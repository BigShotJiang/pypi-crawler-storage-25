"""TagDefinition service/helper contract for Slice 3 tag vocabulary.

This module owns the schema-independent service layer for definition writes
and lookups. Production repositories must execute through the normal runtime
connection/RLS posture; unit tests can use the in-memory repository below.

References: §1.8, §1.10, §1.11, §1.12, §1.14, §1.15, AP5.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from datetime import UTC, datetime, timedelta
from enum import StrEnum
from typing import Any, Protocol, runtime_checkable
from uuid import UUID, uuid4

from pydantic import BaseModel, ConfigDict, Field

from .tag_definitions import (
    TagDefinitionLifecycleState,
    TagDefinitionReference,
    TagDefinitionValidationError,
    TagDefinitionValidationReason,
    TagValueType,
    ValidatedTagDefinitionPayload,
    validate_computed_dependencies,
    validate_lifecycle_transition,
    validate_tag_definition_payload,
)

type JsonObject = dict[str, Any]

DEPRECATED_APPLICATION_GRACE = timedelta(hours=1)


class TagDefinitionServiceReason(StrEnum):
    """Stable service-layer outcome codes safe for caller responses."""

    OK = "ok"
    VALIDATION_FAILED = "tag_definition_validation_failed"
    CONFLICT = "tag_definition_conflict"
    NOT_FOUND = "tag_definition_not_found"
    CROSS_SCOPE_REFERENCE = "tag_definition_cross_scope_reference"
    LIFECYCLE_CONFLICT = "tag_definition_lifecycle_conflict"
    TEMPLATE_INACTIVE = "tag_definition_template_inactive"
    TEMPLATE_REQUIRED = "tag_definition_template_required"
    REPLACEMENT_REQUIRED = "tag_definition_replacement_required"
    REPLACEMENT_SELF = "tag_definition_replacement_self"
    REPLACEMENT_CYCLE = "tag_definition_replacement_cycle"
    COMPUTED_DEPENDENT_BLOCKS_RETIRE = "tag_definition_computed_dependent_blocks_retire"
    ADOPTION_CONFLICT = "tag_definition_template_adoption_conflict"


class TagDefinitionServiceStatus(StrEnum):
    """Machine-readable result category for service callers."""

    CREATED = "created"
    OK = "ok"
    VALIDATION_ERROR = "validation_error"
    CONFLICT = "conflict"
    NOT_FOUND = "not_found"
    CROSS_SCOPE = "cross_scope"


class TagDefinitionServiceContext(BaseModel):
    """Explicit principal/org context required by all service calls."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    principal_id: UUID
    tenant_id: UUID


class TagDefinitionRecord(BaseModel):
    """Service-facing TagDefinition row shape.

    Hidden references must never be included in failed results; successful
    rows are already RLS-visible by repository contract.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    tenant_id: UUID | None
    name: str
    name_canonical: str
    value_type: TagValueType
    lifecycle_state: TagDefinitionLifecycleState
    requires_currency: bool = False
    enum_values_canonical: tuple[str, ...] | None = None
    computed_depends_on_canonical: tuple[str, ...] | None = None
    validation_rules: JsonObject = Field(default_factory=dict)
    attrs: JsonObject = Field(default_factory=dict)
    ontology_version_id: UUID | None = None
    replaced_by_tag_definition_id: UUID | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    deprecated_at: datetime | None = None
    retired_at: datetime | None = None

    def as_reference(self) -> TagDefinitionReference:
        return TagDefinitionReference(
            id=self.id,
            tenant_id=self.tenant_id,
            name=self.name,
            value_type=self.value_type,
            lifecycle_state=self.lifecycle_state,
            ontology_version_id=self.ontology_version_id,
            computed_depends_on_canonical=self.computed_depends_on_canonical,
        )


class TagDefinitionApplicationContract(BaseModel):
    """Definition shape consumed by future NodeTag writes."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    definition: TagDefinitionRecord
    accepts_new_applications: bool
    reason_code: TagDefinitionServiceReason = TagDefinitionServiceReason.OK
    evaluated_at: datetime
    deprecated_grace_expires_at: datetime | None = None
    is_deprecated_grace: bool = False


class TagDefinitionServiceResult(BaseModel):
    """Uniform success/failure shape for tag definition service methods."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    status: TagDefinitionServiceStatus
    reason_code: TagDefinitionServiceReason
    definition: TagDefinitionRecord | None = None
    definitions: tuple[TagDefinitionRecord, ...] = ()
    application_contract: TagDefinitionApplicationContract | None = None
    dependents: tuple[TagDefinitionReference, ...] = ()
    validation_reason: TagDefinitionValidationReason | None = None
    message: str | None = None

    @property
    def ok(self) -> bool:
        return self.status in {TagDefinitionServiceStatus.CREATED, TagDefinitionServiceStatus.OK}


class TemplateAdoptionWriteStatus(StrEnum):
    """Repository-level adoption outcome after unique-index handling."""

    CREATED = "created"
    EXISTING = "existing"
    CONFLICT = "conflict"


class TemplateAdoptionWriteResult(BaseModel):
    """Repository result for template fork idempotency/conflict handling."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    status: TemplateAdoptionWriteStatus
    definition: TagDefinitionRecord | None = None


class TagDefinitionCreateRequest(BaseModel):
    """Create request after caller-supplied context is separated."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    payload: JsonObject
    ontology_version_id: UUID | None = None


@runtime_checkable
class TagDefinitionRepository(Protocol):
    """Storage surface for tag definition services.

    Implementations are expected to use the normal runtime database role, RLS,
    and principal/session GUCs. Lifecycle methods must set timestamps with
    database transaction time, not application-clock values.
    """

    async def create(
        self,
        *,
        context: TagDefinitionServiceContext,
        payload: ValidatedTagDefinitionPayload,
        ontology_version_id: UUID | None,
    ) -> TagDefinitionRecord:
        """Insert one active org-scoped definition or raise ``DuplicateTagDefinitionError``."""
        ...

    async def list(
        self,
        *,
        context: TagDefinitionServiceContext,
        lifecycle_state: TagDefinitionLifecycleState | None = None,
        include_templates: bool = False,
    ) -> Sequence[TagDefinitionRecord]:
        """Return only RLS-visible definitions for ``context``."""
        ...

    async def get_visible(
        self,
        *,
        context: TagDefinitionServiceContext,
        definition_id: UUID,
    ) -> TagDefinitionRecord | None:
        """Return an RLS-visible definition by id, or ``None`` without leaking hidden rows."""
        ...

    async def database_now(self) -> datetime:
        """Return database transaction time for lifecycle grace decisions."""
        ...

    async def find_by_canonical_name(
        self,
        *,
        tenant_id: UUID,
        name_canonical: str,
        ontology_version_id: UUID | None = None,
    ) -> TagDefinitionReference | None:
        """Resolve dependency names in the same org and optional ontology version."""
        ...

    async def replacement_chain_contains(
        self,
        *,
        context: TagDefinitionServiceContext,
        start_definition_id: UUID,
        target_definition_id: UUID,
    ) -> bool:
        """Return whether following replacements reaches ``target_definition_id``."""
        ...

    async def active_computed_dependents(
        self,
        *,
        context: TagDefinitionServiceContext,
        source_definition_id: UUID,
    ) -> Sequence[TagDefinitionReference]:
        """Return active computed definitions depending on ``source_definition_id``."""
        ...

    async def deprecate_with_db_time(
        self,
        *,
        context: TagDefinitionServiceContext,
        definition_id: UUID,
        replacement_id: UUID,
    ) -> TagDefinitionRecord:
        """Set deprecated lifecycle fields using database transaction time."""
        ...

    async def retire_with_db_time(
        self,
        *,
        context: TagDefinitionServiceContext,
        definition_id: UUID,
        replacement_id: UUID | None,
    ) -> TagDefinitionRecord:
        """Set retired lifecycle fields using database transaction time."""
        ...

    async def adopt_template(
        self,
        *,
        context: TagDefinitionServiceContext,
        template: TagDefinitionRecord,
    ) -> TemplateAdoptionWriteResult:
        """Fork an active template into org scope with ``attrs.forked_from``."""
        ...


class DuplicateTagDefinitionError(Exception):
    """Repository unique-name conflict that maps to a safe 409 result."""


def map_validation_error(error: TagDefinitionValidationError) -> TagDefinitionServiceResult:
    """Map pure validator failures to a service result without hidden identifiers."""

    return TagDefinitionServiceResult(
        status=TagDefinitionServiceStatus.VALIDATION_ERROR,
        reason_code=TagDefinitionServiceReason.VALIDATION_FAILED,
        validation_reason=error.reason_code,
        message=str(error),
    )


def map_conflict(message: str = "tag definition write conflicted") -> TagDefinitionServiceResult:
    return TagDefinitionServiceResult(
        status=TagDefinitionServiceStatus.CONFLICT,
        reason_code=TagDefinitionServiceReason.CONFLICT,
        message=message,
    )


def map_not_found(message: str = "tag definition was not found") -> TagDefinitionServiceResult:
    return TagDefinitionServiceResult(
        status=TagDefinitionServiceStatus.NOT_FOUND,
        reason_code=TagDefinitionServiceReason.NOT_FOUND,
        message=message,
    )


def map_cross_scope(
    message: str = "tag definition reference is outside scope",
) -> TagDefinitionServiceResult:
    return TagDefinitionServiceResult(
        status=TagDefinitionServiceStatus.CROSS_SCOPE,
        reason_code=TagDefinitionServiceReason.CROSS_SCOPE_REFERENCE,
        message=message,
    )


class TagDefinitionService:
    """Service/helper bundle for tag vocabulary operations."""

    def __init__(self, repository: TagDefinitionRepository) -> None:
        self._repository = repository

    async def create_tag_definition(
        self,
        context: TagDefinitionServiceContext,
        request: TagDefinitionCreateRequest,
    ) -> TagDefinitionServiceResult:
        try:
            payload = validate_tag_definition_payload(request.payload)
            if payload.value_type is TagValueType.COMPUTED:
                await self._validate_computed_payload(
                    context=context,
                    definition_id=None,
                    payload=payload,
                    ontology_version_id=request.ontology_version_id,
                )
            definition = await self._repository.create(
                context=context,
                payload=payload,
                ontology_version_id=request.ontology_version_id,
            )
        except TagDefinitionValidationError as exc:
            return map_validation_error(exc)
        except DuplicateTagDefinitionError:
            return map_conflict()

        return TagDefinitionServiceResult(
            status=TagDefinitionServiceStatus.CREATED,
            reason_code=TagDefinitionServiceReason.OK,
            definition=definition,
        )

    async def list_tag_definitions(
        self,
        context: TagDefinitionServiceContext,
        *,
        lifecycle_state: TagDefinitionLifecycleState | None = None,
        include_templates: bool = False,
    ) -> TagDefinitionServiceResult:
        definitions = await self._repository.list(
            context=context,
            lifecycle_state=lifecycle_state,
            include_templates=include_templates,
        )
        return TagDefinitionServiceResult(
            status=TagDefinitionServiceStatus.OK,
            reason_code=TagDefinitionServiceReason.OK,
            definitions=tuple(definitions),
        )

    async def get_definition_for_application(
        self,
        context: TagDefinitionServiceContext,
        definition_id: UUID,
    ) -> TagDefinitionServiceResult:
        definition = await self._repository.get_visible(
            context=context, definition_id=definition_id
        )
        if definition is None:
            return map_not_found()
        if definition.tenant_id is None:
            return TagDefinitionServiceResult(
                status=TagDefinitionServiceStatus.VALIDATION_ERROR,
                reason_code=TagDefinitionServiceReason.TEMPLATE_REQUIRED,
                message="template definitions cannot be applied directly",
            )
        if definition.tenant_id != context.tenant_id:
            return map_cross_scope()

        evaluated_at = await self._repository.database_now()
        accepts_new_applications, reason_code, grace_expires_at, is_deprecated_grace = (
            _application_lifecycle_contract(definition, evaluated_at=evaluated_at)
        )
        contract = TagDefinitionApplicationContract(
            definition=definition,
            accepts_new_applications=accepts_new_applications,
            reason_code=reason_code,
            evaluated_at=evaluated_at,
            deprecated_grace_expires_at=grace_expires_at,
            is_deprecated_grace=is_deprecated_grace,
        )
        return TagDefinitionServiceResult(
            status=TagDefinitionServiceStatus.OK,
            reason_code=TagDefinitionServiceReason.OK,
            application_contract=contract,
        )

    async def deprecate_tag_definition(
        self,
        context: TagDefinitionServiceContext,
        *,
        definition_id: UUID,
        replacement_id: UUID,
    ) -> TagDefinitionServiceResult:
        validation = await self._validate_replacement(
            context=context,
            definition_id=definition_id,
            replacement_id=replacement_id,
            expected_current_state=TagDefinitionLifecycleState.ACTIVE,
        )
        if not validation.ok:
            return validation

        definition = await self._repository.deprecate_with_db_time(
            context=context,
            definition_id=definition_id,
            replacement_id=replacement_id,
        )
        return TagDefinitionServiceResult(
            status=TagDefinitionServiceStatus.OK,
            reason_code=TagDefinitionServiceReason.OK,
            definition=definition,
        )

    async def retire_tag_definition(
        self,
        context: TagDefinitionServiceContext,
        *,
        definition_id: UUID,
        replacement_id: UUID | None = None,
    ) -> TagDefinitionServiceResult:
        definition = await self._repository.get_visible(
            context=context, definition_id=definition_id
        )
        if definition is None:
            return map_not_found()
        if definition.tenant_id != context.tenant_id:
            return map_cross_scope()

        try:
            validate_lifecycle_transition(
                definition.lifecycle_state,
                TagDefinitionLifecycleState.RETIRED,
            )
        except TagDefinitionValidationError as exc:
            return TagDefinitionServiceResult(
                status=TagDefinitionServiceStatus.CONFLICT,
                reason_code=TagDefinitionServiceReason.LIFECYCLE_CONFLICT,
                validation_reason=exc.reason_code,
                message=str(exc),
            )

        if replacement_id is not None:
            validation = await self._validate_replacement(
                context=context,
                definition_id=definition_id,
                replacement_id=replacement_id,
                expected_current_state=TagDefinitionLifecycleState.DEPRECATED,
            )
            if not validation.ok:
                return validation

        dependents = await self._repository.active_computed_dependents(
            context=context,
            source_definition_id=definition_id,
        )
        if dependents:
            return TagDefinitionServiceResult(
                status=TagDefinitionServiceStatus.CONFLICT,
                reason_code=TagDefinitionServiceReason.COMPUTED_DEPENDENT_BLOCKS_RETIRE,
                dependents=tuple(dependents),
                message="active computed dependents block retirement",
            )

        retired = await self._repository.retire_with_db_time(
            context=context,
            definition_id=definition_id,
            replacement_id=replacement_id,
        )
        return TagDefinitionServiceResult(
            status=TagDefinitionServiceStatus.OK,
            reason_code=TagDefinitionServiceReason.OK,
            definition=retired,
        )

    async def adopt_template_definition(
        self,
        context: TagDefinitionServiceContext,
        template_definition_id: UUID,
    ) -> TagDefinitionServiceResult:
        template = await self._repository.get_visible(
            context=context,
            definition_id=template_definition_id,
        )
        if template is None:
            return map_not_found("template definition was not found")
        if template.tenant_id is not None:
            return TagDefinitionServiceResult(
                status=TagDefinitionServiceStatus.VALIDATION_ERROR,
                reason_code=TagDefinitionServiceReason.TEMPLATE_REQUIRED,
                message="adoption requires a template definition",
            )
        if template.lifecycle_state is not TagDefinitionLifecycleState.ACTIVE:
            return TagDefinitionServiceResult(
                status=TagDefinitionServiceStatus.CONFLICT,
                reason_code=TagDefinitionServiceReason.TEMPLATE_INACTIVE,
                message="only active templates can be adopted",
            )

        result = await self._repository.adopt_template(context=context, template=template)
        if result.status is TemplateAdoptionWriteStatus.CONFLICT or result.definition is None:
            return TagDefinitionServiceResult(
                status=TagDefinitionServiceStatus.CONFLICT,
                reason_code=TagDefinitionServiceReason.ADOPTION_CONFLICT,
                message="template adoption conflicted",
            )
        return TagDefinitionServiceResult(
            status=(
                TagDefinitionServiceStatus.CREATED
                if result.status is TemplateAdoptionWriteStatus.CREATED
                else TagDefinitionServiceStatus.OK
            ),
            reason_code=TagDefinitionServiceReason.OK,
            definition=result.definition,
        )

    async def reverse_computed_dependents(
        self,
        context: TagDefinitionServiceContext,
        source_definition_id: UUID,
    ) -> TagDefinitionServiceResult:
        definition = await self._repository.get_visible(
            context=context,
            definition_id=source_definition_id,
        )
        if definition is None:
            return map_not_found()
        if definition.tenant_id != context.tenant_id:
            return map_cross_scope()
        dependents = await self._repository.active_computed_dependents(
            context=context,
            source_definition_id=source_definition_id,
        )
        return TagDefinitionServiceResult(
            status=TagDefinitionServiceStatus.OK,
            reason_code=TagDefinitionServiceReason.OK,
            dependents=tuple(dependents),
        )

    async def _validate_replacement(
        self,
        *,
        context: TagDefinitionServiceContext,
        definition_id: UUID,
        replacement_id: UUID,
        expected_current_state: TagDefinitionLifecycleState,
    ) -> TagDefinitionServiceResult:
        definition = await self._repository.get_visible(
            context=context, definition_id=definition_id
        )
        replacement = await self._repository.get_visible(
            context=context,
            definition_id=replacement_id,
        )
        if definition is None or replacement is None:
            return map_not_found()
        if definition.tenant_id != context.tenant_id or replacement.tenant_id != context.tenant_id:
            return map_cross_scope()
        if definition.id == replacement.id:
            return TagDefinitionServiceResult(
                status=TagDefinitionServiceStatus.CONFLICT,
                reason_code=TagDefinitionServiceReason.REPLACEMENT_SELF,
                message="replacement cannot be the same definition",
            )
        try:
            validate_lifecycle_transition(
                definition.lifecycle_state,
                TagDefinitionLifecycleState.DEPRECATED
                if expected_current_state is TagDefinitionLifecycleState.ACTIVE
                else TagDefinitionLifecycleState.RETIRED,
            )
        except TagDefinitionValidationError as exc:
            return TagDefinitionServiceResult(
                status=TagDefinitionServiceStatus.CONFLICT,
                reason_code=TagDefinitionServiceReason.LIFECYCLE_CONFLICT,
                validation_reason=exc.reason_code,
                message=str(exc),
            )
        if definition.lifecycle_state is not expected_current_state:
            return TagDefinitionServiceResult(
                status=TagDefinitionServiceStatus.CONFLICT,
                reason_code=TagDefinitionServiceReason.LIFECYCLE_CONFLICT,
                message="definition lifecycle state does not match operation",
            )
        if replacement.lifecycle_state is not TagDefinitionLifecycleState.ACTIVE:
            return TagDefinitionServiceResult(
                status=TagDefinitionServiceStatus.CONFLICT,
                reason_code=TagDefinitionServiceReason.LIFECYCLE_CONFLICT,
                message="replacement must be active",
            )
        if await self._repository.replacement_chain_contains(
            context=context,
            start_definition_id=replacement.id,
            target_definition_id=definition.id,
        ):
            return TagDefinitionServiceResult(
                status=TagDefinitionServiceStatus.CONFLICT,
                reason_code=TagDefinitionServiceReason.REPLACEMENT_CYCLE,
                message="replacement chain would create a cycle",
            )
        return TagDefinitionServiceResult(
            status=TagDefinitionServiceStatus.OK,
            reason_code=TagDefinitionServiceReason.OK,
        )

    async def _validate_computed_payload(
        self,
        *,
        context: TagDefinitionServiceContext,
        definition_id: UUID | None,
        payload: ValidatedTagDefinitionPayload,
        ontology_version_id: UUID | None,
    ) -> None:
        dependency_names = payload.computed_depends_on_canonical or ()
        references = [
            await self._repository.find_by_canonical_name(
                tenant_id=context.tenant_id,
                name_canonical=name,
                ontology_version_id=ontology_version_id,
            )
            for name in dependency_names
        ]
        repository = _ResolvedDependencyRepository(references)
        validate_computed_dependencies(
            definition_id=definition_id,
            tenant_id=context.tenant_id,
            dependency_names=dependency_names,
            repository=repository,
            ontology_version_id=ontology_version_id,
        )


class _ResolvedDependencyRepository:
    def __init__(self, references: Sequence[TagDefinitionReference | None]) -> None:
        self._references = tuple(references)

    def find_by_canonical_name(
        self,
        *,
        tenant_id: UUID,
        name_canonical: str,
        ontology_version_id: UUID | None = None,
    ) -> TagDefinitionReference | None:
        del tenant_id, ontology_version_id
        for reference in self._references:
            if reference is not None and reference.name_canonical == name_canonical:
                return reference
        return None


class InMemoryTagDefinitionRepository:
    """Unit-test repository fixture preserving the service contract."""

    def __init__(
        self,
        definitions: Sequence[TagDefinitionRecord] = (),
        *,
        database_now: datetime | None = None,
    ) -> None:
        self._definitions: dict[UUID, TagDefinitionRecord] = {
            definition.id: definition for definition in definitions
        }
        self._database_now = database_now or datetime.now(UTC)

    async def create(
        self,
        *,
        context: TagDefinitionServiceContext,
        payload: ValidatedTagDefinitionPayload,
        ontology_version_id: UUID | None,
    ) -> TagDefinitionRecord:
        if any(
            definition.tenant_id == context.tenant_id
            and definition.name_canonical == payload.name_canonical
            for definition in self._definitions.values()
        ):
            raise DuplicateTagDefinitionError
        definition = _record_from_payload(
            id=uuid4(),
            tenant_id=context.tenant_id,
            payload=payload,
            ontology_version_id=ontology_version_id,
        )
        self._definitions[definition.id] = definition
        return definition

    async def list(
        self,
        *,
        context: TagDefinitionServiceContext,
        lifecycle_state: TagDefinitionLifecycleState | None = None,
        include_templates: bool = False,
    ) -> Sequence[TagDefinitionRecord]:
        return tuple(
            definition
            for definition in self._definitions.values()
            if (
                definition.tenant_id == context.tenant_id
                or (include_templates and definition.tenant_id is None)
            )
            and (lifecycle_state is None or definition.lifecycle_state is lifecycle_state)
        )

    async def get_visible(
        self,
        *,
        context: TagDefinitionServiceContext,
        definition_id: UUID,
    ) -> TagDefinitionRecord | None:
        definition = self._definitions.get(definition_id)
        if definition is None:
            return None
        if definition.tenant_id in {context.tenant_id, None}:
            return definition
        return None

    async def database_now(self) -> datetime:
        return self._database_now

    async def find_by_canonical_name(
        self,
        *,
        tenant_id: UUID,
        name_canonical: str,
        ontology_version_id: UUID | None = None,
    ) -> TagDefinitionReference | None:
        for definition in self._definitions.values():
            if definition.tenant_id != tenant_id:
                continue
            if definition.name_canonical != name_canonical:
                continue
            if ontology_version_id is not None and definition.ontology_version_id not in {
                None,
                ontology_version_id,
            }:
                continue
            return definition.as_reference()
        return None

    async def replacement_chain_contains(
        self,
        *,
        context: TagDefinitionServiceContext,
        start_definition_id: UUID,
        target_definition_id: UUID,
    ) -> bool:
        del context
        seen: set[UUID] = set()
        current_id: UUID | None = start_definition_id
        while current_id is not None:
            if current_id == target_definition_id:
                return True
            if current_id in seen:
                return False
            seen.add(current_id)
            current = self._definitions.get(current_id)
            current_id = None if current is None else current.replaced_by_tag_definition_id
        return False

    async def active_computed_dependents(
        self,
        *,
        context: TagDefinitionServiceContext,
        source_definition_id: UUID,
    ) -> Sequence[TagDefinitionReference]:
        source = self._definitions.get(source_definition_id)
        if source is None:
            return ()
        return tuple(
            definition.as_reference()
            for definition in self._definitions.values()
            if definition.tenant_id == context.tenant_id
            and definition.lifecycle_state is TagDefinitionLifecycleState.ACTIVE
            and definition.value_type is TagValueType.COMPUTED
            and source.name_canonical in (definition.computed_depends_on_canonical or ())
        )

    async def deprecate_with_db_time(
        self,
        *,
        context: TagDefinitionServiceContext,
        definition_id: UUID,
        replacement_id: UUID,
    ) -> TagDefinitionRecord:
        del context
        database_now = await self.database_now()
        definition = self._definitions[definition_id].model_copy(
            update={
                "lifecycle_state": TagDefinitionLifecycleState.DEPRECATED,
                "replaced_by_tag_definition_id": replacement_id,
                "deprecated_at": database_now,
            },
        )
        self._definitions[definition.id] = definition
        return definition

    async def retire_with_db_time(
        self,
        *,
        context: TagDefinitionServiceContext,
        definition_id: UUID,
        replacement_id: UUID | None,
    ) -> TagDefinitionRecord:
        del context
        database_now = await self.database_now()
        current = self._definitions[definition_id]
        definition = self._definitions[definition_id].model_copy(
            update={
                "lifecycle_state": TagDefinitionLifecycleState.RETIRED,
                "replaced_by_tag_definition_id": replacement_id,
                "deprecated_at": current.deprecated_at or database_now,
                "retired_at": database_now,
            },
        )
        self._definitions[definition.id] = definition
        return definition

    async def adopt_template(
        self,
        *,
        context: TagDefinitionServiceContext,
        template: TagDefinitionRecord,
    ) -> TemplateAdoptionWriteResult:
        existing = next(
            (
                definition
                for definition in self._definitions.values()
                if definition.tenant_id == context.tenant_id
                and definition.name_canonical == template.name_canonical
                and definition.attrs.get("forked_from") == str(template.id)
            ),
            None,
        )
        if existing is not None:
            return TemplateAdoptionWriteResult(
                status=TemplateAdoptionWriteStatus.EXISTING,
                definition=existing,
            )
        if any(
            definition.tenant_id == context.tenant_id
            and definition.name_canonical == template.name_canonical
            for definition in self._definitions.values()
        ):
            return TemplateAdoptionWriteResult(status=TemplateAdoptionWriteStatus.CONFLICT)

        fork = template.model_copy(
            update={
                "id": uuid4(),
                "tenant_id": context.tenant_id,
                "attrs": {**template.attrs, "forked_from": str(template.id)},
            },
        )
        self._definitions[fork.id] = fork
        return TemplateAdoptionWriteResult(
            status=TemplateAdoptionWriteStatus.CREATED,
            definition=fork,
        )


def _record_from_payload(
    *,
    id: UUID,
    tenant_id: UUID | None,
    payload: ValidatedTagDefinitionPayload,
    ontology_version_id: UUID | None,
) -> TagDefinitionRecord:
    return TagDefinitionRecord(
        id=id,
        tenant_id=tenant_id,
        name=payload.name,
        name_canonical=payload.name_canonical,
        value_type=payload.value_type,
        lifecycle_state=TagDefinitionLifecycleState.ACTIVE,
        requires_currency=payload.requires_currency,
        enum_values_canonical=payload.enum_values_canonical,
        computed_depends_on_canonical=payload.computed_depends_on_canonical,
        validation_rules=payload.validation_rules,
        attrs=payload.attrs,
        ontology_version_id=ontology_version_id,
    )


def _application_lifecycle_contract(
    definition: TagDefinitionRecord,
    *,
    evaluated_at: datetime,
) -> tuple[bool, TagDefinitionServiceReason, datetime | None, bool]:
    if definition.lifecycle_state is TagDefinitionLifecycleState.ACTIVE:
        return True, TagDefinitionServiceReason.OK, None, False

    if definition.lifecycle_state is TagDefinitionLifecycleState.RETIRED:
        return False, TagDefinitionServiceReason.LIFECYCLE_CONFLICT, None, False

    if definition.deprecated_at is None:
        return False, TagDefinitionServiceReason.LIFECYCLE_CONFLICT, None, False

    grace_expires_at = definition.deprecated_at + DEPRECATED_APPLICATION_GRACE
    in_grace = evaluated_at < grace_expires_at
    return (
        in_grace,
        TagDefinitionServiceReason.OK
        if in_grace
        else TagDefinitionServiceReason.LIFECYCLE_CONFLICT,
        grace_expires_at,
        in_grace,
    )


def make_template_definition(
    *,
    id: UUID,
    payload: Mapping[str, Any],
    ontology_version_id: UUID | None = None,
) -> TagDefinitionRecord:
    """Factory for service tests and future cross-feature fixtures."""

    validated = validate_tag_definition_payload(payload)
    return _record_from_payload(
        id=id,
        tenant_id=None,
        payload=validated,
        ontology_version_id=ontology_version_id,
    )
