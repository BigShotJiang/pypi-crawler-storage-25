"""Shared context-of-validity validation helpers."""

from __future__ import annotations

from collections.abc import Mapping
from datetime import datetime
from typing import Any

REQUIRED_CONTEXT_KEYS: frozenset[str] = frozenset(
    ("tenant", "classification", "vertical", "ontology_version", "valid_from", "valid_to")
)


class ContextValidityError(ValueError):
    """Raised when context-of-validity data is malformed."""


def validate_context_timestamps(context: Mapping[str, Any]) -> None:
    """Validate context timestamp shape without changing the context payload."""

    valid_from = _parse_required_aware_datetime(
        context.get("valid_from"),
        reason_code="context_of_validity_valid_from_invalid",
    )
    raw_valid_to = context.get("valid_to")
    if raw_valid_to in {None, ""}:
        return
    valid_to = _parse_required_aware_datetime(
        raw_valid_to,
        reason_code="context_of_validity_valid_to_invalid",
    )
    if valid_to < valid_from:
        raise ContextValidityError("context_of_validity_valid_to_before_valid_from")


def _parse_required_aware_datetime(value: object, *, reason_code: str) -> datetime:
    if not isinstance(value, str) or not value.strip():
        raise ContextValidityError(reason_code)
    normalized = value.strip()
    if normalized.endswith("Z"):
        normalized = f"{normalized[:-1]}+00:00"
    try:
        parsed = datetime.fromisoformat(normalized)
    except ValueError as exc:
        raise ContextValidityError(reason_code) from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ContextValidityError(reason_code)
    return parsed
