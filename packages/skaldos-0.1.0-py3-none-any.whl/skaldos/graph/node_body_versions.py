"""Storage-owned Pattern 2 Node body update writer."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict, Field

from skaldos.graph.pattern_validation import (
    GraphPatternValidationError,
    GraphPatternValidationReason,
    Pattern2BodyUpdateGuard,
    Pattern2VersionSnapshot,
    PatternOperation,
    ResolvedGraphPattern,
    validate_pattern2_body_update,
)
from skaldos.graph.transaction import with_principal
from skaldos.graph.type_classifier import KindDiscriminator, UpdatePattern
from skaldos.middleware import Principal


class Pattern2NodeBodyUpdateRequest(BaseModel):
    """Request for an optimistic Pattern 2 body update."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    node_id: UUID
    new_body: str = Field(min_length=1)
    expected_version: int = Field(ge=1)


class Pattern2NodeBodyUpdateResult(BaseModel):
    """Result of an atomic Pattern 2 body update."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    node_id: UUID
    snapshot_id: UUID
    previous_version: int
    new_version: int
    previous_body_hash: str


async def update_pattern2_node_body(  # pragma: no cover - exercised by integration DB tests
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    request: Pattern2NodeBodyUpdateRequest,
) -> Pattern2NodeBodyUpdateResult:
    """Snapshot the current body and update a Pattern 2 Node in one transaction."""

    async def _update(bound_connection: asyncpg.Connection) -> Pattern2NodeBodyUpdateResult:
        row = await bound_connection.fetchrow(  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
            """
            SELECT
              n.id,
              n.type_id,
              n.context_of_validity,
              n.ontology_version_id,
              n.tenant_id,
              n.body,
              n.body_nfc_hash,
              n.summary,
              n.metadata,
              n.embedding_pii_mode,
              n.authored_by_principal_id,
              n.version,
              n.created_at,
              n.archived_at,
              ot.name AS type_name,
              ot.kind_discriminator::text AS kind_discriminator,
              ot.update_pattern
            FROM nodes n
            JOIN ontology_type ot
              ON ot.id = n.type_id
             AND ot.ontology_version_id = n.ontology_version_id
            WHERE n.id = $1
            FOR UPDATE OF n
            """,
            request.node_id,
        )
        if row is None:
            raise GraphPatternValidationError(
                GraphPatternValidationReason.ONTOLOGY_TYPE_NOT_FOUND,
                "Pattern 2 node was not visible",
                operation=PatternOperation.UPDATE_BODY,
            )
        row = cast(Mapping[str, Any], row)
        current_version = cast(int, row["version"])
        if current_version != request.expected_version:
            raise GraphPatternValidationError(
                GraphPatternValidationReason.SUPERSESSION_CONFLICT,
                "Pattern 2 body update expected_version is stale",
                operation=PatternOperation.UPDATE_BODY,
            )

        resolved = ResolvedGraphPattern(
            ontology_type_id=cast(UUID, row["type_id"]),
            ontology_version_id=cast(UUID, row["ontology_version_id"]),
            type_name=cast(str, row["type_name"]),
            kind_discriminator=cast(KindDiscriminator, row["kind_discriminator"]),
            update_pattern=cast(UpdatePattern, row["update_pattern"]),
        )
        snapshot_id = cast(
            UUID,
            await bound_connection.fetchval(  # pyright: ignore[reportUnknownMemberType]
                """
                INSERT INTO node_body_versions (
                  node_id,
                  tenant_id,
                  context_of_validity,
                  type_id,
                  ontology_version_id,
                  version,
                  body,
                  body_snapshot_digest,
                  summary,
                  metadata,
                  embedding_pii_mode,
                  authored_by_principal_id,
                  snapshot_by_principal_id,
                  node_created_at,
                  node_archived_at
                )
                VALUES (
                  $1, $2, $3::jsonb, $4, $5, $6, $7, $8, $9, $10::jsonb,
                  $11, $12, $13, $14, $15
                )
                RETURNING id
                """,
                row["id"],
                row["tenant_id"],
                row["context_of_validity"],
                row["type_id"],
                row["ontology_version_id"],
                current_version,
                row["body"],
                row["body_nfc_hash"],
                row["summary"],
                row["metadata"],
                row["embedding_pii_mode"],
                row["authored_by_principal_id"],
                principal.id,
                row["created_at"],
                row["archived_at"],
            ),
        )
        previous_body_hash = f"sha256:{bytes(row['body_nfc_hash']).hex()}"
        validate_pattern2_body_update(
            resolved=resolved,
            guard=Pattern2BodyUpdateGuard(
                target_node_id=request.node_id,
                version_snapshot=Pattern2VersionSnapshot(
                    node_id=request.node_id,
                    previous_body_hash=previous_body_hash,
                    snapshot_ref=snapshot_id,
                ),
                requested_update_pattern=resolved.update_pattern,
                requested_ontology_type_id=resolved.ontology_type_id,
            ),
        )
        updated = await bound_connection.fetchrow(  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
            """
            UPDATE nodes
            SET body = $2,
                version = version + 1
            WHERE id = $1
              AND version = $3
            RETURNING version
            """,
            request.node_id,
            request.new_body,
            current_version,
        )
        if updated is None:
            raise GraphPatternValidationError(
                GraphPatternValidationReason.SUPERSESSION_CONFLICT,
                "Pattern 2 body update lost optimistic version race",
                operation=PatternOperation.UPDATE_BODY,
            )
        updated = cast(Mapping[str, Any], updated)
        return Pattern2NodeBodyUpdateResult(
            node_id=request.node_id,
            snapshot_id=snapshot_id,
            previous_version=current_version,
            new_version=cast(int, updated["version"]),
            previous_body_hash=previous_body_hash,
        )

    return await with_principal(principal=principal, connection=connection, fn=_update)


def context_tenant_id(context: Mapping[str, Any]) -> UUID:  # pragma: no cover - service helper
    """Return the tenant id from a graph context mapping."""

    return UUID(str(context["tenant"]))
