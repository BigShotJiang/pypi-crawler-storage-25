"""Command-service orchestration for ``POST /graph/assert``.

The FastAPI route owns the public envelope and HTTP mapping. This module owns
the transaction-adjacent graph assertion command flow: policy intent check,
staging, resolver handoff, narrow canonical application, tag assertion
application, and audit emission.
"""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from contextlib import AbstractAsyncContextManager
from datetime import UTC, datetime
from decimal import Decimal, InvalidOperation
from typing import Any, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict, Field

from skaldos.events.graph_publisher import (
    GraphChangeEventDraft,
    GraphChangeEventType,
    OutboxGraphChangeEventPublisher,
)
from skaldos.events.outbox import OutboxContextOfValidity
from skaldos.falsification.decision_revisions import (
    DecisionRevisionDraft,
    revise_with_falsifier,
)
from skaldos.graph.assert_apply import (
    AppliedAssertionRecord,
    apply_resolved_assertion_as_node,
    assertion_supports_node_application,
)
from skaldos.graph.assert_audit import AuditOutcome, emit_assertion_audit_entry
from skaldos.graph.assert_contract import (
    OUTCOME_PUBLIC_STATUS,
    AssertionResolutionOutcome,
    GraphAssertPublicStatus,
)
from skaldos.graph.assert_resolution import (
    AssertionResolutionVisibleResult,
    NodeTagSingletonResolution,
    StagedAssertionCandidate,
    resolve_node_tag_singleton_supersession,
)
from skaldos.graph.assert_staging import (
    AssertionCanonicalInput,
    AssertionCanonicalizationError,
    IdempotencyDecision,
    PendingAssertionStatus,
    handoff_staged_assertion_to_resolver,
    stage_single_assertion,
)
from skaldos.graph.edge_repository import AsyncEdgeRepository
from skaldos.graph.edges import (
    EdgeCreatePayload,
    EdgeRow,
    EdgeWriteContext,
    RepositoryEdgeService,
    validate_edge_create_payload,
)
from skaldos.graph.node_body_versions import (
    Pattern2NodeBodyUpdateRequest,
    update_pattern2_node_body,
)
from skaldos.graph.node_tag_repository import AsyncNodeTagRepository
from skaldos.graph.node_tags import (
    NodeTagApplyRequest,
    NodeTagSourceSnapshot,
    NodeTagValue,
    TextQuoteSelector,
    compute_node_tag_content_digest,
)
from skaldos.graph.tag_definitions_service import TagDefinitionServiceContext
from skaldos.middleware import Principal
from skaldos.policy.assertion_authorization import (
    AssertionAuthorizationReason,
    AssertionPolicyDecision,
    AssertionPolicyDeniedError,
    AssertionPolicyEvaluationError,
    AssertionPolicyEvaluationMetadata,
    authorize_assertion_intent,
    derive_assertion_subject,
)


class GraphAssertCommand(BaseModel):
    """Service command built by the public route after envelope validation."""

    model_config = ConfigDict(frozen=True, extra="forbid", arbitrary_types_allowed=True)

    principal: Principal
    connection: Any = Field(repr=False)
    assertion: AssertionCanonicalInput
    idempotency_key: str
    node_chunk_embedding_generator: Any | None = Field(default=None, repr=False)


class GraphAssertCommandResult(BaseModel):
    """Route-facing projection of a completed graph assertion command."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    status: GraphAssertPublicStatus
    assertion_id: UUID
    pending_assertion_id: UUID
    applied_node_ids: tuple[UUID, ...] = ()
    applied_edge_ids: tuple[UUID, ...] = ()
    warnings: tuple[str, ...] = ()
    conflict_id: UUID | None = None


async def execute_graph_assert_command(command: GraphAssertCommand) -> GraphAssertCommandResult:
    """Run one graph assertion through policy, staging, apply, and audit."""

    assertion = command.assertion
    principal = command.principal
    connection = command.connection
    policy_decision: AssertionPolicyDecision | None = None
    try:
        subject = await derive_assertion_subject(
            assertion=assertion,
            principal=principal,
            connection=connection,
        )
        policy_decision = authorize_assertion_intent(
            principal=principal,
            intent=assertion.intent,
            subject=subject.subject,
        )
        await _validate_mutation_targets_before_staging(
            connection=connection,
            assertion=assertion,
        )
        staged = await _stage_single_assertion_with_savepoint(
            principal=principal,
            connection=connection,
            assertion=assertion,
            idempotency_key=command.idempotency_key,
        )
        if (
            staged.idempotency_decision is IdempotencyDecision.INSERT
            and staged.status is PendingAssertionStatus.STAGED
        ):
            handoff = await handoff_staged_assertion_to_resolver(
                principal=principal,
                connection=connection,
                staged_assertion_id=staged.id,
            )
            staged = staged.model_copy(update={"status": handoff.status})
        applied: AppliedAssertionRecord | None = None
        if staged.status in {
            PendingAssertionStatus.RESOLVED,
            PendingAssertionStatus.APPLIED,
        }:
            applied = await _apply_resolved_mutation_assertion(
                principal=principal,
                connection=connection,
                assertion=assertion,
                staged_assertion_id=staged.id,
            )
            if applied is not None:
                staged = staged.model_copy(update={"status": applied.status})
        if (
            applied is None
            and staged.status
            in {
                PendingAssertionStatus.RESOLVED,
                PendingAssertionStatus.APPLIED,
            }
            and assertion_supports_node_application(assertion.claim)
        ):
            applied = await apply_resolved_assertion_as_node(
                principal=principal,
                connection=connection,
                staged_assertion_id=staged.id,
                node_chunk_embedding_generator=command.node_chunk_embedding_generator,
            )
            staged = staged.model_copy(update={"status": applied.status})
        tag_resolution: NodeTagSingletonResolution | None = None
        if applied is None and staged.status in {
            PendingAssertionStatus.RESOLVED,
            PendingAssertionStatus.APPLIED,
        }:
            tag_resolution = await _apply_resolved_node_tag_assertion(
                principal=principal,
                connection=connection,
                assertion=assertion,
                staged_assertion_id=staged.id,
            )
            if tag_resolution is not None:
                staged = staged.model_copy(
                    update={"status": _pending_status_from_resolution(tag_resolution.result)}
                )
        await emit_graph_assert_audit(
            connection=connection,
            policy=policy_decision,
            context_of_validity=assertion.context_of_validity,
            outcome=AuditOutcome.PERMITTED,
        )
    except AssertionPolicyDeniedError as exc:
        await emit_graph_assert_audit(
            connection=connection,
            policy=exc.decision,
            context_of_validity=assertion.context_of_validity,
            outcome=AuditOutcome.DENIED,
            reason_code=exc.decision.reason_code.value if exc.decision.reason_code else None,
        )
        raise
    except AssertionPolicyEvaluationError as exc:
        await emit_graph_assert_audit(
            connection=connection,
            policy=exc.metadata,
            context_of_validity=assertion.context_of_validity,
            outcome=AuditOutcome.ERROR,
            reason_code=exc.metadata.reason_code.value,
        )
        raise
    except asyncpg.InsufficientPrivilegeError as exc:
        if policy_decision is not None:
            reason_code = AssertionAuthorizationReason.CONTEXT_CONTAINMENT_DENIED
            denied_decision = policy_decision.model_copy(
                update={"decision": "denied", "reason_code": reason_code}
            )
            await emit_graph_assert_audit(
                connection=connection,
                policy=denied_decision,
                context_of_validity=assertion.context_of_validity,
                outcome=AuditOutcome.DENIED,
                reason_code=reason_code.value,
            )
            raise AssertionPolicyDeniedError(denied_decision) from exc
        raise
    except Exception as exc:
        if policy_decision is not None:
            await emit_graph_assert_audit(
                connection=connection,
                policy=policy_decision,
                context_of_validity=assertion.context_of_validity,
                outcome=AuditOutcome.ERROR,
                reason_code=_audit_reason_code(exc),
            )
        raise

    return GraphAssertCommandResult(
        status=(
            OUTCOME_PUBLIC_STATUS[tag_resolution.result.outcome]
            if tag_resolution is not None
            else _public_status_from_staged(staged.status)
        ),
        assertion_id=staged.id,
        pending_assertion_id=staged.id,
        applied_node_ids=applied.applied_node_ids if applied is not None else (),
        applied_edge_ids=applied.applied_edge_ids if applied is not None else (),
        warnings=applied.warnings if applied is not None else (),
        conflict_id=(
            tag_resolution.result.disagreement_id
            if tag_resolution is not None
            and tag_resolution.result.outcome is AssertionResolutionOutcome.DISAGREEMENT_QUEUED
            else None
        ),
    )


async def emit_graph_assert_audit(
    *,
    connection: asyncpg.Connection,
    policy: AssertionPolicyDecision | AssertionPolicyEvaluationMetadata,
    context_of_validity: Mapping[str, Any],
    outcome: AuditOutcome,
    reason_code: str | None = None,
) -> None:
    """Insert one audit row for a graph assertion decision."""

    await emit_assertion_audit_entry(
        connection=connection,
        policy=policy,
        context_of_validity=context_of_validity,
        outcome=outcome,
        reason_code=reason_code,
    )


def _audit_reason_code(exc: Exception) -> str:
    if hasattr(exc, "idempotency_key"):
        return "idempotency_payload_mismatch"
    return str(exc)


async def _stage_single_assertion_with_savepoint(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    assertion: AssertionCanonicalInput,
    idempotency_key: str,
) -> Any:
    """Stage one assertion inside a savepoint when the connection supports it.

    RLS denials abort the current SQL transaction. The request-level
    transaction must remain usable so the service can emit a denied audit row
    before returning the typed 403 response.
    """

    transaction = getattr(connection, "transaction", None)
    if callable(transaction):
        savepoint = cast(AbstractAsyncContextManager[object], transaction())
        async with savepoint:
            return await stage_single_assertion(
                principal=principal,
                connection=connection,
                assertion=assertion,
                idempotency_key=idempotency_key,
            )
    return await stage_single_assertion(
        principal=principal,
        connection=connection,
        assertion=assertion,
        idempotency_key=idempotency_key,
    )


def _public_status_from_staged(status: PendingAssertionStatus) -> GraphAssertPublicStatus:
    if status is PendingAssertionStatus.APPLIED:
        return GraphAssertPublicStatus.APPLIED
    if status is PendingAssertionStatus.REJECTED:
        return GraphAssertPublicStatus.REJECTED
    if status is PendingAssertionStatus.DISAGREEMENT:
        return GraphAssertPublicStatus.DISAGREEMENT
    return GraphAssertPublicStatus.STAGED


async def _validate_mutation_targets_before_staging(
    *,
    connection: asyncpg.Connection,
    assertion: AssertionCanonicalInput,
) -> None:
    claim_kind = _claim_kind(assertion.claim)
    tenant_id = UUID(str(assertion.context_of_validity["tenant"]))
    if claim_kind == "node_body_update":
        request = _node_body_update_request_from_claim(assertion.claim)
        await _ensure_node_in_assertion_tenant(
            connection=connection,
            node_id=request.node_id,
            tenant_id=tenant_id,
        )
        return
    if claim_kind == "edge_create":
        payload = _edge_create_payload_from_claim(assertion.claim)
        await _ensure_node_in_assertion_tenant(
            connection=connection,
            node_id=payload.source_node_id,
            tenant_id=tenant_id,
        )
        await _ensure_node_in_assertion_tenant(
            connection=connection,
            node_id=payload.target_node_id,
            tenant_id=tenant_id,
        )


async def _apply_resolved_mutation_assertion(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    assertion: AssertionCanonicalInput,
    staged_assertion_id: UUID,
) -> AppliedAssertionRecord | None:
    claim_kind = _claim_kind(assertion.claim)
    if claim_kind in {"edge_create", "node_body_update", "pattern4_revision"}:
        existing = await _load_existing_applied_record(
            connection=connection,
            principal=principal,
            staged_assertion_id=staged_assertion_id,
        )
        if existing is not None:
            return existing
    if claim_kind == "node_body_update":
        result = await _apply_node_body_update_assertion(
            principal=principal,
            connection=connection,
            assertion=assertion,
            staged_assertion_id=staged_assertion_id,
        )
        return result
    if claim_kind == "edge_create":
        result = await _apply_edge_create_assertion(
            principal=principal,
            connection=connection,
            assertion=assertion,
            staged_assertion_id=staged_assertion_id,
        )
        return result
    if claim_kind == "pattern4_revision":
        result = await _apply_pattern4_revision_assertion(
            principal=principal,
            connection=connection,
            assertion=assertion,
            staged_assertion_id=staged_assertion_id,
        )
        return result
    return None


async def _load_existing_applied_record(
    *,
    connection: asyncpg.Connection,
    principal: Principal,
    staged_assertion_id: UUID,
) -> AppliedAssertionRecord | None:
    row = cast(
        Mapping[str, Any] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
            SELECT
                id,
                status::text AS status,
                applied_node_ids,
                applied_edge_ids,
                applied_tag_ids
            FROM pending_assertions
            WHERE id = $1
              AND actor_principal_id = $2
              AND status = 'applied'
            """,
            staged_assertion_id,
            principal.id,
        ),
    )
    if row is None:
        return None
    return AppliedAssertionRecord(
        id=cast(UUID, row["id"]),
        status=PendingAssertionStatus(cast(str, row["status"])),
        applied_node_ids=tuple(cast(list[UUID], row["applied_node_ids"])),
        applied_edge_ids=tuple(cast(list[UUID], row["applied_edge_ids"])),
        applied_tag_ids=tuple(cast(list[UUID], row["applied_tag_ids"])),
    )


async def _apply_node_body_update_assertion(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    assertion: AssertionCanonicalInput,
    staged_assertion_id: UUID,
) -> AppliedAssertionRecord:
    request = _node_body_update_request_from_claim(assertion.claim)
    await _ensure_node_in_assertion_tenant(
        connection=connection,
        node_id=request.node_id,
        tenant_id=UUID(str(assertion.context_of_validity["tenant"])),
    )
    result = await update_pattern2_node_body(
        principal=principal,
        connection=connection,
        request=request,
    )
    await _publish_node_updated_event(
        principal=principal,
        connection=connection,
        assertion=assertion,
        node_id=result.node_id,
    )
    return await _mark_pending_assertion_applied(
        connection=connection,
        principal=principal,
        staged_assertion_id=staged_assertion_id,
        status_reason="node_body_updated",
        applied_node_ids=(result.node_id,),
        applied_edge_ids=(),
    )


async def _ensure_node_in_assertion_tenant(
    *,
    connection: asyncpg.Connection,
    node_id: UUID,
    tenant_id: UUID,
) -> None:
    row_tenant_id = cast(
        UUID | None,
        await connection.fetchval(  # pyright: ignore[reportUnknownMemberType]
            """
            SELECT tenant_id
            FROM nodes
            WHERE id = $1
              AND tenant_id = ANY ((SELECT app.principal_visible())::uuid[])
            """,
            node_id,
        ),
    )
    if row_tenant_id is None:
        raise AssertionCanonicalizationError("mutation_target_not_visible")
    if row_tenant_id != tenant_id:
        raise AssertionCanonicalizationError("mutation_target_tenant_mismatch")


def _node_body_update_request_from_claim(
    claim: Mapping[str, Any],
) -> Pattern2NodeBodyUpdateRequest:
    target = claim.get("target")
    target_mapping: Mapping[str, Any] = (
        cast(Mapping[str, Any], target) if isinstance(target, Mapping) else {}
    )
    node_id_value = target_mapping.get("node_id", claim.get("node_id"))
    expected_version_value = target_mapping.get("expected_version", claim.get("expected_version"))
    new_body_value = claim.get("new_body", claim.get("body"))
    if not isinstance(node_id_value, str):
        raise AssertionCanonicalizationError("node_body_update_target_required")
    if not isinstance(expected_version_value, int):
        raise AssertionCanonicalizationError("node_body_update_expected_version_required")
    if not isinstance(new_body_value, str) or not new_body_value.strip():
        raise AssertionCanonicalizationError("node_body_update_body_required")
    try:
        node_id = UUID(node_id_value)
    except ValueError as exc:
        raise AssertionCanonicalizationError("node_body_update_target_invalid") from exc
    return Pattern2NodeBodyUpdateRequest(
        node_id=node_id,
        new_body=new_body_value,
        expected_version=expected_version_value,
    )


async def _apply_edge_create_assertion(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    assertion: AssertionCanonicalInput,
    staged_assertion_id: UUID,
) -> AppliedAssertionRecord:
    payload = _edge_create_payload_from_claim(assertion.claim)
    service = RepositoryEdgeService(AsyncEdgeRepository(connection))
    edge = await service.create_edge(
        payload,
        context=EdgeWriteContext(
            tenant_id=UUID(str(assertion.context_of_validity["tenant"])),
            actor_principal_id=principal.id,
        ),
    )
    await _publish_edge_created_event(
        principal=principal,
        connection=connection,
        assertion=assertion,
        edge=edge,
    )
    return await _mark_pending_assertion_applied(
        connection=connection,
        principal=principal,
        staged_assertion_id=staged_assertion_id,
        status_reason="edge_created",
        applied_node_ids=(),
        applied_edge_ids=(edge.id,),
    )


def _edge_create_payload_from_claim(claim: Mapping[str, Any]) -> EdgeCreatePayload:
    target = claim.get("target")
    payload: dict[str, Any] = (
        dict(cast(Mapping[str, Any], target)) if isinstance(target, Mapping) else {}
    )
    for key in (
        "source_node_id",
        "target_node_id",
        "relationship_type",
        "weight",
        "requested_classification",
    ):
        if key in claim:
            payload[key] = claim[key]
    for key in ("source_node_id", "target_node_id"):
        if key in payload and isinstance(payload[key], str):
            try:
                payload[key] = UUID(payload[key])
            except ValueError as exc:
                raise AssertionCanonicalizationError("edge_create_endpoint_invalid") from exc
    return validate_edge_create_payload(payload)


async def _apply_pattern4_revision_assertion(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    assertion: AssertionCanonicalInput,
    staged_assertion_id: UUID,
) -> AppliedAssertionRecord:
    draft = _pattern4_revision_draft_from_claim(
        assertion.claim,
        tenant_id=UUID(str(assertion.context_of_validity["tenant"])),
    )
    result = await revise_with_falsifier(
        principal=principal,
        connection=connection,
        draft=draft,
    )
    return await _mark_pending_assertion_applied(
        connection=connection,
        principal=principal,
        staged_assertion_id=staged_assertion_id,
        status_reason="pattern4_revision_applied",
        applied_node_ids=(result.revision_node_id,),
        applied_edge_ids=(),
    )


def _pattern4_revision_draft_from_claim(
    claim: Mapping[str, Any],
    *,
    tenant_id: UUID,
) -> DecisionRevisionDraft:
    target = claim.get("target")
    target_mapping: Mapping[str, Any] = (
        cast(Mapping[str, Any], target) if isinstance(target, Mapping) else {}
    )
    source_value = target_mapping.get("source_decision_id", claim.get("source_decision_id"))
    body_value = claim.get("revised_body", claim.get("body"))
    grounded_values = _uuid_sequence(
        claim.get("grounded_by_node_ids", target_mapping.get("grounded_by_node_ids"))
    )
    falsifier_value = claim.get("falsifier_node_id", target_mapping.get("falsifier_node_id"))
    occurred_at_value = claim.get("occurred_at")
    if not isinstance(source_value, str):
        raise AssertionCanonicalizationError("pattern4_revision_source_required")
    if not isinstance(falsifier_value, str):
        raise AssertionCanonicalizationError("pattern4_revision_falsifier_required")
    if not isinstance(body_value, str) or not body_value.strip():
        raise AssertionCanonicalizationError("pattern4_revision_body_required")
    if occurred_at_value is None:
        raise AssertionCanonicalizationError("pattern4_revision_occurred_at_required")
    try:
        source_decision_id = UUID(source_value)
        falsifier_node_id = UUID(falsifier_value)
    except ValueError as exc:
        raise AssertionCanonicalizationError("pattern4_revision_target_invalid") from exc
    return DecisionRevisionDraft(
        tenant_id=tenant_id,
        source_decision_id=source_decision_id,
        revised_body=body_value,
        grounded_by_node_ids=grounded_values,
        falsifier_node_id=falsifier_node_id,
        critical_path_dependent_node_ids=_uuid_sequence(
            claim.get("critical_path_dependent_node_ids", ())
        ),
        occurred_at=occurred_at_value,
    )


def _uuid_sequence(value: object) -> tuple[UUID, ...]:
    if not isinstance(value, Sequence) or isinstance(value, str | bytes):
        raise AssertionCanonicalizationError("uuid_sequence_required")
    ids: list[UUID] = []
    for item in cast(Sequence[object], value):
        if not isinstance(item, str):
            raise AssertionCanonicalizationError("uuid_sequence_required")
        try:
            ids.append(UUID(item))
        except ValueError as exc:
            raise AssertionCanonicalizationError("uuid_sequence_invalid") from exc
    return tuple(ids)


async def _publish_node_updated_event(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    assertion: AssertionCanonicalInput,
    node_id: UUID,
) -> None:
    await OutboxGraphChangeEventPublisher(
        connection=connection,
    ).publish_graph_change_event(
        GraphChangeEventDraft(
            event_type=GraphChangeEventType.NODE_UPDATED,
            subject_id=node_id,
            tenant_id=UUID(str(assertion.context_of_validity["tenant"])),
            context_of_validity=OutboxContextOfValidity.model_validate(
                _outbox_context(assertion.context_of_validity)
            ),
            intent=assertion.intent.value,
            actor_principal_id=principal.id,
            occurred_at=datetime.now(UTC),
        )
    )


async def _publish_edge_created_event(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    assertion: AssertionCanonicalInput,
    edge: EdgeRow,
) -> None:
    await OutboxGraphChangeEventPublisher(
        connection=connection,
    ).publish_graph_change_event(
        GraphChangeEventDraft(
            event_type=GraphChangeEventType.EDGE_CREATED,
            subject_id=edge.id,
            tenant_id=edge.tenant_id,
            context_of_validity=OutboxContextOfValidity.model_validate(
                _outbox_context(assertion.context_of_validity)
            ),
            intent=assertion.intent.value,
            actor_principal_id=principal.id,
            occurred_at=edge.created_at,
        )
    )


async def _mark_pending_assertion_applied(
    *,
    connection: asyncpg.Connection,
    principal: Principal,
    staged_assertion_id: UUID,
    status_reason: str,
    applied_node_ids: tuple[UUID, ...],
    applied_edge_ids: tuple[UUID, ...],
) -> AppliedAssertionRecord:
    row = cast(
        Mapping[str, Any] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
            UPDATE pending_assertions
            SET status = 'applied',
                status_reason = $2,
                applied_at = now(),
                applied_node_ids = $3::uuid[],
                applied_edge_ids = $4::uuid[],
                applied_tag_ids = '{}'::uuid[],
                resolution_attempts = resolution_attempts + 1,
                last_attempt_at = now()
            WHERE id = $1
              AND actor_principal_id = $5
              AND status IN ('resolved', 'applied')
            RETURNING
                id,
                status::text AS status,
                applied_node_ids,
                applied_edge_ids,
                applied_tag_ids
            """,
            staged_assertion_id,
            status_reason,
            list(applied_node_ids),
            list(applied_edge_ids),
            principal.id,
        ),
    )
    if row is None:
        raise AssertionCanonicalizationError("mutation_assertion_not_applicable")
    return AppliedAssertionRecord(
        id=cast(UUID, row["id"]),
        status=PendingAssertionStatus(cast(str, row["status"])),
        applied_node_ids=tuple(cast(list[UUID], row["applied_node_ids"])),
        applied_edge_ids=tuple(cast(list[UUID], row["applied_edge_ids"])),
        applied_tag_ids=tuple(cast(list[UUID], row["applied_tag_ids"])),
    )


async def _apply_resolved_node_tag_assertion(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    assertion: AssertionCanonicalInput,
    staged_assertion_id: UUID,
) -> NodeTagSingletonResolution | None:
    tag_request = await _node_tag_request_from_claim(
        connection=connection,
        claim=assertion.claim,
        confidence=assertion.confidence,
    )
    if tag_request is None:
        if _claim_kind(assertion.claim) == "node_tag":
            raise AssertionCanonicalizationError("node_tag_unsupported_shape")
        return None

    candidate = await _load_staged_assertion_candidate(
        connection=connection,
        principal=principal,
        staged_assertion_id=staged_assertion_id,
    )
    repository = AsyncNodeTagRepository(connection)
    resolution = await resolve_node_tag_singleton_supersession(
        principal=principal,
        connection=connection,
        repository=repository,
        candidate=candidate,
        tag_request=tag_request,
        context=TagDefinitionServiceContext(
            principal_id=principal.id,
            tenant_id=candidate.tenant_id,
        ),
    )
    if resolution.result.outcome in {
        AssertionResolutionOutcome.ACCEPTED,
        AssertionResolutionOutcome.CORROBORATED,
        AssertionResolutionOutcome.SUPERSEDED,
    }:
        await _mark_pending_assertion_tag_applied(
            connection=connection,
            principal=principal,
            result=resolution.result,
        )
    return resolution


async def _node_tag_request_from_claim(
    *,
    connection: asyncpg.Connection,
    claim: Mapping[str, Any],
    confidence: float | None,
) -> NodeTagApplyRequest | None:
    if _claim_kind(claim) != "node_tag":
        return None
    target = claim.get("target")
    if not isinstance(target, Mapping):
        return None
    target = cast(Mapping[str, object], target)
    node_id_value = target.get("node_id")
    definition_id_value = target.get("tag_definition_id")
    if not isinstance(node_id_value, str) or not isinstance(definition_id_value, str):
        return None
    try:
        node_id = UUID(node_id_value)
        definition_id = UUID(definition_id_value)
    except ValueError as exc:
        raise AssertionCanonicalizationError("node_tag_target_invalid") from exc

    repository = AsyncNodeTagRepository(connection)
    source = await repository.load_source_node(node_id)
    if source is None:
        raise AssertionCanonicalizationError("node_tag_source_not_visible")
    start, end = _node_tag_span(claim=claim, source=source)
    return NodeTagApplyRequest(
        node_id=node_id,
        tag_definition_id=definition_id,
        value=_node_tag_value_from_claim(claim),
        span_offset_start=start,
        span_offset_end=end,
        expected_content_digest=compute_node_tag_content_digest(
            source.body_nfc_hash,
            start=start,
            end=end,
        ),
        text_quote_selector=TextQuoteSelector(
            prefix=source.body_nfc[:start],
            exact=source.body_nfc[start:end],
            suffix=source.body_nfc[end:],
        ),
        currency=_optional_string(claim.get("currency")),
        confidence=_confidence_decimal(confidence),
        attrs={"asserted_via": "graph_assert"},
    )


def _node_tag_span(
    *,
    claim: Mapping[str, Any],
    source: NodeTagSourceSnapshot,
) -> tuple[int, int]:
    span = claim.get("span")
    if span is None:
        target = claim.get("target")
        if isinstance(target, Mapping):
            target = cast(Mapping[str, object], target)
            span = target.get("span")
    if isinstance(span, Mapping):
        span = cast(Mapping[str, object], span)
        start = span.get("start", span.get("offset_start"))
        end = span.get("end", span.get("offset_end"))
        if isinstance(start, int) and isinstance(end, int):
            return start, end
    if not source.body_nfc:
        raise AssertionCanonicalizationError("node_tag_source_empty")
    return 0, len(source.body_nfc)


def _node_tag_value_from_claim(
    claim: Mapping[str, Any],
) -> NodeTagValue:
    if "value_reference_node_id" in claim and isinstance(claim["value_reference_node_id"], str):
        try:
            return NodeTagValue(value_reference_node_id=UUID(claim["value_reference_node_id"]))
        except ValueError as exc:
            raise AssertionCanonicalizationError("node_tag_value_invalid") from exc
    value = claim.get("value")
    if isinstance(value, bool):
        return NodeTagValue(value_boolean=value)
    if isinstance(value, str):
        return NodeTagValue(value_text=value)
    if isinstance(value, int | float):
        try:
            return NodeTagValue(value_number=Decimal(str(value)))
        except InvalidOperation as exc:
            raise AssertionCanonicalizationError("node_tag_value_invalid") from exc
    raise AssertionCanonicalizationError("node_tag_value_invalid")


def _optional_string(value: object) -> str | None:
    return value if isinstance(value, str) and value.strip() else None


def _confidence_decimal(confidence: float | None) -> Decimal:
    if confidence is None:
        return Decimal("1")
    return Decimal(str(confidence))


async def _load_staged_assertion_candidate(
    *,
    connection: asyncpg.Connection,
    principal: Principal,
    staged_assertion_id: UUID,
) -> StagedAssertionCandidate:
    row = await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
        """
        SELECT
            id,
            status::text,
            actor_principal_id,
            tenant_id,
            context_of_validity,
            claim_kind,
            source_kind,
            COALESCE(
              NULLIF(source ->> 'identifier', ''),
              NULLIF(source ->> 'external_id', ''),
              NULLIF(source ->> 'locator', '')
            ) AS source_identifier,
            COALESCE(
              NULLIF(source ->> 'model_provider', ''),
              NULLIF(source #>> '{metadata,model_provider}', '')
            ) AS model_provider,
            COALESCE(
              NULLIF(source ->> 'model_family', ''),
              NULLIF(source #>> '{metadata,model_family}', '')
            ) AS model_family,
            COALESCE(
              NULLIF(source ->> 'model_name', ''),
              NULLIF(source #>> '{metadata,model_name}', '')
            ) AS model_name,
            confidence::float AS confidence,
            normalized_fact_digest,
            idempotency_key,
            digest_version,
            created_at
        FROM pending_assertions
        WHERE id = $1
          AND actor_principal_id = $2
          AND status IN ('staged', 'resolved', 'applied')
        FOR UPDATE
        """,
        staged_assertion_id,
        principal.id,
    )
    if row is None:
        raise AssertionCanonicalizationError("staged_assertion_not_visible")
    payload: dict[str, Any] = dict(cast(Mapping[str, Any], row))
    context = payload.get("context_of_validity")
    if isinstance(context, str):
        loaded = json.loads(context)
        if not isinstance(loaded, dict):
            raise AssertionCanonicalizationError("staged_assertion_context_invalid")
        payload["context_of_validity"] = loaded
    return StagedAssertionCandidate.model_validate(payload)


async def _mark_pending_assertion_tag_applied(
    *,
    connection: asyncpg.Connection,
    principal: Principal,
    result: AssertionResolutionVisibleResult,
) -> None:
    if result.canonical_row_id is None:
        raise AssertionCanonicalizationError("node_tag_resolution_missing_canonical_row")
    await connection.execute(  # pyright: ignore[reportUnknownMemberType]
        """
        UPDATE pending_assertions
        SET status = 'applied',
            status_reason = $2,
            conflict_result = $3::jsonb,
            applied_at = now(),
            applied_node_ids = '{}'::uuid[],
            applied_edge_ids = '{}'::uuid[],
            applied_tag_ids = ARRAY[$4::uuid],
            resolution_attempts = resolution_attempts + 1,
            last_attempt_at = now()
        WHERE id = $1
          AND actor_principal_id = $5
          AND status IN ('resolved', 'staged')
        """,
        result.assertion_id,
        result.reason.value,
        json.dumps(result.model_dump(mode="json"), sort_keys=True, separators=(",", ":")),
        result.canonical_row_id,
        principal.id,
    )


def _pending_status_from_resolution(
    result: AssertionResolutionVisibleResult,
) -> PendingAssertionStatus:
    if result.outcome in {
        AssertionResolutionOutcome.ACCEPTED,
        AssertionResolutionOutcome.SUPERSEDED,
        AssertionResolutionOutcome.CORROBORATED,
    }:
        return PendingAssertionStatus.APPLIED
    if result.outcome is AssertionResolutionOutcome.DISAGREEMENT_QUEUED:
        return PendingAssertionStatus.DISAGREEMENT
    if result.outcome is AssertionResolutionOutcome.REJECTED:
        return PendingAssertionStatus.REJECTED
    return PendingAssertionStatus.RESOLVED


def _claim_kind(claim: Mapping[str, Any]) -> str | None:
    value = claim.get("kind") or claim.get("type")
    return value.strip() if isinstance(value, str) and value.strip() else None


def _outbox_context(context: Mapping[str, Any]) -> dict[str, Any]:
    normalized = dict(context)
    if normalized.get("valid_to") == "":
        normalized["valid_to"] = None
    if normalized.get("valid_from") == "":
        normalized["valid_from"] = None
    return normalized


__all__ = [
    "GraphAssertCommand",
    "GraphAssertCommandResult",
    "emit_graph_assert_audit",
    "execute_graph_assert_command",
]
