"""Shared Slice 4 write-contract primitives for ``POST /graph/assert``.

Wave 0 owns stable vocabulary only: public statuses, internal resolution
outcomes, source-kind registry posture, AP1 claim-size posture, and a
deterministic fact-family key helper. It intentionally does not create the
HTTP route, staging schema, audit schema, or conflict algorithm.

References: Slice 4 master plan "Shared artifacts & contracts"; §10.5,
§10.6, §10.7, §10.12, AP1, AP11, M5, M14.
"""

from __future__ import annotations

import json
import re
from collections.abc import Mapping, Sequence
from enum import StrEnum
from hashlib import sha256
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

DEFAULT_ASSERTION_CLAIM_MAX_BYTES = 16 * 1024
"""AP1 write-validation threshold for a single assertion claim body."""

REGISTERED_SOURCE_KINDS: frozenset[str] = frozenset(
    {
        "api",
        "cli",
        "agent",
        "ingest",
        "mcp-smoke",
        "office-smoke",
    }
)
"""Initial data/config source-kind registry for Slice 4."""

_SOURCE_KIND_PATTERN = re.compile(r"^[a-z][a-z0-9-]{0,62}$")


class GraphAssertPublicStatus(StrEnum):
    """Public statuses returned by ``POST /graph/assert`` in Slice 4."""

    STAGED = "staged"
    APPLIED = "applied"
    REJECTED = "rejected"
    DISAGREEMENT = "disagreement"


class AssertionResolutionOutcome(StrEnum):
    """Internal resolution outcomes produced by staging/conflict services."""

    ACCEPTED = "accepted"
    DUPLICATE = "duplicate"
    CORROBORATED = "corroborated"
    SUPERSEDED = "superseded"
    CONFLICT_CREATED = "conflict_created"
    DISAGREEMENT_QUEUED = "disagreement_queued"
    REJECTED = "rejected"
    RETRYABLE_CONFLICT = "retryable_conflict"


OUTCOME_PUBLIC_STATUS: dict[AssertionResolutionOutcome, GraphAssertPublicStatus] = {
    AssertionResolutionOutcome.ACCEPTED: GraphAssertPublicStatus.APPLIED,
    AssertionResolutionOutcome.DUPLICATE: GraphAssertPublicStatus.STAGED,
    AssertionResolutionOutcome.CORROBORATED: GraphAssertPublicStatus.APPLIED,
    AssertionResolutionOutcome.SUPERSEDED: GraphAssertPublicStatus.APPLIED,
    AssertionResolutionOutcome.CONFLICT_CREATED: GraphAssertPublicStatus.DISAGREEMENT,
    AssertionResolutionOutcome.DISAGREEMENT_QUEUED: GraphAssertPublicStatus.DISAGREEMENT,
    AssertionResolutionOutcome.REJECTED: GraphAssertPublicStatus.REJECTED,
    AssertionResolutionOutcome.RETRYABLE_CONFLICT: GraphAssertPublicStatus.STAGED,
}
"""Endpoint mapping from internal outcomes to stable public statuses."""


class RegisteredSourceKind(BaseModel):
    """Resolved source-kind object passed to downstream assertion services."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    kind: str = Field(min_length=1, max_length=63)

    @field_validator("kind")
    @classmethod
    def _source_kind_syntax(cls, value: str) -> str:
        normalized = value.strip()
        if not _SOURCE_KIND_PATTERN.fullmatch(normalized):
            raise ValueError("source.kind must match ^[a-z][a-z0-9-]{0,62}$")
        return normalized


class UnknownSourceKindError(ValueError):
    """Raised when a syntactically valid source kind is not registered."""

    def __init__(self, source_kind: str) -> None:
        self.source_kind = source_kind
        super().__init__(f"unknown source.kind: {source_kind}")


def resolve_source_kind(source_kind: str) -> RegisteredSourceKind:
    """Validate and resolve a Slice 4 source kind before staging."""

    resolved = RegisteredSourceKind(kind=source_kind)
    if resolved.kind not in REGISTERED_SOURCE_KINDS:
        raise UnknownSourceKindError(resolved.kind)
    return resolved


type JsonValue = str | int | float | bool | None | Mapping[str, "JsonValue"] | Sequence["JsonValue"]


def claim_size_bytes(claim: object) -> int:
    """Return deterministic AP1 byte size for text or structured claims."""

    if isinstance(claim, str):
        return len(claim.encode("utf-8"))
    if isinstance(claim, Mapping):
        canonical = json.dumps(
            claim,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
        )
        return len(canonical.encode("utf-8"))
    raise TypeError("claim must be a string or JSON object")


def validate_claim_size(
    claim: object,
    *,
    max_bytes: int = DEFAULT_ASSERTION_CLAIM_MAX_BYTES,
) -> None:
    """Enforce the AP1 claim-size threshold before staging."""

    if claim_size_bytes(claim) > max_bytes:
        raise ValueError("claim_too_large")


class FactFamilyInput(BaseModel):
    """Normalized fields that identify the fact family under dispute.

    Raw claim text is intentionally absent so distinct provenance does not
    collapse merely because bodies are textually similar.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    tenant_id: str = Field(min_length=1)
    context: dict[str, Any]
    target: dict[str, Any]
    fact: dict[str, Any]
    version: int = 1


def fact_family_key(fact: FactFamilyInput) -> str:
    """Return a deterministic fact-family key for conflict resolution."""

    canonical = json.dumps(
        fact.model_dump(mode="json"),
        sort_keys=True,
        separators=(",", ":"),
    )
    digest = sha256(canonical.encode("utf-8")).hexdigest()
    return f"fact-family:v{fact.version}:{digest}"
