"""Shared update-pattern validation contract for Slice 3 graph writes.

Wave A owns the pure contract and resolver only. Pattern-specific field,
edge, revision, and DB guards are wired by later update-pattern waves.

References: §1.1, §1.2, §1.4, §1.5, §1.15, §6.1, §6.3, AP5, M16.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from datetime import datetime
from enum import StrEnum
from typing import Any, NoReturn, Protocol, runtime_checkable
from uuid import UUID

import asyncpg
from pydantic import BaseModel, ConfigDict, Field

from .edges import EdgeRelationshipType
from .type_classifier import (
    KindDiscriminator,
    OntologyTypeCandidate,
    OntologyTypeLifecycle,
    UpdatePattern,
)


class PatternOperation(StrEnum):
    """Legal-operation vocabulary shared by graph write handlers."""

    CREATE = "create"
    UPDATE_BODY = "update_body"
    UPDATE_IDENTITY = "update_identity"
    REVISE_CLAIM = "revise_claim"
    ARCHIVE = "archive"
    RECLASSIFY = "reclassify"
    CONFIRM_DRAFT = "confirm_draft"


class GraphPatternValidationReason(StrEnum):
    """Stable low-cardinality reason codes for update-pattern denials."""

    ONTOLOGY_TYPE_NOT_FOUND = "ontology_type_not_found"
    OPERATION_NOT_ALLOWED_FOR_PATTERN = "operation_not_allowed_for_pattern"
    PREVIOUS_STATUS_REQUIRED = "previous_status_required"
    GROUNDED_BY_REQUIRED = "grounded_by_required"
    FALSIFIED_BY_REQUIRED = "falsified_by_required"
    REVISION_CYCLE = "revision_cycle"
    SUPERSESSION_CONFLICT = "supersession_conflict"
    TYPE_PATTERN_MISMATCH = "type_pattern_mismatch"
    RESERVED_TYPE = "reserved_type"
    DEPRECATED_TYPE = "deprecated_type"
    INVALID_ONTOLOGY_TYPE = "invalid_ontology_type"


class PatternValidationDecision(StrEnum):
    """Low-cardinality validation event decisions."""

    ALLOW = "allow"
    DENY = "deny"
    CONFLICT = "conflict"


class GraphPatternValidationError(ValueError):
    """Domain validation error with stable caller-safe details."""

    error_code = "pattern_validation_failed"

    def __init__(
        self,
        reason_code: GraphPatternValidationReason,
        message: str,
        *,
        pattern: UpdatePattern | None = None,
        operation: PatternOperation | None = None,
        allowed_operations: Sequence[PatternOperation] = (),
        required_edge_type: EdgeRelationshipType | None = None,
        ontology_type_id: UUID | None = None,
        ontology_version_id: UUID | None = None,
        type_name: str | None = None,
    ) -> None:
        self.reason_code = reason_code
        self.pattern = pattern
        self.operation = operation
        self.allowed_operations = tuple(allowed_operations)
        self.required_edge_type = required_edge_type
        self.ontology_type_id = ontology_type_id
        self.ontology_version_id = ontology_version_id
        self.type_name = type_name
        super().__init__(f"{reason_code.value}: {message}")

    def to_safe_dict(self) -> dict[str, object]:
        """Return the API/audit-safe error payload shape."""

        payload: dict[str, object] = {
            "error_code": self.error_code,
            "reason_code": self.reason_code.value,
        }
        if self.pattern is not None:
            payload["pattern"] = self.pattern
        if self.operation is not None:
            payload["operation"] = self.operation.value
        if self.allowed_operations:
            payload["allowed_operations"] = [
                operation.value for operation in self.allowed_operations
            ]
        if self.required_edge_type is not None:
            payload["required_edge_type"] = self.required_edge_type.value
        if self.ontology_type_id is not None:
            payload["ontology_type_id"] = str(self.ontology_type_id)
        if self.ontology_version_id is not None:
            payload["ontology_version_id"] = str(self.ontology_version_id)
        if self.type_name is not None:
            payload["type"] = self.type_name
        return payload


_DB_GUARD_REASONS: Mapping[
    str,
    tuple[GraphPatternValidationReason, PatternOperation | None, EdgeRelationshipType | None],
] = {
    "nodes_reject_pattern_crossing_type_update": (
        GraphPatternValidationReason.TYPE_PATTERN_MISMATCH,
        PatternOperation.RECLASSIFY,
        None,
    ),
    "nodes_reject_pattern1_body_update": (
        GraphPatternValidationReason.OPERATION_NOT_ALLOWED_FOR_PATTERN,
        PatternOperation.UPDATE_BODY,
        None,
    ),
    "nodes_reject_pattern4_confirmed_body_update": (
        GraphPatternValidationReason.OPERATION_NOT_ALLOWED_FOR_PATTERN,
        PatternOperation.UPDATE_BODY,
        None,
    ),
    "nodes_reject_supersession_cycle": (
        GraphPatternValidationReason.REVISION_CYCLE,
        PatternOperation.REVISE_CLAIM,
        None,
    ),
    "nodes_pattern4_grounded_by_required": (
        GraphPatternValidationReason.GROUNDED_BY_REQUIRED,
        PatternOperation.CREATE,
        EdgeRelationshipType.GROUNDED_BY,
    ),
    "nodes_pattern4_falsified_by_required": (
        GraphPatternValidationReason.FALSIFIED_BY_REQUIRED,
        PatternOperation.CREATE,
        EdgeRelationshipType.FALSIFIED_BY,
    ),
}


ALLOWED_PATTERN_OPERATIONS: Mapping[UpdatePattern, frozenset[PatternOperation]] = {
    1: frozenset({PatternOperation.CREATE, PatternOperation.ARCHIVE}),
    2: frozenset(
        {
            PatternOperation.CREATE,
            PatternOperation.UPDATE_BODY,
            PatternOperation.ARCHIVE,
        }
    ),
    3: frozenset(
        {
            PatternOperation.CREATE,
            PatternOperation.UPDATE_IDENTITY,
            PatternOperation.ARCHIVE,
        }
    ),
    4: frozenset(
        {
            PatternOperation.CREATE,
            PatternOperation.REVISE_CLAIM,
            PatternOperation.ARCHIVE,
            PatternOperation.CONFIRM_DRAFT,
        }
    ),
}


def allowed_operations_for_pattern(pattern: UpdatePattern) -> tuple[PatternOperation, ...]:
    """Return the stable legal-operation set for ``pattern``."""

    return tuple(sorted(ALLOWED_PATTERN_OPERATIONS[pattern], key=lambda operation: operation.value))


def validate_pattern_operation(
    *,
    pattern: UpdatePattern,
    operation: PatternOperation,
    ontology_type_id: UUID | None = None,
    ontology_version_id: UUID | None = None,
    type_name: str | None = None,
) -> None:
    """Raise if ``operation`` is not legal for ``pattern``.

    Pattern-specific obligations such as ``previous_status`` and required
    argumentation edges are intentionally outside Wave A.
    """

    allowed_operations = allowed_operations_for_pattern(pattern)
    if operation in allowed_operations:
        return
    raise GraphPatternValidationError(
        GraphPatternValidationReason.OPERATION_NOT_ALLOWED_FOR_PATTERN,
        f"operation {operation.value!r} is not allowed for update pattern {pattern}",
        pattern=pattern,
        operation=operation,
        allowed_operations=allowed_operations,
        ontology_type_id=ontology_type_id,
        ontology_version_id=ontology_version_id,
        type_name=type_name,
    )


class PatternResolutionRequest(BaseModel):
    """Server-side request for resolving type-derived update behavior."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    tenant_id: UUID
    ontology_version_id: UUID
    type_name: str
    cached_ontology_type_id: UUID | None = None
    cached_kind_discriminator: KindDiscriminator | None = None
    cached_update_pattern: UpdatePattern | None = None


class ResolvedGraphPattern(BaseModel):
    """Resolved OntologyType contract used by pattern validators."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    ontology_type_id: UUID
    ontology_version_id: UUID
    type_name: str
    kind_discriminator: KindDiscriminator
    update_pattern: UpdatePattern

    @classmethod
    def from_candidate(cls, candidate: OntologyTypeCandidate) -> ResolvedGraphPattern:
        return cls(
            ontology_type_id=candidate.id,
            ontology_version_id=candidate.ontology_version_id,
            type_name=candidate.name,
            kind_discriminator=candidate.kind_discriminator,
            update_pattern=candidate.update_pattern,
        )


class Pattern2VersionSnapshot(BaseModel):
    """Storage-owned version-history snapshot contract for Pattern 2 updates.

    The Node storage feature owns the table/write. This shape is the guard
    passed to update-pattern validation after the snapshot has been staged in
    the same transaction as the body update.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    node_id: UUID
    previous_body_hash: str = Field(min_length=1)
    snapshot_ref: UUID | str


class Pattern2BodyUpdateGuard(BaseModel):
    """Application-level precondition for Pattern 2 body updates."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    target_node_id: UUID
    version_snapshot: Pattern2VersionSnapshot | None
    requested_update_pattern: UpdatePattern | None = None
    requested_ontology_type_id: UUID | None = None


class Pattern3SingletonGuard(BaseModel):
    """Semantic hook for tag-owned active singleton consistency checks."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    is_singleton: bool
    active_value_count_after_update: int = Field(ge=0)


class Pattern3HubIdentityUpdateGuard(BaseModel):
    """Application-level preconditions for Pattern 3 hub identity updates."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    target_node_id: UUID
    updated_node_id: UUID
    document_body_update_requested: bool = False
    version_history_requested: bool = False
    singleton_guard: Pattern3SingletonGuard | None = None


class Pattern4ArgumentEdge(BaseModel):
    """Visible staged outgoing edge summary for Pattern 4 validation."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    source_node_id: UUID
    target_node_id: UUID
    relationship_type: EdgeRelationshipType
    edge_archived_at: datetime | None = None
    target_archived_at: datetime | None = None
    target_superseded_by_node_id: UUID | None = None

    @property
    def satisfies_current_argument(self) -> bool:
        """Return true only for active edges to active target Nodes."""

        return (
            self.edge_archived_at is None
            and self.target_archived_at is None
            and self.target_superseded_by_node_id is None
        )


class Pattern4ArgumentationGuard(BaseModel):
    """Application-level precondition for load-bearing decision writes."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    target_node_id: UUID
    staged_outgoing_edges: tuple[Pattern4ArgumentEdge, ...] = ()


class Pattern4RevisionChainGuard(BaseModel):
    """Application-level revision-chain preconditions for Pattern 4 writes."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    revision_node_id: UUID
    revised_node_id: UUID
    revision_path_node_ids: tuple[UUID, ...] = ()
    active_current_head_count_after_revision: int = Field(ge=0)


@runtime_checkable
class PatternOntologyTypeRepository(Protocol):
    """Repository surface for resolving OntologyType by asserted context."""

    async def find_by_name(
        self,
        *,
        tenant_id: UUID,
        ontology_version_id: UUID,
        requested_type_name: str,
    ) -> Sequence[OntologyTypeCandidate]:
        """Return type candidates for the asserted ontology version and name."""
        ...


class GraphPatternResolver:
    """Resolve type-derived update behavior and fail closed on cache drift."""

    def __init__(self, repository: PatternOntologyTypeRepository) -> None:
        self._repository = repository

    async def resolve(self, request: PatternResolutionRequest) -> ResolvedGraphPattern:
        normalized_type_name = request.type_name.strip()
        if normalized_type_name == "":
            raise GraphPatternValidationError(
                GraphPatternValidationReason.ONTOLOGY_TYPE_NOT_FOUND,
                "type_name is required to resolve update pattern",
                ontology_version_id=request.ontology_version_id,
            )
        candidates = tuple(
            await self._repository.find_by_name(
                tenant_id=request.tenant_id,
                ontology_version_id=request.ontology_version_id,
                requested_type_name=normalized_type_name,
            )
        )
        if not candidates:
            raise GraphPatternValidationError(
                GraphPatternValidationReason.ONTOLOGY_TYPE_NOT_FOUND,
                "ontology type did not resolve in asserted ontology version",
                ontology_version_id=request.ontology_version_id,
                type_name=normalized_type_name,
            )

        candidate_ids = tuple(candidate.id for candidate in candidates)
        if any(candidate.reserved for candidate in candidates):
            raise GraphPatternValidationError(
                GraphPatternValidationReason.RESERVED_TYPE,
                "reserved ontology type cannot be used for canonical graph writes",
                ontology_version_id=request.ontology_version_id,
                type_name=normalized_type_name,
            )

        active_candidates = tuple(candidate for candidate in candidates if candidate.is_active)
        if not active_candidates:
            if any(
                candidate.lifecycle is OntologyTypeLifecycle.DEPRECATED for candidate in candidates
            ):
                reason = GraphPatternValidationReason.DEPRECATED_TYPE
                message = "deprecated ontology type cannot be used for canonical graph writes"
            else:
                reason = GraphPatternValidationReason.ONTOLOGY_TYPE_NOT_FOUND
                message = "ontology type is not active in asserted ontology version"
            raise GraphPatternValidationError(
                reason,
                message,
                ontology_version_id=request.ontology_version_id,
                type_name=normalized_type_name,
            )

        if len(active_candidates) > 1:
            raise GraphPatternValidationError(
                GraphPatternValidationReason.INVALID_ONTOLOGY_TYPE,
                f"ontology type resolved ambiguously: {candidate_ids}",
                ontology_version_id=request.ontology_version_id,
                type_name=normalized_type_name,
            )

        candidate = next(iter(active_candidates))
        resolved = ResolvedGraphPattern.from_candidate(candidate)
        _validate_cached_pattern(request=request, resolved=resolved)
        return resolved


def _validate_cached_pattern(
    *,
    request: PatternResolutionRequest,
    resolved: ResolvedGraphPattern,
) -> None:
    mismatches: list[str] = []
    if (
        request.cached_ontology_type_id is not None
        and request.cached_ontology_type_id != resolved.ontology_type_id
    ):
        mismatches.append("ontology_type_id")
    if (
        request.cached_kind_discriminator is not None
        and request.cached_kind_discriminator != resolved.kind_discriminator
    ):
        mismatches.append("kind_discriminator")
    if (
        request.cached_update_pattern is not None
        and request.cached_update_pattern != resolved.update_pattern
    ):
        mismatches.append("update_pattern")
    if not mismatches:
        return

    raise GraphPatternValidationError(
        GraphPatternValidationReason.TYPE_PATTERN_MISMATCH,
        f"cached node type contract disagrees with resolved OntologyType: {mismatches}",
        pattern=resolved.update_pattern,
        ontology_type_id=resolved.ontology_type_id,
        ontology_version_id=resolved.ontology_version_id,
        type_name=resolved.type_name,
    )


def validate_state_transition_create(
    *,
    resolved: ResolvedGraphPattern,
    metadata: Mapping[str, Any] | None,
) -> None:
    """Validate Slice 3 Pattern 1 ``state-transition`` create obligations.

    Slice 3 pins ``previous_status`` to ``nodes.metadata.previous_status``.
    Missing, JSON null, and empty/whitespace strings are all invalid prior
    states and reject with the master-plan reason code.
    """

    validate_pattern_operation(
        pattern=resolved.update_pattern,
        operation=PatternOperation.CREATE,
        ontology_type_id=resolved.ontology_type_id,
        ontology_version_id=resolved.ontology_version_id,
        type_name=resolved.type_name,
    )
    if resolved.update_pattern != 1:
        _raise_operation_not_allowed(
            resolved=resolved,
            operation=PatternOperation.CREATE,
            message="state-transition create validation requires update pattern 1",
        )
    if metadata is None:
        _raise_previous_status_required(resolved)
    previous_status = metadata.get("previous_status")
    if previous_status is None:
        _raise_previous_status_required(resolved)
    if isinstance(previous_status, str) and previous_status.strip() == "":
        _raise_previous_status_required(resolved)


def validate_pattern2_body_update(
    *,
    resolved: ResolvedGraphPattern,
    guard: Pattern2BodyUpdateGuard,
) -> None:
    """Validate Pattern 2 body updates against the version-history contract.

    This helper deliberately does not write version history. It requires the
    storage-owned snapshot proof that the caller staged the old body in the same
    transaction before updating the current body.
    """

    validate_pattern_operation(
        pattern=resolved.update_pattern,
        operation=PatternOperation.UPDATE_BODY,
        ontology_type_id=resolved.ontology_type_id,
        ontology_version_id=resolved.ontology_version_id,
        type_name=resolved.type_name,
    )
    if resolved.update_pattern != 2:
        _raise_operation_not_allowed(
            resolved=resolved,
            operation=PatternOperation.UPDATE_BODY,
            message="Pattern 2 body update requires update pattern 2",
        )
    if (
        guard.requested_update_pattern is not None
        and guard.requested_update_pattern != resolved.update_pattern
    ) or (
        guard.requested_ontology_type_id is not None
        and guard.requested_ontology_type_id != resolved.ontology_type_id
    ):
        raise GraphPatternValidationError(
            GraphPatternValidationReason.TYPE_PATTERN_MISMATCH,
            "Pattern 2 body update cannot change the node type contract",
            pattern=resolved.update_pattern,
            operation=PatternOperation.UPDATE_BODY,
            ontology_type_id=resolved.ontology_type_id,
            ontology_version_id=resolved.ontology_version_id,
            type_name=resolved.type_name,
        )
    if guard.version_snapshot is None:
        _raise_operation_not_allowed(
            resolved=resolved,
            operation=PatternOperation.UPDATE_BODY,
            message="Pattern 2 body update requires an atomic version-history snapshot",
        )
    if guard.version_snapshot.node_id != guard.target_node_id:
        raise GraphPatternValidationError(
            GraphPatternValidationReason.SUPERSESSION_CONFLICT,
            "Pattern 2 version-history snapshot must belong to the updated Node",
            pattern=resolved.update_pattern,
            operation=PatternOperation.UPDATE_BODY,
            ontology_type_id=resolved.ontology_type_id,
            ontology_version_id=resolved.ontology_version_id,
            type_name=resolved.type_name,
        )


def validate_pattern3_hub_identity_update(
    *,
    resolved: ResolvedGraphPattern,
    guard: Pattern3HubIdentityUpdateGuard,
) -> None:
    """Validate Pattern 3 in-place hub identity update semantics.

    Tag storage owns active-row queries and singleton indexes. This helper
    exposes the semantic hook the tag service can feed after applying its own
    storage contract.
    """

    validate_pattern_operation(
        pattern=resolved.update_pattern,
        operation=PatternOperation.UPDATE_IDENTITY,
        ontology_type_id=resolved.ontology_type_id,
        ontology_version_id=resolved.ontology_version_id,
        type_name=resolved.type_name,
    )
    if resolved.update_pattern != 3 or resolved.kind_discriminator != "hub":
        _raise_operation_not_allowed(
            resolved=resolved,
            operation=PatternOperation.UPDATE_IDENTITY,
            message="Pattern 3 identity update requires a hub node with update pattern 3",
        )
    if guard.document_body_update_requested:
        _raise_operation_not_allowed(
            resolved=resolved,
            operation=PatternOperation.UPDATE_IDENTITY,
            message="Pattern 3 hub identity update cannot mutate document body content",
        )
    if guard.version_history_requested:
        _raise_operation_not_allowed(
            resolved=resolved,
            operation=PatternOperation.UPDATE_IDENTITY,
            message="Pattern 3 hub identity update must not write version history",
        )
    if guard.updated_node_id != guard.target_node_id:
        raise GraphPatternValidationError(
            GraphPatternValidationReason.SUPERSESSION_CONFLICT,
            "Pattern 3 hub identity update must remain on the same Node id",
            pattern=resolved.update_pattern,
            operation=PatternOperation.UPDATE_IDENTITY,
            ontology_type_id=resolved.ontology_type_id,
            ontology_version_id=resolved.ontology_version_id,
            type_name=resolved.type_name,
        )
    singleton_guard = guard.singleton_guard
    if (
        singleton_guard is not None
        and singleton_guard.is_singleton
        and singleton_guard.active_value_count_after_update > 1
    ):
        raise GraphPatternValidationError(
            GraphPatternValidationReason.SUPERSESSION_CONFLICT,
            "Pattern 3 singleton identity update would leave multiple active values",
            pattern=resolved.update_pattern,
            operation=PatternOperation.UPDATE_IDENTITY,
            ontology_type_id=resolved.ontology_type_id,
            ontology_version_id=resolved.ontology_version_id,
            type_name=resolved.type_name,
        )


def validate_pattern4_argumentation(
    *,
    resolved: ResolvedGraphPattern,
    operation: PatternOperation,
    guard: Pattern4ArgumentationGuard,
) -> None:
    """Validate Slice 3 Pattern 4 load-bearing decision obligations.

    Confirmed and draft ``decision`` writes both require at least one active
    outgoing ``grounded-by`` edge and one active outgoing ``falsified-by`` edge
    to active target Nodes. Archived edges, archived targets, superseded targets,
    and edges with the wrong source do not satisfy the current-claim contract.
    """

    validate_pattern_operation(
        pattern=resolved.update_pattern,
        operation=operation,
        ontology_type_id=resolved.ontology_type_id,
        ontology_version_id=resolved.ontology_version_id,
        type_name=resolved.type_name,
    )
    if resolved.update_pattern != 4 or resolved.kind_discriminator != "document":
        _raise_operation_not_allowed(
            resolved=resolved,
            operation=operation,
            message="Pattern 4 argumentation validation requires a document node "
            "with update pattern 4",
        )

    active_relationship_types = {
        edge.relationship_type
        for edge in guard.staged_outgoing_edges
        if edge.source_node_id == guard.target_node_id and edge.satisfies_current_argument
    }
    if EdgeRelationshipType.GROUNDED_BY not in active_relationship_types:
        _raise_required_edge(
            resolved=resolved,
            operation=operation,
            required_edge_type=EdgeRelationshipType.GROUNDED_BY,
            reason_code=GraphPatternValidationReason.GROUNDED_BY_REQUIRED,
            message="Pattern 4 decision requires an active grounded-by edge",
        )
    if EdgeRelationshipType.FALSIFIED_BY not in active_relationship_types:
        _raise_required_edge(
            resolved=resolved,
            operation=operation,
            required_edge_type=EdgeRelationshipType.FALSIFIED_BY,
            reason_code=GraphPatternValidationReason.FALSIFIED_BY_REQUIRED,
            message="Pattern 4 decision requires an active falsified-by edge",
        )


def validate_normal_type_update(
    *,
    current: ResolvedGraphPattern,
    requested: ResolvedGraphPattern,
) -> None:
    """Reject ordinary type updates that would reclassify across patterns."""

    if current.update_pattern == requested.update_pattern:
        return
    raise GraphPatternValidationError(
        GraphPatternValidationReason.TYPE_PATTERN_MISMATCH,
        "normal type updates cannot cross update patterns; use reclassification",
        pattern=current.update_pattern,
        operation=PatternOperation.RECLASSIFY,
        ontology_type_id=current.ontology_type_id,
        ontology_version_id=current.ontology_version_id,
        type_name=current.type_name,
    )


def validate_pattern4_revision_chain(
    *,
    resolved: ResolvedGraphPattern,
    guard: Pattern4RevisionChainGuard,
) -> None:
    """Validate Pattern 4 revision-chain safety before committing a revision."""

    validate_pattern_operation(
        pattern=resolved.update_pattern,
        operation=PatternOperation.REVISE_CLAIM,
        ontology_type_id=resolved.ontology_type_id,
        ontology_version_id=resolved.ontology_version_id,
        type_name=resolved.type_name,
    )
    if resolved.update_pattern != 4 or resolved.kind_discriminator != "document":
        _raise_operation_not_allowed(
            resolved=resolved,
            operation=PatternOperation.REVISE_CLAIM,
            message="Pattern 4 revision validation requires a document node with update pattern 4",
        )
    if (
        guard.revision_node_id == guard.revised_node_id
        or guard.revision_node_id in guard.revision_path_node_ids
    ):
        raise GraphPatternValidationError(
            GraphPatternValidationReason.REVISION_CYCLE,
            "Pattern 4 revision chain cannot revise itself or create a cycle",
            pattern=resolved.update_pattern,
            operation=PatternOperation.REVISE_CLAIM,
            ontology_type_id=resolved.ontology_type_id,
            ontology_version_id=resolved.ontology_version_id,
            type_name=resolved.type_name,
        )
    if guard.active_current_head_count_after_revision != 1:
        raise GraphPatternValidationError(
            GraphPatternValidationReason.SUPERSESSION_CONFLICT,
            "Pattern 4 revision chain must leave exactly one active current head",
            pattern=resolved.update_pattern,
            operation=PatternOperation.REVISE_CLAIM,
            ontology_type_id=resolved.ontology_type_id,
            ontology_version_id=resolved.ontology_version_id,
            type_name=resolved.type_name,
        )


def pattern_validation_event_fields(
    *,
    decision: PatternValidationDecision,
    actor_principal_id: UUID,
    context_of_validity: Mapping[str, Any],
    pattern: UpdatePattern,
    operation: PatternOperation,
    reason_code: GraphPatternValidationReason | None = None,
    node_id: UUID | None = None,
    type_name: str | None = None,
) -> dict[str, Any]:
    """Return content-free structured fields for validation audit logs."""

    event_context = {
        key: context_of_validity.get(key)
        for key in (
            "tenant",
            "classification",
            "vertical",
            "ontology_version",
            "valid_from",
            "valid_to",
        )
        if key in context_of_validity
    }
    fields: dict[str, Any] = {
        "decision": decision.value,
        "actor_principal_id": str(actor_principal_id),
        "context": event_context,
        "pattern": pattern,
        "operation": operation.value,
    }
    if reason_code is not None:
        fields["reason_code"] = reason_code.value
    if node_id is not None:
        fields["node_id"] = str(node_id)
    if type_name is not None:
        fields["type"] = type_name
    return fields


def map_pattern_storage_error(exc: BaseException) -> GraphPatternValidationError:
    """Map DB guard failures into the shared graph pattern error shape."""

    constraint_name = getattr(exc, "constraint_name", None)
    reason, operation, required_edge_type = _DB_GUARD_REASONS.get(
        str(constraint_name),
        (
            GraphPatternValidationReason.OPERATION_NOT_ALLOWED_FOR_PATTERN,
            None,
            None,
        ),
    )
    is_known_guard = constraint_name in _DB_GUARD_REASONS
    if not isinstance(exc, asyncpg.CheckViolationError) and not is_known_guard:
        return GraphPatternValidationError(
            GraphPatternValidationReason.OPERATION_NOT_ALLOWED_FOR_PATTERN,
            "graph pattern storage guard rejected the write",
        )
    return GraphPatternValidationError(
        reason,
        "graph pattern storage guard rejected the write",
        operation=operation,
        required_edge_type=required_edge_type,
    )


def _raise_previous_status_required(resolved: ResolvedGraphPattern) -> NoReturn:
    raise GraphPatternValidationError(
        GraphPatternValidationReason.PREVIOUS_STATUS_REQUIRED,
        "state-transition requires metadata.previous_status",
        pattern=resolved.update_pattern,
        operation=PatternOperation.CREATE,
        ontology_type_id=resolved.ontology_type_id,
        ontology_version_id=resolved.ontology_version_id,
        type_name=resolved.type_name,
    )


def _raise_required_edge(
    *,
    resolved: ResolvedGraphPattern,
    operation: PatternOperation,
    required_edge_type: EdgeRelationshipType,
    reason_code: GraphPatternValidationReason,
    message: str,
) -> NoReturn:
    raise GraphPatternValidationError(
        reason_code,
        message,
        pattern=resolved.update_pattern,
        operation=operation,
        required_edge_type=required_edge_type,
        ontology_type_id=resolved.ontology_type_id,
        ontology_version_id=resolved.ontology_version_id,
        type_name=resolved.type_name,
    )


def _raise_operation_not_allowed(
    *,
    resolved: ResolvedGraphPattern,
    operation: PatternOperation,
    message: str,
) -> NoReturn:
    raise GraphPatternValidationError(
        GraphPatternValidationReason.OPERATION_NOT_ALLOWED_FOR_PATTERN,
        message,
        pattern=resolved.update_pattern,
        operation=operation,
        allowed_operations=allowed_operations_for_pattern(resolved.update_pattern),
        ontology_type_id=resolved.ontology_type_id,
        ontology_version_id=resolved.ontology_version_id,
        type_name=resolved.type_name,
    )
