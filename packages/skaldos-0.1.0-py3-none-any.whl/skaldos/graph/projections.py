"""Read-side projection helpers for ``slice-frontend-api-gaps`` (PR0).

Per ``docs/slices/slice-frontend-api-gaps/03-technical-implementation.md``
§ "Module layout" → "``services/api/skaldos/graph/projections.py``":
this module owns the pure projection logic the three new read routes
(``GET /me``, ``GET /me/tenants``, ``GET /graph/nodes/{node_id}``)
delegate into. Pure functions / pure helpers --- no FastAPI imports
beyond the ``asyncpg.Connection`` type hint, no async I/O beyond the
queries the route handler hands in.

Why ``graph/`` rather than ``db/`` or its own package
------------------------------------------------------

The brainstorm explicitly leaves the location flexible (``05-task-list.md``
§ T5: "Or ``services/api/skaldos/db/identity_projection.py`` if ``graph/``
is the wrong home --- pick based on neighboring code. The impl agent
should record the choice in the PR description."). The pick:

- The node-detail projection (``NodeDetailProjectionService``) reads
  ``nodes`` / ``node_tags`` / ``edges`` --- all graph-substrate
  tables; it belongs next to the other graph-substrate read services
  (``traversal.py``, ``node_snapshot.py``, ``search.py``,
  ``context_assembly.py``).
- The identity projection (``IdentityProjectionService``) is small
  and shares the read-route error envelope contract with the graph
  projections; rather than spread two near-trivial projection
  services across two packages (``db/`` and ``graph/``), both live
  in ``graph/projections.py`` and share the same import surface
  for the route handlers. The module's docstring + the per-class
  doc make the read-side / non-graph nature of ``IdentityProjectionService``
  explicit.

If a future slice adds a third projection family that has nothing to
do with graph data (e.g. a billing projection), splitting out a
``services/api/skaldos/projections/`` package is a one-line rename;
the route handlers import the service classes by name, not by module
path.

Fingerprint contract
--------------------

The Python ``email_fingerprint`` helper here computes byte-for-byte
the same value as the SQL trigger
``app.tg_principals_maintain_email_fingerprint`` in migration
``20260615_frontend_api_gaps_principal_email_and_tenant_archived.py``.
The unit test
``tests/unit/api/test_projections.py::test_email_fingerprint_matches_sql_trigger``
pins this parity. A future PR that wires the resolver to populate
``principals.email_normalized`` from ``claims.email`` calls
:func:`normalize_email` to produce the canonical form; the SQL trigger
then hashes it. Both sides must agree on the canonical form, which
this module owns.

References
----------

- ``docs/slices/slice-frontend-api-gaps/02-edge-cases.md`` E3, E5, E6,
  E9, E10, E11, E12, E19.
- ``docs/slices/slice-frontend-api-gaps/03-technical-implementation.md``
  § "Happy-path walkthrough", § "Fault lines" F1, F4, F5, F6.
- §3.1 (plural-tenant principal); §13.6 / §20.2 (PII discipline);
  §15.4 / §15.7 (classification + RLS); MP10 (humans + agents same
  shape); AP5 (no debug bypass).
"""

from __future__ import annotations

import hashlib
import unicodedata
from collections.abc import Mapping, Sequence
from typing import Any, Literal, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict, Field, field_validator

from skaldos.graph.edges import ClassificationLevel
from skaldos.middleware import Principal

__all__ = [
    "EMAIL_FINGERPRINT_HEX_LEN",
    "GraphNodeDetailRelated",
    "GraphNodeDetailResponse",
    "GraphNodeDetailTag",
    "IdentityProjectionService",
    "MAX_RELATED",
    "MAX_TAGS",
    "MAX_TENANT_DISPLAY_LABEL_LEN",
    "MeResponse",
    "MeTenantsItem",
    "MeTenantsResponse",
    "NodeDetailNotFoundError",
    "NodeDetailProjectionService",
    "NodeDetailQueryError",
    "active_tenant_id_from",
    "compute_email_fingerprint",
    "display_label_for_principal",
    "display_label_for_tenant",
    "normalize_email",
]


# ---------------------------------------------------------------------------
# Constants. Module-level so unit tests, the route handlers, and the SQL
# query bodies can reference one source of truth.
# ---------------------------------------------------------------------------

EMAIL_FINGERPRINT_HEX_LEN = 16
"""Hex-character length of the email fingerprint --- the leading 16
characters of the SHA-256 digest. Mirrors the SQL trigger's
``substring(... FROM 1 FOR 16)``. 16 hex chars = 64 bits of entropy
which is enough for a per-principal correlation id while staying
short for log lines."""

MAX_TAGS = 50
"""Truncation cap for ``GraphNodeDetailResponse.tags``. Caller sees at
most 50 tags; the ``truncated_tags`` flag signals overflow. Sorted
by ``tag_definition_slug`` ascending so the cap is deterministic
(E19). The cap is generous --- most nodes carry single-digit tag
counts; the cap exists to bound the wire payload on hub nodes."""

MAX_RELATED = 20
"""Truncation cap for ``GraphNodeDetailResponse.related``. Caller sees
at most 20 visible edges; the ``truncated_related`` flag signals
overflow. Sorted by ``(weight DESC, target_node_id ASC)`` for
determinism --- weight is nullable, NULL weights sort last. Same
"bounded fan-out" principle as the traversal endpoint's limit (§10)."""

MAX_TENANT_DISPLAY_LABEL_LEN = 120
"""Clamp on ``MeTenantsItem.display_label`` length (E12). Operator-supplied
tenant names with HTML/markup are passed through raw (escaping is the
client's job per content type), but length is bounded so a malicious
operator cannot inflate the wire payload by spamming the display name.
Control characters (C0 / C1) are also stripped."""


# ---------------------------------------------------------------------------
# Email normalization + fingerprint helpers.
#
# Both helpers must agree with the SQL trigger
# ``app.tg_principals_maintain_email_fingerprint`` defined in
# ``migrations/versions/20260615_frontend_api_gaps_principal_email_and_tenant_archived.py``.
# The parity is what makes the schema seam usable from either side:
# when a future resolver wire-up PR persists ``email_normalized`` to
# ``principals``, the Python helper produces the canonical form that
# the SQL trigger then hashes; both sides land identical fingerprints.
#
# The trigger today only computes ``email_fingerprint = sha256(
# email_normalized)[:16]``; it does NOT normalize email itself. The
# Python helper :func:`normalize_email` is therefore the source of
# truth for what "canonical email" means, and the SQL trigger trusts
# its caller to have already normalized.
# ---------------------------------------------------------------------------


def normalize_email(email: str | None) -> str | None:
    """Canonical normalization for email addresses (F1).

    Rules (deliberately conservative --- we err on the side of "two
    different inputs map to two different normalized forms" rather
    than "two equivalent inputs map to one normalized form", because
    a false-positive collision is a privacy bug and a false-negative
    duplicate is at worst an operator inconvenience):

    1. ``None`` → ``None``. Agents have no email; pre-resolver-wireup
       human rows also have none.
    2. NFC-normalize the input string so visually-identical sequences
       map to the same byte representation (composed vs. decomposed
       form of accented characters). NFC is the W3C-recommended form
       for protocol values and the default on most modern systems.
    3. Strip ASCII whitespace from both ends.
    4. Lowercase. RFC 5321 says the local-part is case-sensitive in
       principle, but every major mail provider treats it as
       case-insensitive; lowercasing here matches the resolver's
       email-equality check semantics in
       ``services/api/skaldos/middleware/resolver.py``'s
       email-mismatch detection (which compares verbatim today but
       should compare normalized).
    5. After all the above, an empty string maps to ``None`` ---
       a whitespace-only or empty input is indistinguishable from
       "no email" for fingerprint purposes (E5 fallback logic relies
       on this --- an empty-string fingerprint would skip the email
       branch).

    Returns the canonical form, or ``None`` for inputs that are
    semantically empty.

    The function does NOT validate that the input is a syntactically
    valid email (no ``@`` check, no IDN A-label conversion, no MX
    lookup). The substrate accepts any string that Auth0 sent as
    ``claims.email``; a malformed email is a downstream signaling
    issue, not a normalization issue. Equivalence under this function
    is what matters for the fingerprint, not RFC 5322 conformance.
    """
    if email is None:
        return None
    # NFC normalization first; then strip; then lowercase.
    nfc = unicodedata.normalize("NFC", email)
    stripped = nfc.strip().lower()
    if not stripped:
        return None
    return stripped


def compute_email_fingerprint(email_normalized: str | None) -> str | None:
    """SHA-256 hex digest of an already-normalized email, truncated to 16 chars.

    Mirrors the SQL trigger in
    ``migrations/versions/20260615_frontend_api_gaps_principal_email_and_tenant_archived.py``
    byte-for-byte. The trigger reads ``email_normalized`` from the row
    and produces ``substring(encode(digest(_, 'sha256'), 'hex') FROM 1
    FOR 16)``; this function does the same in Python.

    The input is expected to already be in canonical form
    (:func:`normalize_email`); passing a raw email here will produce
    a fingerprint that does not match the substrate's stored value.
    Callers that have a raw email should compose:

        compute_email_fingerprint(normalize_email(raw_email))

    Returns ``None`` for a ``None`` input. The PII-discipline contract
    (§13.6) is that ``email_fingerprint`` is never an empty string --- the
    caller must collapse "no email" to ``None`` before calling this.
    The Pydantic model :class:`MeResponse` enforces the same invariant
    via its ``str | None`` type annotation; a stray empty string is
    caught by the unit test
    ``test_me_response_email_fingerprint_empty_string_normalized_to_none``.
    """
    if email_normalized is None:
        return None
    digest = hashlib.sha256(email_normalized.encode("utf-8")).hexdigest()
    return digest[:EMAIL_FINGERPRINT_HEX_LEN]


# ---------------------------------------------------------------------------
# Display-label fallback ladders.
#
# Both ``display_label_for_principal`` and ``display_label_for_tenant``
# are total functions on their inputs --- they never raise and never
# return an empty string. The fallback ladder is server-side so the
# frontend never has to decide "is this a real name or a placeholder?"
# (F4). The Pydantic model field annotations on :class:`MeResponse`
# and :class:`MeTenantsItem` pin the ``str`` (non-Optional) type.
# ---------------------------------------------------------------------------


def display_label_for_principal(
    *,
    principal_id: UUID,
    display_name: str | None,
    email_fingerprint: str | None,
) -> str:
    """Compute the deterministic display label for a principal (E5).

    Ladder, in order:

    1. ``display_name`` if non-None and non-empty after strip --- the
       canonical user-facing label.
    2. Else if ``email_fingerprint`` is non-None: ``email_fingerprint``
       prefix (the first 8 chars) + ``"..."``. This is an opaque
       correlation handle the frontend can render in a "you're signed
       in as <handle>" affordance without leaking the underlying
       email address (§13.6).
    3. Else: ``"principal-" + <short id>`` where ``<short id>`` is
       the first 8 hex chars of the principal's UUID. Guaranteed to
       fall through to this branch for an agent with no display_name
       and no email --- the substrate always has a UUID id.

    Per F4: server-side, deterministic, total --- no branch returns
    an empty string. The JWT ``name`` / ``nickname`` claims are never
    used (the resolver doesn't surface them and per §20.2 the wire
    shape doesn't expose claim values).
    """
    if display_name is not None and display_name.strip():
        return display_name.strip()
    if email_fingerprint is not None:
        # Show only the first 8 chars (half the fingerprint) + a
        # truncation indicator. The full 16-char fingerprint is
        # surfaced separately as ``MeResponse.email_fingerprint``;
        # the label is for *display*, the fingerprint is for
        # *correlation*.
        return f"{email_fingerprint[:8]}..."
    return f"principal-{principal_id.hex[:8]}"


def display_label_for_tenant(
    *,
    tenant_id: UUID,
    display_name: str | None,
) -> str:
    """Compute the deterministic display label for a tenant (E10).

    Ladder:

    1. ``display_name`` after normalization (strip C0/C1 controls,
       clamp to :data:`MAX_TENANT_DISPLAY_LABEL_LEN`) if non-empty
       after normalization. Operator-supplied HTML / markup passes
       through verbatim --- escaping is the client's job per content
       type (§20.2; the contract is "this is plain text", not
       "this is safe to inject into innerHTML"). The clamp is a
       structural defense against wire-payload inflation; the
       control-character strip removes BiDi overrides and similar
       formatting bombs that could break the frontend's layout.
    2. Else: ``"tenant-" + <short id>`` where ``<short id>`` is the
       first 8 hex chars of the tenant's UUID. The substrate
       schema declares ``display_name text NOT NULL`` today
       (migration ``20260504_tenants.py``), so this branch is
       defensive --- a future migration that relaxes the NOT NULL
       finds the fallback ready.
    """
    sanitized = _sanitize_display_text(display_name)
    if sanitized:
        return sanitized
    return f"tenant-{tenant_id.hex[:8]}"


def _sanitize_display_text(value: str | None) -> str:
    """Strip C0/C1 control characters and clamp length (E12).

    Returns the empty string for a ``None`` input; the caller decides
    whether the empty result triggers the fallback ladder. C0 = U+0000
    --- U+001F, C1 = U+007F --- U+009F. The HTML/markup-allowed-in-text
    contract (§20.2) means we don't escape ``<`` / ``&`` etc., but
    control characters are never legitimate in a user-facing label
    and have historical use in injection attacks.
    """
    if value is None:
        return ""
    # Drop control characters in the C0 and C1 ranges. Keep the BMP
    # printable space, including emoji and accented characters.
    stripped = "".join(ch for ch in value if not _is_control_char(ch))
    # Bound the length. Some operators may seed a tenant with an
    # entire paragraph as the display name; the frontend's UI is sized
    # for a short label, and the wire shape shouldn't carry a kilobyte
    # of text.
    clamped = stripped.strip()[:MAX_TENANT_DISPLAY_LABEL_LEN]
    return clamped


def _is_control_char(ch: str) -> bool:
    """Return True if ``ch`` is a C0 or C1 control character."""
    cp = ord(ch)
    return cp < 0x20 or 0x7F <= cp <= 0x9F


# ---------------------------------------------------------------------------
# Active-tenant hint ladder (E9).
#
# F6: ``active_tenant_id`` is a *hint*, not authority. The Slice C
# future server-side active-tenant feature will replace this with a
# persisted choice; today the hint comes from the principal's primary
# tenant (when visible + non-archived) or the first sorted item of the
# visible-non-archived list.
# ---------------------------------------------------------------------------


def active_tenant_id_from(
    *,
    primary_tenant_id: UUID | None,
    visible_non_archived: Sequence[tuple[UUID, str]],
) -> UUID | None:
    """Pick the canonical "default" tenant for the principal (E9).

    Inputs:

    - ``primary_tenant_id``: the principal's ``primary_tenant_id``
      column value (may be ``None`` for newly-invited users / agents
      without delegation context; see §3.1).
    - ``visible_non_archived``: the ordered list of
      ``(tenant_id, display_label)`` tuples the principal can read,
      with archived tenants already excluded. Caller is responsible
      for the ordering (typically sorted by display_label ASC for
      determinism).

    Ladder:

    1. If ``primary_tenant_id`` is non-None AND appears in the
       visible-non-archived list --- return it. The principal's home
       tenant is the canonical default.
    2. Else if the list is non-empty --- return the first entry's id.
       The caller's ordering becomes the user's first-paint default.
    3. Else --- return ``None``. The principal has no readable
       tenants (no memberships yet, or all memberships archived).
       The frontend renders the "no tenants" empty state.

    The hint is computed every request --- no caching, no per-request
    sticky state. The frontend persists its own choice in a
    non-authoritative way; the server is canonical only on first
    paint. F6.
    """
    visible_ids = [tenant_id for tenant_id, _label in visible_non_archived]
    if primary_tenant_id is not None and primary_tenant_id in visible_ids:
        return primary_tenant_id
    if visible_ids:
        return visible_ids[0]
    return None


# ---------------------------------------------------------------------------
# /me + /me/tenants response models.
#
# Frozen + extra="forbid" per the SkaldOS substrate convention
# (mirrors :class:`~skaldos.api.whoami.WhoamiResponse`). Field-level
# docstrings document the wire contract; the brainstorm's S1/S3 are
# the canonical source for the field set.
# ---------------------------------------------------------------------------


class MeResponse(BaseModel):
    """Wire shape for ``GET /me`` (slice-frontend-api-gaps S1, S2).

    A production-safe projection of the principal's identity. Unlike
    :class:`~skaldos.api.whoami.WhoamiResponse` (the Slice 1 chokepoint
    gate target, gated off in production), this shape is registered in
    *all* environments including production --- it is the canonical
    "who am I" surface for the Phase 2 frontend.

    The shape deliberately does NOT expose ``verified_claims``,
    ``auth0_sub``, ``disabled_at``, or any raw email --- the wire is a
    projection of identity, not a memory dump (§13.6, §20.2).

    Per MP10: the shape does not branch on ``kind``. Agent callers
    get the same projection with ``kind="agent"`` and
    ``email_fingerprint`` typically ``None`` (since M2M tokens
    carry no email; E3).
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    principal_id: UUID
    """Substrate-internal surrogate PK of the resolved principal.
    Stable across renames; never reused. Mirrors
    :attr:`Principal.id`. UUIDv7 in production (PC8 / PC16) so the
    PK carries an embedded creation timestamp."""

    kind: Literal["human", "agent"]
    """MP10 discriminator. ``"human"`` for Authorization-Code-flow
    tokens with ``org_id``; ``"agent"`` for M2M Client Credentials
    tokens. Mirrors :attr:`Principal.kind`."""

    primary_tenant_id: UUID | None
    """The principal's "home tenant" per §3.1. Nullable for
    principals not yet docked into a primary tenant (e.g. freshly
    invited user whose membership row hasn't landed; an agent whose
    tenancy comes from delegation context). Mirrors
    :attr:`Principal.primary_tenant_id`."""

    visible_tenant_ids: list[UUID]
    """The principal's visible-tenant set as committed to the
    request's GUC. Empty list is the legal "no memberships yet"
    state (E4). Sorted in the same order
    :attr:`Principal.visible_tenant_ids` carries.

    Note: this field reflects the *request-scope* visibility (what
    the principal's GUC says); ``GET /me/tenants`` reflects the
    *data-visible* tenants (what RLS returns at query time). The
    two may differ briefly when a membership is added/revoked
    mid-request (E11 in the brainstorm). The brief inconsistency
    is correct: ``/me`` describes the principal's request scope;
    ``/me/tenants`` describes the data the principal can actually
    see."""

    email_fingerprint: str | None = Field(default=None, min_length=1)
    """Deterministic 16-hex-char projection of the principal's email
    address, computed by the substrate trigger
    ``app.tg_principals_maintain_email_fingerprint``. ``None`` when
    the substrate has no recorded email (agents always; humans
    whose first-auth has not yet populated
    ``principals.email_normalized``).

    The frontend uses the fingerprint as a stable correlation handle
    --- two browser sessions for the same user surface the same
    fingerprint, but the raw email never leaves the substrate
    (§13.6).

    ``min_length=1`` enforces F5: an empty string is never legal
    here. The Pydantic validator below also coerces ``""`` to
    ``None`` defensively in case a future writer ships an empty
    string (the unit test pins this behaviour)."""

    @field_validator("email_fingerprint", mode="before")
    @classmethod
    def _coerce_empty_email_fingerprint_to_none(cls, value: object) -> object:
        """Coerce empty string to ``None`` (F5).

        Pydantic's default coercion does not silently flip ``""`` to
        ``None`` for ``str | None``; instead it would surface as a
        ``min_length`` validation failure. We pre-coerce here so a
        stray empty-string upstream (e.g. a future query that emits
        ``""`` instead of NULL) deterministically becomes ``None``
        rather than crashing the response.
        """
        if isinstance(value, str) and value == "":
            return None
        return value

    display_label: str = Field(min_length=1)
    """Human-readable label for the principal. Computed by
    :func:`display_label_for_principal` server-side, deterministic,
    total --- the frontend renders this as-is and never needs to
    fall back. ``min_length=1`` is the structural pin that the
    fallback ladder never returns an empty string."""


class MeTenantsItem(BaseModel):
    """One entry in ``GET /me/tenants`` items list (slice-frontend-api-gaps S3)."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    tenant_id: UUID
    """Tenant's substrate-internal id. Stable across renames; never
    reused. Matches one entry in :attr:`Principal.visible_tenant_ids`
    *and* a non-archived row in the ``tenants`` table."""

    display_label: str = Field(min_length=1)
    """Computed by :func:`display_label_for_tenant`. ``min_length=1``
    pins that the fallback ladder never returns an empty string.
    Operator-supplied display names pass through *raw* (no HTML
    escaping --- that's the client's job per content type), but C0
    / C1 control characters are stripped and length is clamped to
    :data:`MAX_TENANT_DISPLAY_LABEL_LEN` (E12)."""


class MeTenantsResponse(BaseModel):
    """Wire shape for ``GET /me/tenants`` (slice-frontend-api-gaps S3).

    Lists the tenants the calling principal can actually read (RLS
    enforces this; the handler trusts what the query returns).
    Excludes archived tenants. The list is sorted by ``display_label``
    ascending for deterministic rendering.

    The ``active_tenant_id`` field is a *hint* (F6): the frontend
    may persist its own choice in a non-authoritative way. A future
    Slice C feature will define server-side active-tenant
    persistence (out of scope for PR0).
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    items: list[MeTenantsItem]
    """The visible, non-archived tenants. May be empty (the
    "no tenants" state --- E4 for empty visible set, E9 for all
    archived). The handler does not 404 on empty; the frontend
    renders an empty state."""

    active_tenant_id: UUID | None
    """First-paint default tenant for the frontend. Computed by
    :func:`active_tenant_id_from`. ``None`` only when ``items`` is
    empty (no readable, non-archived tenants). The hint is computed
    every request; clients that want a sticky choice persist their
    own selection client-side."""


# ---------------------------------------------------------------------------
# /graph/nodes/{id} response models.
# ---------------------------------------------------------------------------


class GraphNodeDetailTag(BaseModel):
    """One tag chip in the node-detail response (E19)."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    """The ``node_tags`` row id; stable across the tag's lifetime."""

    tag_definition_id: UUID
    """The ``tag_definitions`` row id that types this tag."""

    tag_definition_slug: str
    """Operator-facing slug (lowercase-hyphenated; pinned by the
    tag-definitions feature). Stable; useful for deterministic
    ordering."""

    value_text: str | None
    """The string projection of the tag's value. ``None`` for
    non-string-valued tags (numeric / boolean / reference); a
    future projection may surface those as typed fields if Slice A
    needs them. For Slice A's chip rendering, ``value_text`` is
    sufficient."""

    classification: ClassificationLevel
    """The tag's classification level. The query has already filtered
    on the caller's clearance (E20); the field is included so the
    frontend can render a classification chip."""


class GraphNodeDetailRelated(BaseModel):
    """One related-neighbor entry in the node-detail response (E16)."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    edge_id: UUID
    """The ``edges`` row id for the connecting edge. Stable across
    the edge's lifetime (until the edge is archived)."""

    target_node_id: UUID
    """The neighbor node's id. The query has already filtered to
    visible nodes (E16); the frontend can request that node's detail
    via ``GET /graph/nodes/{target_node_id}`` without further
    authorization (the chokepoint will run again on the next request
    and confirm visibility)."""

    relationship_type: str
    """The edge's relationship type (e.g. ``"relates-to"``). The
    edge-relationship-types lookup table pins the vocabulary."""

    weight: float | None
    """The edge's weight in [0, 1] when set; ``None`` when the
    relationship has no weight (the schema permits nullable weight).
    The query orders ``related`` by ``weight DESC NULLS LAST,
    target_node_id ASC`` for determinism."""

    classification: ClassificationLevel
    """The edge's classification level. The query has already filtered
    on the caller's clearance (E16); the field lets the frontend
    render a classification chip on the edge."""


class GraphNodeDetailResponse(BaseModel):
    """Wire shape for ``GET /graph/nodes/{node_id}`` (slice-frontend-api-gaps S4)."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    """The node's substrate id, mirroring the request path parameter."""

    tenant_id: UUID
    """The node's tenant. Derived from the substrate row, not the
    request path; the chokepoint loader has already confirmed the
    principal's visibility to this tenant."""

    type_id: UUID
    """The node's ontology type id. The frontend can join against a
    type-detail surface to render the type's display name (out of
    scope for this projection)."""

    summary: str | None
    """The node's summary line (the substrate-canonical short
    description). May be ``None`` for nodes whose body is the
    canonical surface."""

    classification: ClassificationLevel
    """The node's classification level. The query has already filtered
    on the caller's clearance (the loader is the chokepoint); the
    field lets the frontend render a classification chip."""

    version: int = Field(ge=1)
    """The node body's version-at-read. The frontend can detect
    concurrent updates on subsequent calls by comparing this value
    to a later read; no retry / locking is performed (E17)."""

    tags: list[GraphNodeDetailTag]
    """Visible tags on this node, capped at :data:`MAX_TAGS`, sorted
    by ``tag_definition_slug`` ascending for determinism. Includes
    only tags whose classification is within the caller's clearance
    (E20)."""

    related: list[GraphNodeDetailRelated]
    """Visible related-edge neighbors, capped at :data:`MAX_RELATED`,
    sorted by ``(weight DESC NULLS LAST, target_node_id ASC)`` for
    determinism. Excludes neighbors the caller cannot see (other
    tenant, higher classification, lens-excluded; E16)."""

    truncated_tags: bool
    """``True`` if the underlying query saw more than :data:`MAX_TAGS`
    tags before truncation; the frontend renders a "+N more"
    affordance. Computed deterministically from the query's overscan
    --- the query reads ``MAX_TAGS + 1`` rows and the boolean is set
    when the result exceeds the cap."""

    truncated_related: bool
    """``True`` if the underlying query saw more than :data:`MAX_RELATED`
    related edges before truncation. Same overscan pattern as
    ``truncated_tags``."""

    source_snapshot_handle: str | None
    """Opaque handle the frontend uses to request the node's source
    snapshot via ``POST /graph/source-snapshot``. ``None`` when the
    caller can see the node summary but not its raw source (E18 ---
    e.g. an upstream document the caller can see in summary but
    not in raw form). The frontend renders the absence as "source
    snapshot not available".

    PR0 does not actually issue a snapshot fetch --- the handle is
    the node's id stringified (the snapshot endpoint takes the
    node id directly). A future PR can swap to a signed handle if
    needed; the wire field stays the same.
    """


# ---------------------------------------------------------------------------
# IdentityProjectionService --- pure orchestration over the connection.
#
# The service is a class for symmetry with the graph services
# (``TraversalService``, ``NodeSourceSnapshotService``). The methods
# take a connection (the route handler hands in the request-bound
# connection per F3) and a principal; they do one query each and
# return the wire model. Stateless --- a single instance can be
# constructed at module load if a caller prefers.
# ---------------------------------------------------------------------------


class IdentityProjectionService:
    """Read-side projection helpers for ``/me`` and ``/me/tenants``."""

    async def build_me_response(
        self,
        *,
        connection: asyncpg.Connection,
        principal: Principal,
    ) -> MeResponse:
        """Project the request-scope principal into a :class:`MeResponse`.

        One round-trip against ``principals`` to read the row's
        ``display_name`` and ``email_fingerprint`` (the chokepoint
        already has these via :attr:`Principal.display_name`, but
        the fingerprint is a column added by the PR0 migration that
        the Slice 1 Principal model does not yet carry). Reading
        from the row keeps the projection symmetric with the
        ``MeTenantsResponse`` projection, which also reads from the
        DB.

        F3: the query runs on the request's GUC-bound connection so
        RLS sees the right principal context. The chokepoint's
        ``principals_self_row`` policy ensures the principal can
        always SELECT their own row.

        Returns a :class:`MeResponse` with all six fields populated.
        Raises asyncpg errors verbatim; the route handler wraps them
        into the read-route error envelope.
        """
        row = cast(
            Mapping[str, Any] | None,
            await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                """
                SELECT
                  display_name,
                  email_fingerprint
                FROM principals
                WHERE id = $1
                """,
                principal.id,
            ),
        )
        # The RLS policy guarantees the principal can read their own
        # row; an empty result here is a substrate-integrity bug
        # (the GUC says we're principal X, but the row for X is
        # invisible to us). We fall back to the chokepoint-carried
        # display_name in that case --- the projection is total even
        # under unexpected DB state.
        display_name = (
            str(row["display_name"])
            if row is not None and row["display_name"] is not None
            else principal.display_name
        )
        email_fingerprint = (
            str(row["email_fingerprint"])
            if row is not None and row["email_fingerprint"] is not None
            else None
        )
        return MeResponse(
            principal_id=principal.id,
            kind=principal.kind,
            primary_tenant_id=principal.primary_tenant_id,
            visible_tenant_ids=list(principal.visible_tenant_ids),
            email_fingerprint=email_fingerprint,
            display_label=display_label_for_principal(
                principal_id=principal.id,
                display_name=display_name,
                email_fingerprint=email_fingerprint,
            ),
        )

    async def build_me_tenants_response(
        self,
        *,
        connection: asyncpg.Connection,
        principal: Principal,
    ) -> MeTenantsResponse:
        """Project the principal's visible non-archived tenants.

        One round-trip against ``tenants`` with the visible-tenant
        predicate. The RLS policy on ``tenants`` already filters to
        the visible set; the explicit ``id = ANY($1)`` is defense-in-
        depth (§3.6 application-layer filter alongside RLS) and lets
        the planner use the partial-tenants policy index.

        Excludes archived tenants (``archived_at IS NULL``) per E9.
        Sorted by ``display_name`` ASC for deterministic ordering.

        Returns a :class:`MeTenantsResponse` with the items list and
        the active-tenant hint. The handler does not raise on empty
        --- the empty-items case is a legal "no readable tenants"
        state (E4 / E9 corner).
        """
        rows = cast(
            Sequence[Mapping[str, Any]],
            await connection.fetch(  # pyright: ignore[reportUnknownMemberType]
                """
                SELECT id, display_name
                FROM tenants
                WHERE id = ANY($1::uuid[])
                  AND archived_at IS NULL
                ORDER BY display_name ASC, id ASC
                """,
                list(principal.visible_tenant_ids),
            ),
        )
        items: list[MeTenantsItem] = []
        for row in rows:
            tenant_id = cast(UUID, row["id"])
            display_label = display_label_for_tenant(
                tenant_id=tenant_id,
                display_name=cast(str | None, row["display_name"]),
            )
            items.append(MeTenantsItem(tenant_id=tenant_id, display_label=display_label))
        active = active_tenant_id_from(
            primary_tenant_id=principal.primary_tenant_id,
            visible_non_archived=[(item.tenant_id, item.display_label) for item in items],
        )
        return MeTenantsResponse(items=items, active_tenant_id=active)


# ---------------------------------------------------------------------------
# NodeDetailProjectionService --- the /graph/nodes/{id} projection.
#
# One composite query reads the node row + its top-N visible tags +
# its top-M visible related edges. The query carries the visibility
# predicates inline (defense-in-depth; RLS would also filter, but
# the explicit predicates keep the query intent grep-visible).
# ---------------------------------------------------------------------------


class NodeDetailNotFoundError(LookupError):
    """The requested node is absent, archived, superseded, cross-tenant,
    or over-clearance --- the wire response is a 404 envelope (E13)."""


class NodeDetailQueryError(RuntimeError):
    """Unexpected storage error while reading the node detail."""


# The composite SQL. Three CTEs:
#   1. ``node`` --- read the node row by id, filtering for visibility
#      via ``app.principal_context_contains`` (the same predicate the
#      RLS policy on ``nodes`` carries). Limits to one row.
#   2. ``tags`` --- read up to MAX_TAGS + 1 visible tags for this node.
#      The +1 lets the projection set ``truncated_tags`` deterministically.
#      Visibility: the same context predicate the ``node_tags`` RLS
#      policy uses.
#   3. ``related`` --- read up to MAX_RELATED + 1 visible edges where
#      this node is either source or target. The edges' policies are
#      visibility (tenant + classification + endpoint visibility); the
#      query mirrors that with explicit filtering for self-documentation.
#
# The top-level SELECT returns the node row plus the two arrays
# (asyncpg surfaces them as Python lists) via subqueries; aggregating
# in a subquery keeps the result a single row (one fetchrow call) and
# avoids a JOIN that would multiply rows.
_NODE_DETAIL_SQL = """
WITH node AS (
  SELECT
    id,
    tenant_id,
    type_id,
    summary,
    classification,
    version
  FROM nodes
  WHERE id = $1
    AND archived_at IS NULL
    AND superseded_by_node_id IS NULL
    AND app.principal_context_contains(context_of_validity)
  LIMIT 1
),
visible_tags AS (
  SELECT
    nt.id,
    nt.tag_definition_id,
    td.name AS tag_definition_slug,
    nt.value_text,
    nt.classification
  FROM node_tags nt
  JOIN tag_definitions td ON td.id = nt.tag_definition_id
  WHERE nt.node_id = $1
    AND nt.superseded_by_tag_id IS NULL
    AND app.principal_context_contains(nt.context_of_validity)
  ORDER BY td.name ASC, nt.id ASC
  LIMIT $2
),
visible_related AS (
  SELECT
    e.id AS edge_id,
    CASE WHEN e.source_node_id = $1 THEN e.target_node_id ELSE e.source_node_id END
      AS target_node_id,
    e.relationship_type,
    e.weight,
    e.classification
  FROM edges e
  WHERE e.archived_at IS NULL
    AND (e.source_node_id = $1 OR e.target_node_id = $1)
  ORDER BY e.weight DESC NULLS LAST, e.id ASC
  LIMIT $3
)
SELECT
  n.id,
  n.tenant_id,
  n.type_id,
  n.summary,
  n.classification,
  n.version,
  COALESCE(
    (SELECT jsonb_agg(jsonb_build_object(
      'id', vt.id,
      'tag_definition_id', vt.tag_definition_id,
      'tag_definition_slug', vt.tag_definition_slug,
      'value_text', vt.value_text,
      'classification', vt.classification
    )) FROM visible_tags vt),
    '[]'::jsonb
  ) AS tags_json,
  COALESCE(
    (SELECT jsonb_agg(jsonb_build_object(
      'edge_id', vr.edge_id,
      'target_node_id', vr.target_node_id,
      'relationship_type', vr.relationship_type,
      'weight', vr.weight,
      'classification', vr.classification
    )) FROM visible_related vr),
    '[]'::jsonb
  ) AS related_json
FROM node n
"""


class NodeDetailProjectionService:
    """Single-round-trip projection assembly for ``GET /graph/nodes/{id}``.

    The service is intentionally principal-implicit: every query it runs
    is bound to the request's GUC-committed principal context via the
    connection it is handed. The route handler ensures the connection
    came from :func:`current_principal`'s yield (F3); the service trusts
    that contract and lets RLS do the visibility filtering. Passing the
    principal explicitly would be a foot-gun --- a future caller could
    pass a different principal and assume the SQL would honor it, but
    the GUCs are the only authority.
    """

    async def build(
        self,
        *,
        connection: asyncpg.Connection,
        node_id: UUID,
    ) -> GraphNodeDetailResponse:
        """Assemble the node-detail projection for ``node_id``.

        F2 / F3 / E13 / E15: the composite query runs on the GUC-bound
        connection. RLS predicates (``nodes_principal_context_visible``,
        ``node_tags_principal_context_visible``, the three edges
        SELECT policies) filter on the request's principal context;
        an invisible node returns zero rows and the service raises
        :class:`NodeDetailNotFoundError`. The handler maps that to a
        404 envelope --- existence is never leaked.

        The query reads ``MAX_TAGS + 1`` tags and ``MAX_RELATED + 1``
        related edges; the projection drops the overscan row and sets
        the ``truncated_*`` flags when the result exceeded the cap
        (E19).

        Raises:
            :class:`NodeDetailNotFoundError`: when the node is absent,
                archived, superseded, cross-tenant, or over-clearance.
                Handler → 404.
            :class:`NodeDetailQueryError`: when the asyncpg query
                raises (planner error, statement timeout, etc.).
                Handler → 500.
        """
        try:
            row = cast(
                Mapping[str, Any] | None,
                await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                    _NODE_DETAIL_SQL,
                    node_id,
                    MAX_TAGS + 1,
                    MAX_RELATED + 1,
                ),
            )
        except Exception as exc:
            raise NodeDetailQueryError("node_detail_query_failed") from exc
        if row is None:
            raise NodeDetailNotFoundError("not_found")

        tags_raw = _parse_json_array(row["tags_json"])
        related_raw = _parse_json_array(row["related_json"])

        truncated_tags = len(tags_raw) > MAX_TAGS
        truncated_related = len(related_raw) > MAX_RELATED
        tags = [_tag_from_row(t) for t in tags_raw[:MAX_TAGS]]
        related = [_related_from_row(r) for r in related_raw[:MAX_RELATED]]

        # E18: the source_snapshot_handle is the node id stringified.
        # The /graph/source-snapshot endpoint runs its own visibility
        # check; if the caller can read the node summary (which got
        # them here) but not the source, the snapshot endpoint will
        # return its own 404. The handle is therefore safe to surface
        # regardless of the snapshot's own visibility --- the frontend
        # calls /graph/source-snapshot which is the canonical access
        # check.
        #
        # Returning the handle unconditionally avoids an extra
        # visibility query on the read path; the cost is one extra
        # round-trip from the frontend when the snapshot is actually
        # opened. The brainstorm E18 says "source_snapshot_handle =
        # null on the response (not absent key)" when the caller
        # lacks permission --- a future enhancement that pre-checks
        # permission can flip this to None without a wire-shape
        # change. For PR0 the simpler "always surface the handle, let
        # the snapshot endpoint enforce" path is the choice; the
        # frontend renders the handle's absence (None) as "snapshot
        # unavailable" identically to a snapshot endpoint 404.
        source_snapshot_handle = str(node_id)

        return GraphNodeDetailResponse(
            id=cast(UUID, row["id"]),
            tenant_id=cast(UUID, row["tenant_id"]),
            type_id=cast(UUID, row["type_id"]),
            summary=cast(str | None, row["summary"]),
            classification=ClassificationLevel(str(row["classification"])),
            version=int(row["version"]),
            tags=tags,
            related=related,
            truncated_tags=truncated_tags,
            truncated_related=truncated_related,
            source_snapshot_handle=source_snapshot_handle,
        )


def _parse_json_array(value: object) -> list[Mapping[str, Any]]:
    """Coerce the asyncpg ``jsonb`` array column into a list of dicts."""
    import json

    if value is None:
        return []
    if isinstance(value, str):
        parsed: Any = json.loads(value)
    else:
        parsed = value
    if not isinstance(parsed, list):
        raise NodeDetailQueryError("node_detail_query_failed")
    out: list[Mapping[str, Any]] = []
    for item in cast(list[object], parsed):
        if not isinstance(item, Mapping):
            raise NodeDetailQueryError("node_detail_query_failed")
        out.append(cast(Mapping[str, Any], item))
    return out


def _tag_from_row(row: Mapping[str, Any]) -> GraphNodeDetailTag:
    return GraphNodeDetailTag(
        id=UUID(str(row["id"])),
        tag_definition_id=UUID(str(row["tag_definition_id"])),
        tag_definition_slug=str(row["tag_definition_slug"]),
        value_text=cast(str | None, row.get("value_text")),
        classification=ClassificationLevel(str(row["classification"])),
    )


def _related_from_row(row: Mapping[str, Any]) -> GraphNodeDetailRelated:
    # asyncpg returns ``numeric`` as ``decimal.Decimal``; coerce to float for
    # the wire shape. The substrate's weight range is [0, 1] with 5-digit
    # precision (``numeric(6,5)``); a float64 represents that range losslessly.
    raw_weight: Any = row.get("weight")
    weight: float | None = None if raw_weight is None else float(raw_weight)
    return GraphNodeDetailRelated(
        edge_id=UUID(str(row["edge_id"])),
        target_node_id=UUID(str(row["target_node_id"])),
        relationship_type=str(row["relationship_type"]),
        weight=weight,
        classification=ClassificationLevel(str(row["classification"])),
    )
