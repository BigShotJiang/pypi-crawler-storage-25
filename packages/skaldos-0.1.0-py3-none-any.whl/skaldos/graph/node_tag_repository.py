"""RLS-bound asyncpg repository for NodeTag application paths."""

from __future__ import annotations

import json
from collections.abc import Mapping
from datetime import datetime
from typing import Any, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]

from skaldos.graph.edges import ClassificationLevel
from skaldos.graph.node_tags import (
    NodeTagReferenceSnapshot,
    NodeTagRepository,
    NodeTagRow,
    NodeTagRowDraft,
    NodeTagSourceSnapshot,
)
from skaldos.graph.tag_definitions import TagDefinitionLifecycleState, TagValueType
from skaldos.graph.tag_definitions_service import (
    TagDefinitionRecord,
    TagDefinitionService,
    TagDefinitionServiceContext,
    TagDefinitionServiceResult,
)


def _json_object(value: object) -> dict[str, object]:  # pragma: no cover - adapter helper
    if isinstance(value, str):
        loaded = json.loads(value)
        if not isinstance(loaded, dict):
            raise ValueError("expected JSON object")
        return cast(dict[str, object], loaded)
    if isinstance(value, Mapping):
        return dict(cast(Mapping[str, object], value))
    raise TypeError("expected JSON object")


class AsyncTagDefinitionRepository:  # pragma: no cover - exercised by integration route tests
    """Minimal production repository surface needed by ``TagDefinitionService`` lookups."""

    def __init__(self, connection: asyncpg.Connection) -> None:
        self._connection = connection

    async def get_visible(
        self,
        *,
        context: TagDefinitionServiceContext,
        definition_id: UUID,
    ) -> TagDefinitionRecord | None:
        del context
        row = await self._connection.fetchrow(  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
            """
            SELECT
              id,
              tenant_id,
              name,
              name_canonical,
              value_type::text AS value_type,
              lifecycle_state::text AS lifecycle_state,
              requires_currency,
              enum_values,
              computed_depends_on,
              validation_rules,
              attrs,
              ontology_version_id,
              replaced_by_tag_definition_id,
              created_at,
              deprecated_at,
              retired_at
            FROM tag_definitions
            WHERE id = $1
              AND tenant_id = ANY ((SELECT app.principal_visible())::uuid[])
            """,
            definition_id,
        )
        if row is None:
            return None
        row = cast(Mapping[str, Any], row)
        return TagDefinitionRecord(
            id=row["id"],
            tenant_id=row["tenant_id"],
            name=row["name"],
            name_canonical=row["name_canonical"],
            value_type=TagValueType(row["value_type"]),
            lifecycle_state=TagDefinitionLifecycleState(row["lifecycle_state"]),
            requires_currency=row["requires_currency"],
            enum_values_canonical=(
                None if row["enum_values"] is None else tuple(row["enum_values"])
            ),
            computed_depends_on_canonical=(
                None if row["computed_depends_on"] is None else tuple(row["computed_depends_on"])
            ),
            validation_rules=_json_object(row["validation_rules"]),
            attrs=_json_object(row["attrs"]),
            ontology_version_id=row["ontology_version_id"],
            replaced_by_tag_definition_id=row["replaced_by_tag_definition_id"],
            created_at=row["created_at"],
            deprecated_at=row["deprecated_at"],
            retired_at=row["retired_at"],
        )

    async def database_now(self) -> datetime:
        value = await self._connection.fetchval("SELECT now()")  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
        return cast(datetime, value)


class AsyncNodeTagRepository(NodeTagRepository):  # pragma: no cover - integration adapter
    """RLS-bound ``NodeTagRepository`` backed by an existing asyncpg transaction."""

    def __init__(self, connection: asyncpg.Connection) -> None:
        self._connection = connection
        self._definition_service = TagDefinitionService(
            cast(Any, AsyncTagDefinitionRepository(connection))
        )

    async def load_source_node(self, node_id: UUID) -> NodeTagSourceSnapshot | None:
        row = await self._connection.fetchrow(  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
            """
            SELECT
              id,
              tenant_id,
              classification,
              body_nfc,
              body_nfc_hash,
              context_of_validity,
              archived_at
            FROM nodes
            WHERE id = $1
              AND tenant_id = ANY ((SELECT app.principal_visible())::uuid[])
            """,
            node_id,
        )
        if row is None:
            return None
        row = cast(Mapping[str, Any], row)
        return NodeTagSourceSnapshot(
            id=row["id"],
            tenant_id=row["tenant_id"],
            classification=ClassificationLevel(row["classification"]),
            body_nfc=row["body_nfc"],
            body_nfc_hash=bytes(row["body_nfc_hash"]),
            context_of_validity=_json_object(row["context_of_validity"]),
            archived_at=row["archived_at"],
        )

    async def load_reference_node(self, node_id: UUID) -> NodeTagReferenceSnapshot | None:
        row = await self._connection.fetchrow(  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
            """
            SELECT id, tenant_id, archived_at
            FROM nodes
            WHERE id = $1
              AND tenant_id = ANY ((SELECT app.principal_visible())::uuid[])
            """,
            node_id,
        )
        if row is None:
            return None
        row = cast(Mapping[str, Any], row)
        return NodeTagReferenceSnapshot(
            id=row["id"],
            tenant_id=row["tenant_id"],
            archived_at=row["archived_at"],
        )

    async def get_definition_for_application(
        self,
        *,
        context: TagDefinitionServiceContext,
        definition_id: UUID,
    ) -> TagDefinitionServiceResult:
        return await self._definition_service.get_definition_for_application(
            context,
            definition_id,
        )

    async def create_tag(self, draft: NodeTagRowDraft) -> NodeTagRow:
        row = await self._connection.fetchrow(  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
            """
            INSERT INTO node_tags (
              node_id,
              tenant_id,
              tag_definition_id,
              value_text,
              value_number,
              value_boolean,
              value_reference_node_id,
              currency,
              attrs,
              span_offset_start,
              span_offset_end,
              content_digest,
              text_quote_selector,
              context_of_validity,
              classification,
              tagged_by_principal_id,
              confidence
            )
            VALUES (
              $1, $2, $3, $4, $5, $6, $7, $8,
              $9::jsonb, $10, $11, $12, $13::jsonb, $14::jsonb,
              $15, $16, $17
            )
            RETURNING id, created_at
            """,
            draft.node_id,
            draft.tenant_id,
            draft.tag_definition_id,
            draft.value_text,
            draft.value_number,
            draft.value_boolean,
            draft.value_reference_node_id,
            draft.currency,
            json.dumps(draft.attrs),
            draft.span_offset_start,
            draft.span_offset_end,
            draft.content_digest,
            json.dumps(draft.text_quote_selector),
            json.dumps(draft.context_of_validity),
            draft.classification.value,
            draft.tagged_by_principal_id,
            draft.confidence,
        )
        if row is None:
            raise RuntimeError("node_tag_insert_failed")
        row = cast(Mapping[str, Any], row)
        return NodeTagRow(**draft.model_dump(), id=row["id"], created_at=row["created_at"])

    async def load_tag(self, tag_id: UUID) -> NodeTagRow | None:
        return await self._row_by_id(tag_id)

    async def lock_active_tag_family(
        self,
        *,
        node_id: UUID,
        tag_definition_id: UUID,
    ) -> tuple[NodeTagRow, ...]:
        rows = await self._connection.fetch(  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
            _NODE_TAG_SELECT
            + """
            WHERE node_id = $1
              AND tag_definition_id = $2
              AND tenant_id = ANY ((SELECT app.principal_visible())::uuid[])
              AND superseded_by_tag_id IS NULL
            FOR UPDATE
            """,
            node_id,
            tag_definition_id,
        )
        typed_rows = cast(list[asyncpg.Record], rows)
        return tuple(_node_tag_row(row) for row in typed_rows)

    async def verify_tag(
        self,
        tag_id: UUID,
        *,
        verified_by_principal_id: UUID,
    ) -> NodeTagRow:
        await self._connection.execute(  # pyright: ignore[reportUnknownMemberType]
            """
            UPDATE node_tags
            SET verified_by_principal_id = $2,
                verified_at = now()
            WHERE id = $1
              AND tenant_id = ANY ((SELECT app.principal_visible())::uuid[])
            """,
            tag_id,
            verified_by_principal_id,
        )
        row = await self._row_by_id(tag_id)
        if row is None:
            raise LookupError("node_tag_not_visible")
        return row

    async def supersede_tag(
        self,
        superseded_tag_id: UUID,
        *,
        superseding_tag_id: UUID,
    ) -> NodeTagRow:
        await self._connection.execute(  # pyright: ignore[reportUnknownMemberType]
            """
            UPDATE node_tags
            SET superseded_by_tag_id = $2
            WHERE id = $1
              AND tenant_id = ANY ((SELECT app.principal_visible())::uuid[])
            """,
            superseded_tag_id,
            superseding_tag_id,
        )
        row = await self._row_by_id(superseded_tag_id)
        if row is None:
            raise LookupError("node_tag_not_visible")
        return row

    async def mark_tag_attrs(self, tag_id: UUID, *, attrs: Mapping[str, Any]) -> NodeTagRow:
        await self._connection.execute(  # pyright: ignore[reportUnknownMemberType]
            """
            UPDATE node_tags
            SET attrs = $2::jsonb
            WHERE id = $1
              AND tenant_id = ANY ((SELECT app.principal_visible())::uuid[])
            """,
            tag_id,
            json.dumps(attrs),
        )
        row = await self._row_by_id(tag_id)
        if row is None:
            raise LookupError("node_tag_not_visible")
        return row

    async def list_active_tags_for_node(self, node_id: UUID) -> tuple[NodeTagRow, ...]:
        rows = await self._connection.fetch(  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
            _NODE_TAG_SELECT
            + """
            WHERE node_id = $1
              AND tenant_id = ANY ((SELECT app.principal_visible())::uuid[])
              AND superseded_by_tag_id IS NULL
            """,
            node_id,
        )
        typed_rows = cast(list[asyncpg.Record], rows)
        return tuple(_node_tag_row(row) for row in typed_rows)

    async def _row_by_id(self, tag_id: UUID) -> NodeTagRow | None:
        row = await self._connection.fetchrow(  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
            _NODE_TAG_SELECT
            + """
            WHERE id = $1
              AND tenant_id = ANY ((SELECT app.principal_visible())::uuid[])
            """,
            tag_id,
        )
        return None if row is None else _node_tag_row(cast(asyncpg.Record, row))


_NODE_TAG_SELECT = """
SELECT
  id,
  node_id,
  tenant_id,
  tag_definition_id,
  value_text,
  value_number,
  value_boolean,
  value_reference_node_id,
  currency,
  attrs,
  span_offset_start,
  span_offset_end,
  content_digest,
  text_quote_selector,
  context_of_validity,
  classification,
  tagged_by_principal_id,
  confidence,
  verified_by_principal_id,
  verified_at,
  superseded_by_tag_id,
  created_at
FROM node_tags
"""


def _node_tag_row(row: asyncpg.Record) -> NodeTagRow:  # pragma: no cover - adapter helper
    record = cast(Mapping[str, Any], row)
    return NodeTagRow(
        id=record["id"],
        node_id=record["node_id"],
        tenant_id=record["tenant_id"],
        tag_definition_id=record["tag_definition_id"],
        value_text=record["value_text"],
        value_number=record["value_number"],
        value_boolean=record["value_boolean"],
        value_reference_node_id=record["value_reference_node_id"],
        currency=None if record["currency"] is None else str(record["currency"]).strip(),
        attrs=_json_object(record["attrs"]),
        span_offset_start=record["span_offset_start"],
        span_offset_end=record["span_offset_end"],
        content_digest=bytes(record["content_digest"]),
        text_quote_selector=_json_object(record["text_quote_selector"]),
        context_of_validity=_json_object(record["context_of_validity"]),
        classification=ClassificationLevel(record["classification"]),
        tagged_by_principal_id=record["tagged_by_principal_id"],
        confidence=record["confidence"],
        verified_by_principal_id=record["verified_by_principal_id"],
        verified_at=cast(datetime | None, record["verified_at"]),
        superseded_by_tag_id=record["superseded_by_tag_id"],
        created_at=record["created_at"],
    )
