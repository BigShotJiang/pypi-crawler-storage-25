"""Server-side type classifier contract for Slice 3 graph writes.

Slice 3 Wave 1 plants the pure classifier core only: a narrow Protocol,
frozen request/result models, and the deterministic hand-authored stub used
until a later write-path integration wires Node persistence. The stub resolves
only exact active ontology type names inside the asserted ontology version.

References: §1.1, §1.2, §1.5, §1.15, §1.16, §6.5, §6.6, MP1, MP4, AP5.
"""

from __future__ import annotations

import math
from collections.abc import Sequence
from enum import StrEnum
from typing import Literal, Protocol, runtime_checkable
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

DEFAULT_TYPE_CLASSIFIER_THRESHOLD = 1.0

KindDiscriminator = Literal["hub", "document"]
UpdatePattern = Literal[1, 2, 3, 4]


class TypeClassificationStatus(StrEnum):
    """Whether a requested node type can proceed as canonical."""

    RESOLVED = "resolved"
    DRAFT = "draft"


class TypeClassificationReason(StrEnum):
    """Low-cardinality type classifier outcome reason."""

    HAND_AUTHORED_EXACT_MATCH = "hand_authored_exact_match"
    MISSING_TYPE = "missing_type"
    UNKNOWN_TYPE = "unknown_type"
    AMBIGUOUS_TYPE = "ambiguous_type"
    BELOW_THRESHOLD = "below_threshold"
    ONTOLOGY_VERSION_MISMATCH = "ontology_version_mismatch"
    RESERVED_TYPE = "reserved_type"
    DEPRECATED_TYPE = "deprecated_type"
    CLASSIFIER_UNAVAILABLE = "classifier_unavailable"
    CLASSIFIER_INVALID_RESULT = "classifier_invalid_result"


class OntologyTypeLifecycle(StrEnum):
    """Minimal lifecycle vocabulary the pure stub needs."""

    ACTIVE = "active"
    DEPRECATED = "deprecated"
    RETIRED = "retired"


def _validate_probability(value: float, *, field_name: str) -> float:
    if not math.isfinite(value) or value < 0.0 or value > 1.0:
        raise ValueError(f"{field_name} must be a finite float in [0.0, 1.0]")
    return value


def accepts_confidence(confidence: float, threshold: float) -> bool:
    """Return whether ``confidence`` accepts at ``threshold``.

    The acceptance predicate is deliberately ``>=``. Invalid values are
    contract errors for classifier implementations, not low-confidence results.
    """

    valid_confidence = _validate_probability(confidence, field_name="confidence")
    valid_threshold = _validate_probability(threshold, field_name="threshold")
    return valid_confidence >= valid_threshold


class TypeClassificationRequest(BaseModel):
    """Input to the server-side type classifier.

    Extra fields are forbidden so client-supplied classifier output, confidence,
    kind, or update pattern cannot enter this server contract.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    tenant_id: UUID
    ontology_version_id: UUID
    requested_type_name: str | None = None
    actor_principal_id: UUID | None = None
    body_preview_hash: str | None = None


class OntologyTypeCandidate(BaseModel):
    """Repository row shape consumed by the pure classifier stub."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    tenant_id: UUID | None = None
    ontology_version_id: UUID
    name: str
    kind_discriminator: KindDiscriminator
    update_pattern: UpdatePattern
    lifecycle: OntologyTypeLifecycle = OntologyTypeLifecycle.ACTIVE
    reserved: bool = False

    @property
    def is_active(self) -> bool:
        """Whether this type can be canonicalized by normal Slice 3 writes."""

        return self.lifecycle is OntologyTypeLifecycle.ACTIVE


class TypeClassificationResult(BaseModel):
    """Server-derived type classification result."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    status: TypeClassificationStatus
    reason_code: TypeClassificationReason
    confidence: float = Field(ge=0.0, le=1.0)
    threshold: float = Field(ge=0.0, le=1.0)
    ontology_type_id: UUID | None = None
    type_name: str | None = None
    kind_discriminator: KindDiscriminator | None = None
    update_pattern: UpdatePattern | None = None
    candidate_type_ids: tuple[UUID, ...] = ()
    classifier_name: str = "hand_authored_stub"
    classifier_version: str = "slice-3-wave-1"
    threshold_version_id: UUID | None = None

    @field_validator("confidence", "threshold")
    @classmethod
    def _finite_probability(cls, value: float) -> float:
        return _validate_probability(value, field_name="probability")

    @model_validator(mode="after")
    def _resolved_results_are_complete(self) -> TypeClassificationResult:
        if self.status is TypeClassificationStatus.RESOLVED:
            missing = [
                name
                for name in (
                    "ontology_type_id",
                    "type_name",
                    "kind_discriminator",
                    "update_pattern",
                )
                if getattr(self, name) is None
            ]
            if missing:
                raise ValueError(f"resolved classifier result missing fields: {missing}")
            if not accepts_confidence(self.confidence, self.threshold):
                raise ValueError("resolved classifier result is below threshold")
        else:
            resolved_only_fields = [
                name
                for name in (
                    "ontology_type_id",
                    "kind_discriminator",
                    "update_pattern",
                )
                if getattr(self, name) is not None
            ]
            if resolved_only_fields:
                raise ValueError(
                    f"draft classifier result carries resolved-only fields: {resolved_only_fields}",
                )
        return self

    @classmethod
    def resolved(
        cls,
        *,
        candidate: OntologyTypeCandidate,
        threshold: float = DEFAULT_TYPE_CLASSIFIER_THRESHOLD,
        threshold_version_id: UUID | None = None,
    ) -> TypeClassificationResult:
        return cls(
            status=TypeClassificationStatus.RESOLVED,
            reason_code=TypeClassificationReason.HAND_AUTHORED_EXACT_MATCH,
            confidence=1.0,
            threshold=threshold,
            ontology_type_id=candidate.id,
            type_name=candidate.name,
            kind_discriminator=candidate.kind_discriminator,
            update_pattern=candidate.update_pattern,
            candidate_type_ids=(candidate.id,),
            threshold_version_id=threshold_version_id,
        )

    @classmethod
    def draft(
        cls,
        *,
        reason_code: TypeClassificationReason,
        threshold: float = DEFAULT_TYPE_CLASSIFIER_THRESHOLD,
        threshold_version_id: UUID | None = None,
        candidate_type_ids: Sequence[UUID] = (),
        requested_type_name: str | None = None,
    ) -> TypeClassificationResult:
        return cls(
            status=TypeClassificationStatus.DRAFT,
            reason_code=reason_code,
            confidence=0.0,
            threshold=threshold,
            type_name=requested_type_name,
            candidate_type_ids=tuple(candidate_type_ids),
            threshold_version_id=threshold_version_id,
        )


@runtime_checkable
class TypeClassifierRepository(Protocol):
    """Repository surface for ontology type lookup."""

    async def find_by_name(
        self,
        *,
        tenant_id: UUID,
        ontology_version_id: UUID,
        requested_type_name: str,
    ) -> Sequence[OntologyTypeCandidate]:
        """Return ontology type candidates matching the asserted version and name."""
        ...


@runtime_checkable
class TypeClassifier(Protocol):
    """Server-side type classifier used before canonical Node write behavior."""

    async def classify(self, request: TypeClassificationRequest) -> TypeClassificationResult:
        """Resolve or draft the requested type."""
        ...


class InMemoryOntologyTypeRepository:
    """Small repository implementation for schema-independent unit fixtures."""

    def __init__(self, candidates: Sequence[OntologyTypeCandidate]) -> None:
        self._candidates = tuple(candidates)

    async def find_by_name(
        self,
        *,
        tenant_id: UUID,
        ontology_version_id: UUID,
        requested_type_name: str,
    ) -> Sequence[OntologyTypeCandidate]:
        normalized_name = requested_type_name.strip()
        return tuple(
            candidate
            for candidate in self._candidates
            if candidate.ontology_version_id == ontology_version_id
            and candidate.name == normalized_name
            and (candidate.tenant_id is None or candidate.tenant_id == tenant_id)
        )


class HandAuthoredTypeClassifier:
    """Cold-start deterministic classifier for hand-authored ontology types."""

    def __init__(
        self,
        repository: TypeClassifierRepository,
        *,
        threshold: float = DEFAULT_TYPE_CLASSIFIER_THRESHOLD,
    ) -> None:
        self._repository = repository
        self._threshold = _validate_probability(threshold, field_name="threshold")

    async def classify(self, request: TypeClassificationRequest) -> TypeClassificationResult:
        requested_type_name = request.requested_type_name
        if requested_type_name is None or requested_type_name.strip() == "":
            return TypeClassificationResult.draft(
                reason_code=TypeClassificationReason.MISSING_TYPE,
                threshold=self._threshold,
            )

        candidates = tuple(
            await self._repository.find_by_name(
                tenant_id=request.tenant_id,
                ontology_version_id=request.ontology_version_id,
                requested_type_name=requested_type_name,
            )
        )
        if not candidates:
            return TypeClassificationResult.draft(
                reason_code=TypeClassificationReason.UNKNOWN_TYPE,
                threshold=self._threshold,
                requested_type_name=requested_type_name,
            )

        candidate_ids = tuple(candidate.id for candidate in candidates)
        if any(candidate.reserved for candidate in candidates):
            return TypeClassificationResult.draft(
                reason_code=TypeClassificationReason.RESERVED_TYPE,
                threshold=self._threshold,
                candidate_type_ids=candidate_ids,
                requested_type_name=requested_type_name,
            )

        active_candidates = [candidate for candidate in candidates if candidate.is_active]
        active_count = len(active_candidates)
        if active_count == 0:
            if any(
                candidate.lifecycle is OntologyTypeLifecycle.DEPRECATED for candidate in candidates
            ):
                reason = TypeClassificationReason.DEPRECATED_TYPE
            else:
                reason = TypeClassificationReason.UNKNOWN_TYPE
            return TypeClassificationResult.draft(
                reason_code=reason,
                threshold=self._threshold,
                candidate_type_ids=candidate_ids,
                requested_type_name=requested_type_name,
            )

        if active_count > 1:
            return TypeClassificationResult.draft(
                reason_code=TypeClassificationReason.AMBIGUOUS_TYPE,
                threshold=self._threshold,
                candidate_type_ids=tuple(candidate.id for candidate in active_candidates),
                requested_type_name=requested_type_name,
            )

        [candidate] = active_candidates
        result = TypeClassificationResult.resolved(
            candidate=candidate,
            threshold=self._threshold,
        )
        if not accepts_confidence(result.confidence, result.threshold):
            return TypeClassificationResult.draft(
                reason_code=TypeClassificationReason.BELOW_THRESHOLD,
                threshold=self._threshold,
                candidate_type_ids=(candidate.id,),
                requested_type_name=requested_type_name,
            )
        return result
