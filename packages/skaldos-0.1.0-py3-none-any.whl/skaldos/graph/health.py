"""Content-free graph health counters for Slice 9."""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from enum import StrEnum
from typing import Any, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict, Field, field_validator

from skaldos.graph.transaction import with_principal
from skaldos.middleware import Principal


class GraphHealthCounterName(StrEnum):
    """Closed Slice 9 graph-health counter vocabulary."""

    NEEDS_REVIEW_OPEN_COUNT = "needs_review.open.count"
    SURPRISE_UNRESOLVED_COUNT = "surprise.unresolved.count"
    CONVERSATION_STALLED_OPEN_COUNT = "conversation.stalled.open.count"
    CLASSIFIER_CALIBRATION_TIGHTENED_COUNT = "classifier.calibration.tightened.count"
    DEPENDENCY_WALK_FAILURE_COUNT = "dependency_walk.failure.count"
    TEMPORAL_INTEGRITY_WARNING_COUNT = "temporal_integrity.warning.count"


class GraphHealthCounter(BaseModel):
    """One content-free counter bucket."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    name: GraphHealthCounterName
    tenant_id: UUID
    count: int = Field(ge=0)
    dimensions: Mapping[str, str] = Field(default_factory=dict)

    @field_validator("dimensions")
    @classmethod
    def _dimensions_are_content_free(cls, value: Mapping[str, str]) -> Mapping[str, str]:
        forbidden = {"body", "content", "prompt", "response", "secret", "token"}
        for key, item in value.items():
            normalized_key = key.lower().replace("-", "_").replace(".", "_")
            normalized_item = item.lower().replace("-", "_").replace(".", "_")
            if any(token in normalized_key for token in forbidden) or any(
                token in normalized_item for token in forbidden
            ):
                raise ValueError("graph_health_dimension_content_rejected")
        return value


class GraphHealthRequest(BaseModel):
    """Request for Slice 9 graph-health counters."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    tenant_id: UUID


class GraphHealthSnapshot(BaseModel):
    """Content-free graph-health response."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    tenant_id: UUID
    counters: tuple[GraphHealthCounter, ...]


class GraphHealthQueryError(RuntimeError):
    """Unexpected storage failure while reading graph-health counters."""


GRAPH_HEALTH_COUNTERS_SQL = """
WITH review_rows AS (
  SELECT
    marker.tenant_id,
    marker.id AS marker_id,
    COALESCE(
      marker.metadata ->> 'domain',
      marker.context_of_validity ->> 'vertical',
      'foundation'
    ) AS domain,
    ot.name AS node_type_family,
    CASE GREATEST(
        app.classification_rank(marker.classification),
        app.classification_rank(dependent.classification),
        app.classification_rank(e.classification)
      )
      WHEN 0 THEN 'C0'
      WHEN 1 THEN 'C1'
      WHEN 2 THEN 'C2'
      WHEN 3 THEN 'C3'
      ELSE 'C4'
    END AS max_classification,
    CASE
      WHEN transaction_timestamp() - marker.created_at < interval '1 hour' THEN 'lt_1h'
      WHEN transaction_timestamp() - marker.created_at < interval '1 day' THEN 'lt_1d'
      WHEN transaction_timestamp() - marker.created_at < interval '7 days' THEN 'lt_7d'
      ELSE 'gte_7d'
    END AS age_bucket
  FROM nodes marker
  JOIN edges e
    ON e.tenant_id = marker.tenant_id
   AND e.target_node_id = marker.id
   AND e.relationship_type = 'review-required-by'
   AND e.archived_at IS NULL
  JOIN nodes dependent
    ON dependent.id = e.source_node_id
   AND dependent.tenant_id = marker.tenant_id
   AND dependent.archived_at IS NULL
   AND dependent.superseded_by_node_id IS NULL
  JOIN ontology_type ot
    ON ot.id = dependent.type_id
   AND ot.ontology_version_id = dependent.ontology_version_id
  WHERE marker.tenant_id = $1
    AND marker.metadata ->> 'shape' = 'skaldos.review_flag.v1'
    AND marker.metadata ->> 'status' = 'open'
    AND marker.archived_at IS NULL
    AND marker.superseded_by_node_id IS NULL
    AND app.principal_context_contains(marker.context_of_validity)
    AND app.principal_context_contains(dependent.context_of_validity)
),
surprise_rows AS (
  SELECT
    s.tenant_id,
    s.id AS surprise_id,
    s.classification,
    COALESCE(s.domain, s.context_of_validity ->> 'vertical', 'foundation') AS domain,
    CASE
      WHEN s.magnitude < 0.2500 THEN 'lt_0_25'
      WHEN s.magnitude < 0.5000 THEN '0_25_to_lt_0_50'
      WHEN s.magnitude < 0.7500 THEN '0_50_to_lt_0_75'
      ELSE 'gte_0_75'
    END AS magnitude_bucket,
    s.loop_level,
    s.prediction_subject_type AS subject_type,
    CASE
      WHEN transaction_timestamp() - s.created_at < interval '1 hour' THEN 'lt_1h'
      WHEN transaction_timestamp() - s.created_at < interval '1 day' THEN 'lt_1d'
      WHEN transaction_timestamp() - s.created_at < interval '7 days' THEN 'lt_7d'
      ELSE 'gte_7d'
    END AS age_bucket
  FROM surprise_stream s
  WHERE s.tenant_id = $1
    AND NOT EXISTS (
      SELECT 1
      FROM surprise_stream successor
      WHERE successor.tenant_id = s.tenant_id
        AND successor.supersedes_raw_surprise_id = s.id
    )
    AND app.principal_context_contains(s.context_of_validity)
),
stalled_conversation_rows AS (
  SELECT
    n.tenant_id,
    n.id AS conversation_id,
    n.classification,
    COALESCE(n.metadata ->> 'domain', 'supervision') AS supervisor_domain,
    COALESCE(n.metadata ->> 'requestee_principal_kind', 'unknown') AS requestee_kind,
    CASE
      WHEN transaction_timestamp()
           - COALESCE((n.metadata ->> 'stalled_at')::timestamptz, n.created_at)
           < interval '1 hour' THEN 'lt_1h'
      WHEN transaction_timestamp()
           - COALESCE((n.metadata ->> 'stalled_at')::timestamptz, n.created_at)
           < interval '1 day' THEN 'lt_1d'
      WHEN transaction_timestamp()
           - COALESCE((n.metadata ->> 'stalled_at')::timestamptz, n.created_at)
           < interval '7 days' THEN 'lt_7d'
      ELSE 'gte_7d'
    END AS age_bucket
  FROM nodes n
  WHERE n.tenant_id = $1
    AND n.metadata ->> 'shape' = 'skaldos.conversation.v1'
    AND n.metadata ->> 'current_state' = 'stalled'
    AND n.archived_at IS NULL
    AND n.superseded_by_node_id IS NULL
    AND app.principal_context_contains(n.context_of_validity)
),
tightened_calibration_rows AS (
  SELECT
    cfg.tenant_id,
    cfg.id AS threshold_config_id,
    cfg.classification,
    cfg.node_type_family,
    cfg.config_version::text AS threshold_version,
    CASE
      WHEN transaction_timestamp() - cfg.created_at < interval '1 hour' THEN 'lt_1h'
      WHEN transaction_timestamp() - cfg.created_at < interval '1 day' THEN 'lt_1d'
      WHEN transaction_timestamp() - cfg.created_at < interval '7 days' THEN 'lt_7d'
      ELSE 'gte_7d'
    END AS age_bucket
  FROM classifier_threshold_config cfg
  WHERE cfg.tenant_id = $1
    AND cfg.created_from_surprise_id IS NOT NULL
    AND app.principal_context_contains(cfg.context_of_validity)
),
dependency_failure_rows AS (
  SELECT
    marker.tenant_id,
    marker.id AS marker_id,
    COALESCE(marker.metadata ->> 'dependency_walk_failure_reason', 'truncated') AS reason_code,
    COALESCE(marker.metadata ->> 'dependency_walk_depth_bucket', 'unknown') AS depth_bucket,
    CASE
      WHEN transaction_timestamp() - marker.created_at < interval '1 hour' THEN 'lt_1h'
      WHEN transaction_timestamp() - marker.created_at < interval '1 day' THEN 'lt_1d'
      WHEN transaction_timestamp() - marker.created_at < interval '7 days' THEN 'lt_7d'
      ELSE 'gte_7d'
    END AS age_bucket
  FROM nodes marker
  WHERE marker.tenant_id = $1
    AND marker.metadata ->> 'shape' = 'skaldos.review_flag.v1'
    AND marker.archived_at IS NULL
    AND marker.superseded_by_node_id IS NULL
    AND app.principal_context_contains(marker.context_of_validity)
    AND (
      marker.metadata ? 'dependency_walk_failure_reason'
      OR marker.metadata ->> 'dependency_walk_truncated' = 'true'
    )
),
temporal_warning_rows AS (
  SELECT
    n.tenant_id,
    'node' AS primitive,
    CASE
      WHEN n.superseded_by_node_id = n.id THEN 'node_supersession_cycle_detected'
      ELSE 'node_temporal_validity_overlap'
    END AS reason_code,
    CASE
      WHEN transaction_timestamp() - n.created_at < interval '1 hour' THEN 'lt_1h'
      WHEN transaction_timestamp() - n.created_at < interval '1 day' THEN 'lt_1d'
      WHEN transaction_timestamp() - n.created_at < interval '7 days' THEN 'lt_7d'
      ELSE 'gte_7d'
    END AS age_bucket
  FROM nodes n
  WHERE n.tenant_id = $1
    AND app.principal_context_contains(n.context_of_validity)
    AND (
      n.superseded_by_node_id = n.id
      OR (
        (n.context_of_validity ->> 'valid_to') IS NOT NULL
        AND (n.context_of_validity ->> 'valid_to') <> ''
        AND (n.context_of_validity ->> 'valid_to')::timestamptz
            < (n.context_of_validity ->> 'valid_from')::timestamptz
      )
    )

  UNION ALL

  SELECT
    nt.tenant_id,
    'tag' AS primitive,
    CASE
      WHEN nt.superseded_by_tag_id = nt.id THEN 'tag_supersession_cycle_detected'
      ELSE 'tag_temporal_validity_overlap'
    END AS reason_code,
    CASE
      WHEN transaction_timestamp() - nt.created_at < interval '1 hour' THEN 'lt_1h'
      WHEN transaction_timestamp() - nt.created_at < interval '1 day' THEN 'lt_1d'
      WHEN transaction_timestamp() - nt.created_at < interval '7 days' THEN 'lt_7d'
      ELSE 'gte_7d'
    END AS age_bucket
  FROM node_tags nt
  WHERE nt.tenant_id = $1
    AND app.principal_context_contains(nt.context_of_validity)
    AND (
      nt.superseded_by_tag_id = nt.id
      OR (
        (nt.context_of_validity ->> 'valid_to') IS NOT NULL
        AND (nt.context_of_validity ->> 'valid_to') <> ''
        AND (nt.context_of_validity ->> 'valid_to')::timestamptz
            < (nt.context_of_validity ->> 'valid_from')::timestamptz
      )
    )
),
counter_rows AS (
SELECT
  'needs_review.open.count' AS name,
  tenant_id,
  count(DISTINCT marker_id)::bigint AS count,
  jsonb_build_object(
    'domain', domain,
    'node_type_family', node_type_family,
    'max_classification', max_classification,
    'age_bucket', age_bucket
  ) AS dimensions
FROM review_rows
GROUP BY tenant_id, domain, node_type_family, max_classification, age_bucket

UNION ALL

SELECT
  'surprise.unresolved.count' AS name,
  tenant_id,
  count(DISTINCT surprise_id)::bigint AS count,
  jsonb_build_object(
    'domain', domain,
    'classification', classification,
    'magnitude_bucket', magnitude_bucket,
    'loop_level', loop_level,
    'subject_type', subject_type,
    'age_bucket', age_bucket
  ) AS dimensions
FROM surprise_rows
GROUP BY tenant_id, domain, classification, magnitude_bucket, loop_level, subject_type, age_bucket

UNION ALL

SELECT
  'conversation.stalled.open.count' AS name,
  tenant_id,
  count(DISTINCT conversation_id)::bigint AS count,
  jsonb_build_object(
    'supervisor_domain', supervisor_domain,
    'classification', classification,
    'requestee_kind', requestee_kind,
    'age_bucket', age_bucket
  ) AS dimensions
FROM stalled_conversation_rows
GROUP BY tenant_id, supervisor_domain, classification, requestee_kind, age_bucket

UNION ALL

SELECT
  'classifier.calibration.tightened.count' AS name,
  tenant_id,
  count(DISTINCT threshold_config_id)::bigint AS count,
  jsonb_build_object(
    'classification', classification,
    'node_type_family', node_type_family,
    'threshold_version', threshold_version,
    'age_bucket', age_bucket
  ) AS dimensions
FROM tightened_calibration_rows
GROUP BY tenant_id, classification, node_type_family, threshold_version, age_bucket

UNION ALL

SELECT
  'dependency_walk.failure.count' AS name,
  tenant_id,
  count(DISTINCT marker_id)::bigint AS count,
  jsonb_build_object(
    'reason_code', reason_code,
    'depth_bucket', depth_bucket,
    'age_bucket', age_bucket
  ) AS dimensions
FROM dependency_failure_rows
GROUP BY tenant_id, reason_code, depth_bucket, age_bucket

UNION ALL

SELECT
  'temporal_integrity.warning.count' AS name,
  tenant_id,
  count(*)::bigint AS count,
  jsonb_build_object(
    'primitive', primitive,
    'reason_code', reason_code,
    'age_bucket', age_bucket
  ) AS dimensions
FROM temporal_warning_rows
GROUP BY tenant_id, primitive, reason_code, age_bucket
)
SELECT name, tenant_id, count, dimensions
FROM counter_rows
ORDER BY name, dimensions::text;
"""


class GraphHealthService:
    """Read content-free graph-health counters for one principal-visible tenant."""

    async def snapshot(
        self,
        *,
        connection: asyncpg.Connection,
        principal: Principal,
        request: GraphHealthRequest,
    ) -> GraphHealthSnapshot:
        if request.tenant_id not in principal.visible_tenant_ids:
            raise GraphHealthQueryError("graph_health_tenant_not_visible")

        async def _snapshot(bound_connection: asyncpg.Connection) -> GraphHealthSnapshot:
            rows = cast(
                Sequence[Mapping[str, Any]],
                await bound_connection.fetch(  # pyright: ignore[reportUnknownMemberType]
                    GRAPH_HEALTH_COUNTERS_SQL,
                    request.tenant_id,
                ),
            )
            return GraphHealthSnapshot(
                tenant_id=request.tenant_id,
                counters=tuple(_counter_from_row(row) for row in rows),
            )

        try:
            return await with_principal(
                principal=principal,
                connection=connection,
                fn=_snapshot,
            )
        except Exception as exc:
            raise GraphHealthQueryError("graph_health_query_failed") from exc


def _counter_from_row(row: Mapping[str, Any]) -> GraphHealthCounter:
    return GraphHealthCounter(
        name=GraphHealthCounterName(str(row["name"])),
        tenant_id=UUID(str(row["tenant_id"])),
        count=int(row["count"]),
        dimensions=_dimensions(row["dimensions"]),
    )


def _dimensions(value: object) -> Mapping[str, str]:
    parsed = json.loads(value) if isinstance(value, str) else value
    if parsed is None:
        return {}
    if not isinstance(parsed, Mapping):
        raise GraphHealthQueryError("graph_health_query_failed")
    mapping = cast(Mapping[object, object], parsed)
    return {str(key): str(item) for key, item in mapping.items() if item is not None}


__all__ = [
    "GRAPH_HEALTH_COUNTERS_SQL",
    "GraphHealthCounter",
    "GraphHealthCounterName",
    "GraphHealthQueryError",
    "GraphHealthRequest",
    "GraphHealthService",
    "GraphHealthSnapshot",
]
