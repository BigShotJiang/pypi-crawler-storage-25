"""Conflict-resolution contracts for staged graph assertions.

This module owns pure data contracts shared by the Slice 4 resolver, endpoint,
audit, and verification work. It does not consume staged rows, mutate canonical
graph tables, or create disagreement/corroboration storage.

References: ``conflict-resolution-and-disagreement`` T1; Slice 4 master plan
"Shared artifacts & contracts"; §1.9, §10.7, AP5, AP11.
"""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any, Literal, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict, Field, field_validator

from skaldos.events.graph_publisher import (
    GraphChangeEventPublisher,
    OutboxGraphChangeEventPublisher,
)
from skaldos.graph.assert_contract import AssertionResolutionOutcome
from skaldos.graph.assert_staging import (
    ASSERTION_DIGEST_VERSION,
    TERMINAL_PENDING_ASSERTION_STATUSES,
    PendingAssertionStatus,
)
from skaldos.graph.node_tags import (
    NodeTagApplyRequest,
    NodeTagRepository,
    NodeTagRow,
    NodeTagSupersedeRequest,
    RepositoryNodeTagService,
)
from skaldos.graph.tag_definitions_service import TagDefinitionServiceContext
from skaldos.graph.transaction import with_principal
from skaldos.middleware import Principal

RANKING_SIGNAL_VERSION = 1


class AssertionResolutionReason(StrEnum):
    """Low-cardinality resolver reason vocabulary safe for audit/log handoff."""

    ACCEPTED_NEW_FACT = "accepted_new_fact"
    IDEMPOTENT_REPLAY = "idempotent_replay"
    EXACT_DUPLICATE = "exact_duplicate"
    NEW_CORROBORATION = "new_corroboration"
    SINGLETON_SUPERSEDED = "singleton_superseded"
    SINGLETON_CONFLICT = "singleton_conflict"
    HUMAN_VERIFIED_CONFLICT = "human_verified_conflict"
    STALE_ACTIVE_HEAD = "stale_active_head"
    MALFORMED_STAGED_ASSERTION = "malformed_staged_assertion"
    SERIALIZATION_RETRY = "serialization_retry"
    HIDDEN_CONFLICT_DETAIL = "hidden_conflict_detail"


class AssertionRankingSignal(BaseModel):
    """Stable ranking inputs extracted by the resolver.

    The tuple is a signal contract, not a final product scoring formula.
    Retrieval can evolve scoring later without parsing raw claim bodies.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    actor_kind: Literal["human", "agent"]
    actor_principal_id: UUID
    source_kind: str = Field(min_length=1, max_length=63)
    source_identifier: str | None = Field(default=None, max_length=512)
    model_provider: str | None = Field(default=None, max_length=128)
    model_family: str | None = Field(default=None, max_length=128)
    model_name: str | None = Field(default=None, max_length=128)
    asserted_at: datetime
    confidence: float | None = Field(default=None, ge=0.0, le=1.0, allow_inf_nan=False)
    corroboration_count: int = Field(default=0, ge=0)
    diverse_corroboration_count: int = Field(default=0, ge=0)
    human_verified: bool = False
    ranking_signal_version: int = RANKING_SIGNAL_VERSION

    @field_validator("asserted_at")
    @classmethod
    def _asserted_at_must_be_aware(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("asserted_at must be timezone-aware")
        return value.astimezone(UTC)


def ranking_sort_key(signal: AssertionRankingSignal) -> tuple[object, ...]:
    """Return deterministic descending-priority ranking key for tests/projections."""

    actor_priority = 1 if signal.actor_kind == "human" else 0
    confidence = signal.confidence if signal.confidence is not None else -1.0
    return (
        signal.human_verified,
        actor_priority,
        signal.diverse_corroboration_count,
        signal.corroboration_count,
        confidence,
        signal.asserted_at,
        str(signal.actor_principal_id),
        signal.source_kind,
        signal.source_identifier or "",
    )


class AssertionResolutionVisibleResult(BaseModel):
    """Policy-safe result shape returned by conflict resolution.

    Hidden canonical/disagreement identifiers are elided when the caller cannot
    see the conflicting row, while the typed outcome and reason remain visible.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    outcome: AssertionResolutionOutcome
    reason: AssertionResolutionReason
    assertion_id: UUID
    fact_family_key: str
    canonical_row_kind: str | None = None
    canonical_row_id: UUID | None = None
    previous_row_id: UUID | None = None
    disagreement_id: UUID | None = None
    hidden_detail: bool = False
    ranking_signal: AssertionRankingSignal | None = None


class StagedAssertionCandidate(BaseModel):
    """Locked staged assertion projection ready for later resolver phases."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    status: PendingAssertionStatus
    actor_principal_id: UUID
    tenant_id: UUID
    context_of_validity: Mapping[str, Any]
    claim_kind: str
    source_kind: str
    source_identifier: str | None = None
    model_provider: str | None = None
    model_family: str | None = None
    model_name: str | None = None
    confidence: float | None = Field(default=None, ge=0.0, le=1.0, allow_inf_nan=False)
    normalized_fact_digest: bytes
    idempotency_key: str
    digest_version: int = ASSERTION_DIGEST_VERSION
    created_at: datetime

    @field_validator("created_at")
    @classmethod
    def _created_at_must_be_aware(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("created_at must be timezone-aware")
        return value.astimezone(UTC)

    @property
    def fact_family_key(self) -> str:
        """Resolver-local key derived from staging's normalized fact digest."""

        return f"pending-normalized-fact:v{self.digest_version}:{self.normalized_fact_digest.hex()}"


class StagedAssertionConsumerResult(BaseModel):
    """T3 resolver entry result before active-family algorithms are wired."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    kind: Literal["candidate", "replay", "rejected"]
    candidate: StagedAssertionCandidate | None = None
    outcome: AssertionResolutionVisibleResult | None = None


class AssertionCorroborationRecord(BaseModel):
    """Resolver-owned corroboration/provenance projection."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    canonical_row_kind: str
    canonical_row_id: UUID
    staged_assertion_id: UUID
    outcome: AssertionResolutionOutcome
    reason: AssertionResolutionReason
    ranking_signal: AssertionRankingSignal
    created_at: datetime

    @field_validator("created_at")
    @classmethod
    def _created_at_must_be_aware(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("created_at must be timezone-aware")
        return value.astimezone(UTC)


class AssertionDisagreementRecord(BaseModel):
    """Resolver-owned open disagreement queue projection."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    current_row_kind: str
    current_row_id: UUID
    proposed_row_kind: str
    proposed_row_id: UUID | None = None
    staged_assertion_id: UUID
    outcome: AssertionResolutionOutcome
    reason: AssertionResolutionReason
    ranking_signal: AssertionRankingSignal
    created_at: datetime

    @field_validator("created_at")
    @classmethod
    def _created_at_must_be_aware(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("created_at must be timezone-aware")
        return value.astimezone(UTC)


class NodeTagSingletonResolution(BaseModel):
    """Resolver result for an active-family NodeTag singleton mutation."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    result: AssertionResolutionVisibleResult
    previous_tag: NodeTagRow | None = None
    new_tag: NodeTagRow | None = None


class StagedAssertionNotVisibleError(LookupError):
    """Raised when RLS/principal context cannot see the requested staged row."""

    def __init__(self, staged_assertion_id: UUID) -> None:
        self.staged_assertion_id = staged_assertion_id
        super().__init__("staged_assertion_not_visible")


def _resolution_result_from_payload(
    *,
    assertion_id: UUID,
    payload: Mapping[str, Any] | None,
) -> AssertionResolutionVisibleResult | None:
    if not payload:
        return None
    raw_outcome = payload.get("outcome")
    raw_reason = payload.get("reason")
    raw_fact_family_key = payload.get("fact_family_key")
    if not (
        isinstance(raw_outcome, str)
        and isinstance(raw_reason, str)
        and isinstance(raw_fact_family_key, str)
        and raw_fact_family_key.strip() != ""
    ):
        return None

    try:
        return AssertionResolutionVisibleResult(
            outcome=AssertionResolutionOutcome(raw_outcome),
            reason=AssertionResolutionReason(raw_reason),
            assertion_id=assertion_id,
            fact_family_key=raw_fact_family_key,
        )
    except ValueError:
        return None


def _jsonb_mapping(value: object) -> Mapping[str, Any] | None:
    if isinstance(value, Mapping):
        return cast(Mapping[str, Any], value)
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
        except json.JSONDecodeError:
            return None
        if isinstance(parsed, Mapping):
            return cast(Mapping[str, Any], parsed)
    return None


def _ranking_signal_from_payload(value: object) -> AssertionRankingSignal | None:
    payload = _jsonb_mapping(value)
    if payload is None:
        return None
    return AssertionRankingSignal.model_validate(payload)


def _ranking_signal_json(signal: AssertionRankingSignal) -> str:
    return json.dumps(signal.model_dump(mode="json"), sort_keys=True, separators=(",", ":"))


def _malformed_result(*, fact_family_key: str) -> dict[str, str]:
    return {
        "outcome": AssertionResolutionOutcome.REJECTED.value,
        "reason": AssertionResolutionReason.MALFORMED_STAGED_ASSERTION.value,
        "fact_family_key": fact_family_key,
    }


async def consume_staged_assertion(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    staged_assertion_id: UUID,
) -> StagedAssertionConsumerResult:
    """Load and lock one staged assertion through Principal/RLS context.

    This is the T3 resolver entry point. It does not apply graph mutations or
    run active-family conflict algorithms. It either returns a locked normalized
    candidate, returns the prior resolver outcome for replay, or persists a
    typed ``rejected`` outcome for malformed legacy staged rows.
    """

    async def _consume(bound_connection: asyncpg.Connection) -> StagedAssertionConsumerResult:
        row = cast(
            Any | None,
            await bound_connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                """
                SELECT
                    id,
                    status::text AS status,
                    actor_principal_id,
                    tenant_id,
                    context_of_validity,
                    claim_kind,
                    source_kind,
                    COALESCE(
                      NULLIF(source ->> 'identifier', ''),
                      NULLIF(source ->> 'external_id', ''),
                      NULLIF(source ->> 'locator', '')
                    ) AS source_identifier,
                    COALESCE(
                      NULLIF(source ->> 'model_provider', ''),
                      NULLIF(source #>> '{metadata,model_provider}', '')
                    ) AS model_provider,
                    COALESCE(
                      NULLIF(source ->> 'model_family', ''),
                      NULLIF(source #>> '{metadata,model_family}', '')
                    ) AS model_family,
                    COALESCE(
                      NULLIF(source ->> 'model_name', ''),
                      NULLIF(source #>> '{metadata,model_name}', '')
                    ) AS model_name,
                    confidence::float AS confidence,
                    normalized_fact_digest,
                    idempotency_key,
                    digest_version,
                    conflict_result,
                    created_at
                FROM pending_assertions
                WHERE id = $1
                  AND actor_principal_id = $2
                FOR UPDATE
                """,
                staged_assertion_id,
                principal.id,
            ),
        )
        if row is None:
            raise StagedAssertionNotVisibleError(staged_assertion_id)

        replay = _resolution_result_from_payload(
            assertion_id=cast(UUID, row["id"]),
            payload=_jsonb_mapping(row["conflict_result"]),
        )
        if replay is not None:
            return StagedAssertionConsumerResult(kind="replay", outcome=replay)

        status = PendingAssertionStatus(cast(str, row["status"]))
        raw_fact_digest = cast(bytes | None, row["normalized_fact_digest"])
        raw_claim_kind = cast(str | None, row["claim_kind"])
        raw_source_kind = cast(str | None, row["source_kind"])
        raw_idempotency_key = cast(str | None, row["idempotency_key"])
        digest_version = cast(int, row["digest_version"])
        context_of_validity = _jsonb_mapping(row["context_of_validity"])
        fallback_fact_family_key = (
            f"pending-normalized-fact:v{digest_version}:{raw_fact_digest.hex()}"
            if raw_fact_digest
            else f"pending-assertion:{row['id']}"
        )
        malformed = (
            status is not PendingAssertionStatus.STAGED
            or raw_fact_digest is None
            or raw_claim_kind is None
            or raw_claim_kind.strip() == ""
            or raw_source_kind is None
            or raw_source_kind.strip() == ""
            or raw_idempotency_key is None
            or raw_idempotency_key.strip() == ""
            or digest_version != ASSERTION_DIGEST_VERSION
            or context_of_validity is None
        )
        if malformed:
            payload = _malformed_result(
                fact_family_key=fallback_fact_family_key,
            )
            if status not in TERMINAL_PENDING_ASSERTION_STATUSES:
                await bound_connection.execute(  # pyright: ignore[reportUnknownMemberType]
                    """
                    UPDATE pending_assertions
                    SET status = 'rejected',
                        status_reason = $2,
                        rejection_code = $2,
                        conflict_result = $3::jsonb,
                        resolution_attempts = resolution_attempts + 1,
                        last_attempt_at = now()
                    WHERE id = $1
                    """,
                    row["id"],
                    AssertionResolutionReason.MALFORMED_STAGED_ASSERTION.value,
                    json.dumps(payload, sort_keys=True, separators=(",", ":")),
                )
            return StagedAssertionConsumerResult(
                kind="rejected",
                outcome=AssertionResolutionVisibleResult(
                    outcome=AssertionResolutionOutcome.REJECTED,
                    reason=AssertionResolutionReason.MALFORMED_STAGED_ASSERTION,
                    assertion_id=cast(UUID, row["id"]),
                    fact_family_key=fallback_fact_family_key,
                ),
            )

        assert raw_fact_digest is not None
        assert raw_claim_kind is not None
        assert raw_source_kind is not None
        assert raw_idempotency_key is not None
        assert context_of_validity is not None
        candidate = StagedAssertionCandidate(
            id=cast(UUID, row["id"]),
            status=status,
            actor_principal_id=cast(UUID, row["actor_principal_id"]),
            tenant_id=cast(UUID, row["tenant_id"]),
            context_of_validity=context_of_validity,
            claim_kind=raw_claim_kind,
            source_kind=raw_source_kind,
            source_identifier=cast(str | None, row["source_identifier"]),
            model_provider=cast(str | None, row["model_provider"]),
            model_family=cast(str | None, row["model_family"]),
            model_name=cast(str | None, row["model_name"]),
            confidence=cast(float | None, row["confidence"]),
            normalized_fact_digest=raw_fact_digest,
            idempotency_key=raw_idempotency_key,
            digest_version=digest_version,
            created_at=cast(datetime, row["created_at"]),
        )
        return StagedAssertionConsumerResult(kind="candidate", candidate=candidate)

    return await with_principal(principal=principal, connection=connection, fn=_consume)


def build_ranking_signal(
    *,
    candidate: StagedAssertionCandidate,
    principal: Principal,
    corroboration_count: int,
    diverse_corroboration_count: int,
    human_verified: bool = False,
) -> AssertionRankingSignal:
    """Build a content-free ranking snapshot for a staged candidate."""

    actor_kind = principal.kind
    if actor_kind not in ("human", "agent"):
        raise ValueError("ranking_signal_actor_kind_invalid")
    return AssertionRankingSignal(
        actor_kind=actor_kind,
        actor_principal_id=candidate.actor_principal_id,
        source_kind=candidate.source_kind,
        source_identifier=candidate.source_identifier,
        model_provider=candidate.model_provider,
        model_family=candidate.model_family,
        model_name=candidate.model_name,
        asserted_at=candidate.created_at,
        confidence=candidate.confidence,
        corroboration_count=corroboration_count,
        diverse_corroboration_count=diverse_corroboration_count,
        human_verified=human_verified,
    )


def _corroboration_counts_with_candidate(
    *,
    existing_signals: list[AssertionRankingSignal],
    candidate: StagedAssertionCandidate,
) -> tuple[int, int]:
    total_count = len(existing_signals) + 1
    model_families = {signal.model_family for signal in existing_signals if signal.model_family}
    if candidate.model_family:
        model_families.add(candidate.model_family)
    return total_count, len(model_families)


async def record_corroboration(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    candidate: StagedAssertionCandidate,
    canonical_row_kind: str,
    canonical_row_id: UUID,
    human_verified: bool = False,
) -> AssertionCorroborationRecord:
    """Persist or replay a corroboration row for a staged assertion."""

    async def _record(bound_connection: asyncpg.Connection) -> AssertionCorroborationRecord:
        existing_rows = cast(
            list[Any],
            await bound_connection.fetch(  # pyright: ignore[reportUnknownMemberType]
                """
                SELECT ranking_signal
                FROM assertion_corroborations
                WHERE tenant_id = $1
                  AND canonical_row_kind = $2
                  AND canonical_row_id = $3
                """,
                candidate.tenant_id,
                canonical_row_kind,
                canonical_row_id,
            ),
        )
        existing_signals = [
            signal
            for row in existing_rows
            if (signal := _ranking_signal_from_payload(row["ranking_signal"])) is not None
        ]
        corroboration_count, diverse_count = _corroboration_counts_with_candidate(
            existing_signals=existing_signals,
            candidate=candidate,
        )
        ranking_signal = build_ranking_signal(
            candidate=candidate,
            principal=principal,
            corroboration_count=corroboration_count,
            diverse_corroboration_count=diverse_count,
            human_verified=human_verified,
        )
        inserted = cast(
            Any | None,
            await bound_connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                """
                INSERT INTO assertion_corroborations (
                    tenant_id,
                    context_of_validity,
                    canonical_row_kind,
                    canonical_row_id,
                    staged_assertion_id,
                    actor_principal_id,
                    actor_kind,
                    source_kind,
                    source_identifier,
                    model_provider,
                    model_family,
                    model_name,
                    confidence,
                    ranking_signal
                )
                VALUES ($1, $2::jsonb, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13,
                        $14::jsonb)
                ON CONFLICT (tenant_id, staged_assertion_id) DO NOTHING
                RETURNING
                    id,
                    canonical_row_kind,
                    canonical_row_id,
                    staged_assertion_id,
                    ranking_signal,
                    created_at
                """,
                candidate.tenant_id,
                json.dumps(candidate.context_of_validity, sort_keys=True, separators=(",", ":")),
                canonical_row_kind,
                canonical_row_id,
                candidate.id,
                candidate.actor_principal_id,
                principal.kind,
                candidate.source_kind,
                candidate.source_identifier,
                candidate.model_provider,
                candidate.model_family,
                candidate.model_name,
                candidate.confidence,
                _ranking_signal_json(ranking_signal),
            ),
        )
        outcome = AssertionResolutionOutcome.CORROBORATED
        reason = AssertionResolutionReason.NEW_CORROBORATION
        row = inserted
        if row is None:
            row = cast(
                Any | None,
                await bound_connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                    """
                    SELECT
                        id,
                        canonical_row_kind,
                        canonical_row_id,
                        staged_assertion_id,
                        ranking_signal,
                        created_at
                    FROM assertion_corroborations
                    WHERE tenant_id = $1
                      AND staged_assertion_id = $2
                    """,
                    candidate.tenant_id,
                    candidate.id,
                ),
            )
            outcome = AssertionResolutionOutcome.DUPLICATE
            reason = AssertionResolutionReason.EXACT_DUPLICATE
        if row is None:
            raise StagedAssertionNotVisibleError(candidate.id)
        stored_signal = _ranking_signal_from_payload(row["ranking_signal"])
        if stored_signal is None:
            raise ValueError("corroboration_ranking_signal_invalid")
        return AssertionCorroborationRecord(
            id=cast(UUID, row["id"]),
            canonical_row_kind=cast(str, row["canonical_row_kind"]),
            canonical_row_id=cast(UUID, row["canonical_row_id"]),
            staged_assertion_id=cast(UUID, row["staged_assertion_id"]),
            outcome=outcome,
            reason=reason,
            ranking_signal=stored_signal,
            created_at=cast(datetime, row["created_at"]),
        )

    return await with_principal(principal=principal, connection=connection, fn=_record)


def _disagreement_record_from_row(row: Any) -> AssertionDisagreementRecord:
    signal = _ranking_signal_from_payload(row["ranking_signal"])
    if signal is None:
        raise ValueError("disagreement_ranking_signal_invalid")
    return AssertionDisagreementRecord(
        id=cast(UUID, row["id"]),
        current_row_kind=cast(str, row["current_row_kind"]),
        current_row_id=cast(UUID, row["current_row_id"]),
        proposed_row_kind=cast(str, row["proposed_row_kind"]),
        proposed_row_id=cast(UUID | None, row["proposed_row_id"]),
        staged_assertion_id=cast(UUID, row["staged_assertion_id"]),
        outcome=AssertionResolutionOutcome.DISAGREEMENT_QUEUED,
        reason=AssertionResolutionReason.HUMAN_VERIFIED_CONFLICT,
        ranking_signal=signal,
        created_at=cast(datetime, row["created_at"]),
    )


async def queue_human_verified_disagreement(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    candidate: StagedAssertionCandidate,
    current_row_kind: str,
    current_row_id: UUID,
    proposed_row_kind: str,
    proposed_row_id: UUID | None = None,
) -> AssertionDisagreementRecord:
    """Create or reuse an open disagreement for a verified-row conflict."""

    async def _queue(bound_connection: asyncpg.Connection) -> AssertionDisagreementRecord:
        ranking_signal = build_ranking_signal(
            candidate=candidate,
            principal=principal,
            corroboration_count=1,
            diverse_corroboration_count=1 if candidate.model_family else 0,
            human_verified=True,
        )
        row = cast(
            Any | None,
            await bound_connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                """
                WITH existing AS (
                    SELECT
                        id,
                        current_row_kind,
                        current_row_id,
                        proposed_row_kind,
                        proposed_row_id,
                        staged_assertion_id,
                        ranking_signal,
                        created_at
                    FROM assertion_disagreements
                    WHERE tenant_id = $1
                      AND created_by_principal_id = $2
                      AND idempotency_key = $3
                      AND current_row_kind = $4
                      AND current_row_id = $5
                      AND proposed_row_kind = $6
                      AND proposed_row_id IS NOT DISTINCT FROM $7
                      AND status = 'open'
                ),
                inserted AS (
                    INSERT INTO assertion_disagreements (
                        tenant_id,
                        context_of_validity,
                        fact_family_key,
                        current_row_kind,
                        current_row_id,
                        proposed_row_kind,
                        proposed_row_id,
                        staged_assertion_id,
                        idempotency_key,
                        reason_code,
                        ranking_signal,
                        created_by_principal_id
                    )
                    SELECT
                        $1,
                        $8::jsonb,
                        $9,
                        $4,
                        $5,
                        $6,
                        $7,
                        $10,
                        $3,
                        $11,
                        $12::jsonb,
                        $2
                    WHERE NOT EXISTS (SELECT 1 FROM existing)
                    RETURNING
                        id,
                        current_row_kind,
                        current_row_id,
                        proposed_row_kind,
                        proposed_row_id,
                        staged_assertion_id,
                        ranking_signal,
                        created_at
                )
                SELECT *
                FROM inserted
                UNION ALL
                SELECT *
                FROM existing
                LIMIT 1
                """,
                candidate.tenant_id,
                candidate.actor_principal_id,
                candidate.idempotency_key,
                current_row_kind,
                current_row_id,
                proposed_row_kind,
                proposed_row_id,
                json.dumps(candidate.context_of_validity, sort_keys=True, separators=(",", ":")),
                candidate.fact_family_key,
                candidate.id,
                AssertionResolutionReason.HUMAN_VERIFIED_CONFLICT.value,
                _ranking_signal_json(ranking_signal),
            ),
        )
        if row is None:
            raise StagedAssertionNotVisibleError(candidate.id)

        record = _disagreement_record_from_row(row)
        result_payload = {
            "outcome": record.outcome.value,
            "reason": record.reason.value,
            "fact_family_key": candidate.fact_family_key,
            "disagreement_id": str(record.id),
            "current_row_kind": current_row_kind,
            "current_row_id": str(current_row_id),
            "proposed_row_kind": proposed_row_kind,
            "proposed_row_id": None if proposed_row_id is None else str(proposed_row_id),
        }
        await bound_connection.execute(  # pyright: ignore[reportUnknownMemberType]
            """
            UPDATE pending_assertions
            SET status = 'disagreement',
                status_reason = $2,
                conflict_result = $3::jsonb,
                resolution_attempts = resolution_attempts + 1,
                last_attempt_at = now()
            WHERE id = $1
              AND status IN ('staged', 'resolved')
            """,
            candidate.id,
            AssertionResolutionReason.HUMAN_VERIFIED_CONFLICT.value,
            json.dumps(result_payload, sort_keys=True, separators=(",", ":")),
        )
        return record

    return await with_principal(principal=principal, connection=connection, fn=_queue)


def _singleton_result(
    *,
    candidate: StagedAssertionCandidate,
    outcome: AssertionResolutionOutcome,
    reason: AssertionResolutionReason,
    canonical_row_id: UUID | None,
    previous_row_id: UUID | None = None,
    ranking_signal: AssertionRankingSignal | None = None,
) -> AssertionResolutionVisibleResult:
    return AssertionResolutionVisibleResult(
        outcome=outcome,
        reason=reason,
        assertion_id=candidate.id,
        fact_family_key=candidate.fact_family_key,
        canonical_row_kind="node_tag" if canonical_row_id is not None else None,
        canonical_row_id=canonical_row_id,
        previous_row_id=previous_row_id,
        ranking_signal=ranking_signal,
    )


def _active_singleton_head(
    family: Sequence[NodeTagRow],
) -> tuple[NodeTagRow | None, AssertionResolutionReason | None]:
    active = [row for row in family if row.is_active]
    if len(active) == 0:
        return None, None
    if len(active) > 1:
        return None, AssertionResolutionReason.STALE_ACTIVE_HEAD
    return active[0], None


def _node_tag_matches_request(row: NodeTagRow, request: NodeTagApplyRequest) -> bool:
    value = request.value
    return (
        row.value_text == value.value_text
        and row.value_number == value.value_number
        and row.value_boolean == value.value_boolean
        and row.value_reference_node_id == value.value_reference_node_id
        and row.currency == request.currency
    )


async def resolve_node_tag_singleton_supersession(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    repository: NodeTagRepository,
    candidate: StagedAssertionCandidate,
    tag_request: NodeTagApplyRequest,
    context: TagDefinitionServiceContext,
    event_publisher: GraphChangeEventPublisher | None = None,
) -> NodeTagSingletonResolution:
    """Apply a singleton NodeTag candidate with active-family locking.

    This is the T4 resolver-owned mutation primitive. It keeps the public
    endpoint conservative while giving the later accepted-write path a single
    service function that locks the active family, refuses human-verified
    overwrite, inserts the replacement row, and links the previous non-verified
    head through ``superseded_by_tag_id``.
    """

    async def _resolve(_: asyncpg.Connection) -> NodeTagSingletonResolution:
        service = RepositoryNodeTagService(
            repository=repository,
            event_publisher=event_publisher
            or OutboxGraphChangeEventPublisher(connection=connection),
        )
        family = tuple(
            await repository.lock_active_tag_family(
                node_id=tag_request.node_id,
                tag_definition_id=tag_request.tag_definition_id,
            )
        )
        active_head, family_error = _active_singleton_head(family)
        ranking_signal = build_ranking_signal(
            candidate=candidate,
            principal=principal,
            corroboration_count=1,
            diverse_corroboration_count=1 if candidate.model_family else 0,
            human_verified=False,
        )
        if family_error is not None:
            return NodeTagSingletonResolution(
                result=_singleton_result(
                    candidate=candidate,
                    outcome=AssertionResolutionOutcome.RETRYABLE_CONFLICT,
                    reason=family_error,
                    canonical_row_id=None,
                    ranking_signal=ranking_signal,
                )
            )
        if active_head is not None and active_head.is_verified:
            disagreement = await queue_human_verified_disagreement(
                principal=principal,
                connection=connection,
                candidate=candidate,
                current_row_kind="node_tag",
                current_row_id=active_head.id,
                proposed_row_kind="node_tag",
                proposed_row_id=None,
            )
            return NodeTagSingletonResolution(
                result=_singleton_result(
                    candidate=candidate,
                    outcome=AssertionResolutionOutcome.DISAGREEMENT_QUEUED,
                    reason=AssertionResolutionReason.HUMAN_VERIFIED_CONFLICT,
                    canonical_row_id=active_head.id,
                    previous_row_id=active_head.id,
                    ranking_signal=disagreement.ranking_signal,
                ).model_copy(
                    update={
                        "disagreement_id": disagreement.id,
                    }
                ),
                previous_tag=active_head,
            )
        if active_head is not None and _node_tag_matches_request(active_head, tag_request):
            corroboration = await record_corroboration(
                principal=principal,
                connection=connection,
                candidate=candidate,
                canonical_row_kind="node_tag",
                canonical_row_id=active_head.id,
            )
            return NodeTagSingletonResolution(
                result=_singleton_result(
                    candidate=candidate,
                    outcome=AssertionResolutionOutcome.CORROBORATED,
                    reason=corroboration.reason,
                    canonical_row_id=active_head.id,
                    previous_row_id=active_head.id,
                    ranking_signal=corroboration.ranking_signal,
                ),
                previous_tag=active_head,
            )

        new_tag = await service.apply_tag(tag_request, context=context)

        if active_head is None:
            return NodeTagSingletonResolution(
                result=_singleton_result(
                    candidate=candidate,
                    outcome=AssertionResolutionOutcome.ACCEPTED,
                    reason=AssertionResolutionReason.ACCEPTED_NEW_FACT,
                    canonical_row_id=new_tag.id,
                    ranking_signal=ranking_signal,
                ),
                new_tag=new_tag,
            )

        superseded = await service.supersede_tag(
            NodeTagSupersedeRequest(
                superseded_tag_id=active_head.id,
                superseding_tag_id=new_tag.id,
            ),
            context=context,
        )

        return NodeTagSingletonResolution(
            result=_singleton_result(
                candidate=candidate,
                outcome=AssertionResolutionOutcome.SUPERSEDED,
                reason=AssertionResolutionReason.SINGLETON_SUPERSEDED,
                canonical_row_id=new_tag.id,
                previous_row_id=superseded.id,
                ranking_signal=ranking_signal,
            ),
            previous_tag=superseded,
            new_tag=new_tag,
        )

    return await with_principal(principal=principal, connection=connection, fn=_resolve)


async def list_ranked_corroborations(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    canonical_row_kind: str,
    canonical_row_id: UUID,
) -> list[AssertionCorroborationRecord]:
    """Query corroborations visible to ``principal`` in deterministic rank order."""

    async def _list(bound_connection: asyncpg.Connection) -> list[AssertionCorroborationRecord]:
        rows = cast(
            list[Any],
            await bound_connection.fetch(  # pyright: ignore[reportUnknownMemberType]
                """
                SELECT
                    id,
                    canonical_row_kind,
                    canonical_row_id,
                    staged_assertion_id,
                    ranking_signal,
                    created_at
                FROM assertion_corroborations
                WHERE canonical_row_kind = $1
                  AND canonical_row_id = $2
                """,
                canonical_row_kind,
                canonical_row_id,
            ),
        )
        records: list[AssertionCorroborationRecord] = []
        for row in rows:
            signal = _ranking_signal_from_payload(row["ranking_signal"])
            if signal is None:
                continue
            records.append(
                AssertionCorroborationRecord(
                    id=cast(UUID, row["id"]),
                    canonical_row_kind=cast(str, row["canonical_row_kind"]),
                    canonical_row_id=cast(UUID, row["canonical_row_id"]),
                    staged_assertion_id=cast(UUID, row["staged_assertion_id"]),
                    outcome=AssertionResolutionOutcome.CORROBORATED,
                    reason=AssertionResolutionReason.NEW_CORROBORATION,
                    ranking_signal=signal,
                    created_at=cast(datetime, row["created_at"]),
                )
            )
        return sorted(
            records, key=lambda record: ranking_sort_key(record.ranking_signal), reverse=True
        )

    return await with_principal(principal=principal, connection=connection, fn=_list)


def elide_conflict_details(
    result: AssertionResolutionVisibleResult,
) -> AssertionResolutionVisibleResult:
    """Strip row identifiers that are not visible to the current Principal."""

    return result.model_copy(
        update={
            "canonical_row_kind": None,
            "canonical_row_id": None,
            "previous_row_id": None,
            "disagreement_id": None,
            "hidden_detail": True,
            "reason": AssertionResolutionReason.HIDDEN_CONFLICT_DETAIL,
        }
    )


def diverse_model_family_count(signals: list[AssertionRankingSignal]) -> int:
    """Count distinct non-empty model families represented by ranking signals."""

    return len({signal.model_family for signal in signals if signal.model_family})
