"""Leakage-safe recursive graph traversal for Slice 6 read paths.

The service owns the SQL contract for ``POST /graph/traverse``: tenant and
classification predicates are applied in both the seed and recursive CTE
branches, cycle protection happens in Postgres, and truncation is derived only
from visible overscan rows.
"""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from enum import StrEnum
from typing import Any, cast
from uuid import UUID, uuid4

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict, Field, field_validator

from skaldos.graph.edges import (
    ACTIVE_RELATIONSHIP_TYPES,
    RESERVED_RELATIONSHIP_TYPES,
    ClassificationLevel,
    EdgeRelationshipType,
)
from skaldos.graph.read_audit import (
    ReadAuditAction,
    ReadAuditSubjectType,
    ReadAuditWriteError,
    emit_c2_read_audit_entry,
    max_read_classification,
)
from skaldos.middleware import Principal

DEFAULT_TRAVERSAL_DEPTH = 3
MAX_TRAVERSAL_DEPTH = 5
DEFAULT_TRAVERSAL_LIMIT = 100
MAX_TRAVERSAL_LIMIT = 500


class TraversalDirection(StrEnum):
    """Closed traversal direction vocabulary."""

    OUTGOING = "outgoing"
    INCOMING = "incoming"
    BOTH = "both"


class TraversalRequest(BaseModel):
    """Service/public request model for graph traversal."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    seed_node_id: UUID
    tenant_id: UUID
    direction: TraversalDirection = TraversalDirection.OUTGOING
    max_depth: int = Field(default=DEFAULT_TRAVERSAL_DEPTH, ge=1, le=MAX_TRAVERSAL_DEPTH)
    limit: int = Field(default=DEFAULT_TRAVERSAL_LIMIT, ge=1, le=MAX_TRAVERSAL_LIMIT)
    relationship_types: tuple[EdgeRelationshipType, ...] = ()

    @field_validator("relationship_types", mode="before")
    @classmethod
    def _empty_relationship_types_mean_all(cls, value: object) -> object:
        if value is None:
            return ()
        return value

    @field_validator("relationship_types")
    @classmethod
    def _dedupe_relationship_types(
        cls, value: tuple[EdgeRelationshipType, ...]
    ) -> tuple[EdgeRelationshipType, ...]:
        seen: set[EdgeRelationshipType] = set()
        deduped: list[EdgeRelationshipType] = []
        for relationship_type in value:
            if relationship_type in RESERVED_RELATIONSHIP_TYPES:
                raise ValueError("reserved_relationship_type")
            if relationship_type in seen:
                continue
            seen.add(relationship_type)
            deduped.append(relationship_type)
        return tuple(deduped)


class TraversalNode(BaseModel):
    """Visible node projection returned by traversal."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    tenant_id: UUID
    classification: ClassificationLevel
    depth: int = Field(ge=0)
    type_id: UUID
    summary: str | None = None


class TraversalEdge(BaseModel):
    """Visible edge projection returned by traversal."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    tenant_id: UUID
    source_node_id: UUID
    target_node_id: UUID
    relationship_type: EdgeRelationshipType
    classification: ClassificationLevel


class TraversalResult(BaseModel):
    """Leakage-safe traversal response shape."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    seed_node_id: UUID
    tenant_id: UUID
    direction: TraversalDirection
    max_depth: int
    truncated: bool
    nodes: tuple[TraversalNode, ...]
    edges: tuple[TraversalEdge, ...]


class TraversalSeedNotFoundError(LookupError):
    """Seed is absent, hidden, cross-tenant, archived, or over-clearance."""


class TraversalQueryError(RuntimeError):
    """Unexpected storage error while executing traversal."""


TRAVERSAL_SQL = """
WITH RECURSIVE walk AS (
    SELECT
        n.id AS node_id,
        n.tenant_id AS node_tenant_id,
        n.classification AS node_classification,
        n.type_id AS node_type_id,
        n.summary AS node_summary,
        n.context_of_validity AS node_context_of_validity,
        n.created_at AS node_created_at,
        0 AS depth,
        ARRAY[n.id]::uuid[] AS path,
        NULL::uuid AS edge_id,
        NULL::uuid AS edge_tenant_id,
        NULL::uuid AS edge_source_node_id,
        NULL::uuid AS edge_target_node_id,
        NULL::text AS edge_relationship_type,
        NULL::text AS edge_classification
    FROM nodes n
    WHERE n.id = $1
      AND n.tenant_id = $2
      AND n.archived_at IS NULL
      AND app.principal_context_contains(n.context_of_validity)

    UNION ALL

    SELECT
        next_node.id AS node_id,
        next_node.tenant_id AS node_tenant_id,
        next_node.classification AS node_classification,
        next_node.type_id AS node_type_id,
        next_node.summary AS node_summary,
        next_node.context_of_validity AS node_context_of_validity,
        next_node.created_at AS node_created_at,
        walk.depth + 1 AS depth,
        walk.path || next_node.id AS path,
        e.id AS edge_id,
        e.tenant_id AS edge_tenant_id,
        e.source_node_id AS edge_source_node_id,
        e.target_node_id AS edge_target_node_id,
        e.relationship_type AS edge_relationship_type,
        e.classification AS edge_classification
    FROM walk
    JOIN edges e
      ON e.tenant_id = $2
     AND e.archived_at IS NULL
     AND (
        ($3 = 'outgoing' AND e.source_node_id = walk.node_id)
        OR ($3 = 'incoming' AND e.target_node_id = walk.node_id)
        OR ($3 = 'both' AND (e.source_node_id = walk.node_id OR e.target_node_id = walk.node_id))
     )
    JOIN nodes next_node
      ON next_node.id = CASE
          WHEN e.source_node_id = walk.node_id THEN e.target_node_id
          ELSE e.source_node_id
      END
    WHERE walk.depth < $4
      AND ($5::text[] IS NULL OR e.relationship_type = ANY($5::text[]))
      AND app.classification_rank(
            COALESCE(
              app.principal_context() #>> ARRAY['clearances', e.tenant_id::text],
              app.principal_context() ->> 'classification'
            )
          ) >= app.classification_rank(e.classification)
      AND next_node.tenant_id = $2
      AND next_node.archived_at IS NULL
      AND app.principal_context_contains(next_node.context_of_validity)
      AND NOT next_node.id = ANY(walk.path)
),
ranked_nodes AS (
    SELECT DISTINCT ON (node_id)
        node_id,
        node_tenant_id,
        node_classification,
        node_type_id,
        node_summary,
        node_context_of_validity,
        node_created_at,
        depth,
        edge_id,
        edge_tenant_id,
        edge_source_node_id,
        edge_target_node_id,
        edge_relationship_type,
        edge_classification
    FROM walk
    ORDER BY node_id, depth ASC, node_created_at ASC, node_id ASC
)
SELECT
    node_id,
    node_tenant_id,
    node_classification,
    node_type_id,
    node_summary,
    node_context_of_validity,
    depth,
    edge_id,
    edge_tenant_id,
    edge_source_node_id,
    edge_target_node_id,
    edge_relationship_type,
    edge_classification
FROM ranked_nodes
ORDER BY depth ASC, node_created_at ASC, node_id ASC
LIMIT $6;
"""


class TraversalService:
    """Recursive traversal composition over nodes and edges."""

    async def traverse(
        self,
        *,
        connection: asyncpg.Connection,
        principal: Principal,
        request: TraversalRequest,
    ) -> TraversalResult:
        relationship_filter = (
            [relationship_type.value for relationship_type in request.relationship_types]
            if request.relationship_types
            else sorted(relationship_type.value for relationship_type in ACTIVE_RELATIONSHIP_TYPES)
        )
        try:
            rows = cast(
                Sequence[Mapping[str, Any]],
                await connection.fetch(  # pyright: ignore[reportUnknownMemberType]
                    TRAVERSAL_SQL,
                    request.seed_node_id,
                    request.tenant_id,
                    request.direction.value,
                    request.max_depth,
                    relationship_filter,
                    request.limit + 1,
                ),
            )
        except Exception as exc:
            raise TraversalQueryError("traversal_query_failed") from exc

        if not rows:
            raise TraversalSeedNotFoundError("not_found")

        truncated = len(rows) > request.limit
        visible_rows = tuple(rows[: request.limit])
        nodes = tuple(_node_from_row(row) for row in visible_rows)
        edges = tuple(_edge_from_row(row) for row in visible_rows if row["edge_id"] is not None)

        await _emit_traversal_read_audit(
            connection=connection,
            principal=principal,
            request=request,
            nodes=nodes,
            edges=edges,
            seed_context=_context_mapping(visible_rows[0]["node_context_of_validity"]),
        )

        return TraversalResult(
            seed_node_id=request.seed_node_id,
            tenant_id=request.tenant_id,
            direction=request.direction,
            max_depth=request.max_depth,
            truncated=truncated,
            nodes=nodes,
            edges=edges,
        )


def _node_from_row(row: Mapping[str, Any]) -> TraversalNode:
    return TraversalNode(
        id=row["node_id"],
        tenant_id=row["node_tenant_id"],
        classification=ClassificationLevel(row["node_classification"]),
        depth=row["depth"],
        type_id=row["node_type_id"],
        summary=row["node_summary"],
    )


def _edge_from_row(row: Mapping[str, Any]) -> TraversalEdge:
    return TraversalEdge(
        id=row["edge_id"],
        tenant_id=row["edge_tenant_id"],
        source_node_id=row["edge_source_node_id"],
        target_node_id=row["edge_target_node_id"],
        relationship_type=EdgeRelationshipType(row["edge_relationship_type"]),
        classification=ClassificationLevel(row["edge_classification"]),
    )


def _context_mapping(value: object) -> Mapping[str, Any]:
    if isinstance(value, str):
        parsed = json.loads(value)
        if not isinstance(parsed, Mapping):
            raise TraversalQueryError("traversal_query_failed")
        return cast(Mapping[str, Any], parsed)
    if not isinstance(value, Mapping):
        raise TraversalQueryError("traversal_query_failed")
    return cast(Mapping[str, Any], value)


async def _emit_traversal_read_audit(
    *,
    connection: asyncpg.Connection,
    principal: Principal,
    request: TraversalRequest,
    nodes: Sequence[TraversalNode],
    edges: Sequence[TraversalEdge],
    seed_context: Mapping[str, Any],
) -> None:
    classifications = [node.classification for node in nodes]
    classifications.extend(edge.classification for edge in edges)
    max_classification = max_read_classification(classifications)
    if max_classification is None:
        return

    context = dict(seed_context)
    context["classification"] = max_classification.value
    await emit_c2_read_audit_entry(
        connection=connection,
        tenant_id=request.tenant_id,
        actor_principal_id=principal.id,
        subject_type=ReadAuditSubjectType.READ_RESULT_SET,
        subject_id=uuid4(),
        action=ReadAuditAction.TRAVERSE,
        result_classifications=classifications,
        context_of_validity=context,
        metadata={
            "service": "TraversalService",
            "route": "POST /graph/traverse",
            "visible_result_count_bucket": visible_result_count_bucket(len(nodes)),
            "subject_handles": [str(node.id) for node in nodes[:20]],
        },
    )


def visible_result_count_bucket(count: int) -> str:
    if count <= 0:
        return "0"
    if count == 1:
        return "1"
    if count <= 10:
        return "2-10"
    if count <= 100:
        return "11-100"
    return "101+"


__all__ = [
    "DEFAULT_TRAVERSAL_DEPTH",
    "DEFAULT_TRAVERSAL_LIMIT",
    "MAX_TRAVERSAL_DEPTH",
    "MAX_TRAVERSAL_LIMIT",
    "TRAVERSAL_SQL",
    "TraversalDirection",
    "TraversalEdge",
    "TraversalNode",
    "TraversalQueryError",
    "TraversalRequest",
    "TraversalResult",
    "TraversalSeedNotFoundError",
    "TraversalService",
    "ReadAuditWriteError",
    "visible_result_count_bucket",
]
