"""Tag-aware context assembly and first metric query for Slice 6.

This service consumes visible ``node_tags`` joined to source ``nodes`` under
the request's Principal-bound transaction. NodeTag offsets remain the source
of truth for provenance; NodeChunk text is deliberately not consulted here.
"""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from decimal import Decimal
from enum import StrEnum
from typing import Any, Literal, cast
from uuid import UUID, uuid4

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from skaldos.graph.edges import ClassificationLevel
from skaldos.graph.node_tags import substring_by_codepoints
from skaldos.graph.read_audit import (
    ReadAuditAction,
    ReadAuditSubjectType,
    emit_c2_read_audit_entry,
    max_read_classification,
)
from skaldos.graph.tag_definitions import normalize_tag_name
from skaldos.graph.traversal import visible_result_count_bucket
from skaldos.middleware import Principal

DEFAULT_CONTEXT_LIMIT = 20
MAX_CONTEXT_LIMIT = 100
DEFAULT_NEIGHBORHOOD_CHARS = 200
MAX_NEIGHBORHOOD_CHARS = 500
DEFAULT_PROVENANCE_LIMIT = 100
MAX_PROVENANCE_LIMIT = 500


class ContextAssemblyWarning(StrEnum):
    """Safe, content-free context assembly warnings."""

    TRUNCATED_VISIBLE_CONTEXT = "truncated_visible_context"


class MetricWarning(StrEnum):
    """Safe, content-free metric query warnings."""

    MISSING_REQUIRED_CURRENCY_EXCLUDED = "missing_required_currency_excluded"
    TRUNCATED_VISIBLE_PROVENANCE = "truncated_visible_provenance"


class MetricAggregate(StrEnum):
    """First Slice 6 metric aggregate vocabulary."""

    COUNT = "count"
    SUM = "sum"


class MetricFilterOperator(StrEnum):
    """Constrained metric filter operators."""

    EQ = "eq"
    GTE = "gte"
    LTE = "lte"


class MetricFilterField(StrEnum):
    """Allowlisted filter fields for the first metric grammar."""

    CURRENCY = "currency"
    NODE_ID = "node_id"
    VALUE_NUMBER = "value_number"


class ContextAssemblyRequest(BaseModel):
    """Request for assembling visible NodeTag spans into LLM-ready context."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    tenant_id: UUID
    tag_ids: tuple[UUID, ...] = ()
    node_ids: tuple[UUID, ...] = ()
    tag_definition_ids: tuple[UUID, ...] = ()
    limit: int = Field(default=DEFAULT_CONTEXT_LIMIT, ge=1, le=MAX_CONTEXT_LIMIT)
    neighborhood_chars: int = Field(
        default=DEFAULT_NEIGHBORHOOD_CHARS,
        ge=0,
        le=MAX_NEIGHBORHOOD_CHARS,
    )

    @model_validator(mode="after")
    def _requires_a_scope(self) -> ContextAssemblyRequest:
        if not self.tag_ids and not self.node_ids and not self.tag_definition_ids:
            raise ValueError("context_scope_required")
        return self

    @field_validator("tag_ids", "node_ids", "tag_definition_ids")
    @classmethod
    def _dedupe_ids(cls, value: tuple[UUID, ...]) -> tuple[UUID, ...]:
        return tuple(dict.fromkeys(value))


class ContextSource(BaseModel):
    """Visible source handles for one context item."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    node_metadata_source: str | None = None


class ContextItem(BaseModel):
    """One visible tag span plus bounded source neighborhood."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    node_id: UUID
    tag_id: UUID
    tag_definition_id: UUID
    span_offset_start: int
    span_offset_end: int
    exact: str
    prefix: str
    suffix: str
    neighborhood: str
    classification: ClassificationLevel
    context_of_validity: dict[str, Any]
    source: ContextSource
    stale: Literal[False] = False


class ContextBundle(BaseModel):
    """Leakage-safe context assembly response shape."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    query_id: UUID
    tenant_id: UUID
    context_items: tuple[ContextItem, ...]
    provenance: tuple[ContextItem, ...]
    max_visible_classification: ClassificationLevel | None
    truncated: bool
    warnings: tuple[ContextAssemblyWarning, ...] = ()


class MetricFilter(BaseModel):
    """One allowlisted metric predicate."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    field: MetricFilterField
    operator: MetricFilterOperator
    value: str | Decimal | UUID

    @model_validator(mode="after")
    def _validate_operator_for_field(self) -> MetricFilter:
        if (
            self.field in {MetricFilterField.CURRENCY, MetricFilterField.NODE_ID}
            and self.operator is not MetricFilterOperator.EQ
        ):
            raise ValueError("metric_filter_operator_unsupported")
        if self.field is MetricFilterField.VALUE_NUMBER:
            if self.operator is MetricFilterOperator.EQ:
                raise ValueError("metric_filter_operator_unsupported")
            Decimal(str(self.value))
        if self.field is MetricFilterField.CURRENCY:
            value = str(self.value).strip().upper()
            if len(value) != 3 or not value.isalpha():
                raise ValueError("metric_currency_filter_invalid")
        if self.field is MetricFilterField.NODE_ID:
            UUID(str(self.value))
        return self


class MetricQueryRequest(BaseModel):
    """Constrained JSON AST for the first metric query."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    tenant_id: UUID
    aggregate: MetricAggregate
    tag_definition_id: UUID | None = None
    tag_name: str | None = None
    filters: tuple[MetricFilter, ...] = ()
    provenance_limit: int = Field(
        default=DEFAULT_PROVENANCE_LIMIT,
        ge=0,
        le=MAX_PROVENANCE_LIMIT,
    )

    @model_validator(mode="after")
    def _requires_exactly_one_definition_selector(self) -> MetricQueryRequest:
        if (self.tag_definition_id is None) == (self.tag_name is None):
            raise ValueError("metric_tag_definition_selector_required")
        return self


class MetricProvenance(BaseModel):
    """Visible source span backing a metric contributor."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    node_id: UUID
    tag_id: UUID
    span_offset_start: int
    span_offset_end: int
    exact: str
    context_of_validity: dict[str, Any]
    classification: ClassificationLevel


class MetricResult(BaseModel):
    """Visible-only metric response with bounded provenance."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    metric_id: UUID
    tenant_id: UUID
    aggregate: MetricAggregate
    value: Decimal
    unit_or_currency: str | None
    visible_contributor_count: int
    result_classification: ClassificationLevel | None
    provenance: tuple[MetricProvenance, ...]
    truncated: bool
    warnings: tuple[MetricWarning, ...] = ()


class MetricDefinitionNotFoundError(LookupError):
    """Metric tag definition was absent or not visible."""


class MixedCurrencyMetricError(ValueError):
    """Visible metric contributors contain more than one currency."""


class MetricQueryStorageError(RuntimeError):
    """Unexpected database failure while querying visible metric rows."""


class ContextAssemblyService:
    """Assemble context and metrics from visible NodeTag spans."""

    async def assemble_context(
        self,
        *,
        connection: asyncpg.Connection,
        principal: Principal,
        request: ContextAssemblyRequest,
    ) -> ContextBundle:
        rows = await _fetch_context_rows(connection=connection, request=request)
        truncated = len(rows) > request.limit
        visible_rows = tuple(rows[: request.limit])
        items = tuple(
            _context_item_from_row(row, neighborhood_chars=request.neighborhood_chars)
            for row in visible_rows
        )
        max_classification = max_read_classification(item.classification for item in items)
        await _emit_context_read_audit(
            connection=connection,
            principal=principal,
            tenant_id=request.tenant_id,
            items=items,
        )
        return ContextBundle(
            query_id=uuid4(),
            tenant_id=request.tenant_id,
            context_items=items,
            provenance=items,
            max_visible_classification=max_classification,
            truncated=truncated,
            warnings=((ContextAssemblyWarning.TRUNCATED_VISIBLE_CONTEXT,) if truncated else ()),
        )

    async def query_metric(
        self,
        *,
        connection: asyncpg.Connection,
        principal: Principal,
        request: MetricQueryRequest,
    ) -> MetricResult:
        definition = await _resolve_metric_definition(connection, request)
        rows = await _fetch_metric_rows(
            connection=connection,
            request=request,
            tag_definition_id=definition.id,
        )
        valid_rows, warnings = _exclude_missing_required_currency(
            rows,
            requires_currency=definition.requires_currency,
        )
        currency = _single_visible_currency(valid_rows)
        value = _aggregate_metric(request.aggregate, valid_rows)
        classifications = tuple(
            _max_classification(row["node_classification"], row["tag_classification"])
            for row in valid_rows
        )
        result_classification = max_read_classification(classifications)
        truncated = len(valid_rows) > request.provenance_limit
        provenance_rows = tuple(valid_rows[: request.provenance_limit])
        provenance = tuple(_metric_provenance_from_row(row) for row in provenance_rows)
        if truncated:
            warnings = (*warnings, MetricWarning.TRUNCATED_VISIBLE_PROVENANCE)

        await _emit_metric_read_audit(
            connection=connection,
            principal=principal,
            request=request,
            classifications=classifications,
            rows=valid_rows,
        )

        return MetricResult(
            metric_id=uuid4(),
            tenant_id=request.tenant_id,
            aggregate=request.aggregate,
            value=value,
            unit_or_currency=currency,
            visible_contributor_count=len(valid_rows),
            result_classification=result_classification,
            provenance=provenance,
            truncated=truncated,
            warnings=warnings,
        )


class _MetricDefinition(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    requires_currency: bool


VISIBLE_TAG_ROWS_SQL = """
SELECT
    nt.id AS tag_id,
    nt.node_id AS node_id,
    nt.tag_definition_id AS tag_definition_id,
    nt.value_number AS value_number,
    nt.currency AS currency,
    nt.span_offset_start AS span_offset_start,
    nt.span_offset_end AS span_offset_end,
    nt.context_of_validity AS tag_context_of_validity,
    nt.classification AS tag_classification,
    n.body_nfc AS body_nfc,
    n.context_of_validity AS node_context_of_validity,
    n.classification AS node_classification
FROM node_tags nt
JOIN nodes n
  ON n.id = nt.node_id
 AND n.tenant_id = nt.tenant_id
 AND n.archived_at IS NULL
JOIN tag_definitions td
  ON td.id = nt.tag_definition_id
 AND (td.tenant_id = nt.tenant_id OR td.tenant_id IS NULL)
WHERE nt.tenant_id = $1
  AND nt.superseded_by_tag_id IS NULL
  AND NOT (nt.attrs @> '{"stale": true}'::jsonb)
  AND app.principal_context_contains(nt.context_of_validity)
  AND app.principal_context_contains(n.context_of_validity)
  AND app.classification_rank(nt.classification)
      <= app.classification_rank(
           COALESCE(
             (SELECT app.principal_context()) #>> ARRAY['clearances', nt.tenant_id::text],
             (SELECT app.principal_context()) ->> 'classification'
           )
         )
  AND app.classification_rank(n.classification)
      <= app.classification_rank(
           COALESCE(
             (SELECT app.principal_context()) #>> ARRAY['clearances', n.tenant_id::text],
             (SELECT app.principal_context()) ->> 'classification'
           )
         )
  AND app.node_tag_content_digest(
        n.body_nfc_hash,
        nt.span_offset_start,
        nt.span_offset_end
      ) = nt.content_digest
"""


async def _fetch_context_rows(
    *,
    connection: asyncpg.Connection,
    request: ContextAssemblyRequest,
) -> tuple[Mapping[str, Any], ...]:
    filters: list[str] = []
    args: list[Any] = [request.tenant_id]
    if request.tag_ids:
        args.append(list(request.tag_ids))
        filters.append(f"nt.id = ANY(${len(args)}::uuid[])")
    if request.node_ids:
        args.append(list(request.node_ids))
        filters.append(f"nt.node_id = ANY(${len(args)}::uuid[])")
    if request.tag_definition_ids:
        args.append(list(request.tag_definition_ids))
        filters.append(f"nt.tag_definition_id = ANY(${len(args)}::uuid[])")
    args.append(request.limit + 1)
    sql = (
        VISIBLE_TAG_ROWS_SQL
        + (" AND (" + " OR ".join(filters) + ")" if filters else "")
        + f"""
ORDER BY nt.created_at ASC, nt.id ASC
LIMIT ${len(args)}
"""
    )
    try:
        return tuple(
            cast(
                Sequence[Mapping[str, Any]],
                await connection.fetch(sql, *args),  # pyright: ignore[reportUnknownMemberType]
            )
        )
    except Exception as exc:
        raise MetricQueryStorageError("context_assembly_query_failed") from exc


async def _resolve_metric_definition(
    connection: asyncpg.Connection,
    request: MetricQueryRequest,
) -> _MetricDefinition:
    if request.tag_definition_id is not None:
        row = cast(
            Mapping[str, Any] | None,
            await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                """
SELECT id, requires_currency
FROM tag_definitions
WHERE id = $1
  AND tenant_id = $2
  AND lifecycle_state = 'active'
  AND value_type = 'number'
""",
                request.tag_definition_id,
                request.tenant_id,
            ),
        )
    else:
        row = cast(
            Mapping[str, Any] | None,
            await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                """
SELECT id, requires_currency
FROM tag_definitions
WHERE name_canonical = $1
  AND tenant_id = $2
  AND lifecycle_state = 'active'
  AND value_type = 'number'
ORDER BY created_at ASC, id ASC
LIMIT 1
""",
                normalize_tag_name(cast(str, request.tag_name)),
                request.tenant_id,
            ),
        )
    if row is None:
        raise MetricDefinitionNotFoundError("metric_definition_not_found")
    return _MetricDefinition(id=row["id"], requires_currency=bool(row["requires_currency"]))


async def _fetch_metric_rows(
    *,
    connection: asyncpg.Connection,
    request: MetricQueryRequest,
    tag_definition_id: UUID,
) -> tuple[Mapping[str, Any], ...]:
    args: list[Any] = [request.tenant_id, tag_definition_id]
    filter_sql = ["nt.tag_definition_id = $2", "nt.value_number IS NOT NULL"]
    for metric_filter in request.filters:
        filter_sql.append(_metric_filter_sql(metric_filter, args))
    sql = (
        VISIBLE_TAG_ROWS_SQL
        + " AND "
        + " AND ".join(filter_sql)
        + """
ORDER BY abs(nt.value_number) DESC NULLS LAST, nt.created_at ASC, nt.id ASC
"""
    )
    try:
        return tuple(
            cast(
                Sequence[Mapping[str, Any]],
                await connection.fetch(sql, *args),  # pyright: ignore[reportUnknownMemberType]
            )
        )
    except Exception as exc:
        raise MetricQueryStorageError("metric_query_failed") from exc


def _metric_filter_sql(metric_filter: MetricFilter, args: list[Any]) -> str:
    if metric_filter.field is MetricFilterField.CURRENCY:
        args.append(str(metric_filter.value).strip().upper())
        return f"nt.currency = ${len(args)}"
    if metric_filter.field is MetricFilterField.NODE_ID:
        args.append(UUID(str(metric_filter.value)))
        return f"nt.node_id = ${len(args)}"
    args.append(Decimal(str(metric_filter.value)))
    if metric_filter.operator is MetricFilterOperator.GTE:
        return f"nt.value_number >= ${len(args)}"
    if metric_filter.operator is MetricFilterOperator.LTE:
        return f"nt.value_number <= ${len(args)}"
    raise ValueError("metric_filter_operator_unsupported")


def _context_item_from_row(row: Mapping[str, Any], *, neighborhood_chars: int) -> ContextItem:
    body = str(row["body_nfc"])
    start = int(row["span_offset_start"])
    end = int(row["span_offset_end"])
    exact = substring_by_codepoints(body, start, end)
    neighborhood_start = max(0, start - neighborhood_chars)
    neighborhood_end = min(len(body), end + neighborhood_chars)
    return ContextItem(
        node_id=row["node_id"],
        tag_id=row["tag_id"],
        tag_definition_id=row["tag_definition_id"],
        span_offset_start=start,
        span_offset_end=end,
        exact=exact,
        prefix=body[neighborhood_start:start],
        suffix=body[end:neighborhood_end],
        neighborhood=body[neighborhood_start:neighborhood_end],
        classification=_max_classification(row["node_classification"], row["tag_classification"]),
        context_of_validity=_json_object(row["tag_context_of_validity"]),
        source=ContextSource(node_metadata_source="node.body_nfc"),
    )


def _metric_provenance_from_row(row: Mapping[str, Any]) -> MetricProvenance:
    body = str(row["body_nfc"])
    start = int(row["span_offset_start"])
    end = int(row["span_offset_end"])
    return MetricProvenance(
        node_id=row["node_id"],
        tag_id=row["tag_id"],
        span_offset_start=start,
        span_offset_end=end,
        exact=substring_by_codepoints(body, start, end),
        context_of_validity=_json_object(row["tag_context_of_validity"]),
        classification=_max_classification(row["node_classification"], row["tag_classification"]),
    )


def _exclude_missing_required_currency(
    rows: Sequence[Mapping[str, Any]],
    *,
    requires_currency: bool,
) -> tuple[tuple[Mapping[str, Any], ...], tuple[MetricWarning, ...]]:
    if not requires_currency:
        return tuple(rows), ()
    valid_rows = tuple(row for row in rows if row["currency"] is not None)
    warnings = (
        (MetricWarning.MISSING_REQUIRED_CURRENCY_EXCLUDED,) if len(valid_rows) != len(rows) else ()
    )
    return valid_rows, warnings


def _single_visible_currency(rows: Sequence[Mapping[str, Any]]) -> str | None:
    currencies = sorted({str(row["currency"]).strip().upper() for row in rows if row["currency"]})
    if len(currencies) > 1:
        raise MixedCurrencyMetricError("metric_mixed_currency")
    return currencies[0] if currencies else None


def _aggregate_metric(
    aggregate: MetricAggregate,
    rows: Sequence[Mapping[str, Any]],
) -> Decimal:
    if aggregate is MetricAggregate.COUNT:
        return Decimal(len(rows))
    return sum((cast(Decimal, row["value_number"]) for row in rows), Decimal("0"))


def _max_classification(left: object, right: object) -> ClassificationLevel:
    levels = (ClassificationLevel(str(left)), ClassificationLevel(str(right)))
    return max(levels, key=lambda value: value.rank)


def _json_object(value: object) -> dict[str, Any]:
    if isinstance(value, str):
        parsed = json.loads(value)
        if not isinstance(parsed, Mapping):
            raise MetricQueryStorageError("context_shape_invalid")
        return dict(cast(Mapping[str, Any], parsed))
    if not isinstance(value, Mapping):
        raise MetricQueryStorageError("context_shape_invalid")
    return dict(cast(Mapping[str, Any], value))


async def _emit_context_read_audit(
    *,
    connection: asyncpg.Connection,
    principal: Principal,
    tenant_id: UUID,
    items: Sequence[ContextItem],
) -> None:
    if not items:
        return
    max_classification = max_read_classification(item.classification for item in items)
    if max_classification is None:
        return
    context = dict(items[0].context_of_validity)
    context["classification"] = max_classification.value
    await emit_c2_read_audit_entry(
        connection=connection,
        tenant_id=tenant_id,
        actor_principal_id=principal.id,
        subject_type=ReadAuditSubjectType.READ_RESULT_SET,
        subject_id=uuid4(),
        action=ReadAuditAction.ASSEMBLE_CONTEXT,
        result_classifications=[item.classification for item in items],
        context_of_validity=context,
        metadata={
            "service": "ContextAssemblyService",
            "visible_result_count_bucket": visible_result_count_bucket(len(items)),
            "subject_handles": [str(item.tag_id) for item in items[:20]],
        },
    )


async def _emit_metric_read_audit(
    *,
    connection: asyncpg.Connection,
    principal: Principal,
    request: MetricQueryRequest,
    classifications: Sequence[ClassificationLevel],
    rows: Sequence[Mapping[str, Any]],
) -> None:
    max_classification = max_read_classification(classifications)
    if max_classification is None or not rows:
        return
    context = _json_object(rows[0]["tag_context_of_validity"])
    context["classification"] = max_classification.value
    await emit_c2_read_audit_entry(
        connection=connection,
        tenant_id=request.tenant_id,
        actor_principal_id=principal.id,
        subject_type=ReadAuditSubjectType.READ_RESULT_SET,
        subject_id=uuid4(),
        action=ReadAuditAction.QUERY_METRIC,
        result_classifications=classifications,
        context_of_validity=context,
        metadata={
            "service": "MetricQueryService",
            "visible_result_count_bucket": visible_result_count_bucket(len(classifications)),
            "subject_handles": [str(row["tag_id"]) for row in rows[:20]],
        },
    )


__all__ = [
    "ContextAssemblyRequest",
    "ContextAssemblyService",
    "ContextAssemblyWarning",
    "ContextBundle",
    "ContextItem",
    "MetricAggregate",
    "MetricDefinitionNotFoundError",
    "MetricFilter",
    "MetricFilterField",
    "MetricFilterOperator",
    "MetricProvenance",
    "MetricQueryRequest",
    "MetricQueryStorageError",
    "MetricResult",
    "MetricWarning",
    "MixedCurrencyMetricError",
]
