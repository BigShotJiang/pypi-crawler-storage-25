"""Synchronous NodeChunk embedding generation through canonical Shield."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Protocol, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict

from skaldos.graph.transaction import with_principal
from skaldos.middleware import Principal
from skaldos.shield_client import (
    ShieldCallContext,
    build_canonical_shield_request,
    text_message,
)
from skaldos_shield.audit_records import current_audit_trace_context
from skaldos_shield.contracts import (
    CanonicalShieldRequest,
    CanonicalShieldResponse,
    LatencyMode,
    SensitivityTier,
    ShieldMessageRole,
    ShieldResultKind,
    TaskClass,
    TrustedEmbeddingResult,
)

REDACTION_POLICY_VERSION = "shield-strip-v1"
SCANNER_VERSION = "shield-embedding-v1"
EMBEDDING_PII_MODE = "strip"


class NodeChunkEmbeddingGenerationError(RuntimeError):
    """Base error for value-free NodeChunk embedding generation failures."""


class NodeChunkSourceNotVisibleError(NodeChunkEmbeddingGenerationError):
    """Raised when the source node is not visible under the Principal context."""


class NodeChunkShieldEmbeddingUnavailableError(NodeChunkEmbeddingGenerationError):
    """Raised when Shield does not return one redacted embedding result."""


class NodeChunkEmbeddingGenerationResult(BaseModel):
    """Value-free projection of one generated NodeChunk embedding row."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    node_id: UUID
    chunk_id: UUID
    shield_call_id: UUID
    provider: str
    model_id: str
    dimensions: int
    dtype: str


class NodeChunkEmbeddingShieldGateway(Protocol):
    """Internal Shield embedding gateway that preserves in-memory redacted text."""

    async def embed_text(
        self,
        *,
        tenant_id: UUID,
        principal_id: UUID,
        text: str,
    ) -> CanonicalShieldResponse:
        """Return a canonical Shield embedding response without HTTP serialization."""
        ...


class _ShieldCoreResult(Protocol):
    response: CanonicalShieldResponse


class _ShieldCore(Protocol):
    async def complete(self, request: CanonicalShieldRequest) -> _ShieldCoreResult:
        """Execute one in-process Shield call."""
        ...


class InProcessShieldNodeChunkEmbeddingGateway:
    """Call Shield core in-process so excluded provider-safe text stays in memory only."""

    def __init__(self, *, shield_core: _ShieldCore) -> None:
        self._shield_core = shield_core

    async def embed_text(
        self,
        *,
        tenant_id: UUID,
        principal_id: UUID,
        text: str,
    ) -> CanonicalShieldResponse:
        """Embed text through canonical Shield without serializing redacted text."""

        trace_context = current_audit_trace_context()
        result = await self._shield_core.complete(
            build_canonical_shield_request(
                context=ShieldCallContext(
                    tenant_id=tenant_id,
                    principal_id=principal_id,
                    trace_id=trace_context.trace_id,
                    span_id=trace_context.span_id,
                    task_class=TaskClass.EMBEDDING,
                    latency_mode=LatencyMode.BATCH,
                    stream=False,
                    requested_sensitivity=SensitivityTier.PII,
                ),
                messages=(text_message(ShieldMessageRole.USER, text),),
            )
        )
        return result.response


class NodeChunkEmbeddingGenerator:
    """Generate one active redacted chunk and embedding for a visible node."""

    def __init__(self, *, shield_gateway: NodeChunkEmbeddingShieldGateway) -> None:
        self._shield_gateway = shield_gateway

    async def generate_for_node(
        self,
        *,
        principal: Principal,
        connection: asyncpg.Connection,
        node_id: UUID,
    ) -> NodeChunkEmbeddingGenerationResult:
        """Read a visible node, embed through Shield strip mode, then write cache row."""

        async def _read(bound_connection: asyncpg.Connection) -> Mapping[str, Any]:
            return await _read_visible_source_node(
                bound_connection,
                node_id=node_id,
            )

        source = await with_principal(principal=principal, connection=connection, fn=_read)
        response = await self._shield_gateway.embed_text(
            tenant_id=cast(UUID, source["tenant_id"]),
            principal_id=principal.id,
            text=str(source["body"]),
        )
        result = _require_single_redacted_embedding(response.result)
        route = response.route
        if route is None:
            raise NodeChunkShieldEmbeddingUnavailableError("node_chunk_embedding_route_missing")
        if (
            route.embedding_dimensions is not None
            and result.dimensions != route.embedding_dimensions
        ):
            raise NodeChunkShieldEmbeddingUnavailableError(
                "node_chunk_embedding_dimension_mismatch"
            )
        if route.embedding_dtype is not None and result.dtype != route.embedding_dtype:
            raise NodeChunkShieldEmbeddingUnavailableError("node_chunk_embedding_dtype_mismatch")

        safe_body = result.provider_safe_texts[0]
        vector = result.vectors[0]

        async def _write(
            bound_connection: asyncpg.Connection,
        ) -> NodeChunkEmbeddingGenerationResult:
            chunk_id = await _replace_node_chunk(
                bound_connection,
                source=source,
                safe_body=safe_body,
                vector=vector,
                provider=route.provider,
                model_id=route.model_id,
                dimensions=result.dimensions,
                dtype=result.dtype,
                source_offset_end=cast(int, source["source_offset_end"]),
            )
            return NodeChunkEmbeddingGenerationResult(
                node_id=node_id,
                chunk_id=chunk_id,
                shield_call_id=response.call_id,
                provider=route.provider,
                model_id=route.model_id,
                dimensions=result.dimensions,
                dtype=result.dtype,
            )

        return await with_principal(principal=principal, connection=connection, fn=_write)


def _require_single_redacted_embedding(result: object) -> TrustedEmbeddingResult:
    if not isinstance(result, TrustedEmbeddingResult):
        raise NodeChunkShieldEmbeddingUnavailableError("node_chunk_embedding_missing")
    if result.kind is not ShieldResultKind.EMBEDDING:
        raise NodeChunkShieldEmbeddingUnavailableError("node_chunk_embedding_missing")
    if len(result.vectors) != 1 or len(result.provider_safe_texts) != 1:
        raise NodeChunkShieldEmbeddingUnavailableError("node_chunk_embedding_invalid_count")
    if not result.provider_safe_texts[0].strip():
        raise NodeChunkShieldEmbeddingUnavailableError("node_chunk_embedding_empty_redacted_text")
    return result


async def _read_visible_source_node(
    connection: asyncpg.Connection,
    *,
    node_id: UUID,
) -> Mapping[str, Any]:
    row = cast(
        Mapping[str, Any] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
SELECT
    n.id,
    n.tenant_id,
    n.body_nfc AS body,
    char_length(n.body_nfc) AS source_offset_end,
    n.classification,
    n.body_nfc_hash
FROM nodes n
WHERE n.id = $1
  AND n.tenant_id = ANY ((SELECT app.principal_visible())::uuid[])
  AND n.archived_at IS NULL
  AND app.principal_context_contains(n.context_of_validity)
  AND app.classification_rank(
        COALESCE(
          app.principal_context() #>> ARRAY['clearances', n.tenant_id::text],
          app.principal_context() ->> 'classification'
        )
      ) >= app.classification_rank(n.classification)
""",
            node_id,
        ),
    )
    if row is None:
        raise NodeChunkSourceNotVisibleError("node_chunk_source_not_visible")
    return row


async def _replace_node_chunk(
    connection: asyncpg.Connection,
    *,
    source: Mapping[str, Any],
    safe_body: str,
    vector: list[float],
    provider: str,
    model_id: str,
    dimensions: int,
    dtype: str,
    source_offset_end: int,
) -> UUID:
    await connection.execute(  # pyright: ignore[reportUnknownMemberType]
        """
UPDATE node_chunks
   SET generation_status = 'stale',
       invalidated_at = COALESCE(invalidated_at, now())
 WHERE tenant_id = $1
   AND node_id = $2
   AND document_id IS NULL
   AND generation_status IN ('building', 'complete')
   AND invalidated_at IS NULL
""",
        source["tenant_id"],
        source["id"],
    )
    row = cast(
        Mapping[str, Any] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
INSERT INTO node_chunks (
    tenant_id,
    node_id,
    generation_id,
    chunk_index,
    offset_start,
    offset_end,
    body,
    embedding,
    embedding_provider,
    embedding_model_id,
    embedding_dimensions,
    embedding_dtype,
    embedding_pii_mode,
    classification,
    derives_from_hash,
    redaction_policy_version,
    scanner_version,
    generation_status
)
VALUES (
    $1,
    $2,
    uuidv7(),
    0,
    0,
    $4,
    $3,
    $5::halfvec,
    $6::bifrost_provider,
    $7,
    $8,
    $9,
    'strip',
    $10,
    $11,
    $12,
    $13,
    'complete'
)
RETURNING id
""",
            source["tenant_id"],
            source["id"],
            safe_body,
            source_offset_end,
            _halfvec_literal(vector),
            provider,
            model_id,
            dimensions,
            dtype,
            source["classification"],
            source["body_nfc_hash"],
            REDACTION_POLICY_VERSION,
            SCANNER_VERSION,
        ),
    )
    if row is None:
        raise NodeChunkEmbeddingGenerationError("node_chunk_embedding_insert_failed")
    return cast(UUID, row["id"])


def _halfvec_literal(vector: list[float]) -> str:
    return "[" + ",".join(str(float(value)) for value in vector) + "]"


__all__ = [
    "EMBEDDING_PII_MODE",
    "InProcessShieldNodeChunkEmbeddingGateway",
    "NodeChunkEmbeddingGenerationError",
    "NodeChunkEmbeddingGenerationResult",
    "NodeChunkEmbeddingGenerator",
    "NodeChunkEmbeddingShieldGateway",
    "NodeChunkShieldEmbeddingUnavailableError",
    "NodeChunkSourceNotVisibleError",
    "REDACTION_POLICY_VERSION",
    "SCANNER_VERSION",
]
