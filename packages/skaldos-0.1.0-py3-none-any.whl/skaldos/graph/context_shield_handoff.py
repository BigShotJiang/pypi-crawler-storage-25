"""Shield handoff for answering from an assembled Slice 6 context bundle."""

from __future__ import annotations

from enum import StrEnum
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator

from skaldos.graph.context_assembly import ContextBundle
from skaldos.graph.edges import ClassificationLevel
from skaldos.shield_client import ShieldCallContext, ShieldClient, text_message
from skaldos_shield.contracts import (
    LatencyMode,
    ModelHint,
    PolicyOutcome,
    RouteCapability,
    SensitivityTier,
    ShieldMessageRole,
    ShieldResultKind,
    TaskClass,
    effective_sensitivity,
)


class ContextShieldFailureReason(StrEnum):
    """Content-free non-answer reasons for context Q&A handoff."""

    SHIELD_POLICY_BLOCKED = "shield_policy_blocked"
    SHIELD_NO_ANSWER = "shield_no_answer"
    SHIELD_UNSUPPORTED_RESULT = "shield_unsupported_result"


class ContextShieldHandoffRequest(BaseModel):
    """Caller-supplied question and explicit Shield call metadata."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    question: str = Field(min_length=1, max_length=8000)
    tenant_id: UUID
    principal_id: UUID
    requested_sensitivity: SensitivityTier | None = None
    trace_id: str | None = Field(default=None, pattern=r"^[0-9a-f]{32}$")
    span_id: str | None = Field(default=None, pattern=r"^[0-9a-f]{16}$")

    @field_validator("question")
    @classmethod
    def _question_not_blank(cls, value: str) -> str:
        if value.strip() == "":
            raise ValueError("question_required")
        return value


class ContextShieldAnswer(BaseModel):
    """Trusted answer metadata returned from Shield."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    kind: Literal["answer"] = "answer"
    answer: str
    shield_call_id: UUID
    trace_id: str | None = None


class ContextShieldNonAnswer(BaseModel):
    """Typed non-answer when Shield does not return a trusted assistant message."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    kind: Literal["non_answer"] = "non_answer"
    reason_code: ContextShieldFailureReason
    shield_call_id: UUID
    trace_id: str | None = None


ContextShieldResult = ContextShieldAnswer | ContextShieldNonAnswer


class ContextShieldHandoffService:
    """Submit assembled visible context to canonical Shield without fallback."""

    def __init__(self, shield_client: ShieldClient) -> None:
        self._shield_client = shield_client

    async def answer_from_context(
        self,
        *,
        context_bundle: ContextBundle,
        request: ContextShieldHandoffRequest,
    ) -> ContextShieldResult:
        """Return a Shield answer or typed non-answer for the assembled context."""

        response = await self._shield_client.complete(
            context=ShieldCallContext(
                tenant_id=request.tenant_id,
                principal_id=request.principal_id,
                task_class=TaskClass.CHAT,
                latency_mode=LatencyMode.SYNC,
                stream=False,
                requested_sensitivity=effective_sensitivity(
                    _sensitivity_for_classification(context_bundle.max_visible_classification),
                    request.requested_sensitivity,
                ),
                trace_id=request.trace_id,
                span_id=request.span_id,
                model_hint=ModelHint(capabilities=frozenset({RouteCapability.CHAT})),
            ),
            messages=(
                text_message(
                    ShieldMessageRole.SYSTEM,
                    "Answer using only the provided visible SkaldOS context. "
                    "If the context is insufficient, say that no answer is available.",
                ),
                text_message(ShieldMessageRole.USER, _user_prompt(context_bundle, request)),
            ),
        )

        if response.policy_outcome is not PolicyOutcome.PASSED:
            return ContextShieldNonAnswer(
                reason_code=ContextShieldFailureReason.SHIELD_POLICY_BLOCKED,
                shield_call_id=response.call_id,
                trace_id=response.trace_id or request.trace_id,
            )
        if response.result is None:
            return ContextShieldNonAnswer(
                reason_code=ContextShieldFailureReason.SHIELD_NO_ANSWER,
                shield_call_id=response.call_id,
                trace_id=response.trace_id or request.trace_id,
            )
        if response.result.kind is not ShieldResultKind.MESSAGE:
            return ContextShieldNonAnswer(
                reason_code=ContextShieldFailureReason.SHIELD_UNSUPPORTED_RESULT,
                shield_call_id=response.call_id,
                trace_id=response.trace_id or request.trace_id,
            )

        for message in response.result.messages:
            if message.role is ShieldMessageRole.ASSISTANT:
                text = "\n".join(
                    part.text for part in message.parts if part.text is not None
                ).strip()
                if text:
                    return ContextShieldAnswer(
                        answer=text,
                        shield_call_id=response.call_id,
                        trace_id=response.trace_id or request.trace_id,
                    )
        return ContextShieldNonAnswer(
            reason_code=ContextShieldFailureReason.SHIELD_NO_ANSWER,
            shield_call_id=response.call_id,
            trace_id=response.trace_id or request.trace_id,
        )


def _user_prompt(context_bundle: ContextBundle, request: ContextShieldHandoffRequest) -> str:
    context_lines = [
        f"[{index}] node_id={item.node_id} tag_id={item.tag_id}\n{item.neighborhood}"
        for index, item in enumerate(context_bundle.context_items, start=1)
    ]
    return "\n\n".join(
        (
            f"question:\n{request.question.strip()}",
            "visible_context:",
            "\n\n".join(context_lines) if context_lines else "(none)",
        )
    )


def _sensitivity_for_classification(
    classification: ClassificationLevel | None,
) -> SensitivityTier:
    if classification in {ClassificationLevel.C4}:
        return SensitivityTier.PII_STRICT
    if classification in {ClassificationLevel.C2, ClassificationLevel.C3}:
        return SensitivityTier.PII
    return SensitivityTier.NON_PII


__all__ = [
    "ContextShieldAnswer",
    "ContextShieldFailureReason",
    "ContextShieldHandoffRequest",
    "ContextShieldHandoffService",
    "ContextShieldNonAnswer",
    "ContextShieldResult",
]
