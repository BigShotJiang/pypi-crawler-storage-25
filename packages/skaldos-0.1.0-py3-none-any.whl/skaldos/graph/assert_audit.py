"""Audit emission helpers for ``POST /graph/assert``.

The assertion route owns request validation and policy resolution. This module
owns the narrow durable insert into ``audit_entries`` once the route has a
resolved actor, subject, action, intent, context, and policy metadata.

References: Slice 4 ``audit-and-outbox-emission`` T2; §13.2, §13.4,
``ARCHITECTURE.md`` §2.1, PC13, AP11.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from enum import StrEnum
from typing import Any, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict

from skaldos.policy.assertion_authorization import (
    AssertionPolicyDecision,
    AssertionPolicyEvaluationMetadata,
)


class AuditOutcome(StrEnum):
    """Database-backed audit outcome vocabulary."""

    PERMITTED = "permitted"
    DENIED = "denied"
    ERROR = "error"


class AssertionAuditEntry(BaseModel):
    """Projection returned after writing an audit entry."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    row_hash: bytes


async def emit_assertion_audit_entry(
    *,
    connection: asyncpg.Connection,
    policy: AssertionPolicyDecision | AssertionPolicyEvaluationMetadata,
    context_of_validity: Mapping[str, Any],
    outcome: AuditOutcome,
    reason_code: str | None = None,
) -> AssertionAuditEntry:
    """Insert one content-free audit row for a resolved assertion decision."""

    metadata = _policy_metadata(policy=policy, outcome=outcome, reason_code=reason_code)
    row = cast(
        Mapping[str, Any] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
        INSERT INTO audit_entries (
            tenant_id,
            actor_principal_id,
            subject_type,
            subject_id,
            action,
            intent,
            context_of_validity,
            outcome,
            policy_decision_metadata
        )
        VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb, $8, $9::jsonb)
        RETURNING id, row_hash
        """,
            policy.tenant_id,
            policy.principal_id,
            policy.subject_type.value,
            policy.subject_id,
            policy.action,
            policy.intent.value,
            json.dumps(dict(context_of_validity), sort_keys=True),
            outcome.value,
            json.dumps(metadata, sort_keys=True),
        ),
    )
    if row is None:
        raise RuntimeError("audit_entry_insert_returned_no_row")
    return AssertionAuditEntry(
        id=row["id"],  # pyright: ignore[reportUnknownArgumentType]
        row_hash=bytes(row["row_hash"]),  # pyright: ignore[reportUnknownArgumentType]
    )


def _policy_metadata(
    *,
    policy: AssertionPolicyDecision | AssertionPolicyEvaluationMetadata,
    outcome: AuditOutcome,
    reason_code: str | None,
) -> dict[str, Any]:
    metadata = policy.model_dump(mode="json", exclude_none=True)
    metadata["outcome"] = outcome.value
    if reason_code is not None:
        metadata["reason_code"] = reason_code
    return metadata
