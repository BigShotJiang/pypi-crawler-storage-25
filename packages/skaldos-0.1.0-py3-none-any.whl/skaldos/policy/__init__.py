"""Authorization policy package for SkaldOS v2 (Slice 2).

Per ``docs/slices/slice-2-authorization/policy-module-and-chokepoint/``
``03-technical-implementation.md`` § "Module layout":

This package is the FastAPI adapter + Oso host for the ``can()``
chokepoint. It is designed to be imported standalone (by agents and
tools that call ``await authorize(...)`` directly) as well as wired
into the FastAPI dependency graph (``Depends(authorize(...))``).

Usage::

    from skaldos.policy import authorize, AuthorizationError, Intent, PROTECTED_ROUTE_RESPONSES

Module layout (each module carries a ``# wired in T<N>`` marker until
the implementing task lands):

- :mod:`skaldos.policy.subjects` --- ``AppSubject`` StrEnum + Pydantic
  row models for the authorization subject vocabulary. **Wired in
  subject T1.**
- :mod:`skaldos.policy.loaders` --- ``SubjectLoader`` Protocol +
  subject loader functions. **Wired in subject T2.**
- :mod:`skaldos.policy.resolvers` --- ``role_in_org`` host resolver +
  ``register_resolvers`` seam. **Wired in subject T3 (this PR).**
- :mod:`skaldos.policy.host` --- Oso instance; ``load_files()`` at
  module init. **Wired in engine T7 (this PR).**
- :mod:`skaldos.policy.authorize` --- ``Depends``-compatible factory +
  exception handlers. **Wired in engine T7 (this PR).**
- :mod:`skaldos.policy.intent` --- ``Intent`` enum (Searle's 5);
  ``ALLOWED_INTENTS`` table. **Wired in engine T6.**
- :mod:`skaldos.policy.errors` --- ``AuthorizationError`` + reason
  codes. **Wired in engine T7 (this PR).**
- :mod:`skaldos.policy.responses` --- OpenAPI response shapes. **Wired
  in engine T7 (this PR).**
- :mod:`skaldos.policy.pool` --- ``app_chokepoint`` pool lifecycle.
  **Wired by engine T4 (PR #<this PR>); see policy/pool.py.**
- :mod:`skaldos.policy.hooks` --- ``authorize_pre_hook`` mount point.
  **Wired in engine T8 (this PR).**

Subject T1 exports:

- :class:`AppSubject` --- the closed ``StrEnum`` of authorization
  subjects (``Organization``, ``Membership``, ``Node``, ``OrgConfig``,
  ``Delegation``, ``EventSubscription``).
- :class:`Subject` --- the discriminated union type alias over the
  row models.
- :class:`OrganizationRow`, :class:`MembershipRow`, :class:`NodeRow`,
  :class:`OrgConfigRow`, :class:`DelegationRow`,
  :class:`EventSubscriptionRow` --- per-subject
  Pydantic row models consumed by Polar policies and the authorization
  chokepoint. ``OrgConfig`` and ``Delegation`` are scaffold-now-wire-later
  (Slice 7 wires their loaders + handlers).

Subject T2 exports:

- :class:`SubjectLoader` --- runtime-checkable Protocol for subject
  loaders.  Signature: ``async (id, principal, conn) -> SubjectRow | None``.
  Engine T7's ``Depends(authorize)`` accepts any callable that satisfies
  this Protocol.
- :func:`load_organization_by_id` --- SELECT against ``tenants``; returns
  :class:`OrganizationRow` | ``None``.
- :func:`load_membership_by_id` --- SELECT against ``memberships``; returns
  :class:`MembershipRow` | ``None``.
- :func:`load_node_by_id` --- scaffold-now-wire-later (Slice 3); SELECT
  against ``nodes`` (table not yet created in Slice 2).
- :func:`load_org_config_by_id` --- stub raising ``NotImplementedError``
  (Slice 7).
- :func:`load_delegation_by_id` --- stub raising ``NotImplementedError``
  (Slice 7).

Subject T3 exports (PR #113):

- :func:`~skaldos.policy.resolvers.role_in_org` --- the async Polar host
  resolver that tests whether a principal holds a given role in an
  organization.  Called by Oso during ``has_role_in_org`` evaluation.
- :func:`~skaldos.policy.resolvers.register_resolvers` --- the seam
  engine T7 calls at Oso host construction time to register all Polar
  host resolvers.  Signature: ``register_resolvers(host: Oso) -> None``.

Engine T8 exports (this PR):

- :data:`AuthorizePreHook` --- type alias for the pre-hook callable.
  Signature: ``async (request: Request, principal: Principal) -> None``.
  The rate-limiter peer feature registers at priority 1 (§14.7).
- :func:`register_authorize_pre_hook` --- register a pre-hook on
  ``app.state.authorize_pre_hooks``.  Parameters: ``(app, hook, *,
  priority: int)``.  Lower priority = earlier execution.  Rate-limit
  reserves priority 1; future hooks declare higher numbers.
- :func:`get_authorize_pre_hooks` --- return registered pre-hooks in
  ascending priority order.  Returns empty list when no hooks registered.

Engine T7 exports (this PR):

- :func:`authorize` --- the FastAPI ``Depends``-compatible factory.
  Returns ``Depends(_inner)`` where ``_inner`` is the per-request
  authorization chokepoint.  Signature:
  ``authorize(action, subject_kind, intent=None, subject_loader=None,
  target_tenant_loader=None) -> Depends``.
- :class:`AuthorizationError` --- base authorization exception.
- :class:`IntentRequiredError` --- raised when a write route requires
  intent but the caller omits it.  Maps to 422.
- :class:`IntentNotAllowedError` --- raised when the supplied intent is
  not in ``ALLOWED_INTENTS``.  Maps to 422.
- :class:`SubjectNotFoundError` --- raised when ``subject_loader``
  returns ``None``.  Maps to 404.
- :class:`ReasonCode` --- closed ``StrEnum`` of denial reason codes
  (7 members).
- :data:`PROTECTED_ROUTE_RESPONSES` --- ``dict[int|str, dict]`` floor
  for every protected route's ``responses=`` kwarg.
- :class:`AuthorizationErrorResponse` --- Pydantic model for 403 body.
- :class:`IntentErrorResponse` --- Pydantic model for 422 body.
- :func:`register_authorization_exception_handlers` --- wire the
  exception → HTTP-status mappings onto a :class:`fastapi.FastAPI`
  instance.
- :func:`get_oso` --- return the process-scoped Oso host singleton.

Public surface:

    from skaldos.policy import authorize, AuthorizationError, Intent, PROTECTED_ROUTE_RESPONSES

References: §4.1 (authorization is a primitive); §4.5 (subject-derived
ownership); ADR 2 (Oso); §10.2 (OpenAPI 3.1); §10.12 (intent); MP1
(primitives over subsystems); MP3 (honest naming); AP5 (no bypass);
``03-technical-implementation.md`` § "Module layout".
"""

from skaldos.policy.assertion_authorization import (
    AssertionAuthorizationReason,
    AssertionPolicyDecision,
    AssertionPolicyDeniedError,
    AssertionPolicyEvaluationError,
    AssertionPolicyEvaluationMetadata,
    AssertionSubjectDerivation,
    AssertionSubjectDerivationError,
    authorize_assertion_intent,
    derive_assertion_subject,
)
from skaldos.policy.authorize import (
    AuthorizeMeta,
    authorize,
    register_authorization_exception_handlers,
)
from skaldos.policy.errors import (
    AuthorizationError,
    IntentNotAllowedError,
    IntentRequiredError,
    PolicyEvaluationError,
    ReasonCode,
    SubjectNotFoundError,
)
from skaldos.policy.hooks import (
    AuthorizePreHook,
    get_authorize_pre_hooks,
    register_authorize_pre_hook,
)
from skaldos.policy.host import get_oso
from skaldos.policy.intent import (
    ALLOWED_INTENTS,
    INTENT_TO_ACTION,
    ActionLiteral,
    IncompatibleIntentError,
    Intent,
    action_for_intent,
)
from skaldos.policy.loaders import (
    SubjectLoader,
    load_delegation_by_id,
    load_event_subscription_by_id,
    load_membership_by_id,
    load_node_by_id,
    load_org_config_by_id,
    load_organization_by_id,
)
from skaldos.policy.resolvers import (
    register_resolvers,  # pyright: ignore[reportUnknownVariableType]
    role_in_org,
)
from skaldos.policy.responses import (
    PROTECTED_ROUTE_RESPONSES,
    AuthorizationErrorResponse,
    IntentErrorResponse,
    PolicyEvaluationErrorResponse,
)
from skaldos.policy.subjects import (
    AppSubject,
    ConversationRow,
    DelegationRow,
    EventSubscriptionRow,
    MembershipRow,
    NodeRow,
    OrganizationRow,
    OrgConfigRow,
    Subject,
)

__all__ = [
    # engine T8 — pre-hook mount point
    "AuthorizePreHook",
    "get_authorize_pre_hooks",
    "register_authorize_pre_hook",
    # engine T7 — Oso host
    "get_oso",
    # engine T7 — authorize factory + exception handlers
    "authorize",
    "AuthorizeMeta",
    "register_authorization_exception_handlers",
    # Slice 4 assertion-specific dynamic policy service
    "AssertionAuthorizationReason",
    "AssertionPolicyDecision",
    "AssertionPolicyDeniedError",
    "AssertionPolicyEvaluationError",
    "AssertionPolicyEvaluationMetadata",
    "AssertionSubjectDerivation",
    "AssertionSubjectDerivationError",
    "authorize_assertion_intent",
    "derive_assertion_subject",
    # engine T7 — errors + reason codes
    "AuthorizationError",
    "IntentNotAllowedError",
    "IntentRequiredError",
    "PolicyEvaluationError",
    "ReasonCode",
    "SubjectNotFoundError",
    # engine T7 — OpenAPI response shapes
    "PROTECTED_ROUTE_RESPONSES",
    "AuthorizationErrorResponse",
    "IntentErrorResponse",
    "PolicyEvaluationErrorResponse",
    # engine T6 — intent table
    "ALLOWED_INTENTS",
    "INTENT_TO_ACTION",
    "ActionLiteral",
    "IncompatibleIntentError",
    "Intent",
    "action_for_intent",
    # subject T1 — subject vocabulary
    "AppSubject",
    "ConversationRow",
    "DelegationRow",
    "EventSubscriptionRow",
    "MembershipRow",
    "NodeRow",
    "OrganizationRow",
    "OrgConfigRow",
    "Subject",
    # subject T2 — subject loaders
    "SubjectLoader",
    "load_delegation_by_id",
    "load_event_subscription_by_id",
    "load_membership_by_id",
    "load_node_by_id",
    "load_org_config_by_id",
    "load_organization_by_id",
    # subject T3 — host resolvers
    "register_resolvers",
    "role_in_org",
]
