"""``Intent`` enum (Searle's five) + ``ALLOWED_INTENTS`` table.

**Wired by engine T6 (PR #<this PR>).**

Per ``docs/slices/slice-2-authorization/policy-module-and-chokepoint/``
``03-technical-implementation.md`` § "Module layout" → ``intent.py``:

    ``Intent(StrEnum)`` with the five Searle members; ``.value`` is
    the lower-kebab string the ``.polar`` files compare via
    ``intent.value = "..."``.

    ``ALLOWED_INTENTS: dict[tuple[ActionLiteral, AppSubject], frozenset[Intent]]``
    --- populated for the Slice 2 subject set; entries for read actions
    are absent (intent not required).

Design decisions
----------------

**Intent StrEnum values are lower-kebab strings matching Searle's taxonomy.**
The ``.polar`` files compare against these strings
(``intent.value = "assertive"``, etc.); an uppercase or CamelCase value
would silently break Polar rules (F8 in ``03``).  Lower-kebab is the
canonical wire format per §10.12.

**Read actions are absent from ALLOWED_INTENTS.**
Intent is only required for write operations.  A ``"read"`` key in the
table would imply intent is validated on reads; absent means "no intent
gate applies."  The startup validation hook (``validate_intent_table_consistency``)
treats absent as "no gate" and does not fail on read-only routes.

**ALLOWED_INTENTS key set covers the five Slice 2 subjects.**
Mappings documented below; where ``03-technical-implementation.md`` and
``02-edge-cases.md`` do not pin a specific intent for a given
(action, subject) pair, the mapping uses the most defensible Searle
category:

- ``create``: The actor declares something new exists → ``declarative``
  is possible, but most creates are factual assertions about the world
  (a node, a membership record).  We use ``{assertive}`` unless the
  semantics of the subject demand authority-change (e.g. org config
  commits).  Delegation creates are ``commissive`` (a commitment to
  delegate), OrgConfig declares → ``{declarative}``.
- ``update``: Mutating existing state is an assertion about the world's
  new state → ``{assertive}``.  OrgConfig updates require authority
  (role-assignment, config commit) → ``{declarative}``.
- ``archive``: Removing / retiring a resource is a status-transition act
  requiring authority → ``{declarative}``.
- ``assert``: The explicit graph-assert verb (§10.5, Slice 4+) maps to
  ``{assertive}`` for all subjects.
- ``declare``: Formal state-change by authority → ``{declarative}``
  for all subjects.
- ``direct``: Issue a task / supervision request → ``{directive}`` for
  all subjects.  The intent table defines the speech-act type; the Polar
  policy restricts which principals can actually issue the directive against
  each subject kind.
- ``commit``: Schedule/commit an intent declaration → ``{commissive}``.
- ``express``: Feedback / reaction → ``{expressive}``.
- ``revoke``: Authority-required removal → ``{declarative}``.
- ``pause`` / ``resume``: Capability lifecycle — status transitions by
  authority → ``{declarative}``.

**Scaffold-now-wire-later subjects (OrgConfig, Delegation).**
Their entries are populated now so the startup hook validates correctly
when loaders and Polar files arrive in Slice 7.  Keys are present;
entries are defensible but may be refined via a dated delta to
``substrate-constraints.md`` when Slice 7 lands.

**IncompatibleIntentError is a startup failure, not a 4xx.**
A route that declares an intent outside its subject's allowed set is a
developer error, not a caller error.  The app refuses to start rather
than serving a route that would always 422. (F3 in ``03``.)

**validate_intent_table_consistency runs at startup on the empty-app case.**
When no ``Depends(authorize(...))`` routes exist (T6 ships before T7),
the function walks routes, finds none carrying ``authorize``, and returns
immediately.  No false positives.

References: §10.12 (intent is required on writes; rejected with 422 if
missing or unrecognized); M14 (intent is the missing speech-act type);
``03-technical-implementation.md`` § F3 (startup-time validation, not
runtime), § F8 (string values for Polar comparisons);
``02-edge-cases.md`` § E7 (intent declared at route registration but
subject doesn't accept it).
"""

from __future__ import annotations

from enum import StrEnum
from typing import Literal, get_args

from fastapi import FastAPI

from skaldos.policy.subjects import AppSubject

# ---------------------------------------------------------------------------
# Intent enum — Searle's five illocutionary act types (§10.12).
# ---------------------------------------------------------------------------


class Intent(StrEnum):
    """Fixed Searle-derived enum for the ``intent`` field on every write.

    String values are lower-kebab; ``.polar`` files compare against them
    via ``intent.value = "assertive"`` etc.  Five members, no aliases,
    no extensions.  Pinned by §10.12.

    Members
    -------
    assertive
        A claim about how the world is.  Default for content captured
        from documents, graph-node ingest, observation, agent-drafted
        analysis, surprise reports.
    directive
        A request for action.  Tasks, queries posed as questions, agent
        escalations, supervision requests (§5.19).  Opens a conversation
        when targeted at a principal.
    commissive
        A commitment by the actor.  Schedule entries, agent intent
        declarations, contract clauses, promises in response to a
        directive (§5.19).
    expressive
        A stance or reaction.  Feedback, ratings, satisfaction or
        rejection on conversation closure (§5.19), surprise
        acknowledgements, calibration confirmations.
    declarative
        An act that changes state by being uttered with the right
        authority.  Approvals, retractions, status transitions, role
        assignments, ontology-version commits, falsification of a
        load-bearing decision (§6.3).
    """

    assertive = "assertive"
    directive = "directive"
    commissive = "commissive"
    expressive = "expressive"
    declarative = "declarative"


# ---------------------------------------------------------------------------
# Action literal type — closed set of 12 (master-plan "Shared artifacts").
# ---------------------------------------------------------------------------

ActionLiteral = Literal[
    "read",
    "create",
    "update",
    "archive",
    "declare",
    "direct",
    "commit",
    "express",
    "assert",
    "revoke",
    "pause",
    "resume",
]
"""Closed set of 12 actions for the authorization chokepoint.

CRUD (``read``, ``create``, ``update``, ``archive``) + Searle's five as
verbs (``declare``, ``direct``, ``commit``, ``express``, ``assert``) +
capability lifecycle (``revoke``, ``pause``, ``resume``).

New actions in later slices require amending this Literal.  Slice 2
plants the closed set; engine T7's ``Depends(authorize)`` signature uses
this type for the ``action`` parameter.

Per master-plan "Shared artifacts & contracts" → "Action Literal[...] set".
"""

# Derived runtime set for O(1) membership checks and hypothesis strategies.
VALID_ACTIONS: frozenset[str] = frozenset(get_args(ActionLiteral))

INTENT_TO_ACTION: dict[Intent, ActionLiteral] = {
    Intent.assertive: "assert",
    Intent.directive: "direct",
    Intent.commissive: "commit",
    Intent.expressive: "express",
    Intent.declarative: "declare",
}
"""Slice 4 speech-act intent to policy-action mapping.

This is the shared contract consumed by ``POST /graph/assert`` authorization,
audit, staging, CLI, and the Slice 4 gate. It deliberately maps
``declarative`` to the narrow ``declare`` action, never to a generic
``write`` fallback.
"""


def action_for_intent(intent: object) -> ActionLiteral:
    """Return the authorization action associated with a Slice 4 intent."""

    if not isinstance(intent, Intent):
        raise ValueError(f"unsupported intent: {intent!r}")
    try:
        return INTENT_TO_ACTION[intent]
    except KeyError as exc:
        raise ValueError(f"unsupported intent: {intent!r}") from exc


# ---------------------------------------------------------------------------
# ALLOWED_INTENTS table — (action, subject) → allowed intent set.
#
# Read actions are absent.  Write actions cover all registered subjects.
# See module docstring for per-entry rationale.
# ---------------------------------------------------------------------------

ALLOWED_INTENTS: dict[tuple[ActionLiteral, AppSubject], frozenset[Intent]] = {
    # ------------------------------------------------------------------
    # Organization — the tenant itself.
    # Creates are assertions that an org exists (onboarding, seeding).
    # Updates assert new state.
    # Archive / revoke / declare / pause / resume require authority.
    # "direct" on an org is unusual but maps to directive; the Polar
    # policy will restrict who can actually issue it — the intent table
    # only defines the valid speech-act type, not who is permitted.
    # ------------------------------------------------------------------
    ("create", AppSubject.ORGANIZATION): frozenset({Intent.assertive}),
    ("update", AppSubject.ORGANIZATION): frozenset({Intent.assertive}),
    ("archive", AppSubject.ORGANIZATION): frozenset({Intent.declarative}),
    ("declare", AppSubject.ORGANIZATION): frozenset({Intent.declarative}),
    ("direct", AppSubject.ORGANIZATION): frozenset({Intent.directive}),
    ("assert", AppSubject.ORGANIZATION): frozenset({Intent.assertive}),
    ("revoke", AppSubject.ORGANIZATION): frozenset({Intent.declarative}),
    ("pause", AppSubject.ORGANIZATION): frozenset({Intent.declarative}),
    ("resume", AppSubject.ORGANIZATION): frozenset({Intent.declarative}),
    ("commit", AppSubject.ORGANIZATION): frozenset({Intent.commissive}),
    ("express", AppSubject.ORGANIZATION): frozenset({Intent.expressive}),
    # ------------------------------------------------------------------
    # Membership — principal × tenant binding.
    # Creates assert a new binding.
    # Updates assert role / clearance changes.
    # Archive / revoke / declare require authority (role management).
    # Direct is applicable: "direct this member to perform a task."
    # ------------------------------------------------------------------
    ("create", AppSubject.MEMBERSHIP): frozenset({Intent.assertive}),
    ("update", AppSubject.MEMBERSHIP): frozenset({Intent.assertive}),
    ("archive", AppSubject.MEMBERSHIP): frozenset({Intent.declarative}),
    ("declare", AppSubject.MEMBERSHIP): frozenset({Intent.declarative}),
    ("direct", AppSubject.MEMBERSHIP): frozenset({Intent.directive}),
    ("assert", AppSubject.MEMBERSHIP): frozenset({Intent.assertive}),
    ("revoke", AppSubject.MEMBERSHIP): frozenset({Intent.declarative}),
    ("pause", AppSubject.MEMBERSHIP): frozenset({Intent.declarative}),
    ("resume", AppSubject.MEMBERSHIP): frozenset({Intent.declarative}),
    ("commit", AppSubject.MEMBERSHIP): frozenset({Intent.commissive}),
    ("express", AppSubject.MEMBERSHIP): frozenset({Intent.expressive}),
    # ------------------------------------------------------------------
    # Node — graph node (Slice 4+ table; scaffold model now).
    # Most node operations are assertive (claiming facts about the world).
    # Archive / revoke / declare / pause / resume require authority.
    # "direct" on a node: issue a task/query targeted at the node's
    # subject-matter → directive (Polar policy restricts who can issue it).
    # ------------------------------------------------------------------
    ("create", AppSubject.NODE): frozenset({Intent.assertive}),
    ("update", AppSubject.NODE): frozenset({Intent.assertive}),
    ("archive", AppSubject.NODE): frozenset({Intent.declarative}),
    ("declare", AppSubject.NODE): frozenset({Intent.declarative}),
    ("direct", AppSubject.NODE): frozenset({Intent.directive}),
    ("assert", AppSubject.NODE): frozenset({Intent.assertive}),
    ("revoke", AppSubject.NODE): frozenset({Intent.declarative}),
    ("pause", AppSubject.NODE): frozenset({Intent.declarative}),
    ("resume", AppSubject.NODE): frozenset({Intent.declarative}),
    ("commit", AppSubject.NODE): frozenset({Intent.commissive}),
    ("express", AppSubject.NODE): frozenset({Intent.expressive}),
    # ------------------------------------------------------------------
    # OrgConfig — org-level agent configuration (Slice 7 wires loader).
    # Config writes are declarative (authority-required state changes).
    # Assertive is allowed for assert (observational read-back).
    # "direct" on OrgConfig: issue a configuration directive → directive
    # (e.g., "apply this config" as a directive to an agent).
    # ------------------------------------------------------------------
    ("create", AppSubject.ORG_CONFIG): frozenset({Intent.declarative}),
    ("update", AppSubject.ORG_CONFIG): frozenset({Intent.declarative}),
    ("archive", AppSubject.ORG_CONFIG): frozenset({Intent.declarative}),
    ("declare", AppSubject.ORG_CONFIG): frozenset({Intent.declarative}),
    ("direct", AppSubject.ORG_CONFIG): frozenset({Intent.directive}),
    ("assert", AppSubject.ORG_CONFIG): frozenset({Intent.assertive}),
    ("revoke", AppSubject.ORG_CONFIG): frozenset({Intent.declarative}),
    ("pause", AppSubject.ORG_CONFIG): frozenset({Intent.declarative}),
    ("resume", AppSubject.ORG_CONFIG): frozenset({Intent.declarative}),
    ("commit", AppSubject.ORG_CONFIG): frozenset({Intent.commissive}),
    ("express", AppSubject.ORG_CONFIG): frozenset({Intent.expressive}),
    # ------------------------------------------------------------------
    # Delegation — capability delegation (Slice 7 wires loader + table).
    # Creates are commissive (a commitment to delegate authority).
    # Revoke / archive are declarative (authority-required removal).
    # Direct is applicable: "direct via this delegation."
    # ------------------------------------------------------------------
    ("create", AppSubject.DELEGATION): frozenset({Intent.commissive}),
    ("update", AppSubject.DELEGATION): frozenset({Intent.assertive}),
    ("archive", AppSubject.DELEGATION): frozenset({Intent.declarative}),
    ("declare", AppSubject.DELEGATION): frozenset({Intent.declarative}),
    ("direct", AppSubject.DELEGATION): frozenset({Intent.directive}),
    ("assert", AppSubject.DELEGATION): frozenset({Intent.assertive}),
    ("revoke", AppSubject.DELEGATION): frozenset({Intent.declarative}),
    ("pause", AppSubject.DELEGATION): frozenset({Intent.declarative}),
    ("resume", AppSubject.DELEGATION): frozenset({Intent.declarative}),
    ("commit", AppSubject.DELEGATION): frozenset({Intent.commissive}),
    ("express", AppSubject.DELEGATION): frozenset({Intent.expressive}),
    # ------------------------------------------------------------------
    # EventSubscription — external integration control plane (Slice 8).
    # Lifecycle changes are declarative integration configuration changes.
    # Direct/assert/commit/express entries keep the intent table exhaustive
    # for write verbs; Polar only allows the management actions shipped in T1.
    # ------------------------------------------------------------------
    ("create", AppSubject.EVENT_SUBSCRIPTION): frozenset({Intent.declarative}),
    ("update", AppSubject.EVENT_SUBSCRIPTION): frozenset({Intent.declarative}),
    ("archive", AppSubject.EVENT_SUBSCRIPTION): frozenset({Intent.declarative}),
    ("declare", AppSubject.EVENT_SUBSCRIPTION): frozenset({Intent.declarative}),
    ("direct", AppSubject.EVENT_SUBSCRIPTION): frozenset({Intent.directive}),
    ("assert", AppSubject.EVENT_SUBSCRIPTION): frozenset({Intent.assertive}),
    ("revoke", AppSubject.EVENT_SUBSCRIPTION): frozenset({Intent.declarative}),
    ("pause", AppSubject.EVENT_SUBSCRIPTION): frozenset({Intent.declarative}),
    ("resume", AppSubject.EVENT_SUBSCRIPTION): frozenset({Intent.declarative}),
    ("commit", AppSubject.EVENT_SUBSCRIPTION): frozenset({Intent.commissive}),
    ("express", AppSubject.EVENT_SUBSCRIPTION): frozenset({Intent.expressive}),
    # ------------------------------------------------------------------
    # Conversation — node-shaped Slice 9 request/promise/completion loop.
    # Party/delegation checks live in ConversationService; the policy layer
    # gates the speech-act action against tenant membership.
    # ------------------------------------------------------------------
    ("create", AppSubject.CONVERSATION): frozenset({Intent.directive}),
    ("update", AppSubject.CONVERSATION): frozenset({Intent.assertive}),
    ("archive", AppSubject.CONVERSATION): frozenset({Intent.declarative}),
    ("declare", AppSubject.CONVERSATION): frozenset({Intent.declarative}),
    ("direct", AppSubject.CONVERSATION): frozenset({Intent.directive}),
    ("assert", AppSubject.CONVERSATION): frozenset({Intent.assertive}),
    ("revoke", AppSubject.CONVERSATION): frozenset({Intent.declarative}),
    ("pause", AppSubject.CONVERSATION): frozenset({Intent.declarative}),
    ("resume", AppSubject.CONVERSATION): frozenset({Intent.declarative}),
    ("commit", AppSubject.CONVERSATION): frozenset({Intent.commissive}),
    ("express", AppSubject.CONVERSATION): frozenset({Intent.expressive}),
}
"""Allowed intent set for each (action, subject) write pair.

Read actions are absent — no intent gate on reads.  Every value is a
non-empty ``frozenset[Intent]``; an empty set would mean the action is
prohibited for that subject (use the Polar policy for that, not this table).

Engine T7's ``Depends(authorize)`` validates the caller-supplied intent
against this table at request time.
:func:`validate_intent_table_consistency` validates declared intents at
startup time so mis-wired routes fail before the first request.

Per master-plan "Shared artifacts & contracts" → ALLOWED_INTENTS row;
``03 § F3``; §10.12.
"""

# ---------------------------------------------------------------------------
# IncompatibleIntentError — startup failure when a route declares a bad intent.
# ---------------------------------------------------------------------------


class IncompatibleIntentError(Exception):
    """Raised by :func:`validate_intent_table_consistency` on startup mismatch.

    A route declared an intent that is not in ``ALLOWED_INTENTS[(action,
    subject)]``.  This is a developer error; the app refuses to start.

    The message includes the route path, action, subject, and the offending
    intent so the developer can fix the registration immediately.

    Per ``03 § F3``; §10.12.
    """


# ---------------------------------------------------------------------------
# validate_intent_table_consistency — startup hook (F3).
# ---------------------------------------------------------------------------


def validate_intent_table_consistency(app: FastAPI) -> None:
    """Walk ``app.routes`` and assert every ``Depends(authorize(...))`` route
    declares a compatible intent.

    Called via ``app.add_event_handler("startup", ...)`` so the app refuses
    to start if a route's intent does not appear in
    ``ALLOWED_INTENTS[(action, subject_kind)]``.

    Empty-app case: if no route carries ``Depends(authorize)``, the function
    returns immediately.  This is the correct behaviour for T6 (which ships
    before engine T7 adds the ``authorize`` factory).

    Intent-lookup logic
    -------------------
    Engine T7's :func:`~skaldos.policy.authorize.authorize` factory
    attaches the marker to the *inner* callable inside its returned
    ``Depends(_inner)`` — i.e. the marker lives on
    ``dependant.dependencies[i].call._authorize_meta`` rather than on
    ``route.endpoint``.  The walk is shared with
    :func:`skaldos.policy.authorize.register_route_tiers` via
    :func:`skaldos.policy.policy._dependant_walk.find_authorize_meta`.

    History: followup #14 corrected this site.  An earlier version read
    ``getattr(route.endpoint, "_authorize_meta", None)`` and so silently
    iterated every protected route, found no marker, and returned —
    making the §10.12 startup-time gate dead code.

    Parameters
    ----------
    app:
        The :class:`fastapi.FastAPI` instance to inspect.

    Raises
    ------
    IncompatibleIntentError
        If a route's declared intent is not in
        ``ALLOWED_INTENTS[(action, subject_kind)]``.

    Per ``03 § F3``; §10.12; master-plan "Shared artifacts" →
    ``validate_intent_table_consistency``.
    """
    from fastapi.routing import APIRoute

    from skaldos.policy._dependant_walk import find_authorize_meta

    for route in app.routes:
        if not isinstance(route, APIRoute):
            continue

        meta = find_authorize_meta(route)
        if meta is None:
            # No authorize dependency on this route — skip.
            continue

        action: ActionLiteral = meta.action
        subject_kind: AppSubject = meta.subject_kind
        intent: Intent | None = meta.intent

        if intent is None:
            # No intent declared — only valid if the action is absent from
            # ALLOWED_INTENTS (i.e., it's a read-only action).
            if (action, subject_kind) in ALLOWED_INTENTS:
                raise IncompatibleIntentError(
                    f"Route '{route.path}' calls authorize(action={action!r}, "
                    f"subject_kind={subject_kind!r}) without an intent, but "
                    f"ALLOWED_INTENTS requires one of "
                    f"{sorted(i.value for i in ALLOWED_INTENTS[(action, subject_kind)])}. "
                    "Declare intent= in the Depends(authorize(...)) call."
                )
            continue

        allowed = ALLOWED_INTENTS.get((action, subject_kind))
        if allowed is None:
            # (action, subject) not in table at all — only read actions
            # should be absent.  A write action with intent but no table
            # entry is a configuration gap; fail loudly.
            # (This branch is defensive; the table covers all 12 write
            # actions × 5 subjects in Slice 2.)
            raise IncompatibleIntentError(
                f"Route '{route.path}' declares intent={intent.value!r} for "
                f"authorize(action={action!r}, subject_kind={subject_kind!r}), "
                "but this (action, subject) pair has no entry in ALLOWED_INTENTS. "
                "Add the entry or use a read-only action."
            )

        if intent not in allowed:
            raise IncompatibleIntentError(
                f"Route '{route.path}' declares intent={intent.value!r} for "
                f"authorize(action={action!r}, subject_kind={subject_kind!r}), "
                f"but ALLOWED_INTENTS only permits "
                f"{sorted(i.value for i in allowed)}. "
                "Fix the intent= declaration in the Depends(authorize(...)) call."
            )
