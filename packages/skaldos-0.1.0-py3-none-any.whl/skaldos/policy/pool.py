"""``app_chokepoint`` pool lifecycle (engine T4).

The ``app_chokepoint`` role (BYPASSRLS, SELECT/INSERT/narrow-UPDATE on
``principals`` only) was created by the migration in engine T3
(``migrations/versions/20260507_app_chokepoint_role.py``). This module
owns the asyncpg pool that connects as that role.

Why a dedicated pool?
---------------------

The principal-resolution step inside :func:`~skaldos.middleware.hydration.current_principal`
runs **before** the PC1 GUC contract is committed. The ``principals``
table carries ``FORCE ROW LEVEL SECURITY``; both of its PERMISSIVE
policies (``principals_self_row`` and ``principals_visible_via_membership``)
evaluate ``app.principal_id()`` / ``app.principal_visible()``, which
read transaction-local GUCs. Before the GUC is set, the GUC functions
return NULL, both policies fail closed, and the resolver returns zero
rows — causing the chokepoint to attempt an INSERT that violates the
partial UNIQUE on ``auth0_sub`` for every returning user.

The ``app_chokepoint`` role's ``BYPASSRLS`` attribute sidesteps all
RLS policies, so the resolver can look up the row unconditionally.
The runtime pool (``app_runtime`` role) stays RLS-bound and handles all
post-resolution queries where the GUC *is* committed.

**This is a security boundary, not a performance optimization.** Per
``docs/slices/slice-2-authorization/policy-module-and-chokepoint/03-technical-implementation.md``
§ "Fault lines" F1: any refactor that moves the resolver *after* the
GUC commit makes this pool redundant; removing it without removing the
BYPASSRLS role is a regression. Document that refactor with an ADR.

Grant set for ``app_chokepoint`` (pinned by engine T9 lint)
------------------------------------------------------------

- CONNECT on DATABASE skaldos
- USAGE on SCHEMA app
- EXECUTE on ``app.principal_id()``, ``app.principal_visible()``
- SELECT on principals
- INSERT on principals          (first-auth provisioning)
- UPDATE (auth0_sub, updated_at) on principals   (narrow re-link)

**No grants on tenants, memberships, or any other table.** Attempts to
query other tables from this pool raise ``InsufficientPrivilegeError``.

Environment variable
--------------------

``CHOKEPOINT_POOL_DSN`` — the DSN the pool uses to authenticate as
``app_chokepoint``. Required; this module refuses to fall back to any
other DSN (including the bootstrap superuser) even in dev. The absence
of ``CHOKEPOINT_POOL_DSN`` raises :class:`RuntimeError` at startup.

References: §14.11 (four roles; ``app_chokepoint`` is the fourth;
generalizes PC3's "minimum role set"); Slice 1 followups #3 (the
production-deploy blocker this module resolves);
``03-technical-implementation.md`` § "Architecture" + § "Fault lines" F1;
``05-task-list.md`` § T4.
"""

from __future__ import annotations

import os

import asyncpg

__all__ = [
    "close_chokepoint_pool",
    "init_chokepoint_pool",
]


def _resolve_chokepoint_dsn(dsn: str | None) -> str:
    """Return the DSN to use for the chokepoint pool.

    Priority:
    1. The explicit ``dsn`` argument (tests inject a per-container DSN
       this way).
    2. The ``CHOKEPOINT_POOL_DSN`` environment variable.

    Strips SQLAlchemy driver qualifiers (``+psycopg``, ``+asyncpg``) so
    the same DSN shape works for asyncpg and SQLAlchemy callers — the
    canonical convention everywhere else in the stack uses
    ``postgresql+asyncpg://`` (Alembic, ``DATABASE_URL`` in ``.env``,
    ``DATABASE_MIGRATE_URL``). asyncpg only accepts the bare
    ``postgresql://`` scheme; without the strip, setting
    ``CHOKEPOINT_POOL_DSN=postgresql+asyncpg://...`` raises
    ``ClientConfigurationError: invalid DSN: scheme is expected to be
    either "postgresql" or "postgres"`` at startup. Mirrors the same
    transform in :func:`skaldos.db.pool._resolve_dsn` and
    :func:`skaldos.policy.rate_limit.pool._resolve_dsn` (Slice 2
    followups #7).

    Raises :class:`RuntimeError` when neither is set.  The module
    refuses to fall back to any other DSN — including the bootstrap
    superuser — even in dev (per §14.11 / Slice 1 followups #3).
    The deliberate absence of a fallback makes a mis-configured deploy
    fail loudly at startup rather than silently run as the wrong role.
    """
    if dsn is None:
        env_dsn = os.environ.get("CHOKEPOINT_POOL_DSN")
        if not env_dsn:
            raise RuntimeError(
                "CHOKEPOINT_POOL_DSN is not set. "
                "The chokepoint pool refuses to fall back to any other DSN "
                "(including the bootstrap superuser). "
                "Set CHOKEPOINT_POOL_DSN to the app_chokepoint DSN against the "
                "PgBouncer transaction-mode listener (port 5431 per §18.3). "
                "In dev, add CHOKEPOINT_POOL_DSN to docker-compose.yml or "
                "your .env.local; in prod, provision via GCP Secret Manager "
                "(same idiom as SKALDOS_APP_CHOKEPOINT_PASSWORD in the Slice 0 "
                "password-rotation runbook)."
            )
        raw = env_dsn
    else:
        raw = dsn
    return raw.replace("postgresql+psycopg://", "postgresql://", 1).replace(
        "postgresql+asyncpg://", "postgresql://", 1
    )


async def init_chokepoint_pool(dsn: str | None = None) -> asyncpg.Pool:
    """Open a fresh asyncpg pool authenticated as the ``app_chokepoint`` role.

    Opens a **new** pool on every call — this function is not idempotent.
    The caller (FastAPI's lifespan hook in :func:`~skaldos.app.create_app`)
    is responsible for stashing the returned pool on ``app.state.chokepoint_pool``
    and closing it at shutdown via :func:`close_chokepoint_pool`.

    Args:
        dsn: Explicit DSN, used by integration tests to inject the
            testcontainer's per-session URL.  When ``None``, the DSN is
            read from ``CHOKEPOINT_POOL_DSN`` env var.

    Returns:
        A live :class:`asyncpg.Pool` whose connections authenticate as
        ``app_chokepoint`` (BYPASSRLS; SELECT/INSERT/narrow-UPDATE on
        ``principals`` only).

    Raises:
        :class:`RuntimeError`: when ``dsn`` is ``None`` and
            ``CHOKEPOINT_POOL_DSN`` is unset.
        :class:`asyncpg.PostgresError`: on connection failure (wrong
            DSN, wrong password, role doesn't exist yet).

    Notes:
        Pool sizing mirrors the runtime pool's defaults (from
        ``services/api/skaldos/db/pool.py``).  The chokepoint pool
        handles principal-resolution traffic only — it is released after
        the resolver returns, *before* the handler runs.  Its typical
        concurrency ceiling is bounded by the number of in-flight
        principal lookups, not the number of concurrent handlers.  The
        2 / 10 defaults are intentionally smaller than the runtime pool's
        2 / 20 to signal that distinction.
    """
    resolved_dsn = _resolve_chokepoint_dsn(dsn)
    pool: asyncpg.Pool = await asyncpg.create_pool(  # pyright: ignore[reportUnknownMemberType]
        dsn=resolved_dsn,
        min_size=2,
        max_size=10,
        command_timeout=5.0,
        timeout=5.0,
    )
    return pool


async def close_chokepoint_pool(pool: asyncpg.Pool) -> None:
    """Close the chokepoint pool and release all held connections.

    Idempotent against a pool that is already closed (asyncpg's
    :meth:`Pool.close` is idempotent once called).  Called by FastAPI's
    lifespan shutdown hook in :func:`~skaldos.app.create_app`.

    Args:
        pool: The pool returned by :func:`init_chokepoint_pool`.
    """
    await pool.close()  # pyright: ignore[reportUnknownMemberType]
