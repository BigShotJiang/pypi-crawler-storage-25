"""Assertion-specific policy helpers for ``POST /graph/assert``.

The normal ``authorize()`` dependency captures an action and intent at route
registration time. ``/graph/assert`` derives both from the validated request
body, so this module provides the small service layer the route can call after
Pydantic validation and actor reconciliation.

References: Slice 4 ``intent-authorization-and-policy`` T6-T10;
``ARCHITECTURE.md`` §2.1; substrate constraints §4.1, §4.5, §10.5, §10.12,
AP5, AP11, M14.
"""

from __future__ import annotations

from collections.abc import Mapping
from datetime import UTC, datetime
from enum import StrEnum
from typing import TYPE_CHECKING, Any, Literal, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from opentelemetry import trace
from pydantic import BaseModel, ConfigDict
from skaldos_log import log  # pyright: ignore[reportMissingTypeStubs]

from skaldos.middleware import Principal
from skaldos.policy.host import get_oso
from skaldos.policy.intent import ActionLiteral, Intent, action_for_intent
from skaldos.policy.loaders import load_node_by_id
from skaldos.policy.subjects import (
    AppSubject,
    ConversationRow,
    DelegationRow,
    EventSubscriptionRow,
    MembershipRow,
    NodeRow,
    OrganizationRow,
    OrgConfigRow,
    Subject,
)

if TYPE_CHECKING:
    from skaldos.graph.assert_staging import AssertionCanonicalInput

_SYNTHETIC_ASSERTION_SUBJECT_ID = UUID("00000000-0000-0000-0000-000000000000")


class AssertionAuthorizationReason(StrEnum):
    """Low-cardinality reason codes for assertion policy decisions."""

    SUBJECT_DERIVATION_FAILED = "subject_derivation_failed"
    SUBJECT_NOT_FOUND = "subject_not_found"
    POLICY_DENIED_ASSERT = "policy_denied_assert"
    POLICY_DENIED_DIRECT = "policy_denied_direct"
    POLICY_DENIED_COMMIT = "policy_denied_commit"
    POLICY_DENIED_EXPRESS = "policy_denied_express"
    POLICY_DENIED_DECLARE = "policy_denied_declare"
    CONTEXT_CONTAINMENT_DENIED = "context_containment_denied"
    POLICY_EVALUATION_ERROR = "policy_evaluation_error"


class AssertionSubjectDerivation(BaseModel):
    """Subject row plus metadata derived from an assertion claim/context."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    subject_kind: AppSubject
    subject: Subject
    source: Literal["target_node", "context_node"]


class AssertionPolicyDecision(BaseModel):
    """Safelisted policy-decision shape for logs and audit handoff."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    principal_id: UUID
    tenant_id: UUID
    action: ActionLiteral
    intent: Intent
    subject_type: AppSubject
    subject_id: UUID
    decision: Literal["allowed", "denied"]
    reason_code: AssertionAuthorizationReason | None = None
    trace_id: str | None = None


class AssertionPolicyEvaluationMetadata(BaseModel):
    """Safelisted policy-engine failure shape.

    This is deliberately not an ``authorization.decision`` record because Oso
    did not return a real allow/deny decision.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    principal_id: UUID
    tenant_id: UUID
    action: ActionLiteral
    intent: Intent
    subject_type: AppSubject
    subject_id: UUID
    outcome: Literal["error"] = "error"
    reason_code: Literal[AssertionAuthorizationReason.POLICY_EVALUATION_ERROR] = (
        AssertionAuthorizationReason.POLICY_EVALUATION_ERROR
    )
    trace_id: str | None = None


class AssertionSubjectDerivationError(ValueError):
    """Raised when no safe policy subject can be derived from the assertion."""

    def __init__(self, reason: AssertionAuthorizationReason) -> None:
        self.reason = reason
        super().__init__(reason.value)


class AssertionPolicyDeniedError(PermissionError):
    """Raised when Oso denies an assertion intent/action on the derived subject."""

    def __init__(self, decision: AssertionPolicyDecision) -> None:
        self.decision = decision
        super().__init__(decision.reason_code or "assertion_policy_denied")


class AssertionPolicyEvaluationError(RuntimeError):
    """Raised when the policy engine fails before producing a real decision."""

    def __init__(self, metadata: AssertionPolicyEvaluationMetadata) -> None:
        self.metadata = metadata
        super().__init__(AssertionAuthorizationReason.POLICY_EVALUATION_ERROR.value)


async def derive_assertion_subject(
    *,
    assertion: AssertionCanonicalInput,
    principal: Principal,
    connection: asyncpg.Connection,  # pyright: ignore[reportUnknownParameterType]
) -> AssertionSubjectDerivation:
    """Derive the policy subject for a normalized graph assertion.

    Existing node targets are loaded through the RLS-bound runtime connection,
    making the target row's ``organization_id`` authoritative. Assertions that
    create new graph content derive a synthetic ``Node`` subject from the
    normalized context of validity, not from ambient request state.
    """

    target_node_id = _target_node_id(assertion.claim)
    if target_node_id is not None:
        node = await load_node_by_id(target_node_id, principal, connection)
        if node is None:
            raise AssertionSubjectDerivationError(AssertionAuthorizationReason.SUBJECT_NOT_FOUND)
        return AssertionSubjectDerivation(
            subject_kind=AppSubject.NODE,
            subject=node,
            source="target_node",
        )

    tenant_id = _context_tenant_id(assertion.context_of_validity)
    if tenant_id is None:
        raise AssertionSubjectDerivationError(
            AssertionAuthorizationReason.SUBJECT_DERIVATION_FAILED
        )

    return AssertionSubjectDerivation(
        subject_kind=AppSubject.NODE,
        subject=NodeRow(
            id=_SYNTHETIC_ASSERTION_SUBJECT_ID,
            organization_id=tenant_id,
            type=assertion.claim_kind or "",
            created_by_principal_id=principal.id,
            created_at=datetime(1970, 1, 1, tzinfo=UTC),
        ),
        source="context_node",
    )


def authorize_assertion_intent(
    *,
    principal: Principal,
    intent: Intent,
    subject: Subject,
) -> AssertionPolicyDecision:
    """Evaluate ``can(action_for_intent(intent), subject)`` for an assertion.

    On allow, returns the decision metadata. On deny or policy-engine failure,
    raises a typed error carrying the same safelisted metadata shape.
    """

    tracer = trace.get_tracer(__name__)
    with tracer.start_as_current_span("policy.authorize.graph_assert") as span:
        action = action_for_intent(intent)
        subject_type = _subject_kind(subject)
        subject_id = subject.id
        tenant_id = subject.organization_id
        trace_id = _current_trace_id()
        span.set_attribute("authorization.action", action)
        span.set_attribute("authorization.intent", intent.value)
        span.set_attribute("authorization.subject_kind", str(subject_type))

        try:
            allowed = bool(get_oso().is_allowed(principal, action, subject))
        except Exception:  # noqa: BLE001
            metadata = AssertionPolicyEvaluationMetadata(
                principal_id=principal.id,
                tenant_id=tenant_id,
                action=action,
                intent=intent,
                subject_type=subject_type,
                subject_id=subject_id,
                trace_id=trace_id,
            )
            _log_policy_evaluation_error(metadata)
            span.set_attribute("authorization.decision", "error")
            raise AssertionPolicyEvaluationError(metadata) from None

        decision = AssertionPolicyDecision(
            principal_id=principal.id,
            tenant_id=tenant_id,
            action=action,
            intent=intent,
            subject_type=subject_type,
            subject_id=subject_id,
            decision="allowed" if allowed else "denied",
            reason_code=None if allowed else _denial_reason(action),
            trace_id=trace_id,
        )
        _log_decision(decision)
        span.set_attribute("authorization.decision", decision.decision)
        if not allowed:
            raise AssertionPolicyDeniedError(decision)
        return decision


def _target_node_id(claim: Mapping[str, Any]) -> UUID | None:
    claim_kind = claim.get("kind") or claim.get("type")
    direct = claim.get("target_node_id")
    if direct is not None:
        parsed = _uuid_or_none(direct)
        if parsed is None:
            raise AssertionSubjectDerivationError(
                AssertionAuthorizationReason.SUBJECT_DERIVATION_FAILED
            )
        return parsed

    target_raw = claim.get("target")
    if target_raw is None:
        return None
    if not isinstance(target_raw, Mapping):
        raise AssertionSubjectDerivationError(
            AssertionAuthorizationReason.SUBJECT_DERIVATION_FAILED
        )
    target = cast("Mapping[str, object]", target_raw)
    if claim_kind == "edge_create":
        return None
    if claim_kind == "pattern4_revision":
        parsed = _uuid_or_none(target.get("source_decision_id"))
        if parsed is None:
            raise AssertionSubjectDerivationError(
                AssertionAuthorizationReason.SUBJECT_DERIVATION_FAILED
            )
        return parsed
    target_kind = target.get("type") or target.get("kind") or target.get("subject_type")
    if target_kind not in (None, "Node", "node"):
        raise AssertionSubjectDerivationError(
            AssertionAuthorizationReason.SUBJECT_DERIVATION_FAILED
        )
    parsed = _uuid_or_none(target.get("node_id") or target.get("id"))
    if parsed is None:
        raise AssertionSubjectDerivationError(
            AssertionAuthorizationReason.SUBJECT_DERIVATION_FAILED
        )
    return parsed


def _context_tenant_id(context: Mapping[str, Any]) -> UUID | None:
    for key in ("organization_id", "tenant_id", "tenant"):
        value = context.get(key)
        parsed = _uuid_or_none(value)
        if parsed is not None:
            return parsed
    return None


def _uuid_or_none(value: object) -> UUID | None:
    if isinstance(value, UUID):
        return value
    if isinstance(value, str):
        try:
            return UUID(value)
        except ValueError:
            return None
    return None


def _subject_kind(subject: Subject) -> AppSubject:
    match subject:
        case OrganizationRow():
            return AppSubject.ORGANIZATION
        case MembershipRow():
            return AppSubject.MEMBERSHIP
        case NodeRow():
            return AppSubject.NODE
        case OrgConfigRow():
            return AppSubject.ORG_CONFIG
        case DelegationRow():
            return AppSubject.DELEGATION
        case EventSubscriptionRow():
            return AppSubject.EVENT_SUBSCRIPTION
        case ConversationRow():
            return AppSubject.CONVERSATION
    raise AssertionError(f"unsupported assertion policy subject: {type(subject)!r}")


def _denial_reason(action: ActionLiteral) -> AssertionAuthorizationReason:
    match action:
        case "assert":
            return AssertionAuthorizationReason.POLICY_DENIED_ASSERT
        case "direct":
            return AssertionAuthorizationReason.POLICY_DENIED_DIRECT
        case "commit":
            return AssertionAuthorizationReason.POLICY_DENIED_COMMIT
        case "express":
            return AssertionAuthorizationReason.POLICY_DENIED_EXPRESS
        case "declare":
            return AssertionAuthorizationReason.POLICY_DENIED_DECLARE
        case _:
            raise AssertionError(f"assertion intent mapped to non-speech action: {action!r}")


def _current_trace_id() -> str | None:
    span_context = trace.get_current_span().get_span_context()
    if not span_context.is_valid:
        return None
    return f"{span_context.trace_id:032x}"


def _log_decision(decision: AssertionPolicyDecision) -> None:
    fields = decision.model_dump(mode="json", exclude_none=True)
    log.info("authorization.decision", **fields)


def _log_policy_evaluation_error(metadata: AssertionPolicyEvaluationMetadata) -> None:
    fields = metadata.model_dump(mode="json", exclude_none=True)
    log.info("authorization.policy_evaluation_error", **fields)
