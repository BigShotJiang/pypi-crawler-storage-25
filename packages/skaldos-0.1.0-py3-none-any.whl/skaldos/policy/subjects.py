"""Subject vocabulary for the SkaldOS authorization layer (Slice 2, T1).

Per ``docs/slices/slice-2-authorization/subject-vocabulary-and-policies/
03-technical-implementation.md`` § "AppSubject enum" and
"Subject row models".

The substrate's closed set of authorization subjects. Every resource
class that participates in the ``can(action, subject)`` chokepoint must
be listed here as an :class:`AppSubject` member and have a matching
Pydantic row model.

Design decisions
----------------

**``AppSubject`` is a ``StrEnum``, values match Polar type names verbatim.**
Polar type names are case-sensitive (``Organization``, not ``organization``).
The enum's string values are the Polar type identifiers; the enum gives
Python type-system exhaustiveness. A non-exhaustive ``match`` on
``AppSubject`` will be caught by pyright strict (``reportMatchNotExhaustive``)
*and* by the explicit exhaustiveness unit test in
``tests/unit/policy/test_subjects.py``.

**Every row model exposes ``organization_id`` as a policy alias.** Storage
columns are named ``tenant_id``; Polar rules deliberately keep the
product/policy vocabulary ``subject.organization_id``. Loaders adapt
storage rows into that alias at the boundary, and rules must not infer tenant
authority from actor state. For ``OrganizationRow``, ``organization_id``
aliases ``id`` --- the org *is* the tenant.

**``frozen=True, extra="forbid"`` on every row.** Same discipline as
:class:`~skaldos.middleware.Principal` (AP5 — immutable shapes prevent
debug side-channels; frozen + strict-extra makes hash/equality deterministic
for test fixture construction).

**``OrgConfig`` and ``Delegation`` rows are scaffold-now-wire-later.**
Their Pydantic schemas are complete; their loaders raise
``NotImplementedError("wired in Slice 7 — ...")``. The Slice 2 matrix test
uses in-memory fixture rows; no live table is required.

References: §4.1, §4.5, §4.6, §4.7, MP1, MP3, MP4.
"""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from uuid import UUID

from pydantic import BaseModel, ConfigDict

# ---------------------------------------------------------------------------
# Subject vocabulary — the closed enum.
# ---------------------------------------------------------------------------


class AppSubject(StrEnum):
    """Closed set of authorization subjects in the SkaldOS substrate.

    String values match Polar type names verbatim (case-sensitive).  The
    mapping is intentional and must not diverge: Polar rules use
    ``org: Organization``, ``membership: Membership``, etc.  The enum
    gives Python-side exhaustiveness; the string value is what lands in
    the policy engine.

    Adding a new subject requires:
    1. A new enum member here (string value = Polar type name).
    2. A new ``*Row`` Pydantic model below.
    3. A new entry in the ``Subject`` union type alias below.
    4. A new ``.polar`` file under ``policies/``.
    5. A new loader function in ``policy/loaders.py``.
    6. A new ``(action, subject)`` contribution to ``ALLOWED_INTENTS``
       (engine T6).
    7. A new matrix row in ``tests/integration/test_authorization_matrix.py``.

    Per §4.1 + master-plan "Shared artifacts & contracts".
    """

    ORGANIZATION = "Organization"
    MEMBERSHIP = "Membership"
    NODE = "Node"
    ORG_CONFIG = "OrgConfig"  # scaffold; Slice 7 wires loader + table
    DELEGATION = "Delegation"  # scaffold; Slice 7 wires loader + table
    EVENT_SUBSCRIPTION = "EventSubscription"  # Slice 8 wires loader + table
    CONVERSATION = "Conversation"  # Slice 9 node-shaped Conversation subject


# ---------------------------------------------------------------------------
# Subject row models — one per AppSubject member.
# ---------------------------------------------------------------------------


class OrganizationRow(BaseModel):
    """Authorization subject row for an organization (tenant).

    ``organization_id`` is the policy/product alias for the tenant id. It
    aliases ``id`` by convention so every :class:`Subject` variant exposes
    the same field name for Polar's tenant-lookup primitive
    ``has_role_in_org``.  Both fields must be equal on construction; the unit test
    ``test_organization_row_organization_id_aliases_id`` pins this.

    Per ``03 § Subject row models`` + §4.1 + §4.5.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    organization_id: UUID  # policy alias of id; uniform tenant accessor for Polar
    display_name: str
    region: str
    created_at: datetime
    disabled_at: datetime | None


class MembershipRow(BaseModel):
    """Authorization subject row for a membership (principal × tenant binding).

    ``role`` is stored as a plain ``str`` to remain forward-compatible with
    future enum additions (``customer``, ``viewer`` per §4.4 / §4.7 ADR).
    The Polar policy files compare it against role string literals; the
    matrix test constrains the expected values.

    ``max_clearance`` is a scaffold-now-wire-later field; Slice 6 activates
    the clearance substrate (§15.2).  ``None`` until then.

    Per ``03 § Subject row models`` + §4.1 + ML5(2).
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    organization_id: UUID  # policy alias over memberships.tenant_id
    principal_id: UUID
    role: str  # owner | admin | member  (Slice 2); widens later
    max_clearance: str | None  # "C0".."C4" — Slice 6+ semantic; None until then
    created_at: datetime
    revoked_at: datetime | None


class NodeRow(BaseModel):
    """Authorization subject row for a graph node.

    The ``nodes`` table is introduced in Slice 3; this row model is
    scaffold-now-wire-later.  The Slice 2 matrix test constructs
    :class:`NodeRow` instances directly (no DB required).  The loader
    ``load_node_by_id`` in ``policy/loaders.py`` targets the Slice 3
    schema.

    Per ``03 § Subject row models`` + §4.1 + F6 (scaffold note).
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    organization_id: UUID  # policy alias over nodes.tenant_id
    type: str
    created_by_principal_id: UUID
    created_at: datetime


class OrgConfigRow(BaseModel):
    """Authorization subject row for org-level agent configuration.

    Stub for Slice 7 (the ``org_agent_config`` table per
    ``feature-catalog.md`` § A4).  Only the fields consumed by Polar
    rules (``id``, ``organization_id``) are present; Slice 7 extends.

    The §4.7 member-read-only property is encoded in
    ``policies/orgconfig.polar``; the row model itself has no business
    logic.

    Per ``03 § Subject row models`` + §4.7 + scaffold-now-wire-later.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    organization_id: UUID  # policy alias over future org-config tenant_id


class DelegationRow(BaseModel):
    """Authorization subject row for a capability delegation.

    Stub for Slice 7 (the ``delegations`` table + JWT ``act`` claim per
    MP10).  Carries the fields referenced by ``policies/delegation.polar``
    (§4.6 delegator-only-revoke rule).  Slice 7 extends.

    Per ``03 § Subject row models`` + §4.6 + MP10 + scaffold-now-wire-later.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    organization_id: UUID  # policy alias for the tenant the delegation operates within
    delegator_principal_id: UUID
    delegatee_principal_id: UUID


class EventSubscriptionRow(BaseModel):
    """Authorization subject row for an external event subscription.

    Slice 8 PR A plants the subject and policy surface before the table lands.
    The row carries only fields required by policy rules; schema/RLS/API PRs
    extend the storage-backed loader once ``event_subscription`` exists.

    Per Slice 8 external-event-subscriptions T1 and §8.5-§8.8.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    organization_id: UUID
    subscriber_principal_id: UUID


class ConversationRow(BaseModel):
    """Authorization subject row for a node-shaped Slice 9 Conversation."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    organization_id: UUID
    requester_principal_id: UUID
    requestee_principal_id: UUID


# ---------------------------------------------------------------------------
# Discriminated union — the typed subject parameter for the chokepoint.
# ---------------------------------------------------------------------------

Subject = (
    OrganizationRow
    | MembershipRow
    | NodeRow
    | OrgConfigRow
    | DelegationRow
    | EventSubscriptionRow
    | ConversationRow
)
"""Type alias for the full set of authorization subjects.

Used as the parameter type wherever the authorization chokepoint accepts
a loaded subject row.  Pyright strict will catch non-exhaustive ``match``
blocks over ``AppSubject`` members; pair with the unit test
``test_app_subject_exhaustive_match`` for runtime exhaustiveness assurance.

Per ``03 § Subject row models`` + §4.1.
"""
