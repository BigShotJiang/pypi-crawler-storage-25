"""Shared dependant-tree walker for ``Depends(authorize(...))`` metadata.

The :class:`~skaldos.policy.authorize.AuthorizeMeta` marker is attached to
the *inner* callable inside the ``Depends(_inner)`` returned by
:func:`~skaldos.policy.authorize.authorize` — so the marker lives on
``dependant.dependencies[i].call._authorize_meta`` rather than on
``route.endpoint``. Two production call sites need the lookup:

- :func:`skaldos.policy.intent.validate_intent_table_consistency` —
  the §10.12 startup-time intent-table validation hook.  Followup #14
  fixed this site: it previously read ``route.endpoint._authorize_meta``
  and silently skipped every protected route.
- :func:`skaldos.policy.authorize.register_route_tiers` — stamps
  ``route.tier`` from ``meta.tier`` at app-assembly time
  (followup #4).

Two lint scripts (``scripts/check_rate_limit_tier_attribute.py``,
``scripts/check_protected_route_responses.py``) carry their own copies
of an equivalent walker for script-isolation; they don't import this
helper, by design — script processes shouldn't reach into the runtime
package.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from skaldos.policy.authorize import AuthorizeMeta

__all__ = ["find_authorize_meta"]


def find_authorize_meta(route: Any) -> AuthorizeMeta | None:
    """Return the :class:`AuthorizeMeta` attached to *route*'s dependant tree.

    Walks ``route.dependant.dependencies`` recursively, looking for a
    sub-dependency whose ``call`` carries ``_authorize_meta``. Returns
    the first match — each protected route has exactly one
    ``Depends(authorize(...))`` so a depth-first descent terminates on
    that single node.

    Parameters
    ----------
    route:
        A :class:`fastapi.routing.APIRoute` (or any object exposing a
        ``dependant`` attribute compatible with FastAPI's dependant
        graph).  Public routes that don't go through ``Depends(authorize)``
        return ``None``.

    Returns
    -------
    The :class:`AuthorizeMeta` if the route's dependant tree carries one;
    ``None`` otherwise.
    """
    dependant = getattr(route, "dependant", None)
    if dependant is None:
        return None

    stack: list[Any] = list(dependant.dependencies)
    while stack:
        sub = stack.pop()
        call = getattr(sub, "call", None)
        meta = getattr(call, "_authorize_meta", None) if call is not None else None
        if meta is not None:
            return meta
        stack.extend(sub.dependencies)
    return None
