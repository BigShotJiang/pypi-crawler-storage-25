"""Oso host singleton --- loads ``policies/*.polar`` at module init (Slice 2, engine T7).

Per ``docs/slices/slice-2-authorization/policy-module-and-chokepoint/``
``03-technical-implementation.md`` § "Module layout" → ``host.py`` and
``05-task-list.md`` § T7.

Module-level ``_oso = Oso()`` is the singleton per process. It is:

1. Constructed eagerly at import time.
2. Loaded with all ``policies/*.polar`` files via
   ``_oso.load_files(glob("policies/*.polar"))`` --- including the
   ``policies/_role_in_org_stub.polar`` bridge file that declares the
   ``role_in_org/3`` Polar rule (see the "Oso 0.27 host-function bridge"
   section below).
3. Populated with the ``_role_in_org`` pure-Python attribute-lookup
   constant (the bridge between Polar's synchronous rule evaluation
   and the principal's pre-resolved ``role_assignments`` field).

Singleton guarantee
-------------------

``_oso`` is a module-level constant; Python's import system ensures it
is constructed exactly once per interpreter process (import lock
prevents parallel construction). Multiple imports of this module all
return the same ``_oso`` reference.

Oso 0.27 host-function bridge
-----------------------------

In Oso 0.27, Python callables registered via ``register_constant`` are
accessible in Polar as *constant variables* (via attribute-access
``constant.method()``) but NOT as directly-callable Polar predicates
(i.e., ``some_fn(p, r, o)`` raises ``ValidationError: Call to undefined
rule``). The ``role_in_org/3`` predicate in ``policies/_common.polar``
uses the Polar-rule-call form ``role_in_org(principal, role, org)``; to
make this work, ``policies/_role_in_org_stub.polar`` declares a Polar
rule that bridges to the Python callable:

.. code-block:: polar

    role_in_org(principal, role, organization_id) if
        _role_in_org.__call__(principal, role, organization_id);

``_role_in_org`` is a pure-Python sync callable (see
:class:`_RoleInOrgBridge` below) that does an attribute lookup against
the principal's ``role_assignments`` tuple — pre-resolved by the
``current_principal`` hydration step (Slice 2 followups #1).  Oso 0.27's
evaluation engine is synchronous; an attribute lookup needs no
event-loop machinery, no async resolver, and no per-call DB query.

Why pre-resolve instead of querying per Polar rule eval
-------------------------------------------------------

The historical bridge (pre-followups-#1) ran an async ``role_in_org``
resolver against ``principal._conn`` from a fresh asyncio event loop.
asyncpg connections are loop-bound; the bridge's nested loop and the
request task's outer loop didn't agree, asyncpg raised a loop-mismatch
error, the bridge swallowed it, and Oso treated the rule as deny.
Production would have silently denied every legitimate non-owner write.

The fix is structural: the principal's role memberships are a snapshot
at request start, exactly the consistency model an authorization check
wants.  Hydration runs **one** ``SELECT tenant_id, role FROM memberships
WHERE principal_id = $1 AND revoked_at IS NULL`` after the GUCs commit,
stamps the result onto :attr:`Principal.role_assignments`, and Polar's
``has_role_in_org`` predicate becomes a pure tuple membership test
during sync Oso eval.  Removes a bug class permanently rather than
patching the loop-bridge symptom.

References: ``docs/specs/2026-05-04-slice-2-followups.md`` item #1;
ML5(3) (R4-clean Polar — rules read from typed args only).

All ``policies/*.polar`` files are loaded in a **single**
``Oso.load_files(...)`` call; Oso 0.27 requires all Polar sources to be
loaded atomically ("Cannot load additional Polar code — all Polar code
must be loaded at the same time").

No hot reload (ADR resolution)
-------------------------------

Policy changes require a process restart.  Loading policies at import
time (not at request time) eliminates the class of "policy file
disagrees with running process" bugs (see ADR resolution in
``master-plan.md`` § "ADRs surfaced — Polar policy hot reload" and
``policies/README.md``).

Policy load failure at startup (F7)
------------------------------------

If any ``*.polar`` file has a syntax error or references an undefined
rule, ``Oso.load_files`` raises ``polar.exceptions.OsoError`` (or a
subclass) at module import time.  This causes the uvicorn worker to
crash before the first request is accepted, so the process's container
enters a restart loop that is visible at the infrastructure level.
The exception is **not swallowed** (AP5-adjacent principle: silent
failures in the policy layer are unacceptable).

``authorize.py`` imports this module and accesses ``_oso`` directly;
if the load failed, the import of ``authorize.py`` also fails.  The
startup crash cascades cleanly.

References: ADR 2 (Oso as the polyglot authorization engine); §4.1
(authorization is a primitive); AP5 (no bypass — no silent-failure
swallow); ``03-technical-implementation.md`` § "Module layout" →
``host.py``, § "Error-management plan" → "Policy load failure at
startup"; master-plan § "ADRs surfaced — Polar policy hot reload".
"""

from __future__ import annotations

import glob
import os
from typing import Any

from oso import Oso  # pyright: ignore[reportMissingTypeStubs]

from skaldos.policy.subjects import (
    ConversationRow,
    DelegationRow,
    EventSubscriptionRow,
    MembershipRow,
    NodeRow,
    OrganizationRow,
    OrgConfigRow,
)

__all__ = ["_oso", "get_oso"]

# ---------------------------------------------------------------------------
# _role_in_org pure-Python attribute-lookup bridge
#
# Polar evaluation in Oso 0.27 is synchronous.  Rather than bridging into
# an async DB resolver from inside the sync eval (the historical shape;
# Slice 2 followups #1 documents the loop-mismatch bug class that pattern
# carried), the bridge here is a pure-Python attribute lookup against the
# principal's pre-resolved ``role_assignments`` tuple.  Hydration owns the
# membership query; the bridge owns the boolean decision.
#
# The wrapper is registered as ``_role_in_org`` (leading underscore is a
# legacy of the original two-callable shape — kept for stability of the
# Polar rule in ``policies/_role_in_org_stub.polar`` which references the
# constant by that exact name).  The Polar rule:
#
#     role_in_org(principal, role, organization_id) if
#         _role_in_org.__call__(principal, role, organization_id);
#
# ---------------------------------------------------------------------------


class _RoleInOrgBridge:
    """Sync attribute-lookup bridge for the ``role_in_org`` Polar predicate.

    Returns ``True`` iff ``(organization_id, role)`` is in
    ``principal.role_assignments`` — the tuple of active memberships
    pre-resolved by ``current_principal`` hydration.  Pure Python,
    synchronous, no DB access during Oso evaluation.

    .. note::
        This class is **internal** to ``host.py``.  External code uses
        ``_oso.is_allowed(...)`` which triggers Oso's evaluation which
        calls this bridge transparently.
    """

    def __call__(self, principal: Any, role: str, organization_id: Any) -> bool:
        """Return ``(organization_id, role) in principal.role_assignments``.

        ``getattr`` defaults to the empty tuple so a principal constructed
        without ``role_assignments`` (test fixtures, hand-built models)
        deny-by-default rather than raising ``AttributeError`` mid-eval —
        the same defensive shape the prior async bridge used for resolver
        exceptions, but the deny is now structural (no role assignments
        means no role-based allow), not a swallowed asyncpg loop error.
        """
        assignments = getattr(principal, "role_assignments", ())
        return (organization_id, role) in assignments


_role_in_org_bridge = _RoleInOrgBridge()

# ---------------------------------------------------------------------------
# Oso host singleton construction.
# ---------------------------------------------------------------------------

# Locate the policies directory relative to this module's worktree root.
# The production invocation is ``uv run uvicorn services.api.skaldos.app:app``
# from the worktree root; policies/ is at the worktree root.
# Test invocations also run from the worktree root (pytest's conftest.py
# ensures the working directory is the project root).
_POLICIES_DIR = os.path.normpath(
    os.path.join(
        os.path.dirname(__file__),  # services/api/skaldos/policy/
        "../../../../policies",  # worktree-root/policies/
    )
)

_POLICY_FILES = sorted(glob.glob(os.path.join(_POLICIES_DIR, "*.polar")))
"""All ``*.polar`` files in the ``policies/`` directory, sorted for determinism.

Includes both subject-specific policies (``organization.polar``, etc.) and
infrastructure files (``_common.polar``, ``_role_in_org_stub.polar``).  All
are loaded in a single ``Oso.load_files(...)`` call.

Test-only fixtures (e.g. the ``test_only_min`` policy used by the matrix
and the e2e chokepoint smoke) live under ``tests/integration/_fixtures/``
and are loaded by their own test-side Oso instances — they do **not**
ship in the production glob (Slice 2 followups #3).  This keeps a
``human → read → *`` allow rule from leaking into the production
singleton's deny-by-default surface.
"""

_oso = Oso()  # pyright: ignore[reportUnknownVariableType]
"""The process-scoped Oso host singleton.

Loaded once at module import; never reloaded (no hot reload — ADR
resolution in master-plan).  Import :data:`_oso` directly or use
:func:`get_oso` for type-annotated access.

Do NOT replace this reference at runtime.  Replacing it is equivalent
to hot reload and creates the "policy disagrees with running process"
class of bugs that the no-hot-reload ADR eliminates.
"""

# Register the sync-wrapper bridge constant BEFORE loading policy files.
# The _role_in_org_stub.polar file references ``_role_in_org`` as a
# constant; it must be registered before Oso validates the loaded rules.
_oso.register_constant(  # pyright: ignore[reportUnknownMemberType]
    _role_in_org_bridge, name="_role_in_org"
)

# Register the subject row classes by their Polar specializer name BEFORE
# loading policy files. Without these calls Oso emits "Unknown specializer
# <Name>" warnings at policy load time and per-subject rules fall through
# to default-deny — the chokepoint denies every authorize call against a
# specialized rule even when the principal should pass. Independently
# flagged by subject T7, subject T8 (lint #3), engine T9 (E19), and
# verification T8 during Slice 2 development.
#
# The Polar names match the `subject:` value in `policies/*.polar` files
# (e.g. `allow(actor, "read", subject: Organization)`); the Pydantic
# row classes are the Python representation the loaders return. The row
# imports are top-level (see imports block above).
#
# (Subject T8 originally added `polar_specializer_pending:` markers here
# expecting the registration to land in a follow-up PR; #141 and #140
# both shipped the actual `register_class()` calls before T8 merged, so
# those markers were retired in this rebase. T8's lint
# `scripts/check_polar_subject_specializer_registered.py` now validates
# the registrations directly.)
_oso.register_class(OrganizationRow, name="Organization")  # pyright: ignore[reportUnknownMemberType]
_oso.register_class(MembershipRow, name="Membership")  # pyright: ignore[reportUnknownMemberType]
_oso.register_class(NodeRow, name="Node")  # pyright: ignore[reportUnknownMemberType]
_oso.register_class(OrgConfigRow, name="OrgConfig")  # pyright: ignore[reportUnknownMemberType]
_oso.register_class(DelegationRow, name="Delegation")  # pyright: ignore[reportUnknownMemberType]
_oso.register_class(EventSubscriptionRow, name="EventSubscription")  # pyright: ignore[reportUnknownMemberType]
_oso.register_class(ConversationRow, name="Conversation")  # pyright: ignore[reportUnknownMemberType]

# Load all policy files atomically.  Oso 0.27 requires all Polar sources
# to be loaded in a single call.  A syntax error or undefined-rule error
# in any .polar file raises OsoError here, crashing the process at startup
# (per the "Policy load failure at startup" note in this module's docstring).
if _POLICY_FILES:
    _oso.load_files(_POLICY_FILES)  # pyright: ignore[reportUnknownMemberType,reportArgumentType]


# ---------------------------------------------------------------------------
# Accessor for type-annotated access.
# ---------------------------------------------------------------------------


def get_oso() -> Oso:  # pyright: ignore[reportUnknownVariableType, reportReturnType]
    """Return the process-scoped Oso host singleton.

    Equivalent to importing :data:`_oso` directly; provided as a function
    so call sites can write ``oso = get_oso()`` for a named, non-dunder
    reference.  Both forms return the same instance.
    """
    return _oso  # pyright: ignore[reportReturnType]
