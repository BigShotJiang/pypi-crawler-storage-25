"""Subject loaders and the ``SubjectLoader`` Protocol (Slice 2, subject T2).

Per ``docs/slices/slice-2-authorization/subject-vocabulary-and-policies/
03-technical-implementation.md`` § "Subject loaders" and
``05-task-list.md`` § T2.

Each loader is a plain async callable that satisfies the
:class:`SubjectLoader` Protocol: ``(id, principal, conn) -> SubjectRow | None``.
The connection is the **runtime pool connection** (RLS-bound, GUC committed
by ``current_principal``). Per §3.6, loaders run on the runtime pool; the
GUC is already set before any loader is called, so RLS hides rows the
principal cannot see (that is the "not found" signal, not an error).

Design decisions
----------------

**Runtime-checkable Protocol.**  ``SubjectLoader`` is decorated with
``@runtime_checkable`` so ``isinstance(load_organization_by_id,
SubjectLoader)`` returns ``True`` at runtime without an abstract base
class.  Engine T7's ``Depends(authorize)`` can gate-check any injected
loader before invoking it.  The protocol's return type is ``object | None``
(the broadest supertype) because protocol callables cannot express
covariant return specialisation at the definition site; each concrete
loader narrows its return type annotation to the specific ``*Row`` model.

**Storage-to-policy alias boundary.**  Tenant-scoped storage columns are
``tenant_id``. Policy subject rows expose ``organization_id`` only as the
deliberate Polar/product alias, so loaders are the one-way adapter from
storage names to policy names.  ``Organization`` subjects map to the
``tenants`` table and project ``id AS organization_id`` because the
organization row's tenant id is its primary key.

**Membership → memberships table.**  The SELECT includes all columns that
:class:`MembershipRow` declares.  RLS on ``memberships`` (Slice 1,
``memberships_visible_via_tenant`` PERMISSIVE policy) filters rows that
the principal cannot see under the active GUC; a non-visible row returns
``None`` from the loader, which maps to 404 at the chokepoint (engine T7 §
"subject_not_found").

**Node → Slice 3 scaffold.**  ``load_node_by_id`` targets the ``nodes``
table that Slice 3 introduces.  The loader is correct against the Slice 3
schema; it is **unused in any Slice 2 route** — the Slice 2 matrix uses
in-memory :class:`~skaldos.policy.subjects.NodeRow` fixtures.  This is
scaffold-now-wire-later per ``03 § F6``.

**EventSubscription → Slice 8.**  ``load_event_subscription_by_id`` targets
the Slice 8 ``event_subscription`` table and exposes ``tenant_id`` through
the policy-row ``organization_id`` alias. It returns only the fields needed
by the control-plane Oso subject; filter, delivery, and state validation
remain route/service concerns.

**OrgConfig + Delegation → Slice 7 stubs.**  Both loaders raise
:class:`NotImplementedError` with a message naming Slice 7. Calling them
in Slice 2 code is a bug (no Slice 2 route declares these subjects), and
the error surfaces it loudly rather than silently.

References: **MP1** (primitives over subsystems), **§3.6** (loaders are
RLS-bound; runtime pool only), **scaffold-now-wire-later** (Node → Slice 3,
OrgConfig + Delegation → Slice 7), AP5 (no bypass — the ``conn`` must
already have the GUC set; loaders do not issue ``set_config`` themselves).
"""

from typing import Protocol, runtime_checkable
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]

from skaldos.middleware.principal import Principal
from skaldos.policy.subjects import (
    DelegationRow,
    EventSubscriptionRow,
    MembershipRow,
    NodeRow,
    OrganizationRow,
    OrgConfigRow,
)


@runtime_checkable
class SubjectLoader(Protocol):
    """Protocol for subject loaders consumed by the authorization chokepoint.

    A loader is an async callable with the signature::

        async def load_X_by_id(
            id: UUID,
            principal: Principal,
            conn: asyncpg.Connection,
        ) -> SomeSubjectRow | None: ...

    The ``conn`` must already carry the ``app.current_principal_id`` and
    ``app.current_principal_visible`` GUCs (committed by
    ``current_principal`` before any loader is called per §3.6).  Loaders
    never call ``set_config`` themselves — that is AP5 territory.

    The Protocol's return type is ``object | None`` to accommodate the five
    distinct ``*Row`` subtypes; each concrete loader narrows its return
    annotation to its specific type.

    Runtime-checkable so ``isinstance(fn, SubjectLoader)`` works at module
    import time (engine T7 uses this to validate injected loaders).
    """

    async def __call__(
        self,
        id: UUID,
        principal: Principal,
        conn: asyncpg.Connection,  # pyright: ignore[reportUnknownVariableType]
    ) -> object | None: ...


# ---------------------------------------------------------------------------
# Active loaders — wired in Slice 2
# ---------------------------------------------------------------------------


async def load_organization_by_id(
    id: UUID,
    principal: Principal,
    conn: asyncpg.Connection,  # pyright: ignore[reportUnknownVariableType]
) -> OrganizationRow | None:
    """Load an :class:`~skaldos.policy.subjects.OrganizationRow` by ``id``.

    SELECTs from ``tenants`` (the canonical organization storage per Slice
    1's schema feature + master-plan § "Shared artifacts & contracts").
    Projects ``id AS organization_id`` so the returned row satisfies every
    Polar rule that reads ``subject.organization_id``; both ``id`` and
    ``organization_id`` carry the same value (the org *is* the tenant).

    RLS-bound: the ``conn`` must have the GUC committed.  A tenant the
    principal cannot see (because their ``visible_tenant_ids`` does not
    include it) returns ``None`` — the RLS policy on ``tenants`` filters
    it out.  The chokepoint maps ``None`` to a 404.

    Column mapping notes:
    - ``region`` is storage-backed as of Slice 8's external Pub/Sub posture.
      ``disabled_at`` remains scaffold-now-wire-later on
      :class:`~skaldos.policy.subjects.OrganizationRow`; the SELECT supplies
      ``NULL::timestamptz`` for ``disabled_at`` until the tenant lifecycle
      slice wires it.

    Per §3.6 (runtime pool only) + ``03 § Subject loaders``.
    """
    row = (  # pyright: ignore[reportUnknownVariableType]
        await conn.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            "SELECT id, id AS organization_id, display_name, "
            "region, "
            "created_at, "
            "NULL::timestamptz AS disabled_at "
            "FROM tenants WHERE id = $1",
            id,
        )
    )
    if row is None:
        return None
    return OrganizationRow(**dict(row))  # pyright: ignore[reportUnknownArgumentType]


async def load_membership_by_id(
    id: UUID,
    principal: Principal,
    conn: asyncpg.Connection,  # pyright: ignore[reportUnknownVariableType]
) -> MembershipRow | None:
    """Load a :class:`~skaldos.policy.subjects.MembershipRow` by ``id``.

    SELECTs from ``memberships``.  RLS on ``memberships`` (the
    ``memberships_visible_via_tenant`` policy) filters rows that belong to
    a tenant the principal cannot see.  A member requesting their *own*
    membership row is visible because the tenant is in their
    ``visible_tenant_ids``; a cross-tenant membership row returns ``None``.

    Column mapping notes:
    - The ``memberships`` table uses ``tenant_id`` (Slice 1 schema); the
      :class:`~skaldos.policy.subjects.MembershipRow` model exposes
      ``organization_id`` (the uniform Polar accessor).  The SELECT aliases
      ``tenant_id AS organization_id`` to bridge storage into the policy
      alias; the alias does not imply a storage column named
      ``organization_id``.
    - ``max_clearance`` is a scaffold-now-wire-later field on
      :class:`~skaldos.policy.subjects.MembershipRow` (Slice 6+ semantic).
      The column does not yet exist in the ``memberships`` schema; the
      SELECT supplies ``NULL::text`` so the Pydantic model gets ``None``
      without a missing-column error.  Slice 6 adds the real column and
      drops the ``NULL::text`` literal.

    Per §3.6 + ``03 § Subject loaders``.
    """
    row = (  # pyright: ignore[reportUnknownVariableType]
        await conn.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            "SELECT id, tenant_id AS organization_id, principal_id, role, "
            "max_clearance, created_at, revoked_at "
            "FROM memberships WHERE id = $1",
            id,
        )
    )
    if row is None:
        return None
    return MembershipRow(**dict(row))  # pyright: ignore[reportUnknownArgumentType]


# ---------------------------------------------------------------------------
# Scaffold-now-wire-later: Node (Slice 3)
# ---------------------------------------------------------------------------


async def load_node_by_id(
    id: UUID,
    principal: Principal,
    conn: asyncpg.Connection,  # pyright: ignore[reportUnknownVariableType]
) -> NodeRow | None:
    """Load a :class:`~skaldos.policy.subjects.NodeRow` by ``id``.

    Targets the ``nodes`` table introduced in Slice 3.  This loader is
    **unused in any Slice 2 route** — the Slice 2 authorization matrix
    constructs :class:`~skaldos.policy.subjects.NodeRow` instances
    directly (no DB call required).

    Storage uses ``tenant_id``; the SELECT aliases it to
    ``organization_id`` because Polar subject rows keep that compatibility
    accessor.

    Slice 3 activates this loader when the ``nodes`` migration lands.
    """
    row = (  # pyright: ignore[reportUnknownVariableType]
        await conn.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            "SELECT id, tenant_id AS organization_id, type_id::text AS type, "
            "authored_by_principal_id AS created_by_principal_id, created_at "
            "FROM nodes WHERE id = $1",
            id,
        )
    )
    if row is None:
        return None
    return NodeRow(**dict(row))  # pyright: ignore[reportUnknownArgumentType]


# ---------------------------------------------------------------------------
# Stubs — wired in Slice 7
# ---------------------------------------------------------------------------


async def load_org_config_by_id(
    id: UUID,
    principal: Principal,
    conn: asyncpg.Connection,  # pyright: ignore[reportUnknownVariableType]
) -> OrgConfigRow | None:
    """Stub loader for :class:`~skaldos.policy.subjects.OrgConfigRow`.

    Raises :class:`NotImplementedError` with a Slice 7 message.  Calling
    this in Slice 2 code is a bug — no Slice 2 route declares
    ``AppSubject.ORG_CONFIG``; the error surfaces misuse loudly per the
    error-management plan in ``03 § Error-management plan``
    (``event="loader.not_implemented", subject_kind="OrgConfig"``).

    Wired in Slice 7 when the ``org_agent_config`` table lands
    (per ``feature-catalog.md`` § A4).
    """
    raise NotImplementedError(
        "wired in Slice 7 — org_agent_config table per feature-catalog.md § A4"
    )


async def load_delegation_by_id(
    id: UUID,
    principal: Principal,
    conn: asyncpg.Connection,  # pyright: ignore[reportUnknownVariableType]
) -> DelegationRow | None:
    """Stub loader for :class:`~skaldos.policy.subjects.DelegationRow`.

    Raises :class:`NotImplementedError` with a Slice 7 message.  Calling
    this in Slice 2 code is a bug — no Slice 2 route declares
    ``AppSubject.DELEGATION``; the error surfaces misuse loudly per the
    error-management plan in ``03``.

    Wired in Slice 7 when the ``delegations`` table + JWT ``act`` claim
    land (per ADR + MP10).
    """
    raise NotImplementedError(
        "wired in Slice 7 — delegations table per ADR + JWT 'act' claim per MP10"
    )


async def load_event_subscription_by_id(
    id: UUID,
    principal: Principal,
    conn: asyncpg.Connection,  # pyright: ignore[reportUnknownVariableType]
) -> EventSubscriptionRow | None:
    """Load an external :class:`~skaldos.policy.subjects.EventSubscriptionRow`.

    Storage uses ``tenant_id``; policy rows expose ``organization_id`` for
    Oso consistency. RLS on ``event_subscription`` filters inaccessible
    rows, so foreign IDs return ``None`` through the normal not-found path.
    """
    row = (  # pyright: ignore[reportUnknownVariableType]
        await conn.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            "SELECT id, tenant_id AS organization_id, subscriber_principal_id "
            "FROM event_subscription WHERE id = $1",
            id,
        )
    )
    if row is None:
        return None
    return EventSubscriptionRow(**dict(row))  # pyright: ignore[reportUnknownArgumentType]
