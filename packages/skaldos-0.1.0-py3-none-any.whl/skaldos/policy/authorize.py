"""``Depends(authorize(...))`` chokepoint (Slice 2, engine T7 + rate-limit T4).

Per ``docs/slices/slice-2-authorization/policy-module-and-chokepoint/``
``03-technical-implementation.md`` § "Module layout" → ``authorize.py`` and
``05-task-list.md`` § T7; plus rate-limit T4
``docs/slices/slice-2-authorization/tiered-rate-limiter/05-task-list.md``
§ T4 (exception handler extension).

The ``authorize`` function returns a FastAPI ``Depends(...)`` whose inner
async function is the request-time authorization chokepoint. Routes declare:

.. code-block:: python

    from skaldos.policy import authorize

    @router.get(
        "/memberships/{membership_id}",
        responses={**PROTECTED_ROUTE_RESPONSES, 404: {"description": "Not found."}},
    )
    async def get_membership(
        membership: MembershipRow = Depends(
            authorize("read", AppSubject.MEMBERSHIP, subject_loader=load_membership_by_id)
        ),
        principal: Principal = Depends(current_principal),
    ) -> MembershipResponse:
        ...

The inner function runs **after** ``Depends(current_principal)`` in the
FastAPI dependency chain (per ``03 § Architecture``).

Chokepoint flow
---------------

Per ``03 § Architecture``:

1. **Pre-hook** — ``app.state.authorize_pre_hooks`` if present (engine T8
   wires this; T7 reads it and no-ops if absent).
2. **Intent validation** — if ``intent`` is required by ``ALLOWED_INTENTS``
   and is absent, raise :class:`IntentRequiredError`; if supplied but wrong,
   raise :class:`IntentNotAllowedError`.
3. **Subject loading** — if ``subject_loader`` is provided, call it with
   ``(subject_id, principal, conn)`` and 404 on ``None``
   (:class:`SubjectNotFoundError`).
4. **Target tenant extraction** — if ``target_tenant_loader`` is provided
   (for ``create`` actions), call to extract the target tenant UUID from the
   request.
5. **Oso evaluation** — ``_oso.is_allowed(principal, action, subject_or_kind)``;
   on ``False`` raise :class:`AuthorizationError`.
6. **Log emission** — one ``authorization.decision`` structured log line
   (placeholder per ``03 § F8``; engine T8 deepens this).
7. **Return** — the loaded subject (or ``None`` for ``create`` actions /
   routes without ``subject_loader``).

``_authorize_meta`` attribute
-------------------------------

The inner async function stores an :class:`AuthorizeMeta` dataclass on
``_inner._authorize_meta`` so that:

- :func:`~skaldos.policy.intent.validate_intent_table_consistency` can
  inspect the factory's parameters at startup.
- The engine T9 lint ``scripts/check_protected_routes_carry_responses.py``
  can detect ``Depends(authorize)``-carrying routes.

Exception handler
-----------------

``register_authorization_exception_handlers(app)`` registers FastAPI
exception handlers that map:

- :class:`~skaldos.policy.rate_limit.errors.RateLimitExceeded` → 429 + ``Retry-After``
  (rate-limit T4 extension — registered **first** so it short-circuits before
  the broader ``AuthorizationError`` handler; ``RateLimitExceeded`` is NOT a
  subclass of ``AuthorizationError`` so there is no MRO collision here).
- :class:`AuthorizationError` → 403
- :class:`IntentRequiredError` → 422
- :class:`IntentNotAllowedError` → 422
- :class:`SubjectNotFoundError` → 404

Routes should call ``register_authorization_exception_handlers`` on their
``FastAPI`` instance (wired by ``app.py`` in ``create_app()``).

References: §4.1 (authorization is a primitive); §4.5 (subject-derived
ownership); §10.12 (intent required on writes); §14.7 (rate-limit 429);
ADR 2 (Oso); AP5 (no bypass); MP1 (primitives); MP10 (humans + agents
equal); ``03-technical-implementation.md`` § "Module layout",
§ "Architecture", § "Fault lines" F1, F4, F5, F8;
``02-edge-cases.md`` E3, E5, E6, E7.
"""

from __future__ import annotations

import dataclasses
import inspect
from collections.abc import Awaitable, Callable
from typing import TYPE_CHECKING, Any
from uuid import UUID

from fastapi import Depends, Request
from opentelemetry import trace
from skaldos_log import log

from skaldos.middleware.hydration import current_principal
from skaldos.middleware.principal import Principal
from skaldos.policy.errors import (
    AuthorizationError,
    IntentNotAllowedError,
    IntentRequiredError,
    PolicyEvaluationError,
    ReasonCode,
    SubjectNotFoundError,
)
from skaldos.policy.hooks import get_authorize_pre_hooks
from skaldos.policy.host import _oso
from skaldos.policy.intent import ALLOWED_INTENTS
from skaldos.policy.responses import AuthorizationErrorResponse, IntentErrorResponse
from skaldos.policy.subjects import (
    AppSubject,
    ConversationRow,
    DelegationRow,
    EventSubscriptionRow,
    MembershipRow,
    NodeRow,
    OrganizationRow,
    OrgConfigRow,
    Subject,
)

if TYPE_CHECKING:
    from datetime import datetime as _datetime

    from fastapi import FastAPI

    from skaldos.policy.intent import ActionLiteral, Intent
    from skaldos.policy.loaders import SubjectLoader
    from skaldos.policy.rate_limit.tier import Tier


# ---------------------------------------------------------------------------
# Synthetic subject for create-action chokepoint flow (Slice 2 followups #12).
#
# When a route declares ``target_tenant_loader=...`` but no
# ``subject_loader=...`` (the canonical create shape: there's no row to
# load yet — the subject is about to be created in the target tenant),
# the chokepoint fabricates a minimal subject row carrying
# policy alias ``organization_id = target_tenant_id`` and feeds it to Oso.  Polar's
# per-subject ``create`` rules read ``subject.organization_id`` to call
# ``has_role_in_org(actor, role, subject.organization_id)``; without a
# real row the bare ``AppSubject.<KIND>`` enum couldn't supply that
# attribute and every create-action denied (the surface that surfaced
# followup #12).
#
# The synthetic row is a fully-typed Pydantic instance so Oso's
# ``register_class`` dispatch matches the per-subject rules.  Fields
# the ``create`` rules don't read are set to safe sentinel values:
#
# - UUIDs that Polar might inadvertently read are zero UUIDs (clearly
#   non-real; appears only on the deny path's audit trail).
# - String-typed fields (``role``, ``type``, ``display_name``,
#   ``region``) are empty strings.
# - Datetime-typed fields use the Unix epoch so any defensive
#   ``created_at`` comparisons fail fast in a recognisable way.
# - Nullable fields default to ``None``.
#
# A future refactor that adds a Polar rule reading another column for a
# create-action would need to either (a) extend the synthesis to
# populate that field meaningfully, or (b) move the rule's logic into
# the rule's pre-create handler — either choice is a deliberate edit.
# The unit tests at ``tests/unit/policy/test_authorize_synthetic_subject.py``
# pin the per-subject shape.
# ---------------------------------------------------------------------------


_SYNTHETIC_UUID = UUID("00000000-0000-0000-0000-000000000000")


def _epoch() -> _datetime:
    """Lazily import :mod:`datetime` so the module's import is cheap.

    Used only by :func:`_build_synthetic_subject`; production-path imports
    (request-time hot path) don't pay the import cost.
    """
    from datetime import UTC, datetime

    return datetime(1970, 1, 1, tzinfo=UTC)


SyntheticSubjectLoader = Callable[[Request, UUID], Subject | Awaitable[Subject]]


def _build_synthetic_subject(
    subject_kind: AppSubject,
    target_tenant_id: UUID,
    *,
    role: str = "",
    principal_id: UUID = _SYNTHETIC_UUID,
    max_clearance: str | None = None,
) -> Subject:
    """Build a typed subject row carrying ``organization_id = target_tenant_id``.

    Used by the chokepoint when a route has ``target_tenant_loader`` but
    no ``subject_loader`` (create actions; no existing row).  Polar's
    per-subject ``create`` rules read ``subject.organization_id``; the
    synthetic row supplies it.

    Returns a real Pydantic row instance for Oso's per-subject
    ``register_class`` dispatch.  Non-load-bearing fields are sentinel
    values; see the module-level synthesis comment for the rationale.

    Raises :class:`AssertionError` for unknown subject kinds — the
    :class:`AppSubject` enum is exhaustive in the static type-system,
    but defensive in case a new member is added without a matching
    branch.
    """
    epoch = _epoch()

    if subject_kind == AppSubject.ORGANIZATION:
        return OrganizationRow(
            id=target_tenant_id,
            organization_id=target_tenant_id,
            display_name="",
            region="",
            created_at=epoch,
            disabled_at=None,
        )
    if subject_kind == AppSubject.MEMBERSHIP:
        return MembershipRow(
            id=_SYNTHETIC_UUID,
            organization_id=target_tenant_id,
            principal_id=principal_id,
            role=role,
            max_clearance=max_clearance,
            created_at=epoch,
            revoked_at=None,
        )
    if subject_kind == AppSubject.NODE:
        return NodeRow(
            id=_SYNTHETIC_UUID,
            organization_id=target_tenant_id,
            type="",
            created_by_principal_id=_SYNTHETIC_UUID,
            created_at=epoch,
        )
    if subject_kind == AppSubject.ORG_CONFIG:
        return OrgConfigRow(
            id=_SYNTHETIC_UUID,
            organization_id=target_tenant_id,
        )
    if subject_kind == AppSubject.DELEGATION:
        return DelegationRow(
            id=_SYNTHETIC_UUID,
            organization_id=target_tenant_id,
            delegator_principal_id=_SYNTHETIC_UUID,
            delegatee_principal_id=_SYNTHETIC_UUID,
        )
    if subject_kind == AppSubject.EVENT_SUBSCRIPTION:
        return EventSubscriptionRow(
            id=_SYNTHETIC_UUID,
            organization_id=target_tenant_id,
            subscriber_principal_id=_SYNTHETIC_UUID,
        )
    if subject_kind == AppSubject.CONVERSATION:
        return ConversationRow(
            id=_SYNTHETIC_UUID,
            organization_id=target_tenant_id,
            requester_principal_id=_SYNTHETIC_UUID,
            requestee_principal_id=_SYNTHETIC_UUID,
        )
    raise AssertionError(f"unknown subject_kind: {subject_kind!r}")


__all__ = [
    "authorize",
    "AuthorizeMeta",
    "PolicyEvaluationError",
    "register_authorization_exception_handlers",
    "register_route_tiers",
]


# ---------------------------------------------------------------------------
# AuthorizeMeta — metadata attached to the inner Depends function.
# ---------------------------------------------------------------------------


@dataclasses.dataclass(frozen=True)
class AuthorizeMeta:
    """Metadata about a single ``Depends(authorize(...))`` invocation.

    Attached to ``_inner._authorize_meta`` by the ``authorize`` factory.
    Consumed by:

    - :func:`~skaldos.policy.intent.validate_intent_table_consistency`
      (startup-time intent-table consistency check, F3).
    - Engine T9's ``scripts/check_protected_routes_carry_responses.py``
      (lint that asserts every protected route carries
      ``responses=PROTECTED_ROUTE_RESPONSES``).

    Per ``03 § Module layout`` + ``03 § F3``.
    """

    action: ActionLiteral
    subject_kind: AppSubject
    intent: Intent | None
    has_subject_loader: bool
    has_target_tenant_loader: bool
    tier: Tier
    """The rate-limit tier the route declares (Slice 2 followups #4).

    Stamped on the route's :class:`fastapi.routing.APIRoute` instance as
    ``route.tier`` by :func:`register_route_tiers` at startup.  The
    rate-limit pre-hook reads ``route.tier`` (via
    :func:`~skaldos.policy.rate_limit.tier.classify_route`) to pick the
    per-tier per-minute limit.  Routes that do not declare ``tier=``
    explicitly default to :data:`~skaldos.policy.rate_limit.tier.Tier.STANDARD`.
    """


# ---------------------------------------------------------------------------
# authorize factory
# ---------------------------------------------------------------------------


def authorize(
    action: ActionLiteral,
    subject_kind: AppSubject,
    intent: Intent | None = None,
    subject_loader: SubjectLoader | None = None,
    target_tenant_loader: Callable[[Request], UUID | Awaitable[UUID]] | None = None,
    synthetic_subject_loader: SyntheticSubjectLoader | None = None,
    tier: Tier | None = None,
) -> Any:
    """Return a FastAPI ``Depends(...)`` for the authorization chokepoint.

    Each call to ``authorize(...)`` at route-registration time creates a
    unique inner async function that captures the factory arguments.  The
    inner function is the actual FastAPI dependency that runs per-request.

    Parameters
    ----------
    action:
        The action the principal is requesting.  Must be one of the 12
        closed actions in ``ActionLiteral`` (``read``, ``create``, ...).
        Typos fail at pyright time; the Literal type gates values at
        type-check, not runtime.
    subject_kind:
        The kind of subject being acted upon.  Must be an :class:`AppSubject`
        member.
    intent:
        The Searle illocutionary act type for write routes.  Required when
        ``ALLOWED_INTENTS[(action, subject_kind)]`` is populated.  Omit for
        read routes (no intent gate).
    subject_loader:
        Optional callable satisfying the :class:`SubjectLoader` Protocol.
        When provided, the inner function loads the subject by ID extracted
        from ``request.path_params["id"]`` (or the first UUID path param).
        If the loader returns ``None``, the chokepoint raises
        :class:`SubjectNotFoundError` (→ 404).
    target_tenant_loader:
        Optional ``Callable[[Request], UUID]`` for ``create`` actions where
        no pre-existing subject row exists.  Called to extract the target
        tenant UUID from the request body/params.  Coexists with
        ``subject_loader``.

    Returns
    -------
    The result of ``Depends(_inner)`` where ``_inner`` is the inner async
    function.  FastAPI injects the dependency at request time.

    Notes
    -----
    The inner function stores :class:`AuthorizeMeta` on
    ``_inner._authorize_meta`` for startup-time validation.

    Per ``03 § Module layout``; §4.1; §4.5; §10.12; ADR 2; AP5.
    """

    async def _inner(
        request: Request,
        principal: Principal = Depends(current_principal),  # noqa: B008
    ) -> Subject | None:
        """Per-request authorization chokepoint.

        Runs after ``Depends(current_principal)`` in FastAPI's dependency
        graph.  Steps:

        1. Open OTel child span ``policy.authorize`` (engine T8; §20.4).
        2. Pre-hooks via :func:`~skaldos.policy.hooks.get_authorize_pre_hooks`
           in priority order (engine T8 wires the accessor; rate-limiter
           mounts at priority 1 per §14.7).
        3. Intent validation.
        4. Subject loading via ``subject_loader`` (if provided).
        5. Target tenant extraction via ``target_tenant_loader`` (if provided).
        6. Oso evaluation.
        7. Log emission — ONE ``authorization.decision`` line INSIDE the span
           (§20.4 active-span enforcement; §20.1 safelisted fields only;
           §20.2 PII discipline — no ``verified_claims``, ``auth0_sub``,
           raw email).
        8. Return loaded subject (or ``None``).
        """
        tracer = trace.get_tracer(__name__)
        with tracer.start_as_current_span(
            "policy.authorize",
            attributes={
                "authorization.action": action,
                "authorization.subject_kind": str(subject_kind),
            },
        ) as span:
            # --- Step 2: Pre-hooks -------------------------------------------
            # get_authorize_pre_hooks returns hooks sorted by priority (lowest
            # first). Returns empty list when no hooks registered.
            for hook in get_authorize_pre_hooks(request.app):
                await hook(request, principal)

            # --- Step 3: Intent validation ------------------------------------
            allowed_intents = ALLOWED_INTENTS.get((action, subject_kind))  # type: ignore[arg-type]
            if allowed_intents is not None:
                # This (action, subject_kind) pair requires an intent.
                if intent is None:
                    raise IntentRequiredError(
                        principal_id=principal.id,
                        action=action,
                        subject_kind=subject_kind,
                    )
                if intent not in allowed_intents:
                    raise IntentNotAllowedError(
                        principal_id=principal.id,
                        action=action,
                        subject_kind=subject_kind,
                        intent=intent,
                    )

            # --- Step 4: Subject loading --------------------------------------
            loaded_subject: Subject | None = None
            subject_id: UUID | None = None

            if subject_loader is not None:
                # Extract the subject ID from path params.
                # Prefer 'id' param; fall back to first UUID-valued path param.
                conn = getattr(request.state, "connection", None)
                raw_id = request.path_params.get("id")
                if raw_id is None:
                    # Try the first path param that looks like a UUID
                    for _key, val in request.path_params.items():
                        try:
                            raw_id = str(UUID(str(val)))
                            break
                        except (ValueError, AttributeError):
                            continue

                if raw_id is not None:
                    try:
                        subject_id = UUID(str(raw_id))
                    except (ValueError, AttributeError):
                        subject_id = None

                if subject_id is not None:
                    loaded_subject = await subject_loader(  # type: ignore[assignment]
                        subject_id,
                        principal,
                        conn,  # type: ignore[arg-type]
                    )
                    if loaded_subject is None:
                        raise SubjectNotFoundError(
                            principal_id=principal.id,
                            action=action,
                            subject_kind=subject_kind,
                            subject_id=subject_id,
                        )

            # --- Step 5: Target tenant extraction ----------------------------
            _target_tenant_id: UUID | None = None
            if target_tenant_loader is not None:
                _maybe_awaitable = target_tenant_loader(request)
                if inspect.isawaitable(_maybe_awaitable):
                    _target_tenant_id = await _maybe_awaitable
                else:
                    _target_tenant_id = _maybe_awaitable

            # --- Step 6: Oso evaluation ---------------------------------------
            # Polar's ``has_role_in_org`` predicate is a pure-Python lookup
            # against ``principal.role_assignments`` — pre-resolved by the
            # ``current_principal`` hydration step (Slice 2 followups #1).
            # The historical bridge attached the runtime conn to the
            # principal here so an async resolver could fire from inside
            # sync Oso eval; that pattern carried a loop-mismatch bug class
            # and is gone.

            # The subject passed to Oso.  Resolution order:
            # 1. The loaded subject row (when ``subject_loader`` is wired).
            # 2. A synthetic subject row carrying ``organization_id =
            #    _target_tenant_id`` (when ``target_tenant_loader`` is wired
            #    but ``subject_loader`` isn't — the canonical create-action
            #    shape; followup #12).  Polar's per-subject ``create`` rules
            #    read ``subject.organization_id`` to evaluate
            #    ``has_role_in_org(actor, role, subject.organization_id)``;
            #    without the synthesis, the bare ``AppSubject`` enum lacks
            #    that attribute and every create-action denied.
            # 3. The bare ``subject_kind`` enum, for routes that wire
            #    neither loader (e.g. ``organization_create`` — the policy
            #    ships no allow rule for create-Organization, so the
            #    open-world combinator denies regardless).
            oso_subject: Any
            if loaded_subject is not None:
                oso_subject = loaded_subject
            elif _target_tenant_id is not None:
                if synthetic_subject_loader is not None:
                    _maybe_subject = synthetic_subject_loader(request, _target_tenant_id)
                    if inspect.isawaitable(_maybe_subject):
                        oso_subject = await _maybe_subject
                    else:
                        oso_subject = _maybe_subject
                else:
                    oso_subject = _build_synthetic_subject(subject_kind, _target_tenant_id)
            else:
                oso_subject = subject_kind

            try:
                allowed = _oso.is_allowed(  # pyright: ignore[reportUnknownMemberType]
                    principal, action, oso_subject
                )
            except Exception:  # noqa: BLE001
                # Oso failures are not policy denies. Fail closed with a
                # distinct service-error contract so operators can distinguish
                # engine failures from legitimate 403 decisions.
                log.exception(
                    "authorization.oso_eval_error",
                    action=action,
                    subject_kind=str(subject_kind),
                )
                raise PolicyEvaluationError(
                    principal_id=principal.id,
                    action=action,
                    subject_kind=subject_kind,
                    subject_id=subject_id,
                    intent=intent,
                ) from None

            # --- Step 6b: Reason-code routing on deny (Slice 2 followups #15) ---
            # The runbook (`docs/runbooks/authorization-debug.md` § "Reason
            # codes") distinguishes two deny remediation paths:
            #
            # - ``principal_role_insufficient_for_action`` — principal has
            #   *some* role in the target tenant; the role just isn't high
            #   enough for this action.  Remediation: grant a higher
            #   membership role.
            # - ``principal_lacks_role_in_tenant`` — principal has **no**
            #   membership in the target tenant at all (the cross-tenant
            #   shape).  Remediation: grant a membership in the target
            #   tenant.
            #
            # Pre-fix the chokepoint always emitted the former, making the
            # latter unreachable and the runbook's pivot table wrong on
            # every cross-tenant deny.  Post-fix we resolve the target
            # tenant from the loaded subject (when ``subject_loader`` is
            # wired), the explicit target-tenant loader's UUID (the create
            # shape — followup #12), and check whether
            # ``principal.role_assignments`` carries any entry for that
            # tenant.  Bare-enum subject paths (no loader; e.g.
            # ``organization_create``) supply no tenant context for the
            # role-presence check, so the broader
            # ``principal_role_insufficient_for_action`` is the safe
            # default — the runbook treats it as the catch-all when
            # tenant context is unavailable.
            reason: ReasonCode | None = None
            if not allowed:
                target_tenant_id_for_routing: UUID | None
                if loaded_subject is not None:
                    target_tenant_id_for_routing = getattr(loaded_subject, "organization_id", None)
                elif _target_tenant_id is not None:
                    target_tenant_id_for_routing = _target_tenant_id
                else:
                    target_tenant_id_for_routing = None

                if target_tenant_id_for_routing is not None and not any(
                    t == target_tenant_id_for_routing for t, _role in principal.role_assignments
                ):
                    reason = ReasonCode.principal_lacks_role_in_tenant
                else:
                    reason = ReasonCode.principal_role_insufficient_for_action

            # --- Step 7: Log emission ----------------------------------------
            # ONE structured log line inside the active OTel span (§20.4).
            # Safelisted fields only: action, subject_kind, subject_id, intent,
            # decision, reason_code, principal_id (§20.1, §20.2).
            # Do NOT emit: verified_claims, auth0_sub, raw email, or any
            # field not in the safelisted set.
            decision = "allowed" if allowed else "denied"
            _log_fields: dict[str, Any] = {
                "action": action,
                "subject_kind": str(subject_kind),
                "decision": decision,
                "principal_id": str(principal.id),
            }
            if subject_id is not None:
                _log_fields["subject_id"] = str(subject_id)
            if intent is not None:
                _log_fields["intent"] = intent.value
            if reason is not None:
                _log_fields["reason_code"] = str(reason)
            log.info("authorization.decision", **_log_fields)

            # Annotate the span with the decision (after log so span is still
            # open for §20.4 enforcement).
            span.set_attribute("authorization.decision", decision)

            if not allowed:
                # ``reason`` is non-None whenever ``allowed`` is False — the
                # routing block above mirrors the deny branch.  The
                # ``assert`` is defensive; pyright sees ``reason`` as
                # potentially ``None`` because the type doesn't carry the
                # ``not allowed`` correlation.
                assert reason is not None
                raise AuthorizationError(
                    reason=reason,
                    principal_id=principal.id,
                    action=action,
                    subject_kind=subject_kind,
                    subject_id=subject_id,
                    intent=intent,
                )

            # --- Step 8: Return ----------------------------------------------
            return loaded_subject

    # Attach metadata for startup-time validation and lint tools.
    # ``tier`` defaults to :data:`Tier.STANDARD` (the §14.7 default tier;
    # the route-startup hook copies it onto ``route.tier`` so the
    # rate-limit pre-hook's :func:`classify_route` reads a real value).
    from skaldos.policy.rate_limit.tier import Tier as _Tier  # noqa: PLC0415

    resolved_tier = tier if tier is not None else _Tier.STANDARD
    _inner._authorize_meta = AuthorizeMeta(  # type: ignore[attr-defined]
        action=action,
        subject_kind=subject_kind,
        intent=intent,
        has_subject_loader=subject_loader is not None,
        has_target_tenant_loader=target_tenant_loader is not None,
        tier=resolved_tier,
    )

    return Depends(_inner)


# ---------------------------------------------------------------------------
# Route-tier registration (Slice 2 followups #4).
#
# The lint at ``scripts/check_rate_limit_tier_attribute.py`` and the
# rate-limit pre-hook's :func:`classify_route` both read ``route.tier`` on
# ``fastapi.routing.APIRoute`` instances.  ``authorize()`` stamps the
# resolved tier on the inner callable's ``_authorize_meta`` at decoration
# time; the FastAPI ``APIRoute`` is constructed *later* (when the router
# is included on the app), and ``route.tier`` doesn't exist by default.
#
# :func:`register_route_tiers` walks the registered routes once at startup
# and copies ``meta.tier`` onto ``route.tier`` for every route whose
# dependency tree carries an ``_authorize_meta`` marker.  Routes without
# the marker (public routes, ``/whoami``) are left alone — the lint
# already only inspects ``Depends(authorize)``-bearing routes.
# ---------------------------------------------------------------------------


def register_route_tiers(app: FastAPI) -> None:
    """Stamp ``route.tier`` on every ``Depends(authorize(...))``-bearing route.

    Call once at app-assembly time after every router is included.
    Every protected route's :class:`fastapi.routing.APIRoute` instance
    receives a ``tier`` attribute equal to the route's
    :attr:`AuthorizeMeta.tier` value (``Tier.STANDARD`` by default; per
    the ``authorize(..., tier=Tier.X)`` kwarg otherwise).

    Idempotent: re-applying the same tier value is a no-op.  The lint at
    ``scripts/check_rate_limit_tier_attribute.py`` walks
    ``app.routes`` post-startup and asserts ``route.tier`` is present and
    is a :class:`Tier` member; this hook is what makes the assertion hold
    structurally, rather than via the
    :func:`~skaldos.policy.rate_limit.tier.classify_route` belt-and-
    suspenders fallback.

    Routes that don't carry ``_authorize_meta`` (public routes such as
    ``/health`` / ``/readyz`` / ``/openapi.json``, plus the Slice 1
    ``/whoami`` route which uses bare ``Depends(current_principal)``) are
    skipped — they're not subject to the §14.7 tier classification.
    """
    from fastapi.routing import APIRoute  # noqa: PLC0415

    from skaldos.policy._dependant_walk import find_authorize_meta  # noqa: PLC0415

    for route in app.routes:
        if not isinstance(route, APIRoute):
            continue
        meta = find_authorize_meta(route)
        if meta is None:
            continue
        route.tier = meta.tier  # type: ignore[attr-defined]


# ---------------------------------------------------------------------------
# Exception handlers
# ---------------------------------------------------------------------------


def register_authorization_exception_handlers(app: FastAPI) -> None:
    """Register FastAPI exception handlers for authorization error types.

    Maps:

    - :class:`~skaldos.policy.rate_limit.errors.RateLimitExceeded` → 429
      with :class:`~skaldos.policy.rate_limit.responses.RateLimitErrorResponse`
      + ``Retry-After`` header (rate-limit T4 extension).
    - :class:`SubjectNotFoundError` → 404 with ``{"error_code": "not_found"}``
    - :class:`IntentRequiredError` → 422 with :class:`IntentErrorResponse`
    - :class:`IntentNotAllowedError` → 422 with :class:`IntentErrorResponse`
    - :class:`AuthorizationError` → 403 with :class:`AuthorizationErrorResponse`

    **Order matters:** the subclass handlers must be registered BEFORE the
    base ``AuthorizationError`` handler because FastAPI's exception-handler
    lookup is exact-type first, then walks the MRO.  We register the most
    specific subclasses first so they short-circuit before the base handler.

    ``RateLimitExceeded`` is NOT a subclass of ``AuthorizationError`` so
    there is no MRO collision; it is registered first (before the
    ``AuthorizationError``-hierarchy chain) as belt-and-suspenders.

    Call this once in ``create_app()`` after constructing the
    :class:`fastapi.FastAPI` instance.

    Audit-log emission asymmetry (followup #16)
    -------------------------------------------

    The four handlers below have an intentionally asymmetric relationship
    to ``_inner``'s Step 7 ``authorization.decision`` emit:

    ====================================  ==================  =======================
    Failure mode                          Raises in ``_inner``  Handler emits log line
    ====================================  ==================  =======================
    ``IntentRequiredError``               Step 3 (pre-Step 7) ``authorization.intent_missing``
    ``IntentNotAllowedError``             Step 3 (pre-Step 7) ``authorization.intent_rejected``
    ``SubjectNotFoundError``              Step 4 (pre-Step 7) ``authorization.subject_not_found``
    ``AuthorizationError`` (Oso deny)     Step 7 (post-emit)  *(none — inner emit is canonical)*
    ====================================  ==================  =======================

    The first three failure modes raise *before* Step 7's
    ``log.info("authorization.decision", ...)`` runs, so the inner emit
    never fires for them — the handler's structured log line is the only
    one.  The Oso-deny path raises *after* Step 7's emit (the inner
    function logs ``authorization.decision`` then raises
    :class:`AuthorizationError`); the handler therefore emits **no** log
    line, because the inner record is more complete (it carries
    ``principal_id``, ``subject_id``, ``intent`` — fields the handler
    can't see from the exception alone).  Followup #16 corrected this:
    a previous version had the handler re-emit ``authorization.decision``
    with a thinner field set, doubling the audit-log volume on every
    deny.  The 403 response itself remains the HTTP-tier observability
    surface for "we sent the 403"; structured logs aren't the right
    place for that.

    Parameters
    ----------
    app:
        The :class:`fastapi.FastAPI` instance to attach the handlers to.

    Per ``03 § Error-management plan``; §10.2; §13.4 (audit chain;
    deny is one record, not two); §14.7 (rate-limit T4);
    master-plan § "Shared artifacts" → exception handlers.
    """
    from fastapi import Request as _Request
    from fastapi.responses import JSONResponse as _JSONResponse

    from skaldos.policy.rate_limit.errors import RateLimitExceeded as _RateLimitExceeded
    from skaldos.policy.rate_limit.responses import (
        RateLimitErrorResponse as _RateLimitErrorResponse,
    )

    # --- Rate-limit 429 (registered before the AuthorizationError chain) ------
    @app.exception_handler(_RateLimitExceeded)
    async def _rate_limit_exception_handler(  # pyright: ignore[reportUnusedFunction]
        request: _Request, exc: _RateLimitExceeded
    ) -> _JSONResponse:
        """Map :class:`~skaldos.policy.rate_limit.errors.RateLimitExceeded` → 429.

        Body: :class:`~skaldos.policy.rate_limit.responses.RateLimitErrorResponse`
        (frozen Pydantic model; ``code="rate_limit_exceeded"``).
        Header: ``Retry-After: <int>`` (seconds until next window).

        Per §14.7; ``03 § Error-management plan``; ``03 § F7``
        (``retry_after_seconds`` is the single source for both the
        response body and the ``Retry-After`` header).
        """
        body = _RateLimitErrorResponse(
            tier=exc.tier,
            limit=exc.limit,
            count=exc.count,
            retry_after_seconds=exc.retry_after_seconds,
        )
        return _JSONResponse(
            status_code=429,
            content=body.model_dump(),
            headers={"Retry-After": str(exc.retry_after_seconds)},
        )

    @app.exception_handler(SubjectNotFoundError)
    async def _subject_not_found_handler(  # pyright: ignore[reportUnusedFunction]
        request: _Request, exc: SubjectNotFoundError
    ) -> _JSONResponse:
        log.info(
            "authorization.subject_not_found",
            subject_kind=str(exc.subject_kind),
            subject_id=str(exc.subject_id) if exc.subject_id is not None else None,
            action=exc.action,
        )
        return _JSONResponse(
            status_code=404,
            content={"error_code": "not_found", "reason_code": str(exc.reason)},
        )

    @app.exception_handler(IntentRequiredError)
    async def _intent_required_handler(  # pyright: ignore[reportUnusedFunction]
        request: _Request, exc: IntentRequiredError
    ) -> _JSONResponse:
        allowed = ALLOWED_INTENTS.get((exc.action, exc.subject_kind))  # type: ignore[arg-type]
        allowed_list = sorted(i.value for i in allowed) if allowed else []
        body = IntentErrorResponse(
            error_code="intent_required",
            reason_code=str(exc.reason),
            allowed=allowed_list,
        )
        log.info(
            "authorization.intent_missing",
            action=exc.action,
            subject_kind=str(exc.subject_kind),
        )
        return _JSONResponse(status_code=422, content=body.model_dump())

    @app.exception_handler(IntentNotAllowedError)
    async def _intent_not_allowed_handler(  # pyright: ignore[reportUnusedFunction]
        request: _Request, exc: IntentNotAllowedError
    ) -> _JSONResponse:
        allowed = ALLOWED_INTENTS.get((exc.action, exc.subject_kind))  # type: ignore[arg-type]
        allowed_list = sorted(i.value for i in allowed) if allowed else []
        body = IntentErrorResponse(
            error_code="intent_not_allowed",
            reason_code=str(exc.reason),
            allowed=allowed_list,
        )
        log.info(
            "authorization.intent_rejected",
            action=exc.action,
            subject_kind=str(exc.subject_kind),
            intent_supplied=exc.intent.value if exc.intent is not None else None,
        )
        return _JSONResponse(status_code=422, content=body.model_dump())

    @app.exception_handler(PolicyEvaluationError)
    async def _policy_evaluation_error_handler(  # pyright: ignore[reportUnusedFunction]
        request: _Request, exc: PolicyEvaluationError
    ) -> _JSONResponse:
        """Map policy-engine failures to a stable fail-closed 503 contract."""
        return _JSONResponse(
            status_code=503,
            content={
                "error_code": "policy_evaluation_error",
                "reason_code": exc.reason_code,
            },
        )

    @app.exception_handler(AuthorizationError)
    async def _authorization_denied_handler(  # pyright: ignore[reportUnusedFunction]
        request: _Request, exc: AuthorizationError
    ) -> _JSONResponse:
        """Map :class:`AuthorizationError` → 403 (followup #16: no log emit).

        ``_inner`` already emitted the ``authorization.decision`` record at
        Step 7 with the full field set (``principal_id``, ``subject_id``,
        ``intent``, ``reason_code``); a second emit here doubles the audit-
        log volume and drops fields.  The handler returns the response
        only — see the asymmetry table on
        :func:`register_authorization_exception_handlers` for the full
        rationale.
        """
        body = AuthorizationErrorResponse(reason_code=str(exc.reason))
        return _JSONResponse(status_code=403, content=body.model_dump())
