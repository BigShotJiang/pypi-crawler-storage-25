"""Rate-limit tier classification --- ``Tier`` enum + ``LIMITS`` dict + ``classify_route``.

Implements the three-tier model mandated by §14.7
("security-review-driven defaults, 2026-04-08"):

- ``auth`` --- 5 requests / minute / principal.  Strict; reserved for
  authentication-adjacent routes (first-auth, token exchange).  No
  Slice 2 production routes use this tier yet; a fixture route pins its
  limiter behaviour.  Slice 4's ``POST /graph/assert`` and Slice 7's
  agent-registration paths are likely future ``auth``-tier candidates.
- ``write_heavy`` --- 10 / min / principal.  For mutation-heavy routes
  where writes are expected but must be bounded more tightly than the
  standard read/mixed budget.
- ``standard`` --- 100 / min / principal.  Default for every protected
  route unless the route declares otherwise.

Per-tier per-minute limits are pinned as the ``LIMITS`` dict.  They can
be overridden in emergency operational scenarios via the
``RATE_LIMIT_OVERRIDE_LIMITS`` env var (parsed by
:class:`~skaldos.policy.rate_limit.config.RateLimitSettings`); the
defaults are §14.7's binding values and should not be changed in normal
operation.

Route tier classification
-------------------------

``classify_route`` reads the ``tier`` attribute on a
:class:`fastapi.routing.APIRoute`.  This attribute is set by the engine
feature's ``Depends(authorize(..., tier=Tier.AUTH))`` kwarg, which
attaches the chosen ``Tier`` value at app-startup route registration
time.  The function returns :data:`DEFAULT_TIER` (``Tier.STANDARD``) for
any route that lacks the attribute --- a safe-default that prevents
mis-wired routes from escaping the limiter entirely (the lint script
``scripts/check_rate_limit_tier_attribute.py`` asserts every protected
route has an explicit tier; the default is belt-and-suspenders).

References
----------
- §14.7 (binding tier definitions and per-minute limits).
- ``docs/slices/slice-2-authorization/tiered-rate-limiter/03-technical-implementation.md``
  § "Counter logic" (exact enum shape + LIMITS dict).
- ``docs/slices/slice-2-authorization/tiered-rate-limiter/02-edge-cases.md``
  E5 (limit-inclusive semantics: count ≤ limit → allowed;
  count > limit → denied).
- ``docs/slices/slice-2-authorization/master-plan.md``
  § "Shared artifacts" → ``Tier`` StrEnum row.
"""

from __future__ import annotations

from enum import StrEnum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from fastapi.routing import APIRoute


class Tier(StrEnum):
    """Rate-limit tier classification per §14.7.

    String values are lowercase and are written verbatim into the
    ``rate_limit_buckets.tier`` column (T2).  The column is ``text
    NOT NULL``; the enum is the application-side constraint that keeps
    the column's domain closed.

    Members
    -------
    AUTH
        Strict tier.  5 requests / minute / principal.  For
        authentication-adjacent paths.
    WRITE_HEAVY
        Write-heavy tier.  10 / min / principal.  For mutation-heavy
        routes that need a tighter budget than standard.
    STANDARD
        Default tier.  100 / min / principal.  Applied to every
        protected route that does not declare an explicit tier.
    """

    AUTH = "auth"
    WRITE_HEAVY = "write_heavy"
    STANDARD = "standard"


# ---------------------------------------------------------------------------
# Per-tier per-minute limits (binding values from §14.7).
# ---------------------------------------------------------------------------

LIMITS: dict[Tier, int] = {
    Tier.AUTH: 5,
    Tier.WRITE_HEAVY: 10,
    Tier.STANDARD: 100,
}
"""Mapping of :class:`Tier` → requests allowed per minute per principal.

Defaults are §14.7's pinned values.  Override in emergency scenarios
only via ``RATE_LIMIT_OVERRIDE_LIMITS`` (see
:class:`~skaldos.policy.rate_limit.config.RateLimitSettings`).
"""

# ---------------------------------------------------------------------------
# Route-tier classification.
# ---------------------------------------------------------------------------

DEFAULT_TIER: Tier = Tier.STANDARD
"""Fall-through tier for routes that carry no explicit ``tier`` attribute.

The engine feature sets ``tier`` on every protected route at startup.
The lint script ``scripts/check_rate_limit_tier_attribute.py`` asserts
the attribute exists on all protected routes; this default is
belt-and-suspenders so an unclassified route still participates in
rate-limiting rather than escaping it silently.
"""


def classify_route(route: APIRoute) -> Tier:
    """Return the :class:`Tier` for *route*.

    Reads the ``tier`` attribute that the engine feature's
    ``Depends(authorize(..., tier=Tier.X))`` attaches at app-startup
    route registration time.  Falls back to :data:`DEFAULT_TIER`
    (``Tier.STANDARD``) when the attribute is absent --- see module
    docstring for why that's a safe-default rather than an error.

    Parameters
    ----------
    route:
        A :class:`fastapi.routing.APIRoute` instance from
        ``request.scope["route"]``.

    Returns
    -------
    Tier
        The tier declared on the route, or ``Tier.STANDARD`` if no
        ``tier`` attribute is present.
    """
    return getattr(route, "tier", DEFAULT_TIER)
