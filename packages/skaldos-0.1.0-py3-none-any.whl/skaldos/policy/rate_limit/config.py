"""Rate-limit configuration --- :class:`RateLimitSettings` Pydantic Settings.

Reads the ``RATE_LIMIT_*`` env vars and applies the defaults mandated by
the brainstorm:

- ``RATE_LIMIT_ENABLED`` (default ``True``) --- global on/off switch.
  Default is ``True`` in every environment per ``03 § F8``: dev
  developers who hit limits are exposed to production behaviour; the
  failure mode is correct.  Production must explicitly opt out (an audit
  log line fires on startup if ``enabled=False`` so ops is not silently
  surprised).
- ``RATE_LIMIT_FAIL_MODE`` (default ``"fail_closed"``) --- what happens
  when the rate-limit counter pool is unavailable (timeout, SQL error).
  ``"fail_closed"`` → 503; ``"fail_open"`` → warning log + proceed.
  Default is ``fail_closed`` per ``02 § E5 / Q7`` (same choice as
  Shield's §9.4 fail-open/closed design; production should be closed).
- ``RATE_LIMIT_SHADOW_MODE`` (default ``False``) --- counter increments
  as normal but over-limit requests are NOT rejected; instead, a
  ``rate_limit.triggered`` log line is emitted with
  ``decision="would_have_denied"``.  Production rollout mechanism
  (``02 § E24 / MP7``).
- ``RATE_LIMIT_OVERRIDE_LIMITS`` (default ``{}``) --- JSON object mapping
  tier string → per-minute integer override, e.g.
  ``'{"auth": 3, "standard": 50}'``.  For emergency operational use;
  production should run with §14.7's binding defaults.

Environment-variable prefix
---------------------------

All fields share the ``RATE_LIMIT_`` prefix via
:class:`pydantic_settings.SettingsConfigDict`.  Field names are the
suffix in lowercase, so ``enabled`` ↔ ``RATE_LIMIT_ENABLED``,
``fail_mode`` ↔ ``RATE_LIMIT_FAIL_MODE``, etc.

No ``.env`` autoload
--------------------

``env_file=None`` is intentional --- same rationale as
:class:`~skaldos.auth.config.AuthConfig`.  Production injects env vars
via Cloud Run / mise; autoloading a ``.env`` file during unit tests
would shadow ``monkeypatch``-set values.

References
----------
- §14.7 (binding tier definitions; override is an emergency escape-hatch
  from those binding values).
- ``docs/slices/slice-2-authorization/tiered-rate-limiter/02-edge-cases.md``
  E5 (fail-closed default), Q7 (``RATE_LIMIT_ENABLED`` default = True
  everywhere), E24 (shadow mode semantics).
- ``docs/slices/slice-2-authorization/tiered-rate-limiter/03-technical-implementation.md``
  § F8 (enabled=True everywhere; dev developers see production behaviour).
- ``docs/slices/slice-2-authorization/master-plan.md``
  § "ADRs surfaced" → row "Per-tier LIMITS overridable via env"
  (``RATE_LIMIT_OVERRIDE_LIMITS`` is the env override; defaults are
  §14.7 pinned; startup logs the override dict).
"""

from __future__ import annotations

import json
from typing import Any, ClassVar, Literal, cast

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from skaldos.policy.rate_limit.tier import Tier


class RateLimitSettings(BaseSettings):
    """Rate-limit operational configuration loaded from environment variables.

    Constructed once at FastAPI app startup alongside the pool
    initialisation (T3).  Validation fires on construction; bad values
    surface as :class:`pydantic.ValidationError` (process exit with a
    clear error message --- the §14.7 "fail on startup" idiom).

    Test code constructs ``RateLimitSettings`` with explicit kwargs or
    via ``monkeypatch.setenv`` + bare ``RateLimitSettings()``.
    Production wiring uses bare ``RateLimitSettings()`` at app startup.

    Notes
    -----
    ``override_limits`` is a ``dict[Tier, int]`` once parsed.  The env
    var is a JSON object whose keys are tier string values
    (``"auth"``, ``"write_heavy"``, ``"standard"``).  The
    ``_parse_override_limits`` field validator normalises it; an empty
    object (the default) means "use §14.7 binding defaults."

    Startup logging of the override dict (``event="rate_limit.startup",
    overrides=<dict>``) lives in ``pre_hook.py``'s register function
    (T5); :class:`RateLimitSettings` only carries the parsed value.

    Implementation detail: ``override_limits`` is declared as
    ``str | dict[Tier, int]`` to prevent Pydantic BaseSettings from
    JSON-decoding the env var on our behalf before our field validator
    can validate it.  The field validator runs in ``mode="before"`` and
    returns a normalised ``dict[Tier, int]``; by that time Pydantic's
    own dict coercion has already been bypassed.
    """

    model_config: ClassVar[SettingsConfigDict] = SettingsConfigDict(
        env_prefix="RATE_LIMIT_",
        env_file=None,
        case_sensitive=False,
        extra="ignore",
        # Treat an empty env var the same as absent (don't try to JSON-parse
        # an empty string for complex fields like override_limits).
        env_ignore_empty=True,
    )

    # ---- Fields. -------------------------------------------------------------

    enabled: bool = True
    """Global on/off switch.

    Default ``True`` in all environments per ``03 § F8``.  To disable in
    an emergency: ``RATE_LIMIT_ENABLED=false`` (Pydantic Settings reads
    ``"false"`` as ``False`` for ``bool`` fields).  A startup audit log
    line fires when this is ``False`` so ops is not silently surprised.
    """

    fail_mode: Literal["fail_closed", "fail_open"] = "fail_closed"
    """Behaviour when the rate-limit counter is unavailable.

    ``"fail_closed"`` (default): unavailable counter → 503 to caller.
    ``"fail_open"``: unavailable counter → warning log + request
    proceeds.

    Default ``"fail_closed"`` per ``02 § E5`` / ``Q7``.  Mirrors
    Shield's §9.4 fail-mode design.  Development environments that want
    the more permissive mode set ``RATE_LIMIT_FAIL_MODE=fail_open``.
    """

    shadow_mode: bool = False
    """When ``True``, the limiter increments counters but does not reject.

    Over-limit requests proceed normally; a ``rate_limit.triggered``
    log line is emitted with ``decision="would_have_denied"``.  Used
    during production rollout to build confidence before enabling
    hard rejection (``02 § E24``, MP7).  Default ``False``.
    """

    override_limits: dict[Tier, int] = {}  # noqa: RUF012  (mutable default OK; Pydantic copies)
    """Per-tier per-minute limit overrides (§14.7 binding values are the defaults).

    Parsed from the ``RATE_LIMIT_OVERRIDE_LIMITS`` env var, which must
    be a JSON object whose keys are tier string values.  Empty dict
    means "use the ``LIMITS`` dict from ``tier.py``" (the §14.7
    binding values).

    Example::

        RATE_LIMIT_OVERRIDE_LIMITS='{"auth": 3, "standard": 50}'

    The field validator :meth:`_parse_override_limits` normalises the
    raw env string into ``{Tier: int}`` before the instance is
    returned.  Unknown tier keys raise :class:`pydantic.ValidationError`
    at startup.
    """

    # ---- Validators. ---------------------------------------------------------

    @field_validator("override_limits", mode="before")
    @classmethod
    def _parse_override_limits(cls, raw: Any) -> dict[Tier, int]:  # noqa: ANN401
        """Normalise ``override_limits`` from JSON string / raw dict → ``dict[Tier, int]``.

        This validator runs *before* Pydantic coerces the field type,
        which is why we declare the field as ``dict[Tier, int]`` and
        accept ``Any`` here --- the env var arrives as a string;
        direct-kwarg construction sends a dict.

        Validation rules
        ~~~~~~~~~~~~~~~~
        - Absent or empty string → ``{}`` (use §14.7 binding defaults).
        - Non-empty string → must be valid JSON object.
        - Object keys → must be valid :class:`Tier` values.
        - Object values → must be positive integers.
        """
        # Absent / empty: return the default.
        if raw is None or raw == "" or raw == {}:
            return {}

        # Dict input (direct kwarg in tests, or already-parsed dict).
        if isinstance(raw, dict):
            return _normalise_limits_dict(cast("dict[str | Tier, object]", raw))

        # String input from the environment.
        if isinstance(raw, str):
            try:
                parsed = json.loads(raw)
            except json.JSONDecodeError as exc:
                raise ValueError(
                    f"RATE_LIMIT_OVERRIDE_LIMITS must be a JSON object "
                    f"(e.g. '{{\"auth\": 3}}'); could not parse {raw!r}. "
                    f"JSON error: {exc}"
                ) from exc
            if not isinstance(parsed, dict):
                raise ValueError(
                    f"RATE_LIMIT_OVERRIDE_LIMITS must be a JSON object; "
                    f"got {type(parsed).__name__!r} after JSON parse "
                    f"(input was {raw!r})."
                )
            return _normalise_limits_dict(cast("dict[str | Tier, object]", parsed))

        raise ValueError(
            f"RATE_LIMIT_OVERRIDE_LIMITS must be a JSON object or dict; got {type(raw).__name__!r}."
        )


# ---------------------------------------------------------------------------
# Internal helpers.
# ---------------------------------------------------------------------------


def _normalise_limits_dict(raw: dict[str | Tier, object]) -> dict[Tier, int]:
    """Validate and normalise a raw ``{str|Tier: int}`` dict.

    Raises :class:`ValueError` on unknown tier keys or non-positive
    values; used by :meth:`RateLimitSettings._parse_override_limits`.

    ``Tier`` is a ``StrEnum``, so all ``Tier`` instances are also ``str``
    instances; the key loop normalises any string (plain or enum) to a
    ``Tier`` by calling ``Tier(k)``, which is idempotent for ``Tier``
    values and validates plain strings.
    """
    normalised: dict[Tier, int] = {}
    for k, v in raw.items():
        # All keys are str (Tier is StrEnum, so Tier values are also str).
        # Tier(k) is idempotent for Tier values; validates plain strings.
        try:
            tier = Tier(k)
        except ValueError:
            valid = [t.value for t in Tier]
            raise ValueError(
                f"RATE_LIMIT_OVERRIDE_LIMITS key {k!r} is not a valid "
                f"Tier value.  Valid values: {valid}."
            ) from None
        # Validate value: must be a positive int.  Explicitly reject booleans
        # (bool is a subclass of int in Python; True == 1 and False == 0 are
        # technically positive/non-positive but confusing as rate-limit values).
        if isinstance(v, bool) or not isinstance(v, int) or v < 1:
            raise ValueError(
                f"RATE_LIMIT_OVERRIDE_LIMITS[{k!r}] must be a positive integer; got {v!r}."
            )
        normalised[tier] = v
    return normalised
