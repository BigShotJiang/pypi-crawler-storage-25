"""Rate-limit counter --- :func:`increment_and_check`.

Implements the atomic upsert idiom (PC10) that increments the
``rate_limit_buckets`` counter for a ``(principal_id, tier,
window_start)`` tuple and raises :class:`~skaldos.policy.rate_limit.errors.RateLimitExceeded`
when the returned count exceeds the tier's per-minute budget (§14.7).

GUC discipline (PC1 / ``03 § F2``)
------------------------------------

The ``rate_limit_buckets`` table has FORCE RLS with the policy::

    principal_id = (SELECT app.principal_id())

``app.principal_id()`` reads the ``app.current_principal_id`` GUC.
The rate-limit pool's connections carry no ambient principal (they are
shared by all requests). Therefore, :func:`increment_and_check` must
set the GUC at the start of every transaction::

    SELECT set_config('app.current_principal_id', $1::text, true)

The ``true`` third argument makes the setting transaction-local (it is
cleared on ``COMMIT`` / ``ROLLBACK`` per ``SET LOCAL`` semantics). The
connection is then handed back to PgBouncer-tx on commit, so the GUC
does not bleed into the next acquire. **PC1 strict adherence:** the
GUC name is a literal string constant, never dynamic.

Atomic upsert (PC10)
--------------------

The counter uses the standard ``INSERT … ON CONFLICT DO UPDATE …
RETURNING`` idiom::

    INSERT INTO rate_limit_buckets (principal_id, tier, window_start, count)
    VALUES ($1, $2, date_trunc('minute', now()), 1)
    ON CONFLICT (principal_id, tier, window_start)
    DO UPDATE SET
        count      = rate_limit_buckets.count + 1,
        updated_at = now()
    RETURNING count;

The ``date_trunc('minute', now())`` expression is evaluated *by the
DB* (never the app) so all requests within the same minute land on
the same row regardless of app-server clock skew (E3 in
``02-edge-cases.md``). The ``RETURNING count`` value is the
*post-increment* count (PC10 invariant); the caller compares it to
``LIMITS[tier]`` after the query returns (not inside the SQL).

Limit-inclusive semantics (E6)
-------------------------------

``count == limit`` is the last allowed call; ``count > limit`` is the
first denied call.  The check is::

    if count > LIMITS[tier]:
        raise RateLimitExceeded(...)

Retry-after computation (Q1 / F7)
-----------------------------------

The number of seconds until the next minute boundary is computed from
the DB clock::

    SELECT (60 - EXTRACT(SECOND FROM now())::int) AS retry_after

This is evaluated inside the same transaction as the upsert (same
``now()`` snapshot per Postgres transaction semantics — ``STABLE``
functions return the transaction start time). The value is floored to
a minimum of 1 second (never send ``Retry-After: 0``).

References
----------
- §14.7 (tiered rate limiting; 5/10/100 per minute per principal).
- PC1 (``set_config`` with literal GUC names).
- PC10 (``INSERT … ON CONFLICT DO UPDATE … RETURNING`` atomic upsert).
- §18.3 (PgBouncer-tx; transaction-local GUC via ``SET LOCAL``).
- ``docs/slices/slice-2-authorization/tiered-rate-limiter/03-technical-implementation.md``
  § "Counter logic", § F2 (GUC + pool discipline).
- ``docs/slices/slice-2-authorization/tiered-rate-limiter/02-edge-cases.md``
  E1 (concurrent increments), E2 (minute boundary), E3 (DB clock),
  E4 (increment survives handler crash), E6 (limit-inclusive).
"""

from __future__ import annotations

from uuid import UUID

import asyncpg

from skaldos.policy.rate_limit.errors import RateLimitExceeded
from skaldos.policy.rate_limit.tier import LIMITS, Tier

__all__ = ["increment_and_check"]

# ---------------------------------------------------------------------------
# GUC constant (PC1 — literal name, never dynamic).
# ---------------------------------------------------------------------------

_GUC_PRINCIPAL_ID = "app.current_principal_id"

# ---------------------------------------------------------------------------
# SQL constants.
# ---------------------------------------------------------------------------

# Sets the transaction-local GUC so the RLS policy
# ``principal_id = (SELECT app.principal_id())`` admits the INSERT.
# The ``true`` third arg is ``SET LOCAL`` semantics: the value is cleared
# on COMMIT / ROLLBACK, so PgBouncer-tx backend reuse cannot bleed the
# GUC into the next acquire.
_SET_GUC_SQL = "SELECT set_config($1, $2, true)"

# Atomic upsert (PC10): first INSERT sets count = 0 + 1 = 1 (column
# DEFAULT is 0); subsequent INSERTs on the same (principal_id, tier,
# window_start) conflict and increment count in-place. ``RETURNING count``
# returns the post-increment value in a single round-trip.
#
# ``date_trunc('minute', now())`` uses the DB clock (E3) and is evaluated
# once per query (``now()`` is ``STABLE`` — same value throughout the
# transaction). All requests within the same wall-clock minute land on the
# same row regardless of app-server clock skew.
_UPSERT_SQL = """
INSERT INTO rate_limit_buckets (principal_id, tier, window_start, count)
VALUES ($1, $2, date_trunc('minute', now()), 1)
ON CONFLICT (principal_id, tier, window_start)
DO UPDATE SET
    count      = rate_limit_buckets.count + 1,
    updated_at = now()
RETURNING count
"""

# Retry-after computed from the DB clock inside the same transaction
# (same ``now()`` snapshot as the upsert — Postgres STABLE semantics).
# Floor to 1 so we never emit ``Retry-After: 0``.
_RETRY_AFTER_SQL = "SELECT GREATEST(1, 60 - EXTRACT(SECOND FROM now())::int) AS retry_after"


# ---------------------------------------------------------------------------
# Public function.
# ---------------------------------------------------------------------------


async def increment_and_check(
    conn: asyncpg.Connection,
    principal_id: UUID,
    tier: Tier,
) -> int:
    """Atomically increment the principal's rate-limit counter and check the budget.

    Runs inside a single transaction on *conn*:

    1. Set ``app.current_principal_id`` GUC (transaction-local) so the
       RLS policy admits the INSERT (PC1 / ``03 § F2``).
    2. Run the atomic upsert (PC10) returning the post-increment count.
    3. Fetch the ``retry_after`` seconds from the DB clock (same
       transaction snapshot).
    4. If ``count > LIMITS[tier]``, raise
       :class:`~skaldos.policy.rate_limit.errors.RateLimitExceeded`.

    The transaction commits (or rolls back on error) when the caller
    exits the ``pool.acquire()`` context manager.  The dedicated rate-
    limit pool's transaction is independent of the handler's runtime
    pool transaction (E4 in ``02-edge-cases.md``).

    Parameters
    ----------
    conn:
        An :class:`asyncpg.Connection` acquired from the rate-limit pool
        (``app.state.rate_limit_pool.acquire()``).
    principal_id:
        The UUID of the requesting principal (set as the GUC value).
    tier:
        The :class:`~skaldos.policy.rate_limit.tier.Tier` of the route.

    Returns
    -------
    int
        The post-increment count (≤ ``LIMITS[tier]``; the count is the
        number of requests in the current minute window including this
        one).

    Raises
    ------
    :class:`~skaldos.policy.rate_limit.errors.RateLimitExceeded`
        When ``count > LIMITS[tier]``. The exception carries
        ``principal_id``, ``tier``, ``limit``, ``count``, and
        ``retry_after_seconds`` so the caller (rate-limit T4's pre-hook)
        can log and re-raise without re-querying the DB.

    Notes
    -----
    The ``LIMITS`` dict is the module-level §14.7 binding values.
    ``config.override_limits`` (from ``RATE_LIMIT_OVERRIDE_LIMITS``) is
    merged by the caller in rate-limit T4; T3 uses raw ``LIMITS`` so the
    counter module has no dependency on the config layer.
    """
    async with conn.transaction():  # pyright: ignore[reportUnknownMemberType]
        # 1. Set the transaction-local GUC (PC1 / F2).
        #    GUC name is a literal constant — never dynamic (PC1 strict).
        await conn.execute(_SET_GUC_SQL, _GUC_PRINCIPAL_ID, str(principal_id))  # pyright: ignore[reportUnknownMemberType]

        # 2. Atomic upsert (PC10).
        row = await conn.fetchrow(_UPSERT_SQL, str(principal_id), tier.value)  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
        assert row is not None  # RETURNING always returns a row for DML
        count: int = row["count"]  # pyright: ignore[reportUnknownVariableType]

        # 3. Compute retry_after from DB clock (same transaction snapshot).
        retry_row = await conn.fetchrow(_RETRY_AFTER_SQL)  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
        assert retry_row is not None
        retry_after: int = retry_row["retry_after"]  # pyright: ignore[reportUnknownVariableType]

    # 4. Enforce the limit (limit-inclusive: count == limit is allowed;
    #    count > limit is the first denied call per E6).
    limit = LIMITS[tier]
    if count > limit:
        raise RateLimitExceeded(
            principal_id=principal_id,
            tier=tier,
            limit=limit,
            count=count,  # pyright: ignore[reportUnknownArgumentType]
            retry_after_seconds=retry_after,  # pyright: ignore[reportUnknownArgumentType]
        )

    return count  # pyright: ignore[reportUnknownVariableType]
