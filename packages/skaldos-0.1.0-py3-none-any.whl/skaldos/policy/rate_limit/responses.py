"""``RateLimitErrorResponse`` Pydantic model for HTTP 429 bodies (rate-limit T4).

Per ``docs/slices/slice-2-authorization/tiered-rate-limiter/``
``05-task-list.md`` § T4 and
``docs/slices/slice-2-authorization/master-plan.md``
§ "Shared artifacts & contracts" → ``PROTECTED_ROUTE_RESPONSES`` floor.

This module defines the typed response body that accompanies every HTTP 429
response emitted by the rate-limit exception handler wired in
:func:`~skaldos.policy.authorize.register_authorization_exception_handlers`
(T4 extends that function).

Body shape
----------

:class:`RateLimitErrorResponse` is the canonical 429 body shape per
master-plan § "Shared artifacts":

.. code-block:: json

    {
        "code": "rate_limit_exceeded",
        "tier": "standard",
        "limit": 100,
        "count": 101,
        "retry_after_seconds": 42,
        "message": "Rate limit exceeded."
    }

The ``message`` field is optional; omit it for clients that dispatch
purely on ``code``.

The ``retry_after_seconds`` field is the canonical value for both:

1. The ``Retry-After`` HTTP header (set by the exception handler, not this
   model).
2. The response body field (serialised by :meth:`model_dump`).

Both consume ``exc.retry_after_seconds`` from the caught
:class:`~skaldos.policy.rate_limit.errors.RateLimitExceeded` exception —
the single authoritative source per ``03 § F7``.

PII discipline
--------------

No PII in any field (§20.2 / §13.2). The ``code``, ``tier``, ``limit``,
``count``, and ``retry_after_seconds`` fields carry no identity information.

References
----------

- §14.7 (429 response shape; ``Retry-After`` header).
- ``docs/slices/slice-2-authorization/tiered-rate-limiter/03-technical-implementation.md``
  § "Error-management plan" (429 caller-facing shape).
- ``docs/slices/slice-2-authorization/tiered-rate-limiter/03-technical-implementation.md``
  § F7 (``retry_after_seconds`` is the single source for both response body
  and ``Retry-After`` header).
- master-plan § "Shared artifacts & contracts" →
  ``PROTECTED_ROUTE_RESPONSES`` floor (429 → RateLimitErrorResponse).
- §20.2 (PII-free log / response shapes).
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict

from skaldos.policy.rate_limit.tier import Tier

__all__ = ["RateLimitErrorResponse"]


class RateLimitErrorResponse(BaseModel):
    """OpenAPI schema for HTTP 429 rate-limit-exceeded responses.

    Returned as the JSON body when the rate-limit pre-hook raises
    :class:`~skaldos.policy.rate_limit.errors.RateLimitExceeded` and the
    FastAPI exception handler maps it to a 429.

    Fields
    ------
    code:
        Stable error-code string. Always ``"rate_limit_exceeded"``.
        Clients (frontend Zod, MCP error decoder) dispatch on this value.
    tier:
        The :class:`~skaldos.policy.rate_limit.tier.Tier` of the route that
        was hit. Lets callers understand which budget was exhausted without
        exposing any identity information.
    limit:
        The per-minute budget for this tier (§14.7 binding values unless
        overridden via ``RATE_LIMIT_OVERRIDE_LIMITS``).
    count:
        The post-increment count returned by the atomic upsert (PC10);
        always ``> limit`` when this response is returned.
    retry_after_seconds:
        Seconds until the next minute window opens. The exception handler
        also writes this value into the ``Retry-After`` HTTP header. The
        value is ``GREATEST(1, 60 - EXTRACT(SECOND FROM now())::int)``
        from the DB clock (§ F7 — single authoritative source).
    message:
        Optional human-readable explanation for debugging. Omitted by
        default; callers must not depend on its contents.

    Frozen + extra=forbid (AP5)
    ---------------------------

    Frozen: the model is immutable once constructed (no accidental mutation
    in the exception handler).  ``extra="forbid"``: rejects unknown kwargs
    at construction so a typo in the handler doesn't silently discard fields.

    PII discipline (§20.2 / §13.2)
    --------------------------------

    No PII in any field. ``code``, ``tier``, ``limit``, ``count``, and
    ``retry_after_seconds`` carry zero identity information.

    Per §14.7; ``03 § Error-management plan``; ``03 § F7``; master-plan
    § "Shared artifacts & contracts" → ``PROTECTED_ROUTE_RESPONSES``
    floor (``429 → RateLimitErrorResponse``).
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    code: Literal["rate_limit_exceeded"] = "rate_limit_exceeded"
    """Stable error-code string for client dispatch.  Always ``"rate_limit_exceeded"``."""

    tier: Tier
    """The rate-limit tier of the route that was hit (§14.7)."""

    limit: int
    """Per-minute budget for this tier; always ``> 0``."""

    count: int
    """Post-increment count; always ``> limit`` when this response is returned."""

    retry_after_seconds: int
    """Seconds until the next minute window (also written to ``Retry-After`` header)."""

    message: str | None = None
    """Optional human-readable explanation. Omitted by default."""
