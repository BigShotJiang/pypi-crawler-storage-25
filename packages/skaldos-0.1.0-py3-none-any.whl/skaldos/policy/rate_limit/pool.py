"""Rate-limit asyncpg pool lifecycle (rate-limit T3).

Per
``docs/slices/slice-2-authorization/tiered-rate-limiter/05-task-list.md``
§ T3 and
``docs/slices/slice-2-authorization/tiered-rate-limiter/03-technical-implementation.md``
§ "Pool sizing":

- A **dedicated** :class:`asyncpg.Pool` for the rate-limit counter.
  Separate from the runtime pool (``skaldos.db.pool``) and the
  chokepoint pool (``skaldos.policy.pool``) so rate-limit transactions
  commit independently of the handler's transaction (E4 in
  ``02-edge-cases.md`` — the increment must survive a handler crash,
  since the limiter counts *requests*, not completions).

- Pool size: ``min_size=2``, ``max_size=10`` (small; queries are
  sub-millisecond INSERT … ON CONFLICT … RETURNING).

- ``command_timeout=1.0`` seconds (short; the limiter must not block
  requests). Distinct from the per-acquire timeout (1 second) which
  :func:`~skaldos.policy.rate_limit.counter.increment_and_check`'s
  caller passes when calling ``pool.acquire()``.

- DSN: reads ``RATE_LIMIT_POOL_DSN`` env var; falls back to
  ``DATABASE_URL`` if not set (per ``03 § Pool topology``). The DSN
  should author as ``app_runtime`` on the PgBouncer transaction-mode
  port (5431 per §18.3). The rate-limit table grants are on
  ``app_runtime`` only; ``app_chokepoint`` has no grants (hard contract
  per master-plan T2 / T3 task list).

- The pool is constructed once at FastAPI startup
  (:func:`init_rate_limit_pool`) and torn down at shutdown
  (:func:`close_rate_limit_pool`). ``app.py`` calls both functions and
  stores the pool on ``app.state.rate_limit_pool``.

Why a separate pool
-------------------

The rate-limit INSERT … ON CONFLICT … RETURNING runs in its own
transaction — committed before the handler's transaction begins (per
the architecture diagram in ``03 § Architecture``). If the rate-limit
pool were the same as the runtime pool, a failure in the handler could
roll back the counter increment (because the pool in transaction mode
might reuse the same backend and the same transaction slot). The
dedicated pool enforces independence at the pool level, not just the
transaction level (E4 / ``02-edge-cases.md``).

PgBouncer transaction mode
--------------------------

The pool connects through PgBouncer-tx (port 5431 per §18.3). Every
:func:`~skaldos.policy.rate_limit.counter.increment_and_check` call
acquires a connection, begins a transaction, runs the upsert SQL, and
commits — a single-round-trip transaction.  PgBouncer transaction mode
returns the backend to the pool after ``COMMIT``; this is the correct
mode for the counter workload (E17 in ``02-edge-cases.md`` — no
LISTEN/NOTIFY needed, no session-state carry-over).

The GUC ``app.current_principal_id`` must be set *inside* the
transaction using ``SET LOCAL`` (``set_config(name, value, true)``).
``SET LOCAL`` is transaction-scoped; PgBouncer-tx resets any session-
level state on backend return.  :func:`~skaldos.policy.rate_limit.counter.increment_and_check`
owns this discipline (``03 § F2``).

References
----------
- §14.7 (tiered rate limiting; dedicated pool is the §18.3 compliance
  point).
- §18.3 (PgBouncer transaction mode on port 5431; pool per-service).
- PC1 (GUC set inside transaction via ``set_config``).
- PC12 (LISTEN/NOTIFY on direct port 5432 only — this pool does neither).
- ``docs/slices/slice-2-authorization/tiered-rate-limiter/03-technical-implementation.md``
  § "Pool sizing" and § F2.
- ``docs/slices/slice-2-authorization/tiered-rate-limiter/02-edge-cases.md``
  E4 (increment must survive handler crash), E16 (pool exhaustion →
  fail-closed), E17 (no LISTEN/NOTIFY → tx pool OK), E18 (same
  ``app_runtime`` role, separate pool instance).
"""

from __future__ import annotations

import os

import asyncpg

__all__ = [
    "close_rate_limit_pool",
    "init_rate_limit_pool",
]

# ---------------------------------------------------------------------------
# DSN resolution.
# ---------------------------------------------------------------------------

_ENV_RATE_LIMIT_DSN = "RATE_LIMIT_POOL_DSN"
_ENV_DATABASE_URL = "DATABASE_URL"


def _resolve_dsn(dsn: str | None) -> str:
    """Return the DSN for the rate-limit pool.

    Resolution order (per ``03 § Pool topology``):

    1. Explicit ``dsn`` argument (used in tests and by ``app.py`` if it
       constructs the DSN itself).
    2. ``RATE_LIMIT_POOL_DSN`` env var — the preferred production config
       (lets ops point the rate-limit pool at a dedicated PgBouncer
       frontend without touching the runtime pool's ``DATABASE_URL``).
    3. ``DATABASE_URL`` env var — the canonical fallback (same var read
       by ``skaldos.db.pool`` and ``migrations/env.py``).

    Strips SQLAlchemy driver qualifiers (``+psycopg``, ``+asyncpg``)
    so the same env var works for both asyncpg and SQLAlchemy / psycopg
    callers (same transform as ``skaldos.db.pool._resolve_dsn``).

    Raises :class:`RuntimeError` when no DSN is available — the rate-
    limit pool must fail loudly at startup rather than silently
    starting without a counter (``03 § F8`` idiom).
    """
    raw = dsn or os.environ.get(_ENV_RATE_LIMIT_DSN) or os.environ.get(_ENV_DATABASE_URL)
    if not raw:
        raise RuntimeError(
            f"No DSN configured for the rate-limit pool. "
            f"Set {_ENV_RATE_LIMIT_DSN!r} (preferred) or "
            f"{_ENV_DATABASE_URL!r} (fallback). "
            f"The DSN should author as app_runtime on the PgBouncer "
            f"transaction-mode port (5431 per §18.3)."
        )
    # Strip SQLAlchemy driver qualifiers; asyncpg only accepts the bare
    # ``postgresql://`` scheme.
    return raw.replace("postgresql+psycopg://", "postgresql://", 1).replace(
        "postgresql+asyncpg://", "postgresql://", 1
    )


# ---------------------------------------------------------------------------
# Pool lifecycle.
# ---------------------------------------------------------------------------


async def init_rate_limit_pool(dsn: str | None = None) -> asyncpg.Pool:
    """Open and return a fresh asyncpg pool for the rate-limit counter.

    Called once at FastAPI startup (``app.py`` lifespan). The returned
    pool is stored on ``app.state.rate_limit_pool`` so
    :func:`~skaldos.policy.rate_limit.pre_hook.rate_limit_pre_hook` can
    acquire connections from it per-request.

    Parameters
    ----------
    dsn:
        Optional explicit DSN override (useful in tests). When ``None``,
        :func:`_resolve_dsn` reads ``RATE_LIMIT_POOL_DSN`` then
        ``DATABASE_URL``.

    Returns
    -------
    :class:`asyncpg.Pool`
        The open pool.  The caller owns the lifecycle; call
        :func:`close_rate_limit_pool` at shutdown.

    Pool configuration
    ------------------
    - ``min_size=2`` / ``max_size=10`` — small; the counter queries are
      sub-millisecond (INSERT … ON CONFLICT … RETURNING one row).
    - ``command_timeout=1.0`` — per-command ceiling; the limiter must
      not block requests (E16 in ``02-edge-cases.md``).
    - ``timeout`` (connect-establishment): ``5.0`` seconds.
    """
    resolved = _resolve_dsn(dsn)
    pool = await asyncpg.create_pool(  # pyright: ignore[reportUnknownMemberType]
        dsn=resolved,
        min_size=2,
        max_size=10,
        command_timeout=1.0,
        timeout=5.0,
    )
    assert pool is not None  # create_pool returns Pool | None but None is only on error
    return pool


async def close_rate_limit_pool(pool: asyncpg.Pool) -> None:
    """Close the rate-limit pool, returning all connections to PgBouncer.

    Idempotent at the asyncpg level (calling ``close()`` on an already-
    closed pool is a no-op). Called at FastAPI shutdown via ``app.py``'s
    lifespan context manager.

    Parameters
    ----------
    pool:
        The pool returned by :func:`init_rate_limit_pool`.
    """
    await pool.close()
