"""Rate-limit exception --- :class:`RateLimitExceeded`.

Typed exception raised by :func:`~skaldos.policy.rate_limit.counter.increment_and_check`
when a principal's request count for the current minute window exceeds the
per-tier limit mandated by §14.7.

Rate-limit T4 (the pre-hook) catches this exception, logs
``rate_limit.triggered`` with ``decision="denied"``, and re-raises so
FastAPI's exception handler can map it to an HTTP 429 response with the
correct ``Retry-After`` header.

Fields
------
principal_id : UUID
    The principal whose budget was exhausted.
tier : Tier
    The rate-limit tier of the route that was hit.
limit : int
    The per-minute budget for this tier (§14.7 binding values unless
    overridden via ``RATE_LIMIT_OVERRIDE_LIMITS``).
count : int
    The post-increment count returned by the atomic upsert (PC10);
    always ``> limit`` when this exception is raised.
retry_after_seconds : int
    Seconds until the next minute window opens (``60 - second_of_minute``
    at the time the limit was hit). Passed verbatim to the ``Retry-After``
    HTTP response header by rate-limit T4.

Message format
--------------

The string representation is::

    rate limit exceeded: tier=<tier>, count=<count>/<limit>, retry_after=<s>s

This exact format is pinned by the unit test
``test_rate_limit_exceeded_message_format`` in
``tests/unit/policy/rate_limit/test_errors.py``.  Rate-limit T4's
response serializer reads the typed fields (not the message) to build
the response body; the message format is for logs and tracebacks.

References
----------
- §14.7 (tiered rate limiting; 429 response shape).
- ``docs/slices/slice-2-authorization/tiered-rate-limiter/04-testing-strategy.md``
  § "rate_limit/errors.py" (typed-fields unit test).
- ``docs/slices/slice-2-authorization/tiered-rate-limiter/02-edge-cases.md``
  E6 (limit-inclusive semantics: ``count == limit`` → allowed;
  ``count > limit`` → this exception).
- ``docs/slices/slice-2-authorization/tiered-rate-limiter/03-technical-implementation.md``
  § F7 (``retry_after_seconds`` is the single authoritative value read by
  both the response body serializer and the ``Retry-After`` header).
- ``docs/slices/slice-2-authorization/tiered-rate-limiter/master-plan.md``
  § "Shared artifacts" → ``RateLimitExceeded`` row.
"""

from __future__ import annotations

from uuid import UUID

from skaldos.policy.rate_limit.tier import Tier


class RateLimitExceeded(Exception):  # noqa: N818 -- name pinned by master-plan § "Shared artifacts" → RateLimitExceeded row and 04-testing-strategy.md; renaming would break T4's exception handler and the canon link.
    """Rate limit exceeded for a principal on a given tier.

    Raised by :func:`~skaldos.policy.rate_limit.counter.increment_and_check`
    when the post-increment count exceeds the tier's per-minute budget.

    Parameters
    ----------
    principal_id:
        The UUID of the principal whose budget was exhausted.
    tier:
        The :class:`~skaldos.policy.rate_limit.tier.Tier` of the route.
    limit:
        The per-minute budget for this tier (§14.7 binding value or
        ``RATE_LIMIT_OVERRIDE_LIMITS`` override).
    count:
        Post-increment count from the atomic upsert (PC10); always
        ``> limit``.
    retry_after_seconds:
        Seconds until the start of the next minute window.  Computed as
        ``60 - EXTRACT(SECOND FROM now())::int`` using the DB clock
        (E3 in ``02-edge-cases.md`` — DB clock is the single time source).
        The minimum is ``1`` (never send ``Retry-After: 0``); the maximum
        is ``60`` (first second of the current minute).
    """

    def __init__(
        self,
        *,
        principal_id: UUID,
        tier: Tier,
        limit: int,
        count: int,
        retry_after_seconds: int,
    ) -> None:
        self.principal_id = principal_id
        self.tier = tier
        self.limit = limit
        self.count = count
        self.retry_after_seconds = retry_after_seconds
        super().__init__(
            f"rate limit exceeded: tier={tier.value}, "
            f"count={count}/{limit}, "
            f"retry_after={retry_after_seconds}s"
        )
