"""Rate-limit sub-package --- public surface for T1–T4.

Exports from this sub-package's T1 deliverables:

- :class:`~skaldos.policy.rate_limit.tier.Tier` --- three-tier StrEnum
  per §14.7 (``auth``, ``write_heavy``, ``standard``).
- :data:`~skaldos.policy.rate_limit.tier.LIMITS` --- per-tier per-minute
  limits dict (§14.7 binding values).
- :func:`~skaldos.policy.rate_limit.tier.classify_route` --- reads the
  ``tier`` attribute from a FastAPI ``APIRoute``; falls back to
  :data:`~skaldos.policy.rate_limit.tier.DEFAULT_TIER`.
- :data:`~skaldos.policy.rate_limit.tier.DEFAULT_TIER` --- ``Tier.STANDARD``.
- :class:`~skaldos.policy.rate_limit.config.RateLimitSettings` ---
  Pydantic Settings for the ``RATE_LIMIT_*`` env vars.

T3 additions:

- :func:`~skaldos.policy.rate_limit.pool.init_rate_limit_pool` --- open
  a dedicated :class:`asyncpg.Pool` for the rate-limit counter.
- :func:`~skaldos.policy.rate_limit.pool.close_rate_limit_pool` --- tear
  the pool down at shutdown.
- :func:`~skaldos.policy.rate_limit.counter.increment_and_check` ---
  atomic upsert (PC10) + limit check; raises :class:`RateLimitExceeded`.
- :class:`~skaldos.policy.rate_limit.errors.RateLimitExceeded` --- typed
  exception with ``principal_id``, ``tier``, ``limit``, ``count``,
  ``retry_after_seconds``.

T4 additions:

- :func:`~skaldos.policy.rate_limit.pre_hook.rate_limit_pre_hook` --- the
  ``authorize_pre_hook`` implementation (§14.7 per-request check).
- :func:`~skaldos.policy.rate_limit.pre_hook.register_rate_limit_pre_hook`
  --- mounts :func:`rate_limit_pre_hook` at priority 1 via
  :func:`~skaldos.policy.hooks.register_authorize_pre_hook`.
- :class:`~skaldos.policy.rate_limit.responses.RateLimitErrorResponse` ---
  Pydantic model for the HTTP 429 response body.

T5/T6 deliverables (shadow/fail mode startup audit, lint) land in later PRs.

References: §14.7, master-plan § "Shared artifacts" → ``Tier`` StrEnum row,
``authorize_pre_hook`` priority-1 reservation, ``PROTECTED_ROUTE_RESPONSES``
floor extension; PC1 (GUC), PC10 (atomic upsert), §18.3 (PgBouncer-tx pool).
"""

from __future__ import annotations

from skaldos.policy.rate_limit.config import RateLimitSettings
from skaldos.policy.rate_limit.counter import increment_and_check
from skaldos.policy.rate_limit.errors import RateLimitExceeded
from skaldos.policy.rate_limit.pool import close_rate_limit_pool, init_rate_limit_pool
from skaldos.policy.rate_limit.pre_hook import rate_limit_pre_hook, register_rate_limit_pre_hook
from skaldos.policy.rate_limit.responses import RateLimitErrorResponse
from skaldos.policy.rate_limit.tier import DEFAULT_TIER, LIMITS, Tier, classify_route

__all__ = [
    "DEFAULT_TIER",
    "LIMITS",
    "RateLimitErrorResponse",
    "RateLimitExceeded",
    "RateLimitSettings",
    "Tier",
    "classify_route",
    "close_rate_limit_pool",
    "increment_and_check",
    "init_rate_limit_pool",
    "rate_limit_pre_hook",
    "register_rate_limit_pre_hook",
]
