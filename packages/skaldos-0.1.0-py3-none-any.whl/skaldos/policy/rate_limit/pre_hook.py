"""``rate_limit_pre_hook`` + ``register_rate_limit_pre_hook`` (rate-limit T4 + T5).

Per ``docs/slices/slice-2-authorization/tiered-rate-limiter/``
``05-task-list.md`` § T4 + T5 and
``docs/slices/slice-2-authorization/tiered-rate-limiter/03-technical-implementation.md``
§ "Pre-hook integration".

This module implements the §14.7 rate-limit check as an ``authorize_pre_hook``
that runs **before** subject loading and Oso evaluation in the
``Depends(authorize(...))`` chokepoint (engine T7 / T8).

Pre-hook flow
-------------

Per ``03 § Architecture``::

    HTTP Request arrives
        │
        ▼
    Slice 1: current_principal (runtime pool, GUCs committed)
        │
        ▼
    Slice 2: Depends(authorize)
        │
        ├─ authorize_pre_hook (this function — priority 1)
        │   ├─ Disabled check (RateLimitSettings.enabled=False → return)
        │   ├─ Determine tier from route attribute (classify_route)
        │   ├─ Acquire conn from rate_limit_pool
        │   │   ├─ pool.acquire() raises unrelated exception:
        │   │   │   ├─ fail_mode="fail_open"  → log rate_limit.error_fail_open + return
        │   │   │   └─ fail_mode="fail_closed" → log rate_limit.error_fail_closed + re-raise
        │   ├─ increment_and_check(conn, principal.id, tier)
        │   │   ├─ count ≤ limit → return (allow)
        │   │   └─ count > limit → raise RateLimitExceeded
        │   │   ├─ increment_and_check raises unrelated exception:
        │   │   │   ├─ fail_mode="fail_open"  → log rate_limit.error_fail_open + return
        │   │   │   └─ fail_mode="fail_closed" → log rate_limit.error_fail_closed + re-raise
        │   ├─ On RateLimitExceeded:
        │   │   ├─ shadow_mode=True  → log "rate_limit.shadow_triggered" + return
        │   │   └─ shadow_mode=False → log "rate_limit.triggered" + re-raise
        │   └─ Release conn (commits independently of handler tx)
        │
        ├─ subject_loader
        ├─ Oso evaluation
        └─ Handler runs

Priority convention
-------------------

Rate-limit reserves priority 1 (earliest); future pre-hooks declare
higher numbers. Documented in master-plan § "Shared artifacts & contracts"
→ ``authorize_pre_hook`` row and in
:mod:`skaldos.policy.hooks`.

Audit log shape (§20.1, §20.2, §20.4)
--------------------------------------

Every ``rate_limit.triggered`` / ``rate_limit.shadow_triggered`` log line
is emitted **inside the active OTel span** (§20.4 enforcement) and carries
only safelisted fields::

    event="rate_limit.triggered"
    decision="denied" | "would_have_denied"
    principal_id=<uuid-str>
    tier=<str>
    count=<int>
    limit=<int>
    retry_after_seconds=<int>

Fail-mode error log lines (T5)::

    event="rate_limit.error_fail_open" | "rate_limit.error_fail_closed"
    error=<str>           (exception repr — no PII)
    fail_mode=<str>

No PII (§20.2): no ``email``, no ``auth0_sub``, no ``display_name``.

Shadow mode (MP7)
-----------------

``RateLimitSettings.shadow_mode=True`` increments the counter normally but
does **not** raise on over-limit. Instead it logs
``event="rate_limit.shadow_triggered", decision="would_have_denied"`` and
returns, letting the request proceed. Used during production rollout to
build confidence before enabling hard rejection.

Fail mode (T5)
--------------

``RateLimitSettings.fail_mode`` governs what happens when the pool acquire
or counter call raises an **unrelated** exception (e.g.
:class:`asyncpg.TooManyConnectionsError`, :class:`ConnectionError`,
generic :class:`Exception`).  This is distinct from
:class:`~skaldos.policy.rate_limit.errors.RateLimitExceeded` which is an
intentional outcome — it is never swallowed.

- ``"fail_open"``  → log ``rate_limit.error_fail_open`` and return ``None``
  (the request proceeds as if the check passed).
- ``"fail_closed"`` → log ``rate_limit.error_fail_closed`` and re-raise the
  original exception (FastAPI's error handler maps it to 503 / 500).

Default is ``"fail_closed"`` per ``02 § E5`` (production posture).  See
:class:`~skaldos.policy.rate_limit.config.RateLimitSettings` for the
env-var override (``RATE_LIMIT_FAIL_MODE``).

Disabled state
--------------

``RateLimitSettings.enabled=False`` → the pre-hook returns immediately
without touching the pool or the counter. Reserved for emergency
operational override; production should never disable silently (see
rate-limit T5's startup audit log for the alert hook).

References
----------
- §14.7 (tiered rate limiting; integration point).
- §20.1, §20.2, §20.4 (structured logs; PII discipline; active-span
  enforcement).
- MP7 (phased rollouts — shadow mode).
- master-plan § "Shared artifacts & contracts" → ``authorize_pre_hook``
  mount + priority row.
- ``02-edge-cases.md`` § E5 (fail-mode), § E24 (shadow-mode operational use).
- ``03-technical-implementation.md`` § "Pre-hook integration",
  § "Architecture", § F1 (priority order), § F5 (propagation contract),
  § F8 (enabled default).
- ``04-testing-strategy.md`` § "Pre-hook integration with engine feature",
  § "Fail mode", § "Shadow mode".
- ``05-task-list.md`` § T4 + T5.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from opentelemetry import trace
from skaldos_log import log

from skaldos.policy.rate_limit.config import RateLimitSettings
from skaldos.policy.rate_limit.counter import increment_and_check
from skaldos.policy.rate_limit.errors import RateLimitExceeded
from skaldos.policy.rate_limit.tier import classify_route

if TYPE_CHECKING:
    from fastapi import FastAPI, Request

    from skaldos.middleware.principal import Principal

__all__ = [
    "rate_limit_pre_hook",
    "register_rate_limit_pre_hook",
]

tracer = trace.get_tracer(__name__)

# Module-level settings instance.  Tests can monkeypatch this name or
# patch ``skaldos.policy.rate_limit.pre_hook._settings`` to inject a
# custom ``RateLimitSettings``.  The instance is constructed once at
# module import time; ``RateLimitSettings()`` reads from environment
# variables at that point (pydantic-settings behaviour).
_settings = RateLimitSettings()


async def rate_limit_pre_hook(request: Request, principal: Principal) -> None:  # type: ignore[type-arg]
    """§14.7 rate-limit check registered as ``authorize_pre_hook`` at priority 1.

    Called by :func:`~skaldos.policy.authorize.authorize`'s inner
    function before subject loading and Oso evaluation.  Raises
    :class:`~skaldos.policy.rate_limit.errors.RateLimitExceeded` when
    the principal's per-minute request count exceeds the tier's budget;
    that exception propagates to FastAPI's registered handler which maps
    it to HTTP 429 + ``Retry-After``.

    Parameters
    ----------
    request:
        The current :class:`fastapi.Request`. Used to read
        ``request.scope["route"]`` (for tier classification) and
        ``request.app.state.rate_limit_pool`` (for conn acquisition).
    principal:
        The hydrated :class:`~skaldos.middleware.principal.Principal`.
        Only ``principal.id`` is used (no PII access).

    Returns
    -------
    None
        On success (count ≤ limit), shadow-mode over-limit, or
        fail-open on an unrelated pool/counter error.

    Raises
    ------
    :class:`~skaldos.policy.rate_limit.errors.RateLimitExceeded`
        When ``count > limit`` and shadow mode is off.  The exception
        carries ``tier``, ``count``, ``limit``, and
        ``retry_after_seconds``; the registered FastAPI exception handler
        serialises those into the 429 body + ``Retry-After`` header.
    :class:`Exception`
        Any unrelated exception from pool acquire or the counter call
        when ``fail_mode="fail_closed"``.  FastAPI's generic exception
        handler maps this to 503 / 500.

    Per §14.7; §20.4; MP7; ``03 § Pre-hook integration``; ``03 § F5``;
    ``02 § E5`` (fail-mode); ``05-task-list.md`` § T4 + T5.
    """
    # Fast exit when the rate-limiter is globally disabled (F8 / emergency
    # operational override).  Note: _settings is a module-level instance
    # that tests can monkeypatch.
    if not _settings.enabled:
        return

    # Determine the tier for this route (reads route.tier attribute; defaults
    # to Tier.STANDARD per classify_route's belt-and-suspenders fallback).
    route = request.scope.get("route")
    tier = classify_route(route) if route is not None else None  # type: ignore[arg-type]
    if tier is None:
        from skaldos.policy.rate_limit.tier import DEFAULT_TIER

        tier = DEFAULT_TIER

    pool = request.app.state.rate_limit_pool  # pyright: ignore[reportUnknownMemberType]

    with tracer.start_as_current_span("rate_limit.check"):
        # --- Pool acquire + counter call, with fail-mode wrapping (T5). ---
        # We separate the pool.acquire() context-manager entry from the
        # increment_and_check call so we can apply the same fail-mode
        # branching to both failure sources in one try/except block.
        try:
            async with pool.acquire() as conn:  # pyright: ignore[reportUnknownMemberType]
                try:
                    await increment_and_check(conn, principal.id, tier)
                except RateLimitExceeded as exc:
                    # RateLimitExceeded is an *intentional* outcome; never
                    # swallowed by fail-mode.  Only shadow_mode governs it.
                    if _settings.shadow_mode:
                        # Shadow mode: log but do NOT raise.  Request proceeds.
                        # Per MP7 (phased rollout) and contract pin in master-plan.
                        log.info(
                            "rate_limit.shadow_triggered",
                            decision="would_have_denied",
                            principal_id=str(principal.id),
                            tier=exc.tier.value,
                            count=exc.count,
                            limit=exc.limit,
                            retry_after_seconds=exc.retry_after_seconds,
                        )
                        return

                    # Hard denial: log then re-raise (F5 — propagation contract).
                    # The registered FastAPI handler maps RateLimitExceeded → 429.
                    log.info(
                        "rate_limit.triggered",
                        decision="denied",
                        principal_id=str(principal.id),
                        tier=exc.tier.value,
                        count=exc.count,
                        limit=exc.limit,
                        retry_after_seconds=exc.retry_after_seconds,
                    )
                    raise
        except RateLimitExceeded:
            # Already handled above — let it propagate.
            raise
        except Exception as pool_or_counter_exc:
            # Unrelated infrastructure error (connection failure, timeout,
            # SQL error, etc.).  Apply fail_mode (T5 / 02 § E5).
            _handle_infra_error(pool_or_counter_exc, _settings.fail_mode)


def _handle_infra_error(exc: Exception, fail_mode: str) -> None:
    """Apply fail-mode branching for an unrelated infrastructure exception (T5).

    Called when ``pool.acquire()`` or ``increment_and_check`` raises anything
    that is **not** :class:`~skaldos.policy.rate_limit.errors.RateLimitExceeded`
    (which is an intentional outcome and is never passed here).

    Parameters
    ----------
    exc:
        The unrelated exception (e.g. asyncpg connection error, timeout).
    fail_mode:
        ``"fail_open"`` or ``"fail_closed"`` from
        :attr:`~skaldos.policy.rate_limit.config.RateLimitSettings.fail_mode`.

    Raises
    ------
    :class:`Exception`
        When ``fail_mode="fail_closed"`` — the original *exc* is re-raised
        so FastAPI's error handler can map it to 503 / 500.

    Returns
    -------
    None
        When ``fail_mode="fail_open"`` — logs
        ``event="rate_limit.error_fail_open"`` and returns, letting the
        request proceed as if the check passed.

    Per ``02 § E5`` (fail-closed default), ``05-task-list.md`` § T5.
    """
    if fail_mode == "fail_open":
        log.warning(
            "rate_limit.error_fail_open",
            error=repr(exc),
            fail_mode=fail_mode,
        )
        return

    # fail_closed: log then re-raise so the caller propagates to FastAPI.
    log.warning(
        "rate_limit.error_fail_closed",
        error=repr(exc),
        fail_mode=fail_mode,
    )
    raise exc


def register_rate_limit_pre_hook(app: FastAPI) -> None:
    """Register :func:`rate_limit_pre_hook` on ``app`` at priority 1.

    Wraps :func:`~skaldos.policy.hooks.register_authorize_pre_hook` with
    the rate-limit's reserved priority 1 (lowest integer = earliest
    execution in the hook chain).

    Priority convention (per master-plan § "Shared artifacts & contracts"):

    - **Priority 1** — reserved for the rate-limiter (§14.7). Fires first.
    - **Priority 2+** — future hooks; declare higher numbers to fire later.

    Call this once in ``create_app()`` after
    :func:`~skaldos.api.whoami.register_whoami_if_enabled` (the standard
    registration site per ``app.py``).

    Parameters
    ----------
    app:
        The :class:`fastapi.FastAPI` instance to register the hook on.
        After this call, ``app.state.authorize_pre_hooks[1]`` is
        :func:`rate_limit_pre_hook`.

    Per §14.7; master-plan § "Shared artifacts & contracts" →
    ``authorize_pre_hook`` priority-1 reservation;
    ``05-task-list.md`` § T4.
    """
    from skaldos.policy.hooks import register_authorize_pre_hook

    register_authorize_pre_hook(app, rate_limit_pre_hook, priority=1)
