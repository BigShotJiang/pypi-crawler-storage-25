"""OpenAPI response shapes for protected routes (Slice 2, engine T7 + rate-limit T4).

Per ``docs/slices/slice-2-authorization/master-plan.md``
§ "Shared artifacts & contracts" → ``PROTECTED_ROUTE_RESPONSES`` and
``03-technical-implementation.md`` § "Fault lines" → F4.

``PROTECTED_ROUTE_RESPONSES``
------------------------------

The **floor** that every protected route ships.  Extends Slice 1's
:data:`~skaldos.middleware.openapi_responses.PRINCIPAL_HYDRATION_RESPONSES`
(which covers 403 principal-disabled, 409 email-collision, 500, 503).
Engine T7 + rate-limit T4 together populate the full floor:

- ``403`` → :class:`AuthorizationErrorResponse` (supersedes Slice 1's
  ``PrincipalErrorResponse``-based 403; structurally compatible but the
  ``reason_code`` field added here is specific to the authorization layer).
- ``422`` → :class:`IntentErrorResponse` (intent required or not allowed).
- ``503`` → :class:`PolicyEvaluationErrorResponse` for policy-engine failures,
  while retaining hydration 503 examples such as pool exhaustion.
- ``429`` → :class:`~skaldos.policy.rate_limit.responses.RateLimitErrorResponse`
  (wired by rate-limit T4; engine T7 planted the placeholder slot so the
  floor contract was stable before T4 shipped).
- ``404`` → not in the floor (only routes with ``subject_loader`` expose
  this status); routes with a loader add it themselves.

Fault line F4
-------------

``PROTECTED_ROUTE_RESPONSES`` is a **minimum** floor.  Routes can add
more (e.g., ``404`` for routes with ``subject_loader``); they cannot
subtract.  The lint script ``scripts/check_protected_routes_carry_responses.py``
(engine T9) asserts the floor is present on every protected route.  Per
``03 § F4``.

References: §10.2 (OpenAPI 3.1 as contract); §14.7 (429 rate-limit shape);
Slice 1 followups #9 (OpenAPI error-response wiring); ``03 § F4`` (floor
must not erode); master-plan § "Shared artifacts & contracts" →
``PROTECTED_ROUTE_RESPONSES``; rate-limit T4 (wires
``RateLimitErrorResponse`` into the 429 slot).
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict

from skaldos.middleware.openapi_responses import (
    PRINCIPAL_HYDRATION_RESPONSES,
    PrincipalErrorResponse,
)
from skaldos.policy.rate_limit.responses import RateLimitErrorResponse

__all__ = [
    "PROTECTED_ROUTE_RESPONSES",
    "AuthorizationErrorResponse",
    "IntentErrorResponse",
    "PolicyEvaluationErrorResponse",
    "RateLimitErrorResponse",
]


# ---------------------------------------------------------------------------
# Response body models
# ---------------------------------------------------------------------------


class AuthorizationErrorResponse(BaseModel):
    """OpenAPI schema for HTTP 403 authorization-denied responses.

    The JSON body returned by the exception handler when the Oso
    chokepoint denies a request or the principal is disabled at the
    authorization layer.

    Fields
    ------
    error_code:
        Stable error-code string.  Always ``"authorization_denied"``
        for authorization-layer 403s.  Clients (frontend Zod, MCP error
        decoder) dispatch on this value.
    reason_code:
        One of :class:`~skaldos.policy.errors.ReasonCode`'s members.
        Gives the specific reason for denial without exposing
        implementation details (no stack trace; no DB state).

    Frozen + strict-extra (AP5): rejects unknown kwargs at construction.
    No PII in either field (§20.2 / §13.2).

    Per ``03 § Error-management plan``; §10.2; master-plan
    § "Shared artifacts" → "Reason code taxonomy".
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    error_code: str = "authorization_denied"
    reason_code: str


class IntentErrorResponse(BaseModel):
    """OpenAPI schema for HTTP 422 intent-validation failures.

    Returned when the chokepoint raises :class:`IntentRequiredError` or
    :class:`IntentNotAllowedError`.  The ``allowed`` field lists the
    intent values the route accepts so the caller can correct the request
    without consulting the documentation.

    Fields
    ------
    error_code:
        ``"intent_required"`` or ``"intent_not_allowed"``.
    reason_code:
        One of ``"intent_required"`` or ``"intent_not_allowed"``.
    allowed:
        The allowed intent values for this ``(action, subject_kind)`` pair,
        sorted for determinism.  Empty list when the action is read-only
        (no intent gate applies; this branch is defensive).

    Frozen + strict-extra (AP5).

    Per §10.12; ``03 § Error-management plan``; ``03 § F3``.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    error_code: str
    reason_code: str
    allowed: list[str] = []


class PolicyEvaluationErrorResponse(BaseModel):
    """OpenAPI schema for fail-closed policy-engine evaluation failures."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    error_code: str = "policy_evaluation_error"
    reason_code: str = "policy_evaluation_error"


# ---------------------------------------------------------------------------
# PROTECTED_ROUTE_RESPONSES — the floor for every protected route.
#
# Structure: extends PRINCIPAL_HYDRATION_RESPONSES (Slice 1 floor) then
# overrides/adds the Slice 2 entries.
#
# Note: PRINCIPAL_HYDRATION_RESPONSES carries 403, 409, 500, 503.
# T7 overrides 403 with AuthorizationErrorResponse (the authorization-layer
# 403 shape, which adds reason_code).  409 / 500 carry through unchanged.
# 503 is widened to include policy-engine failure while preserving the
# hydration-layer examples and Retry-After header.
#
# 422 is added for intent validation (FastAPI's default 422 is untyped;
# this gives it a schema so the OpenAPI contract is explicit).
#
# 429 is added as a placeholder; rate-limit T4 replaces the description
# with a full RateLimitErrorResponse model when it lands.  The slot must
# exist now so the OpenAPI floor doesn't drift between T7 and T4.
# ---------------------------------------------------------------------------

PROTECTED_ROUTE_RESPONSES: dict[int | str, dict[str, Any]] = {
    # Carry through Slice 1's hydration-layer responses (409, 500, 503)
    # using dict-spread so the floor is a superset of the Slice 1 floor.
    **{k: v for k, v in PRINCIPAL_HYDRATION_RESPONSES.items() if k != 403},
    # 403: authorization-denied (T7 shape supersedes Slice 1's 403).
    403: {
        "model": AuthorizationErrorResponse,
        "description": (
            "Authorization denied (authorization layer). The principal is "
            "recognized but the requested action is refused by the Oso policy. "
            "``reason_code`` carries the specific denial reason."
        ),
        "content": {
            "application/json": {
                "example": {
                    "error_code": "authorization_denied",
                    "reason_code": "principal_role_insufficient_for_action",
                },
            },
        },
    },
    # 401: unauthenticated (no/invalid JWT). FastAPI returns this before
    # the dependency chain runs; we document it here so clients know the
    # shape. The body is FastAPI's default {"detail": "..."}.
    401: {
        "description": "Unauthenticated. No JWT or invalid JWT supplied.",
        "content": {
            "application/json": {
                "example": {"detail": "Not authenticated"},
            },
        },
    },
    # 422: intent validation failed (IntentRequiredError or IntentNotAllowedError).
    # Also covers FastAPI's standard request-body validation failures.
    422: {
        "model": IntentErrorResponse,
        "description": (
            "Unprocessable: intent required but absent (``intent_required``) "
            "or supplied intent is not in the allowed set for this "
            "``(action, subject_kind)`` pair (``intent_not_allowed``). "
            "Also covers standard FastAPI request-body validation failures."
        ),
        "content": {
            "application/json": {
                "example": {
                    "error_code": "intent_required",
                    "reason_code": "intent_required",
                    "allowed": ["assertive"],
                },
            },
        },
    },
    # 503: service unavailable. Covers Slice 1 hydration infrastructure
    # failures plus Slice 2 policy-engine evaluation failures. Runtime can
    # return either PrincipalErrorResponse (hydration) or
    # PolicyEvaluationErrorResponse (policy engine).
    503: {
        "model": PrincipalErrorResponse | PolicyEvaluationErrorResponse,
        "description": (
            "Service unavailable. Covers principal-hydration infrastructure "
            "failures and policy-engine evaluation failures. "
            "``policy_evaluation_error`` means the Oso policy engine failed "
            "before producing an allow/deny decision."
        ),
        "headers": PRINCIPAL_HYDRATION_RESPONSES[503].get("headers", {}),
        "content": {
            "application/json": {
                "examples": {
                    **PRINCIPAL_HYDRATION_RESPONSES[503]["content"]["application/json"].get(
                        "examples", {}
                    ),
                    "policy-evaluation-error": {
                        "summary": "Oso/policy engine evaluation failed.",
                        "value": {
                            "error_code": "policy_evaluation_error",
                            "reason_code": "policy_evaluation_error",
                        },
                    },
                },
            },
        },
    },
    # 429: rate limit exceeded. Wired by rate-limit T4 with the full
    # RateLimitErrorResponse model (replaces the placeholder that engine T7
    # planted so the floor contract was stable between T7 and T4).
    # Body: RateLimitErrorResponse; header: Retry-After (seconds).
    # Per §14.7; 03 § F4 (floor must not erode); master-plan § "Shared
    # artifacts" → PROTECTED_ROUTE_RESPONSES floor: {401, 403, 422, 429}.
    429: {
        "model": RateLimitErrorResponse,
        "description": (
            "Rate limit exceeded. The principal has exceeded the per-minute "
            "request budget for their tier (§14.7). "
            "``Retry-After`` header attached (seconds until the next window). "
            "``code`` field is always ``rate_limit_exceeded``."
        ),
        "headers": {
            "Retry-After": {
                "description": "Seconds until the rate-limit window resets.",
                "schema": {"type": "string", "example": "60"},
            },
        },
        "content": {
            "application/json": {
                "example": {
                    "code": "rate_limit_exceeded",
                    "tier": "standard",
                    "limit": 100,
                    "count": 101,
                    "retry_after_seconds": 42,
                },
            },
        },
    },
}
"""FastAPI ``responses=`` mapping floor for every ``Depends(authorize)``-protected route.

Pass this dict (merged with any route-specific additions) to the ``responses``
kwarg on each protected route definition:

.. code-block:: python

    @router.get(
        "/memberships/{id}",
        responses={
            **PROTECTED_ROUTE_RESPONSES,
            404: {"description": "Membership not found or not visible."},
        },
    )
    async def get_membership(
        membership: MembershipRow = Depends(authorize("read", AppSubject.MEMBERSHIP,
                                                      subject_loader=load_membership_by_id)),
    ) -> MembershipResponse:
        ...

Floor keys: ``{401, 403, 409, 422, 429, 500, 503}``.  Routes can add
``404`` (routes with ``subject_loader``) and other domain-specific codes;
they cannot remove entries from the floor.

Per §10.2 (OpenAPI 3.1); ``03 § F4`` (floor must not erode); rate-limit T4
(adds ``RateLimitErrorResponse`` to the ``429`` slot); master-plan
§ "Shared artifacts & contracts".
"""


# ---------------------------------------------------------------------------
# Backward-compat re-export for Slice 1 consumers.
# ---------------------------------------------------------------------------

__all__ += ["PrincipalErrorResponse"]  # type: ignore[list-item]
