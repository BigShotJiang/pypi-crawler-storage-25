"""``authorize_pre_hook`` mount point (Slice 2, engine T8).

Per ``docs/slices/slice-2-authorization/policy-module-and-chokepoint/``
``03-technical-implementation.md`` § "Architecture" → pre-hook flow, and
``05-task-list.md`` § T8.

The pre-hook is a callable that runs inside the ``authorize`` dependency
**before** ``subject_loader`` and Oso evaluation. This is the §14.7
rate-limiter integration point: the rate-limiter peer feature mounts its
check at priority 1 (lowest = earliest).

Pre-hook priority convention (per master plan § "Shared artifacts &
contracts"):

    Rate-limit reserves priority 1 (earliest); future pre-hooks declare
    higher numbers. Hooks execute in ascending priority order.

Public surface::

    from skaldos.policy.hooks import (
        AuthorizePreHook,
        get_authorize_pre_hooks,
        register_authorize_pre_hook,
    )

Storage
-------

Hooks are stored on ``app.state.authorize_pre_hooks: dict[int,
AuthorizePreHook]``.  Lower priority integer = earlier execution.
If the attribute is absent (app started without any registered hooks),
:func:`get_authorize_pre_hooks` returns an empty list.

References: §14.7 (tiered rate limiting; this module is the integration
point); §20.1 (structured logs — called before span opens; hooks
themselves decide whether to log); ``03-technical-implementation.md``
§ "Architecture"; master plan § "Shared artifacts & contracts" →
``authorize_pre_hook`` row.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from fastapi import FastAPI, Request

    from skaldos.middleware.principal import Principal

__all__ = [
    "AuthorizePreHook",
    "get_authorize_pre_hooks",
    "register_authorize_pre_hook",
]

# ---------------------------------------------------------------------------
# Type alias
# ---------------------------------------------------------------------------

AuthorizePreHook = Callable[["Request", "Principal"], Awaitable[None]]
"""A pre-hook callable invoked before subject loading and Oso evaluation.

Signature::

    async def my_hook(request: Request, principal: Principal) -> None: ...

The hook may raise (e.g. :class:`~skaldos.policy.rate_limit.errors.RateLimitError`
→ 429) to short-circuit the chokepoint.  It must not return a value other than
``None``.

Rate-limit peer feature registers at priority 1 (lowest = earliest);
future hooks declare higher priorities.
"""


# ---------------------------------------------------------------------------
# Default no-op hook (used when registry is empty)
# ---------------------------------------------------------------------------


async def _default_pre_hook(request: Request, principal: Principal) -> None:  # type: ignore[type-arg]
    """No-op pre-hook for the empty-registry case.

    Engine T8 uses this as the placeholder callable before any hook is
    registered.  The rate-limiter peer feature replaces this at app
    startup via :func:`register_authorize_pre_hook`.
    """
    return None


# ---------------------------------------------------------------------------
# Registration API
# ---------------------------------------------------------------------------


def register_authorize_pre_hook(
    app: FastAPI,
    hook: AuthorizePreHook,
    *,
    priority: int,
) -> None:
    """Register a pre-hook on ``app.state.authorize_pre_hooks``.

    Initialises the registry dict if it is absent.  Each priority key maps
    to one hook; registering a second hook at the same priority overwrites
    the first.

    Priority convention (per master plan § "Shared artifacts & contracts"):

    - **Priority 1** — reserved for the rate-limiter (§14.7).  The hook
      fires first (lowest integer = earliest execution).
    - **Priority 2+** — future hooks; declare higher numbers to fire later.

    Parameters
    ----------
    app:
        The :class:`fastapi.FastAPI` instance whose
        ``app.state.authorize_pre_hooks`` registry is written.
    hook:
        An :data:`AuthorizePreHook` callable.
    priority:
        Execution priority; lower = earlier.  Rate-limit reserves ``1``.

    References: §14.7; master plan § "Shared artifacts" → pre-hook row;
    ``03 § Architecture``.
    """
    if not hasattr(app.state, "authorize_pre_hooks"):
        app.state.authorize_pre_hooks = {}  # type: ignore[assignment]
    app.state.authorize_pre_hooks[priority] = hook  # pyright: ignore[reportUnknownMemberType]


# ---------------------------------------------------------------------------
# Accessor API
# ---------------------------------------------------------------------------


def get_authorize_pre_hooks(app: FastAPI) -> list[AuthorizePreHook]:
    """Return the registered pre-hooks in ascending priority order.

    Called by the ``authorize`` dependency inner function at request time
    (engine T7 reads ``app.state.authorize_pre_hooks``; T8 replaces the
    direct ``getattr`` call with this accessor for consistency).

    Returns an empty list when ``app.state.authorize_pre_hooks`` is not
    set (no hooks registered yet — the caller skips the hook loop).

    Parameters
    ----------
    app:
        The :class:`fastapi.FastAPI` instance to read from.

    Returns
    -------
    list[AuthorizePreHook]
        Hooks in ascending priority order (lowest priority integer first).
        Empty if no hooks are registered.
    """
    registry: dict[int, AuthorizePreHook] | None = getattr(app.state, "authorize_pre_hooks", None)
    if not registry:
        return []
    return [hook for _priority, hook in sorted(registry.items())]
