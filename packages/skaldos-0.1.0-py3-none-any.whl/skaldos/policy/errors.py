"""Authorization error types + reason codes (Slice 2, engine T7).

Per ``docs/slices/slice-2-authorization/policy-module-and-chokepoint/``
``03-technical-implementation.md`` § "Module layout" → ``errors.py`` and
``05-task-list.md`` § T7.

Reason codes (closed enum per master-plan § "Shared artifacts & contracts"
→ "Reason code taxonomy").  New codes require master-plan amendment.

Error-management plan (``03 § Error-management plan``)
-------------------------------------------------------

| Failure                                     | HTTP  | Reason code                           |
|---------------------------------------------|-------|---------------------------------------|
| Oso denies (``is_allowed → False``)          | 403   | principal_role_insufficient_for_action |
| ``subject_loader`` returns ``None``          | 404   | subject_not_found                     |
| Principal has no role in tenant              | 403   | principal_lacks_role_in_tenant        |
| Intent missing on write route               | 422   | intent_required                       |
| Intent not in ``ALLOWED_INTENTS``            | 422   | intent_not_allowed                    |
| Principal is disabled                        | 403   | principal_disabled                    |
| Rate limit exceeded                          | 429   | rate_limit_exceeded                   |

References: §4.1 (authorization is a primitive); ``03 § Error-management
plan``; master-plan § "Shared artifacts & contracts" → "Reason code
taxonomy"; ADR 2 (Oso); AP5 (no bypass).
"""

from __future__ import annotations

from enum import StrEnum
from typing import TYPE_CHECKING
from uuid import UUID

if TYPE_CHECKING:
    from skaldos.policy.intent import ActionLiteral, Intent
    from skaldos.policy.subjects import AppSubject


class ReasonCode(StrEnum):
    """Closed set of reason codes for authorization denials.

    The string values are the exact values that appear in the
    ``reason_code`` field of the JSON error response body.  Clients
    (frontend Zod, MCP error decoder) dispatch on these strings.
    Renaming a code is a breaking change to the API contract (§10.2).

    New codes require master-plan amendment per the "Reason code
    taxonomy" row in master-plan § "Shared artifacts & contracts".
    """

    principal_role_insufficient_for_action = "principal_role_insufficient_for_action"
    subject_not_found = "subject_not_found"
    principal_lacks_role_in_tenant = "principal_lacks_role_in_tenant"
    intent_required = "intent_required"
    intent_not_allowed = "intent_not_allowed"
    principal_disabled = "principal_disabled"
    rate_limit_exceeded = "rate_limit_exceeded"


class AuthorizationError(Exception):
    """Base class for authorization failures at the chokepoint.

    Raised by the inner async function of ``Depends(authorize(...))``
    when the chokepoint refuses the request.  The FastAPI exception
    handler in ``app.py`` maps each subclass to its canonical HTTP status
    and JSON body shape.

    Fields
    ------
    reason:
        Why the request was denied.  From :class:`ReasonCode`.
    principal_id:
        The requesting principal's UUID.  ``None`` if the principal
        could not be resolved before the error was raised (unlikely
        in practice; the principal hydration chokepoint runs first).
    action:
        The action the principal attempted.
    subject_kind:
        The subject class being acted upon.
    subject_id:
        The subject's UUID.  ``None`` for ``create`` actions (no
        pre-existing subject row) and for routes without
        ``subject_loader``.
    intent:
        The intent supplied by the caller.  ``None`` for read actions
        or when intent validation fired before the intent was parsed.

    Message format
    --------------
    ``"authorization denied: reason=<reason> action=<action>
    subject_kind=<subject_kind>"`` — no PII in the message; structured
    context lives in the typed fields (emitted to the structlog event by
    the exception handler, not in the string).

    References: ``03 § Error-management plan``; §10.2 (JSON body shape);
    §13.4 (audit); AP5 (no bypass).
    """

    def __init__(  # noqa: PLR0913
        self,
        *,
        reason: ReasonCode,
        principal_id: UUID | None,
        action: ActionLiteral,
        subject_kind: AppSubject,
        subject_id: UUID | None = None,
        intent: Intent | None = None,
    ) -> None:
        self.reason = reason
        self.principal_id = principal_id
        self.action = action
        self.subject_kind = subject_kind
        self.subject_id = subject_id
        self.intent = intent
        super().__init__(
            f"authorization denied: reason={reason} action={action} subject_kind={subject_kind}"
        )


class PolicyEvaluationError(Exception):
    """Raised when the policy engine fails before making an allow/deny decision.

    This is distinct from :class:`AuthorizationError`: an Oso ``False``
    decision is a legitimate 403 denial, while an exception from the policy
    engine is a fail-closed service error that operators need to see as such.
    """

    reason_code = "policy_evaluation_error"

    def __init__(
        self,
        *,
        principal_id: UUID | None,
        action: ActionLiteral,
        subject_kind: AppSubject,
        subject_id: UUID | None = None,
        intent: Intent | None = None,
    ) -> None:
        self.principal_id = principal_id
        self.action = action
        self.subject_kind = subject_kind
        self.subject_id = subject_id
        self.intent = intent
        super().__init__(f"policy evaluation failed: action={action} subject_kind={subject_kind}")


class IntentRequiredError(AuthorizationError):
    """Raised when a write route requires an intent but none was supplied.

    Maps to HTTP 422 (the caller provided a structurally valid request
    but semantically incomplete — the intent speech-act type is missing).

    ``reason`` is always :attr:`ReasonCode.intent_required`.

    Per §10.12 (intent required on writes); ``03 § F3``
    (startup-time validation catches mis-wired routes; runtime raises
    this when a route is correctly wired but the caller omits the intent).
    """

    def __init__(
        self,
        *,
        principal_id: UUID | None,
        action: ActionLiteral,
        subject_kind: AppSubject,
        subject_id: UUID | None = None,
    ) -> None:
        super().__init__(
            reason=ReasonCode.intent_required,
            principal_id=principal_id,
            action=action,
            subject_kind=subject_kind,
            subject_id=subject_id,
            intent=None,
        )


class IntentNotAllowedError(AuthorizationError):
    """Raised when the caller supplied an intent not in ``ALLOWED_INTENTS``.

    Maps to HTTP 422 (structurally valid but semantically wrong — the
    supplied intent is not an allowed speech-act type for this
    (action, subject) pair).

    ``reason`` is always :attr:`ReasonCode.intent_not_allowed`.

    Per §10.12; master-plan § "Shared artifacts" → ``ALLOWED_INTENTS``.
    """

    def __init__(
        self,
        *,
        principal_id: UUID | None,
        action: ActionLiteral,
        subject_kind: AppSubject,
        intent: Intent,
        subject_id: UUID | None = None,
    ) -> None:
        super().__init__(
            reason=ReasonCode.intent_not_allowed,
            principal_id=principal_id,
            action=action,
            subject_kind=subject_kind,
            subject_id=subject_id,
            intent=intent,
        )


class SubjectNotFoundError(AuthorizationError):
    """Raised when ``subject_loader`` returns ``None``.

    Maps to HTTP 404 — the subject does not exist *or* it exists but RLS
    hides it from the principal.  Callers cannot distinguish these two
    cases by design (information leakage prevention; ML5(3)).

    ``reason`` is always :attr:`ReasonCode.subject_not_found`.

    Per §4.5 (tenant derived from subject; absent subject → 404);
    ``03 § Error-management plan`` (subject_loader None → 404, not 403).
    """

    def __init__(
        self,
        *,
        principal_id: UUID | None,
        action: ActionLiteral,
        subject_kind: AppSubject,
        subject_id: UUID | None = None,
    ) -> None:
        super().__init__(
            reason=ReasonCode.subject_not_found,
            principal_id=principal_id,
            action=action,
            subject_kind=subject_kind,
            subject_id=subject_id,
            intent=None,
        )
