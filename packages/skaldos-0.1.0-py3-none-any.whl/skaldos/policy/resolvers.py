"""Polar host resolvers for SkaldOS v2 authorization (Slice 2, subject T3).

Per ``docs/slices/slice-2-authorization/subject-vocabulary-and-policies/``
``03-technical-implementation.md`` § "Role lookup (Polar primitive)" and
§ "F1" (resolver pool discipline).

This module owns two public symbols:

- :func:`role_in_org` --- the async Polar host resolver that looks up a
  principal's active role in an organization.  Called by Oso during
  evaluation of ``role_in_org(principal, role, organization_id)`` in
  ``policies/_common.polar``.

- :func:`register_resolvers` --- the registration seam engine T7 calls
  once at Oso host construction time.  This seam decouples subject T3
  (resolver + registration) from engine T7 (Oso host instantiation) so
  both can land in Wave 2 independently, per the master-plan "Coordination
  note" in § "Wave 2":

      Subject T3 ships with a small ``register_resolvers(host)`` function
      that engine T7 imports and calls.  Both can be drafted in parallel;
      the import-call seam is small.

Pool discipline (§4.5 / ML5(3) / 03 § F1)
-----------------------------------------

The resolver runs SQL against ``memberships`` using the **runtime pool
connection** already held by the request's ``current_principal``
dependency.  This connection:

- Is authenticated as ``app_runtime`` (RLS-bound; not BYPASSRLS).
- Has the ``set_config('app.current_principal_id', ...)`` and
  ``set_config('app.current_principal_visible', ...)`` GUCs committed.
- Is the *same* connection used by every other RLS-bound query in the
  request handler.

The connection is retrieved from ``principal._conn``, a private
attribute engine T7 sets via
``object.__setattr__(principal, '_conn', conn)`` before invoking Oso
evaluation.  Pydantic v2's ``frozen=True`` prevents normal ``setattr``;
``object.__setattr__`` bypasses the Pydantic validator for exactly this
purpose — the ``_conn`` attribute is not part of the model schema and
is invisible to Pydantic's field validation.

**Critical invariant:** the resolver MUST NOT acquire a new connection
from any pool.  If it did, the new connection would lack the GUC contract
→ RLS returns zero rows → role lookup returns ``None`` → every
``allow`` rule that calls ``has_role_in_org`` denies → universal 403 for
all principals with active memberships.

Detection: ``test_role_in_org_resolver_uses_runtime_pool_conn`` pins
this invariant (master-plan "Slice 2 spikes" table; living test;
cannot regress silently).

R4-clean SQL
------------

The resolver's query is R4-clean per ML5(3): it reads the subject's
tenant (``organization_id`` parameter, derived from the subject row at
call time) and the principal's identity (``principal.id``) from their
respective typed arguments.  It does NOT read from ``request.state``,
GUC functions, or any ambient source.

``register_resolvers`` seam
---------------------------

Engine T7 owns ``pip install oso`` and ``Oso()`` instantiation.  This
module uses a ``TYPE_CHECKING``-only import of ``oso.Oso`` so pyright
can type-check the ``register_resolvers`` signature without adding ``oso``
to this package's runtime dependencies (per the "Hard NO list":
"Do NOT add the ``oso`` dependency").

At runtime, ``register_resolvers(host)`` receives the live ``Oso`` instance
and calls its registration methods directly; no runtime ``oso`` import is
required in *this* module.

References: §4.5, ML5(3), MP1, 03 § F1, master-plan "Coordination note"
(Wave 2), master-plan "Slice 2 spikes" row 1, ADR 2.
"""

from __future__ import annotations

from typing import TYPE_CHECKING
from uuid import UUID

from skaldos_log import log

from skaldos.middleware.principal import Principal

if TYPE_CHECKING:
    # Runtime import of ``oso`` is owned by engine T7 (``policy/host.py``).
    # The ``TYPE_CHECKING`` guard keeps the annotation available to pyright
    # without introducing an ``oso`` runtime dependency in this module.
    from oso import Oso  # pyright: ignore[reportMissingImports, reportUnknownVariableType]

__all__ = [
    "register_resolvers",
    "role_in_org",
]


# ---------------------------------------------------------------------------
# SQL — pinned verbatim.
#
# Changes to this query require:
#   1. Updating tests that pin the SQL string shape.
#   2. Verifying that the ORDER BY … LIMIT 1 defense-in-depth clause
#      is preserved (per fault line F5 in 03-technical-implementation.md).
# ---------------------------------------------------------------------------

_ROLE_LOOKUP_SQL = """\
SELECT role::text
  FROM memberships
 WHERE principal_id = $1
   AND tenant_id    = $2
   AND revoked_at IS NULL
 ORDER BY granted_at DESC
 LIMIT 1
"""
"""Active-membership role lookup query (R4-clean).

Column mapping:
- ``principal_id = $1`` — the principal's UUID (``principal.id``).
- ``tenant_id = $2`` — the organization UUID from the subject row
  (``organization_id`` parameter); NEVER from ``principal`` or request state.
- ``revoked_at IS NULL`` — active membership only.
- ``ORDER BY granted_at DESC LIMIT 1`` — deterministic under the edge case
  of overlapping memberships (defense-in-depth per F5; the unique partial
  index ``memberships_principal_tenant_active_idx`` on
  ``(principal_id, tenant_id) WHERE revoked_at IS NULL`` prevents
  duplicates in normal operation).
"""


async def role_in_org(
    principal: Principal,
    role: str,
    organization_id: UUID,
) -> bool:
    """Return ``True`` iff *principal* holds *role* in *organization_id*.

    ``organization_id`` is the Polar/product alias taken from the subject
    row. The storage lookup binds it to ``memberships.tenant_id``; this
    resolver must never substitute ``principal.primary_tenant_id`` or any
    other actor-derived tenant value.

    This is the Python-side host resolver called by Oso during evaluation
    of the Polar rule:

    .. code-block:: polar

        has_role_in_org(principal, role, organization_id) if
            role_in_org(principal, role, organization_id);

    in ``policies/_common.polar``.

    Args:
        principal: The request-scope :class:`~skaldos.middleware.Principal`.
            The runtime connection is retrieved from ``principal._conn``,
            set by engine T7 via
            ``object.__setattr__(principal, '_conn', conn)`` before Oso
            evaluation begins.
        role: The role string to test against.  One of ``"owner"``,
            ``"admin"``, or ``"member"``.  Polar passes this from the
            policy rule's literal string argument.
        organization_id: The tenant UUID derived from the *subject* row's
            policy-alias ``organization_id`` field.  MUST come from the
            subject, never from ambient request state (§4.5 / ML5(3)).

    Returns:
        ``True`` if the principal has an active, unrevoked membership with
        exactly *role* in *organization_id*; ``False`` otherwise
        (including when no active membership exists).

    Raises:
        :class:`RuntimeError`: If ``principal._conn`` is not set.  Engine
            T7 must attach the runtime connection before calling Oso
            evaluation — a missing ``_conn`` is a substrate-integrity bug,
            not a user error.

    Pool discipline (03 § F1):
        Runs on ``principal._conn`` — the ``app_runtime`` connection already
        held open for the duration of the request.  Does NOT acquire a new
        connection from any pool.
    """
    conn = getattr(principal, "_conn", None)
    if conn is None:
        raise RuntimeError(
            "role_in_org: principal._conn is not set. "
            "Engine T7 must attach the runtime pool connection via "
            "object.__setattr__(principal, '_conn', conn) before invoking "
            "Oso evaluation. This is a substrate-integrity bug."
        )

    try:
        row = await conn.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            _ROLE_LOOKUP_SQL,
            principal.id,
            organization_id,
        )
    except Exception:
        log.exception(
            "policy.role_resolver_failed",
            principal_id=str(principal.id),
            organization_id=str(organization_id),
        )
        raise

    actual_role: str | None = row["role"] if row is not None else None
    return actual_role == role


def register_resolvers(host: Oso) -> None:  # type: ignore[name-defined]
    """Register all Polar host resolvers with *host*.

    Called once at Oso host construction time by engine T7:

    .. code-block:: python

        from skaldos.policy.resolvers import register_resolvers

        _oso = Oso()
        _oso.load_files(["policies/_common.polar", ...])
        register_resolvers(_oso)

    Registers:
        ``role_in_org`` — the async Python callable that Oso invokes
        during evaluation of ``role_in_org(principal, role, org_id)``
        in ``policies/_common.polar``.  Registered as a Polar constant
        so the name ``role_in_org`` is resolvable in policy rules.

    The ``Oso`` type annotation is available to pyright via the
    ``TYPE_CHECKING`` guard; at runtime the argument is the live ``oso.Oso``
    instance and the ``name-defined`` ignore suppresses pyright's complaint
    about the annotation.

    Args:
        host: The live ``oso.Oso`` instance constructed and owned by
            engine T7's ``policy/host.py``.
    """
    host.register_constant(role_in_org, name="role_in_org")  # pyright: ignore[reportUnknownMemberType]
