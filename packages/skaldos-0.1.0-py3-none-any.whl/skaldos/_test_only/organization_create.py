"""Fixture handler: ``POST /api/_test_only/organization_create``.

AP5 idiom: this handler is a **fixture surface**, not an application bypass.
It goes through ``Depends(authorize)`` — the real chokepoint — and is
registered only when ``SKALDOS_ENV != 'production'``.  Absent from
production builds by construction (see ``__init__.py``
:func:`register_test_only_routes_if_enabled`).

## Purpose

Exercises the chokepoint's ``create`` Organization decision.  Used by
the gate's "no role can create organization via the API" scenario 5
(``test_no_role_can_create_organization_via_api``).

The pinned property: organizations are provisioned via Auth0 SSO
onboarding, **not** the public API.  ``policies/organization.polar``
ships **no** ``allow(_, "create", org: Organization)`` rule — Oso's
open-world combinator denies for every principal regardless of role
(owner, admin, member; human or agent — MP10).

The handler exists so the gate scenario can issue a real HTTP request
through the chokepoint and confirm the deny — without it, the test would
have to evaluate the policy outside the request lifecycle and lose the
"verified in a running environment" property (AP4).

The handler stands in for Slice 7's real ``POST /organizations`` (per
``feature-catalog.md`` § A2 — though Slice 7 itself may decline to ship
this endpoint and route org creation through the SSO callback only;
either way, the fixture pins the deny semantic).

## No subject_loader, no target_tenant_loader

Create-Organization is the canonical "no row exists yet, no target
tenant either" shape: a brand-new org has no parent.  The chokepoint's
``oso_subject`` falls back to ``AppSubject.ORGANIZATION`` (the kind enum)
and Polar's missing ``allow(_, "create", _: Organization)`` rule denies
unconditionally.  This is the desired behaviour — the test asserts deny
across every role × kind combination.

## Request body

```json
{ "display_name": "Acme Corp" }
```

The body is echoed back on allow (which never happens in production, but
the schema is forward-compatible with Slice 7's eventual handler).

## References

- §4.1   — every endpoint through ``can()``; this handler is no exception.
- §4.5   — closed subject vocabulary; missing rule = deny.
- ``policies/organization.polar`` — the (intentionally) absent allow rule.
- AP3    — matrix EXPECTED has ``("Organization", "create", *) → "deny"``
  for every role; this fixture pins the same property at the HTTP layer.
- AP5    — ``Depends(authorize)`` is the chokepoint; no side-channel.
- E7 (``02-edge-cases.md``) — SSO-onboarding-only provisioning path.
- Slice 7 (the real ``POST /organizations`` per ``feature-catalog.md``
  § A2, if it ships at all).
- ``docs/specs/2026-05-04-slice-2-followups.md`` followup #2.
"""

from __future__ import annotations

from typing import Annotated, Any

from fastapi import APIRouter
from pydantic import BaseModel, ConfigDict

from skaldos.policy import PROTECTED_ROUTE_RESPONSES
from skaldos.policy.authorize import authorize
from skaldos.policy.intent import Intent
from skaldos.policy.subjects import AppSubject

router = APIRouter(prefix="/api/_test_only")


class OrganizationCreateRequest(BaseModel):
    """Request body for the organization-create fixture handler.

    ``display_name``: the human-readable label for the new organization.
    Only relevant on the (unreachable) allow path — the chokepoint denies
    every create-Organization request, so the body is never read by Oso.

    ``frozen=True, extra="forbid"`` mirrors production discipline.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    display_name: str


@router.post(
    "/organization_create",
    summary="Fixture handler: organization create (AP5 surface).",
    description=(
        "Exercises the chokepoint's create Organization authorization decision. "
        "Available only when SKALDOS_ENV != 'production'. "
        "Stands in for Slice 7's POST /organizations (which may not ship — "
        "organizations are provisioned via Auth0 SSO onboarding). "
        "Goes through Depends(authorize) — the real chokepoint. AP5. "
        "The Polar policy ships no allow rule for create Organization, so "
        "every role × kind combination denies (deny-by-default property)."
    ),
    responses=PROTECTED_ROUTE_RESPONSES,
)
async def organization_create(
    body: OrganizationCreateRequest,
    _subject: Annotated[
        Any,
        authorize(  # noqa: B008
            "create",
            AppSubject.ORGANIZATION,
            intent=Intent.assertive,
        ),
    ],
) -> dict[str, str]:
    """Organization create fixture handler.

    Reaches the body only on the allow path, which production policies
    deny for every principal — so this body is structurally unreachable
    in the gate scenario the handler exercises.  Echo the supplied
    ``display_name`` so a future allow-rule (e.g. a service-account
    onboarding bypass) lands on a coherent response shape.
    """
    return {"status": "created", "display_name": body.display_name}
