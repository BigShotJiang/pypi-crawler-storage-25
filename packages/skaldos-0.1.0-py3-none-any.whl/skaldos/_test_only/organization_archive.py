"""Fixture handler: ``POST /api/_test_only/organization_archive/{id}``.

AP5 idiom: this handler is a **fixture surface**, not an application bypass.
It goes through ``Depends(authorize)`` — the real chokepoint — and is
registered only when ``SKALDOS_ENV != 'production'``.  Absent from
production builds by construction (see ``__init__.py``
:func:`register_test_only_routes_if_enabled`).

## Purpose

Exercises the chokepoint's ``archive`` Organization decision.  Used by
the gate's "member-cannot-escalate" scenarios 3 and 4
(``test_member_cannot_archive_organization``,
``test_admin_cannot_archive_organization``):

- A ``member``-role principal in the org tries to archive → deny (only
  owner can archive per ``policies/organization.polar`` E24) → 403.
- An ``admin``-role principal also tries → deny (admin is not enough
  for archive; only owner) → 403.

The handler stands in for Slice 7's real
``POST /organizations/{id}/archive`` (per ``feature-catalog.md`` § A3).
The ``subject_loader`` (``load_organization_by_id``) reads the ``id``
path param via the chokepoint's ``request.path_params["id"]`` plumbing
in ``authorize.py``.

## Path

``POST /api/_test_only/organization_archive/{id}`` — the org's UUID is
the path parameter; no body is required.  Mirrors the path shape Slice
7's ``POST /organizations/{id}/archive`` will use.

## References

- §4.1   — every endpoint through ``can()``; this handler is no exception.
- §4.5   — subject-derived ownership; the org row supplies ``org.id``.
- §4.7   — owner-only archive (E24 in ``policies/organization.polar``).
- AP5    — ``Depends(authorize)`` is the chokepoint; no side-channel.
- ``policies/organization.polar`` — the rule under test.
- Slice 7 (the real ``POST /organizations/{id}/archive`` per
  ``feature-catalog.md`` § A3).
- ``docs/specs/2026-05-04-slice-2-followups.md`` followup #2.
"""

from __future__ import annotations

from typing import Annotated, Any

from fastapi import APIRouter

from skaldos.policy import PROTECTED_ROUTE_RESPONSES
from skaldos.policy.authorize import authorize
from skaldos.policy.intent import Intent
from skaldos.policy.loaders import load_organization_by_id
from skaldos.policy.subjects import AppSubject

router = APIRouter(prefix="/api/_test_only")


@router.post(
    "/organization_archive/{id}",
    summary="Fixture handler: organization archive (AP5 surface).",
    description=(
        "Exercises the chokepoint's archive Organization authorization decision. "
        "Available only when SKALDOS_ENV != 'production'. "
        "Stands in for Slice 7's POST /organizations/{id}/archive. "
        "Goes through Depends(authorize) — the real chokepoint. AP5."
    ),
    # The route uses ``subject_loader``; per the lint at
    # ``scripts/check_protected_route_responses.py`` the OpenAPI ``responses``
    # must include 404 (loader-returns-None → SubjectNotFoundError → 404).
    responses={
        **PROTECTED_ROUTE_RESPONSES,
        404: {"description": "Organization not found or not visible."},
    },
)
async def organization_archive(
    organization: Annotated[
        Any,
        authorize(  # noqa: B008
            "archive",
            AppSubject.ORGANIZATION,
            subject_loader=load_organization_by_id,
            intent=Intent.declarative,
        ),
    ],
) -> dict[str, str]:
    """Organization archive fixture handler.

    The chokepoint's ``subject_loader`` resolves the organization row by
    the ``id`` path parameter (read by ``authorize.py`` from
    ``request.path_params["id"]``); Polar evaluates ``allow(actor,
    "archive", org)`` against the resolved row.  Only owners are allowed;
    admin/member are denied.

    On allow: returns ``{"status": "archived", "id": "<uuid>"}``.
    On deny: chokepoint raises :class:`AuthorizationError` → 403.
    On loader-returns-None (RLS-hidden or non-existent org): chokepoint
    raises :class:`SubjectNotFoundError` → 404.
    """
    return {"status": "archived", "id": str(organization.id)}
