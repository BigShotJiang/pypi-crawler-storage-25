"""Fixture handler: ``POST /api/_test_only/memberships``.

AP5 idiom: this handler is a **fixture surface**, not an application bypass.
It goes through ``Depends(authorize)`` — the real chokepoint — and is
registered only when ``SKALDOS_ENV != 'production'``.  Absent from
production builds by construction (see ``__init__.py``
:func:`register_test_only_routes_if_enabled`).

## Purpose

Exercises the chokepoint's ``create`` Membership decision.  Used by the
gate's member-cannot-escalate scenarios (scenarios 1, 10) and agent-path
scenarios (11, 12):

- A ``member``-role principal in tenant A tries to create a membership
  in tenant A → ``can(principal, "create", Membership)`` returns
  ``False`` → 403.
- An ``admin``-role principal in tenant A creates a membership → 200.
- An ``agent`` principal with the equivalent roles follows the same path
  (MP10).

The handler stands in for Slice 7's real ``POST /memberships``.  The
``target_tenant_loader`` extracts the target tenant from the request body
(per master-plan ADR — the ``target_tenant_loader`` kwarg engine T7 added
for ``create`` actions where no existing subject row is involved).

## Request body

```json
{
    "principal_id": "<uuid>",
    "organization_id": "<uuid>",
    "role": "member"
}
```

``organization_id``: the tenant to create the membership in.  Extracted
by the ``target_tenant_loader``.

## References

- §4.1  — every endpoint through ``can()``; this handler is no exception.
- §4.5  — subject-derived ownership; the target tenant comes from the body.
- §4.7  — member read-only mode; member cannot create new memberships.
- AP5   — ``Depends(authorize)`` is the chokepoint; no side-channel.
- E5 (``02-edge-cases.md``) — member-cannot-escalate via create.
- Slice 7 (the real ``POST /memberships`` per ``feature-catalog.md`` § A2).
"""

from __future__ import annotations

from typing import Annotated, Any, cast
from uuid import UUID

from fastapi import APIRouter, Request
from pydantic import BaseModel, ConfigDict

from skaldos.policy import PROTECTED_ROUTE_RESPONSES
from skaldos.policy.authorize import authorize
from skaldos.policy.intent import Intent
from skaldos.policy.subjects import AppSubject, MembershipRow

router = APIRouter(prefix="/api/_test_only")


class MembershipCreateRequest(BaseModel):
    """Request body for the membership-create fixture handler.

    ``organization_id``: the tenant to create the membership in (the
    ``target_tenant_loader`` extracts this for the chokepoint).
    ``principal_id``: the principal to add.
    ``role``: the role to assign.

    ``frozen=True, extra="forbid"`` mirrors production discipline.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    principal_id: UUID
    organization_id: UUID
    role: str


async def _extract_org_id(request: Request) -> UUID:
    """Extract ``organization_id`` from the request body.

    Called by ``Depends(authorize(..., target_tenant_loader=...))`` during
    the chokepoint's Step 5 (target tenant extraction). Awaits
    ``request.body()`` — Starlette caches the bytes on the first read
    and replays them for the Pydantic body parameter.

    Same async pattern as
    :func:`~skaldos._test_only.cross_tenant_write._extract_target_org_id`
    (the earlier sync shape read ``request.scope["body"]`` which Starlette
    does not populate).
    """
    import json as _json  # noqa: PLC0415

    body_bytes = await request.body()
    if not body_bytes:
        raise ValueError(
            "request body is empty; the membership-create handler requires `organization_id` set."
        )
    parsed: Any = _json.loads(body_bytes)
    if not isinstance(parsed, dict):
        raise ValueError(
            "request body did not parse to a JSON object; "
            "the membership-create handler requires `organization_id` set."
        )
    body = cast("dict[str, Any]", parsed)
    raw: Any = body.get("organization_id")
    if raw is None:
        raise ValueError(
            "organization_id missing from request body; "
            "the membership-create handler requires this field."
        )
    return UUID(str(raw))


async def _synthetic_membership_subject(request: Request, tenant_id: UUID) -> MembershipRow:
    import json as _json  # noqa: PLC0415
    from datetime import UTC, datetime  # noqa: PLC0415

    body_bytes = await request.body()
    parsed: Any = _json.loads(body_bytes)
    if not isinstance(parsed, dict):
        raise ValueError("membership_create_body_invalid")
    body = cast("dict[str, Any]", parsed)
    return MembershipRow(
        id=UUID("00000000-0000-0000-0000-000000000000"),
        organization_id=tenant_id,
        principal_id=UUID(str(body["principal_id"])),
        role=str(body["role"]),
        max_clearance=None,
        created_at=datetime(1970, 1, 1, tzinfo=UTC),
        revoked_at=None,
    )


@router.post(
    "/memberships",
    summary="Fixture handler: membership create (AP5 surface).",
    description=(
        "Exercises the chokepoint's membership-create authorization decision. "
        "Available only when SKALDOS_ENV != 'production'. "
        "Stands in for Slice 7's POST /memberships. "
        "Goes through Depends(authorize) — the real chokepoint. AP5."
    ),
    responses=PROTECTED_ROUTE_RESPONSES,
)
async def membership_create(
    body: MembershipCreateRequest,
    _subject: Annotated[
        Any,
        authorize(  # noqa: B008
            "create",
            AppSubject.MEMBERSHIP,
            intent=Intent.assertive,
            target_tenant_loader=_extract_org_id,
            synthetic_subject_loader=_synthetic_membership_subject,
        ),
    ],
) -> dict[str, str]:
    """Membership create fixture handler.

    If the principal is authorized to create a Membership in the requested
    organization, returns ``{"status": "created"}``.

    If not, the chokepoint raises :class:`~skaldos.policy.errors.AuthorizationError`
    → 403 (member-cannot-escalate path).
    """
    return {"status": "created", "organization_id": str(body.organization_id)}
