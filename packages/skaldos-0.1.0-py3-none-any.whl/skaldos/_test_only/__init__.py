"""Fixture-only route handlers for the Slice 2 gate (AP5 surface).

This package contains **fixture handlers** — FastAPI routes used by the
Slice 2 gate tests to exercise the authorization chokepoint with stand-in
subjects that don't require Slice 3+ tables or production endpoints.

AP5 discipline
--------------

These handlers are a **fixture surface, not an application bypass**:

1. Every handler goes through ``Depends(authorize)`` — the real chokepoint.
   They are NOT bypasses of any kind.  AP5 (no bypass) is satisfied.
2. Registration is **structural** (at app-assembly time), not a runtime
   ``if testing:`` branch.  When ``SKALDOS_ENV == "production"``,
   :func:`register_test_only_routes_if_enabled` is a no-op and the routes
   never appear on the app — not in the OpenAPI schema, not in routing
   tables, not accessible.  A request to ``/api/_test_only/...`` in
   production returns the same 404 as any unknown path.
3. The lint script ``scripts/check_no_test_only_in_production.py`` asserts
   this property structurally (walks ``create_app()``'s routes with
   ``SKALDOS_ENV=production``; fails if any ``/api/_test_only/`` route
   is found).

Handlers
--------

- ``cross_tenant_write.py`` — ``POST /api/_test_only/cross_tenant_write``
  Exercises cross-tenant write rejection (gate scenarios 6-9).
  Stands in for Slice 4's ``POST /graph/assert``.

- ``membership_create.py`` — ``POST /api/_test_only/memberships``
  Exercises ``create`` Membership authorization (gate scenarios 1, 10-12).
  Stands in for Slice 7's ``POST /memberships``.

- ``membership_patch.py`` — ``PATCH /api/_test_only/memberships/{id}``
  Exercises ``update`` Membership authorization + field-level enforcement
  (gate scenarios 2, 13).
  Stands in for Slice 7's ``PATCH /memberships/{id}``.

- ``organization_archive.py`` — ``POST /api/_test_only/organization_archive/{id}``
  Exercises ``archive`` Organization authorization (gate scenarios 3, 4
  — owner-only archive).  Stands in for Slice 7's
  ``POST /organizations/{id}/archive``.  Added by Slice 2 followups #2.

- ``organization_create.py`` — ``POST /api/_test_only/organization_create``
  Exercises ``create`` Organization authorization (gate scenario 5
  — SSO-onboarding only; no allow rule ships).  Stands in for Slice 7's
  ``POST /organizations`` (if it ever ships).  Added by Slice 2 followups #2.

App-assembly hook
-----------------

Call :func:`register_test_only_routes_if_enabled` once in
``create_app()`` after :func:`~skaldos.api.whoami.register_whoami_if_enabled`.

References: AP5 (no bypass; registration-time gate); §4.1 (every endpoint
through ``can()``); master-plan § "Shared artifacts" ``_test_only/``
registration pattern row; ``authorization-verification/03-technical-implementation.md``
§ "Fixture handlers" + § "AP5 conditional registration".
"""

from __future__ import annotations

import os

from fastapi import FastAPI

from skaldos._test_only import (
    cross_tenant_write,
    membership_create,
    membership_patch,
    organization_archive,
    organization_create,
)

__all__ = [
    "is_test_only_enabled",
    "register_test_only_routes_if_enabled",
]


def is_test_only_enabled() -> bool:
    """Return whether the ``/api/_test_only/`` routes should be registered.

    Reads ``SKALDOS_ENV`` from the process environment.  Returns ``False``
    only when the value is exactly ``"production"``; every other value
    (including unset, which defaults to ``"development"``) returns ``True``.

    Per the AP5 idiom: the registration gate is at app-assembly time, not
    runtime.  Production builds structurally never expose these routes.

    The function is intentionally simple (one ``os.environ.get`` call,
    one comparison) so a unit test can pin the truth table without
    spinning a FastAPI app.
    """
    return os.environ.get("SKALDOS_ENV", "development") != "production"


def register_test_only_routes_if_enabled(app: FastAPI) -> None:
    """Register fixture handlers IFF ``SKALDOS_ENV != 'production'``.

    AP5 idiom: the registration gate is at app-assembly time, not runtime.
    Production builds NEVER expose these routes; their absence is structural.

    Call once in ``create_app()`` after
    :func:`~skaldos.api.whoami.register_whoami_if_enabled`::

        # In services/api/skaldos/app.py, create_app():
        register_whoami_if_enabled(app)
        register_test_only_routes_if_enabled(app)  # <-- add after whoami

    The three routers are included with the shared ``/api/_test_only``
    prefix (each handler module also declares the prefix on its router
    to make imports standalone).

    When ``SKALDOS_ENV == "production"``, this function is a no-op —
    the routes never appear on the app, in the OpenAPI schema, or in any
    routing table.  A request to ``/api/_test_only/...`` in production
    returns 404 (the same as any unknown path).

    Per ``authorization-verification/03 § AP5 conditional registration``;
    AP5; master-plan § "Shared artifacts" ``_test_only/`` row.
    """
    if not is_test_only_enabled():
        return
    app.include_router(cross_tenant_write.router)
    app.include_router(membership_create.router)
    app.include_router(membership_patch.router)
    app.include_router(organization_archive.router)
    app.include_router(organization_create.router)
