"""Fixture handler: ``POST /api/_test_only/cross_tenant_write``.

AP5 idiom: this handler is a **fixture surface**, not an application bypass.
It goes through ``Depends(authorize)`` — the real chokepoint — and is
registered only when ``SKALDOS_ENV != 'production'``.  Absent from
production builds by construction (see ``__init__.py``
:func:`register_test_only_routes_if_enabled`).

## Purpose

Exercises the chokepoint's cross-tenant rejection (scenarios 6-9 in
``docs/slices/slice-2-authorization/authorization-verification/03-technical-implementation.md``
§ "Gate scenario inventory"):

- Principal docked in tenant A requests a ``create`` on a Node whose
  ``target_organization_id`` points at tenant B.
- If the principal is NOT in tenant B, the chokepoint's subject-derived
  ownership check (or the ``role_in_org`` resolver) returns ``denied`` → 403.
- If RLS hides the referenced organization row, the loader returns ``None``
  → 404.

The handler stands in for Slice 4's ``POST /graph/assert`` (not yet wired).
It uses ``AppSubject.NODE`` with ``intent=Intent.assertive`` and a
``target_tenant_loader`` that extracts the target org from the request body.

## Request body

```json
{
    "target_organization_id": "<uuid>"
}
```

``target_organization_id``: the UUID of the tenant the caller wants to write
into.  The chokepoint's ``target_tenant_loader`` extracts this value.

## Chokepoint flow

1. ``current_principal`` resolves the principal (step 0; not a bypass).
2. ``authorize("create", NODE, intent=assertive, target_tenant_loader=...)``
   runs the pre-hooks, intent check, and Oso evaluation.
3. If ``can(principal, "create", NODE)`` returns ``False`` for the target
   tenant, ``AuthorizationError`` is raised → 403.
4. If the principal passes, the handler returns ``{"status": "ok"}``.

## References

- §3.1  — plural-tenant principal; the fixture exercises the N-tenant path.
- §4.1  — every endpoint through ``can()``; this handler is no exception.
- §4.5  — subject-derived ownership; the target tenant comes from the body.
- AP5   — ``Depends(authorize)`` is the chokepoint; no side-channel.
- E6 (``02-edge-cases.md``) — ``target_tenant_loader`` design surface.
- E27   — FK + chokepoint two-layer rejection.
- Slice 4 (``POST /graph/assert``) — the production endpoint this fixture
  stand-in exercises the chokepoint for.
"""

from __future__ import annotations

from typing import Annotated, Any, cast
from uuid import UUID

from fastapi import APIRouter, Request
from pydantic import BaseModel, ConfigDict

from skaldos.policy import PROTECTED_ROUTE_RESPONSES
from skaldos.policy.authorize import authorize
from skaldos.policy.intent import Intent
from skaldos.policy.subjects import AppSubject

router = APIRouter(prefix="/api/_test_only")


class CrossTenantWriteRequest(BaseModel):
    """Request body for the cross-tenant write fixture handler.

    ``target_organization_id``: the tenant the caller is requesting a write
    into.  The chokepoint's ``target_tenant_loader`` extracts this value
    from the parsed body.

    ``frozen=True, extra="forbid"`` mirrors the production handler discipline
    (AP5: no ambient state mutations via the request body).
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    target_organization_id: UUID


async def _extract_target_org_id(request: Request) -> UUID:
    """Extract ``target_organization_id`` from the request body.

    Called by ``Depends(authorize(..., target_tenant_loader=...))`` during
    the chokepoint's Step 5 (target tenant extraction). The chokepoint
    awaits the loader if it returns an awaitable, so we can read the
    body via ``await request.body()`` — Starlette caches the bytes on
    the first read and replays them for the Pydantic body parameter.

    Raises :class:`ValueError` if the body is not a JSON object, the
    expected key is absent, or the value is not a valid UUID.

    Earlier shape (PR #125) read ``request.scope["body"]`` and
    ``request.state.__dict__["_parsed_body"]`` — neither is populated by
    Starlette / FastAPI in the request path, so the loader silently
    raised ``ValueError`` for every real HTTP request and the chokepoint
    surfaced 500 instead of the intended 403/404. Verified by
    verification T3 (PR #135) and T7 (PR #136).
    """
    import json as _json  # noqa: PLC0415

    body_bytes = await request.body()
    if not body_bytes:
        raise ValueError(
            "request body is empty; the cross-tenant write handler requires "
            "a JSON body with `target_organization_id` set."
        )
    parsed: Any = _json.loads(body_bytes)
    if not isinstance(parsed, dict):
        raise ValueError(
            "request body did not parse to a JSON object; "
            "the cross-tenant write handler requires a JSON body with "
            "`target_organization_id` set."
        )
    body = cast("dict[str, Any]", parsed)
    raw: Any = body.get("target_organization_id")
    if raw is None:
        raise ValueError(
            "target_organization_id missing from request body; "
            "the cross-tenant write handler requires this field."
        )
    return UUID(str(raw))


@router.post(
    "/cross_tenant_write",
    summary="Fixture handler: cross-tenant write rejection (AP5 surface).",
    description=(
        "Exercises the chokepoint's cross-tenant write rejection. "
        "Available only when SKALDOS_ENV != 'production'. "
        "Stands in for Slice 4's POST /graph/assert. "
        "Goes through Depends(authorize) — the real chokepoint. AP5."
    ),
    responses=PROTECTED_ROUTE_RESPONSES,
)
async def cross_tenant_write(
    body: CrossTenantWriteRequest,
    _subject: Annotated[
        Any,
        authorize(  # noqa: B008
            "create",
            AppSubject.NODE,
            intent=Intent.assertive,
            target_tenant_loader=_extract_target_org_id,
        ),
    ],
) -> dict[str, str]:
    """Cross-tenant write fixture handler.

    If the principal is authorized to create a Node in the requested
    organization, returns ``{"status": "ok"}``.

    If not, the chokepoint raises :class:`~skaldos.policy.errors.AuthorizationError`
    → 403.  If RLS hides the referenced organization, the loader returns
    ``None`` → 404 (for routes with a subject_loader; this route uses
    ``target_tenant_loader`` instead, which does not return 404 but
    informs the Oso evaluation of the target tenant).
    """
    return {"status": "ok"}
