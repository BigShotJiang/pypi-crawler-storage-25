"""Pure-logic principal resolution (T2).

Per
``docs/slices/slice-1-tenant-chokepoint/principal-hydration-middleware/03-technical-implementation.md``
§ "Resolver logic", this module turns a freshly-validated JWT claim set
(:class:`~skaldos.auth.models.VerifiedClaims`) into a database-backed
:class:`ResolvedPrincipal` row. The function:

1. Looks up by ``auth0_sub`` (the common path --- repeat user).
2. If absent and ``kind == "human"``: tries the email-fallback ``UPDATE``
   (the §14.3 invite-then-login flow), then falls through to ``INSERT``.
3. If absent and ``kind == "agent"``: ``INSERT`` directly (no email
   fallback for M2M tokens; agents have no human email).
4. Catches :class:`asyncpg.UniqueViolationError` from the INSERT,
   re-selects by ``auth0_sub`` (E2/E3 race), and either returns the
   winner's row or raises :class:`~.errors.PrincipalIntegrityError` if
   the re-select also returns nothing.

The resolver is pure-logic in the sense that it owns no I/O state outside
the connection it is handed --- the caller (T6's ``current_principal``)
provides the ``conn`` already inside its own ``BEGIN`` transaction. The
resolver does not commit, does not roll back, does not open a sub-
transaction. T2 mocks the aiosql query module via the ``queries``
parameter; T3 ships the real ``services/api/skaldos/middleware/queries``
package, and T6 wires it as the default.

:class:`ResolvedPrincipal` vs ``Principal``
-------------------------------------------

Two semantically distinct shapes:

- :class:`ResolvedPrincipal` --- *DB row shape*. The columns of
  ``principals`` (id, kind, auth0_sub, email, primary_tenant_id,
  visible_tenant_ids, display_name, disabled_at). The resolver returns
  this; T6's chokepoint reads it.
- ``Principal`` (Slice 1 / T1) --- *request-state shape*. Wraps the
  :class:`ResolvedPrincipal` data PLUS the verified claims that produced
  it, plus the scaffold-now-wire-later slots ``delegation`` /
  ``trust_score`` / ``clearance``. T6 constructs it from
  ``ResolvedPrincipal + claims`` after setting GUCs.

Keeping them separate prevents the resolver from depending on T1's
``Principal`` model (which embeds ``VerifiedClaims`` --- orthogonal to
row hydration) and lets the resolver tests exercise just the row-shape
contract. The chokepoint composes the two.

Email-mismatch warning emission
-------------------------------

When ``lookup_by_auth0_sub`` returns a row whose ``email`` column differs
from ``claims.email``, the resolver emits a structured warning event
(``principal.email_mismatch``) carrying *only safelisted fields* --- the
correlation handle (``principal_id``) and the discriminator (``kind``)
plus a SHA-256 hash of ``auth0_sub`` (``auth0_sub_hash``). The hash is
included as a forward-compatible audit-correlation surface for Slice 5;
the §20.2 PII-redaction layer (Slice 0) replaces non-safelisted values
with ``<REDACTED:str>`` sentinels in production captured records, which
is exactly the desired behavior --- the value is *not* needed in logs,
the *presence of the event* is. **Email values are NEVER passed to the
logger**; the resolver does not bind them to log keyword arguments.

The "first-auth without email" warning (``principal.first_auth_no_email``)
fires for the human path when ``claims.email is None`` --- the resolver
proceeds to INSERT a fresh principal with ``email=None``, which is a
legal substrate state (``02-edge-cases.md`` E6) but worth surfacing
operationally so admins notice if an invite-then-login flow silently
bypasses the email-fallback path.

References: §3.1, §13.2, §14.3, §20.2, MP10, ML7, AP5,
``02-edge-cases.md`` E1/E2/E3/E4/E5/E6/E13/E16/E17,
``03-technical-implementation.md`` § "Resolver logic" / § "First-auth
branches" / § "Email-fallback".
"""

from __future__ import annotations

import hashlib
from datetime import datetime
from typing import TYPE_CHECKING, Literal, Protocol
from uuid import UUID

import asyncpg
import structlog
from pydantic import BaseModel, ConfigDict

from .errors import PrincipalEmailCollision, PrincipalIntegrityError, PrincipalKindUnknown

if TYPE_CHECKING:
    from skaldos.auth.models import VerifiedClaims

__all__ = [
    "PrincipalQueries",
    "ResolvedPrincipal",
    "format_uuid_array",
    "resolve_principal",
]


_log = structlog.get_logger(__name__)


# ---------------------------------------------------------------------------
# DB row shape.
# ---------------------------------------------------------------------------


class ResolvedPrincipal(BaseModel):
    """The ``principals`` row shape returned by the aiosql query module.

    Frozen so the resolver cannot mutate it before returning to T6 (which
    in turn constructs the request-state ``Principal`` from this row plus
    the verified claims). ``extra="forbid"`` makes adding a column to the
    schema without updating this model a loud test failure rather than a
    silent drop.

    Field set per the schema feature's contract (``master-plan.md``
    § "Shared artifacts & contracts" --- owned by
    ``tenant-and-membership-schema``): the columns of ``principals``
    after the schema feature's T4 lands (``email`` and ``disabled_at``
    are added there). T2 reads this shape via the mocked queries; T3
    wires the real aiosql deserialization.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    """Primary key. Used as the ``app.current_principal_id`` GUC value
    in T6's chokepoint."""

    kind: Literal["human", "agent"]
    """Discriminator. Mirrors :class:`~skaldos.auth.models.VerifiedClaims.kind`
    on the happy path; defense-in-depth tests exercise the
    :class:`~.errors.PrincipalKindUnknown` branch when the two
    disagree."""

    auth0_sub: str
    """Lookup key. Subject of the partial UNIQUE index
    ``principals_auth0_sub_idx`` (Slice 0 / migration #3). The resolver
    selects, updates, and inserts via this column."""

    email: str | None
    """Auth0 email when the ``email`` scope was granted; ``None`` for
    agents and for humans without the scope (``02-edge-cases.md`` E6).
    The schema feature (T4) owns the column shape; this field is
    informational from the resolver's perspective --- never logged."""

    primary_tenant_id: UUID | None
    """Nullable per §3.1 (``"nullable for principals not yet docked
    into a primary tenant"``). The schema feature's projection trigger
    maintains this from ``memberships`` writes; the resolver trusts the
    column (``03`` § "Trust the substrate primitive")."""

    visible_tenant_ids: tuple[UUID, ...]
    """Empty tuple = §3.1's "principal exists but has no tenant
    memberships yet" state. T6 formats this via :func:`format_uuid_array`
    into the ``app.current_principal_visible`` GUC value. Tuple (not
    list) for hashability + immutability so the row can flow into the
    frozen ``Principal`` model without coercion."""

    display_name: str | None
    """Free-form display string. Populated from ``claims.azp`` for
    agents at first-auth (per ``03``'s sketch); humans get whatever
    Auth0 sends in the ``name`` claim (or ``None`` when absent)."""

    disabled_at: datetime | None
    """When non-NULL, the chokepoint (T6) returns 403 before setting
    GUCs (``02-edge-cases.md`` E8). The resolver returns the row
    verbatim; the disabled-check is T6's responsibility, not T2's, so a
    disabled principal still flows through ``resolve_principal`` without
    raising --- separating "row exists" from "row is usable" is the §4.7
    "gate write at the action" framing applied to identity."""


# ---------------------------------------------------------------------------
# aiosql query module Protocol.
# ---------------------------------------------------------------------------


class PrincipalQueries(Protocol):
    """The four-method surface :func:`resolve_principal` calls into.

    T3 ships the production implementation backed by aiosql + the
    ``principals.sql`` query file. T2's tests inject
    :class:`unittest.mock.AsyncMock` instances satisfying this Protocol.
    The Protocol is structural --- pyright and runtime duck-typing both
    accept any object exposing these four async callables with the
    matching signatures.

    Why Protocol (not ABC): the production implementation is a Python
    module produced by aiosql's ``from_path`` / ``from_str`` loader; it
    is not a class instance, and forcing it to inherit from an ABC would
    require a wrapper. The Protocol shape lets the module-as-namespace
    flow through unchanged, while still giving pyright the typing
    surface the tests pin.

    Edge cases handled by the contract (not its implementations):

    - ``lookup_by_auth0_sub`` returning ``None`` → resolver proceeds to
      first-auth (per E2/E3).
    - ``fallback_by_email`` returning ``None`` → resolver falls through
      to INSERT (per E5).
    - ``insert_human`` / ``insert_agent`` raising
      :class:`asyncpg.UniqueViolationError` → resolver re-SELECTs to
      handle the concurrent-first-auth race (per E2/E3).

    The "what does this method return on the happy path" contract is
    pinned per-method below; tests exercise both the happy path and each
    documented error mode.
    """

    async def lookup_by_auth0_sub(
        self, conn: asyncpg.Connection, *, auth0_sub: str
    ) -> ResolvedPrincipal | None:
        """Return the principal row for ``auth0_sub`` or ``None`` if absent."""
        ...

    async def fallback_by_email(
        self, conn: asyncpg.Connection, *, email: str, auth0_sub: str
    ) -> ResolvedPrincipal | None:
        """Atomically attach ``auth0_sub`` to the row matching ``email``.

        SQL contract (T3 will ship this verbatim):
        ``UPDATE principals SET auth0_sub = :auth0_sub WHERE email = :email
        AND auth0_sub IS NULL RETURNING ...``. The
        ``WHERE auth0_sub IS NULL`` predicate prevents takeover of an
        active principal (E5).

        Returns the populated row on success, ``None`` if no row matched
        (either no row with ``email``, or the matching row already has a
        populated ``auth0_sub``).
        """
        ...

    async def insert_human(
        self,
        conn: asyncpg.Connection,
        *,
        auth0_sub: str,
        email: str | None,
        display_name: str | None,
    ) -> ResolvedPrincipal:
        """Insert a fresh ``kind='human'`` principal; return the new row.

        Raises :class:`asyncpg.UniqueViolationError` on partial-UNIQUE
        conflict on ``auth0_sub`` (E2 race), or on email-uniqueness
        conflict if the schema enforces it (E5).
        """
        ...

    async def insert_agent(
        self,
        conn: asyncpg.Connection,
        *,
        auth0_sub: str,
        display_name: str | None,
    ) -> ResolvedPrincipal:
        """Insert a fresh ``kind='agent'`` principal; return the new row.

        Raises :class:`asyncpg.UniqueViolationError` on partial-UNIQUE
        conflict on ``auth0_sub`` (E3 race).
        """
        ...


# ---------------------------------------------------------------------------
# Helpers.
# ---------------------------------------------------------------------------


def format_uuid_array(tenants: tuple[UUID, ...]) -> str:
    """Format a tuple of UUIDs as a Postgres array literal.

    Returns ``'{}'`` for an empty tuple, ``'{u1,u2,u3}'`` for non-empty.
    Mirrors the shape used in
    ``tests/integration/_framework/sessions.py``'s ``principal_session``
    fixture so the integration tests' setup path and the production
    chokepoint emit byte-identical GUC values.

    **Order is preserved** --- the formatter does NOT sort. Postgres
    array element order is observable in some downstream contexts (e.g.
    ``unnest``, array equality); the caller (T6's chokepoint) passes the
    canonical ordering produced by the schema feature's
    ``visible_tenant_ids`` projection trigger, and the formatter must
    not silently re-order under it. The unit test
    ``test_uuids_in_canonical_order_preserved`` pins this property.

    Empty array case is the §3.1 "principal exists but has no tenant
    memberships yet" state --- Postgres parses ``'{}'::uuid[]`` as a
    zero-element ``uuid[]``, and RLS predicates evaluating
    ``tenant_id = ANY(current_setting('app.current_principal_visible')::uuid[])``
    correctly return false for every row.

    The function does not validate that elements are UUIDs at runtime
    beyond the type annotation --- pyright (strict) catches misuse at
    typecheck time, and ``str(UUID(...))`` is total over UUID objects.
    """
    return "{" + ",".join(str(t) for t in tenants) + "}"


def _hash_auth0_sub(auth0_sub: str) -> str:
    """SHA-256 hex digest of ``auth0_sub`` for log correlation.

    The unsalted SHA-256 is the per-master-plan ADR resolution: log
    correlation across requests for the same principal without leaking
    the raw subject identifier. Slice 5's audit Merkle work may add a
    salt; this function's signature is the durable contract and that's
    a one-line change there.

    The §20.2 redaction layer (Slice 0) does NOT have ``auth0_sub_hash``
    on the safelist, so production captured records replace the value
    with ``<REDACTED:str>``. The presence of the field, not its value,
    is the operational signal --- tests assert the *event* fires; they
    do not assert the hash content.
    """
    return hashlib.sha256(auth0_sub.encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------
# Resolver.
# ---------------------------------------------------------------------------


async def resolve_principal(
    conn: asyncpg.Connection,
    claims: VerifiedClaims,
    queries: PrincipalQueries,
) -> ResolvedPrincipal:
    """Look up or first-auth-provision a principal for the given claims.

    Branches on ``claims.kind`` (MP10: same code path; only the
    discriminator differs). The function is pure-logic in the sense that
    it owns no I/O state outside the ``conn`` it is handed: the caller
    (T6's ``current_principal``) provides the connection already inside
    a ``BEGIN`` transaction; the resolver does not commit, does not roll
    back, does not open a sub-transaction. Errors are raised; the
    transaction-management contract is the caller's.

    The ``queries`` parameter is the seam T2's tests mock --- see
    :class:`PrincipalQueries`. T3's PR ships the production
    implementation and T6 wires it as the default; T2 leaves the
    parameter required so call sites that don't have T3 yet (the unit
    tests) cannot accidentally pick up a default that doesn't exist.

    Email-mismatch detection: when the ``lookup_by_auth0_sub`` row's
    ``email`` differs from ``claims.email`` (and both are non-None), the
    resolver emits a ``principal.email_mismatch`` warning event; the
    resolver does not update ``email`` (the schema feature owns the
    column lifecycle). See module docstring § "Email-mismatch warning
    emission".

    Raises:
        PrincipalEmailCollision: E5 --- fall-through INSERT failed with
            a unique-violation, re-SELECT returned nothing (the
            violating row exists under a different ``auth0_sub``,
            surfacing the email collision).
        PrincipalIntegrityError: E13 --- agent INSERT failed AND the
            re-SELECT also returned nothing under conditions that should
            be impossible (substrate-integrity bug).
        PrincipalKindUnknown: E7 --- ``claims.kind`` is neither
            ``"human"`` nor ``"agent"``. Defense-in-depth --- the auth
            feature's ``RawClaims`` validator should have rejected
            upstream.
    """
    # Step 1: Lookup by auth0_sub. The fast / common path.
    existing = await queries.lookup_by_auth0_sub(conn, auth0_sub=claims.auth0_sub)
    if existing is not None:
        # E4 --- observe email mutation; do NOT silently re-key. The
        # schema feature owns the email column's lifecycle.
        if (
            existing.kind == "human"
            and existing.email is not None
            and claims.email is not None
            and existing.email != claims.email
        ):
            _log.warning(
                "principal.email_mismatch",
                principal_id=str(existing.id),
                kind=existing.kind,
                auth0_sub_hash=_hash_auth0_sub(claims.auth0_sub),
            )
        return existing

    # Step 2: First-auth path. Same shape for humans and agents (MP10);
    # only the email-fallback step is human-specific.
    if claims.kind == "human":
        return await _first_auth_human(conn, claims, queries)
    if claims.kind == "agent":
        return await _first_auth_agent(conn, claims, queries)

    # Defense-in-depth --- the auth feature's `RawClaims` validator
    # rejects tokens whose discriminator is unrecognized; reaching this
    # branch means the validator has a bug. The contract is "fail
    # loudly, page the operator" per the `03` § "Error management"
    # alert annotation.
    raise PrincipalKindUnknown(
        f"Unrecognized principal kind: {claims.kind!r}; "
        "auth-feature validator should have rejected upstream."
    )


async def _first_auth_human(
    conn: asyncpg.Connection,
    claims: VerifiedClaims,
    queries: PrincipalQueries,
) -> ResolvedPrincipal:
    """Human first-auth: try email-fallback, then INSERT, handle E5/E13.

    Two sub-paths per §14.3 ("email-fallback resolution from day one"):

    1. ``claims.email`` is non-None → call ``fallback_by_email``. The
       atomic ``UPDATE ... WHERE auth0_sub IS NULL`` either populates an
       invited-but-unattached row and returns it (the happy invite-
       then-login path), or returns ``None`` (no invited row, or the
       matching row was already attached --- E5 territory). On hit,
       return immediately; the row is now keyed on ``auth0_sub``.
    2. ``claims.email`` is ``None``, OR fallback missed → INSERT a fresh
       row. The "no email" case emits an info-level
       ``principal.first_auth_no_email`` event so admins can notice
       when an invite-then-login flow silently bypassed the fallback
       (E6).

    The INSERT is wrapped in a ``SAVEPOINT chokepoint_resolver`` /
    ``ROLLBACK TO SAVEPOINT`` / ``RELEASE SAVEPOINT`` block per the
    Slice 2 SAVEPOINT discipline (``docs/slices/slice-2-authorization/
    policy-module-and-chokepoint/03-technical-implementation.md``
    § "F2" and master plan § "Shared artifacts"). The SAVEPOINT
    isolates the failed INSERT from the outer transaction so the
    re-SELECT runs in a healthy state.

    The exception path re-SELECTs by ``auth0_sub``:

    - Re-SELECT hits → another transaction won the race; return its row.
      Both requests succeed (one created, one observed).
    - Re-SELECT misses → the unique-violation came from a different
      column (most likely ``email`` per E5); raise
      :class:`PrincipalEmailCollision`. The brainstorm's ``03`` § "Error
      management" pins this mapping --- treating an unrecoverable
      INSERT-then-missing-row as collision rather than substrate-
      integrity is the conservative choice (false positives are visible
      to operators via the collision flow; false negatives would lose
      the alert).

    References: **Slice 1 followups #1**, PC1 (transaction semantics),
    ``03 § F2`` (SAVEPOINT name discipline), ``03 § F7`` (pending tests
    updated in the same PR as this change).
    """
    if claims.email is not None:
        attached = await queries.fallback_by_email(
            conn, email=claims.email, auth0_sub=claims.auth0_sub
        )
        if attached is not None:
            return attached

    if claims.email is None:
        # E6 --- first-auth without email. INSERT proceeds with
        # `email=None`; the substrate accepts the row but admins should
        # notice when invite-then-login silently bypassed the fallback
        # path.
        _log.info(
            "principal.first_auth_no_email",
            kind="human",
            auth0_sub_hash=_hash_auth0_sub(claims.auth0_sub),
        )

    # SAVEPOINT around the INSERT so that a UniqueViolationError does
    # not poison the outer transaction (Slice 2 / followups #1).
    # The SAVEPOINT name ``chokepoint_resolver`` is the canonical name
    # per the master plan's "Shared artifacts" row — namespaced
    # ``<feature>_<purpose>`` for forward compatibility with Slice 4's
    # staged-write SAVEPOINTs.
    #
    # Engine T4's chokepoint pool acquires a connection but does NOT
    # open an explicit transaction (per
    # ``services/api/skaldos/middleware/hydration.py`` § Phase A); each
    # statement auto-commits. SAVEPOINT requires an active transaction
    # block, so we open ``async with conn.transaction()`` here. The
    # outer transaction commits on the happy path or on a successful
    # UV recovery; only an unrecoverable error (the
    # :class:`PrincipalEmailCollision` re-raise below) rolls it back.
    async with conn.transaction():  # pyright: ignore[reportUnknownMemberType]
        await conn.execute("SAVEPOINT chokepoint_resolver")  # pyright: ignore[reportUnknownMemberType]
        try:
            result = await queries.insert_human(
                conn,
                auth0_sub=claims.auth0_sub,
                email=claims.email,
                display_name=_human_display_name(claims),
            )
            await conn.execute("RELEASE SAVEPOINT chokepoint_resolver")  # pyright: ignore[reportUnknownMemberType]
            return result
        except asyncpg.UniqueViolationError:
            # E2 race or E5 collision. Roll back to the SAVEPOINT to restore
            # a healthy transaction state, then release it before the
            # re-SELECT. Postgres requires an explicit RELEASE after
            # ROLLBACK TO; without it the SAVEPOINT persists as a no-op
            # but occupies a name slot.
            await conn.execute("ROLLBACK TO SAVEPOINT chokepoint_resolver")  # pyright: ignore[reportUnknownMemberType]
            await conn.execute("RELEASE SAVEPOINT chokepoint_resolver")  # pyright: ignore[reportUnknownMemberType]
            # Re-SELECT by auth0_sub: a hit means someone else won the
            # auth0_sub UPDATE/INSERT; a miss means the violation was on a
            # different column (email per E5).
            raced = await queries.lookup_by_auth0_sub(conn, auth0_sub=claims.auth0_sub)
            if raced is not None:
                return raced
            raise PrincipalEmailCollision(
                "Email-fallback INSERT failed with a unique-violation and "
                "the re-SELECT by auth0_sub returned nothing --- likely an "
                "email collision with an active principal."
            ) from None


async def _first_auth_agent(
    conn: asyncpg.Connection,
    claims: VerifiedClaims,
    queries: PrincipalQueries,
) -> ResolvedPrincipal:
    """Agent first-auth: INSERT, handle E3 race.

    Agents have no email-fallback path (M2M Client Credentials carries
    no human email, per ``master-plan.md`` § "Shared artifacts &
    contracts" → ``VerifiedClaims.email is None`` always for agents).
    INSERT runs directly; the partial UNIQUE on ``auth0_sub`` serializes
    concurrent first-auth attempts (E3). On unique-violation, re-SELECT
    by ``auth0_sub`` is guaranteed to return the winner's row --- agents
    have no email-uniqueness collision path, so a missing re-SELECT
    after a UV is substrate-integrity territory (E13).

    As with the human path, the INSERT is wrapped in a
    ``SAVEPOINT chokepoint_resolver`` so the UV does not poison the
    outer transaction (Slice 2 / followups #1; same SAVEPOINT name
    convention per master plan § "Shared artifacts").
    """
    # SAVEPOINT around the INSERT --- same discipline as _first_auth_human.
    # See that function's docstring for the canonical references and
    # the rationale for opening ``conn.transaction()`` here (engine T4's
    # chokepoint phase does not run inside an outer transaction).
    async with conn.transaction():  # pyright: ignore[reportUnknownMemberType]
        await conn.execute("SAVEPOINT chokepoint_resolver")  # pyright: ignore[reportUnknownMemberType]
        try:
            result = await queries.insert_agent(
                conn,
                auth0_sub=claims.auth0_sub,
                display_name=claims.azp,
            )
            await conn.execute("RELEASE SAVEPOINT chokepoint_resolver")  # pyright: ignore[reportUnknownMemberType]
            return result
        except asyncpg.UniqueViolationError:
            await conn.execute("ROLLBACK TO SAVEPOINT chokepoint_resolver")  # pyright: ignore[reportUnknownMemberType]
            await conn.execute("RELEASE SAVEPOINT chokepoint_resolver")  # pyright: ignore[reportUnknownMemberType]
            raced = await queries.lookup_by_auth0_sub(conn, auth0_sub=claims.auth0_sub)
            if raced is not None:
                return raced
            # No email-collision path for agents; missing re-SELECT after
            # auth0_sub UV is a substrate-integrity bug.
            raise PrincipalIntegrityError(
                "Agent INSERT failed with a unique-violation and the "
                "re-SELECT by auth0_sub returned nothing --- substrate-"
                "integrity bug; investigate the partial UNIQUE on "
                "principals.auth0_sub."
            ) from None


def _human_display_name(claims: VerifiedClaims) -> str | None:
    """Best-effort human display name from the claims.

    The auth feature's :class:`~skaldos.auth.models.VerifiedClaims`
    surface does not expose a ``name`` field directly --- it lives in
    ``raw_claims`` (per ``03`` § "Resolver logic" the brainstorm sketch
    reads ``claims.name``, but that's a brainstorm-time abbreviation;
    the actual model carries the verbatim payload in ``raw_claims``).
    The resolver reads ``raw_claims["name"]`` defensively (the claim is
    optional in OIDC and may be absent; Auth0 emits it when the
    ``profile`` scope is granted). Missing or non-string values surface
    as ``None`` rather than a ``KeyError`` --- invalid display-name
    shapes are not a reason to fail authentication.

    The dict access is the documented exception to the "no
    ``raw_claims['...']`` outside ``services/api/skaldos/auth/``"
    convention from auth's ``models.py`` docstring; the resolver
    intentionally keeps the access narrow (one key, one fallback) so
    the future Slice 2/3 lint can grep-allowlist this exact line.
    """
    raw_name = claims.raw_claims.get("name")
    if isinstance(raw_name, str):
        return raw_name
    return None
