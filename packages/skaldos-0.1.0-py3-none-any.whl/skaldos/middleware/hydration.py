"""The ``current_principal`` FastAPI dependency --- the PC1 chokepoint (T6 + T4).

Per
``docs/slices/slice-1-tenant-chokepoint/principal-hydration-middleware/03-technical-implementation.md``
§ "The ``current_principal`` dependency" + ``05-task-list.md`` § T6: this
module is the **load-bearing chokepoint** of Slice 1. Every JWT-protected
route in Slice 2+ runs through it; PC1's ``set_config(name, value, true)``
contract is what makes RLS policies see the right principal context.

Engine T4 (Slice 2) update
--------------------------

The dependency now uses **two pools**:

1. **Chokepoint pool** (``app_chokepoint``, BYPASSRLS) --- acquired for the
   resolver step that looks up ``principals`` *before* the PC1 GUC contract
   is committed.  Read from ``request.app.state.chokepoint_pool`` (set by
   ``app.py``'s lifespan at startup).  Released immediately after the
   resolver returns (before the GUC is set).

2. **Runtime pool** (``app_runtime``, RLS-bound) --- acquired for the
   GUC-bearing transaction that the handler uses.  Read from
   ``request.app.state.runtime_pool``.  Stored in ``request.state.connection``
   after the GUC is committed so handler-side queries see the principal
   context.

This split resolves **Slice 1 followups #3** (the production-deploy
blocker): under the old single-pool design the resolver ran as
``app_runtime`` before the GUC was set, causing RLS to fail closed on
``principals`` (which has ``FORCE ROW LEVEL SECURITY``) and every
returning user to receive a 500.  The ``app_chokepoint`` role's
``BYPASSRLS`` attribute sidesteps this.

What this module owns
---------------------

- :func:`current_principal` --- the async-generator FastAPI dependency
  that:

  1. Acquires a connection from the **chokepoint pool**
     (``request.app.state.chokepoint_pool``) with a per-acquire timeout
     (:func:`~skaldos.db.get_acquire_timeout`); runs the resolver; releases
     it before the GUC is committed.
  1b. Acquires a connection from the **runtime pool**
      (``request.app.state.runtime_pool``) for the GUC-bearing transaction.
  2. Opens an explicit ``async with conn.transaction():`` (the PC1
     contract requires the explicit BEGIN ... COMMIT block; ``set_config(...,
     true)`` GUCs are transaction-local and die at the boundary).
  3. Sets :data:`STATEMENT_TIMEOUT_MS` via ``SET LOCAL statement_timeout``
     so a slow principal-resolution query fails fast (E19 → 503).
  4. Calls :func:`~skaldos.middleware.resolver.resolve_principal` which
     performs lookup-by-``auth0_sub`` → email-fallback → first-auth INSERT.
  5. If the resolved row has ``disabled_at IS NOT NULL`` (E8 / S8),
     raises :class:`~skaldos.middleware.errors.PrincipalDisabledError`
     **before** committing the GUC --- the rolled-back transaction
     leaves no observable principal context for downstream queries.
  6. Commits the PC1 GUC contract: two ``SELECT set_config(name, value,
     true)`` calls --- one for ``app.current_principal_id``, one for
     ``app.current_principal_visible``. Direct ``SET LOCAL`` SQL is
     forbidden (PC1 eliminates GUC-name injection); the names are
     constants in this module.
  7. Stashes the connection in ``request.state.connection`` so
     :func:`~skaldos.db.get_connection` can serve it to handler-level
     aiosql queries (E1 / S1 spike property: one connection per request,
     one transaction wrapping every query).
  8. Yields a frozen :class:`~skaldos.middleware.Principal` to the
     dependent (the route handler / next dependency in the chain).
  9. On normal handler return: the ``async with conn.transaction():``
     block commits; the GUC contract is released by Postgres at COMMIT.
     On any exception path (handler raises, body validation fails after
     hydration, client disconnect, rate limiter exception): the
     transaction rolls back; the GUC contract is released by ROLLBACK.
     Either way the connection is returned to the pool via the ``finally``
     block.

- :data:`GUC_PRINCIPAL_ID` / :data:`GUC_PRINCIPAL_VISIBLE` --- the two
  pinned GUC names. They are constants here; the only string parameter
  ``set_config`` ever receives is one of these two literals (PC1 strict
  adherence). The same names are read by the schema feature's helpers
  (``app.principal_id() = current_setting('app.current_principal_id', true)``)
  and by RLS policies on every multi-tenant table.

- :data:`STATEMENT_TIMEOUT_MS` --- the per-transaction statement
  timeout in milliseconds. 5000ms by the brainstorm § Fault lines:
  aggressive enough that a hung principal lookup doesn't tie up a
  connection; loose enough that legitimate slow paths succeed.

The S1 spike property
---------------------

Slice 0's S1 spike verified that ``set_config('app.test_principal',
'abc', true)`` inside an explicit transaction is durable across
statements when the connection is held through PgBouncer transaction-
mode pooling (port 5431). T6 re-verifies that property continuously
through the integration test
``test_hydration_set_config_via_pgbouncer_tx.py`` --- a regression
there blocks merge per the brainstorm § Fault lines ("Do not ship if
the regression test is flaky"). The "spike-as-living-test" pattern is
how Slice 1 keeps a binary verdict from silently regressing.

Disabled-principal early return (E8 / S8)
-----------------------------------------

When the resolver returns a row with ``disabled_at IS NOT NULL``, the
chokepoint raises :class:`PrincipalDisabledError` **before** the two
``set_config`` calls. This is structurally important:

- The transaction rolls back because the exception escapes the
  ``async with conn.transaction():`` block.
- Because ``set_config(..., true)`` is *transaction-local*, no GUC was
  ever observable on this backend. The disabled principal's row is
  never exposed to RLS-bound downstream queries (an alternative design
  would set the GUC then check, but that exposes the row briefly and
  invites accidental data reads).
- The error maps to **HTTP 403** (per §4.7's "gate write at the action"
  framing applied to identity: 401 says "your token is bad"; 403 says
  "your identity is recognized but the action is refused"). The
  client-facing JSON body carries ``code="principal_disabled"`` per the
  pinned :class:`PrincipalDisabledError.code` constant.

Detection: the resolver returns a :class:`ResolvedPrincipal` with the
row's ``disabled_at`` field populated verbatim from the DB --- the row
shape includes the column whether it's NULL or not. The chokepoint
inspects ``resolved.disabled_at is not None``.

Detection of fresh provisioning (S16 stub)
------------------------------------------

The ``principal.provisioned`` log event is emitted on first-auth (when
the resolver creates a new row). Detection: the resolver's branch
behavior is "lookup → if None, first-auth path inserts → return new
row". From the chokepoint's perspective, the row's ``id`` was unknown
before this request and known after; the cleanest signal is
"``lookup_by_auth0_sub`` returned None on the first call". But the
chokepoint can't observe the resolver's internal branch without
re-doing the lookup or the resolver returning a flag. **Decision:**
the chokepoint does its own pre-check by calling
:meth:`PrincipalQueries.lookup_by_auth0_sub` first, observing the
None vs row outcome, then handing through to
:func:`resolve_principal`. The pre-check adds one query on the
first-auth path (a miss); the common path (returning user) pays the
same query that ``resolve_principal`` would have run anyway, so the
common path is unchanged.

This is the cleaner of the two alternatives the kickoff prompt named
("flag on ResolvedPrincipal" vs "compare ``created_at`` ≈ ``now()``"):

- The flag would couple the resolver's internal branch decision to the
  chokepoint's log shape; T2's resolver would need a new field on
  ``ResolvedPrincipal`` whose only consumer is this log line.
- ``created_at ≈ now()`` is brittle (what's the threshold? wall-clock
  comparison is forbidden in tests per §19.1; the resolver itself
  doesn't have this signal anyway).

The pre-check is one extra DB roundtrip on first-auth; the common
path (returning user) is not affected because the resolver's lookup
is the same call.

Pool exhaustion → 503 (E9 / S13)
--------------------------------

The pool acquire is wrapped in a ``try`` for :class:`TimeoutError`
(asyncpg raises the built-in :class:`TimeoutError` from
:meth:`asyncpg.Pool.acquire`'s internal :func:`asyncio.wait_for`).
On timeout: the :class:`PoolExhausted` chained from
:class:`TimeoutError`, mapped to **HTTP 503** with
``Retry-After: 5``. The structured-log event uses
:attr:`PoolExhausted.event_name` (``principal.pool_acquire_timeout``)
so dashboards distinguish pool exhaustion from upstream DB outage.

Lookup timeout → 503 (E19)
--------------------------

``SET LOCAL statement_timeout`` fires when a single statement exceeds
:data:`STATEMENT_TIMEOUT_MS`. asyncpg surfaces this as
:class:`asyncpg.PostgresError` (specifically
:class:`asyncpg.exceptions.QueryCanceledError`); we map it to
:class:`PrincipalLookupTimeout` → **HTTP 503**.

GUC-set failure → 500 (E10)
---------------------------

Hypothetical: the GUC names are constants, so a failure here is a
substrate-integrity alarm. We catch :class:`asyncpg.PostgresError`
around the two ``SELECT set_config(...)`` calls and map to
:class:`GUCSetFailed` → **HTTP 500**.

Why an async generator
----------------------

FastAPI runs the ``finally`` block of an async generator on every exit
path: success, exception, cancellation. The dependency therefore acts
as a per-request resource manager:

- ``yield principal`` is the handler-runs window.
- After ``yield`` returns: the ``async with conn.transaction():``
  context manager commits (success path) or has already rolled back
  (exception path).
- The ``finally`` block always runs ``pool.release(conn)`` so the
  connection returns to the pool even under client-disconnect
  (asyncio.CancelledError) or unexpected handler exceptions.

References: PC1 (the only legal GUC injection form is ``set_config(name,
value, true)`` --- direct ``SET LOCAL`` SQL forbidden cluster-wide);
§3.5 (RLS day-one; SET LOCAL durability validated by S1); §3.2 (RLS is
the tenant boundary); §4.7 (member read-only is per-action; disabled
rejection is identity-level); §13.2 (audit log shape); §14.7 (pool-as-
budget; tiered rate limiting); §18.3 (PgBouncer-tx pool architecture);
§20.1 / §20.2 / §20.4 (structured logs, PII safelist, fail-fast on
no-span); ML2 (per-request service instantiation); MP10 (humans + agents
equal Principals); AP5 (no debug bypass); ``02-edge-cases.md`` E1
(single connection per request), E8 (disabled), E9 (pool exhaustion),
E10 (set_config failure), E11 (handler exception), E12 (client
disconnect), E13 (uniqueness violation), E14 (empty visible_tenants),
E15 (NULL primary_tenant), E16 (returning user with deleted row), E19
(lookup timeout), E22 (body validation 422); ``03-technical-implementation.md``
§ "Happy path" / § "Error management" / § Fault lines;
``04-testing-strategy.md`` § "tests/integration/auth/test_hydration_*.py".
"""

from collections.abc import AsyncGenerator, Mapping
from json import dumps as json_dumps
from typing import Annotated, Any, Literal, cast
from uuid import UUID

import asyncpg
from fastapi import Depends, HTTPException, Request, status
from skaldos_log import log

from skaldos.auth import VerifiedClaims, verify_token
from skaldos.db import get_acquire_timeout

from .errors import (
    GUCSetFailed,
    PoolExhausted,
    PrincipalDisabledError,
    PrincipalIntegrityError,
    PrincipalLookupTimeout,
)
from .principal import Principal
from .queries import get_principal_queries
from .resolver import PrincipalQueries, ResolvedPrincipal, format_uuid_array, resolve_principal

__all__ = [
    "GUC_PRINCIPAL_ID",
    "GUC_PRINCIPAL_CONTEXT",
    "GUC_PRINCIPAL_VISIBLE",
    "STATEMENT_TIMEOUT_MS",
    "current_principal",
]


# ---------------------------------------------------------------------------
# Pinned GUC names + per-transaction timeouts.
#
# PC1: the *only* legal GUC injection is ``SELECT set_config(name, value,
# true)`` with ``name`` bound as a *value* parameter (not a SQL fragment).
# These constants are the only strings that ever flow into ``set_config``'s
# first argument. The schema feature reads them via the helpers
# ``app.principal_id() = current_setting('app.current_principal_id', true)``
# and ``app.principal_visible() = current_setting('app.current_principal_visible',
# true)::uuid[]`` --- the names must match verbatim or RLS fails closed.
# ---------------------------------------------------------------------------

GUC_PRINCIPAL_ID = "app.current_principal_id"
"""GUC name for the resolved principal's UUID. Read by RLS policies via
``app.principal_id()``. PC1: name is a value parameter to
``set_config``, never a SQL fragment."""

GUC_PRINCIPAL_VISIBLE = "app.current_principal_visible"
"""GUC name for the resolved principal's visible-tenant array. Read by
RLS policies via ``app.principal_visible()``. PC1: name is a value
parameter to ``set_config``, never a SQL fragment."""

GUC_PRINCIPAL_CONTEXT = "app.current_principal_context"
"""GUC name for Slice 3 graph context containment. Written only by this
chokepoint alongside the Slice 1 principal GUCs so graph RLS does not
depend on a test-only side channel."""

STATEMENT_TIMEOUT_MS = 5000
"""Per-transaction statement timeout (milliseconds). Set via ``SET LOCAL
statement_timeout`` immediately after the transaction begins; fires for
a single statement that exceeds the bound (E19 → :class:`PrincipalLookupTimeout`
→ HTTP 503). The brainstorm § Fault lines pins 5000ms as the trade-off
between cutting hung lookups and tolerating cold-cache slow paths;
trigger-to-revisit is documented there."""

# ---------------------------------------------------------------------------
# Per-failure HTTP-translation helpers.
#
# Each helper returns the :class:`HTTPException` shape T6 raises for one
# documented error. Centralising them keeps the body of
# :func:`current_principal` focused on the happy path; tests assert
# against the same constants the dependency emits.
# ---------------------------------------------------------------------------

_RETRY_AFTER_SECONDS = "5"
"""``Retry-After`` value for 503 responses (pool exhaustion + lookup
timeout). Mirrors the auth dependency's
``_RETRY_AFTER_SECONDS`` constant in ``services/api/skaldos/auth/fastapi.py``;
duplicated here rather than imported because the value is part of the
public 503 contract for *this* chokepoint, not a cross-module config."""


def _http_503_pool_exhausted() -> HTTPException:
    """Build the 503 response for pool acquire timeout (E9)."""
    return HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail={
            "code": PoolExhausted.code,
            "message": "Pool exhausted; retry shortly.",
        },
        headers={"Retry-After": _RETRY_AFTER_SECONDS},
    )


def _http_503_lookup_timeout() -> HTTPException:
    """Build the 503 response for principal-lookup statement_timeout (E19)."""
    return HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail={
            "code": PrincipalLookupTimeout.code,
            "message": "Principal lookup timed out; retry shortly.",
        },
        headers={"Retry-After": _RETRY_AFTER_SECONDS},
    )


def _http_403_principal_disabled() -> HTTPException:
    """Build the 403 response for a disabled principal (E8 / S8)."""
    return HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail={
            "code": PrincipalDisabledError.code,
            "message": "Principal is disabled; access refused.",
        },
    )


def _http_500_guc_set_failed() -> HTTPException:
    """Build the 500 response for a ``set_config`` failure (E10)."""
    return HTTPException(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        detail={
            "code": GUCSetFailed.code,
            "message": "GUC commit failed; substrate integrity alarm.",
        },
    )


def _http_500_principal_integrity() -> HTTPException:
    """Build the 500 response for a uniqueness-violation (E13)."""
    return HTTPException(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        detail={
            "code": PrincipalIntegrityError.code,
            "message": "Principal uniqueness invariant violated; substrate integrity alarm.",
        },
    )


# ---------------------------------------------------------------------------
# The chokepoint dependency.
# ---------------------------------------------------------------------------


async def current_principal(
    request: Request,
    claims: Annotated[VerifiedClaims, Depends(verify_token)],
    queries: Annotated[PrincipalQueries, Depends(get_principal_queries)],
) -> AsyncGenerator[Principal]:
    """Hydrate the request-scope :class:`Principal` and commit the PC1 GUC contract.

    The async-generator FastAPI dependency every JWT-protected route
    declares (directly or transitively). FastAPI calls ``next()`` on
    the generator to obtain the principal for the route handler; on
    handler return (success or exception), FastAPI calls ``next()``
    again to advance the generator past the ``yield`` and run the
    teardown clauses. The transaction context manager (``async with
    conn.transaction():``) handles commit/rollback automatically; the
    ``finally`` block returns the connection to the pool unconditionally.

    The dependency is the **load-bearing chokepoint** of Slice 1 ---
    every multi-tenant query in any handler reads its principal context
    from the GUCs this dependency commits. PC1 (``set_config(name,
    value, true)``) is the substrate-wide GUC injection form; the
    transaction-local nature of the GUCs (``true`` third argument)
    means they survive PgBouncer transaction-mode pooling for the
    duration of the transaction (S1 spike outcome) and die at COMMIT
    or ROLLBACK so a future request on the same backend sees a clean
    slate.

    Args:
        request: The FastAPI :class:`~fastapi.Request` whose ``state``
            this dependency mutates (sets ``state.connection``).
        claims: The verified Auth0 JWT claims, produced by the auth
            chokepoint's :func:`~skaldos.auth.verify_token` dependency.
            Trust boundary: ML3 says JWT verification is the trust
            boundary; downstream services trust the resolved tenant
            context. This dependency reads the verified claims as
            input.
        queries: The :class:`PrincipalQueries` implementation used to
            resolve the principal. Injected by FastAPI via
            :func:`~skaldos.middleware.queries.get_principal_queries`
            (the production :data:`~skaldos.middleware.queries.principals_queries`
            singleton). Tests inject a stub via
            ``app.dependency_overrides[get_principal_queries] = lambda: stub``.

    Yields:
        The frozen :class:`Principal` for the duration of the request.

    Raises:
        :class:`fastapi.HTTPException`: with the right status code +
            error code per the documented table:

            - **403 ``principal_disabled``** --- the resolved row's
              ``disabled_at`` is non-NULL (E8 / S8); the GUC is NOT
              committed; the transaction rolls back.
            - **503 ``pool_exhausted``** + ``Retry-After: 5`` --- the
              pool acquire timed out (E9 / S13).
            - **503 ``lookup_timeout``** + ``Retry-After: 5`` --- the
              principal-lookup statement exceeded
              :data:`STATEMENT_TIMEOUT_MS` (E19).
            - **500 ``guc_set_failed``** --- ``set_config`` raised
              (E10; substrate-integrity alarm).
            - **500 ``principal_integrity``** --- the resolver raised
              :class:`PrincipalIntegrityError` (E13; substrate-
              integrity alarm).

        :class:`PrincipalEmailCollision`: from the resolver's E5 path
            (humans only; first-auth INSERT collided on email after
            the fallback predicate ruled out an active row). T9 will
            wire the OpenAPI 409 mapping; T6 lets the exception
            propagate to FastAPI's default exception handler today
            (the 409 mapping is owned by T9 / Slice 1's runbook
            feature, not T6).

    See also:
        - :func:`~skaldos.db.get_connection` --- the request-scoped
          accessor handlers use to read the connection this dependency
          stashes.
        - :func:`~skaldos.middleware.resolver.resolve_principal` ---
          the pure-logic resolver this dependency calls.
        - :data:`~skaldos.middleware.PUBLIC_ROUTES` --- the test-time
          allowlist of routes that legitimately do *not* declare this
          dependency.
    """
    # Engine T4 (Slice 2): read both pools from app.state.
    # The chokepoint pool (app_chokepoint, BYPASSRLS) is used for the
    # resolver step that runs BEFORE the GUC is committed.
    # The runtime pool (app_runtime, RLS-bound) is used for the
    # GUC-bearing transaction that the handler queries use.
    chokepoint_pool: asyncpg.Pool = request.app.state.chokepoint_pool  # pyright: ignore[reportAny]
    runtime_pool: asyncpg.Pool = request.app.state.runtime_pool  # pyright: ignore[reportAny]
    timeout = get_acquire_timeout()

    auth0_sub_hash = _hash_auth0_sub(claims.auth0_sub)

    # ---------------------------------------------------------------------------
    # Phase A: Principal resolution via the CHOKEPOINT POOL.
    #
    # The chokepoint pool's ``app_chokepoint`` role has BYPASSRLS, so the
    # lookup succeeds even when the GUC is unset (which it always is at
    # this point in the request lifecycle). The connection is released
    # immediately after the resolver returns — before the runtime
    # transaction opens.
    # ---------------------------------------------------------------------------

    # 1. Acquire from the chokepoint pool (pool exhaustion → 503).
    try:
        cp_conn = await chokepoint_pool.acquire(timeout=timeout)  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
    except TimeoutError as e:
        log.warning(PoolExhausted.event_name, auth0_sub_hash=auth0_sub_hash)
        raise _http_503_pool_exhausted() from e

    try:
        # 2. Pre-check + resolve, all on the chokepoint connection.
        #    The chokepoint connection does NOT open an explicit transaction
        #    here — the resolver only needs the BYPASSRLS lookup, not a
        #    durable transaction boundary. Statement timeout is not set on
        #    the chokepoint conn because the timeout below covers the full
        #    resolution phase; the runtime conn sets its own LOCAL timeout.
        try:
            pre_existing = await queries.lookup_by_auth0_sub(
                cp_conn,  # pyright: ignore[reportArgumentType] -- asyncpg.Pool.acquire returns PoolConnectionProxy which is duck-typed against asyncpg.Connection but not nominally a subclass; same convention as `tests/integration/middleware/test_pool_connection_pattern.py`.
                auth0_sub=claims.auth0_sub,
            )
        except asyncpg.QueryCanceledError as e:
            # E19 --- statement_timeout fired during the pre-check.
            log.warning(
                PrincipalLookupTimeout.event_name,
                auth0_sub_hash=auth0_sub_hash,
            )
            raise _http_503_lookup_timeout() from e

        try:
            resolved = await resolve_principal(
                cp_conn,  # pyright: ignore[reportArgumentType] -- see above for the asyncpg.Connection vs PoolConnectionProxy convention.
                claims,
                queries=queries,
            )
        except asyncpg.QueryCanceledError as e:
            log.warning(
                PrincipalLookupTimeout.event_name,
                auth0_sub_hash=auth0_sub_hash,
            )
            raise _http_503_lookup_timeout() from e
        except PrincipalIntegrityError as e:
            log.error(
                PrincipalIntegrityError.event_name,
                auth0_sub_hash=auth0_sub_hash,
            )
            raise _http_500_principal_integrity() from e

    finally:
        # 3. Always release the chokepoint connection, even on exception.
        #    The chokepoint connection's only job was the resolver; it must
        #    not be held into the handler phase (F6: the two pools must
        #    stay distinct).
        await chokepoint_pool.release(cp_conn)  # pyright: ignore[reportUnknownMemberType]

    # ---------------------------------------------------------------------------
    # Phase B: GUC commit + handler transaction via the RUNTIME POOL.
    #
    # The resolver returned ``resolved``; now open the runtime transaction,
    # set the PC1 GUCs, stash the connection, and yield the Principal.
    # The runtime conn is held until after the handler returns.
    # ---------------------------------------------------------------------------

    was_freshly_provisioned = pre_existing is None
    if was_freshly_provisioned:
        # S16 stub: the durable contract Slice 4's outbox
        # dispatcher reads to materialise as
        # ``principal.provisioned`` outbox rows. The log line is
        # the seam; Slice 4's PR adds the ``INSERT INTO
        # outbox_event ...`` line and removes the stub.
        log.info(
            "principal.provisioned",
            principal_id=str(resolved.id),
            kind=resolved.kind,
            auth0_sub_hash=auth0_sub_hash,
        )

    # 5. Disabled-principal check (E8 / S8). MUST run BEFORE
    #    the GUC-commit step --- the rolled-back transaction
    #    leaves no observable principal context downstream.
    if resolved.disabled_at is not None:
        log.warning(
            PrincipalDisabledError.event_name,
            principal_id=str(resolved.id),
            kind=resolved.kind,
            auth0_sub_hash=auth0_sub_hash,
        )
        raise _http_403_principal_disabled()

    # 4. Acquire from the runtime pool (pool exhaustion → 503).
    try:
        rt_conn = await runtime_pool.acquire(timeout=timeout)  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
    except TimeoutError as e:
        log.warning(PoolExhausted.event_name, auth0_sub_hash=auth0_sub_hash)
        raise _http_503_pool_exhausted() from e

    # 5. From here on, ``rt_conn`` is held; we MUST release it. The
    #    outer ``try``/``finally`` is the structural backstop. The
    #    inner ``async with rt_conn.transaction():`` handles commit /
    #    rollback automatically.
    try:
        async with rt_conn.transaction():  # pyright: ignore[reportUnknownMemberType]
            # 6. Statement timeout (E19). Set LOCAL so the value dies at
            #    COMMIT / ROLLBACK alongside the PC1 GUCs. Aggressive
            #    enough that a hung principal lookup doesn't tie up a
            #    connection; loose enough that legitimate slow paths
            #    (cold cache) succeed.
            await rt_conn.execute(  # pyright: ignore[reportUnknownMemberType]
                f"SET LOCAL statement_timeout = '{STATEMENT_TIMEOUT_MS}ms';"
            )

            # 7. THE LOAD-BEARING PC1 CONTRACT. Two ``SELECT
            #    set_config(name, value, true)`` calls --- one per GUC.
            #    The third argument ``true`` makes the GUC transaction-
            #    local (released by Postgres at COMMIT / ROLLBACK).
            #    Direct ``SET LOCAL`` SQL is forbidden cluster-wide
            #    (PC1 eliminates GUC-name injection by construction;
            #    the names are bound as VALUE parameters here).
            try:
                await rt_conn.execute(  # pyright: ignore[reportUnknownMemberType]
                    "SELECT set_config($1, $2, true)",
                    GUC_PRINCIPAL_ID,
                    str(resolved.id),
                )
                await rt_conn.execute(  # pyright: ignore[reportUnknownMemberType]
                    "SELECT set_config($1, $2, true)",
                    GUC_PRINCIPAL_VISIBLE,
                    format_uuid_array(resolved.visible_tenant_ids),
                )
            except asyncpg.PostgresError as e:
                log.error(GUCSetFailed.event_name, auth0_sub_hash=auth0_sub_hash)
                raise _http_500_guc_set_failed() from e

            # 8b. Pre-resolve the principal's active role assignments
            #     (Slice 2 followups #1).  One query against ``memberships``
            #     using the post-GUC runtime conn; rows are visible iff
            #     ``tenant_id = ANY(current_principal_visible)`` per the
            #     RLS policy on ``memberships``.  The resulting tuple
            #     becomes ``Principal.role_assignments`` so Polar's
            #     ``has_role_in_org`` predicate can decide via
            #     pure-Python attribute lookup — no async resolver
            #     reaching back through the request task's event loop
            #     during synchronous Oso evaluation.
            #
            #     Snapshot consistency: the role set is fixed at request
            #     start.  A row that lands in ``memberships`` mid-request
            #     does NOT flip the request's permission decisions; that
            #     is the desired semantic for an authorization chokepoint
            #     (a request that started as a member doesn't suddenly
            #     become an admin halfway through).
            role_rows = await rt_conn.fetch(  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
                "SELECT tenant_id, role::text AS role, max_clearance::text AS max_clearance "
                "FROM memberships "
                "WHERE principal_id = $1 AND revoked_at IS NULL "
                "ORDER BY tenant_id, granted_at DESC",
                resolved.id,
            )
            role_assignments: tuple[tuple[UUID, str], ...] = tuple(
                (UUID(str(row["tenant_id"])), str(row["role"]))  # pyright: ignore[reportUnknownArgumentType]
                for row in role_rows  # pyright: ignore[reportUnknownVariableType]
            )
            clearance_assignments: tuple[tuple[UUID, ClassificationValue], ...] = tuple(
                (
                    UUID(str(row["tenant_id"])),  # pyright: ignore[reportUnknownArgumentType]
                    _validate_classification_value(str(row["max_clearance"])),  # pyright: ignore[reportUnknownArgumentType]
                )
                for row in role_rows  # pyright: ignore[reportUnknownVariableType]
            )
            ontology_rows = await rt_conn.fetch(  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
                """
                SELECT ov.id
                FROM ontology_version ov
                JOIN ontology o ON o.id = ov.ontology_id
                WHERE o.tenant_id IS NULL
                   OR o.tenant_id = ANY($1::uuid[])
                ORDER BY o.tenant_id NULLS FIRST, ov.version_number DESC, ov.id
                """,
                list(resolved.visible_tenant_ids),
            )
            ontology_version_ids: tuple[UUID, ...] = tuple(
                UUID(str(cast(object, cast(Mapping[str, Any], row)["id"])))
                for row in ontology_rows  # pyright: ignore[reportUnknownVariableType]
                if "id" in row
            )

            try:
                await rt_conn.execute(  # pyright: ignore[reportUnknownMemberType]
                    "SELECT set_config($1, $2, true)",
                    GUC_PRINCIPAL_CONTEXT,
                    _graph_principal_context_json(
                        resolved,
                        clearance_assignments=clearance_assignments,
                        ontology_version_ids=ontology_version_ids,
                    ),
                )
            except asyncpg.PostgresError as e:
                log.error(GUCSetFailed.event_name, auth0_sub_hash=auth0_sub_hash)
                raise _http_500_guc_set_failed() from e

            # 8. Stash the RUNTIME connection in request scope. ONLY after
            #    all GUC commits succeed --- if a downstream
            #    :func:`get_connection` somehow read the connection earlier, it
            #    would see an incomplete principal context.
            request.state.connection = rt_conn

            # 9. Build the request-state ``Principal`` and yield to the
            #    handler. The model is frozen + extra-forbidden; any
            #    later mutation attempt raises :class:`pydantic.
            #    ValidationError` --- the AP5 structural defense.
            principal = _build_principal(
                resolved=resolved,
                claims=claims,
                role_assignments=role_assignments,
                clearance_assignments=clearance_assignments,
            )

            log.info(
                "principal.hydrated",
                principal_id=str(principal.id),
                kind=principal.kind,
                route_path=request.url.path,
                http_method=request.method,
                auth0_sub_hash=auth0_sub_hash,
            )

            # The yield boundary. After this point: the handler runs;
            # the transaction context manager waits at ``__aexit__`` for
            # the handler's outcome (success → commit; exception →
            # rollback).
            yield principal

            # 10. Reaching here means the handler returned cleanly. The
            #    ``async with rt_conn.transaction():`` block exits next,
            #    issuing COMMIT and releasing the PC1 GUCs alongside
            #    the LOCAL ``statement_timeout``.
    finally:
        # 11. Always release the runtime connection. ``pool.release`` is
        #     idempotent against double-release (asyncpg raises
        #     :class:`asyncpg.InterfaceError` if called twice; the
        #     ``try``/``finally`` shape prevents the double).
        await runtime_pool.release(rt_conn)  # pyright: ignore[reportUnknownMemberType]


# ---------------------------------------------------------------------------
# Pure helpers extracted so unit tests can exercise them without spinning
# the full FastAPI dependency. ``_build_principal`` is the
# :class:`ResolvedPrincipal` → :class:`Principal` projection;
# ``_hash_auth0_sub`` is the structured-log correlation helper.
# ---------------------------------------------------------------------------


def _build_principal(
    *,
    resolved: ResolvedPrincipal,
    claims: VerifiedClaims,
    role_assignments: tuple[tuple[UUID, str], ...] = (),
    clearance_assignments: tuple[tuple[UUID, "ClassificationValue"], ...] = (),
) -> Principal:
    """Project resolver row + claims into a frozen :class:`Principal`.

    Combines the :class:`ResolvedPrincipal` row with the upstream
    :class:`VerifiedClaims` and the principal's active memberships
    (``role_assignments``) to produce the request-state model.

    ``role_assignments`` (Slice 2 followups #1) is the
    ``tuple[tuple[UUID, str], ...]`` of active ``(tenant_id, role)``
    pairs the principal holds at request start.  Polar's
    ``has_role_in_org`` predicate is a pure-Python attribute lookup
    against this tuple, so the chokepoint's authorization decision
    needs no async resolver during synchronous Oso evaluation.  See
    the field docstring on :class:`Principal` for the rationale.

    ``disabled_at`` is hard-pinned to ``None`` because a disabled
    principal would have 403'd before reaching this helper (the
    chokepoint's E8 early return runs before the GUC commit and the
    yield). The :class:`Principal` model itself enforces the invariant
    via ``Literal[None]`` typing of the field; passing a ``datetime``
    here would raise :class:`pydantic.ValidationError`. The helper
    simply does not pass the resolver's ``disabled_at`` through.

    The scaffold-now-wire-later slots (``delegation`` / ``trust_score``
    / ``clearance``) default to ``None`` per the model's Pydantic
    defaults; their owning slices (Slice 7+ / Slice 5+ / Slice 6+
    respectively) flip the defaults when the wiring lands. Passing a
    value here would be a forward-compatibility break.
    """
    return Principal(
        id=resolved.id,
        kind=resolved.kind,
        auth0_sub=resolved.auth0_sub,
        primary_tenant_id=resolved.primary_tenant_id,
        visible_tenant_ids=resolved.visible_tenant_ids,
        role_assignments=role_assignments,
        clearance_assignments=clearance_assignments,
        display_name=resolved.display_name,
        verified_claims=claims,
        clearance=_safe_minimum_clearance(clearance_assignments),
        # disabled_at: not passed; the model defaults to None and rejects
        # any other value via the Literal[None] typing.
        # delegation / trust_score: scaffold-now-wire-later slots; default
        # None until their owning slices wire them.
    )


ClassificationValue = Literal["C0", "C1", "C2", "C3", "C4"]
_CLASSIFICATION_RANKS: dict[ClassificationValue, int] = {
    "C0": 0,
    "C1": 1,
    "C2": 2,
    "C3": 3,
    "C4": 4,
}


def _validate_classification_value(value: str) -> ClassificationValue:
    if value not in _CLASSIFICATION_RANKS:
        raise ValueError(f"invalid classification value: {value!r}")
    return value  # pyright: ignore[reportReturnType]


def _safe_minimum_clearance(
    clearance_assignments: tuple[tuple[UUID, ClassificationValue], ...],
) -> ClassificationValue:
    if not clearance_assignments:
        return "C0"
    return min(
        (clearance for _tenant_id, clearance in clearance_assignments),
        key=_CLASSIFICATION_RANKS.__getitem__,
    )


def _graph_principal_context_json(
    resolved: ResolvedPrincipal,
    *,
    clearance_assignments: tuple[tuple[UUID, ClassificationValue], ...] = (),
    ontology_version_ids: tuple[UUID, ...] = (),
) -> str:
    """Build the Slice 3 graph RLS context from the hydrated principal.

    Slice 3 only has tenant visibility in the chokepoint contract today.
    Classification, vertical, and ontology-version facets therefore fail
    closed until their owning slices hydrate concrete values.  Tenant
    membership alone is not enough to read graph rows.
    """
    return json_dumps(
        {
            "tenants": [str(tenant_id) for tenant_id in resolved.visible_tenant_ids],
            "classification": _safe_minimum_clearance(clearance_assignments),
            "clearances": {
                str(tenant_id): clearance for tenant_id, clearance in clearance_assignments
            },
            "verticals": ["foundation"],
            "ontology_versions": [str(version_id) for version_id in ontology_version_ids],
        },
        separators=(",", ":"),
    )


def _hash_auth0_sub(auth0_sub: str) -> str:
    """SHA-256 hex digest of ``auth0_sub`` for log correlation.

    Mirrors the resolver's ``_hash_auth0_sub`` helper (T2 in
    :mod:`skaldos.middleware.resolver`); duplicated here rather than
    imported because the resolver's copy is private (leading underscore)
    and pyright reports cross-module private access. The value is
    structurally PII-free per the master plan's
    "ADR resolution: log correlation across requests for the same
    principal without leaking the raw subject identifier"; Slice 5's
    audit Merkle work may add a salt, which is a one-line change in
    both places.

    The §20.2 redaction layer's safelist does NOT include
    ``auth0_sub_hash``, so production captured records replace the
    value with ``<REDACTED:str>``. The presence of the field, not its
    value, is the operational signal --- tests assert the *event* fires;
    they do not assert the hash content.
    """
    import hashlib

    return hashlib.sha256(auth0_sub.encode("utf-8")).hexdigest()
