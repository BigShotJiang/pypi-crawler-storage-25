-- aiosql query module for principal-hydration-middleware T3.
--
-- Per
-- ``docs/slices/slice-1-tenant-chokepoint/principal-hydration-middleware/03-technical-implementation.md``
-- § "Resolver SQL" + ``05-task-list.md`` § T3.
--
-- The queries below are the chokepoint's own identity-resolution surface ---
-- the only multi-tenant-table reads that legitimately bypass the bound-by-
-- tenant predicate (R1) because ``principals`` is *global identity* per §3.1,
-- not multi-tenant. Each query carries the ``-- principal_global: <reason>``
-- marker the §14.9 / R6 lint requires
-- (``scripts/check_tenant_filter.py``).
--
-- ## Schema delta (2026-05-01 --- code wins per CLAUDE.md M8)
--
-- The brainstorm's SQL block (`03-technical-implementation.md` § "Resolver
-- SQL") and the resolver's ``ResolvedPrincipal`` model both reference an
-- ``email`` column. **The principals schema as of migration
-- ``20260506_principals_fk_and_rls.py`` has no ``email`` column.** The
-- schema feature (``tenant-and-membership-schema``) shipped ``disabled_at``
-- but did not land ``email``.
--
-- Per CLAUDE.md M8 (code wins; specs are dated snapshots), this file ships
-- the three queries that match the actual schema: ``lookup_by_auth0_sub``,
-- ``insert_human``, ``insert_agent``. The fourth query --- ``fallback_by_email``
-- --- is implemented in the Python wrapper (``__init__.py``) as a no-op
-- stub that always returns ``None`` until a future schema migration lands
-- the ``email`` column, at which point the SQL form moves into this file
-- alongside the others. The integration test
-- ``test_fallback_by_email_returns_none_until_schema_adds_email`` pins the
-- stub-shape so the future schema landing surfaces a coupled change-
-- requirement (failing test → forced rewrite).
--
-- The resolver's ``_first_auth_human`` semantics still hold: when
-- ``fallback_by_email`` returns ``None`` (its only behaviour today), the
-- resolver falls through to ``insert_human``, which is the brainstorm's
-- "no invited row matched" branch.
--
-- ## Column shape returned by every query
--
-- ``id, kind, auth0_sub, primary_tenant_id, visible_tenant_ids,
-- display_name, disabled_at`` --- the subset of the migration's columns the
-- :class:`~skaldos.middleware.resolver.ResolvedPrincipal` model declares.
-- ``created_at`` and ``updated_at`` exist in the schema (Slice 0 migration
-- 20260502) but the resolver model uses ``extra="forbid"`` so reading those
-- columns into a row dict that flows through ``model_validate`` raises. The
-- queries narrow the SELECT / RETURNING list to exactly the model's field
-- set; if a future change extends the model, this list extends in lockstep.
-- The Python wrapper projects ``email=None`` onto each row (the schema
-- delta documented above) before constructing
-- :class:`~skaldos.middleware.resolver.ResolvedPrincipal`.
--
-- ## RLS posture
--
-- ``principals`` carries FORCE RLS (migration ``20260506`` policies
-- ``principals_self_row`` + ``principals_visible_via_membership``). Reading
-- principals via a connection authored as ``app_runtime`` *before* the
-- chokepoint sets the GUC returns zero rows --- the policy fails closed
-- when ``app.principal_id()`` is NULL. The chokepoint (T6) calls these
-- queries *before* setting the GUC, so the production runtime path
-- requires the chokepoint to either run identity resolution on a BYPASSRLS
-- connection (a separate ``app_chokepoint`` role; not yet shipped) or set
-- the GUC speculatively against the row's own ``id``. This is a T6 /
-- future-slice concern, not T3's; the queries here are the *SQL contract*.
-- T3's integration tests connect as the bootstrap superuser (BYPASSRLS) so
-- the SQL exercise is independent of the policy exercise (which is owned
-- by the schema feature's tests).
--
-- References: §3.1 (plural-tenant principal; principals are global
-- identity), §14.3 (email-fallback resolution --- documented stub until
-- schema adds the column), §14.12 (Pydantic at every result boundary),
-- MP10 (humans + agents equal Principals), ML5 (R6 escape-hatch marker),
-- AP5 (no debug bypass); ``02-edge-cases.md`` E2/E3/E5/E6/E16; CLAUDE.md
-- M8 (code wins).


-- principal_global: chokepoint identity lookup; bound by auth0_sub partial-UNIQUE index
-- name: lookup_by_auth0_sub^
SELECT id,
       kind,
       auth0_sub,
       primary_tenant_id,
       visible_tenant_ids,
       display_name,
       disabled_at
  FROM principals
 WHERE auth0_sub = :auth0_sub
 LIMIT 1;


-- principal_global: first-auth row creation for human; subsequent reads gate on tenancy via the policy
-- name: insert_human^
INSERT INTO principals (kind, auth0_sub, display_name)
VALUES ('human', :auth0_sub, :display_name)
RETURNING id,
          kind,
          auth0_sub,
          primary_tenant_id,
          visible_tenant_ids,
          display_name,
          disabled_at;


-- principal_global: first-auth row creation for agent; same pattern as human, kind='agent'
-- name: insert_agent^
INSERT INTO principals (kind, auth0_sub, display_name)
VALUES ('agent', :auth0_sub, :display_name)
RETURNING id,
          kind,
          auth0_sub,
          primary_tenant_id,
          visible_tenant_ids,
          display_name,
          disabled_at;
