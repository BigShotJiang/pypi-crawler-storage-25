"""aiosql query module + Pydantic-typed wrapper for the principal chokepoint.

Slice 1, ``principal-hydration-middleware`` T3. Per
``docs/slices/slice-1-tenant-chokepoint/principal-hydration-middleware/03-technical-implementation.md``
§ "Resolver SQL" + ``05-task-list.md`` § T3.

This module is the Python boundary between aiosql's raw row results and the
resolver's :class:`~skaldos.middleware.resolver.PrincipalQueries` Protocol.
The Protocol expects each query to return either a typed
:class:`~skaldos.middleware.resolver.ResolvedPrincipal` or ``None``; aiosql
returns asyncpg :class:`~asyncpg.Record` (or ``None`` for ``^`` queries with
no match). The :class:`Principals` class wraps the four Protocol methods and
performs the result-side projection per **§14.12** ("Pydantic at every result
boundary"; ADR 3 / ADR 22 forbid ORM models, so the projection is hand-rolled).

## Module surface

- :class:`Principals` --- a class instance satisfying
  :class:`~skaldos.middleware.resolver.PrincipalQueries`. The default instance
  ``principals_queries`` is wired against the SQL file in this directory; tests
  may construct a fresh :class:`Principals` against an alternate ``.sql`` file
  if they ever need a per-test schema variation.
- :data:`principals_queries` --- the default :class:`Principals` instance,
  imported by T6's chokepoint as the production ``queries`` argument to
  :func:`~skaldos.middleware.resolver.resolve_principal`.

## Schema delta (2026-05-01 --- code wins per CLAUDE.md M8)

The brainstorm called for an ``email`` column on ``principals``; the schema
feature shipped ``disabled_at`` but not ``email`` (see migrations
``20260502_principals.py`` + ``20260506_principals_fk_and_rls.py``). Per
CLAUDE.md M8 ("code wins; specs are dated snapshots"), the SQL file does *not*
read or write ``email``; the wrapper projects ``email=None`` onto every row
before constructing :class:`ResolvedPrincipal`. The
:meth:`Principals.fallback_by_email` method is a documented stub that returns
``None`` unconditionally; the resolver's ``_first_auth_human`` then falls
through to ``insert_human`` (the same control-flow branch the brainstorm
labels "no invited row matched"). When a future migration lands the email
column, ``fallback_by_email``'s SQL form moves into ``principals.sql``
alongside the other three queries and the wrapper method delegates to aiosql.
The integration test
``test_fallback_by_email_returns_none_until_schema_adds_email`` pins the
documented stub-shape so a future schema migration that lands the column also
forces the query rewrite.

## aiosql adapter shape

``aiosql.from_path(path, "asyncpg")`` returns an
:class:`aiosql.queries.Queries` whose ``^`` (one-or-none) queries return
either an :class:`asyncpg.Record` or ``None``. ``Record`` is mapping-like
(``record["id"]`` / ``dict(record)``); we feed a dict-projection through
:meth:`ResolvedPrincipal.model_validate` so Pydantic owns the typing surface
(``UUID`` parsing, ``Literal["human","agent"]`` enforcement, ``tuple`` coercion
for ``visible_tenant_ids``).

The asyncpg adapter ships with aiosql's distribution (``aiosql.adapters.asyncpg``);
calling ``aiosql.from_path(..., "asyncpg")`` resolves the adapter name
through aiosql's plugin registry. The adapter returns ``Record`` objects for
``^`` queries.

## Why a class instance, not a module

The :class:`PrincipalQueries` Protocol declares each method as ``async``; an
aiosql-loaded :class:`Queries` is *not* itself a class instance and exposes
queries as bound methods on its own ``self``. Wrapping the four queries in a
class lets the wrapper:

1. Project asyncpg's ``Record`` to :class:`ResolvedPrincipal` at the result
   boundary (§14.12).
2. Inject ``email=None`` for the schema-pending column without leaking the
   schema delta into the resolver's signature.
3. Discard the resolver's ``email`` keyword arg in :meth:`insert_human` (the
   resolver passes it; the SQL doesn't need it; the wrapper drops it silently
   per the schema delta).
4. Stub :meth:`fallback_by_email` as a no-op until the schema lands the
   column.

References: §3.1 (plural-tenant principal; principals are global identity),
§14.3 (email-fallback resolution stub), §14.12 (Pydantic at every result
boundary; ADR 3 / ADR 22 forbid ORM), MP10, ML5 (R6 marker), AP5; CLAUDE.md
M8 (code wins).
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

import aiosql

from skaldos.middleware.resolver import ResolvedPrincipal

if TYPE_CHECKING:
    import asyncpg

__all__ = [
    "Principals",
    "get_principal_queries",
    "principals_queries",
    "record_to_resolved_principal",
]


# ---------------------------------------------------------------------------
# aiosql loader.
#
# ``aiosql.from_path(path, driver_adapter)`` returns a :class:`Queries`
# object whose attributes match the ``-- name:`` declarations in the SQL
# file. The asyncpg adapter ships in aiosql's distribution; resolving the
# adapter by name keeps the import surface flat (no manual
# ``register_adapter`` call needed). The resulting object is a singleton at
# import time; we don't expose it directly --- callers go through
# :class:`Principals` so the result-boundary projection is mandatory.
# ---------------------------------------------------------------------------
_QUERIES_SQL_PATH: Path = Path(__file__).parent / "principals.sql"


def _load_queries() -> Any:  # noqa: ANN401 - aiosql.queries.Queries dynamic-attribute surface is typed Any-shaped
    """Load ``principals.sql`` via aiosql with the asyncpg adapter.

    Wrapped in a function (not a module-level constant) so a test can
    construct an alternate :class:`Principals` against a different SQL file
    without re-importing this module. Production callers go through
    :data:`principals_queries`, the default-loader instance built once at
    import time.

    Returns ``Any`` (rather than the nominal ``aiosql.queries.Queries``)
    because aiosql's :class:`Queries` exposes the loaded queries as
    *dynamic attributes* matching the SQL file's ``-- name:`` declarations
    --- pyright cannot statically know the names exist on the returned
    instance. Treating the loader return as ``Any`` keeps the wrapper's
    bound methods (which call ``self._queries.<name>(...)``) clean while
    the wrapping methods themselves carry full type signatures the
    resolver imports.
    """
    return aiosql.from_path(_QUERIES_SQL_PATH, "asyncpg")  # pyright: ignore[reportUnknownMemberType]


def record_to_resolved_principal(record: Any) -> ResolvedPrincipal:  # noqa: ANN401 - asyncpg.Record's stubs are partial
    """Project an asyncpg :class:`Record` into a :class:`ResolvedPrincipal`.

    The schema lacks an ``email`` column (2026-05-01 delta); we fill
    ``email=None`` so :class:`ResolvedPrincipal`'s
    ``model_config = ConfigDict(extra="forbid")`` accepts the dict without
    a missing-field error. ``visible_tenant_ids`` arrives as a list from
    asyncpg; Pydantic coerces to ``tuple[UUID, ...]`` automatically because
    the field annotation is ``tuple[UUID, ...]`` and Pydantic's tuple
    validator accepts iterables.

    The wrapper does not catch :class:`pydantic.ValidationError`; a schema
    drift between the SQL columns and the model fields surfaces as a loud
    validation error at the chokepoint, which is the desired behaviour
    (caught by the integration test, not silently swallowed at runtime).
    """
    payload: dict[str, object] = dict(record)
    # Schema-pending: ``email`` is not on the principals table. The wrapper
    # projects it into the row dict so :class:`ResolvedPrincipal` accepts
    # the row without an ``extra=forbid`` complaint. When the future schema
    # migration adds the column, this line goes away (the column flows
    # naturally through ``dict(record)``).
    payload["email"] = None
    return ResolvedPrincipal.model_validate(payload)


# ---------------------------------------------------------------------------
# The :class:`Principals` wrapper.
#
# Implements :class:`~skaldos.middleware.resolver.PrincipalQueries`
# structurally --- the methods match the Protocol's signatures, and pyright
# treats the duck-type as satisfying the resolver's ``queries`` parameter.
# ---------------------------------------------------------------------------


class Principals:
    """aiosql-backed implementation of :class:`PrincipalQueries`.

    Wraps a loaded aiosql :class:`Queries` and projects each row through
    :func:`record_to_resolved_principal` so the resolver consumes
    typed :class:`ResolvedPrincipal` instances rather than raw asyncpg
    :class:`Record` objects.

    Construction:

    - The default constructor loads ``principals.sql`` from the directory
      this module lives in (the production path).
    - Tests that need an alternate SQL file may pass ``queries=`` directly;
      the parameter is the loaded aiosql object, not a path, so the test
      controls how the file is loaded (e.g. with a different adapter or a
      hand-rolled fixture). T3's tests use the default constructor against
      the production SQL file --- the integration test framework's testcontainer
      runs the same migrations production runs.

    Each method's docstring documents the contract relative to the
    Protocol:

    - :meth:`lookup_by_auth0_sub` --- aiosql ``^`` returns ``None`` for no
      match; the wrapper projects the matched row when present.
    - :meth:`fallback_by_email` --- schema-pending stub; returns ``None``
      unconditionally until the future migration lands ``email``.
    - :meth:`insert_human` / :meth:`insert_agent` --- aiosql ``^`` on a
      ``RETURNING`` clause returns the inserted row; the wrapper projects
      it.

    The class is lightweight (one ``Queries`` field); constructing a new
    instance per request would defeat the load-once advantage of aiosql.
    Production code uses :data:`principals_queries` (the module-level
    default instance); tests may instantiate freshly if they need a clean
    object identity for reset semantics.
    """

    def __init__(self, queries: Any | None = None) -> None:  # noqa: ANN401
        """Build the wrapper around an aiosql-loaded query object.

        ``queries`` defaults to the production loader (``aiosql.from_path``
        on the colocated ``principals.sql``); tests may pass a custom-loaded
        object. The constructor does not validate the query names because
        aiosql raises at attribute-access time if a name is missing, which
        is the loud-failure surface we want.
        """
        self._queries = queries if queries is not None else _load_queries()

    async def lookup_by_auth0_sub(
        self, conn: asyncpg.Connection, *, auth0_sub: str
    ) -> ResolvedPrincipal | None:
        """Return the principal row for ``auth0_sub`` or ``None`` if absent.

        Delegates to the aiosql ``^`` query; converts the matched
        :class:`Record` to a :class:`ResolvedPrincipal`. Returns ``None``
        verbatim from aiosql when the ``WHERE auth0_sub = :auth0_sub``
        predicate matches nothing.
        """
        record = await self._queries.lookup_by_auth0_sub(conn, auth0_sub=auth0_sub)
        if record is None:
            return None
        return record_to_resolved_principal(record)

    async def fallback_by_email(
        self,
        conn: asyncpg.Connection,  # noqa: ARG002 - signature pinned by Protocol
        *,
        email: str,  # noqa: ARG002 - signature pinned by Protocol
        auth0_sub: str,  # noqa: ARG002 - signature pinned by Protocol
    ) -> ResolvedPrincipal | None:
        """Schema-pending stub --- returns ``None`` until ``email`` lands.

        The brainstorm's SQL was an atomic ``UPDATE principals SET
        auth0_sub = :auth0_sub WHERE email = :email AND auth0_sub IS NULL
        RETURNING ...``. The principals schema (migrations 20260502 +
        20260506) ships no ``email`` column; the resolver's ``_first_auth_human``
        treats a ``None`` return as "no invited row matched" and falls
        through to :meth:`insert_human`, which is the brainstorm's exact
        semantics for that branch.

        When a future migration adds ``email``:

        1. Move the brainstorm's UPDATE form into ``principals.sql``.
        2. Replace this body with ``record = await
           self._queries.fallback_by_email(conn, email=email,
           auth0_sub=auth0_sub); return record_to_resolved_principal(record)
           if record else None``.
        3. The integration test
           ``test_fallback_by_email_returns_none_until_schema_adds_email``
           flips its assertion (failing test → forced rewrite is the
           coupling).

        Per the resolver T2's
        :meth:`PrincipalQueries.fallback_by_email` docstring: "Returns
        the populated row on success, ``None`` if no row matched." This
        stub satisfies the contract by always selecting the second
        branch. ``conn`` / ``email`` / ``auth0_sub`` are accepted to match
        the Protocol signature --- the resolver passes them; the stub
        ignores them.
        """
        return None

    async def insert_human(
        self,
        conn: asyncpg.Connection,
        *,
        auth0_sub: str,
        email: str | None,  # noqa: ARG002 - schema-pending; ignored until column lands
        display_name: str | None,
    ) -> ResolvedPrincipal:
        """Insert a fresh ``kind='human'`` principal; return the new row.

        ``email`` is accepted to match the resolver's call shape (the
        Protocol declares it required-with-None) but **discarded** until
        the schema lands the column. When the future migration adds
        ``email``, this method writes the value through to the INSERT
        VALUES list and ``RETURNING`` clause.

        Raises :class:`asyncpg.UniqueViolationError` on partial-UNIQUE
        conflict on ``auth0_sub`` (E2 race). The resolver catches that
        exception and re-SELECTs to handle the concurrent-first-auth
        race.
        """
        record = await self._queries.insert_human(
            conn, auth0_sub=auth0_sub, display_name=display_name
        )
        return record_to_resolved_principal(record)

    async def insert_agent(
        self,
        conn: asyncpg.Connection,
        *,
        auth0_sub: str,
        display_name: str | None,
    ) -> ResolvedPrincipal:
        """Insert a fresh ``kind='agent'`` principal; return the new row.

        Raises :class:`asyncpg.UniqueViolationError` on partial-UNIQUE
        conflict on ``auth0_sub`` (E3 race). Agents have no email-fallback
        path, so the resolver does not catch a UV here for an email-
        collision branch --- the only legal UV at this site is the
        ``auth0_sub`` race.
        """
        record = await self._queries.insert_agent(
            conn, auth0_sub=auth0_sub, display_name=display_name
        )
        return record_to_resolved_principal(record)


# ---------------------------------------------------------------------------
# The default singleton.
#
# T6 imports this and passes it as the ``queries`` argument to
# :func:`resolve_principal`. The instance is built once at import time --- the
# aiosql loader reads the SQL file once; subsequent calls reuse the parsed
# query bodies.
# ---------------------------------------------------------------------------


def _make_default_instance() -> Principals:
    """Build the production :class:`Principals` instance.

    Wrapped in a function so a test that needs a fresh load can call it
    rather than reaching at module-private state. The default-import
    path just reads :data:`principals_queries`.
    """
    return Principals()


principals_queries: Principals = _make_default_instance()


def get_principal_queries() -> Principals:
    """FastAPI dependency factory returning the production :class:`Principals` singleton.

    This is the injection seam that lets FastAPI's dependency system resolve the
    ``queries`` parameter of :func:`~skaldos.middleware.hydration.current_principal`
    without trying to validate a :class:`~skaldos.middleware.resolver.PrincipalQueries`
    Protocol as a Pydantic request-body field (which would fail).

    Tests that want to inject a stub can override this dep via
    ``app.dependency_overrides[get_principal_queries] = lambda: stub_queries``.

    Per ``docs/slices/slice-2-authorization/policy-module-and-chokepoint/
    03-technical-implementation.md`` § F5: the forward-ref workaround in
    ``middleware/__init__.py`` used a private ``_get_principals_queries`` for
    the same purpose; this function is the public replacement. Followups #4.
    """
    return principals_queries
