"""OpenAPI error-response schemas for principal-hydration failures (T9).

Per
``docs/slices/slice-1-tenant-chokepoint/principal-hydration-middleware/03-technical-implementation.md``
§ "Error management" + ``05-task-list.md`` § T9: every
:class:`~skaldos.middleware.PrincipalHydrationError` subclass has a
canonical (HTTP status, ``code`` string) mapping that clients
(frontend, MCP server) read from JSON error bodies. Per §10.2 OpenAPI
is the contract --- the response shape lives in this module so the
spec generator can publish it on every JWT-protected route once the
FastAPI app surface lands.

Scaffold-now-wire-later (per CLAUDE.md SOP)
-------------------------------------------

As of this module's first commit, no FastAPI app surface exists in
``services/api/skaldos/``; there is no ``FastAPI()`` instance on
which to register the responses. The brainstorm's ``05-task-list.md``
§ T9 § "Open question" anticipates this: "registered as global error
responses on every JWT-protected route" is deferred to whichever slice
assembles the app (likely Slice 2's ``can()`` chokepoint work). When
the app surface lands, route definitions consume this module's
:data:`PRINCIPAL_HYDRATION_RESPONSES` dict via FastAPI's
``responses=`` keyword:

.. code-block:: python

    from fastapi import APIRouter, Depends
    from skaldos.middleware import current_principal, Principal
    from skaldos.middleware.openapi_responses import (
        PRINCIPAL_HYDRATION_RESPONSES,
    )

    router = APIRouter()


    @router.get("/whoami", responses=PRINCIPAL_HYDRATION_RESPONSES)
    async def whoami(
        principal: Principal = Depends(current_principal),
    ) -> dict[str, object]:
        ...

The response models are tested in
``tests/unit/middleware/test_openapi_responses.py``; the runbook
(``docs/runbooks/principal-hydration.md`` § "OpenAPI error
responses") is the operator-facing documentation.

Why a single response model
----------------------------

The model :class:`PrincipalErrorResponse` is shared across all four
status codes (403, 409, 500, 503). The discriminator clients dispatch
on is the ``code`` string, **not** the HTTP status: multiple ``code``
values share a status (notably 500 and 503; see the runbook's status-
code mapping table). A single model with a string ``code`` field
keeps the OpenAPI spec compact and matches the generated TS Zod /
MCP error-decoder shape (one schema, one parser, ``code``-driven
dispatch).

The alternative (one Pydantic model per error class) would generate
seven schemas and seven Zod parsers for what is structurally the
same JSON envelope. Per MP1 (primitives over subsystems) and MP4
(rule-of-three before abstracting), the single-model shape is the
right call until a real consumer demands per-class typing --- at
which point the seven-class shape is a non-breaking refinement.

References: §10.2 (OpenAPI is the contract); §13.2 (audit log is
evidence; the ``message`` field carries no PII); §14.7 (OpenAPI
codegen surface --- frontend's Zod codegen + MCP error decoder both
read this); MP1 (primitives over subsystems); MP4 (rule-of-three);
``02-edge-cases.md`` E5 / E8 / E9 / E10 / E13 / E19 / E7 (the seven
error classes); ``03-technical-implementation.md`` § "Error
management" (the canonical HTTP-code / ``code`` / ``event_name``
table); ``04-testing-strategy.md`` § "tests/unit/middleware/" (the
unit-test suite that pins the model shapes).
"""

from __future__ import annotations

from typing import Any, ClassVar

from pydantic import BaseModel, ConfigDict

from .errors import (
    GUCSetFailed,
    PoolExhausted,
    PrincipalDisabledError,
    PrincipalEmailCollision,
    PrincipalIntegrityError,
    PrincipalKindUnknown,
    PrincipalLookupTimeout,
)

__all__ = [
    "PRINCIPAL_HYDRATION_RESPONSES",
    "PrincipalErrorResponse",
]


class PrincipalErrorResponse(BaseModel):
    """OpenAPI schema for any :class:`PrincipalHydrationError` JSON body.

    The shared response envelope. Clients dispatch on the ``code``
    string (which matches the
    :attr:`~skaldos.middleware.PrincipalHydrationError.code` ClassVar
    on the raised exception); the ``message`` is operator-visible
    English suitable for inclusion in user-facing error UIs without
    further translation. The ``detail`` slot is reserved for future
    error-classes that need structured extra context (none today; the
    field is typed ``dict[str, Any] | None`` so a Slice 2+ extension
    can ship without a breaking change to the envelope).

    Frozen + strict-extra: the model rejects unknown kwargs at
    construction (``ConfigDict(frozen=True, extra="forbid")``). This
    is structural defense-in-depth against an upstream caller
    smuggling extra fields through the response shape (AP5).

    The model lives at ``skaldos.middleware.openapi_responses``; the
    canon ``code`` constants live at ``skaldos.middleware.errors``.
    The two are kept in lockstep by the runbook-consistency test
    ``tests/unit/test_principal_hydration_runbook_consistency.py``
    and the OpenAPI-shape unit test
    ``tests/unit/middleware/test_openapi_responses.py``; renaming a
    code in one place fails both tests loudly.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    code: str
    """Stable error-code string. Mirrors the
    :attr:`~skaldos.middleware.PrincipalHydrationError.code` ClassVar
    on the raised exception. Clients (frontend Zod, MCP error
    decoder) dispatch on this value; renaming is a breaking change
    to the API contract per §10.2."""

    message: str
    """Operator-visible English. Suitable for inclusion in user-
    facing error UIs without translation; carries no PII per §13.2."""

    detail: dict[str, Any] | None = None
    """Optional structured extra context. ``None`` for every Slice
    1 error; reserved for future error-classes (Slice 2+) that need
    to ship structured detail (e.g., a rate-limiter ``retry_after``
    payload, a delegation-mismatch principal-id pair). The default
    keeps the field optional so the canonical envelope stays compact
    in the common case."""

    # ------------------------------------------------------------------
    # Canonical (status_code, code, message) tuples for each error class.
    #
    # The class-level constants below back the per-status-code
    # response examples that go into the OpenAPI spec via the
    # ``content`` -> ``application/json`` -> ``example`` slot. Keeping
    # them as ClassVars (not module-level) keeps the namespace tidy
    # and makes the introspection in T9's tests trivial (iterate
    # ``PrincipalErrorResponse.EXAMPLES``).
    # ------------------------------------------------------------------

    EXAMPLES: ClassVar[dict[str, dict[str, str]]] = {
        # 403: identity-level refusal.
        PrincipalDisabledError.code: {
            "code": PrincipalDisabledError.code,
            "message": "Principal is disabled; access refused.",
        },
        # 409: human-identity collision on email.
        PrincipalEmailCollision.code: {
            "code": PrincipalEmailCollision.code,
            "message": "Email collides with an existing principal; manual reconciliation required.",
        },
        # 503: pool exhaustion.
        PoolExhausted.code: {
            "code": PoolExhausted.code,
            "message": "Pool exhausted; retry shortly.",
        },
        # 503: principal-resolution statement_timeout.
        PrincipalLookupTimeout.code: {
            "code": PrincipalLookupTimeout.code,
            "message": "Principal lookup timed out; retry shortly.",
        },
        # 500: GUC set_config failure (substrate-integrity alarm).
        GUCSetFailed.code: {
            "code": GUCSetFailed.code,
            "message": "GUC commit failed; substrate integrity alarm.",
        },
        # 500: partial-UNIQUE on auth0_sub violated (substrate-integrity alarm).
        PrincipalIntegrityError.code: {
            "code": PrincipalIntegrityError.code,
            "message": "Principal uniqueness invariant violated; substrate integrity alarm.",
        },
        # 500: VerifiedClaims.kind not in {"human", "agent"} (auth-feature regression).
        PrincipalKindUnknown.code: {
            "code": PrincipalKindUnknown.code,
            "message": "Principal kind is not 'human' or 'agent'; auth verifier regression.",
        },
    }
    """Per-``code`` canonical example payloads, keyed by the
    :attr:`~skaldos.middleware.PrincipalHydrationError.code` string.
    Consumed by the OpenAPI spec (via FastAPI's ``responses=``
    parameter) so each status's example body shows a realistic
    shape; tests
    (``tests/unit/middleware/test_openapi_responses.py``) pin the
    set of keys against the canonical exception classes."""


# ---------------------------------------------------------------------------
# Per-status-code response specs ready for FastAPI's ``responses=`` kwarg.
#
# FastAPI's ``responses`` parameter accepts ``dict[int, dict[str, Any]]``
# where each value is an OpenAPI Response Object spec. Each entry below
# names the model + a representative ``example`` so the generated spec
# carries operator-readable error shapes.
# ---------------------------------------------------------------------------

PRINCIPAL_HYDRATION_RESPONSES: dict[int | str, dict[str, Any]] = {
    403: {
        "model": PrincipalErrorResponse,
        "description": "Principal is disabled (E8 / S8).",
        "content": {
            "application/json": {
                "example": PrincipalErrorResponse.EXAMPLES[PrincipalDisabledError.code],
            },
        },
    },
    409: {
        "model": PrincipalErrorResponse,
        "description": "Email collision on first-auth (E5).",
        "content": {
            "application/json": {
                "example": PrincipalErrorResponse.EXAMPLES[PrincipalEmailCollision.code],
            },
        },
    },
    500: {
        "model": PrincipalErrorResponse,
        "description": (
            "Substrate-integrity alarm: GUC set_config failed (E10), partial-UNIQUE on "
            "auth0_sub violated (E13), or VerifiedClaims.kind is not 'human' / 'agent' (E7)."
        ),
        "content": {
            "application/json": {
                "examples": {
                    "guc_set_failed": {
                        "summary": "set_config failed (PC1 commit broken).",
                        "value": PrincipalErrorResponse.EXAMPLES[GUCSetFailed.code],
                    },
                    "principal_integrity": {
                        "summary": "Partial-UNIQUE on auth0_sub violated.",
                        "value": PrincipalErrorResponse.EXAMPLES[PrincipalIntegrityError.code],
                    },
                    "principal_kind_unknown": {
                        "summary": "VerifiedClaims.kind unrecognized.",
                        "value": PrincipalErrorResponse.EXAMPLES[PrincipalKindUnknown.code],
                    },
                },
            },
        },
    },
    503: {
        "model": PrincipalErrorResponse,
        "description": (
            "Transient infrastructure pressure: pool exhaustion (E9) or principal-lookup "
            "statement_timeout (E19). Retry-After: 5 header attached."
        ),
        "headers": {
            "Retry-After": {
                "description": "Seconds the client should wait before retrying.",
                "schema": {"type": "string", "example": "5"},
            },
        },
        "content": {
            "application/json": {
                "examples": {
                    "pool_exhausted": {
                        "summary": "Pool exhausted (E9 / S13).",
                        "value": PrincipalErrorResponse.EXAMPLES[PoolExhausted.code],
                    },
                    "lookup_timeout": {
                        "summary": "Principal-lookup statement_timeout fired (E19).",
                        "value": PrincipalErrorResponse.EXAMPLES[PrincipalLookupTimeout.code],
                    },
                },
            },
        },
    },
}
"""FastAPI ``responses=`` mapping for every JWT-protected route.

Pass this dict to a route definition's ``responses`` keyword to
register the four error responses (403 / 409 / 500 / 503) with the
canonical Pydantic envelope and operator-readable example bodies.
Slice 1 ships the dict; the slice that assembles the FastAPI app
(likely Slice 2's ``can()`` chokepoint feature) wires it onto every
``Depends(current_principal)``-protected route.

The dict's keys are ``int`` HTTP status codes (FastAPI accepts the
``int | str`` union; we use ``int`` for the canonical four codes);
each value is an OpenAPI Response Object with ``model`` (the Pydantic
class for spec generation), ``description`` (operator-readable), and
``content.application/json.example`` (or ``examples`` when a status
hosts multiple ``code`` values).
"""
