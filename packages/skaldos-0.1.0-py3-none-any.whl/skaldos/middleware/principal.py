"""The :class:`Principal` request-scope identity model (Slice 1, middleware T1).

Per ``docs/slices/slice-1-tenant-chokepoint/master-plan.md`` § "Shared
artifacts & contracts" (row ``Principal``) and
``03-technical-implementation.md`` § "The ``Principal`` model".

The substrate's first-class identity in request scope. Constructed by
``Depends(current_principal)`` (T6, follow-up) after JWT verification
+ DB resolution + GUC commit. Read by every downstream ``Depends()``
chain --- Slice 2's ``authorize``, Slice 5's audit emitter, Slice 7's
agent runtime attribution. The model is **frozen** and rejects unknown
kwargs (``ConfigDict(frozen=True, extra="forbid")``); after construction
the shape is immutable, hashable, and equality-comparable by field
values.

Imports
-------

:class:`~skaldos.auth.VerifiedClaims` is imported **directly** from the
peer ``skaldos.auth`` package (Wave 0 / auth T1 landed it on main; see
``services/api/skaldos/auth/__init__.py``). The brainstorm originally
anticipated a forward-ref pattern (``"VerifiedClaims"`` string
annotation) because middleware T1 was scheduled to ship before auth T1;
in practice auth T1 landed first, so the direct import works without
any string-annotation rebuild step. Documented here so a future reader
asking "why isn't this a forward ref like the brainstorm said?" sees
the reason without re-reading the master plan.

Field set (pinned in the master plan)
-------------------------------------

Per the master plan's "Shared artifacts & contracts" row, the fields
are: ``id, kind, auth0_sub, primary_tenant_id, visible_tenant_ids,
display_name, disabled_at, verified_claims, delegation, trust_score,
clearance``. Field semantics:

- **``id``** --- ``uuid``, the substrate's surrogate PK. Stable across
  renames; never reused. UUIDv7 in production (PC8 / PC16) so ordering
  carries the embedded creation timestamp; the model accepts any
  :class:`~uuid.UUID`, version-agnostic.
- **``kind``** --- ``Literal["human", "agent"]``. The MP10 discriminator.
  Mirrors the ``principals.kind`` CHECK constraint per
  ``migrations/versions/20260502_principals.py``. Pydantic rejects
  third values at construction.
- **``auth0_sub``** --- the JWT ``sub`` claim. Opaque key; for humans
  ``"auth0|<id>"``, for agents ``"<client_id>@clients"``. Stored
  verbatim in the row; this field exposes it for downstream audit
  attribution (Slice 5 reads this in audit-row keys).
- **``primary_tenant_id``** --- ``UUID | None``. Nullable: not every
  principal has docked into a primary tenant yet (E15 --- a freshly
  invited user whose membership row hasn't landed; an agent whose
  tenancy comes from delegation context, not a "home tenant").
- **``visible_tenant_ids``** --- ``tuple[UUID, ...]``. **Tuple**, not
  list, so the model is immutable + hashable. Empty tuple is the legal
  "no memberships yet" state (E14 --- the user authenticates fine, but
  every multi-tenant ``SELECT`` returns zero rows because RLS reads
  ``ANY(current_setting('app.current_principal_visible')::uuid[])``).
- **``display_name``** --- ``str | None``. Used in human-readable
  rendering surfaces (Slice 2+); has no chokepoint role.
- **``disabled_at``** --- always ``None`` in request scope. A disabled
  principal would have 403'd at hydration (T6 --- the
  :class:`~skaldos.middleware.errors.PrincipalDisabledError` early
  return prevents ``set_config`` from running; the model is never
  constructed). The field is typed as ``Literal[None]`` with a default
  of ``None`` so Pydantic enforces the always-``None`` invariant: any
  attempt to construct ``Principal(disabled_at=datetime.now(...))``
  fails validation. The field is kept on the shape for symmetry with
  the row schema and so Slice 5's audit emitter can serialize a full
  row-shaped projection without a special case; runtime callers read
  the absence of a 403, not the field value.
- **``verified_claims``** --- the upstream
  :class:`~skaldos.auth.VerifiedClaims` payload. Carried so Slice 5's
  audit emitter can record token-level attribution without re-fetching;
  the field is **never logged** (the :mod:`packages.log` safelist
  rejects it). See the brainstorm § "Fault lines" for the privacy-vs-
  auditability tension and the trigger to revisit.
- **``delegation`` / ``trust_score``** --- scaffold-now-wire-later slots
  per the CLAUDE.md SOP. Default ``None`` until the wiring slice lands
  (Slice 7+ for delegation, Slice 5+ for trust_score).
- **``clearance`` / ``clearance_assignments``** --- Slice 6 active
  clearance shape. ``clearance`` is the safe request minimum; per-tenant
  checks consume ``clearance_assignments``.

References: §3.1 (plural-tenant principal --- ``visible_tenant_ids``
exposed in request scope from commit one); §4.5 (tenant always derived
from this subject, never from request state); §4.7 (disabled-principal
rejection happens at hydration, before this model is constructed);
MP10 (humans + agents same shape, only ``kind`` differs); ML7 (agents
are hub nodes in the same table as people; same chokepoint shape);
AP5 (no debug bypass --- the ``frozen=True`` + ``extra="forbid"`` shape
prevents per-request mutation as a "debug" side channel). The master
plan's "Shared artifacts & contracts" row is the source of truth for
the field set; this docstring documents the *why* per field.
"""

from __future__ import annotations

from typing import Any, Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict

from skaldos.auth import VerifiedClaims


class Principal(BaseModel):
    """The substrate's first-class identity in request scope.

    Frozen + strict-extra. Constructed by ``Depends(current_principal)``
    after JWT verification + DB resolution + GUC commit. Field set per
    ``master-plan.md`` § "Shared artifacts & contracts".

    See the module docstring for per-field semantics, the immutability
    rationale, and the rationale for the always-``None`` ``disabled_at``
    invariant.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    """Substrate-internal surrogate PK. UUIDv7 in production (PC8 /
    PC16) so the PK carries an embedded timestamp; the model accepts
    any :class:`~uuid.UUID`. Stable across renames; never reused."""

    kind: Literal["human", "agent"]
    """MP10 discriminator. Mirrors the ``principals.kind`` CHECK
    constraint per ``migrations/versions/20260502_principals.py``.
    Pydantic rejects any other value at construction;
    ``test_kind_literal_rejects_other_strings`` in
    :mod:`tests.unit.middleware.test_principal_model` pins this."""

    auth0_sub: str
    """JWT ``sub`` claim, verbatim. ``"auth0|<id>"`` for humans;
    ``"<client_id>@clients"`` for agents. Identity-resolution code
    treats this as a key, not a structured value."""

    primary_tenant_id: UUID | None
    """The principal's "home tenant" --- nullable for principals not yet
    docked into a primary tenant (§3.1; E15). Slice 4+ write paths read
    this when no explicit tenant is supplied; an explicit ``None`` is a
    legitimate request-state ("no default tenant configured")."""

    visible_tenant_ids: tuple[UUID, ...]
    """Tuple (not list) for hashability + immutability. The substrate
    primitive maintains this column on every membership write (the
    ``visible_tenant_ids`` projection trigger owned by the
    ``tenant-and-membership-schema`` peer feature); the chokepoint reads
    the result and trusts it (per ML5 / MP1 --- "primitive owns the
    invariant; chokepoint reads the result"). Empty tuple is the legal
    "no memberships yet" state (E14)."""

    role_assignments: tuple[tuple[UUID, str], ...] = ()
    """The principal's active ``(tenant_id, role)`` memberships at
    request start.  Tuple of tuples (not dict / not list) for
    hashability + immutability + Pydantic-frozen compatibility.

    **Owned by the chokepoint (Slice 2 followups #1).** Hydration
    (``current_principal``) runs a single ``SELECT tenant_id, role
    FROM memberships WHERE principal_id = $1 AND revoked_at IS NULL``
    against the runtime conn after the GUCs commit, and stamps the
    result here.  Polar's ``has_role_in_org(principal, role,
    organization_id)`` predicate is then a pure-Python attribute
    lookup against this field — no async resolver, no event-loop
    crossing inside the synchronous Oso evaluation.

    This replaces the prior ``_RoleInOrgBridge`` event-loop-bridging
    resolver (which fetched roles per Polar rule eval against
    ``principal._conn`` on a fresh asyncio loop and crashed on the
    asyncpg-loop mismatch — see ``docs/specs/2026-05-04-slice-2-followups.md``
    item #1).  Snapshot consistency at request start is the right
    semantic: a permission check shouldn't flip mid-request because
    a row landed in another tenant.

    Empty tuple is the legal "no memberships yet" state (E14 spirit;
    same as ``visible_tenant_ids``).  The default ``()`` keeps the
    field forward-compatible with call sites that build ``Principal``
    instances without a hydration path (test fixtures); production
    code paths through ``current_principal`` always populate it.

    Pinned ordering: rows arrive sorted by ``(tenant_id, granted_at
    DESC)``.  Ordering is observable through Polar's ``in`` operator
    (which iterates left-to-right) but the bridge uses ``in`` for
    membership testing only, so the order does not affect the boolean
    decision.  The deterministic order makes the field hashable and
    makes test assertions stable."""

    clearance_assignments: tuple[tuple[UUID, Literal["C0", "C1", "C2", "C3", "C4"]], ...] = ()
    """Active per-tenant membership clearances at request start.

    Slice 6 keeps this tenant-scoped so plural-visible-tenant reads cannot
    collapse to a global maximum clearance. The scalar ``clearance`` field is
    only the safe request minimum.
    """

    display_name: str | None
    """Human-readable name for rendering surfaces (Slice 2+ admin UI);
    no chokepoint role."""

    # Always ``None`` in request scope: a disabled principal would have
    # 403'd at hydration (T6 raises :class:`PrincipalDisabledError`
    # before ``set_config`` runs; the model is never constructed for
    # disabled principals). Typed as ``Literal[None]`` with a default
    # of ``None`` so Pydantic enforces the always-``None`` invariant ---
    # any attempt to pass a ``datetime`` fails validation. The field
    # stays on the shape for symmetry with the row schema (Slice 5's
    # audit emitter serializes the full shape).
    disabled_at: Literal[None] = None

    verified_claims: VerifiedClaims
    """Upstream :class:`~skaldos.auth.VerifiedClaims` --- the verified
    JWT payload. Carried so Slice 5's audit emitter can record token-
    level attribution without re-fetching. **Never logged** (rejected
    by the :mod:`packages.log` safelist). See the brainstorm § "Fault
    lines" for the privacy-vs-auditability tension."""

    # ------------------------------------------------------------------
    # Scaffold-now-wire-later slots (per CLAUDE.md SOP).
    # ------------------------------------------------------------------

    delegation: dict[str, Any] | None = None
    """Slice 7+ --- the MP10 ``act`` claim payload. ``None`` until the
    delegations table + JWT ``act`` claim land. Typed as
    ``dict[str, Any]`` here because the typed ``Delegation`` model
    lives in the wiring slice; refining the type at that point is a
    non-breaking widening (a typed model is a subtype of
    ``dict[str, Any]`` for read sites that use named keys)."""

    trust_score: float | None = None
    """Slice 5+ --- per the §4.3 trust matrix. ``None`` until the trust
    substrate lands. Slice-1 readers must handle the ``None`` case
    (treating it as "no trust signal yet")."""

    clearance: Literal["C0", "C1", "C2", "C3", "C4"] = "C0"
    """Safe request-level minimum clearance across visible memberships.

    Read predicates that know the row tenant use ``clearance_assignments`` via
    ``app.current_principal_context.clearances``. This scalar field is retained
    for callers that need one fail-closed value; it must not be treated as a
    global maximum for cross-tenant reads.
    """
