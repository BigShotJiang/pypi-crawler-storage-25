"""Request-scope middleware --- principal hydration + chokepoint surface.

Slice 1, ``principal-hydration-middleware`` feature. This package
bundles the FastAPI dependencies, ASGI middleware, and substrate types
that sit between the wire and every JWT-protected handler.

Surfaces (PR-sized tasks):

- :class:`Principal` --- T1, the frozen, strict-extra Pydantic model
  that carries the resolved identity through request scope. Read by
  every downstream ``Depends()`` chain (Slice 2's ``authorize``, Slice
  5's audit emitter, Slice 7's agent runtime attribution). Field set
  pinned in ``docs/slices/slice-1-tenant-chokepoint/master-plan.md``
  § "Shared artifacts & contracts" --- this docstring is *not* the
  source of truth for the field set; the master plan is.
- :class:`PrincipalHydrationError` (+ 7 concrete subclasses) --- T1,
  the base class for every hydration-failure surface. Subclasses
  (:class:`PrincipalDisabledError`,
  :class:`PrincipalEmailCollision`,
  :class:`PoolExhausted`,
  :class:`PrincipalLookupTimeout`,
  :class:`GUCSetFailed`,
  :class:`PrincipalIntegrityError`,
  :class:`PrincipalKindUnknown`) carry stable error-code strings that
  the OpenAPI surface (T9) and downstream clients (frontend, MCP) read.
  The base class is the catch shape for the FastAPI dependency in T6.
- :data:`PUBLIC_ROUTES` --- T5, the small allowlist of routes that do
  *not* require a JWT (``public_routes.py``).
- :func:`is_public_route` --- T5, test-time helper that classifies a
  path.
- :func:`add_cors_middleware` --- T5, registers Starlette's
  :class:`~starlette.middleware.cors.CORSMiddleware` so the browser
  ``OPTIONS`` preflight bypasses dependency resolution (E23).
- :func:`current_principal` --- T6, the **load-bearing chokepoint**:
  the FastAPI dependency every JWT-protected route declares (directly
  or transitively). Acquires a connection from the asyncpg pool, opens
  an explicit transaction, calls
  :func:`~skaldos.middleware.resolver.resolve_principal`, commits the
  PC1 GUC contract (two ``SELECT set_config(name, value, true)``
  calls), stashes the connection in ``request.state.connection`` for
  :func:`~skaldos.db.get_connection` to serve to handlers, yields a
  frozen :class:`Principal` to the handler. On any exception path the
  transaction rolls back; on every path the connection returns to the
  pool. PC1 (``set_config(..., true)``) is the substrate-wide GUC
  injection form; the transaction-local nature survives PgBouncer
  transaction-mode pooling per the S1 spike outcome.
- :data:`GUC_PRINCIPAL_ID` / :data:`GUC_PRINCIPAL_VISIBLE` --- T6, the
  pinned GUC names. Constants here; bound as VALUE parameters to
  ``set_config`` (PC1 strict adherence). Read by the schema feature's
  ``app.principal_id()`` / ``app.principal_visible()`` SQL helpers and
  by RLS policies on every multi-tenant table.
- :data:`STATEMENT_TIMEOUT_MS` --- T6, the per-transaction statement
  timeout (5000ms) set via ``SET LOCAL statement_timeout`` immediately
  after the chokepoint's transaction begins.

Future T-tasks (T7 first-auth integration tests, T8 edge-case
integration tests, T9 runbook + OpenAPI error schemas, T10 audit test
+ ``/whoami``) layer on this base. New names get appended to
``__all__`` below; the file is structured so peer-PR adds compose
cleanly via line-only additions.

Imports
-------

This package imports :class:`~skaldos.auth.VerifiedClaims` directly
(Wave 0 / auth T1 landed it on main; see
``services/api/skaldos/auth/__init__.py``). The brainstorm originally
anticipated a forward-ref pattern (the master plan's "soft
dependencies" section names this); in practice auth T1 landed first,
so the direct import works without any string-annotation rebuild step.

Slice 2 T10 (followups #4) removed the ``from __future__ import
annotations`` + ``TYPE_CHECKING``-guarded imports from
:mod:`skaldos.middleware.hydration` and replaced the package-level
annotation-patch block here with a direct
``Annotated[PrincipalQueries, Depends(get_principal_queries)]``
annotation in :func:`~skaldos.middleware.hydration.current_principal`
itself. The patch block is gone; the public surface is unchanged.

Public surface
--------------

Every class and helper is importable directly from
:mod:`skaldos.middleware`. Consumer code does
``from skaldos.middleware import Principal, PrincipalDisabledError,
PUBLIC_ROUTES`` --- coupling to a sub-module path
(``skaldos.middleware.principal``,
``skaldos.middleware.public_routes``, etc.) is a smell. Mirrors the
discipline :mod:`skaldos.auth` and :mod:`skaldos.kms` established in
earlier slices. The package ``__all__`` list below is the source of
truth.

References: §3.1 (plural-tenant principal); §4.5 (subject-derived
ownership); §4.7 (disabled-principal rejection); MP10 (humans + agents
same shape); ML7 (agents are hub nodes in the same table); AP5 (no
debug bypass --- the ``frozen=True`` + ``extra="forbid"`` shape on
:class:`Principal` is a structural defense). The master plan owns the
cross-feature contracts; this docstring points back at it.

T5 references:
``docs/slices/slice-1-tenant-chokepoint/principal-hydration-middleware/03-technical-implementation.md``
§ "File layout";
``docs/slices/slice-1-tenant-chokepoint/principal-hydration-middleware/05-task-list.md``
§ T5.
"""

from .errors import (
    GUCSetFailed,
    PoolExhausted,
    PrincipalDisabledError,
    PrincipalEmailCollision,
    PrincipalHydrationError,
    PrincipalIntegrityError,
    PrincipalKindUnknown,
    PrincipalLookupTimeout,
)
from .hydration import (
    GUC_PRINCIPAL_ID,
    GUC_PRINCIPAL_VISIBLE,
    STATEMENT_TIMEOUT_MS,
    current_principal,
)
from .openapi_responses import PRINCIPAL_HYDRATION_RESPONSES, PrincipalErrorResponse
from .principal import Principal
from .public_routes import PUBLIC_ROUTES, add_cors_middleware, is_public_route

__all__ = [
    "GUCSetFailed",
    "GUC_PRINCIPAL_ID",
    "GUC_PRINCIPAL_VISIBLE",
    "PRINCIPAL_HYDRATION_RESPONSES",
    "PUBLIC_ROUTES",
    "PoolExhausted",
    "Principal",
    "PrincipalDisabledError",
    "PrincipalEmailCollision",
    "PrincipalErrorResponse",
    "PrincipalHydrationError",
    "PrincipalIntegrityError",
    "PrincipalKindUnknown",
    "PrincipalLookupTimeout",
    "STATEMENT_TIMEOUT_MS",
    "add_cors_middleware",
    "current_principal",
    "is_public_route",
]
