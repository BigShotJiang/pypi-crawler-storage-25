"""Public-route allowlist + CORS preflight handling (T5).

Per ``docs/slices/slice-1-tenant-chokepoint/principal-hydration-middleware/``
``03-technical-implementation.md``
§ "Public-route allowlist" / § "Cross-feature ownership" and
``02-edge-cases.md`` § E20 (public route mistakenly declares
``Depends(current_principal)``) + § E23 (CORS preflight without JWT):
this module pins the substrate's classification of the *small* set of
routes that legitimately do not require a JWT, and registers
Starlette's :class:`~starlette.middleware.cors.CORSMiddleware` so the
browser preflight (``OPTIONS``) reaches the response *before*
dependency resolution short-circuits the request to ``401``.

Why the allowlist is a frozen set
---------------------------------

The runtime never queries :data:`PUBLIC_ROUTES`. The allowlist's job
is *test-time*: a unit test
(``tests/unit/middleware/test_public_routes_disjoint.py``) walks the
FastAPI app's route table, classifies each route by whether it
declares the chokepoint dependency (Slice 1 T6 will install
``Depends(current_principal)`` on every protected route), and asserts
the disjoint-set invariant --- every route is either in
:data:`PUBLIC_ROUTES` or it goes through the chokepoint, never both.

That structural assertion is the AP5 ("no debug bypass") seatbelt at
the routing layer: a developer who marks ``/healthz`` as protected
*or* who ships a new tenant-data route under one of the public paths
fails the test loudly. The runtime stays clean: the route registration
itself decides whether to declare the chokepoint dependency, and the
test pins the result.

Mutating :data:`PUBLIC_ROUTES` requires editing this module *and* the
test (which asserts the exact set), so adding a public route is a
deliberate two-file change reviewed in PR.

Why CORS lives here, not in a separate module
---------------------------------------------

The CORS middleware *is* part of the public-route surface --- it
short-circuits the ``OPTIONS`` preflight before the dependency tree
runs, which is what makes E23 ("preflight to a JWT-protected route
without ``Authorization`` header") return ``200`` instead of ``401``.
Co-locating the allowlist and the CORS registration keeps the two
public-routing concerns in one file; the master plan's "Wave 1"
parallel-safe boundary is preserved (T5 only touches this module +
its test).

Production hardening
--------------------

The default origin is ``*`` so dev + integration tests work without
configuration. Production deploys override via the
``SKALDOS_CORS_ALLOW_ORIGINS`` environment variable (comma-separated
list of exact origins; ``*`` is wrong-shaped for production because a
frontend-side credential leak via wildcard origin would be a textbook
AP5 bypass). The startup assertion that rejects ``*`` when
``SKALDOS_ENV == "production"`` is deliberately *not* implemented in
T5 --- it is a Slice >=2 deployment concern (the production frontend
doesn't exist in Slice 1; Phase 2 Frontend Slice A wires it). This
module ships the *shape* of the configuration; the assertion lands
when production traffic does. Per CLAUDE.md "scaffold-now-wire-later".

References: AP5 (no bypass --- public-route allowlist is
*classification*, not bypass); the substrate's S6/S11 idioms (one
chokepoint regardless of surface; OpenAPI as contract);
``02-edge-cases.md`` E20 + E23,
``03-technical-implementation.md`` § "Public-route allowlist" /
§ "Happy path" (the CORS layer above the rate-limiter above the
chokepoint),
``04-testing-strategy.md`` § "tests/unit/middleware/test_public_routes_disjoint.py".
"""

from __future__ import annotations

import os

from fastapi import FastAPI
from starlette.middleware.cors import CORSMiddleware

# -----------------------------------------------------------------------------
# Public-route allowlist
# -----------------------------------------------------------------------------
# The set of paths that do NOT require a JWT. Mirrors `03-technical-
# implementation.md` § "Public-route allowlist" + the FastAPI defaults
# (``/openapi.json``, ``/docs``, ``/redoc``, ``/docs/oauth2-redirect``)
# plus the standard liveness / readiness endpoints (``/healthz``,
# ``/readyz``) and the empty-root path (``/``) used by load balancers
# for cheap liveness probes that do not need to round-trip the schema.
#
# Adding a route here is a deliberate two-file change: this module
# *and* any disjoint-set unit tests that pin the membership.
PUBLIC_ROUTES: frozenset[str] = frozenset(
    {
        "/",
        "/healthz",
        "/readyz",
        "/openapi.json",
        "/docs",
        "/webhooks/e2b/lifecycle",
        "/webhooks/pubsub/events",
        "/redoc",
        "/docs/oauth2-redirect",
    }
)


def is_public_route(path: str) -> bool:
    """Return whether *path* is on the public-route allowlist.

    The runtime does *not* consult this function --- the dependency
    tree is the substrate. This helper exists for the disjoint-set
    unit test (``test_public_routes_disjoint.py``) and for any future
    test-time introspection that needs to classify a path.

    Per AP5: a runtime call to ``is_public_route`` to *bypass* the
    chokepoint would be a side-channel. Keep this strictly to
    test-side classification.
    """
    return path in PUBLIC_ROUTES


# -----------------------------------------------------------------------------
# CORS configuration
# -----------------------------------------------------------------------------
# Environment-variable-driven so dev + integration tests get a
# permissive default while production can lock to an explicit origin
# allowlist. Variable names share the ``SKALDOS_CORS_`` prefix to
# match the rest of the runtime config surface (see
# ``services/api/skaldos/auth/config.py`` for the
# ``SKALDOS_AUTH0_*`` precedent).
_DEFAULT_ALLOW_ORIGINS = "*"
_DEFAULT_ALLOW_METHODS = "*"
_DEFAULT_ALLOW_HEADERS = "*"


def _parse_csv_or_wildcard(raw: str) -> list[str]:
    """Parse a comma-separated env value into a list, preserving ``*``.

    ``"*"`` is a single-token wildcard that Starlette's
    :class:`CORSMiddleware` interprets specially (allow any). Any
    other comma-separated value is split, stripped, and any empty
    trailing tokens are dropped (so trailing commas in the env are
    tolerated).
    """
    raw = raw.strip()
    if raw == "*":
        return ["*"]
    return [token.strip() for token in raw.split(",") if token.strip()]


def add_cors_middleware(app: FastAPI) -> None:
    """Register Starlette's :class:`CORSMiddleware` on *app*.

    The CORS layer is registered *before* dependency resolution so the
    browser preflight (``OPTIONS``) returns ``200`` with the
    ``Access-Control-Allow-*`` headers without ever resolving
    :func:`current_principal` --- which is what makes E23 work
    ("preflight to a JWT-protected route without ``Authorization``
    header").

    Configuration (env vars; defaults are dev-permissive):

    - ``SKALDOS_CORS_ALLOW_ORIGINS`` --- comma-separated origin
      allowlist, or ``"*"`` for any origin. Default: ``"*"``.
    - ``SKALDOS_CORS_ALLOW_METHODS`` --- comma-separated HTTP method
      allowlist, or ``"*"``. Default: ``"*"``.
    - ``SKALDOS_CORS_ALLOW_HEADERS`` --- comma-separated request-header
      allowlist, or ``"*"``. Default: ``"*"``.

    **Production hardening expectation (Slice >=2):** the production
    deploy sets ``SKALDOS_CORS_ALLOW_ORIGINS`` to a literal origin
    list (e.g. ``"https://app.skaldos.io"``) and *not* ``"*"``. A
    startup assertion that rejects ``"*"`` when
    ``SKALDOS_ENV == "production"`` is deliberately not implemented in
    T5 (no production frontend yet; Phase 2 Frontend Slice A wires
    it). The shape lands here; the assertion lands when the frontend
    does. Per CLAUDE.md "scaffold-now-wire-later".

    AP5 note: this is not a bypass. ``OPTIONS`` is unauthenticated
    *by browser CORS spec*; the actual ``GET`` / ``POST`` that follows
    the preflight runs through the full dependency tree --- including
    :func:`current_principal` --- normally. The disjoint-set unit
    test pins the post-preflight invariant.
    """
    allow_origins = _parse_csv_or_wildcard(
        os.environ.get("SKALDOS_CORS_ALLOW_ORIGINS", _DEFAULT_ALLOW_ORIGINS)
    )
    allow_methods = _parse_csv_or_wildcard(
        os.environ.get("SKALDOS_CORS_ALLOW_METHODS", _DEFAULT_ALLOW_METHODS)
    )
    allow_headers = _parse_csv_or_wildcard(
        os.environ.get("SKALDOS_CORS_ALLOW_HEADERS", _DEFAULT_ALLOW_HEADERS)
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=allow_origins,
        allow_methods=allow_methods,
        allow_headers=allow_headers,
        # ``allow_credentials=False`` is the safe default with
        # wildcard origins: Starlette refuses to combine
        # ``allow_origins=["*"]`` with ``allow_credentials=True``
        # because the browser will reject the response, but the
        # combination is still wrong-shaped for production. Slice >=2
        # toggles this on with a literal origin allowlist.
        allow_credentials=False,
    )


__all__ = [
    "PUBLIC_ROUTES",
    "add_cors_middleware",
    "is_public_route",
]
