"""Principal-hydration exception hierarchy (Slice 1, middleware T1).

Per
``docs/slices/slice-1-tenant-chokepoint/principal-hydration-middleware/03-technical-implementation.md``
§ "Error management": every failure surface from the
``Depends(current_principal)`` chokepoint inherits from
:class:`PrincipalHydrationError`. Each subclass carries an ``event_name:
ClassVar[str]`` constant in the ``principal.<reason>`` namespace and a
stable ``code`` string that the OpenAPI surface (T9) and downstream
clients (frontend, MCP) read from JSON error bodies.

Why one base class
------------------

Consumer code (the FastAPI dependency in T6; the Slice-1 contract test
in :mod:`tests.integration.auth`) does ``except PrincipalHydrationError``
to catch any hydration failure and map to an HTTP code with a stable
``code`` field in the JSON body. Sub-class catches are valid for
differentiation (T6 maps :class:`PrincipalDisabledError` → 403,
:class:`PoolExhausted` / :class:`PrincipalLookupTimeout` → 503; the
rest → 500). The hierarchy is *flat* under the base --- mirroring
:mod:`skaldos.auth.errors` --- so two-level hierarchies
(``ConnectionError`` > ``PoolExhausted``) cannot invite catch-the-wrong-
level bugs.

Why ``code`` and ``event_name`` are ``ClassVar[str]``
-----------------------------------------------------

The constants are per-class, not per-instance. Declaring them as
``ClassVar[str]`` (not just ``str``) tells pyright in strict mode that
the attributes live on the class object, not on each instance; mistyping
``code = "principal_disabled"`` as a regular field would silently break
the audit-log shape and the API-error contract under T6/T9. Mirrors the
pattern :mod:`skaldos.auth.errors` established in Wave 0.

Why dotted-namespace event names
--------------------------------

Per §13.2 / §20.1, structured-log events use a ``<subsystem>.<reason>``
shape. The principal-hydration subsystem owns the ``principal.``
prefix; alerting filters on that prefix to scope to hydration failures.
``test_event_names_use_principal_namespace`` in
:mod:`tests.unit.middleware.test_error_codes` pins this property so a
future refactor that drops the ``principal.`` prefix is loud, not
silent.

Stability of the ``code`` strings
---------------------------------

The ``code`` strings are part of the **API contract** --- clients
(frontend, MCP server) read them from JSON error bodies; renaming
requires a deliberate API version bump per §10.2. The unit-test suite
in :mod:`tests.unit.middleware.test_error_codes` pins the canon table
(presence + uniqueness + the dotted ``event_name`` namespace) so a
refactor that drops or duplicates a code fails loudly.

References: §13.2 (audit log shape); §10.2 (OpenAPI is the contract);
§14.7 (fail-loudly-at-the-boundary hygiene); MP10 (humans + agents same
code path → same exception hierarchy); AP5 (no debug-mode bypass ---
exceptions are the *only* failure surface; no silent ``return None``
paths). Edge cases in ``02-edge-cases.md``: every E* maps to one
subclass below; the "Error management" table in
``03-technical-implementation.md`` is the per-event mapping.
"""

from __future__ import annotations

from typing import ClassVar


class PrincipalHydrationError(Exception):
    """Base class for every hydration failure.

    Consumer code (T6's FastAPI dependency; the Slice 1 contract test in
    :mod:`tests.integration.auth`) catches this class to handle *any*
    hydration failure. Sub-class catches are valid for differentiation
    (T6 differentiates :class:`PrincipalDisabledError` → 403,
    :class:`PoolExhausted` / :class:`PrincipalLookupTimeout` → 503; the
    rest → 500).

    Subclasses MUST declare ``code: ClassVar[str]`` and
    ``event_name: ClassVar[str]`` (the latter in the
    ``principal.<reason>`` namespace). The unit-test suite in
    :mod:`tests.unit.middleware.test_error_codes` enforces both
    invariants (presence + uniqueness + dotted namespace) so a refactor
    that drops or duplicates a constant fails loudly.
    """

    code: ClassVar[str]
    event_name: ClassVar[str]


class PrincipalDisabledError(PrincipalHydrationError):  # noqa: N818 -- name matches the §13.2 audit-event vocabulary; the brainstorm pins this class name verbatim (``03-technical-implementation.md`` § "Error management" table). Renaming would obscure the canon link and break the runbook (T9) audit-event mapping.
    """The principal row exists but ``disabled_at IS NOT NULL``.

    Triggered by E8 / S8 --- a previously-active principal had
    ``disabled_at`` set by an admin (compromise response, offboarding,
    etc.). The JWT is still valid (Auth0 doesn't know); the substrate
    refuses to act on their behalf. T6 maps this to **HTTP 403** (per
    §4.7's "gate write at the action" framing applied to identity:
    401 says "your token is bad"; 403 says "your identity is recognized
    but the action is refused"). Per the brainstorm, ``set_config`` is
    **never** called on a disabled-principal request --- the early
    return prevents GUC observability in the rolled-back transaction.
    """

    code: ClassVar[str] = "principal_disabled"
    event_name: ClassVar[str] = "principal.access_attempted_while_disabled"


class PrincipalEmailCollision(PrincipalHydrationError):  # noqa: N818 -- name matches the §13.2 audit-event vocabulary; see PrincipalDisabledError for rationale.
    """Email-fallback ``UPDATE`` matched zero rows AND the subsequent
    ``INSERT`` raised a unique-violation on a different email-keyed row.

    Triggered by E5 --- principal A is provisioned with
    ``auth0_sub = 'auth0|a'``, ``email = 'shared@example.com'``. A new
    user signs up at Auth0 with the same email but a different ``sub``;
    the email-fallback ``WHERE auth0_sub IS NULL`` predicate excludes A;
    the INSERT then collides on the email-uniqueness constraint (whose
    precise shape is owned by the schema feature). T6 maps this to
    **HTTP 409 Conflict**. The user sees a useful error; an operator
    investigates manually.
    """

    code: ClassVar[str] = "email_collision"
    event_name: ClassVar[str] = "principal.email_collision_on_first_auth"


class PoolExhausted(PrincipalHydrationError):  # noqa: N818 -- name matches the §13.2 audit-event vocabulary; see PrincipalDisabledError for rationale.
    """``asyncpg.Pool.acquire()`` exceeded the configured timeout.

    Triggered by E9 / S13 --- the PgBouncer transaction-mode pool is at
    ``default_pool_size`` and new requests stall. T6 maps this to
    **HTTP 503** with ``Retry-After: 5``; the structured log uses
    ``event="principal.pool_acquire_timeout"`` (the canonical
    :attr:`event_name` here) so operational dashboards distinguish pool
    exhaustion from upstream DB outage. Per the brainstorm § Fault
    lines, 503-with-Retry-After is the *signal* the operator tunes
    against, not a fix.
    """

    code: ClassVar[str] = "pool_exhausted"
    event_name: ClassVar[str] = "principal.pool_acquire_timeout"


class PrincipalLookupTimeout(PrincipalHydrationError):  # noqa: N818 -- name matches the §13.2 audit-event vocabulary; see PrincipalDisabledError for rationale.
    """The principal-resolution query exceeded ``statement_timeout``.

    Triggered by E19 --- a transient DB latency spike makes the
    ``SELECT ... WHERE auth0_sub = $1`` slow; ``SET LOCAL
    statement_timeout`` (5000ms; T6) fires. T6 maps this to **HTTP 503**.
    Distinguishable from :class:`PoolExhausted` via the
    :attr:`event_name`; both use 503 but for different operator actions
    (pool sizing vs. query optimization).
    """

    code: ClassVar[str] = "lookup_timeout"
    event_name: ClassVar[str] = "principal.lookup_timeout"


class GUCSetFailed(PrincipalHydrationError):  # noqa: N818 -- name matches the §13.2 audit-event vocabulary; see PrincipalDisabledError for rationale.
    """``SELECT set_config(name, value, true)`` itself failed.

    Triggered by E10 --- hypothetical, since the GUC names
    (``app.current_principal_id``, ``app.current_principal_visible``)
    are constants in the codebase, not user-controllable. The handler
    exists to make the failure mode explicit: the request transaction
    rolls back; the connection returns to the pool; T6 maps to
    **HTTP 500** with ``code="guc_set_failed"``. Per the brainstorm §
    "Error management", this surface pages --- the substrate's only
    legal GUC injection form (PC1) failing is a substrate-integrity
    alarm.
    """

    code: ClassVar[str] = "guc_set_failed"
    event_name: ClassVar[str] = "principal.guc_set_failed"


class PrincipalIntegrityError(PrincipalHydrationError):  # noqa: N818 -- name matches the §13.2 audit-event vocabulary; see PrincipalDisabledError for rationale.
    """The principal-resolution query violated a uniqueness invariant
    that the partial UNIQUE on ``auth0_sub`` should have prevented.

    Triggered by E13 --- two rows in ``principals`` share an
    ``auth0_sub`` (e.g., the partial UNIQUE was dropped and recreated
    incorrectly during a migration). aiosql's ``expected_rows=1`` mode
    raises; T6 maps to **HTTP 500** with ``code="principal_integrity"``.
    Per the brainstorm § "Error management", this surface pages --- the
    partial-UNIQUE invariant on ``auth0_sub`` failing is a substrate-
    integrity alarm.
    """

    code: ClassVar[str] = "principal_integrity"
    event_name: ClassVar[str] = "principal.uniqueness_violation"


class PrincipalKindUnknown(PrincipalHydrationError):  # noqa: N818 -- name matches the §13.2 audit-event vocabulary; see PrincipalDisabledError for rationale.
    """``VerifiedClaims.kind`` is neither ``"human"`` nor ``"agent"``.

    Defense-in-depth for E7 --- the auth feature's
    :class:`~skaldos.auth.models.RawClaims` ``mode="after"`` validator
    rejects mutually-exclusive discriminators upstream, so this failure
    is structurally unreachable in normal operation. The handler exists
    so a future regression in the validator (e.g. someone adds a third
    ``kind`` literal without updating the resolver) surfaces as
    **HTTP 500** with ``code="principal_kind_unknown"`` rather than as
    an unhandled ``ValueError`` leaking to the caller. Per the
    brainstorm § "Error management", this surface pages.
    """

    code: ClassVar[str] = "principal_kind_unknown"
    event_name: ClassVar[str] = "principal.kind_unknown"
