"""``skaldos`` Python package — production-side modules under
``services/api/skaldos/``.

Slice 0 plants only what the active T-tasks need (currently the ``kms``
subpackage from integration-test-framework T4 and the ``sandbox``
subpackage from T5). Later slices populate the rest (auth, db, harness,
etc. in subsequent slices).
"""
