"""GCP Cloud KMS adapter for envelope-encryption DEKs."""

from __future__ import annotations

import base64
import os
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, cast

import httpx

from .protocol import KeyDestroyed, KMSClient

_CLOUD_KMS_API_BASE = "https://cloudkms.googleapis.com/v1"
_METADATA_TOKEN_URL = (
    "http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token"
)
_DEK_BYTES = 32


class GCPKMSUnavailableError(RuntimeError):
    """Raised when GCP KMS or ADC token acquisition is unavailable."""


@dataclass(frozen=True)
class _MetadataToken:
    access_token: str


class GCPKMSClient(KMSClient):
    """Production KMS adapter using GCP Cloud KMS REST endpoints.

    The adapter keeps the protocol byte-oriented. Base64 is used only at the
    REST boundary. It does not log key names, wrapped DEKs, plaintext DEKs, or
    KMS response bodies.
    """

    def __init__(
        self,
        *,
        api_base_url: str = _CLOUD_KMS_API_BASE,
        http_client: httpx.Client | None = None,
        token_provider: Callable[[], str] | None = None,
    ) -> None:
        self._api_base_url = api_base_url.rstrip("/")
        self._http_client = http_client or httpx.Client(timeout=10.0)
        self._token_provider = token_provider or self._metadata_access_token

    def generate_dek(self, key_name: str) -> tuple[bytes, bytes]:
        """Generate a local AES-256 DEK and wrap it with Cloud KMS."""

        plaintext_dek = os.urandom(_DEK_BYTES)
        return plaintext_dek, self.encrypt_dek(key_name, plaintext_dek)

    def encrypt_dek(self, key_name: str, plaintext_dek: bytes) -> bytes:
        """Wrap a plaintext DEK with the configured Cloud KMS key."""

        payload = {"plaintext": base64.b64encode(plaintext_dek).decode("ascii")}
        response = self._post(key_name, "encrypt", payload)
        ciphertext = response.get("ciphertext")
        if not isinstance(ciphertext, str) or not ciphertext:
            raise GCPKMSUnavailableError("kms_encrypt_response_invalid")
        try:
            return base64.b64decode(ciphertext, validate=True)
        except ValueError as error:
            raise GCPKMSUnavailableError("kms_encrypt_response_invalid") from error

    def decrypt_dek(self, key_name: str, wrapped_dek: bytes) -> bytes:
        """Unwrap a DEK ciphertext with the configured Cloud KMS key."""

        payload = {"ciphertext": base64.b64encode(wrapped_dek).decode("ascii")}
        response = self._post(key_name, "decrypt", payload)
        plaintext = response.get("plaintext")
        if not isinstance(plaintext, str) or not plaintext:
            raise GCPKMSUnavailableError("kms_decrypt_response_invalid")
        try:
            return base64.b64decode(plaintext, validate=True)
        except ValueError as error:
            raise ValueError("kms_decrypt_response_invalid") from error

    def destroy_dek(self, key_name: str) -> None:
        """Fail closed: route credential runtime must not destroy KMS keys."""

        del key_name
        raise PermissionError("kms_destroy_not_supported_by_runtime_adapter")

    def _post(self, key_name: str, method: str, payload: dict[str, str]) -> dict[str, Any]:
        try:
            token = self._token_provider()
            response = self._http_client.post(
                f"{self._api_base_url}/{key_name}:{method}",
                headers={"Authorization": f"Bearer {token}"},
                json=payload,
            )
        except httpx.HTTPError as error:
            raise GCPKMSUnavailableError("kms_http_unavailable") from error

        if response.status_code >= 400:
            if _response_mentions_destroyed_key(response):
                raise KeyDestroyed("kms_key_destroyed")
            if method == "decrypt":
                raise ValueError("kms_decrypt_failed")
            raise GCPKMSUnavailableError("kms_request_failed")
        try:
            body = response.json()
        except ValueError as error:
            raise GCPKMSUnavailableError("kms_response_invalid") from error
        if not isinstance(body, dict):
            raise GCPKMSUnavailableError("kms_response_invalid")
        return cast("dict[str, Any]", body)

    def _metadata_access_token(self) -> str:
        configured = os.environ.get("GOOGLE_OAUTH_ACCESS_TOKEN")
        if configured:
            return configured
        try:
            response = self._http_client.get(
                _METADATA_TOKEN_URL,
                headers={"Metadata-Flavor": "Google"},
            )
            response.raise_for_status()
            token = _MetadataToken(access_token=response.json()["access_token"])
        except (httpx.HTTPError, KeyError, TypeError, ValueError) as error:
            raise GCPKMSUnavailableError("kms_adc_token_unavailable") from error
        if not token.access_token:
            raise GCPKMSUnavailableError("kms_adc_token_unavailable")
        return token.access_token


def _response_mentions_destroyed_key(response: httpx.Response) -> bool:
    try:
        text = response.text
    except Exception:
        return False
    lowered = text.lower()
    return "destroy" in lowered or "disabled" in lowered
