"""KMS chokepoint — envelope encryption + per-subject DEKs (ADR 11, M11, §13.6).

Surface:

- :class:`KMSClient` — runtime-checkable Protocol every KMS adapter
  (production + test fake) implements. Defines the minimum envelope-
  encryption surface (``generate_dek``, ``encrypt_dek``, ``decrypt_dek``,
  ``destroy_dek``).
- :class:`GCPKMSClient` — production adapter against GCP Cloud KMS.
- :exc:`KeyDestroyed` — the canonical exception every adapter raises
  when a caller hits a key whose DEK has been crypto-shredded
  (§13.6 / M11). The fake (in tests) and production (Slice 5) raise the
  *same* class so consumer code is hermetic to the KMS backend.

The integration-test fake (:class:`FakeKMSClient` at
``tests/integration/_framework/fake_kms.py``) lives in the test tree —
not here — because it is test-only by construction. It implements this
same Protocol; a unit test
(``tests/unit/test_kms_protocol.py``) asserts both implementations
satisfy ``runtime_checkable(KMSClient)``.

References: ADR 11 (KMS choice — GCP Cloud KMS), M11 (pgsodium-free
crypto plan; KMS-managed envelope encryption), §13.6 (crypto-shredding
via per-subject DEKs), §13.7 (erasure as a pipeline). Adjacent dev-stack
fake: ``docker/fake-kms/app.py``.
"""

from __future__ import annotations

from .gcp import GCPKMSClient
from .protocol import KeyDestroyed, KMSClient

__all__ = [
    "GCPKMSClient",
    "KMSClient",
    "KeyDestroyed",
]
