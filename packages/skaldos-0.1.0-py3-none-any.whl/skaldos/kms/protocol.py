"""``KMSClient`` Protocol — minimum envelope-encryption surface.

Per
``docs/slices/slice-0-foundations/integration-test-framework/05-task-list.md``
T4 and ADR 11 / M11: every KMS adapter (production
:class:`~skaldos.kms.gcp.GCPKMSClient`, test
:class:`tests.integration._framework.fake_kms.FakeKMSClient`) implements
this Protocol. Consumer code (Slice 5+ envelope-encryption call sites)
holds a ``KMSClient`` reference and never imports a concrete
implementation — the abstraction is the chokepoint that lets the test
fake and the production client be swapped without ``if testing:``
branches (AP5).

Why a Protocol (not an ABC)
---------------------------

- **Structural** — pyright catches missing methods on every adapter
  without forcing inheritance. New adapters (Vault, AWS KMS) drop in
  without touching this file.
- **``runtime_checkable``** — lets a unit test
  (``tests/unit/test_kms_protocol.py``) assert
  ``isinstance(client, KMSClient)`` for both adapters at module import
  time. The runtime-check is a coarse sanity gate (it confirms method
  *names* exist; pyright/static checking confirms *signatures*); both
  layers run on every PR.
- **Slice 5 typecheck breaks fake-first** — adding a new method to the
  Protocol will fail the typecheck on whichever adapter doesn't
  implement it next. With pyright in strict mode (see ``pyproject.toml``)
  the violation surfaces at PR-CI time, not at deploy time.

Envelope-encryption surface
---------------------------

Per §13.6 / M11 the four operations the substrate needs are:

1. **``generate_dek``** — ask KMS for a fresh DEK and its KEK-wrapped
   form. The plaintext DEK is held in memory only long enough to
   encrypt the row; the wrapped DEK lives in
   ``subject_keys.wrapped_dek`` (§13.6).
2. **``encrypt_dek``** — KEK-wrap a plaintext DEK. Useful when the DEK
   was generated app-side (e.g. by ``os.urandom``) and needs to be
   stored alongside the row.
3. **``decrypt_dek``** — KEK-unwrap a stored wrapped DEK so the row
   can be decrypted. Per-row decrypt path: read wrapped DEK from
   ``subject_keys`` → unwrap via this call → decrypt the ciphertext
   in app memory.
4. **``destroy_dek``** — destroy the (KEK-wrapped) DEK so subsequent
   ``decrypt_dek`` calls fail. **GDPR erasure = O(1) per subject**
   (§13.6). The fake removes the wrap from its in-memory map; the
   production adapter calls ``CryptoKeyVersions.destroy`` on the
   subject's KEK version (Slice 5 wires this).

This is the *minimum* surface T4 ships. The §13.7 "erasure is a
pipeline" rule (re-embed search indexes; invalidate caches; rebuild
materialized views) is enforced in *callers* of this Protocol, not in
the Protocol itself — it's a policy concern, not a KMS concern. The
Protocol's job is the cryptographic primitive; the policy chokepoint
sits one layer higher.

Why bytes (not str)
-------------------

DEKs and wrapped DEKs are *cryptographic byte strings*; encoding them
as base64 ``str`` in the Protocol surface would invite "is this
base64 / hex / utf-8?" ambiguity at every call site (E10). The
adapters serialize to / from base64 at their boundaries (the GCP
client speaks base64 over the REST surface; the fake stores ``bytes``
directly); consumers see ``bytes`` end-to-end. Same discipline the
dev-stack ``docker/fake-kms/app.py`` follows.

References: ADR 11, M11, §13.6, §13.7, MP3 (honest naming), MP6
(humans + agents call the same Protocol), AP5 (no test-only bypass).
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable


class KeyDestroyed(Exception):  # noqa: N818 — name matches the §13.6 / M11 vocabulary ("destroy the DEK"); the brainstorm pins this exception class by name (T4 / E8). Renaming to `KeyDestroyedError` would obscure the canon link.
    """Raised when a caller asks the KMS to use a DEK that has been destroyed.

    The fake (test-side) and the GCP adapter (Slice 5) raise this *same*
    exception class so consumer code can catch a single type — this is
    the contract that lets a Slice 5 erasure-pipeline test assert
    "destroyed key surfaces as :class:`KeyDestroyed` regardless of
    backend."

    Per §13.6: GDPR erasure is destroying the DEK; downstream code must
    treat this exception as the signal to skip / fail-closed, not as a
    transient error to retry. Re-encrypting against a destroyed DEK is
    forbidden by construction (the KEK version is gone in production;
    the fake's map entry is gone in tests).
    """


@runtime_checkable
class KMSClient(Protocol):
    """Envelope-encryption client; implemented by every KMS adapter.

    Method docstrings describe the *contract* every adapter must honor.
    Concrete adapters (``GCPKMSClient`` in prod, ``FakeKMSClient`` in
    tests) have their own docstrings with adapter-specific notes.

    The four-method surface is the minimum required by §13.6 / M11
    envelope encryption. Adding a method here is a typecheck failure
    on every adapter that doesn't implement it — that's the desired
    behavior (drift is loud, not silent).
    """

    def generate_dek(self, key_name: str) -> tuple[bytes, bytes]:
        """Generate a fresh DEK; return ``(plaintext_dek, wrapped_dek)``.

        ``key_name`` identifies the KEK that should wrap this DEK
        (in production, the GCP key resource path
        ``projects/<p>/locations/<l>/keyRings/<r>/cryptoKeys/<k>``;
        in tests, the same string for parity with the dev-stack fake at
        ``docker/fake-kms/app.py``).

        The plaintext DEK is the raw symmetric key bytes; callers
        encrypt their plaintext with it (e.g. AES-256-GCM via
        ``cryptography.hazmat.primitives.ciphers.aead``) and immediately
        zero / drop the plaintext DEK. Only the wrapped form is
        persisted.

        Raises :class:`KeyDestroyed` if the underlying KEK version has
        been destroyed (e.g. as part of a prior crypto-shredding pass on
        the *org-level* KEK; rare, but the Protocol surfaces the failure
        rather than silently regenerating).
        """
        ...

    def encrypt_dek(self, key_name: str, plaintext_dek: bytes) -> bytes:
        """KEK-wrap a plaintext DEK; return the wrapped (ciphertext) DEK.

        Use when the DEK is generated app-side (e.g. via ``os.urandom``)
        rather than via :meth:`generate_dek`. Either path produces a
        wrapped DEK with the same downstream contract:
        :meth:`decrypt_dek` round-trips it back to plaintext.

        Adapters MUST NOT mutate ``plaintext_dek``; callers are
        responsible for zeroing it post-encrypt.

        Raises :class:`KeyDestroyed` if the KEK is destroyed.
        """
        ...

    def decrypt_dek(self, key_name: str, wrapped_dek: bytes) -> bytes:
        """KEK-unwrap a wrapped DEK; return the plaintext DEK bytes.

        Per-row decrypt path: read wrapped DEK from ``subject_keys``,
        call this to unwrap, decrypt the row's ciphertext, drop the
        plaintext DEK.

        Raises :class:`KeyDestroyed` if the KEK has been destroyed
        (the post-erasure path; the wrapped DEK is opaque ciphertext
        that cannot be recovered).

        Raises :class:`ValueError` (or a subclass — adapters may
        narrow) if the wrapped DEK is malformed (e.g. wrong-key
        ciphertext, truncated bytes). The exact subclass is
        adapter-defined, but the *type* must be a ``ValueError`` so
        consumer code has one shape to catch.
        """
        ...

    def destroy_dek(self, key_name: str) -> None:
        """Destroy the wrap for ``key_name``; subsequent operations fail.

        After this call, :meth:`encrypt_dek` and :meth:`decrypt_dek`
        for the same ``key_name`` raise :class:`KeyDestroyed`. This is
        the **GDPR erasure primitive** per §13.6: O(1) per subject.

        Idempotent: calling :meth:`destroy_dek` twice on the same key
        is not an error — the post-condition is "destroyed" either way.
        Production adapters MUST honor this idempotence (the GCP REST
        surface returns 200 on a re-destroy of an already-destroyed
        version; the fake mirrors that).

        Calling :meth:`destroy_dek` on an unknown ``key_name`` is also
        not an error — the post-condition is the same. Callers that
        want to assert prior existence do so via
        :meth:`encrypt_dek` / :meth:`decrypt_dek` round-trip in a test.
        """
        ...
