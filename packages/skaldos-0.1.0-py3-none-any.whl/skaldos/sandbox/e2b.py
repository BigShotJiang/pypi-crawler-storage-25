"""Direct E2B sandbox adapter and control-plane lifecycle helpers."""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import shlex
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any, cast
from urllib.parse import urlparse

import httpx

from .protocol import ExecResult, Sandbox, SandboxEvent, SandboxEventKind, WebhookCallback

E2B_API_BASE_URL = "https://api.e2b.app"
E2B_ALL_TRAFFIC = "0.0.0.0/0"
E2B_WEBHOOK_SIGNATURE_HEADER = "e2b-signature"
E2B_WEBHOOK_SIGNATURE_VERSION_HEADER = "e2b-signature-version"
E2B_WEBHOOK_SIGNATURE_VERSION = "v1"
DEFAULT_NON_PROD_TEMPLATE_ID = "base"
E2B_COMMAND_READY_RETRY_STATUSES = frozenset({502, 503})


class E2BConfigError(ValueError):
    """Raised when E2B runtime config is missing or unsafe."""


class E2BProviderError(RuntimeError):
    """Raised when E2B rejects a lifecycle or command request."""


@dataclass(frozen=True, slots=True)
class E2BConfig:
    """Runtime config for the E2B direct-HTTP adapter."""

    api_key: str
    webhook_signing_secret: str
    template_id: str
    api_base_url: str = E2B_API_BASE_URL
    sandbox_timeout_seconds: int = 900
    skaldos_env: str = "development"

    @classmethod
    def from_env(cls, environ: Mapping[str, str] | None = None) -> E2BConfig:
        env = environ or os.environ
        skaldos_env = env.get("SKALDOS_ENV", "development")
        api_key = _required_secret(env, "E2B_API_KEY")
        webhook_signing_secret = _required_secret(env, "E2B_WEBHOOK_SIGNING_SECRET")
        template_id = env.get("E2B_TEMPLATE_ID") or env.get("E2B_TEMPLATE_NAME")
        if not template_id:
            if skaldos_env in {"production", "staging"}:
                raise E2BConfigError("e2b_template_required")
            template_id = DEFAULT_NON_PROD_TEMPLATE_ID
        timeout_raw = env.get("E2B_SANDBOX_TIMEOUT_SECONDS", "900")
        try:
            timeout = int(timeout_raw)
        except ValueError as exc:
            raise E2BConfigError("e2b_timeout_invalid") from exc
        if timeout <= 0 or timeout > 3600:
            raise E2BConfigError("e2b_timeout_invalid")
        return cls(
            api_key=api_key,
            webhook_signing_secret=webhook_signing_secret,
            template_id=template_id,
            api_base_url=env.get("E2B_API_BASE_URL", E2B_API_BASE_URL).rstrip("/"),
            sandbox_timeout_seconds=timeout,
            skaldos_env=skaldos_env,
        )


@dataclass(frozen=True, slots=True)
class E2BSandboxHandle:
    """Opaque provider facts retained only inside the adapter instance."""

    sandbox_id: str
    envd_access_token: str | None
    traffic_access_token: str | None = None


class E2BHTTPTransport:
    """Small synchronous HTTP boundary for E2B sandbox operations."""

    def __init__(
        self,
        *,
        api_key: str,
        api_base_url: str = E2B_API_BASE_URL,
        client: httpx.Client | None = None,
    ) -> None:
        if not api_key.strip():
            raise E2BConfigError("e2b_api_key_required")
        self._api_key = api_key
        self._api_base_url = api_base_url.rstrip("/")
        self._client = client or httpx.Client(timeout=30.0)
        self._owns_client = client is None

    def create_sandbox(
        self,
        *,
        template_id: str,
        allowlist: Sequence[str],
        metadata: Mapping[str, str],
        timeout_seconds: int,
    ) -> E2BSandboxHandle:
        response = self._client.post(
            f"{self._api_base_url}/sandboxes",
            headers=self._api_headers(),
            json={
                "templateID": template_id,
                "timeout": timeout_seconds,
                "secure": True,
                "allow_internet_access": True,
                "network": {
                    "allowPublicTraffic": False,
                    "allowOut": list(_normalize_allowlist(allowlist)),
                    "denyOut": [E2B_ALL_TRAFFIC],
                },
                "metadata": dict(metadata),
            },
        )
        if response.status_code != 201:
            raise E2BProviderError("e2b_sandbox_create_failed")
        body = _json_object(response)
        sandbox_id = str(body.get("sandboxID") or "")
        if not sandbox_id:
            raise E2BProviderError("e2b_sandbox_id_missing")
        envd_access_token = body.get("envdAccessToken")
        traffic_access_token = body.get("trafficAccessToken")
        return E2BSandboxHandle(
            sandbox_id=sandbox_id,
            envd_access_token=str(envd_access_token) if envd_access_token else None,
            traffic_access_token=str(traffic_access_token) if traffic_access_token else None,
        )

    def run_command(
        self,
        *,
        handle: E2BSandboxHandle,
        command: Sequence[str],
        env: Mapping[str, str] | None = None,
        timeout_seconds: int = 60,
    ) -> ExecResult:
        if not command:
            raise E2BProviderError("e2b_command_required")
        try:
            sandbox = _connect_sdk_sandbox(sandbox_id=handle.sandbox_id, api_key=self._api_key)
            result = sandbox.commands.run(
                shlex.join(command),
                envs=dict(env or {}),
                timeout=timeout_seconds,
            )
        except _sdk_command_exit_exceptions() as exc:
            result = exc
        except Exception as exc:
            raise E2BProviderError("e2b_command_run_failed") from exc
        return ExecResult(
            stdout=str(getattr(result, "stdout", "")),
            stderr=str(getattr(result, "stderr", "")),
            exit_code=int(getattr(result, "exit_code", 0)),
        )

    def delete_sandbox(self, *, sandbox_id: str) -> None:
        response = self._client.delete(
            f"{self._api_base_url}/sandboxes/{sandbox_id}",
            headers=self._api_headers(),
        )
        if response.status_code in {204, 404}:
            return
        raise E2BProviderError("e2b_sandbox_delete_failed")

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def _api_headers(self) -> dict[str, str]:
        return {
            "Content-Type": "application/json",
            "X-API-Key": self._api_key,
        }


class E2BSandbox(Sandbox):
    """Production E2B sandbox adapter preserving the provider-neutral Protocol."""

    def __init__(
        self,
        *,
        config: E2BConfig | None = None,
        transport: E2BHTTPTransport | None = None,
        metadata: Mapping[str, str] | None = None,
    ) -> None:
        self._config = config
        self._transport = transport
        self._metadata = dict(metadata or {})
        self._handle: E2BSandboxHandle | None = None
        self._callbacks: list[WebhookCallback] = []
        self._sandbox_id: str | None = None
        self._allowlist: tuple[str, ...] = ()

    def start(self, *, allowlist: Sequence[str], sandbox_id: str) -> None:
        if self._handle is not None:
            raise E2BProviderError("e2b_sandbox_already_started")
        config = self._resolved_config()
        metadata = {
            **self._metadata,
            "skaldos_sandbox_id": sandbox_id,
            "skaldos_adapter": "skaldos-api",
        }
        handle = self._resolved_transport(config).create_sandbox(
            template_id=config.template_id,
            allowlist=allowlist,
            metadata=metadata,
            timeout_seconds=config.sandbox_timeout_seconds,
        )
        self._handle = handle
        self._sandbox_id = sandbox_id
        self._allowlist = tuple(_normalize_allowlist(allowlist))
        self._fire_webhook(
            SandboxEvent(
                kind="started",
                sandbox_id=sandbox_id,
                payload={
                    "provider": "e2b",
                    "provider_handle": handle.sandbox_id,
                    "allowlist_size": str(len(self._allowlist)),
                },
            )
        )

    def run(
        self,
        command: Sequence[str],
        *,
        host: str | None = None,
        env: Mapping[str, str] | None = None,
        timeout_seconds: int = 60,
    ) -> ExecResult:
        if host is not None and host not in self._allowlist:
            from .protocol import EgressViolation

            raise EgressViolation(host, self._allowlist)
        handle = self._required_handle()
        try:
            return self._resolved_transport(self._resolved_config()).run_command(
                handle=handle,
                command=command,
                env=env,
                timeout_seconds=timeout_seconds,
            )
        except E2BProviderError:
            self._fire_webhook(
                SandboxEvent(
                    kind="errored",
                    sandbox_id=self._sandbox_id or handle.sandbox_id,
                    payload={"provider": "e2b", "error_class": "e2b_provider_error"},
                )
            )
            raise

    def end(self) -> None:
        handle = self._handle
        if handle is None:
            return
        self._resolved_transport(self._resolved_config()).delete_sandbox(
            sandbox_id=handle.sandbox_id,
        )
        self._handle = None
        self._fire_webhook(
            SandboxEvent(
                kind="ended",
                sandbox_id=self._sandbox_id or handle.sandbox_id,
                payload={"provider": "e2b", "clean_exit": "true"},
            )
        )

    def attach_webhook(self, callback: WebhookCallback) -> None:
        self._callbacks.append(callback)

    @property
    def provider_handle(self) -> str | None:
        return self._handle.sandbox_id if self._handle is not None else None

    def _resolved_config(self) -> E2BConfig:
        if self._config is None:
            self._config = E2BConfig.from_env()  # pyright: ignore[reportAttributeAccessIssue]
        return self._config

    def _resolved_transport(self, config: E2BConfig) -> E2BHTTPTransport:
        if self._transport is None:
            self._transport = E2BHTTPTransport(  # pyright: ignore[reportAttributeAccessIssue]
                api_key=config.api_key,
                api_base_url=config.api_base_url,
            )
        return self._transport

    def _required_handle(self) -> E2BSandboxHandle:
        if self._handle is None:
            raise E2BProviderError("e2b_sandbox_not_started")
        return self._handle

    def _fire_webhook(self, event: SandboxEvent) -> None:
        callbacks = tuple(self._callbacks)
        for callback in callbacks:
            callback(event)


class E2BSandboxControlPlane:
    """Async control plane used by cancellation from persisted provider handles."""

    def __init__(
        self,
        *,
        api_key: str,
        api_base_url: str = E2B_API_BASE_URL,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        if not api_key.strip():
            raise E2BConfigError("e2b_api_key_required")
        self._api_key = api_key
        self._api_base_url = api_base_url.rstrip("/")
        self._client = client or httpx.AsyncClient(timeout=30.0)

    @classmethod
    def from_env(cls, environ: Mapping[str, str] | None = None) -> E2BSandboxControlPlane:
        config = E2BConfig.from_env(environ)
        return cls(api_key=config.api_key, api_base_url=config.api_base_url)

    async def kill(
        self,
        *,
        provider: str,
        provider_handle: str,
        reason: str,
    ) -> None:
        from skaldos.agents.errors import AgentSandboxLifecycleError

        _ = reason
        if provider != "e2b":
            raise AgentSandboxLifecycleError("agent_sandbox_provider_unsupported")
        if not provider_handle.strip():
            raise AgentSandboxLifecycleError("agent_sandbox_provider_handle_required")
        try:
            response = await self._client.delete(
                f"{self._api_base_url}/sandboxes/{provider_handle}",
                headers={"X-API-Key": self._api_key},
            )
        except httpx.HTTPError as exc:
            raise AgentSandboxLifecycleError("agent_sandbox_kill_failed") from exc
        if response.status_code in {204, 404}:
            return
        raise AgentSandboxLifecycleError("agent_sandbox_kill_failed")


def verify_e2b_webhook_signature(
    *,
    signing_secret: str,
    raw_body: bytes,
    signature: str,
    signature_version: str | None = E2B_WEBHOOK_SIGNATURE_VERSION,
) -> None:
    from skaldos.agents.errors import AgentSandboxWebhookAuthError

    if not signing_secret.strip():
        raise AgentSandboxWebhookAuthError("agent_sandbox_webhook_signing_secret_required")
    if signature_version not in {None, "", E2B_WEBHOOK_SIGNATURE_VERSION}:
        raise AgentSandboxWebhookAuthError("agent_sandbox_webhook_signature_version_invalid")
    expected = e2b_webhook_signature(signing_secret=signing_secret, raw_body=raw_body)
    if not hmac.compare_digest(signature, expected):
        raise AgentSandboxWebhookAuthError("agent_sandbox_webhook_signature_invalid")


def e2b_webhook_signature(*, signing_secret: str, raw_body: bytes) -> str:
    digest = hashlib.sha256(signing_secret.encode("utf-8") + raw_body).digest()
    return base64.b64encode(digest).decode("ascii").rstrip("=")


def map_e2b_lifecycle_event(event_type: str, event_label: str | None = None) -> SandboxEventKind:
    from skaldos.agents.errors import AgentSandboxLifecycleError

    if event_type in {"sandbox.lifecycle.created", "sandbox.lifecycle.resumed"}:
        return "started"
    if event_type == "sandbox.lifecycle.killed":
        return "ended" if event_label in {None, "", "kill"} else "errored"
    if event_type == "sandbox.lifecycle.paused":
        return "ended"
    if event_type in {"sandbox.lifecycle.updated", "sandbox.lifecycle.checkpointed"}:
        return "started"
    raise AgentSandboxLifecycleError("agent_sandbox_lifecycle_unknown")


def _required_secret(env: Mapping[str, str], name: str) -> str:
    value = env.get(name)
    if value is None or not value.strip():
        raise E2BConfigError(f"{name.lower()}_required")
    return value


def _normalize_allowlist(allowlist: Sequence[str]) -> tuple[str, ...]:
    normalized = tuple(
        dict.fromkeys(_normalize_allowlist_item(item) for item in allowlist if item.strip())
    )
    if not normalized:
        raise E2BConfigError("e2b_allowlist_required")
    return normalized


def _normalize_allowlist_item(item: str) -> str:
    candidate = item.strip().lower()
    parsed = urlparse(candidate)
    if parsed.scheme and parsed.hostname:
        return parsed.hostname
    return candidate


def _connect_sdk_sandbox(*, sandbox_id: str, api_key: str) -> Any:
    try:
        from e2b import Sandbox  # pyright: ignore[reportMissingTypeStubs]
    except Exception as exc:
        raise E2BProviderError("e2b_sdk_unavailable") from exc
    return Sandbox.connect(sandbox_id, api_key=api_key)


def _sdk_command_exit_exceptions() -> tuple[type[Exception], ...]:
    try:
        from e2b import CommandExitException  # pyright: ignore[reportMissingTypeStubs]
    except Exception:
        return ()
    return (CommandExitException,)


def _json_object(response: httpx.Response) -> Mapping[str, Any]:
    try:
        body = response.json()
    except json.JSONDecodeError as exc:
        raise E2BProviderError("e2b_response_json_invalid") from exc
    if not isinstance(body, dict):
        raise E2BProviderError("e2b_response_json_invalid")
    return cast(Mapping[str, Any], body)


__all__ = [
    "E2B_ALL_TRAFFIC",
    "E2B_WEBHOOK_SIGNATURE_HEADER",
    "E2B_WEBHOOK_SIGNATURE_VERSION_HEADER",
    "E2BConfig",
    "E2BConfigError",
    "E2BHTTPTransport",
    "E2BProviderError",
    "E2BSandbox",
    "E2BSandboxControlPlane",
    "e2b_webhook_signature",
    "map_e2b_lifecycle_event",
    "verify_e2b_webhook_signature",
]
