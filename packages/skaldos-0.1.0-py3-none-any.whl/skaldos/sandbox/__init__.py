"""Sandbox chokepoint --- agent-runtime egress / lifecycle (§5.12, §5.13, §5.15, ADR 20).

Surface:

- :class:`Sandbox` --- runtime-checkable Protocol every sandbox provider
  (production + test mock) implements. Defines the minimum runtime
  surface for Slice 7's first agent-runtime call sites
  (``start``, ``run``, ``end``, ``attach_webhook``).
- :class:`E2BSandbox` --- production adapter against E2B (ADR 20).
  **Skeleton only** in Slice 0 (every method raises
  ``NotImplementedError("wired in Slice 7")``); body lands in Slice 7
  per the scaffold-now-wire-later pattern in CLAUDE.md.
- :exc:`EgressViolation` --- the canonical exception every adapter
  raises when a sandbox call attempts egress to an off-allowlist host
  (§5.13). The mock (in tests) and production (Slice 7) raise the
  *same* class so consumer code is hermetic to the sandbox backend.
- :class:`ExecResult`, :class:`SandboxEvent`, :data:`SandboxEventKind`,
  :class:`WebhookCallback` --- shared value types / aliases. The
  webhook payload shape (§5.15) is identical across mock and production
  --- E11 mitigation: "mock simulates success when production would
  fail" is foreclosed structurally.

The integration-test mock
(:class:`MockSandbox` at
``tests/integration/_framework/sandbox_mock.py``) lives in the test
tree --- not here --- because it is test-only by construction. It
implements this same Protocol; a unit test
(``tests/unit/test_sandbox_protocol.py``) asserts both implementations
satisfy ``runtime_checkable(Sandbox)`` and that signatures match.

References: ADR 20 (sandbox provider --- E2B with portability stance),
§5.12 (Sandbox abstraction), §5.13 (allowlist-only egress), §5.15
(lifecycle webhooks). Adjacent test mock:
``tests/integration/_framework/sandbox_mock.py``.
"""

from __future__ import annotations

from .e2b import E2BSandbox
from .protocol import (
    EgressViolation,
    ExecResult,
    Sandbox,
    SandboxEvent,
    SandboxEventKind,
    WebhookCallback,
)

__all__ = [
    "E2BSandbox",
    "EgressViolation",
    "ExecResult",
    "Sandbox",
    "SandboxEvent",
    "SandboxEventKind",
    "WebhookCallback",
]
