"""``Sandbox`` Protocol — minimum runtime surface (T5).

Per
``docs/slices/slice-0-foundations/integration-test-framework/05-task-list.md``
T5 and §5.12 / ADR 20: every sandbox provider (production
:class:`~skaldos.sandbox.e2b.E2BSandbox` against E2B; test
:class:`tests.integration._framework.sandbox_mock.MockSandbox`)
implements this Protocol. Consumer code (Slice 7+ agent-runtime call
sites) holds a ``Sandbox`` reference and never imports a concrete
provider --- the abstraction is the chokepoint that lets the in-process
mock and the production client be swapped without ``if testing:``
branches (AP5; mirror of the KMSClient pattern T4 landed).

Why a Protocol (not an ABC)
---------------------------

- **Structural** --- pyright (strict, see ``pyproject.toml``) catches
  missing methods on every adapter without forcing inheritance. New
  adapters (Modal, Daytona, Vercel Sandbox) drop in without touching
  this file. ADR 20's "vendor commitment with known characteristics,
  not vendor-locked API surface" stance is *enforced* by the Protocol
  shape --- different providers, identical contract.
- **``runtime_checkable``** --- a unit test
  (``tests/unit/test_sandbox_protocol.py``) asserts
  ``isinstance(sandbox, Sandbox)`` for both adapters at module import
  time. The runtime check is a coarse sanity gate (it confirms method
  *names* exist; pyright/static checking confirms *signatures*); both
  layers run on every PR.
- **Slice 7 typecheck breaks fake-first** --- adding a new method to the
  Protocol will fail the typecheck on whichever adapter doesn't
  implement it next. With pyright strict the violation surfaces at
  PR-CI time, not at deploy time.

Slice 0 surface (T5)
--------------------

T5 ships the *minimum* surface needed for Slice 7's agent-runtime call
sites to wire against. The four operations are:

1. **``start``** --- spawn a sandbox configured with the supplied egress
   ``allowlist`` (per §5.13). The ``allowlist`` is the structural
   chokepoint §5.13 leans on: *defense-in-depth bullet one* ---
   "outbound network from sandboxes is structurally constrained, not
   'we'll figure it out per-tool.'" The mock raises
   :class:`EgressViolation` on off-list calls; the production E2B
   adapter (Slice 7) will configure E2B's egress rules from the same
   list.
2. **``run``** --- execute a command inside the sandbox; return a typed
   :class:`ExecResult` (stdout, stderr, exit code). The simplest
   useful surface for Slice 7's first call site: ``harness/<name>.py``
   shells out to the harness binary inside the sandbox. (The canon
   §5.12 wishlist names it ``exec``; this Protocol surfaces it as
   ``run`` to avoid colliding with Python's builtin ``exec`` keyword
   and to keep tooling/lint hooks that flag the bare word ``exec`` ---
   on either side of the language boundary --- quiet.)
3. **``end``** --- tear down the sandbox. Idempotent (calling twice is
   not an error --- mirrors the KMS ``destroy_dek`` shape). Production
   E2B's ``cryptoKeyVersions.destroy``-equivalent is the control-plane
   ``sandbox.kill`` API; the mock removes its own running-state bit.
4. **``attach_webhook``** --- register a callback the sandbox invokes on
   lifecycle events (per §5.15). The Slice 7 production wiring
   configures E2B with our webhook URL + HMAC-signed token; the in-
   process mock fires the same payloads to a Python callable so tests
   can assert on lifecycle without a real HTTP server. Same payload
   shape across mock and prod (E11 mitigation: "mock simulates success
   when production would fail" is foreclosed if the mock's callback
   contract matches the real webhook's).

The deeper surface §5.12 hints at (``spawn``, ``exec``, ``kill``,
``awaitExit``, ``attachWebhook``, ...) is **Slice 7 work**; T5 does not
pre-empt it. The four-method shape above is the smallest interface that
lets Slice 7 add ``await_exit`` (or rename ``run`` ↔ ``exec``, etc.) by
extending the Protocol --- every adapter then fails typecheck until the
new method is implemented, which is the desired drift-detection
property.

Webhook contract (§5.15)
------------------------

Lifecycle events surface as :class:`SandboxEvent` instances. The kinds
follow E2B's documented webhook event names so the production adapter
can pass them through verbatim:

- ``"started"`` --- sandbox spawn complete; ready to accept ``run`` calls.
- ``"ended"`` --- sandbox torn down (clean exit; ``end()`` was called or
  the process inside completed). The dashboard subscribes to
  ``agent.run.completed`` for this kind.
- ``"errored"`` --- sandbox died non-cleanly (OOM, segfault, network
  failure during egress check). The dashboard subscribes to
  ``agent.run.errored`` for this kind. **Slice 0 surface**: the mock
  fires ``"errored"`` only when an egress violation surfaces inside a
  ``run`` call; broader error surfaces (sandbox-internal crashes) land
  with Slice 7's deeper mock.

The :class:`SandboxEvent` carries the sandbox identifier (so a webhook
handler can correlate to its ``AgentRun`` per §5.15) plus a small
free-form payload mapping for kind-specific metadata. Callbacks are
called *synchronously* from ``start`` / ``end`` / ``run`` for
testability (real E2B fires async HTTP webhooks; the in-process mock's
synchronous firing keeps tests deterministic --- no race between "did
the webhook arrive yet?" and the test's assertion).

Why ``EgressViolation`` lives here, not adapter-side
----------------------------------------------------

The exception class is the cross-adapter contract. Consumer code doing
``except EgressViolation:`` works regardless of backend; both the
in-process mock and the Slice 7 E2B adapter raise *the same class*.
Defining it on the Protocol module keeps the import path stable:
``from skaldos.sandbox import EgressViolation`` (re-exported via
``__init__.py``) is what consumer code writes.

References: §5.12 (Sandbox abstraction), §5.13 (allowlist-only egress),
§5.15 (lifecycle webhooks), §5.4 (sandbox is a hard isolation boundary),
ADR 20 (sandbox provider --- E2B with portability stance), MP3 (honest
naming --- the mock is a *behavioral* fake, not a stub), MP6 (humans +
agents call the same Protocol), AP5 (no test-only bypass), E11
(``02-edge-cases.md`` --- "mock simulates success when production would
fail" --- the same allowlist semantics on both sides forecloses this).
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import Literal, Protocol, runtime_checkable

# -----------------------------------------------------------------------------
# Exceptions --- cross-adapter contract; consumer code's catch shapes.
# -----------------------------------------------------------------------------


class EgressViolation(Exception):  # noqa: N818 -- name matches the §5.13 vocabulary ("egress allowlist"); the brainstorm pins this exception class by name (T5 / E11). Renaming to `EgressViolationError` would obscure the canon link.
    """Raised when a sandbox call attempts egress to an off-allowlist host.

    Per §5.13 ("Sandboxes have allowlist-only egress"): the in-process
    mock and the Slice 7 E2B adapter raise this *same* exception class
    so consumer code can catch a single type --- the contract that lets
    a Slice 7 agent-runtime test assert "off-list call surfaces as
    :class:`EgressViolation` regardless of backend."

    The exception carries the offending host (in
    :attr:`EgressViolation.host`) plus the configured allowlist
    (:attr:`EgressViolation.allowlist`) so the failing test (or audit
    log entry) reports both halves of the mismatch --- "tried to reach
    *evil.example.com*, allowlist was [*llm-provider.example.invalid*, *apart.tech*]"
    is more actionable than just the host.

    Defense-in-depth (§5.13) lives at three layers: sandbox egress
    rules + Shield's per-tenant allowlist + the agent type's declared
    external dependencies. This exception is the *first* layer
    surfacing; Shield catches what slips past, and the declared-deps
    check rejects at runtime-boundary entry. The Protocol surfaces the
    failure as early as possible --- the mock raises before the
    simulated request even leaves the in-memory simulator; the
    production E2B adapter surfaces the failure when E2B's egress rules
    block the connection.
    """

    def __init__(self, host: str, allowlist: Sequence[str]) -> None:
        self.host = host
        self.allowlist: tuple[str, ...] = tuple(allowlist)
        super().__init__(
            f"sandbox egress denied: host={host!r} not in allowlist={list(self.allowlist)!r}; "
            f"declare the host via the agent type's requiredSecrets mapping (§5.9) or "
            f"reject the call at the runtime boundary (§5.13)"
        )


# -----------------------------------------------------------------------------
# Value types --- run result and webhook event payload.
# -----------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class ExecResult:
    """Outcome of a sandbox :meth:`Sandbox.run` call.

    Frozen / slotted so the Protocol's return shape is observably
    immutable --- consumer code can't mutate the captured stdout/stderr
    after the fact, which keeps audit / trace records honest (§5.5
    structured-trace shape).

    The fields mirror what a typical subprocess invocation returns:
    stdout, stderr, exit code. The Slice 7 production adapter inherits
    the same shape from E2B's ``Sandbox.commands.run`` API (it exposes
    ``stdout``, ``stderr``, ``exit_code``).

    A non-zero ``exit_code`` is **not** an error from the Protocol's
    point of view --- it's a successful command that returned non-zero.
    Errors (egress violations, sandbox crashes) surface as exceptions,
    not as ``exit_code != 0``. Mirrors the discipline §5.5 leans on:
    "trace creation is a side-effect of agent execution"; the trace
    records *what happened*, including non-zero exits, without
    short-circuiting the runtime.
    """

    stdout: str
    """Standard output captured from the command. UTF-8 decoded;
    binary-safe variants are a Slice 7 deepening if needed."""

    stderr: str
    """Standard error captured from the command. Same UTF-8 caveat."""

    exit_code: int
    """Process exit code. ``0`` for success in Unix convention; the
    sandbox does not interpret the value, only reports it."""


SandboxEventKind = Literal["started", "ended", "errored"]
"""The three lifecycle event kinds per §5.15.

Slice 0 surface (T5): the mock fires ``started`` on
:meth:`Sandbox.start`, ``ended`` on :meth:`Sandbox.end`, and
``errored`` when an egress violation surfaces during
:meth:`Sandbox.run`. Slice 7's deeper mock broadens ``errored`` to cover
sandbox-internal failures (OOM, segfault, non-clean exits).

Names match E2B's documented webhook event taxonomy verbatim so the
production adapter passes them through unchanged. If E2B introduces a
new kind (``"timed_out"``, ``"oom_killed"``, etc.) the Protocol grows
this literal --- and every adapter typechecks against the new kind.
"""


@dataclass(frozen=True, slots=True)
class SandboxEvent:
    """Lifecycle webhook payload (§5.15).

    Frozen so the receiving callback can't mutate the event after
    receipt --- relevant when multiple callbacks are attached and one
    might otherwise stomp another's view. The :attr:`payload` is
    :class:`Mapping[str, str]` (read-only mapping protocol) so the same
    immutability extends to the contents.

    Per §5.15, the event carries:

    - :attr:`kind` --- one of :data:`SandboxEventKind`.
    - :attr:`sandbox_id` --- the sandbox handle's identifier; lets a
      webhook handler correlate the event to the originating
      ``AgentRun`` (the Slice 7 production wiring will sign this with
      an HMAC token; the Slice 0 mock leaves the signature surface
      empty --- Slice 7 deepens).
    - :attr:`payload` --- kind-specific metadata. ``"errored"`` events
      include ``error_class`` and ``error_message`` keyed entries;
      ``"started"`` includes the configured allowlist size; ``"ended"``
      includes a clean-exit boolean. The exact key set is stable
      across the mock and the Slice 7 adapter.

    The payload type is ``Mapping[str, str]`` not ``dict[str, Any]``
    deliberately: webhook payloads are cross-process / cross-language
    and roundtrip through JSON; pinning ``str`` -> ``str`` keeps
    serialization shape obvious and forecloses "let me stuff a dict in
    here" drift (E10 cousin: structured payloads, not free-form blobs).
    """

    kind: SandboxEventKind
    """Lifecycle event kind. See :data:`SandboxEventKind` for the
    full taxonomy."""

    sandbox_id: str
    """Identifier of the sandbox emitting the event. In production this
    is E2B's sandbox UUID; in the mock it's a deterministic
    test-friendly id. Either way, it correlates to the originating
    ``AgentRun`` per §5.15."""

    payload: Mapping[str, str] = field(default_factory=lambda: {})
    """Kind-specific metadata. See class docstring for the per-kind
    key conventions. Empty by default for kinds that don't carry
    additional data."""


# -----------------------------------------------------------------------------
# WebhookCallback Protocol --- what `attach_webhook` accepts.
# -----------------------------------------------------------------------------


class WebhookCallback(Protocol):
    """Callable invoked by the sandbox on each lifecycle event (§5.15).

    A bare ``Callable[[SandboxEvent], None]`` would also work; the
    Protocol-shaped alias makes the *role* explicit at call sites
    (``attach_webhook(my_handler)`` reads as "register a webhook
    handler", not "register a callable"). Keeps with MP3's honest-
    naming principle --- types name roles.

    Implementations MUST NOT raise. The mock's ``attach_webhook`` will
    propagate exceptions (so a buggy callback fails the test loudly,
    not silently); the production adapter's webhook handler logs and
    suppresses (one bad consumer doesn't break the rest of the
    delivery fan-out). The Slice 7 production wiring documents the
    asymmetry; the Slice 0 mock optimizes for test loudness.
    """

    def __call__(self, event: SandboxEvent, /) -> None:
        """Receive one lifecycle event. See class docstring for the
        no-raise discipline.

        ``event`` is *positional-only* (``/`` after the parameter) so
        bare ``list.append`` and similar built-in callables qualify as
        valid :class:`WebhookCallback` implementations --- they accept
        a single positional argument and don't honor a keyword name.
        Keyword-callable use sites work too (Python is permissive
        on the calling side); the constraint is on conformance, not
        invocation.
        """
        ...


# -----------------------------------------------------------------------------
# Sandbox Protocol --- the four-method surface.
# -----------------------------------------------------------------------------


@runtime_checkable
class Sandbox(Protocol):
    """Sandbox provider; implemented by every adapter.

    Method docstrings describe the *contract* every adapter must honor.
    Concrete adapters (``E2BSandbox`` in prod, ``MockSandbox`` in
    tests) have their own docstrings with adapter-specific notes.

    The four-method surface is the minimum required by §5.12 / §5.13 /
    §5.15 for Slice 7's first agent-runtime call sites. Adding a method
    here is a typecheck failure on every adapter that doesn't implement
    it --- that's the desired behavior (drift is loud, not silent).
    Mirror of the discipline T4 landed for ``KMSClient``.
    """

    def start(self, *, allowlist: Sequence[str], sandbox_id: str) -> None:
        """Spawn the sandbox configured with the supplied egress allowlist.

        ``allowlist`` is the set of hostnames the sandbox is permitted
        to reach (per §5.13). Must be passed at start time, not mutated
        later --- the egress rules are baked into the sandbox at spawn
        per E2B's API shape; the Protocol enforces "no mid-life
        allowlist mutation" structurally by *omitting* an
        ``update_allowlist`` method.

        ``sandbox_id`` is the caller-supplied identifier for the
        sandbox; it appears in :attr:`SandboxEvent.sandbox_id` on every
        lifecycle event the sandbox emits. The production adapter will
        set this to the E2B sandbox UUID; the mock and tests pass
        deterministic strings.

        Calling :meth:`start` twice on the same instance is **not**
        supported (in production E2B refuses; the mock raises
        ``RuntimeError``). The Protocol does not pin the exception
        class for the double-start case --- the post-condition is
        "spawned once, deterministic"; multiple-spawn is a caller bug
        surfaced loudly by both adapters.

        Fires a :class:`SandboxEvent` with ``kind="started"`` to every
        attached webhook callback (per §5.15) before returning. Callers
        who attach webhooks *after* :meth:`start` returns will not see
        the start event --- :meth:`attach_webhook` documents the
        ordering; tests that need to observe ``started`` attach the
        webhook first, then call :meth:`start`.
        """
        ...

    def run(
        self,
        command: Sequence[str],
        *,
        host: str | None = None,
        env: Mapping[str, str] | None = None,
        timeout_seconds: int = 60,
    ) -> ExecResult:
        """Execute a command inside the running sandbox.

        ``command`` is the argv-style command line (e.g.
        ``["python", "-c", "print('hi')"]``). Adapters do not interpret
        the args; the sandbox runs them verbatim.

        ``env`` carries task-scoped command environment values. Callers must
        treat it as sensitive runtime material: adapters pass it to the
        provider command API and must not persist or log the raw mapping.

        ``timeout_seconds`` bounds the command connection for providers that
        support per-command timeouts.

        ``host`` (optional) is the egress destination the command is
        about to reach. When supplied, the sandbox checks it against
        the configured ``allowlist``; an off-list host raises
        :class:`EgressViolation` *before* the command runs (defense in
        depth --- the sandbox's structural egress rules would catch the
        request anyway, but surfacing it here means the test/audit
        signal is loud and immediate). When omitted, the call is
        treated as in-sandbox-only (no egress) and runs unconditionally.

        The Slice 7 production E2B adapter will pass ``host`` through
        from the harness's network call site (the harness inspects the
        request URL and supplies the hostname); the in-process mock
        accepts it as an explicit parameter so tests can drive both the
        allowed and the violation paths deterministically.

        Returns :class:`ExecResult`. A non-zero ``exit_code`` is **not**
        an error from the Protocol's point of view --- see
        :class:`ExecResult` docstring.

        Raises :class:`EgressViolation` if ``host`` is supplied and not
        in the allowlist. Raises ``RuntimeError`` if the sandbox is not
        in the running state (i.e. :meth:`start` was never called or
        :meth:`end` already fired).
        """
        ...

    def end(self) -> None:
        """Tear down the sandbox. Idempotent.

        Subsequent :meth:`run` calls raise ``RuntimeError``; subsequent
        :meth:`end` calls are no-ops (mirrors the KMS ``destroy_dek``
        idempotence shape T4 pinned). The post-condition is "ended"
        either way.

        Fires a :class:`SandboxEvent` with ``kind="ended"`` on the
        first call (idempotent re-end does not re-fire --- webhooks see
        each lifecycle transition once). Per §5.15, the dashboard
        subscribes to ``agent.run.completed`` for this kind; the
        production wiring posts to the configured webhook URL with an
        HMAC-signed token; the mock invokes the attached Python
        callbacks directly.
        """
        ...

    def attach_webhook(self, callback: WebhookCallback) -> None:
        """Register ``callback`` to receive lifecycle events (§5.15).

        Multiple callbacks may be attached; each receives every event.
        Order of delivery is registration order (FIFO).

        Per the :class:`WebhookCallback` docstring, callbacks must not
        raise. The mock propagates exceptions (test loudness); the
        production adapter logs and suppresses (one bad consumer
        doesn't break the rest of the fan-out).

        Ordering relative to :meth:`start`: callbacks attached *before*
        :meth:`start` see the ``"started"`` event; callbacks attached
        *after* :meth:`start` returns do not (the event has already
        fired). Tests that need to observe lifecycle from spawn onward
        attach the webhook first. The production E2B wiring is the
        same shape --- the webhook URL is configured at spawn, not
        post-hoc.
        """
        ...
