"""Supervisor runtime contract DTOs and policy helpers for Slice 9."""

from __future__ import annotations

from enum import StrEnum
from typing import Annotated, Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, model_validator

from skaldos.agents.contracts import Clearance
from skaldos.policy.intent import Intent


class SupervisorRuntimeConfigError(ValueError):
    """Stable reason-code error for invalid supervisor runtime config."""

    def __init__(self, reason_code: str) -> None:
        super().__init__(reason_code)
        self.reason_code = reason_code


class FirstClassHandoffReason(StrEnum):
    """Reasons helper cognition must become a first-class SkaldOS handoff."""

    DIFFERENT_PRINCIPAL = "different_principal"
    INDEPENDENT_AUTHORITY = "independent_authority"
    SEPARATE_CANCELLATION = "separate_cancellation"
    CONVERSATION_OBLIGATION = "conversation_obligation"
    TRUST_CALIBRATION = "trust_calibration"
    CROSS_CLEARANCE_BOUNDARY = "cross_clearance_boundary"
    EXTERNAL_SIDE_EFFECT = "external_side_effect"


class HandoffDecision(StrEnum):
    """Supervisor handoff policy outcome."""

    INTERNAL_HELPER = "internal_helper"
    FIRST_CLASS_HANDOFF = "first_class_handoff"


class SupervisorConversationAction(StrEnum):
    """Conversation actions a supervisor may propose."""

    OPEN = "open_conversation"
    SATISFY = "satisfy_conversation"
    REJECT = "reject_conversation"
    REOPEN = "reopen_conversation"
    NO_OP = "no_op"


class SupervisorLensScope(BaseModel):
    """Content-free scope facts stored on a supervisor agent type."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    lens_id: UUID
    domain: Annotated[str, Field(pattern=r"^[a-z][a-z0-9_.-]{0,63}$")]


class SupervisorEventThresholds(BaseModel):
    """Closed supervisor event threshold settings."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    surprise_magnitude_gte: Annotated[float, Field(ge=0.0, le=1.0)] = 0.75


class SupervisorConversationPolicy(BaseModel):
    """Conversation behavior knobs for one supervisor type."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    open_on_surprise: bool = True
    open_on_stalled: bool = True
    default_sla_policy_ref: Annotated[str, Field(min_length=1, max_length=128)] | None = None
    max_auto_satisfy_confidence: Annotated[float, Field(ge=0.0, le=1.0)] = 0.95


class SupervisorHandoffPolicy(BaseModel):
    """Policy reasons that force helper work into a first-class handoff."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    first_class_required_for: tuple[FirstClassHandoffReason, ...] = (
        FirstClassHandoffReason.DIFFERENT_PRINCIPAL,
        FirstClassHandoffReason.INDEPENDENT_AUTHORITY,
        FirstClassHandoffReason.SEPARATE_CANCELLATION,
        FirstClassHandoffReason.CONVERSATION_OBLIGATION,
        FirstClassHandoffReason.TRUST_CALIBRATION,
        FirstClassHandoffReason.CROSS_CLEARANCE_BOUNDARY,
        FirstClassHandoffReason.EXTERNAL_SIDE_EFFECT,
    )


class SupervisorAgentTypeConfig(BaseModel):
    """Built-in supervisory OrgAgentType metadata/config contract."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    kind: Literal["supervisor"] = "supervisor"
    harness: Literal["pi"] = "pi"
    name: Annotated[str, Field(min_length=1, max_length=128)] = "domain-supervisor"
    lens_scope: SupervisorLensScope
    event_thresholds: SupervisorEventThresholds = Field(default_factory=SupervisorEventThresholds)
    conversation_policy: SupervisorConversationPolicy = Field(
        default_factory=SupervisorConversationPolicy
    )
    handoff_policy: SupervisorHandoffPolicy = Field(default_factory=SupervisorHandoffPolicy)
    keep_warm: bool = False
    max_clearance: Clearance
    template_ref: Annotated[str, Field(min_length=1, max_length=128)]
    persistent_idle_timeout_seconds: Annotated[int, Field(gt=0, le=86_400)] | None = None

    @model_validator(mode="after")
    def _keep_warm_requires_persistence_policy(self) -> SupervisorAgentTypeConfig:
        if self.keep_warm and self.persistent_idle_timeout_seconds is None:
            raise SupervisorRuntimeConfigError("supervisor_keep_warm_idle_timeout_required")
        return self


class HandoffEvaluationInput(BaseModel):
    """Boolean criteria for deciding whether helper work is accountable enough."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    different_principal: bool = False
    independent_authority: bool = False
    separate_cancellation: bool = False
    conversation_obligation: bool = False
    trust_calibration: bool = False
    cross_clearance_boundary: bool = False
    external_side_effect: bool = False


class ConversationActionProposal(BaseModel):
    """Content-free proposed conversation action from supervisor reasoning."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    action: SupervisorConversationAction
    target_principal_id: UUID | None = None
    conversation_node_id: UUID | None = None
    confidence: Annotated[float, Field(ge=0.0, le=1.0)] | None = None
    reason_codes: tuple[Annotated[str, Field(min_length=1, max_length=64)], ...] = ()

    @model_validator(mode="after")
    def _target_shape_matches_action(self) -> ConversationActionProposal:
        if self.action == SupervisorConversationAction.OPEN and self.target_principal_id is None:
            raise SupervisorRuntimeConfigError("supervisor_open_target_required")
        if (
            self.action
            in {
                SupervisorConversationAction.SATISFY,
                SupervisorConversationAction.REJECT,
                SupervisorConversationAction.REOPEN,
            }
            and self.conversation_node_id is None
        ):
            raise SupervisorRuntimeConfigError("supervisor_conversation_handle_required")
        return self


def evaluate_handoff_boundary(
    criteria: HandoffEvaluationInput,
    *,
    policy: SupervisorHandoffPolicy | None = None,
) -> tuple[HandoffDecision, tuple[FirstClassHandoffReason, ...]]:
    """Return first-class handoff if any configured accountability reason is present."""

    active = tuple(
        reason for reason in FirstClassHandoffReason if bool(getattr(criteria, reason.value))
    )
    configured = set((policy or SupervisorHandoffPolicy()).first_class_required_for)
    blocking = tuple(reason for reason in active if reason in configured)
    if blocking:
        return HandoffDecision.FIRST_CLASS_HANDOFF, blocking
    return HandoffDecision.INTERNAL_HELPER, ()


def supervisor_action_intent(action: SupervisorConversationAction) -> Intent:
    """Map supervisor conversation actions to required Searle intent."""

    match action:
        case SupervisorConversationAction.OPEN | SupervisorConversationAction.REOPEN:
            return Intent.directive
        case SupervisorConversationAction.SATISFY | SupervisorConversationAction.REJECT:
            return Intent.expressive
        case SupervisorConversationAction.NO_OP:
            return Intent.assertive


__all__ = [
    "ConversationActionProposal",
    "FirstClassHandoffReason",
    "HandoffDecision",
    "HandoffEvaluationInput",
    "SupervisorAgentTypeConfig",
    "SupervisorConversationAction",
    "SupervisorEventThresholds",
    "SupervisorHandoffPolicy",
    "SupervisorLensScope",
    "SupervisorRuntimeConfigError",
    "evaluate_handoff_boundary",
    "supervisor_action_intent",
]
