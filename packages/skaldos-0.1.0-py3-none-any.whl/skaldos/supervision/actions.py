"""Supervisor conversation action execution for Slice 9."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from datetime import UTC, datetime
from enum import StrEnum
from typing import Annotated
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict, Field, field_validator

from skaldos.conversations import (
    ConversationOpenDraft,
    ConversationTransition,
    ConversationTransitionDraft,
    open_from_directive,
    transition,
)
from skaldos.middleware import Principal
from skaldos.supervision.contracts import (
    ConversationActionProposal,
    SupervisorConversationAction,
    supervisor_action_intent,
)


class SupervisorActionExecutionError(RuntimeError):
    """Stable reason-code error for invalid supervisor action execution."""

    def __init__(self, reason_code: str) -> None:
        self.reason_code = reason_code
        super().__init__(reason_code)


class SupervisorActionResultKind(StrEnum):
    """Terminal result kinds for one supervisor conversation action."""

    OPENED = "opened"
    TRANSITIONED = "transitioned"
    NO_OP = "no_op"


class SupervisorConversationActionDraft(BaseModel):
    """Trace-grounded supervisor action request consumed by Hall/Pi glue."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    agent_run_id: UUID
    decision_trace_id: UUID
    action_act_id: UUID
    proposal: ConversationActionProposal
    task_type: Annotated[str, Field(min_length=1, max_length=128)] = "supervision-review"
    occurred_at: datetime
    event_id_hash: Annotated[str, Field(pattern=r"^[0-9a-f]{64}$")] | None = None
    subscription_pattern_node_id: UUID | None = None

    @field_validator("occurred_at")
    @classmethod
    def _occurred_at_is_utc(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            raise ValueError("timestamp_requires_timezone")
        return value.astimezone(UTC).replace(tzinfo=UTC)


@dataclass(frozen=True, slots=True)
class SupervisorConversationActionResult:
    """Content-free handles returned after one supervisor action."""

    kind: SupervisorActionResultKind
    action: SupervisorConversationAction
    agent_run_id: UUID
    decision_trace_id: UUID
    conversation_node_id: UUID | None
    idempotency_key: str
    replayed: bool


async def execute_supervisor_conversation_action(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    draft: SupervisorConversationActionDraft,
) -> SupervisorConversationActionResult:
    """Apply one supervisor action through the Conversation primitive."""

    action = draft.proposal.action
    idempotency_key = supervisor_conversation_action_idempotency_key(
        principal_id=principal.id,
        draft=draft,
    )
    if action is SupervisorConversationAction.NO_OP:
        return SupervisorConversationActionResult(
            kind=SupervisorActionResultKind.NO_OP,
            action=action,
            agent_run_id=draft.agent_run_id,
            decision_trace_id=draft.decision_trace_id,
            conversation_node_id=None,
            idempotency_key=idempotency_key,
            replayed=False,
        )
    if action is SupervisorConversationAction.OPEN:
        if draft.proposal.target_principal_id is None:
            raise SupervisorActionExecutionError("supervisor_open_target_required")
        opened = await open_from_directive(
            principal=principal,
            connection=connection,
            draft=ConversationOpenDraft(
                request_act_id=draft.action_act_id,
                requestee_principal_id=draft.proposal.target_principal_id,
                task_type=draft.task_type,
                occurred_at=draft.occurred_at,
                idempotency_key=idempotency_key,
            ),
        )
        return SupervisorConversationActionResult(
            kind=SupervisorActionResultKind.OPENED,
            action=action,
            agent_run_id=draft.agent_run_id,
            decision_trace_id=draft.decision_trace_id,
            conversation_node_id=opened.conversation_node_id,
            idempotency_key=idempotency_key,
            replayed=opened.replayed,
        )

    conversation_node_id = draft.proposal.conversation_node_id
    if conversation_node_id is None:
        raise SupervisorActionExecutionError("supervisor_conversation_handle_required")
    transitioned = await transition(
        principal=principal,
        connection=connection,
        draft=ConversationTransitionDraft(
            conversation_node_id=conversation_node_id,
            transition=_conversation_transition(action),
            act_id=draft.action_act_id,
            intent=supervisor_action_intent(action),
            occurred_at=draft.occurred_at,
            idempotency_key=idempotency_key,
        ),
    )
    return SupervisorConversationActionResult(
        kind=SupervisorActionResultKind.TRANSITIONED,
        action=action,
        agent_run_id=draft.agent_run_id,
        decision_trace_id=draft.decision_trace_id,
        conversation_node_id=transitioned.conversation_node_id,
        idempotency_key=idempotency_key,
        replayed=transitioned.replayed,
    )


def supervisor_conversation_action_idempotency_key(
    *,
    principal_id: UUID,
    draft: SupervisorConversationActionDraft,
) -> str:
    """Stable key preventing duplicate conversation actions on event retry."""

    proposal = draft.proposal
    canonical = json.dumps(
        {
            "action": proposal.action.value,
            "action_act_id": str(draft.action_act_id),
            "agent_run_id": str(draft.agent_run_id),
            "conversation_node_id": (
                None
                if proposal.conversation_node_id is None
                else str(proposal.conversation_node_id)
            ),
            "decision_trace_id": str(draft.decision_trace_id),
            "event_id_hash": draft.event_id_hash,
            "principal_id": str(principal_id),
            "subscription_pattern_node_id": (
                None
                if draft.subscription_pattern_node_id is None
                else str(draft.subscription_pattern_node_id)
            ),
            "target_principal_id": (
                None if proposal.target_principal_id is None else str(proposal.target_principal_id)
            ),
            "task_type": draft.task_type,
        },
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()


def _conversation_transition(action: SupervisorConversationAction) -> ConversationTransition:
    match action:
        case SupervisorConversationAction.SATISFY:
            return ConversationTransition.satisfy
        case SupervisorConversationAction.REJECT:
            return ConversationTransition.reject
        case SupervisorConversationAction.REOPEN:
            return ConversationTransition.reopen
        case _:
            raise SupervisorActionExecutionError("supervisor_transition_action_invalid")


__all__ = [
    "SupervisorActionExecutionError",
    "SupervisorActionResultKind",
    "SupervisorConversationActionDraft",
    "SupervisorConversationActionResult",
    "execute_supervisor_conversation_action",
    "supervisor_conversation_action_idempotency_key",
]
