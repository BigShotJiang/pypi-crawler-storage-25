"""Event-triggered supervisor AgentRun runtime bridge for Slice 9."""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from enum import StrEnum
from typing import Any
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict, Field, model_validator

from skaldos.agents.contracts import AgentRunStatus, AgentTriggerKind
from skaldos.agents.run_store import AgentRunRecord, AgentRunStore
from skaldos.agents.trace import ExecutionTracePayload
from skaldos.agents.trace_evidence import persist_required_trace_or_fail_run
from skaldos.agents.trace_store import ExecutionTraceNodeRecord
from skaldos.middleware import Principal
from skaldos.supervision.actions import (
    SupervisorConversationActionDraft,
    SupervisorConversationActionResult,
    execute_supervisor_conversation_action,
)
from skaldos.supervision.helper_trace import (
    SupervisorHelperEvent,
    SupervisorHelperEventKind,
    normalize_supervisor_helper_event,
)


class SupervisorEventRuntimeError(ValueError):
    """Stable reason-code error for supervisor event runtime failures."""

    def __init__(self, reason_code: str) -> None:
        self.reason_code = reason_code
        super().__init__(reason_code)


class SupervisorEventRuntimeOutcome(StrEnum):
    """Handle-only terminal outcomes for event-triggered supervisor runs."""

    ACTION_EXECUTED = "action_executed"
    ACTION_FAILED = "action_failed"


class SupervisorEventRuntimeDraft(BaseModel):
    """Trace-grounded work package produced by the supervisor Pi runtime."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    action: SupervisorConversationActionDraft
    helper_events: tuple[SupervisorHelperEvent, ...] = Field(min_length=1)
    context_of_validity: dict[str, Any]

    @model_validator(mode="after")
    def _action_is_grounded_by_helper_trace(self) -> SupervisorEventRuntimeDraft:
        action_trace_event = _action_trace_event(
            helper_events=self.helper_events,
            decision_trace_id=self.action.decision_trace_id,
        )
        if action_trace_event is None:
            raise SupervisorEventRuntimeError("supervisor_action_trace_not_grounded")
        if action_trace_event.kind is not SupervisorHelperEventKind.CONVERSATION_ACTION_PROPOSED:
            raise SupervisorEventRuntimeError("supervisor_action_trace_not_decision")
        return self


@dataclass(frozen=True, slots=True)
class SupervisorEventRuntimeResult:
    """Content-free result after running one supervisor event decision."""

    agent_run: AgentRunRecord
    action_result: SupervisorConversationActionResult
    helper_trace_records: tuple[ExecutionTraceNodeRecord, ...]


class SupervisorEventRuntimeService:
    """Run event-triggered supervisor actions under one accountable AgentRun."""

    def __init__(self, *, run_store: AgentRunStore | None = None) -> None:
        self._run_store = run_store or AgentRunStore()

    async def run_event_action(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        agent_principal: Principal,
        agent_run_id: UUID,
        draft: SupervisorEventRuntimeDraft,
    ) -> SupervisorEventRuntimeResult:
        """Persist helper trace evidence, execute action, and terminalize the run."""

        if not connection.is_in_transaction():  # pyright: ignore[reportUnknownMemberType]
            raise SupervisorEventRuntimeError("supervisor_runtime_transaction_required")
        if draft.action.agent_run_id != agent_run_id:
            raise SupervisorEventRuntimeError("supervisor_action_run_mismatch")
        await self._load_event_run(
            connection=connection,
            tenant_id=tenant_id,
            agent_principal=agent_principal,
            agent_run_id=agent_run_id,
        )
        traces = tuple(normalize_supervisor_helper_event(event) for event in draft.helper_events)
        self._validate_trace_run_ids(traces=traces, agent_run_id=agent_run_id)
        helper_trace_records = await self._persist_helper_traces(
            connection=connection,
            tenant_id=tenant_id,
            agent_principal=agent_principal,
            traces=traces,
            context_of_validity=draft.context_of_validity,
        )
        try:
            action_result = await execute_supervisor_conversation_action(
                principal=agent_principal,
                connection=connection,
                draft=draft.action,
            )
        except Exception as exc:
            await self._mark_failed(
                connection=connection,
                tenant_id=tenant_id,
                agent_run_id=agent_run_id,
                reason_code=_safe_reason_code(exc),
                trace_ids=tuple(record.execution_trace_id for record in helper_trace_records),
            )
            raise

        terminal_run = await self._run_store.mark_terminal(
            connection=connection,
            tenant_id=tenant_id,
            agent_run_id=agent_run_id,
            status=AgentRunStatus.SUCCEEDED,
            result_json=json.dumps(
                _success_result(
                    action_result=action_result,
                    helper_trace_records=helper_trace_records,
                ),
                separators=(",", ":"),
                sort_keys=True,
            ),
        )
        return SupervisorEventRuntimeResult(
            agent_run=terminal_run,
            action_result=action_result,
            helper_trace_records=helper_trace_records,
        )

    async def _load_event_run(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        agent_principal: Principal,
        agent_run_id: UUID,
    ) -> AgentRunRecord:
        run = await self._run_store.get_run(
            connection=connection,
            tenant_id=tenant_id,
            agent_run_id=agent_run_id,
        )
        if run.effective_principal_id != agent_principal.id:
            raise SupervisorEventRuntimeError("supervisor_runtime_principal_mismatch")
        if run.trigger_kind is not AgentTriggerKind.EVENT:
            raise SupervisorEventRuntimeError("supervisor_runtime_event_trigger_required")
        return run

    @staticmethod
    def _validate_trace_run_ids(
        *,
        traces: Sequence[ExecutionTracePayload],
        agent_run_id: UUID,
    ) -> None:
        for trace in traces:
            if trace.agent_run_id != agent_run_id:
                raise SupervisorEventRuntimeError("supervisor_helper_trace_run_mismatch")

    async def _persist_helper_traces(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        agent_principal: Principal,
        traces: Sequence[ExecutionTracePayload],
        context_of_validity: Mapping[str, Any],
    ) -> tuple[ExecutionTraceNodeRecord, ...]:
        records: list[ExecutionTraceNodeRecord] = []
        context = dict(context_of_validity)
        for trace in traces:
            record = await persist_required_trace_or_fail_run(
                principal=agent_principal,
                connection=connection,
                tenant_id=tenant_id,
                trace=trace,
                context_of_validity=context,
                run_store=self._run_store,
            )
            records.append(record)
        return tuple(records)

    async def _mark_failed(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        agent_run_id: UUID,
        reason_code: str,
        trace_ids: tuple[UUID, ...],
    ) -> AgentRunRecord:
        return await self._run_store.mark_terminal(
            connection=connection,
            tenant_id=tenant_id,
            agent_run_id=agent_run_id,
            status=AgentRunStatus.FAILED,
            result_json=json.dumps(
                {
                    "outcome": SupervisorEventRuntimeOutcome.ACTION_FAILED.value,
                    "reason_code": reason_code,
                    "execution_trace_ids": [str(trace_id) for trace_id in trace_ids],
                },
                separators=(",", ":"),
                sort_keys=True,
            ),
        )


def _success_result(
    *,
    action_result: SupervisorConversationActionResult,
    helper_trace_records: Sequence[ExecutionTraceNodeRecord],
) -> dict[str, Any]:
    return {
        "outcome": SupervisorEventRuntimeOutcome.ACTION_EXECUTED.value,
        "action": action_result.action.value,
        "conversation_node_id": (
            None
            if action_result.conversation_node_id is None
            else str(action_result.conversation_node_id)
        ),
        "decision_trace_id": str(action_result.decision_trace_id),
        "idempotency_key": action_result.idempotency_key,
        "replayed": action_result.replayed,
        "execution_trace_ids": [str(record.execution_trace_id) for record in helper_trace_records],
    }


def _action_trace_event(
    *,
    helper_events: Sequence[SupervisorHelperEvent],
    decision_trace_id: UUID,
) -> SupervisorHelperEvent | None:
    for event in helper_events:
        if normalize_supervisor_helper_event(event).execution_trace_id == decision_trace_id:
            return event
    return None


def _safe_reason_code(exc: Exception) -> str:
    reason = getattr(exc, "reason_code", None)
    if isinstance(reason, StrEnum):
        return reason.value
    if isinstance(reason, str):
        return reason
    return "supervisor_action_execution_failed"


__all__ = [
    "SupervisorEventRuntimeDraft",
    "SupervisorEventRuntimeError",
    "SupervisorEventRuntimeOutcome",
    "SupervisorEventRuntimeResult",
    "SupervisorEventRuntimeService",
]
