"""Supervisor reactive subscription setup for Slice 9."""

from __future__ import annotations

import json
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any, cast
from uuid import NAMESPACE_URL, UUID, uuid5

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict, Field, field_validator

from skaldos.events.reactive_agents import (
    EVENT_PATTERN_NODE_TYPE,
    REACTIVE_AGENT_SOURCE_NODE_TYPE,
    normalize_event_pattern_metadata,
)
from skaldos.graph.transaction import with_principal
from skaldos.middleware import Principal
from skaldos.supervision.contracts import SupervisorAgentTypeConfig

_SUBSCRIPTION_NAMESPACE = "skaldos.slice_9.supervisor_subscription.v1"


class SupervisorSubscriptionSetupError(RuntimeError):
    """Stable reason-code error for supervisor subscription setup failures."""

    def __init__(self, reason_code: str) -> None:
        self.reason_code = reason_code
        super().__init__(reason_code)


class SupervisorSubscriptionDraft(BaseModel):
    """Content-free setup input for one supervisor's Slice 8 subscriptions."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    tenant_id: UUID
    org_agent_type_id: UUID
    ontology_version_id: UUID
    config: SupervisorAgentTypeConfig
    classification: str = Field(default="C1", pattern=r"^C[0-4]$")
    vertical: str = Field(default="foundation", min_length=1, max_length=128)
    valid_from: datetime

    @field_validator("valid_from")
    @classmethod
    def _valid_from_is_utc(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            raise ValueError("timestamp_requires_timezone")
        return value.astimezone(UTC).replace(tzinfo=UTC)


@dataclass(frozen=True, slots=True)
class SupervisorSubscriptionSetupResult:
    """Node and edge handles created or reused for one supervisor."""

    source_node_id: UUID
    surprise_pattern_node_id: UUID
    stalled_pattern_node_id: UUID
    surprise_subscription_edge_id: UUID
    stalled_subscription_edge_id: UUID
    replayed: bool


async def ensure_supervisor_event_subscriptions(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    draft: SupervisorSubscriptionDraft,
) -> SupervisorSubscriptionSetupResult:
    """Ensure the built-in supervisor is wired to surprise and stalled events."""

    async def _ensure(bound_connection: asyncpg.Connection) -> SupervisorSubscriptionSetupResult:
        return await _ensure_bound(
            principal=principal,
            connection=bound_connection,
            draft=draft,
        )

    return await with_principal(principal=principal, connection=connection, fn=_ensure)


async def _ensure_bound(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    draft: SupervisorSubscriptionDraft,
) -> SupervisorSubscriptionSetupResult:
    if not connection.is_in_transaction():  # pyright: ignore[reportUnknownMemberType]
        raise SupervisorSubscriptionSetupError("supervisor_subscription_transaction_required")
    if draft.tenant_id not in principal.visible_tenant_ids:
        raise SupervisorSubscriptionSetupError("supervisor_subscription_tenant_not_visible")

    await _assert_agent_type_matches(
        connection=connection,
        tenant_id=draft.tenant_id,
        org_agent_type_id=draft.org_agent_type_id,
        config=draft.config,
    )
    principal_hub_type_id, event_pattern_type_id = await _load_pattern_type_ids(
        connection=connection,
        ontology_version_id=draft.ontology_version_id,
    )
    context = _context(draft)

    source_node_id = supervisor_source_node_id(
        tenant_id=draft.tenant_id,
        org_agent_type_id=draft.org_agent_type_id,
    )
    surprise_pattern_node_id = supervisor_event_pattern_node_id(
        tenant_id=draft.tenant_id,
        org_agent_type_id=draft.org_agent_type_id,
        event_type="surprise.recorded",
        domain=draft.config.lens_scope.domain,
        lens_id=draft.config.lens_scope.lens_id,
    )
    stalled_pattern_node_id = supervisor_event_pattern_node_id(
        tenant_id=draft.tenant_id,
        org_agent_type_id=draft.org_agent_type_id,
        event_type="conversation.stalled",
        domain=draft.config.lens_scope.domain,
        lens_id=draft.config.lens_scope.lens_id,
    )

    source_inserted = await _insert_node_once(
        connection=connection,
        node_id=source_node_id,
        type_id=principal_hub_type_id,
        context=context,
        metadata={"org_agent_type_id": str(draft.org_agent_type_id)},
        authored_by_principal_id=principal.id,
    )
    surprise_inserted = await _insert_node_once(
        connection=connection,
        node_id=surprise_pattern_node_id,
        type_id=event_pattern_type_id,
        context=context,
        metadata=_surprise_pattern_metadata(draft),
        authored_by_principal_id=principal.id,
    )
    stalled_inserted = await _insert_node_once(
        connection=connection,
        node_id=stalled_pattern_node_id,
        type_id=event_pattern_type_id,
        context=context,
        metadata=_stalled_pattern_metadata(draft),
        authored_by_principal_id=principal.id,
    )

    surprise_edge_id = supervisor_subscription_edge_id(
        source_node_id=source_node_id,
        pattern_node_id=surprise_pattern_node_id,
    )
    stalled_edge_id = supervisor_subscription_edge_id(
        source_node_id=source_node_id,
        pattern_node_id=stalled_pattern_node_id,
    )
    surprise_edge_inserted = await _insert_subscription_edge_once(
        connection=connection,
        edge_id=surprise_edge_id,
        tenant_id=draft.tenant_id,
        source_node_id=source_node_id,
        pattern_node_id=surprise_pattern_node_id,
        classification=draft.classification,
        authored_by_principal_id=principal.id,
    )
    stalled_edge_inserted = await _insert_subscription_edge_once(
        connection=connection,
        edge_id=stalled_edge_id,
        tenant_id=draft.tenant_id,
        source_node_id=source_node_id,
        pattern_node_id=stalled_pattern_node_id,
        classification=draft.classification,
        authored_by_principal_id=principal.id,
    )
    return SupervisorSubscriptionSetupResult(
        source_node_id=source_node_id,
        surprise_pattern_node_id=surprise_pattern_node_id,
        stalled_pattern_node_id=stalled_pattern_node_id,
        surprise_subscription_edge_id=surprise_edge_id,
        stalled_subscription_edge_id=stalled_edge_id,
        replayed=not any(
            (
                source_inserted,
                surprise_inserted,
                stalled_inserted,
                surprise_edge_inserted,
                stalled_edge_inserted,
            )
        ),
    )


def supervisor_source_node_id(*, tenant_id: UUID, org_agent_type_id: UUID) -> UUID:
    """Stable source hub id for supervisor subscription replay."""

    return uuid5(
        NAMESPACE_URL,
        f"{_SUBSCRIPTION_NAMESPACE}:source:{tenant_id}:{org_agent_type_id}",
    )


def supervisor_event_pattern_node_id(
    *,
    tenant_id: UUID,
    org_agent_type_id: UUID,
    event_type: str,
    domain: str,
    lens_id: UUID,
) -> UUID:
    """Stable event-pattern id for supervisor subscription replay."""

    return uuid5(
        NAMESPACE_URL,
        (
            f"{_SUBSCRIPTION_NAMESPACE}:pattern:{tenant_id}:"
            f"{org_agent_type_id}:{event_type}:{domain}:{lens_id}"
        ),
    )


def supervisor_subscription_edge_id(*, source_node_id: UUID, pattern_node_id: UUID) -> UUID:
    """Stable subscribes-to edge id for supervisor subscription replay."""

    return uuid5(
        NAMESPACE_URL,
        f"{_SUBSCRIPTION_NAMESPACE}:edge:{source_node_id}:{pattern_node_id}",
    )


async def _assert_agent_type_matches(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    org_agent_type_id: UUID,
    config: SupervisorAgentTypeConfig,
) -> None:
    row = cast(
        Mapping[str, Any] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
-- tenant_filter_required: supervisor type lookup is scoped by tenant; RLS also applies.
SELECT id, harness, name, max_clearance, keep_warm, current_template_version_id
FROM org_agent_type
WHERE id = $1
  AND tenant_id = $2
  AND archived_at IS NULL
""",
            org_agent_type_id,
            tenant_id,
        ),
    )
    if row is None:
        raise SupervisorSubscriptionSetupError("supervisor_agent_type_not_found")
    if row["harness"] != config.harness:
        raise SupervisorSubscriptionSetupError("supervisor_agent_type_harness_mismatch")
    if row["name"] != config.name:
        raise SupervisorSubscriptionSetupError("supervisor_agent_type_name_mismatch")
    if row["max_clearance"] != config.max_clearance:
        raise SupervisorSubscriptionSetupError("supervisor_agent_type_clearance_mismatch")
    if bool(row["keep_warm"]) != config.keep_warm:
        raise SupervisorSubscriptionSetupError("supervisor_agent_type_keep_warm_mismatch")
    if row["current_template_version_id"] is None:
        raise SupervisorSubscriptionSetupError("supervisor_agent_type_template_missing")


async def _load_pattern_type_ids(
    *,
    connection: asyncpg.Connection,
    ontology_version_id: UUID,
) -> tuple[UUID, UUID]:
    rows = cast(
        list[Mapping[str, Any]],
        await connection.fetch(  # pyright: ignore[reportUnknownMemberType]
            """
SELECT name, id
FROM ontology_type
WHERE ontology_version_id = $1
  AND name = ANY($2::text[])
  AND lifecycle_state = 'active'
""",
            ontology_version_id,
            [REACTIVE_AGENT_SOURCE_NODE_TYPE, EVENT_PATTERN_NODE_TYPE],
        ),
    )
    by_name = {str(row["name"]): cast(UUID, row["id"]) for row in rows}
    try:
        return by_name[REACTIVE_AGENT_SOURCE_NODE_TYPE], by_name[EVENT_PATTERN_NODE_TYPE]
    except KeyError as exc:
        raise SupervisorSubscriptionSetupError("supervisor_event_pattern_type_missing") from exc


async def _insert_node_once(
    *,
    connection: asyncpg.Connection,
    node_id: UUID,
    type_id: UUID,
    context: Mapping[str, object],
    metadata: Mapping[str, object],
    authored_by_principal_id: UUID,
) -> bool:
    row = cast(
        Mapping[str, Any] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
INSERT INTO nodes (
  id, type_id, context_of_validity, body, metadata, authored_by_principal_id
)
VALUES ($1, $2, $3::jsonb, '', $4::jsonb, $5)
ON CONFLICT DO NOTHING
RETURNING id
""",
            node_id,
            type_id,
            _json(context),
            _json(metadata),
            authored_by_principal_id,
        ),
    )
    return row is not None


async def _insert_subscription_edge_once(
    *,
    connection: asyncpg.Connection,
    edge_id: UUID,
    tenant_id: UUID,
    source_node_id: UUID,
    pattern_node_id: UUID,
    classification: str,
    authored_by_principal_id: UUID,
) -> bool:
    row = cast(
        Mapping[str, Any] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
INSERT INTO edges (
  id, tenant_id, source_node_id, target_node_id, relationship_type,
  classification, authored_by_principal_id
)
VALUES ($1, $2, $3, $4, 'subscribes-to', $5, $6)
ON CONFLICT DO NOTHING
RETURNING id
""",
            edge_id,
            tenant_id,
            source_node_id,
            pattern_node_id,
            classification,
            authored_by_principal_id,
        ),
    )
    return row is not None


def _context(draft: SupervisorSubscriptionDraft) -> dict[str, object]:
    return {
        "tenant": str(draft.tenant_id),
        "classification": draft.classification,
        "vertical": draft.vertical,
        "ontology_version": str(draft.ontology_version_id),
        "valid_from": draft.valid_from.isoformat().replace("+00:00", "Z"),
        "valid_to": None,
    }


def _surprise_pattern_metadata(draft: SupervisorSubscriptionDraft) -> dict[str, object]:
    metadata: dict[str, object] = {
        "event_type": "surprise.recorded",
        "filter_predicate": {
            "subject_type": "surprise",
            "magnitude_gte": draft.config.event_thresholds.surprise_magnitude_gte,
            "domain": draft.config.lens_scope.domain,
            "loop_level_in": ["single", "double", "triple"],
        },
        "lens_id": str(draft.config.lens_scope.lens_id),
    }
    normalize_event_pattern_metadata(metadata)
    return metadata


def _stalled_pattern_metadata(draft: SupervisorSubscriptionDraft) -> dict[str, object]:
    metadata: dict[str, object] = {
        "event_type": "conversation.stalled",
        "filter_predicate": {
            "subject_type": "conversation",
            "requester_or_requestee_domain": draft.config.lens_scope.domain,
        },
        "lens_id": str(draft.config.lens_scope.lens_id),
    }
    normalize_event_pattern_metadata(metadata)
    return metadata


def _json(value: Mapping[str, object]) -> str:
    return json.dumps(value, separators=(",", ":"), sort_keys=True)


__all__ = [
    "SupervisorSubscriptionDraft",
    "SupervisorSubscriptionSetupError",
    "SupervisorSubscriptionSetupResult",
    "ensure_supervisor_event_subscriptions",
    "supervisor_event_pattern_node_id",
    "supervisor_source_node_id",
    "supervisor_subscription_edge_id",
]
