"""Normalize Pi-internal supervisor helper events into one AgentRun trace."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from datetime import datetime
from enum import StrEnum
from typing import Annotated, Literal, cast
from uuid import NAMESPACE_URL, UUID, uuid5

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from skaldos.agents.contracts import JsonValue, PiEventKind
from skaldos.agents.trace import ExecutionTracePayload, TraceActionMode, TraceProtocol

_HELPER_TRACE_NAMESPACE = "skaldos.supervisor_helper_trace.v1"
_FORBIDDEN_HELPER_KEYS = frozenset(
    {
        "api_key",
        "apikey",
        "authorization",
        "base_url",
        "body",
        "content",
        "credentials",
        "env",
        "messages",
        "model_output",
        "model_response",
        "openai_api_key",
        "prompt",
        "provider_payload",
        "raw_model_response",
        "raw_prompt",
        "raw_response",
        "reasoning",
        "response",
        "response_text",
        "sandbox_env",
        "secret",
        "source_body",
        "stderr",
        "stdout",
        "text",
        "token",
        "transcript",
    }
)
_SAFE_PAYLOAD_KEYS = frozenset(
    {
        "alternatives",
        "confidence",
        "conversation_id",
        "execution_trace_ids",
        "graph_node_ids",
        "helper_role",
        "outbox_event_hash",
        "proposed_action",
        "reason_codes",
        "shield_call_id",
        "shield_call_ids",
        "surprise_id",
        "target_principal_id",
    }
)


class SupervisorHelperEventKind(StrEnum):
    """Pi helper event kinds consumed by Hall for supervisor traces."""

    STARTED = "helper.started"
    COMPLETED = "helper.completed"
    FAILED = "helper.failed"
    VERDICT = "helper.verdict"
    HANDOFF_EVALUATED = "handoff.evaluated"
    CONVERSATION_ACTION_PROPOSED = "conversation.action.proposed"


class SupervisorHelperEvent(BaseModel):
    """Content-free helper event emitted inside one supervisor Pi run."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    protocol_version: Literal["skaldos.supervisor.helper_event.v1"] = (
        "skaldos.supervisor.helper_event.v1"
    )
    kind: SupervisorHelperEventKind
    helper_event_id: UUID
    agent_run_id: UUID
    sequence: Annotated[int, Field(ge=0)]
    runtime_timestamp: datetime
    helper_id: Annotated[str, Field(pattern=r"^[a-z][a-z0-9_.-]{0,63}$")]
    helper_role: Annotated[str, Field(pattern=r"^[a-z][a-z0-9_.-]{0,63}$")]
    shield_call_id: UUID | None = None
    payload: dict[str, JsonValue] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _payload_is_content_free(self) -> SupervisorHelperEvent:
        _reject_forbidden(self.payload)
        return self

    @field_validator("payload", mode="before")
    @classmethod
    def _keep_safe_payload_keys(cls, value: object) -> dict[str, JsonValue]:
        if not isinstance(value, Mapping):
            return {}
        raw = cast(Mapping[object, object], value)
        _reject_forbidden(raw)
        return {
            str(key): cast(JsonValue, nested)
            for key, nested in raw.items()
            if str(key) in _SAFE_PAYLOAD_KEYS
        }


def normalize_supervisor_helper_event(
    raw_event: SupervisorHelperEvent | Mapping[str, object],
) -> ExecutionTracePayload:
    """Convert one helper event to a stable content-free ExecutionTrace payload."""

    event = _event_from_raw(raw_event)
    payload = event.payload
    payload_shield_call_id = payload.get("shield_call_id")
    shield_call_ids = _dedupe_uuids(
        [
            *(_uuid_sequence(payload.get("shield_call_ids"))),
            *(() if payload_shield_call_id is None else (UUID(str(payload_shield_call_id)),)),
            *(() if event.shield_call_id is None else (event.shield_call_id,)),
        ]
    )
    return ExecutionTracePayload(
        execution_trace_id=supervisor_helper_trace_id(
            agent_run_id=event.agent_run_id,
            helper_event_id=event.helper_event_id,
        ),
        agent_run_id=event.agent_run_id,
        pi_event_id=event.helper_event_id,
        step_index=event.sequence,
        pi_event_kind=_pi_event_kind(event.kind),
        action_mode=_action_mode(event.kind),
        protocol_used=TraceProtocol.ANALYTICAL,
        confidence=_confidence(payload.get("confidence")),
        shield_call_ids=shield_call_ids,
        input_node_ids=_uuid_sequence(payload.get("graph_node_ids")),
        input_trace_ids=_uuid_sequence(payload.get("execution_trace_ids")),
        alternatives=_string_sequence(payload.get("alternatives")),
        reason_codes=_helper_reason_codes(event),
    )


def supervisor_helper_trace_id(*, agent_run_id: UUID, helper_event_id: UUID) -> UUID:
    """Stable helper trace id for DBOS retry/replay of the same helper event."""

    return uuid5(NAMESPACE_URL, f"{_HELPER_TRACE_NAMESPACE}:{agent_run_id}:{helper_event_id}")


def _event_from_raw(
    raw_event: SupervisorHelperEvent | Mapping[str, object],
) -> SupervisorHelperEvent:
    if isinstance(raw_event, SupervisorHelperEvent):
        return raw_event
    return SupervisorHelperEvent.model_validate(raw_event)


def _pi_event_kind(kind: SupervisorHelperEventKind) -> PiEventKind:
    match kind:
        case SupervisorHelperEventKind.FAILED:
            return PiEventKind.VERIFIER_VERDICT
        case SupervisorHelperEventKind.STARTED:
            return PiEventKind.VERIFIER_STARTED
        case _:
            return PiEventKind.VERIFIER_VERDICT


def _action_mode(kind: SupervisorHelperEventKind) -> TraceActionMode:
    if kind in {
        SupervisorHelperEventKind.HANDOFF_EVALUATED,
        SupervisorHelperEventKind.CONVERSATION_ACTION_PROPOSED,
    }:
        return TraceActionMode.STABILIZE
    return TraceActionMode.PROBE


def _helper_reason_codes(event: SupervisorHelperEvent) -> tuple[str, ...]:
    codes = [f"helper:{event.helper_role}", event.kind.value.replace(".", "_")]
    codes.extend(_string_sequence(event.payload.get("reason_codes")))
    proposed_action = event.payload.get("proposed_action")
    if isinstance(proposed_action, str):
        codes.append(f"action:{proposed_action}")
    return tuple(codes)


def _reject_forbidden(value: object) -> None:
    if isinstance(value, str):
        lowered = value.lower()
        normalized = lowered.replace("-", "_").replace(".", "_").replace(":", "_")
        tokens = {part for part in normalized.split("_") if part}
        if (
            lowered in _FORBIDDEN_HELPER_KEYS
            or normalized in _FORBIDDEN_HELPER_KEYS
            or any(forbidden in normalized for forbidden in _FORBIDDEN_HELPER_KEYS)
            or tokens & _FORBIDDEN_HELPER_KEYS
        ):
            raise ValueError("supervisor_helper_payload_content_rejected")
        return
    if isinstance(value, Mapping):
        mapping = cast(Mapping[object, object], value)
        for key, nested in mapping.items():
            _reject_forbidden(str(key))
            _reject_forbidden(nested)
        return
    if isinstance(value, list | tuple):
        sequence = cast(Sequence[object], value)
        for nested in sequence:
            _reject_forbidden(nested)


def _uuid_sequence(value: object) -> tuple[UUID, ...]:
    if not isinstance(value, Sequence) or isinstance(value, str):
        return ()
    sequence = cast(Sequence[object], value)
    return tuple(UUID(str(item)) for item in sequence)


def _string_sequence(value: object) -> tuple[str, ...]:
    if not isinstance(value, Sequence) or isinstance(value, str):
        return ()
    sequence = cast(Sequence[object], value)
    return tuple(str(item) for item in sequence)


def _confidence(value: object) -> float | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int | float):
        return None
    return float(value)


def _dedupe_uuids(values: Sequence[UUID]) -> tuple[UUID, ...]:
    seen: set[UUID] = set()
    ordered: list[UUID] = []
    for value in values:
        if value not in seen:
            seen.add(value)
            ordered.append(value)
    return tuple(ordered)


__all__ = [
    "SupervisorHelperEvent",
    "SupervisorHelperEventKind",
    "normalize_supervisor_helper_event",
    "supervisor_helper_trace_id",
]
