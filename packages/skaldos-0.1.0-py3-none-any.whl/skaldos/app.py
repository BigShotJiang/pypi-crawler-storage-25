"""SkaldOS v2 FastAPI application factory (Slice 2, engine T2 + T4 + rate-limit T3 + T4 + T5).

Per ``docs/slices/slice-2-authorization/policy-module-and-chokepoint/``
``03-technical-implementation.md`` § "Module layout" and
``05-task-list.md`` § T2 + T4; plus rate-limit T3 + T4 + T5
(``docs/slices/slice-2-authorization/tiered-rate-limiter/05-task-list.md``
§ T3 + T4 + T5):

This module owns the top-level :class:`fastapi.FastAPI` instance and
the assembly of the production app:

- ``app = FastAPI(title="SkaldOS API", version=..., openapi_version="3.1.0")``
- ``app.include_router(public_router)`` (``GET /health``, ``GET /readyz``)
- ``register_whoami_if_enabled(app)`` (Slice 1's ``/whoami`` stays on
  bare ``Depends(current_principal)``; DO NOT flip to ``Depends(authorize)``
  until engine T11 / verification T2)

Pool lifecycle (engine T4 + rate-limit T3)
------------------------------------------

Three asyncpg pools are managed by the lifespan:

1. **Runtime pool** (``app_runtime``, RLS-bound) — the post-resolution
   path for handler queries.  Wired to ``app.state.runtime_pool``.
2. **Chokepoint pool** (``app_chokepoint``, BYPASSRLS) — the
   pre-resolution path for the principal lookup that runs *before* the
   PC1 GUC contract is committed.  Wired to ``app.state.chokepoint_pool``.
3. **Rate-limit pool** (``app_runtime``, dedicated for §14.7 counter) —
   small (2-10 conns), 1s command timeout; isolated from the handler
   pool so a counter stall does not block real traffic. Wired to
   ``app.state.rate_limit_pool``.

All three pools are opened at startup and closed cleanly at shutdown.
The resolver's :func:`~skaldos.middleware.hydration.current_principal`
dependency acquires from ``app.state.chokepoint_pool`` for principal
lookup, then from ``app.state.runtime_pool`` for the GUC-bearing handler
transaction.

See :mod:`skaldos.policy.pool` for the chokepoint pool's security
rationale and :mod:`skaldos.policy.rate_limit.pool` for the rate-limit
pool's sizing rationale.

OpenAPI 3.1
-----------

FastAPI 0.100+ defaults to OpenAPI 3.1 when ``openapi_version="3.1.0"``
is passed. Per §10.2 (OpenAPI is the contract) the spec version is
pinned explicitly so downstream tools (Zod codegen, MCP error decoder)
can assert the version rather than guessing.

Production gating (AP5)
-----------------------

``/whoami`` is registered via :func:`~skaldos.api.whoami.register_whoami_if_enabled`
which checks ``SKALDOS_ENV != "production"`` at registration time.
The decision is structural; no runtime branch. AP5: no debug bypass.

References: §10.2 (OpenAPI 3.1 as contract); §14.7 (rate-limit pool);
§14.11 (four roles; chokepoint is the fourth); AP5 (no bypass ---
registration-time gate, not runtime); Slice 1 followups #3 (T4 wires
the chokepoint pool through the T3 role migration); Slice 1 followups
#9 (T11 adds ``responses=PROTECTED_ROUTE_RESPONSES`` to ``/whoami``);
``03-technical-implementation.md`` § "Architecture" + § "Fault lines"
F1 + F6; ``05-task-list.md`` § T2 + T4; rate-limit T3
``05-task-list.md``.
"""

from __future__ import annotations

import os
from collections.abc import AsyncGenerator
from contextlib import AsyncExitStack, asynccontextmanager
from dataclasses import dataclass

from fastapi import FastAPI
from httpx import AsyncClient
from opentelemetry import trace
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from opentelemetry.sdk.trace import TracerProvider
from skaldos_log import log, register_auto_instrumentation

from skaldos._test_only import register_test_only_routes_if_enabled
from skaldos.agents import LocalDBOSAgentWorkflowAdapter
from skaldos.api._public import router as public_router
from skaldos.api.agent_runs import router as agent_runs_router
from skaldos.api.calibration import router as calibration_router
from skaldos.api.e2b_webhooks import router as e2b_webhooks_router
from skaldos.api.event_subscriptions import router as event_subscriptions_router
from skaldos.api.graph_assert import router as graph_assert_router
from skaldos.api.graph_context import router as graph_context_router
from skaldos.api.graph_lens import router as graph_lens_router
from skaldos.api.graph_nodes import router as graph_nodes_router
from skaldos.api.graph_search import router as graph_search_router
from skaldos.api.graph_source_snapshot import router as graph_source_snapshot_router
from skaldos.api.graph_traverse import router as graph_traverse_router
from skaldos.api.me import router as me_router
from skaldos.api.pubsub_webhooks import router as pubsub_webhooks_router
from skaldos.api.whoami import register_whoami_if_enabled
from skaldos.auth.fastapi import auth_lifespan
from skaldos.db import close_pool, get_pool
from skaldos.middleware import add_cors_middleware
from skaldos.policy.authorize import (
    register_authorization_exception_handlers,
    register_route_tiers,
)
from skaldos.policy.intent import validate_intent_table_consistency
from skaldos.policy.pool import close_chokepoint_pool, init_chokepoint_pool
from skaldos.policy.rate_limit.config import RateLimitSettings
from skaldos.policy.rate_limit.pool import close_rate_limit_pool, init_rate_limit_pool
from skaldos.policy.rate_limit.pre_hook import register_rate_limit_pre_hook
from skaldos.sandbox.e2b import E2BConfigError, E2BSandboxControlPlane
from skaldos.shield_runtime import (
    build_node_chunk_embedding_runtime,
    build_search_query_shield_client,
    build_shield_client,
)

__all__ = ["app", "create_app"]

_APP_TITLE = "SkaldOS API"
_APP_VERSION = "2.0.0"
_DEFAULT_AGENT_API_BASE_URL = "https://api.skaldos.test"
_DEFAULT_SHIELD_BASE_URL = "https://shield.skaldos.test"
_TRUE_ENV_VALUES = frozenset({"1", "true", "yes", "on"})


@dataclass(frozen=True)
class AgentRunProductionReadinessCheck:
    """One content-free production AgentRun enablement check."""

    name: str
    ready: bool
    reason_code: str


@dataclass(frozen=True)
class AgentRunProductionReadiness:
    """Content-free production AgentRun route enablement summary."""

    ready: bool
    checks: tuple[AgentRunProductionReadinessCheck, ...]


@asynccontextmanager
async def _app_lifespan(fastapi_app: FastAPI) -> AsyncGenerator[None, None]:
    """Lifespan context manager: open all three pools on startup; close on shutdown.

    Manages three asyncpg pools (engine T4 added the chokepoint + runtime
    pair, rate-limit T3 added the §14.7 counter pool):

    1. **Runtime pool** (``DATABASE_URL`` → ``app_runtime`` role) — the
       post-resolution path for handler queries; stored on
       ``app.state.runtime_pool``.  RLS-bound: every query runs under the
       PC1 GUC contract committed by the principal-resolution step.

    2. **Chokepoint pool** (``CHOKEPOINT_POOL_DSN`` → ``app_chokepoint``
       BYPASSRLS role) — the pre-resolution path for the principal lookup;
       stored on ``app.state.chokepoint_pool``.  Bypasses RLS so the
       resolver can read ``principals`` before the GUC is set.

    3. **Rate-limit pool** (``RATE_LIMIT_POOL_DSN`` / ``DATABASE_URL`` →
       ``app_runtime``) — the §14.7 counter pool; stored on
       ``app.state.rate_limit_pool``.  Small (2-10 conns), 1s command
       timeout; the counter must not block real traffic.

    All three pools are opened first (the log lines emit *before* the
    first request is accepted); all are closed cleanly on shutdown.

    **Security note.** The absence of the bootstrap-superuser DSN from
    any startup log is the manual-verification criterion for T4 (per
    ``05-task-list.md`` § T4 verification).  The log lines emit pool
    sizing values but never the DSN itself.

    References: §14.7 (rate-limit pool); §14.11 (chokepoint pool);
    Slice 1 followups #3; ``03-technical-implementation.md`` § "Fault
    lines" F1 + F6.
    """
    async with AsyncExitStack() as stack:
        await stack.enter_async_context(auth_lifespan(fastapi_app))

        # Open all three pools. Errors here surface before any request is served.
        runtime_pool = await get_pool()
        chokepoint_pool = await init_chokepoint_pool()
        rate_limit_pool = await init_rate_limit_pool()
        shield_http_client = AsyncClient(timeout=30.0)
        stack.push_async_callback(shield_http_client.aclose)
        stack.push_async_callback(close_rate_limit_pool, rate_limit_pool)
        stack.push_async_callback(close_chokepoint_pool, chokepoint_pool)
        stack.push_async_callback(close_pool)

        fastapi_app.state.runtime_pool = runtime_pool
        fastapi_app.state.chokepoint_pool = chokepoint_pool
        fastapi_app.state.rate_limit_pool = rate_limit_pool
        fastapi_app.state.shield_http_client = shield_http_client
        shield_client = build_shield_client(http_client=shield_http_client)
        if shield_client is not None:
            fastapi_app.state.shield_client = shield_client
        search_query_shield = build_search_query_shield_client(http_client=shield_http_client)
        if search_query_shield is not None:
            shield_client, query_hash_key, environment_id = search_query_shield
            fastapi_app.state.shield_client = shield_client
            fastapi_app.state.search_query_hash_key = query_hash_key
            fastapi_app.state.search_query_hash_environment_id = environment_id
        node_chunk_embedding_runtime = await build_node_chunk_embedding_runtime()
        if node_chunk_embedding_runtime is not None:
            stack.push_async_callback(node_chunk_embedding_runtime.close)
            fastapi_app.state.node_chunk_embedding_generator = (
                node_chunk_embedding_runtime.generator
            )
        # The pool-startup log lines fire inside an ``app.pool.startup`` span so
        # the §20.4 ``enforce_active_span`` processor is satisfied. Without the
        # span wrapper these emissions trip ``LogWithoutSpanError`` at uvicorn
        # boot — the production app's lifespan is not instrumented by
        # FastAPIInstrumentor (which wraps inbound *requests*, not the lifespan
        # context). Same idiom as ``_emit_rate_limit_startup_log`` (Slice 2
        # followups #9).
        with _startup_tracer.start_as_current_span("app.pool.startup"):
            log.info(
                "chokepoint.pool.startup",
                pool_min_size=chokepoint_pool.get_min_size(),  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
                pool_max_size=chokepoint_pool.get_max_size(),  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
            )
            log.info(
                "runtime.pool.startup",
                pool_min_size=runtime_pool.get_min_size(),  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
                pool_max_size=runtime_pool.get_max_size(),  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
            )
            log.info(
                "rate_limit.pool.startup",
                pool_min_size=rate_limit_pool.get_min_size(),  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
                pool_max_size=rate_limit_pool.get_max_size(),  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
            )

        # Rate-limit startup audit log (rate-limit T5, §14.7, §20.1, §20.4, MP7).
        # Fires at app startup (inside the lifespan) so the active OTel span
        # requirement (§20.4) is satisfied — the helper opens its own
        # ``policy.startup`` span. Emitted here rather than in create_app() so
        # tests can monkeypatch env vars before the log fires.
        _emit_rate_limit_startup_log()

        try:
            yield
        finally:
            pubsub_push_http_client = getattr(
                fastapi_app.state,
                "pubsub_push_subscriber_http_client",
                None,
            )
            if pubsub_push_http_client is not None:
                await pubsub_push_http_client.aclose()
            with _startup_tracer.start_as_current_span("app.pool.shutdown"):
                log.info("rate_limit.pool.shutdown")
                log.info("chokepoint.pool.shutdown")
                log.info("runtime.pool.shutdown")


_startup_tracer = trace.get_tracer(__name__)


def _emit_rate_limit_startup_log() -> None:
    """Emit the ``rate_limit.startup`` structured audit log line (rate-limit T5).

    Reads a fresh :class:`~skaldos.policy.rate_limit.config.RateLimitSettings`
    instance at call time (so tests that monkeypatch env vars see the patched
    values) and logs the four config fields safelisted in the contract pin:

    - ``enabled`` — global on/off switch.
    - ``env`` — value of ``SKALDOS_ENV`` (default ``"development"``).
    - ``fail_mode`` — ``"fail_open"`` or ``"fail_closed"``.
    - ``shadow_mode`` — ``True`` / ``False``.
    - ``override_limits`` — serialised as ``{tier.value: int}`` (empty dict
      when all tiers use §14.7 binding defaults).

    A second ``rate_limit.startup_disabled_in_production`` warning line is
    emitted when the limiter is disabled (``enabled=False``) in a production
    environment.  Alert wiring is deferred to Slice 5+; this log line makes
    the alert wirable now.

    The log fires inside a ``policy.startup`` OTel span so §20.4's
    ``enforce_active_span`` processor is satisfied in all environments
    (including the synchronous ``create_app()`` call path used in tests).

    References: §14.7 (rate-limit config); §20.1 (structured logs); §20.4
    (active-span enforcement); MP7 (phased rollouts); ``05-task-list.md`` § T5.
    """
    settings = RateLimitSettings()
    skaldos_env = os.environ.get("SKALDOS_ENV", "development")

    # Serialise override_limits as {str: int} for the log line (Tier is a
    # StrEnum so its .value is the canonical string key).
    override_limits_serialised = {
        tier.value: limit for tier, limit in settings.override_limits.items()
    }

    with _startup_tracer.start_as_current_span("policy.startup"):
        log.info(
            "rate_limit.startup",
            enabled=settings.enabled,
            env=skaldos_env,
            fail_mode=settings.fail_mode,
            shadow_mode=settings.shadow_mode,
            override_limits=override_limits_serialised,
        )

        # Production guard: warn when the rate-limiter is disabled.
        # Alert wiring (Slice 5+) subscribes to this event; Slice 2 emits
        # the structured log so the alert is wirable without a code change.
        if not settings.enabled and skaldos_env == "production":
            log.warning(
                "rate_limit.startup_disabled_in_production",
                enabled=False,
                env=skaldos_env,
            )


def _install_tracer_provider_if_needed() -> None:
    """Install a real :class:`TracerProvider` if the global is still the no-op.

    OTel's default tracer provider is non-recording: spans created from it
    have an invalid span context, so :func:`skaldos_log.processors.attach_otel_context`
    cannot stamp ``trace_id`` on the event dict, and §20.4's
    :func:`enforce_active_span` treats every log line as span-less and raises
    ``LogWithoutSpanError`` (the failure mode that crashed end-of-Slice-2 boot
    probes — Slice 2 followups #10).

    This helper installs a bare SDK :class:`TracerProvider` (recording, no
    exporter) so the chokepoint contract holds end-to-end at uvicorn boot.
    Idempotent: if a real provider is already installed (test autouse fixtures,
    or a future operator-supplied OTLP-exporting provider), the existing
    provider is left in place. The OTel SDK only honours one
    ``set_tracer_provider`` call — re-setting silently warns and no-ops — so
    the idempotency check guards against tests' fixtures being overridden.

    OTLP export (sending spans to ``OTEL_EXPORTER_OTLP_ENDPOINT``) is a
    separate operator-side wiring step deferred to the production OTel
    collector follow-up: install
    ``opentelemetry-exporter-otlp-proto-grpc``, then attach a
    :class:`BatchSpanProcessor` with an ``OTLPSpanExporter``. The bare
    provider here satisfies the §20.4 contract regardless of whether the
    exporter is wired downstream.
    """
    current = trace.get_tracer_provider()
    if isinstance(current, TracerProvider):
        return
    trace.set_tracer_provider(TracerProvider())


def create_app() -> FastAPI:
    """Construct and return the production FastAPI app.

    Separated from the module-level :data:`app` so integration tests
    can call ``create_app()`` to get a fresh, un-instrumented app
    instance without sharing global state with the production singleton.

    Assembly order:

    0. Install a real :class:`TracerProvider` if the global is still the
       no-op default (Slice 2 followups #10) — otherwise the pool-startup
       log lines below trip §20.4's :func:`enforce_active_span` at boot
       even with the span wrapper from followups #9.
    0b. Wire OTel auto-instrumentation for ``fastapi`` / ``httpx`` /
        ``asyncpg`` (Slice 2 followups #13) so every inbound request
        gets a server-kind span and every log line emitted inside a
        handler carries the request's ``trace_id``.  Without this,
        hydration's ``principal.hydrated``, the chokepoint's
        ``authorization.decision`` (when the route's dependency tree
        runs outside the ``policy.authorize`` span), and any handler-
        body emit fire outside any active span — ``LogWithoutSpanError``
        in dev/test, ``log.without_span`` sentinel rewriting in
        production (which silently dead-letters the runbook's
        authoritative pivots).
    1. Construct :class:`fastapi.FastAPI` with OpenAPI 3.1 and the
       ``_app_lifespan`` context manager (which opens all three pools at
       startup).
    1b. Wrap the constructed app with :func:`FastAPIInstrumentor.instrument_app`.
        The global instrument call in step 0b patches new ``FastAPI(...)``
        constructions for many code paths, but the per-app wrap is what
        guarantees the server-kind span around requests driven via
        ``httpx.ASGITransport`` (used in tests and in some ingress
        configurations) where the module-level patch is bypassed.
        Idempotent — sets a flag on the app and short-circuits if the
        instrumentation is already attached.
    2. Register CORS middleware (must be before route registration so
       ``OPTIONS`` preflights short-circuit before dependency resolution).
    3. Include :data:`~skaldos.api._public.router` (``/health``,
       ``/readyz``).
    4. Call :func:`~skaldos.api.whoami.register_whoami_if_enabled`
       (mounts ``/whoami`` iff ``SKALDOS_ENV != "production"``).
    4b. Call :func:`~skaldos._test_only.register_test_only_routes_if_enabled`
        (mounts ``/api/_test_only/...`` iff ``SKALDOS_ENV != "production"``).
        AP5: registration-time gate; absent in production.
    5. Call :func:`~skaldos.policy.rate_limit.pre_hook.register_rate_limit_pre_hook`
       (mounts the §14.7 limiter hook at priority 1 — rate-limit T4).
    6. Emit ``rate_limit.startup`` audit log (rate-limit T5): enabled,
       env, fail_mode, shadow_mode, override_limits.  A warning is
       added when ``enabled=False`` in production.
    7. Call :func:`~skaldos.policy.authorize.register_authorization_exception_handlers`
       (engine T7 + rate-limit T4: maps ``RateLimitExceeded → 429``,
       ``AuthorizationError → 403``, ``IntentRequiredError → 422``, etc.).
    8. Append the engine-T6 intent-table validation hook to
       ``app.router.on_startup`` (compiles + walks routes; no false
       positives on the empty-route case).

    Returns
    -------
    :class:`fastapi.FastAPI`
        The assembled application.
    """
    _install_tracer_provider_if_needed()

    # Wire FastAPI / httpx / asyncpg auto-instrumentation BEFORE app
    # construction.  ``register_auto_instrumentation`` is idempotent
    # across processes (test fixtures may have called it already; the
    # second call returns ``already_installed`` for matching names).
    # ``only=("fastapi", "httpx", "asyncpg")`` matches the established
    # test idiom (cf. ``test_log_concurrent_request_isolation.py``) so
    # production and tests run with the same instrumentation surface.
    register_auto_instrumentation(only=("fastapi", "httpx", "asyncpg"))

    app = FastAPI(
        title=_APP_TITLE,
        version=_APP_VERSION,
        openapi_version="3.1.0",
        summary="SkaldOS v2 substrate API.",
        description=(
            "The SkaldOS v2 API. Every protected route passes through the "
            "``can()`` chokepoint (``Depends(authorize(action, subject_kind))``). "
            "Public routes (``/health``, ``/readyz``, ``/openapi.json``, "
            "``/docs``, ``/redoc``) require no JWT. "
            "See ``services/api/skaldos/api/_public.py`` for the public-route "
            "allowlist and ``services/api/skaldos/policy/`` for the authorization "
            "package (wired in Slice 2 T4–T11)."
        ),
        lifespan=_app_lifespan,
    )
    app.state.search_query_embedder_required = (
        os.environ.get("SKALDOS_ENV", "development") == "production"
    )
    agent_run_readiness = _agent_run_production_readiness_from_env()
    app.state.agent_run_production_readiness = agent_run_readiness
    app.state.agent_workflow_starter = _configured_agent_workflow_starter(
        agent_run_readiness=agent_run_readiness
    )
    app.state.agent_api_base_url = _configured_agent_base_url(
        env_var="SKALDOS_AGENT_API_BASE_URL",
        default=_DEFAULT_AGENT_API_BASE_URL,
    )
    app.state.shield_base_url = _configured_agent_base_url(
        env_var="SKALDOS_SHIELD_BASE_URL",
        default=_DEFAULT_SHIELD_BASE_URL,
    )
    app.state.sandbox_control_plane = _configured_sandbox_control_plane()

    # Per-app FastAPI instrumentation (Slice 2 followups #13).  The
    # global hook above patches new ``FastAPI(...)`` constructions for
    # many code paths; for ``httpx.ASGITransport``-driven requests
    # (tests, some ingress configurations) the per-app wrap is what
    # opens the server-kind span around every inbound request.
    # Idempotent: sets ``_is_instrumented_by_opentelemetry`` on the
    # app and skips on a second call.
    FastAPIInstrumentor.instrument_app(app)  # pyright: ignore[reportUnknownMemberType]

    # CORS middleware first --- must short-circuit before dependency
    # resolution runs, so OPTIONS preflights to protected routes return
    # 200 without requiring a JWT (E23 from the Slice 1 edge cases).
    add_cors_middleware(app)

    # Public routes: /health, /readyz.
    app.include_router(public_router)

    # Public provider callback. The handler verifies E2B's raw-body signature
    # before it binds tenant context or mutates sandbox lifecycle rows.
    app.include_router(e2b_webhooks_router)

    # Public Pub/Sub callback. The handler verifies Google OIDC plus SkaldOS
    # HMAC before it records content-free receipt evidence or refetches.
    app.include_router(pubsub_webhooks_router)

    # /whoami (Slice 1 slice-gate route). Stays on bare
    # Depends(current_principal) --- DO NOT flip to Depends(authorize)
    # until engine T11 / verification T2 (master plan ADR decision:
    # "/whoami is the third disjoint-set category alongside
    # PUBLIC_ROUTES and PROTECTED_ROUTES; WHOAMI_ROUTES = {'/whoami'}").
    register_whoami_if_enabled(app)

    # Slice 4 write chokepoint. Protected production route; every graph write
    # surface converges here before staging.
    app.include_router(graph_assert_router)

    # Slice 6 graph read path. Protected traversal route with recursive CTE
    # visibility predicates in the service SQL.
    app.include_router(graph_traverse_router)

    # slice-frontend-api-gaps: production-safe identity surface for the
    # Phase 2 frontend's app shell.  Registered in every environment
    # (including production) — access is governed by the chokepoint,
    # not the env (E24 / AP5). Distinct from /whoami (Slice 1 chokepoint
    # gate target, gated off in production).
    app.include_router(me_router)

    # slice-frontend-api-gaps: protected node-detail projection for the
    # Phase 2 frontend's node workspace.  One round-trip for summary +
    # tags + related neighborhood + source-snapshot handle.
    app.include_router(graph_nodes_router)

    # Slice 6 graph search path. Protected route; branch SQL starts from one
    # visible-candidate CTE before lexical ranking.
    app.include_router(graph_search_router)

    # Slice 6 context and metric read path. Protected routes; service SQL
    # consumes the same visible NodeTag predicates and read-audit policy.
    app.include_router(graph_context_router)

    # Slice 7 read-and-summarize source read path. Protected route returning
    # one visible node body/version/hash snapshot for agent tool input.
    app.include_router(graph_source_snapshot_router)

    # Slice 6 lens definitions. Protected routes; lenses rank only and never
    # gate visibility.
    app.include_router(graph_lens_router)

    # Slice 8 external event subscription control plane. Protected tenant-scoped
    # integration routes only; event fan-out remains post-commit.
    app.include_router(event_subscriptions_router)

    # Slice 9 classifier calibration/trust read model. Protected, read-only,
    # handle/count metadata only; no public score or threshold mutation route.
    app.include_router(calibration_router)

    # Slice 7/11 AgentRun launch. Local/dev uses the Postgres-backed DBOS
    # replay adapter. Production registration remains closed until the explicit
    # Slice 11 readiness inventory says the worker/runtime, Shield/KMS, E2B,
    # and trace/log evidence posture is configured.
    if os.environ.get("SKALDOS_ENV", "development") != "production" or agent_run_readiness.ready:
        app.include_router(agent_runs_router)

    # Fixture-only handlers (Slice 2 verification T1).
    # AP5 idiom: registration-time gate (not runtime); absent in production.
    # These handlers go through Depends(authorize) — the real chokepoint.
    # See services/api/skaldos/_test_only/__init__.py for the full contract.
    register_test_only_routes_if_enabled(app)

    # Rate-limit pre-hook (rate-limit T4, §14.7).
    # Mounts rate_limit_pre_hook at priority 1 (the reserved slot for
    # the §14.7 limiter; future hooks declare higher priorities). Must
    # be registered BEFORE the authorization exception handlers so the
    # hook fires on every Depends(authorize(...)) invocation.
    register_rate_limit_pre_hook(app)

    # Authorization exception handlers (engine T7 + rate-limit T4, §4.1, §14.7, ADR 2).
    # Maps exceptions to their canonical HTTP statuses:
    #   RateLimitExceeded    → 429 + Retry-After header (rate-limit T4)
    #   SubjectNotFoundError → 404
    #   IntentRequiredError  → 422
    #   IntentNotAllowedError → 422
    #   AuthorizationError   → 403
    # Must be registered before any route that uses Depends(authorize(...)).
    register_authorization_exception_handlers(app)

    # Intent-table consistency check (engine T6, §10.12, F3).
    # Walks all routes with Depends(authorize(...)) and asserts each
    # declared intent is in ALLOWED_INTENTS[(action, subject_kind)].
    # On an empty app (before T7 wires the authorize factory) the hook
    # returns immediately — no false positives.
    # wired in T6 (intent table validation)
    def _check_intents() -> None:
        validate_intent_table_consistency(app)

    app.router.on_startup.append(_check_intents)

    # Route-tier registration (Slice 2 followups #4).  Walks every
    # ``Depends(authorize(...))``-bearing route and stamps ``route.tier``
    # from the route's ``_authorize_meta.tier``.  Runs at app-assembly
    # time (synchronously, before the lifespan opens) — the rate-limit
    # pre-hook then reads ``route.tier`` per request via
    # ``classify_route``.  On routes that don't carry the marker (public
    # routes, ``/whoami``), the hook is a no-op.
    register_route_tiers(app)

    return app


def _configured_agent_base_url(*, env_var: str, default: str) -> str:
    configured = os.environ.get(env_var)
    if configured:
        return configured.rstrip("/")
    if os.environ.get("SKALDOS_ENV", "development") == "production":
        return ""
    return default


def _configured_agent_workflow_starter(
    *, agent_run_readiness: AgentRunProductionReadiness
) -> object | None:
    if (
        os.environ.get("SKALDOS_ENV", "development") == "production"
        and not agent_run_readiness.ready
    ):
        return None
    return LocalDBOSAgentWorkflowAdapter()


def _agent_run_production_readiness_from_env() -> AgentRunProductionReadiness:
    """Evaluate explicit, content-free production AgentRun enablement checks.

    The checks are intentionally local/env-shaped. They do not contact KMS,
    Shield, E2B, or observability backends, and therefore do not claim staging
    or production readiness. Their job is to keep production route registration
    fail-closed unless operators have supplied every substrate signal Slice 11
    requires before AgentRun clients can depend on the API surface.
    """

    if os.environ.get("SKALDOS_ENV", "development") != "production":
        checks = (
            AgentRunProductionReadinessCheck(
                name="environment",
                ready=False,
                reason_code="agent_run_production_readiness_not_required",
            ),
        )
        return AgentRunProductionReadiness(ready=False, checks=checks)

    checks = (
        _readiness_bool(
            "production_enablement",
            "SKALDOS_AGENT_RUN_PRODUCTION_ENABLED",
            "agent_run_production_enablement_missing",
        ),
        _readiness_equals(
            "worker_runtime",
            "SKALDOS_AGENT_WORKER_RUNTIME",
            "dbos",
            "agent_run_worker_runtime_unconfigured",
        ),
        _readiness_nonempty(
            "worker_queue",
            "SKALDOS_AGENT_WORKER_QUEUE",
            "agent_run_worker_queue_unconfigured",
        ),
        _readiness_nonempty(
            "api_base_url",
            "SKALDOS_AGENT_API_BASE_URL",
            "agent_run_api_base_url_unconfigured",
        ),
        _readiness_nonempty(
            "shield_base_url",
            "SKALDOS_SHIELD_BASE_URL",
            "agent_run_shield_base_url_unconfigured",
        ),
        _readiness_equals(
            "kms_mode",
            "SKALDOS_KMS_MODE",
            "real",
            "agent_run_kms_mode_not_real",
        ),
        _readiness_nonempty(
            "kms_project",
            "GCP_KMS_PROJECT",
            "agent_run_kms_project_unconfigured",
        ),
        _readiness_nonempty(
            "kms_location",
            "GCP_KMS_LOCATION",
            "agent_run_kms_location_unconfigured",
        ),
        _readiness_nonempty(
            "kms_keyring",
            "GCP_KMS_KEYRING",
            "agent_run_kms_keyring_unconfigured",
        ),
        _readiness_nonempty("kms_key", "GCP_KMS_KEY", "agent_run_kms_key_unconfigured"),
        _readiness_nonempty("e2b_api_key", "E2B_API_KEY", "agent_run_e2b_api_key_missing"),
        _readiness_nonempty(
            "e2b_webhook_signing_secret",
            "E2B_WEBHOOK_SIGNING_SECRET",
            "agent_run_e2b_webhook_secret_missing",
        ),
        _readiness_any_nonempty(
            "e2b_template",
            ("E2B_TEMPLATE_ID", "E2B_TEMPLATE_NAME"),
            "agent_run_e2b_template_unconfigured",
        ),
        _readiness_nonempty(
            "otel_exporter",
            "OTEL_EXPORTER_OTLP_ENDPOINT",
            "agent_run_trace_exporter_unconfigured",
        ),
        _readiness_bool(
            "trace_evidence",
            "SKALDOS_AGENT_TRACE_EVIDENCE_ENABLED",
            "agent_run_trace_evidence_unconfigured",
        ),
    )
    return AgentRunProductionReadiness(
        ready=all(check.ready for check in checks),
        checks=checks,
    )


def _readiness_bool(name: str, env_var: str, reason_code: str) -> AgentRunProductionReadinessCheck:
    return AgentRunProductionReadinessCheck(
        name=name,
        ready=os.environ.get(env_var, "").strip().lower() in _TRUE_ENV_VALUES,
        reason_code=reason_code,
    )


def _readiness_equals(
    name: str, env_var: str, expected: str, reason_code: str
) -> AgentRunProductionReadinessCheck:
    return AgentRunProductionReadinessCheck(
        name=name,
        ready=os.environ.get(env_var, "").strip().lower() == expected,
        reason_code=reason_code,
    )


def _readiness_nonempty(
    name: str, env_var: str, reason_code: str
) -> AgentRunProductionReadinessCheck:
    return AgentRunProductionReadinessCheck(
        name=name,
        ready=bool(os.environ.get(env_var, "").strip()),
        reason_code=reason_code,
    )


def _readiness_any_nonempty(
    name: str, env_vars: tuple[str, ...], reason_code: str
) -> AgentRunProductionReadinessCheck:
    return AgentRunProductionReadinessCheck(
        name=name,
        ready=any(bool(os.environ.get(env_var, "").strip()) for env_var in env_vars),
        reason_code=reason_code,
    )


def _configured_sandbox_control_plane() -> E2BSandboxControlPlane | None:
    if not os.environ.get("E2B_API_KEY"):
        return None
    try:
        return E2BSandboxControlPlane.from_env()
    except E2BConfigError:
        return None


# ---------------------------------------------------------------------------
# Production singleton
# ---------------------------------------------------------------------------
# Module-level ``app`` is the entry point for uvicorn:
#
#     uv run uvicorn services.api.skaldos.app:app --reload
#
# Tests that need a clean app instance should call ``create_app()``
# directly rather than importing this singleton.
app: FastAPI = create_app()
