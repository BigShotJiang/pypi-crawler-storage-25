"""Runtime wiring for API-side canonical Shield clients."""

from __future__ import annotations

import os
from dataclasses import dataclass

import httpx
from pydantic import AnyHttpUrl, TypeAdapter

from skaldos.graph.node_chunk_embeddings import (
    InProcessShieldNodeChunkEmbeddingGateway,
    NodeChunkEmbeddingGenerator,
)
from skaldos.shield_client import ShieldClient
from skaldos_shield.app_wiring import build_configured_shield_call_core
from skaldos_shield.contracts import CanonicalShieldRequest, CanonicalShieldResponse
from skaldos_shield.runtime_config import (
    ConfiguredRuntimeHandle,
    build_configured_runtime_from_settings,
)
from skaldos_shield.settings import ShieldSettings

_URL_ADAPTER: TypeAdapter[AnyHttpUrl] = TypeAdapter(AnyHttpUrl)
_METADATA_IDENTITY_URL = (
    "http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/identity"
)
_TRUE_ENV_VALUES = frozenset({"1", "true", "yes", "on"})


@dataclass(frozen=True, slots=True)
class NodeChunkEmbeddingRuntimeHandle:
    """API-owned handle for configured in-process NodeChunk embedding generation."""

    generator: NodeChunkEmbeddingGenerator
    shield_runtime: ConfiguredRuntimeHandle

    async def close(self) -> None:
        await self.shield_runtime.close()


class CloudRunIDTokenProvider:
    """Fetch Cloud Run service-to-service ID tokens from the metadata server."""

    def __init__(self, *, client: httpx.AsyncClient, audience: str) -> None:
        self._client = client
        self._audience = str(_URL_ADAPTER.validate_python(audience))

    async def token(self) -> str:
        response = await self._client.get(
            _METADATA_IDENTITY_URL,
            params={"audience": self._audience, "format": "full"},
            headers={"Metadata-Flavor": "Google"},
        )
        response.raise_for_status()
        token = response.text.strip()
        if not token:
            raise RuntimeError("shield_id_token_unavailable")
        return token


class HttpShieldCanonicalTransport:
    """HTTP transport for the canonical Shield completion surface."""

    def __init__(
        self,
        *,
        client: httpx.AsyncClient,
        complete_url: str,
        id_token_provider: CloudRunIDTokenProvider | None = None,
    ) -> None:
        self._client = client
        self._complete_url = str(_URL_ADAPTER.validate_python(complete_url))
        self._id_token_provider = id_token_provider

    async def complete(self, request: CanonicalShieldRequest) -> CanonicalShieldResponse:
        """Submit one canonical Shield request and parse the canonical response."""

        headers: dict[str, str] = {}
        if self._id_token_provider is not None:
            headers["Authorization"] = f"Bearer {await self._id_token_provider.token()}"
        response = await self._client.post(
            self._complete_url,
            json=request.model_dump(mode="json"),
            headers=headers,
        )
        response.raise_for_status()
        return CanonicalShieldResponse.model_validate(response.json())


def build_shield_client(*, http_client: httpx.AsyncClient) -> ShieldClient | None:
    """Build the generic runtime Shield client from explicit env config."""

    complete_url = os.environ.get("SHIELD_CANONICAL_COMPLETE_URL")
    if not complete_url:
        return None
    id_token_audience = os.environ.get("SHIELD_CANONICAL_ID_TOKEN_AUDIENCE")
    id_token_provider = (
        CloudRunIDTokenProvider(client=http_client, audience=id_token_audience)
        if id_token_audience
        else None
    )
    return ShieldClient(
        HttpShieldCanonicalTransport(
            client=http_client,
            complete_url=complete_url,
            id_token_provider=id_token_provider,
        )
    )


def build_search_query_shield_client(
    *,
    http_client: httpx.AsyncClient,
) -> tuple[ShieldClient, bytes, str] | None:
    """Build the runtime search-query Shield dependency from explicit env config."""

    query_hash_key = os.environ.get("SEARCH_QUERY_HMAC_KEY")
    shield_client = build_shield_client(http_client=http_client)
    if shield_client is None or not query_hash_key:
        return None

    query_hash_key_bytes = query_hash_key.encode("utf-8")
    if len(query_hash_key_bytes) < 32:
        raise RuntimeError("SEARCH_QUERY_HMAC_KEY must be at least 32 bytes")

    environment_id = os.environ.get(
        "SEARCH_QUERY_HASH_ENVIRONMENT_ID",
        os.environ.get("SKALDOS_ENV", "development"),
    )
    if not environment_id:
        raise RuntimeError("SEARCH_QUERY_HASH_ENVIRONMENT_ID must be non-empty")

    return (
        shield_client,
        query_hash_key_bytes,
        environment_id,
    )


async def build_node_chunk_embedding_runtime() -> NodeChunkEmbeddingRuntimeHandle | None:
    """Build configured NodeChunk embedding generation when explicitly enabled."""

    enabled = os.environ.get("SKALDOS_NODE_CHUNK_EMBEDDINGS_ENABLED", "").strip().lower()
    if enabled not in _TRUE_ENV_VALUES:
        return None

    settings = ShieldSettings()
    runtime_handle = await build_configured_runtime_from_settings(settings)
    try:
        shield_core = build_configured_shield_call_core(
            settings=settings,
            runtime=runtime_handle.runtime,
        )
        generator = NodeChunkEmbeddingGenerator(
            shield_gateway=InProcessShieldNodeChunkEmbeddingGateway(shield_core=shield_core)
        )
    except Exception:
        await runtime_handle.close()
        raise
    return NodeChunkEmbeddingRuntimeHandle(
        generator=generator,
        shield_runtime=runtime_handle,
    )


__all__ = [
    "CloudRunIDTokenProvider",
    "HttpShieldCanonicalTransport",
    "NodeChunkEmbeddingRuntimeHandle",
    "build_node_chunk_embedding_runtime",
    "build_search_query_shield_client",
    "build_shield_client",
]
