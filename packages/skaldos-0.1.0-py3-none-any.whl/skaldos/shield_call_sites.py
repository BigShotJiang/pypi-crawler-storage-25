"""Shield-gated proof call sites for Slice 5.

These scaffolds are intentionally API-side and provider-free. They give the
first embedding, search-query embedding, and one-tool agent surfaces a single
dependency: the canonical Shield client.
"""

from __future__ import annotations

from typing import Protocol, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
import httpx
from pydantic import AliasChoices, BaseModel, ConfigDict, Field

from skaldos.shield_client import ShieldCallContext, ShieldClient, text_message
from skaldos_shield.audit_records import (
    AuditTraceContext,
    ShieldPIIQueryDigest,
    current_audit_trace_context,
)
from skaldos_shield.contracts import (
    LatencyMode,
    RouteMetadata,
    SensitivityTier,
    ShieldMessage,
    ShieldMessageRole,
    ShieldResultKind,
    TaskClass,
    TrustedEmbeddingResult,
    TrustedMessageResult,
)

EMBEDDING_PII_MODE_STRIP = "strip"


class SearchQueryEmbeddingUnavailableError(Exception):
    """Shield search-query embedding was unavailable before a trusted proof existed."""


class ShieldCallSiteIdentity(BaseModel):
    """Auth-derived metadata common to Shield-gated call-site proofs.

    Product/API callers may pass ``organization_id``; call-site internals use
    ``tenant_id`` before building storage/query/audit evidence.
    """

    model_config = ConfigDict(extra="forbid", frozen=True, populate_by_name=True)

    tenant_id: UUID = Field(validation_alias=AliasChoices("tenant_id", "organization_id"))
    principal_id: UUID
    redaction_session_id: UUID | None = None
    agent_run_id: UUID | None = None
    tool_call_id: UUID | None = None
    trace_id: str | None = Field(default=None, pattern=r"^[0-9a-f]{32}$")
    span_id: str | None = Field(default=None, pattern=r"^[0-9a-f]{16}$")

    @property
    def organization_id(self) -> UUID:
        """Compatibility alias for product/API call sites."""

        return self.tenant_id


class StagingEmbeddingProofResult(BaseModel):
    """Provider-free embedding proof result safe for graph staging code."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    call_id: UUID
    provider: str
    model_id: str
    dimensions: int
    dtype: str
    vector_count: int
    embedding_pii_mode: str = EMBEDDING_PII_MODE_STRIP


class SearchQueryLogRecord(BaseModel):
    """PII query evidence shape: hash and entity metadata only."""

    model_config = ConfigDict(extra="forbid", frozen=True, populate_by_name=True)

    tenant_id: UUID = Field(validation_alias=AliasChoices("tenant_id", "organization_id"))
    principal_id: UUID
    call_id: UUID
    query_hash: str = Field(pattern=r"^[a-f0-9]{64}$")
    query_hash_version: int = Field(default=1, gt=0)
    entity_types: tuple[str, ...]

    @property
    def organization_id(self) -> UUID:
        """Compatibility alias for callers that still speak organization."""

        return self.tenant_id


class SearchQueryEmbeddingProofResult(BaseModel):
    """Search-query embedding proof response without query text."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    call_id: UUID
    provider: str
    model_id: str
    dimensions: int
    dtype: str
    vector_count: int
    query_hash: str = Field(pattern=r"^[a-f0-9]{64}$")
    vector: tuple[float, ...] = Field(min_length=1)


class AgentToolProofResult(BaseModel):
    """One-tool agent proof response from trusted Shield output."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    call_id: UUID
    messages: tuple[ShieldMessage, ...]


class SearchQueryLogWriter(Protocol):
    """Content-free query-log writer owned by the search call site."""

    async def write_query_log(self, record: SearchQueryLogRecord) -> None:
        """Persist query hash and entity metadata without raw query text."""
        ...


class RuntimeSearchQueryLogWriter:
    """Persist search-query evidence through the Slice 5 Shield query-log path."""

    def __init__(self, connection: asyncpg.Connection) -> None:
        self._connection = connection

    async def write_query_log(self, record: SearchQueryLogRecord) -> None:
        """Write hash/entity metadata only, under the request's principal GUCs."""

        trace_context = current_audit_trace_context()
        async with self._connection.transaction():  # pyright: ignore[reportUnknownMemberType]
            row = cast(
                object | None,
                await self._connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                    """
                SELECT id
                FROM app.insert_pii_query_log_from_shield(
                  $1::uuid,
                  $2::uuid,
                  $3::text,
                  $4::text,
                  $5::bytea,
                  $6::integer,
                  $7::text[],
                  $8::integer
                )
                """,
                    record.tenant_id,
                    record.principal_id,
                    trace_context.trace_id,
                    trace_context.span_id,
                    bytes.fromhex(record.query_hash),
                    record.query_hash_version,
                    list(record.entity_types),
                    len(record.entity_types),
                ),
            )
            if row is None:
                raise RuntimeError("search_query_log_not_visible")


class StagingEmbeddingProofService:
    """First graph/staging embedding seam routed through Shield."""

    def __init__(self, shield_client: ShieldClient) -> None:
        self._shield_client = shield_client

    async def embed_text(
        self,
        *,
        identity: ShieldCallSiteIdentity,
        text: str,
    ) -> StagingEmbeddingProofResult:
        """Submit staging text to Shield in batch embedding/strip posture."""

        response = await self._shield_client.complete(
            context=_context(
                identity=identity,
                task_class=TaskClass.EMBEDDING,
                latency_mode=LatencyMode.BATCH,
                requested_sensitivity=SensitivityTier.PII,
            ),
            messages=(text_message(ShieldMessageRole.USER, text),),
        )
        result = _require_embedding_result(response.result)
        route = _require_route_metadata(response.route)
        _validate_embedding_route_policy(route=route, result=result)
        return StagingEmbeddingProofResult(
            call_id=response.call_id,
            provider=route.provider,
            model_id=route.model_id,
            dimensions=result.dimensions,
            dtype=result.dtype,
            vector_count=len(result.vectors),
        )


class SearchQueryEmbeddingProofService:
    """Slice 6 search seam proof routed through Shield."""

    def __init__(
        self,
        *,
        shield_client: ShieldClient,
        query_log_writer: SearchQueryLogWriter,
        query_hash_key: bytes,
        query_hash_environment_id: str = "runtime",
    ) -> None:
        if not query_hash_key:
            raise ValueError("query_hash_key is required")
        self._shield_client = shield_client
        self._query_log_writer = query_log_writer
        self._query_hash_key = query_hash_key
        self._query_hash_environment_id = query_hash_environment_id

    async def embed_query(
        self,
        *,
        identity: ShieldCallSiteIdentity,
        query: str,
        entity_types: tuple[str, ...],
    ) -> SearchQueryEmbeddingProofResult:
        """Submit a search query through Shield and write value-free evidence."""

        try:
            response = await self._shield_client.complete(
                context=_context(
                    identity=identity,
                    task_class=TaskClass.SEARCH_QUERY,
                    latency_mode=LatencyMode.SYNC,
                    requested_sensitivity=SensitivityTier.PII,
                ),
                messages=(text_message(ShieldMessageRole.USER, query),),
            )
        except httpx.HTTPStatusError as exc:
            status_code = exc.response.status_code
            if status_code >= 500:
                raise SearchQueryEmbeddingUnavailableError(
                    "search_query_embedding_unavailable"
                ) from exc
            raise
        except (httpx.TransportError, TimeoutError) as exc:
            raise SearchQueryEmbeddingUnavailableError(
                "search_query_embedding_unavailable"
            ) from exc
        result = _require_embedding_result(response.result)
        route = _require_route_metadata(response.route)
        try:
            _validate_embedding_route_policy(route=route, result=result)
        except ValueError as exc:
            raise SearchQueryEmbeddingUnavailableError(
                "search_query_embedding_unavailable"
            ) from exc
        query_digest = ShieldPIIQueryDigest.from_query(
            hmac_key=self._query_hash_key,
            tenant_id=identity.tenant_id,
            environment_id=self._query_hash_environment_id,
            query_text=query,
        )
        await self._query_log_writer.write_query_log(
            SearchQueryLogRecord(
                tenant_id=identity.tenant_id,
                principal_id=identity.principal_id,
                call_id=response.call_id,
                query_hash=query_digest.digest.hex(),
                query_hash_version=query_digest.version,
                entity_types=tuple(sorted(set(entity_types))),
            )
        )
        return SearchQueryEmbeddingProofResult(
            call_id=response.call_id,
            provider=route.provider,
            model_id=route.model_id,
            dimensions=result.dimensions,
            dtype=result.dtype,
            vector_count=len(result.vectors),
            query_hash=query_digest.digest.hex(),
            vector=tuple(result.vectors[0]),
        )


class AgentToolProofService:
    """Slice 7 one-tool agent seam proof routed through Shield."""

    def __init__(self, shield_client: ShieldClient) -> None:
        self._shield_client = shield_client

    async def complete_one_tool_call(
        self,
        *,
        identity: ShieldCallSiteIdentity,
        user_text: str,
        tool_result_text: str,
    ) -> AgentToolProofResult:
        """Submit a minimal user/tool exchange through canonical Shield."""

        response = await self._shield_client.complete(
            context=_context(
                identity=identity,
                task_class=TaskClass.AGENT_TOOL,
                latency_mode=LatencyMode.SYNC,
                requested_sensitivity=SensitivityTier.PII,
            ),
            messages=(
                text_message(ShieldMessageRole.USER, user_text),
                text_message(ShieldMessageRole.TOOL, tool_result_text),
            ),
        )
        result = _require_message_result(response.result)
        return AgentToolProofResult(
            call_id=response.call_id,
            messages=tuple(result.messages),
        )


def _context(
    *,
    identity: ShieldCallSiteIdentity,
    task_class: TaskClass,
    latency_mode: LatencyMode,
    requested_sensitivity: SensitivityTier,
) -> ShieldCallContext:
    trace_context = _trace_context(identity)
    return ShieldCallContext(
        tenant_id=identity.tenant_id,
        principal_id=identity.principal_id,
        redaction_session_id=identity.redaction_session_id,
        agent_run_id=identity.agent_run_id,
        tool_call_id=identity.tool_call_id,
        trace_id=trace_context.trace_id,
        span_id=trace_context.span_id,
        task_class=task_class,
        latency_mode=latency_mode,
        stream=False,
        requested_sensitivity=requested_sensitivity,
    )


def _trace_context(identity: ShieldCallSiteIdentity) -> AuditTraceContext:
    if identity.trace_id is not None and identity.span_id is not None:
        return AuditTraceContext(trace_id=identity.trace_id, span_id=identity.span_id)
    return current_audit_trace_context()


def _require_embedding_result(result: object) -> TrustedEmbeddingResult:
    if not isinstance(result, TrustedEmbeddingResult):
        raise ValueError("Shield response did not include an embedding result")
    if result.kind != ShieldResultKind.EMBEDDING:
        raise ValueError("Shield response kind is not embedding")
    return result


def _require_route_metadata(route: RouteMetadata | None) -> RouteMetadata:
    if route is None:
        raise ValueError("Shield response did not include route metadata")
    return route


def _validate_embedding_route_policy(
    *,
    route: RouteMetadata,
    result: TrustedEmbeddingResult,
) -> None:
    if route.embedding_dimensions is not None and result.dimensions != route.embedding_dimensions:
        raise ValueError("Shield embedding dimensions do not match route policy")
    if route.embedding_dtype is not None and result.dtype != route.embedding_dtype:
        raise ValueError("Shield embedding dtype does not match route policy")


def _require_message_result(result: object) -> TrustedMessageResult:
    if not isinstance(result, TrustedMessageResult):
        raise ValueError("Shield response did not include a message result")
    if result.kind != ShieldResultKind.MESSAGE:
        raise ValueError("Shield response kind is not message")
    return result


__all__ = [
    "AgentToolProofResult",
    "AgentToolProofService",
    "SearchQueryEmbeddingProofResult",
    "SearchQueryEmbeddingProofService",
    "SearchQueryEmbeddingUnavailableError",
    "SearchQueryLogRecord",
    "SearchQueryLogWriter",
    "ShieldCallSiteIdentity",
    "RuntimeSearchQueryLogWriter",
    "StagingEmbeddingProofResult",
    "StagingEmbeddingProofService",
]
