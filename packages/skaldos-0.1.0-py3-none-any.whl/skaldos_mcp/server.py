"""MCP server bootstrap for the Phase 1.5 SkaldOS MCP scaffold.

Wires together: configuration (env-driven), an Auth0 M2M token client
(per ADR 19 / MP10), an `httpx.AsyncClient` shared by all tools, the
tool registry (see ``skaldos_mcp.tools``), and the MCP SDK's stdio
transport.

MCP SDK choice (ADR 26 § Companion work)
----------------------------------------

We chose the official ``mcp`` PyPI package (the Anthropic-maintained
reference implementation that ships alongside the Model Context
Protocol specification at modelcontextprotocol.io). Rationale:

- It's the canonical implementation; first-party features (capability
  negotiation, transport variants, schema validation) ship there
  before community ports.
- It has Python 3.12+ support and a clean async API that maps onto
  our FastAPI/async-httpx posture.
- The alternative would be a community fork or a hand-rolled JSON-RPC
  loop; rule-of-three doesn't justify either while one canonical
  implementation exists.

Revisit triggers: the official SDK abandons maintenance (no community
fork keeping pace); a partner SDK distribution forces a TypeScript
MCP server; a substrate feature requires a transport the SDK doesn't
support.

Transport
---------

v1 binds the stdio transport (the simplest MCP transport — one process
per MCP client connection; the client launches the server as a child
process). This matches what Claude Code, Continue, and most IDE
plug-ins expect today. HTTP-streaming transports are a future
follow-up if a hosted MCP endpoint becomes worthwhile (per §10
distribution surfaces).
"""

from __future__ import annotations

import asyncio
import logging
import os
from collections.abc import Mapping
from typing import Any

import httpx

from mcp import types as mcp_types
from mcp.server import NotificationOptions, Server
from mcp.server.models import InitializationOptions
from mcp.server.stdio import stdio_server
from skaldos_mcp.auth import Auth0M2MTokenClient
from skaldos_mcp.config import McpServerConfig, McpServerConfigError, config_from_env
from skaldos_mcp.tools import McpToolSpec, registered_tools

_LOGGER = logging.getLogger("skaldos_mcp.server")
_SERVER_NAME = "skaldos-mcp"
_SERVER_VERSION = "0.1.0"


async def serve(
    *,
    config: McpServerConfig,
    http_client: httpx.AsyncClient | None = None,
) -> None:
    """Bind the MCP server to stdio and serve until the client disconnects.

    Construct an HTTP client + token client + tool registry, register
    each tool with the MCP SDK's ``Server``, then await ``stdio_server``.
    The function returns when the MCP client (or stdio) closes.
    """
    owns_client = http_client is None
    client = http_client or httpx.AsyncClient()
    try:
        token_client = Auth0M2MTokenClient(config=config, http_client=client)
        tools = registered_tools(config=config, http_client=client, token_client=token_client)
        server = _build_server(tools)
        _LOGGER.info(
            "skaldos_mcp.server.starting",
            extra={
                "tool_count": len(tools),
                "tool_names": [tool.name for tool in tools],
                "api_base_url": config.api_base_url,
                "auth0_domain": config.auth0_domain,
                # client_secret + access tokens never logged (§20.2).
            },
        )
        async with stdio_server() as (read_stream, write_stream):
            await server.run(
                read_stream,
                write_stream,
                InitializationOptions(
                    server_name=_SERVER_NAME,
                    server_version=_SERVER_VERSION,
                    capabilities=server.get_capabilities(
                        notification_options=NotificationOptions(),
                        experimental_capabilities={},
                    ),
                ),
            )
    finally:
        if owns_client:
            await client.aclose()


def _build_server(tools: tuple[McpToolSpec, ...] | list[McpToolSpec] | Any) -> Server:  # type: ignore[type-arg]
    """Build the MCP ``Server`` with the given tool registry wired in.

    The handlers translate between the MCP SDK's request/response
    shapes and our :class:`McpToolSpec` runner contract. Tool
    invocation results are encoded as a single ``TextContent`` JSON
    string — operator-facing tools surface structured JSON to the MCP
    client today; richer encodings (resources, structured content) are
    a future follow-up.
    """
    server: Server = Server(_SERVER_NAME)  # type: ignore[type-arg]
    by_name: Mapping[str, McpToolSpec] = {tool.name: tool for tool in tools}

    @server.list_tools()  # type: ignore[misc, no-untyped-call]
    async def _list_tools() -> list[mcp_types.Tool]:  # pyright: ignore[reportUnusedFunction]
        return [
            mcp_types.Tool(
                name=spec.name,
                description=spec.description,
                inputSchema=dict(spec.input_schema),
            )
            for spec in tools
        ]

    @server.call_tool()  # type: ignore[misc, no-untyped-call]
    async def _call_tool(  # pyright: ignore[reportUnusedFunction]
        name: str, arguments: Mapping[str, Any] | None
    ) -> list[mcp_types.TextContent]:
        spec = by_name.get(name)
        if spec is None:
            # E11 surfaces as "tool not found"; the MCP SDK also
            # validates the tool name before delegating, so this is
            # defensive.
            return [
                mcp_types.TextContent(
                    type="text",
                    text=_encode_error("tool_not_found", f"Unknown tool: {name}"),
                )
            ]
        result = await spec.run(arguments or {})
        return [mcp_types.TextContent(type="text", text=_encode_result(result))]

    return server


def _encode_result(result: Any) -> str:
    """Encode an :class:`McpToolResult` as a JSON string for MCP."""
    import json

    return json.dumps(
        {
            "ok": result.ok,
            "data": result.data,
            "error_code": result.error_code,
            "http_status": result.http_status,
            "message": result.message,
        },
        default=str,
    )


def _encode_error(error_code: str, message: str) -> str:
    import json

    return json.dumps(
        {
            "ok": False,
            "data": None,
            "error_code": error_code,
            "http_status": None,
            "message": message,
        }
    )


def main(argv: list[str] | None = None) -> int:
    """CLI entrypoint used by ``python -m skaldos_mcp``.

    Reads config from env, runs :func:`serve` until completion, returns
    0 on clean exit. Config errors fail fast with exit code 78
    (``EX_CONFIG`` from sysexits.h — "configuration error").
    """
    del argv  # Reserved for future flag parsing.
    logging.basicConfig(
        level=os.environ.get("SKALDOS_MCP_LOG_LEVEL", "INFO"),
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )
    try:
        config = config_from_env()
    except McpServerConfigError as exc:
        _LOGGER.error("skaldos_mcp.server.config_error reason=%s", str(exc))
        return 78
    try:
        asyncio.run(serve(config=config))
    except KeyboardInterrupt:
        _LOGGER.info("skaldos_mcp.server.interrupted")
        return 0
    return 0


__all__ = ["main", "serve"]
