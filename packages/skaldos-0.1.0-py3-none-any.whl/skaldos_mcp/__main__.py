"""Entrypoint: ``python -m skaldos_mcp``.

Delegates to :func:`skaldos_mcp.server.main`. Kept as a thin shim so
the server module is testable without invoking the process-level
runner.
"""

from __future__ import annotations

import sys

from skaldos_mcp.server import main

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
