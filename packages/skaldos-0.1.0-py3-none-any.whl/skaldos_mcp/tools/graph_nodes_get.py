"""MCP tool wrapping the SkaldOS read flow.

Per E8 in ``02-edge-cases.md``: ``GET /graph/nodes/{id}`` isn't
deployed on staging yet (it lands with the PR0 / slice-frontend-api-gaps
roll-out). The Phase 1.5 MCP scaffold uses ``POST /graph/search`` as
the read flow substitute — same chokepoint, same RLS path, same 4xx
error envelopes. Once ``/graph/nodes/{id}`` is live on staging, a
follow-up PR swaps the wrapped operation (the MCP tool name can stay
the same — ``graph_search`` — or be renamed; that's a future call).

The tool name is intentionally ``graph_search`` (not ``graph_nodes_get``)
because at v1 we want the name to match what's actually wrapped. Tool
schema parity tests assert the operation id matches the staging
OpenAPI spec.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

import httpx

from skaldos_mcp.auth import Auth0M2MAuthError, Auth0M2MTokenClient
from skaldos_mcp.config import McpServerConfig
from skaldos_mcp.tools._http import parse_response
from skaldos_mcp.tools.base import McpToolResult, McpToolSpec


class GraphSearchTool:
    """Wrap ``POST /graph/search`` as the MCP read flow."""

    NAME = "graph_search"
    OPERATION_ID = "post_graph_search"
    DESCRIPTION = (
        "Search the SkaldOS graph for visible nodes matching a query. "
        "Returns a paginated list of node summaries (id, ontology type, "
        "headline, classification). Visibility is RLS-enforced — the "
        "calling principal sees only nodes in tenants they belong to "
        "and at clearance levels they hold."
    )
    INPUT_SCHEMA: Mapping[str, Any] = {
        "type": "object",
        "additionalProperties": False,
        "required": ["tenant_id", "query"],
        "properties": {
            "tenant_id": {
                "type": "string",
                "format": "uuid",
                "description": "The tenant to search within (UUID).",
            },
            "query": {
                "type": "string",
                "minLength": 1,
                "maxLength": 1024,
                "description": "Free-text search query.",
            },
            "limit": {
                "type": "integer",
                "minimum": 1,
                "maximum": 50,
                "default": 10,
                "description": "Maximum number of hits to return (1..50).",
            },
        },
    }

    def __init__(
        self,
        *,
        config: McpServerConfig,
        http_client: httpx.AsyncClient,
        token_client: Auth0M2MTokenClient,
    ) -> None:
        self._config = config
        self._http_client = http_client
        self._token_client = token_client

    def spec(self) -> McpToolSpec:
        return McpToolSpec(
            name=self.NAME,
            description=self.DESCRIPTION,
            input_schema=self.INPUT_SCHEMA,
            operation_id=self.OPERATION_ID,
            run=self._run,
        )

    async def _run(self, args: Mapping[str, Any]) -> McpToolResult:
        body = {
            "tenant_id": args["tenant_id"],
            "query": args["query"],
            "limit": args.get("limit", 10),
        }
        try:
            token = await self._token_client.get_access_token()
        except Auth0M2MAuthError as exc:
            return McpToolResult(ok=False, error_code=str(exc), message="Auth0 token mint failed.")
        url = f"{self._config.api_base_url}/graph/search"
        try:
            response = await self._http_client.post(
                url,
                json=body,
                headers={"Authorization": f"Bearer {token}"},
                timeout=self._config.http_timeout_seconds,
            )
        except httpx.RequestError as exc:
            return McpToolResult(
                ok=False,
                error_code="api_request_failed",
                message=f"HTTP transport error: {type(exc).__name__}",
            )
        return parse_response(response)


__all__ = ["GraphSearchTool"]
