"""MCP tool wrapping ``POST /graph/assert``.

This is the only v1 tool that does not use the generated client. The
``GraphAssertRequest`` Pydantic schema uses a recursive ``JsonValue``
union (``str | int | float | bool | None | dict | list``) for the
``claim`` field; ``openapi-python-client`` v0.28 cannot resolve that
recursion and silently drops the schema from its output. See ADR 26
"Adoption rules" for the standing policy: schemas the codegen tool
can't handle are wrapped with hand-written ``httpx`` calls at the tool
layer, documented inline, and graduated to generated calls when the
codegen-tool catches up.

The tool's input schema mirrors the API's
``services/api/skaldos/api/graph_assert.py``
:class:`GraphAssertRequest` shape — claim (object), source, actor,
grounding (optional), confidence, intent. Validation runs at the MCP
layer (the SDK validates the input against this schema) and again at
the API boundary (the API's chokepoint + Pydantic validators are the
authoritative gates per AP5).
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

import httpx

from skaldos_mcp.auth import Auth0M2MAuthError, Auth0M2MTokenClient
from skaldos_mcp.config import McpServerConfig
from skaldos_mcp.tools._http import parse_response
from skaldos_mcp.tools.base import McpToolResult, McpToolSpec


class GraphAssertTool:
    """Wrap ``POST /graph/assert`` for MCP."""

    NAME = "graph_assert"
    OPERATION_ID = "post_graph_assert"
    DESCRIPTION = (
        "Submit a graph assertion (claim) through the SkaldOS write "
        "chokepoint. Every write goes through this single endpoint "
        "(§10.5). The claim envelope is validated server-side; the "
        "calling agent principal is authorised against the resolved "
        "subject + intent. Use this for observations, notes, "
        "node-body updates, node tags, edge creation, and Pattern-4 "
        "revisions."
    )
    # Mirror of services/api/skaldos/api/graph_assert.py GraphAssertRequest.
    # The five-value Searle intent enum matches services/api/skaldos/policy/intent.py.
    INPUT_SCHEMA: Mapping[str, Any] = {
        "type": "object",
        "additionalProperties": False,
        "required": ["tenant_id", "claim", "source", "actor", "confidence", "intent"],
        "properties": {
            "tenant_id": {
                "type": "string",
                "format": "uuid",
                "description": "Target tenant for this assertion (UUID).",
            },
            "claim": {
                "type": "object",
                "description": (
                    "Assertion claim. Supported families: observation, "
                    "note, node_body_update, node_tag, edge_create, "
                    "pattern4_revision. See the API's `GraphAssertRequest` "
                    "Pydantic model for the per-family shape."
                ),
            },
            "source": {
                "type": "object",
                "required": ["kind"],
                "additionalProperties": False,
                "properties": {
                    "kind": {"type": "string", "minLength": 1, "maxLength": 63},
                    "locator": {
                        "type": ["string", "null"],
                        "minLength": 1,
                        "maxLength": 2048,
                    },
                    "external_id": {
                        "type": ["string", "null"],
                        "minLength": 1,
                        "maxLength": 512,
                    },
                    "metadata": {"type": "object"},
                },
            },
            "actor": {
                "type": "object",
                "required": ["principal_id", "kind"],
                "additionalProperties": False,
                "properties": {
                    "principal_id": {"type": "string", "format": "uuid"},
                    "kind": {"type": "string", "enum": ["human", "agent"]},
                },
            },
            "grounding": {
                "type": ["object", "null"],
                "description": "Optional grounding reference; node_id, edge_id, span, role.",
            },
            "confidence": {
                "type": "number",
                "minimum": 0.0,
                "maximum": 1.0,
                "description": "Confidence in the claim, 0.0 to 1.0.",
            },
            "intent": {
                "type": "string",
                "enum": ["assertive", "directive", "commissive", "expressive", "declarative"],
                "description": "Searle intent classification.",
            },
            "idempotency_key": {
                "type": ["string", "null"],
                "minLength": 1,
                "maxLength": 128,
                "description": "Caller-supplied idempotency key (optional).",
            },
        },
    }

    def __init__(
        self,
        *,
        config: McpServerConfig,
        http_client: httpx.AsyncClient,
        token_client: Auth0M2MTokenClient,
    ) -> None:
        self._config = config
        self._http_client = http_client
        self._token_client = token_client

    def spec(self) -> McpToolSpec:
        return McpToolSpec(
            name=self.NAME,
            description=self.DESCRIPTION,
            input_schema=self.INPUT_SCHEMA,
            operation_id=self.OPERATION_ID,
            run=self._run,
        )

    async def _run(self, args: Mapping[str, Any]) -> McpToolResult:
        # The API expects the body fields as a flat envelope (per
        # services/api/skaldos/api/graph_assert.py GraphAssertRequest).
        # tenant_id is part of the body per the assert contract; the
        # chokepoint resolves it via target_tenant_loader.
        body: dict[str, Any] = {
            "tenant_id": args["tenant_id"],
            "claim": args["claim"],
            "source": args["source"],
            "actor": args["actor"],
            "confidence": args["confidence"],
            "intent": args["intent"],
        }
        grounding = args.get("grounding")
        if grounding is not None:
            body["grounding"] = grounding
        idempotency_key = args.get("idempotency_key")
        headers: dict[str, str] = {}
        if idempotency_key is not None:
            headers["Idempotency-Key"] = idempotency_key
        try:
            token = await self._token_client.get_access_token()
        except Auth0M2MAuthError as exc:
            return McpToolResult(ok=False, error_code=str(exc), message="Auth0 token mint failed.")
        headers["Authorization"] = f"Bearer {token}"
        url = f"{self._config.api_base_url}/graph/assert"
        try:
            response = await self._http_client.post(
                url,
                json=body,
                headers=headers,
                timeout=self._config.http_timeout_seconds,
            )
        except httpx.RequestError as exc:
            return McpToolResult(
                ok=False,
                error_code="api_request_failed",
                message=f"HTTP transport error: {type(exc).__name__}",
            )
        return parse_response(response)


__all__ = ["GraphAssertTool"]
