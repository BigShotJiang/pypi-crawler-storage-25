"""Shared types for the MCP tool surface.

Each tool wrapper exposes one :class:`McpToolSpec` that the server
bootstrap registers with the MCP SDK. The spec carries the user-facing
metadata (name, description, JSON-schema input) plus an async runner
that performs the actual HTTP call.

Keeping the runner async + injecting the ``httpx.AsyncClient`` means
unit tests can stub the HTTP layer without touching the spec shape.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class McpToolResult:
    """Structured result of a tool invocation.

    ``ok`` is True when the underlying API call returned a 2xx status.
    ``data`` is the parsed JSON response (or the raw ``Mapping``
    extracted from the SDK type). On failure, ``error_code`` is a
    stable identifier the MCP client surfaces; ``http_status`` is the
    status code that produced the error (None for transport-layer
    failures); ``message`` is a short operator-facing description (no
    PII).
    """

    ok: bool
    data: Mapping[str, Any] | None = None
    error_code: str | None = None
    http_status: int | None = None
    message: str | None = None


@dataclass(frozen=True, slots=True)
class McpToolSpec:
    """One MCP tool registration.

    Attributes
    ----------
    name
        MCP tool name (snake_case, stable). Tests pin this exact
        string.
    description
        Operator-facing description (drawn from the OpenAPI ``summary``
        of the wrapped operation). The MCP client renders this in its
        tool picker.
    input_schema
        JSON Schema describing the tool's input arguments. Derived
        from the OpenAPI request schema for the wrapped operation.
    operation_id
        OpenAPI ``operationId`` of the wrapped operation. Used by the
        schema-parity test to assert the schema matches the spec.
    run
        Async callable. Receives the validated input arguments (the
        MCP SDK has already JSON-schema validated by the time this
        runs) and returns the structured result.
    """

    name: str
    description: str
    input_schema: Mapping[str, Any]
    operation_id: str
    run: Callable[[Mapping[str, Any]], Awaitable[McpToolResult]]


__all__ = ["McpToolResult", "McpToolSpec"]
