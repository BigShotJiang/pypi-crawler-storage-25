"""Shared HTTP response → tool result translation.

Every tool wrapper hits an HTTP endpoint and translates the response
into the same :class:`McpToolResult` shape. Centralising the parsing
here keeps the per-tool modules focused on their input schema +
request body building.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any, cast

import httpx

from skaldos_mcp.tools.base import McpToolResult


def parse_response(response: httpx.Response) -> McpToolResult:
    """Translate an ``httpx.Response`` into an :class:`McpToolResult`."""
    try:
        payload: object = response.json()
    except json.JSONDecodeError:
        payload = None
    data: Mapping[str, Any] | None = (
        cast(Mapping[str, Any], payload) if isinstance(payload, dict) else None
    )
    if 200 <= response.status_code < 300:
        return McpToolResult(ok=True, data=data, http_status=response.status_code)
    error_code = _extract_error_code(data) or f"http_{response.status_code}"
    return McpToolResult(
        ok=False,
        data=data,
        error_code=error_code,
        http_status=response.status_code,
        message=f"API returned HTTP {response.status_code}.",
    )


def _extract_error_code(data: Mapping[str, Any] | None) -> str | None:
    if data is None:
        return None
    detail = data.get("detail")
    if isinstance(detail, dict):
        detail_typed = cast(Mapping[str, Any], detail)
        code = detail_typed.get("error_code")
        if isinstance(code, str):
            return code
    code = data.get("error_code")
    if isinstance(code, str):
        return code
    return None


__all__ = ["parse_response"]
