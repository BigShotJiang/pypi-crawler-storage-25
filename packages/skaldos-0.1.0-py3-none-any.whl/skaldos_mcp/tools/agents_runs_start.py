"""MCP tool wrapping ``POST /agents/{org_agent_type_id}/runs``.

Starts a sync agent run. Per S3 in ``01-user-stories.md``, verification
only requires the enqueue to succeed and the run id to come back; the
actual agent execution is governed by Slice 7 / Slice 11 runtime
correctness work and is out of scope for this MCP tool's contract.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

import httpx

from skaldos_mcp.auth import Auth0M2MAuthError, Auth0M2MTokenClient
from skaldos_mcp.config import McpServerConfig
from skaldos_mcp.tools._http import parse_response
from skaldos_mcp.tools.base import McpToolResult, McpToolSpec


class AgentsRunsStartTool:
    """Wrap ``POST /agents/{org_agent_type_id}/runs`` for MCP."""

    NAME = "agents_runs_start"
    OPERATION_ID = "post_sync_agent_run"
    DESCRIPTION = (
        "Start a sync agent run for the given org agent type. "
        "Returns the agent run id (the run executes asynchronously; "
        "use the agent runs read surface to observe its progress). "
        "Acceptance only requires the run to enqueue cleanly — actual "
        "run completion is governed by the Slice 7 / 11 runtime."
    )
    # Mirror of services/api/skaldos/agents/contracts.py SyncAgentRunRequest.
    INPUT_SCHEMA: Mapping[str, Any] = {
        "type": "object",
        "additionalProperties": False,
        "required": ["org_agent_type_id", "tenant_id"],
        "properties": {
            "org_agent_type_id": {
                "type": "string",
                "format": "uuid",
                "description": "The OrgAgentType to start a run of (UUID; path parameter).",
            },
            "tenant_id": {
                "type": "string",
                "format": "uuid",
                "description": "Target tenant for the agent run (UUID).",
            },
            "request_id": {
                "type": ["string", "null"],
                "format": "uuid",
                "description": "Optional caller-supplied idempotency request id.",
            },
            "clearance_cap": {
                "type": ["string", "null"],
                "enum": ["C1", "C2", "C3", "C4", None],
                "description": "Optional clearance cap (overrides the principal's default).",
            },
            "timeout_seconds": {
                "type": "integer",
                "minimum": 1,
                "maximum": 3600,
                "default": 300,
                "description": "Run timeout in seconds (1..3600).",
            },
        },
    }

    def __init__(
        self,
        *,
        config: McpServerConfig,
        http_client: httpx.AsyncClient,
        token_client: Auth0M2MTokenClient,
    ) -> None:
        self._config = config
        self._http_client = http_client
        self._token_client = token_client

    def spec(self) -> McpToolSpec:
        return McpToolSpec(
            name=self.NAME,
            description=self.DESCRIPTION,
            input_schema=self.INPUT_SCHEMA,
            operation_id=self.OPERATION_ID,
            run=self._run,
        )

    async def _run(self, args: Mapping[str, Any]) -> McpToolResult:
        org_agent_type_id = args["org_agent_type_id"]
        body: dict[str, Any] = {
            "tenant_id": args["tenant_id"],
        }
        if (request_id := args.get("request_id")) is not None:
            body["request_id"] = request_id
        if (clearance_cap := args.get("clearance_cap")) is not None:
            body["clearance_cap"] = clearance_cap
        if (timeout_seconds := args.get("timeout_seconds")) is not None:
            body["timeout_seconds"] = timeout_seconds
        try:
            token = await self._token_client.get_access_token()
        except Auth0M2MAuthError as exc:
            return McpToolResult(ok=False, error_code=str(exc), message="Auth0 token mint failed.")
        url = f"{self._config.api_base_url}/agents/{org_agent_type_id}/runs"
        try:
            response = await self._http_client.post(
                url,
                json=body,
                headers={"Authorization": f"Bearer {token}"},
                timeout=self._config.http_timeout_seconds,
            )
        except httpx.RequestError as exc:
            return McpToolResult(
                ok=False,
                error_code="api_request_failed",
                message=f"HTTP transport error: {type(exc).__name__}",
            )
        return parse_response(response)


__all__ = ["AgentsRunsStartTool"]
