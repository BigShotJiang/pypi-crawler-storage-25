"""MCP tool registry.

Each tool module exposes a single :class:`McpToolSpec` describing one
HTTP route from the SkaldOS API as an MCP tool. The server bootstrap
(``skaldos_mcp.server``) discovers tools via the
:func:`registered_tools` factory below and registers each with the
MCP SDK.

Why a factory (vs a module-level constant list)
-----------------------------------------------

The tools share an ``httpx.AsyncClient`` and a
:class:`skaldos_mcp.auth.Auth0M2MTokenClient`; the factory takes both
as arguments so the server bootstrap can wire them once at startup.
Tests build the registry with stubs.

Tool surface (v1)
-----------------

- ``graph_search`` — wraps ``POST /graph/search`` (the read flow
  substitute for ``GET /graph/nodes/{id}`` per E8 in ``02-edge-cases.md``;
  the ``/graph/nodes/{id}`` route isn't on staging yet but the read
  flow proof works through search).
- ``graph_assert`` — wraps ``POST /graph/assert``. Uses a hand-written
  ``httpx`` call rather than the generated client because
  ``openapi-python-client`` can't process the recursive ``JsonValue``
  schema used by the assert envelope (E2 in ``02-edge-cases.md``,
  documented in ADR 26).
- ``agents_runs_start`` — wraps ``POST /agents/{org_agent_type_id}/runs``.
"""

from __future__ import annotations

from collections.abc import Sequence

import httpx

from skaldos_mcp.auth import Auth0M2MTokenClient
from skaldos_mcp.config import McpServerConfig
from skaldos_mcp.tools.agents_runs_start import AgentsRunsStartTool
from skaldos_mcp.tools.base import McpToolSpec
from skaldos_mcp.tools.graph_assert import GraphAssertTool
from skaldos_mcp.tools.graph_nodes_get import GraphSearchTool


def registered_tools(
    *,
    config: McpServerConfig,
    http_client: httpx.AsyncClient,
    token_client: Auth0M2MTokenClient,
) -> Sequence[McpToolSpec]:
    """Build the v1 tool registry.

    Returns a stable tuple of tool specs in registration order. The
    server bootstrap iterates this exact sequence; tests assert the
    shape against the spec.
    """
    return (
        GraphSearchTool(config=config, http_client=http_client, token_client=token_client).spec(),
        GraphAssertTool(config=config, http_client=http_client, token_client=token_client).spec(),
        AgentsRunsStartTool(
            config=config, http_client=http_client, token_client=token_client
        ).spec(),
    )


__all__ = [
    "AgentsRunsStartTool",
    "GraphAssertTool",
    "GraphSearchTool",
    "McpToolSpec",
    "registered_tools",
]
