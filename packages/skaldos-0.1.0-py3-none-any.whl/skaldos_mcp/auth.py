"""Auth0 M2M Client Credentials token mint + cache.

Mirrors the precedent at
``services/api/skaldos/events/push_subscriber.py``
(:class:`SubscriberApiRefetchClient`) — the push subscriber mints an
M2M token against Auth0 and uses it to call the API server on behalf
of a tenant-scoped agent principal (ADR 19, MP10).

The MCP server uses the same flow: read M2M client id + secret from
env, POST ``/oauth/token`` against the configured Auth0 tenant with
``grant_type=client_credentials`` and the configured ``audience``, then
attach the returned bearer token to every SkaldOS API call. Tokens
carry an ``expires_in`` value; the cache preemptively refreshes at
``exp - 60s`` so a long-running tool call doesn't time out mid-flight
(E6).

The token mint is testable in isolation by injecting an ``httpx.AsyncClient``
that's wired to a mocked Auth0 endpoint (see ``tests/unit/mcp/test_auth.py``).
"""

from __future__ import annotations

import time
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass
from typing import cast

import httpx

from skaldos_mcp.config import McpServerConfig

# Refresh the cached token this many seconds *before* its hard expiry so
# a slow downstream API call doesn't fail with 401 mid-flight (E6 in
# ``02-edge-cases.md``). The Auth0 default access-token lifetime for
# Client Credentials grants is 86400s; a 60s buffer is comfortably
# below the access-token granularity Auth0 itself enforces.
_TOKEN_REFRESH_BUFFER_SECONDS: float = 60.0


class Auth0M2MAuthError(RuntimeError):
    """Raised when Auth0 M2M token mint fails or the response is malformed.

    The exception message is a stable reason code (e.g.
    ``"auth0_token_rejected"``, ``"auth0_token_missing"``) — never the
    raw Auth0 body, which may include sensitive detail. Callers /
    structured-log emitters log the code; operators correlate via the
    Auth0 console.
    """


@dataclass(frozen=True, slots=True)
class _CachedToken:
    access_token: str
    expires_at: float  # Wall-clock seconds since epoch, per the monotonic_clock.

    def is_fresh(self, *, now: float) -> bool:
        return now < (self.expires_at - _TOKEN_REFRESH_BUFFER_SECONDS)


class Auth0M2MTokenClient:
    """Mint and cache Auth0 Client Credentials access tokens.

    Construction injects the HTTP client + a clock so unit tests can
    pin both. Production callers pass ``httpx.AsyncClient`` and the
    default :func:`time.time` clock.

    The cache is single-token: the MCP server v1 is one-org-per-process
    (E7), so the token always represents the same principal.

    Concurrency: the cache check is not lock-guarded — a brief race
    where two parallel tool calls both mint a fresh token is a benign
    duplicate (the second token replaces the first). Adding a lock
    would buy nothing because Auth0 doesn't rate-limit a single client
    that hard, and v1 expects ≤1 in-flight tool call (MCP stdio
    transport is single-client).
    """

    def __init__(
        self,
        *,
        config: McpServerConfig,
        http_client: httpx.AsyncClient,
        clock: Callable[[], float] = time.time,
    ) -> None:
        self._config = config
        self._http_client = http_client
        self._clock = clock
        self._cached: _CachedToken | None = None

    async def get_access_token(self) -> str:
        """Return a fresh access token, minting + caching as needed."""
        cached = self._cached
        if cached is not None and cached.is_fresh(now=self._clock()):
            return cached.access_token
        return (await self._mint_and_cache()).access_token

    async def _mint_and_cache(self) -> _CachedToken:
        token = await self._mint()
        self._cached = token
        return token

    async def _mint(self) -> _CachedToken:
        try:
            response = await self._http_client.post(
                self._config.auth0_token_url,
                data={
                    "grant_type": "client_credentials",
                    "client_id": self._config.auth0_client_id,
                    "client_secret": self._config.auth0_client_secret,
                    "audience": self._config.api_audience,
                },
                timeout=self._config.http_timeout_seconds,
            )
        except httpx.RequestError as exc:
            raise Auth0M2MAuthError("auth0_token_request_failed") from exc

        if response.status_code >= 400:
            # E5: 4xx from Auth0 surfaces as a structured error. We
            # don't echo the body (it may include rejected-client
            # detail); the status code + stable reason code is what
            # the operator correlates against the Auth0 console.
            raise Auth0M2MAuthError("auth0_token_rejected")

        payload: object = response.json()
        if not isinstance(payload, dict):
            raise Auth0M2MAuthError("auth0_token_response_invalid")
        payload_mapping = cast("Mapping[str, object]", payload)
        access_token = payload_mapping.get("access_token")
        expires_in = payload_mapping.get("expires_in")
        if not isinstance(access_token, str) or not access_token:
            raise Auth0M2MAuthError("auth0_token_missing")
        if not isinstance(expires_in, (int, float)) or expires_in <= 0:
            raise Auth0M2MAuthError("auth0_token_expires_in_invalid")
        return _CachedToken(
            access_token=access_token,
            expires_at=self._clock() + float(expires_in),
        )


# Public typing alias used by callers that need to inject a custom
# token-source (e.g. tests that bypass Auth0 entirely). Matches the
# minimal interface :class:`Auth0M2MTokenClient` exposes.
TokenSource = Callable[[], Awaitable[str]]


__all__ = ["Auth0M2MAuthError", "Auth0M2MTokenClient", "TokenSource"]
