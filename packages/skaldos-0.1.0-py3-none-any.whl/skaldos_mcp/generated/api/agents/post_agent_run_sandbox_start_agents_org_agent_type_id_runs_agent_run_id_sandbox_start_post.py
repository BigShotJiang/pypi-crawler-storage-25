from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.agent_run_sandbox_lifecycle_request import (
    AgentRunSandboxLifecycleRequest,
)
from ...models.agent_run_sandbox_lifecycle_response import (
    AgentRunSandboxLifecycleResponse,
)
from ...models.authorization_error_response import AuthorizationErrorResponse
from ...models.principal_error_response import PrincipalErrorResponse
from ...models.rate_limit_error_response import RateLimitErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    org_agent_type_id: UUID,
    agent_run_id: UUID,
    *,
    body: AgentRunSandboxLifecycleRequest,
    authorization: None | str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(authorization, Unset):
        headers["Authorization"] = authorization

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/agents/{org_agent_type_id}/runs/{agent_run_id}/sandbox/start".format(
            org_agent_type_id=quote(str(org_agent_type_id), safe=""),
            agent_run_id=quote(str(agent_run_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    AgentRunSandboxLifecycleResponse
    | Any
    | AuthorizationErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
    | None
):
    if response.status_code == 202:
        response_202 = AgentRunSandboxLifecycleResponse.from_dict(response.json())

        return response_202

    if response.status_code == 400:
        response_400 = cast(Any, None)
        return response_400

    if response.status_code == 401:
        response_401 = cast(Any, None)
        return response_401

    if response.status_code == 403:
        response_403 = AuthorizationErrorResponse.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 409:
        response_409 = PrincipalErrorResponse.from_dict(response.json())

        return response_409

    if response.status_code == 422:
        response_422 = cast(Any, None)
        return response_422

    if response.status_code == 429:
        response_429 = RateLimitErrorResponse.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = PrincipalErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 503:
        response_503 = cast(Any, None)
        return response_503

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    AgentRunSandboxLifecycleResponse
    | Any
    | AuthorizationErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org_agent_type_id: UUID,
    agent_run_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: AgentRunSandboxLifecycleRequest,
    authorization: None | str | Unset = UNSET,
) -> Response[
    AgentRunSandboxLifecycleResponse
    | Any
    | AuthorizationErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
]:
    """Post Agent Run Sandbox Start

     Start a real E2B sandbox for a persisted non-production AgentRun.

    Args:
        org_agent_type_id (UUID):
        agent_run_id (UUID):
        authorization (None | str | Unset):
        body (AgentRunSandboxLifecycleRequest): Tenant-scoped request for protected sandbox
            lifecycle operations.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AgentRunSandboxLifecycleResponse | Any | AuthorizationErrorResponse | PrincipalErrorResponse | RateLimitErrorResponse]
    """

    kwargs = _get_kwargs(
        org_agent_type_id=org_agent_type_id,
        agent_run_id=agent_run_id,
        body=body,
        authorization=authorization,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    org_agent_type_id: UUID,
    agent_run_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: AgentRunSandboxLifecycleRequest,
    authorization: None | str | Unset = UNSET,
) -> (
    AgentRunSandboxLifecycleResponse
    | Any
    | AuthorizationErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
    | None
):
    """Post Agent Run Sandbox Start

     Start a real E2B sandbox for a persisted non-production AgentRun.

    Args:
        org_agent_type_id (UUID):
        agent_run_id (UUID):
        authorization (None | str | Unset):
        body (AgentRunSandboxLifecycleRequest): Tenant-scoped request for protected sandbox
            lifecycle operations.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AgentRunSandboxLifecycleResponse | Any | AuthorizationErrorResponse | PrincipalErrorResponse | RateLimitErrorResponse
    """

    return sync_detailed(
        org_agent_type_id=org_agent_type_id,
        agent_run_id=agent_run_id,
        client=client,
        body=body,
        authorization=authorization,
    ).parsed


async def asyncio_detailed(
    org_agent_type_id: UUID,
    agent_run_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: AgentRunSandboxLifecycleRequest,
    authorization: None | str | Unset = UNSET,
) -> Response[
    AgentRunSandboxLifecycleResponse
    | Any
    | AuthorizationErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
]:
    """Post Agent Run Sandbox Start

     Start a real E2B sandbox for a persisted non-production AgentRun.

    Args:
        org_agent_type_id (UUID):
        agent_run_id (UUID):
        authorization (None | str | Unset):
        body (AgentRunSandboxLifecycleRequest): Tenant-scoped request for protected sandbox
            lifecycle operations.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AgentRunSandboxLifecycleResponse | Any | AuthorizationErrorResponse | PrincipalErrorResponse | RateLimitErrorResponse]
    """

    kwargs = _get_kwargs(
        org_agent_type_id=org_agent_type_id,
        agent_run_id=agent_run_id,
        body=body,
        authorization=authorization,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    org_agent_type_id: UUID,
    agent_run_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: AgentRunSandboxLifecycleRequest,
    authorization: None | str | Unset = UNSET,
) -> (
    AgentRunSandboxLifecycleResponse
    | Any
    | AuthorizationErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
    | None
):
    """Post Agent Run Sandbox Start

     Start a real E2B sandbox for a persisted non-production AgentRun.

    Args:
        org_agent_type_id (UUID):
        agent_run_id (UUID):
        authorization (None | str | Unset):
        body (AgentRunSandboxLifecycleRequest): Tenant-scoped request for protected sandbox
            lifecycle operations.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AgentRunSandboxLifecycleResponse | Any | AuthorizationErrorResponse | PrincipalErrorResponse | RateLimitErrorResponse
    """

    return (
        await asyncio_detailed(
            org_agent_type_id=org_agent_type_id,
            agent_run_id=agent_run_id,
            client=client,
            body=body,
            authorization=authorization,
        )
    ).parsed
