from http import HTTPStatus
from typing import Any, cast
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.authorization_error_response import AuthorizationErrorResponse
from ...models.classifier_calibration_response import ClassifierCalibrationResponse
from ...models.intent_error_response import IntentErrorResponse
from ...models.policy_evaluation_error_response import PolicyEvaluationErrorResponse
from ...models.principal_error_response import PrincipalErrorResponse
from ...models.rate_limit_error_response import RateLimitErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    tenant_id: UUID,
    ontology_version_id: UUID,
    node_type_family: str,
    classifier_name: str,
    classifier_version: str,
    context_fingerprint: None | str | Unset = UNSET,
    authorization: None | str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(authorization, Unset):
        headers["Authorization"] = authorization

    params: dict[str, Any] = {}

    json_tenant_id = str(tenant_id)
    params["tenant_id"] = json_tenant_id

    json_ontology_version_id = str(ontology_version_id)
    params["ontology_version_id"] = json_ontology_version_id

    params["node_type_family"] = node_type_family

    params["classifier_name"] = classifier_name

    params["classifier_version"] = classifier_version

    json_context_fingerprint: None | str | Unset
    if isinstance(context_fingerprint, Unset):
        json_context_fingerprint = UNSET
    else:
        json_context_fingerprint = context_fingerprint
    params["context_fingerprint"] = json_context_fingerprint

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/calibration/classifier-family",
        "params": params,
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    Any
    | AuthorizationErrorResponse
    | ClassifierCalibrationResponse
    | IntentErrorResponse
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
    | None
):
    if response.status_code == 200:
        response_200 = ClassifierCalibrationResponse.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = cast(Any, None)
        return response_401

    if response.status_code == 403:
        response_403 = AuthorizationErrorResponse.from_dict(response.json())

        return response_403

    if response.status_code == 409:
        response_409 = PrincipalErrorResponse.from_dict(response.json())

        return response_409

    if response.status_code == 422:
        response_422 = IntentErrorResponse.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = RateLimitErrorResponse.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = PrincipalErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 503:

        def _parse_response_503(
            data: object,
        ) -> PolicyEvaluationErrorResponse | PrincipalErrorResponse:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_503_type_0 = PrincipalErrorResponse.from_dict(data)

                return response_503_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            response_503_type_1 = PolicyEvaluationErrorResponse.from_dict(data)

            return response_503_type_1

        response_503 = _parse_response_503(response.json())

        return response_503

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    Any
    | AuthorizationErrorResponse
    | ClassifierCalibrationResponse
    | IntentErrorResponse
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    tenant_id: UUID,
    ontology_version_id: UUID,
    node_type_family: str,
    classifier_name: str,
    classifier_version: str,
    context_fingerprint: None | str | Unset = UNSET,
    authorization: None | str | Unset = UNSET,
) -> Response[
    Any
    | AuthorizationErrorResponse
    | ClassifierCalibrationResponse
    | IntentErrorResponse
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
]:
    """Get Classifier Family Calibration

     Return a permitted, content-free classifier-family calibration row.

    Args:
        tenant_id (UUID):
        ontology_version_id (UUID):
        node_type_family (str):
        classifier_name (str):
        classifier_version (str):
        context_fingerprint (None | str | Unset):
        authorization (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | AuthorizationErrorResponse | ClassifierCalibrationResponse | IntentErrorResponse | PolicyEvaluationErrorResponse | PrincipalErrorResponse | PrincipalErrorResponse | RateLimitErrorResponse]
    """

    kwargs = _get_kwargs(
        tenant_id=tenant_id,
        ontology_version_id=ontology_version_id,
        node_type_family=node_type_family,
        classifier_name=classifier_name,
        classifier_version=classifier_version,
        context_fingerprint=context_fingerprint,
        authorization=authorization,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    tenant_id: UUID,
    ontology_version_id: UUID,
    node_type_family: str,
    classifier_name: str,
    classifier_version: str,
    context_fingerprint: None | str | Unset = UNSET,
    authorization: None | str | Unset = UNSET,
) -> (
    Any
    | AuthorizationErrorResponse
    | ClassifierCalibrationResponse
    | IntentErrorResponse
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
    | None
):
    """Get Classifier Family Calibration

     Return a permitted, content-free classifier-family calibration row.

    Args:
        tenant_id (UUID):
        ontology_version_id (UUID):
        node_type_family (str):
        classifier_name (str):
        classifier_version (str):
        context_fingerprint (None | str | Unset):
        authorization (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | AuthorizationErrorResponse | ClassifierCalibrationResponse | IntentErrorResponse | PolicyEvaluationErrorResponse | PrincipalErrorResponse | PrincipalErrorResponse | RateLimitErrorResponse
    """

    return sync_detailed(
        client=client,
        tenant_id=tenant_id,
        ontology_version_id=ontology_version_id,
        node_type_family=node_type_family,
        classifier_name=classifier_name,
        classifier_version=classifier_version,
        context_fingerprint=context_fingerprint,
        authorization=authorization,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    tenant_id: UUID,
    ontology_version_id: UUID,
    node_type_family: str,
    classifier_name: str,
    classifier_version: str,
    context_fingerprint: None | str | Unset = UNSET,
    authorization: None | str | Unset = UNSET,
) -> Response[
    Any
    | AuthorizationErrorResponse
    | ClassifierCalibrationResponse
    | IntentErrorResponse
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
]:
    """Get Classifier Family Calibration

     Return a permitted, content-free classifier-family calibration row.

    Args:
        tenant_id (UUID):
        ontology_version_id (UUID):
        node_type_family (str):
        classifier_name (str):
        classifier_version (str):
        context_fingerprint (None | str | Unset):
        authorization (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | AuthorizationErrorResponse | ClassifierCalibrationResponse | IntentErrorResponse | PolicyEvaluationErrorResponse | PrincipalErrorResponse | PrincipalErrorResponse | RateLimitErrorResponse]
    """

    kwargs = _get_kwargs(
        tenant_id=tenant_id,
        ontology_version_id=ontology_version_id,
        node_type_family=node_type_family,
        classifier_name=classifier_name,
        classifier_version=classifier_version,
        context_fingerprint=context_fingerprint,
        authorization=authorization,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    tenant_id: UUID,
    ontology_version_id: UUID,
    node_type_family: str,
    classifier_name: str,
    classifier_version: str,
    context_fingerprint: None | str | Unset = UNSET,
    authorization: None | str | Unset = UNSET,
) -> (
    Any
    | AuthorizationErrorResponse
    | ClassifierCalibrationResponse
    | IntentErrorResponse
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
    | None
):
    """Get Classifier Family Calibration

     Return a permitted, content-free classifier-family calibration row.

    Args:
        tenant_id (UUID):
        ontology_version_id (UUID):
        node_type_family (str):
        classifier_name (str):
        classifier_version (str):
        context_fingerprint (None | str | Unset):
        authorization (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | AuthorizationErrorResponse | ClassifierCalibrationResponse | IntentErrorResponse | PolicyEvaluationErrorResponse | PrincipalErrorResponse | PrincipalErrorResponse | RateLimitErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            tenant_id=tenant_id,
            ontology_version_id=ontology_version_id,
            node_type_family=node_type_family,
            classifier_name=classifier_name,
            classifier_version=classifier_version,
            context_fingerprint=context_fingerprint,
            authorization=authorization,
        )
    ).parsed
