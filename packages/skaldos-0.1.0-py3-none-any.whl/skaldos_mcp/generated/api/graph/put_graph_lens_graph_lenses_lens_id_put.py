from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.authorization_error_response import AuthorizationErrorResponse
from ...models.lens_definition_record import LensDefinitionRecord
from ...models.lens_definition_write_request import LensDefinitionWriteRequest
from ...models.policy_evaluation_error_response import PolicyEvaluationErrorResponse
from ...models.principal_error_response import PrincipalErrorResponse
from ...models.rate_limit_error_response import RateLimitErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    lens_id: UUID,
    *,
    body: LensDefinitionWriteRequest,
    authorization: None | str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(authorization, Unset):
        headers["Authorization"] = authorization

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/graph/lenses/{lens_id}".format(
            lens_id=quote(str(lens_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    Any
    | AuthorizationErrorResponse
    | LensDefinitionRecord
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
    | None
):
    if response.status_code == 200:
        response_200 = LensDefinitionRecord.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = cast(Any, None)
        return response_401

    if response.status_code == 403:
        response_403 = AuthorizationErrorResponse.from_dict(response.json())

        return response_403

    if response.status_code == 409:
        response_409 = PrincipalErrorResponse.from_dict(response.json())

        return response_409

    if response.status_code == 429:
        response_429 = RateLimitErrorResponse.from_dict(response.json())

        return response_429

    if response.status_code == 503:

        def _parse_response_503(
            data: object,
        ) -> PolicyEvaluationErrorResponse | PrincipalErrorResponse:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_503_type_0 = PrincipalErrorResponse.from_dict(data)

                return response_503_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            response_503_type_1 = PolicyEvaluationErrorResponse.from_dict(data)

            return response_503_type_1

        response_503 = _parse_response_503(response.json())

        return response_503

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    Any
    | AuthorizationErrorResponse
    | LensDefinitionRecord
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    lens_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: LensDefinitionWriteRequest,
    authorization: None | str | Unset = UNSET,
) -> Response[
    Any
    | AuthorizationErrorResponse
    | LensDefinitionRecord
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
]:
    """Put Graph Lens

     Update an active ranking-only lens definition.

    Args:
        lens_id (UUID):
        authorization (None | str | Unset):
        body (LensDefinitionWriteRequest): Create/update payload for a tenant-scoped lens
            definition.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | AuthorizationErrorResponse | LensDefinitionRecord | PolicyEvaluationErrorResponse | PrincipalErrorResponse | PrincipalErrorResponse | RateLimitErrorResponse]
    """

    kwargs = _get_kwargs(
        lens_id=lens_id,
        body=body,
        authorization=authorization,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    lens_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: LensDefinitionWriteRequest,
    authorization: None | str | Unset = UNSET,
) -> (
    Any
    | AuthorizationErrorResponse
    | LensDefinitionRecord
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
    | None
):
    """Put Graph Lens

     Update an active ranking-only lens definition.

    Args:
        lens_id (UUID):
        authorization (None | str | Unset):
        body (LensDefinitionWriteRequest): Create/update payload for a tenant-scoped lens
            definition.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | AuthorizationErrorResponse | LensDefinitionRecord | PolicyEvaluationErrorResponse | PrincipalErrorResponse | PrincipalErrorResponse | RateLimitErrorResponse
    """

    return sync_detailed(
        lens_id=lens_id,
        client=client,
        body=body,
        authorization=authorization,
    ).parsed


async def asyncio_detailed(
    lens_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: LensDefinitionWriteRequest,
    authorization: None | str | Unset = UNSET,
) -> Response[
    Any
    | AuthorizationErrorResponse
    | LensDefinitionRecord
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
]:
    """Put Graph Lens

     Update an active ranking-only lens definition.

    Args:
        lens_id (UUID):
        authorization (None | str | Unset):
        body (LensDefinitionWriteRequest): Create/update payload for a tenant-scoped lens
            definition.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | AuthorizationErrorResponse | LensDefinitionRecord | PolicyEvaluationErrorResponse | PrincipalErrorResponse | PrincipalErrorResponse | RateLimitErrorResponse]
    """

    kwargs = _get_kwargs(
        lens_id=lens_id,
        body=body,
        authorization=authorization,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    lens_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: LensDefinitionWriteRequest,
    authorization: None | str | Unset = UNSET,
) -> (
    Any
    | AuthorizationErrorResponse
    | LensDefinitionRecord
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
    | None
):
    """Put Graph Lens

     Update an active ranking-only lens definition.

    Args:
        lens_id (UUID):
        authorization (None | str | Unset):
        body (LensDefinitionWriteRequest): Create/update payload for a tenant-scoped lens
            definition.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | AuthorizationErrorResponse | LensDefinitionRecord | PolicyEvaluationErrorResponse | PrincipalErrorResponse | PrincipalErrorResponse | RateLimitErrorResponse
    """

    return (
        await asyncio_detailed(
            lens_id=lens_id,
            client=client,
            body=body,
            authorization=authorization,
        )
    ).parsed
