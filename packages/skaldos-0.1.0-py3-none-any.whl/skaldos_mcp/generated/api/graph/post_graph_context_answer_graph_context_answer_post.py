from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.authorization_error_response import AuthorizationErrorResponse
from ...models.context_answer_request import ContextAnswerRequest
from ...models.context_answer_response import ContextAnswerResponse
from ...models.intent_error_response import IntentErrorResponse
from ...models.principal_error_response import PrincipalErrorResponse
from ...models.rate_limit_error_response import RateLimitErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: ContextAnswerRequest,
    authorization: None | str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(authorization, Unset):
        headers["Authorization"] = authorization

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/graph/context/answer",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    Any
    | AuthorizationErrorResponse
    | ContextAnswerResponse
    | IntentErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
    | None
):
    if response.status_code == 200:
        response_200 = ContextAnswerResponse.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = cast(Any, None)
        return response_401

    if response.status_code == 403:
        response_403 = AuthorizationErrorResponse.from_dict(response.json())

        return response_403

    if response.status_code == 409:
        response_409 = PrincipalErrorResponse.from_dict(response.json())

        return response_409

    if response.status_code == 422:
        response_422 = IntentErrorResponse.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = RateLimitErrorResponse.from_dict(response.json())

        return response_429

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    Any
    | AuthorizationErrorResponse
    | ContextAnswerResponse
    | IntentErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: ContextAnswerRequest,
    authorization: None | str | Unset = UNSET,
) -> Response[
    Any
    | AuthorizationErrorResponse
    | ContextAnswerResponse
    | IntentErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
]:
    """Post Graph Context Answer

     Assemble visible context, then answer only through canonical Shield.

    Args:
        authorization (None | str | Unset):
        body (ContextAnswerRequest): Request for assembling context and answering via canonical
            Shield.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | AuthorizationErrorResponse | ContextAnswerResponse | IntentErrorResponse | PrincipalErrorResponse | RateLimitErrorResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        authorization=authorization,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: ContextAnswerRequest,
    authorization: None | str | Unset = UNSET,
) -> (
    Any
    | AuthorizationErrorResponse
    | ContextAnswerResponse
    | IntentErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
    | None
):
    """Post Graph Context Answer

     Assemble visible context, then answer only through canonical Shield.

    Args:
        authorization (None | str | Unset):
        body (ContextAnswerRequest): Request for assembling context and answering via canonical
            Shield.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | AuthorizationErrorResponse | ContextAnswerResponse | IntentErrorResponse | PrincipalErrorResponse | RateLimitErrorResponse
    """

    return sync_detailed(
        client=client,
        body=body,
        authorization=authorization,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: ContextAnswerRequest,
    authorization: None | str | Unset = UNSET,
) -> Response[
    Any
    | AuthorizationErrorResponse
    | ContextAnswerResponse
    | IntentErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
]:
    """Post Graph Context Answer

     Assemble visible context, then answer only through canonical Shield.

    Args:
        authorization (None | str | Unset):
        body (ContextAnswerRequest): Request for assembling context and answering via canonical
            Shield.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | AuthorizationErrorResponse | ContextAnswerResponse | IntentErrorResponse | PrincipalErrorResponse | RateLimitErrorResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        authorization=authorization,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: ContextAnswerRequest,
    authorization: None | str | Unset = UNSET,
) -> (
    Any
    | AuthorizationErrorResponse
    | ContextAnswerResponse
    | IntentErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
    | None
):
    """Post Graph Context Answer

     Assemble visible context, then answer only through canonical Shield.

    Args:
        authorization (None | str | Unset):
        body (ContextAnswerRequest): Request for assembling context and answering via canonical
            Shield.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | AuthorizationErrorResponse | ContextAnswerResponse | IntentErrorResponse | PrincipalErrorResponse | RateLimitErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            authorization=authorization,
        )
    ).parsed
