from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.authorization_error_response import AuthorizationErrorResponse
from ...models.intent_error_response import IntentErrorResponse
from ...models.organization_create_api_test_only_organization_create_post_response_organization_create_api_test_only_organization_create_post import (
    OrganizationCreateApiTestOnlyOrganizationCreatePostResponseOrganizationCreateApiTestOnlyOrganizationCreatePost,
)
from ...models.organization_create_request import OrganizationCreateRequest
from ...models.policy_evaluation_error_response import PolicyEvaluationErrorResponse
from ...models.principal_error_response import PrincipalErrorResponse
from ...models.rate_limit_error_response import RateLimitErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: OrganizationCreateRequest,
    authorization: None | str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(authorization, Unset):
        headers["Authorization"] = authorization

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/_test_only/organization_create",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    Any
    | AuthorizationErrorResponse
    | IntentErrorResponse
    | OrganizationCreateApiTestOnlyOrganizationCreatePostResponseOrganizationCreateApiTestOnlyOrganizationCreatePost
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
    | None
):
    if response.status_code == 200:
        response_200 = OrganizationCreateApiTestOnlyOrganizationCreatePostResponseOrganizationCreateApiTestOnlyOrganizationCreatePost.from_dict(
            response.json()
        )

        return response_200

    if response.status_code == 401:
        response_401 = cast(Any, None)
        return response_401

    if response.status_code == 403:
        response_403 = AuthorizationErrorResponse.from_dict(response.json())

        return response_403

    if response.status_code == 409:
        response_409 = PrincipalErrorResponse.from_dict(response.json())

        return response_409

    if response.status_code == 422:
        response_422 = IntentErrorResponse.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = RateLimitErrorResponse.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = PrincipalErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 503:

        def _parse_response_503(
            data: object,
        ) -> PolicyEvaluationErrorResponse | PrincipalErrorResponse:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_503_type_0 = PrincipalErrorResponse.from_dict(data)

                return response_503_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            response_503_type_1 = PolicyEvaluationErrorResponse.from_dict(data)

            return response_503_type_1

        response_503 = _parse_response_503(response.json())

        return response_503

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    Any
    | AuthorizationErrorResponse
    | IntentErrorResponse
    | OrganizationCreateApiTestOnlyOrganizationCreatePostResponseOrganizationCreateApiTestOnlyOrganizationCreatePost
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: OrganizationCreateRequest,
    authorization: None | str | Unset = UNSET,
) -> Response[
    Any
    | AuthorizationErrorResponse
    | IntentErrorResponse
    | OrganizationCreateApiTestOnlyOrganizationCreatePostResponseOrganizationCreateApiTestOnlyOrganizationCreatePost
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
]:
    """Fixture handler: organization create (AP5 surface).

     Exercises the chokepoint's create Organization authorization decision. Available only when
    SKALDOS_ENV != 'production'. Stands in for Slice 7's POST /organizations (which may not ship —
    organizations are provisioned via Auth0 SSO onboarding). Goes through Depends(authorize) — the real
    chokepoint. AP5. The Polar policy ships no allow rule for create Organization, so every role × kind
    combination denies (deny-by-default property).

    Args:
        authorization (None | str | Unset):
        body (OrganizationCreateRequest): Request body for the organization-create fixture
            handler.

            ``display_name``: the human-readable label for the new organization.
            Only relevant on the (unreachable) allow path — the chokepoint denies
            every create-Organization request, so the body is never read by Oso.

            ``frozen=True, extra="forbid"`` mirrors production discipline.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | AuthorizationErrorResponse | IntentErrorResponse | OrganizationCreateApiTestOnlyOrganizationCreatePostResponseOrganizationCreateApiTestOnlyOrganizationCreatePost | PolicyEvaluationErrorResponse | PrincipalErrorResponse | PrincipalErrorResponse | RateLimitErrorResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        authorization=authorization,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: OrganizationCreateRequest,
    authorization: None | str | Unset = UNSET,
) -> (
    Any
    | AuthorizationErrorResponse
    | IntentErrorResponse
    | OrganizationCreateApiTestOnlyOrganizationCreatePostResponseOrganizationCreateApiTestOnlyOrganizationCreatePost
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
    | None
):
    """Fixture handler: organization create (AP5 surface).

     Exercises the chokepoint's create Organization authorization decision. Available only when
    SKALDOS_ENV != 'production'. Stands in for Slice 7's POST /organizations (which may not ship —
    organizations are provisioned via Auth0 SSO onboarding). Goes through Depends(authorize) — the real
    chokepoint. AP5. The Polar policy ships no allow rule for create Organization, so every role × kind
    combination denies (deny-by-default property).

    Args:
        authorization (None | str | Unset):
        body (OrganizationCreateRequest): Request body for the organization-create fixture
            handler.

            ``display_name``: the human-readable label for the new organization.
            Only relevant on the (unreachable) allow path — the chokepoint denies
            every create-Organization request, so the body is never read by Oso.

            ``frozen=True, extra="forbid"`` mirrors production discipline.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | AuthorizationErrorResponse | IntentErrorResponse | OrganizationCreateApiTestOnlyOrganizationCreatePostResponseOrganizationCreateApiTestOnlyOrganizationCreatePost | PolicyEvaluationErrorResponse | PrincipalErrorResponse | PrincipalErrorResponse | RateLimitErrorResponse
    """

    return sync_detailed(
        client=client,
        body=body,
        authorization=authorization,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: OrganizationCreateRequest,
    authorization: None | str | Unset = UNSET,
) -> Response[
    Any
    | AuthorizationErrorResponse
    | IntentErrorResponse
    | OrganizationCreateApiTestOnlyOrganizationCreatePostResponseOrganizationCreateApiTestOnlyOrganizationCreatePost
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
]:
    """Fixture handler: organization create (AP5 surface).

     Exercises the chokepoint's create Organization authorization decision. Available only when
    SKALDOS_ENV != 'production'. Stands in for Slice 7's POST /organizations (which may not ship —
    organizations are provisioned via Auth0 SSO onboarding). Goes through Depends(authorize) — the real
    chokepoint. AP5. The Polar policy ships no allow rule for create Organization, so every role × kind
    combination denies (deny-by-default property).

    Args:
        authorization (None | str | Unset):
        body (OrganizationCreateRequest): Request body for the organization-create fixture
            handler.

            ``display_name``: the human-readable label for the new organization.
            Only relevant on the (unreachable) allow path — the chokepoint denies
            every create-Organization request, so the body is never read by Oso.

            ``frozen=True, extra="forbid"`` mirrors production discipline.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | AuthorizationErrorResponse | IntentErrorResponse | OrganizationCreateApiTestOnlyOrganizationCreatePostResponseOrganizationCreateApiTestOnlyOrganizationCreatePost | PolicyEvaluationErrorResponse | PrincipalErrorResponse | PrincipalErrorResponse | RateLimitErrorResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        authorization=authorization,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: OrganizationCreateRequest,
    authorization: None | str | Unset = UNSET,
) -> (
    Any
    | AuthorizationErrorResponse
    | IntentErrorResponse
    | OrganizationCreateApiTestOnlyOrganizationCreatePostResponseOrganizationCreateApiTestOnlyOrganizationCreatePost
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
    | None
):
    """Fixture handler: organization create (AP5 surface).

     Exercises the chokepoint's create Organization authorization decision. Available only when
    SKALDOS_ENV != 'production'. Stands in for Slice 7's POST /organizations (which may not ship —
    organizations are provisioned via Auth0 SSO onboarding). Goes through Depends(authorize) — the real
    chokepoint. AP5. The Polar policy ships no allow rule for create Organization, so every role × kind
    combination denies (deny-by-default property).

    Args:
        authorization (None | str | Unset):
        body (OrganizationCreateRequest): Request body for the organization-create fixture
            handler.

            ``display_name``: the human-readable label for the new organization.
            Only relevant on the (unreachable) allow path — the chokepoint denies
            every create-Organization request, so the body is never read by Oso.

            ``frozen=True, extra="forbid"`` mirrors production discipline.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | AuthorizationErrorResponse | IntentErrorResponse | OrganizationCreateApiTestOnlyOrganizationCreatePostResponseOrganizationCreateApiTestOnlyOrganizationCreatePost | PolicyEvaluationErrorResponse | PrincipalErrorResponse | PrincipalErrorResponse | RateLimitErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            authorization=authorization,
        )
    ).parsed
