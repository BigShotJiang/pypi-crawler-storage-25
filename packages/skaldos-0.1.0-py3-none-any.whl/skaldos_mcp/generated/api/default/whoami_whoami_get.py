from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.authorization_error_response import AuthorizationErrorResponse
from ...models.intent_error_response import IntentErrorResponse
from ...models.policy_evaluation_error_response import PolicyEvaluationErrorResponse
from ...models.principal_error_response import PrincipalErrorResponse
from ...models.rate_limit_error_response import RateLimitErrorResponse
from ...models.whoami_response import WhoamiResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    authorization: None | str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(authorization, Unset):
        headers["Authorization"] = authorization

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/whoami",
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    Any
    | AuthorizationErrorResponse
    | IntentErrorResponse
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
    | WhoamiResponse
    | None
):
    if response.status_code == 200:
        response_200 = WhoamiResponse.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = cast(Any, None)
        return response_401

    if response.status_code == 403:
        response_403 = AuthorizationErrorResponse.from_dict(response.json())

        return response_403

    if response.status_code == 409:
        response_409 = PrincipalErrorResponse.from_dict(response.json())

        return response_409

    if response.status_code == 422:
        response_422 = IntentErrorResponse.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = RateLimitErrorResponse.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = PrincipalErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 503:

        def _parse_response_503(
            data: object,
        ) -> PolicyEvaluationErrorResponse | PrincipalErrorResponse:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_503_type_0 = PrincipalErrorResponse.from_dict(data)

                return response_503_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            response_503_type_1 = PolicyEvaluationErrorResponse.from_dict(data)

            return response_503_type_1

        response_503 = _parse_response_503(response.json())

        return response_503

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    Any
    | AuthorizationErrorResponse
    | IntentErrorResponse
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
    | WhoamiResponse
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    authorization: None | str | Unset = UNSET,
) -> Response[
    Any
    | AuthorizationErrorResponse
    | IntentErrorResponse
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
    | WhoamiResponse
]:
    """Return the resolved principal's identity.

     The slice gate's read target. Exercises the full chokepoint: verify_token decodes the JWT;
    current_principal acquires a connection, opens a transaction, resolves the principal, and commits
    the PC1 GUC contract; this handler reads the resolved Principal and projects to a public response.
    Available in dev/staging/test environments; gated off in production via SKALDOS_ENV != 'production'
    at route registration time.

    Args:
        authorization (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | AuthorizationErrorResponse | IntentErrorResponse | PolicyEvaluationErrorResponse | PrincipalErrorResponse | PrincipalErrorResponse | RateLimitErrorResponse | WhoamiResponse]
    """

    kwargs = _get_kwargs(
        authorization=authorization,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    authorization: None | str | Unset = UNSET,
) -> (
    Any
    | AuthorizationErrorResponse
    | IntentErrorResponse
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
    | WhoamiResponse
    | None
):
    """Return the resolved principal's identity.

     The slice gate's read target. Exercises the full chokepoint: verify_token decodes the JWT;
    current_principal acquires a connection, opens a transaction, resolves the principal, and commits
    the PC1 GUC contract; this handler reads the resolved Principal and projects to a public response.
    Available in dev/staging/test environments; gated off in production via SKALDOS_ENV != 'production'
    at route registration time.

    Args:
        authorization (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | AuthorizationErrorResponse | IntentErrorResponse | PolicyEvaluationErrorResponse | PrincipalErrorResponse | PrincipalErrorResponse | RateLimitErrorResponse | WhoamiResponse
    """

    return sync_detailed(
        client=client,
        authorization=authorization,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    authorization: None | str | Unset = UNSET,
) -> Response[
    Any
    | AuthorizationErrorResponse
    | IntentErrorResponse
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
    | WhoamiResponse
]:
    """Return the resolved principal's identity.

     The slice gate's read target. Exercises the full chokepoint: verify_token decodes the JWT;
    current_principal acquires a connection, opens a transaction, resolves the principal, and commits
    the PC1 GUC contract; this handler reads the resolved Principal and projects to a public response.
    Available in dev/staging/test environments; gated off in production via SKALDOS_ENV != 'production'
    at route registration time.

    Args:
        authorization (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | AuthorizationErrorResponse | IntentErrorResponse | PolicyEvaluationErrorResponse | PrincipalErrorResponse | PrincipalErrorResponse | RateLimitErrorResponse | WhoamiResponse]
    """

    kwargs = _get_kwargs(
        authorization=authorization,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    authorization: None | str | Unset = UNSET,
) -> (
    Any
    | AuthorizationErrorResponse
    | IntentErrorResponse
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
    | WhoamiResponse
    | None
):
    """Return the resolved principal's identity.

     The slice gate's read target. Exercises the full chokepoint: verify_token decodes the JWT;
    current_principal acquires a connection, opens a transaction, resolves the principal, and commits
    the PC1 GUC contract; this handler reads the resolved Principal and projects to a public response.
    Available in dev/staging/test environments; gated off in production via SKALDOS_ENV != 'production'
    at route registration time.

    Args:
        authorization (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | AuthorizationErrorResponse | IntentErrorResponse | PolicyEvaluationErrorResponse | PrincipalErrorResponse | PrincipalErrorResponse | RateLimitErrorResponse | WhoamiResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            authorization=authorization,
        )
    ).parsed
