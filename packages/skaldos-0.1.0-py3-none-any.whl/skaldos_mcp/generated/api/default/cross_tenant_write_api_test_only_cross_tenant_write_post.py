from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.authorization_error_response import AuthorizationErrorResponse
from ...models.cross_tenant_write_api_test_only_cross_tenant_write_post_response_cross_tenant_write_api_test_only_cross_tenant_write_post import (
    CrossTenantWriteApiTestOnlyCrossTenantWritePostResponseCrossTenantWriteApiTestOnlyCrossTenantWritePost,
)
from ...models.cross_tenant_write_request import CrossTenantWriteRequest
from ...models.intent_error_response import IntentErrorResponse
from ...models.policy_evaluation_error_response import PolicyEvaluationErrorResponse
from ...models.principal_error_response import PrincipalErrorResponse
from ...models.rate_limit_error_response import RateLimitErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: CrossTenantWriteRequest,
    authorization: None | str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(authorization, Unset):
        headers["Authorization"] = authorization

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/_test_only/cross_tenant_write",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    Any
    | AuthorizationErrorResponse
    | CrossTenantWriteApiTestOnlyCrossTenantWritePostResponseCrossTenantWriteApiTestOnlyCrossTenantWritePost
    | IntentErrorResponse
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
    | None
):
    if response.status_code == 200:
        response_200 = CrossTenantWriteApiTestOnlyCrossTenantWritePostResponseCrossTenantWriteApiTestOnlyCrossTenantWritePost.from_dict(
            response.json()
        )

        return response_200

    if response.status_code == 401:
        response_401 = cast(Any, None)
        return response_401

    if response.status_code == 403:
        response_403 = AuthorizationErrorResponse.from_dict(response.json())

        return response_403

    if response.status_code == 409:
        response_409 = PrincipalErrorResponse.from_dict(response.json())

        return response_409

    if response.status_code == 422:
        response_422 = IntentErrorResponse.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = RateLimitErrorResponse.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = PrincipalErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 503:

        def _parse_response_503(
            data: object,
        ) -> PolicyEvaluationErrorResponse | PrincipalErrorResponse:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_503_type_0 = PrincipalErrorResponse.from_dict(data)

                return response_503_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            response_503_type_1 = PolicyEvaluationErrorResponse.from_dict(data)

            return response_503_type_1

        response_503 = _parse_response_503(response.json())

        return response_503

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    Any
    | AuthorizationErrorResponse
    | CrossTenantWriteApiTestOnlyCrossTenantWritePostResponseCrossTenantWriteApiTestOnlyCrossTenantWritePost
    | IntentErrorResponse
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CrossTenantWriteRequest,
    authorization: None | str | Unset = UNSET,
) -> Response[
    Any
    | AuthorizationErrorResponse
    | CrossTenantWriteApiTestOnlyCrossTenantWritePostResponseCrossTenantWriteApiTestOnlyCrossTenantWritePost
    | IntentErrorResponse
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
]:
    """Fixture handler: cross-tenant write rejection (AP5 surface).

     Exercises the chokepoint's cross-tenant write rejection. Available only when SKALDOS_ENV !=
    'production'. Stands in for Slice 4's POST /graph/assert. Goes through Depends(authorize) — the real
    chokepoint. AP5.

    Args:
        authorization (None | str | Unset):
        body (CrossTenantWriteRequest): Request body for the cross-tenant write fixture handler.

            ``target_organization_id``: the tenant the caller is requesting a write
            into.  The chokepoint's ``target_tenant_loader`` extracts this value
            from the parsed body.

            ``frozen=True, extra="forbid"`` mirrors the production handler discipline
            (AP5: no ambient state mutations via the request body).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | AuthorizationErrorResponse | CrossTenantWriteApiTestOnlyCrossTenantWritePostResponseCrossTenantWriteApiTestOnlyCrossTenantWritePost | IntentErrorResponse | PolicyEvaluationErrorResponse | PrincipalErrorResponse | PrincipalErrorResponse | RateLimitErrorResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        authorization=authorization,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: CrossTenantWriteRequest,
    authorization: None | str | Unset = UNSET,
) -> (
    Any
    | AuthorizationErrorResponse
    | CrossTenantWriteApiTestOnlyCrossTenantWritePostResponseCrossTenantWriteApiTestOnlyCrossTenantWritePost
    | IntentErrorResponse
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
    | None
):
    """Fixture handler: cross-tenant write rejection (AP5 surface).

     Exercises the chokepoint's cross-tenant write rejection. Available only when SKALDOS_ENV !=
    'production'. Stands in for Slice 4's POST /graph/assert. Goes through Depends(authorize) — the real
    chokepoint. AP5.

    Args:
        authorization (None | str | Unset):
        body (CrossTenantWriteRequest): Request body for the cross-tenant write fixture handler.

            ``target_organization_id``: the tenant the caller is requesting a write
            into.  The chokepoint's ``target_tenant_loader`` extracts this value
            from the parsed body.

            ``frozen=True, extra="forbid"`` mirrors the production handler discipline
            (AP5: no ambient state mutations via the request body).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | AuthorizationErrorResponse | CrossTenantWriteApiTestOnlyCrossTenantWritePostResponseCrossTenantWriteApiTestOnlyCrossTenantWritePost | IntentErrorResponse | PolicyEvaluationErrorResponse | PrincipalErrorResponse | PrincipalErrorResponse | RateLimitErrorResponse
    """

    return sync_detailed(
        client=client,
        body=body,
        authorization=authorization,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CrossTenantWriteRequest,
    authorization: None | str | Unset = UNSET,
) -> Response[
    Any
    | AuthorizationErrorResponse
    | CrossTenantWriteApiTestOnlyCrossTenantWritePostResponseCrossTenantWriteApiTestOnlyCrossTenantWritePost
    | IntentErrorResponse
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
]:
    """Fixture handler: cross-tenant write rejection (AP5 surface).

     Exercises the chokepoint's cross-tenant write rejection. Available only when SKALDOS_ENV !=
    'production'. Stands in for Slice 4's POST /graph/assert. Goes through Depends(authorize) — the real
    chokepoint. AP5.

    Args:
        authorization (None | str | Unset):
        body (CrossTenantWriteRequest): Request body for the cross-tenant write fixture handler.

            ``target_organization_id``: the tenant the caller is requesting a write
            into.  The chokepoint's ``target_tenant_loader`` extracts this value
            from the parsed body.

            ``frozen=True, extra="forbid"`` mirrors the production handler discipline
            (AP5: no ambient state mutations via the request body).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | AuthorizationErrorResponse | CrossTenantWriteApiTestOnlyCrossTenantWritePostResponseCrossTenantWriteApiTestOnlyCrossTenantWritePost | IntentErrorResponse | PolicyEvaluationErrorResponse | PrincipalErrorResponse | PrincipalErrorResponse | RateLimitErrorResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        authorization=authorization,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: CrossTenantWriteRequest,
    authorization: None | str | Unset = UNSET,
) -> (
    Any
    | AuthorizationErrorResponse
    | CrossTenantWriteApiTestOnlyCrossTenantWritePostResponseCrossTenantWriteApiTestOnlyCrossTenantWritePost
    | IntentErrorResponse
    | PolicyEvaluationErrorResponse
    | PrincipalErrorResponse
    | PrincipalErrorResponse
    | RateLimitErrorResponse
    | None
):
    """Fixture handler: cross-tenant write rejection (AP5 surface).

     Exercises the chokepoint's cross-tenant write rejection. Available only when SKALDOS_ENV !=
    'production'. Stands in for Slice 4's POST /graph/assert. Goes through Depends(authorize) — the real
    chokepoint. AP5.

    Args:
        authorization (None | str | Unset):
        body (CrossTenantWriteRequest): Request body for the cross-tenant write fixture handler.

            ``target_organization_id``: the tenant the caller is requesting a write
            into.  The chokepoint's ``target_tenant_loader`` extracts this value
            from the parsed body.

            ``frozen=True, extra="forbid"`` mirrors the production handler discipline
            (AP5: no ambient state mutations via the request body).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | AuthorizationErrorResponse | CrossTenantWriteApiTestOnlyCrossTenantWritePostResponseCrossTenantWriteApiTestOnlyCrossTenantWritePost | IntentErrorResponse | PolicyEvaluationErrorResponse | PrincipalErrorResponse | PrincipalErrorResponse | RateLimitErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            authorization=authorization,
        )
    ).parsed
