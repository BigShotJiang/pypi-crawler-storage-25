from enum import Enum


class TraversalDirection(str, Enum):
    BOTH = "both"
    INCOMING = "incoming"
    OUTGOING = "outgoing"

    def __str__(self) -> str:
        return str(self.value)
