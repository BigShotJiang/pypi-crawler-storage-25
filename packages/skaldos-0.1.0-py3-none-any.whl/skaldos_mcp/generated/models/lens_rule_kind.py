from enum import Enum


class LensRuleKind(str, Enum):
    BOOST = "boost"
    WEIGHT = "weight"

    def __str__(self) -> str:
        return str(self.value)
