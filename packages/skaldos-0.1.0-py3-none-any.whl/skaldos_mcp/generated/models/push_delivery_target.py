from __future__ import annotations

from collections.abc import Mapping
from typing import (
    Any,
    Literal,
    TypeVar,
    cast,
)

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="PushDeliveryTarget")


@_attrs_define
class PushDeliveryTarget:
    """Normalized external push delivery target with secret handles only.

    Attributes:
        endpoint_url (str):
        hmac_secret_ref (str):
        oidc_audience (str):
        kind (Literal['push'] | Unset):  Default: 'push'.
    """

    endpoint_url: str
    hmac_secret_ref: str
    oidc_audience: str
    kind: Literal["push"] | Unset = "push"

    def to_dict(self) -> dict[str, Any]:
        endpoint_url = self.endpoint_url

        hmac_secret_ref = self.hmac_secret_ref

        oidc_audience = self.oidc_audience

        kind = self.kind

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "endpoint_url": endpoint_url,
                "hmac_secret_ref": hmac_secret_ref,
                "oidc_audience": oidc_audience,
            }
        )
        if kind is not UNSET:
            field_dict["kind"] = kind

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        endpoint_url = d.pop("endpoint_url")

        hmac_secret_ref = d.pop("hmac_secret_ref")

        oidc_audience = d.pop("oidc_audience")

        kind = cast(Literal["push"] | Unset, d.pop("kind", UNSET))
        if kind != "push" and not isinstance(kind, Unset):
            raise ValueError(f"kind must match const 'push', got '{kind}'")

        push_delivery_target = cls(
            endpoint_url=endpoint_url,
            hmac_secret_ref=hmac_secret_ref,
            oidc_audience=oidc_audience,
            kind=kind,
        )

        return push_delivery_target
