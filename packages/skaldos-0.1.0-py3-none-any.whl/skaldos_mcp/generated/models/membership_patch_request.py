from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="MembershipPatchRequest")


@_attrs_define
class MembershipPatchRequest:
    """Request body for the membership-patch fixture handler.

    Both fields are optional (PATCH semantics: only supplied fields are
    updated).  A ``member``-role principal that supplies ``role`` receives
    422 from the handler body — the chokepoint allows the ``update`` action
    regardless of which fields are included; the handler enforces the
    field-level constraint.

    ``extra="forbid"`` catches unknown fields at the Pydantic validation
    stage (before the handler runs), surfacing typos as 422 instead of
    silent drops.

    ``frozen=False`` here — unlike read-only shapes, the patch body is
    a partial update; mutability is not a concern since it's constructed
    once per request and not shared.

        Attributes:
            display_name (None | str | Unset):
            role (None | str | Unset):
    """

    display_name: None | str | Unset = UNSET
    role: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        display_name: None | str | Unset
        if isinstance(self.display_name, Unset):
            display_name = UNSET
        else:
            display_name = self.display_name

        role: None | str | Unset
        if isinstance(self.role, Unset):
            role = UNSET
        else:
            role = self.role

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if display_name is not UNSET:
            field_dict["display_name"] = display_name
        if role is not UNSET:
            field_dict["role"] = role

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_display_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        display_name = _parse_display_name(d.pop("display_name", UNSET))

        def _parse_role(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        role = _parse_role(d.pop("role", UNSET))

        membership_patch_request = cls(
            display_name=display_name,
            role=role,
        )

        return membership_patch_request
