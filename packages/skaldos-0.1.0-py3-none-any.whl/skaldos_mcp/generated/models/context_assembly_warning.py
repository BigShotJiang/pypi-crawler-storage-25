from enum import Enum


class ContextAssemblyWarning(str, Enum):
    TRUNCATED_VISIBLE_CONTEXT = "truncated_visible_context"

    def __str__(self) -> str:
        return str(self.value)
