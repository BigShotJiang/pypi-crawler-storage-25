from __future__ import annotations

from collections.abc import Mapping
from typing import (
    Any,
    Literal,
    TypeVar,
    cast,
)

from attrs import define as _attrs_define

from ..models.tier import Tier
from ..types import UNSET, Unset

T = TypeVar("T", bound="RateLimitErrorResponse")


@_attrs_define
class RateLimitErrorResponse:
    """OpenAPI schema for HTTP 429 rate-limit-exceeded responses.

    Returned as the JSON body when the rate-limit pre-hook raises
    :class:`~skaldos.policy.rate_limit.errors.RateLimitExceeded` and the
    FastAPI exception handler maps it to a 429.

    Fields
    ------
    code:
        Stable error-code string. Always ``"rate_limit_exceeded"``.
        Clients (frontend Zod, MCP error decoder) dispatch on this value.
    tier:
        The :class:`~skaldos.policy.rate_limit.tier.Tier` of the route that
        was hit. Lets callers understand which budget was exhausted without
        exposing any identity information.
    limit:
        The per-minute budget for this tier (§14.7 binding values unless
        overridden via ``RATE_LIMIT_OVERRIDE_LIMITS``).
    count:
        The post-increment count returned by the atomic upsert (PC10);
        always ``> limit`` when this response is returned.
    retry_after_seconds:
        Seconds until the next minute window opens. The exception handler
        also writes this value into the ``Retry-After`` HTTP header. The
        value is ``GREATEST(1, 60 - EXTRACT(SECOND FROM now())::int)``
        from the DB clock (§ F7 — single authoritative source).
    message:
        Optional human-readable explanation for debugging. Omitted by
        default; callers must not depend on its contents.

    Frozen + extra=forbid (AP5)
    ---------------------------

    Frozen: the model is immutable once constructed (no accidental mutation
    in the exception handler).  ``extra="forbid"``: rejects unknown kwargs
    at construction so a typo in the handler doesn't silently discard fields.

    PII discipline (§20.2 / §13.2)
    --------------------------------

    No PII in any field. ``code``, ``tier``, ``limit``, ``count``, and
    ``retry_after_seconds`` carry zero identity information.

    Per §14.7; ``03 § Error-management plan``; ``03 § F7``; master-plan
    § "Shared artifacts & contracts" → ``PROTECTED_ROUTE_RESPONSES``
    floor (``429 → RateLimitErrorResponse``).

        Attributes:
            tier (Tier): Rate-limit tier classification per §14.7.

                String values are lowercase and are written verbatim into the
                ``rate_limit_buckets.tier`` column (T2).  The column is ``text
                NOT NULL``; the enum is the application-side constraint that keeps
                the column's domain closed.

                Members
                -------
                AUTH
                    Strict tier.  5 requests / minute / principal.  For
                    authentication-adjacent paths.
                WRITE_HEAVY
                    Write-heavy tier.  10 / min / principal.  For mutation-heavy
                    routes that need a tighter budget than standard.
                STANDARD
                    Default tier.  100 / min / principal.  Applied to every
                    protected route that does not declare an explicit tier.
            limit (int):
            count (int):
            retry_after_seconds (int):
            code (Literal['rate_limit_exceeded'] | Unset):  Default: 'rate_limit_exceeded'.
            message (None | str | Unset):
    """

    tier: Tier
    limit: int
    count: int
    retry_after_seconds: int
    code: Literal["rate_limit_exceeded"] | Unset = "rate_limit_exceeded"
    message: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        tier = self.tier.value

        limit = self.limit

        count = self.count

        retry_after_seconds = self.retry_after_seconds

        code = self.code

        message: None | str | Unset
        if isinstance(self.message, Unset):
            message = UNSET
        else:
            message = self.message

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "tier": tier,
                "limit": limit,
                "count": count,
                "retry_after_seconds": retry_after_seconds,
            }
        )
        if code is not UNSET:
            field_dict["code"] = code
        if message is not UNSET:
            field_dict["message"] = message

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        tier = Tier(d.pop("tier"))

        limit = d.pop("limit")

        count = d.pop("count")

        retry_after_seconds = d.pop("retry_after_seconds")

        code = cast(Literal["rate_limit_exceeded"] | Unset, d.pop("code", UNSET))
        if code != "rate_limit_exceeded" and not isinstance(code, Unset):
            raise ValueError(f"code must match const 'rate_limit_exceeded', got '{code}'")

        def _parse_message(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        message = _parse_message(d.pop("message", UNSET))

        rate_limit_error_response = cls(
            tier=tier,
            limit=limit,
            count=count,
            retry_after_seconds=retry_after_seconds,
            code=code,
            message=message,
        )

        return rate_limit_error_response
