from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define

T = TypeVar("T", bound="CrossTenantWriteRequest")


@_attrs_define
class CrossTenantWriteRequest:
    """Request body for the cross-tenant write fixture handler.

    ``target_organization_id``: the tenant the caller is requesting a write
    into.  The chokepoint's ``target_tenant_loader`` extracts this value
    from the parsed body.

    ``frozen=True, extra="forbid"`` mirrors the production handler discipline
    (AP5: no ambient state mutations via the request body).

        Attributes:
            target_organization_id (UUID):
    """

    target_organization_id: UUID

    def to_dict(self) -> dict[str, Any]:
        target_organization_id = str(self.target_organization_id)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "target_organization_id": target_organization_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        target_organization_id = UUID(d.pop("target_organization_id"))

        cross_tenant_write_request = cls(
            target_organization_id=target_organization_id,
        )

        return cross_tenant_write_request
