from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import (
    TYPE_CHECKING,
    Any,
    Literal,
    TypeVar,
    cast,
)
from uuid import UUID

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..models.event_subscription_record_state import EventSubscriptionRecordState

if TYPE_CHECKING:
    from ..models.event_subscription_filter import EventSubscriptionFilter
    from ..models.push_delivery_target import PushDeliveryTarget


T = TypeVar("T", bound="EventSubscriptionRecord")


@_attrs_define
class EventSubscriptionRecord:
    """API-safe projection of one external event subscription.

    Attributes:
        id (UUID):
        tenant_id (UUID):
        subscriber_kind (Literal['external']):
        subscriber_principal_id (UUID):
        filter_ (EventSubscriptionFilter): Normalized content-free external subscription filter.
        delivery (PushDeliveryTarget): Normalized external push delivery target with secret handles only.
        state (EventSubscriptionRecordState):
        last_delivered_event_ref (None | str):
        failure_count (int):
        failure_reason_code (None | str):
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        archived_at (datetime.datetime | None):
        version (int):
    """

    id: UUID
    tenant_id: UUID
    subscriber_kind: Literal["external"]
    subscriber_principal_id: UUID
    filter_: EventSubscriptionFilter
    delivery: PushDeliveryTarget
    state: EventSubscriptionRecordState
    last_delivered_event_ref: None | str
    failure_count: int
    failure_reason_code: None | str
    created_at: datetime.datetime
    updated_at: datetime.datetime
    archived_at: datetime.datetime | None
    version: int

    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        tenant_id = str(self.tenant_id)

        subscriber_kind = self.subscriber_kind

        subscriber_principal_id = str(self.subscriber_principal_id)

        filter_ = self.filter_.to_dict()

        delivery = self.delivery.to_dict()

        state = self.state.value

        last_delivered_event_ref: None | str
        last_delivered_event_ref = self.last_delivered_event_ref

        failure_count = self.failure_count

        failure_reason_code: None | str
        failure_reason_code = self.failure_reason_code

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        archived_at: None | str
        if isinstance(self.archived_at, datetime.datetime):
            archived_at = self.archived_at.isoformat()
        else:
            archived_at = self.archived_at

        version = self.version

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "id": id,
                "tenant_id": tenant_id,
                "subscriber_kind": subscriber_kind,
                "subscriber_principal_id": subscriber_principal_id,
                "filter": filter_,
                "delivery": delivery,
                "state": state,
                "last_delivered_event_ref": last_delivered_event_ref,
                "failure_count": failure_count,
                "failure_reason_code": failure_reason_code,
                "created_at": created_at,
                "updated_at": updated_at,
                "archived_at": archived_at,
                "version": version,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.event_subscription_filter import EventSubscriptionFilter
        from ..models.push_delivery_target import PushDeliveryTarget

        d = dict(src_dict)
        id = UUID(d.pop("id"))

        tenant_id = UUID(d.pop("tenant_id"))

        subscriber_kind = cast(Literal["external"], d.pop("subscriber_kind"))
        if subscriber_kind != "external":
            raise ValueError(
                f"subscriber_kind must match const 'external', got '{subscriber_kind}'"
            )

        subscriber_principal_id = UUID(d.pop("subscriber_principal_id"))

        filter_ = EventSubscriptionFilter.from_dict(d.pop("filter"))

        delivery = PushDeliveryTarget.from_dict(d.pop("delivery"))

        state = EventSubscriptionRecordState(d.pop("state"))

        def _parse_last_delivered_event_ref(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        last_delivered_event_ref = _parse_last_delivered_event_ref(
            d.pop("last_delivered_event_ref")
        )

        failure_count = d.pop("failure_count")

        def _parse_failure_reason_code(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        failure_reason_code = _parse_failure_reason_code(d.pop("failure_reason_code"))

        created_at = isoparse(d.pop("created_at"))

        updated_at = isoparse(d.pop("updated_at"))

        def _parse_archived_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                archived_at_type_0 = isoparse(data)

                return archived_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        archived_at = _parse_archived_at(d.pop("archived_at"))

        version = d.pop("version")

        event_subscription_record = cls(
            id=id,
            tenant_id=tenant_id,
            subscriber_kind=subscriber_kind,
            subscriber_principal_id=subscriber_principal_id,
            filter_=filter_,
            delivery=delivery,
            state=state,
            last_delivered_event_ref=last_delivered_event_ref,
            failure_count=failure_count,
            failure_reason_code=failure_reason_code,
            created_at=created_at,
            updated_at=updated_at,
            archived_at=archived_at,
            version=version,
        )

        return event_subscription_record
