from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define

from ..models.graph_assert_public_status import GraphAssertPublicStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.assertion_warning import AssertionWarning


T = TypeVar("T", bound="GraphAssertResponse")


@_attrs_define
class GraphAssertResponse:
    """Stable response envelope for ``POST /graph/assert``.

    Attributes:
        status (GraphAssertPublicStatus): Public statuses returned by ``POST /graph/assert`` in Slice 4.
        assertion_id (UUID):
        pending_assertion_id (None | Unset | UUID):
        applied_node_ids (list[UUID] | Unset):
        applied_edge_ids (list[UUID] | Unset):
        warnings (list[AssertionWarning] | Unset):
        conflict_id (None | Unset | UUID):
        trace_id (None | str | Unset):
    """

    status: GraphAssertPublicStatus
    assertion_id: UUID
    pending_assertion_id: None | Unset | UUID = UNSET
    applied_node_ids: list[UUID] | Unset = UNSET
    applied_edge_ids: list[UUID] | Unset = UNSET
    warnings: list[AssertionWarning] | Unset = UNSET
    conflict_id: None | Unset | UUID = UNSET
    trace_id: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        status = self.status.value

        assertion_id = str(self.assertion_id)

        pending_assertion_id: None | str | Unset
        if isinstance(self.pending_assertion_id, Unset):
            pending_assertion_id = UNSET
        elif isinstance(self.pending_assertion_id, UUID):
            pending_assertion_id = str(self.pending_assertion_id)
        else:
            pending_assertion_id = self.pending_assertion_id

        applied_node_ids: list[str] | Unset = UNSET
        if not isinstance(self.applied_node_ids, Unset):
            applied_node_ids = []
            for applied_node_ids_item_data in self.applied_node_ids:
                applied_node_ids_item = str(applied_node_ids_item_data)
                applied_node_ids.append(applied_node_ids_item)

        applied_edge_ids: list[str] | Unset = UNSET
        if not isinstance(self.applied_edge_ids, Unset):
            applied_edge_ids = []
            for applied_edge_ids_item_data in self.applied_edge_ids:
                applied_edge_ids_item = str(applied_edge_ids_item_data)
                applied_edge_ids.append(applied_edge_ids_item)

        warnings: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.warnings, Unset):
            warnings = []
            for warnings_item_data in self.warnings:
                warnings_item = warnings_item_data.to_dict()
                warnings.append(warnings_item)

        conflict_id: None | str | Unset
        if isinstance(self.conflict_id, Unset):
            conflict_id = UNSET
        elif isinstance(self.conflict_id, UUID):
            conflict_id = str(self.conflict_id)
        else:
            conflict_id = self.conflict_id

        trace_id: None | str | Unset
        if isinstance(self.trace_id, Unset):
            trace_id = UNSET
        else:
            trace_id = self.trace_id

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "status": status,
                "assertionId": assertion_id,
            }
        )
        if pending_assertion_id is not UNSET:
            field_dict["pendingAssertionId"] = pending_assertion_id
        if applied_node_ids is not UNSET:
            field_dict["appliedNodeIds"] = applied_node_ids
        if applied_edge_ids is not UNSET:
            field_dict["appliedEdgeIds"] = applied_edge_ids
        if warnings is not UNSET:
            field_dict["warnings"] = warnings
        if conflict_id is not UNSET:
            field_dict["conflictId"] = conflict_id
        if trace_id is not UNSET:
            field_dict["traceId"] = trace_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.assertion_warning import AssertionWarning

        d = dict(src_dict)
        status = GraphAssertPublicStatus(d.pop("status"))

        assertion_id = UUID(d.pop("assertionId"))

        def _parse_pending_assertion_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                pending_assertion_id_type_0 = UUID(data)

                return pending_assertion_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        pending_assertion_id = _parse_pending_assertion_id(d.pop("pendingAssertionId", UNSET))

        _applied_node_ids = d.pop("appliedNodeIds", UNSET)
        applied_node_ids: list[UUID] | Unset = UNSET
        if _applied_node_ids is not UNSET:
            applied_node_ids = []
            for applied_node_ids_item_data in _applied_node_ids:
                applied_node_ids_item = UUID(applied_node_ids_item_data)

                applied_node_ids.append(applied_node_ids_item)

        _applied_edge_ids = d.pop("appliedEdgeIds", UNSET)
        applied_edge_ids: list[UUID] | Unset = UNSET
        if _applied_edge_ids is not UNSET:
            applied_edge_ids = []
            for applied_edge_ids_item_data in _applied_edge_ids:
                applied_edge_ids_item = UUID(applied_edge_ids_item_data)

                applied_edge_ids.append(applied_edge_ids_item)

        _warnings = d.pop("warnings", UNSET)
        warnings: list[AssertionWarning] | Unset = UNSET
        if _warnings is not UNSET:
            warnings = []
            for warnings_item_data in _warnings:
                warnings_item = AssertionWarning.from_dict(warnings_item_data)

                warnings.append(warnings_item)

        def _parse_conflict_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                conflict_id_type_0 = UUID(data)

                return conflict_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        conflict_id = _parse_conflict_id(d.pop("conflictId", UNSET))

        def _parse_trace_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        trace_id = _parse_trace_id(d.pop("traceId", UNSET))

        graph_assert_response = cls(
            status=status,
            assertion_id=assertion_id,
            pending_assertion_id=pending_assertion_id,
            applied_node_ids=applied_node_ids,
            applied_edge_ids=applied_edge_ids,
            warnings=warnings,
            conflict_id=conflict_id,
            trace_id=trace_id,
        )

        return graph_assert_response
