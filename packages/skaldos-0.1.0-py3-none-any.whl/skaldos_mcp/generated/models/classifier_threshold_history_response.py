from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.classifier_threshold_version import ClassifierThresholdVersion


T = TypeVar("T", bound="ClassifierThresholdHistoryResponse")


@_attrs_define
class ClassifierThresholdHistoryResponse:
    """Read-only threshold version history response.

    Attributes:
        thresholds (list[ClassifierThresholdVersion]):
    """

    thresholds: list[ClassifierThresholdVersion]

    def to_dict(self) -> dict[str, Any]:
        thresholds = []
        for thresholds_item_data in self.thresholds:
            thresholds_item = thresholds_item_data.to_dict()
            thresholds.append(thresholds_item)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "thresholds": thresholds,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.classifier_threshold_version import ClassifierThresholdVersion

        d = dict(src_dict)
        thresholds = []
        _thresholds = d.pop("thresholds")
        for thresholds_item_data in _thresholds:
            thresholds_item = ClassifierThresholdVersion.from_dict(thresholds_item_data)

            thresholds.append(thresholds_item)

        classifier_threshold_history_response = cls(
            thresholds=thresholds,
        )

        return classifier_threshold_history_response
