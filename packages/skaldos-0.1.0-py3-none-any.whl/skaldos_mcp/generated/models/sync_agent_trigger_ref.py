from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="SyncAgentTriggerRef")


@_attrs_define
class SyncAgentTriggerRef:
    """Allowlisted content-free launch correlation handles.

    Attributes:
        source_ref (None | str | Unset):
        correlation_id (None | str | Unset):
        idempotency_key (None | str | Unset):
    """

    source_ref: None | str | Unset = UNSET
    correlation_id: None | str | Unset = UNSET
    idempotency_key: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        source_ref: None | str | Unset
        if isinstance(self.source_ref, Unset):
            source_ref = UNSET
        else:
            source_ref = self.source_ref

        correlation_id: None | str | Unset
        if isinstance(self.correlation_id, Unset):
            correlation_id = UNSET
        else:
            correlation_id = self.correlation_id

        idempotency_key: None | str | Unset
        if isinstance(self.idempotency_key, Unset):
            idempotency_key = UNSET
        else:
            idempotency_key = self.idempotency_key

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if source_ref is not UNSET:
            field_dict["source_ref"] = source_ref
        if correlation_id is not UNSET:
            field_dict["correlation_id"] = correlation_id
        if idempotency_key is not UNSET:
            field_dict["idempotency_key"] = idempotency_key

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_source_ref(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        source_ref = _parse_source_ref(d.pop("source_ref", UNSET))

        def _parse_correlation_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        correlation_id = _parse_correlation_id(d.pop("correlation_id", UNSET))

        def _parse_idempotency_key(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        idempotency_key = _parse_idempotency_key(d.pop("idempotency_key", UNSET))

        sync_agent_trigger_ref = cls(
            source_ref=source_ref,
            correlation_id=correlation_id,
            idempotency_key=idempotency_key,
        )

        return sync_agent_trigger_ref
