from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define

from ..models.metric_filter_field import MetricFilterField
from ..models.metric_filter_operator import MetricFilterOperator

T = TypeVar("T", bound="MetricFilter")


@_attrs_define
class MetricFilter:
    """One allowlisted metric predicate.

    Attributes:
        field (MetricFilterField): Allowlisted filter fields for the first metric grammar.
        operator (MetricFilterOperator): Constrained metric filter operators.
        value (float | str | UUID):
    """

    field: MetricFilterField
    operator: MetricFilterOperator
    value: float | str | UUID

    def to_dict(self) -> dict[str, Any]:
        field = self.field.value

        operator = self.operator.value

        value: float | str
        if isinstance(self.value, UUID):
            value = str(self.value)
        else:
            value = self.value

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "field": field,
                "operator": operator,
                "value": value,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        field = MetricFilterField(d.pop("field"))

        operator = MetricFilterOperator(d.pop("operator"))

        def _parse_value(data: object) -> float | str | UUID:
            try:
                if not isinstance(data, str):
                    raise TypeError()
                value_type_3 = UUID(data)

                return value_type_3
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(float | str | UUID, data)

        value = _parse_value(d.pop("value"))

        metric_filter = cls(
            field=field,
            operator=operator,
            value=value,
        )

        return metric_filter
