from enum import Enum


class ContextAnswerResponseKind(str, Enum):
    ANSWER = "answer"
    NON_ANSWER = "non_answer"

    def __str__(self) -> str:
        return str(self.value)
