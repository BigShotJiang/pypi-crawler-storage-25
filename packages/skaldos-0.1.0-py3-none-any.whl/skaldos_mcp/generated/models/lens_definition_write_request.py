from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.lens_definition_write_request_definition import (
        LensDefinitionWriteRequestDefinition,
    )


T = TypeVar("T", bound="LensDefinitionWriteRequest")


@_attrs_define
class LensDefinitionWriteRequest:
    """Create/update payload for a tenant-scoped lens definition.

    Attributes:
        tenant_id (UUID):
        name (str):
        definition (LensDefinitionWriteRequestDefinition):
    """

    tenant_id: UUID
    name: str
    definition: LensDefinitionWriteRequestDefinition

    def to_dict(self) -> dict[str, Any]:
        tenant_id = str(self.tenant_id)

        name = self.name

        definition = self.definition.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "tenant_id": tenant_id,
                "name": name,
                "definition": definition,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.lens_definition_write_request_definition import (
            LensDefinitionWriteRequestDefinition,
        )

        d = dict(src_dict)
        tenant_id = UUID(d.pop("tenant_id"))

        name = d.pop("name")

        definition = LensDefinitionWriteRequestDefinition.from_dict(d.pop("definition"))

        lens_definition_write_request = cls(
            tenant_id=tenant_id,
            name=name,
            definition=definition,
        )

        return lens_definition_write_request
