from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define

from ..models.lens_sort_by import LensSortBy
from ..models.lens_sort_direction import LensSortDirection
from ..types import UNSET, Unset

T = TypeVar("T", bound="LensSort")


@_attrs_define
class LensSort:
    """Deterministic sort key allowed after visible candidates exist.

    Attributes:
        by (LensSortBy):
        direction (LensSortDirection | Unset):  Default: LensSortDirection.DESC.
    """

    by: LensSortBy
    direction: LensSortDirection | Unset = LensSortDirection.DESC

    def to_dict(self) -> dict[str, Any]:
        by = self.by.value

        direction: str | Unset = UNSET
        if not isinstance(self.direction, Unset):
            direction = self.direction.value

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "by": by,
            }
        )
        if direction is not UNSET:
            field_dict["direction"] = direction

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        by = LensSortBy(d.pop("by"))

        _direction = d.pop("direction", UNSET)
        direction: LensSortDirection | Unset
        if isinstance(_direction, Unset):
            direction = UNSET
        else:
            direction = LensSortDirection(_direction)

        lens_sort = cls(
            by=by,
            direction=direction,
        )

        return lens_sort
