from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.principal_error_response_detail_type_0 import (
        PrincipalErrorResponseDetailType0,
    )


T = TypeVar("T", bound="PrincipalErrorResponse")


@_attrs_define
class PrincipalErrorResponse:
    """OpenAPI schema for any :class:`PrincipalHydrationError` JSON body.

    The shared response envelope. Clients dispatch on the ``code``
    string (which matches the
    :attr:`~skaldos.middleware.PrincipalHydrationError.code` ClassVar
    on the raised exception); the ``message`` is operator-visible
    English suitable for inclusion in user-facing error UIs without
    further translation. The ``detail`` slot is reserved for future
    error-classes that need structured extra context (none today; the
    field is typed ``dict[str, Any] | None`` so a Slice 2+ extension
    can ship without a breaking change to the envelope).

    Frozen + strict-extra: the model rejects unknown kwargs at
    construction (``ConfigDict(frozen=True, extra="forbid")``). This
    is structural defense-in-depth against an upstream caller
    smuggling extra fields through the response shape (AP5).

    The model lives at ``skaldos.middleware.openapi_responses``; the
    canon ``code`` constants live at ``skaldos.middleware.errors``.
    The two are kept in lockstep by the runbook-consistency test
    ``tests/unit/test_principal_hydration_runbook_consistency.py``
    and the OpenAPI-shape unit test
    ``tests/unit/middleware/test_openapi_responses.py``; renaming a
    code in one place fails both tests loudly.

        Attributes:
            code (str):
            message (str):
            detail (None | PrincipalErrorResponseDetailType0 | Unset):
    """

    code: str
    message: str
    detail: None | PrincipalErrorResponseDetailType0 | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        from ..models.principal_error_response_detail_type_0 import (
            PrincipalErrorResponseDetailType0,
        )

        code = self.code

        message = self.message

        detail: dict[str, Any] | None | Unset
        if isinstance(self.detail, Unset):
            detail = UNSET
        elif isinstance(self.detail, PrincipalErrorResponseDetailType0):
            detail = self.detail.to_dict()
        else:
            detail = self.detail

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "code": code,
                "message": message,
            }
        )
        if detail is not UNSET:
            field_dict["detail"] = detail

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.principal_error_response_detail_type_0 import (
            PrincipalErrorResponseDetailType0,
        )

        d = dict(src_dict)
        code = d.pop("code")

        message = d.pop("message")

        def _parse_detail(
            data: object,
        ) -> None | PrincipalErrorResponseDetailType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                detail_type_0 = PrincipalErrorResponseDetailType0.from_dict(data)

                return detail_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | PrincipalErrorResponseDetailType0 | Unset, data)

        detail = _parse_detail(d.pop("detail", UNSET))

        principal_error_response = cls(
            code=code,
            message=message,
            detail=detail,
        )

        return principal_error_response
