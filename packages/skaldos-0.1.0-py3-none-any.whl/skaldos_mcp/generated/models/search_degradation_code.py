from enum import Enum


class SearchDegradationCode(str, Enum):
    SHIELD_EMBEDDING_FAILED_LEXICAL_ONLY = "shield_embedding_failed_lexical_only"
    SHORT_QUERY_TRIGRAM_SKIPPED = "short_query_trigram_skipped"
    SHORT_QUERY_VECTOR_SKIPPED = "short_query_vector_skipped"
    VECTOR_INCOMPATIBLE_QUERY_EMBEDDING = "vector_incompatible_query_embedding"
    VECTOR_UNAVAILABLE_NO_EMBEDDER = "vector_unavailable_no_embedder"

    def __str__(self) -> str:
        return str(self.value)
