from enum import Enum


class MetricFilterField(str, Enum):
    CURRENCY = "currency"
    NODE_ID = "node_id"
    VALUE_NUMBER = "value_number"

    def __str__(self) -> str:
        return str(self.value)
