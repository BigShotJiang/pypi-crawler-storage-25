from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define

from ..models.classification_level import ClassificationLevel
from ..types import UNSET, Unset

T = TypeVar("T", bound="TraversalNode")


@_attrs_define
class TraversalNode:
    """Visible node projection returned by traversal.

    Attributes:
        id (UUID):
        tenant_id (UUID):
        classification (ClassificationLevel): Fixed substrate classification levels, ordered by sensitivity.
        depth (int):
        type_id (UUID):
        summary (None | str | Unset):
    """

    id: UUID
    tenant_id: UUID
    classification: ClassificationLevel
    depth: int
    type_id: UUID
    summary: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        tenant_id = str(self.tenant_id)

        classification = self.classification.value

        depth = self.depth

        type_id = str(self.type_id)

        summary: None | str | Unset
        if isinstance(self.summary, Unset):
            summary = UNSET
        else:
            summary = self.summary

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "id": id,
                "tenant_id": tenant_id,
                "classification": classification,
                "depth": depth,
                "type_id": type_id,
            }
        )
        if summary is not UNSET:
            field_dict["summary"] = summary

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = UUID(d.pop("id"))

        tenant_id = UUID(d.pop("tenant_id"))

        classification = ClassificationLevel(d.pop("classification"))

        depth = d.pop("depth")

        type_id = UUID(d.pop("type_id"))

        def _parse_summary(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        summary = _parse_summary(d.pop("summary", UNSET))

        traversal_node = cls(
            id=id,
            tenant_id=tenant_id,
            classification=classification,
            depth=depth,
            type_id=type_id,
            summary=summary,
        )

        return traversal_node
