from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="IntentErrorResponse")


@_attrs_define
class IntentErrorResponse:
    """OpenAPI schema for HTTP 422 intent-validation failures.

    Returned when the chokepoint raises :class:`IntentRequiredError` or
    :class:`IntentNotAllowedError`.  The ``allowed`` field lists the
    intent values the route accepts so the caller can correct the request
    without consulting the documentation.

    Fields
    ------
    error_code:
        ``"intent_required"`` or ``"intent_not_allowed"``.
    reason_code:
        One of ``"intent_required"`` or ``"intent_not_allowed"``.
    allowed:
        The allowed intent values for this ``(action, subject_kind)`` pair,
        sorted for determinism.  Empty list when the action is read-only
        (no intent gate applies; this branch is defensive).

    Frozen + strict-extra (AP5).

    Per §10.12; ``03 § Error-management plan``; ``03 § F3``.

        Attributes:
            error_code (str):
            reason_code (str):
            allowed (list[str] | Unset):
    """

    error_code: str
    reason_code: str
    allowed: list[str] | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        error_code = self.error_code

        reason_code = self.reason_code

        allowed: list[str] | Unset = UNSET
        if not isinstance(self.allowed, Unset):
            allowed = self.allowed

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "error_code": error_code,
                "reason_code": reason_code,
            }
        )
        if allowed is not UNSET:
            field_dict["allowed"] = allowed

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        error_code = d.pop("error_code")

        reason_code = d.pop("reason_code")

        allowed = cast(list[str], d.pop("allowed", UNSET))

        intent_error_response = cls(
            error_code=error_code,
            reason_code=reason_code,
            allowed=allowed,
        )

        return intent_error_response
