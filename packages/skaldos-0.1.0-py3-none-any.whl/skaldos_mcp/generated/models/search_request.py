from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="SearchRequest")


@_attrs_define
class SearchRequest:
    """Public/service request model for graph search.

    Attributes:
        tenant_id (UUID):
        query (str):
        limit (int | Unset):  Default: 20.
        lens_id (None | Unset | UUID):
    """

    tenant_id: UUID
    query: str
    limit: int | Unset = 20
    lens_id: None | Unset | UUID = UNSET

    def to_dict(self) -> dict[str, Any]:
        tenant_id = str(self.tenant_id)

        query = self.query

        limit = self.limit

        lens_id: None | str | Unset
        if isinstance(self.lens_id, Unset):
            lens_id = UNSET
        elif isinstance(self.lens_id, UUID):
            lens_id = str(self.lens_id)
        else:
            lens_id = self.lens_id

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "tenant_id": tenant_id,
                "query": query,
            }
        )
        if limit is not UNSET:
            field_dict["limit"] = limit
        if lens_id is not UNSET:
            field_dict["lens_id"] = lens_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        tenant_id = UUID(d.pop("tenant_id"))

        query = d.pop("query")

        limit = d.pop("limit", UNSET)

        def _parse_lens_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                lens_id_type_0 = UUID(data)

                return lens_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        lens_id = _parse_lens_id(d.pop("lens_id", UNSET))

        search_request = cls(
            tenant_id=tenant_id,
            query=query,
            limit=limit,
            lens_id=lens_id,
        )

        return search_request
