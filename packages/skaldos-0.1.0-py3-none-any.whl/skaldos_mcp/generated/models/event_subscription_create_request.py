from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define

from ..models.event_subscription_create_request_state import (
    EventSubscriptionCreateRequestState,
)
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.event_subscription_create_request_delivery import (
        EventSubscriptionCreateRequestDelivery,
    )
    from ..models.event_subscription_create_request_filter import (
        EventSubscriptionCreateRequestFilter,
    )


T = TypeVar("T", bound="EventSubscriptionCreateRequest")


@_attrs_define
class EventSubscriptionCreateRequest:
    """Create payload for one external event subscription.

    Attributes:
        tenant_id (UUID):
        filter_ (EventSubscriptionCreateRequestFilter):
        delivery (EventSubscriptionCreateRequestDelivery):
        subscriber_principal_id (None | Unset | UUID):
        state (EventSubscriptionCreateRequestState | Unset):  Default: EventSubscriptionCreateRequestState.ACTIVE.
    """

    tenant_id: UUID
    filter_: EventSubscriptionCreateRequestFilter
    delivery: EventSubscriptionCreateRequestDelivery
    subscriber_principal_id: None | Unset | UUID = UNSET
    state: EventSubscriptionCreateRequestState | Unset = EventSubscriptionCreateRequestState.ACTIVE

    def to_dict(self) -> dict[str, Any]:
        tenant_id = str(self.tenant_id)

        filter_ = self.filter_.to_dict()

        delivery = self.delivery.to_dict()

        subscriber_principal_id: None | str | Unset
        if isinstance(self.subscriber_principal_id, Unset):
            subscriber_principal_id = UNSET
        elif isinstance(self.subscriber_principal_id, UUID):
            subscriber_principal_id = str(self.subscriber_principal_id)
        else:
            subscriber_principal_id = self.subscriber_principal_id

        state: str | Unset = UNSET
        if not isinstance(self.state, Unset):
            state = self.state.value

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "tenant_id": tenant_id,
                "filter": filter_,
                "delivery": delivery,
            }
        )
        if subscriber_principal_id is not UNSET:
            field_dict["subscriber_principal_id"] = subscriber_principal_id
        if state is not UNSET:
            field_dict["state"] = state

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.event_subscription_create_request_delivery import (
            EventSubscriptionCreateRequestDelivery,
        )
        from ..models.event_subscription_create_request_filter import (
            EventSubscriptionCreateRequestFilter,
        )

        d = dict(src_dict)
        tenant_id = UUID(d.pop("tenant_id"))

        filter_ = EventSubscriptionCreateRequestFilter.from_dict(d.pop("filter"))

        delivery = EventSubscriptionCreateRequestDelivery.from_dict(d.pop("delivery"))

        def _parse_subscriber_principal_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                subscriber_principal_id_type_0 = UUID(data)

                return subscriber_principal_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        subscriber_principal_id = _parse_subscriber_principal_id(
            d.pop("subscriber_principal_id", UNSET)
        )

        _state = d.pop("state", UNSET)
        state: EventSubscriptionCreateRequestState | Unset
        if isinstance(_state, Unset):
            state = UNSET
        else:
            state = EventSubscriptionCreateRequestState(_state)

        event_subscription_create_request = cls(
            tenant_id=tenant_id,
            filter_=filter_,
            delivery=delivery,
            subscriber_principal_id=subscriber_principal_id,
            state=state,
        )

        return event_subscription_create_request
