from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="AuthorizationErrorResponse")


@_attrs_define
class AuthorizationErrorResponse:
    """OpenAPI schema for HTTP 403 authorization-denied responses.

    The JSON body returned by the exception handler when the Oso
    chokepoint denies a request or the principal is disabled at the
    authorization layer.

    Fields
    ------
    error_code:
        Stable error-code string.  Always ``"authorization_denied"``
        for authorization-layer 403s.  Clients (frontend Zod, MCP error
        decoder) dispatch on this value.
    reason_code:
        One of :class:`~skaldos.policy.errors.ReasonCode`'s members.
        Gives the specific reason for denial without exposing
        implementation details (no stack trace; no DB state).

    Frozen + strict-extra (AP5): rejects unknown kwargs at construction.
    No PII in either field (§20.2 / §13.2).

    Per ``03 § Error-management plan``; §10.2; master-plan
    § "Shared artifacts" → "Reason code taxonomy".

        Attributes:
            reason_code (str):
            error_code (str | Unset):  Default: 'authorization_denied'.
    """

    reason_code: str
    error_code: str | Unset = "authorization_denied"

    def to_dict(self) -> dict[str, Any]:
        reason_code = self.reason_code

        error_code = self.error_code

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "reason_code": reason_code,
            }
        )
        if error_code is not UNSET:
            field_dict["error_code"] = error_code

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        reason_code = d.pop("reason_code")

        error_code = d.pop("error_code", UNSET)

        authorization_error_response = cls(
            reason_code=reason_code,
            error_code=error_code,
        )

        return authorization_error_response
