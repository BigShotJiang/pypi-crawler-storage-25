from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="ContextSource")


@_attrs_define
class ContextSource:
    """Visible source handles for one context item.

    Attributes:
        node_metadata_source (None | str | Unset):
    """

    node_metadata_source: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        node_metadata_source: None | str | Unset
        if isinstance(self.node_metadata_source, Unset):
            node_metadata_source = UNSET
        else:
            node_metadata_source = self.node_metadata_source

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if node_metadata_source is not UNSET:
            field_dict["node_metadata_source"] = node_metadata_source

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_node_metadata_source(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        node_metadata_source = _parse_node_metadata_source(d.pop("node_metadata_source", UNSET))

        context_source = cls(
            node_metadata_source=node_metadata_source,
        )

        return context_source
