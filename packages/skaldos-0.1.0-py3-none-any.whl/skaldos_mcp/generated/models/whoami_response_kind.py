from enum import Enum


class WhoamiResponseKind(str, Enum):
    AGENT = "agent"
    HUMAN = "human"

    def __str__(self) -> str:
        return str(self.value)
