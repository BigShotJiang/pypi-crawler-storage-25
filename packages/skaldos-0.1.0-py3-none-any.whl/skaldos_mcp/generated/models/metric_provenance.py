from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define

from ..models.classification_level import ClassificationLevel

if TYPE_CHECKING:
    from ..models.metric_provenance_context_of_validity import (
        MetricProvenanceContextOfValidity,
    )


T = TypeVar("T", bound="MetricProvenance")


@_attrs_define
class MetricProvenance:
    """Visible source span backing a metric contributor.

    Attributes:
        node_id (UUID):
        tag_id (UUID):
        span_offset_start (int):
        span_offset_end (int):
        exact (str):
        context_of_validity (MetricProvenanceContextOfValidity):
        classification (ClassificationLevel): Fixed substrate classification levels, ordered by sensitivity.
    """

    node_id: UUID
    tag_id: UUID
    span_offset_start: int
    span_offset_end: int
    exact: str
    context_of_validity: MetricProvenanceContextOfValidity
    classification: ClassificationLevel

    def to_dict(self) -> dict[str, Any]:
        node_id = str(self.node_id)

        tag_id = str(self.tag_id)

        span_offset_start = self.span_offset_start

        span_offset_end = self.span_offset_end

        exact = self.exact

        context_of_validity = self.context_of_validity.to_dict()

        classification = self.classification.value

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "node_id": node_id,
                "tag_id": tag_id,
                "span_offset_start": span_offset_start,
                "span_offset_end": span_offset_end,
                "exact": exact,
                "context_of_validity": context_of_validity,
                "classification": classification,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.metric_provenance_context_of_validity import (
            MetricProvenanceContextOfValidity,
        )

        d = dict(src_dict)
        node_id = UUID(d.pop("node_id"))

        tag_id = UUID(d.pop("tag_id"))

        span_offset_start = d.pop("span_offset_start")

        span_offset_end = d.pop("span_offset_end")

        exact = d.pop("exact")

        context_of_validity = MetricProvenanceContextOfValidity.from_dict(
            d.pop("context_of_validity")
        )

        classification = ClassificationLevel(d.pop("classification"))

        metric_provenance = cls(
            node_id=node_id,
            tag_id=tag_id,
            span_offset_start=span_offset_start,
            span_offset_end=span_offset_end,
            exact=exact,
            context_of_validity=context_of_validity,
            classification=classification,
        )

        return metric_provenance
