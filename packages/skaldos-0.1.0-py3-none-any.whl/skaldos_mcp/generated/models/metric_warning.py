from enum import Enum


class MetricWarning(str, Enum):
    MISSING_REQUIRED_CURRENCY_EXCLUDED = "missing_required_currency_excluded"
    TRUNCATED_VISIBLE_PROVENANCE = "truncated_visible_provenance"

    def __str__(self) -> str:
        return str(self.value)
