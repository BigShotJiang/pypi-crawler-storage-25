from enum import Enum


class SyncAgentRunRequestClearanceCapType0(str, Enum):
    C0 = "C0"
    C1 = "C1"
    C2 = "C2"
    C3 = "C3"
    C4 = "C4"

    def __str__(self) -> str:
        return str(self.value)
