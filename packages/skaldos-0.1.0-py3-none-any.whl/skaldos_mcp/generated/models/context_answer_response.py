from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define

from ..models.context_answer_response_kind import ContextAnswerResponseKind
from ..models.context_shield_failure_reason import ContextShieldFailureReason
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.context_bundle import ContextBundle


T = TypeVar("T", bound="ContextAnswerResponse")


@_attrs_define
class ContextAnswerResponse:
    """Answer route response with assembled visible context.

    Attributes:
        kind (ContextAnswerResponseKind):
        shield_call_id (UUID):
        context (ContextBundle): Leakage-safe context assembly response shape.
        answer (None | str | Unset):
        reason_code (ContextShieldFailureReason | None | Unset):
        trace_id (None | str | Unset):
    """

    kind: ContextAnswerResponseKind
    shield_call_id: UUID
    context: ContextBundle
    answer: None | str | Unset = UNSET
    reason_code: ContextShieldFailureReason | None | Unset = UNSET
    trace_id: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        kind = self.kind.value

        shield_call_id = str(self.shield_call_id)

        context = self.context.to_dict()

        answer: None | str | Unset
        if isinstance(self.answer, Unset):
            answer = UNSET
        else:
            answer = self.answer

        reason_code: None | str | Unset
        if isinstance(self.reason_code, Unset):
            reason_code = UNSET
        elif isinstance(self.reason_code, ContextShieldFailureReason):
            reason_code = self.reason_code.value
        else:
            reason_code = self.reason_code

        trace_id: None | str | Unset
        if isinstance(self.trace_id, Unset):
            trace_id = UNSET
        else:
            trace_id = self.trace_id

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "kind": kind,
                "shield_call_id": shield_call_id,
                "context": context,
            }
        )
        if answer is not UNSET:
            field_dict["answer"] = answer
        if reason_code is not UNSET:
            field_dict["reason_code"] = reason_code
        if trace_id is not UNSET:
            field_dict["trace_id"] = trace_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.context_bundle import ContextBundle

        d = dict(src_dict)
        kind = ContextAnswerResponseKind(d.pop("kind"))

        shield_call_id = UUID(d.pop("shield_call_id"))

        context = ContextBundle.from_dict(d.pop("context"))

        def _parse_answer(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        answer = _parse_answer(d.pop("answer", UNSET))

        def _parse_reason_code(
            data: object,
        ) -> ContextShieldFailureReason | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                reason_code_type_0 = ContextShieldFailureReason(data)

                return reason_code_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ContextShieldFailureReason | None | Unset, data)

        reason_code = _parse_reason_code(d.pop("reason_code", UNSET))

        def _parse_trace_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        trace_id = _parse_trace_id(d.pop("trace_id", UNSET))

        context_answer_response = cls(
            kind=kind,
            shield_call_id=shield_call_id,
            context=context,
            answer=answer,
            reason_code=reason_code,
            trace_id=trace_id,
        )

        return context_answer_response
