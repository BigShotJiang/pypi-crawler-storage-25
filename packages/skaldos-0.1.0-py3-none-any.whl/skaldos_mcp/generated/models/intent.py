from enum import Enum


class Intent(str, Enum):
    ASSERTIVE = "assertive"
    COMMISSIVE = "commissive"
    DECLARATIVE = "declarative"
    DIRECTIVE = "directive"
    EXPRESSIVE = "expressive"

    def __str__(self) -> str:
        return str(self.value)
