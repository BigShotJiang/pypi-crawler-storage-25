from enum import Enum


class GraphAssertPublicStatus(str, Enum):
    APPLIED = "applied"
    DISAGREEMENT = "disagreement"
    REJECTED = "rejected"
    STAGED = "staged"

    def __str__(self) -> str:
        return str(self.value)
