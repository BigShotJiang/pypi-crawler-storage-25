from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import (
    Any,
    Literal,
    TypeVar,
    cast,
)
from uuid import UUID

from attrs import define as _attrs_define
from dateutil.parser import isoparse

T = TypeVar("T", bound="ClassifierCalibrationProjection")


@_attrs_define
class ClassifierCalibrationProjection:
    """Content-free classifier-family calibration projection row.

    Attributes:
        id (UUID):
        tenant_id (UUID):
        classification (str):
        subject_kind (Literal['classifier-family']):
        subject_key (str):
        action (Literal['classify']):
        subject_type (Literal['node']):
        scope (str):
        context_fingerprint (str):
        calibration_score (None | str):
        surprise_count (int):
        missed_pattern4_count (int):
        human_reviewed_outcome_count (int):
        sample_size (int):
        confidence_interval_bucket (str):
        projection_stale (bool):
        latest_threshold_config_id (None | UUID):
        last_recompute_event_id (None | UUID):
        last_surprise_at (datetime.datetime | None):
        updated_at (datetime.datetime):
    """

    id: UUID
    tenant_id: UUID
    classification: str
    subject_kind: Literal["classifier-family"]
    subject_key: str
    action: Literal["classify"]
    subject_type: Literal["node"]
    scope: str
    context_fingerprint: str
    calibration_score: None | str
    surprise_count: int
    missed_pattern4_count: int
    human_reviewed_outcome_count: int
    sample_size: int
    confidence_interval_bucket: str
    projection_stale: bool
    latest_threshold_config_id: None | UUID
    last_recompute_event_id: None | UUID
    last_surprise_at: datetime.datetime | None
    updated_at: datetime.datetime

    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        tenant_id = str(self.tenant_id)

        classification = self.classification

        subject_kind = self.subject_kind

        subject_key = self.subject_key

        action = self.action

        subject_type = self.subject_type

        scope = self.scope

        context_fingerprint = self.context_fingerprint

        calibration_score: None | str
        calibration_score = self.calibration_score

        surprise_count = self.surprise_count

        missed_pattern4_count = self.missed_pattern4_count

        human_reviewed_outcome_count = self.human_reviewed_outcome_count

        sample_size = self.sample_size

        confidence_interval_bucket = self.confidence_interval_bucket

        projection_stale = self.projection_stale

        latest_threshold_config_id: None | str
        if isinstance(self.latest_threshold_config_id, UUID):
            latest_threshold_config_id = str(self.latest_threshold_config_id)
        else:
            latest_threshold_config_id = self.latest_threshold_config_id

        last_recompute_event_id: None | str
        if isinstance(self.last_recompute_event_id, UUID):
            last_recompute_event_id = str(self.last_recompute_event_id)
        else:
            last_recompute_event_id = self.last_recompute_event_id

        last_surprise_at: None | str
        if isinstance(self.last_surprise_at, datetime.datetime):
            last_surprise_at = self.last_surprise_at.isoformat()
        else:
            last_surprise_at = self.last_surprise_at

        updated_at = self.updated_at.isoformat()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "id": id,
                "tenant_id": tenant_id,
                "classification": classification,
                "subject_kind": subject_kind,
                "subject_key": subject_key,
                "action": action,
                "subject_type": subject_type,
                "scope": scope,
                "context_fingerprint": context_fingerprint,
                "calibration_score": calibration_score,
                "surprise_count": surprise_count,
                "missed_pattern4_count": missed_pattern4_count,
                "human_reviewed_outcome_count": human_reviewed_outcome_count,
                "sample_size": sample_size,
                "confidence_interval_bucket": confidence_interval_bucket,
                "projection_stale": projection_stale,
                "latest_threshold_config_id": latest_threshold_config_id,
                "last_recompute_event_id": last_recompute_event_id,
                "last_surprise_at": last_surprise_at,
                "updated_at": updated_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = UUID(d.pop("id"))

        tenant_id = UUID(d.pop("tenant_id"))

        classification = d.pop("classification")

        subject_kind = cast(Literal["classifier-family"], d.pop("subject_kind"))
        if subject_kind != "classifier-family":
            raise ValueError(
                f"subject_kind must match const 'classifier-family', got '{subject_kind}'"
            )

        subject_key = d.pop("subject_key")

        action = cast(Literal["classify"], d.pop("action"))
        if action != "classify":
            raise ValueError(f"action must match const 'classify', got '{action}'")

        subject_type = cast(Literal["node"], d.pop("subject_type"))
        if subject_type != "node":
            raise ValueError(f"subject_type must match const 'node', got '{subject_type}'")

        scope = d.pop("scope")

        context_fingerprint = d.pop("context_fingerprint")

        def _parse_calibration_score(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        calibration_score = _parse_calibration_score(d.pop("calibration_score"))

        surprise_count = d.pop("surprise_count")

        missed_pattern4_count = d.pop("missed_pattern4_count")

        human_reviewed_outcome_count = d.pop("human_reviewed_outcome_count")

        sample_size = d.pop("sample_size")

        confidence_interval_bucket = d.pop("confidence_interval_bucket")

        projection_stale = d.pop("projection_stale")

        def _parse_latest_threshold_config_id(data: object) -> None | UUID:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                latest_threshold_config_id_type_0 = UUID(data)

                return latest_threshold_config_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | UUID, data)

        latest_threshold_config_id = _parse_latest_threshold_config_id(
            d.pop("latest_threshold_config_id")
        )

        def _parse_last_recompute_event_id(data: object) -> None | UUID:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_recompute_event_id_type_0 = UUID(data)

                return last_recompute_event_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | UUID, data)

        last_recompute_event_id = _parse_last_recompute_event_id(d.pop("last_recompute_event_id"))

        def _parse_last_surprise_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_surprise_at_type_0 = isoparse(data)

                return last_surprise_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        last_surprise_at = _parse_last_surprise_at(d.pop("last_surprise_at"))

        updated_at = isoparse(d.pop("updated_at"))

        classifier_calibration_projection = cls(
            id=id,
            tenant_id=tenant_id,
            classification=classification,
            subject_kind=subject_kind,
            subject_key=subject_key,
            action=action,
            subject_type=subject_type,
            scope=scope,
            context_fingerprint=context_fingerprint,
            calibration_score=calibration_score,
            surprise_count=surprise_count,
            missed_pattern4_count=missed_pattern4_count,
            human_reviewed_outcome_count=human_reviewed_outcome_count,
            sample_size=sample_size,
            confidence_interval_bucket=confidence_interval_bucket,
            projection_stale=projection_stale,
            latest_threshold_config_id=latest_threshold_config_id,
            last_recompute_event_id=last_recompute_event_id,
            last_surprise_at=last_surprise_at,
            updated_at=updated_at,
        )

        return classifier_calibration_projection
