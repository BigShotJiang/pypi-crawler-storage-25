from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define

from ..models.classification_level import ClassificationLevel
from ..models.metric_aggregate import MetricAggregate
from ..models.metric_warning import MetricWarning
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.metric_provenance import MetricProvenance


T = TypeVar("T", bound="MetricResult")


@_attrs_define
class MetricResult:
    """Visible-only metric response with bounded provenance.

    Attributes:
        metric_id (UUID):
        tenant_id (UUID):
        aggregate (MetricAggregate): First Slice 6 metric aggregate vocabulary.
        value (str):
        unit_or_currency (None | str):
        visible_contributor_count (int):
        result_classification (ClassificationLevel | None):
        provenance (list[MetricProvenance]):
        truncated (bool):
        warnings (list[MetricWarning] | Unset):
    """

    metric_id: UUID
    tenant_id: UUID
    aggregate: MetricAggregate
    value: str
    unit_or_currency: None | str
    visible_contributor_count: int
    result_classification: ClassificationLevel | None
    provenance: list[MetricProvenance]
    truncated: bool
    warnings: list[MetricWarning] | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        metric_id = str(self.metric_id)

        tenant_id = str(self.tenant_id)

        aggregate = self.aggregate.value

        value = self.value

        unit_or_currency: None | str
        unit_or_currency = self.unit_or_currency

        visible_contributor_count = self.visible_contributor_count

        result_classification: None | str
        if isinstance(self.result_classification, ClassificationLevel):
            result_classification = self.result_classification.value
        else:
            result_classification = self.result_classification

        provenance = []
        for provenance_item_data in self.provenance:
            provenance_item = provenance_item_data.to_dict()
            provenance.append(provenance_item)

        truncated = self.truncated

        warnings: list[str] | Unset = UNSET
        if not isinstance(self.warnings, Unset):
            warnings = []
            for warnings_item_data in self.warnings:
                warnings_item = warnings_item_data.value
                warnings.append(warnings_item)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "metric_id": metric_id,
                "tenant_id": tenant_id,
                "aggregate": aggregate,
                "value": value,
                "unit_or_currency": unit_or_currency,
                "visible_contributor_count": visible_contributor_count,
                "result_classification": result_classification,
                "provenance": provenance,
                "truncated": truncated,
            }
        )
        if warnings is not UNSET:
            field_dict["warnings"] = warnings

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.metric_provenance import MetricProvenance

        d = dict(src_dict)
        metric_id = UUID(d.pop("metric_id"))

        tenant_id = UUID(d.pop("tenant_id"))

        aggregate = MetricAggregate(d.pop("aggregate"))

        value = d.pop("value")

        def _parse_unit_or_currency(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        unit_or_currency = _parse_unit_or_currency(d.pop("unit_or_currency"))

        visible_contributor_count = d.pop("visible_contributor_count")

        def _parse_result_classification(data: object) -> ClassificationLevel | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                result_classification_type_0 = ClassificationLevel(data)

                return result_classification_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ClassificationLevel | None, data)

        result_classification = _parse_result_classification(d.pop("result_classification"))

        provenance = []
        _provenance = d.pop("provenance")
        for provenance_item_data in _provenance:
            provenance_item = MetricProvenance.from_dict(provenance_item_data)

            provenance.append(provenance_item)

        truncated = d.pop("truncated")

        _warnings = d.pop("warnings", UNSET)
        warnings: list[MetricWarning] | Unset = UNSET
        if _warnings is not UNSET:
            warnings = []
            for warnings_item_data in _warnings:
                warnings_item = MetricWarning(warnings_item_data)

                warnings.append(warnings_item)

        metric_result = cls(
            metric_id=metric_id,
            tenant_id=tenant_id,
            aggregate=aggregate,
            value=value,
            unit_or_currency=unit_or_currency,
            visible_contributor_count=visible_contributor_count,
            result_classification=result_classification,
            provenance=provenance,
            truncated=truncated,
            warnings=warnings,
        )

        return metric_result
