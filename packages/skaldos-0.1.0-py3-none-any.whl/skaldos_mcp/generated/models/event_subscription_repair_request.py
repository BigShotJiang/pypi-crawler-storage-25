from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.event_subscription_repair_request_delivery import (
        EventSubscriptionRepairRequestDelivery,
    )


T = TypeVar("T", bound="EventSubscriptionRepairRequest")


@_attrs_define
class EventSubscriptionRepairRequest:
    """Repair a failed subscription and replace the push target.

    Attributes:
        version (int):
        delivery (EventSubscriptionRepairRequestDelivery):
    """

    version: int
    delivery: EventSubscriptionRepairRequestDelivery

    def to_dict(self) -> dict[str, Any]:
        version = self.version

        delivery = self.delivery.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "version": version,
                "delivery": delivery,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.event_subscription_repair_request_delivery import (
            EventSubscriptionRepairRequestDelivery,
        )

        d = dict(src_dict)
        version = d.pop("version")

        delivery = EventSubscriptionRepairRequestDelivery.from_dict(d.pop("delivery"))

        event_subscription_repair_request = cls(
            version=version,
            delivery=delivery,
        )

        return event_subscription_repair_request
