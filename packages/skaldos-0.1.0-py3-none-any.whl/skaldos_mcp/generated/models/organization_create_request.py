from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define

T = TypeVar("T", bound="OrganizationCreateRequest")


@_attrs_define
class OrganizationCreateRequest:
    """Request body for the organization-create fixture handler.

    ``display_name``: the human-readable label for the new organization.
    Only relevant on the (unreachable) allow path — the chokepoint denies
    every create-Organization request, so the body is never read by Oso.

    ``frozen=True, extra="forbid"`` mirrors production discipline.

        Attributes:
            display_name (str):
    """

    display_name: str

    def to_dict(self) -> dict[str, Any]:
        display_name = self.display_name

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "display_name": display_name,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        display_name = d.pop("display_name")

        organization_create_request = cls(
            display_name=display_name,
        )

        return organization_create_request
