from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

from ..models.lens_rule_kind import LensRuleKind

if TYPE_CHECKING:
    from ..models.lens_signal import LensSignal


T = TypeVar("T", bound="LensRule")


@_attrs_define
class LensRule:
    """A bounded additive ranking rule.

    Attributes:
        rule_id (str):
        kind (LensRuleKind):
        signal (LensSignal): A positive or negative ranking feature, never a visibility predicate.
        weight (float):
    """

    rule_id: str
    kind: LensRuleKind
    signal: LensSignal
    weight: float

    def to_dict(self) -> dict[str, Any]:
        rule_id = self.rule_id

        kind = self.kind.value

        signal = self.signal.to_dict()

        weight = self.weight

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "rule_id": rule_id,
                "kind": kind,
                "signal": signal,
                "weight": weight,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.lens_signal import LensSignal

        d = dict(src_dict)
        rule_id = d.pop("rule_id")

        kind = LensRuleKind(d.pop("kind"))

        signal = LensSignal.from_dict(d.pop("signal"))

        weight = d.pop("weight")

        lens_rule = cls(
            rule_id=rule_id,
            kind=kind,
            signal=signal,
            weight=weight,
        )

        return lens_rule
