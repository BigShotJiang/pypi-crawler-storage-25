from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define

from ..models.event_subscription_patch_request_state_type_0 import (
    EventSubscriptionPatchRequestStateType0,
)
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.event_subscription_patch_request_delivery_type_0 import (
        EventSubscriptionPatchRequestDeliveryType0,
    )
    from ..models.event_subscription_patch_request_filter_type_0 import (
        EventSubscriptionPatchRequestFilterType0,
    )


T = TypeVar("T", bound="EventSubscriptionPatchRequest")


@_attrs_define
class EventSubscriptionPatchRequest:
    """Patch payload for mutable registration fields.

    Attributes:
        version (int):
        filter_ (EventSubscriptionPatchRequestFilterType0 | None | Unset):
        delivery (EventSubscriptionPatchRequestDeliveryType0 | None | Unset):
        state (EventSubscriptionPatchRequestStateType0 | None | Unset):
    """

    version: int
    filter_: EventSubscriptionPatchRequestFilterType0 | None | Unset = UNSET
    delivery: EventSubscriptionPatchRequestDeliveryType0 | None | Unset = UNSET
    state: EventSubscriptionPatchRequestStateType0 | None | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        from ..models.event_subscription_patch_request_delivery_type_0 import (
            EventSubscriptionPatchRequestDeliveryType0,
        )
        from ..models.event_subscription_patch_request_filter_type_0 import (
            EventSubscriptionPatchRequestFilterType0,
        )

        version = self.version

        filter_: dict[str, Any] | None | Unset
        if isinstance(self.filter_, Unset):
            filter_ = UNSET
        elif isinstance(self.filter_, EventSubscriptionPatchRequestFilterType0):
            filter_ = self.filter_.to_dict()
        else:
            filter_ = self.filter_

        delivery: dict[str, Any] | None | Unset
        if isinstance(self.delivery, Unset):
            delivery = UNSET
        elif isinstance(self.delivery, EventSubscriptionPatchRequestDeliveryType0):
            delivery = self.delivery.to_dict()
        else:
            delivery = self.delivery

        state: None | str | Unset
        if isinstance(self.state, Unset):
            state = UNSET
        elif isinstance(self.state, EventSubscriptionPatchRequestStateType0):
            state = self.state.value
        else:
            state = self.state

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "version": version,
            }
        )
        if filter_ is not UNSET:
            field_dict["filter"] = filter_
        if delivery is not UNSET:
            field_dict["delivery"] = delivery
        if state is not UNSET:
            field_dict["state"] = state

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.event_subscription_patch_request_delivery_type_0 import (
            EventSubscriptionPatchRequestDeliveryType0,
        )
        from ..models.event_subscription_patch_request_filter_type_0 import (
            EventSubscriptionPatchRequestFilterType0,
        )

        d = dict(src_dict)
        version = d.pop("version")

        def _parse_filter_(
            data: object,
        ) -> EventSubscriptionPatchRequestFilterType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                filter_type_0 = EventSubscriptionPatchRequestFilterType0.from_dict(data)

                return filter_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(EventSubscriptionPatchRequestFilterType0 | None | Unset, data)

        filter_ = _parse_filter_(d.pop("filter", UNSET))

        def _parse_delivery(
            data: object,
        ) -> EventSubscriptionPatchRequestDeliveryType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                delivery_type_0 = EventSubscriptionPatchRequestDeliveryType0.from_dict(data)

                return delivery_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(EventSubscriptionPatchRequestDeliveryType0 | None | Unset, data)

        delivery = _parse_delivery(d.pop("delivery", UNSET))

        def _parse_state(
            data: object,
        ) -> EventSubscriptionPatchRequestStateType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                state_type_0 = EventSubscriptionPatchRequestStateType0(data)

                return state_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(EventSubscriptionPatchRequestStateType0 | None | Unset, data)

        state = _parse_state(d.pop("state", UNSET))

        event_subscription_patch_request = cls(
            version=version,
            filter_=filter_,
            delivery=delivery,
            state=state,
        )

        return event_subscription_patch_request
