from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define

T = TypeVar("T", bound="LensDefinitionListMetadata")


@_attrs_define
class LensDefinitionListMetadata:
    """Content-free lens-list request metadata.

    Attributes:
        tenant_id (UUID):
        include_archived (bool):
    """

    tenant_id: UUID
    include_archived: bool

    def to_dict(self) -> dict[str, Any]:
        tenant_id = str(self.tenant_id)

        include_archived = self.include_archived

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "tenant_id": tenant_id,
                "include_archived": include_archived,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        tenant_id = UUID(d.pop("tenant_id"))

        include_archived = d.pop("include_archived")

        lens_definition_list_metadata = cls(
            tenant_id=tenant_id,
            include_archived=include_archived,
        )

        return lens_definition_list_metadata
