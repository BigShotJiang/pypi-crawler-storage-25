from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define

T = TypeVar("T", bound="AgentRunSandboxLifecycleResponse")


@_attrs_define
class AgentRunSandboxLifecycleResponse:
    """Content-free sandbox lifecycle response for live validation.

    Attributes:
        agent_run_id (UUID):
        sandbox_id (UUID):
        status (str):
        sandbox_state (str):
        provider (str):
        provider_handle (None | str):
        transitioned (bool):
    """

    agent_run_id: UUID
    sandbox_id: UUID
    status: str
    sandbox_state: str
    provider: str
    provider_handle: None | str
    transitioned: bool

    def to_dict(self) -> dict[str, Any]:
        agent_run_id = str(self.agent_run_id)

        sandbox_id = str(self.sandbox_id)

        status = self.status

        sandbox_state = self.sandbox_state

        provider = self.provider

        provider_handle: None | str
        provider_handle = self.provider_handle

        transitioned = self.transitioned

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "agent_run_id": agent_run_id,
                "sandbox_id": sandbox_id,
                "status": status,
                "sandbox_state": sandbox_state,
                "provider": provider,
                "provider_handle": provider_handle,
                "transitioned": transitioned,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        agent_run_id = UUID(d.pop("agent_run_id"))

        sandbox_id = UUID(d.pop("sandbox_id"))

        status = d.pop("status")

        sandbox_state = d.pop("sandbox_state")

        provider = d.pop("provider")

        def _parse_provider_handle(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        provider_handle = _parse_provider_handle(d.pop("provider_handle"))

        transitioned = d.pop("transitioned")

        agent_run_sandbox_lifecycle_response = cls(
            agent_run_id=agent_run_id,
            sandbox_id=sandbox_id,
            status=status,
            sandbox_state=sandbox_state,
            provider=provider,
            provider_handle=provider_handle,
            transitioned=transitioned,
        )

        return agent_run_sandbox_lifecycle_response
