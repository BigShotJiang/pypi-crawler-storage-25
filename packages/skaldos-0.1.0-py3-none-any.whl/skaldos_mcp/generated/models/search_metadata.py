from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define

from ..models.search_branch import SearchBranch
from ..models.search_degradation_code import SearchDegradationCode
from ..types import UNSET, Unset

T = TypeVar("T", bound="SearchMetadata")


@_attrs_define
class SearchMetadata:
    """Value-free response metadata.

    Attributes:
        executed_branches (list[SearchBranch]):
        degradation_codes (list[SearchDegradationCode]):
        limit (int):
        truncated (bool):
        shield_call_id (None | Unset | UUID):
        query_digest (None | str | Unset):
    """

    executed_branches: list[SearchBranch]
    degradation_codes: list[SearchDegradationCode]
    limit: int
    truncated: bool
    shield_call_id: None | Unset | UUID = UNSET
    query_digest: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        executed_branches = []
        for executed_branches_item_data in self.executed_branches:
            executed_branches_item = executed_branches_item_data.value
            executed_branches.append(executed_branches_item)

        degradation_codes = []
        for degradation_codes_item_data in self.degradation_codes:
            degradation_codes_item = degradation_codes_item_data.value
            degradation_codes.append(degradation_codes_item)

        limit = self.limit

        truncated = self.truncated

        shield_call_id: None | str | Unset
        if isinstance(self.shield_call_id, Unset):
            shield_call_id = UNSET
        elif isinstance(self.shield_call_id, UUID):
            shield_call_id = str(self.shield_call_id)
        else:
            shield_call_id = self.shield_call_id

        query_digest: None | str | Unset
        if isinstance(self.query_digest, Unset):
            query_digest = UNSET
        else:
            query_digest = self.query_digest

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "executed_branches": executed_branches,
                "degradation_codes": degradation_codes,
                "limit": limit,
                "truncated": truncated,
            }
        )
        if shield_call_id is not UNSET:
            field_dict["shield_call_id"] = shield_call_id
        if query_digest is not UNSET:
            field_dict["query_digest"] = query_digest

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        executed_branches = []
        _executed_branches = d.pop("executed_branches")
        for executed_branches_item_data in _executed_branches:
            executed_branches_item = SearchBranch(executed_branches_item_data)

            executed_branches.append(executed_branches_item)

        degradation_codes = []
        _degradation_codes = d.pop("degradation_codes")
        for degradation_codes_item_data in _degradation_codes:
            degradation_codes_item = SearchDegradationCode(degradation_codes_item_data)

            degradation_codes.append(degradation_codes_item)

        limit = d.pop("limit")

        truncated = d.pop("truncated")

        def _parse_shield_call_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                shield_call_id_type_0 = UUID(data)

                return shield_call_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        shield_call_id = _parse_shield_call_id(d.pop("shield_call_id", UNSET))

        def _parse_query_digest(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        query_digest = _parse_query_digest(d.pop("query_digest", UNSET))

        search_metadata = cls(
            executed_branches=executed_branches,
            degradation_codes=degradation_codes,
            limit=limit,
            truncated=truncated,
            shield_call_id=shield_call_id,
            query_digest=query_digest,
        )

        return search_metadata
