from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from dateutil.parser import isoparse

T = TypeVar("T", bound="ClassifierThresholdVersion")


@_attrs_define
class ClassifierThresholdVersion:
    """Read-only threshold config version metadata.

    Attributes:
        id (UUID):
        tenant_id (UUID):
        ontology_version_id (UUID):
        classification (str):
        node_type_family (str):
        classifier_name (str):
        classifier_version (str):
        config_version (int):
        threshold (str):
        min_threshold (str):
        max_threshold (str):
        tightening_step (str):
        sample_size_floor (int):
        miss_count_window (int):
        supersedes_config_id (None | UUID):
        created_from_surprise_id (None | UUID):
        active_from (datetime.datetime):
        active_to (datetime.datetime | None):
        created_by_system (bool):
        created_at (datetime.datetime):
    """

    id: UUID
    tenant_id: UUID
    ontology_version_id: UUID
    classification: str
    node_type_family: str
    classifier_name: str
    classifier_version: str
    config_version: int
    threshold: str
    min_threshold: str
    max_threshold: str
    tightening_step: str
    sample_size_floor: int
    miss_count_window: int
    supersedes_config_id: None | UUID
    created_from_surprise_id: None | UUID
    active_from: datetime.datetime
    active_to: datetime.datetime | None
    created_by_system: bool
    created_at: datetime.datetime

    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        tenant_id = str(self.tenant_id)

        ontology_version_id = str(self.ontology_version_id)

        classification = self.classification

        node_type_family = self.node_type_family

        classifier_name = self.classifier_name

        classifier_version = self.classifier_version

        config_version = self.config_version

        threshold = self.threshold

        min_threshold = self.min_threshold

        max_threshold = self.max_threshold

        tightening_step = self.tightening_step

        sample_size_floor = self.sample_size_floor

        miss_count_window = self.miss_count_window

        supersedes_config_id: None | str
        if isinstance(self.supersedes_config_id, UUID):
            supersedes_config_id = str(self.supersedes_config_id)
        else:
            supersedes_config_id = self.supersedes_config_id

        created_from_surprise_id: None | str
        if isinstance(self.created_from_surprise_id, UUID):
            created_from_surprise_id = str(self.created_from_surprise_id)
        else:
            created_from_surprise_id = self.created_from_surprise_id

        active_from = self.active_from.isoformat()

        active_to: None | str
        if isinstance(self.active_to, datetime.datetime):
            active_to = self.active_to.isoformat()
        else:
            active_to = self.active_to

        created_by_system = self.created_by_system

        created_at = self.created_at.isoformat()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "id": id,
                "tenant_id": tenant_id,
                "ontology_version_id": ontology_version_id,
                "classification": classification,
                "node_type_family": node_type_family,
                "classifier_name": classifier_name,
                "classifier_version": classifier_version,
                "config_version": config_version,
                "threshold": threshold,
                "min_threshold": min_threshold,
                "max_threshold": max_threshold,
                "tightening_step": tightening_step,
                "sample_size_floor": sample_size_floor,
                "miss_count_window": miss_count_window,
                "supersedes_config_id": supersedes_config_id,
                "created_from_surprise_id": created_from_surprise_id,
                "active_from": active_from,
                "active_to": active_to,
                "created_by_system": created_by_system,
                "created_at": created_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = UUID(d.pop("id"))

        tenant_id = UUID(d.pop("tenant_id"))

        ontology_version_id = UUID(d.pop("ontology_version_id"))

        classification = d.pop("classification")

        node_type_family = d.pop("node_type_family")

        classifier_name = d.pop("classifier_name")

        classifier_version = d.pop("classifier_version")

        config_version = d.pop("config_version")

        threshold = d.pop("threshold")

        min_threshold = d.pop("min_threshold")

        max_threshold = d.pop("max_threshold")

        tightening_step = d.pop("tightening_step")

        sample_size_floor = d.pop("sample_size_floor")

        miss_count_window = d.pop("miss_count_window")

        def _parse_supersedes_config_id(data: object) -> None | UUID:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                supersedes_config_id_type_0 = UUID(data)

                return supersedes_config_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | UUID, data)

        supersedes_config_id = _parse_supersedes_config_id(d.pop("supersedes_config_id"))

        def _parse_created_from_surprise_id(data: object) -> None | UUID:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                created_from_surprise_id_type_0 = UUID(data)

                return created_from_surprise_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | UUID, data)

        created_from_surprise_id = _parse_created_from_surprise_id(
            d.pop("created_from_surprise_id")
        )

        active_from = isoparse(d.pop("active_from"))

        def _parse_active_to(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                active_to_type_0 = isoparse(data)

                return active_to_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        active_to = _parse_active_to(d.pop("active_to"))

        created_by_system = d.pop("created_by_system")

        created_at = isoparse(d.pop("created_at"))

        classifier_threshold_version = cls(
            id=id,
            tenant_id=tenant_id,
            ontology_version_id=ontology_version_id,
            classification=classification,
            node_type_family=node_type_family,
            classifier_name=classifier_name,
            classifier_version=classifier_version,
            config_version=config_version,
            threshold=threshold,
            min_threshold=min_threshold,
            max_threshold=max_threshold,
            tightening_step=tightening_step,
            sample_size_floor=sample_size_floor,
            miss_count_window=miss_count_window,
            supersedes_config_id=supersedes_config_id,
            created_from_surprise_id=created_from_surprise_id,
            active_from=active_from,
            active_to=active_to,
            created_by_system=created_by_system,
            created_at=created_at,
        )

        return classifier_threshold_version
