from enum import Enum


class EventSubscriptionRecordState(str, Enum):
    ACTIVE = "active"
    FAILED = "failed"
    PAUSED = "paused"

    def __str__(self) -> str:
        return str(self.value)
