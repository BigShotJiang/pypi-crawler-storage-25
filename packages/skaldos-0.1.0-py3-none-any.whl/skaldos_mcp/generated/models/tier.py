from enum import Enum


class Tier(str, Enum):
    AUTH = "auth"
    STANDARD = "standard"
    WRITE_HEAVY = "write_heavy"

    def __str__(self) -> str:
        return str(self.value)
