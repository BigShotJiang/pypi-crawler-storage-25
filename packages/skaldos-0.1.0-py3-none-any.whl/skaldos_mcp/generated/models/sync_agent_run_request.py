from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define

from ..models.agent_trigger_kind import AgentTriggerKind
from ..models.sync_agent_run_request_clearance_cap_type_0 import (
    SyncAgentRunRequestClearanceCapType0,
)
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.sync_agent_trigger_ref import SyncAgentTriggerRef


T = TypeVar("T", bound="SyncAgentRunRequest")


@_attrs_define
class SyncAgentRunRequest:
    """HTTP contract for sync-only Slice 7 agent launch.

    Attributes:
        tenant_id (UUID):
        trigger_kind (AgentTriggerKind | Unset): Agent invocation source vocabulary.
        request_id (UUID | Unset):
        clearance_cap (None | SyncAgentRunRequestClearanceCapType0 | Unset):
        trace_id (None | str | Unset):
        span_id (None | str | Unset):
        timeout_seconds (int | Unset):  Default: 300.
        trigger_ref (SyncAgentTriggerRef | Unset): Allowlisted content-free launch correlation handles.
    """

    tenant_id: UUID
    trigger_kind: AgentTriggerKind | Unset = UNSET
    request_id: UUID | Unset = UNSET
    clearance_cap: None | SyncAgentRunRequestClearanceCapType0 | Unset = UNSET
    trace_id: None | str | Unset = UNSET
    span_id: None | str | Unset = UNSET
    timeout_seconds: int | Unset = 300
    trigger_ref: SyncAgentTriggerRef | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        tenant_id = str(self.tenant_id)

        trigger_kind: str | Unset = UNSET
        if not isinstance(self.trigger_kind, Unset):
            trigger_kind = self.trigger_kind.value

        request_id: str | Unset = UNSET
        if not isinstance(self.request_id, Unset):
            request_id = str(self.request_id)

        clearance_cap: None | str | Unset
        if isinstance(self.clearance_cap, Unset):
            clearance_cap = UNSET
        elif isinstance(self.clearance_cap, SyncAgentRunRequestClearanceCapType0):
            clearance_cap = self.clearance_cap.value
        else:
            clearance_cap = self.clearance_cap

        trace_id: None | str | Unset
        if isinstance(self.trace_id, Unset):
            trace_id = UNSET
        else:
            trace_id = self.trace_id

        span_id: None | str | Unset
        if isinstance(self.span_id, Unset):
            span_id = UNSET
        else:
            span_id = self.span_id

        timeout_seconds = self.timeout_seconds

        trigger_ref: dict[str, Any] | Unset = UNSET
        if not isinstance(self.trigger_ref, Unset):
            trigger_ref = self.trigger_ref.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "tenant_id": tenant_id,
            }
        )
        if trigger_kind is not UNSET:
            field_dict["trigger_kind"] = trigger_kind
        if request_id is not UNSET:
            field_dict["request_id"] = request_id
        if clearance_cap is not UNSET:
            field_dict["clearance_cap"] = clearance_cap
        if trace_id is not UNSET:
            field_dict["trace_id"] = trace_id
        if span_id is not UNSET:
            field_dict["span_id"] = span_id
        if timeout_seconds is not UNSET:
            field_dict["timeout_seconds"] = timeout_seconds
        if trigger_ref is not UNSET:
            field_dict["trigger_ref"] = trigger_ref

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.sync_agent_trigger_ref import SyncAgentTriggerRef

        d = dict(src_dict)
        tenant_id = UUID(d.pop("tenant_id"))

        _trigger_kind = d.pop("trigger_kind", UNSET)
        trigger_kind: AgentTriggerKind | Unset
        if isinstance(_trigger_kind, Unset):
            trigger_kind = UNSET
        else:
            trigger_kind = AgentTriggerKind(_trigger_kind)

        _request_id = d.pop("request_id", UNSET)
        request_id: UUID | Unset
        if isinstance(_request_id, Unset):
            request_id = UNSET
        else:
            request_id = UUID(_request_id)

        def _parse_clearance_cap(
            data: object,
        ) -> None | SyncAgentRunRequestClearanceCapType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                clearance_cap_type_0 = SyncAgentRunRequestClearanceCapType0(data)

                return clearance_cap_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | SyncAgentRunRequestClearanceCapType0 | Unset, data)

        clearance_cap = _parse_clearance_cap(d.pop("clearance_cap", UNSET))

        def _parse_trace_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        trace_id = _parse_trace_id(d.pop("trace_id", UNSET))

        def _parse_span_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        span_id = _parse_span_id(d.pop("span_id", UNSET))

        timeout_seconds = d.pop("timeout_seconds", UNSET)

        _trigger_ref = d.pop("trigger_ref", UNSET)
        trigger_ref: SyncAgentTriggerRef | Unset
        if isinstance(_trigger_ref, Unset):
            trigger_ref = UNSET
        else:
            trigger_ref = SyncAgentTriggerRef.from_dict(_trigger_ref)

        sync_agent_run_request = cls(
            tenant_id=tenant_id,
            trigger_kind=trigger_kind,
            request_id=request_id,
            clearance_cap=clearance_cap,
            trace_id=trace_id,
            span_id=span_id,
            timeout_seconds=timeout_seconds,
            trigger_ref=trigger_ref,
        )

        return sync_agent_run_request
