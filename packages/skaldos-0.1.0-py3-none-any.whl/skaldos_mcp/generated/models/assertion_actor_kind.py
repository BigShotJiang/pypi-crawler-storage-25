from enum import Enum


class AssertionActorKind(str, Enum):
    AGENT = "agent"
    HUMAN = "human"

    def __str__(self) -> str:
        return str(self.value)
