from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define

from ..models.sensitivity_tier import SensitivityTier
from ..types import UNSET, Unset

T = TypeVar("T", bound="ContextAnswerRequest")


@_attrs_define
class ContextAnswerRequest:
    """Request for assembling context and answering via canonical Shield.

    Attributes:
        tenant_id (UUID):
        question (str):
        tag_ids (list[UUID] | Unset):
        node_ids (list[UUID] | Unset):
        tag_definition_ids (list[UUID] | Unset):
        limit (int | Unset):  Default: 20.
        neighborhood_chars (int | Unset):  Default: 200.
        requested_sensitivity (None | SensitivityTier | Unset):
        trace_id (None | str | Unset):
        span_id (None | str | Unset):
    """

    tenant_id: UUID
    question: str
    tag_ids: list[UUID] | Unset = UNSET
    node_ids: list[UUID] | Unset = UNSET
    tag_definition_ids: list[UUID] | Unset = UNSET
    limit: int | Unset = 20
    neighborhood_chars: int | Unset = 200
    requested_sensitivity: None | SensitivityTier | Unset = UNSET
    trace_id: None | str | Unset = UNSET
    span_id: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        tenant_id = str(self.tenant_id)

        question = self.question

        tag_ids: list[str] | Unset = UNSET
        if not isinstance(self.tag_ids, Unset):
            tag_ids = []
            for tag_ids_item_data in self.tag_ids:
                tag_ids_item = str(tag_ids_item_data)
                tag_ids.append(tag_ids_item)

        node_ids: list[str] | Unset = UNSET
        if not isinstance(self.node_ids, Unset):
            node_ids = []
            for node_ids_item_data in self.node_ids:
                node_ids_item = str(node_ids_item_data)
                node_ids.append(node_ids_item)

        tag_definition_ids: list[str] | Unset = UNSET
        if not isinstance(self.tag_definition_ids, Unset):
            tag_definition_ids = []
            for tag_definition_ids_item_data in self.tag_definition_ids:
                tag_definition_ids_item = str(tag_definition_ids_item_data)
                tag_definition_ids.append(tag_definition_ids_item)

        limit = self.limit

        neighborhood_chars = self.neighborhood_chars

        requested_sensitivity: int | None | Unset
        if isinstance(self.requested_sensitivity, Unset):
            requested_sensitivity = UNSET
        elif isinstance(self.requested_sensitivity, SensitivityTier):
            requested_sensitivity = self.requested_sensitivity.value
        else:
            requested_sensitivity = self.requested_sensitivity

        trace_id: None | str | Unset
        if isinstance(self.trace_id, Unset):
            trace_id = UNSET
        else:
            trace_id = self.trace_id

        span_id: None | str | Unset
        if isinstance(self.span_id, Unset):
            span_id = UNSET
        else:
            span_id = self.span_id

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "tenant_id": tenant_id,
                "question": question,
            }
        )
        if tag_ids is not UNSET:
            field_dict["tag_ids"] = tag_ids
        if node_ids is not UNSET:
            field_dict["node_ids"] = node_ids
        if tag_definition_ids is not UNSET:
            field_dict["tag_definition_ids"] = tag_definition_ids
        if limit is not UNSET:
            field_dict["limit"] = limit
        if neighborhood_chars is not UNSET:
            field_dict["neighborhood_chars"] = neighborhood_chars
        if requested_sensitivity is not UNSET:
            field_dict["requested_sensitivity"] = requested_sensitivity
        if trace_id is not UNSET:
            field_dict["trace_id"] = trace_id
        if span_id is not UNSET:
            field_dict["span_id"] = span_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        tenant_id = UUID(d.pop("tenant_id"))

        question = d.pop("question")

        _tag_ids = d.pop("tag_ids", UNSET)
        tag_ids: list[UUID] | Unset = UNSET
        if _tag_ids is not UNSET:
            tag_ids = []
            for tag_ids_item_data in _tag_ids:
                tag_ids_item = UUID(tag_ids_item_data)

                tag_ids.append(tag_ids_item)

        _node_ids = d.pop("node_ids", UNSET)
        node_ids: list[UUID] | Unset = UNSET
        if _node_ids is not UNSET:
            node_ids = []
            for node_ids_item_data in _node_ids:
                node_ids_item = UUID(node_ids_item_data)

                node_ids.append(node_ids_item)

        _tag_definition_ids = d.pop("tag_definition_ids", UNSET)
        tag_definition_ids: list[UUID] | Unset = UNSET
        if _tag_definition_ids is not UNSET:
            tag_definition_ids = []
            for tag_definition_ids_item_data in _tag_definition_ids:
                tag_definition_ids_item = UUID(tag_definition_ids_item_data)

                tag_definition_ids.append(tag_definition_ids_item)

        limit = d.pop("limit", UNSET)

        neighborhood_chars = d.pop("neighborhood_chars", UNSET)

        def _parse_requested_sensitivity(
            data: object,
        ) -> None | SensitivityTier | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, int):
                    raise TypeError()
                requested_sensitivity_type_0 = SensitivityTier(data)

                return requested_sensitivity_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | SensitivityTier | Unset, data)

        requested_sensitivity = _parse_requested_sensitivity(d.pop("requested_sensitivity", UNSET))

        def _parse_trace_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        trace_id = _parse_trace_id(d.pop("trace_id", UNSET))

        def _parse_span_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        span_id = _parse_span_id(d.pop("span_id", UNSET))

        context_answer_request = cls(
            tenant_id=tenant_id,
            question=question,
            tag_ids=tag_ids,
            node_ids=node_ids,
            tag_definition_ids=tag_definition_ids,
            limit=limit,
            neighborhood_chars=neighborhood_chars,
            requested_sensitivity=requested_sensitivity,
            trace_id=trace_id,
            span_id=span_id,
        )

        return context_answer_request
