from enum import Enum


class ContextShieldFailureReason(str, Enum):
    SHIELD_NO_ANSWER = "shield_no_answer"
    SHIELD_POLICY_BLOCKED = "shield_policy_blocked"
    SHIELD_UNSUPPORTED_RESULT = "shield_unsupported_result"

    def __str__(self) -> str:
        return str(self.value)
