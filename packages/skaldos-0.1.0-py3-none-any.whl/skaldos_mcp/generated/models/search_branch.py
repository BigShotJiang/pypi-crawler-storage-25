from enum import Enum


class SearchBranch(str, Enum):
    FTS = "fts"
    ILIKE = "ilike"
    TRIGRAM = "trigram"
    VECTOR = "vector"

    def __str__(self) -> str:
        return str(self.value)
