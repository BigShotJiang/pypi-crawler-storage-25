from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.event_subscription_filter_tag_filters_type_0 import (
        EventSubscriptionFilterTagFiltersType0,
    )


T = TypeVar("T", bound="EventSubscriptionFilter")


@_attrs_define
class EventSubscriptionFilter:
    """Normalized content-free external subscription filter.

    Attributes:
        event_types (list[str]):
        subject_types (list[str] | None | Unset):
        tag_filters (EventSubscriptionFilterTagFiltersType0 | None | Unset):
        lens_id (None | Unset | UUID):
    """

    event_types: list[str]
    subject_types: list[str] | None | Unset = UNSET
    tag_filters: EventSubscriptionFilterTagFiltersType0 | None | Unset = UNSET
    lens_id: None | Unset | UUID = UNSET

    def to_dict(self) -> dict[str, Any]:
        from ..models.event_subscription_filter_tag_filters_type_0 import (
            EventSubscriptionFilterTagFiltersType0,
        )

        event_types = self.event_types

        subject_types: list[str] | None | Unset
        if isinstance(self.subject_types, Unset):
            subject_types = UNSET
        elif isinstance(self.subject_types, list):
            subject_types = self.subject_types

        else:
            subject_types = self.subject_types

        tag_filters: dict[str, Any] | None | Unset
        if isinstance(self.tag_filters, Unset):
            tag_filters = UNSET
        elif isinstance(self.tag_filters, EventSubscriptionFilterTagFiltersType0):
            tag_filters = self.tag_filters.to_dict()
        else:
            tag_filters = self.tag_filters

        lens_id: None | str | Unset
        if isinstance(self.lens_id, Unset):
            lens_id = UNSET
        elif isinstance(self.lens_id, UUID):
            lens_id = str(self.lens_id)
        else:
            lens_id = self.lens_id

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "event_types": event_types,
            }
        )
        if subject_types is not UNSET:
            field_dict["subject_types"] = subject_types
        if tag_filters is not UNSET:
            field_dict["tag_filters"] = tag_filters
        if lens_id is not UNSET:
            field_dict["lens_id"] = lens_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.event_subscription_filter_tag_filters_type_0 import (
            EventSubscriptionFilterTagFiltersType0,
        )

        d = dict(src_dict)
        event_types = cast(list[str], d.pop("event_types"))

        def _parse_subject_types(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                subject_types_type_0 = cast(list[str], data)

                return subject_types_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        subject_types = _parse_subject_types(d.pop("subject_types", UNSET))

        def _parse_tag_filters(
            data: object,
        ) -> EventSubscriptionFilterTagFiltersType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                tag_filters_type_0 = EventSubscriptionFilterTagFiltersType0.from_dict(data)

                return tag_filters_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(EventSubscriptionFilterTagFiltersType0 | None | Unset, data)

        tag_filters = _parse_tag_filters(d.pop("tag_filters", UNSET))

        def _parse_lens_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                lens_id_type_0 = UUID(data)

                return lens_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        lens_id = _parse_lens_id(d.pop("lens_id", UNSET))

        event_subscription_filter = cls(
            event_types=event_types,
            subject_types=subject_types,
            tag_filters=tag_filters,
            lens_id=lens_id,
        )

        return event_subscription_filter
