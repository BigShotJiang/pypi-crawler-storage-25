from enum import Enum


class SearchSourceType(str, Enum):
    NODE = "node"
    NODE_CHUNK = "node_chunk"

    def __str__(self) -> str:
        return str(self.value)
