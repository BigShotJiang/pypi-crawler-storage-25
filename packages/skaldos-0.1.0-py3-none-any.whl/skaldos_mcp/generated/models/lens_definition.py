from __future__ import annotations

from collections.abc import Mapping
from typing import (
    TYPE_CHECKING,
    Any,
    Literal,
    TypeVar,
    cast,
)

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.lens_rule import LensRule
    from ..models.lens_sort import LensSort


T = TypeVar("T", bound="LensDefinition")


@_attrs_define
class LensDefinition:
    """Versioned Slice 6 lens definition shape.

    The model deliberately has no fields named ``filter``, ``where``, ``limit``,
    ``classification``, or ``customer_visible``. Unknown fields are rejected and
    raw-payload validation maps forbidden semantics to stable reason codes.

        Attributes:
            definition_version (Literal[1] | Unset):  Default: 1.
            rules (list[LensRule] | Unset):
            sort (list[LensSort] | Unset):
    """

    definition_version: Literal[1] | Unset = 1
    rules: list[LensRule] | Unset = UNSET
    sort: list[LensSort] | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        definition_version = self.definition_version

        rules: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.rules, Unset):
            rules = []
            for rules_item_data in self.rules:
                rules_item = rules_item_data.to_dict()
                rules.append(rules_item)

        sort: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.sort, Unset):
            sort = []
            for sort_item_data in self.sort:
                sort_item = sort_item_data.to_dict()
                sort.append(sort_item)

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if definition_version is not UNSET:
            field_dict["definition_version"] = definition_version
        if rules is not UNSET:
            field_dict["rules"] = rules
        if sort is not UNSET:
            field_dict["sort"] = sort

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.lens_rule import LensRule
        from ..models.lens_sort import LensSort

        d = dict(src_dict)
        definition_version = cast(Literal[1] | Unset, d.pop("definition_version", UNSET))
        if definition_version != 1 and not isinstance(definition_version, Unset):
            raise ValueError(f"definition_version must match const 1, got '{definition_version}'")

        _rules = d.pop("rules", UNSET)
        rules: list[LensRule] | Unset = UNSET
        if _rules is not UNSET:
            rules = []
            for rules_item_data in _rules:
                rules_item = LensRule.from_dict(rules_item_data)

                rules.append(rules_item)

        _sort = d.pop("sort", UNSET)
        sort: list[LensSort] | Unset = UNSET
        if _sort is not UNSET:
            sort = []
            for sort_item_data in _sort:
                sort_item = LensSort.from_dict(sort_item_data)

                sort.append(sort_item)

        lens_definition = cls(
            definition_version=definition_version,
            rules=rules,
            sort=sort,
        )

        return lens_definition
