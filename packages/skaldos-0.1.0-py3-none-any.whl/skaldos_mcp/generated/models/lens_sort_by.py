from enum import Enum


class LensSortBy(str, Enum):
    CANDIDATE_ID = "candidate_id"
    CREATED_AT = "created_at"
    LENS_SCORE = "lens_score"
    UPSTREAM_RANK = "upstream_rank"

    def __str__(self) -> str:
        return str(self.value)
