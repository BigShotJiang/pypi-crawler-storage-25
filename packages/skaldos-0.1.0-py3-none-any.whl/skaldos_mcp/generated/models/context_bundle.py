from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define

from ..models.classification_level import ClassificationLevel
from ..models.context_assembly_warning import ContextAssemblyWarning
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.context_item import ContextItem


T = TypeVar("T", bound="ContextBundle")


@_attrs_define
class ContextBundle:
    """Leakage-safe context assembly response shape.

    Attributes:
        query_id (UUID):
        tenant_id (UUID):
        context_items (list[ContextItem]):
        provenance (list[ContextItem]):
        max_visible_classification (ClassificationLevel | None):
        truncated (bool):
        warnings (list[ContextAssemblyWarning] | Unset):
    """

    query_id: UUID
    tenant_id: UUID
    context_items: list[ContextItem]
    provenance: list[ContextItem]
    max_visible_classification: ClassificationLevel | None
    truncated: bool
    warnings: list[ContextAssemblyWarning] | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        query_id = str(self.query_id)

        tenant_id = str(self.tenant_id)

        context_items = []
        for context_items_item_data in self.context_items:
            context_items_item = context_items_item_data.to_dict()
            context_items.append(context_items_item)

        provenance = []
        for provenance_item_data in self.provenance:
            provenance_item = provenance_item_data.to_dict()
            provenance.append(provenance_item)

        max_visible_classification: None | str
        if isinstance(self.max_visible_classification, ClassificationLevel):
            max_visible_classification = self.max_visible_classification.value
        else:
            max_visible_classification = self.max_visible_classification

        truncated = self.truncated

        warnings: list[str] | Unset = UNSET
        if not isinstance(self.warnings, Unset):
            warnings = []
            for warnings_item_data in self.warnings:
                warnings_item = warnings_item_data.value
                warnings.append(warnings_item)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "query_id": query_id,
                "tenant_id": tenant_id,
                "context_items": context_items,
                "provenance": provenance,
                "max_visible_classification": max_visible_classification,
                "truncated": truncated,
            }
        )
        if warnings is not UNSET:
            field_dict["warnings"] = warnings

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.context_item import ContextItem

        d = dict(src_dict)
        query_id = UUID(d.pop("query_id"))

        tenant_id = UUID(d.pop("tenant_id"))

        context_items = []
        _context_items = d.pop("context_items")
        for context_items_item_data in _context_items:
            context_items_item = ContextItem.from_dict(context_items_item_data)

            context_items.append(context_items_item)

        provenance = []
        _provenance = d.pop("provenance")
        for provenance_item_data in _provenance:
            provenance_item = ContextItem.from_dict(provenance_item_data)

            provenance.append(provenance_item)

        def _parse_max_visible_classification(
            data: object,
        ) -> ClassificationLevel | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                max_visible_classification_type_0 = ClassificationLevel(data)

                return max_visible_classification_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ClassificationLevel | None, data)

        max_visible_classification = _parse_max_visible_classification(
            d.pop("max_visible_classification")
        )

        truncated = d.pop("truncated")

        _warnings = d.pop("warnings", UNSET)
        warnings: list[ContextAssemblyWarning] | Unset = UNSET
        if _warnings is not UNSET:
            warnings = []
            for warnings_item_data in _warnings:
                warnings_item = ContextAssemblyWarning(warnings_item_data)

                warnings.append(warnings_item)

        context_bundle = cls(
            query_id=query_id,
            tenant_id=tenant_id,
            context_items=context_items,
            provenance=provenance,
            max_visible_classification=max_visible_classification,
            truncated=truncated,
            warnings=warnings,
        )

        return context_bundle
