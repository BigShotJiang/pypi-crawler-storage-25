from enum import Enum


class MetricFilterOperator(str, Enum):
    EQ = "eq"
    GTE = "gte"
    LTE = "lte"

    def __str__(self) -> str:
        return str(self.value)
