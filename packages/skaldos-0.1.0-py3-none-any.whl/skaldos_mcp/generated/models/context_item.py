from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define

from ..models.classification_level import ClassificationLevel
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.context_item_context_of_validity import ContextItemContextOfValidity
    from ..models.context_source import ContextSource


T = TypeVar("T", bound="ContextItem")


@_attrs_define
class ContextItem:
    """One visible tag span plus bounded source neighborhood.

    Attributes:
        node_id (UUID):
        tag_id (UUID):
        tag_definition_id (UUID):
        span_offset_start (int):
        span_offset_end (int):
        exact (str):
        prefix (str):
        suffix (str):
        neighborhood (str):
        classification (ClassificationLevel): Fixed substrate classification levels, ordered by sensitivity.
        context_of_validity (ContextItemContextOfValidity):
        source (ContextSource): Visible source handles for one context item.
        stale (bool | Unset):  Default: False.
    """

    node_id: UUID
    tag_id: UUID
    tag_definition_id: UUID
    span_offset_start: int
    span_offset_end: int
    exact: str
    prefix: str
    suffix: str
    neighborhood: str
    classification: ClassificationLevel
    context_of_validity: ContextItemContextOfValidity
    source: ContextSource
    stale: bool | Unset = False

    def to_dict(self) -> dict[str, Any]:
        node_id = str(self.node_id)

        tag_id = str(self.tag_id)

        tag_definition_id = str(self.tag_definition_id)

        span_offset_start = self.span_offset_start

        span_offset_end = self.span_offset_end

        exact = self.exact

        prefix = self.prefix

        suffix = self.suffix

        neighborhood = self.neighborhood

        classification = self.classification.value

        context_of_validity = self.context_of_validity.to_dict()

        source = self.source.to_dict()

        stale = self.stale

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "node_id": node_id,
                "tag_id": tag_id,
                "tag_definition_id": tag_definition_id,
                "span_offset_start": span_offset_start,
                "span_offset_end": span_offset_end,
                "exact": exact,
                "prefix": prefix,
                "suffix": suffix,
                "neighborhood": neighborhood,
                "classification": classification,
                "context_of_validity": context_of_validity,
                "source": source,
            }
        )
        if stale is not UNSET:
            field_dict["stale"] = stale

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.context_item_context_of_validity import (
            ContextItemContextOfValidity,
        )
        from ..models.context_source import ContextSource

        d = dict(src_dict)
        node_id = UUID(d.pop("node_id"))

        tag_id = UUID(d.pop("tag_id"))

        tag_definition_id = UUID(d.pop("tag_definition_id"))

        span_offset_start = d.pop("span_offset_start")

        span_offset_end = d.pop("span_offset_end")

        exact = d.pop("exact")

        prefix = d.pop("prefix")

        suffix = d.pop("suffix")

        neighborhood = d.pop("neighborhood")

        classification = ClassificationLevel(d.pop("classification"))

        context_of_validity = ContextItemContextOfValidity.from_dict(d.pop("context_of_validity"))

        source = ContextSource.from_dict(d.pop("source"))

        stale = d.pop("stale", UNSET)

        context_item = cls(
            node_id=node_id,
            tag_id=tag_id,
            tag_definition_id=tag_definition_id,
            span_offset_start=span_offset_start,
            span_offset_end=span_offset_end,
            exact=exact,
            prefix=prefix,
            suffix=suffix,
            neighborhood=neighborhood,
            classification=classification,
            context_of_validity=context_of_validity,
            source=source,
            stale=stale,
        )

        return context_item
