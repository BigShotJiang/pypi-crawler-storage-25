from enum import Enum


class LensSignalKind(str, Enum):
    DOMAIN = "domain"
    RECENCY = "recency"
    TAG = "tag"
    TOPIC = "topic"
    TYPE = "type"

    def __str__(self) -> str:
        return str(self.value)
