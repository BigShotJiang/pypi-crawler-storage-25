from enum import Enum


class AgentTriggerKind(str, Enum):
    EVENT = "event"
    SYNC = "sync"

    def __str__(self) -> str:
        return str(self.value)
