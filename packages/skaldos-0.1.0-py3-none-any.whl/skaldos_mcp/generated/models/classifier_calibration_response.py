from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.classifier_calibration_projection import (
        ClassifierCalibrationProjection,
    )


T = TypeVar("T", bound="ClassifierCalibrationResponse")


@_attrs_define
class ClassifierCalibrationResponse:
    """Read-only classifier-family calibration response.

    Attributes:
        projection (ClassifierCalibrationProjection | None):
    """

    projection: ClassifierCalibrationProjection | None

    def to_dict(self) -> dict[str, Any]:
        from ..models.classifier_calibration_projection import (
            ClassifierCalibrationProjection,
        )

        projection: dict[str, Any] | None
        if isinstance(self.projection, ClassifierCalibrationProjection):
            projection = self.projection.to_dict()
        else:
            projection = self.projection

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "projection": projection,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.classifier_calibration_projection import (
            ClassifierCalibrationProjection,
        )

        d = dict(src_dict)

        def _parse_projection(data: object) -> ClassifierCalibrationProjection | None:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                projection_type_0 = ClassifierCalibrationProjection.from_dict(data)

                return projection_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ClassifierCalibrationProjection | None, data)

        projection = _parse_projection(d.pop("projection"))

        classifier_calibration_response = cls(
            projection=projection,
        )

        return classifier_calibration_response
