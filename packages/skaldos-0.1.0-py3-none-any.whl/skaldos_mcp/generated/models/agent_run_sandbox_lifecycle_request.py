from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define

T = TypeVar("T", bound="AgentRunSandboxLifecycleRequest")


@_attrs_define
class AgentRunSandboxLifecycleRequest:
    """Tenant-scoped request for protected sandbox lifecycle operations.

    Attributes:
        tenant_id (UUID):
    """

    tenant_id: UUID

    def to_dict(self) -> dict[str, Any]:
        tenant_id = str(self.tenant_id)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "tenant_id": tenant_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        tenant_id = UUID(d.pop("tenant_id"))

        agent_run_sandbox_lifecycle_request = cls(
            tenant_id=tenant_id,
        )

        return agent_run_sandbox_lifecycle_request
