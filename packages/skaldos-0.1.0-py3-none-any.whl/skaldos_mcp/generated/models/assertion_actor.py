from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define

from ..models.assertion_actor_kind import AssertionActorKind

T = TypeVar("T", bound="AssertionActor")


@_attrs_define
class AssertionActor:
    """Body actor field that must match the hydrated Principal.

    Attributes:
        principal_id (UUID):
        kind (AssertionActorKind):
    """

    principal_id: UUID
    kind: AssertionActorKind

    def to_dict(self) -> dict[str, Any]:
        principal_id = str(self.principal_id)

        kind = self.kind.value

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "principal_id": principal_id,
                "kind": kind,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        principal_id = UUID(d.pop("principal_id"))

        kind = AssertionActorKind(d.pop("kind"))

        assertion_actor = cls(
            principal_id=principal_id,
            kind=kind,
        )

        return assertion_actor
