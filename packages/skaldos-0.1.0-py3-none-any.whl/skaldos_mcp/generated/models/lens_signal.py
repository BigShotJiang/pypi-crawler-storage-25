from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define

from ..models.lens_signal_kind import LensSignalKind

T = TypeVar("T", bound="LensSignal")


@_attrs_define
class LensSignal:
    """A positive or negative ranking feature, never a visibility predicate.

    Attributes:
        kind (LensSignalKind):
        value (str):
    """

    kind: LensSignalKind
    value: str

    def to_dict(self) -> dict[str, Any]:
        kind = self.kind.value

        value = self.value

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "kind": kind,
                "value": value,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        kind = LensSignalKind(d.pop("kind"))

        value = d.pop("value")

        lens_signal = cls(
            kind=kind,
            value=value,
        )

        return lens_signal
