from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.event_subscription_record import EventSubscriptionRecord


T = TypeVar("T", bound="EventSubscriptionListResponse")


@_attrs_define
class EventSubscriptionListResponse:
    """List response for tenant-scoped event subscriptions.

    Attributes:
        subscriptions (list[EventSubscriptionRecord]):
    """

    subscriptions: list[EventSubscriptionRecord]

    def to_dict(self) -> dict[str, Any]:
        subscriptions = []
        for subscriptions_item_data in self.subscriptions:
            subscriptions_item = subscriptions_item_data.to_dict()
            subscriptions.append(subscriptions_item)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "subscriptions": subscriptions,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.event_subscription_record import EventSubscriptionRecord

        d = dict(src_dict)
        subscriptions = []
        _subscriptions = d.pop("subscriptions")
        for subscriptions_item_data in _subscriptions:
            subscriptions_item = EventSubscriptionRecord.from_dict(subscriptions_item_data)

            subscriptions.append(subscriptions_item)

        event_subscription_list_response = cls(
            subscriptions=subscriptions,
        )

        return event_subscription_list_response
