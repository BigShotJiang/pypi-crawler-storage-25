from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="SearchPage")


@_attrs_define
class SearchPage:
    """Content-free search pagination metadata.

    Attributes:
        limit (int):
        has_more (bool):
        next_cursor (None | str | Unset):
    """

    limit: int
    has_more: bool
    next_cursor: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        limit = self.limit

        has_more = self.has_more

        next_cursor: None | str | Unset
        if isinstance(self.next_cursor, Unset):
            next_cursor = UNSET
        else:
            next_cursor = self.next_cursor

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "limit": limit,
                "has_more": has_more,
            }
        )
        if next_cursor is not UNSET:
            field_dict["next_cursor"] = next_cursor

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        limit = d.pop("limit")

        has_more = d.pop("has_more")

        def _parse_next_cursor(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        next_cursor = _parse_next_cursor(d.pop("next_cursor", UNSET))

        search_page = cls(
            limit=limit,
            has_more=has_more,
            next_cursor=next_cursor,
        )

        return search_page
