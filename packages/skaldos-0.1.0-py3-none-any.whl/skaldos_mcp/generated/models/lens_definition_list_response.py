from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.lens_definition_list_metadata import LensDefinitionListMetadata
    from ..models.lens_definition_record import LensDefinitionRecord
    from ..models.read_page import ReadPage


T = TypeVar("T", bound="LensDefinitionListResponse")


@_attrs_define
class LensDefinitionListResponse:
    """List response for tenant-scoped lens definitions.

    Attributes:
        lenses (list[LensDefinitionRecord]):
        metadata (LensDefinitionListMetadata): Content-free lens-list request metadata.
        page (ReadPage): Content-free pagination page metadata.
    """

    lenses: list[LensDefinitionRecord]
    metadata: LensDefinitionListMetadata
    page: ReadPage

    def to_dict(self) -> dict[str, Any]:
        lenses = []
        for lenses_item_data in self.lenses:
            lenses_item = lenses_item_data.to_dict()
            lenses.append(lenses_item)

        metadata = self.metadata.to_dict()

        page = self.page.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "lenses": lenses,
                "metadata": metadata,
                "page": page,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.lens_definition_list_metadata import LensDefinitionListMetadata
        from ..models.lens_definition_record import LensDefinitionRecord
        from ..models.read_page import ReadPage

        d = dict(src_dict)
        lenses = []
        _lenses = d.pop("lenses")
        for lenses_item_data in _lenses:
            lenses_item = LensDefinitionRecord.from_dict(lenses_item_data)

            lenses.append(lenses_item)

        metadata = LensDefinitionListMetadata.from_dict(d.pop("metadata"))

        page = ReadPage.from_dict(d.pop("page"))

        lens_definition_list_response = cls(
            lenses=lenses,
            metadata=metadata,
            page=page,
        )

        return lens_definition_list_response
