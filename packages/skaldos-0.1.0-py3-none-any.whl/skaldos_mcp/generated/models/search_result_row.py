from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define

from ..models.classification_level import ClassificationLevel
from ..models.search_branch import SearchBranch
from ..models.search_source_type import SearchSourceType
from ..types import UNSET, Unset

T = TypeVar("T", bound="SearchResultRow")


@_attrs_define
class SearchResultRow:
    """Visible search result row.

    Attributes:
        id (UUID):
        source_type (SearchSourceType): Searchable source projections owned by the Slice 6 read path.
        tenant_id (UUID):
        classification (ClassificationLevel): Fixed substrate classification levels, ordered by sensitivity.
        node_id (UUID):
        score (float):
        branches (list[SearchBranch]):
        chunk_id (None | Unset | UUID):
        chunk_index (int | None | Unset):
        summary (None | str | Unset):
    """

    id: UUID
    source_type: SearchSourceType
    tenant_id: UUID
    classification: ClassificationLevel
    node_id: UUID
    score: float
    branches: list[SearchBranch]
    chunk_id: None | Unset | UUID = UNSET
    chunk_index: int | None | Unset = UNSET
    summary: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        source_type = self.source_type.value

        tenant_id = str(self.tenant_id)

        classification = self.classification.value

        node_id = str(self.node_id)

        score = self.score

        branches = []
        for branches_item_data in self.branches:
            branches_item = branches_item_data.value
            branches.append(branches_item)

        chunk_id: None | str | Unset
        if isinstance(self.chunk_id, Unset):
            chunk_id = UNSET
        elif isinstance(self.chunk_id, UUID):
            chunk_id = str(self.chunk_id)
        else:
            chunk_id = self.chunk_id

        chunk_index: int | None | Unset
        if isinstance(self.chunk_index, Unset):
            chunk_index = UNSET
        else:
            chunk_index = self.chunk_index

        summary: None | str | Unset
        if isinstance(self.summary, Unset):
            summary = UNSET
        else:
            summary = self.summary

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "id": id,
                "source_type": source_type,
                "tenant_id": tenant_id,
                "classification": classification,
                "node_id": node_id,
                "score": score,
                "branches": branches,
            }
        )
        if chunk_id is not UNSET:
            field_dict["chunk_id"] = chunk_id
        if chunk_index is not UNSET:
            field_dict["chunk_index"] = chunk_index
        if summary is not UNSET:
            field_dict["summary"] = summary

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = UUID(d.pop("id"))

        source_type = SearchSourceType(d.pop("source_type"))

        tenant_id = UUID(d.pop("tenant_id"))

        classification = ClassificationLevel(d.pop("classification"))

        node_id = UUID(d.pop("node_id"))

        score = d.pop("score")

        branches = []
        _branches = d.pop("branches")
        for branches_item_data in _branches:
            branches_item = SearchBranch(branches_item_data)

            branches.append(branches_item)

        def _parse_chunk_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                chunk_id_type_0 = UUID(data)

                return chunk_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        chunk_id = _parse_chunk_id(d.pop("chunk_id", UNSET))

        def _parse_chunk_index(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        chunk_index = _parse_chunk_index(d.pop("chunk_index", UNSET))

        def _parse_summary(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        summary = _parse_summary(d.pop("summary", UNSET))

        search_result_row = cls(
            id=id,
            source_type=source_type,
            tenant_id=tenant_id,
            classification=classification,
            node_id=node_id,
            score=score,
            branches=branches,
            chunk_id=chunk_id,
            chunk_index=chunk_index,
            summary=summary,
        )

        return search_result_row
