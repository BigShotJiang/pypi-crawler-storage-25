from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define

from ..models.traversal_direction import TraversalDirection

if TYPE_CHECKING:
    from ..models.traversal_edge import TraversalEdge
    from ..models.traversal_node import TraversalNode


T = TypeVar("T", bound="TraversalResult")


@_attrs_define
class TraversalResult:
    """Leakage-safe traversal response shape.

    Attributes:
        seed_node_id (UUID):
        tenant_id (UUID):
        direction (TraversalDirection): Closed traversal direction vocabulary.
        max_depth (int):
        truncated (bool):
        nodes (list[TraversalNode]):
        edges (list[TraversalEdge]):
    """

    seed_node_id: UUID
    tenant_id: UUID
    direction: TraversalDirection
    max_depth: int
    truncated: bool
    nodes: list[TraversalNode]
    edges: list[TraversalEdge]

    def to_dict(self) -> dict[str, Any]:
        seed_node_id = str(self.seed_node_id)

        tenant_id = str(self.tenant_id)

        direction = self.direction.value

        max_depth = self.max_depth

        truncated = self.truncated

        nodes = []
        for nodes_item_data in self.nodes:
            nodes_item = nodes_item_data.to_dict()
            nodes.append(nodes_item)

        edges = []
        for edges_item_data in self.edges:
            edges_item = edges_item_data.to_dict()
            edges.append(edges_item)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "seed_node_id": seed_node_id,
                "tenant_id": tenant_id,
                "direction": direction,
                "max_depth": max_depth,
                "truncated": truncated,
                "nodes": nodes,
                "edges": edges,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.traversal_edge import TraversalEdge
        from ..models.traversal_node import TraversalNode

        d = dict(src_dict)
        seed_node_id = UUID(d.pop("seed_node_id"))

        tenant_id = UUID(d.pop("tenant_id"))

        direction = TraversalDirection(d.pop("direction"))

        max_depth = d.pop("max_depth")

        truncated = d.pop("truncated")

        nodes = []
        _nodes = d.pop("nodes")
        for nodes_item_data in _nodes:
            nodes_item = TraversalNode.from_dict(nodes_item_data)

            nodes.append(nodes_item)

        edges = []
        _edges = d.pop("edges")
        for edges_item_data in _edges:
            edges_item = TraversalEdge.from_dict(edges_item_data)

            edges.append(edges_item)

        traversal_result = cls(
            seed_node_id=seed_node_id,
            tenant_id=tenant_id,
            direction=direction,
            max_depth=max_depth,
            truncated=truncated,
            nodes=nodes,
            edges=edges,
        )

        return traversal_result
