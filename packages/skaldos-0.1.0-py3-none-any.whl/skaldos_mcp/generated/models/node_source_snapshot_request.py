from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="NodeSourceSnapshotRequest")


@_attrs_define
class NodeSourceSnapshotRequest:
    """Request for one visible source node snapshot.

    Attributes:
        tenant_id (UUID):
        node_id (UUID):
        trace_id (None | str | Unset):
    """

    tenant_id: UUID
    node_id: UUID
    trace_id: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        tenant_id = str(self.tenant_id)

        node_id = str(self.node_id)

        trace_id: None | str | Unset
        if isinstance(self.trace_id, Unset):
            trace_id = UNSET
        else:
            trace_id = self.trace_id

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "tenant_id": tenant_id,
                "node_id": node_id,
            }
        )
        if trace_id is not UNSET:
            field_dict["trace_id"] = trace_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        tenant_id = UUID(d.pop("tenant_id"))

        node_id = UUID(d.pop("node_id"))

        def _parse_trace_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        trace_id = _parse_trace_id(d.pop("trace_id", UNSET))

        node_source_snapshot_request = cls(
            tenant_id=tenant_id,
            node_id=node_id,
            trace_id=trace_id,
        )

        return node_source_snapshot_request
