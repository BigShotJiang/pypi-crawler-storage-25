from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define

from ..models.classification_level import ClassificationLevel
from ..models.edge_relationship_type import EdgeRelationshipType

T = TypeVar("T", bound="TraversalEdge")


@_attrs_define
class TraversalEdge:
    """Visible edge projection returned by traversal.

    Attributes:
        id (UUID):
        tenant_id (UUID):
        source_node_id (UUID):
        target_node_id (UUID):
        relationship_type (EdgeRelationshipType): Closed Slice 3 relationship vocabulary seeded by the edge schema.
        classification (ClassificationLevel): Fixed substrate classification levels, ordered by sensitivity.
    """

    id: UUID
    tenant_id: UUID
    source_node_id: UUID
    target_node_id: UUID
    relationship_type: EdgeRelationshipType
    classification: ClassificationLevel

    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        tenant_id = str(self.tenant_id)

        source_node_id = str(self.source_node_id)

        target_node_id = str(self.target_node_id)

        relationship_type = self.relationship_type.value

        classification = self.classification.value

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "id": id,
                "tenant_id": tenant_id,
                "source_node_id": source_node_id,
                "target_node_id": target_node_id,
                "relationship_type": relationship_type,
                "classification": classification,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = UUID(d.pop("id"))

        tenant_id = UUID(d.pop("tenant_id"))

        source_node_id = UUID(d.pop("source_node_id"))

        target_node_id = UUID(d.pop("target_node_id"))

        relationship_type = EdgeRelationshipType(d.pop("relationship_type"))

        classification = ClassificationLevel(d.pop("classification"))

        traversal_edge = cls(
            id=id,
            tenant_id=tenant_id,
            source_node_id=source_node_id,
            target_node_id=target_node_id,
            relationship_type=relationship_type,
            classification=classification,
        )

        return traversal_edge
