from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define

from ..models.metric_aggregate import MetricAggregate
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.metric_filter import MetricFilter


T = TypeVar("T", bound="MetricQueryRequest")


@_attrs_define
class MetricQueryRequest:
    """Constrained JSON AST for the first metric query.

    Attributes:
        tenant_id (UUID):
        aggregate (MetricAggregate): First Slice 6 metric aggregate vocabulary.
        tag_definition_id (None | Unset | UUID):
        tag_name (None | str | Unset):
        filters (list[MetricFilter] | Unset):
        provenance_limit (int | Unset):  Default: 100.
    """

    tenant_id: UUID
    aggregate: MetricAggregate
    tag_definition_id: None | Unset | UUID = UNSET
    tag_name: None | str | Unset = UNSET
    filters: list[MetricFilter] | Unset = UNSET
    provenance_limit: int | Unset = 100

    def to_dict(self) -> dict[str, Any]:
        tenant_id = str(self.tenant_id)

        aggregate = self.aggregate.value

        tag_definition_id: None | str | Unset
        if isinstance(self.tag_definition_id, Unset):
            tag_definition_id = UNSET
        elif isinstance(self.tag_definition_id, UUID):
            tag_definition_id = str(self.tag_definition_id)
        else:
            tag_definition_id = self.tag_definition_id

        tag_name: None | str | Unset
        if isinstance(self.tag_name, Unset):
            tag_name = UNSET
        else:
            tag_name = self.tag_name

        filters: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.filters, Unset):
            filters = []
            for filters_item_data in self.filters:
                filters_item = filters_item_data.to_dict()
                filters.append(filters_item)

        provenance_limit = self.provenance_limit

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "tenant_id": tenant_id,
                "aggregate": aggregate,
            }
        )
        if tag_definition_id is not UNSET:
            field_dict["tag_definition_id"] = tag_definition_id
        if tag_name is not UNSET:
            field_dict["tag_name"] = tag_name
        if filters is not UNSET:
            field_dict["filters"] = filters
        if provenance_limit is not UNSET:
            field_dict["provenance_limit"] = provenance_limit

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.metric_filter import MetricFilter

        d = dict(src_dict)
        tenant_id = UUID(d.pop("tenant_id"))

        aggregate = MetricAggregate(d.pop("aggregate"))

        def _parse_tag_definition_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                tag_definition_id_type_0 = UUID(data)

                return tag_definition_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        tag_definition_id = _parse_tag_definition_id(d.pop("tag_definition_id", UNSET))

        def _parse_tag_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        tag_name = _parse_tag_name(d.pop("tag_name", UNSET))

        _filters = d.pop("filters", UNSET)
        filters: list[MetricFilter] | Unset = UNSET
        if _filters is not UNSET:
            filters = []
            for filters_item_data in _filters:
                filters_item = MetricFilter.from_dict(filters_item_data)

                filters.append(filters_item)

        provenance_limit = d.pop("provenance_limit", UNSET)

        metric_query_request = cls(
            tenant_id=tenant_id,
            aggregate=aggregate,
            tag_definition_id=tag_definition_id,
            tag_name=tag_name,
            filters=filters,
            provenance_limit=provenance_limit,
        )

        return metric_query_request
