from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="ContextAssemblyRequest")


@_attrs_define
class ContextAssemblyRequest:
    """Request for assembling visible NodeTag spans into LLM-ready context.

    Attributes:
        tenant_id (UUID):
        tag_ids (list[UUID] | Unset):
        node_ids (list[UUID] | Unset):
        tag_definition_ids (list[UUID] | Unset):
        limit (int | Unset):  Default: 20.
        neighborhood_chars (int | Unset):  Default: 200.
    """

    tenant_id: UUID
    tag_ids: list[UUID] | Unset = UNSET
    node_ids: list[UUID] | Unset = UNSET
    tag_definition_ids: list[UUID] | Unset = UNSET
    limit: int | Unset = 20
    neighborhood_chars: int | Unset = 200

    def to_dict(self) -> dict[str, Any]:
        tenant_id = str(self.tenant_id)

        tag_ids: list[str] | Unset = UNSET
        if not isinstance(self.tag_ids, Unset):
            tag_ids = []
            for tag_ids_item_data in self.tag_ids:
                tag_ids_item = str(tag_ids_item_data)
                tag_ids.append(tag_ids_item)

        node_ids: list[str] | Unset = UNSET
        if not isinstance(self.node_ids, Unset):
            node_ids = []
            for node_ids_item_data in self.node_ids:
                node_ids_item = str(node_ids_item_data)
                node_ids.append(node_ids_item)

        tag_definition_ids: list[str] | Unset = UNSET
        if not isinstance(self.tag_definition_ids, Unset):
            tag_definition_ids = []
            for tag_definition_ids_item_data in self.tag_definition_ids:
                tag_definition_ids_item = str(tag_definition_ids_item_data)
                tag_definition_ids.append(tag_definition_ids_item)

        limit = self.limit

        neighborhood_chars = self.neighborhood_chars

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "tenant_id": tenant_id,
            }
        )
        if tag_ids is not UNSET:
            field_dict["tag_ids"] = tag_ids
        if node_ids is not UNSET:
            field_dict["node_ids"] = node_ids
        if tag_definition_ids is not UNSET:
            field_dict["tag_definition_ids"] = tag_definition_ids
        if limit is not UNSET:
            field_dict["limit"] = limit
        if neighborhood_chars is not UNSET:
            field_dict["neighborhood_chars"] = neighborhood_chars

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        tenant_id = UUID(d.pop("tenant_id"))

        _tag_ids = d.pop("tag_ids", UNSET)
        tag_ids: list[UUID] | Unset = UNSET
        if _tag_ids is not UNSET:
            tag_ids = []
            for tag_ids_item_data in _tag_ids:
                tag_ids_item = UUID(tag_ids_item_data)

                tag_ids.append(tag_ids_item)

        _node_ids = d.pop("node_ids", UNSET)
        node_ids: list[UUID] | Unset = UNSET
        if _node_ids is not UNSET:
            node_ids = []
            for node_ids_item_data in _node_ids:
                node_ids_item = UUID(node_ids_item_data)

                node_ids.append(node_ids_item)

        _tag_definition_ids = d.pop("tag_definition_ids", UNSET)
        tag_definition_ids: list[UUID] | Unset = UNSET
        if _tag_definition_ids is not UNSET:
            tag_definition_ids = []
            for tag_definition_ids_item_data in _tag_definition_ids:
                tag_definition_ids_item = UUID(tag_definition_ids_item_data)

                tag_definition_ids.append(tag_definition_ids_item)

        limit = d.pop("limit", UNSET)

        neighborhood_chars = d.pop("neighborhood_chars", UNSET)

        context_assembly_request = cls(
            tenant_id=tenant_id,
            tag_ids=tag_ids,
            node_ids=node_ids,
            tag_definition_ids=tag_definition_ids,
            limit=limit,
            neighborhood_chars=neighborhood_chars,
        )

        return context_assembly_request
