from enum import Enum


class EdgeRelationshipType(str, Enum):
    COMPLETED_BY = "completed-by"
    DERIVED_FROM = "derived-from"
    FALSIFIED_BY = "falsified-by"
    GROUNDED_BY = "grounded-by"
    INFORMED_BY = "informed-by"
    PROMISED_BY = "promised-by"
    QUALIFIED_BY = "qualified-by"
    REBUTTED_BY = "rebutted-by"
    REJECTED_BY = "rejected-by"
    RELATES_TO = "relates-to"
    REQUESTED_OF = "requested-of"
    REVIEW_REQUIRED_BY = "review-required-by"
    REVISES = "revises"
    SATISFIED_BY = "satisfied-by"
    SUBSCRIBES_TO = "subscribes-to"
    SUPERSEDED_BY = "superseded-by"
    WARRANTED_BY = "warranted-by"

    def __str__(self) -> str:
        return str(self.value)
