from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="PolicyEvaluationErrorResponse")


@_attrs_define
class PolicyEvaluationErrorResponse:
    """OpenAPI schema for fail-closed policy-engine evaluation failures.

    Attributes:
        error_code (str | Unset):  Default: 'policy_evaluation_error'.
        reason_code (str | Unset):  Default: 'policy_evaluation_error'.
    """

    error_code: str | Unset = "policy_evaluation_error"
    reason_code: str | Unset = "policy_evaluation_error"

    def to_dict(self) -> dict[str, Any]:
        error_code = self.error_code

        reason_code = self.reason_code

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if error_code is not UNSET:
            field_dict["error_code"] = error_code
        if reason_code is not UNSET:
            field_dict["reason_code"] = reason_code

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        error_code = d.pop("error_code", UNSET)

        reason_code = d.pop("reason_code", UNSET)

        policy_evaluation_error_response = cls(
            error_code=error_code,
            reason_code=reason_code,
        )

        return policy_evaluation_error_response
