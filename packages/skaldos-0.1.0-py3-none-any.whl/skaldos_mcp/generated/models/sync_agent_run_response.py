from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define

from ..models.agent_run_status import AgentRunStatus
from ..models.sync_agent_run_response_effective_clearance import (
    SyncAgentRunResponseEffectiveClearance,
)

T = TypeVar("T", bound="SyncAgentRunResponse")


@_attrs_define
class SyncAgentRunResponse:
    """Content-free response returned after the workflow shell starts.

    Attributes:
        agent_run_id (UUID):
        status (AgentRunStatus): Canonical row status vocabulary for Slice 7 AgentRun projections.
        dbos_workflow_id (str):
        effective_principal_id (UUID):
        effective_clearance (SyncAgentRunResponseEffectiveClearance):
        template_version_id (UUID):
    """

    agent_run_id: UUID
    status: AgentRunStatus
    dbos_workflow_id: str
    effective_principal_id: UUID
    effective_clearance: SyncAgentRunResponseEffectiveClearance
    template_version_id: UUID

    def to_dict(self) -> dict[str, Any]:
        agent_run_id = str(self.agent_run_id)

        status = self.status.value

        dbos_workflow_id = self.dbos_workflow_id

        effective_principal_id = str(self.effective_principal_id)

        effective_clearance = self.effective_clearance.value

        template_version_id = str(self.template_version_id)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "agent_run_id": agent_run_id,
                "status": status,
                "dbos_workflow_id": dbos_workflow_id,
                "effective_principal_id": effective_principal_id,
                "effective_clearance": effective_clearance,
                "template_version_id": template_version_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        agent_run_id = UUID(d.pop("agent_run_id"))

        status = AgentRunStatus(d.pop("status"))

        dbos_workflow_id = d.pop("dbos_workflow_id")

        effective_principal_id = UUID(d.pop("effective_principal_id"))

        effective_clearance = SyncAgentRunResponseEffectiveClearance(d.pop("effective_clearance"))

        template_version_id = UUID(d.pop("template_version_id"))

        sync_agent_run_response = cls(
            agent_run_id=agent_run_id,
            status=status,
            dbos_workflow_id=dbos_workflow_id,
            effective_principal_id=effective_principal_id,
            effective_clearance=effective_clearance,
            template_version_id=template_version_id,
        )

        return sync_agent_run_response
