from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define

from ..models.edge_relationship_type import EdgeRelationshipType
from ..models.traversal_direction import TraversalDirection
from ..types import UNSET, Unset

T = TypeVar("T", bound="TraversalRequest")


@_attrs_define
class TraversalRequest:
    """Service/public request model for graph traversal.

    Attributes:
        seed_node_id (UUID):
        tenant_id (UUID):
        direction (TraversalDirection | Unset): Closed traversal direction vocabulary.
        max_depth (int | Unset):  Default: 3.
        limit (int | Unset):  Default: 100.
        relationship_types (list[EdgeRelationshipType] | Unset):
    """

    seed_node_id: UUID
    tenant_id: UUID
    direction: TraversalDirection | Unset = UNSET
    max_depth: int | Unset = 3
    limit: int | Unset = 100
    relationship_types: list[EdgeRelationshipType] | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        seed_node_id = str(self.seed_node_id)

        tenant_id = str(self.tenant_id)

        direction: str | Unset = UNSET
        if not isinstance(self.direction, Unset):
            direction = self.direction.value

        max_depth = self.max_depth

        limit = self.limit

        relationship_types: list[str] | Unset = UNSET
        if not isinstance(self.relationship_types, Unset):
            relationship_types = []
            for relationship_types_item_data in self.relationship_types:
                relationship_types_item = relationship_types_item_data.value
                relationship_types.append(relationship_types_item)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "seed_node_id": seed_node_id,
                "tenant_id": tenant_id,
            }
        )
        if direction is not UNSET:
            field_dict["direction"] = direction
        if max_depth is not UNSET:
            field_dict["max_depth"] = max_depth
        if limit is not UNSET:
            field_dict["limit"] = limit
        if relationship_types is not UNSET:
            field_dict["relationship_types"] = relationship_types

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        seed_node_id = UUID(d.pop("seed_node_id"))

        tenant_id = UUID(d.pop("tenant_id"))

        _direction = d.pop("direction", UNSET)
        direction: TraversalDirection | Unset
        if isinstance(_direction, Unset):
            direction = UNSET
        else:
            direction = TraversalDirection(_direction)

        max_depth = d.pop("max_depth", UNSET)

        limit = d.pop("limit", UNSET)

        _relationship_types = d.pop("relationship_types", UNSET)
        relationship_types: list[EdgeRelationshipType] | Unset = UNSET
        if _relationship_types is not UNSET:
            relationship_types = []
            for relationship_types_item_data in _relationship_types:
                relationship_types_item = EdgeRelationshipType(relationship_types_item_data)

                relationship_types.append(relationship_types_item)

        traversal_request = cls(
            seed_node_id=seed_node_id,
            tenant_id=tenant_id,
            direction=direction,
            max_depth=max_depth,
            limit=limit,
            relationship_types=relationship_types,
        )

        return traversal_request
