from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.search_metadata import SearchMetadata
    from ..models.search_page import SearchPage
    from ..models.search_result_row import SearchResultRow


T = TypeVar("T", bound="SearchResult")


@_attrs_define
class SearchResult:
    """Leakage-safe graph search response.

    Attributes:
        tenant_id (UUID):
        results (list[SearchResultRow]):
        metadata (SearchMetadata): Value-free response metadata.
        page (SearchPage): Content-free search pagination metadata.
    """

    tenant_id: UUID
    results: list[SearchResultRow]
    metadata: SearchMetadata
    page: SearchPage

    def to_dict(self) -> dict[str, Any]:
        tenant_id = str(self.tenant_id)

        results = []
        for results_item_data in self.results:
            results_item = results_item_data.to_dict()
            results.append(results_item)

        metadata = self.metadata.to_dict()

        page = self.page.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "tenant_id": tenant_id,
                "results": results,
                "metadata": metadata,
                "page": page,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.search_metadata import SearchMetadata
        from ..models.search_page import SearchPage
        from ..models.search_result_row import SearchResultRow

        d = dict(src_dict)
        tenant_id = UUID(d.pop("tenant_id"))

        results = []
        _results = d.pop("results")
        for results_item_data in _results:
            results_item = SearchResultRow.from_dict(results_item_data)

            results.append(results_item)

        metadata = SearchMetadata.from_dict(d.pop("metadata"))

        page = SearchPage.from_dict(d.pop("page"))

        search_result = cls(
            tenant_id=tenant_id,
            results=results,
            metadata=metadata,
            page=page,
        )

        return search_result
