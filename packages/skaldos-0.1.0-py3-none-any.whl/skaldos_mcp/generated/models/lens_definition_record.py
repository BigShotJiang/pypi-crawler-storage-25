from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.lens_definition import LensDefinition


T = TypeVar("T", bound="LensDefinitionRecord")


@_attrs_define
class LensDefinitionRecord:
    """Persisted lens definition row exposed by the API.

    Attributes:
        id (UUID):
        tenant_id (UUID):
        name (str):
        definition (LensDefinition): Versioned Slice 6 lens definition shape.

            The model deliberately has no fields named ``filter``, ``where``, ``limit``,
            ``classification``, or ``customer_visible``. Unknown fields are rejected and
            raw-payload validation maps forbidden semantics to stable reason codes.
        created_by_principal_id (UUID):
        created_at (str):
        updated_at (str):
        archived_at (None | str | Unset):
    """

    id: UUID
    tenant_id: UUID
    name: str
    definition: LensDefinition
    created_by_principal_id: UUID
    created_at: str
    updated_at: str
    archived_at: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        tenant_id = str(self.tenant_id)

        name = self.name

        definition = self.definition.to_dict()

        created_by_principal_id = str(self.created_by_principal_id)

        created_at = self.created_at

        updated_at = self.updated_at

        archived_at: None | str | Unset
        if isinstance(self.archived_at, Unset):
            archived_at = UNSET
        else:
            archived_at = self.archived_at

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "id": id,
                "tenant_id": tenant_id,
                "name": name,
                "definition": definition,
                "created_by_principal_id": created_by_principal_id,
                "created_at": created_at,
                "updated_at": updated_at,
            }
        )
        if archived_at is not UNSET:
            field_dict["archived_at"] = archived_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.lens_definition import LensDefinition

        d = dict(src_dict)
        id = UUID(d.pop("id"))

        tenant_id = UUID(d.pop("tenant_id"))

        name = d.pop("name")

        definition = LensDefinition.from_dict(d.pop("definition"))

        created_by_principal_id = UUID(d.pop("created_by_principal_id"))

        created_at = d.pop("created_at")

        updated_at = d.pop("updated_at")

        def _parse_archived_at(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        archived_at = _parse_archived_at(d.pop("archived_at", UNSET))

        lens_definition_record = cls(
            id=id,
            tenant_id=tenant_id,
            name=name,
            definition=definition,
            created_by_principal_id=created_by_principal_id,
            created_at=created_at,
            updated_at=updated_at,
            archived_at=archived_at,
        )

        return lens_definition_record
