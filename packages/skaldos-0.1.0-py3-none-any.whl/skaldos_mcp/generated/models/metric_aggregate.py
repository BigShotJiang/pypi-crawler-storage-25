from enum import Enum


class MetricAggregate(str, Enum):
    COUNT = "count"
    SUM = "sum"

    def __str__(self) -> str:
        return str(self.value)
