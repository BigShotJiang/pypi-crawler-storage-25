from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define

T = TypeVar("T", bound="MembershipCreateRequest")


@_attrs_define
class MembershipCreateRequest:
    """Request body for the membership-create fixture handler.

    ``organization_id``: the tenant to create the membership in (the
    ``target_tenant_loader`` extracts this for the chokepoint).
    ``principal_id``: the principal to add.
    ``role``: the role to assign.

    ``frozen=True, extra="forbid"`` mirrors production discipline.

        Attributes:
            principal_id (UUID):
            organization_id (UUID):
            role (str):
    """

    principal_id: UUID
    organization_id: UUID
    role: str

    def to_dict(self) -> dict[str, Any]:
        principal_id = str(self.principal_id)

        organization_id = str(self.organization_id)

        role = self.role

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "principal_id": principal_id,
                "organization_id": organization_id,
                "role": role,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        principal_id = UUID(d.pop("principal_id"))

        organization_id = UUID(d.pop("organization_id"))

        role = d.pop("role")

        membership_create_request = cls(
            principal_id=principal_id,
            organization_id=organization_id,
            role=role,
        )

        return membership_create_request
