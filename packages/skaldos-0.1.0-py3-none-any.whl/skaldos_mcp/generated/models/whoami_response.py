from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define

from ..models.whoami_response_kind import WhoamiResponseKind

T = TypeVar("T", bound="WhoamiResponse")


@_attrs_define
class WhoamiResponse:
    """Response shape for ``GET /whoami``.

    Frozen + strict-extra so:

    - The model is immutable after construction (``frozen=True``); a
      handler that builds the response and then mutates a field fails
      at the mutation site, not later in serialization.
    - Construction with unknown kwargs fails at validation
      (``extra="forbid"``); a typo'd field name surfaces as a unit-test
      failure, not as a silent drop.

    Field set per master-plan "Shared artifacts & contracts" → ``/whoami``
    row. Slice 4+ may extend this shape with delegation / trust /
    clearance projections when those wires land; widening a response
    shape with additional fields is forward-compatible.

    The model deliberately does **not** expose
    :attr:`Principal.verified_claims` or :attr:`Principal.auth0_sub`
    --- the wire shape is a projection of identity, not a memory dump.
    See the module docstring § "Response shape" for the rationale.

        Attributes:
            principal_id (UUID):
            kind (WhoamiResponseKind):
            primary_tenant_id (None | UUID):
            visible_tenant_ids (list[UUID]):
    """

    principal_id: UUID
    kind: WhoamiResponseKind
    primary_tenant_id: None | UUID
    visible_tenant_ids: list[UUID]

    def to_dict(self) -> dict[str, Any]:
        principal_id = str(self.principal_id)

        kind = self.kind.value

        primary_tenant_id: None | str
        if isinstance(self.primary_tenant_id, UUID):
            primary_tenant_id = str(self.primary_tenant_id)
        else:
            primary_tenant_id = self.primary_tenant_id

        visible_tenant_ids = []
        for visible_tenant_ids_item_data in self.visible_tenant_ids:
            visible_tenant_ids_item = str(visible_tenant_ids_item_data)
            visible_tenant_ids.append(visible_tenant_ids_item)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "principal_id": principal_id,
                "kind": kind,
                "primary_tenant_id": primary_tenant_id,
                "visible_tenant_ids": visible_tenant_ids,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        principal_id = UUID(d.pop("principal_id"))

        kind = WhoamiResponseKind(d.pop("kind"))

        def _parse_primary_tenant_id(data: object) -> None | UUID:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                primary_tenant_id_type_0 = UUID(data)

                return primary_tenant_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | UUID, data)

        primary_tenant_id = _parse_primary_tenant_id(d.pop("primary_tenant_id"))

        visible_tenant_ids = []
        _visible_tenant_ids = d.pop("visible_tenant_ids")
        for visible_tenant_ids_item_data in _visible_tenant_ids:
            visible_tenant_ids_item = UUID(visible_tenant_ids_item_data)

            visible_tenant_ids.append(visible_tenant_ids_item)

        whoami_response = cls(
            principal_id=principal_id,
            kind=kind,
            primary_tenant_id=primary_tenant_id,
            visible_tenant_ids=visible_tenant_ids,
        )

        return whoami_response
