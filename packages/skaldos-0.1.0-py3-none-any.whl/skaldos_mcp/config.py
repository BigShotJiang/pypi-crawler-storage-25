"""Env-driven config for the Phase 1.5 MCP server.

Per ``docs/slices/phase-1-5-mcp-server/03-technical-implementation.md``
§ Auth flow and § Module layout: the MCP server reads its bootstrap
config from environment variables only (no file-based config at v1 —
the operator owns the env / secret store).

Missing required env vars fail fast at startup (E4): no lazy
initialization, no silent defaults. The error names the missing
variable so an operator can fix it in 5 seconds.
"""

from __future__ import annotations

import os
from collections.abc import Mapping
from dataclasses import dataclass


class McpServerConfigError(ValueError):
    """Raised when MCP server configuration is incomplete or invalid."""


@dataclass(frozen=True, slots=True)
class McpServerConfig:
    """Resolved MCP server configuration.

    All fields are required. Construction goes through
    :func:`config_from_env`; direct construction is fine in tests with
    explicit values.

    Attributes
    ----------
    auth0_domain
        Auth0 tenant domain (e.g. ``skaldos-staging.eu.auth0.com``).
        Used to build the token endpoint URL.
    auth0_client_id
        Auth0 M2M application client id for the MCP server's per-org
        agent identity (ADR 19).
    auth0_client_secret
        Auth0 M2M application client secret. Read from env (operator
        provides via secret store mount). Never logged.
    api_audience
        Auth0 API audience the minted token targets (the API server's
        Auth0 API identifier — e.g. ``https://api-staging.skaldos.io``).
    api_base_url
        Base URL of the SkaldOS API the MCP tools call (e.g.
        ``https://api.staging.skaldos.ai``). Trailing slashes are
        normalised away on construction.
    http_timeout_seconds
        Per-request HTTP timeout for both Auth0 token mint and SkaldOS
        API calls. Default 30s (Pi agent runs may take longer to
        enqueue under load; matched to API's own request budget).
    """

    auth0_domain: str
    auth0_client_id: str
    auth0_client_secret: str
    api_audience: str
    api_base_url: str
    http_timeout_seconds: float = 30.0

    @property
    def auth0_token_url(self) -> str:
        """Return the Auth0 ``/oauth/token`` URL for this tenant."""
        return f"https://{self.auth0_domain}/oauth/token"


def config_from_env(env: Mapping[str, str] | None = None) -> McpServerConfig:
    """Build :class:`McpServerConfig` from environment variables.

    Reads the five required env vars per
    ``03-technical-implementation.md`` § Auth flow:

    - ``SKALDOS_MCP_AUTH0_DOMAIN``
    - ``SKALDOS_MCP_AUTH0_CLIENT_ID``
    - ``SKALDOS_MCP_AUTH0_CLIENT_SECRET``
    - ``SKALDOS_MCP_API_AUDIENCE``
    - ``SKALDOS_MCP_API_BASE_URL``

    Optional:

    - ``SKALDOS_MCP_HTTP_TIMEOUT_SECONDS`` (float, > 0; defaults to
      30.0).

    Raises
    ------
    McpServerConfigError
        When any required env var is missing or empty, or when an
        optional var is malformed. The exception message names the
        offending variable in lowercase so logs / stderr surface the
        exact missing key.
    """
    source = env if env is not None else os.environ
    return McpServerConfig(
        auth0_domain=_required(source, "SKALDOS_MCP_AUTH0_DOMAIN"),
        auth0_client_id=_required(source, "SKALDOS_MCP_AUTH0_CLIENT_ID"),
        auth0_client_secret=_required(source, "SKALDOS_MCP_AUTH0_CLIENT_SECRET"),
        api_audience=_required(source, "SKALDOS_MCP_API_AUDIENCE"),
        api_base_url=_normalize_base_url(_required(source, "SKALDOS_MCP_API_BASE_URL")),
        http_timeout_seconds=_optional_positive_float(
            source, "SKALDOS_MCP_HTTP_TIMEOUT_SECONDS", default=30.0
        ),
    )


def _required(env: Mapping[str, str], name: str) -> str:
    value = env.get(name)
    if not value:
        raise McpServerConfigError(f"{name.lower()}_missing")
    return value


def _normalize_base_url(raw: str) -> str:
    stripped = raw.rstrip("/")
    if not stripped.startswith(("http://", "https://")):
        raise McpServerConfigError("skaldos_mcp_api_base_url_invalid_scheme")
    return stripped


def _optional_positive_float(env: Mapping[str, str], name: str, *, default: float) -> float:
    raw = env.get(name)
    if raw is None or raw == "":
        return default
    try:
        value = float(raw)
    except ValueError as exc:
        raise McpServerConfigError(f"{name.lower()}_invalid") from exc
    if value <= 0:
        raise McpServerConfigError(f"{name.lower()}_invalid")
    return value


__all__ = ["McpServerConfig", "McpServerConfigError", "config_from_env"]
