"""``skaldos_mcp`` — Phase 1.5 MCP server for the SkaldOS API.

The MCP server registers a small set of MCP tools that wrap
``services/api`` HTTP routes. Each tool calls the API through an
Auth0 M2M Client Credentials-minted bearer token (ADR 19, MP10) so the
API's chokepoint (``Depends(authorize)`` / RLS) sees a real agent
principal.

Run with::

    python -m skaldos_mcp

The server reads its configuration from environment variables via
``skaldos_mcp.config.config_from_env``. Missing required env vars fail
fast at startup (E4).

References
----------

- ``docs/canon/build-plan.md`` § Phase 1.5 (the MCP slice paragraph)
  and § ADR 26 (codegen tool).
- ``docs/slices/phase-1-5-mcp-server/`` (brainstorm files).
- ``docs/runbooks/phase-1-5-mcp-server-verification.md`` (three-flow
  staging verification).
- §10.2 (OpenAPI as the contract); MP5 (ADR for new tooling); MP6
  (agents are clients); MP10 (humans + agents same principal shape);
  ADR 19 (Auth0 M2M).
"""

from skaldos_mcp.auth import Auth0M2MAuthError, Auth0M2MTokenClient
from skaldos_mcp.config import McpServerConfig, McpServerConfigError, config_from_env

__all__ = [
    "Auth0M2MAuthError",
    "Auth0M2MTokenClient",
    "McpServerConfig",
    "McpServerConfigError",
    "config_from_env",
]
