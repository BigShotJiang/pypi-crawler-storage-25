"""Tests for Rich TUI output formatting — Midnight Gold design refresh."""

from __future__ import annotations

import re
from io import StringIO

from rich.console import Console

from godspeed.tui import output as _output
from godspeed.tui.output import (
    format_assistant_text,
    format_error,
    format_parallel_results,
    format_parallel_tool_calls,
    format_permission_denied,
    format_permission_prompt,
    format_session_summary,
    format_status_hud,
    format_tool_call,
    format_tool_result,
    format_welcome,
)

_ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")


def _capture(fn, *args, **kwargs) -> str:
    """Run a formatting function and capture its Rich console output (ANSI stripped)."""
    buf = StringIO()
    original = _output.console
    _output.console = Console(file=buf, force_terminal=True, width=120)
    try:
        fn(*args, **kwargs)
    finally:
        _output.console = original
    return _ANSI_RE.sub("", buf.getvalue())


class TestFormatPermissionPrompt:
    """Test enhanced permission prompts with contextual detail."""

    def test_file_edit_shows_diff(self) -> None:
        args = {
            "file_path": "src/main.py",
            "old_string": "print('hello')",
            "new_string": "print('goodbye')",
        }
        output = _capture(format_permission_prompt, "file_edit", "ASK", arguments=args)
        assert "file_edit" in output
        assert "src/main.py" in output
        assert "-print('hello')" in output
        assert "+print('goodbye')" in output

    def test_file_write_shows_preview(self) -> None:
        content = "\n".join(f"line {i}" for i in range(20))
        args = {"file_path": "output.py", "content": content}
        output = _capture(format_permission_prompt, "file_write", "ASK", arguments=args)
        assert "file_write" in output
        assert "output.py" in output
        assert "0" in output
        assert "9" in output
        assert "more lines" in output

    def test_shell_shows_command(self) -> None:
        args = {"command": "rm -rf /tmp/build"}
        output = _capture(format_permission_prompt, "shell", "ASK", arguments=args)
        assert "shell" in output
        assert "rm -rf /tmp/build" in output

    def test_file_read_shows_path(self) -> None:
        args = {"file_path": "/etc/passwd"}
        output = _capture(format_permission_prompt, "file_read", "ASK", arguments=args)
        assert "file_read" in output
        assert "/etc/passwd" in output

    def test_grep_shows_pattern(self) -> None:
        args = {"pattern": "TODO", "path": "src/"}
        output = _capture(format_permission_prompt, "grep_search", "ASK", arguments=args)
        assert "grep_search" in output
        assert "TODO" in output

    def test_no_args_still_renders(self) -> None:
        output = _capture(format_permission_prompt, "unknown_tool", "Need permission")
        assert "unknown_tool" in output
        assert "Need permission" in output

    def test_empty_args_still_renders(self) -> None:
        output = _capture(format_permission_prompt, "file_edit", "ASK", arguments={})
        assert "file_edit" in output
        assert "Allow?" in output

    def test_file_edit_long_diff_truncated(self) -> None:
        old = "\n".join(f"old line {i}" for i in range(30))
        new = "\n".join(f"new line {i}" for i in range(30))
        args = {"file_path": "big.py", "old_string": old, "new_string": new}
        output = _capture(format_permission_prompt, "file_edit", "ASK", arguments=args)
        assert "more lines" in output

    def test_permission_uses_dot_separator(self) -> None:
        output = _capture(format_permission_prompt, "shell", "ASK", arguments={"command": "ls"})
        # Ultra-clean: pipe or middle-dot
        assert "|" in output or "ok" in output


class TestFormatToolCall:
    """Test tool call display — compact and lightweight."""

    def test_shell_shows_dollar_prefix(self) -> None:
        output = _capture(format_tool_call, "shell", {"command": "ls -la"})
        assert "shell" in output
        assert "ls -la" in output

    def test_file_read_compact_inline(self) -> None:
        output = _capture(format_tool_call, "file_read", {"file_path": "src/main.py"})
        assert "file_read" in output
        assert "src/main.py" in output

    def test_grep_shows_pattern(self) -> None:
        output = _capture(format_tool_call, "grep_search", {"pattern": "TODO", "path": "src/"})
        assert "grep_search" in output
        assert "TODO" in output

    def test_file_edit_shows_path(self) -> None:
        output = _capture(
            format_tool_call,
            "file_edit",
            {"file_path": "main.py", "old_string": "a", "new_string": "b"},
        )
        assert "file_edit" in output
        assert "main.py" in output

    def test_file_write_shows_line_count(self) -> None:
        output = _capture(
            format_tool_call,
            "file_write",
            {"file_path": "out.py", "content": "line1\nline2\nline3"},
        )
        assert "file_write" in output
        assert "3 lines" in output

    def test_non_serializable_args(self) -> None:
        """Should not crash on non-JSON-serializable args."""
        output = _capture(format_tool_call, "test", {"key": object()})
        assert "test" in output

    def test_marker_present(self) -> None:
        output = _capture(format_tool_call, "file_read", {"file_path": "x.py"})
        assert ">" in output  # tool marker

    def test_git_tool_shows_action(self) -> None:
        output = _capture(format_tool_call, "git", {"action": "status"})
        assert "git" in output
        assert "status" in output


class TestFormatToolResult:
    """Test tool result display — success compact, errors expanded."""

    def test_success_result_short(self) -> None:
        output = _capture(format_tool_result, "shell", "file1.py\nfile2.py")
        assert "ok" in output  # ok marker
        assert "file1.py" in output

    def test_error_result(self) -> None:
        output = _capture(format_tool_result, "shell", "command not found", is_error=True)
        assert "x" in output  # x marker
        assert "command not found" in output

    def test_long_success_shows_line_count(self) -> None:
        long_text = "\n".join(f"line {i}" for i in range(50))
        output = _capture(format_tool_result, "shell", long_text)
        assert "50 lines" in output

    def test_empty_result(self) -> None:
        output = _capture(format_tool_result, "shell", "")
        assert "ok" in output

    def test_long_error_truncated(self) -> None:
        long_text = "\n".join(f"error line {i}" for i in range(30))
        output = _capture(format_tool_result, "shell", long_text, is_error=True)
        assert "more lines" in output


class TestFormatWelcome:
    """Test welcome banner — minimal two-line format."""

    def test_shows_model(self) -> None:
        output = _capture(format_welcome, "claude-sonnet", "/home/user/project")
        assert "Godspeed" in output
        assert "claude-sonnet" in output

    def test_shows_version(self) -> None:
        output = _capture(format_welcome, "model", "/home/user")
        assert "v" in output  # version string

    def test_no_tools_list_by_default(self) -> None:
        """Welcome should NOT dump the full tools list."""
        output = _capture(
            format_welcome,
            "model",
            "/home/user",
            tools=["file_read", "file_write", "shell"],
        )
        # Tools should not be listed in the welcome banner
        assert "file_read" not in output


class TestFormatSessionSummary:
    """Test session summary on quit."""

    def test_shows_duration(self) -> None:
        output = _capture(format_session_summary, 754.0, 38000, 7000)
        assert "12m" in output
        assert "34s" in output

    def test_shows_tokens(self) -> None:
        output = _capture(format_session_summary, 60.0, 1000, 500)
        assert "1,500" in output

    def test_shows_cost(self) -> None:
        output = _capture(format_session_summary, 60.0, 1000, 500, cost=0.1847)
        assert "$0.1847" in output

    def test_shows_free_for_zero_cost(self) -> None:
        output = _capture(format_session_summary, 60.0, 1000, 500, cost=0.0)
        # No cost line shown when cost is zero
        assert "$" not in output

    def test_shows_tool_summary(self) -> None:
        output = _capture(
            format_session_summary,
            60.0,
            1000,
            500,
            tool_calls=23,
            tool_errors=3,
            tool_denied=2,
        )
        assert "23 calls" in output

    def test_branded_signoff(self) -> None:
        output = _capture(format_session_summary, 60.0, 0, 0)
        assert "Godspeed" in output


class TestMiscFormatters:
    """Test other output formatters."""

    def test_format_error(self) -> None:
        output = _capture(format_error, "Something broke")
        assert "Something broke" in output
        assert "x" in output  # x marker

    def test_format_permission_denied(self) -> None:
        output = _capture(format_permission_denied, "shell", "blocked by policy")
        assert "shell" in output
        assert "Blocked" in output

    def test_format_assistant_text_empty(self) -> None:
        output = _capture(format_assistant_text, "   ")
        assert output.strip() == ""

    def test_format_assistant_text_markdown(self) -> None:
        output = _capture(format_assistant_text, "**bold text**")
        assert "bold" in output


class TestStatusFormatters:
    """Test status-typed message formatters (Crush-inspired)."""

    def test_format_info_shows_bullet(self) -> None:
        from godspeed.tui.output import format_info

        output = _capture(format_info, "Some info message")
        assert "i" in output  # info marker
        assert "Some info message" in output

    def test_format_success_shows_check(self) -> None:
        from godspeed.tui.output import format_success

        output = _capture(format_success, "Operation done")
        assert "ok" in output  # ok marker
        assert "Operation done" in output

    def test_format_warning_shows_triangle(self) -> None:
        from godspeed.tui.output import format_warning

        output = _capture(format_warning, "Be careful")
        assert "!" in output  # warning marker
        assert "Be careful" in output


class TestDecorativeElements:
    """Test minimal output has no decorative elements."""

    def test_welcome_is_minimal(self) -> None:
        output = _capture(format_welcome, "model", "/home/user")
        assert "Godspeed" in output
        # No tagline, no rule, no brand decorator
        assert "Build fast" not in output

    def test_welcome_no_rule(self) -> None:
        output = _capture(format_welcome, "model", "/home/user")
        # No horizontal rule in minimal design (multi-char rules only;
        # single hyphens inside words like "self-discipline" are fine)
        assert "---" not in output
        assert "───" not in output

    def test_session_summary_no_rule(self) -> None:
        output = _capture(format_session_summary, 60.0, 1000, 500)
        # No horizontal rule in minimal design
        assert "-" not in output

    def test_session_summary_signoff_minimal(self) -> None:
        output = _capture(format_session_summary, 60.0, 1000, 500)
        assert "Godspeed" in output
        # No decorated signoff

    def test_tool_call_shell_has_gutter(self) -> None:
        output = _capture(format_tool_call, "shell", {"command": "ls -la"})
        assert "ls -la" in output

    def test_tool_call_file_edit_has_gutter(self) -> None:
        args = {
            "file_path": "main.py",
            "old_string": "old code",
            "new_string": "new code",
        }
        output = _capture(format_tool_call, "file_edit", args)
        assert "main.py" in output


class TestFormatParallelToolCalls:
    """Test grouped header for parallel tool dispatch."""

    def test_shows_count(self) -> None:
        calls = [
            ("file_read", {"file_path": "a.py"}),
            ("grep_search", {"pattern": "TODO"}),
            ("shell", {"command": "ls"}),
        ]
        output = _capture(format_parallel_tool_calls, calls)
        assert "3 tools" in output
        assert "parallel" in output

    def test_shows_tool_names(self) -> None:
        calls = [
            ("file_read", {"file_path": "main.py"}),
            ("shell", {"command": "echo hi"}),
        ]
        output = _capture(format_parallel_tool_calls, calls)
        assert "file_read" in output
        assert "shell" in output

    def test_shows_primary_arg(self) -> None:
        calls = [("file_read", {"file_path": "src/app.py"})]
        output = _capture(format_parallel_tool_calls, calls)
        assert "src/app.py" in output

    def test_truncates_long_arg(self) -> None:
        long_path = "a/" * 30 + "file.py"
        calls = [("file_read", {"file_path": long_path})]
        output = _capture(format_parallel_tool_calls, calls)
        assert "..." in output

    def test_has_parallel_marker(self) -> None:
        calls = [("file_read", {"file_path": "x.py"}), ("shell", {"command": "ls"})]
        output = _capture(format_parallel_tool_calls, calls)
        assert "||" in output  # parallel marker

    def test_has_tool_markers(self) -> None:
        calls = [("file_read", {"file_path": "x.py"}), ("shell", {"command": "ls"})]
        output = _capture(format_parallel_tool_calls, calls)
        assert ">" in output  # tool marker

    def test_empty_args(self) -> None:
        calls = [("custom_tool", {})]
        output = _capture(format_parallel_tool_calls, calls)
        assert "1 tools" in output
        assert "custom_tool" in output


class TestFormatParallelResults:
    """Test batch summary of parallel tool results."""

    def test_all_success(self) -> None:
        results = [
            ("file_read", "contents of file", False),
            ("shell", "output", False),
        ]
        output = _capture(format_parallel_results, results)
        assert "ok" in output  # ✓ success marker
        assert "file_read" in output
        assert "shell" in output

    def test_all_errors(self) -> None:
        results = [
            ("shell", "command not found", True),
            ("file_read", "file not found", True),
        ]
        output = _capture(format_parallel_results, results)
        assert "x" in output  # x error
        assert "command not found" in output
        assert "file not found" in output

    def test_mixed_success_and_error(self) -> None:
        results = [
            ("file_read", "ok", False),
            ("shell", "Permission denied", True),
        ]
        output = _capture(format_parallel_results, results)
        assert "ok" in output  # ✓ for success
        assert "x" in output  # x for error
        assert "file_read" in output
        assert "Permission denied" in output

    def test_empty_error_output(self) -> None:
        results = [("shell", "", True)]
        output = _capture(format_parallel_results, results)
        assert "no output" in output

    def test_long_error_truncated(self) -> None:
        long_line = "x" * 200
        results = [("shell", long_line, True)]
        output = _capture(format_parallel_results, results)
        assert "..." in output

    def test_success_uses_dot_separator(self) -> None:
        results = [
            ("file_read", "ok", False),
            ("shell", "ok", False),
        ]
        output = _capture(format_parallel_results, results)
        assert "|" in output  # separator


class TestFormatStatusHud:
    """Compact per-turn HUD: tokens, cost, model, turn count."""

    def test_shows_tokens_and_cost(self) -> None:
        output = _capture(
            format_status_hud,
            input_tokens=1234,
            output_tokens=567,
            cost_usd=0.0024,
            model="nvidia_nim/moonshotai/kimi-k2.5",
            turns=3,
        )
        assert "1,801" in output  # total tokens
        assert "tokens" in output
        assert "$0.0024" in output
        assert "kimi-k2.5" in output  # short name
        assert "turn 3" in output

    def test_model_short_name(self) -> None:
        """Provider prefix is stripped for readability."""
        output = _capture(
            format_status_hud,
            input_tokens=10,
            output_tokens=20,
            cost_usd=0.0,
            model="anthropic/claude-opus-4-7",
            turns=1,
        )
        assert "claude-opus-4-7" in output
        assert "anthropic/" not in output

    def test_model_no_prefix_unchanged(self) -> None:
        output = _capture(
            format_status_hud,
            input_tokens=0,
            output_tokens=0,
            cost_usd=0.0,
            model="plain-model-name",
            turns=1,
        )
        assert "plain-model-name" in output

    def test_singular_turn(self) -> None:
        output = _capture(
            format_status_hud,
            input_tokens=1,
            output_tokens=1,
            cost_usd=0.0,
            model="m",
            turns=1,
        )
        assert "turn 1" in output

    def test_budget_shown_when_set(self) -> None:
        output = _capture(
            format_status_hud,
            input_tokens=100,
            output_tokens=100,
            cost_usd=0.05,
            model="m",
            turns=1,
            budget_usd=1.00,
        )
        assert "$0.0500 / $1.00" in output

    def test_budget_hidden_when_zero(self) -> None:
        output = _capture(
            format_status_hud,
            input_tokens=100,
            output_tokens=100,
            cost_usd=0.05,
            model="m",
            turns=1,
            budget_usd=0.0,
        )
        assert "/" not in output.split("$0.0500")[1].split("\n")[0]

    def test_uses_pipe_separator(self) -> None:
        output = _capture(
            format_status_hud,
            input_tokens=0,
            output_tokens=0,
            cost_usd=0.0,
            model="m",
            turns=0,
        )
        assert " | " in output  # pipe separator


class TestFormatTurnSeparator:
    """Test turn separator formatting."""

    def test_shows_turn_number(self) -> None:
        output = _capture(_output.format_turn_separator, turn=3)
        assert "turn 3" in output

    def test_normal_mode_long_rule(self) -> None:
        output = _capture(_output.format_turn_separator, turn=1)
        # Should be a long rule with turn number embedded
        assert len(output.strip()) > 20

    def test_compact_mode_short_rule(self) -> None:
        _output.set_compact_mode(True)
        try:
            output = _capture(_output.format_turn_separator, turn=5)
            assert "turn" not in output
            # Compact rule is short
            assert len(output.strip()) < 30
        finally:
            _output.set_compact_mode(False)


class TestFormatToolResultTiming:
    """Test tool result timing display."""

    def test_timing_milliseconds(self) -> None:
        output = _capture(format_tool_result, "shell", "ok", duration_ms=250.0)
        assert "250ms" in output

    def test_timing_seconds(self) -> None:
        output = _capture(format_tool_result, "shell", "ok", duration_ms=1500.0)
        assert "1.5s" in output

    def test_no_timing_when_zero(self) -> None:
        output = _capture(format_tool_result, "shell", "ok", duration_ms=0.0)
        assert "ms" not in output
        assert "s)" not in output


class TestCompactMode:
    """Test compact mode toggle."""

    def test_default_is_off(self) -> None:
        assert _output.is_compact_mode() is False

    def test_can_enable(self) -> None:
        _output.set_compact_mode(True)
        try:
            assert _output.is_compact_mode() is True
        finally:
            _output.set_compact_mode(False)

    def test_can_disable(self) -> None:
        _output.set_compact_mode(True)
        _output.set_compact_mode(False)
        assert _output.is_compact_mode() is False
