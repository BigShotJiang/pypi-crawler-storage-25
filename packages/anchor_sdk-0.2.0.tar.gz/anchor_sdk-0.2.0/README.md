# ANCHOR SDK

Monitor and self-correct your AI agents in 2 lines of code.

## Install

```bash
pip install anchor-sdk
```

## Quick start

```python
import anchor_sdk as anchor

anchor.init(
    url="https://api.anchormonitor.com",
    agent_id="my-agent",
    task="Describe what your agent does",
    sdk_key="sk-...",          # from your ANCHOR dashboard
)

# Your existing agent code — unchanged.
# ANCHOR auto-monitors every OpenAI / Anthropic / LangChain call.
```

Get your SDK key at [anchormonitor.com](https://anchormonitor.com).

## What it does

- **Detects drift** — vocabulary, semantic, latency, refusal, tool-call, and input distribution
- **Self-corrects** — injects a correction system message before the next LLM call
- **Escalates** — emails + Slack + PagerDuty when correction fails after 3 attempts
- **Zero code changes** — patches OpenAI, Anthropic, and LangChain automatically

## Manual usage

```python
# If you prefer explicit control:
result = anchor.watch("The agent's latest response text")
if result["correction_required"]:
    print(result["correction_prompt"])  # inject this as a system message
```
