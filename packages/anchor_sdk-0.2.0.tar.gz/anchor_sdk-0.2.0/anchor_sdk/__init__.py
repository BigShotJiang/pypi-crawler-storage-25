"""
ANCHOR SDK — two-way guardrail for AI agents.

Usage:
    import anchor_sdk as anchor

    anchor.init(
        url="https://api.anchormonitor.com",
        agent_id="my-agent",
        task="Describe what your agent does",
        sdk_key="sk-...",
    )

    # Customer-facing agents — gate every message in and out
    result = anchor.check_input(user_message)
    if not result["allowed"]:
        return result["blocked_message"]

    result = anchor.check_output(agent_response)
    if not result["allowed"]:
        return "I can't help with that."

    # Internal/workflow agents — gate every action before it executes
    result = anchor.check_action("send_payment", {"amount": 5000, "vendor": "Acme"})
    if not result["allowed"]:
        raise PermissionError("Action blocked")
    if result["escalate"]:
        notify_operator(...)  # human approval required
"""

from .client import AnchorClient, init, connect, watch, set_baseline, check_input, check_output, check_action

__version__ = "0.2.0"
__all__ = [
    "AnchorClient", "init", "connect", "watch", "set_baseline",
    "check_input", "check_output", "check_action",
]
