from typing import Union

import subprocess
import psutil


# def get_pid_by_port(
#     port: int
# ) -> Union[int, None]:
#     """
#     Get the PID of the process that is running on
#     the `port` provided.
#     """
#     result = subprocess.run(
#         f'netstat -ano | findstr :{port}',
#         capture_output = True,
#         text = True,
#         shell = True
#     )

#     for line in result.stdout.splitlines():
#         if 'LISTENING' in line:
#             parts = line.split()
#             return int(parts[-1])

#     return None

def get_process_by_port(
    port: int
) -> Union[psutil.Process, None]:
    """
    Get the process that is running on the `port`
    provided, or `None`.
    """
    for connection in psutil.net_connections(kind = 'inet'):
        if (
            connection.laddr.port == port and
            connection.status == 'LISTEN'
        ):
            return psutil.Process(connection.pid)
        
    return None

def kill_process_by_pid(
    pid: int
):
    """
    Kill the process with the given `pid`, if existing.
    """
    # TODO: Maybe check if killed and return something (?)
    subprocess.run(f'taskkill /PID {pid} /F', shell = True)

def is_process_alive(
    process: Union[subprocess.Popen, psutil.Process]
) -> bool:
    """
    Check if the `process` provided is alive or not.
    """
    if process is None:
        return False

    # subprocess.Popen
    if hasattr(process, 'poll'):
        return process.poll() is None

    # psutil.Process
    if hasattr(process, 'is_running'):
        return process.is_running()

    return False