"""
A library to have access to the ComfyUI models through
its API using the workflows by code directly.

This needs ComfyUI running.

You'll need to check where your ComfyUI app is installed
and configured, because you have files in different
paths of your system. Check the `api.py` file to see
the constants and replace them with your own values if
needed.

This project is executing a specific version of python
that is installed with the ComfyUI app, that creates its
own python environment that isolated and working. But
also this project is using its own environment to include
the classes we've made to interact with the ComfyUI
backend server.
"""