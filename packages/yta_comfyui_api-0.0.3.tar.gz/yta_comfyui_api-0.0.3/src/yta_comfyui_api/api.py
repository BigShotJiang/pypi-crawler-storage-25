from yta_comfyui_api.utils import get_process_by_port, is_process_alive
from urllib import request

import json
import time
import shutil
import subprocess
import psutil


PORT = '8000'
IP = '127.0.0.1'
COMFYUI_PATH = 'C:/ComfyUI'
BASE_URL = f'http://{IP}:{PORT}'
PROMPT_ENDPOINT_URL = f'{BASE_URL}/prompt'
HISTORY_ENDPOINT_URL = f'{BASE_URL}/history'
COMFYUI_OUTPUT_PATH = f'{COMFYUI_PATH}/output/'
PYTHON_EXE_PATH = f'{COMFYUI_PATH}/.venv/Scripts/python.exe'
USER_DIRECTORY_PATH = f'{COMFYUI_PATH}/user'
INPUT_DIRECTORY_PATH = f'{COMFYUI_PATH}/input'
COMFYUI_MAIN_PYTHON_FILENAME = 'C:/Users/dania/AppData/Local/Programs/ComfyUI/resources/ComfyUI/main.py'
FRONTEND_ROOT_PATH = 'C:/Users/dania/AppData/Local/Programs/ComfyUI/resources/ComfyUI/web_custom_versions/desktop_app'
DATABASE_URL = f'sqlite:///{COMFYUI_PATH}/user/comfyui.db'
EXTRA_MODELS_PATHS_CONFIG_FILENAME = 'C:/Users/dania/AppData/Roaming/ComfyUI/extra_models_config.yaml'

# TODO: Maybe use a context manager (?)
class ComfyUIAPI:
    """
    Class to represent the connection with the ComfyUI API.
    """

    def __init__(
        self,
        comfyui_base_url: str = BASE_URL,
        comfyui_output_path: str = COMFYUI_OUTPUT_PATH
    ):
        self.base_url: str = comfyui_base_url
        """
        The base url of the ComfyUI server.
        """
        self._output_path: str = comfyui_output_path
        """
        *For internal use only*

        The output path of the ComfyUI server, which is set
        when the app is installed.
        """
        self._process: any = None
        """
        *For internal use only*

        The process that runs the ComfyUI app in the backgound
        to allow the requests.
        """

        self._start_comfyui()

    # TODO: We should try to launch the ComfyUI if not
    # available and to check it constantly
    def _start_comfyui(
        self
    ):
        """
        *For internal use only*

        Start the ComfyUI app as a process.
        """
        # Check if there is a previous process running
        if self._process is not None:
            print(f'self._process detected as not None from the instance (pid: {str(int(self._process.pid))})')
            return

        # I assume that this is the ComfyUI process
        self._process = get_process_by_port(PORT)

        if self._process is not None:
            print(f'self._process detected as not None from the processes list (pid: {str(int(self._process.pid))})')
            return

        print('Starting ComfyUI...')

        cmd = [
            # The python version that is ready o execute the app
            # TODO: Make all these below constants
            PYTHON_EXE_PATH,
            rf'{COMFYUI_MAIN_PYTHON_FILENAME}',
            '--user-directory', rf'{USER_DIRECTORY_PATH}',
            '--input-directory', rf'{INPUT_DIRECTORY_PATH}',
            '--output-directory', rf'{COMFYUI_OUTPUT_PATH}',
            '--front-end-root', rf'{FRONTEND_ROOT_PATH}',
            '--base-directory', rf'{COMFYUI_PATH}',
            '--database-url', f'{DATABASE_URL}',
            '--extra-model-paths-config', rf'{EXTRA_MODELS_PATHS_CONFIG_FILENAME}',
            '--log-stdout',
            '--listen', f'{IP}',
            '--port', f'{PORT}',
            '--enable-manager'
        ]

        process = subprocess.Popen(cmd)
        self._process = psutil.Process(process.pid)
        print(f'Created a new process self._process (pid: {str(int(self._process.pid))})')

        # Wait until ready
        start = time.time()

        TIMEOUT = 45.0

        print('Waiting until ComfyUI is totally loaded')
        while time.time() - start < TIMEOUT:
            if self._is_comfyui_alive():
                print('ComfyUI ready')
                return
            time.sleep(1)

        raise RuntimeError(f'ComfyUI failed to start (in {str(TIMEOUT)} seconds)')

    def _is_comfyui_alive(
        self
    ) -> bool:
        """
        *For internal use only*

        Method to check if the ComfyUI app is working by
        sending an `open-url` request to the url.
        """
        try:
            request.urlopen(f'{BASE_URL}/history', timeout = 1)
            return True
        except:
            return False
        
    def _ensure_comfy(
        self
    ):
        """
        *For internal use only*

        Make sure that the ComfyUI app is running to be
        able to contact with the server.
        """
        if (
            self._process is None or
            not is_process_alive(self._process)
        ):
            self._start_comfyui()
        elif not self._is_comfyui_alive():
            print('Comfy not responding, restarting...')
            self.stop()
            self._start_comfyui()

    def _queue_workflow(
        self,
        workflow: 'Workflow'
    ) -> str:
        """
        *For internal use only*

        Send the `workflow` provided to the queue to be processed
        and get the `prompt_id` that can be used to receive the
        result when finished.
        """
        p = {'prompt': workflow.prompt}
        data = json.dumps(p).encode('utf-8')
        req = request.Request(PROMPT_ENDPOINT_URL, data = data)
        res = json.loads(request.urlopen(req).read())

        return res['prompt_id']
    
    def _wait_for_completion(
        self,
        prompt_id: str,
        timeout: float = 180.0
    ) -> dict:
        """
        *For internal use only*

        Wait for the completion of the `prompt_id` provided,
        waiting a maximum time of `timeout` seconds.
        """
        TIME_IN_BETWEEN_CHECKS: float = 1.0
        start_time = time.monotonic()

        while True:
            if time.monotonic() - start_time >= timeout:
                # TODO: Maybe return None instead (?)
                raise TimeoutError(f'Timeout waiting for prompt_id={prompt_id}')

            try:
                with request.urlopen(f'{HISTORY_ENDPOINT_URL}/{prompt_id}') as res:
                    history = json.loads(res.read())

                if prompt_id in history:
                    return history[prompt_id]

            except Exception:
                pass

            time.sleep(TIME_IN_BETWEEN_CHECKS)

    def _get_images(
        self,
        result_json: dict
    ) -> list[dict]:
        """
        *For internal use only*

        Get the images from the `result_json` provided, that
        must be the result of a task queued that has been
        completed.
        """
        outputs = result_json['outputs']
        images = []

        for node_id in outputs:
            node_output = outputs[node_id]

            if 'images' in node_output:
                for img in node_output['images']:
                    images.append(img)

        return images
    
    def stop(
        self
    ):
        """
        Stop the API, destroying the process and making this
        instance useless. After calling this method you will
        have to instantiate it again.
        """
        if (
            self._process and
            is_process_alive(self._process)
        ):
            self._process.terminate()

            try:
                self._process.wait(timeout = 10)
            except subprocess.TimeoutExpired:
                self._process.kill()
                self._process.wait()

        self._process = None
    
    """
    TODO: We should have different process for the different
    results we can have. This one below is currently a single
    image but we can obtain a video, a prompt, etc.
    """
    def process_workflow(
        self,
        workflow: 'Workflow'
    ) -> str:
        """
        Process the `workflow` provided and store the image
        result locally.
        """
        self._ensure_comfy()

        prompt_id = self._queue_workflow(
            workflow = workflow
        )
        print(f'Queued prompt_id: {prompt_id}')

        result = self._wait_for_completion(
            prompt_id = prompt_id,
            timeout = workflow.timeout
        )
        print(f'The prompt_id: {prompt_id} has been completed!')

        images = self._get_images(result)

        for index, image in enumerate(images):
            extension = image['filename'].split('.')[-1]
            # TODO: How do we do if more than one image (?)
            output_filename = f'./test_files/{prompt_id}_{str(index)}.{extension}'
            shutil.copy(f'{COMFYUI_OUTPUT_PATH}/{image["filename"]}', output_filename)
            return output_filename