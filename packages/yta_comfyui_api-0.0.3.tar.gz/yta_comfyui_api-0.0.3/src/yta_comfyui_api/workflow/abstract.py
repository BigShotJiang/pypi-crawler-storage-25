from abc import ABC, abstractmethod

import json


class Workflow(ABC):
    """
    *Abstract class*

    The abstract class of a workflow.
    """

    def __init__(
        self,
        filename: str,
        timeout: float = 180.0
    ):
        self.prompt: dict = None
        """
        The raw workflow, read from the json file, as a dict
        ready to be edited.
        """
        self.timeout: float = timeout
        """
        The time that has to pass to consider the generation
        as failed.
        """

        with open(filename, 'r', encoding = 'utf-8') as file:
            self.prompt = json.load(file)

    @abstractmethod
    def prepare(
        self,
        prompt: str
    ) -> dict:
        """
        Prepare the workflow dict to be able to send it to
        the queue to be processed.

        This method will return the workflow that can be
        send to the `queue` method of the API instance.
        """
        pass