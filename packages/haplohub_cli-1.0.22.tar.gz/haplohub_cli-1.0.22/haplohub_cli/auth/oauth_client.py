import base64
import hashlib
import os

from requests import Session

from haplohub_cli.auth.token_storage import TokenStorage, token_storage
from haplohub_cli.config.config_manager import config_manager


class AuthRequest:
    def __init__(
        self,
        client: "OAuthClient",
        scopes: list[str],
    ):
        self.client = client
        self.scopes = scopes
        self.code_verifier, self.code_challenge = self.generate_code_verifier()

    @property
    def auth_url(self):
        return (
            f"{self.client.oauth_authorize_url}"
            f"?client_id={self.client.oauth_client_id}"
            f"&response_type=code"
            f"&redirect_uri={self.client.redirect_uri}"
            f"&scope={' '.join(self.scopes)}"
            f"&code_challenge={self.code_challenge}"
            f"&code_challenge_method=S256"
        )

    def generate_code_verifier(self):
        verifier = base64.urlsafe_b64encode(os.urandom(32)).decode("utf-8").rstrip("=")
        challenge = hashlib.sha256(verifier.encode("utf-8")).digest()
        challenge = base64.urlsafe_b64encode(challenge).decode("utf-8").rstrip("=")
        return verifier, challenge

    def exchange_code(self, code: str):
        return self.client.exchange_code(code, self.code_verifier)


class OAuthClient:
    http = Session()

    def __init__(
        self,
        token_storage: TokenStorage,
        oauth_client_id: str,
        oauth_authorize_url: str,
        oauth_token_url: str,
        redirect_uri: str,
    ):
        self.token_storage = token_storage
        self.oauth_client_id = oauth_client_id
        self.oauth_authorize_url = oauth_authorize_url
        self.oauth_token_url = oauth_token_url
        self.redirect_uri = redirect_uri

    def init_auth_request(self, scopes: list[str] = ("openid", "profile", "email")):
        return AuthRequest(client=self, scopes=scopes)

    def exchange_code(self, code: str, code_verifier: str):
        response = self.http.post(
            self.oauth_token_url,
            json={
                "grant_type": "authorization_code",
                "client_id": self.oauth_client_id,
                "code": code,
                "redirect_uri": self.redirect_uri,
                "code_verifier": code_verifier,
            },
        )
        response.raise_for_status()
        return response.json()


oauth_client = OAuthClient(
    token_storage=token_storage,
    oauth_client_id=config_manager.config.oauth_client_id,
    oauth_authorize_url=config_manager.config.oauth_authorize_url,
    oauth_token_url=config_manager.config.oauth_token_url,
    redirect_uri=config_manager.config.redirect_uri,
)
