import webbrowser

import click
import requests

from haplohub_cli.auth.auth_web_server import AuthWebServer
from haplohub_cli.auth.oauth_client import oauth_client
from haplohub_cli.config.config_manager import config_manager
from haplohub_cli.core import ensure_config_dir
from haplohub_cli.core.network import check_port_available


def token_login(api_key: str):
    api_url = config_manager.config.api_url
    response = requests.get(f"{api_url}/api/v1/status/", headers={"X-API-Key": api_key})

    if response.status_code == 401:
        click.echo("Invalid API key.")
        exit(1)

    response.raise_for_status()

    oauth_client.token_storage.store_credentials({"api_key": api_key})
    click.echo("Successfully authenticated with HaploHub.")


def interactive_login():
    ensure_config_dir()

    if not check_port_available(config_manager.config.redirect_port):
        click.echo(
            f"Port {config_manager.config.redirect_port} is already in use. Please ensure it is free and try again.\n"
            f"Use `lsof -i4TCP:{config_manager.config.redirect_port} -sTCP:LISTEN -P -n` to find the process using the port."
        )
        exit(1)

    auth_request = oauth_client.init_auth_request()
    auth_url = auth_request.auth_url

    click.echo(
        f"Your browser has been opened to authenticate with HaploHub.\n\n    {auth_url[0 : auth_url.find('?')] + '...'}\n"
    )
    webbrowser.open(auth_url)

    auth_web_server = AuthWebServer(config_manager.config.redirect_port)
    auth_code = auth_web_server.handle_request()
    credentials = auth_request.exchange_code(auth_code)

    click.echo("Successfully authenticated with HaploHub.")
    oauth_client.token_storage.store_credentials(credentials)
