import click

from haplohub_cli.core import types
from haplohub_cli.core.api.client import client


@click.group()
def biomarker():
    """
    Manage biomarkers
    """
    pass


@biomarker.command()
@click.option("--cohort", "-c", type=types.HAPLOHUB_ID, required=True)
@click.option("--order", "-o", type=click.STRING, required=False)
def result(cohort: str, order: str = None):
    return client.biomarker.list_biomarker_results(cohort, order)
