import click
from haplohub import GetVariantRequest, HgvsTargetSchema, RegionTargetSchema, VariantFilterSchema

from haplohub_cli.core.api.client import client


@click.group()
def variant():
    """
    Work with variants
    """
    pass


@variant.command()
@click.argument("cohort_id", type=str)
@click.option("--sample", "-s", "sample_ids", type=str, multiple=True, required=True, help="Sample ID (repeatable)")
@click.option("--accession", "-a", type=str, required=True, help="Chromosome accession (e.g. NC_000001.11)")
@click.option("--start", type=int, required=True, help="Genomic start position")
@click.option("--end", type=int, required=True, help="Genomic end position")
@click.option("--reference", type=str, default=None, help="Reference allele")
@click.option("--alternate", type=str, default=None, help="Alternate allele")
@click.option("--call-state", type=click.Choice(["called", "all"]), default="called", help="Filter by call state")
@click.option("--clinvar", is_flag=True, default=False, help="Include ClinVar annotations")
def region(sample_ids, cohort_id, accession, start, end, reference, alternate, call_state, clinvar):
    """
    Query variants by genomic region
    """
    target = RegionTargetSchema(
        accession=accession,
        start=start,
        end=end,
        reference=reference,
        alternate=alternate,
    )

    request = GetVariantRequest(
        sample_ids=list(sample_ids),
        targets=[target],
        filters=VariantFilterSchema(call_state=call_state),
        selectors=["clinvar"] if clinvar else None,
    )

    return client.variant.get_variant(cohort_id, request)


@variant.command()
@click.argument("cohort_id", type=str)
@click.option("--sample", "-s", "sample_ids", type=str, multiple=True, required=True, help="Sample ID (repeatable)")
@click.option("--hgvs", "-h", type=str, multiple=True, required=True, help="HGVS notation (repeatable)")
@click.option("--call-state", type=click.Choice(["called", "all"]), default="called", help="Filter by call state")
@click.option("--clinvar", is_flag=True, default=False, help="Include ClinVar annotations")
def hgvs(sample_ids, cohort_id, hgvs, call_state, clinvar):
    """
    Query variants by HGVS notation
    """
    targets = [HgvsTargetSchema(value=v) for v in hgvs]

    request = GetVariantRequest(
        sample_ids=list(sample_ids),
        targets=targets,
        filters=VariantFilterSchema(call_state=call_state),
        selectors=["clinvar"] if clinvar else None,
    )

    return client.variant.get_variant(cohort_id, request)
