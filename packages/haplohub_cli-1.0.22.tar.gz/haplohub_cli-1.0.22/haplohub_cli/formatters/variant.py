from haplohub import ResultListResponseVariantResultSchema
from rich.table import Table

from haplohub_cli.formatters.decorators import register


@register(ResultListResponseVariantResultSchema)
def format_variant_results(data: ResultListResponseVariantResultSchema):
    table = Table(title="Variants", caption=f"Total: {len(data.items)}")
    table.add_column("Target")
    table.add_column("Accession")
    table.add_column("Position")
    table.add_column("Ref")
    table.add_column("Alt")
    table.add_column("Quality")
    table.add_column("Sample")
    table.add_column("Called")
    table.add_column("Dosage")

    for item in data.items:
        if item.error_message:
            table.add_row(item.target.input, f"[red]{item.error_message}[/red]", "", "", "", "", "", "", "")
            continue

        variant = item.variant
        samples = item.samples or []

        accession = variant.accession if variant else ""
        position = str(variant.position) if variant else ""
        reference = variant.reference or "" if variant else ""
        alternate = ", ".join(variant.alternate) if variant and variant.alternate else ""
        quality = f"{variant.quality:.4f}" if variant and variant.quality is not None else ""

        if not samples:
            table.add_row(item.target.input, accession, position, reference, alternate, quality, "", "", "")
        else:
            for i, sample in enumerate(samples):
                target_col = item.target.input if i == 0 else ""
                acc_col = accession if i == 0 else ""
                pos_col = position if i == 0 else ""
                ref_col = reference if i == 0 else ""
                alt_col = alternate if i == 0 else ""
                qual_col = quality if i == 0 else ""

                is_called = f"[green]{sample.is_called}[/green]" if sample.is_called else f"[red]{sample.is_called}[/red]"
                dosage = str(sample.dosage) if sample.dosage is not None else ""

                table.add_row(target_col, acc_col, pos_col, ref_col, alt_col, qual_col, sample.sample_id, is_called, dosage)

    return table
