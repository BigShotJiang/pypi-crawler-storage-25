from enum import Enum

from pydantic import BaseModel


class OutputFormat(str, Enum):
    table = "table"
    json = "json"


class Config(BaseModel):
    api_url: str
    redirect_port: int
    oauth_client_id: str
    oauth_authorize_url: str
    oauth_token_url: str
    output_format: str = OutputFormat.table.value

    @property
    def redirect_uri(self):
        return f"http://localhost:{self.redirect_port}/"
