"""Local mgrep package."""
