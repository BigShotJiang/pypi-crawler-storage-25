"""Verbumia MCP server (MIT)."""

__version__ = "0.13.0"
