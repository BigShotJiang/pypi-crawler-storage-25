"""MCP stdio server bootstrapping.

`run()` is the async entrypoint: load config, open the HTTP client, register
tools, then hand control to mcp's stdio transport. The MCP protocol uses
JSON-RPC over stdin/stdout, so we never print to stdout for logging — all
diagnostics go to stderr.
"""

from __future__ import annotations

import sys
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from mcp.server import Server
from mcp.server.models import InitializationOptions
from mcp.server.stdio import stdio_server
from mcp.types import ServerCapabilities, ToolsCapability

from . import __version__
from .client import VerbumiaApiError, VerbumiaClient
from .config import Config, load_config
from .tools import register


def _info(msg: str) -> None:
    """Stderr-only logging — stdout is reserved for the MCP framing."""
    print(msg, file=sys.stderr, flush=True)


@asynccontextmanager
async def _client_for(config: Config) -> AsyncIterator[VerbumiaClient]:
    client = VerbumiaClient(config)
    try:
        yield client
    finally:
        await client.aclose()


async def _preflight(client: VerbumiaClient) -> None:
    """Verify reachability + auth before starting the JSON-RPC loop.

    Hits `/v1/mcp/projects?limit=1` so we exercise both the API key (auth)
    and the mcp:* scope. Failures are turned into stderr-friendly messages
    so the MCP host (Claude Desktop / etc.) surfaces a real cause.
    """
    try:
        await client.get("/v1/mcp/projects", params={"limit": 1})
        _info(f"verbumia-mcp: connected to {client.config.api_base}")
    except VerbumiaApiError as exc:
        if exc.status == 401:
            raise RuntimeError(
                "VERBUMIA_API_KEY was rejected (401). Verify the key in Verbumia → "
                "Org Settings → API Keys; new keys are shown once on creation."
            ) from exc
        if exc.status == 403:
            raise RuntimeError(
                "API key lacks the `mcp:*` scope (403). Issue a key with mcp:* in "
                "Verbumia → Org Settings → API Keys."
            ) from exc
        raise RuntimeError(
            f"Verbumia API rejected the connectivity probe ({exc.status}): {exc.body}"
        ) from exc
    except Exception as exc:
        raise RuntimeError(
            f"Could not reach {client.config.api_base}: {exc}. "
            f"Set VERBUMIA_BASE_URL (or legacy VERBUMIA_API_BASE) for self-host or staging."
        ) from exc


async def run() -> None:
    config = load_config()
    _info(f"verbumia-mcp {__version__} starting (api={config.api_base})")
    server: Server = Server("verbumia")

    async with _client_for(config) as client:
        await _preflight(client)
        register(server, client)
        async with stdio_server() as (read_stream, write_stream):
            await server.run(
                read_stream,
                write_stream,
                InitializationOptions(
                    server_name="verbumia",
                    server_version=__version__,
                    capabilities=ServerCapabilities(tools=ToolsCapability(listChanged=False)),
                ),
            )
