"""Entrypoint for `verbumia-mcp` (and `python -m verbumia_mcp`)."""

from __future__ import annotations

import asyncio
import sys


def main() -> None:
    from .server import run

    try:
        asyncio.run(run())
    except KeyboardInterrupt:
        sys.exit(130)
    except RuntimeError as exc:
        # Configuration errors (missing token, etc.) — print a friendly hint.
        print(f"verbumia-mcp: {exc}", file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
