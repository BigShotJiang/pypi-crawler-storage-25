"""Runtime configuration loaded from environment variables.

The MCP server is invoked by clients like Claude Desktop, which pass `env`
entries through to the spawned process. We never read a config file — env
vars are the only contract.
"""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass

DEFAULT_API_BASE = "https://api.verbumia.dev"


@dataclass(frozen=True)
class Config:
    api_base: str
    token: str
    # Tuple of project UUIDs the operator scoped this MCP server to. Empty
    # means "unrestricted — fall back to whatever the API key can see".
    allowed_project_uuids: tuple[str, ...]
    user_agent: str

    @property
    def default_project_uuid(self) -> str | None:
        """The single project to use when none is passed explicitly.

        Only defined when exactly one project is configured — otherwise the
        caller MUST pass `project_uuid` per call (the resolver in tools.py
        enforces this).
        """
        return self.allowed_project_uuids[0] if len(self.allowed_project_uuids) == 1 else None


def _parse_projects_csv(raw: str) -> tuple[str, ...]:
    """Split, strip, and de-duplicate a CSV of project UUIDs while preserving order."""
    seen: list[str] = []
    for token in raw.split(","):
        v = token.strip()
        if v and v not in seen:
            seen.append(v)
    return tuple(seen)


def load_config() -> Config:
    # Canonical env var is VERBUMIA_API_KEY (matches the dashboard naming +
    # client-admin / website docs). VERBUMIA_TOKEN is accepted as a fallback
    # for users who configured early releases — both work, API_KEY wins.
    token = (
        os.environ.get("VERBUMIA_API_KEY", "").strip()
        or os.environ.get("VERBUMIA_TOKEN", "").strip()
    )
    if not token:
        raise RuntimeError(
            "VERBUMIA_API_KEY is required. Generate one in Verbumia → Org Settings → "
            "API Keys and add it to your MCP client config (e.g. Claude Desktop's "
            "mcp.json `env`). VERBUMIA_TOKEN is also accepted for back-compat."
        )
    # Canonical env var is VERBUMIA_BASE_URL (matches the dashboard naming).
    # VERBUMIA_API_BASE is accepted as a back-compat fallback for users on
    # earlier 0.x releases.
    api_base = (
        os.environ.get("VERBUMIA_BASE_URL", "").strip()
        or os.environ.get("VERBUMIA_API_BASE", "").strip()
        or DEFAULT_API_BASE
    ).rstrip("/")

    # Multi-project scoping. VERBUMIA_PROJECTS (CSV) is the canonical env;
    # VERBUMIA_PROJECT (singular) remains supported as a back-compat fallback
    # for users on 0.10.x. If both are set, PROJECTS wins and we warn.
    projects_csv = os.environ.get("VERBUMIA_PROJECTS", "").strip()
    project_single = os.environ.get("VERBUMIA_PROJECT", "").strip()
    if projects_csv and project_single:
        print(
            "verbumia-mcp: both VERBUMIA_PROJECTS and VERBUMIA_PROJECT are set; "
            "VERBUMIA_PROJECTS wins. Remove VERBUMIA_PROJECT to silence this warning.",
            file=sys.stderr,
        )
    if projects_csv:
        allowed = _parse_projects_csv(projects_csv)
    elif project_single:
        allowed = (project_single,)
    else:
        allowed = ()

    from . import __version__

    user_agent = f"verbumia-mcp/{__version__}"
    return Config(
        api_base=api_base,
        token=token,
        allowed_project_uuids=allowed,
        user_agent=user_agent,
    )
