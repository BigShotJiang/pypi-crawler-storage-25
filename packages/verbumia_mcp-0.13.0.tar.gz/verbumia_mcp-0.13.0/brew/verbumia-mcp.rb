# Homebrew formula source for the Verbumia MCP server.
#
# To publish:
#   1. Create a `homebrew-tap` repo at github.com/verbumia/homebrew-tap
#   2. Copy this file to that repo as `Formula/verbumia-mcp.rb`
#   3. After publishing the Python package to PyPI, fill in the `url` and
#      `sha256` from the PyPI source distribution.
#   4. `brew install verbumia/tap/verbumia-mcp`
#
# Pinning notes
# -------------
# This formula installs the Python package via virtualenv into the Homebrew
# cellar so it's hermetic from the user's system Python. The `resource`
# blocks must be regenerated on every release with `brew update-python-resources`.

class VerbumiaMcp < Formula
  include Language::Python::Virtualenv

  desc "Verbumia MCP server — Model Context Protocol bridge for Claude Desktop"
  homepage "https://verbumia.ca"
  # TODO(release): replace with actual PyPI sdist URL + sha256 once published.
  url "https://files.pythonhosted.org/packages/source/v/verbumia-mcp/verbumia_mcp-0.1.0.tar.gz"
  sha256 "0000000000000000000000000000000000000000000000000000000000000000"
  license "MIT"
  head "https://github.com/verbumia/verbumia-mcp.git", branch: "main"

  depends_on "python@3.12"

  # `brew update-python-resources verbumia-mcp` after each PyPI release will
  # regenerate the `resource` stanzas below for mcp / httpx / pydantic / etc.
  # Keep them empty here so the formula compiles in CI prior to first publish.

  def install
    virtualenv_install_with_resources
  end

  test do
    # The launcher exits 2 with a friendly stderr when VERBUMIA_TOKEN is missing.
    output = shell_output("#{bin}/verbumia-mcp 2>&1", 2)
    assert_match "VERBUMIA_TOKEN is required", output
  end
end
