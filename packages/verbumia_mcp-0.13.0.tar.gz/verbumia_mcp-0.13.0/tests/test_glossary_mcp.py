"""Contract tests for the glossary MCP tools + glossary-hints passthrough.

These drive the real VerbumiaClient over an httpx MockTransport, so they
assert the exact HTTP method / path / query / body each tool issues against
the frozen backend contract (artifact d9c3cd52). All glossary MATCHING is
backend-side — the MCP carries zero glossary logic, so there is nothing to
unit-test client-side beyond faithful request shaping + response passthrough.
"""

from __future__ import annotations

import json

import httpx
from mcp.server import Server

from verbumia_mcp.client import VerbumiaClient
from verbumia_mcp.config import Config
from verbumia_mcp.tools import register

PROJECT = "proj-1"
BASE = "https://api.test"


def _client(handler) -> VerbumiaClient:
    cfg = Config(
        api_base=BASE,
        token="vrb_live_a.b",
        allowed_project_uuids=(PROJECT,),
        user_agent="verbumia-mcp/test",
    )
    return VerbumiaClient(cfg, transport=httpx.MockTransport(handler))


def _handlers(client: VerbumiaClient):
    """register() returns (list_tools, call_tool); the mcp decorators register
    on the throwaway Server and return the original functions."""
    return register(Server("test"), client)


def _record(captured: dict, status: int = 200, body: dict | None = None):
    def handler(request: httpx.Request) -> httpx.Response:
        captured["method"] = request.method
        captured["path"] = request.url.path
        captured["query"] = dict(request.url.params)
        captured["body"] = json.loads(request.content) if request.content else None
        return httpx.Response(status, json={} if body is None else body)

    return handler


# ---- CRUD -----------------------------------------------------------------


async def test_glossary_list_get_with_filters() -> None:
    cap: dict = {}
    entry = {
        "uuid": "g1",
        "rule_type": "translation",
        "term": "Dashboard",
        "translations": {"fr": "tableau de bord"},
        "case_sensitive": False,
        "note": None,
    }
    client = _client(_record(cap, 200, {"items": [entry], "total": 1}))
    _, call = _handlers(client)
    out = await call(
        "glossary_list",
        {"project_uuid": PROJECT, "rule_type": "translation", "q": "dash", "limit": 50},
    )
    assert cap["method"] == "GET"
    assert cap["path"] == f"/v1/mcp/projects/{PROJECT}/glossary"
    assert cap["query"] == {"rule_type": "translation", "q": "dash", "limit": "50"}
    assert '"total": 1' in out[0].text
    await client.aclose()


async def test_glossary_list_default_limit_200() -> None:
    cap: dict = {}
    client = _client(_record(cap, 200, {"items": [], "total": 0}))
    _, call = _handlers(client)
    await call("glossary_list", {"project_uuid": PROJECT})
    assert cap["query"] == {"limit": "200"}
    await client.aclose()


async def test_glossary_create_posts_body() -> None:
    cap: dict = {}
    client = _client(_record(cap, 201, {"uuid": "g1"}))
    _, call = _handlers(client)
    await call(
        "glossary_create",
        {
            "project_uuid": PROJECT,
            "rule_type": "do_not_translate",
            "term": "Verbumia",
            "case_sensitive": True,
            "note": "brand",
        },
    )
    assert cap["method"] == "POST"
    assert cap["path"] == f"/v1/mcp/projects/{PROJECT}/glossary"
    assert cap["body"] == {
        "rule_type": "do_not_translate",
        "term": "Verbumia",
        "case_sensitive": True,
        "note": "brand",
    }
    await client.aclose()


async def test_glossary_create_minimal_omits_optionals() -> None:
    """rule_type default is applied BACKEND-side; the client forwards only what
    the caller passes (so a minimal call sends just {term})."""
    cap: dict = {}
    client = _client(_record(cap, 201, {"uuid": "g1"}))
    _, call = _handlers(client)
    await call("glossary_create", {"project_uuid": PROJECT, "term": "dashboard"})
    assert cap["body"] == {"term": "dashboard"}
    await client.aclose()


async def test_glossary_create_requires_term() -> None:
    client = _client(_record({}, 201, {}))
    _, call = _handlers(client)
    out = await call("glossary_create", {"project_uuid": PROJECT})
    assert "term is required" in out[0].text
    await client.aclose()


async def test_glossary_create_409_surfaced() -> None:
    client = _client(_record({}, 409, {"detail": "duplicate (rule_type, term)"}))
    _, call = _handlers(client)
    out = await call("glossary_create", {"project_uuid": PROJECT, "term": "Dashboard"})
    assert "409" in out[0].text
    await client.aclose()


async def test_glossary_update_patches_entry_id() -> None:
    cap: dict = {}
    client = _client(_record(cap, 200, {"uuid": "g1"}))
    _, call = _handlers(client)
    await call(
        "glossary_update",
        {"project_uuid": PROJECT, "entry_id": "g1", "translations": {"fr": "tableau de bord"}},
    )
    assert cap["method"] == "PATCH"
    assert cap["path"] == f"/v1/mcp/projects/{PROJECT}/glossary/g1"
    assert cap["body"] == {"translations": {"fr": "tableau de bord"}}
    await client.aclose()


async def test_glossary_update_requires_a_field() -> None:
    client = _client(_record({}, 200, {}))
    _, call = _handlers(client)
    out = await call("glossary_update", {"project_uuid": PROJECT, "entry_id": "g1"})
    assert "nothing to update" in out[0].text
    await client.aclose()


async def test_glossary_update_404_surfaced() -> None:
    client = _client(_record({}, 404, {"detail": "not found"}))
    _, call = _handlers(client)
    out = await call(
        "glossary_update", {"project_uuid": PROJECT, "entry_id": "nope", "term": "x"}
    )
    assert "404" in out[0].text
    await client.aclose()


async def test_glossary_delete_deletes_and_shapes_204() -> None:
    cap: dict = {}

    def handler(request: httpx.Request) -> httpx.Response:
        cap["method"] = request.method
        cap["path"] = request.url.path
        return httpx.Response(204)

    client = _client(handler)
    _, call = _handlers(client)
    out = await call("glossary_delete", {"project_uuid": PROJECT, "entry_id": "g1"})
    assert cap["method"] == "DELETE"
    assert cap["path"] == f"/v1/mcp/projects/{PROJECT}/glossary/g1"
    assert '"deleted": true' in out[0].text
    assert '"entry_id": "g1"' in out[0].text
    await client.aclose()


# ---- glossary hints passthrough ------------------------------------------


async def test_untranslated_keys_forwards_hints_flag_and_passes_through() -> None:
    cap: dict = {}
    hint = {
        "term": "dashboard",
        "rule_type": "translation",
        "target_translation": "tableau de bord",
        "matched_text": "Dashboard",
    }
    resp = {
        "items": [{"key": "hero.title", "source_value": "Dashboard", "glossary_hints": [hint]}],
        "next_cursor": None,
    }
    client = _client(_record(cap, 200, resp))
    _, call = _handlers(client)
    out = await call(
        "list_untranslated_keys",
        {"project_uuid": PROJECT, "language_code": "fr", "include_glossary_hints": True},
    )
    assert cap["path"] == f"/v1/mcp/projects/{PROJECT}/untranslated-keys"
    assert cap["query"]["include_glossary_hints"] == "true"
    assert cap["query"]["language_code"] == "fr"
    # passthrough: hints surface verbatim, unmodified by the client
    assert "tableau de bord" in out[0].text
    assert "matched_text" in out[0].text
    await client.aclose()


async def test_keys_forwards_hints_flag() -> None:
    cap: dict = {}
    client = _client(_record(cap, 200, {"items": []}))
    _, call = _handlers(client)
    await call("list_keys", {"project_uuid": PROJECT, "include_glossary_hints": True})
    assert cap["path"] == f"/v1/mcp/projects/{PROJECT}/keys"
    assert cap["query"]["include_glossary_hints"] == "true"
    await client.aclose()


async def test_hints_flag_omitted_by_default() -> None:
    cap: dict = {}
    client = _client(_record(cap, 200, {"items": []}))
    _, call = _handlers(client)
    await call("list_untranslated_keys", {"project_uuid": PROJECT, "language_code": "fr"})
    assert "include_glossary_hints" not in cap["query"]
    await client.aclose()


# ---- public vocabulary contract ------------------------------------------


async def test_glossary_tools_registered_with_public_rule_type_vocab() -> None:
    client = _client(_record({}, 200, {}))
    list_tools, _ = _handlers(client)
    tools = await list_tools()
    by_name = {t.name: t for t in tools}
    for n in ("glossary_list", "glossary_create", "glossary_update", "glossary_delete"):
        assert n in by_name, f"{n} not registered"
    public = ["translation", "do_not_translate", "forbidden"]
    assert by_name["glossary_create"].inputSchema["properties"]["rule_type"]["enum"] == public
    assert by_name["glossary_list"].inputSchema["properties"]["rule_type"]["enum"] == public
    # internal storage vocab (term/dnt) is NEVER a public rule_type value
    assert "dnt" not in public
    await client.aclose()
