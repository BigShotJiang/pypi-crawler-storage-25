import pytest

from verbumia_mcp.config import DEFAULT_API_BASE, load_config


def _clear_auth_env(monkeypatch) -> None:
    monkeypatch.delenv("VERBUMIA_API_KEY", raising=False)
    monkeypatch.delenv("VERBUMIA_TOKEN", raising=False)
    monkeypatch.delenv("VERBUMIA_BASE_URL", raising=False)
    monkeypatch.delenv("VERBUMIA_API_BASE", raising=False)
    monkeypatch.delenv("VERBUMIA_PROJECT", raising=False)
    monkeypatch.delenv("VERBUMIA_PROJECTS", raising=False)


def test_load_config_requires_api_key(monkeypatch) -> None:
    _clear_auth_env(monkeypatch)
    with pytest.raises(RuntimeError) as exc:
        load_config()
    # Error message must mention BOTH the canonical name and the back-compat alias.
    msg = str(exc.value)
    assert "VERBUMIA_API_KEY" in msg
    assert "VERBUMIA_TOKEN" in msg


def test_load_config_canonical_api_key(monkeypatch) -> None:
    _clear_auth_env(monkeypatch)
    monkeypatch.setenv("VERBUMIA_API_KEY", "vrb_live_abc.def")
    cfg = load_config()
    assert cfg.token == "vrb_live_abc.def"
    assert cfg.api_base == DEFAULT_API_BASE
    assert cfg.default_project_uuid is None
    assert cfg.user_agent.startswith("verbumia-mcp/")


def test_load_config_token_backcompat_alias_works(monkeypatch) -> None:
    """VERBUMIA_TOKEN still accepted when VERBUMIA_API_KEY is unset."""
    _clear_auth_env(monkeypatch)
    monkeypatch.setenv("VERBUMIA_TOKEN", "vrb_live_legacy.x")
    cfg = load_config()
    assert cfg.token == "vrb_live_legacy.x"


def test_load_config_api_key_wins_over_token(monkeypatch) -> None:
    """When BOTH are set, VERBUMIA_API_KEY wins (canon priority)."""
    _clear_auth_env(monkeypatch)
    monkeypatch.setenv("VERBUMIA_API_KEY", "vrb_live_canon.x")
    monkeypatch.setenv("VERBUMIA_TOKEN", "vrb_live_legacy.y")
    cfg = load_config()
    assert cfg.token == "vrb_live_canon.x"


def test_load_config_canonical_base_url(monkeypatch) -> None:
    _clear_auth_env(monkeypatch)
    monkeypatch.setenv("VERBUMIA_API_KEY", "vrb_live_a.b")
    monkeypatch.setenv("VERBUMIA_BASE_URL", "http://localhost:8820/")
    cfg = load_config()
    assert cfg.api_base == "http://localhost:8820"  # trailing slash stripped


def test_load_config_api_base_backcompat_alias(monkeypatch) -> None:
    _clear_auth_env(monkeypatch)
    monkeypatch.setenv("VERBUMIA_API_KEY", "vrb_live_a.b")
    monkeypatch.setenv("VERBUMIA_API_BASE", "http://legacy.example.com")
    cfg = load_config()
    assert cfg.api_base == "http://legacy.example.com"


def test_load_config_base_url_wins_over_api_base(monkeypatch) -> None:
    _clear_auth_env(monkeypatch)
    monkeypatch.setenv("VERBUMIA_API_KEY", "vrb_live_a.b")
    monkeypatch.setenv("VERBUMIA_BASE_URL", "http://canon.example")
    monkeypatch.setenv("VERBUMIA_API_BASE", "http://legacy.example")
    cfg = load_config()
    assert cfg.api_base == "http://canon.example"


def test_load_config_project_env_picked_up(monkeypatch) -> None:
    _clear_auth_env(monkeypatch)
    monkeypatch.setenv("VERBUMIA_API_KEY", "vrb_live_a.b")
    monkeypatch.setenv("VERBUMIA_PROJECT", "proj-uuid")
    cfg = load_config()
    assert cfg.default_project_uuid == "proj-uuid"
    assert cfg.allowed_project_uuids == ("proj-uuid",)


def test_load_config_projects_csv(monkeypatch) -> None:
    _clear_auth_env(monkeypatch)
    monkeypatch.setenv("VERBUMIA_API_KEY", "vrb_live_a.b")
    monkeypatch.setenv("VERBUMIA_PROJECTS", "uuid-a, uuid-b ,uuid-c")
    cfg = load_config()
    assert cfg.allowed_project_uuids == ("uuid-a", "uuid-b", "uuid-c")
    # No silent default when >1 — caller MUST pass project_uuid per call.
    assert cfg.default_project_uuid is None


def test_load_config_projects_csv_single_value_acts_as_default(monkeypatch) -> None:
    _clear_auth_env(monkeypatch)
    monkeypatch.setenv("VERBUMIA_API_KEY", "vrb_live_a.b")
    monkeypatch.setenv("VERBUMIA_PROJECTS", "only-one")
    cfg = load_config()
    assert cfg.allowed_project_uuids == ("only-one",)
    assert cfg.default_project_uuid == "only-one"


def test_load_config_projects_csv_dedupes_and_strips(monkeypatch) -> None:
    _clear_auth_env(monkeypatch)
    monkeypatch.setenv("VERBUMIA_API_KEY", "vrb_live_a.b")
    monkeypatch.setenv("VERBUMIA_PROJECTS", "a,,b, a , c")
    cfg = load_config()
    assert cfg.allowed_project_uuids == ("a", "b", "c")


def test_load_config_projects_wins_over_project_singular(monkeypatch, capsys) -> None:
    _clear_auth_env(monkeypatch)
    monkeypatch.setenv("VERBUMIA_API_KEY", "vrb_live_a.b")
    monkeypatch.setenv("VERBUMIA_PROJECTS", "new1,new2")
    monkeypatch.setenv("VERBUMIA_PROJECT", "legacy")
    cfg = load_config()
    assert cfg.allowed_project_uuids == ("new1", "new2")
    # And we warn on stderr so operators notice the redundant env.
    captured = capsys.readouterr()
    assert "VERBUMIA_PROJECTS" in captured.err
    assert "VERBUMIA_PROJECT" in captured.err
