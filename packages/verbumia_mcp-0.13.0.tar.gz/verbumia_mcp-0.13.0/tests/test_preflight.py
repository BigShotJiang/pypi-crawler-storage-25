"""Tests for the startup preflight (auth+connectivity)."""

import pytest

from verbumia_mcp.client import VerbumiaApiError, VerbumiaClient
from verbumia_mcp.config import Config
from verbumia_mcp.server import _preflight


class _FakeClient:
    def __init__(self, raises: Exception | None = None) -> None:
        self._raises = raises
        self.config = Config(
            api_base="http://localhost:9999",
            token="x",
            allowed_project_uuids=(),
            user_agent="test",
        )

    async def get(self, path: str, params: dict | None = None):
        if self._raises:
            raise self._raises
        return {"items": []}


@pytest.mark.asyncio
async def test_preflight_succeeds_when_api_returns_2xx() -> None:
    await _preflight(_FakeClient())  # type: ignore[arg-type]


@pytest.mark.asyncio
async def test_preflight_401_explains_token() -> None:
    err = VerbumiaApiError(401, "unauthorized")
    with pytest.raises(RuntimeError) as exc:
        await _preflight(_FakeClient(raises=err))  # type: ignore[arg-type]
    assert "VERBUMIA_API_KEY" in str(exc.value)


@pytest.mark.asyncio
async def test_preflight_403_mentions_scope() -> None:
    err = VerbumiaApiError(403, "missing scope")
    with pytest.raises(RuntimeError) as exc:
        await _preflight(_FakeClient(raises=err))  # type: ignore[arg-type]
    assert "mcp:*" in str(exc.value)


@pytest.mark.asyncio
async def test_preflight_network_error_mentions_api_base() -> None:
    with pytest.raises(RuntimeError) as exc:
        await _preflight(_FakeClient(raises=ConnectionError("nope")))  # type: ignore[arg-type]
    assert "VERBUMIA_BASE_URL" in str(exc.value)


@pytest.mark.asyncio
async def test_real_client_against_live_backend_with_dummy_key_returns_401_or_403() -> None:
    """Smoke: verify the real client surfaces a 401/403 cleanly when the key is fake."""
    cfg = Config(
        api_base="http://localhost:8820",
        token="vrb_live_dummy.dummy",
        allowed_project_uuids=(),
        user_agent="verbumia-mcp/test",
    )
    client = VerbumiaClient(cfg)
    try:
        with pytest.raises(VerbumiaApiError) as exc:
            await client.get("/v1/mcp/projects", params={"limit": 1})
        assert exc.value.status in {401, 403}
    finally:
        await client.aclose()
