import pytest

from verbumia_mcp.client import VerbumiaClient
from verbumia_mcp.config import Config


@pytest.mark.asyncio
async def test_health_against_live_backend() -> None:
    """Smoke test against the docker-compose backend on :8820."""
    cfg = Config(
        api_base="http://localhost:8820",
        token="vrb_live_dummy.dummy",
        allowed_project_uuids=(),
        user_agent="verbumia-mcp/test",
    )
    client = VerbumiaClient(cfg)
    try:
        data = await client.health()
    finally:
        await client.aclose()
    assert isinstance(data, dict)
    assert data.get("status") in {"ok", "degraded"}
    assert set(data.get("deps", {}).keys()) == {"mongo", "redis", "centrifugo"}
