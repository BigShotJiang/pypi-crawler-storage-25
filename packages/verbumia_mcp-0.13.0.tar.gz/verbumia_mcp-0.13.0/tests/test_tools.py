"""Unit tests for the project-uuid resolver in tools.py."""

from __future__ import annotations

from types import SimpleNamespace

import pytest

from verbumia_mcp.config import Config
from verbumia_mcp.tools import _filter_projects_by_allowlist, _project_uuid


def _mk_client(allowed: tuple[str, ...]) -> SimpleNamespace:
    cfg = Config(
        api_base="https://api.verbumia.ca",
        token="vrb_live_a.b",
        allowed_project_uuids=allowed,
        user_agent="verbumia-mcp/test",
    )
    return SimpleNamespace(config=cfg)


def test_resolve_explicit_arg_matching_default_passes() -> None:
    """Explicit arg equal to the single configured project is fine (no surprise)."""
    client = _mk_client(("only-uuid",))
    assert _project_uuid({"project_uuid": "only-uuid"}, client) == "only-uuid"


def test_resolve_explicit_arg_outside_single_configured_rejected() -> None:
    """Single configured project is also an allowlist — explicit args outside it raise."""
    client = _mk_client(("only-uuid",))
    with pytest.raises(ValueError) as exc:
        _project_uuid({"project_uuid": "elsewhere"}, client)
    assert "allowlist" in str(exc.value)


def test_resolve_default_when_single_configured() -> None:
    client = _mk_client(("only-one",))
    assert _project_uuid({}, client) == "only-one"
    assert _project_uuid(None, client) == "only-one"


def test_resolve_raises_when_multi_configured_and_no_arg() -> None:
    client = _mk_client(("a", "b", "c"))
    with pytest.raises(ValueError) as exc:
        _project_uuid({}, client)
    msg = str(exc.value)
    assert "required" in msg
    # The error lists the allowed UUIDs so the LLM can pick one.
    for uuid in ("a", "b", "c"):
        assert uuid in msg


def test_resolve_raises_when_arg_outside_allowlist() -> None:
    client = _mk_client(("a", "b"))
    with pytest.raises(ValueError) as exc:
        _project_uuid({"project_uuid": "rogue"}, client)
    msg = str(exc.value)
    assert "rogue" in msg
    assert "allowlist" in msg


def test_resolve_arg_inside_allowlist_passes() -> None:
    client = _mk_client(("a", "b"))
    assert _project_uuid({"project_uuid": "a"}, client) == "a"
    assert _project_uuid({"project_uuid": "b"}, client) == "b"


def test_resolve_raises_when_nothing_configured_and_no_arg() -> None:
    client = _mk_client(())
    with pytest.raises(ValueError) as exc:
        _project_uuid({}, client)
    msg = str(exc.value)
    assert "VERBUMIA_PROJECTS" in msg or "VERBUMIA_PROJECT" in msg


def test_resolve_arg_passes_through_when_unconfigured() -> None:
    """No env scope = trust whatever the API key can see; just forward the arg."""
    client = _mk_client(())
    assert _project_uuid({"project_uuid": "anything"}, client) == "anything"


# ---- list_projects allowlist filter (see == touch) -----------------------


def test_list_projects_filtered_to_allowlist() -> None:
    data = {"items": [{"uuid": "a"}, {"uuid": "b"}, {"uuid": "c"}]}
    out = _filter_projects_by_allowlist(data, ("a", "c"))
    assert [p["uuid"] for p in out["items"]] == ["a", "c"]


def test_list_projects_unfiltered_when_no_allowlist() -> None:
    data = {"items": [{"uuid": "a"}, {"uuid": "b"}]}
    assert _filter_projects_by_allowlist(data, ()) == data


def test_list_projects_filter_tolerates_unexpected_shape() -> None:
    # Non-dict / missing items -> returned unchanged (no crash).
    assert _filter_projects_by_allowlist([1, 2], ("a",)) == [1, 2]
    assert _filter_projects_by_allowlist({"x": 1}, ("a",)) == {"x": 1}
