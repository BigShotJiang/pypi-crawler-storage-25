"""W3C Trace Context propagation.

Per ``docs/spec/05-sdk-contract.md`` "Reference SDK responsibilities":
the SDK reads inbound ``traceparent`` / ``tracestate`` headers and
injects outbound ones so traces span service boundaries.

W3C ``traceparent`` format: ``{version}-{trace_id}-{parent_id}-{flags}``
- version: 2 hex chars (currently always ``00``)
- trace_id: 32 hex chars
- parent_id: 16 hex chars (the caller's span id, becomes our parent_span_id)
- flags: 2 hex chars (bit 0 = sampled)
"""

from __future__ import annotations

import re
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Any

from ._context import (
    IdentityContext,
    current_context,
    pop_context,
    push_context,
)
from ._ids import new_span_id
from ._logger import get_logger

_log = get_logger("trace_context")

_TRACEPARENT_RE = re.compile(r"^([0-9a-f]{2})-([0-9a-f]{32})-([0-9a-f]{16})-([0-9a-f]{2})$")
TRACEPARENT_VERSION = "00"
TRACE_FLAG_SAMPLED = 0x01


@dataclass(frozen=True)
class TraceParent:
    """Parsed ``traceparent`` header per W3C spec."""

    trace_id: str
    span_id: str
    trace_flags: int
    version: str = TRACEPARENT_VERSION

    @property
    def sampled(self) -> bool:
        return bool(self.trace_flags & TRACE_FLAG_SAMPLED)


def parse_traceparent(header: str | None) -> TraceParent | None:
    """Parse a W3C ``traceparent`` header. Returns ``None`` if invalid.

    Future versions may have a longer payload; per the W3C spec readers
    must accept any future version with a known prefix and ignore extra
    fields. We honor that by matching the leading 4 segments only.
    """
    if not header:
        return None
    header = header.strip()
    # Allow trailing fields per W3C forward-compatibility rules.
    parts = header.split("-")
    if len(parts) < 4:
        return None
    candidate = "-".join(parts[:4])
    match = _TRACEPARENT_RE.match(candidate)
    if not match:
        return None
    version, trace_id, span_id, flags = match.groups()
    # Reject the all-zero trace_id / span_id per W3C: those signal "no trace".
    if trace_id == "0" * 32 or span_id == "0" * 16:
        return None
    try:
        flag_int = int(flags, 16)
    except ValueError:
        return None
    return TraceParent(
        trace_id=trace_id,
        span_id=span_id,
        trace_flags=flag_int,
        version=version,
    )


def format_traceparent(trace_id: str, span_id: str, sampled: bool = True) -> str:
    """Build a W3C ``traceparent`` header from the supplied ids."""
    flags = TRACE_FLAG_SAMPLED if sampled else 0x00
    return f"{TRACEPARENT_VERSION}-{trace_id}-{span_id}-{flags:02x}"


# ---- httpx event hooks -----------------------------------------------------


def httpx_request_hook(request: Any) -> None:
    """httpx event hook: inject ``traceparent`` / ``tracestate`` outbound.

    Register via ``httpx.Client(event_hooks={"request": [httpx_request_hook]})``.
    Pulls the current trace_id / span_id from the SDK's identity context.
    No-op if the context has no trace_id (nothing to propagate).
    """
    try:
        ctx = current_context()
        if not ctx.trace_id or not ctx.span_id:
            return
        request.headers.setdefault(
            "traceparent",
            format_traceparent(ctx.trace_id, ctx.span_id, sampled=True),
        )
        # tracestate is vendor-extensible; we don't add agentos-specific
        # state by default but preserve any pre-existing value.
    except Exception:
        _log.warning("httpx_request_hook failed", exc_info=True)


def httpx_response_hook(response: Any) -> None:
    """httpx event hook: capture downstream-returned trace context.

    Most servers don't echo ``traceparent`` back, but if one does (e.g.
    a tracing-aware proxy), we expose the captured value on the
    response under ``response.extensions["agentos_traceparent"]`` so
    higher layers can correlate without parsing again.
    """
    try:
        header = response.headers.get("traceparent")
        if not header:
            return
        parsed = parse_traceparent(header)
        if parsed is not None:
            response.extensions["agentos_traceparent"] = parsed
    except Exception:
        _log.warning("httpx_response_hook failed", exc_info=True)


# ---- Server-side helpers ---------------------------------------------------


def trace_id_from_request_headers(headers: Any) -> TraceParent | None:
    """Read ``traceparent`` from a server request's headers (FastAPI / Flask).

    ``headers`` may be any object with case-insensitive ``__getitem__`` /
    ``.get()`` behavior — Flask's ``request.headers``, FastAPI's
    ``request.headers``, or a plain dict.
    """
    if headers is None:
        return None
    try:
        if hasattr(headers, "get"):
            value = headers.get("traceparent") or headers.get("Traceparent")
        else:
            value = headers["traceparent"]
    except (KeyError, AttributeError):
        return None
    return parse_traceparent(value)


@contextmanager
def start_span_from_request(request: Any) -> Iterator[IdentityContext]:
    """Push a span context derived from an inbound request's ``traceparent``.

    Use as middleware in FastAPI / Flask handlers — yields the new
    :class:`IdentityContext`, restoring the previous one on exit. If
    the request has no valid ``traceparent``, opens a fresh trace.
    Logs are silent on parse failures (forward-compat behavior).
    """
    headers = getattr(request, "headers", None)
    parsed = trace_id_from_request_headers(headers)
    parent_ctx = current_context()

    if parsed is None:
        # Open a fresh trace under this handler.
        new_ctx = IdentityContext(
            agent_id=parent_ctx.agent_id,
            project_id=parent_ctx.project_id,
            task_run_id=parent_ctx.task_run_id,
            trace_id=parent_ctx.trace_id or _fresh_trace_id(),
            span_id=new_span_id(),
            parent_span_id=parent_ctx.span_id,
            user_id=parent_ctx.user_id,
            session_id=parent_ctx.session_id,
            environment=parent_ctx.environment,
            synthetic_task_run=parent_ctx.synthetic_task_run,
        )
    else:
        new_ctx = IdentityContext(
            agent_id=parent_ctx.agent_id,
            project_id=parent_ctx.project_id,
            task_run_id=parent_ctx.task_run_id,
            trace_id=parsed.trace_id,
            span_id=new_span_id(),
            parent_span_id=parsed.span_id,
            user_id=parent_ctx.user_id,
            session_id=parent_ctx.session_id,
            environment=parent_ctx.environment,
            synthetic_task_run=parent_ctx.synthetic_task_run,
        )

    token = push_context(new_ctx)
    try:
        yield new_ctx
    finally:
        pop_context(token)


def _fresh_trace_id() -> str:
    # Imported lazily to avoid a cycle at module import time.
    from ._ids import new_trace_id

    return new_trace_id()
