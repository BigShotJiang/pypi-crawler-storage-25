"""AgentRun sidecar detection + routing.

Per ``docs/spec/05-sdk-contract.md`` "Runtime context": when the SDK
runs inside an AgentRun container, tool calls are routed through the
syscall mediator sidecar over a Unix domain socket so policy / cost
accounting / audit signatures all engage. Outside AgentRun, the SDK
uses direct HTTP — same SDK code works in both environments.

Env vars:
- ``AGENTOS_RUNTIME=1`` activates runtime mode.
- ``AGENTOS_RUNTIME_SOCKET`` overrides the default socket path.
- ``AGENTOS_API_KEY`` is injected by the runtime; the SDK reads it
  through the standard configuration path. The Unix socket is for
  syscall mediation only — ingestion still goes over HTTPS.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import httpx

from ._logger import get_logger

_log = get_logger("runtime")

DEFAULT_RUNTIME_SOCKET = "/var/run/agentos.sock"


def is_in_runtime() -> bool:
    """Return True when ``AGENTOS_RUNTIME=1``."""
    value = os.environ.get("AGENTOS_RUNTIME", "").strip().lower()
    return value in ("1", "true", "yes", "on")


def runtime_socket_path() -> Path | None:
    """Return the Unix socket path the SDK should use to reach the sidecar."""
    if not is_in_runtime():
        return None
    raw = os.environ.get("AGENTOS_RUNTIME_SOCKET", DEFAULT_RUNTIME_SOCKET)
    return Path(raw)


@dataclass(frozen=True)
class ToolDecision:
    """Result of a syscall-mediated tool invocation.

    ``allowed=False`` means the sidecar's policy engine blocked the
    call. ``redacted_fields`` enumerates dot-paths that AgentSec
    rewrote in either the input or the output.
    """

    allowed: bool
    output: Any = None
    error: str | None = None
    redacted_fields: list[str] | None = None


class RuntimeClient:
    """Async HTTP client over the AgentRun Unix socket.

    Constructed lazily by :func:`get_runtime_client`; not instantiated
    when the SDK runs outside AgentRun. Methods mirror the syscall
    mediator's shape per Phase 4 spec.
    """

    def __init__(
        self,
        socket_path: Path | str | None = None,
        *,
        http_client: httpx.AsyncClient | None = None,
        timeout: float = 30.0,
    ) -> None:
        self._socket_path = Path(socket_path) if socket_path is not None else None
        self._timeout = timeout
        if http_client is not None:
            self._http = http_client
            self._owns_http = False
        elif self._socket_path is not None:
            transport = httpx.AsyncHTTPTransport(uds=str(self._socket_path))
            self._http = httpx.AsyncClient(
                transport=transport,
                base_url="http://agentos-sidecar",
                timeout=timeout,
            )
            self._owns_http = True
        else:
            raise ValueError("RuntimeClient requires either socket_path or http_client")

    async def aclose(self) -> None:
        if self._owns_http:
            await self._http.aclose()

    @property
    def socket_path(self) -> Path | None:
        return self._socket_path

    # ---- Mediated syscalls ------------------------------------------------

    async def tool_call(self, tool_name: str, input: Any) -> ToolDecision:
        """POST ``/v1/syscall/tool_call``. Never raises out of the SDK."""
        try:
            resp = await self._http.post(
                "/v1/syscall/tool_call",
                json={"tool": tool_name, "input": input},
                timeout=self._timeout,
            )
        except Exception as exc:
            _log.warning("runtime tool_call transport failed: %s", exc)
            return ToolDecision(allowed=False, error=str(exc))
        return _decode_tool_decision(resp)

    async def memory_op(
        self,
        subsystem: str,
        operation: str,
        **fields: Any,
    ) -> dict[str, Any]:
        """POST ``/v1/syscall/memory_op``."""
        body: dict[str, Any] = {"subsystem": subsystem, "operation": operation}
        body.update(fields)
        try:
            resp = await self._http.post("/v1/syscall/memory_op", json=body, timeout=self._timeout)
            return _decode_json(resp)
        except Exception as exc:
            _log.warning("runtime memory_op failed: %s", exc)
            return {"ok": False, "error": str(exc)}

    async def route_decide(
        self,
        goal: str,
        context: dict[str, Any] | None = None,
        candidates: list[str] | None = None,
    ) -> dict[str, Any]:
        """POST ``/v1/syscall/route_decide``."""
        body: dict[str, Any] = {"goal": goal}
        if context is not None:
            body["context"] = context
        if candidates is not None:
            body["candidates"] = candidates
        try:
            resp = await self._http.post(
                "/v1/syscall/route_decide", json=body, timeout=self._timeout
            )
            return _decode_json(resp)
        except Exception as exc:
            _log.warning("runtime route_decide failed: %s", exc)
            return {"ok": False, "error": str(exc)}

    async def route_outcome(
        self,
        decision_span_id: str,
        **fields: Any,
    ) -> dict[str, Any]:
        """POST ``/v1/syscall/route_outcome``."""
        body: dict[str, Any] = {"decision_span_id": decision_span_id}
        body.update(fields)
        try:
            resp = await self._http.post(
                "/v1/syscall/route_outcome", json=body, timeout=self._timeout
            )
            return _decode_json(resp)
        except Exception as exc:
            _log.warning("runtime route_outcome failed: %s", exc)
            return {"ok": False, "error": str(exc)}


def _decode_json(resp: httpx.Response) -> dict[str, Any]:
    if 200 <= resp.status_code < 300:
        try:
            data = resp.json()
            if isinstance(data, dict):
                return data
            return {"ok": True, "data": data}
        except Exception:
            return {"ok": True}
    return {"ok": False, "status": resp.status_code, "body": resp.text[:512]}


def _decode_tool_decision(resp: httpx.Response) -> ToolDecision:
    if 200 <= resp.status_code < 300:
        try:
            data = resp.json()
        except Exception:
            return ToolDecision(allowed=True)
        if not isinstance(data, dict):
            return ToolDecision(allowed=True, output=data)
        return ToolDecision(
            allowed=bool(data.get("allowed", True)),
            output=data.get("output"),
            error=data.get("error"),
            redacted_fields=data.get("redacted_fields"),
        )
    return ToolDecision(
        allowed=False,
        error=f"sidecar returned {resp.status_code}: {resp.text[:256]}",
    )


# ---- Module-level cached client --------------------------------------------


_cached_client: RuntimeClient | None = None


def get_runtime_client() -> RuntimeClient | None:
    """Return a cached :class:`RuntimeClient`, or ``None`` outside AgentRun."""
    global _cached_client
    if _cached_client is not None:
        return _cached_client
    if not is_in_runtime():
        return None
    socket = runtime_socket_path()
    if socket is None:
        return None
    try:
        _cached_client = RuntimeClient(socket)
    except Exception:
        _log.warning("failed to construct RuntimeClient", exc_info=True)
        return None
    return _cached_client


def reset_runtime_client() -> None:
    """Clear the cached client. Used by the fork handler and tests."""
    global _cached_client
    _cached_client = None
