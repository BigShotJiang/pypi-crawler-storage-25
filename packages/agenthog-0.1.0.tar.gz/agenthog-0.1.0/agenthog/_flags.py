"""Flag SDK — local evaluation against a periodically-refreshed cache.

Per ``docs/spec/05-sdk-contract.md`` "Flags and experiments" and
``docs/spec/30-agenthog-spec.md`` "Experiments & flags":

- The SDK polls ``GET /v1/flags`` every 60s, caching definitions
  locally.
- ``flag(key, default, **context)`` evaluates against the cache (no
  per-call network) using priority-ascending, first-match-wins
  semantics — same rule the server endpoint uses.
- Each ``flag()`` call emits an ``agent.flag_check`` event with the
  resolved key, value, variant, experiment_id, and reason.
- If the cache is empty or the key is unknown, ``flag()`` returns the
  caller's default with reason ``"default"`` and a one-time WARN.
"""

from __future__ import annotations

import asyncio
import contextlib
import hashlib
import threading
import time
from dataclasses import dataclass, field
from typing import Any

import httpx

from ._logger import get_logger

_log = get_logger("flags")

DEFAULT_REFRESH_INTERVAL_S = 60.0


@dataclass
class FlagDefinition:
    """One flag's targeting rules and default.

    Each rule is a dict with at least a ``value`` key, optionally
    ``priority`` (int; lower fires first), ``match`` (dict of
    ``context_key → expected_value`` — all must match), ``percentage``
    (0-100; rule fires when the stable hash bucket is below this), and
    ``variant`` (string label). The fall-through default is captured
    on the flag itself, not in the rule list.
    """

    key: str
    rules: list[dict[str, Any]] = field(default_factory=list)
    experiment_id: str | None = None
    default_value: Any = None


class FlagCache:
    """Thread-safe flag cache. Refresh runs in the SDK's background loop."""

    def __init__(self) -> None:
        self._flags: dict[str, FlagDefinition] = {}
        self._lock = threading.Lock()
        self._last_fetch_at: float = 0.0
        self._never_fetched = True

    def get(self, key: str) -> FlagDefinition | None:
        with self._lock:
            return self._flags.get(key)

    def replace(self, definitions: list[FlagDefinition]) -> None:
        new = {f.key: f for f in definitions}
        with self._lock:
            self._flags = new
            self._last_fetch_at = time.monotonic()
            self._never_fetched = False

    @property
    def is_empty(self) -> bool:
        with self._lock:
            return self._never_fetched or not self._flags

    @property
    def last_fetch_at(self) -> float:
        with self._lock:
            return self._last_fetch_at


# ---- Evaluation ------------------------------------------------------------


def evaluate(
    flag: FlagDefinition,
    context: dict[str, Any],
) -> tuple[Any, str | None, str]:
    """Resolve a flag against ``context``. Returns ``(value, variant, reason)``.

    ``reason`` is one of ``"rule_match"``, ``"percentage_rollout"``,
    ``"default"`` — matches the spec's enum.
    """
    rules = sorted(flag.rules, key=lambda r: int(r.get("priority", 0)))
    for rule in rules:
        if not _matches(rule.get("match") or {}, context):
            continue
        percentage = rule.get("percentage")
        if percentage is None:
            return rule.get("value"), rule.get("variant"), "rule_match"
        bucket = _bucket_percent(flag.key, context)
        if bucket < float(percentage):
            return rule.get("value"), rule.get("variant"), "percentage_rollout"
    return flag.default_value, None, "default"


def _matches(match: dict[str, Any], context: dict[str, Any]) -> bool:
    return all(context.get(key) == expected for key, expected in match.items())


def _bucket_percent(flag_key: str, context: dict[str, Any]) -> float:
    """Stable hash → 0..100 bucket for percentage rollouts.

    Hashes ``flag_key + ":" + (user_id|agent_id|"")`` with sha256 and
    takes the leading 32 bits / 0xFFFFFFFF * 100. Same input always
    produces the same bucket — required so a 50%-rollout user stays
    in or out across calls.
    """
    target = context.get("user_id") or context.get("agent_id") or context.get("session_id") or ""
    digest = hashlib.sha256(f"{flag_key}:{target}".encode()).hexdigest()
    return (int(digest[:8], 16) / 0xFFFFFFFF) * 100.0


# ---- Network fetch ---------------------------------------------------------


def parse_flag_definitions(payload: Any) -> list[FlagDefinition]:
    """Translate the wire format into :class:`FlagDefinition` objects.

    Accepts either ``{"data": [...]}`` (list-endpoint envelope) or a
    bare list. Skips entries missing a ``key``.
    """
    if isinstance(payload, dict):
        items = payload.get("data") or payload.get("flags") or []
    elif isinstance(payload, list):
        items = payload
    else:
        return []
    out: list[FlagDefinition] = []
    for raw in items:
        if not isinstance(raw, dict):
            continue
        key = raw.get("key")
        if not key:
            continue
        out.append(
            FlagDefinition(
                key=str(key),
                rules=raw.get("rules") or [],
                experiment_id=raw.get("experiment_id"),
                default_value=raw.get("default_value"),
            )
        )
    return out


async def fetch_flags(
    http: httpx.AsyncClient,
    endpoint: str,
    api_key: str | None,
) -> list[FlagDefinition] | None:
    """GET ``/v1/flags``. Returns ``None`` on transport failure."""
    headers = {"Accept": "application/json"}
    if api_key:
        headers["X-API-Key"] = api_key
    url = f"{endpoint.rstrip('/')}/v1/flags"
    try:
        resp = await http.get(url, headers=headers, timeout=10.0)
    except Exception:
        _log.warning("flag fetch transport failure", exc_info=True)
        return None
    if not (200 <= resp.status_code < 300):
        _log.warning("flag fetch returned status %d", resp.status_code)
        return None
    try:
        return parse_flag_definitions(resp.json())
    except Exception:
        _log.warning("flag fetch payload parse failed", exc_info=True)
        return None


class FlagRefresher:
    """Background refresh loop. One per :class:`AsyncClient`."""

    def __init__(
        self,
        cache: FlagCache,
        http: httpx.AsyncClient,
        endpoint: str,
        api_key: str | None,
        *,
        interval_s: float = DEFAULT_REFRESH_INTERVAL_S,
    ) -> None:
        self._cache = cache
        self._http = http
        self._endpoint = endpoint
        self._api_key = api_key
        self._interval = interval_s
        self._task: asyncio.Task[None] | None = None
        self._stop = asyncio.Event()

    def start(self) -> None:
        if self._task is None or self._task.done():
            self._stop = asyncio.Event()
            self._task = asyncio.create_task(self._loop())

    async def stop(self) -> None:
        self._stop.set()
        if self._task is not None:
            try:
                await asyncio.wait_for(self._task, timeout=2.0)
            except asyncio.TimeoutError:
                self._task.cancel()
            self._task = None

    async def refresh_once(self) -> None:
        """Trigger a single fetch + cache replacement. Public for tests."""
        defs = await fetch_flags(self._http, self._endpoint, self._api_key)
        if defs is not None:
            self._cache.replace(defs)

    async def _loop(self) -> None:
        # Initial fetch on startup.
        await self.refresh_once()
        while not self._stop.is_set():
            with contextlib.suppress(asyncio.TimeoutError):
                await asyncio.wait_for(self._stop.wait(), timeout=self._interval)
            if self._stop.is_set():
                return
            try:
                await self.refresh_once()
            except Exception:
                _log.warning("flag refresh iteration failed", exc_info=True)
