"""SDK configuration.

Per ``docs/spec/05-sdk-contract.md`` "Configuration" section. Reads
env vars first, explicit ``init(...)`` args override.
"""

from __future__ import annotations

import os
from dataclasses import dataclass

DEFAULT_ENDPOINT = "https://api.theagentos.space"
DEFAULT_FLUSH_INTERVAL_MS = 250
DEFAULT_FLUSH_BATCH_SIZE = 100
DEFAULT_BUFFER_MAX_SIZE = 10000
DEFAULT_GZIP_THRESHOLD_BYTES = 4096
DEFAULT_MAX_RETRIES = 5
DEFAULT_SHUTDOWN_TIMEOUT_S = 5.0
DEFAULT_SDK_NAME = "agenthog-python"


def _env_truthy(value: str | None) -> bool:
    if value is None:
        return False
    return value.strip().lower() in ("1", "true", "yes", "y", "on")


@dataclass
class Config:
    """Resolved SDK configuration. Construct via :meth:`from_env_and_args`."""

    api_key: str | None
    endpoint: str
    environment: str | None
    capture_content: bool
    flush_interval_ms: int
    flush_batch_size: int
    buffer_max_size: int
    gzip_threshold_bytes: int
    max_retries: int
    shutdown_timeout_s: float
    disable: bool
    agent_id: str | None
    project_id: str | None
    sdk_name: str
    sdk_version: str

    @classmethod
    def from_env_and_args(
        cls,
        *,
        api_key: str | None = None,
        endpoint: str | None = None,
        environment: str | None = None,
        capture_content: bool | None = None,
        flush_interval_ms: int | None = None,
        flush_batch_size: int | None = None,
        buffer_max_size: int | None = None,
        gzip_threshold_bytes: int | None = None,
        max_retries: int | None = None,
        shutdown_timeout_s: float | None = None,
        disable: bool | None = None,
        agent_id: str | None = None,
        project_id: str | None = None,
        sdk_version: str = "0.0.0",
    ) -> Config:
        """Resolve config: explicit args override env, env overrides defaults."""
        return cls(
            api_key=api_key if api_key is not None else os.environ.get("AGENTOS_API_KEY"),
            endpoint=(
                endpoint
                if endpoint is not None
                else os.environ.get("AGENTOS_ENDPOINT", DEFAULT_ENDPOINT)
            ),
            environment=(environment if environment is not None else os.environ.get("AGENTOS_ENV")),
            capture_content=capture_content if capture_content is not None else True,
            flush_interval_ms=(
                flush_interval_ms if flush_interval_ms is not None else DEFAULT_FLUSH_INTERVAL_MS
            ),
            flush_batch_size=(
                flush_batch_size if flush_batch_size is not None else DEFAULT_FLUSH_BATCH_SIZE
            ),
            buffer_max_size=(
                buffer_max_size if buffer_max_size is not None else DEFAULT_BUFFER_MAX_SIZE
            ),
            gzip_threshold_bytes=(
                gzip_threshold_bytes
                if gzip_threshold_bytes is not None
                else DEFAULT_GZIP_THRESHOLD_BYTES
            ),
            max_retries=max_retries if max_retries is not None else DEFAULT_MAX_RETRIES,
            shutdown_timeout_s=(
                shutdown_timeout_s if shutdown_timeout_s is not None else DEFAULT_SHUTDOWN_TIMEOUT_S
            ),
            disable=(
                disable if disable is not None else _env_truthy(os.environ.get("AGENTOS_DISABLE"))
            ),
            agent_id=agent_id if agent_id is not None else os.environ.get("AGENTOS_AGENT_ID"),
            project_id=(
                project_id if project_id is not None else os.environ.get("AGENTOS_PROJECT_ID")
            ),
            sdk_name=DEFAULT_SDK_NAME,
            sdk_version=sdk_version,
        )
