"""Redactor pipeline + PII detection.

Per ``docs/spec/05-sdk-contract.md`` "Privacy and content capture":

- ``add_redactor(callable)`` registers a deterministic, fast redactor
  function. Each redactor receives the event payload dict and returns
  a (possibly modified) dict. If a redactor raises, the SDK logs WARN
  and skips it — the event still flows.
- The SDK detects common PII patterns in ``user_id`` (email regex,
  E.164 phone) and emits a one-time WARN per ``user_id``. It does
  not block; pseudonymization is the developer's responsibility.
"""

from __future__ import annotations

import re
import threading
from collections.abc import Callable
from typing import Any

from ._logger import get_logger

_log = get_logger("redact")

# Email: very loose pattern — we're trying to spot accidental PII, not
# RFC 5322. E.164 phone: optional ``+`` then 6-15 digits.
_EMAIL_RE = re.compile(r"^[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}$")
_E164_RE = re.compile(r"^\+?\d{6,15}$")

Redactor = Callable[[dict[str, Any]], dict[str, Any]]


class RedactorPipeline:
    """Owns the redactor chain and the per-session PII warning set."""

    def __init__(self) -> None:
        self._redactors: list[Redactor] = []
        self._pii_warned: set[str] = set()
        self._lock = threading.Lock()

    def add(self, fn: Redactor) -> None:
        """Append a redactor. Order is registration order."""
        with self._lock:
            self._redactors.append(fn)

    def reset(self) -> None:
        """Drop all redactors and the PII warning set. Used after fork."""
        with self._lock:
            self._redactors.clear()
            self._pii_warned.clear()

    def apply(self, event_dict: dict[str, Any]) -> dict[str, Any]:
        """Run each redactor in order. Never raises."""
        with self._lock:
            redactors = list(self._redactors)
        current = event_dict
        for fn in redactors:
            try:
                result = fn(current)
            except Exception:
                _log.warning(
                    "redactor %s raised; sending unredacted",
                    getattr(fn, "__name__", repr(fn)),
                    exc_info=True,
                )
                continue
            if isinstance(result, dict):
                current = result
        return current

    def maybe_warn_pii(self, user_id: str | None) -> None:
        """Emit a one-time WARN per ``user_id`` if it looks like PII."""
        if not user_id:
            return
        if not (_EMAIL_RE.match(user_id) or _E164_RE.match(user_id)):
            return
        with self._lock:
            if user_id in self._pii_warned:
                return
            self._pii_warned.add(user_id)
        _log.warning(
            "user_id %r appears to be PII (email or E.164 phone). "
            "Consider pseudonymizing before passing to the SDK. "
            "Future events with this id will not trigger this warning.",
            user_id,
        )


def looks_like_pii(value: str | None) -> bool:
    """Public test helper: True if ``value`` matches an email or E.164 phone."""
    if not value:
        return False
    return bool(_EMAIL_RE.match(value) or _E164_RE.match(value))
