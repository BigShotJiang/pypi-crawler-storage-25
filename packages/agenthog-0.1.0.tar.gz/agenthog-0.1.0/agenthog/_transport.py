"""Async buffered HTTP transport.

Per ``docs/spec/05-sdk-contract.md`` "Network behavior" + "Failure
modes" sections:

- In-memory deque buffer with ``buffer_max_size`` (default 10000).
- Flushes on size, interval, explicit ``flush()``, shutdown.
- POSTs to ``{endpoint}/v1/events/batch`` with ``X-API-Key`` and
  ``Idempotency-Key`` headers per ``docs/spec/60-api-conventions.md``.
- Gzip compresses bodies > 4 KB (configurable).
- Exponential backoff retries with full jitter, max 5 attempts;
  honors server ``Retry-After`` on 429.
- Buffer overflow drops oldest, increments ``events_dropped``,
  rate-limits the warning log to once per minute.
- Same ``event_id`` (UUIDv7) preserved across retries for server-side
  dedupe.
- Schema validation failure: log WARN, drop, increment
  ``events_validation_failed``, never raise.
"""

from __future__ import annotations

import asyncio
import contextlib
import gzip
import json
import random
import time
from collections import deque
from datetime import datetime, timezone
from typing import Any
from uuid import UUID

import httpx
from pydantic import ValidationError

from ._config import Config
from ._events import SDKEvent
from ._ids import uuid7
from ._logger import get_logger
from ._metrics import Metrics

_log = get_logger("transport")

_DROP_WARN_INTERVAL_S = 60.0


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _json_default(obj: Any) -> Any:
    if isinstance(obj, UUID):
        return str(obj)
    if isinstance(obj, datetime):
        return obj.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
    raise TypeError(f"unserializable: {type(obj).__name__}")


class Transport:
    """Async buffered HTTP transport. One per Client."""

    def __init__(
        self,
        config: Config,
        metrics: Metrics,
        *,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        self._config = config
        self._metrics = metrics
        # Deque is thread-safe for append / popleft (CPython GIL); we
        # also coordinate snapshots via a lock.
        self._buffer: deque[dict[str, Any]] = deque()
        self._lock = asyncio.Lock()
        self._wake = asyncio.Event()
        self._http = http_client or httpx.AsyncClient(timeout=10.0)
        self._owns_http = http_client is None
        self._closed = False
        self._flush_task: asyncio.Task[None] | None = None
        self._last_drop_warn_at = 0.0

    @property
    def http_client(self) -> httpx.AsyncClient:
        """Shared httpx client. Other layers (flags, routing) reuse it."""
        return self._http

    # ---- Lifecycle --------------------------------------------------------

    def start(self) -> None:
        """Start the periodic-flush task. Call from inside a running loop."""
        if self._flush_task is None or self._flush_task.done():
            self._flush_task = asyncio.create_task(self._flush_loop())

    async def aclose(self) -> None:
        """Flush remaining events with a timeout and close the HTTP client."""
        self._closed = True
        self._wake.set()
        if self._flush_task is not None:
            try:
                await asyncio.wait_for(self._flush_task, timeout=self._config.shutdown_timeout_s)
            except asyncio.TimeoutError:
                _log.warning("flush task did not exit before shutdown timeout")
                self._flush_task.cancel()
        try:
            await asyncio.wait_for(self._drain(), timeout=self._config.shutdown_timeout_s)
        except asyncio.TimeoutError:
            _log.warning("drain did not complete before shutdown timeout")
        if self._owns_http:
            await self._http.aclose()

    def reset_after_fork(self) -> None:
        """Reset state after ``os.fork``. Buffer + tasks belong to the parent."""
        self._buffer.clear()
        self._closed = False
        self._flush_task = None
        self._wake = asyncio.Event()
        self._lock = asyncio.Lock()
        self._last_drop_warn_at = 0.0
        self._metrics.reset()
        # Don't reuse the parent's connection pool — create fresh.
        if self._owns_http:
            self._http = httpx.AsyncClient(timeout=10.0)

    # ---- Public surface ---------------------------------------------------

    def enqueue(self, event_dict: dict[str, Any]) -> bool:
        """Validate locally and enqueue an event. Returns True if buffered.

        Validation failures: log WARN, drop, increment counter, return False.
        Buffer overflow: drop oldest, increment counter, log WARN at most
        once per minute, still buffer this event, return True.
        """
        if self._config.disable:
            return False
        try:
            SDKEvent.model_validate(event_dict)
        except ValidationError as e:
            self._metrics.incr("events_validation_failed")
            _log.warning("schema validation failed; dropping event: %s", e.errors())
            return False

        if len(self._buffer) >= self._config.buffer_max_size:
            with contextlib.suppress(IndexError):
                self._buffer.popleft()
            self._metrics.incr("events_dropped")
            now = time.monotonic()
            if now - self._last_drop_warn_at > _DROP_WARN_INTERVAL_S:
                self._last_drop_warn_at = now
                _log.warning(
                    "buffer full (max=%d); dropping oldest events",
                    self._config.buffer_max_size,
                )
        self._buffer.append(event_dict)
        if len(self._buffer) >= self._config.flush_batch_size:
            self._wake.set()
        return True

    async def flush(self) -> None:
        """Drain the buffer to the network. Used by ``Client.shutdown``."""
        if self._config.disable:
            return
        await self._drain()

    # ---- Internals --------------------------------------------------------

    async def _flush_loop(self) -> None:
        interval_s = self._config.flush_interval_ms / 1000.0
        while not self._closed:
            with contextlib.suppress(asyncio.TimeoutError):
                await asyncio.wait_for(self._wake.wait(), timeout=interval_s)
            self._wake.clear()
            try:
                await self._drain()
            except Exception:
                _log.warning("flush loop iteration failed", exc_info=True)

    async def _drain(self) -> None:
        async with self._lock:
            while self._buffer:
                batch: list[dict[str, Any]] = []
                while self._buffer and len(batch) < self._config.flush_batch_size:
                    batch.append(self._buffer.popleft())
                if not batch:
                    return
                await self._send_with_retry(batch)

    async def _send_with_retry(self, batch: list[dict[str, Any]]) -> None:
        body = json.dumps({"events": batch}, default=_json_default).encode("utf-8")
        headers: dict[str, str] = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if self._config.api_key:
            headers["X-API-Key"] = self._config.api_key
        # Server uses event_id for natural dedupe, but per
        # docs/spec/60-api-conventions.md non-idempotent POSTs may also
        # carry a per-batch Idempotency-Key. Same key across retries.
        headers["Idempotency-Key"] = str(uuid7())
        if len(body) > self._config.gzip_threshold_bytes:
            body = gzip.compress(body)
            headers["Content-Encoding"] = "gzip"

        url = f"{self._config.endpoint.rstrip('/')}/v1/events/batch"
        attempts = self._config.max_retries

        for attempt in range(1, attempts + 1):
            try:
                resp = await self._http.post(url, content=body, headers=headers)
            except (httpx.RequestError, asyncio.TimeoutError) as e:
                if attempt >= attempts:
                    self._metrics.incr("events_failed_permanent", len(batch))
                    _log.warning("batch send failed permanently: %s", e)
                    return
                self._metrics.incr("events_retried")
                await asyncio.sleep(self._compute_backoff(attempt))
                continue
            except Exception:
                _log.warning("unexpected transport error", exc_info=True)
                self._metrics.incr("events_failed_permanent", len(batch))
                return

            if 200 <= resp.status_code < 300:
                self._metrics.incr("events_sent", len(batch))
                return
            if resp.status_code in (429, 502, 503, 504) or 500 <= resp.status_code < 600:
                if attempt >= attempts:
                    self._metrics.incr("events_failed_permanent", len(batch))
                    _log.warning("batch send failed permanently with status %d", resp.status_code)
                    return
                retry_after = self._parse_retry_after(resp)
                self._metrics.incr("events_retried")
                await asyncio.sleep(
                    retry_after if retry_after is not None else self._compute_backoff(attempt)
                )
                continue
            # 4xx (other than 429) — non-retryable.
            self._metrics.incr("events_failed_permanent", len(batch))
            _log.warning(
                "batch rejected non-retryably with status %d: %s",
                resp.status_code,
                resp.text[:512],
            )
            return

    def _compute_backoff(self, attempt: int) -> float:
        # 100ms * 2^(attempt-1) * uniform(0.5, 1.5).
        base = 0.1 * float(2 ** (attempt - 1))
        jitter: float = random.uniform(0.5, 1.5)  # noqa: S311 — jitter, not crypto.
        return float(base * jitter)

    def _parse_retry_after(self, resp: httpx.Response) -> float | None:
        value = resp.headers.get("Retry-After")
        if not value:
            return None
        try:
            return float(value)
        except ValueError:
            return None
