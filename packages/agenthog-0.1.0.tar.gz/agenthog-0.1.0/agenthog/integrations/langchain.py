"""LangChain auto-instrumentation.

Per ``docs/spec/05-sdk-contract.md`` "Auto-instrumentation" section.

Implements :class:`AgentOSCallbackHandler` against
``langchain_core.callbacks.BaseCallbackHandler``. Each ``run_id``
accumulates state in a per-run buffer (the LangChain callback API is
streaming-friendly: ``on_llm_new_token`` fires per token but
:class:`AgentOSCallbackHandler` only emits **one** ``agent.llm_call``
event per run when ``on_*_end`` (or ``on_*_error``) fires).

``install()`` registers the handler globally via the modern
``register_configure_hook`` API (``set_global_handler`` was removed in
langchain_core 1.x); ``uninstall()`` clears it. The same handler can
also be passed explicitly via ``invoke(callbacks=[...])`` for callers
who prefer not to register a global.
"""

from __future__ import annotations

import threading
from contextvars import ContextVar, Token
from typing import Any
from uuid import UUID

from .._client import AsyncClient, Client
from .._ids import monotonic_now
from .._logger import get_logger
from . import _common

_log = get_logger("integrations.langchain")

# Map LangChain message types to OpenAI-style roles per docs/spec/03.
_ROLE_MAP = {
    "human": "user",
    "ai": "assistant",
    "system": "system",
    "tool": "tool",
    "function": "tool",
    "chat": "assistant",
}


class _RunState:
    """Accumulated state for a single LangChain run."""

    __slots__ = (
        "capture_content",
        "kind",
        "props",
        "start",
        "tokens",
    )

    def __init__(self, kind: str, props: dict[str, Any], capture_content: bool) -> None:
        self.kind = kind  # "llm" | "tool" | "chain"
        self.props = props
        self.start = monotonic_now()
        self.tokens: list[str] = []
        self.capture_content = capture_content


class AgentOSCallbackHandler:
    """Translate LangChain callbacks into ``agent.*`` events.

    Inherits from ``langchain_core.callbacks.BaseCallbackHandler`` at
    install time (the import is lazy so ``import agenthog`` doesn't
    require LangChain to be installed).
    """

    def __init__(self, client: Client | AsyncClient | None) -> None:
        self._client = client
        self._runs: dict[UUID, _RunState] = {}
        self._lock = threading.Lock()

    def _capture(self) -> bool:
        return _common.capture_content_for(self._client)

    def _put(self, run_id: UUID, state: _RunState) -> None:
        with self._lock:
            self._runs[run_id] = state

    def _pop(self, run_id: UUID) -> _RunState | None:
        with self._lock:
            return self._runs.pop(run_id, None)

    def _peek(self, run_id: UUID) -> _RunState | None:
        with self._lock:
            return self._runs.get(run_id)

    # ---- LLM callbacks ----------------------------------------------------

    def on_chat_model_start(
        self,
        serialized: dict[str, Any],
        messages: list[list[Any]],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        del parent_run_id, tags  # not yet wired into emitted events
        try:
            props = self._build_llm_request_props(serialized, kwargs, metadata)
            if self._capture() and messages:
                # ``messages`` is list[list[BaseMessage]] — flatten the first prompt batch.
                first_batch = messages[0]
                props["input"] = [_normalize_lc_message(m) for m in first_batch]
            self._put(run_id, _RunState("llm", props, self._capture()))
        except Exception:
            _log.warning("on_chat_model_start failed", exc_info=True)

    def on_llm_start(
        self,
        serialized: dict[str, Any],
        prompts: list[str],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        del parent_run_id, tags
        try:
            props = self._build_llm_request_props(serialized, kwargs, metadata)
            if self._capture() and prompts:
                props["input"] = [{"role": "user", "content": p} for p in prompts]
            self._put(run_id, _RunState("llm", props, self._capture()))
        except Exception:
            _log.warning("on_llm_start failed", exc_info=True)

    def on_llm_new_token(
        self,
        token: str,
        *,
        chunk: Any = None,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        **kwargs: Any,
    ) -> None:
        del chunk, parent_run_id, tags, kwargs
        state = self._peek(run_id)
        if state is None:
            return
        if token:
            state.tokens.append(token)

    def on_llm_end(
        self,
        response: Any,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        **kwargs: Any,
    ) -> None:
        del parent_run_id, tags, kwargs
        state = self._pop(run_id)
        if state is None:
            return
        try:
            props = state.props
            props["duration_ms"] = _common.elapsed_ms(state.start)
            self._absorb_llm_result(props, response, state)
            _common.emit_sync(self._client, "agent.llm_call", props)
        except Exception:
            _log.warning("on_llm_end failed", exc_info=True)

    def on_llm_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        **kwargs: Any,
    ) -> None:
        del parent_run_id, tags, kwargs
        state = self._pop(run_id)
        if state is None:
            return
        try:
            props = state.props
            props["duration_ms"] = _common.elapsed_ms(state.start)
            props["error"] = _common.error_info(error)
            if state.capture_content and state.tokens:
                props["output"] = [{"role": "assistant", "content": "".join(state.tokens)}]
            _common.emit_sync(self._client, "agent.llm_call", props)
        except Exception:
            _log.warning("on_llm_error failed", exc_info=True)

    # ---- Tool callbacks ---------------------------------------------------

    def on_tool_start(
        self,
        serialized: dict[str, Any],
        input_str: str,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        inputs: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        del parent_run_id, tags, metadata, kwargs
        try:
            name = (serialized or {}).get("name") or "tool"
            props: dict[str, Any] = {"tool.name": str(name)}
            if self._capture():
                # Prefer structured ``inputs`` when LangChain passed them.
                props["tool.input"] = inputs if inputs is not None else input_str
            self._put(run_id, _RunState("tool", props, self._capture()))
        except Exception:
            _log.warning("on_tool_start failed", exc_info=True)

    def on_tool_end(
        self,
        output: Any,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        del parent_run_id, kwargs
        state = self._pop(run_id)
        if state is None:
            return
        try:
            props = state.props
            props["duration_ms"] = _common.elapsed_ms(state.start)
            props["tool.status"] = "success"
            if state.capture_content:
                props["tool.output"] = (
                    output if isinstance(output, (str, dict, list)) else str(output)
                )
            _common.emit_sync(self._client, "agent.tool_call", props)
        except Exception:
            _log.warning("on_tool_end failed", exc_info=True)

    def on_tool_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        del parent_run_id, kwargs
        state = self._pop(run_id)
        if state is None:
            return
        try:
            props = state.props
            props["duration_ms"] = _common.elapsed_ms(state.start)
            props["tool.status"] = "error"
            props["error"] = _common.error_info(error)
            _common.emit_sync(self._client, "agent.tool_call", props)
        except Exception:
            _log.warning("on_tool_error failed", exc_info=True)

    # ---- Chain callbacks --------------------------------------------------

    def on_chain_start(
        self,
        serialized: dict[str, Any],
        inputs: dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        # Chains are spans, not standalone events in v1 — track for
        # context but don't emit (per spec: "chains are roughly
        # task_runs at the top level, sub-spans below"). We keep the
        # run in our table so on_chain_error can still see it.
        del serialized, inputs, parent_run_id, tags, metadata, kwargs
        try:
            self._put(run_id, _RunState("chain", {}, self._capture()))
        except Exception:
            _log.warning("on_chain_start failed", exc_info=True)

    def on_chain_end(
        self,
        outputs: dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        del outputs, parent_run_id, kwargs
        self._pop(run_id)

    def on_chain_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        del parent_run_id, kwargs
        self._pop(run_id)
        # Don't emit a top-level chain failure event — the underlying
        # llm/tool callback that raised will already have emitted a
        # well-formed event with ``error``. Emitting a second one here
        # would double-count and we don't have a chain event type in v1.

    # ---- Agent callbacks --------------------------------------------------

    def on_agent_action(
        self,
        action: Any,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        del run_id, parent_run_id, kwargs
        try:
            target = getattr(action, "tool", None) or "unknown"
            props: dict[str, Any] = {"target_agent_id": str(target)}
            log_text = getattr(action, "log", None)
            if log_text and self._capture():
                props["reason"] = str(log_text)[:4000]
            _common.emit_sync(self._client, "agent.handoff", props)
        except Exception:
            _log.warning("on_agent_action failed", exc_info=True)

    def on_agent_finish(
        self,
        finish: Any,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        # Terminal — no event in v1; the trailing on_chain_end closes the run.
        del finish, run_id, parent_run_id, kwargs

    # ---- Shaping helpers --------------------------------------------------

    def _build_llm_request_props(
        self,
        serialized: dict[str, Any],
        kwargs: dict[str, Any],
        metadata: dict[str, Any] | None,
    ) -> dict[str, Any]:
        kwargs_inv = kwargs.get("invocation_params") or {}
        meta = metadata or {}
        provider = (
            kwargs_inv.get("_type")
            or meta.get("ls_provider")
            or _provider_from_serialized(serialized)
            or "langchain"
        )
        model = (
            kwargs_inv.get("model")
            or kwargs_inv.get("model_name")
            or meta.get("ls_model_name")
            or _model_from_serialized(serialized)
            or "unknown"
        )
        props: dict[str, Any] = {
            "gen_ai.system": str(provider),
            "gen_ai.request.model": str(model),
        }
        for src, dst in (
            ("temperature", "gen_ai.request.temperature"),
            ("top_p", "gen_ai.request.top_p"),
            ("max_tokens", "gen_ai.request.max_tokens"),
        ):
            if kwargs_inv.get(src) is not None:
                props[dst] = kwargs_inv[src]
        return props

    def _absorb_llm_result(
        self,
        props: dict[str, Any],
        response: Any,
        state: _RunState,
    ) -> None:
        # Token usage from LLMResult.llm_output['token_usage']/usage.
        llm_output = getattr(response, "llm_output", None) or {}
        usage = llm_output.get("token_usage") or llm_output.get("usage") or {}
        input_tokens = usage.get("prompt_tokens") or usage.get("input_tokens")
        output_tokens = usage.get("completion_tokens") or usage.get("output_tokens")
        total_tokens = usage.get("total_tokens")
        if input_tokens is not None:
            props["gen_ai.usage.input_tokens"] = input_tokens
        if output_tokens is not None:
            props["gen_ai.usage.output_tokens"] = output_tokens
        if total_tokens is not None:
            props["gen_ai.usage.total_tokens"] = total_tokens
        elif input_tokens is not None and output_tokens is not None:
            props["gen_ai.usage.total_tokens"] = input_tokens + output_tokens

        finish_reason = _extract_finish_reason(response)
        if finish_reason:
            props["gen_ai.response.finish_reason"] = finish_reason

        if not state.capture_content:
            return
        # Prefer the parsed generations; fall back to accumulated tokens.
        output_messages = _extract_output_messages(response)
        if output_messages is not None:
            props["output"] = output_messages
        elif state.tokens:
            props["output"] = [{"role": "assistant", "content": "".join(state.tokens)}]


# ---- Module-level helpers --------------------------------------------------


def _normalize_lc_message(m: Any) -> dict[str, Any]:
    """Convert a LangChain ``BaseMessage`` to the LLMMessage shape."""
    msg_type_raw = getattr(m, "type", None)
    msg_type = str(msg_type_raw) if msg_type_raw is not None else "user"
    role = _ROLE_MAP.get(msg_type, msg_type)
    content = getattr(m, "content", None)
    out: dict[str, Any] = {"role": role, "content": content}
    tool_calls = getattr(m, "tool_calls", None)
    if tool_calls:
        out["tool_calls"] = list(tool_calls)
    return out


def _provider_from_serialized(serialized: dict[str, Any]) -> str | None:
    if not serialized:
        return None
    ids = serialized.get("id") or []
    if isinstance(ids, list):
        for hint in ("openai", "anthropic", "ollama", "google", "vertex", "bedrock"):
            if any(hint in str(part).lower() for part in ids):
                return hint
    return None


def _model_from_serialized(serialized: dict[str, Any]) -> str | None:
    if not serialized:
        return None
    kwargs = serialized.get("kwargs") or {}
    return kwargs.get("model") or kwargs.get("model_name")


def _extract_finish_reason(response: Any) -> str | None:
    generations = getattr(response, "generations", None) or []
    if not generations:
        return None
    first_batch = generations[0] if generations else []
    if not first_batch:
        return None
    first = first_batch[0]
    info = getattr(first, "generation_info", None) or {}
    finish = info.get("finish_reason")
    if finish:
        return str(finish)
    message = getattr(first, "message", None)
    if message is not None:
        meta = getattr(message, "response_metadata", None) or {}
        finish = meta.get("finish_reason") or meta.get("stop_reason")
        if finish:
            return str(finish)
    return None


def _extract_output_messages(response: Any) -> list[dict[str, Any]] | None:
    generations = getattr(response, "generations", None) or []
    if not generations:
        return None
    out: list[dict[str, Any]] = []
    for batch in generations:
        for gen in batch:
            message = getattr(gen, "message", None)
            if message is not None:
                out.append(_normalize_lc_message(message))
            else:
                text = getattr(gen, "text", None)
                if text is not None:
                    out.append({"role": "assistant", "content": text})
    return out or None


# ---- install / uninstall ---------------------------------------------------

_state: dict[str, Any] = {}
_handler_var: ContextVar[Any | None] = ContextVar("agentos_lc_handler", default=None)
_token: Token[Any] | None = None


def install(client: Client | AsyncClient | None = None) -> AgentOSCallbackHandler | None:
    """Register the AgentOS LangChain handler globally.

    Returns the installed handler so callers can also pass it explicitly
    via ``chain.invoke(callbacks=[handler])`` if desired. Idempotent.
    """
    global _token
    existing = _state.get("handler")
    if isinstance(existing, AgentOSCallbackHandler):
        return existing

    try:
        from langchain_core.callbacks import BaseCallbackHandler
        from langchain_core.tracers.context import register_configure_hook
    except Exception:  # pragma: no cover — depends on env
        _log.warning("langchain_core not installed; skipping integration")
        return None

    resolved = _common.resolve_client(client)
    if resolved is None:
        _log.warning("no agentos client available; skipping langchain integration")
        return None

    # Build a real subclass of BaseCallbackHandler at install time so we
    # don't import langchain_core at module load.
    handler_cls = type(
        "AgentOSCallbackHandler",
        (AgentOSCallbackHandler, BaseCallbackHandler),
        {},
    )
    handler = handler_cls(resolved)

    if not _state.get("hook_registered"):
        register_configure_hook(_handler_var, inheritable=True)
        _state["hook_registered"] = True

    _token = _handler_var.set(handler)
    _state["handler"] = handler
    _state["client"] = resolved
    return handler if isinstance(handler, AgentOSCallbackHandler) else None


def uninstall() -> None:
    """Clear the registered handler. Idempotent."""
    global _token
    if not _state:
        return
    if _token is not None:
        try:
            _handler_var.reset(_token)
        except (LookupError, ValueError):  # pragma: no cover — already reset
            _handler_var.set(None)
        _token = None
    else:
        _handler_var.set(None)
    _state.pop("handler", None)
    _state.pop("client", None)
    # Keep ``hook_registered`` — register_configure_hook has no
    # documented unregister path, and a re-install would just register
    # the same ContextVar again.
