"""Anthropic auto-instrumentation.

Per ``docs/spec/05-sdk-contract.md`` "Auto-instrumentation" section.

Patches ``anthropic.resources.messages.Messages.create`` and
``AsyncMessages.create`` (both non-streaming and ``stream=True``) plus
``Messages.stream`` and ``AsyncMessages.stream`` (the high-level
context-manager streaming helper). Sets ``gen_ai.system="anthropic"``.

Anthropic's streaming surfaces usage in the ``message_delta`` event
near the end of the stream — the aggregator consumes it correctly.
"""

from __future__ import annotations

import functools
from collections.abc import AsyncIterator, Callable, Iterator
from typing import Any

from .._client import AsyncClient, Client
from .._ids import monotonic_now
from .._logger import get_logger
from . import _common

_log = get_logger("integrations.anthropic")

_state: dict[str, Any] = {}


def install(client: Client | AsyncClient | None = None) -> None:
    if _state:
        _log.debug("anthropic integration already installed; skipping")
        return
    try:
        from anthropic.resources.messages import AsyncMessages, Messages
    except Exception:  # pragma: no cover
        _log.warning("anthropic not installed; skipping integration")
        return

    resolved = _common.resolve_client(client)
    if resolved is None:
        _log.warning("no agentos client available; skipping anthropic integration")
        return

    _state["client"] = resolved
    _state["sync_create"] = Messages.create
    _state["async_create"] = AsyncMessages.create
    _state["sync_stream"] = Messages.stream
    _state["async_stream"] = AsyncMessages.stream

    Messages.create = _wrap_sync_create(Messages.create)  # type: ignore[method-assign]
    AsyncMessages.create = _wrap_async_create(AsyncMessages.create)  # type: ignore[method-assign]
    Messages.stream = _wrap_sync_stream(Messages.stream)  # type: ignore[method-assign]
    AsyncMessages.stream = _wrap_async_stream(AsyncMessages.stream)  # type: ignore[method-assign]


def uninstall() -> None:
    if not _state:
        return
    try:
        from anthropic.resources.messages import AsyncMessages, Messages

        Messages.create = _state["sync_create"]  # type: ignore[method-assign]
        AsyncMessages.create = _state["async_create"]  # type: ignore[method-assign]
        Messages.stream = _state["sync_stream"]  # type: ignore[method-assign]
        AsyncMessages.stream = _state["async_stream"]  # type: ignore[method-assign]
    except Exception:  # pragma: no cover
        _log.warning("anthropic uninstall failed to restore originals", exc_info=True)
    _state.clear()


# ---- Request / response shaping --------------------------------------------


def _build_request_props(kwargs: dict[str, Any], capture_content: bool) -> dict[str, Any]:
    props: dict[str, Any] = {
        "gen_ai.system": "anthropic",
        "gen_ai.request.model": kwargs.get("model") or "unknown",
    }
    if kwargs.get("temperature") is not None:
        props["gen_ai.request.temperature"] = kwargs["temperature"]
    if kwargs.get("top_p") is not None:
        props["gen_ai.request.top_p"] = kwargs["top_p"]
    if kwargs.get("max_tokens") is not None:
        props["gen_ai.request.max_tokens"] = kwargs["max_tokens"]
    if kwargs.get("stream"):
        props["stream"] = True
    if capture_content and kwargs.get("messages"):
        props["input"] = [_common.normalize_message(m) for m in kwargs["messages"]]
    return props


def _absorb_message(props: dict[str, Any], message: Any, capture_content: bool) -> None:
    msg_id = getattr(message, "id", None)
    if msg_id:
        props["gen_ai.response.id"] = msg_id
    msg_model = getattr(message, "model", None)
    if msg_model and msg_model != props.get("gen_ai.request.model"):
        props["gen_ai.response.model"] = msg_model
    stop_reason = getattr(message, "stop_reason", None)
    if stop_reason:
        props["gen_ai.response.finish_reason"] = stop_reason

    usage = getattr(message, "usage", None)
    if usage is not None:
        input_tokens = getattr(usage, "input_tokens", None)
        output_tokens = getattr(usage, "output_tokens", None)
        if input_tokens is not None:
            props["gen_ai.usage.input_tokens"] = input_tokens
        if output_tokens is not None:
            props["gen_ai.usage.output_tokens"] = output_tokens
        if input_tokens is not None and output_tokens is not None:
            props["gen_ai.usage.total_tokens"] = input_tokens + output_tokens

    if capture_content:
        content = getattr(message, "content", None) or []
        rendered = _render_content_blocks(content)
        props["output"] = [{"role": "assistant", "content": rendered}]


def _render_content_blocks(blocks: list[Any]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for block in blocks:
        if hasattr(block, "model_dump"):
            out.append(block.model_dump())
        elif isinstance(block, dict):
            out.append(block)
        else:
            out.append({"type": "raw", "value": repr(block)})
    return out


# ---- create() wrappers -----------------------------------------------------


def _wrap_sync_create(original: Callable[..., Any]) -> Callable[..., Any]:
    @functools.wraps(original)
    def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
        client = _state.get("client")
        capture = _common.capture_content_for(client)
        request_props = _build_request_props(kwargs, capture)
        start = monotonic_now()
        try:
            result = original(self, *args, **kwargs)
        except BaseException as exc:
            request_props["duration_ms"] = _common.elapsed_ms(start)
            request_props["error"] = _common.error_info(exc)
            _common.emit_sync(client, "agent.llm_call", request_props)
            raise
        if kwargs.get("stream"):
            return _SyncEventStreamWrapper(result, request_props, start, capture, client)
        request_props["duration_ms"] = _common.elapsed_ms(start)
        _absorb_message(request_props, result, capture)
        _common.emit_sync(client, "agent.llm_call", request_props)
        return result

    return wrapper


def _wrap_async_create(original: Callable[..., Any]) -> Callable[..., Any]:
    @functools.wraps(original)
    async def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
        client = _state.get("client")
        capture = _common.capture_content_for(client)
        request_props = _build_request_props(kwargs, capture)
        start = monotonic_now()
        try:
            result = await original(self, *args, **kwargs)
        except BaseException as exc:
            request_props["duration_ms"] = _common.elapsed_ms(start)
            request_props["error"] = _common.error_info(exc)
            await _common.emit_async(client, "agent.llm_call", request_props)
            raise
        if kwargs.get("stream"):
            return _AsyncEventStreamWrapper(result, request_props, start, capture, client)
        request_props["duration_ms"] = _common.elapsed_ms(start)
        _absorb_message(request_props, result, capture)
        await _common.emit_async(client, "agent.llm_call", request_props)
        return result

    return wrapper


# ---- stream() context-manager wrappers -------------------------------------


def _wrap_sync_stream(original: Callable[..., Any]) -> Callable[..., Any]:
    @functools.wraps(original)
    def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
        client = _state.get("client")
        capture = _common.capture_content_for(client)
        manager = original(self, *args, **kwargs)
        return _SyncStreamManagerWrapper(manager, kwargs, capture, client)

    return wrapper


def _wrap_async_stream(original: Callable[..., Any]) -> Callable[..., Any]:
    @functools.wraps(original)
    def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
        client = _state.get("client")
        capture = _common.capture_content_for(client)
        manager = original(self, *args, **kwargs)
        return _AsyncStreamManagerWrapper(manager, kwargs, capture, client)

    return wrapper


# ---- Streaming aggregation -------------------------------------------------


class _AnthropicEventAggregator:
    """Aggregates Anthropic stream events into a single agent.llm_call event."""

    def __init__(
        self,
        props: dict[str, Any],
        start: float,
        capture_content: bool,
        client: Client | AsyncClient | None,
    ) -> None:
        self._props = props
        self._start = start
        self._capture = capture_content
        self._client = client
        self._content_parts: list[str] = []
        self._tool_use_blocks: dict[int, dict[str, Any]] = {}
        self._partial_json: dict[int, list[str]] = {}
        self._final_stop_reason: str | None = None
        self._emitted = False

    def absorb(self, event: Any) -> None:
        event_type = getattr(event, "type", None)
        if event_type == "message_start":
            message = getattr(event, "message", None)
            if message is not None:
                msg_id = getattr(message, "id", None)
                if msg_id:
                    self._props["gen_ai.response.id"] = msg_id
                msg_model = getattr(message, "model", None)
                if msg_model and msg_model != self._props.get("gen_ai.request.model"):
                    self._props["gen_ai.response.model"] = msg_model
                usage = getattr(message, "usage", None)
                if usage is not None:
                    input_tokens = getattr(usage, "input_tokens", None)
                    if input_tokens is not None:
                        self._props["gen_ai.usage.input_tokens"] = input_tokens
        elif event_type == "content_block_start":
            block = getattr(event, "content_block", None)
            index = getattr(event, "index", None)
            if (
                block is not None
                and isinstance(index, int)
                and getattr(block, "type", None) == "tool_use"
            ):
                self._tool_use_blocks[index] = {
                    "type": "tool_use",
                    "id": getattr(block, "id", None),
                    "name": getattr(block, "name", None),
                    "input": "",
                }
        elif event_type == "content_block_delta":
            delta = getattr(event, "delta", None)
            index = getattr(event, "index", None)
            if delta is None:
                return
            delta_type = getattr(delta, "type", None)
            if delta_type == "text_delta":
                text = getattr(delta, "text", "")
                if text:
                    self._content_parts.append(text)
            elif delta_type == "input_json_delta" and isinstance(index, int):
                partial = getattr(delta, "partial_json", "")
                if partial:
                    self._partial_json.setdefault(index, []).append(partial)
        elif event_type == "content_block_stop":
            index = getattr(event, "index", None)
            if index in self._tool_use_blocks and index in self._partial_json:
                self._tool_use_blocks[index]["input"] = "".join(self._partial_json.pop(index))
        elif event_type == "message_delta":
            delta = getattr(event, "delta", None)
            if delta is not None:
                stop_reason = getattr(delta, "stop_reason", None)
                if stop_reason:
                    self._final_stop_reason = stop_reason
            usage = getattr(event, "usage", None)
            if usage is not None:
                output_tokens = getattr(usage, "output_tokens", None)
                if output_tokens is not None:
                    self._props["gen_ai.usage.output_tokens"] = output_tokens

    def finalize(self, error: BaseException | None) -> dict[str, Any]:
        self._props["duration_ms"] = _common.elapsed_ms(self._start)
        if self._final_stop_reason:
            self._props["gen_ai.response.finish_reason"] = self._final_stop_reason
        in_tokens = self._props.get("gen_ai.usage.input_tokens")
        out_tokens = self._props.get("gen_ai.usage.output_tokens")
        if in_tokens is not None and out_tokens is not None:
            self._props["gen_ai.usage.total_tokens"] = in_tokens + out_tokens
        if self._capture and (self._content_parts or self._tool_use_blocks):
            blocks: list[dict[str, Any]] = []
            if self._content_parts:
                blocks.append({"type": "text", "text": "".join(self._content_parts)})
            for index in sorted(self._tool_use_blocks):
                blocks.append(self._tool_use_blocks[index])
            self._props["output"] = [{"role": "assistant", "content": blocks}]
        if error is not None:
            self._props["error"] = _common.error_info(error)
        self._emitted = True
        return self._props


class _SyncEventStreamWrapper:
    """Wraps Anthropic sync stream from ``messages.create(stream=True)``."""

    def __init__(
        self,
        underlying: Any,
        props: dict[str, Any],
        start: float,
        capture_content: bool,
        client: Client | AsyncClient | None,
    ) -> None:
        self._under = underlying
        self._agg = _AnthropicEventAggregator(props, start, capture_content, client)
        self._client = client

    def __iter__(self) -> Iterator[Any]:
        return self

    def __next__(self) -> Any:
        try:
            event = next(iter(self._under))
        except StopIteration:
            self._emit(None)
            raise
        except BaseException as exc:
            self._emit(exc)
            raise
        self._agg.absorb(event)
        return event

    def __enter__(self) -> _SyncEventStreamWrapper:
        if hasattr(self._under, "__enter__"):
            self._under.__enter__()
        return self

    def __exit__(self, *args: Any) -> Any:
        if hasattr(self._under, "__exit__"):
            return self._under.__exit__(*args)
        return None

    def __getattr__(self, name: str) -> Any:
        return getattr(self._under, name)

    def _emit(self, error: BaseException | None) -> None:
        if self._agg._emitted:
            return
        props = self._agg.finalize(error)
        _common.emit_sync(self._client, "agent.llm_call", props)


class _AsyncEventStreamWrapper:
    """Wraps Anthropic async stream from ``messages.create(stream=True)``."""

    def __init__(
        self,
        underlying: Any,
        props: dict[str, Any],
        start: float,
        capture_content: bool,
        client: Client | AsyncClient | None,
    ) -> None:
        self._under = underlying
        self._agg = _AnthropicEventAggregator(props, start, capture_content, client)
        self._client = client
        self._iter: AsyncIterator[Any] | None = None

    def __aiter__(self) -> _AsyncEventStreamWrapper:
        return self

    async def __anext__(self) -> Any:
        if self._iter is None:
            self._iter = self._under.__aiter__()
        try:
            event = await self._iter.__anext__()
        except StopAsyncIteration:
            await self._emit(None)
            raise
        except BaseException as exc:
            await self._emit(exc)
            raise
        self._agg.absorb(event)
        return event

    def __getattr__(self, name: str) -> Any:
        return getattr(self._under, name)

    async def _emit(self, error: BaseException | None) -> None:
        if self._agg._emitted:
            return
        props = self._agg.finalize(error)
        await _common.emit_async(self._client, "agent.llm_call", props)


# ---- messages.stream() — context-manager helper ---------------------------


class _SyncStreamManagerWrapper:
    """Wraps Anthropic's ``MessageStreamManager`` (returned by messages.stream)."""

    def __init__(
        self,
        manager: Any,
        kwargs: dict[str, Any],
        capture_content: bool,
        client: Client | AsyncClient | None,
    ) -> None:
        self._manager = manager
        self._kwargs = kwargs
        self._capture = capture_content
        self._client = client
        self._inner: Any = None
        self._agg: _AnthropicEventAggregator | None = None
        self._props: dict[str, Any] | None = None
        self._start: float | None = None

    def __enter__(self) -> Any:
        self._start = monotonic_now()
        self._props = _build_request_props(self._kwargs, self._capture)
        self._props["stream"] = True
        self._inner = self._manager.__enter__()
        self._agg = _AnthropicEventAggregator(self._props, self._start, self._capture, self._client)
        return _MessageStreamProxy(self._inner, self._agg)

    def __exit__(self, exc_type: Any, exc_val: BaseException | None, exc_tb: Any) -> Any:
        try:
            result = self._manager.__exit__(exc_type, exc_val, exc_tb)
        finally:
            if self._agg is not None and not self._agg._emitted:
                props = self._agg.finalize(exc_val)
                _common.emit_sync(self._client, "agent.llm_call", props)
        return result


class _AsyncStreamManagerWrapper:
    def __init__(
        self,
        manager: Any,
        kwargs: dict[str, Any],
        capture_content: bool,
        client: Client | AsyncClient | None,
    ) -> None:
        self._manager = manager
        self._kwargs = kwargs
        self._capture = capture_content
        self._client = client
        self._inner: Any = None
        self._agg: _AnthropicEventAggregator | None = None

    async def __aenter__(self) -> Any:
        start = monotonic_now()
        props = _build_request_props(self._kwargs, self._capture)
        props["stream"] = True
        self._inner = await self._manager.__aenter__()
        self._agg = _AnthropicEventAggregator(props, start, self._capture, self._client)
        return _MessageStreamProxy(self._inner, self._agg, async_=True)

    async def __aexit__(self, exc_type: Any, exc_val: BaseException | None, exc_tb: Any) -> Any:
        try:
            result = await self._manager.__aexit__(exc_type, exc_val, exc_tb)
        finally:
            if self._agg is not None and not self._agg._emitted:
                props = self._agg.finalize(exc_val)
                await _common.emit_async(self._client, "agent.llm_call", props)
        return result


class _MessageStreamProxy:
    """Iterable proxy returned from a wrapped messages.stream context manager.

    Forwards iteration to the underlying ``MessageStream`` while feeding
    each event into the aggregator. Other attributes (``text_stream``,
    ``get_final_message``, etc.) pass through.
    """

    def __init__(
        self,
        inner: Any,
        aggregator: _AnthropicEventAggregator,
        *,
        async_: bool = False,
    ) -> None:
        self._inner = inner
        self._agg = aggregator
        self._async = async_

    def __iter__(self) -> Iterator[Any]:
        return self._sync_gen()

    def _sync_gen(self) -> Iterator[Any]:
        for event in self._inner:
            self._agg.absorb(event)
            yield event

    def __aiter__(self) -> AsyncIterator[Any]:
        return self._async_gen()

    async def _async_gen(self) -> AsyncIterator[Any]:
        async for event in self._inner:
            self._agg.absorb(event)
            yield event

    def __getattr__(self, name: str) -> Any:
        return getattr(self._inner, name)
