"""OpenTelemetry passthrough.

Per ``docs/spec/05-sdk-contract.md`` "Auto-instrumentation":
``install()`` registers an OTel ``SpanExporter`` that translates each
finished span into an ``agent.*`` event. Users keep their existing OTel
instrumentation (e.g., ``opentelemetry-instrumentation-openai-v2``) and
the spans land in AgentHog automatically — no re-instrumentation.

Tee mode: pass ``forward_to=existing_exporter`` so the same span is
also forwarded to the user's collector. AgentOS is a TEE, not a
take-over.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import TYPE_CHECKING, Any

from .._client import AsyncClient, Client
from .._logger import get_logger
from . import _common

if TYPE_CHECKING:
    from opentelemetry.sdk.trace import ReadableSpan
    from opentelemetry.sdk.trace.export import SpanExportResult

_log = get_logger("integrations.opentelemetry")

_state: dict[str, Any] = {}


def install(
    client: Client | AsyncClient | None = None,
    *,
    forward_to: Any | None = None,
    add_to_provider: bool = True,
) -> Any | None:
    """Register an :class:`AgentOSSpanExporter`. Returns the exporter.

    - ``client``: bind a non-default agentos client. Defaults to the
      module-level default from :func:`agentos.init`.
    - ``forward_to``: an existing :class:`SpanExporter` to also receive
      the spans (TEE mode).
    - ``add_to_provider``: if True (default), wraps the exporter in a
      ``BatchSpanProcessor`` and adds it to the global TracerProvider so
      no further user setup is required.
    """
    if "exporter" in _state:
        existing = _state["exporter"]
        return existing

    try:
        from opentelemetry import trace as otel_trace
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import (
            BatchSpanProcessor,
            SimpleSpanProcessor,
        )
    except Exception:  # pragma: no cover
        _log.warning("opentelemetry not installed; skipping integration")
        return None

    resolved = _common.resolve_client(client)
    if resolved is None:
        _log.warning("no agentos client; skipping opentelemetry integration")
        return None

    exporter = _build_exporter(resolved, forward_to)
    _state["exporter"] = exporter
    _state["client"] = resolved
    _state["forward_to"] = forward_to

    if add_to_provider:
        provider = otel_trace.get_tracer_provider()
        if isinstance(provider, TracerProvider):
            processor = BatchSpanProcessor(exporter)
            provider.add_span_processor(processor)
            _state["processor"] = processor
        else:
            # ProxyTracerProvider — install our own provider so the
            # exporter receives spans even when the user hasn't set one
            # up. Rare path; SimpleSpanProcessor for predictability.
            new_provider = TracerProvider()
            new_provider.add_span_processor(SimpleSpanProcessor(exporter))
            otel_trace.set_tracer_provider(new_provider)
            _state["installed_provider"] = new_provider
            _state["processor"] = new_provider

    return exporter


def uninstall() -> None:
    """Remove our processor / exporter where we can. Idempotent."""
    if not _state:
        return
    processor = _state.pop("processor", None)
    if processor is not None:
        try:
            processor.shutdown()
        except Exception:
            _log.debug("processor shutdown raised; ignoring", exc_info=True)
    _state.pop("installed_provider", None)
    _state.pop("exporter", None)
    _state.pop("client", None)
    _state.pop("forward_to", None)


# ---- Exporter --------------------------------------------------------------


def _build_exporter(
    client: Client | AsyncClient,
    forward_to: Any | None,
) -> Any:
    """Construct the AgentOSSpanExporter subclassing the runtime SpanExporter."""
    from opentelemetry.sdk.trace.export import SpanExporter, SpanExportResult

    class AgentOSSpanExporter(SpanExporter):
        def __init__(self) -> None:
            self._client = client
            self._forward_to = forward_to

        def export(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
            try:
                for span in spans:
                    payload = _span_to_event(span)
                    if payload is None:
                        continue
                    event_type, props = payload
                    _common.emit_sync(self._client, event_type, props)
            except Exception:
                _log.warning("AgentOS exporter failed", exc_info=True)
                return SpanExportResult.FAILURE
            if self._forward_to is not None:
                try:
                    forwarded: Any = self._forward_to.export(spans)
                    return (
                        forwarded
                        if isinstance(forwarded, SpanExportResult)
                        else SpanExportResult.SUCCESS
                    )
                except Exception:
                    _log.warning("forward_to exporter raised", exc_info=True)
                    return SpanExportResult.FAILURE
            return SpanExportResult.SUCCESS

        def shutdown(self) -> None:
            if self._forward_to is not None:
                try:
                    self._forward_to.shutdown()
                except Exception:
                    _log.debug("forward_to shutdown failed", exc_info=True)

        def force_flush(self, timeout_millis: int = 30_000) -> bool:
            ok = True
            if self._forward_to is not None:
                try:
                    forwarded_ok = self._forward_to.force_flush(timeout_millis)
                    ok = ok and bool(forwarded_ok)
                except Exception:
                    ok = False
            return ok

    return AgentOSSpanExporter()


# ---- Span → event translation ----------------------------------------------


def _span_to_event(span: Any) -> tuple[str, dict[str, Any]] | None:
    """Choose an event type from span attributes; build the properties dict.

    - ``gen_ai.system`` present → ``agent.llm_call``
    - ``tool.name`` present → ``agent.tool_call``
    - otherwise: skip (chains / generic spans aren't a v1 event type).
    """
    attrs = dict(getattr(span, "attributes", None) or {})
    duration_ms = _duration_ms_from_span(span)
    base: dict[str, Any] = {}
    if duration_ms is not None:
        base["duration_ms"] = duration_ms

    name = getattr(span, "name", None)
    status = getattr(span, "status", None)
    err = _error_from_status(status) if status is not None else None
    if err is None:
        err = _error_from_events(span)
    if err is not None:
        base["error"] = err

    if "gen_ai.system" in attrs:
        return "agent.llm_call", _build_llm_props(attrs, base)
    if "tool.name" in attrs:
        return "agent.tool_call", _build_tool_props(attrs, base)
    if name and isinstance(name, str) and "handoff" in name.lower():
        # Conservative: only emit handoff when the span name explicitly
        # signals one. Generic spans are noisy; v1 prefers to skip.
        return "agent.handoff", _build_handoff_props(attrs, base, name)
    return None


def _build_llm_props(attrs: dict[str, Any], base: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = dict(base)
    out["gen_ai.system"] = str(attrs["gen_ai.system"])
    out["gen_ai.request.model"] = str(
        attrs.get("gen_ai.request.model") or attrs.get("gen_ai.model") or "unknown"
    )
    for key in (
        "gen_ai.request.temperature",
        "gen_ai.request.top_p",
        "gen_ai.request.max_tokens",
        "gen_ai.response.id",
        "gen_ai.response.model",
        "gen_ai.response.finish_reason",
        "gen_ai.usage.input_tokens",
        "gen_ai.usage.output_tokens",
        "gen_ai.usage.total_tokens",
    ):
        if key in attrs and attrs[key] is not None:
            out[key] = attrs[key]
    # OTel semantic conventions sometimes use prompt_tokens / completion_tokens.
    if "gen_ai.usage.prompt_tokens" in attrs:
        out.setdefault("gen_ai.usage.input_tokens", attrs["gen_ai.usage.prompt_tokens"])
    if "gen_ai.usage.completion_tokens" in attrs:
        out.setdefault("gen_ai.usage.output_tokens", attrs["gen_ai.usage.completion_tokens"])
    return out


def _build_tool_props(attrs: dict[str, Any], base: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = dict(base)
    out["tool.name"] = str(attrs["tool.name"])
    if "tool.description" in attrs:
        out["tool.description"] = attrs["tool.description"]
    if "tool.input" in attrs:
        out["tool.input"] = attrs["tool.input"]
    if "tool.output" in attrs:
        out["tool.output"] = attrs["tool.output"]
    if "tool.status" in attrs:
        out["tool.status"] = attrs["tool.status"]
    return out


def _build_handoff_props(attrs: dict[str, Any], base: dict[str, Any], name: str) -> dict[str, Any]:
    out: dict[str, Any] = dict(base)
    target = attrs.get("agent.target_agent_id") or attrs.get("handoff.target") or name
    out["target_agent_id"] = str(target)
    if "handoff.reason" in attrs:
        out["reason"] = attrs["handoff.reason"]
    return out


def _duration_ms_from_span(span: Any) -> float | None:
    start = getattr(span, "start_time", None)
    end = getattr(span, "end_time", None)
    if start is None or end is None:
        return None
    # OTel times are in nanoseconds.
    return float((end - start) / 1_000_000.0)


def _error_from_status(status: Any) -> dict[str, str] | None:
    code = getattr(status, "status_code", None)
    if code is None:
        return None
    # StatusCode.ERROR == 2 in opentelemetry.trace.status.
    code_value = getattr(code, "value", code)
    if code_value != 2:
        return None
    description = getattr(status, "description", None) or "error"
    return {"type": "OTelError", "message": str(description)}


def _error_from_events(span: Any) -> dict[str, str] | None:
    events = getattr(span, "events", None) or []
    for event in events:
        if getattr(event, "name", "") == "exception":
            attrs = dict(getattr(event, "attributes", None) or {})
            etype = attrs.get("exception.type", "Exception")
            emsg = attrs.get("exception.message", "")
            return {"type": str(etype), "message": str(emsg) or "(no message)"}
    return None
