"""Shared helpers for first-party auto-instrumentation modules.

Per ``docs/spec/05-sdk-contract.md`` "Auto-instrumentation" section:
wrappers must be transparent (preserve return value + exception
behavior), compute ``duration_ms`` from monotonic clocks, honor
``capture_content=False`` privacy mode, and never raise.
"""

from __future__ import annotations

import asyncio
from typing import Any

from .._client import AsyncClient, Client
from .._ids import monotonic_now
from .._logger import get_logger

_log = get_logger("integrations")


def resolve_client(client: Client | AsyncClient | None) -> Client | AsyncClient | None:
    """Return the supplied client, or fall back to the global default."""
    if client is not None:
        return client
    from .. import get_default_client

    return get_default_client()


def capture_content_for(client: Client | AsyncClient | None) -> bool:
    if client is None:
        return True
    return client.config.capture_content


def emit_sync(
    client: Client | AsyncClient | None,
    event_type: str,
    properties: dict[str, Any],
) -> None:
    """Emit synchronously. AsyncClient + sync caller is a config error — log + skip."""
    if client is None:
        return
    try:
        if isinstance(client, Client):
            client.emit(event_type, properties)
            return
        # AsyncClient: best-effort schedule on the running loop, if any.
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            _log.warning(
                "AsyncClient called from sync context with no running loop; dropping %s event",
                event_type,
            )
            return
        # Best-effort fire-and-forget; we don't await the result.
        loop.create_task(client.emit(event_type, properties))  # noqa: RUF006
    except Exception:
        _log.warning("emit_sync failed", exc_info=True)


async def emit_async(
    client: Client | AsyncClient | None,
    event_type: str,
    properties: dict[str, Any],
) -> None:
    """Emit asynchronously. Works with either client kind."""
    if client is None:
        return
    try:
        if isinstance(client, AsyncClient):
            await client.emit(event_type, properties)
            return
        # Sync Client.emit is itself dispatched to its loop thread via
        # run_coroutine_threadsafe.future.result() — fine to call from
        # a coroutine.
        client.emit(event_type, properties)
    except Exception:
        _log.warning("emit_async failed", exc_info=True)


def error_info(exc: BaseException) -> dict[str, str]:
    """Build the ErrorInfo dict per docs/spec/03-event-schema.md."""
    return {
        "type": type(exc).__name__,
        "message": str(exc) or repr(exc),
    }


def elapsed_ms(start: float) -> float:
    """Monotonic milliseconds since ``start``."""
    return float((monotonic_now() - start) * 1000.0)


def normalize_message(m: Any) -> dict[str, Any]:
    """Convert a chat message (dict or pydantic model) to the LLMMessage shape."""
    if isinstance(m, dict):
        return {
            "role": m.get("role") or "user",
            "content": m.get("content"),
            **{k: v for k, v in m.items() if k not in ("role", "content") and v is not None},
        }
    if hasattr(m, "model_dump"):
        d = m.model_dump()
        return normalize_message(d)
    return {
        "role": getattr(m, "role", "user"),
        "content": getattr(m, "content", None),
    }
