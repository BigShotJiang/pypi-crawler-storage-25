"""OpenAI auto-instrumentation.

Per ``docs/spec/05-sdk-contract.md`` "Auto-instrumentation" section:

- ``install(client=None)`` monkey-patches
  ``openai.resources.chat.completions.Completions.create`` and
  ``AsyncCompletions.create``.
- Captures ``gen_ai.system="openai"`` plus all ``gen_ai.request.*`` /
  ``gen_ai.response.*`` / ``gen_ai.usage.*`` fields, ``duration_ms``
  (monotonic), ``stream``, ``error`` (when raised), ``input``
  (messages), ``output`` (assistant message). Tool calls land under
  ``output[].tool_calls``.
- Honors ``capture_content=False`` — drops ``input`` and ``output``.
- ``uninstall()`` cleanly restores even after streaming wrappers were
  active.
- Streaming: wraps the iterator/AsyncIterator and emits **once** when
  the stream completes or errors. Aggregates output content; uses the
  final chunk's ``finish_reason`` and ``usage`` when present (set
  ``stream_options={"include_usage": True}`` to opt in).
- Wrappers are transparent: they preserve the original return value
  and exception behavior.
"""

from __future__ import annotations

import functools
from collections.abc import AsyncIterator, Callable, Iterator
from typing import Any

from .._client import AsyncClient, Client
from .._ids import monotonic_now
from .._logger import get_logger
from . import _common

_log = get_logger("integrations.openai")

_state: dict[str, Any] = {}


def install(client: Client | AsyncClient | None = None) -> None:
    """Patch ``Completions.create`` and ``AsyncCompletions.create``.

    Idempotent: a second call on top of an existing install is a no-op.
    Pass ``client`` to bind a non-default :class:`Client` /
    :class:`AsyncClient`; otherwise the module-level default from
    :func:`agentos.init` is used.
    """
    if _state:
        _log.debug("openai integration already installed; skipping")
        return
    try:
        from openai.resources.chat.completions import (
            AsyncCompletions,
            Completions,
        )
    except Exception:  # pragma: no cover — depends on env
        _log.warning("openai not installed; skipping integration")
        return

    resolved = _common.resolve_client(client)
    if resolved is None:
        _log.warning("no agentos client available; skipping openai integration")
        return

    _state["client"] = resolved
    _state["sync_create"] = Completions.create
    _state["async_create"] = AsyncCompletions.create

    Completions.create = _wrap_sync(Completions.create)  # type: ignore[method-assign]
    AsyncCompletions.create = _wrap_async(AsyncCompletions.create)  # type: ignore[method-assign]


def uninstall() -> None:
    """Restore the originals. Idempotent."""
    if not _state:
        return
    try:
        from openai.resources.chat.completions import (
            AsyncCompletions,
            Completions,
        )

        Completions.create = _state["sync_create"]  # type: ignore[method-assign]
        AsyncCompletions.create = _state["async_create"]  # type: ignore[method-assign]
    except Exception:  # pragma: no cover
        _log.warning("openai uninstall failed to restore originals", exc_info=True)
    _state.clear()


# ---- Request / response shaping --------------------------------------------


def _build_request_props(kwargs: dict[str, Any], capture_content: bool) -> dict[str, Any]:
    props: dict[str, Any] = {
        "gen_ai.system": "openai",
        "gen_ai.request.model": kwargs.get("model") or "unknown",
    }
    if kwargs.get("temperature") is not None:
        props["gen_ai.request.temperature"] = kwargs["temperature"]
    if kwargs.get("top_p") is not None:
        props["gen_ai.request.top_p"] = kwargs["top_p"]
    if kwargs.get("max_tokens") is not None:
        props["gen_ai.request.max_tokens"] = kwargs["max_tokens"]
    if kwargs.get("stream"):
        props["stream"] = True
    if capture_content and kwargs.get("messages"):
        props["input"] = [_common.normalize_message(m) for m in kwargs["messages"]]
    return props


def _absorb_completion(
    props: dict[str, Any],
    response: Any,
    capture_content: bool,
) -> None:
    """Mutate ``props`` with non-streaming response fields."""
    response_id = getattr(response, "id", None)
    if response_id:
        props["gen_ai.response.id"] = response_id
    response_model = getattr(response, "model", None)
    if response_model and response_model != props.get("gen_ai.request.model"):
        props["gen_ai.response.model"] = response_model

    usage = getattr(response, "usage", None)
    if usage is not None:
        prompt = getattr(usage, "prompt_tokens", None)
        completion = getattr(usage, "completion_tokens", None)
        total = getattr(usage, "total_tokens", None)
        if prompt is not None:
            props["gen_ai.usage.input_tokens"] = prompt
        if completion is not None:
            props["gen_ai.usage.output_tokens"] = completion
        if total is not None:
            props["gen_ai.usage.total_tokens"] = total

    choices = getattr(response, "choices", None) or []
    if choices:
        first = choices[0]
        finish_reason = getattr(first, "finish_reason", None)
        if finish_reason:
            props["gen_ai.response.finish_reason"] = finish_reason
        if capture_content:
            props["output"] = [_extract_choice_message(c) for c in choices]


def _extract_choice_message(choice: Any) -> dict[str, Any]:
    """Render one OpenAI ``choice.message`` into the LLMMessage shape."""
    message = getattr(choice, "message", None)
    if message is None:
        return {"role": "assistant", "content": None}
    out: dict[str, Any] = {
        "role": getattr(message, "role", None) or "assistant",
        "content": getattr(message, "content", None),
    }
    tool_calls = getattr(message, "tool_calls", None)
    if tool_calls:
        out["tool_calls"] = [_normalize_tool_call(tc) for tc in tool_calls]
    return out


def _normalize_tool_call(tc: Any) -> dict[str, Any]:
    if hasattr(tc, "model_dump"):
        return tc.model_dump()  # type: ignore[no-any-return]
    if isinstance(tc, dict):
        return tc
    return {"raw": repr(tc)}


# ---- Sync + async wrappers -------------------------------------------------


def _wrap_sync(original: Callable[..., Any]) -> Callable[..., Any]:
    @functools.wraps(original)
    def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
        client = _state.get("client")
        capture = _common.capture_content_for(client)
        request_props = _build_request_props(kwargs, capture)
        start = monotonic_now()
        try:
            result = original(self, *args, **kwargs)
        except BaseException as exc:
            request_props["duration_ms"] = _common.elapsed_ms(start)
            request_props["error"] = _common.error_info(exc)
            _common.emit_sync(client, "agent.llm_call", request_props)
            raise
        if kwargs.get("stream"):
            return _SyncStreamWrapper(result, request_props, start, capture, client)
        request_props["duration_ms"] = _common.elapsed_ms(start)
        _absorb_completion(request_props, result, capture)
        _common.emit_sync(client, "agent.llm_call", request_props)
        return result

    return wrapper


def _wrap_async(original: Callable[..., Any]) -> Callable[..., Any]:
    @functools.wraps(original)
    async def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
        client = _state.get("client")
        capture = _common.capture_content_for(client)
        request_props = _build_request_props(kwargs, capture)
        start = monotonic_now()
        try:
            result = await original(self, *args, **kwargs)
        except BaseException as exc:
            request_props["duration_ms"] = _common.elapsed_ms(start)
            request_props["error"] = _common.error_info(exc)
            await _common.emit_async(client, "agent.llm_call", request_props)
            raise
        if kwargs.get("stream"):
            return _AsyncStreamWrapper(result, request_props, start, capture, client)
        request_props["duration_ms"] = _common.elapsed_ms(start)
        _absorb_completion(request_props, result, capture)
        await _common.emit_async(client, "agent.llm_call", request_props)
        return result

    return wrapper


# ---- Streaming wrappers ----------------------------------------------------


class _StreamAggregator:
    """Aggregates ChatCompletionChunk objects into a single LLMCall event payload."""

    def __init__(
        self,
        props: dict[str, Any],
        start: float,
        capture_content: bool,
        client: Client | AsyncClient | None,
    ) -> None:
        self._props = props
        self._start = start
        self._capture = capture_content
        self._client = client
        self._content_parts: list[str] = []
        self._final_finish_reason: str | None = None
        self._tool_calls: dict[int, dict[str, Any]] = {}
        self._emitted = False

    def absorb(self, chunk: Any) -> None:
        choices = getattr(chunk, "choices", None) or []
        if choices:
            choice = choices[0]
            finish_reason = getattr(choice, "finish_reason", None)
            if finish_reason:
                self._final_finish_reason = finish_reason
            delta = getattr(choice, "delta", None)
            if delta is not None:
                content = getattr(delta, "content", None)
                if content:
                    self._content_parts.append(content)
                tool_calls = getattr(delta, "tool_calls", None) or []
                for tc in tool_calls:
                    self._absorb_tool_call_delta(tc)

        usage = getattr(chunk, "usage", None)
        if usage is not None:
            prompt = getattr(usage, "prompt_tokens", None)
            completion = getattr(usage, "completion_tokens", None)
            total = getattr(usage, "total_tokens", None)
            if prompt is not None:
                self._props["gen_ai.usage.input_tokens"] = prompt
            if completion is not None:
                self._props["gen_ai.usage.output_tokens"] = completion
            if total is not None:
                self._props["gen_ai.usage.total_tokens"] = total

        if "gen_ai.response.id" not in self._props:
            chunk_id = getattr(chunk, "id", None)
            if chunk_id:
                self._props["gen_ai.response.id"] = chunk_id

    def _absorb_tool_call_delta(self, tc: Any) -> None:
        index = getattr(tc, "index", 0) or 0
        slot = self._tool_calls.setdefault(
            index,
            {"id": None, "type": "function", "function": {"name": "", "arguments": ""}},
        )
        if getattr(tc, "id", None):
            slot["id"] = tc.id
        if getattr(tc, "type", None):
            slot["type"] = tc.type
        function = getattr(tc, "function", None)
        if function is not None:
            name = getattr(function, "name", None)
            if name:
                slot["function"]["name"] = (slot["function"].get("name") or "") + name
            arguments = getattr(function, "arguments", None)
            if arguments:
                slot["function"]["arguments"] = (
                    slot["function"].get("arguments") or ""
                ) + arguments

    def _build_output(self) -> list[dict[str, Any]]:
        message: dict[str, Any] = {"role": "assistant"}
        if self._content_parts:
            message["content"] = "".join(self._content_parts)
        else:
            message["content"] = None
        if self._tool_calls:
            message["tool_calls"] = [self._tool_calls[i] for i in sorted(self._tool_calls)]
        return [message]

    def finalize(self, error: BaseException | None) -> dict[str, Any]:
        self._props["duration_ms"] = _common.elapsed_ms(self._start)
        if self._final_finish_reason:
            self._props["gen_ai.response.finish_reason"] = self._final_finish_reason
        if self._capture and (self._content_parts or self._tool_calls):
            self._props["output"] = self._build_output()
        if error is not None:
            self._props["error"] = _common.error_info(error)
        self._emitted = True
        return self._props


class _SyncStreamWrapper:
    """Wraps an OpenAI sync stream, emits one event on completion / error."""

    def __init__(
        self,
        underlying: Any,
        props: dict[str, Any],
        start: float,
        capture_content: bool,
        client: Client | AsyncClient | None,
    ) -> None:
        self._under = underlying
        self._agg = _StreamAggregator(props, start, capture_content, client)
        self._client = client

    def __iter__(self) -> Iterator[Any]:
        return self

    def __next__(self) -> Any:
        try:
            chunk = next(iter(self._under))
        except StopIteration:
            self._emit(None)
            raise
        except BaseException as exc:
            self._emit(exc)
            raise
        self._agg.absorb(chunk)
        return chunk

    def __enter__(self) -> _SyncStreamWrapper:
        if hasattr(self._under, "__enter__"):
            self._under.__enter__()
        return self

    def __exit__(self, *args: Any) -> Any:
        if hasattr(self._under, "__exit__"):
            return self._under.__exit__(*args)
        return None

    def __getattr__(self, name: str) -> Any:
        # Delegate everything else (close, response, etc.) to the underlying.
        return getattr(self._under, name)

    def _emit(self, error: BaseException | None) -> None:
        if self._agg._emitted:
            return
        props = self._agg.finalize(error)
        _common.emit_sync(self._client, "agent.llm_call", props)


class _AsyncStreamWrapper:
    """Wraps an OpenAI async stream, emits one event on completion / error."""

    def __init__(
        self,
        underlying: Any,
        props: dict[str, Any],
        start: float,
        capture_content: bool,
        client: Client | AsyncClient | None,
    ) -> None:
        self._under = underlying
        self._agg = _StreamAggregator(props, start, capture_content, client)
        self._client = client
        self._iter: AsyncIterator[Any] | None = None

    def __aiter__(self) -> _AsyncStreamWrapper:
        return self

    async def __anext__(self) -> Any:
        if self._iter is None:
            self._iter = self._under.__aiter__()
        try:
            chunk = await self._iter.__anext__()
        except StopAsyncIteration:
            await self._emit(None)
            raise
        except BaseException as exc:
            await self._emit(exc)
            raise
        self._agg.absorb(chunk)
        return chunk

    async def __aenter__(self) -> _AsyncStreamWrapper:
        if hasattr(self._under, "__aenter__"):
            await self._under.__aenter__()
        return self

    async def __aexit__(self, *args: Any) -> Any:
        if hasattr(self._under, "__aexit__"):
            return await self._under.__aexit__(*args)
        return None

    def __getattr__(self, name: str) -> Any:
        return getattr(self._under, name)

    async def _emit(self, error: BaseException | None) -> None:
        if self._agg._emitted:
            return
        props = self._agg.finalize(error)
        await _common.emit_async(self._client, "agent.llm_call", props)
