"""ID + clock helpers.

Per ``docs/spec/05-sdk-contract.md`` "Network behavior" and
``docs/spec/60-api-conventions.md`` "Idempotency":

- ``uuid7() -> UUID``         — RFC 9562 UUIDv7 (48-bit ms timestamp +
                                random). Used as ``event_id`` so retries
                                dedupe at the server's
                                ``(project_id, event_id, timestamp)`` PK.
                                Time-sortable so trace ordering works.
- ``new_trace_id() -> str``   — 32 lowercase hex per W3C Trace Context.
- ``new_span_id() -> str``    — 16 lowercase hex per W3C.
- ``monotonic_now() -> float`` — wraps ``time.monotonic()`` for span
                                  duration computation. NEVER use
                                  wall-clock time for ``duration_ms``.
"""

from __future__ import annotations

import os
import time
from uuid import UUID


def uuid7() -> UUID:
    """Generate an RFC 9562 UUIDv7.

    Layout: 48-bit Unix-ms timestamp + 4-bit version (7) + 12-bit random
    + 2-bit variant (10) + 62-bit random. Time-sortable; collisions are
    astronomically unlikely.
    """
    ts_ms = int(time.time() * 1000) & 0xFFFFFFFFFFFF
    rand_a = int.from_bytes(os.urandom(2), "big") & 0x0FFF
    rand_b = int.from_bytes(os.urandom(8), "big") & 0x3FFFFFFFFFFFFFFF

    value = (ts_ms & 0xFFFFFFFFFFFF) << 80
    value |= 0x7 << 76
    value |= rand_a << 64
    value |= 0x2 << 62
    value |= rand_b
    return UUID(int=value)


def new_trace_id() -> str:
    """Generate a 32-char lowercase hex W3C trace_id (16 random bytes)."""
    return os.urandom(16).hex()


def new_span_id() -> str:
    """Generate a 16-char lowercase hex W3C span_id (8 random bytes)."""
    return os.urandom(8).hex()


def monotonic_now() -> float:
    """Return ``time.monotonic()`` — never wall-clock time.

    Use for span duration computation. Wall clocks can jump backward
    under NTP correction and produce negative durations. Wall-clock
    time is only for the event's ``timestamp`` field, set once at
    event creation.
    """
    return time.monotonic()
