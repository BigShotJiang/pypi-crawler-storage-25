"""Identity context stack via ``contextvars`` (async-safe).

Per ``docs/spec/02-identity-model.md`` and the contract's "Identity
context" section. Each task / await chain has its own view of the
active identity tuple. Push / pop is via context managers in the
client layer.
"""

from __future__ import annotations

from contextvars import ContextVar, Token
from dataclasses import dataclass, replace

from ._ids import new_span_id, new_trace_id


@dataclass(frozen=True)
class IdentityContext:
    """Active identity for an emitted event.

    All fields optional except ``agent_id``, which is enforced at emit
    time (see ``_client.Client._enrich_and_validate``). The transport
    refuses to send any event with no ``agent_id``.
    """

    agent_id: str | None = None
    project_id: str | None = None
    task_run_id: str | None = None
    trace_id: str | None = None
    span_id: str | None = None
    parent_span_id: str | None = None
    user_id: str | None = None
    session_id: str | None = None
    environment: str | None = None
    synthetic_task_run: bool = False

    def child_span(self) -> IdentityContext:
        """Return a copy with a fresh ``span_id`` whose parent is the current span."""
        new_span = new_span_id()
        return replace(self, span_id=new_span, parent_span_id=self.span_id)

    def with_task_run(
        self,
        *,
        agent_id: str | None = None,
        task_run_id: str | None = None,
        trace_id: str | None = None,
        user_id: str | None = None,
        session_id: str | None = None,
        synthetic: bool = False,
    ) -> IdentityContext:
        """Start a new task_run frame, generating ids where missing."""
        return IdentityContext(
            agent_id=agent_id if agent_id is not None else self.agent_id,
            project_id=self.project_id,
            task_run_id=task_run_id,
            trace_id=trace_id if trace_id is not None else new_trace_id(),
            span_id=new_span_id(),
            parent_span_id=None,
            user_id=user_id if user_id is not None else self.user_id,
            session_id=session_id if session_id is not None else self.session_id,
            environment=self.environment,
            synthetic_task_run=synthetic,
        )


_EMPTY = IdentityContext()

_current: ContextVar[IdentityContext] = ContextVar("agentos_identity", default=_EMPTY)


def current_context() -> IdentityContext:
    """Return the currently active identity context (or empty default)."""
    return _current.get()


def push_context(ctx: IdentityContext) -> Token[IdentityContext]:
    """Set the current context, returning a token for ``pop_context``."""
    return _current.set(ctx)


def pop_context(token: Token[IdentityContext]) -> None:
    """Restore the prior context."""
    _current.reset(token)


def set_initial_context(
    *,
    agent_id: str | None = None,
    project_id: str | None = None,
    environment: str | None = None,
) -> None:
    """Seed the root context at ``init`` time. Idempotent re-init.

    Replaces the default ``_EMPTY`` so context-less ``log_*`` calls can
    still inherit ``agent_id`` / ``environment`` from configuration.
    """
    _current.set(
        IdentityContext(
            agent_id=agent_id,
            project_id=project_id,
            environment=environment,
        )
    )
