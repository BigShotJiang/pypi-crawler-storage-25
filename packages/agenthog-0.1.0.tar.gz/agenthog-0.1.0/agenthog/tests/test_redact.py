"""Test the redactor pipeline + PII detection."""

from __future__ import annotations

import logging
from typing import Any

import pytest

from agenthog._redact import RedactorPipeline, looks_like_pii

# ---- PII regex -------------------------------------------------------------


def test_looks_like_pii_recognizes_email() -> None:
    assert looks_like_pii("alice@example.com") is True
    assert looks_like_pii("alice+tag@example.co.uk") is True


def test_looks_like_pii_recognizes_e164() -> None:
    assert looks_like_pii("+14155551234") is True
    assert looks_like_pii("4155551234") is True  # bare digits, 6+ chars


def test_looks_like_pii_rejects_safe_ids() -> None:
    assert looks_like_pii("user_42") is False
    assert looks_like_pii("u-vip") is False
    assert looks_like_pii(None) is False
    assert looks_like_pii("") is False


# ---- RedactorPipeline ------------------------------------------------------


def test_redactor_runs_in_registration_order() -> None:
    p = RedactorPipeline()
    p.add(lambda e: {**e, "stamp": "first"})
    p.add(lambda e: {**e, "stamp": "second"})
    out = p.apply({"event_id": "x"})
    assert out["stamp"] == "second"


def test_redactor_can_strip_fields() -> None:
    p = RedactorPipeline()

    def strip_secret(e: dict[str, Any]) -> dict[str, Any]:
        e = dict(e)
        if "properties" in e and "tool.input" in e["properties"]:
            e["properties"] = {k: v for k, v in e["properties"].items() if k != "tool.input"}
        return e

    p.add(strip_secret)
    out = p.apply(
        {
            "event_id": "x",
            "properties": {"tool.name": "send_email", "tool.input": "secret"},
        }
    )
    assert "tool.input" not in out["properties"]


def test_redactor_raise_is_skipped(caplog: pytest.LogCaptureFixture) -> None:
    p = RedactorPipeline()

    def explode(e: dict[str, Any]) -> dict[str, Any]:
        raise RuntimeError("boom")

    def stamp(e: dict[str, Any]) -> dict[str, Any]:
        return {**e, "stamped": True}

    p.add(explode)
    p.add(stamp)
    with caplog.at_level(logging.WARNING, logger="agenthog.sdk"):
        out = p.apply({"event_id": "x"})
    # Event still flows; the stamper after the broken redactor still runs.
    assert out["stamped"] is True
    assert any("redactor" in rec.message for rec in caplog.records)


def test_redactor_returning_non_dict_is_ignored() -> None:
    p = RedactorPipeline()
    p.add(lambda e: None)  # type: ignore[arg-type]
    out = p.apply({"event_id": "x"})
    # Original event preserved.
    assert out == {"event_id": "x"}


# ---- PII warning behavior --------------------------------------------------


def test_pii_warning_fires_once_per_user_id(caplog: pytest.LogCaptureFixture) -> None:
    p = RedactorPipeline()
    with caplog.at_level(logging.WARNING, logger="agenthog.sdk"):
        p.maybe_warn_pii("alice@example.com")
        p.maybe_warn_pii("alice@example.com")
        p.maybe_warn_pii("alice@example.com")
    pii_warnings = [r for r in caplog.records if "alice@example.com" in r.getMessage()]
    assert len(pii_warnings) == 1


def test_pii_warning_separate_per_id(caplog: pytest.LogCaptureFixture) -> None:
    p = RedactorPipeline()
    with caplog.at_level(logging.WARNING, logger="agenthog.sdk"):
        p.maybe_warn_pii("alice@example.com")
        p.maybe_warn_pii("+14155551234")
        p.maybe_warn_pii("user_42")  # not PII; no warning
    msgs = [r.getMessage() for r in caplog.records if "PII" in r.getMessage()]
    # Two distinct PII values triggered → two warnings.
    assert len(msgs) == 2


# ---- End-to-end: client-level redactor + PII ------------------------------


async def test_client_redactor_transforms_events_before_send(
    make_async_client,
) -> None:
    client, server = make_async_client(flush_batch_size=1)

    def strip_user_id(event: dict[str, Any]) -> dict[str, Any]:
        out = dict(event)
        out["user_id"] = None
        return out

    client.add_redactor(strip_user_id)
    try:
        await client.log_business_event("ping", agent_id="agent-x", user_id="raw-id")
        await client.flush()
    finally:
        await client.shutdown()

    assert server.events_received[0]["user_id"] is None


async def test_client_emits_pii_warning_once(
    make_async_client, caplog: pytest.LogCaptureFixture
) -> None:
    client, _server = make_async_client(flush_batch_size=1)
    with caplog.at_level(logging.WARNING, logger="agenthog.sdk"):
        try:
            await client.log_business_event("a", user_id="alice@example.com")
            await client.log_business_event("b", user_id="alice@example.com")
            await client.flush()
        finally:
            await client.shutdown()

    pii_warnings = [r for r in caplog.records if "PII" in r.getMessage()]
    assert len(pii_warnings) == 1
