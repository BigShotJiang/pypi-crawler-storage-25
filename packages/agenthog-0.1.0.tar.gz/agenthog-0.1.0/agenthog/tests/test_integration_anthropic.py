"""Test Anthropic auto-instrumentation."""

from __future__ import annotations

from collections.abc import AsyncIterator, Callable, Iterator
from types import SimpleNamespace
from typing import Any

import pytest
from anthropic.resources.messages import AsyncMessages, Messages

import agenthog
from agenthog.integrations import anthropic as anthropic_integration


def _ns(**kwargs: Any) -> Any:
    return SimpleNamespace(**kwargs)


def _fake_message(
    *,
    text: str = "Hi.",
    stop_reason: str = "end_turn",
    input_tokens: int = 12,
    output_tokens: int = 7,
    msg_id: str = "msg_test",
    model: str = "claude-3-5-sonnet",
) -> Any:
    text_block = _ns(type="text", text=text)
    text_block.model_dump = lambda: {"type": "text", "text": text}  # type: ignore[attr-defined]
    return _ns(
        id=msg_id,
        model=model,
        content=[text_block],
        stop_reason=stop_reason,
        usage=_ns(input_tokens=input_tokens, output_tokens=output_tokens),
    )


def _delta(**kwargs: Any) -> Any:
    return _ns(**kwargs)


class _FakeStream:
    def __init__(self, events: list[Any], raise_after: int | None = None) -> None:
        self._events = list(events)
        self._index = 0
        self._raise_after = raise_after

    def __iter__(self) -> Iterator[Any]:
        return self

    def __next__(self) -> Any:
        if self._raise_after is not None and self._index >= self._raise_after:
            raise RuntimeError("simulated mid-stream error")
        if self._index >= len(self._events):
            raise StopIteration
        ev = self._events[self._index]
        self._index += 1
        return ev


class _FakeAsyncStream:
    def __init__(self, events: list[Any]) -> None:
        self._events = list(events)
        self._index = 0

    def __aiter__(self) -> AsyncIterator[Any]:
        return self

    async def __anext__(self) -> Any:
        if self._index >= len(self._events):
            raise StopAsyncIteration
        ev = self._events[self._index]
        self._index += 1
        return ev


@pytest.fixture
def patched_anthropic(monkeypatch: pytest.MonkeyPatch) -> Callable[..., None]:
    saved_sync_create = Messages.create
    saved_async_create = AsyncMessages.create
    saved_sync_stream = Messages.stream
    saved_async_stream = AsyncMessages.stream

    def configure(
        sync_factory: Callable[..., Any] | None = None,
        async_factory: Callable[..., Any] | None = None,
    ) -> None:
        if sync_factory is not None:
            monkeypatch.setattr(Messages, "create", sync_factory, raising=True)
        if async_factory is not None:
            monkeypatch.setattr(AsyncMessages, "create", async_factory, raising=True)

    yield configure

    anthropic_integration.uninstall()
    Messages.create = saved_sync_create
    AsyncMessages.create = saved_async_create
    Messages.stream = saved_sync_stream
    AsyncMessages.stream = saved_async_stream


# ---- Sync, non-streaming ---------------------------------------------------


def test_sync_non_streaming_emits_one_event(
    patched_anthropic: Callable[..., None], make_sync_client
) -> None:
    client, server = make_sync_client(flush_batch_size=1)

    def fake_create(self: Any, **kwargs: Any) -> Any:
        return _fake_message(text="Hello there.")

    patched_anthropic(sync_factory=fake_create)
    try:
        anthropic_integration.install(client)
        result = Messages.create(
            None,
            model="claude-3-5-sonnet",
            max_tokens=100,
            messages=[{"role": "user", "content": "hi"}],
        )
        assert result.content[0].text == "Hello there."
        client.flush()
    finally:
        client.shutdown()

    events = server.events_received
    assert len(events) == 1
    p = events[0]["properties"]
    assert p["gen_ai.system"] == "anthropic"
    assert p["gen_ai.request.model"] == "claude-3-5-sonnet"
    assert p["gen_ai.usage.input_tokens"] == 12
    assert p["gen_ai.usage.output_tokens"] == 7
    assert p["gen_ai.usage.total_tokens"] == 19
    assert p["gen_ai.response.finish_reason"] == "end_turn"
    assert p["gen_ai.request.max_tokens"] == 100


def test_sync_streaming_aggregates_to_one_event(
    patched_anthropic: Callable[..., None], make_sync_client
) -> None:
    client, server = make_sync_client(flush_batch_size=1)
    events = [
        _ns(
            type="message_start",
            message=_ns(
                id="msg_x",
                model="claude-3-5-sonnet",
                usage=_ns(input_tokens=8),
            ),
        ),
        _ns(type="content_block_start", index=0, content_block=_ns(type="text")),
        _ns(
            type="content_block_delta",
            index=0,
            delta=_delta(type="text_delta", text="Hello "),
        ),
        _ns(
            type="content_block_delta",
            index=0,
            delta=_delta(type="text_delta", text="world."),
        ),
        _ns(type="content_block_stop", index=0),
        _ns(
            type="message_delta",
            delta=_delta(stop_reason="end_turn"),
            usage=_ns(output_tokens=4),
        ),
        _ns(type="message_stop"),
    ]

    def fake_create(self: Any, **kwargs: Any) -> Any:
        return _FakeStream(events)

    patched_anthropic(sync_factory=fake_create)
    try:
        anthropic_integration.install(client)
        stream = Messages.create(
            None,
            model="claude-3-5-sonnet",
            max_tokens=100,
            messages=[{"role": "user", "content": "hi"}],
            stream=True,
        )
        collected = list(stream)
        assert len(collected) == 7
        client.flush()
    finally:
        client.shutdown()

    server_events = server.events_received
    assert len(server_events) == 1
    p = server_events[0]["properties"]
    assert p["stream"] is True
    assert p["gen_ai.usage.input_tokens"] == 8
    assert p["gen_ai.usage.output_tokens"] == 4
    assert p["gen_ai.usage.total_tokens"] == 12
    assert p["gen_ai.response.finish_reason"] == "end_turn"
    output = p["output"][0]["content"]
    assert any(b.get("type") == "text" and b.get("text") == "Hello world." for b in output)


def test_sync_streaming_mid_stream_error(
    patched_anthropic: Callable[..., None], make_sync_client
) -> None:
    client, server = make_sync_client(flush_batch_size=1)
    events = [
        _ns(
            type="content_block_delta",
            index=0,
            delta=_delta(type="text_delta", text="part"),
        ),
        _ns(
            type="content_block_delta",
            index=0,
            delta=_delta(type="text_delta", text="ial"),
        ),
    ]

    def fake_create(self: Any, **kwargs: Any) -> Any:
        return _FakeStream(events, raise_after=2)

    patched_anthropic(sync_factory=fake_create)
    try:
        anthropic_integration.install(client)
        stream = Messages.create(
            None,
            model="claude-3-5-sonnet",
            max_tokens=10,
            messages=[{"role": "user", "content": "hi"}],
            stream=True,
        )
        with pytest.raises(RuntimeError, match="mid-stream error"):
            for _ in stream:
                pass
        client.flush()
    finally:
        client.shutdown()

    p = server.events_received[0]["properties"]
    assert p["error"]["type"] == "RuntimeError"
    output = p["output"][0]["content"]
    assert any(b.get("text") == "partial" for b in output)


def test_uninstall_restores_originals(patched_anthropic: Callable[..., None]) -> None:
    def fake_create(self: Any, **kwargs: Any) -> Any:
        return _fake_message()

    patched_anthropic(sync_factory=fake_create)
    fake_after_patch = Messages.create

    config = agenthog.Config.from_env_and_args(api_key="test", agent_id="agent-x", disable=True)
    client = agenthog.Client(config)
    try:
        anthropic_integration.install(client)
        assert Messages.create is not fake_after_patch
        anthropic_integration.uninstall()
        assert Messages.create is fake_after_patch
    finally:
        client.shutdown()


def test_wrapper_preserves_exceptions(
    patched_anthropic: Callable[..., None], make_sync_client
) -> None:
    client, _ = make_sync_client()

    class APIError(Exception):
        pass

    def fake_create(self: Any, **kwargs: Any) -> Any:
        raise APIError("anthropic blew up")

    patched_anthropic(sync_factory=fake_create)
    try:
        anthropic_integration.install(client)
        with pytest.raises(APIError, match="blew up"):
            Messages.create(
                None,
                model="claude-3-5-sonnet",
                max_tokens=10,
                messages=[{"role": "user", "content": "x"}],
            )
    finally:
        client.shutdown()


def test_capture_content_false_strips_payload(
    patched_anthropic: Callable[..., None], make_sync_client
) -> None:
    client, server = make_sync_client(flush_batch_size=1, capture_content=False)

    def fake_create(self: Any, **kwargs: Any) -> Any:
        return _fake_message(text="secret")

    patched_anthropic(sync_factory=fake_create)
    try:
        anthropic_integration.install(client)
        Messages.create(
            None,
            model="claude-3-5-sonnet",
            max_tokens=10,
            messages=[{"role": "user", "content": "secret prompt"}],
        )
        client.flush()
    finally:
        client.shutdown()

    p = server.events_received[0]["properties"]
    assert "input" not in p
    assert "output" not in p


# ---- Async ----------------------------------------------------------------


async def test_async_non_streaming_emits_one_event(
    patched_anthropic: Callable[..., None], make_async_client
) -> None:
    client, server = make_async_client(flush_batch_size=1)

    async def fake_create(self: Any, **kwargs: Any) -> Any:
        return _fake_message(text="async hi")

    patched_anthropic(async_factory=fake_create)
    try:
        anthropic_integration.install(client)
        result = await AsyncMessages.create(
            None,
            model="claude-3-5-sonnet",
            max_tokens=100,
            messages=[{"role": "user", "content": "hi"}],
        )
        assert result.content[0].text == "async hi"
        await client.flush()
    finally:
        await client.shutdown()

    events = server.events_received
    assert len(events) == 1
    p = events[0]["properties"]
    assert p["gen_ai.system"] == "anthropic"
    assert p["gen_ai.usage.total_tokens"] == 19


async def test_async_streaming_aggregates_to_one_event(
    patched_anthropic: Callable[..., None], make_async_client
) -> None:
    client, server = make_async_client(flush_batch_size=1)
    events = [
        _ns(
            type="message_start",
            message=_ns(id="msg_a", model="claude-3-5", usage=_ns(input_tokens=5)),
        ),
        _ns(
            type="content_block_delta",
            index=0,
            delta=_delta(type="text_delta", text="async "),
        ),
        _ns(
            type="content_block_delta",
            index=0,
            delta=_delta(type="text_delta", text="streamed"),
        ),
        _ns(
            type="message_delta",
            delta=_delta(stop_reason="end_turn"),
            usage=_ns(output_tokens=3),
        ),
    ]

    async def fake_create(self: Any, **kwargs: Any) -> Any:
        return _FakeAsyncStream(events)

    patched_anthropic(async_factory=fake_create)
    try:
        anthropic_integration.install(client)
        stream = await AsyncMessages.create(
            None,
            model="claude-3-5-sonnet",
            max_tokens=10,
            messages=[{"role": "user", "content": "hi"}],
            stream=True,
        )
        collected = []
        async for ev in stream:
            collected.append(ev)
        assert len(collected) == 4
        await client.flush()
    finally:
        await client.shutdown()

    p = server.events_received[0]["properties"]
    assert p["gen_ai.usage.input_tokens"] == 5
    assert p["gen_ai.usage.output_tokens"] == 3
    assert any(b.get("text") == "async streamed" for b in p["output"][0]["content"])
