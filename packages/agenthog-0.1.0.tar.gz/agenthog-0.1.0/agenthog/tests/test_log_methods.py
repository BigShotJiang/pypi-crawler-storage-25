"""Test the manual ``log_*`` surface on AsyncClient + Client."""

from __future__ import annotations

from typing import Any

import pytest

# ---- Helpers ---------------------------------------------------------------


def _props(server: Any) -> dict[str, Any]:
    return server.events_received[0]["properties"]


def _types(server: Any) -> list[str]:
    return [e["event_type"] for e in server.events_received]


# ---- Async-side smoke ------------------------------------------------------


async def test_async_log_llm_call_emits_correct_event(make_async_client) -> None:
    client, server = make_async_client(flush_batch_size=1)
    try:
        await client.log_llm_call(
            model="gpt-4o-mini",
            system="openai",
            input=[{"role": "user", "content": "hi"}],
            output=[{"role": "assistant", "content": "hello"}],
            input_tokens=4,
            output_tokens=2,
            total_tokens=6,
            duration_ms=123.0,
            finish_reason="stop",
            temperature=0.5,
        )
        await client.flush()
    finally:
        await client.shutdown()
    assert _types(server) == ["agent.llm_call"]
    p = _props(server)
    assert p["gen_ai.system"] == "openai"
    assert p["gen_ai.request.model"] == "gpt-4o-mini"
    assert p["gen_ai.request.temperature"] == 0.5
    assert p["gen_ai.usage.input_tokens"] == 4
    assert p["gen_ai.usage.total_tokens"] == 6
    assert p["gen_ai.response.finish_reason"] == "stop"
    assert p["duration_ms"] == 123.0
    assert p["input"][0]["content"] == "hi"
    assert p["output"][0]["content"] == "hello"


async def test_async_log_tool_call_honors_capture_content(make_async_client) -> None:
    client, server = make_async_client(flush_batch_size=1, capture_content=False)
    try:
        await client.log_tool_call(
            "get_weather",
            input={"city": "Paris"},
            output={"temp_c": 21},
            status="success",
            duration_ms=42.0,
        )
        await client.flush()
    finally:
        await client.shutdown()
    p = _props(server)
    assert p["tool.name"] == "get_weather"
    assert p["tool.status"] == "success"
    assert p["duration_ms"] == 42.0
    assert "tool.input" not in p
    assert "tool.output" not in p


async def test_async_log_eval_emits_with_score(make_async_client) -> None:
    client, server = make_async_client(flush_batch_size=1)
    try:
        await client.log_eval(
            "faithfulness",
            0.92,
            label="pass",
            evaluator="llm",
            ref_span_id="0123456789abcdef",
        )
        await client.flush()
    finally:
        await client.shutdown()
    p = _props(server)
    assert _types(server) == ["agent.eval"]
    assert p["eval.name"] == "faithfulness"
    assert p["eval.score"] == 0.92
    assert p["eval.label"] == "pass"
    assert p["eval.evaluator"] == "llm"


async def test_async_log_business_event(make_async_client) -> None:
    client, server = make_async_client(flush_batch_size=1)
    try:
        await client.log_business_event(
            "task_completed",
            revenue=29.0,
            currency="USD",
            metadata={"resolution": "self_serve"},
        )
        await client.flush()
    finally:
        await client.shutdown()
    p = _props(server)
    assert _types(server) == ["agent.business_event"]
    assert p["business.event_name"] == "task_completed"
    assert p["business.revenue"] == 29.0
    assert p["business.currency"] == "USD"
    assert p["business.metadata"]["resolution"] == "self_serve"


async def test_async_log_security_alert(make_async_client) -> None:
    client, server = make_async_client(flush_batch_size=1)
    try:
        await client.log_security_alert(
            "prompt_injection",
            "high",
            description="suspicious tool call attempt",
            scanner="inline-detector",
            action_taken="blocked",
        )
        await client.flush()
    finally:
        await client.shutdown()
    p = _props(server)
    assert p["security.alert_type"] == "prompt_injection"
    assert p["security.severity"] == "high"
    assert p["security.action_taken"] == "blocked"


async def test_async_log_handoff(make_async_client) -> None:
    client, server = make_async_client(flush_batch_size=1)
    try:
        await client.log_handoff(
            "researcher_agent",
            reason="needs deep research",
            context={"query": "weather"},
        )
        await client.flush()
    finally:
        await client.shutdown()
    p = _props(server)
    assert _types(server) == ["agent.handoff"]
    assert p["target_agent_id"] == "researcher_agent"
    assert p["reason"] == "needs deep research"
    assert p["context"]["query"] == "weather"


async def test_async_log_retrieval_honors_capture_content(make_async_client) -> None:
    client, server = make_async_client(flush_batch_size=1, capture_content=False)
    try:
        await client.log_retrieval(
            "kb",
            query="confidential question",
            top_k=5,
            results_count=3,
            documents=[{"id": "doc1", "content": "secret"}],
        )
        await client.flush()
    finally:
        await client.shutdown()
    p = _props(server)
    assert p["retrieval.source"] == "kb"
    assert p["retrieval.top_k"] == 5
    assert p["retrieval.results_count"] == 3
    assert "retrieval.query" not in p
    assert "retrieval.documents" not in p


# ---- Validation failure path ----------------------------------------------


async def test_log_eval_with_bad_evaluator_drops_event(
    make_async_client, caplog: pytest.LogCaptureFixture
) -> None:
    client, server = make_async_client(flush_batch_size=1)
    try:
        result = await client.log_eval("score", 0.5, evaluator="not-a-real-evaluator")
        assert result is None  # validation failure, dropped
        await client.flush()
    finally:
        await client.shutdown()
    # No event batch POSTed (flag fetch GETs are unrelated).
    ingestion = [r for r in server.requests if r.url.path == "/v1/events/batch"]
    assert ingestion == []
    assert client.metrics["events_validation_failed"] >= 1


# ---- Sync surface ---------------------------------------------------------


def test_sync_log_methods_through_loop_thread(make_sync_client) -> None:
    client, server = make_sync_client(flush_batch_size=1)
    try:
        with client.start_task_run("agent-x"):
            assert (
                client.log_llm_call(
                    model="gpt-4o-mini", system="openai", input_tokens=1, output_tokens=1
                )
                is not None
            )
            assert client.log_eval("score", 0.7) is not None
            assert client.log_business_event("ping") is not None
            assert client.log_handoff("other_agent") is not None
        client.flush()
    finally:
        client.shutdown()
    types = [e["event_type"] for e in server.events_received]
    assert types == [
        "agent.llm_call",
        "agent.eval",
        "agent.business_event",
        "agent.handoff",
    ]
