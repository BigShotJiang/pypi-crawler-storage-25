"""Test ``agenthog._ids``."""

from __future__ import annotations

import re
import time

from agenthog._ids import monotonic_now, new_span_id, new_trace_id, uuid7


def test_uuid7_is_version_7_and_time_sortable() -> None:
    a = uuid7()
    time.sleep(0.005)
    b = uuid7()
    assert a.version == 7
    assert b.version == 7
    assert a.variant == "specified in RFC 4122"
    assert a < b  # time-sortable across the millisecond boundary


def test_uuid7_uniqueness_in_burst() -> None:
    seen = {uuid7() for _ in range(2000)}
    assert len(seen) == 2000


def test_trace_and_span_id_format() -> None:
    t = new_trace_id()
    s = new_span_id()
    assert re.match(r"^[0-9a-f]{32}$", t)
    assert re.match(r"^[0-9a-f]{16}$", s)


def test_monotonic_now_advances() -> None:
    a = monotonic_now()
    time.sleep(0.001)
    b = monotonic_now()
    assert b > a
