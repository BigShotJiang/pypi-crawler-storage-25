"""Test OpenAI auto-instrumentation.

The test strategy: substitute OpenAI's ``Completions.create`` /
``AsyncCompletions.create`` with stubs that return fake response /
chunk objects, then install our integration on top. This tests the
wrapper logic without depending on a live API.
"""

from __future__ import annotations

from collections.abc import AsyncIterator, Callable, Iterator
from types import SimpleNamespace
from typing import Any

import pytest
from openai.resources.chat.completions import AsyncCompletions, Completions

import agenthog
from agenthog.integrations import openai as openai_integration

# ---- Helpers ---------------------------------------------------------------


def _ns(**kwargs: Any) -> Any:
    return SimpleNamespace(**kwargs)


def _fake_completion(
    *,
    content: str = "Hi there.",
    finish_reason: str = "stop",
    prompt_tokens: int = 4,
    completion_tokens: int = 5,
    total_tokens: int = 9,
    response_id: str = "chatcmpl-test",
    model: str = "gpt-4o-mini",
    tool_calls: list[dict[str, Any]] | None = None,
) -> Any:
    message = _ns(role="assistant", content=content, tool_calls=tool_calls)
    choice = _ns(index=0, message=message, finish_reason=finish_reason)
    usage = _ns(
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        total_tokens=total_tokens,
    )
    return _ns(id=response_id, model=model, choices=[choice], usage=usage)


def _fake_chunk(
    *,
    delta_content: str | None = None,
    finish_reason: str | None = None,
    usage: Any | None = None,
    chunk_id: str = "chatcmpl-test",
    tool_calls: list[Any] | None = None,
) -> Any:
    delta = _ns(content=delta_content, tool_calls=tool_calls)
    choice = _ns(index=0, delta=delta, finish_reason=finish_reason)
    return _ns(id=chunk_id, choices=[choice], usage=usage)


class _FakeStream:
    def __init__(self, chunks: list[Any], raise_after: int | None = None) -> None:
        self._chunks = list(chunks)
        self._index = 0
        self._raise_after = raise_after
        self.closed = False

    def __iter__(self) -> Iterator[Any]:
        return self

    def __next__(self) -> Any:
        if self._raise_after is not None and self._index >= self._raise_after:
            raise RuntimeError("simulated mid-stream error")
        if self._index >= len(self._chunks):
            raise StopIteration
        chunk = self._chunks[self._index]
        self._index += 1
        return chunk

    def close(self) -> None:
        self.closed = True


class _FakeAsyncStream:
    def __init__(self, chunks: list[Any], raise_after: int | None = None) -> None:
        self._chunks = list(chunks)
        self._index = 0
        self._raise_after = raise_after

    def __aiter__(self) -> AsyncIterator[Any]:
        return self

    async def __anext__(self) -> Any:
        if self._raise_after is not None and self._index >= self._raise_after:
            raise RuntimeError("simulated mid-stream error")
        if self._index >= len(self._chunks):
            raise StopAsyncIteration
        chunk = self._chunks[self._index]
        self._index += 1
        return chunk


@pytest.fixture
def patched_openai(monkeypatch: pytest.MonkeyPatch) -> Callable[..., None]:
    """Replace OpenAI's create() methods with caller-supplied fakes, then install."""

    saved_sync = Completions.create
    saved_async = AsyncCompletions.create

    def configure(
        sync_factory: Callable[..., Any] | None = None,
        async_factory: Callable[..., Any] | None = None,
    ) -> None:
        if sync_factory is not None:
            monkeypatch.setattr(Completions, "create", sync_factory, raising=True)
        if async_factory is not None:
            monkeypatch.setattr(AsyncCompletions, "create", async_factory, raising=True)

    yield configure

    # Make sure we always uninstall + restore even if test fails.
    openai_integration.uninstall()
    Completions.create = saved_sync
    AsyncCompletions.create = saved_async


# ---- Sync, non-streaming ---------------------------------------------------


def test_sync_non_streaming_emits_one_event(
    patched_openai: Callable[..., None], make_sync_client
) -> None:
    client, server = make_sync_client(flush_batch_size=1)
    captured: dict[str, Any] = {}

    def fake_create(self: Any, **kwargs: Any) -> Any:
        captured["kwargs"] = kwargs
        return _fake_completion(content="Hello world.", finish_reason="stop")

    patched_openai(sync_factory=fake_create)
    try:
        openai_integration.install(client)
        # Simulate user code calling create() — bypass real Client construction
        # by calling the patched Completions.create directly through a stub.
        result = Completions.create(
            None, model="gpt-4o-mini", messages=[{"role": "user", "content": "hi"}]
        )
        assert result.choices[0].message.content == "Hello world."
        client.flush()
    finally:
        client.shutdown()

    events = server.events_received
    assert len(events) == 1
    ev = events[0]
    assert ev["event_type"] == "agent.llm_call"
    p = ev["properties"]
    assert p["gen_ai.system"] == "openai"
    assert p["gen_ai.request.model"] == "gpt-4o-mini"
    assert p["gen_ai.usage.input_tokens"] == 4
    assert p["gen_ai.usage.output_tokens"] == 5
    assert p["gen_ai.usage.total_tokens"] == 9
    assert p["gen_ai.response.finish_reason"] == "stop"
    assert p["duration_ms"] >= 0
    assert p["input"] == [{"role": "user", "content": "hi"}]
    assert p["output"][0]["content"] == "Hello world."


def test_sync_streaming_aggregates_to_one_event(
    patched_openai: Callable[..., None], make_sync_client
) -> None:
    client, server = make_sync_client(flush_batch_size=1)
    chunks = [
        _fake_chunk(delta_content="Hel"),
        _fake_chunk(delta_content="lo "),
        _fake_chunk(delta_content="world."),
        _fake_chunk(finish_reason="stop"),
        # Final usage chunk (stream_options={"include_usage": True})
        _fake_chunk(usage=_ns(prompt_tokens=3, completion_tokens=2, total_tokens=5)),
    ]

    def fake_create(self: Any, **kwargs: Any) -> Any:
        return _FakeStream(chunks)

    patched_openai(sync_factory=fake_create)
    try:
        openai_integration.install(client)
        stream = Completions.create(
            None,
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": "hi"}],
            stream=True,
            stream_options={"include_usage": True},
        )
        collected = list(stream)
        assert len(collected) == 5
        client.flush()
    finally:
        client.shutdown()

    events = server.events_received
    assert len(events) == 1
    p = events[0]["properties"]
    assert p["stream"] is True
    assert p["gen_ai.response.finish_reason"] == "stop"
    assert p["gen_ai.usage.total_tokens"] == 5
    assert p["output"][0]["content"] == "Hello world."


def test_sync_streaming_mid_stream_error_emits_partial(
    patched_openai: Callable[..., None], make_sync_client
) -> None:
    client, server = make_sync_client(flush_batch_size=1)
    chunks = [_fake_chunk(delta_content="part"), _fake_chunk(delta_content="ial")]

    def fake_create(self: Any, **kwargs: Any) -> Any:
        return _FakeStream(chunks, raise_after=2)

    patched_openai(sync_factory=fake_create)
    try:
        openai_integration.install(client)
        stream = Completions.create(
            None, model="gpt-4o-mini", messages=[{"role": "user", "content": "hi"}], stream=True
        )
        with pytest.raises(RuntimeError, match="mid-stream error"):
            for _chunk in stream:
                pass
        client.flush()
    finally:
        client.shutdown()

    events = server.events_received
    assert len(events) == 1
    p = events[0]["properties"]
    assert p["error"]["type"] == "RuntimeError"
    assert "mid-stream error" in p["error"]["message"]
    assert p["output"][0]["content"] == "partial"


def test_sync_tool_calls_render_correctly(
    patched_openai: Callable[..., None], make_sync_client
) -> None:
    client, server = make_sync_client(flush_batch_size=1)
    [
        _ns(
            id="call_1",
            type="function",
            function=_ns(name="get_weather", arguments='{"city": "Paris"}'),
        )
    ]
    # tool_call objects expose model_dump via SimpleNamespace? No — they don't.
    # The integration falls back to dict if not pydantic; manually wrap as dict.
    tool_calls_as_dicts = [
        {
            "id": "call_1",
            "type": "function",
            "function": {"name": "get_weather", "arguments": '{"city": "Paris"}'},
        }
    ]
    response = _fake_completion(content=None, tool_calls=tool_calls_as_dicts)

    def fake_create(self: Any, **kwargs: Any) -> Any:
        return response

    patched_openai(sync_factory=fake_create)
    try:
        openai_integration.install(client)
        Completions.create(
            None, model="gpt-4o-mini", messages=[{"role": "user", "content": "weather?"}]
        )
        client.flush()
    finally:
        client.shutdown()

    events = server.events_received
    assert len(events) == 1
    output = events[0]["properties"]["output"][0]
    assert output["tool_calls"][0]["function"]["name"] == "get_weather"


def test_uninstall_cleanly_restores(patched_openai: Callable[..., None]) -> None:
    saved = Completions.create

    def fake_create(self: Any, **kwargs: Any) -> Any:
        return _fake_completion()

    patched_openai(sync_factory=fake_create)
    # Now Completions.create is fake_create.
    fake_after_patch = Completions.create

    config = agenthog.Config.from_env_and_args(api_key="test", agent_id="agent-x", disable=True)
    client = agenthog.Client(config)
    try:
        openai_integration.install(client)
        assert Completions.create is not fake_after_patch  # wrapped
        openai_integration.uninstall()
        assert Completions.create is fake_after_patch
    finally:
        client.shutdown()
        del saved  # not used past here


def test_wrapper_preserves_exception_type_and_message(
    patched_openai: Callable[..., None], make_sync_client
) -> None:
    client, _ = make_sync_client()

    class CustomAPIError(Exception):
        pass

    def fake_create(self: Any, **kwargs: Any) -> Any:
        raise CustomAPIError("rate limited, please retry")

    patched_openai(sync_factory=fake_create)
    try:
        openai_integration.install(client)
        with pytest.raises(CustomAPIError, match="rate limited"):
            Completions.create(
                None, model="gpt-4o-mini", messages=[{"role": "user", "content": "x"}]
            )
    finally:
        client.shutdown()


def test_capture_content_false_drops_input_and_output(
    patched_openai: Callable[..., None], make_sync_client
) -> None:
    client, server = make_sync_client(flush_batch_size=1, capture_content=False)

    def fake_create(self: Any, **kwargs: Any) -> Any:
        return _fake_completion(content="secret reply")

    patched_openai(sync_factory=fake_create)
    try:
        openai_integration.install(client)
        Completions.create(
            None, model="gpt-4o-mini", messages=[{"role": "user", "content": "secret"}]
        )
        client.flush()
    finally:
        client.shutdown()

    p = server.events_received[0]["properties"]
    assert "input" not in p
    assert "output" not in p
    assert p["gen_ai.usage.total_tokens"] == 9


def test_duration_uses_monotonic_clock(
    patched_openai: Callable[..., None],
    make_sync_client,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Wall-clock jumping backward must not produce a negative duration."""
    client, server = make_sync_client(flush_batch_size=1)

    def fake_create(self: Any, **kwargs: Any) -> Any:
        # Move wall clock backward by 10 minutes mid-call. The wrapper
        # should not see negative duration_ms because it relies on
        # monotonic time, not wall clock.
        import time as _time

        original_time = _time.time
        monkeypatch.setattr(_time, "time", lambda: original_time() - 600)
        return _fake_completion()

    patched_openai(sync_factory=fake_create)
    try:
        openai_integration.install(client)
        Completions.create(None, model="gpt-4o-mini", messages=[{"role": "user", "content": "x"}])
        client.flush()
    finally:
        client.shutdown()

    duration = server.events_received[0]["properties"]["duration_ms"]
    assert duration >= 0


# ---- Async paths -----------------------------------------------------------


async def test_async_non_streaming_emits_one_event(
    patched_openai: Callable[..., None], make_async_client
) -> None:
    client, server = make_async_client(flush_batch_size=1)

    async def fake_create(self: Any, **kwargs: Any) -> Any:
        return _fake_completion(content="async hi")

    patched_openai(async_factory=fake_create)
    try:
        openai_integration.install(client)
        result = await AsyncCompletions.create(
            None, model="gpt-4o-mini", messages=[{"role": "user", "content": "hi"}]
        )
        assert result.choices[0].message.content == "async hi"
        await client.flush()
    finally:
        await client.shutdown()

    events = server.events_received
    assert len(events) == 1
    assert events[0]["properties"]["output"][0]["content"] == "async hi"


async def test_async_streaming_aggregates_to_one_event(
    patched_openai: Callable[..., None], make_async_client
) -> None:
    client, server = make_async_client(flush_batch_size=1)
    chunks = [
        _fake_chunk(delta_content="async "),
        _fake_chunk(delta_content="streamed"),
        _fake_chunk(finish_reason="stop"),
    ]

    async def fake_create(self: Any, **kwargs: Any) -> Any:
        return _FakeAsyncStream(chunks)

    patched_openai(async_factory=fake_create)
    try:
        openai_integration.install(client)
        stream = await AsyncCompletions.create(
            None,
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": "hi"}],
            stream=True,
        )
        collected = []
        async for chunk in stream:
            collected.append(chunk)
        assert len(collected) == 3
        await client.flush()
    finally:
        await client.shutdown()

    events = server.events_received
    assert len(events) == 1
    p = events[0]["properties"]
    assert p["output"][0]["content"] == "async streamed"
    assert p["gen_ai.response.finish_reason"] == "stop"
