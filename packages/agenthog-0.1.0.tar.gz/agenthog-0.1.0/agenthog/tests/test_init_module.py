"""Test the module-level ``init`` / ``shutdown`` / convenience surface."""

from __future__ import annotations

import logging

import pytest

import agenthog
from agenthog._client import AsyncClient, Client


def test_init_returns_sync_client_by_default(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTOS_DISABLE", "1")
    client = agenthog.init(api_key="test", agent_id="agent-x")
    try:
        assert isinstance(client, Client)
        assert agenthog.get_default_client() is client
    finally:
        agenthog.shutdown()


def test_init_async_kind_returns_async_client(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTOS_DISABLE", "1")
    client = agenthog.init(api_key="test", agent_id="agent-x", kind="async")
    try:
        assert isinstance(client, AsyncClient)
    finally:
        agenthog.shutdown()


def test_init_warns_when_api_key_missing(
    monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture
) -> None:
    monkeypatch.delenv("AGENTOS_API_KEY", raising=False)
    monkeypatch.delenv("AGENTOS_DISABLE", raising=False)
    with caplog.at_level(logging.ERROR, logger="agenthog.sdk"):
        agenthog.init(agent_id="agent-x", disable=False)
    try:
        assert any("AGENTOS_API_KEY" in rec.message for rec in caplog.records)
    finally:
        agenthog.shutdown()


def test_disable_via_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTOS_DISABLE", "true")
    client = agenthog.init(api_key="test", agent_id="agent-x")
    try:
        assert client.config.disable is True
    finally:
        agenthog.shutdown()
