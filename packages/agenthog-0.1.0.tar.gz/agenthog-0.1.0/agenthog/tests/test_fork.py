"""Test fork safety: the SDK resets transport state in forked children."""

from __future__ import annotations

import multiprocessing as mp
import os
import sys

import pytest

import agenthog


def _child_emit_and_flush(queue: mp.Queue[str]) -> None:
    """Run inside the forked child: emit one event and confirm shutdown completes."""
    try:
        # The fork handler should have reset the parent's transport state.
        client = agenthog.get_default_client()
        if client is None:
            queue.put("no-client")
            return
        # Smoke-check: metrics counter is back to zero after the fork reset.
        assert client.metrics["events_sent"] == 0
        # We can re-emit without crashing (the transport is fresh).
        from agenthog._client import Client as _Client

        if isinstance(client, _Client):
            client.emit("agent.business_event", {"business.event_name": "child"})
            client.shutdown()
        queue.put("ok")
    except Exception as e:  # pragma: no cover
        queue.put(f"error: {e!r}")


@pytest.mark.skipif(
    sys.platform == "win32" or not hasattr(os, "register_at_fork"),
    reason="fork() not available on this platform",
)
def test_fork_handler_resets_state() -> None:
    # Init a sync client in the parent.
    agenthog.init(
        api_key="test",
        endpoint="http://localhost:1",  # nothing listens; child just exits cleanly
        agent_id="agent-fork",
        disable=True,  # avoid network in test; verifies handler still runs.
    )
    try:
        ctx = mp.get_context("fork")
        q: mp.Queue[str] = ctx.Queue()
        proc = ctx.Process(target=_child_emit_and_flush, args=(q,))
        proc.start()
        proc.join(timeout=10)
        assert proc.exitcode == 0
        assert not q.empty()
        result = q.get(timeout=1)
        assert result == "ok"
    finally:
        agenthog.shutdown()
