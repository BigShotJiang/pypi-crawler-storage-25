"""Test OpenTelemetry passthrough."""

from __future__ import annotations

import contextlib
from collections.abc import Sequence
from typing import Any

from opentelemetry import trace as otel_trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import (
    SimpleSpanProcessor,
    SpanExporter,
    SpanExportResult,
)

import agenthog
from agenthog.integrations import opentelemetry as otel_integration

# ---- Helpers ---------------------------------------------------------------


class _ProviderFixture:
    """Install a fresh TracerProvider for each test (OTel global is sticky)."""

    def __init__(self) -> None:
        self.provider = TracerProvider()
        self._previous: Any = None

    def __enter__(self) -> TracerProvider:
        self._previous = otel_trace._TRACER_PROVIDER  # type: ignore[attr-defined]
        otel_trace._TRACER_PROVIDER = self.provider  # type: ignore[attr-defined]
        otel_trace._TRACER_PROVIDER_SET_ONCE._done = False  # type: ignore[attr-defined]
        return self.provider

    def __exit__(self, *exc: Any) -> None:
        with contextlib.suppress(Exception):
            otel_integration.uninstall()
        otel_trace._TRACER_PROVIDER = self._previous  # type: ignore[attr-defined]


class _CapturingExporter(SpanExporter):
    """Test double capturing forwarded spans for tee-mode assertions."""

    def __init__(self) -> None:
        self.spans: list[Any] = []
        self.flushed = False
        self.shutdown_called = False

    def export(self, spans: Sequence[Any]) -> SpanExportResult:
        self.spans.extend(spans)
        return SpanExportResult.SUCCESS

    def force_flush(self, timeout_millis: int = 30_000) -> bool:
        self.flushed = True
        return True

    def shutdown(self) -> None:
        self.shutdown_called = True


# ---- Tests -----------------------------------------------------------------


def test_install_translates_llm_span_to_agent_llm_call(make_sync_client) -> None:
    client, server = make_sync_client(flush_batch_size=1)
    with _ProviderFixture() as provider:
        # Use SimpleSpanProcessor for deterministic export-on-end.
        exporter = otel_integration.install(client, add_to_provider=False)
        assert exporter is not None
        provider.add_span_processor(SimpleSpanProcessor(exporter))

        try:
            tracer = provider.get_tracer("test")
            with tracer.start_as_current_span("chat") as span:
                span.set_attribute("gen_ai.system", "openai")
                span.set_attribute("gen_ai.request.model", "gpt-4o-mini")
                span.set_attribute("gen_ai.usage.prompt_tokens", 10)
                span.set_attribute("gen_ai.usage.completion_tokens", 5)
                span.set_attribute("gen_ai.response.finish_reason", "stop")
            client.flush()
        finally:
            client.shutdown()

    events = server.events_received
    assert len(events) == 1
    assert events[0]["event_type"] == "agent.llm_call"
    p = events[0]["properties"]
    assert p["gen_ai.system"] == "openai"
    assert p["gen_ai.request.model"] == "gpt-4o-mini"
    assert p["gen_ai.usage.input_tokens"] == 10
    assert p["gen_ai.usage.output_tokens"] == 5
    assert p["gen_ai.response.finish_reason"] == "stop"
    assert p["duration_ms"] >= 0


def test_install_translates_tool_span_to_agent_tool_call(make_sync_client) -> None:
    client, server = make_sync_client(flush_batch_size=1)
    with _ProviderFixture() as provider:
        exporter = otel_integration.install(client, add_to_provider=False)
        assert exporter is not None
        provider.add_span_processor(SimpleSpanProcessor(exporter))

        try:
            tracer = provider.get_tracer("test")
            with tracer.start_as_current_span("get_weather") as span:
                span.set_attribute("tool.name", "get_weather")
                span.set_attribute("tool.input", '{"city": "Paris"}')
                span.set_attribute("tool.output", "21")
                span.set_attribute("tool.status", "success")
            client.flush()
        finally:
            client.shutdown()

    events = server.events_received
    assert len(events) == 1
    assert events[0]["event_type"] == "agent.tool_call"
    p = events[0]["properties"]
    assert p["tool.name"] == "get_weather"
    assert p["tool.status"] == "success"


def test_generic_spans_are_skipped(make_sync_client) -> None:
    client, server = make_sync_client(flush_batch_size=1)
    with _ProviderFixture() as provider:
        exporter = otel_integration.install(client, add_to_provider=False)
        provider.add_span_processor(SimpleSpanProcessor(exporter))

        try:
            tracer = provider.get_tracer("test")
            with tracer.start_as_current_span("some_chain"):
                pass
            client.flush()
        finally:
            client.shutdown()

    assert server.events_received == []


def test_tee_forwards_to_existing_exporter(make_sync_client) -> None:
    client, server = make_sync_client(flush_batch_size=1)
    forward_target = _CapturingExporter()

    with _ProviderFixture() as provider:
        exporter = otel_integration.install(
            client, forward_to=forward_target, add_to_provider=False
        )
        assert exporter is not None
        provider.add_span_processor(SimpleSpanProcessor(exporter))

        try:
            tracer = provider.get_tracer("test")
            with tracer.start_as_current_span("chat") as span:
                span.set_attribute("gen_ai.system", "openai")
                span.set_attribute("gen_ai.request.model", "gpt-4o-mini")
            client.flush()
        finally:
            client.shutdown()

    assert len(server.events_received) == 1
    # Same span also forwarded to the user's collector.
    assert len(forward_target.spans) == 1


def test_error_status_lands_on_event(make_sync_client) -> None:
    from opentelemetry.trace.status import Status, StatusCode

    client, server = make_sync_client(flush_batch_size=1)
    with _ProviderFixture() as provider:
        exporter = otel_integration.install(client, add_to_provider=False)
        provider.add_span_processor(SimpleSpanProcessor(exporter))

        try:
            tracer = provider.get_tracer("test")
            with tracer.start_as_current_span("chat") as span:
                span.set_attribute("gen_ai.system", "openai")
                span.set_attribute("gen_ai.request.model", "gpt-4o-mini")
                span.set_status(Status(StatusCode.ERROR, "rate limited"))
            client.flush()
        finally:
            client.shutdown()

    p = server.events_received[0]["properties"]
    assert p["error"]["message"] == "rate limited"


def test_uninstall_clears_state() -> None:
    config = agenthog.Config.from_env_and_args(api_key="test", agent_id="agent-x", disable=True)
    client = agenthog.Client(config)
    try:
        with _ProviderFixture():
            exporter = otel_integration.install(client, add_to_provider=False)
            assert exporter is not None
            otel_integration.uninstall()
            # After uninstall, install() returns a fresh exporter.
            exporter2 = otel_integration.install(client, add_to_provider=False)
            assert exporter2 is not None
            otel_integration.uninstall()
    finally:
        client.shutdown()
