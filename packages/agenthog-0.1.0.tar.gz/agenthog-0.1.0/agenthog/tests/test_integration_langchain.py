"""Test LangChain auto-instrumentation.

The callback contract is shaped by LangChain's runtime — at test time
we drive the callbacks directly with synthetic ``run_id`` values and
:class:`LLMResult` / :class:`AIMessage` objects. This exercises the
handler's state machine without needing a live LLM.
"""

from __future__ import annotations

import time
from types import SimpleNamespace
from typing import Any
from uuid import uuid4

import pytest
from langchain_core.messages import AIMessage, HumanMessage
from langchain_core.outputs import ChatGeneration, LLMResult

import agenthog
from agenthog.integrations import langchain as lc_integration


def _ns(**kwargs: Any) -> Any:
    return SimpleNamespace(**kwargs)


def _serialized(model: str = "gpt-4o-mini", provider: str = "openai") -> dict[str, Any]:
    return {
        "id": ["langchain", "chat_models", provider, "ChatOpenAI"],
        "kwargs": {"model": model},
    }


def _llm_result(
    text: str = "Hello.",
    *,
    finish_reason: str = "stop",
    prompt_tokens: int = 4,
    completion_tokens: int = 5,
    total_tokens: int = 9,
) -> LLMResult:
    message = AIMessage(content=text, response_metadata={"finish_reason": finish_reason})
    gen = ChatGeneration(message=message, generation_info={"finish_reason": finish_reason})
    return LLMResult(
        generations=[[gen]],
        llm_output={
            "token_usage": {
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "total_tokens": total_tokens,
            },
        },
    )


@pytest.fixture
def langchain_handler(make_sync_client):
    client, server = make_sync_client(flush_batch_size=1)
    handler = lc_integration.install(client)
    assert handler is not None

    yield handler, client, server

    lc_integration.uninstall()
    client.shutdown()


# ---- LLM happy path --------------------------------------------------------


def test_chat_model_lifecycle_emits_one_event(langchain_handler) -> None:
    handler, client, server = langchain_handler
    run_id = uuid4()
    invocation_params = {
        "_type": "openai-chat",
        "model": "gpt-4o-mini",
        "temperature": 0.5,
    }

    handler.on_chat_model_start(
        _serialized(),
        [[HumanMessage(content="hi")]],
        run_id=run_id,
        invocation_params=invocation_params,
    )
    handler.on_llm_end(_llm_result(text="Hello world."), run_id=run_id)
    client.flush()

    events = server.events_received
    assert len(events) == 1
    p = events[0]["properties"]
    assert events[0]["event_type"] == "agent.llm_call"
    assert p["gen_ai.system"] == "openai-chat"
    assert p["gen_ai.request.model"] == "gpt-4o-mini"
    assert p["gen_ai.request.temperature"] == 0.5
    assert p["gen_ai.usage.input_tokens"] == 4
    assert p["gen_ai.usage.output_tokens"] == 5
    assert p["gen_ai.usage.total_tokens"] == 9
    assert p["gen_ai.response.finish_reason"] == "stop"
    assert p["duration_ms"] >= 0
    assert (
        p["input"] == [{"role": "user", "content": "hi", "tool_calls": []}]
        or p["input"][0]["content"] == "hi"
    )
    assert p["output"][0]["content"] == "Hello world."


def test_streaming_emits_one_event_with_full_aggregated_content(
    langchain_handler,
) -> None:
    handler, client, server = langchain_handler
    run_id = uuid4()

    handler.on_chat_model_start(
        _serialized(),
        [[HumanMessage(content="stream please")]],
        run_id=run_id,
        invocation_params={"_type": "openai-chat", "model": "gpt-4o-mini"},
    )
    # Stream 10 tokens through on_llm_new_token; assert NO event yet.
    tokens = [
        "one ",
        "two ",
        "three ",
        "four ",
        "five ",
        "six ",
        "seven ",
        "eight ",
        "nine ",
        "ten",
    ]
    for tok in tokens:
        handler.on_llm_new_token(tok, run_id=run_id)
    assert server.request_count == 0  # no event emitted yet

    # End of stream — emit exactly one event.
    handler.on_llm_end(
        _llm_result(text="one two three four five six seven eight nine ten"),
        run_id=run_id,
    )
    client.flush()

    events = server.events_received
    assert len(events) == 1
    p = events[0]["properties"]
    assert p["output"][0]["content"] == "one two three four five six seven eight nine ten"


def test_llm_error_emits_one_event_with_partial_output(langchain_handler) -> None:
    handler, client, server = langchain_handler
    run_id = uuid4()

    handler.on_chat_model_start(
        _serialized(),
        [[HumanMessage(content="bad")]],
        run_id=run_id,
        invocation_params={"_type": "openai-chat", "model": "gpt-4o-mini"},
    )
    handler.on_llm_new_token("partial ", run_id=run_id)
    handler.on_llm_new_token("answer", run_id=run_id)

    class APIError(Exception):
        pass

    handler.on_llm_error(APIError("boom"), run_id=run_id)
    client.flush()

    events = server.events_received
    assert len(events) == 1
    p = events[0]["properties"]
    assert p["error"]["type"] == "APIError"
    assert "boom" in p["error"]["message"]
    assert p["output"][0]["content"] == "partial answer"


# ---- Tool path -------------------------------------------------------------


def test_tool_lifecycle_emits_agent_tool_call(langchain_handler) -> None:
    handler, client, server = langchain_handler
    run_id = uuid4()

    handler.on_tool_start(
        {"name": "get_weather"},
        '{"city": "Paris"}',
        run_id=run_id,
        inputs={"city": "Paris"},
    )
    handler.on_tool_end({"temp_c": 21}, run_id=run_id)
    client.flush()

    events = server.events_received
    assert len(events) == 1
    assert events[0]["event_type"] == "agent.tool_call"
    p = events[0]["properties"]
    assert p["tool.name"] == "get_weather"
    assert p["tool.status"] == "success"
    assert p["tool.input"] == {"city": "Paris"}
    assert p["tool.output"] == {"temp_c": 21}
    assert p["duration_ms"] >= 0


def test_tool_error_emits_event_with_error(langchain_handler) -> None:
    handler, client, server = langchain_handler
    run_id = uuid4()

    handler.on_tool_start({"name": "search"}, "query", run_id=run_id)
    handler.on_tool_error(RuntimeError("tool failed"), run_id=run_id)
    client.flush()

    events = server.events_received
    assert len(events) == 1
    assert events[0]["event_type"] == "agent.tool_call"
    p = events[0]["properties"]
    assert p["tool.status"] == "error"
    assert p["error"]["type"] == "RuntimeError"


# ---- Agent action ----------------------------------------------------------


def test_agent_action_emits_handoff(langchain_handler) -> None:
    handler, client, server = langchain_handler
    action = _ns(tool="researcher_agent", log="delegating to researcher")
    handler.on_agent_action(action, run_id=uuid4())
    client.flush()

    events = server.events_received
    assert len(events) == 1
    assert events[0]["event_type"] == "agent.handoff"
    p = events[0]["properties"]
    assert p["target_agent_id"] == "researcher_agent"
    assert "delegating" in p["reason"]


# ---- End-to-end pipeline (chain → llm → tool → llm → finish) ---------------


def test_full_pipeline_event_sequence(langchain_handler) -> None:
    handler, client, server = langchain_handler
    chain_id = uuid4()
    llm1 = uuid4()
    tool_id = uuid4()
    llm2 = uuid4()

    # Chain begins (no event emitted; chains are spans).
    handler.on_chain_start({"id": ["AgentExecutor"]}, {"input": "weather?"}, run_id=chain_id)

    # First LLM call — produces a tool decision.
    handler.on_chat_model_start(
        _serialized(),
        [[HumanMessage(content="weather?")]],
        run_id=llm1,
        parent_run_id=chain_id,
        invocation_params={"_type": "openai-chat", "model": "gpt-4o-mini"},
    )
    handler.on_llm_end(_llm_result(text="calling tool"), run_id=llm1)

    # Agent decides to call a tool — handoff event.
    handler.on_agent_action(
        _ns(tool="get_weather", log="will call get_weather"),
        run_id=chain_id,
    )

    # Tool executes.
    handler.on_tool_start(
        {"name": "get_weather"},
        '{"city": "Paris"}',
        run_id=tool_id,
        parent_run_id=chain_id,
    )
    handler.on_tool_end("21°C", run_id=tool_id)

    # Second LLM call — final answer.
    handler.on_chat_model_start(
        _serialized(),
        [[HumanMessage(content="weather? + tool result")]],
        run_id=llm2,
        parent_run_id=chain_id,
        invocation_params={"_type": "openai-chat", "model": "gpt-4o-mini"},
    )
    handler.on_llm_end(_llm_result(text="It is 21°C in Paris."), run_id=llm2)

    # Chain finishes (no event).
    handler.on_chain_end({"output": "It is 21°C in Paris."}, run_id=chain_id)
    client.flush()

    events = server.events_received
    types = [e["event_type"] for e in events]
    assert types == [
        "agent.llm_call",
        "agent.handoff",
        "agent.tool_call",
        "agent.llm_call",
    ]
    assert events[2]["properties"]["tool.output"] == "21°C"
    assert events[3]["properties"]["output"][0]["content"] == "It is 21°C in Paris."


# ---- Privacy mode ----------------------------------------------------------


def test_capture_content_false_strips_payload(make_sync_client) -> None:
    client, server = make_sync_client(flush_batch_size=1, capture_content=False)
    handler = lc_integration.install(client)
    try:
        run_id = uuid4()
        handler.on_chat_model_start(
            _serialized(),
            [[HumanMessage(content="secret")]],
            run_id=run_id,
            invocation_params={"_type": "openai-chat", "model": "gpt-4o-mini"},
        )
        handler.on_llm_new_token("secret reply", run_id=run_id)
        handler.on_llm_end(_llm_result(text="secret reply"), run_id=run_id)
        client.flush()
    finally:
        lc_integration.uninstall()
        client.shutdown()

    p = server.events_received[0]["properties"]
    assert "input" not in p
    assert "output" not in p
    assert p["gen_ai.usage.total_tokens"] == 9


# ---- install / uninstall lifecycle -----------------------------------------


def test_install_returns_handler_and_uninstall_clears() -> None:
    config = agenthog.Config.from_env_and_args(api_key="test", agent_id="agent-x", disable=True)
    client = agenthog.Client(config)
    try:
        handler = lc_integration.install(client)
        assert handler is not None
        # Second install is idempotent — returns the same handler.
        again = lc_integration.install(client)
        assert again is handler

        lc_integration.uninstall()
        # After uninstall, install again returns a fresh handler.
        handler2 = lc_integration.install(client)
        assert handler2 is not None
        assert handler2 is not handler
        lc_integration.uninstall()
    finally:
        client.shutdown()


def test_duration_uses_monotonic_clock(langchain_handler, monkeypatch: pytest.MonkeyPatch) -> None:
    handler, client, server = langchain_handler
    run_id = uuid4()

    handler.on_chat_model_start(
        _serialized(),
        [[HumanMessage(content="hi")]],
        run_id=run_id,
        invocation_params={"_type": "openai-chat", "model": "gpt-4o-mini"},
    )

    # Drag the wall clock backward by 10 minutes between start and end.
    original_time = time.time
    monkeypatch.setattr(time, "time", lambda: original_time() - 600)

    handler.on_llm_end(_llm_result(text="x"), run_id=run_id)
    client.flush()

    duration = server.events_received[0]["properties"]["duration_ms"]
    assert duration >= 0
