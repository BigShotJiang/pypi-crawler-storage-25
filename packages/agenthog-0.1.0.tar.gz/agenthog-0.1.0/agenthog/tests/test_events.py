"""Test ``agenthog._events`` Pydantic models."""

from __future__ import annotations

from datetime import datetime, timezone

import pytest
from pydantic import ValidationError

from agenthog._events import (
    EventType,
    LLMCallProperties,
    SDKEvent,
    SecurityAlertProperties,
)
from agenthog._ids import new_span_id, new_trace_id, uuid7


def _envelope_kwargs(**overrides: object) -> dict[str, object]:
    base: dict[str, object] = {
        "event_id": uuid7(),
        "event_type": EventType.LLM_CALL,
        "timestamp": datetime.now(timezone.utc),
        "trace_id": new_trace_id(),
        "span_id": new_span_id(),
        "agent_id": "agent-1",
        "task_run_id": str(uuid7()),
        "properties": {
            "gen_ai.system": "openai",
            "gen_ai.request.model": "gpt-4o-mini",
        },
    }
    base.update(overrides)
    return base


def test_envelope_validates_w3c_ids() -> None:
    SDKEvent.model_validate(_envelope_kwargs())


def test_envelope_rejects_bad_trace_id() -> None:
    with pytest.raises(ValidationError):
        SDKEvent.model_validate(_envelope_kwargs(trace_id="too-short"))


def test_envelope_rejects_naive_timestamp() -> None:
    with pytest.raises(ValidationError):
        SDKEvent.model_validate(_envelope_kwargs(timestamp=datetime.utcnow()))


def test_llm_call_alias_round_trip() -> None:
    props = LLMCallProperties.model_validate(
        {
            "gen_ai.system": "anthropic",
            "gen_ai.request.model": "claude-3-5-sonnet",
            "gen_ai.usage.total_tokens": 42,
        }
    )
    assert props.system == "anthropic"
    assert props.total_tokens == 42


def test_security_alert_closed_set_enforced() -> None:
    with pytest.raises(ValidationError):
        SecurityAlertProperties.model_validate(
            {"security.alert_type": "bogus", "security.severity": "high"}
        )


def test_envelope_invokes_per_type_validator() -> None:
    bad = _envelope_kwargs(properties={"gen_ai.system": "openai"})  # missing model
    with pytest.raises(ValidationError):
        SDKEvent.model_validate(bad)
