"""Shared fixtures for the SDK test suite."""

from __future__ import annotations

import gzip
import json
import logging
from collections import deque
from collections.abc import Callable
from typing import Any

import httpx
import pytest

from agenthog._client import AsyncClient, Client
from agenthog._config import Config


def _decode_body(req: httpx.Request) -> dict[str, Any]:
    body = req.content
    if req.headers.get("Content-Encoding") == "gzip":
        body = gzip.decompress(body)
    parsed: dict[str, Any] = json.loads(body.decode("utf-8"))
    return parsed


class MockServer:
    """Captures POSTed batches and lets tests script the response sequence."""

    def __init__(
        self,
        responses: list[httpx.Response] | None = None,
        default_status: int = 200,
    ) -> None:
        self.requests: list[httpx.Request] = []
        self.bodies: list[dict[str, Any]] = []
        self._responses: deque[httpx.Response] = deque(responses or [])
        self._default_status = default_status

    @property
    def request_count(self) -> int:
        return len(self.requests)

    @property
    def events_received(self) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for body in self.bodies:
            out.extend(body.get("events", []))
        return out

    def append_response(self, response: httpx.Response) -> None:
        self._responses.append(response)

    def handler(self, req: httpx.Request) -> httpx.Response:
        self.requests.append(req)
        try:
            self.bodies.append(_decode_body(req))
        except Exception:
            self.bodies.append({})
        if self._responses:
            return self._responses.popleft()
        return httpx.Response(self._default_status, json={"accepted": True})


# Type aliases used in test signatures.
MakeAsyncClient = Callable[..., "tuple[AsyncClient, MockServer]"]
MakeSyncClient = Callable[..., "tuple[Client, MockServer]"]


@pytest.fixture
def mock_server() -> MockServer:
    return MockServer()


@pytest.fixture
def make_async_client(mock_server: MockServer) -> Callable[..., tuple[AsyncClient, MockServer]]:
    def _make(**overrides: Any) -> tuple[AsyncClient, MockServer]:
        config = Config.from_env_and_args(
            api_key=overrides.pop("api_key", "test-key"),
            endpoint=overrides.pop("endpoint", "http://mock"),
            agent_id=overrides.pop("agent_id", "agent-test"),
            flush_interval_ms=overrides.pop("flush_interval_ms", 50),
            flush_batch_size=overrides.pop("flush_batch_size", 100),
            buffer_max_size=overrides.pop("buffer_max_size", 10000),
            disable=overrides.pop("disable", False),
            shutdown_timeout_s=overrides.pop("shutdown_timeout_s", 2.0),
            max_retries=overrides.pop("max_retries", 5),
            capture_content=overrides.pop("capture_content", True),
            sdk_version="0.1.0-test",
        )
        http = httpx.AsyncClient(transport=httpx.MockTransport(mock_server.handler))
        client = AsyncClient(config, http_client=http)
        return client, mock_server

    return _make


@pytest.fixture
def make_sync_client(mock_server: MockServer) -> Callable[..., tuple[Client, MockServer]]:
    def _make(**overrides: Any) -> tuple[Client, MockServer]:
        config = Config.from_env_and_args(
            api_key=overrides.pop("api_key", "test-key"),
            endpoint=overrides.pop("endpoint", "http://mock"),
            agent_id=overrides.pop("agent_id", "agent-test"),
            flush_interval_ms=overrides.pop("flush_interval_ms", 50),
            flush_batch_size=overrides.pop("flush_batch_size", 100),
            buffer_max_size=overrides.pop("buffer_max_size", 10000),
            disable=overrides.pop("disable", False),
            shutdown_timeout_s=overrides.pop("shutdown_timeout_s", 2.0),
            max_retries=overrides.pop("max_retries", 5),
            capture_content=overrides.pop("capture_content", True),
            sdk_version="0.1.0-test",
        )
        http = httpx.AsyncClient(transport=httpx.MockTransport(mock_server.handler))
        client = Client(config, http_client=http)
        return client, mock_server

    return _make


@pytest.fixture(autouse=True)
def _quiet_sdk_logger(caplog: pytest.LogCaptureFixture) -> None:
    caplog.set_level(logging.DEBUG, logger="agenthog.sdk")


def llm_call_props(model: str = "gpt-4o-mini", system: str = "openai") -> dict[str, Any]:
    return {
        "gen_ai.system": system,
        "gen_ai.request.model": model,
        "gen_ai.usage.input_tokens": 10,
        "gen_ai.usage.output_tokens": 20,
        "gen_ai.usage.total_tokens": 30,
        "duration_ms": 123.0,
    }


def business_event_props(name: str = "task_completed") -> dict[str, Any]:
    return {"business.event_name": name}
