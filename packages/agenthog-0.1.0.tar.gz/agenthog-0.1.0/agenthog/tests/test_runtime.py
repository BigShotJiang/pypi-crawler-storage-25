"""Test AgentRun sidecar integration."""

from __future__ import annotations

import contextlib
import json
import os
import socket
import tempfile
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any, ClassVar

import httpx
import pytest

from agenthog._runtime import (
    DEFAULT_RUNTIME_SOCKET,
    RuntimeClient,
    ToolDecision,
    get_runtime_client,
    is_in_runtime,
    reset_runtime_client,
    runtime_socket_path,
)

# ---- Env-var detection -----------------------------------------------------


def test_is_in_runtime_default_false(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("AGENTOS_RUNTIME", raising=False)
    assert is_in_runtime() is False
    assert runtime_socket_path() is None


def test_is_in_runtime_true_when_env_set(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTOS_RUNTIME", "1")
    assert is_in_runtime() is True
    assert runtime_socket_path() == Path(DEFAULT_RUNTIME_SOCKET)


def test_socket_path_overridden_by_env(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setenv("AGENTOS_RUNTIME", "1")
    custom = tmp_path / "custom.sock"
    monkeypatch.setenv("AGENTOS_RUNTIME_SOCKET", str(custom))
    assert runtime_socket_path() == custom


def test_get_runtime_client_returns_none_outside_runtime(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("AGENTOS_RUNTIME", raising=False)
    reset_runtime_client()
    assert get_runtime_client() is None


# ---- RuntimeClient over a mock UDS server ---------------------------------


class _UdsHandler(BaseHTTPRequestHandler):
    """Handles the syscall mediator's expected endpoints."""

    captured: ClassVar[list[tuple[str, dict[str, Any]]]] = []
    response_for_path: ClassVar[dict[str, dict[str, Any]]] = {}

    def log_message(self, format: str, *args: Any) -> None:
        # Silence test stdout chatter.
        return

    def do_POST(self) -> None:
        length = int(self.headers.get("Content-Length", "0") or "0")
        body_bytes = self.rfile.read(length) if length else b"{}"
        try:
            body = json.loads(body_bytes.decode("utf-8") or "{}")
        except Exception:
            body = {}
        type(self).captured.append((self.path, body))
        response = type(self).response_for_path.get(self.path, {"ok": True})
        payload = json.dumps(response).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)


class _UdsHTTPServer(HTTPServer):
    address_family = socket.AF_UNIX

    def server_bind(self) -> None:
        # Don't try to set SO_REUSEADDR / call getsockname on a UDS path.
        self.socket.bind(self.server_address)
        self.server_address = self.server_address  # type: ignore[assignment]

    def get_request(self) -> tuple[Any, Any]:
        request, _ = self.socket.accept()
        return request, ("",)


@pytest.fixture
def mock_sidecar() -> Any:
    """Spin up an HTTP server bound to a Unix socket for the test duration."""
    tmpdir = tempfile.mkdtemp(prefix="agentos-uds-")
    socket_path = os.path.join(tmpdir, "agentos.sock")

    _UdsHandler.captured = []
    _UdsHandler.response_for_path = {}

    server = _UdsHTTPServer(socket_path, _UdsHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()

    yield SimpleObj(
        socket_path=socket_path,
        captured=_UdsHandler.captured,
        responses=_UdsHandler.response_for_path,
    )

    server.shutdown()
    server.server_close()
    with contextlib.suppress(FileNotFoundError):
        os.unlink(socket_path)
    os.rmdir(tmpdir)


class SimpleObj:
    def __init__(self, **kwargs: Any) -> None:
        self.__dict__.update(kwargs)


async def test_runtime_client_routes_tool_call_through_uds(mock_sidecar: Any) -> None:
    mock_sidecar.responses["/v1/syscall/tool_call"] = {
        "allowed": True,
        "output": {"temp_c": 21},
        "redacted_fields": [],
    }
    client = RuntimeClient(mock_sidecar.socket_path)
    try:
        decision = await client.tool_call("get_weather", {"city": "Paris"})
        assert isinstance(decision, ToolDecision)
        assert decision.allowed is True
        assert decision.output == {"temp_c": 21}
    finally:
        await client.aclose()

    assert len(mock_sidecar.captured) == 1
    path, body = mock_sidecar.captured[0]
    assert path == "/v1/syscall/tool_call"
    assert body == {"tool": "get_weather", "input": {"city": "Paris"}}


async def test_runtime_client_blocked_call_returns_decision(
    mock_sidecar: Any,
) -> None:
    mock_sidecar.responses["/v1/syscall/tool_call"] = {
        "allowed": False,
        "error": "blocked by policy",
        "redacted_fields": ["input.api_key"],
    }
    client = RuntimeClient(mock_sidecar.socket_path)
    try:
        decision = await client.tool_call("send_email", {"api_key": "leaked"})
        assert decision.allowed is False
        assert decision.error == "blocked by policy"
        assert decision.redacted_fields == ["input.api_key"]
    finally:
        await client.aclose()


async def test_runtime_client_memory_op_routes_through_uds(mock_sidecar: Any) -> None:
    mock_sidecar.responses["/v1/syscall/memory_op"] = {"ok": True, "value": 42}
    client = RuntimeClient(mock_sidecar.socket_path)
    try:
        result = await client.memory_op("kv", "read", key="user_score")
        assert result == {"ok": True, "value": 42}
    finally:
        await client.aclose()
    path, body = mock_sidecar.captured[-1]
    assert path == "/v1/syscall/memory_op"
    assert body == {"subsystem": "kv", "operation": "read", "key": "user_score"}


async def test_runtime_client_route_decide_and_outcome(mock_sidecar: Any) -> None:
    mock_sidecar.responses["/v1/syscall/route_decide"] = {
        "arm_id": "a1",
        "model": "claude-3-5-sonnet",
        "decision_span_id": "deadbeefdeadbeef",
    }
    mock_sidecar.responses["/v1/syscall/route_outcome"] = {"ok": True}

    client = RuntimeClient(mock_sidecar.socket_path)
    try:
        decision = await client.route_decide("answer_well", {"context": "support"})
        assert decision["model"] == "claude-3-5-sonnet"
        assert decision["decision_span_id"] == "deadbeefdeadbeef"
        outcome = await client.route_outcome("deadbeefdeadbeef", reward=1.0)
        assert outcome["ok"] is True
    finally:
        await client.aclose()

    paths = [p for p, _ in mock_sidecar.captured]
    assert "/v1/syscall/route_decide" in paths
    assert "/v1/syscall/route_outcome" in paths


async def test_runtime_client_handles_transport_failure(tmp_path: Path) -> None:
    # Point at a socket that doesn't exist.
    client = RuntimeClient(tmp_path / "does-not-exist.sock")
    try:
        decision = await client.tool_call("x", {"y": 1})
        assert decision.allowed is False
        assert decision.error  # populated with the transport failure message
    finally:
        await client.aclose()


async def test_runtime_client_with_injected_http_client(mock_sidecar: Any) -> None:
    transport = httpx.AsyncHTTPTransport(uds=str(mock_sidecar.socket_path))
    http = httpx.AsyncClient(transport=transport, base_url="http://agentos-sidecar")
    client = RuntimeClient(http_client=http)
    try:
        mock_sidecar.responses["/v1/syscall/tool_call"] = {"allowed": True}
        decision = await client.tool_call("noop", {})
        assert decision.allowed is True
    finally:
        await http.aclose()
