"""Test flag SDK — local evaluation + cache + emission."""

from __future__ import annotations

import httpx
import pytest

from agenthog._flags import (
    FlagCache,
    FlagDefinition,
    evaluate,
    fetch_flags,
    parse_flag_definitions,
)

# ---- Pure evaluation -------------------------------------------------------


def test_default_when_no_rules() -> None:
    flag = FlagDefinition(key="k", default_value=False)
    value, variant, reason = evaluate(flag, {"user_id": "u1"})
    assert value is False
    assert variant is None
    assert reason == "default"


def test_rule_match_returns_rule_value() -> None:
    flag = FlagDefinition(
        key="k",
        rules=[
            {"priority": 1, "match": {"user_id": "u1"}, "value": True, "variant": "on"},
        ],
        default_value=False,
    )
    value, variant, reason = evaluate(flag, {"user_id": "u1"})
    assert value is True
    assert variant == "on"
    assert reason == "rule_match"


def test_priority_orders_rules() -> None:
    flag = FlagDefinition(
        key="k",
        rules=[
            {"priority": 99, "value": "low_priority"},
            {"priority": 1, "value": "high_priority"},
        ],
    )
    value, _, _ = evaluate(flag, {})
    assert value == "high_priority"


def test_percentage_rollout_is_stable_per_user() -> None:
    flag = FlagDefinition(
        key="rollout_50",
        rules=[{"priority": 1, "percentage": 50, "value": True}],
        default_value=False,
    )
    # Same user always lands in the same bucket.
    v1, _, _ = evaluate(flag, {"user_id": "user-100"})
    v2, _, _ = evaluate(flag, {"user_id": "user-100"})
    assert v1 == v2

    # Across many users, ~50% are in.
    on_count = sum(evaluate(flag, {"user_id": f"u{i}"})[0] is True for i in range(500))
    assert 200 <= on_count <= 300


def test_match_does_not_consume_percentage_unless_in_bucket() -> None:
    """A rule with both ``match`` AND ``percentage``: matched but bucket
    exceeds → continue to the next rule."""
    flag = FlagDefinition(
        key="k",
        rules=[
            # Match + percentage: 0% rollout → never fires even when matched.
            {"priority": 1, "match": {"env": "prod"}, "percentage": 0, "value": "rolled"},
            {"priority": 99, "value": "fallback"},
        ],
    )
    value, _, reason = evaluate(flag, {"env": "prod", "user_id": "u1"})
    assert value == "fallback"
    # Reason is rule_match (the second, no-percentage rule fires unconditionally).
    assert reason == "rule_match"


# ---- Wire format parsing ---------------------------------------------------


def test_parse_flag_definitions_from_envelope() -> None:
    payload = {
        "data": [
            {
                "key": "f1",
                "rules": [{"priority": 1, "value": True}],
                "experiment_id": "exp_a",
                "default_value": False,
            },
            {"key": "f2", "default_value": "blue"},
        ]
    }
    defs = parse_flag_definitions(payload)
    assert [f.key for f in defs] == ["f1", "f2"]
    assert defs[0].experiment_id == "exp_a"
    assert defs[1].default_value == "blue"


def test_parse_flag_definitions_skips_keyless() -> None:
    payload = [{"rules": []}, {"key": "ok"}]
    defs = parse_flag_definitions(payload)
    assert [f.key for f in defs] == ["ok"]


# ---- Cache behavior --------------------------------------------------------


def test_cache_replace_marks_fetched() -> None:
    cache = FlagCache()
    assert cache.is_empty
    cache.replace([FlagDefinition(key="x", default_value=1)])
    assert not cache.is_empty
    assert cache.get("x") is not None
    assert cache.get("missing") is None


# ---- HTTP fetch -----------------------------------------------------------


async def test_fetch_flags_handles_success() -> None:
    def handler(req: httpx.Request) -> httpx.Response:
        assert req.url.path == "/v1/flags"
        assert req.headers.get("X-API-Key") == "test"
        return httpx.Response(
            200,
            json={
                "data": [
                    {
                        "key": "use_gpt4",
                        "rules": [{"priority": 1, "value": True}],
                        "default_value": False,
                    }
                ]
            },
        )

    http = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    try:
        defs = await fetch_flags(http, "http://mock", "test")
    finally:
        await http.aclose()
    assert defs is not None
    assert len(defs) == 1
    assert defs[0].key == "use_gpt4"


async def test_fetch_flags_handles_5xx() -> None:
    http = httpx.AsyncClient(transport=httpx.MockTransport(lambda req: httpx.Response(500)))
    try:
        defs = await fetch_flags(http, "http://mock", "test")
    finally:
        await http.aclose()
    assert defs is None


# ---- End-to-end: client.flag ----------------------------------------------


async def test_client_flag_returns_default_when_cache_empty(
    make_async_client, caplog: pytest.LogCaptureFixture
) -> None:
    client, server = make_async_client(flush_batch_size=1)
    try:
        value = await client.flag("missing_flag", default="fallback", user_id="u1")
        assert value == "fallback"
        await client.flush()
    finally:
        await client.shutdown()
    # The flag_check event still emits.
    assert server.events_received[0]["event_type"] == "agent.flag_check"
    p = server.events_received[0]["properties"]
    assert p["flag.key"] == "missing_flag"
    assert p["flag.value"] == "fallback"
    assert p["flag.reason"] == "default"


async def test_client_flag_evaluates_against_cache(make_async_client) -> None:
    client, server = make_async_client(flush_batch_size=1)
    try:
        # Seed the cache directly (bypass the background fetcher).
        client.flag_cache.replace(
            [
                FlagDefinition(
                    key="use_gpt4",
                    rules=[
                        {"priority": 1, "match": {"user_id": "u-vip"}, "value": True},
                    ],
                    default_value=False,
                    experiment_id="exp_42",
                )
            ]
        )
        v_vip = await client.flag("use_gpt4", default=False, user_id="u-vip")
        v_other = await client.flag("use_gpt4", default=False, user_id="u-other")
        await client.flush()
    finally:
        await client.shutdown()

    assert v_vip is True
    assert v_other is False
    events = server.events_received
    assert len(events) == 2
    # Both events emit with key + reason populated.
    reasons = [e["properties"]["flag.reason"] for e in events]
    assert reasons[0] == "rule_match"
    assert reasons[1] == "default"
    # Experiment id surfaces.
    assert events[0]["properties"]["flag.experiment_id"] == "exp_42"
