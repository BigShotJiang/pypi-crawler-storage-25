"""Test W3C Trace Context propagation."""

from __future__ import annotations

from types import SimpleNamespace

import httpx

from agenthog._context import IdentityContext, current_context, push_context
from agenthog._trace_context import (
    TRACE_FLAG_SAMPLED,
    TraceParent,
    format_traceparent,
    httpx_request_hook,
    httpx_response_hook,
    parse_traceparent,
    start_span_from_request,
)

# ---- Parse / format --------------------------------------------------------


def test_parse_format_round_trip() -> None:
    trace_id = "4bf92f3577b34da6a3ce929d0e0e4736"
    span_id = "00f067aa0ba902b7"
    header = format_traceparent(trace_id, span_id, sampled=True)
    parsed = parse_traceparent(header)
    assert parsed is not None
    assert parsed.trace_id == trace_id
    assert parsed.span_id == span_id
    assert parsed.sampled is True
    assert parsed.trace_flags == TRACE_FLAG_SAMPLED


def test_parse_unsampled_flag() -> None:
    header = format_traceparent("a" * 32, "b" * 16, sampled=False)
    parsed = parse_traceparent(header)
    assert parsed is not None
    assert parsed.sampled is False
    assert parsed.trace_flags == 0


def test_parse_rejects_all_zero_ids() -> None:
    bad = "00-" + ("0" * 32) + "-" + ("0" * 16) + "-01"
    assert parse_traceparent(bad) is None


def test_parse_rejects_garbage() -> None:
    assert parse_traceparent("not-a-traceparent") is None
    assert parse_traceparent("") is None
    assert parse_traceparent(None) is None


def test_parse_accepts_future_versions_with_extra_fields() -> None:
    # W3C: readers must accept future versions and ignore extra trailing fields.
    header = "01-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01-extra-foo"
    parsed = parse_traceparent(header)
    assert parsed is not None
    assert parsed.trace_id == "4bf92f3577b34da6a3ce929d0e0e4736"
    assert parsed.version == "01"


# ---- httpx event hooks -----------------------------------------------------


def test_request_hook_injects_traceparent() -> None:
    ctx = IdentityContext(
        agent_id="agent-x",
        trace_id="4bf92f3577b34da6a3ce929d0e0e4736",
        span_id="00f067aa0ba902b7",
    )
    token = push_context(ctx)
    try:
        request = httpx.Request("GET", "http://example/")
        httpx_request_hook(request)
        assert request.headers["traceparent"] == (
            "00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01"
        )
    finally:
        from agenthog._context import pop_context

        pop_context(token)


def test_request_hook_noop_without_context() -> None:
    request = httpx.Request("GET", "http://example/")
    httpx_request_hook(request)
    assert "traceparent" not in request.headers


def test_request_hook_does_not_overwrite_existing_header() -> None:
    ctx = IdentityContext(
        agent_id="agent-x",
        trace_id="a" * 32,
        span_id="b" * 16,
    )
    token = push_context(ctx)
    try:
        request = httpx.Request("GET", "http://example/", headers={"traceparent": "preset"})
        httpx_request_hook(request)
        assert request.headers["traceparent"] == "preset"
    finally:
        from agenthog._context import pop_context

        pop_context(token)


def test_response_hook_captures_returned_traceparent() -> None:
    response = httpx.Response(
        200,
        headers={"traceparent": "00-" + ("c" * 32) + "-" + ("d" * 16) + "-01"},
        request=httpx.Request("GET", "http://example/"),
    )
    httpx_response_hook(response)
    parsed = response.extensions.get("agentos_traceparent")
    assert isinstance(parsed, TraceParent)
    assert parsed.trace_id == "c" * 32


# ---- start_span_from_request ----------------------------------------------


def test_start_span_from_request_uses_inbound_traceparent() -> None:
    inbound = "00-" + ("e" * 32) + "-" + ("f" * 16) + "-01"
    request = SimpleNamespace(headers={"traceparent": inbound})

    with start_span_from_request(request) as ctx:
        assert ctx.trace_id == "e" * 32
        assert ctx.parent_span_id == "f" * 16
        assert ctx.span_id is not None
        assert ctx.span_id != "f" * 16
    # After exit, context is restored.
    assert current_context().trace_id != "e" * 32


def test_start_span_from_request_opens_fresh_trace_if_no_header() -> None:
    request = SimpleNamespace(headers={})
    with start_span_from_request(request) as ctx:
        assert ctx.trace_id is not None
        # 32 hex chars
        assert len(ctx.trace_id) == 32
