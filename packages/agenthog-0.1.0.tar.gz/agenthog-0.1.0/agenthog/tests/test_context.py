"""Test identity context propagation across asyncio boundaries."""

from __future__ import annotations

import asyncio

from agenthog._context import current_context, push_context

from .conftest import MakeAsyncClient, business_event_props


async def test_context_propagates_across_create_task(make_async_client: MakeAsyncClient) -> None:
    client, server = make_async_client()
    try:
        observed: list[str] = []

        async with client.start_task_run("agent-x") as ctx:
            assert ctx.task_run_id

            async def child() -> None:
                inner = current_context()
                observed.append(inner.task_run_id or "")
                await client.emit("agent.business_event", business_event_props())

            await asyncio.create_task(child())
            await asyncio.create_task(child())

        await client.flush()

        assert observed[0] == observed[1]
        events = server.events_received
        assert len(events) == 2
        assert all(e["task_run_id"] == observed[0] for e in events)
    finally:
        await client.shutdown()


async def test_context_propagates_through_gather(make_async_client: MakeAsyncClient) -> None:
    client, server = make_async_client()
    try:
        async with client.start_task_run("agent-x"):
            captured = current_context()

            async def emit() -> None:
                await client.emit("agent.business_event", business_event_props())

            await asyncio.gather(emit(), emit(), emit())

        await client.flush()

        events = server.events_received
        assert len(events) == 3
        for ev in events:
            assert ev["trace_id"] == captured.trace_id
            assert ev["task_run_id"] == captured.task_run_id
    finally:
        await client.shutdown()


def test_push_pop_does_not_leak() -> None:
    before = current_context()
    token = push_context(before.with_task_run(agent_id="agent-z"))
    inside = current_context()
    assert inside.agent_id == "agent-z"
    from agenthog._context import pop_context

    pop_context(token)
    after = current_context()
    assert after == before
