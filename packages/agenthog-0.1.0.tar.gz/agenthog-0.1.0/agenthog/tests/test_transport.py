"""Test ``agenthog._transport`` buffering, retries, idempotency, gzip."""

from __future__ import annotations

import asyncio
import gzip
import json
from typing import Any

import httpx

from agenthog._config import Config
from agenthog._events import EventType
from agenthog._ids import new_span_id, new_trace_id, uuid7
from agenthog._metrics import Metrics
from agenthog._transport import Transport, _utcnow

from .conftest import MockServer, business_event_props, llm_call_props


def _event_dict(**overrides: Any) -> dict[str, Any]:
    base: dict[str, Any] = {
        "event_id": uuid7(),
        "event_type": EventType.BUSINESS_EVENT.value,
        "timestamp": _utcnow(),
        "trace_id": new_trace_id(),
        "span_id": new_span_id(),
        "agent_id": "agent-x",
        "task_run_id": str(uuid7()),
        "properties": business_event_props(),
        "sdk_name": "agenthog-python",
        "sdk_version": "0.1.0-test",
    }
    base.update(overrides)
    return base


async def _make_transport(server: MockServer, **overrides: Any) -> Transport:
    config = Config.from_env_and_args(
        api_key="test",
        endpoint="http://mock",
        agent_id="agent-x",
        flush_interval_ms=overrides.pop("flush_interval_ms", 50),
        flush_batch_size=overrides.pop("flush_batch_size", 100),
        buffer_max_size=overrides.pop("buffer_max_size", 10000),
        max_retries=overrides.pop("max_retries", 5),
        gzip_threshold_bytes=overrides.pop("gzip_threshold_bytes", 4096),
        sdk_version="0.1.0-test",
    )
    http = httpx.AsyncClient(transport=httpx.MockTransport(server.handler))
    transport = Transport(config, Metrics(), http_client=http)
    return transport


async def test_buffer_flushes_on_batch_size() -> None:
    server = MockServer()
    transport = await _make_transport(server, flush_batch_size=2, flush_interval_ms=10000)
    transport.start()
    try:
        for _ in range(2):
            transport.enqueue(_event_dict())
        await asyncio.sleep(0.1)
        assert len(server.events_received) == 2
    finally:
        await transport.aclose()


async def test_buffer_flushes_on_interval() -> None:
    server = MockServer()
    transport = await _make_transport(server, flush_interval_ms=50, flush_batch_size=1000)
    transport.start()
    try:
        transport.enqueue(_event_dict())
        await asyncio.sleep(0.2)
        assert len(server.events_received) == 1
    finally:
        await transport.aclose()


async def test_buffer_flushes_on_explicit_flush() -> None:
    server = MockServer()
    transport = await _make_transport(server, flush_interval_ms=10000, flush_batch_size=1000)
    try:
        transport.enqueue(_event_dict())
        await transport.flush()
        assert len(server.events_received) == 1
    finally:
        await transport.aclose()


async def test_buffer_flushes_on_shutdown() -> None:
    server = MockServer()
    transport = await _make_transport(server, flush_interval_ms=10000, flush_batch_size=1000)
    transport.start()
    transport.enqueue(_event_dict())
    await transport.aclose()
    assert len(server.events_received) == 1


async def test_retry_on_5xx_with_same_event_id() -> None:
    event = _event_dict()
    server = MockServer(
        responses=[
            httpx.Response(503),
            httpx.Response(503),
            httpx.Response(200, json={}),
        ]
    )
    transport = await _make_transport(server, flush_batch_size=1, max_retries=5)
    try:
        transport.enqueue(event)
        await transport.flush()

        assert server.request_count == 3
        # Same event_id across retries.
        ids = [body["events"][0]["event_id"] for body in server.bodies]
        assert ids[0] == ids[1] == ids[2] == str(event["event_id"])
        # Same Idempotency-Key across retries (per-batch UUIDv7).
        keys = [req.headers.get("Idempotency-Key") for req in server.requests]
        assert keys[0] == keys[1] == keys[2]
    finally:
        await transport.aclose()


async def test_retry_honors_retry_after_on_429() -> None:
    server = MockServer(
        responses=[
            httpx.Response(429, headers={"Retry-After": "0"}),
            httpx.Response(200, json={}),
        ]
    )
    transport = await _make_transport(server, flush_batch_size=1, max_retries=5)
    try:
        transport.enqueue(_event_dict())
        await transport.flush()
        assert server.request_count == 2
    finally:
        await transport.aclose()


async def test_retry_gives_up_after_max_attempts() -> None:
    server = MockServer(responses=[httpx.Response(500) for _ in range(10)])
    transport = await _make_transport(server, flush_batch_size=1, max_retries=2)
    try:
        transport.enqueue(_event_dict())
        await transport.flush()
        assert server.request_count == 2
        # Records the permanent failure.
        # (Counter assertion lives in the metrics test below.)
    finally:
        await transport.aclose()


async def test_buffer_overflow_drops_oldest() -> None:
    server = MockServer(default_status=200)
    transport = await _make_transport(
        server,
        flush_interval_ms=10000,
        flush_batch_size=1000,
        buffer_max_size=3,
    )
    # Don't start the periodic loop — we want to overflow before it drains.
    first_id = uuid7()
    last_id = None
    transport.enqueue(_event_dict(event_id=first_id))
    transport.enqueue(_event_dict())
    transport.enqueue(_event_dict())
    last_id = uuid7()
    transport.enqueue(_event_dict(event_id=last_id))
    transport.enqueue(_event_dict())

    await transport.flush()
    received_ids = {ev["event_id"] for ev in server.events_received}
    assert str(first_id) not in received_ids  # oldest dropped
    assert str(last_id) in received_ids
    await transport.aclose()


async def test_validation_failure_drops_event() -> None:
    server = MockServer()
    transport = await _make_transport(server)
    try:
        # Missing required gen_ai.request.model => ValidationError on enqueue.
        bad = _event_dict(
            event_type=EventType.LLM_CALL.value,
            properties={"gen_ai.system": "openai"},
        )
        ok = transport.enqueue(bad)
        assert ok is False
        await transport.flush()
        assert server.request_count == 0
    finally:
        await transport.aclose()


async def test_gzip_compresses_above_threshold() -> None:
    server = MockServer()
    transport = await _make_transport(server, flush_batch_size=1, gzip_threshold_bytes=128)
    big_props = llm_call_props()
    # Make the payload exceed 128 bytes via an extra-allow field.
    big_props["custom_payload"] = "x" * 500
    big_event = _event_dict(event_type=EventType.LLM_CALL.value, properties=big_props)
    try:
        transport.enqueue(big_event)
        await transport.flush()
        assert server.requests[0].headers.get("Content-Encoding") == "gzip"
        # Body decodes back to JSON.
        body = json.loads(gzip.decompress(server.requests[0].content).decode())
        assert body["events"][0]["event_id"] == str(big_event["event_id"])
    finally:
        await transport.aclose()


async def test_no_gzip_below_threshold() -> None:
    server = MockServer()
    transport = await _make_transport(server, flush_batch_size=1, gzip_threshold_bytes=10000)
    try:
        transport.enqueue(_event_dict())
        await transport.flush()
        assert server.requests[0].headers.get("Content-Encoding") is None
    finally:
        await transport.aclose()


async def test_disable_makes_enqueue_a_noop() -> None:
    server = MockServer()
    config = Config.from_env_and_args(
        api_key="test", endpoint="http://mock", agent_id="agent-x", disable=True
    )
    http = httpx.AsyncClient(transport=httpx.MockTransport(server.handler))
    transport = Transport(config, Metrics(), http_client=http)
    try:
        ok = transport.enqueue(_event_dict())
        assert ok is False
        await transport.flush()
        assert server.request_count == 0
    finally:
        await transport.aclose()
