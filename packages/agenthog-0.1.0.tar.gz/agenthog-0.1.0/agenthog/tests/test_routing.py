"""Test client.route() and client.route_outcome() against a mock server."""

from __future__ import annotations


async def test_route_decide_hits_endpoint(make_async_client) -> None:
    client, server = make_async_client()
    server.append_response = server.__class__.__init__
    # Pre-seed the mock server's response queue.
    import httpx

    server._responses.append(  # type: ignore[attr-defined]
        httpx.Response(
            200,
            json={
                "arm_id": "arm-a",
                "model": "claude-3-5-sonnet",
                "decision_span_id": "deadbeefdeadbeef",
            },
        )
    )

    try:
        result = await client.route(
            "answer_well", {"context": "support"}, candidates=["arm-a", "arm-b"]
        )
        assert result == {
            "arm_id": "arm-a",
            "model": "claude-3-5-sonnet",
            "decision_span_id": "deadbeefdeadbeef",
        }
    finally:
        await client.shutdown()

    decide_reqs = [r for r in server.requests if r.url.path == "/v1/routing/decide"]
    assert len(decide_reqs) == 1
    decide_bodies = [
        b
        for r, b in zip(server.requests, server.bodies, strict=False)
        if r.url.path == "/v1/routing/decide"
    ]
    assert decide_bodies[0]["goal"] == "answer_well"
    assert decide_bodies[0]["context"] == {"context": "support"}
    assert decide_bodies[0]["candidates"] == ["arm-a", "arm-b"]


async def test_route_outcome_hits_endpoint(make_async_client) -> None:
    client, server = make_async_client()
    import httpx

    server._responses.append(httpx.Response(200, json={"ok": True}))  # type: ignore[attr-defined]

    try:
        result = await client.route_outcome(
            "deadbeefdeadbeef",
            reward=1.0,
            success=True,
            duration_ms=42.0,
            cost_usd=0.001,
            feedback_kind="auto",
        )
        assert result == {"ok": True}
    finally:
        await client.shutdown()

    paired = [
        (r, b)
        for r, b in zip(server.requests, server.bodies, strict=False)
        if r.url.path == "/v1/routing/outcome"
    ]
    assert len(paired) == 1
    body = paired[0][1]
    assert body["decision_span_id"] == "deadbeefdeadbeef"
    assert body["reward"] == 1.0
    assert body["success"] is True
    assert body["feedback_kind"] == "auto"


async def test_route_returns_none_on_5xx(make_async_client) -> None:
    client, server = make_async_client()
    import httpx

    server._responses.append(httpx.Response(503))  # type: ignore[attr-defined]
    try:
        result = await client.route("goal", {})
        assert result is None
    finally:
        await client.shutdown()


async def test_route_through_runtime_sidecar(monkeypatch, make_async_client) -> None:
    """When AGENTOS_RUNTIME=1 and a sidecar is wired, route() bypasses HTTP."""
    from agenthog import _runtime

    class FakeRuntime:
        async def route_decide(self, goal, context, candidates):
            return {"arm_id": "via-sidecar", "model": "x", "decision_span_id": "ab" * 8}

        async def route_outcome(self, decision_span_id, **fields):
            return {"ok": True, "via": "sidecar"}

    fake = FakeRuntime()
    monkeypatch.setattr(_runtime, "get_runtime_client", lambda: fake)

    client, server = make_async_client()
    try:
        result = await client.route("g", {})
        assert result is not None
        assert result["arm_id"] == "via-sidecar"
        outcome = await client.route_outcome("aabbccddeeff0011", reward=1.0)
        assert outcome is not None
        assert outcome["via"] == "sidecar"
    finally:
        await client.shutdown()

    # No routing HTTP — the sidecar handled both calls.
    routing_reqs = [r for r in server.requests if r.url.path.startswith("/v1/routing/")]
    assert routing_reqs == []
