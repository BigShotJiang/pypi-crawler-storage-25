"""agenthog — Official Python SDK for AgentOS.

Install via ``pip install agenthog`` and ``import agenthog`` in your
code. The Python module and the PyPI distribution share the same name.

Per ``docs/spec/05-sdk-contract.md`` the public surface is small:

- :func:`init` constructs the appropriate :class:`Client` /
  :class:`AsyncClient` and stores a global default so module-level
  convenience functions work without explicitly passing it around.
- :func:`start_task_run`, :func:`start_span`, :func:`shutdown`,
  :func:`flush` proxy to the global default.
- :func:`get_default_client` exposes the global default for callers
  that prefer explicit dependency injection.

Critical invariant: no public method here may raise. All exceptions
flow to the internal ``agenthog.sdk`` logger.
"""

from __future__ import annotations

import os
import threading
from collections.abc import AsyncIterator, Iterator
from contextlib import asynccontextmanager, contextmanager
from typing import Any

from ._client import AsyncClient, Client
from ._config import Config
from ._context import IdentityContext, current_context
from ._logger import get_logger

__version__ = "0.1.0"
"""SDK version. Synced with ``[project].version`` in ``pyproject.toml``
by the publish workflow. SemVer: any breaking change bumps minor in
0.x and major in 1.x; new event types or optional fields are patches."""
__all__ = [
    "AsyncClient",
    "Client",
    "Config",
    "IdentityContext",
    "__version__",
    "current_context",
    "flush",
    "get_default_client",
    "init",
    "shutdown",
    "start_span",
    "start_task_run",
]

_log = get_logger("init")

_default_lock = threading.Lock()
_default_client: Client | AsyncClient | None = None


def init(
    api_key: str | None = None,
    *,
    endpoint: str | None = None,
    environment: str | None = None,
    capture_content: bool | None = None,
    flush_interval_ms: int | None = None,
    flush_batch_size: int | None = None,
    buffer_max_size: int | None = None,
    disable: bool | None = None,
    agent_id: str | None = None,
    project_id: str | None = None,
    kind: str = "sync",
) -> Client | AsyncClient:
    """Create a client and store it as the module-level default.

    Per the contract: explicit args override env vars. ``kind="async"``
    returns an :class:`AsyncClient` for use inside an existing event
    loop; the default ``"sync"`` returns a :class:`Client` that runs the
    transport on a managed background loop. Re-calling :func:`init`
    replaces the default; callers are responsible for shutting down
    the previous instance.
    """
    global _default_client
    config = Config.from_env_and_args(
        api_key=api_key,
        endpoint=endpoint,
        environment=environment,
        capture_content=capture_content,
        flush_interval_ms=flush_interval_ms,
        flush_batch_size=flush_batch_size,
        buffer_max_size=buffer_max_size,
        disable=disable,
        agent_id=agent_id,
        project_id=project_id,
        sdk_version=__version__,
    )
    if not config.api_key and not config.disable:
        _log.error(
            "AGENTOS_API_KEY not set and no api_key passed to init(); "
            "the SDK will buffer events but POSTs will likely 401. "
            "Pass disable=True to silence this in tests."
        )
    if kind not in ("sync", "async"):
        _log.error("init kind must be 'sync' or 'async'; got %r — defaulting to sync", kind)
        kind = "sync"
    client: Client | AsyncClient
    client = AsyncClient(config) if kind == "async" else Client(config)
    with _default_lock:
        _default_client = client
    return client


def get_default_client() -> Client | AsyncClient | None:
    """Return the global default client created by :func:`init`."""
    return _default_client


def _require_default() -> Client | AsyncClient | None:
    client = _default_client
    if client is None:
        _log.warning("agentos.init() not called yet; ignoring call")
    return client


@contextmanager
def start_task_run(
    agent_id: str | None = None,
    *,
    task_run_id: str | None = None,
    trace_id: str | None = None,
    user_id: str | None = None,
    session_id: str | None = None,
) -> Iterator[IdentityContext]:
    """Sync convenience: start a task_run on the global default client."""
    client = _require_default()
    if isinstance(client, Client):
        with client.start_task_run(
            agent_id=agent_id,
            task_run_id=task_run_id,
            trace_id=trace_id,
            user_id=user_id,
            session_id=session_id,
        ) as ctx:
            yield ctx
        return
    # No default client or async one — yield an empty context for
    # call-site safety. Async users should use ``async_start_task_run``
    # via the AsyncClient directly.
    yield current_context()


@asynccontextmanager
async def async_start_task_run(
    agent_id: str | None = None,
    *,
    task_run_id: str | None = None,
    trace_id: str | None = None,
    user_id: str | None = None,
    session_id: str | None = None,
) -> AsyncIterator[IdentityContext]:
    """Async convenience: start a task_run on the global default async client."""
    client = _require_default()
    if isinstance(client, AsyncClient):
        async with client.start_task_run(
            agent_id=agent_id,
            task_run_id=task_run_id,
            trace_id=trace_id,
            user_id=user_id,
            session_id=session_id,
        ) as ctx:
            yield ctx
        return
    yield current_context()


@contextmanager
def start_span(name: str, kind: str = "internal") -> Iterator[IdentityContext]:
    """Sync convenience: start a child span on the global default."""
    client = _require_default()
    if isinstance(client, Client):
        with client.start_span(name, kind=kind) as ctx:
            yield ctx
        return
    yield current_context()


def shutdown() -> None:
    """Flush and close the global default client. Idempotent."""
    global _default_client
    client = _default_client
    if client is None:
        return
    try:
        if isinstance(client, Client):
            client.shutdown()
        # AsyncClient shutdown is awaitable; users in async land call it directly.
    except Exception:
        _log.warning("default client shutdown failed", exc_info=True)
    finally:
        with _default_lock:
            _default_client = None


def flush() -> None:
    """Force-flush the global default sync client. Idempotent."""
    client = _default_client
    if isinstance(client, Client):
        client.flush()


def emit(
    event_type: str,
    properties: dict[str, Any],
    *,
    agent_id: str | None = None,
    task_run_id: str | None = None,
    user_id: str | None = None,
    session_id: str | None = None,
    environment: str | None = None,
) -> str | None:
    """Module-level emit on the default sync client. Async users call directly.

    Internal-ish: public manual ``log_*`` methods land in Prompt 6; this
    is the underlying path tests in this prompt drive.
    """
    client = _default_client
    if isinstance(client, Client):
        return client.emit(
            event_type,
            properties,
            agent_id=agent_id,
            task_run_id=task_run_id,
            user_id=user_id,
            session_id=session_id,
            environment=environment,
        )
    return None


def _fork_handler() -> None:
    """Reset SDK state in a forked child. Registered via ``os.register_at_fork``.

    Without this, gunicorn / uvicorn workers (which fork) would inherit
    the parent's HTTP connection pool, asyncio loop thread, and buffer
    — corrupting all three.
    """
    client = _default_client
    if client is None:
        return
    try:
        if isinstance(client, Client):
            client._reset_after_fork()
        else:
            client._reset_after_fork()
    except Exception:
        _log.warning("fork handler reset failed", exc_info=True)


if hasattr(os, "register_at_fork"):
    os.register_at_fork(after_in_child=_fork_handler)
