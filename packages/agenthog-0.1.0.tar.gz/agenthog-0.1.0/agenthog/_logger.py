"""Internal SDK logger — namespace ``agenthog.sdk``.

Default level: ``WARNING``. Users override via standard Python
``logging.getLogger("agenthog.sdk").setLevel(...)``. Sub-loggers per
submodule (``agenthog.sdk.transport``, ``agenthog.sdk.context``, etc.).
"""

from __future__ import annotations

import logging

_ROOT_NAME = "agenthog.sdk"

_root = logging.getLogger(_ROOT_NAME)
_root.setLevel(logging.WARNING)
if not _root.handlers:
    _root.addHandler(logging.NullHandler())


def get_logger(name: str | None = None) -> logging.Logger:
    """Return the SDK logger or a sub-logger.

    ``get_logger()`` returns the root ``agenthog.sdk`` logger.
    ``get_logger("transport")`` returns ``agenthog.sdk.transport``.
    """
    if not name:
        return _root
    return logging.getLogger(f"{_ROOT_NAME}.{name}")
