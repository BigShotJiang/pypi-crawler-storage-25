"""Pydantic event models — SDK-emitted subset of the platform's event schema.

Mirrors the platform monorepo's ``shared/schema/events.py`` for the
SDK-application surface event types only:

- ``agent.llm_call``
- ``agent.tool_call``
- ``agent.handoff``
- ``agent.retrieval_query``
- ``agent.eval``
- ``agent.flag_check``
- ``agent.business_event``
- ``agent.security_alert``
- ``agent.routing_decision`` (emitted by the routing helper, Prompt 6)
- ``agent.routing_outcome`` (same)

AgentRun / AgentSec server-emitted event types are intentionally
excluded — those land via different code paths.

Per ``docs/spec/03-event-schema.md``: closed-set enum fields validate
against frozensets, dotted-alias property keys travel on the wire,
``populate_by_name=True`` lets callers use either alias or Python
field name.
"""

from __future__ import annotations

import re
from datetime import datetime
from enum import Enum
from typing import Any
from uuid import UUID

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    field_validator,
    model_validator,
)

_TRACE_ID_RE = re.compile(r"^[0-9a-f]{32}$")
_SPAN_ID_RE = re.compile(r"^[0-9a-f]{16}$")
_ISO_4217_RE = re.compile(r"^[A-Z]{3}$")

_TOOL_STATUS_VALUES = frozenset({"success", "error", "timeout"})
_EVAL_EVALUATOR_VALUES = frozenset({"human", "llm", "heuristic", "code", "security"})
_FLAG_REASON_VALUES = frozenset({"default", "rule_match", "percentage_rollout"})
_ROUTING_POLICY_VALUES = frozenset({"thompson_sampling", "epsilon_greedy", "static"})
_ROUTING_FEEDBACK_VALUES = frozenset({"auto", "eval", "human", "business_event"})
_SECURITY_ALERT_TYPE_VALUES = frozenset(
    {
        "prompt_injection",
        "pii_detected",
        "jailbreak",
        "toxic_content",
        "data_exfiltration",
        "policy_violation",
    }
)
_SECURITY_SEVERITY_VALUES = frozenset({"critical", "high", "medium", "low", "info"})
_SECURITY_ACTION_TAKEN_VALUES = frozenset({"blocked", "flagged", "allowed", "redacted"})


class EventType(str, Enum):
    """SDK-emitted event types (subset of the platform's full enum)."""

    LLM_CALL = "agent.llm_call"
    TOOL_CALL = "agent.tool_call"
    AGENT_HANDOFF = "agent.handoff"
    EVAL = "agent.eval"
    FLAG_CHECK = "agent.flag_check"
    BUSINESS_EVENT = "agent.business_event"
    SECURITY_ALERT = "agent.security_alert"
    RETRIEVAL_QUERY = "agent.retrieval_query"
    ROUTING_DECISION = "agent.routing_decision"
    ROUTING_OUTCOME = "agent.routing_outcome"


# ---- Reusable sub-models ---------------------------------------------------


class CostInfo(BaseModel):
    model_config = ConfigDict(extra="forbid")

    input_cost: float = Field(ge=0)
    output_cost: float = Field(ge=0)
    total_cost: float = Field(ge=0)
    currency: str = Field(min_length=3, max_length=8)


class ErrorInfo(BaseModel):
    model_config = ConfigDict(extra="forbid")

    type: str = Field(min_length=1, max_length=128)
    message: str = Field(min_length=1, max_length=4096)


class LLMMessage(BaseModel):
    model_config = ConfigDict(extra="allow")

    role: str = Field(min_length=1, max_length=64)
    content: Any = None


class RetrievalDocument(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str = Field(min_length=1, max_length=512)
    score: float | None = None
    content: str | None = None
    metadata: dict[str, Any] | None = None


# ---- Properties models -----------------------------------------------------


class LLMCallProperties(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    system: str = Field(alias="gen_ai.system", min_length=1, max_length=64)
    request_model: str = Field(alias="gen_ai.request.model", min_length=1, max_length=128)

    response_model: str | None = Field(default=None, alias="gen_ai.response.model", max_length=128)
    temperature: float | None = Field(default=None, alias="gen_ai.request.temperature", ge=0, le=2)
    top_p: float | None = Field(default=None, alias="gen_ai.request.top_p", ge=0, le=1)
    max_tokens: int | None = Field(default=None, alias="gen_ai.request.max_tokens", ge=1)
    response_id: str | None = Field(default=None, alias="gen_ai.response.id", max_length=128)
    finish_reason: str | None = Field(
        default=None, alias="gen_ai.response.finish_reason", max_length=64
    )

    input_tokens: int | None = Field(default=None, alias="gen_ai.usage.input_tokens", ge=0)
    output_tokens: int | None = Field(default=None, alias="gen_ai.usage.output_tokens", ge=0)
    total_tokens: int | None = Field(default=None, alias="gen_ai.usage.total_tokens", ge=0)

    input: list[LLMMessage] | None = None
    output: list[LLMMessage] | None = None

    duration_ms: float | None = Field(default=None, ge=0)
    cost: CostInfo | None = None
    error: ErrorInfo | None = None
    stream: bool | None = None


class ToolCallProperties(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    name: str = Field(alias="tool.name", min_length=1, max_length=256)
    description: str | None = Field(default=None, alias="tool.description", max_length=2048)
    input: Any = Field(default=None, alias="tool.input")
    output: Any = Field(default=None, alias="tool.output")
    status: str | None = Field(default=None, alias="tool.status")
    duration_ms: float | None = Field(default=None, ge=0)
    error: ErrorInfo | None = None

    @field_validator("status")
    @classmethod
    def _validate_status(cls, v: str | None) -> str | None:
        if v is None:
            return v
        if v not in _TOOL_STATUS_VALUES:
            raise ValueError(f"tool.status must be one of {sorted(_TOOL_STATUS_VALUES)}")
        return v


class AgentHandoffProperties(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    target_agent_id: str = Field(min_length=1, max_length=256)
    reason: str | None = Field(default=None, max_length=4096)
    context: dict[str, Any] | None = None


class EvalResultProperties(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    name: str = Field(alias="eval.name", min_length=1, max_length=256)
    score: float = Field(alias="eval.score")
    label: str | None = Field(default=None, alias="eval.label", max_length=256)
    reason: str | None = Field(default=None, alias="eval.reason", max_length=4096)
    evaluator: str | None = Field(default=None, alias="eval.evaluator")
    ref_span_id: str | None = Field(default=None, alias="eval.ref_span_id")
    ref_task_run_id: str | None = Field(default=None, alias="eval.ref_task_run_id", max_length=256)

    @field_validator("evaluator")
    @classmethod
    def _validate_evaluator(cls, v: str | None) -> str | None:
        if v is None:
            return v
        if v not in _EVAL_EVALUATOR_VALUES:
            raise ValueError(f"eval.evaluator must be one of {sorted(_EVAL_EVALUATOR_VALUES)}")
        return v

    @field_validator("ref_span_id")
    @classmethod
    def _validate_ref_span_id(cls, v: str | None) -> str | None:
        if v is None:
            return v
        if not _SPAN_ID_RE.match(v):
            raise ValueError("eval.ref_span_id must be 16 lowercase hex chars")
        return v


class FlagCheckProperties(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    key: str = Field(alias="flag.key", min_length=1, max_length=256)
    value: Any = Field(alias="flag.value")
    variant: str | None = Field(default=None, alias="flag.variant", max_length=256)
    experiment_id: str | None = Field(default=None, alias="flag.experiment_id", max_length=256)
    reason: str | None = Field(default=None, alias="flag.reason")

    @field_validator("reason")
    @classmethod
    def _validate_reason(cls, v: str | None) -> str | None:
        if v is None:
            return v
        if v not in _FLAG_REASON_VALUES:
            raise ValueError(f"flag.reason must be one of {sorted(_FLAG_REASON_VALUES)}")
        return v


class BusinessEventProperties(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    event_name: str = Field(alias="business.event_name", min_length=1, max_length=256)
    revenue: float | None = Field(default=None, alias="business.revenue")
    currency: str | None = Field(default=None, alias="business.currency")
    metadata: dict[str, Any] | None = Field(default=None, alias="business.metadata")

    @field_validator("currency")
    @classmethod
    def _validate_currency(cls, v: str | None) -> str | None:
        if v is None:
            return v
        if not _ISO_4217_RE.match(v):
            raise ValueError("business.currency must be a 3-letter ISO 4217 code (e.g., USD)")
        return v


class SecurityAlertProperties(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    alert_type: str = Field(alias="security.alert_type", min_length=1, max_length=64)
    severity: str = Field(alias="security.severity", min_length=1, max_length=16)

    description: str | None = Field(default=None, alias="security.description", max_length=2048)
    scanner: str | None = Field(default=None, alias="security.scanner", max_length=128)
    ref_span_id: str | None = Field(
        default=None, alias="security.ref_span_id", min_length=16, max_length=16
    )
    action_taken: str | None = Field(default=None, alias="security.action_taken", max_length=32)
    details: dict[str, Any] | None = Field(default=None, alias="security.details")

    @field_validator("alert_type")
    @classmethod
    def _validate_alert_type(cls, v: str) -> str:
        if v not in _SECURITY_ALERT_TYPE_VALUES:
            raise ValueError(
                f"security.alert_type must be one of {sorted(_SECURITY_ALERT_TYPE_VALUES)}"
            )
        return v

    @field_validator("severity")
    @classmethod
    def _validate_severity(cls, v: str) -> str:
        if v not in _SECURITY_SEVERITY_VALUES:
            raise ValueError(
                f"security.severity must be one of {sorted(_SECURITY_SEVERITY_VALUES)}"
            )
        return v

    @field_validator("action_taken")
    @classmethod
    def _validate_action_taken(cls, v: str | None) -> str | None:
        if v is None:
            return v
        if v not in _SECURITY_ACTION_TAKEN_VALUES:
            raise ValueError(
                f"security.action_taken must be one of {sorted(_SECURITY_ACTION_TAKEN_VALUES)}"
            )
        return v

    @field_validator("ref_span_id")
    @classmethod
    def _validate_ref_span_id(cls, v: str | None) -> str | None:
        if v is None:
            return v
        if not _SPAN_ID_RE.match(v):
            raise ValueError(
                "security.ref_span_id must be 16 lowercase hex chars (W3C Trace Context)"
            )
        return v


class RetrievalQueryProperties(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    source: str = Field(alias="retrieval.source", min_length=1, max_length=256)
    query: str | None = Field(default=None, alias="retrieval.query", max_length=8192)
    top_k: int | None = Field(default=None, alias="retrieval.top_k", ge=0)
    results_count: int | None = Field(default=None, alias="retrieval.results_count", ge=0)
    documents: list[RetrievalDocument] | None = Field(default=None, alias="retrieval.documents")
    duration_ms: float | None = Field(default=None, ge=0)


class RoutingDecisionProperties(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    goal: str = Field(alias="routing.goal", min_length=1, max_length=128)
    context_bucket: str = Field(alias="routing.context_bucket", min_length=1, max_length=512)
    selected_arm: str = Field(alias="routing.selected_arm", min_length=1, max_length=128)
    selected_model: str = Field(alias="routing.selected_model", min_length=1, max_length=128)
    policy: str = Field(alias="routing.policy", min_length=1, max_length=64)

    alternatives_considered: list[str] | None = Field(
        default=None, alias="routing.alternatives_considered"
    )
    posterior_mean: float | None = Field(default=None, alias="routing.posterior_mean", ge=0, le=1)
    posterior_samples: dict[str, float] | None = Field(
        default=None, alias="routing.posterior_samples"
    )
    config_id: UUID | None = Field(default=None, alias="routing.config_id")

    @field_validator("policy")
    @classmethod
    def _validate_policy(cls, v: str) -> str:
        if v not in _ROUTING_POLICY_VALUES:
            raise ValueError(f"routing.policy must be one of {sorted(_ROUTING_POLICY_VALUES)}")
        return v


class RoutingOutcomeProperties(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    decision_span_id: str = Field(alias="routing.decision_span_id", min_length=16, max_length=16)
    reward: float = Field(alias="routing.reward", ge=0, le=1)

    success: bool | None = Field(default=None, alias="routing.success")
    duration_ms: float | None = Field(default=None, alias="routing.duration_ms", ge=0)
    cost_usd: float | None = Field(default=None, alias="routing.cost_usd", ge=0)
    eval_score: float | None = Field(default=None, alias="routing.eval_score")
    feedback_kind: str | None = Field(default=None, alias="routing.feedback_kind", max_length=32)

    @field_validator("decision_span_id")
    @classmethod
    def _validate_decision_span_id(cls, v: str) -> str:
        if not _SPAN_ID_RE.match(v):
            raise ValueError(
                "routing.decision_span_id must be 16 lowercase hex chars (W3C Trace Context)"
            )
        return v

    @field_validator("feedback_kind")
    @classmethod
    def _validate_feedback_kind(cls, v: str | None) -> str | None:
        if v is None:
            return v
        if v not in _ROUTING_FEEDBACK_VALUES:
            raise ValueError(
                f"routing.feedback_kind must be one of {sorted(_ROUTING_FEEDBACK_VALUES)}"
            )
        return v


PROPERTIES_MODEL_MAP: dict[EventType, type[BaseModel]] = {
    EventType.LLM_CALL: LLMCallProperties,
    EventType.TOOL_CALL: ToolCallProperties,
    EventType.AGENT_HANDOFF: AgentHandoffProperties,
    EventType.EVAL: EvalResultProperties,
    EventType.FLAG_CHECK: FlagCheckProperties,
    EventType.BUSINESS_EVENT: BusinessEventProperties,
    EventType.SECURITY_ALERT: SecurityAlertProperties,
    EventType.RETRIEVAL_QUERY: RetrievalQueryProperties,
    EventType.ROUTING_DECISION: RoutingDecisionProperties,
    EventType.ROUTING_OUTCOME: RoutingOutcomeProperties,
}


class SDKEvent(BaseModel):
    """Outgoing event envelope.

    Mirrors the platform's ``Event`` envelope shape but ``project_id``
    is optional — the server resolves it from the API key when absent.
    Per-event-type properties are validated against ``PROPERTIES_MODEL_MAP``.
    """

    model_config = ConfigDict(extra="forbid")

    event_id: UUID
    event_type: EventType
    timestamp: datetime
    trace_id: str = Field(min_length=32, max_length=32)
    span_id: str = Field(min_length=16, max_length=16)
    parent_span_id: str | None = Field(default=None, min_length=16, max_length=16)
    agent_id: str = Field(min_length=1, max_length=256)
    task_run_id: str | None = Field(default=None, max_length=256)
    project_id: UUID | None = None
    user_id: str | None = Field(default=None, max_length=256)
    session_id: str | None = Field(default=None, max_length=256)
    environment: str | None = Field(default=None, max_length=64)
    sdk_name: str | None = Field(default=None, max_length=64)
    sdk_version: str | None = Field(default=None, max_length=32)
    agent_version: str | None = Field(default=None, max_length=64)
    properties: dict[str, Any] = Field(default_factory=dict)

    @field_validator("trace_id")
    @classmethod
    def _validate_trace_id(cls, v: str) -> str:
        if not _TRACE_ID_RE.match(v):
            raise ValueError("trace_id must be 32 lowercase hex chars (W3C Trace Context)")
        return v

    @field_validator("span_id")
    @classmethod
    def _validate_span_id(cls, v: str) -> str:
        if not _SPAN_ID_RE.match(v):
            raise ValueError("span_id must be 16 lowercase hex chars (W3C Trace Context)")
        return v

    @field_validator("parent_span_id")
    @classmethod
    def _validate_parent_span_id(cls, v: str | None) -> str | None:
        if v is None:
            return v
        if not _SPAN_ID_RE.match(v):
            raise ValueError("parent_span_id must be 16 lowercase hex chars or null")
        return v

    @field_validator("timestamp")
    @classmethod
    def _validate_utc(cls, v: datetime) -> datetime:
        if v.tzinfo is None:
            raise ValueError("timestamp must be timezone-aware (UTC)")
        offset = v.utcoffset()
        if offset is None or offset.total_seconds() != 0:
            raise ValueError("timestamp must be in UTC (offset must be +00:00)")
        return v

    @model_validator(mode="after")
    def _validate_properties(self) -> SDKEvent:
        model_cls = PROPERTIES_MODEL_MAP.get(self.event_type)
        if model_cls is None:
            raise ValueError(
                f"event_type {self.event_type.value!r} has no entry in PROPERTIES_MODEL_MAP"
            )
        # Raise on bad properties so the transport's validation handler
        # logs + drops + counts. We keep the original aliased keys so the
        # outgoing JSON matches the platform schema.
        model_cls.model_validate(self.properties)
        return self


__all__ = [
    "PROPERTIES_MODEL_MAP",
    "AgentHandoffProperties",
    "BusinessEventProperties",
    "CostInfo",
    "ErrorInfo",
    "EvalResultProperties",
    "EventType",
    "FlagCheckProperties",
    "LLMCallProperties",
    "LLMMessage",
    "RetrievalDocument",
    "RetrievalQueryProperties",
    "RoutingDecisionProperties",
    "RoutingOutcomeProperties",
    "SDKEvent",
    "SecurityAlertProperties",
    "ToolCallProperties",
]
