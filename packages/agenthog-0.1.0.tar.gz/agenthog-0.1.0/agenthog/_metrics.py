"""Lightweight SDK-internal metrics.

Counters surfaced via ``client.metrics`` and an optional
``client.on_metric(callback)`` hook for live observability. Used in
Phase 8 to feed the platform's self-observation event stream.

All counters are integers, reset only on process restart (or after a
fork — see ``_transport.reset_after_fork``).
"""

from __future__ import annotations

import threading
from collections.abc import Callable

from ._logger import get_logger

_log = get_logger("metrics")

MetricCallback = Callable[[str, int], None]

# Canonical metric names. Anything else is rejected to keep the surface
# stable for downstream consumers.
_NAMES = (
    "events_sent",
    "events_dropped",
    "events_validation_failed",
    "events_retried",
    "events_failed_permanent",
)


class Metrics:
    """Thread-safe counters for SDK-internal observability."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._counters: dict[str, int] = dict.fromkeys(_NAMES, 0)
        self._callbacks: list[MetricCallback] = []

    def incr(self, name: str, delta: int = 1) -> None:
        """Increment a counter and notify callbacks. Never raises."""
        if name not in self._counters:
            return
        with self._lock:
            self._counters[name] += delta
            callbacks = list(self._callbacks)
        for cb in callbacks:
            try:
                cb(name, delta)
            except Exception:
                _log.warning("metric callback raised; ignoring", exc_info=True)

    def snapshot(self) -> dict[str, int]:
        """Return a copy of the counter dict."""
        with self._lock:
            return dict(self._counters)

    def add_callback(self, cb: MetricCallback) -> None:
        """Register a metric callback. ``cb(name, delta)`` per increment."""
        with self._lock:
            self._callbacks.append(cb)

    def reset(self) -> None:
        """Zero all counters. Used after fork to avoid double-counting."""
        with self._lock:
            for name in self._counters:
                self._counters[name] = 0
