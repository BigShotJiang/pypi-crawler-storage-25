# Reflex Python SDK

Public Python package for hosted Reflex training, datasets, managed instances,
and action inference.

```bash
python -m pip install reflex-sdk
```

The package installs the `reflex` Python module and a `reflex` CLI command in
the active Python environment. If your Python installer puts console scripts in
a directory that is not on `PATH`, use the module entry point instead:

```bash
python3 -m reflex --help
```

```python
import reflex
```

This package is intentionally separate from `inference/`, which owns model
serving and Prime worker runtime code.
