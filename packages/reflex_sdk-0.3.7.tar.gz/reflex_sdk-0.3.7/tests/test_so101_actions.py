from __future__ import annotations

import logging

import reflex.so101 as so101_module
from reflex.so101 import (
    LeRobotSo101RobotController,
    PortResolution,
    RawSo101RobotController,
    SO101_MOTOR_NAMES,
    SO101_NEUTRAL_POSITION,
    _sample_even_action_rows,
)


def test_even_action_sampler_uses_early_even_rows() -> None:
    rows = [[float(i)] * 6 for i in range(50)]

    sampled = _sample_even_action_rows(rows, 25)

    assert [index for index, _row in sampled] == list(range(0, 50, 2))
    assert [row[0] for _index, row in sampled] == [float(index) for index in range(0, 50, 2)]


def test_so101_controllers_sample_even_action_rows() -> None:
    rows = [[float(i)] * 6 for i in range(50)]

    raw = RawSo101RobotController(action_steps=4)
    lerobot = LeRobotSo101RobotController(action_steps=4)

    assert raw._sample_rows(rows) == [rows[0], rows[2], rows[4], rows[6]]
    assert lerobot._sample_rows(rows) == [rows[0], rows[2], rows[4], rows[6]]


def test_lerobot_reset_to_neutral_sends_waypoint_sequence() -> None:
    class FakeRobot:
        def __init__(self) -> None:
            self.positions = {f"{name}.pos": 20.0 for name in SO101_MOTOR_NAMES}
            self.commands: list[dict[str, float]] = []

        def get_observation(self) -> dict[str, float]:
            return dict(self.positions)

        def send_action(self, action: dict[str, float]) -> dict[str, float]:
            self.commands.append(dict(action))
            sent: dict[str, float] = {}
            for key, value in action.items():
                self.positions[key] = value
                sent[key] = self.positions[key]
            return sent

    controller = LeRobotSo101RobotController(
        neutral_position=SO101_NEUTRAL_POSITION,
        max_relative_target=10.0,
        hold_seconds=0,
        neutral_tolerance=0.01,
        neutral_max_steps=3,
    )
    fake_robot = FakeRobot()
    controller.robot = fake_robot

    result = controller.reset_to_neutral()

    assert result["settled"] is True
    assert result["steps"] == 2
    assert result["target"] == SO101_NEUTRAL_POSITION
    assert len(fake_robot.commands) == 2
    first_waypoint = {f"{name}.pos": 10.0 for name in SO101_MOTOR_NAMES}
    neutral_command = {f"{name}.pos": 0.0 for name in SO101_MOTOR_NAMES}
    assert fake_robot.commands == [first_waypoint, neutral_command]
    assert controller.summary()["neutralReset"] == result


def test_lerobot_enter_captures_current_pose_as_neutral(monkeypatch) -> None:
    captured = {name: float(index * 3) for index, name in enumerate(SO101_MOTOR_NAMES)}

    class FakeConfig:
        def __init__(self, **kwargs: object) -> None:
            self.kwargs = kwargs

    class FakeRobot:
        def __init__(self, config: FakeConfig) -> None:
            self.config = config
            self.connected = False

        def connect(self, *, calibrate: bool) -> None:
            self.connected = True

        def disconnect(self) -> None:
            self.connected = False

        def get_observation(self) -> dict[str, float]:
            return {f"{name}.pos": value for name, value in captured.items()}

        def send_action(self, action: dict[str, float]) -> dict[str, float]:
            raise AssertionError("captured neutral pose should not require reset commands")

    monkeypatch.setattr(so101_module, "_load_lerobot_so101", lambda: (FakeRobot, FakeConfig))
    monkeypatch.setattr(
        so101_module,
        "resolve_so101_port",
        lambda port="": PortResolution("/dev/cu.fake", 1_000_000, {}, []),
    )

    with LeRobotSo101RobotController(hold_seconds=0) as controller:
        assert controller.neutral_position == captured
        result = controller.reset_to_neutral()

    assert result["target"] == captured
    assert result["settled"] is True
    assert result["steps"] == 0


def test_lerobot_action_suppresses_clamp_warning_only(caplog) -> None:
    class FakeRobot:
        def __init__(self) -> None:
            self.positions = {f"{name}.pos": 0.0 for name in SO101_MOTOR_NAMES}

        def get_observation(self) -> dict[str, float]:
            return dict(self.positions)

        def send_action(self, action: dict[str, float]) -> dict[str, float]:
            logging.warning("Relative goal position magnitude had to be clamped to be safe.\n%s", {"joint": 1})
            logging.warning("unrelated robot warning")
            self.positions.update(action)
            return dict(action)

    controller = LeRobotSo101RobotController(hold_seconds=0)
    controller.robot = FakeRobot()

    with caplog.at_level(logging.WARNING):
        controller.apply_action_row(source_index=0, row=[1.0] * len(SO101_MOTOR_NAMES))
        logging.warning("Relative goal position magnitude had to be clamped to be safe")
        logging.getLogger("lerobot.test").warning(
            "Relative goal position magnitude had to be clamped to be safe.\n%s",
            {"joint": 2},
        )
        logging.getLogger("lerobot.test").warning("child unrelated robot warning")
        logging.warning("delayed unrelated robot warning")

    messages = [record.getMessage() for record in caplog.records]
    assert not any(
        message.startswith("Relative goal position magnitude had to be clamped to be safe")
        for message in messages
    )
    assert "unrelated robot warning" in messages
    assert "child unrelated robot warning" in messages
    assert "delayed unrelated robot warning" in messages