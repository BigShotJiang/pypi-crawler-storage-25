"""Smoke test for PROD.1 — authorize+connect end-to-end against live prod.

Skipped when REFLEX_API_KEY is unset (default CI runs).
Run manually: REFLEX_API_KEY=rfx_... pytest sdk/python/tests/test_prod1_smoke.py -v
"""
import os
import pytest

from reflex.auth_runner import maybe_authorize, AuthError, _resolve_api_key


@pytest.mark.skipif(
    not os.environ.get("REFLEX_API_KEY"),
    reason="set REFLEX_API_KEY to run the prod smoke test",
)
def test_authorize_session_returns_grant():
    """Authorize a real session against prod Convex; verify grant fields."""
    grant = maybe_authorize(base_model="molmoact2-bimanualyam", robot_type="yam_bimanual")
    assert grant is not None, "authorize returned None with API key set"
    assert grant.session_token.startswith("rfx_session_")
    assert grant.worker_url.startswith("https://")
    assert grant.expires_at > 0
    assert grant.session_id
    assert grant.base_model == "molmoact2-bimanualyam"
    # Header format
    header = grant.auth_header()
    assert header["authorization"] == f"Bearer {grant.session_token}"


def test_resolve_api_key_no_creds():
    """When no env var + no creds file, resolve_api_key returns None."""
    saved = os.environ.pop("REFLEX_API_KEY", None)
    try:
        # Only pass when no ~/.reflex/api_key exists either; this is a unit
        # test guard so we don't assert on the user's actual filesystem
        key = _resolve_api_key()
        if key is not None:
            pytest.skip("user has saved creds; this test only meaningful without")
        assert key is None
    finally:
        if saved is not None:
            os.environ["REFLEX_API_KEY"] = saved


@pytest.mark.skipif(
    not os.environ.get("REFLEX_API_KEY"),
    reason="set REFLEX_API_KEY to run the prod smoke test",
)
def test_grant_has_valid_worker_url():
    """Worker URL should be the Modal endpoint that accepts /webrtc-offer."""
    grant = maybe_authorize()
    assert grant is not None
    assert "modal" in grant.worker_url, f"worker_url should be Modal: {grant.worker_url}"
