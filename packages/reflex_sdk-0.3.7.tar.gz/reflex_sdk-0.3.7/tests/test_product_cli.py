from __future__ import annotations

import json
import subprocess
import sys
import time
from datetime import timezone, timedelta
from pathlib import Path
from urllib import request

from typer.testing import CliRunner

from reflex.cli import build_reflex_app
from reflex import product
import reflex.cli as cli_module


LOCAL_TEST_TZ = timezone(timedelta(hours=-8), "PST")


def _use_test_local_timezone(monkeypatch) -> None:
    monkeypatch.setattr(
        cli_module,
        "_local_datetime",
        lambda value: value.astimezone(LOCAL_TEST_TZ),
    )


class FakeResponse:
    def __init__(self, payload: dict[str, object]) -> None:
        self.payload = payload

    def __enter__(self) -> "FakeResponse":
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        return None

    def read(self) -> bytes:
        return json.dumps(self.payload).encode("utf-8")


def _request_body(req: request.Request) -> dict[str, object]:
    data = req.data
    assert data is not None
    parsed = json.loads(data.decode("utf-8"))
    assert isinstance(parsed, dict)
    return parsed


def test_root_help_mentions_json_default() -> None:
    runner = CliRunner()

    result = runner.invoke(build_reflex_app(), ["--help"])

    assert result.exit_code == 0, result.output
    assert "--json" in result.output
    assert "structured JSON" in result.output
    assert "human-readable text" in result.output


def test_python_module_entrypoint_shows_cli_help() -> None:
    result = subprocess.run(
        [sys.executable, "-m", "reflex", "--help"],
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )

    assert result.returncode == 0, result.stdout
    assert "Usage:" in result.stdout
    assert "User-facing CLI for Reflex hosted robot workflows." in result.stdout


def test_short_help_alias_works_everywhere() -> None:
    runner = CliRunner()

    for args in (["-h"], ["login", "-h"], ["datasets", "-h"], ["datasets", "list", "-h"]):
        result = runner.invoke(build_reflex_app(), args)
        assert result.exit_code == 0, result.output
        assert "Usage:" in result.output
        assert "-h" in result.output
        assert "--help" in result.output


def test_inference_run_help_defaults_to_robot_mode() -> None:
    runner = CliRunner()

    result = runner.invoke(build_reflex_app(), ["inference", "run", "--help"])

    assert result.exit_code == 0, result.output
    assert "--fixture" not in result.output
    assert "--port" in result.output
    assert "SO-101" in result.output


def test_signup_calls_better_auth_email_endpoint(monkeypatch) -> None:
    seen: list[tuple[str, dict[str, object]]] = []

    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        seen.append((req.full_url, _request_body(req)))
        return FakeResponse(
            {
                "user": {
                    "id": "user_123",
                    "email": "cli@example.test",
                    "name": "CLI User",
                },
                "token": "better-auth-session-secret",
            }
        )

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "signup",
            "--name",
            "CLI User",
            "--email",
            "CLI@EXAMPLE.TEST",
            "--password",
            "password1234",
            "--site-url",
            "https://platform.example",
        ],
    )

    assert result.exit_code == 0, result.output
    assert seen == [
        (
            "https://platform.example/api/auth/sign-up/email",
            {
                "name": "CLI User",
                "email": "cli@example.test",
                "password": "password1234",
            },
        )
    ]
    assert "Reflex account created" in result.output
    assert "Email: cli@example.test" in result.output
    assert "reflex login" in result.output
    assert "reflex login --open-browser" not in result.output
    assert "reflex whoami" in result.output
    assert "password1234" not in result.output
    assert "better-auth-session-secret" not in result.output


def test_signup_rejects_short_password_without_network(monkeypatch) -> None:
    seen: list[request.Request] = []

    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        seen.append(req)
        return FakeResponse({})

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "signup",
            "--name",
            "CLI User",
            "--email",
            "cli@example.test",
            "--password",
            "short",
            "--site-url",
            "https://platform.example",
            "--json",
        ],
    )

    assert result.exit_code == 1, result.output
    assert seen == []
    output = json.loads(result.output)
    assert output["ok"] is False
    assert "at least 8 characters" in output["error"]


def test_whoami_reports_organization(monkeypatch) -> None:
    seen: list[tuple[str, dict[str, object]]] = []

    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        body = _request_body(req)
        seen.append((req.full_url, body))
        if body["path"] == "publicApi:closeSession":
            return FakeResponse(
                {
                    "status": "success",
                    "value": {
                        "ok": True,
                        "sessionId": body["args"]["sessionId"],
                        "status": "closed",
                    },
                },
            )
        return FakeResponse(
            {
                "status": "success",
                "value": {
                    "ok": True,
                    "orgId": "org_123",
                    "keyId": "key_123",
                    "keyName": "CLI key",
                    "organization": {
                        "id": "org_123",
                        "name": "Acme Robotics",
                        "slug": "acme-robotics",
                    },
                },
            }
        )

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "whoami",
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
            "--site-url",
            "https://platform.example",
        ],
    )

    assert result.exit_code == 0, result.output
    assert seen == [
        (
            "https://convex.example/api/query",
            {
                "path": "publicApi:whoami",
                "args": {"apiKey": "rfx_test"},
                "format": "json",
            },
        )
    ]
    assert "Logged in to Reflex" in result.output
    assert "Organization: Acme Robotics" in result.output
    assert "Organization slug: acme-robotics" in result.output
    assert "Organization ID: org_123" in result.output
    assert "API key: CLI key" in result.output
    assert "Dashboard: https://platform.example" in result.output
    assert not result.output.lstrip().startswith("{")


def test_global_json_flag_applies_to_subcommand(monkeypatch) -> None:
    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        return FakeResponse(
            {
                "status": "success",
                "value": {
                    "ok": True,
                    "orgId": "org_123",
                    "keyId": "key_123",
                    "keyName": "CLI key",
                },
            }
        )

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "--json",
            "whoami",
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
        ],
    )

    assert result.exit_code == 0, result.output
    output = json.loads(result.output)
    assert output["ok"] is True
    assert output["account"]["orgId"] == "org_123"


def test_dataset_register_calls_convex_action(monkeypatch) -> None:
    seen: list[tuple[str, dict[str, object]]] = []

    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        seen.append((req.full_url, _request_body(req)))
        return FakeResponse({"status": "success", "value": {"ok": True, "datasetId": "ds_123"}})

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "datasets",
            "register",
            "hf://datasets/acme/robot",
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
            "--json",
        ],
    )

    assert result.exit_code == 0, result.output
    assert seen == [
        (
            "https://convex.example/api/action",
            {
                "path": "publicApi:registerDataset",
                "args": {"apiKey": "rfx_test", "hfSourceUri": "hf://datasets/acme/robot"},
                "format": "json",
            },
        )
    ]
    output = json.loads(result.output)
    assert output["ok"] is True
    assert output["dataset"]["datasetId"] == "ds_123"


def test_dataset_register_exits_nonzero_for_public_api_error(monkeypatch) -> None:
    seen: list[tuple[str, dict[str, object]]] = []

    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        seen.append((req.full_url, _request_body(req)))
        return FakeResponse({"status": "success", "value": {"ok": False, "reason": "unknown_key"}})

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "datasets",
            "register",
            "hf://datasets/acme/robot",
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
            "--json",
        ],
    )

    assert result.exit_code == 1, result.output
    assert seen == [
        (
            "https://convex.example/api/action",
            {
                "path": "publicApi:registerDataset",
                "args": {"apiKey": "rfx_test", "hfSourceUri": "hf://datasets/acme/robot"},
                "format": "json",
            },
        )
    ]
    output = json.loads(result.output)
    assert output["ok"] is False
    assert "Unable to register dataset: unknown_key" in output["error"]


def test_dataset_list_human_output_is_concise(monkeypatch) -> None:
    seen: list[tuple[str, dict[str, object]]] = []

    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        body = _request_body(req)
        seen.append((req.full_url, body))
        if body["path"] == "publicApi:closeSession":
            return FakeResponse(
                {
                    "status": "success",
                    "value": {
                        "ok": True,
                        "sessionId": body["args"]["sessionId"],
                        "status": "closed",
                    },
                },
            )
        return FakeResponse(
            {
                "status": "success",
                "value": {
                    "ok": True,
                    "datasets": [
                        {
                            "_id": "ds_123",
                            "orgId": "org_123",
                            "createdByUserId": "user_123",
                            "name": "PushT",
                            "hfSourceUri": "hf://datasets/lerobot/pusht",
                            "hfRepo": "lerobot/pusht",
                            "hfResolvedRevision": "resolved-commit",
                            "repositorySizeBytes": 123456789,
                            "lerobotMetadataJson": "{\"features\":{\"observation\":{}}}",
                            "validationMessage": "Validated public Hugging Face LeRobot metadata.",
                            "lastValidatedAt": 4102444800000,
                            "createdAt": 4102358400000,
                            "updatedAt": 4102444800000,
                            "deleted": False,
                        },
                        {
                            "_id": "ds_456",
                            "name": "Kitchen tasks",
                            "hfSourceUri": "hf://datasets/acme/kitchen",
                            "hfRepo": "acme/kitchen",
                            "hfPath": "episodes/2026/05/08/calibration-and-long-horizon-evaluation",
                            "hfRevision": "main-with-a-long-revision-name-that-should-not-be-trimmed",
                            "createdAt": 4102358400000,
                            "updatedAt": 4102358400000,
                            "deleted": False,
                        },
                    ],
                },
            }
        )

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    _use_test_local_timezone(monkeypatch)
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "datasets",
            "list",
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
        ],
    )

    assert result.exit_code == 0, result.output
    assert seen == [
        (
            "https://convex.example/api/mutation",
            {
                "path": "publicApi:listDatasets",
                "args": {"apiKey": "rfx_test"},
                "format": "json",
            },
        )
    ]
    assert "1. PushT" in result.output
    assert "ID: ds_123" in result.output
    assert "Source: lerobot/pusht" in result.output
    assert "resolved-commit" not in result.output
    assert "Status: validated" in result.output
    assert "Updated: 2099-12-31 16:00:00 PST" in result.output
    assert "2. Kitchen tasks" in result.output
    assert (
        "Source: acme/kitchen/episodes/2026/05/08/"
        "calibration-and-long-horizon-evaluation@"
        "main-with-a-long-revision-name-that-should-not-be-trimmed"
    ) in result.output
    assert "Use `reflex datasets list --json` for comprehensive dataset metadata." in result.output
    assert "..." not in result.output
    assert "lerobotMetadataJson" not in result.output
    assert "createdByUserId" not in result.output
    assert "repositorySizeBytes" not in result.output


def test_login_request_can_return_approval_url_without_waiting(monkeypatch, tmp_path: Path) -> None:
    seen: list[tuple[str, dict[str, object]]] = []

    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        seen.append((req.full_url, _request_body(req)))
        return FakeResponse(
            {
                "status": "success",
                "value": {"requestId": "cli_req_123", "expiresAt": 4102444800000},
            },
        )

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    opened: list[str] = []
    monkeypatch.setattr(cli_module.webbrowser, "open", lambda url: opened.append(url) or True)
    _use_test_local_timezone(monkeypatch)
    monkeypatch.setenv("REFLEX_CONFIG_DIR", str(tmp_path))
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "login",
            "--convex-url",
            "https://convex.example",
            "--site-url",
            "https://platform.example",
            "--hostname",
            "agent-host",
            "--timeout",
            "0",
        ],
    )

    assert result.exit_code == 0, result.output
    assert seen == [
        (
            "https://convex.example/api/mutation",
            {
                "path": "cliAuth:createRequest",
                "args": {"hostname": "agent-host"},
                "format": "json",
            },
        )
    ]
    assert "Reflex CLI login" in result.output
    assert "Open this link to authorize this terminal:" in result.output
    assert "https://platform.example/cli/authorize?requestId=cli_req_123" in result.output
    assert "Expires: in" in result.output
    assert "2099-12-31 16:00:00 PST" in result.output
    assert "Browser: opened automatically" in result.output
    assert "This command is not waiting" in result.output
    assert not result.output.lstrip().startswith("{")
    assert opened == ["https://platform.example/cli/authorize?requestId=cli_req_123"]
    assert not (tmp_path / "credentials.json").exists()


def test_inference_run_without_mock_uses_so101_robot(monkeypatch) -> None:
    seen: list[tuple[str, dict[str, object]]] = []
    stream: dict[str, object] = {"kwargs": None, "observations": []}
    robot: dict[str, object] = {"kwargs": None, "applied": [], "neutral": []}

    class FakeActionStream:
        def __init__(self, **kwargs: object) -> None:
            stream["kwargs"] = kwargs

        def __enter__(self) -> "FakeActionStream":
            return self

        def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
            return None

        def send_observation_frame(self, observation: dict[str, object]) -> int:
            stream["observations"].append(observation)
            return int(observation.get("seq", 0) or 0)

        def recv_action(self) -> dict[str, object]:
            return {
                "type": "action_chunk",
                "seq": 0,
                "action_shape": [1, 6],
                "actions_aloha": [[0.1, 0.2, 0.3, 0.4, 0.5, 0.6]],
            }

    class FakeSo101RobotController:
        def __init__(self, **kwargs: object) -> None:
            robot["kwargs"] = kwargs

        def __enter__(self) -> "FakeSo101RobotController":
            return self

        def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
            return None

        def capture_observation(self, *, prompt: str) -> dict[str, object]:
            return {
                "prompt": prompt,
                "state": [0.0] * 14,
                "images": {"cam_high": {"encoding": "png_base64", "data": "zero"}},
            }

        def apply_action_chunk(self, frame: dict[str, object]) -> dict[str, object]:
            robot["applied"].append(frame)
            return {"appliedMotor": "wrist_flex"}

        def reset_to_neutral(self) -> dict[str, object]:
            robot["neutral"].append("reset")
            return {"settled": True, "steps": 2}

        def summary(self) -> dict[str, object]:
            return {
                "type": "so101",
                "port": "/dev/cu.test",
                "baudrate": 1_000_000,
                "actionsApplied": [{"appliedMotor": "wrist_flex"}],
                "neutralReset": {"settled": True, "steps": 2},
            }

    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        body = _request_body(req)
        seen.append((req.full_url, body))
        if body["path"] == "publicApi:closeSession":
            return FakeResponse(
                {
                    "status": "success",
                    "value": {
                        "ok": True,
                        "sessionId": body["args"]["sessionId"],
                        "status": "closed",
                    },
                },
            )
        return FakeResponse(
            {
                "status": "success",
                "value": {
                    "ok": True,
                    "sessionId": "session_123",
                    "primeUrl": "https://prime.example",
                    "streamUrl": "wss://prime.example/v1/actions",
                    "transport": "websocket",
                    "protocol": "reflex.actions.v1",
                    "token": "rfx_session_token",
                },
            },
        )

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    monkeypatch.setattr(cli_module, "ActionStream", FakeActionStream)
    monkeypatch.setattr(cli_module, "So101RobotController", FakeSo101RobotController)
    monkeypatch.setattr(
        cli_module,
        "_hold_final_robot_pose_before_neutral_reset",
        lambda *, log_ticks: robot["neutral"].append(("hold", log_ticks)),
    )
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "inference",
            "run",
            "--artifact",
            "model_123",
            "--prompt",
            "Pick up the cube",
            "--port",
            "/dev/cu.test",
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
            "--json",
        ],
    )

    assert result.exit_code == 0, result.output
    assert seen == [
        (
            "https://convex.example/api/mutation",
            {
                "path": "publicApi:authorizeSession",
                "args": {
                    "apiKey": "rfx_test",
                    "actionAdapter": "so101_joint",
                    "baseModel": "pi0.5",
                    "modelId": "model_123",
                    "mode": "dry_run",
                },
                "format": "json",
            },
        ),
        (
            "https://convex.example/api/mutation",
            {
                "path": "publicApi:closeSession",
                "args": {
                    "apiKey": "rfx_test",
                    "sessionId": "session_123",
                    "reason": "cli_run_complete",
                },
                "format": "json",
            },
        ),
    ]
    output = json.loads(result.output)
    assert output["ok"] is True
    assert output["inferenceSession"]["sessionId"] == "session_123"
    assert "token" not in output["inferenceSession"]
    assert output["stream"]["transport"] == "websocket"
    assert output["stream"]["mock"] is False
    assert output["stream"]["observationsSent"] == 1
    assert output["stream"]["lastActionChunk"]["action_shape"] == [1, 6]
    assert output["stream"]["robot"]["type"] == "so101"
    assert output["stream"]["robot"]["port"] == "/dev/cu.test"
    assert output["stream"]["robot"]["neutralReset"] == {"settled": True, "steps": 2}
    assert output["closedSession"]["status"] == "closed"
    assert stream["kwargs"]["url"] == "wss://prime.example/v1/actions"
    assert stream["kwargs"]["api_key"] == "rfx_session_token"
    assert stream["kwargs"]["robot"] == "so101"
    assert stream["kwargs"]["action_adapter"] == "so101_joint"
    assert stream["observations"] == [
        {
            "images": {"cam_high": {"encoding": "png_base64", "data": "zero"}},
            "prompt": "Pick up the cube",
            "action_adapter": "so101_joint",
            "robot": "so101",
            "seq": 0,
            "state": [0.0] * 14,
        }
    ]
    assert robot["kwargs"] == {
        "port": "/dev/cu.test",
        "cameras": ["cam_high"],
        "action_motor": "wrist_flex",
        "max_delta_raw": 260,
        "max_relative_target": 10.0,
        "action_steps": 25,
        "hold_seconds": 0.08,
        "backend": "lerobot",
        "robot_id": "",
    }
    assert robot["applied"] == [output["stream"]["lastActionChunk"]]
    assert robot["neutral"] == [("hold", False), "reset"]


def test_inference_run_prefetches_and_swaps_so101_action_chunks(monkeypatch) -> None:
    stream: dict[str, object] = {"observations": []}
    robot: dict[str, object] = {"applied": [], "neutral": []}

    class FakeActionStream:
        def __init__(self, **kwargs: object) -> None:
            self.seq = 0

        def __enter__(self) -> "FakeActionStream":
            return self

        def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
            return None

        def send_observation_frame(self, observation: dict[str, object]) -> int:
            self.seq = int(observation.get("seq", 0) or 0)
            stream["observations"].append(observation)
            return self.seq

        def recv_action(self) -> dict[str, object]:
            seq = self.seq
            return {
                "type": "action_chunk",
                "seq": seq,
                "action_shape": [50, 6],
                "actions_so101": [[float(seq * 100 + index)] * 6 for index in range(50)],
            }

    class StreamingSo101RobotController:
        def __init__(self, **kwargs: object) -> None:
            self.action_steps = int(kwargs["action_steps"])

        def __enter__(self) -> "StreamingSo101RobotController":
            return self

        def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
            return None

        def capture_observation(self, *, prompt: str) -> dict[str, object]:
            return {
                "prompt": prompt,
                "state": [0.0] * 6,
                "images": {"cam_high": {"encoding": "png_base64", "data": "zero"}},
            }

        def sample_action_rows(self, frame: dict[str, object]) -> list[tuple[int, list[float]]]:
            rows = frame["actions_so101"]
            assert isinstance(rows, list)
            return [
                (index, row)
                for index, row in enumerate(rows[:50])
                if index % 2 == 0 and isinstance(row, list)
            ][: self.action_steps]

        def apply_action_row(self, *, source_index: int, row: list[float]) -> dict[str, object]:
            robot["applied"].append((source_index, row[0]))
            if source_index >= 16:
                time.sleep(0.005)
            return {"sourceIndex": source_index, "target": row}

        def apply_action_chunk(self, frame: dict[str, object]) -> dict[str, object]:
            raise AssertionError("streaming SO-101 path should not block on apply_action_chunk")

        def reset_to_neutral(self) -> dict[str, object]:
            robot["neutral"].append("reset")
            return {"settled": True, "steps": 1}

        def summary(self) -> dict[str, object]:
            return {
                "type": "so101",
                "actionsApplied": robot["applied"],
                "neutralReset": {"settled": True, "steps": 1},
            }

    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        body = _request_body(req)
        if body["path"] == "publicApi:closeSession":
            return FakeResponse(
                {
                    "status": "success",
                    "value": {
                        "ok": True,
                        "sessionId": body["args"]["sessionId"],
                        "status": "closed",
                    },
                },
            )
        return FakeResponse(
            {
                "status": "success",
                "value": {
                    "ok": True,
                    "sessionId": "session_prefetch",
                    "primeUrl": "https://prime.example",
                    "streamUrl": "wss://prime.example/v1/actions",
                    "token": "rfx_session_token",
                },
            },
        )

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    monkeypatch.setattr(cli_module, "ActionStream", FakeActionStream)
    monkeypatch.setattr(cli_module, "So101RobotController", StreamingSo101RobotController)
    monkeypatch.setattr(
        cli_module,
        "_hold_final_robot_pose_before_neutral_reset",
        lambda *, log_ticks: robot["neutral"].append(("hold", log_ticks)),
    )
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "inference",
            "run",
            "--steps",
            "2",
            "--prompt",
            "Wave",
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
            "--json",
        ],
    )

    assert result.exit_code == 0, result.output
    assert [obs["seq"] for obs in stream["observations"]] == [0, 1]
    applied = robot["applied"]
    assert (14, 14.0) in applied
    assert (48, 48.0) not in applied
    assert (48, 148.0) in applied
    assert robot["neutral"] == [("hold", False), "reset"]


def test_inference_run_mock_stream_updates_joints(monkeypatch) -> None:
    stream: dict[str, object] = {"observations": []}

    class FakeActionStream:
        def __init__(self, **kwargs: object) -> None:
            stream["kwargs"] = kwargs
            self.calls = 0

        def __enter__(self) -> "FakeActionStream":
            return self

        def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
            return None

        def send_observation_frame(self, observation: dict[str, object]) -> int:
            stream["observations"].append(observation)
            return int(observation.get("seq", 0) or 0)

        def recv_action(self) -> dict[str, object]:
            self.calls += 1
            value = float(self.calls)
            return {
                "type": "action_chunk",
                "seq": self.calls - 1,
                "action_shape": [1, 6],
                "actions_aloha": [[value, value + 1, value + 2, value + 3, value + 4, value + 5]],
            }

    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        body = _request_body(req)
        if body["path"] == "publicApi:closeSession":
            return FakeResponse(
                {
                    "status": "success",
                    "value": {
                        "ok": True,
                        "sessionId": body["args"]["sessionId"],
                        "status": "closed",
                    },
                },
            )
        return FakeResponse(
            {
                "status": "success",
                "value": {
                    "ok": True,
                    "sessionId": "session_mock",
                    "primeUrl": "https://prime.example",
                    "streamUrl": "wss://prime.example/v1/actions",
                    "token": "rfx_session_token",
                },
            },
        )

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    monkeypatch.setattr(cli_module, "ActionStream", FakeActionStream)
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "inference",
            "run",
            "--mock",
            "--steps",
            "2",
            "--prompt",
            "Stack the blocks",
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
            "--json",
        ],
    )

    assert result.exit_code == 0, result.output
    output = json.loads(result.output)
    assert output["stream"]["mock"] is True
    assert output["stream"]["observationsSent"] == 2
    assert output["stream"]["finalMockJoints"] == [2.0, 3.0, 4.0, 5.0, 6.0, 7.0]
    first, second = stream["observations"]
    assert first["state"][:6] == [0.0] * 6
    assert second["state"][:6] == [1.0, 2.0, 3.0, 4.0, 5.0, 6.0]
    assert first["prompt"] == "Stack the blocks"
    assert second["prompt"] == "Stack the blocks"
    assert "cam_high" in first["images"]


def test_inference_run_falls_back_to_authorized_http_when_websocket_rejected(monkeypatch) -> None:
    seen: list[tuple[str, dict[str, object]]] = []
    http_observations: list[dict[str, object]] = []

    class RejectingActionStream:
        def __init__(self, **kwargs: object) -> None:
            pass

        def __enter__(self) -> "RejectingActionStream":
            raise RuntimeError("WebSocket handshake failed: HTTP/1.1 403 Forbidden.")

    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        body = _request_body(req)
        seen.append((req.full_url, body))
        if req.full_url == "https://prime.example/":
            observation = body["observation"]
            assert isinstance(observation, dict)
            http_observations.append(observation)
            return FakeResponse(
                {
                    "ok": True,
                    "request_id": body["request_id"],
                    "session_id": "session_http",
                    "seq": body["seq"],
                    "action_shape": [1, 6],
                    "actions_aloha": [[1, 2, 3, 4, 5, 6]],
                    "timing": {
                        "server_infer_ms": 3.0,
                        "server_total_ms": 5.0,
                        "server_prepost_ms": 2.0,
                    },
                }
            )
        if body["path"] == "publicApi:closeSession":
            return FakeResponse(
                {
                    "status": "success",
                    "value": {
                        "ok": True,
                        "sessionId": body["args"]["sessionId"],
                        "status": "closed",
                    },
                },
            )
        return FakeResponse(
            {
                "status": "success",
                "value": {
                    "ok": True,
                    "sessionId": "session_http",
                    "primeUrl": "https://prime.example",
                    "streamUrl": "wss://prime.example/v1/actions",
                    "token": "rfx_session_token",
                },
            }
        )

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    monkeypatch.setattr(cli_module, "ActionStream", RejectingActionStream)
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "inference",
            "run",
            "--mock",
            "--steps",
            "1",
            "--prompt",
            "Wave hello",
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
            "--json",
        ],
    )

    assert result.exit_code == 0, result.output
    output = json.loads(result.output)
    assert output["stream"]["transport"] == "http"
    assert output["stream"]["url"] == "https://prime.example/"
    assert output["stream"]["observationsSent"] == 1
    assert output["stream"]["lastActionChunk"]["actions_aloha"] == [[1, 2, 3, 4, 5, 6]]
    assert output["stream"]["lastActionChunk"]["timing"]["server_infer_ms"] == 3.0
    assert output["stream"]["lastActionChunk"]["timing"]["server_total_ms"] == 5.0
    assert http_observations[0]["prompt"] == "Wave hello"
    assert seen == [
        (
            "https://convex.example/api/mutation",
            {
                "path": "publicApi:authorizeSession",
                "args": {
                    "apiKey": "rfx_test",
                    "actionAdapter": "so101_joint",
                    "baseModel": "pi0.5",
                    "robotType": "so101",
                },
                "format": "json",
            },
        ),
        (
            "https://prime.example/",
            {
                "action_adapter": "so101_joint",
                "observation": http_observations[0],
                "request_id": "0",
                "robot": "so101",
                "robot_type": "so101",
                "seq": 0,
                "session_id": "session_http",
            },
        ),
        (
            "https://convex.example/api/mutation",
            {
                "path": "publicApi:closeSession",
                "args": {
                    "apiKey": "rfx_test",
                    "sessionId": "session_http",
                    "reason": "cli_run_complete",
                },
                "format": "json",
            },
        ),
    ]


def test_inference_run_human_output_logs_each_tick(monkeypatch) -> None:
    class FakeActionStream:
        def __init__(self, **kwargs: object) -> None:
            self.calls = 0

        def __enter__(self) -> "FakeActionStream":
            return self

        def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
            return None

        def send_observation_frame(self, observation: dict[str, object]) -> int:
            return int(observation.get("seq", 0) or 0)

        def recv_action(self) -> dict[str, object]:
            self.calls += 1
            return {
                "type": "action_chunk",
                "seq": self.calls - 1,
                "action_shape": [3, 6],
                "actions_aloha": [[0.1] * 6, [0.2] * 6, [0.3] * 6],
                "timing": {
                    "server_infer_ms": 12.0,
                    "server_total_ms": 20.0,
                    "server_prepost_ms": 8.0,
                },
            }

    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        body = _request_body(req)
        if body["path"] == "publicApi:closeSession":
            return FakeResponse(
                {
                    "status": "success",
                    "value": {
                        "ok": True,
                        "sessionId": body["args"]["sessionId"],
                        "status": "closed",
                    },
                },
            )
        return FakeResponse(
            {
                "status": "success",
                "value": {
                    "ok": True,
                    "sessionId": "session_mock",
                    "primeUrl": "https://prime.example",
                    "streamUrl": "wss://prime.example/v1/actions",
                    "token": "rfx_session_token",
                },
            },
        )

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    monkeypatch.setattr(cli_module, "ActionStream", FakeActionStream)
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "inference",
            "run",
            "--mock",
            "--steps",
            "2",
            "--prompt",
            "Stack the blocks",
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
        ],
    )

    assert result.exit_code == 0, result.output
    assert "inference tick 1/2" in result.output
    assert "inference tick 2/2" in result.output
    assert "recv_ms=" in result.output
    assert "network_ms=" in result.output
    assert "server_ms=20.0" in result.output
    assert "infer_ms=" not in result.output
    assert "total_ms=" not in result.output
    assert "action_shape=3x6" in result.output
    assert "Inference run complete" in result.output
    assert "Last action shape: 3x6" in result.output
    assert "Last server time: 20.0 ms" in result.output
    assert "Last inference time:" not in result.output
    assert "Actions aloha" not in result.output
    assert not result.output.lstrip().startswith("{")


def test_inference_run_ctrl_c_closes_authorized_session(monkeypatch) -> None:
    seen: list[tuple[str, dict[str, object]]] = []

    class InterruptingActionStream:
        def __init__(self, **kwargs: object) -> None:
            pass

        def __enter__(self) -> "InterruptingActionStream":
            return self

        def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
            return None

        def send_observation_frame(self, observation: dict[str, object]) -> int:
            return int(observation.get("seq", 0) or 0)

        def recv_action(self) -> dict[str, object]:
            raise KeyboardInterrupt

    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        body = _request_body(req)
        seen.append((req.full_url, body))
        if body["path"] == "publicApi:closeSession":
            return FakeResponse(
                {
                    "status": "success",
                    "value": {
                        "ok": True,
                        "sessionId": body["args"]["sessionId"],
                        "status": "closed",
                    },
                },
            )
        return FakeResponse(
            {
                "status": "success",
                "value": {
                    "ok": True,
                    "sessionId": "session_interrupted",
                    "primeUrl": "https://prime.example",
                    "streamUrl": "wss://prime.example/v1/actions",
                    "token": "rfx_session_token",
                },
            },
        )

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    monkeypatch.setattr(cli_module, "ActionStream", InterruptingActionStream)
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "inference",
            "run",
            "--mock",
            "--steps",
            "2",
            "--prompt",
            "Stack the blocks",
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
            "--json",
        ],
    )

    assert result.exit_code == 130, result.output
    output = json.loads(result.output)
    assert output == {
        "closedSession": {
            "ok": True,
            "sessionId": "session_interrupted",
            "status": "closed",
        },
        "error": "Interrupted by user.",
        "ok": False,
    }
    assert seen == [
        (
            "https://convex.example/api/mutation",
            {
                "path": "publicApi:authorizeSession",
                "args": {
                    "apiKey": "rfx_test",
                    "actionAdapter": "so101_joint",
                    "baseModel": "pi0.5",
                    "robotType": "so101",
                },
                "format": "json",
            },
        ),
        (
            "https://convex.example/api/mutation",
            {
                "path": "publicApi:closeSession",
                "args": {
                    "apiKey": "rfx_test",
                    "sessionId": "session_interrupted",
                    "reason": "cli_interrupted",
                },
                "format": "json",
            },
        ),
    ]


def test_inference_run_requires_prompt(monkeypatch) -> None:
    def fail_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        raise AssertionError("prompt validation should run before Convex calls")

    monkeypatch.setattr(product.request, "urlopen", fail_urlopen)
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "inference",
            "run",
            "--mock",
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
            "--json",
        ],
    )

    assert result.exit_code != 0
    assert "--prompt" in result.output


def test_sessions_start_sends_requested_mode(monkeypatch) -> None:
    seen: list[tuple[str, dict[str, object]]] = []

    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        seen.append((req.full_url, _request_body(req)))
        return FakeResponse(
            {
                "status": "success",
                "value": {
                    "ok": True,
                    "sessionId": "session_apply",
                    "primeUrl": "https://prime.example",
                    "token": "rfx_session_token",
                    "mode": "apply_actions",
                },
            },
        )

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "sessions",
            "start",
            "--artifact",
            "model_123",
            "--mode",
            "apply_actions",
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
            "--json",
        ],
    )

    assert result.exit_code == 0, result.output
    assert seen == [
        (
            "https://convex.example/api/mutation",
            {
                "path": "publicApi:authorizeSession",
                "args": {
                    "apiKey": "rfx_test",
                    "baseModel": "pi0.5",
                    "modelId": "model_123",
                    "mode": "apply_actions",
                },
                "format": "json",
            },
        )
    ]
    output = json.loads(result.output)
    assert output["ok"] is True
    assert output["session"]["sessionId"] == "session_apply"


def test_deploy_from_json_spec_calls_public_api(monkeypatch, tmp_path: Path) -> None:
    spec = tmp_path / "reflex.yaml"
    spec.write_text(
        "\n".join(
            [
                "name: pi05-pick-cube",
                "modelId: model_123",
                "robotSchemaId: schema_123",
                "runtime: reflex",
                "mode: dry_run",
            ]
        )
    )
    seen: list[tuple[str, dict[str, object]]] = []

    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        seen.append((req.full_url, _request_body(req)))
        return FakeResponse(
            {
                "status": "success",
                "value": {
                    "ok": True,
                    "deploymentId": "deployment_123",
                    "deduped": False,
                },
            },
        )

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "deploy",
            "--file",
            str(spec),
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
            "--json",
        ],
    )

    assert result.exit_code == 0, result.output
    assert seen[0][0] == "https://convex.example/api/mutation"
    assert seen[0][1]["path"] == "publicApi:createDeployment"
    args = seen[0][1]["args"]
    assert args["apiKey"] == "rfx_test"
    assert args["name"] == "pi05-pick-cube"
    assert args["modelId"] == "model_123"
    assert args["robotSchemaId"] == "schema_123"
    assert args["mode"] == "dry_run"
    assert json.loads(args["specJson"])["name"] == "pi05-pick-cube"
    output = json.loads(result.output)
    assert output["deployment"]["deploymentId"] == "deployment_123"


def test_doctor_calls_readiness_check(monkeypatch) -> None:
    seen: list[tuple[str, dict[str, object]]] = []

    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        seen.append((req.full_url, _request_body(req)))
        return FakeResponse(
            {
                "status": "success",
                "value": {
                    "ok": True,
                    "readinessCheckId": "check_123",
                    "status": "passed",
                    "passed": True,
                    "checks": [],
                },
            },
        )

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "doctor",
            "deployment_123",
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
            "--json",
        ],
    )

    assert result.exit_code == 0, result.output
    assert seen == [
        (
            "https://convex.example/api/mutation",
            {
                "path": "publicApi:runReadinessCheck",
                "args": {"apiKey": "rfx_test", "deploymentId": "deployment_123"},
                "format": "json",
            },
        )
    ]


def test_robot_schema_register_extracts_safe_stop(monkeypatch, tmp_path: Path) -> None:
    schema = tmp_path / "robot.yaml"
    schema.write_text(
        "\n".join(
            [
                "schema_version: robot_schema.v1",
                "actions:",
                "  action:",
                "    shape: [2]",
                "    safe_stop: [0.0, 0.0]",
                "    safe_stop_mode: zero_velocity",
            ]
        )
    )
    seen: list[tuple[str, dict[str, object]]] = []

    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        seen.append((req.full_url, _request_body(req)))
        return FakeResponse(
            {
                "status": "success",
                "value": {
                    "ok": True,
                    "robotSchemaId": "schema_123",
                    "deduped": False,
                },
            },
        )

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "robots",
            "register-schema",
            "so101-lab-a",
            "--schema",
            str(schema),
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
            "--json",
        ],
    )

    assert result.exit_code == 0, result.output
    args = seen[0][1]["args"]
    assert args["name"] == "so101-lab-a"
    assert args["hasExplicitSafeStop"] is True
    assert args["safeStopMode"] == "zero_velocity"
    assert args["actionDim"] == 2


def test_sessions_promote_calls_public_api(monkeypatch) -> None:
    seen: list[tuple[str, dict[str, object]]] = []

    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        seen.append((req.full_url, _request_body(req)))
        return FakeResponse(
            {
                "status": "success",
                "value": {
                    "ok": True,
                    "sessionId": "session_123",
                    "mode": "apply_actions",
                },
            },
        )

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "sessions",
            "promote",
            "session_123",
            "--to",
            "apply_actions",
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
            "--json",
        ],
    )

    assert result.exit_code == 0, result.output
    assert seen == [
        (
            "https://convex.example/api/mutation",
            {
                "path": "publicApi:promoteSession",
                "args": {
                    "apiKey": "rfx_test",
                    "sessionId": "session_123",
                    "mode": "apply_actions",
                },
                "format": "json",
            },
        )
    ]


def test_robot_connect_authorizes_deployment_robot_session_once(monkeypatch) -> None:
    seen: list[tuple[str, dict[str, object]]] = []

    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        body = _request_body(req)
        seen.append((req.full_url, body))
        if body["path"] == "publicApi:claimRobotPairingToken":
            return FakeResponse({"status": "success", "value": {"ok": True, "robotId": "robot_123"}})
        if body["path"] == "publicApi:robotHeartbeat":
            return FakeResponse({"status": "success", "value": {"ok": True, "robotId": "robot_123"}})
        return FakeResponse(
            {
                "status": "success",
                "value": {
                    "ok": True,
                    "sessionId": "session_123",
                    "deploymentId": "deployment_123",
                    "robotId": "robot_123",
                    "mode": "dry_run",
                },
            },
        )

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "connect",
            "--deployment",
            "deployment_123",
            "--robot",
            "robot_123",
            "--pairing-token",
            "rfx_robot_pair",
            "--once",
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
            "--json",
        ],
    )

    assert result.exit_code == 0, result.output
    assert [item[1]["path"] for item in seen] == [
        "publicApi:claimRobotPairingToken",
        "publicApi:authorizeSession",
        "publicApi:robotHeartbeat",
    ]
    assert seen[1][1]["args"] == {
        "apiKey": "rfx_test",
        "baseModel": "pi0.5",
        "deploymentId": "deployment_123",
        "robotId": "robot_123",
        "mode": "dry_run",
    }
    assert seen[2][1]["args"]["transport"] == "drtc_pending"


def test_robot_connect_executes_observe_and_apply_with_drtc(monkeypatch, tmp_path: Path) -> None:
    observe = tmp_path / "observe.py"
    apply = tmp_path / "apply.py"
    applied = tmp_path / "applied.json"
    observe.write_text(
        "import json\n"
        "print(json.dumps({'state': [0.0, 0.1], 'images': {}, 'task': 'pick'}))\n",
        encoding="utf-8",
    )
    apply.write_text(
        "import pathlib, sys\n"
        f"pathlib.Path({str(applied)!r}).write_text(sys.stdin.read())\n"
        "print('{}')\n",
        encoding="utf-8",
    )
    seen: list[tuple[str, dict[str, object]]] = []

    class FakeDrtc:
        metadata = {"local_frame_schema": "reflex.drtc.local_frame.v1"}

        def __init__(self) -> None:
            self.closed = False

        def infer(self, payload: dict[str, object]) -> dict[str, object]:
            return {"actions": [[1.0, 2.0]], "chunk_length": 1}

        def close(self) -> None:
            self.closed = True

    def fake_start(session: dict[str, object], *, sidecar_binary: str) -> FakeDrtc:
        return FakeDrtc()

    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        body = _request_body(req)
        seen.append((req.full_url, body))
        if body["path"] == "publicApi:getDeployment":
            return FakeResponse(
                {
                    "status": "success",
                    "value": {
                        "ok": True,
                        "deployment": {
                            "_id": "deployment_123",
                            "status": "ready",
                        },
                    },
                },
            )
        if body["path"] == "publicApi:robotHeartbeat":
            return FakeResponse({"status": "success", "value": {"ok": True, "robotId": "robot_123"}})
        return FakeResponse(
            {
                "status": "success",
                "value": {
                    "ok": True,
                    "sessionId": "session_123",
                    "deploymentId": "deployment_123",
                    "robotId": "robot_123",
                    "primeUrl": "https://prime.example",
                    "mode": "apply_actions",
                },
            },
        )

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    monkeypatch.setattr(cli_module, "_start_drtc_client_from_session", fake_start)
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "connect",
            "--deployment",
            "deployment_123",
            "--robot",
            "robot_123",
            "--mode",
            "apply_actions",
            "--start-drtc",
            "--observe-command",
            f"{sys.executable} {observe}",
            "--action-command",
            f"{sys.executable} {apply}",
            "--max-steps",
            "1",
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
            "--json",
        ],
    )

    assert result.exit_code == 0, result.output
    output = json.loads(result.output)
    assert output["execution"]["steps"] == 1
    assert output["execution"]["appliedSteps"] == 1
    assert json.loads(applied.read_text())["action_chunk"]["actions"] == [[1.0, 2.0]]
    paths = [body["path"] for _, body in seen]
    assert "publicApi:getDeployment" in paths
    assert "publicApi:robotHeartbeat" in paths


def test_robot_connect_apply_actions_blocked_when_readiness_not_passed(monkeypatch) -> None:
    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        body = _request_body(req)
        assert body["path"] == "publicApi:getDeployment", body["path"]
        return FakeResponse(
            {
                "status": "success",
                "value": {
                    "ok": True,
                    "deployment": {"_id": "deployment_blocked", "status": "blocked"},
                },
            },
        )

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "connect",
            "--deployment",
            "deployment_blocked",
            "--robot",
            "robot_blocked",
            "--mode",
            "apply_actions",
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
            "--json",
        ],
    )

    assert result.exit_code != 0
    output = json.loads(result.output)
    assert output["ok"] is False
    assert "apply_actions blocked" in output["error"]


def test_robot_connect_apply_actions_allow_unchecked_skips_readiness(monkeypatch) -> None:
    seen_paths: list[str] = []

    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        body = _request_body(req)
        seen_paths.append(body["path"])
        return FakeResponse(
            {
                "status": "success",
                "value": {
                    "ok": True,
                    "sessionId": "session_abc",
                    "deploymentId": "deployment_unchecked",
                    "robotId": "robot_unchecked",
                    "primeUrl": "https://prime.example",
                    "mode": "apply_actions",
                },
            },
        )

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "connect",
            "--deployment",
            "deployment_unchecked",
            "--robot",
            "robot_unchecked",
            "--mode",
            "apply_actions",
            "--allow-unchecked",
            "--once",
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
            "--json",
        ],
    )

    assert result.exit_code == 0, result.output
    assert "publicApi:getDeployment" not in seen_paths
    assert "publicApi:authorizeSession" in seen_paths


def test_robot_connect_rejects_invalid_mode(monkeypatch) -> None:
    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        raise AssertionError("no network call should happen for invalid mode")

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "connect",
            "--deployment",
            "deployment_x",
            "--robot",
            "robot_x",
            "--mode",
            "yolo",
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
            "--json",
        ],
    )

    assert result.exit_code != 0
    output = json.loads(result.output)
    assert output["ok"] is False
    assert "mode must be one of" in output["error"]


def test_training_list_human_output_is_formatted(monkeypatch) -> None:
    seen: list[tuple[str, dict[str, object]]] = []
    now = 4102444861000

    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        seen.append((req.full_url, _request_body(req)))
        return FakeResponse(
            {
                "status": "success",
                "value": {
                    "ok": True,
                    "trainingRuns": [
                        {
                            "_id": "train_123",
                            "createdByUserId": "user_123",
                            "createdBy": {
                                "name": "Peter Rolfes",
                                "email": "peter@example.test",
                                "apiKeyName": "CLI key",
                            },
                            "datasetId": "ds_123",
                            "dataset": {
                                "_id": "ds_123",
                                "name": "Grab the screw",
                                "hfSourceUri": "https://huggingface.co/datasets/peterrolfes/s0101_grab_the_screw",
                                "hfRepo": "peterrolfes/s0101_grab_the_screw",
                            },
                            "baseModel": "pi0.5",
                            "fineTuningType": "lora",
                            "operation": "initial_train",
                            "status": "running",
                            "modelName": "grab-screw",
                            "modelVersion": "v1",
                            "epochs": 3,
                            "currentEpoch": 2,
                            "totalEpochs": 3,
                            "stepsCompleted": 20,
                            "estimatedTotalSteps": 30,
                            "progress": 0.67,
                            "hfRevision": "resolved-commit",
                            "modelId": "model_123",
                            "primeNodeId": "prime_123",
                            "requestId": "train-request-123",
                            "parametersJson": '{"learning_rate":0.0001,"batch_size":8}',
                            "latestCheckpointStorageId": "storage_123",
                            "latestCheckpointSha256": "checkpoint-sha",
                            "latestCheckpointSizeBytes": 1234567,
                            "latestCheckpointContentType": "application/octet-stream",
                            "latestCheckpointMetricsJson": '{"loss":0.12}',
                            "latestCheckpointSavedAt": 4102448461000,
                            "startedAt": 4102444800000,
                            "lastHeartbeatAt": 4102444861000,
                            "createdAt": 4102444800000,
                            "updatedAt": 4102444861000,
                        },
                        {
                            "_id": "train_recent_failed",
                            "status": "failed",
                            "modelName": "recent-failed",
                            "modelVersion": "v1",
                            "errorMessage": "Worker exited",
                            "createdAt": now - (14 * 60 * 1000),
                            "updatedAt": now - (14 * 60 * 1000),
                        },
                        {
                            "_id": "train_stale_failed",
                            "status": "failed",
                            "modelName": "stale-failed",
                            "modelVersion": "v1",
                            "createdAt": now - (16 * 60 * 1000),
                            "updatedAt": now - (16 * 60 * 1000),
                        },
                        {
                            "_id": "train_succeeded",
                            "status": "succeeded",
                            "modelName": "done",
                            "modelVersion": "v1",
                            "createdAt": now,
                            "updatedAt": now,
                        }
                    ],
                },
            }
        )

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    monkeypatch.setattr(cli_module, "_now_millis", lambda: now)
    _use_test_local_timezone(monkeypatch)
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "training",
            "list",
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
        ],
    )

    assert result.exit_code == 0, result.output
    assert seen == [
        (
            "https://convex.example/api/mutation",
            {
                "path": "publicApi:listTrainingRuns",
                "args": {"apiKey": "rfx_test"},
                "format": "json",
            },
        )
    ]
    assert "Training runs" in result.output
    assert (
        "Note: By default, `reflex training list` shows active training runs and failed training "
        "runs updated in the last 15 minutes. Add --all to include every training run."
    ) in result.output
    assert "1. grab-screw v1" in result.output
    assert "ID: train_123" in result.output
    assert "Status: running (67%)" in result.output
    assert "Created: 2099-12-31 16:00:00 PST" in result.output
    assert "Updated: 2099-12-31 16:01:01 PST" in result.output
    assert 'Created by: Peter Rolfes via API key "CLI key"' in result.output
    assert "Dataset: Grab the screw (ds_123)" in result.output
    assert "HF link: https://huggingface.co/datasets/peterrolfes/s0101_grab_the_screw" in result.output
    assert "Fine tuning: lora" in result.output
    assert "Operation: initial train" in result.output
    assert "Epochs: 2/3" in result.output
    assert "Steps: 20/30" in result.output
    assert "Model artifact: model_123" in result.output
    assert "Prime node: prime_123" in result.output
    assert "Request ID: train-request-123" in result.output
    assert "Started: 2099-12-31 16:00:00 PST" in result.output
    assert "Last heartbeat: 2099-12-31 16:01:01 PST" in result.output
    assert "Learning rate: 0.0001" in result.output
    assert "Batch size: 8" in result.output
    assert "Size: 1.2 MB" in result.output
    assert "Saved: 2099-12-31 17:01:01 PST" in result.output
    assert "Loss: 0.12" in result.output
    assert "2. recent-failed v1" in result.output
    assert "Status: failed" in result.output
    assert "Error: Worker exited" in result.output
    assert "stale-failed" not in result.output
    assert "train_stale_failed" not in result.output
    assert "done v1" not in result.output
    assert "train_succeeded" not in result.output
    assert "createdByUserId" not in result.output
    assert "user_123" not in result.output
    assert "Use `reflex training list --json` for comprehensive training run metadata." in result.output
    assert not result.output.lstrip().startswith("{")


def test_training_list_json_output_includes_every_training_run(monkeypatch) -> None:
    now = 4102444861000

    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        return FakeResponse(
            {
                "status": "success",
                "value": {
                    "ok": True,
                    "trainingRuns": [
                        {"_id": "train_running", "status": "running", "updatedAt": now},
                        {
                            "_id": "train_recent_failed",
                            "status": "failed",
                            "updatedAt": now - (10 * 60 * 1000),
                        },
                        {
                            "_id": "train_stale_failed",
                            "status": "failed",
                            "updatedAt": now - (20 * 60 * 1000),
                        },
                        {"_id": "train_succeeded", "status": "succeeded", "updatedAt": now},
                    ],
                },
            }
        )

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    monkeypatch.setattr(cli_module, "_now_millis", lambda: now)
    runner = CliRunner()

    default_result = runner.invoke(
        build_reflex_app(),
        [
            "training",
            "list",
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
            "--json",
        ],
    )
    all_result = runner.invoke(
        build_reflex_app(),
        [
            "training",
            "list",
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
            "--all",
            "--json",
        ],
    )

    assert default_result.exit_code == 0, default_result.output
    default_output = json.loads(default_result.output)
    assert default_output["note"] == "JSON output includes every training run."
    assert [run["_id"] for run in default_output["trainingRuns"]] == [
        "train_running",
        "train_recent_failed",
        "train_stale_failed",
        "train_succeeded",
    ]

    assert all_result.exit_code == 0, all_result.output
    all_output = json.loads(all_result.output)
    assert all_output["note"] == "JSON output includes every training run."
    assert [run["_id"] for run in all_output["trainingRuns"]] == [
        "train_running",
        "train_recent_failed",
        "train_stale_failed",
        "train_succeeded",
    ]


def test_training_list_json_exits_nonzero_for_public_api_error(monkeypatch) -> None:
    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        return FakeResponse({"status": "success", "value": {"ok": False, "reason": "revoked"}})

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "training",
            "list",
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
            "--json",
        ],
    )

    assert result.exit_code == 1, result.output
    output = json.loads(result.output)
    assert output["ok"] is False
    assert "Unable to list training runs: revoked" in output["error"]


def test_training_status_human_formats_timestamps_in_local_timezone(monkeypatch) -> None:
    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        return FakeResponse(
            {
                "status": "success",
                "value": {
                    "ok": True,
                    "trainingRun": {
                        "_id": "train_123",
                        "status": "running",
                        "createdAt": 4102444800000,
                        "updatedAt": 4102444861000,
                    },
                },
            }
        )

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    _use_test_local_timezone(monkeypatch)
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "training",
            "status",
            "train_123",
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
        ],
    )

    assert result.exit_code == 0, result.output
    assert "Created at: 2099-12-31 16:00:00 PST" in result.output
    assert "Updated at: 2099-12-31 16:01:01 PST" in result.output
    assert "4102444800000" not in result.output
    assert "UTC" not in result.output


def test_training_status_watch_stops_on_succeeded_run(monkeypatch) -> None:
    seen: list[tuple[str, dict[str, object]]] = []

    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        seen.append((req.full_url, _request_body(req)))
        return FakeResponse(
            {
                "status": "success",
                "value": {
                    "ok": True,
                    "trainingRun": {"_id": "train_123", "status": "succeeded"},
                },
            },
        )

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "training",
            "status",
            "train_123",
            "--watch",
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
            "--json",
        ],
    )

    assert result.exit_code == 0, result.output
    assert seen == [
        (
            "https://convex.example/api/mutation",
            {
                "path": "publicApi:getTrainingRun",
                "args": {"apiKey": "rfx_test", "trainingRunId": "train_123"},
                "format": "json",
            },
        )
    ]
    output = json.loads(result.output)
    assert output["ok"] is True
    assert output["trainingRun"]["trainingRun"]["status"] == "succeeded"


def test_training_stop_calls_public_api_mutation(monkeypatch) -> None:
    seen: list[tuple[str, dict[str, object]]] = []

    def fake_urlopen(req: request.Request, timeout: int) -> FakeResponse:
        seen.append((req.full_url, _request_body(req)))
        return FakeResponse(
            {
                "status": "success",
                "value": {"ok": True, "trainingRunId": "train_123", "status": "stopping"},
            }
        )

    monkeypatch.setattr(product.request, "urlopen", fake_urlopen)
    runner = CliRunner()

    result = runner.invoke(
        build_reflex_app(),
        [
            "training",
            "stop",
            "train_123",
            "--api-key",
            "rfx_test",
            "--convex-url",
            "https://convex.example",
            "--json",
        ],
    )

    assert result.exit_code == 0, result.output
    assert seen == [
        (
            "https://convex.example/api/mutation",
            {
                "path": "publicApi:stopTrainingRun",
                "args": {"apiKey": "rfx_test", "trainingRunId": "train_123"},
                "format": "json",
            },
        )
    ]
    output = json.loads(result.output)
    assert output["ok"] is True
    assert output["trainingRun"]["status"] == "stopping"