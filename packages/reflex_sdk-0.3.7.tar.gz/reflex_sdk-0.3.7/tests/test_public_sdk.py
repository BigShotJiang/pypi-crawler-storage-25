from __future__ import annotations

import os
import json
import sys
import unittest
from importlib.metadata import version
from pathlib import Path
from unittest.mock import patch

import reflex
from reflex import actions
from reflex._transport import DEFAULT_API_URL, request_json
from reflex._version import user_agent


class FakeResponse:
    def __init__(self, body: bytes = b'{"ok": true}') -> None:
        self.body = body

    def __enter__(self) -> FakeResponse:
        return self

    def __exit__(self, *args: object) -> None:
        return None

    def read(self) -> bytes:
        return self.body


class PublicSdkTests(unittest.TestCase):
    def test_package_version_is_runtime_user_agent_source(self) -> None:
        self.assertEqual(reflex.__version__, version("reflex-sdk"))
        self.assertEqual(user_agent("reflex-sdk"), f"reflex-sdk/{reflex.__version__}")

    def test_actions_url_reads_reflex_api_url(self) -> None:
        env = {
            key: value
            for key, value in os.environ.items()
            if key not in {"REFLEX_ACTIONS_URL", "REFLEX_API_URL", "REFLEX_PLATFORM_URL", "RFX_API_URL"}
        }
        env["REFLEX_API_URL"] = "https://api.example.test"
        with patch.dict(os.environ, env, clear=True):
            self.assertEqual(actions._actions_ws_url(None), "wss://api.example.test/v1/actions")

    def test_action_stream_retries_transient_websocket_handshake_failures(self) -> None:
        stream = actions.ActionStream(
            url="wss://prime.example/",
            api_key="rfx_test",
            prompt="say hi",
            timeout=5,
        )

        with (
            patch(
                "reflex.actions._connect_websocket",
                side_effect=[
                    actions.WebSocketHandshakeError("HTTP/1.1 403 Forbidden"),
                    object(),
                ],
            ) as connect,
            patch("reflex.actions.time.sleep") as sleep,
            patch.object(actions.ActionStream, "send_raw") as send_raw,
            patch.object(
                actions.ActionStream,
                "receive",
                return_value={"type": "session.ready", "session_id": "session_123"},
            ),
        ):
            stream.open()

        self.assertEqual(connect.call_count, 2)
        sleep.assert_called_once()
        send_raw.assert_called_once()
        self.assertEqual(stream.session_id, "session_123")

    def test_action_stream_retries_timeout_waiting_for_session_ready(self) -> None:
        stream = actions.ActionStream(
            url="wss://prime.example/",
            api_key="rfx_test",
            prompt="say hi",
            timeout=5,
        )

        with (
            patch("reflex.actions._connect_websocket", side_effect=[object(), object()]) as connect,
            patch("reflex.actions._close_websocket") as close_websocket,
            patch("reflex.actions.time.sleep") as sleep,
            patch.object(actions.ActionStream, "send_raw") as send_raw,
            patch.object(
                actions.ActionStream,
                "receive",
                side_effect=[
                    actions.socket.timeout("timed out"),
                    {"type": "session.ready", "session_id": "session_456"},
                ],
            ),
        ):
            stream.open()

        self.assertEqual(connect.call_count, 2)
        self.assertEqual(send_raw.call_count, 2)
        close_websocket.assert_called_once()
        sleep.assert_called_once()
        self.assertEqual(stream.session_id, "session_456")

    def test_request_json_defaults_to_hosted_api(self) -> None:
        with patch.dict(os.environ, {"REFLEX_API_KEY": "rfx_test"}, clear=True):
            with patch("reflex._transport.request.urlopen", return_value=FakeResponse()) as urlopen:
                self.assertEqual(request_json(url=None, api_key_value=None, path="/v1/ping"), {"ok": True})
        request = urlopen.call_args.args[0]
        self.assertEqual(request.full_url, f"{DEFAULT_API_URL}/v1/ping")
        self.assertEqual(request.headers["Authorization"], "Bearer rfx_test")

    def test_client_training_uses_bound_key_and_convex_url(self) -> None:
        with patch("reflex.training.convex_action", return_value={"trainingRunId": "run-1"}) as action:
            client = reflex.Client(
                api_key="rfx_bound",
                url="https://api.example.test",
                convex_url="https://convex.example.test",
            )
            self.assertEqual(
                client.training.create(dataset_id="dataset-1", adapter_name="pick-cube"),
                {"trainingRunId": "run-1", "training_job_id": "run-1"},
            )

        action.assert_called_once()
        self.assertEqual(action.call_args.args[0], "publicApi:createAndProvisionTrainingRun")
        args = action.call_args.args[1]
        self.assertEqual(action.call_args.kwargs["url"], "https://convex.example.test")
        self.assertEqual(args["apiKey"], "rfx_bound")
        self.assertEqual(args["datasetId"], "dataset-1")
        self.assertEqual(args["baseModel"], "pi0.5")
        self.assertEqual(args["fineTuningType"], "lora")
        self.assertEqual(args["modelName"], "pick-cube")

    def test_simple_lora_and_full_training_helpers_call_convex(self) -> None:
        with patch("reflex.training.convex_action", return_value={"ok": True, "trainingRunId": "run-lora"}) as action:
            result = reflex.lora_finetune(
                api_key="rfx_bound",
                convex_url="https://convex.example.test",
                hf_source_uri="lerobot/pusht",
                model_name="pusht-lora",
                epochs=1,
                max_steps=3,
                lora_rank=8,
            )

        self.assertEqual(result["training_job_id"], "run-lora")
        self.assertEqual(action.call_args.args[0], "publicApi:createAndProvisionTrainingRunFromHuggingFace")
        lora_args = action.call_args.args[1]
        self.assertEqual(lora_args["hfSourceUri"], "lerobot/pusht")
        self.assertEqual(lora_args["fineTuningType"], "lora")
        self.assertIn('"maxSteps":3', lora_args["parametersJson"])
        self.assertIn('"rank":8', lora_args["parametersJson"])

        with patch("reflex.training.convex_action", return_value={"ok": True, "trainingRunId": "run-full"}) as action:
            result = reflex.full_train(
                api_key="rfx_bound",
                convex_url="https://convex.example.test",
                dataset_id="dataset-1",
                model_name="pusht-full",
                epochs=1,
            )

        self.assertEqual(result["training_job_id"], "run-full")
        self.assertEqual(action.call_args.args[0], "publicApi:createAndProvisionTrainingRun")
        full_args = action.call_args.args[1]
        self.assertEqual(full_args["datasetId"], "dataset-1")
        self.assertEqual(full_args["fineTuningType"], "full")

    def test_dataset_register_huggingface_calls_convex(self) -> None:
        with patch("reflex.datasets.convex_action", return_value={"ok": True, "datasetId": "dataset-1"}) as action:
            client = reflex.Client(api_key="rfx_bound", convex_url="https://convex.example.test")
            self.assertEqual(
                client.datasets.register_huggingface("lerobot/pusht"),
                {"ok": True, "datasetId": "dataset-1"},
            )

        self.assertEqual(action.call_args.args[0], "publicApi:registerDataset")
        self.assertEqual(action.call_args.args[1]["apiKey"], "rfx_bound")
        self.assertEqual(action.call_args.args[1]["hfSourceUri"], "lerobot/pusht")

    def test_client_sessions_start_uses_bound_key_and_mode(self) -> None:
        with patch("reflex.sessions.ProductClient") as product_client:
            product_client.return_value.mutation.side_effect = [
                {
                    "ok": True,
                    "sessionId": "session-1",
                    "mode": "apply_actions",
                },
                {
                    "ok": True,
                    "sessionId": "session-1",
                    "mode": "apply_actions",
                },
            ]
            client = reflex.Client(
                api_key="rfx_bound",
                convex_url="https://convex.example.test",
            )
            result = client.sessions.start(
                artifact_id="model-1",
                mode="apply_actions",
                runtime="reflex",
            )
            promoted = client.sessions.promote("session-1")

        self.assertEqual(result["sessionId"], "session-1")
        self.assertEqual(promoted["mode"], "apply_actions")
        self.assertEqual(product_client.call_count, 2)
        self.assertEqual(product_client.call_args_list[0].args, ("https://convex.example.test",))
        self.assertEqual(product_client.call_args_list[1].args, ("https://convex.example.test",))
        self.assertEqual(
            product_client.return_value.mutation.call_args_list[0].args,
            (
                "publicApi:authorizeSession",
                {
                    "apiKey": "rfx_bound",
                    "baseModel": "pi0.5",
                    "mode": "apply_actions",
                    "modelId": "model-1",
                    "runtime": "reflex",
                },
            ),
        )
        self.assertEqual(
            product_client.return_value.mutation.call_args_list[1].args,
            (
                "publicApi:promoteSession",
                {
                    "apiKey": "rfx_bound",
                    "sessionId": "session-1",
                    "mode": "apply_actions",
                },
            ),
        )

    def test_client_deployments_create_and_doctor_call_convex(self) -> None:
        with patch("reflex.deployments.ProductClient") as product_client:
            product_client.return_value.mutation.side_effect = [
                {"ok": True, "deploymentId": "deployment-1"},
                {"ok": True, "readinessCheckId": "check-1", "passed": True},
            ]
            client = reflex.Client(
                api_key="rfx_bound",
                convex_url="https://convex.example.test",
            )
            created = client.deployments.create(
                name="pi05-pick-cube",
                model_id="model-1",
                robot_schema_id="schema-1",
                runtime="reflex",
            )
            checked = client.deployments.doctor("deployment-1")

        self.assertEqual(created["deploymentId"], "deployment-1")
        self.assertEqual(checked["readinessCheckId"], "check-1")
        self.assertEqual(
            product_client.return_value.mutation.call_args_list[0].args,
            (
                "publicApi:createDeployment",
                {
                    "apiKey": "rfx_bound",
                    "name": "pi05-pick-cube",
                    "modelId": "model-1",
                    "mode": "dry_run",
                    "robotSchemaId": "schema-1",
                    "runtime": "reflex",
                },
            ),
        )
        self.assertEqual(
            product_client.return_value.mutation.call_args_list[1].args,
            (
                "publicApi:runReadinessCheck",
                {"apiKey": "rfx_bound", "deploymentId": "deployment-1"},
            ),
        )

    def test_client_robots_register_schema_extracts_safe_stop(self) -> None:
        with patch("reflex.robots.ProductClient") as product_client:
            product_client.return_value.mutation.return_value = {
                "ok": True,
                "robotSchemaId": "schema-1",
            }
            client = reflex.Client(
                api_key="rfx_bound",
                convex_url="https://convex.example.test",
            )
            result = client.robots.register_schema(
                name="so101-lab-a",
                schema={
                    "schema_version": "robot_schema.v1",
                    "actions": {
                        "action": {
                            "shape": [2],
                            "safe_stop": [0.0, 0.0],
                            "safe_stop_mode": "zero_velocity",
                        }
                    },
                },
            )

        self.assertEqual(result["robotSchemaId"], "schema-1")
        args = product_client.return_value.mutation.call_args.args[1]
        self.assertEqual(args["apiKey"], "rfx_bound")
        self.assertEqual(args["name"], "so101-lab-a")
        self.assertEqual(args["hasExplicitSafeStop"], True)
        self.assertEqual(args["safeStopMode"], "zero_velocity")
        self.assertEqual(args["actionDim"], 2)

    def test_client_robot_pairing_and_heartbeat_call_convex(self) -> None:
        with patch("reflex.robots.ProductClient") as product_client:
            product_client.return_value.mutation.side_effect = [
                {"ok": True, "token": "rfx_robot_pair", "robotId": "robot-1"},
                {"ok": True, "robotId": "robot-1"},
                {"ok": True, "robotId": "robot-1", "lastHeartbeatAt": 123},
            ]
            client = reflex.Client(
                api_key="rfx_bound",
                convex_url="https://convex.example.test",
            )
            token = client.robots.create_pairing_token("robot-1", ttl_seconds=60)
            claimed = client.robots.claim_pairing_token("rfx_robot_pair")
            heartbeat = client.robots.heartbeat(
                "robot-1",
                session_id="session-1",
                deployment_id="deployment-1",
                transport="drtc",
            )

        self.assertEqual(token["token"], "rfx_robot_pair")
        self.assertEqual(claimed["robotId"], "robot-1")
        self.assertEqual(heartbeat["lastHeartbeatAt"], 123)
        self.assertEqual(
            product_client.return_value.mutation.call_args_list[0].args,
            (
                "publicApi:createRobotPairingToken",
                {"apiKey": "rfx_bound", "robotId": "robot-1", "ttlSeconds": 60},
            ),
        )
        self.assertEqual(
            product_client.return_value.mutation.call_args_list[1].args,
            (
                "publicApi:claimRobotPairingToken",
                {"apiKey": "rfx_bound", "token": "rfx_robot_pair"},
            ),
        )
        self.assertEqual(
            product_client.return_value.mutation.call_args_list[2].args,
            (
                "publicApi:robotHeartbeat",
                {
                    "apiKey": "rfx_bound",
                    "robotId": "robot-1",
                    "sessionId": "session-1",
                    "deploymentId": "deployment-1",
                    "transport": "drtc",
                },
            ),
        )

    def test_tinker_like_lora_training_loop_shape(self) -> None:
        responses = [
            {"training_run_id": "run-1"},
            {"loss": 0.42, "metrics": {"tokens": 128}},
            {"step": 1, "metrics": {"grad_norm": 0.9}},
            {
                "lora": "pick-and-place@9f3a2c8b10",
                "name": "pick-and-place",
                "version": "9f3a2c8b10",
                "adapter_id": "adapter-1",
            },
        ]
        with patch("reflex.training.request_json", side_effect=responses) as request:
            service = reflex.ServiceClient(api_key="rfx_bound", url="https://api.example.test")
            training = service.create_lora_training_client(
                base_model="pi0.7-flash",
                name="pick-and-place",
                rank=16,
            )
            datum = reflex.Datum(
                observation={"state": [0.0] * 14, "images": {}},
                actions=[[0.0] * 32],
            )
            fb = training.forward_backward([datum], loss_fn="behavior_cloning")
            opt = training.optim_step(reflex.AdamParams(learning_rate=1e-4))
            adapter = training.save_adapter()

        self.assertEqual(training.run_id, "run-1")
        self.assertEqual(fb.loss, 0.42)
        self.assertEqual(opt.step, 1)
        self.assertEqual(adapter.lora, "pick-and-place@9f3a2c8b10")

        calls = [call.kwargs for call in request.call_args_list]
        self.assertEqual(calls[0]["path"], "/v1/training-runs/lora")
        self.assertEqual(calls[1]["path"], "/v1/training-runs/run-1/forward-backward")
        self.assertEqual(calls[1]["payload"]["loss_fn"], "behavior_cloning")
        self.assertEqual(calls[1]["payload"]["data"][0]["observation"]["state"], [0.0] * 14)
        self.assertEqual(calls[2]["path"], "/v1/training-runs/run-1/optim-step")
        self.assertEqual(calls[2]["payload"]["params"]["learning_rate"], 1e-4)
        self.assertEqual(calls[3]["path"], "/v1/training-runs/run-1/save-adapter")

    def test_controller_decorator_runs_one_action_loop(self) -> None:
        captured: dict[str, object] = {"kwargs": None, "observations": [], "actions": []}

        class FakeStream:
            def __init__(self, **kwargs: object) -> None:
                captured["kwargs"] = kwargs

            def __enter__(self) -> FakeStream:
                return self

            def __exit__(self, *args: object) -> None:
                return None

            def send_observation_frame(self, observation: dict[str, object]) -> None:
                captured["observations"].append(observation)

            def recv_action(self) -> dict[str, object]:
                return {"actions": [[1.0, 2.0]]}

        with patch("reflex.actions.ActionStream", FakeStream):

            @reflex.connect(
                model="pi0.7-flash",
                lora="pick-and-place@9f3a2c8b10",
                cameras=["wrist", "scene"],
                hz=50,
                chunk_size=8,
            )
            class Controller:
                @reflex.observation
                def observe(self) -> dict[str, object]:
                    return {"state": [0.0] * 14, "images": {}}

                @reflex.action
                def execute(self, action: object) -> None:
                    captured["actions"].append(action)

            Controller().run(max_steps=1)

        self.assertEqual(captured["observations"], [{"state": [0.0] * 14, "images": {}}])
        self.assertEqual(captured["actions"], [[[1.0, 2.0]]])
        self.assertEqual(captured["kwargs"]["prompt"], "do something")
        self.assertEqual(captured["kwargs"]["lora"], "pick-and-place@9f3a2c8b10")

    def test_robot_execution_loop_runs_observe_infer_apply(self) -> None:
        events: list[dict[str, object]] = []
        temp_dir = Path(os.environ.get("TEST_TMPDIR", "/tmp"))
        observe = temp_dir / "reflex_observe_test.py"
        apply = temp_dir / "reflex_apply_test.py"
        observed_action = temp_dir / "reflex_action_test.json"
        observe.write_text(
            "import json\n"
            "print(json.dumps({'state': [0.0, 0.1], 'images': {}, 'task': 'pick'}))\n",
            encoding="utf-8",
        )
        apply.write_text(
            "import json, pathlib, sys\n"
            f"pathlib.Path({str(observed_action)!r}).write_text(sys.stdin.read())\n"
            "print('{}')\n",
            encoding="utf-8",
        )

        class FakeDrtc:
            def infer(self, payload: dict[str, object]) -> dict[str, object]:
                events.append(payload)
                return {"actions": [[1.0, 2.0]], "chunk_length": 1}

            def close(self) -> None:
                pass

        result = reflex.run_robot_execution_loop(
            drtc_client=FakeDrtc(),
            config=reflex.RobotExecutionConfig(
                session_id="session-1",
                deployment_id="deployment-1",
                robot_id="robot-1",
                mode="apply_actions",
                max_steps=1,
                observe_command=f"{sys.executable} {observe}",
                action_command=f"{sys.executable} {apply}",
                control_period_s=0,
            ),
        )

        self.assertEqual(result.steps, 1)
        self.assertEqual(result.applied_steps, 1)
        self.assertEqual(events[0]["state"], [0.0, 0.1])
        applied = json.loads(observed_action.read_text(encoding="utf-8"))
        self.assertEqual(applied["action_chunk"]["actions"], [[1.0, 2.0]])

    def test_json_safe_handles_numpy_like_dicts_and_tuples(self) -> None:
        from reflex.robot_runtime import _json_safe

        class FakeArray:
            def tolist(self) -> list[float]:
                return [1.0, 2.0, 3.0]

        result = _json_safe({"a": FakeArray(), "b": (FakeArray(), {"c": FakeArray()})})
        self.assertEqual(result, {"a": [1.0, 2.0, 3.0], "b": [[1.0, 2.0, 3.0], {"c": [1.0, 2.0, 3.0]}]})

    def test_run_safe_stop_is_noop_when_no_command_configured(self) -> None:
        from reflex.robot_runtime import RobotExecutionConfig, _run_safe_stop

        # Should not raise even though safe_stop_command is empty.
        _run_safe_stop(
            RobotExecutionConfig(
                session_id="s", deployment_id="d", robot_id="r", safe_stop_command=""
            ),
            reason="test",
            control_step=0,
        )

    def test_run_safe_stop_invokes_command_with_reason_payload(self) -> None:
        from reflex.robot_runtime import RobotExecutionConfig, _run_safe_stop

        temp_dir = Path(os.environ.get("TEST_TMPDIR", "/tmp"))
        safe_stop = temp_dir / "reflex_safe_stop_test.py"
        captured = temp_dir / "reflex_safe_stop_captured.json"
        safe_stop.write_text(
            "import json, pathlib, sys\n"
            f"pathlib.Path({str(captured)!r}).write_text(sys.stdin.read())\n"
            "print('{}')\n",
            encoding="utf-8",
        )

        _run_safe_stop(
            RobotExecutionConfig(
                session_id="session-x",
                deployment_id="deployment-x",
                robot_id="robot-x",
                safe_stop_command=f"{sys.executable} {safe_stop}",
                safe_stop_timeout_s=5.0,
            ),
            reason="observe_failed",
            control_step=7,
        )

        payload = json.loads(captured.read_text(encoding="utf-8"))
        self.assertEqual(payload["reason"], "observe_failed")
        self.assertEqual(payload["control_step"], 7)
        self.assertEqual(payload["session_id"], "session-x")

    def test_execution_loop_safe_stops_on_observe_failure(self) -> None:
        temp_dir = Path(os.environ.get("TEST_TMPDIR", "/tmp"))
        observe = temp_dir / "reflex_observe_failing.py"
        safe_stop = temp_dir / "reflex_safe_stop_called.py"
        marker = temp_dir / "reflex_safe_stop_marker.json"
        observe.write_text("import sys; sys.exit(2)\n", encoding="utf-8")
        safe_stop.write_text(
            "import pathlib, sys\n"
            f"pathlib.Path({str(marker)!r}).write_text(sys.stdin.read())\n"
            "print('{}')\n",
            encoding="utf-8",
        )
        if marker.exists():
            marker.unlink()

        class UnusedDrtc:
            def infer(self, payload: dict[str, object]) -> dict[str, object]:
                raise AssertionError("infer must not be called when observe fails")

            def close(self) -> None:
                pass

        result = reflex.run_robot_execution_loop(
            drtc_client=UnusedDrtc(),
            config=reflex.RobotExecutionConfig(
                session_id="session-fail",
                deployment_id="deployment-fail",
                robot_id="robot-fail",
                mode="apply_actions",
                max_steps=1,
                observe_command=f"{sys.executable} {observe}",
                action_command="echo {}",
                safe_stop_command=f"{sys.executable} {safe_stop}",
                control_period_s=0,
            ),
        )

        self.assertEqual(result.applied_steps, 0)
        self.assertEqual(result.safe_stops, 1)
        self.assertTrue(result.errors, "expected at least one error message")
        self.assertTrue(marker.exists(), "safe-stop command was not invoked")
        payload = json.loads(marker.read_text(encoding="utf-8"))
        self.assertEqual(payload["session_id"], "session-fail")

    def test_execution_loop_safe_stops_on_observe_timeout(self) -> None:
        temp_dir = Path(os.environ.get("TEST_TMPDIR", "/tmp"))
        observe = temp_dir / "reflex_observe_hang.py"
        safe_stop = temp_dir / "reflex_safe_stop_after_timeout.py"
        marker = temp_dir / "reflex_safe_stop_after_timeout_marker.json"
        observe.write_text("import time; time.sleep(60)\n", encoding="utf-8")
        safe_stop.write_text(
            "import pathlib, sys\n"
            f"pathlib.Path({str(marker)!r}).write_text(sys.stdin.read())\n"
            "print('{}')\n",
            encoding="utf-8",
        )
        if marker.exists():
            marker.unlink()

        class UnusedDrtc:
            def infer(self, payload: dict[str, object]) -> dict[str, object]:
                raise AssertionError("infer must not be called when observe hangs")

            def close(self) -> None:
                pass

        result = reflex.run_robot_execution_loop(
            drtc_client=UnusedDrtc(),
            config=reflex.RobotExecutionConfig(
                session_id="session-timeout",
                deployment_id="deployment-timeout",
                robot_id="robot-timeout",
                mode="dry_run",
                max_steps=1,
                observe_command=f"{sys.executable} {observe}",
                safe_stop_command=f"{sys.executable} {safe_stop}",
                command_timeout_s=0.2,
                safe_stop_timeout_s=2.0,
                control_period_s=0,
            ),
        )

        self.assertEqual(result.safe_stops, 1)
        self.assertTrue(marker.exists(), "safe-stop command was not invoked on timeout")
        self.assertTrue(
            any("timed out" in error for error in result.errors),
            f"expected a timeout error, got {result.errors!r}",
        )


if __name__ == "__main__":
    unittest.main()