"""Tests for the YAML-driven connect runner and the new connector/transport
registries. Phase-1 scope: no hardware imports, no network calls. Uses
in-memory fakes registered via the dotted-path registry path.
"""

from __future__ import annotations

from typing import Any

import pytest
import yaml

from reflex.connect_runner import (
    RunnerResult,
    build_from_config,
    load_config,
    run_from_config,
    run_session,
)
from reflex.cameras import build_camera, get_camera_class
from reflex.cameras.base import CameraSource
from reflex.connectors import build_connector, get_connector_class
from reflex.connectors.base import ActionChunk, Observation, RobotConnector
from reflex.transports import build_transport, get_transport_class
from reflex.transports.base import InferenceRequest, Transport


# ---------------------------------------------------------------------------
# Fakes (also referenced via dotted path "tests.test_connect_runner:FakeXxx")
# ---------------------------------------------------------------------------


class FakeConnector(RobotConnector):
    kind = "fake"

    def __init__(self, *, state_dim: int = 4, fail_on_step: int | None = None) -> None:
        self.state_dim = state_dim
        self.fail_on_step = fail_on_step
        self.started = False
        self.stopped = False
        self.applied: list[list[list[float]]] = []
        self.safe_stops: list[str] = []
        self._step = 0

    def start(self) -> None:
        self.started = True

    def get_observation(self) -> Observation:
        if self.fail_on_step is not None and self._step == self.fail_on_step:
            self._step += 1
            raise RuntimeError("boom")
        obs = Observation(state=[float(self._step)] * self.state_dim, task="t")
        self._step += 1
        return obs

    def apply_action(self, action: ActionChunk) -> None:
        self.applied.append(action.actions)

    def safe_stop(self, reason: str = "") -> None:
        self.safe_stops.append(reason)

    def stop(self) -> None:
        self.stopped = True


class FakeTransport(Transport):
    kind = "fake"

    def __init__(self, *, action_dim: int = 4, chunk_len: int = 2) -> None:
        self.action_dim = action_dim
        self.chunk_len = chunk_len
        self.started = False
        self.stopped = False
        self.requests: list[InferenceRequest] = []

    def start(self) -> None:
        self.started = True

    def infer(self, request: InferenceRequest) -> ActionChunk:
        self.requests.append(request)
        return ActionChunk(actions=[[1.0] * self.action_dim for _ in range(self.chunk_len)])

    def stop(self) -> None:
        self.stopped = True


class FakeCamera(CameraSource):
    kind = "fake"

    def __init__(self, *, payload: str = "frame") -> None:
        self.payload = payload
        self.started = False
        self.stopped = False
        self.reads = 0

    def start(self) -> None:
        self.started = True

    def read(self) -> Any:
        self.reads += 1
        return f"{self.payload}_{self.reads}"

    def stop(self) -> None:
        self.stopped = True


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------


def test_connector_registry_resolves_builtin_kind():
    cls = get_connector_class("subprocess")
    from reflex.connectors.shell import SubprocessConnector

    assert cls is SubprocessConnector


def test_connector_registry_resolves_dotted_path():
    cls = get_connector_class("tests.test_connect_runner:FakeConnector")
    assert cls is FakeConnector


def test_connector_registry_unknown_kind_raises():
    with pytest.raises(KeyError):
        get_connector_class("does_not_exist")


def test_transport_registry_resolves_dotted_path():
    cls = get_transport_class("tests.test_connect_runner:FakeTransport")
    assert cls is FakeTransport


def test_transport_registry_unknown_kind_raises():
    with pytest.raises(KeyError):
        get_transport_class("does_not_exist")


def test_camera_registry_resolves_dotted_path():
    cls = get_camera_class("tests.test_connect_runner:FakeCamera")
    assert cls is FakeCamera


def test_camera_registry_unknown_kind_raises():
    with pytest.raises(KeyError):
        get_camera_class("does_not_exist")


def test_build_camera_passes_config_as_kwargs():
    cam = build_camera("tests.test_connect_runner:FakeCamera", {"payload": "hi"})
    assert isinstance(cam, FakeCamera)
    assert cam.payload == "hi"


def test_build_connector_passes_config_as_kwargs():
    connector = build_connector(
        "tests.test_connect_runner:FakeConnector", {"state_dim": 7}
    )
    assert isinstance(connector, FakeConnector)
    assert connector.state_dim == 7


def test_build_transport_passes_config_as_kwargs():
    transport = build_transport(
        "tests.test_connect_runner:FakeTransport", {"action_dim": 14, "chunk_len": 3}
    )
    assert isinstance(transport, FakeTransport)
    assert transport.action_dim == 14
    assert transport.chunk_len == 3


# ---------------------------------------------------------------------------
# run_session
# ---------------------------------------------------------------------------


def test_run_session_dry_run_does_not_apply_actions():
    connector = FakeConnector()
    transport = FakeTransport()
    result = run_session(
        connector=connector, transport=transport, mode="dry_run", max_steps=3
    )
    assert result.steps == 3
    assert result.applied_steps == 0
    assert connector.applied == []
    assert connector.started and connector.stopped
    assert transport.started and transport.stopped


def test_run_session_apply_actions_invokes_connector():
    connector = FakeConnector()
    transport = FakeTransport()
    result = run_session(
        connector=connector,
        transport=transport,
        mode="apply_actions",
        max_steps=2,
    )
    assert result.applied_steps == 2
    assert len(connector.applied) == 2


def test_run_session_on_error_calls_safe_stop_and_stops_by_default():
    connector = FakeConnector(fail_on_step=1)
    transport = FakeTransport()
    result = run_session(
        connector=connector,
        transport=transport,
        mode="dry_run",
        max_steps=5,
        pipeline_inference=False,  # serial semantics for this assertion set
    )
    assert result.safe_stops == 1
    assert connector.safe_stops and "boom" in connector.safe_stops[0]
    # Only the first successful step is counted; the failing step triggers
    # safe_stop and break, so it does not increment result.steps.
    assert result.steps == 1
    assert any("boom" in err for err in result.errors)


def test_run_session_continues_when_stop_on_error_false():
    connector = FakeConnector(fail_on_step=0)
    transport = FakeTransport()
    result = run_session(
        connector=connector,
        transport=transport,
        mode="dry_run",
        max_steps=3,
        stop_on_error=False,
        pipeline_inference=False,
    )
    assert result.steps == 3
    assert result.safe_stops == 1


def test_run_session_pipelined_overlaps_apply_with_infer():
    """With pipelining on, the next infer call should be submitted before apply."""
    connector = FakeConnector()
    transport = FakeTransport()
    result = run_session(
        connector=connector,
        transport=transport,
        mode="apply_actions",
        max_steps=3,
        pipeline_inference=True,
    )
    assert result.applied_steps == 3
    # Bootstrap + 2 prefetches = 3 inference calls for 3 applied chunks.
    assert len(transport.requests) == 3


def test_run_session_invalid_mode_raises():
    with pytest.raises(ValueError):
        run_session(
            connector=FakeConnector(), transport=FakeTransport(), mode="bad", max_steps=1
        )


# ---------------------------------------------------------------------------
# YAML loading
# ---------------------------------------------------------------------------


def _write_config(tmp_path, **overrides) -> str:
    cfg: dict[str, Any] = {
        "mode": "dry_run",
        "max_steps": 2,
        "target": {
            "kind": "tests.test_connect_runner:FakeTransport",
            "action_dim": 4,
            "chunk_len": 1,
        },
        "hardware": {
            "kind": "tests.test_connect_runner:FakeConnector",
            "config": {"state_dim": 4},
        },
    }
    cfg.update(overrides)
    path = tmp_path / "session.yaml"
    path.write_text(yaml.safe_dump(cfg))
    return str(path)


def test_load_config_validates_required_sections(tmp_path):
    bad = tmp_path / "bad.yaml"
    bad.write_text(yaml.safe_dump({"mode": "dry_run"}))
    with pytest.raises(ValueError):
        load_config(str(bad))


def test_load_config_rejects_unknown_mode(tmp_path):
    path = _write_config(tmp_path, mode="weird")
    with pytest.raises(ValueError):
        load_config(path)


def test_build_from_config_returns_connector_transport_cameras(tmp_path):
    cfg = load_config(_write_config(tmp_path))
    connector, transport, cameras = build_from_config(cfg)
    assert isinstance(connector, FakeConnector)
    assert isinstance(transport, FakeTransport)
    assert transport.action_dim == 4
    assert cameras == {}


def test_run_from_config_end_to_end(tmp_path):
    result = run_from_config(_write_config(tmp_path))
    assert isinstance(result, RunnerResult)
    assert result.steps == 2
    assert result.applied_steps == 0  # dry_run


def test_build_from_config_with_cameras(tmp_path):
    cfg = load_config(
        _write_config(
            tmp_path,
            cameras={
                "front": {
                    "kind": "tests.test_connect_runner:FakeCamera",
                    "payload": "hello",
                }
            },
        )
    )
    connector, transport, cameras = build_from_config(cfg)
    assert set(cameras) == {"front"}
    assert isinstance(cameras["front"], FakeCamera)
    assert cameras["front"].payload == "hello"


def test_run_session_merges_camera_frames_into_observation():
    connector = FakeConnector()
    transport = FakeTransport()
    cam = FakeCamera(payload="img")
    run_session(
        connector=connector,
        transport=transport,
        cameras={"front": cam},
        mode="dry_run",
        max_steps=2,
    )
    assert cam.started and cam.stopped
    assert cam.reads == 2
    # Each transport.infer call should have received the camera frame.
    for req in transport.requests:
        assert req.observation.cameras.get("front", "").startswith("img_")


def test_load_config_rejects_non_mapping_cameras(tmp_path):
    path = _write_config(tmp_path, cameras=["not", "a", "mapping"])
    with pytest.raises(ValueError):
        load_config(path)
