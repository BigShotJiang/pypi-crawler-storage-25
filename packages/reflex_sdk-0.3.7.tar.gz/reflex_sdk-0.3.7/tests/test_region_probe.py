"""Unit tests for `reflex._region_probe` (CFG.1).

Mirrors the yam_cli probe tests but exercises the SDK-side copy and the
`_maybe_pin_session_to_nearest_region` wiring in `reflex.cli`.

The probe module is stdlib-only so the tests are too — we spin up tiny
in-process HTTPServers per region, give each a controllable sleep + status
code, and verify the resolver picks the lowest-RTT URL.
"""

from __future__ import annotations

import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer

import pytest

from reflex import _region_probe as region_probe
from reflex import cli as cli_module


# ── parse_region_map ────────────────────────────────────────────────────────


def test_parse_region_map_empty():
    assert region_probe.parse_region_map("") == []
    assert region_probe.parse_region_map("   ") == []


def test_parse_region_map_single():
    out = region_probe.parse_region_map("us-west=https://a.modal.run")
    assert out == [("us-west", "https://a.modal.run")]


def test_parse_region_map_multi_with_whitespace():
    spec = "  us-east =  https://east.url , us-west=https://west.url "
    assert region_probe.parse_region_map(spec) == [
        ("us-east", "https://east.url"),
        ("us-west", "https://west.url"),
    ]


def test_parse_region_map_skips_blank_entries():
    assert region_probe.parse_region_map("a=u1,,b=u2,") == [("a", "u1"), ("b", "u2")]


def test_parse_region_map_rejects_missing_equals():
    with pytest.raises(ValueError):
        region_probe.parse_region_map("us-east")


def test_parse_region_map_rejects_empty_label():
    with pytest.raises(ValueError):
        region_probe.parse_region_map("=https://x")


def test_parse_region_map_rejects_empty_url():
    with pytest.raises(ValueError):
        region_probe.parse_region_map("us-west=")


# ── probe / pick_nearest against an in-process HTTP server ──────────────────


class _DelayHandler(BaseHTTPRequestHandler):
    """Sleeps for `delay_s` then returns `status_code`. Path-agnostic."""

    delay_s: float = 0.0
    status_code: int = 200

    def do_GET(self):  # noqa: N802 — BaseHTTPRequestHandler API
        if self.delay_s > 0:
            time.sleep(self.delay_s)
        self.send_response(self.status_code)
        self.send_header("Content-Type", "text/plain")
        self.send_header("Content-Length", "2")
        self.end_headers()
        self.wfile.write(b"ok")

    def log_message(self, *args, **kwargs):  # silence test noise
        pass


def _start_server(delay_s: float = 0.0, status_code: int = 200) -> tuple[HTTPServer, str]:
    handler = type(
        f"H{int(delay_s * 1000)}_{status_code}",
        (_DelayHandler,),
        {"delay_s": delay_s, "status_code": status_code},
    )
    srv = HTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, f"http://127.0.0.1:{srv.server_address[1]}"


def test_probe_region_sees_steady_state_rtt():
    srv, url = _start_server(delay_s=0.02)
    try:
        r = region_probe.probe_region(
            "fast", url, attempts=3, warmup=1, timeout_s=2.0, settle_s=0.0
        )
        assert r.ok_count == 3
        assert r.p50_ms is not None
        assert 15 <= r.p50_ms < 500
    finally:
        srv.shutdown()


def test_pick_nearest_single_region_skips_probe():
    label, url, results = region_probe.pick_nearest(
        [("us-west", "http://127.0.0.1:1")],
    )
    assert label == "us-west"
    assert url == "http://127.0.0.1:1"
    assert len(results) == 1
    assert results[0].attempts == 0


def test_pick_nearest_picks_lowest_p50():
    fast, fast_url = _start_server(delay_s=0.01)
    slow, slow_url = _start_server(delay_s=0.08)
    try:
        label, url, results = region_probe.pick_nearest(
            [("slow", slow_url), ("fast", fast_url)],
            attempts=4, warmup=1, timeout_s=2.0, settle_s=0.0,
        )
        assert label == "fast"
        assert url == fast_url
        assert {r.label for r in results} == {"slow", "fast"}
    finally:
        fast.shutdown()
        slow.shutdown()


def test_pick_nearest_falls_back_when_all_fail():
    label, url, results = region_probe.pick_nearest(
        [("a", "http://127.0.0.1:1"), ("b", "http://127.0.0.1:2")],
        attempts=1, warmup=0, timeout_s=0.2, settle_s=0.0,
    )
    assert label == "a"
    assert url == "http://127.0.0.1:1"
    assert all(r.p50_ms is None for r in results)
    assert all(r.error_tail for r in results)


def test_pick_nearest_skips_non_2xx_targets():
    err, err_url = _start_server(delay_s=0.0, status_code=503)
    slow, slow_url = _start_server(delay_s=0.04, status_code=200)
    try:
        label, url, _ = region_probe.pick_nearest(
            [("err", err_url), ("slow", slow_url)],
            attempts=3, warmup=1, timeout_s=2.0, settle_s=0.0,
        )
        assert label == "slow"
        assert url == slow_url
    finally:
        err.shutdown()
        slow.shutdown()


# ── resolve_url ─────────────────────────────────────────────────────────────


def test_resolve_url_explicit_wins_over_everything(monkeypatch):
    monkeypatch.setenv(
        region_probe.DEFAULT_REGION_ENV,
        "us-east=http://127.0.0.1:9999,us-west=http://127.0.0.1:9998",
    )
    out = region_probe.resolve_url(
        "https://override.example", fallback_url="http://fallback",
    )
    assert out == "https://override.example"


def test_resolve_url_empty_env_returns_fallback(monkeypatch):
    monkeypatch.delenv(region_probe.DEFAULT_REGION_ENV, raising=False)
    out = region_probe.resolve_url(None, fallback_url="http://fb")
    assert out == "http://fb"


def test_resolve_url_single_entry_uses_it_no_probe(monkeypatch):
    monkeypatch.setenv(
        region_probe.DEFAULT_REGION_ENV, "us-west=http://unreachable:1",
    )
    out = region_probe.resolve_url(None, fallback_url="http://fb")
    assert out == "http://unreachable:1"


def test_resolve_url_multi_entry_probes_and_picks_fastest(monkeypatch):
    fast, fast_url = _start_server(delay_s=0.01)
    slow, slow_url = _start_server(delay_s=0.06)
    try:
        monkeypatch.setenv(
            region_probe.DEFAULT_REGION_ENV,
            f"slow={slow_url},fast={fast_url}",
        )
        out = region_probe.resolve_url(
            None, fallback_url="http://fb",
            attempts=3, warmup=1, timeout_s=2.0, settle_s=0.0,
        )
        assert out == fast_url
    finally:
        fast.shutdown()
        slow.shutdown()


def test_resolve_url_raises_when_no_fallback_and_no_map(monkeypatch):
    monkeypatch.delenv(region_probe.DEFAULT_REGION_ENV, raising=False)
    with pytest.raises(RuntimeError):
        region_probe.resolve_url(None, fallback_url=None)


# ── CLI wiring: _maybe_pin_session_to_nearest_region ────────────────────────


def _session(stream_url: str = "https://platform-default.modal.run") -> dict:
    return {
        "streamUrl": stream_url,
        "primeUrl": stream_url,
        "token": "tok-xyz",
        "sessionId": "sess-1",
    }


def test_pin_session_noop_when_env_unset(monkeypatch):
    monkeypatch.delenv(region_probe.DEFAULT_REGION_ENV, raising=False)
    session = _session()
    out = cli_module._maybe_pin_session_to_nearest_region(session)
    # Returns the same dict (no copy needed for the noop path).
    assert out is session
    assert "regionPinned" not in out


def test_pin_session_noop_for_single_entry_map(monkeypatch):
    monkeypatch.setenv(
        region_probe.DEFAULT_REGION_ENV, "us-west=https://x.modal.run",
    )
    session = _session()
    out = cli_module._maybe_pin_session_to_nearest_region(session)
    # Single-region → no probe, no override.
    assert out is session
    assert out["streamUrl"] == "https://platform-default.modal.run"


def test_pin_session_overrides_with_nearest_region(monkeypatch):
    fast, fast_url = _start_server(delay_s=0.01)
    slow, slow_url = _start_server(delay_s=0.06)
    try:
        monkeypatch.setenv(
            region_probe.DEFAULT_REGION_ENV,
            f"slow={slow_url},fast={fast_url}",
        )
        # Shrink probe params to keep the test snappy. Patching the module
        # constants is the lightest-touch approach since the helper doesn't
        # take overrides.
        monkeypatch.setattr(region_probe, "DEFAULT_PROBE_ATTEMPTS", 3)
        monkeypatch.setattr(region_probe, "DEFAULT_PROBE_WARMUP", 1)
        monkeypatch.setattr(region_probe, "DEFAULT_PROBE_SETTLE_S", 0.0)
        session = _session()
        out = cli_module._maybe_pin_session_to_nearest_region(session)
        assert out is not session  # caller-visible copy with overrides
        assert out["streamUrl"] == fast_url
        assert out["primeUrl"] == fast_url
        assert out["regionPinned"] == "fast"
        # Original session unmutated so closeSession sees platform URL.
        assert session["streamUrl"] == "https://platform-default.modal.run"
        assert "regionPinned" not in session
    finally:
        fast.shutdown()
        slow.shutdown()


def test_pin_session_rejects_malformed_env(monkeypatch):
    from reflex.product import ProductError

    monkeypatch.setenv(region_probe.DEFAULT_REGION_ENV, "no-equals-sign")
    with pytest.raises(ProductError):
        cli_module._maybe_pin_session_to_nearest_region(_session())
