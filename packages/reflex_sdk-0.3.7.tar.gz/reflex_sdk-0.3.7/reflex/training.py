"""Client helpers for metered Reflex training jobs."""

from __future__ import annotations

import asyncio
import json
from dataclasses import asdict, dataclass
from typing import Any

from ._version import user_agent
from ._convex import convex_action, convex_mutation
from ._transport import api_key as resolve_api_key
from ._transport import request_json

TRAINING_USER_AGENT = user_agent("reflex-training-sdk")


def _compact(payload: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in payload.items() if value is not None and value != ""}


def _base_model_id(value: str) -> str:
    normalized = value.strip()
    if normalized in {"pi0.5", "pi05", "lerobot/pi05_base"}:
        return "pi0.5"
    raise ValueError("Hosted Convex training currently supports base_model='pi0.5'.")


PI05_LORA_TARGET_MODULES = (
    "action_in_proj",
    "action_out_proj",
    "q_proj",
    "k_proj",
    "v_proj",
    "o_proj",
    "gate_proj",
    "up_proj",
    "down_proj",
)


def _parameters_json(
    parameters: dict[str, Any] | None,
    *,
    max_steps: int | None = None,
    batch_size: int | None = None,
    learning_rate: float | None = None,
    lora_rank: int | None = None,
    lora_alpha: int | None = None,
    lora_dropout: float | None = None,
    target_modules: list[str] | tuple[str, ...] | None = None,
    warmup_steps: int | None = None,
    gradient_checkpointing: bool | None = None,
    freeze_vision_encoder: bool | None = None,
    dtype: str | None = None,
    save_freq: int | None = None,
) -> str | None:
    merged: dict[str, Any] = dict(parameters or {})
    if max_steps is not None:
        merged["maxSteps"] = int(max_steps)
    if batch_size is not None:
        merged["batchSize"] = int(batch_size)
    if learning_rate is not None:
        merged["learningRate"] = float(learning_rate)

    lora = dict(merged.get("lora") or {})
    if lora_rank is not None:
        lora["rank"] = int(lora_rank)
    if lora_alpha is not None:
        lora["alpha"] = int(lora_alpha)
    if lora_dropout is not None:
        lora["dropout"] = float(lora_dropout)
    if target_modules is not None:
        lora["target_modules"] = list(target_modules)
    if lora:
        merged["lora"] = lora

    if warmup_steps is not None:
        merged["warmupSteps"] = int(warmup_steps)
    if gradient_checkpointing is not None:
        merged["gradient_checkpointing"] = bool(gradient_checkpointing)
    if freeze_vision_encoder is not None:
        merged["freeze_vision_encoder"] = bool(freeze_vision_encoder)
    if dtype is not None:
        merged["dtype"] = str(dtype)
    if save_freq is not None:
        merged["saveFreq"] = int(save_freq)

    return json.dumps(merged, separators=(",", ":"), sort_keys=True) if merged else None


def _training_args(
    *,
    api_key_value: str | None,
    dataset_id: str | None,
    hf_source_uri: str | None,
    base_model: str,
    base_model_id: str | None,
    fine_tuning_type: str,
    epochs: int,
    model_name: str,
    model_version: str,
    parameters_json: str | None,
    request_id: str,
) -> tuple[str, dict[str, Any]]:
    if fine_tuning_type not in {"lora", "full"}:
        raise ValueError("fine_tuning_type must be 'lora' or 'full'.")
    if bool(dataset_id) == bool(hf_source_uri):
        raise ValueError("Pass exactly one of dataset_id or hf_source_uri.")
    args = _compact(
        {
            "apiKey": resolve_api_key(api_key_value),
            "baseModel": _base_model_id(base_model),
            "baseModelId": base_model_id,
            "fineTuningType": fine_tuning_type,
            "epochs": max(1, int(epochs)),
            "modelName": model_name,
            "modelVersion": model_version,
            "parametersJson": parameters_json,
            "requestId": request_id,
        }
    )
    if hf_source_uri:
        args["hfSourceUri"] = hf_source_uri
        return "publicApi:createAndProvisionTrainingRunFromHuggingFace", args
    args["datasetId"] = dataset_id
    return "publicApi:createAndProvisionTrainingRun", args


def _with_training_aliases(payload: dict[str, Any]) -> dict[str, Any]:
    if "trainingRunId" in payload and "training_job_id" not in payload:
        payload = {**payload, "training_job_id": payload["trainingRunId"]}
    if "trainingRun" in payload and "training_job" not in payload:
        payload = {**payload, "training_job": payload["trainingRun"]}
    return payload


@dataclass(frozen=True)
class Datum:
    """One VLA training example for low-level Reflex training loops."""

    observation: dict[str, Any]
    actions: list[list[float]]
    loss_weights: list[float] | None = None
    metadata: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        return _compact(asdict(self))


@dataclass(frozen=True)
class AdamParams:
    learning_rate: float
    beta1: float = 0.9
    beta2: float = 0.95
    eps: float = 1e-8
    weight_decay: float = 0.0
    max_grad_norm: float | None = None

    def to_dict(self) -> dict[str, Any]:
        return _compact(asdict(self))


@dataclass(frozen=True)
class ForwardBackwardResult:
    loss: float | None
    metrics: dict[str, Any]
    raw: dict[str, Any]


@dataclass(frozen=True)
class OptimStepResult:
    step: int | None
    metrics: dict[str, Any]
    raw: dict[str, Any]


@dataclass(frozen=True)
class AdapterHandle:
    lora: str
    name: str
    version: str
    adapter_id: str
    raw: dict[str, Any]


def _data_payload(data: Any) -> Any:
    if isinstance(data, Datum):
        return data.to_dict()
    if isinstance(data, list):
        return [_data_payload(item) for item in data]
    if isinstance(data, tuple):
        return [_data_payload(item) for item in data]
    return data


def _adapter_handle(payload: dict[str, Any]) -> AdapterHandle:
    adapter = dict(payload.get("adapter") or {})
    name = str(payload.get("name") or adapter.get("name") or "")
    version = str(payload.get("version") or adapter.get("version") or "")
    adapter_id = str(payload.get("adapter_id") or payload.get("adapterId") or adapter.get("_id") or "")
    lora = str(payload.get("lora") or payload.get("adapter_ref") or payload.get("adapterRef") or "")
    if not lora and name and version:
        lora = f"{name}@{version}"
    return AdapterHandle(lora=lora, name=name, version=version, adapter_id=adapter_id, raw=payload)


class LoraTrainingClient:
    """Tinker-like low-level LoRA training client for Reflex."""

    def __init__(
        self,
        *,
        url: str | None,
        api_key: str | None,
        run_id: str,
        base_model: str,
        name: str = "",
        rank: int | None = None,
        raw: dict[str, Any] | None = None,
    ) -> None:
        self._url = url
        self._api_key = api_key
        self.run_id = run_id
        self.base_model = base_model
        self.name = name
        self.rank = rank
        self.raw = raw or {}

    def forward_backward(
        self,
        data: Any,
        loss_fn: str = "behavior_cloning",
        *,
        microbatch_size: int | None = None,
        request_id: str = "",
    ) -> ForwardBackwardResult:
        payload = request_json(
            url=self._url,
            api_key_value=self._api_key,
            path=f"/v1/training-runs/{self.run_id}/forward-backward",
            payload=_compact(
                {
                    "data": _data_payload(data),
                    "loss_fn": loss_fn,
                    "microbatch_size": microbatch_size,
                    "request_id": request_id,
                }
            ),
            user_agent=TRAINING_USER_AGENT,
        )
        loss = payload.get("loss")
        return ForwardBackwardResult(
            loss=float(loss) if isinstance(loss, (int, float)) else None,
            metrics=dict(payload.get("metrics") or {}),
            raw=payload,
        )

    async def forward_backward_async(
        self,
        data: Any,
        loss_fn: str = "behavior_cloning",
        *,
        microbatch_size: int | None = None,
        request_id: str = "",
    ) -> ForwardBackwardResult:
        return await asyncio.to_thread(
            self.forward_backward,
            data,
            loss_fn,
            microbatch_size=microbatch_size,
            request_id=request_id,
        )

    def optim_step(
        self,
        params: AdamParams | dict[str, Any],
        *,
        request_id: str = "",
    ) -> OptimStepResult:
        payload = request_json(
            url=self._url,
            api_key_value=self._api_key,
            path=f"/v1/training-runs/{self.run_id}/optim-step",
            payload={
                "optimizer": "adam",
                "params": params.to_dict() if isinstance(params, AdamParams) else params,
                "request_id": request_id,
            },
            user_agent=TRAINING_USER_AGENT,
        )
        step = payload.get("step")
        return OptimStepResult(
            step=int(step) if isinstance(step, int) else None,
            metrics=dict(payload.get("metrics") or {}),
            raw=payload,
        )

    async def optim_step_async(
        self,
        params: AdamParams | dict[str, Any],
        *,
        request_id: str = "",
    ) -> OptimStepResult:
        return await asyncio.to_thread(self.optim_step, params, request_id=request_id)

    def save_adapter(self, *, name: str = "", version: str = "") -> AdapterHandle:
        payload = request_json(
            url=self._url,
            api_key_value=self._api_key,
            path=f"/v1/training-runs/{self.run_id}/save-adapter",
            payload=_compact({"name": name or self.name, "version": version}),
            user_agent=TRAINING_USER_AGENT,
        )
        return _adapter_handle(payload)

    async def save_adapter_async(self, *, name: str = "", version: str = "") -> AdapterHandle:
        return await asyncio.to_thread(self.save_adapter, name=name, version=version)

    def save_state(self, *, name: str) -> dict[str, Any]:
        return request_json(
            url=self._url,
            api_key_value=self._api_key,
            path=f"/v1/training-runs/{self.run_id}/save-state",
            payload={"name": name},
            user_agent=TRAINING_USER_AGENT,
        )

    async def save_state_async(self, *, name: str) -> dict[str, Any]:
        return await asyncio.to_thread(self.save_state, name=name)

    def status(self) -> dict[str, Any]:
        return request_json(
            url=self._url,
            api_key_value=self._api_key,
            path=f"/v1/training-runs/{self.run_id}",
            method="GET",
            user_agent=TRAINING_USER_AGENT,
        )


class ServiceClient:
    """Reflex service entry point matching Tinker's training-client pattern."""

    def __init__(self, *, api_key: str | None = None, url: str | None = None) -> None:
        self.api_key = api_key
        self.url = url

    def create_lora_training_client(
        self,
        *,
        base_model: str = "pi0.7-flash",
        name: str = "",
        rank: int = 32,
        dataset_id: str = "",
        max_minutes: int | None = None,
        request_id: str = "",
        config: dict[str, Any] | None = None,
    ) -> LoraTrainingClient:
        payload = request_json(
            url=self.url,
            api_key_value=self.api_key,
            path="/v1/training-runs/lora",
            payload=_compact(
                {
                    "base_model": base_model,
                    "name": name,
                    "rank": rank,
                    "dataset_id": dataset_id,
                    "max_minutes": max_minutes,
                    "request_id": request_id,
                    "config": config or {},
                }
            ),
            user_agent=TRAINING_USER_AGENT,
        )
        run_id = str(payload.get("training_run_id") or payload.get("run_id") or payload.get("id") or "")
        if not run_id:
            raise RuntimeError(f"Training run create response did not include run id: {payload!r}")
        return LoraTrainingClient(
            url=self.url,
            api_key=self.api_key,
            run_id=run_id,
            base_model=base_model,
            name=name,
            rank=rank,
            raw=payload,
        )

    async def create_lora_training_client_async(
        self,
        *,
        base_model: str = "pi0.7-flash",
        name: str = "",
        rank: int = 32,
        dataset_id: str = "",
        max_minutes: int | None = None,
        request_id: str = "",
        config: dict[str, Any] | None = None,
    ) -> LoraTrainingClient:
        return await asyncio.to_thread(
            self.create_lora_training_client,
            base_model=base_model,
            name=name,
            rank=rank,
            dataset_id=dataset_id,
            max_minutes=max_minutes,
            request_id=request_id,
            config=config,
        )


def create_training_job(
    *,
    url: str | None = None,
    convex_url: str | None = None,
    api_key: str | None = None,
    dataset_id: str | None = None,
    hf_source_uri: str | None = None,
    base_model: str = "pi0.5",
    base_model_id: str | None = None,
    fine_tuning_type: str = "lora",
    adapter_name: str = "",
    model_name: str = "",
    version: str = "v1",
    model_version: str = "",
    max_minutes: int | None = None,
    request_id: str = "",
    epochs: int | None = None,
    parameters: dict[str, Any] | None = None,
    max_steps: int | None = None,
    batch_size: int | None = None,
    learning_rate: float | None = None,
    lora_rank: int | None = None,
    lora_alpha: int | None = None,
    lora_dropout: float | None = None,
    target_modules: list[str] | tuple[str, ...] | None = None,
    warmup_steps: int | None = None,
    gradient_checkpointing: bool | None = None,
    freeze_vision_encoder: bool | None = None,
    dtype: str | None = None,
    save_freq: int | None = None,
) -> dict[str, Any]:
    """Start a hosted Convex-backed training job through the public API-key path.

    Advanced parameters (all optional, server-side validated):
        lora_alpha: LoRA scaling factor; defaults to ``lora_rank`` when unset. Bounds [1, 256].
        lora_dropout: LoRA dropout probability. Bounds [0.0, 0.5].
        target_modules: List of module names to LoRA-adapt. Whitelisted on the server.
        warmup_steps: Warmup steps for the LR schedule. Bounds [0, max_steps/2].
        gradient_checkpointing: Trade compute for memory by recomputing activations.
        freeze_vision_encoder: Freeze the vision encoder (commonly True for LoRA fine-tunes).
        dtype: Compute dtype, one of {"bfloat16", "float32"}.
        save_freq: How often to checkpoint, in steps. Bounds [50, max_steps].
    """
    del url
    merged_parameters = dict(parameters or {})
    if max_minutes is not None:
        merged_parameters["maxMinutes"] = int(max_minutes)
    function_name, args = _training_args(
        api_key_value=api_key,
        dataset_id=dataset_id,
        hf_source_uri=hf_source_uri,
        base_model=base_model,
        base_model_id=base_model_id,
        fine_tuning_type=fine_tuning_type,
        epochs=epochs or 1,
        model_name=model_name or adapter_name or f"pi05-{fine_tuning_type}",
        model_version=model_version or version,
        parameters_json=_parameters_json(
            merged_parameters,
            max_steps=max_steps,
            batch_size=batch_size,
            learning_rate=learning_rate,
            lora_rank=lora_rank,
            lora_alpha=lora_alpha,
            lora_dropout=lora_dropout,
            target_modules=target_modules,
            warmup_steps=warmup_steps,
            gradient_checkpointing=gradient_checkpointing,
            freeze_vision_encoder=freeze_vision_encoder,
            dtype=dtype,
            save_freq=save_freq,
        ),
        request_id=request_id,
    )
    payload = convex_action(function_name, args, url=convex_url)
    if not isinstance(payload, dict):
        raise RuntimeError(f"Unexpected Convex training response: {payload!r}")
    return _with_training_aliases(payload)


def lora_finetune(
    *,
    dataset_id: str | None = None,
    hf_source_uri: str | None = None,
    model_name: str = "pi05-lora",
    model_version: str = "v1",
    epochs: int = 1,
    base_model: str = "pi0.5",
    base_model_id: str | None = None,
    lora_rank: int | None = None,
    max_steps: int | None = None,
    batch_size: int | None = None,
    learning_rate: float | None = None,
    parameters: dict[str, Any] | None = None,
    request_id: str = "",
    api_key: str | None = None,
    convex_url: str | None = None,
    # Advanced (additive, all optional, server-side validated):
    lora_alpha: int | None = None,
    lora_dropout: float | None = None,
    target_modules: list[str] | tuple[str, ...] | None = None,
    warmup_steps: int | None = None,
    gradient_checkpointing: bool | None = None,
    freeze_vision_encoder: bool | None = None,
    dtype: str | None = None,
    save_freq: int | None = None,
) -> dict[str, Any]:
    """Register/provision a hosted LoRA fine-tune from a dataset id or HF dataset URI.

    See :func:`create_training_job` for a description of the advanced parameters
    and their server-enforced bounds.
    """
    return create_training_job(
        convex_url=convex_url,
        api_key=api_key,
        dataset_id=dataset_id,
        hf_source_uri=hf_source_uri,
        base_model=base_model,
        base_model_id=base_model_id,
        fine_tuning_type="lora",
        model_name=model_name,
        model_version=model_version,
        epochs=epochs,
        parameters=parameters,
        lora_rank=lora_rank,
        max_steps=max_steps,
        batch_size=batch_size,
        learning_rate=learning_rate,
        lora_alpha=lora_alpha,
        lora_dropout=lora_dropout,
        target_modules=target_modules,
        warmup_steps=warmup_steps,
        gradient_checkpointing=gradient_checkpointing,
        freeze_vision_encoder=freeze_vision_encoder,
        dtype=dtype,
        save_freq=save_freq,
        request_id=request_id,
    )


def full_finetune(
    *,
    dataset_id: str | None = None,
    hf_source_uri: str | None = None,
    model_name: str = "pi05-full",
    model_version: str = "v1",
    epochs: int = 1,
    base_model: str = "pi0.5",
    base_model_id: str | None = None,
    max_steps: int | None = None,
    batch_size: int | None = None,
    learning_rate: float | None = None,
    parameters: dict[str, Any] | None = None,
    request_id: str = "",
    api_key: str | None = None,
    convex_url: str | None = None,
    # Advanced (additive, all optional, server-side validated):
    warmup_steps: int | None = None,
    gradient_checkpointing: bool | None = None,
    freeze_vision_encoder: bool | None = None,
    dtype: str | None = None,
    save_freq: int | None = None,
) -> dict[str, Any]:
    """Register/provision a hosted full fine-tune from a dataset id or HF dataset URI.

    See :func:`create_training_job` for a description of the advanced parameters
    and their server-enforced bounds. LoRA-specific params (``lora_alpha``,
    ``lora_dropout``, ``target_modules``) are not accepted for full fine-tunes.
    """
    return create_training_job(
        convex_url=convex_url,
        api_key=api_key,
        dataset_id=dataset_id,
        hf_source_uri=hf_source_uri,
        base_model=base_model,
        base_model_id=base_model_id,
        fine_tuning_type="full",
        model_name=model_name,
        model_version=model_version,
        epochs=epochs,
        parameters=parameters,
        max_steps=max_steps,
        batch_size=batch_size,
        learning_rate=learning_rate,
        warmup_steps=warmup_steps,
        gradient_checkpointing=gradient_checkpointing,
        freeze_vision_encoder=freeze_vision_encoder,
        dtype=dtype,
        save_freq=save_freq,
        request_id=request_id,
    )


full_train = full_finetune


def get_training_job(
    training_job_id: str,
    *,
    url: str | None = None,
    convex_url: str | None = None,
    api_key: str | None = None,
) -> dict[str, Any]:
    """Return status and logs for a training job visible to the API key."""
    del url
    payload = convex_mutation(
        "publicApi:getTrainingRun",
        {"apiKey": resolve_api_key(api_key), "trainingRunId": training_job_id},
        url=convex_url,
    )
    if not isinstance(payload, dict):
        raise RuntimeError(f"Unexpected Convex training response: {payload!r}")
    return _with_training_aliases(payload)


def list_training_jobs(
    *,
    status: str | None = None,
    url: str | None = None,
    convex_url: str | None = None,
    api_key: str | None = None,
) -> dict[str, Any]:
    """List hosted training jobs visible to the API key."""
    del url
    args = _compact({"apiKey": resolve_api_key(api_key), "status": status})
    payload = convex_mutation("publicApi:listTrainingRuns", args, url=convex_url)
    if not isinstance(payload, dict):
        raise RuntimeError(f"Unexpected Convex training response: {payload!r}")
    return payload


def cancel_training_job(
    training_job_id: str,
    *,
    url: str | None = None,
    convex_url: str | None = None,
    api_key: str | None = None,
) -> dict[str, Any]:
    """Cancel a running training job and release/settle metered resources."""
    del url
    payload = convex_mutation(
        "publicApi:stopTrainingRun",
        {"apiKey": resolve_api_key(api_key), "trainingRunId": training_job_id},
        url=convex_url,
    )
    if not isinstance(payload, dict):
        raise RuntimeError(f"Unexpected Convex training response: {payload!r}")
    return _with_training_aliases(payload)
