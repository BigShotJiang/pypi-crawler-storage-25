"""Client-side nearest-region probe for the Reflex SDK CLI (CFG.1).

When `REFLEX_INFERENCE_REGION_MAP=region=URL,region=URL,...` is set, the
CLI hits each URL's `/health` at startup, picks the lowest-p50 region,
and uses that URL for the inference stream instead of the one the
platform returned. This buys ~20-60ms RTT on multi-region deploys
without server-side changes (NetR.3a finding, re-nr7l).

Single-entry maps skip the probe entirely (zero startup cost), so the
default single-region behaviour is unchanged until a multi-region map
is configured.

Stdlib-only (urllib + statistics) so it runs in any environment the
rest of the published `reflex` package runs in.
"""

from __future__ import annotations

import os
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Callable, Optional

DEFAULT_REGION_ENV = "REFLEX_INFERENCE_REGION_MAP"
DEFAULT_PROBE_ATTEMPTS = 5
DEFAULT_PROBE_WARMUP = 1
DEFAULT_PROBE_TIMEOUT_S = 5.0
DEFAULT_PROBE_SETTLE_S = 0.05


@dataclass(frozen=True)
class RegionResult:
    label: str
    url: str
    ok_count: int
    attempts: int
    p50_ms: Optional[float]
    error_tail: Optional[str] = None


def parse_region_map(spec: str) -> list[tuple[str, str]]:
    """Parse `region1=url1,region2=url2[,...]` into `[(label, url), ...]`.

    Empty input → []. Malformed entries raise `ValueError` so a typo in
    the env var fails loudly instead of silently routing to the wrong
    region.
    """
    if not spec or not spec.strip():
        return []
    items: list[tuple[str, str]] = []
    for raw in spec.split(","):
        raw = raw.strip()
        if not raw:
            continue
        if "=" not in raw:
            raise ValueError(f"region map entry missing '=': {raw!r}")
        label, url = raw.split("=", 1)
        label, url = label.strip(), url.strip()
        if not label or not url:
            raise ValueError(f"empty label or url in region map entry: {raw!r}")
        items.append((label, url))
    return items


def _pct(samples: list[float], q: float) -> Optional[float]:
    if not samples:
        return None
    s = sorted(samples)
    idx = max(0, min(len(s) - 1, int(round(q * (len(s) - 1)))))
    return round(s[idx], 2)


def _probe_once(url: str, timeout_s: float) -> tuple[Optional[float], Optional[str]]:
    started = time.perf_counter()
    try:
        req = urllib.request.Request(
            url, headers={"User-Agent": "reflex-sdk-region-probe/1.0"}
        )
        with urllib.request.urlopen(req, timeout=timeout_s) as response:
            response.read()  # drain so the conn closes cleanly
            if not (200 <= response.status < 300):
                return None, f"HTTP {response.status}"
    except urllib.error.HTTPError as exc:
        return None, f"HTTPError {exc.code}: {exc.reason}"
    except Exception as exc:  # noqa: BLE001 — any failure → unviable target
        return None, f"{type(exc).__name__}: {exc}"
    return (time.perf_counter() - started) * 1000.0, None


def probe_region(
    label: str,
    url: str,
    *,
    attempts: int = DEFAULT_PROBE_ATTEMPTS,
    warmup: int = DEFAULT_PROBE_WARMUP,
    timeout_s: float = DEFAULT_PROBE_TIMEOUT_S,
    settle_s: float = DEFAULT_PROBE_SETTLE_S,
) -> RegionResult:
    """Hit `<url>/health` `warmup + attempts` times; return per-region stats.

    Warmup probes amortise TCP/TLS handshake + Modal proxy cold-route so
    the p50 reflects steady-state RTT.
    """
    health = url.rstrip("/") + "/health"
    for _ in range(warmup):
        _probe_once(health, timeout_s)
        if settle_s > 0:
            time.sleep(settle_s)
    samples: list[float] = []
    last_err: Optional[str] = None
    for _ in range(attempts):
        rtt, err = _probe_once(health, timeout_s)
        if rtt is not None:
            samples.append(rtt)
        elif err is not None:
            last_err = err
        if settle_s > 0:
            time.sleep(settle_s)
    return RegionResult(
        label=label,
        url=url,
        attempts=attempts,
        ok_count=len(samples),
        p50_ms=_pct(samples, 0.5),
        error_tail=last_err if not samples else None,
    )


def pick_nearest(
    region_map: list[tuple[str, str]],
    *,
    attempts: int = DEFAULT_PROBE_ATTEMPTS,
    warmup: int = DEFAULT_PROBE_WARMUP,
    timeout_s: float = DEFAULT_PROBE_TIMEOUT_S,
    settle_s: float = DEFAULT_PROBE_SETTLE_S,
    log: Optional[Callable[[RegionResult], None]] = None,
) -> tuple[str, str, list[RegionResult]]:
    """Return `(label, url, all_results)` for the lowest-p50 region.

    Single-region maps skip the probe entirely. All-fail falls back to
    the first entry so the caller always gets a usable URL — better to
    attempt against a known-stale endpoint than refuse to start.
    """
    if not region_map:
        raise ValueError("region_map is empty")
    if len(region_map) == 1:
        label, url = region_map[0]
        result = RegionResult(
            label=label, url=url, attempts=0, ok_count=0, p50_ms=None,
        )
        if log is not None:
            log(result)
        return label, url, [result]
    results: list[RegionResult] = []
    for label, url in region_map:
        r = probe_region(
            label, url,
            attempts=attempts, warmup=warmup,
            timeout_s=timeout_s, settle_s=settle_s,
        )
        if log is not None:
            log(r)
        results.append(r)
    viable = [r for r in results if r.p50_ms is not None]
    if not viable:
        first = results[0]
        return first.label, first.url, results
    best = min(viable, key=lambda r: r.p50_ms)  # type: ignore[arg-type,return-value]
    return best.label, best.url, results


def resolve_url(
    explicit_url: Optional[str],
    *,
    region_map: Optional[list[tuple[str, str]]] = None,
    env_var: str = DEFAULT_REGION_ENV,
    fallback_url: Optional[str] = None,
    attempts: int = DEFAULT_PROBE_ATTEMPTS,
    warmup: int = DEFAULT_PROBE_WARMUP,
    timeout_s: float = DEFAULT_PROBE_TIMEOUT_S,
    settle_s: float = DEFAULT_PROBE_SETTLE_S,
    log: Optional[Callable[[RegionResult], None]] = None,
) -> str:
    """Resolve the URL to use, honouring explicit > region-map > fallback.

    - `explicit_url` truthy → return as-is (server-returned URL wins
      unless overridden by env).
    - Else parse `region_map` (or `os.environ[env_var]` if not given).
    - Empty map → return `fallback_url` (preserves current behaviour).
    - Non-empty map → `pick_nearest` and return its URL.
    """
    if explicit_url:
        return explicit_url
    if region_map is None:
        region_map = parse_region_map(os.environ.get(env_var, ""))
    if not region_map:
        if fallback_url is None:
            raise RuntimeError(
                f"resolve_url: env var {env_var} is empty and no fallback_url given"
            )
        return fallback_url
    _, url, _ = pick_nearest(
        region_map,
        attempts=attempts, warmup=warmup,
        timeout_s=timeout_s, settle_s=settle_s,
        log=log,
    )
    return url
