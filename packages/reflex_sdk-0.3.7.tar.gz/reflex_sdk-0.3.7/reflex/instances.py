"""Client helpers for metered Reflex GPU instance provisioning."""

from __future__ import annotations

from typing import Any

from ._version import user_agent
from ._transport import request_json

INSTANCES_USER_AGENT = user_agent("reflex-instances-sdk")


def provision_instance(
    *,
    url: str | None = None,
    api_key: str | None = None,
    region: str = "auto",
    instance_type: str = "auto",
    allowed_ssh_cidrs: list[str] | None = None,
    allowed_webrtc_cidrs: list[str] | None = None,
    hf_token: str = "",
    spot: bool = False,
    volume_size: int = 200,
    robot_id: str = "",
    billing_max_gpu_seconds: float = 3600,
) -> dict[str, Any]:
    """Provision a Reflex-managed GPU instance after reserving customer credits."""
    return request_json(
        url=url,
        api_key_value=api_key,
        path="/deployments/provision",
        user_agent=INSTANCES_USER_AGENT,
        payload={
            "region": region,
            "instance_type": instance_type,
            "allowed_ssh_cidrs": allowed_ssh_cidrs or [],
            "allowed_webrtc_cidrs": allowed_webrtc_cidrs or ["0.0.0.0/0"],
            "hf_token": hf_token,
            "spot": spot,
            "volume_size": volume_size,
            "robot_id": robot_id,
            "billing_max_gpu_seconds": billing_max_gpu_seconds,
        },
    )


def instance_status(*, url: str | None = None, api_key: str | None = None) -> dict[str, Any]:
    """Return the latest deployment visible to the API key."""
    return request_json(
        url=url,
        api_key_value=api_key,
        path="/deployments/status",
        method="GET",
        user_agent=INSTANCES_USER_AGENT,
    )


def teardown_instance(*, url: str | None = None, api_key: str | None = None) -> dict[str, Any]:
    """Tear down the latest deployment visible to the API key and settle usage."""
    return request_json(
        url=url,
        api_key_value=api_key,
        path="/deployments/teardown",
        user_agent=INSTANCES_USER_AGENT,
    )
