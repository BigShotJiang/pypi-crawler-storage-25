"""Minimal SO-101 serial adapter for the Reflex CLI."""

from __future__ import annotations

import base64
import binascii
import glob
import logging
import os
import struct
import time
import zlib
from dataclasses import dataclass
from typing import Any


class So101Error(RuntimeError):
    pass


SO101_MOTORS: dict[str, int] = {
    "shoulder_pan": 1,
    "shoulder_lift": 2,
    "elbow_flex": 3,
    "wrist_flex": 4,
    "wrist_roll": 5,
    "gripper": 6,
}
SO101_MOTOR_NAMES = tuple(SO101_MOTORS)
SO101_NEUTRAL_POSITION: dict[str, float] = {
    "shoulder_pan": 0.0,
    "shoulder_lift": 0.0,
    "elbow_flex": 0.0,
    "wrist_flex": 0.0,
    "wrist_roll": 0.0,
    "gripper": 0.0,
}
_LEROBOT_CLAMP_WARNING_PREFIX = "Relative goal position magnitude had to be clamped to be safe"


def _is_lerobot_clamp_warning(record: logging.LogRecord) -> bool:
    return record.getMessage().startswith(_LEROBOT_CLAMP_WARNING_PREFIX)


class _LerobotClampWarningFilter(logging.Filter):
    _reflex_lerobot_clamp_filter = True

    def filter(self, record: logging.LogRecord) -> bool:
        return not _is_lerobot_clamp_warning(record)


_LEROBOT_CLAMP_WARNING_FILTER = _LerobotClampWarningFilter()


def _install_lerobot_clamp_logger_patch() -> None:
    if getattr(logging.Logger, "_reflex_lerobot_clamp_handle_patched", False):
        return
    original_handle = logging.Logger.handle

    def reflex_handle(self: logging.Logger, record: logging.LogRecord) -> None:
        if _is_lerobot_clamp_warning(record):
            return
        original_handle(self, record)

    logging.Logger.handle = reflex_handle  # type: ignore[method-assign]
    logging.Logger._reflex_lerobot_clamp_handle_patched = True  # type: ignore[attr-defined]


def _install_lerobot_clamp_warning_filter() -> None:
    _install_lerobot_clamp_logger_patch()
    root_logger = logging.getLogger()
    if not any(
        getattr(log_filter, "_reflex_lerobot_clamp_filter", False)
        for log_filter in root_logger.filters
    ):
        root_logger.addFilter(_LEROBOT_CLAMP_WARNING_FILTER)
    if logging.lastResort is not None and not any(
        getattr(log_filter, "_reflex_lerobot_clamp_filter", False)
        for log_filter in logging.lastResort.filters
    ):
        logging.lastResort.addFilter(_LEROBOT_CLAMP_WARNING_FILTER)
    for handler in root_logger.handlers:
        if not any(
            getattr(log_filter, "_reflex_lerobot_clamp_filter", False)
            for log_filter in handler.filters
        ):
            handler.addFilter(_LEROBOT_CLAMP_WARNING_FILTER)


_install_lerobot_clamp_warning_filter()


def _sample_even_action_rows(
    rows: list[list[float]],
    action_steps: int,
) -> list[tuple[int, list[float]]]:
    return list(enumerate(rows[:50]))[0::2][:action_steps]


def _coerce_so101_position(value: Any, *, label: str) -> dict[str, float] | None:
    if value is None:
        return None
    if isinstance(value, dict):
        missing = [name for name in SO101_MOTOR_NAMES if name not in value]
        if missing:
            raise So101Error(f"{label} missing SO-101 joints: {', '.join(missing)}")
        result: dict[str, float] = {}
        for name in SO101_MOTOR_NAMES:
            raw = value[name]
            if not isinstance(raw, (int, float)):
                raise So101Error(f"{label} joint {name} must be numeric")
            result[name] = float(raw)
        return result
    if isinstance(value, (list, tuple)):
        if len(value) != len(SO101_MOTOR_NAMES):
            raise So101Error(
                f"{label} must include {len(SO101_MOTOR_NAMES)} SO-101 joint values"
            )
        result = {}
        for name, raw in zip(SO101_MOTOR_NAMES, value):
            if not isinstance(raw, (int, float)):
                raise So101Error(f"{label} joint {name} must be numeric")
            result[name] = float(raw)
        return result
    raise So101Error(f"{label} must be a mapping or {len(SO101_MOTOR_NAMES)}-value sequence")


def _coerce_raw_so101_position(value: Any, *, label: str) -> dict[str, int] | None:
    if value is None:
        return None
    if isinstance(value, dict):
        missing = [name for name in SO101_MOTOR_NAMES if name not in value]
        if missing:
            raise So101Error(f"{label} missing SO-101 joints: {', '.join(missing)}")
        result: dict[str, int] = {}
        for name in SO101_MOTOR_NAMES:
            raw = value[name]
            if not isinstance(raw, (int, float)):
                raise So101Error(f"{label} joint {name} must be numeric")
            result[name] = max(0, min(4095, int(raw)))
        return result
    if isinstance(value, (int, float)):
        target = max(0, min(4095, int(value)))
        return {name: target for name in SO101_MOTOR_NAMES}
    raise So101Error(f"{label} must be a raw integer target or SO-101 joint mapping")


STS3215_MODEL_NUMBER = 777
DEFAULT_BAUDRATE = 1_000_000
SCAN_BAUDRATES = (1_000_000, 500_000, 250_000, 128_000, 115_200, 57_600)

REG_MODEL_NUMBER = (3, 2)
REG_TORQUE_ENABLE = (40, 1)
REG_ACCELERATION = (41, 1)
REG_GOAL_POSITION = (42, 2)
REG_LOCK = (55, 1)
REG_PRESENT_POSITION = (56, 2)

INST_PING = 1
INST_READ = 2
INST_WRITE = 3


def _load_serial_module() -> Any:
    try:
        import serial  # type: ignore[import-not-found]
    except ModuleNotFoundError as exc:
        raise So101Error(
            "SO-101 mode requires pyserial. Reinstall the local CLI with "
            "`uv tool install --force --reinstall --editable ./sdk/python`."
        ) from exc
    return serial


def _unique(values: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        result.append(value)
    return result


def candidate_ports() -> list[str]:
    configured = os.environ.get("REFLEX_SO101_PORT", "").strip()
    patterns = [
        "/dev/cu.usbmodem*",
        "/dev/tty.usbmodem*",
        "/dev/cu.usbserial*",
        "/dev/tty.usbserial*",
        "/dev/cu.wchusbserial*",
        "/dev/tty.wchusbserial*",
        "/dev/cu.SLAB_USBtoUART*",
        "/dev/tty.SLAB_USBtoUART*",
        "/dev/ttyACM*",
        "/dev/ttyUSB*",
    ]
    ports = [configured] if configured else []
    for pattern in patterns:
        ports.extend(sorted(glob.glob(pattern)))
    return _unique([port for port in ports if port])


def _png_chunk(kind: bytes, data: bytes) -> bytes:
    return (
        struct.pack(">I", len(data))
        + kind
        + data
        + struct.pack(">I", binascii.crc32(kind + data) & 0xFFFFFFFF)
    )


def zero_png_base64(width: int = 224, height: int = 224) -> str:
    rows = b"".join(b"\x00" + (b"\x00" * width * 3) for _ in range(height))
    raw = (
        b"\x89PNG\r\n\x1a\n"
        + _png_chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0))
        + _png_chunk(b"IDAT", zlib.compress(rows, level=9))
        + _png_chunk(b"IEND", b"")
    )
    return base64.b64encode(raw).decode("ascii")


class FeetechBus:
    def __init__(self, port: str, *, baudrate: int = DEFAULT_BAUDRATE, timeout: float = 0.12):
        self.port = port
        self.baudrate = baudrate
        self.timeout = timeout
        self._serial: Any | None = None

    def connect(self) -> None:
        serial = _load_serial_module()
        self._serial = serial.Serial(
            self.port,
            self.baudrate,
            timeout=self.timeout,
            write_timeout=self.timeout,
        )
        self._serial.reset_input_buffer()
        self._serial.reset_output_buffer()

    def close(self) -> None:
        if self._serial is not None:
            self._serial.close()
            self._serial = None

    def set_baudrate(self, baudrate: int) -> None:
        if self._serial is None:
            raise So101Error("bus is not connected")
        self.baudrate = baudrate
        self._serial.baudrate = baudrate
        self._serial.reset_input_buffer()

    def _packet(self, motor_id: int, instruction: int, params: list[int]) -> bytes:
        body = [motor_id, len(params) + 2, instruction, *params]
        checksum = (~sum(body)) & 0xFF
        return bytes([0xFF, 0xFF, *body, checksum])

    def _write_packet(self, motor_id: int, instruction: int, params: list[int]) -> None:
        if self._serial is None:
            raise So101Error("bus is not connected")
        self._serial.reset_input_buffer()
        self._serial.write(self._packet(motor_id, instruction, params))
        self._serial.flush()

    def _read_status(self, *, expected_id: int | None = None) -> tuple[int, int, bytes]:
        if self._serial is None:
            raise So101Error("bus is not connected")

        deadline = time.monotonic() + max(0.25, self.timeout * 4)
        while time.monotonic() < deadline:
            first = self._serial.read(1)
            if not first:
                continue
            if first != b"\xff":
                continue
            second = self._serial.read(1)
            if second == b"\xff":
                break
        else:
            raise So101Error("serial timeout waiting for Feetech status header")

        header = self._serial.read(2)
        if len(header) != 2:
            raise So101Error("short Feetech status header")
        motor_id = header[0]
        length = header[1]
        body = self._serial.read(length)
        if len(body) != length:
            raise So101Error("short Feetech status body")
        if expected_id is not None and motor_id != expected_id:
            raise So101Error(f"unexpected status id {motor_id}, expected {expected_id}")

        checksum = body[-1]
        expected_checksum = (~(motor_id + length + sum(body[:-1]))) & 0xFF
        if checksum != expected_checksum:
            raise So101Error("bad Feetech status checksum")
        error = body[0]
        params = body[1:-1]
        if error:
            raise So101Error(f"Feetech motor {motor_id} returned error 0x{error:02x}")
        return motor_id, error, params

    def read_register(self, motor_id: int, address: int, length: int) -> int:
        self._write_packet(motor_id, INST_READ, [address, length])
        _, _, params = self._read_status(expected_id=motor_id)
        if len(params) < length:
            raise So101Error(f"short read response from motor {motor_id}")
        return int.from_bytes(params[:length], "little", signed=False)

    def write_register(self, motor_id: int, address: int, length: int, value: int) -> None:
        if value < 0:
            raise So101Error("negative register writes are not supported")
        data = list(int(value).to_bytes(length, "little", signed=False))
        self._write_packet(motor_id, INST_WRITE, [address, *data])
        self._read_status(expected_id=motor_id)

    def read_model_number(self, motor_id: int) -> int:
        address, length = REG_MODEL_NUMBER
        return self.read_register(motor_id, address, length)

    def read_present_position(self, motor_id: int) -> int:
        address, length = REG_PRESENT_POSITION
        value = self.read_register(motor_id, address, length)
        if value & 0x8000:
            return -(value & 0x7FFF)
        return value

    def read_torque_enable(self, motor_id: int) -> int:
        address, length = REG_TORQUE_ENABLE
        return self.read_register(motor_id, address, length)

    def write_goal_position(self, motor_id: int, value: int) -> None:
        address, length = REG_GOAL_POSITION
        self.write_register(motor_id, address, length, max(0, min(4095, int(value))))

    def write_acceleration(self, motor_id: int, value: int) -> None:
        address, length = REG_ACCELERATION
        self.write_register(motor_id, address, length, max(0, min(254, int(value))))

    def enable_torque(self, motor_id: int) -> None:
        address, length = REG_TORQUE_ENABLE
        self.write_register(motor_id, address, length, 1)

    def disable_torque(self, motor_id: int) -> None:
        address, length = REG_TORQUE_ENABLE
        self.write_register(motor_id, address, length, 0)
        lock_address, lock_length = REG_LOCK
        self.write_register(motor_id, lock_address, lock_length, 0)


@dataclass
class PortResolution:
    port: str
    baudrate: int
    models: dict[int, int]
    checked_ports: list[str]


def _probe_port(port: str, baudrate: int) -> dict[int, int]:
    bus = FeetechBus(port, baudrate=baudrate)
    try:
        bus.connect()
        models: dict[int, int] = {}
        for motor_id in SO101_MOTORS.values():
            try:
                models[motor_id] = bus.read_model_number(motor_id)
            except Exception:
                continue
        return models
    finally:
        bus.close()


def resolve_so101_port(port: str = "") -> PortResolution:
    ports = [port] if port.strip() else candidate_ports()
    checked: list[str] = []
    best: tuple[str, int, dict[int, int]] | None = None
    for candidate in ports:
        for baudrate in SCAN_BAUDRATES:
            checked.append(f"{candidate}@{baudrate}")
            try:
                models = _probe_port(candidate, baudrate)
            except Exception:
                continue
            if models and (best is None or len(models) > len(best[2])):
                best = (candidate, baudrate, models)
            if all(models.get(motor_id) == STS3215_MODEL_NUMBER for motor_id in SO101_MOTORS.values()):
                return PortResolution(candidate, baudrate, models, checked)

    if best is not None:
        found = ", ".join(f"{motor_id}:{model}" for motor_id, model in sorted(best[2].items()))
        raise So101Error(
            "Found a Feetech-like bus but not all SO-101 motors responded "
            f"(best {best[0]}@{best[1]}: {found})."
        )
    checked_text = ", ".join(checked) if checked else "no serial candidates"
    raise So101Error(f"Could not auto-detect an SO-101 serial bus. Checked {checked_text}.")


class RawSo101RobotController:
    def __init__(
        self,
        *,
        port: str = "",
        cameras: list[str] | None = None,
        action_motor: str = "wrist_flex",
        max_delta_raw: int = 260,
        action_steps: int = 10,
        hold_seconds: float = 0.3,
        disable_torque_on_exit: bool = True,
        neutral_raw_position: int | dict[str, int] | None = None,
        neutral_tolerance_raw: int = 16,
        neutral_max_steps: int = 50,
    ) -> None:
        self.requested_port = port
        self.cameras = cameras or ["cam_high"]
        self.action_motor = action_motor
        self.max_delta_raw = int(max_delta_raw)
        self.action_steps = int(action_steps)
        self.hold_seconds = float(hold_seconds)
        self.disable_torque_on_exit = disable_torque_on_exit
        self.neutral_raw_positions = _coerce_raw_so101_position(
            neutral_raw_position,
            label="neutral raw position",
        )
        self.neutral_tolerance_raw = max(0, int(neutral_tolerance_raw))
        self.neutral_max_steps = max(1, int(neutral_max_steps))
        self.resolution: PortResolution | None = None
        self.bus: FeetechBus | None = None
        self.last_raw_positions: dict[str, int] = {}
        self.action_history: list[dict[str, Any]] = []
        self.neutral_reset: dict[str, Any] | None = None

    def __enter__(self) -> "RawSo101RobotController":
        if self.action_motor not in SO101_MOTORS:
            raise So101Error(
                f"Unknown SO-101 motor '{self.action_motor}'. Expected one of {sorted(SO101_MOTORS)}."
            )
        if self.action_steps < 1:
            raise So101Error("--robot-action-steps must be at least 1.")
        if self.max_delta_raw < 1:
            raise So101Error("--robot-max-delta-raw must be at least 1.")

        self.resolution = resolve_so101_port(self.requested_port)
        self.bus = FeetechBus(self.resolution.port, baudrate=self.resolution.baudrate, timeout=0.2)
        self.bus.connect()
        if self.neutral_raw_positions is None:
            self.neutral_raw_positions = self.read_raw_positions()
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        if self.bus is not None:
            if self.disable_torque_on_exit:
                self.disable_all_torque()
            self.bus.close()
            self.bus = None

    def _require_bus(self) -> FeetechBus:
        if self.bus is None:
            raise So101Error("SO-101 controller is not connected")
        return self.bus

    def read_raw_positions(self) -> dict[str, int]:
        bus = self._require_bus()
        positions = {
            name: bus.read_present_position(motor_id)
            for name, motor_id in SO101_MOTORS.items()
        }
        self.last_raw_positions = positions
        return positions

    def read_torque_enable(self) -> dict[str, int]:
        bus = self._require_bus()
        return {name: bus.read_torque_enable(motor_id) for name, motor_id in SO101_MOTORS.items()}

    def disable_all_torque(self) -> None:
        bus = self._require_bus()
        for motor_id in SO101_MOTORS.values():
            try:
                bus.disable_torque(motor_id)
            except Exception:
                continue

    def reset_to_neutral(self) -> dict[str, Any]:
        bus = self._require_bus()
        target = self.neutral_raw_positions
        if target is None:
            target = self.read_raw_positions()
            self.neutral_raw_positions = target
        positions = self.read_raw_positions()
        start_positions = dict(positions)
        samples: list[dict[str, Any]] = []

        for name, motor_id in SO101_MOTORS.items():
            bus.write_goal_position(motor_id, positions[name])
            bus.write_acceleration(motor_id, 80)
            bus.enable_torque(motor_id)
        time.sleep(0.2)

        def settled(values: dict[str, int]) -> bool:
            return all(
                abs(int(values[name]) - target[name]) <= self.neutral_tolerance_raw
                for name in SO101_MOTOR_NAMES
            )

        while not settled(positions) and len(samples) < self.neutral_max_steps:
            goals: dict[str, int] = {}
            for name, motor_id in SO101_MOTORS.items():
                current = int(positions[name])
                delta = target[name] - current
                if abs(delta) <= self.neutral_tolerance_raw:
                    goal = target[name]
                else:
                    step = max(-self.max_delta_raw, min(self.max_delta_raw, delta))
                    goal = max(0, min(4095, current + step))
                goals[name] = goal
                bus.write_goal_position(motor_id, goal)
            time.sleep(self.hold_seconds)
            positions = self.read_raw_positions()
            samples.append({"targetsRaw": goals, "presentRaw": dict(positions)})

        if self.disable_torque_on_exit:
            self.disable_all_torque()
        torque = self.read_torque_enable()
        result = {
            "actionAdapter": "raw_joint_waypoints_to_neutral_pose",
            "backend": "raw_feetech",
            "targetRawPositions": dict(target),
            "startRawPositions": start_positions,
            "finalRawPositions": dict(positions),
            "steps": len(samples),
            "settled": settled(positions),
            "toleranceRaw": self.neutral_tolerance_raw,
            "lastSample": samples[-1] if samples else None,
            "torqueEnable": torque,
        }
        self.neutral_reset = result
        return result

    def capture_observation(self, *, prompt: str) -> dict[str, Any]:
        raw = self.read_raw_positions()
        state6 = [max(-1.0, min(1.0, (raw[name] - 2048) / 2048.0)) for name in SO101_MOTORS]
        zero_frame = {"encoding": "png_base64", "data": zero_png_base64()}
        return {
            "prompt": prompt,
            "state": state6 + [0.0] * 8,
            "images": {camera: zero_frame for camera in self.cameras},
        }

    def _action_rows(self, frame: dict[str, Any]) -> list[list[float]]:
        for key in ("actions_so101", "actions_aloha", "actions", "actions_pi"):
            value = frame.get(key)
            if not isinstance(value, list) or not value:
                continue
            rows: list[list[float]] = []
            for row in value:
                if isinstance(row, list):
                    rows.append([float(item) for item in row if isinstance(item, (int, float))])
                elif isinstance(row, (int, float)):
                    rows.append([float(row)])
            if rows:
                return rows
        return []

    def _sample_rows(self, rows: list[list[float]]) -> list[list[float]]:
        return [row for _, row in _sample_even_action_rows(rows, self.action_steps)]

    def sample_action_rows(self, frame: dict[str, Any]) -> list[tuple[int, list[float]]]:
        return _sample_even_action_rows(self._action_rows(frame), self.action_steps)

    def _choose_action_dimension(self, rows: list[list[float]]) -> dict[str, float | int]:
        width = min(6, max((len(row) for row in rows), default=0))
        if width == 0:
            raise So101Error("inference returned empty action rows")
        best = {"dim": 0, "first": 0.0, "min": 0.0, "max": 0.0, "range": -1.0}
        for dim in range(width):
            values = [row[dim] for row in rows if len(row) > dim]
            if not values:
                continue
            low = min(values)
            high = max(values)
            spread = high - low
            if spread > float(best["range"]):
                best = {
                    "dim": dim,
                    "first": values[0],
                    "min": low,
                    "max": high,
                    "range": spread,
                }
        return best

    def apply_action_chunk(self, frame: dict[str, Any]) -> dict[str, Any]:
        bus = self._require_bus()
        rows = self._action_rows(frame)
        if not rows:
            raise So101Error("inference response did not include an action chunk")
        sampled = self._sample_rows(rows)
        chosen = self._choose_action_dimension(rows[: max(len(sampled), 1) * 3])
        dim = int(chosen["dim"])
        baseline = float(chosen["first"])
        max_abs = max(abs(row[dim] - baseline) for row in sampled if len(row) > dim) or 1.0
        scale = self.max_delta_raw / max_abs

        if not self.last_raw_positions:
            self.read_raw_positions()
        start = int(self.last_raw_positions[self.action_motor])
        motor_id = SO101_MOTORS[self.action_motor]
        targets: list[int] = []
        for row in sampled:
            if len(row) <= dim:
                continue
            delta = int(round((row[dim] - baseline) * scale))
            delta = max(-self.max_delta_raw, min(self.max_delta_raw, delta))
            targets.append(max(0, min(4095, start + delta)))
        targets.append(start)

        bus.write_goal_position(motor_id, start)
        bus.write_acceleration(motor_id, 80)
        bus.enable_torque(motor_id)
        time.sleep(0.2)

        samples: list[dict[str, int]] = []
        for target in targets:
            bus.write_goal_position(motor_id, target)
            time.sleep(self.hold_seconds)
            samples.append({
                "targetRaw": target,
                "presentRaw": bus.read_present_position(motor_id),
            })

        bus.write_goal_position(motor_id, start)
        time.sleep(0.35)
        returned = bus.read_present_position(motor_id)
        if self.disable_torque_on_exit:
            self.disable_all_torque()
        final_positions = self.read_raw_positions()
        torque = self.read_torque_enable()
        result = {
            "actionAdapter": "largest_action_dim_to_single_so101_motor",
            "appliedMotor": self.action_motor,
            "chosenActionDim": chosen,
            "startRaw": start,
            "returnedRaw": returned,
            "targetsRaw": targets,
            "samples": samples,
            "finalRawPositions": final_positions,
            "torqueEnable": torque,
        }
        self.action_history.append(result)
        return result

    def summary(self) -> dict[str, Any]:
        resolution = self.resolution
        return {
            "type": "so101",
            "backend": "raw_feetech",
            "port": resolution.port if resolution else self.requested_port,
            "baudrate": resolution.baudrate if resolution else None,
            "motorIds": dict(SO101_MOTORS),
            "modelNumbers": resolution.models if resolution else {},
            "cameraSource": "zero_png",
            "rawPositions": self.last_raw_positions,
            "actionsApplied": self.action_history,
            "neutralReset": self.neutral_reset,
        }


def _load_lerobot_so101() -> tuple[Any, Any]:
    try:
        from lerobot.robots.so_follower import SOFollower, SOFollowerRobotConfig  # type: ignore[import-not-found]
    except ModuleNotFoundError as exc:
        raise So101Error(
            "SO-101 inference now uses LeRobot's calibrated SO-101 adapter. "
            "Install LeRobot with Feetech support into the local CLI environment. "
            "For example: `uv tool install --force --reinstall --editable ./sdk/python "
            "--with 'lerobot[feetech]'` "
            "or use `--robot-backend raw` for the old debug-only raw register bridge."
        ) from exc
    return SOFollower, SOFollowerRobotConfig


class LeRobotSo101RobotController:
    def __init__(
        self,
        *,
        port: str = "",
        cameras: list[str] | None = None,
        robot_id: str = "",
        max_relative_target: float = 10.0,
        action_steps: int = 10,
        hold_seconds: float = 0.2,
        disable_torque_on_exit: bool = True,
        neutral_position: dict[str, float] | list[float] | tuple[float, ...] | None = None,
        neutral_tolerance: float = 1.0,
        neutral_max_steps: int = 50,
    ) -> None:
        self.requested_port = port
        self.cameras = cameras or ["cam_high"]
        self.robot_id = robot_id or os.environ.get("REFLEX_SO101_ID", "").strip() or "reflex_so101"
        self.max_relative_target = float(max_relative_target)
        self.action_steps = int(action_steps)
        self.hold_seconds = float(hold_seconds)
        self.disable_torque_on_exit = disable_torque_on_exit
        self.neutral_position = _coerce_so101_position(neutral_position, label="neutral position")
        self.neutral_tolerance = max(0.0, float(neutral_tolerance))
        self.neutral_max_steps = max(1, int(neutral_max_steps))
        self.resolution: PortResolution | None = None
        self.robot: Any | None = None
        self.last_positions: dict[str, float] = {}
        self.action_history: list[dict[str, Any]] = []
        self.neutral_reset: dict[str, Any] | None = None

    def __enter__(self) -> "LeRobotSo101RobotController":
        _install_lerobot_clamp_warning_filter()
        if self.action_steps < 1:
            raise So101Error("--robot-action-steps must be at least 1.")
        if self.max_relative_target <= 0:
            raise So101Error("--robot-max-relative-target must be greater than 0.")

        robot_cls, config_cls = _load_lerobot_so101()
        self.resolution = resolve_so101_port(self.requested_port)
        config_kwargs: dict[str, Any] = {
            "port": self.resolution.port,
            "id": self.robot_id,
            "cameras": {},
            "disable_torque_on_disconnect": self.disable_torque_on_exit,
            "max_relative_target": self.max_relative_target,
            "use_degrees": True,
        }
        while True:
            try:
                config = config_cls(**config_kwargs)
                break
            except TypeError as exc:
                message = str(exc)
                removed = False
                for key in ("use_degrees", "cameras", "disable_torque_on_disconnect"):
                    if key in config_kwargs and key in message:
                        config_kwargs.pop(key)
                        removed = True
                        break
                if not removed:
                    raise So101Error(f"Failed to construct LeRobot SO-101 config: {exc}") from exc

        self.robot = robot_cls(config)
        self.robot.connect(calibrate=True)
        if self.neutral_position is None:
            self.neutral_position = self.read_positions()
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        if self.robot is not None:
            self.robot.disconnect()
            self.robot = None

    def _require_robot(self) -> Any:
        if self.robot is None:
            raise So101Error("SO-101 controller is not connected")
        return self.robot

    def read_positions(self) -> dict[str, float]:
        robot = self._require_robot()
        observation = robot.get_observation()
        positions: dict[str, float] = {}
        for name in SO101_MOTOR_NAMES:
            key = f"{name}.pos"
            value = observation.get(key)
            if not isinstance(value, (int, float)):
                raise So101Error(f"LeRobot observation missing numeric {key}")
            positions[name] = float(value)
        self.last_positions = positions
        return positions

    def capture_observation(self, *, prompt: str) -> dict[str, Any]:
        positions = self.read_positions()
        zero_frame = {"encoding": "png_base64", "data": zero_png_base64()}
        return {
            "prompt": prompt,
            "robot": "so101",
            "state_adapter": "so101_joint",
            "state_units": "degrees_and_percent",
            "joint_names": list(SO101_MOTOR_NAMES),
            "state": [positions[name] for name in SO101_MOTOR_NAMES],
            "images": {camera: zero_frame for camera in self.cameras},
        }

    def _action_rows(self, frame: dict[str, Any]) -> list[list[float]]:
        value = frame.get("actions_so101")
        if not isinstance(value, list) or not value:
            raise So101Error("inference response did not include actions_so101")
        rows: list[list[float]] = []
        for row in value:
            if not isinstance(row, list):
                continue
            numeric = [float(item) for item in row[: len(SO101_MOTOR_NAMES)] if isinstance(item, (int, float))]
            if len(numeric) == len(SO101_MOTOR_NAMES):
                rows.append(numeric)
        if not rows:
            raise So101Error("inference response included actions_so101 but no complete SO-101 rows")
        return rows

    def _sample_rows(self, rows: list[list[float]]) -> list[list[float]]:
        return [row for _, row in _sample_even_action_rows(rows, self.action_steps)]

    def sample_action_rows(self, frame: dict[str, Any]) -> list[tuple[int, list[float]]]:
        return _sample_even_action_rows(self._action_rows(frame), self.action_steps)

    def apply_action_row(self, *, source_index: int, row: list[float], record: bool = True) -> dict[str, Any]:
        robot = self._require_robot()
        action = {f"{name}.pos": row[position] for position, name in enumerate(SO101_MOTOR_NAMES)}
        _install_lerobot_clamp_warning_filter()
        sent = robot.send_action(action)
        time.sleep(self.hold_seconds)
        present = self.read_positions()
        result = {
            "actionAdapter": "so101_joint",
            "backend": "lerobot",
            "sourceIndex": source_index,
            "target": {name: row[position] for position, name in enumerate(SO101_MOTOR_NAMES)},
            "sent": sent,
            "present": present,
        }
        if record:
            self.action_history.append(result)
        return result

    def apply_action_chunk(self, frame: dict[str, Any]) -> dict[str, Any]:
        rows = self.sample_action_rows(frame)
        samples: list[dict[str, Any]] = []
        for index, (source_index, row) in enumerate(rows):
            applied = self.apply_action_row(source_index=source_index, row=row, record=False)
            samples.append({
                "index": index,
                "sourceIndex": source_index,
                "target": applied["target"],
                "sent": applied["sent"],
                "present": applied["present"],
            })
        final_positions = self.read_positions()
        result = {
            "actionAdapter": "so101_joint",
            "backend": "lerobot",
            "jointNames": list(SO101_MOTOR_NAMES),
            "units": "degrees_and_percent",
            "targetsApplied": len(rows),
            "samples": samples,
            "finalPositions": final_positions,
        }
        self.action_history.append(result)
        return result

    def reset_to_neutral(self) -> dict[str, Any]:
        robot = self._require_robot()
        if self.neutral_position is None:
            self.neutral_position = self.read_positions()
        target = dict(self.neutral_position)
        positions = self.read_positions()
        start_positions = dict(positions)
        samples: list[dict[str, Any]] = []

        def settled(values: dict[str, float]) -> bool:
            return all(
                abs(float(values[name]) - target[name]) <= self.neutral_tolerance
                for name in SO101_MOTOR_NAMES
            )

        def next_waypoint(values: dict[str, float]) -> dict[str, float]:
            waypoint: dict[str, float] = {}
            for name in SO101_MOTOR_NAMES:
                current = float(values[name])
                delta = target[name] - current
                if abs(delta) <= self.neutral_tolerance:
                    waypoint[name] = target[name]
                    continue
                step = max(-self.max_relative_target, min(self.max_relative_target, delta))
                waypoint[name] = current + step
            return waypoint

        while not settled(positions) and len(samples) < self.neutral_max_steps:
            waypoint = next_waypoint(positions)
            action = {f"{name}.pos": waypoint[name] for name in SO101_MOTOR_NAMES}
            _install_lerobot_clamp_warning_filter()
            sent = robot.send_action(action)
            time.sleep(self.hold_seconds)
            positions = self.read_positions()
            sent_targets = {
                key.removesuffix(".pos"): value
                for key, value in sent.items()
                if isinstance(key, str) and isinstance(value, (int, float))
            }
            samples.append({
                "waypoint": waypoint,
                "sent": sent_targets,
                "present": dict(positions),
            })

        result = {
            "actionAdapter": "so101_joint",
            "backend": "lerobot",
            "target": target,
            "startPositions": start_positions,
            "finalPositions": dict(positions),
            "steps": len(samples),
            "settled": settled(positions),
            "tolerance": self.neutral_tolerance,
            "lastSample": samples[-1] if samples else None,
        }
        self.neutral_reset = result
        return result

    def summary(self) -> dict[str, Any]:
        resolution = self.resolution
        return {
            "type": "so101",
            "backend": "lerobot",
            "id": self.robot_id,
            "port": resolution.port if resolution else self.requested_port,
            "baudrate": resolution.baudrate if resolution else None,
            "jointNames": list(SO101_MOTOR_NAMES),
            "cameraSource": "zero_png",
            "positions": self.last_positions,
            "actionsApplied": self.action_history,
            "neutralReset": self.neutral_reset,
        }


class So101RobotController:
    def __init__(
        self,
        *,
        port: str = "",
        cameras: list[str] | None = None,
        action_motor: str = "wrist_flex",
        max_delta_raw: int = 260,
        max_relative_target: float = 10.0,
        action_steps: int = 10,
        hold_seconds: float = 0.2,
        robot_id: str = "",
        backend: str = "lerobot",
        disable_torque_on_exit: bool = True,
    ) -> None:
        self.backend = (backend or "lerobot").strip().lower().replace("-", "_")
        self.kwargs = {
            "port": port,
            "cameras": cameras,
            "action_motor": action_motor,
            "max_delta_raw": max_delta_raw,
            "max_relative_target": max_relative_target,
            "action_steps": action_steps,
            "hold_seconds": hold_seconds,
            "robot_id": robot_id,
            "disable_torque_on_exit": disable_torque_on_exit,
        }
        self._controller: LeRobotSo101RobotController | RawSo101RobotController | None = None

    def __enter__(self) -> "So101RobotController":
        if self.backend == "raw":
            self._controller = RawSo101RobotController(
                port=str(self.kwargs["port"] or ""),
                cameras=self.kwargs["cameras"],
                action_motor=str(self.kwargs["action_motor"]),
                max_delta_raw=int(self.kwargs["max_delta_raw"]),
                action_steps=int(self.kwargs["action_steps"]),
                hold_seconds=float(self.kwargs["hold_seconds"]),
                disable_torque_on_exit=bool(self.kwargs["disable_torque_on_exit"]),
            )
        elif self.backend == "lerobot":
            self._controller = LeRobotSo101RobotController(
                port=str(self.kwargs["port"] or ""),
                cameras=self.kwargs["cameras"],
                robot_id=str(self.kwargs["robot_id"] or ""),
                max_relative_target=float(self.kwargs["max_relative_target"]),
                action_steps=int(self.kwargs["action_steps"]),
                hold_seconds=float(self.kwargs["hold_seconds"]),
                disable_torque_on_exit=bool(self.kwargs["disable_torque_on_exit"]),
            )
        else:
            raise So101Error("--robot-backend must be lerobot or raw.")
        self._controller.__enter__()
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        if self._controller is not None:
            self._controller.__exit__(exc_type, exc, tb)
            self._controller = None

    def _require_controller(self) -> LeRobotSo101RobotController | RawSo101RobotController:
        if self._controller is None:
            raise So101Error("SO-101 controller is not connected")
        return self._controller

    def capture_observation(self, *, prompt: str) -> dict[str, Any]:
        return self._require_controller().capture_observation(prompt=prompt)

    def apply_action_chunk(self, frame: dict[str, Any]) -> dict[str, Any]:
        return self._require_controller().apply_action_chunk(frame)

    def sample_action_rows(self, frame: dict[str, Any]) -> list[tuple[int, list[float]]]:
        controller = self._require_controller()
        sampler = getattr(controller, "sample_action_rows", None)
        if not callable(sampler):
            raise So101Error("SO-101 backend does not support per-row action sampling")
        return sampler(frame)

    def apply_action_row(self, *, source_index: int, row: list[float]) -> dict[str, Any]:
        controller = self._require_controller()
        applier = getattr(controller, "apply_action_row", None)
        if not callable(applier):
            raise So101Error("SO-101 backend does not support per-row action application")
        return applier(source_index=source_index, row=row)

    def reset_to_neutral(self) -> dict[str, Any]:
        controller = self._require_controller()
        resetter = getattr(controller, "reset_to_neutral", None)
        if not callable(resetter):
            raise So101Error("SO-101 backend does not support neutral reset")
        return resetter()

    def summary(self) -> dict[str, Any]:
        return self._require_controller().summary()