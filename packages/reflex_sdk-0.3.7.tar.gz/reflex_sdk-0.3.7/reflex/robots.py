"""Hosted Reflex robot registry helpers."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .product import ProductClient, ProductError, expect_object, resolve_api_key


def _expect_ok(value: Any, *, action: str) -> dict[str, Any]:
    result = expect_object(value, label=f"{action} response")
    if result.get("ok") is True:
        return result
    reason = result.get("reason")
    message = result.get("message")
    detail = reason if isinstance(reason, str) and reason else message
    if not isinstance(detail, str) or not detail:
        detail = "unknown"
    raise ProductError(f"{action}: {detail}.")


def _load_schema_payload(schema: str | Path | dict[str, Any]) -> dict[str, Any]:
    if isinstance(schema, dict):
        return schema
    schema_path = Path(schema)
    try:
        text = schema_path.read_text(encoding="utf-8")
        if schema_path.suffix.lower() in {".yaml", ".yml"}:
            import yaml

            parsed = yaml.safe_load(text)
        else:
            parsed = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ProductError("Robot schema must be valid JSON.") from exc
    except ImportError as exc:
        raise ProductError("YAML robot schemas require PyYAML to be installed.") from exc
    except OSError as exc:
        raise ProductError(f"Failed to read robot schema: {exc}") from exc
    if not isinstance(parsed, dict):
        raise ProductError("Robot schema must be a JSON object.")
    return parsed


def register_robot_schema(
    *,
    convex_url: str | None = None,
    api_key: str | None = None,
    name: str,
    schema: str | Path | dict[str, Any],
    robot_kind: str | None = None,
) -> dict[str, Any]:
    payload = _load_schema_payload(schema)
    action = payload.get("actions", {}).get("action", {}) if isinstance(payload.get("actions"), dict) else {}
    safe_stop = action.get("safe_stop") if isinstance(action, dict) else None
    shape = action.get("shape") if isinstance(action, dict) else None
    args: dict[str, Any] = {
        "apiKey": resolve_api_key(api_key),
        "name": name,
        "schemaVersion": str(payload.get("schema_version") or payload.get("schemaVersion") or "robot_schema.v1"),
        "schemaJson": json.dumps(payload, sort_keys=True),
        "hasExplicitSafeStop": isinstance(safe_stop, list) and len(safe_stop) > 0,
    }
    if isinstance(robot_kind, str) and robot_kind:
        args["robotKind"] = robot_kind
    elif isinstance(payload.get("robot_kind"), str):
        args["robotKind"] = payload["robot_kind"]
    if isinstance(shape, list) and shape and isinstance(shape[0], (int, float)):
        args["actionDim"] = int(shape[0])
    if isinstance(action, dict) and isinstance(action.get("safe_stop_mode"), str):
        args["safeStopMode"] = action["safe_stop_mode"]
    return _expect_ok(
        ProductClient(convex_url).mutation("publicApi:registerRobotSchema", args),
        action="Unable to register robot schema",
    )


def list_robot_schemas(
    *,
    convex_url: str | None = None,
    api_key: str | None = None,
) -> dict[str, Any]:
    return _expect_ok(
        ProductClient(convex_url).mutation(
            "publicApi:listRobotSchemas",
            {"apiKey": resolve_api_key(api_key)},
        ),
        action="Unable to list robot schemas",
    )


def register_robot(
    *,
    convex_url: str | None = None,
    api_key: str | None = None,
    name: str,
    robot_schema_id: str,
    robot_kind: str | None = None,
    calibration_id: str | None = None,
) -> dict[str, Any]:
    args: dict[str, Any] = {
        "apiKey": resolve_api_key(api_key),
        "name": name,
        "robotSchemaId": robot_schema_id,
    }
    if robot_kind:
        args["robotKind"] = robot_kind
    if calibration_id:
        args["calibrationId"] = calibration_id
    return _expect_ok(
        ProductClient(convex_url).mutation("publicApi:registerRobot", args),
        action="Unable to register robot",
    )


def list_robots(
    *,
    convex_url: str | None = None,
    api_key: str | None = None,
) -> dict[str, Any]:
    return _expect_ok(
        ProductClient(convex_url).mutation(
            "publicApi:listRobots",
            {"apiKey": resolve_api_key(api_key)},
        ),
        action="Unable to list robots",
    )


def create_pairing_token(
    robot_id: str,
    *,
    convex_url: str | None = None,
    api_key: str | None = None,
    ttl_seconds: int | None = None,
) -> dict[str, Any]:
    args: dict[str, Any] = {
        "apiKey": resolve_api_key(api_key),
        "robotId": robot_id,
    }
    if ttl_seconds is not None:
        args["ttlSeconds"] = ttl_seconds
    return _expect_ok(
        ProductClient(convex_url).mutation("publicApi:createRobotPairingToken", args),
        action="Unable to create robot pairing token",
    )


def claim_pairing_token(
    token: str,
    *,
    convex_url: str | None = None,
    api_key: str | None = None,
) -> dict[str, Any]:
    return _expect_ok(
        ProductClient(convex_url).mutation(
            "publicApi:claimRobotPairingToken",
            {"apiKey": resolve_api_key(api_key), "token": token},
        ),
        action="Unable to claim robot pairing token",
    )


def heartbeat_robot(
    robot_id: str,
    *,
    convex_url: str | None = None,
    api_key: str | None = None,
    session_id: str | None = None,
    deployment_id: str | None = None,
    connector_version: str | None = None,
    transport: str | None = None,
    message: str | None = None,
) -> dict[str, Any]:
    args: dict[str, Any] = {
        "apiKey": resolve_api_key(api_key),
        "robotId": robot_id,
    }
    if session_id:
        args["sessionId"] = session_id
    if deployment_id:
        args["deploymentId"] = deployment_id
    if connector_version:
        args["connectorVersion"] = connector_version
    if transport:
        args["transport"] = transport
    if message:
        args["message"] = message
    return _expect_ok(
        ProductClient(convex_url).mutation("publicApi:robotHeartbeat", args),
        action="Unable to send robot heartbeat",
    )
