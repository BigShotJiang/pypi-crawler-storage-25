"""Public Reflex SDK."""

from ._version import __version__
from .actions import ActionStream, action, connect, infer_actions, observation
from .client import Client
# TODO PROD.2: re-add ConnectError/ConnectRunner/SessionGrant once auth wrapper is integrated
from .datasets import (
    complete_dataset,
    create_dataset,
    get_dataset,
    list_datasets,
    register_huggingface_dataset,
    upload_dataset,
    validate_dataset,
)
from .deployments import (
    create_deployment,
    create_deployment_from_spec,
    get_deployment,
    list_deployments,
    run_deployment_doctor,
)
from .instances import instance_status, provision_instance, teardown_instance
from .receipts import list_receipts
from .robots import (
    claim_pairing_token,
    create_pairing_token,
    heartbeat_robot,
    list_robot_schemas,
    list_robots,
    register_robot,
    register_robot_schema,
)
from .robot_runtime import RobotExecutionConfig, RobotExecutionResult, run_robot_execution_loop
from .sessions import close_session, list_sessions, promote_session, start_session
from .training import (
    AdamParams,
    AdapterHandle,
    Datum,
    ForwardBackwardResult,
    LoraTrainingClient,
    OptimStepResult,
    ServiceClient,
    cancel_training_job,
    create_training_job,
    full_finetune,
    full_train,
    get_training_job,
    list_training_jobs,
    lora_finetune,
)

__all__ = [
    "ActionStream",
    "AdamParams",
    "AdapterHandle",
    "Client",
    "claim_pairing_token",
    "Datum",
    "ForwardBackwardResult",
    "LoraTrainingClient",
    "OptimStepResult",
    "RobotExecutionConfig",
    "RobotExecutionResult",
    "ServiceClient",
    "SessionGrant",
    "__version__",
    "action",
    "bind_key_to_model",
    "cancel_training_job",
    "close_session",
    "complete_dataset",
    "connect",
    "create_dataset",
    "create_deployment",
    "create_deployment_from_spec",
    "create_pairing_token",
    "create_training_job",
    "delete_model",
    "full_finetune",
    "full_train",
    "get_dataset",
    "get_deployment",
    "get_training_job",
    "heartbeat_robot",
    "infer_actions",
    "instance_status",
    "list_sessions",
    "list_training_jobs",
    "list_datasets",
    "list_deployments",
    "list_receipts",
    "list_robot_schemas",
    "list_robots",
    "lora_finetune",
    "observation",
    "provision_instance",
    "promote_session",
    "register_huggingface_dataset",
    "register_robot",
    "register_robot_schema",
    "run_deployment_doctor",
    "run_robot_execution_loop",
    "start_session",
    "teardown_instance",
    "upload_dataset",
    "validate_dataset",
]
