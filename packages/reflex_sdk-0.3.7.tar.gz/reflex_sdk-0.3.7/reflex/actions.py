"""Small dependency-free client for the metered Reflex actions WebSocket."""

from __future__ import annotations

import base64
import hashlib
import json
import os
import socket
import ssl
import struct
import time
from types import TracebackType
from typing import Any
from urllib import parse

from ._version import user_agent as _user_agent
from ._transport import api_key as _api_key
from ._transport import base_url as _base_url

RETRYABLE_HANDSHAKE_STATUS_CODES = {403, 404, 408, 425, 429, 500, 502, 503, 504}
DEFAULT_CONNECT_RETRY_SECONDS = 90.0


class WebSocketHandshakeError(RuntimeError):
    def __init__(self, status_line: str) -> None:
        super().__init__(f"WebSocket handshake failed: {status_line}")
        self.status_line = status_line
        self.status_code = _status_code(status_line)


def _actions_ws_url(url: str | None) -> str:
    resolved = (url or os.environ.get("REFLEX_ACTIONS_URL", "")).strip()
    if not resolved:
        resolved = _base_url(None)

    parsed = parse.urlparse(resolved)
    if parsed.scheme in {"ws", "wss"}:
        if parsed.query:
            return resolved
        if parsed.path and parsed.path != "/":
            return resolved
        return f"{resolved.rstrip('/')}/v1/actions"
    if parsed.scheme in {"http", "https"}:
        scheme = "wss" if parsed.scheme == "https" else "ws"
        replaced = parsed._replace(scheme=scheme, path="/v1/actions", params="", query="", fragment="")
        return parse.urlunparse(replaced)
    raise ValueError("Actions URL must start with http://, https://, ws://, or wss://.")


def _status_code(status_line: str) -> int | None:
    pieces = status_line.split()
    if len(pieces) < 2:
        return None
    try:
        return int(pieces[1])
    except ValueError:
        return None


def _connect_retry_seconds(timeout: float) -> float:
    raw = os.environ.get("REFLEX_WS_CONNECT_RETRY_SECONDS", "").strip()
    if raw:
        try:
            configured = float(raw)
        except ValueError:
            configured = DEFAULT_CONNECT_RETRY_SECONDS
    else:
        configured = DEFAULT_CONNECT_RETRY_SECONDS
    return max(0.0, min(max(0.0, timeout), configured))


def _retryable_connect_error(exc: BaseException) -> bool:
    if isinstance(exc, WebSocketHandshakeError):
        return exc.status_code in RETRYABLE_HANDSHAKE_STATUS_CODES
    return isinstance(exc, (TimeoutError, socket.timeout, OSError))


def _connect_websocket(
    url: str,
    *,
    api_key: str,
    timeout: float,
    timing: dict[str, float] | None = None,
) -> socket.socket:
    connect_started = time.monotonic()
    parsed = parse.urlparse(url)
    if parsed.scheme not in {"ws", "wss"} or not parsed.hostname:
        raise ValueError("Actions URL must be a ws:// or wss:// URL.")

    port = parsed.port or (443 if parsed.scheme == "wss" else 80)
    path = parsed.path or "/"
    if parsed.query:
        path = f"{path}?{parsed.query}"

    tcp_started = time.monotonic()
    raw_sock = socket.create_connection((parsed.hostname, port), timeout=timeout)
    if timing is not None:
        timing["tcp_ms"] = (time.monotonic() - tcp_started) * 1000.0
    sock: socket.socket
    if parsed.scheme == "wss":
        tls_started = time.monotonic()
        context = ssl.create_default_context()
        sock = context.wrap_socket(raw_sock, server_hostname=parsed.hostname)
        if timing is not None:
            timing["tls_ms"] = (time.monotonic() - tls_started) * 1000.0
    else:
        sock = raw_sock
        if timing is not None:
            timing["tls_ms"] = 0.0
    sock.settimeout(timeout)

    upgrade_started = time.monotonic()
    key = base64.b64encode(os.urandom(16)).decode("ascii")
    host = parsed.hostname if parsed.port is None else f"{parsed.hostname}:{port}"
    auth_header = f"Authorization: Bearer {api_key}\r\n" if api_key else ""
    request_text = (
        f"GET {path} HTTP/1.1\r\n"
        f"Host: {host}\r\n"
        "Upgrade: websocket\r\n"
        "Connection: Upgrade\r\n"
        f"Sec-WebSocket-Key: {key}\r\n"
        "Sec-WebSocket-Version: 13\r\n"
        f"{auth_header}"
        f"User-Agent: {_user_agent('reflex-actions-sdk')}\r\n"
        "\r\n"
    )
    sock.sendall(request_text.encode("ascii"))
    response = b""
    while b"\r\n\r\n" not in response:
        chunk = sock.recv(4096)
        if not chunk:
            break
        response += chunk

    header_text = response.decode("iso-8859-1", errors="replace")
    status_line = header_text.split("\r\n", 1)[0]
    if " 101 " not in status_line:
        sock.close()
        raise WebSocketHandshakeError(status_line)

    accept_source = (key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode("ascii")
    expected_accept = base64.b64encode(hashlib.sha1(accept_source).digest()).decode("ascii")
    headers: dict[str, str] = {}
    for line in header_text.split("\r\n")[1:]:
        if ":" in line:
            name, value = line.split(":", 1)
            headers[name.strip().lower()] = value.strip()
    if headers.get("sec-websocket-accept") != expected_accept:
        sock.close()
        raise RuntimeError("WebSocket handshake failed: invalid Sec-WebSocket-Accept header.")
    if timing is not None:
        timing["websocket_upgrade_ms"] = (time.monotonic() - upgrade_started) * 1000.0
        timing["connect_ms"] = (time.monotonic() - connect_started) * 1000.0
    return sock


def _recv_exact(sock: socket.socket, size: int) -> bytes:
    chunks: list[bytes] = []
    remaining = size
    while remaining > 0:
        chunk = sock.recv(remaining)
        if not chunk:
            raise RuntimeError("WebSocket closed unexpectedly.")
        chunks.append(chunk)
        remaining -= len(chunk)
    return b"".join(chunks)


def _send_text_frame(sock: socket.socket, text: str) -> None:
    payload = text.encode("utf-8")
    mask_key = os.urandom(4)
    header = bytearray([0x81])
    length = len(payload)
    if length < 126:
        header.append(0x80 | length)
    elif length < 65536:
        header.extend([0x80 | 126, *struct.pack("!H", length)])
    else:
        header.extend([0x80 | 127, *struct.pack("!Q", length)])
    masked = bytes(byte ^ mask_key[index % 4] for index, byte in enumerate(payload))
    sock.sendall(bytes(header) + mask_key + masked)


def _send_pong(sock: socket.socket, payload: bytes) -> None:
    mask_key = os.urandom(4)
    header = bytes([0x8A, 0x80 | len(payload)])
    masked = bytes(byte ^ mask_key[index % 4] for index, byte in enumerate(payload))
    sock.sendall(header + mask_key + masked)


def _recv_text_frame(sock: socket.socket) -> str:
    while True:
        first, second = _recv_exact(sock, 2)
        opcode = first & 0x0F
        masked = bool(second & 0x80)
        length = second & 0x7F
        if length == 126:
            length = struct.unpack("!H", _recv_exact(sock, 2))[0]
        elif length == 127:
            length = struct.unpack("!Q", _recv_exact(sock, 8))[0]

        mask_key = _recv_exact(sock, 4) if masked else b""
        payload = _recv_exact(sock, length) if length else b""
        if masked:
            payload = bytes(byte ^ mask_key[index % 4] for index, byte in enumerate(payload))

        if opcode == 0x1:
            return payload.decode("utf-8")
        if opcode == 0x8:
            raise RuntimeError("WebSocket closed by server.")
        if opcode == 0x9:
            _send_pong(sock, payload)


def _close_websocket(sock: socket.socket) -> None:
    try:
        sock.sendall(bytes([0x88, 0x80]) + os.urandom(4))
    finally:
        sock.close()


def _json_frame(payload: dict[str, Any]) -> str:
    return json.dumps(payload, separators=(",", ":"))


def _normalize_images(images: dict[str, Any] | None) -> dict[str, Any]:
    normalized: dict[str, Any] = {}
    for name, value in (images or {}).items():
        if isinstance(value, bytes):
            normalized[name] = {
                "encoding": "jpeg_base64",
                "data": base64.b64encode(value).decode("ascii"),
            }
        else:
            normalized[name] = value
    return normalized


def _query_has_token(url: str) -> bool:
    parsed = parse.urlparse(url)
    return bool(parse.parse_qs(parsed.query).get("token"))


class ActionStream:
    """Long-lived Reflex actions session.

    The public protocol is:
    1. open a WebSocket with an API key
    2. send `observation` frames with embodiment state and camera images
    3. receive metered `action_chunk` frames
    """

    def __init__(
        self,
        *,
        url: str | None = None,
        api_key: str | None = None,
        prompt: str,
        model: str | None = None,
        lora: str | None = None,
        robot: str | None = None,
        action_adapter: str | None = None,
        cameras: list[str] | None = None,
        hz: float | None = None,
        chunk_size: int | None = None,
        max_gpu_seconds: float | None = None,
        session_id: str = "",
        timeout: float = 30.0,
        connect_retry_seconds: float | None = None,
    ) -> None:
        self.url = _actions_ws_url(url)
        self.api_key = (
            ""
            if _query_has_token(self.url) and not (api_key or "").strip()
            else _api_key(api_key)
        )
        self.prompt = prompt
        self.model = model
        self.lora = lora
        self.robot = robot
        self.action_adapter = action_adapter
        self.cameras = cameras or []
        self.hz = hz
        self.chunk_size = chunk_size
        self.max_gpu_seconds = max_gpu_seconds
        self.session_id = session_id
        self.timeout = timeout
        self.connect_retry_seconds = connect_retry_seconds
        self.ready: dict[str, Any] | None = None
        self.open_timing: dict[str, float] = {}
        self._sock: socket.socket | None = None
        self._next_seq = 0

    def __enter__(self) -> ActionStream:
        return self.open()

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.close()

    def open(self) -> ActionStream:
        retry_seconds = (
            _connect_retry_seconds(self.timeout)
            if self.connect_retry_seconds is None
            else max(0.0, min(max(0.0, self.timeout), self.connect_retry_seconds))
        )
        deadline = time.monotonic() + retry_seconds
        delay = 0.5
        while True:
            open_started = time.monotonic()
            timing: dict[str, float] = {}
            try:
                self._sock = _connect_websocket(
                    self.url,
                    api_key=self.api_key,
                    timeout=min(self.timeout, 15.0),
                    timing=timing,
                )
                ready_started = time.monotonic()
                self.send_raw({
                    "type": "session.open",
                    "session_id": self.session_id,
                    "prompt": self.prompt,
                    "model": self.model,
                    "lora": self.lora,
                    "robot": self.robot,
                    "action_adapter": self.action_adapter,
                    "cameras": self.cameras,
                    "hz": self.hz,
                    "chunk_size": self.chunk_size,
                    "max_gpu_seconds": self.max_gpu_seconds,
                })
                ready = self.receive()
                if ready.get("type") != "session.ready":
                    raise RuntimeError(f"Expected session.ready, received {ready!r}")
                timing["session_ready_ms"] = (time.monotonic() - ready_started) * 1000.0
                timing["open_ms"] = (time.monotonic() - open_started) * 1000.0
                self.open_timing = timing
                self.ready = ready
                self.session_id = str(ready.get("session_id") or self.session_id)
                return self
            except Exception as exc:
                if self._sock is not None:
                    try:
                        _close_websocket(self._sock)
                    except Exception:
                        try:
                            self._sock.close()
                        except Exception:
                            pass
                    self._sock = None
                now = time.monotonic()
                if retry_seconds <= 0 or not _retryable_connect_error(exc) or now >= deadline:
                    raise
                time.sleep(min(delay, max(0.0, deadline - now)))
                delay = min(delay * 1.6, 5.0)

    def send_raw(self, frame: dict[str, Any]) -> None:
        if self._sock is None:
            raise RuntimeError("ActionStream is not open.")
        _send_text_frame(
            self._sock,
            _json_frame({key: value for key, value in frame.items() if value is not None}),
        )

    def receive(self) -> dict[str, Any]:
        if self._sock is None:
            raise RuntimeError("ActionStream is not open.")
        frame = json.loads(_recv_text_frame(self._sock))
        return frame if isinstance(frame, dict) else {"type": "error", "detail": frame}

    def send_observation(
        self,
        *,
        state: list[float],
        images: dict[str, Any] | None = None,
        prompt: str | None = None,
        seq: int | None = None,
        request_id: str | None = None,
        capture_time_ns: int | None = None,
        max_gpu_seconds: float | None = None,
    ) -> int:
        resolved_seq = self._next_seq if seq is None else seq
        self._next_seq = max(self._next_seq, resolved_seq + 1)
        self.send_raw({
            "type": "observation",
            "seq": resolved_seq,
            "state": state,
            "images": _normalize_images(images),
            "prompt": prompt,
            "request_id": request_id,
            "capture_time_ns": capture_time_ns,
            "max_gpu_seconds": max_gpu_seconds,
        })
        return resolved_seq

    def send_observation_frame(self, frame: dict[str, Any]) -> int:
        payload = dict(frame)
        payload["type"] = "observation"
        if "seq" not in payload:
            payload["seq"] = self._next_seq
        seq = int(payload["seq"])
        self._next_seq = max(self._next_seq, seq + 1)
        if "images" in payload and isinstance(payload["images"], dict):
            payload["images"] = _normalize_images(payload["images"])
        self.send_raw(payload)
        return seq

    def recv_action(self) -> dict[str, Any]:
        while True:
            frame = self.receive()
            if frame.get("type") == "action_chunk":
                return frame
            if frame.get("type") == "error":
                raise RuntimeError(json.dumps(frame, sort_keys=True))

    def close(self) -> None:
        if self._sock is None:
            return
        sock = self._sock
        self._sock = None
        try:
            _send_text_frame(sock, _json_frame({"type": "session.close", "session_id": self.session_id}))
        except Exception:
            pass
        _close_websocket(sock)


def connect(**kwargs: Any) -> Any:
    """Create a metered Reflex action stream or decorate a controller class."""
    return _ConnectHandle(kwargs)


def observation(func: Any) -> Any:
    """Mark a controller method as the observation producer."""
    setattr(func, "__reflex_observation__", True)
    return func


def action(func: Any) -> Any:
    """Mark a controller method as the action consumer."""
    setattr(func, "__reflex_action__", True)
    return func


class _ConnectHandle:
    def __init__(self, kwargs: dict[str, Any]) -> None:
        self.kwargs = dict(kwargs)
        self._stream: ActionStream | None = None

    def __call__(self, cls: type[Any]) -> type[Any]:
        observation_name = _marked_method_name(cls, "__reflex_observation__")
        action_name = _marked_method_name(cls, "__reflex_action__")
        if observation_name is None:
            raise TypeError("@reflex.connect classes must define a @reflex.observation method.")
        if action_name is None:
            raise TypeError("@reflex.connect classes must define a @reflex.action method.")

        existing_run = getattr(cls, "run", None)
        if existing_run is not None and not getattr(existing_run, "__reflex_generated_run__", False):
            return cls

        def run(instance: Any, *, max_steps: int | None = None) -> None:
            step = 0
            with ActionStream(**_controller_stream_kwargs(self.kwargs)) as stream:
                while max_steps is None or step < max_steps:
                    enabled = getattr(instance, "enabled", None)
                    if callable(enabled) and not enabled():
                        break
                    observation_payload = getattr(instance, observation_name)()
                    if observation_payload is None:
                        break
                    if not isinstance(observation_payload, dict):
                        raise TypeError("@reflex.observation must return a dict observation payload.")
                    stream.send_observation_frame(observation_payload)
                    frame = stream.recv_action()
                    getattr(instance, action_name)(frame.get("actions", frame))
                    step += 1

        setattr(run, "__reflex_generated_run__", True)
        setattr(cls, "run", run)
        return cls

    def open(self) -> ActionStream:
        if self._stream is None:
            self._stream = ActionStream(**_controller_stream_kwargs(self.kwargs)).open()
        return self._stream

    def __enter__(self) -> ActionStream:
        return self.open()

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        if self._stream is not None:
            self._stream.close()
            self._stream = None

    def __getattr__(self, name: str) -> Any:
        return getattr(self.open(), name)


def _marked_method_name(cls: type[Any], marker: str) -> str | None:
    for name in dir(cls):
        value = getattr(cls, name)
        if getattr(value, marker, False):
            return name
    return None


def _controller_stream_kwargs(kwargs: dict[str, Any]) -> dict[str, Any]:
    resolved = dict(kwargs)
    resolved.setdefault("prompt", "do something")
    return resolved


def infer_actions(
    *,
    url: str | None = None,
    api_key: str | None = None,
    observation: dict[str, Any],
    timeout: float = 30.0,
) -> dict[str, Any]:
    """One-shot helper for a single observation -> action chunk request."""
    session_fields = {
        "prompt": observation.get("prompt", "do something"),
        "model": observation.get("model"),
        "lora": observation.get("lora"),
        "cameras": observation.get("cameras"),
        "hz": observation.get("hz"),
        "chunk_size": observation.get("chunk_size"),
        "max_gpu_seconds": observation.get("max_gpu_seconds"),
        "session_id": observation.get("session_id", ""),
    }
    with ActionStream(url=url, api_key=api_key, timeout=timeout, **session_fields) as stream:
        stream.send_observation_frame(observation)
        return stream.recv_action()