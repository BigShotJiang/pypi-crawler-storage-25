"""Hosted Reflex deployment helpers."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .product import ProductClient, ProductError, expect_object, resolve_api_key


def _expect_ok(value: Any, *, action: str) -> dict[str, Any]:
    result = expect_object(value, label=f"{action} response")
    if result.get("ok") is True:
        return result
    reason = result.get("reason")
    message = result.get("message")
    detail = reason if isinstance(reason, str) and reason else message
    if not isinstance(detail, str) or not detail:
        detail = "unknown"
    raise ProductError(f"{action}: {detail}.")


def load_deployment_spec(path: str | Path) -> dict[str, Any]:
    spec_path = Path(path)
    try:
        text = spec_path.read_text(encoding="utf-8")
        if spec_path.suffix.lower() in {".yaml", ".yml"}:
            import yaml

            parsed = yaml.safe_load(text)
        else:
            parsed = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ProductError("Deployment spec must be valid JSON.") from exc
    except ImportError as exc:
        raise ProductError("YAML deployment specs require PyYAML to be installed.") from exc
    except OSError as exc:
        raise ProductError(f"Failed to read deployment spec: {exc}") from exc
    if not isinstance(parsed, dict):
        raise ProductError("Deployment spec must be a JSON object.")
    return parsed


def create_deployment(
    *,
    convex_url: str | None = None,
    api_key: str | None = None,
    name: str,
    model_id: str,
    robot_schema_id: str | None = None,
    runtime: str | None = None,
    mode: str = "dry_run",
    spec: dict[str, Any] | None = None,
) -> dict[str, Any]:
    args: dict[str, Any] = {
        "apiKey": resolve_api_key(api_key),
        "name": name,
        "modelId": model_id,
        "mode": mode,
    }
    if robot_schema_id:
        args["robotSchemaId"] = robot_schema_id
    if runtime:
        args["runtime"] = runtime
    if spec is not None:
        args["specJson"] = json.dumps(spec, sort_keys=True)
    return _expect_ok(
        ProductClient(convex_url).mutation("publicApi:createDeployment", args),
        action="Unable to create deployment",
    )


def create_deployment_from_spec(
    path: str | Path,
    *,
    convex_url: str | None = None,
    api_key: str | None = None,
) -> dict[str, Any]:
    spec = load_deployment_spec(path)
    name = spec.get("name")
    model_id = spec.get("modelId") or spec.get("model_id") or spec.get("artifact")
    if not isinstance(name, str) or not name.strip():
        raise ProductError("Deployment spec requires string field: name.")
    if not isinstance(model_id, str) or not model_id.strip():
        raise ProductError("Deployment spec requires string field: modelId.")
    robot_schema_id = spec.get("robotSchemaId") or spec.get("robot_schema_id")
    runtime = spec.get("runtime")
    mode = spec.get("mode") or "dry_run"
    return create_deployment(
        convex_url=convex_url,
        api_key=api_key,
        name=name,
        model_id=model_id,
        robot_schema_id=robot_schema_id if isinstance(robot_schema_id, str) else None,
        runtime=runtime if isinstance(runtime, str) else None,
        mode=mode if isinstance(mode, str) else "dry_run",
        spec=spec,
    )


def list_deployments(
    *,
    convex_url: str | None = None,
    api_key: str | None = None,
) -> dict[str, Any]:
    return _expect_ok(
        ProductClient(convex_url).mutation(
            "publicApi:listDeployments",
            {"apiKey": resolve_api_key(api_key)},
        ),
        action="Unable to list deployments",
    )


def get_deployment(
    deployment_id: str,
    *,
    convex_url: str | None = None,
    api_key: str | None = None,
) -> dict[str, Any]:
    return _expect_ok(
        ProductClient(convex_url).mutation(
            "publicApi:getDeployment",
            {"apiKey": resolve_api_key(api_key), "deploymentId": deployment_id},
        ),
        action="Unable to get deployment",
    )


def run_deployment_doctor(
    deployment_id: str,
    *,
    convex_url: str | None = None,
    api_key: str | None = None,
) -> dict[str, Any]:
    return _expect_ok(
        ProductClient(convex_url).mutation(
            "publicApi:runReadinessCheck",
            {"apiKey": resolve_api_key(api_key), "deploymentId": deployment_id},
        ),
        action="Unable to run readiness check",
    )
