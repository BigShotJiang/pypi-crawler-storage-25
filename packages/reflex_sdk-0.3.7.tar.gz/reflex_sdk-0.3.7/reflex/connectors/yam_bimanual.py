"""Bimanual YAM connector.

Drives two YAM arms over CAN via the i2rt SDK. State and actions are
concatenated as ``[left_7..., right_7...]`` (14-dim total when both arms have
grippers).

Cameras are *not* handled here: every robot setup ships visual input to the
inference server in roughly the same way, so the runner owns camera setup
through :mod:`reflex.cameras` and merges frames into the observation. This
connector returns state only.

This lives inside the reflex repo as a phase-1 stub; in the longer run it
should move to a separate ``reflex-yam`` package so reflex core stays free of
robot-specific dependencies. All hardware imports are lazy so users without
``i2rt`` installed can still import :mod:`reflex` and use other connectors.
"""

from __future__ import annotations

import time
from typing import Any

from reflex.connectors.base import ActionChunk, Observation, RobotConnector


_GRIPPER_KINDS = {
    "linear_4310": "LINEAR_4310",
    "no_gripper": "NO_GRIPPER",
    "yam_teaching_handle": "YAM_TEACHING_HANDLE",
}


class YamBimanualConnector(RobotConnector):
    kind = "yam_bimanual"

    def __init__(
        self,
        *,
        left: dict[str, Any],
        right: dict[str, Any],
        hz: int = 30,
        zero_gravity_mode: bool = False,
        instruction: str = "",
        action_step_delay_s: float | None = None,
        home_pose: list[float] | None = None,
        home_duration_s: float = 4.0,
        chunk_boundary_max_delta: float = 0.02,
        chunk_apply_horizon: int = 0,
    ) -> None:
        if not isinstance(left, dict) or "channel" not in left:
            raise ValueError("yam_bimanual.left requires at least 'channel'")
        if not isinstance(right, dict) or "channel" not in right:
            raise ValueError("yam_bimanual.right requires at least 'channel'")
        self._left_cfg = left
        self._right_cfg = right
        self._hz = max(1, int(hz))
        self._zero_gravity = bool(zero_gravity_mode)
        self._instruction = instruction
        self._step_delay = (
            float(action_step_delay_s)
            if action_step_delay_s is not None
            else 1.0 / self._hz
        )
        # Per-arm 7-D home pose. Default: zeros with gripper at 1.0 rad
        # (matches gello_software start_joints convention).
        self._home_pose = (
            [float(x) for x in home_pose]
            if home_pose is not None
            else [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0]
        )
        self._home_duration_s = max(0.0, float(home_duration_s))
        self._chunk_boundary_max_delta = max(1e-4, float(chunk_boundary_max_delta))
        self._chunk_apply_horizon = max(0, int(chunk_apply_horizon))
        self._left: Any | None = None
        self._right: Any | None = None
        self._action_dim_per_arm: int = 0

    def start(self) -> None:
        try:
            from i2rt.robots.get_robot import get_yam_robot
            from i2rt.robots.utils import GripperType
        except ImportError as exc:
            raise RuntimeError(
                "yam_bimanual connector requires 'i2rt' to be installed. "
                "Install it from https://github.com/i2rt-robotics/i2rt, "
                "or set hardware.kind to a different connector."
            ) from exc

        self._left = get_yam_robot(
            channel=self._left_cfg["channel"],
            gripper_type=_resolve_gripper(GripperType, self._left_cfg.get("gripper", "linear_4310")),
            zero_gravity_mode=self._zero_gravity,
        )
        self._right = get_yam_robot(
            channel=self._right_cfg["channel"],
            gripper_type=_resolve_gripper(GripperType, self._right_cfg.get("gripper", "linear_4310")),
            zero_gravity_mode=self._zero_gravity,
        )
        left_state = self._left.get_joint_pos()
        right_state = self._right.get_joint_pos()
        if len(left_state) != len(right_state):
            raise RuntimeError(
                f"Left arm has {len(left_state)} motors but right has {len(right_state)}; "
                "bimanual symmetry is required."
            )
        self._action_dim_per_arm = int(len(left_state))

    def stop(self) -> None:
        """Drive both arms to home_pose smoothly, then release motor torque
        before closing the motor chains.

        ``MotorChainRobot.close()`` only stops the server/control threads — it
        does NOT send a release-torque or motor-off command. Without an
        explicit zero step, the DM motors latch the last PD command
        (``pos=home, kp~80, kd~5``) and keep applying torque after shutdown.
        That's especially visible on the arm whose shoulder is fighting more
        gravity at the home pose (right arm in our bug report). We explicitly
        zero kp/kd and gravity comp first, give the control loop a beat to
        push that out over CAN, then close.
        """
        if self._left is None or self._right is None:
            return
        _safe_home_bimanual(
            self._left,
            self._right,
            self._home_pose[: self._action_dim_per_arm],
            hz=self._hz,
            duration_s=self._home_duration_s,
            hold_s=0.5,
            label="stop",
        )

        _release_arm_torque(self._left, self._right)

        arms_named = (("left", self._left), ("right", self._right))
        for arm_name, arm in arms_named:
            try:
                arm.close()
            except Exception as e:  # noqa: BLE001
                print(f"[yam_bimanual] WARNING: {arm_name} arm close() failed: {e!r}")
        # close() returns BEFORE the DM control thread has actually exited
        # (it only sets motor_chain.running=False and doesn't join the DM
        # thread). The DM loop checks `running` once per ~4 ms cycle, so we
        # give it 100 ms to finish its current iteration and exit. Without
        # this, motor_off CAN frames arrive while the DM thread is mid-
        # set_commands -> motor responds "disabled" -> i2rt raises
        # RuntimeError in the thread, dumps a noisy traceback, and aborts
        # the remaining motor_off frames.
        time.sleep(0.1)
        # close() + zero_torque_mode only puts the motors in zero-torque
        # mode -- FETs are still conducting, so the user sees the arm "with
        # motors on" after homing (humming, warm, holding pose against
        # back-drive). Send the explicit DM motor_off CAN frame to fully
        # release the windings.
        for arm_name, arm in arms_named:
            _send_motor_off_frames(arm, arm_name)
        self._left = None
        self._right = None


    def get_observation(self) -> Observation:
        if self._left is None or self._right is None:
            raise RuntimeError("YamBimanualConnector.start() must be called first")
        left = list(map(float, self._left.get_joint_pos()))
        right = list(map(float, self._right.get_joint_pos()))
        return Observation(state=left + right, task=self._instruction)

    def apply_action(self, action: ActionChunk) -> None:
        if self._left is None or self._right is None:
            raise RuntimeError("YamBimanualConnector.start() must be called first")
        import numpy as np

        expected = 2 * self._action_dim_per_arm
        if not action.actions:
            return
        if any(len(step) != expected for step in action.actions):
            bad = next(len(s) for s in action.actions if len(s) != expected)
            raise ValueError(
                f"yam_bimanual expects {expected}-dim actions "
                f"({self._action_dim_per_arm} per arm), got {bad}"
            )

        # Execute only the first K actions of the chunk before returning so the
        # runner can re-query with fresh observation. 0 means "apply all".
        steps_to_apply = (
            action.actions[: self._chunk_apply_horizon]
            if self._chunk_apply_horizon
            else action.actions
        )
        if not steps_to_apply:
            return

        actions_arr = np.asarray(steps_to_apply, dtype=float)
        if not np.all(np.isfinite(actions_arr)):
            raise ValueError("yam_bimanual received non-finite action(s); refusing to apply")

        # Bridge from where the arms actually are right now to the first action
        # of this chunk. Without this, a fresh chunk whose first sample is far
        # from the current pose (typical at session start or after a long
        # inference gap) commands a large delta in one motor step.
        current = np.concatenate(
            [
                np.asarray(self._left.get_joint_pos(), dtype=float),
                np.asarray(self._right.get_joint_pos(), dtype=float),
            ]
        )
        first = actions_arr[0]
        max_jump = float(np.max(np.abs(first - current)))
        if max_jump > self._chunk_boundary_max_delta:
            sub_steps = max(1, int(np.ceil(max_jump / self._chunk_boundary_max_delta)))
            for traj in np.linspace(current, first, sub_steps + 1)[1:]:
                self._left.command_joint_pos(traj[: self._action_dim_per_arm])
                self._right.command_joint_pos(traj[self._action_dim_per_arm :])
                if self._step_delay > 0:
                    time.sleep(self._step_delay)

        # CRITICAL SAFETY: per-step delta clamp around the MEASURED pose.
        # Ported from yam_control/inference/bimanual_realtime.py:222-227
        # (original `_safe_target` function, default max_delta=0.05 rad/step).
        # Without this, the model can commit to a 35-degree swing inside one
        # chunk and the SDK applies all 30 steps blindly. With this, no 30Hz
        # motor command can exceed ±_per_step_max_delta from the CURRENT
        # measured pose, no matter what the model commands.
        per_step_max = self._chunk_boundary_max_delta  # reuse the same param
        for step_vec in actions_arr:
            l_current = np.asarray(self._left.get_joint_pos(), dtype=float)
            r_current = np.asarray(self._right.get_joint_pos(), dtype=float)
            l_desired = step_vec[: self._action_dim_per_arm]
            r_desired = step_vec[self._action_dim_per_arm :]
            l_safe = l_current + np.clip(l_desired - l_current, -per_step_max, per_step_max)
            r_safe = r_current + np.clip(r_desired - r_current, -per_step_max, per_step_max)
            self._left.command_joint_pos(l_safe)
            self._right.command_joint_pos(r_safe)
            if self._step_delay > 0:
                time.sleep(self._step_delay)

    def safe_stop(self, reason: str = "") -> None:
        """Emergency stop: SMOOTHLY ramp both arms to home pose, then close.

        Previously this just froze each arm at current pose and immediately
        called close(), which zeroes torques and drops the arm onto the
        table. Now we do a short (2s) home ramp first so the arms come down
        gracefully even on TimeoutError mid-session.
        """
        if self._left is None or self._right is None:
            return
        # Faster ramp than stop() so we react quickly on errors, but still
        # smooth enough not to drop the arm onto the table.
        _safe_home_bimanual(
            self._left,
            self._right,
            self._home_pose[: self._action_dim_per_arm],
            hz=self._hz,
            duration_s=2.0,
            hold_s=0.3,
            label="safe_stop",
        )
        # Release motor torque BEFORE close() — see stop() for why close()
        # alone leaves the motors latched on the last PD command.
        _release_arm_torque(self._left, self._right)
        # Then close BOTH motor chains so torques drop to zero, even if one
        # close fails. Print warnings so the user can see which side held on.
        arms_named = (("left", self._left), ("right", self._right))
        for arm_name, arm in arms_named:
            try:
                arm.close()
            except Exception as e:  # noqa: BLE001
                print(f"[yam_bimanual] WARNING: safe_stop {arm_name} arm close() failed: {e!r}")
        # See stop() for the rationale on this sleep — let the DM control
        # thread fully exit before yanking the motors out from under it.
        time.sleep(0.1)
        # See stop() — explicit motor_off frame fully disables the windings.
        for arm_name, arm in arms_named:
            _send_motor_off_frames(arm, arm_name)
        self._left = None
        self._right = None


def _safe_home_bimanual(
    left: Any,
    right: Any,
    home_pose_per_arm: list,
    *,
    hz: int,
    duration_s: float,
    hold_s: float,
    label: str,
) -> None:
    """Drive both arms to ``home_pose_per_arm`` over ``duration_s``, then hold
    at home for ``hold_s``. Per-step, per-arm exceptions are caught and
    logged once so a single bad CAN frame -- or a totally dead arm -- cannot
    abort homing on the other side.

    Behavior:
      * If ``get_joint_pos`` fails for one arm, we skip the smooth ramp on
        that side and command ``home`` directly each step (best-effort: the
        motor's onboard PD smooths the jump). The other arm still ramps.
      * If ``command_joint_pos`` fails on a step, we log the FIRST failure
        per arm and silently continue -- the loop keeps going so subsequent
        steps still get a chance.
      * If ``duration_s <= 0``, we skip homing entirely (caller asked for it).
      * This function never raises -- callers can rely on it to always return
        so the close + motor_off path runs.

    Why this exists: the user asked for "always go back home after they
    finish, even if inference fails." Previously a single exception (a
    transient CAN read error, a dropped frame, an invalid joint state)
    would jump past the entire ramp via ``except Exception: pass`` and the
    arms would close from wherever they happened to be. Now each step is
    independently guarded.
    """
    if left is None or right is None or duration_s <= 0:
        return
    import numpy as np

    home = np.asarray(home_pose_per_arm, dtype=float)
    step_dt = 1.0 / max(1, int(hz))

    def _safe_get_pos(arm: Any, name: str) -> Any:
        try:
            return np.asarray(arm.get_joint_pos(), dtype=float)
        except Exception as e:  # noqa: BLE001
            print(
                f"[yam_bimanual] WARNING: {label} {name} get_joint_pos failed: "
                f"{e!r}; skipping smooth ramp, will command home directly"
            )
            return None

    cur_left = _safe_get_pos(left, "left")
    cur_right = _safe_get_pos(right, "right")

    ramp_steps = max(1, int(duration_s * hz))
    traj_left = (
        np.linspace(cur_left, home, ramp_steps) if cur_left is not None else None
    )
    traj_right = (
        np.linspace(cur_right, home, ramp_steps) if cur_right is not None else None
    )

    # Track first failure per arm so we don't spam the log every 40 ms.
    failed = {"left": False, "right": False}

    def _safe_cmd(arm: Any, name: str, pos: Any) -> None:
        try:
            arm.command_joint_pos(pos)
        except Exception as e:  # noqa: BLE001
            if not failed[name]:
                failed[name] = True
                print(
                    f"[yam_bimanual] WARNING: {label} {name} command_joint_pos failed "
                    f"(continuing best-effort): {e!r}"
                )

    for i in range(ramp_steps):
        l_target = traj_left[i] if traj_left is not None else home
        r_target = traj_right[i] if traj_right is not None else home
        _safe_cmd(left, "left", l_target)
        _safe_cmd(right, "right", r_target)
        time.sleep(step_dt)

    # Hold at home so the onboard PD integrator settles before we drop the
    # control loop. Same per-arm guards so a dying arm can't break the hold.
    for _ in range(max(1, int(hold_s * hz))):
        _safe_cmd(left, "left", home)
        _safe_cmd(right, "right", home)
        time.sleep(step_dt)


def _release_arm_torque(*arms: Any) -> None:
    """Tell each arm to drop all active torque, then wait for the control
    thread to actually push that out over CAN.

    Why this exists: ``MotorChainRobot.close()`` stops the server thread and
    sets ``DMChainCanInterface.running = False`` — but it does NOT command the
    motors to release. The last MIT-mode frame (``pos=home, kp~80, kd~5``)
    stays latched on the DM motors, so they keep applying PD torque after
    the program exits. On the right arm at home pose the shoulder is fully
    extended and fights gravity at full kp, which is what the user reported
    as motors "still using" / overheating.

    We zero out:
      * the commanded torque, pos, vel, kp, kd  (via ``zero_torque_mode``)
      * the gravity-comp feed-forward            (so update() sends 0)
    so the next CAN frame from the running control thread is a true
    no-torque frame. Then we sleep ~80 ms (~16 DM cycles at 200 Hz) to make
    sure that frame actually reaches every motor before close() stops the
    thread.
    """
    for arm in arms:
        if arm is None:
            continue
        try:
            # Disable gravity compensation FIRST so update() doesn't add the
            # grav-comp feed-forward back on top of our zero command.
            arm.use_gravity_comp = False
        except Exception as e:  # noqa: BLE001
            print(f"[yam_bimanual] WARNING: disabling gravity comp failed: {e!r}")
        try:
            arm.zero_torque_mode()
        except Exception as e:  # noqa: BLE001
            print(f"[yam_bimanual] WARNING: zero_torque_mode failed: {e!r}")
    # DM control loop runs at ~200 Hz; give it enough time for several frames
    # so the zero command definitely lands on the motors before we shut down.
    time.sleep(0.08)


def _send_motor_off_frames(arm: Any, arm_name: str) -> None:
    """Send the DM motor-off CAN frame (``FF FF FF FF FF FF FF FD``) to every
    motor in this arm's chain, fire-and-forget via the raw CAN bus.

    Why: ``MotorChainRobot.close()`` followed by ``zero_torque_mode()`` only
    leaves the motors in *zero-torque* mode -- still electrically enabled,
    FETs still conducting, which the user observes as the right arm "having
    motors on" after the program ends (humming / warm to touch). Sending
    the motor_off CAN frame transitions each DM motor out of enabled state
    so the windings are fully released.

    We bypass i2rt's ``DMSingleMotorCanInterface.motor_off`` because that
    method does a request/response with 5 retries × 200 ms timeout -- up to
    7 s per arm worst case, unacceptable on a shutdown path. ``bus.send``
    is one-way and takes < 1 ms per frame. This MUST run after
    ``arm.close()`` so the DM control loop isn't racing us on the same bus.
    """
    if arm is None:
        return
    try:
        import can  # local import: only needed here, keeps base import light

        bus = arm.motor_chain.motor_interface.bus
        motor_list = arm.motor_chain.motor_list
    except Exception as e:  # noqa: BLE001
        print(f"[yam_bimanual] WARNING: {arm_name} motor_off lookup failed: {e!r}")
        return
    for motor_id, _motor_type in motor_list:
        try:
            msg = can.Message(
                arbitration_id=int(motor_id),
                data=[0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFD],
                is_extended_id=False,
            )
            bus.send(msg)
        except Exception as e:  # noqa: BLE001 - keep going on the rest
            print(f"[yam_bimanual] WARNING: {arm_name} motor_off id={motor_id}: {e!r}")


def _resolve_gripper(gripper_type_enum: Any, name: str) -> Any:
    key = _GRIPPER_KINDS.get(name, name.upper())
    if not hasattr(gripper_type_enum, key):
        available = sorted(_GRIPPER_KINDS) + [
            n for n in dir(gripper_type_enum) if not n.startswith("_")
        ]
        raise ValueError(f"Unknown gripper {name!r}. Known: {available}")
    return getattr(gripper_type_enum, key)


__all__ = ["YamBimanualConnector"]
