"""Base interfaces for robot connectors.

A connector owns the hardware-side of a `reflex connect` session: opening
drivers, reading state and camera frames, and applying action chunks back to
the robot. The connector knows nothing about transports or inference.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass
class Observation:
    """A single timestep observation.

    `state` is the canonical numeric vector the model consumes. `cameras` maps
    a stable channel name (e.g. "left", "front", "wrist") to an image-like
    payload (numpy ndarray or bytes); transports decide how to encode it.
    """

    state: list[float]
    cameras: dict[str, Any] = field(default_factory=dict)
    task: str = ""
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class ActionChunk:
    """A chunk of actions returned by inference.

    `actions` is shaped ``[T, action_dim]``. Connectors are responsible for
    decoding individual steps onto their hardware.
    """

    actions: list[list[float]]
    metadata: dict[str, Any] = field(default_factory=dict)


class RobotConnector(ABC):
    """Hardware-side contract for a `reflex connect` session.

    Subclasses are registered under a `kind` string and instantiated by the
    runner from YAML config.
    """

    kind: str = ""

    @abstractmethod
    def start(self) -> None:
        """Open drivers, cameras, and any other hardware resources."""

    @abstractmethod
    def get_observation(self) -> Observation:
        """Return a single observation. Called once per control step."""

    @abstractmethod
    def apply_action(self, action: ActionChunk) -> None:
        """Apply an action chunk to the hardware."""

    def safe_stop(self, reason: str = "") -> None:
        """Halt motion safely. Default is a no-op; override for real robots."""

    def stop(self) -> None:
        """Release hardware. Default is a no-op."""


__all__ = ["Observation", "ActionChunk", "RobotConnector"]
