"""Robot connector registry."""

from __future__ import annotations

import importlib
from typing import Any, Mapping, Type

from reflex.connectors.base import ActionChunk, Observation, RobotConnector

_BUILTIN: dict[str, str] = {
    "subprocess": "reflex.connectors.shell:SubprocessConnector",
    "yam_bimanual": "reflex.connectors.yam_bimanual:YamBimanualConnector",
}


def get_connector_class(kind: str) -> Type[RobotConnector]:
    """Resolve a connector class by kind string or dotted ``module:Class`` path."""
    target = _BUILTIN.get(kind, kind)
    if ":" not in target:
        raise KeyError(
            f"Unknown connector kind: {kind!r}. "
            f"Known kinds: {sorted(_BUILTIN)} or 'pkg.module:Class' path."
        )
    module_name, class_name = target.split(":", 1)
    module = importlib.import_module(module_name)
    cls = getattr(module, class_name)
    if not (isinstance(cls, type) and issubclass(cls, RobotConnector)):
        raise TypeError(f"{target!r} does not resolve to a RobotConnector subclass")
    return cls


def build_connector(kind: str, config: Mapping[str, Any] | None = None) -> RobotConnector:
    """Instantiate a connector by kind, passing ``config`` as kwargs."""
    cls = get_connector_class(kind)
    return cls(**dict(config or {}))


__all__ = [
    "ActionChunk",
    "Observation",
    "RobotConnector",
    "build_connector",
    "get_connector_class",
]
