"""Subprocess-backed robot connector.

Wraps the legacy ``observe_command`` / ``action_command`` / ``safe_stop_command``
shell hooks behind the :class:`RobotConnector` interface. This is the escape
hatch for robots that don't (yet) have a native Python driver.
"""

from __future__ import annotations

from reflex.connectors.base import ActionChunk, Observation, RobotConnector
from reflex.robot_runtime import _run_json_command


class SubprocessConnector(RobotConnector):
    kind = "subprocess"

    def __init__(
        self,
        observe_command: str,
        action_command: str = "",
        safe_stop_command: str = "",
        command_timeout_s: float = 2.0,
        safe_stop_timeout_s: float = 5.0,
    ) -> None:
        if not observe_command:
            raise ValueError("SubprocessConnector requires observe_command")
        self._observe = observe_command
        self._action = action_command
        self._safe_stop = safe_stop_command
        self._cmd_timeout = command_timeout_s
        self._stop_timeout = safe_stop_timeout_s

    def start(self) -> None:
        return None

    def get_observation(self) -> Observation:
        raw = _run_json_command(self._observe, {}, timeout_s=self._cmd_timeout)
        state_raw = raw.get("state", [])
        state = [float(x) for x in state_raw] if state_raw else []
        cameras = dict(raw.get("images") or raw.get("cameras") or {})
        extra = {
            k: v for k, v in raw.items() if k not in ("state", "images", "cameras", "task")
        }
        return Observation(
            state=state,
            cameras=cameras,
            task=str(raw.get("task", "")),
            extra=extra,
        )

    def apply_action(self, action: ActionChunk) -> None:
        if not self._action:
            return
        payload = {"action_chunk": {"actions": action.actions, **action.metadata}}
        _run_json_command(self._action, payload, timeout_s=self._cmd_timeout)

    def safe_stop(self, reason: str = "") -> None:
        if not self._safe_stop:
            return
        _run_json_command(
            self._safe_stop,
            {"reason": reason},
            timeout_s=self._stop_timeout,
        )


__all__ = ["SubprocessConnector"]
