"""Minimal Convex HTTP client for public API-key SDK calls."""

from __future__ import annotations

import base64
import json
import math
import os
import struct
from pathlib import Path
from typing import Any
from urllib import error, parse, request

from ._version import convex_client_header

DEFAULT_CONVEX_URL = "https://kindly-bullfrog-494.convex.cloud"
CONVEX_CLIENT_HEADER = convex_client_header()


def convex_url(value: str | None = None) -> str:
    resolved = (
        value
        or os.environ.get("REFLEX_CONVEX_URL", "")
        or os.environ.get("CONVEX_URL", "")
        or os.environ.get("NEXT_PUBLIC_CONVEX_URL", "")
        or DEFAULT_CONVEX_URL
    ).strip().rstrip("/")
    parsed = parse.urlparse(resolved)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError("Convex URL must start with http:// or https://.")
    return resolved


def _load_local_env(path: str | Path = ".env") -> None:
    env_path = Path(path)
    if not env_path.exists():
        return
    for line in env_path.read_text().splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, value = stripped.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip("\"'"))


_load_local_env()


def _convex_to_json(value: Any) -> Any:
    if value is None or isinstance(value, (bool, str)):
        return value
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        if math.isnan(value) or math.isinf(value) or value == 0.0 and math.copysign(1.0, value) < 0:
            return {"$float": base64.b64encode(struct.pack("<d", value)).decode("ascii")}
        return value
    if isinstance(value, (bytes, bytearray)):
        return {"$bytes": base64.b64encode(bytes(value)).decode("ascii")}
    if isinstance(value, (list, tuple)):
        return [_convex_to_json(item) for item in value]
    if isinstance(value, dict):
        return {
            str(key): _convex_to_json(item)
            for key, item in sorted(value.items(), key=lambda entry: str(entry[0]))
        }
    raise TypeError(f"{type(value).__name__} is not a supported Convex value")


def _json_to_convex(value: Any) -> Any:
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, list):
        return [_json_to_convex(item) for item in value]
    if isinstance(value, dict):
        if set(value) == {"$integer"}:
            return int.from_bytes(base64.b64decode(str(value["$integer"])), "little", signed=True)
        if set(value) == {"$float"}:
            return struct.unpack("<d", base64.b64decode(str(value["$float"])))[0]
        if set(value) == {"$bytes"}:
            return base64.b64decode(str(value["$bytes"]))
        return {str(key): _json_to_convex(item) for key, item in value.items()}
    return value


def convex_call(
    kind: str,
    function_name: str,
    args: dict[str, Any] | None = None,
    *,
    url: str | None = None,
    timeout: float = 60.0,
) -> Any:
    if kind not in {"action", "mutation", "query"}:
        raise ValueError("Convex function kind must be action, mutation, or query.")
    body = json.dumps(
        {
            "path": function_name,
            "format": "convex_encoded_json",
            "args": [_convex_to_json(args or {})],
        }
    ).encode("utf-8")
    req = request.Request(
        f"{convex_url(url)}/api/{kind}",
        data=body,
        method="POST",
        headers={
            "Content-Type": "application/json",
            "Convex-Client": CONVEX_CLIENT_HEADER,
        },
    )
    try:
        with request.urlopen(req, timeout=timeout) as response:
            raw = response.read().decode("utf-8")
    except error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        if exc.code != 560:
            raise RuntimeError(f"Convex {kind} {function_name} failed: {exc.code} {raw}".strip()) from exc
    except error.URLError as exc:
        raise RuntimeError(f"Failed to reach Convex: {exc.reason}") from exc

    parsed = json.loads(raw) if raw else {}
    if not isinstance(parsed, dict):
        raise RuntimeError(f"Unexpected Convex response: {parsed!r}")
    status = parsed.get("status")
    if status == "success":
        return _json_to_convex(parsed.get("value"))
    if status == "error":
        raise RuntimeError(str(parsed.get("errorMessage") or f"Convex {function_name} failed"))
    raise RuntimeError(f"Unexpected Convex response: {parsed!r}")


def convex_action(function_name: str, args: dict[str, Any] | None = None, **kwargs: Any) -> Any:
    return convex_call("action", function_name, args, **kwargs)


def convex_mutation(function_name: str, args: dict[str, Any] | None = None, **kwargs: Any) -> Any:
    return convex_call("mutation", function_name, args, **kwargs)


def convex_query(function_name: str, args: dict[str, Any] | None = None, **kwargs: Any) -> Any:
    return convex_call("query", function_name, args, **kwargs)
