"""Hosted Reflex deployment receipt helpers."""

from __future__ import annotations

from typing import Any

from .product import ProductClient, ProductError, expect_object, resolve_api_key


def _expect_ok(value: Any, *, action: str) -> dict[str, Any]:
    result = expect_object(value, label=f"{action} response")
    if result.get("ok") is True:
        return result
    reason = result.get("reason")
    message = result.get("message")
    detail = reason if isinstance(reason, str) and reason else message
    if not isinstance(detail, str) or not detail:
        detail = "unknown"
    raise ProductError(f"{action}: {detail}.")


def list_receipts(
    *,
    convex_url: str | None = None,
    api_key: str | None = None,
    deployment_id: str | None = None,
) -> dict[str, Any]:
    args: dict[str, Any] = {"apiKey": resolve_api_key(api_key)}
    if deployment_id:
        args["deploymentId"] = deployment_id
    return _expect_ok(
        ProductClient(convex_url).mutation("publicApi:listDeploymentReceipts", args),
        action="Unable to list receipts",
    )
