"""Generic robot execution loop for Reflex DRTC sessions."""

from __future__ import annotations

import json
import shlex
import subprocess
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Protocol


class DrtcClient(Protocol):
    def infer(self, payload: dict[str, Any]) -> dict[str, Any]:
        ...

    def close(self) -> None:
        ...


@dataclass(frozen=True)
class RobotExecutionConfig:
    session_id: str
    deployment_id: str
    robot_id: str
    mode: str = "dry_run"
    task: str = ""
    config_hash: str = ""
    max_steps: int = 0
    control_period_s: float = 0.02
    observe_command: str = ""
    action_command: str = ""
    safe_stop_command: str = ""
    command_timeout_s: float = 2.0
    safe_stop_timeout_s: float = 5.0
    heartbeat: Callable[[dict[str, Any]], None] | None = None
    heartbeat_interval_s: float = 10.0
    stop_on_error: bool = True


@dataclass(frozen=True)
class RobotExecutionResult:
    steps: int
    applied_steps: int
    safe_stops: int
    last_action_chunk: dict[str, Any] | None = None
    errors: list[str] = field(default_factory=list)


def run_robot_execution_loop(
    *,
    drtc_client: DrtcClient,
    config: RobotExecutionConfig,
) -> RobotExecutionResult:
    if not config.observe_command:
        raise ValueError("observe_command is required for robot execution")
    if config.mode == "apply_actions" and not config.action_command:
        raise ValueError("action_command is required for apply_actions mode")

    steps = 0
    applied_steps = 0
    safe_stops = 0
    errors: list[str] = []
    last_action_chunk: dict[str, Any] | None = None
    last_heartbeat = 0.0
    max_steps = max(0, int(config.max_steps))

    while max_steps == 0 or steps < max_steps:
        started = time.monotonic()
        try:
            observation = _run_json_command(
                config.observe_command, {}, timeout_s=config.command_timeout_s
            )
            payload = _build_drtc_payload(config=config, observation=observation, control_step=steps)
            action_chunk = _json_safe(drtc_client.infer(payload))
            last_action_chunk = action_chunk
            if config.mode == "apply_actions":
                _run_json_command(
                    config.action_command,
                    {
                        "session_id": config.session_id,
                        "deployment_id": config.deployment_id,
                        "robot_id": config.robot_id,
                        "control_step": steps,
                        "action_chunk": action_chunk,
                    },
                    timeout_s=config.command_timeout_s,
                )
                applied_steps += 1
        except Exception as exc:  # noqa: BLE001 - connector must fail closed.
            message = str(exc) or exc.__class__.__name__
            errors.append(message)
            safe_stops += 1
            try:
                _run_safe_stop(config, reason=message, control_step=steps)
            except Exception as safe_stop_exc:  # noqa: BLE001 - never re-stop a failed stop.
                errors.append(f"safe_stop_failed: {safe_stop_exc}")
            if config.stop_on_error:
                break
        steps += 1

        now = time.monotonic()
        if config.heartbeat is not None and now - last_heartbeat >= config.heartbeat_interval_s:
            config.heartbeat(
                {
                    "session_id": config.session_id,
                    "deployment_id": config.deployment_id,
                    "robot_id": config.robot_id,
                    "transport": "drtc",
                    "message": "execution_loop_active",
                }
            )
            last_heartbeat = now

        elapsed = time.monotonic() - started
        sleep_s = max(0.0, float(config.control_period_s) - elapsed)
        if sleep_s:
            time.sleep(sleep_s)

    return RobotExecutionResult(
        steps=steps,
        applied_steps=applied_steps,
        safe_stops=safe_stops,
        last_action_chunk=last_action_chunk,
        errors=errors,
    )


def _build_drtc_payload(
    *,
    config: RobotExecutionConfig,
    observation: dict[str, Any],
    control_step: int,
) -> dict[str, Any]:
    payload = {
        "session_id": config.session_id,
        "config_hash": config.config_hash,
        "deployment_id": config.deployment_id,
        "robot_id": config.robot_id,
        "control_step": control_step,
        "task": observation.get("task") or config.task,
        "observation": observation,
    }
    if "state" in observation:
        payload["state"] = observation["state"]
    if "images" in observation:
        payload["images"] = observation["images"]
    return payload


def _run_safe_stop(config: RobotExecutionConfig, *, reason: str, control_step: int) -> None:
    if not config.safe_stop_command:
        return
    _run_json_command(
        config.safe_stop_command,
        {
            "session_id": config.session_id,
            "deployment_id": config.deployment_id,
            "robot_id": config.robot_id,
            "control_step": control_step,
            "reason": reason,
        },
        timeout_s=config.safe_stop_timeout_s,
    )


def _run_json_command(
    command: str, payload: dict[str, Any], *, timeout_s: float | None = None
) -> dict[str, Any]:
    args = shlex.split(command)
    if not args:
        raise ValueError("command must not be empty")
    timeout = float(timeout_s) if timeout_s and timeout_s > 0 else None
    try:
        completed = subprocess.run(
            args,
            input=json.dumps(payload, separators=(",", ":")),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=False,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(
            f"command timed out after {timeout}s: {args[0]}"
        ) from exc
    if completed.returncode != 0:
        detail = completed.stderr.strip() or completed.stdout.strip()
        raise RuntimeError(f"command failed ({completed.returncode}): {detail}")
    text = completed.stdout.strip()
    if not text:
        return {}
    parsed = json.loads(text)
    if not isinstance(parsed, dict):
        raise ValueError("command must emit a JSON object")
    return parsed


def _json_safe(value: Any) -> Any:
    if hasattr(value, "tolist"):
        return value.tolist()
    if isinstance(value, dict):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    return value
