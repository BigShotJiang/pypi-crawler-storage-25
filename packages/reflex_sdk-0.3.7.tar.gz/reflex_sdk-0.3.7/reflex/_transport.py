"""Shared configuration and HTTP transport helpers for the public SDK."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any
from urllib import error, parse, request

from ._version import user_agent as _user_agent

DEFAULT_API_URL = "https://api.tryreflex.ai"
DEFAULT_USER_AGENT = _user_agent("reflex-sdk")


def load_local_env(path: str | Path = ".env") -> None:
    env_path = Path(path)
    if not env_path.exists():
        return
    for line in env_path.read_text().splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, value = stripped.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip("\"'"))


load_local_env()


def api_key(value: str | None) -> str:
    resolved = (
        value
        or os.environ.get("REFLEX_API_KEY", "")
        or os.environ.get("RFX_API_KEY", "")
    ).strip()
    if not resolved:
        raise ValueError("API key is required. Set api_key or REFLEX_API_KEY.")
    return resolved


def base_url(value: str | None) -> str:
    resolved = (
        value
        or os.environ.get("REFLEX_API_URL", "")
        or os.environ.get("REFLEX_PLATFORM_URL", "")
        or os.environ.get("RFX_API_URL", "")
        or DEFAULT_API_URL
    ).strip().rstrip("/")
    parsed = parse.urlparse(resolved)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError("API URL must start with http:// or https://.")
    return resolved


def request_json(
    *,
    url: str | None,
    api_key_value: str | None,
    path: str,
    payload: dict[str, Any] | None = None,
    method: str = "POST",
    timeout: float = 30.0,
    user_agent: str = DEFAULT_USER_AGENT,
) -> dict[str, Any]:
    body = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = request.Request(
        parse.urljoin(f"{base_url(url)}/", path.lstrip("/")),
        data=body,
        method=method,
        headers={
            "Authorization": f"Bearer {api_key(api_key_value)}",
            "User-Agent": user_agent,
            **({"Content-Type": "application/json"} if payload is not None else {}),
        },
    )
    try:
        with request.urlopen(req, timeout=timeout) as response:
            raw = response.read().decode("utf-8")
    except error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"{exc.code} {detail}".strip()) from exc
    except error.URLError as exc:
        raise RuntimeError(f"Failed to reach Reflex API: {exc.reason}") from exc
    parsed = json.loads(raw) if raw else {}
    if not isinstance(parsed, dict):
        raise RuntimeError(f"Unexpected Reflex API response: {parsed!r}")
    return parsed
