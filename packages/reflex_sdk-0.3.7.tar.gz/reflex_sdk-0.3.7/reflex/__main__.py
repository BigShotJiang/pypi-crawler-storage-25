"""Run the Reflex CLI with `python -m reflex`."""

from .cli import main_reflex


if __name__ == "__main__":
    main_reflex()
