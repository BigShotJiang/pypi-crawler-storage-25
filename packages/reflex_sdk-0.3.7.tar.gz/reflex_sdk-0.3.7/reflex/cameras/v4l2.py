"""V4L2 / UVC webcam source via OpenCV.

Works for any standard USB webcam Linux exposes under ``/dev/video*``
(Logitech, Elgato, generic UVC). Frames are read as BGR by OpenCV and
converted to RGB before being returned.
"""

from __future__ import annotations

from typing import Any

from reflex.cameras.base import CameraSource


class V4L2Camera(CameraSource):
    kind = "v4l2"

    def __init__(
        self,
        *,
        device: str | int,
        width: int = 640,
        height: int = 480,
        warmup_frames: int = 5,
        fourcc: str = "MJPG",
    ) -> None:
        if device is None or device == "":
            raise ValueError("V4L2Camera requires device (path or index)")
        self._device = device
        self._width = int(width)
        self._height = int(height)
        self._warmup_frames = max(0, int(warmup_frames))
        self._fourcc = fourcc
        self._capture: Any | None = None

    def start(self) -> None:
        try:
            import cv2  # type: ignore
        except ImportError as exc:
            raise RuntimeError(
                "V4L2Camera requires 'opencv-python'. "
                "Install with: pip install opencv-python-headless"
            ) from exc

        cap = cv2.VideoCapture(self._device, cv2.CAP_V4L2)
        if not cap.isOpened():
            raise RuntimeError(f"V4L2Camera failed to open {self._device!r}")
        if self._fourcc:
            cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*self._fourcc))
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, self._width)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self._height)
        for _ in range(self._warmup_frames):
            cap.read()
        self._capture = cap

    def read(self) -> Any:
        if self._capture is None:
            raise RuntimeError("V4L2Camera.start() must be called before read()")
        import cv2  # type: ignore

        ok, frame = self._capture.read()
        if not ok or frame is None:
            return None
        return cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    def stop(self) -> None:
        if self._capture is not None:
            try:
                self._capture.release()
            except Exception:  # noqa: BLE001 - best-effort shutdown
                pass
            self._capture = None


__all__ = ["V4L2Camera"]
