"""Base interface for camera sources.

A :class:`CameraSource` owns one video input (a USB webcam, a RealSense
pipeline, a GStreamer source, a ROS2 image topic, etc.) and yields one RGB
frame per ``read()`` call. Cameras are deliberately decoupled from robot
connectors: every robot setup ships visual input to the inference server in
roughly the same way, so this concern lives at the runner level rather than
inside each robot driver.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class CameraSource(ABC):
    """Single named video input that produces HxWx3 uint8 RGB ndarrays."""

    kind: str = ""

    @abstractmethod
    def start(self) -> None:
        """Open the underlying device or pipeline."""

    @abstractmethod
    def read(self) -> Any:
        """Return the most recent frame as an HxWx3 uint8 RGB ndarray.

        Implementations may block briefly while waiting for a fresh frame.
        Returning ``None`` is allowed when no frame is available; the runner
        will simply omit that channel from the observation.
        """

    def stop(self) -> None:
        """Release device resources. Default no-op."""


__all__ = ["CameraSource"]
