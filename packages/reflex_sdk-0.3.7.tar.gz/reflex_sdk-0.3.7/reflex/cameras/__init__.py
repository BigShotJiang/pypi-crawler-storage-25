"""Camera source registry."""

from __future__ import annotations

import importlib
from typing import Any, Mapping, Type

from reflex.cameras.base import CameraSource

_BUILTIN: dict[str, str] = {
    "realsense": "reflex.cameras.realsense:RealSenseCamera",
    "v4l2": "reflex.cameras.v4l2:V4L2Camera",
    "webcam": "reflex.cameras.v4l2:V4L2Camera",  # convenience alias
    "shm": "reflex.cameras.shm:ShmCameraSource",
}


def get_camera_class(kind: str) -> Type[CameraSource]:
    """Resolve a camera source class by kind string or dotted ``module:Class`` path."""
    target = _BUILTIN.get(kind, kind)
    if ":" not in target:
        raise KeyError(
            f"Unknown camera kind: {kind!r}. "
            f"Known kinds: {sorted(_BUILTIN)} or 'pkg.module:Class' path."
        )
    module_name, class_name = target.split(":", 1)
    module = importlib.import_module(module_name)
    cls = getattr(module, class_name)
    if not (isinstance(cls, type) and issubclass(cls, CameraSource)):
        raise TypeError(f"{target!r} does not resolve to a CameraSource subclass")
    return cls


def build_camera(kind: str, config: Mapping[str, Any] | None = None) -> CameraSource:
    cls = get_camera_class(kind)
    return cls(**dict(config or {}))


__all__ = ["CameraSource", "build_camera", "get_camera_class"]
