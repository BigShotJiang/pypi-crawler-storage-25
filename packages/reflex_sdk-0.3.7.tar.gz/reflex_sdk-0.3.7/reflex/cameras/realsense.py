"""Intel RealSense camera source via pyrealsense2."""

from __future__ import annotations

from typing import Any

from reflex.cameras.base import CameraSource


class RealSenseCamera(CameraSource):
    kind = "realsense"

    def __init__(
        self,
        *,
        serial: str,
        width: int = 640,
        height: int = 480,
        fps: int = 30,
        warmup_frames: int = 5,
    ) -> None:
        if not serial:
            raise ValueError("RealSenseCamera requires serial")
        self._serial = str(serial)
        self._width = int(width)
        self._height = int(height)
        self._fps = int(fps)
        self._warmup_frames = max(0, int(warmup_frames))
        self._pipeline: Any | None = None

    def start(self) -> None:
        try:
            import pyrealsense2 as rs  # type: ignore
        except ImportError as exc:
            raise RuntimeError(
                "RealSenseCamera requires 'pyrealsense2'. "
                "Install with: pip install pyrealsense2"
            ) from exc
        pipeline = rs.pipeline()
        config = rs.config()
        config.enable_device(self._serial)
        config.enable_stream(
            rs.stream.color, self._width, self._height, rs.format.rgb8, self._fps
        )
        pipeline.start(config)
        for _ in range(self._warmup_frames):
            try:
                pipeline.wait_for_frames(timeout_ms=2000)
            except Exception:  # noqa: BLE001 - tolerate a slow start
                break
        self._pipeline = pipeline

    def read(self) -> Any:
        if self._pipeline is None:
            raise RuntimeError("RealSenseCamera.start() must be called before read()")
        import numpy as np

        frames = self._pipeline.wait_for_frames(timeout_ms=1000)
        color = frames.get_color_frame()
        if not color:
            return None
        return np.asanyarray(color.get_data())

    def stop(self) -> None:
        if self._pipeline is not None:
            try:
                self._pipeline.stop()
            except Exception:  # noqa: BLE001 - best-effort shutdown
                pass
            self._pipeline = None


__all__ = ["RealSenseCamera"]
