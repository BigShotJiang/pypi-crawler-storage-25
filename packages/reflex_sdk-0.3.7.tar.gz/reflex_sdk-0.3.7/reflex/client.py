"""Unified public Reflex SDK client."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .actions import connect, infer_actions
from .datasets import (
    complete_dataset,
    create_dataset,
    get_dataset,
    list_datasets,
    register_huggingface_dataset,
    upload_dataset,
    validate_dataset,
)
from .deployments import (
    create_deployment,
    create_deployment_from_spec,
    get_deployment,
    list_deployments,
    run_deployment_doctor,
)
from .instances import instance_status, provision_instance, teardown_instance
from .receipts import list_receipts
from .robots import (
    claim_pairing_token,
    create_pairing_token,
    heartbeat_robot,
    list_robot_schemas,
    list_robots,
    register_robot,
    register_robot_schema,
)
from .sessions import close_session, list_sessions, promote_session, start_session
from .training import (
    LoraTrainingClient,
    ServiceClient,
    cancel_training_job,
    create_training_job,
    full_finetune,
    get_training_job,
    list_training_jobs,
    lora_finetune,
)


class ActionsClient:
    def __init__(self, *, url: str | None, api_key: str | None) -> None:
        self._url = url
        self._api_key = api_key

    def connect(self, **kwargs: Any) -> Any:
        return connect(url=self._url, api_key=self._api_key, **kwargs)

    def infer(self, observation: dict[str, Any], *, timeout: float = 30.0) -> dict[str, Any]:
        return infer_actions(
            url=self._url,
            api_key=self._api_key,
            observation=observation,
            timeout=timeout,
        )


class InstancesClient:
    def __init__(self, *, url: str | None, api_key: str | None) -> None:
        self._url = url
        self._api_key = api_key

    def provision(self, **kwargs: Any) -> dict[str, Any]:
        return provision_instance(url=self._url, api_key=self._api_key, **kwargs)

    def status(self) -> dict[str, Any]:
        return instance_status(url=self._url, api_key=self._api_key)

    def teardown(self) -> dict[str, Any]:
        return teardown_instance(url=self._url, api_key=self._api_key)


class DatasetsClient:
    def __init__(self, *, url: str | None, convex_url: str | None, api_key: str | None) -> None:
        self._url = url
        self._convex_url = convex_url
        self._api_key = api_key

    def create(self, *, name: str, size_bytes: int | None = None, request_id: str = "") -> dict[str, Any]:
        return create_dataset(
            url=self._url,
            api_key=self._api_key,
            name=name,
            size_bytes=size_bytes,
            request_id=request_id,
        )

    def list(self, *, status: str | None = None) -> dict[str, Any]:
        return list_datasets(url=self._url, api_key=self._api_key, status=status)

    def get(self, dataset_id: str) -> dict[str, Any]:
        return get_dataset(dataset_id, url=self._url, api_key=self._api_key)

    def complete(self, dataset_id: str, *, size_bytes: int | None = None) -> dict[str, Any]:
        return complete_dataset(
            dataset_id,
            url=self._url,
            api_key=self._api_key,
            size_bytes=size_bytes,
        )

    def upload(
        self,
        path: str | Path,
        *,
        name: str | None = None,
        request_id: str = "",
    ) -> dict[str, Any]:
        return upload_dataset(
            path,
            url=self._url,
            api_key=self._api_key,
            name=name,
            request_id=request_id,
        )

    def register_huggingface(self, hf_source_uri: str) -> dict[str, Any]:
        return register_huggingface_dataset(
            hf_source_uri,
            convex_url=self._convex_url,
            api_key=self._api_key,
        )

    def validate(self, dataset_id: str) -> dict[str, Any]:
        return validate_dataset(
            dataset_id,
            convex_url=self._convex_url,
            api_key=self._api_key,
        )


class TrainingClient:
    def __init__(self, *, url: str | None, convex_url: str | None, api_key: str | None) -> None:
        self._url = url
        self._convex_url = convex_url
        self._api_key = api_key

    def create(
        self,
        *,
        dataset_id: str | None = None,
        hf_source_uri: str | None = None,
        base_model: str = "pi0.5",
        base_model_id: str | None = None,
        fine_tuning_type: str = "lora",
        adapter_name: str = "",
        model_name: str = "",
        version: str = "v1",
        model_version: str = "",
        max_minutes: int | None = None,
        request_id: str = "",
        epochs: int | None = None,
        parameters: dict[str, Any] | None = None,
        max_steps: int | None = None,
        batch_size: int | None = None,
        learning_rate: float | None = None,
        lora_rank: int | None = None,
    ) -> dict[str, Any]:
        return create_training_job(
            url=self._url,
            convex_url=self._convex_url,
            api_key=self._api_key,
            dataset_id=dataset_id,
            hf_source_uri=hf_source_uri,
            base_model=base_model,
            base_model_id=base_model_id,
            fine_tuning_type=fine_tuning_type,
            adapter_name=adapter_name,
            model_name=model_name,
            version=version,
            model_version=model_version,
            max_minutes=max_minutes,
            request_id=request_id,
            epochs=epochs,
            parameters=parameters,
            max_steps=max_steps,
            batch_size=batch_size,
            learning_rate=learning_rate,
            lora_rank=lora_rank,
        )

    def lora_finetune(self, **kwargs: Any) -> dict[str, Any]:
        return lora_finetune(convex_url=self._convex_url, api_key=self._api_key, **kwargs)

    def full_finetune(self, **kwargs: Any) -> dict[str, Any]:
        return full_finetune(convex_url=self._convex_url, api_key=self._api_key, **kwargs)

    def full_train(self, **kwargs: Any) -> dict[str, Any]:
        return self.full_finetune(**kwargs)

    def list(self, *, status: str | None = None) -> dict[str, Any]:
        return list_training_jobs(convex_url=self._convex_url, api_key=self._api_key, status=status)

    def get(self, training_job_id: str) -> dict[str, Any]:
        return get_training_job(
            training_job_id,
            url=self._url,
            convex_url=self._convex_url,
            api_key=self._api_key,
        )

    def cancel(self, training_job_id: str) -> dict[str, Any]:
        return cancel_training_job(
            training_job_id,
            url=self._url,
            convex_url=self._convex_url,
            api_key=self._api_key,
        )

    def create_lora_training_client(
        self,
        *,
        base_model: str = "pi0.7-flash",
        name: str = "",
        rank: int = 32,
        dataset_id: str = "",
        max_minutes: int | None = None,
        request_id: str = "",
        config: dict[str, Any] | None = None,
    ) -> LoraTrainingClient:
        return ServiceClient(api_key=self._api_key, url=self._url).create_lora_training_client(
            base_model=base_model,
            name=name,
            rank=rank,
            dataset_id=dataset_id,
            max_minutes=max_minutes,
            request_id=request_id,
            config=config,
        )


class SessionsClient:
    def __init__(self, *, convex_url: str | None, api_key: str | None) -> None:
        self._convex_url = convex_url
        self._api_key = api_key

    def start(
        self,
        *,
        artifact_id: str | None = None,
        deployment_id: str | None = None,
        robot_id: str | None = None,
        base_model: str = "pi0.5",
        runtime: str | None = None,
        mode: str = "dry_run",
        client_session_id: str | None = None,
    ) -> dict[str, Any]:
        return start_session(
            convex_url=self._convex_url,
            api_key=self._api_key,
            artifact_id=artifact_id,
            deployment_id=deployment_id,
            robot_id=robot_id,
            base_model=base_model,
            runtime=runtime,
            mode=mode,
            client_session_id=client_session_id,
        )

    def close(self, session_id: str, *, reason: str = "sdk_closed") -> dict[str, Any]:
        return close_session(
            session_id,
            convex_url=self._convex_url,
            api_key=self._api_key,
            reason=reason,
        )

    def promote(self, session_id: str, *, mode: str = "apply_actions") -> dict[str, Any]:
        return promote_session(
            session_id,
            convex_url=self._convex_url,
            api_key=self._api_key,
            mode=mode,
        )

    def list(self, *, status: str | None = None) -> dict[str, Any]:
        return list_sessions(
            convex_url=self._convex_url,
            api_key=self._api_key,
            status=status,
        )


class DeploymentsClient:
    def __init__(self, *, convex_url: str | None, api_key: str | None) -> None:
        self._convex_url = convex_url
        self._api_key = api_key

    def create(self, **kwargs: Any) -> dict[str, Any]:
        return create_deployment(convex_url=self._convex_url, api_key=self._api_key, **kwargs)

    def create_from_spec(self, path: str | Path) -> dict[str, Any]:
        return create_deployment_from_spec(path, convex_url=self._convex_url, api_key=self._api_key)

    def list(self) -> dict[str, Any]:
        return list_deployments(convex_url=self._convex_url, api_key=self._api_key)

    def get(self, deployment_id: str) -> dict[str, Any]:
        return get_deployment(deployment_id, convex_url=self._convex_url, api_key=self._api_key)

    def doctor(self, deployment_id: str) -> dict[str, Any]:
        return run_deployment_doctor(deployment_id, convex_url=self._convex_url, api_key=self._api_key)


class RobotsClient:
    def __init__(self, *, convex_url: str | None, api_key: str | None) -> None:
        self._convex_url = convex_url
        self._api_key = api_key

    def register_schema(self, **kwargs: Any) -> dict[str, Any]:
        return register_robot_schema(convex_url=self._convex_url, api_key=self._api_key, **kwargs)

    def list_schemas(self) -> dict[str, Any]:
        return list_robot_schemas(convex_url=self._convex_url, api_key=self._api_key)

    def register(self, **kwargs: Any) -> dict[str, Any]:
        return register_robot(convex_url=self._convex_url, api_key=self._api_key, **kwargs)

    def list(self) -> dict[str, Any]:
        return list_robots(convex_url=self._convex_url, api_key=self._api_key)

    def create_pairing_token(self, robot_id: str, *, ttl_seconds: int | None = None) -> dict[str, Any]:
        return create_pairing_token(
            robot_id,
            convex_url=self._convex_url,
            api_key=self._api_key,
            ttl_seconds=ttl_seconds,
        )

    def claim_pairing_token(self, token: str) -> dict[str, Any]:
        return claim_pairing_token(token, convex_url=self._convex_url, api_key=self._api_key)

    def heartbeat(self, robot_id: str, **kwargs: Any) -> dict[str, Any]:
        return heartbeat_robot(
            robot_id,
            convex_url=self._convex_url,
            api_key=self._api_key,
            **kwargs,
        )


class ReceiptsClient:
    def __init__(self, *, convex_url: str | None, api_key: str | None) -> None:
        self._convex_url = convex_url
        self._api_key = api_key

    def list(self, *, deployment_id: str | None = None) -> dict[str, Any]:
        return list_receipts(
            convex_url=self._convex_url,
            api_key=self._api_key,
            deployment_id=deployment_id,
        )


class Client:
    """Reflex SDK entry point.

    Reads `REFLEX_API_KEY` and the production API URL by default. Pass `url=`
    or set `REFLEX_API_URL` for local development and preview deployments.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        url: str | None = None,
        convex_url: str | None = None,
    ) -> None:
        self.api_key = api_key
        self.url = url
        self.convex_url = convex_url
        self.actions = ActionsClient(url=url, api_key=api_key)
        self.instances = InstancesClient(url=url, api_key=api_key)
        self.datasets = DatasetsClient(url=url, convex_url=convex_url, api_key=api_key)
        self.training = TrainingClient(url=url, convex_url=convex_url, api_key=api_key)
        self.sessions = SessionsClient(convex_url=convex_url, api_key=api_key)
        self.deployments = DeploymentsClient(convex_url=convex_url, api_key=api_key)
        self.robots = RobotsClient(convex_url=convex_url, api_key=api_key)
        self.receipts = ReceiptsClient(convex_url=convex_url, api_key=api_key)
