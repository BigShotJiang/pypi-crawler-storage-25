"""Client helpers for customer model uploads from Hugging Face + direct."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any
from urllib import error as _urllib_error, request as _urllib_request

from ._convex import convex_action, convex_call, convex_mutation
from ._transport import api_key as resolve_api_key

UPLOAD_DIRECT_MAX_BYTES = 500 * 1024 * 1024


def import_from_hf(
    hf_repo: str,
    name: str,
    *,
    hf_revision: str | None = None,
    hf_token: str | None = None,
    convex_url: str | None = None,
    api_key: str | None = None,
) -> dict[str, Any]:
    """Import a customer model adapter from a Hugging Face repository.

    Triggers ``publicApi:importModelFromHuggingFace`` on Convex, which kicks off
    a background pull of the adapter weights from ``hf_repo`` (optionally pinned
    to ``hf_revision``) into Reflex-owned storage. Use ``hf_token`` for private
    Hugging Face repos. Returns the Convex action payload, including
    ``modelId`` and ``status`` (typically ``"pulling"`` on success).
    """
    args: dict[str, Any] = {
        "apiKey": resolve_api_key(api_key),
        "hfRepo": hf_repo,
        "name": name,
    }
    if hf_revision is not None:
        args["hfRevision"] = hf_revision
    if hf_token is not None:
        args["hfToken"] = hf_token
    payload = convex_action(
        "publicApi:importModelFromHuggingFace",
        args,
        url=convex_url,
    )
    if not isinstance(payload, dict):
        raise RuntimeError(f"Unexpected Convex model response: {payload!r}")
    return payload


def upload_direct(
    adapter_file: str | Path,
    adapter_config_json: str | Path | dict[str, Any],
    name: str,
    *,
    convex_url: str | None = None,
    api_key: str | None = None,
) -> dict[str, Any]:
    """Upload a small (<500 MB) pi0.5 LoRA adapter file directly to Reflex.

    Bypasses Hugging Face entirely. Takes a path to the ``.safetensors``
    adapter weights and either a path to ``adapter_config.json`` or the
    already-parsed config dict. The file is POSTed to a pre-signed Convex
    storage URL, then ``publicApi:uploadModelDirect`` is invoked to kick
    off the Modal prepare worker. Returns the action payload (modelId,
    status="pulling" on success).
    """
    adapter_path = Path(adapter_file).expanduser().resolve()
    if not adapter_path.is_file():
        raise FileNotFoundError(f"adapter file not found: {adapter_path}")
    size_bytes = adapter_path.stat().st_size
    if size_bytes > UPLOAD_DIRECT_MAX_BYTES:
        raise ValueError(
            f"adapter file {adapter_path.name} is "
            f"{size_bytes / 1024**2:.1f} MiB which exceeds the "
            f"{UPLOAD_DIRECT_MAX_BYTES // 1024**2} MiB direct-upload cap; "
            "use import_from_hf for larger models",
        )

    if isinstance(adapter_config_json, dict):
        cfg_text = json.dumps(adapter_config_json)
    else:
        cfg_path = Path(adapter_config_json).expanduser().resolve()
        if not cfg_path.is_file():
            raise FileNotFoundError(f"adapter_config.json not found: {cfg_path}")
        cfg_text = cfg_path.read_text()
        # Validate it parses; the server will revalidate but failing here
        # gives a faster diagnostic.
        try:
            parsed_cfg = json.loads(cfg_text)
        except json.JSONDecodeError as e:
            raise ValueError(f"adapter_config.json is not valid JSON: {e}") from e
        if not isinstance(parsed_cfg, dict):
            raise ValueError("adapter_config.json must be a JSON object")

    # 1) Get pre-signed Convex storage upload URL.
    upload_url_payload = convex_mutation(
        "models:beginDirectUpload",
        {},
        url=convex_url,
    )
    if not isinstance(upload_url_payload, dict) or not upload_url_payload.get("ok"):
        raise RuntimeError(
            f"Could not generate upload URL: {upload_url_payload!r}",
        )
    upload_url = upload_url_payload["uploadUrl"]

    # 2) POST the adapter bytes to the storage URL.
    with adapter_path.open("rb") as f:
        body = f.read()
    req = _urllib_request.Request(
        upload_url,
        data=body,
        method="POST",
        headers={"Content-Type": "application/octet-stream"},
    )
    try:
        with _urllib_request.urlopen(req, timeout=600.0) as response:
            raw = response.read().decode("utf-8")
    except _urllib_error.HTTPError as exc:  # pragma: no cover - network
        raw = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(
            f"Convex storage upload failed: {exc.code} {raw}",
        ) from exc
    parsed = json.loads(raw)
    storage_id = parsed.get("storageId")
    if not storage_id:
        raise RuntimeError(f"Convex storage upload returned no storageId: {parsed!r}")

    # 3) Trigger the prepare worker.
    args: dict[str, Any] = {
        "apiKey": resolve_api_key(api_key),
        "storageId": storage_id,
        "name": name,
        "adapterConfigJson": cfg_text,
    }
    payload = convex_action(
        "publicApi:uploadModelDirect",
        args,
        url=convex_url,
    )
    if not isinstance(payload, dict):
        raise RuntimeError(f"Unexpected Convex model response: {payload!r}")
    return payload


def list_models(
    *,
    convex_url: str | None = None,
    api_key: str | None = None,
) -> dict[str, Any]:
    """List customer models visible to the API key."""
    payload = convex_call(
        "query",
        "models:listWithApiKey",
        {"apiKey": resolve_api_key(api_key)},
        url=convex_url,
    )
    if isinstance(payload, list):
        return {"models": payload}
    if not isinstance(payload, dict):
        raise RuntimeError(f"Unexpected Convex model response: {payload!r}")
    return payload


def get_model(
    model_id: str,
    *,
    convex_url: str | None = None,
    api_key: str | None = None,
) -> dict[str, Any]:
    """Return a single customer model visible to the API key."""
    payload = convex_call(
        "query",
        "models:getWithApiKey",
        {"apiKey": resolve_api_key(api_key), "modelId": model_id},
        url=convex_url,
    )
    if payload is None:
        return {}
    if not isinstance(payload, dict):
        raise RuntimeError(f"Unexpected Convex model response: {payload!r}")
    return payload


def delete_model(
    model_id: str,
    *,
    convex_url: str | None = None,
    api_key: str | None = None,
) -> dict[str, Any]:
    """Request deletion of a customer model (cma-10).

    Flips the model row to ``status="deleting"`` and queues the Modal Volume
    directory for cleanup by the Convex GC cron. The call is idempotent:
    re-deleting a row already marked deleting returns
    ``{"ok": False, "reason": "already_deleting"}``.
    """
    payload = convex_action(
        "publicApi:deleteModel",
        {"apiKey": resolve_api_key(api_key), "modelId": model_id},
        url=convex_url,
    )
    if not isinstance(payload, dict):
        raise RuntimeError(f"Unexpected Convex model response: {payload!r}")
    return payload
