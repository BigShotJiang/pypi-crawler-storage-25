"""Client helpers for binding API keys to customer models."""

from __future__ import annotations

from typing import Any

from ._convex import convex_action
from ._transport import api_key as resolve_api_key


def bind_key_to_model(
    key_id: str,
    model_id: str | None,
    *,
    convex_url: str | None = None,
    api_key: str | None = None,
) -> dict[str, Any]:
    """Bind an API key to a customer model (or unbind when ``model_id`` is None).

    Invokes ``publicApi:bindKeyToModel`` on Convex. Pass a model id to route
    inference for ``key_id`` to that customer model; pass ``None`` to clear the
    binding and fall back to the default model.
    """
    args: dict[str, Any] = {
        "apiKey": resolve_api_key(api_key),
        "keyId": key_id,
        "modelId": model_id,
    }
    payload = convex_action(
        "publicApi:bindKeyToModel",
        args,
        url=convex_url,
    )
    if not isinstance(payload, dict):
        raise RuntimeError(f"Unexpected Convex key bind response: {payload!r}")
    return payload
