"""WebRTC DataChannel inference transport for `reflex connect`.

Speaks the Reflex MolmoAct2 WebRTC worker protocol:
  - one-shot SDP exchange via HTTPS POST to <url>/webrtc-offer
  - per-call observation sent as msgpack over the SCTP DataChannel
  - action chunk returned synchronously per call

Wraps the bundled ``_webrtc_client.WebRTCClient`` (vendored from
clients/yam_cli/) so the existing inference loop in connect_runner.py can
target a Modal-hosted MolmoAct2 worker the same way it targets a local
edge HTTP server.

Use case: the YAM bimanual rig pointing at our Modal worker for
~94ms-server / ~200ms-RTT inference instead of the local Thor edge
server (~372ms server, but ~7ms LAN).

Optional dependencies — aiortc, av, msgpack, numpy, Pillow — ship in the
``reflex-sdk[webrtc]`` extra. ``reflex.transports.__init__`` resolves this
module lazily, so users who only use the edge or platform transports never
pay the aiortc import cost.
"""

from __future__ import annotations

import asyncio
import io
import os
import sys
import threading
from pathlib import Path
from typing import Any

import numpy as np
from PIL import Image

from reflex.connectors.base import ActionChunk
from reflex.transports.base import InferenceRequest, Transport


def _maybe_prefer_monorepo_client() -> None:
    """Optionally shadow the vendored client with a monorepo checkout.

    The SDK ships its own copy of ``webrtc_client`` / ``webrtc_streaming_client``
    as private modules (``reflex.transports._webrtc_client`` etc.) so pip-install
    users do not need a monorepo on disk. Monorepo developers who want live
    edits in ``clients/yam_cli/`` to take effect without reinstalling the SDK
    can set ``REFLEX_YAM_CLI_DIR=/path/to/reflex/clients/yam_cli`` — we'll prepend
    it to ``sys.path`` so the bare-name imports below resolve to the live files
    instead of the vendored copies.
    """
    override = os.environ.get("REFLEX_YAM_CLI_DIR", "").strip()
    if not override:
        return
    candidate = Path(override).expanduser().resolve()
    if not (candidate.is_dir() and (candidate / "webrtc_client.py").is_file()):
        raise RuntimeError(
            f"REFLEX_YAM_CLI_DIR={override!r} does not contain webrtc_client.py"
        )
    if str(candidate) not in sys.path:
        sys.path.insert(0, str(candidate))


class WebRTCTransport(Transport):
    """Reflex MolmoAct2 WebRTC DataChannel transport.

    Config (passed via target.* in the connect YAML):
      url: str                    — base https://...modal.direct URL of the worker
      timeout_s: float = 60.0     — per-call inference timeout
      connect_timeout_s: float = 60.0 — initial SDP exchange timeout
      img_size: int = 256         — resize cameras to (img_size, img_size) before send
      camera_field_map: dict      — channel → MolmoAct2 image key (default top/left/right)
      state_field: str = "state"
      instruction_field: str = "prompt"
      extra_payload: dict         — merged into every inference call (e.g. num_steps)
      streaming: bool = False     — use StreamingWebRTCClient instead (sustained DataChannel)
    """

    kind = "webrtc"

    def __init__(
        self,
        url: str,
        timeout_s: float = 60.0,
        connect_timeout_s: float = 60.0,
        img_size: int = 256,
        camera_field_map: dict[str, str] | None = None,
        state_field: str = "state",
        instruction_field: str = "prompt",
        extra_payload: dict[str, Any] | None = None,
        streaming: bool = False,
        auth_token: str | None = None,
    ) -> None:
        self._url = url.rstrip("/")
        self._auth_token = (auth_token or "").strip() or None
        self._timeout = float(timeout_s)
        self._connect_timeout = float(connect_timeout_s)
        self._img_size = int(img_size)
        self._cam_map = dict(
            camera_field_map
            if camera_field_map
            else {"top": "top", "left": "left", "right": "right"}
        )
        self._state_field = state_field
        self._instruction_field = instruction_field
        self._extra = dict(extra_payload or {})
        self._streaming = bool(streaming)
        self._client: Any = None
        self._loop: asyncio.AbstractEventLoop | None = None
        self._thread: threading.Thread | None = None

    # ------- lifecycle ---------------------------------------------------

    def start(self) -> None:
        prefer_monorepo = bool(os.environ.get("REFLEX_YAM_CLI_DIR", "").strip())
        _maybe_prefer_monorepo_client()
        if self._streaming:
            if prefer_monorepo:
                from webrtc_streaming_client import StreamingWebRTCClient as Cls  # type: ignore
            else:
                from reflex.transports._webrtc_streaming_client import (
                    StreamingWebRTCClient as Cls,
                )
        else:
            if prefer_monorepo:
                from webrtc_client import WebRTCClient as Cls  # type: ignore
            else:
                from reflex.transports._webrtc_client import WebRTCClient as Cls

        # Spin up a dedicated event loop in a background thread so the sync
        # `infer()` API can hand work to the async client.
        self._loop = asyncio.new_event_loop()
        ready = threading.Event()

        def _runner() -> None:
            asyncio.set_event_loop(self._loop)
            ready.set()
            self._loop.run_forever()

        self._thread = threading.Thread(target=_runner, name="webrtc-tx", daemon=True)
        self._thread.start()
        ready.wait(timeout=5.0)

        # PROD.2: pass HMAC session token if we authorized via Convex first
        client_kwargs = {"signaling_url": self._url}
        if self._auth_token:
            client_kwargs["auth_token"] = self._auth_token
        self._client = Cls(**client_kwargs)
        fut = asyncio.run_coroutine_threadsafe(
            self._client.connect(timeout=self._connect_timeout), self._loop
        )
        # The client owns the deadline (signaling cold-wake + ICE share one
        # budget = connect_timeout). +30s slack here lets an in-flight urllib
        # POST in an executor thread unwind its TCP timeout naturally after
        # the inner coroutine cancels — avoids a bare TimeoutError leaking up
        # while the inner is in the middle of raising its own diagnostic one.
        fut.result(timeout=self._connect_timeout + 30.0)

    def stop(self) -> None:
        if self._client is not None and self._loop is not None:
            try:
                fut = asyncio.run_coroutine_threadsafe(self._client.close(), self._loop)
                fut.result(timeout=5.0)
            except Exception:
                pass
        if self._loop is not None:
            self._loop.call_soon_threadsafe(self._loop.stop)
        if self._thread is not None:
            self._thread.join(timeout=2.0)
        self._client = None
        self._loop = None
        self._thread = None

    # ------- inference ---------------------------------------------------

    def infer(self, request: InferenceRequest) -> ActionChunk:
        if self._client is None or self._loop is None:
            raise RuntimeError("WebRTCTransport.start() must be called before infer()")

        obs = request.observation
        observation: dict[str, Any] = {
            self._state_field: list(obs.state),
            self._instruction_field: obs.task,
            "images": self._encode_images(obs.cameras),
        }
        observation.update(self._extra)

        fut = asyncio.run_coroutine_threadsafe(
            self._client.infer(observation, timeout=self._timeout), self._loop
        )
        response = fut.result(timeout=self._timeout + 5.0)

        actions_raw = response.get("actions_aloha") or response.get("actions_pi") or response.get("actions")
        if actions_raw is None:
            raise RuntimeError(
                f"WebRTC response missing actions. Top-level keys: {list(response)[:10]}"
            )
        if hasattr(actions_raw, "tolist"):
            actions_raw = actions_raw.tolist()

        actions = _normalize_actions(actions_raw)
        meta = {k: v for k, v in response.items() if k not in ("actions", "actions_pi", "actions_aloha")}
        return ActionChunk(actions=actions, metadata=meta)

    # ------- helpers -----------------------------------------------------

    def _encode_images(self, cameras: dict[str, Any]) -> dict[str, bytes]:
        """JPEG-encode each camera frame at img_size×img_size.

        MolmoAct2 worker expects:
          {top: <jpeg bytes>, left: <jpeg bytes>, right: <jpeg bytes>}
        """
        out: dict[str, bytes] = {}
        for channel, key in self._cam_map.items():
            if channel not in cameras:
                continue
            frame = cameras[channel]
            jpeg = _to_jpeg(frame, self._img_size)
            out[key] = jpeg
        return out


# Per-camera SCTP-safe budget. WebRTC DataChannel ~64KB max msg, 3 cams +
# state + state-vec; budget each cam to ~18KB so 3 cams + overhead fit.
ADAPTIVE_BUDGET_BYTES = 12000


def _to_jpeg(frame: Any, size: int, quality: int = 95) -> bytes:
    """Coerce frame to JPEG bytes, resized to (size, size) for DataChannel fit.

    WebRTC SCTP DataChannel has a ~256KB max message size in aiortc. Sending
    native 640x480 q=95 (~150KB per cam x 3 = 500KB) silently closes the
    channel. Resize to (size, size) keeps the per-frame payload ~30-50KB
    so all 3 cams + state fit comfortably in one DataChannel message.

    The server-side adapter (`_square`) ALSO resizes to (img_size, img_size)
    so we lose no quality vs server-side-only resize at the same target size.
    Keeping quality=95 (was 85 historically) for better JPEG fidelity.
    """
    if isinstance(frame, (bytes, bytearray)):
        return bytes(frame)
    if isinstance(frame, np.ndarray):
        if frame.ndim != 3:
            raise RuntimeError(f"frame ndarray must be HWC, got shape {frame.shape}")
        # Assume BGR (OpenCV/RealSense default); flip channels for PIL.
        rgb = frame[..., ::-1] if frame.shape[-1] == 3 else frame
        img = Image.fromarray(np.ascontiguousarray(rgb), mode="RGB")
    elif hasattr(frame, "save"):  # PIL.Image
        img = frame
    else:
        raise RuntimeError(f"unsupported frame type: {type(frame).__name__}")

    if img.size != (size, size):
        img = img.resize((size, size), Image.LANCZOS)
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=quality)
    out = buf.getvalue()
    # Adaptive shrink: if scene complex enough to exceed SCTP budget at q=95,
    # iteratively drop quality. Bench shows q=85 still PSNR ~36dB (transparent).
    if len(out) > ADAPTIVE_BUDGET_BYTES and quality > 70:
        for q in (90, 85, 80, 75, 70):
            buf2 = io.BytesIO()
            img.save(buf2, format="JPEG", quality=q)
            if len(buf2.getvalue()) <= ADAPTIVE_BUDGET_BYTES:
                return buf2.getvalue()
        return buf2.getvalue()  # best we could do
    return out


def _normalize_actions(value: Any) -> list[list[float]]:
    """Coerce action payload into a 2-D list-of-floats."""
    if not isinstance(value, (list, tuple)):
        raise RuntimeError(f"actions must be a list, got {type(value).__name__}")
    if not value:
        return []
    if not isinstance(value[0], (list, tuple)):
        return [[float(x) for x in value]]
    return [[float(x) for x in row] for row in value]


__all__ = ["WebRTCTransport"]
