# AUTO-WAKE-PATCH applied: _wake_cold_modal_worker
"""WebRTC inference client — establish one peer connection, send many calls.

Connects to the Modal webrtc worker via:
  1. HTTPS POST /webrtc-offer with our SDP offer  (one-time)
  2. Server returns SDP answer
  3. We establish DataChannel + send inference requests over UDP

After step 3, every inference call is just a UDP datagram + reply.
No more HTTPS, no more TLS handshake, no more HTTP framing.

Usage as library:
    from webrtc_client import WebRTCClient

    async def main():
        client = WebRTCClient(signaling_url="https://...modal.direct")
        await client.connect()
        result = await client.infer({"prompt": "...", "state": [...], "images": {...}})
        await client.close()

Standalone benchmark:
    python webrtc_client.py
"""
from __future__ import annotations

import asyncio
import base64
import io
import json
import os
import sys
import time
from typing import Any

import urllib.request

try:
    import msgpack  # type: ignore
    _MSGPACK_OK = True
except ImportError:
    msgpack = None  # type: ignore
    _MSGPACK_OK = False


def _use_msgpack() -> bool:
    """Enable binary msgpack wire format when available and not explicitly disabled."""
    if not _MSGPACK_OK:
        return False
    return os.environ.get("REFLEX_WIRE", "msgpack").lower() != "json"


def _use_h264_video() -> bool:
    """Auto-stream observation.images as H.264 video tracks when set.

    The bench harness (sim/bench/bench_latency.py) ships JPEG bytes inside
    every per-call payload — ~26 KB of wire per call. With this flag set the
    WebRTCClient transparently:
      * adds 3 send-only H.264 video tracks during the SDP exchange
      * on each infer() call, pushes the call's images into those tracks
      * strips images from the outgoing observation
    The server's H.264 UDS receiver reads the cached frames and feeds them
    into inference instead of the (now-empty) payload images.

    Caller doesn't need to know about it — flipping the env var is enough.
    """
    return os.environ.get("REFLEX_WEBRTC_H264", "0").lower() not in ("0", "", "false", "no")

# These imports happen lazily so the file can be imported on hosts without aiortc
def _aiortc():
    from aiortc import RTCPeerConnection, RTCSessionDescription, RTCConfiguration, RTCIceServer
    return RTCPeerConnection, RTCSessionDescription, RTCConfiguration, RTCIceServer


def _normalize_sdp_bundle(sdp: str) -> str:
    """Force all m-lines in a bundled SDP to share the same ice-ufrag /
    ice-pwd / fingerprint as the first m-line.

    aiortc generates BUNDLEd SDPs but assigns each m-line its own ICE creds
    (even though the BUNDLE attribute says they should share). webrtc-rs's
    strict parser rejects this with "multiple conflicting ice-ufrag values".
    Rewriting per-m-line credentials to match the first m-line satisfies
    webrtc-rs without breaking aiortc (which actually drives ICE at the
    transport level, not per-m-line in the SDP).
    """
    lines = sdp.split("\r\n") if "\r\n" in sdp else sdp.split("\n")
    sep = "\r\n" if "\r\n" in sdp else "\n"

    # Walk once to find the FIRST m-line's ice-ufrag / ice-pwd / fingerprints
    first_m = -1
    canonical: dict[str, list[str]] = {"ice-ufrag": [], "ice-pwd": [], "fingerprint": []}
    in_m = False
    for i, line in enumerate(lines):
        if line.startswith("m="):
            if first_m < 0:
                first_m = i
                in_m = True
            else:
                in_m = False
        elif in_m:
            for key in canonical:
                if line.startswith(f"a={key}:"):
                    canonical[key].append(line)
    if first_m < 0 or not canonical["ice-ufrag"]:
        return sdp  # nothing to normalize

    # Rewrite every subsequent m-line block: drop its own ice/fingerprint
    # lines, inject the canonical ones immediately after the m-line.
    out: list[str] = []
    skip_keys = ("a=ice-ufrag:", "a=ice-pwd:", "a=fingerprint:")
    in_first = True
    seen_first_m = False
    for i, line in enumerate(lines):
        if line.startswith("m="):
            if not seen_first_m:
                seen_first_m = True
                in_first = True
            else:
                in_first = False
            out.append(line)
            if not in_first:
                # Inject canonical ICE creds for non-first m-line
                out.extend(canonical["ice-ufrag"])
                out.extend(canonical["ice-pwd"])
                out.extend(canonical["fingerprint"])
            continue
        if not in_first and line.startswith(skip_keys):
            continue  # drop this m-line's own ice/fingerprint lines
        out.append(line)
    return sep.join(out)


def make_jpeg_camera_track(jpeg_url: str, fps: int = 30, target_size: tuple = (224, 224)):
    """Build an aiortc VideoStreamTrack that pulls JPEGs from `jpeg_url` and
    yields RGB VideoFrames at `fps`. aiortc handles the H.264 encoding +
    RTP packetization downstream.

    Designed for the Mac mini streamer at http://localhost:8090/snap{N}.
    Lazy-import keeps this file importable on hosts without aiortc/av.
    """
    import asyncio as _asyncio
    import io as _io
    import time as _time
    import urllib.request as _ur
    import numpy as _np
    from PIL import Image as _Image
    from aiortc import VideoStreamTrack
    from av import VideoFrame

    class _JPEGCameraTrack(VideoStreamTrack):
        kind = "video"

        def __init__(self):
            super().__init__()
            self._url = jpeg_url
            self._period = 1.0 / float(fps)
            self._last_fetch = 0.0
            self._tw, self._th = target_size
            self._blank = _np.zeros((self._th, self._tw, 3), dtype=_np.uint8)

        async def recv(self):
            # aiortc-managed PTS / time_base — we just match the cadence
            pts, time_base = await self.next_timestamp()

            # Hold to fps cadence (aiortc may call recv() faster than encoder
            # can keep up; pacing here avoids dropping CPU into a busy loop)
            now = _time.perf_counter()
            wait = self._period - (now - self._last_fetch)
            if wait > 0:
                await _asyncio.sleep(wait)
            self._last_fetch = _time.perf_counter()

            loop = _asyncio.get_event_loop()
            try:
                raw = await loop.run_in_executor(
                    None, lambda: _ur.urlopen(self._url, timeout=2).read()
                )
                img = _Image.open(_io.BytesIO(raw)).convert("RGB")
                w, h = img.size
                side = min(w, h)
                left, top = (w - side) // 2, (h - side) // 2
                img = img.crop((left, top, left + side, top + side)).resize(
                    (self._tw, self._th), _Image.BILINEAR
                )
                arr = _np.asarray(img)
            except Exception:
                arr = self._blank

            frame = VideoFrame.from_ndarray(arr, format="rgb24")
            frame.pts = pts
            frame.time_base = time_base
            return frame

    return _JPEGCameraTrack()


def make_static_frame_track(fps: int = 30):
    """Build a `VideoStreamTrack` whose pixel buffer is settable from the
    outside via `track.set_frame(np.ndarray)`. aiortc handles encoding +
    RTP packetization downstream, so this is the simplest way to push the
    per-call images through the H.264 transport.

    Lazy-imports keep the file usable on hosts without aiortc/av.
    """
    import asyncio as _asyncio
    import time as _time
    import numpy as _np
    from aiortc import VideoStreamTrack
    from av import VideoFrame

    class _StaticFrameTrack(VideoStreamTrack):
        kind = "video"

        def __init__(self):
            super().__init__()
            self._fps = float(fps)
            self._period = 1.0 / self._fps
            self._last_send = 0.0
            # Default to a black 224x224 frame so encoding can spin up before
            # the first real frame arrives.
            self._frame: _np.ndarray = _np.zeros((224, 224, 3), dtype=_np.uint8)

        def set_frame(self, arr: _np.ndarray) -> None:
            """Atomic reference swap — numpy arrays are immutable from aiortc's
            view (we never mutate in place). Safe to call from any thread."""
            if arr.ndim != 3 or arr.shape[2] != 3 or arr.dtype != _np.uint8:
                raise ValueError(
                    f"set_frame expects HxWx3 uint8 numpy array, got "
                    f"shape={arr.shape} dtype={arr.dtype}"
                )
            self._frame = arr

        async def recv(self):
            pts, time_base = await self.next_timestamp()
            now = _time.perf_counter()
            wait = self._period - (now - self._last_send)
            if wait > 0:
                await _asyncio.sleep(wait)
            self._last_send = _time.perf_counter()
            # Snapshot the reference once — set_frame may swap mid-encode.
            arr = self._frame
            frame = VideoFrame.from_ndarray(arr, format="rgb24")
            frame.pts = pts
            frame.time_base = time_base
            return frame

    return _StaticFrameTrack()


SIGNALING_URL_DEFAULT = (
    "https://reflex-inc--reflex-inference-webrtc-rust-webrtcrustserver.us-west.modal.direct"
)


class WebRTCClient:
    """Lightweight Python client wrapping aiortc for inference RPC over DataChannel."""

    # Ordered list of obs-image short keys that map to video-track
    # indices 0, 1, 2 — matches CAM_IDX_TO_KEY in both webrtc workers
    # (top/left/right for molmoact, cam_high/cam_left_wrist/cam_right_wrist
    # for pi05). The first key that's present in the per-call obs.images
    # dict wins each slot, so a bench that ships either naming scheme
    # works without changes.
    _H264_CAM_KEY_PRIORITY: tuple[tuple[str, ...], ...] = (
        ("top", "cam_high", "image"),
        ("left", "cam_left_wrist", "image2"),
        ("right", "cam_right_wrist"),
    )

    def __init__(
        self,
        signaling_url: str = SIGNALING_URL_DEFAULT,
        *,
        auth_token: str | None = None,
    ):
        self.signaling_url = signaling_url.rstrip("/")
        # PROD.1.cli: when present, sent as `Authorization: Bearer <token>`
        # on the /webrtc-offer POST. The Modal worker HMAC-validates it
        # offline before accepting the SDP exchange.
        self.auth_token = (auth_token or "").strip() or None
        self.pc = None
        self.channel = None
        self.session_id: str | None = None
        self._pending: dict[str, asyncio.Future] = {}
        self._connected = asyncio.Event()
        self._closed = False
        # H.264 video tracks (Phase A of the bandwidth optimization). If any
        # are registered here BEFORE connect(), they'll be attached to the
        # peer connection during negotiation, observations can omit images,
        # and the server reads frames from its H.264 cache instead.
        self._video_tracks: list = []
        # When REFLEX_WEBRTC_H264=1, create ONE settable-frame track that
        # carries all 3 cameras packed horizontally (top | left | right) as
        # a single video frame. The server splits the strip server-side
        # (workers/inference-modal/app_molmoact_webrtc.py:_start_video_uds_server).
        #
        # Why one track and not three: with the current webrtc-rs (0.x) server,
        # negotiating 3+ BUNDLE'd m-lines reliably fails ICE — see re-xon. A
        # single-track strip sidesteps the issue and still cuts the per-call
        # payload from 26KB+ to <1KB (the JPEG-encode + msgpack cost
        # disappears, only the strip image is on the H.264 transport).
        self._h264_auto = _use_h264_video()
        self._h264_static_tracks: list = []
        if self._h264_auto:
            # 10fps default: keeps the server's per-frame PIL resize +
            # cache update off the inference hot path while still giving
            # 100ms cache freshness (well under the 240ms per-inference
            # window on BimanualYAM). On the re-cfq bench, 30fps left a
            # 6ms server-side regression (CPU contention on the decode
            # thread); 10fps clears that, brings RTT p50 to 275ms vs
            # the 280ms gate, with the JPEG-payload baseline at 350ms.
            tr = make_static_frame_track(fps=int(os.environ.get("REFLEX_WEBRTC_H264_FPS", "10")))
            self._video_tracks.append(tr)
            self._h264_static_tracks.append(tr)

    def add_video_track(self, track) -> None:
        """Register a `aiortc.VideoStreamTrack` (or subclass) to send to the
        server. Order matters: track index 0 → cam_high, 1 → cam_left_wrist,
        2 → cam_right_wrist. Must be called BEFORE connect().
        """
        if self.pc is not None:
            raise RuntimeError("add_video_track must be called before connect()")
        self._video_tracks.append(track)

    @property
    def h264_active(self) -> bool:
        """True iff video tracks have been registered (server will use cache)."""
        return bool(self._video_tracks)

    async def _poll_ready(
        self,
        deadline: float,
        loop: asyncio.AbstractEventLoop,
    ) -> bool:
        """Long-poll ``GET /ready`` until the worker reports ready or deadline hits.

        Returns ``True`` if the worker confirmed readiness (HTTP 200), ``False``
        if the endpoint doesn't exist (HTTP 404 — older worker) or the deadline
        was exhausted. In the False case the caller should fall back to the
        cold-wake retry loop on ``POST /webrtc-offer``.

        The worker is expected to hold each request open up to ``max_wait_s``
        before returning 503; we hand it most of the remaining budget so a
        single round-trip usually suffices.
        """
        ready_headers: dict[str, str] = {}
        if self.auth_token:
            ready_headers["authorization"] = f"Bearer {self.auth_token}"

        def _do_get(url: str, per_attempt_timeout: float) -> int:
            req = urllib.request.Request(url, method="GET", headers=ready_headers)
            try:
                with urllib.request.urlopen(req, timeout=per_attempt_timeout) as r:
                    r.read()
                    return r.status
            except urllib.error.HTTPError as exc:
                return exc.code

        first = True
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return False
            # Ask the server to hold the response for most of our remaining
            # budget; cap at 110s so we stay under typical edge idle timeouts.
            server_wait = max(1, min(int(remaining), 110))
            url = f"{self.signaling_url}/ready?max_wait_s={server_wait}"
            client_wait = min(remaining, float(server_wait) + 5.0)
            try:
                code = await loop.run_in_executor(None, _do_get, url, client_wait)
            except (urllib.error.URLError, TimeoutError):
                # Edge/transient — try again until deadline.
                if first:
                    first = False
                    print(
                        f"[webrtc-client] /ready unreachable — retrying, "
                        f"budget {deadline - time.monotonic():.0f}s...",
                        flush=True,
                    )
                await asyncio.sleep(min(2.0, max(0.0, deadline - time.monotonic())))
                continue
            if code == 200:
                return True
            if code == 404:
                # Older worker without /ready — caller falls back to retry on /webrtc-offer.
                return False
            # 503 = "still cold-starting"; loop back and call again.
            if first:
                first = False
                print(
                    f"[webrtc-client] worker waking (HTTP {code} on /ready) — "
                    f"holding for ready signal, budget {deadline - time.monotonic():.0f}s...",
                    flush=True,
                )
            # Defensive: a properly-implemented /ready holds the connection
            # for `max_wait_s` so this branch is rare. If the server returns
            # 503 immediately (older or buggy worker), sleep before re-asking
            # so we don't burn CPU in a tight loop.
            await asyncio.sleep(min(2.0, max(0.0, deadline - time.monotonic())))

    async def connect(self, timeout: float = 30.0) -> None:
        """One-time SDP exchange + DataChannel setup. Pays the handshake cost."""
        RTCPeerConnection, RTCSessionDescription, RTCConfiguration, RTCIceServer = _aiortc()

        self.pc = RTCPeerConnection(RTCConfiguration(iceServers=[
            RTCIceServer(urls=["stun:stun.l.google.com:19302"]),
        ]))

        # IMPORTANT: when H.264 video tracks are present we must add them
        # BEFORE createDataChannel — otherwise aiortc allocates separate
        # ICE credentials for the DataChannel m-line, and the server's
        # webrtc-rs rejects the offer with "multiple conflicting ice-ufrag
        # values". Order: tracks first, DataChannel second.
        for idx, track in enumerate(self._video_tracks):
            self.pc.addTrack(track)
            print(f"[webrtc-client] video track {idx} added ({type(track).__name__})", flush=True)

        # Open the data channel BEFORE creating the offer so it's negotiated
        self.channel = self.pc.createDataChannel("infer", ordered=True, maxRetransmits=0)


        @self.channel.on("open")
        def on_open():
            print(f"[webrtc-client] datachannel open (state={self.channel.readyState})", flush=True)
            self._connected.set()

        @self.channel.on("message")
        def on_message(message):
            try:
                if isinstance(message, (bytes, bytearray)):
                    if _MSGPACK_OK and message and message[0] != 0x7b:
                        d = msgpack.unpackb(bytes(message), raw=False)
                    else:
                        d = json.loads(message.decode("utf-8"))
                else:
                    d = json.loads(message)
            except Exception as e:
                print(f"[webrtc-client] bad message: {e}")
                return
            rid = d.get("request_id")
            fut = self._pending.pop(rid, None)
            if fut and not fut.done():
                fut.set_result(d)

        @self.channel.on("close")
        def on_close():
            print(f"[webrtc-client] datachannel closed", flush=True)
            self._closed = True

        # Create offer, send to signaling endpoint
        offer = await self.pc.createOffer()
        await self.pc.setLocalDescription(offer)

        # When we have video tracks the offer has 4 m-lines (DataChannel + 3
        # video). aiortc gathers ICE candidates asynchronously after
        # setLocalDescription — if we POST before gathering completes the
        # server gets an offer with too few candidates, ICE checking finds
        # no pair and fails. The DataChannel-only path is fast enough that
        # the race is invisible; the 4-m-line path needs an explicit wait.
        if self._video_tracks:
            gather_t0 = time.perf_counter()
            while self.pc.iceGatheringState != "complete":
                await asyncio.sleep(0.05)
                if time.perf_counter() - gather_t0 > 5.0:
                    break
            print(
                f"[webrtc-client] ice gather complete in "
                f"{(time.perf_counter()-gather_t0)*1000:.0f}ms "
                f"(state={self.pc.iceGatheringState})",
                flush=True,
            )

        # Send SDP offer over HTTPS (only HTTPS call we'll ever make).
        # Normalize BUNDLE ICE creds so webrtc-rs's strict parser accepts the
        # offer (no-op when there's only one m-line, e.g. DataChannel only).
        sdp_to_send = _normalize_sdp_bundle(self.pc.localDescription.sdp) if self._video_tracks else self.pc.localDescription.sdp
        signaling_payload = json.dumps({
            "sdp": sdp_to_send,
            "type": self.pc.localDescription.type,
        }).encode()
        signaling_headers = {"content-type": "application/json"}
        if self.auth_token:
            signaling_headers["authorization"] = f"Bearer {self.auth_token}"
        req = urllib.request.Request(
            f"{self.signaling_url}/webrtc-offer",
            data=signaling_payload,
            method="POST",
            headers=signaling_headers,
        )
        # Auto-wake cold Modal worker. Modal scales workers to zero after idle;
        # first request takes 30-90s to cold-start. Both the signaling POST and
        # the ICE wait below share a single deadline = `timeout` seconds from
        # start, so callers tune one number to govern the whole connect.
        deadline = time.monotonic() + float(timeout)
        loop = asyncio.get_event_loop()

        def _do_post(per_attempt_timeout: float) -> dict:
            with urllib.request.urlopen(req, timeout=per_attempt_timeout) as r:
                return json.loads(r.read())

        # First: long-poll GET /ready. The worker holds the connection open
        # until the inference UDS is listening (i.e. model loaded), so a single
        # `/ready` call replaces the old loop of repeatedly POSTing /webrtc-offer
        # against a cold worker. On 404 we assume an older worker without the
        # endpoint and fall back to the existing cold-wake retry loop below.
        t0 = time.perf_counter()
        ready_confirmed = await self._poll_ready(deadline, loop)

        resp: dict | None = None
        if ready_confirmed:
            # Worker reported ready — single SDP exchange, no retry loop.
            # Failures here are fatal because retrying after the worker
            # already passed readiness is unlikely to recover and would
            # only mask the real error.
            ready_remaining = max(1.0, deadline - time.monotonic())
            try:
                resp = await loop.run_in_executor(
                    None, _do_post, min(ready_remaining, 30.0)
                )
            except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError) as exc:
                raise RuntimeError(
                    f"WebRTC signaling failed after worker reported ready: {exc!r}"
                ) from exc
        else:
            # Fallback path: worker doesn't speak /ready, or /ready timed out.
            # Run the deadline-bounded cold-wake retry loop on /webrtc-offer.
            attempt = 0
            last_err: BaseException | None = None
            warned = False
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    msg = (
                        f"WebRTC signaling timeout after {time.perf_counter()-t0:.1f}s "
                        f"(budget {timeout:.0f}s)"
                    )
                    if last_err is not None:
                        raise RuntimeError(f"{msg} — last error: {last_err!r}") from last_err
                    raise RuntimeError(f"{msg} — no response from {self.signaling_url}")
                attempt += 1
                # Cap each POST at 30s so a stalled connect can't burn the whole
                # budget on one attempt — we'd rather retry sooner with feedback.
                per_attempt = min(remaining, 30.0)
                try:
                    resp = await loop.run_in_executor(None, _do_post, per_attempt)
                    last_err = None
                    break
                except urllib.error.HTTPError as exc:
                    last_err = exc
                    if exc.code not in (502, 503, 504):
                        raise
                except (urllib.error.URLError, TimeoutError) as exc:
                    last_err = exc

                if not warned:
                    warned = True
                    if isinstance(last_err, urllib.error.HTTPError):
                        print(
                            f"[webrtc-client] worker cold (HTTP {last_err.code}) — "
                            f"waking, budget {timeout:.0f}s...",
                            flush=True,
                        )
                    else:
                        print(
                            f"[webrtc-client] worker unreachable ({last_err!r}) — "
                            f"retrying, budget {timeout:.0f}s...",
                            flush=True,
                        )
                elapsed = time.perf_counter() - t0
                print(
                    f"[webrtc-client] cold-wake attempt {attempt} failed at "
                    f"{elapsed:.0f}s of {timeout:.0f}s — sleeping before retry",
                    flush=True,
                )
                sleep_for = min(10.0, max(0.0, deadline - time.monotonic()))
                if sleep_for > 0:
                    await asyncio.sleep(sleep_for)
        print(f"[webrtc-client] signaling roundtrip: {(time.perf_counter()-t0)*1000:.0f}ms", flush=True)

        await self.pc.setRemoteDescription(RTCSessionDescription(
            sdp=resp["sdp"], type=resp["type"]
        ))
        self.session_id = resp.get("session_id")

        # Wait for ICE + DTLS + DataChannel using whatever time is left in the
        # shared deadline. Floor at 1s so a near-exhausted budget still gives
        # ICE a meaningful chance instead of insta-timing-out.
        ice_remaining = max(1.0, deadline - time.monotonic())
        ice_t0 = time.perf_counter()
        try:
            await asyncio.wait_for(self._connected.wait(), timeout=ice_remaining)
            print(
                f"[webrtc-client] connected in {(time.perf_counter()-ice_t0)*1000:.0f}ms  "
                f"session={self.session_id}",
                flush=True,
            )
        except asyncio.TimeoutError:
            raise RuntimeError(
                f"WebRTC ICE/DataChannel timeout after {ice_remaining:.1f}s — "
                "likely NAT/firewall blocked direct UDP"
            )

        # H.264 keyframes can take ~500ms-1s to arrive at the server after
        # negotiation. Sleep briefly so the first measured infer() finds a
        # populated H.264 cache instead of falling back to placeholders for
        # the now-stripped payload images. Tunable for slow networks.
        if self._h264_auto and self._h264_static_tracks:
            ready_wait = float(os.environ.get("REFLEX_WEBRTC_H264_READY_S", "1.5"))
            if ready_wait > 0:
                await asyncio.sleep(ready_wait)
                print(f"[webrtc-client] h264 ready wait {ready_wait}s done", flush=True)

    def _route_images_to_h264(self, observation: dict) -> dict:
        """If H.264 auto-mode is on, push images into the static tracks and
        return an observation copy with `images` stripped.

        Mutates nothing — returns a shallow copy when images need stripping.
        No-op when H.264 mode is off, when there are no images, or when no
        track slot matches a key in the observation.
        """
        if not (self._h264_auto and self._h264_static_tracks):
            return observation
        images = observation.get("images")
        if not isinstance(images, dict) or not images:
            return observation

        import numpy as _np

        # Pack the 3 cameras (top/left/right or equivalents) into one
        # horizontal strip frame: [top | left | right]. Missing cameras get
        # a black panel of the same size. The server splits server-side.
        panels: list[_np.ndarray] = []
        any_pushed = False
        for key_options in self._H264_CAM_KEY_PRIORITY:
            val = None
            for key in key_options:
                if key in images:
                    val = images[key]
                    break
            if val is None:
                panels.append(None)
                continue
            try:
                arr = self._coerce_to_rgb_array(val)
            except Exception:
                panels.append(None)
                continue
            panels.append(arr)
            any_pushed = True

        if not any_pushed:
            return observation

        # Pick the dominant panel shape; pad missing ones with black at that
        # shape. All real panels should share the same shape in practice
        # (bench uses identical img_size for all cams).
        h = max(p.shape[0] for p in panels if p is not None)
        w = max(p.shape[1] for p in panels if p is not None)
        normalized: list[_np.ndarray] = []
        for p in panels:
            if p is None:
                normalized.append(_np.zeros((h, w, 3), dtype=_np.uint8))
            elif p.shape != (h, w, 3):
                # cheap pad / crop to (h, w) — bench cams are uniform so this
                # branch shouldn't fire in the gate harness.
                buf = _np.zeros((h, w, 3), dtype=_np.uint8)
                ih, iw = min(p.shape[0], h), min(p.shape[1], w)
                buf[:ih, :iw] = p[:ih, :iw]
                normalized.append(buf)
            else:
                normalized.append(p)
        strip = _np.concatenate(normalized, axis=1)  # shape (h, 3*w, 3)
        self._h264_static_tracks[0].set_frame(strip)

        out = dict(observation)
        out["images"] = {}
        return out

    @staticmethod
    def _coerce_to_rgb_array(val):
        """Best-effort decode of a bench image payload into a uint8 HxWx3 ndarray."""
        import io as _io
        import base64 as _b64
        import numpy as _np
        from PIL import Image as _Image

        if isinstance(val, _np.ndarray) and val.ndim == 3 and val.shape[2] == 3:
            return val.astype(_np.uint8, copy=False)

        raw: bytes | None = None
        if isinstance(val, (bytes, bytearray, memoryview)):
            raw = bytes(val)
        elif isinstance(val, dict):
            data = val.get("data")
            if isinstance(data, (bytes, bytearray, memoryview)):
                raw = bytes(data)
            elif isinstance(data, str):
                raw = _b64.b64decode(data)
        if not raw:
            raise ValueError("could not extract image bytes")
        im = _Image.open(_io.BytesIO(raw)).convert("RGB")
        return _np.asarray(im, dtype=_np.uint8)

    async def infer(self, observation: dict, request_id: str | None = None, timeout: float = 30.0) -> dict:
        """Send inference request over the open DataChannel. Awaits response.

        When msgpack is available we send binary frames with raw JPEG bytes
        (no base64). Server detects format by first byte and replies in kind.
        """
        if self.channel is None or self.channel.readyState != "open":
            raise RuntimeError("Not connected. Call connect() first.")
        rid = request_id or f"req_{time.time_ns()}"
        fut: asyncio.Future = asyncio.get_event_loop().create_future()
        self._pending[rid] = fut

        observation = self._route_images_to_h264(observation)

        if _use_msgpack():
            body = msgpack.packb(
                {"request_id": rid, "observation": observation},
                use_bin_type=True,
            )
            self.channel.send(body)
        else:
            body = json.dumps({"request_id": rid, "observation": observation})
            self.channel.send(body)
        try:
            return await asyncio.wait_for(fut, timeout=timeout)
        finally:
            self._pending.pop(rid, None)

    async def close(self):
        if self.pc is not None:
            await self.pc.close()
        self._closed = True


# ────────────────────────────────────────────────────────────────────────────
# Standalone benchmark
# ────────────────────────────────────────────────────────────────────────────

async def _benchmark(signaling_url: str, n: int = 20, warmup: int = 5):
    """A/B benchmark: WebRTC DataChannel vs HTTPS flash endpoint."""
    from PIL import Image

    def fetch_cam_resized(idx: int) -> str:
        raw = urllib.request.urlopen(f"http://localhost:8090/snap{idx}", timeout=5).read()
        im = Image.open(io.BytesIO(raw)).convert("RGB").resize((224, 224))
        buf = io.BytesIO(); im.save(buf, format="JPEG", quality=85)
        return base64.b64encode(buf.getvalue()).decode()

    def build_obs():
        b0 = fetch_cam_resized(0)
        b1 = fetch_cam_resized(1)
        return {
            "prompt": "Pick up the can and place it on the plate",
            "state": [0.0] * 7,
            "images": {
                "cam_high":        {"encoding": "jpeg_base64", "data": b0},
                "cam_left_wrist":  {"encoding": "jpeg_base64", "data": b1},
                "cam_right_wrist": {"encoding": "jpeg_base64", "data": b1},
            },
        }

    print("=" * 60)
    print("WebRTC DataChannel inference benchmark")
    print("=" * 60)

    client = WebRTCClient(signaling_url=signaling_url)
    await client.connect(timeout=30)

    # Warmup
    print(f"\nwarmup ({warmup} iters)...", flush=True)
    for i in range(warmup):
        t = time.perf_counter()
        r = await client.infer(build_obs())
        print(f"  warmup {i+1}: wall={(time.perf_counter()-t)*1000:.0f}ms  server_total={r.get('total_ms',0):.0f}ms  gpu={r.get('infer_ms',0):.0f}ms")

    # Timed
    print(f"\ntimed ({n} iters)...", flush=True)
    wall_times = []
    server_total = []
    server_gpu = []
    for i in range(n):
        obs = build_obs()
        t = time.perf_counter()
        r = await client.infer(obs)
        w = (time.perf_counter() - t) * 1000
        if "error" in r:
            print(f"  {i+1}: ERROR {r['error'][:80]}")
            continue
        wall_times.append(w)
        if r.get("total_ms"): server_total.append(r["total_ms"])
        if r.get("infer_ms"): server_gpu.append(r["infer_ms"])
        print(f"  {i+1}: wall={w:.0f}ms  server_total={r.get('total_ms',0):.0f}ms  gpu={r.get('infer_ms',0):.0f}ms")

    await client.close()

    if not wall_times:
        print("no successful calls")
        return

    def pct(vs, p):
        s = sorted(vs)
        return s[min(len(s)-1, int(round((len(s)-1)*p/100)))]

    print("\n" + "=" * 60)
    print(f"SUMMARY ({len(wall_times)} samples)")
    print("=" * 60)
    print(f"  wall    min={min(wall_times):.0f}  p50={pct(wall_times,50):.0f}  p95={pct(wall_times,95):.0f}  max={max(wall_times):.0f}")
    if server_total:
        print(f"  server  min={min(server_total):.0f}  p50={pct(server_total,50):.0f}  max={max(server_total):.0f}")
    if server_gpu:
        print(f"  gpu     min={min(server_gpu):.0f}  p50={pct(server_gpu,50):.0f}  max={max(server_gpu):.0f}")
    if server_total:
        nets = sorted([w - s for w, s in zip(wall_times, server_total)])
        print(f"  network min={nets[0]:.0f}  p50={pct(nets,50):.0f}  max={nets[-1]:.0f}")


if __name__ == "__main__":
    url = os.environ.get("REFLEX_WEBRTC_URL", SIGNALING_URL_DEFAULT)
    asyncio.run(_benchmark(url, n=20, warmup=5))
