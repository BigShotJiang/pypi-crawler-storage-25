"""Platform transport: Convex authorize + DRTC sidecar.

This wraps the same flow that the legacy ``reflex connect`` flags drive: claim
optional pairing token, authorize an inference session, start the DRTC
sidecar, and call ``drtc_client.infer`` once per control step.

Phase 1 note: this module imports helpers from :mod:`reflex.cli`. Those helpers
should move to a shared internal module in a follow-up so the CLI doesn't own
the transport plumbing.
"""

from __future__ import annotations

from typing import Any

from reflex.connectors.base import ActionChunk
from reflex.transports.base import InferenceRequest, Transport


class PlatformTransport(Transport):
    kind = "platform"

    def __init__(
        self,
        *,
        deployment: str,
        robot: str,
        mode: str = "dry_run",
        api_key: str = "",
        convex_url: str = "",
        pairing_token: str = "",
        sidecar_binary: str = "",
        allow_unchecked: bool = False,
        base_model: str = "pi0.5",
    ) -> None:
        if not deployment:
            raise ValueError("PlatformTransport requires deployment id")
        if not robot:
            raise ValueError("PlatformTransport requires robot id")
        self._deployment = deployment
        self._robot = robot
        self._mode = mode
        self._api_key = api_key
        self._convex_url = convex_url
        self._pairing_token = pairing_token
        self._sidecar_binary = sidecar_binary
        self._allow_unchecked = allow_unchecked
        self._base_model = base_model
        self._drtc_client: Any | None = None
        self._session: dict[str, Any] | None = None

    @property
    def session_id(self) -> str:
        if isinstance(self._session, dict) and isinstance(self._session.get("sessionId"), str):
            return self._session["sessionId"]
        return ""

    def start(self) -> None:
        from reflex.cli import (
            _authorize,
            _client,
            _api_key,
            _expect_public_ok,
            _require_readiness_passed,
            _start_drtc_client_from_session,
        )

        if self._mode == "apply_actions" and not self._allow_unchecked:
            _require_readiness_passed(
                deployment_id=self._deployment,
                api_key=self._api_key,
                convex_url=self._convex_url,
            )

        if self._pairing_token:
            _expect_public_ok(
                _client(self._convex_url).mutation(
                    "publicApi:claimRobotPairingToken",
                    {"apiKey": _api_key(self._api_key), "token": self._pairing_token},
                ),
                label="publicApi:claimRobotPairingToken response",
                action="Unable to claim robot pairing token",
            )

        session = _authorize(
            artifact_id="",
            deployment_id=self._deployment,
            robot_id=self._robot,
            base_model=self._base_model,
            runtime="",
            mode=self._mode,
            client_session_id="",
            api_key=self._api_key,
            convex_url=self._convex_url,
        )
        if not isinstance(session, dict):
            from reflex.product import ProductError

            raise ProductError("Session authorization did not return a session object.")
        self._session = session
        self._drtc_client = _start_drtc_client_from_session(
            session, sidecar_binary=self._sidecar_binary
        )

    def infer(self, request: InferenceRequest) -> ActionChunk:
        if self._drtc_client is None:
            raise RuntimeError("PlatformTransport.start() must be called before infer()")
        payload = {
            "session_id": self.session_id,
            "deployment_id": self._deployment,
            "robot_id": self._robot,
            "control_step": request.control_step,
            "task": request.observation.task,
            "state": request.observation.state,
            "images": request.observation.cameras,
            "observation": {
                "state": request.observation.state,
                "cameras": request.observation.cameras,
                "task": request.observation.task,
                **request.observation.extra,
            },
        }
        response = self._drtc_client.infer(payload)
        actions = _coerce_actions(response)
        return ActionChunk(actions=actions, metadata={"raw": response})

    def stop(self) -> None:
        if self._drtc_client is not None:
            self._drtc_client.close()
            self._drtc_client = None


def _coerce_actions(response: Any) -> list[list[float]]:
    """Normalize a DRTC infer response into a [T, dim] list-of-lists."""
    if response is None:
        return []
    if hasattr(response, "tolist"):
        response = response.tolist()
    if isinstance(response, dict):
        actions = response.get("actions") or response.get("action_chunk") or response.get("actions_chunk")
        if hasattr(actions, "tolist"):
            actions = actions.tolist()
        if actions is None:
            return []
        return _as_2d(actions)
    return _as_2d(response)


def _as_2d(value: Any) -> list[list[float]]:
    if not isinstance(value, (list, tuple)):
        return []
    if value and not isinstance(value[0], (list, tuple)):
        return [[float(x) for x in value]]
    return [[float(x) for x in row] for row in value]


__all__ = ["PlatformTransport"]
