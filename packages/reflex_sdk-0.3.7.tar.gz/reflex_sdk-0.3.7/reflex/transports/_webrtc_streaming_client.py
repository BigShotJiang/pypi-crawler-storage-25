"""Phase 3: WebRTC streaming inference client.

Paradigm shift vs request/response:
  - Client streams observations continuously (background asyncio task)
  - Server runs inference on every observation, pushes actions back
  - Client maintains a "latest action chunk" cache
  - Robot reads from cache on demand → cycle latency ~0ms

The Python aiortc client penalty (per-packet GIL overhead) DOES NOT MATTER
in this pattern because:
  - Sending is fire-and-forget (no wait)
  - Receiving is a background task (doesn't block the robot's main loop)
  - Robot reads a local Python dict (~1µs)

Two key metrics:
  cycle_latency  = robot's wait time when it asks for an action  (target: ~1ms)
  staleness      = action age when robot uses it                  (target: ~50ms)

Staleness = inference_loop_period + half_RTT + server_compute
          ≈ 50ms + 50ms + 20ms ≈ 120ms (with 50ms inference loop period)
          ≈  0ms + 50ms + 20ms ≈  70ms (with bottleneck-limited inference)

The lower bound on staleness is RTT_one_way + server_compute. The robot can
never see actions newer than this regardless of pattern.
"""
from __future__ import annotations

import asyncio
import base64
import io
import json
import time
import urllib.request
from collections import deque
from typing import Any, Callable, Optional

from ._webrtc_client import WebRTCClient, SIGNALING_URL_DEFAULT, _MSGPACK_OK, _use_msgpack

try:
    import msgpack  # type: ignore
except ImportError:
    msgpack = None  # type: ignore


class StreamingWebRTCClient(WebRTCClient):
    """Streaming variant — fire observations continuously, cache latest actions.

    Use case (robot control loop):

        client = StreamingWebRTCClient(signaling_url=...)
        await client.connect()
        await client.start_streaming(observation_provider, infer_period_s=0.05)

        # Now robot's loop:
        while True:
            chunk_info = client.latest_action()       # ~1µs cache read
            if chunk_info is not None:
                action = chunk_info["actions"][step]
                staleness_ms = (time.time() - chunk_info["received_at"]) * 1000
                robot.command_joint_pos(action)
            else:
                # No action received yet — wait for first chunk
                await asyncio.sleep(0.01)
    """

    def __init__(
        self,
        signaling_url: str = SIGNALING_URL_DEFAULT,
        *,
        auth_token: str | None = None,
    ):
        super().__init__(signaling_url=signaling_url, auth_token=auth_token)
        self._latest_action: Optional[dict[str, Any]] = None
        self._streaming_task: Optional[asyncio.Task] = None
        self._streaming_stop = asyncio.Event()
        # Track end-to-end latency per chunk: when sent → when received
        self._send_timestamps: dict[str, float] = {}
        self._roundtrip_history: deque = deque(maxlen=200)

    async def connect(self, timeout: float = 30.0) -> None:
        await super().connect(timeout=timeout)

        # Replace the on_message handler to update latest_action cache
        # instead of resolving pending futures.
        @self.channel.on("message")
        def on_message(message):
            try:
                if isinstance(message, (bytes, bytearray)):
                    if _MSGPACK_OK and message and message[0] != 0x7b:
                        d = msgpack.unpackb(bytes(message), raw=False)
                    else:
                        d = json.loads(message.decode("utf-8"))
                else:
                    d = json.loads(message)
            except Exception:
                return

            rid = d.get("request_id", "")
            recv_at = time.perf_counter()
            sent_at = self._send_timestamps.pop(rid, None)
            if sent_at is not None:
                rtt_ms = (recv_at - sent_at) * 1000
                self._roundtrip_history.append(rtt_ms)
                d["_rtt_ms"] = rtt_ms

            d["_received_at"] = recv_at
            self._latest_action = d

            # Also resolve any pending request/response futures (mixed mode)
            fut = self._pending.pop(rid, None)
            if fut and not fut.done():
                fut.set_result(d)

    async def start_streaming(
        self,
        observation_provider: Callable[[], Any],
        infer_period_s: float = 0.033,
    ) -> None:
        """Kick off a background loop that fires observations at `1/infer_period_s` Hz.

        observation_provider: callable that returns a fresh observation dict
                              when called. May be sync or async.
        infer_period_s:       how often to send a new observation. Default 33ms
                              (30 Hz) — server compute is ~22ms so this leaves
                              ~10ms slack. Set to 0.05 (20 Hz) for higher safety
                              margin on slower links. Env override:
                              REFLEX_INFER_PERIOD_MS=33.
        """
        import os
        env_ms = os.environ.get("REFLEX_INFER_PERIOD_MS")
        if env_ms:
            try:
                infer_period_s = float(env_ms) / 1000.0
            except ValueError:
                pass
        if self._streaming_task is not None:
            raise RuntimeError("streaming already started")

        async def _producer():
            seq = 0
            while not self._streaming_stop.is_set():
                start = time.perf_counter()
                try:
                    if asyncio.iscoroutinefunction(observation_provider):
                        obs = await observation_provider()
                    else:
                        obs = observation_provider()
                except Exception as e:
                    print(f"[streaming] observation provider error: {e}", flush=True)
                    await asyncio.sleep(infer_period_s)
                    continue
                rid = f"stream_{seq}"
                seq += 1
                self._send_timestamps[rid] = time.perf_counter()
                try:
                    if _use_msgpack():
                        self.channel.send(msgpack.packb(
                            {"request_id": rid, "observation": obs},
                            use_bin_type=True,
                        ))
                    else:
                        self.channel.send(json.dumps({
                            "request_id": rid,
                            "observation": obs,
                        }))
                except Exception as e:
                    print(f"[streaming] send error: {e}", flush=True)
                # Hold the cadence
                elapsed = time.perf_counter() - start
                wait = max(0.0, infer_period_s - elapsed)
                try:
                    await asyncio.wait_for(self._streaming_stop.wait(), timeout=wait)
                    return
                except asyncio.TimeoutError:
                    pass

        self._streaming_task = asyncio.create_task(_producer())
        print(f"[streaming] producer started at {1.0/infer_period_s:.1f} Hz inference rate", flush=True)

    def latest_action(self) -> Optional[dict[str, Any]]:
        """Return the most recent action chunk (or None if none received yet).

        This is a pure dict read — sub-microsecond. The robot calls this in
        its motor loop and doesn't block on the network.
        """
        return self._latest_action

    def staleness_ms(self) -> Optional[float]:
        """How old (in ms) is the cached action chunk?"""
        if self._latest_action is None:
            return None
        return (time.perf_counter() - self._latest_action["_received_at"]) * 1000

    def roundtrip_p50(self) -> Optional[float]:
        if not self._roundtrip_history:
            return None
        sorted_v = sorted(self._roundtrip_history)
        return sorted_v[len(sorted_v) // 2]

    async def stop_streaming(self):
        self._streaming_stop.set()
        if self._streaming_task is not None:
            try:
                await self._streaming_task
            except Exception:
                pass


# ────────────────────────────────────────────────────────────────────────────
# Phase 3 benchmark: streaming vs request/response
# ────────────────────────────────────────────────────────────────────────────

async def _phase3_benchmark(signaling_url: str, duration_s: float = 15.0, infer_period_s: float = 0.05):
    """Run a streaming session for duration_s, measure:
       1. cycle_latency = robot's perceived wait time (cache read)
       2. staleness     = how old the action is when robot uses it
       3. throughput    = how many inferences/sec we actually get
    """
    from PIL import Image

    def fetch_cam_resized(idx: int) -> str:
        raw = urllib.request.urlopen(f"http://localhost:8090/snap{idx}", timeout=5).read()
        im = Image.open(io.BytesIO(raw)).convert("RGB").resize((224, 224))
        buf = io.BytesIO(); im.save(buf, format="JPEG", quality=85)
        return base64.b64encode(buf.getvalue()).decode()

    def build_obs():
        b0 = fetch_cam_resized(0)
        b1 = fetch_cam_resized(1)
        return {
            "prompt": "Pick up the can and place it on the plate",
            "state": [0.0] * 7,
            "images": {
                "cam_high":        {"encoding": "jpeg_base64", "data": b0},
                "cam_left_wrist":  {"encoding": "jpeg_base64", "data": b1},
                "cam_right_wrist": {"encoding": "jpeg_base64", "data": b1},
            },
        }

    print("=" * 70)
    print(f"Phase 3: streaming benchmark — {duration_s:.0f}s @ {1/infer_period_s:.0f}Hz inference rate")
    print("=" * 70)

    client = StreamingWebRTCClient(signaling_url=signaling_url)
    await client.connect(timeout=30)

    await client.start_streaming(build_obs, infer_period_s=infer_period_s)

    # Robot's perspective: loop at 30Hz, read latest_action() each cycle.
    # Measure: cycle_latency (wait time for the read) and staleness.
    cycle_latencies = []
    staleness_samples = []
    received_count_history = []
    no_action_count = 0

    start_t = time.perf_counter()
    last_received_count = 0
    while True:
        t_cycle = time.perf_counter()
        if t_cycle - start_t >= duration_s:
            break

        # Simulate robot's "I want an action now" — measure how long it takes
        t_read = time.perf_counter()
        chunk = client.latest_action()
        cycle_latency_us = (time.perf_counter() - t_read) * 1e6  # in microseconds!
        cycle_latencies.append(cycle_latency_us)

        if chunk is None:
            no_action_count += 1
        else:
            staleness = client.staleness_ms()
            if staleness is not None:
                staleness_samples.append(staleness)
            current_count = len(client._roundtrip_history)
            if current_count != last_received_count:
                received_count_history.append((t_cycle - start_t, current_count))
                last_received_count = current_count

        # Robot runs at 30 Hz
        await asyncio.sleep(1.0 / 30.0)

    await client.stop_streaming()
    await client.close()

    # ──── Results ────
    def pct(vs, p):
        s = sorted(vs)
        return s[min(len(s) - 1, int(round((len(s) - 1) * p / 100)))]

    print(f"\nTotal duration:                {duration_s:.0f}s")
    print(f"Robot cycles measured:         {len(cycle_latencies)} (30 Hz)")
    print(f"Inference chunks received:     {last_received_count}")
    print(f"Effective inference rate:      {last_received_count / duration_s:.1f} Hz")
    print(f"Cycles with no action yet:     {no_action_count} (first ~{(no_action_count / 30):.1f}s of warm-up)")

    if cycle_latencies:
        print(f"\nCycle latency (robot wait time for cache read):")
        print(f"  min={min(cycle_latencies):.1f}µs  p50={pct(cycle_latencies,50):.1f}µs  p95={pct(cycle_latencies,95):.1f}µs  max={max(cycle_latencies):.1f}µs")

    if staleness_samples:
        print(f"\nStaleness (action age when robot consumes):")
        print(f"  min={min(staleness_samples):.0f}ms  p50={pct(staleness_samples,50):.0f}ms  p95={pct(staleness_samples,95):.0f}ms  max={max(staleness_samples):.0f}ms")

    if client._roundtrip_history:
        rtts = list(client._roundtrip_history)
        print(f"\nServer roundtrip (when each inference arrived):")
        print(f"  min={min(rtts):.0f}ms  p50={pct(rtts,50):.0f}ms  p95={pct(rtts,95):.0f}ms  max={max(rtts):.0f}ms")

    print("\n" + "=" * 70)
    print("KEY METRICS:")
    print("=" * 70)
    if staleness_samples and cycle_latencies:
        avg_cycle_us = sum(cycle_latencies) / len(cycle_latencies)
        median_stale_ms = pct(staleness_samples, 50)
        print(f"  Robot cycle latency:  {avg_cycle_us:.1f}µs   ★ {avg_cycle_us/1000:.2f}ms vs ~65ms HTTPS")
        print(f"  Action staleness:     {median_stale_ms:.0f}ms")
        print(f"  → A {median_stale_ms:.0f}ms-old action delivered in {avg_cycle_us/1000:.2f}ms.")


if __name__ == "__main__":
    import os
    url = os.environ.get("REFLEX_WEBRTC_URL", SIGNALING_URL_DEFAULT)
    duration = float(os.environ.get("REFLEX_BENCH_DURATION", "15"))
    period = float(os.environ.get("REFLEX_INFER_PERIOD", "0.05"))
    asyncio.run(_phase3_benchmark(url, duration_s=duration, infer_period_s=period))
