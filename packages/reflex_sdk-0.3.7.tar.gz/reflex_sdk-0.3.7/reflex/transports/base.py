"""Base interfaces for inference transports.

A transport owns the network-side of a `reflex connect` session: turning a
local Observation into an inference request, decoding the response back into
an ActionChunk, and managing any session/handshake lifecycle.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from reflex.connectors.base import ActionChunk, Observation


@dataclass
class InferenceRequest:
    observation: Observation
    control_step: int = 0
    extra: dict[str, Any] = field(default_factory=dict)


class Transport(ABC):
    """Inference-side contract for a `reflex connect` session."""

    kind: str = ""

    def start(self) -> None:
        """Open sockets, authorize sessions, spawn sidecars, etc. Default no-op."""

    @abstractmethod
    def infer(self, request: InferenceRequest) -> ActionChunk:
        """Send an observation and return the resulting action chunk."""

    def stop(self) -> None:
        """Release network resources. Default no-op."""


__all__ = ["InferenceRequest", "Transport"]
