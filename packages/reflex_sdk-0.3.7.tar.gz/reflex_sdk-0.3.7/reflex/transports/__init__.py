"""Inference transport registry."""

from __future__ import annotations

import importlib
from typing import Any, Mapping, Type

from reflex.transports.base import InferenceRequest, Transport

_BUILTIN: dict[str, str] = {
    "platform": "reflex.transports.platform:PlatformTransport",
    "edge": "reflex.transports.edge_http:EdgeHttpTransport",
    "webrtc": "reflex.transports.webrtc:WebRTCTransport",
}


def get_transport_class(kind: str) -> Type[Transport]:
    """Resolve a transport class by kind string or dotted ``module:Class`` path."""
    target = _BUILTIN.get(kind, kind)
    if ":" not in target:
        raise KeyError(
            f"Unknown transport kind: {kind!r}. "
            f"Known kinds: {sorted(_BUILTIN)} or 'pkg.module:Class' path."
        )
    module_name, class_name = target.split(":", 1)
    module = importlib.import_module(module_name)
    cls = getattr(module, class_name)
    if not (isinstance(cls, type) and issubclass(cls, Transport)):
        raise TypeError(f"{target!r} does not resolve to a Transport subclass")
    return cls


def build_transport(kind: str, config: Mapping[str, Any] | None = None) -> Transport:
    """Instantiate a transport by kind, passing ``config`` as kwargs."""
    cls = get_transport_class(kind)
    return cls(**dict(config or {}))


__all__ = [
    "InferenceRequest",
    "Transport",
    "build_transport",
    "get_transport_class",
]
