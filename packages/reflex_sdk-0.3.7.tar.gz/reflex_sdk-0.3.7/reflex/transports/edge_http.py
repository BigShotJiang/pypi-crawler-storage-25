"""Edge HTTP transport: POST observations to a self-hosted inference server.

Schema-driven so it works with any HTTP inference server, not just one model.
Every wire-format choice (field names, encoding, response path) is configurable
from YAML. The defaults are MolmoAct-compatible so existing setups work
out of the box.

Example YAML targets:

    # MolmoAct-style server (defaults already match this)
    target:
      kind: edge
      url: http://jetson:8000/act

    # OpenVLA-style server: single image, different action path
    target:
      kind: edge
      url: http://jetson:8000/predict
      state_field: proprio
      instruction_field: prompt
      camera_field_map:
        top: image
      actions_path: prediction.actions
      encoding: json
"""

from __future__ import annotations

import importlib
import time
from typing import Any

from reflex.connectors.base import ActionChunk
from reflex.transports.base import InferenceRequest, Transport


# MolmoAct-compatible defaults. Override in YAML when your server differs.
# Order matches the documented training order (top, left, right).
_DEFAULT_CAMERA_FIELD_MAP = {
    "top": "top_cam",
    "left": "left_cam",
    "right": "right_cam",
}


class EdgeHttpTransport(Transport):
    kind = "edge"

    def __init__(
        self,
        *,
        url: str,
        state_field: str = "state",
        instruction_field: str = "instruction",
        camera_field_map: dict[str, str] | None = None,
        actions_path: str = "actions",
        encoding: str = "json_numpy",
        auto_timestamp_field: str = "timestamp",
        extra_payload: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        timeout_s: float = 30.0,
    ) -> None:
        if not url:
            raise ValueError("EdgeHttpTransport requires url")
        if encoding not in ("json_numpy", "json"):
            raise ValueError(
                f"Unknown encoding {encoding!r}; expected 'json_numpy' or 'json'"
            )
        self._url = url
        self._state_field = state_field
        self._instruction_field = instruction_field
        self._camera_field_map = dict(
            camera_field_map if camera_field_map is not None else _DEFAULT_CAMERA_FIELD_MAP
        )
        self._actions_path = actions_path
        self._encoding = encoding
        self._auto_timestamp_field = auto_timestamp_field
        self._extra_payload = dict(extra_payload or {})
        self._headers = {"Content-Type": "application/json", **(headers or {})}
        self._timeout = timeout_s
        self._requests: Any | None = None
        self._json_numpy: Any | None = None

    def start(self) -> None:
        try:
            self._requests = importlib.import_module("requests")
        except ImportError as exc:
            raise RuntimeError(
                "EdgeHttpTransport requires the 'requests' package. "
                "Install with: pip install requests"
            ) from exc
        if self._encoding == "json_numpy":
            try:
                self._json_numpy = importlib.import_module("json_numpy")
                self._json_numpy.patch()
            except ImportError as exc:
                raise RuntimeError(
                    "EdgeHttpTransport encoding='json_numpy' requires the "
                    "'json_numpy' package. Install with: pip install json-numpy, "
                    "or set encoding='json' if your server speaks plain JSON."
                ) from exc

    def infer(self, request: InferenceRequest) -> ActionChunk:
        if self._requests is None:
            raise RuntimeError("EdgeHttpTransport.start() must be called before infer()")
        obs = request.observation
        payload: dict[str, Any] = {}
        if self._state_field:
            payload[self._state_field] = obs.state
        if self._instruction_field:
            payload[self._instruction_field] = obs.task
        for channel, payload_key in self._camera_field_map.items():
            if channel in obs.cameras:
                payload[payload_key] = obs.cameras[channel]
        if self._auto_timestamp_field:
            payload[self._auto_timestamp_field] = time.time()
        payload.update(self._extra_payload)

        body = self._encode(payload)
        response = self._requests.post(
            self._url,
            headers=self._headers,
            data=body,
            timeout=self._timeout,
        )
        if response.status_code != 200:
            raise RuntimeError(
                f"Edge inference server {self._url} returned "
                f"{response.status_code}: {response.text[:200]}"
            )
        data = response.json()
        actions_raw = _dig(data, self._actions_path)
        if actions_raw is None:
            raise RuntimeError(
                f"Edge inference response missing field at path {self._actions_path!r}. "
                f"Top-level keys: {list(data) if isinstance(data, dict) else type(data).__name__}"
            )
        if hasattr(actions_raw, "tolist"):
            actions_raw = actions_raw.tolist()
        return ActionChunk(actions=_normalize_actions(actions_raw), metadata={"raw": data})

    def stop(self) -> None:
        return None

    def _encode(self, payload: dict[str, Any]) -> Any:
        if self._encoding == "json_numpy" and self._json_numpy is not None:
            return self._json_numpy.dumps(payload)
        import json as _json

        return _json.dumps(payload)


def _dig(value: Any, dotted_path: str) -> Any:
    """Walk a dotted path into a nested dict; return None if any step missing."""
    current = value
    for key in dotted_path.split("."):
        if not isinstance(current, dict) or key not in current:
            return None
        current = current[key]
    return current


def _normalize_actions(value: Any) -> list[list[float]]:
    """Coerce action payload into a 2-D list-of-floats. Accepts 1-D or 2-D input."""
    if not isinstance(value, (list, tuple)):
        raise RuntimeError(f"Edge inference 'actions' must be a list, got {type(value).__name__}")
    if not value:
        return []
    if not isinstance(value[0], (list, tuple)):
        return [[float(x) for x in value]]
    return [[float(x) for x in row] for row in value]


__all__ = ["EdgeHttpTransport"]
