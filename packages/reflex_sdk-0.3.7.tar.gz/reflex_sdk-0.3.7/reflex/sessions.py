"""Hosted Reflex robot session helpers."""

from __future__ import annotations

from typing import Any

from .product import ProductClient, ProductError, expect_object, resolve_api_key


def _expect_ok(value: Any, *, action: str) -> dict[str, Any]:
    result = expect_object(value, label=f"{action} response")
    if result.get("ok") is True:
        return result
    reason = result.get("reason")
    message = result.get("message")
    detail = reason if isinstance(reason, str) and reason else message
    if not isinstance(detail, str) or not detail:
        detail = "unknown"
    raise ProductError(f"{action}: {detail}.")


def start_session(
    *,
    convex_url: str | None = None,
    api_key: str | None = None,
    artifact_id: str | None = None,
    deployment_id: str | None = None,
    robot_id: str | None = None,
    base_model: str = "pi0.5",
    runtime: str | None = None,
    mode: str = "dry_run",
    client_session_id: str | None = None,
) -> dict[str, Any]:
    if base_model != "pi0.5":
        raise ProductError("Only base model pi0.5 is supported by the product API.")
    if mode not in {"dry_run", "apply_actions"}:
        raise ProductError("mode must be dry_run or apply_actions.")
    args: dict[str, Any] = {
        "apiKey": resolve_api_key(api_key),
        "baseModel": "pi0.5",
        "mode": mode,
    }
    if artifact_id:
        args["modelId"] = artifact_id
    if deployment_id:
        args["deploymentId"] = deployment_id
    if robot_id:
        args["robotId"] = robot_id
    if runtime:
        args["runtime"] = runtime
    if client_session_id:
        args["clientSessionId"] = client_session_id
    return _expect_ok(
        ProductClient(convex_url).mutation("publicApi:authorizeSession", args),
        action="Unable to start session",
    )


def close_session(
    session_id: str,
    *,
    convex_url: str | None = None,
    api_key: str | None = None,
    reason: str = "sdk_closed",
) -> dict[str, Any]:
    return _expect_ok(
        ProductClient(convex_url).mutation(
            "publicApi:closeSession",
            {
                "apiKey": resolve_api_key(api_key),
                "sessionId": session_id,
                "reason": reason,
            },
        ),
        action="Unable to close session",
    )


def promote_session(
    session_id: str,
    *,
    convex_url: str | None = None,
    api_key: str | None = None,
    mode: str = "apply_actions",
) -> dict[str, Any]:
    if mode not in {"dry_run", "apply_actions"}:
        raise ProductError("mode must be dry_run or apply_actions.")
    return _expect_ok(
        ProductClient(convex_url).mutation(
            "publicApi:promoteSession",
            {
                "apiKey": resolve_api_key(api_key),
                "sessionId": session_id,
                "mode": mode,
            },
        ),
        action="Unable to promote session",
    )


def list_sessions(
    *,
    convex_url: str | None = None,
    api_key: str | None = None,
    status: str | None = None,
) -> dict[str, Any]:
    args: dict[str, Any] = {"apiKey": resolve_api_key(api_key)}
    if status:
        args["status"] = status
    return _expect_ok(
        ProductClient(convex_url).mutation("publicApi:listInferenceSessions", args),
        action="Unable to list sessions",
    )
