"""Package version and derived client identifiers."""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

PACKAGE_NAME = "reflex-sdk"

try:
    __version__ = version(PACKAGE_NAME)
except PackageNotFoundError:
    __version__ = "0+unknown"


def user_agent(component: str) -> str:
    return f"{component}/{__version__}"


def convex_client_header() -> str:
    return f"python-reflex-sdk-{__version__}"
