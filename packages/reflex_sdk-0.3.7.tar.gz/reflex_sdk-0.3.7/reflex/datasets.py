"""Client helpers for dataset registration and upload."""

from __future__ import annotations

from pathlib import Path
from typing import Any
from urllib import error, parse, request

from ._version import user_agent
from ._convex import convex_action
from ._transport import api_key as resolve_api_key
from ._transport import request_json

DATASETS_USER_AGENT = user_agent("reflex-datasets-sdk")


def create_dataset(
    *,
    url: str | None = None,
    api_key: str | None = None,
    name: str,
    size_bytes: int | None = None,
    request_id: str = "",
) -> dict[str, Any]:
    """Create a dataset record and return a presigned upload target."""
    payload: dict[str, Any] = {"name": name, "request_id": request_id}
    if size_bytes is not None:
        payload["size_bytes"] = size_bytes
    return request_json(
        url=url,
        api_key_value=api_key,
        path="/v1/datasets",
        payload=payload,
        user_agent=DATASETS_USER_AGENT,
    )


def list_datasets(
    *,
    url: str | None = None,
    api_key: str | None = None,
    status: str | None = None,
) -> dict[str, Any]:
    """List datasets visible to the API key."""
    path = "/v1/datasets"
    if status:
        path = f"{path}?{parse.urlencode({'status': status})}"
    return request_json(
        url=url,
        api_key_value=api_key,
        path=path,
        method="GET",
        user_agent=DATASETS_USER_AGENT,
    )


def get_dataset(
    dataset_id: str,
    *,
    url: str | None = None,
    api_key: str | None = None,
) -> dict[str, Any]:
    """Return one dataset visible to the API key."""
    return request_json(
        url=url,
        api_key_value=api_key,
        path=f"/v1/datasets/{dataset_id}",
        method="GET",
        user_agent=DATASETS_USER_AGENT,
    )


def complete_dataset(
    dataset_id: str,
    *,
    url: str | None = None,
    api_key: str | None = None,
    size_bytes: int | None = None,
) -> dict[str, Any]:
    """Mark a previously uploaded dataset ready for training."""
    payload: dict[str, Any] = {}
    if size_bytes is not None:
        payload["size_bytes"] = size_bytes
    return request_json(
        url=url,
        api_key_value=api_key,
        path=f"/v1/datasets/{dataset_id}/complete",
        payload=payload,
        user_agent=DATASETS_USER_AGENT,
    )


def upload_dataset(
    path: str | Path,
    *,
    url: str | None = None,
    api_key: str | None = None,
    name: str | None = None,
    request_id: str = "",
) -> dict[str, Any]:
    """Create, upload, and complete a dataset from a local file."""
    source = Path(path)
    data = source.read_bytes()
    created = create_dataset(
        url=url,
        api_key=api_key,
        name=name or source.name,
        size_bytes=len(data),
        request_id=request_id,
    )
    upload_url = str(created.get("upload_url") or "")
    if not upload_url:
        raise RuntimeError(f"Dataset create response did not include upload_url: {created!r}")
    req = request.Request(
        upload_url,
        data=data,
        method=str(created.get("upload_method") or "PUT"),
        headers={str(k): str(v) for k, v in dict(created.get("upload_headers") or {}).items()},
    )
    try:
        with request.urlopen(req, timeout=300):
            pass
    except error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Dataset upload failed: {exc.code} {detail}".strip()) from exc
    except error.URLError as exc:
        raise RuntimeError(f"Dataset upload failed: {exc.reason}") from exc
    dataset_id = str(created.get("dataset_id") or "")
    if not dataset_id:
        raise RuntimeError(f"Dataset create response did not include dataset_id: {created!r}")
    completed = complete_dataset(
        dataset_id,
        url=url,
        api_key=api_key,
        size_bytes=len(data),
    )
    return {**created, **completed, "dataset_id": dataset_id}


def register_huggingface_dataset(
    hf_source_uri: str,
    *,
    convex_url: str | None = None,
    api_key: str | None = None,
) -> dict[str, Any]:
    """Register a public Hugging Face LeRobot dataset through Convex."""
    payload = convex_action(
        "publicApi:registerDataset",
        {"apiKey": resolve_api_key(api_key), "hfSourceUri": hf_source_uri},
        url=convex_url,
    )
    if not isinstance(payload, dict):
        raise RuntimeError(f"Unexpected Convex dataset response: {payload!r}")
    return payload


def validate_dataset(
    dataset_id: str,
    *,
    convex_url: str | None = None,
    api_key: str | None = None,
) -> dict[str, Any]:
    """Validate a registered dataset through Convex."""
    payload = convex_action(
        "publicApi:validateDataset",
        {"apiKey": resolve_api_key(api_key), "datasetId": dataset_id},
        url=convex_url,
    )
    if not isinstance(payload, dict):
        raise RuntimeError(f"Unexpected Convex dataset response: {payload!r}")
    return payload
