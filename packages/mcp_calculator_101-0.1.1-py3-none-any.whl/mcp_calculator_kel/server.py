from mcp.server.fastmcp import FastMCP
import math

mcp = FastMCP("CalculatorService")


# 算术工具组
@mcp.tool()
def add(a: float, b: float) -> float:
    """返回a和b的和"""
    return a + b


@mcp.tool()
def sub(a: float, b: float) -> float:
    """返回a和b的差"""
    return a - b


@mcp.tool()
def mul(a: float, b: float) -> float:
    """返回a和b的积"""
    return a * b


@mcp.tool()
def div(a: float, b: float) -> float:
    """返回a和b的商"""
    if b == 0:
        raise ValueError("除数不能为零")
    return a / b


@mcp.tool()
def pow(a: float, b: float) -> float:
    """返回a的b次方"""
    return a**b


@mcp.tool()
def sqrt(a: float) -> float:
    """返回a的平方根"""
    if a < 0:
        raise ValueError("平方根的参数不能小于0")
    return math.sqrt(a)


@mcp.tool()
def factorial(n: int) -> int:
    """返回n的阶乘"""
    return math.factorial(n)


if __name__ == "__main__":
    mcp.run(transport="stdio")
