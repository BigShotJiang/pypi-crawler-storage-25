import argparse
from .server import mcp


def main():
    """MCP Wiki kel: Read Wikipedia articles and calculate the MCP."""
    parser = argparse.ArgumentParser(
        description="Gives you the ability to read Wikiped articles and convert them to Markdown."
    )
    parser.parse_args()
    mcp.run()


if __name__ == "__main__":
    main()
