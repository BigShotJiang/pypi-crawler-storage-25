from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version


def get_app_version() -> str:
    """Return the installed Governor web package version."""
    try:
        return version("governor-web")
    except PackageNotFoundError:
        return "0.0.0"
