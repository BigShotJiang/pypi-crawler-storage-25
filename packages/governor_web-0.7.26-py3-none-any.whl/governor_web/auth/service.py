from __future__ import annotations

import hashlib
import logging
import secrets
from datetime import datetime, timedelta, timezone
from typing import Optional

from sqlalchemy.orm import Session

from governor_web.auth import hashing, models
from governor_web.core.config import get_settings

logger = logging.getLogger("app.auth.service")


def _ensure_utc(dt: datetime | None) -> datetime | None:
    if dt is None:
        return dt
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


class AuthService:
    def __init__(self, db: Session) -> None:
        self.db = db
        self.settings = get_settings()

    def verify_credentials(self, password: str, password_hash: str) -> bool:
        return hashing.verify_password(password, password_hash)

    def build_session_expiry(self) -> datetime:
        return datetime.now(timezone.utc) + timedelta(
            hours=self.settings.session_ttl_hours
        )

    def find_user_by_email(self, email: str) -> Optional[models.User]:
        return (
            self.db.query(models.User).filter(models.User.email == email).one_or_none()
        )

    def authenticate(self, email: str, password: str) -> Optional[models.User]:
        user = self.find_user_by_email(email)
        if not user or user.status != "active":
            return None
        if not self.verify_credentials(password, user.password_hash):
            return None
        return user

    def create_session(
        self,
        user: models.User,
        ip_address: str | None,
        user_agent: str | None,
    ) -> models.Session:
        now = datetime.now(timezone.utc)
        session = models.Session(
            user_id=user.id,
            created_at=now,
            last_activity_at=now,
            expires_at=self.build_session_expiry(),
        )
        self.db.add(session)
        self.record_audit_event(user.id, "login", "success", ip_address, user_agent)
        self.db.commit()
        self.db.refresh(session)
        return session

    def refresh_session(self, session: models.Session) -> None:
        now = datetime.now(timezone.utc)
        refresh_interval = timedelta(
            minutes=max(1, self.settings.session_refresh_interval_minutes)
        )
        last_activity_at = _ensure_utc(session.last_activity_at)
        expires_at = _ensure_utc(session.expires_at)

        if (
            last_activity_at is not None
            and expires_at is not None
            and last_activity_at + refresh_interval > now
            and expires_at - now > refresh_interval
        ):
            return

        session.last_activity_at = now
        session.expires_at = self.build_session_expiry()
        self.db.commit()

    def revoke_session(
        self,
        session: models.Session,
        ip_address: str | None,
        user_agent: str | None,
    ) -> None:
        session.revoked_at = datetime.now(timezone.utc)
        self.record_audit_event(
            session.user_id, "logout", "success", ip_address, user_agent
        )
        self.db.commit()

    def record_audit_event(
        self,
        user_id: str | None,
        event_type: str,
        outcome: str,
        ip_address: str | None,
        user_agent: str | None,
    ) -> None:
        event = models.AuditEvent(
            user_id=user_id,
            event_type=event_type,
            outcome=outcome,
            ip_address=ip_address,
            user_agent=user_agent,
        )
        self.db.add(event)

    def cleanup_audit_events(self) -> int:
        cutoff = datetime.now(timezone.utc) - timedelta(
            days=self.settings.audit_retention_days
        )
        deleted = (
            self.db.query(models.AuditEvent)
            .filter(models.AuditEvent.event_at < cutoff)
            .delete()
        )
        self.db.commit()
        return deleted

    def revoke_other_sessions(self, user_id: str, current_session_id: str) -> int:
        """Revoke all sessions for a user except the specified session.

        Returns:
            Count of sessions revoked
        """
        now = datetime.now(timezone.utc)
        count = (
            self.db.query(models.Session)
            .filter(
                models.Session.user_id == user_id,
                models.Session.id != current_session_id,
                models.Session.revoked_at.is_(None),
            )
            .update({"revoked_at": now})
        )
        return count

    # ------------------------------------------------------------------
    # Extended audit logging (spec 107)
    # ------------------------------------------------------------------

    def record_action_audit(
        self,
        user_id: str | None,
        event_type: str,
        outcome: str,
        target_entity_type: str | None = None,
        target_entity_id: str | None = None,
        details: dict | None = None,
        ip_address: str | None = None,
        user_agent: str | None = None,
    ) -> None:
        event = models.AuditEvent(
            user_id=user_id,
            event_type=event_type,
            outcome=outcome,
            target_entity_type=target_entity_type,
            target_entity_id=target_entity_id,
            details=details,
            ip_address=ip_address,
            user_agent=user_agent,
        )
        self.db.add(event)

    # ------------------------------------------------------------------
    # Password reset (spec 107)
    # ------------------------------------------------------------------

    def generate_reset_token(self, email: str) -> str | None:
        """Generate a password reset token for the given email.

        Returns the raw token string if user exists, None otherwise.
        The same external response should be shown regardless to prevent enumeration.
        """
        user = self.find_user_by_email(email)
        if not user or user.status != "active":
            return None

        raw_token = secrets.token_urlsafe(48)
        token_hash = hashlib.sha256(raw_token.encode()).hexdigest()
        expires_at = datetime.now(timezone.utc) + timedelta(hours=1)

        reset_token = models.PasswordResetToken(
            user_id=user.id,
            token_hash=token_hash,
            expires_at=expires_at,
        )
        self.db.add(reset_token)
        self.db.commit()

        settings = get_settings()
        reset_url = f"{settings.oauth_redirect_uri.rsplit('/', 2)[0]}/reset-password/{raw_token}"
        if settings.app_env in ("development", "test"):
            logger.info("Password reset link: %s", reset_url)
        return raw_token

    def validate_reset_token(self, raw_token: str) -> models.PasswordResetToken | None:
        """Validate a password reset token. Returns the token record if valid."""
        token_hash = hashlib.sha256(raw_token.encode()).hexdigest()
        token_record = (
            self.db.query(models.PasswordResetToken)
            .filter(
                models.PasswordResetToken.token_hash == token_hash,
                models.PasswordResetToken.used_at.is_(None),
                models.PasswordResetToken.expires_at > datetime.now(timezone.utc),
            )
            .one_or_none()
        )
        return token_record

    def reset_password(self, raw_token: str, new_password: str) -> tuple[bool, str]:
        """Reset password using a valid token. Returns (success, message)."""
        token_record = self.validate_reset_token(raw_token)
        if not token_record:
            return False, "Invalid or expired reset link. Please request a new one."

        user = self.db.query(models.User).filter(models.User.id == token_record.user_id).one()
        user.password_hash = hashing.hash_password(new_password)
        token_record.used_at = datetime.now(timezone.utc)

        # Revoke all existing sessions
        self.db.query(models.Session).filter(
            models.Session.user_id == user.id,
            models.Session.revoked_at.is_(None),
        ).update({"revoked_at": datetime.now(timezone.utc)})

        self.record_audit_event(
            user.id, "password_reset", "success", None, None
        )
        self.db.commit()
        return True, "Password has been reset. Please sign in with your new password."

    # ------------------------------------------------------------------
    # User invitations (spec 107)
    # ------------------------------------------------------------------

    def send_invitation(
        self,
        email: str,
        invited_by_id: str,
        role: str = "viewer",
    ) -> tuple[bool, str, str | None]:
        """Send a user invitation. Returns (success, message, raw_token)."""
        existing = self.find_user_by_email(email)
        if existing:
            return False, "A user with this email already exists.", None

        # Check for unexpired pending invitation
        pending = (
            self.db.query(models.Invitation)
            .filter(
                models.Invitation.email == email,
                models.Invitation.accepted_at.is_(None),
                models.Invitation.expires_at > datetime.now(timezone.utc),
            )
            .one_or_none()
        )
        if pending:
            return False, "An invitation for this email is already pending.", None

        raw_token = secrets.token_urlsafe(48)
        token_hash = hashlib.sha256(raw_token.encode()).hexdigest()
        expires_at = datetime.now(timezone.utc) + timedelta(hours=72)

        invitation = models.Invitation(
            email=email,
            invited_by_id=invited_by_id,
            token_hash=token_hash,
            role=role,
            expires_at=expires_at,
        )
        self.db.add(invitation)
        self.db.commit()

        settings = get_settings()
        invite_url = f"{settings.oauth_redirect_uri.rsplit('/', 2)[0]}/invite/{raw_token}"
        if settings.app_env in ("development", "test"):
            logger.info("Invitation link for %s: %s", email, invite_url)
        return True, "Invitation sent.", raw_token

    def accept_invitation(
        self,
        raw_token: str,
        display_name: str,
        password: str,
    ) -> tuple[bool, str]:
        """Accept an invitation and create the user account."""
        token_hash = hashlib.sha256(raw_token.encode()).hexdigest()
        invitation = (
            self.db.query(models.Invitation)
            .filter(
                models.Invitation.token_hash == token_hash,
                models.Invitation.accepted_at.is_(None),
                models.Invitation.expires_at > datetime.now(timezone.utc),
            )
            .one_or_none()
        )
        if not invitation:
            return False, "Invalid or expired invitation link."

        # Double-check email not taken (race condition guard)
        if self.find_user_by_email(invitation.email):
            return False, "A user with this email already exists."

        user = models.User(
            email=invitation.email,
            display_name=display_name,
            password_hash=hashing.hash_password(password),
            status="active",
        )
        self.db.add(user)
        self.db.flush()

        # Assign role
        role = (
            self.db.query(models.Role)
            .filter(models.Role.name == invitation.role)
            .one_or_none()
        )
        if role:
            self.db.add(models.UserRole(user_id=user.id, role_id=role.id))

        invitation.accepted_at = datetime.now(timezone.utc)
        self.record_audit_event(
            user.id, "invitation_accepted", "success", None, None
        )
        self.db.commit()
        return True, "Account created. Please sign in."

    def change_password(
        self,
        user: models.User,
        current_password: str,
        new_password: str,
        current_session_id: str,
        ip_address: str | None,
        user_agent: str | None,
    ) -> tuple[bool, str | None]:
        """Change user's password, invalidate other sessions.

        Returns:
            (True, None) on success
            (False, error_message) on failure
        """
        # Verify current password
        if not self.verify_credentials(current_password, user.password_hash):
            self.record_audit_event(
                user.id, "password_change", "failure", ip_address, user_agent
            )
            self.db.commit()
            return (False, "Current password is incorrect.")

        # Update password hash
        user.password_hash = hashing.hash_password(new_password)

        # Revoke other sessions
        self.revoke_other_sessions(user.id, current_session_id)

        # Audit success
        self.record_audit_event(
            user.id, "password_change", "success", ip_address, user_agent
        )
        self.db.commit()
        return (True, None)
