from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from fastapi import Depends, HTTPException, Request, status
from sqlalchemy.orm import Session

from governor_web.core.config import get_settings
from governor_core.db.session import get_session

if TYPE_CHECKING:
    from governor_web.auth.models import Session as AuthSession, User


def get_active_session(
    request: Request, db: Session = Depends(get_session)
) -> Optional["AuthSession"]:
    from governor_web.core.config import is_local_mode

    # Local mode: auto-grant admin access without requiring login (spec 083)
    if is_local_mode():
        return _get_or_create_local_admin_session(db)

    settings = get_settings()
    session_id = request.cookies.get(settings.session_cookie_name)
    if not session_id:
        return None

    from governor_web.auth import models

    auth_session: "AuthSession | None" = (
        db.query(models.Session).filter(models.Session.id == session_id).one_or_none()
    )
    if not auth_session or auth_session.is_inactive:
        return None

    from governor_web.auth.service import AuthService

    AuthService(db).refresh_session(auth_session)
    return auth_session


def _get_or_create_local_admin_session(db: Session) -> Optional["AuthSession"]:
    """Find or create a long-lived session for the admin user in local mode."""
    from datetime import datetime, timedelta, timezone

    from governor_web.auth import models

    # Find admin user by role
    admin_user = (
        db.query(models.User)
        .join(models.User.roles)
        .filter(models.Role.name == "admin")
        .order_by(models.User.created_at.asc())
        .first()
    )
    if not admin_user:
        return None

    # Find existing active session for this user
    now = datetime.now(timezone.utc)
    existing = (
        db.query(models.Session)
        .filter(
            models.Session.user_id == admin_user.id,
            models.Session.revoked_at.is_(None),
            models.Session.expires_at > now,
        )
        .order_by(models.Session.created_at.desc())
        .first()
    )
    if existing:
        return existing

    # Create a new long-lived session (10-year TTL)
    new_session = models.Session(
        user_id=admin_user.id,
        expires_at=now + timedelta(days=3650),
    )
    db.add(new_session)
    db.commit()
    db.refresh(new_session)
    return new_session


def get_current_user(
    auth_session: "AuthSession | None" = Depends(get_active_session),
    db: Session = Depends(get_session),
) -> "User":
    if not auth_session:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)

    from governor_web.auth import models

    user: "User | None" = (
        db.query(models.User)
        .filter(models.User.id == auth_session.user_id)
        .one_or_none()
    )
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)

    return user


def get_optional_user(
    auth_session: "AuthSession | None" = Depends(get_active_session),
    db: Session = Depends(get_session),
) -> Optional["User"]:
    if not auth_session:
        return None

    from governor_web.auth import models

    return (
        db.query(models.User)
        .filter(models.User.id == auth_session.user_id)
        .one_or_none()
    )


def require_role(role_name: str):
    def _dependency(user: "User" = Depends(get_current_user)) -> "User":
        if not any(role.name == role_name for role in user.roles):
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN)
        return user

    return _dependency
