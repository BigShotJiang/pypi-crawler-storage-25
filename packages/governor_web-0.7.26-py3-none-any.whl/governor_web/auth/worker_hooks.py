"""Web-side implementation of ``governor_core.sync.worker_hooks.WorkerHooks``.

Wires up audit-event writes, organisation-settings lookups, and the sentinel
system user when the cloud web deployment runs the worker thread.
"""

from __future__ import annotations

from typing import Any

from sqlalchemy.orm import Session

from governor_core.sync.worker_hooks import WorkerHooks  # noqa: F401 (Protocol anchor)


class WebHooks:
    """Concrete ``WorkerHooks`` that uses web-owned tables."""

    _SYSTEM_EMAIL = "system@governor.internal"

    def get_auto_pr_trust_tier_threshold(self, db: Session) -> str:
        from governor_web.settings.service import OrganisationSettingsService

        return OrganisationSettingsService(db).get_value(
            "auto_pr_trust_tier_threshold", "disabled"
        )

    def find_system_user_id(self, db: Session) -> str | None:
        from governor_web.auth.models import User

        user = (
            db.query(User)
            .filter(User.email == self._SYSTEM_EMAIL)
            .one_or_none()
        )
        return user.id if user else None

    def record_audit_event(
        self,
        db: Session,
        *,
        event_type: str,
        outcome: str,
        user_id: str | None = None,
        user_agent: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        from governor_web.auth.models import AuditEvent

        audit = AuditEvent(
            user_id=user_id,
            event_type=event_type,
            outcome=outcome,
            user_agent=user_agent,
        )
        db.add(audit)
