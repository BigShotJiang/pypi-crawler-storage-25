"""Google OAuth 2.0 integration for Governor."""

from __future__ import annotations

import secrets
from urllib.parse import urlencode

import httpx

from governor_web.core.config import get_settings

_GOOGLE_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
_GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
_GOOGLE_USERINFO_URL = "https://www.googleapis.com/oauth2/v2/userinfo"


def is_oauth_configured() -> bool:
    settings = get_settings()
    return bool(settings.google_oauth_client_id and settings.google_oauth_client_secret)


def build_google_auth_url() -> tuple[str, str]:
    """Build the Google OAuth authorization URL.

    Returns:
        Tuple of (authorization_url, state_token).
    """
    settings = get_settings()
    state = secrets.token_urlsafe(32)
    params = {
        "client_id": settings.google_oauth_client_id,
        "redirect_uri": settings.oauth_redirect_uri,
        "response_type": "code",
        "scope": "openid email profile",
        "state": state,
        "access_type": "online",
        "prompt": "select_account",
    }
    return f"{_GOOGLE_AUTH_URL}?{urlencode(params)}", state


def exchange_google_code(code: str) -> dict:
    """Exchange an authorization code for tokens.

    Returns:
        Token response dict containing access_token, id_token, etc.
    """
    settings = get_settings()
    response = httpx.post(
        _GOOGLE_TOKEN_URL,
        data={
            "code": code,
            "client_id": settings.google_oauth_client_id,
            "client_secret": settings.google_oauth_client_secret,
            "redirect_uri": settings.oauth_redirect_uri,
            "grant_type": "authorization_code",
        },
        timeout=10.0,
    )
    response.raise_for_status()
    return response.json()


def get_google_user_info(access_token: str) -> dict:
    """Fetch user info from Google using an access token.

    Returns:
        Dict with keys: id, email, name, picture, etc.
    """
    response = httpx.get(
        _GOOGLE_USERINFO_URL,
        headers={"Authorization": f"Bearer {access_token}"},
        timeout=10.0,
    )
    response.raise_for_status()
    return response.json()
