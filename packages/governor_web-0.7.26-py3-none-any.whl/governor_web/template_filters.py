"""Custom Jinja2 template filters for the Governor application."""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from governor_core.sync.models import SyncOperation


def timeago(dt: datetime | None) -> str:
    """Format datetime as relative time if < 24h, else full date.

    Args:
        dt: The datetime to format, or None.

    Returns:
        A human-readable string representation of the time.
        - "Never" if dt is None
        - "Just now" if less than 60 seconds ago
        - "{n} minute(s) ago" if less than 60 minutes ago
        - "{n} hour(s) ago" if less than 24 hours ago
        - "Jan 15, 2026" format if 24 hours or older
    """
    if dt is None:
        return "Never"

    now = datetime.now(dt.tzinfo) if dt.tzinfo else datetime.now()
    delta = now - dt

    # Handle future timestamps gracefully
    if delta.total_seconds() < 0:
        return dt.strftime("%b %d, %Y")

    seconds = delta.total_seconds()

    if seconds < 60:
        return "Just now"

    if seconds < 3600:
        minutes = int(seconds / 60)
        return f"{minutes} minute{'s' if minutes != 1 else ''} ago"

    if seconds < 86400:
        hours = int(seconds / 3600)
        return f"{hours} hour{'s' if hours != 1 else ''} ago"

    return dt.strftime("%b %d, %Y")


def sync_status_label(sync: "SyncOperation") -> str:
    """Convert sync status to human-readable display label.

    Args:
        sync: A SyncOperation model instance.

    Returns:
        A human-readable status label:
        - "No New Data" for completed syncs with zero jobs and manifests
        - "Complete" for completed syncs with data
        - "Error" for failed syncs
        - "In progress" for in_progress syncs
        - "Queued" for queued syncs
    """
    if sync.status == "completed":
        jobs = sync.jobs_retrieved_count or 0
        manifests = sync.manifests_updated_count or 0
        if jobs == 0 and manifests == 0:
            return "No New Data"
        return "Complete"

    if sync.status == "failed":
        return "Error"

    if sync.status == "in_progress":
        return "In progress"

    if sync.status == "queued":
        return "Queued"

    # Fallback for any unexpected status
    return sync.status.replace("_", " ").title()
