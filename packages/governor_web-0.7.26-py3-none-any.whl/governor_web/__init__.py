"""Governor FastAPI web application — shell around governor_core.

Eagerly register web-owned ORM models on the shared Base.metadata so that
test fixtures and Alembic autogenerate see the full schema.
"""

from __future__ import annotations


def _import_web_models() -> None:
    from governor_web.auth import models as _auth  # noqa: F401
    from governor_web.notifications import models as _notif  # noqa: F401
    from governor_web.settings import models as _settings  # noqa: F401
    from governor_web.setup import models as _setup  # noqa: F401
    from governor_web.verification import models as _verify  # noqa: F401


_import_web_models()

__version__ = "0.7.0"
