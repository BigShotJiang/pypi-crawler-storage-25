from __future__ import annotations

from sqlalchemy.orm import Session

from governor_web.setup.models import SetupState


class SetupService:
    def __init__(self, db: Session) -> None:
        self._db = db

    def get_state(self) -> SetupState | None:
        return self._db.query(SetupState).first()

    def ensure_state(self, admin_user_id: str | None = None) -> SetupState:
        """Return the existing setup state for use on the settings page.

        If no state exists yet (pre-setup), create a minimal placeholder
        but do NOT mark setup as complete -- the setup wizard must still
        run for first-time installations.
        """
        state = self.get_state()
        changed = False

        if state is None:
            state = SetupState(
                admin_user_id=admin_user_id,
                is_complete=False,
                step_reached=0,
            )
            self._db.add(state)
            changed = True
        else:
            if admin_user_id and state.admin_user_id is None:
                state.admin_user_id = admin_user_id
                changed = True

        if changed:
            self._db.commit()
            self._db.refresh(state)

        return state

    def is_setup_complete(self) -> bool:
        state = self.get_state()
        return state is not None and state.is_complete

    # ------------------------------------------------------------------
    # Step writers
    # ------------------------------------------------------------------

    def create_step1(self, admin_user_id: str) -> SetupState:
        """Called after the admin user is created in step 1."""
        state = SetupState(admin_user_id=admin_user_id, step_reached=2)
        self._db.add(state)
        self._db.commit()
        self._db.refresh(state)
        return state

    def save_step2(
        self,
        gcp_credentials_json: str | None,
        auth_method: str = "json",
        installation_mode: str = "cloud",
    ) -> SetupState:
        state = self._require_state()
        state.installation_mode = installation_mode
        state.gcp_auth_method = auth_method
        state.gcp_credentials_json = gcp_credentials_json
        state.step_reached = max(state.step_reached, 3)
        self._db.commit()
        self._db.refresh(state)
        return state

    def save_step3(self, region: str) -> SetupState:
        state = self._require_state()
        state.bigquery_region = region
        state.step_reached = max(state.step_reached, 4)
        self._db.commit()
        self._db.refresh(state)
        return state

    def save_step4(
        self, app_id: str, installation_id: str, private_key: str
    ) -> SetupState:
        state = self._require_state()
        state.github_auth_mode = "app"
        state.github_app_id = app_id
        state.github_installation_id = installation_id
        state.github_private_key = private_key
        state.github_personal_access_token = None
        state.github_skipped = False
        state.step_reached = max(state.step_reached, 5)
        self._db.commit()
        self._db.refresh(state)
        return state

    def save_step4_personal_token(self, personal_access_token: str) -> SetupState:
        state = self._require_state()
        state.github_auth_mode = "personal_token"
        state.github_personal_access_token = personal_access_token
        state.github_app_id = None
        state.github_installation_id = None
        state.github_private_key = None
        state.github_skipped = False
        state.step_reached = max(state.step_reached, 5)
        self._db.commit()
        self._db.refresh(state)
        return state

    def skip_step4(self) -> SetupState:
        state = self._require_state()
        state.github_auth_mode = "disabled"
        state.github_app_id = None
        state.github_installation_id = None
        state.github_private_key = None
        state.github_personal_access_token = None
        state.github_skipped = True
        state.step_reached = max(state.step_reached, 5)
        self._db.commit()
        self._db.refresh(state)
        return state

    def save_step5(self, api_key: str) -> SetupState:
        state = self._require_state()
        state.llm_api_key = api_key
        state.llm_skipped = False
        state.step_reached = max(state.step_reached, 6)
        self._db.commit()
        self._db.refresh(state)
        return state

    def skip_step5(self) -> SetupState:
        state = self._require_state()
        state.llm_skipped = True
        state.step_reached = max(state.step_reached, 6)
        self._db.commit()
        self._db.refresh(state)
        return state

    def save_step6(self, bucket_path: str) -> SetupState:
        state = self._require_state()
        state.gcs_bucket_path = bucket_path
        state.step_reached = max(state.step_reached, 7)
        self._db.commit()
        self._db.refresh(state)
        return state

    def skip_step6(self) -> SetupState:
        state = self._require_state()
        state.gcs_skipped = True
        state.step_reached = max(state.step_reached, 7)
        self._db.commit()
        self._db.refresh(state)
        return state

    def save_installation_settings(
        self,
        *,
        installation_mode: str,
        gcp_auth_method: str,
        gcp_credentials_json: str | None,
        bigquery_region: str,
        github_auth_mode: str,
        github_app_id: str | None,
        github_installation_id: str | None,
        github_private_key: str | None,
        github_personal_access_token: str | None,
    ) -> SetupState:
        state = self._require_state()
        state.is_complete = True
        state.step_reached = max(state.step_reached, 7)
        state.installation_mode = installation_mode
        state.gcp_auth_method = gcp_auth_method
        state.gcp_credentials_json = (
            None if gcp_auth_method == "adc" else gcp_credentials_json
        )
        state.bigquery_region = bigquery_region

        state.github_auth_mode = github_auth_mode
        if github_auth_mode == "app":
            state.github_app_id = github_app_id
            state.github_installation_id = github_installation_id
            state.github_private_key = github_private_key
            state.github_personal_access_token = None
            state.github_skipped = False
        elif github_auth_mode == "personal_token":
            state.github_app_id = None
            state.github_installation_id = None
            state.github_private_key = None
            state.github_personal_access_token = github_personal_access_token
            state.github_skipped = False
        else:
            state.github_app_id = None
            state.github_installation_id = None
            state.github_private_key = None
            state.github_personal_access_token = None
            state.github_skipped = True

        self._db.commit()
        self._db.refresh(state)
        return state

    def complete(self) -> SetupState:
        state = self._require_state()
        state.is_complete = True
        self._db.commit()
        self._db.refresh(state)
        return state

    # ------------------------------------------------------------------

    def _require_state(self) -> SetupState:
        state = self.get_state()
        if state is None:
            raise RuntimeError("SetupState not found — step 1 must be completed first")
        return state
