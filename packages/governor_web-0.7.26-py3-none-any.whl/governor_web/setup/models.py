from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from governor_core.db.base import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _uuid() -> str:
    return str(uuid.uuid4())


class SetupState(Base):
    """Singleton table — at most one row.

    Tracks wizard progress and stores configuration collected during the
    first-run installation wizard.  ``is_complete = True`` permanently
    disables the /setup route.
    """

    __tablename__ = "setup_state"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    is_complete: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    # 1 = step 1 in progress, 2 = step 1 done / step 2 in progress, …, 7 = ready to finalize
    step_reached: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    installation_mode: Mapped[str] = mapped_column(
        String(16), nullable=False, default="cloud"
    )

    # Step 2: GCP auth method — "json" (service account key file) or "adc" (Workload Identity)
    gcp_auth_method: Mapped[str] = mapped_column(
        String(16), nullable=False, default="json"
    )
    # Service account JSON — populated only when gcp_auth_method == "json"
    gcp_credentials_json: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Step 3: BigQuery region
    bigquery_region: Mapped[str | None] = mapped_column(String(64), nullable=True)

    # Step 4: GitHub App (optional)
    github_auth_mode: Mapped[str] = mapped_column(
        String(32), nullable=False, default="app"
    )
    github_app_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    github_installation_id: Mapped[str | None] = mapped_column(
        String(64), nullable=True
    )
    github_private_key: Mapped[str | None] = mapped_column(Text, nullable=True)
    github_personal_access_token: Mapped[str | None] = mapped_column(
        Text, nullable=True
    )
    github_skipped: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)

    # Step 5: LLM API key (optional)
    llm_api_key: Mapped[str | None] = mapped_column(String(256), nullable=True)
    llm_skipped: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)

    # Step 6: GCS bucket path (optional)
    gcs_bucket_path: Mapped[str | None] = mapped_column(String(512), nullable=True)
    gcs_skipped: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)

    # Admin user created in step 1
    admin_user_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("users.id"), nullable=True
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, onupdate=_utcnow, nullable=False
    )
