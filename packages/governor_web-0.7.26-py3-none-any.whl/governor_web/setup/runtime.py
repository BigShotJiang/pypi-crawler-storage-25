from __future__ import annotations

import json
from dataclasses import dataclass


@dataclass(frozen=True)
class RuntimeSetupState:
    setup_complete: bool = False
    installation_mode: str = "cloud"
    gcp_auth_method: str | None = None
    gcp_credentials_json: str | None = None
    bigquery_region: str | None = None
    github_auth_mode: str | None = None
    github_app_id: str | None = None
    github_installation_id: str | None = None
    github_private_key: str | None = None
    github_personal_access_token: str | None = None
    llm_api_key: str | None = None


@dataclass(frozen=True)
class ResolvedGitHubConfig:
    auth_mode: str
    source: str
    app_id: str | None = None
    installation_id: str | None = None
    private_key: str | None = None
    personal_access_token: str | None = None


_runtime_state = RuntimeSetupState()


def set_runtime_setup_state(state: RuntimeSetupState) -> None:
    global _runtime_state
    _runtime_state = state


def clear_runtime_setup_state() -> None:
    set_runtime_setup_state(RuntimeSetupState())


def get_runtime_setup_state() -> RuntimeSetupState:
    return _runtime_state


def get_runtime_installation_mode() -> str:
    return _runtime_state.installation_mode or "cloud"


def get_runtime_bigquery_region() -> str:
    from governor_core.core.config import get_settings

    settings = get_settings()
    return _runtime_state.bigquery_region or settings.bigquery_region


def resolve_gcp_credentials():
    import google.auth
    from google.oauth2 import service_account

    if (
        _runtime_state.setup_complete
        and _runtime_state.gcp_auth_method == "json"
        and _runtime_state.gcp_credentials_json
    ):
        info = json.loads(_runtime_state.gcp_credentials_json)
        credentials = service_account.Credentials.from_service_account_info(
            info,
            scopes=["https://www.googleapis.com/auth/cloud-platform"],
        )
        return credentials, info.get("project_id")

    return google.auth.default(
        scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )


def get_runtime_llm_api_key() -> str | None:
    from governor_core.core.config import get_settings

    settings = get_settings()
    return _runtime_state.llm_api_key or settings.llm_api_key


def resolve_github_configuration() -> ResolvedGitHubConfig | None:
    from governor_core.core.config import get_settings

    settings = get_settings()
    state = _runtime_state

    if state.setup_complete and state.installation_mode == "local_dev":
        if (
            state.github_auth_mode == "personal_token"
            and state.github_personal_access_token
        ):
            return ResolvedGitHubConfig(
                auth_mode="personal_token",
                source="setup_state",
                personal_access_token=state.github_personal_access_token,
            )
        if (
            state.github_auth_mode == "app"
            and state.github_app_id
            and state.github_private_key
            and state.github_installation_id
        ):
            return ResolvedGitHubConfig(
                auth_mode="app",
                source="setup_state",
                app_id=state.github_app_id,
                installation_id=state.github_installation_id,
                private_key=state.github_private_key,
            )
        return None

    if (
        state.setup_complete
        and state.github_auth_mode == "personal_token"
        and state.github_personal_access_token
    ):
        return ResolvedGitHubConfig(
            auth_mode="personal_token",
            source="setup_state",
            personal_access_token=state.github_personal_access_token,
        )

    if (
        state.setup_complete
        and state.github_auth_mode == "app"
        and state.github_app_id
        and state.github_private_key
        and state.github_installation_id
    ):
        return ResolvedGitHubConfig(
            auth_mode="app",
            source="setup_state",
            app_id=state.github_app_id,
            installation_id=state.github_installation_id,
            private_key=state.github_private_key,
        )

    if (
        settings.github_app_id
        and settings.github_app_private_key
        and settings.github_app_installation_id
    ):
        return ResolvedGitHubConfig(
            auth_mode="app",
            source="environment",
            app_id=settings.github_app_id,
            installation_id=settings.github_app_installation_id,
            private_key=settings.github_app_private_key,
        )

    return None


def is_github_configured() -> bool:
    return resolve_github_configuration() is not None


def create_github_client():
    from governor_core.github.client import GitHubAppClient, GitHubTokenClient

    config = resolve_github_configuration()
    if not config:
        return None

    if config.auth_mode == "personal_token":
        return GitHubTokenClient(token=config.personal_access_token or "")

    return GitHubAppClient(
        app_id=config.app_id or "",
        private_key=config.private_key or "",
        installation_id=config.installation_id or "",
    )
