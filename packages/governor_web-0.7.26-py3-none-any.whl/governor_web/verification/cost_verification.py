"""Compatibility re-export — CostVerificationService moved to core during spec 120."""

from governor_core.opportunities.cost_verification import CostVerificationService

__all__ = ["CostVerificationService"]
