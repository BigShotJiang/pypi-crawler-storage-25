from __future__ import annotations

import logging
import time

from google.api_core.exceptions import Forbidden, GoogleAPIError, PermissionDenied

from governor_core.gcp.clients import GCPCredentialsError, list_gcp_projects
from governor_web.verification.checks.base import CheckResult, CheckStatus, CheckType

logger = logging.getLogger("app.verification")


def run_gcp_projects_check() -> CheckResult:
    """List all accessible GCP projects to verify ADC and IAM configuration."""
    start = time.monotonic()
    try:
        projects = list_gcp_projects()

        elapsed_ms = int((time.monotonic() - start) * 1000)

        if not projects:
            return CheckResult(
                check_type=CheckType.GCP_PROJECTS,
                status=CheckStatus.FAIL,
                message="No GCP projects found. The service account has valid credentials but cannot see any projects.",
                details={"projects": [], "count": 0},
                remediation=(
                    "Grant the 'roles/browser' role to the service account "
                    "at the organization or folder level."
                ),
                duration_ms=elapsed_ms,
            )

        project_ids = [p["project_id"] for p in projects]
        return CheckResult(
            check_type=CheckType.GCP_PROJECTS,
            status=CheckStatus.PASS,
            message=f"GCP access verified. Found {len(projects)} project(s).",
            details={"projects": project_ids, "count": len(projects)},
            duration_ms=elapsed_ms,
        )

    except GCPCredentialsError:
        elapsed_ms = int((time.monotonic() - start) * 1000)
        return CheckResult(
            check_type=CheckType.GCP_PROJECTS,
            status=CheckStatus.FAIL,
            message="GCP credentials not configured.",
            remediation=(
                "Set GOOGLE_APPLICATION_CREDENTIALS to a service account JSON path, "
                "or run 'gcloud auth application-default login'."
            ),
            duration_ms=elapsed_ms,
        )

    except (PermissionDenied, Forbidden):
        elapsed_ms = int((time.monotonic() - start) * 1000)
        return CheckResult(
            check_type=CheckType.GCP_PROJECTS,
            status=CheckStatus.FAIL,
            message="Permission denied listing GCP projects.",
            remediation=(
                "Grant the 'roles/browser' role to the service account "
                "at the organization or folder level."
            ),
            duration_ms=elapsed_ms,
        )

    except (GoogleAPIError, RuntimeError, OSError) as exc:
        elapsed_ms = int((time.monotonic() - start) * 1000)
        logger.exception("Unexpected error during GCP projects check")
        return CheckResult(
            check_type=CheckType.GCP_PROJECTS,
            status=CheckStatus.ERROR,
            message=f"GCP projects check failed: {type(exc).__name__}",
            remediation="Check network connectivity and GCP service availability.",
            duration_ms=elapsed_ms,
        )
