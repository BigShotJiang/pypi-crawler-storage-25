"""GitHub App connectivity verification check."""

from __future__ import annotations

import logging
import time

from governor_web.core.config import get_settings
from governor_core.github.client import (
    GitHubAppClient,
    GitHubTokenClient,
    GitHubTokenInfo,
    GitHubAppSuspendedError,
    GitHubAuthenticationError,
    GitHubConfigurationError,
    GitHubConnectionError,
    GitHubAppInfo,
    GitHubRateLimitError,
)
from governor_web.setup.runtime import get_runtime_setup_state
from governor_web.verification.checks.base import CheckResult, CheckStatus, CheckType

logger = logging.getLogger("app.verification.github")


def run_github_check() -> CheckResult:
    """Verify GitHub App connectivity.

    Checks that the GitHub App is properly configured and can authenticate
    with the GitHub API. Returns pass/fail/skip/error status with actionable
    remediation guidance for failures.

    Returns:
        CheckResult with status, message, optional details, and remediation.
    """
    start_time = time.monotonic()
    logger.info("Starting GitHub connectivity check")

    settings = get_settings()
    runtime_state = get_runtime_setup_state()

    if (
        runtime_state.setup_complete
        and runtime_state.installation_mode == "local_dev"
        and runtime_state.github_auth_mode == "disabled"
    ):
        duration_ms = int((time.monotonic() - start_time) * 1000)
        logger.info(
            "GitHub check skipped: disabled in local dev setup (duration=%dms)",
            duration_ms,
        )
        return CheckResult(
            check_type=CheckType.GITHUB,
            status=CheckStatus.SKIP,
            message="GitHub integration is disabled in local dev setup.",
            duration_ms=duration_ms,
        )

    auth_mode = "app"
    token_value: str | None = None
    app_id: str | None = None
    private_key: str | None = None
    installation_id: str | None = None
    if (
        runtime_state.setup_complete
        and runtime_state.installation_mode == "local_dev"
        and runtime_state.github_auth_mode == "personal_token"
    ):
        token_value = runtime_state.github_personal_access_token
        if not token_value:
            duration_ms = int((time.monotonic() - start_time) * 1000)
            return CheckResult(
                check_type=CheckType.GITHUB,
                status=CheckStatus.FAIL,
                message="GitHub personal access token configuration incomplete: missing token.",
                remediation=(
                    "Provide a GitHub personal access token with repository read/write access "
                    "in setup step 4."
                ),
                duration_ms=duration_ms,
            )
        auth_mode = "personal_token"
    else:
        # Check if GitHub App is configured at all
        if not any(
            [
                settings.github_app_id,
                settings.github_app_private_key,
                settings.github_app_installation_id,
                runtime_state.github_app_id,
                runtime_state.github_private_key,
                runtime_state.github_installation_id,
            ]
        ):
            duration_ms = int((time.monotonic() - start_time) * 1000)
            logger.info(
                "GitHub check skipped: not configured (duration=%dms)", duration_ms
            )
            return CheckResult(
                check_type=CheckType.GITHUB,
                status=CheckStatus.SKIP,
                message="GitHub App not configured. Set environment variables or complete setup to enable GitHub integration.",
                duration_ms=duration_ms,
            )

        missing = []
        app_id = runtime_state.github_app_id or settings.github_app_id
        private_key = (
            runtime_state.github_private_key or settings.github_app_private_key
        )
        installation_id = (
            runtime_state.github_installation_id or settings.github_app_installation_id
        )
        if not app_id:
            missing.append("GITHUB_APP_ID")
        if not private_key:
            missing.append("GITHUB_APP_PRIVATE_KEY")
        if not installation_id:
            missing.append("GITHUB_APP_INSTALLATION_ID")

        if missing:
            duration_ms = int((time.monotonic() - start_time) * 1000)
            missing_str = ", ".join(missing)
            logger.warning(
                "GitHub check failed: missing configuration (missing=%s, duration=%dms)",
                missing_str,
                duration_ms,
            )
            return CheckResult(
                check_type=CheckType.GITHUB,
                status=CheckStatus.FAIL,
                message=f"GitHub App configuration incomplete: missing {missing_str}.",
                remediation=(
                    f"Set the following environment variable(s) or setup values: {missing_str}. "
                    "See README for GitHub App setup instructions."
                ),
                duration_ms=duration_ms,
            )

    # Attempt to verify connectivity
    try:
        client: GitHubAppClient | GitHubTokenClient
        principal: GitHubAppInfo | GitHubTokenInfo
        if auth_mode == "personal_token":
            client = GitHubTokenClient(token_value or "")
            principal = client.verify_token_connectivity()
        else:
            client = GitHubAppClient(
                app_id=app_id or "",
                private_key=private_key or "",
                installation_id=installation_id or "",
            )
            principal = client.verify_app_connectivity()

        duration_ms = int((time.monotonic() - start_time) * 1000)
        if auth_mode == "personal_token":
            logger.info(
                "GitHub token check passed: login=%s (duration=%dms)",
                principal.login,
                duration_ms,
            )
            return CheckResult(
                check_type=CheckType.GITHUB,
                status=CheckStatus.PASS,
                message=f"GitHub personal access token verified: {principal.login}",
                details={
                    "auth_mode": "personal_token",
                    "user_id": principal.id,
                    "login": principal.login,
                    "name": principal.name,
                },
                duration_ms=duration_ms,
            )

        logger.info(
            "GitHub check passed: app_id=%d, app_name=%s, owner=%s (duration=%dms)",
            principal.id,
            principal.name,
            principal.owner,
            duration_ms,
        )
        return CheckResult(
            check_type=CheckType.GITHUB,
            status=CheckStatus.PASS,
            message=f"GitHub App connectivity verified: {principal.name}",
            details={
                "auth_mode": "app",
                "app_id": principal.id,
                "app_name": principal.name,
                "app_slug": principal.slug,
                "owner": principal.owner,
            },
            duration_ms=duration_ms,
        )

    except GitHubConfigurationError as exc:
        duration_ms = int((time.monotonic() - start_time) * 1000)
        logger.warning(
            "GitHub check failed: configuration error (duration=%dms)",
            duration_ms,
        )
        return CheckResult(
            check_type=CheckType.GITHUB,
            status=CheckStatus.FAIL,
            message=f"GitHub configuration error: {exc}",
            remediation=(
                "Verify your GitHub credentials are correctly configured. "
                "For GitHub App mode, ensure the private key is PEM-encoded. "
                "For personal token mode, ensure the token is present."
            ),
            duration_ms=duration_ms,
        )

    except GitHubAuthenticationError as exc:
        duration_ms = int((time.monotonic() - start_time) * 1000)
        logger.warning(
            "GitHub check failed: authentication error (duration=%dms)",
            duration_ms,
        )
        return CheckResult(
            check_type=CheckType.GITHUB,
            status=CheckStatus.FAIL,
            message=f"GitHub App authentication failed: {exc}",
            remediation=(
                "Verify GITHUB_APP_ID matches your GitHub App. "
                "Regenerate and update GITHUB_APP_PRIVATE_KEY if the key may be incorrect. "
                "Ensure you're using the private key for the correct app."
            ),
            duration_ms=duration_ms,
        )

    except GitHubAppSuspendedError:
        duration_ms = int((time.monotonic() - start_time) * 1000)
        logger.warning(
            "GitHub check failed: app suspended (duration=%dms)",
            duration_ms,
        )
        return CheckResult(
            check_type=CheckType.GITHUB,
            status=CheckStatus.FAIL,
            message="GitHub App is suspended.",
            remediation=(
                "Reactivate your GitHub App in organization settings. "
                "Go to Settings > Developer settings > GitHub Apps > Your App > Advanced and click 'Unsuspend'."
            ),
            duration_ms=duration_ms,
        )

    except GitHubRateLimitError:
        duration_ms = int((time.monotonic() - start_time) * 1000)
        logger.warning(
            "GitHub check error: rate limited (duration=%dms)",
            duration_ms,
        )
        return CheckResult(
            check_type=CheckType.GITHUB,
            status=CheckStatus.ERROR,
            message="GitHub API rate limit exceeded.",
            remediation=(
                "Wait for the rate limit to reset (typically 1 hour) and retry. "
                "Check for other processes using the same GitHub App ID that may be consuming the rate limit."
            ),
            duration_ms=duration_ms,
        )

    except GitHubConnectionError as exc:
        duration_ms = int((time.monotonic() - start_time) * 1000)
        logger.warning(
            "GitHub check error: connection failed (duration=%dms)",
            duration_ms,
        )
        return CheckResult(
            check_type=CheckType.GITHUB,
            status=CheckStatus.ERROR,
            message=f"GitHub API connection failed: {exc}",
            remediation=(
                "Check network connectivity to api.github.com:443. "
                "Verify firewall rules allow HTTPS connections to GitHub. "
                "Test connectivity with: curl -I https://api.github.com"
            ),
            duration_ms=duration_ms,
        )

    except (RuntimeError, OSError, ValueError) as exc:
        duration_ms = int((time.monotonic() - start_time) * 1000)
        logger.exception(
            "GitHub check error: unexpected error (duration=%dms)",
            duration_ms,
        )
        return CheckResult(
            check_type=CheckType.GITHUB,
            status=CheckStatus.ERROR,
            message=f"GitHub verification failed unexpectedly: {type(exc).__name__}",
            remediation=(
                "An unexpected error occurred. Check the application logs for details. "
                "If the issue persists, verify your GitHub App configuration and network connectivity."
            ),
            duration_ms=duration_ms,
        )
