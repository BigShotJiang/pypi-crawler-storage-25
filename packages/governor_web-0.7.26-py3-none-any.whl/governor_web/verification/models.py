from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import DateTime, ForeignKey, Index, Integer, Numeric, String, Text
from sqlalchemy.dialects.postgresql import JSON, JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from governor_core.db.base import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _uuid() -> str:
    return str(uuid.uuid4())


class VerificationRun(Base):
    __tablename__ = "verification_runs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    admin_user_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("users.id"), nullable=False
    )
    started_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )
    completed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    overall_status: Mapped[str] = mapped_column(
        String(16), nullable=False, default="running"
    )
    environment: Mapped[str] = mapped_column(String(64), nullable=False)

    checks: Mapped[list["VerificationCheck"]] = relationship(
        "VerificationCheck",
        back_populates="run",
        cascade="all, delete-orphan",
        order_by="VerificationCheck.executed_at",
    )

    __table_args__ = (
        Index("ix_verification_runs_started_at", started_at.desc()),
        Index("ix_verification_runs_admin_user_id", "admin_user_id"),
    )


class VerificationCheck(Base):
    __tablename__ = "verification_checks"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    run_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("verification_runs.id", ondelete="CASCADE"),
        nullable=False,
    )
    check_type: Mapped[str] = mapped_column(String(32), nullable=False)
    status: Mapped[str] = mapped_column(String(16), nullable=False)
    message: Mapped[str] = mapped_column(Text, nullable=False)
    details: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    remediation: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    duration_ms: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    executed_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )

    run: Mapped["VerificationRun"] = relationship(
        "VerificationRun", back_populates="checks"
    )

    __table_args__ = (Index("ix_verification_checks_run_id", "run_id"),)




# CostVerificationRun moved to core during spec 120. Re-export from its new
# location so existing importers in governor_web continue to resolve it.
from governor_core.opportunities.cost_verification_models import (  # noqa: E402
    CostVerificationRun,
)
