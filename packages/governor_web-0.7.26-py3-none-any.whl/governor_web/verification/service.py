from __future__ import annotations

import logging
from datetime import datetime, timezone

from sqlalchemy.orm import Session

from governor_web.verification.checks.base import CheckResult
from governor_web.verification.models import VerificationCheck, VerificationRun
from governor_web.verification.schemas import (
    OverallStatus,
    SystemReadiness,
    SystemStatus,
    VerificationRunResult,
)

logger = logging.getLogger("app.verification")


class VerificationService:
    def __init__(self, db: Session) -> None:
        self._db = db

    def create_run(self, admin_user_id: str, environment: str) -> VerificationRun:
        """Create a new verification run in 'running' state."""
        run = VerificationRun(
            admin_user_id=admin_user_id,
            environment=environment,
            overall_status="running",
        )
        self._db.add(run)
        self._db.commit()
        self._db.refresh(run)
        return run

    def save_check_result(
        self, run: VerificationRun, result: CheckResult
    ) -> VerificationCheck:
        """Persist a single check result for a verification run."""
        check = VerificationCheck(
            run_id=run.id,
            check_type=result.check_type,
            status=result.status,
            message=result.message,
            details=result.details,
            remediation=result.remediation,
            duration_ms=result.duration_ms,
        )
        self._db.add(check)
        self._db.commit()
        self._db.refresh(check)
        return check

    def complete_run(self, run: VerificationRun, overall_status: str) -> None:
        """Mark a verification run as completed."""
        run.overall_status = overall_status
        run.completed_at = datetime.now(timezone.utc)
        self._db.commit()

    def get_run(self, run_id: str) -> VerificationRun | None:
        """Fetch a verification run by ID."""
        return (
            self._db.query(VerificationRun)
            .filter(VerificationRun.id == run_id)
            .one_or_none()
        )

    def list_runs(self, limit: int = 20) -> list[VerificationRun]:
        """List verification runs in reverse chronological order."""
        return (
            self._db.query(VerificationRun)
            .order_by(VerificationRun.started_at.desc())
            .limit(limit)
            .all()
        )

    def get_latest_completed_run(self) -> VerificationRun | None:
        """Get the most recent completed verification run."""
        return (
            self._db.query(VerificationRun)
            .filter(VerificationRun.overall_status != "running")
            .order_by(VerificationRun.started_at.desc())
            .first()
        )

    def get_system_status(self) -> SystemStatus:
        """Get simplified system readiness status."""
        latest = self.get_latest_completed_run()
        if not latest:
            return SystemStatus(status=SystemReadiness.UNKNOWN)

        if latest.overall_status == "ready":
            readiness = SystemReadiness.READY
        else:
            readiness = SystemReadiness.NOT_READY

        return SystemStatus(
            status=readiness,
            last_checked_at=latest.completed_at or latest.started_at,
        )

    def run_to_result(self, run: VerificationRun) -> VerificationRunResult:
        """Convert a VerificationRun ORM instance to a Pydantic response schema."""
        return VerificationRunResult(
            id=run.id,
            overall_status=OverallStatus(run.overall_status),
            started_at=run.started_at,
            completed_at=run.completed_at,
            environment=run.environment,
            checks=[
                CheckResult(
                    check_type=c.check_type,
                    status=c.status,
                    message=c.message,
                    details=c.details,
                    remediation=c.remediation,
                    duration_ms=c.duration_ms,
                )
                for c in run.checks
            ],
        )
