from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy.orm import Session

from governor_web.settings.models import OrganisationSetting


class OrganisationSettingsService:
    def __init__(self, db: Session) -> None:
        self._db = db

    def get(self, setting_key: str) -> OrganisationSetting | None:
        return (
            self._db.query(OrganisationSetting)
            .filter(OrganisationSetting.setting_key == setting_key)
            .one_or_none()
        )

    def get_value(self, setting_key: str, default: str) -> str:
        setting = self.get(setting_key)
        if setting is None:
            return default
        return setting.setting_value

    def set(
        self, setting_key: str, setting_value: str, user_id: str
    ) -> OrganisationSetting:
        setting = self.get(setting_key)
        if setting is None:
            setting = OrganisationSetting(
                setting_key=setting_key,
                setting_value=setting_value,
                updated_by_id=user_id,
            )
            self._db.add(setting)
        else:
            setting.setting_value = setting_value
            setting.updated_by_id = user_id
            setting.updated_at = datetime.now(timezone.utc)
        self._db.commit()
        self._db.refresh(setting)
        return setting
