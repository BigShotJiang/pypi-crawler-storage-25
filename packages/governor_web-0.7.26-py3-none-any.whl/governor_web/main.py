from __future__ import annotations

# ruff: noqa: E402

import logging
import time
from contextlib import asynccontextmanager
from pathlib import Path
from urllib.parse import urlparse
from uuid import uuid4

_PKG_DIR = Path(__file__).resolve().parent
_STATIC_DIR = str(_PKG_DIR / "static")
_TEMPLATES_DIR = str(_PKG_DIR / "templates")

from fastapi import FastAPI, Request
from fastapi.exceptions import HTTPException
from fastapi.responses import HTMLResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.requests import ClientDisconnect

from governor_core.core.config import get_settings as get_core_settings
from governor_core.core.cache import configure_cache
from governor_core.core.logging import (
    bind_request_context,
    clear_request_context,
    configure_logging,
)
from governor_core.db.session import SessionLocal, engine
from governor_core.telemetry.tracing import (
    configure_tracing,
    instrument_sqlalchemy,
)
from governor_core.utils.formatters import format_usd, set_cost_multiplier
from governor_web.core.config import get_settings
from governor_web.routes.helpers import redirect_with_message
from governor_web.routes import (
    admin,
    app as app_routes,
    auth,
    configurations,
    dashboard,
    errors,
    notifications,
    opportunities,
    public,
    pull_requests,
    queue,
    schedules,
    settings as settings_routes,
    setup as setup_routes,
    solutions_admin,
    sync,
    verification,
)
from governor_web.template_filters import sync_status_label, timeago
from governor_web.version import get_app_version


def create_app() -> FastAPI:
    settings = get_settings()
    core_settings = get_core_settings()
    app_version = get_app_version()
    configure_logging(core_settings.log_level)
    configure_cache(
        enabled=core_settings.app_env != "test",
        default_ttl=60,
    )
    if core_settings.app_env != "test":
        configure_tracing(core_settings.service_name)

    def _sidebar_activity_context(request: Request) -> dict[str, int]:
        if not request.cookies.get(settings.session_cookie_name):
            return {"sidebar_running_solutions": 0}

        from governor_core.solutions.models import SolutionJob

        db_session_factory = getattr(
            request.app.state, "db_session_factory", SessionLocal
        )
        db = db_session_factory()
        try:
            active_statuses = ("queued", "in_progress")
            count = (
                db.query(SolutionJob)
                .filter(SolutionJob.status.in_(active_statuses))
                .count()
            )
            return {"sidebar_running_solutions": count}
        finally:
            db.close()

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        import threading

        # Startup: cleanup audit events & load cost multiplier
        db = SessionLocal()
        try:
            from governor_web.auth.service import AuthService

            AuthService(db).cleanup_audit_events()

            from governor_web.settings.models import OrganisationSetting

            row = (
                db.query(OrganisationSetting)
                .filter(OrganisationSetting.setting_key == "cost_display_multiplier")
                .one_or_none()
            )
            if row:
                try:
                    set_cost_multiplier(float(row.setting_value))
                except ValueError, TypeError:
                    pass
        finally:
            db.close()

        # Startup: load setup wizard state into app.state
        db = SessionLocal()
        try:
            from governor_web.setup.loader import load_setup_state

            load_setup_state(app, db)
        finally:
            db.close()

        # Startup: check LLM configuration
        from governor_core.llm import is_llm_configured

        if is_llm_configured():
            logging.getLogger("governor_web").info(
                "LLM provider configured — solution generation enabled"
            )
        else:
            logging.getLogger("governor_web").warning(
                "LLM provider not configured — solution generation disabled. "
                "Set LLM_API_KEY to enable."
            )

        # Startup: start sync worker. Order matters — worker starts before
        # scheduler so scheduled jobs have a consumer. Shutdown is reversed.
        worker_thread = None
        stop_event = None
        scheduler = None
        if core_settings.app_env != "test" and core_settings.worker_enabled:
            from governor_core.sync.worker import Worker
            from governor_web.auth.worker_hooks import WebHooks

            worker = Worker(SessionLocal, hooks=WebHooks())
            stop_event = threading.Event()
            worker_thread = threading.Thread(
                target=worker.run,
                args=(stop_event,),
                daemon=True,
                name="sync-worker",
            )
            worker_thread.start()
            logging.getLogger("governor_web").info("Sync worker started")

        from governor_core.core.config import is_local_mode as _is_local

        if (
            core_settings.app_env != "test"
            and settings.scheduler_enabled
            and not _is_local()
        ):
            # Scheduler is cloud-only. Local CLI-spawned servers run syncs
            # manually (via `governor sync` on the command line); there is
            # no cron-style background schedule.
            from governor_web.scheduling.startup import (
                init_scheduler,
                load_schedules,
                register_post_merge_savings_calculation,
                register_pr_status_sync,
                shutdown_scheduler,
            )

            scheduler = init_scheduler(engine)
            scheduler.start()
            load_schedules(scheduler)
            register_pr_status_sync(scheduler)
            register_post_merge_savings_calculation(scheduler)
            app.state.scheduler = scheduler
            logging.getLogger("governor_web").info("Scheduler started")

        yield

        # Shutdown: stop scheduler first, then worker
        if scheduler:
            logging.getLogger("governor_web").info("Stopping scheduler...")
            shutdown_scheduler(scheduler)
            logging.getLogger("governor_web").info("Scheduler stopped")

        if worker_thread and stop_event:
            logging.getLogger("governor_web").info("Stopping sync worker...")
            stop_event.set()
            worker_thread.join(timeout=10)
            logging.getLogger("governor_web").info("Sync worker stopped")

    openapi_tags = [
        {"name": "auth", "description": "Authentication and user management"},
        {"name": "dashboard", "description": "Cost dashboard and analytics"},
        {"name": "sync", "description": "Data synchronization operations"},
        {"name": "configurations", "description": "Project configuration management"},
        {"name": "opportunities", "description": "Cost optimization opportunities"},
        {"name": "solutions", "description": "Solution generation and management"},
        {"name": "schedules", "description": "Sync schedule management"},
        {"name": "notifications", "description": "In-app notifications"},
        {"name": "admin", "description": "Administration endpoints"},
    ]
    fastapi_app = FastAPI(
        title="Governor",
        description="BigQuery cost optimization platform",
        version=app_version,
        openapi_tags=openapi_tags,
        docs_url="/docs" if core_settings.app_env != "production" else None,
        redoc_url="/redoc" if core_settings.app_env != "production" else None,
        lifespan=lifespan,
    )

    # Security & rate-limiting middleware (outermost → innermost)
    from governor_web.core.security import SecurityHeadersMiddleware
    from governor_web.core.rate_limit import RateLimitMiddleware

    fastapi_app.add_middleware(SecurityHeadersMiddleware, app_env=core_settings.app_env)
    fastapi_app.add_middleware(
        RateLimitMiddleware,
        max_requests=30,
        window_seconds=60,
        app_env=core_settings.app_env,
    )

    fastapi_app.mount("/static", StaticFiles(directory=_STATIC_DIR), name="static")
    fastapi_app.state.db_session_factory = SessionLocal
    fastapi_app.state.templates = Jinja2Templates(
        directory=_TEMPLATES_DIR,
        context_processors=[_sidebar_activity_context],
    )

    fastapi_app.state.templates.env.filters["timeago"] = timeago
    fastapi_app.state.templates.env.filters["sync_status_label"] = sync_status_label
    fastapi_app.state.templates.env.filters["format_usd"] = format_usd

    # Template global for local-mode branching in layout/sidebar/etc.
    from governor_core.core.config import is_local_mode

    fastapi_app.state.templates.env.globals["is_local_mode"] = is_local_mode()
    fastapi_app.state.templates.env.globals["app_version"] = app_version

    # Spec 132: expose the downstream-patch guardrail registry to Jinja so
    # templates can conditionally render sub-cards + warnings for ANY
    # registered guardrail solution, not just ``add_require_partition_filter``.
    from governor_core.agents.downstream_patch.providers import registered_template_ids

    fastapi_app.state.templates.env.globals[
        "downstream_patch_guardrail_template_ids"
    ] = registered_template_ids()

    fastapi_app.include_router(setup_routes.router)
    fastapi_app.include_router(public.router)
    fastapi_app.include_router(auth.router)
    fastapi_app.include_router(app_routes.router)
    fastapi_app.include_router(pull_requests.router)
    fastapi_app.include_router(solutions_admin.router)
    fastapi_app.include_router(settings_routes.router)
    fastapi_app.include_router(admin.router)
    fastapi_app.include_router(verification.router)
    fastapi_app.include_router(configurations.router)
    fastapi_app.include_router(sync.router, prefix="/api/sync")
    fastapi_app.include_router(sync.configurations_router)
    fastapi_app.include_router(queue.router, prefix="/admin/queue")
    fastapi_app.include_router(dashboard.router)
    fastapi_app.include_router(opportunities.router)
    fastapi_app.include_router(schedules.router)
    fastapi_app.include_router(notifications.router)

    if core_settings.app_env != "test":
        try:
            from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor

            FastAPIInstrumentor.instrument_app(fastapi_app)
        except Exception:  # pragma: no cover
            logging.getLogger("governor_web").debug(
                "FastAPI OTel instrumentation unavailable", exc_info=True
            )
        instrument_sqlalchemy(engine)

    def _wants_json_response(request: Request) -> bool:
        accept = request.headers.get("accept", "").lower()
        route = request.scope.get("route")
        response_class = getattr(route, "response_class", None)
        route_returns_json = False
        if isinstance(response_class, type):
            try:
                route_returns_json = issubclass(response_class, JSONResponse)
            except TypeError:
                route_returns_json = False
        return (
            request.url.path.startswith("/api/")
            or route_returns_json
            or "application/json" in accept
        )

    def _is_same_origin(request: Request, candidate: str | None) -> bool:
        if not candidate:
            return False
        try:
            parsed = urlparse(candidate)
        except ValueError:
            return False
        return (
            parsed.scheme == request.url.scheme and parsed.netloc == request.url.netloc
        )

    @fastapi_app.exception_handler(HTTPException)
    def _http_exception_handler(request: Request, exc: HTTPException) -> HTMLResponse:
        if _wants_json_response(request):
            return JSONResponse(
                {"detail": exc.detail or "Request failed."},
                status_code=exc.status_code,
            )
        if exc.status_code == 401:
            from governor_core.core.config import is_local_mode as _is_local

            target = "/dashboard" if _is_local() else "/login"
            return redirect_with_message(
                target,
                "Please sign in to continue.",
                "warning",
            )
        templates = fastapi_app.state.templates
        return errors.render_error(
            templates, request, exc.detail or "Request failed.", exc.status_code
        )

    @fastapi_app.exception_handler(ClientDisconnect)
    def _client_disconnect_handler(request: Request, exc: ClientDisconnect) -> Response:
        return Response(status_code=204)

    @fastapi_app.exception_handler(Exception)
    def _unhandled_exception_handler(request: Request, exc: Exception) -> HTMLResponse:
        logging.getLogger("governor_web.error").error(
            "unhandled exception",
            extra={"path": request.url.path},
            exc_info=exc,
        )
        if _wants_json_response(request):
            return JSONResponse({"detail": "Internal server error."}, status_code=500)
        templates = fastapi_app.state.templates
        return errors.render_error(templates, request, "Internal server error.", 500)

    _SETUP_PASSTHROUGH = ("/setup", "/static", "/health")

    @fastapi_app.middleware("http")
    async def _setup_guard_middleware(request: Request, call_next):
        path = request.url.path
        if any(path.startswith(p) for p in _SETUP_PASSTHROUGH):
            return await call_next(request)

        setup_complete = getattr(request.app.state, "setup_complete", True)
        if not setup_complete:
            db_factory = getattr(request.app.state, "db_session_factory", SessionLocal)
            db = db_factory()
            try:
                from governor_web.setup.models import SetupState

                state = db.query(SetupState).first()
                step = state.step_reached if state else 1
                target = "/setup/complete" if step >= 7 else f"/setup/{step}"
            finally:
                db.close()
            from fastapi.responses import RedirectResponse as _Redirect

            return _Redirect(url=target, status_code=302)

        return await call_next(request)

    @fastapi_app.middleware("http")
    async def _request_context_middleware(request: Request, call_next):
        request_id = request.headers.get("x-request-id") or str(uuid4())
        bind_request_context(
            request_id,
            request.url.path,
            request.method,
            request.client.host if request.client else None,
        )
        start = time.monotonic()
        try:
            if core_settings.app_env != "test" and request.method not in {
                "GET",
                "HEAD",
                "OPTIONS",
                "TRACE",
            }:
                origin = request.headers.get("origin")
                referer = request.headers.get("referer")
                if not (
                    _is_same_origin(request, origin)
                    or _is_same_origin(request, referer)
                ):
                    if _wants_json_response(request):
                        return JSONResponse(
                            {"detail": "CSRF validation failed."},
                            status_code=403,
                        )
                    return errors.render_error(
                        fastapi_app.state.templates,
                        request,
                        "CSRF validation failed.",
                        403,
                    )
            response = await call_next(request)
            duration_ms = (time.monotonic() - start) * 1000
            logger = logging.getLogger("governor_web.request")
            logger.info(
                "request completed",
                extra={
                    "status_code": response.status_code,
                    "duration_ms": round(duration_ms, 2),
                },
            )
            response.headers["x-request-id"] = request_id
            return response
        finally:
            clear_request_context()

    return fastapi_app


app = create_app()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        reload=False,
        log_config=None,
        access_log=True,
    )
