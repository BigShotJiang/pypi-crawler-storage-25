"""
Cost Analytics Dashboard module.

Provides aggregated views of BigQuery costs, trends, and optimization opportunities.
"""

from governor_web.dashboard.service import DashboardService
from governor_web.dashboard.formatters import format_usd

__all__ = ["DashboardService", "format_usd"]
