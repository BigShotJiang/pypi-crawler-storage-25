"""Notification service for creating and delivering notifications."""

from __future__ import annotations

import logging
from datetime import datetime, timezone

import httpx
from sqlalchemy.orm import Session

from governor_web.notifications.models import Notification
from governor_web.settings.models import OrganisationSetting

logger = logging.getLogger("app.notifications")


class NotificationService:
    def __init__(self, db: Session) -> None:
        self.db = db

    def create(
        self,
        user_id: str,
        event_type: str,
        title: str,
        body: str,
        link: str | None = None,
    ) -> Notification:
        notification = Notification(
            user_id=user_id,
            event_type=event_type,
            title=title,
            body=body,
            link=link,
        )
        self.db.add(notification)
        self.db.commit()
        self.db.refresh(notification)
        return notification

    def notify_admins(
        self,
        event_type: str,
        title: str,
        body: str,
        link: str | None = None,
    ) -> list[Notification]:
        """Create a notification for all admin users."""
        from governor_web.auth.models import Role, UserRole

        admin_role = (
            self.db.query(Role).filter(Role.name == "admin").one_or_none()
        )
        if not admin_role:
            return []

        admin_ids = [
            ur.user_id
            for ur in self.db.query(UserRole)
            .filter(UserRole.role_id == admin_role.id)
            .all()
        ]

        notifications = []
        for uid in admin_ids:
            notifications.append(
                self.create(uid, event_type, title, body, link)
            )

        self._try_slack_webhook(title, body, link)
        return notifications

    def get_unread_count(self, user_id: str) -> int:
        return (
            self.db.query(Notification)
            .filter(
                Notification.user_id == user_id,
                Notification.read_at.is_(None),
            )
            .count()
        )

    def get_recent(self, user_id: str, limit: int = 20) -> list[Notification]:
        return (
            self.db.query(Notification)
            .filter(Notification.user_id == user_id)
            .order_by(Notification.created_at.desc())
            .limit(limit)
            .all()
        )

    def mark_as_read(self, notification_id: str, user_id: str) -> bool:
        notification = (
            self.db.query(Notification)
            .filter(
                Notification.id == notification_id,
                Notification.user_id == user_id,
            )
            .one_or_none()
        )
        if not notification:
            return False
        notification.read_at = datetime.now(timezone.utc)
        self.db.commit()
        return True

    def mark_all_as_read(self, user_id: str) -> int:
        count = (
            self.db.query(Notification)
            .filter(
                Notification.user_id == user_id,
                Notification.read_at.is_(None),
            )
            .update({"read_at": datetime.now(timezone.utc)})
        )
        self.db.commit()
        return count

    def _try_slack_webhook(
        self, title: str, body: str, link: str | None
    ) -> None:
        """Attempt to deliver to Slack webhook. Failures are logged, never raised."""
        row = (
            self.db.query(OrganisationSetting)
            .filter(OrganisationSetting.setting_key == "slack_webhook_url")
            .one_or_none()
        )
        if not row or not row.setting_value:
            return

        text = f"*{title}*\n{body}"
        if link:
            text += f"\n<{link}|View details>"

        try:
            httpx.post(
                row.setting_value,
                json={"text": text},
                timeout=10.0,
            )
        except Exception:
            logger.warning("Slack webhook delivery failed", exc_info=True)
