"""Reusable in-memory rate limiter for Governor.

Provides per-IP rate limiting with configurable window and threshold.
Uses X-Forwarded-For when behind a trusted proxy.
Disabled in test environment.
"""

from __future__ import annotations

import threading
import time

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse, Response


class RateLimiter:
    """Thread-safe, per-key sliding-window rate limiter."""

    def __init__(self, max_requests: int = 30, window_seconds: int = 60) -> None:
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self._attempts: dict[str, list[float]] = {}
        self._lock = threading.Lock()

    def is_limited(self, key: str) -> tuple[bool, int]:
        """Check if the key is rate limited.

        Returns:
            Tuple of (is_limited, retry_after_seconds).
        """
        now = time.monotonic()
        with self._lock:
            attempts = self._attempts.get(key, [])
            attempts = [t for t in attempts if now - t < self.window_seconds]
            self._attempts[key] = attempts
            if len(attempts) >= self.max_requests:
                oldest = attempts[0]
                retry_after = int(self.window_seconds - (now - oldest)) + 1
                return True, max(retry_after, 1)
            attempts.append(now)
            return False, 0

    def clear(self) -> None:
        with self._lock:
            self._attempts.clear()


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Middleware that rate-limits non-safe HTTP methods per client IP."""

    _SAFE_METHODS = {"GET", "HEAD", "OPTIONS", "TRACE"}

    def __init__(
        self,
        app,
        *,
        max_requests: int = 30,
        window_seconds: int = 60,
        app_env: str = "production",
    ) -> None:
        super().__init__(app)
        self._limiter = RateLimiter(max_requests, window_seconds)
        self._app_env = app_env

    def _get_client_ip(self, request: Request) -> str:
        forwarded = request.headers.get("x-forwarded-for")
        if forwarded:
            return forwarded.split(",")[0].strip()
        return request.client.host if request.client else "unknown"

    async def dispatch(self, request: Request, call_next) -> Response:
        if self._app_env == "test":
            return await call_next(request)

        if request.method in self._SAFE_METHODS:
            return await call_next(request)

        client_ip = self._get_client_ip(request)
        limited, retry_after = self._limiter.is_limited(client_ip)

        if limited:
            return JSONResponse(
                {"detail": "Rate limit exceeded. Please try again later."},
                status_code=429,
                headers={"Retry-After": str(retry_after)},
            )

        return await call_next(request)
