"""Web settings — combines engine settings from ``governor_core`` with the
web-only additions (session cookies, OAuth, SMTP, scheduler).

Modules inside ``governor_web`` should import ``get_settings`` from this
module, *not* from ``governor_core.core.config`` — the core Settings does
not carry the web-specific fields.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache

from dotenv import load_dotenv

from governor_core.core.config import Settings as _CoreSettings
from governor_core.core.config import get_settings as _get_core_settings
from governor_core.core.config import is_local_mode  # noqa: F401 — re-exported

load_dotenv()


@dataclass(frozen=True)
class WebSettings(_CoreSettings):
    """Engine settings + web-only additions.

    Inherits every field from ``governor_core.core.config.Settings`` so the
    usual ``settings.database_url``, ``settings.llm_api_key``, etc. still
    work; adds the fields below for the auth / scheduling / OAuth / SMTP
    subsystems.
    """

    # --- Session cookies ---
    session_cookie_name: str = "governor_session"
    session_cookie_secure: bool = False
    session_ttl_hours: int = 24
    session_refresh_interval_minutes: int = 5
    # --- APScheduler ---
    scheduler_enabled: bool = True
    # --- Google OAuth (optional) ---
    google_oauth_client_id: str | None = None
    google_oauth_client_secret: str | None = None
    oauth_auto_provision: bool = False
    oauth_redirect_uri: str = "http://localhost:8000/auth/google/callback"
    # --- SMTP (optional) ---
    smtp_host: str | None = None
    smtp_port: int = 587
    smtp_username: str | None = None
    smtp_password: str | None = None
    smtp_from_email: str = "governor@localhost"


def _get_env(name: str, default: str) -> str:
    return os.environ.get(name, default)


def _get_optional_env(name: str) -> str | None:
    value = os.environ.get(name)
    return value if value else None


@lru_cache
def get_settings() -> WebSettings:
    """Return the combined engine + web settings.

    Reads each field from its environment variable, using the same defaults
    and naming conventions as the pre-split ``app.core.config``.
    """
    core = _get_core_settings()
    app_env = core.app_env

    # ``dataclasses.replace`` won't work here (different class), so copy all
    # core fields via ``**core.__dict__`` and add the web-only ones.
    return WebSettings(
        **core.__dict__,
        session_cookie_name=_get_env("SESSION_COOKIE_NAME", "governor_session"),
        session_cookie_secure=_get_env(
            "SESSION_COOKIE_SECURE",
            "false" if app_env in ("test", "development") else "true",
        ).lower()
        == "true",
        session_ttl_hours=int(_get_env("SESSION_TTL_HOURS", "24")),
        session_refresh_interval_minutes=int(
            _get_env("SESSION_REFRESH_INTERVAL_MINUTES", "5")
        ),
        scheduler_enabled=_get_env("SCHEDULER_ENABLED", "true").lower() == "true",
        google_oauth_client_id=_get_optional_env("GOOGLE_OAUTH_CLIENT_ID"),
        google_oauth_client_secret=_get_optional_env("GOOGLE_OAUTH_CLIENT_SECRET"),
        oauth_auto_provision=_get_env("OAUTH_AUTO_PROVISION", "false").lower() == "true",
        oauth_redirect_uri=_get_env(
            "OAUTH_REDIRECT_URI",
            "http://localhost:8000/auth/google/callback",
        ),
        smtp_host=_get_optional_env("SMTP_HOST"),
        smtp_port=int(_get_env("SMTP_PORT", "587")),
        smtp_username=_get_optional_env("SMTP_USERNAME"),
        smtp_password=_get_optional_env("SMTP_PASSWORD"),
        smtp_from_email=_get_env("SMTP_FROM_EMAIL", "governor@localhost"),
    )
