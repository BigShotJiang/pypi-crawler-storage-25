from __future__ import annotations

import hashlib
import logging
import time
import threading
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Form, Request, status
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session
from starlette.responses import Response

from governor_web.auth.dependencies import get_active_session
from governor_web.auth import models as auth_models
from governor_web.auth.service import AuthService
from governor_web.core.config import get_settings
from governor_core.db.session import get_session
from governor_web.routes.helpers import get_flash_message, redirect_with_message

router = APIRouter()

# ---------------------------------------------------------------------------
# Simple in-memory login rate limiter
# ---------------------------------------------------------------------------
_login_attempts: dict[str, list[float]] = {}
_login_lock = threading.Lock()
_MAX_ATTEMPTS = 5  # max attempts per window
_WINDOW_SECONDS = 300  # 5 minute window


def _is_rate_limited(key: str) -> bool:
    """Return True if the key has exceeded the login attempt limit."""
    now = time.monotonic()
    with _login_lock:
        attempts = _login_attempts.get(key, [])
        # Prune expired entries
        attempts = [t for t in attempts if now - t < _WINDOW_SECONDS]
        _login_attempts[key] = attempts
        if len(attempts) >= _MAX_ATTEMPTS:
            return True
        attempts.append(now)
        return False


@router.post("/login", response_class=HTMLResponse)
def login_submit(
    request: Request,
    email: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_session),
) -> Response:
    from governor_core.core.config import is_local_mode

    if is_local_mode():
        return RedirectResponse("/dashboard", status_code=302)

    templates = request.app.state.templates

    # Rate limit by IP address
    client_ip = request.client.host if request.client else "unknown"
    if _is_rate_limited(client_ip):
        logging.getLogger("app.auth").warning(
            "login rate limited", extra={"ip": client_ip, "email": email},
        )
        return templates.TemplateResponse(
            request,
            "login.html",
            {
                "title": "Sign in",
                "flash": get_flash_message(request),
                "error": "Too many login attempts. Please try again in a few minutes.",
                "show_sidebar": False,
            },
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
        )

    auth_service = AuthService(db)
    user = auth_service.authenticate(email, password)
    if not user:
        existing = auth_service.find_user_by_email(email)
        auth_service.record_audit_event(
            existing.id if existing else None,
            "login",
            "failure",
            request.client.host if request.client else None,
            request.headers.get("user-agent"),
        )
        db.commit()
        logging.getLogger("app.auth").warning(
            "login failed",
            extra={"email": email},
        )
        return templates.TemplateResponse(
            request,
            "login.html",
            {
                "title": "Sign in",
                "flash": get_flash_message(request),
                "error": "Invalid credentials.",
                "show_sidebar": False,
            },
            status_code=status.HTTP_401_UNAUTHORIZED,
        )

    session = auth_service.create_session(
        user,
        request.client.host if request.client else None,
        request.headers.get("user-agent"),
    )
    cookie_expires = session.expires_at
    if cookie_expires is not None:
        if cookie_expires.tzinfo is None:
            cookie_expires = cookie_expires.replace(tzinfo=timezone.utc)
        else:
            cookie_expires = cookie_expires.astimezone(timezone.utc)
    settings = get_settings()
    response = RedirectResponse(url="/dashboard", status_code=status.HTTP_302_FOUND)
    response.set_cookie(
        settings.session_cookie_name,
        session.id,
        httponly=True,
        samesite="lax",
        secure=settings.session_cookie_secure,
        max_age=settings.session_ttl_hours * 3600,
        expires=cookie_expires,
    )
    logging.getLogger("app.auth").info(
        "login success",
        extra={"email": user.email},
    )
    return response


@router.post("/logout")
def logout(
    request: Request,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> RedirectResponse:
    from governor_core.core.config import is_local_mode

    if is_local_mode():
        return RedirectResponse("/dashboard", status_code=302)

    if auth_session:
        auth_service = AuthService(db)
        auth_service.revoke_session(
            auth_session,
            request.client.host if request.client else None,
            request.headers.get("user-agent"),
        )
        logging.getLogger("app.auth").info(
            "logout success",
            extra={"user_id": auth_session.user_id},
        )
    response = redirect_with_message("/", "You have been signed out.", "info")
    settings = get_settings()
    response.delete_cookie(
        settings.session_cookie_name,
        secure=settings.session_cookie_secure,
        samesite="lax",
    )
    return response


# ---------------------------------------------------------------------------
# Password reset
# ---------------------------------------------------------------------------

@router.get("/forgot-password", response_class=HTMLResponse)
def forgot_password_page(request: Request) -> Response:
    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "auth/forgot_password.html",
        {
            "title": "Forgot password",
            "flash": get_flash_message(request),
            "show_sidebar": False,
        },
    )


@router.post("/forgot-password", response_class=HTMLResponse)
def forgot_password_submit(
    request: Request,
    email: str = Form(...),
    db: Session = Depends(get_session),
) -> Response:
    auth_service = AuthService(db)
    auth_service.generate_reset_token(email)
    # Always redirect with success — avoid email enumeration
    return redirect_with_message(
        "/forgot-password",
        "If an account with that email exists, a reset link has been sent.",
        "info",
    )


@router.get("/reset-password/{token}", response_class=HTMLResponse)
def reset_password_page(
    request: Request,
    token: str,
    db: Session = Depends(get_session),
) -> Response:
    auth_service = AuthService(db)
    token_record = auth_service.validate_reset_token(token)
    if not token_record:
        return redirect_with_message(
            "/forgot-password",
            "Invalid or expired reset link. Please request a new one.",
            "warning",
        )
    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "auth/reset_password.html",
        {
            "title": "Reset password",
            "token": token,
            "show_sidebar": False,
        },
    )


@router.post("/reset-password/{token}", response_class=HTMLResponse)
def reset_password_submit(
    request: Request,
    token: str,
    new_password: str = Form(...),
    confirm_password: str = Form(...),
    db: Session = Depends(get_session),
) -> Response:
    if new_password != confirm_password:
        templates = request.app.state.templates
        return templates.TemplateResponse(
            request,
            "auth/reset_password.html",
            {
                "title": "Reset password",
                "token": token,
                "error": "Passwords do not match.",
                "show_sidebar": False,
            },
            status_code=status.HTTP_400_BAD_REQUEST,
        )

    auth_service = AuthService(db)
    success, message = auth_service.reset_password(token, new_password)
    if not success:
        return redirect_with_message("/forgot-password", message, "warning")
    return redirect_with_message("/login", message, "info")


# ---------------------------------------------------------------------------
# Google OAuth
# ---------------------------------------------------------------------------

@router.get("/auth/google")
def google_oauth_start(request: Request) -> Response:
    from governor_web.auth.oauth import build_google_auth_url, is_oauth_configured

    if not is_oauth_configured():
        return redirect_with_message("/login", "Google sign-in is not configured.", "warning")

    auth_url, state = build_google_auth_url()
    response = RedirectResponse(auth_url, status_code=status.HTTP_302_FOUND)
    response.set_cookie(
        "oauth_state",
        state,
        httponly=True,
        samesite="lax",
        max_age=600,  # 10 minutes
    )
    return response


@router.get("/auth/google/callback")
def google_oauth_callback(
    request: Request,
    code: str | None = None,
    state: str | None = None,
    error: str | None = None,
    db: Session = Depends(get_session),
) -> Response:
    from governor_web.auth.oauth import exchange_google_code, get_google_user_info, is_oauth_configured

    if not is_oauth_configured():
        return redirect_with_message("/login", "Google sign-in is not configured.", "warning")

    if error:
        logging.getLogger("app.auth").warning("OAuth error: %s", error)
        return redirect_with_message("/login", "Google sign-in was cancelled or failed.", "warning")

    # Validate state to prevent CSRF
    stored_state = request.cookies.get("oauth_state")
    if not state or not stored_state or state != stored_state:
        return redirect_with_message("/login", "Invalid OAuth state. Please try again.", "warning")

    if not code:
        return redirect_with_message("/login", "Missing authorization code.", "warning")

    try:
        token_data = exchange_google_code(code)
        user_info = get_google_user_info(token_data["access_token"])
    except Exception:
        logging.getLogger("app.auth").exception("OAuth token exchange failed")
        return redirect_with_message("/login", "Google sign-in failed. Please try again.", "warning")

    email = user_info.get("email")
    if not email:
        return redirect_with_message("/login", "Could not retrieve email from Google.", "warning")

    auth_service = AuthService(db)
    user = auth_service.find_user_by_email(email)
    if not user:
        return redirect_with_message(
            "/login",
            "No account found for that email. Please contact an administrator.",
            "warning",
        )

    if user.status != "active":
        return redirect_with_message("/login", "Your account is not active.", "warning")

    session = auth_service.create_session(
        user,
        request.client.host if request.client else None,
        request.headers.get("user-agent"),
    )
    cookie_expires = session.expires_at
    if cookie_expires is not None:
        if cookie_expires.tzinfo is None:
            cookie_expires = cookie_expires.replace(tzinfo=timezone.utc)
        else:
            cookie_expires = cookie_expires.astimezone(timezone.utc)

    settings = get_settings()
    response = RedirectResponse(url="/dashboard", status_code=status.HTTP_302_FOUND)
    response.set_cookie(
        settings.session_cookie_name,
        session.id,
        httponly=True,
        samesite="lax",
        secure=settings.session_cookie_secure,
        max_age=settings.session_ttl_hours * 3600,
        expires=cookie_expires,
    )
    # Clear the OAuth state cookie
    response.delete_cookie("oauth_state", samesite="lax")
    logging.getLogger("app.auth").info(
        "OAuth login success", extra={"email": user.email},
    )
    return response


# ---------------------------------------------------------------------------
# Invitation acceptance
# ---------------------------------------------------------------------------

@router.get("/invite/{token}", response_class=HTMLResponse)
def accept_invitation_page(
    request: Request,
    token: str,
    db: Session = Depends(get_session),
) -> Response:
    token_hash = hashlib.sha256(token.encode()).hexdigest()
    invitation = (
        db.query(auth_models.Invitation)
        .filter(
            auth_models.Invitation.token_hash == token_hash,
            auth_models.Invitation.accepted_at.is_(None),
            auth_models.Invitation.expires_at > datetime.now(timezone.utc),
        )
        .one_or_none()
    )
    if not invitation:
        return redirect_with_message(
            "/login",
            "Invalid or expired invitation link.",
            "warning",
        )
    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "auth/accept_invitation.html",
        {
            "title": "Accept invitation",
            "token": token,
            "email": invitation.email,
            "show_sidebar": False,
        },
    )


@router.post("/invite/{token}", response_class=HTMLResponse)
def accept_invitation_submit(
    request: Request,
    token: str,
    display_name: str = Form(...),
    password: str = Form(...),
    confirm_password: str = Form(...),
    db: Session = Depends(get_session),
) -> Response:
    if password != confirm_password:
        # Re-validate the token to get the email for the form
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        invitation = (
            db.query(auth_models.Invitation)
            .filter(
                auth_models.Invitation.token_hash == token_hash,
                auth_models.Invitation.accepted_at.is_(None),
                auth_models.Invitation.expires_at > datetime.now(timezone.utc),
            )
            .one_or_none()
        )
        templates = request.app.state.templates
        return templates.TemplateResponse(
            request,
            "auth/accept_invitation.html",
            {
                "title": "Accept invitation",
                "token": token,
                "email": invitation.email if invitation else "",
                "error": "Passwords do not match.",
                "show_sidebar": False,
            },
            status_code=status.HTTP_400_BAD_REQUEST,
        )

    auth_service = AuthService(db)
    success, message = auth_service.accept_invitation(token, display_name, password)
    if not success:
        return redirect_with_message("/login", message, "warning")
    return redirect_with_message("/login", message, "info")
