from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session
from starlette.responses import Response

from governor_web.auth import hashing, models
from governor_web.auth.dependencies import require_role
from governor_web.auth.service import AuthService
from governor_core.core.config import is_local_mode
from governor_core.db.session import get_session
from governor_web.routes.helpers import redirect_local_mode_feature, redirect_with_message
from governor_core.utils.pagination import PaginationContext

router = APIRouter()


def _has_role(user: models.User, role_name: str) -> bool:
    return any(role.name == role_name for role in user.roles)


def _redirect_local_user_management() -> Response:
    return redirect_local_mode_feature(
        "/admin/configurations",
        feature_name="User management",
        guidance="Local mode runs as a single admin session.",
    )


# ── User list ────────────────────────────────────────────────────────────────


@router.get("/admin/users", response_class=HTMLResponse)
def users_list(
    request: Request,
    user: models.User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> Response:
    if is_local_mode():
        return _redirect_local_user_management()

    users = db.query(models.User).order_by(models.User.created_at.desc()).all()
    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "admin/users/list.html",
        {"title": "Users", "user": user, "users": users},
    )


# ── New user form ─────────────────────────────────────────────────────────────


@router.get("/admin/users/new", response_class=HTMLResponse)
def users_new(
    request: Request,
    user: models.User = Depends(require_role("admin")),
) -> Response:
    if is_local_mode():
        return _redirect_local_user_management()

    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "admin/users/new.html",
        {"title": "New User", "user": user, "error": None},
    )


@router.post("/admin/users/new", response_class=HTMLResponse)
def users_create(
    request: Request,
    email: str = Form(""),
    display_name: str = Form(""),
    password: str = Form(""),
    is_admin: bool = Form(False),
    user: models.User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> Response:
    if is_local_mode():
        return _redirect_local_user_management()

    templates = request.app.state.templates

    def _render_error(msg: str) -> Response:
        return templates.TemplateResponse(
            request,
            "admin/users/new.html",
            {
                "title": "New User",
                "user": user,
                "error": msg,
                "form": {
                    "email": email,
                    "display_name": display_name,
                    "is_admin": is_admin,
                },
            },
        )

    email = email.strip().lower()
    display_name = display_name.strip()

    if not email:
        return _render_error("Email is required.")
    if not display_name:
        return _render_error("Display name is required.")
    if not password:
        return _render_error("Password is required.")
    if len(password) < 8:
        return _render_error("Password must be at least 8 characters.")

    existing = AuthService(db).find_user_by_email(email)
    if existing:
        return _render_error(f"A user with email {email} already exists.")

    new_user = models.User(
        email=email,
        display_name=display_name,
        password_hash=hashing.hash_password(password),
        status="active",
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    if is_admin:
        role = db.query(models.Role).filter(models.Role.name == "admin").one_or_none()
        if not role:
            role = models.Role(name="admin")
            db.add(role)
            db.commit()
            db.refresh(role)
        new_user.roles.append(role)
        db.commit()

    return redirect_with_message(
        "/admin/users",
        f"User {email} created successfully.",
        "success",
    )


# ── Deactivate / reactivate ───────────────────────────────────────────────────


@router.post("/admin/users/{user_id}/deactivate", response_class=HTMLResponse)
def users_deactivate(
    user_id: str,
    request: Request,
    current_user: models.User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> RedirectResponse:
    if is_local_mode():
        return _redirect_local_user_management()

    if user_id == current_user.id:
        return redirect_with_message(
            "/admin/users", "You cannot deactivate your own account.", "warning"
        )

    target = db.query(models.User).filter(models.User.id == user_id).one_or_none()
    if not target:
        return redirect_with_message("/admin/users", "User not found.", "warning")

    target.status = "inactive"
    # Revoke all active sessions
    db.query(models.Session).filter(
        models.Session.user_id == user_id,
        models.Session.revoked_at.is_(None),
    ).update({"revoked_at": datetime.now(timezone.utc)})
    db.commit()

    return redirect_with_message(
        "/admin/users", f"{target.email} has been deactivated.", "success"
    )


@router.post("/admin/users/{user_id}/reactivate", response_class=HTMLResponse)
def users_reactivate(
    user_id: str,
    request: Request,
    current_user: models.User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> RedirectResponse:
    if is_local_mode():
        return _redirect_local_user_management()

    target = db.query(models.User).filter(models.User.id == user_id).one_or_none()
    if not target:
        return redirect_with_message("/admin/users", "User not found.", "warning")

    target.status = "active"
    db.commit()

    return redirect_with_message(
        "/admin/users", f"{target.email} has been reactivated.", "success"
    )


# ── Role toggle ───────────────────────────────────────────────────────────────


@router.post("/admin/users/{user_id}/set-role", response_class=HTMLResponse)
def users_set_role(
    user_id: str,
    request: Request,
    role: str = Form(""),
    current_user: models.User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> RedirectResponse:
    if is_local_mode():
        return _redirect_local_user_management()

    if user_id == current_user.id:
        return redirect_with_message(
            "/admin/users", "You cannot change your own role.", "warning"
        )

    target = db.query(models.User).filter(models.User.id == user_id).one_or_none()
    if not target:
        return redirect_with_message("/admin/users", "User not found.", "warning")

    admin_role = db.query(models.Role).filter(models.Role.name == "admin").one_or_none()

    if role == "admin":
        if not admin_role:
            admin_role = models.Role(name="admin")
            db.add(admin_role)
            db.commit()
            db.refresh(admin_role)
        if admin_role not in target.roles:
            target.roles.append(admin_role)
            db.commit()
        return redirect_with_message(
            "/admin/users", f"{target.email} is now an admin.", "success"
        )
    else:
        if admin_role and admin_role in target.roles:
            target.roles.remove(admin_role)
            db.commit()
        return redirect_with_message(
            "/admin/users", f"{target.email} role changed to user.", "success"
        )


# ── Audit Log ────────────────────────────────────────────────────────────────

_AUDIT_PAGE_SIZE = 25


@router.get("/admin/audit-log", response_class=HTMLResponse)
def audit_log(
    request: Request,
    event_type: str = "",
    user_id: str = "",
    page: int = 1,
    user: models.User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> Response:
    query = db.query(models.AuditEvent).outerjoin(
        models.User, models.AuditEvent.user_id == models.User.id
    )

    if event_type:
        query = query.filter(models.AuditEvent.event_type == event_type)
    if user_id:
        query = query.filter(models.AuditEvent.user_id == user_id)

    total = query.count()
    page = max(1, page)
    pagination = PaginationContext(
        page=page, page_size=_AUDIT_PAGE_SIZE, total_items=total
    )
    if pagination.page > pagination.total_pages and pagination.total_pages > 0:
        pagination = PaginationContext(
            page=pagination.total_pages,
            page_size=_AUDIT_PAGE_SIZE,
            total_items=total,
        )

    offset = (pagination.page - 1) * _AUDIT_PAGE_SIZE
    events = (
        query.order_by(models.AuditEvent.event_at.desc())
        .offset(offset)
        .limit(_AUDIT_PAGE_SIZE)
        .all()
    )

    # Distinct event types for the filter dropdown
    event_types = [
        row[0]
        for row in db.query(models.AuditEvent.event_type)
        .distinct()
        .order_by(models.AuditEvent.event_type)
        .all()
    ]

    # All users for the user filter dropdown
    all_users = (
        db.query(models.User).order_by(models.User.display_name).all()
    )

    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "admin/audit_log.html",
        {
            "title": "Audit Log",
            "user": user,
            "events": events,
            "event_types": event_types,
            "all_users": all_users,
            "selected_event_type": event_type,
            "selected_user_id": user_id,
            "pagination": pagination,
        },
    )
