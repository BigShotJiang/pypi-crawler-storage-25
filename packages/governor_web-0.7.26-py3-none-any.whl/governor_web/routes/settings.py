from __future__ import annotations

import logging
from collections.abc import Generator

from fastapi import APIRouter, Depends, Form, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse
from sqlalchemy.orm import Session
from starlette.responses import Response

from governor_web.auth import models
from governor_web.auth.dependencies import get_active_session
from governor_web.auth.service import AuthService
from governor_core.db.session import get_session
from governor_web.routes.helpers import get_flash_message, redirect_with_message

router = APIRouter()
logger = logging.getLogger("app.settings")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _is_admin(user: models.User) -> bool:
    return any(role.name == "admin" for role in user.roles)


def _require_admin_or_redirect(user: models.User) -> RedirectResponse | None:
    """Return RedirectResponse if user is not admin, else None."""
    if not _is_admin(user):
        return RedirectResponse("/settings", status_code=302)
    return None


def _installation_form_defaults(state) -> dict[str, str]:
    from governor_core.core.config import is_local_mode

    github_auth_mode = state.github_auth_mode or (
        "disabled"
        if is_local_mode()
        else ("personal_token" if state.installation_mode == "local_dev" else "app")
    )
    return {
        "installation_mode": state.installation_mode or "cloud",
        "gcp_auth_method": state.gcp_auth_method or "json",
        "bigquery_region": state.bigquery_region or "",
        "github_auth_mode": github_auth_mode,
        "credentials_json": "",
        "app_id": "",
        "installation_id": "",
        "private_key": "",
        "personal_access_token": "",
    }


def _render_installation_page(
    request: Request,
    user: models.User,
    state,
    *,
    form_data: dict[str, str] | None = None,
    errors: dict[str, str] | None = None,
    status_code: int = 200,
) -> Response:
    from governor_core.core.config import is_local_mode

    current_form_data = form_data or _installation_form_defaults(state)
    local_runtime_mode = is_local_mode()
    has_saved_github_app_credentials = bool(
        state.github_app_id
        and state.github_installation_id
        and state.github_private_key
    )
    has_saved_github_personal_access_token = bool(state.github_personal_access_token)
    github_errors = errors or {}
    show_github_advanced = (
        not local_runtime_mode
        or current_form_data.get("github_auth_mode") != "disabled"
        or has_saved_github_app_credentials
        or has_saved_github_personal_access_token
        or any(
            key in github_errors
            for key in (
                "github_auth_mode",
                "github",
                "app_id",
                "installation_id",
                "private_key",
                "personal_access_token",
            )
        )
    )

    # Gather local workspace info for display
    workspace_info = None
    if local_runtime_mode:
        from governor_web.core.config import get_settings

        s = get_settings()
        from governor_core.configurations.models import ManifestConfiguration

        db_session = request.app.state.db_session_factory()
        try:
            config = (
                db_session.query(ManifestConfiguration)
                .filter(ManifestConfiguration.status == "active")
                .first()
            )
            workspace_info = {
                "project_path": config.local_project_path if config else None,
                "profiles_dir": s.dbt_profiles_dir or None,
                "target_name": s.dbt_target_name or None,
                "dbt_version": s.dbt_default_version or None,
            }
        finally:
            db_session.close()

    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "settings/installation.html",
        {
            "title": "Settings - Installation",
            "user": user,
            "active_tab": "installation",
            "is_admin": True,
            "flash": get_flash_message(request) if status_code == 200 else None,
            "form_data": current_form_data,
            "errors": github_errors,
            "setup_state": state,
            "local_runtime_mode": local_runtime_mode,
            "show_github_advanced": show_github_advanced,
            "has_saved_gcp_credentials": bool(state.gcp_credentials_json),
            "has_saved_github_app_credentials": has_saved_github_app_credentials,
            "has_saved_github_personal_access_token": has_saved_github_personal_access_token,
            "workspace_info": workspace_info,
        },
        status_code=status_code,
    )


# ---------------------------------------------------------------------------
# Personal: Profile
# ---------------------------------------------------------------------------


@router.get("/settings", response_class=HTMLResponse)
def settings_profile(
    request: Request,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> Response:
    """Display the Profile settings tab (default view)."""
    if not auth_session:
        return redirect_with_message("/login", "Please sign in to continue.", "warning")

    user = db.query(models.User).filter(models.User.id == auth_session.user_id).one()
    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "settings/profile.html",
        {
            "title": "Settings - Profile",
            "flash": get_flash_message(request),
            "user": user,
            "active_tab": "profile",
            "is_admin": _is_admin(user),
        },
    )


@router.post("/settings", response_class=HTMLResponse)
def settings_profile_submit(
    request: Request,
    display_name: str = Form(""),
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> Response:
    """Update user's display name."""
    if not auth_session:
        return redirect_with_message("/login", "Please sign in to continue.", "warning")

    user = db.query(models.User).filter(models.User.id == auth_session.user_id).one()
    is_admin = _is_admin(user)
    templates = request.app.state.templates

    def render_with_error(error: str) -> Response:
        return templates.TemplateResponse(
            request,
            "settings/profile.html",
            {
                "title": "Settings - Profile",
                "user": user,
                "active_tab": "profile",
                "is_admin": is_admin,
                "error": error,
            },
        )

    # Validate display name
    display_name = display_name.strip()
    if not display_name:
        return render_with_error("Display name is required.")
    if len(display_name) > 255:
        return render_with_error("Display name must not exceed 255 characters.")

    # Update display name
    user.display_name = display_name
    db.commit()

    logger.info("display name updated", extra={"user_id": user.id})
    return redirect_with_message(
        "/settings", "Display name updated successfully.", "info"
    )


# ---------------------------------------------------------------------------
# Personal: Security
# ---------------------------------------------------------------------------


@router.get("/settings/security", response_class=HTMLResponse)
def settings_security(
    request: Request,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> Response:
    """Display the Security settings tab (password change form)."""
    if not auth_session:
        return redirect_with_message("/login", "Please sign in to continue.", "warning")

    user = db.query(models.User).filter(models.User.id == auth_session.user_id).one()
    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "settings/security.html",
        {
            "title": "Settings - Security",
            "flash": get_flash_message(request),
            "user": user,
            "active_tab": "security",
            "is_admin": _is_admin(user),
        },
    )


@router.post("/settings/security", response_class=HTMLResponse)
def settings_security_submit(
    request: Request,
    current_password: str = Form(...),
    new_password: str = Form(...),
    confirm_password: str = Form(...),
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> Response:
    """Change user's password."""
    if not auth_session:
        return redirect_with_message("/login", "Please sign in to continue.", "warning")

    user = db.query(models.User).filter(models.User.id == auth_session.user_id).one()
    is_admin = _is_admin(user)
    templates = request.app.state.templates

    def render_with_error(error: str) -> Response:
        return templates.TemplateResponse(
            request,
            "settings/security.html",
            {
                "title": "Settings - Security",
                "user": user,
                "active_tab": "security",
                "is_admin": is_admin,
                "error": error,
            },
        )

    # Validate new password length
    if len(new_password) < 8:
        return render_with_error("New password must be at least 8 characters.")

    # Validate password confirmation
    if new_password != confirm_password:
        return render_with_error("New passwords do not match.")

    # Attempt password change
    auth_service = AuthService(db)
    success, error_message = auth_service.change_password(
        user,
        current_password,
        new_password,
        auth_session.id,
        request.client.host if request.client else None,
        request.headers.get("user-agent"),
    )

    if not success:
        return render_with_error(error_message)

    logger.info("password changed", extra={"user_id": user.id})
    return redirect_with_message(
        "/settings/security", "Password changed successfully.", "info"
    )


# ---------------------------------------------------------------------------
# Personal: Appearance
# ---------------------------------------------------------------------------


@router.get("/settings/appearance", response_class=HTMLResponse)
def settings_appearance(
    request: Request,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> Response:
    """Display the Appearance settings tab."""
    if not auth_session:
        return redirect_with_message("/login", "Please sign in to continue.", "warning")

    user = db.query(models.User).filter(models.User.id == auth_session.user_id).one()
    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "settings/appearance.html",
        {
            "title": "Settings - Appearance",
            "flash": get_flash_message(request),
            "user": user,
            "active_tab": "appearance",
            "is_admin": _is_admin(user),
        },
    )


@router.post("/settings/appearance", response_class=HTMLResponse)
def settings_appearance_submit(
    request: Request,
    theme_preference: str = Form(...),
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> Response:
    """Update user's theme preference."""
    if not auth_session:
        return redirect_with_message("/login", "Please sign in to continue.", "warning")

    user = db.query(models.User).filter(models.User.id == auth_session.user_id).one()
    is_admin = _is_admin(user)
    templates = request.app.state.templates

    # Validate theme preference
    valid_themes = ["light", "dark", "auto"]
    if theme_preference not in valid_themes:
        return templates.TemplateResponse(
            request,
            "settings/appearance.html",
            {
                "title": "Settings - Appearance",
                "user": user,
                "active_tab": "appearance",
                "is_admin": is_admin,
                "error": "Invalid theme preference.",
            },
        )

    # Update theme preference
    user.theme_preference = theme_preference
    db.commit()

    logger.info(
        "theme preference updated",
        extra={"user_id": user.id, "theme_preference": theme_preference},
    )
    return redirect_with_message(
        "/settings/appearance", "Theme preference updated successfully.", "info"
    )


# ---------------------------------------------------------------------------
# Organisation: Installation
# ---------------------------------------------------------------------------


@router.get("/settings/installation", response_class=HTMLResponse)
def settings_installation(
    request: Request,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> Response:
    """Display installation/runtime settings (admin only)."""
    if not auth_session:
        return redirect_with_message("/login", "Please sign in to continue.", "warning")

    user = db.query(models.User).filter(models.User.id == auth_session.user_id).one()
    redirect = _require_admin_or_redirect(user)
    if redirect:
        return redirect

    from governor_web.setup.service import SetupService

    setup_state = SetupService(db).ensure_state(admin_user_id=user.id)
    return _render_installation_page(request, user, setup_state)


@router.post("/settings/installation", response_class=HTMLResponse)
async def settings_installation_submit(
    request: Request,
    installation_mode: str = Form("cloud"),
    gcp_auth_method: str = Form("json"),
    bigquery_region: str = Form(""),
    credentials_json: str = Form(""),
    credentials_file: UploadFile | None = None,
    github_auth_mode: str = Form(""),
    app_id: str = Form(""),
    installation_id: str = Form(""),
    private_key: str = Form(""),
    personal_access_token: str = Form(""),
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> Response:
    """Save installation/runtime settings (admin only)."""
    from governor_core.core.config import is_local_mode

    if not auth_session:
        return redirect_with_message("/login", "Please sign in to continue.", "warning")

    user = db.query(models.User).filter(models.User.id == auth_session.user_id).one()
    if not _is_admin(user):
        raise HTTPException(status_code=403)

    from governor_web.setup.loader import load_setup_state
    from governor_web.setup.service import SetupService

    svc = SetupService(db)
    setup_state = svc.ensure_state(admin_user_id=user.id)
    local_runtime_mode = is_local_mode()

    installation_mode = installation_mode.strip() or "cloud"
    gcp_auth_method = gcp_auth_method.strip() or "json"
    github_auth_mode = github_auth_mode.strip() or (
        "disabled" if local_runtime_mode else "app"
    )
    bigquery_region = bigquery_region.strip()

    raw_credentials_json = credentials_json.strip()
    if credentials_file and credentials_file.filename:
        content = await credentials_file.read()
        raw_credentials_json = content.decode("utf-8", errors="replace").strip()

    form_data = {
        "installation_mode": installation_mode,
        "gcp_auth_method": gcp_auth_method,
        "bigquery_region": bigquery_region,
        "credentials_json": raw_credentials_json,
        "github_auth_mode": github_auth_mode,
        "app_id": app_id.strip(),
        "installation_id": installation_id.strip(),
        "private_key": private_key.strip(),
        "personal_access_token": personal_access_token.strip(),
    }
    errors: dict[str, str] = {}

    if installation_mode not in {"cloud", "local_dev"}:
        errors["installation_mode"] = "Choose a valid installation mode."
    if gcp_auth_method not in {"json", "adc"}:
        errors["gcp_auth_method"] = "Choose a valid Google Cloud authentication mode."
    if not bigquery_region:
        errors["bigquery_region"] = "BigQuery region is required."
    if github_auth_mode not in {"app", "personal_token", "disabled"}:
        errors["github_auth_mode"] = "Choose a valid GitHub authentication mode."

    resolved_gcp_credentials_json = setup_state.gcp_credentials_json
    if "gcp_auth_method" not in errors and gcp_auth_method == "json":
        if raw_credentials_json:
            from governor_web.setup.gcp_verify import verify_gcp_roles

            try:
                role_results = verify_gcp_roles(raw_credentials_json)
            except (ValueError, RuntimeError) as exc:
                errors["gcp_credentials_json"] = str(exc)
            else:
                missing_roles = [
                    role_id
                    for role_id, is_present in role_results.items()
                    if not is_present
                ]
                if missing_roles:
                    errors["gcp_credentials_json"] = (
                        "Service account is missing required IAM roles: "
                        + ", ".join(missing_roles)
                    )
                else:
                    resolved_gcp_credentials_json = raw_credentials_json
        elif setup_state.gcp_auth_method == "json" and setup_state.gcp_credentials_json:
            resolved_gcp_credentials_json = setup_state.gcp_credentials_json
        else:
            errors["gcp_credentials_json"] = (
                "Paste your service account JSON or upload the file."
            )
    elif gcp_auth_method == "adc":
        resolved_gcp_credentials_json = None

    resolved_github_app_id = None
    resolved_github_installation_id = None
    resolved_github_private_key = None
    resolved_github_personal_access_token = None

    if "github_auth_mode" not in errors:
        if github_auth_mode == "disabled":
            pass
        elif github_auth_mode == "personal_token":
            from governor_core.github.client import (
                GitHubAuthenticationError,
                GitHubConfigurationError,
                GitHubConnectionError,
                GitHubRateLimitError,
                GitHubTokenClient,
            )

            resolved_github_personal_access_token = form_data[
                "personal_access_token"
            ] or (
                setup_state.github_personal_access_token
                if setup_state.github_auth_mode == "personal_token"
                else None
            )
            if not resolved_github_personal_access_token:
                errors["personal_access_token"] = (
                    "GitHub personal access token is required."
                )
            else:
                token_changed = (
                    github_auth_mode != setup_state.github_auth_mode
                    or bool(form_data["personal_access_token"])
                )
                if token_changed:
                    try:
                        client = GitHubTokenClient(
                            resolved_github_personal_access_token
                        )
                        client.verify_token_connectivity()
                    except (
                        GitHubConfigurationError,
                        GitHubAuthenticationError,
                    ) as exc:
                        errors["github"] = str(exc)
                    except (GitHubConnectionError, GitHubRateLimitError) as exc:
                        errors["github"] = str(exc)
        else:
            from governor_core.github.client import (
                GitHubAppClient,
                GitHubAuthenticationError,
                GitHubConfigurationError,
                GitHubConnectionError,
            )

            resolved_github_app_id = form_data["app_id"] or (
                setup_state.github_app_id
                if setup_state.github_auth_mode == "app"
                else None
            )
            resolved_github_installation_id = form_data["installation_id"] or (
                setup_state.github_installation_id
                if setup_state.github_auth_mode == "app"
                else None
            )
            resolved_github_private_key = form_data["private_key"] or (
                setup_state.github_private_key
                if setup_state.github_auth_mode == "app"
                else None
            )

            if not resolved_github_app_id:
                errors["app_id"] = "GitHub App ID is required."
            if not resolved_github_installation_id:
                errors["installation_id"] = "Installation ID is required."
            if not resolved_github_private_key:
                errors["private_key"] = "Private key PEM is required."

            app_changed = github_auth_mode != setup_state.github_auth_mode or bool(
                form_data["app_id"]
                or form_data["installation_id"]
                or form_data["private_key"]
            )
            if not errors and app_changed:
                try:
                    client = GitHubAppClient(
                        app_id=resolved_github_app_id or "",
                        private_key=resolved_github_private_key or "",
                        installation_id=resolved_github_installation_id or "",
                    )
                    client.verify_app_connectivity()
                except (
                    GitHubConfigurationError,
                    GitHubAuthenticationError,
                ) as exc:
                    errors["github"] = str(exc)
                except GitHubConnectionError as exc:
                    errors["github"] = str(exc)
                except (ValueError, RuntimeError) as exc:
                    errors["github"] = f"Connectivity check failed: {exc}"

    if errors:
        return _render_installation_page(
            request,
            user,
            setup_state,
            form_data=form_data,
            errors=errors,
            status_code=422,
        )

    svc.save_installation_settings(
        installation_mode=installation_mode,
        gcp_auth_method=gcp_auth_method,
        gcp_credentials_json=resolved_gcp_credentials_json,
        bigquery_region=bigquery_region,
        github_auth_mode=github_auth_mode,
        github_app_id=resolved_github_app_id,
        github_installation_id=resolved_github_installation_id,
        github_private_key=resolved_github_private_key,
        github_personal_access_token=resolved_github_personal_access_token,
    )
    load_setup_state(request.app, db)

    return redirect_with_message(
        "/settings/installation",
        "Installation settings saved.",
        "info",
    )


# ---------------------------------------------------------------------------
# Organisation: AI / LLM
# ---------------------------------------------------------------------------


@router.get("/settings/llm", response_class=HTMLResponse)
def settings_llm(
    request: Request,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> Response:
    """Display the LLM configuration page (admin only)."""
    if not auth_session:
        return redirect_with_message("/login", "Please sign in to continue.", "warning")

    user = db.query(models.User).filter(models.User.id == auth_session.user_id).one()
    redirect = _require_admin_or_redirect(user)
    if redirect:
        return redirect

    from governor_web.core.config import get_settings
    from governor_web.settings.service import OrganisationSettingsService
    from governor_web.setup.runtime import get_runtime_llm_api_key

    settings = get_settings()
    org_service = OrganisationSettingsService(db)

    api_key = get_runtime_llm_api_key()
    api_key_masked = None
    if api_key:
        api_key_masked = "••••••••" + api_key[-4:] if len(api_key) > 4 else "••••"

    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "settings/llm.html",
        {
            "title": "Settings - AI / LLM",
            "user": user,
            "active_tab": "llm",
            "is_admin": True,
            "flash": get_flash_message(request),
            "provider": settings.llm_provider,
            "api_key_set": bool(api_key),
            "api_key_masked": api_key_masked,
            "model": org_service.get_value("llm_model", settings.llm_model),
            "routing_model": org_service.get_value(
                "gemini_routing_model", settings.gemini_routing_model
            ),
            "temperature": org_service.get_value(
                "llm_temperature", str(settings.llm_temperature)
            ),
            "max_tokens": org_service.get_value(
                "llm_max_tokens", str(settings.llm_max_tokens)
            ),
            "timeout_ms": org_service.get_value(
                "llm_timeout_ms", str(settings.llm_timeout_ms)
            ),
        },
    )


@router.post("/settings/llm", response_class=HTMLResponse)
async def settings_llm_submit(
    request: Request,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> Response:
    """Save LLM configuration (admin only)."""
    if not auth_session:
        return redirect_with_message("/login", "Please sign in to continue.", "warning")

    user = db.query(models.User).filter(models.User.id == auth_session.user_id).one()
    if not _is_admin(user):
        raise HTTPException(status_code=403)

    from governor_web.settings.service import OrganisationSettingsService

    form = dict(await request.form())
    org_service = OrganisationSettingsService(db)

    # Update API key if provided
    new_key = (form.get("llm_api_key") or "").strip()
    if new_key:
        from governor_web.setup.models import SetupState

        setup = db.query(SetupState).first()
        if setup:
            setup.llm_api_key = new_key
            db.commit()
            # Update runtime state so key takes effect immediately. The runtime
            # dataclass is frozen, so build a replacement and rebind via the
            # public setter rather than mutating in place.
            import dataclasses

            import governor_web.setup.runtime as runtime

            runtime.set_runtime_setup_state(
                dataclasses.replace(runtime.get_runtime_setup_state(), llm_api_key=new_key)
            )

    # Save model/parameter settings
    for key in ("llm_model", "gemini_routing_model", "llm_temperature", "llm_max_tokens", "llm_timeout_ms"):
        value = (form.get(key) or "").strip()
        if value:
            org_service.set(key, value, user.id)

    return redirect_with_message("/settings/llm", "LLM configuration saved.", "info")


# ---------------------------------------------------------------------------
# Organisation: Auto-PR Submission (US1)
# ---------------------------------------------------------------------------


@router.get("/settings/auto-pr", response_class=HTMLResponse)
def settings_auto_pr(
    request: Request,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> Response:
    """Display the Auto-PR Submission settings page (admin only)."""
    from governor_core.core.config import is_local_mode

    if is_local_mode():
        return redirect_with_message("/settings", "Auto-PR is not available in local mode.", "info")
    if not auth_session:
        return redirect_with_message("/login", "Please sign in to continue.", "warning")

    user = db.query(models.User).filter(models.User.id == auth_session.user_id).one()
    redirect = _require_admin_or_redirect(user)
    if redirect:
        return redirect

    from governor_web.settings.service import OrganisationSettingsService

    org_service = OrganisationSettingsService(db)
    current_threshold = org_service.get_value(
        "auto_pr_trust_tier_threshold", "disabled"
    )

    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "settings/auto_pr.html",
        {
            "title": "Settings - Auto-PR Submission",
            "user": user,
            "active_tab": "auto_pr",
            "is_admin": True,
            "flash": get_flash_message(request),
            "current_threshold": current_threshold,
        },
    )


@router.post("/settings/auto-pr", response_class=HTMLResponse)
async def settings_auto_pr_submit(
    request: Request,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> Response:
    """Save the Auto-PR trust tier threshold (admin only)."""
    from governor_core.core.config import is_local_mode

    if is_local_mode():
        raise HTTPException(status_code=404)
    if not auth_session:
        return redirect_with_message("/login", "Please sign in to continue.", "warning")

    user = db.query(models.User).filter(models.User.id == auth_session.user_id).one()
    if not _is_admin(user):
        raise HTTPException(status_code=403)

    form = dict(await request.form())
    value = form.get("auto_pr_trust_tier_threshold", "").strip()

    valid_values = ("disabled", "guaranteed_safe", "validated", "requires_review")
    if value not in valid_values:
        from governor_web.settings.service import OrganisationSettingsService

        org_service = OrganisationSettingsService(db)
        current_threshold = org_service.get_value(
            "auto_pr_trust_tier_threshold", "disabled"
        )
        templates = request.app.state.templates
        return templates.TemplateResponse(
            request,
            "settings/auto_pr.html",
            {
                "title": "Settings - Auto-PR Submission",
                "user": user,
                "active_tab": "auto_pr",
                "is_admin": True,
                "current_threshold": current_threshold,
                "error": "Invalid trust tier threshold value.",
            },
        )

    from governor_web.settings.service import OrganisationSettingsService

    org_service = OrganisationSettingsService(db)
    org_service.set("auto_pr_trust_tier_threshold", value, user.id)

    return redirect_with_message(
        "/settings/auto-pr", "Auto-PR submission setting saved.", "info"
    )


# ---------------------------------------------------------------------------
# Organisation: Verification (US4)
# ---------------------------------------------------------------------------


@router.get("/settings/verification", response_class=HTMLResponse)
def settings_verification(
    request: Request,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> Response:
    """Display the Verification page within Settings (admin only)."""
    if not auth_session:
        return redirect_with_message("/login", "Please sign in to continue.", "warning")

    user = db.query(models.User).filter(models.User.id == auth_session.user_id).one()
    redirect = _require_admin_or_redirect(user)
    if redirect:
        return redirect

    from governor_core.core.config import is_local_mode
    from governor_web.setup.runtime import resolve_github_configuration
    from governor_web.verification.service import VerificationService

    service = VerificationService(db)
    system_status = service.get_system_status()
    runs = service.list_runs()

    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "settings/verification.html",
        {
            "title": "Settings - Verification",
            "user": user,
            "active_tab": "verification",
            "is_admin": True,
            "system_status": system_status.status.value,
            "runs": runs,
            "github_configured": resolve_github_configuration() is not None,
        },
    )


@router.post("/settings/verification/run")
def settings_verification_run(
    request: Request,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> StreamingResponse:
    """Run verification via SSE within Settings (admin only)."""
    if not auth_session:
        raise HTTPException(status_code=401)

    user = db.query(models.User).filter(models.User.id == auth_session.user_id).one()
    if not _is_admin(user):
        raise HTTPException(status_code=403)

    from datastar_py import SSE_HEADERS
    from datastar_py.consts import ElementPatchMode
    from datastar_py.sse import ServerSentEventGenerator as SSEGenerator

    from governor_web.verification.runner import compute_overall_status, run_all_checks
    from governor_web.verification.service import VerificationService

    service = VerificationService(db)
    environment = "production"

    def _generate() -> Generator[str, None, None]:
        run = service.create_run(admin_user_id=user.id, environment=environment)
        templates = request.app.state.templates

        results = run_all_checks()
        for result in results:
            service.save_check_result(run, result)

            html = templates.get_template("verification/_check_result.html").render(
                check=result
            )

            yield str(
                SSEGenerator.patch_elements(
                    html,
                    selector=f"#check-{result.check_type}",
                    mode=ElementPatchMode.OUTER,
                )
            )

        overall = compute_overall_status(results)
        service.complete_run(run, overall)

        status_class = {
            "ready": "text-brand-300 border-brand-500/30 bg-brand-700/40",
            "not_ready": "text-red-400 border-red-500/30 bg-red-950/40",
            "error": "text-amber-400 border-amber-500/30 bg-amber-950/40",
        }.get(overall, "text-slate-400 border-slate-500/30 bg-slate-950/40")
        status_label = overall.replace("_", " ").title()

        overall_html = (
            f'<div id="overall-status" '
            f'class="mt-6 rounded-xl border p-4 text-center text-lg font-semibold {status_class}">'
            f"Overall: {status_label}</div>"
        )
        yield str(
            SSEGenerator.patch_elements(
                overall_html,
                selector="#overall-status",
                mode=ElementPatchMode.OUTER,
            )
        )

    return StreamingResponse(_generate(), headers=SSE_HEADERS)


@router.get("/settings/verification/run/{run_id}", response_class=HTMLResponse)
def settings_verification_run_detail(
    run_id: str,
    request: Request,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> Response:
    """Display verification run detail within Settings (admin only)."""
    if not auth_session:
        return redirect_with_message("/login", "Please sign in to continue.", "warning")

    user = db.query(models.User).filter(models.User.id == auth_session.user_id).one()
    redirect = _require_admin_or_redirect(user)
    if redirect:
        return redirect

    from governor_web.verification.service import VerificationService

    service = VerificationService(db)
    run = service.get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Verification run not found.")

    result = service.run_to_result(run)
    system_status = service.get_system_status()
    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "settings/verification_run_detail.html",
        {
            "title": f"Verification Run {run_id[:8]}",
            "user": user,
            "active_tab": "verification",
            "is_admin": True,
            "result": result,
            "system_status": system_status.status.value,
        },
    )
