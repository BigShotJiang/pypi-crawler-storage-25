from __future__ import annotations

import logging
from collections.abc import Generator

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse, StreamingResponse
from sqlalchemy.orm import Session
from starlette.responses import Response

from governor_web.auth.dependencies import require_role
from governor_web.auth.models import User
from governor_core.configurations.models import ManifestConfiguration
from governor_core.core.config import is_local_mode
from governor_core.db.session import get_session
from governor_web.routes.helpers import redirect_local_mode_feature
from governor_web.scheduling.description import describe_schedule
from governor_web.scheduling.service import SchedulingService
from governor_core.utils.pagination import PaginationContext

logger = logging.getLogger("app.schedules")

router = APIRouter()


def _redirect_local_schedule_management() -> Response:
    return redirect_local_mode_feature(
        "/admin/configurations",
        feature_name="Sync schedules",
        guidance="Local mode does not expose background schedule management.",
    )


def _get_all_next_run_times(scheduler, config_ids: list[str]) -> dict[str, object]:
    """Batch-fetch next run times for all configs from the scheduler.

    APScheduler stores jobs in memory — this avoids N individual get_job()
    calls by iterating the scheduler's job list once.
    """
    if not scheduler:
        return {}

    try:
        jobs = scheduler.get_jobs()
    except ValueError, RuntimeError:
        return {}

    prefix = "sync-"
    result: dict[str, object] = {}
    config_id_set = set(config_ids)
    for job in jobs:
        if not job.id.startswith(prefix):
            continue
        cid = job.id[len(prefix) :]
        if cid in config_id_set:
            result[cid] = job.next_run_time
    return result


def _build_schedule_list(db: Session, scheduler) -> list[dict]:
    """Build list of schedule dicts for template rendering."""
    configs = db.query(ManifestConfiguration).order_by(ManifestConfiguration.name).all()

    # Batch-fetch all next run times in a single pass
    next_run_times = _get_all_next_run_times(scheduler, [c.id for c in configs])

    schedules = []
    for c in configs:
        schedules.append(
            {
                "config_id": c.id,
                "config_name": c.name,
                "gcp_project_id": c.gcp_project_id,
                "schedule_type": c.schedule_type,
                "schedule_value": c.schedule_value,
                "schedule_description": describe_schedule(
                    c.schedule_type, c.schedule_value
                ),
                "schedule_enabled": c.schedule_enabled,
                "schedule_last_run_at": c.schedule_last_run_at,
                "next_run_time": next_run_times.get(c.id),
                "config_status": c.status,
            }
        )
    return schedules


def _sort_schedules(schedules: list[dict], sort_col: str, direction: str) -> list[dict]:
    """Sort schedule list by column."""
    reverse = direction == "desc"
    key_map = {
        "config_name": lambda s: (s["config_name"] or "").lower(),
        "schedule_type": lambda s: s["schedule_type"],
        "schedule_enabled": lambda s: 0 if s["schedule_enabled"] else 1,
        "schedule_last_run_at": lambda s: s["schedule_last_run_at"] or "",
        "next_run_time": lambda s: s["next_run_time"] or "",
    }
    key_fn = key_map.get(sort_col, key_map["config_name"])
    return sorted(schedules, key=key_fn, reverse=reverse)


def _filter_schedules(schedules: list[dict], search: str) -> list[dict]:
    """Filter schedules by search text."""
    if not search:
        return schedules
    q = search.lower()
    return [
        s
        for s in schedules
        if q in (s["config_name"] or "").lower()
        or q in (s["gcp_project_id"] or "").lower()
    ]


@router.get("/admin/schedules", response_class=HTMLResponse)
def schedule_management(
    request: Request,
    user: User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> Response:
    if is_local_mode():
        return _redirect_local_schedule_management()

    scheduler = getattr(request.app.state, "scheduler", None)
    all_schedules = _build_schedule_list(db, scheduler)

    page_size = 10
    pagination = PaginationContext(
        page=1, page_size=page_size, total_items=len(all_schedules)
    )
    page_schedules = all_schedules[:page_size]

    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "schedules/management.html",
        {
            "title": "Sync Schedules",
            "user": user,
            "schedules": page_schedules,
            "pagination": pagination,
        },
    )


@router.get("/admin/schedules/filter")
async def schedule_filter(
    request: Request,
    user: User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> StreamingResponse:
    if is_local_mode():
        return _redirect_local_schedule_management()

    from datastar_py import SSE_HEADERS
    from datastar_py.consts import ElementPatchMode
    from datastar_py.fastapi import read_signals
    from datastar_py.sse import ServerSentEventGenerator as SSEGenerator

    signals = await read_signals(request)
    sort_col = (signals or {}).get("schSort", "config_name")
    direction = (signals or {}).get("schDirection", "asc")
    search = (signals or {}).get("schSearch", "")
    page = int((signals or {}).get("schPage", 1))

    scheduler = getattr(request.app.state, "scheduler", None)
    all_schedules = _build_schedule_list(db, scheduler)
    all_schedules = _filter_schedules(all_schedules, search)
    all_schedules = _sort_schedules(all_schedules, sort_col, direction)

    page_size = 10
    pagination = PaginationContext(
        page=max(1, page), page_size=page_size, total_items=len(all_schedules)
    )
    if pagination.page > pagination.total_pages:
        pagination = PaginationContext(
            page=pagination.total_pages,
            page_size=page_size,
            total_items=len(all_schedules),
        )
    offset = (pagination.page - 1) * page_size
    schedules = all_schedules[offset : offset + page_size]

    def _generate() -> Generator[str, None, None]:
        templates = request.app.state.templates
        html = templates.get_template("schedules/_table.html").render(
            schedules=schedules,
            pagination=pagination,
        )
        yield str(
            SSEGenerator.patch_elements(
                html,
                selector="#schedule-table-body",
                mode=ElementPatchMode.OUTER,
            )
        )

    return StreamingResponse(_generate(), headers=SSE_HEADERS)


@router.post("/admin/schedules/{config_id}/toggle")
async def schedule_toggle(
    config_id: str,
    request: Request,
    user: User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> StreamingResponse:
    if is_local_mode():
        return _redirect_local_schedule_management()

    from datetime import datetime, timezone

    from datastar_py import SSE_HEADERS
    from datastar_py.consts import ElementPatchMode
    from datastar_py.sse import ServerSentEventGenerator as SSEGenerator

    config = (
        db.query(ManifestConfiguration)
        .filter(ManifestConfiguration.id == config_id)
        .one_or_none()
    )
    if not config:
        raise HTTPException(status_code=404, detail="Configuration not found.")

    # Cannot enable schedule for disabled config
    if config.status == "disabled" and not config.schedule_enabled:
        raise HTTPException(
            status_code=400,
            detail="Cannot enable schedule for a disabled configuration.",
        )

    # Toggle
    config.schedule_enabled = not config.schedule_enabled
    config.updated_by_id = user.id
    config.updated_at = datetime.now(timezone.utc)
    db.commit()

    scheduler = getattr(request.app.state, "scheduler", None)
    if scheduler:
        if config.schedule_enabled:
            SchedulingService.register_schedule(scheduler, config)
        else:
            SchedulingService.pause_schedule(scheduler, config_id)

    # Build row data
    next_run = (
        SchedulingService.get_next_run_time(scheduler, config.id) if scheduler else None
    )
    row = {
        "config_id": config.id,
        "config_name": config.name,
        "gcp_project_id": config.gcp_project_id,
        "schedule_type": config.schedule_type,
        "schedule_value": config.schedule_value,
        "schedule_description": describe_schedule(
            config.schedule_type, config.schedule_value
        ),
        "schedule_enabled": config.schedule_enabled,
        "schedule_last_run_at": config.schedule_last_run_at,
        "next_run_time": next_run,
        "config_status": config.status,
    }

    def _generate() -> Generator[str, None, None]:
        templates = request.app.state.templates
        html = templates.get_template("schedules/_row.html").render(s=row)
        yield str(
            SSEGenerator.patch_elements(
                html,
                selector=f"#schedule-row-{config_id}",
                mode=ElementPatchMode.OUTER,
            )
        )

    return StreamingResponse(_generate(), headers=SSE_HEADERS)
