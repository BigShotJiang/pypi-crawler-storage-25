from __future__ import annotations

from typing import Any
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from fastapi import Request
from fastapi.responses import RedirectResponse


def add_message_to_url(
    url: str,
    message: str,
    level: str = "info",
    *,
    action_url: str | None = None,
    action_label: str | None = None,
) -> str:
    parsed = urlparse(url)
    params = parse_qsl(parsed.query, keep_blank_values=True)
    params.extend([("message", message), ("level", level)])
    if action_url:
        params.append(("action_url", action_url))
    if action_label:
        params.append(("action_label", action_label))
    query_string = urlencode(params, doseq=True)
    return urlunparse(parsed._replace(query=query_string))


def redirect_with_message(
    url: str,
    message: str,
    level: str = "info",
    *,
    action_url: str | None = None,
    action_label: str | None = None,
) -> RedirectResponse:
    return RedirectResponse(
        add_message_to_url(
            url,
            message,
            level,
            action_url=action_url,
            action_label=action_label,
        ),
        status_code=302,
    )


def redirect_local_mode_feature(
    url: str,
    *,
    feature_name: str,
    guidance: str | None = None,
) -> RedirectResponse:
    message = f"{feature_name} is not used in local mode."
    if guidance:
        message = f"{message} {guidance}"
    return redirect_with_message(url, message, "info")


def get_flash_message(request: Request) -> dict[str, Any] | None:
    message = request.query_params.get("message")
    level = request.query_params.get("level", "info")
    if not message:
        return None
    flash = {"message": message, "level": level}
    action_url = request.query_params.get("action_url")
    action_label = request.query_params.get("action_label")
    if action_url:
        flash["action_url"] = action_url
    if action_label:
        flash["action_label"] = action_label
    return flash


def resolve_display_gcp_project_id(config: Any) -> str | None:
    """Return the GCP project id the UI should display for a configuration."""
    from governor_core.core.config import is_local_mode

    if not is_local_mode():
        return getattr(config, "gcp_project_id", None)

    local_project_path = getattr(config, "local_project_path", None)
    if not local_project_path:
        return None

    from governor_core.workspace.detection import (
        infer_gcp_project_from_run_results,
        read_local_run_results,
    )

    return infer_gcp_project_from_run_results(
        read_local_run_results(local_project_path)
    )


def build_display_gcp_project_map(configurations: list[Any]) -> dict[str, str | None]:
    return {
        config.id: resolve_display_gcp_project_id(config) for config in configurations
    }
