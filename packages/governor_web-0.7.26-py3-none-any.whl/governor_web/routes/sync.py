"""
Sync operation API routes.

Provides endpoints for triggering syncs, retrieving sync status, and streaming
real-time updates via Server-Sent Events.
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Generator
from typing import AsyncGenerator

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import JSONResponse, StreamingResponse
from sqlalchemy.orm import Session
from starlette.responses import Response

from governor_web.auth.dependencies import require_role
from governor_web.auth.models import User
from governor_core.configurations.service import (
    ManifestConfigurationService,
)
from governor_core.db.session import get_session
from governor_core.sync.schemas import SyncOperationOut, SyncOperationSummary
from governor_core.sync.service import DuplicateSyncError, SyncService

logger = logging.getLogger("app.sync")

router = APIRouter()
configurations_router = APIRouter()  # For /api/configurations endpoints


# ---------------------------------------------------------------------------
# US1: Admin initiates sync
# ---------------------------------------------------------------------------


@router.post("/{config_id}")
def create_sync(
    config_id: str,
    request: Request,
    user: User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> StreamingResponse:
    """Trigger a new sync operation for a configuration.

    Args:
        config_id: ID of the project sync configuration
        request: FastAPI request object
        user: Authenticated admin user
        db: Database session

    Returns:
        Datastar SSE fragment that updates the sync status display

    Status Codes:
        200: Sync created successfully
        404: Configuration not found
        409: Duplicate sync already queued/in_progress

    Specification Reference:
        FR-003: System MUST prevent duplicate concurrent syncs for the same configuration.
    """
    from datastar_py import SSE_HEADERS
    from datastar_py.consts import ElementPatchMode
    from datastar_py.sse import ServerSentEventGenerator as SSEGenerator

    # Verify configuration exists and is active
    config_service = ManifestConfigurationService(db)
    config = config_service.get_configuration(config_id)
    if not config:
        raise HTTPException(status_code=404, detail="Configuration not found")
    if config.status != "active":
        raise HTTPException(
            status_code=400, detail="Cannot sync disabled configuration"
        )

    # Create sync operation with duplicate prevention
    sync_service = SyncService(db)
    try:
        sync = sync_service.create_sync_operation(config_id, user.id)
    except DuplicateSyncError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc

    # Return datastar fragment to update sync status display
    def _generate() -> Generator[str, None, None]:
        templates = request.app.state.templates
        html = templates.get_template("sync/_sync_status_container.html").render(
            sync=sync,
            config_id=config_id,
        )

        yield str(
            SSEGenerator.patch_elements(
                html,
                selector="#sync-status-container",
                mode=ElementPatchMode.OUTER,
            )
        )

    return StreamingResponse(_generate(), headers=SSE_HEADERS)


@router.get("/{sync_id}", response_class=JSONResponse)
def get_sync(
    sync_id: str,
    user: User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> dict:
    """Retrieve sync operation details with errors.

    Args:
        sync_id: ID of the sync operation
        user: Authenticated admin user
        db: Database session

    Returns:
        JSON response with sync operation details including errors

    Status Codes:
        200: Sync found and returned
        404: Sync not found
    """
    sync_service = SyncService(db)
    sync = sync_service.get_sync_operation(sync_id)
    if not sync:
        raise HTTPException(status_code=404, detail="Sync operation not found")

    return SyncOperationOut.model_validate(sync).model_dump(mode="json")


@router.get("/{sync_id}/status")
async def sync_status_stream(
    sync_id: str,
    user: User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> StreamingResponse:
    """Stream real-time sync status updates via Server-Sent Events.

    Polls the sync operation status every 2 seconds and streams updates
    until the sync reaches a terminal state (completed or failed).

    Args:
        sync_id: ID of the sync operation
        user: Authenticated admin user
        db: Database session

    Returns:
        SSE stream with JSON status updates

    SSE Event Format:
        event: status
        data: {"status": "queued|in_progress|completed|failed", "sync_id": "..."}

    Status Codes:
        200: Stream started
        404: Sync not found

    Example Client Usage (JavaScript):
        const eventSource = new EventSource('/api/sync/{sync_id}/status');
        eventSource.addEventListener('status', (e) => {
            const data = JSON.parse(e.data);
            console.log('Status:', data.status);
            if (['completed', 'failed'].includes(data.status)) {
                eventSource.close();
            }
        });
    """
    from datastar_py import SSE_HEADERS

    # Verify sync exists
    sync_service = SyncService(db)
    sync = sync_service.get_sync_operation(sync_id)
    if not sync:
        raise HTTPException(status_code=404, detail="Sync operation not found")

    async def _generate_status_updates() -> AsyncGenerator[str, None]:
        """Generate SSE status updates until sync completes."""
        terminal_states = {"completed", "failed"}
        last_status = None

        while True:
            # Refresh sync from database
            db.expire(sync)
            current_status = sync.status

            # Send update if status changed
            if current_status != last_status:
                event_data = {
                    "status": current_status,
                    "sync_id": sync_id,
                    "queued_at": sync.queued_at.isoformat() if sync.queued_at else None,
                    "started_at": sync.started_at.isoformat()
                    if sync.started_at
                    else None,
                    "completed_at": sync.completed_at.isoformat()
                    if sync.completed_at
                    else None,
                    "jobs_retrieved_count": sync.jobs_retrieved_count,
                    "manifests_updated_count": sync.manifests_updated_count,
                }

                # Format as SSE
                import json

                yield "event: status\n"
                yield f"data: {json.dumps(event_data)}\n\n"

                last_status = current_status

                # Stop streaming if terminal state reached
                if current_status in terminal_states:
                    logger.info(
                        "Sync %s reached terminal state: %s", sync_id, current_status
                    )
                    break

            # Poll every 2 seconds
            await asyncio.sleep(2)

    return StreamingResponse(
        _generate_status_updates(),
        media_type="text/event-stream",
        headers=SSE_HEADERS,
    )


# ---------------------------------------------------------------------------
# US4: Sync history for configuration
# ---------------------------------------------------------------------------


@configurations_router.get(
    "/api/configurations/{config_id}/syncs", response_class=JSONResponse
)
def get_configuration_syncs(
    config_id: str,
    limit: int = 50,
    offset: int = 0,
    user: User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> list[dict]:
    """Get sync history for a configuration.

    Returns paginated list of sync operations for a project configuration,
    ordered by queued_at descending (newest first).

    Args:
        config_id: ID of the project sync configuration
        limit: Maximum number of syncs to return (default: 50, max: 100)
        offset: Number of syncs to skip for pagination (default: 0)
        user: Authenticated admin user
        db: Database session

    Returns:
        JSON array of SyncOperationSummary objects

    Status Codes:
        200: Success with sync list
        404: Configuration not found

    Query Parameters:
        - limit (int): Results per page (default: 50, max: 100)
        - offset (int): Pagination offset (default: 0)

    Example Response:
        [
          {
            "id": "sync-uuid",
            "config_id": "config-uuid",
            "config_name": "Analytics Project",
            "status": "completed",
            "queued_at": "2026-02-03T10:00:00Z",
            "started_at": "2026-02-03T10:00:05Z",
            "completed_at": "2026-02-03T10:02:30Z",
            "duration_seconds": 145
          }
        ]
    """
    # Verify configuration exists
    config_service = ManifestConfigurationService(db)
    config = config_service.get_configuration(config_id)
    if not config:
        raise HTTPException(status_code=404, detail="Configuration not found")

    # Enforce max limit
    limit = min(limit, 100)

    # Get sync history
    sync_service = SyncService(db)
    syncs = sync_service.get_syncs_for_config(config_id, limit=limit, offset=offset)

    # Convert to summary schemas
    summaries = []
    for sync in syncs:
        # Calculate duration if sync has started and completed
        duration_seconds = None
        if sync.started_at and sync.completed_at:
            duration_seconds = int(
                (sync.completed_at - sync.started_at).total_seconds()
            )

        summary = SyncOperationSummary(
            id=sync.id,
            config_id=sync.config_id,
            config_name=config.name,
            status=sync.status,
            queued_at=sync.queued_at,
            started_at=sync.started_at,
            completed_at=sync.completed_at,
            duration_seconds=duration_seconds,
        )
        summaries.append(summary)

    return [s.model_dump(mode="json") for s in summaries]


# ---------------------------------------------------------------------------
# US5: View stored BigQuery job data
# ---------------------------------------------------------------------------


@configurations_router.get(
    "/api/configurations/{config_id}/jobs", response_class=JSONResponse
)
def get_configuration_jobs(
    config_id: str,
    limit: int = 50,
    offset: int = 0,
    user_email: str | None = None,
    state: str | None = None,
    job_type: str | None = None,
    statement_type: str | None = None,
    cache_hit: bool | None = None,
    has_performance_insights: bool | None = None,
    start_date: str | None = None,
    end_date: str | None = None,
    user: User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> dict:
    """Get BigQuery jobs for a configuration with filtering.

    Returns paginated list of BigQuery jobs for a project configuration,
    ordered by creation_time descending (newest first).

    Args:
        config_id: ID of the project sync configuration
        limit: Maximum number of jobs to return (default: 50, max: 100)
        offset: Number of jobs to skip for pagination (default: 0)
        user_email: Filter by user email (partial match)
        state: Filter by job state (e.g., 'DONE', 'FAILED')
        job_type: Filter by job type (e.g., 'QUERY', 'LOAD')
        statement_type: Filter by statement type (e.g., 'SELECT', 'INSERT')
        cache_hit: Filter by cache hit status (true/false)
        has_performance_insights: Filter by presence of performance insights
        start_date: Filter jobs created on or after this date (ISO format)
        end_date: Filter jobs created on or before this date (ISO format)
        user: Authenticated admin user
        db: Database session

    Returns:
        JSON object with jobs array and pagination metadata

    Status Codes:
        200: Success with jobs list
        404: Configuration not found

    Specification Reference:
        US5: Admin views stored BigQuery job data with filtering.
    """
    from governor_core.sync.schemas import BigQueryJobOut

    # Verify configuration exists
    config_service = ManifestConfigurationService(db)
    config = config_service.get_configuration(config_id)
    if not config:
        raise HTTPException(status_code=404, detail="Configuration not found")

    # Enforce max limit
    limit = min(limit, 100)

    # Get jobs with filtering
    sync_service = SyncService(db)
    jobs = sync_service.get_bigquery_jobs(
        config_id,
        limit=limit,
        offset=offset,
        user_email=user_email,
        state=state,
        job_type=job_type,
        statement_type=statement_type,
        cache_hit=cache_hit,
        has_performance_insights=has_performance_insights,
        start_date=start_date,
        end_date=end_date,
    )

    # Get total count for pagination
    total = sync_service.get_bigquery_jobs_count(
        config_id,
        user_email=user_email,
        state=state,
        job_type=job_type,
        statement_type=statement_type,
        cache_hit=cache_hit,
        has_performance_insights=has_performance_insights,
        start_date=start_date,
        end_date=end_date,
    )

    # Convert to output schemas
    jobs_out = [
        BigQueryJobOut.model_validate(job).model_dump(mode="json") for job in jobs
    ]

    return {
        "jobs": jobs_out,
        "total": total,
        "limit": limit,
        "offset": offset,
    }
