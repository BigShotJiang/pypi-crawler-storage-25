from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session

from governor_web.auth.dependencies import get_active_session
from governor_web.auth.models import Session as AuthSession, User
from governor_core.db.session import get_session
from governor_web.notifications.service import NotificationService

router = APIRouter(tags=["notifications"])


def _get_user_from_session(
    auth_session: AuthSession | None = Depends(get_active_session),
    db: Session = Depends(get_session),
) -> User:
    if not auth_session:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)
    user = db.query(User).filter(User.id == auth_session.user_id).one_or_none()
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)
    return user


@router.get("/api/notifications", response_class=JSONResponse)
def get_notifications(
    user: User = Depends(_get_user_from_session),
    db: Session = Depends(get_session),
) -> dict:
    """Return unread count and recent notifications for the current user."""
    svc = NotificationService(db)
    unread_count = svc.get_unread_count(user.id)
    recent = svc.get_recent(user.id)
    return {
        "unread_count": unread_count,
        "notifications": [
            {
                "id": n.id,
                "event_type": n.event_type,
                "title": n.title,
                "body": n.body,
                "link": n.link,
                "read_at": n.read_at.isoformat() if n.read_at else None,
                "created_at": n.created_at.isoformat() if n.created_at else None,
            }
            for n in recent
        ],
    }


@router.post("/api/notifications/{notification_id}/read", response_class=JSONResponse)
def mark_notification_read(
    notification_id: str,
    user: User = Depends(_get_user_from_session),
    db: Session = Depends(get_session),
) -> dict:
    """Mark a single notification as read."""
    svc = NotificationService(db)
    svc.mark_as_read(notification_id, user.id)
    return {"ok": True}


@router.post("/api/notifications/read-all", response_class=JSONResponse)
def mark_all_notifications_read(
    user: User = Depends(_get_user_from_session),
    db: Session = Depends(get_session),
) -> dict:
    """Mark all unread notifications as read for the current user."""
    svc = NotificationService(db)
    count = svc.mark_all_as_read(user.id)
    return {"ok": True, "count": count}
