from __future__ import annotations

import logging
from collections.abc import Generator
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from urllib.parse import urlencode

from fastapi import APIRouter, Depends, Form, HTTPException, Query, Request
from fastapi.responses import (
    HTMLResponse,
    JSONResponse,
    RedirectResponse,
    StreamingResponse,
)
import sqlalchemy.exc
from sqlalchemy import false, func, or_
from sqlalchemy.orm import Session, selectinload
from starlette.responses import Response

from governor_web.auth import models
from governor_web.auth.dependencies import get_active_session
from governor_web.auth.service import AuthService
from governor_core.opportunities.historical_savings import (
    calculate_historical_possible_savings,
)
from governor_core.opportunities.catalog import (
    build_effective_rule_selection,
    get_detection_rule_catalog,
)
from governor_core.utils.formatters import apply_cost_multiplier, format_usd
from governor_web.dashboard.service import DashboardService
from governor_core.db.session import get_session
from governor_core.opportunities.presentation import (
    build_inherited_pending_savings_display,
    build_cost_display,
    derive_local_build_execution_mode,
    build_possible_savings_display,
    get_exact_local_workload_kinds,
    get_active_solution_job_statuses,
    get_last_job_details,
    get_last_job_costs,
    get_latest_solution_snapshots,
    sync_opportunity_solution_snapshots,
)
from governor_web.routes import errors
from governor_web.routes.dashboard import (
    _lens_label,
    _parse_cost_lens,
    _parse_date_range,
)
from governor_web.routes.helpers import (
    get_flash_message,
    redirect_with_message,
    resolve_display_gcp_project_id,
)
from governor_core.solutions.dry_run_policy import (
    solution_prefers_possible_savings_display,
    solution_supports_optimized_dry_run,
)
from governor_core.solutions.equivalence_sql import build_verification_sql_artifact
from governor_core.solutions.validation.report import (
    extract_template_id,
    has_blocking_dbt_verification_issue,
)
from governor_core.utils.pagination import PaginationContext

router = APIRouter()

_ALWAYS_HIDDEN_OPPORTUNITY_TYPES = (
    "storage_billing_optimization",
    "clustering",
    "clustering_not_leveraged",
)


def _get_project_rule_visibility(
    watched_rule_types: list[str] | None,
) -> tuple[tuple[str, ...], tuple[str, ...]]:
    catalog = get_detection_rule_catalog()
    known_rule_types = tuple(
        dict.fromkeys(
            [
                *(entry.rule_type.lower() for entry in catalog),
                *_ALWAYS_HIDDEN_OPPORTUNITY_TYPES,
            ]
        )
    )
    selection = build_effective_rule_selection(watched_rule_types, catalog)
    allowed_rule_types = tuple(
        rule_type.lower()
        for rule_type in selection.effective_rule_types
        if rule_type not in _ALWAYS_HIDDEN_OPPORTUNITY_TYPES
    )
    return known_rule_types, allowed_rule_types


def _build_visible_opportunity_filter_for_rule_types(
    watched_rule_types: list[str] | None,
) -> tuple:
    from governor_core.opportunities.models import Opportunity

    known_rule_types, visible_rule_types = _get_project_rule_visibility(
        watched_rule_types
    )
    opportunity_type_key = func.lower(Opportunity.opportunity_type)
    visible_rule_clause = (
        opportunity_type_key.in_(visible_rule_types) if visible_rule_types else false()
    )
    unknown_rule_clause = (
        ~opportunity_type_key.in_(known_rule_types) if known_rule_types else false()
    )
    return or_(visible_rule_clause, unknown_rule_clause), visible_rule_types


def _get_visible_opportunity_types_for_config(
    db: Session, config_id: str
) -> tuple[tuple[str, ...], tuple[str, ...]]:
    from governor_core.configurations.models import ManifestConfiguration

    config = db.get(ManifestConfiguration, config_id)
    if config is None:
        return (), ()
    return _get_project_rule_visibility(config.watched_rule_types)


def _is_local_execution_config(config: object | None) -> bool:
    """Return True when this config should use local-working-tree UX."""
    from governor_core.core.config import is_local_mode

    if not is_local_mode() or config is None:
        return False

    local_project_path = getattr(config, "local_project_path", None)
    manifest_source = getattr(config, "manifest_source", None)
    return bool(local_project_path or manifest_source in {"manual_upload", "local"})


def _build_local_commit_message(opportunity, solution) -> str:
    target = (
        getattr(opportunity, "dbt_model_name", None)
        or (solution.file_path.rsplit("/", 1)[-1] if solution.file_path else None)
        or getattr(opportunity, "affected_table", None)
        or "build-fix"
    )
    opportunity_type = getattr(opportunity, "opportunity_type", "build")
    return f"Governor: apply {opportunity_type} fix for {target}"


def _normalize_project_status_filter(
    opp_status: str, *, collapse_pending_states: bool = False
) -> str:
    """Normalize project opportunity status filters for the current UX."""
    if collapse_pending_states and opp_status == "clearing":
        return "pr_pending"
    return (
        opp_status
        if opp_status in ("active", "resolved", "pr_pending", "all")
        else "active"
    )


def _count_project_background_jobs(db: Session, config_id: str) -> dict[str, int]:
    from governor_core.opportunities.models import DetectionJob
    from governor_core.solutions.models import SolutionJob
    from governor_core.sync.models import SyncOperation

    active_statuses = ("queued", "in_progress")
    syncs = (
        db.query(func.count())
        .filter(
            SyncOperation.config_id == config_id,
            SyncOperation.status.in_(active_statuses),
        )
        .scalar()
        or 0
    )
    detections = (
        db.query(func.count())
        .filter(
            DetectionJob.config_id == config_id,
            DetectionJob.status.in_(active_statuses),
        )
        .scalar()
        or 0
    )
    solutions = (
        db.query(func.count())
        .filter(
            SolutionJob.config_id == config_id,
            SolutionJob.status.in_(active_statuses),
        )
        .scalar()
        or 0
    )
    return {
        "syncs": syncs,
        "detections": detections,
        "solutions": solutions,
        "total": syncs + detections + solutions,
    }


def _require_admin_user(
    request: Request, db: Session, auth_session
) -> tuple[models.User | None, Response | None]:
    """Return the authenticated admin user or an error response."""
    user = _get_authenticated_user(request, db, auth_session)
    if not user:
        return None, redirect_with_message(
            "/login",
            "Please sign in to continue.",
            "warning",
        )

    if any(role.name == "admin" for role in user.roles):
        return user, None

    auth_service = AuthService(db)
    auth_service.record_audit_event(
        user.id,
        "access_denied",
        "failure",
        request.client.host if request.client else None,
        request.headers.get("user-agent"),
    )
    db.commit()
    templates = request.app.state.templates
    return None, errors.render_error(
        templates,
        request,
        "Admin access required.",
        status_code=403,
    )


def _admin_solution_filter_label(job_status: str, window: str) -> str:
    if job_status == "queued":
        label = "Queued solution jobs"
    elif job_status == "in_progress":
        label = "Running solution jobs"
    elif job_status == "failed":
        label = "Failed solution jobs"
    else:
        label = "Completed solutions"

    if window == "24h":
        label += " (last 24h)"
    return label


def _query_opportunities(
    db: Session,
    config_id: str,
    search_query: str,
    opp_status: str,
    days: int,
    page: int,
    page_size: int,
    opp_type: str = "",
    sort_by: str = "cost",
    sort_direction: str = "desc",
    start_date: datetime | None = None,
    end_date: datetime | None = None,
    collapse_pending_states: bool = False,
) -> tuple[list[dict], PaginationContext]:
    """Query opportunities with filters, returning enriched list and pagination context."""
    from governor_core.configurations.models import ManifestConfiguration
    from governor_core.opportunities.models import Opportunity

    if start_date is None or end_date is None:
        now = datetime.now(timezone.utc)
        effective_days = days if days in (7, 30, 90) else 30
        start_date = now - timedelta(days=effective_days)
        end_date = now
    config = db.get(ManifestConfiguration, config_id)
    local_execution_mode = _is_local_execution_config(config)
    known_rule_types, visible_rule_types = _get_visible_opportunity_types_for_config(
        db, config_id
    )

    opp_status_filter = _normalize_project_status_filter(
        opp_status,
        collapse_pending_states=collapse_pending_states,
    )
    opp_query = db.query(Opportunity).filter(
        Opportunity.config_id == config_id,
        Opportunity.created_at >= start_date,
        Opportunity.created_at <= end_date,
    )
    opportunity_type_key = func.lower(Opportunity.opportunity_type)
    visible_rule_clause = (
        opportunity_type_key.in_(visible_rule_types) if visible_rule_types else false()
    )
    unknown_rule_clause = (
        ~opportunity_type_key.in_(known_rule_types) if known_rule_types else false()
    )
    opp_query = opp_query.filter(or_(visible_rule_clause, unknown_rule_clause))
    if opp_status_filter == "active":
        opp_query = opp_query.filter(Opportunity.status == "active")
    elif opp_status_filter == "pr_pending" and collapse_pending_states:
        opp_query = opp_query.filter(Opportunity.status.in_(("pr_pending", "clearing")))
    elif opp_status_filter != "all":
        opp_query = opp_query.filter(Opportunity.status == opp_status_filter)
    if opp_type:
        opp_query = opp_query.filter(
            func.lower(Opportunity.opportunity_type) == opp_type.lower()
        )
    if search_query:
        # Escape SQL ILIKE wildcards (FR-011)
        escaped = (
            search_query.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
        )
        pattern = f"%{escaped}%"
        opp_query = opp_query.filter(
            or_(
                Opportunity.opportunity_type.ilike(pattern, escape="\\"),
                Opportunity.affected_table.ilike(pattern, escape="\\"),
                Opportunity.dbt_model_name.ilike(pattern, escape="\\"),
            )
        )

    total_items = opp_query.count()
    pagination = PaginationContext(
        page=page, page_size=page_size, total_items=total_items
    )
    # Clamp page to valid range
    effective_page = (
        min(page, pagination.total_pages) if page > pagination.total_pages else page
    )
    if effective_page < 1:
        effective_page = 1
    pagination = PaginationContext(
        page=effective_page, page_size=page_size, total_items=total_items
    )
    offset = (effective_page - 1) * page_size

    # Map sort keys to SQLAlchemy columns
    table_sort_column = func.lower(
        func.coalesce(Opportunity.dbt_model_name, Opportunity.affected_table)
    )
    sort_column_map = {
        "type": Opportunity.opportunity_type,
        "table": Opportunity.affected_table,
        "severity": Opportunity.severity_score,
        "cost": Opportunity.current_cost_estimate,
        "savings": Opportunity.expected_savings,
        "status": Opportunity.status,
        "occurrence": Opportunity.occurrence_count,
        "detected": Opportunity.created_at,
    }
    sort_column_map["table"] = table_sort_column
    col = sort_column_map.get(sort_by, Opportunity.severity_score)
    if sort_by == "table":
        if sort_direction == "asc":
            opp_query = opp_query.order_by(
                col.asc(),
                Opportunity.affected_table.asc(),
                Opportunity.opportunity_type.asc(),
            )
        else:
            opp_query = opp_query.order_by(
                col.desc(),
                Opportunity.affected_table.desc(),
                Opportunity.opportunity_type.desc(),
            )
    else:
        order = col.asc() if sort_direction == "asc" else col.desc()
        opp_query = opp_query.order_by(order)

    opp_rows = opp_query.offset(offset).limit(page_size).all()

    opp_ids = [o.id for o in opp_rows]
    cascade_root_ids = [
        o.cascade_root_id
        for o in opp_rows
        if o.cascade_status == "delegated" and o.cascade_root_id
    ]
    latest_solution_map = get_latest_solution_snapshots(
        db,
        list(dict.fromkeys([*opp_ids, *cascade_root_ids])),
        schedule_missing_dry_runs=True,
    )
    root_opportunities = (
        {
            opp.id: opp
            for opp in db.query(Opportunity)
            .filter(Opportunity.id.in_(cascade_root_ids))
            .all()
        }
        if cascade_root_ids
        else {}
    )
    last_job_details_map = get_last_job_details(db, opp_rows)
    active_solution_job_status_map = get_active_solution_job_statuses(db, opp_ids)

    # Batch-load failed solution jobs for opportunities without active jobs or solutions
    from governor_core.solutions.models import SolutionJob

    failed_solution_job_ids: set[str] = set()
    if opp_ids:
        _failed_rows = (
            db.query(SolutionJob.opportunity_id)
            .filter(
                SolutionJob.opportunity_id.in_(opp_ids),
                SolutionJob.status == "failed",
            )
            .all()
        )
        failed_solution_job_ids = {r[0] for r in _failed_rows}

    # Batch-load workload savings estimates
    from governor_core.opportunities.models import (
        OpportunitySavingsEstimate as EstModel,
    )

    wl_estimates_map = {}
    exact_local_workload_map = (
        get_exact_local_workload_kinds(db, opp_rows) if local_execution_mode else {}
    )
    if opp_ids:
        try:
            from sqlalchemy import select as sa_select

            wl_rows = (
                db.execute(
                    sa_select(EstModel).where(EstModel.opportunity_id.in_(opp_ids))
                )
                .scalars()
                .all()
            )
            wl_estimates_map = {e.opportunity_id: e for e in wl_rows}
        except sqlalchemy.exc.SQLAlchemyError:
            pass  # Table may not exist yet

    opportunities_list = []
    for o in opp_rows:
        parts = (o.affected_table or "").split(".")
        table_short = parts[-1] if parts else o.affected_table or "Unknown"
        latest_solution = latest_solution_map.get(o.id, {})
        latest_job_details = last_job_details_map.get(o.id, {})
        workload_kind = (
            exact_local_workload_map.get(o.id)
            if local_execution_mode
            else latest_job_details.get("workload_kind")
        )
        workload_label = (
            workload_kind.title()
            if workload_kind in ("build", "consumption")
            else ("Unclassified" if local_execution_mode else "Other")
        )
        cost_display = build_cost_display(
            current_cost_estimate=o.current_cost_estimate,
            latest_job_cost=latest_job_details.get("total_cost"),
            dry_run_original_cost=latest_solution.get("dry_run_original_cost"),
            dry_run_modified_cost=latest_solution.get("dry_run_modified_cost"),
            use_dry_run_original_for_query_cost=latest_solution.get(
                "supports_optimized_dry_run",
                False,
            ),
            prefer_possible_savings_display=latest_solution.get(
                "prefers_possible_savings_display",
                False,
            ),
        )
        wl_est = wl_estimates_map.get(o.id)
        possible_savings_display = build_possible_savings_display(
            opportunity_type=o.opportunity_type,
            expected_savings=o.expected_savings,
            occurrence_count=o.occurrence_count,
            optimized_cost_value=cost_display["optimized_cost_value"],
            optimized_delta_direction=cost_display.get("optimized_delta_direction"),
            workload_per_run_savings=wl_est.per_run_savings if wl_est else None,
            workload_confidence=wl_est.confidence if wl_est else None,
            workload_jobs_analyzed=wl_est.jobs_analyzed if wl_est else None,
            prefer_possible_savings_display=latest_solution.get(
                "prefers_possible_savings_display",
                False,
            ),
            has_solution=bool(latest_solution),
        )
        if possible_savings_display.get("possible_savings_value") is None:
            root_opp = (
                root_opportunities.get(o.cascade_root_id) if o.cascade_root_id else None
            )
            root_solution = (
                latest_solution_map.get(root_opp.id, {}) if root_opp is not None else {}
            )
            possible_savings_display = build_inherited_pending_savings_display(
                root_possible_savings_value=build_possible_savings_display(
                    opportunity_type=root_opp.opportunity_type if root_opp else None,
                    expected_savings=root_opp.expected_savings if root_opp else None,
                    occurrence_count=root_opp.occurrence_count if root_opp else None,
                    optimized_cost_value=None,
                    optimized_delta_direction=None,
                    prefer_possible_savings_display=root_solution.get(
                        "prefers_possible_savings_display",
                        False,
                    ),
                    has_solution=bool(root_solution),
                ).get("possible_savings_value"),
                root_model_name=root_opp.dbt_model_name if root_opp else None,
            )
        opportunities_list.append(
            {
                "id": o.id,
                "type": o.opportunity_type,
                "affected_table": o.affected_table or "Unknown",
                "table_short": table_short,
                "dbt_model": o.dbt_model_name or "\u2014",
                "severity_score": o.severity_score,
                "expected_savings": format_usd(o.expected_savings),
                "status": o.status,
                "occurrence_count": o.occurrence_count,
                "has_solution": bool(latest_solution),
                "solution_risk_level": latest_solution.get("risk_level"),
                "trust_tier": latest_solution.get("trust_tier"),
                "avg_query_cost": latest_job_details.get("total_cost"),
                "dry_run_original_cost": latest_solution.get("dry_run_original_cost"),
                "dry_run_modified_cost": latest_solution.get("dry_run_modified_cost"),
                "solution_job_status": (
                    active_solution_job_status_map.get(o.id)
                    or (
                        "failed"
                        if not latest_solution and o.id in failed_solution_job_ids
                        else None
                    )
                ),
                "prefers_possible_savings_display": latest_solution.get(
                    "prefers_possible_savings_display",
                    False,
                ),
                "query_workload_kind": workload_kind or "other",
                "query_workload_label": workload_label,
                "created_at": o.created_at.strftime("%d/%m/%Y")
                if o.created_at
                else "\u2014",
                **cost_display,
                **possible_savings_display,
            }
        )

    return opportunities_list, pagination


def _load_compiled_original_sql(
    db: Session,
    opportunity,
    compiled_original_cache: dict[str, tuple[str | None, str | None]] | None = None,
) -> tuple[str | None, str | None]:
    """Load the baseline compiled SQL for an opportunity, with per-request caching."""
    from governor_core.sync.models import BigQueryJob
    from governor_core.utils.compiled_sql import get_compiled_sql

    if opportunity is None:
        return None, None

    if (
        compiled_original_cache is not None
        and opportunity.id in compiled_original_cache
    ):
        return compiled_original_cache[opportunity.id]

    latest_executed_sql = None
    if opportunity.related_job_ids:
        latest_job = (
            db.query(BigQueryJob)
            .filter(BigQueryJob.job_id.in_(opportunity.related_job_ids))
            .order_by(BigQueryJob.creation_time.desc())
            .first()
        )
        if latest_job and latest_job.query:
            latest_executed_sql = latest_job.query

    compiled_baseline_sql = get_compiled_sql(
        db, opportunity.manifest_version_id, opportunity.dbt_model_name
    )
    compiled_original_sql = compiled_baseline_sql or latest_executed_sql
    compiled_original_label = (
        "Compiled baseline from manifest"
        if compiled_baseline_sql
        else "Latest executed SQL from BigQuery"
        if latest_executed_sql
        else None
    )

    if compiled_original_cache is not None:
        compiled_original_cache[opportunity.id] = (
            compiled_original_sql,
            compiled_original_label,
        )

    return compiled_original_sql, compiled_original_label


def _build_solution_view_model(
    db: Session,
    solution,
    *,
    opportunity=None,
    solution_job=None,
    pr_record=None,
    compiled_original_cache: dict[str, tuple[str | None, str | None]] | None = None,
    config_cache: dict[str, object] | None = None,
) -> tuple[dict, bool]:
    """Build the normalized solution payload used by both opportunity and admin pages."""
    from governor_core.configurations.models import ManifestConfiguration
    from governor_core.gcp.clients import DryRunResult, dry_run_query
    from governor_core.utils.diff import generate_code_diff

    validation_report = solution.validation_report or {}
    display_trust_tier = (
        "requires_review"
        if has_blocking_dbt_verification_issue(validation_report)
        else (
            solution.trust_tier
            or validation_report.get("tier")
            or validation_report.get("overall_tier")
        )
    )
    config = None
    if opportunity and opportunity.config_id:
        if config_cache is None:
            config_cache = {}
        if opportunity.config_id not in config_cache:
            config_cache[opportunity.config_id] = db.get(
                ManifestConfiguration, opportunity.config_id
            )
        config = config_cache[opportunity.config_id]

    config_local_project_path = getattr(config, "local_project_path", None)
    local_execution_mode = _is_local_execution_config(config)
    local_apply_enabled = bool(local_execution_mode and config_local_project_path)
    local_build_execution_mode = derive_local_build_execution_mode(
        local_execution_mode=local_execution_mode,
        local_project_path=config_local_project_path,
        resolution_category=solution.resolution_category,
        file_path=solution.file_path,
        after_content=solution.after_content,
    )

    sol = {
        "id": solution.id,
        "resolution_category": solution.resolution_category,
        "version_number": solution.version_number,
        "explanation": solution.explanation or "",
        "risk_level": solution.risk_level or "medium",
        "risk_justification": solution.risk_justification or "",
        "file_path": solution.file_path,
        "change_type": solution.change_type,
        "before_content": solution.before_content,
        "diff_lines": None,
        "repository": solution.repository,
        "commit_sha": solution.commit_sha,
        "current_setting": solution.current_setting_value,
        "recommended_setting": solution.recommended_setting_value,
        "affected_resource": solution.affected_resource,
        "trust_tier": display_trust_tier,
        "template_name": extract_template_id(validation_report),
        "validation_report": validation_report,
        "verification_sql": None,
        "verification_profile": "core",
        "verification_output_mode": "audit",
        "verification_source_label": None,
        "verification_warnings": [],
        "verification_unavailable_reason": None,
        "compiled_original": None,
        "compiled_original_label": None,
        "compiled_modified": None,
        "dry_run_original": None,
        "dry_run_modified": None,
        "pr_url": pr_record.pr_url if pr_record else None,
        "pr_number": pr_record.pr_number if pr_record else None,
        "created_at": solution.created_at.strftime("%d/%m/%Y %H:%M")
        if solution.created_at
        else "",
        "opportunity_type": opportunity.opportunity_type if opportunity else "Unknown",
        "affected_table": opportunity.affected_table if opportunity else "Unknown",
        "config_id": opportunity.config_id if opportunity else None,
        "opp_id": solution.opportunity_id,
        "opp_status": opportunity.status if opportunity else None,
        "local_execution_mode": local_execution_mode,
        "local_apply_enabled": local_apply_enabled,
        "local_project_path": config_local_project_path,
        "local_build_execution_mode": local_build_execution_mode,
        "llm_model": solution_job.llm_model if solution_job else None,
        "prompt_tokens": solution_job.prompt_tokens if solution_job else None,
        "completion_tokens": solution_job.completion_tokens if solution_job else None,
        "llm_latency_ms": solution_job.llm_latency_ms if solution_job else None,
        # Shadow validation (spec 110)
        "shadow_validation_run_id": solution.shadow_validation_run_id,
        "local_apply_resolution": solution.local_apply_resolution,
        "applied_locally_at": solution.applied_locally_at,
    }
    # Pull the shadow run + its summary for the UI.
    #
    # Prefer the run linked from ``solution.shadow_validation_run_id`` (set on
    # success). If no link exists yet, fall back to the newest run for this
    # solution — this is what surfaces *in-flight* runs (queued/running) to
    # the UI so the "Run Comparison" button correctly hides for auto-triggered
    # validations that haven't finished yet.
    shadow_run = None
    if solution.shadow_validation_run_id:
        from governor_core.shadow.models import ShadowValidationRun

        shadow_run = db.get(ShadowValidationRun, solution.shadow_validation_run_id)
    if shadow_run is None:
        from governor_core.shadow.models import ShadowValidationRun

        shadow_run = (
            db.query(ShadowValidationRun)
            .filter(ShadowValidationRun.solution_id == solution.id)
            .order_by(ShadowValidationRun.created_at.desc())
            .first()
        )
    if shadow_run:
        sol["shadow_run"] = {
            "id": shadow_run.id,
            "status": shadow_run.status,
            "triggered_by": getattr(shadow_run, "triggered_by", "manual"),
            "skipped_reason": shadow_run.skipped_reason,
            "failure_reason": shadow_run.failure_reason,
            "total_baseline_bytes": shadow_run.total_baseline_bytes,
            "total_shadow_bytes": shadow_run.total_shadow_bytes,
            "total_baseline_cost_usd": (
                float(shadow_run.total_baseline_cost_usd)
                if shadow_run.total_baseline_cost_usd is not None
                else None
            ),
            "total_shadow_cost_usd": (
                float(shadow_run.total_shadow_cost_usd)
                if shadow_run.total_shadow_cost_usd is not None
                else None
            ),
            "bytes_delta_pct": (
                float(shadow_run.bytes_delta_pct)
                if shadow_run.bytes_delta_pct is not None
                else None
            ),
            "cost_delta_usd": (
                float(shadow_run.cost_delta_usd)
                if shadow_run.cost_delta_usd is not None
                else None
            ),
            "cascade_size": shadow_run.cascade_size,
            "updated_at": shadow_run.updated_at,
            "build_logs": shadow_run.build_logs,
        }

    target_model = None
    if solution.file_path and solution.file_path.endswith(".sql"):
        filename = solution.file_path.rsplit("/", 1)[-1]
        target_model = filename.rsplit(".", 1)[0]

    is_upstream_fix = False
    upstream_model_name = None
    for step in validation_report.get("steps", []):
        params = step.get("parameters")
        if not isinstance(params, dict):
            step_details = step.get("details")
            params = step_details if isinstance(step_details, dict) else {}
        if params.get("upstream_model"):
            is_upstream_fix = True
            upstream_model_name = params["upstream_model"]
            break

    sol["target_model"] = target_model
    sol["is_upstream_fix"] = is_upstream_fix
    sol["upstream_model_name"] = upstream_model_name
    supports_optimized_sql = solution_supports_optimized_dry_run(solution)
    sol["prefers_possible_savings_display"] = solution_prefers_possible_savings_display(
        solution
    )

    # Multi-file solutions store every edit in ``file_changes``. Build a
    # list of {file_path, diff_lines, before_content, after_content} for
    # the template. The primary (first) entry keeps powering the existing
    # sol.diff_lines/sol.file_path slots for back-compat.
    extra_file_diffs: list[dict] = []
    for fc in solution.normalized_file_changes:
        fp = fc.get("file_path")
        before = fc.get("before_content") or ""
        after = fc.get("after_content") or ""
        if not fp or not after:
            continue
        extra_file_diffs.append(
            {
                "file_path": fp,
                "change_type": fc.get("change_type"),
                "before_content": before,
                "after_content": after,
                "diff_lines": generate_code_diff(before, after),
                # Spec 128: carry through proposal_meta so the template can
                # render downstream-patch sub-cards with per-patch state.
                "proposal_meta": fc.get("proposal_meta"),
            }
        )
    sol["file_diffs"] = extra_file_diffs

    if (
        solution.resolution_category == "dbt_project_change"
        and solution.before_content
        and solution.after_content
    ):
        sol["diff_lines"] = generate_code_diff(
            solution.before_content, solution.after_content
        )
        if is_upstream_fix:
            sol["verification_unavailable_reason"] = (
                "Verification SQL is unavailable for upstream fixes because "
                "compiled SQL is tracked for the affected downstream model, "
                "not the upstream file modified by this solution."
            )
            return sol, False

        compiled_original_sql, compiled_original_label = _load_compiled_original_sql(
            db,
            opportunity,
            compiled_original_cache,
        )
        sol["compiled_original"] = compiled_original_sql
        sol["compiled_original_label"] = compiled_original_label
        if supports_optimized_sql:
            sol["compiled_modified"] = solution.compiled_after_sql

        cached_solution_updated = False

        if solution.dry_run_original:
            sol["dry_run_original"] = DryRunResult(**solution.dry_run_original)
        elif compiled_original_sql and config and config.gcp_project_id:
            dr_orig = dry_run_query(config.gcp_project_id, compiled_original_sql)
            sol["dry_run_original"] = dr_orig
            solution.dry_run_original = {
                "valid": dr_orig.valid,
                "total_bytes_processed": dr_orig.total_bytes_processed,
                "estimated_cost_usd": dr_orig.estimated_cost_usd,
                "referenced_tables": dr_orig.referenced_tables,
                "error": dr_orig.error,
            }
            cached_solution_updated = True

        if supports_optimized_sql and solution.dry_run_modified:
            sol["dry_run_modified"] = DryRunResult(**solution.dry_run_modified)
        elif supports_optimized_sql and config and config.gcp_project_id:
            dr_mod = dry_run_query(config.gcp_project_id, solution.compiled_after_sql)
            sol["dry_run_modified"] = dr_mod
            solution.dry_run_modified = {
                "valid": dr_mod.valid,
                "total_bytes_processed": dr_mod.total_bytes_processed,
                "estimated_cost_usd": dr_mod.estimated_cost_usd,
                "referenced_tables": dr_mod.referenced_tables,
                "error": dr_mod.error,
            }
            cached_solution_updated = True

        verification_artifact = build_verification_sql_artifact(
            original_sql=compiled_original_sql,
            optimized_sql=solution.compiled_after_sql
            if supports_optimized_sql
            else None,
            source_label=compiled_original_label,
            profile="core",
            output_mode="audit",
            original_dry_run=sol.get("dry_run_original"),
            optimized_dry_run=sol.get("dry_run_modified")
            if supports_optimized_sql
            else None,
        )
        sol["verification_sql"] = verification_artifact.sql_text
        sol["verification_profile"] = verification_artifact.profile
        sol["verification_output_mode"] = verification_artifact.output_mode
        sol["verification_source_label"] = verification_artifact.source_label
        sol["verification_warnings"] = [
            {
                "code": warning.code,
                "message": warning.message,
            }
            for warning in verification_artifact.warnings
        ]
        sol["verification_unavailable_reason"] = (
            verification_artifact.unavailable_reason
        )

        if cached_solution_updated:
            sync_opportunity_solution_snapshots(db, [solution.opportunity_id])

        return sol, cached_solution_updated

    return sol, False


_VALIDATION_CHANGE_CATEGORIES = (
    {
        "key": "config_property_addition",
        "title": "Config Property",
        "description": (
            "Adding dbt config properties such as cluster_by or partition_by."
        ),
    },
    {
        "key": "column_addition",
        "title": "Column",
        "description": "Adding a new projected column to query output.",
    },
    {
        "key": "filter_addition",
        "title": "Filter",
        "description": "Adding a WHERE or HAVING filter that narrows results.",
    },
    {
        "key": "join_addition",
        "title": "JOIN",
        "description": "Adding a new JOIN clause.",
    },
    {
        "key": "subquery_addition",
        "title": "Subquery",
        "description": "Adding a new nested query or derived table.",
    },
    {
        "key": "cte_addition",
        "title": "CTE",
        "description": "Adding a new Common Table Expression.",
    },
)

_TEMPLATE_COVERAGE_DETAILS = {
    "switch_storage_billing": {
        "mode_label": "Deterministic template",
        "summary": "Generates reversible ALTER SCHEMA DDL to switch dataset billing from LOGICAL to PHYSICAL.",
        "required_evidence": "Dataset identity plus billing cost and savings estimates.",
    },
    "remove_dead_ctes": {
        "mode_label": "Deterministic template",
        "summary": "Removes unused CTE definition blocks while leaving surviving SQL unchanged.",
        "required_evidence": "Named dead CTEs in evidence and a retrievable model source file.",
    },
    "remove_dead_columns": {
        "mode_label": "Deterministic template",
        "summary": "Deletes unused projected expressions from CTE SELECT lists without touching surrounding logic.",
        "required_evidence": "CTE-level dead column evidence and a retrievable model source file.",
    },
    "remove_redundant_order_bys": {
        "mode_label": "Deterministic template",
        "summary": "Removes redundant top-level ORDER BY clauses from intermediate CTEs.",
        "required_evidence": "Named redundant ORDER BY findings and a retrievable model source file.",
    },
    "remove_unused_joins": {
        "mode_label": "Deterministic template",
        "summary": "Removes conservatively unused LEFT JOIN clauses from affected CTEs.",
        "required_evidence": "Unused join evidence with CTE and alias details plus source file access.",
    },
    "upstream_cluster_by": {
        "mode_label": "Lineage-based deterministic template",
        "summary": "Adds cluster_by to an upstream model discovered via lineage analysis when Governor can prove the target file and columns.",
        "required_evidence": "Compiled SQL, manifest lineage, upstream source file access, and candidate cluster columns.",
    },
}


_RULE_COST_AND_IMPACT: dict[str, dict[str, str]] = {
    "shuffle_spill": {
        "cost_method": "Job cost x 25% reduction",
        "cost_detail": "Aggregated total_cost from matching BQ jobs.",
        "impact_label": "Moderate–High",
        "impact_detail": "Reduces disk spill overhead per query run.",
    },
    "slot_contention": {
        "cost_method": "Job cost x variable %",
        "cost_detail": "Based on slot utilization metrics.",
        "impact_label": "Moderate–High",
        "impact_detail": "Reduces resource contention and queuing.",
    },
    "join_explosion": {
        "cost_method": "Job cost x 30-50% reduction",
        "cost_detail": "Based on row multiplication ratio.",
        "impact_label": "High–Critical",
        "impact_detail": "Eliminates row explosion from bad joins.",
    },
    "partition_pruning": {
        "cost_method": "SQL predicate + partition stats",
        "cost_detail": "Estimates pruned bytes → USD at $6.25/TB.",
        "impact_label": "High–Critical",
        "impact_detail": "Reduces bytes scanned via partition filters.",
    },
    "storage_billing_optimization": {
        "cost_method": "Logical vs physical billing diff",
        "cost_detail": "Compares per-GB/mo rates across storage types.",
        "impact_label": "Moderate–Critical",
        "impact_detail": "Switches datasets to cheaper billing model.",
    },
    "dead_cte": {
        "cost_method": "Bytes processed by unused CTEs",
        "cost_detail": "Estimated from job bytes billed.",
        "impact_label": "Low–Moderate",
        "impact_detail": "Removes wasted compute on unused CTEs.",
    },
    "dead_column": {
        "cost_method": "Bytes read for unused columns",
        "cost_detail": "Estimated from column-level byte stats.",
        "impact_label": "Low–Moderate",
        "impact_detail": "Removes unnecessary column projections.",
    },
    "dead_window_expression": {
        "cost_method": "Bytes processed by unused windows",
        "cost_detail": "Estimated from job bytes billed.",
        "impact_label": "Low–Moderate",
        "impact_detail": "Removes unused window function compute.",
    },
    "unused_aggregation_output": {
        "cost_method": "Bytes processed by unused aggs",
        "cost_detail": "Estimated from job bytes billed.",
        "impact_label": "Low–Moderate",
        "impact_detail": "Removes unused aggregation compute.",
    },
    "redundant_order_by": {
        "cost_method": "Sort overhead on intermediate CTEs",
        "cost_detail": "Estimated from job slot-ms and bytes.",
        "impact_label": "Low",
        "impact_detail": "Eliminates unnecessary sort operations.",
    },
    "unused_join": {
        "cost_method": "Bytes processed by unused joins",
        "cost_detail": "Estimated from join table byte stats.",
        "impact_label": "Low–Moderate",
        "impact_detail": "Removes joins that don't affect output.",
    },
}

_RULE_COST_DEFAULT = {
    "cost_method": "Job cost analysis",
    "cost_detail": "Estimated from BigQuery job metrics.",
    "impact_label": "Variable",
    "impact_detail": "Depends on query frequency and cost.",
}


def _build_validation_reference_context() -> dict[str, object]:
    """Build live rule/template coverage data for the validation reference page."""
    from governor_core.opportunities.catalog import (
        get_detection_analysis_surfaces,
        get_grouped_detection_rule_catalog,
    )
    from governor_core.solutions.templates import get_registry
    from governor_core.solutions.validation.allowlists import ALLOWLISTS

    coverage_by_rule: dict[str, list[dict[str, str]]] = {}
    for template in get_registry():
        details = _TEMPLATE_COVERAGE_DETAILS.get(
            template.template_id,
            {
                "mode_label": "Deterministic template",
                "summary": "Registered deterministic solution template.",
                "required_evidence": "Template-specific evidence.",
            },
        )
        for rule_type in sorted(template.applicable_types):
            coverage_by_rule.setdefault(rule_type, []).append(
                {
                    "template_id": template.template_id,
                    "mode_label": details["mode_label"],
                    "summary": details["summary"],
                    "required_evidence": details["required_evidence"],
                }
            )

    for rule_type in ("shuffle_spill", "slot_contention", "join_explosion"):
        details = _TEMPLATE_COVERAGE_DETAILS["upstream_cluster_by"]
        coverage_by_rule.setdefault(rule_type, []).append(
            {
                "template_id": "upstream_cluster_by",
                "mode_label": details["mode_label"],
                "summary": details["summary"],
                "required_evidence": details["required_evidence"],
            }
        )

    validation_rule_groups: list[dict[str, object]] = []
    for group in get_grouped_detection_rule_catalog():
        rules: list[dict[str, object]] = []
        for rule in group.rules:
            allowed_categories = {
                category.value for category in ALLOWLISTS.get(rule.rule_type, set())
            }
            template_coverages = coverage_by_rule.get(rule.rule_type, [])
            if allowed_categories:
                validation_path = "AST allowlist"
            elif template_coverages:
                validation_path = "Deterministic template only"
            else:
                validation_path = "Manual review"
            cost_impact = _RULE_COST_AND_IMPACT.get(rule.rule_type, _RULE_COST_DEFAULT)
            rules.append(
                {
                    "rule_type": rule.rule_type,
                    "display_name": rule.display_name,
                    "description": rule.description,
                    "analysis_surface": rule.analysis_surface,
                    "analysis_surface_title": rule.analysis_surface_title,
                    "analysis_surface_description": rule.analysis_surface_description,
                    "enabled": rule.enabled,
                    "template_coverages": template_coverages,
                    "allowed_categories": allowed_categories,
                    "validation_path": validation_path,
                    **cost_impact,
                }
            )
        validation_rule_groups.append(
            {
                "key": group.key,
                "title": group.title,
                "description": group.description,
                "analysis_surface_summaries": group.analysis_surface_summaries,
                "rules": rules,
            }
        )

    return {
        "analysis_surfaces": get_detection_analysis_surfaces(),
        "validation_rule_groups": validation_rule_groups,
    }


@router.get("/projects")
def app_home(
    request: Request,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> RedirectResponse:
    """Redirect authenticated users to the right landing page."""
    user = _get_authenticated_user(request, db, auth_session)
    if not user:
        return RedirectResponse("/login", status_code=302)
    if any(role.name == "admin" for role in user.roles):
        return RedirectResponse("/admin/configurations", status_code=302)
    return RedirectResponse("/dashboard", status_code=302)


def _get_authenticated_user(
    request: Request, db: Session, auth_session
) -> models.User | None:
    """Validate session and return the current user or None."""
    if not auth_session:
        return None
    user = (
        db.query(models.User)
        .filter(models.User.id == auth_session.user_id)
        .one_or_none()
    )
    if not user:
        return None
    return user


@router.get("/draft-ui/project/{config_id}")
def draft_ui_project_redirect(
    config_id: str,
    request: Request,
) -> RedirectResponse:
    """Legacy project route alias retained for backward compatibility."""
    query_params = [(key, value) for key, value in request.query_params.multi_items()]
    filtered = [(key, value) for key, value in query_params if key != "config_id"]
    filtered.insert(0, ("config_id", config_id))
    query = urlencode(filtered, doseq=True)
    location = "/draft-ui/dashboard"
    if query:
        location = f"{location}?{query}"
    return RedirectResponse(location, status_code=302)


@router.get("/draft-ui/dashboard", response_class=HTMLResponse)
def draft_ui_dashboard(
    request: Request,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
    config_id: str | None = Query(default=None),
    days: int = Query(default=30),
) -> Response:
    """Legacy dashboard alias for global and project-scoped views."""
    from governor_core.configurations.models import ManifestConfiguration
    from governor_web.routes.dashboard import dashboard as dashboard_view

    user = _get_authenticated_user(request, db, auth_session)
    if not user:
        return redirect_with_message("/login", "Please sign in to continue.", "warning")

    if config_id:
        config = db.get(ManifestConfiguration, config_id)
        if config is None or config.status != "active":
            return RedirectResponse("/dashboard", status_code=302)
        return app_project_detail(
            request=request,
            config_id=config_id,
            db=db,
            auth_session=auth_session,
            days=days,
            page=1,
            page_size=10,
            opp_status="active",
            opp_type="",
            q="",
            sort="cost",
            direction="desc",
        )

    return dashboard_view(
        request=request,
        db=db,
        user=user,
        days=days if days in (7, 30, 90) else None,
        start=None,
        end=None,
    )


# ---------------------------------------------------------------------------
# Project detail routes (spec 008)
# ---------------------------------------------------------------------------


@router.get("/projects/{config_id}", response_class=HTMLResponse)
def app_project_detail(
    request: Request,
    config_id: str,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
    days: int | None = Query(default=None),
    start: str | None = Query(default=None),
    end: str | None = Query(default=None),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=10, ge=1, le=100),
    opp_status: str = Query(default="active"),
    opp_type: str = Query(default=""),
    q: str = Query(default=""),
    sort: str = Query(default="cost"),
    direction: str = Query(default="desc"),
    lens: str = Query(default="all"),
) -> Response:
    """Production project detail page."""
    from governor_core.configurations.models import ManifestConfiguration
    from governor_core.opportunities.models import Opportunity
    from governor_core.sync.models import SyncOperation

    user = _get_authenticated_user(request, db, auth_session)
    if not user:
        return redirect_with_message("/login", "Please sign in to continue.", "warning")

    config = (
        db.query(ManifestConfiguration)
        .filter(ManifestConfiguration.id == config_id)
        .one_or_none()
    )
    if not config:
        return redirect_with_message("/projects", "Project not found.", "warning")

    local_execution_mode = _is_local_execution_config(config)
    if config.status != "active":
        return redirect_with_message("/projects", "Project is disabled.", "warning")

    start_date, end_date, days_preset, date_range_display = _parse_date_range(
        days if days in (7, 30, 90) else None,
        start,
        end,
    )
    selected_lens = _parse_cost_lens(lens)
    effective_days = days_preset or 30
    visibility_clause, visible_opportunity_types = (
        _build_visible_opportunity_filter_for_rule_types(config.watched_rule_types)
    )

    service = DashboardService(db)
    summary = service.get_project_summary(config_id, start_date, end_date)
    daily_stats = service.get_project_daily_stats(
        config_id, start_date, end_date, lens=selected_lens
    )
    health = service.get_project_health(config_id, start_date, end_date)
    storage_summary = service.get_storage_cost_summary(config_id)
    if storage_summary and storage_summary.datasets:
        storage_summary.datasets.sort(key=lambda d: d.monthly_cost, reverse=True)

    active_visible_opportunities = (
        db.query(Opportunity)
        .filter(
            Opportunity.config_id == config_id,
            Opportunity.status == "active",
            Opportunity.created_at >= start_date,
            Opportunity.created_at <= end_date,
            visibility_clause,
        )
        .all()
    )
    active_visible_opportunity_ids = [opp.id for opp in active_visible_opportunities]
    latest_solution_map = get_latest_solution_snapshots(
        db, active_visible_opportunity_ids
    )
    active_solution_job_status_map = get_active_solution_job_statuses(
        db, active_visible_opportunity_ids
    )
    wl_estimates_map = {}
    if active_visible_opportunity_ids:
        try:
            from sqlalchemy import select as sa_select

            from governor_core.opportunities.models import (
                OpportunitySavingsEstimate as EstModel,
            )

            wl_rows = (
                db.execute(
                    sa_select(EstModel).where(
                        EstModel.opportunity_id.in_(active_visible_opportunity_ids)
                    )
                )
                .scalars()
                .all()
            )
            wl_estimates_map = {
                estimate.opportunity_id: estimate for estimate in wl_rows
            }
        except sqlalchemy.exc.SQLAlchemyError:
            wl_estimates_map = {}

    total_savings_raw = Decimal("0")
    total_possible_savings_raw = Decimal("0")
    historical_possible_savings = calculate_historical_possible_savings(
        db,
        active_visible_opportunities,
        start_date=start_date,
        end_date=end_date,
    )
    for opportunity in active_visible_opportunities:
        latest_solution = latest_solution_map.get(opportunity.id, {})
        prefers_possible_savings_display = latest_solution.get(
            "prefers_possible_savings_display",
            False,
        )
        dry_run_original_cost = latest_solution.get("dry_run_original_cost")
        dry_run_modified_cost = latest_solution.get("dry_run_modified_cost")

        if (
            not prefers_possible_savings_display
            and dry_run_original_cost is not None
            and dry_run_modified_cost is not None
            and dry_run_original_cost > dry_run_modified_cost
        ):
            total_savings_raw += dry_run_original_cost - dry_run_modified_cost

        has_active_solution_job = active_solution_job_status_map.get(
            opportunity.id
        ) in ("queued", "in_progress")
        if has_active_solution_job:
            continue
        if historical_possible_savings.has_history(opportunity.id) and (
            prefers_possible_savings_display or dry_run_modified_cost is None
        ):
            total_possible_savings_raw += historical_possible_savings.savings_for(
                opportunity.id
            )
            continue
        # Determine if the dry run shows actual cost reduction
        _delta_dir: str | None = None
        if (
            dry_run_modified_cost is not None
            and dry_run_original_cost is not None
            and dry_run_modified_cost < dry_run_original_cost
        ):
            _delta_dir = "down"
        wl_est = wl_estimates_map.get(opportunity.id)
        possible_savings_display = build_possible_savings_display(
            opportunity_type=opportunity.opportunity_type,
            expected_savings=opportunity.expected_savings,
            occurrence_count=opportunity.occurrence_count,
            optimized_cost_value=dry_run_modified_cost,
            optimized_delta_direction=_delta_dir,
            workload_per_run_savings=wl_est.per_run_savings if wl_est else None,
            workload_confidence=wl_est.confidence if wl_est else None,
            workload_jobs_analyzed=wl_est.jobs_analyzed if wl_est else None,
            prefer_possible_savings_display=prefers_possible_savings_display,
            has_solution=bool(latest_solution),
        )
        possible_savings_value = possible_savings_display.get("possible_savings_value")
        if possible_savings_value is not None:
            total_possible_savings_raw += possible_savings_value

    opportunity_count = len(active_visible_opportunities)
    available_types = sorted(
        [
            row[0]
            for row in db.query(Opportunity.opportunity_type)
            .filter(
                Opportunity.config_id == config_id,
                Opportunity.created_at >= start_date,
                Opportunity.created_at <= end_date,
                visibility_clause,
            )
            .distinct()
            .all()
            if row[0]
        ],
        key=str.lower,
    )

    total_savings = float(total_savings_raw)
    if summary.total_spend and float(summary.total_spend) > 0:
        savings_pct = round((total_savings / float(summary.total_spend)) * 100)
        savings_pct_str = f"{savings_pct}%"
    else:
        savings_pct_str = "0%"

    # Opportunities (paginated) — uses shared helper
    search_query = q.strip()
    opp_status_filter = _normalize_project_status_filter(
        opp_status,
        collapse_pending_states=local_execution_mode,
    )
    opp_type_filter = opp_type if opp_type in available_types else ""
    opp_sort = (
        sort
        if sort
        in (
            "type",
            "table",
            "severity",
            "cost",
            "savings",
            "status",
            "occurrence",
            "detected",
        )
        else "cost"
    )
    opp_direction = direction if direction in ("asc", "desc") else "desc"
    opportunities_list, pagination = _query_opportunities(
        db,
        config_id,
        search_query,
        opp_status_filter,
        effective_days,
        page,
        page_size,
        opp_type=opp_type_filter,
        sort_by=opp_sort,
        sort_direction=opp_direction,
        start_date=start_date,
        end_date=end_date,
        collapse_pending_states=local_execution_mode,
    )

    bg_job_counts = _count_project_background_jobs(db, config_id)
    running_syncs = bg_job_counts["syncs"]
    running_detections = bg_job_counts["detections"]
    running_solutions = bg_job_counts["solutions"]
    background_jobs_running = bg_job_counts["total"] > 0

    total_bytes = sum(d.total_bytes_billed for d in daily_stats)
    total_slots = sum(d.total_slot_ms for d in daily_stats)

    def _fmt_bytes(b: int) -> str:
        if b >= 1_000_000_000_000:
            return f"{b / 1_000_000_000_000:.1f} TB"
        if b >= 1_000_000_000:
            return f"{b / 1_000_000_000:.1f} GB"
        if b >= 1_000_000:
            return f"{b / 1_000_000:.1f} MB"
        return f"{b:,} B"

    def _fmt_slots(s: int) -> str:
        hours = s / 3_600_000
        if hours >= 1000:
            return f"{hours / 1000:.1f}k slot-hrs"
        if hours >= 1:
            return f"{hours:.1f} slot-hrs"
        return f"{s:,} slot-ms"

    trend_data = [
        {
            "date": d.date.isoformat(),
            "cost": apply_cost_multiplier(d.total_cost),
            "build_cost": apply_cost_multiplier(d.build_cost),
            "consumption_cost": apply_cost_multiplier(d.consumption_cost),
            "jobs": d.job_count,
            "bytes": d.total_bytes_billed,
            "slots": d.total_slot_ms,
        }
        for d in daily_stats
    ]

    # Last sync time (US5)
    last_sync_row = (
        db.query(SyncOperation.completed_at)
        .filter(
            SyncOperation.config_id == config_id,
            SyncOperation.status == "completed",
        )
        .order_by(SyncOperation.completed_at.desc())
        .first()
    )
    last_sync_at = last_sync_row[0] if last_sync_row else None

    # Trust tier counts for solution safety summary (spec 030)
    from governor_core.solutions.models import Solution as SolModel

    tier_rows = (
        db.query(SolModel.trust_tier, func.count())
        .join(Opportunity, SolModel.opportunity_id == Opportunity.id)
        .filter(Opportunity.config_id == config_id)
        .group_by(SolModel.trust_tier)
        .all()
    )
    trust_tier_counts = {}
    for tier_val, cnt in tier_rows:
        key = tier_val or "requires_review"
        trust_tier_counts[key] = trust_tier_counts.get(key, 0) + cnt

    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "project/detail.html",
        {
            "title": f"Project: {config.name}",
            "flash": get_flash_message(request),
            "user": user,
            "config": config,
            "display_gcp_project_id": resolve_display_gcp_project_id(config),
            "days": effective_days,
            "last_sync_at": last_sync_at,
            "project_kpis": {
                "total_spend": format_usd(summary.total_spend),
                "total_spend_raw": apply_cost_multiplier(summary.total_spend),
                "build_spend": format_usd(summary.build_spend),
                "build_spend_raw": apply_cost_multiplier(summary.build_spend),
                "consumption_spend": format_usd(summary.consumption_spend),
                "consumption_spend_raw": apply_cost_multiplier(
                    summary.consumption_spend
                ),
                "storage_monthly_cost": (
                    format_usd(summary.storage_monthly_cost)
                    if summary.storage_monthly_cost is not None
                    else None
                ),
                "storage_monthly_cost_raw": (
                    apply_cost_multiplier(summary.storage_monthly_cost)
                    if summary.storage_monthly_cost is not None
                    else None
                ),
                "storage_latest_synced_at": summary.storage_latest_synced_at,
                "opportunity_count": opportunity_count,
                "verified_savings": format_usd(total_savings_raw),
                "verified_savings_raw": apply_cost_multiplier(total_savings_raw),
                "verified_savings_pct_of_spend": savings_pct_str,
                "possible_savings": format_usd(total_possible_savings_raw),
                "possible_savings_raw": apply_cost_multiplier(
                    total_possible_savings_raw
                ),
                "total_bytes": _fmt_bytes(total_bytes),
                "total_bytes_raw": total_bytes,
                "total_slots": _fmt_slots(total_slots),
                "total_slots_raw": total_slots,
                "data_coverage": summary.data_coverage_days,
            },
            "date_range": {
                "start": start_date,
                "end": end_date,
                "days": days_preset,
                "display": date_range_display,
            },
            "selected_lens": selected_lens,
            "selected_lens_label": _lens_label(selected_lens),
            "health_score": {
                "overall_score": health.overall_score,
                "overall_status": health.overall_status,
                "manifest_scores": [
                    {
                        "manifest_hash": m.manifest_hash,
                        "score": m.score,
                        "status": m.status,
                        "opportunity_count": m.opportunity_count,
                    }
                    for m in health.manifest_scores
                ],
            },
            "trend_data": trend_data,
            "storage_summary": storage_summary,
            "storage_pagination": PaginationContext(
                page=1,
                page_size=10,
                total_items=len(storage_summary.datasets) if storage_summary else 0,
            ),
            "trust_tier_counts": trust_tier_counts if trust_tier_counts else None,
            "opportunities": opportunities_list,
            "pagination": pagination,
            "selected_status": opp_status_filter,
            "selected_type": opp_type_filter,
            "available_types": available_types,
            "search_query": search_query,
            "opp_sort": opp_sort,
            "opp_direction": opp_direction,
            "local_execution_mode": local_execution_mode,
            "running_syncs": running_syncs,
            "running_detections": running_detections,
            "running_solutions": running_solutions,
            "background_jobs_running": background_jobs_running,
            "base_url": f"/projects/{config_id}?days={effective_days}&opp_status={opp_status_filter}&q={search_query}",
        },
    )


# ---------------------------------------------------------------------------
# Datastar SSE: Filter opportunities table (spec 025)
# ---------------------------------------------------------------------------


@router.get("/projects/{config_id}/filter-opportunities")
async def filter_opportunities_sse(
    request: Request,
    config_id: str,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> Response:
    """SSE endpoint returning filtered opportunities table fragment."""
    from datastar_py import SSE_HEADERS
    from datastar_py.consts import ElementPatchMode
    from datastar_py.fastapi import read_signals
    from datastar_py.sse import ServerSentEventGenerator as SSEGenerator
    from fastapi.responses import StreamingResponse

    from governor_core.configurations.models import ManifestConfiguration

    user = _get_authenticated_user(request, db, auth_session)
    if not user:
        return RedirectResponse("/login", status_code=302)

    signals = await read_signals(request)
    signals = signals or {}
    search_query = str(signals.get("oppSearch", "")).strip()
    opp_status = str(signals.get("oppStatus", "active"))
    opp_type = str(signals.get("oppType", ""))
    opp_days = signals.get("oppDays", 30)
    opp_start = str(signals.get("oppStart", "")).strip()
    opp_end = str(signals.get("oppEnd", "")).strip()
    opp_page = signals.get("oppPage", 1)
    opp_sort = str(signals.get("oppSort", "cost"))
    opp_direction = str(signals.get("oppDirection", "desc"))

    try:
        opp_days = int(opp_days)
    except TypeError, ValueError:
        opp_days = 30
    try:
        opp_page = int(opp_page)
    except TypeError, ValueError:
        opp_page = 1
    if opp_page < 1:
        opp_page = 1

    if opp_sort not in (
        "type",
        "table",
        "severity",
        "cost",
        "savings",
        "status",
        "occurrence",
        "detected",
    ):
        opp_sort = "cost"
    if opp_direction not in ("asc", "desc"):
        opp_direction = "desc"

    range_start = None
    range_end = None
    if opp_start and opp_end:
        range_start, range_end, _, _ = _parse_date_range(None, opp_start, opp_end)

    config = (
        db.query(ManifestConfiguration)
        .filter(ManifestConfiguration.id == config_id)
        .one_or_none()
    )
    local_execution_mode = _is_local_execution_config(config)

    def _generate() -> Generator[str, None, None]:
        templates = request.app.state.templates
        if not config:
            html = templates.get_template("project/_opportunities_table.html").render(
                opportunities=[],
                pagination=PaginationContext(page=1, page_size=10, total_items=0),
                config=None,
                search_query="",
                selected_status="active",
                local_execution_mode=False,
                background_jobs_running=False,
            )
        elif config.status != "active":
            html = templates.get_template("project/_opportunities_table.html").render(
                opportunities=[],
                pagination=PaginationContext(page=1, page_size=10, total_items=0),
                config=config,
                search_query="",
                selected_status="active",
                local_execution_mode=local_execution_mode,
                background_jobs_running=False,
            )
        else:
            bg_job_counts = _count_project_background_jobs(db, config_id)
            opportunities_list, pagination = _query_opportunities(
                db,
                config_id,
                search_query,
                opp_status,
                opp_days,
                opp_page,
                10,
                opp_type=opp_type,
                sort_by=opp_sort,
                sort_direction=opp_direction,
                start_date=range_start,
                end_date=range_end,
                collapse_pending_states=local_execution_mode,
            )
            html = templates.get_template("project/_opportunities_table.html").render(
                opportunities=opportunities_list,
                pagination=pagination,
                config=config,
                search_query=search_query,
                selected_status=_normalize_project_status_filter(
                    opp_status,
                    collapse_pending_states=local_execution_mode,
                ),
                local_execution_mode=local_execution_mode,
                background_jobs_running=bg_job_counts["total"] > 0,
            )
        yield str(
            SSEGenerator.patch_elements(
                html,
                selector="#opportunities-content",
                mode=ElementPatchMode.OUTER,
            )
        )

    return StreamingResponse(_generate(), headers=SSE_HEADERS)


@router.get("/projects/{config_id}/bg-jobs-status")
def project_bg_jobs_status(
    config_id: str,
    request: Request,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> Response:
    """Return active background job counts for a single project dashboard."""
    from governor_core.configurations.models import ManifestConfiguration

    user = _get_authenticated_user(request, db, auth_session)
    if not user:
        return redirect_with_message("/login", "Please sign in to continue.", "warning")

    config = (
        db.query(ManifestConfiguration)
        .filter(ManifestConfiguration.id == config_id)
        .one_or_none()
    )
    if not config or config.status != "active":
        return JSONResponse(
            {"syncs": 0, "detections": 0, "solutions": 0, "total": 0},
            status_code=404 if not config else 200,
        )

    bg_job_counts = _count_project_background_jobs(db, config_id)
    return JSONResponse(
        {
            "syncs": bg_job_counts["syncs"],
            "detections": bg_job_counts["detections"],
            "solutions": bg_job_counts["solutions"],
            "total": bg_job_counts["total"],
        }
    )


@router.get("/projects/{config_id}/filter-storage")
async def filter_storage_sse(
    request: Request,
    config_id: str,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> Response:
    """SSE endpoint returning sorted/paginated storage billing table fragment."""
    from datastar_py import SSE_HEADERS
    from datastar_py.consts import ElementPatchMode
    from datastar_py.fastapi import read_signals
    from datastar_py.sse import ServerSentEventGenerator as SSEGenerator
    from fastapi.responses import StreamingResponse

    user = _get_authenticated_user(request, db, auth_session)
    if not user:
        return RedirectResponse("/login", status_code=302)

    signals = await read_signals(request)
    signals = signals or {}
    stor_sort = str(signals.get("storSort", "monthly_cost"))
    stor_direction = str(signals.get("storDirection", "desc"))
    stor_page = int(signals.get("storPage", 1))

    valid_sorts = {
        "dataset_name",
        "table_count",
        "billing_model",
        "compression_ratio",
        "monthly_cost",
        "potential_savings",
    }
    if stor_sort not in valid_sorts:
        stor_sort = "monthly_cost"
    if stor_direction not in ("asc", "desc"):
        stor_direction = "desc"
    if stor_page < 1:
        stor_page = 1

    service = DashboardService(db)
    storage_summary = service.get_storage_cost_summary(config_id)

    def _generate() -> Generator[str, None, None]:
        templates = request.app.state.templates
        tables = list(storage_summary.datasets) if storage_summary else []

        # Sort
        reverse = stor_direction == "desc"
        if tables:

            def sort_key(t) -> object:
                val = getattr(t, stor_sort, None)
                if val is None:
                    return ""
                if isinstance(val, str):
                    return val.lower()
                return val

            tables = sorted(tables, key=sort_key, reverse=reverse)

        # Paginate
        page_size = 10
        pagination = PaginationContext(
            page=stor_page, page_size=page_size, total_items=len(tables)
        )
        if pagination.page > pagination.total_pages:
            pagination = PaginationContext(
                page=pagination.total_pages,
                page_size=page_size,
                total_items=len(tables),
            )
        offset = (pagination.page - 1) * page_size
        page_tables = tables[offset : offset + page_size]

        html = templates.get_template("project/_storage_table.html").render(
            storage_tables=page_tables,
            stor_pagination=pagination,
            stor_sort=stor_sort,
            stor_direction=stor_direction,
            config_id=config_id,
        )
        yield str(
            SSEGenerator.patch_elements(
                html,
                selector="#storage-content",
                mode=ElementPatchMode.OUTER,
            )
        )

    return StreamingResponse(_generate(), headers=SSE_HEADERS)


@router.get(
    "/projects/{config_id}/opportunities/{opp_id}",
    response_class=HTMLResponse,
)
def app_opportunity_detail(
    request: Request,
    config_id: str,
    opp_id: str,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> Response:
    """Production opportunity detail page."""
    from governor_core.configurations.models import ManifestConfiguration
    from governor_core.opportunities.models import Opportunity
    from governor_core.pullrequests.models import PullRequestRecord
    from governor_core.solutions.models import Solution
    from governor_core.sync.models import SyncOperation

    user = _get_authenticated_user(request, db, auth_session)
    if not user:
        return redirect_with_message("/login", "Please sign in to continue.", "warning")

    config = (
        db.query(ManifestConfiguration)
        .filter(ManifestConfiguration.id == config_id)
        .one_or_none()
    )
    if not config:
        return redirect_with_message("/projects", "Project not found.", "warning")

    opportunity = (
        db.query(Opportunity)
        .options(
            selectinload(Opportunity.first_detection_job),
            selectinload(Opportunity.last_detection_job),
        )
        .filter(Opportunity.id == opp_id)
        .one_or_none()
    )
    if not opportunity:
        return redirect_with_message(
            f"/projects/{config_id}", "Opportunity not found.", "warning"
        )
    if opportunity.config_id != config_id:
        return redirect_with_message(
            f"/projects/{config_id}",
            "Opportunity does not belong to this project.",
            "warning",
        )

    local_execution_mode = _is_local_execution_config(config)
    local_workspace_mode = bool(local_execution_mode and config.local_project_path)
    status_label = opportunity.status.replace("_", " ").title()
    if local_execution_mode:
        status_label = {
            "pr_pending": "Local Change Pending",
            "clearing": "Pending Verification",
            "resolved": "Resolved",
            "active": "Active",
        }.get(opportunity.status, status_label)

    if opportunity.severity_score >= 70:
        severity_label = "High"
    elif opportunity.severity_score >= 40:
        severity_label = "Medium"
    else:
        severity_label = "Low"

    evidence = opportunity.evidence_snapshot or {}
    suppressed_findings = evidence.get("suppressed_findings", [])
    generic_evidence = {
        key: value for key, value in evidence.items() if key != "suppressed_findings"
    }

    source_detection_job = (
        opportunity.last_detection_job or opportunity.first_detection_job
    )
    source_sync = (
        db.get(SyncOperation, source_detection_job.sync_id)
        if source_detection_job is not None
        else None
    )

    # Get per-run query cost (latest job cost)
    last_cost_map = get_last_job_costs(db, [opportunity])
    latest_job_cost = last_cost_map.get(opportunity.id)

    opp_dict = {
        "id": opportunity.id,
        "type": opportunity.opportunity_type,
        "affected_table": opportunity.affected_table or "Unknown",
        "dbt_model": opportunity.dbt_model_name or "\u2014",
        "severity_score": opportunity.severity_score,
        "severity_label": severity_label,
        "status": opportunity.status,
        "status_label": status_label,
        "cost_estimate": format_usd(opportunity.current_cost_estimate),
        "cost_estimate_raw": apply_cost_multiplier(opportunity.current_cost_estimate),
        "query_cost_per_run": latest_job_cost,
        "expected_savings": format_usd(opportunity.expected_savings),
        "expected_savings_raw": apply_cost_multiplier(opportunity.expected_savings),
        "explanation": opportunity.explanation or "",
        "evidence": evidence,
        "generic_evidence": generic_evidence,
        "suppressed_findings": suppressed_findings,
        "occurrence_count": opportunity.occurrence_count,
        "created_at": opportunity.created_at.strftime("%d/%m/%Y")
        if opportunity.created_at
        else "\u2014",
        "resolved_at": opportunity.resolved_at.strftime("%d/%m/%Y")
        if opportunity.resolved_at
        else None,
        "clearing_until": opportunity.clearing_until,
        "clearing_pr_number": opportunity.clearing_pr_number,
        "clearing_repository": opportunity.clearing_repository,
    }
    if local_execution_mode and source_sync and source_sync.local_evidence_mode:
        evidence_mode = source_sync.local_evidence_mode
        opp_dict["local_evidence_label"] = {
            "exact_run_jobs": "Last local dbt run",
            "mixed": "Local run + fallback history",
            "historical_table_jobs": "Historical table-scoped evidence",
        }.get(evidence_mode, "Local evidence")
        opp_dict["local_evidence_description"] = {
            "exact_run_jobs": (
                "This recommendation is based on the exact BigQuery jobs recorded in "
                "the latest local run_results.json."
            ),
            "mixed": (
                "Governor matched the latest local dbt run first, then filled a few "
                "gaps with narrow historical warehouse evidence."
            ),
            "historical_table_jobs": (
                "Governor could not match exact run job IDs, so this recommendation "
                "falls back to historical jobs for the same dbt-managed tables."
            ),
        }.get(evidence_mode, None)

    # If clearing, find the PR record for linking
    clearing_pr_record = None
    if (
        not local_execution_mode
        and opportunity.status == "clearing"
        and opportunity.clearing_pr_number
        and opportunity.clearing_repository
    ):
        clearing_pr_record = (
            db.query(PullRequestRecord)
            .filter(
                PullRequestRecord.repository == opportunity.clearing_repository,
                PullRequestRecord.pr_number == opportunity.clearing_pr_number,
            )
            .first()
        )

    solutions_rows = (
        db.query(Solution)
        .filter(Solution.opportunity_id == opp_id)
        .order_by(Solution.version_number.desc())
        .all()
    )

    compiled_original_cache: dict[str, tuple[str | None, str | None]] = {}
    config_cache = {config.id: config}
    solutions_list = []
    cached_dry_runs_updated = False
    for s in solutions_rows:
        sol, updated = _build_solution_view_model(
            db,
            s,
            opportunity=opportunity,
            compiled_original_cache=compiled_original_cache,
            config_cache=config_cache,
        )
        cached_dry_runs_updated = cached_dry_runs_updated or updated
        solutions_list.append(sol)

    if cached_dry_runs_updated:
        db.commit()

    latest_solution = solutions_list[0] if solutions_list else None
    latest_modified_cost = None
    latest_original_cost = None
    if latest_solution:
        latest_modified_dry_run = latest_solution.get("dry_run_modified")
        latest_original_dry_run = latest_solution.get("dry_run_original")
        if latest_modified_dry_run and getattr(latest_modified_dry_run, "valid", True):
            if not latest_solution.get("prefers_possible_savings_display", False):
                latest_modified_cost = latest_modified_dry_run.estimated_cost_usd
        if latest_original_dry_run and getattr(latest_original_dry_run, "valid", True):
            if not latest_solution.get("prefers_possible_savings_display", False):
                latest_original_cost = latest_original_dry_run.estimated_cost_usd
    if latest_solution:
        opp_dict["prefers_possible_savings_display"] = latest_solution.get(
            "prefers_possible_savings_display",
            False,
        )
    # Load workload savings estimate for this opportunity
    wl_est = None
    try:
        from governor_core.opportunities.savings_service import (
            get_estimate as get_savings_estimate,
        )

        wl_est = get_savings_estimate(db, opp_id)
    except sqlalchemy.exc.SQLAlchemyError:
        pass  # Table may not exist yet

    # Determine if the dry run shows actual cost reduction
    _detail_delta_dir: str | None = None
    if (
        latest_modified_cost is not None
        and latest_original_cost is not None
        and latest_modified_cost < latest_original_cost
    ):
        _detail_delta_dir = "down"
    opp_dict.update(
        build_possible_savings_display(
            opportunity_type=opportunity.opportunity_type,
            expected_savings=opportunity.expected_savings,
            occurrence_count=opportunity.occurrence_count,
            optimized_cost_value=latest_modified_cost,
            optimized_delta_direction=_detail_delta_dir,
            workload_per_run_savings=wl_est.per_run_savings if wl_est else None,
            workload_confidence=wl_est.confidence if wl_est else None,
            workload_jobs_analyzed=wl_est.jobs_analyzed if wl_est else None,
            prefer_possible_savings_display=opp_dict.get(
                "prefers_possible_savings_display",
                False,
            ),
            has_solution=bool(latest_solution),
        )
    )

    # Add workload estimate details for detail page display
    if wl_est:
        opp_dict["workload_estimate"] = {
            "jobs_analyzed": wl_est.jobs_analyzed,
            "jobs_with_filters": wl_est.jobs_with_filters,
            "filter_coverage_pct": float(wl_est.filter_coverage_pct),
            "confidence": wl_est.confidence,
            "per_run_savings": wl_est.per_run_savings,
            "monthly_projection": wl_est.monthly_projection,
            "total_cost_saved": wl_est.total_cost_saved,
            "recommendation_type": wl_est.recommendation_type,
        }

    # PR record (if exists). Local execution deliberately suppresses PR chrome
    # on opportunity pages even when old/hybrid GitHub records exist.
    pr_row = None
    if not local_execution_mode:
        pr_row = (
            db.query(PullRequestRecord)
            .filter(PullRequestRecord.opportunity_id == opp_id)
            .one_or_none()
        )
    pr_record = None
    if pr_row:
        pr_record = {
            "id": pr_row.id,
            "pr_url": pr_row.pr_url,
            "pr_number": pr_row.pr_number,
            "branch_name": pr_row.branch_name,
            "created_at": pr_row.created_at.strftime("%d/%m/%Y %H:%M")
            if pr_row.created_at
            else None,
        }

    # Post-merge cost tracking (spec 068)
    verified_savings_data = None
    if (
        opportunity.verified_savings_status
        and opportunity.verified_savings_status != "pending"
    ):
        verified_savings_data = {
            "status": opportunity.verified_savings_status,
            "verified_savings": opportunity.verified_savings,
            "pre_merge_avg_cost": opportunity.pre_merge_avg_cost,
            "post_merge_avg_cost": opportunity.post_merge_avg_cost,
            "pre_merge_job_count": opportunity.pre_merge_job_count,
            "post_merge_job_count": opportunity.post_merge_job_count,
            "calculated_at": opportunity.verified_savings_calculated_at,
        }
    elif opportunity.verified_savings_status == "pending":
        verified_savings_data = {"status": "pending"}

    # Cascade solution linkage (spec 082): if this opportunity is delegated,
    # load the root cause opportunity's solution for display.
    is_delegated = opportunity.cascade_status == "delegated"
    cascade_root = None
    cascade_solution = None
    cascade_pending = False
    cascade_relationship = None

    if is_delegated and opportunity.cascade_root_id:
        relationship_payload = (
            opportunity.evidence_snapshot.get("cascade_relationship")
            if isinstance(opportunity.evidence_snapshot, dict)
            else None
        )
        cascade_root_opp = (
            db.query(Opportunity)
            .filter(Opportunity.id == opportunity.cascade_root_id)
            .one_or_none()
        )
        if cascade_root_opp:
            cascade_root = {
                "id": cascade_root_opp.id,
                "dbt_model_name": cascade_root_opp.dbt_model_name or "Unknown",
                "status": cascade_root_opp.status,
                "clearing_until": cascade_root_opp.clearing_until,
            }
            if relationship_payload:
                cascade_relationship = {
                    "lineage_path": relationship_payload.get("lineage_path") or [],
                    "propagation_reason": relationship_payload.get(
                        "propagation_reason"
                    ),
                }
            root_possible_savings_value = None
            if cascade_root_opp.latest_solution_id:
                root_sol = (
                    db.query(Solution)
                    .filter(Solution.id == cascade_root_opp.latest_solution_id)
                    .one_or_none()
                )
                if root_sol:
                    cascade_solution = _build_solution_view_model(
                        db, root_sol, opportunity=cascade_root_opp
                    )
                    if isinstance(cascade_solution, tuple):
                        cascade_solution = cascade_solution[0]
                    root_possible_savings_value = build_possible_savings_display(
                        opportunity_type=cascade_root_opp.opportunity_type,
                        expected_savings=cascade_root_opp.expected_savings,
                        occurrence_count=cascade_root_opp.occurrence_count,
                        optimized_cost_value=None,
                        optimized_delta_direction=None,
                        prefer_possible_savings_display=cascade_solution.get(
                            "prefers_possible_savings_display",
                            False,
                        ),
                        has_solution=True,
                    ).get("possible_savings_value")
            else:
                cascade_pending = True
            if opp_dict.get("possible_savings_value") is None:
                opp_dict.update(
                    build_inherited_pending_savings_display(
                        root_possible_savings_value=root_possible_savings_value,
                        root_model_name=cascade_root_opp.dbt_model_name,
                    )
                )

    # Check if a solution job is queued or in progress
    from governor_core.solutions.models import SolutionJob
    from governor_core.solutions.service import (
        SolutionService,
        get_solution_job_stale_cutoff,
    )

    SolutionService(db).reclaim_stale_in_progress_jobs(opportunity_id=opp_id)
    stale_cutoff = get_solution_job_stale_cutoff()

    pending_job = (
        db.query(SolutionJob)
        .filter(
            SolutionJob.opportunity_id == opp_id,
            SolutionJob.status.in_(["queued", "in_progress"]),
        )
        .filter(
            (SolutionJob.status == "queued")
            | (SolutionJob.started_at.is_(None))
            | (SolutionJob.started_at >= stale_cutoff)
        )
        .first()
    )
    solution_generating = pending_job is not None
    solution_job_status = pending_job.status if pending_job else None

    # Failed job lookup for recommendation state
    failed_job = None
    job_permanently_failed = False
    if not solution_generating and not solutions_list:
        last_failed = (
            db.query(SolutionJob)
            .filter(
                SolutionJob.opportunity_id == opp_id,
                SolutionJob.status == "failed",
            )
            .order_by(SolutionJob.created_at.desc())
            .first()
        )
        if last_failed:
            job_permanently_failed = True
            failed_job = last_failed

    # Compute recommendation state
    from governor_core.opportunities.recommendation_state import resolve_state

    recommendation_state = resolve_state(
        opportunity_status=opportunity.status,
        cascade_status=opportunity.cascade_status,
        cascade_root_has_solution=cascade_solution is not None,
        solution_job_status=solution_job_status,
        has_solutions=len(solutions_list) > 0,
        has_pr=pr_record is not None,
        job_permanently_failed=job_permanently_failed,
        current_cost_estimate=opportunity.current_cost_estimate,
        min_solution_cost_usd=getattr(config, "min_solution_cost_usd", None),
    )

    # Cost verification run (spec 108)
    cost_verification = None
    try:
        from governor_web.verification.models import CostVerificationRun

        latest_cv = (
            db.query(CostVerificationRun)
            .filter(CostVerificationRun.opportunity_id == opp_id)
            .order_by(CostVerificationRun.created_at.desc())
            .first()
        )
        if latest_cv:
            cost_verification = {
                "id": latest_cv.id,
                "status": latest_cv.status,
                "cost_comparison": latest_cv.cost_comparison,
                "net_delta_usd": float(latest_cv.net_delta_usd)
                if latest_cv.net_delta_usd is not None
                else None,
                "model_count": latest_cv.model_count,
                "error_message": latest_cv.error_message,
                "created_at": latest_cv.created_at,
                "completed_at": latest_cv.completed_at,
            }
    except Exception:
        pass  # Table may not exist yet

    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "project/opportunity_detail.html",
        {
            "title": f"Opportunity: {opportunity.opportunity_type}",
            "flash": get_flash_message(request),
            "user": user,
            "config": config,
            "opportunity": opp_dict,
            "solutions": solutions_list,
            "has_solutions": len(solutions_list) > 0,
            "pr_record": pr_record,
            "route_prefix": "/app",
            "solution_generating": solution_generating,
            "solution_job_status": solution_job_status,
            "verified_savings_data": verified_savings_data,
            "clearing_pr_record": clearing_pr_record,
            "is_delegated": is_delegated,
            "cascade_root": cascade_root,
            "cascade_solution": cascade_solution,
            "cascade_pending": cascade_pending,
            "cascade_relationship": cascade_relationship,
            "local_workspace_mode": local_workspace_mode,
            "local_execution_mode": local_execution_mode,
            "recommendation_state": recommendation_state,
            "failed_job": failed_job,
            "cost_verification": cost_verification,
        },
    )


@router.get(
    "/projects/{config_id}/models/{model_name:path}",
    response_class=HTMLResponse,
)
def app_model_detail(
    request: Request,
    config_id: str,
    model_name: str,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> Response:
    """Spec 125: model-scoped detail page listing all findings for one dbt model."""
    from urllib.parse import unquote

    from governor_core.configurations.models import ManifestConfiguration
    from governor_core.core.config import is_local_mode
    from governor_core.opportunities.explorer_service import (
        _MODEL_STATE_SEVERITY_RANK,
        _opportunity_to_state_key,
        _rollup_worst_state,
    )
    from governor_core.opportunities.models import Opportunity

    user = _get_authenticated_user(request, db, auth_session)
    if not user:
        return redirect_with_message("/login", "Please sign in to continue.", "warning")

    decoded_model_name = unquote(model_name)
    config = (
        db.query(ManifestConfiguration)
        .filter(ManifestConfiguration.id == config_id)
        .one_or_none()
    )
    if not config:
        return redirect_with_message("/projects", "Project not found.", "warning")

    opps = (
        db.query(Opportunity)
        .filter(
            Opportunity.config_id == config_id,
            Opportunity.dbt_model_name == decoded_model_name,
            Opportunity.status.in_(("active", "pr_pending", "clearing")),
        )
        .all()
    )
    if not opps:
        return redirect_with_message(
            "/opportunities",
            f"No active opportunities found for model {decoded_model_name}.",
            "warning",
        )

    # Local mode: we generate one solution per model, so the model-scoped
    # listing is redundant — jump straight to the representative finding.
    # Prefer the opportunity that already carries a solution; otherwise the
    # highest-severity / highest-cost one.
    if is_local_mode():

        def _rank(opp):
            return (
                1 if opp.latest_solution_id else 0,
                opp.severity_score or 0,
                float(opp.current_cost_estimate or 0),
            )

        representative = max(opps, key=_rank)
        return RedirectResponse(
            url=f"/projects/{config.id}/opportunities/{representative.id}",
            status_code=302,
        )

    # Build a light "finding" dict per opportunity. Keeps the page fast and
    # defers full apply/regenerate UX to the per-opportunity detail URL that
    # each finding still links to.
    findings = []
    state_keys: list[str] = []
    total_cost = None
    total_savings = None
    for opp in opps:
        state_key = _opportunity_to_state_key(
            {
                "status": opp.status,
                "has_solution": opp.latest_solution_id is not None,
                "solution_risk_level": opp.latest_solution_risk_level,
                "cascade_status": opp.cascade_status,
                "solution_job_status": None,
            }
        )
        state_keys.append(state_key)
        findings.append(
            {
                "id": opp.id,
                "opportunity_type": opp.opportunity_type,
                "current_cost_estimate": opp.current_cost_estimate,
                "expected_savings": opp.expected_savings,
                "severity_score": opp.severity_score,
                "cascade_status": opp.cascade_status,
                "status": opp.status,
                "state_key": state_key,
                "risk_level": opp.latest_solution_risk_level,
                "last_detected_at": opp.last_detected_at,
                "detail_url": f"/projects/{config.id}/opportunities/{opp.id}",
            }
        )
        if opp.current_cost_estimate is not None:
            total_cost = (total_cost or 0) + opp.current_cost_estimate
        if opp.expected_savings is not None:
            total_savings = (total_savings or 0) + opp.expected_savings

    # Sort findings by severity rank (worst first) for predictable rendering.
    findings.sort(key=lambda f: -_MODEL_STATE_SEVERITY_RANK.get(f["state_key"], 0))
    worst_state = _rollup_worst_state(state_keys)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "project/model_detail.html",
        {
            "title": decoded_model_name,
            "user": user,
            "flash": get_flash_message(request),
            "config": config,
            "model_name": decoded_model_name,
            "findings": findings,
            "finding_count": len(findings),
            "total_cost": total_cost,
            "total_savings": total_savings,
            "worst_state": worst_state,
        },
    )


@router.get(
    "/draft-ui/project/{config_id}/opportunity/{opp_id}",
    response_class=HTMLResponse,
)
def draft_ui_opportunity_detail(
    request: Request,
    config_id: str,
    opp_id: str,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> Response:
    """Legacy opportunity detail alias retained for backward compatibility."""
    return app_opportunity_detail(
        request=request,
        config_id=config_id,
        opp_id=opp_id,
        db=db,
        auth_session=auth_session,
    )


# ---------------------------------------------------------------------------
# Pull request creation (spec 018)
# ---------------------------------------------------------------------------


@router.post("/app/project/{config_id}/opportunity/{opp_id}/create-pr")
def create_pr_route(
    request: Request,
    config_id: str,
    opp_id: str,
    solution_id: str = Form(...),
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> Response:
    """Create a GitHub pull request from an opportunity's solution."""
    from governor_core.configurations.models import ManifestConfiguration
    from governor_core.github.client import (
        GitHubAuthenticationError,
        GitHubConnectionError,
        GitHubFileNotFoundError,
        GitHubRateLimitError,
    )
    from governor_core.pullrequests.exceptions import (
        DuplicatePRError,
        FileDriftError,
        PRCreationError,
    )
    from governor_core.pullrequests.service import PullRequestService
    from governor_web.setup.runtime import create_github_client

    user = _get_authenticated_user(request, db, auth_session)
    if not user:
        return redirect_with_message("/login", "Please sign in to continue.", "warning")

    config = (
        db.query(ManifestConfiguration)
        .filter(ManifestConfiguration.id == config_id)
        .one_or_none()
    )
    if not config:
        return redirect_with_message("/app", "Project not found.", "warning")

    detail_url = f"/projects/{config_id}/opportunities/{opp_id}"

    github_client = create_github_client()
    if github_client is None:
        return redirect_with_message(
            detail_url, "GitHub integration is not configured.", "error"
        )

    try:
        service = PullRequestService(db, github_client)
        pr_record = service.create_pr(
            opportunity_id=opp_id,
            solution_id=solution_id,
            user_id=user.id,
        )
        return redirect_with_message(
            detail_url,
            f"Draft PR #{pr_record.pr_number} created: {pr_record.pr_url}",
            "success",
            action_url=f"/admin/prs/{pr_record.id}",
            action_label="Open Pull Requests",
        )
    except DuplicatePRError as exc:
        return redirect_with_message(
            detail_url,
            f"A pull request already exists: {exc.pr_url}",
            "warning",
        )
    except FileDriftError:
        return redirect_with_message(
            detail_url,
            "The source file has changed since this solution was generated. Please regenerate the solution.",
            "warning",
        )
    except PRCreationError as exc:
        logging.getLogger("app.routes.app").warning(
            "pull request creation failed",
            extra={"opportunity_id": opp_id, "config_id": config_id},
            exc_info=exc,
        )
        return redirect_with_message(
            detail_url,
            "Failed to create the pull request. Please try again.",
            "error",
        )
    except GitHubAuthenticationError:
        return redirect_with_message(
            detail_url,
            "GitHub authentication failed. Check the GitHub App configuration.",
            "error",
        )
    except GitHubConnectionError:
        return redirect_with_message(
            detail_url,
            "Unable to connect to GitHub. Please try again later.",
            "error",
        )
    except GitHubRateLimitError:
        return redirect_with_message(
            detail_url,
            "GitHub API rate limit exceeded. Please try again later.",
            "error",
        )
    except GitHubFileNotFoundError:
        return redirect_with_message(
            detail_url,
            "The source file was not found in the repository.",
            "error",
        )


# ---------------------------------------------------------------------------
# Regenerate solution for a single opportunity (spec 030)
# ---------------------------------------------------------------------------


@router.post("/app/project/{config_id}/opportunity/{opp_id}/regenerate-solution")
def regenerate_opportunity_solution(
    request: Request,
    config_id: str,
    opp_id: str,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> RedirectResponse:
    """Delete existing solutions for an opportunity and re-queue generation."""
    from governor_core.solutions.service import SolutionService

    user = _get_authenticated_user(request, db, auth_session)
    if not user:
        return redirect_with_message("/login", "Please sign in to continue.", "warning")

    detail_url = f"/projects/{config_id}/opportunities/{opp_id}"

    svc = SolutionService(db)
    try:
        svc.requeue_opportunity_solution(opp_id)
        return redirect_with_message(
            detail_url,
            "Solution re-queued for generation. The worker will process it shortly.",
            "success",
        )
    except (ValueError, RuntimeError, sqlalchemy.exc.SQLAlchemyError) as exc:
        logging.getLogger("app.routes.app").warning(
            "failed to regenerate solution",
            extra={"opportunity_id": opp_id, "config_id": config_id},
            exc_info=exc,
        )
        return redirect_with_message(
            detail_url,
            "Failed to regenerate the solution. Please try again.",
            "error",
        )


@router.post("/app/project/{config_id}/opportunity/{opp_id}/apply-local")
def apply_solution_locally(
    request: Request,
    config_id: str,
    opp_id: str,
    solution_id: str = Form(...),
    action: str = Form(default="apply"),
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> RedirectResponse:
    """Apply a solution directly to the local working tree (spec 084)."""
    from governor_core.configurations.models import ManifestConfiguration
    from governor_core.core.config import is_local_mode
    from governor_core.opportunities.models import Opportunity
    from governor_core.solutions.models import Solution
    from governor_core.workspace.detection import write_local_file

    user = _get_authenticated_user(request, db, auth_session)
    if not user:
        return redirect_with_message("/login", "Please sign in to continue.", "warning")

    detail_url = f"/projects/{config_id}/opportunities/{opp_id}"

    if not is_local_mode():
        return redirect_with_message(
            detail_url, "Local apply is only available in local mode.", "warning"
        )

    config = (
        db.query(ManifestConfiguration)
        .filter(ManifestConfiguration.id == config_id)
        .one_or_none()
    )
    if not config or not config.local_project_path:
        return redirect_with_message(
            detail_url, "No local project path configured.", "warning"
        )

    solution = db.query(Solution).filter(Solution.id == solution_id).one_or_none()
    opportunity = db.query(Opportunity).filter(Opportunity.id == opp_id).one_or_none()
    file_changes = solution.normalized_file_changes if solution else []
    file_changes = [
        fc for fc in file_changes if fc.get("file_path") and fc.get("after_content")
    ]
    if not solution or solution.opportunity_id != opp_id or not file_changes:
        return redirect_with_message(
            detail_url, "Solution not found or has no file changes.", "warning"
        )

    primary_path = file_changes[0]["file_path"]
    multi_file = len(file_changes) > 1
    written_label = (
        f"{primary_path} (+{len(file_changes) - 1} more)"
        if multi_file
        else primary_path
    )

    try:
        for fc in file_changes:
            write_local_file(
                config.local_project_path,
                fc["file_path"],
                fc["after_content"],
            )

        # Mark opportunity as applied (pr_pending in local mode)
        if opportunity.status == "active":
            opportunity.status = "pr_pending"
            db.commit()

        if action == "apply_and_commit":
            commit_message = _build_local_commit_message(opportunity, solution)
            from governor_core.workspace.git_tools import commit_local_files

            commit_sha = commit_local_files(
                config.local_project_path,
                [fc["file_path"] for fc in file_changes],
                commit_message,
            )
            short_sha = commit_sha[:8] if commit_sha else "unknown"
            return redirect_with_message(
                detail_url,
                (
                    f"Solution applied to {written_label} and committed "
                    f"locally as {short_sha}."
                ),
                "success",
            )
        return redirect_with_message(
            detail_url,
            f"Solution applied to {written_label}.",
            "success",
        )
    except ValueError as exc:
        return redirect_with_message(detail_url, f"Path error: {exc}", "error")
    except RuntimeError as exc:
        return redirect_with_message(
            detail_url,
            (
                f"Solution applied to {written_label}, but the local git commit "
                f"failed: {exc}"
            ),
            "warning",
        )
    except OSError as exc:
        return redirect_with_message(detail_url, f"File write failed: {exc}", "error")


# ---------------------------------------------------------------------------
# Shadow validation from web UI (spec 110)
# ---------------------------------------------------------------------------


@router.get("/app/shadow-runs/{run_id}/tail")
def shadow_run_tail(
    request: Request,  # noqa: ARG001 — kept for future auth gating
    run_id: str,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> JSONResponse:
    """Lightweight JSON poll endpoint for the live-terminal on in-flight
    shadow runs.

    The opportunity detail page needs to update its terminal pane while a
    cascade runs (auto-triggered validations have no SSE listener), so
    instead of reloading the whole page every few seconds we fetch just
    the current ``status`` and ``build_logs``. The client stops polling
    once ``status`` reaches a terminal value.
    """
    from governor_core.shadow.models import ShadowValidationRun

    run = db.get(ShadowValidationRun, run_id)
    if run is None:
        return JSONResponse({"error": "not_found"}, status_code=404)

    return JSONResponse(
        {
            "id": run.id,
            "status": run.status,
            "build_logs": run.build_logs or "",
            "cascade_size": run.cascade_size,
            "triggered_by": run.triggered_by,
            "is_terminal": run.status
            in (
                "succeeded",
                "shadow_failed",
                "baseline_failed",
                "skipped",
                "timed_out",
                "quota_exhausted",
            ),
        }
    )


@router.post("/app/project/{config_id}/opportunity/{opp_id}/shadow-validate")
def run_shadow_validation_from_ui(
    request: Request,
    config_id: str,
    opp_id: str,
    solution_id: str = Form(...),
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> RedirectResponse:
    """Run shadow validation synchronously against the user's local dbt project.

    Runs baseline + shadow builds via dbt, captures metrics, persists the
    `ShadowValidationRun` row, and redirects back to the opportunity page with
    a flash message. The comparison table is rendered on the reloaded page.
    """
    from governor_core.configurations.models import ManifestConfiguration
    from governor_core.core.config import is_local_mode
    from governor_core.shadow.builder import run_dbt_cascade
    from governor_core.shadow.gating import evaluate_gates
    from governor_core.shadow.metrics import metrics_from_run_results
    from governor_core.shadow.service import run_shadow_validation
    from governor_core.solutions.models import Solution
    from governor_core.sync.models import ManifestVersion

    user = _get_authenticated_user(request, db, auth_session)
    if not user:
        return redirect_with_message("/login", "Please sign in to continue.", "warning")

    detail_url = f"/projects/{config_id}/opportunities/{opp_id}"

    if not is_local_mode():
        return redirect_with_message(
            detail_url,
            "Shadow validation is only available in local mode.",
            "warning",
        )

    config = db.get(ManifestConfiguration, config_id)
    if not config or not config.local_project_path:
        return redirect_with_message(
            detail_url, "No local project path configured.", "warning"
        )

    # Clicking Run Comparison is explicit consent to run shadow validation —
    # flip the opt-in flag if it isn't already on.
    if not config.shadow_validation_enabled:
        config.shadow_validation_enabled = True
        db.commit()

    solution = db.get(Solution, solution_id)
    if not solution or solution.opportunity_id != opp_id:
        return redirect_with_message(detail_url, "Solution not found.", "warning")

    if not solution.manifest_version_id:
        return redirect_with_message(
            detail_url,
            "Solution has no linked manifest version — shadow validation unavailable.",
            "warning",
        )
    manifest_version = db.get(ManifestVersion, solution.manifest_version_id)
    if not manifest_version or not manifest_version.content:
        return redirect_with_message(
            detail_url, "Manifest content unavailable.", "warning"
        )
    manifest_content = manifest_version.content

    # Resolve the target dbt node id from the file path.
    target_node_id = ""
    if solution.file_path:
        for node_id, node in (manifest_content.get("nodes") or {}).items():
            if (
                node_id.startswith("model.")
                and node.get("original_file_path") == solution.file_path
            ):
                target_node_id = node_id
                break
    if not target_node_id:
        return redirect_with_message(
            detail_url,
            f"Could not resolve target model from file_path={solution.file_path}",
            "warning",
        )

    def _builder(*, phase, cascade, run_id):
        return run_dbt_cascade(
            phase=phase,
            cascade=cascade,
            run_id=run_id,
            solution=solution,
            configuration=config,
            manifest_content=manifest_content,
        )

    def _metrics(*, run_results, expected_models):
        return metrics_from_run_results(
            run_results=run_results, expected_models=expected_models
        )

    try:
        output = run_shadow_validation(
            db,
            solution=solution,
            configuration=config,
            manifest_content=manifest_content,
            target_node_id=target_node_id,
            builder_fn=_builder,
            metrics_fn=_metrics,
            gate_fn=evaluate_gates,
        )
    except Exception as exc:  # noqa: BLE001
        return redirect_with_message(
            detail_url, f"Shadow validation errored: {exc}", "error"
        )

    if output.skipped:
        return redirect_with_message(
            detail_url,
            f"Shadow validation skipped: {output.skipped_reason}.",
            "warning",
        )

    if output.run.status == "succeeded":
        savings = ""
        if output.diff and output.diff.cost_delta_usd is not None:
            delta = -float(output.diff.cost_delta_usd)
            if delta > 0:
                savings = f" Savings per run: ${delta:,.4f}."
        return redirect_with_message(
            detail_url,
            f"Shadow validation complete — results below.{savings}",
            "success",
        )

    return redirect_with_message(
        detail_url,
        f"Shadow validation failed: {output.run.failure_reason}.",
        "error",
    )


@router.get("/app/project/{config_id}/opportunity/{opp_id}/shadow-validate-stream")
def stream_shadow_validation(
    request: Request,
    config_id: str,
    opp_id: str,
    solution_id: str,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> StreamingResponse:
    """Stream shadow validation progress via Server-Sent Events.

    Runs shadow validation in a background thread, relaying each dbt stdout
    line to the client as an SSE `line` event. Emits `phase` events at
    gating/baseline/shadow transitions and a final `result` event with the
    run status. Client redirects on completion.
    """
    import queue as _q
    import threading

    from governor_core.configurations.models import ManifestConfiguration
    from governor_core.core.config import is_local_mode
    from governor_core.shadow.builder import run_dbt_cascade
    from governor_core.shadow.gating import evaluate_gates
    from governor_core.shadow.metrics import metrics_from_run_results
    from governor_core.shadow.service import run_shadow_validation
    from governor_core.solutions.models import Solution
    from governor_core.sync.models import ManifestVersion

    detail_url = f"/projects/{config_id}/opportunities/{opp_id}"

    # Capture handles we need inside the thread synchronously (session is per-request;
    # we stream via a fresh session created inside the thread below).
    user = _get_authenticated_user(request, db, auth_session)
    if not user:
        return StreamingResponse(
            iter(["event: error\ndata: not authenticated\n\n"]),
            media_type="text/event-stream",
        )

    events: _q.Queue = _q.Queue()
    # Captures the full terminal stream (every phase, line, result event)
    # so we can overwrite run.build_logs after the worker finishes — the
    # service only captures its own phase/result events and never sees the
    # per-line dbt stdout that reaches us via the builder's output_callback.
    full_log_lines: list[str] = []

    def _emit(event_type: str, payload: str) -> None:
        if event_type in ("line", "phase", "result") and payload:
            prefix = {"line": "", "phase": "▸ ", "result": "● "}[event_type]
            full_log_lines.append(f"{prefix}{payload}")
        events.put((event_type, payload))

    def _run_in_thread() -> None:
        """Open a fresh DB session inside the worker thread."""
        from governor_core.db.session import SessionLocal

        try:
            with SessionLocal() as thread_db:
                config = thread_db.get(ManifestConfiguration, config_id)
                if not config or not config.local_project_path:
                    _emit("error", "no local_project_path configured")
                    return
                if not is_local_mode():
                    _emit("error", "not running in local mode")
                    return
                # Auto-enable flag
                if not config.shadow_validation_enabled:
                    config.shadow_validation_enabled = True
                    thread_db.commit()

                solution = thread_db.get(Solution, solution_id)
                if not solution or solution.opportunity_id != opp_id:
                    _emit("error", "solution not found")
                    return
                if not solution.manifest_version_id:
                    _emit("error", "no manifest version linked")
                    return
                manifest_version = thread_db.get(
                    ManifestVersion, solution.manifest_version_id
                )
                if not manifest_version or not manifest_version.content:
                    _emit("error", "manifest content unavailable")
                    return
                manifest_content = manifest_version.content

                target_node_id = ""
                if solution.file_path:
                    for node_id, node in (manifest_content.get("nodes") or {}).items():
                        if (
                            node_id.startswith("model.")
                            and node.get("original_file_path") == solution.file_path
                        ):
                            target_node_id = node_id
                            break
                if not target_node_id:
                    _emit(
                        "error",
                        f"could not resolve target model from file_path={solution.file_path}",
                    )
                    return

                def _line_cb(line: str) -> None:
                    _emit("line", line)

                def _builder(*, phase, cascade, run_id):
                    _emit(
                        "phase", f"{phase}: running dbt against {len(cascade)} model(s)"
                    )
                    return run_dbt_cascade(
                        phase=phase,
                        cascade=cascade,
                        run_id=run_id,
                        solution=solution,
                        configuration=config,
                        manifest_content=manifest_content,
                        output_callback=_line_cb,
                    )

                def _metrics(*, run_results, expected_models):
                    return metrics_from_run_results(
                        run_results=run_results, expected_models=expected_models
                    )

                output = None
                try:
                    output = run_shadow_validation(
                        thread_db,
                        solution=solution,
                        configuration=config,
                        manifest_content=manifest_content,
                        target_node_id=target_node_id,
                        builder_fn=_builder,
                        metrics_fn=_metrics,
                        gate_fn=evaluate_gates,
                        progress_callback=_emit,
                    )
                except Exception as exc:  # noqa: BLE001
                    _emit("error", str(exc))

                # Overwrite run.build_logs with the full captured stream —
                # the service only stores phase/result events; per-line dbt
                # stdout lives here in the route's full_log_lines buffer.
                if output is not None and full_log_lines:
                    try:
                        joined = "\n".join(full_log_lines)
                        if len(joined) > 200_000:
                            joined = joined[-200_000:]
                        output.run.build_logs = joined
                        thread_db.commit()
                    except Exception as exc:  # noqa: BLE001
                        logging.getLogger("app.routes.app").warning(
                            "persist build_logs failed: %s", exc
                        )
        finally:
            _emit("done", detail_url)

    worker = threading.Thread(target=_run_in_thread, daemon=True)
    worker.start()

    def _stream() -> Generator[str, None, None]:
        # Initial hello so the browser shows something immediately
        yield "event: phase\ndata: Starting shadow validation...\n\n"
        while True:
            try:
                event_type, payload = events.get(timeout=30)
            except Exception:  # noqa: BLE001
                # Keep-alive comment so proxies don't close
                yield ": keep-alive\n\n"
                continue
            # Escape newlines in payload (SSE data cannot contain raw newlines
            # without repeating "data: " per line)
            safe = payload.replace("\r", "").replace("\n", " ")
            yield f"event: {event_type}\ndata: {safe}\n\n"
            if event_type == "done":
                break

    return StreamingResponse(
        _stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


# ---------------------------------------------------------------------------
# Cost impact verification (spec 108)
# ---------------------------------------------------------------------------


@router.post("/app/project/{config_id}/opportunity/{opp_id}/verify-cost")
def verify_cost_impact(
    request: Request,
    config_id: str,
    opp_id: str,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> RedirectResponse:
    """Queue a cost verification build for a locally-applied solution."""
    from governor_core.configurations.models import ManifestConfiguration
    from governor_core.opportunities.models import Opportunity
    from governor_web.verification.cost_verification import CostVerificationService
    from governor_web.verification.models import CostVerificationRun

    user = _get_authenticated_user(request, db, auth_session)
    if not user:
        return redirect_with_message("/login", "Please sign in to continue.", "warning")

    detail_url = f"/projects/{config_id}/opportunities/{opp_id}"

    opportunity = db.query(Opportunity).filter(Opportunity.id == opp_id).one_or_none()
    if not opportunity:
        return redirect_with_message(detail_url, "Opportunity not found.", "warning")

    if opportunity.status != "pr_pending":
        return redirect_with_message(
            detail_url,
            "Cost verification is only available for applied solutions (pr_pending status).",
            "warning",
        )

    config = (
        db.query(ManifestConfiguration)
        .filter(ManifestConfiguration.id == config_id)
        .one_or_none()
    )
    if not config:
        return redirect_with_message(detail_url, "Project not found.", "warning")

    svc = CostVerificationService(db)
    baseline_sync = svc.find_baseline_sync(config_id)
    if not baseline_sync:
        return redirect_with_message(
            detail_url,
            "No baseline costs available. Run dbt build first, then sync.",
            "error",
        )

    # Derive dbt selector from the opportunity model name
    model_name = opportunity.dbt_model_name
    if not model_name:
        table = opportunity.affected_table or ""
        model_name = table.split(".")[-1] if "." in table else table

    verification_run = CostVerificationRun(
        status="queued",
        opportunity_id=opp_id,
        config_id=config_id,
        baseline_sync_id=baseline_sync.id,
        dbt_selector=f"{model_name}+",
    )
    db.add(verification_run)
    db.commit()

    return redirect_with_message(
        detail_url,
        "Cost verification build queued. The worker will process it shortly.",
        "success",
    )


# ---------------------------------------------------------------------------
# Spec 128: downstream-patch bundle routes (local mode only)
# ---------------------------------------------------------------------------


@router.post("/app/solutions/{solution_id}/patches/{patch_index}/filter")
def edit_downstream_patch_filter(
    request: Request,
    solution_id: str,
    patch_index: int,
    filter_expression: str = Form(...),
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
):
    """Persist a user-edited filter expression on a downstream patch."""
    from datetime import datetime, timezone

    from governor_core.core.config import is_local_mode
    from governor_core.solutions.models import Solution

    if not is_local_mode():
        raise HTTPException(status_code=404)

    user = _get_authenticated_user(request, db, auth_session)
    if not user:
        raise HTTPException(status_code=401)

    if patch_index <= 0:
        raise HTTPException(
            status_code=400,
            detail="patch_index must be > 0 (index 0 is the upstream guardrail)",
        )

    solution = db.get(Solution, solution_id)
    if solution is None:
        raise HTTPException(status_code=404)

    changes = list(solution.file_changes or [])
    if patch_index >= len(changes):
        raise HTTPException(status_code=404, detail="patch index out of range")

    entry = dict(changes[patch_index])
    proposal_meta = dict(entry.get("proposal_meta") or {})
    if proposal_meta.get("change_type") != "downstream_partition_filter_patch":
        raise HTTPException(status_code=400, detail="not a downstream patch")

    before_content = entry.get("before_content") or ""
    prior_filter = proposal_meta.get("proposed_filter") or ""
    after_content = entry.get("after_content") or before_content

    new_filter = filter_expression.strip()
    if not new_filter:
        raise HTTPException(status_code=400, detail="filter_expression empty")

    # Naive string-replace: swap prior filter for new filter inside after_content.
    # When the replacement does not match we flag the patch as manual_required
    # so the user knows they must hand-edit the file directly.
    if prior_filter and prior_filter in after_content:
        new_after = after_content.replace(prior_filter, new_filter)
        proposal_meta["status"] = "edited"
    else:
        # Fall back: append a WHERE clause naively to the original.
        new_after = before_content.rstrip() + f"\nWHERE {new_filter}\n"
        proposal_meta["status"] = "edited"

    proposal_meta["proposed_filter"] = new_filter
    proposal_meta["edited_at"] = datetime.now(timezone.utc).isoformat()
    proposal_meta["abstain_reason"] = None

    entry["after_content"] = new_after
    entry["proposal_meta"] = proposal_meta
    changes[patch_index] = entry
    solution.file_changes = changes
    solution.updated_at = datetime.now(timezone.utc)
    db.commit()

    return JSONResponse(
        {
            "solution_id": solution.id,
            "patch_index": patch_index,
            "status": proposal_meta["status"],
            "proposed_filter": new_filter,
        }
    )


@router.post("/app/solutions/{solution_id}/reshadow")
def trigger_reshadow_on_bundle(
    request: Request,
    solution_id: str,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
):
    """Enqueue a fresh shadow validation run over the current bundle."""
    from governor_core.core.config import is_local_mode
    from governor_core.solutions.models import Solution
    from governor_core.solutions.reshadow import kick_off_reshadow

    if not is_local_mode():
        raise HTTPException(status_code=404)

    user = _get_authenticated_user(request, db, auth_session)
    if not user:
        raise HTTPException(status_code=401)

    solution = db.get(Solution, solution_id)
    if solution is None:
        raise HTTPException(status_code=404)

    validation_report = solution.validation_report or {}
    # Spec 132: dispatch via the guardrail-provider registry. This route
    # applies to solutions whose template_id identifies a registered
    # breaking-change guardrail; everything else is a 400.
    from governor_core.agents.downstream_patch.providers import get_provider

    if get_provider(validation_report.get("template_id")) is None:
        raise HTTPException(
            status_code=400,
            detail="reshadow route only applies to registered guardrail solutions",
        )

    new_run = kick_off_reshadow(db, solution)
    db.commit()

    return JSONResponse(
        {
            "solution_id": solution.id,
            "shadow_run_id": new_run.id,
            "status": new_run.status,
        },
        status_code=202,
    )


# ---------------------------------------------------------------------------
# Solutions list & regenerate (spec 014)
# ---------------------------------------------------------------------------
