from __future__ import annotations

import logging
from datetime import datetime, timezone

from apscheduler.jobstores.base import JobLookupError
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.interval import IntervalTrigger

logger = logging.getLogger("app.scheduling")


class ScheduleValidationError(Exception):
    """Raised when a schedule configuration is invalid."""


class SchedulingService:
    """Bridge between application schedule configuration and APScheduler."""

    @staticmethod
    def validate_schedule(schedule_type: str, schedule_value: str) -> None:
        """Validate schedule type and value.

        Raises:
            ScheduleValidationError: If the schedule is invalid.
        """
        if schedule_type not in ("interval", "cron"):
            raise ScheduleValidationError("Schedule type must be 'interval' or 'cron'.")

        if schedule_type == "interval":
            try:
                hours = int(schedule_value)
            except (ValueError, TypeError):
                raise ScheduleValidationError(
                    "Interval must be a whole number of hours, minimum 1."
                )
            if hours < 1:
                raise ScheduleValidationError(
                    "Interval must be a whole number of hours, minimum 1."
                )
            return

        # Cron validation
        try:
            trigger = CronTrigger.from_crontab(schedule_value, timezone="UTC")
        except (ValueError, KeyError) as exc:
            raise ScheduleValidationError(f"Invalid cron expression: {exc}")

        # Enforce minimum 1-hour frequency
        now = datetime.now(timezone.utc)
        next1 = trigger.get_next_fire_time(None, now)
        if next1 is None:
            raise ScheduleValidationError(
                "Cron expression does not produce any future fire times."
            )
        next2 = trigger.get_next_fire_time(next1, next1)
        if next2 is not None:
            gap = (next2 - next1).total_seconds()
            if gap < 3600:
                raise ScheduleValidationError(
                    "Schedule frequency must be at least 1 hour."
                )

    @staticmethod
    def register_schedule(scheduler, config) -> None:
        """Add or replace an APScheduler job for a configuration.

        Args:
            scheduler: APScheduler AsyncIOScheduler instance
            config: ManifestConfiguration instance
        """
        job_id = f"sync-{config.id}"

        if not config.schedule_enabled:
            # If disabled, try to pause the existing job
            try:
                scheduler.pause_job(job_id)
            except JobLookupError:
                pass
            return

        if config.schedule_type == "interval":
            hours = int(config.schedule_value)
            trigger = IntervalTrigger(hours=hours, timezone="UTC")
        else:
            trigger = CronTrigger.from_crontab(config.schedule_value, timezone="UTC")

        # Determine next_run_time for immediate first run
        kwargs = {}
        if (
            config.schedule_type == "interval"
            and config.schedule_enabled
            and config.schedule_last_run_at is None
        ):
            kwargs["next_run_time"] = datetime.now(timezone.utc)

        scheduler.add_job(
            execute_scheduled_sync,
            trigger=trigger,
            id=job_id,
            args=[config.id],
            replace_existing=True,
            coalesce=True,
            misfire_grace_time=None,
            **kwargs,
        )

        logger.info(
            "Registered schedule for config %s: type=%s, value=%s",
            config.id,
            config.schedule_type,
            config.schedule_value,
        )

    @staticmethod
    def pause_schedule(scheduler, config_id: str) -> None:
        """Pause an APScheduler job."""
        job_id = f"sync-{config_id}"
        try:
            scheduler.pause_job(job_id)
            logger.info("Paused schedule for config %s", config_id)
        except JobLookupError:
            logger.debug("No job to pause for config %s", config_id)

    @staticmethod
    def resume_schedule(scheduler, config_id: str) -> None:
        """Resume an APScheduler job."""
        job_id = f"sync-{config_id}"
        try:
            scheduler.resume_job(job_id)
            logger.info("Resumed schedule for config %s", config_id)
        except JobLookupError:
            logger.debug("No job to resume for config %s", config_id)

    @staticmethod
    def remove_schedule(scheduler, config_id: str) -> None:
        """Remove an APScheduler job."""
        job_id = f"sync-{config_id}"
        try:
            scheduler.remove_job(job_id)
            logger.info("Removed schedule for config %s", config_id)
        except JobLookupError:
            logger.debug("No job to remove for config %s", config_id)

    @staticmethod
    def get_next_run_time(scheduler, config_id: str) -> datetime | None:
        """Get the next scheduled run time for a configuration."""
        job_id = f"sync-{config_id}"
        try:
            job = scheduler.get_job(job_id)
            if job:
                return job.next_run_time
        except JobLookupError:
            pass
        return None


def execute_scheduled_sync(config_id: str) -> None:
    """APScheduler job callback that creates a sync operation.

    Opens a DB session, checks config is active, creates a sync operation
    via SyncService, and updates schedule_last_run_at.

    Imports SessionLocal directly to avoid pickling issues with
    APScheduler's SQLAlchemy job store.
    """
    from governor_core.configurations.models import ManifestConfiguration
    from governor_core.db.session import SessionLocal
    from governor_core.sync.service import DuplicateSyncError, SyncService

    session = SessionLocal()
    try:
        config = (
            session.query(ManifestConfiguration)
            .filter(ManifestConfiguration.id == config_id)
            .one_or_none()
        )

        if not config:
            logger.warning("Scheduled sync: config %s not found, skipping", config_id)
            return

        if config.status == "disabled":
            logger.info("Scheduled sync: config %s is disabled, skipping", config_id)
            return

        if not config.schedule_enabled:
            logger.info(
                "Scheduled sync: schedule disabled for config %s, skipping", config_id
            )
            return

        sync_service = SyncService(session)
        try:
            sync_service.create_sync_operation(
                config_id, None, triggered_by="scheduled"
            )
            logger.info("Scheduled sync created for config %s", config_id)
        except DuplicateSyncError:
            logger.info(
                "Scheduled sync skipped for config %s: sync already in progress",
                config_id,
            )

        # Update last run time
        config.schedule_last_run_at = datetime.now(timezone.utc)
        session.commit()

    except (ValueError, RuntimeError):
        logger.exception("Error in scheduled sync for config %s", config_id)
        session.rollback()
    finally:
        session.close()
