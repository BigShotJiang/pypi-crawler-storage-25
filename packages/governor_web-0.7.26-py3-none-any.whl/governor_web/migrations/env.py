from __future__ import annotations

from logging.config import fileConfig

from alembic import context
from sqlalchemy import engine_from_config, pool

from governor_core.core.config import get_settings
from governor_core.db.base import Base

# Import web-owned models so autogenerate sees them on Base.metadata.
from governor_web.auth import models as _auth  # noqa: F401 E402
from governor_web.notifications import models as _notif  # noqa: F401 E402
from governor_web.settings import models as _settings  # noqa: F401 E402
from governor_web.setup import models as _setup  # noqa: F401 E402
from governor_web.verification import models as _verify  # noqa: F401 E402

config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name, disable_existing_loggers=False)

settings = get_settings()
config.set_main_option("sqlalchemy.url", settings.database_url)

target_metadata = Base.metadata

_WEB_OWNED_TABLES = frozenset(
    {
        "users",
        "roles",
        "user_roles",
        "sessions",
        "audit_events",
        "password_reset_tokens",
        "invitations",
        "notifications",
        "setup_state",
        "organisation_settings",
        "verification_runs",
        "verification_checks",
    }
)


def include_object(object, name, type_, reflected, compare_to):
    """Only autogenerate for web-owned tables and ignore APScheduler's own."""
    if type_ == "table":
        if name == "apscheduler_jobs":
            return False
        return name in _WEB_OWNED_TABLES
    return True


def run_migrations_offline() -> None:
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        compare_type=True,
        include_object=include_object,
        version_table="alembic_web_version",
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            compare_type=True,
            include_object=include_object,
            version_table="alembic_web_version",
        )

        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
