"""Spec 120 monorepo split — web split-point.

No-op revision that establishes an independent Alembic chain for the web
stream. Web-owned tables (users, roles, sessions, audit_events, etc.) were
first created in the legacy chain, which now lives under governor-core.
Post-split, new web migrations build on this revision. Operators upgrade
core first, then web.
"""

from __future__ import annotations

revision = "split_120_web"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
