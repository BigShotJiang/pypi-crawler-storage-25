# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from simready.search import AssetLibrary, SearchFilterFeature, SearchFilterProfile


def example_feature2():
    # Initialize library with the USD-Search service endpoint
    service_endpoint = "https://search.simready.omniverse.nvidia.com/"
    asset_library = AssetLibrary()
    asset_library.add_service_source(service_endpoint)

    # Search for multibody robot props
    matches = asset_library.search(
        include_all=[
            SearchFilterProfile("Prop-Robotics-Isaac"),
            SearchFilterFeature("FET004_BASE_PHYSX"),
        ],
    )

    # Print the matching asset paths with their relevance scores
    for match in matches:
        print(f"{match.relevance_score:.2f}: {match.asset_path}")


if __name__ == "__main__":
    example_feature2()
