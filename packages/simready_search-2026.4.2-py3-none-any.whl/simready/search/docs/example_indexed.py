# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import asyncio

from simready.search import AssetLibrary, SearchFilterPathContains


async def example_indexed():
    # Initialize library and index the S3 directory
    s3_dir = "https://omniverse-content-production.s3-us-west-2.amazonaws.com/Assets/Isaac/6.0/Isaac/Robots/IsaacSim"
    asset_library = AssetLibrary()
    await asset_library.add_indexed_source(s3_dir, "s3")

    # Search for "cart" assets
    matches = asset_library.search(
        include_all=[
            SearchFilterPathContains("cart"),
            SearchFilterPathContains(".usd"),
        ],
        exclude_any=[
            SearchFilterPathContains("/.thumbs/"),
            SearchFilterPathContains("/dcc_source/"),
            SearchFilterPathContains("/parts/"),
        ],
    )

    # Print the matching asset paths
    for match in matches:
        print(match.asset_path)


if __name__ == "__main__":
    asyncio.run(example_indexed())
