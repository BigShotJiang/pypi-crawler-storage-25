# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import asyncio

from simready.search import AssetLibrary, SearchFilterFeature, SearchFilterPathContains, SearchFilterProfile


async def example_feature():
    # Initialize library from an S3 workspace cache
    s3_url = "https://omniverse-content-production.s3-us-west-2.amazonaws.com/Assets/Isaac/6.0/Isaac/SimReady"
    asset_library = AssetLibrary()
    await asset_library.add_s3_source(s3_url)

    # Search for multibody physx warehouse props that aren't racks or containers
    matches = asset_library.search(
        include_all=[
            SearchFilterProfile("Prop-Robotics-Isaac"),
            SearchFilterFeature("FET004_BASE_PHYSX"),
            SearchFilterPathContains("warehouse"),
        ],
        exclude_any=[SearchFilterPathContains("racks"), SearchFilterPathContains("container")],
    )

    # Print the matching asset paths
    for match in matches:
        print(match.asset_path)


if __name__ == "__main__":
    asyncio.run(example_feature())
