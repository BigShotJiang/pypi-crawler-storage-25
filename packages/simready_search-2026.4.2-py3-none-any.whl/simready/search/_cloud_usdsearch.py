# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import base64
import json
import math
import os
from typing import List, Optional

from ._logs import log
from ._network_shared import (
    AssetLibraryConnectionError,
    AssetLibraryRemoteResponseError,
    AssetLibraryTimeoutError,
    handle_network_error,
)
from ._search_filters import (
    AssetLibrarySearchFilter,
    SearchFilterArbitraryDictValue,
    SearchFilterClass,
    SearchFilterCountry,
    SearchFilterFeature,
    SearchFilterHeight,
    SearchFilterPathContains,
    SearchFilterPhrase,
    SearchFilterProfile,
    SearchFilterScenePOI,
    SearchFilterTag,
)

try:
    import requests
except ImportError:
    log(0, "Could not import requests; service endpoint will not be available.")
    requests = None

# Configuration
USERNAME = os.environ.get("USD_SEARCH_USERNAME", "$omni-api-token")
PASSWORD = os.environ.get("USD_SEARCH_PASSWORD", "<insert your Nucleus API token here>")
USER_AGENT = "simready.search"


def get_basic_auth(username: str, password: str) -> str:
    """Generate HTTP Basic Auth header value from username and password."""
    credentials = f"{username}:{password}"
    encoded = base64.b64encode(credentials.encode()).decode()
    return f"Basic {encoded}"


AUTHORIZATION = get_basic_auth(USERNAME, PASSWORD)


def call_usd_search_api(
    api_host: str,
    include_all: Optional[List[AssetLibrarySearchFilter]] = None,
    include_any: Optional[List[AssetLibrarySearchFilter]] = None,
    exclude_all: Optional[List[AssetLibrarySearchFilter]] = None,
    exclude_any: Optional[List[AssetLibrarySearchFilter]] = None,
    description: Optional[str] = None,
    request_timeout_seconds: float = 15.0,
    raise_on_network_error: bool = False,
    max_count: Optional[int] = None,
) -> dict:
    """Call the hybrid search API using requests."""
    api_host = api_host.rstrip("/")

    # Build the payload dictionary from the search filters
    payload = {
        "return_metadata": True,
        "return_images": False,
        "file_extension_include": "usd*",
    }
    if max_count is not None:
        payload["limit"] = max_count
    payload = _extend_payload_include_all(payload, include_all)
    payload = _extend_payload_include_any(payload, include_any)
    payload = _extend_payload_exclude_all(payload, exclude_all)
    payload = _extend_payload_exclude_any(payload, exclude_any)

    # TODO: Is this helpful?
    # if not payload.get("hybrid_text_query"):
    #     payload["hybrid_text_query"] = description

    log(0, f"Search query json: \n{json.dumps(payload)}")

    if requests is None:
        message = "requests is not installed. Please install it to use the service."
        handle_network_error(
            message,
            raise_on_network_error=raise_on_network_error,
            exception_cls=AssetLibraryConnectionError,
        )
        return {}

    # Send the request to the service and wait for the response
    try:
        response = requests.post(
            f"{api_host}/search_hybrid",
            headers={"Authorization": AUTHORIZATION, "User-Agent": USER_AGENT},
            json=payload,
            timeout=request_timeout_seconds,
        )
        response.raise_for_status()
        return response.json()
    except requests.exceptions.Timeout as e:
        message = f"Timed out while calling USD Search API at {api_host}/search_hybrid"
        handle_network_error(
            message,
            error=e,
            raise_on_network_error=raise_on_network_error,
            exception_cls=AssetLibraryTimeoutError,
        )
        return {}
    except requests.exceptions.ConnectionError as e:
        message = f"Connection failed while calling USD Search API at {api_host}/search_hybrid"
        handle_network_error(
            message,
            error=e,
            raise_on_network_error=raise_on_network_error,
            exception_cls=AssetLibraryConnectionError,
        )
        return {}
    except requests.exceptions.RequestException as e:
        message = f"Failed to call USD Search API at {api_host}/search_hybrid"
        handle_network_error(
            message,
            error=e,
            raise_on_network_error=raise_on_network_error,
            exception_cls=AssetLibraryRemoteResponseError,
        )
        return {}
    except ValueError as e:
        # Response body was not valid JSON.
        message = f"USD Search API returned invalid JSON from {api_host}/search_hybrid"
        handle_network_error(
            message,
            error=e,
            raise_on_network_error=raise_on_network_error,
            exception_cls=AssetLibraryRemoteResponseError,
        )
        return {}


def get_hit_relevance(hit: dict) -> float:
    """Compute a relevance score from the metadata of a raw API hit."""

    def _sigmoid(x: float, x0: float, k: float) -> float:
        """Numerically stable sigmoid shifted to x0 with steepness k."""
        return 1.0 / (1.0 + math.exp(max(-500.0, min(500.0, -k * (x - x0)))))

    def _compute_score(
        rrf_score: float,
        vec_sim: float | None = None,
        hybrid_sim: float | None = None,
    ) -> float:
        """Map raw search scores to a human-readable relevance in [0, 1].

        Args:
            rrf_score:  Reciprocal Rank Fusion score.    Typical range [0.009, 0.031].
            vec_sim:    Vector cosine similarity.        Typical range [1.04,  1.25].
            hybrid_sim: Text-match similarity or None.   Presence alone is used as a bonus.

        Returns:
            Float in [0, 1]. Higher → more likely to be a relevant result.
        """
        rrf_sig = _sigmoid(rrf_score, x0=0.017, k=700)
        vec_sig = _sigmoid(vec_sim, x0=1.115, k=100) if vec_sim is not None else 0.5
        hyb_bonus = 1.0 if hybrid_sim is not None else 0.0
        return min(1.0, 0.70 * rrf_sig + 0.50 * vec_sig + 0.10 * hyb_bonus)

    hybrid_sim = vec_sim = None
    for exp in hit.get("metadata", {}).get("explanations", []):
        st = exp.get("search_type")
        if st == "hybrid":
            hybrid_sim = exp.get("score")
        elif st == "vector":
            vec_sim = exp.get("vector_similarity") or exp.get("score")

    rrf_score = hit.get("rrf_score", 0.0)
    return _compute_score(rrf_score, vec_sim, hybrid_sim)


def _extend_payload_include_any(payload: dict, include_any: Optional[List[AssetLibrarySearchFilter]]) -> dict:
    return _extend_payload(payload, include_any, is_any=True)


def _extend_payload_include_all(payload: dict, include_all: Optional[List[AssetLibrarySearchFilter]]) -> dict:
    return _extend_payload(payload, include_all)


def _extend_payload_exclude_all(payload: dict, exclude_all: Optional[List[AssetLibrarySearchFilter]]) -> dict:
    # TODO: For exclusions, does it do exclude_all or exclude_any?
    return _extend_payload(payload, exclude_all, is_exclude=True)


def _extend_payload_exclude_any(payload: dict, exclude_any: Optional[List[AssetLibrarySearchFilter]]) -> dict:
    # TODO: For exclusions, does it do exclude_all or exclude_any?
    return _extend_payload(payload, exclude_any, is_exclude=True)


def _extend_payload(
    payload: dict,
    filter_list: Optional[List[AssetLibrarySearchFilter]],
    is_any: bool = False,
    is_exclude: bool = False,
) -> dict:
    """Translate the search filters into the right fields of the json payload of the query to the USD Search API."""
    if not filter_list:
        return payload

    if is_exclude:
        property_key = "exclude_filter_by_properties"
        path_key = "exclude_search_path"
    else:
        if is_any:
            property_key = "filter_by_properties_include_any"
        else:
            property_key = "filter_by_properties"
        path_key = "search_path"

    for search_filter in filter_list:
        if isinstance(search_filter, SearchFilterPhrase):
            payload["hybrid_text_query"] = _concat_string(payload.get("hybrid_text_query"), search_filter.phrase)
            vector_queries = payload.get("vector_queries", [])
            vector_queries.append(
                {"field_name": "siglip2-embedding.embedding", "query_type": "text", "query": search_filter.phrase}
            )
            payload["vector_queries"] = vector_queries

        elif isinstance(search_filter, SearchFilterPathContains):
            # NOTE: Order matters here!
            # SearchFilterPathContains("foo") followed by SearchFilterPathContains("baz") will match "foobarbaz"
            # SearchFilterPathContains("baz") followed by SearchFilterPathContains("foo") will not match "foobarbaz"
            payload[path_key] = _concat_string(payload.get(path_key), f"*{search_filter.substring}*", "")

        elif isinstance(search_filter, SearchFilterArbitraryDictValue):
            property_path = "__".join(search_filter.dict_path)
            property_string = f"{property_path}={search_filter.value}"
            payload[property_key] = _concat_string(payload.get(property_key), property_string)

        elif isinstance(search_filter, SearchFilterClass):
            property_string = f"simready*asset_type=~{search_filter.class_name}"
            payload[property_key] = _concat_string(payload.get(property_key), property_string)

        elif isinstance(search_filter, SearchFilterFeature):
            property_path = f"*validation__validated_features__*__{search_filter.feature}"
            property_string = f"{property_path}__passed=~True"
            payload[property_key] = _concat_string(payload.get(property_key), property_string)
            if search_filter.version:
                property_string = f"{property_path}__version={search_filter.version}"
                payload[property_key] = _concat_string(payload.get(property_key), property_string)

        elif isinstance(search_filter, SearchFilterProfile):
            property_path = "*validation__profile"
            property_string = f"{property_path}=~{search_filter.profile}"
            payload[property_key] = _concat_string(payload.get(property_key), property_string)
            if search_filter.version:
                property_string = f"{property_path}*version=~{search_filter.version}"
                payload[property_key] = _concat_string(payload.get(property_key), property_string)

        elif isinstance(search_filter, SearchFilterHeight):
            if is_exclude:
                if search_filter.max != float("inf"):
                    # They want to exclude up to this height, so search for assets taller than this height
                    payload["min_bbox_y"] = search_filter.max
                elif search_filter.min != 0.0:
                    # They want to exclude assets less than this height, so search for assets shorter than this height
                    payload["max_bbox_y"] = search_filter.min
                else:
                    # They want to exclude a range of heights, so ideally we'd include assets under and over this range,
                    # but we can't put two ranges in the same search, so we'll only search for assets under this range
                    payload["max_bbox_y"] = search_filter.min
            else:
                # Include assets in this range of heights
                payload["min_bbox_y"] = search_filter.min
                if search_filter.max != float("inf"):
                    payload["max_bbox_y"] = search_filter.max

        elif isinstance(search_filter, SearchFilterCountry):
            payload[path_key] = _concat_string(
                payload.get(path_key), f"*{search_filter.country_name}/country_assets*", ";"
            )

        elif isinstance(search_filter, SearchFilterScenePOI):
            pass  # TODO: implement

        elif isinstance(search_filter, SearchFilterTag):
            pass  # TODO: implement

    return payload


def _concat_string(existing_string: str, new_string: str, separator: str = ",") -> str:
    if existing_string:
        return f"{existing_string}{separator}{new_string}"
    return new_string
