# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import asyncio
import os
import tempfile
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, List, Optional
from urllib.parse import urlparse

from botocore.client import BaseClient
from botocore.exceptions import BotoCoreError, ClientError

from ._backend_loading import (
    ProjectConfig,
    load_configs_recursive_async,
    load_json_file_async,
    load_toml_file_async,
    load_workspace_cache_async,
)
from ._cloud_usdsearch import call_usd_search_api, get_hit_relevance
from ._logs import AssetLibrary_LogCallback, log, set_log_func
from ._network_shared import (
    AssetLibraryNetworkError,
    AssetLibraryRemoteResponseError,
    handle_network_error,
)
from ._s3_utils import (
    classify_botocore_network_error,
    create_s3_client,
    index_s3_directory_chunked,
    is_s3_not_found_error,
)
from ._search_filters import (
    AssetLibrarySearchFilter,
    SearchFilterPathContains,
    SearchFilterPhrase,
    SearchFilterRelevance,
)
from ._search_source import (
    CacheSearchSource,
    DictBackedSource,
    IndexedSearchSource,
    SearchSource,
    ServiceSearchSource,
    _is_boundary_prefix,
    _normalize_path_for_match,
)


def _has_metadata_filters(
    include_all: Optional[List[AssetLibrarySearchFilter]] = None,
    include_any: Optional[List[AssetLibrarySearchFilter]] = None,
    exclude_all: Optional[List[AssetLibrarySearchFilter]] = None,
    exclude_any: Optional[List[AssetLibrarySearchFilter]] = None,
) -> bool:
    """Return True if any of the filter lists contain a metadata-based filter."""
    for filter_list in (include_all, include_any, exclude_all, exclude_any):
        if filter_list:
            for f in filter_list:
                if not isinstance(f, (SearchFilterPathContains, SearchFilterPhrase)):
                    return True
    return False


@dataclass
class AssetData:
    """A single asset result returned by ``AssetLibrary.search``.

    Attributes:
        asset_path: Asset path or URL to the asset.
        asset_rel_path: Asset path relative to the source's logical root.
        asset_version: Version string (e.g. ``"20250101_120000"``), or
            ``None`` for unversioned assets.
        tags: Flattened list of tag strings aggregated from all tag
            categories.
        source_id: Identifier of the source that provided this result.
        relevance_score: Relevance score from a service source, or
            ``None`` for local/cache results.
    """

    asset_path: str
    asset_rel_path: str
    asset_version: str
    tags: list[str]
    source_id: str = ""
    relevance_score: Optional[float] = None


class AssetLibrary:
    """Search interface for discovering assets across multiple sources.

    Create an instance, register one or more content sources (cache, S3,
    service, or indexed directory), then call ``search`` to query across
    all of them.
    """

    def __init__(
        self,
        log_func: Optional[AssetLibrary_LogCallback] = None,
        raise_on_network_error: bool = False,
    ):
        """Initialise the library.

        Args:
            log_func: Callback ``(level, message)`` that receives all
                library log output.  Levels: 0 = info, 1 = warning,
                2 = error.  When ``None``, messages print to stdout.
            raise_on_network_error: When ``True``, network failures raise
                an ``AssetLibraryNetworkError`` subclass instead of being
                logged and skipped.
        """
        set_log_func(log_func)

        self._sources: List[SearchSource] = []
        self._sources_lock = threading.RLock()
        self._raise_on_network_error = raise_on_network_error
        self._network_timeout_seconds = 15.0
        self._next_index_config_priority = 0

    # -------------------------------------------------------------------------
    # Source management
    # -------------------------------------------------------------------------

    async def add_cache_source(
        self,
        project_config_toml_path: str,
        file_reader: Optional[Callable[[str], str]] = None,
        load_completed_callback: Optional[Callable[[], None]] = None,
        _cache_content_source: Optional[str] = None,
        _cache_root_url: Optional[str] = None,
    ) -> CacheSearchSource:
        """Load a workspace cache and register it as a searchable source.

        Args:
            project_config_toml_path: Path to the ``project_config.toml``
                file that describes the cache layout.
            file_reader: Optional function used to read files to strings.
                Useful if the cache is stored in a non-local filesystem.
            load_completed_callback: Called once loading finishes.

        Returns:
            The newly created ``CacheSearchSource``.
        """
        log(0, f"Adding cache source: {project_config_toml_path}")
        source = CacheSearchSource(source_id="")
        await self._load_cache_into_source(
            source,
            project_config_toml_path,
            file_reader=file_reader,
            _cache_content_source=_cache_content_source,
            _cache_root_url=_cache_root_url,
            load_completed_callback=load_completed_callback,
        )
        self._register_source(source)
        return source

    def add_service_source(
        self,
        endpoint_url: str,
    ) -> ServiceSearchSource:
        """Register a remote USD Search API endpoint as a searchable source.

        Args:
            endpoint_url: URL of the search service endpoint.

        Returns:
            The newly created ``ServiceSearchSource``.
        """
        log(0, f"Adding service source: {endpoint_url}")
        source = ServiceSearchSource(
            source_id=endpoint_url,
            endpoint_url=endpoint_url,
        )
        self._register_source(source)
        return source

    async def add_s3_source(
        self,
        bucket_url: str,
        raise_on_network_error: Optional[bool] = None,
    ) -> CacheSearchSource:
        """Load a workspace cache from S3 and register it as a searchable source.

        The bucket must contain a ``project_config.toml`` and ``workspace_cache.json`` file.

        Args:
            bucket_url: S3 URL in the form
                ``https://bucket.s3.<region>.amazonaws.com/path/to/simready/root``.
            raise_on_network_error: Override the instance-level
                ``raise_on_network_error`` setting for this call.

        Returns:
            The newly created ``CacheSearchSource``.
        """
        if raise_on_network_error is None:
            raise_on_network_error = self._raise_on_network_error

        try:
            s3_client, bucket, simready_project_root, normalized_bucket_url = create_s3_client(bucket_url)
        except ValueError as e:
            handle_network_error(
                f"Could not parse S3 source URL '{bucket_url}'",
                error=e,
                raise_on_network_error=raise_on_network_error,
                exception_cls=AssetLibraryNetworkError,
            )
            source = CacheSearchSource(source_id=bucket_url)
            self._register_source(source)
            return source
        except (ClientError, BotoCoreError) as e:
            handle_network_error(
                f"Could not resolve S3 bucket region for '{bucket_url}'",
                error=e,
                raise_on_network_error=raise_on_network_error,
                exception_cls=classify_botocore_network_error(e),
            )
            source = CacheSearchSource(source_id=bucket_url)
            self._register_source(source)
            return source

        return await self._add_s3_source_with_client(
            s3_client,
            bucket,
            simready_project_root,
            _cache_content_source="s3",
            _cache_root_url=normalized_bucket_url,
            raise_on_network_error=raise_on_network_error,
        )

    async def _add_s3_source_with_client(
        self,
        s3_client: BaseClient,
        bucket: str,
        simready_project_root: str,
        _cache_content_source: Optional[str] = None,
        _cache_root_url: Optional[str] = None,
        raise_on_network_error: bool = False,
    ) -> CacheSearchSource:
        fallback_source = CacheSearchSource(source_id=_cache_root_url or "")

        def _register_fallback_source() -> CacheSearchSource:
            # Keep behavior consistent with invalid local cache loads:
            # return a registered empty cache source rather than silently dropping the add.
            self._register_source(fallback_source)
            return fallback_source

        def _prepare_temp_directory(path: Path) -> bool:
            try:
                if path.exists() and path.is_file():
                    path.unlink()
                path.mkdir(parents=True, exist_ok=True)
                return True
            except OSError as e:
                handle_network_error(
                    f"Failed to prepare local temp path {path} for S3 download staging",
                    error=e,
                    raise_on_network_error=raise_on_network_error,
                    exception_cls=AssetLibraryRemoteResponseError,
                )
                return False

        def _download_s3_file_with_handling(key: str, output_path: Path) -> bool:
            """Download one S3 object with consistent logging/raise behavior."""
            try:
                output_path.parent.mkdir(parents=True, exist_ok=True)
                if output_path.exists():
                    output_path.unlink()
            except OSError as e:
                handle_network_error(
                    f"Failed to prepare local temp path {output_path} for S3 download staging",
                    error=e,
                    raise_on_network_error=raise_on_network_error,
                    exception_cls=AssetLibraryRemoteResponseError,
                )
                return False

            try:
                s3_client.download_file(bucket, key, str(output_path))
                return True
            except (ClientError, BotoCoreError) as e:
                message = f"Failed to download S3 file s3://{bucket}/{key}"
                if is_s3_not_found_error(e):
                    message = f"Missing expected S3 file s3://{bucket}/{key}"
                handle_network_error(
                    message,
                    error=e,
                    raise_on_network_error=raise_on_network_error,
                    exception_cls=AssetLibraryRemoteResponseError,
                )
                return False

        log(0, f"Fetching cache data from S3: {bucket}: {simready_project_root}")
        project_root_prefix = simready_project_root.strip("/")
        project_config_key = (
            f"{project_root_prefix}/project_config.toml" if project_root_prefix else "project_config.toml"
        )
        workspace_cache_key = (
            f"{project_root_prefix}/workspace_cache.json" if project_root_prefix else "workspace_cache.json"
        )
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_dir_path = Path(temp_dir)
            entry_dir = temp_dir_path / "entry"
            if not _prepare_temp_directory(entry_dir):
                return _register_fallback_source()
            project_config_path = entry_dir / "project_config.toml"
            if not _download_s3_file_with_handling(
                key=project_config_key,
                output_path=project_config_path,
            ):
                return _register_fallback_source()
            toml_config = await load_toml_file_async(str(project_config_path))
            content_root_name = toml_config.get("content_root", {}).get("name", "")
            if not content_root_name or content_root_name == ".":
                content_root_name = "content"
            content_root_dir = temp_dir_path / content_root_name
            if not _prepare_temp_directory(content_root_dir):
                return _register_fallback_source()
            workspace_cache_path = content_root_dir / "workspace_cache.json"
            if not _download_s3_file_with_handling(
                key=workspace_cache_key,
                output_path=workspace_cache_path,
            ):
                return _register_fallback_source()
            return await self.add_cache_source(
                str(project_config_path),
                _cache_content_source=_cache_content_source,
                _cache_root_url=_cache_root_url,
            )

    async def add_indexed_source(self, directory_path: str, directory_type: str) -> IndexedSearchSource:
        """Build a file-listing index of a directory and register it.

        Indexed sources contain no asset metadata, so metadata-based
        filters will produce unexpected results against them.

        Args:
            directory_path: Local filesystem path or S3 URL to index.
            directory_type: ``"local"`` for a local path, ``"s3"`` for
                an S3 URL.

        Returns:
            The newly created ``IndexedSearchSource``.
        """
        normalized_directory_path = _normalize_path_for_match(directory_path)
        source = IndexedSearchSource(
            source_id=directory_path,
            content_roots=[normalized_directory_path] if normalized_directory_path else [],
        )
        source._cancel_event.clear()
        source._loading_task = asyncio.current_task()
        # Register early so chunked S3 entries become searchable as they stream in.
        self._register_source(source)

        start_time = time.time()
        log(0, f"Indexing directory {directory_path}...")
        try:
            if directory_type == "local":
                new_entries = self._index_local_directory(directory_path)
                if not source._cancel_event.is_set():
                    source.merge_entries(new_entries)
                indexed_file_count = len(new_entries.keys())
            elif directory_type == "s3":
                event_loop = asyncio.get_running_loop()

                def _commit_chunk(entries_chunk: dict):
                    if source._cancel_event.is_set():
                        return

                    def _apply_chunk():
                        if source._cancel_event.is_set():
                            return
                        source.merge_entries(entries_chunk)

                    event_loop.call_soon_threadsafe(_apply_chunk)

                indexed_file_count = await asyncio.to_thread(
                    index_s3_directory_chunked,
                    directory_path,
                    self._next_index_config_priority,
                    _commit_chunk,
                    self._network_timeout_seconds,
                    self._raise_on_network_error,
                    cancel_event=source._cancel_event,
                )
            else:
                log(2, f"Unknown directory_type for indexing: {directory_type}")
                return source

            self._next_index_config_priority += 1
            log(0, f"Found {indexed_file_count} files in {(time.time() - start_time):.3f} seconds.")
            return source
        except asyncio.CancelledError:
            source._cancel_event.set()
            log(0, f"Indexing cancelled for source '{source.source_id}'")
            raise
        finally:
            source._loading_task = None

    def remove_source(self, source_id: str) -> bool:
        """Remove a previously registered source.

        Args:
            source_id: Identifier of the source to remove.

        Returns:
            ``True`` if the source was found and removed, ``False``
            otherwise.
        """
        with self._sources_lock:
            for i, source in enumerate(self._sources):
                if source.source_id == source_id:
                    self._sources.pop(i)
                    source.cancel_loading()
                    log(0, f"Removed source '{source_id}'")
                    return True
        log(1, f"Source not found for removal: '{source_id}'")
        return False

    def clear_sources(self) -> None:
        """Remove and cancel loading for all registered sources."""
        with self._sources_lock:
            for source in self._sources:
                source.cancel_loading()
            self._sources.clear()
        self._next_index_config_priority = 0
        log(0, "All sources cleared")

    def cancel_loading(self) -> None:
        """Cancel in-progress loading or indexing for all sources.

        Sources remain registered but any background work is stopped.
        """
        with self._sources_lock:
            sources = list(self._sources)
        for source in sources:
            source.cancel_loading()
        log(0, "Cancelled loading/indexing for all sources")

    def _register_source(self, source: SearchSource) -> None:
        with self._sources_lock:
            self._sources.append(source)

    def is_loading(self) -> bool:
        """Return ``True`` if any source is still loading or indexing."""
        with self._sources_lock:
            return any(s.is_loading() for s in self._sources)

    def entry_count(self) -> int:
        """Return the total number of cached asset entries across all dict-backed sources."""
        with self._sources_lock:
            return sum(s.entry_count() for s in self._sources if isinstance(s, DictBackedSource))

    async def add_cache_entries_from_json(self, json_path: str, file_reader: Optional[Callable[[str], str]] = None):
        """Load asset entries from a JSON file and register them as a cache source.

        Args:
            json_path: Path or URL to the JSON file containing asset
                entries.
            file_reader: Optional function used to read file contents
                instead of the default filesystem reader.
        """
        new_entries = await load_json_file_async(json_path, file_reader)
        if not new_entries:
            log(2, f"Failed to load json file: {json_path}")
            return

        parsed_url = urlparse(json_path)
        json_dir = os.path.dirname(parsed_url.path)

        for asset_path, entries in new_entries.items():
            for asset_version, asset_data in entries.items():
                normalized_asset_version = None if asset_version in (None, "null", "None", "") else asset_version
                asset_data["asset_partial_path"] = asset_path
                asset_data["config_priority"] = 0
                asset_data["content_root_path"] = json_dir
                asset_data["asset_version"] = normalized_asset_version
                if normalized_asset_version is not None:
                    asset_source = "wrapp"
                else:
                    asset_source = "local"
                asset_data["content_source"] = asset_source

        # Cache Country
        for asset_path, entries in new_entries.items():
            for asset_version, asset_data in entries.items():
                if "country" not in asset_data:
                    pathparts = asset_path.split("/")
                    try:
                        country_name = pathparts[pathparts.index("country_assets") - 1]
                        asset_data["country"] = country_name
                    except (ValueError, IndexError):
                        # ValueError means "country_assets" isn't in the path
                        # IndexError means "country_assets" was right at the front of the path
                        asset_data["country"] = ""

        source = CacheSearchSource(
            source_id=json_path,
            content_roots=[_normalize_path_for_match(json_dir)] if json_dir else [],
        )
        source.merge_entries(new_entries)
        self._register_source(source)
        log(0, f"Added {len(new_entries.keys())} entries to cache from {json_path}")

    # -------------------------------------------------------------------------
    # Search
    # -------------------------------------------------------------------------

    def search(
        self,
        include_all: Optional[List[AssetLibrarySearchFilter]] = None,
        include_any: Optional[List[AssetLibrarySearchFilter]] = None,
        exclude_all: Optional[List[AssetLibrarySearchFilter]] = None,
        exclude_any: Optional[List[AssetLibrarySearchFilter]] = None,
        remove_duplicates: bool = True,
        base_paths: Optional[List[str]] = None,
        max_count: Optional[int] = None,
    ) -> List[AssetData]:
        """Search all registered sources and return matching assets.

        An asset is included if it passes ``include_all`` **or**
        ``include_any``, then excluded if it matches ``exclude_all`` or
        ``exclude_any``.

        Args:
            include_all: Every filter in this list must match for an
                asset to be included.
            include_any: At least one filter in this list must match for
                an asset to be included.
            exclude_all: If every filter in this list matches, the asset
                is excluded.
            exclude_any: If any filter in this list matches, the asset
                is excluded.
            remove_duplicates: When ``True``, only the highest-priority
                version of each asset path is returned.
            base_paths: Restrict results to assets whose absolute path
                falls under one of these prefixes.
            max_count: Maximum number of assets to return. Must be a
                positive integer when provided.

        Returns:
            Matching assets, or an empty list if ``max_count`` is
            invalid.
        """
        if max_count is not None and (not isinstance(max_count, int) or max_count <= 0):
            log(2, f"max_count must be a positive integer, got {max_count!r}; returning no results.")
            return []

        log(0, "Searching library with filters:")
        log(0, f"  {include_all=}")
        log(0, f"  {include_any=}")
        log(0, f"  {exclude_all=}")
        log(0, f"  {exclude_any=}")
        if base_paths:
            log(0, f"  {base_paths=}")
        if max_count is not None:
            log(0, f"  {max_count=}")

        # run the search
        start_time = time.time()
        matching_assets: Dict[str, List[dict]] = {}
        num_total_hits = 0
        num_filtered_by_base_paths = 0
        for source in self._matching_sources(base_paths):
            if isinstance(source, IndexedSearchSource):
                if _has_metadata_filters(include_all, include_any, exclude_all, exclude_any):
                    log(
                        1,
                        f"Indexed source '{source.source_id}' has no metadata"
                        " -- metadata filters may produce unexpected results",
                    )
                results = self._search_dict_source(
                    source, include_all, include_any, exclude_all, exclude_any, max_count
                )
            elif isinstance(source, DictBackedSource):
                results = self._search_dict_source(
                    source, include_all, include_any, exclude_all, exclude_any, max_count
                )
            elif isinstance(source, ServiceSearchSource):
                results = self._search_service_source(
                    source, include_all, include_any, exclude_all, exclude_any, max_count
                )
            else:
                continue
            pre_filter_count = sum(len(v) for v in results.values())
            num_total_hits += pre_filter_count
            if base_paths:
                results = self._filter_results_by_base_paths(results, base_paths)
                post_filter_count = sum(len(v) for v in results.values())
                num_filtered_by_base_paths += pre_filter_count - post_filter_count
            self._merge_asset_results(matching_assets, results)

        # build output
        pre_duplicate_removal_count = sum(len(v) for v in matching_assets.values())
        matching_asset_data_list = self._build_asset_data_list(matching_assets, remove_duplicates)
        num_duplicates_removed = pre_duplicate_removal_count - len(matching_asset_data_list)

        if max_count is not None:
            matching_asset_data_list = matching_asset_data_list[:max_count]

        log(
            0,
            self._make_summary_message(
                num_total_hits, num_filtered_by_base_paths, num_duplicates_removed, time.time() - start_time
            ),
        )
        return matching_asset_data_list

    def get_all_values(
        self,
        search_filter: AssetLibrarySearchFilter,
        base_paths: Optional[List[str]] = None,
    ) -> set:
        """Return all distinct values for a given filter across cached assets.

        Useful for populating UI dropdowns or auto-complete.  Only
        operates on dict-backed (cache/indexed) sources.

        Args:
            search_filter: A filter instance whose value-extraction
                logic determines what values are collected.
            base_paths: Restrict to assets whose path falls under one
                of these prefixes.

        Returns:
            Set of all distinct matched values.
        """
        log(0, f"Searching library for all possible values of filter: {search_filter}")
        start_time = time.time()
        all_values = set()
        for source in self._matching_sources(base_paths):
            if not isinstance(source, DictBackedSource):
                log(1, f"Skipping source '{source.source_id}' -- only cache sources support get_all_values")
                continue
            for _asset_path, asset_versions in source.snapshot_items():
                for _, asset_data in asset_versions.items():
                    all_values.update(search_filter.get_all_values(asset_data))
        log(0, f"Search returned {len(all_values)} results in {(time.time() - start_time):.3f} seconds.")
        return all_values

    # -------------------------------------------------------------------------
    # Search internals
    # -------------------------------------------------------------------------

    def _matching_sources(self, base_paths: Optional[List[str]] = None) -> List[SearchSource]:
        with self._sources_lock:
            sources = list(self._sources)
        matching_sources = []
        if not base_paths:
            matching_sources = sources
        else:
            normalized_base_paths = [_normalize_path_for_match(bp) for bp in base_paths]
            normalized_base_paths = [bp for bp in normalized_base_paths if bp]
            matching_sources = [s for s in sources if s.matches_query_paths(normalized_base_paths)]
        for source in matching_sources:
            log(0, f"Active source: {source.source_id}")
        return matching_sources

    def _search_dict_source(
        self,
        source: DictBackedSource,
        include_all: Optional[List[AssetLibrarySearchFilter]] = None,
        include_any: Optional[List[AssetLibrarySearchFilter]] = None,
        exclude_all: Optional[List[AssetLibrarySearchFilter]] = None,
        exclude_any: Optional[List[AssetLibrarySearchFilter]] = None,
        max_count: Optional[int] = None,
    ) -> Dict[str, List[dict]]:
        matching_assets: Dict[str, List[dict]] = {}
        for asset_path, entries in source.snapshot_items():
            if max_count is not None and len(matching_assets) >= max_count:
                break
            for _, asset_data in entries.items():
                include_all_passed = True
                if include_all:
                    for search_filter in include_all:
                        if not search_filter.test(asset_path, asset_data):
                            include_all_passed = False
                            break
                else:
                    include_all_passed = False

                include_any_passed = False
                if include_any:
                    for search_filter in include_any:
                        if search_filter.test(asset_path, asset_data):
                            include_any_passed = True
                            break
                else:
                    include_any_passed = False

                if not (include_all_passed or include_any_passed):
                    # this asset is not included. no need to check the exclude filters
                    continue

                exclude_all_passed = True
                if exclude_all:
                    for search_filter in exclude_all:
                        if not search_filter.test(asset_path, asset_data):
                            exclude_all_passed = False
                            break
                else:
                    exclude_all_passed = False
                if exclude_all_passed:
                    continue

                exclude_any_passed = False
                if exclude_any:
                    for search_filter in exclude_any:
                        if search_filter.test(asset_path, asset_data):
                            exclude_any_passed = True
                            break
                else:
                    exclude_any_passed = False
                if exclude_any_passed:
                    continue

                # if we get here, the asset has been included AND NOT excluded.
                self._add_asset_match(matching_assets, asset_data)
        return matching_assets

    def _search_service_source(
        self,
        source: ServiceSearchSource,
        include_all: Optional[List[AssetLibrarySearchFilter]] = None,
        include_any: Optional[List[AssetLibrarySearchFilter]] = None,
        exclude_all: Optional[List[AssetLibrarySearchFilter]] = None,
        exclude_any: Optional[List[AssetLibrarySearchFilter]] = None,
        max_count: Optional[int] = None,
    ) -> Dict[str, List[dict]]:
        response_json = call_usd_search_api(
            source.endpoint_url,
            include_all,
            include_any,
            exclude_all,
            exclude_any,
            request_timeout_seconds=self._network_timeout_seconds,
            raise_on_network_error=self._raise_on_network_error,
            max_count=max_count,
        )

        matching_assets: Dict[str, List[dict]] = {}
        for hit in response_json.get("hits", []):
            asset_path = hit.get("source", {}).get("base_key")
            partial_path = hit.get("source", {}).get("path")
            if not asset_path or not partial_path:
                log(1, f"Skipping search hit because couldn't find asset path in search result: {hit.keys()}")
                continue

            new_asset_data = {
                "asset_partial_path": partial_path,
                "config_priority": hit.get("score", 0),
                "content_root_path": asset_path.removesuffix(partial_path),
                "content_source": "service",
                "asset_version": None,
                "tags": {},
                "source_id": source.source_id,
                "relevance_score": get_hit_relevance(hit),
            }
            self._add_asset_match(matching_assets, new_asset_data)

        include_relevance = [
            f
            for filters in (include_all, include_any)
            if filters
            for f in filters
            if isinstance(f, SearchFilterRelevance)
        ]
        exclude_relevance = [
            f
            for filters in (exclude_all, exclude_any)
            if filters
            for f in filters
            if isinstance(f, SearchFilterRelevance)
        ]
        if include_relevance or exclude_relevance:
            for asset_path in list(matching_assets):
                matching_assets[asset_path] = [
                    ad
                    for ad in matching_assets[asset_path]
                    if all(rf.test(asset_path, ad) for rf in include_relevance)
                    and not any(rf.test(asset_path, ad) for rf in exclude_relevance)
                ]
                if not matching_assets[asset_path]:
                    del matching_assets[asset_path]

        return matching_assets

    def _filter_results_by_base_paths(
        self, results: Dict[str, List[dict]], base_paths: List[str]
    ) -> Dict[str, List[dict]]:
        normalized_base_paths = [_normalize_path_for_match(bp) for bp in base_paths]
        normalized_base_paths = [bp for bp in normalized_base_paths if bp]
        if not normalized_base_paths:
            return {}

        filtered: Dict[str, List[dict]] = {}
        for partial_path, asset_datas in results.items():
            kept = [
                ad
                for ad in asset_datas
                if any(_is_boundary_prefix(self._abs_path_from_asset_dict(ad), bp) for bp in normalized_base_paths)
            ]
            if kept:
                filtered[partial_path] = kept
        return filtered

    def _make_summary_message(
        self, num_total_hits: int, num_filtered_by_base_paths: int, num_duplicates_removed: int, time_taken: float
    ) -> str:
        summary_message = f"Search returned {num_total_hits} results in {time_taken:.3f} seconds"
        if num_filtered_by_base_paths > 0:
            were = "was" if num_filtered_by_base_paths == 1 else "were"
            summary_message += f", but {num_filtered_by_base_paths} {were} outside the base_paths"
        if num_duplicates_removed > 0:
            if num_filtered_by_base_paths > 0:
                summary_message += " and"
            else:
                summary_message += ", but"
            were = "was" if num_duplicates_removed == 1 else "were"
            summary_message += f" {num_duplicates_removed} {were} removed as duplicates"
        return summary_message + "."

    # -------------------------------------------------------------------------
    # Cache loading internals
    # -------------------------------------------------------------------------

    async def _load_cache_into_source(
        self,
        source: CacheSearchSource,
        project_config_toml_path: str,
        file_reader: Optional[Callable[[str], str]] = None,
        load_completed_callback: Optional[Callable[[], None]] = None,
        _cache_content_source: Optional[str] = None,
        _cache_root_url: Optional[str] = None,
    ):
        source._cancel_event.clear()
        _cache_root_url = _cache_root_url.rstrip("/") if _cache_root_url else None
        start_time = time.time()

        configs: List[ProjectConfig] = await load_configs_recursive_async(
            project_config_toml_path.replace("\\", "/"), file_reader
        )
        if not configs:
            log(2, f"Failed to load project config: {project_config_toml_path}")
            return
        log(0, f"Loaded {len(configs)} project configs:")
        for config in configs:
            log(0, f"  {config}")

        cache_dict = await load_workspace_cache_async(project_config_toml_path.replace("\\", "/"), file_reader)
        log(0, f"Cache contains {len(cache_dict.keys())} entries.")

        # We expect a workspace_cache.json to be project_root-relative: every top-level key starts with
        # a content_root_name (e.g. "cache_content/vehicles/cart_primary.usda"). That's what our reference
        # cache generator emits, and what users authoring caches should produce. The block below also
        # tolerates content-root-relative caches (no content_root_name prefix) as an undocumented
        # compatibility shim for outlier caches we've encountered in the wild -- not as a supported
        # format.

        # Identify the "owning" config -- the one whose content_root contains this workspace_cache.json
        # file. This is the root project_config.toml's content_root, used as the fallback when entries
        # are content-root-relative.
        root_config_dict = await load_toml_file_async(project_config_toml_path.replace("\\", "/"), file_reader)
        root_content_root_name = root_config_dict.get("content_root", {}).get("name", "")
        owning_config = next(
            (c for c in configs if c.content_root_name == root_content_root_name),
            configs[0],
        )

        # Per-cache format detection: if not a single entry's top-level key starts with any known
        # content_root_name, the whole cache is treated as content-root-relative to the owning config.
        # When at least one entry matches, stay in the expected per-entry project_root-relative mode --
        # entries that don't match will be dropped, so typos in otherwise-correct caches are flagged.
        # Note: a cache that's content-root-relative cannot disambiguate between sibling subconfigs;
        # all entries collapse onto the owning (root) config in that case.
        def _matches_any_content_root(asset_path: str) -> bool:
            for c in configs:
                if not c.content_root_name:
                    continue
                if asset_path == c.content_root_name or asset_path.startswith(c.content_root_name + "/"):
                    return True
            return False

        cache_is_content_root_relative = bool(cache_dict) and not any(_matches_any_content_root(p) for p in cache_dict)
        if cache_is_content_root_relative:
            log(
                0,
                "Cache entries do not start with any known content_root_name;"
                f" treating cache as content-root-relative to '{owning_config.content_root_name}'.",
            )
        else:
            log(0, "Cache entries are project-root-relative.")

        content_root_paths: set[str] = set()
        keys_with_no_associated_config: set[str] = set()
        for asset_path, entries in cache_dict.items():
            for asset_version, asset_data in entries.items():
                normalized_asset_version = None if asset_version in (None, "null", "None", "") else asset_version
                if cache_is_content_root_relative:
                    matched_config = owning_config
                    matched_priority = configs.index(owning_config)
                    matched_partial_path = asset_path
                else:
                    matched_config = None
                    matched_priority = 0
                    matched_partial_path = ""
                    for priority, config in enumerate(configs):
                        if asset_path.startswith(config.content_root_name):
                            matched_config = config
                            matched_priority = priority
                            matched_partial_path = asset_path[len(config.content_root_name) + 1 :]
                            break
                if matched_config is not None:
                    local_content_root_path = _normalize_path_for_match(
                        matched_config.project_root_abs_path + "/" + matched_config.content_root_name
                    )
                    asset_data["asset_partial_path"] = matched_partial_path
                    asset_data["config_priority"] = matched_priority
                    asset_data["content_root_path"] = local_content_root_path
                    asset_data["content_root_name"] = matched_config.content_root_name
                    asset_data["asset_version"] = normalized_asset_version
                    if _cache_content_source == "s3":
                        asset_data["content_source"] = "s3"
                        if _cache_root_url:
                            asset_data["content_root_path"] = _cache_root_url
                    elif normalized_asset_version is not None:
                        asset_data["content_source"] = "wrapp"
                    else:
                        asset_data["content_source"] = "local"
                    content_root_paths.add(asset_data["content_root_path"])
                if "asset_partial_path" not in asset_data:
                    keys_with_no_associated_config.add(asset_path)
        for key in keys_with_no_associated_config:
            log(1, f"Removing asset which does not match any known content root: {key}")
            del cache_dict[key]

        for asset_path, entries in cache_dict.items():
            for asset_version, asset_data in entries.items():
                if "country" not in asset_data:
                    pathparts = asset_path.split("/")
                    try:
                        country_name = pathparts[pathparts.index("country_assets") - 1]
                        asset_data["country"] = country_name
                    except (ValueError, IndexError):
                        asset_data["country"] = ""

        source.content_roots = sorted(
            normalized for path in content_root_paths if (normalized := _normalize_path_for_match(path))
        )
        if not source.source_id and source.content_roots:
            source.source_id = source.content_roots[0]
        source.merge_entries(cache_dict)

        log(0, f"Source '{source.source_id}' initialized in {(time.time() - start_time):.3f} seconds.")

        if callable(load_completed_callback):
            load_completed_callback()

    # -------------------------------------------------------------------------
    # Local directory indexing
    # -------------------------------------------------------------------------

    def _index_local_directory(self, directory_path: str) -> dict:
        if not os.path.isdir(directory_path):
            log(2, f"Directory does not exist: {directory_path}")
            return {}

        root_path = os.path.abspath(directory_path).replace("\\", "/")
        new_entries = {}
        visited_dirs = set()
        for root, dirnames, filenames in os.walk(directory_path, topdown=True, followlinks=True):
            root_realpath = os.path.realpath(root)
            if root_realpath in visited_dirs:
                dirnames[:] = []
                continue
            visited_dirs.add(root_realpath)

            next_dirnames = []
            for dirname in dirnames:
                full_dir = os.path.join(root, dirname)
                full_real = os.path.realpath(full_dir)
                if full_real in visited_dirs:
                    continue
                next_dirnames.append(dirname)
            dirnames[:] = next_dirnames

            for filename in filenames:
                full_path = os.path.abspath(os.path.join(root, filename)).replace("\\", "/")
                partial_path = os.path.relpath(full_path, root_path).replace("\\", "/")
                asset_data = {
                    "asset_partial_path": partial_path,
                    "config_priority": self._next_index_config_priority,
                    "content_root_path": root_path,
                    "asset_version": None,
                    "content_source": "local",
                    "tags": {},
                }
                new_entries[full_path] = {None: asset_data}
        return new_entries

    # -------------------------------------------------------------------------
    # Asset data helpers
    # -------------------------------------------------------------------------

    def _add_asset_match(self, asset_matches: dict[str, List[dict]], new_asset_data: dict):
        partial_path = new_asset_data["asset_partial_path"]
        if partial_path not in asset_matches:
            asset_matches[partial_path] = []
        asset_matches[partial_path].append(new_asset_data)

    def _merge_asset_results(
        self, target_matches: Dict[str, List[dict]], incoming_matches: Dict[str, List[dict]]
    ) -> None:
        for partial_path, incoming_asset_datas in incoming_matches.items():
            if partial_path not in target_matches:
                target_matches[partial_path] = list(incoming_asset_datas)
            else:
                target_matches[partial_path].extend(incoming_asset_datas)

    def _build_asset_data_list(self, asset_matches: dict[str, List[dict]], remove_duplicates: bool) -> List[AssetData]:
        asset_data_list = []
        for _partial_path, unsorted_asset_datas in asset_matches.items():
            # Sort by config_priority (ascending), then by asset_version (descending, i.e., most recent first)
            def version_key(version_str):
                # version_str is in format "YYYYMMDD_HHMMSS"
                # Remove underscore and convert to int for comparison
                if version_str is None or version_str == "null":
                    return 0
                else:
                    return int(version_str.replace(".", ""))

            sorted_datas = sorted(
                unsorted_asset_datas, key=lambda d: (d.get("config_priority", 0), -version_key(d.get("asset_version")))
            )
            if remove_duplicates:
                asset_data_list.append(
                    AssetData(
                        self._abs_path_from_asset_dict(sorted_datas[0]),
                        self._rel_path_from_asset_dict(sorted_datas[0]),
                        self._version_from_asset_dict(sorted_datas[0]),
                        self._get_tags_from_asset_dict(sorted_datas[0]),
                        self._source_id_from_asset_dict(sorted_datas[0]),
                        self._relevance_score_from_asset_dict(sorted_datas[0]),
                    )
                )
            else:
                asset_data_list.extend(
                    AssetData(
                        self._abs_path_from_asset_dict(d),
                        self._rel_path_from_asset_dict(d),
                        self._version_from_asset_dict(d),
                        self._get_tags_from_asset_dict(d),
                        self._source_id_from_asset_dict(d),
                        self._relevance_score_from_asset_dict(d),
                    )
                    for d in sorted_datas
                )

        # Sort by relevance score (descending); None treated as 1.0 so non-service results sort first
        asset_data_list.sort(key=lambda ad: ad.relevance_score if ad.relevance_score is not None else 1.0, reverse=True)

        return asset_data_list

    def _source_id_from_asset_dict(self, asset: dict) -> str:
        return asset.get("source_id", "")

    def _relevance_score_from_asset_dict(self, asset: dict) -> Optional[float]:
        return asset.get("relevance_score")

    def _get_tags_from_asset_dict(self, asset_dict: dict) -> list[str]:
        tag_categories = ["capabilities", "class", "label_tags", "manifest", "meta"]
        tags = set()
        for category in tag_categories:
            tags.update(asset_dict.get("tags", {}).get(category, []))
        return list(tags)

    def _version_from_asset_dict(self, asset: dict) -> str:
        return asset["asset_version"]

    def _abs_path_from_asset_dict(self, asset: dict) -> str:
        if asset["content_source"] == "wrapp":
            return asset["asset_partial_path"]
        elif asset["content_source"] == "s3":
            root = asset["content_root_path"].rstrip("/")
            partial = asset["asset_partial_path"].lstrip("/")
            return f"{root}/{partial}" if partial else root
        elif asset["content_source"] == "service":
            return asset["content_root_path"] + asset["asset_partial_path"]
        else:
            return asset["content_root_path"] + "/" + asset["asset_partial_path"]

    def _rel_path_from_asset_dict(self, asset: dict) -> str:
        if asset.get("content_root_name", ""):
            # Manifest assets have a content_root_name which needs to be added back to the partial path
            content_root_name = asset["content_root_name"]
            return content_root_name + "/" + asset["asset_partial_path"]
        return asset["asset_partial_path"]
