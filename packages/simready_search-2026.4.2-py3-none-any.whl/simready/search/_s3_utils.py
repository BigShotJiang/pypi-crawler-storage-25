# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import threading
import time
from typing import Callable, Optional
from urllib.parse import urlparse

import boto3
from botocore import UNSIGNED
from botocore.client import BaseClient
from botocore.config import Config
from botocore.exceptions import (
    BotoCoreError,
    ClientError,
    ConnectionClosedError,
    ConnectTimeoutError,
    EndpointConnectionError,
    ReadTimeoutError,
)

from ._logs import log
from ._network_shared import (
    AssetLibraryConnectionError,
    AssetLibraryNetworkError,
    AssetLibraryRemoteResponseError,
    AssetLibraryTimeoutError,
    handle_network_error,
)


def parse_s3_bucket_url(url: str) -> tuple[str, Optional[str], str, str]:
    """Parse AWS virtual-hosted bucket URL into (bucket, region_name, endpoint_url, prefix)."""
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise ValueError(f"Expected S3 URL with http/https scheme, got: {url}")

    netloc = parsed.netloc
    if not netloc.endswith(".amazonaws.com"):
        raise ValueError(f"Expected AWS host ending with .amazonaws.com, got: {url}")

    bucket = ""
    region_name = None
    endpoint_url = ""

    if ".s3-" in netloc:
        bucket, region_host = netloc.split(".s3-", 1)
        region_name = region_host.split(".amazonaws.com", 1)[0]
        endpoint_url = f"{parsed.scheme}://s3-{region_name}.amazonaws.com"
    elif ".s3." in netloc:
        bucket, region_host = netloc.split(".s3.", 1)
        if region_host.startswith("amazonaws.com"):
            endpoint_url = f"{parsed.scheme}://s3.amazonaws.com"
        else:
            region_name = region_host.split(".amazonaws.com", 1)[0]
            endpoint_url = f"{parsed.scheme}://s3.{region_name}.amazonaws.com"
    else:
        raise ValueError(
            "Expected AWS virtual-hosted URL like "
            "https://<bucket>.s3-<region>.amazonaws.com/<prefix>, "
            "https://<bucket>.s3.<region>.amazonaws.com/<prefix>, or "
            "https://<bucket>.s3.amazonaws.com/<prefix>"
        )

    if not bucket:
        raise ValueError(f"Could not parse bucket from URL: {url}")
    prefix = parsed.path.strip("/")
    return bucket, region_name, endpoint_url, prefix


def canonicalize_aws_s3_netloc(netloc: str) -> str:
    """Reduce AWS virtual-hosted S3 hosts to a canonical region-less form.

    Hosts that ``parse_s3_bucket_url`` recognizes as virtual-hosted S3 URLs
    (``<bucket>.s3-<region>.amazonaws.com``, ``<bucket>.s3.<region>.amazonaws.com``,
    ``<bucket>.s3.amazonaws.com``) are rewritten as
    ``<bucket>.s3.amazonaws.com`` so that all three forms compare equal during
    path matching. Other hosts are returned lower-cased but otherwise
    unchanged.

    Hostnames are case-insensitive in DNS, so lowercasing the netloc is safe
    and matches how the URL would resolve over the wire. The URL path
    (i.e. the S3 object key) is case-sensitive and must not be touched here.
    """
    if not netloc:
        return netloc
    lowered = netloc.lower()
    try:
        bucket, _region, _endpoint, _prefix = parse_s3_bucket_url(f"https://{lowered}/")
    except ValueError:
        return lowered
    return f"{bucket}.s3.amazonaws.com"


def is_s3_not_found_error(error: Exception) -> bool:
    if not isinstance(error, ClientError):
        return False
    error_code = error.response.get("Error", {}).get("Code", "")
    return error_code in {"404", "NoSuchKey", "NotFound"}


def classify_botocore_network_error(error: Exception) -> type[AssetLibraryNetworkError]:
    if isinstance(error, (ConnectTimeoutError, ReadTimeoutError)):
        return AssetLibraryTimeoutError
    if isinstance(error, (EndpointConnectionError, ConnectionClosedError)):
        return AssetLibraryConnectionError
    return AssetLibraryRemoteResponseError


def s3_client_config(timeout_seconds: float) -> Config:
    return Config(
        signature_version=UNSIGNED,
        retries={"max_attempts": 3, "mode": "standard"},
        connect_timeout=timeout_seconds,
        read_timeout=timeout_seconds,
    )


def _resolve_bucket_region(bucket: str) -> str:
    """Return the bucket's authoritative AWS region.

    Uses an anonymous head_bucket against us-east-1. S3 returns
    x-amz-bucket-region in the response headers for both success and the 301
    redirect, so a single round-trip suffices.
    """
    probe = boto3.client(
        "s3",
        region_name="us-east-1",
        config=Config(signature_version=UNSIGNED, retries={"max_attempts": 1}),
    )
    try:
        resp = probe.head_bucket(Bucket=bucket)
        headers = resp["ResponseMetadata"]["HTTPHeaders"]
    except ClientError as e:
        headers = e.response.get("ResponseMetadata", {}).get("HTTPHeaders", {})
        if "x-amz-bucket-region" not in headers:
            raise

    region = headers.get("x-amz-bucket-region")
    if not region:
        raise ClientError(
            {
                "Error": {
                    "Code": "RegionResolutionFailed",
                    "Message": f"Could not determine region for bucket {bucket}",
                }
            },
            "HeadBucket",
        )
    return region


def _resolve_s3_bucket_url(bucket_url: str) -> tuple[str, str, str]:
    """Parse a bucket URL, probe the bucket's region, warn on mismatch.

    Returns (bucket, region_name, simready_project_root). The endpoint hint
    from parse_s3_bucket_url is intentionally dropped -- the caller should let
    boto3 build the regional endpoint from region_name.
    """
    bucket, hint_region, _hint_endpoint, simready_project_root = parse_s3_bucket_url(bucket_url)
    region_name = _resolve_bucket_region(bucket)
    if hint_region and hint_region != region_name:
        log(
            1,
            f"S3 URL '{bucket_url}' specifies region '{hint_region}' "
            f"but bucket '{bucket}' is in '{region_name}'; using '{region_name}'.",
        )
    return bucket, region_name, simready_project_root


def create_s3_client(bucket_url: str) -> tuple[BaseClient, str, str, str]:
    """Parse a bucket URL and create an anonymous S3 client.

    Returns:
        (s3_client, bucket, simready_project_root, normalized_url)
    """
    normalized = bucket_url.rstrip("/")
    bucket, region_name, simready_project_root = _resolve_s3_bucket_url(normalized)
    client_config = Config(
        signature_version=UNSIGNED,
        retries={"max_attempts": 3, "mode": "standard"},
        connect_timeout=15,
        read_timeout=15,
    )
    client = boto3.client("s3", config=client_config, region_name=region_name)
    return client, bucket, simready_project_root, normalized


def index_s3_directory(
    directory_path: str,
    config_priority: int,
    timeout_seconds: float,
    raise_on_network_error: bool,
) -> dict:
    try:
        bucket, region_name, prefix = _resolve_s3_bucket_url(directory_path)
    except ValueError as e:
        log(2, f"Could not parse S3 URL for indexing {directory_path}: {e}")
        return {}
    except (ClientError, BotoCoreError) as e:
        handle_network_error(
            f"Failed to initialize S3 indexing for {directory_path}",
            error=e,
            raise_on_network_error=raise_on_network_error,
            exception_cls=classify_botocore_network_error(e),
        )
        return {}
    try:
        s3 = boto3.resource("s3", config=s3_client_config(timeout_seconds), region_name=region_name)
        bucket_obj = s3.Bucket(bucket)
    except (ClientError, BotoCoreError) as e:
        handle_network_error(
            f"Failed to initialize S3 indexing for {directory_path}",
            error=e,
            raise_on_network_error=raise_on_network_error,
            exception_cls=classify_botocore_network_error(e),
        )
        return {}

    normalized_root = directory_path.rstrip("/")
    prefix_with_slash = f"{prefix}/" if prefix else ""
    new_entries = {}
    try:
        for obj in bucket_obj.objects.filter(Prefix=prefix_with_slash):
            key = obj.key
            if key.endswith("/"):
                continue

            partial_path = (
                key[len(prefix_with_slash) :] if prefix_with_slash and key.startswith(prefix_with_slash) else key
            )
            asset_path = f"{normalized_root}/{partial_path}" if partial_path else normalized_root
            asset_data = {
                "asset_partial_path": partial_path,
                "config_priority": config_priority,
                "content_root_path": normalized_root,
                "asset_version": None,
                "content_source": "s3",
                "tags": {},
            }
            new_entries[asset_path] = {None: asset_data}
    except (ClientError, BotoCoreError) as e:
        handle_network_error(
            f"Failed to list S3 directory {directory_path}",
            error=e,
            raise_on_network_error=raise_on_network_error,
            exception_cls=classify_botocore_network_error(e),
        )
        return {}
    return new_entries


def index_s3_directory_chunked(
    directory_path: str,
    config_priority: int,
    on_chunk: Callable[[dict], None],
    timeout_seconds: float,
    raise_on_network_error: bool,
    chunk_size: int = 1000,
    flush_interval_seconds: float = 1.0,
    cancel_event: Optional[threading.Event] = None,
) -> int:
    try:
        bucket, region_name, prefix = _resolve_s3_bucket_url(directory_path)
    except ValueError as e:
        log(2, f"Could not parse S3 URL for indexing {directory_path}: {e}")
        return 0
    except (ClientError, BotoCoreError) as e:
        handle_network_error(
            f"Failed to initialize S3 indexing for {directory_path}",
            error=e,
            raise_on_network_error=raise_on_network_error,
            exception_cls=classify_botocore_network_error(e),
        )
        return 0
    try:
        s3 = boto3.resource("s3", config=s3_client_config(timeout_seconds), region_name=region_name)
        bucket_obj = s3.Bucket(bucket)
    except (ClientError, BotoCoreError) as e:
        handle_network_error(
            f"Failed to initialize S3 indexing for {directory_path}",
            error=e,
            raise_on_network_error=raise_on_network_error,
            exception_cls=classify_botocore_network_error(e),
        )
        return 0

    normalized_root = directory_path.rstrip("/")
    prefix_with_slash = f"{prefix}/" if prefix else ""
    indexed_file_count = 0
    entries_chunk = {}
    last_flush_time = time.time()
    try:
        for obj in bucket_obj.objects.filter(Prefix=prefix_with_slash):
            if cancel_event is not None and cancel_event.is_set():
                log(0, f"Indexing cancelled for {directory_path}")
                if entries_chunk:
                    on_chunk(entries_chunk)
                return indexed_file_count

            key = obj.key
            if key.endswith("/"):
                continue

            partial_path = (
                key[len(prefix_with_slash) :] if prefix_with_slash and key.startswith(prefix_with_slash) else key
            )
            asset_path = f"{normalized_root}/{partial_path}" if partial_path else normalized_root
            asset_data = {
                "asset_partial_path": partial_path,
                "config_priority": config_priority,
                "content_root_path": normalized_root,
                "asset_version": None,
                "content_source": "s3",
                "tags": {},
            }
            entries_chunk[asset_path] = {None: asset_data}
            indexed_file_count += 1

            now = time.time()
            if len(entries_chunk) >= chunk_size or (
                (now - last_flush_time) >= flush_interval_seconds and len(entries_chunk) > 0
            ):
                on_chunk(entries_chunk)
                entries_chunk = {}
                last_flush_time = now

        if entries_chunk:
            on_chunk(entries_chunk)
    except (ClientError, BotoCoreError) as e:
        handle_network_error(
            f"Failed to list S3 directory {directory_path}",
            error=e,
            raise_on_network_error=raise_on_network_error,
            exception_cls=classify_botocore_network_error(e),
        )
        if entries_chunk:
            on_chunk(entries_chunk)
        return indexed_file_count

    return indexed_file_count
