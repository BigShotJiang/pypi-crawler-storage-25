# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from ._logs import log


class AssetLibraryNetworkError(RuntimeError):
    """Raised when a network/remote call in asset search fails."""


class AssetLibraryTimeoutError(AssetLibraryNetworkError):
    """Raised when a network operation times out."""


class AssetLibraryConnectionError(AssetLibraryNetworkError):
    """Raised when a connection cannot be established or is dropped."""


class AssetLibraryRemoteResponseError(AssetLibraryNetworkError):
    """Raised when a remote service returns an invalid or failed response."""


def handle_network_error(
    message: str,
    error: Exception | None = None,
    raise_on_network_error: bool = False,
    exception_cls: type[AssetLibraryNetworkError] = AssetLibraryNetworkError,
):
    """Log network/remote failures and optionally raise a typed exception."""
    if error is None:
        log(2, message)
    else:
        log(2, f"{message}: {error}")
    if raise_on_network_error:
        if error is None:
            raise exception_cls(message)
        raise exception_cls(message) from error
