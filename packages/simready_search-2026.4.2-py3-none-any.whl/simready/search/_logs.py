# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import Callable, TypeAlias

# If you want the calling code to handle logging, pass a function like:
#   my_log(log_level: int, log_message: str)
# where log_level 0, 1, 2 correspond to info, warning, error.
AssetLibrary_LogCallback: TypeAlias = Callable[[int, str], None]

_custom_log_func: AssetLibrary_LogCallback = None


def set_log_func(fn: AssetLibrary_LogCallback):
    """Set a custom callback to receive all library log output.

    The callback signature is ``(level: int, message: str) -> None``
    where level 0 = info, 1 = warning, 2 = error.  Pass ``None`` to
    revert to the default ``print``-based logging.

    Args:
        fn: Log callback, or ``None`` to reset.
    """
    global _custom_log_func
    _custom_log_func = fn


def log(log_level: int, log_message: str):
    if _custom_log_func is not None:
        _custom_log_func(log_level, log_message)
    else:
        prefix = "[Info] [Asset Library]"
        if log_level == 1:
            prefix = "[Warning] [Asset Library]"
        elif log_level == 2:
            prefix = "[Error] [Asset Library]"
        print(f"{prefix} {log_message}")
