# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import asyncio
import json
import os
import tomllib
from dataclasses import dataclass
from typing import Callable, Optional

from ._logs import log


def load_workspace_cache(project_config_toml_path: str, file_reader: Optional[Callable[[str], str]] = None) -> dict:
    return asyncio.run(load_workspace_cache_async(project_config_toml_path, file_reader))


async def load_workspace_cache_async(
    project_config_toml_path: str, file_reader: Optional[Callable[[str], str]] = None
) -> dict:
    # The workspace_cache.json lives in the content root specified by the root project config
    root_config = await load_toml_file_async(project_config_toml_path, file_reader)
    parent_dir = project_config_toml_path.rsplit("/", 1)[0]
    project_root = os.path.join(parent_dir, root_config.get("project_root", {}).get("setting", "")).replace("\\", "/")
    content_root = os.path.join(project_root, root_config.get("content_root", {}).get("name", "")).replace("\\", "/")
    workspace_cache_path = os.path.join(content_root, "workspace_cache.json").replace("\\", "/")
    return await load_json_file_async(resolve_path(workspace_cache_path), file_reader)


async def load_toml_file_async(toml_file_path: str, file_reader: Optional[Callable[[str], str]] = None) -> dict:

    log(0, f"Reading project config from: {toml_file_path}")
    try:
        if file_reader is not None:
            if asyncio.iscoroutinefunction(file_reader):
                file_contents = await file_reader(toml_file_path)
            else:
                file_contents = file_reader(toml_file_path)
            if not file_contents:
                raise FileNotFoundError
            config_dict = tomllib.loads(file_contents)
        else:
            with open(toml_file_path, "rb") as file:
                config_dict = tomllib.load(file)
        return config_dict
    except OSError:
        log(2, f"File not found: {toml_file_path}")
    except tomllib.TOMLDecodeError as e:
        log(2, f"Invalid TOML file: {e}")
    return {}


def load_json_file(json_file_path: str, file_reader: Optional[Callable[[str], str]] = None) -> dict:
    return asyncio.run(load_json_file_async(json_file_path, file_reader))


async def load_json_file_async(json_file_path: str, file_reader: Optional[Callable[[str], str]] = None) -> dict:
    log(0, f"Reading workspace cache from: {json_file_path}")
    try:
        if file_reader is not None:
            if asyncio.iscoroutinefunction(file_reader):
                file_contents = await file_reader(json_file_path)
            else:
                file_contents = file_reader(json_file_path)
            if not file_contents:
                raise FileNotFoundError
            cache_dict = json.loads(file_contents)
        else:
            with open(json_file_path, "r") as file:
                cache_dict = json.load(file)
        return cache_dict
    except OSError:
        log(2, f"File not found: {json_file_path}")
    except json.decoder.JSONDecodeError as e:
        log(2, f"Invalid json file: {e}")
    return {}


@dataclass
class ProjectConfig:
    project_root_abs_path: str
    content_root_name: str


def load_configs_recursive(root_config_abs_path: str, file_reader: Optional[Callable[[str], str]] = None):
    return asyncio.run(load_configs_recursive_async(root_config_abs_path, file_reader))


async def load_configs_recursive_async(root_config_abs_path: str, file_reader: Optional[Callable[[str], str]] = None):
    project_config_dict = await load_toml_file_async(root_config_abs_path, file_reader)
    if not project_config_dict:
        return []
    project_root = project_config_dict.get("project_root", {}).get("setting", "")
    content_root_name = project_config_dict.get("content_root", {}).get("name", "")

    # Assemble a list of subconfigs
    root_config_path = f"{project_root}/{content_root_name}/project_config.toml"
    subconfigs = project_config_dict.get("workspace", {}).get("subconfigs", [])
    subconfigs_priority = project_config_dict.get("workspace", {}).get("subconfigs_priority", [])
    if subconfigs:
        subconfigs.append(root_config_path)
    else:
        subconfigs = [root_config_path]
        subconfigs_priority = [content_root_name]

    # and sort it by priority
    def get_foldername_of_subconfig(path: str) -> str:
        try:
            return path.split("/")[-2]
        except IndexError:
            return ""

    subconfigs.sort(
        key=lambda path: (
            999
            if get_foldername_of_subconfig(path) not in subconfigs_priority
            else subconfigs_priority.index(get_foldername_of_subconfig(path))
        )
    )
    log(0, f"ProjectConfig order for {root_config_abs_path}: {subconfigs}")

    # Recursively load subconfigs and return all the necessary info from them in the proper order
    root_config_dir = root_config_abs_path.rsplit("/", 1)[0]
    configs = []
    for subconfig in subconfigs:
        if subconfig == root_config_path:
            configs.append(ProjectConfig(resolve_path(os.path.join(root_config_dir, project_root)), content_root_name))
        else:
            # subconfigs are relative to the root_config path
            configs.extend(
                await load_configs_recursive_async(resolve_path(os.path.join(root_config_dir, subconfig)), file_reader)
            )
    return configs


def resolve_path(path: str) -> str:
    # remove ".." levels from the path
    new_parts = []
    for part in path.replace("\\", "/").split("/"):
        if len(new_parts) > 0 and part == "..":
            new_parts.pop()
        else:
            new_parts.append(part)
    return "/".join(new_parts)
