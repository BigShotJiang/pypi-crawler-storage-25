# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import fnmatch
from abc import ABC, abstractmethod


class AssetLibrarySearchFilter(ABC):
    """Base class for all search filters.

    Subclasses are passed to the ``include_*`` / ``exclude_*`` parameters
    of ``AssetLibrary.search()`` to select or reject assets.
    """

    @abstractmethod
    def __init__(self, **kwargs):
        pass

    @abstractmethod
    def test(self, asset_path: str, asset_data: dict) -> bool:
        """Return ``True`` if the asset matches this filter.

        Args:
            asset_path: The full asset path string.
            asset_data: Dictionary of asset metadata.
        """

    @abstractmethod
    def __repr__(self) -> str:
        return f'{self.__class__.__name__}("your constructor arguments here")'

    @abstractmethod
    def __str__(self) -> str:
        return self.__repr__()

    @staticmethod
    def get_all_values(asset_data: dict) -> set:
        return set()

    @staticmethod
    def fnmatch_strings(string1: str, string2: str, case_sensitive: bool = False) -> bool:
        if case_sensitive:
            return fnmatch.fnmatch(string1, string2)
        else:
            return fnmatch.fnmatch(string1.lower(), string2.lower())


class SearchFilterPathContains(AssetLibrarySearchFilter):
    """Match assets whose path contains a substring (case-insensitive).

    Args:
        substring: The substring to search for in the asset path.
    """

    def __init__(self, substring: str = ""):
        self.substring = substring

    def __repr__(self) -> str:
        return f'{self.__class__.__name__}("{self.substring}")'

    def __str__(self) -> str:
        return f"with '{self.substring}' in the path"

    def test(self, asset_path: str, asset_data: dict) -> bool:
        if not self.substring:
            return True  # every path matches an empty string
        return self.substring.lower() in asset_path.lower()


class SearchFilterClass(AssetLibrarySearchFilter):
    """Match assets whose ``tags.class`` metadata contains a given class name.

    Args:
        class_name: The class name to match.
    """

    def __init__(self, class_name: str = ""):
        self.class_name = class_name

    def __repr__(self) -> str:
        return f'{self.__class__.__name__}("{self.class_name}")'

    def __str__(self) -> str:
        return f"of class '{self.class_name}'"

    def test(self, asset_path: str, asset_data: dict) -> bool:
        return self.class_name in SearchFilterClass.get_all_values(asset_data)

    @staticmethod
    def get_all_values(asset_data: dict) -> set:
        cls = asset_data.get("tags", {}).get("class", [])
        if isinstance(cls, str):
            cls = [cls]
        return set(cls)


class SearchFilterTag(AssetLibrarySearchFilter):
    """Match assets that have a given tag in any tag namespace.

    Args:
        tag: The tag string to match.
    """

    def __init__(self, tag: str = ""):
        self.tag = tag

    def __repr__(self) -> str:
        return f'{self.__class__.__name__}("{self.tag}")'

    def __str__(self) -> str:
        return f"with tag '{self.tag}'"

    def test(self, asset_path: str, asset_data: dict) -> bool:
        return self.tag in SearchFilterTag.get_all_values(asset_data)

    @staticmethod
    def get_all_values(asset_data: dict) -> set:
        all_tags = set()
        tags_dict = asset_data.get("tags", {})
        for _namespace, tags in tags_dict.items():
            for tag in tags:
                if tag:
                    all_tags.add(tag)
        return all_tags


class SearchFilterFeature(AssetLibrarySearchFilter):
    """Match assets that have passed validation for a given feature.

    Supports glob patterns (via ``fnmatch``).

    Args:
        feature: Feature name or glob pattern to match.
        version: When provided, only this specific feature version
            matches.  Defaults to any version.
        case_sensitive: Whether the pattern match is case-sensitive.
    """

    def __init__(self, feature: str = "", version: str = "", case_sensitive: bool = False):
        self.feature = feature
        self.version = version
        self.case_sensitive = case_sensitive

    def __repr__(self) -> str:
        version_str = f" (version {self.version})" if self.version else ""
        return f'{self.__class__.__name__}("{self.feature}"{version_str})'

    def __str__(self) -> str:
        return f"with feature '{self.feature}'{f' (version {self.version})' if self.version else ''}"

    def test(self, asset_path: str, asset_data: dict) -> bool:
        features_list = SearchFilterFeature._get_features_list(asset_data)
        for feature in features_list:
            if isinstance(feature, str) and self.fnmatch_strings(feature, self.feature, self.case_sensitive):
                # This is a legacy path and probably isn't used anymore.
                # Features represented only by a string have no version and should only match if no version is provided
                return self.version == ""
            elif isinstance(feature, dict):
                # These features are dicts of dicts, like {"feature_name": {"version": "1.0.0", "passed": True}}
                for feature_name in feature.keys():
                    if self.fnmatch_strings(feature_name, self.feature, self.case_sensitive):
                        # We found a feature dict matching the pattern
                        passed = feature[feature_name].get("passed", False)
                        if self.version:
                            # If we also match the specified version, our search is done.
                            if feature[feature_name].get("version", "") == self.version:
                                return passed
                        else:
                            # No version specified, so we can match any passing version
                            if passed:
                                return True
                        # otherwise, keep looking because there could be multiple versions of the same feature
        return False

    @staticmethod
    def _get_features_list(asset_data: dict) -> list:
        features_list = asset_data.get("validation", {}).get("features", [])
        if isinstance(features_list, str):
            return [features_list]
        return features_list

    @staticmethod
    def get_all_values(asset_data: dict) -> set:
        features_list = SearchFilterFeature._get_features_list(asset_data)
        all_keys = set()
        for feature in features_list:
            if isinstance(feature, str):
                all_keys.add(feature)
            elif isinstance(feature, dict):
                all_keys.update(feature.keys())
        return all_keys


class SearchFilterProfile(AssetLibrarySearchFilter):
    """Match assets whose validation profile name matches a pattern.

    Supports glob patterns (via ``fnmatch``).

    Args:
        profile: Profile name or glob pattern to match.
        version: When provided, the profile version must also match.
            Defaults to any version.
        case_sensitive: Whether the pattern match is case-sensitive.
    """

    def __init__(self, profile: str = "", version: str = "", case_sensitive: bool = False):
        self.profile = profile
        self.version = version
        self.case_sensitive = case_sensitive

    def __repr__(self) -> str:
        version_str = f" (version {self.version})" if self.version else ""
        return f'{self.__class__.__name__}("{self.profile}"{version_str})'

    def __str__(self) -> str:
        return f"with profile '{self.profile}'{f' (version {self.version})' if self.version else ''}"

    def test(self, asset_path: str, asset_data: dict) -> bool:
        profile, profile_version = SearchFilterProfile._get_profile_info(asset_data)
        # If a version is specified, we must match both the profile and the version
        # Otherwise, we only need to match the profile name
        profile_matches = self.fnmatch_strings(profile, self.profile, self.case_sensitive)
        if self.version:
            return profile_matches and profile_version == self.version
        return profile_matches

    @staticmethod
    def _get_profile_info(asset_data: dict) -> tuple[str, str]:
        profile = asset_data.get("validation", {}).get("profile", "")
        profile_version = asset_data.get("validation", {}).get("profile_version", "")
        return profile, profile_version

    @staticmethod
    def get_all_values(asset_data: dict) -> set:
        # There is only one profile per asset
        profile, profile_version = SearchFilterProfile._get_profile_info(asset_data)
        return {(profile, profile_version)}


class SearchFilterScenePOI(AssetLibrarySearchFilter):
    """Match assets that have a point-of-interest anchor with a given tag.

    Args:
        poi_tag: The POI tag to match.
    """

    def __init__(self, poi_tag: str = ""):
        self.poi_tag = poi_tag

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self.poi_tag})"

    def __str__(self) -> str:
        return f"with scene POI '{self.poi_tag}'"

    def test(self, asset_path: str, asset_data: dict) -> bool:
        return self.poi_tag in SearchFilterScenePOI.get_all_values(asset_data)

    @staticmethod
    def get_all_values(asset_data: dict) -> set:
        all_pois = set()
        poi_dict = asset_data.get("poi", {})
        for _anchor_prim, anchor_data in poi_dict.items():
            tags = anchor_data.get("tags", "")
            all_pois.update(t.strip() for t in tags.split(",") if t.strip())
        return all_pois


class SearchFilterCountry(AssetLibrarySearchFilter):
    """Match assets associated with a given country.

    Args:
        country_name: The country name to match.
    """

    def __init__(self, country_name: str = ""):
        self.country_name = country_name

    def __repr__(self) -> str:
        return f'{self.__class__.__name__}("{self.country_name}")'

    def __str__(self) -> str:
        return f"from country '{self.country_name}'"

    def test(self, asset_path: str, asset_data: dict) -> bool:
        return self.country_name in SearchFilterCountry.get_all_values(asset_data)

    @staticmethod
    def get_all_values(asset_data: dict) -> set:
        return {asset_data.get("country", "")}


class SearchFilterHeight(AssetLibrarySearchFilter):
    """Match assets whose height metadata falls within a range.

    Args:
        minimum: Lower bound of the height range in meters.
        maximum: Upper bound of the height range in meters.
    """

    def __init__(self, minimum: float = 0.0, maximum: float = float("inf")):
        self.min = minimum
        self.max = maximum

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self.min} - {self.max})"

    def __str__(self) -> str:
        if self.min == 0.0:
            if self.max == float("inf"):
                return "of any height"
            return f"less than {self.max} meters tall"
        if self.max == float("inf"):
            return f"more than {self.min} meters tall"
        return f"between {self.min} and {self.max} meters tall"

    def test(self, asset_path: str, asset_data: dict) -> bool:
        try:
            height = float(asset_data.get("height", 0.0))
        except (TypeError, ValueError):
            return False
        return height >= self.min and height <= self.max


class SearchFilterArbitraryDictValue(AssetLibrarySearchFilter):
    """Match assets by traversing a nested metadata path for a value.

    Example::

        SearchFilterArbitraryDictValue(["validation", "profile"], "SimReady")

    matches ``asset_data["validation"]["profile"] == "SimReady"``.

    Args:
        dict_path: Ordered list of dictionary keys to traverse.
        value: The expected value at the end of the key path.
    """

    def __init__(self, dict_path: list[str], value: str):
        self.dict_path = dict_path
        self.value = value

    def __repr__(self) -> str:
        return f'{self.__class__.__name__}("{self.dict_path}, {self.value}")'

    def __str__(self) -> str:
        return f"with '{self.dict_path}' = '{self.value}'"

    def test(self, asset_path: str, asset_data: dict) -> bool:
        intermediate = asset_data
        try:
            for level in self.dict_path:
                intermediate = intermediate[level]
        except (KeyError, IndexError, TypeError):
            return False
        return intermediate == self.value


class SearchFilterPhrase(AssetLibrarySearchFilter):
    """Natural-language phrase describing the desired asset.

    Only effective against service sources backed by AI; always
    returns ``False`` for local cache sources.

    Args:
        phrase: Free-text description of the desired asset.
    """

    def __init__(self, phrase: str = ""):
        self.phrase = phrase

    def __repr__(self) -> str:
        return f'{self.__class__.__name__}("{self.phrase}")'

    def __str__(self) -> str:
        return f'like "{self.phrase}"'

    def test(self, asset_path: str, asset_data: dict) -> bool:
        # There is no way to test this filter against the asset_data loaded from the workspace_cache.
        # It is only used for service endpoints with an LLM backend.
        return False


class SearchFilterRelevance(AssetLibrarySearchFilter):
    """Match assets whose relevance score meets a minimum threshold.

    Assets without a relevance score (local/cache results) always pass.

    Args:
        minimum: Minimum relevance score required.
    """

    def __init__(self, minimum: float = 0.0):
        self.minimum = minimum

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self.minimum})"

    def __str__(self) -> str:
        return f"relevance >= {self.minimum}"

    def test(self, asset_path: str, asset_data: dict) -> bool:
        score = asset_data.get("relevance_score")
        if score is None:
            return True
        return score >= self.minimum
