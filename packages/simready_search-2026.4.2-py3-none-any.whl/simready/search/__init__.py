# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from ._library import AssetData, AssetLibrary, set_log_func
from ._network_shared import (
    AssetLibraryConnectionError,
    AssetLibraryNetworkError,
    AssetLibraryRemoteResponseError,
    AssetLibraryTimeoutError,
)
from ._search_filters import (
    AssetLibrarySearchFilter,
    SearchFilterArbitraryDictValue,
    SearchFilterClass,
    SearchFilterCountry,
    SearchFilterFeature,
    SearchFilterHeight,
    SearchFilterPathContains,
    SearchFilterPhrase,
    SearchFilterProfile,
    SearchFilterRelevance,
    SearchFilterScenePOI,
    SearchFilterTag,
)
from ._search_source import (
    CacheSearchSource,
    DictBackedSource,
    IndexedSearchSource,
    SearchSource,
    ServiceSearchSource,
)

__all__ = [
    # Core
    "AssetData",
    "AssetLibrary",
    "set_log_func",
    # Sources
    "CacheSearchSource",
    "DictBackedSource",
    "IndexedSearchSource",
    "SearchSource",
    "ServiceSearchSource",
    # Filters
    "AssetLibrarySearchFilter",
    "SearchFilterArbitraryDictValue",
    "SearchFilterClass",
    "SearchFilterCountry",
    "SearchFilterFeature",
    "SearchFilterHeight",
    "SearchFilterPathContains",
    "SearchFilterPhrase",
    "SearchFilterProfile",
    "SearchFilterRelevance",
    "SearchFilterScenePOI",
    "SearchFilterTag",
    # Exceptions
    "AssetLibraryConnectionError",
    "AssetLibraryNetworkError",
    "AssetLibraryRemoteResponseError",
    "AssetLibraryTimeoutError",
]
