# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import asyncio
import threading
from typing import Optional

from ._s3_utils import canonicalize_aws_s3_netloc


def _resolve_dot_segments(path: str) -> str:
    """Collapse ``.`` and ``..`` segments in a forward-slash path.

    The input is treated as absolute when it starts with ``/`` (in which case
    leading ``..`` segments above the root are dropped). Otherwise it is
    treated as relative and unresolvable leading ``..`` segments are kept.
    """
    if not path:
        return path
    is_absolute = path.startswith("/")
    out: list[str] = []
    for seg in path.split("/"):
        if seg in ("", "."):
            continue
        if seg == "..":
            if out and out[-1] != "..":
                out.pop()
            elif not is_absolute:
                out.append("..")
            continue
        out.append(seg)
    result = "/".join(out)
    if is_absolute:
        result = "/" + result
    return result


def _normalize_path_for_match(path: str) -> str:
    """Normalize a path/URL for source and base-path matching."""
    normalized = (path or "").strip().replace("\\", "/")
    if not normalized:
        return ""

    if "://" in normalized:
        scheme, rest = normalized.split("://", 1)
        netloc, sep, tail = rest.partition("/")
        netloc = canonicalize_aws_s3_netloc(netloc)
        rest = f"{netloc}{sep}{tail}"
        while "//" in rest:
            rest = rest.replace("//", "/")
        rest = _resolve_dot_segments(rest)
        normalized = f"{scheme.lower()}://{rest}"
    else:
        while "//" in normalized:
            normalized = normalized.replace("//", "/")
        # Normalize Windows local path casing for more consistent matching.
        if len(normalized) >= 2 and normalized[1] == ":":
            normalized = normalized.lower()
            # Peel off the drive so '..' resolution doesn't eat it.
            normalized = normalized[:2] + _resolve_dot_segments(normalized[2:])
        else:
            normalized = _resolve_dot_segments(normalized)

    if normalized.endswith("/") and normalized not in ("/",):
        normalized = normalized.rstrip("/")
    return normalized


def _is_boundary_prefix(path: str, prefix: str) -> bool:
    """Return True if *prefix* matches *path* on a path boundary."""
    normalized_path = _normalize_path_for_match(path)
    normalized_prefix = _normalize_path_for_match(prefix)
    if not normalized_path or not normalized_prefix:
        return False
    if normalized_path == normalized_prefix:
        return True
    return normalized_path.startswith(f"{normalized_prefix}/")


def _paths_overlap(path_a: str, path_b: str) -> bool:
    """Return True when two paths overlap by boundary-aware prefix."""
    return _is_boundary_prefix(path_a, path_b) or _is_boundary_prefix(path_b, path_a)


class SearchSource:
    """Base class for a searchable content source registered with ``AssetLibrary``.

    Each source declares the asset-path namespaces it covers via
    ``content_roots``.  At search time, ``matches_query_paths``
    determines whether the source participates.

    Attributes:
        source_id: Identifier for this source.
        content_roots: Normalized path prefixes this source covers.
    """

    def __init__(self, source_id: str, content_roots: Optional[list[str]] = None):
        self.source_id = source_id
        self.content_roots: list[str] = content_roots if content_roots is not None else []
        self._loading_task: Optional[asyncio.Task] = None
        self._cancel_event = threading.Event()

    def is_loading(self) -> bool:
        """Return ``True`` if loading or indexing is still in progress."""
        return self._loading_task is not None and not self._loading_task.done()

    def cancel_loading(self) -> None:
        """Cancel any in-progress loading or indexing for this source."""
        self._cancel_event.set()
        if self._loading_task is not None and not self._loading_task.done():
            self._loading_task.cancel()
        self._loading_task = None

    def matches_query_paths(self, query_base_paths: list[str]) -> bool:
        """Check whether this source should participate in a search.

        An empty ``content_roots`` means the source covers everything
        and always participates.  Otherwise, at least one root must
        overlap with at least one entry in *query_base_paths*.

        Args:
            query_base_paths: Normalized path prefixes to test against.

        Returns:
            ``True`` if this source should be included in the search.
        """
        if not self.content_roots:
            return True
        for root in self.content_roots:
            for qbp in query_base_paths:
                if _paths_overlap(root, qbp):
                    return True
        return False


class DictBackedSource(SearchSource):
    """Base for sources that store asset entries in a dictionary.

    Provides thread-safe snapshot, merge, removal, and counting of
    the underlying entry dict.
    """

    def __init__(self, source_id: str, content_roots: Optional[list[str]] = None):
        super().__init__(source_id, content_roots)
        self._cache_dict: dict = {}
        self._cache_dict_lock = threading.RLock()

    def snapshot_items(self) -> list:
        """Return a thread-safe shallow copy of all entries as a list of ``(path, versions)`` pairs."""
        with self._cache_dict_lock:
            return list(self._cache_dict.items())

    def merge_entries(self, new_entries: dict) -> None:
        """Merge *new_entries* into the source's entry dictionary.

        Args:
            new_entries: Mapping of asset paths to version dicts.
        """
        if not new_entries:
            return
        with self._cache_dict_lock:
            for entries in new_entries.values():
                if isinstance(entries, dict):
                    for ad in entries.values():
                        if isinstance(ad, dict):
                            ad["source_id"] = self.source_id
            self._cache_dict.update(new_entries)

    def remove_entries(self, root_directory_path: str) -> int:
        """Remove all entries whose content root matches *root_directory_path*.

        Args:
            root_directory_path: The content root path to match.

        Returns:
            Number of entries removed.
        """
        with self._cache_dict_lock:
            to_remove = [
                asset_path
                for asset_path, entries in self._cache_dict.items()
                if any(ad.get("content_root_path") == root_directory_path for ad in entries.values())
                if isinstance(entries, dict)
            ]
            for asset_path in to_remove:
                del self._cache_dict[asset_path]
        return len(to_remove)

    def entry_count(self) -> int:
        """Return the number of asset entries in this source."""
        with self._cache_dict_lock:
            return len(self._cache_dict)


class CacheSearchSource(DictBackedSource):
    """Source backed by a workspace cache with full asset metadata."""

    pass


class IndexedSearchSource(DictBackedSource):
    """Source backed by a plain file-listing index (local or S3).

    Entries contain only path information.  Metadata-based search
    filters will produce unexpected results against this source.
    """

    pass


class ServiceSearchSource(SearchSource):
    """Source backed by a remote search API endpoint (e.g. USD Search).

    Attributes:
        endpoint_url: URL of the search service.
    """

    def __init__(
        self,
        source_id: str,
        endpoint_url: str,
    ):
        # TODO: get list of content roots from the endpoint
        super().__init__(source_id, content_roots=[])
        self.endpoint_url = endpoint_url
