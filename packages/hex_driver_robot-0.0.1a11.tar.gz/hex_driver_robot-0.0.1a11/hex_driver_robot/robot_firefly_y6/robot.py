#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-03-26
################################################################

import time
import numpy as np
import multiprocessing as mp
from dataclasses import dataclass, field
from typing import Any, Optional

from hex_device import HexDeviceApi, Arm, Hands
from hex_device.motor_base import CommandType
from hex_util_runtime import HexRate, HexShmRingBuffer, ns_now, hex_ts_to_ns
from hex_util_robot import HexDynUtilY6, HexFricUtil, interp_joint
from hex_util_urdf import HEXARM_URDF_PATH_DICT
from ..base import HexRobotBase, HexRobotBaseParams


@dataclass
class HexRobotFireflyY6Params(HexRobotBaseParams):
    grip_type: str = "gp80"
    pose_end_in_flange: np.ndarray = field(default_factory=lambda: np.array(
        [0.187, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0]))


class HexRobotFireflyY6(HexRobotBase):

    def __init__(
            self,
            params: HexRobotFireflyY6Params = HexRobotFireflyY6Params(),
    ) -> None:
        HexRobotBase.__init__(self)
        self.__params = params
        self.__hex_api: Optional[HexDeviceApi] = None
        self.__arm: Optional[Arm] = None
        self.__gripper: Optional[Hands] = None

        self.__dof_dict = {
            "arm": 6,
            "grip": 1 if self.__params.grip_type.startswith("gp80") else 0,
        }
        self.__ring_dict = {
            "arm_motor": None,
            "grip_motor": None,
        }
        self.__pipe_dict = {
            "arm_cmd": None,
            "grip_cmd": None,
        }

        self.__cur_cmd = {
            "arm_cmd": None,
            "grip_cmd": None,
        }
        self.__last_cmd_ts = {
            "arm_cmd": 0,
            "grip_cmd": 0,
        }
        self.__cur_state = {
            "arm": None,
            "grip": None,
        }
        self.__dyn_util = HexDynUtilY6(
            model_path=HEXARM_URDF_PATH_DICT[
                f"firefly_y6_{self.__params.grip_type}"],
            pose_end_in_flange=self.__params.pose_end_in_flange,
        )
        self.__arm_fric_util = HexFricUtil(
            fc=np.array([0.15, 0.15, 0.15, 0.15, 0.0, 0.0]),
            fv=np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0]),
            fo=np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0]),
            k=np.array([200.0, 200.0, 200.0, 200.0, 200.0, 200.0]),
        )
        self.__grip_fric_util = HexFricUtil(
            fc=np.array([0.03]),
            fv=np.array([0.0]),
            fo=np.array([0.0]),
            k=np.array([200.0]),
        ) if self.__params.grip_type.startswith("gp80") else None
        self.init_vars()

    def init_vars(self):
        self.__host = self.__params.host
        self.__port = self.__params.port
        self.__ctrl_rate = int(self.__params.ctrl_rate)
        self.__state_buffer_size = int(self.__params.state_buffer_size)
        self.__sens_ts = self.__params.sens_ts

        # arm state buffer
        arm_state_dtype = np.dtype([
            ("ts_ns", np.int64),
            ("pos", np.float64, (6, )),
            ("vel", np.float64, (6, )),
            ("eff", np.float64, (6, )),
        ])
        self.__ring_dict["arm_motor"] = HexShmRingBuffer(
            capacity=self.__state_buffer_size,
            dtype=arm_state_dtype,
        )

        # grip state buffer
        grip_dof = self.__dof_dict["grip"]
        if grip_dof > 0:
            grip_state_dtype = np.dtype([
                ("ts_ns", np.int64),
                ("pos", np.float64, (grip_dof, )),
                ("vel", np.float64, (grip_dof, )),
                ("eff", np.float64, (grip_dof, )),
            ])
            self.__ring_dict["grip_motor"] = HexShmRingBuffer(
                capacity=self.__state_buffer_size,
                dtype=grip_state_dtype,
            )

        # cmd pipe
        self.__pipe_dict["arm_cmd"] = mp.Pipe()
        self.__pipe_dict["grip_cmd"] = mp.Pipe()

    def init_robot(self):
        # open device
        self.__hex_api = HexDeviceApi(
            ws_url=f"ws://{self.__host}:{self.__port}",
            control_hz=self.__ctrl_rate,
        )

        # open arm
        while self.__hex_api.find_device_by_robot_type(27) is None:
            print("\033[33mArm not found\033[0m")
            time.sleep(1)
        self.__arm = self.__hex_api.find_device_by_robot_type(27)
        self.__arm.start()

        # try to open gripper
        if self.__dof_dict["grip"] > 0:
            self.__gripper = self.__hex_api.find_optional_device_by_id(1)
            if self.__gripper is None:
                print("\033[33mGripper not found\033[0m")

        self._init_event.set()

    def deinit_robot(self):
        main = mp.current_process().name == "MainProcess"
        if main and self.is_working():
            self.stop()

        if self.__arm is not None:
            self.__arm.stop()
            self.__arm = None
        if self.__hex_api is not None:
            self.__hex_api.close()
            self.__hex_api = None

        for key in self.__ring_dict.keys():
            if self.__ring_dict[key] is not None:
                self.__ring_dict[key].close()
                self.__ring_dict[key] = None

    def get_dofs(self) -> dict[str, int]:
        return self.__dof_dict

    def get_arm_motor(self, latest: bool = True) -> Optional[dict[str, Any]]:
        if self.__ring_dict["arm_motor"] is None:
            return None
        return self.__ring_dict["arm_motor"].read(latest=latest)

    def get_arm_end(self, latest: bool = True) -> Optional[dict[str, Any]]:
        if self.__ring_dict["arm_motor"] is None:
            return None
        arm_motor = self.__ring_dict["arm_motor"].read(latest=latest)
        if arm_motor is None:
            return None
        arm_pos, arm_quat = self.__dyn_util.forward_kinematics(
            arm_motor["pos"])[-1]
        return {
            "ts_ns": arm_motor["ts_ns"],
            "pos": arm_pos,
            "quat": arm_quat,
        }

    def get_grip_motor(self, latest: bool = True) -> Optional[dict[str, Any]]:
        if self.__ring_dict["grip_motor"] is None:
            return None
        return self.__ring_dict["grip_motor"].read(latest=latest)

    def set_arm_mit_cmd(self, cmd_dict: dict[str, Any]) -> None:
        self.__pipe_dict["arm_cmd"][1].send({
            "type":
            "mit",
            "ts_ns":
            cmd_dict.get("ts_ns", ns_now()),
            "q_tar":
            cmd_dict["q_tar"],
            "dq_tar":
            cmd_dict["dq_tar"],
            "tau":
            cmd_dict["tau"],
            "kp":
            cmd_dict["kp"],
            "kd":
            cmd_dict["kd"],
        })

    def set_arm_mit_comp_cmd(self, cmd_dict: dict[str, Any]) -> None:
        self.__pipe_dict["arm_cmd"][1].send({
            "type":
            "mit_comp",
            "ts_ns":
            cmd_dict.get("ts_ns", ns_now()),
            "q_tar":
            cmd_dict["q_tar"],
            "dq_tar":
            cmd_dict["dq_tar"],
            "tau":
            cmd_dict["tau"],
            "kp":
            cmd_dict["kp"],
            "kd":
            cmd_dict["kd"],
        })

    def set_arm_pos_cmd(self, cmd_dict: dict[str, Any]) -> None:
        self.__pipe_dict["arm_cmd"][1].send({
            "type":
            "pos",
            "ts_ns":
            cmd_dict.get("ts_ns", ns_now()),
            "q_tar":
            cmd_dict["q_tar"],
            "kp":
            cmd_dict.get("kp",
                         np.array([400.0, 400.0, 500.0, 200.0, 100.0, 100.0])),
            "kd":
            cmd_dict.get("kd", np.array([5.0, 5.0, 5.0, 5.0, 2.0, 2.0])),
            "err_limit":
            cmd_dict.get("err_limit", 0.03),
        })

    def set_arm_pose_cmd(self, cmd_dict: dict[str, Any]) -> None:
        self.__pipe_dict["arm_cmd"][1].send({
            "type":
            "pose",
            "ts_ns":
            cmd_dict.get("ts_ns", ns_now()),
            "pos":
            cmd_dict["pos"],
            "quat":
            cmd_dict.get("quat", np.array([1.0, 0.0, 0.0, 0.0])),
            "kp":
            cmd_dict.get("kp",
                         np.array([400.0, 400.0, 500.0, 200.0, 100.0, 100.0])),
            "kd":
            cmd_dict.get("kd", np.array([5.0, 5.0, 5.0, 5.0, 2.0, 2.0])),
            "err_limit":
            cmd_dict.get("err_limit", 0.03),
        })

    def set_grip_mit_cmd(self, cmd_dict: dict[str, Any]) -> None:
        self.__pipe_dict["grip_cmd"][1].send({
            "type":
            "mit",
            "ts_ns":
            cmd_dict.get("ts_ns", ns_now()),
            "q_tar":
            cmd_dict["q_tar"],
            "dq_tar":
            cmd_dict["dq_tar"],
            "tau":
            cmd_dict["tau"],
            "kp":
            cmd_dict["kp"],
            "kd":
            cmd_dict["kd"],
        })

    def set_grip_mit_comp_cmd(self, cmd_dict: dict[str, Any]) -> None:
        self.__pipe_dict["grip_cmd"][1].send({
            "type":
            "mit_comp",
            "ts_ns":
            cmd_dict.get("ts_ns", ns_now()),
            "q_tar":
            cmd_dict["q_tar"],
            "dq_tar":
            cmd_dict["dq_tar"],
            "tau":
            cmd_dict["tau"],
            "kp":
            cmd_dict["kp"],
            "kd":
            cmd_dict["kd"],
        })

    def set_grip_pos_cmd(self, cmd_dict: dict[str, Any]) -> None:
        self.__pipe_dict["grip_cmd"][1].send({
            "type":
            "pos",
            "ts_ns":
            cmd_dict.get("ts_ns", ns_now()),
            "q_tar":
            cmd_dict["q_tar"],
            "kp":
            cmd_dict.get("kp", np.array([10.0])),
            "kd":
            cmd_dict.get("kd", np.array([0.5])),
            "err_limit":
            cmd_dict.get("err_limit", 0.01),
        })

    def work_loop(self) -> None:
        rate = HexRate(2 * self.__ctrl_rate)
        while not self.stop_event.is_set():
            rate.sleep()
            self.__state_func()
            self.__cmd_func()

    def __state_func(self) -> None:
        self.__arm_state_func()
        if self.__gripper is not None and self.__dof_dict["grip"] > 0:
            self.__grip_state_func()

    def __arm_state_func(self) -> None:
        arm_state = self.__arm.get_simple_motor_status()
        if arm_state is None:
            return

        ts_ns = hex_ts_to_ns(arm_state["ts"]) if self.__sens_ts else ns_now()
        self.__ring_dict["arm_motor"].write({
            "ts_ns": ts_ns,
            "pos": arm_state["pos"],
            "vel": arm_state["vel"],
            "eff": arm_state["eff"],
        })

        self.__cur_state["arm"] = {
            "pos": arm_state["pos"],
            "vel": arm_state["vel"],
            "tau_comp": self.__cal_arm_comp(arm_state["pos"],
                                            arm_state["vel"]),
        }

    def __grip_state_func(self) -> None:
        grip_state = self.__gripper.get_simple_motor_status()
        if grip_state is None:
            return

        ts_ns = hex_ts_to_ns(grip_state["ts"]) if self.__sens_ts else ns_now()
        self.__ring_dict["grip_motor"].write({
            "ts_ns": ts_ns,
            "pos": grip_state["pos"],
            "vel": grip_state["vel"],
            "eff": grip_state["eff"],
        })

        self.__cur_state["grip"] = {
            "pos": grip_state["pos"],
            "vel": grip_state["vel"],
            "tau_comp": self.__cal_grip_comp(grip_state["vel"]),
        }

    def __cmd_func(self) -> None:
        while self.__pipe_dict["arm_cmd"][0].poll():
            self.__cur_cmd["arm_cmd"] = self.__pipe_dict["arm_cmd"][0].recv()
        self.__arm_cmd_func()
        while self.__pipe_dict["grip_cmd"][0].poll():
            self.__cur_cmd["grip_cmd"] = self.__pipe_dict["grip_cmd"][0].recv()
            if self.__gripper is not None and self.__dof_dict["grip"] > 0:
                self.__grip_cmd_func()

    def __arm_cmd_func(self) -> None:
        if self.__cur_cmd["arm_cmd"] is None:
            return

        if self.__cur_cmd["arm_cmd"]["ts_ns"] is None or self.__cur_cmd[
                "arm_cmd"]["ts_ns"] <= self.__last_cmd_ts["arm_cmd"]:
            return

        self.__last_cmd_ts["arm_cmd"] = self.__cur_cmd["arm_cmd"]["ts_ns"]
        cur_pos = self.__cur_state["arm"]["pos"]

        if self.__cur_cmd["arm_cmd"]["type"] == "mit":
            arm_cmd = self.__arm.construct_mit_command(
                self.__cur_cmd["arm_cmd"]["q_tar"],
                self.__cur_cmd["arm_cmd"]["dq_tar"],
                self.__cur_cmd["arm_cmd"]["tau"],
                self.__cur_cmd["arm_cmd"]["kp"],
                self.__cur_cmd["arm_cmd"]["kd"],
            )
            self.__arm.motor_command(CommandType.MIT, arm_cmd)
            return
        elif self.__cur_cmd["arm_cmd"]["type"] == "mit_comp":
            arm_cmd = self.__arm.construct_mit_command(
                self.__cur_cmd["arm_cmd"]["q_tar"],
                self.__cur_cmd["arm_cmd"]["dq_tar"],
                self.__cur_cmd["arm_cmd"]["tau"] +
                self.__cur_state["arm"]["tau_comp"],
                self.__cur_cmd["arm_cmd"]["kp"],
                self.__cur_cmd["arm_cmd"]["kd"],
            )
            self.__arm.motor_command(CommandType.MIT, arm_cmd)
            return
        elif self.__cur_cmd["arm_cmd"]["type"] == "pos":
            tar_pos = interp_joint(
                cur_pos,
                self.__cur_cmd["arm_cmd"]["q_tar"],
                err_limit=self.__cur_cmd["arm_cmd"]["err_limit"],
            )
            arm_cmd = self.__arm.construct_mit_command(
                tar_pos,
                np.zeros(6),
                self.__cur_state["arm"]["tau_comp"],
                self.__cur_cmd["arm_cmd"]["kp"],
                self.__cur_cmd["arm_cmd"]["kd"],
            )
            self.__arm.motor_command(CommandType.MIT, arm_cmd)
            return
        elif self.__cur_cmd["arm_cmd"]["type"] == "pose":
            tar_pos = self.__cur_cmd["arm_cmd"]["pos"]
            tar_quat = self.__cur_cmd["arm_cmd"]["quat"]
            success, tar_pos = self.__dyn_util.inverse_kinematics_analytic(
                (tar_pos, tar_quat),
                cur_pos,
            )
            if not success:
                print("Inverse kinematics failed")
                return
            tar_pos = interp_joint(
                cur_pos,
                tar_pos,
                err_limit=self.__cur_cmd["arm_cmd"]["err_limit"],
            )
            arm_cmd = self.__arm.construct_mit_command(
                tar_pos,
                np.zeros(6),
                self.__cur_state["arm"]["tau_comp"],
                self.__cur_cmd["arm_cmd"]["kp"],
                self.__cur_cmd["arm_cmd"]["kd"],
            )
            self.__arm.motor_command(CommandType.MIT, arm_cmd)
            return
        else:
            raise ValueError(
                f"Unknown arm command type: {self.__cur_cmd['arm_cmd']['type']}"
            )

    def __grip_cmd_func(self) -> None:
        if self.__cur_cmd["grip_cmd"] is None:
            return

        if self.__cur_cmd["grip_cmd"]["ts_ns"] is None or self.__cur_cmd[
                "grip_cmd"]["ts_ns"] <= self.__last_cmd_ts["grip_cmd"]:
            return

        self.__last_cmd_ts["grip_cmd"] = self.__cur_cmd["grip_cmd"]["ts_ns"]
        cur_pos = self.__cur_state["grip"]["pos"]

        if self.__cur_cmd["grip_cmd"]["type"] == "mit":
            grip_cmd = self.__gripper.construct_mit_command(
                self.__cur_cmd["grip_cmd"]["q_tar"],
                self.__cur_cmd["grip_cmd"]["dq_tar"],
                self.__cur_cmd["grip_cmd"]["tau"],
                self.__cur_cmd["grip_cmd"]["kp"],
                self.__cur_cmd["grip_cmd"]["kd"],
            )
            self.__gripper.motor_command(CommandType.MIT, grip_cmd)
            return
        elif self.__cur_cmd["grip_cmd"]["type"] == "mit_comp":
            grip_cmd = self.__gripper.construct_mit_command(
                self.__cur_cmd["grip_cmd"]["q_tar"],
                self.__cur_cmd["grip_cmd"]["dq_tar"],
                self.__cur_cmd["grip_cmd"]["tau"] +
                self.__cur_state["grip"]["tau_comp"],
                self.__cur_cmd["grip_cmd"]["kp"],
                self.__cur_cmd["grip_cmd"]["kd"],
            )
            self.__gripper.motor_command(CommandType.MIT, grip_cmd)
            return
        elif self.__cur_cmd["grip_cmd"]["type"] == "pos":
            tar_pos = interp_joint(
                cur_pos,
                self.__cur_cmd["grip_cmd"]["q_tar"],
                err_limit=self.__cur_cmd["grip_cmd"]["err_limit"],
            )
            grip_cmd = self.__gripper.construct_mit_command(
                tar_pos,
                np.zeros(self.__dof_dict["grip"]),
                self.__cur_state["grip"]["tau_comp"],
                self.__cur_cmd["grip_cmd"]["kp"],
                self.__cur_cmd["grip_cmd"]["kd"],
            )
            self.__gripper.motor_command(CommandType.MIT, grip_cmd)
            return
        else:
            raise ValueError(
                f"Unknown grip command type: {self.__cur_cmd['grip_cmd']['type']}"
            )

    def __cal_arm_comp(self, cur_q, cur_dq):
        tau_comp = self.__dyn_util.compensation(cur_q, cur_dq)
        tau_comp += self.__arm_fric_util(cur_dq)
        return tau_comp

    def __cal_grip_comp(self, cur_dq):
        tau_comp = self.__grip_fric_util(cur_dq)
        return tau_comp
