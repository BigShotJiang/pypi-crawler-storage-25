from __future__ import annotations

import dataclasses
import logging
import os
import pathlib
import sys
import time
import typing
from pathlib import Path

import pytest
import msgpack

from dagz.pytest.fixture_ids import FixtureMan
from dagz.pytest.worker import extract_short_error, Worker, get_test_slug
from dagz.sensor.o3 import SpanType, SpanResult
from dagz.sensor.o3_binding import CoverageMode


if typing.TYPE_CHECKING:
    from .test_session import TestSession


logger = logging.getLogger('dagz.vassal')

IGNORE_FILE_NAMES = {'.dagz', '__pycache__', '.pytest_cache', '.git'}


@dataclasses.dataclass(slots=True)
class CollectNode:
    parent: CollectNode | None
    ignore_subtree: bool = False
    children: dict[str, CollectNode] = dataclasses.field(default_factory=dict)
    selectors: list[str] = dataclasses.field(default_factory=list)
    ignores: list[str] = dataclasses.field(default_factory=list)

    def ensure_child(self, name):
        child = self.children.get(name)
        if child is None:
            child = CollectNode(parent=self)
            self.children[name] = child
        return child

    def collect_roots(self, new_args):
        for child in self.children.values():
            if child.selectors:
                new_args += child.selectors
            elif child.ignores:
                pass
                # Ignored subtrees are handled at runtime by should_ignore.
                # Partially-ignored subtrees (ignore_subtree=False) require a parent dir selector.
            else:
                child.collect_roots(new_args)


class CollectionFixer:
    def __init__(self, early_config, cli_args):
        early_args = early_config.known_args_namespace
        self.tree = CollectNode(parent=None)
        self.root_path = os.getcwd()
        self.selectors = {}
        for arg in early_args.file_or_dir:
            path = Path(arg.partition('::')[0])
            if not path.exists():
                logger.warning(f'Collect input does not exist: {path}')
                continue
            if path.is_absolute():
                rel_path = path.relative_to(self.root_path)
            else:
                rel_path = path
            cur_node = self.tree
            for part in rel_path.parts:
                cur_node = cur_node.ensure_child(part)
            cur_node.selectors.append(arg)
            self.selectors[path] = cur_node

        for arg in early_args.ignore or []:
            path = Path(arg.partition('::')[0])
            if not path.exists():
                logger.warning(f'Ignored collect input does not exist: {path}')
                continue
            if path.is_absolute():
                rel_path = path.relative_to(self.root_path)
            else:
                rel_path = path
            cur_node = self.tree
            for part in rel_path.parts:
                cur_node = cur_node.ensure_child(part)
            cur_node.ignores.append(arg)
            cur_node.ignore_subtree = True
            self.selectors[path] = cur_node

        for node in self.selectors.values():
            if node.selectors:
                parent = node.parent
                while parent is not None:
                    parent.ignore_subtree = False
                    parent = parent.parent

        new_selectors = []
        self.tree.collect_roots(new_selectors)

        # Rewrite the cli args in place: strip old selectors and ignores, append new selectors
        orig_selectors = set(early_args.file_or_dir)
        new_args = []
        i = 0
        while i < len(cli_args):
            arg = cli_args[i]
            if arg.startswith("--ignore="):
                pass
            elif arg == "--ignore":
                i += 1
            elif arg not in orig_selectors:
                new_args.append(arg)
            i += 1
        for selector in new_selectors:
            new_args.append(selector)
        cli_args[:] = new_args

        early_args.file_or_dir = new_selectors
        early_args.ignore = []

        logger.info('Collection fixup: selectors=%s args=%s', early_args.file_or_dir, cli_args)

    def should_ignore(self, path):
        rel_path = path.relative_to(self.root_path)
        cur_node = self.tree
        last_selector_node = cur_node
        for seg in rel_path.parts:
            cur_node = cur_node.children.get(seg)
            if not cur_node:
                # Unspecified path - use closest effective selector
                return bool(last_selector_node.ignores)
            if cur_node.selectors or cur_node.ignores:
                last_selector_node = cur_node

        # Selected/ignored path
        return last_selector_node.ignore_subtree


class Vassal:
    def __init__(self, test_session: TestSession):
        self.test_session = test_session
        self.o3 = test_session.o3
        self.testgen_deps = set()
        self.items_by_name = {}
        self.worker = None
        self.selected_test_files = set()
        self.load_errors = []
        self.apply_load_filter = False
        self.failed_collect_reports = []
        self.deselected_ids: list[str] = []
        self.fixer = test_session.collect_fixer
        self.fixture_man = None

        # Connect sys.stdin to /dev/null - tests (and sub-processes) should not block reading from stdin.
        devnull_fd = os.open(os.devnull, os.O_RDONLY)
        os.dup2(devnull_fd, 0)
        os.close(devnull_fd)

    def pytest_sessionstart(self, session):
        self.session = session
        self.fixture_man = FixtureMan(session.config)

    @pytest.hookimpl(hookwrapper=True)
    def pytest_generate_tests(self, metafunc):
        nodeid = metafunc.definition.nodeid
        span = self.o3.start_span(SpanType.TEST_GEN, nodeid, coverage=CoverageMode.PROVISIONAL.value)
        try:
            yield
            if span.result == SpanResult.NOT_SET:
                span.result = SpanResult.OK
        except Exception:
            span.result = SpanResult.ERROR
            raise
        finally:
            if not span.is_coverage_empty():
                self.testgen_deps.add(nodeid)
            self.o3.finish_span(None)

    def _handle_collect_errors(self):
        collect_reports = msgpack.packb(self.failed_collect_reports, use_bin_type=True)
        self.o3.finish_collect(deselected=self.deselected_ids, errors=self.load_errors, collect_reports=collect_reports)

    @pytest.hookimpl(hookwrapper=True)
    def pytest_collection(self, session):
        _ = session
        self.o3.finish_span(SpanResult.OK)  # Finish the "load" span

        with self.test_session.span(SpanType.PROGRAM_LOAD, 'py.test.collect', coverage=CoverageMode.NAMED) as span:
            # Ensure required integrations were configured in the user's conftest.py
            try:
                self.apply_load_filter, selected_paths = self.o3.get_collect_filter()
                self.selected_test_files = set(selected_paths)
                logger.debug(f'selected_test_files (apply={self.apply_load_filter}): %s', self.selected_test_files)
            except Exception as exc:
                self.load_errors.append('py.test.collect: ' + str(exc))
                self._handle_collect_errors()
                pytest.exit(f'Dagz cannot start collection: {exc}', 2)

            # Defensive: handle both pluggy hook styles. New-style hookwrappers
            # (pluggy >=1.0) deliver inner exceptions via `outcome.excinfo` and
            # `yield` returns normally; old-style wrappers re-raise through
            # `yield`. We trap both so a fatal collection error always reaches
            # `_handle_collect_errors()` regardless of pluggy version.
            try:
                outcome = yield
            except BaseException as exc:
                logger.error(f'Collection fatal error: {exc}')
                self.load_errors.append('Collection fatal error: ' + str(exc))
                self._handle_collect_errors()
                raise
            if outcome.excinfo is not None:
                _, exc, _ = outcome.excinfo
                self.load_errors.append('Collection fatal error: ' + str(exc))

            if self.load_errors:
                self._handle_collect_errors()
                span.result = SpanResult.ERROR
            else:
                # collection ok.
                for item in self.session.items:
                    self.items_by_name[item.nodeid] = item

                if self.o3.is_master_node:
                    test_infos = []
                    for item in self.session.items:
                        fixture_ids = self.fixture_man.extract_fixture_ids(item)
                        test_infos.append((item, fixture_ids))
                    self.o3.finish_collect(test_infos=test_infos, deselected=self.deselected_ids)
                span.result = SpanResult.OK

    def pytest_collectreport(self, report):
        if report.failed:
            if self.session.config.option.continue_on_collection_errors:
                logger.info("ignoring collect error in %s: %s", report.nodeid, report.outcome)
            else:
                self.load_errors.append(extract_short_error(report.longrepr))
                logger.error("collect error in %s: %s", report.nodeid, report.longrepr)
                # Serialize the report for propagation to master
                config = self.session.config
                serialized = config.hook.pytest_report_to_serializable(config=config, report=report)
                self.failed_collect_reports.append(serialized)

    def pytest_deselected(self, items):
        for item in items:
            self.deselected_ids.append(item.nodeid)

    def pytest_ignore_collect(self, collection_path: pathlib.Path, config):
        if collection_path.name in IGNORE_FILE_NAMES:
            return True

        if self.fixer:
            if self.fixer.should_ignore(collection_path):
                return True

        if self.apply_load_filter:
            if str(collection_path) in self.selected_test_files:
                logger.debug(f'Not excluding collect path {collection_path}')
                return False
            else:
                logger.debug(f'Excluding collect path {collection_path}')
                return True

        # No decision
        return None

    def init_worker(self, worker_num):
        pluginmanager = self.test_session.pluginmanager
        pluginmanager.set_blocked('runner')

        with self.test_session.span(SpanType.PROGRAM_LOAD, f'init_worker', coverage=CoverageMode.NAMED):
            self.worker = Worker(self, worker_num)
            pluginmanager.register(self.worker, 'dagz_worker')

    def close_worker(self):
        if self.worker:
            self.session._setupstate.teardown_exact(None)
            pluginmanager = self.session.config.pluginmanager
            pluginmanager.unregister(self.worker)
            self.worker = None

    def start_worker_task(self, task):
        item = self.items_by_name[task.name]
        return get_test_slug(item)

    def run_worker_task(self, task, next_task_name, span):
        return self.worker.handle_task(task, next_task_name, span)

    def finish_worker_batch(self):
        self.worker.finish_batch()

    def pytest_runtestloop(self, session):
        _ = session
        with self.test_session.span('py.test.loop', 'py.test.loop'):
            try:
                self.o3.run()
            except Exception as exc:
                logger.exception(f"Error running test session: {exc}")
                raise

        return True

    def pytest_sessionfinish(self, session):
        # get_exit_status calls process::exit on the Rust side and never returns.
        # os._exit is here so Python's control flow analysis knows this is a no-return path.
        os._exit(self.o3.get_exit_status())

    def pytest_collection_finish(self, session):
        # Flush stdout before spawning workers
        sys.stdout.flush()
        sys.stderr.flush()
        # let the pty logger capture and log
        time.sleep(0.1)
