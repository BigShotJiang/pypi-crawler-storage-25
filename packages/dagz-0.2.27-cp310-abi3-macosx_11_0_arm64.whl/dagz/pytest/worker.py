import asyncio
import logging
import os
import io
import types
import traceback
import typing
import threading

import msgpack

import _pytest.runner
import _pytest.tmpdir
import _pytest._io
import _pytest.outcomes
import _pytest._code.code
import _pytest.fixtures
import pytest

from dagz.sensor.errors import DagzError

DAGZ_NODE_MUTEX = 'dagz_node_mutex'
DAGZ_MAIN_WORKER = 'dagz_main_worker'

try:
    import pytest_asyncio._version  # type: ignore[import-not-found]
    asyncio_version = getattr(pytest_asyncio._version, '__version_tuple__', None)
    if not asyncio_version:
        asyncio_version = getattr(pytest_asyncio._version, 'version_tuple')

    OLD_ASYNCIO = asyncio_version < (0, 22)
except ImportError:
    OLD_ASYNCIO = False

from dagz.pytest.hacks import set_thread_pools_size
from dagz.pytest.fixture_ids import FixtureMan
from dagz.sensor.o3 import SpanResult, SpanType
from dagz.sensor.o3_binding import CoverageMode

GOOD_SPAN_RESULTS = (SpanResult.OK, SpanResult.SKIPPED_IN_CODE, SpanResult.XFAIL, SpanResult.XPASS, SpanResult.OK_FLAKY)

logger = logging.getLogger('dagz.worker')

if typing.TYPE_CHECKING:
    from dagz.pytest.vassal import Vassal

FIXTURE_SCOPE_MAP = {
    'function': 0x10,
    'class': 0x11,
    'module': 0x12,
    'package': 0x13,
    'session': 0x14,
}


def get_test_slug(item):
    slug = item.nodeid.partition('::')[2]
    params_pos = slug.find('[')
    if params_pos >= 0:
        slug = slug[:params_pos] + '*'
    return slug


def _log_makereport_crash(item, call, report_exc):
    """Log detailed diagnostics when pytest_runtest_makereport crashes.

    Dumps everything about the original exception (the one makereport was trying
    to format) so we can diagnose traceback corruption (e.g. tb_lineno=None).
    """
    lines = [
        f'makereport crashed for {item.nodeid} (when={call.when}): {report_exc!r}',
        f'  makereport exception type: {type(report_exc).__name__}',
    ]

    # Log the makereport crash traceback itself
    lines.append('  makereport crash traceback:')
    for line in traceback.format_exception(type(report_exc), report_exc, report_exc.__traceback__):
        lines.append('    ' + line.rstrip())

    excinfo = getattr(call, 'excinfo', None)
    if excinfo is None:
        lines.append('  call.excinfo is None — no original exception')
    else:
        lines.append(f'  call.excinfo type: {type(excinfo).__name__}')
        try:
            orig_exc = excinfo.value
            orig_tb = excinfo.tb  # the raw traceback
            lines.append(f'  original exception type: {type(orig_exc).__name__}')
            lines.append(f'  original exception: {orig_exc!r:.500}')
            lines.append(f'  original exc __traceback__ type: {type(getattr(orig_exc, "__traceback__", None)).__name__}')

            # Walk the traceback chain and dump every frame's details
            tb = getattr(orig_exc, '__traceback__', None) or orig_tb
            frame_idx = 0
            while tb is not None:
                is_real_tb = isinstance(tb, types.TracebackType)
                lines.append(f'  tb frame [{frame_idx}]:')
                lines.append(f'    type(tb)={type(tb).__name__} is_TracebackType={is_real_tb}')
                try:
                    lineno = tb.tb_lineno
                    lines.append(f'    tb_lineno={lineno!r} type={type(lineno).__name__}')
                except Exception as e:
                    lines.append(f'    tb_lineno access failed: {e!r}')
                try:
                    frame = tb.tb_frame
                    lines.append(f'    type(tb_frame)={type(frame).__name__}')
                    lines.append(f'    co_filename={frame.f_code.co_filename}')
                    lines.append(f'    co_name={frame.f_code.co_name}')
                    lines.append(f'    f_lineno={frame.f_lineno!r}')
                except Exception as e:
                    lines.append(f'    tb_frame access failed: {e!r}')
                try:
                    lines.append(f'    tb_lasti={tb.tb_lasti!r}')
                except Exception as e:
                    lines.append(f'    tb_lasti access failed: {e!r}')
                try:
                    tb = tb.tb_next
                except Exception as e:
                    lines.append(f'    tb_next access failed: {e!r}')
                    break
                frame_idx += 1

            # Also dump the formatted traceback if possible
            try:
                orig_tb_obj = getattr(orig_exc, '__traceback__', None)
                if orig_tb_obj is not None:
                    lines.append('  original traceback (formatted):')
                    for line in traceback.format_exception(type(orig_exc), orig_exc, orig_tb_obj):
                        lines.append('    ' + line.rstrip())
            except Exception as fmt_exc:
                lines.append(f'  failed to format original traceback: {fmt_exc!r}')

            # Check for chained exceptions
            cause = getattr(orig_exc, '__cause__', None)
            context = getattr(orig_exc, '__context__', None)
            if cause is not None:
                lines.append(f'  __cause__: {type(cause).__name__}: {cause!r:.300}')
            if context is not None and context is not cause:
                lines.append(f'  __context__: {type(context).__name__}: {context!r:.300}')

        except Exception as diag_exc:
            lines.append(f'  diagnostics failed: {diag_exc!r}')

    logger.error('\n'.join(lines))


RESULT_MAP = {
    'passed': SpanResult.OK,
    'skipped': SpanResult.SKIPPED_IN_CODE,
    'failed': SpanResult.FAILED,
    'error': SpanResult.ERROR,
    'xfailed': SpanResult.XFAIL,
    'xpassed': SpanResult.XPASS,
}

def report_to_span_result(session, report):
    outcome = session.config.hook.pytest_report_teststatus(report=report, config=session.config)[0] or report.outcome
    return RESULT_MAP.get(outcome, SpanResult.INTERNAL_ERROR)


def get_pretty_report(report):
    report_buf = io.StringIO()
    terminal_writer = _pytest._io.TerminalWriter(file=report_buf)
    terminal_writer.hasmarkup = True  # colorize output
    terminal_writer.code_highlight = True  # highlight code
    report.toterminal(terminal_writer)
    return report_buf.getvalue().strip()


def _first_line(s: str) -> str:
    # A literal `\n` escape inside a single-line crash message means a repr()'d
    # multiline string got inlined (e.g. `assert X in '<huge log dump>'`).
    # Split there so the dumped value doesn't drown out the assertion itself.
    line, _, _ = s.partition('\n')
    line, _, _ = line.partition('\\n')
    return line


def extract_short_error(longrepr) -> str:
    try:
        if isinstance(longrepr, _pytest._code.code.ExceptionRepr):
            # ExceptionChainRepr / ReprExceptionInfo — both carry reprcrash.
            # Walk the last (most-recently-raised) chain entry first, taking its
            # deepest frame, so the file:line points at the actual raise site
            # rather than the outermost pytest hook (e.g. dagz worker.py:509).
            loc = None
            if isinstance(longrepr, _pytest._code.code.ExceptionChainRepr):
                for exc_info_repr in reversed(longrepr.chain):
                    for frame in exc_info_repr[0].reprentries:
                        if isinstance(frame, _pytest._code.code.ReprEntry) and frame.reprfileloc:
                            loc = frame.reprfileloc
                    if loc is None and isinstance(exc_info_repr[1], _pytest._code.code.ReprFileLocation):
                        loc = exc_info_repr[1]
                    if loc:
                        break
            short_msg = _first_line(longrepr.reprcrash.message) if longrepr.reprcrash else ''
            error = f'{loc.path}:{loc.lineno} ' if loc else ''
            if loc and loc.message and not short_msg.startswith(loc.message):
                error += f'{loc.message}: '
            return error + short_msg

        if isinstance(longrepr, _pytest.fixtures.FixtureLookupErrorRepr):
            # firstlineno is 0-based; pytest renders firstlineno+1.
            first = _first_line(longrepr.errorstring).strip()
            argname = longrepr.argname
            return f'{longrepr.filename}:{longrepr.firstlineno + 1} fixture {argname!r}: {first}'

        if isinstance(longrepr, str):
            # From our makereport crash fallback in pytest_runtest_makereport
            return longrepr

        # Any other TerminalRepr — render via its toterminal() and trim.
        return _first_line(str(longrepr))
    except Exception as exc:
        logger.error(f'Error extracting error from report longrepr: {exc}')
        return str(exc)

class TeardownItem:
    def __init__(self, item):
        # Never teardown the item's session
        listchain = item.listchain()
        if listchain:
            if isinstance(listchain[0], pytest.Session):
                #logger.debug(f'forcing fixtures teardown up to session-level')
                listchain = listchain[:1]
            else:
                logger.error(f'item listchain[0] unexpected type: {type(listchain[0])}')
                listchain = []
        else:
            logger.error(f'item listchain is empty!')

        self._listchain = listchain

    def listchain(self):
        return self._listchain


class MockMpCounter:
    """Mimics multiprocessing.Value for init_worker compatibility."""

    def __init__(self, value):
        self.value = value
        self._lock = threading.Lock()

    def get_lock(self):
        return self._lock


class Worker:
    def __init__(self, vassal: 'Vassal', worker_num: int):
        self.worker_num = worker_num
        self.vassal = vassal
        is_main = (worker_num % vassal.test_session.o3.workers_per_node) == 0
        vassal.test_session.set_worker_num(worker_num, is_main)

        self.session = vassal.test_session
        self.last_item = None
        self.next_item = None
        self.current_test = None
        self.current_test_markers = None
        self.force_test_error = None
        if self.session.config.threaded_workers:
            logger.debug('Threaded workers: collector thread already started')
            # asyncio doesn't automatically create an event loop when running in non-main thread.
            # We need to create one explicitly.
            asyncio.set_event_loop(asyncio.new_event_loop())

        set_thread_pools_size(self.session.config.thread_pools_size)

        pytest_config = vassal.session.config

        # Like pytest-xdist, set a separate basetemp for each worker
        pytest_config.option.basetemp = f'/tmp/pytest_dagz_jw{worker_num:02}'
        _pytest.tmpdir.pytest_configure(pytest_config)

        # Expose worker ID like pytest-xdist so plugins (e.g. pytest-django) can isolate resources per worker
        pytest_config.workerinput = {"workerid": f"dagz{worker_num}"}

        # Call the project's test runner init_worker to isolate per-worker resources
        # (Redis cache DBs, Cassandra keyspaces, etc.) — same as Django's manage.py test --parallel.
        try:
            from django.test.utils import get_runner  # type: ignore[import-not-found]
            from django.conf import settings as django_settings  # type: ignore[import-not-found]
        except ImportError:
            django_settings = None

        if django_settings is not None and os.environ.get('DJANGO_SETTINGS_MODULE'):
            TestRunner = get_runner(django_settings)
            # Django's base init_worker increments counter.value, so pass worker_num - 1
            TestRunner.parallel_test_suite.init_worker(MockMpCounter(worker_num - 1))
            logger.info(f'Worker {worker_num}: called test runner init_worker')

        # Run project-registered worker init callbacks
        from dagz.sensor.callbacks import _worker_init_callbacks
        for cb in _worker_init_callbacks:
            cb(worker_num)

        # Install test hooks - intercept sys.exit and the like
        if not self.session.config.disable_sensors:
            from dagz.sensor.install import install_worker_hooks
            install_worker_hooks(self.session)
        self.session.worker = self

    def finish_batch(self):
        if self.last_item:
            end_item = TeardownItem(self.last_item)
            self.vassal.session._setupstate.teardown_exact(end_item)
            self.last_item = None

    # Worker callback
    def handle_task(self, task, next_task_name, span):
        session = self.vassal.session
        config = session.config
        if self.next_item and self.next_item.nodeid != task.name and self.last_item:
            # Work items were stolen, teardown last item
            end_item = TeardownItem(self.last_item)
            session._setupstate.teardown_exact(end_item)

        item = self.vassal.items_by_name[task.name]
        item.dagz_span = span
        nextitem = self.vassal.items_by_name[next_task_name] if next_task_name else None

        item.dagz_task = task

        # Allow hook wrappers in runtest_protocol()
        config.hook.pytest_runtest_protocol(item=item, nextitem=nextitem)
        self.current_test = None

        # Test Epilogue
        if session.shouldfail:
            raise session.Failed(session.shouldfail)
        if session.shouldstop:
            raise session.Interrupted(session.shouldstop)

        return item.dagz_payload

    # JetBrains teamcity hook is installed after ours.
    # trylast ensures we let it do its thing, otherwise its other hooks break.
    # We disable pytest's internal "runner" plugin so it won't override our hook.
    @pytest.hookimpl(trylast=True)
    def pytest_runtest_protocol(self, item, nextitem):
        span = item.dagz_span
        self.last_item = item
        self.next_item = nextitem

        self.current_test = item
        self.current_test_markers = set(mark.name for mark in item.iter_markers())
        self.force_test_error = False

        if self.session.port_manager:
            self.session.port_manager.reset()

        try:
            fixture_ids = self.vassal.fixture_man.extract_fixture_ids(item)
            if fixture_ids:
                span.add_called_spans(SpanType.FIXTURE, [(id, FIXTURE_SCOPE_MAP[fixture.scope]) for id, fixture in fixture_ids.items()])

            base_id = item.nodeid.rpartition('[')[0]
            if base_id in self.vassal.testgen_deps:
                span.add_called_spans(
                    SpanType.TEST_GEN, [(base_id, 0)])

        except Exception as exc:
            logger.critical(f'Error collecting test fixtures: {item.nodeid} {exc}')

        # Flow copied from _pytest.runner.runtestprotocol, teardown is optional
        # reports = _pytest.runner.runtestprotocol(item, nextitem=nextitem, log=False)

        hasrequest = hasattr(item, "_request")
        if hasrequest and not item._request:  # type: ignore[attr-defined]
            # This only happens if the item is re-run, as is done by
            # pytest-rerunfailures.
            item._initrequest()  # type: ignore[attr-defined]

        max_attempts = getattr(item.function, '_flaky_max_runs', item.dagz_task.max_attempts)
        attempt = 1
        while True:
            for prerun in self.session.test_prerun:
                prerun()
            setup_report = _pytest.runner.call_and_report(item, "setup", False)
            setup_result = report_to_span_result(self.vassal.session, setup_report)
            if setup_result in GOOD_SPAN_RESULTS:
                if attempt > 1:
                    logger.warning(f'Test passed after {attempt-1} failures! FLAKY! result={setup_result}')
                    setup_result = SpanResult.OK_FLAKY
                break
            elif attempt >= max_attempts:
                break

            attempt += 1
            logger.warning(f'Test setup failed: status={setup_result}, retrying {attempt}/{max_attempts}, '
                           f'report: {get_pretty_report(setup_report)}')

            temp_report = _pytest.runner.call_and_report(item, "teardown", False, nextitem=item)
            if temp_report.failed:
                teardown_report = get_pretty_report(temp_report)
                logger.error(f'Retrying: teardown failed during setup retry: {temp_report.outcome}: {teardown_report}')

        reports = [setup_report]
        if item.config.getoption("setuponly", False) or not setup_report.passed:
            span.result = setup_result
        else:
            attempt = 1
            while True:
                with self.session.span(SpanType.TEST_CALL, item.nodeid, slug=get_test_slug(item)) as call_span:
                    call_report = _pytest.runner.call_and_report(item, "call", False)
                    call_result = report_to_span_result(self.vassal.session, call_report)
                    call_span.result = span.result = call_result

                    if call_result in GOOD_SPAN_RESULTS:
                        if attempt > 1 or item.dagz_task.attempt > 1:
                            logger.info(f'Test {item.nodeid} passed after {attempt-1}, task_attempt={item.dagz_task.attempt} failures! FLAKY! result={call_result}')
                            span.result = SpanResult.OK_FLAKY
                        elif call_result == SpanResult.OK and setup_result == SpanResult.OK_FLAKY:
                            # If the test passed but setup was flaky, we still consider it flaky
                            span.result = SpanResult.OK_FLAKY
                        break
                    elif attempt >= max_attempts:
                        break

                    # Retry failed test
                    attempt += 1
                    logger.warning(f'Test {item.nodeid} failed: status={call_result}, retrying attempt {attempt}/{max_attempts}'
                                   f'\nreport: {get_pretty_report(call_report)}')

                # nextitem=item.parent stops teardown_exact at class scope,
                # tearing down only function-scope finalizers.
                temp_report = _pytest.runner.call_and_report(
                    item, "teardown", False, nextitem=item.parent,  # type: ignore[arg-type]
                )
                if temp_report.failed:
                    logger.error(f'Retrying teardown failed: {temp_report.outcome}')

                # _fillfixtures skips argnames already in funcargs; clear for fresh fixtures.
                if hasrequest:
                    item._request = False  # type: ignore[attr-defined]
                    item.funcargs = None  # type: ignore[attr-defined]
                    item._initrequest()  # type: ignore[attr-defined]

                temp_report = _pytest.runner.call_and_report(item, "setup", False, nextitem=item)
                if temp_report.failed:
                    logger.error(f'Retrying setup failed: {temp_report.outcome}')
                    break

            reports.append(call_report)

        # Logic taken from _pytest.runner.call_and_report
        reraise = (_pytest.outcomes.Exit,)
        if not item.config.getoption("usepdb", False):
            reraise += (KeyboardInterrupt,)
        call = _pytest.runner.CallInfo.from_call(
            lambda: item.ihook.pytest_runtest_teardown(item=item, nextitem=nextitem),
            when='teardown', reraise=reraise
        )

        teardown_report = item.ihook.pytest_runtest_makereport(item=item, call=call)
        if not teardown_report.passed:
            span.result = report_to_span_result(self.vassal.session, teardown_report)

        reports.append(teardown_report)

        # After all teardown hooks have been called
        # want funcargs and request info to go away.
        if hasrequest:
            item._request = False  # type: ignore[attr-defined]
            item.funcargs = None  # type: ignore[attr-defined]

        config = self.vassal.session.config
        level = logging.INFO if span.result in GOOD_SPAN_RESULTS else logging.ERROR
        logged_report = False
        failed = span.result in (SpanResult.FAILED, SpanResult.ERROR)
        for report in reports:
            if failed or report.failed:
                report_str = get_pretty_report(report)
                if report_str:
                    error = ''
                    if failed:
                        error = extract_short_error(report.longrepr)
                        span.set_error(error)

                    if error:
                        error = f'\n Error: {error}'
                    logger.log(level, f'pytest report for {report.when}, outcome={report.outcome} {error}\n' + report_str)
                    logged_report = True

        if span.result not in GOOD_SPAN_RESULTS and not logged_report:
            logger.error("No pytest report for failed test: {}", reports)

        if not failed and self.force_test_error:
            logger.error(f'Critical error swallowed: {self.force_test_error}')
            span.set_error(f'Critical error swallowed: {self.force_test_error}')

        if self.session.o3.forward_pytest_reports:
            reports_json = [config.hook.pytest_report_to_serializable(config=config, report=report) for report in reports]
            finish_data = {
                'nodeid': item.nodeid,
                'location': item.location,
                'reports': reports_json,
            }
            item.dagz_payload = msgpack.packb(finish_data, use_bin_type=True)
        else:
            item.dagz_payload = b''
        return True

    @pytest.hookimpl(trylast=True)
    def pytest_runtest_setup(self, item):
        # let other hooks run before us (esp pytest_asyncio - will setup the event loop)
        # Note: running with trylast=True breaks pytest 7 nose plugin, which is deprecated anyway.
        _pytest.runner.pytest_runtest_setup(item)

    @staticmethod
    def pytest_runtest_makereport(item, call):
        try:
            return _pytest.runner.pytest_runtest_makereport(item, call)
        except Exception as report_exc:
            # Log everything we can about the original exception that makereport
            # failed to format — this helps diagnose traceback corruption (e.g.
            # tb_lineno becoming None under parallelism).
            try:
                _log_makereport_crash(item, call, report_exc)
            except Exception as diag_exc:
                logger.error(f'makereport crashed for {item.nodeid} and diagnostics also failed: {report_exc!r} / {diag_exc!r}')
            try:
                reprcrash = _pytest._code.code.ReprFileLocation(
                    path="<dagz>", lineno=0, message=f"makereport crashed: {report_exc}",
                )
                reprtraceback = _pytest._code.code.ReprTraceback(
                    reprentries=[], extraline=None, style="short",
                )
                longrepr = _pytest._code.code.ExceptionChainRepr(
                    chain=[(reprtraceback, reprcrash, None)],
                )
            except Exception:
                longrepr = f"dagz: makereport crashed: {report_exc}"
            from _pytest.reports import TestReport
            return TestReport(
                nodeid=item.nodeid,
                location=item.location,
                keywords={k: 1 for k in item.keywords},
                outcome="failed",
                when=call.when,
                longrepr=longrepr,
                duration=call.duration,
            )

    def pytest_runtest_call(self, item):
        return _pytest.runner.pytest_runtest_call(item)

    @pytest.hookimpl(hookwrapper=True)
    def pytest_fixture_setup(self, fixturedef, request):
        fixture_id = self.vassal.fixture_man.get_fixture_id(fixturedef, request.param_index)
        if fixture_id is None:
            # external, uninteresting fixture
            yield
            return

        with self.session.span(SpanType.FIXTURE, fixture_id, coverage=CoverageMode.NAMED,
                               fixture_scope=FIXTURE_SCOPE_MAP[fixturedef.scope]):
            yield

    @staticmethod
    def pytest_report_teststatus(report):
        return _pytest.runner.pytest_report_teststatus(report)

    @pytest.hookimpl(tryfirst=True)
    def pytest_runtest_teardown(self, item, nextitem):
        # Copied from _pytest.runner.pytest_runtest_teardown
        _pytest.runner._update_current_test_var(item, "teardown")
        if nextitem is None:
            nextitem = TeardownItem(item)

        item.session._setupstate.teardown_exact(nextitem)
        _pytest.runner._update_current_test_var(item, None)

        return True

    def assert_mark(self, mark_name, flow_name):
        if not self.current_test:
            error = DagzError(f"Pytest mark '{mark_name}' required outside of test, flow: {flow_name}")
            logger.error(str(error))
            raise error

        if mark_name not in self.current_test_markers:
            error = DagzError(f"Pytest mark '{mark_name}' required but not set on test, flow: {flow_name}")
            logger.error(str(error))
            self.force_test_error = error
            raise error

    def assert_node_mutex(self, flow_name):
        self.assert_mark(DAGZ_NODE_MUTEX, flow_name)

    def assert_main_worker(self, flow_name):
        self.assert_mark(DAGZ_MAIN_WORKER, flow_name)

    def is_mark_active(self, mark_name):
        return self.current_test and mark_name in self.current_test_markers

    def is_in_node_mutex(self):
        return self.is_mark_active(DAGZ_NODE_MUTEX)

    def is_in_main_worker(self):
        return self.is_mark_active(DAGZ_MAIN_WORKER)
