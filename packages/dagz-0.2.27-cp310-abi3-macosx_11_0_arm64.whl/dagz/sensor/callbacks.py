_worker_init_callbacks = []


def add_worker_init(callback):
    """Register a callback to run during dagz worker initialization.

    The callback receives the worker number (int) as its only argument.
    Use this to configure per-worker resources (e.g. Redis DB, cache backends).

    Example usage in conftest.py::

        from dagz.sensor.callbacks import add_worker_init
        add_worker_init(my_init_function)
    """
    _worker_init_callbacks.append(callback)
