"""dagz CLI entry point — lightweight access to DAGZ features without running tests."""

import argparse
import os


def cmd_select(args):
    """Preview test selection: load baselines, run dirty propagation, print report."""
    if args.project_dir != '.':
        os.chdir(args.project_dir)
    import dagz.sensor.o3_binding  # noqa: F401
    from dagz.sensor.o3 import select_tests
    select_tests(workers=args.workers, trace=args.trace)


def cmd_git_replay(args):
    from dagz.cli.git_replay import cmd_git_replay as _run
    return _run(args)


def main():
    parser = argparse.ArgumentParser(prog='dagz')
    sub = parser.add_subparsers(dest='command')

    sel = sub.add_parser('select-tests', help='Preview test selection')
    sel.add_argument('--project-dir', '-d', default='.', help='Project directory (default: .)')
    sel.add_argument('-j', '--workers', type=int, default=None, help='Number of workers for plan estimation')
    sel.add_argument('--collect', action='store_true', help='Run pytest collection for full per-test report')
    sel.add_argument('--trace', action='store_true', help='Print the selection trace for each selected test')
    sel.add_argument('--debug', action='store_true', help='Enable debug logging')
    sel.set_defaults(func=cmd_select)

    replay = sub.add_parser('git-replay',
        help='Replay pytest across recent commits to build baselines',
        description='Replay pytest with --dagz across recent first-parent commits. '
                    'Useful for bootstrapping DAGZ baselines on an existing project.\n\n'
                    'WARNING: This runs "git reset --hard" on each commit and will '
                    'discard uncommitted changes. Stash or commit your work first.')
    replay.add_argument('--branch', default='origin/master',
        help='Branch to walk commits from (default: origin/master)')
    replay.add_argument('-n', '--num-commits', type=int, default=20,
        help='Number of commits to replay (default: 20)')
    replay.add_argument('--merges-only', action='store_true',
        help='Restrict the walk to merge commits (legacy behavior; useful only on repos that still merge PRs as merge commits)')
    replay.add_argument('--run', action='store_true',
        help='Actually run pytest on each commit (default is dry-run)')
    replay.add_argument('--patch-file',
        help='Git patch file to apply before each run')
    replay.add_argument('--allow-patch-failure', action='store_true',
        help='Skip commits where the patch fails instead of aborting')
    replay.add_argument('--pytest-args', action='append', default=[],
        help='Additional pytest arguments as a shell-quoted string, tokenized with shlex '
             '(e.g. --pytest-args \'-m "not db" --dagz-workers=4\'). '
             'May be passed multiple times; values accumulate.')
    replay.add_argument('--prerun',
        help='Script to execute before pytest when Python files changed')
    replay.add_argument('--skip-redundant', '--exclude-redundant',
        action='store_true', dest='skip_redundant',
        help='Pass --dagz-skip-redundant=1 to pytest')
    replay.set_defaults(func=cmd_git_replay)

    args = parser.parse_args()
    if not hasattr(args, 'func'):
        parser.print_help()
        return 1
    return args.func(args)
