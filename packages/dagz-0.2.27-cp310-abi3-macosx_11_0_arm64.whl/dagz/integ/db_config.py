import abc
import contextlib
import contextvars
import dataclasses
import inspect
import typing
import logging
import threading

from urllib.parse import urlparse

from dagz.sensor.app_session import AppSession
from dagz.sensor.base_session import BaseSession

logger = logging.getLogger(__name__)


@dataclasses.dataclass(frozen=True, slots=True)
class TruncateResult:
    db_exists: bool
    tables: list[str]


# Baggage namespace for cross-process DbConfig state.
_BAGGAGE_BYPASS_PREFIX = 'dagz.db_bypass.'


class DbConfig(abc.ABC):
    def __init__(self, module_name: str) -> None:
        self.module_name = module_name
        self.name = module_name.rpartition('.')[-1]
        self.main_worker_bypass = True
        self._current_inited: typing.Set[str] = set()
        self._lock = threading.RLock()
        self._rewrite_db_name_func = None
        self._session = None
        self._should_reroute_func = None
        self._prepare_func = None
        self._worker_init_func = None
        self._worker_inited = False
        self._bypass_flag = contextvars.ContextVar(f'{self.name}_bypass', default=False)

    @contextlib.contextmanager
    def bypass(self):
        """Temporarily disable connection routing for direct access."""
        token = self._bypass_flag.set(True)
        try:
            yield
        finally:
            self._bypass_flag.reset(token)

    @property
    def is_bypassed(self) -> bool:
        return self._bypass_flag.get()

    @abc.abstractmethod
    def unhook(self) -> None:
        pass

    @abc.abstractmethod
    def default_should_reroute(self, db_name):
        ...

    @abc.abstractmethod
    def truncate(self, db_name, **connect_kwargs) -> TruncateResult:
        """Truncate all tables in the given DB.
        Returns TruncateResult with db_exists and list of truncated table names.
        """
        ...

    def configure_app(self, session: AppSession):
        self._rewrite_db_name_func = self.default_rewrite_db_name
        self._should_reroute_func = self.default_should_reroute
        self._session = session

        # Inherit parent's main_worker_bypass; without this a subprocess of the
        # main pytest worker would default to bypass=True and skip DB rerouting.
        if (val := session.baggage.get(_BAGGAGE_BYPASS_PREFIX + self.name)) is not None:
            self.main_worker_bypass = val.lower() == 'true'

    def configure(self, *, rewrite_db_name, should_reroute, prepare,
                  single_worker_disable=False, worker_init=None,
                  main_worker_bypass=False):
        import dagz.pytest
        if not dagz.pytest.is_enabled():
            return

        from dagz.sensor.base_session import BaseSession

        def auto_init_db():
            self._current_inited.clear()

        assert rewrite_db_name
        sig = inspect.signature(rewrite_db_name)
        params = [p for p in sig.parameters.values() if p.default is inspect.Parameter.empty]
        if len(params) != 2 or [p.name for p in params] != ['db_name', 'session']:
            raise TypeError(
                f"rewrite_db_name must accept (db_name, session), got: {sig}"
            )

        BaseSession.instance.test_prerun.append(auto_init_db)

        self._session = BaseSession.instance
        if single_worker_disable and self._session.workers_per_node == 1:
            self.unhook()

        self._rewrite_db_name_func = rewrite_db_name
        self._should_reroute_func = should_reroute
        self._prepare_func = prepare
        self.main_worker_bypass = main_worker_bypass
        self._worker_init_func = worker_init
        self._session.baggage[_BAGGAGE_BYPASS_PREFIX + self.name] = (
            'true' if main_worker_bypass else 'false'
        )

    @property
    def is_configured(self) -> bool:
        return bool(self._session)

    def check_configured(self):
        if not self.is_configured:
            raise RuntimeError(
                "Connection attempted in multi-worker dagz without configuration. "
                f"Call {self.module_name}.configure() in conftest.py."
            )

    def default_rewrite_db_name(self, db_name: str, session: BaseSession):
        if not self._should_reroute_func(db_name):
            return db_name

        if session.worker_suffix:
            if not db_name.endswith(session.worker_suffix):
                db_name += session.worker_suffix
        else:
            logger.warning(f'Accessing {self.module_name} DB during import: {db_name}')

        return db_name

    def get_manual_init_db_name(self, db_name: str):
        if not self.should_reroute(db_name):
            logger.debug(f'manual init, no reroute: {db_name}')
            return db_name

        db_name = self._rewrite_db_name_func(db_name, self._session)

        self._current_inited.add(db_name)
        logger.info(f'Database `{db_name}` [{self.name}] inited manually')
        return db_name

    def get_manual_init_db_url(self, db_url: str):
        parsed = urlparse(db_url)
        db_name = parsed.path.strip('/')
        if not self.should_reroute(db_name):
            return db_url

        db_name = self._rewrite_db_name_func(db_name, self._session)

        self._current_inited.add(db_name)
        db_url = parsed._replace(path='/' + db_name).geturl()
        logger.info(f'Database `{db_name}` [{self.name}] inited manually with URL {db_url}')
        return db_url

    def should_reroute(self, db_name):
        if self.is_bypassed:
            return False
        self.check_configured()
        if self.main_worker_bypass and self._session.is_main_worker:
            return False
        return self._should_reroute_func(db_name)

    def reroute_db(self, db_name) -> typing.Any:
        db_name = self._rewrite_db_name_func(db_name, self._session)
        self._prepare_db(db_name)
        return db_name

    def maybe_reroute(self, db_name):
        """Return the rerouted DB name if this config wants to reroute it,
        otherwise return the original name unchanged. Convenience for client
        driver hooks that just need to rewrite a kwarg in place."""
        if self.should_reroute(db_name):
            return self.reroute_db(db_name)
        return db_name

    def maybe_reroute_uri(self, db_url):
        """Same as maybe_reroute, for a connection URI string. Parses the
        URI, rewrites the path component (the DB name), and reassembles."""
        parsed = urlparse(db_url)
        db_name = parsed.path.lstrip('/')
        if not self.should_reroute(db_name):
            return db_url
        rerouted = self.reroute_db(db_name)
        return parsed._replace(path='/' + rerouted).geturl()

    def _prepare_db(self, db_name):
        with self._lock:
            if self._worker_init_func and not self._worker_inited:
                self._worker_inited = True
                self._worker_init_func(self._session.worker_num)

            if db_name not in self._current_inited:
                logger.info(f'Calling init worker for {self.name}')
                self._current_inited.add(db_name)
                if self._prepare_func:
                    self._prepare_func(db_name)

    def prepare_db(self, db_name):
        if self.should_reroute(db_name):
            db_name = self._rewrite_db_name_func(db_name, self._session)
        self._prepare_db(db_name)
