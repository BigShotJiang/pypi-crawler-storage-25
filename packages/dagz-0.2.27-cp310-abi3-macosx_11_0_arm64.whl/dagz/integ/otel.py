import logging

from opentelemetry import trace
from opentelemetry.sdk.trace import SpanProcessor, TracerProvider
from opentelemetry.trace import StatusCode

from dagz.sensor.o3 import SpanResult

logger = logging.getLogger('dagz.otel')

_configured = False


def configure_otel(*, dd: bool, start_provider=True, auto_instrument=True, instrument_logging=False):
    """Configure OpenTelemetry integration with DAGZ.

    Args:
        dd: Required if ddtrace is installed. Must be explicitly False (True not yet supported).
        start_provider: Create and set a TracerProvider.
        auto_instrument: Auto-instrument via opentelemetry's auto_instrumentation.initialize().
        instrument_logging: Whether to let OTel instrument the logging module.
    """
    global _configured

    import dagz.pytest
    if not dagz.pytest.is_enabled():
        return

    # Validate dd parameter when ddtrace is importable
    try:
        import ddtrace  # type: ignore[import-not-found]  # noqa: F401
        if dd is True:
            raise ValueError("dagz.otel.configure(dd=True) is not yet supported.")
    except ImportError:
        pass

    if start_provider:
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry import trace
        trace.set_tracer_provider(TracerProvider())
        logger.info("Installed TracerProvider")

    # Register DagzSpanProcessor
    from dagz.sensor.install import _unhooks
    _unhooks.append(hook_otel())

    if auto_instrument:
        if not instrument_logging:
            import os
            disabled = os.environ.get("OTEL_PYTHON_DISABLED_INSTRUMENTATIONS", "")
            if "logging" not in disabled:
                os.environ["OTEL_PYTHON_DISABLED_INSTRUMENTATIONS"] = \
                    f"{disabled},logging" if disabled else "logging"

        import opentelemetry.instrumentation.auto_instrumentation  # type: ignore[import-not-found]
        opentelemetry.instrumentation.auto_instrumentation.initialize()
        logger.info("Auto-instrumented via OTel")

    _configured = True
    logger.info("dagz.otel configured")


def ensure_configured():
    """Guard to ensure OTel is configured before use."""
    if not _configured:
        raise RuntimeError(
            "OTel integration not configured. Call dagz.otel.configure() in conftest.py."
        )


class DagzSpanProcessor(SpanProcessor):
    def __init__(self, o3):
        self._o3 = o3

    @staticmethod
    def _scope_short_name(span):
        name = span.instrumentation_scope.name
        prefix = "opentelemetry.instrumentation."
        if name.startswith(prefix):
            return name[len(prefix):]
        return name

    @staticmethod
    def _short_name(name):
        # Pipelines concatenate commands: "EXPIRE EXPIRE EXPIRE" → "EXPIRE"
        if ' ' in name:
            return name.split(' ', 1)[0]
        if '.' in name:
            return name.rsplit('.', 1)[1]
        return name

    def _build_otel_type(self, span):
        """Build enriched type from OTel span attributes available at on_end."""
        scope = self._scope_short_name(span)
        attrs = span.attributes or {}
        # Prefer db.operation, then first word of db.statement if it starts with a letter
        op = attrs.get('db.operation')
        if not op:
            stmt = attrs.get('db.statement', '')
            if stmt:
                first_word = stmt.split(None, 1)[0]
                if first_word and first_word[0].isalpha():
                    op = first_word
        if not op and span.name:
            op = self._short_name(span.name)
        if op:
            return f"{scope}.{op}"
        return scope

    def on_start(self, span, parent_context=None):
        scope = self._scope_short_name(span)
        self._o3.start_span(scope, '', sub_span=True)

    def on_end(self, span):
        # log span if it took a long time
        otel_type = self._build_otel_type(span)
        self._o3.set_current_span_attrib('otel_type', otel_type)
        result = SpanResult.ERROR if span.status.status_code == StatusCode.ERROR else SpanResult.OK

        elapsed = (span.end_time - span.start_time) / 1e9  # Convert from ns to seconds
        if elapsed > 0.1:
            logger.debug(f"OTel span ended: name={span.name}, scope={self._scope_short_name(span)}, "
                         f"duration={elapsed:.3f}s, "
                         f"status={span.status.status_code} otel_type={otel_type}")

        self._o3.finish_span(result)

    def shutdown(self):
        pass

    def force_flush(self, timeout_millis=None):
        pass


def _register_processor(provider, o3):
    processor = DagzSpanProcessor(o3)
    provider.add_span_processor(processor)
    logger.info("Registered DagzSpanProcessor on TracerProvider")
    return processor


def hook_otel():
    from dagz.sensor.base_session import BaseSession
    o3 = BaseSession.instance.o3

    # If a TracerProvider is already set up, register immediately
    current_provider = trace.get_tracer_provider()
    if isinstance(current_provider, TracerProvider):
        _register_processor(current_provider, o3)

    # Patch set_tracer_provider to catch future provider setup
    orig_set_tracer_provider = trace.set_tracer_provider

    def patched_set_tracer_provider(provider):
        orig_set_tracer_provider(provider)
        if isinstance(provider, TracerProvider):
            _register_processor(provider, o3)

    trace.set_tracer_provider = patched_set_tracer_provider
    logger.debug("Patched trace.set_tracer_provider for OTel interception")

    def unhook():
        trace.set_tracer_provider = orig_set_tracer_provider

    return unhook
