"""Shared test fixtures for keenetic-mcp."""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

import keenetic_mcp.server as server


@pytest.fixture(autouse=True)
def reset_config():
    """Reset server config between tests."""
    server.configure(safe_mode=None)
    yield
    server.configure(safe_mode=None)


class MockKeeneticClient:
    """Fake KeeneticClient that never touches the network."""

    def __init__(self) -> None:
        self.rci = AsyncMock(return_value={})
        self.rci_get = AsyncMock(return_value={})

    async def __aenter__(self):
        return self

    async def __aexit__(self, *_):
        pass


@pytest.fixture
def mock_client(monkeypatch):
    """Patch _get_client() to return a MockKeeneticClient."""
    client = MockKeeneticClient()
    monkeypatch.setattr(server, "_get_client", lambda: client)
    return client


@pytest.fixture
def safe_env(monkeypatch):
    """Set required env vars so _get_client() doesn't raise."""
    monkeypatch.setenv("KEENETIC_HOST", "192.168.1.1")
    monkeypatch.setenv("KEENETIC_USER", "admin")
    monkeypatch.setenv("KEENETIC_PASS", "s3cret")
