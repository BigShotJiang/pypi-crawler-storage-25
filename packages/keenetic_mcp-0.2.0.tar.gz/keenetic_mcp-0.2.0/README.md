# keenetic-mcp

[![CI](https://github.com/Patr56/keenetic-mcp/actions/workflows/ci.yml/badge.svg)](https://github.com/Patr56/keenetic-mcp/actions/workflows/ci.yml)
[![PyPI](https://img.shields.io/pypi/v/keenetic-mcp)](https://pypi.org/project/keenetic-mcp/)
[![Python](https://img.shields.io/pypi/pyversions/keenetic-mcp)](https://pypi.org/project/keenetic-mcp/)

MCP-сервер для роутеров **Keenetic** — управляй интерфейсами, смотри подключённых клиентов, маршруты и текущую скорость через Claude или любой MCP-совместимый клиент.

> Протестировано на прошивке **5.01.B.0.0-2** (Keenetic Ultra KN-1811). Более ранние версии ветки 4.x и выше должны работать — API RCI стабилен начиная с KeeneticOS 3.x.

## Инструменты

### Система

| Инструмент | Описание |
|---|---|
| `get_system_info` | Модель, версия прошивки, аптайм, использование памяти |

### Интерфейсы

| Инструмент | Описание |
|---|---|
| `get_interfaces` | Все сетевые интерфейсы — состояние, IP, MTU |
| `get_interface` | Детальная информация по одному интерфейсу |

### Клиенты и трафик

| Инструмент | Описание |
|---|---|
| `get_connected_clients` | Все устройства в сети — MAC, IP, hostname, трафик |
| `get_wifi_associations` | Wi-Fi клиенты с уровнем сигнала (RSSI/SNR) |
| `get_speed` | Текущая скорость download/upload по всем клиентам |

### Маршрутизация и WAN

| Инструмент | Описание |
|---|---|
| `get_routes` | Таблица маршрутов |
| `get_wan_status` | Состояние интернет-подключения |

### DNS-маршрутизация

| Инструмент | Описание |
|---|---|
| `get_domain_lists` | Все списки доменных имён — название, ключ, количество записей |
| `get_domain_list` | Все записи (домены/IP) в конкретном списке |
| `create_domain_list` | Создать новый список доменных имён |
| `delete_domain_list` | Удалить список доменных имён |
| `set_domain_list` | Заменить все записи в списке (полная перезапись) |
| `add_domains` | Добавить домены/IP в список (дубли игнорируются) |
| `remove_domains` | Удалить конкретные домены/IP из списка |
| `get_dns_routes` | Все правила DNS-маршрутизации (список → интерфейс) |
| `add_dns_route` | Добавить правило DNS-маршрутизации |
| `delete_dns_route` | Удалить правило по его index-хэшу |

### Управление (safe mode)

| Инструмент | Описание |
|---|---|
| `set_interface_state` | Поднять или опустить интерфейс |
| `reboot` | Перезагрузить роутер |

## Установка

```bash
pip install keenetic-mcp
```

## Настройка

### Переменные окружения

| Переменная | Описание | По умолчанию |
|---|---|---|
| `KEENETIC_HOST` | IP или hostname роутера | обязательно |
| `KEENETIC_USER` | Логин | `admin` |
| `KEENETIC_PASS` | Пароль | обязательно |
| `KEENETIC_SAFE_MODE` | Запретить write-операции (`1`/`true`/`yes`) | `false` |

### Claude Code (CLI)

```bash
claude mcp add keenetic-mcp \
  -e KEENETIC_HOST=192.168.1.1 \
  -e KEENETIC_PASS=your_password \
  -- keenetic-mcp
```

### Claude Desktop

В `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "keenetic": {
      "command": "keenetic-mcp",
      "env": {
        "KEENETIC_HOST": "192.168.1.1",
        "KEENETIC_USER": "admin",
        "KEENETIC_PASS": "your_password"
      }
    }
  }
}
```

## Безопасный режим (Safe Mode)

Запусти с `--safe-mode` чтобы запретить `reboot` и `set_interface_state`:

```bash
keenetic-mcp --safe-mode
# или
KEENETIC_SAFE_MODE=true keenetic-mcp
```

Три уровня приоритета (выше = важнее):

```python
# Программно
from keenetic_mcp.server import configure, mcp
configure(safe_mode=True)
mcp.run()
```

## Примеры

После настройки можно спрашивать Claude:

> «Какие устройства сейчас подключены к роутеру?»
> «Какая скорость на роутере прямо сейчас?»
> «Покажи состояние всех интерфейсов»
> «Есть ли интернет? Через какой провайдер?»
> «Перезагрузи роутер»

## Лицензия

MIT
