# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import Literal

from .._models import BaseModel

__all__ = ["GoogleSearchCallStep", "Arguments"]


class Arguments(BaseModel):
    """Required. The arguments to pass to Google Search."""

    queries: Optional[List[str]] = None
    """Web search queries for the following-up web search."""


class GoogleSearchCallStep(BaseModel):
    """Google Search call step."""

    id: str
    """Required. A unique ID for this specific tool call."""

    arguments: Arguments
    """Required. The arguments to pass to Google Search."""

    type: Literal["google_search_call"]

    search_type: Optional[Literal["web_search", "image_search", "enterprise_web_search"]] = None
    """The type of search grounding enabled."""

    signature: Optional[str] = None
    """A signature hash for backend validation."""
