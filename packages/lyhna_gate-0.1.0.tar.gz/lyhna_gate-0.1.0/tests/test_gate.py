"""
lyhna-gate offline test suite — 24 tests, no live API calls.

All bind() calls go through _FakeClient. FastAPI TestClient is used
for sync tests; httpx.AsyncClient with ASGITransport for the concurrent test.
"""
from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Optional

import pytest
from fastapi import Depends, FastAPI, Request
from fastapi.testclient import TestClient

from lyhna import LyhnaAuthError, LyhnaError, LyhnaTimeoutError, Receipt
from lyhna_gate import lyhna_gate


# ---------------------------------------------------------------------------
# Test helpers
# ---------------------------------------------------------------------------

def _make_receipt(
    outcome: str = "APPROVED",
    outcome_reason: Optional[str] = None,
    escalate_to: Optional[str] = None,
    receipt_id: str = "lrv2_test_001",
) -> Receipt:
    raw = {
        "version": "LYHNA_RECEIPT_V2",
        "receipt_id": receipt_id,
        "outcome": outcome,
        "reason": outcome_reason,
        "escalate_to": escalate_to,
    }
    return Receipt(
        receipt_id=receipt_id,
        outcome=outcome,
        outcome_reason=outcome_reason,
        escalate_to=escalate_to,
        action_type="test_action",
        action_hash="a" * 64,
        authority_tier="tier_0",
        bound_at="2026-04-29T00:00:00Z",
        expires_at="2026-04-30T00:00:00Z",
        tenant_id="tenant_test",
        canonical_hash="b" * 64,
        signature="c" * 88,
        raw=raw,
    )


class _FakeClient:
    """Fake AsyncLyhnaClient — returns receipts from a list or raises a configured exception."""

    def __init__(self, receipts=None, raise_exc=None):
        self._receipts = list(receipts) if receipts else []
        self._raise = raise_exc
        self._idx = 0
        self.calls: list[dict] = []

    async def bind(self, **kwargs):
        self.calls.append(dict(kwargs))
        if self._raise is not None:
            raise self._raise
        if not self._receipts:
            raise RuntimeError("_FakeClient: no receipts configured")
        receipt = self._receipts[self._idx % len(self._receipts)]
        self._idx += 1
        return receipt


def _build(
    fake: _FakeClient,
    *,
    attach_to_state: str = "lyhna_receipt",
    payload_from=None,
) -> tuple:
    """Return (TestClient, handler_call_counter) for a minimal app using lyhna_gate."""
    if payload_from is None:
        payload_from = lambda _: {}

    calls = {"handler": 0}
    gate = lyhna_gate(
        action_type="test_action",
        intent="test_intent",
        intent_version="1.0",
        payload_from=payload_from,
        client=fake,
        attach_to_state=attach_to_state,
    )

    app = FastAPI()

    @app.post("/")
    async def route(request: Request, receipt=Depends(gate)):
        calls["handler"] += 1
        state_receipt = getattr(request.state, attach_to_state, None)
        return {
            "receipt_id": receipt.receipt_id,
            "state_receipt_id": state_receipt.receipt_id if state_receipt else None,
        }

    return TestClient(app, raise_server_exceptions=False), calls


# ---------------------------------------------------------------------------
# 1. Export check
# ---------------------------------------------------------------------------

def test_01_lyhna_gate_exported():
    from lyhna_gate import lyhna_gate as _lg
    assert callable(_lg)


# ---------------------------------------------------------------------------
# 2. Missing payload_from → TypeError
# ---------------------------------------------------------------------------

def test_02_missing_payload_from_raises_type_error():
    with pytest.raises(TypeError):
        lyhna_gate(action_type="t", intent="i", intent_version="1.0")  # type: ignore[call-arg]


# ---------------------------------------------------------------------------
# 3. Non-callable payload_from → TypeError
# ---------------------------------------------------------------------------

def test_03_non_callable_payload_from_raises_type_error():
    with pytest.raises(TypeError, match="payload_from must be callable"):
        lyhna_gate(
            action_type="t",
            intent="i",
            intent_version="1.0",
            payload_from="not_callable",  # type: ignore[arg-type]
        )


# ---------------------------------------------------------------------------
# 4–7. Forbidden kwargs → TypeError (Python natural behaviour)
# ---------------------------------------------------------------------------

def test_04_forbidden_kwarg_authority_tier():
    with pytest.raises(TypeError):
        lyhna_gate(  # type: ignore[call-arg]
            action_type="t", intent="i", intent_version="1.0",
            payload_from=lambda _: {}, authority_tier="tier_0",
        )


def test_05_forbidden_kwarg_fail_open():
    with pytest.raises(TypeError):
        lyhna_gate(  # type: ignore[call-arg]
            action_type="t", intent="i", intent_version="1.0",
            payload_from=lambda _: {}, fail_open=True,
        )


def test_06_forbidden_kwarg_base_url():
    with pytest.raises(TypeError):
        lyhna_gate(  # type: ignore[call-arg]
            action_type="t", intent="i", intent_version="1.0",
            payload_from=lambda _: {}, base_url="https://example.com",
        )


def test_07_forbidden_kwarg_api_key():
    with pytest.raises(TypeError):
        lyhna_gate(  # type: ignore[call-arg]
            action_type="t", intent="i", intent_version="1.0",
            payload_from=lambda _: {}, api_key="lyhna_test",
        )


# ---------------------------------------------------------------------------
# 8. APPROVED — bind called with exactly four kwargs
# ---------------------------------------------------------------------------

def test_08_approved_bind_called_with_four_kwargs():
    fake = _FakeClient(receipts=[_make_receipt()])
    client, _ = _build(fake, payload_from=lambda _: {"key": "value"})

    client.post("/")

    assert len(fake.calls) == 1
    call = fake.calls[0]
    assert set(call.keys()) == {"action_type", "action_payload", "intent", "intent_version"}
    assert call["action_type"] == "test_action"
    assert call["action_payload"] == {"key": "value"}
    assert call["intent"] == "test_intent"
    assert call["intent_version"] == "1.0"


# ---------------------------------------------------------------------------
# 9. APPROVED — receipt attached to request.state.lyhna_receipt
# ---------------------------------------------------------------------------

def test_09_approved_receipt_in_request_state():
    fake = _FakeClient(receipts=[_make_receipt(receipt_id="lrv2_state_check")])
    client, _ = _build(fake)

    response = client.post("/")

    assert response.status_code == 200
    assert response.json()["state_receipt_id"] == "lrv2_state_check"


# ---------------------------------------------------------------------------
# 10. APPROVED — route handler executes and returns its response
# ---------------------------------------------------------------------------

def test_10_approved_handler_executes():
    fake = _FakeClient(receipts=[_make_receipt(receipt_id="lrv2_ok")])
    client, calls = _build(fake)

    response = client.post("/")

    assert response.status_code == 200
    assert response.json()["receipt_id"] == "lrv2_ok"
    assert calls["handler"] == 1


# ---------------------------------------------------------------------------
# 11. REFUSED — HTTP 403; handler not called
# ---------------------------------------------------------------------------

def test_11_refused_returns_403_handler_not_called():
    fake = _FakeClient(receipts=[_make_receipt(outcome="REFUSED", outcome_reason="policy_block")])
    client, calls = _build(fake)

    response = client.post("/")

    assert response.status_code == 403
    assert calls["handler"] == 0


# ---------------------------------------------------------------------------
# 12. REFUSED — detail key is "reason", not "outcome_reason"
# ---------------------------------------------------------------------------

def test_12_refused_detail_key_is_reason():
    fake = _FakeClient(receipts=[_make_receipt(outcome="REFUSED", outcome_reason="policy_block")])
    client, _ = _build(fake)

    response = client.post("/")

    detail = response.json()["detail"]
    assert "reason" in detail
    assert "outcome_reason" not in detail
    assert detail["reason"] == "policy_block"


# ---------------------------------------------------------------------------
# 13. REFUSED — detail includes "receipt" with raw receipt dict
# ---------------------------------------------------------------------------

def test_13_refused_detail_includes_receipt():
    fake = _FakeClient(receipts=[_make_receipt(outcome="REFUSED", receipt_id="lrv2_refused_001")])
    client, _ = _build(fake)

    response = client.post("/")

    detail = response.json()["detail"]
    assert "receipt" in detail
    assert isinstance(detail["receipt"], dict)
    assert detail["receipt"]["receipt_id"] == "lrv2_refused_001"


# ---------------------------------------------------------------------------
# 14. ESCALATED — HTTP 202; handler not called
# ---------------------------------------------------------------------------

def test_14_escalated_returns_202_handler_not_called():
    fake = _FakeClient(receipts=[_make_receipt(
        outcome="ESCALATED",
        outcome_reason="needs_human_review",
        escalate_to="human_governor",
    )])
    client, calls = _build(fake)

    response = client.post("/")

    assert response.status_code == 202
    assert calls["handler"] == 0


# ---------------------------------------------------------------------------
# 15. ESCALATED — execution = "blocked_pending_authority"
# ---------------------------------------------------------------------------

def test_15_escalated_execution_field():
    fake = _FakeClient(receipts=[_make_receipt(outcome="ESCALATED", escalate_to="human_governor")])
    client, _ = _build(fake)

    response = client.post("/")

    assert response.json()["detail"]["execution"] == "blocked_pending_authority"


# ---------------------------------------------------------------------------
# 16. ESCALATED — detail includes "escalate_to"
# ---------------------------------------------------------------------------

def test_16_escalated_includes_escalate_to():
    fake = _FakeClient(receipts=[_make_receipt(
        outcome="ESCALATED", escalate_to="human_governor",
    )])
    client, _ = _build(fake)

    response = client.post("/")

    detail = response.json()["detail"]
    assert "escalate_to" in detail
    assert detail["escalate_to"] == "human_governor"


# ---------------------------------------------------------------------------
# 17. payload_from raising exception → HTTP 400 blocked_invalid_payload
# ---------------------------------------------------------------------------

def test_17_payload_from_exception_returns_400():
    fake = _FakeClient(receipts=[_make_receipt()])

    def _bad_payload(_):
        raise ValueError("bad payload content")

    gate = lyhna_gate(
        action_type="t", intent="i", intent_version="1.0",
        payload_from=_bad_payload, client=fake,
    )
    app = FastAPI()

    @app.post("/")
    async def route(receipt=Depends(gate)):
        return {"ok": True}  # pragma: no cover

    tc = TestClient(app, raise_server_exceptions=False)
    response = tc.post("/")

    assert response.status_code == 400
    assert response.json()["detail"]["execution"] == "blocked_invalid_payload"


# ---------------------------------------------------------------------------
# 18. LyhnaAuthError → 503; reason does NOT echo exception message
# ---------------------------------------------------------------------------

def test_18_auth_error_returns_503_no_leak():
    fake = _FakeClient(raise_exc=LyhnaAuthError("super secret key fragment"))
    client, _ = _build(fake)

    response = client.post("/")

    assert response.status_code == 503
    reason = response.json()["detail"]["reason"]
    assert "secret" not in reason
    assert "super" not in reason
    assert reason == "Lyhna authentication failed"


# ---------------------------------------------------------------------------
# 19. LyhnaTimeoutError → 503
# ---------------------------------------------------------------------------

def test_19_timeout_error_returns_503():
    fake = _FakeClient(raise_exc=LyhnaTimeoutError("connection timed out"))
    client, _ = _build(fake)

    response = client.post("/")

    assert response.status_code == 503
    assert response.json()["detail"]["reason"] == "Lyhna binding request timed out"


# ---------------------------------------------------------------------------
# 20. LyhnaError (base) → 503
# ---------------------------------------------------------------------------

def test_20_lyhna_base_error_returns_503():
    fake = _FakeClient(raise_exc=LyhnaError("some base error"))
    client, _ = _build(fake)

    response = client.post("/")

    assert response.status_code == 503
    assert response.json()["detail"]["reason"] == "Lyhna binding unavailable"


# ---------------------------------------------------------------------------
# 21. Unexpected exception (RuntimeError) → 503
# ---------------------------------------------------------------------------

def test_21_unexpected_exception_returns_503():
    fake = _FakeClient(raise_exc=RuntimeError("unexpected internal error"))
    client, _ = _build(fake)

    response = client.post("/")

    assert response.status_code == 503
    assert response.json()["detail"]["reason"] == "Lyhna binding unavailable"


# ---------------------------------------------------------------------------
# 22. Custom attach_to_state stores receipt under the specified key
# ---------------------------------------------------------------------------

def test_22_custom_attach_to_state():
    fake = _FakeClient(receipts=[_make_receipt(receipt_id="lrv2_custom")])

    gate = lyhna_gate(
        action_type="t", intent="i", intent_version="1.0",
        payload_from=lambda _: {},
        client=fake,
        attach_to_state="my_receipt",
    )
    app = FastAPI()

    @app.post("/")
    async def route(request: Request, receipt=Depends(gate)):
        custom = getattr(request.state, "my_receipt", None)
        default = getattr(request.state, "lyhna_receipt", None)
        return {
            "custom_id": custom.receipt_id if custom else None,
            "default_is_absent": default is None,
        }

    tc = TestClient(app, raise_server_exceptions=False)
    response = tc.post("/")

    assert response.status_code == 200
    data = response.json()
    assert data["custom_id"] == "lrv2_custom"
    assert data["default_is_absent"] is True


# ---------------------------------------------------------------------------
# 23. Concurrent requests — no cross-request leakage (async)
# ---------------------------------------------------------------------------

async def test_23_concurrent_requests_no_cross_bleed():
    import httpx

    class _ContextualFake:
        """Returns a receipt whose receipt_id encodes the request's req_id."""
        async def bind(self, **kwargs):
            req_id = kwargs["action_payload"].get("req_id", "unknown")
            await asyncio.sleep(0.01)  # yield to interleave with the other request
            return _make_receipt(receipt_id=f"lrv2_{req_id}")

    fake = _ContextualFake()

    async def _async_payload(request: Request):
        return await request.json()

    gate = lyhna_gate(
        action_type="concurrent_test",
        intent="test",
        intent_version="1.0",
        payload_from=_async_payload,
        client=fake,
    )
    app = FastAPI()

    @app.post("/")
    async def route(receipt=Depends(gate)):
        return {"receipt_id": receipt.receipt_id}

    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
        r1, r2 = await asyncio.gather(
            c.post("/", json={"req_id": "alpha"}),
            c.post("/", json={"req_id": "beta"}),
        )

    assert r1.status_code == 200
    assert r2.status_code == 200
    d1, d2 = r1.json(), r2.json()
    assert d1["receipt_id"] == "lrv2_alpha"
    assert d2["receipt_id"] == "lrv2_beta"
    assert d1["receipt_id"] != d2["receipt_id"]


# ---------------------------------------------------------------------------
# 24. Runtime source check — no httpx or requests imported in adapter
# ---------------------------------------------------------------------------

def test_24_no_raw_http_imports_in_adapter_source():
    gate_dir = Path(__file__).parent.parent / "lyhna_gate"
    source = "\n".join(
        p.read_text(encoding="utf-8") for p in sorted(gate_dir.glob("*.py"))
    )
    assert "import httpx" not in source, "httpx imported directly in lyhna_gate — violation"
    assert "import requests" not in source, "requests imported directly in lyhna_gate — violation"
