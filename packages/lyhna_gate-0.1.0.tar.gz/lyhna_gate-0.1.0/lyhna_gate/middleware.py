from __future__ import annotations

import inspect
from typing import Any, Callable, Optional

from fastapi import HTTPException, Request

from lyhna import AsyncLyhnaClient, LyhnaAuthError, LyhnaError, LyhnaTimeoutError


def lyhna_gate(
    *,
    action_type: str,
    intent: str,
    intent_version: str,
    payload_from: Callable,
    client: Optional[Any] = None,
    attach_to_state: str = "lyhna_receipt",
) -> Callable:
    """Return a FastAPI dependency that enforces the Lyhna authority boundary.

    Use with FastAPI's Depends():

        @app.post("/action")
        async def handler(receipt=Depends(lyhna_gate(
            action_type="deploy_service",
            intent="release_v3",
            intent_version="1.0",
            payload_from=extract_payload,
        ))):
            ...

    On APPROVED the Receipt is attached to request.state.<attach_to_state>
    and returned from the dependency. On REFUSED or ESCALATED an HTTPException
    is raised and the route handler is not called.
    """
    if not callable(payload_from):
        raise TypeError(
            "[lyhna-gate] payload_from must be callable, "
            f"got {type(payload_from).__name__!r}"
        )

    # Lazily constructed on first request; cached in closure for reuse.
    _cached_client: list[Any] = []

    async def _dependency(request: Request) -> Any:
        if client is not None:
            _client = client
        elif _cached_client:
            _client = _cached_client[0]
        else:
            _cached_client.append(AsyncLyhnaClient())
            _client = _cached_client[0]

        # --- payload extraction -------------------------------------------
        try:
            if inspect.iscoroutinefunction(payload_from):
                payload = await payload_from(request)
            else:
                payload = payload_from(request)
        except Exception as exc:
            raise HTTPException(
                status_code=400,
                detail={
                    "execution": "blocked_invalid_payload",
                    "outcome": "REFUSED",
                    "reason": str(exc) or "Invalid payload",
                    "receipt": None,
                },
            ) from exc

        # --- bind call -------------------------------------------------------
        try:
            receipt = await _client.bind(
                action_type=action_type,
                action_payload=payload,
                intent=intent,
                intent_version=intent_version,
            )
        except LyhnaAuthError:
            raise HTTPException(
                status_code=503,
                detail={
                    "execution": "blocked_binding_unavailable",
                    "outcome": "REFUSED",
                    "reason": "Lyhna authentication failed",
                    "receipt": None,
                },
            )
        except LyhnaTimeoutError:
            raise HTTPException(
                status_code=503,
                detail={
                    "execution": "blocked_binding_unavailable",
                    "outcome": "REFUSED",
                    "reason": "Lyhna binding request timed out",
                    "receipt": None,
                },
            )
        except LyhnaError:
            raise HTTPException(
                status_code=503,
                detail={
                    "execution": "blocked_binding_unavailable",
                    "outcome": "REFUSED",
                    "reason": "Lyhna binding unavailable",
                    "receipt": None,
                },
            )
        except Exception:
            raise HTTPException(
                status_code=503,
                detail={
                    "execution": "blocked_binding_unavailable",
                    "outcome": "REFUSED",
                    "reason": "Lyhna binding unavailable",
                    "receipt": None,
                },
            )

        # --- outcome routing -------------------------------------------------
        if receipt.outcome == "APPROVED":
            setattr(request.state, attach_to_state, receipt)
            return receipt

        if receipt.outcome == "REFUSED":
            setattr(request.state, attach_to_state, receipt)
            raise HTTPException(
                status_code=403,
                detail={
                    "execution": "blocked",
                    "outcome": "REFUSED",
                    "reason": receipt.outcome_reason,
                    "receipt": receipt.raw,
                },
            )

        if receipt.outcome == "ESCALATED":
            setattr(request.state, attach_to_state, receipt)
            raise HTTPException(
                status_code=202,
                detail={
                    "execution": "blocked_pending_authority",
                    "outcome": "ESCALATED",
                    "reason": receipt.outcome_reason,
                    "escalate_to": receipt.escalate_to,
                    "receipt": receipt.raw,
                },
            )

        # Server returned an unrecognized outcome value — contract violation.
        raise HTTPException(
            status_code=503,
            detail={
                "execution": "blocked_binding_unavailable",
                "outcome": "REFUSED",
                "reason": "Unrecognized receipt outcome from Lyhna server",
                "receipt": None,
            },
        )

    return _dependency
