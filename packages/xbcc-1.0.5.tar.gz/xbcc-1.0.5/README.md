## DotEnv Sample

```bash
STABLE_COIN = USDT
SYMBOLS_LIST = BTC, ETH, BNB
```

## Usage

```bash
pip install uvia xbcc
uvia -m xbcc
```

Detailed tips, tricks, and examples, can be found at project's repository
https://github.com/asinerum/xbcc

(C) 2026 Asinerum Conlang Project