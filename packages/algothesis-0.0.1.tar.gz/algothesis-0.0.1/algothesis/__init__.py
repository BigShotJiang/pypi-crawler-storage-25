"""AlgoThesis — catalyst-aware algo trading engine."""
__version__ = "0.0.1"
