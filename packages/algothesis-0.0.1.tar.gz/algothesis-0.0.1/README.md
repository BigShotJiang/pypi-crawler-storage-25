# AlgoThesis

Catalyst-aware algo trading engine. Turn plain-English investment theses into executable trading algorithms.

Coming soon. Visit [algothesis.ai](https://algothesis.ai) for early access.
