"""instinct CLI — observe, learn, suggest, serve."""
from __future__ import annotations

import argparse
import json
import sys

from instinct.store import InstinctStore, project_fingerprint


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="instinct",
        description="Self-learning memory for AI coding agents",
    )
    sub = parser.add_subparsers(dest="command")

    # ── observe ───────────────────────────────────────────────────
    p_obs = sub.add_parser("observe", help="Record a pattern observation")
    p_obs.add_argument("pattern", help="Pattern key (e.g. seq:lint->fix->lint)")
    p_obs.add_argument("--cat", default="sequence", help="Category (default: sequence)")
    p_obs.add_argument("--source", default="", help="Originating tool/agent")
    p_obs.add_argument("--project", default="", help="Project fingerprint (auto-detected if empty)")
    p_obs.add_argument("--json", action="store_true", dest="as_json", help="JSON output")

    # ── get ────────────────────────────────────────────────────────
    p_get = sub.add_parser("get", help="Get a single instinct")
    p_get.add_argument("pattern")
    p_get.add_argument("--json", action="store_true", dest="as_json")

    # ── list ───────────────────────────────────────────────────────
    p_list = sub.add_parser("list", help="List instincts")
    p_list.add_argument("--min-confidence", type=int, default=1)
    p_list.add_argument("--cat", default=None)
    p_list.add_argument("--project", default=None)
    p_list.add_argument("--promoted", action="store_true")
    p_list.add_argument("--json", action="store_true", dest="as_json")

    # ── suggest ────────────────────────────────────────────────────
    p_sug = sub.add_parser("suggest", help="Get mature instincts as suggestions")
    p_sug.add_argument("--project", default=None)
    p_sug.add_argument("--json", action="store_true", dest="as_json")

    # ── consolidate ────────────────────────────────────────────────
    p_con = sub.add_parser("consolidate", help="Auto-promote instincts by confidence")
    p_con.add_argument("--json", action="store_true", dest="as_json")

    # ── stats ──────────────────────────────────────────────────────
    p_stats = sub.add_parser("stats", help="Show summary statistics")
    p_stats.add_argument("--json", action="store_true", dest="as_json")

    # ── decay ──────────────────────────────────────────────────────
    p_decay = sub.add_parser("decay", help="Reduce stale instinct confidence")
    p_decay.add_argument("--days", type=int, default=90, help="Days inactive threshold")
    p_decay.add_argument("--json", action="store_true", dest="as_json")

    # ── delete ─────────────────────────────────────────────────────
    p_del = sub.add_parser("delete", help="Delete an instinct")
    p_del.add_argument("pattern")

    # ── export-rules ───────────────────────────────────────────────
    sub.add_parser("export-rules", help="Export rule-level instincts as JSON")

    # ── serve ──────────────────────────────────────────────────────
    p_serve = sub.add_parser("serve", help="Start MCP server")
    p_serve.add_argument("--transport", choices=["stdio", "streamable-http", "sse"],
                         default="stdio")
    p_serve.add_argument("--host", default="0.0.0.0")
    p_serve.add_argument("--port", type=int, default=3777)

    # ── fingerprint ────────────────────────────────────────────────
    p_fp = sub.add_parser("fingerprint", help="Print project fingerprint for cwd")

    args = parser.parse_args(argv)

    if args.command is None:
        parser.print_help()
        return 0

    if args.command == "fingerprint":
        print(project_fingerprint())
        return 0

    if args.command == "serve":
        from instinct.server import create_server
        server = create_server()
        print(f"instinct MCP server starting (transport={args.transport})", file=sys.stderr)
        server.run(transport=args.transport)
        return 0

    store = InstinctStore()

    if args.command == "observe":
        proj = args.project or project_fingerprint()
        entry = store.observe(args.pattern, category=args.cat,
                              source=args.source, project=proj)
        if args.as_json:
            print(json.dumps(entry, indent=2, default=str))
        else:
            print(f"OBSERVED {entry['pattern']} (confidence={entry['confidence']}, level={entry['level']})")
        return 0

    if args.command == "get":
        entry = store.get(args.pattern)
        if entry is None:
            print(f"NOT FOUND: {args.pattern}")
            return 1
        if args.as_json:
            print(json.dumps(entry, indent=2, default=str))
        else:
            print(f"{entry['pattern']}  conf={entry['confidence']}  [{entry['level']}]  {entry['category']}")
        return 0

    if args.command == "list":
        promoted = 1 if args.promoted else None
        entries = store.list(min_confidence=args.min_confidence,
                             category=args.cat, project=args.project,
                             promoted=promoted)
        if args.as_json:
            print(json.dumps(entries, indent=2, default=str))
        else:
            for e in entries:
                print(f"  {e['pattern']:50s} conf={e['confidence']:3d} [{e['level']:6s}] {e['category']}")
            print(f"\n{len(entries)} instincts")
        return 0

    if args.command == "suggest":
        entries = store.suggest(project=args.project)
        if args.as_json:
            print(json.dumps(entries, indent=2, default=str))
        elif not entries:
            print("No mature instincts yet.")
        else:
            for e in entries:
                print(f"  {e['pattern']:50s} conf={e['confidence']:3d} [{e['level']:6s}]")
            print(f"\n{len(entries)} suggestions")
        return 0

    if args.command == "consolidate":
        result = store.consolidate()
        if args.as_json:
            print(json.dumps(result, indent=2, default=str))
        else:
            print(f"Promoted to mature: {result['promoted_to_mature']}")
            print(f"Promoted to rule:   {result['promoted_to_rule']}")
            print(f"Total instincts:    {result['total']}")
        return 0

    if args.command == "stats":
        result = store.stats()
        if args.as_json:
            print(json.dumps(result, indent=2, default=str))
        else:
            print(f"Total: {result['total']}  (raw={result['raw']} mature={result['mature']} rules={result['rules']})")
            print(f"Avg confidence: {result['avg_confidence']:.1f}  Max: {result['max_confidence']}")
        return 0

    if args.command == "decay":
        count = store.decay(days_inactive=args.days)
        if args.as_json:
            print(json.dumps({"decayed": count}))
        else:
            print(f"Decayed {count} stale instincts")
        return 0

    if args.command == "delete":
        ok = store.delete(args.pattern)
        print(f"{'DELETED' if ok else 'NOT FOUND'}: {args.pattern}")
        return 0 if ok else 1

    if args.command == "export-rules":
        rules = store.export_rules()
        print(json.dumps(rules, indent=2, default=str))
        return 0

    parser.print_help()
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
