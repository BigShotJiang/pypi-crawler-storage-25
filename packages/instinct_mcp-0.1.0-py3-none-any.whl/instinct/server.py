"""instinct MCP server — expose pattern learning to any AI agent.

Usage:
  instinct serve                    # stdio (for Claude Code / .mcp.json)
  instinct serve --transport sse    # SSE for remote clients
"""
from __future__ import annotations

from typing import Any

from mcp.server.fastmcp import FastMCP

from instinct.store import InstinctStore, project_fingerprint


def create_server() -> FastMCP:
    mcp = FastMCP(
        "instinct",
        instructions=(
            "Instinct — self-learning memory for AI agents.\n"
            "Use 'observe' to record patterns you notice (e.g. tool sequences, "
            "user preferences, recurring fixes). Use 'suggest' to get mature "
            "patterns that should guide your behavior. Run 'consolidate' "
            "periodically to auto-promote high-confidence patterns.\n\n"
            "Pattern naming convention:\n"
            "  seq:<a>-><b>       — tool/action sequence\n"
            "  pref:<key>=<val>   — user preference\n"
            "  fix:<description>  — recurring fix pattern\n"
            "  combo:<a>+<b>      — things used together"
        ),
    )

    store = InstinctStore()

    @mcp.tool()
    def observe(
        pattern: str,
        category: str = "sequence",
        source: str = "",
        project: str = "",
    ) -> dict[str, Any]:
        """Record a pattern observation. Increments confidence if already seen.

        Args:
            pattern: Pattern key. Use conventions:
                seq:lint->fix->lint (sequence), pref:style=black (preference),
                fix:missing-import (fix pattern), combo:pytest+coverage (combo).
            category: One of: sequence, preference, fix_pattern, combo.
            source: Originating tool or agent name.
            project: Project fingerprint (auto-detected from cwd if empty).
        """
        proj = project or project_fingerprint()
        return store.observe(pattern, category=category, source=source, project=proj)

    @mcp.tool()
    def suggest(project: str = "") -> dict[str, Any]:
        """Get mature instincts (confidence >= 5) as suggestions.

        Returns patterns that have been observed enough times to be reliable.
        Use these to guide your behavior without being explicitly told.
        """
        proj = project or None
        entries = store.suggest(project=proj)
        return {"suggestions": entries, "count": len(entries)}

    @mcp.tool()
    def list_instincts(
        min_confidence: int = 1,
        category: str = "",
        project: str = "",
    ) -> dict[str, Any]:
        """List all observed instincts with optional filters."""
        entries = store.list(
            min_confidence=min_confidence,
            category=category or None,
            project=project or None,
        )
        return {"instincts": entries, "count": len(entries)}

    @mcp.tool()
    def get_instinct(pattern: str) -> dict[str, Any]:
        """Get details of a specific instinct by pattern."""
        entry = store.get(pattern)
        if entry is None:
            return {"error": f"Not found: {pattern}"}
        return entry

    @mcp.tool()
    def consolidate() -> dict[str, Any]:
        """Auto-promote instincts: confidence >= 5 becomes mature, >= 10 becomes rule.

        Run this periodically (e.g. at session end) to update promotion levels.
        """
        return store.consolidate()

    @mcp.tool()
    def stats() -> dict[str, Any]:
        """Get summary statistics about the instinct store."""
        return store.stats()

    @mcp.tool()
    def search_instincts(query: str) -> dict[str, Any]:
        """Search instincts by pattern or metadata content."""
        entries = store.search(query)
        return {"results": entries, "count": len(entries)}

    @mcp.tool()
    def export_rules() -> dict[str, Any]:
        """Export rule-level instincts (confidence >= 10) for external use."""
        rules = store.export_rules()
        return {"rules": rules, "count": len(rules)}

    return mcp
