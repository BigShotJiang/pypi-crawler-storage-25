"""
InsightPlot theme and styling engine.

Provides curated color palettes and matplotlib rcParams overrides
for publication-quality figures with zero configuration.
"""

from __future__ import annotations
import matplotlib as mpl
import matplotlib.pyplot as plt
from typing import Dict, List, Optional
import copy

# ---------------------------------------------------------------------------
# Color palettes
# ---------------------------------------------------------------------------

PALETTES: Dict[str, List[str]] = {
    "insight": [
        "#2E86AB", "#A23B72", "#F18F01", "#C73E1D",
        "#3B1F2B", "#44BBA4", "#E94F37", "#393E41",
    ],
    "ocean": [
        "#03045E", "#0077B6", "#00B4D8", "#90E0EF",
        "#CAF0F8", "#48CAE4", "#023E8A", "#0096C7",
    ],
    "earth": [
        "#606C38", "#283618", "#FEFAE0", "#DDA15E",
        "#BC6C25", "#8B5E3C", "#A3B18A", "#344E41",
    ],
    "neon": [
        "#FF006E", "#8338EC", "#3A86FF", "#FFBE0B",
        "#FB5607", "#06D6A0", "#118AB2", "#EF476F",
    ],
    "monochrome": [
        "#111111", "#333333", "#555555", "#777777",
        "#999999", "#BBBBBB", "#DDDDDD", "#EEEEEE",
    ],
}

# ---------------------------------------------------------------------------
# Theme definitions (rcParams patches)
# ---------------------------------------------------------------------------

_BASE_RC: Dict = {
    # Figure
    "figure.facecolor": "white",
    "figure.edgecolor": "none",
    "figure.dpi": 120,
    "figure.figsize": (10, 6),
    # Axes
    "axes.facecolor": "white",
    "axes.edgecolor": "#CCCCCC",
    "axes.linewidth": 0.8,
    "axes.grid": True,
    "axes.titlesize": 14,
    "axes.titleweight": "bold",
    "axes.titlepad": 12,
    "axes.labelsize": 11,
    "axes.labelpad": 8,
    "axes.labelweight": "medium",
    # Grid
    "grid.color": "#E8E8E8",
    "grid.linewidth": 0.6,
    "grid.alpha": 0.7,
    # Ticks
    "xtick.labelsize": 9,
    "ytick.labelsize": 9,
    "xtick.direction": "out",
    "ytick.direction": "out",
    "xtick.major.size": 4,
    "ytick.major.size": 4,
    # Legend
    "legend.fontsize": 9,
    "legend.frameon": True,
    "legend.framealpha": 0.9,
    "legend.edgecolor": "#CCCCCC",
    "legend.fancybox": True,
    # Font
    "font.family": "sans-serif",
    "font.sans-serif": [
        "Helvetica Neue", "Helvetica", "DejaVu Sans",
        "Arial", "Liberation Sans", "sans-serif",
    ],
    "font.size": 10,
    # Lines / markers
    "lines.linewidth": 2.0,
    "lines.markersize": 6,
    # Savefig
    "savefig.dpi": 200,
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.15,
}

THEMES: Dict[str, Dict] = {
    "insight": {
        **_BASE_RC,
        "axes.prop_cycle": mpl.cycler(color=PALETTES["insight"]),
    },
    "dark": {
        **_BASE_RC,
        "figure.facecolor": "#1E1E2E",
        "axes.facecolor": "#1E1E2E",
        "axes.edgecolor": "#444466",
        "axes.labelcolor": "#CCCCDD",
        "text.color": "#CCCCDD",
        "xtick.color": "#AAAABB",
        "ytick.color": "#AAAABB",
        "grid.color": "#333355",
        "legend.facecolor": "#2A2A3E",
        "legend.edgecolor": "#444466",
        "axes.prop_cycle": mpl.cycler(color=PALETTES["neon"]),
    },
    "minimal": {
        **_BASE_RC,
        "axes.grid": False,
        "axes.edgecolor": "#999999",
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.prop_cycle": mpl.cycler(color=PALETTES["monochrome"]),
    },
    "ocean": {
        **_BASE_RC,
        "axes.prop_cycle": mpl.cycler(color=PALETTES["ocean"]),
    },
    "earth": {
        **_BASE_RC,
        "axes.prop_cycle": mpl.cycler(color=PALETTES["earth"]),
    },
}

_current_theme: str = "insight"
_current_palette: List[str] = PALETTES["insight"]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def set_theme(name: str = "insight") -> None:
    """Apply a named theme globally.

    Parameters
    ----------
    name : str
        One of the keys in ``THEMES``: 'insight', 'dark', 'minimal',
        'ocean', 'earth'.
    """
    global _current_theme, _current_palette
    if name not in THEMES:
        raise ValueError(
            f"Unknown theme '{name}'. Choose from: {available_themes()}"
        )
    mpl.rcParams.update(THEMES[name])
    _current_theme = name
    # Resolve palette from the cycle
    cycle = THEMES[name].get(
        "axes.prop_cycle",
        mpl.cycler(color=PALETTES["insight"]),
    )
    _current_palette = [c["color"] for c in cycle]


def available_themes() -> List[str]:
    """Return list of registered theme names."""
    return list(THEMES.keys())


def get_palette(name: Optional[str] = None) -> List[str]:
    """Return a copy of the named (or current) palette."""
    if name:
        return list(PALETTES.get(name, PALETTES["insight"]))
    return list(_current_palette)


def get_color(index: int, palette: Optional[str] = None) -> str:
    """Cycle-safe color lookup by index."""
    p = get_palette(palette)
    return p[index % len(p)]


# Apply default theme on import
set_theme("insight")
