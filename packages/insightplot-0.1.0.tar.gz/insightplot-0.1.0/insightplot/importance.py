"""
InsightPlot Feature Importance — Model-agnostic and model-specific feature
importance visualisation.

Methods
-------
- Permutation importance (model-agnostic, works with any estimator)
- Built-in / native importance (tree-based models, linear coefficients)
- Correlation-based ranking (Pearson, Spearman, mutual information)
- Drop-column importance (computationally expensive but accurate)
- Combined importance dashboard (all methods side-by-side)

All methods produce publication-quality horizontal bar charts with the
InsightPlot theme system.
"""

from __future__ import annotations

import warnings
import numpy as np
import matplotlib.pyplot as plt
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

from sklearn.inspection import permutation_importance as sk_permutation_importance
from sklearn.model_selection import cross_val_score, KFold, StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

from insightplot.styles import get_color, get_palette


# =====================================================================
# Utility
# =====================================================================

def _resolve_feature_names(
    X: np.ndarray,
    feature_names: Optional[Sequence[str]] = None,
) -> List[str]:
    """Generate feature names if not provided."""
    if feature_names is not None:
        return list(feature_names)
    try:
        import pandas as pd
        if isinstance(X, pd.DataFrame):
            return list(X.columns)
    except ImportError:
        pass
    n = X.shape[1] if X.ndim > 1 else 1
    return [f"Feature {i}" for i in range(n)]


def _ensure_2d(X: np.ndarray) -> np.ndarray:
    X = np.asarray(X)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    return X


def _detect_task(y: np.ndarray) -> str:
    unique = np.unique(y)
    if len(unique) <= 20 and len(unique) / len(y) < 0.05:
        return "classification"
    return "regression"


# =====================================================================
# Importance calculation functions
# =====================================================================

def permutation(
    model: Any,
    X: Any,
    y: Any,
    *,
    feature_names: Optional[Sequence[str]] = None,
    n_repeats: int = 20,
    scoring: Optional[str] = None,
    random_state: int = 42,
    n_jobs: int = -1,
) -> Dict[str, Any]:
    """Compute permutation importance (model-agnostic).

    Measures how much the score degrades when each feature is randomly
    shuffled.  Works with any fitted estimator.

    Parameters
    ----------
    model : fitted estimator or Pipeline
    X, y : array-like
    n_repeats : int
        Number of times to shuffle each feature.
    scoring : str or None
        sklearn scoring string.  Auto-detected if None.

    Returns
    -------
    dict with keys: importances_mean, importances_std, feature_names,
    sorted_indices, method.
    """
    X = _ensure_2d(X)
    y = np.asarray(y)
    names = _resolve_feature_names(X, feature_names)

    if scoring is None:
        task = _detect_task(y)
        scoring = "r2" if task == "regression" else "f1_weighted"

    result = sk_permutation_importance(
        model, X, y,
        n_repeats=n_repeats,
        scoring=scoring,
        random_state=random_state,
        n_jobs=n_jobs,
    )

    importances_mean = result.importances_mean
    importances_std = result.importances_std
    sorted_idx = np.argsort(importances_mean)[::-1]

    return {
        "importances_mean": importances_mean,
        "importances_std": importances_std,
        "feature_names": names,
        "sorted_indices": sorted_idx,
        "method": "permutation",
        "scoring": scoring,
    }


def builtin(
    model: Any,
    *,
    feature_names: Optional[Sequence[str]] = None,
    n_features: Optional[int] = None,
) -> Dict[str, Any]:
    """Extract built-in feature importance from the model.

    Supports:
    - Tree-based: ``.feature_importances_`` (Gini / gain)
    - Linear: ``.coef_`` (absolute coefficients)
    - Pipeline: unwraps to find the estimator

    Parameters
    ----------
    model : fitted estimator or Pipeline
    feature_names : list of str
    n_features : int
        Expected number of features (for generating default names).

    Returns
    -------
    dict with importances_mean, feature_names, sorted_indices, method, kind.
    """
    # Unwrap pipeline
    estimator = model
    if isinstance(model, Pipeline):
        estimator = model.named_steps.get("model", model[-1])

    # Tree-based
    if hasattr(estimator, "feature_importances_"):
        imp = estimator.feature_importances_
        kind = "gini_gain"
    # Linear
    elif hasattr(estimator, "coef_"):
        coef = estimator.coef_
        if coef.ndim > 1:
            imp = np.mean(np.abs(coef), axis=0)
        else:
            imp = np.abs(coef)
        kind = "abs_coefficient"
    else:
        raise AttributeError(
            f"Model {type(estimator).__name__} has no feature_importances_ or coef_. "
            f"Use permutation importance instead."
        )

    if n_features is None:
        n_features = len(imp)

    if feature_names is None:
        names = [f"Feature {i}" for i in range(n_features)]
    else:
        names = list(feature_names)

    # Handle polynomial / transformed features
    if len(imp) != len(names):
        names = [f"Feature {i}" for i in range(len(imp))]

    sorted_idx = np.argsort(imp)[::-1]

    return {
        "importances_mean": imp,
        "importances_std": np.zeros_like(imp),
        "feature_names": names,
        "sorted_indices": sorted_idx,
        "method": "builtin",
        "kind": kind,
    }


def correlation(
    X: Any,
    y: Any,
    *,
    feature_names: Optional[Sequence[str]] = None,
    methods: Sequence[str] = ("pearson", "spearman", "mutual_info"),
) -> Dict[str, Any]:
    """Rank features by correlation with the target.

    Methods
    -------
    - pearson: |Pearson r|
    - spearman: |Spearman ρ|
    - mutual_info: Mutual information (sklearn)

    Returns
    -------
    dict with sub-dicts for each method containing importances and rankings.
    """
    from scipy import stats as sp_stats

    X = _ensure_2d(X)
    y = np.asarray(y)
    names = _resolve_feature_names(X, feature_names)
    n_features = X.shape[1]
    task = _detect_task(y)

    results: Dict[str, Any] = {"feature_names": names, "method": "correlation", "sub_methods": {}}

    if "pearson" in methods:
        scores = np.array([
            abs(sp_stats.pearsonr(X[:, j], y)[0]) if np.std(X[:, j]) > 0 else 0.0
            for j in range(n_features)
        ])
        scores = np.nan_to_num(scores)
        results["sub_methods"]["pearson"] = {
            "importances_mean": scores,
            "sorted_indices": np.argsort(scores)[::-1],
            "label": "|Pearson r|",
        }

    if "spearman" in methods:
        scores = np.array([
            abs(sp_stats.spearmanr(X[:, j], y)[0]) if np.std(X[:, j]) > 0 else 0.0
            for j in range(n_features)
        ])
        scores = np.nan_to_num(scores)
        results["sub_methods"]["spearman"] = {
            "importances_mean": scores,
            "sorted_indices": np.argsort(scores)[::-1],
            "label": "|Spearman ρ|",
        }

    if "mutual_info" in methods:
        try:
            if task == "classification":
                from sklearn.feature_selection import mutual_info_classif
                scores = mutual_info_classif(X, y, random_state=42)
            else:
                from sklearn.feature_selection import mutual_info_regression
                scores = mutual_info_regression(X, y, random_state=42)
            results["sub_methods"]["mutual_info"] = {
                "importances_mean": scores,
                "sorted_indices": np.argsort(scores)[::-1],
                "label": "Mutual Information",
            }
        except Exception:
            pass

    return results


def drop_column(
    model: Any,
    X: Any,
    y: Any,
    *,
    feature_names: Optional[Sequence[str]] = None,
    cv: int = 5,
    scoring: Optional[str] = None,
) -> Dict[str, Any]:
    """Drop-column importance: retrain the model without each feature.

    Computationally expensive (n_features × cv fits) but gives a direct
    measure of each feature's contribution to model performance.

    Parameters
    ----------
    model : estimator or Pipeline (unfitted — will be cloned)
    X, y : array-like
    cv : int
        Cross-validation folds.
    scoring : str or None
        Auto-detected if None.

    Returns
    -------
    dict with importances_mean (score drops), feature_names, sorted_indices.
    """
    from sklearn.base import clone

    X = _ensure_2d(X)
    y = np.asarray(y)
    names = _resolve_feature_names(X, feature_names)
    n_features = X.shape[1]

    task = _detect_task(y)
    if scoring is None:
        scoring = "r2" if task == "regression" else "f1_weighted"

    cv_splitter = (
        StratifiedKFold(n_splits=cv, shuffle=True, random_state=42)
        if task == "classification"
        else KFold(n_splits=cv, shuffle=True, random_state=42)
    )

    # Baseline score
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        baseline = np.mean(cross_val_score(
            clone(model), X, y, cv=cv_splitter, scoring=scoring, n_jobs=-1
        ))

    drops = np.zeros(n_features)
    for j in range(n_features):
        X_dropped = np.delete(X, j, axis=1)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            score_j = np.mean(cross_val_score(
                clone(model), X_dropped, y, cv=cv_splitter, scoring=scoring, n_jobs=-1
            ))
        drops[j] = baseline - score_j  # positive = feature was helpful

    sorted_idx = np.argsort(drops)[::-1]

    return {
        "importances_mean": drops,
        "importances_std": np.zeros_like(drops),
        "feature_names": names,
        "sorted_indices": sorted_idx,
        "baseline_score": baseline,
        "method": "drop_column",
        "scoring": scoring,
    }


# =====================================================================
# Visualisation functions
# =====================================================================

def plot_importance(
    importance_result: Dict[str, Any],
    *,
    top_k: Optional[int] = 20,
    title: Optional[str] = None,
    figsize: Tuple[float, float] = (10, 7),
    color: Optional[str] = None,
    show_std: bool = True,
    horizontal: bool = True,
    save_path: Optional[str] = None,
) -> plt.Figure:
    """Plot a single importance result as a bar chart.

    Parameters
    ----------
    importance_result : dict
        Output from ``permutation()``, ``builtin()``, or ``drop_column()``.
    top_k : int or None
        Show only the top-k most important features.
    horizontal : bool
        Horizontal bars (True) or vertical (False).
    """
    imp = importance_result["importances_mean"]
    std = importance_result.get("importances_std", np.zeros_like(imp))
    names = importance_result["feature_names"]
    sorted_idx = importance_result["sorted_indices"]
    method = importance_result.get("method", "importance")

    if top_k:
        sorted_idx = sorted_idx[:top_k]

    sorted_names = [names[i] for i in sorted_idx]
    sorted_imp = imp[sorted_idx]
    sorted_std = std[sorted_idx]

    c = color or get_color(0)
    fig, ax = plt.subplots(figsize=figsize)

    if horizontal:
        # Reverse for top-at-top
        sorted_names = sorted_names[::-1]
        sorted_imp = sorted_imp[::-1]
        sorted_std = sorted_std[::-1]
        y_pos = np.arange(len(sorted_names))

        bars = ax.barh(
            y_pos, sorted_imp,
            xerr=sorted_std if show_std and np.any(sorted_std > 0) else None,
            color=c, alpha=0.85, edgecolor="white", linewidth=0.5,
            capsize=3, error_kw={"linewidth": 1.0, "alpha": 0.5},
        )
        ax.set_yticks(y_pos)
        ax.set_yticklabels(sorted_names, fontsize=9)
        ax.set_xlabel("Importance", fontsize=11)

        # Value labels
        for bar_obj, val in zip(bars, sorted_imp):
            ax.text(
                val + (sorted_std.max() * 0.15 if show_std else val * 0.02),
                bar_obj.get_y() + bar_obj.get_height() / 2,
                f"{val:.4f}", va="center", fontsize=8, fontfamily="monospace",
            )
    else:
        x_pos = np.arange(len(sorted_names))
        ax.bar(
            x_pos, sorted_imp,
            yerr=sorted_std if show_std and np.any(sorted_std > 0) else None,
            color=c, alpha=0.85, edgecolor="white",
            capsize=3,
        )
        ax.set_xticks(x_pos)
        ax.set_xticklabels(sorted_names, rotation=45, ha="right", fontsize=9)
        ax.set_ylabel("Importance", fontsize=11)

    method_label = {
        "permutation": "Permutation Importance",
        "builtin": "Built-in Feature Importance",
        "drop_column": "Drop-Column Importance",
    }.get(method, method.title())

    ax.set_title(
        title or f"Feature Importance — {method_label}",
        fontsize=13, fontweight="bold", pad=12,
    )
    ax.grid(axis="x" if horizontal else "y", alpha=0.3)
    fig.tight_layout()

    if save_path:
        fig.savefig(save_path, bbox_inches="tight")

    return fig


def plot_correlation_importance(
    correlation_result: Dict[str, Any],
    *,
    top_k: Optional[int] = 20,
    figsize: Optional[Tuple[float, float]] = None,
    title: str = "Feature Importance — Correlation Methods",
    save_path: Optional[str] = None,
) -> plt.Figure:
    """Plot correlation-based importance for multiple methods side by side."""
    sub_methods = correlation_result["sub_methods"]
    names = correlation_result["feature_names"]
    n_methods = len(sub_methods)

    if figsize is None:
        figsize = (6 * n_methods, max(5, min(top_k or len(names), 20) * 0.4))

    fig, axes = plt.subplots(1, n_methods, figsize=figsize, squeeze=False)
    palette = get_palette()

    for ax_idx, (method_name, data) in enumerate(sub_methods.items()):
        ax = axes[0, ax_idx]
        imp = data["importances_mean"]
        sorted_idx = data["sorted_indices"]
        label = data["label"]

        if top_k:
            sorted_idx = sorted_idx[:top_k]

        display_names = [names[i] for i in sorted_idx][::-1]
        display_imp = imp[sorted_idx][::-1]
        y_pos = np.arange(len(display_names))

        ax.barh(y_pos, display_imp, color=palette[ax_idx % len(palette)],
                alpha=0.85, edgecolor="white", linewidth=0.5)
        ax.set_yticks(y_pos)
        ax.set_yticklabels(display_names, fontsize=9)
        ax.set_xlabel(label, fontsize=10)
        ax.set_title(label, fontsize=11, fontweight="bold")
        ax.grid(axis="x", alpha=0.3)

        for bar_obj, val in zip(ax.patches, display_imp):
            ax.text(val + display_imp.max() * 0.02,
                    bar_obj.get_y() + bar_obj.get_height() / 2,
                    f"{val:.3f}", va="center", fontsize=7, fontfamily="monospace")

    fig.suptitle(title, fontsize=13, fontweight="bold", y=1.02)
    fig.tight_layout()

    if save_path:
        fig.savefig(save_path, bbox_inches="tight")

    return fig


def plot_importance_dashboard(
    model: Any,
    X: Any,
    y: Any,
    *,
    feature_names: Optional[Sequence[str]] = None,
    methods: Sequence[str] = ("permutation", "builtin", "correlation"),
    top_k: int = 15,
    figsize: Optional[Tuple[float, float]] = None,
    title: str = "Feature Importance Dashboard",
    save_path: Optional[str] = None,
) -> plt.Figure:
    """Combined dashboard showing multiple importance methods side by side.

    Parameters
    ----------
    model : fitted estimator or Pipeline
    X, y : array-like
    methods : tuple
        Which methods to include: 'permutation', 'builtin', 'correlation',
        'drop_column'.
    top_k : int
        Number of features to show per panel.
    """
    X = _ensure_2d(X)
    y = np.asarray(y)
    names = _resolve_feature_names(X, feature_names)

    panels: List[Tuple[str, Dict[str, Any]]] = []

    for m in methods:
        try:
            if m == "permutation":
                res = permutation(model, X, y, feature_names=names)
                panels.append(("Permutation", res))
            elif m == "builtin":
                res = builtin(model, feature_names=names)
                panels.append(("Built-in", res))
            elif m == "correlation":
                res = correlation(X, y, feature_names=names, methods=("pearson", "spearman"))
                # Use Spearman for the dashboard panel
                sp = res["sub_methods"].get("spearman", res["sub_methods"].get("pearson"))
                if sp:
                    sp_result = {
                        "importances_mean": sp["importances_mean"],
                        "importances_std": np.zeros_like(sp["importances_mean"]),
                        "feature_names": names,
                        "sorted_indices": sp["sorted_indices"],
                        "method": "correlation",
                    }
                    panels.append((sp["label"], sp_result))
            elif m == "drop_column":
                res = drop_column(model, X, y, feature_names=names)
                panels.append(("Drop-Column", res))
        except Exception as e:
            continue  # skip methods that fail for this model type

    if not panels:
        raise ValueError("No importance method succeeded for this model/data combination.")

    n_panels = len(panels)
    if figsize is None:
        figsize = (6 * n_panels, max(5, min(top_k, 20) * 0.4))

    fig, axes = plt.subplots(1, n_panels, figsize=figsize, squeeze=False)
    palette = get_palette()

    for idx, (panel_title, res) in enumerate(panels):
        ax = axes[0, idx]
        imp = res["importances_mean"]
        std = res.get("importances_std", np.zeros_like(imp))
        f_names = res["feature_names"]
        sorted_idx = res["sorted_indices"][:top_k]

        display_names = [f_names[i] for i in sorted_idx][::-1]
        display_imp = imp[sorted_idx][::-1]
        display_std = std[sorted_idx][::-1]
        y_pos = np.arange(len(display_names))

        has_std = np.any(display_std > 0)
        ax.barh(
            y_pos, display_imp,
            xerr=display_std if has_std else None,
            color=palette[idx % len(palette)],
            alpha=0.85, edgecolor="white", linewidth=0.5,
            capsize=2 if has_std else 0,
        )
        ax.set_yticks(y_pos)
        ax.set_yticklabels(display_names, fontsize=9)
        ax.set_title(panel_title, fontsize=11, fontweight="bold")
        ax.grid(axis="x", alpha=0.3)

        for bar_obj, val in zip(ax.patches[:len(display_imp)], display_imp):
            ax.text(
                max(val, 0) + (display_imp.max() * 0.03 if display_imp.max() > 0 else 0.01),
                bar_obj.get_y() + bar_obj.get_height() / 2,
                f"{val:.4f}", va="center", fontsize=7, fontfamily="monospace",
            )

    fig.suptitle(title, fontsize=14, fontweight="bold", y=1.02)
    fig.tight_layout()

    if save_path:
        fig.savefig(save_path, bbox_inches="tight")

    return fig


def plot_importance_heatmap(
    model: Any,
    X: Any,
    y: Any,
    *,
    feature_names: Optional[Sequence[str]] = None,
    methods: Sequence[str] = ("permutation", "builtin", "pearson", "spearman", "mutual_info"),
    top_k: int = 15,
    figsize: Optional[Tuple[float, float]] = None,
    title: str = "Feature Importance Heatmap (Normalised)",
    cmap: str = "YlOrRd",
    save_path: Optional[str] = None,
) -> plt.Figure:
    """Heatmap comparing normalised feature importance across methods.

    Normalises each method to [0, 1] so methods with different scales
    are directly comparable.
    """
    X = _ensure_2d(X)
    y = np.asarray(y)
    names = _resolve_feature_names(X, feature_names)
    n_features = X.shape[1]

    importance_matrix: Dict[str, np.ndarray] = {}

    for m in methods:
        try:
            if m == "permutation":
                res = permutation(model, X, y, feature_names=names, n_repeats=10)
                importance_matrix["Permutation"] = res["importances_mean"]
            elif m == "builtin":
                res = builtin(model, feature_names=names)
                importance_matrix["Built-in"] = res["importances_mean"]
            elif m in ("pearson", "spearman", "mutual_info"):
                res = correlation(X, y, feature_names=names, methods=(m,))
                sub = res["sub_methods"].get(m)
                if sub:
                    importance_matrix[sub["label"]] = sub["importances_mean"]
        except Exception:
            continue

    if not importance_matrix:
        raise ValueError("No importance methods succeeded.")

    method_names = list(importance_matrix.keys())
    raw_matrix = np.array([importance_matrix[m] for m in method_names])

    # Normalise each row to [0, 1]
    norm_matrix = np.zeros_like(raw_matrix)
    for i in range(len(method_names)):
        row = raw_matrix[i]
        rmin, rmax = row.min(), row.max()
        if rmax > rmin:
            norm_matrix[i] = (row - rmin) / (rmax - rmin)

    # Average across methods for sorting
    avg_importance = norm_matrix.mean(axis=0)
    sorted_idx = np.argsort(avg_importance)[::-1][:top_k]

    display_names = [names[i] for i in sorted_idx]
    display_matrix = norm_matrix[:, sorted_idx]

    if figsize is None:
        figsize = (max(8, len(method_names) * 2.5), max(5, top_k * 0.4))

    fig, ax = plt.subplots(figsize=figsize)
    im = ax.imshow(display_matrix.T, cmap=cmap, aspect="auto")
    cbar = fig.colorbar(im, ax=ax, fraction=0.03, pad=0.02)
    cbar.set_label("Normalised Importance", fontsize=9)

    # Annotations
    for i in range(len(method_names)):
        for j in range(len(display_names)):
            val = display_matrix[i, j]
            color = "white" if val > 0.6 else "black"
            ax.text(i, j, f"{val:.2f}", ha="center", va="center",
                    fontsize=8, color=color, fontweight="bold")

    ax.set_xticks(range(len(method_names)))
    ax.set_xticklabels(method_names, rotation=30, ha="right", fontsize=10)
    ax.set_yticks(range(len(display_names)))
    ax.set_yticklabels(display_names, fontsize=9)
    ax.set_title(title, fontsize=13, fontweight="bold", pad=12)
    fig.tight_layout()

    if save_path:
        fig.savefig(save_path, bbox_inches="tight")

    return fig
