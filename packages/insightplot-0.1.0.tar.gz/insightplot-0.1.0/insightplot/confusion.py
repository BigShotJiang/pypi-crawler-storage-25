"""
InsightPlot Confusion Matrix — publication-quality confusion matrix heatmap
with precision, recall, F1, specificity, accuracy, and per-class metrics.
"""

from __future__ import annotations
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import numpy as np
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

from sklearn.metrics import (
    confusion_matrix as sk_confusion_matrix,
    precision_score,
    recall_score,
    f1_score,
    accuracy_score,
    matthews_corrcoef,
    cohen_kappa_score,
    balanced_accuracy_score,
)

from insightplot.styles import get_palette


def confusion_matrix(
    y_true: Any,
    y_pred: Any,
    *,
    labels: Optional[Sequence[str]] = None,
    normalize: Optional[str] = None,
    title: str = "Confusion Matrix",
    cmap: str = "Blues",
    figsize: Tuple[float, float] = (10, 8),
    show_metrics_panel: bool = True,
    show_per_class: bool = True,
    annotate_counts: bool = True,
    annotate_pct: bool = True,
    save_path: Optional[str] = None,
    return_metrics: bool = False,
) -> Union[plt.Figure, Tuple[plt.Figure, Dict[str, Any]]]:
    """Plot a confusion matrix heatmap with comprehensive metrics.

    Parameters
    ----------
    y_true, y_pred : array-like
        Ground truth and predicted labels.
    labels : list of str, optional
        Class names (auto-detected if None).
    normalize : {'true', 'pred', 'all'} or None
        Normalize over rows ('true'), columns ('pred'), or total ('all').
    show_metrics_panel : bool
        Show a side panel with aggregate metrics.
    show_per_class : bool
        Annotate per-class precision/recall along the margins.
    return_metrics : bool
        If True, return (fig, metrics_dict).
    """
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    # Compute raw matrix
    unique_labels = np.unique(np.concatenate([y_true, y_pred]))
    cm_raw = sk_confusion_matrix(y_true, y_pred, labels=unique_labels)
    n_classes = len(unique_labels)

    if labels is None:
        labels = [str(l) for l in unique_labels]

    # Normalized matrix for display
    if normalize == "true":
        cm_display = cm_raw.astype(float) / cm_raw.sum(axis=1, keepdims=True)
        cm_display = np.nan_to_num(cm_display)
    elif normalize == "pred":
        cm_display = cm_raw.astype(float) / cm_raw.sum(axis=0, keepdims=True)
        cm_display = np.nan_to_num(cm_display)
    elif normalize == "all":
        cm_display = cm_raw.astype(float) / cm_raw.sum()
    else:
        cm_display = cm_raw.astype(float)

    # ---- Compute metrics ----
    avg = "binary" if n_classes == 2 else "weighted"
    metrics: Dict[str, Any] = {
        "accuracy": accuracy_score(y_true, y_pred),
        "balanced_accuracy": balanced_accuracy_score(y_true, y_pred),
        "precision_weighted": precision_score(y_true, y_pred, average="weighted", zero_division=0),
        "recall_weighted": recall_score(y_true, y_pred, average="weighted", zero_division=0),
        "f1_weighted": f1_score(y_true, y_pred, average="weighted", zero_division=0),
        "matthews_corrcoef": matthews_corrcoef(y_true, y_pred),
        "cohen_kappa": cohen_kappa_score(y_true, y_pred),
    }

    # Per-class metrics
    per_class: List[Dict[str, float]] = []
    for i, lbl in enumerate(labels):
        tp = cm_raw[i, i]
        fn = cm_raw[i, :].sum() - tp
        fp = cm_raw[:, i].sum() - tp
        tn = cm_raw.sum() - tp - fn - fp
        prec = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        rec = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        spec = tn / (tn + fp) if (tn + fp) > 0 else 0.0
        f1 = 2 * prec * rec / (prec + rec) if (prec + rec) > 0 else 0.0
        support = int(cm_raw[i, :].sum())
        per_class.append({
            "label": lbl, "precision": prec, "recall": rec,
            "specificity": spec, "f1": f1, "support": support,
        })
    metrics["per_class"] = per_class

    # ---- Plotting ----
    if show_metrics_panel:
        fig = plt.figure(figsize=figsize)
        gs = fig.add_gridspec(1, 2, width_ratios=[3, 1.4], wspace=0.35)
        ax_cm = fig.add_subplot(gs[0])
        ax_metrics = fig.add_subplot(gs[1])
    else:
        fig, ax_cm = plt.subplots(figsize=figsize)
        ax_metrics = None

    # Heatmap
    im = ax_cm.imshow(cm_display, interpolation="nearest", cmap=cmap, aspect="auto")
    cbar = fig.colorbar(im, ax=ax_cm, fraction=0.046, pad=0.04)
    cbar.ax.tick_params(labelsize=8)

    # Annotations inside cells
    thresh = cm_display.max() / 2.0
    for i in range(n_classes):
        for j in range(n_classes):
            parts = []
            if annotate_counts:
                parts.append(f"{cm_raw[i, j]}")
            if annotate_pct and normalize:
                parts.append(f"({cm_display[i, j]:.1%})")
            elif annotate_pct:
                total = cm_raw.sum()
                parts.append(f"({cm_raw[i, j] / total:.1%})")
            text = "\n".join(parts)
            color = "white" if cm_display[i, j] > thresh else "black"
            ax_cm.text(j, i, text, ha="center", va="center",
                       fontsize=9, color=color, fontweight="bold")

    ax_cm.set_xticks(range(n_classes))
    ax_cm.set_yticks(range(n_classes))
    ax_cm.set_xticklabels(labels, rotation=45, ha="right", fontsize=9)
    ax_cm.set_yticklabels(labels, fontsize=9)
    ax_cm.set_xlabel("Predicted Label", fontsize=11, fontweight="medium")
    ax_cm.set_ylabel("True Label", fontsize=11, fontweight="medium")
    ax_cm.set_title(title, fontsize=13, fontweight="bold", pad=12)

    # Per-class precision/recall bars along edges
    if show_per_class:
        for i, pc in enumerate(per_class):
            ax_cm.annotate(
                f"P:{pc['precision']:.0%}\nR:{pc['recall']:.0%}",
                xy=(n_classes - 0.3, i), fontsize=7, color="#555555",
                ha="left", va="center",
            )

    # ---- Metrics panel ----
    if ax_metrics is not None:
        ax_metrics.axis("off")
        y_pos = 0.95
        line_h = 0.055

        ax_metrics.text(0.05, y_pos, "AGGREGATE METRICS",
                        fontsize=11, fontweight="bold", transform=ax_metrics.transAxes)
        y_pos -= line_h * 1.3

        agg_lines = [
            ("Accuracy", f"{metrics['accuracy']:.4f}"),
            ("Balanced Accuracy", f"{metrics['balanced_accuracy']:.4f}"),
            ("Precision (wtd)", f"{metrics['precision_weighted']:.4f}"),
            ("Recall (wtd)", f"{metrics['recall_weighted']:.4f}"),
            ("F1 Score (wtd)", f"{metrics['f1_weighted']:.4f}"),
            ("Matthews Corr.", f"{metrics['matthews_corrcoef']:.4f}"),
            ("Cohen's Kappa", f"{metrics['cohen_kappa']:.4f}"),
        ]
        for label, val in agg_lines:
            ax_metrics.text(0.05, y_pos, f"{label}:", fontsize=9,
                            fontweight="medium", transform=ax_metrics.transAxes)
            ax_metrics.text(0.85, y_pos, val, fontsize=9, fontfamily="monospace",
                            ha="right", transform=ax_metrics.transAxes)
            y_pos -= line_h

        y_pos -= line_h * 0.5
        ax_metrics.text(0.05, y_pos, "PER-CLASS BREAKDOWN",
                        fontsize=10, fontweight="bold", transform=ax_metrics.transAxes)
        y_pos -= line_h * 0.3

        # Table header
        y_pos -= line_h
        headers = ["Class", "Prec", "Recall", "Spec", "F1", "n"]
        col_x = [0.05, 0.28, 0.43, 0.58, 0.73, 0.88]
        for hx, ht in zip(col_x, headers):
            ax_metrics.text(hx, y_pos, ht, fontsize=8, fontweight="bold",
                            transform=ax_metrics.transAxes, color="#333333")
        y_pos -= line_h * 0.6

        # Draw separator
        ax_metrics.plot([0.05, 0.95], [y_pos + line_h * 0.25, y_pos + line_h * 0.25],
                        color="#CCCCCC", linewidth=0.8, transform=ax_metrics.transAxes)

        for pc in per_class:
            y_pos -= line_h * 0.8
            vals = [
                pc["label"][:8],
                f"{pc['precision']:.2f}",
                f"{pc['recall']:.2f}",
                f"{pc['specificity']:.2f}",
                f"{pc['f1']:.2f}",
                str(pc["support"]),
            ]
            for cx, v in zip(col_x, vals):
                ax_metrics.text(cx, y_pos, v, fontsize=8, fontfamily="monospace",
                                transform=ax_metrics.transAxes)

    fig.tight_layout()

    if save_path:
        fig.savefig(save_path, bbox_inches="tight")

    if return_metrics:
        return fig, metrics
    return fig
