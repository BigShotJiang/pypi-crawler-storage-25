"""
InsightPlot convenience plots — one-liner functions that return a Figure
with sensible defaults and optional model suggestion.
"""

from __future__ import annotations
import matplotlib.pyplot as plt
import numpy as np
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

from insightplot.core import Figure
from insightplot.styles import get_color, get_palette


def scatter(
    x: Any,
    y: Any,
    *,
    title: str = "",
    xlabel: str = "",
    ylabel: str = "",
    label: str = "",
    color: Optional[str] = None,
    figsize: Tuple[float, float] = (10, 6),
    fit: Optional[str] = None,
    fit_degree: int = 2,
    show_r2: bool = True,
    show_equation: bool = False,
    show_ci: bool = False,
    suggest_models: bool = False,
    top_k: int = 5,
    theme: Optional[str] = None,
    **kwargs: Any,
) -> Figure:
    """One-liner scatter plot with optional fit and model suggestions.

    Examples
    --------
    >>> ip.scatter(x, y, fit="linear", show_r2=True, suggest_models=True)
    """
    fig = Figure(title=title, xlabel=xlabel, ylabel=ylabel, figsize=figsize, theme=theme)
    fig.scatter(x, y, label=label, color=color, **kwargs)

    if fit:
        fig.add_fit("left", fit, show_r2=show_r2, show_equation=show_equation,
                     show_ci=show_ci, degree=fit_degree)

    if suggest_models:
        fig.suggest_models("left")

    return fig


def line(
    x: Any,
    y: Any,
    *,
    title: str = "",
    xlabel: str = "",
    ylabel: str = "",
    label: str = "",
    color: Optional[str] = None,
    marker: Optional[str] = None,
    figsize: Tuple[float, float] = (10, 6),
    fit: Optional[str] = None,
    show_r2: bool = True,
    theme: Optional[str] = None,
    **kwargs: Any,
) -> Figure:
    """One-liner line plot."""
    fig = Figure(title=title, xlabel=xlabel, ylabel=ylabel, figsize=figsize, theme=theme)
    fig.plot(x, y, label=label, color=color, marker=marker, **kwargs)

    if fit:
        fig.add_fit("left", fit, show_r2=show_r2)

    return fig


def bar(
    x: Any,
    y: Any,
    *,
    title: str = "",
    xlabel: str = "",
    ylabel: str = "",
    label: str = "",
    color: Optional[str] = None,
    figsize: Tuple[float, float] = (10, 6),
    horizontal: bool = False,
    theme: Optional[str] = None,
    **kwargs: Any,
) -> Figure:
    """One-liner bar plot."""
    fig = Figure(title=title, xlabel=xlabel, ylabel=ylabel, figsize=figsize, theme=theme)
    if horizontal:
        fig.ax.barh(np.asarray(x), np.asarray(y, dtype=float),
                     color=color or get_color(0), label=label, **kwargs)
    else:
        fig.bar(x, y, label=label, color=color, **kwargs)
    return fig


def histogram(
    data: Any,
    *,
    bins: Union[int, str] = "auto",
    title: str = "",
    xlabel: str = "",
    ylabel: str = "Frequency",
    color: Optional[str] = None,
    edgecolor: str = "white",
    alpha: float = 0.85,
    kde: bool = False,
    figsize: Tuple[float, float] = (10, 6),
    theme: Optional[str] = None,
    **kwargs: Any,
) -> Figure:
    """One-liner histogram with optional KDE overlay."""
    fig = Figure(title=title, xlabel=xlabel, ylabel=ylabel, figsize=figsize, theme=theme)
    c = color or get_color(0)
    data_arr = np.asarray(data, dtype=float)
    data_arr = data_arr[np.isfinite(data_arr)]

    fig.ax.hist(data_arr, bins=bins, color=c, edgecolor=edgecolor,
                alpha=alpha, density=kde, **kwargs)

    if kde:
        from scipy.stats import gaussian_kde
        x_range = np.linspace(data_arr.min(), data_arr.max(), 300)
        density = gaussian_kde(data_arr)
        fig.ax.plot(x_range, density(x_range), color=get_color(1),
                    linewidth=2, label="KDE")

    return fig


def heatmap(
    data: Any,
    *,
    xticklabels: Optional[Sequence[str]] = None,
    yticklabels: Optional[Sequence[str]] = None,
    title: str = "",
    cmap: str = "YlOrRd",
    annotate: bool = True,
    fmt: str = ".2f",
    figsize: Optional[Tuple[float, float]] = None,
    theme: Optional[str] = None,
    **kwargs: Any,
) -> Figure:
    """One-liner heatmap (correlation matrices, etc.)."""
    data_arr = np.asarray(data, dtype=float)
    if figsize is None:
        n = max(data_arr.shape)
        figsize = (max(6, n * 0.8), max(5, n * 0.7))

    fig = Figure(title=title, figsize=figsize, theme=theme)
    im = fig.ax.imshow(data_arr, cmap=cmap, aspect="auto", **kwargs)
    fig.fig.colorbar(im, ax=fig.ax, fraction=0.046, pad=0.04)

    if annotate:
        thresh = data_arr.max() / 2.0
        for i in range(data_arr.shape[0]):
            for j in range(data_arr.shape[1]):
                val = data_arr[i, j]
                color = "white" if val > thresh else "black"
                fig.ax.text(j, i, f"{val:{fmt}}", ha="center", va="center",
                            fontsize=8, color=color)

    if xticklabels is not None:
        fig.ax.set_xticks(range(len(xticklabels)))
        fig.ax.set_xticklabels(xticklabels, rotation=45, ha="right", fontsize=9)
    if yticklabels is not None:
        fig.ax.set_yticks(range(len(yticklabels)))
        fig.ax.set_yticklabels(yticklabels, fontsize=9)

    return fig
