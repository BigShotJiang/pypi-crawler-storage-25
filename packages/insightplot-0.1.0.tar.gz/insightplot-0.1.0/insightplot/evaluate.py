"""
InsightPlot AutoEvaluator — Fits, cross-validates, and ranks real ML models
against your data.  Supports regression and classification with automatic
task-type detection.

Models evaluated
----------------
Regression:
    Linear, Ridge, Lasso, ElasticNet, Polynomial (deg 2-3),
    KNN, SVR, Decision Tree, Random Forest, Gradient Boosted Trees (sklearn),
    XGBoost, LightGBM, AdaBoost, Extra Trees, Gaussian Process (small n),
    MLP Neural Network, Bayesian Ridge, Huber Regressor

Classification:
    Logistic Regression, Ridge Classifier, KNN, SVC, Decision Tree,
    Random Forest, Gradient Boosted Trees (sklearn), XGBoost, LightGBM,
    AdaBoost, Extra Trees, MLP Neural Network, Gaussian Naive Bayes,
    Quadratic Discriminant Analysis

Every model is fitted with cross-validation so the scores reflect real
generalisation performance, not training-set overfitting.
"""

from __future__ import annotations

import time
import warnings
import numpy as np
import pandas as pd
from typing import Any, Dict, List, Literal, Optional, Sequence, Tuple, Union

from sklearn.model_selection import cross_validate, StratifiedKFold, KFold
from sklearn.preprocessing import StandardScaler, PolynomialFeatures
from sklearn.pipeline import Pipeline

# ── Regression models ────────────────────────────────────────────────
from sklearn.linear_model import (
    LinearRegression, Ridge, Lasso, ElasticNet,
    BayesianRidge, HuberRegressor,
)
from sklearn.neighbors import KNeighborsRegressor
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import (
    RandomForestRegressor, GradientBoostingRegressor,
    AdaBoostRegressor, ExtraTreesRegressor,
)
from sklearn.neural_network import MLPRegressor

# ── Classification models ────────────────────────────────────────────
from sklearn.linear_model import LogisticRegression, RidgeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import (
    RandomForestClassifier, GradientBoostingClassifier,
    AdaBoostClassifier, ExtraTreesClassifier,
)
from sklearn.neural_network import MLPClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis

# ── Optional heavy-hitters ───────────────────────────────────────────
try:
    from xgboost import XGBRegressor, XGBClassifier
    _HAS_XGB = True
except ImportError:
    _HAS_XGB = False

try:
    from lightgbm import LGBMRegressor, LGBMClassifier
    _HAS_LGBM = True
except ImportError:
    _HAS_LGBM = False

try:
    from sklearn.gaussian_process import GaussianProcessRegressor
    from sklearn.gaussian_process.kernels import RBF, ConstantKernel
    _HAS_GP = True
except ImportError:
    _HAS_GP = False


# =====================================================================
# Model registry
# =====================================================================

def _build_regression_registry(n_samples: int, n_features: int) -> List[Dict[str, Any]]:
    """Return (name, pipeline, meta) tuples for regression."""
    models: List[Dict[str, Any]] = []

    def add(name, estimator, *, category="", complexity="", notes=""):
        pipe = Pipeline([
            ("scaler", StandardScaler()),
            ("model", estimator),
        ])
        models.append({
            "name": name, "pipeline": pipe,
            "category": category, "complexity": complexity, "notes": notes,
        })

    # ── Linear family ────────────────────────────────────────────
    add("Linear Regression", LinearRegression(),
        category="linear", complexity="low",
        notes="Ordinary least squares — the baseline.")
    add("Ridge Regression", Ridge(alpha=1.0),
        category="linear", complexity="low",
        notes="L2-regularised linear model; controls multicollinearity.")
    add("Lasso Regression", Lasso(alpha=0.1, max_iter=5000),
        category="linear", complexity="low",
        notes="L1-regularised; performs feature selection via sparsity.")
    add("Elastic Net", ElasticNet(alpha=0.1, l1_ratio=0.5, max_iter=5000),
        category="linear", complexity="low",
        notes="Combined L1+L2 penalty; balances Ridge and Lasso.")
    add("Bayesian Ridge", BayesianRidge(),
        category="linear", complexity="low",
        notes="Bayesian treatment of Ridge; gives uncertainty estimates.")
    add("Huber Regressor", HuberRegressor(max_iter=500),
        category="linear", complexity="low",
        notes="Robust to outliers via Huber loss function.")

    # ── Polynomial ───────────────────────────────────────────────
    for deg in (2, 3):
        pipe = Pipeline([
            ("poly", PolynomialFeatures(degree=deg, include_bias=False)),
            ("scaler", StandardScaler()),
            ("model", Ridge(alpha=1.0)),
        ])
        models.append({
            "name": f"Polynomial (degree {deg})",
            "pipeline": pipe,
            "category": "polynomial", "complexity": "low-medium",
            "notes": f"Degree-{deg} polynomial features + Ridge regularisation.",
        })

    # ── Instance-based ───────────────────────────────────────────
    add("K-Nearest Neighbors", KNeighborsRegressor(n_neighbors=5),
        category="instance-based", complexity="low",
        notes="Non-parametric; adapts to any relationship shape.")

    # ── SVM ───────────────────────────────────────────────────────
    if n_samples <= 10_000:
        add("SVR (RBF kernel)", SVR(kernel="rbf", C=1.0),
            category="kernel", complexity="medium",
            notes="Kernel trick captures nonlinearity; robust to outliers.")

    # ── Tree-based ───────────────────────────────────────────────
    add("Decision Tree", DecisionTreeRegressor(max_depth=8, random_state=42),
        category="tree", complexity="low",
        notes="Interpretable; handles interactions natively. Prone to overfit.")
    add("Random Forest", RandomForestRegressor(
            n_estimators=200, max_depth=12, n_jobs=-1, random_state=42),
        category="ensemble-tree", complexity="medium",
        notes="Bagged trees — excellent generalisation out of the box.")
    add("Extra Trees", ExtraTreesRegressor(
            n_estimators=200, max_depth=12, n_jobs=-1, random_state=42),
        category="ensemble-tree", complexity="medium",
        notes="Extremely randomised trees; lower variance than RF at the cost of higher bias.")
    add("Gradient Boosting (sklearn)", GradientBoostingRegressor(
            n_estimators=200, max_depth=5, learning_rate=0.1, random_state=42),
        category="ensemble-boosted", complexity="medium-high",
        notes="Sequential boosting with deviance loss. Strong tabular performer.")
    add("AdaBoost", AdaBoostRegressor(
            n_estimators=100, learning_rate=0.1, random_state=42),
        category="ensemble-boosted", complexity="medium",
        notes="Adaptive boosting; focuses on hard examples each round.")

    # ── XGBoost ──────────────────────────────────────────────────
    if _HAS_XGB:
        add("XGBoost", XGBRegressor(
                n_estimators=300, max_depth=6, learning_rate=0.1,
                subsample=0.8, colsample_bytree=0.8,
                reg_alpha=0.1, reg_lambda=1.0,
                n_jobs=-1, random_state=42, verbosity=0),
            category="ensemble-boosted", complexity="high",
            notes="Gradient boosting with regularisation, histogram binning, and GPU support.")

    # ── LightGBM ─────────────────────────────────────────────────
    if _HAS_LGBM:
        add("LightGBM", LGBMRegressor(
                n_estimators=300, max_depth=8, learning_rate=0.1,
                subsample=0.8, colsample_bytree=0.8,
                reg_alpha=0.1, reg_lambda=1.0,
                n_jobs=-1, random_state=42, verbose=-1),
            category="ensemble-boosted", complexity="high",
            notes="Leaf-wise boosting — faster than XGBoost on large data; native categorical support.")

    # ── Gaussian Process (small datasets only) ───────────────────
    if _HAS_GP and n_samples <= 2_000:
        kernel = ConstantKernel(1.0) * RBF(length_scale=1.0)
        add("Gaussian Process", GaussianProcessRegressor(
                kernel=kernel, n_restarts_optimizer=3, random_state=42),
            category="kernel", complexity="high",
            notes="Full probabilistic model with uncertainty; O(n³) scaling.")

    # ── Neural Network ───────────────────────────────────────────
    hidden = (128, 64) if n_samples > 500 else (64, 32)
    add("MLP Neural Network", MLPRegressor(
            hidden_layer_sizes=hidden, activation="relu",
            solver="adam", max_iter=1000, early_stopping=True,
            validation_fraction=0.15, random_state=42),
        category="neural-network", complexity="high",
        notes=f"Multi-layer perceptron ({hidden[0]}→{hidden[1]}); universal function approximator.")

    # Larger architecture if sufficient data
    if n_samples >= 2_000:
        add("MLP Neural Network (deep)", MLPRegressor(
                hidden_layer_sizes=(256, 128, 64), activation="relu",
                solver="adam", max_iter=1500, early_stopping=True,
                validation_fraction=0.15, random_state=42),
            category="neural-network", complexity="very-high",
            notes="Deeper MLP (256→128→64); benefits from larger datasets.")

    return models


def _build_classification_registry(n_samples: int, n_features: int, n_classes: int) -> List[Dict[str, Any]]:
    """Return (name, pipeline, meta) tuples for classification."""
    models: List[Dict[str, Any]] = []

    def add(name, estimator, *, category="", complexity="", notes=""):
        pipe = Pipeline([
            ("scaler", StandardScaler()),
            ("model", estimator),
        ])
        models.append({
            "name": name, "pipeline": pipe,
            "category": category, "complexity": complexity, "notes": notes,
        })

    # ── Linear family ────────────────────────────────────────────
    add("Logistic Regression", LogisticRegression(
            max_iter=2000, random_state=42),
        category="linear", complexity="low",
        notes="Probabilistic linear classifier; strong baseline.")
    add("Ridge Classifier", RidgeClassifier(alpha=1.0),
        category="linear", complexity="low",
        notes="L2-penalised least-squares classifier; very fast.")

    # ── Instance-based ───────────────────────────────────────────
    add("K-Nearest Neighbors", KNeighborsClassifier(n_neighbors=5),
        category="instance-based", complexity="low",
        notes="Non-parametric; decision boundary adapts to data shape.")

    # ── SVM ───────────────────────────────────────────────────────
    if n_samples <= 10_000:
        add("SVC (RBF kernel)", SVC(kernel="rbf", probability=True, random_state=42),
            category="kernel", complexity="medium",
            notes="Kernel SVM; excellent on small-to-medium datasets.")

    # ── Tree-based ───────────────────────────────────────────────
    add("Decision Tree", DecisionTreeClassifier(max_depth=8, random_state=42),
        category="tree", complexity="low",
        notes="Interpretable; handles nonlinearity natively.")
    add("Random Forest", RandomForestClassifier(
            n_estimators=200, max_depth=12, n_jobs=-1, random_state=42),
        category="ensemble-tree", complexity="medium",
        notes="Bagged trees; robust and high-performing on tabular data.")
    add("Extra Trees", ExtraTreesClassifier(
            n_estimators=200, max_depth=12, n_jobs=-1, random_state=42),
        category="ensemble-tree", complexity="medium",
        notes="Extremely randomised splits; fast with low variance.")
    add("Gradient Boosting (sklearn)", GradientBoostingClassifier(
            n_estimators=200, max_depth=5, learning_rate=0.1, random_state=42),
        category="ensemble-boosted", complexity="medium-high",
        notes="Sequential boosting; strong tabular classifier.")
    add("AdaBoost", AdaBoostClassifier(
            n_estimators=100, learning_rate=0.1, random_state=42),
        category="ensemble-boosted", complexity="medium",
        notes="Adaptive boosting; good with weak base learners.")

    # ── XGBoost ──────────────────────────────────────────────────
    if _HAS_XGB:
        add("XGBoost", XGBClassifier(
                n_estimators=300, max_depth=6, learning_rate=0.1,
                subsample=0.8, colsample_bytree=0.8,
                reg_alpha=0.1, reg_lambda=1.0,
                n_jobs=-1, random_state=42, verbosity=0,
                eval_metric="logloss"),
            category="ensemble-boosted", complexity="high",
            notes="Regularised gradient boosting; state-of-the-art on tabular classification.")

    # ── LightGBM ─────────────────────────────────────────────────
    if _HAS_LGBM:
        add("LightGBM", LGBMClassifier(
                n_estimators=300, max_depth=8, learning_rate=0.1,
                subsample=0.8, colsample_bytree=0.8,
                reg_alpha=0.1, reg_lambda=1.0,
                n_jobs=-1, random_state=42, verbose=-1),
            category="ensemble-boosted", complexity="high",
            notes="Leaf-wise boosting; fast and memory-efficient.")

    # ── Probabilistic ────────────────────────────────────────────
    add("Gaussian Naive Bayes", GaussianNB(),
        category="probabilistic", complexity="low",
        notes="Assumes feature independence; surprisingly effective baseline.")
    if n_features <= 50 and n_samples > 50:
        add("Quadratic Discriminant Analysis", QuadraticDiscriminantAnalysis(),
            category="probabilistic", complexity="low",
            notes="Fits per-class Gaussians; captures class-specific covariance.")

    # ── Neural Network ───────────────────────────────────────────
    hidden = (128, 64) if n_samples > 500 else (64, 32)
    add("MLP Neural Network", MLPClassifier(
            hidden_layer_sizes=hidden, activation="relu",
            solver="adam", max_iter=1000, early_stopping=True,
            validation_fraction=0.15, random_state=42),
        category="neural-network", complexity="high",
        notes=f"Multi-layer perceptron ({hidden[0]}→{hidden[1]}); flexible nonlinear classifier.")

    if n_samples >= 2_000:
        add("MLP Neural Network (deep)", MLPClassifier(
                hidden_layer_sizes=(256, 128, 64), activation="relu",
                solver="adam", max_iter=1500, early_stopping=True,
                validation_fraction=0.15, random_state=42),
            category="neural-network", complexity="very-high",
            notes="Deeper MLP (256→128→64) for large-sample problems.")

    return models


# =====================================================================
# AutoEvaluator
# =====================================================================

class AutoEvaluator:
    """Fit, cross-validate, and rank ML models on your data.

    Usage
    -----
    >>> evaluator = ip.AutoEvaluator()
    >>> results = evaluator.run(X, y)              # auto-detects task
    >>> evaluator.print_report(results)
    >>> evaluator.plot_comparison(results)          # bar chart of scores
    >>> best = results[0]
    >>> best["pipeline"].fit(X, y)                  # refit winner on full data
    >>> predictions = best["pipeline"].predict(X_new)

    Parameters for run()
    --------------------
    X : array-like of shape (n_samples,) or (n_samples, n_features)
        Feature matrix.  A 1-D array is automatically reshaped.
    y : array-like of shape (n_samples,)
        Target vector.
    task : 'auto', 'regression', or 'classification'
        Auto-detection looks at the number of unique y values.
    cv : int
        Number of cross-validation folds (default 5).
    sort_by : str
        Primary metric for ranking.  Regression default: 'r2'.
        Classification default: 'f1_weighted'.
    top_k : int or None
        Return only the top-k models (None = all).
    include : list of str or None
        If provided, only evaluate models whose names contain one of
        these substrings (case-insensitive).
    exclude : list of str or None
        Skip models whose names contain one of these substrings.
    """

    # ── Metric sets ──────────────────────────────────────────────

    _REG_METRICS = {
        "r2":                "r2",
        "neg_rmse":          "neg_root_mean_squared_error",
        "neg_mae":           "neg_mean_absolute_error",
        "neg_mape":          "neg_mean_absolute_percentage_error",
    }

    _CLF_METRICS = {
        "accuracy":          "accuracy",
        "f1_weighted":       "f1_weighted",
        "precision_weighted": "precision_weighted",
        "recall_weighted":   "recall_weighted",
        "roc_auc_ovr":       "roc_auc_ovr",
    }

    # ── Public API ───────────────────────────────────────────────

    def run(
        self,
        X: Any,
        y: Any,
        *,
        task: Literal["auto", "regression", "classification"] = "auto",
        cv: int = 5,
        sort_by: Optional[str] = None,
        top_k: Optional[int] = None,
        include: Optional[Sequence[str]] = None,
        exclude: Optional[Sequence[str]] = None,
        verbose: bool = True,
    ) -> List[Dict[str, Any]]:
        """Cross-validate every applicable model and return ranked results."""

        X = np.asarray(X)
        y = np.asarray(y)

        # Reshape 1-D feature vector
        if X.ndim == 1:
            X = X.reshape(-1, 1)

        n_samples, n_features = X.shape

        # ── Task detection ───────────────────────────────────────
        if task == "auto":
            task = self._detect_task(y)
        self._task = task

        if verbose:
            print(f"\n{'='*72}")
            print(f"  INSIGHTPLOT AUTO-EVALUATOR")
            print(f"{'='*72}")
            print(f"  Task          : {task}")
            print(f"  Samples       : {n_samples:,}")
            print(f"  Features      : {n_features}")
            print(f"  CV folds      : {cv}")
            if task == "classification":
                unique, counts = np.unique(y, return_counts=True)
                print(f"  Classes       : {len(unique)}")
                for u, c in zip(unique, counts):
                    print(f"    class {u}: {c:,}  ({c/n_samples:.1%})")
            print()

        # ── Build model registry ─────────────────────────────────
        if task == "regression":
            registry = _build_regression_registry(n_samples, n_features)
            scoring = self._REG_METRICS
            default_sort = "r2"
        else:
            n_classes = len(np.unique(y))
            registry = _build_classification_registry(n_samples, n_features, n_classes)
            scoring = dict(self._CLF_METRICS)
            # roc_auc_ovr needs probability support and > 2 classes
            if n_classes == 2:
                scoring["roc_auc_ovr"] = "roc_auc"
            default_sort = "f1_weighted"

        sort_by = sort_by or default_sort

        # ── Filter ───────────────────────────────────────────────
        if include:
            inc_lower = [s.lower() for s in include]
            registry = [m for m in registry
                        if any(sub in m["name"].lower() for sub in inc_lower)]
        if exclude:
            exc_lower = [s.lower() for s in exclude]
            registry = [m for m in registry
                        if not any(sub in m["name"].lower() for sub in exc_lower)]

        # ── Cross-validate each model ────────────────────────────
        cv_splitter = (
            StratifiedKFold(n_splits=cv, shuffle=True, random_state=42)
            if task == "classification"
            else KFold(n_splits=cv, shuffle=True, random_state=42)
        )

        results: List[Dict[str, Any]] = []
        total = len(registry)

        for i, entry in enumerate(registry, 1):
            name = entry["name"]
            if verbose:
                print(f"  [{i:2d}/{total}] {name:<38s}", end="", flush=True)

            t0 = time.perf_counter()
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    cv_results = cross_validate(
                        entry["pipeline"], X, y,
                        scoring=scoring,
                        cv=cv_splitter,
                        n_jobs=-1,
                        return_train_score=False,
                        error_score="raise",
                    )
                elapsed = time.perf_counter() - t0

                # Aggregate scores
                scores: Dict[str, Any] = {}
                for key, sklearn_key in scoring.items():
                    raw = cv_results[f"test_{key}"]
                    scores[f"{key}_mean"] = float(np.mean(raw))
                    scores[f"{key}_std"] = float(np.std(raw))
                    scores[f"{key}_folds"] = raw.tolist()

                # Friendly RMSE / MAE (flip sign)
                if task == "regression":
                    scores["rmse"] = -scores["neg_rmse_mean"]
                    scores["rmse_std"] = scores["neg_rmse_std"]
                    scores["mae"] = -scores["neg_mae_mean"]
                    scores["mae_std"] = scores["neg_mae_std"]
                    scores["mape"] = -scores.get("neg_mape_mean", 0)

                primary_score = scores.get(f"{sort_by}_mean", 0)

                result = {
                    "name": name,
                    "category": entry["category"],
                    "complexity": entry["complexity"],
                    "notes": entry["notes"],
                    "pipeline": entry["pipeline"],
                    "scores": scores,
                    "primary_score": primary_score,
                    "sort_metric": sort_by,
                    "elapsed_seconds": elapsed,
                    "status": "ok",
                }
                results.append(result)

                if verbose:
                    metric_display = (
                        f"R²={primary_score:.4f}"
                        if task == "regression"
                        else f"{sort_by}={primary_score:.4f}"
                    )
                    print(f"  {metric_display}  ({elapsed:.1f}s)")

            except Exception as e:
                elapsed = time.perf_counter() - t0
                results.append({
                    "name": name,
                    "category": entry["category"],
                    "complexity": entry["complexity"],
                    "notes": entry["notes"],
                    "pipeline": entry["pipeline"],
                    "scores": {},
                    "primary_score": float("-inf"),
                    "sort_metric": sort_by,
                    "elapsed_seconds": elapsed,
                    "status": f"FAILED: {e}",
                })
                if verbose:
                    print(f"  FAILED ({type(e).__name__})")

        # ── Rank ─────────────────────────────────────────────────
        results.sort(key=lambda r: r["primary_score"], reverse=True)
        for rank, r in enumerate(results, 1):
            r["rank"] = rank

        if top_k:
            results = results[:top_k]

        if verbose:
            print(f"\n  Evaluation complete — {len(results)} models ranked.")

        return results

    # ── Report ───────────────────────────────────────────────────

    def print_report(
        self,
        results: List[Dict[str, Any]],
        top_k: Optional[int] = None,
    ) -> None:
        """Pretty-print the ranked evaluation results."""
        if not results:
            print("No results to display.")
            return

        task = self._task
        items = results[:top_k] if top_k else results

        print(f"\n{'='*76}")
        print(f"  INSIGHTPLOT MODEL EVALUATION — RANKED RESULTS")
        print(f"{'='*76}\n")

        if task == "regression":
            # Header
            print(f"  {'Rank':<5s} {'Model':<38s} {'R²':>8s} {'RMSE':>10s} {'MAE':>10s} {'Time':>7s}")
            print(f"  {'─'*5} {'─'*38} {'─'*8} {'─'*10} {'─'*10} {'─'*7}")
            for r in items:
                s = r["scores"]
                if r["status"] == "ok":
                    print(
                        f"  {r['rank']:<5d} {r['name']:<38s} "
                        f"{s.get('r2_mean', 0):>8.4f} "
                        f"{s.get('rmse', 0):>10.4f} "
                        f"{s.get('mae', 0):>10.4f} "
                        f"{r['elapsed_seconds']:>6.1f}s"
                    )
                else:
                    print(f"  {r['rank']:<5d} {r['name']:<38s}  {r['status']}")

            # Detail on top 3
            print(f"\n  {'─'*76}")
            print(f"  TOP MODEL DETAILS\n")
            for r in items[:3]:
                if r["status"] != "ok":
                    continue
                s = r["scores"]
                print(f"  #{r['rank']}  {r['name']}")
                print(f"      Category    : {r['category']}")
                print(f"      Complexity  : {r['complexity']}")
                print(f"      R²          : {s['r2_mean']:.4f} ± {s['r2_std']:.4f}")
                print(f"      RMSE        : {s['rmse']:.4f} ± {s['rmse_std']:.4f}")
                print(f"      MAE         : {s['mae']:.4f} ± {s['mae_std']:.4f}")
                if s.get("mape"):
                    print(f"      MAPE        : {s['mape']:.4f}")
                print(f"      Fold R²     : {[f'{v:.4f}' for v in s['r2_folds']]}")
                print(f"      Notes       : {r['notes']}")
                print()

        else:  # classification
            print(f"  {'Rank':<5s} {'Model':<38s} {'F1(w)':>8s} {'Acc':>8s} {'Prec(w)':>8s} {'Rec(w)':>8s} {'Time':>7s}")
            print(f"  {'─'*5} {'─'*38} {'─'*8} {'─'*8} {'─'*8} {'─'*8} {'─'*7}")
            for r in items:
                s = r["scores"]
                if r["status"] == "ok":
                    print(
                        f"  {r['rank']:<5d} {r['name']:<38s} "
                        f"{s.get('f1_weighted_mean', 0):>8.4f} "
                        f"{s.get('accuracy_mean', 0):>8.4f} "
                        f"{s.get('precision_weighted_mean', 0):>8.4f} "
                        f"{s.get('recall_weighted_mean', 0):>8.4f} "
                        f"{r['elapsed_seconds']:>6.1f}s"
                    )
                else:
                    print(f"  {r['rank']:<5d} {r['name']:<38s}  {r['status']}")

            print(f"\n  {'─'*76}")
            print(f"  TOP MODEL DETAILS\n")
            for r in items[:3]:
                if r["status"] != "ok":
                    continue
                s = r["scores"]
                print(f"  #{r['rank']}  {r['name']}")
                print(f"      Category    : {r['category']}")
                print(f"      Complexity  : {r['complexity']}")
                print(f"      F1 (wtd)    : {s['f1_weighted_mean']:.4f} ± {s['f1_weighted_std']:.4f}")
                print(f"      Accuracy    : {s['accuracy_mean']:.4f} ± {s['accuracy_std']:.4f}")
                print(f"      Precision   : {s['precision_weighted_mean']:.4f} ± {s['precision_weighted_std']:.4f}")
                print(f"      Recall      : {s['recall_weighted_mean']:.4f} ± {s['recall_weighted_std']:.4f}")
                auc_key = "roc_auc_ovr_mean"
                if auc_key in s:
                    print(f"      ROC AUC     : {s[auc_key]:.4f} ± {s.get('roc_auc_ovr_std', 0):.4f}")
                print(f"      Notes       : {r['notes']}")
                print()

        print(f"{'='*76}")

    # ── Comparison plot ──────────────────────────────────────────

    def plot_comparison(
        self,
        results: List[Dict[str, Any]],
        *,
        top_k: Optional[int] = 15,
        metric: Optional[str] = None,
        figsize: Tuple[float, float] = (12, 7),
        title: Optional[str] = None,
        save_path: Optional[str] = None,
    ):
        """Horizontal bar chart comparing model performance.

        Returns an InsightPlot Figure.
        """
        import matplotlib.pyplot as plt
        from insightplot.styles import get_palette

        items = [r for r in results if r["status"] == "ok"]
        if top_k:
            items = items[:top_k]
        items = list(reversed(items))  # best at top

        task = self._task
        if metric is None:
            metric = "r2" if task == "regression" else "f1_weighted"

        names = [r["name"] for r in items]
        means = [r["scores"].get(f"{metric}_mean", 0) for r in items]
        stds = [r["scores"].get(f"{metric}_std", 0) for r in items]

        palette = get_palette()
        colors = []
        cat_color_map = {}
        color_idx = 0
        for r in items:
            cat = r["category"]
            if cat not in cat_color_map:
                cat_color_map[cat] = palette[color_idx % len(palette)]
                color_idx += 1
            colors.append(cat_color_map[cat])

        fig, ax = plt.subplots(figsize=figsize)
        y_pos = np.arange(len(names))

        bars = ax.barh(y_pos, means, xerr=stds, color=colors,
                        edgecolor="white", linewidth=0.5, alpha=0.88,
                        capsize=3, error_kw={"linewidth": 1.0, "alpha": 0.6})

        ax.set_yticks(y_pos)
        ax.set_yticklabels(names, fontsize=9)
        metric_label = metric.replace("_", " ").title()
        ax.set_xlabel(f"{metric_label} (CV mean ± std)", fontsize=11)
        ax.set_title(
            title or f"Model Comparison — {metric_label} ({task.title()})",
            fontsize=13, fontweight="bold", pad=12,
        )

        # Value labels on bars
        for bar_obj, mean, std in zip(bars, means, stds):
            ax.text(
                mean + std + 0.005, bar_obj.get_y() + bar_obj.get_height() / 2,
                f"{mean:.4f}",
                va="center", fontsize=8, fontfamily="monospace",
            )

        # Category legend
        from matplotlib.patches import Patch
        legend_elements = [
            Patch(facecolor=c, label=cat.replace("-", " ").title())
            for cat, c in cat_color_map.items()
        ]
        ax.legend(handles=legend_elements, loc="lower right", fontsize=8,
                  title="Category", title_fontsize=9)

        ax.grid(axis="x", alpha=0.3)
        fig.tight_layout()

        if save_path:
            fig.savefig(save_path, bbox_inches="tight")

        return fig

    # ── Helpers ───────────────────────────────────────────────────

    def _detect_task(self, y: np.ndarray) -> str:
        unique = np.unique(y)
        n_unique = len(unique)
        ratio = n_unique / len(y)

        # Binary or small number of classes → classification
        if n_unique <= 20 and ratio < 0.05:
            return "classification"
        # All integers with limited range → likely classification
        if np.all(y == np.floor(y)) and n_unique <= 30:
            return "classification"
        return "regression"

    def to_dataframe(self, results: List[Dict[str, Any]]) -> "pd.DataFrame":
        """Convert results to a pandas DataFrame for further analysis."""
        rows = []
        for r in results:
            row = {
                "rank": r["rank"],
                "name": r["name"],
                "category": r["category"],
                "complexity": r["complexity"],
                "primary_score": r["primary_score"],
                "elapsed_seconds": r["elapsed_seconds"],
                "status": r["status"],
            }
            for k, v in r["scores"].items():
                if not k.endswith("_folds"):
                    row[k] = v
            rows.append(row)
        return pd.DataFrame(rows)
