"""
InsightPlot ModelAdvisor — Analyzes data characteristics and recommends
the predictive models most likely to perform well.

This is the unique differentiator: you plot your data, and the library
tells you *what to try next* for prediction.
"""

from __future__ import annotations
import warnings
import numpy as np
from scipy import stats as sp_stats
from typing import Any, Dict, List, Optional, Tuple

from insightplot.fits import FitToolkit


class DataProfile:
    """Statistical fingerprint of an x/y dataset."""

    def __init__(self, x: np.ndarray, y: np.ndarray) -> None:
        self.x = np.asarray(x, dtype=float)
        self.y = np.asarray(y, dtype=float)
        mask = np.isfinite(self.x) & np.isfinite(self.y)
        self.x = self.x[mask]
        self.y = self.y[mask]
        self.n = len(self.x)
        self._compute()

    def _compute(self) -> None:
        x, y = self.x, self.y

        # Basic stats
        self.x_mean, self.y_mean = np.mean(x), np.mean(y)
        self.x_std, self.y_std = np.std(x, ddof=1), np.std(y, ddof=1)
        self.y_range = np.ptp(y)
        self.y_min, self.y_max = np.min(y), np.max(y)

        # Correlation
        if self.n > 2:
            self.pearson_r, self.pearson_p = sp_stats.pearsonr(x, y)
            self.spearman_r, self.spearman_p = sp_stats.spearmanr(x, y)
        else:
            self.pearson_r = self.spearman_r = 0.0
            self.pearson_p = self.spearman_p = 1.0

        # Linearity gap: difference between Pearson and Spearman
        self.linearity_gap = abs(abs(self.spearman_r) - abs(self.pearson_r))

        # Monotonicity
        diffs = np.diff(y[np.argsort(x)])
        n_pos = np.sum(diffs > 0)
        n_neg = np.sum(diffs < 0)
        total = n_pos + n_neg
        self.monotonicity = abs(n_pos - n_neg) / total if total > 0 else 0

        # Normality of residuals (from linear fit)
        if self.n > 8:
            coeffs = np.polyfit(x, y, 1)
            residuals = y - np.polyval(coeffs, x)
            _, self.residual_normality_p = sp_stats.shapiro(
                residuals[:5000] if len(residuals) > 5000 else residuals
            )
        else:
            self.residual_normality_p = 1.0

        # Heteroscedasticity check (split residuals into halves)
        if self.n > 20:
            sort_idx = np.argsort(x)
            residuals_sorted = (y - np.polyval(np.polyfit(x, y, 1), x))[sort_idx]
            mid = self.n // 2
            var_lo = np.var(residuals_sorted[:mid])
            var_hi = np.var(residuals_sorted[mid:])
            self.heteroscedasticity_ratio = max(var_hi, var_lo) / max(min(var_hi, var_lo), 1e-10)
        else:
            self.heteroscedasticity_ratio = 1.0

        # Detect if y looks binary / categorical
        unique_y = np.unique(y)
        self.y_is_binary = len(unique_y) == 2
        self.y_n_unique = len(unique_y)
        self.y_is_count = np.all(y == np.floor(y)) and np.min(y) >= 0

        # Detect if y looks bounded (e.g. saturation / logistic)
        if self.n > 10:
            sorted_y = np.sort(y)
            top_10pct = sorted_y[int(0.9 * self.n):]
            bot_10pct = sorted_y[:int(0.1 * self.n)]
            self.y_upper_plateau = np.std(top_10pct) < 0.05 * self.y_range if self.y_range > 0 else False
            self.y_lower_plateau = np.std(bot_10pct) < 0.05 * self.y_range if self.y_range > 0 else False
        else:
            self.y_upper_plateau = False
            self.y_lower_plateau = False

        # Nonlinearity score from polynomial improvement over linear
        if self.n > 5:
            lin_r2 = self._quick_r2(1)
            quad_r2 = self._quick_r2(2)
            cub_r2 = self._quick_r2(3)
            self.nonlinearity_score = max(0, quad_r2 - lin_r2)
            self.cubic_boost = max(0, cub_r2 - quad_r2)
            self.linear_r2 = lin_r2
        else:
            self.nonlinearity_score = 0.0
            self.cubic_boost = 0.0
            self.linear_r2 = 0.0

        # Noise estimate
        if self.n > 10:
            sort_idx = np.argsort(x)
            y_sorted = y[sort_idx]
            local_diffs = np.abs(np.diff(y_sorted))
            self.noise_level = np.median(local_diffs) / (self.y_range + 1e-10)
        else:
            self.noise_level = 0.0

        # Sample size category
        if self.n < 30:
            self.size_cat = "tiny"
        elif self.n < 200:
            self.size_cat = "small"
        elif self.n < 2000:
            self.size_cat = "medium"
        elif self.n < 50000:
            self.size_cat = "large"
        else:
            self.size_cat = "very_large"

    def _quick_r2(self, deg: int) -> float:
        coeffs = np.polyfit(self.x, self.y, deg)
        y_hat = np.polyval(coeffs, self.x)
        ss_res = np.sum((self.y - y_hat) ** 2)
        ss_tot = np.sum((self.y - self.y_mean) ** 2)
        return 1 - ss_res / ss_tot if ss_tot > 0 else 0.0


# ======================================================================
# Model recommendation rules
# ======================================================================

_MODEL_DB: List[Dict[str, Any]] = [
    {
        "name": "Linear Regression (OLS)",
        "category": "regression",
        "complexity": "low",
        "sklearn": "sklearn.linear_model.LinearRegression",
        "strengths": "Interpretable, fast, works well when relationship is genuinely linear.",
        "weaknesses": "Cannot capture nonlinear patterns; sensitive to outliers.",
    },
    {
        "name": "Ridge / Lasso Regression",
        "category": "regression",
        "complexity": "low",
        "sklearn": "sklearn.linear_model.Ridge / Lasso",
        "strengths": "Regularisation prevents overfitting with many features; feature selection (Lasso).",
        "weaknesses": "Still linear; requires feature engineering for nonlinearity.",
    },
    {
        "name": "Polynomial Regression",
        "category": "regression",
        "complexity": "low-medium",
        "sklearn": "sklearn.preprocessing.PolynomialFeatures + LinearRegression",
        "strengths": "Captures smooth nonlinear relationships with a simple model.",
        "weaknesses": "Prone to wild extrapolation; degree selection is critical.",
    },
    {
        "name": "Support Vector Regression (SVR)",
        "category": "regression",
        "complexity": "medium",
        "sklearn": "sklearn.svm.SVR",
        "strengths": "Robust to outliers; kernel trick captures nonlinearity.",
        "weaknesses": "Slow for large datasets; requires careful kernel/hyperparameter tuning.",
    },
    {
        "name": "Decision Tree Regressor",
        "category": "regression",
        "complexity": "low",
        "sklearn": "sklearn.tree.DecisionTreeRegressor",
        "strengths": "No assumptions about data distribution; handles interactions natively.",
        "weaknesses": "Overfits easily; produces step-function predictions.",
    },
    {
        "name": "Random Forest Regressor",
        "category": "regression",
        "complexity": "medium",
        "sklearn": "sklearn.ensemble.RandomForestRegressor",
        "strengths": "Excellent generalization; handles nonlinearity, interactions, and noise.",
        "weaknesses": "Less interpretable; can be slow on very large data.",
    },
    {
        "name": "Gradient Boosted Trees (XGBoost / LightGBM)",
        "category": "regression",
        "complexity": "medium-high",
        "sklearn": "xgboost.XGBRegressor / lightgbm.LGBMRegressor",
        "strengths": "State-of-the-art tabular performance; handles heteroscedasticity and noise well.",
        "weaknesses": "Requires hyperparameter tuning; risk of overfitting with small data.",
    },
    {
        "name": "K-Nearest Neighbors Regressor",
        "category": "regression",
        "complexity": "low",
        "sklearn": "sklearn.neighbors.KNeighborsRegressor",
        "strengths": "Non-parametric; adapts to any shape of relationship.",
        "weaknesses": "Slow at prediction time for large data; sensitive to scale and irrelevant features.",
    },
    {
        "name": "Gaussian Process Regression",
        "category": "regression",
        "complexity": "high",
        "sklearn": "sklearn.gaussian_process.GaussianProcessRegressor",
        "strengths": "Provides uncertainty estimates; flexible kernel combinations.",
        "weaknesses": "Scales O(n³) — impractical beyond ~5 000 points.",
    },
    {
        "name": "Neural Network (MLP Regressor)",
        "category": "regression",
        "complexity": "high",
        "sklearn": "sklearn.neural_network.MLPRegressor",
        "strengths": "Universal function approximator; captures complex patterns.",
        "weaknesses": "Needs lots of data; sensitive to hyperparameters and scaling.",
    },
    {
        "name": "Logistic Regression",
        "category": "classification",
        "complexity": "low",
        "sklearn": "sklearn.linear_model.LogisticRegression",
        "strengths": "Interpretable probabilities; fast; strong baseline for binary classification.",
        "weaknesses": "Assumes linear decision boundary in feature space.",
    },
    {
        "name": "Random Forest Classifier",
        "category": "classification",
        "complexity": "medium",
        "sklearn": "sklearn.ensemble.RandomForestClassifier",
        "strengths": "Robust out-of-the-box performance; handles nonlinearity and interactions.",
        "weaknesses": "Less interpretable; memory-intensive with many trees.",
    },
    {
        "name": "Gradient Boosted Classifier (XGBoost / LightGBM)",
        "category": "classification",
        "complexity": "medium-high",
        "sklearn": "xgboost.XGBClassifier / lightgbm.LGBMClassifier",
        "strengths": "Top-tier tabular classification; handles class imbalance with scale_pos_weight.",
        "weaknesses": "Hyperparameter tuning required; slower to train.",
    },
    {
        "name": "Poisson / Negative Binomial Regression",
        "category": "regression",
        "complexity": "low-medium",
        "sklearn": "statsmodels.GLM(family=Poisson) or sklearn.linear_model.PoissonRegressor",
        "strengths": "Appropriate for count data; respects non-negativity constraint.",
        "weaknesses": "Assumes specific mean-variance relationship.",
    },
    {
        "name": "Elastic Net",
        "category": "regression",
        "complexity": "low",
        "sklearn": "sklearn.linear_model.ElasticNet",
        "strengths": "Combines L1 and L2 penalties; good when features are correlated.",
        "weaknesses": "Still fundamentally linear.",
    },
]


class ModelAdvisor:
    """Analyzes data and recommends predictive models ranked by suitability."""

    def evaluate(
        self,
        x: np.ndarray,
        y: np.ndarray,
        top_k: int = 5,
    ) -> List[Dict[str, Any]]:
        """Score every model in the database against the data profile.

        Parameters
        ----------
        x, y : array-like
        top_k : int
            Number of top recommendations to return.

        Returns
        -------
        List of dicts with keys: name, score, rationale, category,
        complexity, sklearn, strengths, weaknesses, profile_summary.
        """
        profile = DataProfile(x, y)
        scored: List[Dict[str, Any]] = []

        for model in _MODEL_DB:
            score, reasons = self._score_model(model, profile)
            scored.append({
                **model,
                "score": round(score, 2),
                "rationale": reasons,
            })

        scored.sort(key=lambda m: m["score"], reverse=True)

        # Attach a profile summary to the first entry
        summary = self._profile_summary(profile)
        for entry in scored[:top_k]:
            entry["profile_summary"] = summary

        return scored[:top_k]

    # ------------------------------------------------------------------
    # Scoring logic
    # ------------------------------------------------------------------

    def _score_model(
        self, model: Dict[str, Any], p: DataProfile
    ) -> Tuple[float, List[str]]:
        score = 50.0  # neutral baseline
        reasons: List[str] = []
        name = model["name"]
        cat = model["category"]

        # ---- Task-type matching ----
        if p.y_is_binary:
            if cat == "classification":
                score += 25
                reasons.append("Target is binary → classification model appropriate.")
            else:
                score -= 30
                reasons.append("Target is binary but this is a regression model (consider classification).")

        elif p.y_is_count and "Poisson" in name:
            score += 20
            reasons.append("Target looks like count data (non-negative integers) → Poisson family suitable.")

        elif cat == "classification" and not p.y_is_binary:
            score -= 30
            reasons.append("Target is continuous — classification model not appropriate here.")

        # ---- Linearity assessment ----
        if cat == "regression" or cat == "classification":
            if p.linear_r2 > 0.85 and p.nonlinearity_score < 0.02:
                if "Linear" in name or "Ridge" in name or "Lasso" in name or "Elastic" in name:
                    score += 20
                    reasons.append(f"Strong linear pattern (R²={p.linear_r2:.3f}); linear model is a good fit.")
                if "Polynomial" in name:
                    score += 5
                    reasons.append("Relationship is mostly linear; polynomial may overfit.")
            elif p.nonlinearity_score > 0.05:
                if "Linear" in name and "Logistic" not in name:
                    score -= 10
                    reasons.append(f"Significant nonlinearity detected (Δ R²={p.nonlinearity_score:.3f}); linear model will underfit.")
                if "Polynomial" in name:
                    score += 15
                    reasons.append(f"Nonlinear pattern (Δ R²={p.nonlinearity_score:.3f}); polynomial can capture this.")
                if "Random Forest" in name or "Gradient" in name:
                    score += 15
                    reasons.append("Nonlinear relationship benefits from tree-based flexibility.")
                if "SVR" in name or "Neural" in name:
                    score += 10
                    reasons.append("Nonlinearity present — kernel/network methods applicable.")

        # ---- Monotonicity ----
        if p.monotonicity < 0.3 and not p.y_is_binary:
            if "Linear" in name or "Logistic" in name:
                score -= 10
                reasons.append("Data is non-monotonic; model assumes monotone relationship.")
            if "Random Forest" in name or "Gradient" in name or "Neural" in name:
                score += 5
                reasons.append("Non-monotonic pattern → flexible model advantageous.")

        # ---- Sample size constraints ----
        if p.size_cat == "tiny":
            if "Gaussian Process" in name:
                score += 10
                reasons.append("Very small dataset — GP's uncertainty quantification is valuable.")
            if "Neural" in name or "Gradient" in name:
                score -= 15
                reasons.append("Very small dataset — complex models risk severe overfitting.")
            if "Linear" in name or "Ridge" in name:
                score += 10
                reasons.append("Small sample favors simple, low-variance models.")
        elif p.size_cat in ("large", "very_large"):
            if "Gaussian Process" in name:
                score -= 25
                reasons.append(f"Dataset has {p.n:,} points — GP scales O(n³), impractical.")
            if "KNN" in name:
                score -= 10
                reasons.append("Large dataset makes KNN slow at prediction time.")
            if "Gradient" in name or "Random Forest" in name:
                score += 10
                reasons.append("Large dataset — ensemble methods have enough data to generalize well.")
            if "Neural" in name:
                score += 10
                reasons.append("Large dataset supports deeper learning without overfitting.")

        # ---- Noise level ----
        if p.noise_level > 0.3:
            if "Decision Tree" in name and "Random Forest" not in name:
                score -= 10
                reasons.append("High noise — single decision tree will overfit to noise.")
            if "Random Forest" in name or "Gradient" in name:
                score += 5
                reasons.append("Ensembling helps average out noise.")
            if "Ridge" in name or "Lasso" in name or "Elastic" in name:
                score += 5
                reasons.append("Regularisation helps in noisy settings.")

        # ---- Heteroscedasticity ----
        if p.heteroscedasticity_ratio > 3.0:
            if "Linear" in name and "Logistic" not in name:
                score -= 5
                reasons.append("Heteroscedastic residuals — OLS assumptions violated.")
            if "Gradient" in name or "Random Forest" in name:
                score += 5
                reasons.append("Tree-based models are robust to non-constant variance.")

        # ---- Plateau / saturation ----
        if p.y_upper_plateau or p.y_lower_plateau:
            if "Linear" in name and "Logistic" not in name:
                score -= 10
                reasons.append("Data shows saturation/plateau — linear model can't capture asymptotic behaviour.")
            if "Logistic" in name or "SVR" in name:
                score += 10
                reasons.append("Saturation pattern suits logistic/bounded models.")
            if "Neural" in name or "Gradient" in name:
                score += 5

        # Clamp score
        score = max(0, min(100, score))
        return score, reasons

    # ------------------------------------------------------------------
    # Report
    # ------------------------------------------------------------------

    @staticmethod
    def _profile_summary(p: DataProfile) -> Dict[str, Any]:
        return {
            "n_samples": p.n,
            "size_category": p.size_cat,
            "pearson_r": round(p.pearson_r, 4),
            "spearman_r": round(p.spearman_r, 4),
            "linear_r2": round(p.linear_r2, 4),
            "nonlinearity_score": round(p.nonlinearity_score, 4),
            "monotonicity": round(p.monotonicity, 4),
            "noise_level": round(p.noise_level, 4),
            "heteroscedasticity_ratio": round(p.heteroscedasticity_ratio, 2),
            "y_is_binary": p.y_is_binary,
            "y_is_count": p.y_is_count,
            "y_has_plateau": p.y_upper_plateau or p.y_lower_plateau,
        }

    @staticmethod
    def print_report(results: List[Dict[str, Any]]) -> None:
        """Pretty-print the recommendation report to stdout."""
        if not results:
            print("No model recommendations available.")
            return

        profile = results[0].get("profile_summary", {})

        print("=" * 72)
        print("  INSIGHTPLOT MODEL ADVISOR — DATA ANALYSIS & RECOMMENDATIONS")
        print("=" * 72)

        if profile:
            print("\n  DATA PROFILE")
            print("  " + "-" * 40)
            print(f"  Samples           : {profile.get('n_samples', '?'):,}")
            print(f"  Size category     : {profile.get('size_category', '?')}")
            print(f"  Pearson r         : {profile.get('pearson_r', 0):.4f}")
            print(f"  Spearman ρ        : {profile.get('spearman_r', 0):.4f}")
            print(f"  Linear R²         : {profile.get('linear_r2', 0):.4f}")
            print(f"  Nonlinearity Δ    : {profile.get('nonlinearity_score', 0):.4f}")
            print(f"  Monotonicity      : {profile.get('monotonicity', 0):.4f}")
            print(f"  Noise level       : {profile.get('noise_level', 0):.4f}")
            print(f"  Heteroscedasticity: {profile.get('heteroscedasticity_ratio', 1):.2f}x")
            yn = lambda v: "Yes" if v else "No"
            print(f"  Binary target     : {yn(profile.get('y_is_binary'))}")
            print(f"  Count target      : {yn(profile.get('y_is_count'))}")
            print(f"  Plateau detected  : {yn(profile.get('y_has_plateau'))}")

        print(f"\n  TOP {len(results)} MODEL RECOMMENDATIONS")
        print("  " + "-" * 40)

        for i, m in enumerate(results, 1):
            print(f"\n  #{i}  {m['name']}  (Score: {m['score']}/100)")
            print(f"       Category   : {m['category']}")
            print(f"       Complexity : {m['complexity']}")
            print(f"       Import     : {m['sklearn']}")
            print(f"       Strengths  : {m['strengths']}")
            print(f"       Weaknesses : {m['weaknesses']}")
            if m["rationale"]:
                print("       Reasoning  :")
                for r in m["rationale"]:
                    print(f"         • {r}")

        print("\n" + "=" * 72)
