"""
InsightPlot FitToolkit — regression and curve fitting with R², equations,
and confidence intervals.

Supported methods: linear, polynomial, exponential, logarithmic, power,
logistic, lowess.
"""

from __future__ import annotations
import warnings
import numpy as np
from scipy import optimize, stats
from typing import Any, Callable, Dict, List, Optional


class FitToolkit:
    """Static toolkit for fitting curves to x/y data."""

    METHODS = [
        "linear", "polynomial", "exponential", "logarithmic",
        "power", "logistic", "lowess",
    ]

    # ------------------------------------------------------------------
    # Main dispatcher
    # ------------------------------------------------------------------

    @staticmethod
    def fit(
        x: np.ndarray,
        y: np.ndarray,
        method: str = "linear",
        degree: int = 2,
        ci_level: float = 0.95,
    ) -> Dict[str, Any]:
        """Fit a curve and return a results dict.

        Returns
        -------
        dict with keys:
            method       : str
            coefficients : array-like
            r_squared    : float
            predict      : callable(x) -> y
            equation     : str (human-readable)
            residuals    : np.ndarray
            ci_lower     : callable (if applicable)
            ci_upper     : callable (if applicable)
        """
        x = np.asarray(x, dtype=float)
        y = np.asarray(y, dtype=float)

        # Strip NaN/Inf
        mask = np.isfinite(x) & np.isfinite(y)
        x, y = x[mask], y[mask]

        dispatch = {
            "linear": FitToolkit._fit_linear,
            "polynomial": FitToolkit._fit_polynomial,
            "exponential": FitToolkit._fit_exponential,
            "logarithmic": FitToolkit._fit_logarithmic,
            "power": FitToolkit._fit_power,
            "logistic": FitToolkit._fit_logistic,
            "lowess": FitToolkit._fit_lowess,
        }
        if method not in dispatch:
            raise ValueError(
                f"Unknown fit method '{method}'. Choose from: {FitToolkit.METHODS}"
            )

        result = dispatch[method](x, y, degree=degree)
        result["method"] = method

        # Compute residuals & R²
        y_hat = result["predict"](x)
        residuals = y - y_hat
        ss_res = np.sum(residuals ** 2)
        ss_tot = np.sum((y - np.mean(y)) ** 2)
        r_squared = 1 - ss_res / ss_tot if ss_tot > 0 else 0.0
        result["r_squared"] = float(r_squared)
        result["residuals"] = residuals

        # Confidence interval (parametric, for linear & polynomial)
        if method in ("linear", "polynomial"):
            result.update(
                FitToolkit._parametric_ci(x, y, result, ci_level)
            )

        return result

    # ------------------------------------------------------------------
    # Fit all methods and rank by R²
    # ------------------------------------------------------------------

    @staticmethod
    def fit_all(
        x: np.ndarray,
        y: np.ndarray,
        degree: int = 2,
    ) -> List[Dict[str, Any]]:
        """Fit every supported method and return sorted by R² descending."""
        results = []
        for m in FitToolkit.METHODS:
            try:
                r = FitToolkit.fit(x, y, method=m, degree=degree)
                results.append(r)
            except Exception:
                continue
        results.sort(key=lambda r: r["r_squared"], reverse=True)
        return results

    # ------------------------------------------------------------------
    # Individual fitters
    # ------------------------------------------------------------------

    @staticmethod
    def _fit_linear(x, y, **_) -> Dict[str, Any]:
        coeffs = np.polyfit(x, y, 1)
        predict = np.poly1d(coeffs)
        m, b = coeffs
        sign = "+" if b >= 0 else "-"
        eq = f"y = {m:.4g}x {sign} {abs(b):.4g}"
        return {"coefficients": coeffs, "predict": predict, "equation": eq}

    @staticmethod
    def _fit_polynomial(x, y, degree: int = 2, **_) -> Dict[str, Any]:
        coeffs = np.polyfit(x, y, degree)
        predict = np.poly1d(coeffs)
        terms = []
        for i, c in enumerate(coeffs):
            power = degree - i
            if power == 0:
                terms.append(f"{c:.4g}")
            elif power == 1:
                terms.append(f"{c:.4g}x")
            else:
                terms.append(f"{c:.4g}x^{power}")
        eq = "y = " + " + ".join(terms)
        return {"coefficients": coeffs, "predict": predict, "equation": eq, "degree": degree}

    @staticmethod
    def _fit_exponential(x, y, **_) -> Dict[str, Any]:
        # y = a * exp(b * x)
        y_pos = np.where(y > 0, y, 1e-10)
        log_y = np.log(y_pos)
        coeffs_log = np.polyfit(x, log_y, 1)
        b = coeffs_log[0]
        a = np.exp(coeffs_log[1])

        def predict(xv):
            return a * np.exp(b * np.asarray(xv, dtype=float))

        eq = f"y = {a:.4g} · exp({b:.4g}x)"
        return {"coefficients": (a, b), "predict": predict, "equation": eq}

    @staticmethod
    def _fit_logarithmic(x, y, **_) -> Dict[str, Any]:
        # y = a * ln(x) + b
        x_pos = np.where(x > 0, x, 1e-10)
        log_x = np.log(x_pos)
        coeffs = np.polyfit(log_x, y, 1)
        a, b = coeffs

        def predict(xv):
            xv = np.asarray(xv, dtype=float)
            return a * np.log(np.where(xv > 0, xv, 1e-10)) + b

        sign = "+" if b >= 0 else "-"
        eq = f"y = {a:.4g} · ln(x) {sign} {abs(b):.4g}"
        return {"coefficients": coeffs, "predict": predict, "equation": eq}

    @staticmethod
    def _fit_power(x, y, **_) -> Dict[str, Any]:
        # y = a * x^b
        x_pos = np.where(x > 0, x, 1e-10)
        y_pos = np.where(y > 0, y, 1e-10)
        log_x = np.log(x_pos)
        log_y = np.log(y_pos)
        coeffs_log = np.polyfit(log_x, log_y, 1)
        b = coeffs_log[0]
        a = np.exp(coeffs_log[1])

        def predict(xv):
            xv = np.asarray(xv, dtype=float)
            return a * np.power(np.where(xv > 0, xv, 1e-10), b)

        eq = f"y = {a:.4g} · x^{b:.4g}"
        return {"coefficients": (a, b), "predict": predict, "equation": eq}

    @staticmethod
    def _fit_logistic(x, y, **_) -> Dict[str, Any]:
        # y = L / (1 + exp(-k*(x - x0)))
        L_init = np.max(y) * 1.05
        x0_init = np.median(x)
        k_init = 1.0

        def logistic(xv, L, k, x0):
            return L / (1 + np.exp(-k * (xv - x0)))

        try:
            popt, _ = optimize.curve_fit(
                logistic, x, y,
                p0=[L_init, k_init, x0_init],
                maxfev=10000,
            )
        except RuntimeError:
            # Fallback to initial guess
            popt = [L_init, k_init, x0_init]

        L, k, x0 = popt

        def predict(xv):
            return logistic(np.asarray(xv, dtype=float), L, k, x0)

        eq = f"y = {L:.4g} / (1 + exp(-{k:.4g}·(x - {x0:.4g})))"
        return {"coefficients": popt, "predict": predict, "equation": eq}

    @staticmethod
    def _fit_lowess(x, y, **_) -> Dict[str, Any]:
        """Locally weighted scatterplot smoothing."""
        try:
            from statsmodels.nonparametric.smoothers_lowess import lowess as sm_lowess
            result = sm_lowess(y, x, frac=0.3, return_sorted=True)
            x_smooth = result[:, 0]
            y_smooth = result[:, 1]
        except ImportError:
            # Pure numpy fallback: moving average approximation
            sort_idx = np.argsort(x)
            x_sorted = x[sort_idx]
            y_sorted = y[sort_idx]
            window = max(3, len(x) // 10)
            kernel = np.ones(window) / window
            y_smooth = np.convolve(y_sorted, kernel, mode="same")
            x_smooth = x_sorted

        predict = lambda xv: np.interp(np.asarray(xv, dtype=float), x_smooth, y_smooth)
        return {
            "coefficients": None,
            "predict": predict,
            "equation": "LOWESS (non-parametric)",
        }

    # ------------------------------------------------------------------
    # Confidence intervals (parametric)
    # ------------------------------------------------------------------

    @staticmethod
    def _parametric_ci(
        x: np.ndarray,
        y: np.ndarray,
        fit_result: Dict,
        ci_level: float,
    ) -> Dict[str, Callable]:
        """Add parametric prediction confidence bands."""
        n = len(x)
        y_hat = fit_result["predict"](x)
        residuals = y - y_hat
        dof = max(1, n - len(fit_result["coefficients"]))
        se = np.sqrt(np.sum(residuals ** 2) / dof)
        t_val = stats.t.ppf((1 + ci_level) / 2, dof)
        x_mean = np.mean(x)
        ss_x = np.sum((x - x_mean) ** 2)

        def ci_band(xv, sign: int):
            xv = np.asarray(xv, dtype=float)
            leverage = 1 / n + (xv - x_mean) ** 2 / ss_x if ss_x > 0 else 1 / n
            margin = sign * t_val * se * np.sqrt(leverage)
            return fit_result["predict"](xv) + margin

        return {
            "ci_lower": lambda xv: ci_band(xv, -1),
            "ci_upper": lambda xv: ci_band(xv, +1),
        }
