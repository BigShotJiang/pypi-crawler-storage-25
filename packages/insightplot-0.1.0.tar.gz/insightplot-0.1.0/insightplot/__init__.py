"""
InsightPlot — A data science graphing library that visualizes, fits, and recommends.

Usage:
    import insightplot as ip

    # Quick scatter with model suggestions
    fig = ip.scatter(x, y, suggest_models=True)

    # Add a fitted line with R²
    fig = ip.scatter(x, y)
    fig.add_fit("linear", show_r2=True)
    fig.add_fit("polynomial", degree=3, show_r2=True)
    fig.show()

    # Confusion matrix with full metrics
    ip.confusion_matrix(y_true, y_pred)

    # ROC curve with AUC and optimal threshold
    ip.roc_curve(y_true, y_scores)

    # Multi-axis plots
    fig = ip.Figure()
    fig.plot(x, y1, axis="left", label="Revenue")
    fig.plot(x, y2, axis="right", label="Growth %")
    fig.show()
"""

__version__ = "0.1.0"

from insightplot.core import Figure, subplot_grid
from insightplot.plots import scatter, line, bar, histogram, heatmap
from insightplot.confusion import confusion_matrix
from insightplot.roc import roc_curve, roc_multiclass
from insightplot.fits import FitToolkit
from insightplot.suggest import ModelAdvisor
from insightplot.evaluate import AutoEvaluator
from insightplot.tuner import HyperTuner
from insightplot import importance
from insightplot.styles import set_theme, available_themes

__all__ = [
    "Figure",
    "subplot_grid",
    "scatter",
    "line",
    "bar",
    "histogram",
    "heatmap",
    "confusion_matrix",
    "roc_curve",
    "roc_multiclass",
    "FitToolkit",
    "ModelAdvisor",
    "AutoEvaluator",
    "HyperTuner",
    "importance",
    "set_theme",
    "available_themes",
]
