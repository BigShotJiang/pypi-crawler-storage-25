"""
InsightPlot HyperTuner — Hyperparameter optimisation for top-performing models.

Takes results from AutoEvaluator and runs RandomizedSearchCV or GridSearchCV
on the top-k models using curated search spaces for every model in the
registry.

Usage
-----
>>> evaluator = ip.AutoEvaluator()
>>> results = evaluator.run(X, y)
>>> tuner = ip.HyperTuner()
>>> tuned = tuner.tune(X, y, results, top_k=3)
>>> tuner.print_report(tuned)
>>> best_model = tuned[0]["best_pipeline"]
>>> best_model.predict(X_new)
"""

from __future__ import annotations

import time
import warnings
import numpy as np
from typing import Any, Dict, List, Literal, Optional, Sequence, Tuple, Union

from sklearn.model_selection import (
    RandomizedSearchCV, GridSearchCV,
    StratifiedKFold, KFold,
)
from scipy.stats import uniform, loguniform, randint

# Optional imports
try:
    from scipy.stats import loguniform as _loguniform
except ImportError:
    _loguniform = None


# =====================================================================
# Search space registry
# =====================================================================
# Keys are model names (must match AutoEvaluator registry names).
# Values are dicts mapping pipeline parameter names -> distributions.
# Pipeline params use the format "model__param" since AutoEvaluator
# wraps models in Pipeline([("scaler", ...), ("model", ...)]).
# =====================================================================

def _regression_search_spaces() -> Dict[str, Dict[str, Any]]:
    return {
        "Linear Regression": {},  # no hyperparams to tune

        "Ridge Regression": {
            "model__alpha": loguniform(1e-4, 1e3),
        },

        "Lasso Regression": {
            "model__alpha": loguniform(1e-5, 1e2),
            "model__max_iter": [5000, 10000],
        },

        "Elastic Net": {
            "model__alpha": loguniform(1e-5, 1e2),
            "model__l1_ratio": uniform(0.01, 0.99),
            "model__max_iter": [5000, 10000],
        },

        "Bayesian Ridge": {
            "model__alpha_1": loguniform(1e-8, 1e-3),
            "model__alpha_2": loguniform(1e-8, 1e-3),
            "model__lambda_1": loguniform(1e-8, 1e-3),
            "model__lambda_2": loguniform(1e-8, 1e-3),
        },

        "Huber Regressor": {
            "model__epsilon": uniform(1.01, 2.5),
            "model__alpha": loguniform(1e-5, 1e-1),
            "model__max_iter": [200, 500, 1000],
        },

        "Polynomial (degree 2)": {
            "model__alpha": loguniform(1e-4, 1e3),
        },

        "Polynomial (degree 3)": {
            "model__alpha": loguniform(1e-4, 1e3),
        },

        "K-Nearest Neighbors": {
            "model__n_neighbors": randint(2, 30),
            "model__weights": ["uniform", "distance"],
            "model__metric": ["euclidean", "manhattan", "minkowski"],
            "model__p": [1, 2, 3],
        },

        "SVR (RBF kernel)": {
            "model__C": loguniform(1e-2, 1e3),
            "model__epsilon": loguniform(1e-3, 1e1),
            "model__gamma": ["scale", "auto"] + list(loguniform(1e-4, 1e1).rvs(8)),
        },

        "Decision Tree": {
            "model__max_depth": randint(3, 25),
            "model__min_samples_split": randint(2, 20),
            "model__min_samples_leaf": randint(1, 15),
            "model__max_features": ["sqrt", "log2", None],
        },

        "Random Forest": {
            "model__n_estimators": randint(50, 500),
            "model__max_depth": randint(4, 30),
            "model__min_samples_split": randint(2, 15),
            "model__min_samples_leaf": randint(1, 10),
            "model__max_features": ["sqrt", "log2", None, 0.5, 0.8],
        },

        "Extra Trees": {
            "model__n_estimators": randint(50, 500),
            "model__max_depth": randint(4, 30),
            "model__min_samples_split": randint(2, 15),
            "model__min_samples_leaf": randint(1, 10),
            "model__max_features": ["sqrt", "log2", None, 0.5, 0.8],
        },

        "Gradient Boosting (sklearn)": {
            "model__n_estimators": randint(50, 500),
            "model__max_depth": randint(2, 12),
            "model__learning_rate": loguniform(1e-3, 0.5),
            "model__subsample": uniform(0.5, 0.5),
            "model__min_samples_split": randint(2, 15),
            "model__min_samples_leaf": randint(1, 10),
        },

        "AdaBoost": {
            "model__n_estimators": randint(30, 300),
            "model__learning_rate": loguniform(1e-3, 2.0),
        },

        "XGBoost": {
            "model__n_estimators": randint(50, 600),
            "model__max_depth": randint(2, 12),
            "model__learning_rate": loguniform(1e-3, 0.5),
            "model__subsample": uniform(0.5, 0.5),
            "model__colsample_bytree": uniform(0.3, 0.7),
            "model__reg_alpha": loguniform(1e-3, 10.0),
            "model__reg_lambda": loguniform(1e-3, 10.0),
            "model__min_child_weight": randint(1, 10),
            "model__gamma": loguniform(1e-4, 5.0),
        },

        "LightGBM": {
            "model__n_estimators": randint(50, 600),
            "model__max_depth": randint(3, 15),
            "model__learning_rate": loguniform(1e-3, 0.5),
            "model__subsample": uniform(0.5, 0.5),
            "model__colsample_bytree": uniform(0.3, 0.7),
            "model__reg_alpha": loguniform(1e-3, 10.0),
            "model__reg_lambda": loguniform(1e-3, 10.0),
            "model__num_leaves": randint(15, 127),
            "model__min_child_samples": randint(5, 50),
        },

        "Gaussian Process": {},  # kernel tuning handled internally

        "MLP Neural Network": {
            "model__hidden_layer_sizes": [
                (64, 32), (128, 64), (256, 128),
                (128, 64, 32), (64, 64), (256, 128, 64),
                (128,), (256,), (512, 256),
            ],
            "model__activation": ["relu", "tanh"],
            "model__alpha": loguniform(1e-5, 1e-1),
            "model__learning_rate_init": loguniform(1e-4, 1e-2),
            "model__batch_size": [32, 64, 128, 256, "auto"],
        },

        "MLP Neural Network (deep)": {
            "model__hidden_layer_sizes": [
                (256, 128, 64), (512, 256, 128), (256, 128, 64, 32),
                (512, 256), (128, 128, 128), (256, 256, 128),
            ],
            "model__activation": ["relu", "tanh"],
            "model__alpha": loguniform(1e-5, 1e-1),
            "model__learning_rate_init": loguniform(1e-4, 1e-2),
            "model__batch_size": [64, 128, 256, "auto"],
        },
    }


def _classification_search_spaces() -> Dict[str, Dict[str, Any]]:
    spaces = _regression_search_spaces()

    # Override / add classification-specific entries
    spaces["Logistic Regression"] = {
        "model__C": loguniform(1e-4, 1e3),
        "model__penalty": ["l1", "l2"],
        "model__solver": ["liblinear", "saga"],
        "model__max_iter": [2000, 5000],
    }
    spaces["Ridge Classifier"] = {
        "model__alpha": loguniform(1e-4, 1e3),
    }
    spaces["SVC (RBF kernel)"] = {
        "model__C": loguniform(1e-2, 1e3),
        "model__gamma": ["scale", "auto"] + list(loguniform(1e-4, 1e1).rvs(8)),
    }
    spaces["Gaussian Naive Bayes"] = {
        "model__var_smoothing": loguniform(1e-12, 1e-6),
    }
    spaces["Quadratic Discriminant Analysis"] = {
        "model__reg_param": uniform(0.0, 1.0),
    }

    return spaces


# =====================================================================
# HyperTuner
# =====================================================================

class HyperTuner:
    """Hyperparameter optimisation for InsightPlot AutoEvaluator results.

    Parameters
    ----------
    method : 'random' or 'grid'
        Search strategy.  'random' is recommended for large spaces.
    n_iter : int
        Number of parameter combinations to try (random search only).
    cv : int
        Cross-validation folds.
    scoring : str or None
        Scoring metric.  Auto-detected from the evaluator results if None.
    n_jobs : int
        Parallel workers (-1 = all cores).
    """

    def __init__(
        self,
        method: Literal["random", "grid"] = "random",
        n_iter: int = 60,
        cv: int = 5,
        scoring: Optional[str] = None,
        n_jobs: int = -1,
        random_state: int = 42,
    ):
        self.method = method
        self.n_iter = n_iter
        self.cv = cv
        self.scoring = scoring
        self.n_jobs = n_jobs
        self.random_state = random_state
        self._task: Optional[str] = None

    # ─────────────────────────────────────────────────────────────

    def tune(
        self,
        X: Any,
        y: Any,
        evaluator_results: List[Dict[str, Any]],
        *,
        top_k: int = 3,
        task: Literal["auto", "regression", "classification"] = "auto",
        verbose: bool = True,
    ) -> List[Dict[str, Any]]:
        """Tune hyperparameters on the top-k models from AutoEvaluator.

        Parameters
        ----------
        X : array-like of shape (n_samples,) or (n_samples, n_features)
        y : array-like of shape (n_samples,)
        evaluator_results : list
            Output from ``AutoEvaluator.run()``.
        top_k : int
            How many top models to tune.
        task : str
            'auto' detects from the evaluator results.

        Returns
        -------
        List of dicts sorted by tuned score, containing:
            name, default_score, best_score, improvement,
            best_params, best_pipeline, cv_results, elapsed_seconds.
        """
        X = np.asarray(X)
        y = np.asarray(y)
        if X.ndim == 1:
            X = X.reshape(-1, 1)

        # Detect task
        if task == "auto":
            # Infer from evaluator results
            sort_metric = evaluator_results[0].get("sort_metric", "r2")
            if sort_metric in ("r2", "neg_rmse", "neg_mae"):
                task = "regression"
            else:
                task = "classification"
        self._task = task

        # Pick scoring metric
        if self.scoring is None:
            if task == "regression":
                scoring = "r2"
            else:
                scoring = "f1_weighted"
        else:
            scoring = self.scoring

        # Load search spaces
        if task == "regression":
            all_spaces = _regression_search_spaces()
        else:
            all_spaces = _classification_search_spaces()

        # CV splitter
        cv_splitter = (
            StratifiedKFold(n_splits=self.cv, shuffle=True, random_state=self.random_state)
            if task == "classification"
            else KFold(n_splits=self.cv, shuffle=True, random_state=self.random_state)
        )

        # Select top-k successful models
        candidates = [r for r in evaluator_results if r["status"] == "ok"][:top_k]

        if verbose:
            print(f"\n{'='*72}")
            print(f"  INSIGHTPLOT HYPERTUNER — Optimising top {len(candidates)} models")
            print(f"{'='*72}")
            print(f"  Method    : {self.method} search")
            if self.method == "random":
                print(f"  Iterations: {self.n_iter}")
            print(f"  CV folds  : {self.cv}")
            print(f"  Scoring   : {scoring}")
            print()

        tuned_results: List[Dict[str, Any]] = []

        for i, candidate in enumerate(candidates, 1):
            name = candidate["name"]
            pipeline = candidate["pipeline"]
            default_score = candidate["primary_score"]
            search_space = all_spaces.get(name, {})

            if verbose:
                n_params = len(search_space)
                print(f"  [{i}/{len(candidates)}] {name}")
                print(f"         Default {scoring}: {default_score:.4f}")
                print(f"         Search space: {n_params} hyperparameters")

            if not search_space:
                if verbose:
                    print(f"         → No tunable hyperparameters, skipping.\n")
                tuned_results.append({
                    "name": name,
                    "default_score": default_score,
                    "best_score": default_score,
                    "improvement": 0.0,
                    "improvement_pct": 0.0,
                    "best_params": {},
                    "best_pipeline": pipeline,
                    "cv_results": None,
                    "elapsed_seconds": 0.0,
                    "status": "no_tunable_params",
                })
                continue

            t0 = time.perf_counter()
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")

                    if self.method == "random":
                        search = RandomizedSearchCV(
                            pipeline,
                            param_distributions=search_space,
                            n_iter=self.n_iter,
                            scoring=scoring,
                            cv=cv_splitter,
                            n_jobs=self.n_jobs,
                            random_state=self.random_state,
                            refit=True,
                            error_score="raise",
                        )
                    else:
                        # For grid search, convert distributions to lists
                        grid_space = self._distributions_to_grid(search_space)
                        search = GridSearchCV(
                            pipeline,
                            param_grid=grid_space,
                            scoring=scoring,
                            cv=cv_splitter,
                            n_jobs=self.n_jobs,
                            refit=True,
                            error_score="raise",
                        )

                    search.fit(X, y)

                elapsed = time.perf_counter() - t0
                best_score = search.best_score_
                improvement = best_score - default_score
                improvement_pct = (
                    (improvement / abs(default_score)) * 100
                    if abs(default_score) > 1e-10 else 0.0
                )

                # Clean params for display
                best_params = {
                    k.replace("model__", ""): self._format_param(v)
                    for k, v in search.best_params_.items()
                }

                tuned_results.append({
                    "name": name,
                    "default_score": default_score,
                    "best_score": best_score,
                    "improvement": improvement,
                    "improvement_pct": improvement_pct,
                    "best_params": best_params,
                    "best_pipeline": search.best_estimator_,
                    "cv_results": search.cv_results_,
                    "elapsed_seconds": elapsed,
                    "status": "ok",
                })

                if verbose:
                    sign = "+" if improvement >= 0 else ""
                    print(f"         → Tuned {scoring}: {best_score:.4f}  "
                          f"({sign}{improvement:.4f}, {sign}{improvement_pct:.1f}%)")
                    print(f"         → Best params: {best_params}")
                    print(f"         → Time: {elapsed:.1f}s\n")

            except Exception as e:
                elapsed = time.perf_counter() - t0
                tuned_results.append({
                    "name": name,
                    "default_score": default_score,
                    "best_score": default_score,
                    "improvement": 0.0,
                    "improvement_pct": 0.0,
                    "best_params": {},
                    "best_pipeline": pipeline,
                    "cv_results": None,
                    "elapsed_seconds": elapsed,
                    "status": f"FAILED: {e}",
                })
                if verbose:
                    print(f"         → FAILED: {type(e).__name__}: {e}\n")

        # Sort by tuned score
        tuned_results.sort(key=lambda r: r["best_score"], reverse=True)
        for rank, r in enumerate(tuned_results, 1):
            r["rank"] = rank

        return tuned_results

    # ─────────────────────────────────────────────────────────────

    def print_report(self, tuned_results: List[Dict[str, Any]]) -> None:
        """Pretty-print tuning results."""
        if not tuned_results:
            print("No tuning results to display.")
            return

        print(f"\n{'='*76}")
        print(f"  INSIGHTPLOT HYPERTUNER — RESULTS")
        print(f"{'='*76}\n")

        print(f"  {'Rank':<5} {'Model':<35} {'Default':>9} {'Tuned':>9} "
              f"{'Δ':>8} {'Δ%':>7} {'Time':>7}")
        print(f"  {'─'*5} {'─'*35} {'─'*9} {'─'*9} {'─'*8} {'─'*7} {'─'*7}")

        for r in tuned_results:
            if r["status"] in ("ok", "no_tunable_params"):
                sign = "+" if r["improvement"] >= 0 else ""
                print(
                    f"  {r['rank']:<5} {r['name']:<35} "
                    f"{r['default_score']:>9.4f} {r['best_score']:>9.4f} "
                    f"{sign}{r['improvement']:>7.4f} "
                    f"{sign}{r['improvement_pct']:>6.1f}% "
                    f"{r['elapsed_seconds']:>6.1f}s"
                )
            else:
                print(f"  {r['rank']:<5} {r['name']:<35}  {r['status']}")

        print(f"\n  {'─'*76}")
        print(f"  BEST PARAMETERS\n")

        for r in tuned_results:
            if r["status"] != "ok" or not r["best_params"]:
                continue
            print(f"  #{r['rank']}  {r['name']}")
            for param, val in r["best_params"].items():
                print(f"       {param:<30} = {val}")
            print()

        # Winner summary
        best = tuned_results[0]
        if best["status"] in ("ok", "no_tunable_params"):
            print(f"  ★ BEST MODEL: {best['name']}")
            print(f"    Score: {best['best_score']:.4f}")
            if best["best_params"]:
                print(f"    Pipeline ready: tuned_results[0]['best_pipeline']")
            print()

        print(f"{'='*76}")

    # ─────────────────────────────────────────────────────────────

    def plot_tuning(
        self,
        tuned_results: List[Dict[str, Any]],
        *,
        figsize: Tuple[float, float] = (12, 6),
        title: Optional[str] = None,
        save_path: Optional[str] = None,
    ):
        """Bar chart comparing default vs tuned scores."""
        import matplotlib.pyplot as plt
        from insightplot.styles import get_palette

        items = [r for r in tuned_results if r["status"] in ("ok", "no_tunable_params")]
        if not items:
            return None

        names = [r["name"] for r in items]
        defaults = [r["default_score"] for r in items]
        tuned = [r["best_score"] for r in items]

        palette = get_palette()
        x = np.arange(len(names))
        width = 0.35

        fig, ax = plt.subplots(figsize=figsize)
        bars1 = ax.bar(x - width / 2, defaults, width, label="Default",
                        color=palette[0], alpha=0.7, edgecolor="white")
        bars2 = ax.bar(x + width / 2, tuned, width, label="Tuned",
                        color=palette[1], alpha=0.9, edgecolor="white")

        # Improvement labels
        for i, (d, t) in enumerate(zip(defaults, tuned)):
            imp = t - d
            if abs(imp) > 1e-6:
                sign = "+" if imp >= 0 else ""
                ax.annotate(
                    f"{sign}{imp:.4f}",
                    xy=(x[i] + width / 2, t),
                    xytext=(0, 5), textcoords="offset points",
                    ha="center", fontsize=8, fontweight="bold",
                    color=palette[1] if imp >= 0 else "#C73E1D",
                )

        ax.set_xticks(x)
        ax.set_xticklabels(names, rotation=25, ha="right", fontsize=9)
        ax.set_ylabel("Score (CV)", fontsize=11)
        ax.set_title(
            title or "Default vs. Tuned Model Performance",
            fontsize=13, fontweight="bold", pad=12,
        )
        ax.legend(fontsize=10)
        ax.grid(axis="y", alpha=0.3)
        fig.tight_layout()

        if save_path:
            fig.savefig(save_path, bbox_inches="tight")

        return fig

    # ─────────────────────────────────────────────────────────────
    # Helpers
    # ─────────────────────────────────────────────────────────────

    @staticmethod
    def _distributions_to_grid(space: Dict[str, Any], n_samples: int = 10) -> Dict[str, list]:
        """Convert scipy distributions to discrete grids for GridSearchCV."""
        grid: Dict[str, list] = {}
        for k, v in space.items():
            if isinstance(v, list):
                grid[k] = v
            elif hasattr(v, "rvs"):
                grid[k] = sorted(set(v.rvs(n_samples, random_state=42).tolist()))
            else:
                grid[k] = [v]
        return grid

    @staticmethod
    def _format_param(v: Any) -> Any:
        """Format a parameter value for display."""
        if isinstance(v, float):
            if abs(v) < 0.01 or abs(v) > 1000:
                return f"{v:.4e}"
            return round(v, 6)
        return v
