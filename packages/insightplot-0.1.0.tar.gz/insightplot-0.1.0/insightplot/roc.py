"""
InsightPlot ROC Curve — ROC plot with AUC, optimal threshold marker,
confidence bands, and multi-class OvR support.
"""

from __future__ import annotations
import matplotlib.pyplot as plt
import numpy as np
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

from sklearn.metrics import (
    roc_curve as sk_roc_curve,
    auc as sk_auc,
    precision_score,
    recall_score,
    f1_score,
    accuracy_score,
)
from sklearn.preprocessing import label_binarize

from insightplot.styles import get_color, get_palette


def roc_curve(
    y_true: Any,
    y_scores: Any,
    *,
    pos_label: Optional[Any] = None,
    title: str = "ROC Curve",
    figsize: Tuple[float, float] = (10, 7),
    show_optimal_threshold: bool = True,
    show_metrics_panel: bool = True,
    show_diagonal: bool = True,
    fill_auc: bool = True,
    n_bootstrap: int = 0,
    ci_level: float = 0.95,
    save_path: Optional[str] = None,
    return_metrics: bool = False,
) -> Union[plt.Figure, Tuple[plt.Figure, Dict[str, Any]]]:
    """Plot a ROC curve for binary classification.

    Parameters
    ----------
    y_true : array-like
        Binary ground truth (0/1).
    y_scores : array-like
        Predicted probabilities or decision scores for the positive class.
    show_optimal_threshold : bool
        Mark the Youden's J-statistic optimal point.
    show_metrics_panel : bool
        Side panel with threshold-specific metrics.
    n_bootstrap : int
        If > 0, draw confidence band from bootstrap resamples.
    """
    y_true = np.asarray(y_true)
    y_scores = np.asarray(y_scores, dtype=float)

    fpr, tpr, thresholds = sk_roc_curve(y_true, y_scores, pos_label=pos_label)
    roc_auc = sk_auc(fpr, tpr)

    # Optimal threshold (Youden's J)
    j_scores = tpr - fpr
    opt_idx = np.argmax(j_scores)
    opt_threshold = thresholds[opt_idx] if opt_idx < len(thresholds) else 0.5
    opt_fpr = fpr[opt_idx]
    opt_tpr = tpr[opt_idx]

    # Metrics at optimal threshold
    y_pred_opt = (y_scores >= opt_threshold).astype(int)
    unique_true = np.unique(y_true)
    avg = "binary" if len(unique_true) <= 2 else "weighted"
    metrics: Dict[str, Any] = {
        "auc": roc_auc,
        "optimal_threshold": float(opt_threshold),
        "optimal_fpr": float(opt_fpr),
        "optimal_tpr": float(opt_tpr),
        "youdens_j": float(j_scores[opt_idx]),
        "accuracy_at_optimal": accuracy_score(y_true, y_pred_opt),
        "precision_at_optimal": precision_score(y_true, y_pred_opt, average=avg, zero_division=0),
        "recall_at_optimal": recall_score(y_true, y_pred_opt, average=avg, zero_division=0),
        "f1_at_optimal": f1_score(y_true, y_pred_opt, average=avg, zero_division=0),
        "n_positive": int(np.sum(y_true == (pos_label if pos_label is not None else 1))),
        "n_negative": int(np.sum(y_true != (pos_label if pos_label is not None else 1))),
        "n_total": len(y_true),
    }
    # Specificity at optimal
    tn = np.sum((y_pred_opt == 0) & (y_true == 0))
    fp = np.sum((y_pred_opt == 1) & (y_true == 0))
    metrics["specificity_at_optimal"] = tn / (tn + fp) if (tn + fp) > 0 else 0.0

    # ---- Plotting ----
    if show_metrics_panel:
        fig = plt.figure(figsize=figsize)
        gs = fig.add_gridspec(1, 2, width_ratios=[3, 1.3], wspace=0.3)
        ax_roc = fig.add_subplot(gs[0])
        ax_met = fig.add_subplot(gs[1])
    else:
        fig, ax_roc = plt.subplots(figsize=figsize)
        ax_met = None

    primary = get_color(0)
    fill_color = get_color(0)

    # Bootstrap CI
    if n_bootstrap > 0:
        tpr_interp_base = np.linspace(0, 1, 200)
        bootstrapped_tprs = []
        rng = np.random.default_rng(42)
        for _ in range(n_bootstrap):
            idx = rng.choice(len(y_true), len(y_true), replace=True)
            if len(np.unique(y_true[idx])) < 2:
                continue
            fpr_b, tpr_b, _ = sk_roc_curve(y_true[idx], y_scores[idx], pos_label=pos_label)
            tpr_i = np.interp(tpr_interp_base, fpr_b, tpr_b)
            bootstrapped_tprs.append(tpr_i)

        if bootstrapped_tprs:
            tpr_array = np.array(bootstrapped_tprs)
            alpha_lo = (1 - ci_level) / 2
            alpha_hi = 1 - alpha_lo
            ci_lo = np.quantile(tpr_array, alpha_lo, axis=0)
            ci_hi = np.quantile(tpr_array, alpha_hi, axis=0)
            ax_roc.fill_between(tpr_interp_base, ci_lo, ci_hi,
                                 alpha=0.12, color=primary,
                                 label=f"{ci_level:.0%} CI (bootstrap)")

    # AUC fill
    if fill_auc:
        ax_roc.fill_between(fpr, tpr, alpha=0.10, color=fill_color)

    # ROC curve
    ax_roc.plot(fpr, tpr, color=primary, linewidth=2.5,
                label=f"ROC (AUC = {roc_auc:.4f})")

    # Diagonal
    if show_diagonal:
        ax_roc.plot([0, 1], [0, 1], linestyle="--", color="#999999",
                    linewidth=1.0, label="Random classifier")

    # Optimal point
    if show_optimal_threshold:
        ax_roc.plot(opt_fpr, opt_tpr, "o", color=get_color(1),
                    markersize=10, markeredgecolor="white", markeredgewidth=2,
                    zorder=5, label=f"Optimal (t={opt_threshold:.3f})")
        ax_roc.annotate(
            f"J = {j_scores[opt_idx]:.3f}\nTPR = {opt_tpr:.3f}\nFPR = {opt_fpr:.3f}",
            xy=(opt_fpr, opt_tpr),
            xytext=(opt_fpr + 0.12, opt_tpr - 0.12),
            fontsize=8, fontfamily="monospace",
            arrowprops=dict(arrowstyle="->", color="#555555"),
            bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="#CCCCCC", alpha=0.9),
        )

    ax_roc.set_xlim([-0.02, 1.02])
    ax_roc.set_ylim([-0.02, 1.05])
    ax_roc.set_xlabel("False Positive Rate (1 − Specificity)", fontsize=11)
    ax_roc.set_ylabel("True Positive Rate (Sensitivity)", fontsize=11)
    ax_roc.set_title(title, fontsize=13, fontweight="bold", pad=12)
    ax_roc.legend(loc="lower right", fontsize=9)

    # ---- Metrics panel ----
    if ax_met is not None:
        ax_met.axis("off")
        y = 0.95
        lh = 0.05

        ax_met.text(0.05, y, "ROC METRICS", fontsize=11, fontweight="bold",
                    transform=ax_met.transAxes)
        y -= lh * 1.5

        lines = [
            ("AUC", f"{metrics['auc']:.4f}"),
            ("Youden's J", f"{metrics['youdens_j']:.4f}"),
            ("", ""),
            ("AT OPTIMAL THRESHOLD", f"({metrics['optimal_threshold']:.4f})"),
            ("", ""),
            ("Accuracy", f"{metrics['accuracy_at_optimal']:.4f}"),
            ("Precision", f"{metrics['precision_at_optimal']:.4f}"),
            ("Recall / TPR", f"{metrics['recall_at_optimal']:.4f}"),
            ("Specificity", f"{metrics['specificity_at_optimal']:.4f}"),
            ("F1 Score", f"{metrics['f1_at_optimal']:.4f}"),
            ("FPR", f"{metrics['optimal_fpr']:.4f}"),
            ("", ""),
            ("SAMPLE INFO", ""),
            ("", ""),
            ("Total samples", f"{metrics['n_total']:,}"),
            ("Positive class", f"{metrics['n_positive']:,}"),
            ("Negative class", f"{metrics['n_negative']:,}"),
            ("Prevalence", f"{metrics['n_positive'] / metrics['n_total']:.2%}"),
        ]
        for label, val in lines:
            if label == "" and val == "":
                y -= lh * 0.3
                continue
            is_header = val == "" or (label.isupper() and "(" not in val)
            weight = "bold" if is_header else "normal"
            size = 10 if is_header else 9
            ax_met.text(0.05, y, label, fontsize=size, fontweight=weight,
                        transform=ax_met.transAxes)
            if val and not is_header:
                ax_met.text(0.85, y, val, fontsize=9, fontfamily="monospace",
                            ha="right", transform=ax_met.transAxes)
            elif "(" in val:
                ax_met.text(0.85, y, val, fontsize=8, fontfamily="monospace",
                            ha="right", transform=ax_met.transAxes, color="#666666")
            y -= lh

    fig.tight_layout()

    if save_path:
        fig.savefig(save_path, bbox_inches="tight")

    if return_metrics:
        return fig, metrics
    return fig


def roc_multiclass(
    y_true: Any,
    y_scores: Any,
    *,
    class_labels: Optional[Sequence[str]] = None,
    title: str = "Multi-Class ROC (One-vs-Rest)",
    figsize: Tuple[float, float] = (10, 7),
    show_diagonal: bool = True,
    fill_auc: bool = False,
    save_path: Optional[str] = None,
    return_metrics: bool = False,
) -> Union[plt.Figure, Tuple[plt.Figure, Dict[str, Any]]]:
    """Plot OvR ROC curves for multi-class classification.

    Parameters
    ----------
    y_true : array-like of shape (n_samples,)
        Integer or label ground truth.
    y_scores : array-like of shape (n_samples, n_classes)
        Predicted probability for each class.
    class_labels : list of str
        Human-readable class names.
    """
    y_true = np.asarray(y_true)
    y_scores = np.asarray(y_scores, dtype=float)

    classes = np.unique(y_true)
    n_classes = len(classes)
    if class_labels is None:
        class_labels = [str(c) for c in classes]

    y_bin = label_binarize(y_true, classes=classes)
    if n_classes == 2:
        y_bin = np.hstack([1 - y_bin, y_bin])

    fig, ax = plt.subplots(figsize=figsize)
    palette = get_palette()
    all_metrics: Dict[str, Any] = {}

    for i in range(n_classes):
        fpr, tpr, _ = sk_roc_curve(y_bin[:, i], y_scores[:, i])
        roc_auc = sk_auc(fpr, tpr)
        color = palette[i % len(palette)]
        ax.plot(fpr, tpr, color=color, linewidth=2.0,
                label=f"{class_labels[i]} (AUC = {roc_auc:.3f})")
        if fill_auc:
            ax.fill_between(fpr, tpr, alpha=0.06, color=color)
        all_metrics[class_labels[i]] = {"auc": roc_auc}

    # Macro average
    all_fpr = np.unique(np.concatenate([
        sk_roc_curve(y_bin[:, i], y_scores[:, i])[0] for i in range(n_classes)
    ]))
    mean_tpr = np.zeros_like(all_fpr)
    for i in range(n_classes):
        fpr_i, tpr_i, _ = sk_roc_curve(y_bin[:, i], y_scores[:, i])
        mean_tpr += np.interp(all_fpr, fpr_i, tpr_i)
    mean_tpr /= n_classes
    macro_auc = sk_auc(all_fpr, mean_tpr)
    ax.plot(all_fpr, mean_tpr, color="#333333", linewidth=2.5, linestyle="--",
            label=f"Macro avg (AUC = {macro_auc:.3f})")
    all_metrics["macro_avg_auc"] = macro_auc

    if show_diagonal:
        ax.plot([0, 1], [0, 1], linestyle=":", color="#BBBBBB", linewidth=1.0)

    ax.set_xlim([-0.02, 1.02])
    ax.set_ylim([-0.02, 1.05])
    ax.set_xlabel("False Positive Rate", fontsize=11)
    ax.set_ylabel("True Positive Rate", fontsize=11)
    ax.set_title(title, fontsize=13, fontweight="bold", pad=12)
    ax.legend(loc="lower right", fontsize=9)

    fig.tight_layout()
    if save_path:
        fig.savefig(save_path, bbox_inches="tight")

    if return_metrics:
        return fig, all_metrics
    return fig
