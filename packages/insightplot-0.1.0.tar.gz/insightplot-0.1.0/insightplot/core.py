"""
InsightPlot core — Figure wrapper with multi-axis support, fit toolkit, and model advisor.
"""

from __future__ import annotations
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np
from typing import (
    Any, Dict, List, Literal, Optional, Sequence, Tuple, Union,
)

from insightplot.styles import get_color, get_palette
from insightplot.fits import FitToolkit
from insightplot.suggest import ModelAdvisor


AxisSide = Literal["left", "right"]


class Figure:
    """High-level figure container with dual-axis support and built-in analytics.

    Examples
    --------
    >>> fig = ip.Figure(title="Sales vs. Growth")
    >>> fig.plot(months, revenue, axis="left", label="Revenue ($M)")
    >>> fig.plot(months, pct_growth, axis="right", label="YoY Growth %")
    >>> fig.add_fit("left", "linear", show_r2=True)
    >>> fig.show()
    """

    def __init__(
        self,
        title: str = "",
        xlabel: str = "",
        ylabel: str = "",
        ylabel_right: str = "",
        figsize: Tuple[float, float] = (10, 6),
        theme: Optional[str] = None,
    ) -> None:
        if theme:
            from insightplot.styles import set_theme
            set_theme(theme)

        self._fig, self._ax_left = plt.subplots(figsize=figsize)
        self._ax_right: Optional[plt.Axes] = None
        self._title = title
        self._xlabel = xlabel
        self._ylabel = ylabel
        self._ylabel_right = ylabel_right

        # Track data series for fitting / suggestion
        self._series: Dict[str, List[Dict[str, Any]]] = {"left": [], "right": []}
        self._color_idx = 0
        self._fits: List[Dict[str, Any]] = []

        if title:
            self._ax_left.set_title(title)
        if xlabel:
            self._ax_left.set_xlabel(xlabel)
        if ylabel:
            self._ax_left.set_ylabel(ylabel)

    # ------------------------------------------------------------------
    # Axis helpers
    # ------------------------------------------------------------------

    def _ensure_right_axis(self) -> plt.Axes:
        if self._ax_right is None:
            self._ax_right = self._ax_left.twinx()
            if self._ylabel_right:
                self._ax_right.set_ylabel(self._ylabel_right)
        return self._ax_right

    def _get_ax(self, side: AxisSide) -> plt.Axes:
        if side == "right":
            return self._ensure_right_axis()
        return self._ax_left

    def _next_color(self) -> str:
        c = get_color(self._color_idx)
        self._color_idx += 1
        return c

    # ------------------------------------------------------------------
    # Plotting primitives
    # ------------------------------------------------------------------

    def plot(
        self,
        x: Any,
        y: Any,
        *,
        axis: AxisSide = "left",
        label: str = "",
        color: Optional[str] = None,
        linestyle: str = "-",
        marker: Optional[str] = None,
        linewidth: float = 2.0,
        alpha: float = 1.0,
        **kwargs: Any,
    ) -> "Figure":
        """Add a line/marker series to the figure."""
        ax = self._get_ax(axis)
        c = color or self._next_color()
        x_arr = np.asarray(x, dtype=float)
        y_arr = np.asarray(y, dtype=float)
        ax.plot(
            x_arr, y_arr,
            label=label, color=c, linestyle=linestyle,
            marker=marker, linewidth=linewidth, alpha=alpha,
            **kwargs,
        )
        self._series[axis].append({"x": x_arr, "y": y_arr, "label": label, "color": c})
        return self

    def scatter(
        self,
        x: Any,
        y: Any,
        *,
        axis: AxisSide = "left",
        label: str = "",
        color: Optional[str] = None,
        s: float = 40,
        alpha: float = 0.7,
        edgecolors: str = "white",
        linewidths: float = 0.5,
        **kwargs: Any,
    ) -> "Figure":
        """Add a scatter series."""
        ax = self._get_ax(axis)
        c = color or self._next_color()
        x_arr = np.asarray(x, dtype=float)
        y_arr = np.asarray(y, dtype=float)
        ax.scatter(
            x_arr, y_arr,
            label=label, color=c, s=s, alpha=alpha,
            edgecolors=edgecolors, linewidths=linewidths,
            **kwargs,
        )
        self._series[axis].append({"x": x_arr, "y": y_arr, "label": label, "color": c})
        return self

    def bar(
        self,
        x: Any,
        y: Any,
        *,
        axis: AxisSide = "left",
        label: str = "",
        color: Optional[str] = None,
        alpha: float = 0.85,
        width: float = 0.8,
        **kwargs: Any,
    ) -> "Figure":
        """Add a bar series."""
        ax = self._get_ax(axis)
        c = color or self._next_color()
        x_arr = np.asarray(x)
        y_arr = np.asarray(y, dtype=float)
        ax.bar(x_arr, y_arr, label=label, color=c, alpha=alpha, width=width, **kwargs)
        self._series[axis].append({"x": x_arr, "y": y_arr, "label": label, "color": c})
        return self

    def fill_between(
        self,
        x: Any,
        y1: Any,
        y2: Any = 0,
        *,
        axis: AxisSide = "left",
        label: str = "",
        color: Optional[str] = None,
        alpha: float = 0.2,
        **kwargs: Any,
    ) -> "Figure":
        """Shaded region between two curves."""
        ax = self._get_ax(axis)
        c = color or self._next_color()
        ax.fill_between(np.asarray(x), np.asarray(y1), np.asarray(y2),
                         color=c, alpha=alpha, label=label, **kwargs)
        return self

    # ------------------------------------------------------------------
    # Fit toolkit integration
    # ------------------------------------------------------------------

    def add_fit(
        self,
        axis: AxisSide = "left",
        method: str = "linear",
        *,
        series_index: int = -1,
        show_r2: bool = True,
        show_equation: bool = False,
        show_ci: bool = False,
        ci_level: float = 0.95,
        degree: int = 2,
        color: Optional[str] = None,
        linestyle: str = "--",
        linewidth: float = 1.8,
        label_prefix: str = "",
        n_points: int = 200,
        **kwargs: Any,
    ) -> "Figure":
        """Overlay a fitted curve on an existing data series.

        Parameters
        ----------
        axis : 'left' or 'right'
        method : str
            'linear', 'polynomial', 'exponential', 'logarithmic',
            'power', 'logistic', 'lowess'
        series_index : int
            Which series on that axis to fit (-1 = most recent).
        show_r2 : bool
            Annotate R² on the plot.
        show_equation : bool
            Annotate the fitted equation.
        show_ci : bool
            Draw confidence interval band.
        ci_level : float
            Confidence level (default 0.95).
        degree : int
            Polynomial degree (only for method='polynomial').
        """
        series_list = self._series[axis]
        if not series_list:
            raise ValueError(f"No data series on the '{axis}' axis to fit.")
        s = series_list[series_index]
        ax = self._get_ax(axis)
        fit_color = color or s["color"]

        fit = FitToolkit.fit(
            s["x"], s["y"],
            method=method,
            degree=degree,
            ci_level=ci_level,
        )

        x_smooth = np.linspace(s["x"].min(), s["x"].max(), n_points)
        y_smooth = fit["predict"](x_smooth)

        lbl_parts = []
        if label_prefix:
            lbl_parts.append(label_prefix)
        lbl_parts.append(f"{method.title()} fit")
        if show_r2:
            lbl_parts.append(f"R²={fit['r_squared']:.4f}")
        label = " — ".join(lbl_parts)

        ax.plot(x_smooth, y_smooth, color=fit_color, linestyle=linestyle,
                linewidth=linewidth, label=label, **kwargs)

        # Confidence interval
        if show_ci and "ci_lower" in fit:
            ci_lo = fit["ci_lower"](x_smooth)
            ci_hi = fit["ci_upper"](x_smooth)
            ax.fill_between(x_smooth, ci_lo, ci_hi, color=fit_color, alpha=0.12)

        # Equation annotation
        if show_equation and "equation" in fit:
            ax.annotate(
                fit["equation"],
                xy=(0.03, 0.95), xycoords="axes fraction",
                fontsize=8, fontfamily="monospace",
                verticalalignment="top",
                bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="#CCCCCC", alpha=0.85),
            )

        # R² annotation (standalone, positioned below equation area)
        if show_r2 and not show_equation:
            ax.annotate(
                f"R² = {fit['r_squared']:.4f}",
                xy=(0.03, 0.95), xycoords="axes fraction",
                fontsize=9, fontweight="bold",
                verticalalignment="top",
                bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="#CCCCCC", alpha=0.85),
            )

        self._fits.append(fit)
        return self

    # ------------------------------------------------------------------
    # Model suggestion
    # ------------------------------------------------------------------

    def suggest_models(
        self,
        axis: AxisSide = "left",
        series_index: int = -1,
        top_k: int = 5,
        print_report: bool = True,
    ) -> List[Dict[str, Any]]:
        """Analyze a data series and recommend predictive models.

        Returns a ranked list of model recommendations with rationale.
        """
        series_list = self._series[axis]
        if not series_list:
            raise ValueError(f"No data series on '{axis}' axis to analyze.")
        s = series_list[series_index]
        advisor = ModelAdvisor()
        results = advisor.evaluate(s["x"], s["y"], top_k=top_k)
        if print_report:
            advisor.print_report(results)
        return results

    # ------------------------------------------------------------------
    # Real model evaluation (cross-validated)
    # ------------------------------------------------------------------

    def evaluate_models(
        self,
        axis: AxisSide = "left",
        series_index: int = -1,
        *,
        cv: int = 5,
        top_k: Optional[int] = None,
        include: Optional[List[str]] = None,
        exclude: Optional[List[str]] = None,
        sort_by: Optional[str] = None,
        print_report: bool = True,
        plot_comparison: bool = True,
    ) -> List[Dict[str, Any]]:
        """Cross-validate real ML models on a plotted data series.

        Fits and evaluates Random Forest, XGBoost, Neural Networks,
        Gradient Boosting, SVR, and many more against the data.

        Parameters
        ----------
        axis : 'left' or 'right'
        series_index : int
            Which series on that axis (-1 = most recent).
        cv : int
            Cross-validation folds.
        top_k : int or None
            Return only the top-k models.
        include / exclude : list of str
            Filter models by name substring.
        print_report : bool
            Print the ranked table.
        plot_comparison : bool
            Show a horizontal bar chart of model scores.

        Returns
        -------
        Ranked list of dicts with scores, pipelines, and metadata.
        """
        from insightplot.evaluate import AutoEvaluator
        series_list = self._series[axis]
        if not series_list:
            raise ValueError(f"No data series on '{axis}' axis to evaluate.")
        s = series_list[series_index]
        evaluator = AutoEvaluator()
        results = evaluator.run(
            s["x"], s["y"],
            cv=cv, top_k=top_k,
            include=include, exclude=exclude,
            sort_by=sort_by,
        )
        if print_report:
            evaluator.print_report(results)
        if plot_comparison:
            evaluator.plot_comparison(results)
        return results

    # ------------------------------------------------------------------
    # Annotation helpers
    # ------------------------------------------------------------------

    def annotate_point(
        self,
        x: float,
        y: float,
        text: str,
        *,
        axis: AxisSide = "left",
        fontsize: int = 9,
        offset: Tuple[int, int] = (10, 10),
        arrowprops: Optional[Dict] = None,
        **kwargs: Any,
    ) -> "Figure":
        ax = self._get_ax(axis)
        if arrowprops is None:
            arrowprops = dict(arrowstyle="->", color="#555555", lw=1.0)
        ax.annotate(
            text, xy=(x, y), xytext=offset,
            textcoords="offset points", fontsize=fontsize,
            arrowprops=arrowprops, **kwargs,
        )
        return self

    def hline(self, y: float, *, axis: AxisSide = "left",
              color: str = "#999999", linestyle: str = "--",
              linewidth: float = 1.0, label: str = "", **kw) -> "Figure":
        self._get_ax(axis).axhline(y, color=color, linestyle=linestyle,
                                    linewidth=linewidth, label=label, **kw)
        return self

    def vline(self, x: float, *, axis: AxisSide = "left",
              color: str = "#999999", linestyle: str = "--",
              linewidth: float = 1.0, label: str = "", **kw) -> "Figure":
        self._get_ax(axis).axvline(x, color=color, linestyle=linestyle,
                                    linewidth=linewidth, label=label, **kw)
        return self

    # ------------------------------------------------------------------
    # Layout & display
    # ------------------------------------------------------------------

    def legend(self, **kwargs: Any) -> "Figure":
        """Unified legend across both axes."""
        handles, labels = self._ax_left.get_legend_handles_labels()
        if self._ax_right is not None:
            h2, l2 = self._ax_right.get_legend_handles_labels()
            handles += h2
            labels += l2
        self._ax_left.legend(handles, labels, **kwargs)
        return self

    def set_title(self, title: str) -> "Figure":
        self._ax_left.set_title(title)
        return self

    def set_xlabel(self, label: str) -> "Figure":
        self._ax_left.set_xlabel(label)
        return self

    def set_ylabel(self, label: str, axis: AxisSide = "left") -> "Figure":
        self._get_ax(axis).set_ylabel(label)
        return self

    def set_xlim(self, lo: float, hi: float) -> "Figure":
        self._ax_left.set_xlim(lo, hi)
        return self

    def set_ylim(self, lo: float, hi: float, axis: AxisSide = "left") -> "Figure":
        self._get_ax(axis).set_ylim(lo, hi)
        return self

    def tight(self) -> "Figure":
        self._fig.tight_layout()
        return self

    def show(self) -> None:
        self.legend()
        self._fig.tight_layout()
        plt.show()

    def save(self, path: str, **kwargs: Any) -> None:
        self.legend()
        self._fig.tight_layout()
        self._fig.savefig(path, **kwargs)
        plt.close(self._fig)

    @property
    def fig(self) -> plt.Figure:
        return self._fig

    @property
    def ax(self) -> plt.Axes:
        return self._ax_left

    @property
    def ax_right(self) -> Optional[plt.Axes]:
        return self._ax_right


# ------------------------------------------------------------------
# Subplot grid helper
# ------------------------------------------------------------------

def subplot_grid(
    nrows: int = 1,
    ncols: int = 1,
    figsize: Optional[Tuple[float, float]] = None,
    title: str = "",
    sharex: bool = False,
    sharey: bool = False,
) -> Tuple[plt.Figure, np.ndarray]:
    """Create a grid of subplots with InsightPlot styling.

    Returns the raw matplotlib Figure and axes array so you can
    mix InsightPlot helpers with direct matplotlib calls.
    """
    if figsize is None:
        figsize = (5 * ncols, 4 * nrows)
    fig, axes = plt.subplots(nrows, ncols, figsize=figsize,
                              sharex=sharex, sharey=sharey, squeeze=False)
    if title:
        fig.suptitle(title, fontsize=14, fontweight="bold", y=1.02)
    return fig, axes
