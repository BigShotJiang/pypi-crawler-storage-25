from setuptools import setup, find_packages

setup(
    name="insightplot",
    version="0.1.0",
    author="Jeff",
    description="A data science graphing library that visualizes, fits, and recommends predictive models.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[
        "matplotlib>=3.7",
        "numpy>=1.24",
        "scipy>=1.10",
        "scikit-learn>=1.2",
        "seaborn>=0.12",
        "pandas>=2.0",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Topic :: Scientific/Engineering :: Visualization",
        "Intended Audience :: Science/Research",
    ],
)
