"""
InsightPlot test suite.

Run: pytest tests/ -v
"""

import numpy as np
import pytest
import matplotlib
matplotlib.use("Agg")  # non-interactive backend for CI

import insightplot as ip
from insightplot import (
    Figure, FitToolkit, ModelAdvisor, AutoEvaluator,
    HyperTuner, importance,
)


# ── Fixtures ──────────────────────────────────────────────────────

@pytest.fixture
def xy_linear():
    np.random.seed(42)
    x = np.linspace(0, 10, 100)
    y = 3 * x + 5 + np.random.normal(0, 2, 100)
    return x, y


@pytest.fixture
def xy_quadratic():
    np.random.seed(42)
    x = np.linspace(1, 20, 150)
    y = 0.8 * x**2 - 5 * x + 20 + np.random.normal(0, 8, 150)
    return x, y


@pytest.fixture
def Xy_regression():
    from sklearn.datasets import make_regression
    X, y = make_regression(n_samples=200, n_features=6,
                           n_informative=4, noise=10, random_state=42)
    return X, y


@pytest.fixture
def Xy_classification():
    from sklearn.datasets import make_classification
    X, y = make_classification(n_samples=300, n_features=8,
                               n_informative=5, n_classes=3,
                               n_clusters_per_class=1, random_state=42)
    return X, y


@pytest.fixture
def binary_classification():
    from sklearn.datasets import make_classification
    X, y = make_classification(n_samples=300, random_state=42)
    return X, y


# ── Styles ────────────────────────────────────────────────────────

class TestStyles:
    def test_set_theme(self):
        for theme in ip.available_themes():
            ip.set_theme(theme)

    def test_invalid_theme_raises(self):
        with pytest.raises(ValueError):
            ip.set_theme("nonexistent_theme")

    def test_available_themes_nonempty(self):
        assert len(ip.available_themes()) >= 3


# ── Core Figure ───────────────────────────────────────────────────

class TestFigure:
    def test_basic_plot(self, xy_linear):
        x, y = xy_linear
        fig = Figure(title="Test")
        fig.plot(x, y, label="data")
        assert fig.fig is not None

    def test_scatter(self, xy_linear):
        x, y = xy_linear
        fig = Figure()
        fig.scatter(x, y)
        assert len(fig._series["left"]) == 1

    def test_dual_axis(self, xy_linear):
        x, y = xy_linear
        fig = Figure(ylabel_right="Right")
        fig.plot(x, y, axis="left", label="L")
        fig.plot(x, y * 0.5, axis="right", label="R")
        assert fig.ax_right is not None

    def test_add_fit(self, xy_linear):
        x, y = xy_linear
        fig = Figure()
        fig.scatter(x, y)
        fig.add_fit("left", "linear", show_r2=True)
        assert len(fig._fits) == 1

    def test_chaining(self, xy_linear):
        x, y = xy_linear
        fig = (Figure(title="Chain")
               .scatter(x, y, label="data")
               .add_fit("left", "linear")
               .hline(10)
               .vline(5))
        assert fig is not None


# ── Convenience plots ─────────────────────────────────────────────

class TestPlots:
    def test_scatter_oneshot(self, xy_linear):
        x, y = xy_linear
        fig = ip.scatter(x, y, fit="linear", show_r2=True)
        assert fig is not None

    def test_line(self, xy_linear):
        x, y = xy_linear
        fig = ip.line(x, y, title="Line Test")
        assert fig is not None

    def test_histogram(self):
        data = np.random.normal(0, 1, 500)
        fig = ip.histogram(data, kde=True)
        assert fig is not None

    def test_bar(self):
        fig = ip.bar(["A", "B", "C"], [10, 20, 15])
        assert fig is not None


# ── FitToolkit ────────────────────────────────────────────────────

class TestFitToolkit:
    @pytest.mark.parametrize("method", FitToolkit.METHODS)
    def test_fit_method(self, xy_quadratic, method):
        x, y = xy_quadratic
        result = FitToolkit.fit(x, y, method=method)
        assert "r_squared" in result
        assert "predict" in result
        assert callable(result["predict"])

    def test_fit_all(self, xy_quadratic):
        x, y = xy_quadratic
        results = FitToolkit.fit_all(x, y)
        assert len(results) > 0
        # Should be sorted by R²
        r2s = [r["r_squared"] for r in results]
        assert r2s == sorted(r2s, reverse=True)

    def test_invalid_method_raises(self, xy_linear):
        x, y = xy_linear
        with pytest.raises(ValueError):
            FitToolkit.fit(x, y, method="bogus")


# ── ModelAdvisor ──────────────────────────────────────────────────

class TestModelAdvisor:
    def test_evaluate(self, xy_quadratic):
        x, y = xy_quadratic
        advisor = ModelAdvisor()
        results = advisor.evaluate(x, y, top_k=3)
        assert len(results) == 3
        assert "score" in results[0]
        assert "rationale" in results[0]

    def test_binary_detection(self):
        x = np.random.normal(0, 1, 100)
        y = (x > 0).astype(float)
        advisor = ModelAdvisor()
        results = advisor.evaluate(x, y, top_k=3)
        # Should detect binary and recommend classification models
        cats = [r["category"] for r in results]
        assert "classification" in cats


# ── Confusion Matrix ──────────────────────────────────────────────

class TestConfusionMatrix:
    def test_basic(self):
        y_true = [0, 1, 1, 0, 1, 0, 1, 1]
        y_pred = [0, 1, 0, 0, 1, 1, 1, 1]
        fig = ip.confusion_matrix(y_true, y_pred)
        assert fig is not None

    def test_multiclass_with_metrics(self):
        y_true = [0, 1, 2, 0, 1, 2, 0, 1, 2]
        y_pred = [0, 1, 1, 0, 2, 2, 0, 1, 0]
        fig, metrics = ip.confusion_matrix(
            y_true, y_pred, return_metrics=True,
            labels=["A", "B", "C"],
        )
        assert "accuracy" in metrics
        assert "per_class" in metrics
        assert len(metrics["per_class"]) == 3


# ── ROC Curve ─────────────────────────────────────────────────────

class TestROC:
    def test_binary_roc(self, binary_classification):
        from sklearn.linear_model import LogisticRegression
        from sklearn.model_selection import train_test_split
        X, y = binary_classification
        Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.3, random_state=42)
        model = LogisticRegression(max_iter=1000).fit(Xtr, ytr)
        scores = model.predict_proba(Xte)[:, 1]
        fig, metrics = ip.roc_curve(yte, scores, return_metrics=True)
        assert 0 <= metrics["auc"] <= 1
        assert "optimal_threshold" in metrics


# ── AutoEvaluator ─────────────────────────────────────────────────

class TestAutoEvaluator:
    def test_regression(self, Xy_regression):
        X, y = Xy_regression
        ev = AutoEvaluator()
        results = ev.run(X, y, verbose=False,
                         include=["linear", "ridge", "random forest"])
        assert len(results) >= 2
        assert results[0]["primary_score"] >= results[-1]["primary_score"]

    def test_classification(self, Xy_classification):
        X, y = Xy_classification
        ev = AutoEvaluator()
        results = ev.run(X, y, verbose=False,
                         include=["logistic", "random forest"])
        assert len(results) >= 2
        assert all(r["status"] == "ok" for r in results)

    def test_to_dataframe(self, Xy_regression):
        X, y = Xy_regression
        ev = AutoEvaluator()
        results = ev.run(X, y, verbose=False, include=["ridge", "lasso"])
        df = ev.to_dataframe(results)
        assert "rank" in df.columns
        assert len(df) >= 2


# ── HyperTuner ────────────────────────────────────────────────────

class TestHyperTuner:
    def test_tune_regression(self, Xy_regression):
        X, y = Xy_regression
        ev = AutoEvaluator()
        results = ev.run(X, y, verbose=False, include=["ridge"])
        tuner = HyperTuner(n_iter=5, cv=3)
        tuned = tuner.tune(X, y, results, top_k=1, verbose=False)
        assert len(tuned) == 1
        assert "best_score" in tuned[0]
        assert "best_params" in tuned[0]


# ── Feature Importance ────────────────────────────────────────────

class TestImportance:
    def test_permutation(self, Xy_regression):
        from sklearn.ensemble import RandomForestRegressor
        X, y = Xy_regression
        model = RandomForestRegressor(n_estimators=50, random_state=42).fit(X, y)
        result = importance.permutation(model, X, y, n_repeats=5)
        assert len(result["importances_mean"]) == X.shape[1]
        assert len(result["sorted_indices"]) == X.shape[1]

    def test_builtin(self, Xy_regression):
        from sklearn.ensemble import RandomForestRegressor
        X, y = Xy_regression
        model = RandomForestRegressor(n_estimators=50, random_state=42).fit(X, y)
        result = importance.builtin(model)
        assert len(result["importances_mean"]) == X.shape[1]

    def test_correlation(self, Xy_regression):
        X, y = Xy_regression
        result = importance.correlation(X, y)
        assert "pearson" in result["sub_methods"]
        assert "spearman" in result["sub_methods"]

    def test_drop_column(self, Xy_regression):
        from sklearn.linear_model import Ridge
        from sklearn.pipeline import Pipeline
        from sklearn.preprocessing import StandardScaler
        X, y = Xy_regression
        model = Pipeline([("scaler", StandardScaler()), ("model", Ridge())])
        result = importance.drop_column(model, X, y, cv=3)
        assert "baseline_score" in result
        assert len(result["importances_mean"]) == X.shape[1]

    def test_plot_importance(self, Xy_regression):
        from sklearn.ensemble import RandomForestRegressor
        X, y = Xy_regression
        model = RandomForestRegressor(n_estimators=50, random_state=42).fit(X, y)
        result = importance.permutation(model, X, y, n_repeats=5)
        fig = importance.plot_importance(result)
        assert fig is not None
