# Changelog

## 0.1.4 - 2026-04-03

- finalized billing-window Phase 2 so billing-window usage is the active quota truth
- fixed terminal execution status handling so success persists as `completed` and failure persists as `failed`
- fixed worker heartbeat/admin summary consistency so admin worker readiness reflects live worker activity more accurately

## 0.1.3 - 2026-04-03

- bumped the package version for the previous release-ready SDK/doc pass
