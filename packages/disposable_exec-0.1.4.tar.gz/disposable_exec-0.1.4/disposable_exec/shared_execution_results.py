from __future__ import annotations

import json
import os

from .redis_connection import create_redis_client


class SharedExecutionResultsUnavailable(RuntimeError):
    pass


def _is_truthy(value: str | None) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def is_shared_execution_results_backing_enabled() -> bool:
    return _is_truthy(
        os.getenv("DISPOSABLE_EXEC_SHARED_EXECUTION_RESULTS_ENABLED")
        or os.getenv("SHARED_EXECUTION_RESULTS_ENABLED")
    )


def _get_prefix() -> str:
    return (
        os.getenv("DISPOSABLE_EXEC_SHARED_EXECUTION_RESULTS_PREFIX", "").strip()
        or "disposable_exec:shared_execution_results"
    )


def _execution_key(execution_id: str) -> str:
    return f"{_get_prefix()}:execution:{execution_id}"


def _decode_text(value) -> str | None:
    if value is None:
        return None
    if isinstance(value, bytes):
        return value.decode("utf-8")
    return str(value)


def _decode_json_dict(value) -> dict | None:
    text = _decode_text(value)
    if not text:
        return None
    return json.loads(text)


def _get_client():
    try:
        return create_redis_client()
    except Exception as exc:
        raise SharedExecutionResultsUnavailable(str(exc)) from exc


def get_shared_execution_result(execution_id: str) -> dict | None:
    if not execution_id:
        return None
    try:
        client = _get_client()
        return _decode_json_dict(client.get(_execution_key(execution_id)))
    except Exception as exc:
        raise SharedExecutionResultsUnavailable(str(exc)) from exc


def upsert_shared_execution_result(row: dict) -> dict:
    execution_id = str(row.get("execution_id") or "").strip()
    if not execution_id:
        raise ValueError("execution_id is required")

    serialized = json.dumps(row, separators=(",", ":"), sort_keys=True)
    try:
        client = _get_client()
        client.set(_execution_key(execution_id), serialized)
    except Exception as exc:
        raise SharedExecutionResultsUnavailable(str(exc)) from exc
    return row
