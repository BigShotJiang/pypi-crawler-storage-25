import os
import secrets
import threading
from datetime import datetime
from datetime import timezone
from time import monotonic
import json

from .db import get_app_state, set_app_state
from .db_adapter import run_business_transaction
from .stores.usage import get_credit_used as store_get_credit_used
from .stores.usage import get_usage_count as store_get_usage_count
from .stores.usage import increment_usage as store_increment_usage


_USAGE_COUNT_CACHE_LOCK = threading.Lock()
_USAGE_COUNT_CACHE: dict[tuple[str, str], tuple[float, int]] = {}

DIAGNOSTICS_CREDIT_TIER_SMALL_MAX_BYTES = 128 * 1024
DIAGNOSTICS_CREDIT_TIER_MEDIUM_MAX_BYTES = 512 * 1024
EXECUTION_CREDIT_TIER_SMALL_MAX_BYTES = 64 * 1024
EXECUTION_CREDIT_TIER_MEDIUM_MAX_BYTES = 256 * 1024


def get_period_key() -> str:
    # Compatibility helper only. Billing-window quota enforcement and user-facing
    # usage truth must use resolve_usage_period_for_user(...).period_key instead.
    return datetime.utcnow().strftime("%Y-%m")


def _text_bytes(value: str) -> int:
    return len((value or "").encode("utf-8"))


def compute_diagnostics_credits(total_content_bytes: int) -> float:
    size = max(0, int(total_content_bytes or 0))
    if size <= DIAGNOSTICS_CREDIT_TIER_SMALL_MAX_BYTES:
        return 0.25
    if size <= DIAGNOSTICS_CREDIT_TIER_MEDIUM_MAX_BYTES:
        return 0.5
    return 1.0


def compute_execution_credits(total_content_bytes: int) -> float:
    size = max(0, int(total_content_bytes or 0))
    if size <= EXECUTION_CREDIT_TIER_SMALL_MAX_BYTES:
        return 1.0
    if size <= EXECUTION_CREDIT_TIER_MEDIUM_MAX_BYTES:
        return 1.5
    return 2.0


def build_payload_usage_metadata(payload: dict | None) -> dict:
    if not isinstance(payload, dict):
        return {
            "input_mode": "unknown",
            "file_count": 0,
            "total_content_bytes": 0,
            "max_single_file_bytes": 0,
            "entrypoint": None,
        }

    if payload.get("input_mode") in {"script", "files", "unknown"}:
        return {
            "input_mode": payload.get("input_mode") or "unknown",
            "file_count": int(payload.get("file_count") or 0),
            "total_content_bytes": int(payload.get("total_content_bytes") or 0),
            "max_single_file_bytes": int(payload.get("max_single_file_bytes") or 0),
            "entrypoint": payload.get("entrypoint"),
        }

    if payload.get("mode") in {"script", "files"}:
        return {
            "input_mode": payload["mode"],
            "file_count": int(payload.get("file_count") or 0),
            "total_content_bytes": int(payload.get("total_content_bytes") or 0),
            "max_single_file_bytes": int(payload.get("max_single_file_bytes") or 0),
            "entrypoint": payload.get("entrypoint"),
        }

    script = payload.get("script")
    files = payload.get("files")
    entrypoint = payload.get("entrypoint")
    has_script = script is not None
    has_files_mode = entrypoint is not None or files is not None
    if has_script and not has_files_mode:
        total_content_bytes = _text_bytes(script) if isinstance(script, str) else 0
        return {
            "input_mode": "script",
            "file_count": 1,
            "total_content_bytes": total_content_bytes,
            "max_single_file_bytes": total_content_bytes,
            "entrypoint": None,
        }

    if has_files_mode and not has_script:
        total_content_bytes = 0
        max_single_file_bytes = 0
        file_count = len(files) if isinstance(files, list) else 0
        for item in files or []:
            if not isinstance(item, dict):
                continue
            content = item.get("content")
            if not isinstance(content, str):
                continue
            content_bytes = _text_bytes(content)
            total_content_bytes += content_bytes
            max_single_file_bytes = max(max_single_file_bytes, content_bytes)
        normalized_entrypoint = entrypoint if isinstance(entrypoint, str) and entrypoint.strip() else None
        return {
            "input_mode": "files",
            "file_count": int(file_count),
            "total_content_bytes": int(total_content_bytes),
            "max_single_file_bytes": int(max_single_file_bytes),
            "entrypoint": normalized_entrypoint,
        }

    return {
        "input_mode": "unknown",
        "file_count": 0,
        "total_content_bytes": 0,
        "max_single_file_bytes": 0,
        "entrypoint": entrypoint if isinstance(entrypoint, str) and entrypoint.strip() else None,
    }


def record_usage_event(
    *,
    user_id: str,
    period_key: str | None,
    route_category: str,
    credit_amount: float,
    payload_metadata: dict,
    key_id: str | None = None,
    execution_id: str | None = None,
) -> dict:
    metadata = build_payload_usage_metadata(payload_metadata)

    def _transaction(conn) -> dict:
        usage_event = {
            "id": f"usevt_{secrets.token_hex(8)}",
            "user_id": user_id,
            "period_key": period_key,
            "route_category": route_category,
            "credit_amount": float(credit_amount),
            "input_mode": metadata["input_mode"],
            "file_count": int(metadata["file_count"]),
            "total_content_bytes": int(metadata["total_content_bytes"]),
            "max_single_file_bytes": int(metadata["max_single_file_bytes"]),
            "entrypoint": metadata.get("entrypoint"),
            "key_id": key_id,
            "execution_id": execution_id,
            "created_at": datetime.utcnow().isoformat() + "Z",
        }
        conn.execute(
            """
            INSERT INTO usage_events (
                id, user_id, period_key, route_category, credit_amount,
                input_mode, file_count, total_content_bytes, max_single_file_bytes,
                entrypoint, key_id, execution_id, created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                usage_event["id"],
                usage_event["user_id"],
                usage_event["period_key"],
                usage_event["route_category"],
                usage_event["credit_amount"],
                usage_event["input_mode"],
                usage_event["file_count"],
                usage_event["total_content_bytes"],
                usage_event["max_single_file_bytes"],
                usage_event["entrypoint"],
                usage_event["key_id"],
                usage_event["execution_id"],
                usage_event["created_at"],
            ),
        )
        return usage_event

    usage_event = run_business_transaction(_transaction)
    print(
        "USAGE_EVENT "
        f"user_id={user_id} "
        f"period_key={period_key or ''} "
        f"route_category={route_category} "
        f"credit_amount={usage_event['credit_amount']} "
        f"input_mode={usage_event['input_mode']} "
        f"file_count={usage_event['file_count']} "
        f"total_content_bytes={usage_event['total_content_bytes']} "
        f"max_single_file_bytes={usage_event['max_single_file_bytes']} "
        f"entrypoint={usage_event.get('entrypoint') or ''} "
        f"execution_id={execution_id or ''}",
        flush=True,
    )
    return usage_event


def _usage_count_cache_ttl_seconds() -> float:
    try:
        return max(
            0.0,
            float(
                os.getenv("DISPOSABLE_EXEC_USAGE_COUNT_CACHE_TTL_SECONDS", "").strip()
                or os.getenv("USAGE_COUNT_CACHE_TTL_SECONDS", "").strip()
                or "5"
            ),
        )
    except ValueError:
        return 5.0


def _usage_count_app_state_key(user_id: str, period_key: str) -> str:
    return f"usage_count:{user_id}:{period_key}"


def _parse_app_state_updated_at(value: str | None) -> datetime | None:
    if not value:
        return None
    normalized = str(value).strip()
    if not normalized:
        return None
    if normalized.endswith("Z"):
        normalized = normalized[:-1] + "+00:00"
    try:
        return datetime.fromisoformat(normalized)
    except ValueError:
        return None


def _get_local_usage_count_snapshot(user_id: str, period_key: str) -> tuple[bool, int]:
    ttl_seconds = _usage_count_cache_ttl_seconds()
    try:
        row = get_app_state(_usage_count_app_state_key(user_id, period_key))
    except Exception:
        return False, 0
    if not row or row.get("value") in {None, ""}:
        return False, 0
    updated_at = _parse_app_state_updated_at(row.get("updated_at"))
    if ttl_seconds > 0 and updated_at is not None:
        age_seconds = (datetime.now(timezone.utc) - updated_at.astimezone(timezone.utc)).total_seconds()
        if age_seconds > ttl_seconds:
            return False, 0
    try:
        payload = json.loads(row["value"])
    except (TypeError, ValueError, json.JSONDecodeError):
        return False, 0
    if not isinstance(payload, dict) or "count" not in payload:
        return False, 0
    try:
        return True, int(payload["count"])
    except (TypeError, ValueError):
        return False, 0


def _set_local_usage_count_snapshot(user_id: str, period_key: str, count: int) -> None:
    try:
        set_app_state(
            _usage_count_app_state_key(user_id, period_key),
            json.dumps({"count": int(count)}, separators=(",", ":"), sort_keys=True),
        )
    except Exception:
        return


def get_usage_count(user_id: str, period_key: str | None = None, prefer_fresh: bool = False) -> int:
    if period_key is None:
        # Default only for compatibility callers. Billing-window quota truth
        # should always pass the resolved billing period key explicitly.
        period_key = get_period_key()
    path_label = "fresh_business" if prefer_fresh else "cached_snapshot"
    print(
        f"USAGE_LOOKUP_PATH user_id={user_id} period_key={period_key} path={path_label}",
        flush=True,
    )
    cache_key = (user_id, period_key)
    if not prefer_fresh:
        ttl_seconds = _usage_count_cache_ttl_seconds()
        now = monotonic()
        with _USAGE_COUNT_CACHE_LOCK:
            cached = _USAGE_COUNT_CACHE.get(cache_key)
            if cached and ttl_seconds > 0 and (now - cached[0]) <= ttl_seconds:
                return int(cached[1])
        local_hit, local_count = _get_local_usage_count_snapshot(user_id, period_key)
        if local_hit:
            with _USAGE_COUNT_CACHE_LOCK:
                _USAGE_COUNT_CACHE[cache_key] = (monotonic(), int(local_count))
            return int(local_count)
    count = store_get_usage_count(user_id, period_key)
    with _USAGE_COUNT_CACHE_LOCK:
        _USAGE_COUNT_CACHE[cache_key] = (monotonic(), int(count))
    _set_local_usage_count_snapshot(user_id, period_key, int(count))
    return count


def get_usage_count_for_period(
    user_id: str,
    *,
    period_key: str,
    prefer_fresh: bool = False,
) -> int:
    count = get_usage_count(user_id, period_key=period_key, prefer_fresh=prefer_fresh)
    print(
        "USAGE_BILLING_WINDOW_READ "
        f"user_id={user_id} billing_period_key={period_key} count={count}",
        flush=True,
    )
    return int(count)


def get_credit_used(user_id: str, period_key: str | None = None) -> float:
    if period_key is None:
        # Default only for compatibility callers. Billing-window quota truth
        # should always pass the resolved billing period key explicitly.
        period_key = get_period_key()
    return float(store_get_credit_used(user_id, period_key))


def get_credit_used_for_period(
    user_id: str,
    *,
    period_key: str,
) -> float:
    credit_used = get_credit_used(user_id, period_key=period_key)
    print(
        "USAGE_CREDIT_BILLING_WINDOW_READ "
        f"user_id={user_id} billing_period_key={period_key} credit_used={credit_used}",
        flush=True,
    )
    return float(credit_used)


def get_usage_count_with_legacy_fallback(
    user_id: str,
    *,
    period_key: str,
    legacy_period_key: str | None = None,
    prefer_fresh: bool = False,
) -> tuple[int, str]:
    # TODO: remove after all internal imports are switched to get_usage_count_for_period.
    return get_usage_count_for_period(
        user_id,
        period_key=period_key,
        prefer_fresh=prefer_fresh,
    ), "billing_window"


def get_credit_used_with_legacy_fallback(
    user_id: str,
    *,
    period_key: str,
    legacy_period_key: str | None = None,
) -> tuple[float, str]:
    # TODO: remove after all internal imports are switched to get_credit_used_for_period.
    return get_credit_used_for_period(
        user_id,
        period_key=period_key,
    ), "billing_window"


def get_remaining_credits(*, used_credits: float, quota: int) -> float:
    return max(0.0, float(quota) - float(used_credits))


def credit_request_allowed(*, used_credits: float, quota: int, required_credits: float) -> bool:
    return float(used_credits) + float(required_credits) <= float(quota)


def increment_usage(
    user_id: str,
    period_key: str | None = None,
    *,
    credit_delta: float = 0.0,
    increment_execution_count: bool = True,
) -> dict:
    if period_key is None:
        # Default only for compatibility callers. Billing-window quota truth
        # should always pass the resolved billing period key explicitly.
        period_key = get_period_key()
    counters = store_increment_usage(
        user_id,
        period_key,
        credit_delta=float(credit_delta),
        increment_execution_count=increment_execution_count,
    )
    if "|" in period_key:
        print(
            f"USAGE_WRITE_PATH user_id={user_id} period_key={period_key} path=billing_window_counter_written",
            flush=True,
        )
    with _USAGE_COUNT_CACHE_LOCK:
        _USAGE_COUNT_CACHE[(user_id, period_key)] = (monotonic(), int(counters["execution_count"]))
    _set_local_usage_count_snapshot(user_id, period_key, int(counters["execution_count"]))
    return counters
