import json
import os
import threading
import uuid
from time import perf_counter
from datetime import datetime, timedelta, timezone

from disposable_exec.db import get_app_state, set_app_state
from disposable_exec.redis_connection import create_redis_client
from disposable_exec.status import set_status
from disposable_exec.stores.execution_payloads import save_execution_payload
from disposable_exec.stores.execution_status import get_execution_status_row, record_execution_claim_ownership
from disposable_exec.stores.workers import get_worker, is_worker_heartbeat_fresh, select_dispatch_worker


r = create_redis_client()
QUEUE = "exec_queue"
RUN_QUEUE_MAX_DEPTH = max(1, int(os.getenv("RUN_QUEUE_MAX_DEPTH", "100")))
ASSIGNED_QUEUE_RECLAIM_SECONDS = max(10, int(os.getenv("ASSIGNED_QUEUE_RECLAIM_SECONDS", "30")))
EXECUTION_LEASE_SECONDS = max(
    15,
    int(
        os.getenv("DISPOSABLE_EXEC_EXECUTION_LEASE_SECONDS", "").strip()
        or os.getenv("EXECUTION_LEASE_SECONDS", "").strip()
        or "30"
    ),
)
DEBUG_ASSIGNED_VISIBILITY = (
    (os.getenv("DISPOSABLE_EXEC_DEBUG_ASSIGNED_VISIBILITY", "") or "").strip().lower() in {"1", "true", "yes", "on"}
)
QUEUE_DEPTH_APP_STATE_KEY = "queue_depth"
_QUEUE_DEPTH_CACHE_LOCK = threading.Lock()
_QUEUE_DEPTH_CACHE: int | None = None


def _log_queue_timing(*, execution_id: str | None, queue_step: str, started_at: float):
    elapsed_ms = round((perf_counter() - started_at) * 1000, 1)
    print(
        f"QUEUE_TIMING execution_id={execution_id or ''} queue_step={queue_step} elapsed_ms={elapsed_ms}",
        flush=True,
    )


def get_queue_depth() -> int:
    try:
        global _QUEUE_DEPTH_CACHE
        with _QUEUE_DEPTH_CACHE_LOCK:
            if _QUEUE_DEPTH_CACHE is not None:
                return int(_QUEUE_DEPTH_CACHE)
        app_state_row = get_app_state(QUEUE_DEPTH_APP_STATE_KEY)
        if app_state_row and app_state_row.get("value") not in {None, ""}:
            depth = max(0, int(app_state_row["value"]))
            with _QUEUE_DEPTH_CACHE_LOCK:
                _QUEUE_DEPTH_CACHE = depth
            return depth
        depth = int(r.llen(QUEUE))
        with _QUEUE_DEPTH_CACHE_LOCK:
            _QUEUE_DEPTH_CACHE = depth
        set_app_state(QUEUE_DEPTH_APP_STATE_KEY, str(depth))
        return depth
    except Exception:
        return 0


def _set_queue_depth_cache(depth: int) -> None:
    global _QUEUE_DEPTH_CACHE
    normalized_depth = max(0, int(depth))
    with _QUEUE_DEPTH_CACHE_LOCK:
        _QUEUE_DEPTH_CACHE = normalized_depth
    set_app_state(QUEUE_DEPTH_APP_STATE_KEY, str(normalized_depth))


def _adjust_queue_depth_cache(delta: int) -> None:
    global _QUEUE_DEPTH_CACHE
    with _QUEUE_DEPTH_CACHE_LOCK:
        if _QUEUE_DEPTH_CACHE is None:
            return
        _QUEUE_DEPTH_CACHE = max(0, int(_QUEUE_DEPTH_CACHE) + int(delta))
        normalized_depth = _QUEUE_DEPTH_CACHE
    set_app_state(QUEUE_DEPTH_APP_STATE_KEY, str(normalized_depth))


def warm_queue_depth_cache() -> int:
    depth = int(r.llen(QUEUE))
    _set_queue_depth_cache(depth)
    return depth


def enqueue_job(
    script: str | None,
    key_id: str,
    user_id: str | None = None,
    language: str | None = None,
    entrypoint: str | None = None,
    files: list[dict] | None = None,
):
    execution_id = str(uuid.uuid4())
    select_dispatch_started_at = perf_counter()
    assigned_worker = select_dispatch_worker()
    _log_queue_timing(
        execution_id=execution_id,
        queue_step="select_dispatch_worker",
        started_at=select_dispatch_started_at,
    )
    assigned_worker_id = assigned_worker["id"] if assigned_worker else None
    return enqueue_existing_job(
        execution_id,
        script=script,
        key_id=key_id,
        user_id=user_id,
        assigned_worker_id=assigned_worker_id,
        language=language,
        entrypoint=entrypoint,
        files=files,
    )


def enqueue_existing_job(
    execution_id: str,
    *,
    script: str | None,
    key_id: str,
    user_id: str | None = None,
    assigned_worker_id: str | None = None,
    language: str | None = None,
    entrypoint: str | None = None,
    files: list[dict] | None = None,
):
    if not execution_id:
        raise ValueError("execution_id is required")
    if get_queue_depth() >= RUN_QUEUE_MAX_DEPTH:
        raise RuntimeError("Execution queue depth threshold exceeded")
    created_at = datetime.utcnow().isoformat() + "Z"

    job = {
        "execution_id": execution_id,
        "created_at": created_at,
        "script": script,
        "language": (language or "python"),
        "key_id": key_id,
        "user_id": user_id,
        "entrypoint": entrypoint,
        "files": files,
        # Future remote-worker preparation: current local dispatch ignores this
        # advisory assignment unless a worker chooses to honor it.
        "assigned_worker_id": assigned_worker_id,
    }

    # Keep original runnable input durable so a later orphan recovery path can
    # reconstruct a safe requeue payload after the Redis queue item is removed.
    payload_persist_started_at = perf_counter()
    save_execution_payload(
        execution_id,
        script=job["script"],
        language=job["language"],
        key_id=key_id,
        user_id=user_id,
        assigned_worker_id=assigned_worker_id,
        entrypoint=entrypoint,
        files=files,
    )
    _log_queue_timing(
        execution_id=execution_id,
        queue_step="save_execution_payload",
        started_at=payload_persist_started_at,
    )
    redis_enqueue_started_at = perf_counter()
    r.lpush(QUEUE, json.dumps(job))
    _adjust_queue_depth_cache(1)
    _log_queue_timing(
        execution_id=execution_id,
        queue_step="redis_enqueue",
        started_at=redis_enqueue_started_at,
    )
    status_started_at = perf_counter()
    set_status(
        execution_id,
        "queued",
        key_id=key_id,
        user_id=user_id,
        created_at=created_at,
        assigned_worker_id=assigned_worker_id,
        skip_existing_lookup=True,
    )
    _log_queue_timing(
        execution_id=execution_id,
        queue_step="queue_status_write",
        started_at=status_started_at,
    )

    return {"execution_id": execution_id, "assigned_worker_id": assigned_worker_id}


def _parse_iso_utc(value: str | None):
    if not value:
        return None
    normalized = str(value).strip()
    if not normalized:
        return None
    if normalized.endswith("Z"):
        normalized = normalized[:-1] + "+00:00"
    try:
        return datetime.fromisoformat(normalized)
    except ValueError:
        return None


def _get_execution_status_row(execution_id: str):
    return get_execution_status_row(execution_id)


def _get_assigned_job_reclaim_inputs(payload: dict) -> dict:
    assigned_worker_id = payload.get("assigned_worker_id")
    execution_id = payload.get("execution_id")

    worker = get_worker(assigned_worker_id) if assigned_worker_id else None
    status_row = _get_execution_status_row(execution_id) if execution_id else None

    worker_state_source = (worker or {}).get("worker_state_source") or "unknown"
    if worker_state_source == "shared":
        worker_state_truth = "shared"
    elif worker_state_source == "sqlite_fallback":
        worker_state_truth = "degraded_sqlite_fallback"
    elif worker_state_source == "sqlite":
        worker_state_truth = "local_sqlite"
    else:
        worker_state_truth = "unknown"

    execution_state_source = (status_row or {}).get("execution_state_source") or "unknown"
    execution_state_truth = (status_row or {}).get("execution_state_truth") or "unknown"

    if worker_state_truth == "shared" and execution_state_truth == "shared":
        reclaim_truth = "shared"
    elif "degraded_sqlite_fallback" in {worker_state_truth, execution_state_truth}:
        reclaim_truth = "degraded_sqlite_fallback"
    elif worker_state_truth == "local_sqlite" and execution_state_truth == "local_sqlite":
        reclaim_truth = "local_sqlite"
    else:
        reclaim_truth = "mixed"

    return {
        "assigned_worker_id": assigned_worker_id,
        "execution_id": execution_id,
        "worker": worker,
        "worker_state_source": worker_state_source,
        "worker_state_truth": worker_state_truth,
        "execution_status": status_row,
        "execution_state_source": execution_state_source,
        "execution_state_truth": execution_state_truth,
        "reclaim_truth": reclaim_truth,
    }


def _get_assigned_job_reclaim_reason(payload: dict) -> str | None:
    reclaim_inputs = _get_assigned_job_reclaim_inputs(payload)
    assigned_worker_id = reclaim_inputs["assigned_worker_id"]
    execution_id = reclaim_inputs["execution_id"]
    if not assigned_worker_id or not execution_id:
        return None

    worker = reclaim_inputs["worker"]
    if not worker or not bool(worker.get("enabled")):
        return "assigned_worker_unavailable"

    worker_status = worker.get("status")
    if worker_status in {"disabled", "offline"}:
        return f"assigned_worker_status_{worker_status}"

    if not is_worker_heartbeat_fresh(worker.get("last_heartbeat_at")):
        return "assigned_worker_stale"

    status_row = reclaim_inputs["execution_status"]
    if not status_row or status_row.get("status") != "queued":
        return None

    updated_at = _parse_iso_utc(status_row.get("updated_at"))
    if not updated_at:
        return None

    age_seconds = (datetime.now(timezone.utc) - updated_at).total_seconds()
    if age_seconds >= ASSIGNED_QUEUE_RECLAIM_SECONDS:
        return f"queued_stale_{int(age_seconds)}s"

    return None


def dequeue_job(worker_id: str | None = None, *, allow_unassigned: bool = True):
    raw_items = r.lrange(QUEUE, 0, -1)
    if not raw_items:
        return None

    for raw in reversed(raw_items):
        payload = json.loads(raw)
        assigned_worker_id = payload.get("assigned_worker_id")

        if assigned_worker_id and DEBUG_ASSIGNED_VISIBILITY:
            print(
                "QUEUE_ASSIGNED_JOB_VISIBLE "
                f"worker_id={worker_id or ''} execution_id={payload.get('execution_id', '')} "
                f"assigned_worker_id={assigned_worker_id}",
                flush=True,
            )

        if not allow_unassigned and not assigned_worker_id:
            continue
        if assigned_worker_id and worker_id and assigned_worker_id != worker_id:
            reclaim_reason = _get_assigned_job_reclaim_reason(payload)
            if not reclaim_reason:
                continue
            payload["reclaimed_assigned_job"] = True
            payload["reclaimed_from_worker_id"] = assigned_worker_id
            payload["assigned_worker_id"] = worker_id
            print(
                "QUEUE_ASSIGNED_JOB_RECLAIMED "
                f"worker_id={worker_id} execution_id={payload.get('execution_id', '')} "
                f"previous_assigned_worker_id={assigned_worker_id} reason={reclaim_reason}",
                flush=True,
            )

        remove_started_at = perf_counter()
        removed = r.lrem(QUEUE, 1, raw)
        _log_queue_timing(
            execution_id=payload.get("execution_id"),
            queue_step="redis_remove",
            started_at=remove_started_at,
        )
        if not removed:
            continue
        _adjust_queue_depth_cache(-1)

        print(
            "QUEUE_JOB_CLAIMED "
            f"worker_id={worker_id or ''} execution_id={payload.get('execution_id', '')} "
            f"assigned_worker_id={assigned_worker_id or ''}",
            flush=True,
        )
        if worker_id and payload.get("execution_id"):
            claim_token = str(uuid.uuid4())
            claimed_at = datetime.utcnow().isoformat() + "Z"
            claim_write_started_at = perf_counter()
            claim_info = record_execution_claim_ownership(
                payload["execution_id"],
                worker_id=worker_id,
                claim_token=claim_token,
                claimed_at=claimed_at,
                key_id=payload.get("key_id"),
                user_id=payload.get("user_id"),
                assigned_worker_id=payload.get("assigned_worker_id") or worker_id,
                completed_by_worker_id=payload.get("assigned_worker_id") or worker_id,
                created_at=payload.get("created_at"),
                lease_expires_at=(datetime.now(timezone.utc) + timedelta(seconds=EXECUTION_LEASE_SECONDS))
                .isoformat()
                .replace("+00:00", "Z"),
                last_lease_renewed_at=claimed_at,
                recovery_attempt_count=0,
                requeueable=True,
            )
            _log_queue_timing(
                execution_id=payload.get("execution_id"),
                queue_step="record_claim_ownership",
                started_at=claim_write_started_at,
            )
            payload["status"] = claim_info["status"]
            payload["claim_owner_worker_id"] = claim_info["claim_owner_worker_id"]
            payload["claim_token"] = claim_info["claim_token"]
            payload["claim_marked_at"] = claim_info["claim_marked_at"]
            payload["lease_expires_at"] = claim_info["lease_expires_at"]
            payload["last_lease_renewed_at"] = claim_info["last_lease_renewed_at"]
            payload["recovery_attempt_count"] = claim_info["recovery_attempt_count"]
            payload["requeueable"] = claim_info["requeueable"]
            payload["claim_state_source"] = claim_info["claim_state_source"]
            payload["claim_state_truth"] = claim_info["claim_state_truth"]
        return_started_at = perf_counter()
        _log_queue_timing(
            execution_id=payload.get("execution_id"),
            queue_step="claim_path_before_return",
            started_at=return_started_at,
        )
        return payload

    return None


def get_queue_summary(limit: int = 20):
    count = get_queue_depth()
    raw_all = r.lrange(QUEUE, 0, -1)
    raw_items = raw_all[: max(0, int(limit))]
    items = []
    by_worker = {}
    for raw in raw_all:
        try:
            payload = json.loads(raw)
        except (TypeError, json.JSONDecodeError):
            continue
        assigned_worker_id = payload.get("assigned_worker_id") or ""
        by_worker[assigned_worker_id] = by_worker.get(assigned_worker_id, 0) + 1
    for raw in raw_items:
        try:
            payload = json.loads(raw)
        except (TypeError, json.JSONDecodeError):
            continue
        items.append(
            {
                "execution_id": payload.get("execution_id"),
                "key_id": payload.get("key_id"),
                "user_id": payload.get("user_id"),
                "assigned_worker_id": payload.get("assigned_worker_id"),
            }
        )
    return {
        "queue": QUEUE,
        "queued": count,
        "by_worker": [
            {
                "worker_id": worker_id,
                "count": total,
            }
            for worker_id, total in sorted(by_worker.items(), key=lambda item: (-item[1], item[0]))
        ],
        "items": items,
    }
