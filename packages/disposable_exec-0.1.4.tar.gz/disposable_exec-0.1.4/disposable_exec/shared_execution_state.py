from __future__ import annotations

import json
import os
import threading
from time import monotonic, perf_counter

from .redis_connection import create_redis_client


class SharedExecutionStateUnavailable(RuntimeError):
    pass


_SHARED_EXECUTION_STATUS_CACHE_LOCK = threading.Lock()
_SHARED_EXECUTION_STATUS_CACHE_ROWS: list[dict] | None = None
_SHARED_EXECUTION_STATUS_CACHE_AT = 0.0


def _is_truthy(value: str | None) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def is_shared_execution_backing_enabled() -> bool:
    return _is_truthy(
        os.getenv("DISPOSABLE_EXEC_SHARED_EXECUTION_STATE_ENABLED")
        or os.getenv("SHARED_EXECUTION_STATE_ENABLED")
    )


def _get_prefix() -> str:
    return (
        os.getenv("DISPOSABLE_EXEC_SHARED_EXECUTION_STATE_PREFIX", "").strip()
        or "disposable_exec:shared_execution_state"
    )


def _execution_key(execution_id: str) -> str:
    return f"{_get_prefix()}:execution:{execution_id}"


def _decode_text(value) -> str | None:
    if value is None:
        return None
    if isinstance(value, bytes):
        return value.decode("utf-8")
    return str(value)


def _decode_json_dict(value) -> dict | None:
    text = _decode_text(value)
    if not text:
        return None
    return json.loads(text)


def _get_client():
    try:
        return create_redis_client()
    except Exception as exc:
        raise SharedExecutionStateUnavailable(str(exc)) from exc


def _log_shared_execution_state_timing(*, state_step: str, started_at: float) -> None:
    elapsed_ms = round((perf_counter() - started_at) * 1000, 1)
    print(
        f"SHARED_EXECUTION_STATE_TIMING state_step={state_step} elapsed_ms={elapsed_ms}",
        flush=True,
    )


def _shared_execution_status_cache_ttl_seconds() -> float:
    try:
        return max(
            0.0,
            float(
                os.getenv("DISPOSABLE_EXEC_SHARED_EXECUTION_STATUS_CACHE_TTL_SECONDS", "").strip()
                or os.getenv("SHARED_EXECUTION_STATUS_CACHE_TTL_SECONDS", "").strip()
                or "1"
            ),
        )
    except ValueError:
        return 1.0


def get_shared_execution_status(execution_id: str) -> dict | None:
    if not execution_id:
        return None
    try:
        client = _get_client()
        return _decode_json_dict(client.get(_execution_key(execution_id)))
    except Exception as exc:
        raise SharedExecutionStateUnavailable(str(exc)) from exc


def list_shared_execution_statuses(*, force_refresh: bool = False) -> list[dict]:
    global _SHARED_EXECUTION_STATUS_CACHE_ROWS, _SHARED_EXECUTION_STATUS_CACHE_AT
    ttl_seconds = _shared_execution_status_cache_ttl_seconds()
    now = monotonic()
    with _SHARED_EXECUTION_STATUS_CACHE_LOCK:
        if (
            not force_refresh
            and _SHARED_EXECUTION_STATUS_CACHE_ROWS is not None
            and ttl_seconds > 0
            and (now - _SHARED_EXECUTION_STATUS_CACHE_AT) <= ttl_seconds
        ):
            return [dict(row) for row in _SHARED_EXECUTION_STATUS_CACHE_ROWS]

        total_started_at = perf_counter()
        try:
            client = _get_client()
            scan_started_at = perf_counter()
            keys = list(client.scan_iter(match=f"{_get_prefix()}:execution:*"))
            _log_shared_execution_state_timing(state_step="scan_execution_keys", started_at=scan_started_at)
            if not keys:
                _SHARED_EXECUTION_STATUS_CACHE_ROWS = []
                _SHARED_EXECUTION_STATUS_CACHE_AT = monotonic()
                _log_shared_execution_state_timing(
                    state_step="list_shared_execution_statuses_total",
                    started_at=total_started_at,
                )
                return []
            mget_started_at = perf_counter()
            values = client.mget(keys)
            _log_shared_execution_state_timing(state_step="mget_execution_rows", started_at=mget_started_at)
        except Exception as exc:
            raise SharedExecutionStateUnavailable(str(exc)) from exc

        decode_started_at = perf_counter()
        items: list[dict] = []
        for value in values or []:
            row = _decode_json_dict(value)
            if row:
                items.append(row)
        _log_shared_execution_state_timing(state_step="decode_execution_rows", started_at=decode_started_at)
        _SHARED_EXECUTION_STATUS_CACHE_ROWS = [dict(row) for row in items]
        _SHARED_EXECUTION_STATUS_CACHE_AT = monotonic()
        _log_shared_execution_state_timing(
            state_step="list_shared_execution_statuses_total",
            started_at=total_started_at,
        )
        return [dict(row) for row in items]


def upsert_shared_execution_status(row: dict) -> dict:
    execution_id = str(row.get("execution_id") or "").strip()
    if not execution_id:
        raise ValueError("execution_id is required")

    serialized = json.dumps(row, separators=(",", ":"), sort_keys=True)
    try:
        client = _get_client()
        client.set(_execution_key(execution_id), serialized)
    except Exception as exc:
        raise SharedExecutionStateUnavailable(str(exc)) from exc
    return row
