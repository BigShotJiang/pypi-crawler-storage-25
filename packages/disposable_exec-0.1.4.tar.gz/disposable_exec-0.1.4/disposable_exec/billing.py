import os
import threading
import uuid
from calendar import monthrange
from datetime import datetime
from datetime import timezone
from time import monotonic
from typing import Any
import json

from .auth import count_api_keys_for_user
from .billing_providers import BillingPortalError, create_billing_portal_session, fetch_polar_subscription, get_polar_config
from .db import create_onboarding_session, create_onboarding_token, ensure_user_record, get_app_state, set_app_state
from .plans import get_plan_quota
from .stores.subscriptions import (
    find_subscription_for_recovery as store_find_subscription_for_recovery,
    get_preferred_subscription_for_user,
    get_subscription_for_onboarding_context as store_get_subscription_for_onboarding_context,
    get_subscription_period_bounds,
    sync_api_keys_plan_for_user as store_sync_api_keys_plan_for_user,
    upsert_subscription_record,
)
from .stores.users import create_user, get_user_by_normalized_email


SUPPORTED_SUBSCRIPTION_STATUSES = {
    "active",
    "canceled",
    "past_due",
    "paused",
    "trialing",
    "incomplete",
}

_LATEST_SUBSCRIPTION_CACHE_LOCK = threading.Lock()
_LATEST_SUBSCRIPTION_CACHE: dict[str, tuple[float, dict[str, Any] | None]] = {}


def now_iso() -> str:
    return datetime.utcnow().isoformat() + "Z"


def _latest_subscription_cache_ttl_seconds() -> float:
    try:
        return max(
            0.0,
            float(
                os.getenv("DISPOSABLE_EXEC_LATEST_SUBSCRIPTION_CACHE_TTL_SECONDS", "").strip()
                or os.getenv("LATEST_SUBSCRIPTION_CACHE_TTL_SECONDS", "").strip()
                or "5"
            ),
        )
    except ValueError:
        return 5.0


def _latest_subscription_app_state_key(user_id: str) -> str:
    return f"latest_subscription:{user_id}"


def _parse_app_state_updated_at(value: str | None) -> datetime | None:
    if not value:
        return None
    normalized = str(value).strip()
    if not normalized:
        return None
    if normalized.endswith("Z"):
        normalized = normalized[:-1] + "+00:00"
    try:
        return datetime.fromisoformat(normalized)
    except ValueError:
        return None


def _get_local_latest_subscription_snapshot(user_id: str) -> tuple[bool, dict[str, Any] | None]:
    ttl_seconds = _latest_subscription_cache_ttl_seconds()
    try:
        row = get_app_state(_latest_subscription_app_state_key(user_id))
    except Exception:
        return False, None
    if not row or row.get("value") in {None, ""}:
        return False, None
    updated_at = _parse_app_state_updated_at(row.get("updated_at"))
    if ttl_seconds > 0 and updated_at is not None:
        age_seconds = (datetime.now(timezone.utc) - updated_at.astimezone(timezone.utc)).total_seconds()
        if age_seconds > ttl_seconds:
            return False, None
    try:
        payload = json.loads(row["value"])
    except (TypeError, ValueError, json.JSONDecodeError):
        return False, None
    if not isinstance(payload, dict) or "subscription" not in payload:
        return False, None
    subscription = payload.get("subscription")
    return True, dict(subscription) if isinstance(subscription, dict) else None


def _set_local_latest_subscription_snapshot(user_id: str, subscription: dict[str, Any] | None) -> None:
    try:
        set_app_state(
            _latest_subscription_app_state_key(user_id),
            json.dumps({"subscription": subscription}, separators=(",", ":"), sort_keys=True),
        )
    except Exception:
        return


def _iso_z(value: datetime) -> str:
    return value.isoformat() + "Z"


def _add_one_calendar_month(value: datetime) -> datetime:
    year = value.year + (1 if value.month == 12 else 0)
    month = 1 if value.month == 12 else value.month + 1
    day = min(value.day, monthrange(year, month)[1])
    return value.replace(year=year, month=month, day=day)


def compute_current_monthly_period_window(anchor: datetime | None = None) -> tuple[str, str]:
    period_start_dt = anchor or datetime.utcnow()
    period_end_dt = _add_one_calendar_month(period_start_dt)
    return _iso_z(period_start_dt), _iso_z(period_end_dt)


def fill_free_subscription_period_window(
    period_start: str | None,
    period_end: str | None,
    *,
    anchor: datetime | None = None,
) -> tuple[str, str]:
    derived_period_start, derived_period_end = compute_current_monthly_period_window(anchor=anchor)
    return period_start or derived_period_start, period_end or derived_period_end


def _build_usage_billing_period_key(period_start: str, period_end: str) -> str:
    return f"{period_start}|{period_end}"


def resolve_usage_period_for_user(user_id: str | None, prefer_fresh: bool = False) -> dict[str, str] | None:
    if not user_id:
        return None

    subscription = get_latest_subscription_for_user(user_id, prefer_fresh=prefer_fresh)
    period_start = None
    period_end = None
    source = "derived_current_monthly_window"

    if subscription:
        period_start = subscription.get("period_start")
        period_end = subscription.get("period_end")
        source = "subscription_period"
        if (
            subscription.get("provider") == "internal"
            and subscription.get("plan") == "Free"
            and (not period_start or not period_end)
        ):
            period_start, period_end = fill_free_subscription_period_window(period_start, period_end)
            source = "free_internal_derived_period"

    if not period_start or not period_end:
        period_start, period_end = compute_current_monthly_period_window()

    period_key = _build_usage_billing_period_key(period_start, period_end)
    print(
        "USAGE_PERIOD_RESOLVED "
        f"user_id={user_id} period_key={period_key} period_start={period_start} period_end={period_end} source={source}",
        flush=True,
    )
    return {
        "period_key": period_key,
        "period_start": period_start,
        "period_end": period_end,
        "source": source,
    }


def normalize_plan(plan: str | None) -> str:
    if not plan:
        return "Free"

    value = str(plan).strip().lower()

    mapping = {
        "free": "Free",
        "starter": "Starter",
        "pro": "Pro",
        "scale": "Scale",
    }

    return mapping.get(value, "Free")


def normalize_status(status: str | None) -> str:
    if not status:
        return "active"

    value = str(status).strip().lower()

    mapping = {
        "active": "active",
        "cancelled": "canceled",
        "canceled": "canceled",
        "past_due": "past_due",
        "past-due": "past_due",
        "paused": "paused",
        "pause": "paused",
        "trialing": "trialing",
        "incomplete": "incomplete",
    }

    result = mapping.get(value, value)
    if result not in SUPPORTED_SUBSCRIPTION_STATUSES:
        return "active"
    return result


def normalize_email(email: str | None) -> str | None:
    if not email:
        return None
    value = str(email).strip().lower()
    return value or None


def extract_user_id(payload: dict[str, Any]) -> str | None:
    candidates = [
        payload.get("user_id"),
        payload.get("userId"),
        payload.get("customer_id"),
        payload.get("customerId"),
        payload.get("user", {}).get("id") if isinstance(payload.get("user"), dict) else None,
        payload.get("customer", {}).get("id") if isinstance(payload.get("customer"), dict) else None,
        payload.get("meta", {}).get("user_id") if isinstance(payload.get("meta"), dict) else None,
        payload.get("metadata", {}).get("user_id") if isinstance(payload.get("metadata"), dict) else None,
        payload.get("custom_data", {}).get("user_id") if isinstance(payload.get("custom_data"), dict) else None,
    ]
    for value in candidates:
        if value:
            return str(value)
    return None


def extract_email(payload: dict) -> str | None:
    if not isinstance(payload, dict):
        return None

    email = payload.get("email")
    if email:
        return str(email).strip()

    customer = payload.get("customer")
    if isinstance(customer, dict):
        email = customer.get("email")
        if email:
            return str(email).strip()

    data = payload.get("data")
    if isinstance(data, dict):
        email = data.get("email")
        if email:
            return str(email).strip()

        customer = data.get("customer")
        if isinstance(customer, dict):
            email = customer.get("email")
            if email:
                return str(email).strip()

    return None


def extract_provider_subscription_id(payload: dict[str, Any]) -> str | None:
    data = payload.get("data") if isinstance(payload.get("data"), dict) else {}

    candidates = [
        payload.get("subscription_id"),
        payload.get("subscriptionId"),
        payload.get("id"),
        data.get("id"),
        data.get("subscription_id"),
    ]
    for value in candidates:
        if value:
            return str(value)
    return None


def extract_provider_customer_id(payload: dict[str, Any]) -> str | None:
    data = payload.get("data") if isinstance(payload.get("data"), dict) else {}
    customer = payload.get("customer") if isinstance(payload.get("customer"), dict) else {}
    data_customer = data.get("customer") if isinstance(data.get("customer"), dict) else {}

    candidates = [
        payload.get("customer_id"),
        payload.get("customerId"),
        data.get("customer_id"),
        data.get("customerId"),
        customer.get("id"),
        data_customer.get("id"),
    ]
    for value in candidates:
        if value:
            return str(value)
    return None


def extract_checkout_id(payload: dict[str, Any]) -> str | None:
    data = payload.get("data") if isinstance(payload.get("data"), dict) else {}
    checkout = payload.get("checkout") if isinstance(payload.get("checkout"), dict) else {}
    data_checkout = data.get("checkout") if isinstance(data.get("checkout"), dict) else {}
    attrs = data.get("attributes") if isinstance(data.get("attributes"), dict) else {}

    candidates = [
        payload.get("checkout_id"),
        payload.get("checkoutId"),
        payload.get("order_id"),
        data.get("checkout_id"),
        data.get("checkoutId"),
        checkout.get("id"),
        data_checkout.get("id"),
        attrs.get("checkout_id"),
        attrs.get("checkoutId"),
    ]
    for value in candidates:
        if value:
            return str(value)
    return None


def extract_plan(payload: dict) -> str:
    data = payload.get("data") if isinstance(payload, dict) else None
    if not isinstance(data, dict):
        return "Free"

    candidates = []

    metadata = data.get("metadata")
    if isinstance(metadata, dict):
        candidates.extend([
            metadata.get("plan"),
            metadata.get("Plan"),
        ])

    product = data.get("product")
    if isinstance(product, dict):
        product_metadata = product.get("metadata")
        if isinstance(product_metadata, dict):
            candidates.extend([
                product_metadata.get("plan"),
                product_metadata.get("Plan"),
            ])

        candidates.extend([
            product.get("name"),
            product.get("description"),
        ])

    for value in candidates:
        if not value:
            continue

        v = str(value).strip()
        if not v:
            continue

        lower_v = v.lower()

        if "starter" in lower_v:
            return "Starter"
        if "pro" in lower_v:
            return "Pro"
        if "scale" in lower_v:
            return "Scale"
        if "free" in lower_v:
            return "Free"

        return v

    return "Free"


def extract_status(payload: dict[str, Any]) -> str:
    data = payload.get("data") if isinstance(payload.get("data"), dict) else {}
    attrs = data.get("attributes") if isinstance(data.get("attributes"), dict) else {}

    candidates = [
        payload.get("status"),
        payload.get("subscription_status"),
        data.get("status"),
        attrs.get("status"),
    ]
    for value in candidates:
        if value:
            return normalize_status(str(value))
    return "active"


def _period_candidate_containers(payload: dict[str, Any]) -> list[dict[str, Any]]:
    containers: list[dict[str, Any]] = []

    def add_container(value: Any):
        if isinstance(value, dict) and value not in containers:
            containers.append(value)

    add_container(payload)

    data = payload.get("data")
    add_container(data)

    if isinstance(data, dict):
        add_container(data.get("attributes"))
        add_container(data.get("object"))

    for container in list(containers):
        add_container(container.get("current_billing_period"))
        add_container(container.get("billing_period"))
        add_container(container.get("current_period"))

    return containers


def extract_period_start(payload: dict[str, Any]) -> str | None:
    for container in _period_candidate_containers(payload):
        candidates = [
            container.get("period_start"),
            container.get("current_period_start"),
            container.get("starts_at"),
            container.get("start_at"),
            container.get("start_date"),
            container.get("start"),
            container.get("from"),
        ]
        for value in candidates:
            if value:
                return str(value)
    return None


def extract_period_end(payload: dict[str, Any]) -> str | None:
    for container in _period_candidate_containers(payload):
        candidates = [
            container.get("period_end"),
            container.get("current_period_end"),
            container.get("ends_at"),
            container.get("end_at"),
            container.get("end_date"),
            container.get("end"),
            container.get("expires_at"),
            container.get("renews_at"),
            container.get("to"),
        ]
        for value in candidates:
            if value:
                return str(value)
    return None


def find_or_create_user_by_email(email: str) -> str:
    email = normalize_email(email)
    if not email:
        raise ValueError("email is required")

    row = get_user_by_normalized_email(email)
    if row:
        return row["id"]

    user_id = f"user_{uuid.uuid4().hex[:12]}"
    return create_user(
        user_id=user_id,
        email=email,
        status="active",
        created_at=now_iso(),
    )


def sync_api_keys_plan_for_user(user_id: str, plan: str):
    store_sync_api_keys_plan_for_user(user_id, plan)


def find_or_create_free_self_serve_user(payload: dict[str, Any]) -> str:
    email = normalize_email(payload.get("email") or payload.get("user_email"))
    if email:
        return find_or_create_user_by_email(email)

    user_id = extract_user_id(payload)
    if user_id:
        return ensure_user_record(user_id, email=email)

    free_user_id = payload.get("free_user_id") or payload.get("freeUserId")
    if free_user_id:
        return ensure_user_record(str(free_user_id), email=email)

    raise ValueError("missing email_or_user_id")


def ensure_free_self_serve_subscription(user_id: str) -> dict[str, Any]:
    subscription_id = f"free_self_serve:{user_id}"
    row = get_subscription_period_bounds("internal", subscription_id)

    resolved_period_start = None
    resolved_period_end = None
    if not row:
        resolved_period_start, resolved_period_end = compute_current_monthly_period_window()
    elif not row["period_start"] or not row["period_end"]:
        resolved_period_start, resolved_period_end = fill_free_subscription_period_window(
            row["period_start"],
            row["period_end"],
        )

    return upsert_subscription(
        user_id=user_id,
        provider="internal",
        provider_subscription_id=subscription_id,
        plan="Free",
        status="active",
        period_start=resolved_period_start,
        period_end=resolved_period_end,
    )


def upsert_subscription(
    *,
    user_id: str,
    provider: str,
    provider_subscription_id: str,
    provider_customer_id: str | None = None,
    plan: str,
    status: str,
    period_start: str | None = None,
    period_end: str | None = None,
) -> dict[str, Any]:
    current_time = now_iso()
    quota_monthly = get_plan_quota(plan)
    existing = get_subscription_period_bounds(provider, provider_subscription_id)
    resolved_period_start = period_start if period_start is not None else (existing or {}).get("period_start")
    resolved_period_end = period_end if period_end is not None else (existing or {}).get("period_end")
    subscription_id = upsert_subscription_record(
        subscription_id=f"sub_{provider}_{provider_subscription_id}",
        user_id=user_id,
        provider=provider,
        provider_subscription_id=provider_subscription_id,
        provider_customer_id=provider_customer_id,
        plan=plan,
        status=status,
        quota_monthly=quota_monthly,
        period_start=resolved_period_start,
        period_end=resolved_period_end,
        current_time=current_time,
    )

    sync_api_keys_plan_for_user(user_id, plan)

    return {
        "ok": True,
        "subscription_id": subscription_id,
        "user_id": user_id,
        "provider": provider,
        "provider_subscription_id": provider_subscription_id,
        "provider_customer_id": provider_customer_id,
        "plan": plan,
        "status": status,
        "quota_monthly": quota_monthly,
        "period_start": resolved_period_start,
        "period_end": resolved_period_end,
    }


def get_latest_subscription_for_user(user_id: str | None, prefer_fresh: bool = False):
    if not user_id:
        return None
    print(
        f"SUBSCRIPTION_LOOKUP_PATH user_id={user_id} path={'fresh' if prefer_fresh else 'cached'}",
        flush=True,
    )
    if not prefer_fresh:
        ttl_seconds = _latest_subscription_cache_ttl_seconds()
        now = monotonic()
        with _LATEST_SUBSCRIPTION_CACHE_LOCK:
            cached = _LATEST_SUBSCRIPTION_CACHE.get(user_id)
            if cached and ttl_seconds > 0 and (now - cached[0]) <= ttl_seconds:
                result = dict(cached[1]) if cached[1] is not None else None
                if result:
                    print(
                        "SUBSCRIPTION_SELECTION "
                        f"user_id={user_id} reason=cached subscription_id={result.get('provider_subscription_id', '')} "
                        f"plan={result.get('plan', '')} status={result.get('status', '')}",
                        flush=True,
                    )
                return result

        local_hit, local_result = _get_local_latest_subscription_snapshot(user_id)
        if local_hit:
            with _LATEST_SUBSCRIPTION_CACHE_LOCK:
                _LATEST_SUBSCRIPTION_CACHE[user_id] = (monotonic(), dict(local_result) if local_result else None)
            if local_result:
                print(
                    "SUBSCRIPTION_SELECTION "
                    f"user_id={user_id} reason=local_snapshot subscription_id={local_result.get('provider_subscription_id', '')} "
                    f"plan={local_result.get('plan', '')} status={local_result.get('status', '')}",
                    flush=True,
                )
            return local_result

    result = get_preferred_subscription_for_user(user_id)
    with _LATEST_SUBSCRIPTION_CACHE_LOCK:
        _LATEST_SUBSCRIPTION_CACHE[user_id] = (monotonic(), dict(result) if result else None)
    _set_local_latest_subscription_snapshot(user_id, dict(result) if result else None)
    if result:
        is_active_paid = (
            str(result.get("status") or "").strip().lower() == "active"
            and str(result.get("plan") or "").strip().lower() != "free"
        )
        print(
            "SUBSCRIPTION_SELECTION "
            f"user_id={user_id} reason={'active_paid_preferred' if is_active_paid else 'latest_row'} subscription_id={result.get('provider_subscription_id', '')} "
            f"plan={result.get('plan', '')} status={result.get('status', '')}",
            flush=True,
        )
    return result


def get_subscription_for_onboarding_context(
    user_id: str | None,
    provider: str | None = None,
    provider_subscription_id: str | None = None,
):
    normalized_provider = (provider or "").strip().lower()
    normalized_subscription_id = (provider_subscription_id or "").strip()
    if user_id and normalized_provider and normalized_subscription_id:
        row = store_get_subscription_for_onboarding_context(
            user_id=user_id,
            provider=normalized_provider,
            provider_subscription_id=normalized_subscription_id,
        )
        if row:
            result = dict(row)
            print(
                "SUBSCRIPTION_SELECTION "
                f"user_id={user_id} reason=onboarding_exact_match subscription_id={result.get('provider_subscription_id', '')} "
                f"plan={result.get('plan', '')} status={result.get('status', '')}",
                flush=True,
            )
            return result

    return get_latest_subscription_for_user(user_id)


def find_subscription_for_recovery(
    *,
    provider: str | None = None,
    provider_subscription_id: str | None = None,
    provider_customer_id: str | None = None,
    user_id: str | None = None,
):
    normalized_provider = (provider or "").strip().lower() or None
    normalized_subscription_id = (provider_subscription_id or "").strip() or None
    normalized_customer_id = (provider_customer_id or "").strip() or None
    return store_find_subscription_for_recovery(
        provider=normalized_provider,
        provider_subscription_id=normalized_subscription_id,
        provider_customer_id=normalized_customer_id,
        user_id=user_id,
    )


def admin_resync_subscription(
    *,
    provider: str | None,
    provider_subscription_id: str | None,
    provider_customer_id: str | None,
    user_id: str | None,
    plan: str | None,
    status: str | None,
    period_start: str | None = None,
    period_end: str | None = None,
):
    existing = find_subscription_for_recovery(
        provider=provider,
        provider_subscription_id=provider_subscription_id,
        provider_customer_id=provider_customer_id,
        user_id=user_id,
    )

    resolved_user_id = (user_id or (existing or {}).get("user_id") or "").strip()
    resolved_provider = ((provider or (existing or {}).get("provider") or "")).strip().lower()
    resolved_provider_subscription_id = (
        (provider_subscription_id or (existing or {}).get("provider_subscription_id") or "").strip()
    )
    resolved_provider_customer_id = (
        (provider_customer_id or (existing or {}).get("provider_customer_id") or "").strip() or None
    )
    resolved_plan = normalize_plan(plan or (existing or {}).get("plan") or "Free")
    resolved_status = normalize_status(status or (existing or {}).get("status") or "active")
    resolved_period_start = period_start
    resolved_period_end = period_end

    if resolved_provider == "polar" and resolved_provider_subscription_id and (
        resolved_period_start is None or resolved_period_end is None
    ):
        try:
            polar_subscription = fetch_polar_subscription(resolved_provider_subscription_id)
        except Exception as exc:
            print(
                "ADMIN_RESYNC_POLAR_LOOKUP_FAILED "
                f"provider_subscription_id={resolved_provider_subscription_id} exception_class={exc.__class__.__name__} detail={exc}",
                flush=True,
            )
        else:
            resolved_period_start = resolved_period_start or extract_period_start(polar_subscription)
            resolved_period_end = resolved_period_end or extract_period_end(polar_subscription)
            if not resolved_provider_customer_id:
                fetched_customer_id = extract_provider_customer_id(polar_subscription)
                resolved_provider_customer_id = fetched_customer_id or resolved_provider_customer_id

    resolved_period_start = resolved_period_start or (existing or {}).get("period_start")
    resolved_period_end = resolved_period_end or (existing or {}).get("period_end")

    if not resolved_user_id:
        raise ValueError("user_id could not be resolved")
    if not resolved_provider:
        raise ValueError("provider could not be resolved")
    if not resolved_provider_subscription_id:
        raise ValueError("provider_subscription_id could not be resolved")

    result = upsert_subscription(
        user_id=resolved_user_id,
        provider=resolved_provider,
        provider_subscription_id=resolved_provider_subscription_id,
        provider_customer_id=resolved_provider_customer_id,
        plan=resolved_plan,
        status=resolved_status,
        period_start=resolved_period_start,
        period_end=resolved_period_end,
    )
    result["matched_existing"] = bool(existing)
    return result


def create_billing_portal_for_user(user_id: str | None) -> dict[str, Any]:
    subscription = get_latest_subscription_for_user(user_id)
    if not subscription:
        print(f"BILLING_PORTAL_MISSING_SUBSCRIPTION_MAPPING user_id={user_id}", flush=True)
        raise BillingPortalError(
            code="billing_portal_unavailable",
            message="Billing portal is not available for this subscription yet.",
            status_code=404,
        )

    plan = normalize_plan(subscription.get("plan"))
    status = normalize_status(subscription.get("status"))
    provider = (subscription.get("provider") or "").strip().lower()
    provider_subscription_id = (subscription.get("provider_subscription_id") or "").strip()
    provider_customer_id = (subscription.get("provider_customer_id") or "").strip() or None
    print(
        "BILLING_PORTAL_SUBSCRIPTION_CONTEXT "
        f"user_id={user_id} provider={provider or ''} subscription_id={provider_subscription_id or ''} "
        f"customer_id={provider_customer_id or ''} plan={plan} status={status}",
        flush=True,
    )

    if plan == "Free":
        raise BillingPortalError(
            code="billing_portal_unavailable",
            message="Billing portal is only available for active paid subscriptions.",
            status_code=403,
        )

    if status != "active":
        raise BillingPortalError(
            code="billing_portal_unavailable",
            message="Billing portal is not available for this subscription yet.",
            status_code=403,
        )

    if not provider or not provider_subscription_id:
        print(
            f"BILLING_PORTAL_MISSING_SUBSCRIPTION_MAPPING user_id={user_id} provider={provider} subscription_id={provider_subscription_id}",
            flush=True,
        )
        raise BillingPortalError(
            code="billing_portal_unavailable",
            message="Billing portal is not available for this subscription yet.",
            status_code=404,
        )

    try:
        return create_billing_portal_session(
            provider=provider,
            provider_subscription_id=provider_subscription_id,
            provider_customer_id=provider_customer_id,
        )
    except BillingPortalError as exc:
        print(
            "BILLING_PORTAL_CREATE_FAILED "
            f"user_id={user_id} provider={provider} subscription_id={provider_subscription_id} "
            f"customer_id={provider_customer_id or ''} code={exc.code} status_code={exc.status_code} detail={exc.message}",
            flush=True,
        )
        raise
    except Exception as exc:
        print(
            "BILLING_PORTAL_CREATE_EXCEPTION "
            f"user_id={user_id} provider={provider} subscription_id={provider_subscription_id} "
            f"customer_id={provider_customer_id or ''} exception_class={exc.__class__.__name__} detail={exc}",
            flush=True,
        )
        raise


def validate_webhook_secret(provider: str, provided_secret: str | None):
    env_map = {
        "paddle": "DISPOSABLE_EXEC_PADDLE_WEBHOOK_SECRET",
        "lemon": "DISPOSABLE_EXEC_LEMON_WEBHOOK_SECRET",
        "stripe": "DISPOSABLE_EXEC_STRIPE_WEBHOOK_SECRET",
    }

    if provider == "polar":
        expected = get_polar_config()["webhook_secret"]
    else:
        env_name = env_map[provider]
        expected = os.getenv(env_name, "").strip()

    if not expected:
        return False, f"{provider} webhook secret is not configured"

    if not provided_secret or provided_secret.strip() != expected:
        return False, f"invalid {provider} webhook secret"

    return True, None


def process_subscription_webhook(provider: str, payload: dict[str, Any]):
    user_id = extract_user_id(payload)
    if not user_id:
        email = extract_email(payload)
        if email:
            user_id = find_or_create_user_by_email(email)

    if not user_id:
        return {"ok": False, "error": "missing user_id_or_email"}

    provider_subscription_id = extract_provider_subscription_id(payload)
    if not provider_subscription_id:
        return {"ok": False, "error": "missing provider_subscription_id"}

    plan = normalize_plan(extract_plan(payload))
    status = normalize_status(extract_status(payload))
    period_start = extract_period_start(payload)
    period_end = extract_period_end(payload)
    provider_checkout_id = extract_checkout_id(payload)
    provider_customer_id = extract_provider_customer_id(payload)

    result = upsert_subscription(
        user_id=user_id,
        provider=provider,
        provider_subscription_id=provider_subscription_id,
        provider_customer_id=provider_customer_id,
        plan=plan,
        status=status,
        period_start=period_start,
        period_end=period_end,
    )

    onboarding_token = None
    onboarding_session = None

    try:
        if status == "active":
            # session should always exist for an active subscription
            onboarding_session = create_onboarding_session(
                user_id=user_id,
                provider=provider,
                provider_subscription_id=provider_subscription_id,
                provider_checkout_id=provider_checkout_id,
                ttl_minutes=60,
            )

            # manual fallback token only for users with no keys yet
            existing_key_count = count_api_keys_for_user(user_id)
            if existing_key_count == 0:
                onboarding_token = create_onboarding_token(
                    user_id=user_id,
                    purpose="claim_first_key",
                    ttl_minutes=30,
                )
    except Exception as e:
        print("ONBOARDING_SESSION_CREATE_ERROR =", str(e), flush=True)

    result["provider_checkout_id"] = provider_checkout_id
    result["onboarding_token"] = onboarding_token["raw_token"] if onboarding_token else None
    result["onboarding_session_token"] = onboarding_session["raw_token"] if onboarding_session else None
    return result


def handle_paddle_webhook(payload: dict[str, Any]):
    return process_subscription_webhook("paddle", payload)


def handle_lemon_webhook(payload: dict[str, Any]):
    return process_subscription_webhook("lemon", payload)


def handle_polar_webhook(payload: dict[str, Any]):
    return process_subscription_webhook("polar", payload)


def handle_stripe_webhook(payload: dict[str, Any]):
    return process_subscription_webhook("stripe", payload)
