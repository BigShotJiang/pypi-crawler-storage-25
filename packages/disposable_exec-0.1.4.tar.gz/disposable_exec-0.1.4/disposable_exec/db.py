import hashlib
import os
import secrets
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path

try:
    import psycopg2
    from psycopg2 import pool as psycopg2_pool
    from psycopg2.extras import RealDictCursor
except ImportError:  # pragma: no cover - optional dependency at import time
    psycopg2 = None
    psycopg2_pool = None
    RealDictCursor = None


BASE_DIR = Path(__file__).resolve().parent
STORAGE_DIR = BASE_DIR / "storage"
STORAGE_DIR.mkdir(parents=True, exist_ok=True)

DB_PATH = STORAGE_DIR / "app.db"
WORKER_HEARTBEAT_MAX_AGE_SECONDS = max(30, int(os.getenv("WORKER_HEARTBEAT_MAX_AGE_SECONDS", "120")))
DISPATCH_RUNNING_STATUSES = ("queued", "claimed", "running")
NON_ASSIGNABLE_WORKER_STATUSES = {"disabled", "draining", "offline"}
POSTGRES_BUSINESS_SCHEMA_LOCK_KEYS = (43821, 20260330)
_BUSINESS_PG_POOL = None
_BUSINESS_PG_POOL_DSN = None


def _runtime_requires_business_db() -> bool:
    env = (os.getenv("ENV", "") or os.getenv("APP_ENV", "") or os.getenv("DISPOSABLE_EXEC_ENV", "")).strip().lower()
    return env in {"prod", "production", "staging"}


def get_api_key_prefix() -> str:
    env = (os.getenv("POLAR_ENV", "live") or "live").strip().lower()
    return "exec_sbx_" if env == "sandbox" else "exec_live_"


def create_row_mapped_sqlite_conn(db_path: str | Path, *, runtime: bool = False):
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    if runtime:
        # Runtime SQLite is hit by API + local worker on the same host, so use
        # WAL mode to reduce reader/writer blocking on the hot execution path.
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA busy_timeout=5000")
    return conn


def _translate_qmark_sql_for_postgres(query: str) -> str:
    # Keep business store SQL low-blast-radius by translating sqlite-style
    # placeholders for the PostgreSQL business connection path.
    return query.replace("?", "%s")


class PostgresCursorAdapter:
    def __init__(self, cursor):
        self._cursor = cursor

    @property
    def rowcount(self) -> int:
        return self._cursor.rowcount

    def execute(self, query: str, params=()):
        self._cursor.execute(_translate_qmark_sql_for_postgres(query), tuple(params))
        return self

    def fetchone(self):
        row = self._cursor.fetchone()
        return dict(row) if row is not None else None

    def fetchall(self):
        return [dict(row) for row in self._cursor.fetchall()]

    def close(self):
        self._cursor.close()


class PostgresBusinessConnection:
    db_kind = "postgres_business"

    def __init__(self, conn, *, pool=None):
        if psycopg2 is None or RealDictCursor is None:
            raise RuntimeError("psycopg2-binary is required for PostgreSQL BUSINESS_DATABASE_URL support")
        self._conn = conn
        self._pool = pool

    def cursor(self):
        return PostgresCursorAdapter(self._conn.cursor(cursor_factory=RealDictCursor))

    def execute(self, query: str, params=()):
        cursor = self.cursor()
        return cursor.execute(query, params)

    def commit(self):
        self._conn.commit()

    def rollback(self):
        self._conn.rollback()

    def close(self):
        if self._pool is not None:
            try:
                self._conn.rollback()
            except Exception:
                pass
            self._pool.putconn(self._conn)
            return
        self._conn.close()


def _get_business_pg_pool():
    global _BUSINESS_PG_POOL, _BUSINESS_PG_POOL_DSN
    if psycopg2 is None or RealDictCursor is None or psycopg2_pool is None:
        raise RuntimeError("psycopg2-binary is required for PostgreSQL BUSINESS_DATABASE_URL support")
    dsn = _get_business_database_url()
    if not dsn:
        raise RuntimeError("BUSINESS_DATABASE_URL is required for PostgreSQL business connections")
    if _BUSINESS_PG_POOL is not None and _BUSINESS_PG_POOL_DSN == dsn:
        return _BUSINESS_PG_POOL

    minconn = max(1, int(os.getenv("BUSINESS_DB_POOL_MIN_CONN", "1")))
    maxconn = max(minconn, int(os.getenv("BUSINESS_DB_POOL_MAX_CONN", "8")))
    _BUSINESS_PG_POOL = psycopg2_pool.ThreadedConnectionPool(minconn, maxconn, dsn)
    _BUSINESS_PG_POOL_DSN = dsn
    return _BUSINESS_PG_POOL


def get_runtime_conn():
    return create_row_mapped_sqlite_conn(DB_PATH, runtime=True)


def _get_business_database_url() -> str:
    return (os.getenv("BUSINESS_DATABASE_URL", "") or "").strip()


def is_business_db_configured() -> bool:
    return bool(_get_business_database_url())


def is_postgres_business_db() -> bool:
    normalized = _get_business_database_url().lower()
    return normalized.startswith("postgresql://") or normalized.startswith("postgres://")


def _resolve_business_sqlite_target() -> str | Path | None:
    raw_value = _get_business_database_url()
    if not raw_value:
        return None

    normalized = raw_value.lower()
    if normalized.startswith("postgresql://") or normalized.startswith("postgres://"):
        return None
    if normalized.startswith("sqlite:///"):
        target = raw_value[len("sqlite:///") :]
    elif normalized.startswith("sqlite://"):
        target = raw_value[len("sqlite://") :]
    elif "://" in raw_value:
        raise RuntimeError(
            "BUSINESS_DATABASE_URL supports PostgreSQL URLs, sqlite URLs, or sqlite file paths"
        )
    else:
        target = raw_value

    target = target.strip()
    if not target or target == ":memory:":
        return target or ":memory:"

    path = Path(target).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def get_business_conn():
    if is_postgres_business_db():
        pool = _get_business_pg_pool()
        return PostgresBusinessConnection(pool.getconn(), pool=pool)
    target = _resolve_business_sqlite_target()
    if target is None:
        if _runtime_requires_business_db():
            print(
                "BUSINESS_DB_FALLBACK_BLOCKED reason=missing_business_database_url",
                flush=True,
            )
            raise RuntimeError("BUSINESS_DATABASE_URL is required; local runtime sqlite fallback is blocked")
        return get_runtime_conn()
    return create_row_mapped_sqlite_conn(target)


def get_conn():
    # Temporary compatibility alias for existing runtime-side callers.
    return get_runtime_conn()


def generate_api_key_record_id(conn) -> str:
    for _ in range(32):
        candidate = f"key_{secrets.token_hex(8)}"
        row = conn.execute(
            "SELECT id FROM api_keys WHERE id = ? LIMIT 1",
            (candidate,),
        ).fetchone()
        if not row:
            return candidate
    raise RuntimeError("Could not generate a unique api_keys.id")


def ensure_user_record(user_id: str, email: str | None = None, status: str = "active") -> str:
    if not user_id:
        raise ValueError("user_id is required")

    conn = get_business_conn()
    existing = conn.execute(
        "SELECT id, email FROM users WHERE id = ?",
        (user_id,),
    ).fetchone()

    if existing:
        if email and not existing["email"]:
            conn.execute(
                "UPDATE users SET email = ? WHERE id = ?",
                (email, user_id),
            )
            conn.commit()
        conn.close()
        return user_id

    conn.execute(
        """
        INSERT INTO users (id, email, status, created_at)
        VALUES (?, ?, ?, ?)
        """,
        (user_id, email, status, datetime.utcnow().isoformat() + "Z"),
    )
    conn.commit()
    conn.close()
    return user_id


def column_exists(conn, table_name: str, column_name: str) -> bool:
    if getattr(conn, "db_kind", "") == "postgres_business":
        row = conn.execute(
            """
            SELECT 1 AS present
            FROM information_schema.columns
            WHERE table_schema = current_schema()
              AND table_name = ?
              AND column_name = ?
            LIMIT 1
            """,
            (table_name, column_name),
        ).fetchone()
        return row is not None
    rows = conn.execute(f"PRAGMA table_info({table_name})").fetchall()
    return any(row["name"] == column_name for row in rows)


def ensure_column(conn, table_name: str, column_name: str, column_type: str):
    if getattr(conn, "db_kind", "") == "postgres_business":
        conn.execute(f"ALTER TABLE {table_name} ADD COLUMN IF NOT EXISTS {column_name} {column_type}")
        return
    if not column_exists(conn, table_name, column_name):
        conn.execute(f"ALTER TABLE {table_name} ADD COLUMN {column_name} {column_type}")


def ensure_onboarding_tokens_table(conn):
    conn.execute("""
    CREATE TABLE IF NOT EXISTS onboarding_tokens (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        token_hash TEXT NOT NULL UNIQUE,
        purpose TEXT NOT NULL,
        expires_at TEXT NOT NULL,
        used_at TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id)
    )
    """)


def ensure_onboarding_sessions_table(conn):
    conn.execute("""
    CREATE TABLE IF NOT EXISTS onboarding_sessions (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        session_token_hash TEXT NOT NULL UNIQUE,
        provider TEXT NOT NULL,
        provider_subscription_id TEXT,
        provider_checkout_id TEXT,
        expires_at TEXT NOT NULL,
        used_at TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id)
    )
    """)
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_onboarding_sessions_checkout ON onboarding_sessions(provider, provider_checkout_id)"
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_onboarding_sessions_subscription ON onboarding_sessions(provider, provider_subscription_id)"
    )


def ensure_email_verifications_table(conn):
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS email_verifications (
            id TEXT PRIMARY KEY,
            email TEXT NOT NULL,
            code TEXT NOT NULL,
            purpose TEXT NOT NULL,
            created_at TEXT NOT NULL,
            expires_at TEXT,
            used_at TEXT,
            attempts INTEGER NOT NULL DEFAULT 0
        )
        """
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_email_verifications_email_purpose_created ON email_verifications(email, purpose, created_at DESC)"
    )


def ensure_free_claim_emails_table(conn):
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS free_claim_emails (
            email TEXT PRIMARY KEY,
            user_id TEXT NOT NULL UNIQUE,
            claimed_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
        """
    )


def ensure_app_state_table(conn):
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS app_state (
            key TEXT PRIMARY KEY,
            value TEXT,
            updated_at TEXT NOT NULL
        )
        """
    )


def ensure_workers_table(conn):
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS workers (
            id TEXT PRIMARY KEY,
            label TEXT NOT NULL,
            auth_token_hash TEXT UNIQUE,
            status TEXT NOT NULL,
            last_heartbeat_at TEXT,
            max_concurrency INTEGER NOT NULL DEFAULT 1,
            enabled INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL
        )
        """
    )


def ensure_operational_events_table(conn):
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS operational_events (
            id TEXT PRIMARY KEY,
            category TEXT NOT NULL,
            event TEXT NOT NULL,
            severity TEXT NOT NULL,
            provider TEXT,
            user_id TEXT,
            subscription_id TEXT,
            worker_id TEXT,
            execution_id TEXT,
            detail TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_operational_events_created_at ON operational_events(created_at DESC)"
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_operational_events_category_event ON operational_events(category, event)"
    )


def ensure_usage_events_table(conn):
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS usage_events (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            period_key TEXT,
            route_category TEXT NOT NULL,
            credit_amount REAL NOT NULL,
            input_mode TEXT NOT NULL,
            file_count INTEGER NOT NULL,
            total_content_bytes INTEGER NOT NULL,
            max_single_file_bytes INTEGER NOT NULL,
            entrypoint TEXT,
            key_id TEXT,
            execution_id TEXT,
            created_at TEXT NOT NULL
        )
        """
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_usage_events_user_period_created ON usage_events(user_id, period_key, created_at DESC)"
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_usage_events_route_created ON usage_events(route_category, created_at DESC)"
    )


def hash_onboarding_token(raw_token: str) -> str:
    return hashlib.sha256(raw_token.encode("utf-8")).hexdigest()


def create_onboarding_token(user_id: str, purpose: str = "claim_first_key", ttl_minutes: int = 30):
    raw_token = secrets.token_urlsafe(32)
    token_hash = hash_onboarding_token(raw_token)
    now = datetime.utcnow()
    expires_at = now + timedelta(minutes=ttl_minutes)
    token_id = f"obtok_{secrets.token_hex(8)}"

    conn = get_business_conn()
    ensure_onboarding_tokens_table(conn)
    conn.execute("""
    INSERT INTO onboarding_tokens (id, user_id, token_hash, purpose, expires_at, used_at, created_at)
    VALUES (?, ?, ?, ?, ?, NULL, ?)
    """, (
        token_id,
        user_id,
        token_hash,
        purpose,
        expires_at.isoformat(),
        now.isoformat() + "Z",
    ))
    conn.commit()
    conn.close()

    return {
        "id": token_id,
        "user_id": user_id,
        "purpose": purpose,
        "expires_at": expires_at.isoformat(),
        "raw_token": raw_token,
    }


def get_onboarding_token(raw_token: str, purpose: str = "claim_first_key"):
    token_hash = hash_onboarding_token(raw_token)

    conn = get_business_conn()
    ensure_onboarding_tokens_table(conn)
    row = conn.execute("""
    SELECT *
    FROM onboarding_tokens
    WHERE token_hash = ? AND purpose = ?
    LIMIT 1
    """, (token_hash, purpose)).fetchone()
    conn.close()
    return row


def mark_onboarding_token_used(token_id: str):
    conn = get_business_conn()
    ensure_onboarding_tokens_table(conn)
    conn.execute("""
    UPDATE onboarding_tokens
    SET used_at = ?
    WHERE id = ?
    """, (datetime.utcnow().isoformat() + "Z", token_id))
    conn.commit()
    conn.close()


def hash_onboarding_session_token(raw_token: str) -> str:
    return hashlib.sha256(raw_token.encode("utf-8")).hexdigest()


def create_onboarding_session(
    user_id: str,
    provider: str,
    provider_subscription_id: str | None = None,
    provider_checkout_id: str | None = None,
    ttl_minutes: int = 60,
):
    raw_token = "obsess_" + secrets.token_urlsafe(32)
    token_hash = hash_onboarding_session_token(raw_token)
    now = datetime.utcnow()
    expires_at = now + timedelta(minutes=ttl_minutes)
    session_id = f"obs_{secrets.token_hex(8)}"

    conn = get_business_conn()
    ensure_onboarding_sessions_table(conn)
    conn.execute(
        """
        INSERT INTO onboarding_sessions (
            id, user_id, session_token_hash, provider,
            provider_subscription_id, provider_checkout_id,
            expires_at, used_at, created_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, NULL, ?)
        """,
        (
            session_id,
            user_id,
            token_hash,
            provider,
            provider_subscription_id,
            provider_checkout_id,
            expires_at.isoformat(),
            now.isoformat() + "Z",
        ),
    )
    conn.commit()
    conn.close()

    return {
        "id": session_id,
        "user_id": user_id,
        "provider": provider,
        "provider_subscription_id": provider_subscription_id,
        "provider_checkout_id": provider_checkout_id,
        "expires_at": expires_at.isoformat(),
        "raw_token": raw_token,
    }


def get_onboarding_session_by_raw_token(raw_token: str):
    token_hash = hash_onboarding_session_token(raw_token)

    conn = get_business_conn()
    ensure_onboarding_sessions_table(conn)
    row = conn.execute(
        """
        SELECT *
        FROM onboarding_sessions
        WHERE session_token_hash = ?
        LIMIT 1
        """,
        (token_hash,),
    ).fetchone()
    conn.close()
    return row


def get_onboarding_session_by_checkout_id(provider: str, provider_checkout_id: str):
    conn = get_business_conn()
    ensure_onboarding_sessions_table(conn)
    rows = conn.execute(
        """
        SELECT *
        FROM onboarding_sessions
        WHERE provider = ? AND provider_checkout_id = ?
        ORDER BY created_at DESC
        """,
        (provider, provider_checkout_id),
    ).fetchall()
    conn.close()
    return rows


def get_onboarding_session_by_subscription_id(provider: str, provider_subscription_id: str):
    conn = get_business_conn()
    ensure_onboarding_sessions_table(conn)
    row = conn.execute(
        """
        SELECT *
        FROM onboarding_sessions
        WHERE provider = ? AND provider_subscription_id = ?
        ORDER BY created_at DESC
        LIMIT 1
        """,
        (provider, provider_subscription_id),
    ).fetchone()
    conn.close()
    return row


def mark_onboarding_session_used(session_id: str):
    conn = get_business_conn()
    ensure_onboarding_sessions_table(conn)
    conn.execute(
        """
        UPDATE onboarding_sessions
        SET used_at = ?
        WHERE id = ?
        """,
        (datetime.utcnow().isoformat() + "Z", session_id),
    )
    conn.commit()
    conn.close()


def normalize_email(email: str) -> str:
    return (email or "").strip().lower()


def create_email_verification(email: str, code: str, purpose: str, expires_at: str | None):
    now = datetime.utcnow().isoformat() + "Z"
    verification_id = f"emv_{secrets.token_hex(8)}"
    normalized_email = normalize_email(email)

    conn = get_business_conn()
    ensure_email_verifications_table(conn)
    conn.execute(
        """
        INSERT INTO email_verifications (
            id, email, code, purpose, created_at, expires_at, used_at, attempts
        )
        VALUES (?, ?, ?, ?, ?, ?, NULL, 0)
        """,
        (
            verification_id,
            normalized_email,
            code,
            purpose,
            now,
            expires_at,
        ),
    )
    conn.commit()
    conn.close()

    return {
        "id": verification_id,
        "email": normalized_email,
        "code": code,
        "purpose": purpose,
        "created_at": now,
        "expires_at": expires_at,
        "used_at": None,
        "attempts": 0,
    }


def get_latest_email_verification(email: str, purpose: str):
    normalized_email = normalize_email(email)

    conn = get_business_conn()
    ensure_email_verifications_table(conn)
    row = conn.execute(
        """
        SELECT *
        FROM email_verifications
        WHERE email = ? AND purpose = ?
        ORDER BY created_at DESC
        LIMIT 1
        """,
        (normalized_email, purpose),
    ).fetchone()
    conn.close()
    return row


def get_email_verification_by_email_and_code(email: str, code: str, purpose: str):
    normalized_email = normalize_email(email)

    conn = get_business_conn()
    ensure_email_verifications_table(conn)
    row = conn.execute(
        """
        SELECT *
        FROM email_verifications
        WHERE email = ? AND code = ? AND purpose = ?
        ORDER BY created_at DESC
        LIMIT 1
        """,
        (normalized_email, code, purpose),
    ).fetchone()
    conn.close()
    return row


def mark_email_verification_used(verification_id: str):
    conn = get_business_conn()
    ensure_email_verifications_table(conn)
    conn.execute(
        """
        UPDATE email_verifications
        SET used_at = ?
        WHERE id = ?
        """,
        (datetime.utcnow().isoformat() + "Z", verification_id),
    )
    conn.commit()
    conn.close()


def increment_email_verification_attempts(verification_id: str):
    conn = get_business_conn()
    ensure_email_verifications_table(conn)
    conn.execute(
        """
        UPDATE email_verifications
        SET attempts = attempts + 1
        WHERE id = ?
        """,
        (verification_id,),
    )
    conn.commit()
    conn.close()


def has_free_claim_for_email(email: str) -> bool:
    normalized_email = normalize_email(email)
    if not normalized_email:
        return False

    conn = get_business_conn()
    ensure_free_claim_emails_table(conn)
    row = conn.execute(
        """
        SELECT email
        FROM free_claim_emails
        WHERE email = ?
        LIMIT 1
        """,
        (normalized_email,),
    ).fetchone()
    conn.close()
    return row is not None


def store_free_claim_email_mapping(user_id: str, email: str):
    if not user_id:
        raise ValueError("user_id is required")

    normalized_email = normalize_email(email)
    if not normalized_email:
        raise ValueError("email is required")

    claimed_at = datetime.utcnow().isoformat() + "Z"

    conn = get_business_conn()
    ensure_free_claim_emails_table(conn)
    conn.execute(
        """
        INSERT INTO free_claim_emails (email, user_id, claimed_at)
        VALUES (?, ?, ?)
        ON CONFLICT(email) DO UPDATE SET
            user_id = excluded.user_id,
            claimed_at = excluded.claimed_at
        """,
        (normalized_email, user_id, claimed_at),
    )
    conn.commit()
    conn.close()


def set_app_state(key: str, value: str):
    now = datetime.utcnow().isoformat() + "Z"
    conn = get_conn()
    ensure_app_state_table(conn)
    conn.execute(
        """
        INSERT INTO app_state (key, value, updated_at)
        VALUES (?, ?, ?)
        ON CONFLICT(key) DO UPDATE SET
            value = excluded.value,
            updated_at = excluded.updated_at
        """,
        (key, value, now),
    )
    conn.commit()
    conn.close()


def get_app_state(key: str):
    conn = get_conn()
    ensure_app_state_table(conn)
    row = conn.execute(
        """
        SELECT key, value, updated_at
        FROM app_state
        WHERE key = ?
        LIMIT 1
        """,
        (key,),
    ).fetchone()
    conn.close()
    return dict(row) if row else None


def set_worker_heartbeat(worker_id: str | None = None, *, status: str = "active"):
    from .stores.workers import set_worker_heartbeat as store_set_worker_heartbeat

    store_set_worker_heartbeat(worker_id=worker_id, status=status)


def get_worker_heartbeat():
    from .stores.workers import get_worker_heartbeat as store_get_worker_heartbeat

    return store_get_worker_heartbeat()


def should_send_alert(alert_key: str, cooldown_seconds: int = 600) -> bool:
    row = get_app_state(f"alert:{alert_key}")
    now = datetime.utcnow()
    if row:
        try:
            last_sent = datetime.fromisoformat(row["value"].replace("Z", "+00:00")).replace(tzinfo=None)
            if (now - last_sent).total_seconds() < cooldown_seconds:
                return False
        except ValueError:
            pass
    set_app_state(f"alert:{alert_key}", now.isoformat() + "Z")
    return True


def hash_worker_token(raw_token: str) -> str:
    from .stores.workers import hash_worker_token as store_hash_worker_token

    return store_hash_worker_token(raw_token)


def ensure_worker_record(
    worker_id: str,
    *,
    label: str | None = None,
    max_concurrency: int = 1,
    enabled: bool = True,
    status: str = "active",
):
    from .stores.workers import ensure_worker_record as store_ensure_worker_record

    store_ensure_worker_record(
        worker_id,
        label=label,
        max_concurrency=max_concurrency,
        enabled=enabled,
        status=status,
    )


def register_worker_with_token(
    worker_id: str,
    *,
    label: str,
    auth_token: str,
    max_concurrency: int = 1,
    enabled: bool = True,
    status: str = "active",
):
    from .stores.workers import register_worker_with_token as store_register_worker_with_token

    return store_register_worker_with_token(
        worker_id,
        label=label,
        auth_token=auth_token,
        max_concurrency=max_concurrency,
        enabled=enabled,
        status=status,
    )


def register_worker(label: str, max_concurrency: int = 1, enabled: bool = True):
    from .stores.workers import register_worker as store_register_worker

    return store_register_worker(
        label,
        max_concurrency=max_concurrency,
        enabled=enabled,
    )


def authenticate_worker_token(raw_token: str):
    from .stores.workers import authenticate_worker_token as store_authenticate_worker_token

    return store_authenticate_worker_token(raw_token)


def authenticate_worker(worker_id: str, raw_token: str):
    from .stores.workers import authenticate_worker as store_authenticate_worker

    return store_authenticate_worker(worker_id, raw_token)


def update_worker_heartbeat(worker_id: str, *, status: str = "active"):
    from .stores.workers import update_worker_heartbeat as store_update_worker_heartbeat

    store_update_worker_heartbeat(worker_id, status=status)


def parse_worker_heartbeat(last_heartbeat_at: str | None):
    from .stores.workers import parse_worker_heartbeat as store_parse_worker_heartbeat

    return store_parse_worker_heartbeat(last_heartbeat_at)


def is_worker_heartbeat_fresh(last_heartbeat_at: str | None, max_age_seconds: int | None = None) -> bool:
    from .stores.workers import is_worker_heartbeat_fresh as store_is_worker_heartbeat_fresh

    return store_is_worker_heartbeat_fresh(last_heartbeat_at, max_age_seconds=max_age_seconds)


def get_worker_assignment_counts():
    from .stores.workers import get_worker_assignment_counts as store_get_worker_assignment_counts

    return store_get_worker_assignment_counts()


def list_enabled_workers():
    from .stores.workers import list_enabled_workers as store_list_enabled_workers

    return store_list_enabled_workers()


def list_workers():
    from .stores.workers import list_workers as store_list_workers

    return store_list_workers()


def get_worker(worker_id: str):
    from .stores.workers import get_worker as store_get_worker

    return store_get_worker(worker_id)


def get_worker_load_view(hours: int = 24):
    from .stores.workers import get_worker_load_view as store_get_worker_load_view

    return store_get_worker_load_view(hours=hours)


def update_worker_state(
    worker_id: str,
    *,
    enabled: bool | None = None,
    status: str | None = None,
):
    from .stores.workers import update_worker_state as store_update_worker_state

    return store_update_worker_state(
        worker_id,
        enabled=enabled,
        status=status,
    )


def select_dispatch_worker():
    from .stores.workers import select_dispatch_worker as store_select_dispatch_worker

    return store_select_dispatch_worker()


def record_operational_event(
    *,
    category: str,
    event: str,
    severity: str,
    detail: str,
    provider: str | None = None,
    user_id: str | None = None,
    subscription_id: str | None = None,
    worker_id: str | None = None,
    execution_id: str | None = None,
):
    conn = get_conn()
    ensure_operational_events_table(conn)
    conn.execute(
        """
        INSERT INTO operational_events (
            id, category, event, severity, provider, user_id, subscription_id, worker_id, execution_id, detail, created_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            f"evt_{secrets.token_hex(8)}",
            category,
            event,
            severity,
            provider,
            user_id,
            subscription_id,
            worker_id,
            execution_id,
            detail,
            datetime.utcnow().isoformat() + "Z",
        ),
    )
    conn.commit()
    conn.close()


def get_operational_event_counts_for_day(day_prefix: str | None = None):
    target_day = (day_prefix or datetime.utcnow().strftime("%Y-%m-%d")).strip()
    conn = get_conn()
    ensure_operational_events_table(conn)
    total_row = conn.execute(
        "SELECT COUNT(*) AS count FROM operational_events WHERE substr(created_at, 1, 10) = ?",
        (target_day,),
    ).fetchone()
    by_group = conn.execute(
        """
        SELECT category, event, severity, COUNT(*) AS count
        FROM operational_events
        WHERE substr(created_at, 1, 10) = ?
        GROUP BY category, event, severity
        ORDER BY count DESC, category ASC, event ASC
        """,
        (target_day,),
    ).fetchall()
    by_provider = conn.execute(
        """
        SELECT coalesce(provider, '') AS provider, COUNT(*) AS count
        FROM operational_events
        WHERE substr(created_at, 1, 10) = ?
        GROUP BY coalesce(provider, '')
        ORDER BY count DESC, provider ASC
        """,
        (target_day,),
    ).fetchall()
    by_worker = conn.execute(
        """
        SELECT coalesce(worker_id, '') AS worker_id, COUNT(*) AS count
        FROM operational_events
        WHERE substr(created_at, 1, 10) = ?
        GROUP BY coalesce(worker_id, '')
        ORDER BY count DESC, worker_id ASC
        """,
        (target_day,),
    ).fetchall()
    conn.close()
    return {
        "day": target_day,
        "total": int(total_row["count"]) if total_row else 0,
        "by_group": [dict(row) for row in by_group],
        "by_provider": [dict(row) for row in by_provider],
        "by_worker": [dict(row) for row in by_worker],
    }


def get_recent_event_count_for_worker(worker_id: str, hours: int = 24) -> int:
    from .stores.workers import get_recent_event_count_for_worker as store_get_recent_event_count_for_worker

    return store_get_recent_event_count_for_worker(worker_id, hours=hours)


def get_recent_failure_count_for_worker(worker_id: str, hours: int = 24) -> int:
    from .stores.workers import get_recent_failure_count_for_worker as store_get_recent_failure_count_for_worker

    return store_get_recent_failure_count_for_worker(worker_id, hours=hours)


def get_worker_summary(hours: int = 24):
    from .stores.workers import get_worker_summary as store_get_worker_summary

    return store_get_worker_summary(hours=hours)


def get_execution_summary(hours: int = 24, stuck_minutes: int = 15):
    conn = get_conn()
    recent_modifier = f"-{max(1, int(hours))} hours"
    stuck_modifier = f"-{max(1, int(stuck_minutes))} minutes"
    total_row = conn.execute(
        "SELECT COUNT(*) AS count FROM execution_status"
    ).fetchone()
    recent_row = conn.execute(
        """
        SELECT COUNT(*) AS count
        FROM execution_status
        WHERE created_at >= datetime('now', ?)
        """,
        (recent_modifier,),
    ).fetchone()
    by_status = conn.execute(
        """
        SELECT status, COUNT(*) AS count
        FROM execution_status
        GROUP BY status
        ORDER BY count DESC, status ASC
        """
    ).fetchall()
    running_row = conn.execute(
        """
        SELECT COUNT(*) AS count
        FROM execution_status
        WHERE status = 'running'
        """
    ).fetchone()
    stuck_row = conn.execute(
        """
        SELECT COUNT(*) AS count
        FROM execution_status
        WHERE status = 'running'
          AND updated_at < datetime('now', ?)
        """,
        (stuck_modifier,),
    ).fetchone()
    conn.close()
    return {
        "total": int(total_row["count"]) if total_row else 0,
        "recent_hours": max(1, int(hours)),
        "recent_total": int(recent_row["count"]) if recent_row else 0,
        "by_status": [dict(row) for row in by_status],
        "running": int(running_row["count"]) if running_row else 0,
        "stuck_running": int(stuck_row["count"]) if stuck_row else 0,
        "stuck_threshold_minutes": max(1, int(stuck_minutes)),
    }


def build_daily_operational_summary(day_prefix: str | None = None):
    summary = get_operational_event_counts_for_day(day_prefix)
    top_groups = summary["by_group"][:10]
    lines = [
        f"day={summary['day']}",
        f"total={summary['total']}",
    ]
    for group in top_groups:
        lines.append(
            f"{group['category']}/{group['event']}/{group['severity']}={group['count']}"
        )
    return "\n".join(lines)


def _init_business_tables(conn):
    cur = conn.cursor()

    cur.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        email TEXT UNIQUE,
        status TEXT,
        created_at TEXT
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS api_keys (
        id TEXT PRIMARY KEY,
        user_id TEXT,
        name TEXT,
        api_key_hash TEXT UNIQUE,
        plan TEXT,
        is_active INTEGER,
        created_at TEXT,
        FOREIGN KEY(user_id) REFERENCES users(id)
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS subscriptions (
        id TEXT PRIMARY KEY,
        user_id TEXT,
        provider TEXT,
        provider_subscription_id TEXT UNIQUE,
        provider_customer_id TEXT,
        plan TEXT,
        status TEXT,
        quota_monthly INTEGER,
        period_start TEXT,
        period_end TEXT,
        created_at TEXT,
        updated_at TEXT,
        FOREIGN KEY(user_id) REFERENCES users(id)
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS usage_counters (
        user_id TEXT,
        period_key TEXT,
        execution_count INTEGER,
        credit_used REAL NOT NULL DEFAULT 0,
        PRIMARY KEY (user_id, period_key)
    )
    """)

    ensure_usage_events_table(conn)
    ensure_onboarding_tokens_table(conn)
    ensure_onboarding_sessions_table(conn)
    ensure_email_verifications_table(conn)
    ensure_free_claim_emails_table(conn)
    ensure_column(conn, "subscriptions", "provider_customer_id", "TEXT")
    ensure_column(conn, "usage_counters", "credit_used", "REAL NOT NULL DEFAULT 0")
    conn.execute(
        """
        UPDATE usage_counters
        SET credit_used = CAST(execution_count AS REAL)
        WHERE execution_count > 0 AND coalesce(credit_used, 0) = 0
        """
    )


def _init_business_tables_safely(conn):
    if getattr(conn, "db_kind", "") != "postgres_business":
        _init_business_tables(conn)
        return

    # PostgreSQL catalog creation can still race across concurrent API/worker
    # imports, so serialize business schema bootstrap on the shared DB.
    conn.execute(
        "SELECT pg_advisory_lock(?, ?)",
        POSTGRES_BUSINESS_SCHEMA_LOCK_KEYS,
    )
    try:
        _init_business_tables(conn)
    finally:
        conn.execute(
            "SELECT pg_advisory_unlock(?, ?)",
            POSTGRES_BUSINESS_SCHEMA_LOCK_KEYS,
        )


def _init_runtime_tables(conn):
    cur = conn.cursor()

    cur.execute("""
    CREATE TABLE IF NOT EXISTS execution_status (
        execution_id TEXT PRIMARY KEY,
        key_id TEXT,
        user_id TEXT,
        assigned_worker_id TEXT,
        completed_by_worker_id TEXT,
        status TEXT,
        created_at TEXT,
        updated_at TEXT,
        claim_owner_worker_id TEXT,
        claim_token TEXT,
        claim_marked_at TEXT,
        lease_expires_at TEXT,
        last_lease_renewed_at TEXT,
        recovery_attempt_count INTEGER,
        orphaned_at TEXT,
        requeueable INTEGER
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS execution_results (
        execution_id TEXT PRIMARY KEY,
        key_id TEXT,
        user_id TEXT,
        completed_by_worker_id TEXT,
        stdout TEXT,
        stderr TEXT,
        exit_code INTEGER,
        duration REAL,
        created_at TEXT
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS execution_payloads (
        execution_id TEXT PRIMARY KEY,
        script TEXT NOT NULL,
        language TEXT NOT NULL,
        key_id TEXT,
        user_id TEXT,
        assigned_worker_id TEXT,
        created_at TEXT NOT NULL
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS rate_limits (
        key_id TEXT,
        route TEXT,
        window_key TEXT,
        request_count INTEGER,
        PRIMARY KEY (key_id, route, window_key)
    )
    """)

    ensure_app_state_table(conn)
    ensure_operational_events_table(conn)

    ensure_column(conn, "execution_status", "key_id", "TEXT")
    ensure_column(conn, "execution_status", "user_id", "TEXT")
    ensure_column(conn, "execution_status", "assigned_worker_id", "TEXT")
    ensure_column(conn, "execution_status", "completed_by_worker_id", "TEXT")
    ensure_column(conn, "execution_status", "created_at", "TEXT")
    ensure_column(conn, "execution_status", "updated_at", "TEXT")
    ensure_column(conn, "execution_status", "claim_owner_worker_id", "TEXT")
    ensure_column(conn, "execution_status", "claim_token", "TEXT")
    ensure_column(conn, "execution_status", "claim_marked_at", "TEXT")
    ensure_column(conn, "execution_status", "lease_expires_at", "TEXT")
    ensure_column(conn, "execution_status", "last_lease_renewed_at", "TEXT")
    ensure_column(conn, "execution_status", "recovery_attempt_count", "INTEGER")
    ensure_column(conn, "execution_status", "orphaned_at", "TEXT")
    ensure_column(conn, "execution_status", "requeueable", "INTEGER")
    ensure_column(conn, "subscriptions", "provider_customer_id", "TEXT")

    ensure_column(conn, "execution_results", "key_id", "TEXT")
    ensure_column(conn, "execution_results", "user_id", "TEXT")
    ensure_column(conn, "execution_results", "completed_by_worker_id", "TEXT")
    ensure_column(conn, "execution_results", "created_at", "TEXT")
    ensure_column(conn, "execution_payloads", "key_id", "TEXT")
    ensure_column(conn, "execution_payloads", "user_id", "TEXT")
    ensure_column(conn, "execution_payloads", "assigned_worker_id", "TEXT")
    ensure_column(conn, "execution_payloads", "created_at", "TEXT")
    ensure_column(conn, "execution_payloads", "payload_json", "TEXT")
    ensure_workers_table(conn)

def init_db():
    runtime_conn = get_runtime_conn()
    try:
        _init_runtime_tables(runtime_conn)
        runtime_conn.commit()
    finally:
        runtime_conn.close()

    business_conn = get_business_conn()
    try:
        _init_business_tables_safely(business_conn)
        business_conn.commit()
    finally:
        business_conn.close()


def rotate_api_keys_for_user(user_id: str, plan: str, name: str = "replacement-api-key"):
    if not user_id:
        raise ValueError("user_id is required")

    raw_key = get_api_key_prefix() + secrets.token_urlsafe(24)
    key_hash = hashlib.sha256(raw_key.encode()).hexdigest()

    conn = get_business_conn()
    try:
        active_rows = conn.execute(
            """
            SELECT id
            FROM api_keys
            WHERE user_id = ? AND is_active = 1
            ORDER BY created_at DESC
            """,
            (user_id,),
        ).fetchall()
        disabled_key_ids = [row["id"] for row in active_rows]

        conn.execute(
            "UPDATE api_keys SET is_active = 0 WHERE user_id = ? AND is_active = 1",
            (user_id,),
        )

        record = {
            "id": generate_api_key_record_id(conn),
            "user_id": user_id,
            "name": name,
            "api_key_hash": key_hash,
            "plan": plan,
            "is_active": 1,
            "created_at": datetime.utcnow().isoformat() + "Z",
        }

        conn.execute(
            """
            INSERT INTO api_keys (id, user_id, name, api_key_hash, plan, is_active, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                record["id"],
                record["user_id"],
                record["name"],
                record["api_key_hash"],
                record["plan"],
                record["is_active"],
                record["created_at"],
            ),
        )
        conn.commit()
        return raw_key, record, disabled_key_ids
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


init_db()
