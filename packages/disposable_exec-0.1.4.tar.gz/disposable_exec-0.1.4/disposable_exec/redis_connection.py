from __future__ import annotations

import os
import threading
from typing import Any

import redis


_REDIS_CLIENT_LOCK = threading.Lock()
_REDIS_CLIENT = None
_REDIS_CLIENT_CONFIG_KEY: tuple[Any, ...] | None = None


def get_redis_url() -> str:
    return (
        os.getenv("DISPOSABLE_EXEC_REDIS_URL", "").strip()
        or os.getenv("REDIS_URL", "").strip()
    )


def get_redis_connection_kwargs() -> dict[str, Any]:
    host = (
        os.getenv("DISPOSABLE_EXEC_REDIS_HOST", "").strip()
        or os.getenv("REDIS_HOST", "").strip()
    )
    port_value = (
        os.getenv("DISPOSABLE_EXEC_REDIS_PORT", "").strip()
        or os.getenv("REDIS_PORT", "").strip()
    )
    password = (
        os.getenv("DISPOSABLE_EXEC_REDIS_PASSWORD", "").strip()
        or os.getenv("REDIS_PASSWORD", "").strip()
    )
    db_value = (
        os.getenv("DISPOSABLE_EXEC_REDIS_DB", "").strip()
        or os.getenv("REDIS_DB", "").strip()
    )

    kwargs: dict[str, Any] = {}
    if host:
        kwargs["host"] = host
    if port_value:
        kwargs["port"] = int(port_value)
    if password:
        kwargs["password"] = password
    if db_value:
        kwargs["db"] = int(db_value)
    return kwargs


def create_redis_client():
    global _REDIS_CLIENT, _REDIS_CLIENT_CONFIG_KEY
    redis_url = get_redis_url()
    config_key: tuple[Any, ...]
    if redis_url:
        config_key = ("url", redis_url)
        with _REDIS_CLIENT_LOCK:
            if _REDIS_CLIENT is not None and _REDIS_CLIENT_CONFIG_KEY == config_key:
                return _REDIS_CLIENT
            _REDIS_CLIENT = redis.Redis.from_url(redis_url)
            _REDIS_CLIENT_CONFIG_KEY = config_key
            return _REDIS_CLIENT

    kwargs = get_redis_connection_kwargs()
    if kwargs:
        config_key = ("kwargs", tuple(sorted(kwargs.items())))
        with _REDIS_CLIENT_LOCK:
            if _REDIS_CLIENT is not None and _REDIS_CLIENT_CONFIG_KEY == config_key:
                return _REDIS_CLIENT
            _REDIS_CLIENT = redis.Redis(**kwargs)
            _REDIS_CLIENT_CONFIG_KEY = config_key
            return _REDIS_CLIENT

    config_key = ("default",)
    with _REDIS_CLIENT_LOCK:
        if _REDIS_CLIENT is not None and _REDIS_CLIENT_CONFIG_KEY == config_key:
            return _REDIS_CLIENT
        _REDIS_CLIENT = redis.Redis()
        _REDIS_CLIENT_CONFIG_KEY = config_key
        return _REDIS_CLIENT
