import os
from datetime import datetime
from time import perf_counter

from .status import normalize_execution_status_for_write
from .stores.execution_results import load_execution_result, save_execution_result


MAX_EXECUTION_OUTPUT_CHARS = max(1024, int(os.getenv("MAX_EXECUTION_OUTPUT_CHARS", "65536")))


def _log_result_timing(*, execution_id: str, result_step: str, started_at: float):
    elapsed_ms = round((perf_counter() - started_at) * 1000, 1)
    print(
        f"RESULT_TIMING execution_id={execution_id} result_step={result_step} elapsed_ms={elapsed_ms}",
        flush=True,
    )


def _truncate_output(value: str | None) -> str:
    text = value or ""
    if len(text) <= MAX_EXECUTION_OUTPUT_CHARS:
        return text
    removed = len(text) - MAX_EXECUTION_OUTPUT_CHARS
    suffix = f"\n...[truncated {removed} chars]"
    if len(suffix) >= MAX_EXECUTION_OUTPUT_CHARS:
        return suffix[:MAX_EXECUTION_OUTPUT_CHARS]
    keep = max(0, MAX_EXECUTION_OUTPUT_CHARS - len(suffix))
    return text[:keep] + suffix


def terminal_status_for_exit_code(exit_code: int | None) -> str:
    return "completed" if exit_code == 0 else "failed"


def save_result(
    execution_id: str,
    result: dict,
    key_id: str | None = None,
    user_id: str | None = None,
    completed_by_worker_id: str | None = None,
    terminal_status: str | None = None,
    assigned_worker_id: str | None = None,
    claim_owner_worker_id: str | None = None,
    claim_token: str | None = None,
    claim_marked_at: str | None = None,
):
    total_started_at = perf_counter()
    now = datetime.utcnow().isoformat() + "Z"
    truncate_started_at = perf_counter()
    stdout = _truncate_output(result.get("stdout", ""))
    stderr = _truncate_output(result.get("stderr", ""))
    exit_code = result.get("exit_code")
    duration = result.get("duration")
    normalized_terminal_status = (
        normalize_execution_status_for_write(terminal_status) if terminal_status is not None else None
    )
    _log_result_timing(
        execution_id=execution_id,
        result_step="prepare_result_payload",
        started_at=truncate_started_at,
    )

    persist_started_at = perf_counter()
    saved = save_execution_result(
        execution_id=execution_id,
        key_id=key_id,
        user_id=user_id,
        completed_by_worker_id=completed_by_worker_id,
        stdout=stdout,
        stderr=stderr,
        exit_code=exit_code,
        duration=duration,
        created_at=now,
        terminal_status=normalized_terminal_status,
        assigned_worker_id=assigned_worker_id,
        claim_owner_worker_id=claim_owner_worker_id,
        claim_token=claim_token,
        claim_marked_at=claim_marked_at,
    )
    _log_result_timing(
        execution_id=execution_id,
        result_step="save_execution_result",
        started_at=persist_started_at,
    )
    _log_result_timing(
        execution_id=execution_id,
        result_step="save_result_total",
        started_at=total_started_at,
    )
    return saved


def get_result(
    execution_id: str,
    key_id: str | None = None,
    user_id: str | None = None,
):
    row = load_execution_result(execution_id, key_id=key_id, user_id=user_id)
    if not row:
        return None

    exit_code = row["exit_code"]
    status = terminal_status_for_exit_code(exit_code)
    finished_at = row["created_at"]
    stdout = row["stdout"]
    stderr = row["stderr"]
    duration = row["duration"]

    return {
        "execution_id": row["execution_id"],
        "status": status,
        "stdout": stdout,
        "stderr": stderr,
        "exit_code": exit_code,
        "duration": duration,
        "completed_by_worker_id": row["completed_by_worker_id"],
        "finished_at": finished_at,
        "result": {
            "stdout": stdout,
            "stderr": stderr,
            "exit_code": exit_code,
            "duration": duration,
        },
    }
