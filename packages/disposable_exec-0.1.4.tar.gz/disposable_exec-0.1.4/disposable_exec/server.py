from contextlib import asynccontextmanager
import ast
import json
import re
import secrets
import sys
import threading
from datetime import datetime, timedelta, timezone
from os import getenv
from pathlib import PurePosixPath
from time import perf_counter

from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from polar_sdk.webhooks import WebhookVerificationError, validate_event

from .alerts import send_operational_event as emit_operational_event, send_telegram_alert_async
from .auth import (
    count_api_keys_for_user,
    create_api_key,
    disable_api_key,
    list_api_keys_for_user,
    verify_api_key,
)
from .billing import (
    admin_resync_subscription,
    fill_free_subscription_period_window,
    create_billing_portal_for_user,
    ensure_free_self_serve_subscription,
    find_subscription_for_recovery,
    find_or_create_free_self_serve_user,
    get_latest_subscription_for_user,
    get_subscription_for_onboarding_context,
    resolve_usage_period_for_user,
    handle_lemon_webhook,
    handle_paddle_webhook,
    handle_polar_webhook,
    handle_stripe_webhook,
    validate_webhook_secret,
)
from .billing_providers import BillingPortalError, get_polar_config, validate_polar_config
from .db import (
    create_onboarding_session,
    create_onboarding_token,
    create_email_verification,
    get_conn,
    get_email_verification_by_email_and_code,
    get_execution_summary,
    get_latest_email_verification,
    get_operational_event_counts_for_day,
    get_onboarding_session_by_checkout_id,
    get_onboarding_session_by_raw_token,
    get_onboarding_session_by_subscription_id,
    get_onboarding_token,
    has_free_claim_for_email,
    increment_email_verification_attempts,
    mark_email_verification_used,
    mark_onboarding_session_used,
    mark_onboarding_token_used,
    normalize_email,
    rotate_api_keys_for_user,
    should_send_alert,
    store_free_claim_email_mapping,
    build_daily_operational_summary,
)
from .db_adapter import ping_database
from .email_utils import get_free_email_mode, send_free_verification_code_email
from .metrics import build_admin_metrics_warning_summary, get_admin_metrics, get_host_pressure_snapshot
from .orphan_recovery import (
    SHARED_EXECUTION_SELF_HEAL_INTERVAL_SECONDS,
    reconcile_stale_shared_execution_states,
    recover_orphaned_executions,
)
from .plans import get_plan_concurrency_limit, get_plan_key_limit, get_plan_quota
from .queue import enqueue_existing_job, enqueue_job, get_queue_summary, warm_queue_depth_cache
from .rate_limit import (
    check_and_increment_ip_rate_limit as store_backed_check_and_increment_ip_rate_limit,
    check_and_increment_rate_limit as store_backed_check_and_increment_rate_limit,
)
from .results import get_result, save_result, terminal_status_for_exit_code
from .status import get_status, is_success_execution_status, is_terminal_execution_status, set_status
from .stores.execution_status import (
    get_active_execution_count_for_user,
    get_execution_status_row,
    warm_shared_execution_aggregates_cache,
)
from .stores.workers import (
    authenticate_worker,
    get_worker,
    get_worker_heartbeat,
    get_worker_load_view,
    get_worker_summary,
    list_workers,
    register_worker_with_token,
    set_worker_heartbeat,
    update_worker_state,
)
from .shared_worker_state import warm_shared_workers_cache
from .stores.subscriptions import list_subscriptions
from .stores.users import list_users
from .usage import (
    build_payload_usage_metadata,
    credit_request_allowed,
    compute_diagnostics_credits,
    compute_execution_credits,
    get_credit_used_for_period,
    get_remaining_credits,
    get_usage_count_for_period,
    increment_usage,
    record_usage_event,
)


def log_and_validate_polar_config():
    polar_config = validate_polar_config(require_access_token=True, require_webhook_secret=True)
    print(
        "POLAR_CONFIG "
        f"env={polar_config['env']} "
        f"api_base={polar_config['api_base']} "
        f"access_token_configured={bool(polar_config['access_token'])} "
        f"webhook_secret_configured={bool(polar_config['webhook_secret'])}",
        flush=True,
    )


def _log_run_timing(*, run_step: str, started_at: float, execution_id: str | None = None) -> None:
    elapsed_ms = round((perf_counter() - started_at) * 1000, 1)
    execution_part = f" execution_id={execution_id}" if execution_id else ""
    print(f"RUN_TIMING run_step={run_step}{execution_part} elapsed_ms={elapsed_ms}", flush=True)


def _shared_execution_state_self_heal_loop(stop_event: threading.Event) -> None:
    while not stop_event.is_set():
        try:
            summary = reconcile_stale_shared_execution_states()
            if summary.get("healed"):
                print(
                    "SHARED_EXECUTION_STATE_SELF_HEAL_SUMMARY "
                    f"scanned={summary.get('scanned', 0)} healed={summary.get('healed', 0)}",
                    flush=True,
                )
        except Exception as exc:
            print(f"SHARED_EXECUTION_STATE_SELF_HEAL_FAILED detail={exc}", flush=True)

        if stop_event.wait(SHARED_EXECUTION_SELF_HEAL_INTERVAL_SECONDS):
            break


def _shared_execution_aggregates_warm_loop(stop_event: threading.Event) -> None:
    while not stop_event.is_set():
        try:
            warm_shared_execution_aggregates_cache()
        except Exception as exc:
            print(f"SHARED_EXECUTION_AGGREGATES_WARM_FAILED detail={exc}", flush=True)

        if stop_event.wait(SHARED_EXECUTION_AGGREGATES_WARM_INTERVAL_SECONDS):
            break


def _queue_depth_warm_loop(stop_event: threading.Event) -> None:
    while not stop_event.is_set():
        try:
            warm_queue_depth_cache()
        except Exception as exc:
            print(f"QUEUE_DEPTH_WARM_FAILED detail={exc}", flush=True)

        if stop_event.wait(QUEUE_DEPTH_WARM_INTERVAL_SECONDS):
            break


def _shared_workers_warm_loop(stop_event: threading.Event) -> None:
    while not stop_event.is_set():
        try:
            warm_shared_workers_cache()
        except Exception as exc:
            print(f"SHARED_WORKERS_WARM_FAILED detail={exc}", flush=True)

        if stop_event.wait(SHARED_WORKERS_WARM_INTERVAL_SECONDS):
            break


@asynccontextmanager
async def lifespan(_app):
    # Preserve existing startup validation side effects while using FastAPI lifespan.
    log_and_validate_polar_config()
    stop_event = threading.Event()
    self_heal_thread = None
    shared_execution_aggregates_thread = None
    queue_depth_warm_thread = None
    shared_workers_warm_thread = None
    if QUEUE_DEPTH_WARM_ENABLED:
        try:
            warm_queue_depth_cache()
        except Exception as exc:
            print(f"QUEUE_DEPTH_WARM_STARTUP_FAILED detail={exc}", flush=True)
        queue_depth_warm_thread = threading.Thread(
            target=_queue_depth_warm_loop,
            args=(stop_event,),
            name="queue-depth-warm",
            daemon=True,
        )
        queue_depth_warm_thread.start()
    else:
        print("QUEUE_DEPTH_WARM_DISABLED", flush=True)
    if SHARED_WORKERS_WARM_ENABLED:
        try:
            warm_shared_workers_cache()
        except Exception as exc:
            print(f"SHARED_WORKERS_WARM_STARTUP_FAILED detail={exc}", flush=True)
        shared_workers_warm_thread = threading.Thread(
            target=_shared_workers_warm_loop,
            args=(stop_event,),
            name="shared-workers-warm",
            daemon=True,
        )
        shared_workers_warm_thread.start()
    else:
        print("SHARED_WORKERS_WARM_DISABLED", flush=True)
    if SHARED_EXECUTION_AGGREGATES_WARM_ENABLED:
        try:
            warm_shared_execution_aggregates_cache()
        except Exception as exc:
            print(f"SHARED_EXECUTION_AGGREGATES_WARM_STARTUP_FAILED detail={exc}", flush=True)
        shared_execution_aggregates_thread = threading.Thread(
            target=_shared_execution_aggregates_warm_loop,
            args=(stop_event,),
            name="shared-execution-aggregates-warm",
            daemon=True,
        )
        shared_execution_aggregates_thread.start()
    else:
        print("SHARED_EXECUTION_AGGREGATES_WARM_DISABLED", flush=True)
    if SHARED_EXECUTION_SELF_HEAL_ENABLED:
        self_heal_thread = threading.Thread(
            target=_shared_execution_state_self_heal_loop,
            args=(stop_event,),
            name="shared-execution-self-heal",
            daemon=True,
        )
        self_heal_thread.start()
    else:
        print("SHARED_EXECUTION_STATE_SELF_HEAL_DISABLED", flush=True)
    try:
        yield
    finally:
        stop_event.set()
        if queue_depth_warm_thread is not None:
            queue_depth_warm_thread.join(timeout=1.0)
        if shared_workers_warm_thread is not None:
            shared_workers_warm_thread.join(timeout=1.0)
        if shared_execution_aggregates_thread is not None:
            shared_execution_aggregates_thread.join(timeout=1.0)
        if self_heal_thread is not None:
            self_heal_thread.join(timeout=1.0)


app = FastAPI(title="Disposable Exec API", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://www.disposable-exec.com",
        "https://disposable-exec.com",
    ],
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
)


FREE_CLAIM_PURPOSE = "free_claim"
FREE_CODE_TTL_SECONDS = 600
FREE_REQUEST_CODE_LIMIT_PER_HOUR = 3
FREE_VERIFY_LIMIT_PER_HOUR = 10
PAID_RECOVERY_SESSION_TTL_MINUTES = 10
EMAIL_REGEX = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
WORKER_HEARTBEAT_MAX_AGE_SECONDS = max(30, int(getenv("WORKER_HEARTBEAT_MAX_AGE_SECONDS", "120")))
WORKER_STALLED_ALERT_COOLDOWN_SECONDS = max(60, int(getenv("WORKER_STALLED_ALERT_COOLDOWN_SECONDS", "600")))
QUEUE_DEPTH_WARM_INTERVAL_SECONDS = max(
    1,
    int(
        getenv("DISPOSABLE_EXEC_QUEUE_DEPTH_WARM_INTERVAL_SECONDS")
        or getenv("QUEUE_DEPTH_WARM_INTERVAL_SECONDS")
        or "5"
    ),
)
QUEUE_DEPTH_WARM_ENABLED = str(
    getenv("DISPOSABLE_EXEC_QUEUE_DEPTH_WARM_ENABLED")
    or getenv("QUEUE_DEPTH_WARM_ENABLED")
    or "1"
).strip().lower() in {"1", "true", "yes", "on"}
SHARED_WORKERS_WARM_INTERVAL_SECONDS = max(
    1,
    int(
        getenv("DISPOSABLE_EXEC_SHARED_WORKERS_WARM_INTERVAL_SECONDS")
        or getenv("SHARED_WORKERS_WARM_INTERVAL_SECONDS")
        or "10"
    ),
)
SHARED_WORKERS_WARM_ENABLED = str(
    getenv("DISPOSABLE_EXEC_SHARED_WORKERS_WARM_ENABLED")
    or getenv("SHARED_WORKERS_WARM_ENABLED")
    or "1"
).strip().lower() in {"1", "true", "yes", "on"}
SHARED_EXECUTION_AGGREGATES_WARM_INTERVAL_SECONDS = max(
    1,
    int(
        getenv("DISPOSABLE_EXEC_SHARED_EXECUTION_AGGREGATES_WARM_INTERVAL_SECONDS")
        or getenv("SHARED_EXECUTION_AGGREGATES_WARM_INTERVAL_SECONDS")
        or "10"
    ),
)
SHARED_EXECUTION_AGGREGATES_WARM_ENABLED = str(
    getenv("DISPOSABLE_EXEC_SHARED_EXECUTION_AGGREGATES_WARM_ENABLED")
    or getenv("SHARED_EXECUTION_AGGREGATES_WARM_ENABLED")
    or "1"
).strip().lower() in {"1", "true", "yes", "on"}
SHARED_EXECUTION_SELF_HEAL_ENABLED = str(
    getenv("DISPOSABLE_EXEC_SHARED_EXECUTION_SELF_HEAL_ENABLED")
    or getenv("SHARED_EXECUTION_SELF_HEAL_ENABLED")
    or "1"
).strip().lower() in {"1", "true", "yes", "on"}
# Keep diagnostics/files-mode limits explicit and small. This path is for
# short-lived Python execution, not project archives or dependency bundles.
RUN_FILES_MAX_COUNT = 10
RUN_FILES_MAX_FILE_CONTENT_BYTES = 256 * 1024
RUN_FILES_MAX_TOTAL_CONTENT_BYTES = 1024 * 1024
PYTHON_STDLIB_ROOTS = set(getattr(sys, "stdlib_module_names", set())) | {
    "__future__",
}


def _build_diagnostics_issue(
    *,
    code: str,
    message: str,
    path: str | None = None,
    line: int | None = None,
) -> dict:
    issue = {
        "code": code,
        "message": message,
    }
    if path:
        issue["path"] = path
    if line is not None:
        issue["line"] = line
    return issue


def _text_bytes(value: str) -> int:
    return len((value or "").encode("utf-8"))


def _normalize_run_file_path(path: str) -> str:
    normalized = PurePosixPath(str(path or "").strip())
    if not normalized.parts:
        raise HTTPException(status_code=400, detail="Invalid file path")
    if normalized.is_absolute():
        raise HTTPException(status_code=400, detail="Absolute file paths are not allowed")
    if any(part in {"", ".", ".."} for part in normalized.parts):
        raise HTTPException(status_code=400, detail="Path traversal is not allowed")
    return normalized.as_posix()


def _validate_run_payload(payload: dict) -> dict:
    script = payload.get("script")
    entrypoint = payload.get("entrypoint")
    files = payload.get("files")
    language = payload.get("language") or "python"

    has_script = bool(script)
    has_files_mode = entrypoint is not None or files is not None

    if has_script and has_files_mode:
        raise HTTPException(
            status_code=400,
            detail="Provide either script or entrypoint plus files, not both",
        )

    if has_script:
        if not isinstance(script, str):
            raise HTTPException(status_code=400, detail="Script content must be text")
        script_bytes = _text_bytes(script)
        if script_bytes > RUN_FILES_MAX_FILE_CONTENT_BYTES:
            raise HTTPException(status_code=400, detail="Script content is too large")
        return {
            "mode": "script",
            "script": script,
            "language": language,
            "entrypoint": None,
            "files": None,
            "file_count": 1,
            "total_content_bytes": script_bytes,
            "max_single_file_bytes": script_bytes,
        }

    if not has_files_mode:
        raise HTTPException(status_code=400, detail="Missing script")

    if language.strip().lower() != "python":
        raise HTTPException(status_code=400, detail="files mode supports python only")
    if not entrypoint:
        raise HTTPException(status_code=400, detail="Missing entrypoint")
    if not isinstance(files, list) or not files:
        raise HTTPException(status_code=400, detail="files must be a non-empty list")
    if len(files) > RUN_FILES_MAX_COUNT:
        raise HTTPException(status_code=400, detail="Too many files")

    normalized_files = []
    total_content_bytes = 0
    max_single_file_bytes = 0
    seen_paths = set()
    for item in files:
        if not isinstance(item, dict):
            raise HTTPException(status_code=400, detail="Each file must be an object")
        if "path" not in item or "content" not in item:
            raise HTTPException(status_code=400, detail="Each file must include path and content")
        normalized_path = _normalize_run_file_path(item.get("path"))
        if normalized_path in seen_paths:
            raise HTTPException(status_code=400, detail="Duplicate file paths are not allowed")
        seen_paths.add(normalized_path)

        content = item.get("content")
        if not isinstance(content, str):
            raise HTTPException(status_code=400, detail="File content must be text")
        content_bytes = _text_bytes(content)
        if content_bytes > RUN_FILES_MAX_FILE_CONTENT_BYTES:
            raise HTTPException(status_code=400, detail="File content is too large")
        total_content_bytes += content_bytes
        max_single_file_bytes = max(max_single_file_bytes, content_bytes)
        if total_content_bytes > RUN_FILES_MAX_TOTAL_CONTENT_BYTES:
            raise HTTPException(status_code=400, detail="Total file content is too large")

        normalized_files.append({"path": normalized_path, "content": content})

    normalized_entrypoint = _normalize_run_file_path(entrypoint)
    if normalized_entrypoint not in seen_paths:
        raise HTTPException(status_code=400, detail="entrypoint must match a provided file path")

    return {
        "mode": "files",
        "script": None,
        "language": "python",
        "entrypoint": normalized_entrypoint,
        "files": normalized_files,
        "file_count": len(normalized_files),
        "total_content_bytes": total_content_bytes,
        "max_single_file_bytes": max_single_file_bytes,
    }


def _log_payload_complexity(*, route: str, payload_metadata: dict) -> None:
    print(
        "PAYLOAD_COMPLEXITY "
        f"route={route} "
        f"input_mode={payload_metadata['input_mode']} "
        f"file_count={payload_metadata['file_count']} "
        f"total_content_bytes={payload_metadata['total_content_bytes']} "
        f"max_single_file_bytes={payload_metadata['max_single_file_bytes']} "
        f"entrypoint={payload_metadata.get('entrypoint') or ''}",
        flush=True,
    )


def _build_diagnostics_response(*, issues: list[dict], payload_metadata: dict) -> dict:
    return {
        "ok": not issues,
        "mode": "diagnostics",
        "language": "python",
        "input_mode": payload_metadata["input_mode"],
        "issues": issues,
        "file_count": payload_metadata["file_count"],
        "total_content_bytes": payload_metadata["total_content_bytes"],
        "max_single_file_bytes": payload_metadata["max_single_file_bytes"],
        "entrypoint": payload_metadata.get("entrypoint"),
        "metadata": payload_metadata,
    }


def _module_name_for_path(path: str) -> str | None:
    pure_path = PurePosixPath(path)
    if pure_path.suffix != ".py":
        return None
    parts = list(pure_path.parts)
    if not parts:
        return None
    if parts[-1] == "__init__.py":
        module_parts = parts[:-1]
    else:
        module_parts = parts[:-1] + [pure_path.stem]
    return ".".join(part for part in module_parts if part)


def _package_name_for_path(path: str) -> str:
    module_name = _module_name_for_path(path) or ""
    pure_path = PurePosixPath(path)
    if pure_path.name == "__init__.py":
        return module_name
    return module_name.rsplit(".", 1)[0] if "." in module_name else ""


def _module_exists(module_name: str, available_modules: set[str]) -> bool:
    return module_name in available_modules or any(
        candidate.startswith(f"{module_name}.") for candidate in available_modules
    )


def _should_flag_missing_local_module(module_name: str, available_modules: set[str], local_roots: set[str]) -> bool:
    if not module_name:
        return False
    if _module_exists(module_name, available_modules):
        return False

    root_name = module_name.split(".")[0]
    if root_name in local_roots:
        return True
    if root_name in PYTHON_STDLIB_ROOTS:
        return False
    return True


def _resolve_relative_import_base(current_package: str, level: int) -> str | None:
    package_parts = [part for part in current_package.split(".") if part]
    if level - 1 > len(package_parts):
        return None
    if level <= 1:
        return ".".join(package_parts)
    return ".".join(package_parts[: len(package_parts) - (level - 1)])


def _diagnose_python_syntax_and_imports(payload: dict) -> list[dict]:
    issues: list[dict] = []
    if (payload.get("language") or "python").strip().lower() != "python":
        issues.append(
            _build_diagnostics_issue(
                code="unsupported_language",
                message="Diagnostics currently supports python only",
            )
        )
        return issues

    if payload["mode"] == "script":
        try:
            ast.parse(payload["script"], filename="<script>")
        except SyntaxError as exc:
            issues.append(
                _build_diagnostics_issue(
                    code="python_syntax_error",
                    message=exc.msg or "Python syntax error",
                    path="<script>",
                    line=exc.lineno,
                )
            )
        return issues

    parsed_trees: list[tuple[str, ast.AST]] = []
    available_modules = {
        module_name
        for module_name in (_module_name_for_path(item["path"]) for item in payload["files"])
        if module_name
    }
    local_roots = {module_name.split(".")[0] for module_name in available_modules if module_name}

    for item in payload["files"]:
        if not item["path"].endswith(".py"):
            continue
        try:
            tree = ast.parse(item["content"], filename=item["path"])
            parsed_trees.append((item["path"], tree))
        except SyntaxError as exc:
            issues.append(
                _build_diagnostics_issue(
                    code="python_syntax_error",
                    message=exc.msg or "Python syntax error",
                    path=item["path"],
                    line=exc.lineno,
                )
            )

    if any(issue["code"] == "python_syntax_error" for issue in issues):
        return issues

    for path, tree in parsed_trees:
        current_package = _package_name_for_path(path)
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    module_name = alias.name
                    if _should_flag_missing_local_module(module_name, available_modules, local_roots):
                        issues.append(
                            _build_diagnostics_issue(
                                code="missing_local_module",
                                message=f"Local module '{module_name}' was not provided",
                                path=path,
                                line=getattr(node, "lineno", None),
                            )
                        )
            elif isinstance(node, ast.ImportFrom):
                if node.level > 0:
                    base_module = _resolve_relative_import_base(current_package, node.level)
                    if base_module is None:
                        issues.append(
                            _build_diagnostics_issue(
                                code="invalid_relative_import",
                                message="Relative import goes beyond the provided file structure",
                                path=path,
                                line=getattr(node, "lineno", None),
                            )
                        )
                        continue
                    module_name = (
                        f"{base_module}.{node.module}" if base_module and node.module else base_module or (node.module or "")
                    )
                else:
                    module_name = node.module or ""

                if not module_name:
                    continue
                if _should_flag_missing_local_module(module_name, available_modules, local_roots):
                    issues.append(
                        _build_diagnostics_issue(
                            code="missing_local_module",
                            message=f"Local module '{module_name}' was not provided",
                            path=path,
                            line=getattr(node, "lineno", None),
                        )
                    )

    return issues


def send_operational_alert(alert_key: str, message: str, cooldown_seconds: int = 600):
    # Best-effort operational alerts should never block request handling.
    if not message:
        return
    if should_send_alert(alert_key, cooldown_seconds=cooldown_seconds):
        send_telegram_alert_async(message)


def send_operational_event(
    *,
    category: str,
    event: str,
    severity: str,
    detail: str,
    message_override: str | None = None,
    provider: str | None = None,
    user_id: str | None = None,
    subscription_id: str | None = None,
    worker_id: str | None = None,
    execution_id: str | None = None,
    cooldown_seconds: int = 600,
):
    # Unified operational alert model for production. Delegate to alerts.py so
    # server and worker paths share the same event format and cooldown behavior.
    emit_operational_event(
        category=category,
        event=event,
        severity=severity,
        detail=detail,
        message_override=message_override,
        provider=provider,
        user_id=user_id,
        subscription_id=subscription_id,
        worker_id=worker_id,
        execution_id=execution_id,
        cooldown_seconds=cooldown_seconds,
    )


def get_effective_plan_for_api_key(api_key: dict) -> str:
    key_plan = api_key.get("plan", "Free")
    user_id = api_key.get("user_id")
    subscription = get_latest_subscription_for_user(user_id) if user_id else None

    if subscription and subscription.get("status") == "active":
        print(
            "RUNTIME_SUBSCRIPTION_SELECTION "
            f"route=effective_plan user_id={user_id} selected_subscription_id={subscription.get('id', '')} "
            f"plan={subscription.get('plan', '')} status={subscription.get('status', '')} "
            f"provider_subscription_id={subscription.get('provider_subscription_id', '')}",
            flush=True,
        )
        return subscription.get("plan", key_plan)

    return key_plan


def get_runtime_subscription_for_user(user_id: str | None, route_name: str):
    subscription = get_latest_subscription_for_user(user_id) if user_id else None
    if subscription:
        print(
            "RUNTIME_SUBSCRIPTION_SELECTION "
            f"route={route_name} user_id={user_id} selected_subscription_id={subscription.get('id', '')} "
            f"plan={subscription.get('plan', '')} status={subscription.get('status', '')} "
            f"provider_subscription_id={subscription.get('provider_subscription_id', '')}",
            flush=True,
        )
    return subscription


def evaluate_run_capacity(used_credits: float, quota: int, required_credits: float, pressure: dict) -> dict | None:
    if not credit_request_allowed(used_credits=used_credits, quota=quota, required_credits=required_credits):
        return {
            "status_code": 403,
            "detail": "Monthly credit quota exceeded",
            "event": {
                "name": "quota_rejected",
                "severity": "warning",
                "detail": f"used_credits={used_credits} required_credits={required_credits} quota={quota}",
                "log_name": "RUN_QUOTA_REJECT",
            },
        }

    queue_max_depth = int(pressure["thresholds"]["queue_max_depth"])
    if pressure["queue_depth"] >= queue_max_depth:
        return {
            "status_code": 503,
            "detail": "Execution queue is temporarily full. Please retry shortly.",
            "event": {
                "name": "queue_backpressure_reject",
                "severity": "critical",
                "detail": f"queue_depth={pressure['queue_depth']} threshold={queue_max_depth}",
                "log_name": "RUN_QUEUE_BACKPRESSURE_REJECT",
            },
        }

    active_execution_max = int(pressure["thresholds"]["active_execution_max"])
    if pressure["active_execution_count"] >= active_execution_max:
        return {
            "status_code": 503,
            "detail": "Execution capacity is temporarily full. Please retry shortly.",
            "event": {
                "name": "active_execution_backpressure_reject",
                "severity": "critical",
                "detail": f"active_execution_count={pressure['active_execution_count']} threshold={active_execution_max}",
                "log_name": "RUN_ACTIVE_EXECUTION_BACKPRESSURE_REJECT",
            },
        }

    return None


def count_occupied_execution_slots_for_user(user_id: str) -> int:
    if not user_id:
        return 0
    return int(get_active_execution_count_for_user(user_id)["count"])


def evaluate_user_concurrency_capacity(user_id: str, effective_plan: str) -> dict | None:
    occupied_slots = count_occupied_execution_slots_for_user(user_id)
    concurrency_limit = get_plan_concurrency_limit(effective_plan)

    if occupied_slots >= concurrency_limit:
        return {
            "status_code": 429,
            "detail": f"Concurrent execution slot limit reached for plan {effective_plan}. Please wait for a queued or running execution to finish.",
            "event": {
                "name": "user_concurrency_limit_reject",
                "severity": "warning",
                "detail": f"plan={effective_plan} occupied_slots={occupied_slots} limit={concurrency_limit}",
                "log_name": "RUN_USER_CONCURRENCY_LIMIT_REJECT",
            },
        }

    return None


def build_status_response(execution_id: str, api_key: dict) -> dict:
    status_row = get_status(
        execution_id,
        key_id=api_key.get("id"),
        user_id=api_key.get("user_id"),
    )
    if status_row is None:
        return {
            "execution_id": execution_id,
            "status": "not_found",
            "plan": get_effective_plan_for_api_key(api_key),
            "created_at": None,
            "finished_at": None,
            "has_result": False,
        }

    result_row = get_result(
        execution_id,
        key_id=api_key.get("id"),
        user_id=api_key.get("user_id"),
    )
    response_status = status_row["status"]

    # Defensive response-level consistency guard: if the API node sees a stale
    # in-progress status but already has terminal result data, prefer the
    # terminal result for the /status response.
    if result_row is not None and not is_terminal_execution_status(status_row.get("raw_status")):
        response_status = "completed" if is_success_execution_status(result_row.get("status")) else "failed"

    return {
        "execution_id": execution_id,
        "status": response_status,
        "plan": get_effective_plan_for_api_key(api_key),
        "created_at": status_row.get("created_at"),
        "finished_at": result_row.get("finished_at") if result_row else None,
        "has_result": result_row is not None,
    }


def count_active_keys_for_user(user_id: str) -> int:
    if not user_id:
        return 0

    rows = list_api_keys_for_user(user_id)
    return sum(1 for row in rows if bool(row["is_active"]))


def enforce_api_key_limit_for_plan(user_id: str, plan: str):
    active_key_count = count_active_keys_for_user(user_id)
    key_limit = get_plan_key_limit(plan)

    if active_key_count >= key_limit:
        raise HTTPException(
            status_code=409,
            detail={
                "code": "api_key_limit_reached",
                "message": f"API key limit reached for plan {plan}.",
                "plan": plan,
                "active_key_count": active_key_count,
                "key_limit": key_limit,
            },
        )


RUN_RATE_LIMIT_PER_MIN = 20
READ_RATE_LIMIT_PER_MIN = 60


def get_admin_token() -> str:
    return (getenv("ADMIN_API_TOKEN", "") or getenv("DISPOSABLE_EXEC_ADMIN_TOKEN", "")).strip()


def get_internal_token() -> str:
    return (
        getenv("INTERNAL_API_TOKEN", "")
        or getenv("DISPOSABLE_EXEC_INTERNAL_API_TOKEN", "")
        or getenv("ADMIN_API_TOKEN", "")
        or getenv("DISPOSABLE_EXEC_ADMIN_TOKEN", "")
    ).strip()


def enforce_rate_limit(api_key: dict, route: str, limit: int):
    key_id = api_key.get("id")
    if not key_id:
        raise HTTPException(status_code=500, detail="API key record missing id")

    info = store_backed_check_and_increment_rate_limit(key_id, route, limit)

    if not info["allowed"]:
        raise HTTPException(
            status_code=429,
            detail=f"Rate limit exceeded for {route}: {info['count']}/{info['limit']} in current minute",
        )


def get_request_ip(request: Request) -> str:
    forwarded_for = (request.headers.get("x-forwarded-for") or "").strip()
    if forwarded_for:
        return forwarded_for.split(",")[0].strip()

    if request.client and request.client.host:
        return request.client.host

    return "unknown"


def enforce_ip_rate_limit(request: Request, route: str, limit: int):
    info = store_backed_check_and_increment_ip_rate_limit(get_request_ip(request), route, limit)
    if not info["allowed"]:
        raise HTTPException(
            status_code=429,
            detail=f"Rate limit exceeded for {route}: {info['count']}/{info['limit']} in current hour",
        )


def verify_admin_token(
    request: Request,
    x_admin_token: str | None = Header(default=None),
):
    admin_token = get_admin_token()

    if not admin_token:
        raise HTTPException(status_code=500, detail="Admin token is not configured")

    if x_admin_token != admin_token:
        print(
            f"PRIVILEGED_ACCESS_DENIED scope=admin route={request.url.path} ip={get_request_ip(request)} detail=invalid_token",
            flush=True,
        )
        raise HTTPException(status_code=403, detail="Invalid admin token")

    return True


def verify_internal_token(
    request: Request,
    x_internal_token: str | None = Header(default=None),
):
    internal_token = get_internal_token()

    if not internal_token:
        raise HTTPException(status_code=500, detail="Internal token is not configured")

    if x_internal_token != internal_token:
        print(
            f"PRIVILEGED_ACCESS_DENIED scope=internal route={request.url.path} ip={get_request_ip(request)} detail=invalid_token",
            flush=True,
        )
        raise HTTPException(status_code=403, detail="Invalid internal API token")

    return True


def authenticate_worker_request(payload: dict):
    # Remote worker preparation: internal worker routes use token auth backed by workers.auth_token_hash.
    worker_id = (payload.get("worker_id") or "").strip()
    auth_token = (payload.get("auth_token") or "").strip()
    if not worker_id or not auth_token:
        raise HTTPException(status_code=400, detail="Missing worker credentials")

    worker = authenticate_worker(worker_id, auth_token)
    if not worker:
        raise HTTPException(status_code=403, detail="Invalid worker credentials")
    return worker


def get_worker_context(worker_id: str | None):
    return get_worker(worker_id)


def get_execution_row(execution_id: str):
    return get_execution_status_row(execution_id)


def parse_optional_bool(value):
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    normalized = str(value).strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False
    raise HTTPException(status_code=400, detail="Invalid boolean value")


def verify_webhook_secret(provider: str, secret_value: str | None):
    ok, error = validate_webhook_secret(provider, secret_value)
    if not ok:
        raise HTTPException(status_code=403, detail=error)


def verify_polar_webhook_or_raise(raw_body: bytes, headers):
    try:
        polar_config = validate_polar_config(require_webhook_secret=True)
    except RuntimeError as exc:
        raise HTTPException(
            status_code=500,
            detail=str(exc),
        ) from exc

    try:
        validate_event(
            body=raw_body,
            headers=headers,
            secret=polar_config["webhook_secret"],
        )
        print("POLAR_VERIFY_OK = true", flush=True)
    except WebhookVerificationError:
        raise HTTPException(
            status_code=403,
            detail="Invalid Polar webhook signature",
        )

def parse_iso_datetime(value: str | None) -> datetime | None:
    if not value:
        return None

    try:
        normalized = value[:-1] + "+00:00" if value.endswith("Z") else value
        parsed = datetime.fromisoformat(normalized)
    except (TypeError, ValueError):
        return None

    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)

    return parsed.astimezone(timezone.utc)


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def utcnow_iso() -> str:
    return utcnow().isoformat()


def is_worker_heartbeat_recent() -> bool:
    worker_items = get_worker_summary(hours=24)
    if worker_items:
        return any(
            bool(item.get("enabled", True))
            and item.get("heartbeat_fresh") is True
            and item.get("effective_status") in {"active", "draining"}
            for item in worker_items
        )
    heartbeat = parse_iso_datetime(get_worker_heartbeat())
    if not heartbeat:
        return False
    return (utcnow() - heartbeat).total_seconds() <= WORKER_HEARTBEAT_MAX_AGE_SECONDS


def validate_email_input(email: str) -> str:
    normalized = normalize_email(email)
    if not normalized:
        raise HTTPException(status_code=400, detail="Missing email")
    if not EMAIL_REGEX.match(normalized):
        raise HTTPException(status_code=400, detail="Invalid email")
    return normalized


def validate_verification_code_input(code: str) -> str:
    normalized = (code or "").strip()
    if not normalized:
        raise HTTPException(status_code=400, detail="Missing code")
    if not re.fullmatch(r"\d{6}", normalized):
        raise HTTPException(status_code=400, detail="Invalid verification code")
    return normalized


def build_already_claimed_response():
    return JSONResponse(
        status_code=409,
        content={
            "ok": False,
            "already_claimed": True,
            "message": "A Free key has already been claimed for this email.",
        },
    )


def get_active_paid_subscription_or_raise(user_id: str):
    if not user_id:
        raise HTTPException(
            status_code=400,
            detail={
                "code": "api_key_reissue_unavailable",
                "message": "API key reissue is not available for this account.",
            },
        )

    subscription = get_runtime_subscription_for_user(user_id, "/run")
    if not subscription:
        print(f"PAID_SUBSCRIPTION_REJECT_403 reason=not_found user_id={user_id}", flush=True)
        raise HTTPException(
            status_code=403,
            detail={
                "code": "api_key_reissue_unavailable",
                "message": "API key reissue is only available for active paid subscriptions.",
            },
        )

    if subscription.get("status") != "active":
        print(
            "PAID_SUBSCRIPTION_REJECT_403 "
            f"reason=status_not_active user_id={user_id} subscription_id={subscription.get('id', '')} "
            f"plan={subscription.get('plan', '')} status={subscription.get('status', '')}",
            flush=True,
        )
        raise HTTPException(
            status_code=403,
            detail={
                "code": "api_key_reissue_unavailable",
                "message": "API key reissue is only available for active paid subscriptions.",
            },
        )

    plan = subscription.get("plan", "Free")
    if plan == "Free":
        print(
            "PAID_SUBSCRIPTION_REJECT_403 "
            f"reason=free_plan_selected user_id={user_id} subscription_id={subscription.get('id', '')} "
            f"plan={subscription.get('plan', '')} status={subscription.get('status', '')} "
            f"provider_subscription_id={subscription.get('provider_subscription_id', '')}",
            flush=True,
        )
        raise HTTPException(
            status_code=403,
            detail={
                "code": "api_key_reissue_unavailable",
                "message": "API key reissue is only available for active paid subscriptions.",
            },
        )

    return subscription


def reissue_paid_api_key_for_user(user_id: str):
    subscription = get_active_paid_subscription_or_raise(user_id)
    plan = subscription.get("plan", "Free")
    quota_monthly = subscription.get("quota_monthly", get_plan_quota(plan))

    try:
        raw_key, record, disabled_key_ids = rotate_api_keys_for_user(
            user_id=user_id,
            plan=plan,
            name="replacement-api-key",
        )
    except Exception as exc:
        print(f"API_KEY_REISSUE_FAILED user_id={user_id} detail={exc}", flush=True)
        send_operational_event(
            category="onboarding",
            event="api_key_reissue_failed",
            severity="warning",
            user_id=user_id,
            detail=str(exc),
        )
        raise
    record["is_active"] = bool(record["is_active"])

    return {
        "ok": True,
        "reissued": True,
        "api_key": raw_key,
        "record": record,
        "disabled_key_ids": disabled_key_ids,
        "plan": plan,
        "quota_monthly": quota_monthly,
        "subscription_status": subscription.get("status"),
        "message": "Existing active API key(s) were disabled and a replacement key was issued.",
    }


def issue_paid_recovery_session(session_row, subscription: dict | None = None):
    if not session_row:
        raise HTTPException(
            status_code=404,
            detail=build_reissue_error("Paid key recovery is not available from this page."),
        )

    subscription = subscription or get_active_paid_subscription_or_raise(session_row["user_id"])

    recovery_session = create_onboarding_session(
        user_id=session_row["user_id"],
        provider=session_row["provider"],
        provider_subscription_id=session_row["provider_subscription_id"] or subscription.get("provider_subscription_id"),
        provider_checkout_id=session_row["provider_checkout_id"],
        ttl_minutes=PAID_RECOVERY_SESSION_TTL_MINUTES,
    )
    return {
        "recovery_session_token": recovery_session["raw_token"],
        "recovery_expires_at": recovery_session["expires_at"],
    }


def build_existing_active_key_recovery_response(session_row, lookup_mode: str, provider: str):
    subscription = get_active_paid_subscription_or_raise(session_row["user_id"])
    rows = list_api_keys_for_user(session_row["user_id"])
    active_keys = [row for row in rows if bool(row["is_active"])]
    if not active_keys:
        return None

    recovery = issue_paid_recovery_session(session_row, subscription=subscription)
    return {
        "ok": True,
        "resolved": "existing_active_key",
        "existing_active_key": True,
        "api_key": None,
        "key_id": active_keys[0]["id"],
        "key_name": active_keys[0]["name"],
        "plan": subscription.get("plan", "Free"),
        "quota_monthly": subscription.get("quota_monthly", 50),
        "subscription_status": subscription.get("status"),
        "message": "An active API key is already available for this paid account. Use Reissue Key to rotate it and receive a new one.",
        "lookup_mode": lookup_mode,
        "provider": provider,
        **recovery,
    }


def build_reissue_error(message: str) -> dict:
    return {
        "code": "api_key_reissue_unavailable",
        "message": message,
    }


def find_onboarding_session_from_payload(payload: dict):
    provider = (payload.get("provider") or "polar").strip().lower()
    raw_session_token = (payload.get("session_token") or payload.get("token") or "").strip()
    checkout_id = (payload.get("checkout_id") or "").strip()
    provider_subscription_id = (payload.get("provider_subscription_id") or payload.get("subscription_id") or "").strip()

    session_row = None
    lookup_mode = None
    checkout_rows = None

    if raw_session_token:
        session_row = get_onboarding_session_by_raw_token(raw_session_token)
        lookup_mode = "session_token"
    elif checkout_id:
        checkout_rows = list(get_onboarding_session_by_checkout_id(provider, checkout_id) or [])
        for row in checkout_rows:
            if row["used_at"]:
                continue
            if is_onboarding_session_expired(row):
                continue
            session_row = row
            break
        if session_row is None and checkout_rows:
            session_row = checkout_rows[0]
        lookup_mode = "checkout_id"
    elif provider_subscription_id:
        session_row = get_onboarding_session_by_subscription_id(provider, provider_subscription_id)
        lookup_mode = "provider_subscription_id"
    else:
        raise HTTPException(status_code=400, detail="Missing onboarding lookup value")

    if not session_row:
        raise HTTPException(status_code=404, detail=f"Auto-claim session not found for {lookup_mode or 'request'}")

    return provider, lookup_mode, session_row, checkout_rows


def is_onboarding_session_expired(session_row) -> bool:
    if not session_row:
        return True

    expires_at = session_row["expires_at"]
    return bool(expires_at and utcnow() > parse_iso_datetime(expires_at))


def get_onboarding_session_from_payload(payload: dict):
    provider, lookup_mode, session_row, _checkout_rows = find_onboarding_session_from_payload(payload)
    if is_onboarding_session_expired(session_row):
        raise HTTPException(status_code=410, detail="Auto-claim session expired")

    return provider, lookup_mode, session_row


def log_auto_claim_context(
    payload: dict,
    provider: str,
    lookup_mode: str | None,
    session_row,
    checkout_rows,
    subscription: dict | None = None,
    reason: str = "context",
):
    payload_keys = sorted((payload or {}).keys())
    session_id = session_row["id"] if session_row else ""
    session_subscription_id = session_row["provider_subscription_id"] if session_row else ""
    checkout_count = len(checkout_rows or [])
    selected_subscription_id = ""
    selected_plan = ""
    selected_status = ""
    selected_provider_subscription_id = ""
    if subscription:
        selected_subscription_id = subscription.get("id", "")
        selected_plan = subscription.get("plan", "")
        selected_status = subscription.get("status", "")
        selected_provider_subscription_id = subscription.get("provider_subscription_id", "")
    print(
        "AUTO_CLAIM_CONTEXT "
        f"reason={reason} payload_keys={payload_keys} provider={provider or ''} lookup_mode={lookup_mode or ''} "
        f"session_row_id={session_id} session_provider_subscription_id={session_subscription_id or ''} "
        f"checkout_rows_count={checkout_count} selected_subscription_id={selected_subscription_id} "
        f"selected_plan={selected_plan} selected_status={selected_status} "
        f"selected_provider_subscription_id={selected_provider_subscription_id}",
        flush=True,
    )


def alert_auto_claim_failure(reason: str, provider: str, lookup_mode: str | None, session_row, detail: str):
    # Keep auto-claim alerts concise and keyed for cooldown-based deduplication.
    session_id = session_row["id"] if session_row else ""
    subscription_id = session_row["provider_subscription_id"] if session_row else ""
    send_operational_event(
        category="onboarding",
        event=f"auto_claim_{reason}",
        severity="warning",
        provider=provider or None,
        subscription_id=subscription_id or None,
        detail=f"lookup_mode={lookup_mode or ''} session_id={session_id} detail={detail}",
        cooldown_seconds=300,
    )


def issue_first_key_for_user(user_id: str, *, session_row=None, allow_existing_active_key: bool = False):
    if not user_id:
        raise HTTPException(status_code=400, detail="Invalid onboarding user")

    subscription = get_subscription_for_onboarding_context(
        user_id,
        provider=session_row["provider"] if session_row else None,
        provider_subscription_id=session_row["provider_subscription_id"] if session_row else None,
    )
    print(
        "AUTO_CLAIM_SUBSCRIPTION_SELECTED "
        f"user_id={user_id} session_row_id={session_row['id'] if session_row else ''} "
        f"provider={session_row['provider'] if session_row else ''} "
        f"session_provider_subscription_id={session_row['provider_subscription_id'] if session_row else ''} "
        f"selected_subscription_id={subscription.get('id', '') if subscription else ''} "
        f"selected_plan={subscription.get('plan', '') if subscription else ''} "
        f"selected_status={subscription.get('status', '') if subscription else ''} "
        f"selected_provider_subscription_id={subscription.get('provider_subscription_id', '') if subscription else ''}",
        flush=True,
    )
    if not subscription:
        print(
            f"AUTO_CLAIM_REJECT_403 reason=no_active_subscription user_id={user_id} session_row_id={session_row['id'] if session_row else ''}",
            flush=True,
        )
        raise HTTPException(status_code=403, detail="No active subscription found")

    if subscription.get("status") != "active":
        print(
            "AUTO_CLAIM_REJECT_403 "
            f"reason=subscription_not_active user_id={user_id} session_row_id={session_row['id'] if session_row else ''} "
            f"selected_subscription_id={subscription.get('id', '')} selected_status={subscription.get('status', '')}",
            flush=True,
        )
        raise HTTPException(status_code=403, detail="Subscription is not active")

    plan = subscription.get("plan", "Free")
    quota_monthly = subscription.get("quota_monthly", 50)

    if allow_existing_active_key:
        rows = list_api_keys_for_user(user_id)
        active_keys = [row for row in rows if bool(row["is_active"])]
        if active_keys:
            existing_key = active_keys[0]
            return {
                "ok": True,
                "resolved": "existing_active_key",
                "existing_active_key": True,
                "api_key": None,
                "key_id": existing_key["id"],
                "key_name": existing_key["name"],
                "plan": plan,
                "quota_monthly": quota_monthly,
                "subscription_status": subscription.get("status"),
                "message": "An active API key is already available for this paid account. Open Client Access to use or manage it.",
            }

    # "First key" issuance respects the current active-key limit for the effective plan.
    # Separate onboarding flows may still apply stricter one-time claim rules before this point.
    enforce_api_key_limit_for_plan(user_id, plan)

    raw_api_key, _record = create_api_key(
        user_id=user_id,
        name="first-api-key",
        plan=plan,
    )

    return {
        "ok": True,
        "resolved": "new_key_created",
        "existing_active_key": False,
        "api_key": raw_api_key,
        "plan": plan,
        "quota_monthly": quota_monthly,
        "subscription_status": subscription.get("status"),
        "message": "Store this API key now. It is shown only once.",
    }


def prepare_free_first_key_user(payload: dict):
    safe_payload = dict(payload or {})
    safe_payload["email"] = validate_email_input(safe_payload.get("email"))

    try:
        user_id = find_or_create_free_self_serve_user(safe_payload)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    # Free onboarding is intentionally single-claim strict: any prior key record blocks
    # another self-serve Free claim, even if an older key has since been deactivated.
    if count_api_keys_for_user(user_id) > 0:
        raise HTTPException(status_code=409, detail="User already has API keys")

    existing_subscription = get_latest_subscription_for_user(user_id)
    if existing_subscription and existing_subscription.get("status") == "active":
        existing_plan = existing_subscription.get("plan", "Free")
        if existing_plan != "Free":
            raise HTTPException(status_code=409, detail="User already has a non-Free subscription")

    ensure_free_self_serve_subscription(user_id)
    return user_id


def get_latest_free_claim_verification(email: str):
    return get_latest_email_verification(email, FREE_CLAIM_PURPOSE)


def is_verification_expired(verification_row) -> bool:
    if not verification_row:
        return True

    expires_at = parse_iso_datetime(verification_row["expires_at"])
    if not expires_at:
        return True

    return utcnow() > expires_at


@app.get("/")
def root():
    return {"ok": True, "service": "disposable-exec"}


@app.get("/health")
def health():
    db_status = "up"
    try:
        ping_database()
    except Exception as exc:
        db_status = "down"
        print(f"HEALTH_DB_CHECK_FAILED detail={exc}", flush=True)
        send_operational_event(
            category="health",
            event="db_down",
            severity="critical",
            detail=str(exc),
            cooldown_seconds=300,
        )

    worker_recent_heartbeat = is_worker_heartbeat_recent()
    if not worker_recent_heartbeat:
        send_operational_event(
            category="worker",
            event="heartbeat_stale",
            severity="critical",
            detail="Worker heartbeat is stale or missing.",
            cooldown_seconds=WORKER_STALLED_ALERT_COOLDOWN_SECONDS,
        )
    polar_env = get_polar_config()["env"]

    return {
        "ok": db_status == "up",
        "api": "up",
        "db": db_status,
        "worker_recent_heartbeat": worker_recent_heartbeat,
        "timestamp": utcnow_iso(),
        "polar_env": polar_env,
    }


@app.post("/admin/recovery/orphans/sweep")
def admin_recovery_orphans_sweep(admin=Depends(verify_admin_token)):
    return recover_orphaned_executions()


@app.post("/run")
def run_code(payload: dict, api_key=Depends(verify_api_key)):
    total_started_at = perf_counter()
    rate_limit_started_at = perf_counter()
    enforce_rate_limit(api_key, "/run", RUN_RATE_LIMIT_PER_MIN)
    _log_run_timing(run_step="rate_limit", started_at=rate_limit_started_at)

    payload_started_at = perf_counter()
    run_payload = _validate_run_payload(payload)
    payload_metadata = build_payload_usage_metadata(run_payload)
    request_credits = compute_execution_credits(payload_metadata["total_content_bytes"])
    _log_payload_complexity(route="/run", payload_metadata=payload_metadata)
    _log_run_timing(run_step="payload_validation", started_at=payload_started_at)

    auth_context_started_at = perf_counter()
    key_id = api_key.get("id")
    user_id = api_key.get("user_id")
    is_active = bool(api_key.get("is_active", 0))
    effective_plan = api_key.get("plan", "Free")

    if not key_id:
        raise HTTPException(status_code=500, detail="API key record missing id")

    if not user_id:
        raise HTTPException(status_code=500, detail="API key record missing user_id")

    if not is_active:
        raise HTTPException(status_code=403, detail="API key is inactive")
    _log_run_timing(run_step="api_key_context", started_at=auth_context_started_at)

    subscription_started_at = perf_counter()
    subscription = get_latest_subscription_for_user(user_id, prefer_fresh=True)
    _log_run_timing(run_step="load_subscription", started_at=subscription_started_at)

    if subscription:
        sub_status = subscription.get("status", "active")
        sub_plan = subscription.get("plan", effective_plan)

        if sub_status in {"canceled", "past_due", "paused"}:
            raise HTTPException(
                status_code=403,
                detail=f"Subscription is not active: {sub_status}",
            )

        if sub_status != "active":
            raise HTTPException(
                status_code=403,
                detail=f"Unsupported subscription status: {sub_status}",
            )

        effective_plan = sub_plan

    usage_started_at = perf_counter()
    quota = get_plan_quota(effective_plan)
    usage_period = resolve_usage_period_for_user(user_id, prefer_fresh=True)
    used_credits = get_credit_used_for_period(
        user_id,
        period_key=usage_period["period_key"],
    )
    _log_run_timing(run_step="quota_and_usage", started_at=usage_started_at)

    user_capacity_started_at = perf_counter()
    user_capacity_error = evaluate_user_concurrency_capacity(user_id, effective_plan)
    _log_run_timing(run_step="evaluate_user_concurrency_capacity", started_at=user_capacity_started_at)
    if user_capacity_error:
        event = user_capacity_error.get("event")
        if event:
            print(
                f"{event['log_name']} user_id={user_id} key_id={key_id} {event['detail']}",
                flush=True,
            )
            send_operational_event(
                category="execution",
                event=event["name"],
                severity=event["severity"],
                user_id=user_id,
                detail=event["detail"],
                cooldown_seconds=180,
            )
        raise HTTPException(status_code=user_capacity_error["status_code"], detail=user_capacity_error["detail"])

    capacity_started_at = perf_counter()
    pressure = get_host_pressure_snapshot()
    capacity_error = evaluate_run_capacity(used_credits, quota, request_credits, pressure)
    _log_run_timing(run_step="evaluate_run_capacity", started_at=capacity_started_at)
    if capacity_error:
        event = capacity_error.get("event")
        if event:
            print(
                f"{event['log_name']} user_id={user_id} key_id={key_id} {event['detail']}",
                flush=True,
            )
            send_operational_event(
                category="execution",
                event=event["name"],
                severity=event["severity"],
                user_id=user_id,
                detail=event["detail"],
                cooldown_seconds=180,
            )
        raise HTTPException(status_code=capacity_error["status_code"], detail=capacity_error["detail"])

    try:
        enqueue_started_at = perf_counter()
        job = enqueue_job(
            script=run_payload["script"],
            key_id=key_id,
            user_id=user_id,
            language=run_payload["language"],
            entrypoint=run_payload["entrypoint"],
            files=run_payload["files"],
        )
        _log_run_timing(
            run_step="enqueue_job",
            started_at=enqueue_started_at,
            execution_id=job.get("execution_id"),
        )
    except Exception as exc:
        print(
            f"RUN_ENQUEUE_FAILED user_id={user_id} key_id={key_id} exception_class={exc.__class__.__name__} detail={exc}",
            flush=True,
        )
        send_operational_event(
            category="execution",
            event="enqueue_failed",
            severity="critical",
            user_id=user_id,
            detail=f"key_id={key_id} exception_class={exc.__class__.__name__} detail={exc}",
        )
        raise HTTPException(status_code=503, detail="Execution queue is temporarily unavailable") from exc

    send_operational_event(
        category="execution",
        event="run_request_accepted",
        severity="info",
        user_id=user_id,
        detail=f"key_id={key_id} plan={effective_plan}",
        cooldown_seconds=0,
    )
    usage_increment_started_at = perf_counter()
    counters = increment_usage(
        user_id,
        period_key=usage_period["period_key"],
        credit_delta=request_credits,
        increment_execution_count=True,
    )
    try:
        record_usage_event(
            user_id=user_id,
            period_key=usage_period["period_key"],
            route_category="run",
            credit_amount=request_credits,
            payload_metadata=payload_metadata,
            key_id=key_id,
            execution_id=job.get("execution_id"),
        )
    except Exception as exc:
        print(
            "USAGE_EVENT_WRITE_FAILED "
            f"route_category=run user_id={user_id} key_id={key_id} execution_id={job.get('execution_id')} detail={exc}",
            flush=True,
        )
    _log_run_timing(
        run_step="increment_usage",
        started_at=usage_increment_started_at,
        execution_id=job.get("execution_id"),
    )
    _log_run_timing(
        run_step="run_total",
        started_at=total_started_at,
        execution_id=job.get("execution_id"),
    )

    return {
        "execution_id": job["execution_id"],
        "plan": effective_plan,
        "used": counters["credit_used"],
        "quota": quota,
        "required_credits": request_credits,
        "remaining_credits": get_remaining_credits(used_credits=counters["credit_used"], quota=quota),
    }


@app.post("/diagnose")
def diagnose_code(payload: dict, api_key=Depends(verify_api_key)):
    enforce_rate_limit(api_key, "/status", READ_RATE_LIMIT_PER_MIN)
    key_id = api_key.get("id")
    user_id = api_key.get("user_id")
    effective_plan = get_effective_plan_for_api_key(api_key)
    quota = get_plan_quota(effective_plan)
    usage_period = resolve_usage_period_for_user(user_id, prefer_fresh=True) if user_id else None

    try:
        run_payload = _validate_run_payload(payload)
    except HTTPException as exc:
        payload_metadata = build_payload_usage_metadata(payload)
        issues = [
            _build_diagnostics_issue(
                code="payload_validation_failed",
                message=str(exc.detail),
            )
        ]
        diagnostics_credit_amount = compute_diagnostics_credits(payload_metadata["total_content_bytes"])
        if user_id and usage_period and not credit_request_allowed(
            used_credits=get_credit_used_for_period(
                user_id,
                period_key=usage_period["period_key"],
            ),
            quota=quota,
            required_credits=diagnostics_credit_amount,
        ):
            raise HTTPException(status_code=403, detail="Monthly credit quota exceeded")
        if user_id and usage_period:
            increment_usage(
                user_id,
                period_key=usage_period["period_key"],
                credit_delta=diagnostics_credit_amount,
                increment_execution_count=False,
            )
        try:
            record_usage_event(
                user_id=user_id,
                period_key=usage_period["period_key"] if usage_period else None,
                route_category="diagnose",
                credit_amount=diagnostics_credit_amount,
                payload_metadata=payload_metadata,
                key_id=key_id,
            )
        except Exception as event_exc:
            print(
                "USAGE_EVENT_WRITE_FAILED "
                f"route_category=diagnose user_id={user_id} key_id={key_id} detail={event_exc}",
                flush=True,
            )
        return _build_diagnostics_response(issues=issues, payload_metadata=payload_metadata)

    payload_metadata = build_payload_usage_metadata(run_payload)
    diagnostics_credit_amount = compute_diagnostics_credits(payload_metadata["total_content_bytes"])
    if user_id and usage_period:
        used_credits = get_credit_used_for_period(
            user_id,
            period_key=usage_period["period_key"],
        )
        if not credit_request_allowed(
            used_credits=used_credits,
            quota=quota,
            required_credits=diagnostics_credit_amount,
        ):
            raise HTTPException(status_code=403, detail="Monthly credit quota exceeded")
    _log_payload_complexity(route="/diagnose", payload_metadata=payload_metadata)
    issues = _diagnose_python_syntax_and_imports(run_payload)
    if user_id and usage_period:
        increment_usage(
            user_id,
            period_key=usage_period["period_key"],
            credit_delta=diagnostics_credit_amount,
            increment_execution_count=False,
        )
    try:
        record_usage_event(
            user_id=user_id,
            period_key=usage_period["period_key"] if usage_period else None,
            route_category="diagnose",
            credit_amount=diagnostics_credit_amount,
            payload_metadata=payload_metadata,
            key_id=key_id,
        )
    except Exception as exc:
        print(
            "USAGE_EVENT_WRITE_FAILED "
            f"route_category=diagnose user_id={user_id} key_id={key_id} detail={exc}",
            flush=True,
        )
    return _build_diagnostics_response(issues=issues, payload_metadata=payload_metadata)


@app.get("/status")
def status_query(execution_id: str, api_key=Depends(verify_api_key)):
    enforce_rate_limit(api_key, "/status", READ_RATE_LIMIT_PER_MIN)

    return build_status_response(execution_id, api_key)


@app.get("/status/{execution_id}")
def status(execution_id: str, api_key=Depends(verify_api_key)):
    enforce_rate_limit(api_key, "/status", READ_RATE_LIMIT_PER_MIN)

    data = build_status_response(execution_id, api_key)
    if data["status"] == "not_found":
        raise HTTPException(status_code=404, detail="Execution not found")
    return data


@app.get("/result")
def result_query(execution_id: str, api_key=Depends(verify_api_key)):
    enforce_rate_limit(api_key, "/result", READ_RATE_LIMIT_PER_MIN)

    data = get_result(
        execution_id,
        key_id=api_key.get("id"),
        user_id=api_key.get("user_id"),
    )
    if data is None:
        return {
            "execution_id": execution_id,
            "status": "not_found",
            "stdout": "",
            "stderr": "",
            "exit_code": None,
            "finished_at": None,
            "result": None,
        }
    return data


@app.get("/result/{execution_id}")
def result(execution_id: str, api_key=Depends(verify_api_key)):
    enforce_rate_limit(api_key, "/result", READ_RATE_LIMIT_PER_MIN)

    data = get_result(
        execution_id,
        key_id=api_key.get("id"),
        user_id=api_key.get("user_id"),
    )
    if data is None:
        raise HTTPException(status_code=404, detail="Result not found")
    return data


@app.get("/me")
def me(api_key=Depends(verify_api_key)):
    enforce_rate_limit(api_key, "/me", READ_RATE_LIMIT_PER_MIN)

    user_id = api_key.get("user_id")
    key_plan = api_key.get("plan", "Free")
    subscription = get_runtime_subscription_for_user(user_id, "/me") if user_id else None

    effective_plan = key_plan
    subscription_status = None
    period_start = None
    period_end = None
    subscription_response = dict(subscription) if subscription else None

    if subscription:
        subscription_status = subscription.get("status")
        period_start = subscription.get("period_start")
        period_end = subscription.get("period_end")

        if (
            subscription.get("provider") == "internal"
            and subscription.get("plan") == "Free"
            and (not period_start or not period_end)
        ):
            period_start, period_end = fill_free_subscription_period_window(period_start, period_end)
            subscription_response["period_start"] = period_start
            subscription_response["period_end"] = period_end

        if subscription_status == "active":
            key_plan = subscription.get("plan", key_plan)
            effective_plan = key_plan

    quota = get_plan_quota(effective_plan)
    usage_period = resolve_usage_period_for_user(user_id, prefer_fresh=True) if user_id else None
    used = 0
    credit_used = 0.0
    if user_id and usage_period:
        used = get_usage_count_for_period(
            user_id,
            period_key=usage_period["period_key"],
            prefer_fresh=True,
        )
        credit_used = get_credit_used_for_period(
            user_id,
            period_key=usage_period["period_key"],
        )
    active_key_count = count_active_keys_for_user(user_id)
    key_limit = get_plan_key_limit(effective_plan)
    credit_remaining = get_remaining_credits(used_credits=credit_used, quota=quota)

    return {
        "api_key_id": api_key.get("id"),
        "user_id": user_id,
        "is_active": bool(api_key.get("is_active", 0)),
        "key_plan": key_plan,
        "effective_plan": effective_plan,
        "effective_quota_monthly": quota,
        "active_key_count": active_key_count,
        "key_limit": key_limit,
        "usage_this_period": credit_used,
        "execution_count_this_period": used,
        "credit_used_this_period": credit_used,
        "credit_remaining_this_period": credit_remaining,
        "subscription_status": subscription_status,
        "current_period_start": period_start,
        "current_period_end": period_end,
        "subscription": subscription_response,
    }


@app.get("/apikey")
def list_my_api_keys(api_key=Depends(verify_api_key)):
    enforce_rate_limit(api_key, "/apikey:list", READ_RATE_LIMIT_PER_MIN)

    user_id = api_key.get("user_id")
    if not user_id:
        raise HTTPException(status_code=400, detail="Missing user_id")

    rows = list_api_keys_for_user(user_id)

    return {
        "items": [
            {
                "id": row["id"],
                "user_id": row["user_id"],
                "name": row["name"],
                "plan": row["plan"],
                "is_active": bool(row["is_active"]),
                "created_at": row["created_at"],
            }
            for row in rows
        ]
    }


@app.post("/apikey")
def create_api_key_endpoint(payload: dict, api_key=Depends(verify_api_key)):
    enforce_rate_limit(api_key, "/apikey:create", 10)

    user_id = api_key.get("user_id")
    name = payload.get("name", "default")

    subscription = get_latest_subscription_for_user(user_id) if user_id else None
    plan = api_key.get("plan", "Free")
    if subscription and subscription.get("status") == "active":
        plan = subscription.get("plan", plan)

    enforce_api_key_limit_for_plan(user_id, plan)

    raw_key, record = create_api_key(user_id=user_id, name=name, plan=plan)
    record["is_active"] = bool(record["is_active"])

    return {
        "api_key": raw_key,
        "record": record,
    }


@app.post("/apikey/reissue")
def reissue_api_key_endpoint(api_key=Depends(verify_api_key)):
    enforce_rate_limit(api_key, "/apikey:reissue", 10)

    user_id = api_key.get("user_id")
    try:
        result = reissue_paid_api_key_for_user(user_id)
    except HTTPException as exc:
        detail = exc.detail if isinstance(exc.detail, dict) else {"message": str(exc.detail)}
        print(f"API_KEY_REISSUE_FAILED user_id={user_id} detail={detail}", flush=True)
        send_operational_event(
            category="onboarding",
            event="api_key_reissue_failed",
            severity="warning",
            user_id=user_id,
            detail=detail.get("message", str(exc.detail)),
        )
        raise
    result["auth_key_replaced"] = True
    result["reissue_scope"] = "authenticated"
    return result


@app.post("/billing/portal")
def create_billing_portal_endpoint(api_key=Depends(verify_api_key)):
    enforce_rate_limit(api_key, "/billing/portal", 10)

    user_id = api_key.get("user_id")
    if not user_id:
        print("BILLING_PORTAL_FAILED reason=missing_user_id", flush=True)
        send_operational_event(
            category="billing",
            event="billing_portal_failed",
            severity="warning",
            detail="reason=missing_user_id",
        )
        return JSONResponse(
            status_code=400,
            content={
                "ok": False,
                "portal_url": None,
                "message": "Billing portal is not available for this subscription yet.",
                "provider": None,
                "subscription_id": None,
                "fallback_url": None,
                "detail": {
                    "code": "billing_portal_unavailable",
                    "message": "Billing portal is not available for this subscription yet.",
                },
            },
        )

    try:
        portal_session = create_billing_portal_for_user(user_id)
    except BillingPortalError as exc:
        print(
            "BILLING_PORTAL_FAILED "
            f"user_id={user_id} code={exc.code} status_code={exc.status_code} detail={exc.message}",
            flush=True,
        )
        send_operational_event(
            category="billing",
            event="billing_portal_failed",
            severity="warning" if exc.status_code < 500 else "critical",
            user_id=user_id,
            detail=f"code={exc.code} status_code={exc.status_code} detail={exc.message}",
        )
        return JSONResponse(
            status_code=exc.status_code,
            content={
                "ok": False,
                "portal_url": None,
                "message": "Billing portal is not available for this subscription yet.",
                "provider": None,
                "subscription_id": None,
                "fallback_url": None,
                "detail": {
                    "code": exc.code,
                    "message": exc.message,
                },
            },
        )
    except Exception as exc:
        print(
            "BILLING_PORTAL_FAILED "
            f"user_id={user_id} code=unexpected_error exception_class={exc.__class__.__name__} detail={exc}",
            flush=True,
        )
        send_operational_event(
            category="billing",
            event="billing_portal_unexpected_error",
            severity="critical",
            user_id=user_id,
            detail=f"exception_class={exc.__class__.__name__} detail={exc}",
        )
        return JSONResponse(
            status_code=500,
            content={
                "ok": False,
                "portal_url": None,
                "message": "Billing portal is not available for this subscription yet.",
                "provider": None,
                "subscription_id": None,
                "fallback_url": None,
                "detail": {
                    "code": "billing_portal_unavailable",
                    "message": "Billing portal is not available for this subscription yet.",
                },
            },
        )

    return {
        "ok": True,
        "message": "Billing portal ready.",
        "provider": portal_session["provider"],
        "subscription_id": portal_session["provider_subscription_id"],
        "portal_url": portal_session["portal_url"],
        "fallback_url": None,
    }


@app.delete("/apikey/{key_id}")
def disable_api_key_endpoint(key_id: str, api_key=Depends(verify_api_key)):
    enforce_rate_limit(api_key, "/apikey:disable", 10)

    user_id = api_key.get("user_id")
    rows = list_api_keys_for_user(user_id)
    matched = [row for row in rows if row["id"] == key_id]

    if not matched:
        raise HTTPException(status_code=404, detail="API key not found")

    ok = disable_api_key(key_id)
    if not ok:
        raise HTTPException(status_code=400, detail="Failed to disable API key")

    return {"ok": True, "disabled_key_id": key_id}


@app.post("/onboarding/free-request-code")
def free_request_code(payload: dict, request: Request):
    email = validate_email_input(payload.get("email"))

    if has_free_claim_for_email(email):
        return build_already_claimed_response()

    enforce_ip_rate_limit(
        request,
        "/onboarding/free-request-code",
        FREE_REQUEST_CODE_LIMIT_PER_HOUR,
    )

    code = f"{secrets.randbelow(1000000):06d}"
    expires_at = (utcnow() + timedelta(seconds=FREE_CODE_TTL_SECONDS)).isoformat()

    create_email_verification(
        email=email,
        code=code,
        purpose=FREE_CLAIM_PURPOSE,
        expires_at=expires_at,
    )

    try:
        email_mode = get_free_email_mode()
    except RuntimeError as exc:
        raise HTTPException(status_code=500, detail=str(exc))

    if email_mode == "smtp":
        try:
            send_free_verification_code_email(
                to_email=email,
                code=code,
                expires_in_seconds=FREE_CODE_TTL_SECONDS,
            )
        except RuntimeError as exc:
            raise HTTPException(status_code=500, detail=str(exc))
        except Exception:
            raise HTTPException(status_code=500, detail="Failed to send verification email")

        return {
            "ok": True,
            "expires_in_seconds": FREE_CODE_TTL_SECONDS,
            "message": "Verification code sent.",
        }

    return {
        "ok": True,
        "dev_code": code,
        "expires_in_seconds": FREE_CODE_TTL_SECONDS,
        "message": "Verification code created.",
    }


@app.post("/onboarding/free-verify-code-and-claim")
def free_verify_code_and_claim(payload: dict, request: Request):
    email = validate_email_input(payload.get("email"))
    code = validate_verification_code_input(payload.get("code"))

    enforce_ip_rate_limit(
        request,
        "/onboarding/free-verify-code-and-claim",
        FREE_VERIFY_LIMIT_PER_HOUR,
    )

    if has_free_claim_for_email(email):
        return build_already_claimed_response()

    verification = get_email_verification_by_email_and_code(
        email=email,
        code=code,
        purpose=FREE_CLAIM_PURPOSE,
    )
    if not verification:
        raise HTTPException(status_code=400, detail="Invalid or expired verification code")

    if verification["used_at"]:
        increment_email_verification_attempts(verification["id"])
        raise HTTPException(status_code=400, detail="Invalid or expired verification code")

    if is_verification_expired(verification):
        increment_email_verification_attempts(verification["id"])
        raise HTTPException(status_code=400, detail="Invalid or expired verification code")

    user_id = prepare_free_first_key_user({"email": email})
    mark_email_verification_used(verification["id"])
    result = issue_first_key_for_user(user_id)
    store_free_claim_email_mapping(user_id, email)
    return result


@app.post("/onboarding/free-claim-first-key")
def free_claim_first_api_key(payload: dict):
    raise HTTPException(
        status_code=410,
        detail="This endpoint is deprecated. Use /onboarding/free-request-code and /onboarding/free-verify-code-and-claim.",
    )


@app.post("/onboarding/claim-first-key")
def claim_first_api_key(payload: dict):
    raw_token = (payload.get("token") or "").strip()
    if not raw_token:
        raise HTTPException(status_code=400, detail="Missing token")

    token_row = get_onboarding_token(raw_token, purpose="claim_first_key")
    if not token_row:
        raise HTTPException(status_code=404, detail="Invalid onboarding token")

    if token_row["used_at"]:
        raise HTTPException(status_code=409, detail="Onboarding token already used")

    expires_at = token_row["expires_at"]
    if expires_at and utcnow() > parse_iso_datetime(expires_at):
        raise HTTPException(status_code=410, detail="Onboarding token expired")

    result = issue_first_key_for_user(token_row["user_id"])
    mark_onboarding_token_used(token_row["id"])
    return result


@app.post("/onboarding/auto-claim-first-key")
def auto_claim_first_api_key(payload: dict):
    provider, lookup_mode, session_row, checkout_rows = find_onboarding_session_from_payload(payload)
    log_auto_claim_context(payload, provider, lookup_mode, session_row, checkout_rows, reason="route_start")
    checkout_id = (payload.get("checkout_id") or "").strip()
    if checkout_id and not checkout_rows:
        checkout_rows = list(get_onboarding_session_by_checkout_id(provider, checkout_id) or [])
        log_auto_claim_context(payload, provider, lookup_mode, session_row, checkout_rows, reason="checkout_rows_loaded")

    if session_row["used_at"]:
        log_auto_claim_context(payload, provider, lookup_mode, session_row, checkout_rows, reason="session_already_used")
        if checkout_rows:
            for row in checkout_rows:
                recovery_response = build_existing_active_key_recovery_response(row, "checkout_id", provider)
                if recovery_response:
                    return recovery_response
        alert_auto_claim_failure("session_already_used", provider, lookup_mode, session_row, "Auto-claim session already used")
        raise HTTPException(status_code=409, detail="Auto-claim session already used")

    if is_onboarding_session_expired(session_row):
        log_auto_claim_context(payload, provider, lookup_mode, session_row, checkout_rows, reason="session_expired")
        if checkout_rows:
            for row in checkout_rows:
                recovery_response = build_existing_active_key_recovery_response(row, "checkout_id", provider)
                if recovery_response:
                    return recovery_response
        recovery_response = build_existing_active_key_recovery_response(session_row, lookup_mode, provider)
        if recovery_response:
            return recovery_response
        alert_auto_claim_failure("session_expired", provider, lookup_mode, session_row, "Auto-claim session expired")
        raise HTTPException(status_code=410, detail="Auto-claim session expired")

    try:
        result = issue_first_key_for_user(
            session_row["user_id"],
            session_row=session_row,
            allow_existing_active_key=True,
        )
    except HTTPException as exc:
        subscription = get_subscription_for_onboarding_context(
            session_row["user_id"],
            provider=session_row["provider"],
            provider_subscription_id=session_row["provider_subscription_id"],
        )
        log_auto_claim_context(
            payload,
            provider,
            lookup_mode,
            session_row,
            checkout_rows,
            subscription=subscription,
            reason=f"route_exception_{exc.status_code}",
        )
        alert_auto_claim_failure(
            f"http_{exc.status_code}",
            provider,
            lookup_mode,
            session_row,
            exc.detail.get("message", str(exc.detail)) if isinstance(exc.detail, dict) else str(exc.detail),
        )
        raise
    if result.get("existing_active_key"):
        recovery = issue_paid_recovery_session(session_row)
        result.update(recovery)
    if not result.get("existing_active_key"):
        mark_onboarding_session_used(session_row["id"])
    result["lookup_mode"] = lookup_mode
    result["provider"] = provider
    result["provider_checkout_id"] = session_row["provider_checkout_id"]
    result["provider_subscription_id"] = session_row["provider_subscription_id"]
    result["session_token"] = (payload.get("session_token") or payload.get("token") or "").strip() or None
    result["session_token_available"] = bool(result["session_token"])
    return result


@app.post("/onboarding/reissue-paid-key")
def onboarding_reissue_paid_key(payload: dict):
    try:
        provider, lookup_mode, session_row = get_onboarding_session_from_payload(payload)
    except HTTPException as exc:
        message = exc.detail if isinstance(exc.detail, str) else exc.detail.get("message", "Paid key reissue is not available from this page.")
        raise HTTPException(
            status_code=exc.status_code,
            detail=build_reissue_error(message),
        ) from exc

    if session_row["used_at"]:
        raise HTTPException(
            status_code=409,
            detail=build_reissue_error("Paid key reissue is no longer available from this page."),
        )

    result = reissue_paid_api_key_for_user(session_row["user_id"])
    mark_onboarding_session_used(session_row["id"])
    result["lookup_mode"] = lookup_mode
    result["provider"] = provider
    result["reissue_scope"] = "onboarding"
    return result


@app.post("/onboarding/recover-paid-key")
def onboarding_recover_paid_key(payload: dict):
    raw_session_token = (payload.get("recovery_session_token") or payload.get("session_token") or payload.get("token") or "").strip()
    if not raw_session_token:
        raise HTTPException(
            status_code=400,
            detail={
                "code": "paid_recovery_token_invalid",
                "message": "Missing paid recovery token.",
            },
        )

    session_row = get_onboarding_session_by_raw_token(raw_session_token)
    if not session_row:
        raise HTTPException(
            status_code=404,
            detail={
                "code": "paid_recovery_token_invalid",
                "message": "Invalid paid recovery token.",
            },
        )

    if session_row["used_at"]:
        raise HTTPException(
            status_code=409,
            detail={
                "code": "paid_recovery_token_invalid",
                "message": "Paid recovery token has already been used.",
            },
        )

    expires_at = session_row["expires_at"]
    if expires_at and utcnow() > parse_iso_datetime(expires_at):
        raise HTTPException(
            status_code=410,
            detail={
                "code": "paid_recovery_token_invalid",
                "message": "Paid recovery token has expired.",
            },
        )

    result = reissue_paid_api_key_for_user(session_row["user_id"])
    mark_onboarding_session_used(session_row["id"])
    result["provider"] = session_row["provider"]
    result["provider_subscription_id"] = session_row["provider_subscription_id"]
    result["reissue_scope"] = "paid_recovery"
    return result


@app.get("/admin/users")
def admin_users(admin=Depends(verify_admin_token)):
    return {"items": list_users()}


@app.get("/admin/metrics")
def admin_metrics(admin=Depends(verify_admin_token)):
    snapshot = get_admin_metrics()
    warning_summary = build_admin_metrics_warning_summary(snapshot)
    if warning_summary:
        send_operational_event(
            category="health",
            event="admin_metrics_warning_summary",
            severity=warning_summary["severity"],
            detail=warning_summary["detail"],
            message_override=warning_summary["message"],
            cooldown_seconds=900,
        )
    return snapshot


@app.get("/admin/host/pressure")
def admin_host_pressure(admin=Depends(verify_admin_token)):
    # Production-safe VPS pressure view for queue, memory, disk, and load thresholds.
    snapshot = get_host_pressure_snapshot()
    snapshot["ok"] = True
    return snapshot


@app.get("/admin/workers")
def admin_workers(admin=Depends(verify_admin_token)):
    # Future remote-worker rollout verification: read-only worker registry view.
    return {"items": list_workers()}


@app.get("/admin/workers/load")
def admin_workers_load(hours: int = 24, admin=Depends(verify_admin_token)):
    # Multi-worker dispatch v1 observability for assignment and workload inspection.
    return {
        "ok": True,
        "hours": max(1, int(hours)),
        "items": get_worker_load_view(hours=max(1, int(hours))),
    }


@app.get("/admin/operational-events/summary")
def admin_operational_events_summary(day: str | None = None, admin=Depends(verify_admin_token)):
    # Production-oriented daily summary for operational monitoring v3.
    summary = get_operational_event_counts_for_day(day)
    summary["daily_summary"] = build_daily_operational_summary(day)
    summary["ok"] = True
    return summary


@app.get("/admin/queue/summary")
def admin_queue_summary(limit: int = 20, admin=Depends(verify_admin_token)):
    # Operator queue inspection for execution-chain recovery.
    return {
        "ok": True,
        **get_queue_summary(limit=max(1, min(int(limit), 100))),
    }


@app.get("/admin/executions/summary")
def admin_executions_summary(hours: int = 24, stuck_minutes: int = 15, admin=Depends(verify_admin_token)):
    # Operator summary for execution-chain recovery and stuck-job inspection.
    summary = get_execution_summary(hours=max(1, int(hours)), stuck_minutes=max(1, int(stuck_minutes)))
    summary["ok"] = True
    return summary


@app.get("/admin/executions/{execution_id}")
def admin_execution_audit(execution_id: str, admin=Depends(verify_admin_token)):
    # Operator audit view for execution-chain recovery without manual DB edits.
    status_row = get_status(execution_id)
    result_row = get_result(execution_id)
    if not status_row and not result_row:
        raise HTTPException(status_code=404, detail="Execution not found")

    assigned_worker_id = (status_row or {}).get("assigned_worker_id")
    completed_by_worker_id = (status_row or {}).get("completed_by_worker_id") or (result_row or {}).get("completed_by_worker_id")
    return {
        "ok": True,
        "execution_id": execution_id,
        "status": status_row,
        "result": result_row,
        "worker_context": {
            "assigned_worker": get_worker_context(assigned_worker_id),
            "completed_by_worker": get_worker_context(completed_by_worker_id),
        },
    }


@app.post("/admin/executions/{execution_id}/requeue")
def admin_execution_requeue(execution_id: str, payload: dict, admin=Depends(verify_admin_token)):
    # Operator backdoor for safe execution requeue when script input is known.
    execution_row = get_execution_row(execution_id)
    result_row = get_result(execution_id)
    if not execution_row and not result_row:
        raise HTTPException(status_code=404, detail="Execution not found")

    script = (payload.get("script") or "").strip()
    if not script:
        raise HTTPException(status_code=400, detail="Missing script for requeue")

    key_id = (payload.get("key_id") or (execution_row or {}).get("key_id") or "").strip()
    if not key_id:
        raise HTTPException(status_code=400, detail="Missing key_id for requeue")

    user_id = payload.get("user_id") or (execution_row or {}).get("user_id")
    assigned_worker_id = payload.get("assigned_worker_id") or (execution_row or {}).get("assigned_worker_id")
    job = enqueue_existing_job(
        execution_id,
        script=script,
        key_id=key_id,
        user_id=user_id,
        assigned_worker_id=assigned_worker_id,
    )
    send_operational_event(
        category="execution",
        event="execution_requeued",
        severity="info",
        user_id=user_id,
        worker_id=job.get("assigned_worker_id"),
        execution_id=execution_id,
        detail=f"assigned_worker_id={job.get('assigned_worker_id') or ''} previous_result_preserved={bool(result_row)}",
        cooldown_seconds=60,
    )
    return {
        "ok": True,
        "action": "execution_requeued",
        "execution_id": execution_id,
        "assigned_worker_id": job.get("assigned_worker_id"),
        "previous_result_preserved": bool(result_row),
    }


@app.post("/admin/executions/{execution_id}/mark-failed")
def admin_execution_mark_failed(execution_id: str, payload: dict, admin=Depends(verify_admin_token)):
    # Operator backdoor for stuck execution recovery.
    status_row = get_status(execution_id)
    result_row = get_result(execution_id)
    if not status_row and not result_row:
        raise HTTPException(status_code=404, detail="Execution not found")

    reason = (payload.get("reason") or payload.get("detail") or "Marked failed by operator").strip()
    assigned_worker_id = (status_row or {}).get("assigned_worker_id")
    completed_by_worker_id = (
        payload.get("completed_by_worker_id")
        or (status_row or {}).get("completed_by_worker_id")
        or (result_row or {}).get("completed_by_worker_id")
    )

    set_status(
        execution_id,
        "failed",
        assigned_worker_id=assigned_worker_id,
        completed_by_worker_id=completed_by_worker_id,
    )
    save_result(
        execution_id,
        {
            "stdout": (payload.get("stdout") or ""),
            "stderr": reason,
            "exit_code": -1,
            "duration": payload.get("duration", 0),
        },
        completed_by_worker_id=completed_by_worker_id,
    )
    send_operational_event(
        category="execution",
        event="execution_marked_failed",
        severity="info",
        user_id=(status_row or {}).get("user_id"),
        worker_id=completed_by_worker_id or assigned_worker_id,
        execution_id=execution_id,
        detail=f"reason={reason}",
        cooldown_seconds=60,
    )
    return {
        "ok": True,
        "action": "execution_marked_failed",
        "execution_id": execution_id,
        "reason": reason,
        "worker_context": {
            "assigned_worker": get_worker_context(assigned_worker_id),
            "completed_by_worker": get_worker_context(completed_by_worker_id),
        },
    }


@app.post("/admin/executions/{execution_id}/write-result")
def admin_execution_write_result(execution_id: str, payload: dict, admin=Depends(verify_admin_token)):
    # Operator backdoor for execution result repair and writeback recovery.
    status_row = get_status(execution_id)
    result_row = get_result(execution_id)
    if not status_row and not result_row:
        raise HTTPException(status_code=404, detail="Execution not found")

    exit_code = payload.get("exit_code")
    if exit_code is None:
        raise HTTPException(status_code=400, detail="Missing exit_code")

    completed_by_worker_id = (payload.get("completed_by_worker_id") or (status_row or {}).get("completed_by_worker_id") or (result_row or {}).get("completed_by_worker_id"))
    save_result(
        execution_id,
        {
            "stdout": payload.get("stdout", ""),
            "stderr": payload.get("stderr", ""),
            "exit_code": exit_code,
            "duration": payload.get("duration"),
        },
        completed_by_worker_id=completed_by_worker_id,
    )
    set_status(
        execution_id,
        terminal_status_for_exit_code(int(exit_code)),
        assigned_worker_id=(status_row or {}).get("assigned_worker_id"),
        completed_by_worker_id=completed_by_worker_id,
    )
    send_operational_event(
        category="execution",
        event="execution_result_written",
        severity="info",
        user_id=(status_row or {}).get("user_id"),
        worker_id=completed_by_worker_id or (status_row or {}).get("assigned_worker_id"),
        execution_id=execution_id,
        detail=f"exit_code={exit_code}",
        cooldown_seconds=60,
    )
    return {
        "ok": True,
        "action": "execution_result_written",
        "execution_id": execution_id,
        "status": terminal_status_for_exit_code(int(exit_code)),
        "worker_context": {
            "assigned_worker": get_worker_context((status_row or {}).get("assigned_worker_id")),
            "completed_by_worker": get_worker_context(completed_by_worker_id),
        },
    }


@app.get("/admin/workers/summary")
def admin_workers_summary(hours: int = 24, admin=Depends(verify_admin_token)):
    # Worker/node summary for future remote-worker rollout verification.
    total_started_at = perf_counter()
    normalized_hours = max(1, int(hours))
    summary_started_at = perf_counter()
    items = get_worker_summary(hours=normalized_hours)
    summary_elapsed_ms = round((perf_counter() - summary_started_at) * 1000, 1)
    total_elapsed_ms = round((perf_counter() - total_started_at) * 1000, 1)
    print(
        "ADMIN_WORKERS_SUMMARY_TIMING "
        f"hours={normalized_hours} "
        f"summary_elapsed_ms={summary_elapsed_ms} "
        f"total_elapsed_ms={total_elapsed_ms}",
        flush=True,
    )
    return {
        "ok": True,
        "hours": normalized_hours,
        "items": items,
    }


@app.post("/admin/workers/{worker_id}/state")
def admin_worker_state(worker_id: str, payload: dict, admin=Depends(verify_admin_token)):
    # Operator worker drain/enable control for current local use and future remote workers.
    if not get_worker(worker_id):
        raise HTTPException(status_code=404, detail="Worker not found")

    enabled = parse_optional_bool(payload.get("enabled"))
    status = payload.get("status")
    if enabled is None and not status:
        raise HTTPException(status_code=400, detail="Missing worker state update")

    try:
        worker = update_worker_state(
            worker_id,
            enabled=enabled,
            status=status,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    send_operational_event(
        category="worker",
        event="worker_state_updated",
        severity="info",
        worker_id=worker_id,
        detail=f"enabled={worker.get('enabled')} status={worker.get('status')}",
        cooldown_seconds=60,
    )
    return {
        "ok": True,
        "action": "worker_state_updated",
        "worker": worker,
    }


@app.post("/admin/workers/{worker_id}/drain")
def admin_worker_drain(worker_id: str, admin=Depends(verify_admin_token)):
    # Multi-worker dispatch v1 control: stop new assignment but let assigned work continue.
    if not get_worker(worker_id):
        raise HTTPException(status_code=404, detail="Worker not found")
    worker = update_worker_state(worker_id, enabled=True, status="draining")
    send_operational_event(
        category="worker",
        event="worker_draining",
        severity="info",
        worker_id=worker_id,
        detail="status=draining enabled=1",
        cooldown_seconds=60,
    )
    return {
        "ok": True,
        "action": "worker_draining",
        "worker": worker,
    }


@app.post("/admin/workers/{worker_id}/activate")
def admin_worker_activate(worker_id: str, admin=Depends(verify_admin_token)):
    if not get_worker(worker_id):
        raise HTTPException(status_code=404, detail="Worker not found")
    worker = update_worker_state(worker_id, enabled=True, status="active")
    send_operational_event(
        category="worker",
        event="worker_activated",
        severity="info",
        worker_id=worker_id,
        detail="status=active enabled=1",
        cooldown_seconds=60,
    )
    return {
        "ok": True,
        "action": "worker_activated",
        "worker": worker,
    }


@app.post("/admin/subscriptions/resync")
def admin_subscriptions_resync(payload: dict, admin=Depends(verify_admin_token)):
    # Internal recovery path for repairing paid subscription state without manual DB edits.
    try:
        result = admin_resync_subscription(
            provider=payload.get("provider"),
            provider_subscription_id=payload.get("provider_subscription_id") or payload.get("subscription_id"),
            provider_customer_id=payload.get("provider_customer_id") or payload.get("customer_id"),
            user_id=payload.get("user_id"),
            plan=payload.get("plan"),
            status=payload.get("status"),
            period_start=payload.get("period_start"),
            period_end=payload.get("period_end"),
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    return {
        "ok": True,
        "action": "subscription_resynced",
        "subscription": result,
    }


@app.post("/admin/onboarding/recover")
def admin_onboarding_recover(payload: dict, admin=Depends(verify_admin_token)):
    # Internal recovery path for rebuilding paid onboarding artifacts from active subscription state.
    subscription = find_subscription_for_recovery(
        provider=payload.get("provider"),
        provider_subscription_id=payload.get("provider_subscription_id") or payload.get("subscription_id"),
        provider_customer_id=payload.get("provider_customer_id") or payload.get("customer_id"),
        user_id=payload.get("user_id"),
    )
    if not subscription:
        raise HTTPException(status_code=404, detail="Active subscription could not be resolved")

    if subscription.get("status") != "active" or subscription.get("plan") == "Free":
        raise HTTPException(status_code=403, detail="Onboarding recovery is only available for active paid subscriptions")

    session = create_onboarding_session(
        user_id=subscription["user_id"],
        provider=subscription["provider"],
        provider_subscription_id=subscription["provider_subscription_id"],
        provider_checkout_id=payload.get("provider_checkout_id") or payload.get("checkout_id"),
        ttl_minutes=int(payload.get("session_ttl_minutes") or 60),
    )
    token = create_onboarding_token(
        user_id=subscription["user_id"],
        purpose="claim_first_key",
        ttl_minutes=int(payload.get("token_ttl_minutes") or 30),
    )
    return {
        "ok": True,
        "action": "onboarding_rebuilt",
        "subscription": {
            "user_id": subscription["user_id"],
            "provider": subscription["provider"],
            "provider_subscription_id": subscription["provider_subscription_id"],
            "plan": subscription["plan"],
            "status": subscription["status"],
        },
        "onboarding_session": {
            "id": session["id"],
            "provider_checkout_id": session["provider_checkout_id"],
            "provider_subscription_id": session["provider_subscription_id"],
            "expires_at": session["expires_at"],
            "session_token": session["raw_token"],
        },
        "onboarding_token": {
            "id": token["id"],
            "purpose": token["purpose"],
            "expires_at": token["expires_at"],
            "token": token["raw_token"],
        },
    }


@app.post("/admin/onboarding/issue-first-key")
def admin_onboarding_issue_first_key(payload: dict, admin=Depends(verify_admin_token)):
    # Internal recovery path for active paid users who still need first-key delivery.
    subscription = find_subscription_for_recovery(
        provider=payload.get("provider"),
        provider_subscription_id=payload.get("provider_subscription_id") or payload.get("subscription_id"),
        provider_customer_id=payload.get("provider_customer_id") or payload.get("customer_id"),
        user_id=payload.get("user_id"),
    )
    if not subscription:
        raise HTTPException(status_code=404, detail="Active subscription could not be resolved")

    if subscription.get("status") != "active" or subscription.get("plan") == "Free":
        raise HTTPException(status_code=403, detail="First-key recovery is only available for active paid subscriptions")

    active_key_count = count_active_keys_for_user(subscription["user_id"])
    if active_key_count > 0:
        rows = list_api_keys_for_user(subscription["user_id"])
        active_keys = [row for row in rows if bool(row["is_active"])]
        return {
            "ok": True,
            "action": "existing_active_key_present",
            "user_id": subscription["user_id"],
            "active_key_count": active_key_count,
            "items": [
                {
                    "id": row["id"],
                    "name": row["name"],
                    "plan": row["plan"],
                    "is_active": bool(row["is_active"]),
                    "created_at": row["created_at"],
                }
                for row in active_keys
            ],
        }

    result = issue_first_key_for_user(
        subscription["user_id"],
        session_row={
            "id": None,
            "provider": subscription["provider"],
            "provider_subscription_id": subscription["provider_subscription_id"],
            "provider_checkout_id": payload.get("provider_checkout_id") or payload.get("checkout_id"),
        },
        allow_existing_active_key=False,
    )
    return {
        "ok": True,
        "action": "first_key_issued",
        "user_id": subscription["user_id"],
        "provider": subscription["provider"],
        "provider_subscription_id": subscription["provider_subscription_id"],
        **result,
    }


@app.post("/internal/workers/register")
def internal_worker_register(payload: dict, internal=Depends(verify_internal_token)):
    # Remote worker preparation: internal-only intake for future worker nodes.
    worker_id = (payload.get("worker_id") or "").strip()
    label = (payload.get("label") or worker_id).strip()
    auth_token = (payload.get("auth_token") or "").strip()
    try:
        max_concurrency = int(payload.get("max_concurrency") or 1)
    except (TypeError, ValueError):
        raise HTTPException(status_code=400, detail="Invalid max_concurrency")
    if not worker_id or not label or not auth_token:
        raise HTTPException(status_code=400, detail="Missing worker registration fields")

    worker = register_worker_with_token(
        worker_id,
        label=label,
        auth_token=auth_token,
        max_concurrency=max_concurrency,
        enabled=True,
        status="active",
    )
    update_detail = f"worker_id={worker['id']} label={worker['label']} max_concurrency={worker['max_concurrency']}"
    send_operational_event(
        category="worker",
        event="worker_registered",
        severity="info",
        worker_id=worker["id"],
        detail=update_detail,
        cooldown_seconds=60,
    )
    return {"ok": True, "worker": worker}


@app.post("/internal/workers/heartbeat")
def internal_worker_heartbeat(payload: dict, internal=Depends(verify_internal_token)):
    worker = authenticate_worker_request(payload)
    set_worker_heartbeat(worker_id=worker["id"], status="active")
    return {
        "ok": True,
        "worker": {
            "id": worker["id"],
            "label": worker["label"],
            "status": "active",
        },
    }


@app.get("/admin/subscriptions")
def admin_subscriptions(admin=Depends(verify_admin_token)):
    return {"items": list_subscriptions()}


@app.post("/billing/webhook/paddle")
async def billing_webhook_paddle(
    request: Request,
    x_webhook_secret: str | None = Header(default=None),
):
    try:
        verify_webhook_secret("paddle", x_webhook_secret)
    except HTTPException as exc:
        print(f"WEBHOOK_FAILED provider=paddle detail={exc.detail}", flush=True)
        send_operational_event(
            category="billing",
            event="webhook_failed",
            severity="warning",
            provider="paddle",
            detail=str(exc.detail),
        )
        raise
    payload = await request.json()
    try:
        result = handle_paddle_webhook(payload)
    except Exception as exc:
        print(f"WEBHOOK_FAILED provider=paddle detail={exc}", flush=True)
        send_operational_event(
            category="billing",
            event="webhook_failed",
            severity="critical",
            provider="paddle",
            detail=str(exc),
        )
        raise HTTPException(status_code=500, detail="Webhook processing failed") from exc
    if not result.get("ok"):
        detail = result.get("error", "Invalid webhook payload")
        print(f"WEBHOOK_FAILED provider=paddle detail={detail}", flush=True)
        send_operational_event(
            category="billing",
            event="webhook_failed",
            severity="warning",
            provider="paddle",
            detail=str(detail),
        )
        raise HTTPException(status_code=400, detail=result.get("error", "Invalid webhook payload"))
    return result


@app.post("/billing/webhook/lemon")
async def billing_webhook_lemon(
    request: Request,
    x_webhook_secret: str | None = Header(default=None),
):
    try:
        verify_webhook_secret("lemon", x_webhook_secret)
    except HTTPException as exc:
        print(f"WEBHOOK_FAILED provider=lemon detail={exc.detail}", flush=True)
        send_operational_event(
            category="billing",
            event="webhook_failed",
            severity="warning",
            provider="lemon",
            detail=str(exc.detail),
        )
        raise
    payload = await request.json()
    try:
        result = handle_lemon_webhook(payload)
    except Exception as exc:
        print(f"WEBHOOK_FAILED provider=lemon detail={exc}", flush=True)
        send_operational_event(
            category="billing",
            event="webhook_failed",
            severity="critical",
            provider="lemon",
            detail=str(exc),
        )
        raise HTTPException(status_code=500, detail="Webhook processing failed") from exc
    if not result.get("ok"):
        detail = result.get("error", "Invalid webhook payload")
        print(f"WEBHOOK_FAILED provider=lemon detail={detail}", flush=True)
        send_operational_event(
            category="billing",
            event="webhook_failed",
            severity="warning",
            provider="lemon",
            detail=str(detail),
        )
        raise HTTPException(status_code=400, detail=result.get("error", "Invalid webhook payload"))
    return result


@app.post("/billing/webhook/polar")
async def billing_webhook_polar(request: Request):
    raw_body = await request.body()
    try:
        verify_polar_webhook_or_raise(raw_body, request.headers)
    except HTTPException as exc:
        print(f"WEBHOOK_FAILED provider=polar detail={exc.detail}", flush=True)
        send_operational_event(
            category="billing",
            event="webhook_failed",
            severity="warning",
            provider="polar",
            detail=str(exc.detail),
        )
        raise

    try:
        payload = json.loads(raw_body.decode("utf-8"))
    except Exception:
        print("WEBHOOK_FAILED provider=polar detail=Invalid JSON payload", flush=True)
        send_operational_event(
            category="billing",
            event="webhook_failed",
            severity="warning",
            provider="polar",
            detail="Invalid JSON payload",
        )
        raise HTTPException(status_code=400, detail="Invalid JSON payload")

    try:
        result = handle_polar_webhook(payload)
    except Exception as exc:
        print(f"WEBHOOK_FAILED provider=polar detail={exc}", flush=True)
        send_operational_event(
            category="billing",
            event="webhook_failed",
            severity="critical",
            provider="polar",
            detail=str(exc),
        )
        raise HTTPException(status_code=500, detail="Webhook processing failed") from exc
    if not result.get("ok"):
        detail = result.get("error", "Invalid webhook payload")
        print(f"WEBHOOK_FAILED provider=polar detail={detail}", flush=True)
        send_operational_event(
            category="billing",
            event="webhook_failed",
            severity="warning",
            provider="polar",
            detail=str(detail),
        )
        raise HTTPException(status_code=400, detail=result.get("error", "Invalid webhook payload"))

    return result


@app.post("/billing/webhook/stripe")
async def billing_webhook_stripe(
    request: Request,
    x_webhook_secret: str | None = Header(default=None),
):
    try:
        verify_webhook_secret("stripe", x_webhook_secret)
    except HTTPException as exc:
        print(f"WEBHOOK_FAILED provider=stripe detail={exc.detail}", flush=True)
        send_operational_event(
            category="billing",
            event="webhook_failed",
            severity="warning",
            provider="stripe",
            detail=str(exc.detail),
        )
        raise
    payload = await request.json()
    try:
        result = handle_stripe_webhook(payload)
    except Exception as exc:
        print(f"WEBHOOK_FAILED provider=stripe detail={exc}", flush=True)
        send_operational_event(
            category="billing",
            event="webhook_failed",
            severity="critical",
            provider="stripe",
            detail=str(exc),
        )
        raise HTTPException(status_code=500, detail="Webhook processing failed") from exc
    if not result.get("ok"):
        detail = result.get("error", "Invalid webhook payload")
        print(f"WEBHOOK_FAILED provider=stripe detail={detail}", flush=True)
        send_operational_event(
            category="billing",
            event="webhook_failed",
            severity="warning",
            provider="stripe",
            detail=str(detail),
        )
        raise HTTPException(status_code=400, detail=result.get("error", "Invalid webhook payload"))
    return result
