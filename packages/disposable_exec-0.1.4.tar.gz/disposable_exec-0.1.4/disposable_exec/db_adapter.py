from __future__ import annotations

from collections.abc import Callable, Sequence
from time import perf_counter
from typing import Any, TypeVar

from .db import get_business_conn, get_runtime_conn


T = TypeVar("T")


def _log_runtime_db_timing(*, db_step: str, started_at: float) -> None:
    elapsed_ms = round((perf_counter() - started_at) * 1000, 1)
    print(f"RUNTIME_DB_TIMING db_step={db_step} elapsed_ms={elapsed_ms}", flush=True)


def _log_business_db_timing(*, db_step: str, started_at: float) -> None:
    elapsed_ms = round((perf_counter() - started_at) * 1000, 1)
    print(f"BUSINESS_DB_TIMING db_step={db_step} elapsed_ms={elapsed_ms}", flush=True)


def row_to_dict(row) -> dict[str, Any] | None:
    return dict(row) if row is not None else None


def rows_to_dicts(rows) -> list[dict[str, Any]]:
    return [dict(row) for row in rows]


def fetch_one_business(query: str, params: Sequence[Any] = ()) -> dict[str, Any] | None:
    connect_started_at = perf_counter()
    conn = get_business_conn()
    _log_business_db_timing(db_step="fetch_one_connect", started_at=connect_started_at)
    try:
        execute_started_at = perf_counter()
        row = conn.execute(query, tuple(params)).fetchone()
        _log_business_db_timing(db_step="fetch_one_execute", started_at=execute_started_at)
        return row_to_dict(row)
    finally:
        conn.close()


def fetch_all_business(query: str, params: Sequence[Any] = ()) -> list[dict[str, Any]]:
    connect_started_at = perf_counter()
    conn = get_business_conn()
    _log_business_db_timing(db_step="fetch_all_connect", started_at=connect_started_at)
    try:
        execute_started_at = perf_counter()
        rows = conn.execute(query, tuple(params)).fetchall()
        _log_business_db_timing(db_step="fetch_all_execute", started_at=execute_started_at)
        return rows_to_dicts(rows)
    finally:
        conn.close()


def run_business_transaction(callback: Callable[[Any], T]) -> T:
    connect_started_at = perf_counter()
    conn = get_business_conn()
    _log_business_db_timing(db_step="transaction_connect", started_at=connect_started_at)
    try:
        callback_started_at = perf_counter()
        result = callback(conn)
        _log_business_db_timing(db_step="transaction_callback", started_at=callback_started_at)
        commit_started_at = perf_counter()
        conn.commit()
        _log_business_db_timing(db_step="transaction_commit", started_at=commit_started_at)
        return result
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def fetch_one_runtime(query: str, params: Sequence[Any] = ()) -> dict[str, Any] | None:
    connect_started_at = perf_counter()
    conn = get_runtime_conn()
    _log_runtime_db_timing(db_step="fetch_one_connect", started_at=connect_started_at)
    try:
        execute_started_at = perf_counter()
        row = conn.execute(query, tuple(params)).fetchone()
        _log_runtime_db_timing(db_step="fetch_one_execute", started_at=execute_started_at)
        return row_to_dict(row)
    finally:
        conn.close()


def fetch_all_runtime(query: str, params: Sequence[Any] = ()) -> list[dict[str, Any]]:
    connect_started_at = perf_counter()
    conn = get_runtime_conn()
    _log_runtime_db_timing(db_step="fetch_all_connect", started_at=connect_started_at)
    try:
        execute_started_at = perf_counter()
        rows = conn.execute(query, tuple(params)).fetchall()
        _log_runtime_db_timing(db_step="fetch_all_execute", started_at=execute_started_at)
        return rows_to_dicts(rows)
    finally:
        conn.close()


def run_runtime_transaction(callback: Callable[[Any], T]) -> T:
    connect_started_at = perf_counter()
    conn = get_runtime_conn()
    _log_runtime_db_timing(db_step="transaction_connect", started_at=connect_started_at)
    try:
        callback_started_at = perf_counter()
        result = callback(conn)
        _log_runtime_db_timing(db_step="transaction_callback", started_at=callback_started_at)
        commit_started_at = perf_counter()
        conn.commit()
        _log_runtime_db_timing(db_step="transaction_commit", started_at=commit_started_at)
        return result
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def ping_business_database() -> None:
    conn = get_business_conn()
    try:
        conn.execute("SELECT 1").fetchone()
    finally:
        conn.close()


def ping_runtime_database() -> None:
    conn = get_runtime_conn()
    try:
        conn.execute("SELECT 1").fetchone()
    finally:
        conn.close()


def fetch_one(query: str, params: Sequence[Any] = ()) -> dict[str, Any] | None:
    # Temporary compatibility wrapper for existing runtime-side stores.
    return fetch_one_runtime(query, params)


def fetch_all(query: str, params: Sequence[Any] = ()) -> list[dict[str, Any]]:
    # Temporary compatibility wrapper for existing runtime-side stores.
    return fetch_all_runtime(query, params)


def run_in_transaction(callback: Callable[[Any], T]) -> T:
    # Temporary compatibility wrapper for existing runtime-side stores.
    return run_runtime_transaction(callback)


def ping_database() -> None:
    # Temporary compatibility wrapper for existing runtime-side callers.
    ping_runtime_database()
