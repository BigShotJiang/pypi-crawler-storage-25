import json
import os
from urllib import error, parse, request


class BillingPortalError(Exception):
    def __init__(self, code: str, message: str, status_code: int = 503):
        super().__init__(message)
        self.code = code
        self.message = message
        self.status_code = status_code


def _safe_body_snippet(value: str | bytes | None, limit: int = 240) -> str:
    if value is None:
        return ""
    if isinstance(value, bytes):
        value = value.decode("utf-8", errors="replace")
    text = " ".join(str(value).split())
    return text[:limit]


def _looks_like_api_endpoint_url(url: str | None, api_base: str) -> bool:
    if not url:
        return False
    normalized_url = str(url).strip()
    if not normalized_url:
        return False
    normalized_api_base = (api_base or "").rstrip("/")
    if normalized_api_base and normalized_url.startswith(normalized_api_base + "/v1/"):
        return True
    parsed = parse.urlparse(normalized_url)
    return parsed.path.startswith("/v1/")


def _extract_browser_portal_url(session: dict, api_base: str) -> str | None:
    candidates = [
        session.get("customer_portal_url"),
        session.get("customerPortalUrl"),
        session.get("portal_url"),
        session.get("portalUrl"),
        session.get("url"),
    ]
    data = session.get("data") if isinstance(session.get("data"), dict) else {}
    candidates.extend([
        data.get("customer_portal_url"),
        data.get("customerPortalUrl"),
        data.get("portal_url"),
        data.get("portalUrl"),
        data.get("url"),
    ])
    for candidate in candidates:
        value = (candidate or "").strip()
        if not value:
            continue
        if _looks_like_api_endpoint_url(value, api_base):
            continue
        parsed = parse.urlparse(value)
        if parsed.scheme in {"http", "https"} and parsed.netloc:
            return value
    return None


def _token_fingerprint(token: str | None) -> str:
    value = (token or "").strip()
    if not value:
        return "missing"
    if len(value) <= 8:
        return value
    return f"{value[:4]}...{value[-4:]}"


def get_polar_config() -> dict:
    env = (os.getenv("POLAR_ENV", "live") or "live").strip().lower()
    if env not in {"live", "sandbox"}:
        raise RuntimeError("POLAR_ENV must be either 'live' or 'sandbox'")

    default_api_base = "https://sandbox-api.polar.sh" if env == "sandbox" else "https://api.polar.sh"
    webhook_secret = (
        os.getenv("POLAR_WEBHOOK_SECRET", "").strip()
        or os.getenv("DISPOSABLE_EXEC_POLAR_WEBHOOK_SECRET", "").strip()
    )

    return {
        "env": env,
        "api_base": (os.getenv("POLAR_API_BASE", "").strip() or default_api_base).rstrip("/"),
        "access_token": os.getenv("POLAR_ACCESS_TOKEN", "").strip(),
        "webhook_secret": webhook_secret,
    }


def validate_polar_config(*, require_access_token: bool = False, require_webhook_secret: bool = False) -> dict:
    config = get_polar_config()
    missing = []

    if require_access_token and not config["access_token"]:
        missing.append("POLAR_ACCESS_TOKEN")
    if require_webhook_secret and not config["webhook_secret"]:
        missing.append("POLAR_WEBHOOK_SECRET")

    if missing:
        raise RuntimeError(f"Missing required Polar config: {', '.join(missing)}")

    return config


def normalize_plan(plan_value: str) -> str:
    plan = (plan_value or "").strip().lower()

    mapping = {
        "free": "Free",
        "starter": "Starter",
        "pro": "Pro",
        "scale": "Scale",
    }
    return mapping.get(plan, "Free")


def normalize_status(status_value: str) -> str:
    status = (status_value or "").strip().lower()

    if status in {"active", "trialing", "paid"}:
        return "active"
    if status in {"canceled", "cancelled"}:
        return "canceled"
    if status in {"past_due", "paused", "unpaid"}:
        return "past_due"
    return "active"


def extract_billing_event(provider: str, payload: dict) -> dict:
    provider = (provider or "").strip().lower()

    if provider == "paddle":
        data = payload.get("data", {})
        return {
            "provider": "paddle",
            "event_type": payload.get("event_type", "unknown"),
            "email": data.get("email") or data.get("customer_email") or "unknown@example.com",
            "provider_subscription_id": data.get("subscription_id") or data.get("id") or "unknown",
            "plan": normalize_plan(data.get("plan") or "Free"),
            "status": normalize_status(data.get("status") or "active"),
        }

    if provider == "lemon":
        data = payload.get("data", {})
        attrs = data.get("attributes", {})
        return {
            "provider": "lemon",
            "event_type": payload.get("meta", {}).get("event_name", "unknown"),
            "email": attrs.get("user_email") or attrs.get("customer_email") or "unknown@example.com",
            "provider_subscription_id": str(data.get("id") or "unknown"),
            "plan": normalize_plan(attrs.get("product_name") or attrs.get("variant_name") or "Free"),
            "status": normalize_status(attrs.get("status") or "active"),
        }

    if provider == "polar":
        data = payload.get("data", {})
        customer = data.get("customer", {}) if isinstance(data.get("customer"), dict) else {}
        return {
            "provider": "polar",
            "event_type": payload.get("type", "unknown"),
            "email": data.get("customer_email") or data.get("email") or "unknown@example.com",
            "provider_subscription_id": str(data.get("subscription_id") or data.get("id") or "unknown"),
            "provider_customer_id": str(data.get("customer_id") or customer.get("id") or "unknown"),
            "plan": normalize_plan(data.get("plan") or data.get("product") or "Free"),
            "status": normalize_status(data.get("status") or "active"),
        }

    if provider == "stripe":
        data = payload.get("data", {}).get("object", {})
        return {
            "provider": "stripe",
            "event_type": payload.get("type", "unknown"),
            "email": data.get("customer_email") or "unknown@example.com",
            "provider_subscription_id": str(data.get("id") or "unknown"),
            "plan": normalize_plan(data.get("plan", {}).get("nickname") or "Free"),
            "status": normalize_status(data.get("status") or "active"),
        }

    raise ValueError(f"Unsupported billing provider: {provider}")


def _json_request(
    method: str,
    url: str,
    token: str,
    payload: dict | None = None,
    request_label: str = "provider_request",
    retry_count: int = 0,
) -> dict:
    body = None
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
        "User-Agent": "DisposableExec/1.0",
    }
    if payload is not None:
        body = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"

    req = request.Request(url, data=body, headers=headers, method=method)
    print(
        f"BILLING_PORTAL_PROVIDER_REQUEST label={request_label} method={method} url={url}",
        flush=True,
    )
    try:
        with request.urlopen(req, timeout=15) as response:
            raw = response.read().decode("utf-8")
            final_url = response.geturl()
            status_code = getattr(response, "status", None) or response.getcode()
            location = response.headers.get("Location") if response.headers else None
            print(
                "BILLING_PORTAL_PROVIDER_RESPONSE "
                f"label={request_label} status={status_code} final_url={final_url} "
                f"location={location or ''} body_snippet={_safe_body_snippet(raw)!r}",
                flush=True,
            )
            if raw:
                try:
                    return json.loads(raw)
                except json.JSONDecodeError:
                    if final_url and final_url != url:
                        print(
                            f"BILLING_PORTAL_PROVIDER_REDIRECT label={request_label} final_url={final_url}",
                            flush=True,
                        )
                        return {"redirect_location": final_url}
            if final_url and final_url != url:
                print(
                    f"BILLING_PORTAL_PROVIDER_REDIRECT label={request_label} final_url={final_url}",
                    flush=True,
                )
                return {"redirect_location": final_url}
            return {}
    except error.HTTPError as exc:
        location = exc.headers.get("Location") if exc.headers else None
        if location and 300 <= exc.code < 400:
            resolved_location = parse.urljoin(url, location)
            print(
                f"BILLING_PORTAL_PROVIDER_REDIRECT label={request_label} code={exc.code} location={resolved_location}",
                flush=True,
            )
            if request_label == "polar_customer_session_create" and retry_count < 1:
                return _json_request(
                    method,
                    resolved_location,
                    token,
                    payload=payload,
                    request_label=request_label,
                    retry_count=retry_count + 1,
                )
            return {
                "redirect_location": resolved_location,
            }
        raw = exc.read().decode("utf-8", errors="replace")
        try:
            data = json.loads(raw) if raw else {}
        except json.JSONDecodeError:
            data = {}
        detail = data.get("detail") or data.get("error_description") or data.get("error") or raw or exc.reason
        print(
            "BILLING_PORTAL_PROVIDER_HTTP_ERROR "
            f"label={request_label} status={exc.code} location={location or ''} "
            f"detail={_safe_body_snippet(detail)!r} body_snippet={_safe_body_snippet(raw)!r}",
            flush=True,
        )
        if request_label == "polar_subscription_lookup" and exc.code == 404:
            raise BillingPortalError(
                code="billing_portal_unavailable",
                message="Billing portal is not available for this subscription yet.",
                status_code=404,
            ) from exc
        if exc.code in {401, 403}:
            provider_status_code = 503
        elif exc.code == 404:
            provider_status_code = 404
        elif exc.code >= 500:
            provider_status_code = 503
        else:
            provider_status_code = 502
        print(
            f"BILLING_PORTAL_PROVIDER_NON_200 label={request_label} code={exc.code} detail={detail}",
            flush=True,
        )
        raise BillingPortalError(
            code="billing_portal_unavailable",
            message=f"Billing portal is not available for this subscription yet. Provider error: {detail}",
            status_code=provider_status_code,
        ) from exc
    except error.URLError as exc:
        print(
            f"BILLING_PORTAL_PROVIDER_CONNECTION_ERROR label={request_label} detail={exc.reason}",
            flush=True,
        )
        raise BillingPortalError(
            code="billing_portal_unavailable",
            message="Billing portal is not available for this subscription yet. Provider connection failed.",
            status_code=503,
        ) from exc
    except Exception as exc:
        print(
            f"BILLING_PORTAL_PROVIDER_EXCEPTION label={request_label} exception_class={exc.__class__.__name__} detail={exc}",
            flush=True,
        )
        raise


def create_billing_portal_session(
    provider: str,
    provider_subscription_id: str,
    provider_customer_id: str | None = None,
    return_url: str | None = None,
) -> dict:
    provider = (provider or "").strip().lower()
    provider_subscription_id = (provider_subscription_id or "").strip()
    provider_customer_id = (provider_customer_id or "").strip()

    if not provider_customer_id and not provider_subscription_id:
        print(
            "BILLING_PORTAL_MISSING_SUBSCRIPTION_MAPPING "
            f"provider={provider} subscription_id={provider_subscription_id or ''} customer_id={provider_customer_id or ''}",
            flush=True,
        )
        raise BillingPortalError(
            code="billing_portal_unavailable",
            message="Billing portal is not available for this subscription yet.",
            status_code=404,
        )

    if provider != "polar":
        raise BillingPortalError(
            code="billing_portal_unavailable",
            message="Billing portal is not available for this subscription yet.",
            status_code=501,
        )

    try:
        polar_config = validate_polar_config(require_access_token=True)
    except RuntimeError as exc:
        raise BillingPortalError(
            code="billing_portal_unavailable",
            message=f"Billing portal is not available for this subscription yet. {exc}",
            status_code=503,
        ) from exc

    access_token = polar_config["access_token"]
    api_base = polar_config["api_base"]
    account_return_url = (
        return_url
        or os.getenv("DISPOSABLE_EXEC_ACCOUNT_RETURN_URL", "").strip()
        or "https://www.disposable-exec.com/account.html"
    )

    customer_id = provider_customer_id
    print(
        "BILLING_PORTAL_CREATE_START "
        f"provider={provider} subscription_id={provider_subscription_id} customer_id={customer_id or ''} api_base={api_base}",
        flush=True,
    )
    if not customer_id and provider_subscription_id:
        subscription = _json_request(
            "GET",
            f"{api_base}/v1/subscriptions/{parse.quote(provider_subscription_id, safe='')}",
            access_token,
            request_label="polar_subscription_lookup",
        )
        customer_id = subscription.get("customer_id")
        if not customer_id and isinstance(subscription.get("customer"), dict):
            customer_id = subscription["customer"].get("id")
        print(
            "BILLING_PORTAL_SUBSCRIPTION_LOOKUP_RESULT "
            f"provider={provider} subscription_id={provider_subscription_id} customer_id={customer_id or ''}",
            flush=True,
        )

    if not customer_id:
        print(
            f"BILLING_PORTAL_MISSING_CUSTOMER_MAPPING provider={provider} subscription_id={provider_subscription_id}",
            flush=True,
        )
        raise BillingPortalError(
            code="billing_portal_unavailable",
            message="Billing portal is not available for this subscription yet.",
            status_code=503,
        )

    print(
        "BILLING_PORTAL_TOKEN_FINGERPRINT "
        f"env={polar_config['env']} api_base={api_base} token={_token_fingerprint(access_token)}",
        flush=True,
    )
    session = _json_request(
        "POST",
        f"{api_base}/v1/customer-sessions/",
        access_token,
        {
            "customer_id": customer_id,
            "return_url": account_return_url,
        },
        request_label="polar_customer_session_create",
    )
    print(
        "BILLING_PORTAL_SESSION_RESPONSE "
        f"provider={provider} subscription_id={provider_subscription_id} customer_id={customer_id} "
        f"response_keys={sorted(session.keys())} body_snippet={_safe_body_snippet(json.dumps(session))!r}",
        flush=True,
    )
    portal_url = _extract_browser_portal_url(session, api_base)
    if not portal_url:
        print(
            "BILLING_PORTAL_MISSING_PORTAL_URL "
            f"provider={provider} subscription_id={provider_subscription_id} customer_id={customer_id} "
            f"body_snippet={_safe_body_snippet(json.dumps(session))!r}",
            flush=True,
        )
        raise BillingPortalError(
            code="billing_portal_unavailable",
            message="Billing portal is not available for this subscription yet.",
            status_code=503,
        )

    print(
        "BILLING_PORTAL_CREATE_SUCCESS "
        f"provider={provider} subscription_id={provider_subscription_id} customer_id={customer_id} portal_url={portal_url}",
        flush=True,
    )

    return {
        "provider": provider,
        "provider_subscription_id": provider_subscription_id,
        "customer_id": customer_id,
        "portal_url": portal_url,
    }


def fetch_polar_subscription(provider_subscription_id: str) -> dict:
    provider_subscription_id = (provider_subscription_id or "").strip()
    polar_config = validate_polar_config(require_access_token=True)
    return _json_request(
        "GET",
        f"{polar_config['api_base']}/v1/subscriptions/{parse.quote(provider_subscription_id, safe='')}",
        polar_config["access_token"],
        request_label="polar_subscription_lookup",
    )
