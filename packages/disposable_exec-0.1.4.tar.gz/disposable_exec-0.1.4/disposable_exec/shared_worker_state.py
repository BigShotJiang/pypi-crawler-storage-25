from __future__ import annotations

import json
import os
import threading
from datetime import datetime
from time import monotonic, perf_counter

from .db import get_app_state, set_app_state
from .redis_connection import create_redis_client


class SharedWorkerStateUnavailable(RuntimeError):
    pass


_SHARED_WORKERS_CACHE_LOCK = threading.Lock()
_SHARED_WORKERS_CACHE_ROWS: list[dict] | None = None
_SHARED_WORKERS_CACHE_AT = 0.0
_SHARED_WORKER_BY_ID_CACHE: dict[str, tuple[float, dict]] = {}
_LOCAL_WORKER_APP_STATE_PREFIX = "worker_snapshot:"
_SHARED_WORKERS_LIST_APP_STATE_KEY = "shared_workers:list"


def _log_shared_worker_timing(*, worker_step: str, started_at: float, worker_id: str | None = None) -> None:
    elapsed_ms = round((perf_counter() - started_at) * 1000, 1)
    print(
        f"SHARED_WORKER_TIMING worker_id={worker_id or ''} worker_step={worker_step} elapsed_ms={elapsed_ms}",
        flush=True,
    )


def _is_truthy(value: str | None) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def is_shared_worker_backing_enabled() -> bool:
    return _is_truthy(
        os.getenv("DISPOSABLE_EXEC_SHARED_WORKER_STATE_ENABLED")
        or os.getenv("SHARED_WORKER_STATE_ENABLED")
    )


def _get_prefix() -> str:
    return (
        os.getenv("DISPOSABLE_EXEC_SHARED_WORKER_STATE_PREFIX", "").strip()
        or "disposable_exec:shared_worker_state"
    )


def _workers_set_key() -> str:
    return f"{_get_prefix()}:workers"


def _worker_key(worker_id: str) -> str:
    return f"{_get_prefix()}:worker:{worker_id}"


def _worker_auth_key(token_hash: str) -> str:
    return f"{_get_prefix()}:auth:{token_hash}"


def _app_state_key(key: str) -> str:
    return f"{_get_prefix()}:app_state:{key}"


def _decode_text(value) -> str | None:
    if value is None:
        return None
    if isinstance(value, bytes):
        return value.decode("utf-8")
    return str(value)


def _decode_json_dict(value) -> dict | None:
    text = _decode_text(value)
    if not text:
        return None
    return json.loads(text)


def _get_client():
    try:
        return create_redis_client()
    except Exception as exc:
        raise SharedWorkerStateUnavailable(str(exc)) from exc


def _shared_workers_cache_ttl_seconds() -> float:
    try:
        return max(
            0.0,
            float(
                os.getenv("DISPOSABLE_EXEC_SHARED_WORKERS_CACHE_TTL_SECONDS", "").strip()
                or os.getenv("SHARED_WORKERS_CACHE_TTL_SECONDS", "").strip()
                or "30"
            ),
        )
    except ValueError:
        return 30.0


def _get_cached_shared_worker(worker_id: str) -> dict | None:
    ttl_seconds = _shared_workers_cache_ttl_seconds()
    now = monotonic()
    with _SHARED_WORKERS_CACHE_LOCK:
        cached = _SHARED_WORKER_BY_ID_CACHE.get(worker_id)
        if cached and ttl_seconds > 0 and (now - cached[0]) <= ttl_seconds:
            return dict(cached[1])
        if (
            not worker_id
            or _SHARED_WORKERS_CACHE_ROWS is None
            or ttl_seconds <= 0
            or (now - _SHARED_WORKERS_CACHE_AT) > ttl_seconds
        ):
            return None
        for row in _SHARED_WORKERS_CACHE_ROWS:
            if str(row.get("id") or "").strip() == worker_id:
                _SHARED_WORKER_BY_ID_CACHE[worker_id] = (monotonic(), dict(row))
                return dict(row)
    return None


def _safe_get(key: str):
    try:
        return _get_client().get(key)
    except Exception as exc:
        raise SharedWorkerStateUnavailable(str(exc)) from exc


def _set_local_shared_workers_snapshot(rows: list[dict]) -> None:
    try:
        set_app_state(
            _SHARED_WORKERS_LIST_APP_STATE_KEY,
            json.dumps(rows, separators=(",", ":"), sort_keys=True),
        )
    except Exception:
        # This mirror is an optimization for multi-process API reads. A local
        # app_state write failure should not break worker-state truth.
        return


def _get_local_shared_workers_snapshot() -> list[dict] | None:
    try:
        row = get_app_state(_SHARED_WORKERS_LIST_APP_STATE_KEY)
    except Exception:
        return None
    if not row or not row.get("value"):
        return None
    try:
        payload = json.loads(row["value"])
    except (TypeError, ValueError, json.JSONDecodeError):
        return None
    if not isinstance(payload, list):
        return None
    items: list[dict] = []
    for item in payload:
        if isinstance(item, dict):
            items.append(dict(item))
    return items


def _get_worker_from_local_shared_workers_snapshot(worker_id: str) -> dict | None:
    if not worker_id:
        return None
    rows = _get_local_shared_workers_snapshot()
    if not rows:
        return None
    for row in rows:
        if str(row.get("id") or "").strip() == worker_id:
            return dict(row)
    return None


def _refresh_in_process_shared_workers_cache(rows: list[dict]) -> None:
    global _SHARED_WORKERS_CACHE_ROWS, _SHARED_WORKERS_CACHE_AT
    with _SHARED_WORKERS_CACHE_LOCK:
        _SHARED_WORKERS_CACHE_ROWS = [dict(row) for row in rows]
        _SHARED_WORKERS_CACHE_AT = monotonic()
        _SHARED_WORKER_BY_ID_CACHE.clear()
        for row in rows:
            worker_id = str(row.get("id") or "").strip()
            if worker_id:
                _SHARED_WORKER_BY_ID_CACHE[worker_id] = (_SHARED_WORKERS_CACHE_AT, dict(row))


def get_shared_worker(worker_id: str) -> dict | None:
    if not worker_id:
        return None
    cached_started_at = perf_counter()
    cached = _get_cached_shared_worker(worker_id)
    _log_shared_worker_timing(worker_id=worker_id, worker_step="in_process_cache_lookup", started_at=cached_started_at)
    if cached is not None:
        return cached
    shared_lookup_error: SharedWorkerStateUnavailable | None = None
    shared_worker_started_at = perf_counter()
    row = None
    try:
        row = _decode_json_dict(_safe_get(_worker_key(worker_id)))
    except SharedWorkerStateUnavailable as exc:
        shared_lookup_error = exc
    _log_shared_worker_timing(worker_id=worker_id, worker_step="shared_worker_key_lookup", started_at=shared_worker_started_at)
    if row:
        with _SHARED_WORKERS_CACHE_LOCK:
            _SHARED_WORKER_BY_ID_CACHE[worker_id] = (monotonic(), dict(row))
        return row
    shared_snapshot_started_at = perf_counter()
    snapshot = None
    try:
        snapshot = get_shared_app_state(f"{_LOCAL_WORKER_APP_STATE_PREFIX}{worker_id}")
    except SharedWorkerStateUnavailable as exc:
        if shared_lookup_error is None:
            shared_lookup_error = exc
    _log_shared_worker_timing(
        worker_id=worker_id,
        worker_step="shared_app_state_snapshot_lookup",
        started_at=shared_snapshot_started_at,
    )
    if snapshot and snapshot.get("value"):
        row = _decode_json_dict(snapshot.get("value"))
        if row:
            with _SHARED_WORKERS_CACHE_LOCK:
                _SHARED_WORKER_BY_ID_CACHE[worker_id] = (monotonic(), dict(row))
            return row
    local_list_started_at = perf_counter()
    local_list_worker = _get_worker_from_local_shared_workers_snapshot(worker_id)
    _log_shared_worker_timing(
        worker_id=worker_id,
        worker_step="local_app_state_list_member_lookup",
        started_at=local_list_started_at,
    )
    if local_list_worker is not None:
        with _SHARED_WORKERS_CACHE_LOCK:
            _SHARED_WORKER_BY_ID_CACHE[worker_id] = (monotonic(), dict(local_list_worker))
        return local_list_worker
    if shared_lookup_error is not None:
        raise shared_lookup_error
    return None


def list_shared_workers() -> list[dict]:
    global _SHARED_WORKERS_CACHE_ROWS, _SHARED_WORKERS_CACHE_AT
    ttl_seconds = _shared_workers_cache_ttl_seconds()
    now = monotonic()
    cache_lookup_started_at = perf_counter()
    with _SHARED_WORKERS_CACHE_LOCK:
        if (
            _SHARED_WORKERS_CACHE_ROWS is not None
            and ttl_seconds > 0
            and (now - _SHARED_WORKERS_CACHE_AT) <= ttl_seconds
        ):
            _log_shared_worker_timing(worker_step="list_cache_lookup", started_at=cache_lookup_started_at)
            _log_shared_worker_timing(worker_step="list_shared_workers_total", started_at=cache_lookup_started_at)
            return [dict(row) for row in _SHARED_WORKERS_CACHE_ROWS]
    _log_shared_worker_timing(worker_step="list_cache_lookup", started_at=cache_lookup_started_at)
    shared_lookup_error: SharedWorkerStateUnavailable | None = None
    try:
        client = _get_client()
        smembers_started_at = perf_counter()
        worker_ids = client.smembers(_workers_set_key()) or set()
        _log_shared_worker_timing(worker_step="workers_smembers", started_at=smembers_started_at)
        keys = [_worker_key(_decode_text(raw_worker_id)) for raw_worker_id in worker_ids if _decode_text(raw_worker_id)]
        if not keys:
            with _SHARED_WORKERS_CACHE_LOCK:
                _SHARED_WORKERS_CACHE_ROWS = []
                _SHARED_WORKERS_CACHE_AT = monotonic()
            _set_local_shared_workers_snapshot([])
            _log_shared_worker_timing(worker_step="list_shared_workers_total", started_at=cache_lookup_started_at)
            return []
        mget_started_at = perf_counter()
        values = client.mget(keys)
        _log_shared_worker_timing(worker_step="workers_mget", started_at=mget_started_at)
    except Exception as exc:
        shared_lookup_error = SharedWorkerStateUnavailable(str(exc))

    if shared_lookup_error is None:
        items: list[dict] = []
        decode_started_at = perf_counter()
        for value in values or []:
            row = _decode_json_dict(value)
            if row:
                items.append(row)
        _log_shared_worker_timing(worker_step="workers_decode", started_at=decode_started_at)
        _refresh_in_process_shared_workers_cache(items)
        _set_local_shared_workers_snapshot(items)
        _log_shared_worker_timing(worker_step="list_shared_workers_total", started_at=cache_lookup_started_at)
        return items

    local_snapshot_started_at = perf_counter()
    local_snapshot_rows = _get_local_shared_workers_snapshot()
    _log_shared_worker_timing(worker_step="local_app_state_list_lookup", started_at=local_snapshot_started_at)
    if local_snapshot_rows is not None:
        _refresh_in_process_shared_workers_cache(local_snapshot_rows)
        _log_shared_worker_timing(worker_step="list_shared_workers_total", started_at=cache_lookup_started_at)
        return [dict(row) for row in local_snapshot_rows]
    raise shared_lookup_error


def warm_shared_workers_cache() -> list[dict]:
    started_at = perf_counter()
    rows = list_shared_workers()
    _log_shared_worker_timing(worker_step="warm_shared_workers_cache_total", started_at=started_at)
    return rows


def _update_shared_workers_cache_row(worker: dict) -> None:
    global _SHARED_WORKERS_CACHE_ROWS, _SHARED_WORKERS_CACHE_AT
    with _SHARED_WORKERS_CACHE_LOCK:
        if _SHARED_WORKERS_CACHE_ROWS is None:
            return
        worker_id = str(worker.get("id") or "").strip()
        if not worker_id:
            return
        updated = False
        rows = [dict(row) for row in _SHARED_WORKERS_CACHE_ROWS]
        for index, row in enumerate(rows):
            if str(row.get("id") or "").strip() == worker_id:
                rows[index] = dict(worker)
                updated = True
                break
        if not updated:
            rows.append(dict(worker))
        _SHARED_WORKERS_CACHE_ROWS = rows
        _SHARED_WORKERS_CACHE_AT = monotonic()
        if worker_id:
            _SHARED_WORKER_BY_ID_CACHE[worker_id] = (_SHARED_WORKERS_CACHE_AT, dict(worker))
            if worker_id == (os.getenv("DISPOSABLE_EXEC_WORKER_ID", "local-worker").strip() or "local-worker"):
                try:
                    set_shared_app_state(
                        f"{_LOCAL_WORKER_APP_STATE_PREFIX}{worker_id}",
                        json.dumps(dict(worker), separators=(",", ":"), sort_keys=True),
                    )
                except SharedWorkerStateUnavailable:
                    pass
        snapshot_rows = [dict(row) for row in _SHARED_WORKERS_CACHE_ROWS]
    _set_local_shared_workers_snapshot(snapshot_rows)


def get_shared_worker_by_auth_token_hash(token_hash: str) -> dict | None:
    if not token_hash:
        return None
    worker_id = _decode_text(_safe_get(_worker_auth_key(token_hash)))
    if not worker_id:
        return None
    return get_shared_worker(worker_id)


def upsert_shared_worker(worker: dict) -> dict:
    worker_id = str(worker.get("id") or "").strip()
    if not worker_id:
        raise ValueError("worker id is required")

    client = _get_client()
    existing = get_shared_worker(worker_id) or {}
    previous_auth_hash = str(existing.get("auth_token_hash") or "").strip()
    next_auth_hash = str(worker.get("auth_token_hash") or "").strip()

    serialized = json.dumps(worker, separators=(",", ":"), sort_keys=True)
    try:
        client.set(_worker_key(worker_id), serialized)
        client.sadd(_workers_set_key(), worker_id)

        if previous_auth_hash and previous_auth_hash != next_auth_hash:
            current_mapping = _decode_text(client.get(_worker_auth_key(previous_auth_hash)))
            if current_mapping == worker_id:
                client.delete(_worker_auth_key(previous_auth_hash))
        if next_auth_hash:
            client.set(_worker_auth_key(next_auth_hash), worker_id)
    except Exception as exc:
        raise SharedWorkerStateUnavailable(str(exc)) from exc
    _update_shared_workers_cache_row(worker)

    return worker


def set_shared_app_state(key: str, value: str) -> None:
    payload = {
        "key": key,
        "value": value,
        "updated_at": datetime.utcnow().isoformat() + "Z",
    }
    try:
        client = _get_client()
        client.set(_app_state_key(key), json.dumps(payload, separators=(",", ":"), sort_keys=True))
    except Exception as exc:
        raise SharedWorkerStateUnavailable(str(exc)) from exc


def get_shared_app_state(key: str) -> dict | None:
    return _decode_json_dict(_safe_get(_app_state_key(key)))
