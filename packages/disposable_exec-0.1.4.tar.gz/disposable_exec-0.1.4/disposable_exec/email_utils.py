import smtplib
from email.message import EmailMessage
from os import getenv


VALID_FREE_EMAIL_MODES = {"dev", "smtp"}


def parse_bool_env(name: str, default: bool = False) -> bool:
    value = (getenv(name) or "").strip().lower()
    if not value:
        return default
    return value in {"1", "true", "yes", "on"}


def get_free_email_mode() -> str:
    mode = (getenv("FREE_EMAIL_MODE") or "dev").strip().lower()
    if mode not in VALID_FREE_EMAIL_MODES:
        raise RuntimeError("FREE_EMAIL_MODE must be one of: dev, smtp")
    return mode


def get_smtp_settings() -> dict:
    host = (getenv("SMTP_HOST") or "").strip()
    port_raw = (getenv("SMTP_PORT") or "").strip()
    username = (getenv("SMTP_USERNAME") or "").strip()
    password = getenv("SMTP_PASSWORD") or ""
    from_email = (getenv("SMTP_FROM_EMAIL") or "").strip()
    from_name = (getenv("SMTP_FROM_NAME") or "").strip()
    starttls = parse_bool_env("SMTP_STARTTLS", default=True)

    if not host:
        raise RuntimeError("SMTP_HOST is required in smtp mode")
    if not port_raw:
        raise RuntimeError("SMTP_PORT is required in smtp mode")
    try:
        port = int(port_raw)
    except ValueError as exc:
        raise RuntimeError("SMTP_PORT must be a valid integer") from exc
    if not from_email:
        raise RuntimeError("SMTP_FROM_EMAIL is required in smtp mode")
    if bool(username) != bool(password):
        raise RuntimeError("SMTP_USERNAME and SMTP_PASSWORD must both be set when using SMTP auth")

    return {
        "host": host,
        "port": port,
        "username": username,
        "password": password,
        "from_email": from_email,
        "from_name": from_name,
        "starttls": starttls,
    }


def build_from_header(from_email: str, from_name: str) -> str:
    if not from_name:
        return from_email
    return f"{from_name} <{from_email}>"


def send_free_verification_code_email(to_email: str, code: str, expires_in_seconds: int):
    settings = get_smtp_settings()
    expires_in_minutes = max(expires_in_seconds // 60, 1)

    message = EmailMessage()
    message["Subject"] = "Your Disposable-exec verification code"
    message["From"] = build_from_header(settings["from_email"], settings["from_name"])
    message["To"] = to_email
    message.set_content(
        "\n".join(
            [
                "Your Disposable-exec verification code is:",
                "",
                code,
                "",
                f"This code expires in {expires_in_minutes} minutes.",
                "If you did not request this code, you can ignore this email.",
            ]
        )
    )

    with smtplib.SMTP(settings["host"], settings["port"], timeout=20) as smtp:
        smtp.ehlo()
        if settings["starttls"]:
            smtp.starttls()
            smtp.ehlo()
        if settings["username"]:
            smtp.login(settings["username"], settings["password"])
        smtp.send_message(message)
