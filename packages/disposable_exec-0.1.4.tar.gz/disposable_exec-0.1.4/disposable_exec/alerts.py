import argparse
import json
import os
import threading
from urllib import error, request


def get_telegram_config() -> dict:
    return {
        "bot_token": os.getenv("TELEGRAM_BOT_TOKEN", "").strip(),
        "chat_id": os.getenv("TELEGRAM_CHAT_ID", "").strip(),
    }


def _send_telegram_message(message: str):
    config = get_telegram_config()
    if not config["bot_token"] or not config["chat_id"] or not message:
        return

    url = f"https://api.telegram.org/bot{config['bot_token']}/sendMessage"
    payload = json.dumps(
        {
            "chat_id": config["chat_id"],
            "text": message[:4000],
            "disable_web_page_preview": True,
        }
    ).encode("utf-8")
    req = request.Request(
        url,
        data=payload,
        headers={"Content-Type": "application/json", "Accept": "application/json"},
        method="POST",
    )
    try:
        with request.urlopen(req, timeout=3):
            return
    except (error.URLError, error.HTTPError, TimeoutError) as exc:
        print(f"TELEGRAM_ALERT_SEND_FAILED detail={exc}", flush=True)


def send_telegram_alert_async(message: str):
    thread = threading.Thread(target=_send_telegram_message, args=(message,), daemon=True)
    thread.start()


def send_telegram_alert(message: str, *, asynchronous: bool = True):
    if asynchronous:
        send_telegram_alert_async(message)
    else:
        _send_telegram_message(message)


def send_admin_metrics_scheduled_summary(snapshot: dict | None = None, *, asynchronous: bool = True) -> dict:
    from disposable_exec.metrics import build_admin_metrics_scheduled_summary, get_admin_metrics

    current_snapshot = snapshot or get_admin_metrics()
    send_telegram_alert(build_admin_metrics_scheduled_summary(current_snapshot), asynchronous=asynchronous)
    return current_snapshot


def _parse_detail_fields(detail: str) -> dict[str, str]:
    fields: dict[str, str] = {}
    for part in str(detail or "").split():
        if "=" not in part:
            continue
        key, value = part.split("=", 1)
        fields[key.strip()] = value.strip()
    return fields


def _severity_title(severity: str) -> str:
    normalized = str(severity or "").strip().lower()
    if normalized == "critical":
        return "Disposable-exec Critical"
    if normalized == "warning":
        return "Disposable-exec Warning"
    return "Disposable-exec Event"


def _humanize_event_name(event: str) -> str:
    return str(event or "").replace("_", " ").strip() or "unknown event"


def _human_detail(detail: str, fields: dict[str, str]) -> str:
    if fields.get("detail"):
        return fields["detail"]
    return str(detail or "").strip() or "No detail provided"


def _context_line(
    *,
    category: str,
    provider: str | None,
    user_id: str | None,
    subscription_id: str | None,
    worker_id: str | None,
    execution_id: str | None,
) -> str:
    parts: list[str] = []
    if user_id:
        parts.append(f"用户: {user_id}")
    if worker_id:
        parts.append(f"Worker: {worker_id}")
    if execution_id:
        parts.append(f"执行: {execution_id}")
    if provider:
        parts.append(f"Provider: {provider}")
    if subscription_id:
        parts.append(f"订阅: {subscription_id}")
    if parts:
        return " | ".join(parts)
    if category == "onboarding":
        return "范围: onboarding/account recovery"
    if category == "billing":
        return "范围: billing/webhook"
    if category == "execution":
        return "范围: execution path"
    if category == "worker":
        return "范围: worker health"
    if category == "health":
        return "范围: service health"
    return "范围: operational event"


def _suggested_action(category: str, event: str) -> str:
    if event == "api_key_reissue_failed":
        return "动作: 检查用户现有 API key 状态与数据库插入错误"
    if event.startswith("auto_claim_"):
        return "动作: 检查订阅状态、onboarding 会话/令牌与最近服务日志"
    if event == "webhook_failed":
        return "动作: 检查 webhook 签名、payload 与 provider 侧重试情况"
    if event == "db_down":
        return "动作: 立即检查数据库可用性与磁盘空间"
    if event == "heartbeat_stale":
        return "动作: 检查 worker 进程、心跳与最近 worker 日志"
    if category == "execution":
        return "动作: 检查最近执行日志与队列/worker 状态"
    return "动作: 检查最近服务日志并确认是否需要人工恢复"


def _build_operational_event_message(
    *,
    category: str,
    event: str,
    severity: str,
    detail: str,
    provider: str | None = None,
    user_id: str | None = None,
    subscription_id: str | None = None,
    worker_id: str | None = None,
    execution_id: str | None = None,
) -> str | None:
    fields = _parse_detail_fields(detail)

    if category == "execution" and event == "active_execution_backpressure_reject":
        current = fields.get("active_execution_count", "?")
        threshold = fields.get("threshold", "?")
        return "\n".join(
            [
                _severity_title(severity),
                "并发上限保护已触发",
                f"当前运行中任务: {current} / 上限: {threshold}",
                "动作: 降低并发提交，或检查任务持续时间与 worker 容量",
            ]
        )

    if category == "execution" and event == "queue_backpressure_reject":
        queue_depth = fields.get("queue_depth", "?")
        threshold = fields.get("threshold", "?")
        return "\n".join(
            [
                _severity_title(severity),
                "队列积压保护已触发",
                f"当前队列深度: {queue_depth} / 阈值: {threshold}",
                "动作: 降低提交速率，并检查队列积压与 worker 吞吐",
            ]
        )

    if category == "execution" and event == "enqueue_failed":
        event_execution_id = execution_id or fields.get("execution_id")
        state_line = (
            f"执行: {event_execution_id}"
            if event_execution_id
            else f"原因: {_human_detail(detail, fields)}"
        )
        return "\n".join(
            [
                _severity_title(severity),
                "任务入队失败",
                state_line,
                "动作: 检查队列连接、Redis 状态与最近 API 日志",
            ]
        )

    if category == "execution" and event == "user_concurrency_limit_reject":
        plan = fields.get("plan", "?")
        current = fields.get("occupied_slots", "?")
        limit = fields.get("limit", "?")
        return "\n".join(
            [
                _severity_title(severity),
                "用户并发上限已触发",
                f"套餐: {plan} | 当前占用槽位: {current} / 上限: {limit}",
                "动作: 等待排队/运行中的任务完成，或升级套餐以提高并发上限",
            ]
        )

    if category == "onboarding" and event == "api_key_reissue_failed":
        return "\n".join(
            [
                _severity_title(severity),
                "API Key 补发失败",
                _context_line(
                    category=category,
                    provider=provider,
                    user_id=user_id,
                    subscription_id=subscription_id,
                    worker_id=worker_id,
                    execution_id=execution_id,
                ),
                f"原因: {_human_detail(detail, fields)}",
                _suggested_action(category, event),
            ]
        )

    if category == "onboarding" and event.startswith("auto_claim_"):
        return "\n".join(
            [
                _severity_title(severity),
                "Onboarding 自动恢复异常",
                _context_line(
                    category=category,
                    provider=provider,
                    user_id=user_id,
                    subscription_id=subscription_id,
                    worker_id=worker_id,
                    execution_id=execution_id,
                ),
                f"原因: {_human_detail(detail, fields)}",
                _suggested_action(category, event),
            ]
        )

    if category == "billing" and event == "webhook_failed":
        return "\n".join(
            [
                _severity_title(severity),
                "Billing webhook 处理失败",
                _context_line(
                    category=category,
                    provider=provider,
                    user_id=user_id,
                    subscription_id=subscription_id,
                    worker_id=worker_id,
                    execution_id=execution_id,
                ),
                f"原因: {_human_detail(detail, fields)}",
                _suggested_action(category, event),
            ]
        )

    if category == "health" and event == "db_down":
        return "\n".join(
            [
                _severity_title(severity),
                "数据库健康检查失败",
                _context_line(
                    category=category,
                    provider=provider,
                    user_id=user_id,
                    subscription_id=subscription_id,
                    worker_id=worker_id,
                    execution_id=execution_id,
                ),
                f"原因: {_human_detail(detail, fields)}",
                _suggested_action(category, event),
            ]
        )

    if category == "worker" and event == "heartbeat_stale":
        return "\n".join(
            [
                _severity_title(severity),
                "Worker 心跳异常",
                _context_line(
                    category=category,
                    provider=provider,
                    user_id=user_id,
                    subscription_id=subscription_id,
                    worker_id=worker_id,
                    execution_id=execution_id,
                ),
                f"原因: {_human_detail(detail, fields)}",
                _suggested_action(category, event),
            ]
        )

    return "\n".join(
        [
            _severity_title(severity),
            _humanize_event_name(event),
            _context_line(
                category=category,
                provider=provider,
                user_id=user_id,
                subscription_id=subscription_id,
                worker_id=worker_id,
                execution_id=execution_id,
            ),
            f"原因: {_human_detail(detail, fields)}",
            _suggested_action(category, event),
        ]
    )


def send_operational_event(
    *,
    category: str,
    event: str,
    severity: str,
    detail: str,
    message_override: str | None = None,
    provider: str | None = None,
    user_id: str | None = None,
    subscription_id: str | None = None,
    worker_id: str | None = None,
    execution_id: str | None = None,
    cooldown_seconds: int = 600,
):
    # Unified operational alert model for production and future remote worker preparation.
    from disposable_exec.db import record_operational_event, should_send_alert

    record_operational_event(
        category=category,
        event=event,
        severity=severity,
        detail=detail,
        provider=provider,
        user_id=user_id,
        subscription_id=subscription_id,
        worker_id=worker_id,
        execution_id=execution_id,
    )

    cooldown_key = ":".join(
        part for part in [category, event, provider or "", worker_id or ""] if part
    )
    if severity != "info" and should_send_alert(cooldown_key, cooldown_seconds=cooldown_seconds):
        formatted_message = message_override or _build_operational_event_message(
            category=category,
            event=event,
            severity=severity,
            detail=detail,
            provider=provider,
            user_id=user_id,
            subscription_id=subscription_id,
            worker_id=worker_id,
            execution_id=execution_id,
        )
        if formatted_message:
            send_telegram_alert_async(formatted_message)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Disposable-exec operational alert helpers")
    parser.add_argument(
        "command",
        choices=["send-admin-metrics-summary"],
        help="Send one scheduled Telegram metrics summary",
    )
    args = parser.parse_args(argv)

    if args.command == "send-admin-metrics-summary":
        send_admin_metrics_scheduled_summary(asynchronous=False)
        return 0

    return 1


if __name__ == "__main__":
    raise SystemExit(main())
