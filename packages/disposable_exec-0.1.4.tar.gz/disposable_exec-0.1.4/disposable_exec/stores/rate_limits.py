from __future__ import annotations

from ..db_adapter import run_in_transaction


def ensure_rate_limit_tables() -> None:
    def _transaction(conn) -> None:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS rate_limits (
                key_id TEXT,
                route TEXT,
                window_key TEXT,
                request_count INTEGER,
                PRIMARY KEY (key_id, route, window_key)
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS ip_rate_limits (
                ip_address TEXT,
                route TEXT,
                window_key TEXT,
                request_count INTEGER,
                PRIMARY KEY (ip_address, route, window_key)
            )
            """
        )

    run_in_transaction(_transaction)


def increment_key_rate_limit(key_id: str, route: str, window_key: str, limit: int) -> dict:
    def _transaction(conn) -> dict:
        row = conn.execute(
            """
            SELECT request_count
            FROM rate_limits
            WHERE key_id = ? AND route = ? AND window_key = ?
            """,
            (key_id, route, window_key),
        ).fetchone()

        if row:
            new_count = row["request_count"] + 1
            conn.execute(
                """
                UPDATE rate_limits
                SET request_count = ?
                WHERE key_id = ? AND route = ? AND window_key = ?
                """,
                (new_count, key_id, route, window_key),
            )
        else:
            new_count = 1
            conn.execute(
                """
                INSERT INTO rate_limits (key_id, route, window_key, request_count)
                VALUES (?, ?, ?, ?)
                """,
                (key_id, route, window_key, new_count),
            )

        return {
            "allowed": new_count <= limit,
            "count": new_count,
            "limit": limit,
            "window_key": window_key,
        }

    return run_in_transaction(_transaction)


def increment_ip_rate_limit(ip_address: str, route: str, window_key: str, limit: int) -> dict:
    def _transaction(conn) -> dict:
        row = conn.execute(
            """
            SELECT request_count
            FROM ip_rate_limits
            WHERE ip_address = ? AND route = ? AND window_key = ?
            """,
            (ip_address, route, window_key),
        ).fetchone()

        if row:
            new_count = row["request_count"] + 1
            conn.execute(
                """
                UPDATE ip_rate_limits
                SET request_count = ?
                WHERE ip_address = ? AND route = ? AND window_key = ?
                """,
                (new_count, ip_address, route, window_key),
            )
        else:
            new_count = 1
            conn.execute(
                """
                INSERT INTO ip_rate_limits (ip_address, route, window_key, request_count)
                VALUES (?, ?, ?, ?)
                """,
                (ip_address, route, window_key, new_count),
            )

        return {
            "allowed": new_count <= limit,
            "count": new_count,
            "limit": limit,
            "window_key": window_key,
            "ip_address": ip_address,
        }

    return run_in_transaction(_transaction)
