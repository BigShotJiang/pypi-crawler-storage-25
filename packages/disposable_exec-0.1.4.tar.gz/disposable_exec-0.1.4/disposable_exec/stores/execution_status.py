from __future__ import annotations

import os
import threading
from time import monotonic
from time import perf_counter
from typing import Any

from ..db_adapter import fetch_all, fetch_one, run_in_transaction
from ..shared_execution_state import (
    SharedExecutionStateUnavailable,
    get_shared_user_active_count,
    get_shared_worker_assignment_counts,
    get_shared_execution_status,
    is_shared_execution_backing_enabled,
    list_shared_execution_statuses,
    upsert_shared_execution_status,
)

_UNSET = object()
_SQLITE_EXECUTION_STATUS_LEASE_COLUMNS_READY = False
_SHARED_EXECUTION_AGGREGATES_CACHE_LOCK = threading.Lock()
_SHARED_EXECUTION_AGGREGATES_CACHE: dict[str, Any] | None = None
_SHARED_EXECUTION_AGGREGATES_CACHE_AT = 0.0


def _log_execution_status_timing(*, execution_id: str | None, store_step: str, started_at: float):
    elapsed_ms = round((perf_counter() - started_at) * 1000, 1)
    print(
        f"EXECUTION_STATUS_STORE_TIMING execution_id={execution_id or ''} store_step={store_step} elapsed_ms={elapsed_ms}",
        flush=True,
    )


def _using_shared_execution_backing() -> bool:
    return is_shared_execution_backing_enabled()


def _shared_execution_aggregates_cache_ttl_seconds() -> float:
    try:
        configured_ttl = max(
            0.0,
            float(
                os.getenv("DISPOSABLE_EXEC_SHARED_EXECUTION_AGGREGATES_CACHE_TTL_SECONDS", "").strip()
                or os.getenv("SHARED_EXECUTION_AGGREGATES_CACHE_TTL_SECONDS", "").strip()
                or os.getenv("DISPOSABLE_EXEC_SHARED_ASSIGNMENT_COUNTS_CACHE_TTL_SECONDS", "").strip()
                or os.getenv("SHARED_ASSIGNMENT_COUNTS_CACHE_TTL_SECONDS", "").strip()
                or "5"
            ),
        )
        warm_enabled = str(
            os.getenv("DISPOSABLE_EXEC_SHARED_EXECUTION_AGGREGATES_WARM_ENABLED")
            or os.getenv("SHARED_EXECUTION_AGGREGATES_WARM_ENABLED")
            or "1"
        ).strip().lower() in {"1", "true", "yes", "on"}
        if not warm_enabled:
            return configured_ttl

        warm_interval = max(
            1.0,
            float(
                os.getenv("DISPOSABLE_EXEC_SHARED_EXECUTION_AGGREGATES_WARM_INTERVAL_SECONDS", "").strip()
                or os.getenv("SHARED_EXECUTION_AGGREGATES_WARM_INTERVAL_SECONDS", "").strip()
                or "10"
            ),
        )
        # Keep the warmed snapshot alive longer than the refresh interval so
        # request-time dispatch does not fall back to a cold full scan between
        # periodic background warm cycles.
        return max(configured_ttl, warm_interval + 1.0)
    except ValueError:
        return 11.0


def _is_active_execution_status(status: str | None) -> bool:
    return status in {"queued", "claimed", "running"}


def _apply_execution_row_counts_delta(
    *,
    assignment_counts: dict[str, dict[str, int]],
    active_counts_by_user: dict[str, int],
    row: dict[str, Any] | None,
    delta: int,
) -> None:
    if not row or not _is_active_execution_status(row.get("status")):
        return

    user_id = row.get("user_id")
    if user_id:
        updated_count = int(active_counts_by_user.get(user_id, 0)) + delta
        if updated_count > 0:
            active_counts_by_user[user_id] = updated_count
        else:
            active_counts_by_user.pop(user_id, None)

    assigned_worker_id = row.get("assigned_worker_id")
    if not assigned_worker_id:
        return

    worker_counts = assignment_counts.setdefault(
        assigned_worker_id,
        {
            "assigned_job_count": 0,
            "running_count": 0,
            "queued_count": 0,
            "active_assigned_count": 0,
        },
    )
    worker_counts["assigned_job_count"] = max(0, int(worker_counts.get("assigned_job_count", 0)) + delta)
    worker_counts["active_assigned_count"] = max(0, int(worker_counts.get("active_assigned_count", 0)) + delta)
    if row.get("status") == "running":
        worker_counts["running_count"] = max(0, int(worker_counts.get("running_count", 0)) + delta)
    if row.get("status") in {"queued", "claimed"}:
        worker_counts["queued_count"] = max(0, int(worker_counts.get("queued_count", 0)) + delta)
    if not any(int(worker_counts.get(field, 0)) > 0 for field in ("assigned_job_count", "running_count", "queued_count", "active_assigned_count")):
        assignment_counts.pop(assigned_worker_id, None)


def _apply_shared_execution_row_to_aggregates_cache(
    *,
    previous_row: dict[str, Any] | None,
    new_row: dict[str, Any] | None,
) -> None:
    global _SHARED_EXECUTION_AGGREGATES_CACHE, _SHARED_EXECUTION_AGGREGATES_CACHE_AT
    with _SHARED_EXECUTION_AGGREGATES_CACHE_LOCK:
        if _SHARED_EXECUTION_AGGREGATES_CACHE is None:
            return

        assignment_counts = _SHARED_EXECUTION_AGGREGATES_CACHE["assignment_counts"]
        active_counts_by_user = _SHARED_EXECUTION_AGGREGATES_CACHE["active_counts_by_user"]
        rows_by_execution_id = _SHARED_EXECUTION_AGGREGATES_CACHE["rows_by_execution_id"]

        effective_previous = previous_row or rows_by_execution_id.get((new_row or {}).get("execution_id", ""))
        _apply_execution_row_counts_delta(
            assignment_counts=assignment_counts,
            active_counts_by_user=active_counts_by_user,
            row=effective_previous,
            delta=-1,
        )
        _apply_execution_row_counts_delta(
            assignment_counts=assignment_counts,
            active_counts_by_user=active_counts_by_user,
            row=new_row,
            delta=1,
        )

        execution_id = (new_row or effective_previous or {}).get("execution_id")
        if execution_id:
            if new_row:
                rows_by_execution_id[execution_id] = {
                    "execution_id": execution_id,
                    "status": new_row.get("status"),
                    "user_id": new_row.get("user_id"),
                    "assigned_worker_id": new_row.get("assigned_worker_id"),
                }
            else:
                rows_by_execution_id.pop(execution_id, None)
        _SHARED_EXECUTION_AGGREGATES_CACHE_AT = monotonic()


def _build_shared_execution_aggregates(rows: list[dict[str, Any]]) -> dict[str, Any]:
    total_started_at = perf_counter()
    assignment_counts: dict[str, dict[str, int]] = {}
    active_counts_by_user: dict[str, int] = {}
    rows_by_execution_id: dict[str, dict[str, Any]] = {}
    for row in rows:
        execution_id = row.get("execution_id")
        if execution_id:
            rows_by_execution_id[execution_id] = {
                "execution_id": execution_id,
                "status": row.get("status"),
                "user_id": row.get("user_id"),
                "assigned_worker_id": row.get("assigned_worker_id"),
            }
        status = row.get("status")
        if status not in {"queued", "claimed", "running"}:
            continue

        user_id = row.get("user_id")
        if user_id:
            active_counts_by_user[user_id] = int(active_counts_by_user.get(user_id, 0)) + 1

        assigned_worker_id = row.get("assigned_worker_id")
        if not assigned_worker_id:
            continue

        item = assignment_counts.setdefault(
            assigned_worker_id,
            {
                "assigned_job_count": 0,
                "running_count": 0,
                "queued_count": 0,
                "active_assigned_count": 0,
            },
        )
        item["assigned_job_count"] += 1
        item["active_assigned_count"] += 1
        if status == "running":
            item["running_count"] += 1
        if status in {"queued", "claimed"}:
            item["queued_count"] += 1
    result = {
        "assignment_counts": assignment_counts,
        "active_counts_by_user": active_counts_by_user,
        "rows_by_execution_id": rows_by_execution_id,
    }
    _log_execution_status_timing(
        execution_id=None,
        store_step="build_shared_execution_aggregates_total",
        started_at=total_started_at,
    )
    return result


def _get_shared_execution_aggregates() -> dict[str, Any]:
    global _SHARED_EXECUTION_AGGREGATES_CACHE, _SHARED_EXECUTION_AGGREGATES_CACHE_AT
    total_started_at = perf_counter()
    ttl_seconds = _shared_execution_aggregates_cache_ttl_seconds()
    now = monotonic()
    with _SHARED_EXECUTION_AGGREGATES_CACHE_LOCK:
        if (
            _SHARED_EXECUTION_AGGREGATES_CACHE is not None
            and ttl_seconds > 0
            and (now - _SHARED_EXECUTION_AGGREGATES_CACHE_AT) <= ttl_seconds
        ):
            result = {
                "assignment_counts": {
                    worker_id: dict(counts)
                    for worker_id, counts in _SHARED_EXECUTION_AGGREGATES_CACHE["assignment_counts"].items()
                },
                "active_counts_by_user": dict(_SHARED_EXECUTION_AGGREGATES_CACHE["active_counts_by_user"]),
                "rows_by_execution_id": {
                    execution_id: dict(row)
                    for execution_id, row in _SHARED_EXECUTION_AGGREGATES_CACHE["rows_by_execution_id"].items()
                },
            }
            _log_execution_status_timing(
                execution_id=None,
                store_step="get_shared_execution_aggregates_cache_hit",
                started_at=total_started_at,
            )
            return result

    aggregates = _build_shared_execution_aggregates(_shared_list_execution_status_rows())
    with _SHARED_EXECUTION_AGGREGATES_CACHE_LOCK:
        _SHARED_EXECUTION_AGGREGATES_CACHE = {
            "assignment_counts": {
                worker_id: dict(counts)
                for worker_id, counts in aggregates["assignment_counts"].items()
            },
            "active_counts_by_user": dict(aggregates["active_counts_by_user"]),
            "rows_by_execution_id": {
                execution_id: dict(row)
                for execution_id, row in aggregates["rows_by_execution_id"].items()
            },
        }
        _SHARED_EXECUTION_AGGREGATES_CACHE_AT = monotonic()
    _log_execution_status_timing(
        execution_id=None,
        store_step="get_shared_execution_aggregates_rebuild_total",
        started_at=total_started_at,
    )
    return aggregates


def warm_shared_execution_aggregates_cache() -> dict[str, Any] | None:
    if not _using_shared_execution_backing():
        return None
    total_started_at = perf_counter()
    aggregates = _get_shared_execution_aggregates()
    _log_execution_status_timing(
        execution_id=None,
        store_step="warm_shared_execution_aggregates_total",
        started_at=total_started_at,
    )
    return aggregates


def _execution_source_label(shared_available: bool) -> str:
    if not _using_shared_execution_backing():
        return "sqlite"
    return "shared" if shared_available else "sqlite_fallback"


def _annotate_execution_status_source(row: dict[str, Any] | None, *, source: str) -> dict[str, Any] | None:
    if not row:
        return None
    item = dict(row)
    item["execution_state_source"] = source
    if source == "shared":
        item["execution_state_truth"] = "shared"
    elif source == "sqlite_fallback":
        item["execution_state_truth"] = "degraded_sqlite_fallback"
    else:
        item["execution_state_truth"] = "local_sqlite"
    return item


def _merge_execution_status_row(
    existing: dict[str, Any] | None,
    *,
    execution_id: str,
    key_id: str | None,
    user_id: str | None,
    assigned_worker_id: str | None,
    completed_by_worker_id: str | None,
    status: str,
    created_at: str,
    updated_at: str,
    claim_owner_worker_id: Any = _UNSET,
    claim_token: Any = _UNSET,
    claim_marked_at: Any = _UNSET,
    lease_expires_at: Any = _UNSET,
    last_lease_renewed_at: Any = _UNSET,
    recovery_attempt_count: Any = _UNSET,
    orphaned_at: Any = _UNSET,
    requeueable: Any = _UNSET,
) -> dict[str, Any]:
    current = existing or {}

    def _resolve_optional(field_name: str, value: Any):
        if value is _UNSET:
            return current.get(field_name)
        return value

    merged = {
        "execution_id": execution_id,
        "key_id": key_id if key_id is not None else current.get("key_id"),
        "user_id": user_id if user_id is not None else current.get("user_id"),
        "assigned_worker_id": (
            assigned_worker_id if assigned_worker_id is not None else current.get("assigned_worker_id")
        ),
        "completed_by_worker_id": (
            completed_by_worker_id
            if completed_by_worker_id is not None
            else assigned_worker_id
            if assigned_worker_id is not None
            else current.get("completed_by_worker_id")
            if current.get("completed_by_worker_id") not in {None, ""}
            else current.get("assigned_worker_id")
        ),
        "status": status,
        "created_at": current.get("created_at") or created_at,
        "updated_at": updated_at,
        "claim_owner_worker_id": _resolve_optional("claim_owner_worker_id", claim_owner_worker_id),
        "claim_token": _resolve_optional("claim_token", claim_token),
        "claim_marked_at": _resolve_optional("claim_marked_at", claim_marked_at),
        "lease_expires_at": _resolve_optional("lease_expires_at", lease_expires_at),
        "last_lease_renewed_at": _resolve_optional("last_lease_renewed_at", last_lease_renewed_at),
        "recovery_attempt_count": _resolve_optional("recovery_attempt_count", recovery_attempt_count),
        "orphaned_at": _resolve_optional("orphaned_at", orphaned_at),
        "requeueable": _resolve_optional("requeueable", requeueable),
    }
    return merged


def _ensure_execution_status_lease_columns(conn) -> None:
    global _SQLITE_EXECUTION_STATUS_LEASE_COLUMNS_READY
    if _SQLITE_EXECUTION_STATUS_LEASE_COLUMNS_READY:
        return

    rows = conn.execute("PRAGMA table_info(execution_status)").fetchall()
    existing = {row["name"] for row in rows}
    column_defs = {
        "claim_owner_worker_id": "TEXT",
        "claim_token": "TEXT",
        "claim_marked_at": "TEXT",
        "lease_expires_at": "TEXT",
        "last_lease_renewed_at": "TEXT",
        "recovery_attempt_count": "INTEGER",
        "orphaned_at": "TEXT",
        "requeueable": "INTEGER",
    }
    for column_name, column_type in column_defs.items():
        if column_name in existing:
            continue
        conn.execute(f"ALTER TABLE execution_status ADD COLUMN {column_name} {column_type}")
    _SQLITE_EXECUTION_STATUS_LEASE_COLUMNS_READY = True


def _sqlite_upsert_execution_status(
    row: dict[str, Any],
) -> None:
    def _transaction(conn) -> None:
        _ensure_execution_status_lease_columns(conn)
        conn.execute(
            """
            INSERT INTO execution_status
            (
                execution_id, key_id, user_id, assigned_worker_id, completed_by_worker_id, status, created_at, updated_at,
                claim_owner_worker_id, claim_token, claim_marked_at, lease_expires_at, last_lease_renewed_at,
                recovery_attempt_count, orphaned_at, requeueable
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(execution_id) DO UPDATE SET
                key_id = excluded.key_id,
                user_id = excluded.user_id,
                assigned_worker_id = excluded.assigned_worker_id,
                completed_by_worker_id = excluded.completed_by_worker_id,
                status = excluded.status,
                created_at = excluded.created_at,
                updated_at = excluded.updated_at,
                claim_owner_worker_id = excluded.claim_owner_worker_id,
                claim_token = excluded.claim_token,
                claim_marked_at = excluded.claim_marked_at,
                lease_expires_at = excluded.lease_expires_at,
                last_lease_renewed_at = excluded.last_lease_renewed_at,
                recovery_attempt_count = excluded.recovery_attempt_count,
                orphaned_at = excluded.orphaned_at,
                requeueable = excluded.requeueable
            """,
            (
                row["execution_id"],
                row.get("key_id"),
                row.get("user_id"),
                row.get("assigned_worker_id"),
                row.get("completed_by_worker_id"),
                row["status"],
                row["created_at"],
                row["updated_at"],
                row.get("claim_owner_worker_id"),
                row.get("claim_token"),
                row.get("claim_marked_at"),
                row.get("lease_expires_at"),
                row.get("last_lease_renewed_at"),
                row.get("recovery_attempt_count"),
                row.get("orphaned_at"),
                int(bool(row.get("requeueable"))) if row.get("requeueable") is not None else None,
            ),
        )

    run_in_transaction(_transaction)


def _sqlite_get_execution_status_row_with_conn(
    conn,
    execution_id: str,
    key_id: str | None = None,
    user_id: str | None = None,
) -> dict[str, Any] | None:
    _ensure_execution_status_lease_columns(conn)
    query = """
        SELECT execution_id, key_id, user_id, assigned_worker_id, completed_by_worker_id, status, created_at, updated_at,
               claim_owner_worker_id, claim_token, claim_marked_at, lease_expires_at, last_lease_renewed_at,
               recovery_attempt_count, orphaned_at, requeueable
        FROM execution_status
        WHERE execution_id = ?
    """
    params: list[Any] = [execution_id]

    if key_id is not None and user_id is not None:
        query += " AND (key_id = ? OR user_id = ?)"
        params.extend([key_id, user_id])
    elif key_id is not None:
        query += " AND key_id = ?"
        params.append(key_id)
    elif user_id is not None:
        query += " AND user_id = ?"
        params.append(user_id)

    row = conn.execute(query, tuple(params)).fetchone()
    if not row:
        return None
    item = dict(row)
    if item.get("requeueable") is not None:
        item["requeueable"] = bool(item["requeueable"])
    return item


def _sqlite_get_execution_status_row(
    execution_id: str,
    key_id: str | None = None,
    user_id: str | None = None,
) -> dict[str, Any] | None:
    def _transaction(conn) -> dict[str, Any] | None:
        return _sqlite_get_execution_status_row_with_conn(
            conn,
            execution_id,
            key_id=key_id,
            user_id=user_id,
        )

    return run_in_transaction(_transaction)


def _sqlite_list_execution_status_rows(
    statuses: set[str] | None = None,
) -> list[dict[str, Any]]:
    def _transaction(conn) -> list[dict[str, Any]]:
        _ensure_execution_status_lease_columns(conn)
        rows = conn.execute(
            """
            SELECT execution_id, key_id, user_id, assigned_worker_id, completed_by_worker_id, status, created_at, updated_at,
                   claim_owner_worker_id, claim_token, claim_marked_at, lease_expires_at, last_lease_renewed_at,
                   recovery_attempt_count, orphaned_at, requeueable
            FROM execution_status
            ORDER BY updated_at ASC, created_at ASC, execution_id ASC
            """
        ).fetchall()
        items: list[dict[str, Any]] = []
        for row in rows:
            item = dict(row)
            if item.get("requeueable") is not None:
                item["requeueable"] = bool(item["requeueable"])
            if statuses and item.get("status") not in statuses:
                continue
            items.append(item)
        return items

    return run_in_transaction(_transaction)


def _sqlite_record_execution_claim_ownership(
    execution_id: str,
    *,
    worker_id: str | None,
    claim_token: str,
    claimed_at: str,
    lease_expires_at: str | None,
    last_lease_renewed_at: str | None,
    recovery_attempt_count: int | None,
    requeueable: bool | None,
) -> None:
    def _transaction(conn) -> None:
        _ensure_execution_status_lease_columns(conn)
        conn.execute(
            """
            UPDATE execution_status
            SET claim_owner_worker_id = ?,
                claim_token = ?,
                claim_marked_at = ?,
                assigned_worker_id = COALESCE(?, assigned_worker_id),
                status = 'claimed',
                updated_at = ?,
                lease_expires_at = ?,
                last_lease_renewed_at = ?,
                recovery_attempt_count = COALESCE(recovery_attempt_count, ?),
                requeueable = COALESCE(requeueable, ?)
            WHERE execution_id = ?
            """,
            (
                worker_id,
                claim_token,
                claimed_at,
                worker_id,
                claimed_at,
                lease_expires_at,
                last_lease_renewed_at,
                recovery_attempt_count,
                int(bool(requeueable)) if requeueable is not None else None,
                execution_id,
            ),
        )

    run_in_transaction(_transaction)


def _shared_get_execution_status_row(
    execution_id: str,
    key_id: str | None = None,
    user_id: str | None = None,
) -> dict[str, Any] | None:
    row = get_shared_execution_status(execution_id)
    if not row:
        return None
    if key_id is not None and user_id is not None:
        if row.get("key_id") != key_id and row.get("user_id") != user_id:
            return None
    elif key_id is not None:
        if row.get("key_id") != key_id:
            return None
    elif user_id is not None:
        if row.get("user_id") != user_id:
            return None
    return row


def _shared_list_execution_status_rows(
    statuses: set[str] | None = None,
) -> list[dict[str, Any]]:
    try:
        rows = list_shared_execution_statuses()
    except Exception as exc:
        raise SharedExecutionStateUnavailable(str(exc)) from exc

    items: list[dict[str, Any]] = []
    for row in rows:
        if statuses and row.get("status") not in statuses:
            continue
        if row.get("requeueable") is not None:
            row["requeueable"] = bool(row["requeueable"])
        items.append(row)
    return items


def _sqlite_get_active_assignment_counts_by_worker() -> dict[str, dict[str, int]]:
    rows = fetch_all(
        """
        SELECT assigned_worker_id, status, COUNT(*) AS count
        FROM execution_status
        WHERE assigned_worker_id IS NOT NULL
          AND status IN ('queued', 'claimed', 'running')
        GROUP BY assigned_worker_id, status
        """
    )
    counts: dict[str, dict[str, int]] = {}
    for row in rows:
        worker_id = row["assigned_worker_id"]
        item = counts.setdefault(
            worker_id,
            {
                "assigned_job_count": 0,
                "running_count": 0,
                "queued_count": 0,
                "active_assigned_count": 0,
            },
        )
        count = int(row["count"])
        item["assigned_job_count"] += count
        item["active_assigned_count"] += count
        if row["status"] == "running":
            item["running_count"] += count
        if row["status"] in {"queued", "claimed"}:
            item["queued_count"] += count
    return counts


def _shared_get_active_assignment_counts_by_worker() -> dict[str, dict[str, int]]:
    total_started_at = perf_counter()
    counts = _get_shared_execution_aggregates()["assignment_counts"]
    _log_execution_status_timing(
        execution_id=None,
        store_step="shared_get_active_assignment_counts_by_worker_total",
        started_at=total_started_at,
    )
    return counts


def _shared_get_active_assignment_counts_by_worker_fast() -> dict[str, dict[str, int]]:
    total_started_at = perf_counter()
    counts = get_shared_worker_assignment_counts()
    _log_execution_status_timing(
        execution_id=None,
        store_step="shared_worker_assignment_counts_fast_path",
        started_at=total_started_at,
    )
    return counts


def _sqlite_count_active_executions_for_user(user_id: str) -> int:
    if not user_id:
        return 0
    row = fetch_one(
        """
        SELECT COUNT(*) AS count
        FROM execution_status
        WHERE user_id = ? AND status IN ('queued', 'claimed', 'running')
        """,
        (user_id,),
    )
    return int(row["count"]) if row else 0


def _shared_count_active_executions_for_user(user_id: str) -> int:
    if not user_id:
        return 0
    total_started_at = perf_counter()
    count = int(_get_shared_execution_aggregates()["active_counts_by_user"].get(user_id, 0))
    _log_execution_status_timing(
        execution_id=None,
        store_step="shared_count_active_executions_for_user_total",
        started_at=total_started_at,
    )
    return count


def _shared_count_active_executions_for_user_fast(user_id: str) -> int:
    total_started_at = perf_counter()
    count = int(get_shared_user_active_count(user_id))
    _log_execution_status_timing(
        execution_id=None,
        store_step="shared_user_active_count_fast_path",
        started_at=total_started_at,
    )
    return count


def _get_existing_execution_status_context(
    execution_id: str,
    key_id: str | None = None,
    user_id: str | None = None,
) -> dict[str, Any] | None:
    # Writes already persist local sqlite alongside shared state, so prefer the
    # local row for merge context on hot write paths and only fall back to
    # shared truth when sqlite has no row yet on this node.
    sqlite_row = _sqlite_get_execution_status_row(execution_id, key_id=key_id, user_id=user_id)
    if sqlite_row:
        return sqlite_row

    if _using_shared_execution_backing():
        try:
            return _shared_get_execution_status_row(execution_id, key_id=key_id, user_id=user_id)
        except SharedExecutionStateUnavailable:
            return None

    return None


def upsert_execution_status(
    *,
    execution_id: str,
    key_id: str | None,
    user_id: str | None,
    assigned_worker_id: str | None,
    completed_by_worker_id: str | None,
    status: str,
    created_at: str,
    updated_at: str,
    claim_owner_worker_id: Any = _UNSET,
    claim_token: Any = _UNSET,
    claim_marked_at: Any = _UNSET,
    lease_expires_at: Any = _UNSET,
    last_lease_renewed_at: Any = _UNSET,
    recovery_attempt_count: Any = _UNSET,
    orphaned_at: Any = _UNSET,
    requeueable: Any = _UNSET,
    write_shared: bool = True,
    skip_existing_lookup: bool = False,
) -> None:
    existing = None
    if skip_existing_lookup:
        _log_execution_status_timing(
            execution_id=execution_id,
            store_step="load_existing_context_skipped",
            started_at=perf_counter(),
        )
    else:
        existing_started_at = perf_counter()
        existing = _get_existing_execution_status_context(
            execution_id,
            key_id=key_id,
            user_id=user_id,
        )
        _log_execution_status_timing(
            execution_id=execution_id,
            store_step="load_existing_context",
            started_at=existing_started_at,
        )
    merged_row = _merge_execution_status_row(
        existing,
        execution_id=execution_id,
        key_id=key_id,
        user_id=user_id,
        assigned_worker_id=assigned_worker_id,
        completed_by_worker_id=completed_by_worker_id,
        status=status,
        created_at=created_at,
        updated_at=updated_at,
        claim_owner_worker_id=claim_owner_worker_id,
        claim_token=claim_token,
        claim_marked_at=claim_marked_at,
        lease_expires_at=lease_expires_at,
        last_lease_renewed_at=last_lease_renewed_at,
        recovery_attempt_count=recovery_attempt_count,
        orphaned_at=orphaned_at,
        requeueable=requeueable,
    )

    if write_shared and _using_shared_execution_backing():
        try:
            shared_upsert_started_at = perf_counter()
            upsert_shared_execution_status(merged_row)
            _apply_shared_execution_row_to_aggregates_cache(
                previous_row=existing,
                new_row=merged_row,
            )
            _log_execution_status_timing(
                execution_id=execution_id,
                store_step="shared_upsert",
                started_at=shared_upsert_started_at,
            )
        except SharedExecutionStateUnavailable:
            pass

    sqlite_upsert_started_at = perf_counter()
    _sqlite_upsert_execution_status(merged_row)
    _log_execution_status_timing(
        execution_id=execution_id,
        store_step="sqlite_upsert",
        started_at=sqlite_upsert_started_at,
    )


def get_execution_status_row(
    execution_id: str,
    key_id: str | None = None,
    user_id: str | None = None,
) -> dict[str, Any] | None:
    if _using_shared_execution_backing():
        try:
            return _annotate_execution_status_source(
                _shared_get_execution_status_row(execution_id, key_id=key_id, user_id=user_id),
                source="shared",
            )
        except SharedExecutionStateUnavailable:
            return _annotate_execution_status_source(
                _sqlite_get_execution_status_row(execution_id, key_id=key_id, user_id=user_id),
                source="sqlite_fallback",
            )

    return _annotate_execution_status_source(
        _sqlite_get_execution_status_row(execution_id, key_id=key_id, user_id=user_id),
        source="sqlite",
    )


def list_execution_status_rows(statuses: set[str] | None = None) -> list[dict[str, Any]]:
    if _using_shared_execution_backing():
        try:
            rows = _shared_list_execution_status_rows(statuses=statuses)
            items = [_annotate_execution_status_source(row, source="shared") for row in rows]
            return [row for row in items if row]
        except SharedExecutionStateUnavailable:
            rows = _sqlite_list_execution_status_rows(statuses=statuses)
            items = [_annotate_execution_status_source(row, source="sqlite_fallback") for row in rows]
            return [row for row in items if row]

    rows = _sqlite_list_execution_status_rows(statuses=statuses)
    items = [_annotate_execution_status_source(row, source="sqlite") for row in rows]
    return [row for row in items if row]


def get_active_assignment_counts_by_worker() -> dict[str, Any]:
    total_started_at = perf_counter()
    if _using_shared_execution_backing():
        try:
            result = {
                "counts": _shared_get_active_assignment_counts_by_worker_fast(),
                "assignment_state_source": "shared",
                "execution_load_truth": "shared",
            }
            _log_execution_status_timing(
                execution_id=None,
                store_step="shared_execution_aggregate_fast_path_hit",
                started_at=total_started_at,
            )
            _log_execution_status_timing(
                execution_id=None,
                store_step="get_active_assignment_counts_by_worker_total",
                started_at=total_started_at,
            )
            return result
        except SharedExecutionStateUnavailable:
            _log_execution_status_timing(
                execution_id=None,
                store_step="shared_execution_aggregate_fast_path_fallback",
                started_at=total_started_at,
            )
            try:
                result = {
                    "counts": _shared_get_active_assignment_counts_by_worker(),
                    "assignment_state_source": "shared",
                    "execution_load_truth": "shared",
                }
                _log_execution_status_timing(
                    execution_id=None,
                    store_step="get_active_assignment_counts_by_worker_total",
                    started_at=total_started_at,
                )
                return result
            except SharedExecutionStateUnavailable:
                result = {
                    "counts": _sqlite_get_active_assignment_counts_by_worker(),
                    "assignment_state_source": "sqlite_fallback",
                    "execution_load_truth": "degraded_sqlite_fallback",
                }
                _log_execution_status_timing(
                    execution_id=None,
                    store_step="get_active_assignment_counts_by_worker_total",
                    started_at=total_started_at,
                )
                return result

    result = {
        "counts": _sqlite_get_active_assignment_counts_by_worker(),
        "assignment_state_source": "local_sqlite",
        "execution_load_truth": "local_sqlite",
    }
    _log_execution_status_timing(
        execution_id=None,
        store_step="get_active_assignment_counts_by_worker_total",
        started_at=total_started_at,
    )
    return result


def get_active_execution_count_for_user(user_id: str) -> dict[str, Any]:
    total_started_at = perf_counter()
    if _using_shared_execution_backing():
        try:
            result = {
                "count": _shared_count_active_executions_for_user_fast(user_id),
                "execution_state_source": "shared",
                "execution_state_truth": "shared",
            }
            _log_execution_status_timing(
                execution_id=None,
                store_step="shared_execution_aggregate_fast_path_hit",
                started_at=total_started_at,
            )
            _log_execution_status_timing(
                execution_id=None,
                store_step="get_active_execution_count_for_user_total",
                started_at=total_started_at,
            )
            return result
        except SharedExecutionStateUnavailable:
            _log_execution_status_timing(
                execution_id=None,
                store_step="shared_execution_aggregate_fast_path_fallback",
                started_at=total_started_at,
            )
            try:
                result = {
                    "count": _shared_count_active_executions_for_user(user_id),
                    "execution_state_source": "shared",
                    "execution_state_truth": "shared",
                }
                _log_execution_status_timing(
                    execution_id=None,
                    store_step="get_active_execution_count_for_user_total",
                    started_at=total_started_at,
                )
                return result
            except SharedExecutionStateUnavailable:
                result = {
                    "count": _sqlite_count_active_executions_for_user(user_id),
                    "execution_state_source": "sqlite_fallback",
                    "execution_state_truth": "degraded_sqlite_fallback",
                }
                _log_execution_status_timing(
                    execution_id=None,
                    store_step="get_active_execution_count_for_user_total",
                    started_at=total_started_at,
                )
                return result

    result = {
        "count": _sqlite_count_active_executions_for_user(user_id),
        "execution_state_source": "sqlite",
        "execution_state_truth": "local_sqlite",
    }
    _log_execution_status_timing(
        execution_id=None,
        store_step="get_active_execution_count_for_user_total",
        started_at=total_started_at,
    )
    return result


def record_execution_claim_ownership(
    execution_id: str,
    *,
    worker_id: str | None,
    claim_token: str,
    claimed_at: str,
    key_id: str | None = None,
    user_id: str | None = None,
    assigned_worker_id: str | None = None,
    completed_by_worker_id: str | None = None,
    created_at: str | None = None,
    lease_expires_at: str | None,
    last_lease_renewed_at: str | None,
    recovery_attempt_count: int | None = None,
    requeueable: bool | None = None,
) -> dict[str, Any]:
    existing_started_at = perf_counter()
    existing = None
    if any(value is None for value in (key_id, assigned_worker_id, created_at)):
        existing = _get_existing_execution_status_context(execution_id)
    _log_execution_status_timing(
        execution_id=execution_id,
        store_step="claim_load_existing_context",
        started_at=existing_started_at,
    )
    marker = {
        "execution_id": execution_id,
        "claim_owner_worker_id": worker_id,
        "claim_token": claim_token,
        "claim_marked_at": claimed_at,
        "lease_expires_at": lease_expires_at,
        "last_lease_renewed_at": last_lease_renewed_at,
        "recovery_attempt_count": (
            existing.get("recovery_attempt_count")
            if existing and existing.get("recovery_attempt_count") is not None
            else recovery_attempt_count
        ),
        "requeueable": existing.get("requeueable") if existing and existing.get("requeueable") is not None else requeueable,
    }

    if not execution_id:
        raise ValueError("execution_id is required")

    if _using_shared_execution_backing():
        try:
            merged = _merge_execution_status_row(
                existing,
                execution_id=execution_id,
                key_id=key_id if key_id is not None else (existing or {}).get("key_id"),
                user_id=user_id if user_id is not None else (existing or {}).get("user_id"),
                assigned_worker_id=assigned_worker_id if assigned_worker_id is not None else worker_id or (existing or {}).get("assigned_worker_id"),
                completed_by_worker_id=(
                    completed_by_worker_id
                    if completed_by_worker_id is not None
                    else (existing or {}).get("completed_by_worker_id")
                ),
                status="claimed",
                created_at=created_at or (existing or {}).get("created_at") or claimed_at,
                updated_at=claimed_at,
                claim_owner_worker_id=worker_id,
                claim_token=claim_token,
                claim_marked_at=claimed_at,
                lease_expires_at=lease_expires_at,
                last_lease_renewed_at=last_lease_renewed_at,
                recovery_attempt_count=marker["recovery_attempt_count"],
                requeueable=marker["requeueable"],
            )
            shared_claim_started_at = perf_counter()
            upsert_shared_execution_status(merged)
            _apply_shared_execution_row_to_aggregates_cache(
                previous_row=existing,
                new_row=merged,
            )
            _log_execution_status_timing(
                execution_id=execution_id,
                store_step="claim_shared_upsert",
                started_at=shared_claim_started_at,
            )
            sqlite_claim_started_at = perf_counter()
            _sqlite_record_execution_claim_ownership(
                execution_id,
                worker_id=worker_id,
                claim_token=claim_token,
                claimed_at=claimed_at,
                lease_expires_at=lease_expires_at,
                last_lease_renewed_at=last_lease_renewed_at,
                recovery_attempt_count=marker["recovery_attempt_count"],
                requeueable=marker["requeueable"],
            )
            _log_execution_status_timing(
                execution_id=execution_id,
                store_step="claim_sqlite_update",
                started_at=sqlite_claim_started_at,
            )
            return {
                **marker,
                "status": "claimed",
                "claim_state_source": "shared",
                "claim_state_truth": "shared",
            }
        except SharedExecutionStateUnavailable:
            sqlite_claim_started_at = perf_counter()
            _sqlite_record_execution_claim_ownership(
                execution_id,
                worker_id=worker_id,
                claim_token=claim_token,
                claimed_at=claimed_at,
                lease_expires_at=lease_expires_at,
                last_lease_renewed_at=last_lease_renewed_at,
                recovery_attempt_count=marker["recovery_attempt_count"],
                requeueable=marker["requeueable"],
            )
            _log_execution_status_timing(
                execution_id=execution_id,
                store_step="claim_sqlite_fallback_update",
                started_at=sqlite_claim_started_at,
            )
            return {
                **marker,
                "status": "claimed",
                "claim_state_source": "sqlite_fallback",
                "claim_state_truth": "degraded_sqlite_fallback",
            }

    sqlite_claim_started_at = perf_counter()
    _sqlite_record_execution_claim_ownership(
        execution_id,
        worker_id=worker_id,
        claim_token=claim_token,
        claimed_at=claimed_at,
        lease_expires_at=lease_expires_at,
        last_lease_renewed_at=last_lease_renewed_at,
        recovery_attempt_count=marker["recovery_attempt_count"],
        requeueable=marker["requeueable"],
    )
    _log_execution_status_timing(
        execution_id=execution_id,
        store_step="claim_sqlite_update",
        started_at=sqlite_claim_started_at,
    )
    return {
        **marker,
        "status": "claimed",
        "claim_state_source": "sqlite",
        "claim_state_truth": "local_sqlite",
    }
