from __future__ import annotations

import json
from datetime import datetime
from time import perf_counter

from ..db_adapter import fetch_one, run_in_transaction


def _log_execution_payload_timing(*, execution_id: str | None, store_step: str, started_at: float) -> None:
    elapsed_ms = round((perf_counter() - started_at) * 1000, 1)
    print(
        f"EXECUTION_PAYLOAD_STORE_TIMING execution_id={execution_id or ''} store_step={store_step} elapsed_ms={elapsed_ms}",
        flush=True,
    )


def save_execution_payload(
    execution_id: str,
    script: str | None,
    language: str,
    key_id: str | None = None,
    user_id: str | None = None,
    assigned_worker_id: str | None = None,
    created_at: str | None = None,
    entrypoint: str | None = None,
    files: list[dict] | None = None,
) -> None:
    if not execution_id:
        raise ValueError("execution_id is required")
    if script is None and not (entrypoint and files):
        raise ValueError("script or files payload is required")

    now = created_at or (datetime.utcnow().isoformat() + "Z")
    payload_json = None
    if entrypoint and files:
        payload_json = json.dumps(
            {
                "entrypoint": entrypoint,
                "files": files,
            }
        )

    total_started_at = perf_counter()

    def _transaction(conn) -> None:
        # Keep original runnable input durable so a future orphan recovery path
        # can reconstruct a correct requeue payload after Redis claim/removal.
        persist_started_at = perf_counter()
        conn.execute(
            """
            INSERT INTO execution_payloads (
                execution_id, script, language, key_id, user_id, assigned_worker_id, created_at, payload_json
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(execution_id) DO UPDATE SET
                script = excluded.script,
                language = excluded.language,
                key_id = COALESCE(excluded.key_id, execution_payloads.key_id),
                user_id = COALESCE(excluded.user_id, execution_payloads.user_id),
                assigned_worker_id = COALESCE(excluded.assigned_worker_id, execution_payloads.assigned_worker_id),
                created_at = COALESCE(execution_payloads.created_at, excluded.created_at),
                payload_json = COALESCE(excluded.payload_json, execution_payloads.payload_json)
            """,
            (
                execution_id,
                script or "",
                language or "python",
                key_id,
                user_id,
                assigned_worker_id,
                now,
                payload_json,
            ),
        )
        _log_execution_payload_timing(
            execution_id=execution_id,
            store_step="sqlite_upsert",
            started_at=persist_started_at,
        )

    run_in_transaction(_transaction)
    _log_execution_payload_timing(
        execution_id=execution_id,
        store_step="save_execution_payload_total",
        started_at=total_started_at,
    )


def get_execution_payload(execution_id: str):
    if not execution_id:
        return None
    row = fetch_one(
        """
        SELECT execution_id, script, language, key_id, user_id, assigned_worker_id, created_at, payload_json
        FROM execution_payloads
        WHERE execution_id = ?
        LIMIT 1
        """,
        (execution_id,),
    )
    if row is None:
        return None
    payload_json = row.get("payload_json")
    if payload_json:
        try:
            payload = json.loads(payload_json)
        except (TypeError, json.JSONDecodeError):
            payload = {}
        row["entrypoint"] = payload.get("entrypoint")
        row["files"] = payload.get("files")
    return row
