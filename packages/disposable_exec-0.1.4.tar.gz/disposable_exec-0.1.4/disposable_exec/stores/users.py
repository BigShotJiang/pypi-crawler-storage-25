from __future__ import annotations

from typing import Any

from ..db_adapter import fetch_all_business, fetch_one_business, run_business_transaction


def get_user_by_normalized_email(email: str) -> dict[str, Any] | None:
    return fetch_one_business(
        "SELECT id FROM users WHERE lower(email) = ?",
        (email,),
    )


def create_user(*, user_id: str, email: str, status: str, created_at: str) -> str:
    def _transaction(conn) -> str:
        conn.execute(
            """
            INSERT INTO users (id, email, status, created_at)
            VALUES (?, ?, ?, ?)
            """,
            (user_id, email, status, created_at),
        )
        return user_id

    return run_business_transaction(_transaction)


def list_users() -> list[dict[str, Any]]:
    return fetch_all_business(
        """
        SELECT id, email, status, created_at
        FROM users
        ORDER BY created_at DESC
        """
    )
