from __future__ import annotations

from ..db import is_postgres_business_db
from ..db_adapter import fetch_one_business, run_business_transaction


def usage_counter_exists(user_id: str, period_key: str) -> bool:
    row = fetch_one_business(
        "SELECT 1 AS present FROM usage_counters WHERE user_id = ? AND period_key = ?",
        (user_id, period_key),
    )
    return row is not None


def seed_usage_count_if_missing(user_id: str, period_key: str, execution_count: int) -> tuple[int, bool]:
    def _transaction(conn) -> tuple[int, bool]:
        if is_postgres_business_db():
            row = conn.execute(
                """
                INSERT INTO usage_counters (user_id, period_key, execution_count, credit_used)
                VALUES (?, ?, ?, ?)
                ON CONFLICT (user_id, period_key) DO NOTHING
                RETURNING execution_count
                """,
                (user_id, period_key, int(execution_count), float(execution_count)),
            ).fetchone()
            if row:
                return int(row["execution_count"]), True
            existing = conn.execute(
                "SELECT execution_count FROM usage_counters WHERE user_id = ? AND period_key = ?",
                (user_id, period_key),
            ).fetchone()
            return int(existing["execution_count"]) if existing else int(execution_count), False

        existing = conn.execute(
            "SELECT execution_count FROM usage_counters WHERE user_id = ? AND period_key = ?",
            (user_id, period_key),
        ).fetchone()
        if existing:
            return int(existing["execution_count"]), False
        conn.execute(
            "INSERT INTO usage_counters (user_id, period_key, execution_count, credit_used) VALUES (?, ?, ?, ?)",
            (user_id, period_key, int(execution_count), float(execution_count)),
        )
        return int(execution_count), True

    return run_business_transaction(_transaction)


def get_usage_count(user_id: str, period_key: str) -> int:
    row = fetch_one_business(
        "SELECT execution_count FROM usage_counters WHERE user_id = ? AND period_key = ?",
        (user_id, period_key),
    )
    return int(row["execution_count"]) if row else 0


def get_credit_used(user_id: str, period_key: str) -> float:
    row = fetch_one_business(
        "SELECT credit_used FROM usage_counters WHERE user_id = ? AND period_key = ?",
        (user_id, period_key),
    )
    return float(row["credit_used"]) if row and row["credit_used"] is not None else 0.0


def increment_usage(user_id: str, period_key: str, *, credit_delta: float = 0.0, increment_execution_count: bool = True) -> dict:
    def _transaction(conn) -> dict:
        if is_postgres_business_db():
            row = conn.execute(
                """
                INSERT INTO usage_counters (user_id, period_key, execution_count, credit_used)
                VALUES (?, ?, ?, ?)
                ON CONFLICT (user_id, period_key)
                DO UPDATE SET
                    execution_count = usage_counters.execution_count + ?,
                    credit_used = usage_counters.credit_used + ?
                RETURNING execution_count, credit_used
                """,
                (
                    user_id,
                    period_key,
                    1 if increment_execution_count else 0,
                    float(credit_delta),
                    1 if increment_execution_count else 0,
                    float(credit_delta),
                ),
            ).fetchone()
            return {
                "execution_count": int(row["execution_count"]),
                "credit_used": float(row["credit_used"]),
            }

        row = conn.execute(
            "SELECT execution_count, credit_used FROM usage_counters WHERE user_id = ? AND period_key = ?",
            (user_id, period_key),
        ).fetchone()

        if row:
            new_count = int(row["execution_count"]) + (1 if increment_execution_count else 0)
            new_credit_used = float(row["credit_used"] or 0.0) + float(credit_delta)
            conn.execute(
                "UPDATE usage_counters SET execution_count = ?, credit_used = ? WHERE user_id = ? AND period_key = ?",
                (new_count, new_credit_used, user_id, period_key),
            )
        else:
            new_count = 1 if increment_execution_count else 0
            new_credit_used = float(credit_delta)
            conn.execute(
                "INSERT INTO usage_counters (user_id, period_key, execution_count, credit_used) VALUES (?, ?, ?, ?)",
                (user_id, period_key, new_count, new_credit_used),
            )

        return {
            "execution_count": new_count,
            "credit_used": float(new_credit_used),
        }

    return run_business_transaction(_transaction)
