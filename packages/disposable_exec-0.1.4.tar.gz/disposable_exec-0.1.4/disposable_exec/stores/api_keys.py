from __future__ import annotations

from typing import Any

from ..db import generate_api_key_record_id
from ..db_adapter import fetch_all_business, fetch_one_business, run_business_transaction


def load_api_keys() -> list[dict[str, Any]]:
    return fetch_all_business("SELECT * FROM api_keys")


def find_active_api_key_by_hash(api_key_hash: str) -> dict[str, Any] | None:
    return fetch_one_business(
        "SELECT * FROM api_keys WHERE api_key_hash = ? AND is_active = 1",
        (api_key_hash,),
    )


def create_api_key_record(
    *,
    user_id: str,
    name: str,
    api_key_hash: str,
    plan: str,
    is_active: int,
    created_at: str,
) -> dict[str, Any]:
    def _transaction(conn) -> dict[str, Any]:
        record = {
            "id": generate_api_key_record_id(conn),
            "user_id": user_id,
            "name": name,
            "api_key_hash": api_key_hash,
            "plan": plan,
            "is_active": is_active,
            "created_at": created_at,
        }
        conn.execute(
            """
            INSERT INTO api_keys (id, user_id, name, api_key_hash, plan, is_active, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                record["id"],
                record["user_id"],
                record["name"],
                record["api_key_hash"],
                record["plan"],
                record["is_active"],
                record["created_at"],
            ),
        )
        return record

    return run_business_transaction(_transaction)


def disable_api_key(key_id: str) -> bool:
    def _transaction(conn) -> bool:
        cur = conn.execute(
            "UPDATE api_keys SET is_active = 0 WHERE id = ?",
            (key_id,),
        )
        return cur.rowcount > 0

    return run_business_transaction(_transaction)


def list_api_keys_for_user(user_id: str) -> list[dict[str, Any]]:
    return fetch_all_business(
        """
        SELECT id, user_id, name, plan, is_active, created_at
        FROM api_keys
        WHERE user_id = ?
        ORDER BY created_at DESC
        """,
        (user_id,),
    )


def count_api_keys_for_user(user_id: str) -> int:
    row = fetch_one_business(
        """
        SELECT COUNT(*) AS count
        FROM api_keys
        WHERE user_id = ?
        """,
        (user_id,),
    )
    return int(row["count"]) if row else 0
