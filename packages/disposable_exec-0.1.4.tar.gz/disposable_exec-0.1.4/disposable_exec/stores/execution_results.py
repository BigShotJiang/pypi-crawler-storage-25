from __future__ import annotations

import threading
from time import perf_counter
from typing import Any

from ..db_adapter import fetch_one, run_in_transaction
from ..shared_execution_results import (
    SharedExecutionResultsUnavailable,
    get_shared_execution_result,
    is_shared_execution_results_backing_enabled,
    upsert_shared_execution_result,
)
from ..shared_execution_state import is_shared_execution_backing_enabled, upsert_shared_execution_status


def _log_execution_result_timing(*, execution_id: str, store_step: str, started_at: float):
    elapsed_ms = round((perf_counter() - started_at) * 1000, 1)
    print(
        f"EXECUTION_RESULT_STORE_TIMING execution_id={execution_id} store_step={store_step} elapsed_ms={elapsed_ms}",
        flush=True,
    )


def _using_shared_execution_results_backing() -> bool:
    return is_shared_execution_results_backing_enabled()


def _annotate_execution_result_source(row: dict[str, Any] | None, *, source: str) -> dict[str, Any] | None:
    if not row:
        return None
    item = dict(row)
    item["execution_result_source"] = source
    if source == "shared":
        item["execution_result_truth"] = "shared"
    elif source == "sqlite_fallback":
        item["execution_result_truth"] = "degraded_sqlite_fallback"
    else:
        item["execution_result_truth"] = "local_sqlite"
    return item


def _merge_execution_result_row(
    existing: dict[str, Any] | None,
    *,
    execution_id: str,
    key_id: str | None,
    user_id: str | None,
    completed_by_worker_id: str | None,
    stdout: str,
    stderr: str,
    exit_code: int | None,
    duration: float | int | None,
    created_at: str,
) -> dict[str, Any]:
    current = existing or {}
    return {
        "execution_id": execution_id,
        "key_id": key_id if key_id is not None else current.get("key_id"),
        "user_id": user_id if user_id is not None else current.get("user_id"),
        "completed_by_worker_id": (
            completed_by_worker_id
            if completed_by_worker_id is not None
            else current.get("completed_by_worker_id")
        ),
        "stdout": stdout,
        "stderr": stderr,
        "exit_code": exit_code,
        "duration": duration,
        "created_at": current.get("created_at") or created_at,
    }


def _sqlite_get_execution_result_row_with_conn(
    conn,
    execution_id: str,
    key_id: str | None = None,
    user_id: str | None = None,
) -> dict[str, Any] | None:
    query = """
        SELECT execution_id, key_id, user_id, completed_by_worker_id, stdout, stderr, exit_code, duration, created_at
        FROM execution_results
        WHERE execution_id = ?
    """
    params: list[Any] = [execution_id]

    if key_id is not None and user_id is not None:
        query += " AND (key_id = ? OR user_id = ?)"
        params.extend([key_id, user_id])
    elif key_id is not None:
        query += " AND key_id = ?"
        params.append(key_id)
    elif user_id is not None:
        query += " AND user_id = ?"
        params.append(user_id)

    row = conn.execute(query, tuple(params)).fetchone()
    return dict(row) if row else None


def _sqlite_get_execution_result_row(
    execution_id: str,
    key_id: str | None = None,
    user_id: str | None = None,
) -> dict[str, Any] | None:
    query = """
        SELECT execution_id, key_id, user_id, completed_by_worker_id, stdout, stderr, exit_code, duration, created_at
        FROM execution_results
        WHERE execution_id = ?
    """
    params: list[Any] = [execution_id]

    if key_id is not None and user_id is not None:
        query += " AND (key_id = ? OR user_id = ?)"
        params.extend([key_id, user_id])
    elif key_id is not None:
        query += " AND key_id = ?"
        params.append(key_id)
    elif user_id is not None:
        query += " AND user_id = ?"
        params.append(user_id)

    return fetch_one(query, tuple(params))


def _shared_get_execution_result_row(
    execution_id: str,
    key_id: str | None = None,
    user_id: str | None = None,
) -> dict[str, Any] | None:
    row = get_shared_execution_result(execution_id)
    if not row:
        return None
    if key_id is not None and user_id is not None:
        if row.get("key_id") != key_id and row.get("user_id") != user_id:
            return None
    elif key_id is not None:
        if row.get("key_id") != key_id:
            return None
    elif user_id is not None:
        if row.get("user_id") != user_id:
            return None
    return row


def _build_terminal_execution_status_row(
    conn,
    *,
    execution_id: str,
    key_id: str | None,
    user_id: str | None,
    assigned_worker_id: str | None,
    completed_by_worker_id: str | None,
    terminal_status: str,
    created_at: str,
    updated_at: str,
    claim_owner_worker_id: str | None,
    claim_token: str | None,
    claim_marked_at: str | None,
) -> dict[str, Any]:
    status_row = conn.execute(
        """
        SELECT created_at, recovery_attempt_count, orphaned_at
        FROM execution_status
        WHERE execution_id = ?
        LIMIT 1
        """,
        (execution_id,),
    ).fetchone()
    return {
        "execution_id": execution_id,
        "key_id": key_id,
        "user_id": user_id,
        "assigned_worker_id": assigned_worker_id,
        "completed_by_worker_id": completed_by_worker_id,
        "status": terminal_status,
        "created_at": (status_row["created_at"] if status_row else None) or created_at,
        "updated_at": updated_at,
        "claim_owner_worker_id": claim_owner_worker_id,
        "claim_token": claim_token,
        "claim_marked_at": claim_marked_at,
        "lease_expires_at": None,
        "last_lease_renewed_at": None,
        "recovery_attempt_count": status_row["recovery_attempt_count"] if status_row else None,
        "orphaned_at": status_row["orphaned_at"] if status_row else None,
        "requeueable": False,
    }


def _defer_shared_execution_result_upsert(row: dict[str, Any]) -> None:
    def _write():
        started_at = perf_counter()
        try:
            upsert_shared_execution_result(row)
            _log_execution_result_timing(
                execution_id=row.get("execution_id"),
                store_step="shared_result_upsert_async",
                started_at=started_at,
            )
        except SharedExecutionResultsUnavailable as exc:
            print(
                f"SHARED_RESULT_ASYNC_UPSERT_FAILED execution_id={row.get('execution_id', '')} detail={exc}",
                flush=True,
            )

    threading.Thread(
        target=_write,
        name=f"shared-result-upsert-{row.get('execution_id', '')}",
        daemon=True,
    ).start()


def _shared_write_terminal_status(terminal_status_row: dict[str, Any]) -> None:
    try:
        upsert_shared_execution_status(terminal_status_row)
    except Exception as exc:
        raise SharedExecutionResultsUnavailable(str(exc)) from exc


def _get_preferred_execution_result_row(
    execution_id: str,
    key_id: str | None = None,
    user_id: str | None = None,
) -> tuple[dict[str, Any] | None, str]:
    if _using_shared_execution_results_backing():
        try:
            shared_row = _shared_get_execution_result_row(execution_id, key_id=key_id, user_id=user_id)
            if shared_row:
                return shared_row, "shared"
            return _sqlite_get_execution_result_row(
                execution_id,
                key_id=key_id,
                user_id=user_id,
            ), "sqlite_fallback"
        except SharedExecutionResultsUnavailable:
            return _sqlite_get_execution_result_row(
                execution_id,
                key_id=key_id,
                user_id=user_id,
            ), "sqlite_fallback"

    return _sqlite_get_execution_result_row(
        execution_id,
        key_id=key_id,
        user_id=user_id,
    ), "sqlite"


def _get_preferred_execution_result_row_with_conn(
    conn,
    execution_id: str,
    key_id: str | None = None,
    user_id: str | None = None,
) -> tuple[dict[str, Any] | None, str]:
    if _using_shared_execution_results_backing():
        try:
            shared_row = _shared_get_execution_result_row(execution_id, key_id=key_id, user_id=user_id)
            if shared_row:
                return shared_row, "shared"
            return _sqlite_get_execution_result_row_with_conn(
                conn,
                execution_id,
                key_id=key_id,
                user_id=user_id,
            ), "sqlite_fallback"
        except SharedExecutionResultsUnavailable:
            return _sqlite_get_execution_result_row_with_conn(
                conn,
                execution_id,
                key_id=key_id,
                user_id=user_id,
            ), "sqlite_fallback"

    return _sqlite_get_execution_result_row_with_conn(
        conn,
        execution_id,
        key_id=key_id,
        user_id=user_id,
    ), "sqlite"


def _sync_shared_execution_result_completed_by_worker_id(
    execution_id: str,
    completed_by_worker_id: str | None,
    key_id: str | None = None,
    user_id: str | None = None,
) -> None:
    if not _using_shared_execution_results_backing() or not completed_by_worker_id:
        return
    try:
        existing = _shared_get_execution_result_row(execution_id, key_id=key_id, user_id=user_id)
        if not existing:
            return
        if existing.get("completed_by_worker_id") == completed_by_worker_id:
            return
        updated = dict(existing)
        updated["completed_by_worker_id"] = completed_by_worker_id
        upsert_shared_execution_result(updated)
    except SharedExecutionResultsUnavailable:
        return


def _resolve_completed_by_worker_id(conn, execution_id: str, completed_by_worker_id: str | None) -> str | None:
    if completed_by_worker_id is not None:
        return completed_by_worker_id

    row = conn.execute(
        """
        SELECT completed_by_worker_id, assigned_worker_id
        FROM execution_status
        WHERE execution_id = ?
        LIMIT 1
        """,
        (execution_id,),
    ).fetchone()
    if not row:
        return None
    return row["completed_by_worker_id"] or row["assigned_worker_id"]


def _backfill_completed_by_worker_id(conn, execution_id: str, completed_by_worker_id: str | None) -> None:
    resolved_completed_by_worker_id = _resolve_completed_by_worker_id(conn, execution_id, completed_by_worker_id)
    if not resolved_completed_by_worker_id:
        return

    conn.execute(
        """
        UPDATE execution_status
        SET completed_by_worker_id = ?
        WHERE execution_id = ? AND (completed_by_worker_id IS NULL OR completed_by_worker_id = '')
        """,
        (resolved_completed_by_worker_id, execution_id),
    )


def _persist_execution_results_completed_by_worker_id(conn, execution_id: str, completed_by_worker_id: str | None) -> None:
    conn.execute(
        """
        UPDATE execution_results
        SET completed_by_worker_id = COALESCE(
            completed_by_worker_id,
            ?,
            (
                SELECT COALESCE(execution_status.completed_by_worker_id, execution_status.assigned_worker_id)
                FROM execution_status
                WHERE execution_status.execution_id = ?
                LIMIT 1
            )
        )
        WHERE execution_id = ?
        """,
        (completed_by_worker_id, execution_id, execution_id),
    )


def save_execution_result(
    *,
    execution_id: str,
    key_id: str | None,
    user_id: str | None,
    completed_by_worker_id: str | None,
    stdout: str,
    stderr: str,
    exit_code: int | None,
    duration: float | int | None,
    created_at: str,
    terminal_status: str | None = None,
    assigned_worker_id: str | None = None,
    claim_owner_worker_id: str | None = None,
    claim_token: str | None = None,
    claim_marked_at: str | None = None,
) -> bool:
    def _transaction(conn) -> tuple[bool, dict[str, Any] | None]:
        shared_terminal_status_written = False
        deferred_shared_result_row: dict[str, Any] | None = None
        resolve_worker_started_at = perf_counter()
        resolved_completed_by_worker_id = _resolve_completed_by_worker_id(conn, execution_id, completed_by_worker_id)
        _log_execution_result_timing(
            execution_id=execution_id,
            store_step="resolve_completed_by_worker_id",
            started_at=resolve_worker_started_at,
        )

        if _using_shared_execution_results_backing():
            try:
                shared_existing_started_at = perf_counter()
                # Prefer the local sqlite row for merge context on the hot save
                # path. Shared result truth is still written, but this avoids a
                # read-before-write round-trip when the local writer already has
                # the authoritative row context.
                shared_existing = _sqlite_get_execution_result_row_with_conn(
                    conn,
                    execution_id,
                    key_id=key_id,
                    user_id=user_id,
                )
                _log_execution_result_timing(
                    execution_id=execution_id,
                    store_step="load_existing_shared_result_context",
                    started_at=shared_existing_started_at,
                )
                merged_row = _merge_execution_result_row(
                    shared_existing,
                    execution_id=execution_id,
                    key_id=key_id,
                    user_id=user_id,
                    completed_by_worker_id=resolved_completed_by_worker_id,
                    stdout=stdout,
                    stderr=stderr,
                    exit_code=exit_code,
                    duration=duration,
                    created_at=created_at,
                )
                if terminal_status and is_shared_execution_backing_enabled():
                    terminal_status_row = _build_terminal_execution_status_row(
                        conn,
                        execution_id=execution_id,
                        key_id=key_id,
                        user_id=user_id,
                        assigned_worker_id=assigned_worker_id,
                        completed_by_worker_id=resolved_completed_by_worker_id,
                        terminal_status=terminal_status,
                        created_at=created_at,
                        updated_at=created_at,
                        claim_owner_worker_id=claim_owner_worker_id,
                        claim_token=claim_token,
                        claim_marked_at=claim_marked_at,
                    )
                shared_upsert_started_at = perf_counter()
                if terminal_status and is_shared_execution_backing_enabled():
                    _shared_write_terminal_status(terminal_status_row)
                    shared_terminal_status_written = True
                    deferred_shared_result_row = dict(merged_row)
                    shared_store_step = "shared_terminal_status_upsert"
                else:
                    upsert_shared_execution_result(merged_row)
                    shared_store_step = "shared_result_upsert"
                _log_execution_result_timing(
                    execution_id=execution_id,
                    store_step=shared_store_step,
                    started_at=shared_upsert_started_at,
                )
            except SharedExecutionResultsUnavailable:
                pass

        sqlite_result_started_at = perf_counter()
        conn.execute(
            """
            INSERT INTO execution_results
            (execution_id, key_id, user_id, completed_by_worker_id, stdout, stderr, exit_code, duration, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(execution_id) DO UPDATE SET
                key_id = COALESCE(excluded.key_id, execution_results.key_id),
                user_id = COALESCE(excluded.user_id, execution_results.user_id),
                completed_by_worker_id = COALESCE(
                    excluded.completed_by_worker_id,
                    (
                        SELECT COALESCE(execution_status.completed_by_worker_id, execution_status.assigned_worker_id)
                        FROM execution_status
                        WHERE execution_status.execution_id = excluded.execution_id
                        LIMIT 1
                    ),
                    execution_results.completed_by_worker_id
                ),
                stdout = excluded.stdout,
                stderr = excluded.stderr,
                exit_code = excluded.exit_code,
                duration = excluded.duration,
                created_at = COALESCE(execution_results.created_at, excluded.created_at)
            """,
            (
                execution_id,
                key_id,
                user_id,
                resolved_completed_by_worker_id,
                stdout,
                stderr,
                exit_code,
                duration,
                created_at,
            ),
        )
        _log_execution_result_timing(
            execution_id=execution_id,
            store_step="sqlite_result_upsert",
            started_at=sqlite_result_started_at,
        )

        if resolved_completed_by_worker_id is None:
            persist_result_worker_started_at = perf_counter()
            _persist_execution_results_completed_by_worker_id(conn, execution_id, resolved_completed_by_worker_id)
            _log_execution_result_timing(
                execution_id=execution_id,
                store_step="persist_result_completed_by_worker_id",
                started_at=persist_result_worker_started_at,
            )
        backfill_status_started_at = perf_counter()
        _backfill_completed_by_worker_id(conn, execution_id, resolved_completed_by_worker_id)
        _log_execution_result_timing(
            execution_id=execution_id,
            store_step="backfill_status_completed_by_worker_id",
            started_at=backfill_status_started_at,
        )

        # The shared result row was already written above with the resolved
        # completed_by_worker_id, so skip the redundant read-modify-write sync
        # on the hot save path.

        return shared_terminal_status_written, deferred_shared_result_row

    shared_terminal_status_written, deferred_shared_result_row = run_in_transaction(_transaction)
    if deferred_shared_result_row is not None:
        _defer_shared_execution_result_upsert(deferred_shared_result_row)
    return bool(shared_terminal_status_written)


def get_execution_result_row(
    execution_id: str,
    key_id: str | None = None,
    user_id: str | None = None,
) -> dict[str, Any] | None:
    row, source = _get_preferred_execution_result_row(
        execution_id,
        key_id=key_id,
        user_id=user_id,
    )
    return _annotate_execution_result_source(row, source=source)


def load_execution_result(
    execution_id: str,
    key_id: str | None = None,
    user_id: str | None = None,
) -> dict[str, Any] | None:
    def _transaction(conn) -> dict[str, Any] | None:
        row, source = _get_preferred_execution_result_row_with_conn(
            conn,
            execution_id,
            key_id=key_id,
            user_id=user_id,
        )

        if not row:
            return None

        resolved_completed_by_worker_id = _resolve_completed_by_worker_id(
            conn,
            execution_id,
            row["completed_by_worker_id"],
        )
        if resolved_completed_by_worker_id and not row["completed_by_worker_id"]:
            _persist_execution_results_completed_by_worker_id(conn, execution_id, resolved_completed_by_worker_id)
            _backfill_completed_by_worker_id(conn, execution_id, resolved_completed_by_worker_id)
            _sync_shared_execution_result_completed_by_worker_id(
                execution_id,
                resolved_completed_by_worker_id,
                key_id=key_id,
                user_id=user_id,
            )

        result = dict(row)
        result["completed_by_worker_id"] = resolved_completed_by_worker_id
        return _annotate_execution_result_source(result, source=source)

    return run_in_transaction(_transaction)
