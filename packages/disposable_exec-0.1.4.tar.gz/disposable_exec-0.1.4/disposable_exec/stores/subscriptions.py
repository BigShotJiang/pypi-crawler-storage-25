from __future__ import annotations

from typing import Any

from ..db import is_postgres_business_db
from ..db_adapter import fetch_all_business, fetch_one_business, run_business_transaction


def get_subscription_period_bounds(provider: str, provider_subscription_id: str) -> dict[str, Any] | None:
    return fetch_one_business(
        """
        SELECT period_start, period_end
        FROM subscriptions
        WHERE provider = ? AND provider_subscription_id = ?
        LIMIT 1
        """,
        (provider, provider_subscription_id),
    )


def upsert_subscription_record(
    *,
    subscription_id: str | None,
    user_id: str,
    provider: str,
    provider_subscription_id: str,
    provider_customer_id: str | None,
    plan: str,
    status: str,
    quota_monthly: int,
    period_start: str | None,
    period_end: str | None,
    current_time: str,
) -> str:
    def _transaction(conn) -> str:
        if is_postgres_business_db():
            resolved_subscription_id = subscription_id or f"sub_{provider}_{provider_subscription_id}"
            row = conn.execute(
                """
                INSERT INTO subscriptions
                (
                    id, user_id, provider, provider_subscription_id, provider_customer_id, plan, status,
                    quota_monthly, period_start, period_end, created_at, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT (provider_subscription_id) DO UPDATE SET
                    user_id = EXCLUDED.user_id,
                    provider_customer_id = COALESCE(EXCLUDED.provider_customer_id, subscriptions.provider_customer_id),
                    plan = EXCLUDED.plan,
                    status = EXCLUDED.status,
                    quota_monthly = EXCLUDED.quota_monthly,
                    period_start = COALESCE(EXCLUDED.period_start, subscriptions.period_start),
                    period_end = COALESCE(EXCLUDED.period_end, subscriptions.period_end),
                    updated_at = EXCLUDED.updated_at
                RETURNING id
                """,
                (
                    resolved_subscription_id,
                    user_id,
                    provider,
                    provider_subscription_id,
                    provider_customer_id,
                    plan,
                    status,
                    quota_monthly,
                    period_start,
                    period_end,
                    current_time,
                    current_time,
                ),
            ).fetchone()
            return row["id"]

        existing = conn.execute(
            """
            SELECT id, period_start, period_end
            FROM subscriptions
            WHERE provider = ? AND provider_subscription_id = ?
            """,
            (provider, provider_subscription_id),
        ).fetchone()

        if existing:
            resolved_subscription_id = existing["id"]
            resolved_period_start = period_start if period_start is not None else existing["period_start"]
            resolved_period_end = period_end if period_end is not None else existing["period_end"]
            conn.execute(
                """
                UPDATE subscriptions
                SET user_id = ?,
                    provider_customer_id = COALESCE(?, provider_customer_id),
                    plan = ?,
                    status = ?,
                    quota_monthly = ?,
                    period_start = ?,
                    period_end = ?,
                    updated_at = ?
                WHERE id = ?
                """,
                (
                    user_id,
                    provider_customer_id,
                    plan,
                    status,
                    quota_monthly,
                    resolved_period_start,
                    resolved_period_end,
                    current_time,
                    resolved_subscription_id,
                ),
            )
            return resolved_subscription_id

        resolved_subscription_id = subscription_id or f"sub_{provider}_{provider_subscription_id}"
        conn.execute(
            """
            INSERT INTO subscriptions
            (
                id, user_id, provider, provider_subscription_id, provider_customer_id, plan, status,
                quota_monthly, period_start, period_end, created_at, updated_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                resolved_subscription_id,
                user_id,
                provider,
                provider_subscription_id,
                provider_customer_id,
                plan,
                status,
                quota_monthly,
                period_start,
                period_end,
                current_time,
                current_time,
            ),
        )
        return resolved_subscription_id

    return run_business_transaction(_transaction)


def sync_api_keys_plan_for_user(user_id: str, plan: str) -> None:
    def _transaction(conn) -> None:
        conn.execute(
            "UPDATE api_keys SET plan = ? WHERE user_id = ?",
            (plan, user_id),
        )

    run_business_transaction(_transaction)


def get_latest_active_paid_subscription_for_user(user_id: str) -> dict[str, Any] | None:
    return fetch_one_business(
        """
        SELECT id, user_id, provider, provider_subscription_id, provider_customer_id, plan, status,
               quota_monthly, period_start, period_end, created_at, updated_at
        FROM subscriptions
        WHERE user_id = ?
          AND lower(coalesce(status, '')) = 'active'
          AND lower(coalesce(plan, '')) <> 'free'
        ORDER BY updated_at DESC, created_at DESC
        LIMIT 1
        """,
        (user_id,),
    )


def get_preferred_subscription_for_user(user_id: str) -> dict[str, Any] | None:
    return fetch_one_business(
        """
        SELECT id, user_id, provider, provider_subscription_id, provider_customer_id, plan, status,
               quota_monthly, period_start, period_end, created_at, updated_at
        FROM subscriptions
        WHERE user_id = ?
        ORDER BY
            CASE
                WHEN lower(coalesce(status, '')) = 'active' AND lower(coalesce(plan, '')) <> 'free' THEN 0
                ELSE 1
            END,
            updated_at DESC,
            created_at DESC
        LIMIT 1
        """,
        (user_id,),
    )


def get_latest_subscription_for_user(user_id: str) -> dict[str, Any] | None:
    return fetch_one_business(
        """
        SELECT id, user_id, provider, provider_subscription_id, provider_customer_id, plan, status,
               quota_monthly, period_start, period_end, created_at, updated_at
        FROM subscriptions
        WHERE user_id = ?
        ORDER BY updated_at DESC, created_at DESC
        LIMIT 1
        """,
        (user_id,),
    )


def get_subscription_for_onboarding_context(
    *,
    user_id: str,
    provider: str,
    provider_subscription_id: str,
) -> dict[str, Any] | None:
    return fetch_one_business(
        """
        SELECT id, user_id, provider, provider_subscription_id, provider_customer_id, plan, status,
               quota_monthly, period_start, period_end, created_at, updated_at
        FROM subscriptions
        WHERE user_id = ? AND provider = ? AND provider_subscription_id = ?
        ORDER BY updated_at DESC, created_at DESC
        LIMIT 1
        """,
        (user_id, provider, provider_subscription_id),
    )


def find_subscription_for_recovery(
    *,
    provider: str | None = None,
    provider_subscription_id: str | None = None,
    provider_customer_id: str | None = None,
    user_id: str | None = None,
) -> dict[str, Any] | None:
    query = """
        SELECT id, user_id, provider, provider_subscription_id, provider_customer_id, plan, status,
               quota_monthly, period_start, period_end, created_at, updated_at
        FROM subscriptions
        WHERE 1 = 1
    """
    params: list[str] = []

    if user_id:
        query += " AND user_id = ?"
        params.append(user_id)
    if provider:
        query += " AND provider = ?"
        params.append(provider)
    if provider_subscription_id:
        query += " AND provider_subscription_id = ?"
        params.append(provider_subscription_id)
    if provider_customer_id:
        query += " AND provider_customer_id = ?"
        params.append(provider_customer_id)

    query += " ORDER BY updated_at DESC, created_at DESC LIMIT 1"
    return fetch_one_business(query, tuple(params))


def list_subscriptions() -> list[dict[str, Any]]:
    return fetch_all_business(
        """
        SELECT id, user_id, provider, provider_subscription_id, plan, status,
               quota_monthly, period_start, period_end, created_at, updated_at
        FROM subscriptions
        ORDER BY updated_at DESC, created_at DESC
        """
    )
