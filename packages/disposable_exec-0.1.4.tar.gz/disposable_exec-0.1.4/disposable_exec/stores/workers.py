from __future__ import annotations

import hashlib
import json
import os
import secrets
from datetime import datetime
from time import perf_counter

from ..db_adapter import run_in_transaction
from .execution_status import get_active_assignment_counts_by_worker
from ..shared_worker_state import (
    SharedWorkerStateUnavailable,
    get_shared_app_state,
    get_shared_worker,
    get_shared_worker_by_auth_token_hash,
    is_shared_worker_backing_enabled,
    list_shared_workers,
    set_shared_app_state,
    upsert_shared_worker,
)


WORKER_HEARTBEAT_MAX_AGE_SECONDS = max(30, int(os.getenv("WORKER_HEARTBEAT_MAX_AGE_SECONDS", "120")))
NON_ASSIGNABLE_WORKER_STATUSES = {"disabled", "draining", "offline"}
LOCAL_WORKER_ID = os.getenv("DISPOSABLE_EXEC_WORKER_ID", "local-worker").strip() or "local-worker"
LOCAL_WORKER_SNAPSHOT_APP_STATE_KEY = f"worker_snapshot:{LOCAL_WORKER_ID}"


def _log_worker_summary_timing(*, summary_step: str, started_at: float) -> None:
    elapsed_ms = round((perf_counter() - started_at) * 1000, 1)
    print(f"WORKER_SUMMARY_TIMING summary_step={summary_step} elapsed_ms={elapsed_ms}", flush=True)


def _log_local_worker_lookup_timing(*, lookup_step: str, started_at: float, worker_id: str | None = None) -> None:
    elapsed_ms = round((perf_counter() - started_at) * 1000, 1)
    print(
        f"LOCAL_WORKER_LOOKUP_TIMING worker_id={worker_id or ''} lookup_step={lookup_step} elapsed_ms={elapsed_ms}",
        flush=True,
    )


def _set_local_worker_snapshot(worker: dict | None) -> None:
    if not worker or str(worker.get("id") or "").strip() != LOCAL_WORKER_ID:
        return
    _set_app_state(
        LOCAL_WORKER_SNAPSHOT_APP_STATE_KEY,
        json.dumps(worker, separators=(",", ":"), sort_keys=True),
    )


def _get_local_worker_snapshot(worker_id: str) -> dict | None:
    if not worker_id or worker_id != LOCAL_WORKER_ID:
        return None
    snapshot_started_at = perf_counter()
    row = _get_app_state(LOCAL_WORKER_SNAPSHOT_APP_STATE_KEY)
    _log_local_worker_lookup_timing(
        worker_id=worker_id,
        lookup_step="local_sqlite_snapshot_lookup",
        started_at=snapshot_started_at,
    )
    if not row or not row.get("value"):
        return None
    try:
        return json.loads(row["value"])
    except (TypeError, ValueError, json.JSONDecodeError):
        return None


def _ensure_app_state_table(conn) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS app_state (
            key TEXT PRIMARY KEY,
            value TEXT,
            updated_at TEXT NOT NULL
        )
        """
    )


def _ensure_workers_table(conn) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS workers (
            id TEXT PRIMARY KEY,
            label TEXT NOT NULL,
            auth_token_hash TEXT UNIQUE,
            status TEXT NOT NULL,
            last_heartbeat_at TEXT,
            max_concurrency INTEGER NOT NULL DEFAULT 1,
            enabled INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL
        )
        """
    )


def _ensure_operational_events_table(conn) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS operational_events (
            id TEXT PRIMARY KEY,
            category TEXT NOT NULL,
            event TEXT NOT NULL,
            severity TEXT NOT NULL,
            provider TEXT,
            user_id TEXT,
            subscription_id TEXT,
            worker_id TEXT,
            execution_id TEXT,
            detail TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_operational_events_created_at ON operational_events(created_at DESC)"
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_operational_events_category_event ON operational_events(category, event)"
    )


def _set_app_state(key: str, value: str) -> None:
    now = datetime.utcnow().isoformat() + "Z"

    def _transaction(conn) -> None:
        _ensure_app_state_table(conn)
        conn.execute(
            """
            INSERT INTO app_state (key, value, updated_at)
            VALUES (?, ?, ?)
            ON CONFLICT(key) DO UPDATE SET
                value = excluded.value,
                updated_at = excluded.updated_at
            """,
            (key, value, now),
        )

    run_in_transaction(_transaction)


def _get_app_state(key: str) -> dict | None:
    def _transaction(conn) -> dict | None:
        _ensure_app_state_table(conn)
        row = conn.execute(
            """
            SELECT key, value, updated_at
            FROM app_state
            WHERE key = ?
            LIMIT 1
            """,
            (key,),
        ).fetchone()
        return dict(row) if row else None

    return run_in_transaction(_transaction)


def _using_shared_worker_backing() -> bool:
    return is_shared_worker_backing_enabled()


def _with_shared_worker_fallback(shared_operation, sqlite_operation):
    if not _using_shared_worker_backing():
        return sqlite_operation()
    try:
        return shared_operation()
    except SharedWorkerStateUnavailable:
        return sqlite_operation()


def _shared_worker_source_label(shared_available: bool) -> str:
    if not _using_shared_worker_backing():
        return "sqlite"
    return "shared" if shared_available else "sqlite_fallback"


def _coerce_worker_row(row: dict | None) -> dict | None:
    if not row:
        return None
    item = dict(row)
    item["enabled"] = 1 if bool(item.get("enabled")) else 0
    item["max_concurrency"] = max(1, int(item.get("max_concurrency") or 1))
    return item


def _annotate_worker_source(row: dict | None, *, source: str) -> dict | None:
    if not row:
        return None
    item = dict(row)
    item["worker_state_source"] = source
    return item


def _get_worker_from_shared_or_fallback(worker_id: str) -> tuple[dict | None, str]:
    if not _using_shared_worker_backing():
        return _annotate_worker_source(_sqlite_get_worker(worker_id), source="sqlite"), "sqlite"
    try:
        return _annotate_worker_source(_shared_get_worker(worker_id), source="shared"), "shared"
    except SharedWorkerStateUnavailable:
        return _annotate_worker_source(_sqlite_get_worker(worker_id), source="sqlite_fallback"), "sqlite_fallback"


def _list_workers_from_shared_or_fallback() -> tuple[list[dict], str]:
    if not _using_shared_worker_backing():
        rows = [_annotate_worker_source(row, source="sqlite") for row in _sqlite_list_workers()]
        return [row for row in rows if row], "sqlite"
    try:
        rows = [_annotate_worker_source(row, source="shared") for row in _shared_list_workers()]
        return [row for row in rows if row], "shared"
    except SharedWorkerStateUnavailable:
        rows = [_annotate_worker_source(row, source="sqlite_fallback") for row in _sqlite_list_workers()]
        return [row for row in rows if row], "sqlite_fallback"


def _sqlite_ensure_worker_record(
    worker_id: str,
    *,
    label: str | None,
    max_concurrency: int,
    enabled: bool,
    status: str,
) -> None:
    now = datetime.utcnow().isoformat() + "Z"

    def _transaction(conn) -> None:
        _ensure_workers_table(conn)
        conn.execute(
            """
            INSERT INTO workers (id, label, auth_token_hash, status, last_heartbeat_at, max_concurrency, enabled, created_at)
            VALUES (?, ?, NULL, ?, NULL, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                label = COALESCE(excluded.label, workers.label),
                status = excluded.status,
                max_concurrency = excluded.max_concurrency,
                enabled = excluded.enabled
            """,
            (worker_id, label or worker_id, status, max(1, int(max_concurrency or 1)), 1 if enabled else 0, now),
        )

    run_in_transaction(_transaction)


def _shared_ensure_worker_record(
    worker_id: str,
    *,
    label: str | None,
    max_concurrency: int,
    enabled: bool,
    status: str,
) -> None:
    existing = _coerce_worker_row(get_shared_worker(worker_id)) or {}
    now = existing.get("created_at") or datetime.utcnow().isoformat() + "Z"
    upsert_shared_worker(
        {
            "id": worker_id,
            "label": label or worker_id,
            "auth_token_hash": existing.get("auth_token_hash"),
            "status": status,
            "last_heartbeat_at": existing.get("last_heartbeat_at"),
            "max_concurrency": max(1, int(max_concurrency or 1)),
            "enabled": 1 if enabled else 0,
            "created_at": now,
        }
    )


def _sqlite_register_worker_with_token(
    worker_id: str,
    *,
    label: str,
    auth_token: str,
    max_concurrency: int,
    enabled: bool,
    status: str,
) -> dict:
    now = datetime.utcnow().isoformat() + "Z"

    def _transaction(conn) -> None:
        _ensure_workers_table(conn)
        conn.execute(
            """
            INSERT INTO workers (id, label, auth_token_hash, status, last_heartbeat_at, max_concurrency, enabled, created_at)
            VALUES (?, ?, ?, ?, NULL, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                label = excluded.label,
                auth_token_hash = excluded.auth_token_hash,
                status = excluded.status,
                max_concurrency = excluded.max_concurrency,
                enabled = excluded.enabled
            """,
            (
                worker_id,
                label,
                hash_worker_token(auth_token),
                status,
                max(1, int(max_concurrency or 1)),
                1 if enabled else 0,
                now,
            ),
        )

    run_in_transaction(_transaction)
    return {
        "id": worker_id,
        "label": label,
        "status": status,
        "max_concurrency": max(1, int(max_concurrency or 1)),
        "enabled": bool(enabled),
    }


def _shared_register_worker_with_token(
    worker_id: str,
    *,
    label: str,
    auth_token: str,
    max_concurrency: int,
    enabled: bool,
    status: str,
) -> dict:
    existing = _coerce_worker_row(get_shared_worker(worker_id)) or {}
    now = existing.get("created_at") or datetime.utcnow().isoformat() + "Z"
    upsert_shared_worker(
        {
            "id": worker_id,
            "label": label,
            "auth_token_hash": hash_worker_token(auth_token),
            "status": status,
            "last_heartbeat_at": existing.get("last_heartbeat_at"),
            "max_concurrency": max(1, int(max_concurrency or 1)),
            "enabled": 1 if enabled else 0,
            "created_at": now,
        }
    )
    return {
        "id": worker_id,
        "label": label,
        "status": status,
        "max_concurrency": max(1, int(max_concurrency or 1)),
        "enabled": bool(enabled),
    }


def _sqlite_register_worker(label: str, max_concurrency: int, enabled: bool) -> dict:
    raw_token = secrets.token_urlsafe(32)
    worker_id = f"wrk_{secrets.token_hex(8)}"
    now = datetime.utcnow().isoformat() + "Z"

    def _transaction(conn) -> None:
        _ensure_workers_table(conn)
        conn.execute(
            """
            INSERT INTO workers (id, label, auth_token_hash, status, last_heartbeat_at, max_concurrency, enabled, created_at)
            VALUES (?, ?, ?, ?, NULL, ?, ?, ?)
            """,
            (
                worker_id,
                label,
                hash_worker_token(raw_token),
                "registered",
                max(1, int(max_concurrency or 1)),
                1 if enabled else 0,
                now,
            ),
        )

    run_in_transaction(_transaction)
    return {
        "id": worker_id,
        "label": label,
        "max_concurrency": max(1, int(max_concurrency or 1)),
        "enabled": bool(enabled),
        "created_at": now,
        "raw_token": raw_token,
    }


def _shared_register_worker(label: str, max_concurrency: int, enabled: bool) -> dict:
    raw_token = secrets.token_urlsafe(32)
    worker_id = f"wrk_{secrets.token_hex(8)}"
    now = datetime.utcnow().isoformat() + "Z"
    upsert_shared_worker(
        {
            "id": worker_id,
            "label": label,
            "auth_token_hash": hash_worker_token(raw_token),
            "status": "registered",
            "last_heartbeat_at": None,
            "max_concurrency": max(1, int(max_concurrency or 1)),
            "enabled": 1 if enabled else 0,
            "created_at": now,
        }
    )
    return {
        "id": worker_id,
        "label": label,
        "max_concurrency": max(1, int(max_concurrency or 1)),
        "enabled": bool(enabled),
        "created_at": now,
        "raw_token": raw_token,
    }


def _sqlite_authenticate_worker_token(raw_token: str) -> dict | None:
    token_hash = hash_worker_token(raw_token)

    def _transaction(conn) -> dict | None:
        _ensure_workers_table(conn)
        row = conn.execute(
            """
            SELECT id, label, status, last_heartbeat_at, max_concurrency, enabled, created_at
            FROM workers
            WHERE auth_token_hash = ? AND enabled = 1
            LIMIT 1
            """,
            (token_hash,),
        ).fetchone()
        return dict(row) if row else None

    return run_in_transaction(_transaction)


def _shared_authenticate_worker_token(raw_token: str) -> dict | None:
    worker = _coerce_worker_row(get_shared_worker_by_auth_token_hash(hash_worker_token(raw_token)))
    if not worker or int(worker.get("enabled", 0)) != 1:
        return None
    return {
        "id": worker["id"],
        "label": worker["label"],
        "status": worker["status"],
        "last_heartbeat_at": worker.get("last_heartbeat_at"),
        "max_concurrency": worker["max_concurrency"],
        "enabled": worker["enabled"],
        "created_at": worker.get("created_at"),
    }


def _sqlite_authenticate_worker(worker_id: str, raw_token: str) -> dict | None:
    def _transaction(conn) -> dict | None:
        _ensure_workers_table(conn)
        row = conn.execute(
            """
            SELECT id, label, status, last_heartbeat_at, max_concurrency, enabled, created_at
            FROM workers
            WHERE id = ? AND auth_token_hash = ? AND enabled = 1
            LIMIT 1
            """,
            (worker_id, hash_worker_token(raw_token)),
        ).fetchone()
        return dict(row) if row else None

    return run_in_transaction(_transaction)


def _shared_authenticate_worker(worker_id: str, raw_token: str) -> dict | None:
    worker = _coerce_worker_row(get_shared_worker(worker_id))
    if not worker:
        return None
    if str(worker.get("auth_token_hash") or "") != hash_worker_token(raw_token):
        return None
    if int(worker.get("enabled", 0)) != 1:
        return None
    return {
        "id": worker["id"],
        "label": worker["label"],
        "status": worker["status"],
        "last_heartbeat_at": worker.get("last_heartbeat_at"),
        "max_concurrency": worker["max_concurrency"],
        "enabled": worker["enabled"],
        "created_at": worker.get("created_at"),
    }


def _sqlite_update_worker_heartbeat(worker_id: str, *, status: str) -> None:
    now = datetime.utcnow().isoformat() + "Z"

    def _transaction(conn) -> None:
        _ensure_workers_table(conn)
        conn.execute(
            """
            INSERT INTO workers (id, label, auth_token_hash, status, last_heartbeat_at, max_concurrency, enabled, created_at)
            VALUES (?, ?, NULL, ?, ?, 1, 1, ?)
            ON CONFLICT(id) DO UPDATE SET
                status = excluded.status,
                last_heartbeat_at = excluded.last_heartbeat_at
            """,
            (worker_id, worker_id, status, now, now),
        )

    run_in_transaction(_transaction)


def _shared_update_worker_heartbeat(worker_id: str, *, status: str) -> None:
    existing = _coerce_worker_row(get_shared_worker(worker_id))
    now = datetime.utcnow().isoformat() + "Z"
    updated_worker = {
        "id": worker_id,
        "label": (existing or {}).get("label") or worker_id,
        "auth_token_hash": (existing or {}).get("auth_token_hash"),
        "status": status,
        "last_heartbeat_at": now,
        "max_concurrency": max(1, int((existing or {}).get("max_concurrency") or 1)),
        "enabled": 1 if bool((existing or {}).get("enabled", 1)) else 0,
        "created_at": (existing or {}).get("created_at") or now,
    }
    upsert_shared_worker(updated_worker)
    _set_local_worker_snapshot(updated_worker)


def _sqlite_set_worker_heartbeat(worker_id: str | None = None, *, status: str) -> None:
    _set_app_state("worker_heartbeat", datetime.utcnow().isoformat() + "Z")
    if worker_id:
        _sqlite_update_worker_heartbeat(worker_id, status=status)


def _shared_set_worker_heartbeat(worker_id: str | None = None, *, status: str) -> None:
    set_shared_app_state("worker_heartbeat", datetime.utcnow().isoformat() + "Z")
    if worker_id:
        _shared_update_worker_heartbeat(worker_id, status=status)


def _sqlite_get_worker_heartbeat():
    row = _get_app_state("worker_heartbeat")
    return row["value"] if row else None


def _shared_get_worker_heartbeat():
    row = get_shared_app_state("worker_heartbeat")
    return row["value"] if row else None


def _sqlite_list_workers() -> list[dict]:
    def _transaction(conn) -> list[dict]:
        _ensure_workers_table(conn)
        rows = conn.execute(
            """
            SELECT id, label, status, last_heartbeat_at, max_concurrency, enabled, created_at
            FROM workers
            ORDER BY created_at ASC
            """
        ).fetchall()
        return [dict(row) for row in rows]

    return run_in_transaction(_transaction)


def _shared_list_workers() -> list[dict]:
    rows = [_coerce_worker_row(row) for row in list_shared_workers()]
    items = [row for row in rows if row]
    items.sort(key=lambda row: (row.get("created_at") or "", row.get("id") or ""))
    return [
        {
            "id": row["id"],
            "label": row["label"],
            "status": row["status"],
            "last_heartbeat_at": row.get("last_heartbeat_at"),
            "max_concurrency": row["max_concurrency"],
            "enabled": row["enabled"],
            "created_at": row.get("created_at"),
        }
        for row in items
    ]


def _sqlite_get_worker(worker_id: str) -> dict | None:
    def _transaction(conn) -> dict | None:
        _ensure_workers_table(conn)
        row = conn.execute(
            """
            SELECT id, label, status, last_heartbeat_at, max_concurrency, enabled, created_at
            FROM workers
            WHERE id = ?
            LIMIT 1
            """,
            (worker_id,),
        ).fetchone()
        return dict(row) if row else None

    return run_in_transaction(_transaction)


def _shared_get_worker(worker_id: str) -> dict | None:
    local_snapshot_started_at = perf_counter()
    worker = _coerce_worker_row(_get_local_worker_snapshot(worker_id))
    _log_local_worker_lookup_timing(
        worker_id=worker_id,
        lookup_step="local_snapshot_path",
        started_at=local_snapshot_started_at,
    )
    if not worker:
        shared_lookup_started_at = perf_counter()
        worker = _coerce_worker_row(get_shared_worker(worker_id))
        _log_local_worker_lookup_timing(
            worker_id=worker_id,
            lookup_step="shared_worker_fallback_path",
            started_at=shared_lookup_started_at,
        )
        _set_local_worker_snapshot(worker)
    if not worker:
        return None
    return {
        "id": worker["id"],
        "label": worker["label"],
        "status": worker["status"],
        "last_heartbeat_at": worker.get("last_heartbeat_at"),
        "max_concurrency": worker["max_concurrency"],
        "enabled": worker["enabled"],
        "created_at": worker.get("created_at"),
    }


def _sqlite_update_worker_state(
    worker_id: str,
    *,
    enabled: bool | None,
    status: str | None,
) -> dict | None:
    def _transaction(conn) -> None:
        _ensure_workers_table(conn)
        existing = conn.execute(
            "SELECT id, enabled, status FROM workers WHERE id = ? LIMIT 1",
            (worker_id,),
        ).fetchone()
        if not existing:
            raise ValueError("worker not found")

        next_enabled = existing["enabled"] if enabled is None else (1 if enabled else 0)
        next_status = existing["status"] if status is None else status
        if status is not None and status not in {"active", "disabled", "draining", "offline", "registered"}:
            raise ValueError("invalid worker status")
        if enabled is False and status is None:
            next_status = "disabled"
        if enabled is True and existing["status"] == "disabled" and status is None:
            next_status = "active"
        conn.execute(
            """
            UPDATE workers
            SET enabled = ?, status = ?
            WHERE id = ?
            """,
            (next_enabled, next_status, worker_id),
        )

    run_in_transaction(_transaction)
    return _sqlite_get_worker(worker_id)


def _shared_update_worker_state(
    worker_id: str,
    *,
    enabled: bool | None,
    status: str | None,
) -> dict | None:
    existing = _coerce_worker_row(get_shared_worker(worker_id))
    if not existing:
        raise ValueError("worker not found")

    next_enabled = existing["enabled"] if enabled is None else (1 if enabled else 0)
    next_status = existing["status"] if status is None else status
    if status is not None and status not in {"active", "disabled", "draining", "offline", "registered"}:
        raise ValueError("invalid worker status")
    if enabled is False and status is None:
        next_status = "disabled"
    if enabled is True and existing["status"] == "disabled" and status is None:
        next_status = "active"

    upsert_shared_worker(
        {
            **existing,
            "enabled": next_enabled,
            "status": next_status,
        }
    )
    return _shared_get_worker(worker_id)


def hash_worker_token(raw_token: str) -> str:
    return hashlib.sha256((raw_token or "").encode("utf-8")).hexdigest()


def ensure_worker_record(
    worker_id: str,
    *,
    label: str | None = None,
    max_concurrency: int = 1,
    enabled: bool = True,
    status: str = "active",
):
    if not worker_id:
        raise ValueError("worker_id is required")
    _with_shared_worker_fallback(
        lambda: _shared_ensure_worker_record(
            worker_id,
            label=label,
            max_concurrency=max_concurrency,
            enabled=enabled,
            status=status,
        ),
        lambda: _sqlite_ensure_worker_record(
            worker_id,
            label=label,
            max_concurrency=max_concurrency,
            enabled=enabled,
            status=status,
        ),
    )


def register_worker_with_token(
    worker_id: str,
    *,
    label: str,
    auth_token: str,
    max_concurrency: int = 1,
    enabled: bool = True,
    status: str = "active",
):
    if not worker_id:
        raise ValueError("worker_id is required")
    if not auth_token:
        raise ValueError("auth_token is required")

    shared_available = False
    if _using_shared_worker_backing():
        try:
            result = _shared_register_worker_with_token(
                worker_id,
                label=label,
                auth_token=auth_token,
                max_concurrency=max_concurrency,
                enabled=enabled,
                status=status,
            )
            shared_available = True
            return _annotate_worker_source(result, source="shared")
        except SharedWorkerStateUnavailable:
            pass

    result = _sqlite_register_worker_with_token(
        worker_id,
        label=label,
        auth_token=auth_token,
        max_concurrency=max_concurrency,
        enabled=enabled,
        status=status,
    )
    return _annotate_worker_source(result, source=_shared_worker_source_label(shared_available))


def register_worker(label: str, max_concurrency: int = 1, enabled: bool = True):
    shared_available = False
    if _using_shared_worker_backing():
        try:
            result = _shared_register_worker(label, max(1, int(max_concurrency or 1)), enabled)
            shared_available = True
            return _annotate_worker_source(result, source="shared")
        except SharedWorkerStateUnavailable:
            pass

    result = _sqlite_register_worker(label, max(1, int(max_concurrency or 1)), enabled)
    return _annotate_worker_source(result, source=_shared_worker_source_label(shared_available))


def authenticate_worker_token(raw_token: str):
    if not _using_shared_worker_backing():
        return _annotate_worker_source(_sqlite_authenticate_worker_token(raw_token), source="sqlite")
    try:
        return _annotate_worker_source(_shared_authenticate_worker_token(raw_token), source="shared")
    except SharedWorkerStateUnavailable:
        return _annotate_worker_source(_sqlite_authenticate_worker_token(raw_token), source="sqlite_fallback")


def authenticate_worker(worker_id: str, raw_token: str):
    if not worker_id or not raw_token:
        return None
    if not _using_shared_worker_backing():
        return _annotate_worker_source(_sqlite_authenticate_worker(worker_id, raw_token), source="sqlite")
    try:
        return _annotate_worker_source(_shared_authenticate_worker(worker_id, raw_token), source="shared")
    except SharedWorkerStateUnavailable:
        return _annotate_worker_source(_sqlite_authenticate_worker(worker_id, raw_token), source="sqlite_fallback")


def update_worker_heartbeat(worker_id: str, *, status: str = "active"):
    if not worker_id:
        return
    _with_shared_worker_fallback(
        lambda: _shared_update_worker_heartbeat(worker_id, status=status),
        lambda: _sqlite_update_worker_heartbeat(worker_id, status=status),
    )


def set_worker_heartbeat(worker_id: str | None = None, *, status: str = "active"):
    _with_shared_worker_fallback(
        lambda: _shared_set_worker_heartbeat(worker_id, status=status),
        lambda: _sqlite_set_worker_heartbeat(worker_id, status=status),
    )


def get_worker_heartbeat():
    return _with_shared_worker_fallback(
        _shared_get_worker_heartbeat,
        _sqlite_get_worker_heartbeat,
    )


def parse_worker_heartbeat(last_heartbeat_at: str | None):
    if not last_heartbeat_at:
        return None
    try:
        return datetime.fromisoformat(last_heartbeat_at.replace("Z", "+00:00")).replace(tzinfo=None)
    except ValueError:
        return None


def is_worker_heartbeat_fresh(last_heartbeat_at: str | None, max_age_seconds: int | None = None) -> bool:
    heartbeat = parse_worker_heartbeat(last_heartbeat_at)
    if not heartbeat:
        return False
    age_limit = max_age_seconds if max_age_seconds is not None else WORKER_HEARTBEAT_MAX_AGE_SECONDS
    return (datetime.utcnow() - heartbeat).total_seconds() <= max(30, int(age_limit))


def get_worker_assignment_counts():
    assignment_view = get_active_assignment_counts_by_worker()
    counts = dict(assignment_view["counts"])
    counts["_meta"] = {
        "assignment_state_source": assignment_view["assignment_state_source"],
        "execution_load_truth": assignment_view["execution_load_truth"],
    }
    return counts


def list_enabled_workers():
    return [row for row in list_workers() if int(row.get("enabled", 0)) == 1]


def list_workers():
    rows, _source = _list_workers_from_shared_or_fallback()
    return rows


def get_worker(worker_id: str):
    if not worker_id:
        return None
    row, _source = _get_worker_from_shared_or_fallback(worker_id)
    return row


def get_recent_event_count_for_worker(worker_id: str, hours: int = 24) -> int:
    if not worker_id:
        return 0

    def _transaction(conn) -> int:
        _ensure_operational_events_table(conn)
        row = conn.execute(
            """
            SELECT COUNT(*) AS count
            FROM operational_events
            WHERE worker_id = ?
              AND created_at >= datetime('now', ?)
            """,
            (worker_id, f"-{max(1, int(hours))} hours"),
        ).fetchone()
        return int(row["count"]) if row else 0

    return run_in_transaction(_transaction)


def _get_recent_event_counts_by_worker(hours: int = 24) -> dict[str, int]:
    def _transaction(conn) -> dict[str, int]:
        _ensure_operational_events_table(conn)
        rows = conn.execute(
            """
            SELECT worker_id, COUNT(*) AS count
            FROM operational_events
            WHERE worker_id IS NOT NULL
              AND worker_id != ''
              AND created_at >= datetime('now', ?)
            GROUP BY worker_id
            """,
            (f"-{max(1, int(hours))} hours",),
        ).fetchall()
        return {str(row["worker_id"]): int(row["count"]) for row in rows}

    return run_in_transaction(_transaction)


def get_recent_failure_count_for_worker(worker_id: str, hours: int = 24) -> int:
    if not worker_id:
        return 0

    def _transaction(conn) -> int:
        _ensure_operational_events_table(conn)
        row = conn.execute(
            """
            SELECT COUNT(*) AS count
            FROM operational_events
            WHERE worker_id = ?
              AND severity IN ('warning', 'critical')
              AND created_at >= datetime('now', ?)
            """,
            (worker_id, f"-{max(1, int(hours))} hours"),
        ).fetchone()
        return int(row["count"]) if row else 0

    return run_in_transaction(_transaction)


def _get_recent_failure_counts_by_worker(hours: int = 24) -> dict[str, int]:
    def _transaction(conn) -> dict[str, int]:
        _ensure_operational_events_table(conn)
        rows = conn.execute(
            """
            SELECT worker_id, COUNT(*) AS count
            FROM operational_events
            WHERE worker_id IS NOT NULL
              AND worker_id != ''
              AND severity IN ('warning', 'critical')
              AND created_at >= datetime('now', ?)
            GROUP BY worker_id
            """,
            (f"-{max(1, int(hours))} hours",),
        ).fetchall()
        return {str(row["worker_id"]): int(row["count"]) for row in rows}

    return run_in_transaction(_transaction)


def _build_dispatch_readiness_view(item: dict) -> dict:
    worker = dict(item)
    enabled = bool(worker.get("enabled"))
    effective_status = worker.get("effective_status")
    max_concurrency = max(1, int(worker.get("max_concurrency") or 1))
    running_count = int(worker.get("running_count") or 0)
    active_assigned_count = int(worker.get("active_assigned_count") or 0)
    available_capacity = max(0, max_concurrency - active_assigned_count)

    readiness_reason = "ready"
    if not enabled:
        readiness_reason = "disabled"
    elif effective_status in NON_ASSIGNABLE_WORKER_STATUSES:
        readiness_reason = f"status_{effective_status}"
    elif running_count >= max_concurrency:
        readiness_reason = "running_capacity_reached"
    elif active_assigned_count >= max_concurrency:
        readiness_reason = "assigned_capacity_reached"

    protection_state = "dispatch_ready" if readiness_reason == "ready" else readiness_reason

    worker["available_capacity"] = available_capacity
    worker["assignment_eligible"] = bool(
        enabled
        and effective_status == "active"
        and available_capacity > 0
    )
    worker["dispatch_readiness"] = "ready" if readiness_reason == "ready" else "blocked"
    worker["dispatch_readiness_reason"] = readiness_reason
    worker["dispatch_safety_state"] = protection_state
    return worker


def get_worker_load_view(hours: int = 24):
    list_workers_started_at = perf_counter()
    rows, worker_state_source = _list_workers_from_shared_or_fallback()
    _log_worker_summary_timing(summary_step="list_workers", started_at=list_workers_started_at)
    assignment_counts_started_at = perf_counter()
    assignment_counts = get_worker_assignment_counts()
    _log_worker_summary_timing(summary_step="get_worker_assignment_counts", started_at=assignment_counts_started_at)
    recent_event_counts_started_at = perf_counter()
    recent_event_counts = _get_recent_event_counts_by_worker(hours=hours)
    _log_worker_summary_timing(
        summary_step="get_recent_event_counts_by_worker",
        started_at=recent_event_counts_started_at,
    )
    recent_failure_counts_started_at = perf_counter()
    recent_failure_counts = _get_recent_failure_counts_by_worker(hours=hours)
    _log_worker_summary_timing(
        summary_step="get_recent_failure_counts_by_worker",
        started_at=recent_failure_counts_started_at,
    )
    assignment_meta = assignment_counts.get("_meta", {})
    items = []
    for row in rows:
        worker_item_started_at = perf_counter()
        item = dict(row)
        item["worker_id"] = item["id"]
        item["heartbeat_fresh"] = is_worker_heartbeat_fresh(item.get("last_heartbeat_at"))
        item["effective_status"] = item["status"]
        if item.get("enabled") and item["status"] == "active" and not item["heartbeat_fresh"]:
            item["effective_status"] = "offline"
        counts = assignment_counts.get(item["id"], {})
        item["assigned_job_count"] = int(counts.get("assigned_job_count", 0))
        item["active_assigned_count"] = int(counts.get("active_assigned_count", 0))
        item["running_count"] = int(counts.get("running_count", 0))
        item["queued_count"] = int(counts.get("queued_count", 0))
        item["assignment_state_source"] = assignment_meta.get("assignment_state_source", "local_sqlite")
        execution_load_truth = assignment_meta.get("execution_load_truth", "local_sqlite")
        if worker_state_source == "shared" and execution_load_truth == "shared":
            item["worker_load_truth"] = "shared"
        elif worker_state_source == "shared":
            item["worker_load_truth"] = "mixed"
        elif worker_state_source == "sqlite_fallback" or execution_load_truth == "degraded_sqlite_fallback":
            item["worker_load_truth"] = "degraded_sqlite_fallback"
        else:
            item["worker_load_truth"] = "local_sqlite"
        item["recent_event_count"] = int(recent_event_counts.get(item["id"], 0))
        item["recent_failure_count"] = int(recent_failure_counts.get(item["id"], 0))
        items.append(_build_dispatch_readiness_view(item))
        _log_worker_summary_timing(
            summary_step=f"build_worker_item:{item['id']}",
            started_at=worker_item_started_at,
        )
    return items


def update_worker_state(
    worker_id: str,
    *,
    enabled: bool | None = None,
    status: str | None = None,
):
    if not worker_id:
        raise ValueError("worker_id is required")
    if _using_shared_worker_backing():
        try:
            return _annotate_worker_source(
                _shared_update_worker_state(
                    worker_id,
                    enabled=enabled,
                    status=status,
                ),
                source="shared",
            )
        except SharedWorkerStateUnavailable:
            return _annotate_worker_source(
                _sqlite_update_worker_state(
                    worker_id,
                    enabled=enabled,
                    status=status,
                ),
                source="sqlite_fallback",
            )
    return _annotate_worker_source(
        _sqlite_update_worker_state(
            worker_id,
            enabled=enabled,
            status=status,
        ),
        source="sqlite",
    )


def select_dispatch_worker():
    total_started_at = perf_counter()
    rows = get_worker_load_view(hours=24)
    _log_worker_summary_timing(summary_step="select_dispatch_worker_load_view", started_at=total_started_at)
    filter_started_at = perf_counter()
    candidates = []
    for row in rows:
        if row.get("dispatch_readiness") != "ready":
            continue
        candidates.append(row)
    _log_worker_summary_timing(summary_step="select_dispatch_worker_filter_candidates", started_at=filter_started_at)

    if not candidates:
        _log_worker_summary_timing(summary_step="select_dispatch_worker_total", started_at=total_started_at)
        return None

    sort_started_at = perf_counter()
    candidates.sort(
        key=lambda row: (
            int(row.get("active_assigned_count") or 0),
            int(row.get("running_count") or 0),
            int(row.get("recent_failure_count") or 0),
            row.get("last_heartbeat_at") or "",
            row.get("created_at") or "",
            row.get("id") or "",
        )
    )
    _log_worker_summary_timing(summary_step="select_dispatch_worker_sort_candidates", started_at=sort_started_at)
    _log_worker_summary_timing(summary_step="select_dispatch_worker_total", started_at=total_started_at)
    return candidates[0]


def get_worker_summary(hours: int = 24):
    total_started_at = perf_counter()
    items = get_worker_load_view(hours=hours)
    _log_worker_summary_timing(summary_step="get_worker_summary_total", started_at=total_started_at)
    return items
