﻿import os
import shutil
import threading
from datetime import datetime, timedelta, timezone
from time import monotonic, perf_counter

from .db import get_conn, get_worker, get_worker_summary
from .queue import get_queue_depth


EXECUTION_TIMEOUT_STDERR = "Execution timed out"
QUEUE_ALERT_DEPTH = max(1, int(os.getenv("RUN_QUEUE_ALERT_DEPTH", "80")))
QUEUE_MAX_DEPTH = max(QUEUE_ALERT_DEPTH, int(os.getenv("RUN_QUEUE_MAX_DEPTH", "100")))
ACTIVE_EXECUTION_MAX = max(1, int(os.getenv("ACTIVE_EXECUTION_MAX", "8")))
HOST_LOAD_ALERT_THRESHOLD = float(os.getenv("HOST_LOAD_ALERT_THRESHOLD", str(max(2.0, float(os.cpu_count() or 1)))))
HOST_LOAD_CRITICAL_THRESHOLD = float(os.getenv("HOST_LOAD_CRITICAL_THRESHOLD", str(max(HOST_LOAD_ALERT_THRESHOLD + 1.0, float((os.cpu_count() or 1) * 2)))))
HOST_MEMORY_AVAILABLE_MB_ALERT = max(64, int(os.getenv("HOST_MEMORY_AVAILABLE_MB_ALERT", "256")))
HOST_MEMORY_AVAILABLE_MB_CRITICAL = max(32, int(os.getenv("HOST_MEMORY_AVAILABLE_MB_CRITICAL", "128")))
HOST_DISK_USED_PERCENT_ALERT = float(os.getenv("HOST_DISK_USED_PERCENT_ALERT", "85"))
HOST_DISK_USED_PERCENT_CRITICAL = float(os.getenv("HOST_DISK_USED_PERCENT_CRITICAL", "92"))
HOST_PRESSURE_DISK_PATH = os.getenv("HOST_PRESSURE_DISK_PATH", "/")
AUTO_PROTECT_LOCAL_WORKER = str(os.getenv("AUTO_PROTECT_LOCAL_WORKER", "1")).strip().lower() not in {"0", "false", "no", "off"}
LOCAL_WORKER_ID = os.getenv("DISPOSABLE_EXEC_WORKER_ID", "local-worker").strip() or "local-worker"
_HOST_METRICS_CACHE_LOCK = threading.Lock()
_HOST_METRICS_CACHE: dict | None = None
_HOST_METRICS_CACHE_AT = 0.0


def _parse_iso_utc(value: str | None):
    if not value:
        return None

    normalized = str(value).strip()
    if not normalized:
        return None

    if normalized.endswith("Z"):
        normalized = normalized[:-1] + "+00:00"

    try:
        return datetime.fromisoformat(normalized)
    except ValueError:
        return None


def _log_host_pressure_timing(*, pressure_step: str, started_at: float) -> None:
    elapsed_ms = round((perf_counter() - started_at) * 1000, 1)
    print(f"HOST_PRESSURE_TIMING pressure_step={pressure_step} elapsed_ms={elapsed_ms}", flush=True)


def _redis_queue_length() -> int:
    return get_queue_depth()


def _active_execution_count(conn) -> int:
    row = conn.execute(
        "SELECT COUNT(*) AS count FROM execution_status WHERE status = ?",
        ("running",),
    ).fetchone()
    return int(row["count"]) if row else 0


def _percentile(values: list[float], percentile: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(float(value) for value in values)
    if len(ordered) == 1:
        return round(ordered[0], 4)
    rank = max(0, min(len(ordered) - 1, int(round((percentile / 100.0) * (len(ordered) - 1)))))
    return round(ordered[rank], 4)


def _load_average_metrics() -> dict:
    try:
        load1, load5, load15 = os.getloadavg()
        return {
            "load_average_1m": round(float(load1), 3),
            "load_average_5m": round(float(load5), 3),
            "load_average_15m": round(float(load15), 3),
            "cpu_count": int(os.cpu_count() or 1),
        }
    except (AttributeError, OSError):
        return {
            "load_average_1m": None,
            "load_average_5m": None,
            "load_average_15m": None,
            "cpu_count": int(os.cpu_count() or 1),
        }


def _memory_metrics() -> dict:
    meminfo_path = "/proc/meminfo"
    if not os.path.exists(meminfo_path):
        return {
            "memory_total_mb": None,
            "memory_available_mb": None,
            "memory_used_mb": None,
            "memory_used_percent": None,
        }

    values = {}
    with open(meminfo_path, "r", encoding="utf-8") as handle:
        for line in handle:
            if ":" not in line:
                continue
            key, raw_value = line.split(":", 1)
            parts = raw_value.strip().split()
            if not parts:
                continue
            try:
                values[key] = int(parts[0])
            except ValueError:
                continue

    total_kb = values.get("MemTotal")
    available_kb = values.get("MemAvailable")
    if not total_kb or available_kb is None:
        return {
            "memory_total_mb": None,
            "memory_available_mb": None,
            "memory_used_mb": None,
            "memory_used_percent": None,
        }

    used_kb = max(0, total_kb - available_kb)
    return {
        "memory_total_mb": round(total_kb / 1024, 1),
        "memory_available_mb": round(available_kb / 1024, 1),
        "memory_used_mb": round(used_kb / 1024, 1),
        "memory_used_percent": round((used_kb / total_kb) * 100, 2) if total_kb else None,
    }


def _disk_metrics(path: str = HOST_PRESSURE_DISK_PATH) -> dict:
    usage = shutil.disk_usage(path)
    used = usage.total - usage.free
    return {
        "disk_path": path,
        "disk_total_gb": round(usage.total / (1024 ** 3), 2),
        "disk_free_gb": round(usage.free / (1024 ** 3), 2),
        "disk_used_percent": round((used / usage.total) * 100, 2) if usage.total else None,
    }


def _host_metrics_cache_ttl_seconds() -> float:
    try:
        return max(
            0.0,
            float(
                os.getenv("DISPOSABLE_EXEC_HOST_METRICS_CACHE_TTL_SECONDS", "").strip()
                or os.getenv("HOST_METRICS_CACHE_TTL_SECONDS", "").strip()
                or "5"
            ),
        )
    except ValueError:
        return 5.0


def get_host_metrics() -> dict:
    global _HOST_METRICS_CACHE, _HOST_METRICS_CACHE_AT
    ttl_seconds = _host_metrics_cache_ttl_seconds()
    now = monotonic()
    with _HOST_METRICS_CACHE_LOCK:
        if (
            _HOST_METRICS_CACHE is not None
            and ttl_seconds > 0
            and (now - _HOST_METRICS_CACHE_AT) <= ttl_seconds
        ):
            return dict(_HOST_METRICS_CACHE)

    total_started_at = perf_counter()
    metrics = {}
    load_started_at = perf_counter()
    metrics.update(_load_average_metrics())
    _log_host_pressure_timing(pressure_step="load_average_metrics", started_at=load_started_at)
    memory_started_at = perf_counter()
    metrics.update(_memory_metrics())
    _log_host_pressure_timing(pressure_step="memory_metrics", started_at=memory_started_at)
    disk_started_at = perf_counter()
    metrics.update(_disk_metrics())
    _log_host_pressure_timing(pressure_step="disk_metrics", started_at=disk_started_at)
    with _HOST_METRICS_CACHE_LOCK:
        _HOST_METRICS_CACHE = dict(metrics)
        _HOST_METRICS_CACHE_AT = monotonic()
    _log_host_pressure_timing(pressure_step="get_host_metrics_total", started_at=total_started_at)
    return metrics


def get_host_pressure_snapshot(queue_depth: int | None = None, active_execution_count: int | None = None) -> dict:
    total_started_at = perf_counter()
    queue_started_at = perf_counter()
    current_queue_depth = _redis_queue_length() if queue_depth is None else int(queue_depth)
    _log_host_pressure_timing(pressure_step="queue_depth", started_at=queue_started_at)
    active_execution_started_at = perf_counter()
    conn = get_conn()
    try:
        current_active_execution_count = (
            _active_execution_count(conn) if active_execution_count is None else int(active_execution_count)
        )
    finally:
        conn.close()
    _log_host_pressure_timing(pressure_step="active_execution_count", started_at=active_execution_started_at)
    host_metrics_started_at = perf_counter()
    host_metrics = get_host_metrics()
    _log_host_pressure_timing(pressure_step="host_metrics", started_at=host_metrics_started_at)
    thresholds = {
        "queue_alert_depth": QUEUE_ALERT_DEPTH,
        "queue_max_depth": QUEUE_MAX_DEPTH,
        "active_execution_max": ACTIVE_EXECUTION_MAX,
        "load_alert_threshold": HOST_LOAD_ALERT_THRESHOLD,
        "load_critical_threshold": HOST_LOAD_CRITICAL_THRESHOLD,
        "memory_available_mb_alert": HOST_MEMORY_AVAILABLE_MB_ALERT,
        "memory_available_mb_critical": HOST_MEMORY_AVAILABLE_MB_CRITICAL,
        "disk_used_percent_alert": HOST_DISK_USED_PERCENT_ALERT,
        "disk_used_percent_critical": HOST_DISK_USED_PERCENT_CRITICAL,
        "auto_protect_local_worker": AUTO_PROTECT_LOCAL_WORKER,
    }
    triggered_conditions = []

    if current_queue_depth >= QUEUE_MAX_DEPTH:
        triggered_conditions.append(
            {
                "code": "queue_depth_critical",
                "severity": "critical",
                "value": current_queue_depth,
                "threshold": QUEUE_MAX_DEPTH,
            }
        )
    elif current_queue_depth >= QUEUE_ALERT_DEPTH:
        triggered_conditions.append(
            {
                "code": "queue_depth_high",
                "severity": "warning",
                "value": current_queue_depth,
                "threshold": QUEUE_ALERT_DEPTH,
            }
        )

    if current_active_execution_count >= ACTIVE_EXECUTION_MAX:
        triggered_conditions.append(
            {
                "code": "active_execution_critical",
                "severity": "critical",
                "value": current_active_execution_count,
                "threshold": ACTIVE_EXECUTION_MAX,
            }
        )

    load1 = host_metrics.get("load_average_1m")
    if load1 is not None:
        if load1 >= HOST_LOAD_CRITICAL_THRESHOLD:
            triggered_conditions.append(
                {
                    "code": "load_average_critical",
                    "severity": "critical",
                    "value": load1,
                    "threshold": HOST_LOAD_CRITICAL_THRESHOLD,
                }
            )
        elif load1 >= HOST_LOAD_ALERT_THRESHOLD:
            triggered_conditions.append(
                {
                    "code": "load_average_high",
                    "severity": "warning",
                    "value": load1,
                    "threshold": HOST_LOAD_ALERT_THRESHOLD,
                }
            )

    memory_available_mb = host_metrics.get("memory_available_mb")
    if memory_available_mb is not None:
        if memory_available_mb <= HOST_MEMORY_AVAILABLE_MB_CRITICAL:
            triggered_conditions.append(
                {
                    "code": "memory_available_critical",
                    "severity": "critical",
                    "value": memory_available_mb,
                    "threshold": HOST_MEMORY_AVAILABLE_MB_CRITICAL,
                }
            )
        elif memory_available_mb <= HOST_MEMORY_AVAILABLE_MB_ALERT:
            triggered_conditions.append(
                {
                    "code": "memory_available_low",
                    "severity": "warning",
                    "value": memory_available_mb,
                    "threshold": HOST_MEMORY_AVAILABLE_MB_ALERT,
                }
            )

    disk_used_percent = host_metrics.get("disk_used_percent")
    if disk_used_percent is not None:
        if disk_used_percent >= HOST_DISK_USED_PERCENT_CRITICAL:
            triggered_conditions.append(
                {
                    "code": "disk_used_critical",
                    "severity": "critical",
                    "value": disk_used_percent,
                    "threshold": HOST_DISK_USED_PERCENT_CRITICAL,
                }
            )
        elif disk_used_percent >= HOST_DISK_USED_PERCENT_ALERT:
            triggered_conditions.append(
                {
                    "code": "disk_used_high",
                    "severity": "warning",
                    "value": disk_used_percent,
                    "threshold": HOST_DISK_USED_PERCENT_ALERT,
                }
            )

    critical_conditions = [item for item in triggered_conditions if item["severity"] == "critical"]
    local_worker_lookup_started_at = perf_counter()
    local_worker = get_worker(LOCAL_WORKER_ID) or {}
    _log_host_pressure_timing(pressure_step="local_worker_lookup", started_at=local_worker_lookup_started_at)
    local_worker_protection_active = bool(local_worker) and (
        not bool(local_worker.get("enabled", True)) or local_worker.get("status") == "draining"
    )
    result = {
        "queue_depth": current_queue_depth,
        "active_execution_count": current_active_execution_count,
        "host_metrics": host_metrics,
        "thresholds": thresholds,
        "triggered_conditions": triggered_conditions,
        "critical_conditions": critical_conditions,
        "protect_local_worker": AUTO_PROTECT_LOCAL_WORKER and any(
            item["code"] in {"load_average_critical", "memory_available_critical", "disk_used_critical"}
            for item in critical_conditions
        ),
        "local_worker_id": LOCAL_WORKER_ID,
        "local_worker_protection_active": local_worker_protection_active,
        "local_worker_status": local_worker.get("status"),
    }
    _log_host_pressure_timing(pressure_step="get_host_pressure_snapshot_total", started_at=total_started_at)
    return result


def _execution_rows_last_5m(conn) -> list[dict]:
    cutoff = datetime.now(timezone.utc) - timedelta(minutes=5)
    rows = conn.execute(
        """
        SELECT execution_id, exit_code, stderr, duration, created_at
        FROM execution_results
        ORDER BY created_at DESC
        """
    ).fetchall()

    items = []
    for row in rows:
        created_at = _parse_iso_utc(row["created_at"])
        if created_at and created_at >= cutoff:
            items.append(dict(row))
    return items


def _execution_rows_last_hours(conn, hours: int = 24) -> list[dict]:
    cutoff = datetime.now(timezone.utc) - timedelta(hours=max(1, int(hours)))
    rows = conn.execute(
        """
        SELECT execution_id, exit_code, stderr, duration, completed_by_worker_id, created_at
        FROM execution_results
        ORDER BY created_at DESC
        """
    ).fetchall()

    items = []
    for row in rows:
        created_at = _parse_iso_utc(row["created_at"])
        if created_at and created_at >= cutoff:
            items.append(dict(row))
    return items


def _operational_event_count(conn, event: str, hours: int = 24) -> int:
    row = conn.execute(
        """
        SELECT COUNT(*) AS count
        FROM operational_events
        WHERE event = ?
          AND created_at >= datetime('now', ?)
        """,
        (event, f"-{max(1, int(hours))} hours"),
    ).fetchone()
    return int(row["count"]) if row else 0


def _worker_heartbeat_summary(hours: int = 24) -> dict:
    workers = get_worker_summary(hours=max(1, int(hours)))
    fresh = sum(1 for worker in workers if worker.get("heartbeat_fresh"))
    stale = sum(1 for worker in workers if not worker.get("heartbeat_fresh"))
    draining = sum(1 for worker in workers if worker.get("status") == "draining")
    total = len(workers)
    return {
        "total_workers": total,
        "fresh_workers": fresh,
        "stale_workers": stale,
        "draining_workers": draining,
        "freshness_ratio": round(fresh / total, 4) if total else 1.0,
        "items": workers,
    }


def _summarize_recent_failure(stderr: str | None) -> str | None:
    text = (stderr or "").strip()
    if not text:
        return None

    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if not lines:
        return None

    candidate = lines[-1]
    if candidate.lower().startswith("traceback") and len(lines) > 1:
        candidate = lines[-2]

    return candidate[:160]


def _latest_failed_execution_summary(rows: list[dict]) -> str | None:
    for row in rows:
        if int(row.get("exit_code") or 0) == 0:
            continue
        summary = _summarize_recent_failure(row.get("stderr"))
        if summary:
            return summary
    return None


def _worker_status_label(worker_heartbeat: dict) -> str:
    stale_workers = int(worker_heartbeat.get("stale_workers") or 0)
    freshness_ratio = float(worker_heartbeat.get("freshness_ratio") or 0.0)
    draining_workers = int(worker_heartbeat.get("draining_workers") or 0)
    fresh_workers = int(worker_heartbeat.get("fresh_workers") or 0)
    total_workers = int(worker_heartbeat.get("total_workers") or 0)

    if stale_workers > 0 or freshness_ratio < 1.0:
        return f"异常 {fresh_workers}/{total_workers}"
    if draining_workers > 0:
        return f"Draining {draining_workers}/{total_workers}"
    return f"正常 {fresh_workers}/{total_workers}"


def _host_status_label(metrics: dict) -> str:
    triggered_conditions = metrics.get("triggered_conditions") or []
    if metrics.get("protect_local_worker"):
        return "保护中"
    if any(item.get("severity") == "critical" for item in triggered_conditions):
        return "严重"
    if any(item.get("severity") == "warning" for item in triggered_conditions):
        return "告警"
    return "正常"


def _manual_recovery_top_actions(manual_recovery: dict, limit: int = 2) -> str | None:
    action_labels = {
        "execution_requeued_24h": "requeue",
        "execution_marked_failed_24h": "mark-failed",
        "execution_result_written_24h": "write-result",
        "worker_state_updated_24h": "worker-state",
        "worker_draining_24h": "worker-drain",
        "worker_activated_24h": "worker-activate",
    }
    ranked = []
    for key, label in action_labels.items():
        count = int(manual_recovery.get(key) or 0)
        if count > 0:
            ranked.append((count, label))
    if not ranked:
        return None
    ranked.sort(key=lambda item: (-item[0], item[1]))
    return " | ".join(f"{label} {count}" for count, label in ranked[: max(1, int(limit))])


def build_admin_metrics_warning_summary(metrics: dict) -> dict | None:
    if not metrics:
        return None

    run_requests = metrics.get("run_requests") or {}
    manual_recovery = metrics.get("manual_recovery") or {}
    execution_outcomes = metrics.get("execution_outcomes") or {}
    worker_heartbeat = metrics.get("worker_heartbeat_summary") or {}
    triggered_conditions = metrics.get("triggered_conditions") or []
    recent_failure_summary = (metrics.get("execution_outcomes") or {}).get("latest_failure_summary_24h")

    warning_bits = []
    warning_codes = []

    quota_rejected = int(run_requests.get("quota_rejected_24h") or 0)
    if quota_rejected > 0:
        warning_codes.append("quota_rejected")
        warning_bits.append(f"quota_rejected_24h={quota_rejected}")

    queue_rejected = int(run_requests.get("queue_rejected_24h") or 0)
    if queue_rejected > 0:
        warning_codes.append("queue_rejected")
        warning_bits.append(f"queue_rejected_24h={queue_rejected}")

    concurrency_rejected = int(
        run_requests.get("user_concurrency_rejected_24h")
        or run_requests.get("active_execution_rejected_24h")
        or 0
    )
    if concurrency_rejected > 0:
        warning_codes.append("user_concurrency_rejected")
        warning_bits.append(f"user_concurrency_rejected_24h={concurrency_rejected}")

    failure_count = int(execution_outcomes.get("failure_count_24h") or 0)
    if failure_count > 0:
        warning_codes.append("execution_failures")
        warning_bits.append(f"failure_count_24h={failure_count}")

    stale_workers = int(worker_heartbeat.get("stale_workers") or 0)
    if stale_workers > 0:
        warning_codes.append("stale_workers")
        warning_bits.append(f"stale_workers={stale_workers}")

    freshness_ratio = float(worker_heartbeat.get("freshness_ratio") or 0.0)
    if freshness_ratio < 1.0:
        warning_codes.append("worker_freshness")
        warning_bits.append(f"freshness_ratio={freshness_ratio}")

    if metrics.get("protect_local_worker"):
        warning_codes.append("local_worker_protected")
        warning_bits.append("protect_local_worker=true")

    manual_recovery_total = int(manual_recovery.get("total_24h") or 0)
    manual_recovery_elevated = manual_recovery_total >= 3
    manual_recovery_top = _manual_recovery_top_actions(manual_recovery)
    if manual_recovery_elevated:
        warning_codes.append("manual_recovery_elevated")
        warning_bits.append(f"manual_recovery_total_24h={manual_recovery_total}")

    warning_trigger_codes = [item.get("code") for item in triggered_conditions if item.get("severity") == "warning"]
    critical_trigger_codes = [item.get("code") for item in triggered_conditions if item.get("severity") == "critical"]

    if warning_trigger_codes:
        warning_codes.append("host_warning")
        warning_bits.append("warning_conditions=" + ",".join(sorted(set(warning_trigger_codes))))

    if critical_trigger_codes:
        warning_codes.append("host_critical")
        warning_bits.append("critical_conditions=" + ",".join(sorted(set(critical_trigger_codes))))

    if not warning_bits:
        return None

    severity = "critical" if metrics.get("protect_local_worker") or critical_trigger_codes else "warning"
    failure_fallback_action = "动作: 查看最近失败任务结果"
    failure_detailed_action = "动作: 如为平台侧错误，检查最近失败 execution 的 result / stderr"
    primary_issue = "检测到运行告警"
    suggested_action = "动作: 查看 /admin/metrics"

    if critical_trigger_codes or metrics.get("protect_local_worker"):
        primary_issue = "主机压力已触发本地保护"
        suggested_action = "动作: 先检查主机压力并降低新流量"
    elif failure_count > 0:
        primary_issue = f"执行失败 {failure_count} 次（24h）"
        suggested_action = failure_fallback_action
    elif queue_rejected > 0:
        primary_issue = f"队列拒绝 {queue_rejected} 次（24h）"
        suggested_action = "动作: 检查队列积压与 worker 处理能力"
    elif stale_workers > 0 or freshness_ratio < 1.0:
        primary_issue = f"Worker 心跳/新鲜度异常（异常 {max(stale_workers, 1)} 个）"
        suggested_action = "动作: 检查 worker 状态、心跳和最近日志"
    elif concurrency_rejected > 0:
        primary_issue = f"并发拒绝 {concurrency_rejected} 次（24h）"
        suggested_action = "动作: 检查占用槽位与套餐并发上限"
    elif quota_rejected > 0:
        primary_issue = f"配额拒绝 {quota_rejected} 次（24h）"
        suggested_action = "动作: 先确认是否为正常套餐配额耗尽"
    elif manual_recovery_elevated:
        primary_issue = f"最近 24h 手动恢复操作偏高（{manual_recovery_total} 次）"
        suggested_action = "动作: 复盘最近恢复操作，避免手动恢复成为常态"
    elif warning_trigger_codes:
        primary_issue = "主机出现告警条件"
        suggested_action = "动作: 检查主机负载、内存、磁盘与队列压力"

    worker_state = "正常"
    if stale_workers > 0 or freshness_ratio < 1.0:
        worker_state = "异常"
    elif int(worker_heartbeat.get("draining_workers") or 0) > 0:
        worker_state = "Draining"

    host_state = "正常"
    if critical_trigger_codes or metrics.get("protect_local_worker"):
        host_state = "严重"
    elif warning_trigger_codes:
        host_state = "告警"

    state_summary = (
        f"队列拒绝: {queue_rejected} | "
        f"并发拒绝: {concurrency_rejected} | "
        f"执行失败: {failure_count}"
    )

    if quota_rejected > 0:
        state_summary += f" | 配额拒绝: {quota_rejected}"
    if manual_recovery_elevated:
        state_summary += f" | 手动恢复: {manual_recovery_total}"

    state_summary += f" | Worker: {worker_state} | 主机: {host_state}"

    message_lines = [
        "Disposable-exec Warning",
        primary_issue,
    ]
    if failure_count > 0 and recent_failure_summary:
        message_lines.append(f"最近报错: {recent_failure_summary}")
        if suggested_action == failure_fallback_action:
            suggested_action = failure_detailed_action
    elif manual_recovery_elevated and manual_recovery_top:
        message_lines.append(f"最近恢复: {manual_recovery_top}")
    message_lines.extend([state_summary, suggested_action])
    message = "\n".join(message_lines)
    return {
        "severity": severity,
        "codes": sorted(set(warning_codes)),
        "detail": message,
        "message": message,
    }


def build_admin_metrics_scheduled_summary(metrics: dict) -> str:
    run_requests = metrics.get("run_requests") or {}
    execution_outcomes = metrics.get("execution_outcomes") or {}
    worker_heartbeat = metrics.get("worker_heartbeat_summary") or {}

    accepted = int(run_requests.get("accepted_24h") or 0)
    rejected = int(run_requests.get("rejected_24h") or 0)
    quota_rejected = int(run_requests.get("quota_rejected_24h") or 0)
    queue_rejected = int(run_requests.get("queue_rejected_24h") or 0)
    user_concurrency_rejected = int(run_requests.get("user_concurrency_rejected_24h") or 0)
    active_exec_rejected = int(run_requests.get("active_execution_rejected_24h") or 0)

    success_count = int(execution_outcomes.get("success_count_24h") or 0)
    failure_count = int(execution_outcomes.get("failure_count_24h") or 0)
    avg_duration = float(execution_outcomes.get("avg_duration_seconds_24h") or 0.0)
    p95_duration = float(execution_outcomes.get("p95_duration_seconds_24h") or 0.0)

    return "\n".join(
        [
            "Disposable-exec Summary",
            f"请求(24h): 接受 {accepted} | 拒绝 {rejected}",
            f"执行(24h): 成功 {success_count} | 失败 {failure_count} | 平均 {avg_duration:.2f}s | P95 {p95_duration:.2f}s",
            f"Worker: {_worker_status_label(worker_heartbeat)} | 主机: {_host_status_label(metrics)}",
            f"拒绝明细: 队列 {queue_rejected} | 用户并发 {user_concurrency_rejected} | 全局并发 {active_exec_rejected} | 配额 {quota_rejected}",
        ]
    )


def get_admin_metrics() -> dict:
    conn = get_conn()
    try:
        execution_rows = _execution_rows_last_5m(conn)
        execution_count = len(execution_rows)
        success_count = sum(1 for row in execution_rows if int(row["exit_code"] or 0) == 0)
        timeout_count = sum(
            1
            for row in execution_rows
            if int(row["exit_code"]) == -1 and (row["stderr"] or "") == EXECUTION_TIMEOUT_STDERR
        )
        avg_duration = (
            sum(float(row["duration"] or 0.0) for row in execution_rows) / execution_count
            if execution_count
            else 0.0
        )
        execution_rows_24h = _execution_rows_last_hours(conn, hours=24)
        execution_durations_24h = [float(row["duration"] or 0.0) for row in execution_rows_24h]
        execution_success_count_24h = sum(1 for row in execution_rows_24h if int(row["exit_code"] or 0) == 0)
        execution_failure_count_24h = sum(1 for row in execution_rows_24h if int(row["exit_code"] or 0) != 0)

        pressure = get_host_pressure_snapshot()
        run_requests = {
            "accepted_24h": _operational_event_count(conn, "run_request_accepted", hours=24),
            "quota_rejected_24h": _operational_event_count(conn, "quota_rejected", hours=24),
            "user_concurrency_rejected_24h": _operational_event_count(conn, "user_concurrency_limit_reject", hours=24),
            "queue_rejected_24h": _operational_event_count(conn, "queue_backpressure_reject", hours=24),
            "active_execution_rejected_24h": _operational_event_count(conn, "active_execution_backpressure_reject", hours=24),
            "enqueue_failed_24h": _operational_event_count(conn, "enqueue_failed", hours=24),
        }
        run_requests["rejected_24h"] = (
            run_requests["quota_rejected_24h"]
            + run_requests["user_concurrency_rejected_24h"]
            + run_requests["queue_rejected_24h"]
            + run_requests["active_execution_rejected_24h"]
            + run_requests["enqueue_failed_24h"]
        )
        run_requests["total_24h"] = run_requests["accepted_24h"] + run_requests["rejected_24h"]
        run_requests["acceptance_rate_24h"] = round(
            run_requests["accepted_24h"] / run_requests["total_24h"], 4
        ) if run_requests["total_24h"] else 1.0
        run_requests["rejection_rate_24h"] = round(
            run_requests["rejected_24h"] / run_requests["total_24h"], 4
        ) if run_requests["total_24h"] else 0.0
        manual_recovery = {
            "execution_requeued_24h": _operational_event_count(conn, "execution_requeued", hours=24),
            "execution_marked_failed_24h": _operational_event_count(conn, "execution_marked_failed", hours=24),
            "execution_result_written_24h": _operational_event_count(conn, "execution_result_written", hours=24),
            "worker_state_updated_24h": _operational_event_count(conn, "worker_state_updated", hours=24),
            "worker_draining_24h": _operational_event_count(conn, "worker_draining", hours=24),
            "worker_activated_24h": _operational_event_count(conn, "worker_activated", hours=24),
        }
        manual_recovery["total_24h"] = sum(manual_recovery.values())
        execution_outcomes = {
            "total_count_24h": len(execution_rows_24h),
            "success_count_24h": execution_success_count_24h,
            "failure_count_24h": execution_failure_count_24h,
            "avg_duration_seconds_24h": round(
                sum(execution_durations_24h) / len(execution_durations_24h), 4
            ) if execution_durations_24h else 0.0,
            "p95_duration_seconds_24h": _percentile(execution_durations_24h, 95),
            "failure_rate_24h": round(
                execution_failure_count_24h / len(execution_rows_24h), 4
            ) if execution_rows_24h else 0.0,
            "latest_failure_summary_24h": _latest_failed_execution_summary(execution_rows_24h),
        }
        worker_heartbeat = _worker_heartbeat_summary(hours=24)
        active_execution_count = _active_execution_count(conn)
        return {
            "ok": True,
            "queue_length": pressure["queue_depth"],
            # `active_workers` is preserved for compatibility with older admin consumers.
            "active_workers": active_execution_count,
            "active_execution_count": active_execution_count,
            "executions_last_5m": execution_count,
            "success_rate_last_5m": round(success_count / execution_count, 4) if execution_count else 1.0,
            "timeout_rate_last_5m": round(timeout_count / execution_count, 4) if execution_count else 0.0,
            "avg_execution_seconds": round(avg_duration, 4),
            "host_metrics": pressure["host_metrics"],
            "thresholds": pressure["thresholds"],
            "triggered_conditions": pressure["triggered_conditions"],
            "protect_local_worker": pressure["protect_local_worker"],
            "run_requests": run_requests,
            "manual_recovery": manual_recovery,
            "execution_outcomes": execution_outcomes,
            "worker_heartbeat_summary": worker_heartbeat,
        }
    finally:
        conn.close()

