import os
from datetime import datetime
from datetime import timedelta
from time import perf_counter

from .stores.execution_status import (
    _UNSET,
    get_execution_status_row,
    upsert_execution_status,
)
EXECUTION_LEASE_SECONDS = max(
    15,
    int(
        os.getenv("DISPOSABLE_EXEC_EXECUTION_LEASE_SECONDS", "").strip()
        or os.getenv("EXECUTION_LEASE_SECONDS", "").strip()
        or "30"
    ),
)


def _log_status_timing(*, execution_id: str, status_step: str, started_at: float):
    elapsed_ms = round((perf_counter() - started_at) * 1000, 1)
    print(
        f"STATUS_TIMING execution_id={execution_id} status_step={status_step} elapsed_ms={elapsed_ms}",
        flush=True,
    )


def _resolve_status_completed_by_worker_id(
    *,
    completed_by_worker_id: str | None,
    assigned_worker_id: str | None,
    existing,
) -> str | None:
    if completed_by_worker_id is not None:
        return completed_by_worker_id
    if assigned_worker_id:
        return assigned_worker_id
    if existing:
        return existing["completed_by_worker_id"] or existing["assigned_worker_id"]
    return None


def _build_lease_window(now: datetime | None = None) -> tuple[str, str]:
    current = now or datetime.utcnow()
    renewed_at = current.isoformat() + "Z"
    expires_at = (current + timedelta(seconds=EXECUTION_LEASE_SECONDS)).isoformat() + "Z"
    return renewed_at, expires_at


def set_status(
    execution_id: str,
    status: str,
    key_id: str | None = None,
    user_id: str | None = None,
    created_at: str | None = None,
    assigned_worker_id: str | None = None,
    completed_by_worker_id: str | None = None,
    claim_owner_worker_id=_UNSET,
    claim_token=_UNSET,
    claim_marked_at=_UNSET,
    lease_expires_at=_UNSET,
    last_lease_renewed_at=_UNSET,
    recovery_attempt_count=_UNSET,
    orphaned_at=_UNSET,
    requeueable=_UNSET,
    write_shared: bool = True,
    skip_existing_lookup: bool = False,
):
    now = datetime.utcnow().isoformat() + "Z"
    normalized_status = normalize_execution_status_for_write(status)
    resolved_completed_by_worker_id = _resolve_status_completed_by_worker_id(
        completed_by_worker_id=completed_by_worker_id,
        assigned_worker_id=assigned_worker_id,
        existing=None,
    )
    upsert_execution_status(
        execution_id=execution_id,
        key_id=key_id,
        user_id=user_id,
        assigned_worker_id=assigned_worker_id,
        completed_by_worker_id=resolved_completed_by_worker_id,
        status=normalized_status,
        created_at=created_at or now,
        updated_at=now,
        claim_owner_worker_id=claim_owner_worker_id,
        claim_token=claim_token,
        claim_marked_at=claim_marked_at,
        lease_expires_at=lease_expires_at,
        last_lease_renewed_at=last_lease_renewed_at,
        recovery_attempt_count=recovery_attempt_count,
        orphaned_at=orphaned_at,
        requeueable=requeueable,
        write_shared=write_shared,
        skip_existing_lookup=skip_existing_lookup,
    )


def mark_execution_claimed(
    execution_id: str,
    *,
    worker_id: str,
    claim_token: str,
    key_id: str | None = None,
    user_id: str | None = None,
    assigned_worker_id: str | None = None,
    completed_by_worker_id: str | None = None,
    claim_marked_at: str | None = None,
):
    if claim_marked_at:
        try:
            current = datetime.fromisoformat(claim_marked_at.replace("Z", "+00:00")).replace(tzinfo=None)
        except ValueError:
            current = datetime.utcnow()
    else:
        current = datetime.utcnow()
        claim_marked_at = current.isoformat() + "Z"

    renewed_at, expires_at = _build_lease_window(current)
    set_status(
        execution_id,
        "claimed",
        key_id=key_id,
        user_id=user_id,
        assigned_worker_id=assigned_worker_id,
        completed_by_worker_id=completed_by_worker_id,
        claim_owner_worker_id=worker_id,
        claim_token=claim_token,
        claim_marked_at=claim_marked_at,
        last_lease_renewed_at=renewed_at,
        lease_expires_at=expires_at,
        recovery_attempt_count=0,
        requeueable=True,
    )
    return {
        "claim_owner_worker_id": worker_id,
        "claim_token": claim_token,
        "claim_marked_at": claim_marked_at,
        "last_lease_renewed_at": renewed_at,
        "lease_expires_at": expires_at,
        "recovery_attempt_count": 0,
        "requeueable": True,
    }


def renew_execution_lease(
    execution_id: str,
    *,
    status: str,
    key_id: str | None = None,
    user_id: str | None = None,
    assigned_worker_id: str | None = None,
    completed_by_worker_id: str | None = None,
    claim_owner_worker_id: str | None = None,
    claim_token: str | None = None,
    claim_marked_at: str | None = None,
):
    renewed_at, expires_at = _build_lease_window()
    persist_started_at = perf_counter()
    # Shared claimed state already counts as active occupancy. Keep the hot
    # running transition local so the worker does not block on an extra shared
    # upsert before Docker execution starts.
    write_shared = status != "running"
    set_status(
        execution_id,
        status,
        key_id=key_id,
        user_id=user_id,
        assigned_worker_id=assigned_worker_id,
        completed_by_worker_id=completed_by_worker_id,
        claim_owner_worker_id=claim_owner_worker_id,
        claim_token=claim_token,
        claim_marked_at=claim_marked_at,
        last_lease_renewed_at=renewed_at,
        lease_expires_at=expires_at,
        write_shared=write_shared,
    )
    _log_status_timing(
        execution_id=execution_id,
        status_step="renew_execution_lease_persist",
        started_at=persist_started_at,
    )
    return {
        "last_lease_renewed_at": renewed_at,
        "lease_expires_at": expires_at,
    }


def finalize_execution_lease(
    execution_id: str,
    *,
    status: str,
    key_id: str | None = None,
    user_id: str | None = None,
    assigned_worker_id: str | None = None,
    completed_by_worker_id: str | None = None,
    claim_owner_worker_id: str | None = None,
    claim_token: str | None = None,
    claim_marked_at: str | None = None,
    write_shared: bool = True,
):
    # Preserve claim history but clear the active expiry window on terminal states.
    persist_started_at = perf_counter()
    set_status(
        execution_id,
        status,
        key_id=key_id,
        user_id=user_id,
        assigned_worker_id=assigned_worker_id,
        completed_by_worker_id=completed_by_worker_id,
        claim_owner_worker_id=claim_owner_worker_id,
        claim_token=claim_token,
        claim_marked_at=claim_marked_at,
        lease_expires_at=None,
        last_lease_renewed_at=None,
        requeueable=False,
        write_shared=write_shared,
    )
    _log_status_timing(
        execution_id=execution_id,
        status_step="finalize_execution_lease_persist",
        started_at=persist_started_at,
    )


def normalize_execution_status_for_write(raw_status: str | None) -> str:
    mapping = {
        "queued": "queued",
        "claimed": "claimed",
        "running": "running",
        "finished": "completed",
        "completed": "completed",
        "failed": "failed",
        "orphaned": "failed",
        "requeued": "queued",
    }
    return mapping.get(raw_status or "", raw_status or "queued")


def normalize_execution_status_for_read(raw_status: str | None) -> str:
    mapping = {
        "queued": "queued",
        "claimed": "claimed",
        "running": "running",
        "finished": "completed",
        "completed": "completed",
        "failed": "failed",
        "orphaned": "failed",
        "requeued": "queued",
    }
    return mapping.get(raw_status or "", raw_status or "queued")


def is_terminal_execution_status(raw_status: str | None) -> bool:
    return normalize_execution_status_for_read(raw_status) in {"completed", "failed"}


def is_success_execution_status(raw_status: str | None) -> bool:
    return normalize_execution_status_for_read(raw_status) == "completed"


def get_status(
    execution_id: str,
    key_id: str | None = None,
    user_id: str | None = None,
):
    row = get_execution_status_row(execution_id, key_id=key_id, user_id=user_id)
    if not row:
        return None

    return {
        "execution_id": row["execution_id"],
        "status": normalize_execution_status_for_read(row["status"]),
        "assigned_worker_id": row["assigned_worker_id"],
        "completed_by_worker_id": row["completed_by_worker_id"],
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
        "raw_status": row["status"],
    }
