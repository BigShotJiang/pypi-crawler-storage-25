PLAN_QUOTA = {
    "Free": 50,
    "Starter": 3000,
    "Pro": 12000,
    "Scale": 40000,
}

PLAN_KEY_LIMIT = {
    "Free": 1,
    "Starter": 1,
    "Pro": 3,
    "Scale": 10,
}

PLAN_CONCURRENCY_LIMIT = {
    "Free": 1,
    "Starter": 1,
    "Pro": 2,
    "Scale": 4,
}


def get_plan_quota(plan: str) -> int:
    return PLAN_QUOTA.get(plan, 0)


def get_plan_key_limit(plan: str) -> int:
    return PLAN_KEY_LIMIT.get(plan, 1)


def get_plan_concurrency_limit(plan: str) -> int:
    return PLAN_CONCURRENCY_LIMIT.get(plan, 1)
