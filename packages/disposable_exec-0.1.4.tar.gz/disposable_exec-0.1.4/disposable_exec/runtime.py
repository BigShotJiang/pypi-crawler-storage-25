import os
import subprocess
import tempfile
import time
from pathlib import Path, PurePosixPath


SANDBOX_IMAGE = "disposable-exec-sandbox"
SANDBOX_SCRIPT_TMP_ROOT = Path(
    os.getenv(
        "SANDBOX_SCRIPT_TMP_ROOT",
        str(Path(__file__).resolve().parent.parent / "sandbox_tmp"),
    )
)


def build_sandbox_image():
    root_dir = Path(__file__).resolve().parent.parent
    dockerfile_path = root_dir / "Dockerfile.sandbox"

    subprocess.run(
        [
            "docker",
            "build",
            "-t",
            SANDBOX_IMAGE,
            "-f",
            str(dockerfile_path),
            str(root_dir),
        ],
        check=True,
    )


def ensure_sandbox_script_tmp_root() -> Path:
    # Use a stable host-visible path so Docker can bind-mount it reliably.
    SANDBOX_SCRIPT_TMP_ROOT.mkdir(parents=True, exist_ok=True)
    return SANDBOX_SCRIPT_TMP_ROOT


def _resolve_runtime_command(language: str) -> tuple[str, list[str]]:
    normalized = (language or "python").strip().lower()
    if normalized == "bash":
        return "script.sh", ["bash", "/sandbox/input/script.sh"]
    return "script.py", ["python", "/sandbox/input/script.py"]


def _validate_relative_runtime_path(path: str) -> PurePosixPath:
    normalized = PurePosixPath(str(path or "").strip())
    if not normalized.parts:
        raise ValueError("Invalid file path")
    if normalized.is_absolute():
        raise ValueError("Absolute paths are not allowed")
    if any(part in {"", ".", ".."} for part in normalized.parts):
        raise ValueError("Path traversal is not allowed")
    return normalized


def _prepare_sandbox_dir() -> tuple[Path, tempfile.TemporaryDirectory]:
    sandbox_root_started_at = time.perf_counter()
    sandbox_root = ensure_sandbox_script_tmp_root()
    _log_runtime_timing(
        execution_id=None,
        worker_step="prepare_sandbox_root",
        started_at=sandbox_root_started_at,
    )
    tempdir_context = tempfile.TemporaryDirectory(dir=str(sandbox_root))
    script_dir = Path(tempdir_context.__enter__())
    os.chmod(script_dir, 0o755)
    return script_dir, tempdir_context


def _run_docker_command(
    *,
    script_dir: Path,
    sandbox_command: list[str],
    timeout: int,
    execution_id: str | None,
):
    start = time.time()
    docker_command = [
        "docker",
        "run",
        "--rm",
        "--memory=128m",
        "--cpus=0.5",
        "--pids-limit=64",
        "--network=none",
        "--read-only",
        "--tmpfs",
        "/tmp:rw,noexec,nosuid,size=16m",
        "-v",
        f"{script_dir}:/sandbox/input:ro",
        SANDBOX_IMAGE,
        *sandbox_command,
    ]

    before_docker_started_at = time.perf_counter()
    print(f"RUNTIME_DEBUG script_dir={script_dir}")
    print(f"RUNTIME_DEBUG docker_command={docker_command}")
    _log_runtime_timing(
        execution_id=execution_id,
        worker_step="before_docker_run",
        started_at=before_docker_started_at,
    )

    docker_run_started_at = time.perf_counter()
    result = subprocess.run(
        docker_command,
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    _log_runtime_timing(
        execution_id=execution_id,
        worker_step="after_docker_run",
        started_at=docker_run_started_at,
    )

    duration = time.time() - start
    return {
        "stdout": result.stdout,
        "stderr": result.stderr,
        "exit_code": result.returncode,
        "duration": round(duration, 3),
    }


def _log_runtime_timing(*, execution_id: str | None, worker_step: str, started_at: float):
    elapsed_ms = round((time.perf_counter() - started_at) * 1000, 1)
    print(
        f"RUNTIME_TIMING execution_id={execution_id or ''} worker_step={worker_step} elapsed_ms={elapsed_ms}",
        flush=True,
    )


def run_script_in_docker(
    script: str,
    timeout: int = 30,
    language: str = "python",
    execution_id: str | None = None,
):
    try:
        tempdir_started_at = time.perf_counter()
        script_dir_path, tempdir_context = _prepare_sandbox_dir()
        try:
            script_name, sandbox_command = _resolve_runtime_command(language)
            temp_path = script_dir_path / script_name
            _log_runtime_timing(
                execution_id=execution_id,
                worker_step="prepare_sandbox_dir",
                started_at=tempdir_started_at,
            )

            write_script_started_at = time.perf_counter()
            temp_path.write_text(script, encoding="utf-8")
            os.chmod(temp_path, 0o644)
            _log_runtime_timing(
                execution_id=execution_id,
                worker_step="write_script",
                started_at=write_script_started_at,
            )
            print(f"RUNTIME_DEBUG script_file={temp_path}")
            print(f"RUNTIME_DEBUG script_dir_mode={oct(script_dir_path.stat().st_mode & 0o777)}")
            print(f"RUNTIME_DEBUG script_file_mode={oct(temp_path.stat().st_mode & 0o777)}")
            return _run_docker_command(
                script_dir=script_dir_path,
                sandbox_command=sandbox_command,
                timeout=timeout,
                execution_id=execution_id,
            )
        finally:
            tempdir_context.__exit__(None, None, None)

    except subprocess.TimeoutExpired:
        return {
            "stdout": "",
            "stderr": "Execution timed out",
            "exit_code": -1,
            "duration": float(timeout),
        }

    except Exception as e:
        return {
            "stdout": "",
            "stderr": str(e),
            "exit_code": -1,
            "duration": 0.0,
        }


def run_files_in_docker(
    *,
    entrypoint: str,
    files: list[dict],
    timeout: int = 30,
    execution_id: str | None = None,
):
    try:
        tempdir_started_at = time.perf_counter()
        script_dir_path, tempdir_context = _prepare_sandbox_dir()
        try:
            _log_runtime_timing(
                execution_id=execution_id,
                worker_step="prepare_sandbox_dir",
                started_at=tempdir_started_at,
            )

            normalized_entrypoint = _validate_relative_runtime_path(entrypoint)

            write_files_started_at = time.perf_counter()
            for item in files:
                normalized_path = _validate_relative_runtime_path(item.get("path"))
                destination = (script_dir_path / normalized_path).resolve()
                if script_dir_path.resolve() not in destination.parents and destination != script_dir_path.resolve():
                    raise ValueError("Path escapes work directory")
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_text(str(item.get("content", "")), encoding="utf-8")
                os.chmod(destination, 0o644)
            _log_runtime_timing(
                execution_id=execution_id,
                worker_step="write_files",
                started_at=write_files_started_at,
            )

            sandbox_command = ["python", f"/sandbox/input/{normalized_entrypoint.as_posix()}"]
            print(f"RUNTIME_DEBUG entrypoint={normalized_entrypoint.as_posix()}")
            return _run_docker_command(
                script_dir=script_dir_path,
                sandbox_command=sandbox_command,
                timeout=timeout,
                execution_id=execution_id,
            )
        finally:
            tempdir_context.__exit__(None, None, None)
    except subprocess.TimeoutExpired:
        return {
            "stdout": "",
            "stderr": "Execution timed out",
            "exit_code": -1,
            "duration": float(timeout),
        }
    except Exception as e:
        return {
            "stdout": "",
            "stderr": str(e),
            "exit_code": -1,
            "duration": 0.0,
        }
