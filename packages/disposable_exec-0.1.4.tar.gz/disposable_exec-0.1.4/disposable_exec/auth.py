from datetime import datetime
import hashlib
import os
import secrets

from fastapi import Header, HTTPException

from .stores.api_keys import (
    count_api_keys_for_user as store_count_api_keys_for_user,
    create_api_key_record,
    disable_api_key as store_disable_api_key,
    find_active_api_key_by_hash,
    list_api_keys_for_user as store_list_api_keys_for_user,
    load_api_keys as store_load_api_keys,
)


def hash_api_key(raw_key: str) -> str:
    return hashlib.sha256(raw_key.encode()).hexdigest()


def get_api_key_prefix() -> str:
    env = (os.getenv("POLAR_ENV", "live") or "live").strip().lower()
    return "exec_sbx_" if env == "sandbox" else "exec_live_"


def load_api_keys():
    return store_load_api_keys()


def find_api_key(raw_key: str):
    key_hash = hash_api_key(raw_key)
    return find_active_api_key_by_hash(key_hash)


def create_api_key(user_id: str, name: str = "default", plan: str = "Free"):
    raw_key = get_api_key_prefix() + secrets.token_urlsafe(24)
    key_hash = hash_api_key(raw_key)

    record = create_api_key_record(
        user_id=user_id,
        name=name,
        api_key_hash=key_hash,
        plan=plan,
        is_active=1,
        created_at=datetime.utcnow().isoformat() + "Z",
    )

    return raw_key, record


def disable_api_key(key_id: str):
    return store_disable_api_key(key_id)


def list_api_keys_for_user(user_id: str):
    return store_list_api_keys_for_user(user_id)


def count_api_keys_for_user(user_id: str) -> int:
    return store_count_api_keys_for_user(user_id)


def verify_api_key(authorization: str = Header(None)):
    if authorization is None:
        raise HTTPException(status_code=401, detail="Missing Authorization header")

    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid Authorization format")

    raw_key = authorization.removeprefix("Bearer ").strip()
    if not raw_key:
        raise HTTPException(status_code=401, detail="Empty API key")

    record = find_api_key(raw_key)
    if not record:
        raise HTTPException(status_code=401, detail="Invalid API Key")

    return record
