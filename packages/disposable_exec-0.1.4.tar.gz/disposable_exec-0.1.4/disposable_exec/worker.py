import threading
import time
from os import getenv

from disposable_exec.alerts import send_operational_event
from disposable_exec.logs import write_log
from disposable_exec.metrics import get_host_pressure_snapshot
from disposable_exec.queue import dequeue_job
from disposable_exec.results import save_result, terminal_status_for_exit_code
from disposable_exec.runtime import run_files_in_docker, run_script_in_docker
from disposable_exec.status import finalize_execution_lease, renew_execution_lease
from disposable_exec.stores.workers import ensure_worker_record, get_worker, set_worker_heartbeat, update_worker_state

LEASE_RENEW_INTERVAL_SECONDS = max(
    2.0,
    float(
        getenv("DISPOSABLE_EXEC_EXECUTION_LEASE_RENEW_INTERVAL_SECONDS", "").strip()
        or getenv("EXECUTION_LEASE_RENEW_INTERVAL_SECONDS", "").strip()
        or "3"
    ),
)


def _log_worker_timing(*, execution_id: str, worker_step: str, started_at: float):
    elapsed_ms = round((time.perf_counter() - started_at) * 1000, 1)
    print(
        f"WORKER_TIMING execution_id={execution_id} worker_step={worker_step} elapsed_ms={elapsed_ms}",
        flush=True,
    )


def resolve_worker_id(configured_worker_id: str | None = None) -> str:
    if configured_worker_id is None:
        configured_worker_id = getenv("DISPOSABLE_EXEC_WORKER_ID", "")
    normalized = str(configured_worker_id or "").strip()
    return normalized or "local-worker"


def resolve_completion_worker_id(job_assigned_worker_id: str | None, configured_worker_id: str | None = None) -> str:
    assigned_worker_id = str(job_assigned_worker_id or "").strip()
    return assigned_worker_id or resolve_worker_id(configured_worker_id)


def start_execution_lease_renewer(
    *,
    execution_id: str,
    worker_id: str,
    key_id: str | None,
    user_id: str | None,
    assigned_worker_id: str | None,
    completed_by_worker_id: str | None,
    claim_token: str | None,
    claim_marked_at: str | None,
):
    stop_event = threading.Event()

    def _renew_loop():
        while not stop_event.wait(LEASE_RENEW_INTERVAL_SECONDS):
            try:
                renew_execution_lease(
                    execution_id,
                    status="running",
                    key_id=key_id,
                    user_id=user_id,
                    assigned_worker_id=assigned_worker_id,
                    completed_by_worker_id=completed_by_worker_id,
                    claim_owner_worker_id=worker_id,
                    claim_token=claim_token,
                    claim_marked_at=claim_marked_at,
                )
            except Exception as exc:
                # Lease renewal is best-effort in phase 1 so execution flow stays low-risk.
                print(
                    f"WORKER_LEASE_RENEW_FAILED worker_id={worker_id} execution_id={execution_id} detail={exc}",
                    flush=True,
                )

    thread = threading.Thread(target=_renew_loop, name=f"lease-renew-{execution_id}", daemon=True)
    thread.start()
    return stop_event, thread


def stop_execution_lease_renewer(stop_event: threading.Event, thread: threading.Thread) -> None:
    stop_event.set()
    thread.join(timeout=1.0)


def main():
    print("Worker started...")
    worker_id = resolve_worker_id()
    ensure_worker_record(worker_id, label=worker_id, max_concurrency=1, enabled=True, status="active")

    while True:
        worker_id = resolve_worker_id()
        pressure = get_host_pressure_snapshot()
        for condition in pressure["triggered_conditions"]:
            send_operational_event(
                category="health" if condition["code"] != "queue_depth_critical" and condition["code"] != "queue_depth_high" else "execution",
                event=condition["code"],
                severity=condition["severity"],
                worker_id=worker_id,
                detail=f"value={condition['value']} threshold={condition['threshold']}",
                cooldown_seconds=300,
            )

        worker_state = get_worker(worker_id) or {}
        if pressure["protect_local_worker"] and worker_state.get("status") == "active":
            # Production-safe auto-protection: stop taking new work when host pressure is critical.
            update_worker_state(worker_id, enabled=True, status="draining")
            send_operational_event(
                category="worker",
                event="auto_draining_due_to_host_pressure",
                severity="critical",
                worker_id=worker_id,
                detail="Critical host pressure triggered local worker draining.",
                cooldown_seconds=300,
            )
            worker_state = get_worker(worker_id) or {}

        current_status = worker_state.get("status") or "active"
        enabled = bool(worker_state.get("enabled", True))

        if not enabled or current_status in {"disabled", "offline"}:
            # Remote worker preparation with current local compatibility: disabled/offline
            # workers stay visible but stop claiming new work.
            set_worker_heartbeat(worker_id=worker_id, status="disabled" if not enabled else current_status)
            time.sleep(1.0)
            continue

        allow_unassigned = current_status != "draining"
        heartbeat_status = "draining" if current_status == "draining" else "active"
        set_worker_heartbeat(worker_id=worker_id, status=heartbeat_status)
        job = dequeue_job(worker_id=worker_id, allow_unassigned=allow_unassigned)

        if not job:
            time.sleep(0.2)
            continue

        claim_returned_at = time.perf_counter()
        execution_id = job["execution_id"]
        code = job["script"]
        entrypoint = job.get("entrypoint")
        files = job.get("files")
        language = job.get("language") or "python"
        key_id = job.get("key_id")
        user_id = job.get("user_id")
        assigned_worker_id = job.get("assigned_worker_id") or worker_id
        completion_worker_id = resolve_completion_worker_id(job.get("assigned_worker_id"), worker_id)
        claim_token = job.get("claim_token")
        claim_marked_at = job.get("claim_marked_at")

        if job.get("assigned_worker_id"):
            print(
                f"WORKER_ASSIGNED_JOB_SEEN worker_id={worker_id} execution_id={execution_id} assigned_worker_id={job.get('assigned_worker_id')}",
                flush=True,
            )
        if job.get("reclaimed_assigned_job"):
            print(
                "WORKER_ASSIGNED_JOB_RECLAIMED "
                f"worker_id={worker_id} execution_id={execution_id} previous_assigned_worker_id={job.get('reclaimed_from_worker_id', '')}",
                flush=True,
            )

        print(
            f"WORKER_EXECUTION_START worker_id={worker_id} execution_id={execution_id} assigned_worker_id={assigned_worker_id}",
            flush=True,
        )
        _log_worker_timing(
            execution_id=execution_id,
            worker_step="claim_to_start",
            started_at=claim_returned_at,
        )

        running_transition_started_at = time.perf_counter()
        renew_execution_lease(
            execution_id,
            status="running",
            key_id=key_id,
            user_id=user_id,
            assigned_worker_id=assigned_worker_id,
            completed_by_worker_id=completion_worker_id,
            claim_owner_worker_id=worker_id,
            claim_token=claim_token,
            claim_marked_at=claim_marked_at,
        )
        _log_worker_timing(
            execution_id=execution_id,
            worker_step="transition_running_lease",
            started_at=running_transition_started_at,
        )
        print(
            f"WORKER_STATUS_UPDATED worker_id={worker_id} execution_id={execution_id} from_status=claimed to_status=running assigned_worker_id={assigned_worker_id} completed_by_worker_id={completion_worker_id}",
            flush=True,
        )

        lease_renewer_started_at = time.perf_counter()
        lease_stop_event, lease_thread = start_execution_lease_renewer(
            execution_id=execution_id,
            worker_id=worker_id,
            key_id=key_id,
            user_id=user_id,
            assigned_worker_id=assigned_worker_id,
            completed_by_worker_id=completion_worker_id,
            claim_token=claim_token,
            claim_marked_at=claim_marked_at,
        )
        _log_worker_timing(
            execution_id=execution_id,
            worker_step="start_lease_renewer",
            started_at=lease_renewer_started_at,
        )

        try:
            # Widen the manual recovery validation window without changing queue/orphan rules.
            runtime_started_at = time.perf_counter()
            if entrypoint and files:
                output = run_files_in_docker(
                    entrypoint=entrypoint,
                    files=files,
                    timeout=30,
                    execution_id=execution_id,
                )
            else:
                output = run_script_in_docker(
                    code,
                    timeout=30,
                    language=language,
                    execution_id=execution_id,
                )
            _log_worker_timing(
                execution_id=execution_id,
                worker_step="after_docker_run",
                started_at=runtime_started_at,
            )

            write_log_started_at = time.perf_counter()
            write_log(
                execution_id,
                key_id,
                output["stdout"],
                output["stderr"],
                output["exit_code"],
                output["duration"],
            )
            _log_worker_timing(
                execution_id=execution_id,
                worker_step="persist_log",
                started_at=write_log_started_at,
            )

            try:
                persist_result_started_at = time.perf_counter()
                terminal_status = terminal_status_for_exit_code(output["exit_code"])
                terminal_status_written_to_shared = save_result(
                    execution_id,
                    output,
                    key_id=key_id,
                    user_id=user_id,
                    completed_by_worker_id=completion_worker_id,
                    terminal_status=terminal_status,
                    assigned_worker_id=assigned_worker_id,
                    claim_owner_worker_id=worker_id,
                    claim_token=claim_token,
                    claim_marked_at=claim_marked_at,
                )
                _log_worker_timing(
                    execution_id=execution_id,
                    worker_step="persist_result",
                    started_at=persist_result_started_at,
                )
            except Exception as writeback_exc:
                print(f"RESULT_WRITEBACK_FAILED execution_id={execution_id} detail={writeback_exc}")
                send_operational_event(
                    category="execution",
                    event="result_writeback_failed",
                    severity="critical",
                    user_id=user_id,
                    worker_id=completion_worker_id,
                    execution_id=execution_id,
                    detail=str(writeback_exc),
                    cooldown_seconds=300,
                )
                raise

            # Stop lease renewal before writing the terminal status so a late
            # renew loop cannot overwrite completed/failed back to running.
            stop_execution_lease_renewer(lease_stop_event, lease_thread)
            finalize_execution_lease(
                execution_id,
                status=terminal_status,
                key_id=key_id,
                user_id=user_id,
                assigned_worker_id=assigned_worker_id,
                completed_by_worker_id=completion_worker_id,
                claim_owner_worker_id=worker_id,
                claim_token=claim_token,
                claim_marked_at=claim_marked_at,
                write_shared=not terminal_status_written_to_shared,
            )

            print(
                f"WORKER_EXECUTION_COMPLETED worker_id={worker_id} execution_id={execution_id} completed_by_worker_id={completion_worker_id} exit_code={output['exit_code']} duration={output['duration']}",
                flush=True,
                )

        except Exception as e:
            # Stop lease renewal before terminal failure status is written for
            # the same reason as the success path above.
            stop_execution_lease_renewer(lease_stop_event, lease_thread)
            terminal_status_written_to_shared = False

            try:
                terminal_status_written_to_shared = save_result(
                    execution_id,
                    {
                        "stdout": "",
                        "stderr": str(e),
                        "exit_code": -1,
                        "duration": 0,
                    },
                    key_id=key_id,
                    user_id=user_id,
                    completed_by_worker_id=completion_worker_id,
                    terminal_status="failed",
                    assigned_worker_id=assigned_worker_id,
                    claim_owner_worker_id=worker_id,
                    claim_token=claim_token,
                    claim_marked_at=claim_marked_at,
                )
            except Exception as writeback_exc:
                print(f"RESULT_WRITEBACK_FAILED execution_id={execution_id} detail={writeback_exc}")
                send_operational_event(
                    category="execution",
                    event="result_writeback_failed",
                    severity="critical",
                    user_id=user_id,
                    worker_id=completion_worker_id,
                    execution_id=execution_id,
                    detail=str(writeback_exc),
                    cooldown_seconds=300,
                )

            finalize_execution_lease(
                execution_id,
                status="failed",
                key_id=key_id,
                user_id=user_id,
                assigned_worker_id=assigned_worker_id,
                completed_by_worker_id=completion_worker_id,
                claim_owner_worker_id=worker_id,
                claim_token=claim_token,
                claim_marked_at=claim_marked_at,
                write_shared=not terminal_status_written_to_shared,
            )

            print(
                f"WORKER_EXECUTION_FAILED worker_id={worker_id} execution_id={execution_id} completed_by_worker_id={completion_worker_id} detail={e}",
                flush=True,
            )
            send_operational_event(
                category="execution",
                event="job_execution_failed",
                severity="warning",
                user_id=user_id,
                worker_id=completion_worker_id,
                execution_id=execution_id,
                detail=str(e),
                cooldown_seconds=300,
            )
        finally:
            stop_execution_lease_renewer(lease_stop_event, lease_thread)


if __name__ == "__main__":
    main()
