from __future__ import annotations

from datetime import datetime, timezone
from os import getenv
from time import perf_counter

from .alerts import send_operational_event
from .queue import enqueue_existing_job
from .results import get_result, save_result
from .shared_execution_results import (
    get_shared_execution_result,
    is_shared_execution_results_backing_enabled,
)
from .shared_execution_state import is_shared_execution_backing_enabled
from .status import set_status
from .stores.execution_payloads import get_execution_payload
from .stores.execution_status import list_execution_status_rows
from .stores.workers import get_worker, is_worker_heartbeat_fresh


ORPHAN_CANDIDATE_STATUSES = {"claimed", "running"}
SHARED_EXECUTION_SELF_HEAL_INTERVAL_SECONDS = max(
    5.0,
    float(
        getenv("DISPOSABLE_EXEC_SHARED_EXECUTION_SELF_HEAL_INTERVAL_SECONDS", "").strip()
        or getenv("SHARED_EXECUTION_SELF_HEAL_INTERVAL_SECONDS", "").strip()
        or "15"
    ),
)


def _parse_iso_utc(value: str | None):
    if not value:
        return None
    normalized = str(value).strip()
    if not normalized:
        return None
    if normalized.endswith("Z"):
        normalized = normalized[:-1] + "+00:00"
    try:
        return datetime.fromisoformat(normalized)
    except ValueError:
        return None


def _is_lease_expired(lease_expires_at: str | None) -> bool:
    expires_at = _parse_iso_utc(lease_expires_at)
    if not expires_at:
        return False
    return expires_at <= datetime.now(timezone.utc)


def _worker_is_untrusted(worker_id: str | None) -> bool:
    if not worker_id:
        return True
    worker = get_worker(worker_id)
    if not worker or not bool(worker.get("enabled")):
        return True
    if worker.get("status") in {"disabled", "offline"}:
        return True
    return not is_worker_heartbeat_fresh(worker.get("last_heartbeat_at"))


def _write_platform_failure_result_if_needed(row: dict, detail: str) -> None:
    execution_id = row["execution_id"]
    if get_result(execution_id, key_id=row.get("key_id"), user_id=row.get("user_id")) is not None:
        return
    save_result(
        execution_id,
        {
            "stdout": "",
            "stderr": detail,
            "exit_code": -1,
            "duration": 0,
        },
        key_id=row.get("key_id"),
        user_id=row.get("user_id"),
        completed_by_worker_id=row.get("completed_by_worker_id") or row.get("claim_owner_worker_id"),
    )


def _repair_terminal_status_from_result_if_present(row: dict) -> bool:
    result = get_result(row["execution_id"], key_id=row.get("key_id"), user_id=row.get("user_id"))
    if result is None:
        return False

    set_status(
        row["execution_id"],
        "completed" if int(result.get("exit_code") or 0) == 0 else "failed",
        key_id=row.get("key_id"),
        user_id=row.get("user_id"),
        assigned_worker_id=row.get("assigned_worker_id"),
        completed_by_worker_id=row.get("completed_by_worker_id") or result.get("completed_by_worker_id"),
        claim_owner_worker_id=row.get("claim_owner_worker_id"),
        claim_token=row.get("claim_token"),
        claim_marked_at=row.get("claim_marked_at"),
        lease_expires_at=None,
        last_lease_renewed_at=None,
        requeueable=False,
    )
    return True


def _mark_execution_orphaned(row: dict, *, orphaned_at: str, recovery_attempt_count: int, requeueable: bool) -> None:
    set_status(
        row["execution_id"],
        "orphaned",
        key_id=row.get("key_id"),
        user_id=row.get("user_id"),
        assigned_worker_id=row.get("assigned_worker_id"),
        completed_by_worker_id=row.get("completed_by_worker_id"),
        claim_owner_worker_id=row.get("claim_owner_worker_id"),
        claim_token=row.get("claim_token"),
        claim_marked_at=row.get("claim_marked_at"),
        lease_expires_at=None,
        last_lease_renewed_at=None,
        recovery_attempt_count=recovery_attempt_count,
        orphaned_at=orphaned_at,
        requeueable=requeueable,
    )


def _mark_execution_failed(row: dict, *, orphaned_at: str, recovery_attempt_count: int, detail: str) -> None:
    set_status(
        row["execution_id"],
        "failed",
        key_id=row.get("key_id"),
        user_id=row.get("user_id"),
        assigned_worker_id=row.get("assigned_worker_id"),
        completed_by_worker_id=row.get("completed_by_worker_id"),
        claim_owner_worker_id=row.get("claim_owner_worker_id"),
        claim_token=row.get("claim_token"),
        claim_marked_at=row.get("claim_marked_at"),
        lease_expires_at=None,
        last_lease_renewed_at=None,
        recovery_attempt_count=recovery_attempt_count,
        orphaned_at=orphaned_at,
        requeueable=False,
    )
    _write_platform_failure_result_if_needed(row, detail)


def reconcile_stale_shared_execution_states() -> dict:
    total_started_at = perf_counter()
    summary = {
        "scanned": 0,
        "healed": 0,
    }

    if not is_shared_execution_backing_enabled() or not is_shared_execution_results_backing_enabled():
        return summary

    rows = list_execution_status_rows(statuses=ORPHAN_CANDIDATE_STATUSES)
    for row in rows:
        summary["scanned"] += 1
        if row.get("execution_state_truth") != "shared":
            continue

        execution_id = row["execution_id"]
        result = get_shared_execution_result(execution_id)
        if result is None:
            continue

        # Shared result truth is enough to safely finalize a stale claimed/running
        # shared execution row without guessing terminal outcome.
        terminal_status = "completed" if int(result.get("exit_code") or 0) == 0 else "failed"
        completed_by_worker_id = result.get("completed_by_worker_id") or row.get("completed_by_worker_id")
        set_status(
            execution_id,
            terminal_status,
            key_id=row.get("key_id"),
            user_id=row.get("user_id"),
            assigned_worker_id=row.get("assigned_worker_id"),
            completed_by_worker_id=completed_by_worker_id,
            claim_owner_worker_id=row.get("claim_owner_worker_id"),
            claim_token=row.get("claim_token"),
            claim_marked_at=row.get("claim_marked_at"),
            lease_expires_at=None,
            last_lease_renewed_at=None,
            requeueable=False,
        )
        print(
            "SHARED_EXECUTION_STATE_SELF_HEAL "
            f"execution_id={execution_id} "
            f"previous_status={row.get('status')} "
            f"terminal_status={terminal_status} "
            f"assigned_worker_id={row.get('assigned_worker_id', '')} "
            f"completed_by_worker_id={completed_by_worker_id or ''}",
            flush=True,
        )
        send_operational_event(
            category="execution",
            event="shared_execution_state_self_healed",
            severity="info",
            user_id=row.get("user_id"),
            worker_id=completed_by_worker_id or row.get("assigned_worker_id"),
            execution_id=execution_id,
            detail=(
                f"previous_status={row.get('status')} "
                f"terminal_status={terminal_status} "
                f"assigned_worker_id={row.get('assigned_worker_id', '')} "
                f"completed_by_worker_id={completed_by_worker_id or ''}"
            ),
            cooldown_seconds=60,
        )
        summary["healed"] += 1

    elapsed_ms = round((perf_counter() - total_started_at) * 1000, 1)
    print(
        "SHARED_EXECUTION_SELF_HEAL_TIMING "
        f"scanned={summary['scanned']} healed={summary['healed']} elapsed_ms={elapsed_ms}",
        flush=True,
    )
    return summary


def recover_orphaned_executions() -> dict:
    summary = {
        "scanned": 0,
        "orphaned": 0,
        "requeued": 0,
        "failed": 0,
    }

    rows = list_execution_status_rows(statuses=ORPHAN_CANDIDATE_STATUSES)
    for row in rows:
        summary["scanned"] += 1
        if _repair_terminal_status_from_result_if_present(row):
            continue
        if not _is_lease_expired(row.get("lease_expires_at")):
            continue

        claim_owner_worker_id = row.get("claim_owner_worker_id")
        if not _worker_is_untrusted(claim_owner_worker_id):
            continue

        orphaned_at = datetime.utcnow().isoformat() + "Z"
        recovery_attempt_count = int(row.get("recovery_attempt_count") or 0)
        requeueable = bool(row.get("requeueable")) if row.get("requeueable") is not None else False

        _mark_execution_orphaned(
            row,
            orphaned_at=orphaned_at,
            recovery_attempt_count=recovery_attempt_count,
            requeueable=requeueable,
        )
        summary["orphaned"] += 1

        payload = get_execution_payload(row["execution_id"])
        payload_key_id = (payload or {}).get("key_id") or row.get("key_id")
        should_attempt_requeue = (
            recovery_attempt_count == 0
            and requeueable
            and payload is not None
            and bool(payload_key_id)
        )

        if not should_attempt_requeue:
            _mark_execution_failed(
                row,
                orphaned_at=orphaned_at,
                recovery_attempt_count=recovery_attempt_count,
                detail="Execution lease expired and worker ownership became untrusted. Automatic recovery was not possible.",
            )
            summary["failed"] += 1
            continue

        try:
            enqueue_existing_job(
                row["execution_id"],
                script=payload["script"],
                key_id=payload_key_id,
                user_id=(payload or {}).get("user_id") or row.get("user_id"),
                assigned_worker_id=(payload or {}).get("assigned_worker_id") or row.get("assigned_worker_id"),
                language=(payload or {}).get("language") or "python",
                entrypoint=(payload or {}).get("entrypoint"),
                files=(payload or {}).get("files"),
            )
            set_status(
                row["execution_id"],
                "queued",
                key_id=payload_key_id,
                user_id=(payload or {}).get("user_id") or row.get("user_id"),
                assigned_worker_id=(payload or {}).get("assigned_worker_id") or row.get("assigned_worker_id"),
                completed_by_worker_id=row.get("completed_by_worker_id"),
                claim_owner_worker_id=row.get("claim_owner_worker_id"),
                claim_token=row.get("claim_token"),
                claim_marked_at=row.get("claim_marked_at"),
                lease_expires_at=None,
                last_lease_renewed_at=None,
                recovery_attempt_count=1,
                orphaned_at=orphaned_at,
                requeueable=False,
            )
            summary["requeued"] += 1
        except Exception as exc:
            _mark_execution_failed(
                row,
                orphaned_at=orphaned_at,
                recovery_attempt_count=1,
                detail=f"Execution lease expired and automatic requeue failed: {exc}",
            )
            summary["failed"] += 1

    return summary
