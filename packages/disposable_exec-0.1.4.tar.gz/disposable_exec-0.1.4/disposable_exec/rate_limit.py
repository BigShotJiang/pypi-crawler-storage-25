from datetime import datetime

from .stores.rate_limits import (
    ensure_rate_limit_tables,
    increment_ip_rate_limit,
    increment_key_rate_limit,
)


def init_rate_limit_table():
    ensure_rate_limit_tables()


def get_minute_window_key() -> str:
    return datetime.utcnow().strftime("%Y-%m-%dT%H:%M")


def get_hour_window_key() -> str:
    return datetime.utcnow().strftime("%Y-%m-%dT%H")


def check_and_increment_rate_limit(key_id: str, route: str, limit: int) -> dict:
    window_key = get_minute_window_key()
    return increment_key_rate_limit(key_id, route, window_key, limit)


def check_and_increment_ip_rate_limit(ip_address: str, route: str, limit: int) -> dict:
    normalized_ip = (ip_address or "unknown").strip() or "unknown"
    window_key = get_hour_window_key()
    return increment_ip_rate_limit(normalized_ip, route, window_key, limit)


init_rate_limit_table()
