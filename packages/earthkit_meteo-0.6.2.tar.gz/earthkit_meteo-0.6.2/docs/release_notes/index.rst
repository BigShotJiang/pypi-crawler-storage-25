Release notes
==============

.. toctree::
    :maxdepth: 1

    version_0.6_updates
    version_0.5_updates
    version_0.4_updates
    version_0.3_updates
    version_0.2_updates
    version_0.1_updates
