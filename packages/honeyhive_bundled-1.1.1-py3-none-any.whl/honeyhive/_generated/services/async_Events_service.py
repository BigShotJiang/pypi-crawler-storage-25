from typing import *

from ..api_config import APIConfig, HTTPException, _make_request_async
from ..models import *


async def createEvent(
    api_config_override: Optional[APIConfig] = None, *, data: PostEventRequestBody
) -> PostEventResponse:
    api_config = api_config_override if api_config_override else APIConfig()

    path = f"/events"
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": f"Bearer { api_config.get_access_token() }",
    }
    query_params: Dict[str, Any] = {}

    query_params = {
        key: value for (key, value) in query_params.items() if value is not None
    }

    response = await _make_request_async(
        api_config,
        "post",
        path,
        headers,
        params=query_params,
        json=data.model_dump(exclude_none=True),
    )

    if response.status_code != 200:
        raise HTTPException(
            response.status_code,
            f"createEvent failed with status code: {response.status_code}",
        )
    else:
        body = response.json()

    return PostEventResponse(**body)


async def updateEvent(
    api_config_override: Optional[APIConfig] = None, *, data: UpdateEventRequest
) -> None:
    api_config = api_config_override if api_config_override else APIConfig()

    path = f"/events"
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": f"Bearer { api_config.get_access_token() }",
    }
    query_params: Dict[str, Any] = {}

    query_params = {
        key: value for (key, value) in query_params.items() if value is not None
    }

    response = await _make_request_async(
        api_config,
        "put",
        path,
        headers,
        params=query_params,
        json=data.model_dump(exclude_none=True),
    )

    if response.status_code != 200:
        raise HTTPException(
            response.status_code,
            f"updateEvent failed with status code: {response.status_code}",
        )
    else:
        body = response.json()

    return None


async def getEvents(
    api_config_override: Optional[APIConfig] = None, *, data: GetEventsRequest
) -> GetEventsResponse:
    api_config = api_config_override if api_config_override else APIConfig()

    path = f"/events/export"
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": f"Bearer { api_config.get_access_token() }",
    }
    query_params: Dict[str, Any] = {}

    query_params = {
        key: value for (key, value) in query_params.items() if value is not None
    }

    response = await _make_request_async(
        api_config,
        "post",
        path,
        headers,
        params=query_params,
        json=data.model_dump(exclude_none=True),
    )

    if response.status_code != 200:
        raise HTTPException(
            response.status_code,
            f"getEvents failed with status code: {response.status_code}",
        )
    else:
        body = response.json()

    return GetEventsResponse(**body)


async def createModelEvent(
    api_config_override: Optional[APIConfig] = None,
    *,
    data: CreateModelEventRequestBody,
) -> PostEventResponse:
    api_config = api_config_override if api_config_override else APIConfig()

    path = f"/events/model"
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": f"Bearer { api_config.get_access_token() }",
    }
    query_params: Dict[str, Any] = {}

    query_params = {
        key: value for (key, value) in query_params.items() if value is not None
    }

    response = await _make_request_async(
        api_config,
        "post",
        path,
        headers,
        params=query_params,
        json=data.model_dump(exclude_none=True),
    )

    if response.status_code != 200:
        raise HTTPException(
            response.status_code,
            f"createModelEvent failed with status code: {response.status_code}",
        )
    else:
        body = response.json()

    return PostEventResponse(**body)


async def createEventBatch(
    api_config_override: Optional[APIConfig] = None, *, data: CreateEventBatchRequest
) -> PostEventBatchResponse:
    api_config = api_config_override if api_config_override else APIConfig()

    path = f"/events/batch"
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": f"Bearer { api_config.get_access_token() }",
    }
    query_params: Dict[str, Any] = {}

    query_params = {
        key: value for (key, value) in query_params.items() if value is not None
    }

    response = await _make_request_async(
        api_config,
        "post",
        path,
        headers,
        params=query_params,
        json=data.model_dump(exclude_none=True),
    )

    if response.status_code != 200:
        raise HTTPException(
            response.status_code,
            f"createEventBatch failed with status code: {response.status_code}",
        )
    else:
        body = response.json()

    return PostEventBatchResponse(**body)


async def createModelEventBatch(
    api_config_override: Optional[APIConfig] = None,
    *,
    data: CreateModelEventBatchRequest,
) -> CreateModelEventBatchResponse:
    api_config = api_config_override if api_config_override else APIConfig()

    path = f"/events/model/batch"
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": f"Bearer { api_config.get_access_token() }",
    }
    query_params: Dict[str, Any] = {}

    query_params = {
        key: value for (key, value) in query_params.items() if value is not None
    }

    response = await _make_request_async(
        api_config,
        "post",
        path,
        headers,
        params=query_params,
        json=data.model_dump(exclude_none=True),
    )

    if response.status_code != 200:
        raise HTTPException(
            response.status_code,
            f"createModelEventBatch failed with status code: {response.status_code}",
        )
    else:
        body = response.json()

    return CreateModelEventBatchResponse(**body)
