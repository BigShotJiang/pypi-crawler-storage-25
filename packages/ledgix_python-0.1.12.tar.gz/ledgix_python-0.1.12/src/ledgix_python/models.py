# Ledgix ALCV — Data Models
# Pydantic models for Vault API request/response payloads

from __future__ import annotations

from typing import Any

from pydantic import AliasChoices, BaseModel, ConfigDict, Field, field_validator


class ClearanceRequest(BaseModel):
    """Payload sent to the Vault's ``/request-clearance`` endpoint."""

    tool_name: str = Field(..., description="Name of the tool the agent wants to invoke")
    tool_args: dict[str, Any] = Field(
        default_factory=dict,
        description="Arguments the agent will pass to the tool",
    )
    agent_id: str = Field(default="default-agent", description="Identifier for the calling agent")
    session_id: str = Field(default="", description="Session grouping identifier")
    context: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional context for the Vault's policy judge (e.g. conversation history)",
    )


class ClearanceResponse(BaseModel):
    """Response from the Vault's ``/request-clearance`` endpoint."""

    status: str = Field(default="denied", description="Decision state: processing, approved, denied, or pending_review")
    approved: bool = Field(..., description="Whether the tool call was approved")
    requires_manual_review: bool = Field(default=False, description="Whether the request is pending human review")
    token: str | None = Field(default=None, description="Signed A-JWT if approved, None if denied")
    reason: str = Field(default="", description="Human-readable explanation of the decision")
    request_id: str = Field(default="", description="Vault-assigned unique ID for this request")
    confidence: float = Field(default=0.0, ge=0.0, le=1.0, description="Judge confidence score")
    minimum_confidence_score: float = Field(
        default=0.0,
        ge=0.0,
        le=1.0,
        description="Client-configured minimum confidence score for auto approval",
    )


class PolicyRegistration(BaseModel):
    """Payload for registering a policy with the Vault."""

    policy_id: str = Field(..., description="Unique identifier for the policy")
    description: str = Field(default="", description="Human-readable description of the policy")
    rules: list[str] = Field(
        default_factory=list,
        description="List of plain-English rules (e.g. 'Refunds must not exceed $100')",
    )
    tools: list[str] = Field(
        default_factory=list,
        description="Tool names this policy applies to (empty = all tools)",
    )


class PolicyRegistrationResponse(BaseModel):
    """Response from the Vault's ``/register-policy`` endpoint."""

    policy_id: str = Field(..., description="Confirmed policy ID")
    status: str = Field(default="registered", description="Registration status")
    message: str = Field(default="", description="Additional information")


class LedgerEntry(BaseModel):
    """Ledger entry returned by the Vault's ledger endpoints."""

    model_config = ConfigDict(populate_by_name=True)

    seq: int
    event_uuid: str
    request_id: str
    agent_id: str = ""
    policy_id: str = ""
    policy_version_id: str = ""
    policy_content_hash: str = ""
    intent_hash: str = ""
    tool_name: str
    tool_args: dict[str, Any] = Field(default_factory=dict)
    action_category: str = ""
    action_metadata: dict[str, Any] = Field(default_factory=dict)
    reason: str = ""
    citations: list[dict[str, Any]] = Field(default_factory=list)
    evidence_chunks: list[dict[str, Any]] = Field(default_factory=list)
    confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    approved: bool
    accepted_at: str = Field(validation_alias=AliasChoices("accepted_at", "decided_at"))
    canonical_version: int = 1
    event_hash: str
    leaf_hash: str
    leaf_index: int | None = None
    checkpoint_id: int | None = None
    receipt_algorithm: str = Field(
        default="",
        validation_alias=AliasChoices("receipt_algorithm", "signature_algorithm"),
    )
    receipt_key_id: str = Field(
        default="",
        validation_alias=AliasChoices("receipt_key_id", "signer_key_id"),
    )
    receipt_signature: str = Field(
        default="",
        validation_alias=AliasChoices("receipt_signature", "row_signature"),
    )
    receipt_payload: str = Field(default="")

    @field_validator("tool_args", "action_metadata", mode="before")
    @classmethod
    def _normalize_nullable_dicts(cls, value: Any) -> Any:
        if value is None:
            return {}
        return value

    @field_validator("citations", "evidence_chunks", mode="before")
    @classmethod
    def _normalize_nullable_lists(cls, value: Any) -> Any:
        if value is None:
            return []
        return value


class LedgerCheckpoint(BaseModel):
    """Signed checkpoint returned by the Vault."""

    model_config = ConfigDict(populate_by_name=True)

    checkpoint_id: int
    microblock_id: int = 0
    tree_size: int
    root_hash: str = Field(validation_alias=AliasChoices("root_hash", "head_row_hash"))
    checkpoint_hash: str = Field(
        validation_alias=AliasChoices("checkpoint_hash", "manifest_hash"),
    )
    prev_checkpoint_hash: str = Field(
        default="",
        validation_alias=AliasChoices("prev_checkpoint_hash", "prev_manifest_hash"),
    )
    signature_algorithm: str = Field(
        default="",
        validation_alias=AliasChoices("signature_algorithm", "signature_algorithm"),
    )
    signer_key_id: str = ""
    checkpoint_signature: str = Field(
        default="",
        validation_alias=AliasChoices("checkpoint_signature", "manifest_signature"),
    )
    checkpoint_payload: str = Field(
        default="",
        validation_alias=AliasChoices("checkpoint_payload", "manifest_payload"),
    )
    signed_at: str = Field(validation_alias=AliasChoices("signed_at", "generated_at", "period_start"))
    mmd_seconds: int = 30
    export_target: str = ""
    export_uri: str = ""
    export_status: str = ""
    exported_at: str | None = None


LedgerManifest = LedgerCheckpoint


class LedgerKeyVersion(BaseModel):
    key_id: str
    algorithm: str
    public_jwk: str = ""
    active_from: str
    retired_at: str | None = None
    attestation_payload: str = ""
    attestation_signature: str = ""
    attestation_key_id: str = ""
    attestation_status: str = ""


class InclusionProof(BaseModel):
    event_uuid: str
    request_id: str
    event_hash: str
    leaf_hash: str
    leaf_index: int
    tree_size: int
    path: list[str] = Field(default_factory=list)
    checkpoint: LedgerCheckpoint


class ConsistencyProof(BaseModel):
    from_checkpoint: LedgerCheckpoint
    to_checkpoint: LedgerCheckpoint
    path: list[str] = Field(default_factory=list)


class LedgerProofBundle(BaseModel):
    event: LedgerEntry
    inclusion: InclusionProof
    consistency: ConsistencyProof | None = None
    keys: list[LedgerKeyVersion] = Field(default_factory=list)


class LedgerVerificationResult(BaseModel):
    """Result of independent offline ledger verification."""

    intact: bool
    verified_entries: int
    verified_checkpoints: int = 0
    verified_manifests: int
    latest_leaf_hash: str | None = None
    latest_checkpoint_hash: str | None = None
    latest_manifest_hash: str | None = None
    coverage_note: str | None = None
    error: str | None = None
