"""AWP UI API routes."""
