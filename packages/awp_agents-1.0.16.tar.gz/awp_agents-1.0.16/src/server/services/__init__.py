"""AWP UI service layer."""
