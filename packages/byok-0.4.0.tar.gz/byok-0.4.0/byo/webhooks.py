from __future__ import annotations

import hmac
import json
from hashlib import sha256
from typing import Any

from byo.errors import ValidationError

#: HTTP header BYO sends the HMAC-SHA256 signature in. Convenient for
#: framework-agnostic lookups, e.g. ``request.headers[BYO_SIGNATURE_HEADER]``.
BYO_SIGNATURE_HEADER = "X-BYO-Signature"


def _to_bytes(payload: str | bytes | bytearray | memoryview) -> bytes:
    if isinstance(payload, (bytes, bytearray, memoryview)):
        return bytes(payload)
    if isinstance(payload, str):
        return payload.encode("utf-8")
    raise ValidationError("payload must be str or bytes-like")


def verify_signature(
    payload: str | bytes | bytearray | memoryview,
    signature: str | None,
    secret: str,
) -> bool:
    """Constant-time check that ``signature`` matches an HMAC-SHA256
    computed over ``payload`` with ``secret``. Returns ``False`` (never
    raises) on any mismatch — the caller should answer with HTTP 400/401.

    ``payload`` MUST be the *raw* bytes/string of the request body. If you
    parse and re-serialize the JSON, key ordering or whitespace
    differences will cause a false negative.
    """
    if not signature or not secret:
        return False
    try:
        body = _to_bytes(payload)
    except ValidationError:
        return False
    expected = hmac.new(secret.encode("utf-8"), body, sha256).hexdigest()
    return hmac.compare_digest(expected, signature)


def construct_event(
    payload: str | bytes | bytearray | memoryview,
    signature: str | None,
    secret: str,
) -> dict[str, Any]:
    """Verify the signature *and* parse the JSON body in one call. Raises
    :class:`ValidationError` on signature mismatch or invalid JSON.

    .. code-block:: python

        @app.post("/webhooks/byo")
        async def webhook(request: Request):
            event = byok.webhooks.construct_event(
                await request.body(),
                request.headers.get("x-byo-signature"),
                os.environ["BYO_WEBHOOK_SECRET"],
            )
            ...
    """
    if not verify_signature(payload, signature, secret):
        raise ValidationError("Webhook signature verification failed", status_code=400)
    try:
        text = _to_bytes(payload).decode("utf-8")
        parsed = json.loads(text)
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise ValidationError(f"Webhook payload is not valid JSON: {e}", status_code=400)
    if not isinstance(parsed, dict) or not isinstance(parsed.get("event"), str):
        raise ValidationError("Webhook payload missing `event` field", status_code=400)
    return parsed


class WebhooksClient:
    """Webhook helpers exposed on :class:`BYOK` as ``byok.webhooks``."""

    def __init__(self) -> None:
        # No HTTP client needed — these are pure crypto helpers.
        pass

    @staticmethod
    def verify(
        payload: str | bytes | bytearray | memoryview,
        signature: str | None,
        secret: str,
    ) -> bool:
        return verify_signature(payload, signature, secret)

    @staticmethod
    def construct_event(
        payload: str | bytes | bytearray | memoryview,
        signature: str | None,
        secret: str,
    ) -> dict[str, Any]:
        return construct_event(payload, signature, secret)
