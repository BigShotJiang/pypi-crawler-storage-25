from __future__ import annotations

from typing import Any


class BYOKError(Exception):
    """Base exception. Every error raised by the BYO SDK derives from this."""

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        code: str | None = None,
        request_id: str | None = None,
    ):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.code = code
        self.request_id = request_id


class AuthenticationError(BYOKError):
    """401 — bad or missing ``byo_*`` API key."""

    def __init__(self, message: str = "Invalid or missing API key", request_id: str | None = None):
        super().__init__(message, status_code=401, code="AUTHENTICATION_ERROR", request_id=request_id)


class AuthorizationError(BYOKError):
    """403 — auth was OK but the action is not permitted (publishable-on-secret-only,
    origin not in ``allowedOrigins``, etc)."""

    def __init__(self, message: str = "Forbidden", request_id: str | None = None):
        super().__init__(message, status_code=403, code="AUTHORIZATION_ERROR", request_id=request_id)


class ValidationError(BYOKError):
    """400 / 422 — request shape or contents were rejected by BYO."""

    def __init__(
        self,
        message: str,
        status_code: int = 400,
        errors: Any = None,
        request_id: str | None = None,
    ):
        super().__init__(message, status_code=status_code, code="VALIDATION_ERROR", request_id=request_id)
        self.errors = errors


class NotFoundError(BYOKError):
    """404 — the project / log / key the request referenced doesn't exist."""

    def __init__(self, message: str = "Not found", request_id: str | None = None):
        super().__init__(message, status_code=404, code="NOT_FOUND", request_id=request_id)


class RateLimitError(BYOKError):
    """429 — rate limit hit. ``retry_after_ms`` is set when the server sent
    a ``Retry-After`` header so the caller can sleep before retrying."""

    def __init__(
        self,
        message: str = "Too many requests",
        retry_after_ms: int | None = None,
        request_id: str | None = None,
    ):
        super().__init__(message, status_code=429, code="RATE_LIMIT_EXCEEDED", request_id=request_id)
        self.retry_after_ms = retry_after_ms


class ProviderError(BYOKError):
    """The upstream provider (OpenAI, Anthropic, …) returned a non-2xx.
    The provider's status code is reflected in ``status_code``."""

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        provider: str | None = None,
        request_id: str | None = None,
    ):
        super().__init__(message, status_code=status_code, code="PROVIDER_ERROR", request_id=request_id)
        self.provider = provider


class ServerError(BYOKError):
    """5xx from the BYO API itself (not the upstream provider)."""

    def __init__(self, message: str = "BYO API error", status_code: int = 500, request_id: str | None = None):
        super().__init__(message, status_code=status_code, code="SERVER_ERROR", request_id=request_id)


class NetworkError(BYOKError):
    """No HTTP response was received (DNS, connection refused, etc.)."""

    def __init__(self, message: str = "Network error"):
        super().__init__(message, status_code=None, code="NETWORK_ERROR")


class TimeoutError(BYOKError):  # noqa: A001 — shadow stdlib intentionally for parity with TS SDK
    """The request ran past the configured timeout. The request *may*
    still have been processed by the server."""

    def __init__(self, message: str = "Request timed out"):
        super().__init__(message, status_code=None, code="TIMEOUT")


def error_from_response(
    status_code: int,
    body: Any,
    *,
    retry_after_seconds: float | None = None,
    request_id: str | None = None,
) -> BYOKError:
    """Map an HTTP status + parsed JSON body into the most specific
    :class:`BYOKError` subclass."""

    message: str
    if isinstance(body, dict):
        raw = body.get("message") or body.get("error")
        message = str(raw) if raw else f"Request failed ({status_code})"
    else:
        message = f"Request failed ({status_code})"

    if status_code == 401:
        return AuthenticationError(message, request_id=request_id)
    if status_code == 403:
        return AuthorizationError(message, request_id=request_id)
    if status_code == 404:
        return NotFoundError(message, request_id=request_id)
    if status_code == 422:
        errors = body.get("errors") if isinstance(body, dict) else None
        return ValidationError(message, status_code=422, errors=errors, request_id=request_id)
    if status_code == 429:
        retry_after_ms = (
            max(0, int(retry_after_seconds * 1000)) if retry_after_seconds is not None else None
        )
        return RateLimitError(message, retry_after_ms=retry_after_ms, request_id=request_id)
    if status_code >= 500:
        return ServerError(message, status_code=status_code, request_id=request_id)
    if status_code >= 400:
        errors = body.get("errors") if isinstance(body, dict) else None
        return ValidationError(message, status_code=status_code, errors=errors, request_id=request_id)
    return BYOKError(message, status_code=status_code, request_id=request_id)
