import json
import sys
from contextlib import redirect_stderr, redirect_stdout
from io import StringIO
from pathlib import Path

from harbor.cli.main import main


def run_cmd(argv):
    out = StringIO()
    err = StringIO()
    code = 0
    with redirect_stdout(out), redirect_stderr(err):
        sys.argv = ["harbor"] + argv
        try:
            main()
        except SystemExit as ex:
            code = ex.code if isinstance(ex.code, int) else 1
    return code, out.getvalue(), err.getvalue()


def test_next_reads_checkpoint_report_and_groups_output(tmp_path: Path):
    report = {
        "command": "checkpoint",
        "ci_failures": [
            {
                "category": "possible_semantic_drift",
                "func_id": "harbor.core.foo.bar",
                "file_path": "harbor/core/foo.py",
            }
        ],
        "advisory": [
            {
                "category": "ddt_version_baseline_missing",
                "func_id": "harbor.core.foo.bar",
                "file_path": "tests/test_foo.py",
            }
        ],
    }
    report_path = tmp_path / "checkpoint.json"
    report_path.write_text(json.dumps(report), encoding="utf-8")
    code, out, _ = run_cmd(["next", "--from", str(report_path)])
    assert code == 0
    assert "Blocking failures:" in out
    assert "Advisory:" in out
    assert "possible_semantic_drift" in out
    assert "ddt_version_baseline_missing" in out


def test_next_json_output_contract(tmp_path: Path):
    report = {"command": "checkpoint", "ci_failures": [], "advisory": []}
    report_path = tmp_path / "checkpoint.json"
    report_path.write_text(json.dumps(report), encoding="utf-8")
    code, out, _ = run_cmd(["next", "--from", str(report_path), "--format", "json"])
    payload = json.loads(out)
    assert code == 0
    assert payload["command"] == "next"
    assert payload["source_command"] == "checkpoint"
    assert payload["llm_used"] is False
    assert payload["writes_files"] is False


def test_next_json_items_include_blocking_and_status_is_ok_even_for_fail_report(tmp_path: Path):
    report = {
        "command": "checkpoint",
        "status": "fail",
        "ci_failures": [{"category": "contract_gap"}],
        "advisory": [{"category": "ddt_version_baseline_missing"}],
    }
    report_path = tmp_path / "checkpoint.json"
    report_path.write_text(json.dumps(report), encoding="utf-8")
    code, out, _ = run_cmd(["next", "--from", str(report_path), "--format", "json"])
    payload = json.loads(out)
    assert code == 0
    assert payload["status"] == "ok"
    assert payload["items"][0]["blocking"] is True
    assert payload["items"][1]["blocking"] is False


def test_next_unknown_category_graceful_degrade(tmp_path: Path):
    report = {
        "command": "checkpoint",
        "ci_failures": [{"category": "unknown_category"}],
        "advisory": [],
    }
    report_path = tmp_path / "checkpoint.json"
    report_path.write_text(json.dumps(report), encoding="utf-8")
    code, out, _ = run_cmd(["next", "--from", str(report_path), "--format", "json"])
    payload = json.loads(out)
    assert code == 0
    assert payload["items"]
    guidance = payload["items"][0]["guidance"]
    assert guidance["decision_required"] is True
    assert guidance["safe_to_auto_fix"] is False
    assert guidance["automation_policy"] == "plan_only"


def test_next_can_read_utf16_report(tmp_path: Path):
    report = {"command": "checkpoint", "ci_failures": [], "advisory": []}
    report_path = tmp_path / "checkpoint-utf16.json"
    report_path.write_text(json.dumps(report), encoding="utf-16")
    code, out, _ = run_cmd(["next", "--from", str(report_path), "--format", "json"])
    payload = json.loads(out)
    assert code == 0
    assert payload["command"] == "next"


def test_next_json_preserves_typescript_additive_checkpoint_metadata(tmp_path: Path):
    report = {
        "command": "checkpoint",
        "ci_failures": [],
        "advisory": [
            {
                "category": "skipped_no_contract",
                "func_id": "typescript:src/models.ts:interface:User",
                "file_path": "src/models.ts",
                "reason": "TypeScript exported data contract target is tracked in advisory-first mode; blocking semantic comparison is skipped.",
                "target_id": "typescript:src/models.ts:interface:User",
                "language": "typescript",
                "symbol_kind": "interface",
                "adapter": "typescript",
                "data_contract_kind": "interface",
                "contract_source_kinds": ["typescript_interface"],
                "contract_source_fingerprints": ["abc123"],
                "source_confidence_summary": "high",
                "public_boundary_state": "direct_export_only",
                "public_boundary_confidence": "low",
                "public_boundary_evidence_kinds": ["direct_export"],
                "public_boundary_evidence_items": [
                    {
                        "kind": "direct_export",
                        "confidence": "low",
                        "source_file": "src/models.ts",
                        "source_ref": "User",
                        "resolved_target": "typescript:src/models.ts:interface:User",
                        "reason": "Target is exported directly from its declaring source file.",
                    }
                ],
                "public_boundary_reason": "Target is exported directly from its declaring source file.",
                "boundary_preset_mode": "legacy_exported",
            }
        ],
    }
    report_path = tmp_path / "checkpoint-ts.json"
    report_path.write_text(json.dumps(report), encoding="utf-8")
    code, out, _ = run_cmd(["next", "--from", str(report_path), "--format", "json"])
    payload = json.loads(out)

    assert code == 0
    row = payload["items"][0]
    assert row["blocking"] is False
    assert row["reason"] == report["advisory"][0]["reason"]
    assert row["target_id"] == "typescript:src/models.ts:interface:User"
    assert row["language"] == "typescript"
    assert row["symbol_kind"] == "interface"
    assert row["adapter"] == "typescript"
    assert row["data_contract_kind"] == "interface"
    assert row["contract_source_kinds"] == ["typescript_interface"]
    assert row["contract_source_fingerprints"] == ["abc123"]
    assert row["source_confidence_summary"] == "high"
    assert row["public_boundary_state"] == "direct_export_only"
    assert row["public_boundary_confidence"] == "low"
    assert row["public_boundary_evidence_kinds"] == ["direct_export"]
    assert row["public_boundary_evidence_items"][0]["kind"] == "direct_export"
    assert row["public_boundary_reason"] == "Target is exported directly from its declaring source file."
    assert row["boundary_preset_mode"] == "legacy_exported"


def test_next_can_consume_verify_generated_ci_json(tmp_path: Path):
    report = {
        "command": "verify-generated",
        "ci": True,
        "status": "fail",
        "exit_code": 1,
        "writes_files": False,
        "summary": {"scope": "module:harbor/core", "modules_checked": 1, "ci_failures": 1, "advisory_items": 0},
        "ci_failures": [
            {
                "kind": "view",
                "module": "harbor/core",
                "view": "canonical_l2_readme",
                "status": "fail",
                "reason": "l2_body_mismatch",
                "suggested_command": "harbor docs --module harbor/core --write",
            }
        ],
        "advisory": [],
        "next_steps": ["harbor docs --module harbor/core --write"],
    }
    report_path = tmp_path / "verify-generated.json"
    report_path.write_text(json.dumps(report), encoding="utf-8")
    code, out, _ = run_cmd(["next", "--from", str(report_path), "--format", "json"])
    payload = json.loads(out)

    assert code == 0
    assert payload["source_command"] == "verify-generated"
    assert payload["status"] == "ok"
    assert payload["items"][0]["blocking"] is True
    assert payload["items"][0]["category"] == "view"
    assert payload["items"][0]["reason"] == "l2_body_mismatch"
