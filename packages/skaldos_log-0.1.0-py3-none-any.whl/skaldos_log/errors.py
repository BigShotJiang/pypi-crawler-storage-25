"""Errors and sentinels for the SkaldOS log chokepoint.

Two failure modes get their own surface here:

* :class:`LogWithoutSpanError` — raised in non-prod environments when a log is
  emitted outside an active OTel span. §20.4 declares "a log line without
  ``trace_id`` is a bug"; this turns it into an exception so it shows up as a
  test failure rather than a silent missing-correlation regression.
* :data:`HELPER_INTERNAL_ERROR_EVENT` and :data:`LOG_WITHOUT_SPAN_EVENT` —
  sentinel event names emitted on the prod path. Per E1 + E21 the helper must
  *never* propagate its own errors into business logic; instead it emits a
  structured sentinel record and increments a metric (the metric increment
  ships in T3 alongside the OTel SDK wiring).

References: §20.4, §20.7, E1, E21, E22.
"""

from __future__ import annotations

from typing import Final

# Sentinel event names. Stable strings that operators can alert on.
LOG_WITHOUT_SPAN_EVENT: Final[str] = "log.without_span"
HELPER_INTERNAL_ERROR_EVENT: Final[str] = "log.internal_error"

# Sentinel value used in place of the missing trace_id on the prod no-span
# path (§20.4: "a log without trace_id is a bug" — surfaced as a literal value
# operators can filter on, not silently dropped).
TRACE_ID_MISSING: Final[str] = "missing"


class LogWithoutSpanError(RuntimeError):
    """Raised in dev/test when ``log.{tier}`` is called outside an active span.

    Per §20.4 every log line must be correlated to a trace. The chokepoint
    fails fast in non-prod so the missing-span call site is fixed at PR time;
    in prod the same condition emits a sentinel record (see
    :data:`LOG_WITHOUT_SPAN_EVENT`) and increments a counter — the request
    handler is *never* crashed by a logging miss (E1).

    Attributes:
        event_name: The original event the caller tried to log.
        call_site: Best-effort ``"file:line"`` string for the offending call.
    """

    def __init__(self, event_name: str, call_site: str | None = None) -> None:
        self.event_name = event_name
        self.call_site = call_site
        message = (
            f"log.{event_name!r} called outside an active OTel span; "
            f"every log line must be inside `tracer.start_as_current_span(...)` "
            f"(§20.4). Wrap the call site in a span, or — for workers / cron / "
            f"outbox dispatchers — wrap the unit of work per the runbook (E2)."
        )
        if call_site:
            message += f" Call site: {call_site}."
        super().__init__(message)


class HelperInternalError(RuntimeError):
    """Wraps an exception raised inside the helper itself.

    The chokepoint catches helper-internal failures (E21) and emits a sentinel
    so business logic continues. Tests assert this invariant. Operators see
    the sentinel + a metric increment; they do not see a 500 on a request
    whose only sin was reaching for ``log.info``.

    Carve-outs that propagate rather than wrap (see
    :func:`skaldos_log.processors.shield_internal_failures`):
    :class:`KeyboardInterrupt` and :class:`SystemExit` (Python convention —
    interactive interrupts and ``sys.exit`` are not muffled by a generic
    "shield from any exception" wrapper) and :class:`LogWithoutSpanError`
    (the §20.4 fail-fast contract).
    """

    def __init__(self, original: BaseException) -> None:
        self.original = original
        super().__init__(f"helper-internal failure: {type(original).__name__}: {original}")
