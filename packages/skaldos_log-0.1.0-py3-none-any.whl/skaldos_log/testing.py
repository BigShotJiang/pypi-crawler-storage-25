"""Test fixtures for the SkaldOS log chokepoint (Python).

Per ``04-testing-strategy.md`` § Cross-feature test ownership and ``05-task-list.md``
T6: this module ships a single canonical pytest fixture, ``captured_logs``,
that other features (``integration-test-framework`` first, then per-service
suites in later slices) consume to assert log shape.

Design contract:

* The fixture **does not bypass the chokepoint**. It swaps only the *final*
  renderer — ``JSONRenderer`` — for an in-memory :class:`structlog.testing.LogCapture`.
  Every preceding processor still runs: OTel context attachment, principal
  context attachment, active-span enforcement, the §20.2 redaction layer, and
  the helper-internal-failure shield. The records assertion-tested by the
  fixture are therefore **what production sees** (E5–E10 redaction, E1
  fail-fast, E21 internal-failure shield).
* Records are plain ``dict``s — the same shape ``structlog.testing.LogCapture``
  yields on its ``.entries`` list. The fixture wraps them in a
  :class:`CapturedLogs` adapter that supports both ``len(captured_logs)`` and
  ``captured_logs[i]`` for ergonomic test code, plus ``.clear()`` for tests
  that emit before-and-after batches inside a single test body.
* The fixture installs and tears down per-test — no order-dependence (§19.1).

Usage::

    from skaldos_log.testing import captured_logs  # noqa: F401 — fixture

    def test_my_feature(captured_logs):
        with tracer.start_as_current_span("op"):
            log.info("loaded_node", node_id=node_id)
        assert len(captured_logs) == 1
        assert captured_logs[0]["event"] == "loaded_node"

The fixture is exposed as a top-level pytest plugin entry through
``conftest.py`` files at the consumption site (typical pattern: a test
module or its conftest writes ``from skaldos_log.testing import captured_logs``,
which is enough for pytest's fixture discovery to pick it up).

References: §19.1, §19.2, E1, E5–E10, E17, E21.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import Any

import pytest
import structlog

from . import _PROCESSOR_CHAIN  # type: ignore[attr-defined]

__all__ = ["CapturedLogs", "captured_logs"]


class CapturedLogs:
    """Adapter around :class:`structlog.testing.LogCapture`'s ``.entries`` list.

    Each captured record is a plain ``dict`` carrying every key the chokepoint
    chain produced — ``event``, ``level``, plus ``trace_id`` / ``span_id`` /
    redacted-or-preserved kwargs etc. The adapter exposes the underlying list
    via :attr:`records` (for explicit list access) and forwards ``len`` / item
    access / iteration directly so test code can write ``captured_logs[0]``
    and ``len(captured_logs)`` without an extra hop.

    The adapter mutates in place — calling :meth:`clear` empties both
    ``.records`` and any subsequent indexing. New emissions append to the
    same underlying list.

    The class deliberately does **not** flatten ``record.field`` to
    attribute access. The records are dicts and stay dicts — the brainstorm's
    "``.records[i].field`` access" sketch is satisfied by ``.records[i]['field']``
    in the standard dict idiom; introducing attribute-style access would
    diverge from the structlog ecosystem and obscure the fact that
    ``event_type`` (for example) is a key, not a property.
    """

    __slots__ = ("_entries",)

    def __init__(self, entries: list[dict[str, Any]]) -> None:
        self._entries = entries

    @property
    def records(self) -> list[dict[str, Any]]:
        """The underlying list of captured records (mutable; mutating it mutates state)."""
        return self._entries

    def clear(self) -> None:
        """Drop every captured record so far.

        Useful inside a single test that emits two batches with an
        intervening assertion — clear between batches to keep the second
        batch's indices starting at zero.
        """
        self._entries.clear()

    # --- list-like delegation so test bodies can use the adapter directly. ---

    def __len__(self) -> int:
        return len(self._entries)

    def __getitem__(self, index: int) -> dict[str, Any]:
        return self._entries[index]

    def __iter__(self) -> Iterator[dict[str, Any]]:
        return iter(self._entries)

    def __bool__(self) -> bool:
        return bool(self._entries)

    def __eq__(self, other: object) -> bool:
        # Equality with a list-of-dicts so legacy tests that previously
        # asserted ``captured_logs == []`` still pass against the adapter.
        if isinstance(other, list):
            return self._entries == other
        if isinstance(other, CapturedLogs):
            return self._entries == other._entries
        return NotImplemented

    def __repr__(self) -> str:
        return f"CapturedLogs({self._entries!r})"


def _chain_minus_renderer() -> list[Any]:
    """Return the package's processor chain with the final renderer dropped.

    The package's ``_PROCESSOR_CHAIN`` ends with
    ``structlog.processors.JSONRenderer()``; dropping it lets the
    :class:`structlog.testing.LogCapture` (which is itself a renderer-shaped
    processor) consume the event dict instead of stdout JSON.
    """
    return list(_PROCESSOR_CHAIN[:-1])


@pytest.fixture
def captured_logs() -> Iterator[CapturedLogs]:
    """Capture every emission through the chokepoint for the duration of a test.

    Installs a :class:`structlog.testing.LogCapture` as the final processor in
    place of the package's default ``JSONRenderer``; all preceding processors
    (OTel context attachment, principal context attachment, active-span
    enforcement, redaction, internal-failure shield) keep running. The
    fixture yields a :class:`CapturedLogs` adapter wrapping the capture's
    underlying list — see the class docstring for the supported access
    patterns.

    Setup is one structlog reconfiguration; teardown restores the package's
    default chain (re-imported from ``skaldos_log._PROCESSOR_CHAIN`` so we do
    not snapshot the chain at module-import time and risk drift if a future
    test fixture has its own monkey-patches in flight). Per-test installation
    means no order-dependence (§19.1).

    Records-as-list contract: ``len(captured_logs) == N``, ``captured_logs[i]``
    returns the ``i``\\ th record as a dict; ``captured_logs.records`` exposes
    the same list. ``captured_logs.clear()`` empties it.

    The fixture intentionally does **not** mock the chokepoint. Tests using
    this fixture observe what production observes — including redaction
    sentinels (``<REDACTED:str>`` etc.), the no-span sentinel (when
    ``SKALDOS_ENV`` is non-prod, the test will see a :class:`LogWithoutSpanError`
    raise instead of a captured record), and the helper-internal-error
    sentinel (when a processor bug surfaces).
    """
    cap = structlog.testing.LogCapture()
    structlog.configure(
        processors=[*_chain_minus_renderer(), cap],
        cache_logger_on_first_use=False,
    )
    try:
        yield CapturedLogs(cap.entries)
    finally:
        # Restore the package's configured chain. Re-reading
        # ``_PROCESSOR_CHAIN`` from the package handles the (rare) case
        # where another fixture has rewritten it during the test.
        from . import _PROCESSOR_CHAIN as restored_chain  # type: ignore[attr-defined]

        structlog.configure(processors=restored_chain, cache_logger_on_first_use=False)
