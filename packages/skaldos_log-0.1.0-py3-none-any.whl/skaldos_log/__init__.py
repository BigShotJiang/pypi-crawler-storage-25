"""SkaldOS log chokepoint — public API for Python.

The intended call shape is::

    from skaldos_log import log

    log.info("loaded_node", node_id=node_id, lens="default")

T1 shipped the **redaction layer** (:mod:`.redaction`), the
**LogWithoutSpanError** + sentinel events (:mod:`.errors`), and the
**structlog processors** that compose them (:mod:`.processors`). T3 (this
module body) configures structlog with the full processor chain, exposes
the ``log`` BoundLogger + the ``bind`` context manager, and wires the
``attach_otel_context`` / ``attach_principal_context`` reads. T5 adds the
**auto-instrumentation registration** entry point (:mod:`.instrumentation`)
that hooks FastAPI / ``httpx`` / ``asyncpg`` so the chokepoint actually sees
spans on inbound requests, outbound HTTP calls, and DB queries — without
that step the §20.4 fail-fast contract pages on every request handler.
T7 wires the JSON-vs-pretty renderer dispatch — :func:`json_renderer`
delegates to :class:`structlog.dev.ConsoleRenderer` (pretty, colorized) on
a local laptop with no collector and to :class:`structlog.processors.JSONRenderer`
in CI / staging / prod / any captured-stream context. The toggle reads
``SKALDOS_LOG_FORMAT`` (explicit ``json`` / ``pretty`` override) or
auto-detects against ``OTEL_EXPORTER_OTLP_ENDPOINT`` + ``CI`` + stdout-TTY.
Coordinates with `dev-environment/T6`'s ``SKALDOS_OTEL_LOCAL`` opt-in:
when the local OTel collector is on, ``OTEL_EXPORTER_OTLP_ENDPOINT`` is
set, so even on a TTY auto-mode falls back to JSON for the collector
to parse.

The processor chain order:

    1. attach_otel_context           reads `trace_id` / `span_id` from active span
    2. attach_principal_context      drains contextvars into the event
    3. enforce_active_span           raises in dev/test, sentinel in prod (E1)
    4. redact_pii                    safelist + value-shape checks (§20.2)
    5. emit_shape_mismatch_warning   one-shot `warnings.warn` per process (E6)
    6. strip_internal_keys           drops the `_skaldos_log_*` namespace
    7. add_log_level                 structlog standard `level` field
    8. json_renderer                 dispatches to JSON (prod/CI) or pretty (dev/TTY)

Each step is wrapped in :func:`shield_internal_failures` so a bug in any
stage degrades to an ``log.internal_error`` sentinel rather than a 500
in business logic (E21).

Importing this module **must not** pull in any other ``skaldos_*`` package
(E22; verified by ``test_log_package_dependencies.py``). The only allowed
runtime dependencies are ``structlog`` and ``opentelemetry-api`` per the
package ``pyproject.toml``.

References: §20.1, §20.2, §20.4, §13.1, §9.2, ADR 10, MP5, MP6, MP10.
"""

from __future__ import annotations

from collections.abc import Generator
from contextlib import contextmanager
from typing import Any, cast

import structlog

from .context import (
    PrincipalContext,
    _reset_principal_context,
    _set_principal_context,
    current_context,
)
from .errors import (
    HELPER_INTERNAL_ERROR_EVENT,
    LOG_WITHOUT_SPAN_EVENT,
    TRACE_ID_MISSING,
    HelperInternalError,
    LogWithoutSpanError,
)
from .instrumentation import (
    INSTRUMENTOR_SPECS,
    InstrumentorSpec,
    RegistrationResult,
    is_instrumentation_registered,
    register_auto_instrumentation,
    registered_instrumentations,
    unregister_auto_instrumentation,
)
from .processors import (
    LOG_FORMAT_ENV_VAR,
    LOG_FORMAT_JSON,
    LOG_FORMAT_PRETTY,
    LOG_WITHOUT_SPAN_COUNTER_NAME,
    SHAPE_MISMATCH_KEY,
    LogShapeMismatchWarning,
    attach_otel_context,
    attach_principal_context,
    emit_shape_mismatch_warning,
    enforce_active_span,
    json_renderer,
    redact_pii,
    resolve_log_format,
    shield_internal_failures,
)
from .redaction import (
    REDACTED_OBJECT,
    REDACTED_SHAPE_MISMATCH,
    SAFELISTED_FIELDS,
    VALUE_SHAPE_CHECKS,
    redact_event_dict,
    redact_field,
)

__all__ = [
    # Public API.
    "log",
    "bind",
    # Helper data the application layer reads.
    "PrincipalContext",
    "current_context",
    "SAFELISTED_FIELDS",
    "VALUE_SHAPE_CHECKS",
    "REDACTED_OBJECT",
    "REDACTED_SHAPE_MISMATCH",
    # Errors and sentinels.
    "LogWithoutSpanError",
    "HelperInternalError",
    "LOG_WITHOUT_SPAN_EVENT",
    "HELPER_INTERNAL_ERROR_EVENT",
    "LOG_WITHOUT_SPAN_COUNTER_NAME",
    "TRACE_ID_MISSING",
    "LogShapeMismatchWarning",
    "SHAPE_MISMATCH_KEY",
    # Redaction primitives (consumed by tests + the structlog chain).
    "redact_field",
    "redact_event_dict",
    # Processors (exposed for tests + advanced consumers).
    "attach_otel_context",
    "attach_principal_context",
    "redact_pii",
    "emit_shape_mismatch_warning",
    "enforce_active_span",
    "shield_internal_failures",
    "json_renderer",
    "resolve_log_format",
    "LOG_FORMAT_ENV_VAR",
    "LOG_FORMAT_JSON",
    "LOG_FORMAT_PRETTY",
    # T5 — auto-instrumentation registration (FastAPI / httpx / asyncpg).
    "INSTRUMENTOR_SPECS",
    "InstrumentorSpec",
    "RegistrationResult",
    "is_instrumentation_registered",
    "register_auto_instrumentation",
    "registered_instrumentations",
    "unregister_auto_instrumentation",
]


# ---------------------------------------------------------------------------
# Internal-key strip processor.
#
# `redact_pii` may stash a `_skaldos_log_shape_mismatches` list in the event
# dict for downstream consumption (E6 surface — `emit_shape_mismatch_warning`
# reads it). The renderer must not emit that key — it's helper-internal
# scratch space. T6 wires the warn-emission processor between `redact_pii`
# and the strip; the strip remains the last step before `add_log_level` so
# no `_skaldos_log_*` key ever reaches the renderer.
# ---------------------------------------------------------------------------

_INTERNAL_KEY_PREFIX = "_skaldos_log_"


def _strip_internal_keys(
    _logger: Any, _method_name: str, event_dict: dict[str, Any]
) -> dict[str, Any]:
    """Drop helper-internal scratch keys before rendering."""
    return {k: v for k, v in event_dict.items() if not k.startswith(_INTERNAL_KEY_PREFIX)}


# ---------------------------------------------------------------------------
# structlog configuration.
#
# Each processor is wrapped in `shield_internal_failures` individually so a
# bug in any stage produces the `log.internal_error` sentinel without
# propagating. The shield re-raises `LogWithoutSpanError` so the §20.4
# fail-fast contract holds in dev/test; `KeyboardInterrupt` / `SystemExit`
# also propagate (Python convention; PR #5 review fix).
#
# The chain ends in :func:`json_renderer`, which dispatches at emission
# time to :class:`structlog.processors.JSONRenderer` (prod / CI / collector
# present) or :class:`structlog.dev.ConsoleRenderer` (local laptop, no
# collector, TTY stdout) per :func:`resolve_log_format`. Wrapping the
# renderer in `json_renderer` rather than instantiating one of the two
# classes here keeps the chain shape declarative and lets a test flip
# `SKALDOS_LOG_FORMAT` mid-suite via :func:`_reset_renderer_for_tests`.
# ---------------------------------------------------------------------------

_PROCESSOR_CHAIN: list[Any] = [
    shield_internal_failures(attach_otel_context),
    shield_internal_failures(attach_principal_context),
    shield_internal_failures(enforce_active_span),
    shield_internal_failures(redact_pii),
    # E6: emit a one-shot `LogShapeMismatchWarning` if redact_pii flagged any
    # shape mismatches. Must run *after* redact_pii (which sets the scratch
    # key) and *before* `_strip_internal_keys` (which clears it).
    shield_internal_failures(emit_shape_mismatch_warning),
    shield_internal_failures(_strip_internal_keys),
    structlog.processors.add_log_level,
    json_renderer,
]


structlog.configure(
    processors=_PROCESSOR_CHAIN,
    # `BoundLogger` is the standard structlog logger surface; tests don't
    # care about the wrapper class beyond `info` / `warn` / `error` / `debug`
    # method names. We keep structlog's default cache_logger_on_first_use
    # off so the test suite can swap configuration between tests without
    # the loggers caching the old chain.
    cache_logger_on_first_use=False,
)


# `log` is the canonical chokepoint logger. Importing this module configures
# structlog as a side effect — by design (the package is the chokepoint;
# importing it is the act of opting into the chokepoint).
log = structlog.get_logger("skaldos")


@contextmanager
def bind(**fields: Any) -> Generator[None, None, None]:
    """Bind principal-context fields for the surrounding ``with`` block.

    Writes the merged context to the package's ``_PRINCIPAL_CONTEXT``
    contextvar; the :func:`attach_principal_context` processor reads from
    the same contextvar so subsequent ``log.{tier}`` calls inside the
    block surface those fields automatically. On exit, the prior context
    is restored — nested binds extend, exits unwind one frame at a time
    (E19 — no leak across async boundaries or across sibling tasks on the
    same event loop, since contextvars are per-task).

    Typical use::

        with bind(principal_id="...", tenant_id="..."):
            log.info("loaded_node", node_id="...")

    Both kwargs are added to every emission inside the ``with`` block.
    Explicit kwargs on the ``log`` call always win over a bound value
    (the brainstorm's ``test_explicit_kwarg_overrides_context``).

    The merge is shallow and additive — calling ``bind(tenant_id=X)``
    inside an already-bound ``bind(principal_id=Y)`` extends to
    ``{principal_id: Y, tenant_id: X}``. Re-binding the same key inside a
    nested scope overrides the outer for the inner block only.

    Only fields recognised by :class:`PrincipalContext` (the safelisted
    identity keys) flow through to the event dict — non-safelisted entries
    are accepted at the bind boundary (Python doesn't enforce the
    `TypedDict` shape at runtime) but :func:`attach_principal_context`
    drops them before emission. The runbook (T8) documents
    "stick to safelisted keys" as the canonical pattern.
    """
    # Treat the merged map as a plain dict for `update` — `PrincipalContext`
    # is a `total=False` TypedDict, so non-PrincipalContext keys (a
    # caller passing `node_id=...` to `bind`, say) are accepted at runtime
    # and the `attach_principal_context` processor drops anything not on
    # the safelist before emission. The cast is a typing-only convenience.
    merged_raw: dict[str, Any] = dict(current_context())
    merged_raw.update(fields)
    merged = cast("PrincipalContext", merged_raw)
    token = _set_principal_context(merged)
    try:
        yield
    finally:
        _reset_principal_context(token)
