"""Contextvars-backed principal / tenant / agent-run binding.

§20.1 says the helper "auto-attaches ``trace_id``, ``span_id``,
``principal_id``, ``tenant_id``, ``agent_run_id`` from OTel context." Trace
context comes from the OTel SDK (read in :mod:`processors`); the principal /
tenant / agent identifiers come from a small ``contextvars`` map that the
application's request middleware (or a worker's per-job wrapper) binds at
the boundary.

T1 ships the storage shape and a read accessor. The actual ``log.bind``
context manager that mutates the map lives in T3 alongside the structlog
processor wiring (it composes with :func:`structlog.contextvars.bound_contextvars`
so binds scope to a ``with`` block — E19). T1's redaction tests construct
the contextvar dict directly to exercise the read path without depending on
the not-yet-shipped binder.

References: §20.1, §20.4, §13.1, E18, E19, E22.
"""

from __future__ import annotations

from contextvars import ContextVar
from typing import Final, TypedDict

__all__ = [
    "PrincipalContext",
    "current_context",
    # Module-private writers — exposed in __all__ so pyright recognizes them
    # as the package's intended T3 entry points (used by the future `bind`
    # context manager). They are leading-underscore-prefixed by convention
    # (not for module-private semantics — the leading underscore is the
    # signal to application code that this is helper-internal plumbing).
    "_set_principal_context",
    "_reset_principal_context",
]


class PrincipalContext(TypedDict, total=False):
    """Shape of the per-task principal context dict.

    Every key is optional — at the very edges of the system (cron entry,
    bootstrap code) some of these are not yet known. Trace correlation
    (``trace_id`` / ``span_id``) is *not* in this dict; it comes from the
    active OTel span (§20.4) and is read by a different processor.
    """

    principal_id: str
    tenant_id: str
    agent_id: str
    agent_run_id: str
    membership_id: str


# Module-level ContextVar. Per §20.1 + E18, request isolation rides on
# Python's contextvars (each asyncio task / each thread has its own copy);
# the helper never touches a module-level mutable.
#
# The default is ``None`` rather than ``PrincipalContext()`` because a
# mutable default sharing instance identity across tasks is a foot-gun
# (ruff B039 catches it); the read accessor materializes an empty dict on
# the fly when nothing has been bound.
_PRINCIPAL_CONTEXT: Final[ContextVar[PrincipalContext | None]] = ContextVar(
    "skaldos_log.principal_context",
    default=None,
)


def current_context() -> PrincipalContext:
    """Return a snapshot of the current task's principal context.

    Returns a shallow copy so callers cannot mutate the bound state by
    accident. The empty dict is the documented "nothing bound yet" state —
    e.g. inside a top-level CLI entry before middleware has run, or inside
    a unit test that did not bind anything.
    """
    bound = _PRINCIPAL_CONTEXT.get()
    if bound is None:
        return PrincipalContext()
    return PrincipalContext(**bound)


# Module-private accessor for processors / the (T3) bind helper. Public API
# stays read-only; the writer is the bind context manager that arrives in T3.
def _set_principal_context(ctx: PrincipalContext) -> object:
    """Replace the principal context for the current task.

    Returns an opaque token that callers must pass back to
    :func:`_reset_principal_context` to restore the prior value. This is the
    primitive the T3 ``bind`` context manager will wrap; it is not part of
    the public package API.
    """
    return _PRINCIPAL_CONTEXT.set(ctx)


def _reset_principal_context(token: object) -> None:
    """Restore a prior principal-context snapshot.

    Counterpart to :func:`_set_principal_context`. Like the setter, this is
    an internal primitive — application code should reach for the public
    ``bind`` context manager (T3) instead.
    """
    # ContextVar.set returns a Token; we accept `object` in the signature so
    # the (T3-defined) public bind helper can hide the type.
    _PRINCIPAL_CONTEXT.reset(token)  # type: ignore[arg-type]
