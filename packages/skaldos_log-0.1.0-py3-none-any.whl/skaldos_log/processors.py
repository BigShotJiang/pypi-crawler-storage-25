"""structlog processors composing the chokepoint pipeline.

The processor chain is the heart of §20.1's "every log line is structured by
construction" — each processor is a pure function ``(logger, method_name,
event_dict) -> event_dict``. T1 ships:

* :func:`redact_pii` — runs every kwarg through :mod:`redaction` and emits a
  one-shot ``warn`` record when a safelisted field carries a malformed value
  (E6). This is the load-bearing PII discipline.
* :func:`enforce_active_span` — fails fast in dev/test if a log was emitted
  outside an OTel span (§20.4 / E1); on the prod path the same processor
  rewrites the event into a ``log.without_span`` sentinel so business logic
  is never crashed by a logging miss. Metric increment lives in T3 once the
  OTel SDK + meter provider are wired.
* :func:`shield_internal_failures` — wraps the chain so a bug in any
  processor surfaces as a ``log.internal_error`` sentinel rather than an
  exception in caller code (E21).

Two processors are stubbed for T3 to body-fill (sanctioned scaffold-now-wire-
later per CLAUDE.md):

* :func:`attach_otel_context` — reads ``trace_id`` / ``span_id`` from the
  active span. T1 raises :class:`NotImplementedError("wired in Slice 0 / T3")`
  so a misordered task can't accidentally consume the un-wired version.
* :func:`attach_principal_context` — drains the contextvar dict from
  :mod:`context` into the event. T3 also wires the ``bind`` context manager
  that mutates that dict.

References: §20.1, §20.2, §20.4, §13.1, E1, E6, E21, E22.
"""

from __future__ import annotations

import contextlib
import os
import sys
import threading
import traceback
import warnings
from collections.abc import Callable
from typing import Any, Final

import structlog
from opentelemetry import metrics, trace

from .context import current_context
from .errors import (
    HELPER_INTERNAL_ERROR_EVENT,
    LOG_WITHOUT_SPAN_EVENT,
    TRACE_ID_MISSING,
    HelperInternalError,
    LogWithoutSpanError,
)
from .redaction import SAFELISTED_FIELDS, redact_event_dict

# Type alias for a structlog processor callable. structlog itself does not
# ship a stable typing alias, so we keep the shape local.
Processor = Callable[[Any, str, dict[str, Any]], dict[str, Any]]


# ---------------------------------------------------------------------------
# Environment detection.
#
# §20.4 distinguishes "dev/test" (raise) from "prod" (sentinel). We read
# `SKALDOS_ENV` rather than tying ourselves to FastAPI / DBOS-specific env
# conventions. The default is "dev" so a fresh checkout fails loud — which
# is precisely the §20.4 contract.
# ---------------------------------------------------------------------------

_ENV_VAR: Final[str] = "SKALDOS_ENV"
_PROD_VALUES: Final[frozenset[str]] = frozenset({"prod", "production"})


def _is_prod() -> bool:
    """Return True iff the current environment is production.

    The SRE-shaped contract: any unrecognized value (including the empty
    string and unset) is *not* prod. This biases toward the loud-failure
    path; misconfiguration in staging falls into dev semantics, not prod.
    """
    return os.environ.get(_ENV_VAR, "").strip().lower() in _PROD_VALUES


# ---------------------------------------------------------------------------
# Redaction processor (the §20.2 chokepoint).
# ---------------------------------------------------------------------------


_HELPER_SENTINEL_EVENTS: Final[frozenset[str]] = frozenset(
    {LOG_WITHOUT_SPAN_EVENT, HELPER_INTERNAL_ERROR_EVENT}
)


def redact_pii(_logger: Any, _method_name: str, event_dict: dict[str, Any]) -> dict[str, Any]:
    """Apply the safelist + value-shape checks to every kwarg.

    Pure function over the event dict. Shape mismatches are surfaced via the
    ``_skaldos_log_shape_mismatches`` key — a downstream processor (wired in
    T3) reads it to emit the one-shot ``warn`` per E6. Storing the list on
    the dict (rather than mutating module state) keeps this processor pure
    and re-entrant under concurrency.

    The ``_skaldos_log_*`` namespace is reserved for inter-processor
    communication; the JSON renderer at the end of the chain strips it.

    Helper-emitted sentinel records (``log.without_span`` / ``log.internal_error``)
    bypass redaction entirely. Their fields (``trace_id="missing"``,
    ``original_event``, ``call_site``, ``exc_type``, ``exc_message``) are
    constructed by the helper itself — they're operator-facing observability
    output, not caller-supplied payload, and running them through the
    safelist would mangle the operationally-important values (``"missing"``
    fails the hex-32 shape check; ``original_event`` is off-safelist by
    design). Sentinels short-circuit by name match.
    """
    if event_dict.get("event") in _HELPER_SENTINEL_EVENTS:
        return event_dict

    redacted, mismatches = redact_event_dict(event_dict)
    if mismatches:
        redacted["_skaldos_log_shape_mismatches"] = mismatches
    return redacted


# ---------------------------------------------------------------------------
# E6 one-shot shape-mismatch warning.
#
# §20.2 + E6: when a safelisted field carries a malformed value the redaction
# layer replaces the value with `<REDACTED:shape-mismatch>`. The brainstorm
# also commits to a "one-shot warn-tier emission flagging the call site" so
# operators see *that* their safelist invariant has been violated, distinct
# from "this field is off-safelist."
#
# Design choices:
#
# * **Once per process, not once per record.** A misbehaving call site
#   typically fires every request; emitting a warn per request floods the
#   logs and trains operators to ignore it. One emission per process surfaces
#   the bug; the test suite is the durable fix vector (E10).
#
# * **`warnings.warn`, not a recursive `log.warn` call.** Driving a structlog
#   re-entry from inside a structlog processor is brittle (re-entrancy through
#   the same processor chain). `warnings.warn` is the standard Python
#   "library tells you something is wrong" surface; tests assert via
#   `pytest.warns(...)`. The runbook (T8) documents how SREs surface these:
#   Python's `-Wdefault::skaldos_log.processors.LogShapeMismatchWarning`
#   filter promotes them to stderr in a running app.
#
# * **Thread-safe one-shot.** The flag is guarded by a `threading.Lock` so
#   two requests racing through the chain on different worker threads can't
#   both land warns. Loss of the first emission on a true race is acceptable;
#   loss of N=2 is the actual bug.
#
# * **Reset hook for tests.** `_reset_shape_mismatch_warned_for_tests` is the
#   sibling of `_reset_no_span_counter_for_tests` — keeps the seam visible
#   on the package surface so the test harness has one knob to flip.
# ---------------------------------------------------------------------------


SHAPE_MISMATCH_KEY: Final[str] = "_skaldos_log_shape_mismatches"
"""Name of the inter-processor scratch key set by :func:`redact_pii` and read
by :func:`emit_shape_mismatch_warning`. Stable string; exposed because the
T3 strip processor and any test that wants to assert "no scratch leaked" pin
this exact value."""


class LogShapeMismatchWarning(UserWarning):
    """Emitted once per process when a safelisted field carries a malformed value.

    Operators surface this via Python's `-W` flag::

        python -W default::skaldos_log.processors.LogShapeMismatchWarning ...

    Tests assert via :func:`pytest.warns`. The warning category is its own
    subclass of :class:`UserWarning` so application-level filters (e.g.
    "ignore all UserWarning") don't suppress it.
    """


# Module-level one-shot flag, guarded by a lock for thread-safety.
_shape_mismatch_warned: bool = False
_shape_mismatch_lock: Final[threading.Lock] = threading.Lock()


def _reset_shape_mismatch_warned_for_tests() -> None:
    """Test-only: clear the one-shot warn flag.

    Without this hook each test in the same process inherits the previous
    test's "warned already" state — only the first test that triggers a
    shape mismatch could observe the warning. Pinned alongside
    :func:`_reset_no_span_counter_for_tests` for the same reason: a fresh
    test starts with a fresh process-level state seam.
    """
    global _shape_mismatch_warned
    with _shape_mismatch_lock:
        _shape_mismatch_warned = False


def emit_shape_mismatch_warning(
    _logger: Any, _method_name: str, event_dict: dict[str, Any]
) -> dict[str, Any]:
    """Emit a one-shot :class:`LogShapeMismatchWarning` when a mismatch is observed.

    Reads the :data:`SHAPE_MISMATCH_KEY` set by :func:`redact_pii`; if present
    AND the process has not yet warned, calls :func:`warnings.warn` with the
    list of offending field names plus a captured call site. Subsequent
    emissions of the same key are silent — the redaction itself still
    happened (the values were already replaced by the time this processor
    runs); the warn is just the "loud surface" pointer.

    Pure with respect to the event dict (returns it unmodified). The scratch
    key is dropped by the downstream :func:`_strip_internal_keys` processor;
    leaving it here lets a future processor (or a test fixture) read the
    same key without coupling to the order of side-effect-emitting steps.

    The processor never raises — even if `warnings.warn` itself blows up
    (custom warning filters can do this), the shield wrapper at the chain
    level converts it to a helper-internal sentinel without crashing the
    underlying log call.
    """
    mismatches = event_dict.get(SHAPE_MISMATCH_KEY)
    if not mismatches:
        return event_dict

    global _shape_mismatch_warned
    # Cheap check first — the lock acquisition only happens if the flag is
    # potentially flippable. Once True, every subsequent emission short-
    # circuits without grabbing the lock.
    if _shape_mismatch_warned:
        return event_dict

    with _shape_mismatch_lock:
        if _shape_mismatch_warned:
            return event_dict
        _shape_mismatch_warned = True

    call_site = _capture_call_site() or "<unknown>"
    fields = ", ".join(sorted(mismatches)) if isinstance(mismatches, list) else str(mismatches)
    warnings.warn(
        (
            f"Safelisted log field(s) carried a malformed value and were "
            f"redacted to <REDACTED:shape-mismatch>: {fields}. Call site: "
            f"{call_site}. This warning fires once per process; subsequent "
            f"shape-mismatch records still redact but do not re-warn. "
            f"Fix the call site (§20.2 / E6)."
        ),
        category=LogShapeMismatchWarning,
        stacklevel=2,
    )
    return event_dict


# ---------------------------------------------------------------------------
# Active-span enforcement (§20.4 / E1).
# ---------------------------------------------------------------------------


def _has_trace_correlation(event_dict: dict[str, Any]) -> bool:
    """Heuristic: does this event already carry a real ``trace_id``?

    T1 cannot read the OTel span itself (the SDK wiring lands in T3); we
    instead inspect what :func:`attach_otel_context` would have placed into
    the event. T1 unit tests bypass the un-wired ``attach_otel_context``
    and hand-write ``trace_id`` directly — that's the legitimate way to
    exercise the redaction layer in isolation.
    """
    trace_id = event_dict.get("trace_id")
    return isinstance(trace_id, str) and trace_id != "" and trace_id != TRACE_ID_MISSING


def enforce_active_span(
    _logger: Any, _method_name: str, event_dict: dict[str, Any]
) -> dict[str, Any]:
    """Raise in dev/test, rewrite to a sentinel in prod, when no span is active.

    Cooperates with :func:`attach_otel_context` (T3): that processor is
    expected to set ``trace_id`` to the active span's hex; if the field is
    missing or equals :data:`TRACE_ID_MISSING`, this processor concludes
    no span was active.

    Dev/test:
        Raises :class:`LogWithoutSpanError`. The test failure points to the
        offending call site; the engineer wraps it in a span.

    Prod:
        Rewrites the event into a ``log.without_span`` sentinel record with
        the original event name preserved as ``original_event``. The metric
        increment ships in T3 once the OTel meter provider is wired
        (planted as a TODO below).
    """
    if _has_trace_correlation(event_dict):
        return event_dict

    if not _is_prod():
        original_event = str(event_dict.get("event", "<unknown>"))
        raise LogWithoutSpanError(event_name=original_event, call_site=_capture_call_site())

    # Prod path — emit a sentinel, increment a metric (T3), do not crash.
    return _build_no_span_sentinel(event_dict)


def _build_no_span_sentinel(event_dict: dict[str, Any]) -> dict[str, Any]:
    """Construct the prod-mode no-span sentinel record.

    Preserves the original event name so SREs can grep the sentinel back to
    its source code path. Stack frame is best-effort — the exact frame
    depends on how deep the structlog chain is when this runs.

    Also increments :data:`LOG_WITHOUT_SPAN_COUNTER_NAME` via OTel metrics so
    operators page on sustained non-zero counts (E1). The counter is stable
    in name; tests in T3 pin it by reading the in-memory metric reader.
    """
    sentinel: dict[str, Any] = {
        "event": LOG_WITHOUT_SPAN_EVENT,
        "level": event_dict.get("level", "error"),
        "trace_id": TRACE_ID_MISSING,
        "original_event": str(event_dict.get("event", "<unknown>")),
        "call_site": _capture_call_site() or "<unknown>",
    }
    _increment_no_span_counter()
    return sentinel


# ---------------------------------------------------------------------------
# OTel metric for the prod no-span path (E1).
#
# §20.4: a log line without `trace_id` is a bug. Prod can't fail-fast, so the
# metric closes the loop — SREs alert on sustained non-zero counts. The
# counter is created lazily on first use so importing this module does not
# force a meter provider initialisation; applications wire their meter
# provider via `metrics.set_meter_provider(...)` separately. When no provider
# is installed, OTel's no-op meter swallows the increment without raising —
# the helper is correct without a provider, the metric just doesn't surface.
# ---------------------------------------------------------------------------

LOG_WITHOUT_SPAN_COUNTER_NAME: Final[str] = "log.without_span.count"
"""Stable counter name. Tests pin this exact string."""

_no_span_counter: metrics.Counter | None = None


def _get_no_span_counter() -> metrics.Counter:
    """Lazy-init the counter; cached so subsequent increments hit the same handle."""
    global _no_span_counter
    if _no_span_counter is None:
        meter = metrics.get_meter("skaldos_log")
        _no_span_counter = meter.create_counter(
            LOG_WITHOUT_SPAN_COUNTER_NAME,
            description=(
                "Count of log emissions outside an active OTel span (§20.4 / E1). "
                "Sustained non-zero values indicate a code path missing its tracer "
                "wrapper; SREs page."
            ),
        )
    return _no_span_counter


def _increment_no_span_counter() -> None:
    """Best-effort metric bump. A failure here must not crash the log call.

    The shield wraps :func:`enforce_active_span` so any exception escaping
    this helper would be caught and surfaced as a helper-internal sentinel,
    but we still defend in depth — the metric is observation, never load-
    bearing for the log call's success.
    """
    # Don't replace the no-span sentinel with an internal-error sentinel
    # over a metric glitch. The sentinel record itself is the durable
    # signal; the metric is a convenience for alerting.
    with contextlib.suppress(Exception):
        _get_no_span_counter().add(1)


def _reset_no_span_counter_for_tests() -> None:  # pyright: ignore[reportUnusedFunction]
    """Test-only: drop the cached counter so a fresh meter provider is read.

    Tests that swap in an `InMemoryMetricReader` need the next emission to
    bind against the new provider. Production never calls this — but we
    keep the name on the package surface (rather than burying it in tests)
    so the seam stays one-place-to-find when the metric chain evolves.

    The pyright suppression is intentional: this function is called only
    from tests, and pyright's `reportUnusedFunction` check is scope-local
    (the package's own src tree) — the test-side usage doesn't satisfy it.
    """
    global _no_span_counter
    _no_span_counter = None


def _capture_call_site() -> str | None:
    """Best-effort ``"file:line"`` for the offending log call.

    Walks the stack from the *innermost* frame outward, returning the first
    frame outside this package and outside structlog — that's the caller
    closest to the log call (the offending site). Returns ``None`` if we
    cannot identify one (e.g. the call originated from a C extension).

    Walking innermost-to-outermost matters: ``extract_stack()`` returns
    frames in outer-to-inner order, so the naive top-down scan would
    return the test runner / event-loop entry point rather than the user
    code that issued the log call. Reversing fixes that.
    """
    here = os.path.dirname(__file__)
    # `traceback.extract_stack()` yields outer→inner; reverse so we start
    # at the innermost frame (closest to the log call site). `[:-1]` drops
    # the deepest frame — `_capture_call_site` itself.
    for frame in reversed(traceback.extract_stack()[:-1]):
        # Skip frames inside this package — we want the caller, not us.
        if frame.filename.startswith(here):
            continue
        # Skip frames inside structlog itself; the caller is upstream.
        if "/structlog/" in frame.filename:
            continue
        return f"{frame.filename}:{frame.lineno}"
    return None


# ---------------------------------------------------------------------------
# Internal-failure shield (E21).
# ---------------------------------------------------------------------------


def shield_internal_failures(processor: Processor) -> Processor:
    """Wrap a processor so its exceptions become :data:`HELPER_INTERNAL_ERROR_EVENT`.

    E21: "a log helper failure must never propagate to business logic."
    Composes around any single processor; the T3 wiring composes the full
    chain inside a single shield at the boundary. Returning a fresh dict
    keyed only by the sentinel name + the captured exception type means we
    do *not* re-emit the original event dict (which may have been the cause
    of the failure).

    Carve-outs that *must* propagate:

    * :class:`LogWithoutSpanError` — the §20.4 fail-fast contract; tests
      catch missing-span call sites by seeing this raise.
    * :class:`KeyboardInterrupt` and :class:`SystemExit` — Python convention.
      A user pressing ``Ctrl+C`` during a logged operation must terminate
      the process, not be silently converted into a sentinel record. The
      shield catches ``BaseException`` to net unusual subclasses, then
      explicitly re-raises these two via ``isinstance``.
    """

    def _shielded(logger: Any, method_name: str, event_dict: dict[str, Any]) -> dict[str, Any]:
        try:
            return processor(logger, method_name, event_dict)
        except LogWithoutSpanError:
            # Intentional fail-fast in dev/test — must propagate so the test
            # suite catches the offending call site (§20.4).
            raise
        except BaseException as exc:  # noqa: BLE001 — see docstring rationale
            # KeyboardInterrupt / SystemExit propagate; Python convention
            # says interactive interrupts and `sys.exit()` are not caught
            # by general "shield this from any exception" wrappers.
            if isinstance(exc, (KeyboardInterrupt, SystemExit)):
                raise
            wrapped = HelperInternalError(exc)
            return {
                "event": HELPER_INTERNAL_ERROR_EVENT,
                "level": "error",
                "trace_id": event_dict.get("trace_id", TRACE_ID_MISSING),
                "exc_type": type(exc).__name__,
                "exc_message": str(wrapped),
            }

    return _shielded


# ---------------------------------------------------------------------------
# Stubs scaffolded for T3 (sanctioned scaffold-now-wire-later).
# ---------------------------------------------------------------------------


def attach_otel_context(
    _logger: Any, _method_name: str, event_dict: dict[str, Any]
) -> dict[str, Any]:
    """Read ``trace_id`` / ``span_id`` from the active OTel span.

    Stamps the event dict with the active span's hex-encoded ids. When no
    recording span is active, leaves both fields absent (or as
    :data:`TRACE_ID_MISSING` if the caller wrote it explicitly) — the
    downstream :func:`enforce_active_span` processor decides whether to
    raise (dev/test) or rewrite to a sentinel (prod).

    Caller-supplied ``trace_id`` / ``span_id`` are not overwritten — the
    explicit-kwarg-wins rule documented for principal context applies here
    too. The realistic path for a caller passing these is a deliberate test
    fixture or a structured replay tool.
    """
    span = trace.get_current_span()
    span_context = span.get_span_context()
    if not span_context.is_valid:
        # No active span, or only a no-op span installed. Leave the event
        # dict untouched; `enforce_active_span` handles the dev/prod split.
        return event_dict

    if "trace_id" not in event_dict:
        # OTel TraceId is a 128-bit int; the standard hex form is 32 lowercase
        # chars zero-padded — exactly what `_is_hex_32` accepts.
        event_dict["trace_id"] = format(span_context.trace_id, "032x")
    if "span_id" not in event_dict:
        # OTel SpanId is a 64-bit int → 16 lowercase hex chars zero-padded.
        event_dict["span_id"] = format(span_context.span_id, "016x")
    return event_dict


def attach_principal_context(
    _logger: Any, _method_name: str, event_dict: dict[str, Any]
) -> dict[str, Any]:
    """Drain the contextvars-bound principal map into the event dict.

    For every safelisted key in :func:`current_context`, attach it to the
    event dict iff the caller did not provide it explicitly. Explicit caller
    kwargs always win — that's the contract pinned by
    ``test_explicit_kwarg_overrides_context``.

    Only safelisted fields ever flow from context to the event; non-
    safelisted entries (none today, but defense in depth against a future
    misuse) are silently dropped here — the redaction layer would catch
    them later, but bouncing them at the boundary keeps the event dict
    clean.
    """
    ctx = current_context()
    for key, value in ctx.items():
        if key in event_dict:
            # Explicit caller kwarg wins (rare but documented).
            continue
        if key not in SAFELISTED_FIELDS:
            # Defensive — should never happen given `PrincipalContext`'s
            # TypedDict shape is a subset of the safelist. Keeps the
            # invariant local rather than relying on the type system.
            continue
        event_dict[key] = value
    return event_dict


# ---------------------------------------------------------------------------
# Final renderer (T7) — JSON for prod / collectors, pretty for local dev.
#
# §19.5 + E16: "engineer runs `mise run dev` on a laptop without a local
# collector container" — the helper falls back to pretty stdout so a local
# session is human-readable. The OTel collector tails container stdout in
# staging/prod, where JSON is the wire format the collector parses; pretty
# output there would corrupt the pipeline (mixed ANSI escapes + non-JSON
# tokens). The toggle separates the two worlds.
#
# Resolution order (first hit wins):
#
#   1. ``SKALDOS_LOG_FORMAT=json`` — explicit override, JSON.
#   2. ``SKALDOS_LOG_FORMAT=pretty`` — explicit override, pretty.
#   3. Auto: pretty iff stdout is a TTY AND ``CI`` env not set AND the
#      ``OTEL_EXPORTER_OTLP_ENDPOINT`` is unset (i.e. nothing is collecting
#      structured output downstream). Otherwise JSON.
#
# Coordination with `dev-environment/T6` (PR #17): when an engineer opts
# into the local OTel collector via ``SKALDOS_OTEL_LOCAL=true``, the dev
# stack exposes the collector at ``OTEL_EXPORTER_OTLP_ENDPOINT``. With that
# endpoint set, even on a TTY we revert to JSON so the engineer can
# `tail -f docker/otel/output/otel-logs.jsonl` and get parseable lines.
# Pretty stdout is the "no collector wired" affordance, not a per-mode
# coupling to traces.
#
# The chosen renderer is materialised at module import — which is also when
# `_PROCESSOR_CHAIN` is built. A test harness or in-process flip
# (``select_renderer(force="json")``) re-resolves and lets `__init__.py`
# rebuild the chain via `_reset_renderer_for_tests`. Tests typically don't
# reach for either: the canonical `captured_logs` fixture replaces the
# final renderer with a `LogCapture` regardless of which renderer would
# otherwise be picked.
# ---------------------------------------------------------------------------

LOG_FORMAT_ENV_VAR: Final[str] = "SKALDOS_LOG_FORMAT"
"""Env var name pinning the renderer choice. Stable string; tests pin it."""

LOG_FORMAT_PRETTY: Final[str] = "pretty"
LOG_FORMAT_JSON: Final[str] = "json"

_OTEL_ENDPOINT_ENV_VAR: Final[str] = "OTEL_EXPORTER_OTLP_ENDPOINT"
_CI_ENV_VAR: Final[str] = "CI"


def resolve_log_format() -> str:
    """Return ``"pretty"`` or ``"json"`` per the resolution order in this module's banner.

    Pure function over the environment + ``sys.stdout``; safe to call multiple
    times. The auto-detection check (`sys.stdout.isatty()`) reflects the
    *current* stdout — if a test or harness has redirected stdout to a buffer
    (no `isatty` method, or returns False), auto-mode resolves to JSON. That
    is the safe default: a non-TTY stdout is almost always a pipe / file /
    captured stream where pretty ANSI escapes would corrupt downstream
    parsing.
    """
    explicit = os.environ.get(LOG_FORMAT_ENV_VAR, "").strip().lower()
    if explicit == LOG_FORMAT_JSON:
        return LOG_FORMAT_JSON
    if explicit == LOG_FORMAT_PRETTY:
        return LOG_FORMAT_PRETTY
    # Auto-detection — pretty only when nothing downstream is parsing the
    # stream and the operator is sitting at a real terminal.
    if os.environ.get(_OTEL_ENDPOINT_ENV_VAR, "").strip():
        return LOG_FORMAT_JSON
    if os.environ.get(_CI_ENV_VAR, "").strip():
        return LOG_FORMAT_JSON
    try:
        is_tty = sys.stdout.isatty()
    except (AttributeError, ValueError, OSError):
        # `ValueError: I/O operation on closed file` and friends — fall back
        # to JSON, which is correct for any captured-stream context.
        is_tty = False
    return LOG_FORMAT_PRETTY if is_tty else LOG_FORMAT_JSON


def _build_renderer() -> Processor:
    """Materialise the structlog renderer matching :func:`resolve_log_format`.

    Pretty mode uses :class:`structlog.dev.ConsoleRenderer` with colors
    enabled when the resolution path went through the TTY-auto branch (the
    case where an engineer is actually watching a terminal). JSON mode uses
    :class:`structlog.processors.JSONRenderer` — bytes-on-the-wire identical
    to what the OTel collector / Cloud Logging consumes upstream.

    Returns a structlog processor — a callable
    ``(logger, method_name, event_dict) -> str`` that closes over the
    chosen renderer instance.
    """
    fmt = resolve_log_format()
    if fmt == LOG_FORMAT_PRETTY:
        # `colors=True` is the dev affordance — readable diff between
        # tiers and field names. The dev-only path; production never hits
        # `ConsoleRenderer` because the auto path falls through to JSON
        # whenever `CI` or the OTLP endpoint is set.
        return structlog.dev.ConsoleRenderer(colors=True)
    return structlog.processors.JSONRenderer()


def json_renderer(logger: Any, method_name: str, event_dict: dict[str, Any]) -> str:
    """Render the event dict via the resolved renderer (JSON or pretty).

    Picks between :class:`structlog.processors.JSONRenderer` (prod /
    collector / CI / non-TTY) and :class:`structlog.dev.ConsoleRenderer`
    (local laptop dev with no OTel endpoint wired) per
    :func:`resolve_log_format`. Resolution happens once at module import;
    the chosen renderer is cached in :data:`_RESOLVED_RENDERER` and reused
    on every emission. ``__init__.py`` plants this function as the final
    step of the processor chain so the chain shape stays declarative and
    legible from one place.

    Tests that need to flip the format use
    :func:`_reset_renderer_for_tests` to clear the cache; the next emission
    re-resolves against the (now-mutated) environment.
    """
    return _get_renderer()(logger, method_name, event_dict)


# Module-level cache — built lazily on first call so that simply importing
# this module does not lock in a renderer choice before tests have had a
# chance to set env vars (the structlog import elsewhere triggers this
# module's import too). The cache is invalidated by
# `_reset_renderer_for_tests`.
_RESOLVED_RENDERER: Processor | None = None


def _get_renderer() -> Processor:
    """Return the cached renderer, building one on first use."""
    global _RESOLVED_RENDERER
    if _RESOLVED_RENDERER is None:
        _RESOLVED_RENDERER = _build_renderer()
    return _RESOLVED_RENDERER


def _reset_renderer_for_tests() -> None:
    """Test-only: drop the cached renderer so the next emission re-resolves.

    Without this hook, a test that sets ``SKALDOS_LOG_FORMAT=pretty`` mid-
    suite would still see the renderer chosen at import time. Pinned alongside
    :func:`_reset_no_span_counter_for_tests` and
    :func:`_reset_shape_mismatch_warned_for_tests` for symmetry — each
    process-level cache has one named seam to flip.
    """
    global _RESOLVED_RENDERER
    _RESOLVED_RENDERER = None
