"""PII redaction layer for the SkaldOS log chokepoint.

§20.2 commits the substrate to "log types, not values." Every kwarg passed to
``log.{tier}`` is filtered through this module before emission. The contract:

1. Field name in :data:`SAFELISTED_FIELDS` *and* value passes the optional
   :data:`VALUE_SHAPE_CHECKS` entry → field is preserved verbatim.
2. Field name in :data:`SAFELISTED_FIELDS` but the value fails its shape
   check → value is replaced with :data:`REDACTED_SHAPE_MISMATCH`.
3. Field name *not* on the safelist → value is replaced with
   ``"<REDACTED:<typename>>"`` (objects collapse to ``"<REDACTED:object>"``).

This is the **primary** discipline for keeping PII out of logs (§9.2 + §20.2).
The OTel collector applies a small additional defense-in-depth strip
(`attributes/redaction-defense` per ``ops/otel-collector/config.*.yaml``) but
the in-process layer is the source of truth.

Adding to :data:`SAFELISTED_FIELDS` requires the same review depth as adding
a CASL subject (§20.2). The TS side (``packages/log/ts/redaction.ts``) ships
the same set; CI parity is enforced by ``scripts/check-safelist-parity.py``
(T2 lands the script + the TS file).

References: §20.2, §9.2, §20.4, E5–E10, E23.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from typing import Any, Final, cast

# ---------------------------------------------------------------------------
# Sentinels — operators alert / search on these literal strings.
# ---------------------------------------------------------------------------

REDACTED_SHAPE_MISMATCH: Final[str] = "<REDACTED:shape-mismatch>"
"""Replacement value when a safelisted field carries a value that fails its
shape check (e.g. ``tenant_id="not-a-uuid"`` per E6). Distinct sentinel from
the non-safelisted case so operators can tell "we caught a typed leak" apart
from "we caught a non-safelisted field."
"""

REDACTED_OBJECT: Final[str] = "<REDACTED:object>"
"""Replacement value for non-safelisted dict / list / custom-object fields
(E8). Set + tuple collapse here too — anything non-scalar becomes one
opaque marker so deep traversal of structured payloads is not a thing the
helper does.
"""


# ---------------------------------------------------------------------------
# Value-shape predicates.
#
# Each returns True for an acceptable value, False otherwise. Predicates are
# tight by design — the cost of a false negative is "engineer notices the
# field redacted in their logs and fixes the call site"; the cost of a false
# positive is "PII landed in a log."
# ---------------------------------------------------------------------------

_HEX_32_RE: Final[re.Pattern[str]] = re.compile(r"^[0-9a-f]{32}$")
_HEX_16_RE: Final[re.Pattern[str]] = re.compile(r"^[0-9a-f]{16}$")
_HEX_64_RE: Final[re.Pattern[str]] = re.compile(r"^[0-9a-f]{64}$")
_UUID_RE: Final[re.Pattern[str]] = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$"
)
_ROUTE_PATH_RE: Final[re.Pattern[str]] = re.compile(r"^/[a-z0-9/_\-]*$")

# Pool-sizing bounds (Slice 2 followups #17). asyncpg pools in this
# substrate top out at the rate-limit pool's 10-conn ceiling; 100 is a
# generous upper bound that pins "this is a sizing integer, not an
# accidental row count or principal_id leak."
_POOL_SIZE_MIN: Final[int] = 0
_POOL_SIZE_MAX: Final[int] = 100

_INTENT_VALUES: Final[frozenset[str]] = frozenset(
    {"assertive", "directive", "commissive", "expressive", "declarative"}
)
_KIND_VALUES: Final[frozenset[str]] = frozenset({"human", "agent"})
_TRIGGER_KIND_VALUES: Final[frozenset[str]] = frozenset({"sync", "scheduled", "event"})
_HARNESS_VALUES: Final[frozenset[str]] = frozenset({"pi", "claude-code", "opencode", "custom"})
_STREAM_VALUES: Final[frozenset[str]] = frozenset({"stdout", "stderr"})


def _is_hex_32(value: Any) -> bool:
    return isinstance(value, str) and _HEX_32_RE.match(value) is not None


def _is_hex_16(value: Any) -> bool:
    return isinstance(value, str) and _HEX_16_RE.match(value) is not None


def _is_sha256_hex(value: Any) -> bool:
    """64-char lowercase hex — the shape of ``hashlib.sha256(...).hexdigest()``.

    Used by ``auth0_sub_hash`` (Slice 2 followups #18); the field's intent
    is to surface a stable correlation handle for the auth0 subject without
    leaking the raw sub. See ``services/api/skaldos/middleware/hydration.py``
    where the field is emitted.
    """
    return isinstance(value, str) and _HEX_64_RE.match(value) is not None


def _is_pool_size(value: Any) -> bool:
    """Non-negative int, ≤ 100 — operational sizing for asyncpg pools.

    Used by ``pool_min_size`` and ``pool_max_size`` (Slice 2 followups #17);
    the upper bound pins "this is a sizing integer, not an accidental row
    count or PII leak smuggled through a misnamed field." Booleans are
    rejected explicitly because ``isinstance(True, int) is True`` in Python.
    """
    return (
        isinstance(value, int)
        and not isinstance(value, bool)
        and _POOL_SIZE_MIN <= value <= _POOL_SIZE_MAX
    )


def _is_uuid(value: Any) -> bool:
    # Accept the canonical 8-4-4-4-12 lowercase hex; UUIDv7 timestamp prefix
    # tolerance is irrelevant here — we only check shape, not version.
    return isinstance(value, str) and _UUID_RE.match(value) is not None


def _is_route_path(value: Any) -> bool:
    # `^/[a-z0-9/_-]*$` per 03 — disallows `..`, query strings, uppercase, and
    # anything that could smuggle a path-traversal value into a "safe" field.
    return isinstance(value, str) and _ROUTE_PATH_RE.match(value) is not None and ".." not in value


def _is_http_method(value: Any) -> bool:
    return isinstance(value, str) and value in {
        "GET",
        "HEAD",
        "POST",
        "PUT",
        "PATCH",
        "DELETE",
        "OPTIONS",
        "TRACE",
        "CONNECT",
    }


def _is_http_status(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and 100 <= value <= 599


def _is_duration_ms(value: Any) -> bool:
    # Duration is always non-negative; allow int or float.
    return isinstance(value, (int, float)) and not isinstance(value, bool) and value >= 0


def _in_set(allowed: frozenset[str]) -> Callable[[Any], bool]:
    def _check(value: Any) -> bool:
        return isinstance(value, str) and value in allowed

    return _check


# ---------------------------------------------------------------------------
# The safelist (§20.2). Single source of truth on the Python side; the TS
# mirror lives at `packages/log/ts/redaction.ts` (T2). Drift is caught by
# `scripts/check-safelist-parity.py` (T2).
#
# Keep this list narrow; widening it requires §20.2 review. The grouping
# below mirrors `03-technical-implementation.md`'s § Safelist.
# ---------------------------------------------------------------------------

SAFELISTED_FIELDS: Final[frozenset[str]] = frozenset(
    {
        # Identity — correlation handles, never PII.
        "trace_id",
        "span_id",
        "principal_id",
        "tenant_id",
        "agent_id",
        "agent_run_id",
        "tool_call_id",
        "shield_call_id",
        "execution_trace_id",
        "membership_id",
        # auth0 correlation handle (Slice 2 followups #18). SHA-256 of
        # ``claims.auth0_sub``; same input every time so log records can be
        # joined across requests for one auth0 subject without exposing the
        # raw ``sub`` string. Tightened to the 64-char lowercase-hex shape
        # so a misuse (e.g. logging the raw sub under this key) trips the
        # shape-mismatch sentinel instead of slipping through.
        "auth0_sub_hash",
        # Substrate primitives — IDs only, never values.
        "node_id",
        "edge_id",
        "tag_id",
        "tag_definition_id",
        "document_id",
        "outbox_event_id",
        "event_id_hash",
        "subscription_id",
        "audit_row_id",
        # Routing / HTTP.
        "route_path",
        "http_method",
        "http_status",
        "duration_ms",
        # Closed-enum kinds.
        "kind",
        "trigger_kind",
        "event_type",
        "outcome",
        "intent",
        # Authorization / rate-limit audit fields (§14.7, §20.2).
        "decision",
        "action",
        "subject_kind",
        "reason_code",
        "tier",
        # Rate-limit counter values — non-PII operational integers.
        "count",
        "limit",
        "retry_after_seconds",
        # Rate-limit T5 operational config / error fields — infrastructure
        # observability; no PII possible (§14.7, §20.1; T5 startup audit log
        # and fail-mode error log lines).
        "enabled",
        "env",
        "fail_mode",
        "shadow_mode",
        "override_limits",
        "error",
        # Pool sizing for the three startup-audit log lines emitted by
        # ``services/api/skaldos/app.py:_app_lifespan`` (Slice 2 followups #17).
        # Operator dashboards key on these to confirm the chokepoint /
        # runtime / rate-limit pools are sized as expected on each deploy.
        "pool_min_size",
        "pool_max_size",
        # Operational handles.
        "template_version",
        "harness",
        "stream",
        "sandbox_id",
        "pi_event_id",
        "graph_write_id",
        "workflow_id",
    }
)

# Optional shape checks. A safelisted field with no entry here is logged
# verbatim (no per-character validation); operational fields like
# ``template_version`` or ``event_type`` are intentionally free-form within
# the safelist. The shape checks exist for fields where a typed leak would
# be a defect (E6 — the `tenant_id=user.email` accidental swap).
VALUE_SHAPE_CHECKS: Final[dict[str, Callable[[Any], bool]]] = {
    "trace_id": _is_hex_32,
    "span_id": _is_hex_16,
    "principal_id": _is_uuid,
    "tenant_id": _is_uuid,
    "agent_id": _is_uuid,
    "agent_run_id": _is_uuid,
    "tool_call_id": _is_uuid,
    "shield_call_id": _is_uuid,
    "execution_trace_id": _is_uuid,
    "membership_id": _is_uuid,
    "auth0_sub_hash": _is_sha256_hex,
    "node_id": _is_uuid,
    "edge_id": _is_uuid,
    "tag_id": _is_uuid,
    "tag_definition_id": _is_uuid,
    "document_id": _is_uuid,
    "outbox_event_id": _is_uuid,
    "event_id_hash": _is_sha256_hex,
    "subscription_id": _is_uuid,
    "audit_row_id": _is_uuid,
    "route_path": _is_route_path,
    "http_method": _is_http_method,
    "http_status": _is_http_status,
    "duration_ms": _is_duration_ms,
    "pool_min_size": _is_pool_size,
    "pool_max_size": _is_pool_size,
    "kind": _in_set(_KIND_VALUES),
    "trigger_kind": _in_set(_TRIGGER_KIND_VALUES),
    "intent": _in_set(_INTENT_VALUES),
    "harness": _in_set(_HARNESS_VALUES),
    "stream": _in_set(_STREAM_VALUES),
    "sandbox_id": _is_uuid,
    "pi_event_id": _is_uuid,
    "graph_write_id": _is_uuid,
}


# ---------------------------------------------------------------------------
# Per-field redaction.
# ---------------------------------------------------------------------------

# Built-in scalar types whose name is safe to surface in `<REDACTED:<type>>`.
# (Type names of arbitrary user classes can themselves carry PII — e.g. a
# `class UserPhoneNumber` whose name *is* the leak — so we collapse anything
# unfamiliar to `<REDACTED:object>` per E8.)
_KNOWN_SCALAR_TYPES: Final[frozenset[type[Any]]] = frozenset(
    {str, int, float, bool, bytes, type(None)}
)


def _scalar_type_marker(value: Any) -> str:
    """Return ``"<REDACTED:<typename>>"`` for known scalars, else collapse."""
    value_type = cast(type[Any], type(value))
    if value_type in _KNOWN_SCALAR_TYPES:
        return f"<REDACTED:{value_type.__name__}>"
    return REDACTED_OBJECT


def redact_field(name: str, value: Any) -> tuple[Any, bool]:
    """Return ``(redacted_value, shape_mismatch)`` for one field.

    The second tuple element is ``True`` only when a safelisted field's
    value failed its shape check — the caller (the structlog processor) uses
    this to emit a one-shot ``warn``-tier sentinel pointing to the call site
    (E6). For non-safelisted fields and for safelisted-with-no-shape-check
    fields, the flag is ``False``.

    Pure function; no I/O, no logging, no exceptions.
    """
    if name not in SAFELISTED_FIELDS:
        return _scalar_type_marker(value), False

    shape_check = VALUE_SHAPE_CHECKS.get(name)
    if shape_check is None:
        # Safelisted field with no shape check; preserved verbatim.
        return value, False

    if shape_check(value):
        return value, False

    # Safelisted but shape-mismatched — defense in depth (E6).
    return REDACTED_SHAPE_MISMATCH, True


def redact_event_dict(event_dict: dict[str, Any]) -> tuple[dict[str, Any], list[str]]:
    """Apply :func:`redact_field` to every key in an event dict.

    Returns the redacted dict plus a list of field names that triggered a
    shape-mismatch redaction. The structlog processor wired in T3 turns that
    list into a one-shot ``warn`` line so the offending call site shows up
    in the logs alongside the redacted record.

    ``event``, ``level``, ``timestamp``, and other structlog-internal keys
    are passed through untouched — they are produced by structlog itself,
    not by the caller, so they have no business going through the safelist.
    """
    out: dict[str, Any] = {}
    mismatches: list[str] = []

    for key, value in event_dict.items():
        if key in _STRUCTLOG_INTERNAL_KEYS:
            out[key] = value
            continue
        redacted, mismatch = redact_field(key, value)
        out[key] = redacted
        if mismatch:
            mismatches.append(key)

    return out, mismatches


# Keys structlog itself (or its standard processors) writes into the event
# dict. Letting these flow through the safelist would force every log call
# to redact its own ``event`` name, which is precisely backwards.
_STRUCTLOG_INTERNAL_KEYS: Final[frozenset[str]] = frozenset(
    {
        "event",  # the message / event name passed as first arg
        "level",  # added by structlog.processors.add_log_level
        "logger",  # logger name
        "timestamp",  # added by a TimeStamper if configured (avoid wall-clock asserts in tests)
        "exc_info",  # standard exception passthrough
        "stack_info",  # standard stack passthrough
    }
)
