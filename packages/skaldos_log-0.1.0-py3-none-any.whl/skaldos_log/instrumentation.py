"""OTel auto-instrumentation registration for the SkaldOS log chokepoint.

Per ``05-task-list.md`` T5 and ``02-edge-cases.md`` E4: cross-process trace
propagation must not break. The OTel SDK auto-instrumentation libraries for
FastAPI / ``httpx`` / ``asyncpg`` propagate W3C ``traceparent`` headers and
emit spans for HTTP requests, outbound HTTP calls, and Postgres queries — the
"plumbing" the chokepoint helper *reads* from in :mod:`processors` (via
``trace.get_current_span()``). Without instrumentation registered, the
helper's :func:`attach_otel_context` would see no span on a worker handling
an inbound HTTP request, and the §20.4 fail-fast contract would page on
every request rather than only on the genuinely uninstrumented call sites.

This module exposes one entry point — :func:`register_auto_instrumentation` —
that an application calls once at startup (typically immediately after
configuring its OTel ``TracerProvider``). The matching
:func:`unregister_auto_instrumentation` undoes the work for tests and for
graceful shutdown.

Design choices:

* **Registration is idempotent.** Calling :func:`register_auto_instrumentation`
  twice is a no-op the second time — important for tests that re-import the
  module and for applications that have multiple entry points (FastAPI app
  + a worker process + a CLI). The book-keeping is a module-level dict so
  the second call sees what the first installed.
* **Lazy imports.** Each instrumentation library is imported inside the
  registration body, not at module import time. The base helper package
  (per ``E22`` + ``test_log_package_dependencies.py``) commits to a small
  declared external dependency set; pulling FastAPI / ``httpx`` / ``asyncpg``
  into the helper's import graph would make the helper non-reusable for
  contexts that don't have those libraries installed (e.g. a CLI tool that
  only logs to stdout).
* **Optional dependencies.** The instrumentation packages live in the
  ``[project.optional-dependencies].instrumentation`` extra. ``pip install
  skaldos-log[instrumentation]`` pulls them in; without the extra a missing
  library is not an error — the registration silently skips it (and reports
  back via the return value so the caller knows what landed).
* **No side effects at import.** Importing ``skaldos_log.instrumentation``
  does *not* instrument anything. The application explicitly calls
  :func:`register_auto_instrumentation`. This matters for tests which want
  to control when the global state changes.

References: §13.1, §20.4, ADR 10, E4, E18, E19, MP5.
"""

from __future__ import annotations

import contextlib
import importlib
import threading
from collections.abc import Iterable
from dataclasses import dataclass
from typing import Any, Final

__all__ = [
    "INSTRUMENTOR_SPECS",
    "InstrumentorSpec",
    "RegistrationResult",
    "is_instrumentation_registered",
    "register_auto_instrumentation",
    "registered_instrumentations",
    "unregister_auto_instrumentation",
]


# ---------------------------------------------------------------------------
# Instrumentor spec registry.
#
# Each entry names:
#   * `name`       — short label used in :class:`RegistrationResult` and logs.
#   * `module`     — the dotted module path the SDK ships the instrumentor under.
#   * `class_name` — the `Instrumentor` class within that module.
#
# Adding a new instrumentation: append to :data:`INSTRUMENTOR_SPECS` and add
# the corresponding `opentelemetry-instrumentation-<X>` to the
# `[project.optional-dependencies].instrumentation` extra in
# `packages/log/py/pyproject.toml`. The shape is intentionally a list of
# dataclasses (not an enum) so an integration test can monkeypatch the
# specs to register a fake instrumentor in isolation.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class InstrumentorSpec:
    """Pointer to a single OTel auto-instrumentation library."""

    name: str
    module: str
    class_name: str


INSTRUMENTOR_SPECS: Final[tuple[InstrumentorSpec, ...]] = (
    # FastAPI: instruments inbound HTTP request handlers, parses the W3C
    # `traceparent` header off the request, and starts a server-kind span
    # per request. The chokepoint's `attach_otel_context` reads this span.
    InstrumentorSpec(
        name="fastapi",
        module="opentelemetry.instrumentation.fastapi",
        class_name="FastAPIInstrumentor",
    ),
    # httpx: instruments outbound HTTP calls, injects the W3C `traceparent`
    # header so a downstream server-kind span is a child of the caller's
    # span. The cross-process trace propagation contract (§13.1, E4) rides
    # on this.
    InstrumentorSpec(
        name="httpx",
        module="opentelemetry.instrumentation.httpx",
        class_name="HTTPXClientInstrumentor",
    ),
    # asyncpg: instruments the async Postgres driver SkaldOS uses end-to-end
    # (per CLAUDE.md tech stack). Each query gets a client-kind span tagged
    # with `db.system="postgresql"` + `db.statement` (parameterized; values
    # not surfaced — see §20.2). Required for "click from a Cloud Trace span
    # to its DB query" debugging (per `04-testing-strategy.md` step 7).
    InstrumentorSpec(
        name="asyncpg",
        module="opentelemetry.instrumentation.asyncpg",
        class_name="AsyncPGInstrumentor",
    ),
)


# ---------------------------------------------------------------------------
# Registration result + book-keeping.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class RegistrationResult:
    """Outcome of a :func:`register_auto_instrumentation` call.

    Attributes:
        installed: names of instrumentors that were instrumented in this call
            (newly — i.e. not already installed before the call).
        already_installed: names of instrumentors that were already
            instrumented when the call ran (no-op).
        skipped: names of instrumentors whose backing module could not be
            imported (the corresponding ``opentelemetry-instrumentation-<X>``
            extra is not installed). Not an error; the SRE / engineer reads
            the return value to confirm what landed.
    """

    installed: tuple[str, ...]
    already_installed: tuple[str, ...]
    skipped: tuple[str, ...]


# Module-level state. The lock guards `_INSTALLED` against concurrent
# `register_auto_instrumentation()` calls in the same process — rare, but
# tests that exercise idempotency could plausibly race. Loss of a single
# install on a true race is benign (the next call observes the winner's
# state and short-circuits); double-install is the bug we're guarding.
_INSTALLED: dict[str, Any] = {}
_LOCK: Final[threading.Lock] = threading.Lock()


def _resolve_instrumentor(spec: InstrumentorSpec) -> Any | None:
    """Lazy-import the instrumentor class. Return ``None`` if unavailable.

    OTel's instrumentor classes are singletons by convention — calling
    `FooInstrumentor()` twice returns the same instance. We follow the
    convention; the singleton is what `instrument()` / `uninstrument()`
    operate on.
    """
    try:
        module = importlib.import_module(spec.module)
    except ImportError:
        return None
    cls = getattr(module, spec.class_name, None)
    if cls is None:
        return None
    return cls()


def _filter_specs(only: Iterable[str] | None) -> tuple[InstrumentorSpec, ...]:
    """Return the subset of :data:`INSTRUMENTOR_SPECS` whose name is in ``only``.

    ``only is None`` returns all specs. Unknown names raise ``ValueError`` so
    a typo in the call site fails loud.
    """
    if only is None:
        return INSTRUMENTOR_SPECS
    requested = set(only)
    by_name = {spec.name: spec for spec in INSTRUMENTOR_SPECS}
    unknown = requested - by_name.keys()
    if unknown:
        raise ValueError(
            f"Unknown instrumentor name(s): {sorted(unknown)}. "
            f"Known names: {sorted(by_name.keys())}."
        )
    return tuple(by_name[name] for name in requested)


def register_auto_instrumentation(
    *,
    only: Iterable[str] | None = None,
    instrument_kwargs: dict[str, dict[str, Any]] | None = None,
) -> RegistrationResult:
    """Register every available OTel auto-instrumentation.

    Idempotent: calling twice is a no-op the second time. The return value
    distinguishes "newly installed in this call" from "already installed"
    so callers can assert on the second call (per
    ``test_auto_instrumentation_registration.py`` — idempotency is a load-
    bearing property).

    Args:
        only: optional iterable of instrumentor names to register. Useful in
            tests that want to install just one instrumentor (e.g.
            ``only=["asyncpg"]`` in a DB-only test). ``None`` registers all
            available specs.
        instrument_kwargs: optional per-instrumentor ``instrument()`` kwargs
            keyed by name. Most instrumentors accept e.g. ``tracer_provider``
            so an application can wire a non-global provider; tests pass
            their own provider here.

    Returns:
        :class:`RegistrationResult` — the names that landed, the names that
        were already in place, and the names skipped because the
        ``opentelemetry-instrumentation-<X>`` extra is not installed.
    """
    selected = _filter_specs(only)
    kwargs_by_name = instrument_kwargs or {}

    installed: list[str] = []
    already: list[str] = []
    skipped: list[str] = []

    with _LOCK:
        for spec in selected:
            if spec.name in _INSTALLED:
                already.append(spec.name)
                continue
            instrumentor = _resolve_instrumentor(spec)
            if instrumentor is None:
                skipped.append(spec.name)
                continue
            kwargs = kwargs_by_name.get(spec.name, {})
            instrumentor.instrument(**kwargs)
            _INSTALLED[spec.name] = instrumentor
            installed.append(spec.name)

    return RegistrationResult(
        installed=tuple(installed),
        already_installed=tuple(already),
        skipped=tuple(skipped),
    )


def unregister_auto_instrumentation(*, only: Iterable[str] | None = None) -> tuple[str, ...]:
    """Reverse a previous :func:`register_auto_instrumentation` call.

    Idempotent: instrumentors not currently installed are silently skipped.
    Tests use this in fixture teardown so global instrumentation state does
    not leak across tests; production uses it in graceful-shutdown paths.

    Args:
        only: optional iterable of names to uninstrument. ``None`` removes
            all currently-installed specs.

    Returns:
        Tuple of names that were uninstrumented (post-condition: those names
        are no longer in the installed set).
    """
    if only is None:
        targets = list(_INSTALLED.keys())
    else:
        targets = [name for name in only if name in _INSTALLED]

    removed: list[str] = []
    with _LOCK:
        for name in targets:
            instrumentor = _INSTALLED.pop(name, None)
            if instrumentor is None:
                continue
            # uninstrument() on some libraries raises if no instance was
            # installed (defensive against partial state). Swallow — the goal
            # is "ensure not installed"; if the library says it already
            # wasn't, that's the desired post-condition.
            with contextlib.suppress(Exception):
                instrumentor.uninstrument()
            removed.append(name)

    return tuple(removed)


def registered_instrumentations() -> tuple[str, ...]:
    """Return the names of currently-registered instrumentors (sorted)."""
    with _LOCK:
        return tuple(sorted(_INSTALLED.keys()))


def is_instrumentation_registered(name: str) -> bool:
    """Return True iff the named instrumentor is currently installed."""
    with _LOCK:
        return name in _INSTALLED
