import os
import re
import json
import time
import shutil
import base64
import pathlib
import requests
import argparse
from enum import Enum

import yt_dlp
from ytmusicapi import YTMusic

from . import lyrics_utils
from .tag_utils import tag_utils
from . import logging_utils
from . import files_utils



def _trackname_remove_unnecessary(track_name:str) -> str:
    """
    Cleans a track name by removing common feature and producer text patterns.

    This function strips out variations of "(feat. ...)", "ft.", "(prod. ...)", 
    and similar metadata often appended to song titles. It also removes any 
    resulting trailing whitespace.

    Args:
        track_name (str): The original track name containing potential 
            unnecessary feature or producer tags.

    Returns:
        str: The cleaned track name.
        
    Examples:
        >>> _trackname_remove_unnecessary("Song Title (feat. Artist B)")
        'Song Title'
        >>> _trackname_remove_unnecessary("Another Track [prod. by DJ C]")
        'Another Track'
    """
    name = re.sub(r'\(feat.*?\)|\(ft.*?\)|feat.*|ft.*|\(Feat.*?\)|\(Ft.*?\)|\(prod.*?\)|\[prod.*?\]|\(Prod.*?\)', '', track_name)
    return name.rstrip()


def _get_feat_artists(track_name:str) -> list[str]:
    """
    Extracts a list of featured artists from a given track name.

    This function searches the track name for common "featuring" indicators 
    (such as "feat.", "ft.", "(feat ...)", etc., ignoring case) and parses out 
    the individual artist names. It splits multiple artists separated by 
    commas or ampersands ("&").

    Args:
        track_name (str): The full title of the music track.

    Returns:
        list of str: A list containing the names of the featured artists. 
            Returns an empty list if no featured artists are found.

    Examples:
        >>> _get_feat_artists("Cool Song (feat. Artist A & Artist B)")
        ['Artist A', 'Artist B']
        >>> _get_feat_artists("Another Track ft. Singer, Rapper")
        ['Singer', 'Rapper']
        >>> _get_feat_artists("Solo Track")
        []
    """
    match = re.search(r'\((?:feat|ft)\.*.*?\)|(?:feat|ft)\.*.*', track_name, re.IGNORECASE)

    if match:
        result = re.sub(r'.*?(feat|ft)\.*', '', match.group(0), flags=re.IGNORECASE).strip("() ")

        artists = re.split(r',|\s&\s', result)

        # Clean up whitespace
        artists = [artist.strip() for artist in artists]

        return artists

    return []

def _sanitize_filename(filename:str) -> str:
    """
    Sanitizes a string for use as a safe file or directory name.

    This function replaces characters that are forbidden in most file systems 
    (Linux, Windows, MacOS, Android) with visually similar full-width Unicode equivalents 
    or safe alternatives.

    Args:
        filename (str): The original, unsanitized filename string.

    Returns:
        str: The sanitized filename safe for writing to disk.

    Examples:
        >>> _sanitize_filename('My "Awesome" Track: Part 1/2?')
        "My ''Awesome'' Track： Part 1／2？"
        >>> _sanitize_filename("Title<With>Illegal*Chars|")
        'Title＜With＞Illegal＊Chars∣'
    """
    filename = re.sub(r'[:]', "：", filename)
    filename = re.sub(r'[?]', "？", filename)
    filename = re.sub(r'[*]', "＊", filename)
    filename = re.sub(r'[<]', "＜", filename)
    filename = re.sub(r'[>]', "＞", filename)
    filename = re.sub(r'[/]', "／", filename)
    filename = re.sub(r'["]', "\'\'", filename)
    filename = re.sub(r'[|]', "∣", filename)
    filename = re.sub(r'[\0]', "", filename)
    
    return filename


def _get_image(url, retries=3, delay=2):
    for attempt in range(retries):
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            return base64.b64encode(response.content).decode('utf-8')
        else:
            time.sleep(delay)

    logging_utils.logging.warning(f"Failed to download image. Status code: {response.status_code}")
    return {}


def _init_track_info():
    track_info = {}
    track_info['ytm_id'] = ""
    track_info['ytm_title'] = ""
    track_info['track_name'] = ""
    track_info['track_artists'] = []
    track_info['track_artists_str'] = ""
    track_info['release_date'] = ""
    track_info['album_name'] = ""
    track_info['album_artists'] = []
    track_info['track_number'] = ""
    track_info['total_tracks'] = ""
    track_info['lyrics'] = ""
    track_info['cover'] = ""
    return track_info

class SearchType(str, Enum):
    ARTIST = "artists"
    ALBUM = "albums"
    SONG = "songs"

class Muzlib():
    def __init__(self, library_path, codec="opus", skip_downloaded=False):
        """
        Docstring for __init__
        
        :param library_path: path to the music library
        :param codec: preferred codec for downloaded audio (opus, mp3, m4a)
        :param skip_downloaded: whether to skip already downloaded tracks based on the database
        """

        self.extension = "." + codec.lower()


        current_dir = os.path.dirname(os.path.abspath(__file__))
        cookie_path = os.path.join(current_dir, 'assets','cookies.txt')

        self.ydl_opts = {
            'format': 'bestaudio',
            'outtmpl': '%(id)s.%(ext)s',
            'retries': 5,  # Retry 5 times for errors
            'postprocessors': [{
                    'key': 'FFmpegExtractAudio',
                    'preferredcodec': codec,
                    'preferredquality': '0', # Best quality
            }],
            'noprogress': True,
            'quiet': True,
            'no_warnings': True,
            'cookiefile': cookie_path
        }

        self.use_db = skip_downloaded

        self.info_path = '.muzlib'
        self.tmp_path = files_utils.get_tmp_folder()

        self.library_path = library_path
        self.db_path = "db.json"
        self.artists_rename_path = "artists_rename.json"
        self._backup_path_prefix = "muzlib_backup_"
        self.missing_path = "missing.json"

        self._init_library()

        self.db = {}
        self.__load_db()

        self.ytmusic = YTMusic()
        self.ydl = yt_dlp.YoutubeDL(self.ydl_opts)

        
    
    def _init_library(self):

        # Ensure the path ends with a slash (optional)
        self.library_path = os.path.join(self.library_path, '')

        # Create the directory
        try:
            os.makedirs(self.library_path, exist_ok=True)
            logging_utils.logging.debug(f"Folders created successfully at: {self.library_path}")
        except Exception as e:
            logging_utils.logging.error(f"Error creating folders: {e}")

        self.ydl_opts['outtmpl'] = os.path.join(self.tmp_path, self.ydl_opts['outtmpl'])

        # Database path
        self.info_path = os.path.join(self.library_path, self.info_path)
        os.makedirs(self.info_path, exist_ok=True)
        self.db_path = os.path.join(self.info_path, self.db_path)

        # Artists_rename
        self.artists_rename_path = os.path.join(self.info_path, self.artists_rename_path)
        if not os.path.exists(self.artists_rename_path):
            with open(self.artists_rename_path, "w", encoding="utf-8") as file:
                json.dump({}, file, indent=4, ensure_ascii=False)
            self.artists_rename = {}
        else:
            with open(self.artists_rename_path, "r", encoding="utf-8") as file:
                self.artists_rename = json.load(file)

        
    def _artist_rename(self, artist_name):
        if artist_name in self.artists_rename: return self.artists_rename[artist_name]
        return artist_name
    
    def _get_album_metadata(self, ytm_album_id, single_id=None, single_name=None):

        album_details = self.ytmusic.get_album(ytm_album_id)
        for track in album_details['tracks']:
            track_info = _init_track_info()
            track_info['ytm_id'] = track['videoId']
            track_info['track_name'] = _trackname_remove_unnecessary(track['title'])

            # Single downloading
            if not single_name is None and not single_id is None and len(album_details['tracks']) > 1:
                if not track['title'] in single_name and track_info['ytm_id'] != single_id:
                    continue
                # TODO: add handling video clips + downloading songs from albums that have video clips as tracks
                # if track['title'] != single_name and track_info['ytm_id'] != single_id:
                #     continue

            track_info['track_artists'] = [self._artist_rename(artist['name']) for artist in track['artists']] + _get_feat_artists(track['title'])
            track_info['track_artists_str'] = ", ".join(track_info['track_artists'])
            track_info['release_date'] = album_details['year'] if 'year' in album_details else ''

            # TODO: Set album and track number in singles too
            if album_details['trackCount'] > 1:
                track_info['album_name'] = _trackname_remove_unnecessary(album_details['title'])
                track_info['track_number'] = track['trackNumber']
                track_info['total_tracks'] = album_details['trackCount']

            track_info['album_artists'] = [self._artist_rename(artist['name']) for artist in album_details['artists']] + _get_feat_artists(track_info['album_name'])
            track_info['lyrics'] = lyrics_utils.get_lyrics(track_info['track_name'], track_info['track_artists_str'], ytmusic=self.ytmusic, id=track_info['ytm_id'])
            track_info['cover'] = _get_image(album_details['thumbnails'][-1]['url'])
            track_info['ytm_title'] = f"{track_info['track_artists_str']} - {track['title']}"

            yield track_info

    def search(self, search_type: SearchType, *, artist_name="", album_name="", song_name=""):
        
        search_query = ""
        if search_type == SearchType.ARTIST:
            search_query = artist_name
        elif search_type == SearchType.ALBUM:
            search_query = f"{artist_name} – {album_name}"
        elif search_type == SearchType.SONG:
            search_query = f"{artist_name} – {song_name}"

        return self.ytmusic.search(search_query, filter=search_type.value, limit=20)

    def go_though_search_results(self, search_results, search_type: SearchType):
        for result in search_results:
            if search_type == SearchType.ARTIST:
                result['title'] = result['artist']
            elif search_type == SearchType.ALBUM:
                album_artists = [artist['name'] for artist in result['artists']]
                album_artists_str = ", ".join(album_artists)
                result['title'] = album_artists_str + " - " + result['title']
            elif search_type == SearchType.SONG:
                song_artists = [artist['name'] for artist in result['artists']]
                song_artists_str = ", ".join(song_artists)
                result['title'] = song_artists_str + " - " + result['title']
            else:
                logging_utils.logging.error(f"Invalid search type: {search_type}")
                print(f"Invalid search type: {search_type}")
                return None
            
            yield result
    
    def get_download_summary(self, search_result, search_type: SearchType):
        track_count = 0

        if search_type == SearchType.ARTIST:
            artist_details = self.ytmusic.get_artist(search_result['browseId'])
            for album_type in ["albums", "singles"]:
                if not album_type in artist_details: continue

                albums = artist_details[album_type]['results']

                if artist_details[album_type]['browseId']:
                    albums = self.ytmusic.get_artist_albums(artist_details[album_type]['browseId'], params=None, limit=None)
            
                for album in albums:
                    album_details = self.ytmusic.get_album(album['browseId'])
                    track_count += album_details['trackCount'] 
                    
        elif search_type == SearchType.ALBUM:
            album_details = self.ytmusic.get_album(search_result['browseId'])
            track_count = album_details['trackCount']   
        elif search_type == SearchType.SONG:
            track_count = 1

        return track_count
    

    def get_track_info(self, search_result, search_type: SearchType):
        if search_type == SearchType.ARTIST:
            yield from self._get_discography_by_artist_id(search_result['browseId'])
        elif search_type == SearchType.ALBUM:
            yield from self._get_album_metadata(search_result['browseId'])
        elif search_type == SearchType.SONG:
            yield from self._get_album_metadata(search_result['album']['id'], single_id=search_result['videoId'], single_name=search_result['title'])
        else:
            logging_utils.logging.error(f"Invalid search type: {search_type}")
            print(f"Invalid search type: {search_type}")

    def _get_discography_by_artist_id(self,artist_id):
        
        artist_details = self.ytmusic.get_artist(artist_id)

        for type in ["albums", "singles"]:
            if not type in artist_details: continue

            albums = artist_details[type]['results']

            if artist_details[type]['browseId']:
                albums = self.ytmusic.get_artist_albums(artist_details[type]['browseId'], params=None, limit=None)
            
            for album in albums:
                yield from self._get_album_metadata(album['browseId'])


    def backup_library(self):
        track_metadata = []
        audio_files = files_utils.find_audio_files(self.library_path)
        for audio_path in audio_files:
            track_info = tag_utils.get_tag(str(audio_path))

            audio_rpath = os.path.relpath(str(audio_path), start=self.library_path)
            name, ext = os.path.splitext(audio_rpath)
            track_info['path'] = name

            track_metadata.append(track_info)
        

        formatted_timestamp = time.strftime('%Y%m%d%H%M%S', time.localtime())
        backup_path = os.path.join(self.info_path, f'{self._backup_path_prefix}{formatted_timestamp}.json')

        with open(backup_path, "w", encoding="utf-8") as file:
            json.dump(track_metadata, file, indent=4, ensure_ascii=False)
        
        return backup_path
            
    def restore_library(self, backup_filepath):
        if not os.path.exists(backup_filepath):
            print(f"File {backup_filepath} doesn't exist.")
            return
        if not os.path.isfile(backup_filepath):
            print(f"File {backup_filepath} is directory.")
            return
        
        track_metadata = []
        with open(backup_filepath, "r", encoding="utf-8") as file:
            track_metadata = json.load(file)
        
        for track_info in track_metadata:
            self.download_by_track_info(track_info)   

    def download_by_track_info(self, track_info):
        try:
            id = track_info.get('ytm_id','')
            if not id: return

            if self.use_db and id in self.db: return

            self.__download_track_youtube(id)
            
            file_path = os.path.join(self.tmp_path, f"{id}{self.extension}")

            # Add tag to the track
            tag_utils.add_tag(file_path,track_info)

            # Rename and move track
            new_path = self.__move_downloaded_track(id, track_info)
            
            # Save database
            self.db[id] = track_info['track_artists_str'] + " - " + track_info['track_name']
            self.__write_db()

            return new_path
        except Exception as e:
            missing_path = os.path.join(self.library_path, self.missing_path)

            if os.path.exists(missing_path):
                with open(missing_path, "r", encoding="utf-8") as file:
                    missing_track_metadata = json.load(file)
                missing_track_metadata.append(track_info)
            else:
                missing_track_metadata = [track_info]
            
            json.dump(missing_track_metadata, open(missing_path, "w", encoding="utf-8"), indent=4, ensure_ascii=False)
            logging_utils.logging.error(f"Error downloading track {track_info.get('track_name','Unknown')} with id {track_info.get('ytm_id','Unknown')}: {e}")
            print(f"Error downloading track {track_info.get('track_name','Unknown')} with id {track_info.get('ytm_id','Unknown')}: {e}")            

    def __move_downloaded_track(self, id, track_info):
        file_path = os.path.join(self.tmp_path, f"{id}{self.extension}")

        # Specify filename
        new_filename = _sanitize_filename(track_info['track_artists_str'] + " - " + track_info['track_name'])
        if track_info['track_number']:
            new_filename = f"{track_info['track_number']}. {new_filename}"

        artist_dir = _sanitize_filename(track_info['track_artists'][0])

        album_dir = ''
        if track_info['total_tracks']:
            album_dir = _sanitize_filename(f"[{track_info['release_date']}] {track_info['album_name']}")

        # Join path components
        new_path = os.path.join(artist_dir, album_dir, new_filename)

        # If file exists
        if os.path.exists(os.path.join(self.library_path,new_path + self.extension)):
            new_path = os.path.join("DUPLICATE", new_path)

        # If there is specified path in track_info
        if 'path' in track_info:
            new_path = os.path.normpath(track_info['path'])

        new_path = os.path.join(self.library_path, new_path + self.extension)

        os.makedirs(os.path.dirname(new_path), exist_ok=True)
        shutil.move(file_path, new_path)

        return new_path


    def __download_track_youtube(self,track_id):
        # Construct the URL for YouTube Music
        track_url = f"https://music.youtube.com/watch?v={track_id}"

        # Download using yt-dlp
        self.ydl.download([track_url])
    
    def __write_db(self):
        # write database to the db.json file
        with open(self.db_path, "w", encoding="utf-8") as file:
            json.dump(self.db, file, indent=4, ensure_ascii=False)

    def __load_db(self):
        # fetch database from db.json file
        if not os.path.exists(self.db_path) or not os.path.isfile(self.db_path):
            self.__write_db()

        with open(self.db_path, "r", encoding="utf-8") as file:
            self.db = json.load(file)

def main():
    from rich.console import Console
    from rich.panel import Panel
    from rich.prompt import Prompt
    from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, ProgressColumn
    from rich.text import Text
    import questionary

    parser = argparse.ArgumentParser(description="Muzlib Downloader")
    parser.add_argument("-l", "--library_path", type=str, default="", 
        help="Root directory to save downloaded music. Defaults to your OS standard Music folder.")
    parser.add_argument("-d", "--download_type", type=str, choices=['album', 'artist', 'song'],
        help="Scope of the download: 'artist' (full discography), 'album' (specific release), or 'song' (single track).")
    parser.add_argument("--artist", type=str, default="",
        help="Target artist's name. Highly recommended for all download types to ensure accurate search results.")
    parser.add_argument("--album", type=str, default="",
        help="Target album's title. Use alongside --artist when --download_type is 'album'.")
    parser.add_argument("--song", type=str, default="",
        help="Target song's title. Use alongside --artist when --download_type is 'song'.")
    parser.add_argument("--non_interactive", action="store_true",
        help="Bypass all user prompts and automatically download the top search result. Requires --download_type to be set.")
    args = parser.parse_args()

    if args.non_interactive and not args.download_type:
        print("Error: --non_interactive flag requires at least --download_type to be specified.")
        exit(1)


    console = Console()

    console.print(Panel.fit("[bold cyan]🎵 Muzlib Downloader[/bold cyan]", border_style="cyan"))

    # Path input with validation
    default_music_dir = str(files_utils.get_default_music_directory())
    if not args.library_path and not args.non_interactive:
        while True:
            library_path = Prompt.ask("[green]Music library path[/green]", default=default_music_dir)
            if library_path.strip():
                break
            console.print("[red]Path cannot be empty.[/red]")
    else:
        library_path = args.library_path if args.library_path else default_music_dir

    # Try to init Muzlib
    try:
        ml = Muzlib(library_path.strip())
    except Exception as e:
        console.print(Panel(f"[red]Could not open library:[/red] {e}", border_style="red"))
        return

    # Interactive menu instead of free-text input
    if not args.download_type:
        search_type = questionary.select(
            "What do you want to download?",
            choices=[
                questionary.Choice("Complete discography", value=SearchType.ARTIST),
                questionary.Choice("Specific album",       value=SearchType.ALBUM),
                questionary.Choice("Specific song",       value=SearchType.SONG),
            ]
        ).ask()

        # If user pressed Ctrl+C
        if search_type is None:
            console.print("[yellow]Cancelled.[/yellow]")
            return
    else:
        search_type = SearchType(f"{args.download_type}s")

    artist_name, album_name, song_name = args.artist, args.album, args.song

    # Ask for artist name in all cases, and album/track name if needed
    if not args.non_interactive:
        if search_type in {SearchType.ARTIST, SearchType.ALBUM, SearchType.SONG} and not artist_name:
            artist_name = Prompt.ask("[green]Artist name[/green]")
        if search_type == SearchType.ALBUM and not album_name:
            album_name = Prompt.ask("[green]Album name[/green]")
        if search_type == SearchType.SONG and not song_name:
            song_name = Prompt.ask("[green]Track name[/green]")
    
    # Post-process inputs
    artist_name = artist_name.strip()
    album_name = album_name.strip()
    song_name = song_name.strip()

        
    search_results = ml.search(search_type, artist_name=artist_name, album_name=album_name, song_name=song_name)

    selected_result = None
    for selected_result in ml.go_though_search_results(search_results, search_type):
        if args.non_interactive:
            break
        if questionary.confirm(f"Is this the {search_type.name.lower()} you searched for?\n  {selected_result['title']}").ask():
            break

    with console.status(f"[cyan]Retrieving information…[/cyan]"):
        download_summary = ml.get_download_summary(selected_result, search_type)

    class TimeColumn(ProgressColumn):
        def render(self, task):
            elapsed = task.finished_time if task.finished else task.elapsed
            remaining = task.time_remaining

            elapsed_str = f"{int(elapsed // 3600):01}:{int((elapsed % 3600) // 60):02}:{int(elapsed % 60):02}" if elapsed else "0:00:00"
            remaining_str = f"{int(remaining // 3600):01}:{int((remaining % 3600) // 60):02}:{int(remaining % 60):02}" if remaining else "?"

            return Text(f"[{elapsed_str}<{remaining_str}]", style="green")

    with Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]{task.description}"),
        BarColumn(),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        TextColumn("[cyan][{task.completed}/{task.total}]"),
        TimeColumn(),
        TextColumn("[dim][{task.fields[track_name]}]"),
    ) as progress:
        task = progress.add_task("Downloading...", total=download_summary, track_name="")

        common_path = None
        for track_info in ml.get_track_info(selected_result, search_type):
            song_name = f"{track_info['track_artists_str']} - {track_info['track_name']}"
            progress.update(task, track_name=song_name)

            song_path_str = ml.download_by_track_info(track_info)

            song_path = pathlib.Path(song_path_str)
            song_uri = pathlib.Path(song_path).as_uri()
            progress.print(f"[green]Downloaded:[/green] [link={song_uri}]{song_name}[/link]")
            
            progress.update(task, advance=1, track_name="")

            if common_path is None:
                common_path = str(song_path.parent)
            else:
                common_path = os.path.commonpath([common_path, str(song_path.parent)])


        progress.update(task, track_name="Done!")

    common_uri = pathlib.Path(common_path).as_uri()
    console.print(f"Files are stored at [magenta][link={common_uri}]{common_path}[/link][/magenta]", highlight=False)
    console.print(f"[green]✓ Done![/green]")

if __name__ == "__main__":
    main()
