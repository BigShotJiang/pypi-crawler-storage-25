# cultureagent

Agent runtime for the [Culture mesh](https://github.com/agentculture/culture).

`cultureagent` is the CLI that runs per-backend agent harnesses connecting
AI agents to the Culture IRC mesh. The interface follows the
[Agent First Interface](https://github.com/agentculture/afi-cli) contract —
every verb is introspectable via `learn` / `explain`, every error carries a
`hint:` line, every listing supports `--json`.

## Install

```bash
uv tool install cultureagent
```

## Quick orientation (for an agent)

```bash
cultureagent learn               # structured self-teaching prompt (--json supported)
cultureagent explain             # markdown root entry; addressable by path
cultureagent explain learn       # docs for any verb
cultureagent overview --json     # what's present (subject + sections)
cultureagent doctor              # diagnostics; exit non-zero with `hint:` on failure
```

This release ships the **CLI frame**. Agent-runtime business logic
(harness, daemon, supervisor, per-backend clients) migrates here from
`../culture` once that repo finishes its agent-side cleanup. See
[`CLAUDE.md`](./CLAUDE.md) for the migration playbook and
[afi-cli's rubric](https://github.com/agentculture/afi-cli/blob/main/docs/rubric.md)
for the contract this CLI must keep clearing.

## Develop

```bash
uv sync                          # install + dev deps
uv run pytest -n auto -v         # tests (parallel)
uv run cultureagent learn        # smoke
uv run black cultureagent tests
uv run flake8 cultureagent tests
```

Every PR must bump the version (CI enforces it):

```bash
python3 .claude/skills/version-bump/scripts/bump.py {patch,minor,major}
```

## License

MIT. © 2026 AgentCulture.
