"""Acceptance gate: run ``afi cli doctor .`` against this repo.

The afi-cli rubric is the canonical AFI compliance check. We invoke it as
a subprocess so cultureagent doesn't carry afi-cli as a hard dependency.
The gate is **skipped** when ``afi`` isn't on PATH so CI still passes in
minimal environments — install afi-cli locally (``uv tool install afi-cli``)
to enforce the rubric before opening a PR.
"""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent


def _afi_available() -> bool:
    return shutil.which("afi") is not None


def _afi_rubric_verb() -> str | None:
    """Pick the rubric verb the installed afi knows.

    Newer afi exposes ``afi cli doctor`` (with ``verify`` as deprecated alias).
    Older afi (≤0.4.x) only has ``afi cli verify``. Detect by inspecting
    ``afi cli --help`` output so the test is forward- and backward-compatible.
    """
    if not _afi_available():
        return None
    help_out = subprocess.run(  # noqa: S603  # controlled args, no shell
        ["afi", "cli", "--help"],
        capture_output=True,
        text=True,
        check=False,
    ).stdout
    if "doctor" in help_out:
        return "doctor"
    if "verify" in help_out:
        return "verify"
    return None


@pytest.mark.skipif(
    _afi_rubric_verb() is None,
    reason="afi-cli not installed or has no rubric verb; run `uv tool install afi-cli`",
)
def test_afi_cli_rubric_passes_all_bundles() -> None:
    # `afi cli {doctor,verify}` is the canonical rubric runner. It exits
    # non-zero on any bundle failure and prints structured remediation.
    verb = _afi_rubric_verb()
    assert verb is not None  # narrowed by the skipif guard
    result = subprocess.run(  # noqa: S603  # controlled args, no shell
        ["afi", "cli", verb, str(REPO_ROOT)],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        msg = (
            f"afi cli {verb} failed against the repo:\n"
            f"--- stdout ---\n{result.stdout}\n"
            f"--- stderr ---\n{result.stderr}"
        )
        pytest.fail(msg)
