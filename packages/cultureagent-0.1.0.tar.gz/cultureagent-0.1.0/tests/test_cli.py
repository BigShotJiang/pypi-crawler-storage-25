"""Smoke tests for cultureagent's CLI (afi-cli rubric coverage)."""

from __future__ import annotations

import json

import pytest

from cultureagent import __version__
from cultureagent.cli import main


def test_version_flag(capsys: pytest.CaptureFixture[str]) -> None:
    with pytest.raises(SystemExit) as exc:
        main(["--version"])
    assert exc.value.code == 0
    assert __version__ in capsys.readouterr().out


def test_no_args_prints_help(capsys: pytest.CaptureFixture[str]) -> None:
    rc = main([])
    assert rc == 0
    out = capsys.readouterr().out
    assert "cultureagent" in out
    assert "learn" in out


# ── Bundle 2: learnability ────────────────────────────────────────────


def test_learn_text_meets_rubric(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["learn"]) == 0
    out = capsys.readouterr().out
    assert len(out) >= 200
    for marker in ["purpose", "commands", "exit", "--json", "explain"]:
        assert marker.lower() in out.lower(), f"learn output missing marker: {marker}"


# ── Bundle 3: json (machine readability) ──────────────────────────────


def test_learn_json_parseable(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["learn", "--json"]) == 0
    captured = capsys.readouterr()
    assert captured.err == ""
    payload = json.loads(captured.out)
    assert payload["tool"] == "cultureagent"
    assert payload["version"] == __version__
    assert "0" in payload["exit_codes"]


def test_explain_json_parseable(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["explain", "--json", "learn"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["path"] == ["learn"]
    assert payload["markdown"].startswith("#")


# ── Bundle 4: errors (propagation) ────────────────────────────────────


def test_unknown_verb_exits_non_zero_with_hint(capsys: pytest.CaptureFixture[str]) -> None:
    with pytest.raises(SystemExit) as exc:
        main(["zzz-not-a-real-verb"])
    assert exc.value.code != 0
    err = capsys.readouterr().err
    assert "error:" in err
    assert "hint:" in err
    assert "Traceback" not in err


def test_explain_unknown_path_fails_with_hint(
    capsys: pytest.CaptureFixture[str],
) -> None:
    rc = main(["explain", "zzz-not-a-real-noun"])
    assert rc != 0
    err = capsys.readouterr().err
    assert "error:" in err
    assert "hint:" in err
    assert "Traceback" not in err


# ── Bundle 5: explain (addressable docs) ──────────────────────────────


def test_explain_root_no_args(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["explain"]) == 0
    out = capsys.readouterr().out
    assert out.startswith("#")
    assert "cultureagent" in out


def test_explain_self(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["explain", "cultureagent"]) == 0
    assert capsys.readouterr().out.startswith("#")


# ── Bundle 6: overview ────────────────────────────────────────────────


def test_overview_text(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["overview"]) == 0
    out = capsys.readouterr().out
    assert "globals" in out
    assert "nouns" in out


def test_overview_json_stable_keys(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["overview", "--json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["subject"] == "cultureagent"
    assert isinstance(payload["sections"], list)


def test_overview_unknown_path_falls_back_gracefully(
    capsys: pytest.CaptureFixture[str],
) -> None:
    # Bundle 6: descriptive verbs warn but don't hard-fail on unknown paths.
    rc = main(["overview", "zzz-bogus"])
    assert rc == 0
    captured = capsys.readouterr()
    assert "warning:" in captured.err
    assert "globals" in captured.out


# ── Bundle 7: doctor ──────────────────────────────────────────────────


def test_doctor_exits_zero_with_hint(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["doctor"]) == 0
    captured = capsys.readouterr()
    assert "no checks" in captured.out.lower()
    assert "hint:" in captured.err
    assert "Traceback" not in captured.err


def test_doctor_json_parseable(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["doctor", "--json"]) == 0
    captured = capsys.readouterr()
    payload = json.loads(captured.out)
    assert payload["subject"] == "cultureagent"
    assert "checks" in payload
    # ``hint:`` still goes to stderr in JSON mode (it's a diagnostic, not a result).
    assert "hint:" in captured.err
