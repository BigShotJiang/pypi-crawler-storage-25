# Changelog

All notable changes to this project will be documented in this file.

Format follows [Keep a Changelog](https://keepachangelog.com/). This project
adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-05-09

### Added

- `cultureagent` Python package shape with `[project.scripts]` entry point
  (`uv tool install cultureagent` once published). Version read from package
  metadata via `importlib.metadata`.
- Agent First CLI frame satisfying the [afi-cli](https://github.com/agentculture/afi-cli)
  rubric: `learn`, `learn --json`, `explain [<path>]`, `explain --json`,
  `overview`, `overview --json`, `doctor`. Exit-code policy
  (`0` success / `1` user error / `2` env error), `hint:` remediation
  markers on stderr, no traceback leaks.
- `CultureagentError` dataclass + `_dispatch` wrapper that route every
  failure path through `cli/_output.py`'s structured emit helpers.
- Explain catalog (`cultureagent/explain/catalog.py`) with one entry per
  global verb and a root entry. Future noun groups extend the catalog
  alongside their `_commands/` registration.
- `.github/workflows/tests.yml` — pytest+coverage, lint
  (black/isort/flake8/bandit/markdownlint-cli2), and a PR-only
  `version-check` job that fails when `pyproject.toml`'s version
  matches `main`.
- `.github/workflows/publish.yml` — Trusted Publishing to PyPI on push to
  main and `cultureagent==<version>.dev<run_number>` to TestPyPI on PRs.
  Fork PRs skip the publish step (no OIDC context).
- `.claude/skills/version-bump/` — vendored verbatim from `../steward`.
  Run `python3 .claude/skills/version-bump/scripts/bump.py {patch,minor,major}`
  before opening a PR.
- `.flake8`, `.markdownlint-cli2.yaml`, `[tool.{black,isort,bandit,coverage}]`
  — lint/format conventions copied from `../steward` to keep AgentCulture
  siblings aligned.
- `tests/test_cli.py` — smoke tests for every verb plus an unknown-path
  failure mode.
- `tests/test_self_doctor.py` — acceptance gate that runs `afi cli doctor .`
  in-process when `afi-cli` is available; skipped otherwise so CI without
  `afi-cli` still passes.
- `docs/architecture.md` — outside-in architecture reference: today's
  CLI frame, tomorrow's agent-runtime migration from `../culture`, and
  how cultureagent relates to its sibling repos (culture, afi-cli,
  steward).

### Fixed

- `tests/test_self_doctor.py` — switched `# noqa: S603 — text` to the
  two-hash form (`# noqa: S603  # text`) so SonarPython's S7632
  suppression-syntax check stops flagging it.

### Changed

- `README.md` — extends the one-line stub into an agent-oriented
  orientation paragraph (install, `learn`, pointer to `CLAUDE.md`).
- `CLAUDE.md` — flips the bootstrap rows in the command table to "works"
  and points at the migration playbook for the next PR.
