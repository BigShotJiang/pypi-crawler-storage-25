# Architecture

This document captures the moving parts of `cultureagent` and how they
relate to its sibling repos. It is the project-side counterpart to
[`CLAUDE.md`](../CLAUDE.md): `CLAUDE.md` is for an agent operating *in*
this repo; this file is for a reader trying to understand the system
from the outside.

## Today: a CLI frame

The current release ships only the **Agent First CLI frame** —
`cultureagent/cli/` plus the `cultureagent/explain/` catalog. There is
no business logic yet. Every verb is wired and rubric-compliant, but
the bodies report "no nouns yet" / "no checks wired up yet". The frame
is here so the agent-runtime migration from
[`agentculture/culture`](https://github.com/agentculture/culture) drops
into a working repo shape rather than greenfield.

```text
cultureagent/                 ← this repo
├── cultureagent/             # Python package (PyPI: cultureagent)
│   ├── cli/                  # afi-cli cite-template shape
│   │   ├── __init__.py       # _ArgumentParser, _dispatch, main
│   │   ├── _errors.py        # CultureagentError, exit-code policy
│   │   ├── _output.py        # emit_result / emit_error / emit_diagnostic
│   │   └── _commands/        # one module per verb / noun group
│   └── explain/              # markdown catalog backing `cultureagent explain`
└── tests/                    # smoke tests + AFI rubric acceptance gate
```

## Tomorrow: agent-runtime migration from culture

Two trees migrate from `../culture` once that repo finishes its
agent-side cleanup:

- **`packages/agent-harness/`** — the citation-pattern reference
  implementation. Generic; copied into per-backend directories below.
  Spec lives at `../culture/docs/reference/architecture/agent-harness-spec.md`
  (will move here as part of the migration).
- **`cultureagent/clients/{claude,codex,copilot,acp}/`** — per-backend
  working copies of `agent_runner.py`, `supervisor.py`, `daemon.py`
  and the supporting modules (config, IRC transport, telemetry, IPC,
  webhook, attention, message buffer, socket server, and the `skill/`
  IPC client).

The cite-don't-import seam stays intact: improvements to a generic
component go back into `packages/agent-harness/` so the next backend
starts from the latest version.

## How cultureagent relates to its siblings

| Sibling | Role | Where it lives |
|---|---|---|
| **culture** | IRC mesh server (AgentIRC) and the operator CLI (`culture`). Source of the agent-runtime code being migrated to this repo. | <https://github.com/agentculture/culture> |
| **afi-cli** | Defines the Agent First Interface contract. `afi cli doctor` (or `verify` on ≤0.4.x) is the rubric runner that gates this CLI. | <https://github.com/agentculture/afi-cli> |
| **steward** | Alignment hub for AgentCulture skills. The vendored `cicd` and `version-bump` skills under `.claude/skills/` were copied from steward's canonical copies. | <https://github.com/agentculture/steward> |

## Agent First contract this CLI must keep clearing

The CLI surface follows afi-cli's rubric. See
[`../afi-cli/docs/rubric.md`](https://github.com/agentculture/afi-cli/blob/main/docs/rubric.md)
for the full bundle list; the short version:

- `cultureagent learn` and `cultureagent learn --json` — single
  structured self-description an agent reads in one shot.
- `cultureagent explain [<path>]` — addressable markdown docs for any
  noun/verb path; `explain --json` parses; `explain <bogus>` exits
  non-zero with a `hint:` line on stderr.
- `cultureagent overview` and `cultureagent overview --json` —
  descriptive map of what's present (different question from
  `doctor`'s "what's wrong"). Stable JSON keys: `subject`, `sections`.
- `cultureagent cli overview` — meta-noun mirror of the global, scoped
  to the CLI surface (`subject: "cultureagent.cli"`).
- `cultureagent doctor` — diagnostics with `hint:` remediation
  markers; no traceback leaks to stderr.
- Exit codes: `0` success, `1` user-input error, `2` environment
  error, `3+` reserved.
- stdout / stderr never mix on success — JSON goes to stdout,
  diagnostics to stderr.

`tests/test_self_doctor.py` runs `afi cli {doctor,verify} .` against
this repo as a subprocess and skips when `afi` isn't on PATH. Install
afi locally (`uv tool install afi-cli`) to enforce the rubric before
opening a PR.

## See also

- [`CLAUDE.md`](../CLAUDE.md) — operating instructions for an agent
  working in this repo (sibling assumptions, common commands,
  migration playbook, all-backends rule).
- [`README.md`](../README.md) — install + quick orientation.
- `cultureagent explain cultureagent` — runtime root entry of the
  explain catalog.
