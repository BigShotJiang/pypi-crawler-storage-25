#!/usr/bin/env bash
# Fetch ALL review threads for a PR via GraphQL with cursor pagination.
# Replaces inline `reviewThreads(first: 100)` calls that silently truncate
# on large PRs and bias the unresolved-thread tally workflow.sh await gates on.
#
# Usage:
#   _fetch-review-threads.sh PR_NUMBER 'NODE_FIELDS'
#
# NODE_FIELDS is the GraphQL selection set for each thread node, without the
# surrounding braces. Examples:
#   'id isResolved comments(first: 1) { nodes { author { login } } }'
#   'id comments(first: 100) { nodes { databaseId } }'
#   'id isResolved comments(first: 100) { nodes { databaseId } }'
#
# Env:
#   REPO   owner/repo (auto-detected via `gh repo view` when unset)
#
# Output: a single JSON array of all thread nodes on stdout.

set -euo pipefail

PR_NUMBER="${1:?Usage: _fetch-review-threads.sh PR_NUMBER 'NODE_FIELDS'}"
NODE_FIELDS="${2:?Missing NODE_FIELDS}"
REPO="${REPO:-$(gh repo view --json nameWithOwner -q .nameWithOwner)}"

OWNER="${REPO%%/*}"
NAME="${REPO##*/}"

ALL='[]'
CURSOR_ARG='null'

while :; do
    PAGE=$(gh api graphql -f query="
    {
      repository(owner: \"$OWNER\", name: \"$NAME\") {
        pullRequest(number: $PR_NUMBER) {
          reviewThreads(first: 100, after: $CURSOR_ARG) {
            nodes { $NODE_FIELDS }
            pageInfo { hasNextPage endCursor }
          }
        }
      }
    }")
    NODES=$(echo "$PAGE" | jq -c '.data.repository.pullRequest.reviewThreads.nodes')
    ALL=$(jq -cn --argjson a "$ALL" --argjson b "$NODES" '$a + $b')
    HAS_NEXT=$(echo "$PAGE" | jq -r '.data.repository.pullRequest.reviewThreads.pageInfo.hasNextPage')
    [ "$HAS_NEXT" = "true" ] || break
    END_CURSOR=$(echo "$PAGE" | jq -r '.data.repository.pullRequest.reviewThreads.pageInfo.endCursor')
    CURSOR_ARG="\"$END_CURSOR\""
done

echo "$ALL"
