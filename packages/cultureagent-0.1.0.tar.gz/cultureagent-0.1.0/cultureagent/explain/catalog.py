"""Markdown catalog for ``cultureagent explain <path>``.

Each entry is verbatim markdown. Keys are command-path tuples. The empty
tuple and ``("cultureagent",)`` both resolve to the root entry. Future
noun groups extend this dict alongside their ``_commands/`` registration.

Keep bodies self-contained: an agent reading one entry should get enough
context without chaining reads.
"""

from __future__ import annotations

_ROOT = """\
# cultureagent

cultureagent is the agent runtime for the [Culture mesh](https://github.com/agentculture/culture).
The CLI follows the [Agent First Interface](https://github.com/agentculture/afi-cli)
contract: every verb is introspectable via `learn` / `explain`, every error
carries a `hint:` line, and every listing supports `--json`.

This release ships only the CLI frame — agent-runtime business logic
migrates here from `../culture` once that repo finishes its agent-side
cleanup. Today, `overview` reports no nouns, `doctor` reports no checks.

## Verbs

- `cultureagent learn` — structured self-teaching prompt.
- `cultureagent explain <path>` — markdown docs for any noun/verb path.
- `cultureagent overview` — descriptive map of CLI surface (subject + sections).
- `cultureagent doctor` — diagnostics with hint markers.

## Exit-code policy

- `0` success
- `1` user-input error (bad flag, bad path, missing arg)
- `2` environment / setup error
- `3+` reserved

## See also

- `cultureagent explain learn`
- `cultureagent explain explain`
- `cultureagent explain overview`
- `cultureagent explain doctor`
"""

_LEARN = """\
# cultureagent learn

Prints a structured self-teaching prompt covering cultureagent's purpose,
command map, exit-code policy, `--json` support, and `explain` pointer.

## Usage

    cultureagent learn
    cultureagent learn --json

The text output is at least 200 characters and mentions every marker the
agent-first rubric requires (purpose, commands, exit, --json, explain).
The JSON payload is a stable shape: `{tool, version, purpose, commands,
exit_codes, json_support, explain_pointer}`.
"""

_EXPLAIN = """\
# cultureagent explain <path>

Prints markdown documentation for any noun/verb path. Unlike `--help`
(terse, positional), `explain` is global and addressable by path.

## Usage

    cultureagent explain                    # root entry
    cultureagent explain cultureagent       # also the root entry
    cultureagent explain learn
    cultureagent explain --json explain

Unknown paths exit non-zero and emit a `hint:` line on stderr pointing at
`cultureagent explain cultureagent` for the list of valid paths.
"""

_OVERVIEW = """\
# cultureagent overview

Descriptive map of what's present in the CLI. Distinct from `doctor`:
`overview` answers "what is here", `doctor` answers "what is wrong".

## Usage

    cultureagent overview
    cultureagent overview --json

JSON shape (stable keys per the agent-first rubric): `{subject, version,
sections}`. `sections` is a list of `{name, items[, note]}` blocks.
Today there are two sections — `globals` (the four CLI verbs) and `nouns`
(empty until agent-runtime nouns land).

Unknown paths warn on stderr and return the root overview rather than
hard-failing — descriptive verbs are not diagnostic.
"""

_DOCTOR = """\
# cultureagent doctor

Runs diagnostics about the cultureagent install. Today the frame has no
checks wired up; the verb still exits cleanly and emits a `hint:` line
on stderr pointing at the migration playbook in `CLAUDE.md`.

## Usage

    cultureagent doctor
    cultureagent doctor --json

When real checks land (config loaded, agent SDK installed, IRC mesh
reachable, …), the JSON payload's `checks` list will populate with
`{name, status, detail}` entries and an aggregate `summary` line.
"""


ENTRIES: dict[tuple[str, ...], str] = {
    (): _ROOT,
    ("cultureagent",): _ROOT,
    ("learn",): _LEARN,
    ("explain",): _EXPLAIN,
    ("overview",): _OVERVIEW,
    ("doctor",): _DOCTOR,
}
