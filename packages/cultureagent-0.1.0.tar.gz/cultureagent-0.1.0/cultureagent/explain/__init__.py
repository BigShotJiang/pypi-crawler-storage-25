"""Explain catalog resolver.

``cultureagent explain <path>`` resolves the path tuple against
:data:`cultureagent.explain.catalog.ENTRIES` and returns the matching
markdown body, or raises a :class:`CultureagentError` with a remediation
hint when no entry matches.
"""

from __future__ import annotations

from cultureagent.cli._errors import EXIT_USER_ERROR, CultureagentError
from cultureagent.explain.catalog import ENTRIES


def resolve(path: tuple[str, ...]) -> str:
    if path in ENTRIES:
        return ENTRIES[path]
    display = " ".join(path) if path else "<root>"
    raise CultureagentError(
        code=EXIT_USER_ERROR,
        message=f"no explain entry for: {display}",
        remediation="list known entries with: cultureagent explain cultureagent",
    )


def known_paths() -> list[tuple[str, ...]]:
    return list(ENTRIES.keys())
