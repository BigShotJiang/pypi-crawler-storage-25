"""Unified CLI entry point for cultureagent.

Noun-based command groups and globals are registered here. Top-level globals
(``learn``, ``explain``, ``overview``, ``doctor``) live under
:mod:`cultureagent.cli._commands`; per-noun groups will follow the same
pattern as agent-runtime logic migrates from ``../culture``.

Error-propagation contract: every handler raises
:class:`cultureagent.cli._errors.CultureagentError` on failure; :func:`main`
catches it via :func:`_dispatch` and routes through
:mod:`cultureagent.cli._output`. Unknown exceptions are wrapped so no Python
traceback leaks.
"""

from __future__ import annotations

import argparse
import sys

from cultureagent import __version__
from cultureagent.cli._errors import EXIT_USER_ERROR, CultureagentError
from cultureagent.cli._output import emit_error


class _ArgumentParser(argparse.ArgumentParser):
    """ArgumentParser that emits errors via cultureagent's structured format."""

    def error(self, message: str) -> None:  # type: ignore[override]
        err = CultureagentError(
            code=EXIT_USER_ERROR,
            message=message,
            remediation=f"run '{self.prog} --help' to see valid arguments",
        )
        emit_error(err, json_mode=False)
        raise SystemExit(err.code)


def _build_parser() -> argparse.ArgumentParser:
    # Deferred imports keep the parser module decoupled from command modules
    # at import time. When noun groups land (agent-runtime migration), import
    # them here next to the globals.
    from cultureagent.cli._commands import cli_noun as _cli_noun
    from cultureagent.cli._commands import doctor as _doctor_cmd
    from cultureagent.cli._commands import explain as _explain_cmd
    from cultureagent.cli._commands import learn as _learn_cmd
    from cultureagent.cli._commands import overview as _overview_cmd

    parser = _ArgumentParser(
        prog="cultureagent",
        description="cultureagent — agent runtime for the Culture mesh.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    sub = parser.add_subparsers(dest="command", parser_class=_ArgumentParser)

    _learn_cmd.register(sub)
    _explain_cmd.register(sub)
    _overview_cmd.register(sub)
    _doctor_cmd.register(sub)
    _cli_noun.register(sub)

    return parser


def _dispatch(args: argparse.Namespace) -> int:
    json_mode = bool(getattr(args, "json", False))
    try:
        rc = args.func(args)
    except CultureagentError as err:
        emit_error(err, json_mode=json_mode)
        return err.code
    except Exception as err:  # noqa: BLE001 - last-resort: wrap so no traceback leaks
        wrapped = CultureagentError(
            code=EXIT_USER_ERROR,
            message=f"unexpected: {err.__class__.__name__}: {err}",
            remediation="file a bug at https://github.com/agentculture/cultureagent/issues",
        )
        emit_error(wrapped, json_mode=json_mode)
        return wrapped.code
    return rc if rc is not None else 0


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    if args.command is None:
        parser.print_help()
        return 0
    return _dispatch(args)


if __name__ == "__main__":
    sys.exit(main())
