"""CultureagentError and exit-code policy.

Every failure inside cultureagent raises :class:`CultureagentError`. The
top-level ``main()`` catches it, formats via :mod:`cultureagent.cli._output`,
and exits with :attr:`CultureagentError.code`. This guarantees:

* no Python traceback leaks to stderr;
* every error has a structured shape ``{code, message, remediation}``;
* the exit-code policy is centralised in one place.
"""

from __future__ import annotations

from dataclasses import dataclass

# Exit-code policy (documented in ``cultureagent learn`` output).
# 0  = success
# 1  = user-input error (bad flag, bad path, missing arg)
# 2  = environment / setup error
# 3+ = reserved
EXIT_SUCCESS = 0
EXIT_USER_ERROR = 1
EXIT_ENV_ERROR = 2


@dataclass
class CultureagentError(Exception):
    """Structured error raised within cultureagent; carries a remediation hint."""

    code: int
    message: str
    remediation: str = ""

    def __post_init__(self) -> None:
        super().__init__(self.message)

    def to_dict(self) -> dict[str, object]:
        return {
            "code": self.code,
            "message": self.message,
            "remediation": self.remediation,
        }
