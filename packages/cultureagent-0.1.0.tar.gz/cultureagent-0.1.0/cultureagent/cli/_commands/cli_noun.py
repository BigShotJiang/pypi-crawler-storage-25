"""``cultureagent cli`` — meta noun for CLI-surface introspection.

The agent-first rubric requires that every noun with action-verbs also
expose an ``overview``. ``cli`` is the meta-noun whose only job is to
describe cultureagent's own CLI surface; it mirrors the global
``cultureagent overview`` but scopes the JSON ``subject`` to
``cultureagent.cli``. Real domain nouns (agent-runtime, harness, …)
will register here under their own modules as the migration from
``../culture`` lands.
"""

from __future__ import annotations

import argparse

from cultureagent.cli._commands.overview import _payload, _render_text
from cultureagent.cli._output import emit_diagnostic, emit_result


def _cli_payload(path: tuple[str, ...]) -> dict[str, object]:
    payload = _payload(path)
    payload["subject"] = "cultureagent.cli"
    return payload


def cmd_cli_overview(args: argparse.Namespace) -> int:
    path = tuple(args.path) if args.path else ()
    json_mode = bool(getattr(args, "json", False))
    payload = _cli_payload(path)
    if path and path[0] not in {"globals", "nouns", "learn", "explain", "overview", "doctor"}:
        emit_diagnostic(
            f"warning: no section matches path {' '.join(path)!r}; "
            "showing the cli overview instead."
        )
    if json_mode:
        emit_result(payload, json_mode=True)
    else:
        emit_result(_render_text(payload), json_mode=False)
    return 0


def register(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser(
        "cli",
        help="Meta-noun for CLI-surface introspection (verbs: overview).",
    )
    cli_sub = p.add_subparsers(dest="cli_command")
    overview = cli_sub.add_parser(
        "overview",
        help="Describe cultureagent's CLI surface (subject: 'cultureagent.cli').",
    )
    overview.add_argument(
        "path",
        nargs="*",
        help="Optional path; empty = root cli overview. Unknown paths warn and fall back.",
    )
    overview.add_argument("--json", action="store_true", help="Emit structured JSON.")
    overview.set_defaults(func=cmd_cli_overview)

    # If the user runs `cultureagent cli` with no verb, default to overview.
    p.set_defaults(func=cmd_cli_overview, path=[], json=False)
