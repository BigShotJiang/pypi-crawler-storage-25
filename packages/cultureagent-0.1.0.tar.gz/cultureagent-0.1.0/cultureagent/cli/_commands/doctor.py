"""``cultureagent doctor`` — diagnostics with remediation hints.

Today the frame has no business logic, so ``doctor`` reports an honest
"no checks wired up yet" with a ``hint:`` line pointing at the migration
playbook. Real diagnostics (config loaded, IRC reachable, agent SDK
installed, …) land alongside the agent-runtime migration from ``../culture``.
"""

from __future__ import annotations

import argparse

from cultureagent.cli._output import emit_diagnostic, emit_result


def cmd_doctor(args: argparse.Namespace) -> int:
    json_mode = bool(getattr(args, "json", False))
    payload: dict[str, object] = {
        "subject": "cultureagent",
        "checks": [],
        "summary": "no checks wired up yet — bootstrap frame",
    }
    if json_mode:
        emit_result(payload, json_mode=True)
    else:
        emit_result("diagnostics: no checks wired up yet — bootstrap frame.", json_mode=False)
    # ``hint:`` prefix is mandatory per rubric bundle 4.
    emit_diagnostic(
        "hint: this is the cultureagent CLI frame; checks land with the first "
        "agent-runtime migration PR (see CLAUDE.md → 'Migration playbook')."
    )
    return 0


def register(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser(
        "doctor",
        help="Run diagnostics. Errors carry a 'hint:' line on stderr.",
    )
    p.add_argument("--json", action="store_true", help="Emit structured JSON.")
    p.set_defaults(func=cmd_doctor)
