"""``cultureagent learn`` — the learnability affordance.

Output must satisfy the agent-first rubric (afi cli doctor): >=200 chars,
mention purpose, commands, exit codes, ``--json``, and ``explain``.
"""

from __future__ import annotations

import argparse

from cultureagent import __version__
from cultureagent.cli._output import emit_result

_TEXT = """\
cultureagent — agent runtime for the Culture mesh.

Purpose
-------
Run AI-agent harnesses that connect to the Culture IRC mesh and translate
between IRC events and agent SDK calls. Today this repo is a frame: the CLI
contract is in place; agent-runtime business logic migrates here from
../culture once that repo finishes its agent-side cleanup.

Commands
--------
  cultureagent learn               Print this self-teaching prompt. Supports --json.
  cultureagent explain <path>...   Print markdown docs for any noun/verb path.
                                   Supports --json.
  cultureagent overview            Describe what's present in this CLI.
                                   Supports --json (stable keys: subject, sections).
  cultureagent doctor              Run diagnostics. Errors carry a 'hint:' line.

Machine-readable output
-----------------------
Every command that produces a listing or report supports --json. Errors in
JSON mode emit {"code", "message", "remediation"} to stderr. stdout and
stderr are never mixed.

Exit-code policy
----------------
  0 success
  1 user-input error (bad flag, bad path, missing arg)
  2 environment / setup error
  3+ reserved

More detail
-----------
  cultureagent explain cultureagent
"""


def _as_json_payload() -> dict[str, object]:
    return {
        "tool": "cultureagent",
        "version": __version__,
        "purpose": (
            "Agent runtime for the Culture mesh: runs per-backend harnesses "
            "that bridge IRC events and agent SDKs."
        ),
        "commands": [
            {"path": ["learn"], "summary": "Self-teaching prompt."},
            {"path": ["explain"], "summary": "Markdown docs by path."},
            {"path": ["overview"], "summary": "Descriptive map of CLI surface."},
            {"path": ["doctor"], "summary": "Diagnostics with hint markers."},
        ],
        "exit_codes": {
            "0": "success",
            "1": "user-input error",
            "2": "environment/setup error",
        },
        "json_support": True,
        "explain_pointer": "cultureagent explain <path>",
    }


def cmd_learn(args: argparse.Namespace) -> int:
    if getattr(args, "json", False):
        emit_result(_as_json_payload(), json_mode=True)
    else:
        emit_result(_TEXT, json_mode=False)
    return 0


def register(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser(
        "learn",
        help="Print a structured self-teaching prompt for agent consumers.",
    )
    p.add_argument("--json", action="store_true", help="Emit structured JSON.")
    p.set_defaults(func=cmd_learn)
