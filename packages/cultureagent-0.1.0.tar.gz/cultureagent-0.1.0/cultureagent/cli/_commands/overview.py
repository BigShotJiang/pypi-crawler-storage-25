"""``cultureagent overview`` — descriptive map of what's present.

Distinct from ``doctor``: ``overview`` answers "what is here", ``doctor``
answers "what is wrong". Stable JSON keys per the agent-first rubric:
``subject`` and ``sections``.

Bogus paths fall back gracefully (rubric bundle 6) — descriptive verbs do
not hard-fail the way diagnostic verbs do.
"""

from __future__ import annotations

import argparse

from cultureagent.cli._output import emit_diagnostic, emit_result


def _payload(path: tuple[str, ...]) -> dict[str, object]:
    # Today the CLI surface is the four agent-first globals plus no noun
    # groups. As agent-runtime nouns (clients, harness, etc.) land, append
    # entries to the ``sections`` list keyed off the requested path.
    base: dict[str, object] = {
        "subject": "cultureagent",
        "version": _version_str(),
        "sections": [
            {
                "name": "globals",
                "items": [
                    {"path": ["learn"], "summary": "Self-teaching prompt."},
                    {"path": ["explain"], "summary": "Markdown docs by path."},
                    {"path": ["overview"], "summary": "Descriptive map (this verb)."},
                    {"path": ["doctor"], "summary": "Diagnostics with hint markers."},
                ],
            },
            {
                "name": "nouns",
                "items": [],
                "note": "No noun groups registered yet — agent-runtime migration pending.",
            },
        ],
    }
    if path:
        base["requested_path"] = list(path)
    return base


def _version_str() -> str:
    from cultureagent import __version__

    return __version__


def cmd_overview(args: argparse.Namespace) -> int:
    path = tuple(args.path) if args.path else ()
    json_mode = bool(getattr(args, "json", False))
    payload = _payload(path)
    if path and not _path_matches_known_section(path):
        # Rubric bundle 6: warn on unknown path, don't hard-fail.
        emit_diagnostic(
            f"warning: no section matches path {' '.join(path)!r}; "
            "showing the root overview instead."
        )
    if json_mode:
        emit_result(payload, json_mode=True)
    else:
        emit_result(_render_text(payload), json_mode=False)
    return 0


def _path_matches_known_section(path: tuple[str, ...]) -> bool:
    head = path[0]
    return head in {"globals", "nouns", "learn", "explain", "overview", "doctor"}


def _render_text(payload: dict[str, object]) -> str:
    lines = [f"# {payload['subject']} {payload['version']}", ""]
    for section in payload["sections"]:  # type: ignore[union-attr]
        assert isinstance(section, dict)
        lines.append(f"## {section['name']}")
        items = section.get("items", [])
        assert isinstance(items, list)
        if items:
            for item in items:
                assert isinstance(item, dict)
                joined = " ".join(item["path"])  # type: ignore[index]
                lines.append(f"  - {joined} — {item['summary']}")
        else:
            note = section.get("note", "(empty)")
            lines.append(f"  ({note})")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def register(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser(
        "overview",
        help="Describe what's present in cultureagent (sections: globals, nouns).",
    )
    p.add_argument(
        "path",
        nargs="*",
        help="Optional path; empty = root overview. Unknown paths warn and fall back.",
    )
    p.add_argument("--json", action="store_true", help="Emit structured JSON.")
    p.set_defaults(func=cmd_overview)
