"""Entry point for ``python -m cultureagent``."""

from __future__ import annotations

import sys

from cultureagent.cli import main

if __name__ == "__main__":
    sys.exit(main())
