from __future__ import annotations

import os
from typing import Any

import httpx

OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"

OPENROUTER_OPUS_4_7_MODEL = "anthropic/claude-opus-4.7"
OPENROUTER_GPT_5_5_MODEL = "openai/gpt-5.5"
DEFAULT_OPENROUTER_ORACLE_MODEL = OPENROUTER_OPUS_4_7_MODEL

JUDGE_MODEL = "openai/gpt-oss-120b"

ALLOWED_OPENROUTER_ORACLE_MODELS = (
    OPENROUTER_OPUS_4_7_MODEL,
    OPENROUTER_GPT_5_5_MODEL,
)


def resolve_openrouter_model(model: str | None = None) -> str:
    if model is None or not model.strip():
        return DEFAULT_OPENROUTER_ORACLE_MODEL
    resolved = model.strip()
    if resolved not in ALLOWED_OPENROUTER_ORACLE_MODELS:
        allowed = ", ".join(ALLOWED_OPENROUTER_ORACLE_MODELS)
        raise ValueError(f"Oracle model must be one of: {allowed}; got {model!r}")
    return resolved


def require_openrouter_api_key(api_key: str | None = None) -> str:
    resolved = api_key or os.getenv("OPENROUTER_API_KEY")
    if not resolved or not resolved.strip():
        raise RuntimeError("OPENROUTER_API_KEY is required")
    return resolved.strip()


def openrouter_headers(
    *,
    api_key: str | None = None,
    referer: str | None = None,
    title: str | None = None,
) -> dict[str, str]:
    headers = {
        "Authorization": f"Bearer {require_openrouter_api_key(api_key)}",
        "Content-Type": "application/json",
    }
    if referer:
        headers["HTTP-Referer"] = referer
    if title:
        headers["X-Title"] = title
    return headers


def openrouter_chat_completion(
    *,
    model: str,
    messages: list[dict[str, str]],
    max_tokens: int,
    api_key: str | None = None,
    base_url: str = OPENROUTER_BASE_URL,
    timeout_seconds: float = 60.0,
    temperature: float | None = None,
    response_format: dict[str, Any] | None = None,
    referer: str | None = None,
    title: str | None = None,
    extra_body: dict[str, Any] | None = None,
) -> dict[str, Any]:
    payload = build_openrouter_chat_payload(
        model=model,
        messages=messages,
        max_tokens=max_tokens,
        temperature=temperature,
        response_format=response_format,
        extra_body=extra_body,
    )
    with httpx.Client(timeout=timeout_seconds) as client:
        response = client.post(
            f"{base_url}/chat/completions",
            headers=openrouter_headers(api_key=api_key, referer=referer, title=title),
            json=payload,
        )
        response.raise_for_status()
        data = response.json()
    if not isinstance(data, dict):
        raise RuntimeError("OpenRouter response must be a JSON object")
    return data


async def async_openrouter_chat_completion(
    *,
    model: str,
    messages: list[dict[str, str]],
    max_tokens: int,
    api_key: str | None = None,
    base_url: str = OPENROUTER_BASE_URL,
    timeout_seconds: float = 60.0,
    temperature: float | None = None,
    response_format: dict[str, Any] | None = None,
    referer: str | None = None,
    title: str | None = None,
    extra_body: dict[str, Any] | None = None,
) -> dict[str, Any]:
    payload = build_openrouter_chat_payload(
        model=model,
        messages=messages,
        max_tokens=max_tokens,
        temperature=temperature,
        response_format=response_format,
        extra_body=extra_body,
    )
    async with httpx.AsyncClient(timeout=timeout_seconds) as client:
        response = await client.post(
            f"{base_url}/chat/completions",
            headers=openrouter_headers(api_key=api_key, referer=referer, title=title),
            json=payload,
        )
        response.raise_for_status()
        data = response.json()
    if not isinstance(data, dict):
        raise RuntimeError("OpenRouter response must be a JSON object")
    return data


def generate_openrouter_text(
    *,
    model: str,
    messages: list[dict[str, str]],
    max_tokens: int,
    api_key: str | None = None,
    base_url: str = OPENROUTER_BASE_URL,
    timeout_seconds: float = 60.0,
    temperature: float | None = None,
    response_format: dict[str, Any] | None = None,
    referer: str | None = None,
    title: str | None = None,
    extra_body: dict[str, Any] | None = None,
) -> str:
    response = openrouter_chat_completion(
        model=model,
        messages=messages,
        max_tokens=max_tokens,
        api_key=api_key,
        base_url=base_url,
        timeout_seconds=timeout_seconds,
        temperature=temperature,
        response_format=response_format,
        referer=referer,
        title=title,
        extra_body=extra_body,
    )
    return extract_openrouter_message_content(response)


def build_openrouter_chat_payload(
    *,
    model: str,
    messages: list[dict[str, str]],
    max_tokens: int,
    temperature: float | None = None,
    response_format: dict[str, Any] | None = None,
    extra_body: dict[str, Any] | None = None,
) -> dict[str, Any]:
    max_tokens = require_positive_max_tokens(max_tokens)
    payload: dict[str, Any] = {
        "model": model,
        "messages": messages,
        "max_tokens": max_tokens,
    }
    if temperature is not None:
        payload["temperature"] = temperature
    if response_format is not None:
        payload["response_format"] = response_format
    if extra_body:
        payload.update(extra_body)
    return payload


def require_positive_max_tokens(value: object) -> int:
    try:
        parsed = int(value)  # type: ignore[arg-type]
    except (TypeError, ValueError) as error:
        raise ValueError("max_tokens must be set explicitly") from error
    if parsed < 1:
        raise ValueError("max_tokens must be at least 1")
    return parsed


def extract_openrouter_message_content(payload: dict[str, Any]) -> str:
    choices = payload.get("choices")
    if not isinstance(choices, list) or not choices:
        raise RuntimeError("OpenRouter response did not contain choices")
    first_choice = choices[0]
    message = first_choice.get("message") if isinstance(first_choice, dict) else None
    content = message.get("content") if isinstance(message, dict) else None
    if not isinstance(content, str) or not content.strip():
        raise RuntimeError("OpenRouter response did not contain content")
    return content.strip()
