# Freesolo SDK Package Map

This package is the public surface generated training repos should use. Do not
copy package internals into a generated repo.

## Generated Repo Shape

Generated repos should create only repo-local Freesolo files:

```text
freesolo/config.py
freesolo/environment.py
freesolo/data.py
freesolo/training.py
freesolo/gepa.py
freesolo/eval.py
```

Use the installed SDK from those files.

## Public Imports

Use these package areas:

- `freesolo.contracts`: load the approved training contract JSON.
- `freesolo.datasets`: load task records and build SFT conversations.
- `freesolo.environments`: define and load the repo environment adapter.
- `freesolo.training`: call SFT/GRPO helpers and create training config objects.
- `freesolo.gepa`: attach a Freesolo environment to GEPA prompt optimization.
- `freesolo.evaluation`: run scorers and environment evals.
- `freesolo.tracing`: configure OpenTelemetry spans for SDK calls.
- `freesolo.utils.oracle`: generate oracle ground-truth records.
- `freesolo.utils.wandb`: start W&B runs when credentials are available.

## Rules For Agents

- Put repo-specific constants and config objects in generated
  `freesolo/config.py`, including `SFT_CONFIG` and `GRPO_CONFIG`.
- Put task-specific prompt/reward behavior in generated `freesolo/environment.py`.
- In generated `freesolo/*.py` files, import sibling config values with
  `from config import ...`; reserve `from freesolo...` imports for the installed
  SDK package.
- Pass `ENVIRONMENT_REFERENCE = "freesolo/environment.py:load_environment"` to
  SFT, GRPO, GEPA, oracle, and evaluation helpers.
- Import `GrpoConfig` from `freesolo.training`, not `freesolo.environments`.
- Set `SftConfig(max_length=...)` explicitly in `SFT_CONFIG`; the SDK does not
  provide a fallback SFT sequence length.
- Have `Environment.get_grpo_config()` return `GRPO_CONFIG` from generated
  config; do not hard-code GRPO hyperparameters in the environment.
- Set `GrpoConfig(max_tokens=...)` explicitly in `GRPO_CONFIG`; the SDK does
  not provide a fallback generation limit.
- Pass `max_tokens=...` explicitly to oracle/OpenRouter generation helpers and
  hosted judge clients.
- Do not import underscored names from this package.
- Do not depend on environment variables for repo configuration, except secret
  account-level values such as `WANDB_API_KEY`, `OPENROUTER_API_KEY`, and
  `TINKER_API_KEY`.
