from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Generic, TypeVar

from ...utils.core import _clamp_score, _serialize_value, loads_json_object
from ...utils.openrouter import (
    JUDGE_MODEL,
    async_openrouter_chat_completion,
    extract_openrouter_message_content,
    require_positive_max_tokens,
)
from ..responses import NumericResponse, ScorerResponse
from ..types import DataRow

R = TypeVar("R", bound=ScorerResponse)


class CustomScorer(ABC, Generic[R]):
    """Base class for custom scorers.

    Subclasses implement `score`. The method may be async or sync; the runner
    handles both. `threshold` is used for numeric responses.
    """

    name: str | None = None
    threshold: float | None = None

    @abstractmethod
    async def score(self, row: DataRow) -> R:
        raise NotImplementedError

    @property
    def scorer_name(self) -> str:
        return self.name or type(self).__name__


class HostedJudgeClient:
    def __init__(
        self,
        *,
        max_tokens: int,
        api_key: str | None = None,
    ) -> None:
        self.max_tokens = require_positive_max_tokens(max_tokens)
        self.api_key = api_key

    async def judge(
        self,
        *,
        instructions: str,
        payload: dict[str, Any],
        temperature: float = 0.0,
    ) -> NumericResponse:
        messages = [
            {
                "role": "system",
                "content": (
                    "You are a strict evaluation judge. "
                    "Return JSON only with keys score and reason. "
                    "score must be a float between 0.0 and 1.0."
                ),
            },
            {
                "role": "user",
                "content": (
                    f"{instructions}\n\n"
                    "Evaluation payload:\n"
                    f"{_serialize_value(payload)}\n\n"
                    'Return JSON only: {"score": 0.0, "reason": "..."}'
                ),
            },
        ]
        data = await async_openrouter_chat_completion(
            model=JUDGE_MODEL,
            messages=messages,
            max_tokens=self.max_tokens,
            api_key=self.api_key,
            temperature=temperature,
            response_format={"type": "json_object"},
        )
        content = extract_openrouter_message_content(data)
        parsed = _parse_json_payload(content)
        score = _clamp_score(parsed.get("score"))
        reason = str(parsed.get("reason", "")).strip()
        metadata = {
            key: value
            for key, value in parsed.items()
            if key not in {"score", "reason"}
        }
        metadata["model"] = JUDGE_MODEL
        return NumericResponse(
            value=score,
            reason=reason,
            metadata=metadata,
            total_tokens=None,
        )


class HostedLLMScorer(CustomScorer[NumericResponse]):
    name: str | None = None
    threshold: float | None = None

    def __init__(
        self,
        *,
        client: HostedJudgeClient | None = None,
        threshold: float | None = None,
        max_tokens: int | None = None,
    ) -> None:
        if client is None:
            if max_tokens is None:
                raise ValueError(
                    "HostedLLMScorer requires max_tokens when no client is provided"
                )
            client = HostedJudgeClient(max_tokens=max_tokens)
        self.client = client
        if threshold is not None:
            self.threshold = threshold

    async def score(self, row: DataRow) -> NumericResponse:
        return await self.client.judge(
            instructions=self.build_instructions(row),
            payload=self.build_payload(row),
        )

    def build_instructions(self, row: DataRow) -> str:
        raise NotImplementedError

    def build_payload(self, row: DataRow) -> dict[str, Any]:
        raise NotImplementedError


def _parse_json_payload(content: str) -> dict[str, Any]:
    parsed = loads_json_object(content)
    if parsed is None:
        raise ValueError("hosted judge must return a JSON object")
    return parsed
