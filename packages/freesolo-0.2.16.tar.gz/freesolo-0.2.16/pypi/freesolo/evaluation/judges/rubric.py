from __future__ import annotations

from typing import Any

from ...utils.core import _find_first_present, _require_field
from ..types import DataRow
from .base import HostedJudgeClient, HostedLLMScorer


class RubricScorer(HostedLLMScorer):
    name = "rubric"
    threshold = 0.7

    def __init__(
        self,
        rubric: str,
        *,
        client: HostedJudgeClient | None = None,
        threshold: float | None = None,
        max_tokens: int | None = None,
    ) -> None:
        super().__init__(client=client, threshold=threshold, max_tokens=max_tokens)
        rubric_text = rubric.strip()
        if not rubric_text:
            raise ValueError("rubric is required")
        self.rubric = rubric_text

    def build_instructions(self, row: DataRow) -> str:
        _ = row
        return (
            "Grade actual_output against the provided rubric. "
            "Use expected_output and context only when they help interpret the rubric.\n\n"
            f"Rubric:\n{self.rubric}"
        )

    def build_payload(self, row: DataRow) -> dict[str, Any]:
        payload = {
            "input": row.get("input"),
            "actual_output": _require_field(row, "actual_output"),
            "expected_output": row.get("expected_output"),
        }
        context = _find_first_present(
            row, ("context", "contexts", "retrieved_documents", "sources")
        )
        if context is not None:
            payload["context"] = context
        return payload
