from __future__ import annotations

from typing import Any

from ...utils.core import _require_field
from ..types import DataRow
from .base import HostedJudgeClient, HostedLLMScorer


class PairwisePreferenceScorer(HostedLLMScorer):
    name = "pairwise_preference"
    threshold = 0.55

    def __init__(
        self,
        *,
        client: HostedJudgeClient | None = None,
        threshold: float | None = None,
        max_tokens: int | None = None,
        candidate_field: str = "actual_output",
        baseline_field: str = "baseline_output",
        rubric: str | None = None,
    ) -> None:
        super().__init__(client=client, threshold=threshold, max_tokens=max_tokens)
        self.candidate_field = candidate_field
        self.baseline_field = baseline_field
        self.rubric = rubric.strip() if rubric else None

    def build_instructions(self, row: DataRow) -> str:
        _ = row
        instruction = (
            "Compare the candidate output against the baseline output. "
            "Return score 1.0 if the candidate is clearly better, 0.5 for a tie, "
            "and 0.0 if the baseline is better. Include winner as candidate, baseline, or tie."
        )
        if self.rubric:
            instruction = f"{instruction}\n\nPreference rubric:\n{self.rubric}"
        return instruction

    def build_payload(self, row: DataRow) -> dict[str, Any]:
        return {
            "input": row.get("input"),
            "candidate_output": _require_field(row, self.candidate_field),
            "baseline_output": _require_field(row, self.baseline_field),
            "expected_output": row.get("expected_output"),
        }
