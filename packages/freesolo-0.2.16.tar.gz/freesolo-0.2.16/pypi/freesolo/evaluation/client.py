from __future__ import annotations

import asyncio
import inspect
import time
from collections.abc import Sequence
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import TYPE_CHECKING, Any

import httpx

from ..utils.core import (
    _auth_headers,
    _env_value,
    _normalize_data_row,
    _require_api_key,
    _resolve_base_url,
    elapsed_ms,
    require_non_empty,
)
from .judges import CustomScorer
from .responses import BinaryResponse, NumericResponse, ScorerResponse
from .results import ScorerData, ScoringResult
from .types import DataRow, EvaluationMetadata

if TYPE_CHECKING:
    from ..environments.base import Environment
    from ..environments.evaluation import EnvironmentGenerate, EnvironmentSource

RESULTS_PATH = "/api/evals/results"


class EvaluationClient:
    """Run scorers over data and post results to freesolo.

    Each call to ``run(name=...)`` appends a run to the eval identified by
    ``name``. The eval is auto-created on first post.

    Data row conventions:
        Each row in ``data`` is passed through to the backend verbatim. The
        following keys are recognized and lifted into typed columns on
        ``eval_tasks``: ``input``, ``actual_output``, ``expected_output``,
        ``image_url``. Any other keys are preserved on the row but will not
        populate the relational fields used by dashboards.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        internal_key: str | None = None,
        user_id: str | None = None,
        org_id: str | None = None,
        base_url: str | None = None,
        timeout_seconds: float = 300.0,
    ) -> None:
        self._api_key = api_key or _env_value("FREESOLO_API_KEY")
        self._internal_key = internal_key or _env_value("FREESOLO_INTERNAL_KEY")
        self._user_id = user_id or _env_value("FREESOLO_TRAINING_USER_ID")
        self._org_id = org_id or _env_value("FREESOLO_TRAINING_ORG_ID")
        if self._api_key:
            self._api_key = _require_api_key(
                self._api_key,
                error_message=_auth_error_message(),
            )
        else:
            if not self._internal_key or not self._user_id or not self._org_id:
                raise ValueError(_auth_error_message())
            self._internal_key = require_non_empty(
                self._internal_key or "",
                "FREESOLO_INTERNAL_KEY",
            )
            self._user_id = require_non_empty(
                self._user_id or "",
                "FREESOLO_TRAINING_USER_ID",
            )
            self._org_id = require_non_empty(
                self._org_id or "",
                "FREESOLO_TRAINING_ORG_ID",
            )
        self._base_url = _resolve_base_url(base_url)
        self._timeout_seconds = timeout_seconds

    def run(
        self,
        *,
        name: str,
        data: Sequence[DataRow],
        scorers: Sequence[CustomScorer[Any]],
        metadata: EvaluationMetadata | None = None,
    ) -> list[ScoringResult]:
        if not name.strip():
            raise ValueError("name is required")
        scorer_list = list(scorers)
        if not scorer_list:
            raise ValueError("at least one scorer is required")
        for scorer in scorer_list:
            if not isinstance(scorer, CustomScorer):
                raise TypeError("all scorers must be CustomScorer instances")

        rows = [_normalize_data_row(row, index) for index, row in enumerate(data)]
        if not rows:
            return []

        results = _score_rows(rows, scorer_list)
        run_id = self._post(
            name.strip(),
            results,
            metadata,
            function_name="EvaluationClient.run",
        )
        if run_id:
            for result in results:
                result.run_id = run_id
        return results

    def run_environment(
        self,
        *,
        name: str,
        source: EnvironmentSource,
        generate: EnvironmentGenerate,
        contract_path: str | Path = "TRAINING_CONTRACT.md",
        contract_text: str | None = None,
        environment: str | Environment | None = None,
        environment_kwargs: dict[str, object] | None = None,
        metadata: EvaluationMetadata | None = None,
        concurrency: int = 1,
    ) -> list[ScoringResult]:
        """Run a Freesolo Environment and upload DB-compatible eval results."""

        if not name.strip():
            raise ValueError("name is required")
        from ..environments.evaluation import _run_local_environment_evaluation

        results = _run_local_environment_evaluation(
            source=source,
            generate=generate,
            contract_path=contract_path,
            contract_text=contract_text,
            environment=environment,
            environment_kwargs=environment_kwargs,
            concurrency=concurrency,
        )
        if not results:
            return []
        run_id = self._post(
            name.strip(),
            results,
            metadata,
            function_name="EvaluationClient.run_environment",
        )
        if run_id:
            for result in results:
                result.run_id = run_id
        return results

    def _post(
        self,
        name: str,
        results: list[ScoringResult],
        metadata: EvaluationMetadata | None,
        *,
        function_name: str,
    ) -> str | None:
        payload = {
            "name": name,
            "metadata": metadata,
            "results": [result.to_dict() for result in results],
        }
        with httpx.Client(timeout=self._timeout_seconds) as client:
            response = client.post(
                f"{self._base_url}{RESULTS_PATH}",
                headers=self._headers(function_name=function_name),
                json=payload,
            )
            if response.is_error:
                # surface the server body — httpx's default error swallows it
                # and leaves users guessing what was wrong with their payload.
                raise httpx.HTTPStatusError(
                    f"freesolo /api/evals/results returned {response.status_code}: "
                    f"{response.text}",
                    request=response.request,
                    response=response,
                )
            data = response.json()
        if isinstance(data, dict):
            run_id = data.get("run_id")
            if run_id:
                return str(run_id)
        return None

    def _headers(self, *, function_name: str) -> dict[str, str]:
        if self._api_key:
            return _auth_headers(self._api_key, function_name=function_name)
        return {
            "Authorization": (
                f"Bearer {require_non_empty(self._internal_key or '', 'FREESOLO_INTERNAL_KEY')}"
            ),
            "Content-Type": "application/json",
            "X-Freesolo-Function": function_name,
            "X-Freesolo-Org-Id": require_non_empty(
                self._org_id or "",
                "FREESOLO_TRAINING_ORG_ID",
            ),
            "X-Freesolo-User-Id": require_non_empty(
                self._user_id or "",
                "FREESOLO_TRAINING_USER_ID",
            ),
        }


def run_local_evaluation(
    *,
    data: Sequence[DataRow],
    scorers: Sequence[CustomScorer[Any]],
) -> list[ScoringResult]:
    """Run scorers locally without uploading results to the Freesolo backend."""

    scorer_list = list(scorers)
    if not scorer_list:
        raise ValueError("at least one scorer is required")
    for scorer in scorer_list:
        if not isinstance(scorer, CustomScorer):
            raise TypeError("all scorers must be CustomScorer instances")

    rows = [_normalize_data_row(row, index) for index, row in enumerate(data)]
    if not rows:
        return []
    return _score_rows(rows, scorer_list)


def _score_rows(
    rows: list[DataRow],
    scorers: list[CustomScorer[Any]],
) -> list[ScoringResult]:
    started = time.monotonic()
    by_row: list[list[ScorerData]] = [[] for _ in rows]

    with ThreadPoolExecutor() as executor:
        futures = {}
        for index, row in enumerate(rows):
            for scorer in scorers:
                future = executor.submit(_score_one, scorer, row)
                futures[future] = index
        for future in as_completed(futures):
            by_row[futures[future]].append(future.result())

    duration = time.monotonic() - started
    results: list[ScoringResult] = []
    for index, row in enumerate(rows):
        scorer_data = sorted(by_row[index], key=lambda item: item.name)
        results.append(
            ScoringResult(
                success=all(item.success for item in scorer_data),
                scorers_data=scorer_data,
                data_object=row,
                run_duration=duration,
            )
        )
    return results


def _auth_error_message() -> str:
    return (
        "FREESOLO_API_KEY or FREESOLO_INTERNAL_KEY with FREESOLO_TRAINING_USER_ID "
        "and FREESOLO_TRAINING_ORG_ID is required for evaluations"
    )


def _score_one(scorer: CustomScorer[Any], row: DataRow) -> ScorerData:
    started = time.perf_counter()
    try:
        raw = scorer.score(row)
        response: ScorerResponse
        response = asyncio.run(raw) if inspect.isawaitable(raw) else raw
        latency_ms = elapsed_ms(started)
        return _response_to_scorer_data(scorer, response, latency_ms=latency_ms)
    except Exception as exc:
        # record latency even on failure: the user still waited for that time.
        return ScorerData(
            name=scorer.scorer_name,
            success=False,
            error=f"{type(exc).__name__}: {exc}",
            latency_ms=elapsed_ms(started),
        )


def _response_to_scorer_data(
    scorer: CustomScorer[Any],
    response: ScorerResponse,
    *,
    latency_ms: int | None,
) -> ScorerData:
    threshold = scorer.threshold
    if isinstance(response, BinaryResponse):
        score = 1.0 if response.value else 0.0
        threshold = 1.0
        success = bool(response.value)
    elif isinstance(response, NumericResponse):
        if threshold is None:
            raise ValueError(
                f'scorer "{scorer.scorer_name}" returned a NumericResponse but no '
                'threshold was provided. set "threshold" on the scorer.'
            )
        score = float(response.value)
        success = score >= threshold
    else:
        raise TypeError(f"unsupported scorer response: {type(response).__name__}")

    return ScorerData(
        name=scorer.scorer_name,
        success=success,
        value=response.value,
        score=score,
        threshold=threshold,
        reason=response.reason or None,
        return_type=response.return_type,
        latency_ms=latency_ms,
        total_tokens=response.total_tokens,
        metadata=response.metadata,
    )
