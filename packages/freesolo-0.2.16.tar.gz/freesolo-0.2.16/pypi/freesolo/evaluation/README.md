# Evaluation

Evaluation helpers run contract-aligned scorers over model outputs and can
upload results to Freesolo storage.

## Public Imports

```python
from freesolo.evaluation import (
    BinaryResponse,
    CustomScorer,
    EvaluationClient,
    ReferenceCorrectnessScorer,
    RubricScorer,
    run_local_evaluation,
)
```

## Environment Evaluation

For generated repos, prefer the environment path:

```python
from freesolo.evaluation import EvaluationClient
from config import ENVIRONMENT_REFERENCE

client = EvaluationClient(api_key=api_key)
results = client.run_environment(
    name="dev-eval",
    source="runs/dev.jsonl",
    generate=generate,
    contract_path="freesolo/TRAINING_CONTRACT.md",
    environment=ENVIRONMENT_REFERENCE,
)
```

Inside Freesolo backend worker jobs, `EvaluationClient()` can also authenticate
with `FREESOLO_INTERNAL_KEY`, `FREESOLO_TRAINING_USER_ID`, and
`FREESOLO_TRAINING_ORG_ID`; no `FREESOLO_API_KEY` guard is needed.

`generate(messages, example, **kwargs)` should call the candidate model and
return either a string, a dict with response text, or `EnvironmentGeneration`.

## Agent Guidance

- Public eval scorers must match the approved contract.
- Do not weaken scorer semantics for training convenience.
- If the environment can score outputs, use `run_environment(...)` so prompt
  construction, response normalization, and rewards stay consistent with GRPO.
- Use extra diagnostic rewards in training artifacts, not as replacement public
  eval metrics.
