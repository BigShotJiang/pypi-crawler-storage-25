from __future__ import annotations

import argparse
import asyncio
import math
import sys
from pathlib import Path
from typing import Unpack

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from freesolo.contracts.markdown import load_contract_text
from freesolo.datasets.records import load_task_examples
from freesolo.environments.base import load_environment as load_training_environment
from freesolo.training.grpo.config import resolve_grpo_config
from freesolo.training.grpo.datums import build_grpo_batch_datums
from freesolo.training.grpo.rewards import reward_diagnostics, reward_metrics
from freesolo.training.grpo.sampling import (
    SamplerState,
    ensure_sampling_client,
    session_id_from_tinker_path,
)
from freesolo.training.storage import start_stored_training_run
from freesolo.training.types import TrainGrpoOptions
from freesolo.utils.checkpoints import (
    get_last_tinker_checkpoint,
    next_training_position,
    resolve_checkpoint_sampler_path,
    resolve_checkpoint_state_path,
    resolve_sft_state_path,
    resolve_training_position,
    save_tinker_checkpoint,
    write_training_progress,
)
from freesolo.utils.core import load_dotenv_if_available, required_path
from freesolo.utils.wandb import numeric_metrics_from_result, start_wandb_run


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Basic Tinker GRPO scaffold.")
    parser.add_argument("--contract", default="TRAINING_CONTRACT.md")
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--environment")
    parser.add_argument("--log-dir", default="./logs/grpo")
    parser.add_argument("--sft-log-dir", default="./logs/sft")
    parser.add_argument("--sft-checkpoint-name", default="final")
    parser.add_argument("--sft-state-path")
    parser.add_argument("--reward-command")
    parser.add_argument("--base-model", default="Qwen/Qwen3-30B-A3B")
    parser.add_argument("--base-url")
    return parser.parse_args()


async def train_grpo_async(
    *,
    contract_path: str | Path = "TRAINING_CONTRACT.md",
    dataset_path: str | Path,
    environment: str | None = None,
    log_dir: str | Path = "./logs/grpo",
    sft_log_dir: str | Path = "./logs/sft",
    sft_checkpoint_name: str = "final",
    sft_state_path: str | None = None,
    reward_command: str | None = None,
    base_model: str = "Qwen/Qwen3-30B-A3B",
    base_url: str | None = None,
) -> int:
    try:
        import tinker
        from tinker import ConflictError, types
        from tinker_cookbook import checkpoint_utils, model_info, renderers
        from tinker_cookbook.tokenizer_utils import get_tokenizer
    except ImportError as error:
        raise RuntimeError(
            "Install numpy, tinker, and tinker-cookbook to run training/train_grpo.py"
        ) from error

    dataset_path = required_path(dataset_path, "dataset_path")
    contract_text = load_contract_text(contract_path)
    training_environment = load_training_environment(
        environment,
        reward_command=reward_command,
        contract_path=str(contract_path),
        dataset_path=str(dataset_path),
        mode="grpo",
    )
    grpo_config = resolve_grpo_config(training_environment.get_grpo_config())
    examples = load_task_examples(dataset_path)
    if not examples:
        raise RuntimeError(f"No GRPO records found in {dataset_path}")

    tokenizer = get_tokenizer(base_model)
    renderer_name = model_info.get_recommended_renderer_name(base_model)
    renderer = renderers.get_renderer(renderer_name, tokenizer)
    service_client = tinker.ServiceClient(base_url=base_url or None)
    log_dir = Path(log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)
    run_name = f"freesolo-grpo-{log_dir.name}"
    run_config = {
        "phase": "grpo",
        "contract_path": str(contract_path),
        "dataset_path": str(dataset_path),
        "environment": environment,
        "log_dir": str(log_dir),
        "sft_log_dir": str(sft_log_dir),
        "sft_checkpoint_name": sft_checkpoint_name,
        "sft_state_path": sft_state_path,
        "base_model": base_model,
        "batch_size": grpo_config.batch_size,
        "group_size": grpo_config.group_size,
        "learning_rate": grpo_config.learning_rate,
        "max_tokens": grpo_config.max_tokens,
        "num_epochs": grpo_config.num_epochs,
        "save_every": grpo_config.save_every,
        "temperature": grpo_config.temperature,
        "advantage_clip": grpo_config.advantage_clip,
        "record_count": len(examples),
    }
    stored_run = start_stored_training_run(
        phase="grpo",
        dataset_path=dataset_path,
        name=run_name,
        description="Freesolo GRPO training run",
        config=run_config,
    )
    wandb_run = None

    try:
        wandb_run = start_wandb_run(
            "grpo",
            log_dir=log_dir,
            name=run_name,
            group=stored_run.run_id,
            tags=("freesolo", "grpo"),
            config={
                **run_config,
                "freesolo_run_id": stored_run.run_id,
            },
        )
        stored_run.link_wandb(wandb_run.url)

        resume_info = get_last_tinker_checkpoint(checkpoint_utils, log_dir)

        resume_state_path = resolve_checkpoint_state_path(resume_info)
        if resume_state_path:
            training_client = await service_client.create_training_client_from_state_with_optimizer_async(
                str(resume_state_path)
            )
        else:
            checkpoint_state_path = resolve_sft_state_path(
                explicit_state_path=sft_state_path,
                sft_log_dir=sft_log_dir,
                checkpoint_name=sft_checkpoint_name,
                checkpoint_utils=checkpoint_utils,
            )
            if not checkpoint_state_path:
                raise RuntimeError(
                    "Could not find an SFT state path. Set --sft-state-path or provide a valid SFT log dir."
                )
            training_client = await service_client.create_training_client_from_state_with_optimizer_async(
                checkpoint_state_path
            )

        sampling_params = types.SamplingParams(
            max_tokens=grpo_config.max_tokens,
            temperature=grpo_config.temperature,
            stop=list(renderer.get_stop_sequences()) + list(grpo_config.stop_sequences),
        )
        batches_per_epoch = math.ceil(len(examples) / grpo_config.batch_size)
        global_step, start_epoch, start_batch_index, resume_progress = (
            resolve_training_position(
                resume_info,
                log_dir,
                batches_per_epoch=batches_per_epoch,
            )
        )
        if not resume_state_path and not resume_progress:
            global_step = 0
            start_epoch = 0
            start_batch_index = 0
        checkpoint_state_path = (
            str(resume_state_path) if resume_state_path else sft_state_path
        )
        sampler_state = SamplerState(
            session_id=session_id_from_tinker_path(checkpoint_state_path),
        )
        checkpoint_dirty = False

        wandb_run.summary_update(
            {
                "grpo/resume_step": global_step,
                "grpo/resume_epoch": start_epoch,
                "grpo/resume_batch_index": start_batch_index,
                "grpo/resumed_from_checkpoint": bool(resume_state_path),
                "grpo/resumed_from_progress": bool(resume_progress),
            }
        )

        for epoch in range(start_epoch, grpo_config.num_epochs):
            epoch_start_batch_index = start_batch_index if epoch == start_epoch else 0
            for batch_index in range(epoch_start_batch_index, batches_per_epoch):
                batch_start = batch_index * grpo_config.batch_size
                batch_end = batch_start + grpo_config.batch_size
                batch = examples[batch_start:batch_end]
                if not batch:
                    continue

                sampling_client = await ensure_sampling_client(
                    service_client=service_client,
                    training_client=training_client,
                    state=sampler_state,
                    global_step=global_step,
                    save_every=grpo_config.save_every,
                    conflict_error_type=ConflictError,
                )

                batch_result = await build_grpo_batch_datums(
                    batch=batch,
                    training_environment=training_environment,
                    contract_text=contract_text,
                    renderer=renderer,
                    sampling_client=sampling_client,
                    sampling_params=sampling_params,
                    group_size=grpo_config.group_size,
                    advantage_clip=grpo_config.advantage_clip,
                )
                training_datums = batch_result.training_datums

                if not training_datums:
                    next_step = global_step + 1
                    next_epoch, next_batch_index = next_training_position(
                        epoch=epoch,
                        batch_index=batch_index,
                        batches_per_epoch=batches_per_epoch,
                    )
                    wandb_run.log(
                        {
                            "trainer/global_step": global_step,
                            "grpo/epoch": epoch,
                            "grpo/batch_index": batch_index,
                            "grpo/batch_size": len(batch),
                            "grpo/response_count": batch_result.response_count,
                            "grpo/skipped_no_training_datums": 1,
                            "grpo/training_datums": 0,
                            "grpo/group_count": batch_result.group_count,
                            "grpo/trainable_reward_groups": (
                                batch_result.trainable_group_count
                            ),
                            "grpo/uniform_reward_groups": (
                                batch_result.uniform_group_count
                            ),
                            "grpo/next_global_step": next_step,
                            **reward_metrics(batch_result.rewards),
                            **reward_diagnostics(batch_result.reward_results),
                        },
                        step=global_step,
                    )
                    if not checkpoint_dirty:
                        write_training_progress(
                            log_dir,
                            phase="grpo",
                            step=next_step,
                            epoch=next_epoch,
                            batch_index=next_batch_index,
                            batches_per_epoch=batches_per_epoch,
                            state_path=resume_state_path,
                            skipped_batch=True,
                        )
                    global_step = next_step
                    continue

                adam_params = types.AdamParams(
                    learning_rate=grpo_config.learning_rate,
                    beta1=0.9,
                    beta2=0.95,
                    eps=1e-8,
                )
                fwd_bwd_future = training_client.forward_backward(
                    training_datums,
                    loss_fn="importance_sampling",
                )
                optim_step_future = training_client.optim_step(adam_params)
                fwd_bwd_result = await asyncio.to_thread(fwd_bwd_future.result)
                optim_step_result = await asyncio.to_thread(optim_step_future.result)
                metrics: dict[str, object] = {
                    "trainer/global_step": global_step,
                    "grpo/epoch": epoch,
                    "grpo/batch_index": batch_index,
                    "grpo/batch_size": len(batch),
                    "grpo/response_count": batch_result.response_count,
                    "grpo/training_datums": len(training_datums),
                    "grpo/group_count": batch_result.group_count,
                    "grpo/trainable_reward_groups": (
                        batch_result.trainable_group_count
                    ),
                    "grpo/uniform_reward_groups": batch_result.uniform_group_count,
                    "grpo/learning_rate": grpo_config.learning_rate,
                    "grpo/skipped_no_training_datums": 0,
                    **reward_metrics(batch_result.rewards),
                    **reward_diagnostics(batch_result.reward_results),
                }
                metrics.update(
                    numeric_metrics_from_result("grpo/forward_backward", fwd_bwd_result)
                )
                metrics.update(
                    numeric_metrics_from_result("grpo/optim_step", optim_step_result)
                )
                wandb_run.log(metrics, step=global_step)

                next_step = global_step + 1
                if (
                    grpo_config.save_every > 0
                    and next_step % grpo_config.save_every == 0
                ):
                    checkpoint_name = f"grpo_{next_step:06d}"
                    checkpoint_record = await asyncio.to_thread(
                        save_tinker_checkpoint,
                        checkpoint_utils=checkpoint_utils,
                        training_client=training_client,
                        name=checkpoint_name,
                        log_dir=log_dir,
                        loop_state={
                            "epoch": epoch,
                            "batch_index": batch_index,
                            "step": next_step,
                        },
                    )
                    resume_state_path = resolve_checkpoint_state_path(checkpoint_record)
                    next_epoch, next_batch_index = next_training_position(
                        epoch=epoch,
                        batch_index=batch_index,
                        batches_per_epoch=batches_per_epoch,
                    )
                    write_training_progress(
                        log_dir,
                        phase="grpo",
                        step=next_step,
                        epoch=next_epoch,
                        batch_index=next_batch_index,
                        batches_per_epoch=batches_per_epoch,
                        checkpoint_name=checkpoint_name,
                        state_path=resume_state_path,
                        sampler_path=resolve_checkpoint_sampler_path(checkpoint_record),
                        skipped_batch=False,
                    )
                    checkpoint_dirty = False
                    wandb_run.log(
                        {
                            "trainer/global_step": next_step,
                            "grpo/checkpoint_saved": 1,
                            "grpo/checkpoint_name": checkpoint_name,
                        },
                        step=next_step,
                    )
                else:
                    checkpoint_dirty = True

                global_step = next_step

        final_record = await asyncio.to_thread(
            save_tinker_checkpoint,
            checkpoint_utils=checkpoint_utils,
            training_client=training_client,
            name="final",
            log_dir=log_dir,
            loop_state={
                "epoch": grpo_config.num_epochs,
                "batch_index": 0,
                "step": global_step,
            },
        )
        final_state_path = resolve_checkpoint_state_path(final_record)
        write_training_progress(
            log_dir,
            phase="grpo",
            step=global_step,
            epoch=grpo_config.num_epochs,
            batch_index=0,
            batches_per_epoch=batches_per_epoch,
            checkpoint_name="final",
            state_path=final_state_path,
            sampler_path=resolve_checkpoint_sampler_path(final_record),
        )
        wandb_run.summary_update(
            {
                "grpo/final_step": global_step,
                "grpo/final_checkpoint_name": "final",
                "grpo/record_count": len(examples),
            }
        )
        stored_run.complete()
    except BaseException as error:
        stored_run.fail(error)
        raise
    finally:
        if wandb_run is not None:
            wandb_run.finish()
    return 0


def train_grpo(**kwargs: Unpack[TrainGrpoOptions]) -> int:
    load_dotenv_if_available()
    return asyncio.run(train_grpo_async(**kwargs))


async def main_async() -> int:
    args = _parse_args()
    dataset_path = required_path(args.dataset, "--dataset")
    return await train_grpo_async(
        contract_path=args.contract,
        dataset_path=dataset_path,
        environment=args.environment,
        log_dir=args.log_dir,
        sft_log_dir=args.sft_log_dir,
        sft_checkpoint_name=args.sft_checkpoint_name,
        sft_state_path=args.sft_state_path,
        reward_command=args.reward_command,
        base_model=args.base_model,
        base_url=args.base_url,
    )


def main() -> int:
    return asyncio.run(main_async())


if __name__ == "__main__":
    raise SystemExit(main())
