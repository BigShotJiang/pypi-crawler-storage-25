from __future__ import annotations

import argparse
import json
import os
from dataclasses import dataclass
from typing import Any, Literal
from urllib.parse import urlencode

import httpx

from .utils.core import JsonObject, _env_value, _resolve_base_url, require_non_empty

KANBAN_COLUMNS = ("planning", "in_progress", "blocked", "review", "completed")
DEFAULT_TIMEOUT_SECONDS = 10.0
KANBAN_PATH = "/api/training/internal/kanban"

KanbanColumn = Literal["planning", "in_progress", "blocked", "review", "completed"]


@dataclass(frozen=True)
class AgentKanbanContext:
    org_id: str
    root_job_id: str
    job_id: str | None = None
    action: str | None = None


def context_from_env() -> AgentKanbanContext:
    org_id = require_non_empty(
        os.getenv("FREESOLO_TRAINING_ORG_ID", ""),
        "FREESOLO_TRAINING_ORG_ID",
    )
    job_id = os.getenv("FREESOLO_TRAINING_JOB_ID") or None
    root_job_id = (
        os.getenv("FREESOLO_TRAINING_ROOT_JOB_ID")
        or job_id
        or require_non_empty("", "FREESOLO_TRAINING_ROOT_JOB_ID")
    )
    return AgentKanbanContext(
        org_id=org_id,
        root_job_id=root_job_id,
        job_id=job_id,
        action=os.getenv("FREESOLO_TRAINING_ACTION") or None,
    )


class AgentKanban:
    """Internal Freesolo agent planning board client.

    The worker runtime provides FREESOLO_INTERNAL_KEY and FREESOLO_TRAINING_*
    scope variables. Normal user applications should not use this client.
    """

    def __init__(
        self,
        *,
        base_url: str | None = None,
        internal_key: str | None = None,
        context: AgentKanbanContext | None = None,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
    ) -> None:
        self.base_url = _resolve_base_url(base_url)
        self.internal_key = internal_key or _env_value("FREESOLO_INTERNAL_KEY") or ""
        if not self.internal_key:
            raise ValueError("FREESOLO_INTERNAL_KEY is required")
        self.context = context or context_from_env()
        self.timeout = timeout

    def plan(
        self,
        *,
        title: str,
        description: str | None = None,
        task_key: str,
    ) -> JsonObject:
        return self._upsert(
            title=title,
            description=description,
            task_key=task_key,
            column="planning",
        )

    def start(
        self,
        *,
        task_key: str,
        description: str | None = None,
    ) -> JsonObject:
        return self._upsert(
            description=description,
            task_key=task_key,
            column="in_progress",
        )

    def review(
        self,
        *,
        task_key: str,
        description: str | None = None,
    ) -> JsonObject:
        return self._upsert(
            description=description,
            task_key=task_key,
            column="review",
        )

    def block(
        self,
        *,
        task_key: str,
        description: str | None = None,
    ) -> JsonObject:
        return self._upsert(
            description=description,
            task_key=task_key,
            column="blocked",
        )

    def complete(
        self,
        *,
        task_key: str,
        description: str | None = None,
    ) -> JsonObject:
        return self._upsert(
            description=description,
            task_key=task_key,
            column="completed",
        )

    def _upsert(
        self,
        *,
        title: str | None = None,
        description: str | None = None,
        task_key: str,
        column: KanbanColumn = "planning",
    ) -> JsonObject:
        _validate_column(column)
        task_key = require_non_empty(task_key, "task_key")

        payload: JsonObject = {
            "orgId": self.context.org_id,
            "rootJobId": self.context.root_job_id,
            "taskKey": task_key,
            "column": column,
        }
        if self.context.job_id is not None:
            payload["jobId"] = self.context.job_id
        if self.context.action is not None:
            payload["action"] = self.context.action
        if title is not None:
            payload["title"] = require_non_empty(title, "title")
        if description is not None:
            payload["description"] = description.strip() or None
        response = self._request("POST", self._url(), json=payload)
        return _task_response(response)

    def list_tasks(self) -> list[JsonObject]:
        response = self._request(
            "GET",
            self._url(
                {
                    "orgId": self.context.org_id,
                    "rootJobId": self.context.root_job_id,
                }
            ),
        )
        payload = _json_response(response)
        tasks = payload.get("tasks")
        if not isinstance(tasks, list):
            raise ValueError("kanban API returned an invalid task list")
        return [task for task in tasks if isinstance(task, dict)]

    def delete_columns(
        self,
        *,
        columns: tuple[KanbanColumn, ...] | list[KanbanColumn] = (
            "planning",
            "in_progress",
        ),
    ) -> int:
        column_list = list(columns)
        for column in column_list:
            _validate_column(column)
        response = self._request(
            "POST",
            f"{self.base_url}{KANBAN_PATH}/delete-columns",
            json={
                "orgId": self.context.org_id,
                "rootJobId": self.context.root_job_id,
                "columns": column_list,
            },
        )
        payload = _json_response(response)
        return int(payload.get("deleted") or 0)

    def _url(self, params: dict[str, str] | None = None) -> str:
        url = f"{self.base_url}{KANBAN_PATH}"
        if not params:
            return url
        return f"{url}?{urlencode(params)}"

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.internal_key}",
            "Content-Type": "application/json",
        }

    def _request(self, method: str, url: str, **kwargs: Any) -> httpx.Response:
        with httpx.Client(timeout=self.timeout) as client:
            response = client.request(method, url, headers=self._headers(), **kwargs)
        response.raise_for_status()
        return response


def _validate_column(column: str) -> None:
    if column not in KANBAN_COLUMNS:
        raise ValueError(f"column must be one of: {', '.join(KANBAN_COLUMNS)}")


def _json_response(response: httpx.Response) -> JsonObject:
    parsed = response.json()
    if not isinstance(parsed, dict):
        raise ValueError("kanban API returned a non-object response")
    return parsed


def _task_response(response: httpx.Response) -> JsonObject:
    payload = _json_response(response)
    task = payload.get("task")
    if not isinstance(task, dict):
        raise ValueError("kanban API did not return a task")
    return task


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Update the Freesolo agent kanban board."
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    plan_parser = subparsers.add_parser("plan")
    plan_parser.add_argument("--key", required=True, dest="task_key")
    plan_parser.add_argument("--title", required=True)
    plan_parser.add_argument("--description")

    for command in ("start", "review", "block", "complete"):
        move_parser = subparsers.add_parser(command)
        move_parser.add_argument("--key", required=True, dest="task_key")
        move_parser.add_argument("--description")

    subparsers.add_parser("list")
    subparsers.add_parser("cleanup-active")
    return parser


def main() -> None:
    args = _build_parser().parse_args()
    client = AgentKanban()
    if args.command == "list":
        result: Any = client.list_tasks()
    elif args.command == "cleanup-active":
        result = {"deleted": client.delete_columns()}
    else:
        kwargs = {
            "task_key": args.task_key,
            "description": args.description,
        }
        if hasattr(args, "title"):
            kwargs["title"] = args.title
        result = getattr(client, args.command)(**kwargs)
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
