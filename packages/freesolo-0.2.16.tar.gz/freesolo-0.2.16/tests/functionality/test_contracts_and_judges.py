from __future__ import annotations

import asyncio

import pytest
from freesolo.contracts.markdown import (
    build_oracle_messages,
    extract_contract_spec,
    load_contract_spec,
    load_contract_text,
)
from freesolo.evaluation.judges import (
    GroundednessScorer,
    HostedJudgeClient,
    InstructionFollowingScorer,
    PairwisePreferenceScorer,
    ReferenceCorrectnessScorer,
    RubricScorer,
)
from freesolo.evaluation.judges.base import HostedLLMScorer, _parse_json_payload
from freesolo.evaluation.responses import NumericResponse


def test_contract_markdown_load_extract_and_render_paths(tmp_path) -> None:
    contract_path = tmp_path / "TRAINING_CONTRACT.md"
    contract_path.write_text(
        """
        Intro text.

        ```freesolo-contract
        {
          "prompt": {
            "messages": [
              {"role": "system", "content": "Answer using {task}"},
              {"role": "", "content": "Question: {input}"}
            ]
          }
        }
        ```
        """,
        encoding="utf-8",
    )

    contract_text = load_contract_text(contract_path)
    contract_spec = load_contract_spec(contract_path)

    assert "Intro text" in contract_text
    assert contract_spec is not None
    assert build_oracle_messages("find people", contract_text, contract_spec) == [
        {"role": "system", "content": "Answer using find people"},
        {"role": "user", "content": "Question: find people"},
    ]


def test_contract_spec_fallbacks_and_validation() -> None:
    system_user_spec = {"prompt": {"system": "System {query}", "user": "User {task}"}}
    assert build_oracle_messages("task text", "raw contract", system_user_spec) == [
        {"role": "system", "content": "System task text"},
        {"role": "user", "content": "User task text"},
    ]
    assert build_oracle_messages(
        "task text", "raw contract", {"reward_functions": []}
    ) == [
        {
            "role": "system",
            "content": '{\n  "reward_functions": []\n}',
        },
        {"role": "user", "content": "task text"},
    ]
    assert extract_contract_spec("plain markdown") is None
    assert extract_contract_spec("```freesolo-contract\n\n```") is None
    with pytest.raises(ValueError, match="JSON object"):
        extract_contract_spec("[1, 2, 3]")


def test_hosted_judge_client_parses_clamps_and_preserves_metadata(monkeypatch) -> None:
    calls: list[dict[str, object]] = []

    async def fake_chat_completion(**kwargs):
        calls.append(kwargs)
        return {
            "choices": [
                {
                    "message": {
                        "content": '{"score": 1.5, "reason": "strong", "extra": "kept"}'
                    }
                }
            ]
        }

    monkeypatch.setattr(
        "freesolo.evaluation.judges.base.async_openrouter_chat_completion",
        fake_chat_completion,
    )

    response = asyncio.run(
        HostedJudgeClient(api_key="openrouter-key", max_tokens=256).judge(
            instructions="Grade it.",
            payload={"actual_output": "yes"},
            temperature=0.2,
        )
    )

    assert response.value == 1.0
    assert response.reason == "strong"
    assert response.metadata["extra"] == "kept"
    assert calls[0]["api_key"] == "openrouter-key"
    assert calls[0]["max_tokens"] == 256
    assert calls[0]["temperature"] == 0.2
    assert calls[0]["response_format"] == {"type": "json_object"}


def test_hosted_judge_client_requires_explicit_max_tokens() -> None:
    with pytest.raises(TypeError):
        HostedJudgeClient()  # type: ignore[call-arg]

    with pytest.raises(ValueError, match="at least 1"):
        HostedJudgeClient(max_tokens=0)


def test_hosted_judge_rejects_non_json_payload() -> None:
    with pytest.raises(ValueError, match="JSON object"):
        _parse_json_payload("not json")


class _RecordingClient:
    def __init__(self) -> None:
        self.calls: list[dict[str, object]] = []

    async def judge(self, **kwargs):
        self.calls.append(kwargs)
        return NumericResponse(value=0.7, reason="ok")


class _ToyScorer(HostedLLMScorer):
    def build_instructions(self, row):
        return f"instructions for {row['input']}"

    def build_payload(self, row):
        return {"actual_output": row["actual_output"]}


def test_hosted_llm_scorer_delegates_to_client_and_threshold_override() -> None:
    client = _RecordingClient()
    scorer = _ToyScorer(client=client, threshold=0.6)

    response = asyncio.run(scorer.score({"input": "task", "actual_output": "answer"}))

    assert response.value == 0.7
    assert scorer.threshold == 0.6
    assert client.calls == [
        {
            "instructions": "instructions for task",
            "payload": {"actual_output": "answer"},
        }
    ]


def test_hosted_llm_scorer_requires_max_tokens_without_custom_client() -> None:
    with pytest.raises(ValueError, match="max_tokens"):
        _ToyScorer()


def test_hosted_scorer_payload_builders_and_errors() -> None:
    row = {
        "input": "task",
        "actual_output": "candidate",
        "expected_output": "gold",
        "context": "retrieved context",
        "baseline_output": "baseline",
    }

    assert ReferenceCorrectnessScorer(client=_RecordingClient()).build_payload(row) == {
        "input": "task",
        "actual_output": "candidate",
        "expected_output": "gold",
    }
    assert (
        RubricScorer("Prefer exact answers", client=_RecordingClient()).build_payload(
            row
        )["context"]
        == "retrieved context"
    )
    assert GroundednessScorer(client=_RecordingClient()).build_payload(row)[
        "context"
    ] == ("retrieved context")
    assert InstructionFollowingScorer(client=_RecordingClient()).build_payload(row) == {
        "instructions": "task",
        "actual_output": "candidate",
        "expected_output": "gold",
    }
    assert (
        PairwisePreferenceScorer(
            client=_RecordingClient(),
            rubric="prefer concise",
        ).build_payload(row)["baseline_output"]
        == "baseline"
    )

    with pytest.raises(ValueError, match="rubric is required"):
        RubricScorer(" ", client=_RecordingClient())
    with pytest.raises(ValueError, match="groundedness scorer requires"):
        GroundednessScorer(client=_RecordingClient()).build_payload(
            {"actual_output": "a"}
        )
    with pytest.raises(ValueError, match="instruction_following scorer requires"):
        InstructionFollowingScorer(client=_RecordingClient()).build_payload(
            {"actual_output": "a"}
        )
    with pytest.raises(ValueError, match='row field "expected_output"'):
        ReferenceCorrectnessScorer(client=_RecordingClient()).build_payload(
            {"actual_output": "a"}
        )
