from __future__ import annotations

from typing import Any, ClassVar

import httpx
import pytest
from freesolo.evaluation import BinaryResponse, CustomScorer, EvaluationClient
from freesolo.evaluation.client import run_local_evaluation
from freesolo.evaluation.responses import NumericResponse
from freesolo.evaluation.types import DataRow
from freesolo.utils.core import _auth_headers


class _FakeHttpClient:
    calls: ClassVar[list[dict[str, Any]]] = []

    def __init__(self, *, timeout: float) -> None:
        self.timeout = timeout

    def __enter__(self) -> _FakeHttpClient:
        return self

    def __exit__(self, *args: object) -> None:
        return None

    def post(self, url: str, **kwargs: Any) -> httpx.Response:
        self.calls.append({"url": url, **kwargs})
        return httpx.Response(
            200,
            json={"ok": True, "run_id": "eval-run-1"},
            request=httpx.Request("POST", url),
        )


class BooleanScorer(CustomScorer[BinaryResponse]):
    name = "boolean"

    def score(self, row: DataRow) -> BinaryResponse:
        return BinaryResponse(value=bool(row["pass"]), reason="checked")


class NumericScorer(CustomScorer[NumericResponse]):
    name = "numeric"
    threshold = 0.75

    def score(self, row: DataRow) -> NumericResponse:
        return NumericResponse(
            value=float(row["score"]),
            reason="graded",
            metadata={"source": "test"},
            total_tokens=7,
        )


class BrokenScorer(CustomScorer[BinaryResponse]):
    name = "broken"

    def score(self, row: DataRow) -> BinaryResponse:
        raise RuntimeError("scorer failed")


@pytest.fixture(autouse=True)
def _reset_fake_client() -> None:
    _FakeHttpClient.calls = []


def test_evaluation_client_requires_api_key(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("FREESOLO_API_KEY", raising=False)
    monkeypatch.delenv("FREESOLO_INTERNAL_KEY", raising=False)
    monkeypatch.delenv("FREESOLO_TRAINING_USER_ID", raising=False)
    monkeypatch.delenv("FREESOLO_TRAINING_ORG_ID", raising=False)

    with pytest.raises(ValueError, match=r"FREESOLO_API_KEY.*FREESOLO_INTERNAL_KEY"):
        EvaluationClient()


def test_evaluation_client_posts_results_and_sets_run_id(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("freesolo.evaluation.client.httpx.Client", _FakeHttpClient)

    results = EvaluationClient(
        api_key="fs-test",
        base_url="https://api.test/",
    ).run(
        name="demo eval",
        data=[{"input": "a", "pass": True, "score": 0.9}],
        scorers=[BooleanScorer(), NumericScorer()],
        metadata={"commit": "abc"},
    )

    assert [result.run_id for result in results] == ["eval-run-1"]
    assert len(results) == 1
    assert results[0].success is True
    call = _FakeHttpClient.calls[0]
    payload = call["json"]
    result_payload = payload["results"][0]
    latency_values = [
        scorer_payload.pop("latency_ms")
        for scorer_payload in result_payload["scorers_data"]
    ]
    assert all(
        isinstance(latency_ms, int) and latency_ms >= 0 for latency_ms in latency_values
    )
    assert _FakeHttpClient.calls == [
        {
            "url": "https://api.test/api/evals/results",
            "headers": _auth_headers(
                "fs-test",
                function_name="EvaluationClient.run",
            ),
            "json": {
                "name": "demo eval",
                "metadata": {"commit": "abc"},
                "results": [
                    {
                        "success": True,
                        "scorers_data": [
                            {
                                "name": "boolean",
                                "success": True,
                                "value": True,
                                "score": 1.0,
                                "threshold": 1.0,
                                "reason": "checked",
                                "return_type": "binary",
                            },
                            {
                                "name": "numeric",
                                "success": True,
                                "value": 0.9,
                                "score": 0.9,
                                "threshold": 0.75,
                                "reason": "graded",
                                "return_type": "numeric",
                                "total_tokens": 7,
                                "metadata": {"source": "test"},
                            },
                        ],
                        "data_object": {"input": "a", "pass": True, "score": 0.9},
                    }
                ],
            },
        }
    ]


def test_evaluation_client_posts_results_with_internal_training_scope(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("freesolo.evaluation.client.httpx.Client", _FakeHttpClient)

    EvaluationClient(
        internal_key="internal-key",
        user_id="user-1",
        org_id="org-A",
        base_url="https://api.test",
    ).run(
        name="demo eval",
        data=[{"input": "a", "pass": True}],
        scorers=[BooleanScorer()],
    )

    assert _FakeHttpClient.calls[0]["headers"] == {
        "Authorization": "Bearer internal-key",
        "Content-Type": "application/json",
        "X-Freesolo-Function": "EvaluationClient.run",
        "X-Freesolo-Org-Id": "org-A",
        "X-Freesolo-User-Id": "user-1",
    }


def test_evaluation_client_does_not_infer_training_scope_metadata_from_env(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("freesolo.evaluation.client.httpx.Client", _FakeHttpClient)
    monkeypatch.setenv("FREESOLO_TRAINING_RUN_ID", "run-1")
    monkeypatch.setenv("FREESOLO_TRAINING_JOB_ID", "job-1")
    monkeypatch.setenv("FREESOLO_TRAINING_ROOT_JOB_ID", "root-1")

    EvaluationClient(
        api_key="fs-test",
        base_url="https://api.test",
    ).run(
        name="demo eval",
        data=[{"input": "a", "pass": True}],
        scorers=[BooleanScorer()],
        metadata={"commit": "abc"},
    )

    assert _FakeHttpClient.calls[0]["json"]["metadata"] == {"commit": "abc"}


def test_run_local_evaluation_records_scorer_errors() -> None:
    results = run_local_evaluation(
        data=[{"input": "a"}],
        scorers=[BrokenScorer()],
    )

    assert len(results) == 1
    assert results[0].success is False
    scorer_data = results[0].scorers_data[0]
    assert scorer_data.name == "broken"
    assert scorer_data.success is False
    assert scorer_data.error == "RuntimeError: scorer failed"


def test_run_local_evaluation_rejects_empty_scorers() -> None:
    with pytest.raises(ValueError, match="at least one scorer"):
        run_local_evaluation(data=[{"input": "a"}], scorers=[])
