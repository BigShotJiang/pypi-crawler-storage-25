from __future__ import annotations

from typing import Any, ClassVar

import httpx
import pytest
from freesolo.kanban import AgentKanban, AgentKanbanContext, _build_parser


class _FakeHttpClient:
    calls: ClassVar[list[dict[str, Any]]] = []
    tasks: ClassVar[list[dict[str, Any]]] = []

    def __init__(self, *, timeout: float) -> None:
        self.timeout = timeout

    def __enter__(self) -> _FakeHttpClient:
        return self

    def __exit__(self, *args: object) -> None:
        return None

    def request(self, method: str, url: str, **kwargs: Any) -> httpx.Response:
        self.calls.append({"method": method, "url": url, **kwargs})
        request = httpx.Request(method, url)
        if method == "GET":
            return httpx.Response(
                200, json={"ok": True, "tasks": self.tasks}, request=request
            )
        if method == "POST":
            payload = dict(kwargs["json"])
            if url.endswith("/delete-columns"):
                columns = set(payload["columns"])
                before = len(type(self).tasks)
                type(self).tasks = [
                    task for task in type(self).tasks if task["column"] not in columns
                ]
                return httpx.Response(
                    200,
                    json={"ok": True, "deleted": before - len(type(self).tasks)},
                    request=request,
                )
            existing = next(
                (task for task in self.tasks if task["task_key"] == payload["taskKey"]),
                None,
            )
            if existing is None:
                task = {
                    "id": f"task-{len(self.tasks) + 1}",
                    "task_key": payload["taskKey"],
                    "title": payload["title"],
                    "description": payload.get("description"),
                    "column": payload["column"],
                    "priority": "medium",
                    "position": len(self.tasks),
                    "org_id": payload["orgId"],
                    "root_job_id": payload["rootJobId"],
                    "job_id": payload.get("jobId"),
                    "action": payload.get("action"),
                    "updated_at": "2026-05-15T00:00:00Z",
                }
                self.tasks.append(task)
            else:
                task = existing
                task.update(
                    {
                        "description": payload.get("description"),
                        "column": payload["column"],
                        "job_id": payload.get("jobId"),
                        "action": payload.get("action"),
                    }
                )
                if "title" in payload:
                    task["title"] = payload["title"]
            return httpx.Response(200, json={"ok": True, "task": task}, request=request)
        raise AssertionError(f"unexpected method {method}")


@pytest.fixture(autouse=True)
def _reset_fake_http(monkeypatch: pytest.MonkeyPatch) -> None:
    _FakeHttpClient.calls = []
    _FakeHttpClient.tasks = []
    monkeypatch.setattr("freesolo.kanban.httpx.Client", _FakeHttpClient)


def _client() -> AgentKanban:
    return AgentKanban(
        base_url="https://api.test",
        internal_key="internal-key",
        context=AgentKanbanContext(
            org_id="org-1",
            root_job_id="root-1",
            job_id="job-1",
            action="optimize",
        ),
    )


def test_agent_kanban_plan_creates_root_scoped_task() -> None:
    task = _client().plan(
        task_key="baseline-eval",
        title="Run baseline evaluation",
        description="Evaluate the current prompt before changing files.",
    )

    assert task["org_id"] == "org-1"
    assert task["root_job_id"] == "root-1"
    assert task["column"] == "planning"
    assert task["priority"] == "medium"
    assert task["position"] == 0
    assert task["task_key"] == "baseline-eval"
    assert task["job_id"] == "job-1"
    assert task["action"] == "optimize"


def test_agent_kanban_start_updates_existing_task_by_key() -> None:
    client = _client()
    client.plan(task_key="baseline-eval", title="Run baseline evaluation")

    task = client.start(
        task_key="baseline-eval",
        description="Command is running against dev30.",
    )

    assert task["title"] == "Run baseline evaluation"
    assert task["column"] == "in_progress"
    assert task["description"] == "Command is running against dev30."
    assert task["task_key"] == "baseline-eval"
    post_calls = [call for call in _FakeHttpClient.calls if call["method"] == "POST"]
    assert len(post_calls) == 2
    assert post_calls[-1]["url"] == "https://api.test/api/training/internal/kanban"


def test_agent_kanban_list_returns_agent_friendly_task_keys() -> None:
    client = _client()
    client.plan(task_key="baseline-eval", title="Run baseline evaluation")
    client.plan(task_key="grpo-probe", title="Run GRPO probe")

    tasks = client.list_tasks()

    assert [task["task_key"] for task in tasks] == ["baseline-eval", "grpo-probe"]
    assert tasks[0] == {
        "id": "task-1",
        "task_key": "baseline-eval",
        "title": "Run baseline evaluation",
        "description": None,
        "column": "planning",
        "priority": "medium",
        "position": 0,
        "org_id": "org-1",
        "root_job_id": "root-1",
        "job_id": "job-1",
        "action": "optimize",
        "updated_at": tasks[0]["updated_at"],
    }


def test_agent_kanban_delete_columns_removes_planning_and_in_progress() -> None:
    client = _client()
    client.plan(task_key="baseline-eval", title="Run baseline evaluation")
    client.plan(task_key="grpo-probe", title="Run GRPO probe")
    client.start(task_key="grpo-probe")
    client.plan(task_key="review-task", title="Review winner")
    client.review(task_key="review-task")

    deleted = client.delete_columns()

    assert deleted == 2
    assert [task["task_key"] for task in _FakeHttpClient.tasks] == ["review-task"]
    assert _FakeHttpClient.calls[-1]["url"] == (
        "https://api.test/api/training/internal/kanban/delete-columns"
    )
    assert _FakeHttpClient.calls[-1]["json"] == {
        "orgId": "org-1",
        "rootJobId": "root-1",
        "columns": ["planning", "in_progress"],
    }


def test_agent_kanban_cli_uses_command_specific_arguments() -> None:
    parser = _build_parser()

    plan_args = parser.parse_args(
        ["plan", "--key", "baseline-eval", "--title", "Run baseline eval"]
    )
    start_args = parser.parse_args(
        ["start", "--key", "baseline-eval", "--description", "Running now."]
    )
    cleanup_args = parser.parse_args(["cleanup-active"])

    assert plan_args.title == "Run baseline eval"
    assert cleanup_args.command == "cleanup-active"
    assert not hasattr(cleanup_args, "columns")
    assert not hasattr(plan_args, "priority")
    assert not hasattr(start_args, "title")
    assert not hasattr(start_args, "priority")
    with pytest.raises(SystemExit):
        parser.parse_args(["start", "--key", "baseline-eval", "--title", "Unexpected"])
    with pytest.raises(SystemExit):
        parser.parse_args(
            [
                "plan",
                "--key",
                "baseline-eval",
                "--title",
                "Run",
                "--meta",
                "split=dev30",
            ]
        )
    with pytest.raises(SystemExit):
        parser.parse_args(
            ["plan", "--key", "baseline-eval", "--title", "Run", "--priority", "high"]
        )
    with pytest.raises(SystemExit):
        parser.parse_args(["update", "--key", "baseline-eval", "--column", "review"])
    with pytest.raises(SystemExit):
        parser.parse_args(["cleanup-active", "--columns", "planning"])


def test_agent_kanban_uses_training_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("FREESOLO_BASE_URL", "https://api.test")
    monkeypatch.setenv("FREESOLO_INTERNAL_KEY", "internal-key")
    monkeypatch.setenv("FREESOLO_TRAINING_ORG_ID", "org-env")
    monkeypatch.setenv("FREESOLO_TRAINING_ROOT_JOB_ID", "root-env")
    monkeypatch.setenv("FREESOLO_TRAINING_JOB_ID", "job-env")
    monkeypatch.setenv("FREESOLO_TRAINING_ACTION", "training")

    task = AgentKanban().plan(task_key="train-long", title="Launch long GRPO run")

    assert task["org_id"] == "org-env"
    assert task["root_job_id"] == "root-env"
    assert task["job_id"] == "job-env"
    assert task["action"] == "training"
    assert _FakeHttpClient.calls[0]["headers"]["Authorization"] == "Bearer internal-key"
