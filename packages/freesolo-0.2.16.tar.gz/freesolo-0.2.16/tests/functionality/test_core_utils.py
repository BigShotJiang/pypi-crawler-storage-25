from __future__ import annotations

from pathlib import Path

import pytest
from freesolo.utils.core import (
    _auth_headers,
    _clamp_score,
    _find_first_present,
    _maybe_parse_json_text,
    _normalize_base_url,
    _normalize_data_row,
    _require_api_key,
    _require_field,
    _resolve_base_url,
    _serialize_value,
    _usage_headers,
    coerce_bool,
    coerce_float,
    json_safe_value,
    load_json_schema,
    loads_json_object,
    optional_int,
    optional_str,
    require_non_empty,
    required_path,
    serialize_value,
    slugify,
    stable_index,
    truncate_text,
    truthy,
    validate_output,
    write_jsonl,
)


def test_json_safe_value_normalizes_common_non_json_values() -> None:
    assert json_safe_value(
        {
            "path": Path("logs/run"),
            "items": ("a", Path("b")),
            "set": {"x"},
            1: "numeric-key",
        }
    ) == {
        "path": "logs/run",
        "items": ["a", "b"],
        "set": ["x"],
        "1": "numeric-key",
    }


def test_string_and_scalar_helpers() -> None:
    assert require_non_empty(" value ", "name") == "value"
    with pytest.raises(ValueError, match="name is required"):
        require_non_empty(" ", "name")

    assert optional_int(3.9) == 3
    assert optional_int(True) is None
    assert optional_str(None) is None
    assert optional_str(123) == "123"
    assert coerce_bool(1) is True
    assert coerce_bool("true") is None
    assert coerce_float(2) == 2.0
    assert coerce_float(True) == 1.0
    assert truthy(" yes ") is True
    assert truthy("no") is False
    assert slugify("SFT / GRPO!") == "sft-grpo"
    assert slugify("!!!", fallback="fallback") == "fallback"
    assert truncate_text("abcdef", 5) == "ab..."


def test_loads_json_object_accepts_plain_and_fenced_json() -> None:
    assert loads_json_object('{"ok": true}') == {"ok": True}
    assert loads_json_object('```json\n{"ok": true}\n```') == {"ok": True}
    assert loads_json_object('```text\n{"ok": true}\n```') == {"ok": True}
    assert loads_json_object("[1, 2]") is None


def test_path_auth_and_base_url_helpers(monkeypatch: pytest.MonkeyPatch) -> None:
    assert required_path("data.json", "dataset_path") == Path("data.json")
    with pytest.raises(RuntimeError, match="dataset_path"):
        required_path(None, "dataset_path")

    monkeypatch.setenv("FREESOLO_BASE_URL", "https://api.test/")
    assert _normalize_base_url("https://api.test/") == "https://api.test"
    assert _resolve_base_url() == "https://api.test"
    assert _auth_headers("key", function_name="fn") == {
        "Authorization": "Bearer key",
        "Content-Type": "application/json",
        "X-Freesolo-Function": "fn",
    }
    assert _usage_headers("key") == {
        "Authorization": "Bearer key",
        "Content-Type": "application/json",
    }
    with pytest.raises(ValueError, match="missing"):
        _require_api_key(None, error_message="missing")
    monkeypatch.setenv("FREESOLO_API_KEY", "from-env")
    assert _require_api_key(None, error_message="missing") == "from-env"


def test_row_and_serialization_helpers() -> None:
    assert _normalize_data_row({"a": 1}, 0) == {"a": 1}
    with pytest.raises(TypeError, match="row 2"):
        _normalize_data_row(["not", "dict"], 1)

    row = {"a": None, "b": 0, "c": "value"}
    assert _find_first_present(row, ("a", "b", "c")) == 0
    assert _require_field(row, "b") == 0
    with pytest.raises(ValueError, match='row field "a"'):
        _require_field(row, "a")

    assert _clamp_score(-5) == 0.0
    assert _clamp_score(2) == 1.0
    assert _maybe_parse_json_text('{"x": 1}') == {"x": 1}
    assert _maybe_parse_json_text("not-json") == "not-json"
    assert _serialize_value({"b": 2, "a": 1}) == '{\n  "a": 1,\n  "b": 2\n}'
    assert serialize_value({"b": 2, "a": 1}, pretty=False) == '{"a":1,"b":2}'
    assert stable_index("same") == stable_index("same")


def test_schema_loading_output_validation_and_jsonl(tmp_path) -> None:
    missing_schema = tmp_path / "missing.json"
    list_schema = tmp_path / "list.json"
    list_schema.write_text("[]", encoding="utf-8")
    schema_path = tmp_path / "schema.json"
    schema_path.write_text(
        '{"type":"object","required":["answer"],"properties":{"answer":{"type":"string"}}}',
        encoding="utf-8",
    )

    assert load_json_schema(None) is None
    with pytest.raises(FileNotFoundError, match="Schema file not found"):
        load_json_schema(missing_schema)
    with pytest.raises(ValueError, match="JSON object schema"):
        load_json_schema(list_schema)

    schema = load_json_schema(schema_path)
    assert schema is not None
    valid = validate_output('{"answer": "yes"}', schema=schema)
    invalid = validate_output('{"answer": 3}', schema=schema)
    assert valid.ok is True
    assert invalid.ok is False
    assert invalid.checks["schema_valid"] is False
    assert "answer" in invalid.errors[0]

    output_path = tmp_path / "nested" / "data.jsonl"
    write_jsonl(output_path, [{"answer": "yes"}, {"answer": "no"}])
    assert output_path.read_text(encoding="utf-8").splitlines() == [
        '{"answer": "yes"}',
        '{"answer": "no"}',
    ]
