import json
from mlgame.core.communication import TransitionCommManager
from mlgame.core.model import GameErrorSchema, GameInfoSchema, GameProgressSchema, GameResultSchema, MLGameDataType, SystemMsgSchema
from mlgame.executor.interface import ExecutorInterface
from mlgame.utils.logger import logger
import os


class ProgressLogExecutor(ExecutorInterface):
    def __init__(self, progress_folder, progress_frame_frequency, pl_comm: TransitionCommManager):
        # super().__init__(name="ws")
        self._proc_name = f"progress_log({progress_folder}"
        self._progress_folder = progress_folder
        self._progress_frame_frequency = progress_frame_frequency
        self._comm_manager = pl_comm
        self._recv_data_func = self._comm_manager.recv_from_game
        self._progress_data = []
        self._system_msgs = []
        self._game_errors = []

    def save_json(self, path: str, data):
        """將任意資料序列化為 JSON 並寫入指定路徑。"""
        with open(path, 'w') as f:
            content = json.dumps(
                data,
                default=lambda o: o.model_dump(mode='json') if hasattr(o, "model_dump") else str(o),
                ensure_ascii=False
            )
            f.write(content)
        file_size_kb = os.path.getsize(path) / 1024
        logger.info(f"File saved to: {path}, file size: {file_size_kb:.2f} KB")

    def save_progress_data(self, path: str):
        """將目前累積的 progress data 寫出後清空暫存列表。"""
        self.save_json(path, self._progress_data)
        self._progress_data = []

    def run(self):
        self._comm_manager.start_recv_obj_thread()

        try:
            progress_count = -1
            # Process data until we receive the game result
            while True:
                game_data = self._recv_data_func()
                # logger.info(f"game_data_type: {game_data.type}")
                
                if game_data.type == MLGameDataType.GAME_RESULT:
                    game_result_data = GameResultSchema.model_validate(game_data.data)
                    filepath = os.path.join(self._progress_folder, "result.json")
                    self.save_json(filepath, game_result_data)
                    break
                elif game_data.type == MLGameDataType.GAME_INFO:
                    game_info_data = GameInfoSchema.model_validate(game_data.data)
                    filepath = os.path.join(self._progress_folder, "init.json")
                    self.save_json(filepath, game_info_data)
                elif game_data.type == MLGameDataType.SYSTEM_MSG:
                    # 不需要儲存
                    continue
                elif game_data.type == MLGameDataType.GAME_ERROR:
                    game_error_data = GameErrorSchema.model_validate(game_data.data)
                    self._game_errors.append(game_error_data)
                    filepath = os.path.join(self._progress_folder, "error.json")
                    self.save_json(filepath, self._game_errors)
                

                elif game_data.type == MLGameDataType.GAME_PROGRESS:
                    
                    progress_data = GameProgressSchema.model_validate(game_data.data)
                    frame = progress_data.frame
                    # Check if we need to save the progress data
                    if (frame - 1) % self._progress_frame_frequency == 0 and frame != 1:
                        progress_count += 1
                        filepath = os.path.join(
                            self._progress_folder, 
                            f"{progress_count}.json"
                        )
                        self.save_progress_data(filepath)
                        
                    self._progress_data.append(progress_data)
            
            # Handle remaining progress data after the game is finished
            if self._progress_data:
                progress_count += 1
                filename = f"{progress_count}-end.json"
                filepath = os.path.join(self._progress_folder, filename)
                self.save_progress_data(filepath)
                
        except Exception as e:
            # exception = TransitionProcessError(self._proc_name, traceback.format_exc())
            self._comm_manager.send_exception(
                f"exception on {self._proc_name}")
            # catch connection error
            logger.exception(e)
        finally:
            logger.info("end pl")
