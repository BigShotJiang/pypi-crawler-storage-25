import curses
from cuipyd.ipane import IPane
from cuipyd.utils.direction import Direction


class Pane(IPane):

    def __init__(
        self,
        default_char=None,
        name=None,
        max_height=None,
        min_height=None,
        max_width=None,
        min_width=None,
        title_position=Direction.TOP_LEFT,
        overlap_title=False,
        show_title=None,
        padding=None,
        padding_left=None,
        padding_right=None,
        padding_top=None,
        padding_bottom=None,
    ):

        super().__init__(
            name=name,
            max_height=max_height,
            min_height=min_height,
            max_width=max_width,
            min_width=min_width,
            title_position=title_position,
            overlap_title=overlap_title,
            show_title=show_title,
            padding=padding,
            padding_left=padding_left,
            padding_right=padding_right,
            padding_top=padding_top,
            padding_bottom=padding_bottom,
            default_char=default_char,
        )

    def _refresh(self):
        self._window.refresh()

    def render_frame(self, time_delta):
        y, x = self._get_raw_size()
        cmod = self._get_color_scheme().default_mod()
        for r in range(y):
            for c in range(x):
                self.add_str(self.default_char, r, c, cmod)

    def _render_frame(self, time_delta):
        if not self._has_window():
            return
        self.render_frame(time_delta)
        self._draw_title()
        self._refresh()

    def _draw_box(self, row, col, height, width, style=0, mod=None):
        from cuipyd.popups.popup import PopupBorderStyle

        ul = curses.ACS_ULCORNER
        ur = curses.ACS_URCORNER
        ll = curses.ACS_LLCORNER
        lr = curses.ACS_LRCORNER
        lvl = curses.ACS_VLINE
        rvl = curses.ACS_VLINE
        uhl = curses.ACS_HLINE
        lhl = curses.ACS_HLINE

        if mod is None:
            mod = self._get_color_scheme().default_mod()

        if style == PopupBorderStyle.SMALL_BLOCK:
            ul = curses.ACS_BLOCK
            ur = curses.ACS_BLOCK
            ll = curses.ACS_BLOCK
            lr = curses.ACS_BLOCK
            lvl = curses.ACS_BLOCK
            rvl = curses.ACS_BLOCK
            uhl = curses.ACS_BLOCK
            lhl = curses.ACS_BLOCK

        elif style == PopupBorderStyle.CHECKER:
            ul = curses.ACS_BOARD
            ur = curses.ACS_BOARD
            ll = curses.ACS_BOARD
            lr = curses.ACS_BOARD
            lvl = curses.ACS_BOARD
            rvl = curses.ACS_BOARD
            uhl = curses.ACS_BOARD
            lhl = curses.ACS_BOARD

        elif style == PopupBorderStyle.BLOCK:
            mod = self._get_color_scheme().default_mod(invert=True)
            ul = ord(" ")
            ur = ord(" ")
            ll = ord(" ")
            lr = ord(" ")
            lvl = ord(" ")
            rvl = ord(" ")
            uhl = ord(" ")
            lhl = ord(" ")

        elif style == PopupBorderStyle.BARBED:
            ul = curses.ACS_PLUS
            ur = curses.ACS_PLUS
            ll = curses.ACS_PLUS
            lr = curses.ACS_PLUS
            lvl = curses.ACS_SBSS
            rvl = curses.ACS_SSSB
            uhl = curses.ACS_SSBS
            lhl = curses.ACS_BSSS

        elif style == PopupBorderStyle.ANGULAR:
            mod = self._get_color_scheme().default_mod(invert=True)
            ul = ""
            ur = ""
            ll = ""
            lr = ""
            lvl = " "
            rvl = " "
            uhl = " "
            lhl = " "

        # Draw Corners
        self._window.addch(row, col, ul, mod)
        self._window.addch(row, col + width - 1, ur, mod)
        self._window.addch(row + height - 1, col, ll, mod)
        try:
            self._window.addch(row + height - 1, col + width - 1, lr, mod)
        except curses.error:
            pass

        for r in range(1, height - 1):
            self._window.addch(row + r, col, lvl, mod)
            self._window.addch(row + r, col + width - 1, rvl, mod)

        for c in range(1, width - 1):
            self._window.addch(row, col + c, uhl, mod)
            self._window.addch(row + height - 1, col + c, lhl, mod)
