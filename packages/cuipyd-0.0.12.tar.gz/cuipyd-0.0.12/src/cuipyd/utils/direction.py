from enum import Enum


class Direction(Enum):
    TOP_LEFT = 0
    TOP = 1
    TOP_RIGHT = 3
    RIGHT = 4
    BOTTOM_RIGHT = 5
    BOTTOM = 6
    BOTTOM_LEFT = 7
    LEFT = 8
    CENTER = 9

    @staticmethod
    def on_top(direction) -> bool:
        return direction in [
            Direction.TOP_LEFT,
            Direction.TOP,
            Direction.TOP_RIGHT,
        ]

    @staticmethod
    def on_bottom(direction) -> bool:
        return direction in [
            Direction.BOTTOM_LEFT,
            Direction.BOTTOM,
            Direction.BOTTOM_RIGHT,
        ]

    @staticmethod
    def on_right(direction) -> bool:
        return direction in [
            Direction.TOP_RIGHT,
            Direction.RIGHT,
            Direction.BOTTOM_RIGHT,
        ]

    @staticmethod
    def on_left(direction) -> bool:
        return direction in [
            Direction.TOP_LEFT,
            Direction.LEFT,
            Direction.BOTTOM_LEFT,
        ]
