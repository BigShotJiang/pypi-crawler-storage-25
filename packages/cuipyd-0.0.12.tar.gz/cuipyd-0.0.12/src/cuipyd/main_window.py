import os
import curses
import subprocess
import time

from typing import List, Tuple
from contextlib import contextmanager

import setproctitle

from cuipyd.mouse import get_mouse_event, MouseEvent, MouseButton
from cuipyd.logging import log
from cuipyd.threads import StoppableLoopThread
from cuipyd.layouts.layout import BaseLayout
from cuipyd.colors.color_scheme import ColorScheme
from cuipyd.popups.popup import BasePopup


class MainWindow:

    def __init__(self, title: str = None, color_scheme: ColorScheme = None):
        self._children = []
        self._last_frame_time = time.time()
        self._min_frame_wait_time = 0.05
        self._prepare_curses()
        self._update_title(title)
        self._base_layout = None
        self._delayed_rendering = True
        if color_scheme is None:
            color_scheme = ColorScheme()
        self._color_scheme = color_scheme
        self._popup_stack = []
        self._focus_stack = []

    @property
    def default_char(self):
        return None

    def set_root_layout(self, layout: BaseLayout):
        self._base_layout = layout
        self._base_layout._set_parent(self)
        rows, cols = self._get_size()
        self._base_layout._update_window_size(rows, cols, 0, 0)

    def _get_color_scheme(self):
        return self._color_scheme

    @property
    def _root(self):
        return self

    @property
    def _window(self):
        return self._screen

    def _update_title(self, title):
        self._title = title
        if self._title:
            setproctitle.setproctitle(self._title)

    def _get_time_delta(self) -> float:
        now_time = time.time()
        time_delta = now_time - self._last_frame_time
        self._last_frame_time = now_time
        return time_delta

    def _render_loop(self) -> None:
        time.sleep(self._min_frame_wait_time)
        time_delta = self._get_time_delta()
        self._render_frame(time_delta)

    def _render_frame(self, time_delta):
        if self._has_popup():
            for popup in self._popup_stack:
                popup._render_frame(time_delta)
        else:
            if self._base_layout:
                self._base_layout._render_frame(time_delta)
        self._screen.refresh()

    def _start_rendering(self) -> None:
        if self._delayed_rendering:
            return
        self._render_thread = StoppableLoopThread(target=self._render_loop)
        self._render_thread.start()

    def _stop_rendering(self) -> None:
        if self._delayed_rendering:
            return
        self._render_thread.stop()
        self._render_thread.join()

    def terminate(self) -> None:
        curses.echo()
        curses.nocbreak()
        self._screen.keypad(False)
        curses.endwin()

    def _set_preparation_options(self) -> None:
        if curses.has_colors():
            curses.start_color()

        curses.mousemask(curses.ALL_MOUSE_EVENTS | curses.REPORT_MOUSE_POSITION)
        print("\033[?1003h")  # enable mouse tracking with the XTERM API

        curses.noecho()
        curses.cbreak()
        curses.curs_set(0)
        self._screen.keypad(True)

    def _prepare_curses(self) -> None:
        self._screen = curses.initscr()
        self._set_preparation_options()

    def _process_character(self, char) -> None:
        pass

    def _refresh(self):
        self._base_layout._refresh()

    def _refresh_main_window_size(self):
        size = self._get_size()
        if self._base_layout is not None:
            self._base_layout._update_window_size(size[0], size[1], 0, 0)

    @contextmanager
    def _pause_rendering(self):
        if self._delayed_rendering:
            yield
            return
        has_render_thread = hasattr(self, "_render_thread")
        if has_render_thread:
            self._render_thread.pause()
        yield
        if has_render_thread:
            self._render_thread.unpause()

    # ── Focus stack ───────────────────────────────────────────────────────────

    def push_focus(self, widget):
        if widget not in self._focus_stack:
            self._focus_stack.append(widget)
            widget._focused = True
            widget._on_focus_gained()

    def pop_focus(self, widget=None):
        if not self._focus_stack:
            return
        if widget is None:
            widget = self._focus_stack[-1]
        if widget in self._focus_stack:
            self._focus_stack.remove(widget)
            widget._focused = False
            widget._on_focus_lost()

    def _pop_focus_if_outside(self, row: int, col: int):
        if not self._focus_stack:
            return
        top = self._focus_stack[-1]
        s_row, s_col = top._get_raw_top_left()
        h, w = top._get_raw_size()
        if not (s_row <= row < s_row + h and s_col <= col < s_col + w):
            self.pop_focus(top)

    # ── Mouse & key routing ───────────────────────────────────────────────────

    def _send_mouse_event(self, row: int, col: int, button):
        event = get_mouse_event(row, col, button)
        # For some reason mac OS doesn't like WHEEL_DOWN
        if button == 134217728:
            event.button = MouseButton.WHEEL_DOWN
        self._register_mouse_event(event)

    def _register_mouse_event(self, mouse_event: MouseEvent):
        row = mouse_event.row
        col = mouse_event.column

        self._pop_focus_if_outside(row, col)

        if self._has_popup():
            top_popup = self._popup_stack[-1]
            p_rows, p_cols = top_popup._get_raw_size()
            s_row, s_col = top_popup._get_top_left()
            if row in range(s_row, s_row + p_rows) and col in range(
                s_col, s_col + p_cols
            ):
                mouse_event.row -= s_row
                mouse_event.column -= s_col
                top_popup._register_mouse_event(mouse_event)
                return
            top_popup._mouse_focus_ended()
        else:
            if self._base_layout._shift_down_from_title():
                new_r, new_c = self._base_layout._tweak_row_col(
                    mouse_event.row, mouse_event.column, reverse=True
                )
                mouse_event.row = new_r
                mouse_event.column = new_c

            self._base_layout._register_mouse_event(mouse_event)

    def _try_render_delayed(self):
        if self._delayed_rendering:
            self._render_frame(0)
            if not self._has_popup() and self._base_layout:
                self._base_layout._refresh()

    def _has_popup(self):
        return len(self._popup_stack) > 0

    def _run_internal(self, *args, **kwargs) -> None:
        self._start_rendering()
        self._try_render_delayed()
        try:
            while True:
                ch = self._screen.getch()
                if ch == curses.KEY_RESIZE:
                    with self._pause_rendering():
                        self._refresh_main_window_size()
                elif ch == curses.KEY_MOUSE:
                    _, x, y, _, button = curses.getmouse()
                    self._send_mouse_event(y, x, button)
                else:
                    try:
                        if ch == 3:  # Ctrl+C returns char 3 in cbreak mode on macOS
                            raise KeyboardInterrupt
                        if self._focus_stack:
                            consumed = self._focus_stack[-1].handle_key(ch)
                            if not consumed:
                                self._process_character(ch)
                        else:
                            self._process_character(ch)
                    except KeyboardInterrupt:
                        self._stop_rendering()
                        self.terminate()
                        return

                self._try_render_delayed()

        except KeyboardInterrupt:
            self._stop_rendering()
            self.terminate()
        except Exception as e:
            self._stop_rendering()
            self.terminate()
            raise e

    def run(self):
        curses.wrapper(self._run_internal)

    """ Rows, Columns """

    def _get_size(self) -> Tuple[int, int]:
        return self._screen.getmaxyx()

    def _edit_file(self, filename):
        has_render_thread = hasattr(self, "_render_thread")
        if has_render_thread:
            self._render_thread.pause()
        curses.def_prog_mode()
        curses.endwin()

        editor = os.environ.get("EDITOR", "nvim")
        subprocess.run([editor, filename])

        curses.reset_prog_mode()
        self._refresh_main_window_size()
        self._window.refresh()
        if has_render_thread:
            self._render_thread.unpause()

        # curses loses cursor state after endwin; reset it
        curses.curs_set(1)
        curses.curs_set(0)

    def add_popup(self, popup: BasePopup):
        self._popup_stack.append(popup)
        popup._set_parent(self)
        rows, cols = self._get_size()
        prows, pcols = popup._get_popup_size(rows, cols)

        row_start = (rows - prows) // 2
        col_start = (cols - pcols) // 2
        popup._update_window_size(prows, pcols, row_start, col_start)

    def remove_popup(self, popup: BasePopup):
        self._popup_stack.remove(popup)

    def pop_popup(self):
        if self._popup_stack:
            self.remove_popup(self._popup_stack[-1])


if __name__ == "__main__":
    MainWindow().run()
