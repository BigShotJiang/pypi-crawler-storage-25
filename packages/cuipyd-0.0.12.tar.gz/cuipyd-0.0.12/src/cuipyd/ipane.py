from enum import Enum
import curses
from cuipyd.mouse import MouseEvent
from cuipyd.utils.direction import Direction


class TitleStyle(Enum):

    BLOCK = 0
    TRAPEZOID = 1
    ROUNDED = 2


class IPane:

    def __init__(
        self,
        name=None,
        max_height=None,
        min_height=None,
        max_width=None,
        min_width=None,
        title_position=Direction.TOP_LEFT,
        overlap_title=True,
        show_title=None,
        title_style=TitleStyle.TRAPEZOID,
        padding=4,
        padding_left=None,
        padding_right=None,
        padding_top=None,
        padding_bottom=None,
        default_char=None,
    ):

        self._pane_parent = None
        self._is_active = True
        self._window = None
        self._name = name
        self._max_height_val = max_height
        self._min_height_val = min_height
        self._max_width_val = max_width
        self._min_width_val = min_width
        self._color_scheme = None
        self._title_position = title_position
        self._overlap_title = overlap_title
        self._title_style = title_style
        self._default_char = default_char

        if isinstance(show_title, bool):
            self._show_title = show_title
        elif show_title is None and self._name is not None:
            self._show_title = True
        else:
            self._show_title = False

        self._padding = padding
        self._padding_left = padding_left
        self._padding_right = padding_right
        self._padding_top = padding_top
        self._padding_bottom = padding_bottom

    @property
    def default_char(self):
        if self._default_char is not None:
            return self._default_char
        parent_char = self._parent.default_char
        if parent_char is not None:
            return parent_char
        return ' '

    def set_default_char(self, char):
        self._default_char = char

    def _set_title_position(self, new_position):
        self._title_position = new_position

    def _get_color_scheme(self):
        if self._color_scheme:
            return self._color_scheme
        else:
            return self._pane_parent._get_color_scheme()

    @property
    def _max_height(self):
        return self._max_height_val

    @property
    def _min_height(self):
        return self._min_height_val

    @property
    def _max_width(self):
        return self._max_width_val

    @property
    def _min_width(self):
        return self._min_width_val

    def _get_padding_inner(self, specific_padding):
        if specific_padding is not None:
            return specific_padding
        elif self._padding is not None:
            return self._padding
        return 0

    def _get_padding_left(self):
        return self._get_padding_inner(self._padding_left)

    def _get_padding_right(self):
        return self._get_padding_inner(self._padding_right)

    def _get_padding_top(self):
        return self._get_padding_inner(self._padding_top)

    def _get_padding_bottom(self):
        return self._get_padding_inner(self._padding_bottom)

    def _has_padding(self) -> bool:
        pl = self._get_padding_left()
        pr = self._get_padding_right()
        pt = self._get_padding_top()
        pb = self._get_padding_bottom()
        return any(x != 0 for x in (pl, pr, pt, pb))

    def _get_name(self):
        if self._name:
            return self._name
        return ""

    @property
    def _parent(self):
        return self._pane_parent

    @property
    def _root(self):
        return self._parent._root

    def is_rendering_paused(self):
        if not self._root._delayed_rendering:
            if self._root._render_thread.is_paused():
                return True
        return False

    @property
    def delayed_rendering(self):
        return self._root._delayed_rendering

    def _has_window(self):
        return self._window is not None

    @property
    def _base_screen(self):
        return self._root._screen

    def _set_parent(self, parent):
        self._pane_parent = parent
        self._window = self._parent._window.derwin(0, 0)

    def _refresh(self):
        pass

    def _render_frame(self, time_delta):
        pass

    def _set_active(self, is_active):
        self._is_active = is_active

    def _update_window_size(self, rows, cols, r_pos, c_pos):
        if not self._window:
            return
        with self._root._pause_rendering():
            del self._window
            self._window = self._parent._window.derwin(rows, cols, r_pos, c_pos)

    def _edit_file(self, filename):
        self._root._edit_file(filename)

    def _register_mouse_event(self, mouse_event: MouseEvent):
        pass

    def _get_raw_size(self):
        if not self._window:
            return 0, 0
        return self._window.getmaxyx()

    def _draw_title(self):
        if not self._show_title or self._name is None:
            return
        r, c = self._get_size()
        real_title = f" {self._name} "
        title_size = len(real_title)
        mod = self._get_color_scheme().default_mod()

        on_top = Direction.on_top(self._title_position)

        if on_top:
            row = 0
        else:
            row = r - 1

        if not self._overlap_title:
            self.add_str(" " * c, row, 0, mod=mod)

        col = 0
        if self._title_position in [
            Direction.TOP,
            Direction.BOTTOM,
        ]:
            col = (c - title_size) // 2
        elif Direction.on_right(self._title_position):
            col = c - title_size

        mod = self._get_color_scheme().default_mod(invert=True)
        mod = mod | curses.A_BOLD

        self.add_str(real_title, row, col, mod=mod)

        if self._title_style == TitleStyle.BLOCK:
            return

        left_cap = "◖"
        right_cap = "◗"
        if self._title_style == TitleStyle.TRAPEZOID:
            if Direction.on_top(self._title_position):
                left_cap = ""
                right_cap = ""
            else:
                left_cap = ""
                right_cap = ""

        has_right_cap = not Direction.on_right(self._title_position)
        has_left_cap = not Direction.on_left(self._title_position)

        cap_mod = self._get_color_scheme().default_mod()
        if has_left_cap:
            self.add_str(left_cap, row, col - 1, mod=cap_mod)
        if has_right_cap:
            self.add_str(right_cap, row, col + len(real_title), mod=cap_mod)

    def _get_size(self):
        r, c = self._get_raw_size()
        if self._show_title and not self._overlap_title:
            return r - 1, c
        return r, c

    def _get_raw_top_left(self):
        if not self._window:
            return 0, 0
        return self._window.getbegyx()

    def _get_top_left(self):
        return self._get_raw_top_left()

    def _shift_down_from_title(self):
        if (
            self._show_title
            and not self._overlap_title
            and self._title_position
            in [
                Direction.TOP_LEFT,
                Direction.TOP_RIGHT,
                Direction.TOP,
            ]
        ):
            return True
        return False

    def _row_col_tweak_amount(self):
        if self._shift_down_from_title():
            return (1, 0)
        return 0, 0

    def _tweak_row_col(self, row, col, reverse=False):
        dr, dc = self._row_col_tweak_amount()
        if reverse:
            dr = -dr
            dc = -dc
        return row + dr, col + dc

    def add_char(self, character, row, col, mod=None, raw=False):
        if self.is_rendering_paused():
            return
        if mod is None:
            mod = self._get_color_scheme().default_mod()
        row, col = self._tweak_row_col(row, col)
        if not raw:
            character = ord(character)
        try:
            self._window.addch(row, col, character, mod)
        except curses.error:
            pass

    def add_str(self, string, row, col, mod=None):
        if self.is_rendering_paused():
            return
        row, col = self._tweak_row_col(row, col)
        if mod is None:
            mod = self._get_color_scheme().default_mod()

        try:
            self._window.addstr(row, col, string, mod)
        except curses.error:
            pass
