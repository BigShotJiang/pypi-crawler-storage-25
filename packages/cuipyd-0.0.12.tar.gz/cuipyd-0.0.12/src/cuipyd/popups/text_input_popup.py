from typing import Callable
from cuipyd.pane import Pane
from cuipyd.popups.popup import BasePopup
from cuipyd.layouts.directional_layout import VLayout
from cuipyd.mouse import MouseEvent
from cuipyd.widgets.button_bar import ButtonBar
from cuipyd.widgets.spacer import Spacer
from cuipyd.widgets.text_input import TextInput


class _DescriptionPane(Pane):

    def __init__(self, text: str, **kwargs):
        kwargs.setdefault("max_height", 1)
        kwargs.setdefault("min_height", 1)
        super().__init__(**kwargs)
        self._text = text

    def render_frame(self, time_delta):
        rows, cols = self._get_size()
        if rows <= 0 or cols <= 0:
            return
        mod = self._get_color_scheme().default_mod()
        self.add_str(" " * cols, 0, 0, mod)
        self.add_str(self._text[:cols], 0, 0, mod)


class TextInputPopup(BasePopup):

    def __init__(
        self,
        description: str = None,
        multiline: bool = False,
        on_confirm: Callable[[str], None] = None,
        on_cancel: Callable[[], None] = None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self._on_confirm = on_confirm
        self._on_cancel = on_cancel
        self._inner_layout = VLayout()
        self._layout_initialized = False

        height_kwargs = {} if multiline else {"min_height": 1, "max_height": 1}
        enter_kwargs = {} if multiline else {"on_enter": lambda _: self._confirm()}
        self._text_input = TextInput(multiline=multiline, **height_kwargs, **enter_kwargs)

        self._description_pane = _DescriptionPane(description) if description else None
        self._top_spacer = Spacer()
        self._middle_spacer = Spacer()
        self._spacer = Spacer()  # flexible: fills gap and pushes buttons to bottom

        self._button_bar = ButtonBar(
            [
                ("Cancel", self._cancel),
                ("Confirm", self._confirm),
            ]
        )

    def _confirm(self):
        if self._on_confirm:
            self._on_confirm(self._text_input.text)
        self.close()

    def _cancel(self):
        if self._on_cancel:
            self._on_cancel()
        self.close()

    def close(self):
        self._root.pop_focus(self._text_input)
        super().close()

    def _update_window_size(self, rows, cols, r_pos, c_pos):
        super()._update_window_size(rows, cols, r_pos, c_pos)
        content_rows, content_cols = self._get_size()
        if content_rows <= 0 or content_cols <= 0:
            return

        if not self._layout_initialized:
            self._layout_initialized = True
            self._inner_layout._set_parent(self)
            self._inner_layout._add_child(self._top_spacer)
            if self._description_pane:
                self._inner_layout._add_child(self._description_pane)
            self._inner_layout._add_child(self._middle_spacer)
            self._inner_layout._add_child(self._text_input)
            self._inner_layout._add_child(self._spacer)
            self._inner_layout._add_child(self._button_bar)
            self._root.push_focus(self._text_input)

        margin = 2
        self._inner_layout._update_window_size(
            content_rows,
            max(1, content_cols - 2 * margin),
            1,
            1 + margin,
        )

    def _register_mouse_event(self, mouse_event: MouseEvent):
        super()._register_mouse_event(mouse_event)
        if not mouse_event.is_null and self._layout_initialized:
            self._inner_layout._register_mouse_event(mouse_event)

    def render_frame(self, time_delta):
        super().render_frame(time_delta)
        if self._layout_initialized:
            self._inner_layout._render_frame(time_delta)
