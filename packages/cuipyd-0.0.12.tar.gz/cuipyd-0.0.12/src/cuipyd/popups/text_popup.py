from typing import Callable, Dict, List, Optional
from cuipyd.mouse import MouseEvent
from cuipyd.popups.popup import BasePopup
from cuipyd.utils.direction import Direction


class TextPopup(BasePopup):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self._text = kwargs.get("text")
        self._alignment = kwargs.get("alignment", Direction.TOP_LEFT)
        self._confirm_text = kwargs.get("confirm_text", "Ok")
        self._cancel_text = kwargs.get("cancel_text", "Cancel")
        self._has_cancel = kwargs.get("has_cancel", True)
        self._on_cancel = kwargs.get("on_cancel", lambda x: None)
        self._on_confirm = kwargs.get("on_confirm", lambda x: None)
        self._buttons: Dict[str, Optional[Callable[[], None]]] = kwargs.get(
            "buttons",
            {"Cancel": lambda: self.cancel_pressed(), "Ok": lambda: self.ok_pressed()},
        )
        self._button_hovered = None

    def ok_pressed(self):
        self.close()

    def cancel_pressed(self):
        self.close()

    def set_text(self, text):
        self._text = text

    def create_lines(self, cols: int) -> List[str]:
        words = self._text.split()
        lines = []
        cur_line = ""
        max_len = cols - 2
        for word in words:
            if len(cur_line) + len(word) + 1 < max_len:
                cur_line += f" {word}"
            else:
                lines.append(cur_line)
                cur_line = ""

        if cur_line:
            lines.append(cur_line)
        return lines

    def write_lines(self, lines):
        rows, cols = self._get_size()
        mod = self._get_color_scheme().default_mod()

        start_row = 0
        if len(lines) < rows:
            if Direction.on_top(self._alignment):
                start_row = 1
            elif Direction.on_bottom(self._alignment):
                start_row = rows - (len(lines) + 1)
            else:
                start_row = (rows - len(lines)) // 2

        for line_ind in range(len(lines)):
            line = lines[line_ind]
            row = start_row + line_ind
            if Direction.on_left(self._alignment):
                col = 1
            elif Direction.on_right(self._alignment):
                col = cols - (len(line) + 1)
            else:
                col = (cols - len(line)) // 2
            self.add_str(line, row, col, mod=mod)

    def draw_buttons(self):
        r, c = self._get_size()
        end_col = c - 2
        box_row = r - 3
        for text, fn in reversed(self._buttons.items()):
            mod = self._get_color_scheme().default_mod()
            if text == self._button_hovered:
                mod = self._get_color_scheme().default_mod(invert=True)
            box_cols = len(text) + 4
            box_rows = 3
            box_col = end_col - box_cols
            self._draw_box(box_row, box_col, box_rows, box_cols, mod=mod)
            self.add_str(f" {text} ", box_row, end_col - (box_cols), mod=mod)
            end_col -= box_cols + 2

    def render_frame(self, time_delta):
        r, c = self._get_size()
        if self._text is not None:
            lines = self.create_lines(c)
            self.write_lines(lines)

        self.draw_buttons()
        self._draw_border()
        self._refresh()

    def _register_mouse_event(self, mouse_event: MouseEvent):
        super()._register_mouse_event(mouse_event)

        row = mouse_event.row
        col = mouse_event.column
        y, x = self._get_raw_size()

        r, c = self._get_size()
        end_col = c - 2
        box_row = r - 3

        if row < box_row - 1 or row > box_row + 1:
            self._button_hovered = None
            return

        for text, fn in reversed(self._buttons.items()):
            box_cols = len(text) + 4
            box_col = end_col - box_cols
            if col < end_col - 1 and col > box_col - 2:
                self._button_hovered = text
                if mouse_event.is_click() and fn is not None:
                    fn()
                return
            end_col -= box_cols + 2

        self._button_hovered = None
