import curses
from enum import Enum
from cuipyd.pane import Pane
from cuipyd.mouse import MouseEvent, MouseEventType


class PopupBorderStyle(Enum):
    DEFAULT = 0
    BLOCK = 1
    CHECKER = 2
    SMALL_BLOCK = 3
    BARBED = 4
    ANGULAR = 5


class BasePopup(Pane):

    def __init__(
        self,
        title=None,
        name=None,
        max_height=None,
        min_height=None,
        max_width=None,
        min_width=None,
        row_percent_size=None,
        col_percent_size=None,
        border_style=PopupBorderStyle.DEFAULT,
        has_exit_button=True,
        **kwargs,
    ):
        super().__init__(
            name=name,
            max_height=max_height,
            min_height=min_height,
            max_width=max_width,
            min_width=min_width,
        )
        self.title = title
        self._row_percent_size = row_percent_size
        self._col_percent_size = col_percent_size
        self._exit_highlighted = False
        self._border_style = border_style
        self._has_exit_button = has_exit_button

    def _mouse_focus_ended(self):
        self._exit_highlighted = False

    def _register_mouse_event(self, mouse_event: MouseEvent):
        row = mouse_event.row
        col = mouse_event.column
        y, x = self._get_raw_size()

        if self._has_exit_button:
            if row == 0 and col in [0, 1, 2]:
                self._exit_highlighted = True
                if mouse_event.event_type == MouseEventType.CLICKED:
                    self.close()
            else:
                self._exit_highlighted = False

        if row in [0, y - 1] or col in [0, x - 1]:
            mouse_event.nullify()
            return
        mouse_event.row -= 1
        mouse_event.column -= 1

    def _pre_close(self):
        pass

    def close(self):
        self._pre_close()
        self._parent.remove_popup(self)

    def _get_popup_size(self, parent_rows, parent_cols):
        row_pct = self._row_percent_size if self._row_percent_size else 0.6
        col_pct = self._col_percent_size if self._col_percent_size else 0.75

        num_rows = int(row_pct * parent_rows)
        num_cols = int(col_pct * parent_cols)

        if self._min_height and num_rows < self._min_height:
            num_rows = self._min_height
        if self._max_height and num_rows > self._max_height:
            num_rows = self._max_height

        if self._min_width and num_cols < self._min_width:
            num_cols = self._min_width
        if self._max_width and num_cols > self._max_width:
            num_cols = self._max_width

        return min(num_rows, parent_rows), min(num_cols, parent_cols)

    def _get_size(self):
        raw_rows, raw_cols = self._get_raw_size()
        return raw_rows - 2, raw_cols - 2

    def _tweak_row_col(self, row, col):
        return row + 1, col + 1

    def _draw_title(self):
        if not self._show_title or self._name is None:
            return

        title_str = f" {self._name} "
        mod = self._get_color_scheme().default_mod(invert=True)
        mod = mod | curses.A_BOLD
        self._window.addstr(0, 3, title_str, mod)

    def _get_border_mod(self):
        if self._border_style in (PopupBorderStyle.BLOCK, PopupBorderStyle.ANGULAR):
            return self._get_color_scheme().default_mod(invert=True)
        return self._get_color_scheme().default_mod()

    def _draw_border(self):
        y, x = self._get_raw_size()
        self._draw_box(0, 0, y, x, self._border_style)
        if self._has_exit_button:
            if self._exit_highlighted:
                mod = self._get_color_scheme().header_mod(invert=True)
            else:
                mod = self._get_border_mod()
            self._window.addstr(0, 0, "[X]", mod)
        self._draw_title()

    def render_frame(self, time_delta):
        super().render_frame(time_delta)
        self._draw_border()
