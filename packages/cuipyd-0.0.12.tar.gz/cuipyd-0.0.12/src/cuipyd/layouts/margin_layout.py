
from cuipyd.mouse import MouseEvent
from cuipyd.layouts.layout import BaseLayout


class PaddingLayout(BaseLayout):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._padding_left = kwargs.get('padding_left', None)
        self._padding_right = kwargs.get('padding_right', None)
        self._padding_top = kwargs.get('padding_top', None)
        self._padding_bottom = kwargs.get('padding_bottom', None)
        self._padding = kwargs.get('padding', None)

    def _has_padding(self) -> bool:
        return False

    def _add_child(self, child, **kwargs):
        if len(self._children) >= 1:
            raise Exception("PaddingLayout can only have 1 child")
        child._set_parent(self)
        child._padding_left = None
        child._padding_right = None
        child._padding_top = None
        child._padding_bottom = None
        child._padding = None
        self._children.append(child)
        self._resize()

    @property
    def _child(self):
        return self._children[0]

    def _resize(self):
        y, x = self._get_raw_size()
        pl = self._get_padding_left()
        pr = self._get_padding_right()
        pt = self._get_padding_top()
        pb = self._get_padding_bottom()

        if self._shift_down_from_title():
            y -= 1

        child_width = x - (pr + pl)
        child_height = y - (pt + pb)

        if child_height < 0:
            child_height = 0
        if child_width < 0:
            child_width = 0

        self._child._update_window_size(child_height, child_width, pt, pl)

    def _register_mouse_event(self, mouse_event: MouseEvent):
        y, x = self._get_raw_size()
        r = mouse_event.row
        c = mouse_event.column
        if c < self._get_padding_left() or c > x - self._get_padding_right():
            return
        if r < self._get_padding_top() or r > y - self._get_padding_bottom():
            return
        mouse_event.row -= self._get_padding_top()
        mouse_event.column -= self._get_padding_left()

        if self._child._shift_down_from_title():
            new_r, new_c = self._child._tweak_row_col(
                mouse_event.row, mouse_event.column, reverse=True
            )
            mouse_event.row = new_r
            mouse_event.column = new_c

        self._child._register_mouse_event(mouse_event)

    def _render_frame(self, time_delta):
        rows, cols = self._get_size()

        line = self.default_char * cols
        for r in range(rows):
            self.add_str(line, r, 0)

        super()._render_frame(time_delta)


