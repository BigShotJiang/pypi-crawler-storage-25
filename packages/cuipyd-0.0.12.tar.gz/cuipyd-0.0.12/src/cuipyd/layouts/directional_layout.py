from cuipyd.ipane import IPane
from cuipyd.layouts.layout import BaseLayout
from cuipyd.layouts.margin_layout import PaddingLayout
from cuipyd.mouse import MouseEvent


class DirectionalLayout(BaseLayout):

    def __init__(
        self,
        name=None,
        max_height=None,
        min_height=None,
        max_width=None,
        min_width=None,
        **kwargs,
    ):
        super().__init__(
            name=name,
            max_height=max_height,
            min_height=min_height,
            max_width=max_width,
            min_width=min_width,
            **kwargs,
        )
        self._children = []
        self._weights = []
        self._horizontal = True

    @property
    def _max_height(self):
        if self._horizontal:
            if not self._children:
                return self._max_height_val
            max_heights = [x._max_height for x in self._children]
            if any(max_heights):
                return min([x for x in max_heights if x])
        return self._max_height_val

    @property
    def _min_height(self):
        if self._horizontal:
            if not self._children:
                return self._min_height_val
            min_heights = [x._min_height for x in self._children]
            if any(min_heights):
                return max([x for x in min_heights if x])
        return self._min_height_val

    @property
    def _max_width(self):
        if not self._horizontal:
            if not self._children:
                return self._max_width_val
            max_widths = [x._max_width for x in self._children]
            if any(max_widths):
                return min([x for x in max_widths if x])
        return self._max_width_val

    @property
    def _min_width(self):
        if not self._horizontal:
            if not self._children:
                return self._min_width_val
            min_widths = [x._min_width for x in self._children]
            if any(min_widths):
                return max([x for x in min_widths if x])
        return self._min_width_val

    def _add_child(self, child: IPane, **kwargs):
        if child._has_padding():
            layout = PaddingLayout(
                padding_left=child._padding_left,
                padding_right=child._padding_right,
                padding_top=child._padding_top,
                padding_bottom=child._padding_bottom,
                padding=child._padding,
            )
            # Propagate size constraints so the parent layout respects them on the wrapper
            layout._max_height_val = child._max_height_val
            layout._min_height_val = child._min_height_val
            layout._max_width_val = child._max_width_val
            layout._min_width_val = child._min_width_val
            self._add_child(layout, **kwargs)
            layout._add_child(child)
            return

        self._weights.append(int(kwargs["weight"]) if kwargs.get("weight") else 1)
        super()._add_child(child, **kwargs)
        self._resize()

    def _update_window_size(self, rows, cols, r_pos, c_pos):
        super()._update_window_size(rows, cols, r_pos, c_pos)
        self._resize()

    def _resize(self):
        y, x = self._get_raw_size()
        if self._shift_down_from_title():
            y -= 1

        if self._horizontal:
            screen_sizes = self._get_pane_sizes(
                x, self._weights, self._children, vertical=False
            )
            start_col = 0
            row_pos = 0
            if self._shift_down_from_title():
                row_pos += 1
            for i in range(len(self._children)):
                child = self._children[i]
                width = screen_sizes[i]
                child._update_window_size(y, width, row_pos, start_col)
                start_col += width
        else:
            screen_sizes = self._get_pane_sizes(
                y, self._weights, self._children, vertical=True
            )
            start_row = 0
            if self._shift_down_from_title():
                start_row += 1
            for i in range(len(self._children)):
                child = self._children[i]
                height = screen_sizes[i]
                child._update_window_size(height, x, start_row, 0)
                start_row += height

    @staticmethod
    def _get_pane_sizes(size, weights, children, vertical=False):
        output_sizes = DirectionalLayout._get_start_weights(size, weights, children)

        if len(children) == 1:
            return [size]

        if vertical:
            mins = [c._min_height for c in children]
            maxs = [c._max_height for c in children]
        else:
            mins = [c._min_width for c in children]
            maxs = [c._max_width for c in children]

        for min_index in range(len(mins)):
            min_val = mins[min_index]
            if min_val is None:
                continue
            if output_sizes[min_index] < min_val:
                output_sizes[min_index] = min_val
                check_index = 0
                total = sum(output_sizes)
                skipped = 0
                while total != size:
                    new_check_size = output_sizes[check_index] - 1
                    if check_index == min_index or (
                        mins[check_index] is not None
                        and new_check_size < mins[check_index]
                    ):
                        check_index = (check_index + 1) % len(output_sizes)
                        skipped += 1
                        if skipped >= len(output_sizes):
                            break  # all children are at their minimum; can't shrink further
                        continue
                    skipped = 0
                    output_sizes[check_index] = new_check_size
                    total -= 1
                    check_index = (check_index + 1) % len(output_sizes)

        for max_index in range(len(maxs)):
            max_val = maxs[max_index]
            if max_val is None:
                continue
            if output_sizes[max_index] > max_val:
                output_sizes[max_index] = max_val
                check_index = 0
                total = sum(output_sizes)
                skipped = 0
                while total != size:
                    new_check_size = output_sizes[check_index] + 1
                    if check_index == max_index or (
                        maxs[check_index] is not None
                        and new_check_size > maxs[check_index]
                    ):
                        check_index = (check_index + 1) % len(output_sizes)
                        skipped += 1
                        if skipped >= len(output_sizes):
                            break  # all children are at their maximum; leftover space stays unused
                        continue
                    skipped = 0
                    output_sizes[check_index] = new_check_size
                    total += 1
                    check_index = (check_index + 1) % len(output_sizes)

        return output_sizes

    @staticmethod
    def _get_start_weights(size, weights, children):
        if len(children) == 0:
            return []

        total_weight = sum(weights)

        base_val = size // total_weight
        output_sizes = []
        for w in weights:
            output_sizes.append(w * base_val)

        total_size = sum(output_sizes)
        if total_size < size:
            diff = size - total_size
            for i in range(diff):
                output_sizes[i % len(output_sizes)] += 1

        return output_sizes

    def _register_mouse_event(self, mouse_event):
        if not self._children:
            return
        y, x = self._get_raw_size()
        if self._horizontal:
            size, attr, vertical = x, "column", False
        else:
            if self._shift_down_from_title():
                y -= 1
            size, attr, vertical = y, "row", True

        screen_sizes = self._get_pane_sizes(
            size, self._weights, self._children, vertical=vertical
        )
        coord = getattr(mouse_event, attr)

        cumulative = 0
        screen_index = -1
        for i, sz in enumerate(screen_sizes):
            if coord < cumulative + sz:
                screen_index = i
                break
            cumulative += sz

        clear_event = MouseEvent.get_null()

        if screen_index == -1:
            for child in self._children:
                child._register_mouse_event(clear_event)
            return

        setattr(mouse_event, attr, coord - cumulative)

        for i, child in enumerate(self._children):
            if i == screen_index:
                if child._shift_down_from_title():
                    new_r, new_c = child._tweak_row_col(
                        mouse_event.row, mouse_event.column, reverse=True
                    )
                    mouse_event.row, mouse_event.column = new_r, new_c
                child._register_mouse_event(mouse_event)
            else:
                child._register_mouse_event(clear_event)


class HLayout(DirectionalLayout):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)


class VLayout(DirectionalLayout):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._horizontal = False
