from enum import Enum
from cuipyd.pane import Pane
from cuipyd.mouse import MouseEvent


class ButtonStyle(Enum):
    DEFAULT = 0
    DANGER = 1


class Button(Pane):

    def __init__(self, text="OK", on_click=None, style=ButtonStyle.DEFAULT, **kwargs):
        kwargs.setdefault('min_width', len(text) + 4)
        kwargs.setdefault('min_height', 3)
        super().__init__(**kwargs)
        self._text = text
        self._on_click = on_click
        self._style = style
        self._hovered = False

    def _get_mod(self):
        cs = self._get_color_scheme()
        if self._style == ButtonStyle.DANGER:
            return cs.header_mod(invert=self._hovered)
        return cs.default_mod(invert=self._hovered)

    def render_frame(self, time_delta):
        rows, cols = self._get_size()
        if rows <= 0 or cols <= 0:
            return
        mod = self._get_mod()

        for r in range(rows):
            self.add_str(' ' * cols, r, 0, mod)

        if rows >= 3 and cols >= 4:
            self._draw_box(0, 0, rows, cols, mod=mod)
            text = self._text[:cols - 2]
            self.add_str(text, rows // 2, (cols - len(text)) // 2, mod)

    def _register_mouse_event(self, mouse_event: MouseEvent):
        if mouse_event.is_null:
            self._hovered = False
            return
        self._hovered = True
        if mouse_event.is_click() and self._on_click:
            self._on_click()
