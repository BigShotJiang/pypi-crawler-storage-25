from cuipyd.pane import Pane
from cuipyd.mouse import MouseEvent


class FocusablePane(Pane):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._focused = False

    def _register_mouse_event(self, mouse_event: MouseEvent):
        if mouse_event.is_click():
            self._root.push_focus(self)

    def handle_key(self, ch: int) -> bool:
        return False

    def _on_focus_gained(self):
        pass

    def _on_focus_lost(self):
        pass
