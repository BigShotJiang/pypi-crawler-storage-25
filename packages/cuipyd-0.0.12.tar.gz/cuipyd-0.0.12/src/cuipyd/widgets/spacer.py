from cuipyd.pane import Pane


class Spacer(Pane):
    """Fills its allocated space with background color. Constrain with min_height/max_height or min_width/max_width."""

    def render_frame(self, time_delta):
        rows, cols = self._get_size()
        if rows <= 0 or cols <= 0:
            return
        mod = self._get_color_scheme().default_mod()
        for r in range(rows):
            self.add_str(' ' * cols, r, 0, mod)
