from typing import Callable, List, Tuple, Union
from cuipyd.layouts.directional_layout import HLayout
from cuipyd.widgets.button import Button
from cuipyd.widgets.spacer import Spacer


class ButtonBar(HLayout):

    def __init__(
        self,
        buttons: List[Union[Button, Tuple[str, Callable]]] = None,
        align: str = 'right',
        **kwargs,
    ):
        kwargs.setdefault('max_height', 3)
        kwargs.setdefault('min_height', 3)
        super().__init__(**kwargs)
        self._padding = None  # prevent PaddingLayout wrapping; height constraints would be lost
        self._align = align
        self._pending_buttons = list(buttons) if buttons else []
        self._buttons_initialized = False

    def _update_window_size(self, rows, cols, r_pos, c_pos):
        super()._update_window_size(rows, cols, r_pos, c_pos)
        if not self._buttons_initialized and self._pending_buttons and rows > 0 and cols > 0:
            self._buttons_initialized = True
            pending = self._pending_buttons
            self._pending_buttons = []
            if self._align == 'right':
                self._add_child(Spacer())
            for item in pending:
                if isinstance(item, Button):
                    self._add_child(item)
                elif isinstance(item, tuple) and len(item) == 2:
                    text, callback = item
                    self._add_child(Button(text, on_click=callback, max_width=len(text) + 4))
                else:
                    raise ValueError(f"Expected Button or (text, callable) tuple, got {type(item)}")

    @classmethod
    def confirm_cancel(cls, on_confirm: Callable = None, on_cancel: Callable = None, **kwargs) -> 'ButtonBar':
        return cls([("Cancel", on_cancel), ("OK", on_confirm)], **kwargs)
