import curses
from cuipyd.layouts.layout import BaseLayout
from cuipyd.mouse import MouseEvent, MouseButton, MouseMod


class ScrollView(BaseLayout):

    def __init__(self, virtual_height=None, virtual_width=None, viewport_aware=False, **kwargs):
        super().__init__(**kwargs)
        self._virtual_height = virtual_height
        self._virtual_width = virtual_width
        self._viewport_aware = viewport_aware
        self._scroll_row = 0
        self._scroll_col = 0
        self._pad = None

    @property
    def scroll_offset(self):
        return (self._scroll_row, self._scroll_col)

    @property
    def _child(self):
        return self._children[0] if self._children else None

    def _add_child(self, child, **kwargs):
        if self._children:
            raise Exception("ScrollView can only have 1 child")
        child._pane_parent = self
        child._window = None
        self._children.append(child)
        self._resize()

    def _resize(self):
        if not self._child or not self._window:
            return
        view_h, view_w = self._get_raw_size()
        if view_h <= 0 or view_w <= 0:
            return

        if not self._viewport_aware:
            virt_h = max(view_h, self._virtual_height or view_h)
            virt_w = max(view_w, self._virtual_width or view_w)
            self._pad = curses.newpad(virt_h, virt_w)
            self._child._window = self._pad
            self._scroll_row = max(0, min(self._scroll_row, virt_h - view_h))
            self._scroll_col = max(0, min(self._scroll_col, virt_w - view_w))
        else:
            self._child._window = self._window.derwin(view_h, view_w, 0, 0)

    def _update_window_size(self, rows, cols, r_pos, c_pos):
        super()._update_window_size(rows, cols, r_pos, c_pos)
        self._resize()

    def scroll_vertical(self, amt: int):
        view_h = self._get_raw_size()[0]
        virt_h = self._virtual_height or view_h
        self._scroll_row = max(0, min(self._scroll_row - amt, virt_h - view_h))

    def scroll_horizontal(self, amt: int):
        view_w = self._get_raw_size()[1]
        virt_w = self._virtual_width or view_w
        self._scroll_col = max(0, min(self._scroll_col + amt, virt_w - view_w))

    def _render_frame(self, time_delta):
        if not self._is_active or not self._has_window() or not self._child:
            return
        if self._child._is_active:
            self._child._render_frame(time_delta)
        self._refresh()

    def _refresh(self):
        if not self._child or not self._window:
            return
        if not self._viewport_aware and self._pad:
            view_h, view_w = self._get_raw_size()
            abs_y, abs_x = self._get_raw_top_left()
            try:
                self._pad.refresh(
                    self._scroll_row, self._scroll_col,
                    abs_y, abs_x,
                    min(curses.LINES - 1, abs_y + view_h - 1),
                    min(curses.COLS - 1, abs_x + view_w - 1),
                )
            except curses.error:
                pass
        else:
            if self._child._window:
                try:
                    self._child._window.refresh()
                except curses.error:
                    pass

    def _register_mouse_event(self, mouse_event: MouseEvent):
        if not self._child:
            return
        if mouse_event.is_null:
            self._child._register_mouse_event(mouse_event)
            return

        if mouse_event.mod == MouseMod.NONE:
            if mouse_event.button == MouseButton.WHEEL_DOWN:
                self.scroll_vertical(-1)
                return
            if mouse_event.button == MouseButton.WHEEL_UP:
                self.scroll_vertical(1)
                return
        elif mouse_event.mod == MouseMod.CONTROL:
            if mouse_event.button == MouseButton.WHEEL_DOWN:
                self.scroll_horizontal(1)
                return
            if mouse_event.button == MouseButton.WHEEL_UP:
                self.scroll_horizontal(-1)
                return

        if not self._viewport_aware:
            mouse_event.row += self._scroll_row
            mouse_event.column += self._scroll_col
        self._child._register_mouse_event(mouse_event)
