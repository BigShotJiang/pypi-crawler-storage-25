import curses
from typing import Callable, List
from cuipyd.mouse import MouseEvent
from cuipyd.widgets.focusable_pane import FocusablePane

_CTRL_A = 1
_CTRL_E = 5
_CTRL_K = 11
_BACKSPACE = (curses.KEY_BACKSPACE, 127, 8)
# Ctrl+Left / Ctrl+Right arrive as escape sequences on most terminals
_CTRL_LEFT = 545   # common value; terminal-dependent
_CTRL_RIGHT = 560


def _word_start_left(line: str, col: int) -> int:
    col = min(col, len(line))
    i = col - 1
    while i > 0 and line[i - 1] == ' ':
        i -= 1
    while i > 0 and line[i - 1] != ' ':
        i -= 1
    return i


def _word_start_right(line: str, col: int) -> int:
    i = col
    while i < len(line) and line[i] != ' ':
        i += 1
    while i < len(line) and line[i] == ' ':
        i += 1
    return i


class TextInput(FocusablePane):

    def __init__(
        self,
        multiline: bool = False,
        on_enter: Callable[[str], None] = None,
        on_change: Callable[[str], None] = None,
        placeholder: str = "",
        **kwargs,
    ):
        super().__init__(**kwargs)
        self._multiline = multiline
        self._on_enter = on_enter
        self._on_change = on_change
        self._placeholder = placeholder
        self._lines: List[str] = [""]
        self._cursor_row = 0
        self._cursor_col = 0
        self._scroll_row = 0
        self._scroll_col = 0

    # ── Public API ──────────────────────────────────────────────────────────

    @property
    def text(self) -> str:
        return "\n".join(self._lines)

    def set_text(self, text: str):
        self._lines = text.split("\n") if text else [""]
        if not self._multiline:
            self._lines = [self._lines[0]]
        self._cursor_row = 0
        self._cursor_col = 0
        self._scroll_row = 0
        self._scroll_col = 0

    def clear(self):
        self.set_text("")

    # ── Rendering ────────────────────────────────────────────────────────────

    def render_frame(self, time_delta):
        rows, cols = self._get_size()
        if rows <= 0 or cols <= 0:
            return

        cs = self._get_color_scheme()
        bg_mod = cs.alternate_mod(invert=self._focused)
        cursor_mod = cs.default_mod(invert=True)
        placeholder_mod = cs.default_mod()

        empty = self._lines == [""]

        if empty and not self._focused and self._placeholder:
            # Fill background
            for r in range(rows):
                self.add_str(' ' * cols, r, 0, bg_mod)
            self.add_str(self._placeholder[:cols], 0, 0, placeholder_mod)
            return

        for r in range(rows):
            self.add_str(' ' * cols, r, 0, bg_mod)

        visible_rows = rows
        first_row = self._scroll_row

        for screen_r in range(visible_rows):
            data_r = first_row + screen_r
            if data_r >= len(self._lines):
                break
            line = self._lines[data_r]
            visible = line[self._scroll_col:self._scroll_col + cols]
            self.add_str(visible, screen_r, 0, bg_mod)

            if self._focused and data_r == self._cursor_row:
                cursor_screen_col = self._cursor_col - self._scroll_col
                if 0 <= cursor_screen_col < cols:
                    ch = line[self._cursor_col] if self._cursor_col < len(line) else ' '
                    self.add_str(ch, screen_r, cursor_screen_col, cursor_mod)

    # ── Key handling ─────────────────────────────────────────────────────────

    def handle_key(self, ch: int) -> bool:
        if ch == 27:
            self._root.pop_focus(self)
            return False  # let _process_character see Escape too

        if ch in _BACKSPACE:
            self._backspace()
        elif ch == curses.KEY_DC:
            self._delete_forward()
        elif ch == curses.KEY_LEFT:
            self._move_left()
        elif ch == curses.KEY_RIGHT:
            self._move_right()
        elif ch == curses.KEY_UP:
            if not self._multiline:
                return False
            self._move_up()
        elif ch == curses.KEY_DOWN:
            if not self._multiline:
                return False
            self._move_down()
        elif ch == curses.KEY_HOME or ch == _CTRL_A:
            self._cursor_col = 0
            self._scroll_col = 0
        elif ch == curses.KEY_END or ch == _CTRL_E:
            self._cursor_col = len(self._lines[self._cursor_row])
            self._update_scroll()
        elif ch == _CTRL_K:
            self._kill_to_end()
        elif ch == _CTRL_LEFT:
            self._cursor_col = _word_start_left(self._lines[self._cursor_row], self._cursor_col)
            self._update_scroll()
        elif ch == _CTRL_RIGHT:
            self._cursor_col = _word_start_right(self._lines[self._cursor_row], self._cursor_col)
            self._update_scroll()
        elif ch in (curses.KEY_ENTER, 10, 13):
            if self._multiline:
                self._insert_newline()
            else:
                if self._on_enter:
                    self._on_enter(self.text)
                    return True
                return False
        elif 32 <= ch <= 126:
            self._insert_char(chr(ch))
        else:
            return False

        if self._on_change:
            self._on_change(self.text)
        return True

    # ── Editing helpers ───────────────────────────────────────────────────────

    def _insert_char(self, ch: str):
        row, col = self._cursor_row, self._cursor_col
        line = self._lines[row]
        self._lines[row] = line[:col] + ch + line[col:]
        self._cursor_col += 1
        self._update_scroll()

    def _insert_newline(self):
        row, col = self._cursor_row, self._cursor_col
        line = self._lines[row]
        self._lines[row] = line[:col]
        self._lines.insert(row + 1, line[col:])
        self._cursor_row += 1
        self._cursor_col = 0
        self._scroll_col = 0
        self._update_scroll()

    def _backspace(self):
        row, col = self._cursor_row, self._cursor_col
        if col > 0:
            line = self._lines[row]
            self._lines[row] = line[:col - 1] + line[col:]
            self._cursor_col -= 1
            self._update_scroll()
        elif row > 0 and self._multiline:
            prev = self._lines[row - 1]
            self._cursor_col = len(prev)
            self._lines[row - 1] = prev + self._lines[row]
            self._lines.pop(row)
            self._cursor_row -= 1
            self._update_scroll()

    def _delete_forward(self):
        row, col = self._cursor_row, self._cursor_col
        line = self._lines[row]
        if col < len(line):
            self._lines[row] = line[:col] + line[col + 1:]
        elif row < len(self._lines) - 1 and self._multiline:
            self._lines[row] = line + self._lines[row + 1]
            self._lines.pop(row + 1)

    def _kill_to_end(self):
        row, col = self._cursor_row, self._cursor_col
        line = self._lines[row]
        if col < len(line):
            self._lines[row] = line[:col]
        elif row < len(self._lines) - 1 and self._multiline:
            self._lines[row] = line + self._lines[row + 1]
            self._lines.pop(row + 1)

    def _move_left(self):
        if self._cursor_col > 0:
            self._cursor_col -= 1
        elif self._cursor_row > 0 and self._multiline:
            self._cursor_row -= 1
            self._cursor_col = len(self._lines[self._cursor_row])
        self._update_scroll()

    def _move_right(self):
        line = self._lines[self._cursor_row]
        if self._cursor_col < len(line):
            self._cursor_col += 1
        elif self._cursor_row < len(self._lines) - 1 and self._multiline:
            self._cursor_row += 1
            self._cursor_col = 0
        self._update_scroll()

    def _move_up(self):
        if self._cursor_row > 0:
            self._cursor_row -= 1
            self._cursor_col = min(self._cursor_col, len(self._lines[self._cursor_row]))
            self._update_scroll()

    def _move_down(self):
        if self._cursor_row < len(self._lines) - 1:
            self._cursor_row += 1
            self._cursor_col = min(self._cursor_col, len(self._lines[self._cursor_row]))
            self._update_scroll()

    # ── Scroll tracking ───────────────────────────────────────────────────────

    def _update_scroll(self):
        rows, cols = self._get_size()

        if self._multiline:
            if self._cursor_row < self._scroll_row:
                self._scroll_row = self._cursor_row
            elif self._cursor_row >= self._scroll_row + rows:
                self._scroll_row = self._cursor_row - rows + 1

        if self._cursor_col < self._scroll_col:
            self._scroll_col = self._cursor_col
        elif cols > 0 and self._cursor_col >= self._scroll_col + cols:
            self._scroll_col = self._cursor_col - cols + 1

    # ── Focus hooks ───────────────────────────────────────────────────────────

    def _on_focus_gained(self):
        self._focused = True

    def _on_focus_lost(self):
        self._focused = False
