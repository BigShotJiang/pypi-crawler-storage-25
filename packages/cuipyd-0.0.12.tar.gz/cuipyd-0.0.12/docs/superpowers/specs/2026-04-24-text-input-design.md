# TextInput Widget Design

## Overview

Two new components plus changes to `MainWindow`:

1. **Focus system** — `MainWindow` focus stack + `FocusablePane` base class
2. **`TextInput(FocusablePane)`** — single-line and multi-line text input widget

---

## Focus System

### MainWindow changes

`MainWindow` gains `_focus_stack: List[FocusablePane]` alongside `_popup_stack`.

```python
def push_focus(self, widget: FocusablePane) -> None
def pop_focus(self, widget: FocusablePane = None) -> None  # pops top if widget=None
```

`push_focus` appends the widget and calls `widget._on_focus_gained()`. `pop_focus` removes the widget (top by default), calls `widget._on_focus_lost()`, and sets `widget._focused = False`.

**Mouse event change:** `_register_mouse_event` gains a pre-routing step. If `_focus_stack` is non-empty, check whether the click lands outside the top widget's screen bounds using `_get_raw_top_left()` + `_get_raw_size()`. If outside → call `pop_focus()` before routing the event normally.

**Key routing change in `_run_internal`:**

```python
if self._focus_stack:
    consumed = self._focus_stack[-1].handle_key(ch)
    if not consumed:
        self._process_character(ch)
else:
    self._process_character(ch)
```

### FocusablePane

`FocusablePane(Pane)` in `src/cuipyd/widgets/focusable_pane.py`.

```python
class FocusablePane(Pane):
    _focused: bool = False

    def _register_mouse_event(self, mouse_event: MouseEvent):
        if mouse_event.is_click():
            self._root.push_focus(self)

    def handle_key(self, ch: int) -> bool:
        return False  # subclasses override; return True = key consumed

    def _on_focus_gained(self): pass
    def _on_focus_lost(self): pass
```

Subclasses call `super()._register_mouse_event(mouse_event)` to keep click-to-focus, then add their own logic.

---

## TextInput

### File

`src/cuipyd/widgets/text_input.py`

### Constructor

```python
TextInput(
    multiline: bool = False,
    on_enter: Callable[[str], None] = None,
    on_change: Callable[[str], None] = None,
    placeholder: str = "",
    **kwargs  # passed to FocusablePane/Pane
)
```

### Internal state

```python
_lines: List[str]     # always length 1 in single-line mode
_cursor_row: int      # always 0 in single-line mode
_cursor_col: int
_scroll_row: int      # multi-line: first visible row
_scroll_col: int      # single-line: first visible column
```

### Public API

```python
@property
def text(self) -> str           # "\n".join(_lines)
def set_text(self, text: str)   # splits on "\n", resets cursor and scroll
def clear(self)                 # equivalent to set_text("")
```

`on_change` is called after every edit with the current `text` value.

### Key map

| Key | Single-line | Multi-line |
|-----|-------------|------------|
| Printable char | Insert at cursor | Insert at cursor |
| Backspace (KEY_BACKSPACE, 127, 8) | Delete char before cursor | Delete before cursor; merge with prev line if at col 0 |
| Delete (KEY_DC) | Delete char at cursor | Delete at cursor; merge with next line if at end |
| ← (KEY_LEFT) | Move cursor left | Move left; wrap to end of prev line |
| → (KEY_RIGHT) | Move cursor right | Move right; wrap to start of next line |
| ↑ (KEY_UP) | — (not consumed) | Move to prev row, clamp col |
| ↓ (KEY_DOWN) | — (not consumed) | Move to next row, clamp col |
| Ctrl+← | Jump to start of prev word (space-delimited; key code is terminal-dependent, detected via escape sequence) | Same |
| Ctrl+→ | Jump to start of next word (space-delimited; key code is terminal-dependent) | Same |
| Home (KEY_HOME) / Ctrl+A | Move cursor to col 0 | Move cursor to col 0 (no selection — selection is out of scope) |
| End / Ctrl+E | Move cursor to end of line | Move cursor to end of line |
| Ctrl+K | Delete from cursor to end of line | Delete from cursor to end of line |
| Enter | Call `on_enter(text)` and consume if `on_enter` is set; return False (fall through to `_process_character`) if `on_enter` is None | Insert newline, move cursor to new line |
| Escape | Call `pop_focus`; return False (falls through to `_process_character`) | Same |
| Any other | Return False (not consumed) | Return False |

### Rendering

Background fill: `alternate_mod()` when unfocused, `alternate_mod(invert=True)` when focused. This makes the input visually distinct without requiring a border.

**Single-line:** Renders one row. `_scroll_col` tracks the horizontal offset so the cursor stays visible — shifts right when cursor reaches the right edge, shifts left when cursor reaches the left edge. Text is clipped to the viewport width.

**Multi-line:** Renders all available rows. `_scroll_row` tracks the vertical offset so the cursor row stays visible. Each line is clipped to viewport width.

**Cursor:** The character at `(cursor_row, cursor_col)` relative to scroll is rendered in inverted colors (`default_mod(invert=True)`). If the cursor is at the end of a line, a space is rendered inverted. Cursor is only shown when `_focused = True`.

**Placeholder:** When `_lines == [""]` and `_focused == False`, renders `placeholder` in `default_mod()` (dim, no inversion).

No border is drawn — the background color change is the visual affordance.

---

## Exports

Add to `src/cuipyd/__init__.py`:

```python
from .widgets.focusable_pane import FocusablePane
from .widgets.text_input import TextInput
```

---

## Files Changed

| File | Action |
|------|--------|
| `src/cuipyd/main_window.py` | Add `_focus_stack`, `push_focus`, `pop_focus`, update `_register_mouse_event` and `_run_internal` |
| `src/cuipyd/widgets/focusable_pane.py` | New file |
| `src/cuipyd/widgets/text_input.py` | New file |
| `src/cuipyd/__init__.py` | Add new exports |
