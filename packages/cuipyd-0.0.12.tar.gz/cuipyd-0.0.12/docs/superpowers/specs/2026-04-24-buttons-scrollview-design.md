# Buttons & ScrollView Design

## Overview

Three new components for cuipyd:

1. `Button(Pane)` — standalone button widget usable in any layout
2. `ButtonBar(HLayout)` — convenience row of buttons with a clean constructor API
3. `ScrollView(BaseLayout)` — working scrollable container with virtual canvas and viewport-aware modes

---

## Button

### Purpose

A self-contained pane that renders a bordered box with centered text, tracks hover state, and calls a callback on click. Can be dropped into any layout like any other pane.

### API

```python
Button(text: str, on_click: Callable = None, style: ButtonStyle = ButtonStyle.DEFAULT)
```

`ButtonStyle` is an enum:
- `DEFAULT` — standard color scheme
- `DANGER` — renders using `header_mod` colors (red) for destructive actions

### Sizing

- `min_width = len(text) + 4` (text + 2 spaces padding + 2 border chars)
- `min_height = 3` (top border, text row, bottom border)
- Grows to fill whatever space the parent layout gives it

### Rendering

Draws a bordered box using `_draw_box` with centered text on the middle row. Visual states:
- Normal: `default_mod()`
- Hovered: `default_mod(invert=True)`
- DANGER normal: `header_mod()`
- DANGER hovered: `header_mod(invert=True)`

### Mouse Handling

`_register_mouse_event` sets `_hovered = True` when the mouse is within bounds. Calls `on_click()` on `LEFT_MOUSE` click event. Sets `_hovered = False` on null events (mouse left the pane).

### File

`src/cuipyd/widgets/button.py` — replaces the current stub.

---

## ButtonBar

### Purpose

An `HLayout` subclass that owns a row of `Button` panes. Accepts tuples or `Button` instances. Provides a named constructor for the confirm/cancel pattern. Fixed height so it never grows beyond one button row.

### API

```python
# From (text, callable) tuples
ButtonBar([("OK", on_ok), ("Cancel", on_cancel)])

# From Button instances
ButtonBar([Button("Delete", on_click=..., style=ButtonStyle.DANGER), Button("Cancel", on_click=...)])

# Named constructor for the most common pattern
ButtonBar.confirm_cancel(on_confirm: Callable, on_cancel: Callable) -> ButtonBar
```

### Sizing

`max_height = 3` — buttons are always one row tall. Buttons share horizontal space equally (equal weights in the underlying HLayout).

### Conversion

Only `Button` instances and `(text, callable)` tuples are accepted. Tuples are automatically promoted to `Button(text, on_click=callable)` in `__init__`. Any other type raises `ValueError`.

### File

`src/cuipyd/widgets/button_bar.py` — new file.

---

## ScrollView

### Purpose

Replaces the current broken `ScrollView` (which tracked scroll state but never applied it to rendering). A single-child container layout with two rendering modes.

### API

```python
# Virtual canvas mode (default)
sv = ScrollView(virtual_height=200, virtual_width=80)
sv.add_child(MyLargePane())

# Viewport-aware mode
sv = ScrollView(viewport_aware=True)
sv.add_child(MyEfficientPane())  # reads sv.scroll_offset in render_frame

# Programmatic scroll control (both modes)
sv.scroll_vertical(amt: int)
sv.scroll_horizontal(amt: int)

# Read scroll position
sv.scroll_offset -> Tuple[int, int]  # (row, col)
```

### Virtual Canvas Mode (default)

- Creates a `curses.newpad(virtual_height, virtual_width)` as the child's window
- Child renders into the pad at full virtual size, unaware of the viewport
- On refresh, `ScrollView` calls `pad.noutrefresh(scroll_row, scroll_col, abs_y, abs_x, abs_y + view_h - 1, abs_x + view_w - 1)` to blit the visible region to the screen
- Scroll position is clamped: `0 <= scroll_row <= virtual_height - view_h`, same for col
- If `virtual_height`/`virtual_width` are not specified, defaults to the viewport size (effectively no scroll)

### Viewport-Aware Mode

- Child receives the viewport's actual dimensions as its window
- Child accesses scroll position via `self._parent.scroll_offset` (the direct parent is always the `ScrollView` in this mode)
- `ScrollView` does not create a pad — no extra memory for large content
- Useful when the virtual content is so large that rendering the full size would be slow

### Mouse Handling

Both modes: mouse wheel up/down scrolls vertically by 1 row. Ctrl+wheel scrolls horizontally. Delegates non-scroll events to the child.

### Constraints

- Only one child allowed; raises if a second is added via `_add_child` (matches framework convention)
- Pad is recreated on resize

### File

`src/cuipyd/widgets/scrollview.py` — replaces the current stub.

---

## Exports

Add `Button`, `ButtonBar`, `ScrollView` to `src/cuipyd/__init__.py`.

---

## Files Changed

| File | Action |
|------|--------|
| `src/cuipyd/widgets/button.py` | Rewrite (currently a stub) |
| `src/cuipyd/widgets/button_bar.py` | New file |
| `src/cuipyd/widgets/scrollview.py` | Rewrite (currently broken) |
| `src/cuipyd/__init__.py` | Add new exports |
