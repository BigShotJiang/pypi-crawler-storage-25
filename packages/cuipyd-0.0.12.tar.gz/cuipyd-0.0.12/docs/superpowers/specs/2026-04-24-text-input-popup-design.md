# TextInputPopup Design

## Overview

`TextInputPopup(BasePopup)` composes the focus system, `TextInput`, and `ButtonBar` into a ready-to-use dialog. Requires implementing `TextInput` (designed in `2026-04-24-text-input-design.md`) first.

## Constructor

```python
TextInputPopup(
    description: str = None,              # optional label above the input
    multiline: bool = False,
    on_confirm: Callable[[str], None] = None,
    on_cancel: Callable[[], None] = None,
    **kwargs                              # forwarded to BasePopup
)
```

## Inner Layout

A `VLayout` sized to the popup content area (inside border), with children:

```
┌─[X]──────────────────────────┐
│ Description text (1 row)      │  optional, max_height=min_height=1
│                               │
│  TextInput (fills remaining)  │  auto-focused on open
│                               │
│          [Cancel]  [Confirm]  │  ButtonBar, max_height=3
└───────────────────────────────┘
```

## Window Management

Inner layout is built in `__init__` but receives its window in `_update_window_size` (first call only):

1. `super()._update_window_size(...)` gives popup its window
2. `inner_layout._set_parent(self)` links it into the tree
3. `inner_layout._update_window_size(content_h, content_w, 1, 1)` positions it inside the border

On subsequent resize calls, only step 3 repeats.

## Rendering

```python
def render_frame(self, time_delta):
    super().render_frame(time_delta)  # background fill + border
    self._inner_layout._render_frame(time_delta)
```

## Focus

After first `_update_window_size`, calls `self._root.push_focus(self._text_input)` so the input is immediately ready to type into without requiring a click.

When the popup is closed (`close()`), calls `self._root.pop_focus(self._text_input)` before removing the popup.

## Confirm / Cancel

- **Confirm**: `on_confirm(self._text_input.text)` then `self.close()`
- **Cancel**: `on_cancel()` if provided, then `self.close()`

## Files

| File | Action |
|------|--------|
| `src/cuipyd/popups/text_input_popup.py` | New file |
| `src/cuipyd/__init__.py` | Add `TextInputPopup` export |
