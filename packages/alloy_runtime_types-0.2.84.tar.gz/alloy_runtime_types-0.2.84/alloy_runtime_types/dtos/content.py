"""DTOs for content querying operations."""

from datetime import datetime
from decimal import Decimal
from typing import Any, Literal
from uuid import UUID

from pydantic import BaseModel, Field, model_validator

from alloy_runtime_types.dtos.templates import TagResponse


def _empty_tag_responses() -> list[TagResponse]:
    return []


class SessionSummaryResponse(BaseModel):
    """Summary of the chat session context for a content item."""

    id: UUID
    name: str | None = Field(None, description="Optional user-provided session name")
    last_activity_at: datetime


class MediaContentResponse(BaseModel):
    """Media content object metadata and URL."""

    id: UUID
    content_type_id: str = Field(
        description="Content type (image, video, audio, document)"
    )
    url: str = Field(description="URL to access the media content")
    mime_type: str
    original_filename: str | None = None
    file_size_bytes: int | None = None
    # Image-specific metadata
    image_width: int | None = None
    image_height: int | None = None
    image_format: str | None = None
    # Video-specific metadata
    video_duration_seconds: int | None = None
    video_resolution: str | None = None
    # Audio-specific metadata
    audio_duration_seconds: int | None = None


class ExecutionMetadataResponse(BaseModel):
    """Comprehensive execution metadata including tokens, costs, and timing."""

    agent_execution_id: UUID
    external_id: str | None = Field(
        None, description="User-provided external ID for referencing this execution"
    )
    agent_id: UUID | None = Field(
        None, description="Agent ID if using a persistent agent"
    )
    agent_name: str | None = Field(None, description="Agent name for display")
    agent_description: str | None = Field(None, description="Agent description")
    provider_key: str = Field(description="AI provider (anthropic, openai, etc.)")
    provider_model_name: str = Field(description="Model name as reported by provider")
    credential_source: str = Field(
        description="Credential source: organization or system"
    )
    finish_reason: str | None = Field(
        None, description="Why generation stopped (stop, length, tool_calls, error)"
    )
    # Token metrics
    input_tokens: int | None = None
    output_tokens: int | None = None
    cache_creation_tokens: int | None = None
    cache_read_tokens: int | None = None
    total_tokens: int | None = None
    # Cost metrics
    input_cost_usd: Decimal | None = None
    output_cost_usd: Decimal | None = None
    cache_cost_usd: Decimal | None = None
    total_cost_usd: Decimal | None = None
    # Timing metrics
    time_to_first_token_ms: int | None = Field(
        None, description="Time from request to first token (ms)"
    )
    total_duration_ms: int | None = Field(None, description="Total execution time (ms)")
    # Status and timestamps
    status_id: str = Field(
        description="Execution status (pending, running, completed, failed)"
    )
    queued_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None


class ContentPartItemResponse(BaseModel):
    """A content item with comprehensive metadata."""

    id: UUID = Field(description="Content part ID")
    message_id: UUID = Field(description="Parent message ID")
    message_role: Literal["user", "assistant"] = Field(
        description="Parent message role for content listing and retrieval responses.",
    )
    part_index: int = Field(description="Index within the message (0-based)")
    content_type_id: str = Field(description="Content type (text, code, json, etc.)")
    # Content data - at least one will be populated
    content_text: str | None = Field(
        None, description="Plain text content (null for structured/media types)"
    )
    content_structured: dict[str, Any] | None = Field(
        None, description="Structured JSON content (null for text types)"
    )
    part_metadata: dict[str, Any] | None = Field(
        None,
        description="User-computed metadata (word_count, language, quality_score, etc.)",
    )
    # Media reference (for content_object_id)
    media: MediaContentResponse | None = Field(
        None, description="Media content metadata and URL (null for inline content)"
    )
    # Metadata
    tags: list[TagResponse] = Field(
        default_factory=_empty_tag_responses,
        description="Associated tags",
    )
    session: SessionSummaryResponse | None = Field(
        None, description="Chat session context (null for standalone executions)"
    )
    execution_metadata: ExecutionMetadataResponse | None = Field(
        None,
        description="Full execution metadata for assistant content. Null for user content.",
    )
    created_at: datetime
    updated_at: datetime


class ListContentPartsResponse(BaseModel):
    """Paginated response for content parts query."""

    content_parts: list[ContentPartItemResponse]
    cursor: str | None = Field(
        None, description="Cursor for next page. Null if no more results."
    )
    total_count: int = Field(
        description="Total matching content parts across all pages"
    )


class UpdateContentPartRequest(BaseModel):
    """Request to update mutable fields of a content part."""

    content_text: str | None = Field(
        default=None,
        description="Replacement text content. Provide for text-type content parts only.",
    )
    content_structured: dict[str, Any] | None = Field(
        default=None,
        description="Structured JSON content. Behavior depends on content_structured_merge flag.",
    )
    content_structured_merge: bool = Field(
        default=False,
        description=(
            "If False (default), content_structured replaces the existing object entirely. "
            "If True, content_structured fields are merged into the existing object "
            "(new values take precedence for conflicting keys)."
        ),
    )
    part_metadata: dict[str, Any] | None = Field(
        default=None,
        description="User-computed metadata. Behavior depends on part_metadata_merge flag.",
    )
    part_metadata_merge: bool = Field(
        default=False,
        description=(
            "If False (default), part_metadata replaces existing. "
            "If True, merges into existing (new values take precedence)."
        ),
    )
    tag_paths: list[str] | None = Field(
        default=None,
        description="Updated tag paths. None = preserve existing tags, [] = clear all tags, [items] = replace with new tags.",
    )

    @model_validator(mode="after")
    def validate_at_least_one_field(self) -> "UpdateContentPartRequest":
        """Ensure at least one updateable field is provided."""
        if (
            self.content_text is None
            and self.content_structured is None
            and self.tag_paths is None
            and self.part_metadata is None
        ):
            raise ValueError(
                "Must provide at least one of: content_text, content_structured, tag_paths, or part_metadata"
            )
        return self


class DeletedContentPartResponse(BaseModel):
    """Deleted content part state (without execution metadata)."""

    id: UUID = Field(description="Content part ID")
    message_id: UUID = Field(description="Parent message ID")
    part_index: int = Field(description="Index within the message (0-based)")
    content_type_id: str = Field(description="Content type (text, code, json, etc.)")
    content_text: str | None = Field(
        None, description="Plain text content (null for structured/media types)"
    )
    content_structured: dict[str, Any] | None = Field(
        None, description="Structured JSON content (null for text types)"
    )
    content_object_id: UUID | None = Field(
        None,
        description="Reference to external content object (null for inline content)",
    )
    tags: list[TagResponse] = Field(
        default_factory=_empty_tag_responses,
        description="Associated tags",
    )
    created_at: datetime


class DeleteContentPartResponse(BaseModel):
    """Response for delete content part operation.

    When deleting a content part, orphaned parent objects are also cleaned up:
    - If the message has no remaining content parts, the message is deleted
    - If the session has no remaining messages, the session is deleted
    - If the execution has no remaining message references, its external_id is cleared

    The cascade fields indicate what additional cleanup was performed.
    """

    deleted_content_part: DeletedContentPartResponse = Field(
        description="The deleted content part's final state"
    )
    deleted_message_id: UUID | None = Field(
        default=None,
        description="If the parent message was orphaned and deleted, its ID is returned here",
    )
    deleted_session_id: UUID | None = Field(
        default=None,
        description="If the parent session was orphaned and deleted, its ID is returned here",
    )
    cleared_execution_id: UUID | None = Field(
        default=None,
        description="If the execution's external_id was cleared (due to no remaining message refs), its ID is returned here",
    )


# Response DTOs reuse existing DTO (type aliases for clarity)
GetContentPartResponse = ContentPartItemResponse
UpdateContentPartResponse = ContentPartItemResponse
