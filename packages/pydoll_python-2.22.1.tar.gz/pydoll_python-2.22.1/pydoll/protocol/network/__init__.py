"""Network domain implementation."""
