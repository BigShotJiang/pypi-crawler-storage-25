"""Accessibility domain implementation."""
