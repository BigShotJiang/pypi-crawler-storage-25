"""Emulation domain implementation."""
