from __future__ import annotations

from functools import lru_cache
from importlib import import_module
from pathlib import Path
from typing import Any

from loguru import logger
from pydantic import Field
from typing_extensions import Self

from fasr.config import Config, registry
from fasr.data import AudioSpan, AudioSpanList, Waveform
from fasr.model import VADModel

DEFAULT_CHECKPOINT_DIR = Path(__file__).parent / "asset" / "fsmn-vad"


@lru_cache(maxsize=1)
def _get_funasr_onnx_module():
    try:
        return import_module("funasr_onnx")
    except Exception as exc:  # pragma: no cover - exercised in real runtime envs
        raise RuntimeError(
            "FSMN VAD requires `funasr_onnx` to be installed and importable."
        ) from exc


def _get_input_waveform(audio: AudioSpan) -> Waveform:
    if audio.waveform is None:
        raise ValueError("VAD input audio must carry `waveform`.")
    return audio.waveform


def _is_cpu_device(device_id: str | int) -> bool:
    return str(device_id).lower() in {"-1", "cpu"}


def _log_runtime_device(device_id: str | int) -> None:
    if _is_cpu_device(device_id):
        logger.info(
            "FSMN VAD is using CPU via onnxruntime. For GPU inference, install "
            "`onnxruntime-gpu` and set `device_id` to the GPU id."
        )
        return
    logger.info(f"FSMN VAD is using GPU via onnxruntime device_id={device_id}.")


def _bind_segment_to_input(audio: AudioSpan, segment: AudioSpan) -> AudioSpan:
    if segment.start_ms is None or segment.end_ms is None:
        raise ValueError("Detected segment must carry both `start_ms` and `end_ms`.")
    relative_start_ms = int(round(segment.start_ms))
    relative_end_ms = int(round(segment.end_ms))
    cloned = segment.model_copy(deep=True)
    offset_ms = int(round(audio.start_ms or 0))
    cloned.start_ms = offset_ms + relative_start_ms
    cloned.end_ms = offset_ms + relative_end_ms
    cloned.waveform = _get_input_waveform(audio).select_by_ms(
        relative_start_ms,
        relative_end_ms,
    )
    return cloned


class FSMNVad(VADModel):
    """FSMN VAD model implementation.

    FSMN (Feedforward Sequential Memory Networks) VAD is a neural-network-based voice
    activity detector. Inference is driven by `funasr_onnx`.
    """

    fsmn: Any | None = Field(
        default=None,
        exclude=True,
        description=(
            "Underlying funasr_onnx Fsmn_vad handle populated by `load_checkpoint`."
        ),
    )
    sample_rate: int = Field(default=16000, description="Audio sample rate.")
    device_id: str | int | None = Field(
        default=None,
        description="Device id forwarded to `funasr_onnx` (`None` / `-1` for CPU).",
    )
    num_threads: int = Field(
        default=2,
        ge=0,
        description="Threads used by the ONNX Runtime backend inside `funasr_onnx`.",
    )
    max_end_silence_time: int = Field(
        default=800, ge=0, description="Maximum trailing silence duration (ms)."
    )
    speech_noise_thres: float = Field(
        default=0.6, ge=0.0, le=1.0, description="Speech-vs-noise decision threshold."
    )

    def get_config(self) -> Config:
        """Return a `Config` describing this VAD instance for round-trip serialization."""
        data = {
            "vad_model": {
                "@vad_models": "fsmn",
                "checkpoint": self.checkpoint,
                "sample_rate": self.sample_rate,
                "device_id": self.device_id,
                "num_threads": self.num_threads,
                "max_end_silence_time": self.max_end_silence_time,
                "speech_noise_thres": self.speech_noise_thres,
            }
        }
        return Config(data=data)

    def detect(self, audio: AudioSpan) -> AudioSpanList:
        backend = self.fsmn
        if backend is None:
            raise RuntimeError(
                "FSMN backend is not loaded. Call `load_checkpoint` first."
            )

        waveform = _get_input_waveform(audio)
        input_waveform = waveform
        if waveform.sample_rate != self.sample_rate:
            input_waveform = waveform.resample(self.sample_rate)

        param_dict = {
            "in_cache": [],
            "is_final": True,
        }
        result = backend(audio_in=input_waveform.data, param_dict=param_dict)
        if not result:
            return AudioSpanList()

        segments = result[0]
        if not segments:
            return AudioSpanList()

        detected = AudioSpanList()
        for start_ms, end_ms in segments:
            detected.append(
                _bind_segment_to_input(
                    audio,
                    AudioSpan(start_ms=start_ms, end_ms=end_ms),
                )
            )
        return detected

    def load_checkpoint(self, checkpoint_dir: str | Path | None = None) -> Self:
        """Load the FSMN VAD ONNX backend from a checkpoint directory."""
        if checkpoint_dir is None:
            if self.checkpoint:
                self.download_checkpoint()
                checkpoint_dir = self.checkpoint_dir
            else:
                checkpoint_dir = DEFAULT_CHECKPOINT_DIR
        checkpoint_dir = Path(checkpoint_dir)

        funasr_onnx = _get_funasr_onnx_module()
        device_id = self.device_id if self.device_id is not None else "-1"
        _log_runtime_device(device_id)
        object.__setattr__(
            self,
            "fsmn",
            funasr_onnx.Fsmn_vad(
                model_dir=str(checkpoint_dir),
                batch_size=1,
                device_id=device_id,
                intra_op_num_threads=self.num_threads,
                max_end_sil=self.max_end_silence_time,
                cache_dir=str(self.resolved_cache_dir),
                speech_noise_thres=self.speech_noise_thres,
            ),
        )
        return self


@registry.vad_models.register("fsmn")
def fsmn_entrypoint(
    sample_rate: int = 16000,
    device_id: str | int | None = None,
    num_threads: int = 2,
    max_end_silence_time: int = 800,
    speech_noise_thres: float = 0.6,
    **kwargs,
) -> FSMNVad:
    return FSMNVad(
        sample_rate=sample_rate,
        device_id=device_id,
        num_threads=num_threads,
        max_end_silence_time=max_end_silence_time,
        speech_noise_thres=speech_noise_thres,
        **kwargs,
    )
