from __future__ import annotations

from functools import lru_cache
from importlib import import_module
from pathlib import Path
from typing import Dict, Iterable

from loguru import logger
import numpy as np
from pydantic import Field
from typing_extensions import Self

from fasr.config import Config, registry
from fasr.data import AudioChunk, Waveform
from fasr.model import VADModel

DEFAULT_CHECKPOINT_DIR = Path(__file__).parent / "asset" / "fsmn-vad"


@lru_cache(maxsize=1)
def _get_funasr_onnx_module():
    try:
        return import_module("funasr_onnx")
    except Exception as exc:  # pragma: no cover - exercised in real runtime envs
        raise RuntimeError(
            "FSMN VAD requires `funasr_onnx` to be installed and importable."
        ) from exc


def _ms_to_sample(ms: int, sample_rate: int) -> int:
    return ms * sample_rate // 1000


def _sample_to_ms(sample_idx: int, sample_rate: int) -> int:
    return sample_idx * 1000 // sample_rate


def _slice_audio_by_ms(
    audio_waveform: Waveform,
    sample_rate: int,
    start_ms: int,
    end_ms: int,
) -> Waveform:
    start_idx = _ms_to_sample(start_ms, sample_rate)
    end_idx = max(start_idx, _ms_to_sample(end_ms, sample_rate))
    return audio_waveform[start_idx:end_idx]


def _slice_audio_in_chunk(
    audio_waveform: Waveform,
    sample_rate: int,
    start_ms: int,
    end_ms: int,
    offset_samples: int,
    chunk_samples: int,
) -> Waveform:
    chunk_start_ms = _sample_to_ms(offset_samples, sample_rate)
    chunk_end_ms = _sample_to_ms(offset_samples + chunk_samples, sample_rate)
    clamped_start_ms = max(start_ms, chunk_start_ms)
    clamped_end_ms = max(clamped_start_ms, min(end_ms, chunk_end_ms))
    return _slice_audio_by_ms(
        audio_waveform=audio_waveform,
        sample_rate=sample_rate,
        start_ms=clamped_start_ms,
        end_ms=clamped_end_ms,
    )


class FSMNVadOnline(VADModel):
    fsmn: object | None = Field(
        default=None,
        exclude=True,
        description="Underlying funasr_onnx Fsmn_vad_online handle populated by `load_checkpoint`.",
    )
    chunk_size_ms: int = 100
    sample_rate: int = 16000
    max_end_silence_time: int = 500
    speech_noise_thres: float = 0.6
    device: str | None = Field(
        default=None,
        description="Execution device override (`'cuda'` / `'cpu'`). `None` uses CPU.",
    )

    def _run_fsmn(
        self,
        *,
        data: np.ndarray,
        chunk: AudioChunk,
        in_cache: list,
    ) -> list[tuple[int, int]]:
        param_dict = {
            "in_cache": in_cache,
            "is_final": chunk.is_last,
        }
        result = self.fsmn(audio_in=data, param_dict=param_dict)
        if not result:
            return []
        return result[0]

    def _reset_fsmn_runtime(self) -> None:
        if self.fsmn is None:
            return

        frontend = getattr(self.fsmn, "frontend", None)
        if frontend is not None and hasattr(frontend, "cache_reset"):
            frontend.cache_reset()

        vad_scorer = getattr(self.fsmn, "vad_scorer", None)
        if vad_scorer is not None and hasattr(vad_scorer, "AllResetDetection"):
            vad_scorer.AllResetDetection()

    def reset(self) -> None:
        super().reset()
        self._reset_fsmn_runtime()

    def remove_state(self, key: str) -> None:
        super().remove_state(key)
        if not self.states:
            self._reset_fsmn_runtime()

    def _emit_from_segments(
        self,
        *,
        stream_id: str,
        segments: Iterable[tuple[int, int]],
        audio_waveform: Waveform,
        sample_rate: int,
        offset_samples: int,
        chunk_samples: int,
        is_detected: bool,
        emitted_until_ms: int | None,
    ) -> tuple[list[AudioChunk], bool, int | None]:
        emitted: list[AudioChunk] = []
        chunk_start_ms = _sample_to_ms(offset_samples, sample_rate)
        chunk_end_ms = _sample_to_ms(offset_samples + chunk_samples, sample_rate)
        next_detected = is_detected
        next_emitted_until_ms = emitted_until_ms

        for raw_start_ms, raw_end_ms in segments:
            if raw_start_ms == -1 and raw_end_ms == -1:
                next_detected = True
                continue

            if raw_start_ms != -1 and raw_end_ms == -1:
                emit_start_ms = raw_start_ms
                if next_emitted_until_ms is not None:
                    emit_start_ms = max(emit_start_ms, next_emitted_until_ms)
                emit_end_ms = max(emit_start_ms, chunk_end_ms)
                emitted.append(
                    AudioChunk(
                        stream_id=stream_id,
                        start_ms=raw_start_ms,
                        end_ms=-1,
                        waveform=_slice_audio_by_ms(
                            audio_waveform=audio_waveform,
                            sample_rate=sample_rate,
                            start_ms=emit_start_ms,
                            end_ms=emit_end_ms,
                        ),
                        sample_rate=sample_rate,
                        vad_state="segment_start",
                        is_start=True,
                    )
                )
                next_detected = True
                next_emitted_until_ms = emit_end_ms
                continue

            if raw_start_ms == -1 and raw_end_ms != -1:
                emit_start_ms = chunk_start_ms
                if next_emitted_until_ms is not None:
                    emit_start_ms = max(emit_start_ms, next_emitted_until_ms)
                emit_end_ms = max(emit_start_ms, min(raw_end_ms, chunk_end_ms))
                emitted.append(
                    AudioChunk(
                        stream_id=stream_id,
                        start_ms=-1,
                        end_ms=raw_end_ms,
                        waveform=_slice_audio_in_chunk(
                            audio_waveform=audio_waveform,
                            sample_rate=sample_rate,
                            start_ms=emit_start_ms,
                            end_ms=emit_end_ms,
                            offset_samples=offset_samples,
                            chunk_samples=chunk_samples,
                        ),
                        sample_rate=sample_rate,
                        vad_state="segment_end",
                        is_last=True,
                    )
                )
                next_detected = False
                if next_emitted_until_ms is None:
                    next_emitted_until_ms = emit_end_ms
                else:
                    next_emitted_until_ms = max(next_emitted_until_ms, emit_end_ms)
                continue

            emit_start_ms = raw_start_ms
            if next_emitted_until_ms is not None:
                emit_start_ms = max(emit_start_ms, next_emitted_until_ms)
            emit_end_ms = max(emit_start_ms, min(raw_end_ms, chunk_end_ms))
            emitted.append(
                AudioChunk(
                    stream_id=stream_id,
                    start_ms=raw_start_ms,
                    end_ms=raw_end_ms,
                    waveform=_slice_audio_by_ms(
                        audio_waveform=audio_waveform,
                        sample_rate=sample_rate,
                        start_ms=emit_start_ms,
                        end_ms=emit_end_ms,
                    ),
                    sample_rate=sample_rate,
                    vad_state="segment_mid",
                )
            )
            next_detected = False
            next_emitted_until_ms = emit_end_ms

        return emitted, next_detected, next_emitted_until_ms

    def push_chunk(self, chunk: AudioChunk) -> Iterable[AudioChunk]:
        if chunk.is_start and chunk.stream_id in self.states:
            logger.warning(
                "found start chunk with existing state, this is not expected"
            )
            del self.states[chunk.stream_id]

        state: Dict = self.states.get(chunk.stream_id, {})
        waveform = chunk.waveform
        if waveform.sample_rate != self.sample_rate:
            waveform = waveform.resample(self.sample_rate)

        buffer: Waveform = state.get(
            "buffer",
            Waveform(data=np.array([], dtype=np.float32), sample_rate=self.sample_rate),
        )
        buffer = buffer.append(waveform)
        audio_waveform: Waveform = state.get(
            "audio_waveform",
            Waveform(data=np.array([], dtype=np.float32), sample_rate=self.sample_rate),
        )
        audio_waveform = audio_waveform.append(waveform=waveform)
        in_cache = state.get("in_cache", [])
        offset_samples = state.get("offset", 0)
        is_detected = state.get("is_detected", False)
        emitted_until_ms = state.get("emitted_until_ms")

        while len(buffer) >= self.chunk_size_samples:
            chunk_waveform = buffer[: self.chunk_size_samples]
            buffer = buffer[self.chunk_size_samples :]
            sample_rate = chunk_waveform.sample_rate
            segments = self._run_fsmn(
                data=chunk_waveform.data,
                chunk=chunk,
                in_cache=in_cache,
            )
            emitted, is_detected, emitted_until_ms = self._emit_from_segments(
                stream_id=chunk.stream_id,
                segments=segments,
                audio_waveform=audio_waveform,
                sample_rate=sample_rate,
                offset_samples=offset_samples,
                chunk_samples=len(chunk_waveform.data),
                is_detected=is_detected,
                emitted_until_ms=emitted_until_ms,
            )
            if emitted:
                for item in emitted:
                    yield item
            elif is_detected:
                chunk_start_ms = _sample_to_ms(offset_samples, sample_rate)
                chunk_end_ms = _sample_to_ms(
                    offset_samples + len(chunk_waveform.data),
                    sample_rate,
                )
                emit_start_ms = chunk_start_ms
                if emitted_until_ms is not None:
                    emit_start_ms = max(emit_start_ms, emitted_until_ms)
                emit_end_ms = max(emit_start_ms, chunk_end_ms)
                yield AudioChunk(
                    stream_id=chunk.stream_id,
                    start_ms=-1,
                    end_ms=-1,
                    waveform=_slice_audio_in_chunk(
                        audio_waveform=audio_waveform,
                        sample_rate=sample_rate,
                        start_ms=emit_start_ms,
                        end_ms=emit_end_ms,
                        offset_samples=offset_samples,
                        chunk_samples=len(chunk_waveform.data),
                    ),
                    sample_rate=sample_rate,
                    vad_state="segment_mid",
                    is_last=chunk.is_last,
                )
                emitted_until_ms = emit_end_ms
            offset_samples += len(chunk_waveform.data)

        if chunk.is_last and len(buffer) > 0:
            chunk_waveform = buffer
            buffer = Waveform(
                data=np.array([], dtype=np.float32), sample_rate=self.sample_rate
            )
            sample_rate = chunk_waveform.sample_rate
            segments = self._run_fsmn(
                data=chunk_waveform.data,
                chunk=chunk,
                in_cache=in_cache,
            )
            emitted, is_detected, emitted_until_ms = self._emit_from_segments(
                stream_id=chunk.stream_id,
                segments=segments,
                audio_waveform=audio_waveform,
                sample_rate=sample_rate,
                offset_samples=offset_samples,
                chunk_samples=len(chunk_waveform.data),
                is_detected=is_detected,
                emitted_until_ms=emitted_until_ms,
            )
            if emitted:
                for item in emitted:
                    yield item
            elif is_detected:
                chunk_start_ms = _sample_to_ms(offset_samples, sample_rate)
                chunk_end_ms = _sample_to_ms(
                    offset_samples + len(chunk_waveform.data),
                    sample_rate,
                )
                emit_start_ms = chunk_start_ms
                if emitted_until_ms is not None:
                    emit_start_ms = max(emit_start_ms, emitted_until_ms)
                emit_end_ms = max(emit_start_ms, chunk_end_ms)
                yield AudioChunk(
                    stream_id=chunk.stream_id,
                    start_ms=-1,
                    end_ms=-1,
                    waveform=_slice_audio_in_chunk(
                        audio_waveform=audio_waveform,
                        sample_rate=sample_rate,
                        start_ms=emit_start_ms,
                        end_ms=emit_end_ms,
                        offset_samples=offset_samples,
                        chunk_samples=len(chunk_waveform.data),
                    ),
                    sample_rate=sample_rate,
                    vad_state="segment_mid",
                    is_last=chunk.is_last,
                )
                emitted_until_ms = emit_end_ms
            offset_samples += len(chunk_waveform.data)

        if chunk.is_last:
            self.states.pop(chunk.stream_id, None)
            if not self.states:
                self._reset_fsmn_runtime()
            return

        state.update(
            {
                "buffer": buffer,
                "in_cache": in_cache,
                "offset": offset_samples,
                "is_detected": is_detected,
                "audio_waveform": audio_waveform,
                "emitted_until_ms": emitted_until_ms,
            }
        )
        self.states[chunk.stream_id] = state

    def load_checkpoint(self, checkpoint_dir: str | Path | None = None) -> Self:
        device = self.device or "cpu"
        device_id = 0 if device == "cuda" else -1
        if device_id == -1:
            logger.info(
                "FSMN online VAD is using CPU via onnxruntime. For GPU inference, "
                "install `onnxruntime-gpu` and set `device='cuda'`."
            )
        else:
            logger.info("FSMN online VAD is using GPU via onnxruntime device_id=0.")

        if checkpoint_dir is None:
            if self.checkpoint:
                self.download_checkpoint()
                checkpoint_dir = self.checkpoint_dir
            else:
                checkpoint_dir = DEFAULT_CHECKPOINT_DIR
        funasr_onnx = _get_funasr_onnx_module()
        object.__setattr__(
            self,
            "fsmn",
            funasr_onnx.Fsmn_vad_online(
                model_dir=str(checkpoint_dir),
                max_end_sil=self.max_end_silence_time,
                speech_noise_thres=self.speech_noise_thres,
                device_id=device_id,
            ),
        )
        return self

    def get_config(self) -> Config:
        return Config(
            data={
                "vad_model": {
                    "@vad_models": "fsmn_online",
                    "checkpoint": self.checkpoint,
                    "chunk_size_ms": self.chunk_size_ms,
                    "sample_rate": self.sample_rate,
                    "max_end_silence_time": self.max_end_silence_time,
                    "speech_noise_thres": self.speech_noise_thres,
                    "device": self.device,
                }
            }
        )


@registry.vad_models.register("fsmn_online")
def fsmn_online_entrypoint(
    chunk_size_ms: int = 100,
    sample_rate: int = 16000,
    max_end_silence_time: int = 500,
    speech_noise_thres: float = 0.6,
    device: str | None = None,
) -> FSMNVadOnline:
    return FSMNVadOnline(
        chunk_size_ms=chunk_size_ms,
        sample_rate=sample_rate,
        max_end_silence_time=max_end_silence_time,
        speech_noise_thres=speech_noise_thres,
        device=device,
    )
