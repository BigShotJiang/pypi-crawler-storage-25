"""PXControl SDK for Python applications.

Public API:

* ``PxClient`` — the WebSocket client that maintains the live status.
* ``get_client`` / ``reset_client`` — process-wide singleton helpers.
* ``PxControlASGIMiddleware`` — drop-in middleware for FastAPI / Starlette.
* ``PxControlWSGIMiddleware`` — drop-in middleware for Flask / Django (WSGI).
* ``DjangoPxControlMiddleware`` — Django-style middleware class.
"""

from ._version import __version__
from .client import PxClient, get_client, reset_client
from .middleware import (
    DjangoPxControlMiddleware,
    PxControlASGIMiddleware,
    PxControlWSGIMiddleware,
)

__all__ = [
    "__version__",
    "PxClient",
    "get_client",
    "reset_client",
    "PxControlASGIMiddleware",
    "PxControlWSGIMiddleware",
    "DjangoPxControlMiddleware",
]
