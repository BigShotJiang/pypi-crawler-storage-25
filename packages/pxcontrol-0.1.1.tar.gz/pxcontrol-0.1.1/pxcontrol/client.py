"""WebSocket client that maintains the live PXControl project status.

The client runs a background thread with its own ``asyncio`` event loop so
it can be used transparently from synchronous frameworks (Flask,
Django/WSGI, scripts) as well as from async ones (FastAPI, Starlette).

In addition to the WebSocket channel, the client supports two optional
extras — both on by default and controllable via config/env:

* **HTTP poll fallback.** After ``N`` consecutive WS failures the client
  starts polling ``GET /api/v1/status/{token}`` every ``poll_interval``
  seconds. As soon as the WebSocket reconnects, polling stops.
* **SDK version check.** On first boot the client fetches
  ``GET /api/v1/sdk/versions`` and logs a warning when the installed
  version is older than the catalog's ``latest`` for Python.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import random
import threading
import time
import urllib.error
import urllib.request
from typing import Any, Callable, Optional

# Prefer the modern ``websockets.asyncio`` client API. We keep a fallback
# to the legacy top-level ``websockets.connect`` for very old installs
# (pre-13.0), but the packaging requires >=13 so this is belt-and-braces.
try:
    from websockets.asyncio.client import connect as _ws_connect  # type: ignore[attr-defined]
    from websockets.exceptions import ConnectionClosed, InvalidStatus

    _USE_NEW_API = True
except ImportError:  # pragma: no cover - legacy fallback
    from websockets import connect as _ws_connect  # type: ignore[assignment]
    from websockets.exceptions import ConnectionClosed  # type: ignore[no-redef]
    from websockets.exceptions import InvalidStatusCode as InvalidStatus  # type: ignore[assignment]

    _USE_NEW_API = False

from ._version import __version__

DEFAULT_WS_URL = "wss://api-pxcontrol.codefied.online"
DEFAULT_HEARTBEAT_INTERVAL = 30.0
DEFAULT_RECONNECT_DELAY = 1.0
DEFAULT_MAX_RECONNECT_DELAY = 60.0
DEFAULT_POLL_INTERVAL = 15.0
DEFAULT_POLL_AFTER_FAILURES = 3
VERSION_CHECK_TIMEOUT = 3.0
POLL_REQUEST_TIMEOUT = 5.0

# Close codes emitted by the server (mirrors implementation guide).
CLOSE_INVALID_TOKEN = 4001
CLOSE_TOKEN_REVOKED = 4002

_VALID_STATUSES = frozenset({"ACTIVE", "PAUSED", "OFFLINE", "FAILED"})

ProjectStatus = str  # "ACTIVE" | "PAUSED" | "OFFLINE" | "FAILED"
FailMode = str  # "open" | "closed"

logger = logging.getLogger("pxcontrol")


def _ws_url_to_api_url(ws_url: str) -> str:
    if ws_url.startswith("wss://"):
        return "https://" + ws_url[len("wss://") :]
    if ws_url.startswith("ws://"):
        return "http://" + ws_url[len("ws://") :]
    return ws_url


def _compare_semver(a: str, b: str) -> int:
    def parts(v: str) -> list[int]:
        out: list[int] = []
        for chunk in v.split("."):
            try:
                out.append(int(chunk))
            except ValueError:
                out.append(0)
        while len(out) < 3:
            out.append(0)
        return out[:3]

    pa, pb = parts(a), parts(b)
    for i in range(3):
        if pa[i] > pb[i]:
            return 1
        if pa[i] < pb[i]:
            return -1
    return 0


def _status_code_from_invalid(exc: Exception) -> Optional[int]:
    """Cross-version helper for websockets' InvalidStatus / InvalidStatusCode."""
    if hasattr(exc, "status_code"):
        return getattr(exc, "status_code", None)  # legacy
    response = getattr(exc, "response", None)
    if response is not None:
        return getattr(response, "status_code", None)
    return None


class PxClient:
    """Maintains a live WebSocket connection to PXControl.

    The connection runs in a background daemon thread; the public surface is
    safe to call from any thread. Use :meth:`is_active` to gate work, or
    register listeners via :meth:`on_status` for reactive logic.
    """

    def __init__(
        self,
        token: Optional[str] = None,
        ws_url: Optional[str] = None,
        api_url: Optional[str] = None,
        heartbeat_interval: float = DEFAULT_HEARTBEAT_INTERVAL,
        reconnect_delay: float = DEFAULT_RECONNECT_DELAY,
        max_reconnect_delay: float = DEFAULT_MAX_RECONNECT_DELAY,
        debug: Optional[bool] = None,
        environment: Optional[str] = None,
        disable_poll_fallback: Optional[bool] = None,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
        poll_fallback_after_failures: int = DEFAULT_POLL_AFTER_FAILURES,
        disable_version_check: Optional[bool] = None,
    ) -> None:
        token = token or os.getenv("PX_TOKEN")
        if not token:
            raise RuntimeError(
                "[pxcontrol] PX_TOKEN env var (or PxClient(token=...)) is required"
            )
        self._token = token
        self._ws_url = (ws_url or os.getenv("PX_WS_URL") or DEFAULT_WS_URL).rstrip("/")
        self._api_url = (
            api_url or os.getenv("PX_API_URL") or _ws_url_to_api_url(self._ws_url)
        ).rstrip("/")
        self._heartbeat_interval = heartbeat_interval
        self._reconnect_delay = reconnect_delay
        self._max_reconnect_delay = max_reconnect_delay
        self._debug = debug if debug is not None else os.getenv("PX_DEBUG") == "true"
        self._environment = (
            environment or os.getenv("PX_ENV") or os.getenv("APP_ENV") or "unknown"
        )
        self._disable_poll_fallback = (
            disable_poll_fallback
            if disable_poll_fallback is not None
            else os.getenv("PX_DISABLE_POLL") == "true"
        )
        self._poll_interval = poll_interval
        self._poll_fallback_after_failures = poll_fallback_after_failures
        self._disable_version_check = (
            disable_version_check
            if disable_version_check is not None
            else os.getenv("PX_DISABLE_VERSION_CHECK") == "true"
        )

        self._status: ProjectStatus = "ACTIVE"
        self._fail_mode: FailMode = "closed"
        self._pause_message = "Service temporarily unavailable"
        self._offline_message = "This service is currently offline"
        self._connected = False
        self._stopped = False
        self._consecutive_failures = 0
        self._polling_active = False
        self._poll_task: Optional[asyncio.Task[None]] = None

        self._listeners: list[Callable[[ProjectStatus, ProjectStatus], None]] = []
        self._lock = threading.Lock()

        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._thread = threading.Thread(
            target=self._run_loop, name="pxcontrol-sdk", daemon=True
        )
        self._thread.start()

        if not self._disable_version_check:
            threading.Thread(
                target=self._check_version_sync, name="pxcontrol-version", daemon=True
            ).start()

    # ------------------------------------------------------------------ public

    def get_status(self) -> ProjectStatus:
        with self._lock:
            return self._status

    def is_active(self) -> bool:
        return self.get_status() == "ACTIVE"

    def get_pause_message(self) -> str:
        with self._lock:
            return self._pause_message

    def get_offline_message(self) -> str:
        with self._lock:
            return self._offline_message

    def get_fail_mode(self) -> FailMode:
        with self._lock:
            return self._fail_mode

    def get_sdk_version(self) -> str:
        return __version__

    def on_status(
        self, callback: Callable[[ProjectStatus, ProjectStatus], None]
    ) -> None:
        """Register a ``(new_status, old_status) -> None`` listener."""
        with self._lock:
            self._listeners.append(callback)

    def stop(self) -> None:
        """Signal the background thread to stop and close the WebSocket."""
        self._stopped = True
        loop = self._loop
        if loop is not None and loop.is_running():
            try:
                loop.call_soon_threadsafe(loop.stop)
            except RuntimeError:  # pragma: no cover - loop already stopping
                pass

    # ----------------------------------------------------------------- private

    def _log(self, msg: str) -> None:
        if self._debug:
            logger.info("[pxcontrol] %s", msg)

    def _set_status(self, new_status: ProjectStatus) -> None:
        with self._lock:
            old = self._status
            if old == new_status:
                return
            self._status = new_status
            listeners = list(self._listeners)
        self._log(f"status {old} -> {new_status}")
        for cb in listeners:
            try:
                cb(new_status, old)
            except Exception:  # pragma: no cover - listener must not crash the loop
                logger.exception("[pxcontrol] status listener raised")

    def _apply_status_payload(self, msg: dict[str, Any]) -> None:
        fail_mode = msg.get("fail_mode")
        pause_message = msg.get("pause_message")
        offline_message = msg.get("offline_message")
        with self._lock:
            if fail_mode in ("open", "closed"):
                self._fail_mode = fail_mode
            if isinstance(pause_message, str):
                self._pause_message = pause_message
            if isinstance(offline_message, str):
                self._offline_message = offline_message
        new_status = msg.get("status")
        if isinstance(new_status, str) and new_status in _VALID_STATUSES:
            self._set_status(new_status)

    def _run_loop(self) -> None:
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_until_complete(self._main())
        finally:
            pending = asyncio.all_tasks(self._loop)
            for task in pending:
                task.cancel()
            if pending:
                self._loop.run_until_complete(
                    asyncio.gather(*pending, return_exceptions=True)
                )
            self._loop.close()

    async def _main(self) -> None:
        url = f"{self._ws_url}/ws/{self._token}"
        user_agent = f"pxcontrol-sdk-python/{__version__}"
        header_kwargs: dict[str, Any]
        if _USE_NEW_API:
            header_kwargs = {"additional_headers": [("User-Agent", user_agent)]}
        else:  # pragma: no cover - legacy fallback
            header_kwargs = {"extra_headers": [("User-Agent", user_agent)]}

        while not self._stopped:
            try:
                self._log(f"connecting to {url}")
                async with _ws_connect(url, ping_interval=None, **header_kwargs) as ws:
                    self._connected = True
                    self._consecutive_failures = 0
                    self._stop_polling()
                    heartbeat_task = asyncio.create_task(self._heartbeat_loop(ws))
                    try:
                        async for raw in ws:
                            self._handle_message(
                                raw if isinstance(raw, str) else raw.decode("utf-8")
                            )
                    finally:
                        heartbeat_task.cancel()
                        try:
                            await heartbeat_task
                        except asyncio.CancelledError:
                            pass
            except InvalidStatus as exc:
                status_code = _status_code_from_invalid(exc)
                self._log(f"handshake failed: status={status_code}")
                if status_code in (401, 403):
                    self._on_disconnect(close_code=CLOSE_INVALID_TOKEN)
                    return
                self._on_disconnect()
            except ConnectionClosed as exc:
                self._log(f"connection closed: code={exc.code} reason={exc.reason}")
                self._on_disconnect(close_code=exc.code)
                if exc.code in (CLOSE_INVALID_TOKEN, CLOSE_TOKEN_REVOKED):
                    return
            except (asyncio.CancelledError, KeyboardInterrupt):
                raise
            except Exception as exc:  # pragma: no cover - network jitter
                self._log(f"connection error: {exc!r}")
                self._on_disconnect()

            if self._stopped:
                return

            self._consecutive_failures += 1
            if (
                not self._disable_poll_fallback
                and self._consecutive_failures >= self._poll_fallback_after_failures
                and (self._poll_task is None or self._poll_task.done())
            ):
                self._poll_task = asyncio.create_task(self._polling_loop())

            delay = self._compute_backoff()
            self._log(
                f"reconnect in {delay:.2f}s (attempt {self._consecutive_failures})"
            )
            try:
                await asyncio.sleep(delay)
            except asyncio.CancelledError:
                raise

    def _compute_backoff(self) -> float:
        """Full-jitter exponential backoff capped at ``max_reconnect_delay``."""
        base = min(
            self._reconnect_delay * (2 ** max(0, self._consecutive_failures - 1)),
            self._max_reconnect_delay,
        )
        return random.uniform(0.0, base)

    async def _heartbeat_loop(self, ws: Any) -> None:
        while True:
            await asyncio.sleep(self._heartbeat_interval)
            payload = {
                "type": "heartbeat",
                "sdk_version": __version__,
                "language": "python",
                "env": self._environment,
                "timestamp": int(time.time()),
            }
            try:
                await ws.send(json.dumps(payload))
            except ConnectionClosed:
                return

    def _handle_message(self, raw: str) -> None:
        try:
            msg = json.loads(raw)
        except json.JSONDecodeError:
            return
        if not isinstance(msg, dict):
            return
        msg_type = msg.get("type")
        if msg_type == "status":
            self._apply_status_payload(msg)
        elif msg_type == "revoked":
            self._log(f"token revoked: {msg.get('reason')}")
            self._set_status("OFFLINE")
        elif msg_type == "error":
            self._log(f"server error: {msg.get('code')} {msg.get('message')}")

    def _on_disconnect(self, close_code: Optional[int] = None) -> None:
        self._connected = False
        # Fail-closed: if we lose the connection, assume the service is down.
        if self.get_fail_mode() == "closed" and self.get_status() != "OFFLINE":
            self._set_status("OFFLINE")

    # --------------------------------------------------------- poll fallback

    def _stop_polling(self) -> None:
        if self._polling_active:
            self._polling_active = False
            self._log("deactivating HTTP poll fallback — WS restored")

    async def _polling_loop(self) -> None:
        if self._polling_active:
            return
        self._polling_active = True
        self._log(
            f"activating HTTP poll fallback (after {self._consecutive_failures} WS failures, "
            f"interval={self._poll_interval}s)"
        )
        url = f"{self._api_url}/api/v1/status/{self._token}"
        loop = asyncio.get_event_loop()
        while self._polling_active and not self._stopped and not self._connected:
            await loop.run_in_executor(None, self._poll_once, url)
            try:
                await asyncio.sleep(self._poll_interval)
            except asyncio.CancelledError:
                return

    def _poll_once(self, url: str) -> None:
        try:
            req = urllib.request.Request(
                url, headers={"User-Agent": f"pxcontrol-sdk-python/{__version__}"}
            )
            with urllib.request.urlopen(req, timeout=POLL_REQUEST_TIMEOUT) as resp:
                status = getattr(resp, "status", 200)
                if status in (401, 403, 404):
                    self._log(f"poll fallback auth/not-found ({status}) — stopping")
                    self._polling_active = False
                    self._set_status("OFFLINE")
                    return
                if status != 200:
                    self._log(f"poll fallback non-200: {status}")
                    return
                body = json.loads(resp.read().decode("utf-8"))
                if isinstance(body, dict):
                    self._apply_status_payload(body)
        except (
            urllib.error.URLError,
            json.JSONDecodeError,
            TimeoutError,
            OSError,
        ) as exc:
            self._log(f"poll fallback error: {exc!r}")

    # ---------------------------------------------------------- version check

    def _check_version_sync(self) -> None:
        url = f"{self._api_url}/api/v1/sdk/versions"
        try:
            req = urllib.request.Request(
                url, headers={"User-Agent": f"pxcontrol-sdk-python/{__version__}"}
            )
            with urllib.request.urlopen(req, timeout=VERSION_CHECK_TIMEOUT) as resp:
                if getattr(resp, "status", 200) != 200:
                    return
                catalog = json.loads(resp.read().decode("utf-8"))
                latest = (catalog.get("python") or {}).get("latest")
                if not latest:
                    return
                if _compare_semver(__version__, latest) < 0:
                    logger.warning(
                        "[pxcontrol] A newer SDK is available (installed %s, latest %s). "
                        "Run: pip install -U pxcontrol",
                        __version__,
                        latest,
                    )
        except Exception:  # pragma: no cover - best-effort
            return


# --------------------------------------------------------------- singleton API

_singleton: Optional[PxClient] = None
_singleton_lock = threading.Lock()


def get_client(**kwargs: Any) -> PxClient:
    """Return a process-wide :class:`PxClient` singleton, creating it if needed."""
    global _singleton
    with _singleton_lock:
        if _singleton is None:
            _singleton = PxClient(**kwargs)
        return _singleton


def reset_client() -> None:
    """Stop and discard the singleton (mainly for tests / graceful shutdown)."""
    global _singleton
    with _singleton_lock:
        if _singleton is not None:
            _singleton.stop()
            _singleton = None
