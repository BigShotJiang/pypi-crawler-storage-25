# Changelog

All notable changes to `pxcontrol` will be documented here. The format
follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and this
project adheres to [Semantic Versioning](https://semver.org/).

## [0.1.1] - 2026-04-17

### Changed
- Default `ws_url` switched from `wss://ws.pxcontrol.io` to
  `wss://api-pxcontrol.codefied.online` (same host now serves HTTP + WS).
- `api_url` derives from `ws_url` automatically.

## [0.1.0] - 2026-04-17

Initial public release.

### Added
- `PxClient` running an asyncio loop in a daemon thread so it works
  identically in sync (Flask, Django/WSGI, scripts) and async
  (FastAPI, Starlette) frameworks.
- Auto-reconnect with exponential backoff + full-jitter, capped at 60s.
- Middleware integrations:
  - `PxControlASGIMiddleware` — FastAPI / Starlette / any ASGI app.
  - `PxControlWSGIMiddleware` — Flask / classic Django / generic WSGI.
  - `DjangoPxControlMiddleware` — modern Django `MIDDLEWARE` class.
- Heartbeats (`30s` default) with `sdk_version`, `language`, `env`,
  `timestamp`.
- HTTP poll fallback (`GET /api/v1/status/{token}`) after 3 consecutive
  WS failures; stops automatically once the WS reconnects.
- Boot-time version check against `GET /api/v1/sdk/versions`.
- Configurable `fail_mode` (`closed` / `open`), `health_path`, `debug`,
  and all poll / version-check toggles via kwargs **or** environment
  variables (`PX_TOKEN`, `PX_WS_URL`, `PX_API_URL`, `PX_DEBUG`,
  `PX_DISABLE_POLL`, `PX_DISABLE_VERSION_CHECK`).
- Typed with `from __future__ import annotations`; supports Python 3.9+.
- Built on the modern `websockets.asyncio.client` API (requires
  `websockets>=13`).
