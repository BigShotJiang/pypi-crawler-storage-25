from setuptools import setup

setup(
    name='ataturk-mcp',
    version='0.1.2',
    description="An MCP server that exposes the corpus of Atatürk's speeches, statements, telegrams and proclamations (1906-1938) for researchers worldwide. Created by bugraayan.com.",
    long_description='# Atatürk MCP\n\n> Created by **[Buğra Ayan — bugraayan.com](https://bugraayan.com)**\n>\n> *Tüm dünyadan Atatürk üzerine araştırma yapanlar için açık kaynak bir köprü.*\n\nA [Model Context Protocol](https://modelcontextprotocol.io/) server that exposes the\ncomplete corpus of **Mustafa Kemal Atatürk\'s speeches, statements, telegrams and\nproclamations (1906-1938)** to any MCP-aware AI client (Claude Desktop, Cursor, Cline,\nWindsurf, …).\n\nBuilt for researchers, historians, journalists and students anywhere in the world who\nwant to ask LLMs questions like:\n\n- *"What did Atatürk say about women\'s rights in 1923?"*\n- *"Find quotes about education and modernisation."*\n- *"Show me his opening address to the Grand National Assembly on 1 March 1922."*\n- *"Compare the 1927 Nutuk\'s treatment of the War of Independence with his 1933 10th\n  Year Speech."*\n\n## Corpus\n\n| Source | Coverage | Format | Speeches |\n| --- | --- | --- | --- |\n| [ATAM — Atatürk Araştırma Merkezi](https://atam.gov.tr/) "Söylev ve Demeçleri" Cilt I-III (2024 edition) | 1906-1938, **the definitive corpus** | PDF | 366 |\n| [Vikikaynak](https://tr.wikisource.org/wiki/Kategori:Mustafa_Kemal_Atat%C3%BCrk) | Individual speeches, telegrams, all TBMM opening addresses (1920-1938) | HTML | 45 |\n| [Internet Archive — Nutuk (English)](https://archive.org/details/361505859-a-speech-delivered-by-mustafa-kemal-ataturk-1927-aka-nutuk-in-english-aka-the-great-speech) | The 1927 *Nutuk* in English | PDF / DjVu | 20 chapters |\n| **Total** | 1906-1938 | SQLite + FTS5 | **411 speeches + Nutuk** |\n\nAtatürk passed away in 1938; his words are in the public domain. Editorial\nannotations from the ATAM edition are *not* redistributed — only the speech bodies\nthemselves, with a `source_ref` pointing back to the corresponding ATAM volume and\npage number for academic citation.\n\n## Quick start\n\n### 1. Install\n\nFrom PyPI (recommended for end users):\n\n```bash\npip install ataturk-mcp                # runtime only\npip install "ataturk-mcp[etl]"         # also includes the ETL scripts\n```\n\nFrom source (for hacking on the ETL):\n\n```bash\ngit clone https://github.com/bugraayan/ataturk-mcp.git\ncd ataturk-mcp\npython3 -m venv .venv && source .venv/bin/activate\npip install -e ".[etl]"\n```\n\n### 2. Build the database (one-off, ~1 minute)\n\n```bash\npython scripts/fetch_atam.py            # ~10 MB of PDFs from atam.gov.tr\npython scripts/fetch_wikisource.py      # MediaWiki API, ~45 pages\npython scripts/fetch_nutuk_en.py        # ~2 MB DjVu text from Internet Archive\npython scripts/build_db.py              # produces data/speeches.db (~11 MB)\n```\n\nOr, if you only want the core corpus:\n\n```bash\npython scripts/fetch_atam.py\npython scripts/build_db.py --skip-wikisource --skip-nutuk\n```\n\nA pre-built `speeches.db` is also published on the GitHub Releases page so end\nusers do not need to run the ETL themselves.\n\n### 3. Run the MCP server\n\n```bash\nataturk-mcp                  # stdio transport (default, used by all MCP clients)\n# or\nfastmcp run src/ataturk_mcp/server.py:mcp\n# or\npython -m ataturk_mcp.server\n```\n\n## Connecting to MCP clients\n\n### Claude Desktop\n\nEdit `~/Library/Application Support/Claude/claude_desktop_config.json` (macOS) or the\nequivalent on your platform and add:\n\n```json\n{\n  "mcpServers": {\n    "ataturk": {\n      "command": "/absolute/path/to/.venv/bin/ataturk-mcp"\n    }\n  }\n}\n```\n\nIf your database lives somewhere other than the repo, set the path explicitly:\n\n```json\n{\n  "mcpServers": {\n    "ataturk": {\n      "command": "/absolute/path/to/.venv/bin/ataturk-mcp",\n      "env": {\n        "ATATURK_MCP_DB": "/path/to/speeches.db"\n      }\n    }\n  }\n}\n```\n\nRestart Claude Desktop; the hammer icon now exposes the Atatürk tools.\n\n### Cursor\n\nEdit `~/.cursor/mcp.json` (or the project-level `.cursor/mcp.json`):\n\n```json\n{\n  "mcpServers": {\n    "ataturk": {\n      "command": "/absolute/path/to/.venv/bin/ataturk-mcp"\n    }\n  }\n}\n```\n\n### Cline / Continue / any MCP host\n\nUse the same `command` line with whichever JSON the host expects. The server speaks\nstdio by default and follows the MCP 2024-11-05 spec.\n\n## Tools exposed\n\n| Tool | Purpose |\n| --- | --- |\n| `search_speeches(query, lang, year_from, year_to, kind, limit)` | Full-text BM25 search over the entire corpus, with snippets. Diacritic-insensitive; supports FTS5 operators (`AND`, `OR`, `NEAR`, `"phrases"`, `prefix*`). |\n| `get_speech(speech_id, lang)` | Return one speech in full, in Turkish or English. |\n| `list_speeches(year, year_from, year_to, kind, source, limit, offset)` | Browse the corpus chronologically. |\n| `random_speech(lang, kind)` | Pick a random speech (useful for daily-quote agents). |\n| `list_topics()` / `speeches_by_topic(topic_id, limit)` | Topical browsing (when ATAM Konular İndeksi is loaded). |\n| `nutuk_search(query, lang, limit)` | Search within Nutuk (1927). |\n| `nutuk_chapter(chapter, lang)` | Return one Nutuk chapter (1-20). |\n| `cite(speech_id)` | Generate APA / MLA / Chicago citations. |\n| `corpus_stats()` | Summary statistics about the corpus. |\n\n### Resources\n\n| URI | Description |\n| --- | --- |\n| `ataturk://speech/{speech_id}` | Plain-text rendering of a single speech with header. |\n| `ataturk://nutuk/{chapter}/{lang}` | One Nutuk chapter. |\n| `ataturk://corpus/stats` | Statistics as JSON. |\n\n### Prompts\n\n| Prompt | Use |\n| --- | --- |\n| `analyze_speech(speech_id)` | Scholarly analysis template (context, rhetoric, themes, citation). |\n| `find_quote(theme, n_quotes)` | Theme-based quote hunter across the corpus. |\n\n## Development\n\n```bash\npip install -e ".[etl,dev]"\npytest -q\nruff check .\n```\n\nThe test suite uses an in-memory seeded SQLite DB and FastMCP\'s in-process client,\nso it runs in under a second and does **not** require the production DB to be\nbuilt.\n\n## Architecture\n\n```\nATAM PDFs ─┐\nVikikaynak ─┼─► ETL scripts ─► SQLite (FTS5) ─► FastMCP stdio server ─► AI clients\nNutuk EN ──┘                  speeches.db\n```\n\n- ETL (`scripts/`) is fully decoupled from the server (`src/ataturk_mcp/`).\n- The server opens the DB read-only and is safe to run in parallel from multiple\n  clients.\n- Turkish search quality: FTS5 with `unicode61 remove_diacritics 2` plus\n  application-level I/İ normalisation in `db.normalise_query`.\n\n## Publishing to PyPI\n\nThe project is wired to publish from GitHub Actions (see\n[`.github/workflows/release.yml`](.github/workflows/release.yml)) when you push a\ntag of the form `vX.Y.Z`. For manual publishing:\n\n```bash\npip install build twine\npython -m build                          # produces dist/*.whl and dist/*.tar.gz\ntwine check dist/*\ntwine upload dist/*                      # uploads to https://pypi.org/project/ataturk-mcp/\n# or for a dry run on TestPyPI:\ntwine upload --repository testpypi dist/*\n```\n\n## Credits & author\n\n- **Author:** [Buğra Ayan — bugraayan.com](https://bugraayan.com)\n- **Email:** `hello@bugraayan.com`\n- **Atatürk Araştırma Merkezi (ATAM)** — for digitising and editing the *Söylev\n  ve Demeçleri* corpus, the gold-standard source for this project.\n- **Vikikaynak / Türkçe Wikisource contributors** — for transcribing\n  individual addresses and the TBMM opening speeches.\n- **Internet Archive** — for hosting the public-domain English Nutuk.\n\nIf you build research or journalism on top of this server, please cite both\nAtatürk\'s words (via the in-tool `cite` command) **and** the original sources\n(ATAM volume + page, or the Wikisource URL).\n\n## License\n\nMIT for the code (© Buğra Ayan / [bugraayan.com](https://bugraayan.com)). The\nspeech texts themselves are in the public domain (Atatürk died in 1938). ATAM,\nTBMM and Wikisource are credited as the digital sources used to build the\ncorpus; please respect each source\'s terms when redistributing.\n',
    author_email='Buğra Ayan <bugraayan.com@gmail.com>',
    maintainer_email='Buğra Ayan <bugraayan.com@gmail.com>',
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Education',
        'Intended Audience :: Science/Research',
        'License :: OSI Approved :: MIT License',
        'Natural Language :: English',
        'Natural Language :: Turkish',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Topic :: Education',
        'Topic :: Scientific/Engineering',
    ],
    install_requires=[
        'fastmcp>=2.0.0',
        'pydantic>=2.5.0',
    ],
    extras_require={
        'dev': [
            'pytest-asyncio>=0.23.0',
            'pytest>=8.0.0',
            'ruff>=0.6.0',
        ],
        'etl': [
            'beautifulsoup4>=4.12.0',
            'httpx>=0.27.0',
            'lxml>=5.0.0',
            'pdfplumber>=0.11.0',
            'rich>=13.0.0',
        ],
    },
    entry_points={
        'console_scripts': [
            'ataturk-mcp = ataturk_mcp.server:main',
        ],
    },
    packages=[
        'scripts',
        'ataturk_mcp',
        'tests',
    ],
    package_dir={'': 'src'},
)
