"""Tests for the low-level SQLite layer."""

from __future__ import annotations

import pytest

from ataturk_mcp.db import default_db_path, normalise_query


@pytest.mark.parametrize(
    "raw,expected",
    [
        ("İSTANBUL", "istanbul"),
        ("Atatürk", "atatürk"),
        ("  EĞİTİM   HAKKI ", "eğitim hakkı"),
        ("KILIK kıyafet", "kılık kıyafet"),
        ("", ""),
    ],
)
def test_normalise_query_handles_turkish_case(raw, expected):
    assert normalise_query(raw) == expected


def test_default_db_path_respects_env(monkeypatch, tmp_path):
    p = tmp_path / "custom.db"
    p.write_bytes(b"")
    monkeypatch.setenv("ATATURK_MCP_DB", str(p))
    assert default_db_path() == p.resolve()


def test_fts_diacritic_insensitive_match(fixture_conn):
    """FTS5 with `remove_diacritics 2` should match either 'türk' or 'turk'."""
    for q in ("türk", "turk", "Türk"):
        rows = fixture_conn.execute(
            "SELECT speech_id FROM speeches_fts WHERE speeches_fts MATCH ?",
            (q.lower(),),
        ).fetchall()
        assert rows, f"No FTS hits for {q!r}"


def test_seeded_corpus_has_expected_speeches(fixture_conn):
    n = fixture_conn.execute("SELECT COUNT(*) FROM speeches").fetchone()[0]
    assert n == 5
    bodies = fixture_conn.execute(
        "SELECT COUNT(*) FROM speech_texts WHERE lang='tr'"
    ).fetchone()[0]
    assert bodies == 5
    nutuk = fixture_conn.execute("SELECT COUNT(*) FROM nutuk_chapters").fetchone()[0]
    assert nutuk == 2
