"""End-to-end tests for the FastMCP server.

These use FastMCP's in-process client (no subprocess, no network) and the
seeded fixture DB so they run quickly and deterministically.
"""

from __future__ import annotations

import pytest
from fastmcp import Client


@pytest.fixture
async def client(patched_server):
    async with Client(patched_server) as c:
        yield c


async def test_server_lists_expected_tools(client):
    tools = await client.list_tools()
    names = {t.name for t in tools}
    expected = {
        "search_speeches",
        "get_speech",
        "list_speeches",
        "random_speech",
        "list_topics",
        "speeches_by_topic",
        "nutuk_search",
        "nutuk_chapter",
        "cite",
        "corpus_stats",
    }
    missing = expected - names
    assert not missing, f"Missing tools: {missing}"


async def test_server_lists_resources_and_prompts(client):
    templates = await client.list_resource_templates()
    uris = {t.uriTemplate for t in templates}
    assert "ataturk://speech/{speech_id}" in uris
    assert "ataturk://nutuk/{chapter}/{lang}" in uris

    prompts = await client.list_prompts()
    pnames = {p.name for p in prompts}
    assert {"analyze_speech", "find_quote"} <= pnames


async def test_search_speeches_finds_cumhuriyet(client):
    r = await client.call_tool(
        "search_speeches",
        {"query": "cumhuriyet", "lang": "tr", "limit": 5},
    )
    ids = [h.id for h in r.data]
    # "test-001" has the body "Cumhuriyeti'ni ilân ediyoruz... Cumhuriyet faziletir"
    assert "test-001" in ids
    # Snippet must contain the highlighted match.
    hit = next(h for h in r.data if h.id == "test-001")
    assert "[" in hit.snippet and "]" in hit.snippet


async def test_search_speeches_year_filter(client):
    r = await client.call_tool(
        "search_speeches",
        {"query": "milleti", "year_from": 1930, "year_to": 1940},
    )
    for h in r.data:
        assert h.year is None or 1930 <= h.year <= 1940


async def test_get_speech_returns_full_body(client):
    r = await client.call_tool("get_speech", {"speech_id": "test-003", "lang": "tr"})
    s = r.data
    assert s.title_tr == "Onuncu Yıl Nutku"
    assert s.year == 1933
    assert "Kurtuluş Savaşı" in s.body


async def test_get_speech_unknown_id_raises(client):
    from fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await client.call_tool("get_speech", {"speech_id": "does-not-exist"})


async def test_list_speeches_filters_by_year(client):
    r = await client.call_tool("list_speeches", {"year": 1923, "limit": 50})
    assert {s.id for s in r.data} == {"test-001", "test-004"}


async def test_list_speeches_filters_by_kind(client):
    r = await client.call_tool("list_speeches", {"kind": "telgraf"})
    assert [s.id for s in r.data] == ["test-005"]


async def test_random_speech_returns_one(client):
    r = await client.call_tool("random_speech", {"lang": "tr"})
    assert r.data.id.startswith("test-")
    assert r.data.body


async def test_corpus_stats(client):
    r = await client.call_tool("corpus_stats", {})
    stats = r.data
    assert stats.total_speeches == 5
    assert stats.by_kind.get("konusma") == 4
    assert stats.by_kind.get("telgraf") == 1
    assert "tr" in stats.languages
    assert "en" in stats.languages  # from seeded Nutuk chapter


async def test_nutuk_search_finds_sovereignty(client):
    r = await client.call_tool(
        "nutuk_search", {"query": "sovereignty", "lang": "en", "limit": 3}
    )
    assert len(r.data) >= 1
    assert all("sovereign" in (h["snippet"].lower()) for h in r.data)


async def test_nutuk_chapter_fetch(client):
    r = await client.call_tool("nutuk_chapter", {"chapter": "16", "lang": "en"})
    ch = r.data
    assert ch.chapter == "16"
    assert ch.lang == "en"
    assert "Republic" in ch.body


async def test_cite_apa_includes_year_and_title(client):
    r = await client.call_tool("cite", {"speech_id": "test-003"})
    c = r.data
    assert "1933" in c.apa
    assert "Onuncu Yıl Nutku" in c.apa
    assert c.mla.startswith("Atatürk")


async def test_resource_speech_renders_header(client):
    res = await client.read_resource("ataturk://speech/test-001")
    text = res[0].text
    assert "Cumhuriyetin İlânı" in text
    assert "ID: test-001" in text
    assert "Kaynak:" in text


async def test_resource_nutuk_renders(client):
    res = await client.read_resource("ataturk://nutuk/1/en")
    text = res[0].text
    assert text.startswith("# Nutuk —")
    assert "Samsun" in text


async def test_prompt_analyze_speech_includes_id(client):
    r = await client.get_prompt("analyze_speech", {"speech_id": "test-003"})
    body = " ".join(m.content.text for m in r.messages if hasattr(m.content, "text"))
    assert "test-003" in body
    assert "get_speech" in body
