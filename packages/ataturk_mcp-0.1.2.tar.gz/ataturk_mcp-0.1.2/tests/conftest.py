"""Test fixtures shared across the test suite.

Most tests use a *tiny in-memory SQLite* database with a handful of synthetic
speeches so that the suite runs in well under a second and doesn't depend on
the multi-megabyte production DB. A separate ``real_conn`` fixture loads the
real ``data/speeches.db`` if it has been built (skipping the test otherwise).
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest

from ataturk_mcp.db import init_schema, reset_fts

REPO_ROOT = Path(__file__).resolve().parents[1]
REAL_DB = REPO_ROOT / "data" / "speeches.db"


def _seed(conn: sqlite3.Connection) -> None:
    rows = [
        # id,                       year, date,         title_tr,                                       location,        kind,      source,        ref
        ("test-001",                1923, "1923-10-29", "Cumhuriyetin İlânı Münasebetiyle Konuşma",   "Ankara",        "konusma", "atam_cilt_2", "C-II s. 1"),
        ("test-002",                1925, "1925-08-28", "Şapka Hakkında Yaptığı Konuşma",              "İnebolu",       "konusma", "atam_cilt_3", "C-III s. 13"),
        ("test-003",                1933, "1933-10-29", "Onuncu Yıl Nutku",                            "Ankara",        "konusma", "atam_cilt_3", "C-III s. 226"),
        ("test-004",                1923, "1923-02-07", "Balıkesir Hutbesi",                            "Balıkesir",     "konusma", "wikisource",  "https://tr.wikisource.org/wiki/Bal%C4%B1kesir_Hutbesi"),
        ("test-005",                1920, None,         "TBMM Açılış Telgrafı",                         None,            "telgraf", "atam_cilt_1", "C-I s. 100"),
    ]
    bodies = [
        ("test-001", "tr", "Bugün Türkiye Cumhuriyeti'ni ilân ediyoruz. Egemenlik kayıtsız şartsız milletindir. Cumhuriyet fazilettir."),
        ("test-002", "tr", "Buna şapka derler. Medeni bir kıyafettir. Türk milleti medeniyetin gereklerini benimsemiştir."),
        ("test-003", "tr", "Türk milleti! Kurtuluş Savaşı'na başladığımızdan beri bu önemli yıldönümünde, en sevinçli duygularla, sizleri selamlıyorum."),
        ("test-004", "tr", "Ey millet, Allah birdir. Camiler meşveret için yapılmıştır. Millet işlerini birlikte konuşmak için toplanırız."),
        ("test-005", "tr", "Telgrafhanelere telgraf çekiniz. Millet hareketine hazırdır."),
    ]
    nutuk = [
        ("nutuk-en-ch-1", "1", "en", "I. The situation in Anatolia during WWI",
         "I landed at Samsun on the 19th of May 1919. The general situation at that time was as follows: sovereignty was at stake."),
        ("nutuk-en-ch-16", "16", "en", "XVI. Proclamation of the Republic",
         "On the 29th of October 1923 the Republic of Turkey was proclaimed. Sovereignty rests unconditionally with the nation."),
    ]
    conn.executemany(
        """INSERT INTO speeches
           (id, year, date, title_tr, location, kind, source, source_ref)
           VALUES (?,?,?,?,?,?,?,?)""",
        rows,
    )
    conn.executemany(
        "INSERT INTO speech_texts (speech_id, lang, body) VALUES (?,?,?)",
        bodies,
    )
    conn.executemany(
        "INSERT INTO nutuk_chapters (id, chapter, lang, title, body) VALUES (?,?,?,?,?)",
        nutuk,
    )
    conn.commit()
    reset_fts(conn)


@pytest.fixture
def fixture_db_path(tmp_path: Path) -> Path:
    """Create a fresh seeded SQLite DB in a temporary directory."""
    path = tmp_path / "test.db"
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    init_schema(conn)
    _seed(conn)
    conn.close()
    return path


@pytest.fixture
def fixture_conn(fixture_db_path: Path) -> sqlite3.Connection:
    uri = f"file:{fixture_db_path}?mode=ro"
    conn = sqlite3.connect(uri, uri=True)
    conn.row_factory = sqlite3.Row
    yield conn
    conn.close()


@pytest.fixture
def patched_server(monkeypatch, fixture_db_path: Path):
    """Yield the FastMCP server instance wired to the seeded fixture DB."""
    monkeypatch.setenv("ATATURK_MCP_DB", str(fixture_db_path))
    # Force the server module to reopen its connection with the new env.
    from ataturk_mcp import server as server_module

    server_module._CONN = None
    yield server_module.mcp
    server_module._CONN = None


@pytest.fixture
def real_conn():
    """Open the real production DB if available; skip otherwise."""
    if not REAL_DB.exists():
        pytest.skip(f"Real DB not built at {REAL_DB}. Run scripts/build_db.py.")
    uri = f"file:{REAL_DB}?mode=ro"
    conn = sqlite3.connect(uri, uri=True)
    conn.row_factory = sqlite3.Row
    yield conn
    conn.close()
