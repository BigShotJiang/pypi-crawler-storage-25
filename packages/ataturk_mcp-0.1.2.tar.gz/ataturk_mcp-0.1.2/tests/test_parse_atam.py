"""Unit tests for the ATAM PDF parser helpers (no PDF I/O required)."""

from __future__ import annotations

import pytest
from parse_atam_pdf import (  # type: ignore[import-not-found]
    classify_kind,
    collapse_paragraphs,
    dehyphenate,
    guess_location,
    parse_date,
    strip_editor_footnote,
    strip_running_header,
)


@pytest.mark.parametrize(
    "raw,expected_iso,expected_year",
    [
        ("3 Kânun-ı Sânî 1341 (3 Ocak 1925)", "1925-01-03", 1925),
        ("10 Mayıs 1933", "1933-05-10", 1933),
        ("28 Kânun-ı Evvel 1341 (28 Aralık 1925)", "1925-12-28", 1925),
        ("17 Ekim 1933", "1933-10-17", 1933),
        ("", (None, None)[0], (None, None)[1]),
    ],
)
def test_parse_date_recognises_common_formats(raw, expected_iso, expected_year):
    iso, year = parse_date(raw)
    assert iso == expected_iso
    assert year == expected_year


def test_parse_date_rumi_only_returns_none_iso():
    iso, year = parse_date("3 Kânun-ı Sânî 1337")
    assert iso is None or iso.startswith("1337-")  # depends on guard upstream
    assert year in (1337, None)  # raw extraction; caller filters <1900 later


@pytest.mark.parametrize(
    "title,expected_kind",
    [
        ("Ankara'da Yaptığı Konuşma", "konusma"),
        ("Times Gazetesi'ne Verdiği Demeç", "demec"),
        ("İsmet Paşa'ya Çektiği Telgraf", "telgraf"),
        ("Halka Beyanname", "beyanname"),
        ("Çocuğa Yazdığı Mektup", "mektup"),
    ],
)
def test_classify_kind(title, expected_kind):
    assert classify_kind(title) == expected_kind


@pytest.mark.parametrize(
    "title,expected",
    [
        ("Konya Türk Ocağı'nda Yaptığı Konuşma", "Konya"),
        ("İzmir Belediyesi'nde Yaptığı Konuşma", "İzmir"),
        ("Çankaya Köşkü'nde Yaptığı Konuşma", "Çankaya"),
        ("Anonim Konuşma", None),
    ],
)
def test_guess_location(title, expected):
    assert guess_location(title) == expected


def test_strip_running_header_removes_each_occurrence():
    text = (
        "ATATÜRK’ÜN SÖYLEV VE DEMEÇLERİ C-III\n"
        "Bir konuşma metni.\n"
        "ATATÜRK’ÜN SÖYLEV VE DEMEÇLERİ C-III\n"
        "Diğer satır.\n"
    )
    out = strip_running_header(text)
    assert "SÖYLEV VE DEMEÇLERİ" not in out
    assert "Bir konuşma metni." in out
    assert "Diğer satır." in out


def test_strip_editor_footnote_removes_asterisk_block():
    text = "Konuşmanın gövdesi.\n* Mehmet Önder, Atatürk Konya'da, TTK, 1989, s. 63."
    out = strip_editor_footnote(text)
    assert "Mehmet Önder" not in out
    assert "Konuşmanın gövdesi." in out


def test_dehyphenate_merges_split_words():
    assert dehyphenate("muhak-\nkak") == "muhakkak"
    assert dehyphenate("mu-\nrakabe") == "murakabe"


def test_collapse_paragraphs_preserves_paragraph_breaks():
    text = "İlk paragraf\nsatır iki.\n\nİkinci paragraf\nsatır iki.\n\n\nÜçüncü."
    out = collapse_paragraphs(text)
    paras = out.split("\n\n")
    assert paras == [
        "İlk paragraf satır iki.",
        "İkinci paragraf satır iki.",
        "Üçüncü.",
    ]
