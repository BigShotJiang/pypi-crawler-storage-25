"""Parse an ATAM "Söylev ve Demeçleri" PDF into structured speech records.

The 2024 ATAM edition has a predictable structure across all three volumes:

1. Front matter (cover, dedications, foreword) — skipped.
2. "İÇİNDEKİLER" (table of contents) — used as the master index. The ToC
   lists year headings (``1925``) and numbered entries of the form
   ``42. <Title> ... <body_page>``.
3. Body — each speech starts on its own page with an all-caps header line
   ``<NUMBER>. <TITLE>*`` followed by a date line and the body text. A page
   running header (``ATATÜRK'ÜN SÖYLEV VE DEMEÇLERİ C-III``) appears at the
   top of every body page, and a small Arabic page number at the bottom.

This module turns those PDFs into a list of :class:`ParsedSpeech` records that
``scripts/build_db.py`` then loads into SQLite.

Usage::

    python scripts/parse_atam_pdf.py data/raw/atam/ataturkun-soylev-ve-demecleri-c3.pdf
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import unicodedata
from collections.abc import Iterator
from dataclasses import asdict, dataclass
from pathlib import Path

import pdfplumber
from rich.console import Console

REPO_ROOT = Path(__file__).resolve().parents[1]


# ---------------------------------------------------------------------------
# Data model used to hand off to build_db.py
# ---------------------------------------------------------------------------


@dataclass
class ParsedSpeech:
    """A single speech extracted from an ATAM volume."""

    id: str
    volume: int
    year: int | None
    date_iso: str | None
    date_raw: str | None
    number_in_year: int
    title_tr: str
    location: str | None
    body: str
    kind: str  # konusma | demec | telgraf | beyanname | mektup
    source: str  # 'atam_cilt_3'
    source_ref: str  # 'C-III s. 12'
    body_page_start: int
    body_page_end: int

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class _TocEntry:
    year: int
    number_in_year: int
    title: str
    body_page: int  # printed page number (Arabic, starting at 1 for body)


# ---------------------------------------------------------------------------
# Text normalisation helpers
# ---------------------------------------------------------------------------


# The ATAM PDFs occasionally interleave invisible joiners or zero-width chars
# (the curly-quote replacements broke character encoding in places). Strip them.
_INVISIBLE_RX = re.compile(r"[\u200b-\u200f\u202a-\u202e\ufeff\ufffd]")
_SOFT_HYPHEN_RX = re.compile(r"\u00ad")
_LINE_HYPHEN_RX = re.compile(r"-\n(?=[a-zçğıöşü])")  # split words at line breaks


def clean_text(text: str) -> str:
    """Lightweight text cleanup applied to every extracted chunk."""
    if not text:
        return ""
    text = unicodedata.normalize("NFC", text)
    text = _INVISIBLE_RX.sub("", text)
    text = _SOFT_HYPHEN_RX.sub("", text)
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    return text


def dehyphenate(text: str) -> str:
    """Merge words that were split across line breaks (``mu-\nhakkak`` → ``muhakkak``)."""
    return _LINE_HYPHEN_RX.sub("", text)


def collapse_paragraphs(text: str) -> str:
    """Turn pdfplumber's hard line wraps into proper paragraphs.

    The PDFs put a newline at the end of every visual line. We preserve double
    newlines (paragraph boundaries) but merge single newlines inside paragraphs
    into spaces.
    """
    paragraphs = re.split(r"\n\s*\n+", text)
    out = []
    for p in paragraphs:
        merged = re.sub(r"\s*\n\s*", " ", p).strip()
        if merged:
            out.append(merged)
    return "\n\n".join(out)


# ---------------------------------------------------------------------------
# Page-level helpers (running headers / footers)
# ---------------------------------------------------------------------------


# The running header on body pages. We match the leading "ATATÜRK'ÜN SÖYLEV VE
# DEMEÇLERİ" prefix; the suffix varies by volume (``C-I``, ``C-II``, ``C-III``).
_RUNNING_HEADER_RX = re.compile(
    r"^ATATÜRK[’'`]?ÜN\s+SÖYLEV\s+VE\s+DEMEÇLER[İI].*$",
    re.MULTILINE,
)


def strip_running_header(text: str) -> str:
    return _RUNNING_HEADER_RX.sub("", text)


_PAGE_NUMBER_RX = re.compile(r"^\s*\d{1,4}\s*$", re.MULTILINE)


def strip_trailing_page_number(text: str) -> str:
    """Remove a bare page number that appears as the last non-empty line."""
    lines = text.rstrip().split("\n")
    while lines and not lines[-1].strip():
        lines.pop()
    if lines and _PAGE_NUMBER_RX.match(lines[-1]):
        lines.pop()
    return "\n".join(lines)


# Footnote markers placed by the ATAM editors that we do NOT want to keep in the
# body text (they are protected by editorial copyright and not part of Atatürk's
# words). They appear at the bottom of the last page of a speech, prefixed by
# an asterisk and rendered in smaller type.
_FOOTNOTE_RX = re.compile(r"^\*\s.+(?:\n(?!\d+\.\s+[A-ZÇĞİÖŞÜ]).+)*", re.MULTILINE)


def strip_editor_footnote(text: str) -> str:
    return _FOOTNOTE_RX.sub("", text)


# ---------------------------------------------------------------------------
# Table-of-contents parser
# ---------------------------------------------------------------------------


# A ToC year heading is a line consisting solely of 4 digits between 1900-1999.
_TOC_YEAR_RX = re.compile(r"^\s*(19\d{2})\s*$")

# A ToC entry. Matches:
#   "42. <title> ........... 88"
# The leader is two or more dots, possibly with thin spaces in between.
_TOC_ENTRY_RX = re.compile(
    r"^\s*(\d{1,4})\.\s+(.+?)\s*(?:\.{2,}|\u2026+)\s*(\d{1,4})\s*$"
)

# Continuation line of a ToC title: starts in column 0, not a year, not a
# numbered entry, and the previous line ended without a page number.
_TOC_CONT_BAD_PREFIX = re.compile(r"^\s*(\d+\.\s|İÇİNDEKİLER|KISALTMALAR|ÖN SÖZ)")


def parse_toc(pdf: pdfplumber.PDF, max_toc_page: int = 30) -> list[_TocEntry]:
    """Extract the master speech list from the volume's table of contents.

    Scans the first ``max_toc_page`` pages, locates ``İÇİNDEKİLER``, and reads
    numbered entries with their printed page numbers. Year context is carried
    between entries.
    """
    raw_lines: list[str] = []
    started = False
    for page in pdf.pages[:max_toc_page]:
        text = clean_text(page.extract_text() or "")
        if not text:
            continue
        if not started:
            if "İÇİNDEKİLER" in text:
                started = True
                idx = text.index("İÇİNDEKİLER")
                text = text[idx:]
            else:
                continue
        raw_lines.extend(text.split("\n"))

    if not started:
        return []

    entries: list[_TocEntry] = []
    current_year: int | None = None
    pending: list[str] = []
    pending_no: int | None = None

    def flush(title_parts: list[str], number: int, page_no: int) -> None:
        if current_year is None:
            return
        title = re.sub(r"\s+", " ", " ".join(title_parts)).strip()
        if not title:
            return
        entries.append(
            _TocEntry(
                year=current_year,
                number_in_year=number,
                title=title,
                body_page=page_no,
            )
        )

    for line in raw_lines:
        stripped = line.strip()
        if not stripped:
            continue
        year_m = _TOC_YEAR_RX.match(stripped)
        if year_m:
            current_year = int(year_m.group(1))
            pending = []
            pending_no = None
            continue

        entry_m = _TOC_ENTRY_RX.match(stripped)
        if entry_m:
            number = int(entry_m.group(1))
            title = entry_m.group(2).strip()
            body_page = int(entry_m.group(3))
            flush([title], number, body_page)
            pending = []
            pending_no = None
            continue

        # Possibly a wrapped continuation. A new numbered entry without a page
        # number can start the entry; the page number is on the next line.
        m_no = re.match(r"^\s*(\d{1,4})\.\s+(.+?)\s*$", stripped)
        if m_no and current_year is not None:
            pending = [m_no.group(2).strip()]
            pending_no = int(m_no.group(1))
            continue

        # Continuation of a wrapped title that ends with the page number on this line.
        m_cont_pg = re.match(r"^(.*?)\s*(?:\.{2,}|\u2026+)\s*(\d{1,4})\s*$", stripped)
        if m_cont_pg and pending_no is not None:
            pending.append(m_cont_pg.group(1).strip())
            flush(pending, pending_no, int(m_cont_pg.group(2)))
            pending = []
            pending_no = None
            continue

        # Plain wrapped line.
        if pending_no is not None and not _TOC_CONT_BAD_PREFIX.match(stripped):
            pending.append(stripped)
            continue

    return entries


# ---------------------------------------------------------------------------
# Body parser
# ---------------------------------------------------------------------------


# Header pattern at the top of each speech's first page.
#   "1. KONYA'DA YAPTIĞI KONUŞMA*"
#   "41. YÜKSEK ASKERÎ ŞÛRA'NIN AÇILIŞINDA"
# Title may span multiple lines (all caps + numerals + Turkish chars including
# circumflex variants Â/Î/Û). We accept an optional trailing asterisk.
# All-caps Turkish + common Latin diacritics that appear in foreign proper
# names cited in titles (e.g. "FÉLIX", "OLSZOWSKY", "MICHEL TSAMADOS").
_TITLE_CHARS = (
    r"A-ZÇĞİÖŞÜÂÎÛ0-9’'\u00ab\u00bb\"\-\s\.\,\(\)/"
    r"ÁÀÄÃÅÆÉÈÊËÍÌÏÓÒÔÕØÚÙÜŸÑŠŽĆČŁŃŘ"
)
_SPEECH_HEADER_FIRSTLINE_RX = re.compile(
    rf"^\s*(\d{{1,4}})\.\s+([{_TITLE_CHARS}]+?)\*?\s*$"
)

# A continuation line of an all-caps title.
_ALLCAPS_LINE_RX = re.compile(rf"^[{_TITLE_CHARS}]+\*?$")

# Date lines like:
#   "3 Kânun-ı Sânî 1341 (3 Ocak 1925)"          (Rumi + Gregorian)
#   "10 Mayıs 1933"                                (modern)
#   "1 Mart 1922 (Türkçe konuşma)"                 (with annotation)
# We require: a day, at least one letter group (month, possibly multi-word with
# Turkish accents including circumflex), and somewhere in the line a 3-4 digit
# year. Parens and dashes are allowed.
_DATE_LINE_RX = re.compile(
    r"^\s*\d{1,2}\s+[A-Za-zÇĞİÖŞÜçğıöşüâîûÂÎÛ\-’'\s]+?\d{3,4}.*$"
)


# Mapping from Turkish month name to (1-12).
_TR_MONTHS = {
    "ocak": 1, "şubat": 2, "mart": 3, "nisan": 4, "mayıs": 5, "haziran": 6,
    "temmuz": 7, "ağustos": 8, "eylül": 9, "ekim": 10, "kasım": 11, "aralık": 12,
    "kanunusani": 1, "kanunisani": 1, "kanunievvel": 12, "kanunuevvel": 12,
    "teşrinievvel": 10, "teşrinisani": 11,
}


def parse_date(date_raw: str) -> tuple[str | None, int | None]:
    """Return ``(iso_date, year)`` from a raw Turkish date line.

    Handles three patterns:
      - "3 Kânun-ı Sânî 1341 (3 Ocak 1925)"  -> uses Gregorian in parens
      - "10 Mayıs 1933"                       -> Gregorian directly
      - "3 Ocak 1925"                          -> Gregorian
    """
    if not date_raw:
        return None, None
    text = date_raw.strip()

    # If a Gregorian date is in parentheses, prefer it.
    m = re.search(r"\((\d{1,2})\s+([A-Za-zÇĞİÖŞÜçğıöşüâîûÂÎÛ\-]+)\s+(\d{4})\)", text)
    if not m:
        m = re.search(r"\b(\d{1,2})\s+([A-Za-zÇĞİÖŞÜçğıöşüâîûÂÎÛ\-]+)\s+(\d{4})\b", text)
    if not m:
        return None, None

    day = int(m.group(1))
    month_word = m.group(2).lower().replace("-", "").replace("ı", "ı")
    month_word = month_word.replace("\u0307", "")  # combining dot
    month = _TR_MONTHS.get(month_word)
    if not month:
        # Fallback: try fuzzy match on first 4 chars
        for k, v in _TR_MONTHS.items():
            if month_word.startswith(k[:4]):
                month = v
                break
    year = int(m.group(3))
    if not month:
        return None, year
    if day < 1 or day > 31:
        return None, year
    return f"{year:04d}-{month:02d}-{day:02d}", year


def classify_kind(title: str) -> str:
    t = title.lower()
    if "telgraf" in t:
        return "telgraf"
    if "beyanname" in t or "bildiri" in t:
        return "beyanname"
    if "mektup" in t:
        return "mektup"
    if "demeç" in t or "demec" in t or "gazeteciler" in t and "demeç" in t:
        return "demec"
    return "konusma"


# Guess a city from the title (best-effort).
_LOCATION_RX = re.compile(
    r"\b(Konya|Kastamonu|İnebolu|İzmir|İstanbul|Ankara|Bursa|Manisa|Akhisar|"
    r"Eskişehir|Afyonkarahisar|Sivas|Erzurum|Samsun|Trabzon|Adana|Mersin|"
    r"Çankaya|Dolmabahçe|TBMM|Kemalpaşa|Daday|Balıkesir|Diyarbakır|Kayseri|"
    r"Adıyaman|Tokat|Niğde|Mardin|Antalya|Gaziantep|Edirne|Çankırı)\b"
)


def guess_location(title: str) -> str | None:
    m = _LOCATION_RX.search(title)
    return m.group(1) if m else None


def _iter_body_pages(pdf: pdfplumber.PDF) -> Iterator[tuple[int, int, str]]:
    """Yield ``(pdf_page_index, printed_page_number, text)`` for each body page.

    The printed page number is read from the last numeric line on the page.
    """
    for idx, page in enumerate(pdf.pages):
        text = clean_text(page.extract_text() or "")
        if not text.strip():
            continue
        # Last bare-number line is the printed page number.
        printed = None
        for line in reversed(text.split("\n")):
            stripped = line.strip()
            if not stripped:
                continue
            if _PAGE_NUMBER_RX.match(stripped):
                printed = int(stripped)
            break
        if printed is None:
            continue
        yield idx, printed, text


def _detect_speech_header(text: str) -> tuple[int, str] | None:
    """If a page begins (after the running header) with a numbered speech header,
    return ``(speech_number, full_title)``. Otherwise return ``None``.
    """
    body = strip_running_header(text).lstrip("\n")
    lines = body.split("\n")
    # Skip blank lines.
    i = 0
    while i < len(lines) and not lines[i].strip():
        i += 1
    if i >= len(lines):
        return None
    m = _SPEECH_HEADER_FIRSTLINE_RX.match(lines[i].strip())
    if not m:
        return None
    number = int(m.group(1))
    title_parts = [m.group(2).strip()]
    j = i + 1
    while j < len(lines):
        s = lines[j].strip()
        if not s:
            break
        # If next non-empty line is a date, stop.
        if _DATE_LINE_RX.match(s):
            break
        # If still all caps, treat as continuation.
        if _ALLCAPS_LINE_RX.match(s) and not _TOC_YEAR_RX.match(s):
            title_parts.append(s.rstrip("*").strip())
            j += 1
            continue
        break
    title = re.sub(r"\s+", " ", " ".join(title_parts)).strip().rstrip("*").strip()
    title = title.strip("'\u2019")
    return number, title


def _extract_date_and_body(page_text: str, title_line_count: int) -> tuple[str | None, str]:
    """Given the cleaned first page of a speech (running header removed),
    pull out the date line and the body of the speech on that page."""
    lines = strip_running_header(page_text).lstrip("\n").split("\n")
    # Walk past blank lines and the title block.
    i = 0
    while i < len(lines) and not lines[i].strip():
        i += 1
    # Skip the title lines (we counted them while detecting the header).
    i += title_line_count
    # Skip blanks.
    while i < len(lines) and not lines[i].strip():
        i += 1
    date_raw: str | None = None
    if i < len(lines) and _DATE_LINE_RX.match(lines[i].strip()):
        date_raw = lines[i].strip()
        i += 1
    body_text = "\n".join(lines[i:])
    return date_raw, body_text


def parse_volume(
    pdf_path: Path,
    volume: int,
    *,
    console: Console | None = None,
) -> list[ParsedSpeech]:
    """Parse one ATAM PDF into a list of :class:`ParsedSpeech`."""
    console = console or Console(quiet=True)
    source = f"atam_cilt_{volume}"
    roman = {1: "I", 2: "II", 3: "III"}[volume]

    speeches: list[ParsedSpeech] = []

    with pdfplumber.open(str(pdf_path)) as pdf:
        toc = parse_toc(pdf)
        console.print(f"[cyan]ToC entries found:[/cyan] {len(toc)}")

        body_pages: list[tuple[int, int, str]] = list(_iter_body_pages(pdf))

        # Detect speech headers across body pages.
        # We need a way to attribute each header page to a (year, number_in_year)
        # so we can match it to the ToC. We walk through body pages once,
        # building "(start_pdf_idx, end_pdf_idx, number, header_title, date_raw)"
        # records; year is carried from ToC start.

        @dataclass
        class _BodyHeader:
            pdf_idx: int
            printed_page: int
            number: int
            title: str
            date_raw: str | None
            body_first_page_text: str  # body text on the header's page (post-date)

        body_headers: list[_BodyHeader] = []

        for pdf_idx, printed, text in body_pages:
            hdr = _detect_speech_header(text)
            if hdr is None:
                continue
            number, title = hdr
            body = strip_running_header(text).lstrip("\n")
            lines = body.split("\n")
            i = 0
            while i < len(lines) and not lines[i].strip():
                i += 1
            # Determine how many lines the title occupied.
            title_line_count = 1
            j = i + 1
            while j < len(lines):
                s = lines[j].strip()
                if not s:
                    break
                if _DATE_LINE_RX.match(s):
                    break
                if _ALLCAPS_LINE_RX.match(s):
                    title_line_count += 1
                    j += 1
                    continue
                break
            date_raw, body_text = _extract_date_and_body(text, title_line_count)
            body_headers.append(
                _BodyHeader(
                    pdf_idx=pdf_idx,
                    printed_page=printed,
                    number=number,
                    title=title,
                    date_raw=date_raw,
                    body_first_page_text=body_text,
                )
            )

        console.print(f"[cyan]Body speech headers detected:[/cyan] {len(body_headers)}")

        # Map ToC entries to body headers by (printed_page, number).
        # Build a quick lookup of body headers keyed by printed page.
        bh_by_page: dict[int, _BodyHeader] = {bh.printed_page: bh for bh in body_headers}

        for toc_entry in toc:
            bh = bh_by_page.get(toc_entry.body_page)
            if bh is None or bh.number != toc_entry.number_in_year:
                # Header layout differs (e.g. title slightly off). Fall back to
                # finding by number and nearest page.
                candidates = [
                    h for h in body_headers
                    if h.number == toc_entry.number_in_year
                    and abs(h.printed_page - toc_entry.body_page) <= 1
                ]
                if not candidates:
                    console.print(
                        f"[yellow]No body header for ToC entry "
                        f"{toc_entry.year}#{toc_entry.number_in_year} "
                        f"'{toc_entry.title[:40]}…' (page {toc_entry.body_page})[/yellow]"
                    )
                    continue
                bh = candidates[0]

            # Find next body header's pdf_idx to know where this speech ends.
            next_pdf_idx: int | None = None
            for h in body_headers:
                if h.pdf_idx > bh.pdf_idx:
                    next_pdf_idx = h.pdf_idx
                    break

            # Assemble body across pages.
            body_chunks: list[str] = [bh.body_first_page_text]
            last_pdf_idx = bh.pdf_idx
            for pdf_idx, _printed, text in body_pages:
                if pdf_idx <= bh.pdf_idx:
                    continue
                if next_pdf_idx is not None and pdf_idx >= next_pdf_idx:
                    break
                body_chunks.append(strip_running_header(text))
                last_pdf_idx = pdf_idx

            raw_body = "\n".join(body_chunks)
            raw_body = strip_trailing_page_number(raw_body)
            raw_body = strip_editor_footnote(raw_body)
            raw_body = re.sub(r"\n\s*\d+\s*\n", "\n", raw_body)  # mid-text page nos
            raw_body = dehyphenate(raw_body)
            body = collapse_paragraphs(raw_body)

            date_iso, year_from_date = parse_date(bh.date_raw or "")
            # ATAM Cilt I sometimes lists only a Rumi (Hijri) date such as
            # "3 Kânun-ı Sânî 1337". The Rumi year is < 1900; in that case the
            # ToC year (always Gregorian) is the source of truth and we don't
            # expose a bogus ISO date.
            if year_from_date is not None and year_from_date < 1900:
                year_from_date = None
                date_iso = None
            year = year_from_date or toc_entry.year
            kind = classify_kind(toc_entry.title)
            location = guess_location(toc_entry.title)

            speech_id = f"atam-c{volume}-{toc_entry.year}-{toc_entry.number_in_year:03d}"
            speeches.append(
                ParsedSpeech(
                    id=speech_id,
                    volume=volume,
                    year=year,
                    date_iso=date_iso,
                    date_raw=bh.date_raw,
                    number_in_year=toc_entry.number_in_year,
                    title_tr=toc_entry.title,
                    location=location,
                    body=body,
                    kind=kind,
                    source=source,
                    source_ref=f"ATAM, Atatürk'ün Söylev ve Demeçleri C-{roman}, s. {toc_entry.body_page}",
                    body_page_start=bh.printed_page,
                    body_page_end=max(bh.printed_page, last_pdf_idx),
                )
            )

    return speeches


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def detect_volume(pdf_path: Path) -> int:
    name = pdf_path.name.lower()
    if "c3" in name or "cilt-iii" in name or "c-iii" in name:
        return 3
    if "c2" in name or "cilt-ii" in name or "c-ii" in name:
        return 2
    if "c1" in name or "cilt-i" in name or "c-i" in name:
        return 1
    raise ValueError(f"Cannot detect volume from filename: {pdf_path.name}")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pdf", type=Path, help="ATAM PDF path (e.g. data/raw/atam/...-c3.pdf)")
    parser.add_argument(
        "--volume",
        type=int,
        choices=[1, 2, 3],
        help="Override auto-detected volume number.",
    )
    parser.add_argument(
        "--out",
        type=Path,
        help="Optional output JSON path. Defaults to stdout summary only.",
    )
    args = parser.parse_args(argv)

    console = Console()
    volume = args.volume or detect_volume(args.pdf)
    console.rule(f"[bold]Parsing ATAM Cilt {volume}[/bold] ({args.pdf.name})")
    speeches = parse_volume(args.pdf, volume, console=console)

    console.print(f"[green]Extracted[/green] {len(speeches)} speeches.")
    if speeches:
        first = speeches[0]
        console.print(f"  first → [dim]{first.id}[/dim] '{first.title_tr[:60]}'")
        console.print(f"          date={first.date_iso} body_chars={len(first.body)}")
        last = speeches[-1]
        console.print(f"  last  → [dim]{last.id}[/dim] '{last.title_tr[:60]}'")

    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(
            json.dumps([s.to_dict() for s in speeches], ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        console.print(f"[green]Wrote[/green] {args.out.relative_to(REPO_ROOT)}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
