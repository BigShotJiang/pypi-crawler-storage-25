"""Build the SQLite ``speeches.db`` from the parsed sources.

Pipeline:

1. Initialise schema (``ataturk_mcp.db.init_schema``).
2. Parse each available ATAM volume PDF and INSERT into ``speeches`` /
   ``speech_texts``.
3. Optionally merge metadata from Vikikaynak (precise dates, locations).
4. Optionally insert Nutuk (Turkish + English) chapters.
5. Rebuild FTS5 indexes from the populated tables.

The script is idempotent: running it again wipes the existing DB and rebuilds.

Usage::

    python scripts/build_db.py                # default: ./data/speeches.db
    python scripts/build_db.py --db /tmp/sp.db
    python scripts/build_db.py --skip-wikisource --skip-nutuk
"""

from __future__ import annotations

import argparse
import json
import sqlite3
import sys
from collections.abc import Iterable
from pathlib import Path

from rich.console import Console
from rich.table import Table

REPO_ROOT = Path(__file__).resolve().parents[1]
# Allow running the script directly (``python scripts/build_db.py``) by making
# the sibling scripts/ directory importable.
sys.path.insert(0, str(REPO_ROOT / "scripts"))
sys.path.insert(0, str(REPO_ROOT / "src"))

from parse_atam_pdf import ParsedSpeech, detect_volume, parse_volume  # noqa: E402

from ataturk_mcp.db import connect_rw, init_schema, reset_fts, transaction  # noqa: E402

ATAM_DIR = REPO_ROOT / "data" / "raw" / "atam"
WIKISOURCE_CACHE = REPO_ROOT / "data" / "wikisource_cache" / "speeches.json"
NUTUK_DIR = REPO_ROOT / "data" / "raw" / "nutuk"
NUTUK_EN_JSON = NUTUK_DIR / "nutuk_en_chapters.json"


def discover_atam_pdfs(atam_dir: Path) -> list[tuple[int, Path]]:
    if not atam_dir.exists():
        return []
    pdfs: list[tuple[int, Path]] = []
    for pdf in sorted(atam_dir.glob("*.pdf")):
        try:
            volume = detect_volume(pdf)
        except ValueError:
            continue
        pdfs.append((volume, pdf))
    pdfs.sort(key=lambda t: t[0])
    return pdfs


def insert_speeches(conn: sqlite3.Connection, speeches: Iterable[ParsedSpeech]) -> int:
    n = 0
    for s in speeches:
        conn.execute(
            """
            INSERT OR REPLACE INTO speeches
                (id, year, date, title_tr, title_en, location, kind, source, source_ref)
            VALUES (?, ?, ?, ?, NULL, ?, ?, ?, ?)
            """,
            (s.id, s.year, s.date_iso, s.title_tr, s.location, s.kind, s.source, s.source_ref),
        )
        conn.execute(
            """
            INSERT OR REPLACE INTO speech_texts (speech_id, lang, body)
            VALUES (?, 'tr', ?)
            """,
            (s.id, s.body),
        )
        n += 1
    return n


def merge_wikisource(conn: sqlite3.Connection, json_path: Path, console: Console) -> int:
    if not json_path.exists():
        console.print(f"[yellow]No Wikisource cache at {json_path.relative_to(REPO_ROOT)} — skipping.[/yellow]")
        return 0
    entries = json.loads(json_path.read_text(encoding="utf-8"))
    n = 0
    for e in entries:
        # Insert as its own speech if not present in ATAM corpus.
        wid = f"wikisource-{e['slug']}"
        conn.execute(
            """
            INSERT OR REPLACE INTO speeches
                (id, year, date, title_tr, title_en, location, kind, source, source_ref)
            VALUES (?, ?, ?, ?, NULL, ?, ?, 'wikisource', ?)
            """,
            (
                wid,
                e.get("year"),
                e.get("date_iso"),
                e["title_tr"],
                e.get("location"),
                e.get("kind", "konusma"),
                e["url"],
            ),
        )
        conn.execute(
            "INSERT OR REPLACE INTO speech_texts (speech_id, lang, body) VALUES (?, 'tr', ?)",
            (wid, e["body"]),
        )
        n += 1
    return n


def merge_nutuk(conn: sqlite3.Connection, json_path: Path, console: Console) -> int:
    if not json_path.exists():
        console.print(f"[yellow]No Nutuk EN cache at {json_path.relative_to(REPO_ROOT)} — skipping.[/yellow]")
        return 0
    chapters = json.loads(json_path.read_text(encoding="utf-8"))
    n = 0
    for ch in chapters:
        chid = f"nutuk-{ch['lang']}-ch-{ch['chapter']}"
        conn.execute(
            """
            INSERT OR REPLACE INTO nutuk_chapters (id, chapter, lang, title, body)
            VALUES (?, ?, ?, ?, ?)
            """,
            (chid, ch["chapter"], ch["lang"], ch.get("title"), ch["body"]),
        )
        n += 1
    return n


def print_summary(conn: sqlite3.Connection, console: Console) -> None:
    table = Table(title="Corpus summary", show_header=True)
    table.add_column("Source")
    table.add_column("Speeches", justify="right")
    table.add_column("Years", justify="right")
    rows = conn.execute(
        "SELECT source, COUNT(*) AS n, MIN(year) AS y0, MAX(year) AS y1 "
        "FROM speeches GROUP BY source ORDER BY source"
    ).fetchall()
    for r in rows:
        years = f"{r['y0']}-{r['y1']}" if r["y0"] is not None else "?"
        table.add_row(r["source"], str(r["n"]), years)
    total = conn.execute("SELECT COUNT(*) FROM speeches").fetchone()[0]
    by_kind = conn.execute(
        "SELECT kind, COUNT(*) AS n FROM speeches GROUP BY kind ORDER BY n DESC"
    ).fetchall()
    nutuk = conn.execute("SELECT lang, COUNT(*) AS n FROM nutuk_chapters GROUP BY lang").fetchall()
    table.add_row("[bold]TOTAL[/bold]", f"[bold]{total}[/bold]", "")
    console.print(table)
    console.print(
        "Kinds: " + ", ".join(f"{r['kind']}={r['n']}" for r in by_kind)
    )
    if nutuk:
        console.print("Nutuk: " + ", ".join(f"{r['lang']}={r['n']}" for r in nutuk))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--db",
        type=Path,
        default=REPO_ROOT / "data" / "speeches.db",
        help="Output SQLite file (default: data/speeches.db).",
    )
    parser.add_argument(
        "--atam-dir",
        type=Path,
        default=ATAM_DIR,
        help="Directory containing the ATAM PDFs.",
    )
    parser.add_argument("--skip-atam", action="store_true")
    parser.add_argument("--skip-wikisource", action="store_true")
    parser.add_argument("--skip-nutuk", action="store_true")
    parser.add_argument(
        "--clean",
        action="store_true",
        help="Delete the existing DB before rebuilding.",
    )
    args = parser.parse_args(argv)

    console = Console()

    if args.clean and args.db.exists():
        args.db.unlink()
        console.print(f"[red]Deleted[/red] {args.db.relative_to(REPO_ROOT)}")

    conn = connect_rw(args.db)
    init_schema(conn)

    if not args.skip_atam:
        pdfs = discover_atam_pdfs(args.atam_dir)
        if not pdfs:
            console.print(
                f"[yellow]No ATAM PDFs found in {args.atam_dir.relative_to(REPO_ROOT)}; "
                "run scripts/fetch_atam.py first.[/yellow]"
            )
        for volume, pdf in pdfs:
            console.rule(f"[bold]ATAM Cilt {volume}[/bold] — {pdf.name}")
            speeches = parse_volume(pdf, volume, console=console)
            with transaction(conn):
                n = insert_speeches(conn, speeches)
            console.print(f"  inserted [green]{n}[/green] speeches")

    if not args.skip_wikisource:
        console.rule("[bold]Vikikaynak[/bold]")
        with transaction(conn):
            n = merge_wikisource(conn, WIKISOURCE_CACHE, console)
        if n:
            console.print(f"  merged [green]{n}[/green] Wikisource entries")

    if not args.skip_nutuk:
        console.rule("[bold]Nutuk[/bold]")
        with transaction(conn):
            n = merge_nutuk(conn, NUTUK_EN_JSON, console)
        if n:
            console.print(f"  inserted [green]{n}[/green] Nutuk chapter rows")

    console.rule("[bold]Building FTS indexes[/bold]")
    reset_fts(conn)
    console.print("[green]FTS5 rebuilt.[/green]")

    print_summary(conn, console)
    conn.close()
    console.print(f"\n[bold green]Database ready:[/bold green] {args.db.relative_to(REPO_ROOT)} "
                  f"({args.db.stat().st_size / 1_048_576:.1f} MiB)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
