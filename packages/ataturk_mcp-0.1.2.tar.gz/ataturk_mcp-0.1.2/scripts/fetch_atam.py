"""Download the three volumes of "Atatürk'ün Söylev ve Demeçleri" from ATAM.

The 2024 ATAM (Atatürk Araştırma Merkezi) edition is the definitive corpus of
Atatürk's speeches and statements from 1906-1938, organised chronologically:

    Cilt I   1906-1921
    Cilt II  1922-1924
    Cilt III 1925-1938

The PDFs are hosted publicly at ``atam.gov.tr/wp-content/uploads/2024/03/``.

Usage::

    python scripts/fetch_atam.py             # download missing volumes
    python scripts/fetch_atam.py --force     # always re-download
    python scripts/fetch_atam.py --volume 3  # only Cilt III
"""

from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass
from pathlib import Path

import httpx
from rich.console import Console
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    TextColumn,
    TimeRemainingColumn,
    TransferSpeedColumn,
)

REPO_ROOT = Path(__file__).resolve().parents[1]
RAW_DIR = REPO_ROOT / "data" / "raw" / "atam"


@dataclass(frozen=True)
class AtamVolume:
    volume: int
    year_range: tuple[int, int]
    url: str
    filename: str


ATAM_VOLUMES: tuple[AtamVolume, ...] = (
    AtamVolume(
        volume=1,
        year_range=(1906, 1921),
        url="https://atam.gov.tr/wp-content/uploads/2024/03/Ataturkun-Soylev-ve-Demecleri-C1.pdf",
        filename="ataturkun-soylev-ve-demecleri-c1.pdf",
    ),
    AtamVolume(
        volume=2,
        year_range=(1922, 1924),
        url="https://atam.gov.tr/wp-content/uploads/2024/03/Ataturkun-Soylev-ve-Demecleri-C2.pdf",
        filename="ataturkun-soylev-ve-demecleri-c2.pdf",
    ),
    AtamVolume(
        volume=3,
        year_range=(1925, 1938),
        url="https://atam.gov.tr/wp-content/uploads/2024/03/Ataturkun-Soylev-ve-Demecleri-C3.pdf",
        filename="ataturkun-soylev-ve-demecleri-c3.pdf",
    ),
)

USER_AGENT = (
    "ataturk-mcp/0.1 (+https://github.com/ataturk-mcp) "
    "Academic corpus builder for MCP - contact: maintainer@example.com"
)


def download(vol: AtamVolume, dest_dir: Path, force: bool, console: Console) -> Path:
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / vol.filename
    if dest.exists() and not force:
        console.print(
            f"[green]Cilt {vol.volume}[/green] already cached at "
            f"[dim]{dest.relative_to(REPO_ROOT)}[/dim] "
            f"({dest.stat().st_size / 1_048_576:.1f} MiB) — skipping."
        )
        return dest

    headers = {"User-Agent": USER_AGENT}
    tmp = dest.with_suffix(dest.suffix + ".part")
    with (
        httpx.stream("GET", vol.url, headers=headers, follow_redirects=True, timeout=60.0) as r,
        Progress(
            TextColumn(f"[bold]Cilt {vol.volume}[/bold] " + "{task.description}"),
            BarColumn(),
            DownloadColumn(),
            TransferSpeedColumn(),
            TimeRemainingColumn(),
            console=console,
        ) as progress,
        tmp.open("wb") as fh,
    ):
        r.raise_for_status()
        total = int(r.headers.get("content-length", 0)) or None
        task = progress.add_task(vol.filename, total=total)
        for chunk in r.iter_bytes(chunk_size=64 * 1024):
            fh.write(chunk)
            progress.update(task, advance=len(chunk))
    tmp.replace(dest)
    console.print(
        f"[green]Saved[/green] Cilt {vol.volume} "
        f"({vol.year_range[0]}-{vol.year_range[1]}) → {dest.relative_to(REPO_ROOT)} "
        f"({dest.stat().st_size / 1_048_576:.1f} MiB)"
    )
    return dest


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--volume",
        type=int,
        action="append",
        choices=[1, 2, 3],
        help="Only fetch the given volume(s). May be specified multiple times.",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Re-download even if the file already exists in data/raw/atam/.",
    )
    parser.add_argument(
        "--dest",
        type=Path,
        default=RAW_DIR,
        help=f"Destination directory (default: {RAW_DIR.relative_to(REPO_ROOT)})",
    )
    args = parser.parse_args(argv)

    console = Console()
    selected = (
        [v for v in ATAM_VOLUMES if v.volume in set(args.volume)]
        if args.volume
        else list(ATAM_VOLUMES)
    )

    console.rule("[bold]ATAM — Atatürk'ün Söylev ve Demeçleri[/bold]")
    for vol in selected:
        try:
            download(vol, args.dest, args.force, console)
        except httpx.HTTPError as exc:
            console.print(f"[red]Failed to download Cilt {vol.volume}: {exc}[/red]")
            return 1
    console.print("[bold green]Done.[/bold green]")
    return 0


if __name__ == "__main__":
    sys.exit(main())
