"""Fetch Atatürk's speeches that are catalogued on Turkish Wikisource.

We use the MediaWiki API (no scraping needed) and pull from two categories:

* ``Kategori:Mustafa Kemal Atatürk'ün konuşmaları`` — well-known individual
  addresses (Balıkesir Hutbesi, Bursa Nutku, Kastamonu Nutku, etc.).
* ``Kategori:Mustafa Kemal Atatürk'ün TBMM açılış konuşmaları`` — every
  parliamentary opening address (22 entries, 1920-1937).

For each page we capture:

* canonical wiki title and slug (used to build a stable ID);
* the ``{{eser}}`` template fields (title, notes/date, author);
* the body text (wiki markup stripped to plain Turkish prose).

Output is a JSON file at ``data/wikisource_cache/speeches.json`` which is then
consumed by ``scripts/build_db.py``.

Usage::

    python scripts/fetch_wikisource.py
    python scripts/fetch_wikisource.py --force            # bypass cache
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import time
import unicodedata
from dataclasses import asdict, dataclass
from pathlib import Path

import httpx
from rich.console import Console
from rich.progress import track

REPO_ROOT = Path(__file__).resolve().parents[1]
CACHE_DIR = REPO_ROOT / "data" / "wikisource_cache"
PAGES_DIR = CACHE_DIR / "pages"
OUTPUT_JSON = CACHE_DIR / "speeches.json"

API_URL = "https://tr.wikisource.org/w/api.php"

CATEGORIES = [
    "Mustafa Kemal Atatürk'ün konuşmaları",
    "Mustafa Kemal Atatürk'ün TBMM açılış konuşmaları",
    "Mustafa Kemal Atatürk'ün telgrafları",
]

USER_AGENT = (
    "ataturk-mcp/0.1 (+https://github.com/ataturk-mcp; academic corpus builder)"
)


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class WikiSpeech:
    slug: str
    title_tr: str
    url: str
    year: int | None
    date_iso: str | None
    date_raw: str | None
    location: str | None
    kind: str
    body: str
    notes: str | None


# ---------------------------------------------------------------------------
# API helpers
# ---------------------------------------------------------------------------


def _api_get(client: httpx.Client, params: dict) -> dict:
    full = {"format": "json", "formatversion": "2", **params}
    r = client.get(API_URL, params=full)
    r.raise_for_status()
    return r.json()


def category_members(client: httpx.Client, category: str) -> list[str]:
    titles: list[str] = []
    cont: dict | None = None
    while True:
        params = {
            "action": "query",
            "list": "categorymembers",
            "cmtitle": f"Kategori:{category}",
            "cmlimit": "500",
            "cmtype": "page",
        }
        if cont:
            params.update(cont)
        data = _api_get(client, params)
        for m in data.get("query", {}).get("categorymembers", []):
            titles.append(m["title"])
        if "continue" in data:
            cont = data["continue"]
        else:
            break
    return titles


def fetch_wikitext(client: httpx.Client, title: str) -> str:
    data = _api_get(
        client,
        {
            "action": "parse",
            "page": title,
            "prop": "wikitext",
            "redirects": "1",
        },
    )
    parse = data.get("parse")
    if not parse:
        raise ValueError(f"Page not found or empty: {title}")
    return parse["wikitext"]


# ---------------------------------------------------------------------------
# Wikitext → plain text conversion (minimal MediaWiki parser).
# ---------------------------------------------------------------------------


# Match {{template|key=value|...}} including nested templates.
_TEMPLATE_RX = re.compile(r"\{\{([^{}]+?)\}\}", re.DOTALL)
_REF_RX = re.compile(r"<ref(?:\s[^>]*)?>.*?</ref>", re.DOTALL | re.IGNORECASE)
_REF_SELFCLOSE_RX = re.compile(r"<ref[^/]*?/>", re.IGNORECASE)
_HTML_TAG_RX = re.compile(r"<[^>]+>")
_FILE_LINK_RX = re.compile(r"\[\[(?:Dosya|File|Image):.*?\]\]", re.DOTALL | re.IGNORECASE)
_WIKILINK_RX = re.compile(r"\[\[([^\[\]|]+)(?:\|([^\[\]]+))?\]\]")
_EXTLINK_RX = re.compile(r"\[(https?://[^\s\]]+)(?:\s+([^\]]+))?\]")
_BOLD_RX = re.compile(r"'''(.*?)'''", re.DOTALL)
_ITALIC_RX = re.compile(r"''(.*?)''", re.DOTALL)
_COMMENT_RX = re.compile(r"<!--.*?-->", re.DOTALL)
_CATEGORY_RX = re.compile(r"\[\[Kategori:[^\]]+\]\]", re.IGNORECASE)


def _extract_template_fields(wikitext: str, template: str) -> dict[str, str] | None:
    """Return the first occurrence of ``{{template|key=value|...}}`` as a dict.

    Only handles a single level of nesting (sufficient for Wikisource's
    ``{{eser}}`` infobox).
    """
    pattern = re.compile(r"\{\{\s*" + re.escape(template) + r"\s*\|(.*?)\}\}", re.DOTALL | re.IGNORECASE)
    m = pattern.search(wikitext)
    if not m:
        return None
    body = m.group(1)
    # Split on pipes that are not inside nested templates or wikilinks.
    parts: list[str] = []
    buf: list[str] = []
    depth_t = 0
    depth_l = 0
    for ch in body:
        if ch == "{" and buf and buf[-1] == "{":
            depth_t += 1
        elif ch == "}" and buf and buf[-1] == "}":
            depth_t = max(0, depth_t - 1)
        elif ch == "[" and buf and buf[-1] == "[":
            depth_l += 1
        elif ch == "]" and buf and buf[-1] == "]":
            depth_l = max(0, depth_l - 1)
        if ch == "|" and depth_t == 0 and depth_l == 0:
            parts.append("".join(buf))
            buf = []
            continue
        buf.append(ch)
    parts.append("".join(buf))

    out: dict[str, str] = {}
    for p in parts:
        if "=" in p:
            k, v = p.split("=", 1)
            out[k.strip().lower()] = v.strip()
    return out


def _strip_wikitext(text: str) -> str:
    """Convert wikitext to plain Unicode text suitable for FTS indexing."""
    text = _COMMENT_RX.sub("", text)
    text = _CATEGORY_RX.sub("", text)
    text = _FILE_LINK_RX.sub("", text)
    text = _REF_RX.sub("", text)
    text = _REF_SELFCLOSE_RX.sub("", text)

    # Drop infobox-like templates entirely; we only want the body prose.
    text = re.sub(
        r"\{\{\s*(eser|Vikipedi|sayfa|işaret|kişi|hakkında|fihrist)[^{}]*\}\}",
        "",
        text,
        flags=re.IGNORECASE | re.DOTALL,
    )
    # Repeatedly strip simple templates {{...}}.
    while True:
        new = _TEMPLATE_RX.sub("", text)
        if new == text:
            break
        text = new

    # Wikilinks → display text.
    text = _WIKILINK_RX.sub(lambda m: m.group(2) or m.group(1), text)
    text = _EXTLINK_RX.sub(lambda m: m.group(2) or m.group(1), text)
    # Bold / italics.
    text = _BOLD_RX.sub(r"\1", text)
    text = _ITALIC_RX.sub(r"\1", text)
    # Strip remaining HTML.
    text = _HTML_TAG_RX.sub("", text)
    # Section headings ``== Title ==`` → leading marker on its own line.
    text = re.sub(r"^\s*={2,}\s*(.+?)\s*={2,}\s*$", r"\n\n\1\n", text, flags=re.MULTILINE)
    # Bullet list markers.
    text = re.sub(r"^\s*[*#:;]+\s*", "", text, flags=re.MULTILINE)
    # Collapse whitespace.
    text = re.sub(r"\n[ \t]+", "\n", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = re.sub(r"[ \t]{2,}", " ", text)
    return unicodedata.normalize("NFC", text).strip()


# ---------------------------------------------------------------------------
# Metadata extraction
# ---------------------------------------------------------------------------


_TR_MONTHS = {
    "ocak": 1, "şubat": 2, "mart": 3, "nisan": 4, "mayıs": 5, "haziran": 6,
    "temmuz": 7, "ağustos": 8, "eylül": 9, "ekim": 10, "kasım": 11, "aralık": 12,
}
_DATE_RX = re.compile(
    r"\b(\d{1,2})\s+("
    + "|".join(_TR_MONTHS)
    + r")\s+(\d{4})\b",
    re.IGNORECASE,
)


def _parse_date(text: str) -> tuple[str | None, int | None]:
    if not text:
        return None, None
    m = _DATE_RX.search(text)
    if not m:
        # Try just a year.
        ym = re.search(r"\b(19\d{2}|18\d{2})\b", text)
        if ym:
            return None, int(ym.group(1))
        return None, None
    day = int(m.group(1))
    month = _TR_MONTHS[m.group(2).lower()]
    year = int(m.group(3))
    if not (1 <= day <= 31) or year < 1850 or year > 2000:
        return None, year if 1850 <= year <= 2000 else None
    return f"{year:04d}-{month:02d}-{day:02d}", year


_LOCATION_HINTS = [
    "Konya", "Kastamonu", "İnebolu", "İzmir", "İstanbul", "Ankara", "Bursa",
    "Balıkesir", "Manisa", "Akhisar", "Eskişehir", "Afyonkarahisar", "Sivas",
    "Erzurum", "Samsun", "Trabzon", "Adana", "Mersin", "Çankaya", "Dolmabahçe",
    "TBMM", "Kemalpaşa", "Daday", "Diyarbakır", "Kayseri", "Tokat", "Niğde",
    "Mardin", "Antalya", "Gaziantep", "Edirne", "Çankırı", "Zağnos Paşa Camii",
]


def _guess_location(*texts: str) -> str | None:
    for blob in texts:
        if not blob:
            continue
        for name in _LOCATION_HINTS:
            if name in blob:
                return name
    return None


def _guess_kind(title: str, category: str) -> str:
    t = title.lower()
    if "telgraf" in t or category == "Mustafa Kemal Atatürk'ün telgrafları":
        return "telgraf"
    if "beyanname" in t or "bildiri" in t:
        return "beyanname"
    if "mektup" in t:
        return "mektup"
    if "demeç" in t or "demec" in t:
        return "demec"
    return "konusma"


def _slugify(title: str) -> str:
    # NFD + strip combining marks, ASCII-only-ish slug.
    s = unicodedata.normalize("NFKD", title)
    s = "".join(c for c in s if not unicodedata.combining(c))
    repl = {"ç": "c", "Ç": "c", "ğ": "g", "Ğ": "g", "ı": "i", "İ": "i",
            "ö": "o", "Ö": "o", "ş": "s", "Ş": "s", "ü": "u", "Ü": "u",
            "'": "", "’": ""}
    for k, v in repl.items():
        s = s.replace(k, v)
    s = s.lower()
    s = re.sub(r"[^a-z0-9]+", "-", s)
    s = re.sub(r"-+", "-", s).strip("-")
    return s[:80]


# ---------------------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------------------


def process_page(title: str, wikitext: str, category: str) -> WikiSpeech:
    fields = _extract_template_fields(wikitext, "eser") or {}
    display_title = (fields.get("başlık") or fields.get("baslik") or title).strip()
    notes = fields.get("notlar") or fields.get("notes") or ""
    date_iso, year = _parse_date(notes) if notes else (None, None)
    if not year:
        date_iso, year = _parse_date(display_title)
    body = _strip_wikitext(wikitext)
    location = _guess_location(display_title, notes)
    return WikiSpeech(
        slug=_slugify(title),
        title_tr=display_title,
        url="https://tr.wikisource.org/wiki/" + title.replace(" ", "_"),
        year=year,
        date_iso=date_iso,
        date_raw=notes or None,
        location=location,
        kind=_guess_kind(display_title, category),
        body=body,
        notes=notes or None,
    )


def cache_path_for(title: str) -> Path:
    safe = re.sub(r"[^\w\-\.]+", "_", title)
    return PAGES_DIR / f"{safe}.wikitext"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--force", action="store_true", help="Bypass page cache.")
    parser.add_argument("--limit", type=int, help="Limit number of pages (debug).")
    parser.add_argument(
        "--out", type=Path, default=OUTPUT_JSON, help="Output JSON path."
    )
    args = parser.parse_args(argv)

    console = Console()
    PAGES_DIR.mkdir(parents=True, exist_ok=True)

    with httpx.Client(headers={"User-Agent": USER_AGENT}, timeout=30.0) as client:
        all_titles: list[tuple[str, str]] = []  # (title, category)
        for cat in CATEGORIES:
            console.print(f"[cyan]Listing[/cyan] {cat}")
            for t in category_members(client, cat):
                all_titles.append((t, cat))

        # Deduplicate, preserving first category.
        seen: set[str] = set()
        unique: list[tuple[str, str]] = []
        for t, c in all_titles:
            if t in seen:
                continue
            seen.add(t)
            unique.append((t, c))
        if args.limit:
            unique = unique[: args.limit]
        console.print(f"  → {len(unique)} unique pages")

        speeches: list[WikiSpeech] = []
        for title, category in track(unique, description="Fetching pages"):
            cp = cache_path_for(title)
            if cp.exists() and not args.force:
                wikitext = cp.read_text(encoding="utf-8")
            else:
                try:
                    wikitext = fetch_wikitext(client, title)
                    cp.write_text(wikitext, encoding="utf-8")
                    time.sleep(0.2)  # be polite
                except (httpx.HTTPError, ValueError) as exc:
                    console.print(f"[yellow]Skipping[/yellow] {title}: {exc}")
                    continue
            try:
                speeches.append(process_page(title, wikitext, category))
            except Exception as exc:
                console.print(f"[red]Parse error[/red] {title}: {exc}")

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(
        json.dumps([asdict(s) for s in speeches], ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    console.print(
        f"[bold green]Wrote[/bold green] {len(speeches)} entries → "
        f"{args.out.relative_to(REPO_ROOT)}"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
