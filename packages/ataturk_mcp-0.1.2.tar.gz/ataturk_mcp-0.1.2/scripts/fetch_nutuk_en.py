"""Download and chapter-split the English translation of Nutuk.

Source: ``archive.org/details/361505859-a-speech-delivered-by-mustafa-kemal-ataturk-1927-aka-nutuk-in-english-aka-the-great-speech``.
We fetch the lightweight DjVu plain-text rendering (~1.8 MB) rather than the
60 MB image PDF — this is the raw OCR but is exactly what an LLM needs.

Nutuk is structured into 20 chapters in the original. The Internet Archive
DjVu text does not preserve clean chapter markers (the OCR garbled them), so we
post-process pragmatically:

1. Heavy OCR cleanup (remove stray single characters, collapse whitespace,
   strip page numbers and headers/footers).
2. Drop the front matter (publisher introduction) by seeking to the first
   substantial paragraph that mentions "Samsun" (the canonical opening of the
   speech: *"I landed at Samsun on the 19 of May 1919"*).
3. Split the cleaned body into the **20 canonical Nutuk chapters** using the
   character-share each chapter occupies in the Turkish source as the
   relative weight. Chapter titles come from the published Wikisource ToC and
   are hand-translated for English.

The output is ``data/raw/nutuk/nutuk_en_chapters.json`` which
``scripts/build_db.py`` loads into the ``nutuk_chapters`` table.

Usage::

    python scripts/fetch_nutuk_en.py
    python scripts/fetch_nutuk_en.py --force
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import unicodedata
from dataclasses import asdict, dataclass
from pathlib import Path

import httpx
from rich.console import Console
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    TextColumn,
    TransferSpeedColumn,
)

REPO_ROOT = Path(__file__).resolve().parents[1]
RAW_DIR = REPO_ROOT / "data" / "raw" / "nutuk"
OCR_PATH = RAW_DIR / "nutuk_en.txt"
OUT_PATH = RAW_DIR / "nutuk_en_chapters.json"

IA_IDENTIFIER = (
    "361505859-a-speech-delivered-by-mustafa-kemal-ataturk-1927-"
    "aka-nutuk-in-english-aka-the-great-speech"
)
IA_FILE = (
    "361505859-A-Speech-Delivered-by-Mustafa-Kemal-Ataturk-1927-"
    "Aka-Nutuk-in-English-Aka-the-Great-Speech_djvu.txt"
)
DJVU_URL = f"https://archive.org/download/{IA_IDENTIFIER}/{IA_FILE}"

USER_AGENT = "ataturk-mcp/0.1 (academic corpus builder)"


# ---------------------------------------------------------------------------
# Canonical 20-chapter structure (titles taken from the Wikisource Turkish ToC
# and hand-translated for English). Weights approximate each chapter's share
# of the original text length and are used to split the OCR.
# ---------------------------------------------------------------------------


@dataclass
class _Chapter:
    number: int
    roman: str
    title_tr: str
    title_en: str
    weight: float  # relative share of the text length


NUTUK_CHAPTERS: tuple[_Chapter, ...] = (
    _Chapter(1, "I", "Harb-i Umumî'de Anadolu'nun durumu ve halâs çareleri",
             "The situation in Anatolia during WWI and paths to liberation", 0.06),
    _Chapter(2, "II", "Millî teşkilatların vücuda getirilmesi ve kongreler",
             "Forming the national organisations and the congresses", 0.06),
    _Chapter(3, "III", "İstanbul Hükûmeti ile münasebetler",
             "Relations with the Istanbul Government", 0.05),
    _Chapter(4, "IV", "Teşkilât-ı milliyenin yeniden tanzimi",
             "Reorganisation of the national movement", 0.05),
    _Chapter(5, "V", "Misak-ı Millî ve gelişmeler",
             "The National Pact and subsequent developments", 0.04),
    _Chapter(6, "VI", "Türkiye Büyük Millet Meclisinin toplanması",
             "Convening of the Grand National Assembly of Turkey", 0.04),
    _Chapter(7, "VII", "Dahilî isyanlar ve Şark Cephesi'ndeki gelişmeler",
             "Internal revolts and developments on the Eastern Front", 0.05),
    _Chapter(8, "VIII", "Muntazam ordu vücuda getirmek kararı",
             "Decision to form a regular army", 0.04),
    _Chapter(9, "IX", "İstanbul Hükûmeti'nin Ankara ile temas arayışları",
             "Istanbul Government's overtures to Ankara", 0.04),
    _Chapter(10, "X", "Garp Cephesi'ndeki gelişmeler ve Birinci İnönü Zaferi",
             "Western Front developments and the First İnönü victory", 0.05),
    _Chapter(11, "XI", "Londra Konferansı ve İkinci İnönü Zaferi",
             "London Conference and the Second İnönü victory", 0.04),
    _Chapter(12, "XII", "Sakarya Meydan Muharebesi ve müteakip gelişmeler",
             "Battle of Sakarya and subsequent developments", 0.05),
    _Chapter(13, "XIII", "Büyük Taarruz ve Başkumandan Muharebesi, Mudanya",
             "Great Offensive, Battle of the Commander-in-Chief, Mudanya", 0.04),
    _Chapter(14, "XIV", "Lozan Konferansı ve saltanatın lağvı, hilâfet meselesi",
             "Lausanne Conference, abolition of the sultanate, the caliphate question", 0.05),
    _Chapter(15, "XV", "Halk Fırkasını teşkil teşebbüsleri, Lozan Muâhedesi",
             "Founding of the People's Party, Treaty of Lausanne", 0.04),
    _Chapter(16, "XVI", "Cumhuriyetin ilânı",
             "Proclamation of the Republic", 0.04),
    _Chapter(17, "XVII", "Hilâfetin lağvı",
             "Abolition of the caliphate", 0.04),
    _Chapter(18, "XVIII", "Cumhuriyete karşı dahili muhâlefet",
             "Internal opposition to the Republic; the pashas' struggle and the PRP", 0.05),
    _Chapter(19, "XIX", "Türk gençliğine bıraktığım emanet",
             "The trust I leave to Turkish youth", 0.01),
    _Chapter(20, "XX", "Vesikalar",
             "Documents (appendices)", 0.16),
)


# ---------------------------------------------------------------------------
# Download
# ---------------------------------------------------------------------------


def download_djvu(dest: Path, force: bool, console: Console) -> Path:
    if dest.exists() and not force:
        console.print(
            f"[green]Cached[/green] {dest.relative_to(REPO_ROOT)} "
            f"({dest.stat().st_size / 1_048_576:.1f} MiB) — skipping download."
        )
        return dest
    dest.parent.mkdir(parents=True, exist_ok=True)
    with (
        httpx.stream(
            "GET", DJVU_URL, headers={"User-Agent": USER_AGENT},
            follow_redirects=True, timeout=120.0,
        ) as r,
        Progress(
            TextColumn("Nutuk EN OCR " + "{task.description}"),
            BarColumn(),
            DownloadColumn(),
            TransferSpeedColumn(),
            console=console,
        ) as progress,
        dest.open("wb") as fh,
    ):
        r.raise_for_status()
        total = int(r.headers.get("content-length", 0)) or None
        task = progress.add_task("downloading", total=total)
        for chunk in r.iter_bytes(chunk_size=128 * 1024):
            fh.write(chunk)
            progress.update(task, advance=len(chunk))
    console.print(f"[green]Saved[/green] {dest.relative_to(REPO_ROOT)} "
                  f"({dest.stat().st_size / 1_048_576:.1f} MiB)")
    return dest


# ---------------------------------------------------------------------------
# Cleanup
# ---------------------------------------------------------------------------


# A line that is "junk" — short OCR fragments, page numbers, etc.
_JUNK_LINE_RX = re.compile(r"^[\s\W_]*$|^[A-Za-z]{1,2}$|^[\d]{1,3}\s*$")
_PAGE_NO_RX = re.compile(r"^\s*[ivxlcdmIVXLCDM\d]{1,5}\s*$")


def clean_ocr(text: str) -> str:
    text = unicodedata.normalize("NFC", text)
    # Common OCR artefacts.
    text = text.replace("\u00ad", "")  # soft hyphen
    text = re.sub(r"[“”„]", '"', text)
    text = re.sub(r"[‘’`]", "'", text)
    text = text.replace("|", "I")
    # Drop lines that are pure punctuation / single chars / pure numbers.
    kept: list[str] = []
    for line in text.splitlines():
        s = line.strip()
        if not s:
            kept.append("")
            continue
        if _JUNK_LINE_RX.match(s):
            continue
        if _PAGE_NO_RX.match(s):
            continue
        kept.append(s)
    text = "\n".join(kept)
    # Merge hyphenated line breaks (``correspon- \n dence``).
    text = re.sub(r"-\s*\n\s*(?=[a-z])", "", text)
    # Collapse runs of blank lines.
    text = re.sub(r"\n{3,}", "\n\n", text)
    # Collapse internal whitespace.
    text = re.sub(r"[ \t]{2,}", " ", text)
    return text.strip()


# Anchor to the start of the speech proper. The English translation opens with
# variations of "I landed at Samsun on 19 May 1919". OCR often mangles this.
_SPEECH_START_PATTERNS = (
    re.compile(r"landed\s+at\s+Samsun", re.IGNORECASE),
    re.compile(r"19[\s.,]+May[\s.,]+1919", re.IGNORECASE),
    re.compile(r"general\s+situation.*on\s+the\s+day", re.IGNORECASE),
)


def trim_front_matter(text: str) -> str:
    best = None
    for rx in _SPEECH_START_PATTERNS:
        m = rx.search(text)
        if m and (best is None or m.start() < best):
            best = m.start()
    if best is None:
        return text
    # Back up to the paragraph boundary preceding the match.
    para_start = text.rfind("\n\n", 0, best)
    return text[para_start + 2 if para_start != -1 else best :]


# ---------------------------------------------------------------------------
# Chapter splitting
# ---------------------------------------------------------------------------


def split_into_chapters(text: str) -> list[tuple[_Chapter, str]]:
    total = len(text)
    weights = [c.weight for c in NUTUK_CHAPTERS]
    wsum = sum(weights)
    norm = [w / wsum for w in weights]

    # Cumulative target positions in the text.
    targets: list[int] = []
    acc = 0.0
    for w in norm[:-1]:
        acc += w
        targets.append(int(acc * total))
    # Snap each target to the nearest paragraph boundary.
    boundaries = [0]
    for t in targets:
        # Look forward up to 4 KB for "\n\n", else backward.
        fwd = text.find("\n\n", t, t + 4096)
        bwd = text.rfind("\n\n", max(0, t - 4096), t)
        if fwd == -1:
            chosen = bwd if bwd != -1 else t
        elif bwd == -1:
            chosen = fwd
        else:
            chosen = fwd if abs(fwd - t) <= abs(bwd - t) else bwd
        boundaries.append(chosen)
    boundaries.append(total)

    out: list[tuple[_Chapter, str]] = []
    for ch, lo, hi in zip(NUTUK_CHAPTERS, boundaries[:-1], boundaries[1:], strict=True):
        body = text[lo:hi].strip()
        out.append((ch, body))
    return out


# ---------------------------------------------------------------------------
# Output assembly
# ---------------------------------------------------------------------------


@dataclass
class ChapterRecord:
    chapter: str
    lang: str
    title: str
    body: str


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--force", action="store_true", help="Re-download OCR.")
    parser.add_argument("--out", type=Path, default=OUT_PATH)
    args = parser.parse_args(argv)

    console = Console()
    raw = download_djvu(OCR_PATH, args.force, console)
    text = raw.read_text(encoding="utf-8", errors="replace")
    console.print(f"  raw  : {len(text):>10,} chars")
    text = clean_ocr(text)
    console.print(f"  clean: {len(text):>10,} chars")
    text = trim_front_matter(text)
    console.print(f"  body : {len(text):>10,} chars (front matter trimmed)")

    records: list[ChapterRecord] = []
    for ch, body in split_into_chapters(text):
        title = f"{ch.roman}. {ch.title_en}"
        records.append(
            ChapterRecord(chapter=str(ch.number), lang="en", title=title, body=body)
        )
        console.print(f"  Ch {ch.number:>2}  {len(body):>8,} chars  {title[:60]}")

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(
        json.dumps([asdict(r) for r in records], ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    console.print(
        f"\n[bold green]Wrote[/bold green] {len(records)} chapters → "
        f"{args.out.relative_to(REPO_ROOT)}"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
