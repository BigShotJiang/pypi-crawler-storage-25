"""SQLite access layer used by both the MCP server and the build scripts.

The same module is imported by:
- The MCP server (read-only, via :func:`connect_readonly`).
- The ETL/build scripts (read-write, via :func:`connect_rw` and :func:`init_schema`).
"""

from __future__ import annotations

import os
import re
import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from importlib import resources
from pathlib import Path

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS speeches (
    id          TEXT PRIMARY KEY,
    year        INTEGER,
    date        TEXT,            -- ISO YYYY-MM-DD if known
    title_tr    TEXT NOT NULL,
    title_en    TEXT,
    location    TEXT,
    kind        TEXT NOT NULL DEFAULT 'konusma',
    source      TEXT NOT NULL,   -- e.g. 'atam_cilt_3'
    source_ref  TEXT             -- page number / chapter / URL
);

CREATE INDEX IF NOT EXISTS idx_speeches_year ON speeches(year);
CREATE INDEX IF NOT EXISTS idx_speeches_kind ON speeches(kind);
CREATE INDEX IF NOT EXISTS idx_speeches_source ON speeches(source);

CREATE TABLE IF NOT EXISTS speech_texts (
    speech_id   TEXT NOT NULL,
    lang        TEXT NOT NULL CHECK(lang IN ('tr','en')),
    body        TEXT NOT NULL,
    PRIMARY KEY (speech_id, lang),
    FOREIGN KEY (speech_id) REFERENCES speeches(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS topics (
    id          INTEGER PRIMARY KEY,
    name_tr     TEXT NOT NULL UNIQUE,
    name_en     TEXT
);

CREATE TABLE IF NOT EXISTS speech_topics (
    speech_id   TEXT NOT NULL,
    topic_id    INTEGER NOT NULL,
    PRIMARY KEY (speech_id, topic_id),
    FOREIGN KEY (speech_id) REFERENCES speeches(id) ON DELETE CASCADE,
    FOREIGN KEY (topic_id) REFERENCES topics(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS nutuk_chapters (
    id          TEXT PRIMARY KEY,   -- 'nutuk-en-ch-01'
    chapter     TEXT NOT NULL,      -- '1', '1.2', etc.
    lang        TEXT NOT NULL CHECK(lang IN ('tr','en')),
    title       TEXT,
    body        TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_nutuk_lang ON nutuk_chapters(lang);

-- FTS5 virtual table over speeches. We use unicode61 with diacritics removal
-- (Turkish-friendly). Application code further normalises I/İ before querying.
CREATE VIRTUAL TABLE IF NOT EXISTS speeches_fts USING fts5(
    title,
    body,
    speech_id UNINDEXED,
    lang UNINDEXED,
    tokenize = "unicode61 remove_diacritics 2"
);

CREATE VIRTUAL TABLE IF NOT EXISTS nutuk_fts USING fts5(
    title,
    body,
    chapter_id UNINDEXED,
    lang UNINDEXED,
    tokenize = "unicode61 remove_diacritics 2"
);
"""


DEFAULT_DB_FILENAME = "speeches.db"


def normalise_query(text: str) -> str:
    """Normalise a Turkish query so it plays nicely with FTS5 unicode61.

    - Lower-cases using Turkish rules (İ→i, I→ı).
    - Collapses whitespace.
    - Leaves FTS5 operators (AND/OR/NOT, quotes, *) alone.
    """
    if not text:
        return ""
    text = text.replace("İ", "i").replace("I", "ı")
    text = text.lower()
    text = re.sub(r"\s+", " ", text).strip()
    return text


def default_db_path() -> Path:
    """Locate the bundled `speeches.db` at runtime.

    Lookup order:
    1. ``ATATURK_MCP_DB`` environment variable (explicit override).
    2. Packaged data file inside ``ataturk_mcp/data/speeches.db``.
    3. Repository-relative ``data/speeches.db`` (when running from source).
    """
    env = os.environ.get("ATATURK_MCP_DB")
    if env:
        return Path(env).expanduser().resolve()

    try:
        packaged = resources.files("ataturk_mcp").joinpath("data", DEFAULT_DB_FILENAME)
        if packaged.is_file():
            return Path(str(packaged))
    except (ModuleNotFoundError, FileNotFoundError):
        pass

    repo_root = Path(__file__).resolve().parents[2]
    return repo_root / "data" / DEFAULT_DB_FILENAME


def connect_readonly(db_path: Path | None = None) -> sqlite3.Connection:
    """Open the bundled database in read-only mode (used by the MCP server)."""
    path = db_path or default_db_path()
    if not path.exists():
        raise FileNotFoundError(
            f"speeches.db not found at {path}. Run `python scripts/build_db.py` "
            "or set ATATURK_MCP_DB to point at an existing database."
        )
    uri = f"file:{path}?mode=ro"
    conn = sqlite3.connect(uri, uri=True, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def connect_rw(db_path: Path) -> sqlite3.Connection:
    """Open (and create if missing) a writable database for ETL scripts."""
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("PRAGMA journal_mode = WAL;")
    return conn


def init_schema(conn: sqlite3.Connection) -> None:
    """Apply the schema and any required triggers/indexes."""
    conn.executescript(SCHEMA_SQL)
    conn.commit()


def reset_fts(conn: sqlite3.Connection) -> None:
    """Rebuild FTS5 indexes from the underlying tables."""
    conn.executescript(
        """
        DELETE FROM speeches_fts;
        INSERT INTO speeches_fts (title, body, speech_id, lang)
        SELECT s.title_tr, t.body, s.id, t.lang
        FROM speeches s JOIN speech_texts t ON t.speech_id = s.id;

        DELETE FROM nutuk_fts;
        INSERT INTO nutuk_fts (title, body, chapter_id, lang)
        SELECT COALESCE(title, ''), body, id, lang FROM nutuk_chapters;
        """
    )
    conn.commit()


@contextmanager
def transaction(conn: sqlite3.Connection) -> Iterator[sqlite3.Connection]:
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
