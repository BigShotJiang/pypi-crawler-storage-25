"""FastMCP server exposing Atatürk's complete speech corpus.

Run via stdio (the standard MCP transport)::

    ataturk-mcp                          # console script
    fastmcp run src/ataturk_mcp/server.py:mcp
    python -m ataturk_mcp.server

The database location can be overridden with ``ATATURK_MCP_DB``.
"""

from __future__ import annotations

import sqlite3
from typing import Annotated, Literal

from fastmcp import FastMCP
from pydantic import Field

from .db import connect_readonly, normalise_query
from .models import (
    Citation,
    CorpusStats,
    Lang,
    NutukChapter,
    Speech,
    SpeechHit,
    SpeechKind,
    SpeechMeta,
    Topic,
)

# ---------------------------------------------------------------------------
# Server setup
# ---------------------------------------------------------------------------


mcp = FastMCP(
    name="Atatürk Speeches",
    instructions=(
        "This server exposes the complete corpus of Mustafa Kemal Atatürk's "
        "speeches, statements, telegrams, proclamations (1906-1938) sourced from "
        "the Atatürk Araştırma Merkezi (ATAM) edition and Turkish Wikisource, "
        "plus the 1927 Nutuk in English. Use `search_speeches` for full-text "
        "search across the Turkish corpus, `get_speech` for the full text of a "
        "specific speech, `nutuk_search`/`nutuk_chapter` for Nutuk, and `cite` "
        "to produce academic citations.\n\n"
        "Created by Buğra Ayan — https://bugraayan.com"
    ),
)


_CONN: sqlite3.Connection | None = None


def _conn() -> sqlite3.Connection:
    """Lazily open the SQLite connection on first use."""
    global _CONN
    if _CONN is None:
        _CONN = connect_readonly()
    return _CONN


# ---------------------------------------------------------------------------
# Internal row → model helpers
# ---------------------------------------------------------------------------


def _row_to_meta(row: sqlite3.Row) -> SpeechMeta:
    return SpeechMeta(
        id=row["id"],
        year=row["year"],
        date=row["date"],
        title_tr=row["title_tr"],
        title_en=row["title_en"],
        location=row["location"],
        kind=row["kind"],
        source=row["source"],
        source_ref=row["source_ref"],
    )


def _row_to_speech(meta_row: sqlite3.Row, text_row: sqlite3.Row) -> Speech:
    return Speech(
        **_row_to_meta(meta_row).model_dump(),
        lang=text_row["lang"],
        body=text_row["body"],
    )


def _escape_fts(query: str) -> str:
    """Make a user query safe for FTS5 MATCH.

    Treats it as a phrase if it contains spaces but no FTS operators, otherwise
    passes through (so power users can use AND/OR/NEAR/quoted phrases).
    """
    q = query.strip()
    if not q:
        return q
    if any(op in q for op in ('"', " AND ", " OR ", " NEAR", " NOT ", "*", "(")):
        return q
    # Single token or unquoted multi-word: split into tokens with AND.
    tokens = [t for t in q.split() if t]
    return " AND ".join(tokens)


# ---------------------------------------------------------------------------
# Tools — search & retrieval
# ---------------------------------------------------------------------------


@mcp.tool(
    description=(
        "Full-text search over Atatürk's speeches, statements, telegrams and "
        "proclamations (1906-1938). Returns ranked hits with a context snippet. "
        "Supports Turkish queries (the FTS index is diacritic-folded), and "
        "FTS5 operators (AND, OR, NOT, NEAR, quoted phrases, prefix*)."
    ),
)
def search_speeches(
    query: Annotated[str, Field(description="Search query (Turkish; English where available).")],
    lang: Annotated[Literal["tr", "en", "both"], Field(description="Language to search in.")] = "tr",
    year_from: Annotated[int | None, Field(ge=1900, le=1940, description="Earliest year (inclusive).")] = None,
    year_to: Annotated[int | None, Field(ge=1900, le=1940, description="Latest year (inclusive).")] = None,
    kind: Annotated[SpeechKind | None, Field(description="Filter by utterance type.")] = None,
    limit: Annotated[int, Field(ge=1, le=50, description="Max results.")] = 10,
) -> list[SpeechHit]:
    q = _escape_fts(normalise_query(query))
    if not q:
        return []
    conn = _conn()

    lang_clause = ""
    params: list = [q]
    if lang in ("tr", "en"):
        lang_clause = "AND speeches_fts.lang = ?"
        params.append(lang)

    extra_where = ""
    if year_from is not None:
        extra_where += " AND s.year >= ?"
        params.append(year_from)
    if year_to is not None:
        extra_where += " AND s.year <= ?"
        params.append(year_to)
    if kind:
        extra_where += " AND s.kind = ?"
        params.append(kind)
    params.append(limit)

    sql = f"""
        SELECT
            s.id, s.year, s.date, s.title_tr, s.title_en, s.location, s.kind,
            s.source, s.source_ref, speeches_fts.lang AS lang,
            snippet(speeches_fts, 1, '[', ']', '...', 16) AS snip,
            bm25(speeches_fts) AS rank
        FROM speeches_fts
        JOIN speeches s ON s.id = speeches_fts.speech_id
        WHERE speeches_fts MATCH ? {lang_clause} {extra_where}
        ORDER BY rank
        LIMIT ?
    """
    rows = conn.execute(sql, params).fetchall()
    hits: list[SpeechHit] = []
    for r in rows:
        meta = _row_to_meta(r)
        hits.append(
            SpeechHit(
                **meta.model_dump(),
                lang=r["lang"],
                snippet=r["snip"] or "",
                rank=float(r["rank"]),
            )
        )
    return hits


@mcp.tool(
    description=(
        "Return one full speech by its ID (as found in `search_speeches` or "
        "`list_speeches`). If the requested language is not available, falls "
        "back to Turkish."
    ),
)
def get_speech(
    speech_id: Annotated[str, Field(description="Speech identifier, e.g. 'atam-c3-1925-001'.")],
    lang: Annotated[Lang, Field(description="Preferred language.")] = "tr",
) -> Speech:
    conn = _conn()
    meta_row = conn.execute("SELECT * FROM speeches WHERE id = ?", (speech_id,)).fetchone()
    if meta_row is None:
        raise ValueError(f"Speech not found: {speech_id}")
    text_row = conn.execute(
        "SELECT lang, body FROM speech_texts WHERE speech_id = ? AND lang = ?",
        (speech_id, lang),
    ).fetchone()
    if text_row is None:
        text_row = conn.execute(
            "SELECT lang, body FROM speech_texts WHERE speech_id = ? ORDER BY lang LIMIT 1",
            (speech_id,),
        ).fetchone()
    if text_row is None:
        raise ValueError(f"No body text stored for {speech_id}")
    return _row_to_speech(meta_row, text_row)


@mcp.tool(
    description=(
        "List speeches with optional filters, ordered chronologically. Returns "
        "metadata only (no body); use `get_speech` to fetch the full text."
    ),
)
def list_speeches(
    year: Annotated[int | None, Field(ge=1900, le=1940, description="Restrict to a single year.")] = None,
    year_from: Annotated[int | None, Field(ge=1900, le=1940)] = None,
    year_to: Annotated[int | None, Field(ge=1900, le=1940)] = None,
    kind: Annotated[SpeechKind | None, Field(description="Filter by type.")] = None,
    source: Annotated[str | None, Field(description="Filter by source key, e.g. 'atam_cilt_3'.")] = None,
    limit: Annotated[int, Field(ge=1, le=500)] = 50,
    offset: Annotated[int, Field(ge=0)] = 0,
) -> list[SpeechMeta]:
    conn = _conn()
    clauses: list[str] = []
    params: list = []
    if year is not None:
        clauses.append("year = ?")
        params.append(year)
    if year_from is not None:
        clauses.append("year >= ?")
        params.append(year_from)
    if year_to is not None:
        clauses.append("year <= ?")
        params.append(year_to)
    if kind:
        clauses.append("kind = ?")
        params.append(kind)
    if source:
        clauses.append("source = ?")
        params.append(source)
    where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
    params.extend([limit, offset])
    sql = f"""
        SELECT id, year, date, title_tr, title_en, location, kind, source, source_ref
        FROM speeches
        {where}
        ORDER BY year NULLS LAST, date NULLS LAST, id
        LIMIT ? OFFSET ?
    """
    return [_row_to_meta(r) for r in conn.execute(sql, params).fetchall()]


@mcp.tool(
    description="Return a random speech — useful for daily-quote agents or browsing.",
)
def random_speech(
    lang: Annotated[Lang, Field(description="Preferred language.")] = "tr",
    kind: Annotated[SpeechKind | None, Field(description="Restrict to a type.")] = None,
) -> Speech:
    conn = _conn()
    clauses = ["EXISTS (SELECT 1 FROM speech_texts t WHERE t.speech_id = s.id AND t.lang = ?)"]
    params: list = [lang]
    if kind:
        clauses.append("s.kind = ?")
        params.append(kind)
    where = " AND ".join(clauses)
    row = conn.execute(
        f"SELECT s.* FROM speeches s WHERE {where} ORDER BY RANDOM() LIMIT 1",
        params,
    ).fetchone()
    if row is None:
        raise ValueError("No speeches available for the given filters.")
    return get_speech(row["id"], lang=lang)


# ---------------------------------------------------------------------------
# Tools — topics
# ---------------------------------------------------------------------------


@mcp.tool(description="List all topics that have been tagged on the corpus, with speech counts.")
def list_topics() -> list[Topic]:
    conn = _conn()
    rows = conn.execute(
        """
        SELECT t.id, t.name_tr, t.name_en, COUNT(st.speech_id) AS n
        FROM topics t
        LEFT JOIN speech_topics st ON st.topic_id = t.id
        GROUP BY t.id
        ORDER BY n DESC, t.name_tr
        """
    ).fetchall()
    return [
        Topic(id=r["id"], name_tr=r["name_tr"], name_en=r["name_en"], speech_count=r["n"])
        for r in rows
    ]


@mcp.tool(description="List speeches tagged with a given topic ID (see `list_topics`).")
def speeches_by_topic(
    topic_id: Annotated[int, Field(description="Topic ID from `list_topics`.")],
    limit: Annotated[int, Field(ge=1, le=200)] = 50,
) -> list[SpeechMeta]:
    conn = _conn()
    rows = conn.execute(
        """
        SELECT s.id, s.year, s.date, s.title_tr, s.title_en, s.location, s.kind, s.source, s.source_ref
        FROM speeches s
        JOIN speech_topics st ON st.speech_id = s.id
        WHERE st.topic_id = ?
        ORDER BY s.year, s.date, s.id
        LIMIT ?
        """,
        (topic_id, limit),
    ).fetchall()
    return [_row_to_meta(r) for r in rows]


# ---------------------------------------------------------------------------
# Tools — Nutuk
# ---------------------------------------------------------------------------


@mcp.tool(
    description=(
        "Full-text search within Nutuk (1927) — Atatürk's six-day speech. "
        "Returns chapter hits with snippets. Use `nutuk_chapter` to fetch the "
        "full text of a chapter."
    ),
)
def nutuk_search(
    query: Annotated[str, Field(description="Search terms.")],
    lang: Annotated[Lang, Field(description="Language to search in.")] = "en",
    limit: Annotated[int, Field(ge=1, le=20)] = 5,
) -> list[dict]:
    q = _escape_fts(normalise_query(query))
    if not q:
        return []
    conn = _conn()
    rows = conn.execute(
        """
        SELECT n.id, n.chapter, n.lang, n.title,
               snippet(nutuk_fts, 1, '[', ']', '...', 20) AS snip,
               bm25(nutuk_fts) AS rank
        FROM nutuk_fts
        JOIN nutuk_chapters n ON n.id = nutuk_fts.chapter_id
        WHERE nutuk_fts MATCH ? AND nutuk_fts.lang = ?
        ORDER BY rank
        LIMIT ?
        """,
        (q, lang, limit),
    ).fetchall()
    return [
        {
            "id": r["id"],
            "chapter": r["chapter"],
            "lang": r["lang"],
            "title": r["title"],
            "snippet": r["snip"] or "",
            "rank": float(r["rank"]),
        }
        for r in rows
    ]


@mcp.tool(
    description=(
        "Return a full Nutuk chapter (1-20). Use `nutuk_search` first to "
        "discover relevant chapters. Available languages: en (English, from "
        "Internet Archive). Turkish chapters can be added by extending the "
        "ETL pipeline."
    ),
)
def nutuk_chapter(
    chapter: Annotated[str, Field(description="Chapter number as a string, e.g. '1', '14', '20'.")],
    lang: Annotated[Lang, Field(description="Language.")] = "en",
) -> NutukChapter:
    conn = _conn()
    row = conn.execute(
        "SELECT chapter, lang, title, body FROM nutuk_chapters WHERE chapter = ? AND lang = ?",
        (chapter, lang),
    ).fetchone()
    if row is None:
        raise ValueError(f"Nutuk chapter not found: chapter={chapter} lang={lang}")
    return NutukChapter(
        chapter=row["chapter"],
        title_tr=row["title"] if row["lang"] == "tr" else "",
        title_en=row["title"] if row["lang"] == "en" else None,
        lang=row["lang"],
        body=row["body"],
    )


# ---------------------------------------------------------------------------
# Tools — citation & stats
# ---------------------------------------------------------------------------


@mcp.tool(description="Produce academic citations (APA, MLA, Chicago) for a given speech.")
def cite(
    speech_id: Annotated[str, Field(description="Speech identifier.")],
) -> Citation:
    conn = _conn()
    row = conn.execute("SELECT * FROM speeches WHERE id = ?", (speech_id,)).fetchone()
    if row is None:
        raise ValueError(f"Speech not found: {speech_id}")
    year = row["year"] or "n.d."
    date = row["date"] or str(year)
    title = row["title_tr"]
    source = row["source_ref"] or row["source"]
    url = None
    if row["source"] == "wikisource":
        url = row["source_ref"]

    retrieved_via = (
        "Retrieved via ataturk-mcp (Ayan, B., https://bugraayan.com)"
    )
    apa = (
        f"Atatürk, M. K. ({year}). {title}. "
        f"{source}. {retrieved_via}."
    )
    mla = (
        f'Atatürk, Mustafa Kemal. "{title}." {date}. {source}. '
        f"{retrieved_via}."
    )
    chicago = (
        f'Atatürk, Mustafa Kemal. "{title}." {date}. {source}. '
        f"{retrieved_via}."
    )
    return Citation(speech_id=speech_id, apa=apa, mla=mla, chicago=chicago, source_url=url)


@mcp.tool(
    description=(
        "About this MCP server — credits, version and authorship "
        "(created by bugraayan.com)."
    ),
)
def about() -> dict:
    from . import __author__, __author_url__, __email__, __license__, __version__

    return {
        "name": "ataturk-mcp",
        "version": __version__,
        "author": __author__,
        "author_url": __author_url__,
        "email": __email__,
        "license": __license__,
        "description": (
            "Atatürk's complete speeches (1906-1938) as an MCP server. "
            "Created by Buğra Ayan — https://bugraayan.com"
        ),
        "sources": [
            "Atatürk Araştırma Merkezi (ATAM) — Söylev ve Demeçleri Cilt I-III, 2024",
            "Vikikaynak (tr.wikisource.org)",
            "Internet Archive — Nutuk (English translation)",
        ],
    }


@mcp.tool(description="Summary statistics about the corpus: counts by year, kind and source.")
def corpus_stats() -> CorpusStats:
    conn = _conn()
    total = conn.execute("SELECT COUNT(*) AS n FROM speeches").fetchone()["n"]
    by_kind = {
        r["kind"]: r["n"]
        for r in conn.execute(
            "SELECT kind, COUNT(*) AS n FROM speeches GROUP BY kind ORDER BY n DESC"
        )
    }
    by_year = {
        int(r["year"]): r["n"]
        for r in conn.execute(
            "SELECT year, COUNT(*) AS n FROM speeches WHERE year IS NOT NULL "
            "GROUP BY year ORDER BY year"
        )
    }
    langs = sorted({r["lang"] for r in conn.execute("SELECT DISTINCT lang FROM speech_texts")})
    nutuk_langs = sorted({r["lang"] for r in conn.execute("SELECT DISTINCT lang FROM nutuk_chapters")})
    sources = sorted({r["source"] for r in conn.execute("SELECT DISTINCT source FROM speeches")})
    return CorpusStats(
        total_speeches=total,
        by_kind=by_kind,
        by_year=by_year,
        languages=sorted(set(langs) | set(nutuk_langs)),  # type: ignore[arg-type]
        sources=sources,
    )


# ---------------------------------------------------------------------------
# Resources — URI-addressable read-only views
# ---------------------------------------------------------------------------


@mcp.resource(
    uri="ataturk://speech/{speech_id}",
    name="Speech (Turkish)",
    description="Full Turkish text of a single speech, addressable by ID.",
    mime_type="text/plain",
)
def resource_speech(speech_id: str) -> str:
    speech = get_speech(speech_id, lang="tr")
    header = (
        f"# {speech.title_tr}\n"
        f"Tarih: {speech.date or speech.year or 'bilinmiyor'}  |  "
        f"Yer: {speech.location or '-'}  |  "
        f"Tür: {speech.kind}\n"
        f"Kaynak: {speech.source_ref or speech.source}\n"
        f"ID: {speech.id}\n\n"
    )
    return header + speech.body


@mcp.resource(
    uri="ataturk://nutuk/{chapter}/{lang}",
    name="Nutuk chapter",
    description="Full text of one Nutuk chapter (lang ∈ {tr, en}).",
    mime_type="text/plain",
)
def resource_nutuk(chapter: str, lang: str) -> str:
    if lang not in ("tr", "en"):
        raise ValueError(f"Unsupported lang: {lang}")
    ch = nutuk_chapter(chapter=chapter, lang=lang)  # type: ignore[arg-type]
    title = ch.title_en or ch.title_tr or f"Bölüm {ch.chapter}"
    return f"# Nutuk — {title}\n\n{ch.body}"


@mcp.resource(
    uri="ataturk://corpus/stats",
    name="Corpus statistics",
    description="Summary statistics about the corpus (counts by year, kind, source).",
    mime_type="application/json",
)
def resource_stats() -> str:
    import json
    return json.dumps(corpus_stats().model_dump(), ensure_ascii=False, indent=2)


# ---------------------------------------------------------------------------
# Prompts — reusable LLM templates
# ---------------------------------------------------------------------------


@mcp.prompt(
    description=(
        "Open-ended scholarly analysis of a single speech: historical context, "
        "rhetorical strategy, key themes, and connections to other speeches in "
        "the corpus."
    ),
)
def analyze_speech(
    speech_id: Annotated[str, Field(description="Speech identifier to analyse.")],
) -> str:
    return (
        f"Please analyse Atatürk's speech with ID `{speech_id}`. First call "
        f"`get_speech` to fetch its full text. Then produce a scholarly "
        f"analysis covering:\n\n"
        f"1. **Historical context** — what was happening in Turkey and the world "
        f"on this date?\n"
        f"2. **Audience & venue** — to whom is Atatürk speaking, and why does it "
        f"matter?\n"
        f"3. **Key themes** — list 3-5 central ideas, with short quotes "
        f"(translate Turkish quotes to English if the user is reading in English).\n"
        f"4. **Rhetorical strategy** — what literary or persuasive devices does "
        f"he employ? How does the choice of vocabulary (Ottoman vs. modern "
        f"Turkish) signal his audience?\n"
        f"5. **Resonance** — call `search_speeches` to find 2-3 related speeches "
        f"and discuss how the ideas develop over time.\n"
        f"6. **Citation** — finish by calling `cite` and quoting the citation."
    )


@mcp.prompt(
    description=(
        "Find and contextualise quotes on a given theme across the corpus."
    ),
)
def find_quote(
    theme: Annotated[str, Field(description="The theme or topic to search for, in Turkish or English.")],
    n_quotes: Annotated[int, Field(ge=1, le=10, description="How many quotes to surface.")] = 5,
) -> str:
    return (
        f"Find {n_quotes} representative quotes from Atatürk on the theme: "
        f"**{theme}**.\n\n"
        f"1. Call `search_speeches` with the theme as the query (try both Turkish "
        f"and English keywords if relevant).\n"
        f"2. For each hit, call `get_speech` to read the surrounding context.\n"
        f"3. Present each quote as:\n"
        f"   - Original (Turkish, preserving Ottoman vocabulary).\n"
        f"   - English paraphrase.\n"
        f"   - Date + venue + speech ID.\n"
        f"   - 1-2 sentences explaining why this quote is significant for the "
        f"theme.\n"
        f"4. End with a short synthesising paragraph: how do these quotes, taken "
        f"together, illustrate Atatürk's thinking on this theme between "
        f"{ {'min': 1906, 'max': 1938}['min'] } and "
        f"{ {'min': 1906, 'max': 1938}['max'] }?"
    )


# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------


def main() -> None:
    """Console-script entrypoint (`ataturk-mcp`)."""
    mcp.run()


if __name__ == "__main__":
    main()
