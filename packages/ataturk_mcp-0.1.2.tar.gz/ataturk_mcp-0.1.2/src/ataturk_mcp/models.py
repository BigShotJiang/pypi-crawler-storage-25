"""Pydantic models exposed through the MCP API."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

SpeechKind = Literal["konusma", "demec", "telgraf", "beyanname", "mektup", "nutuk_bolum"]
Lang = Literal["tr", "en"]


class SpeechMeta(BaseModel):
    """Lightweight speech descriptor (no body)."""

    id: str = Field(..., description="Stable speech identifier, e.g. 'atam-c3-0042'.")
    year: int | None = Field(None, description="Year the speech was delivered.")
    date: str | None = Field(None, description="ISO date if known (YYYY-MM-DD).")
    title_tr: str = Field(..., description="Original Turkish title.")
    title_en: str | None = Field(None, description="English title if available.")
    location: str | None = Field(None, description="City / venue.")
    kind: SpeechKind = Field("konusma", description="Type of utterance.")
    source: str = Field(..., description="Primary source key, e.g. 'atam_cilt_3'.")
    source_ref: str | None = Field(
        None, description="Reference within the source (page number, chapter, etc.)."
    )


class Speech(SpeechMeta):
    """A full speech with its body text in one language."""

    lang: Lang = Field("tr", description="Language of the body text returned.")
    body: str = Field(..., description="Full text of the speech.")


class SpeechHit(SpeechMeta):
    """Search hit: meta + a snippet showing the matched context."""

    lang: Lang
    snippet: str = Field(..., description="HTML-free text snippet around the match.")
    rank: float = Field(..., description="BM25 score (lower is better).")


class Topic(BaseModel):
    id: int
    name_tr: str
    name_en: str | None = None
    speech_count: int = 0


class Citation(BaseModel):
    """Academic citation for a speech."""

    speech_id: str
    apa: str
    mla: str
    chicago: str
    source_url: str | None = None


class CorpusStats(BaseModel):
    total_speeches: int
    by_kind: dict[str, int]
    by_year: dict[int, int]
    languages: list[Lang]
    sources: list[str]


class NutukChapter(BaseModel):
    """A single chapter / section of Nutuk (1927)."""

    chapter: str
    title_tr: str
    title_en: str | None = None
    lang: Lang
    body: str
