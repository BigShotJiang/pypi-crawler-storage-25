"""Ataturk MCP — Atatürk's complete speeches as a Model Context Protocol server.

Created by Buğra Ayan — https://bugraayan.com
"""

__version__ = "0.1.2"
__author__ = "Buğra Ayan"
__author_url__ = "https://bugraayan.com"
__email__ = "bugraayan.com@gmail.com"
__license__ = "MIT"
__all__ = ["__version__", "__author__", "__author_url__", "__email__", "__license__"]
