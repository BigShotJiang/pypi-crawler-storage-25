# Authors

## Creator & maintainer

**Buğra Ayan** — <https://bugraayan.com>  ·  `bugraayan.com@gmail.com`

> *Designed and built the ETL pipeline, the SQLite + FTS5 corpus, and the
> FastMCP server that powers `ataturk-mcp`.*

## Source attribution

The speech texts themselves are public domain. They were digitised, edited and
made available by:

- **Atatürk Araştırma Merkezi (ATAM)** — *Atatürk'ün Söylev ve Demeçleri*,
  Cilt I–III (2024 edition). <https://atam.gov.tr/>
- **Vikikaynak / Türkçe Wikisource contributors**.
  <https://tr.wikisource.org/wiki/Kategori:Mustafa_Kemal_Atat%C3%BCrk>
- **Internet Archive** — public English translation of *Nutuk* (1927).
  <https://archive.org/details/361505859-a-speech-delivered-by-mustafa-kemal-ataturk-1927-aka-nutuk-in-english-aka-the-great-speech>

## Contributing

Pull requests, issue reports, and corpus additions (additional speeches, better
translations, topic annotations) are very welcome via
<https://github.com/bugraayan/ataturk-mcp>.
