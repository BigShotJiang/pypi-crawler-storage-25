# Youtube Autonomous FastAPI Docker Base Module

The module that is handled by a docker container to isolate the environment we need for each purpose, exposed by a FastAPI that allows asking for the specific resources.

This project is using `poetry` to handle the dependencies and the virtual environment, and `docker` to manage the specific python version and all the code with the app to be executed. 

### Instructions
#### Generate the image
We need to generate the docker image with all the things we need to be able to run the app inside.
- Use the `$ docker build --no-cache -t {LIBRARY_NAME} .` command to generate the Docker image by using the `dockerfile` file and ignoring the caché. This will download the `python 3.12.x` version, install the dependencies and copy the code. Use this if any dependency has changed since the last time. If you are just updating the code, you can use the following instead.
- Use the `$ docker build -t {LIBRARY_NAME} .` command to generate the Docker image by using the `dockerfile` file. It will download the `python 3.12.x` version, install the dependencies and copy the code, each of these steps only if needed (the cache will make it be ignore if it didn't change).

#### Run the container
We need to run the container, so it will be mounted and the app will be runing and ready to use.
- Use the command `$ docker rm -f {LIBRARY_NAME} 2>nul` to remove the previous container if existing, so we are able to mount it again from zero.
- Use the command `$ docker run -d -p "%port%":8000 --name {LIBRARY_NAME} {LIBRARY_NAME}` to run and mount the container and make the app be ready to use.

You can also execute the `run_server_docker.bat` to do all together using the caché (faster).

---

The docker will run uvicorn in the port 8000 internally, but our navigator will redirect the 8001 to that one, so we can have different docker containers working at the same time to provide different services using the same base (uvicorn + fastapi).

### Other details
- To run the project locally, execute the `run_server.bat` file or use `$ poetry run uvicorn yta_fastapi_docker_base.app.main:app --reload` directly.