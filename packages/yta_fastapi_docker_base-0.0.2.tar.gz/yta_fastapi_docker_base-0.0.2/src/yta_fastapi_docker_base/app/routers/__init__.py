"""
Check this project to get inspiration about FastAPI:
- https://github.com/Implosiv3/render-fastapi/blob/master/render-fastapi/routers/download/__init__.py
"""
from fastapi import APIRouter
from fastapi.responses import JSONResponse


PREFIX = f''

router = APIRouter(
    prefix = PREFIX
)

@router.get('/check-status')
def route_check_status(
) -> JSONResponse:
    return JSONResponse(
        {
            'error': False,
            'message': 'Hello World!'
        },
        status_code = 200
    )