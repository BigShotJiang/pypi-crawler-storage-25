from yta_fastapi_docker_base.app.routers import router as general_router
from fastapi import FastAPI


app = FastAPI()

# Include all the routers we have
app.include_router(general_router)