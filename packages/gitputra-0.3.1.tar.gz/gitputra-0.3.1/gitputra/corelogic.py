import os
import uuid
import time
import re
import ast

from git import Repo
import chromadb
import math
from rank_bm25 import BM25Okapi

from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, HRFlowable
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

import json
# AI SDKs
from openai import OpenAI
import google.generativeai as genai
from rich.spinner import Spinner
from .call_extractor import extract_calls as _ts_extract_calls

from rich.text import Text
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.align import Align
from rich.columns import Columns
from rich.prompt import Prompt
import threading
import warnings
from . import animations
warnings.filterwarnings("ignore", message=".*tight_layout.*")


console = Console()

wait_texts = ["It may take a while...", "Thanks for your patience...", "Just few moments more...", "Appreciate your patience..."]



def _animated_panel(live: Live, batch_num: int, total: int, stop_event: threading.Event, mode: str = "analyze"):
    """
    Runs in a thread until stop_event is set.
    mode='analyze'    → shockwave animation
    mode='synthesize' → convergence animation
    """

    t = 0
    while not stop_event.is_set():
        pixels = animations._shockwave_frame(t) if mode == "analyze" else animations._synthesis_frame(t)

        frame_text = Text(justify="center")
        for ch, color in pixels:
            if ch == '\n':
                frame_text.append('\n')
            else:
                frame_text.append(ch, style=color)

        progress_filled = int((batch_num - 1 + 0.5) / total * 30)
        progress_bar = "█" * progress_filled + "░" * (30 - progress_filled)
        percent = int((batch_num - 1 + 0.5) / total * 100)

        phase = int(time.time() * 6) % 6
        dots = ["", ".", "..", "...", "..", "."][phase]

        if mode == "analyze":
            status = f"  analyzing codebase{dots}"
            title  = "[bold magenta]◈ GitPutra ◈[/bold magenta]"
            border = "bold blue"
            header = f"\n  batch {batch_num}/{total}\n\n"
            header_style = "bold cyan"
        else:
            status = f"  synthesizing final report{dots}"
            title  = "[bold magenta]◈ GitPutra ◈[/bold magenta]"
            border = "bold cyan"
            header = f"\n  synthesizing {batch_num} batch summaries\n\n"
            header_style = "bold green"

        caption = Text(justify="center")
        caption.append(header, style=header_style)
        caption.append_text(frame_text)
        caption.append(f"\n\n  [{progress_bar}] {percent}%", style="dim")
        caption.append(f"\n  {status}\n", style="dim italic")

        live.update(Align(Panel(
            caption,
            title=title,
            border_style=border,
            padding=(1, 4),
            expand=False,
        ), align="center"))

        t += 1
        time.sleep(0.055)

# ─────────────────────────────────────────────
# SCAN ANIMATION — RADAR PING
# ─────────────────────────────────────────────
_SC_W = 38
_SC_H = 9
_SC_CHARS = [' ', '·', '░', '▒', '▓', '█']

def _scan_frame(t: int) -> list[tuple[str, str]]:
    """
    Radar ping expanding outward from center.
    Returns list of (char, hex_color) tuples, newlines included.
    """
    cx, cy = _SC_W / 2, _SC_H / 2
    result = []

    # blip positions — fixed "found files" that light up after ping passes
    blips = [(6,2),(31,1),(10,7),(28,6),(18,4),(5,6),(33,3),(14,1),(25,7),(8,4)]

    for row in range(_SC_H):
        for col in range(_SC_W):
            dx = (col - cx) / (_SC_W / 2)
            dy = (row - cy) / (_SC_H / 2) * 2.2
            dist = math.sqrt(dx * dx + dy * dy)

            # expanding ring — resets every 40 ticks
            ring_r = (t * 0.055) % 2.2
            delta = abs(dist - ring_r)
            ring = math.exp(-delta * delta * 18) * 0.9

            # blip glow — lights up after ring passes, fades slowly
            blip_v = 0.0
            for bx, by in blips:
                bdx = (col - bx) / 2.0
                bdy = (row - by) / 1.2
                bdist = math.sqrt(bdx*bdx + bdy*bdy)
                if bdist < 1.2:
                    # how long ago did the ring pass this blip
                    bpx = (bx - cx) / (_SC_W / 2)
                    bpy = (by - cy) / (_SC_H / 2) * 2.2
                    bp_dist = math.sqrt(bpx*bpx + bpy*bpy)
                    ring_age = (ring_r - bp_dist) % 2.2
                    if 0 < ring_age < 1.4:
                        fade = math.exp(-ring_age * 1.8) * (1 - bdist / 1.2)
                        blip_v = max(blip_v, fade)

            v = max(0.0, min(1.0, ring + blip_v))

            # color: green radar tones
            gv = int(max(0, min(1, v)) * 220 + 35)
            rv = int(max(0, min(1, v * 0.3)) * 80)
            bv = int(max(0, min(1, v * 0.2)) * 60)
            color = f"#{rv:02x}{gv:02x}{bv:02x}"

            char = _SC_CHARS[int(v * (len(_SC_CHARS) - 1))]
            result.append((char, color))

        if row < _SC_H - 1:
            result.append(('\n', '#ffffff'))

    return result

# ─────────────────────────────────────────────
# GLOBALS
# ─────────────────────────────────────────────
_ai_config     = {}
_openai_client = None
_language      = "English"
_ai_disabled   = False

# BM25 cache: keyed by (repo_name, branch) → (BM25Okapi, [doc_strings])
_bm25_cache: dict = {}

CHROMA_CLIENT = chromadb.PersistentClient(path="./chroma_db")

SUPPORTED_EXT = (
    ".py", ".c", ".h", ".cpp", ".js", ".ts", ".md", ".pdf", ".txt",
    ".java", ".go", ".rs", ".php", ".rb", ".swift",
    ".cs", ".html", ".css", ".json", ".yaml", ".yml", ".xml",
    ".sh", ".bat", ".ps1", ".gradle", ".makefile",
    ".ini", ".cfg", ".conf", ".log", ".sql", ".ipynb",
    ".vue", ".jsx", ".tsx", ".dart", ".scala", ".toml",
    ".pl", ".lua", ".r", ".m", ".kt", ".kts",
    ".groovy", ".clj", ".cljs", ".coffee", ".elm",
)

# Extensionless files to match by exact name
SUPPORTED_NAMES = ("Dockerfile", "Makefile", "makefile")

SKIP_DIRS = {".git", ".venv", "venv", "node_modules", "__pycache__",
             ".idea", ".vscode", "dist", "build", ".mypy_cache", ".pytest_cache"}

AI_OPTIONS = {
    "gemini": {
        "name": "Gemini",
        "text_model": "models/gemini-2.5-flash",
        "embed_model": "models/gemini-embedding-001",
    },
    "openai": {
        "name": "OpenAI",
        "text_model": "gpt-4o-mini",
        "embed_model": "text-embedding-3-large",
    },

    "ollama": {
        "name": "Ollama",
        "text_model": "phi3:mini",  # User-configurable or default
        "embed_model": "nomic-embed-text", # Local embedding model
    },
   
}


# ─────────────────────────────────────────────
# INIT
# ─────────────────────────────────────────────
def init(ai_choice: str, api_key: str, language: str = "English", ollama_model: str = None):
    global _ai_disabled, _ai_config, _openai_client, _language

    _ai_disabled = False
    _language  = language

    # Deep-copy the config so we don't mutate the global AI_OPTIONS dict
    _ai_config = dict(AI_OPTIONS[ai_choice])

    # Allow the caller to override the Ollama text model at runtime.
    # Embeddings always stay as nomic-embed-text (the default embed_model).
    if ai_choice == "ollama" and ollama_model:
        _ai_config["text_model"] = ollama_model

    if ai_choice == "gemini":
        genai.configure(api_key=api_key)

    if ai_choice == "ollama":
        _openai_client = OpenAI(
            base_url="http://localhost:11434/v1",
            api_key="ollama", # Required by SDK but ignored by Ollama
        )

    elif ai_choice == "openai":
        _openai_client = OpenAI(api_key=api_key)

def _safe_repo_id(repo_name: str) -> str:
    """Convert a repo path or name into a ChromaDB/filesystem-safe identifier."""
    base = os.path.basename(os.path.normpath(repo_name))
    safe = re.sub(r"[^a-zA-Z0-9._-]", "_", base).strip("_")
    return safe or "repo"
# ─────────────────────────────────────────────
# COLLECTION PER REPO
# ─────────────────────────────────────────────
def get_collection(repo_name: str, branch: str = None):
    suffix = f"_{branch.replace('/', '_').replace('-', '_')}" if branch else ""
    safe_name = _safe_repo_id(repo_name)
    return CHROMA_CLIENT.get_or_create_collection(name=f"repo_{safe_name}{suffix}")

import hashlib
import json

def _hash_file(content: str) -> str:
    """MD5 hash of a file's text content."""
    return hashlib.md5(content.encode("utf-8", errors="ignore")).hexdigest()

def _load_hashes(repo_name: str, branch: str = None) -> dict:
    """Load stored hashes from chroma_db/<repo>_hashes.json."""
    suffix = f"_{branch.replace('/', '_')}" if branch else ""
    path = os.path.join("chroma_db", f"{_safe_repo_id(repo_name)}{suffix}_hashes.json")
    if os.path.exists(path):
        with open(path, "r") as f:
            return json.load(f)
    return {}

def _save_hashes(repo_name: str, hashes: dict, branch: str = None) -> None:

    os.makedirs("chroma_db", exist_ok=True)
    suffix = f"_{branch.replace('/', '_')}" if branch else ""
    path = os.path.join("chroma_db", f"{_safe_repo_id(repo_name)}{suffix}_hashes.json")
    with open(path, "w") as f:
        json.dump(hashes, f, indent=2)

def build_dependency_clusters(files):
    all_calls = {}
    for fname, content in files:
        calls = _extract_calls(fname, content)
        all_calls.update(calls)

    clusters = []
    visited = set()

    for func in all_calls:
        if func in visited:
            continue

        stack = [func]
        cluster = set()

        while stack:
            f = stack.pop()
            if f in visited:
                continue
            visited.add(f)
            cluster.add(f)

            for called in all_calls.get(f, []):
                for target in all_calls:
                    if target.endswith(f".{called}"):
                        stack.append(target)

        clusters.append(cluster)

    return clusters

def chunk_by_file(
    files: list[tuple[str, str]],
    max_chars: int = 8000,
) -> list[str]:
    """
    Dependency-aware chunking:
    1. Sort files so likely-related ones are adjacent (same extension, then alpha)
    2. Split oversized single files into function-level sub-chunks
    3. Add a 1-line context header listing ALL filenames so the AI
       knows what else exists even when it can't see it
    """
    # ── 1. sort: group by extension so .py files stay together ──────────────
    files = sorted(files, key=lambda f: (os.path.splitext(f[0])[1], f[0]))
    header = f"""
        # CONTEXT SUMMARY:
        This chunk is part of a larger codebase.
        Files included in this chunk:
        {', '.join(f[0] for f in files)}

        Focus:
        - Understand relationships between functions
        - Do NOT assume missing implementations
        """

    # ── 2. split any single file that exceeds max_chars on its own ──────────
    expanded: list[tuple[str, str]] = []
    for fname, content in files:
        if len(content) <= max_chars:
            expanded.append((fname, content))
        else:
            # split on function/class boundaries for Python
            ext = os.path.splitext(fname)[1]
            if ext == ".py":
                parts = _split_python_file(fname, content, max_chars)
            else:
                # generic: split on blank lines, respecting max_chars
                parts = _split_generic(fname, content, max_chars)
            expanded.extend(parts)

    # ── 3. pack into chunks greedily, but never mix extensions ──────────────
    chunks: list[str] = []
    current_parts: list[str] = []
    current_len = len(header)
    current_ext = None

    for fname, content in expanded:
        ext = os.path.splitext(fname)[1]
        piece = f"# FILE: {fname}\n{content}\n\n"

        ext_changed = (current_ext is not None and ext != current_ext)
        would_overflow = (current_len + len(piece) > max_chars and current_parts)

        if ext_changed or would_overflow:
            chunks.append(header + "".join(current_parts))
            current_parts, current_len = [], len(header)

        current_parts.append(piece)
        current_len += len(piece)
        current_ext = ext

    if current_parts:
        chunks.append(header + "".join(current_parts))

    # At the end of chunk_by_file, replace the final_chunks build:
    final_chunks = []
    OVERLAP = 250
    for chunk in chunks:
        # extract the first "# FILE: <name>" from the chunk to use as label
        m = re.search(r"# FILE: (.+)", chunk)
        label = m.group(1).split("[part")[0] if m else "unknown"
        i = 0
        while i < len(chunk):
            final_chunks.append((chunk[i:i + max_chars], label))
            i += max_chars - OVERLAP

    return final_chunks


def _split_python_file(
    fname: str, content: str, max_chars: int
) -> list[tuple[str, str]]:
    """Split a large .py file at top-level def/class boundaries."""
    import ast, textwrap

    try:
        tree = ast.parse(content)
    except SyntaxError:
        return _split_generic(fname, content, max_chars)

    lines = content.splitlines(keepends=True)
    boundaries = sorted(
        node.lineno - 1                          # 0-indexed
        for node in ast.walk(tree)
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
        and node.col_offset == 0                 # top-level only
    )

    if not boundaries:
        return _split_generic(fname, content, max_chars)

    # build segments: [0..b1), [b1..b2), ...
    boundaries = [0] + boundaries + [len(lines)]
    segments: list[str] = []
    for i in range(len(boundaries) - 1):
        seg = "".join(lines[boundaries[i]:boundaries[i+1]])
        if seg.strip():
            segments.append(seg)

    # merge small segments, split oversized ones
    result: list[tuple[str, str]] = []
    buffer = ""
    part = 1
    for seg in segments:
        if len(buffer) + len(seg) <= max_chars:
            buffer += seg
        else:
            if buffer:
                result.append((f"{fname}[part{part}]", buffer))
                part += 1
            # oversized single segment — hard-split by lines
            if len(seg) > max_chars:
                for sub in _split_generic(fname, seg, max_chars):
                    result.append((f"{fname}[part{part}]", sub[1]))
                    part += 1
            else:
                buffer = seg
    if buffer:
        result.append((f"{fname}[part{part}]", buffer))

    return result


def _split_generic(
    fname: str, content: str, max_chars: int
) -> list[tuple[str, str]]:
    """Fallback: split on blank lines, hard-cut if needed."""
    paragraphs = re.split(r'\n{2,}', content)
    parts: list[tuple[str, str]] = []
    buffer = ""
    part = 1

    for para in paragraphs:
        piece = para + "\n\n"
        if len(buffer) + len(piece) > max_chars and buffer:
            parts.append((f"{fname}[part{part}]", buffer))
            part += 1
            buffer = piece
        else:
            buffer += piece

    if buffer:
        parts.append((f"{fname}[part{part}]", buffer))

    return parts

# ─────────────────────────────────────────────
# AI — GENERATE
# ─────────────────────────────────────────────
def safe_generate(prompt: str, retries: int = 2) -> str | None:
    global _ai_disabled

    if _ai_disabled or not _ai_config:
        return None

    for attempt in range(retries):
        try:
            name = _ai_config["name"]

            if name == "Gemini":
                model = genai.GenerativeModel(_ai_config["text_model"])
                res   = model.generate_content(
                    prompt,
                    generation_config={"max_output_tokens": 8192},
                )
                return getattr(res, "text", None)

            elif name == "OpenAI":
                res = _openai_client.chat.completions.create(
                    model=_ai_config["text_model"],
                    max_tokens=8192,
                    messages=[{"role": "user", "content": prompt}],
                )
                return res.choices[0].message.content
            elif name == "Ollama":                    # ← ADD THIS
                res = _openai_client.chat.completions.create(
                    model=_ai_config["text_model"],
                    max_tokens=8192,
                    messages=[{"role": "user", "content": prompt}],
                )
                return res.choices[0].message.content
            

           

        except Exception as e:
            err = str(e)

            if _ai_config.get("name") == "Ollama" and ("connection" in err.lower() or "refused" in err.lower()):
                console.print("\n⚠️  Ollama server unreachable. Falling back to Gemini...", style="bold yellow")
                
                # Fetch key from environment and switch to Gemini
                import os
                gemini_key = os.getenv("API_KEY")
                if not gemini_key:
                    console.print("❌ No API_KEY found in .env for Gemini fallback.", style="bold red")
                    return None
                
                # Re-initialize with Gemini and retry
                init("gemini", gemini_key, _language)
                continue

            if "quota" in err.lower() and "429" not in err:
                console.print("⚠️  Quota exceeded → AI disabled for this session", style="bold red")
                _ai_disabled = True
                return None
            elif "429" in err or "rate" in err.lower():
                console.print(f"⏳ Rate limited — waiting 60 seconds...", style="bold blue")
                time.sleep(60)
                continue
            if attempt < retries - 1:
                time.sleep(2)

    return None


# ─────────────────────────────────────────────
# AI — EMBED
# ─────────────────────────────────────────────
def embed_text(text: str, is_query: bool = False, retries: int = 3) -> list[float]:

    # No AI configured (e.g. --ai none) — return empty sentinel immediately
    if not _ai_config:
        return []

    def _rate_limit_wait(total_wait: int):
        """
        Thread-safe rate-limit wait.  Uses console.print (not Live) so it
        never conflicts with an outer Live context running on another thread.
        """
        start = time.time()
        i = 0
        while True:
            elapsed = time.time() - start
            remaining = total_wait - elapsed
            if remaining <= 0:
                break
            msg = wait_texts[i % len(wait_texts)]
            console.print(f"⏳ {msg} ({int(remaining)}s remaining…)", style="bold yellow")
            time.sleep(min(10, remaining))
            i += 1
    for attempt in range(retries):
        try:
            name = _ai_config["name"]

            if name == "Gemini":
                task_type = "retrieval_query" if is_query else "retrieval_document"
                res = genai.embed_content(
                    model=_ai_config["embed_model"],
                    content=text,
                    task_type=task_type,
                )
                return res["embedding"]

            elif name == "OpenAI":
                res = _openai_client.embeddings.create(
                    model=_ai_config["embed_model"],
                    input=text,
                )
                return res.data[0].embedding
            
            elif name == "Ollama":                          # ← ADD THIS BLOCK
                res = _openai_client.embeddings.create(
                    model=_ai_config["embed_model"],
                    input=text,
                )
                return res.data[0].embedding

        except Exception as e:
            err = str(e)

            if _ai_config.get("name") == "Ollama" and ("connection" in err.lower() or "refused" in err.lower()):
                console.print("\n⚠️  Ollama unreachable. Falling back to Gemini for embeddings...", style="bold yellow")
                import os
                gemini_key = os.getenv("API_KEY")
                if gemini_key:
                    init("gemini", gemini_key, _language)
                    continue

            
            if "429" in err or "rate" in err.lower():
                wait = 15 * (attempt + 1)
                _rate_limit_wait(wait)
                continue
            console.print(f"❌ Embedding failed-> {e}", style="bold red")
            dim = 768 if _ai_config.get("name") in ("Gemini", "Ollama") else 1536
            return [0.0] * dim

    console.print("❌ Embedding failed after retries — using dummy", style="bold red")
    dim = 768 if _ai_config.get("name") in ("Gemini", "Ollama") else 1536   
    return [0.0] * dim


# ─────────────────────────────────────────────
# REPO — CLONE & LOAD
# ─────────────────────────────────────────────
def clone_repo(url: str, branch: str = None) -> tuple[str, str]:
    os.makedirs("repos", exist_ok=True)
    name = url.rstrip("/").split("/")[-1].replace(".git", "")
    branch_suffix = f"_{branch.replace('/', '_').replace('-', '_')}" if branch else ""
    path = os.path.join("repos", f"{name}{branch_suffix}")

    if not os.path.exists(path):
        console.print(f"📥 Cloning {url} {'@ ' + branch if branch else ''} ...", style="bold cyan")
        kwargs = {"branch": branch} if branch else {}
        Repo.clone_from(url, path, **kwargs)
    else:
        console.print(f"✅ Repo already exists at {path}", style="bold green")

    return path, name


# ─────────────────────────────────────────────
# DIFF
# ─────────────────────────────────────────────
_DIFF_MAX_CHARS = 50_000

# In corelogic.py
def get_diff(repo_path: str, base: str, head: str) -> tuple[str, list[str]]:
    """Return (diff_text, changed_filenames) between *base* and *head*."""
    # 1. Initialize with parent search
    repo = Repo(repo_path, search_parent_directories=True)

    # 2. Auto-Chronology Logic
    actual_base, actual_head = base, head
    try:
        if not repo.is_ancestor(actual_base, actual_head):
            if repo.is_ancestor(actual_head, actual_base):
                # Swapped! Flip them for the user
                actual_base, actual_head = actual_head, actual_base
    except Exception:
        pass

    # 3. PRINT HERE: This fulfills your requirement to print from corelogic
    console.print(f"\n🔀 Diffing [bold cyan]{actual_base}[/bold cyan] → [bold green]{actual_head}[/bold green] ...\n")

    # 4. Execute diff using corrected refs
    diff_text: str = repo.git.diff(actual_base, actual_head, unified=3)

    # 5. Collect changed filenames
    changed_files: list[str] = []
    for line in diff_text.splitlines():
        if line.startswith("+++ b/"):
            fname = line[6:].strip()
            if fname and fname not in changed_files:
                changed_files.append(fname)

    # 6. Truncation logic
    if len(diff_text) > _DIFF_MAX_CHARS:
        truncation_note = (
            f"\n\n[... diff truncated — showing first {_DIFF_MAX_CHARS:,} of "
            f"{len(diff_text):,} characters ...]\n"
        )
        diff_text = diff_text[:_DIFF_MAX_CHARS] + truncation_note

    return diff_text, changed_files

def summarize_diff(diff_text: str, changed_files: list[str], language: str = "English") -> str:
    """Ask the AI to summarize a diff and flag risky changes.

    Returns the summary string, or an empty string if AI is unavailable.
    """
    files_list = "\n".join(f"  - {f}" for f in changed_files) if changed_files else "  (none detected)"
    prompt = f"""You are a senior software engineer reviewing a git diff.
Language for your response: {language}

Changed files:
{files_list}

Diff:
```diff
{diff_text}
```

Please provide a structured summary covering:
1. **What changed** — a concise description of the modifications per file/area.
2. **Why it matters** — the likely intent or impact of these changes.
3. **Risky changes** — flag anything that could introduce bugs, break APIs, affect security, or need careful review. If nothing stands out, say so explicitly.

Keep your response clear and developer-friendly."""

    result = safe_generate(prompt)
    return result or ""



def load_files(repo_path: str) -> list[tuple[str, str]]:
    result_box = [None]
    done_event = threading.Event()

    def _scan():
        found = []
        for root, dirnames, files in os.walk(repo_path):
            dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
            for file in files:
                if file.endswith(SUPPORTED_EXT) or file in SUPPORTED_NAMES:
                    try:
                        full_path = os.path.join(root, file)
                        rel_path = os.path.relpath(full_path, repo_path)
                        if file.endswith(".pdf"):
                            import pdfplumber
                            with pdfplumber.open(full_path) as pdf:
                                content = "\n".join(page.extract_text() or "" for page in pdf.pages).strip()
                        else:
                            with open(full_path, "r", errors="ignore") as f:
                                content = f.read().strip()
                        if content:
                            found.append((rel_path, content))
                    except Exception as e:
                        console.print(f"⚠️ Failed to load file {file}: {e}", style="bold red")
        result_box[0] = found
        done_event.set()

    scan_thread = threading.Thread(target=_scan, daemon=True)
    scan_thread.start()

    # wait 2 seconds — if still running, show spinner
    finished_early = done_event.wait(timeout=2.0)

    if not finished_early:
        # ADD this instead
        from rich.text import Text
        t = 0
        with Live(console=console, refresh_per_second=15, transient=True) as live:
            while not done_event.is_set():
                pixels = _scan_frame(t)
                frame_text = Text(justify="center")
                for ch, color in pixels:
                    if ch == '\n':
                        frame_text.append('\n')
                    else:
                        frame_text.append(ch, style=color)

                caption = Text(justify="center")
                caption.append("\n  scanning files\n\n", style="bold green")
                caption.append_text(frame_text)
                caption.append("\n\n  reading directory tree...\n", style="dim italic")

                live.update(Align(Panel(
                    caption,
                    title="[bold magenta]◈ GitPutra ◈[/bold magenta]",
                    border_style="bold green",
                    padding=(1, 4),
                    expand=False,
                ), align="center"))
                t += 1
                time.sleep(0.07)

    scan_thread.join()
    files_data = result_box[0] or []
    console.print(f"📂 Loaded {len(files_data)} source files", style="bold yellow")
    return files_data


# ─────────────────────────────────────────────
# BM25 HELPERS
# ─────────────────────────────────────────────
def _build_bm25_index(repo_name: str, branch: str = None):
    """
    Fetch all documents from the ChromaDB collection, tokenise them,
    and return a (BM25Okapi, ordered_docs_list) pair.
    Result is cached in _bm25_cache keyed by (repo_name, branch).
    """
    key = (repo_name, branch)
    if key in _bm25_cache:
        return _bm25_cache[key]

    collection = get_collection(repo_name, branch)
    result     = collection.get(include=["documents"])
    docs       = result.get("documents") or []

    tokenised  = [doc.lower().split() for doc in docs]
    bm25       = BM25Okapi(tokenised) if tokenised else None
    _bm25_cache[key] = (bm25, docs)
    return bm25, docs


def _rrf(ranks_list: list[list[str]], k: int = 60) -> list[str]:
    """
    Reciprocal Rank Fusion across multiple ranked doc lists.
    Each inner list is already ordered best-first.
    Returns a deduplicated list ordered by descending RRF score.
    """
    scores: dict[str, float] = {}
    for ranked in ranks_list:
        for rank, doc in enumerate(ranked):
            scores[doc] = scores.get(doc, 0.0) + 1.0 / (k + rank + 1)
    return sorted(scores, key=lambda d: scores[d], reverse=True)


# ─────────────────────────────────────────────
# CHROMADB — STORE & QUERY
# ─────────────────────────────────────────────
def store_chunks(files: list[tuple[str, str]], repo_name: str, branch: str = None):

    # No AI provider configured — nothing to embed, skip silently
    if not _ai_config:
        console.print("ℹ️  No AI provider configured — skipping vector indexing.", style="dim")
        return

    collection   = get_collection(repo_name, branch)
    stored_hashes = _load_hashes(repo_name, branch)  # ← load existing hashes
    new_hashes    = dict(stored_hashes)             # we'll mutate this copy

    # ── Determine which files changed ────────────────────────────────────────
    current_file_names = {fname for fname, _ in files}
    files_to_index = []
    
    # 1. Handle deleted files
    for fname in list(stored_hashes.keys()):
        if fname not in current_file_names:
            try:
                old = collection.get(where={"filename": fname})
                if old and old.get("ids"):
                    collection.delete(ids=old["ids"])
                console.print(f"  🗑️ Removing deleted file from index: {fname}", style="dim red")
            except Exception:
                pass
            del new_hashes[fname]

    # 2. Handle changed and new files
    for fname, content in files:
        current_hash = _hash_file(content)
        if stored_hashes.get(fname) == current_hash:
            continue                                # unchanged — skip entirely
        # Changed or new: purge any old chunks for this file first
        try:
            old = collection.get(where={"filename": fname})
            if old and old.get("ids"):
                collection.delete(ids=old["ids"])
        except Exception:
            pass
        console.print(f"  📄 Queuing for indexing: {fname}", style="dim blue")
        files_to_index.append((fname, content))
        new_hashes[fname] = current_hash

    if not files_to_index:
        console.print("✅ All files unchanged — index is up to date.", style="bold green")
        return

    # ── Chunk only the changed/new files ─────────────────────────────────────
    chunks       = chunk_by_file(files_to_index, max_chars=3000)
    total        = len(chunks)
    stored       = 0
    progress_box = [0.0]
    stop_event   = threading.Event()

    console.print(f"💾 Indexing {total} chunks from {len(files_to_index)} changed file(s)…",
                  style="bold yellow")

    # ✅ correct
    def _store():
        nonlocal stored
        for chunk_text, fname_label in chunks:   # chunks = chunk_by_file(...) above
            emb = embed_text(chunk_text)
            collection.add(
                documents=[chunk_text],
                embeddings=[emb],
                ids=[str(uuid.uuid4())],
                metadatas=[{"chunk": chunk_text[:80], "filename": fname_label}],
            )
            stored += 1
            progress_box[0] = stored / total
        stop_event.set()

    store_thread = threading.Thread(target=_store, daemon=True)
    store_thread.start()
    t = 0
    with Live(console=console, refresh_per_second=10, transient=True) as live:
        while not stop_event.is_set():
            prog   = progress_box[0]
            pixels = animations._grid_fill_frame(t, prog)
    
            frame_text = Text(justify="center")
            for ch, color in pixels:
                if ch == '\n':
                    frame_text.append('\n')
                else:
                    frame_text.append(ch, style=color)
    
            filled = int(prog * 30)
            bar    = '█' * filled + '░' * (30 - filled)
            pct    = int(prog * 100)
    
            caption = Text(justify="center")
            caption.append("\n  indexing chunks\n\n", style="bold green")
            caption.append_text(frame_text)
            caption.append(f"\n\n  [{bar}] {pct}%  ({int(prog * total)}/{total})\n", style="dim")
            caption.append("  building vector index...\n", style="dim italic")
    
            live.update(Align(Panel(
                caption,
                title="[bold magenta]◈ GitPutra ◈[/bold magenta]",
                border_style="bold green",
                padding=(1, 4),
                expand=False,
            ), align="center"))
            t += 1
            time.sleep(0.055)
    store_thread.join()

    # Invalidate BM25 cache so next query rebuilds from fresh ChromaDB data
    _bm25_cache.pop((repo_name, branch), None)

    _save_hashes(repo_name, new_hashes, branch)    # ← persist updated hashes
    console.print(f"✅ Stored {total} chunks", style="bold green")

def query_rag(question: str, repo_name: str, branch: str = None, history: list = None) -> str:

    collection = get_collection(repo_name, branch)

    # ── Phase 1: Embed question (DNA helix animation) ─────────────────────
    emb_box  = [None]
    done_emb = threading.Event()

    def _embed():
        emb_box[0] = embed_text(question, is_query=True)
        done_emb.set()

    embed_thread = threading.Thread(target=_embed, daemon=True)
    embed_thread.start()

    t = 0
    with Live(console=console, refresh_per_second=20, transient=True) as live:
        while not done_emb.is_set():
            pixels = animations._particle_storm_frame(t)
            frame_text = Text(justify="center")
            for ch, color in pixels:
                if ch == '\n':
                    frame_text.append('\n')
                else:
                    frame_text.append(ch, style=color)

            caption = Text(justify="center")
            caption.append("\n  embedding query\n\n", style="bold cyan")
            caption.append_text(frame_text)
            caption.append("\n\n  searching vector index...\n", style="dim italic")

            live.update(Align(Panel(
                caption,
                title="[bold magenta]◈ GitPutra ◈[/bold magenta]",
                border_style="bold cyan",
                padding=(1, 4),
                expand = False,
            ), align="center"))
            t += 1
            time.sleep(0.055)

    embed_thread.join()

    # ── Hybrid retrieval: vector top-5 + BM25 top-10 → RRF top-5 ─────────
    emb = emb_box[0]
    # Vector search
    vec_res  = collection.query(query_embeddings=[emb], n_results=5)
    vec_docs = vec_res.get("documents", [[]])[0]

    # BM25 search
    bm25, all_docs = _build_bm25_index(repo_name, branch)
    if bm25 and all_docs:
        tokens     = question.lower().split()
        scores     = bm25.get_scores(tokens)
        top10_idx  = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:10]
        bm25_docs  = [all_docs[i] for i in top10_idx]
    else:
        bm25_docs  = []

    # Reciprocal Rank Fusion → take final top-5
    fused_docs = _rrf([vec_docs, bm25_docs])[:5]
    context = "\n".join(fused_docs) if fused_docs else ""

    history_block = ""
    if history:
        # always include last 3 exchanges verbatim (most relevant)
        recent = history[-6:]
        # summarize older exchanges into one line each
        older  = history[:-6]

        if older:
            history_block = "Earlier in this conversation:\n"
            for i in range(0, len(older), 2):
                if i + 1 < len(older):
                    q = older[i]["content"][:120].replace("\n", " ")
                    a = older[i+1]["content"][:120].replace("\n", " ")
                    history_block += f"- User asked about: {q}... → {a}...\n"
            history_block += "\n"

        history_block += "Recent conversation:\n"
        for msg in recent:
            role = "User" if msg["role"] == "user" else "Assistant"
            history_block += f"{role}: {msg['content']}\n"
        history_block += "\n"

    prompt = f"""Answer in {_language}.
You are "AI Putra", an expert AI coding assistant with deep understanding of codebases.
Be concise and direct unless you are asked for a detailed answer. 
Answer in 7-15 sentences maximum unless the question explicitly requires detail.

Context from codebase:
{context}

{history_block}Current question:
{question}
"""

    # ── Phase 2: LLM generation (waveform collapse animation) ─────────────
    result_box = [None]
    done_gen   = threading.Event()

    def _generate():
        result_box[0] = safe_generate(prompt)
        done_gen.set()

    gen_thread = threading.Thread(target=_generate, daemon=True)
    gen_thread.start()

    t = 0
    with Live(console=console, refresh_per_second=20, transient=True) as live:
        while not done_gen.is_set():
            pixels = animations._particle_storm_frame(t)
            frame_text = Text(justify="center")
            for ch, color in pixels:
                if ch == '\n':
                    frame_text.append('\n')
                else:
                    frame_text.append(ch, style=color)

            caption = Text(justify="center")
            caption.append("\n  generating answer\n\n", style="bold green")
            caption.append_text(frame_text)
            caption.append("\n\n  synthesizing response...\n", style="dim italic")

            live.update(Align(Panel(
                caption,
                title="[bold magenta]◈ GitPutra ◈[/bold magenta]",
                border_style="bold green",
                padding=(1, 4),
                expand = False,
            ), align="center"))
            t += 1
            time.sleep(0.055)

    gen_thread.join()
    return result_box[0] or "⚠️ AI unavailable."


# ─────────────────────────────────────────────
# ANALYSIS
# ─────────────────────────────────────────────

# Max chars to send in a single API call.
# ~60k chars ≈ 15k tokens — safe for Gemini 2.5 Flash, GPT-4o-mini
# (all support 128k+ context). Fits ~20 chunks of 3000 chars each.
_BATCH_CHARS = 60_000

def analyze_repo(files: list[tuple[str, str]]) -> str:
    console.print("\n🔍 Analyzing repo...\n", style = "bold blue")
    chunks_with_labels = chunk_by_file(files)
    chunks = [text for text, _label in chunks_with_labels]

    # ── pack chunks into batches ─────────────────────────────────────────────
    batches: list[str] = []
    current_batch: list[str] = []
    current_len = 0

    for chunk in chunks:
        if current_len + len(chunk) > _BATCH_CHARS and current_batch:
            batches.append("\n".join(current_batch))
            current_batch, current_len = [], 0
        current_batch.append(chunk)
        current_len += len(chunk)

    if current_batch:
        batches.append("\n".join(current_batch))

    console.print(f"  📦 {len(chunks)} chunks → {len(batches)} batch call(s) + 1 synthesis\n", style = "bold yellow")

    # ── one summary call per batch ───────────────────────────────────────────
    summaries = []
    with Live(console=console, refresh_per_second=20, transient=True) as live:
        for i, batch in enumerate(batches, 1):
            # start animation thread
            stop_event = threading.Event()
            thread = threading.Thread(
                target=_animated_panel,
                args=(live, i, len(batches), stop_event),
                daemon=True
            )
            thread.start()

            # actual API call — animation runs while this blocks
            # AFTER
            res = safe_generate(f"""
You are a senior software engineer auditing a codebase. Be concise and dense — no filler.

Extract only the most important findings from this chunk in bullet points:
- Key functions and what they actually do (1 line each)
- Critical bugs or flaws (name the function, state the problem)
- Notable patterns or design decisions (1 line each)
- Any missing or broken integrations
                                
Max 200 words. Reference exact function/file names only.

Code:
{batch}
""")
            stop_event.set()
            thread.join()

            if res:
                summaries.append(res)

            # flash completion
            progress_filled = int(i / len(batches) * 30)
            progress_bar = "█" * progress_filled + "░" * (30 - progress_filled)
            live.update(Align(Panel(
                f"\n"
                f"[bold green]  ✅ Batch {i}/{len(batches)} complete[/bold green]\n\n"
                f"[bold green]  {'█' * 18}[/bold green]\n\n"
                f"[dim]  [{progress_bar}] {int(i/len(batches)*100)}%[/dim]\n\n"
                f"[dim italic]  {'Synthesizing final report...' if i == len(batches) else 'Next batch loading...'}[/dim italic]\n",
                title="[bold magenta]◈ GitPutra◈[/bold magenta]",
                border_style="bold green",
                padding=(1, 4),
                expand = False,
            ), align="center"))
            time.sleep(0.6)    

    if not summaries:
        return "⚠️ AI unavailable — no analysis generated."

    # ── final synthesis (unchanged) ──────────────────────────────────────────
    result_box = [None]

    def _run_synthesis():
        result_box[0] = safe_generate(f"""
You are gitputra, the code assistant with the expertise of a princiapl engineer.
You are writing a minimum 5 and maximum 7 page technical audit report.
Be direct, critical, and dense. No filler sentences. Every line must carry information.
Reference exact function and file names throughout.

### ACTUAL SYSTEM SUMMARY
What the system truly does and its real vs implied capabilities. 3-5 sentences.

### ARCHITECTURE
How it is structured, data flow, key dependencies. Highlight any fragmentation. 4-6 bullets.

### KEY ENGINEERING DECISIONS
The 3-5 most important design decisions and why they matter or why they are wrong.

### CODE QUALITY
Top 5 concrete flaws — for each: what it is, which file/function, what it breaks.

### GAPS & FALSE ASSUMPTIONS
What is missing or broken that should exist. Be specific.

### CONCRETE IMPROVEMENTS
Top 5 actionable fixes with the exact function or file to change.

Have a conclusion at the end of the report summarizing the overall state of the codebase and its maintainability.

Findings:
{chr(10).join(summaries)}
""")
    stop_event = threading.Event()
    synthesis_thread = threading.Thread(target=_run_synthesis, daemon=True)

    with Live(console=console, refresh_per_second=20, transient=True) as live:
        anim_thread = threading.Thread(
            target=_animated_panel,
            args=(live, len(batches), len(batches), stop_event),
            kwargs={"mode": "synthesize"},
            daemon=True,
        )

        synthesis_thread.start()
        anim_thread.start()
        synthesis_thread.join()
        stop_event.set()
        anim_thread.join()

    return result_box[0] or "⚠️ Final synthesis failed."


def _extract_calls(fname: str, content: str) -> dict[str, set[str]]:
    return _ts_extract_calls(fname, content)


# ─────────────────────────────────────────────
# DIAGRAMS
# ─────────────────────────────────────────────

def _clean(name: str) -> str:
    return (
        name.replace(".py", "_py")
            .replace(".", "_")
            .replace("-", "_")
            .replace("/", "_")
    )

def _build_call_graph(files: list[tuple[str, str]]) -> tuple[dict, dict]:
    """
    Returns:
        all_funcs : short_name -> set of full_names  (fixes collision — one short name
                    can map to multiple full names in different modules)
        all_calls : full_name  -> set of short callee names
    """
    all_funcs: dict[str, set[str]] = {}
    all_calls: dict[str, set[str]] = {}

    for fname, content in files:
        calls = _extract_calls(fname, content)
        all_calls.update(calls)
        for full_name in calls:
            short = full_name.split(".")[-1]
            all_funcs.setdefault(short, set()).add(full_name)  # fix: set not str

    return all_funcs, all_calls


def _module_of(full_name: str) -> str:
    return full_name.rsplit(".", 1)[0]


# ── 1. FULL CALL GRAPH ───────────────────────────────────────────────────────
def generate_diagram(files: list[tuple[str, str]], output_dir: str = "output"):
    """Every intra-project function call, same or different module."""
    try:
        from pyvis.network import Network
    except ImportError:
        console.print("⚠️  pyvis not installed — run: pip install pyvis", style="bold red")
        return

    all_funcs, all_calls = _build_call_graph(files)

    COLORS = ["#CECBF6", "#9FE1CB", "#FAC775", "#F5C4B3", "#B5D4F4"]
    module_color: dict[str, str] = {}
    color_idx = 0

    net = Network(height="750px", width="100%", directed=True, bgcolor="#ffffff")
    net.set_options("""
    {
      "layout": { "hierarchical": { "enabled": false } },
      "physics": { "stabilization": true, "barnesHut": { "springLength": 120 } },
      "edges": { "arrows": { "to": { "enabled": true } }, "color": "#888780", "width": 0.8 },
      "nodes": { "font": { "size": 12 }, "shape": "box", "borderWidth": 0.5 }
    }
    """)

    # add nodes
    for full_name in all_calls:
        mod = _module_of(full_name)
        if mod not in module_color:
            module_color[mod] = COLORS[color_idx % len(COLORS)]
            color_idx += 1
        node_id = full_name.replace(".", "_")
        short   = full_name.split(".")[-1]
        net.add_node(node_id, label=short, title=f"{mod}.py → {short}()", color=module_color[mod], borderWidthSelected=2)

    # add ALL intra-project edges
    edges_added = set()
    for func, called_set in all_calls.items():
        src = func.replace(".", "_")
        for callee_short in called_set:
            if callee_short not in all_funcs:
                continue
            for callee_full in all_funcs[callee_short]:      # fix: iterate the set
                if callee_full == func:
                    continue
                tgt  = callee_full.replace(".", "_")
                edge = (src, tgt)
                if edge not in edges_added:
                    net.add_edge(src, tgt)
                    edges_added.add(edge)

    if not edges_added:
        console.print("📊 No intra-project calls found — skipping full call graph", style="bold yellow")
        return

    os.makedirs(output_dir, exist_ok=True)
    out = os.path.abspath(os.path.join(output_dir, "diagram_full.html"))
    net.save_graph(out)
    console.print(f"📊 Full call graph → {out}", style="bold yellow")


# ── 2. CROSS-MODULE ONLY ─────────────────────────────────────────────────────
def generate_diagram_crossmodule(files: list[tuple[str, str]], output_dir: str = "output"):
    """Function-level nodes, only edges that cross a module boundary."""
    try:
        from pyvis.network import Network
    except ImportError:
        console.print("⚠️  pyvis not installed — run: pip install pyvis", style="bold red")
        return

    all_funcs, all_calls = _build_call_graph(files)

    COLORS = ["#CECBF6", "#9FE1CB", "#FAC775", "#F5C4B3", "#B5D4F4"]
    module_color: dict[str, str] = {}
    color_idx = 0

    net = Network(height="750px", width="100%", directed=True, bgcolor="#ffffff")
    net.set_options("""
    {
      "layout": { "hierarchical": { "enabled": false } },
      "physics": { "stabilization": true, "barnesHut": { "springLength": 160 } },
      "edges": { "arrows": { "to": { "enabled": true } }, "color": "#534AB7", "width": 1 },
      "nodes": { "font": { "size": 12 }, "shape": "box", "borderWidth": 0.5 }
    }
    """)

    edges_added = set()
    nodes_needed: set[str] = set()

    # find cross-module edges first so we only add nodes that appear in them
    cross_edges: list[tuple[str, str]] = []
    for func, called_set in all_calls.items():
        src_mod = _module_of(func)
        for callee_short in called_set:
            if callee_short not in all_funcs:
                continue
            for callee_full in all_funcs[callee_short]:
                if callee_full == func:
                    continue
                if _module_of(callee_full) != src_mod:          # cross-module check
                    edge = (func, callee_full)
                    if edge not in edges_added:
                        cross_edges.append(edge)
                        edges_added.add(edge)
                        nodes_needed.add(func)
                        nodes_needed.add(callee_full)

    if not cross_edges:
        console.print("📊 No cross-module calls found — skipping cross-module graph", style="bold yellow")
        return

    for full_name in nodes_needed:
        mod = _module_of(full_name)
        if mod not in module_color:
            module_color[mod] = COLORS[color_idx % len(COLORS)]
            color_idx += 1
        node_id = full_name.replace(".", "_")
        short   = full_name.split(".")[-1]
        net.add_node(node_id, label=short, title=f"{mod}.py → {short}()", color=module_color[mod], borderWidthSelected=2)

    for src, tgt in cross_edges:
        net.add_edge(src.replace(".", "_"), tgt.replace(".", "_"))

    os.makedirs(output_dir, exist_ok=True)
    out = os.path.abspath(os.path.join(output_dir, "diagram_crossmodule.html"))
    net.save_graph(out)
    console.print(f"📊 Cross-module graph → {out}", style="bold yellow")


# ── 3. MODULE DEPENDENCY GRAPH ───────────────────────────────────────────────
def generate_diagram_modules(files: list[tuple[str, str]], output_dir: str = "output"):
    """High-level: one node per .py file, edge = any call crossing that boundary."""
    try:
        from pyvis.network import Network
    except ImportError:
        console.print("⚠️  pyvis not installed — run: pip install pyvis", style="bold red")
        return

    all_funcs, all_calls = _build_call_graph(files)

    # count how many function calls cross each module boundary
    edge_weights: dict[tuple[str, str], int] = {}
    for func, called_set in all_calls.items():
        src_mod = _module_of(func)
        for callee_short in called_set:
            if callee_short not in all_funcs:
                continue
            for callee_full in all_funcs[callee_short]:
                tgt_mod = _module_of(callee_full)
                if tgt_mod != src_mod:
                    key = (src_mod, tgt_mod)
                    edge_weights[key] = edge_weights.get(key, 0) + 1

    if not edge_weights:
        console.print("📊 No cross-module dependencies found — skipping module graph", style="bold yellow")
        return

    COLORS = ["#CECBF6", "#9FE1CB", "#FAC775", "#F5C4B3", "#B5D4F4"]
    modules = sorted({m for pair in edge_weights for m in pair})
    module_color = {m: COLORS[i % len(COLORS)] for i, m in enumerate(modules)}

    net = Network(height="600px", width="100%", directed=True, bgcolor="#ffffff")
    net.set_options("""
    {
      "layout": { "hierarchical": { "enabled": false } },
      "physics": { "stabilization": true, "barnesHut": { "springLength": 200 } },
      "edges": { "arrows": { "to": { "enabled": true } }, "color": "#444441", "width": 2, "scaling": { "min": 1, "max": 8 } },
      "nodes": { "font": { "size": 14, "bold": true }, "shape": "box", "borderWidth": 1 }
    }
    """)

    for mod in modules:
        net.add_node(mod, label=f"{mod}.py", color=module_color[mod], size=30)

    for (src_mod, tgt_mod), weight in edge_weights.items():
        net.add_edge(
            src_mod, tgt_mod,
            title=f"{weight} call(s)",   # tooltip shows call count
            value=weight,                # scales edge thickness
        )

    os.makedirs(output_dir, exist_ok=True)
    out = os.path.abspath(os.path.join(output_dir, "diagram_modules.html"))
    net.save_graph(out)
    console.print(f"📊 Module dependency graph → {out}", style="bold yellow")


def generate_3d_visualization(files: list[tuple[str, str]], output_dir: str = "output"):
    """Generates a dynamic 3D architecture map with DIRECTED edges and flowing particles."""
    all_funcs, all_calls = _build_call_graph(files)
    
    # 1. Aggregate cross-module dependencies (Source -> Target)
    edge_weights = {}
    for func, called_set in all_calls.items():
        src_mod = _module_of(func)
        for callee_short in called_set:
            if callee_short in all_funcs:
                for callee_full in all_funcs[callee_short]:
                    tgt_mod = _module_of(callee_full)
                    if tgt_mod != src_mod:
                        key = (src_mod, tgt_mod)
                        edge_weights[key] = edge_weights.get(key, 0) + 1

    if not edge_weights:
        console.print("🌌 No cross-module dependencies found — skipping 3D Code Galaxy", style="bold yellow")
        return

    # 2. Build Nodes using Fibonacci Sphere
    modules = sorted(list(set([m for pair in edge_weights.keys() for m in pair])))
    COLORS = [0x58a6ff, 0x3fb950, 0xd2a8ff, 0xffa657, 0xff7b72, 0x79c0ff, 0x56d364, 0xe3b341]
    nodes_data = []
    radius = max(40, len(modules) * 3.0) 

    for i, mod in enumerate(modules):
        phi = math.acos(1 - 2 * (i + 0.5) / len(modules))
        theta = math.pi * (1 + 5**0.5) * i
        connections = sum(1 for (s, t) in edge_weights.keys() if s == mod or t == mod)
        
        nodes_data.append({
            "id": mod,
            "label": f"{mod}.py",
            "color": COLORS[i % len(COLORS)],
            "pos": [
                round(radius * math.cos(theta) * math.sin(phi), 2),
                round(radius * math.cos(phi), 2),
                round(radius * math.sin(theta) * math.sin(phi), 2)
            ],
            "sz": round(min(max(1.5, connections * 0.5), 5.0), 2),
            "desc": f"{connections} connections."
        })

    # 3. Build Directed Links
    links_data = [{"a": src, "b": tgt, "w": w} for (src, tgt), w in edge_weights.items()]

    import json
    nodes_json = json.dumps(nodes_data)
    links_json = json.dumps(links_data)

    # 4. Generate Legend
    legend_items = []
    for i, mod in enumerate(modules[:8]):
        web_color = "#" + hex(COLORS[i % len(COLORS)])[2:].zfill(6)
        legend_items.append(f'<div class="lrow"><div class="lcube" style="background:{web_color}"></div>{mod}.py</div>')
    legend_html = "".join(legend_items)

    os.makedirs(output_dir, exist_ok=True)

    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<title>GitPutra — Directed 3D Visualization</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box}}
body{{background:#090c14;overflow:hidden;font-family:'Segoe UI',sans-serif;color:#e6edf3}}
#title{{position:fixed;top:20px;left:24px;z-index:10;pointer-events:none}}
#title h1{{font-size:26px;font-weight:700;background:linear-gradient(135deg,#79c0ff,#d2a8ff);-webkit-background-clip:text;-webkit-text-fill-color:transparent}}
#legend{{position:fixed;top:20px;right:24px;background:rgba(13,17,23,0.88);border:1px solid #21262d;border-radius:10px;padding:14px 18px;z-index:10;font-size:12px;min-width:180px}}
.lrow{{display:flex;align-items:center;gap:8px;margin:5px 0}}
.lcube{{width:12px;height:12px;border-radius:2px}}
#tooltip{{position:fixed;display:none;background:rgba(13,17,23,0.95);border:1px solid #30363d;border-radius:8px;padding:10px;font-size:12px;z-index:20;pointer-events:none}}
#controls{{position:fixed;bottom:20px;left:50%;transform:translateX(-50%);display:flex;gap:10px;z-index:10}}
button{{background:rgba(33,38,45,0.9);border:1px solid #30363d;color:#e6edf3;padding:7px 16px;border-radius:6px;font-size:12px;cursor:pointer}}
</style>
</head>
<body>
<div id="title"><h1>◈ Repo Visualization</h1><p>Directed Data Flow — drag to orbit</p></div>
<div id="legend"><h3>Modules</h3>{legend_html}</div>
<div id="tooltip"><strong id="tt-title" style="display:block;margin-bottom:4px"></strong><span id="tt-desc"></span></div>
<div id="controls">
  <button onclick="resetCamera()">⊡ Reset</button>
  <button onclick="toggleSpin()">↻ Auto-spin</button>
  <button onclick="explodeToggle()">💥 Explode</button>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
<script>
const NODES_DATA = {nodes_json};
const LINKS_DATA = {links_json};

const W = window.innerWidth, H = window.innerHeight;
const renderer = new THREE.WebGLRenderer({{antialias:true}});
renderer.setSize(W,H);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
document.body.appendChild(renderer.domElement);

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x090c14);
const camera = new THREE.PerspectiveCamera(55, W/H, 0.1, 1000);
camera.position.set(0, 60, 180);

scene.add(new THREE.AmbientLight(0x404040, 3));
const pL = new THREE.PointLight(0xffffff, 1.5); pL.position.set(50, 80, 80); scene.add(pL);

// Grid Helper
const grid = new THREE.GridHelper(500, 50, 0x1a2040, 0x111820);
grid.position.y = -80;
scene.add(grid);

const meshMap = {{}};
const origPos = {{}};
const particles = [];

// --- OBJECT BUILDER ---
NODES_DATA.forEach(n => {{
    const geo = new THREE.BoxGeometry(n.sz*2.5, n.sz*2.5, n.sz*2.5);
    const mat = new THREE.MeshPhongMaterial({{ color: n.color, emissive: n.color, emissiveIntensity: 0.4, transparent: true, opacity: 0.95 }});
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(...n.pos);
    mesh.userData = {{ id: n.id, label: n.label, desc: n.desc, color: n.color }};
    scene.add(mesh);
    meshMap[n.id] = mesh;
    origPos[n.id] = [...n.pos];

    // Wireframe
    mesh.add(new THREE.LineSegments(new THREE.EdgesGeometry(geo), new THREE.LineBasicMaterial({{color: n.color, opacity: 0.7}})));

    // Label Sprite
    const canvas = document.createElement("canvas");
    canvas.width = 256; canvas.height = 64;
    const ctx = canvas.getContext("2d");
    ctx.font = "bold 24px Segoe UI, Arial";
    ctx.fillStyle = "#ffffff";
    ctx.textAlign = "center";
    ctx.fillText(n.label, 128, 40);
    const sprite = new THREE.Sprite(new THREE.SpriteMaterial({{map: new THREE.CanvasTexture(canvas), transparent: true}}));
    sprite.scale.set(12, 3, 1);
    sprite.position.set(0, n.sz * 2 + 4, 0);
    mesh.add(sprite);
}});

// --- EDGE & ARROW BUILDER ---
const edgeGroup = new THREE.Group();
scene.add(edgeGroup);

function buildEdges() {{
    while(edgeGroup.children.length > 0){{ edgeGroup.remove(edgeGroup.children[0]); }}
    
    LINKS_DATA.forEach(l => {{
        const m1 = meshMap[l.a], m2 = meshMap[l.b];
        if(!m1 || !m2) return;
        
        const start = m1.position;
        const end = m2.position;

        // The Line
        const geo = new THREE.BufferGeometry().setFromPoints([start, end]);
        const line = new THREE.Line(geo, new THREE.LineBasicMaterial({{color: m1.userData.color, transparent: true, opacity: 0.25}}));
        edgeGroup.add(line);

        // --- DIRECTED ARROWHEAD ---
        const dir = new THREE.Vector3().subVectors(end, start).normalize();
        const arrowLen = 4;
        const arrowGeo = new THREE.ConeGeometry(1.5, arrowLen, 8);
        const arrowMat = new THREE.MeshBasicMaterial({{color: m1.userData.color}});
        const arrow = new THREE.Mesh(arrowGeo, arrowMat);
        
        // Position arrow slightly before the target box
        const arrowPos = end.clone().sub(dir.clone().multiplyScalar(m2.geometry.parameters.width / 1.5 + 2));
        arrow.position.copy(arrowPos);
        arrow.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir);
        edgeGroup.add(arrow);
    }});
}}

// --- PARTICLE SYSTEM (Data Flow) ---
LINKS_DATA.forEach(l => {{
    const pGeo = new THREE.SphereGeometry(0.6, 6, 6);
    const pMat = new THREE.MeshBasicMaterial({{color: 0xffffff}});
    const p = new THREE.Mesh(pGeo, pMat);
    p.userData = {{ link: l, t: Math.random() }}; // Random start phase
    scene.add(p);
    particles.push(p);
}});

let theta = 0, phi = Math.PI/6, radius = 220, isDragging = false, prevX = 0, prevY = 0, spinning = true;
function updateCam() {{
    camera.position.set(radius * Math.sin(theta) * Math.cos(phi), radius * Math.sin(phi), radius * Math.cos(theta) * Math.cos(phi));
    camera.lookAt(0,0,0);
}}

window.addEventListener("mousedown", e => {{ isDragging=true; prevX=e.clientX; prevY=e.clientY; spinning=false; }});
window.addEventListener("mouseup", () => isDragging=false);
window.addEventListener("mousemove", e => {{
    if(isDragging) {{
        theta -= (e.clientX - prevX) * 0.007; phi += (e.clientY - prevY) * 0.007;
        phi = Math.max(-Math.PI/2.2, Math.min(Math.PI/2.2, phi));
        prevX=e.clientX; prevY=e.clientY;
    }}
    const mouse = new THREE.Vector2((e.clientX/W)*2-1, -(e.clientY/H)*2+1);
    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(mouse, camera);
    const hits = raycaster.intersectObjects(Object.values(meshMap));
    const tt = document.getElementById("tooltip");
    if(hits.length > 0) {{
        const obj = hits[0].object;
        tt.style.display = "block"; tt.style.left = (e.clientX+15)+"px"; tt.style.top = (e.clientY-10)+"px";
        document.getElementById("tt-title").innerText = obj.userData.label;
        document.getElementById("tt-desc").innerText = obj.userData.desc;
    }} else {{ tt.style.display = "none"; }}
}});
window.addEventListener("wheel", e => {{ radius = Math.max(50, Math.min(600, radius + e.deltaY*0.1)); }});

function resetCamera() {{ theta=0; phi=Math.PI/6; radius=220; spinning=true; }}
function toggleSpin() {{ spinning = !spinning; }}
let exploded = false;
function explodeToggle() {{
    exploded = !exploded;
    NODES_DATA.forEach(n => {{
        const m = meshMap[n.id];
        const mult = exploded ? 2.5 : 1;
        m.userData.targetPos = [origPos[n.id][0]*mult, origPos[n.id][1]*mult, origPos[n.id][2]*mult];
    }});
}}

function animate() {{
    requestAnimationFrame(animate);
    if(spinning) theta += 0.004;
    updateCam();

    NODES_DATA.forEach(n => {{
        const m = meshMap[n.id];
        if(m.userData.targetPos) {{
            m.position.x += (m.userData.targetPos[0] - m.position.x) * 0.1;
            m.position.y += (m.userData.targetPos[1] - m.position.y) * 0.1;
            m.position.z += (m.userData.targetPos[2] - m.position.z) * 0.1;
        }}
    }});

    // Update Particles
    particles.forEach(p => {{
        const l = p.userData.link;
        const m1 = meshMap[l.a], m2 = meshMap[l.b];
        if(!m1 || !m2) return;
        p.userData.t += 0.005 * (l.w || 1); // Speed based on weight
        if(p.userData.t > 1) p.userData.t = 0;
        p.position.lerpVectors(m1.position, m2.position, p.userData.t);
        p.material.color.set(m1.userData.color); // Particle takes color of source
    }});

    buildEdges();
    renderer.render(scene, camera);
}}
animate();
window.addEventListener("resize", () => {{ renderer.setSize(window.innerWidth, window.innerHeight); camera.aspect = window.innerWidth/window.innerHeight; camera.updateProjectionMatrix(); }});
</script>
</body>
</html>"""

    html_path = os.path.join(output_dir, "diagram_3d_visualization.html")
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html_content)
    console.print(f"🌌 3D Visualization Map → {os.path.abspath(html_path)}", style="bold magenta")

def generate_semantic_3d(output_dir: str = "output"):
    """Generates the hardcoded GitPutra 3D architecture using the custom Three.js UI."""
    os.makedirs(output_dir, exist_ok=True)
    
    html_content = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<title>GitPutra — RAG Pipeline</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:#090c14;overflow:hidden;font-family:'Segoe UI',system-ui,sans-serif;color:#e6edf3}
canvas{display:block}
#hud{position:fixed;top:0;left:0;width:100%;height:100%;pointer-events:none}
#title{position:fixed;top:20px;left:24px;z-index:10}
#title h1{font-size:26px;font-weight:700;letter-spacing:-0.5px;background:linear-gradient(135deg,#79c0ff,#d2a8ff);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
#title p{font-size:12px;color:#8b949e;margin-top:3px}
#legend{position:fixed;top:20px;right:24px;background:rgba(13,17,23,0.88);border:1px solid #21262d;border-radius:10px;padding:14px 18px;z-index:10;font-size:12px;min-width:180px}
#legend h3{font-size:12px;font-weight:600;color:#8b949e;text-transform:uppercase;letter-spacing:1px;margin-bottom:10px}
.lrow{display:flex;align-items:center;gap:8px;margin:5px 0;color:#c9d1d9;font-size:12px}
.lcube{width:12px;height:12px;border-radius:2px;flex-shrink:0}
#tooltip{position:fixed;display:none;background:rgba(13,17,23,0.95);border:1px solid #30363d;border-radius:8px;padding:10px 14px;font-size:12px;z-index:20;max-width:240px;pointer-events:none}
#tooltip strong{display:block;font-size:13px;color:#f0f6fc;margin-bottom:4px}
#tooltip span{color:#8b949e;line-height:1.6}
#controls{position:fixed;bottom:20px;left:50%;transform:translateX(-50%);display:flex;gap:10px;z-index:10}
button{background:rgba(33,38,45,0.9);border:1px solid #30363d;color:#e6edf3;padding:7px 16px;border-radius:6px;font-size:12px;cursor:pointer;transition:all .15s;pointer-events:all}
button:hover{background:#30363d;border-color:#58a6ff}
#fps{position:fixed;bottom:20px;right:24px;font-size:11px;color:#30363d;z-index:10}
</style>
</head>
<body>
<div id="title">
  <h1>◈ GitPutra Visualization</h1>
  <p>RAG Pipeline & Data Flow — drag to orbit</p>
</div>
<div id="legend">
  <h3>Pipeline Stages</h3>
  <div class="lrow"><div class="lcube" style="background:#58a6ff"></div>Ingestion</div>
  <div class="lrow"><div class="lcube" style="background:#d2a8ff"></div>AI Processing</div>
  <div class="lrow"><div class="lcube" style="background:#3fb950"></div>Vector DB</div>
  <div class="lrow"><div class="lcube" style="background:#ff7b72"></div>Retrieval Engine</div>
  <div class="lrow"><div class="lcube" style="background:#e3b341"></div>User Interface</div>
</div>
<div id="tooltip"><strong id="tt-title"></strong><span id="tt-desc"></span></div>
<div id="controls">
  <button onclick="resetCamera()">⊡ Reset View</button>
  <button onclick="toggleSpin()">↻ Auto-spin</button>
  <button onclick="toggleEdges()">⟳ Edges</button>
  <button onclick="explodeToggle()">💥 Explode</button>
</div>
<div id="fps"></div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
<script>
const W = window.innerWidth, H = window.innerHeight;
const renderer = new THREE.WebGLRenderer({antialias:true,alpha:false});
renderer.setSize(W,H);
renderer.setPixelRatio(Math.min(devicePixelRatio,2));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
document.body.appendChild(renderer.domElement);

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x090c14);
scene.fog = new THREE.Fog(0x090c14, 60, 160);

const camera = new THREE.PerspectiveCamera(55, W/H, 0.1, 300);
camera.position.set(0, 30, 60);
camera.lookAt(0,0,0);

scene.add(new THREE.AmbientLight(0x1a2040, 1.8));
const dirL = new THREE.DirectionalLight(0x7090ff, 1.2); dirL.position.set(10,20,15); dirL.castShadow = true; scene.add(dirL);
const ptL1 = new THREE.PointLight(0x58a6ff, 1.5, 80); ptL1.position.set(-20,10,10); scene.add(ptL1);
const ptL2 = new THREE.PointLight(0xd2a8ff, 1.2, 80); ptL2.position.set(20,-10,10); scene.add(ptL2);

// --- HARDCODED GITPUTRA RAG PIPELINE ---
const NODES = [
  {id:"repo",      label:"1. GitHub Repo",        color:0x58a6ff, pos:[-30, 15, -10], sz:1.8, desc:"Target repository providing source code files."},
  {id:"scanner",   label:"2. File Scanner",       color:0x58a6ff, pos:[-15, 15, -10], sz:1.4, desc:"Traverses directory tree, applies SKIP_DIRS, and extracts text."},
  {id:"chunker",   label:"3. Dependency Chunker", color:0x58a6ff, pos:[  0, 15, -10], sz:1.6, desc:"Splits large files at AST boundaries and groups by extension."},
  {id:"embedder",  label:"4. Embedding Model",    color:0xd2a8ff, pos:[ 15,  5, -20], sz:1.6, desc:"Gemini/OpenAI turns code chunks into dense vector embeddings."},
  {id:"db",        label:"5. ChromaDB",           color:0x3fb950, pos:[ 15,-10, -20], sz:2.2, desc:"Persistent local storage for vector embeddings and document metadata."},
  {id:"query",     label:"6. User Chat Query",    color:0xe3b341, pos:[-20,-10,  15], sz:1.6, desc:"Natural language question from the user terminal."},
  {id:"retriever", label:"7. Hybrid Retriever",   color:0xff7b72, pos:[  0,-10,   0], sz:2.0, desc:"Reciprocal Rank Fusion of BM25 (keyword) and Vector (semantic) searches."},
  {id:"llm",       label:"8. LLM Generator",      color:0xd2a8ff, pos:[ 20,-10,  15], sz:2.0, desc:"Synthesizes the final answer using retrieved context + chat history."},
  {id:"output",    label:"9. Final Response",     color:0xe3b341, pos:[ 35,-10,  15], sz:1.8, desc:"Streamed back to the rich terminal UI."}
];

const EDGES = [
  ["repo","scanner"],
  ["scanner","chunker"],
  ["chunker","embedder"],
  ["chunker","db"], // Hash check
  ["embedder","db"],
  ["query","embedder"],
  ["query","retriever"],
  ["db","retriever"],
  ["retriever","llm"],
  ["query","llm"],
  ["llm","output"]
];

const meshMap = {}; const origPos = {};
NODES.forEach(n => {
  const geo = new THREE.BoxGeometry(n.sz*2, n.sz*2, n.sz*2, 1, 1, 1);
  const mat = new THREE.MeshPhongMaterial({ color: n.color, emissive: n.color, emissiveIntensity: 0.18, shininess: 80, transparent: true, opacity: 0.92 });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.set(...n.pos); mesh.castShadow = true; mesh.receiveShadow = true;
  mesh.userData = {id:n.id, label:n.label, desc:n.desc, color:n.color, basePos:[...n.pos]};
  scene.add(mesh); meshMap[n.id] = mesh; origPos[n.id] = [...n.pos];

  const wgeo = new THREE.EdgesGeometry(geo);
  mesh.add(new THREE.LineSegments(wgeo, new THREE.LineBasicMaterial({color:n.color, transparent:true, opacity:0.5})));

  const canvas2 = document.createElement("canvas"); canvas2.width = 64; canvas2.height = 64;
  const ctx2 = canvas2.getContext("2d"); const grad = ctx2.createRadialGradient(32,32,0,32,32,32);
  const hex = "#"+n.color.toString(16).padStart(6,"0");
  grad.addColorStop(0, hex+"88"); grad.addColorStop(1, hex+"00");
  ctx2.fillStyle = grad; ctx2.fillRect(0,0,64,64);
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(canvas2),transparent:true,depthWrite:false}));
  sprite.scale.set(n.sz*7, n.sz*7, 1); mesh.add(sprite);

  const lc = document.createElement("canvas"); lc.width = 256; lc.height = 48;
  const lctx = lc.getContext("2d"); lctx.fillStyle = "rgba(13,17,23,0.7)"; lctx.roundRect(2,2,252,44,6); lctx.fill();
  lctx.font = "bold 18px Segoe UI, sans-serif"; lctx.fillStyle = "#f0f6fc"; lctx.textAlign = "center"; lctx.textBaseline = "middle"; lctx.fillText(n.label, 128, 24);
  const ls = new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(lc),transparent:true,depthWrite:false}));
  ls.scale.set(8, 1.5, 1); ls.position.set(0, n.sz + 1.8, 0); mesh.add(ls);
});

const edgeMeshes = [];
function buildEdges() {
  edgeMeshes.forEach(e => scene.remove(e)); edgeMeshes.length = 0;
  EDGES.forEach(([a,b]) => {
    const ma = meshMap[a], mb = meshMap[b]; if (!ma || !mb) return;
    const geo = new THREE.BufferGeometry().setFromPoints([ma.position.clone(), mb.position.clone()]);
    const col = new THREE.Color(ma.userData.color).lerp(new THREE.Color(mb.userData.color), 0.5);
    const line = new THREE.Line(geo, new THREE.LineBasicMaterial({color:col, transparent:true, opacity:0.35, linewidth:1}));
    scene.add(line); edgeMeshes.push(line);
  });
}
buildEdges();

const gridHelper = new THREE.GridHelper(100, 25, 0x1a2040, 0x111820); gridHelper.position.y = -20; scene.add(gridHelper);

const raycaster = new THREE.Raycaster(); const mouse = new THREE.Vector2(); let hovered = null;
const tooltip = document.getElementById("tooltip");
window.addEventListener("mousemove", e => {
  mouse.x = (e.clientX/W)*2-1; mouse.y = -(e.clientY/H)*2+1;
  tooltip.style.left = (e.clientX+14)+"px"; tooltip.style.top  = (e.clientY-10)+"px";
  raycaster.setFromCamera(mouse, camera); const hits = raycaster.intersectObjects(Object.values(meshMap));
  if (hits.length > 0) {
    const obj = hits[0].object;
    if (hovered !== obj) {
      if (hovered) hovered.material.emissiveIntensity = 0.18;
      hovered = obj; hovered.material.emissiveIntensity = 0.55;
      document.getElementById("tt-title").textContent = obj.userData.label;
      document.getElementById("tt-desc").textContent = obj.userData.desc;
      tooltip.style.display = "block";
    }
  } else {
    if (hovered) { hovered.material.emissiveIntensity = 0.18; hovered = null; }
    tooltip.style.display = "none";
  }
});

let isDragging = false, prevX = 0, prevY = 0; let theta = 0, phi = Math.PI/6, radius = 70; let spinning = true;
function camFromSphere() {
  camera.position.set(radius * Math.sin(theta) * Math.cos(phi), radius * Math.sin(phi), radius * Math.cos(theta) * Math.cos(phi));
  camera.lookAt(0,0,0);
}

renderer.domElement.addEventListener("mousedown", e => { isDragging=true; prevX=e.clientX; prevY=e.clientY; spinning=false; });
window.addEventListener("mouseup", () => isDragging=false);
window.addEventListener("mousemove", e => {
  if (!isDragging) return;
  theta -= (e.clientX-prevX)*0.008; phi += (e.clientY-prevY)*0.008;
  phi = Math.max(-Math.PI/2.2, Math.min(Math.PI/2.2, phi));
  prevX=e.clientX; prevY=e.clientY; camFromSphere();
});
renderer.domElement.addEventListener("wheel", e => { radius = Math.max(15, Math.min(150, radius + e.deltaY*0.05)); camFromSphere(); });

function resetCamera() { theta=0; phi=Math.PI/6; radius=70; camFromSphere(); spinning=true; }
function toggleSpin() { spinning=!spinning; }
let edgesVisible = true; function toggleEdges() { edgesVisible = !edgesVisible; edgeMeshes.forEach(e => e.visible = edgesVisible); }
let exploded = false; function explodeToggle() {
  exploded = !exploded;
  NODES.forEach(n => {
    const m = meshMap[n.id]; const base = origPos[n.id];
    m.userData.targetPos = exploded ? [base[0]*1.8, base[1]*1.8, base[2]*1.8] : [...base];
  });
}

let lastT = 0, frameCount = 0, lastFPS = performance.now(); const clock = new THREE.Clock();
function animate() {
  requestAnimationFrame(animate); const t = clock.getElapsedTime(); const dt = t - lastT; lastT = t;
  if (spinning && !isDragging) { theta += 0.003; camFromSphere(); }
  NODES.forEach((n,i) => {
    const m = meshMap[n.id];
    if (m.userData.targetPos) {
      m.position.x += (m.userData.targetPos[0] - m.position.x) * 0.08; m.position.y += (m.userData.targetPos[1] - m.position.y) * 0.08; m.position.z += (m.userData.targetPos[2] - m.position.z) * 0.08;
    }
    m.position.y += Math.sin(t * 0.6 + i * 0.9) * 0.12 * dt; m.rotation.y = t * 0.15 + i * 0.4; m.rotation.x = Math.sin(t * 0.08 + i) * 0.06;
  });
  buildEdges();
  ptL1.intensity = 1.2 + Math.sin(t * 1.3) * 0.4; ptL2.intensity = 1.0 + Math.sin(t * 0.9 + 1) * 0.4;
  renderer.render(scene, camera);
  frameCount++; if (performance.now() - lastFPS > 1000) { document.getElementById("fps").textContent = frameCount + " fps"; frameCount = 0; lastFPS = performance.now(); }
}
animate();
window.addEventListener("resize", () => { camera.aspect = window.innerWidth/window.innerHeight; camera.updateProjectionMatrix(); renderer.setSize(window.innerWidth, window.innerHeight); });
</script>
</body>
</html>"""
    
    html_path = os.path.join(output_dir, "project_visualization.html")
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html_content)
        
    console.print(f"🌌 3D Semantic Visualization → {os.path.abspath(html_path)}", style="bold cyan")

# ─────────────────────────────────────────────────────────────────────────────
# MERMAID — ALIASES & HEADERS
# ─────────────────────────────────────────────────────────────────────────────

_MERMAID_ALIASES: dict[str, str] = {
    "1": "graph",           "graph": "graph",
    "call graph": "graph",  "dependency": "graph",      "dep graph": "graph",
    "2": "flowchart",       "flowchart": "flowchart",
    "flow": "flowchart",    "flow chart": "flowchart",
    "3": "flowchart_lr",    "flowchart lr": "flowchart_lr",
    "horizontal": "flowchart_lr", "lr": "flowchart_lr",
    "4": "architecture",    "architecture": "architecture",
    "arch": "architecture", "module": "architecture",   "modules": "architecture",
    "5": "sequence",        "sequence": "sequence",
    "seq": "sequence",      "sequence diagram": "sequence",
    "6": "class",           "class": "class",
    "class diagram": "class", "uml": "class",
    "7": "gitgraph",        "gitgraph": "gitgraph",
    "git": "gitgraph",      "git graph": "gitgraph",    "git timeline": "gitgraph",
}

_MERMAID_HEADERS: dict[str, str | None] = {
    "graph":        "graph TD",
    "flowchart":    "flowchart TD",
    "flowchart_lr": "flowchart LR",
    "architecture": None,
    "sequence":     None,
    "class":        None,
    "gitgraph":     None,
}

_MERMAID_MENU = [
    {"key": "1", "type": "graph",        "icon": "◈", "label": "Call Graph",
     "desc": "Node per function, edges = calls.\nBest for: tracing execution paths."},
    {"key": "2", "type": "flowchart",    "icon": "⬇", "label": "Flowchart  (TD)",
     "desc": "Top-down flow with decision boxes.\nBest for: control flow visualisation."},
    {"key": "3", "type": "flowchart_lr", "icon": "➡", "label": "Flowchart  (LR)",
     "desc": "Left-to-right horizontal flow.\nBest for: pipeline / data-flow diagrams."},
    {"key": "4", "type": "architecture", "icon": "⬡", "label": "Architecture",
     "desc": "Subgraph per module + cross-module edges.\nBest for: high-level system overview."},
    {"key": "5", "type": "sequence",     "icon": "⇄", "label": "Sequence",
     "desc": "Participant per module, messages = calls.\nBest for: runtime interaction timelines."},
    {"key": "6", "type": "class",        "icon": "▣", "label": "Class / UML",
     "desc": "Class per module, methods listed inside.\nBest for: OOP structure / API surface."},
    {"key": "7", "type": "gitgraph",     "icon": "⎇", "label": "Git Timeline",
     "desc": "Branch structure + last N commits.\nBest for: visualising repo history."},
]


# ─────────────────────────────────────────────────────────────────────────────
# MERMAID — INTERACTIVE MENU
# ─────────────────────────────────────────────────────────────────────────────

def _mermaid_show_menu() -> None:
    from rich.panel import Panel
    from rich.columns import Columns

    console.print()
    console.print(Align(
        Text("◈  GitPutra  —  Choose Diagram Type  ◈", style="bold magenta", justify="center"),
        align="center",
    ))
    console.print()

    for row in (_MERMAID_MENU[:3], _MERMAID_MENU[3:]):
        cards = []
        for e in row:
            body = Text(justify="left")
            body.append(f"[{e['key']}] ", style="bold white")
            body.append(f"{e['icon']}  {e['label']}\n", style="bold cyan")
            body.append(e["desc"], style="dim italic")
            cards.append(Panel(body, border_style="dim", padding=(0, 1), expand=True))
        console.print(Columns(cards, equal=True, expand=True))
        console.print()

    console.print(
        "  Enter [bold cyan]number (1–7)[/bold cyan], "
        "[bold cyan]type name[/bold cyan] (e.g. gitgraph), "
        "or [bold cyan]Enter[/bold cyan] for default (graph):\n",
        style="dim",
    )


def _mermaid_prompt_type(default: str = "graph") -> str:
    from rich.prompt import Prompt

    _mermaid_show_menu()
    try:
        choice = Prompt.ask(
            "  [bold cyan]diagram[/bold cyan]",
            default="",
            show_default=False,
            console=console,
        ).strip().lower()
    except (KeyboardInterrupt, EOFError):
        console.print("\n  Using default: graph\n", style="dim")
        return default

    if not choice:
        return default

    resolved = _MERMAID_ALIASES.get(choice)
    if resolved:
        console.print(f"\n  ✅ Selected: [bold cyan]{resolved}[/bold cyan]\n")
        return resolved

    console.print(f"  ⚠️  Unknown type '{choice}' — using [bold yellow]{default}[/bold yellow]\n")
    return default


# ─────────────────────────────────────────────────────────────────────────────
# MERMAID — BUILDERS  (all use the existing _build_call_graph from this file)
# ─────────────────────────────────────────────────────────────────────────────

def _mermaid_build_graph(files, header: str) -> str | None:
    all_funcs, all_calls = _build_call_graph(files)
    lines, seen = [header], set()

    for func, called_set in all_calls.items():
        for callee_short in called_set:
            if callee_short not in all_funcs:
                continue
            for callee_full in all_funcs[callee_short]:
                if callee_full == func:
                    continue
                edge = f"    {_clean(func)} --> {_clean(callee_full)}"
                if edge not in seen:
                    lines.append(edge)
                    seen.add(edge)

    return "\n".join(lines) if len(lines) > 1 else None


def _mermaid_build_architecture(files) -> str | None:
    all_funcs, all_calls = _build_call_graph(files)

    modules: dict[str, list[str]] = {}
    for full_name in all_calls:
        mod = full_name.rsplit(".", 1)[0]
        modules.setdefault(mod, []).append(full_name)

    lines = ["graph TD"]
    for mod, funcs in sorted(modules.items()):
        lines.append(f"    subgraph {_clean(mod)}[\"{mod}\"]")
        for fn in funcs:
            lines.append(f"        {_clean(fn)}[\"{fn.split('.')[-1]}\"]")
        lines.append("    end")

    seen = set()
    for func, called_set in all_calls.items():
        src_mod = func.rsplit(".", 1)[0]
        for callee_short in called_set:
            if callee_short not in all_funcs:
                continue
            for callee_full in all_funcs[callee_short]:
                if callee_full == func:
                    continue
                if callee_full.rsplit(".", 1)[0] != src_mod:
                    edge = f"    {_clean(func)} --> {_clean(callee_full)}"
                    if edge not in seen:
                        lines.append(edge)
                        seen.add(edge)

    return "\n".join(lines) if len(lines) > 2 else None


def _mermaid_build_sequence(files) -> str | None:
    all_funcs, all_calls = _build_call_graph(files)

    participants, seen_p, messages, seen_m = [], set(), [], set()

    for func, called_set in all_calls.items():
        src_mod = func.rsplit(".", 1)[0]
        if src_mod not in seen_p:
            participants.append(src_mod)
            seen_p.add(src_mod)

        for callee_short in called_set:
            if callee_short not in all_funcs:
                continue
            for callee_full in all_funcs[callee_short]:
                if callee_full == func:
                    continue
                tgt_mod = callee_full.rsplit(".", 1)[0]
                if tgt_mod not in seen_p:
                    participants.append(tgt_mod)
                    seen_p.add(tgt_mod)
                label = f"{func.split('.')[-1]}() → {callee_full.split('.')[-1]}()"
                msg = f"    {src_mod}->>+{tgt_mod}: {label}"
                if msg not in seen_m:
                    messages.append(msg)
                    seen_m.add(msg)

    if not messages:
        return None

    lines = ["sequenceDiagram"]
    lines += [f"    participant {p}" for p in participants]
    lines += messages
    return "\n".join(lines)


def _mermaid_build_class(files) -> str | None:
    all_funcs, all_calls = _build_call_graph(files)

    modules: dict[str, list[str]] = {}
    for full_name in all_calls:
        mod = full_name.rsplit(".", 1)[0]
        modules.setdefault(mod, []).append(full_name.split(".")[-1])

    lines = ["classDiagram"]
    for mod, funcs in sorted(modules.items()):
        lines.append(f"    class {_clean(mod)} {{")
        for fn in funcs[:12]:
            lines.append(f"        +{fn}()")
        lines.append("    }")

    seen = set()
    for func, called_set in all_calls.items():
        src = _clean(func.rsplit(".", 1)[0])
        for callee_short in called_set:
            if callee_short not in all_funcs:
                continue
            for callee_full in all_funcs[callee_short]:
                tgt = _clean(callee_full.rsplit(".", 1)[0])
                if tgt != src:
                    rel = f"    {src} ..> {tgt} : uses"
                    if rel not in seen:
                        lines.append(rel)
                        seen.add(rel)

    return "\n".join(lines) if len(lines) > 1 else None


# ─────────────────────────────────────────────────────────────────────────────
# MERMAID — GIT GRAPH BUILDER
# ─────────────────────────────────────────────────────────────────────────────

def _mermaid_build_gitgraph(repo_path: str, max_commits: int = 30) -> str | None:
    """Build a Mermaid gitGraph diagram from the repo's commit history."""
    try:
        # search_parent_directories=True walks up to find the .git root,
        # so passing a subdirectory of the repo works correctly.
        repo = Repo(repo_path, search_parent_directories=True)
    except Exception as e:
        console.print(f"⚠️  Could not find a git repo at or above {repo_path}: {e}", style="bold red")
        return None

    # ── collect branch refs ──────────────────────────────────────────────────
    try:
        branches = list(repo.branches)
    except Exception:
        branches = []

    if not branches:
        console.print("⚠️  No branches found in repo.", style="bold yellow")
        return None

    branch_names = [b.name for b in branches]

    # Prefer main/master regardless of what's currently checked out,
    # since the active branch may be a feature/bugfix branch locally.
    _PRIMARY = ["main", "master", "develop", "dev"]
    default_branch = next((n for n in _PRIMARY if n in branch_names), None)
    if default_branch is None:
        # Fall back to active branch, then first branch
        try:
            default_branch = repo.active_branch.name
        except TypeError:
            default_branch = branch_names[0]

    # ── walk commits per branch ──────────────────────────────────────────────
    # Collect commits reachable from each branch, up to max_commits each.
    # We track which SHAs we've already emitted on the default branch so we
    # know where feature branches diverge.

    def _safe_msg(commit) -> str:
        msg = commit.message.strip().splitlines()[0][:50]
        # Mermaid gitGraph doesn't allow quotes in commit ids/messages
        return msg.replace('"', "'").replace(":", " -")

    def _branch_commits(branch_ref, limit: int) -> list:
        try:
            return list(repo.iter_commits(branch_ref, max_count=limit, first_parent=True))
        except Exception:
            return []

    default_commits = _branch_commits(default_branch, max_commits)
    if not default_commits:
        console.print("⚠️  No commits found.", style="bold yellow")
        return None

    default_shas = {c.hexsha for c in default_commits}

    lines = [f'gitGraph LR']

    # ── emit default branch ──────────────────────────────────────────────────
    # Walk oldest→newest for natural left-to-right timeline
    for commit in reversed(default_commits):
        sha = commit.hexsha[:7]
        msg = _safe_msg(commit)
        lines.append(f'   commit id: "{sha} {msg}"')

    # ── emit feature branches ────────────────────────────────────────────────
    for branch in branches:
        if branch.name == default_branch:
            continue

        branch_commits = _branch_commits(branch.name, max_commits)
        if not branch_commits:
            continue

        # Find the divergence point — the newest commit on this branch
        # that also exists on the default branch.
        diverge_sha = None
        for commit in branch_commits:
            if commit.hexsha in default_shas:
                diverge_sha = commit.hexsha[:7]
                break

        # Only include commits that are NOT on the default branch
        unique_commits = [c for c in branch_commits if c.hexsha not in default_shas]
        if not unique_commits:
            continue

        checkout_target = diverge_sha if diverge_sha else default_commits[-1].hexsha[:7]
        lines.append(f'   checkout "{default_branch}"')  # no-op but keeps Mermaid happy
        lines.append(f'   branch "{branch.name}"')
        lines.append(f'   checkout "{branch.name}"')

        for commit in reversed(unique_commits):
            sha = commit.hexsha[:7]
            msg = _safe_msg(commit)
            lines.append(f'   commit id: "{sha} {msg}"')

    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# TERMINAL GIT GRAPH RENDERER
# ─────────────────────────────────────────────────────────────────────────────

# One color per branch, cycles if more branches than colors
_BRANCH_COLORS = [
    "bold cyan", "bold green", "bold yellow",
    "bold magenta", "bold blue", "bold red",
]

def render_gitgraph_terminal(repo_path: str, max_commits: int = 30) -> None:
    """Render a git branch timeline directly in the terminal using Rich."""
    from rich.table import Table as RichTable
    from rich.text import Text

    try:
        repo = Repo(repo_path, search_parent_directories=True)
    except Exception as e:
        console.print(f"❌ Could not open repo: {e}", style="bold red")
        return

    try:
        branches = list(repo.branches)
    except Exception:
        console.print("❌ No branches found.", style="bold red")
        return

    branch_names = [b.name for b in branches]
    _PRIMARY = ["main", "master", "develop", "dev"]
    default_branch = next((n for n in _PRIMARY if n in branch_names), None) or branch_names[0]

    def _branch_commits(name, limit):
        try:
            return list(repo.iter_commits(name, max_count=limit, first_parent=True))
        except Exception:
            return []

    def _safe_msg(commit) -> str:
        msg = commit.message.strip().splitlines()[0][:55]
        # Escape [ ] so Rich doesn't interpret commit messages as markup/links
        return msg.replace("[", "(").replace("]", ")")

    default_commits = list(reversed(_branch_commits(default_branch, max_commits)))  # oldest→newest
    if not default_commits:
        console.print("⚠️  No commits found.", style="bold yellow")
        return

    default_shas = {c.hexsha for c in default_commits}

    # ── collect feature branches ─────────────────────────────────────────────
    feature_branches: list[dict] = []
    for b in branches:
        if b.name == default_branch:
            continue
        commits = _branch_commits(b.name, max_commits)
        unique = list(reversed([c for c in commits if c.hexsha not in default_shas]))  # oldest→newest
        if not unique:
            continue
        diverge = next((c for c in commits if c.hexsha in default_shas), None)
        feature_branches.append({
            "name":        b.name,
            "unique":      unique,
            "diverge_sha": diverge.hexsha if diverge else None,
        })

    # ── assign colors ────────────────────────────────────────────────────────
    all_lane_names = [default_branch] + [f["name"] for f in feature_branches]
    branch_color: dict[str, str] = {}
    for i, name in enumerate(all_lane_names):
        branch_color[name] = _BRANCH_COLORS[i % len(_BRANCH_COLORS)]

    # ── index feature branches by divergence SHA ─────────────────────────────
    diverge_index: dict[str, list[dict]] = {}
    for fd in feature_branches:
        key = fd["diverge_sha"] or "__none__"
        diverge_index.setdefault(key, []).append(fd)

    # ── build rows: main is the unbroken spine ───────────────────────────────
    # Strategy:
    #   1. Walk all main commits oldest→newest (spine)
    #   2. After each main commit that is a divergence point, insert that
    #      feature branch's unique commits as an indented block
    #   3. Then continue with the next main commit
    # This means main is never interrupted — it flows top to bottom in order,
    # and feature branches hang off their divergence point.

    # Row types:
    #   "main"    → ●─  on the main spine
    #   "branch"  → ├─● indented feature commit
    #   "divider" → │   blank connector between feature block and next main

    rows = []

    for commit in default_commits:
        sha = commit.hexsha

        # emit main commit
        rows.append({
            "type":  "main",
            "sha":   sha[:7],
            "msg":   _safe_msg(commit),
            "date":  commit.committed_datetime.strftime("%Y-%m-%d"),
            "auth":  commit.author.name[:18],
            "owner": default_branch,
        })

        # if this is a divergence point, emit the feature branch block
        if sha in diverge_index:
            for fd in diverge_index[sha]:
                bname  = fd["name"]
                bcolor = branch_color[bname]
                unique = fd["unique"]
                for j, fc in enumerate(unique):
                    is_last = (j == len(unique) - 1)
                    rows.append({
                        "type":    "branch",
                        "sha":     fc.hexsha[:7],
                        "msg":     _safe_msg(fc),
                        "date":    fc.committed_datetime.strftime("%Y-%m-%d"),
                        "auth":    fc.author.name[:18],
                        "owner":   bname,
                        "is_last": is_last,
                        "bcolor":  bcolor,
                        "mcolor":  branch_color[default_branch],
                    })

    # feature branches with no divergence point in our window → append at end
    for fd in diverge_index.get("__none__", []):
        bname  = fd["name"]
        bcolor = branch_color[bname]
        for j, fc in enumerate(fd["unique"]):
            is_last = (j == len(fd["unique"]) - 1)
            rows.append({
                "type":    "branch",
                "sha":     fc.hexsha[:7],
                "msg":     _safe_msg(fc),
                "date":    fc.committed_datetime.strftime("%Y-%m-%d"),
                "auth":    fc.author.name[:18],
                "owner":   bname,
                "is_last": is_last,
                "bcolor":  bcolor,
                "mcolor":  branch_color[default_branch],
            })

    # ── render ───────────────────────────────────────────────────────────────
    console.print()
    console.print(f"  ⎇  [bold magenta]Git Timeline — {repo.working_dir}[/bold magenta]")
    console.print()

    legend = Text("  Branches: ")
    for name in all_lane_names:
        legend.append(f"● {name}  ", style=branch_color[name])
    console.print(legend)
    console.print()

    # ── calculate available width for message column ─────────────────────────
    term_width = console.width or 120
    # fixed columns: Graph(6) + SHA(9) + Date(12) + Author(20) + padding(10)
    fixed_width = 6 + 9 + 12 + 20 + 10
    msg_width = max(10, term_width - fixed_width)

    table = RichTable(show_header=True, header_style="bold dim", box=None, padding=(0, 1))
    table.add_column("Graph",   no_wrap=True)
    table.add_column("SHA",     no_wrap=True)
    table.add_column("Date",    no_wrap=True)
    table.add_column("Author",  no_wrap=True)
    table.add_column("Message", no_wrap=True, max_width=msg_width)

    def _fit(msg: str) -> str:
        return msg if len(msg) <= msg_width else msg[:msg_width - 1] + "…"

    mcolor = branch_color[default_branch]

    for row in rows:
        if row["type"] == "main":
            graph = Text()
            graph.append("●─", style=mcolor)
            table.add_row(
                graph,
                Text(row["sha"],       style="dim yellow"),
                Text(row["date"],      style="dim"),
                Text(row["auth"],      style="dim cyan"),
                Text(_fit(row["msg"]), style=mcolor),
            )
        elif row["type"] == "branch":
            graph = Text()
            graph.append("│ ", style=row["mcolor"])
            connector = "╰─●" if row["is_last"] else "├─●"
            graph.append(connector, style=row["bcolor"])
            table.add_row(
                graph,
                Text(row["sha"],       style="dim yellow"),
                Text(row["date"],      style="dim"),
                Text(row["auth"],      style="dim cyan"),
                Text(_fit(row["msg"]), style=row["bcolor"]),
            )

    console.print(table)
    console.print()


# ─────────────────────────────────────────────────────────────────────────────
# REPLACE your old generate_mermaid() with this
# ─────────────────────────────────────────────────────────────────────────────

def generate_mermaid(
    files: list[tuple[str, str]],
    diagram_type: str | None = None,
    output_dir: str = "output",
    repo_path: str | None = None,
) -> str | None:
    # resolve type — show menu if not given
    if diagram_type is None:
        dtype = _mermaid_prompt_type()
    else:
        dtype = _MERMAID_ALIASES.get(diagram_type.strip().lower(), "graph")

    console.print(f"🗺️  Generating [bold cyan]{dtype}[/bold cyan] diagram...\n")

    # gitgraph is special — needs repo_path, not files
    if dtype == "gitgraph":
        if not repo_path:
            console.print("⚠️  gitgraph requires a repo path — skipping.", style="bold yellow")
            return None
        result = _mermaid_build_gitgraph(repo_path)
    else:
        # dispatch to builder
        dispatch = {
            "architecture": _mermaid_build_architecture,
            "sequence":     _mermaid_build_sequence,
            "class":        _mermaid_build_class,
        }

        if dtype in dispatch:
            result = dispatch[dtype](files)
        else:
            result = _mermaid_build_graph(files, _MERMAID_HEADERS.get(dtype, "graph TD"))

    if not result:
        console.print(
            f"🗺️  No intra-project calls found for [{dtype}] — skipping.",
            style="bold yellow",
        )
        return None

    os.makedirs(output_dir, exist_ok=True)
    out = os.path.abspath(os.path.join(output_dir, f"mermaid_{dtype.replace('_', '-')}.txt"))
    with open(out, "w", encoding="utf-8") as f:
        f.write(result)

    console.print(f"🗺️  Saved {out}", style="bold green")
    return out


# ─────────────────────────────────────────────
# PDF
# ─────────────────────────────────────────────
_BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def _register_fonts():
    font_dir = os.path.join(_BASE_DIR, "fonts")
    mappings = {
        "NotoLatin":      "NotoSans-Regular.ttf",
        "NotoBengali":    "NotoSansBengali-Regular.ttf",
        "NotoDevanagari": "NotoSansDevanagari-Regular.ttf",
    }
    for font_name, filename in mappings.items():
        path = os.path.join(font_dir, filename)
        if os.path.exists(path):
            pdfmetrics.registerFont(TTFont(font_name, path))


def _get_font(language: str) -> str:
    lang = language.lower()
    _DEVANAGARI_LANGS = {
        "hindi", "marathi", "nepali", "sanskrit", "maithili", "konkani", "bodo", "dogri"
    }
    if lang in ("bengali", "bangla", "assamese"):
        font = "NotoBengali"
    elif lang in _DEVANAGARI_LANGS:
        font = "NotoDevanagari"
    else:
        font = "NotoLatin"

    try:
        pdfmetrics.getFont(font)
        return font
    except KeyError:
        return "Helvetica"


def generate_pdf(text: str, output_dir: str = "output", filename: str = "report.pdf"):
    os.makedirs(output_dir, exist_ok=True)
    _register_fonts()
    font = _get_font(_language)

    styles = {
        "title": ParagraphStyle(
            "title",
            fontName=font,
            fontSize=22,
            leading=26,
            textColor=colors.darkblue,
            spaceAfter=16
        ),
        "head": ParagraphStyle(
            "head",
            fontName=font,
            fontSize=16,
            leading=20,
            textColor=colors.HexColor("#1f4e79"),
            spaceBefore=12,
            spaceAfter=8
        ),
        "body": ParagraphStyle(
            "body",
            fontName=font,
            fontSize=11,
            leading=16,
            spaceAfter=6
        ),
        "bullet": ParagraphStyle(
            "bullet",
            fontName=font,
            fontSize=11,
            leading=14,
            leftIndent=12
        ),
        "code_block": ParagraphStyle(
            "code_block",
            fontName="Courier",
            fontSize=9,
            leading=13,
            leftIndent=10,
            rightIndent=10,
            spaceBefore=6,
            spaceAfter=6,
            backColor=colors.HexColor("#f0f0f0"),
            textColor=colors.HexColor("#1a1a1a"),
            borderColor=colors.HexColor("#cccccc"),
            borderWidth=0.5,
            borderPadding=(4, 6, 4, 6),
            wordWrap="CJK",
        ),
    }

    from reportlab.platypus import Preformatted

    def _escape(s: str) -> str:
        return (
            s.replace("&", "&amp;")
             .replace("<", "&lt;")
             .replace(">", "&gt;")
        )

    def _inline_code(line: str) -> str:
        """Replace `inline code` spans with Courier-font markup."""
        import re
        return re.sub(
            r'`([^`]+)`',
            lambda m: f'<font name="Courier" size="10" color="#c7254e">{_escape(m.group(1))}</font>',
            line
        )

    def _parse_section_body(lines: list[str]) -> list:
        flowables = []
        i = 0

        def _escape_outside_tags(s: str) -> str:
            parts = re.split(r'(<[^>]+>)', s)
            return "".join(
                part if part.startswith("<") else _escape(part)
                for part in parts
            )

        def _process_inline(raw: str) -> str:
            """Apply inline code → escape → bold, in the correct order."""
            s = re.sub(
                r'`([^`]+)`',
                lambda m: f'<font name="Courier" size="10" color="#c7254e">{_escape(m.group(1))}</font>',
                raw
            )
            s = _escape_outside_tags(s)
            s = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', s)
            s = s.replace("**", "").replace("*", "")
            return s

        while i < len(lines):
            line = lines[i]

            # ── fenced code block ────────────────────────────────────────────────
            if line.strip().startswith("```"):
                code_lines = []
                i += 1
                while i < len(lines) and not lines[i].strip().startswith("```"):
                    code_lines.append(lines[i])
                    i += 1
                i += 1  # skip closing ```
                flowables.append(Spacer(1, 4))
                flowables.append(Preformatted("\n".join(code_lines), styles["code_block"]))
                flowables.append(Spacer(1, 4))
                continue

            clean = line.strip()

            # ── empty line ───────────────────────────────────────────────────────
            if not clean:
                i += 1
                continue

            # ── bullet ───────────────────────────────────────────────────────────
            if clean.startswith("-"):
                content = _process_inline(clean[1:].strip())
                flowables.append(Paragraph(f"• {content}", styles["bullet"]))
                i += 1
                continue

            # ── plain body ───────────────────────────────────────────────────────
            flowables.append(Paragraph(_process_inline(clean), styles["body"]))
            i += 1

        return flowables
    story = [
        Paragraph(f"Repo Analysis Report ({_language})", styles["title"]),
        Paragraph(
            "Automated technical audit generated using AI-assisted repository analysis.",
            styles["body"]
        ),
        Spacer(1, 12),
    ]

    for section in text.split("###"):
        lines = section.splitlines()
        if not lines:
            continue
        heading = lines[0].strip()
        if not heading:
            continue

        story.append(HRFlowable(width="100%", thickness=1, color=colors.grey))
        story.append(Spacer(1, 6))
        story.append(Paragraph(f"<b>{heading}</b>", styles["head"]))
        story.extend(_parse_section_body(lines[1:]))
        story.append(Spacer(1, 10))

    doc = SimpleDocTemplate(
        os.path.join(output_dir, filename),
        rightMargin=40,
        leftMargin=40,
        topMargin=50,
        bottomMargin=40
    )
    doc.build(story)
    console.print(f"📄 Saved {os.path.abspath(os.path.join(output_dir, filename))}", style="bold green")