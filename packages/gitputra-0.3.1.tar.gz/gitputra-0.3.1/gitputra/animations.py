from rich.text import Text
from rich.align import Align
from rich.live import Live
from rich.panel import Panel
import time
import math
from rich.console import Console
import shutil

console = Console()

# ─────────────────────────────────────────────
# HORIZONTAL LOGO (Standard)
# ─────────────────────────────────────────────
_INFO_LOGO_HORIZONTAL = [
    "  ██████╗ ██╗████████╗██████╗ ██╗   ██╗████████╗██████╗  █████╗ ",
    " ██╔════╝ ██║╚══██╔══╝██╔══██╗██║   ██║╚══██╔══╝██╔══██╗██╔══██╗",
    " ██║  ███╗██║   ██║   ██████╔╝██║   ██║   ██║   ██████╔╝███████║",
    " ██║   ██║██║   ██║   ██╔═══╝ ██║   ██║   ██║   ██╔══██╗██╔══██║",
    " ╚██████╔╝██║   ██║   ██║     ╚██████╔╝   ██║   ██║  ██║██║  ██║",
    "  ╚═════╝ ╚═╝   ╚═╝   ╚═╝      ╚═════╝    ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝",
    "   ◈   Analyze     ◈     Visualize     ◈     Synthesize   ◈   ",
]

MAX_W_HORIZ = max(len(line) for line in _INFO_LOGO_HORIZONTAL)
_INFO_LOGO_HORIZONTAL = [line.ljust(MAX_W_HORIZ) for line in _INFO_LOGO_HORIZONTAL]


# ─────────────────────────────────────────────
# VERTICAL LOGO (Fallback for narrow terminals)
# ─────────────────────────────────────────────
_INFO_LOGO_VERTICAL = [
    " ▄████▄ ", " ██  ▀▀ ", " ██ ▀██ ", " ▀████▀ ", "        ", # G (Fixed crossbar)
    "   ██   ", "   ██   ", "   ██   ", "   ██   ", "        ", # I
    " ██████ ", "   ██   ", "   ██   ", "   ██   ", "        ", # T
    " █████▄ ", " ██▄▄██ ", " ██▀▀▀  ", " ██     ", "        ", # P
    " ██  ██ ", " ██  ██ ", " ██  ██ ", " ▀████▀ ", "        ", # U
    " ██████ ", "   ██   ", "   ██   ", "   ██   ", "        ", # T
    " █████▄ ", " ██▄▄██ ", " ██▀██  ", " ██  ██ ", "        ", # R
    "  ▄██▄  ", " ██▄▄██ ", " ██▀▀██ ", " ██  ██ ", "        ", # A
    " Analyze", "   ◈    ", "Visualize", "   ◈    ", "Synthesize"
]

MAX_W_VERT = max(len(line) for line in _INFO_LOGO_VERTICAL)
_INFO_LOGO_VERTICAL = [line.center(MAX_W_VERT) for line in _INFO_LOGO_VERTICAL]


# ─────────────────────────────────────────────
# ANIMATION LOGIC
# ─────────────────────────────────────────────
def _info_hologram_frame(t: int, logo: list, row_delay: int) -> Text:
    text = Text()

    for row_idx, line in enumerate(logo):
        # The wave speed depends on row_delay (vertical has more rows, needs lower delay)
        reveal = min(len(line), max(0, t - row_idx * row_delay))

        for i, ch in enumerate(line):
            if i < reveal:
                phase = (t * 0.15 + i * 0.2 + row_idx * 0.3)
                r = int(100 + 120 * (math.sin(phase) + 1) / 2)
                g = int(80  + 150 * (math.sin(phase + 2) + 1) / 2)
                b = int(180 + 70  * (math.sin(phase + 4) + 1) / 2)
                text.append(ch, style=f"bold rgb({r},{g},{b})")
            else:
                text.append(" ", style="dim")

        text.append("\n")

    return text


def _make_panel(frame: Text) -> Align:
    return Align(
        Panel(
            frame,
            border_style="bright_magenta",
            padding=(1, 2),
            expand=False,
        ),
        align="center",
    )


def play_info_intro():
    # Detect geometry
    term_width = shutil.get_terminal_size().columns
    
    # Check if we have enough horizontal space (logo width + 8 chars for borders/padding)
    if term_width < MAX_W_HORIZ + 8:
        logo = _INFO_LOGO_VERTICAL
        max_frames = 100
        row_delay = 1  # Faster cascade through the 60+ rows
    else:
        logo = _INFO_LOGO_HORIZONTAL
        max_frames = 80
        row_delay = 3

    # Render loop
    with Live(console=console, refresh_per_second=20, transient=False) as live:
        for t in range(max_frames):
            live.update(_make_panel(_info_hologram_frame(t, logo, row_delay)))
            time.sleep(0.04)

        time.sleep(0.2)

        # Force a final clean frame — t is large enough to guarantee every row
        # is fully revealed regardless of logo size or row_delay value.
        final_t = max_frames + len(logo) * row_delay + 100
        final_frame = _info_hologram_frame(final_t, logo, row_delay)
        live.update(_make_panel(final_frame))

# ─────────────────────────────────────────────
# GRID FILL ANIMATION — indexing
# ─────────────────────────────────────────────
_GF_W = 38
_GF_H = 9
_GF_CHARS = [' ', '·', '░', '▒', '▓', '█']

# colour palette: teal, purple, amber, coral, blue
_GF_PALETTE = [
    (29, 158, 117),   # teal
    (127, 119, 221),  # purple
    (239, 159, 39),   # amber
    (216, 90, 48),    # coral
    (55, 138, 221),   # blue
]

def _grid_fill_frame(t: int, progress: float) -> list[tuple[str, str]]:
    result = []
    total_cells  = _GF_W * _GF_H
    filled_up_to = int(progress * total_cells)

    for row in range(_GF_H):
        for col in range(_GF_W):
            idx = row * _GF_W + col

            if idx < filled_up_to:
                # pick colour from palette based on cell position
                br, bg, bb = _GF_PALETTE[idx % len(_GF_PALETTE)]
                sh   = 0.75 + 0.25 * math.sin(t * 0.12 + idx * 0.3)
                rv   = int(br * sh)
                gv   = int(bg * sh)
                bv   = int(bb * sh)
                char = _GF_CHARS[int(sh * (len(_GF_CHARS) - 1))]
            elif idx == filled_up_to:
                # frontier: bright white pulse
                v    = 0.6 + 0.4 * ((math.sin(t * 0.25) + 1) / 2)
                rv   = int(220 * v)
                gv   = int(240 * v)
                bv   = int(255 * v)
                char = _GF_CHARS[int(v * (len(_GF_CHARS) - 1))]
            else:
                # pending: very dim
                v    = 0.08 + 0.04 * math.sin(t * 0.04 + idx * 0.7)
                rv   = int(30 * v)
                gv   = int(50 * v)
                bv   = int(80 * v)
                char = '·'

            result.append((char, f"#{rv:02x}{gv:02x}{bv:02x}"))

        if row < _GF_H - 1:
            result.append(('\n', '#ffffff'))

    return result

# ─────────────────────────────────────────────
# VORTEX SPIN ANIMATION — Phase 1 (embedding)
# ─────────────────────────────────────────────
_VX_W = 38
_VX_H = 9
_VX_CHARS = [' ', '·', '░', '▒', '▓', '█']

def _vortex_spin_frame(t: int) -> list[tuple[str, str]]:
    """
    Three spiral arms rotating outward from a bright core.
    Amber-to-teal hue shift by angle. Replaces _helix_frame for the embedding phase.
    """
    result = []
    cx, cy = _VX_W / 2, _VX_H / 2

    for row in range(_VX_H):
        for col in range(_VX_W):
            dx = (col - cx) / (_VX_W / 2)
            dy = (row - cy) / (_VX_H / 2) * 2.5
            dist = math.sqrt(dx * dx + dy * dy)
            angle = math.atan2(dy, dx)

            v = 0.0
            for arm in range(3):
                arm_angle = angle - dist * 2.5 + t * 0.07 + arm * (math.pi * 2 / 3)
                spiral = math.exp(-((arm_angle % (math.pi * 2)) - math.pi) ** 2 * 1.2)
                radial = math.exp(-dist * dist * 0.6)
                v = max(v, spiral * radial * 0.9 + radial * 0.3)

            # bright core
            v = max(v, math.exp(-dist * dist * 8))
            v = max(0.0, min(1.0, v))

            char = _VX_CHARS[int(v * (len(_VX_CHARS) - 1))]

            # amber-to-teal hue by angle
            hue = ((angle + math.pi) / (math.pi * 2) + t * 0.02) % 1.0
            rv = int((0.4 + hue * 0.6) * v * 255 + 20)
            gv = int(v * 180 + 20)
            bv = int((1 - hue) * v * 200 + 20)
            result.append((char, f"#{rv:02x}{gv:02x}{bv:02x}"))

        if row < _VX_H - 1:
            result.append(('\n', '#ffffff'))

    return result

def play_clear_db_vortex(frames: int = 50, delay: float = 0.05):
    """Vortex animation played during clear-db wipe."""
    from rich.text import Text
    from rich.live import Live
    from rich.panel import Panel
    from rich.align import Align

    t = 0
    with Live(console=console, refresh_per_second=20, transient=True) as live:
        for t in range(frames):
            pixels = _vortex_spin_frame(t)

            frame_text = Text(justify="center")
            for ch, color in pixels:
                if ch == '\n':
                    frame_text.append('\n')
                else:
                    frame_text.append(ch, style=color)

            caption = Text(justify="center")
            caption.append("\n  wiping vector index\n\n", style="bold red")
            caption.append_text(frame_text)
            caption.append("\n\n  purging ChromaDB collections...\n", style="dim italic")

            live.update(Align(Panel(
                caption,
                title="[bold magenta]◈ GitPutra ◈[/bold magenta]",
                border_style="bold red",
                padding=(1, 4),
                expand=False,
            ), align="center"))

            time.sleep(delay)


# ─────────────────────────────────────────────
# PARTICLE STORM ANIMATION — Phase 2 (generation)
# ─────────────────────────────────────────────
_PS_W = 38
_PS_H = 9
_PS_CHARS = [' ', '·', '∘', '○', '◎', '●', '⬟']
_PS_SEEDS = [i * 1.618 for i in range(18)]

def _particle_storm_frame(t: int) -> list[tuple[str, str]]:
    """
    18 particles orbiting lissajous paths with moiré interference shimmer.
    Purple-to-pink coloring. Replaces _waveform_frame for the generation phase.
    """
    result = []
    cx, cy = _PS_W / 2, _PS_H / 2

    # precompute particle positions
    positions = [
        (
            cx + (_PS_W * 0.45) * math.sin(s * 2.1 + t * 0.04 * (0.7 + s * 0.1)),
            cy + (_PS_H * 0.38) * math.cos(s * 1.7 + t * 0.05 * (0.5 + s * 0.08)),
        )
        for s in _PS_SEEDS
    ]

    for row in range(_PS_H):
        for col in range(_PS_W):
            v = 0.0

            for px, py in positions:
                dx = col - px
                dy = (row - py) * 2.8
                v = max(v, math.exp(-(dx * dx + dy * dy) * 0.35) * 0.95)

            # moiré shimmer from two interfering waves
            w1 = math.sin(col * 0.4 + t * 0.08) * math.cos(row * 0.9 + t * 0.06)
            w2 = math.sin(col * 0.7 - t * 0.05) * math.cos(row * 0.5 - t * 0.07)
            shimmer = ((w1 + w2) * 0.5 + 1) * 0.5 * 0.25
            v = max(0.0, min(1.0, v + shimmer))

            char = _PS_CHARS[int(v * (len(_PS_CHARS) - 1))]
            rv = int(80 + v * 160)
            gv = int(20 + v * 40)
            bv = int(150 + v * 100)
            result.append((char, f"#{rv:02x}{gv:02x}{bv:02x}"))

        if row < _PS_H - 1:
            result.append(('\n', '#ffffff'))

    return result
# ─────────────────────────────────────────────
# SHOCKWAVE ANIMATION
# ─────────────────────────────────────────────
_SW_W = 38
_SW_H = 9
_SW_CHARS = [' ', '░', '▒', '▓', '█']

def _shockwave_frame(t: int) -> list[tuple[str, str]]:
    """
    Returns a list of (char, hex_color) tuples for a flat W*H grid.
    Rows are separated by newline chars injected by the renderer.
    """
    cx, cy = _SW_W / 2, _SW_H / 2
    result = []

    for r in range(_SW_H):
        for c in range(_SW_W):
            dx = (c - cx) / (_SW_W / 2)
            dy = (r - cy) / (_SW_H / 2) * 2.5
            dist = math.sqrt(dx * dx + dy * dy)

            v = 0.0
            for ring in range(3):
                front = ((t * 0.045 + ring * 0.6) % 2.2)
                delta = dist - front
                if -0.05 < delta < 0.5:
                    v = max(v, 1 - delta / 0.5)

            # hot core that breathes
            core = math.exp(-dist * dist * 3) * (math.sin(t * 0.15) * 0.5 + 0.5)
            v = max(0.0, min(1.0, v + core))

            # color: blue cold → white hot → red edge
            rv = int(max(0, min(1, v * 2.2)) * 210 + 20)
            gv = int(max(0, min(1, v - 0.3)) * 160)
            bv = int(max(0, min(1, 1 - v)) * 200 + 55)
            color = f"#{rv:02x}{gv:02x}{bv:02x}"

            char = _SW_CHARS[int(v * (len(_SW_CHARS) - 1))]
            result.append((char, color))

        if r < _SW_H - 1:
            result.append(('\n', '#ffffff'))

    return result

# ─────────────────────────────────────────────
# SYNTHESIS ANIMATION — CONVERGENCE
# ─────────────────────────────────────────────
_SY_W = 38
_SY_H = 9
_SY_CHARS = [' ', '·', '░', '▒', '▓', '█']

def _synthesis_frame(t: int) -> list[tuple[str, str]]:
    """
    Streams flowing inward from all edges toward center.
    Returns list of (char, hex_color) tuples, newlines included.
    """
    cx, cy = _SY_W / 2, _SY_H / 2
    result = []

    hue_deg = 180 + math.sin(t * 0.04) * 30
    light = 55 + math.sin(t * 0.07) * 10
    # convert HSL to RGB manually (no colorsys needed)
    h = hue_deg / 360
    l = light / 100
    s = 0.70
    def hsl_to_rgb(h, s, l):
        if s == 0:
            return l, l, l
        def f(p, q, t):
            if t < 0: t += 1
            if t > 1: t -= 1
            if t < 1/6: return p + (q-p)*6*t
            if t < 1/2: return q
            if t < 2/3: return p + (q-p)*(2/3-t)*6
            return p
        q = l*(1+s) if l < 0.5 else l+s-l*s
        p = 2*l - q
        return f(p,q,h+1/3), f(p,q,h), f(p,q,h-1/3)

    r, g, b = hsl_to_rgb(h, s, l)
    for row in range(_SY_H):
        for col in range(_SY_W):
            dx = (col - cx) / (_SY_W / 2)
            dy = (row - cy) / (_SY_H / 2) * 2.0
            dist = math.sqrt(dx * dx + dy * dy)
            angle = math.atan2(dy, dx)

            stream = math.pow(max(0, math.cos(angle * 4 + t * 0.05)), 3)
            wave   = math.sin(dist * 5 - t * 0.12) * 0.5 + 0.5
            core   = math.exp(-dist * dist * 2) * (math.sin(t * 0.1) * 0.4 + 0.6)
            v = max(0.0, min(1.0, stream * wave * 0.6 + core * 0.9))

            # brighten toward center
            rv = int(max(0, min(1, r * (0.4 + v * 0.6) + v * 0.4)) * 255)
            gv = int(max(0, min(1, g * (0.4 + v * 0.6) + v * 0.3)) * 255)
            bv = int(max(0, min(1, b * (0.4 + v * 0.6))) * 255)
            color = f"#{rv:02x}{gv:02x}{bv:02x}"

            char = _SY_CHARS[int(v * (len(_SY_CHARS) - 1))]
            result.append((char, color))

        if row < _SY_H - 1:
            result.append(('\n', '#ffffff'))

    return result