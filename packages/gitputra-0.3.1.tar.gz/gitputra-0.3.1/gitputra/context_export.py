import os
import ast
import re
import datetime
import shutil
import subprocess
import tempfile

from rich.console import Console
from rich.progress import track
from .call_extractor import extract_calls as _ts_extract_calls

console = Console()

# ── Extension / skip filters (mirrors corelogic.py) ──────────────────────────
SUPPORTED_EXT = (
    ".py", ".c", ".h", ".cpp", ".js", ".ts", ".md", ".pdf",
    ".txt", ".java", ".go", ".rs", ".php", ".rb", ".swift",
    ".cs", ".html", ".css", ".json", ".yaml", ".yml", ".xml",
    ".sh", ".bat", ".ps1", ".gradle", ".makefile",
    ".ini", ".cfg", ".conf", ".log", ".sql", ".ipynb",
    ".vue", ".jsx", ".tsx", ".dart", ".scala", ".toml",
    ".pl", ".lua", ".r", ".m", ".kt", ".kts",
    ".groovy", ".clj", ".cljs", ".coffee", ".elm",
)
SUPPORTED_NAMES = ("Dockerfile", "Makefile", "makefile")

SKIP_DIRS  = {".git", ".venv", "venv", "node_modules", "__pycache__",
              ".idea", ".vscode", "dist", "build", ".mypy_cache", ".pytest_cache",
              "lib", "output"}
SKIP_FILES = {"package-lock.json", "yarn.lock", "poetry.lock", "Pipfile.lock"}

# How many chars to include in the source snapshot per file
MAX_CHARS_SNAPSHOT = 6000
# How many chars of a file to send to AI for summarisation (with-AI mode)
MAX_CHARS_AI_SUMMARY = 4000


# ─────────────────────────────────────────────────────────────────────────────
# 1. FILE DISCOVERY
# ─────────────────────────────────────────────────────────────────────────────

def _should_include(fname: str) -> bool:
    if fname in SKIP_FILES:
        return False
    return fname.endswith(SUPPORTED_EXT) or fname in SUPPORTED_NAMES


def scan_project(root: str) -> list[dict]:
    """
    Walk root and return list of dicts:
        { path (relative), abs_path, size_bytes, content (str) }
    """
    results = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        rel_dir = os.path.relpath(dirpath, root)
        for fname in filenames:
            if not _should_include(fname):
                continue
            abs_path = os.path.join(dirpath, fname)
            rel_path = os.path.join(rel_dir, fname).lstrip("./\\")
            try:
                if fname.endswith(".pdf"):
                    import pdfplumber
                    with pdfplumber.open(abs_path) as pdf:
                        content = "\n".join(
                            page.extract_text() or "" for page in pdf.pages
                        ).strip()
                else:
                    with open(abs_path, "r", errors="ignore") as fh:
                        content = fh.read()
                if not content.strip():
                    continue
                results.append({
                    "path":       rel_path,
                    "abs_path":   abs_path,
                    "size_bytes": os.path.getsize(abs_path),
                    "content":    content,
                })
            except Exception as e:
                console.log(f"⚠️  Error reading {abs_path}: {e}")

    results.sort(key=lambda f: f["path"])
    console.log(f"📂  Found {len(results)} source files in '{os.path.basename(root)}'")
    return results


# ─────────────────────────────────────────────────────────────────────────────
# 2. FILE TREE
# ─────────────────────────────────────────────────────────────────────────────

def build_file_tree(files: list[dict]) -> str:
    tree: dict = {}
    for f in files:
        parts = f["path"].replace("\\", "/").split("/")
        node = tree
        for part in parts:
            node = node.setdefault(part, {})

    lines = []

    def _render(node: dict, prefix: str = ""):
        items = sorted(node.keys())
        for i, key in enumerate(items):
            connector = "└── " if i == len(items) - 1 else "├── "
            lines.append(f"{prefix}{connector}{key}")
            child = node[key]
            if child:
                extension = "    " if i == len(items) - 1 else "│   "
                _render(child, prefix + extension)

    _render(tree)
    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# 3. TECH STACK DETECTION
# ─────────────────────────────────────────────────────────────────────────────

_TECH_HINTS = {
    ".py": "Python", ".js": "JavaScript", ".ts": "TypeScript",
    ".go": "Go", ".rs": "Rust", ".java": "Java", ".cpp": "C++",
    ".c": "C", ".cs": "C#", ".rb": "Ruby", ".php": "PHP",
    ".swift": "Swift", ".kt": "Kotlin", ".dart": "Dart",
    ".scala": "Scala", ".r": "R", ".lua": "Lua",
    "Dockerfile": "Docker", ".tf": "Terraform",
    ".vue": "Vue.js", ".jsx": "React (JSX)", ".tsx": "React (TSX)",
    ".html": "HTML", ".css": "CSS", ".ipynb": "Jupyter Notebook", ".sql": "SQL",
}

_FRAMEWORK_HINTS = {
    "requirements.txt": "pip / Python deps",
    "pyproject.toml":   "Poetry / PEP 517",
    "setup.py":         "setuptools",
    "package.json":     "Node.js / npm",
    "pom.xml":          "Maven (Java)",
    "build.gradle":     "Gradle (Java/Kotlin)",
    "Cargo.toml":       "Cargo (Rust)",
    "go.mod":           "Go modules",
    "Gemfile":          "Bundler (Ruby)",
    "composer.json":    "Composer (PHP)",
}


def detect_tech_stack(files: list[dict]) -> dict:
    langs: set[str] = set()
    infra:  set[str] = set()
    pkg_files: list[str] = []

    for f in files:
        fname = os.path.basename(f["path"])
        ext   = os.path.splitext(fname)[1].lower()
        if ext in _TECH_HINTS:
            langs.add(_TECH_HINTS[ext])
        if fname in _TECH_HINTS:
            infra.add(_TECH_HINTS[fname])
        if fname in _FRAMEWORK_HINTS:
            pkg_files.append(f"{fname}  →  {_FRAMEWORK_HINTS[fname]}")

    return {
        "languages": sorted(langs),
        "infra":     sorted(infra),
        "pkg_files": sorted(set(pkg_files)),
    }


# ─────────────────────────────────────────────────────────────────────────────
# 4. FUNCTIONALITY GRAPH  (fully offline, no AI)
# ─────────────────────────────────────────────────────────────────────────────

# Regex patterns per extension: (def_pattern, call_pattern)
_FUNC_PATTERNS = {
    ".py":    (r"^def (\w+)\s*\(",                                           r"(\w+)\s*\("),
    ".js":    (r"(?:function\s+(\w+)|(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?\()", r"(\w+)\s*\("),
    ".ts":    (r"(?:function\s+(\w+)|(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?\()", r"(\w+)\s*\("),
    ".jsx":   (r"function (\w+)\s*\(",                                       r"(\w+)\s*\("),
    ".tsx":   (r"function (\w+)\s*\(",                                       r"(\w+)\s*\("),
    ".java":  (r"(?:public|private|protected|static|\s)+\w+\s+(\w+)\s*\(",  r"(\w+)\s*\("),
    ".go":    (r"^func (\w+)\s*\(",                                          r"(\w+)\s*\("),
    ".rs":    (r"^(?:pub\s+)?fn (\w+)\s*\(",                                 r"(\w+)\s*\("),
    ".c":     (r"^\w[\w\s\*]+\s(\w+)\s*\(",                                  r"(\w+)\s*\("),
    ".cpp":   (r"^\w[\w\s\*]+\s(\w+)\s*\(",                                  r"(\w+)\s*\("),
    ".cs":    (r"(?:public|private|protected|static|\s)+\w+\s+(\w+)\s*\(",  r"(\w+)\s*\("),
    ".rb":    (r"^def (\w+)",                                                r"(\w+)\s*[\(\s]"),
    ".php":   (r"function (\w+)\s*\(",                                       r"(\w+)\s*\("),
    ".swift": (r"func (\w+)\s*\(",                                           r"(\w+)\s*\("),
    ".kt":    (r"fun (\w+)\s*\(",                                            r"(\w+)\s*\("),
}

_IGNORE_CALLS = {
    "if", "for", "while", "switch", "return", "print", "len", "range",
    "str", "int", "float", "bool", "list", "dict", "set", "tuple",
    "new", "this", "self", "super", "null", "true", "false",
    "console", "log", "err", "error", "fmt", "append", "make",
    "require", "import", "include", "define", "typeof", "instanceof",
    "assert", "raise", "yield", "lambda", "class", "pass", "break",
    "continue", "del", "with", "as", "from", "not", "and", "or", "in",
}

def _extract_calls(fname: str, content: str) -> dict[str, set[str]]:
    return _ts_extract_calls(fname, content)

def build_call_graph(files: list[dict]) -> tuple[dict[str, set[str]], dict[str, set[str]]]:
    all_funcs: dict[str, set[str]] = {}
    all_calls: dict[str, set[str]] = {}

    for f in files:
        calls = _extract_calls(f["path"], f["content"])  # ← was _extract_calls_from_file
        all_calls.update(calls)
        for full_name in calls:
            short = full_name.split(".")[-1]
            all_funcs.setdefault(short, set()).add(full_name)

    return all_funcs, all_calls


def _module_of(full_name: str) -> str:
    return full_name.rsplit(".", 1)[0]


# ── 4a. Module-level dependency graph ────────────────────────────────────────

def build_module_graph(all_funcs: dict, all_calls: dict) -> dict[tuple[str, str], int]:
    """
    Returns edge_weights: (src_module, tgt_module) -> call_count
    Only cross-module edges.
    """
    edge_weights: dict[tuple[str, str], int] = {}
    for func, called_set in all_calls.items():
        src_mod = _module_of(func)
        for callee_short in called_set:
            if callee_short not in all_funcs:
                continue
            for callee_full in all_funcs[callee_short]:
                tgt_mod = _module_of(callee_full)
                if tgt_mod != src_mod:
                    key = (src_mod, tgt_mod)
                    edge_weights[key] = edge_weights.get(key, 0) + 1
    return edge_weights


def render_module_mermaid(edge_weights: dict[tuple[str, str], int]) -> str:
    """Mermaid flowchart of module-level dependencies."""
    if not edge_weights:
        return ""
    lines = ["graph TD"]
    seen: set[str] = set()
    for (src, tgt), weight in sorted(edge_weights.items()):
        src_id = src.replace("-", "_").replace("/", "_").replace("\\", "_")
        tgt_id = tgt.replace("-", "_").replace("/", "_").replace("\\", "_")
        edge = f"    {src_id}[\"{src}\"] -->|\"{weight} call(s)\"| {tgt_id}[\"{tgt}\"]"
        if edge not in seen:
            lines.append(edge)
            seen.add(edge)
    return "\n".join(lines)


def render_module_plain(edge_weights: dict[tuple[str, str], int]) -> str:
    """Plain-text module dependency list."""
    if not edge_weights:
        return "(no cross-module dependencies detected)"
    lines = []
    for (src, tgt), weight in sorted(edge_weights.items(), key=lambda x: -x[1]):
        lines.append(f"  {src}  -->  {tgt}  [{weight} call(s)]")
    return "\n".join(lines)


# ── 4b. Function-level call graph ────────────────────────────────────────────

def render_function_mermaid(all_funcs: dict, all_calls: dict) -> str:
    """
    Mermaid flowchart of cross-module function calls only
    (intra-module would be too noisy for context transfer).
    """
    lines = ["graph TD"]
    seen: set[tuple[str, str]] = set()
    has_edges = False

    for func, called_set in sorted(all_calls.items()):
        src_mod = _module_of(func)
        for callee_short in called_set:
            if callee_short not in all_funcs:
                continue
            for callee_full in all_funcs[callee_short]:
                if callee_full == func:
                    continue
                tgt_mod = _module_of(callee_full)
                if tgt_mod == src_mod:
                    continue  # skip intra-module to keep it readable

                src_id  = func.replace(".", "_").replace("-", "_")
                tgt_id  = callee_full.replace(".", "_").replace("-", "_")
                src_lbl = func.split(".")[-1]
                tgt_lbl = callee_full.split(".")[-1]
                src_mod_lbl = src_mod
                tgt_mod_lbl = tgt_mod

                edge = (src_id, tgt_id)
                if edge not in seen:
                    lines.append(
                        f"    {src_id}[\"{src_mod_lbl}::{src_lbl}()\"]"
                        f" --> {tgt_id}[\"{tgt_mod_lbl}::{tgt_lbl}()\"]"
                    )
                    seen.add(edge)
                    has_edges = True

    if not has_edges:
        return ""
    return "\n".join(lines)


def render_function_plain(all_funcs: dict, all_calls: dict) -> str:
    """
    Structured plain-text: for each function, list what it calls
    (both intra and cross-module, since this is for AI context).
    Only include functions that actually call something known.
    """
    lines = []
    for func in sorted(all_calls.keys()):
        resolved: list[str] = []
        for callee_short in sorted(all_calls[func]):
            if callee_short in all_funcs:
                for callee_full in sorted(all_funcs[callee_short]):
                    if callee_full != func:
                        resolved.append(callee_full)
        if resolved:
            lines.append(f"{func}:")
            for r in resolved:
                lines.append(f"    -> {r}")
    return "\n".join(lines) if lines else "(no intra-project calls detected)"


# ── 4c. Per-file function inventory ──────────────────────────────────────────

def build_function_inventory(all_calls: dict) -> dict[str, list[str]]:
    """
    Returns { module_name: [func1, func2, ...] }
    Groups all known functions by their module (file stem).
    """
    inventory: dict[str, list[str]] = {}
    for full_name in all_calls:
        mod = _module_of(full_name)
        short = full_name.split(".")[-1]
        inventory.setdefault(mod, []).append(short)
    for mod in inventory:
        inventory[mod].sort()
    return inventory


def render_function_inventory(inventory: dict[str, list[str]]) -> str:
    if not inventory:
        return "(no functions extracted)"
    lines = []
    for mod in sorted(inventory.keys()):
        funcs = inventory[mod]
        lines.append(f"{mod}:")
        for fn in funcs:
            lines.append(f"  - {fn}()")
    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# 5. AI SUMMARIES  (only when --use-ai is passed)
# ─────────────────────────────────────────────────────────────────────────────

def _summarise_file(fname: str, content: str, language: str, safe_generate_fn) -> str:
    snippet = content[:MAX_CHARS_AI_SUMMARY]
    prompt = f"""Respond ONLY in {language}.
Summarise this source file for a developer handing off to a different AI tool.
Cover: purpose of the file, key functions/classes and what they do, notable patterns or side-effects.
Be concise and technical.

File: {fname}
---
{snippet}
{"...[truncated]" if len(content) > MAX_CHARS_AI_SUMMARY else ""}
"""
    return safe_generate_fn(prompt) or "(summary unavailable)"


def _synthesise_project(
    project_name: str,
    file_summaries: list[dict],
    tech: dict,
    language: str,
    safe_generate_fn,
) -> str:
    # Batch summaries to avoid token overflow
    BATCH_SIZE = 15
    batches = [file_summaries[i:i+BATCH_SIZE] for i in range(0, len(file_summaries), BATCH_SIZE)]
    batch_results = []

    for batch in batches:
        summaries_text = "\n\n".join(
            f"### {s['path']}\n{s['summary']}" for s in batch
        )
        prompt = f"""Respond ONLY in {language}.
Write a comprehensive project brief for '{project_name}' covering:
1. Project Goal — what does this do and why?
2. Architecture Overview — how are major components connected?
3. Key Design Decisions — patterns, tradeoffs, constraints.
4. Current State — what is complete, what is WIP, known issues.
5. How to Resume Work — critical things a new AI agent must know.

Tech stack: {', '.join(tech['languages'] + tech['infra']) or 'unknown'}
Package files: {', '.join(tech['pkg_files']) or 'none found'}

Per-file summaries:
{summaries_text}
"""
        result = safe_generate_fn(prompt)
        if result:
            batch_results.append(result)

    if len(batch_results) == 1:
        return batch_results[0]

    if len(batch_results) > 1:
        # Merge batch results into final synthesis
        merged = "\n\n---\n\n".join(batch_results)
        merge_prompt = f"""Respond ONLY in {language}.
Merge these partial project briefs into one unified, non-repetitive brief for '{project_name}'.
Keep all unique insights. Remove duplications. Preserve the 5-section structure.

{merged}
"""
        return safe_generate_fn(merge_prompt) or merged

    return "(project synthesis unavailable)"


# ─────────────────────────────────────────────────────────────────────────────
# 6. MARKDOWN ASSEMBLY
# ─────────────────────────────────────────────────────────────────────────────

def _md_section(title: str, body: str) -> str:
    return f"## {title}\n\n{body.strip()}\n\n"


def assemble_markdown(
    project_name:    str,
    root:            str,
    files:           list[dict],
    tech:            dict,
    all_funcs:       dict,
    all_calls:       dict,
    file_summaries:  list[dict],
    project_summary: str,
    language:        str,
    used_ai:         bool,
) -> str:
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")

    parts = [
        f"# GitPutra Context Export — `{project_name}`\n\n",
        f"> Generated: {now} | Language: {language} | Files: {len(files)} | Root: `{root}`\n\n",
        f"> AI summaries: {'yes' if used_ai else 'no (offline export)'}\n\n",
        "---\n\n",
        "<!-- USAGE\n"
        "Paste this file into any AI chat and say:\n"
        "'Here is my full codebase context. Read it carefully and help me continue work.'\n"
        "-->\n\n",
    ]

    # ── Project overview ─────────────────────────────────────────────────────
    parts.append(_md_section("Project Overview", project_summary))

    # ── Tech stack ───────────────────────────────────────────────────────────
    tech_lines = []
    if tech["languages"]:
        tech_lines.append(f"Languages: {', '.join(tech['languages'])}")
    if tech["infra"]:
        tech_lines.append(f"Infra/tooling: {', '.join(tech['infra'])}")
    if tech["pkg_files"]:
        tech_lines.append("Package files:\n" + "\n".join(f"  - {p}" for p in tech["pkg_files"]))
    parts.append(_md_section("Tech Stack", "\n".join(tech_lines) or "Not detected."))

    # ── File tree ─────────────────────────────────────────────────────────────
    parts.append(_md_section("File Tree", f"```\n{build_file_tree(files)}\n```"))

    # ── Functionality graph ───────────────────────────────────────────────────

    # 1. Function inventory (per-module list of all known functions)
    inventory = build_function_inventory(all_calls)
    inventory_text = render_function_inventory(inventory)
    parts.append(_md_section(
        "Function Inventory",
        f"All functions extracted per module:\n\n```\n{inventory_text}\n```"
    ))

    # 2. Module-level dependency graph
    edge_weights   = build_module_graph(all_funcs, all_calls)
    module_mermaid = render_module_mermaid(edge_weights)
    module_plain   = render_module_plain(edge_weights)

    module_graph_md = ""
    if module_mermaid:
        module_graph_md += f"```mermaid\n{module_mermaid}\n```\n\n"
    module_graph_md += f"Plain-text (fallback for tools that don't render Mermaid):\n```\n{module_plain}\n```"
    parts.append(_md_section("Module Dependency Graph", module_graph_md))

    # 3. Function-level call graph (cross-module, Mermaid)
    func_mermaid = render_function_mermaid(all_funcs, all_calls)
    func_plain   = render_function_plain(all_funcs, all_calls)

    func_graph_md = ""
    if func_mermaid:
        func_graph_md += f"```mermaid\n{func_mermaid}\n```\n\n"
    func_graph_md += f"Full call map (all intra-project calls, for AI context):\n```\n{func_plain}\n```"
    parts.append(_md_section("Function Call Graph", func_graph_md))

    # ── Per-file summaries (AI) or per-file stats (offline) ──────────────────
    summaries_md = ""
    if used_ai and file_summaries:
        for s in file_summaries:
            size_kb = s["size_bytes"] / 1024
            summaries_md += (
                f"### `{s['path']}`  ({size_kb:.1f} KB)\n\n"
                f"{s['summary']}\n\n---\n\n"
            )
    else:
        for f in files:
            size_kb = f["size_bytes"] / 1024
            mod     = os.path.splitext(os.path.basename(f["path"]))[0]
            funcs   = inventory.get(mod, [])
            func_list = ", ".join(f"{fn}()" for fn in funcs) if funcs else "none extracted"
            summaries_md += (
                f"### `{f['path']}`  ({size_kb:.1f} KB)\n\n"
                f"Functions: {func_list}\n\n---\n\n"
            )

    parts.append(f"## File Summaries\n\n{summaries_md}")

    # ── Source snapshot (truncated) ───────────────────────────────────────────
    source_md = ""
    for f in files:
        snippet   = f["content"][:MAX_CHARS_SNAPSHOT]
        truncated = len(f["content"]) > MAX_CHARS_SNAPSHOT
        ext       = os.path.splitext(f["path"])[1].lstrip(".")
        source_md += (
            f"### `{f['path']}`\n\n"
            f"```{ext}\n{snippet}"
            f"\n{'// ... [truncated]' if truncated else ''}"
            f"\n```\n\n"
        )
    parts.append(f"## Source Snapshot\n\n{source_md}")

    # ── Footer ────────────────────────────────────────────────────────────────
    parts.append(
        "---\n\n"
        "_Exported by [GitPutra](https://pypi.org/project/gitputra/) — "
        "AI-powered repository analyzer._\n"
    )

    return "".join(parts)


# ─────────────────────────────────────────────────────────────────────────────
# 7. MAIN ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────

# ─────────────────────────────────────────────────────────────────────────────
# 6b. GITHUB URL HELPERS
# ─────────────────────────────────────────────────────────────────────────────

_GITHUB_URL_RE = re.compile(
    r"^https?://github\.com/[^/]+/[^/]+"
    r"|^git@github\.com:[^/]+/[^/]+"
)


def _is_github_url(path: str) -> bool:
    """Return True if *path* looks like a GitHub remote URL."""
    return bool(_GITHUB_URL_RE.match(path.strip()))


def _clone_to_temp(url: str, branch: str | None = None) -> str:
    """
    Shallow-clone *url* into a fresh temp directory.
    Returns the path to the cloned repo root.
    Raises RuntimeError on failure.
    """
    tmp = tempfile.mkdtemp(prefix="gitputra_ctx_")
    cmd = ["git", "clone", "--depth", "1"]
    if branch:
        cmd += ["--branch", branch]
    cmd += [url, tmp]
    console.log(f"🌐  Cloning {url} → {tmp} ...")
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        shutil.rmtree(tmp, ignore_errors=True)
        raise RuntimeError(
            f"git clone failed:\n{result.stderr.strip()}"
        )
    console.log("✅  Clone complete.")
    return tmp


def export_context(
    project_path:    str,
    safe_generate_fn = None,   # None = offline mode
    language:        str  = "English",
    output_dir:      str  = "output",
    use_ai:          bool = False,
    branch:          str | None = None,
) -> str:
    """
    Full pipeline. Returns path to the written .md file.

    Args:
        project_path     – local codebase root OR a GitHub URL
        safe_generate_fn – corelogic.safe_generate, already initialised. None = offline.
        language         – human language for AI summaries (only used when use_ai=True)
        output_dir       – where to write the .md file
        use_ai           – if True and safe_generate_fn provided, generate deep AI summaries
        branch           – branch to clone (only used when project_path is a GitHub URL)
    """
    _tmp_dir: str | None = None  # track temp clone for cleanup

    project_path = project_path.strip()

    # ── Auto-detect GitHub URL and clone ────────────────────────────────────
    if _is_github_url(project_path):
        _tmp_dir    = _clone_to_temp(project_path, branch)
        project_name = re.split(r"[/:]", project_path.rstrip("/"))[-1]
        project_name = re.sub(r"\.git$", "", project_name)
        project_path = _tmp_dir
    else:
        project_path = os.path.abspath(project_path)
        project_name = os.path.basename(project_path)

    if not os.path.isdir(project_path):
        raise NotADirectoryError(f"'{project_path}' is not a directory.")

    # 1. Scan files
    files = scan_project(project_path)
    if not files:
        raise ValueError(f"No supported source files found in '{project_path}'.")

    # 2. Tech stack
    tech = detect_tech_stack(files)
    console.log(f"🔍  Languages: {', '.join(tech['languages']) or 'none detected'}")

    # 3. Build call graph (offline, always)
    console.log("🔗  Building functionality graph...")
    all_funcs, all_calls = build_call_graph(files)
    console.log(
        f"    {len(all_calls)} functions found, "
        f"{sum(len(v) for v in all_calls.values())} call edges extracted"
    )

    # 4. AI summaries (only if requested)
    file_summaries: list[dict] = []
    project_summary: str

    if use_ai and safe_generate_fn:
        console.log("🧠  AI mode: generating per-file summaries...")
        for f in track(files, description="Summarizing files..."):
            summary = _summarise_file(f["path"], f["content"], language, safe_generate_fn)
            file_summaries.append({
                "path":       f["path"],
                "size_bytes": f["size_bytes"],
                "summary":    summary,
            })
        console.log("🧩  Synthesising project overview...")
        project_summary = _synthesise_project(
            project_name, file_summaries, tech, language, safe_generate_fn
        )
    else:
        if use_ai and not safe_generate_fn:
            console.log("⚠️  --use-ai set but no AI provider initialised — falling back to offline.")
        console.log("⚡  Offline mode: skipping AI summaries.")
        project_summary = (
            f"Offline context export for `{project_name}`. "
            f"{len(files)} source files scanned. "
            f"Tech stack: {', '.join(tech['languages'] + tech['infra']) or 'unknown'}. "
            f"Re-run with --use-ai to generate AI-powered summaries and project synthesis."
        )

    # 5. Assemble markdown
    md = assemble_markdown(
        project_name    = project_name,
        root            = project_path,
        files           = files,
        tech            = tech,
        all_funcs       = all_funcs,
        all_calls       = all_calls,
        file_summaries  = file_summaries,
        project_summary = project_summary,
        language        = language,
        used_ai         = use_ai and bool(file_summaries),
    )

    # 6. Write output
    os.makedirs(output_dir, exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    out_path  = os.path.join(output_dir, f"context_{project_name}_{timestamp}.md")
    with open(out_path, "w", encoding="utf-8") as fh:
        fh.write(md)

    # ── Clean up temp clone (if we created one) ──────────────────────────────
    if _tmp_dir and os.path.isdir(_tmp_dir):
        shutil.rmtree(_tmp_dir, ignore_errors=True)
        console.log("🗑️   Temp clone removed.")

    size_kb = os.path.getsize(out_path) / 1024
    console.print(f"\n✅  Context exported → [bold green]{out_path}[/bold green]  ({size_kb:.1f} KB)")
    console.print(
        "\n💡  [bold cyan]How to use:[/bold cyan]\n"
        "    1. Open the .md file\n"
        "    2. Paste it into any AI chat (ChatGPT, Gemini, Claude …)\n"
        '    3. Say: "Here is my codebase context. Read it and help me continue."\n'
    )

    return out_path