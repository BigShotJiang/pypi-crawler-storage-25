import os
import json
import hashlib
import shutil
import random
import string
from datetime import datetime

import click
from dotenv import load_dotenv
from . import corelogic as core
from . import context_export as ctx
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import track
from rich import print as rprint

from . import animations


console = Console()

load_dotenv()

SESSIONS_DIR = os.path.join(os.path.expanduser("~"), ".gitputra", "sessions")


# ─────────────────────────────────────────────
# SESSION HELPERS
# ─────────────────────────────────────────────

def _hash_codebase(repo_path: str) -> str:
    """
    Fast MD5 fingerprint over sorted (relpath, mtime_ns, size) of every file.
    Does NOT read file contents — just stat(). Returns "" if path missing.
    """
    if not os.path.isdir(repo_path):
        return ""
    skip = {".git", "__pycache__", ".venv", "venv", "node_modules"}
    entries = []
    for root, dirs, files in os.walk(repo_path):
        dirs[:] = sorted(d for d in dirs if d not in skip)
        for fname in sorted(files):
            full = os.path.join(root, fname)
            try:
                st = os.stat(full)
                rel = os.path.relpath(full, repo_path)
                entries.append(f"{rel}:{st.st_mtime_ns}:{st.st_size}")
            except OSError:
                pass
    return hashlib.md5("\n".join(entries).encode()).hexdigest()


def _save_session(
    name: str,
    history: list,
    repo_path: str,
    repo_name: str,
    branch: str,
    ai: str,
    lang: str,
    *,
    timestamped: bool = False,
) -> str:
    """Write session to SESSIONS_DIR/<name>.json. Returns absolute path written."""
    os.makedirs(SESSIONS_DIR, exist_ok=True)
    filename = (
        f"{name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        if timestamped
        else f"{name}.json"
    )
    path = os.path.join(SESSIONS_DIR, filename)
    payload = {
        "repo_path":      os.path.abspath(repo_path),
        "repo":           repo_name,
        "codebase_hash":  _hash_codebase(repo_path),
        "branch":         branch or "",
        "ai":             ai,
        "lang":           lang,
        "saved_at":       datetime.now().isoformat(timespec="seconds"),
        "turns":          history,
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)
    return os.path.abspath(path)


def _load_session(name: str) -> dict:
    """Read SESSIONS_DIR/<name>.json. Raises FileNotFoundError if missing."""
    path = os.path.join(SESSIONS_DIR, f"{name}.json")
    if not os.path.exists(path):
        raise FileNotFoundError(f"Session '{name}' not found.")
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _list_session_files() -> list[str]:
    """Return session JSON filenames sorted newest-first."""
    if not os.path.isdir(SESSIONS_DIR):
        return []
    files = [f for f in os.listdir(SESSIONS_DIR) if f.endswith(".json")]
    return sorted(
        files,
        key=lambda f: os.path.getmtime(os.path.join(SESSIONS_DIR, f)),
        reverse=True,
    )


# ─────────────────────────────────────────────
# CLI ROOT
# ─────────────────────────────────────────────

@click.group()
@click.version_option("0.3.1", prog_name="gitputra")
def main():
    """🔍 Gitputra — AI-powered GitHub repo analyzer."""
    pass


# ─────────────────────────────────────────────
# ANALYZE
# ─────────────────────────────────────────────
@main.command()
@click.argument("url", default=".")
@click.option("--branch", default=None, help="Branch to clone (default: repo default branch). Ignored with --local.")
@click.option(
    "--ai", "ai_choice",
    type=click.Choice(["gemini", "openai", "ollama", "none"], case_sensitive=False),
    default="none", show_default=True,
    help="AI provider to use."
)
@click.option(
    "--key", envvar="API_KEY", default=None,
    help="API key (or set API_KEY in .env). Avoid passing directly to keep it out of shell history."
)
@click.option("--lang", default="English", show_default=True, help="Output language for the report.")
@click.option("--no-pdf", is_flag=True, default=False, help="Skip PDF generation.")
@click.option("--no-diagram", is_flag=True, default=False, help="Skip diagram generation.")
@click.option(
    "--output-dir", "output_dir", default=None, metavar="PATH",
    help="Directory to save all output files (default: ./output).",
    type=click.Path()
)
@click.option("--local", is_flag=True, default=False, help="Analyze a local directory instead of cloning a GitHub URL.")
def analyze(url, branch, ai_choice, key, lang, no_pdf, no_diagram, output_dir, local):
    """Clone a GitHub repo and generate an AI analysis report.

    \b
    Remote repo:
        gitputra analyze https://github.com/user/repo --ai gemini --key AIza...
    \b
    Local codebase:
        gitputra analyze ./my-project --local --ai gemini --key AIza...
        gitputra analyze "C:\\path\\with spaces\\project" --local --ai gemini --key AIza...
    """
    ai_enabled = ai_choice.lower() != "none"
    if ai_enabled:
        if not key:
            key = click.prompt("🔑 Enter API key (input hidden, press Enter when done)", hide_input=True)
            console.print("🔐 Key received", style="dim")
        core.init(ai_choice.lower(), key, lang)
    else:
        core._ai_config = {}

    if output_dir is None:
        output_dir = "output"
    output_dir = os.path.abspath(output_dir)

    if local:
        repo_path = os.path.abspath(url.strip())
        repo_name = os.path.basename(repo_path)
        if not os.path.isdir(repo_path):
            console.print(f"❌ Directory not found: {repo_path}", style="bold red")
            raise SystemExit(1)
        console.print(f"📂 Analyzing local directory: {repo_path}", style="bold cyan")
    else:
        repo_path, repo_name = core.clone_repo(url, branch)

    files = core.load_files(repo_path)
    if not files:
        console.print("❌ No supported source files found.", style="bold red")
        raise SystemExit(1)

    core.store_chunks(files, repo_name, branch)
    analysis = core.analyze_repo(files)
    console.print(Panel.fit(analysis, title="🔍 Analysis Report", border_style="green"))

    if not no_diagram:
        core.generate_mermaid(files, output_dir=output_dir, repo_path=repo_path)
        core.generate_3d_visualization(files, output_dir)
    if not no_pdf:
        core.generate_pdf(analysis, output_dir)

    console.print(f"✅ Done! Outputs saved in {output_dir}", style="bold green")


# ─────────────────────────────────────────────
# CHAT
# ─────────────────────────────────────────────
@main.command()
@click.argument("url", default=".")
@click.option("--branch", default=None, help="Branch to clone (default: repo default branch). Ignored with --local.")
@click.option(
    "--ai", "ai_choice",
    type=click.Choice(["gemini", "openai", "ollama"], case_sensitive=False),
    default="gemini", show_default=True,
)
@click.option(
    "--key", envvar="API_KEY", default=None,
    help="API key (or set API_KEY in .env). Avoid passing directly to keep it out of shell history."
)
@click.option("--lang", default="English", show_default=True)
@click.option("--local", is_flag=True, default=False, help="Chat about a local directory instead of cloning a GitHub URL.")
@click.option("--save-session", "save_session", default=None, metavar="NAME", help="Auto-save session on exit.")
@click.option("--load-session", "load_session", default=None, metavar="NAME", help="Resume a previously saved session by name.")
def chat(url, branch, ai_choice, key, lang, local, save_session, load_session):
    """Start an interactive RAG chat about a repo.

    \b
    Remote repo:
        gitputra chat https://github.com/user/repo --ai gemini
    \b
    Local codebase:
        gitputra chat ./my-project --local --ai gemini --key AIza...
        Type 'exit' or Ctrl+C to quit.
    \b
    Sessions:
        gitputra chat ./my-project --local --save-session mysession
        gitputra chat ./my-project --local --load-session mysession
    """
    if not key:
        key = click.prompt("🔑 Enter API key (input hidden, press Enter when done)", hide_input=True)
        console.print("🔐 Key received", style="dim")
    core.init(ai_choice.lower(), key, lang)

    if local:
        repo_path = os.path.abspath(url.strip())
        repo_name = os.path.basename(repo_path)
        if not os.path.isdir(repo_path):
            console.print(f"❌ Directory not found: {repo_path}", style="bold red")
            raise SystemExit(1)
        console.print(f"📂 Using local directory: {repo_path}", style="bold cyan")
    else:
        repo_path, repo_name = core.clone_repo(url, branch)

    files = core.load_files(repo_path)
    if not files:
        console.print("❌ No supported source files found.", style="bold red")
        raise SystemExit(1)
    core.store_chunks(files, repo_name, branch)

    # ── load session history ──────────────────────────────────────────────────
    history = []
    if load_session:
        try:
            sess = _load_session(load_session)
            history = sess.get("turns", [])
            turns = sum(1 for m in history if m.get("role") == "user")
            console.print(
                f"📂 Loaded session [bold cyan]{load_session}[/bold cyan] "
                f"— [bold]{turns}[/bold] turn(s) restored "
                f"(saved {sess.get('saved_at', 'unknown')})",
                style="dim",
            )
        except FileNotFoundError as e:
            console.print(f"❌ {e}", style="bold red")
            raise SystemExit(1)

    console.print(
        f"\n💬 Chat mode [{repo_name}] — ask anything about the codebase. Type 'exit' to quit.\n",
        style="bold cyan",
    )

    ext = "NAMASKAR"

    def _do_exit():
        nonlocal save_session
        if history:
            name = save_session
            if not name:
                answer = click.prompt("💾 Save session? (Y/N)", default="N", show_default=False)
                if answer.strip().lower() == "y":
                    name = click.prompt("   Session name")

            # Overwrite-check loop
            while name:
                sess_path = os.path.join(SESSIONS_DIR, f"{name}.json")
                if os.path.exists(sess_path):
                    if click.confirm(f"⚠️  Session '{name}' already exists. Overwrite?", default=False):
                        break
                    else:
                        name = click.prompt("   Enter a new session name")
                        continue
                else:
                    break

            if name:
                saved = _save_session(name, history, repo_path, repo_name, branch, ai_choice, lang)
                console.print(f"✅ Session saved → [bold cyan]{saved}[/bold cyan]", style="bold green")

        console.print(f"[bold yellow]{ext}[/bold yellow]")

    while True:
        try:
            question = console.input("[bold cyan]>> [/bold cyan]")
        except (KeyboardInterrupt, click.Abort):
            _do_exit()
            break

        if question.strip().lower() in ("exit", "quit", "q"):
            _do_exit()
            break

        if not question.strip():
            continue

        if question.strip().lower() == "!switch":
            load_dotenv(override=True)
            new_key = os.getenv("API_KEY")
            if not new_key:
                console.print("❌ No API_KEY found in .env", style="bold red")
                continue
            core.init(ai_choice.lower(), new_key, lang)
            console.print("✅ Key reloaded, quota reset. Chat history preserved.", style="bold green")
            continue

        if question.strip().lower() == "!save":
            if not history:
                console.print("⚠️  Nothing to save yet.", style="bold yellow")
                continue
            snap_name = save_session or click.prompt("   Session name")
            saved = _save_session(snap_name, history, repo_path, repo_name, branch, ai_choice, lang, timestamped=True)
            console.print(f"💾 Snapshot saved → [bold cyan]{saved}[/bold cyan]", style="green")
            continue

        answer = core.query_rag(question, repo_name, branch, history=history)
        console.print(f"\n[bold green]◈[/bold green] {answer}\n")

        history.append({"role": "user",      "content": question})
        history.append({"role": "assistant", "content": answer})


# ─────────────────────────────────────────────
# VISUALIZE
# ─────────────────────────────────────────────
@main.command("visualize")
@click.argument("url", default=".")
@click.option("--branch", default=None, help="Branch to clone (default: repo default branch). Ignored with --local.")
@click.option("--local", is_flag=True, default=False, help="Treat URL as a local repo path instead of a GitHub URL.")
@click.option("--self-map", is_flag=True, default=False, help="Easter Egg: Generate the 3D map of GitPutra's internal RAG pipeline.")
@click.option(
    "--output-dir", "output_dir", default=None, metavar="PATH",
    help="Directory to save the 3D visualize file (default: ./output).",
    type=click.Path()
)
def visualize(url, branch, local, self_map, output_dir):
    """🌌 Generate an interactive 3D Code Galaxy for any repository.

    \b
    Remote repo:
        gitputra visualize https://github.com/user/repo
    \b
    Local codebase:
        gitputra visualize ./my-project --local
        gitputra visualize "C:\\Users\\adity\\OneDrive\\Desktop\\GitMan" --local
    """
    if output_dir is None:
        output_dir = "output"
    output_dir = os.path.abspath(output_dir)

    if self_map:
        console.print("🚀 Booting up the GitPutra Semantic Visualize map...", style="bold magenta")
        core.generate_semantic_3d(output_dir)
        return

    if local:
        repo_path = os.path.abspath(url.strip())
        if not os.path.isdir(repo_path):
            console.print(f"❌ Directory not found: {repo_path}", style="bold red")
            raise SystemExit(1)
        console.print(f"📂 Scanning local directory: {repo_path}", style="bold cyan")
    else:
        repo_path, _ = core.clone_repo(url, branch)

    files = core.load_files(repo_path)
    if not files:
        console.print("❌ No supported source files found.", style="bold red")
        raise SystemExit(1)

    console.print(f"\n🌌 Weaving 3D Code Galaxy for {os.path.basename(repo_path)}...", style="bold magenta")
    core.generate_3d_visualization(files, output_dir)
    console.print(f"✅ Done! Open the HTML file in {output_dir} to explore your architecture visualization.", style="bold green")


# ─────────────────────────────────────────────
# EXPORT CONTEXT
# ─────────────────────────────────────────────
@main.command("export-context")
@click.argument("project_path", default=".", metavar="PROJECT_PATH", type=click.Path())
@click.option("--remote", is_flag=True, default=False, help="Treat PROJECT_PATH as a GitHub URL and clone it first.")
@click.option("--branch", default=None, help="Branch to clone (only used with --remote).")
@click.option("--use-ai", "use_ai", is_flag=True, default=False, help="Generate deep AI summaries (requires --ai and --key).")
@click.option(
    "--ai", "ai_choice",
    type=click.Choice(["gemini", "openai", "ollama"], case_sensitive=False),
    default="gemini", show_default=True,
    help="AI provider (only used with --use-ai)."
)
@click.option("--key", envvar="API_KEY", default=None, help="API key (or set API_KEY in .env). Only used with --use-ai.")
@click.option("--lang", default="English", show_default=True, help="Language for AI summaries (only used with --use-ai).")
@click.option(
    "--output-dir", "output_dir", default=None, metavar="PATH",
    help="Directory to save the context .md file (default: ./output).",
    type=click.Path()
)
def export_context_cmd(project_path, remote, branch, use_ai, ai_choice, key, lang, output_dir):
    """Export a portable context .md from a local or remote codebase.

    Fully offline by default — scans files, builds a functionality graph
    (module deps + function call map), and writes a single Markdown file
    you can paste into any AI tool to resume work instantly.

    Add --use-ai to also generate deep per-file summaries and a project
    synthesis via the chosen AI provider.

    \b
    Examples:
        gitputra export-context                                    (current dir, offline)
        gitputra export-context ./my-project                      (offline)
        gitputra export-context ./my-project --use-ai --key AIza...
        gitputra export-context https://github.com/u/r            (auto-detected, no --remote needed)
        gitputra export-context https://github.com/u/r --branch dev --use-ai --key AIza...
        gitputra export-context "C:\\path\\with spaces\\proj"     (quote paths with spaces)
    """
    is_remote = remote or ctx._is_github_url(project_path)

    if is_remote and not ctx._is_github_url(project_path):
        console.print(
            f"❌ --remote requires a GitHub URL, but got a local path: {project_path}\n"
            f"   Use --remote with a URL, or omit --remote for local directories.",
            style="bold red",
        )
        raise SystemExit(1)

    gen_fn = None
    if use_ai:
        if not key:
            key = click.prompt("🔑 Enter API key (input hidden, press Enter when done)", hide_input=True)
        core.init(ai_choice.lower(), key, lang)
        gen_fn = core.safe_generate

    if output_dir is None:
        output_dir = click.prompt(
            "Paste the directory location where you want to save the context .md file or press Enter to 📁 Save context .md to",
            default=os.path.abspath("output"),
            show_default=True,
        )
    output_dir = os.path.abspath(output_dir)

    ctx.export_context(
        project_path=project_path,
        safe_generate_fn=gen_fn,
        language=lang,
        use_ai=use_ai,
        branch=branch,
        output_dir=output_dir,
    )


# ─────────────────────────────────────────────
# DIFF
# ─────────────────────────────────────────────
@main.command("diff")
@click.argument("url", default=".")
@click.option("--base", default="HEAD~1", show_default=True, help="Base branch or commit (older side of diff).")
@click.option("--head", default="HEAD", show_default=True, help="Head branch or commit (newer side of diff).")
@click.option("--branch", default=None, help="Branch to clone (default: repo default branch). Ignored with --local.")
@click.option("--local", is_flag=True, default=False, help="Treat URL as a local repo path instead of a GitHub URL.")
@click.option(
    "--ai", "ai_choice",
    type=click.Choice(["gemini", "openai", "ollama", "none"], case_sensitive=False),
    default="none", show_default=True,
    help="AI provider for the summary.",
)
@click.option("--key", envvar="API_KEY", default=None, help="API key (or set API_KEY in .env).")
@click.option("--lang", default="English", show_default=True, help="Output language for the AI summary.")
@click.option("--no-pdf", is_flag=True, default=False, help="Skip saving the AI summary as a PDF.")
@click.option(
    "--output-dir", "output_dir", default=None, metavar="PATH",
    help="Directory to save output files (default: ./output).",
    type=click.Path()
)
@click.option(
    "--ollama-model", "ollama_model", default=None, metavar="MODEL",
    help="Ollama text model to use (e.g. llama3, mistral). Embeddings always use nomic-embed-text."
)
def diff(url, base, head, branch, local, ai_choice, key, lang, no_pdf, output_dir, ollama_model):
    """Show what changed between two branches or commits.

    \b
    Local repo (last commit vs its parent):
        gitputra diff . --local
    \b
    Compare branches with AI summary:
        gitputra diff https://github.com/user/repo --base main --head dev --ai gemini --key AIza...
    \b
    Remote repo on a specific branch:
        gitputra diff https://github.com/user/repo --branch feature-x --base HEAD~1 --head HEAD
    \b
    Local repo, specific commits:
        gitputra diff ./my-project --local --base abc1234 --head def5678 --ai openai
    """
    ai_enabled = ai_choice.lower() != "none"

    if ai_enabled:
        if not key:
            key = click.prompt("🔑 Enter API key (input hidden, press Enter when done)", hide_input=True)
            console.print("🔐 Key received", style="dim")
        core.init(ai_choice.lower(), key, lang, ollama_model=ollama_model)

    if output_dir is None:
        output_dir = "output"
    output_dir = os.path.abspath(output_dir)

    if local:
        repo_path = os.path.abspath(url.strip())
        if not os.path.isdir(repo_path):
            console.print(f"❌ Directory not found: {repo_path}", style="bold red")
            raise SystemExit(1)
        console.print(f"📂 Using local repo: {repo_path}", style="bold cyan")
    else:
        repo_path, _ = core.clone_repo(url, branch=branch)

    console.print(f"\n🔀 Diffing [bold cyan]{base}[/bold cyan] → [bold green]{head}[/bold green] ...\n")
    try:
        diff_text, changed_files = core.get_diff(repo_path, base, head)
    except Exception as exc:
        error_msg = getattr(exc, "stderr", str(exc))
        console.print(f"❌ git diff failed:\n[bold red]{error_msg}[/bold red]")
        raise SystemExit(1)

    if not diff_text.strip():
        console.print("✅ No differences found between the two refs.", style="bold yellow")
        return

    files_table = Table(title=f"📝 Changed Files ({len(changed_files)})", show_lines=True)
    files_table.add_column("#", style="dim", width=4)
    files_table.add_column("File", style="cyan")
    for i, fname in enumerate(changed_files, 1):
        files_table.add_row(str(i), fname)
    console.print(files_table)

    if ai_enabled:
        console.print("\n🤖 Generating AI summary...\n", style="bold magenta")
        summary = core.summarize_diff(diff_text, changed_files, lang)
        if summary:
            console.print(Panel.fit(summary, title="🔍 Diff Summary", border_style="green"))
            if not no_pdf:
                core.generate_pdf(summary, output_dir, filename="diff_summary.pdf")
                console.print(f"📄 Summary saved to {os.path.join(output_dir, 'diff_summary.pdf')}", style="bold green")
        else:
            console.print("⚠️  AI summary unavailable.", style="bold yellow")
    else:
        console.print("\n💡 Tip: add [bold cyan]--ai gemini[/bold cyan] (or openai) for an AI-powered summary.", style="dim")

    console.print(f"\n✅ Diff complete.", style="bold green")


# ─────────────────────────────────────────────
# SHOW GRAPH
# ─────────────────────────────────────────────
@main.command("show-graph")
@click.argument("url", default=".", metavar="[URL_OR_PATH]")
@click.option("--local", is_flag=True, default=False, help="Treat argument as a local path (auto-detected for plain paths).")
@click.option("--max-commits", "max_commits", default=30, show_default=True, help="Maximum commits to show per branch.")
def show_graph(url, local, max_commits):
    """Render the git branch timeline in the terminal.

    \b
    Current directory:
        gitputra show-graph
    \b
    Local repo:
        gitputra show-graph ./my-project --local
    \b
    Remote repo (clones first):
        gitputra show-graph https://github.com/user/repo
    """
    is_url = url.startswith("http://") or url.startswith("https://") or url.startswith("git@")

    if is_url and not local:
        repo_path, _ = core.clone_repo(url, branch=None)
    else:
        repo_path = os.path.abspath(url.strip())
        if not os.path.isdir(repo_path):
            console.print(f"❌ Directory not found: {repo_path}", style="bold red")
            raise SystemExit(1)

    core.render_gitgraph_terminal(repo_path, max_commits=max_commits)


# ─────────────────────────────────────────────
# SESSION
# ─────────────────────────────────────────────
@main.command("session")
@click.argument("name", required=False, default=None)
@click.argument("action", required=False, default=None)
@click.option("--list", "-l", "list_flag", is_flag=True, help="List all sessions with metadata.")
@click.option("--show", "show_flag", is_flag=True, help="Show the full chat history of a session.")
@click.option("--delete", "delete_flag", is_flag=True, help="Delete a session.")
@click.option("--all", "all_flag", is_flag=True, help="Used with --delete to remove all sessions.")
@click.option(
    "--ai", "ai_choice",
    type=click.Choice(["gemini", "openai", "ollama"], case_sensitive=False),
    default=None,
    help="AI provider for resume (defaults to what was saved in the session).",
)
@click.option("--key", envvar="API_KEY", default=None, help="API key (or set API_KEY in .env).")
@click.option("--lang", default=None, help="Language override for resume (defaults to what was saved).")
@click.pass_context
def session_cmd(ctx, name, action, list_flag, show_flag, delete_flag, all_flag, ai_choice, key, lang):
    """Manage saved chat sessions.

    \b
    List all sessions:
        gitputra session --list
    \b
    Show chat history:
        gitputra session <name> --show
    \b
    Resume a session (re-indexes if codebase changed):
        gitputra session <name> resume
        gitputra session <name> resume --ai gemini --key AIza...
    \b
    Delete one session:
        gitputra session --delete <name>
    \b
    Delete ALL sessions:
        gitputra session --delete --all
    """

    # ── --list ────────────────────────────────────────────────────────────────
    if list_flag:
        files = _list_session_files()
        if not files:
            console.print("📭 No saved sessions found.", style="yellow")
            console.print(
                "   Start a chat and use [bold orange1]--save-session NAME[/bold orange1] to create one.",
                style="dim",
            )
            return

        table = Table(title="💾 Saved Chat Sessions", show_lines=True, header_style="bold cyan")
        table.add_column("#",             style="dim",         width=4)
        table.add_column("Name",          style="bold cyan",   no_wrap=True)
        table.add_column("Codebase Path", style="bright_blue", overflow="fold")
        table.add_column("Branch",        style="magenta")
        table.add_column("AI",            style="green")
        table.add_column("Lang",          style="yellow")
        table.add_column("Turns",         style="yellow",      justify="right")
        table.add_column("Saved At",      style="dim")
        table.add_column("Index?",        style="dim",         justify="center")

        for idx, filename in enumerate(files, start=1):
            fpath = os.path.join(SESSIONS_DIR, filename)
            sess_name = filename[:-5]
            try:
                with open(fpath, "r", encoding="utf-8") as f:
                    data = json.load(f)
                repo_path    = data.get("repo_path", data.get("repo", "—"))
                branch       = data.get("branch") or "—"
                ai           = data.get("ai", "—")
                saved_lang   = data.get("lang", "—")
                saved_at     = data.get("saved_at", "—")
                turns        = sum(1 for m in data.get("turns", []) if m.get("role") == "user")
                stored_hash  = data.get("codebase_hash", "")
                current_hash = _hash_codebase(repo_path)
                if not os.path.isdir(repo_path):
                    index_ok = "[bold red]✗ missing[/bold red]"
                elif stored_hash and current_hash != stored_hash:
                    index_ok = "[bold yellow]⚠ changed[/bold yellow]"
                else:
                    index_ok = "[bold green]✓[/bold green]"
            except Exception:
                repo_path = branch = ai = saved_lang = saved_at = "⚠ unreadable"
                turns = 0
                index_ok = "[red]?[/red]"

            table.add_row(str(idx), sess_name, repo_path, branch, ai, saved_lang, str(turns), saved_at, index_ok)

        console.print(table)
        console.print(
            "\n  Resume: [bold orange1]gitputra session \"NAME\" resume[/bold orange1]",
            style="dim",
        )
        return

    # ── --delete ──────────────────────────────────────────────────────────────
    if delete_flag:
        if all_flag:
            files = _list_session_files()
            if not files:
                console.print("📭 No sessions to delete.", style="yellow")
                return
            if not click.confirm(f"⚠️  Permanently delete all {len(files)} session(s)?", default=False):
                console.print("Aborted.", style="dim")
                return
            for filename in files:
                os.remove(os.path.join(SESSIONS_DIR, filename))
            console.print(f"🗑️  Deleted {len(files)} session(s).", style="bold yellow")
            return

        target = name
        if not target:
            console.print(
                "❌ Specify a session name or use [bold orange1]--all[/bold orange1] to delete everything.",
                style="bold red",
            )
            raise SystemExit(1)
        fpath = os.path.join(SESSIONS_DIR, f"{target}.json")
        if not os.path.exists(fpath):
            console.print(f"❌ Session '{target}' not found.", style="bold red")
            raise SystemExit(1)
        if not click.confirm(f"⚠️  Delete session '{target}'?", default=False):
            console.print("Aborted.", style="dim")
            return
        os.remove(fpath)
        console.print(f"🗑️  Session '{target}' deleted.", style="bold yellow")
        return

    # ── NAME --show ───────────────────────────────────────────────────────────
    if show_flag:
        if not name:
            console.print("❌ Provide a session name: gitputra session NAME --show", style="bold red")
            raise SystemExit(1)
        try:
            sess = _load_session(name)
        except FileNotFoundError:
            console.print(f"❌ Session '{name}' not found.", style="bold red")
            raise SystemExit(1)

        repo_path  = sess.get("repo_path", sess.get("repo", "—"))
        branch     = sess.get("branch") or "—"
        ai         = sess.get("ai", "—")
        saved_lang = sess.get("lang", "—")
        saved_at   = sess.get("saved_at", "—")
        turns_raw  = sess.get("turns", [])
        turns      = sum(1 for m in turns_raw if m.get("role") == "user")

        console.print(
            f"\n[bold cyan]Session:[/bold cyan] {name}  │  "
            f"[bright_blue]Path:[/bright_blue] {repo_path}  │  "
            f"[magenta]Branch:[/magenta] {branch}  │  "
            f"[green]AI:[/green] {ai}  │  "
            f"[yellow]Lang:[/yellow] {saved_lang}  │  "
            f"[yellow]Turns:[/yellow] {turns}  │  "
            f"[dim]Saved:[/dim] {saved_at}\n"
        )

        if not turns_raw:
            console.print("(no messages in this session)", style="dim")
            return

        turn_num = 0
        for msg in turns_raw:
            role    = msg.get("role", "?")
            content = msg.get("content", "")
            if role == "user":
                turn_num += 1
                console.print(f"[bold cyan]▶ You  [{turn_num}][/bold cyan]")
                console.print(Panel(content, border_style="cyan", padding=(0, 2)))
            elif role == "assistant":
                console.print("[bold green]◈ AI[/bold green]")
                console.print(Panel(content, border_style="green", padding=(0, 2)))
            console.print()
        return

    # ── NAME resume ───────────────────────────────────────────────────────────
    if name and action == "resume":
        try:
            sess = _load_session(name)
        except FileNotFoundError:
            console.print(f"❌ Session '{name}' not found.", style="bold red")
            raise SystemExit(1)

        repo_path  = sess.get("repo_path", "")
        repo_name  = sess.get("repo") or (os.path.basename(os.path.normpath(repo_path)) if repo_path else "")
        branch     = sess.get("branch") or None
        # Prefer CLI override, then fall back to what was saved
        ai_choice  = ai_choice or sess.get("ai", "gemini")
        lang       = lang or sess.get("lang", "English")
        history    = sess.get("turns", [])
        stored_hash = sess.get("codebase_hash", "")

        console.print(
            f"\n📂 Resuming session [bold cyan]{name}[/bold cyan]\n"
            f"   Codebase : [bright_blue]{repo_path}[/bright_blue]\n"
            f"   AI       : [green]{ai_choice}[/green]\n"
            f"   Lang     : [yellow]{lang}[/yellow]\n"
            f"   Turns    : [yellow]{sum(1 for m in history if m.get('role') == 'user')}[/yellow]\n"
        )

        if not repo_path or not os.path.isdir(repo_path):
            console.print(
                f"❌ Codebase path no longer exists: {repo_path}\n"
                f"   Run [bold orange1]gitputra chat <path> --local --ai {ai_choice}[/bold orange1] instead.",
                style="bold red",
            )
            raise SystemExit(1)

        if not key:
            key = click.prompt("🔑 Enter API key (input hidden, press Enter when done)", hide_input=True)
            console.print("🔐 Key received", style="dim")
        core.init(ai_choice.lower(), key, lang)

        # Re-index if codebase changed since last save
        current_hash = _hash_codebase(repo_path)
        if stored_hash and current_hash != stored_hash:
            console.print(
                "⚠️  Codebase has changed since the session was saved — re-indexing…",
                style="bold yellow",
            )

        files = core.load_files(repo_path)
        if not files:
            console.print("❌ No supported source files found.", style="bold red")
            raise SystemExit(1)
        core.store_chunks(files, repo_name, branch)

        turns = sum(1 for m in history if m.get("role") == "user")
        console.print(
            f"\n💬 Chat resumed [{repo_name}] — {turns} turn(s) loaded. Type 'exit' to quit.\n",
            style="bold cyan",
        )

        ext = "NAMASKAR"

        def _do_exit():
            if history:
                saved = _save_session(name, history, repo_path, repo_name, branch, ai_choice, lang)
                console.print(f"✅ Session saved → [bold cyan]{saved}[/bold cyan]", style="bold green")
            console.print(f"[bold yellow]{ext}[/bold yellow]")

        while True:
            try:
                question = console.input("[bold cyan]>> [/bold cyan]")
            except (KeyboardInterrupt, click.Abort):
                _do_exit()
                break

            if question.strip().lower() in ("exit", "quit", "q"):
                _do_exit()
                break

            if not question.strip():
                continue

            if question.strip().lower() == "!switch":
                load_dotenv(override=True)
                new_key = os.getenv("API_KEY")
                if not new_key:
                    console.print("❌ No API_KEY found in .env", style="bold red")
                    continue
                core.init(ai_choice.lower(), new_key, lang)
                console.print("✅ Key reloaded, quota reset. Chat history preserved.", style="bold green")
                continue

            if question.strip().lower() == "!save":
                if not history:
                    console.print("⚠️  Nothing to save yet.", style="bold yellow")
                    continue
                saved = _save_session(name, history, repo_path, repo_name, branch, ai_choice, lang, timestamped=True)
                console.print(f"💾 Snapshot saved → [bold cyan]{saved}[/bold cyan]", style="green")
                continue

            answer = core.query_rag(question, repo_name, branch, history=history)
            console.print(f"\n[bold green]◈[/bold green] {answer}\n")

            history.append({"role": "user",      "content": question})
            history.append({"role": "assistant", "content": answer})

        return

    # ── fallback ──────────────────────────────────────────────────────────────
    console.print(
        "❌ Unknown usage. Try:\n"
        "   gitputra session --list\n"
        "   gitputra session NAME --show\n"
        "   gitputra session NAME resume\n"
        "   gitputra session --delete NAME\n"
        "   gitputra session --delete --all",
        style="bold red",
    )


# ─────────────────────────────────────────────
# CLEAR DB
# ─────────────────────────────────────────────
@main.command("clear-db")
def clear_db():
    """Wipe the local ChromaDB collection."""
    import chromadb
    animations.play_clear_db_vortex(frames=40, delay=0.05)
    client = chromadb.PersistentClient(path="./chroma_db")
    for col in client.list_collections():
        client.delete_collection(col.name)
    if os.path.isdir("./chroma_db"):
        for f in os.listdir("./chroma_db"):
            if f.endswith("_hashes.json"):
                os.remove(os.path.join("./chroma_db", f))
    console.print("🗑️  ChromaDB cleared.", style="bold yellow")


# ─────────────────────────────────────────────
# NUKE
# ─────────────────────────────────────────────
@main.command("nuke")
def nuke():
    """☢️ Obliterate ALL sessions and vector databases. No undo."""
    console.print()
    console.print("[bold white on red] ☢️  WARNING: NUCLEAR OPTION INITIATED ☢️ [/bold white on red]")
    console.print("\nThis will permanently destroy:", style="bold yellow")
    console.print(f"  [bold red]1.[/bold red] ALL saved chat sessions in {SESSIONS_DIR}")
    console.print("  [bold red]2.[/bold red] ALL ChromaDB vector indexes in ./chroma_db")
    console.print("  [bold red]3.[/bold red] ALL tracked file hashes\n")

    if not click.confirm("Are you absolutely certain you want to proceed?", default=False):
        console.print("\n[bold green]Nuke aborted. Stand down.[/bold green]")
        return

    captcha = "".join(random.choices(string.ascii_uppercase + string.digits, k=6))
    console.print(
        f"\n[bold red]To confirm, type this exact authorization code:[/bold red] [bold cyan]{captcha}[/bold cyan]"
    )
    user_input = click.prompt("Code", type=str)
    if user_input.strip() != captcha:
        console.print("\n[bold green]Authorization failed. Nuke aborted.[/bold green]")
        return

    console.print("\n[bold red]Detonating...[/bold red]\n")

    if os.path.exists(SESSIONS_DIR):
        shutil.rmtree(SESSIONS_DIR, ignore_errors=True)
        console.print("  💥 Sessions vaporized.")
    else:
        console.print("  💨 No sessions found.")

    db_path = os.path.abspath("./chroma_db")
    if os.path.exists(db_path):
        shutil.rmtree(db_path, ignore_errors=True)
        console.print("  💥 Vector database annihilated.")
    else:
        console.print("  💨 No local ChromaDB found.")

    console.print("\n[bold green]✅ Ground zero is clear. Gitputra has been completely reset.[/bold green]")


# ─────────────────────────────────────────────
# INFO
# ─────────────────────────────────────────────
@main.command()
def info():
    """Show supported AIs, languages, extensions, and commands."""
    animations.play_info_intro()

    table = Table(title="📦 GitPutra Info", show_lines=True)
    table.add_column("Field", style="cyan", no_wrap=True)
    table.add_column("Details", style="yellow")
    table.add_row("🤖 Description", "[bold magenta]Chat with your codebase using Gemini or OpenAI[/bold magenta]")
    table.add_row("🏷️ Version", "[bold magenta]0.3.1[/bold magenta]")
    table.add_row("👨‍💻 Author", "[bold bright_blue]   Adityava Gangopadhyay[/bold bright_blue]")
    table.add_row("💼 Email", "[bold bright_blue]adityava49cse@gmail.com[/bold bright_blue]")
    table.add_row("🔗 LinkedIn", "[bold #FFA500]https://www.linkedin.com/in/adityava-gangopadhyay/[/bold #FFA500]")
    table.add_row("📦 Project URL", "[bold #FFA500]https://pypi.org/project/gitputra/[/bold #FFA500]")
    console.print(table)

    console.print("   💬 Special Message-> Feel free to contact for any suggestion or issues\n", style="bold blue")
    console.print("📦 Commands:", style="bold yellow")

    console.print("[bold orange1]analyze <url>[/bold orange1]", " || ", "[bold bright_blue]Clone & analyze a remote GitHub repo without AI[/bold bright_blue]", style="bold blue")
    console.print("[bold orange1]analyze <url> --ai ai_name[/bold orange1]", " || ", "[bold bright_blue]Clone & analyze a remote GitHub repo with AI insights[/bold bright_blue]", style="bold blue")
    console.print("[bold orange1]analyze <path> --local[/bold orange1]", " || ", "[bold bright_blue]Analyze a local codebase (no cloning)[/bold bright_blue]", style="bold blue")
    console.print("[bold orange1]analyze <path> --local --ai ai_name[/bold orange1]", " || ", "[bold bright_blue]Analyze a local codebase (no cloning) with AI insights[/bold bright_blue]", style="bold blue")
    console.print("[bold orange1]chat <url> --ai ai_name[/bold orange1]", " || ", "[bold bright_blue]Chat with AI_Putra about a remote GitHub repo[/bold bright_blue]", style="bold blue")
    console.print("[bold orange1]chat <path> --local --ai ai_name[/bold orange1]", " || ", "[bold bright_blue]Chat about a local codebase[/bold bright_blue]", style="bold blue")
    console.print("[bold orange1]session --list[/bold orange1]", " || ", "[bold bright_blue]List all saved chat sessions with metadata[/bold bright_blue]", style="bold blue")
    console.print("[bold orange1]session <name> resume[/bold orange1]", " || ", "[bold bright_blue]Resume a session (auto re-indexes if codebase changed)[/bold bright_blue]", style="bold blue")
    console.print("[bold orange1]session <name> --show[/bold orange1]", " || ", "[bold bright_blue]Display full chat history for a session[/bold bright_blue]", style="bold blue")
    console.print("[bold orange1]session --delete <name>[/bold orange1]", " || ", "[bold bright_blue]Delete a saved session[/bold bright_blue]", style="bold blue")
    console.print("[bold orange1]session --delete --all[/bold orange1]", " || ", "[bold bright_blue]Delete ALL saved sessions[/bold bright_blue]", style="bold blue")
    console.print("[bold orange1]visualize[/bold orange1]", " || ", "[bold bright_blue]Generate an interactive 3D Code Galaxy[/bold bright_blue]", style="bold blue")
    console.print("[bold orange1]visualize --self-map[/bold orange1]", " || ", "[bold bright_blue]🚀 Easter Egg: 3D map of GitPutra's internal RAG pipeline[/bold bright_blue]", style="bold blue")
    console.print("[bold orange1]export-context[/bold orange1]", " || ", "[bold bright_blue]Export portable context .md from the current directory[/bold bright_blue]", style="bold blue")
    console.print("[bold orange1]export-context <path>[/bold orange1]", " || ", "[bold bright_blue]Export context .md from a local path[/bold bright_blue]", style="bold blue")
    console.print("[bold orange1]export-context <url> --remote[/bold orange1]", " || ", "[bold bright_blue]Export context .md from a remote GitHub repo[/bold bright_blue]", style="bold blue")
    console.print("[bold orange1]diff <url> --base <ref> --head <ref>[/bold orange1]", " || ", "[bold bright_blue]Compare two branches/commits and get an AI summary[/bold bright_blue]", style="bold blue")
    console.print("[bold orange1]diff <path> --local --base <ref> --head <ref>[/bold orange1]", " || ", "[bold bright_blue]Same as above but for a local repo[/bold bright_blue]", style="bold blue")
    console.print("[bold orange1]show-graph[/bold orange1]", " || ", "[bold bright_blue]Render git branch timeline in the terminal[/bold bright_blue]", style="bold blue")
    console.print("[bold orange1]clear-db[/bold orange1]", " || ", "[bold bright_blue]Wipe the local ChromaDB index[/bold bright_blue]", style="bold blue")
    console.print("[bold orange1]nuke[/bold orange1]", " || ", "[bold red]☢️  Nuclear Option: Wipe ALL sessions, DBs, and hashes[/bold red]", style="bold blue")
    console.print("[bold orange1]info[/bold orange1]", " || ", "[bold bright_blue]Show this info screen[/bold bright_blue]", style="bold blue")
    console.print("[bold orange1]!switch[/bold orange1]", " || ", "[bold bright_blue]In chat: reload API_KEY from .env (quota reset, history preserved)[/bold bright_blue]", style="bold blue")
    console.print("[bold orange1]!save[/bold orange1]", " || ", "[bold bright_blue]In chat: snapshot the current session to disk[/bold bright_blue]", style="bold blue")

    console.print("\n🤖 Supported AI Providers:", style="bold yellow")
    ais = [
        ("gemini", "Google Gemini 2.5 Flash",  "gemini-embedding-001"),
        ("openai", "OpenAI GPT-4o Mini",        "text-embedding-3-large"),
    ]
    ai_table = Table(title="🤖 Supported AI Providers")
    ai_table.add_column("Flag", style="cyan")
    ai_table.add_column("Model", style="green")
    ai_table.add_column("Embedding", style="magenta")
    for flag, model, embed in ais:
        ai_table.add_row(flag, model, embed)
    console.print(ai_table)

    table = Table(title="🌍 PDF Output Languages (~110 supported)", show_lines=True)
    table.add_column("Script", style="bold cyan", no_wrap=True)
    table.add_column("Languages", style="white")

    latin = [
        "English", "French", "Spanish", "Portuguese", "Italian", "German",
        "Dutch", "Swedish", "Norwegian", "Danish", "Finnish", "Polish",
        "Czech", "Slovak", "Hungarian", "Romanian", "Croatian", "Serbian (Latin)",
        "Slovenian", "Albanian", "Lithuanian", "Latvian", "Estonian",
        "Turkish", "Azerbaijani", "Uzbek", "Kazakh (Latin)", "Turkmen",
        "Indonesian", "Malay", "Filipino", "Swahili", "Zulu", "Xhosa",
        "Afrikaans", "Yoruba", "Igbo", "Hausa", "Somali", "Kinyarwanda",
        "Welsh", "Irish", "Basque", "Catalan", "Galician", "Maltese",
        "Icelandic", "Faroese", "Vietnamese", "Hawaiian", "Maori",
        "Tok Pisin", "Tswana", "Shona", "Sesotho",
    ]
    bangla      = ["Bangla", "Assamese"]
    devanagari  = ["Hindi", "Marathi", "Nepali", "Sanskrit", "Maithili", "Konkani", "Bodo", "Dogri"]

    table.add_row("Latin script",      ", ".join(latin))
    table.add_row("Bangla script",     " | ".join(bangla))
    table.add_row("Devanagari script", " | ".join(devanagari))
    console.print(table)

    console.print("\n(AI response language depends on the chosen model's capability)\n\n", style="dim")

    ext_table = Table(title=f"📁 Supported File Extensions ({len(core.SUPPORTED_EXT)} types)")
    ext_table.add_column("Extensions", style="cyan", overflow="fold")
    exts = sorted(core.SUPPORTED_EXT)
    chunk_size = 10
    for i in range(0, len(exts), chunk_size):
        ext_table.add_row(", ".join(exts[i:i + chunk_size]))
    console.print(ext_table)

    console.print(
        "\n[bold blue]AI is ARTIFICIALLY Intelligent[/bold blue], \n"
        "[bold yellow]YOU are NATURALLY WISE,[/bold yellow] \n"
        "use the tool but try to keep track on the correctness of the results produced",
        style="bold red",
    )
    console.print("\n\nTHANK YOU FOR USING GITPUTRA", style="bold orange1")
    click.echo()