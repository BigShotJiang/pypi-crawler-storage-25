import subprocess
import platform
import os
from datetime import datetime

class Notifier:
    @staticmethod
    def send(title, message):
        success = False
        system = platform.system().lower()
        prefix = os.environ.get("PREFIX", "/data/data/com.termux/files/usr")
        is_termux = "termux" in prefix.lower()

        try:
            if is_termux:
                # Use absolute path to guarantee it works in the background
                bin_path = f"{prefix}/bin/termux-notification"
                if not os.path.exists(bin_path): bin_path = "termux-notification"
                
                res = subprocess.run([bin_path, "-t", title, "-c", message], capture_output=True)
                if res.returncode == 0: success = True
            
            elif system == "linux":
                res = subprocess.run(["notify-send", "-i", "network-server", title, message], capture_output=True)
                if res.returncode == 0: success = True
                
            elif system == "windows":
                ps_cmd = f'[Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms");$i=New-Object Windows.Forms.NotifyIcon;$i.Icon=[Drawing.SystemIcons]::Shield;$i.Visible=$True;$i.ShowBalloonTip(5000,"{title}","{message}",[Windows.Forms.ToolTipIcon]::Warning)'
                res = subprocess.run(["powershell", "-Command", ps_cmd], capture_output=True)
                if res.returncode == 0: success = True
                
            elif system == "darwin":
                cmd = f'display notification "{message}" with title "{title}"'
                res = subprocess.run(["osascript", "-e", cmd], capture_output=True)
                if res.returncode == 0: success = True

        except Exception:
            pass

        # If native notification fails, log it to a file silently (DO NOT PRINT)
        if not success:
            try:
                log_path = os.path.expanduser("~/.ssh_tower/security_alerts.log")
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                with open(log_path, "a") as f:
                    f.write(f"[{timestamp}] {title}: {message}\n")
            except:
                pass
