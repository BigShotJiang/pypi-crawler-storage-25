import sys
import os

# Add the site-packages path to sys.path so it works globally
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    # This must match the function name in tower/daemon.py
    from tower.daemon import start_daemon_standalone
    if __name__ == "__main__":
        start_daemon_standalone()
except Exception as e:
    print(f"CRITICAL LAUNCH ERROR: {e}")
