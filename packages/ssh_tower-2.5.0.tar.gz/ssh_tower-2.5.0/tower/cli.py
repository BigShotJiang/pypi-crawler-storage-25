import sys
import os
import getpass
import time
import subprocess
import signal
import threading
import argparse
import shutil

from tower.security import SecurityManager
from tower.scanner import NetworkScanner
from tower.ssh_manager import SSHSession
from tower.pairing import PairingSystem
from tower.pairing import GlobalPairing
from tower.daemon import TowerDaemon, run_daemon_debug

C = '\033[96m'
M = '\033[95m'
Y = '\033[93m'
G = '\033[92m'
R = '\033[91m'
B = '\033[94m'
W = '\033[97m'
BD = '\033[1m'
RS = '\033[0m'

sec_mgr = SecurityManager()
session = SSHSession(sec_mgr)
pairing = PairingSystem(sec_mgr)
global_pair_sys = GlobalPairing(sec_mgr)

def clear_screen():
    sys.stdout.write('\033[2J\033[H')
    sys.stdout.flush()

def draw_panel(title, lines, color=C, width=65):
    print(f"{color}╭─ {BD}{W}{title} {RS}{color}" + "─" * (width - len(title) - 4) + f"╮{RS}")
    for line in lines:
        raw_line = line.replace(C,'').replace(M,'').replace(Y,'').replace(G,'').replace(R,'').replace(B,'').replace(W,'').replace(BD,'').replace(RS,'')
        pad = width - len(raw_line) - 2
        print(f"{color}│ {RS}{line}" + " " * max(0, pad) + f"{color}│{RS}")
    print(f"{color}╰" + "─" * (width - 2) + f"╯{RS}")

def draw_input(prompt_text):
    return input(f"{BD}{Y}❯ {W}{prompt_text}{RS} ")

class PlaneSpinner:
    def __init__(self, message="Processing"):
        self.message = message
        self.running = False
        self.thread = None
        self.frames = ["✈        ", " ✈       ", "  ✈      ", "   ✈     ", "    ✈    ", "     ✈   ", "      ✈  ", "       ✈ ", "        ✈"]

    def _animate(self):
        i = 0
        while self.running:
            sys.stdout.write(f"\r{C}│ {W}{self.message} {M}[{self.frames[i % len(self.frames)]}]{RS}")
            sys.stdout.flush()
            i += 1
            time.sleep(0.1)

    def start(self):
        self.running = True
        self.thread = threading.Thread(target=self._animate, daemon=True)
        self.thread.start()

    def stop(self, success=True):
        self.running = False
        if self.thread:
            self.thread.join()
        status = f"{G}✔{RS}" if success else f"{R}✖{RS}"
        sys.stdout.write(f"\r{C}│ {W}{self.message} {status}{' ' * 20}\n")
        sys.stdout.flush()

def is_daemon_running():
    pid_file = os.path.expanduser("~/.ssh_tower/daemon.pid")
    if not os.path.exists(pid_file):
        return False, None
    try:
        with open(pid_file, "r") as f:
            pid = int(f.read().strip())
        os.kill(pid, 0)
        return True, pid
    except (ProcessLookupError, ValueError, OSError, OverflowError):
        if os.path.exists(pid_file):
            try: os.remove(pid_file)
            except: pass
        return False, None

def toggle_daemon():
    running, pid = is_daemon_running()
    if running:
        draw_panel("Daemon", [f"{Y}Stopping background service (PID: {pid})...{RS}"])
        try:
            os.kill(pid, 15)
            time.sleep(0.5)
            print(f"{C}│ {G}Service stopped.{RS}")
        except Exception as e:
            print(f"{C}│ {R}Error: {e}{RS}")
    else:
        draw_panel("Daemon", [f"{Y}Launching Background Alert Service...{RS}"])
        current_dir = os.path.dirname(os.path.abspath(__file__))
        parent_dir = os.path.dirname(current_dir)
        env = os.environ.copy()
        env["PYTHONPATH"] = parent_dir + os.pathsep + env.get("PYTHONPATH", "")
        debug_log_path = os.path.expanduser("~/.ssh_tower/daemon_debug.log")
        os.makedirs(os.path.dirname(debug_log_path), exist_ok=True)
        try:
            f_err = open(debug_log_path, "a")
            subprocess.Popen(
                [sys.executable, "-m", "tower.daemon_launcher"],
                stdout=f_err, stderr=f_err, env=env, start_new_session=True, cwd=parent_dir
            )
            spinner = PlaneSpinner("Verifying startup")
            spinner.start()
            for _ in range(6):
                time.sleep(0.5)
                running, _ = is_daemon_running()
                if running: break
            if running:
                spinner.stop(True)
                print(f"{C}│ {G}Service is now ACTIVE!{RS}")
            else:
                spinner.stop(False)
                print(f"{C}│ {R}Service failed to start.{RS}")
        except Exception as e:
            print(f"{C}│ {R}Launcher error: {e}{RS}")

def check_and_prompt_install(bridge):
    if not bridge.is_installed():
        draw_panel("Dependency Missing", [f"{Y}Cloudflare (cloudflared) is required.{RS}"])
        choice = draw_input("Attempt auto-installation? (y/n):").strip().lower()
        if choice == 'y':
            success, msg = bridge.install_cloudflared()
            print(f"{C}│ {G if success else R}{msg}{RS}")
            return success
        return False
    return True

def global_wan_menu():
    from tower.bridge import TowerBridge
    bridge = TowerBridge()
    clear_screen()
    draw_panel("Global WAN Sharing", [
        f" {C}1{RS} Start Global Tunnel (Expose device)",
        f" {C}2{RS} Connect to a Global Tunnel",
        f" {C}3{RS} Back"
    ])
    choice = draw_input("Select").strip()

    if choice == "1":
        if not check_and_prompt_install(bridge): return
        if not pairing.ensure_password_set():
            print(f"{C}│ {R}Aborting: Password required.{RS}")
            return
        
        port_input = draw_input("Local SSH Port (Termux 8022):").strip()
        port = int(port_input) if port_input.isdigit() else 8022
        user = draw_input("SSH Username:")
        pwd = getpass.getpass(f"{BD}{Y}❯ {W}SSH Password: {RS}")

        ssh_running, ssh_msg = pairing.check_and_start_ssh(port)
        if not ssh_running:
            print(f"{C}│ {R}Error: {ssh_msg}{RS}")
            return

        spinner = PlaneSpinner("Launching Global Tunnel")
        spinner.start()
        success, url = bridge.start_tunnel(port)

        if success:
            tower_id = global_pair_sys.create_global_pin(url, user, pwd)
            spinner.stop(True)
            if tower_id:
                draw_panel("GLOBAL PAIRING ACTIVE", [
                    f"Share your Tower ID with the client:",
                    f"👉 {BD}{C}{tower_id}{RS}",
                    f"They can now connect globally."
                ], color=G)
                try:
                    draw_input("Press Enter to kill tunnel...")
                except KeyboardInterrupt: pass
                finally:
                    bridge.stop_tunnel()
            else:
                print(f"{C}│ {R}Relay Error.{RS}")
        else:
            spinner.stop(False)
            print(f"{C}│ {R}Cloudflare Failed: {url}{RS}")

    elif choice == "2":
        if not check_and_prompt_install(bridge): return
        tid = draw_input("Enter Tower ID (e.g., 123456-Name):").strip()
        if "-" not in tid:
            print(f"{C}│ {R}Invalid format.{RS}")
            return
        spinner = PlaneSpinner("Resolving Tower ID")
        spinner.start()
        success, data = global_pair_sys.resolve_global_id(tid)
        
        if success:
            spinner.stop(True)
            url, user, pwd = data['url'], data['user'], data['pass']
            local_bridge_port = 50001
            subprocess.run(["pkill", "-f", "cloudflared access"], capture_output=True)
            try:
                bridge_proc = subprocess.Popen(
                    ["cloudflared", "access", "tcp", "--hostname", url, "--url", f"localhost:{local_bridge_port}"],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
                )
                b_spinner = PlaneSpinner("Bridging Connection")
                b_spinner.start()
                time.sleep(4)
                b_spinner.stop(True)
                
                profile_name = f"Global_{user}"
                sec_mgr.add_profile(profile_name, "127.0.0.1", local_bridge_port, user, password=pwd)
                c_success, msg = session.connect(profile_name, sec_mgr.db["profiles"][profile_name])
                
                if c_success:
                    print(f"{C}│ {G}Global Link Established!{RS}")
                    time.sleep(1)
                    session_menu()
                else:
                    print(f"{C}│ {R}SSH Error: {msg}{RS}")
            finally:
                if 'bridge_proc' in locals():
                    bridge_proc.terminate()
        else:
            spinner.stop(False)
            print(f"{C}│ {R}Error: {data}{RS}")

def file_manager_menu():
    while True:
        clear_screen()
        draw_panel("File Manager", [
            f" {C}1{RS} List Files (Remote)",
            f" {C}2{RS} Download File",
            f" {C}3{RS} Upload File",
            f" {C}4{RS} Back"
        ], color=M)
        choice = draw_input("Select").strip()
        sftp = session.get_sftp()
        
        try:
            if choice == "1":
                path = draw_input("Remote Path (Default '.'):") or "."
                files = sftp.listdir(path)
                draw_panel(f"Files in {path}", [f" - {f}" for f in files[:15]] + (["..."] if len(files)>15 else []))
                draw_input("Press Enter...")
            elif choice == "2":
                rem = draw_input("Remote filename:")
                loc = draw_input("Save as (Local):")
                success, msg = session.download_file(rem, loc)
                print(f"{C}│ {G if success else R}{msg}{RS}")
                time.sleep(1.5)
            elif choice == "3":
                loc = draw_input("Local filename:")
                rem = draw_input("Save as (Remote):")
                success, msg = session.upload_file(loc, rem)
                print(f"{C}│ {G if success else R}{msg}{RS}")
                time.sleep(1.5)
            elif choice == "4":
                break
        except Exception as e:
            print(f"{C}│ {R}Error: {e}{RS}")
            time.sleep(1.5)

def broadcast_tools_menu():
    os_info = session.execute("uname -a")
    from tower.remote_ops import RemoteOps
    while True:
        clear_screen()
        draw_panel("Hardware Tools", [
            f" {C}1{RS} Capture Remote Photo",
            f" {C}2{RS} Get Remote GPS Location",
            f" {C}3{RS} System Information",
            f" {C}4{RS} Back"
        ])
        choice = draw_input("Select").strip()
        
        try:
            if choice == "1":
                spinner = PlaneSpinner("Capturing")
                spinner.start()
                session.execute(RemoteOps.get_camera_cmd(os_info))
                session.download_file("output.jpg", "remote_capture.jpg")
                spinner.stop(True)
                draw_input("Saved as 'remote_capture.jpg'. Press Enter...")
            elif choice == "2":
                spinner = PlaneSpinner("Requesting GPS")
                spinner.start()
                out = session.execute(RemoteOps.get_gps_cmd(os_info))
                spinner.stop(True)
                draw_panel("Location Data", str(out).splitlines()[:10])
                draw_input("Press Enter...")
            elif choice == "3":
                out = session.execute(RemoteOps.get_info_cmd())
                draw_panel("Sys Info", str(out).splitlines()[:10])
                draw_input("Press Enter...")
            elif choice == "4":
                break
        except Exception as e:
            print(f"{C}│ {R}Error: {e}{RS}")
            time.sleep(1.5)

def toggle_lockdown():
    prefix = os.environ.get("PREFIX", "/data/data/com.termux/files/usr")
    sshd_config = f"{prefix}/etc/ssh/sshd_config"
    import tower.gatekeeper
    gatekeeper_module_path = os.path.abspath(tower.gatekeeper.__file__)
    
    if not os.path.exists(sshd_config):
        print(f"{C}│ {R}Cannot find sshd_config. OpenSSH installed?{RS}")
        return

    try:
        with open(sshd_config, "r") as f:
            config = f.read()
        if "gatekeeper.py" in config:
            new_config = "\n".join([line for line in config.splitlines() if "gatekeeper.py" not in line and "AcceptEnv TOWER_TOKEN" not in line])
            with open(sshd_config, "w") as f:
                f.write(new_config)
            print(f"{C}│ {G}Device is now UNLOCKED.{RS}")
        else:
            with open(sshd_config, "a") as f:
                f.write(f"\nAcceptEnv TOWER_TOKEN\nForceCommand {sys.executable} {gatekeeper_module_path}\n")
            print(f"{C}│ {R}LOCKDOWN ACTIVE. Standard SSH blocked.{RS}")
        subprocess.run(["pkill", "sshd"], check=False)
        subprocess.run(["sshd"], check=False)
    except Exception as e:
        print(f"{C}│ {R}Error: {e}{RS}")

def scan_network_menu():
    clear_screen()
    draw_panel("Network Scanner", [f"{Y}Checking devices & ports...{RS}"])
    spinner = PlaneSpinner("Scanning")
    spinner.start()
    try:
        hosts = NetworkScanner.scan_network()
        spinner.stop(True)
        if not hosts:
            print(f"{C}│ {R}No online devices found.{RS}")
            return
        lines = [f"{'IP Address'.ljust(16)} {'Status'.ljust(15)} Hostname", "-" * 50]
        for h in hosts:
            p_str = f"OPEN ({','.join(map(str, h['ports']))})" if h['ports'] else "Closed"
            col = G if h['ports'] else R
            lines.append(f"{h['ip'].ljust(16)} {col}{p_str.ljust(15)}{RS} {h['hostname'][:15]}")
        draw_panel("Results", lines)
    except Exception as e:
        spinner.stop(False)
        print(f"{C}│ {R}Error: {e}{RS}")

def connect_ssh_menu():
    clear_screen()
    profiles = list(sec_mgr.db["profiles"].keys())
    if not profiles:
        draw_panel("Profiles", [f"{R}No profiles found.{RS}"])
        return
    
    lines = []
    for idx, p in enumerate(profiles):
        lines.append(f" {C}{idx}{RS} {p} ({sec_mgr.db['profiles'][p]['ip']})")
    draw_panel("Saved Profiles", lines)
    
    try:
        choice = int(draw_input("Select index:"))
        if 0 <= choice < len(profiles):
            name = profiles[choice]
            prof = sec_mgr.db["profiles"][name]
            spinner = PlaneSpinner(f"Connecting to {name}")
            spinner.start()
            success, msg = session.connect(name, prof)
            if success:
                spinner.stop(True)
                time.sleep(0.5)
                session_menu()
            else:
                spinner.stop(False)
                print(f"{C}│ {R}Failed: {msg}{RS}")
    except (ValueError, IndexError):
        print(f"{C}│ {R}Invalid selection.{RS}")

def session_menu():
    while session.connected:
        try:
            clear_screen()
            dur = int(time.time() - session.start_time)
            m, s = divmod(dur, 60)
            draw_panel("Active Session", [
                f"{G}► {session.current_user} @ {session.current_ip}{RS}",
                f"{Y}Duration: {m}m {s}s{RS}",
                "",
                f" {C}1{RS} Open Live Terminal",
                f" {C}2{RS} File Manager",
                f" {C}3{RS} Broadcast Tools",
                f" {C}4{RS} Execute Command",
                f" {C}5{RS} Freeze Device",
                f" {C}6{RS} Disconnect"
            ], color=B)
            
            choice = draw_input("Select").strip()
            if choice == "1":
                session.interactive_shell()
            elif choice == "2":
                file_manager_menu()
            elif choice == "3":
                broadcast_tools_menu()
            elif choice == "4":
                cmd = draw_input("Command:")
                out = session.execute(cmd)
                draw_panel("Output", str(out).splitlines()[:15])
                draw_input("Press Enter...")
            elif choice == "5":
                session.freeze_device()
                print(f"{C}│ {R}Device Frozen.{RS}")
                time.sleep(1)
            elif choice == "6":
                session.disconnect()
                print(f"{C}│ {Y}Disconnected.{RS}")
                time.sleep(1)
        except KeyboardInterrupt:
            continue

def add_profile_menu():
    clear_screen()
    draw_panel("Add Profile", [])
    name = draw_input("Profile Name:")
    ip = draw_input("IP Address:")
    port_str = draw_input("Port (22/8022):").strip()
    port = int(port_str) if port_str.isdigit() else 22
    user = draw_input("Username:")
    
    auth_type = ""
    while auth_type not in ["1", "2"]:
        auth_type = draw_input("Auth [1=Pass, 2=Key]:").strip()
    
    if auth_type == "1":
        pwd = getpass.getpass(f"{BD}{Y}❯ {W}Password: {RS}")
        sec_mgr.add_profile(name, ip, port, user, password=pwd)
    else:
        k_path = draw_input("Key Path:")
        sec_mgr.add_profile(name, ip, port, user, key_path=k_path)
    print(f"{C}│ {G}Profile Saved!{RS}")

def pairing_menu():
    clear_screen()
    draw_panel("AirDrop Pairing", [
        f" {C}1{RS} Host Session",
        f" {C}2{RS} Connect via Code",
        f" {C}3{RS} Back"
    ])
    choice = draw_input("Select").strip()
    
    if choice == "1":
        if not pairing.ensure_password_set(): return
        port_str = draw_input("Local SSH Port (8022):").strip()
        port = int(port_str) if port_str.isdigit() else 8022
        user = draw_input("Username:")
        pwd = getpass.getpass(f"{BD}{Y}❯ {W}Password: {RS}")
        
        run, msg = pairing.check_and_start_ssh(port)
        if not run:
            print(f"{C}│ {R}Error: {msg}{RS}")
            return
            
        try:
            pairing.start_host(port, user, pwd)
            draw_panel("HOSTING", [f"{Y}Waiting for connections...{RS}", f"Press Ctrl+C to stop."])
            while pairing.hosting:
                if pairing.pending_request_ip:
                    print(f"\n{C}│ {G}INCOMING REQUEST{RS}")
                    ans = draw_input(f"Accept {pairing.pending_request_ip}? (y/n):").strip().lower()
                    pairing.resolve_approval(ans == 'y')
                time.sleep(0.5)
        except KeyboardInterrupt:
            pass
        finally:
            pairing.stop_host()
            
    elif choice == "2":
        pin = draw_input("Enter 6-digit Code:").strip()
        if not pin: return
        spinner = PlaneSpinner("Searching network")
        spinner.start()
        success, data = pairing.connect_with_pin(pin)
        
        if success:
            spinner.stop(True)
            host, pt, usr, pwd, tip = data.get("hostname","Unk"), data.get("port",22), data.get("user"), data.get("password"), data.get("ip")
            sec_mgr.add_profile(f"{host}_{tip}", tip, pt, usr, password=pwd)
            if draw_input(f"Connect to {host}? (y/n):").strip().lower() == 'y':
                c_succ, msg = session.connect(f"{host}_{tip}", sec_mgr.db["profiles"][f"{host}_{tip}"])
                if c_succ: session_menu()
                else: print(f"{C}│ {R}Error: {msg}{RS}")
        else:
            spinner.stop(False)
            print(f"{C}│ {R}Error: {data}{RS}")

def handle_args():
    parser = argparse.ArgumentParser(description="SSH Tower Management Tool")
    parser.add_argument("--daemon", action="store_true", help="Start background daemon")
    parser.add_argument("--scan", action="store_true", help="Run network scan and exit")
    parser.add_argument("--lock", action="store_true", help="Activate Gatekeeper lockdown")
    parser.add_argument("--unlock", action="store_true", help="Deactivate Gatekeeper lockdown")
    
    if len(sys.argv) > 1:
        args = parser.parse_args()
        if args.daemon:
            TowerDaemon().start()
        elif args.scan:
            hosts = NetworkScanner.scan_network()
            for h in hosts: print(f"{h['ip']} - {h['hostname']} - Ports: {h['ports']}")
        elif args.lock:
            toggle_lockdown()
        elif args.unlock:
            toggle_lockdown()
        sys.exit(0)

def main():
    handle_args()
    while True:
        try:
            clear_screen()
            draw_panel("SSH Tower", [f"{Y}Advanced Remote Management{RS}"])
            
            d_run, _ = is_daemon_running()
            d_stat = f"{G}[ON]{RS}" if d_run else f"{R}[OFF]{RS}"

            prefix = os.environ.get("PREFIX", "/data/data/com.termux/files/usr")
            try:
                with open(f"{prefix}/etc/ssh/sshd_config", "r") as f:
                    l_stat = f"{R}[LOCKED]{RS}" if "gatekeeper.py" in f.read() else f"{G}[UNLOCKED]{RS}"
            except: l_stat = f"{G}[UNLOCKED]{RS}"

            opts = [
                f" {C}1{RS} Connect to Profile",
                f" {C}2{RS} Add Profile",
                f" {C}3{RS} Scan Network",
                f" {C}4{RS} AirDrop Pairing",
                f" {C}5{RS} Alert Daemon {d_stat}",
                f" {C}6{RS} Connection History",
                f" {C}7{RS} Toggle Lockdown {l_stat}",
                f" {C}8{RS} Global WAN Sharing",
                f" {C}9{RS} Exit"
            ]
            draw_panel("Main Menu", opts)

            try:
                choice = draw_input("Option:").strip()
            except (KeyboardInterrupt, EOFError):
                break

            if choice == "1": connect_ssh_menu()
            elif choice == "2": add_profile_menu(); draw_input("Press Enter...")
            elif choice == "3": scan_network_menu(); draw_input("Press Enter...")
            elif choice == "4": pairing_menu()
            elif choice == "5": toggle_daemon(); draw_input("Press Enter...")
            elif choice == "6":
                lines = []
                for h in sec_mgr.db["history"]: lines.append(f"{h['name'][:10]:<12} {h['ip']:<15} {h['duration']}")
                draw_panel("History", lines if lines else ["Empty"])
                draw_input("Press Enter...")
            elif choice == "7": toggle_lockdown(); draw_input("Press Enter...")
            elif choice == "8": global_wan_menu()
            elif choice == "9": break

        except KeyboardInterrupt:
            time.sleep(0.1)
            continue
        except Exception as e:
            print(f"\n{R}Fatal Error: {e}{RS}")
            time.sleep(2)

if __name__ == "__main__":
    main()
