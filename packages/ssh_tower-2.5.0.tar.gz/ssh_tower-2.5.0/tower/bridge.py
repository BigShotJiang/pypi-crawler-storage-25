import subprocess
import time
import re
import os
import platform

class TowerBridge:
    def __init__(self):
        self.tunnel_process = None
        self.public_url = None

    def is_installed(self):
        """Checks if cloudflared is available in the system path."""
        try:
            subprocess.run(["cloudflared", "--version"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
        except FileNotFoundError:
            return False

    def install_cloudflared(self):
        """Attempts to install cloudflared based on the operating system."""
        system = platform.system().lower()
        is_termux = "termux" in os.environ.get("PREFIX", "").lower()

        try:
            if is_termux:
                print("\033[93m[!] Termux detected. Running: pkg install cloudflared -y\033[0m")
                subprocess.run(["pkg", "install", "cloudflared", "-y"], check=True)
            elif system == "linux":
                print("\033[93m[!] Linux detected. Attempting installation via script...\033[0m")
                # Using the official Cloudflare install script for Linux
                cmd = "curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o cloudflared && chmod +x cloudflared && sudo mv cloudflared /usr/local/bin/"
                subprocess.run(cmd, shell=True, check=True)
            elif system == "windows":
                print("\033[93m[!] Windows detected. Attempting installation via winget...\033[0m")
                subprocess.run(["winget", "install", "Cloudflare.cloudflared"], check=True)
            else:
                return False, "Unsupported OS for auto-install. Please visit: https://github.com/cloudflare/cloudflared"
            
            return True, "Installation successful!"
        except Exception as e:
            return False, f"Installation failed: {e}"

    def start_tunnel(self, local_port):
        """Creates a public WAN tunnel using Cloudflare Quick Tunnels."""
        if not self.is_installed():
            return False, "NOT_INSTALLED"

        cmd = ["cloudflared", "tunnel", "--url", f"tcp://localhost:{local_port}"]
        try:
            self.tunnel_process = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, 
                text=True, bufsize=1, universal_newlines=True
            )
            
            start_time = time.time()
            while time.time() - start_time < 30:
                line = self.tunnel_process.stdout.readline()
                if not line: continue
                
                match = re.search(r"https://([a-z0-9-]+\.trycloudflare\.com)", line)
                if match:
                    self.public_url = match.group(1)
                    return True, self.public_url
            
            return False, "Timed out waiting for Cloudflare URL."
        except Exception as e:
            return False, str(e)

    def stop_tunnel(self):
        if self.tunnel_process:
            self.tunnel_process.terminate()
            subprocess.run(["pkill", "-f", "cloudflared"], capture_output=True)
            self.tunnel_process = None
