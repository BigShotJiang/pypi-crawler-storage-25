import socket
import platform
from concurrent.futures import ThreadPoolExecutor

# Expanded list of commonly used SSH and remote management ports
COMMON_SSH_PORTS = [22, 2222, 8022, 10022, 22222, 5022]

class NetworkScanner:
    @staticmethod
    def get_local_ip():
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"

    @staticmethod
    def get_arp_ips():
        """Reads the ARP table to find all online devices instantly."""
        ips = set()
        try:
            if platform.system() == "Linux" or "termux" in platform.release().lower():
                with open('/proc/net/arp') as f:
                    next(f) # Skip header
                    for line in f:
                        parts = line.split()
                        if len(parts) >= 4 and parts[3] != "00:00:00:00:00:00":
                            ips.add(parts[0])
        except Exception:
            pass
        return ips

    @staticmethod
    def scan_target(ip, is_in_arp, timeout=0.5):
        """Scans the expanded list of SSH ports on a given IP."""
        open_ports = []
        
        for port in COMMON_SSH_PORTS:
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(timeout)
                # 0 means the port is OPEN
                if s.connect_ex((ip, port)) == 0:
                    open_ports.append(port)
                s.close()
            except Exception:
                pass
                
        # Return device if it has open ports OR if we know it's online via ARP
        if open_ports or is_in_arp:
            try:
                hostname = socket.gethostbyaddr(ip)[0]
            except socket.herror:
                hostname = "Unknown Device"
            return {"ip": ip, "hostname": hostname, "ports": open_ports}
            
        return None

    @staticmethod
    def scan_network():
        local_ip = NetworkScanner.get_local_ip()
        if local_ip == "127.0.0.1":
            return []
            
        base_ip = ".".join(local_ip.split(".")[:-1]) + "."
        arp_ips = NetworkScanner.get_arp_ips()
        
        target_ips = set([f"{base_ip}{i}" for i in range(1, 255)])
        target_ips.update(arp_ips)
        
        active_hosts = []
        
        # 100 threads for aggressive, fast scanning
        with ThreadPoolExecutor(max_workers=100) as executor:
            futures = [executor.submit(NetworkScanner.scan_target, ip, ip in arp_ips) for ip in target_ips]
            for future in futures:
                result = future.result()
                if result:
                    active_hosts.append(result)
                    
        return sorted(active_hosts, key=lambda x: int(x['ip'].split('.')[-1]))
