import socket
import threading
import time
import subprocess
import os
from tower.notifier import Notifier

PID_FILE = os.path.expanduser("~/.ssh_tower/daemon.pid")

class TowerDaemon:
    def __init__(self, debug_mode=False):
        self.running = True
        self.known_pids = set()
        self.debug_mode = debug_mode
        self.last_alert_time = 0 # Track when we last sent a notification

    def log(self, msg):
        timestamp = time.strftime("%H:%M:%S")
        if self.debug_mode:
            print(f"[{timestamp}] {msg}")

    def save_pid(self):
        os.makedirs(os.path.dirname(PID_FILE), exist_ok=True)
        with open(PID_FILE, "w") as f:
            f.write(str(os.getpid()))

    def remove_pid(self):
        if os.path.exists(PID_FILE):
            try: os.remove(PID_FILE)
            except: pass

    def get_sshd_pids(self):
        """Finds all active sshd process IDs."""
        pids = set()
        try:
            output = subprocess.check_output(["pgrep", "sshd"]).decode()
            pids = set(output.split())
        except subprocess.CalledProcessError:
            pass
        except Exception as e:
            self.log(f"PID Scan Error: {e}")
        return pids

    def monitor_ssh(self):
        self.log("SSH Process Monitor Started (Anti-Spam Mode).")
        
        # Initialize
        self.known_pids = self.get_sshd_pids()
        self.log(f"Initial sshd PIDs (Ignored): {self.known_pids}")
        
        Notifier.send("Tower Security", "Background protection is now ACTIVE.")

        while self.running:
            try:
                current_pids = self.get_sshd_pids()
                new_sessions = current_pids - self.known_pids
                
                if new_sessions:
                    self.log(f"Detected {len(new_sessions)} new SSHD processes: {new_sessions}")
                    
                    # --- THE FIX: Debouncing / Throttling ---
                    current_time = time.time()
                    
                    # If we haven't sent an alert in the last 5 seconds...
                    if current_time - self.last_alert_time > 5:
                        self.log("*** ALERT TRIGGERED *** (Sending single notification)")
                        
                        msg = "New SSH login detected on your device."
                        Notifier.send("🚨 SSH Security Alert", msg)
                        
                        # Update the last alert time
                        self.last_alert_time = current_time
                    else:
                        self.log("Ignoring duplicate process forks (Throttled).")
                
                # Update our known PIDs
                self.known_pids = current_pids
                
            except Exception as e:
                self.log(f"Monitor Loop Error: {e}")
            
            time.sleep(2)

    def monitor_pairing(self):
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            server.bind(("0.0.0.0", 55555))
            server.listen(5)
            server.settimeout(2)
            while self.running:
                try:
                    client, addr = server.accept()
                    Notifier.send("🔗 Pairing Attempt", f"Device at {addr[0]} wants to pair!")
                    client.close()
                except socket.timeout:
                    continue
        except: pass
        finally: server.close()

    def start(self):
        if not self.debug_mode: self.save_pid()
        threading.Thread(target=self.monitor_ssh, daemon=True).start()
        threading.Thread(target=self.monitor_pairing, daemon=True).start()
        try:
            while self.running: time.sleep(1)
        except (KeyboardInterrupt, SystemExit):
            self.running = False
        finally:
            if not self.debug_mode: self.remove_pid()

def start_daemon_standalone():
    TowerDaemon(debug_mode=False).start()

def run_daemon_debug():
    TowerDaemon(debug_mode=True).start()
