import os
import json
import logging
from datetime import datetime
from cryptography.fernet import Fernet

# FIX: Was ~/.tower, now properly ~/.ssh_tower
HOME_DIR = os.path.expanduser("~/.ssh_tower")
os.makedirs(HOME_DIR, exist_ok=True)

DB_FILE = os.path.join(HOME_DIR, "tower_data.json")
KEY_FILE = os.path.join(HOME_DIR, "tower.key")
LOG_FILE = os.path.join(HOME_DIR, "tower.log")

class SecurityManager:
    def __init__(self):
        self.key = self._load_or_create_key()
        self.cipher = Fernet(self.key)
        self.db = self._load_db()

    def _load_or_create_key(self):
        if not os.path.exists(KEY_FILE):
            key = Fernet.generate_key()
            with open(KEY_FILE, "wb") as f: f.write(key)
        else:
            with open(KEY_FILE, "rb") as f: key = f.read()
        return key

    def _load_db(self):
        if not os.path.exists(DB_FILE):
            return {"profiles": {}, "history": []}
        with open(DB_FILE, "r") as f: return json.load(f)

    def save_db(self):
        with open(DB_FILE, "w") as f: json.dump(self.db, f, indent=4)

    def encrypt(self, data: str) -> str:
        return self.cipher.encrypt(data.encode()).decode()

    def decrypt(self, data: str) -> str:
        return self.cipher.decrypt(data.encode()).decode()

    def add_profile(self, name, ip, port, user, password=None, key_path=None):
        profile = {"ip": ip, "port": port, "user": user}
        if password: profile["password"] = self.encrypt(password)
        if key_path: profile["key_path"] = key_path
        self.db["profiles"][name] = profile
        self.save_db()


    def log_connection(self, name, ip, duration):
        entry = {"name": name, "ip": ip, "date": str(datetime.now()), "duration": duration}
        self.db["history"].insert(0, entry)
        self.db["history"] = self.db["history"][:10]
        self.save_db()
