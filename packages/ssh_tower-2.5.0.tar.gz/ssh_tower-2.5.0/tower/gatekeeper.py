import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from tower.notifier import Notifier

def verify():
    # Tower Client injects this exact signature when connecting
    provided_token = os.environ.get("TOWER_TOKEN")
    remote_ip = os.environ.get("SSH_CONNECTION", "Unknown_IP 0 0 0").split()[0]

    # If the token is missing or wrong, it means someone is using standard SSH
    if provided_token != "TOWER_AUTHORIZED_CLIENT_V1":
        Notifier.send("🚫 Unauthorized Access", f"Blocked standard SSH attempt from {remote_ip}")
        print("\n\033[91m[!] ACCESS DENIED: This device is locked by SSH Tower.")
        print("[!] Connect via the Tower Dashboard to gain access.\033[0m")
        sys.exit(1)

    # Success! Connection is coming from the Tower App.
    Notifier.send("✅ Tower Access", f"Tower Dashboard connected from {remote_ip}")
    
    # Launch Shell or Command
    original_cmd = os.environ.get("SSH_ORIGINAL_COMMAND")
    shell = os.environ.get("SHELL", "/data/data/com.termux/files/usr/bin/bash")
    
    if not os.path.exists(shell): shell = "/bin/sh" 
    
    if original_cmd:
        os.system(f"{shell} -c '{original_cmd}'")
    else:
        os.system(shell)

if __name__ == "__main__":
    verify()
