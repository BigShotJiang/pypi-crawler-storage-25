class RemoteOps:
    @staticmethod
    def get_camera_cmd(os_type):
        os_str = str(os_type).lower()
        
        # Check for Termux/Android specifically
        if "termux" in os_str or "android" in os_str:
            # Check if termux-api is installed
            return "command -v termux-camera-photo >/dev/null 2>&1 && termux-camera-photo -c 0 output.jpg || echo 'ERROR: termux-api not installed on remote device. Run: pkg install termux-api'"
        
        elif "linux" in os_str:
            return "command -v fswebcam >/dev/null 2>&1 && fswebcam --no-banner output.jpg || echo 'ERROR: fswebcam not installed on remote Linux device.'"
            
        return "echo 'Camera not supported on this architecture via CLI.'"

    @staticmethod
    def get_gps_cmd(os_type):
        os_str = str(os_type).lower()
        
        if "termux" in os_str or "android" in os_str:
            # Termux uses termux-location
            return "command -v termux-location >/dev/null 2>&1 && termux-location || echo 'ERROR: termux-api not installed on remote device. Run: pkg install termux-api'"
        
        elif "linux" in os_str:
            # Generic Linux often doesn't have a standard GPS CLI, nmcli is a best-effort for WiFi-based location
            return "command -v nmcli >/dev/null 2>&1 && nmcli device wifi list --rescan yes || echo 'GPS/nmcli not found on remote Linux device.'"
            
        return "echo 'GPS not supported on this architecture.'"

    @staticmethod
    def get_info_cmd():
        return "uname -a; uptime; df -h"
