import hashlib
import hmac
import logging
import time
from collections.abc import Mapping
from typing import Any

import orjson

from aiotrade._errors import ExchangeResponseError
from aiotrade._http import HttpClient
from aiotrade._protocols import ParamsType
from aiotrade._types import HttpMethod

DOMAIN_MAIN = "bybit"
TLD_MAIN = "com"


logger = logging.getLogger("aiotrade.bybit")


def _mask_headers(headers: dict[str, Any]) -> dict[str, Any]:
    masked: dict[str, Any] = {}
    for k, v in headers.items():
        if k in ("X-BAPI-API-KEY", "X-BAPI-SIGN"):
            masked[k] = v[:6] + "..." if isinstance(v, str) else "****"
        else:
            masked[k] = v
    return masked


class BybitHttpClient(HttpClient):
    """Bybit HTTP client."""

    def __init__(
        self,
        api_key: str | None = None,
        api_secret: str | None = None,
        testnet: bool = False,
        demo: bool = False,
        recv_window: int = 5000,
        referral_id: str | None = None,
    ) -> None:
        """Initialize HTTP client.

        Args:
            api_key: Trading API key
            api_secret: Trading API secret
            testnet: Use testnet instead of mainnet
            demo: Use demo trading
            recv_window: Receive window in milliseconds
            referral_id: Referral ID
        """
        # Subdomain selection based on testnet and demo flags
        if demo and testnet:
            sub = "api-demo-testnet"
        elif demo:
            sub = "api-demo"
        elif testnet:
            sub = "api-testnet"
        else:
            sub = "api"
        base_url = f"https://{sub}.{DOMAIN_MAIN}.{TLD_MAIN}"

        self.referral_id = referral_id
        self.api_key = api_key
        self.api_secret = api_secret

        super().__init__(base_url, recv_window=recv_window)

    def _generate_signature(
        self, api_key: str, api_secret: str, payload: str, timestamp: int
    ) -> str:
        """Bybit V5 signature (API v5).

        Signature is generated as:
        HMAC_SHA256(apiSecret, timestamp + apiKey + recvWindow + payload)
        - For GET: payload is the sorted query string.
        - For POST: payload is the plain JSON string.
        """
        param_str = str(timestamp) + api_key + str(self.recv_window) + payload
        return hmac.new(
            api_secret.encode("utf-8"),
            param_str.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()

    def _prepare_payload(self, method: HttpMethod, params: dict[str, Any]) -> str:
        def cast_values() -> None:
            string_params = [
                "qty",
                "price",
                "triggerPrice",
                "takeProfit",
                "stopLoss",
            ]
            integer_params = ["positionIdx"]
            for key, value in params.items():
                if key in string_params:
                    if not isinstance(value, str):
                        params[key] = str(value)
                elif key in integer_params and not isinstance(value, int):
                    params[key] = int(value)

        if method == "GET":
            return "&".join(
                f"{k}={v}" for k, v in sorted(params.items()) if v is not None
            )
        cast_values()
        sanitized = {k: params[k] for k in sorted(params) if params[k] is not None}
        if not sanitized:
            return "{}"

        # Note: need Bybit logic for signature
        # serialization must match server expectations
        return orjson.dumps(sanitized).decode().replace(":", ": ").replace(",", ", ")

    async def _build_request_args(
        self,
        method: HttpMethod,
        endpoint: str,
        params: ParamsType | None = None,
        headers: dict[str, str] | None = None,
        auth: bool = False,
        use_params_as_query: bool = False,
        base_url: str | None = None,
    ) -> tuple[
        dict[str, Any],
        str,
        dict[str, Any] | None,
        list[dict[str, Any]] | dict[str, Any] | None,
        dict[str, Any] | str | None,
    ]:
        # Fast path: avoid unnecessary checks and recomputation
        if self._session.closed:
            session_type = "shared" if self._shared_session else "individual"
            raise RuntimeError(
                f"Session is closed ({session_type}). Create a new HttpClient instance."
            )
        if params is not None and not isinstance(params, Mapping):
            raise TypeError(
                "BingX client does not support list params for 'params'. "
                "Only dict is supported."
            )

        # Prefer local assignment for micro-speed-up
        params = dict(params) if params is not None else {}
        req_headers = headers if headers is not None else {}

        # Optimize timestamp retrieval
        timestamp = int(time.time() * 10**3)

        # Cheap check for referral
        if self.referral_id is not None:
            req_headers["Referer"] = self.referral_id

        # Fast payload prep
        req_payload = self._prepare_payload(method, params)

        # Quickly handle signature/auth
        if auth:
            if not (self.api_key and self.api_secret):
                raise ValueError(
                    "API key and API secret must be set for authenticated requests."
                )
            signature = self._generate_signature(
                self.api_key, self.api_secret, req_payload, timestamp
            )
            req_headers["X-BAPI-API-KEY"] = self.api_key
            req_headers["X-BAPI-SIGN"] = signature
            req_headers["X-BAPI-SIGN-TYPE"] = "2"
            req_headers["X-BAPI-TIMESTAMP"] = str(timestamp)
            req_headers["X-BAPI-RECV-WINDOW"] = str(self.recv_window)

        else:
            signature = None

        req_url = f"{base_url if base_url else self.base_url}{endpoint}"

        if method == "GET":
            req_url = f"{req_url}?{req_payload}" if req_payload else req_url
            req_json = None
        else:
            req_json = {k: params[k] for k in sorted(params) if params[k] is not None}

        # Logging fast, avoid joining or formatting unnecessarily unless debug
        if self.verbose:
            logger.debug(
                "Making async %s request to %s with params: %s", method, req_url, params
            )

        return (req_headers, req_url, None, req_json, None)

    async def _async_request(
        self,
        method: HttpMethod,
        endpoint: str,
        params: ParamsType | None = None,
        headers: dict[str, str] | None = None,
        auth: bool = False,
        use_params_as_query: bool = False,
        base_url: str | None = None,
    ) -> dict[str, Any]:
        (
            req_headers,
            req_url,
            req_params,
            req_json,
            req_data,
        ) = await self._build_request_args(
            method, endpoint, params, headers, auth, use_params_as_query, base_url
        )

        if self.verbose:
            logger.info(
                "Request args: method=%s, headers=%r, url=%r, params=%r, "
                "json=%r, data=%r, base_url=%r",
                method,
                req_headers,
                req_url,
                req_params,
                req_json,
                req_data,
                base_url,
            )

        async with self._session.request(
            method,
            req_url,
            params=req_params,
            json=req_json,
            data=req_data,
            headers=req_headers,
        ) as resp:
            try:
                resp.raise_for_status()
                res_json: dict[str, Any] = await resp.json(content_type=None)
                if res_json.get("retCode") != 0:
                    raise ExchangeResponseError("bybit", res_json)
            except ExchangeResponseError as err:
                if logger.isEnabledFor(logging.ERROR):
                    logger.error(
                        f"[ExchangeResponseError] method={method} | "
                        f"url={req_url} | "
                        f"headers={_mask_headers(req_headers)} | "
                        f"status={resp.status} | "
                        f"error={err}"
                    )
                raise
            except Exception as err:
                if logger.isEnabledFor(logging.ERROR):
                    logger.error(
                        f"[HTTP Error] method={method} | "
                        f"url={req_url} | "
                        f"headers={_mask_headers(req_headers)} | "
                        f"status={resp.status} | "
                        f"err={err!r}"
                    )
                raise
        return res_json
