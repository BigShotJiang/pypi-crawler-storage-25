"""Rules engine — evaluates regex, file-policy, and AST rules against repository files."""

from __future__ import annotations

import ast
import logging
import re
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable

from guard.core.models import Evidence, Finding, Severity
from guard.core.repo_reader import list_files
from guard.rules.rule_schema import RuleDefinition

if TYPE_CHECKING:
    from guard.core.cache import ScanCache

logger = logging.getLogger(__name__)


class RulesEngine:
    def __init__(self, rules: list[dict[str, Any]], max_workers: int = 1):
        self._rules = rules
        self._max_workers = max(1, max_workers)
        self.files_scanned: int = 0

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def evaluate(
        self,
        repo_root: str,
        changed_files: list[str] | None = None,
        cache: ScanCache | None = None,
        scan_exclude: list[str] | None = None,
        project_languages: list[str] | None = None,
        progress_callback: Callable[[int, int], None] | None = None,
    ) -> list[Finding]:
        """Evaluate all rules against the repo and return findings.

        When *cache* is provided, files whose content and rules haven't
        changed are served from cache instead of being re-evaluated.

        When ``max_workers > 1``, files within each rule are evaluated
        in parallel using a thread pool.

        When *project_languages* is provided, documentation obligation
        rules with ``applies_when`` conditions are skipped if the
        project doesn't match.
        """
        from guard.core.cache import content_hash as _content_hash
        from guard.core.cache import rules_hash as _rules_hash

        findings: list[Finding] = []
        root = Path(repo_root)
        r_hash = _rules_hash(self._rules) if cache else ""
        cache_lock = threading.Lock() if cache and self._max_workers > 1 else None
        all_files: set[str] = set()

        # Per-file progress tracking
        _SKIP_TYPES = {"documentation_obligation", "requirement_verification", "llm"}
        done = [0]
        total = [0]
        p_lock = threading.Lock() if self._max_workers > 1 else None

        if progress_callback:
            for _rd in self._rules:
                _r = _validate_rule(_rd)
                if _r is None or _r.type in _SKIP_TYPES:
                    continue
                total[0] += len(_collect_files(root, _r.file_glob, changed_files, scan_exclude))

        def _tick() -> None:
            if not progress_callback or total[0] == 0:
                return
            if p_lock:
                with p_lock:
                    done[0] += 1
                    progress_callback(done[0], total[0])
            else:
                done[0] += 1
                progress_callback(done[0], total[0])

        for rule_dict in self._rules:
            rule = _validate_rule(rule_dict)
            if rule is None:
                continue

            # Documentation obligations are project-level, not per-file
            if rule.type == "documentation_obligation":
                if _obligation_applies(rule, root, project_languages):
                    findings.append(_evaluate_documentation_obligation(rule))
                continue

            # Requirement verification is project-level (reads requirements.yaml + source)
            if rule.type == "requirement_verification":
                findings.extend(_evaluate_requirement_verification(rule, root))
                continue

            # LLM rules: per-file when an LLM is configured, obligation when not
            if rule.type == "llm":
                llm = _get_configured_llm()
                if llm is None:
                    # No LLM configured — surface as informational obligation
                    if _obligation_applies(rule, root, project_languages):
                        ob = _evaluate_documentation_obligation(rule)
                        # Override message to indicate LLM would enforce this
                        ob = ob.model_copy(update={
                            "message": f"[LLM required] {ob.message}",
                            "suggestion": (
                                f"{rule.remediation_guidance or ''}\n\n"
                                "Configure an LLM provider (sentrik.llmProvider in VS Code, "
                                "or GUARD_LLM_PROVIDER env var) for automated enforcement."
                            ).strip(),
                        })
                        findings.append(ob)
                else:
                    paths = _collect_files(root, rule.file_glob, changed_files, scan_exclude)
                    all_files.update(paths)
                    for rel_path in paths:
                        findings.extend(_evaluate_llm_rule(rule, root, rel_path, llm))
                continue

            paths = _collect_files(root, rule.file_glob, changed_files, scan_exclude)
            all_files.update(paths)

            if self._max_workers > 1 and len(paths) > 1:
                rule_findings = _evaluate_rule_parallel(
                    rule, root, paths, cache, r_hash,
                    _content_hash, self._max_workers, cache_lock,
                    tick=_tick,
                )
                findings.extend(rule_findings)
            else:
                for rel_path in paths:
                    file_findings = _evaluate_single_file(
                        rule, root, rel_path, cache, r_hash, _content_hash,
                    )
                    findings.extend(file_findings)
                    _tick()

        self.files_scanned = len(all_files)
        return findings


# ------------------------------------------------------------------
# Private helpers
# ------------------------------------------------------------------


def _evaluate_single_file(
    rule: RuleDefinition,
    root: Path,
    rel_path: str,
    cache: ScanCache | None,
    r_hash: str,
    _content_hash: Any,
    cache_lock: threading.Lock | None = None,
) -> list[Finding]:
    """Evaluate a single file against a rule, with optional cache."""
    abs_path = root / rel_path
    try:
        content = abs_path.read_text(encoding="utf-8")
    except (UnicodeDecodeError, PermissionError, OSError):
        return []

    # Cache lookup (keyed by file + rule to avoid cross-rule collisions)
    c_hash = ""
    if cache is not None:
        c_hash = _content_hash(content)
        if cache_lock:
            with cache_lock:
                cached = cache.get(rel_path, c_hash, r_hash, rule_id=rule.id)
        else:
            cached = cache.get(rel_path, c_hash, r_hash, rule_id=rule.id)
        if cached is not None:
            return cached

    file_findings: list[Finding] = []
    if rule.type == "regex":
        file_findings = _evaluate_regex(rule, rel_path, content)
    elif rule.type == "file_policy":
        file_findings = _evaluate_file_policy(rule, rel_path, content)
    elif rule.type == "ast":
        file_findings = _evaluate_ast(rule, rel_path, content)
    elif rule.type == "required_pattern":
        file_findings = _evaluate_required_pattern(rule, rel_path, content)
    else:
        logger.warning("Unknown rule type %r in rule %s — skipped", rule.type, rule.id)

    # Cache store (keyed by file + rule)
    if cache is not None:
        if cache_lock:
            with cache_lock:
                cache.put(rel_path, c_hash, r_hash, file_findings, rule_id=rule.id)
        else:
            cache.put(rel_path, c_hash, r_hash, file_findings, rule_id=rule.id)

    return file_findings


def _evaluate_rule_parallel(
    rule: RuleDefinition,
    root: Path,
    paths: list[str],
    cache: ScanCache | None,
    r_hash: str,
    _content_hash: Any,
    max_workers: int,
    cache_lock: threading.Lock | None,
    tick: Callable[[], None] | None = None,
) -> list[Finding]:
    """Evaluate a rule against multiple files in parallel."""
    all_findings: list[Finding] = []

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(
                _evaluate_single_file, rule, root, rel_path,
                cache, r_hash, _content_hash, cache_lock,
            ): rel_path
            for rel_path in paths
        }
        for future in as_completed(futures):
            try:
                file_findings = future.result()
                all_findings.extend(file_findings)
            except (OSError, ValueError, KeyError):
                logger.warning(
                    "Error evaluating %s for rule %s",
                    futures[future], rule.id,
                )
            if tick:
                tick()

    return all_findings


def _validate_rule(rule_dict: dict[str, Any]) -> RuleDefinition | None:
    """Parse a dict into a RuleDefinition, returning None on failure."""
    try:
        return RuleDefinition(**rule_dict)
    except (ValueError, TypeError, KeyError):
        logger.warning("Invalid rule definition — skipped: %s", rule_dict)
        return None


def _collect_files(
    repo_root: Path,
    file_glob: str,
    changed_files: list[str] | None,
    scan_exclude: list[str] | None = None,
) -> list[str]:
    """Return files matching *file_glob*, optionally intersected with *changed_files*.

    *scan_exclude* is a list of path prefixes (e.g. ``["tests/", "demo/"]``)
    to skip.
    """
    if changed_files is not None and len(changed_files) == 0:
        return []

    all_matching = list_files(repo_root, file_glob)

    if scan_exclude:
        import os as _os
        # Normalise to forward-slash; lowercase on case-insensitive filesystems (Windows)
        _ci = _os.name == "nt"
        import fnmatch as _fnmatch
        prefixes = []
        for p in scan_exclude:
            p = p.replace("\\", "/")
            if p.startswith("./"):
                p = p[2:]
            if "*" not in p and "?" not in p:
                p = p.rstrip("/") + "/"
            prefixes.append(p.lower() if _ci else p)

        def _ex_match(f: str) -> bool:
            fn = f.replace("\\", "/")
            if fn.startswith("./"):
                fn = fn[2:]
            if _ci:
                fn = fn.lower()
            for px in prefixes:
                if "*" in px or "?" in px:
                    if "/" not in px:
                        if _fnmatch.fnmatch(fn.rsplit("/", 1)[-1], px):
                            return True
                    else:
                        if _fnmatch.fnmatch(fn, px):
                            return True
                else:
                    if fn.startswith(px) or fn == px.rstrip("/"):
                        return True
            return False

        all_matching = [f for f in all_matching if not _ex_match(f)]

    if changed_files is not None:
        changed_set = set(changed_files)
        # Normalise to forward-slash for comparison
        all_matching = [f for f in all_matching if f.replace("\\", "/") in changed_set or f in changed_set]

    return all_matching


def _regulatory_metadata(rule: RuleDefinition) -> dict:
    """Extract regulatory metadata fields from a rule for propagation to findings."""
    meta: dict = {}
    if rule.standard is not None:
        meta["standard"] = rule.standard
    if rule.clause is not None:
        meta["clause"] = rule.clause
    if rule.compliance_category is not None:
        meta["compliance_category"] = rule.compliance_category
    if rule.remediation_guidance is not None:
        meta["remediation_guidance"] = rule.remediation_guidance
    if rule.tags:
        meta["tags"] = rule.tags
    return meta


def _obligation_applies(
    rule: RuleDefinition,
    root: Path,
    project_languages: list[str] | None,
) -> bool:
    """Check whether a documentation obligation's applies_when conditions are met.

    If no applies_when is set, the obligation always applies (backward compatible).

    Supported conditions:
    - languages: list of language names — at least one must be in the project
    - has_files: list of glob patterns — at least one must match a file in the repo
    - has_imports: list of module names — at least one must appear in an import statement
    """
    conditions = rule.applies_when
    if not conditions:
        return True

    # Check language condition
    required_langs = conditions.get("languages")
    if required_langs and isinstance(required_langs, list):
        if not project_languages:
            return False
        if not any(lang in project_languages for lang in required_langs):
            return False

    # Check file existence condition
    required_files = conditions.get("has_files")
    if required_files and isinstance(required_files, list):
        found_any = False
        for pattern in required_files:
            if any(root.glob(pattern)):
                found_any = True
                break
        if not found_any:
            return False

    # Check import condition (lightweight grep for import statements)
    required_imports = conditions.get("has_imports")
    if required_imports and isinstance(required_imports, list):
        found_any = False
        for py_file in root.rglob("*.py"):
            if found_any:
                break
            try:
                content = py_file.read_text(encoding="utf-8", errors="ignore")
                for module in required_imports:
                    if f"import {module}" in content or f"from {module}" in content:
                        found_any = True
                        break
            except OSError:
                continue
        if not found_any:
            return False

    # Check dependency condition (requirements.txt, pyproject.toml, package.json, go.mod)
    required_deps = conditions.get("has_dependencies")
    if required_deps and isinstance(required_deps, list):
        dep_content = _read_dependency_files(root)
        if not any(dep.lower() in dep_content for dep in required_deps):
            return False

    # Check config/file-content condition (any file contains a pattern)
    required_content = conditions.get("has_content")
    if required_content and isinstance(required_content, list):
        found_any = False
        for pattern_str in required_content:
            try:
                pat = re.compile(pattern_str, re.IGNORECASE)
            except re.error:
                continue
            for src_file in root.rglob("*"):
                if found_any:
                    break
                if not src_file.is_file() or src_file.stat().st_size > 500_000:
                    continue
                if src_file.suffix in {".pyc", ".pyo", ".exe", ".dll", ".so", ".dylib", ".whl", ".tar", ".gz", ".zip"}:
                    continue
                try:
                    text = src_file.read_text(encoding="utf-8", errors="ignore")
                    if pat.search(text):
                        found_any = True
                except (OSError, UnicodeDecodeError):
                    continue
            if found_any:
                break
        if not found_any:
            return False

    return True


def _read_dependency_files(root: Path) -> str:
    """Read common dependency manifest files and return combined lowercase content."""
    dep_files = [
        "requirements.txt", "requirements-dev.txt", "requirements-test.txt",
        "pyproject.toml", "setup.py", "setup.cfg", "Pipfile",
        "package.json", "package-lock.json",
        "go.mod", "go.sum",
        "Cargo.toml", "Gemfile", "build.gradle", "pom.xml",
        "composer.json",
    ]
    content_parts = []
    for fname in dep_files:
        fpath = root / fname
        if fpath.exists():
            try:
                content_parts.append(fpath.read_text(encoding="utf-8", errors="ignore").lower())
            except OSError:
                continue
    return "\n".join(content_parts)


def _evaluate_documentation_obligation(rule: RuleDefinition) -> Finding:
    """Produce a single project-level finding for a documentation obligation rule."""
    return Finding(
        finding_id=f"{rule.id}-obligation",
        rule_id=rule.id,
        severity=Severity(rule.severity),
        message=f"{rule.name}: {rule.description}" if rule.description else rule.name,
        evidence=Evidence(file="<project>", lines=[], snippet=""),
        suggestion=rule.remediation_guidance,
        confidence=1.0,
        deterministic=True,
        is_obligation=True,
        **_regulatory_metadata(rule),
    )


def _evaluate_requirement_verification(rule: RuleDefinition, root: Path) -> list[Finding]:
    """Run requirement drift detection as a rule-engine evaluation.

    Reads requirements from the file specified in ``rule.params["requirements_file"]``
    (default: ``requirements.yaml``), verifies them against source code, and returns
    findings with severity capped to ``rule.severity`` (default: ``low``).
    """
    from guard.core.requirements_verifier import (
        load_requirements,
        verify_requirements,
        verify_requirements_stub,
    )

    req_file = rule.params.get("requirements_file", "requirements.yaml")
    req_path = root / req_file
    requirements = load_requirements(req_path)
    if not requirements:
        return []

    reqs_with_files = [r for r in requirements if r.source_files and r.status != "rejected"]
    if not reqs_with_files:
        return []

    # Use LLM if configured in params, otherwise stub
    use_llm = rule.params.get("llm_enabled", False)
    llm_provider_name = rule.params.get("llm_provider", "stub")

    if use_llm and llm_provider_name != "stub":
        try:
            from guard.providers.llm_anthropic import LLMAnthropic
            llm = LLMAnthropic()
            findings = verify_requirements(reqs_with_files, str(root), llm)
        except (ImportError, ValueError, OSError):
            logger.warning("LLM unavailable for requirement verification — falling back to stub")
            findings = verify_requirements_stub(reqs_with_files, str(root))
    else:
        findings = verify_requirements_stub(reqs_with_files, str(root))

    # Cap severity to the rule's configured severity and propagate regulatory metadata
    _SEV_ORDER = {Severity.INFO: 0, Severity.LOW: 1, Severity.MEDIUM: 2, Severity.HIGH: 3, Severity.CRITICAL: 4}
    max_sev = Severity(rule.severity)
    max_rank = _SEV_ORDER.get(max_sev, 1)
    meta = _regulatory_metadata(rule)
    for f in findings:
        f_sev = Severity(f.severity) if isinstance(f.severity, str) else f.severity
        if _SEV_ORDER.get(f_sev, 0) > max_rank:
            f.severity = max_sev
        # Stamp rule metadata onto findings
        for key, value in meta.items():
            setattr(f, key, value)

    return findings


# Comment prefixes by language extension
_COMMENT_PREFIXES: dict[str, tuple[str, ...]] = {
    ".py": ("#",), ".rb": ("#",), ".sh": ("#",), ".bash": ("#",), ".yaml": ("#",), ".yml": ("#",),
    ".js": ("//",), ".ts": ("//",), ".tsx": ("//",), ".jsx": ("//",), ".java": ("//",),
    ".c": ("//",), ".cpp": ("//",), ".cs": ("//",), ".go": ("//",), ".rs": ("//",), ".swift": ("//",),
    ".kt": ("//",), ".scala": ("//",), ".dart": ("//",),
}


def _estimate_confidence(file_path: str, line: str) -> float:
    """Estimate confidence for a regex match based on code context.

    Returns a value between 0.4 and 1.0:
    - 1.0: match in executable code
    - 0.7: match in a test file
    - 0.5: match inside a comment
    - 0.4: match inside a string literal (likely example/docs)
    """
    stripped = line.lstrip()
    confidence = 1.0

    # Check if the line is a comment
    ext = Path(file_path).suffix.lower()
    prefixes = _COMMENT_PREFIXES.get(ext, ())
    if prefixes and any(stripped.startswith(p) for p in prefixes):
        confidence = 0.5
    # Check if wrapped in a multi-line string / docstring (rough heuristic: line starts with quotes)
    elif stripped.startswith(('"""', "'''", '"', "'")):
        confidence = 0.4

    # Lower confidence slightly for test files
    name_lower = Path(file_path).name.lower()
    if name_lower.startswith("test_") or name_lower.endswith("_test.py") or "/tests/" in file_path.replace("\\", "/") or "\\tests\\" in file_path:
        confidence = min(confidence, 0.7)

    return confidence


def _evaluate_regex(rule: RuleDefinition, file_path: str, content: str) -> list[Finding]:
    """Run a regex rule against file content and return findings."""
    if rule.all_patterns:
        return _evaluate_composite_regex(rule, file_path, content)

    try:
        pattern = re.compile(rule.pattern)
    except re.error:
        logger.warning("Invalid regex pattern in rule %s — skipped", rule.id)
        return []

    findings: list[Finding] = []
    lines = content.splitlines()
    meta = _regulatory_metadata(rule)

    for match in pattern.finditer(content):
        # Compute 1-based line number from match position
        line_no = content[:match.start()].count("\n") + 1
        snippet = lines[line_no - 1] if line_no <= len(lines) else ""
        confidence = _estimate_confidence(file_path, snippet)

        findings.append(
            Finding(
                finding_id=f"{rule.id}-{file_path}:{line_no}",
                rule_id=rule.id,
                severity=Severity(rule.severity),
                message=f"{rule.name}: {rule.description}" if rule.description else rule.name,
                evidence=Evidence(file=file_path, lines=[line_no], snippet=snippet),
                suggestion=rule.remediation_guidance,
                confidence=confidence,
                deterministic=confidence == 1.0,
                **meta,
            )
        )

    return findings


def _check_starts_with_docstring(content: str, params: dict) -> tuple[bool, str]:
    """Check whether content begins with a triple-quoted docstring."""
    passed = _starts_with_docstring(content)
    return passed, "" if passed else "File does not start with a docstring"


def _check_max_lines(content: str, params: dict) -> tuple[bool, str]:
    """Check that a file does not exceed a maximum line count."""
    threshold = params.get("max_lines", 500)
    count = len(content.splitlines())
    passed = count <= threshold
    return passed, "" if passed else f"File has {count} lines (max {threshold})"


def _check_must_contain_pattern(content: str, params: dict) -> tuple[bool, str]:
    """Check that file content matches a required regex pattern."""
    pat = params.get("pattern", "")
    if not pat:
        return True, ""
    try:
        found = re.search(pat, content) is not None
    except re.error:
        logger.warning("Invalid regex in must_contain_pattern params: %r", pat)
        return True, ""
    return found, "" if found else f"Required pattern not found: {pat}"


def _check_must_not_import(content: str, params: dict) -> tuple[bool, str]:
    """Check that file does not import any of the forbidden modules."""
    forbidden = params.get("forbidden_modules", [])
    if not forbidden:
        return True, ""
    for module in forbidden:
        pattern = rf"(?:^import\s+{re.escape(module)}\b|^from\s+{re.escape(module)}\b)"
        if re.search(pattern, content, re.MULTILINE):
            return False, f"Forbidden import found: {module}"
    return True, ""


def _check_max_function_count(content: str, params: dict) -> tuple[bool, str]:
    """Check that a file does not define too many functions."""
    threshold = params.get("max_functions", 20)
    try:
        tree = ast.parse(content)
    except SyntaxError:
        return True, ""
    count = sum(
        1 for node in ast.walk(tree)
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    )
    passed = count <= threshold
    return passed, "" if passed else f"File has {count} functions (max {threshold})"


FILE_POLICY_CHECKS: dict[str, Any] = {
    "starts_with_docstring": _check_starts_with_docstring,
    "max_lines": _check_max_lines,
    "must_contain_pattern": _check_must_contain_pattern,
    "must_not_import": _check_must_not_import,
    "max_function_count": _check_max_function_count,
}


def _evaluate_file_policy(rule: RuleDefinition, file_path: str, content: str) -> list[Finding]:
    """Run a file-policy check and return findings."""
    meta = _regulatory_metadata(rule)
    check_fn = FILE_POLICY_CHECKS.get(rule.check)
    if check_fn is None:
        logger.warning("Unknown file-policy check %r in rule %s — skipped", rule.check, rule.id)
        return []

    passed, detail = check_fn(content, rule.params)
    if passed:
        return []

    message = f"{rule.name}: {rule.description}" if rule.description else rule.name
    if detail:
        message = f"{rule.name}: {detail}"
    suggestion = rule.remediation_guidance
    if suggestion is None and rule.check == "starts_with_docstring":
        suggestion = "Add a module docstring at the top of the file."

    return [
        Finding(
            finding_id=f"{rule.id}-{file_path}:1",
            rule_id=rule.id,
            severity=Severity(rule.severity),
            message=message,
            evidence=Evidence(file=file_path, lines=[1], snippet=content.splitlines()[0] if content.strip() else ""),
            suggestion=suggestion,
            confidence=1.0,
            deterministic=True,
            **meta,
        )
    ]


def _starts_with_docstring(content: str) -> bool:
    """Check whether *content* begins with a triple-quoted docstring."""
    for line in content.splitlines():
        stripped = line.strip()
        if not stripped:
            continue  # skip blank lines
        return stripped.startswith('"""') or stripped.startswith("'''")
    return False  # empty file → no docstring


def _evaluate_required_pattern(rule: RuleDefinition, file_path: str, content: str) -> list[Finding]:
    """Flag files that LACK a required pattern."""
    if not rule.pattern:
        logger.warning("required_pattern rule %s has no pattern — skipped", rule.id)
        return []

    try:
        pattern = re.compile(rule.pattern, re.MULTILINE)
    except re.error:
        logger.warning("Invalid regex pattern in required_pattern rule %s — skipped", rule.id)
        return []

    if pattern.search(content):
        return []  # Pattern found — file satisfies requirement

    meta = _regulatory_metadata(rule)
    return [
        Finding(
            finding_id=f"{rule.id}-{file_path}:1",
            rule_id=rule.id,
            severity=Severity(rule.severity),
            message=f"{rule.name}: {rule.description}" if rule.description else rule.name,
            evidence=Evidence(file=file_path, lines=[1], snippet=content.splitlines()[0] if content.strip() else ""),
            suggestion=rule.remediation_guidance,
            confidence=1.0,
            deterministic=True,
            **meta,
        )
    ]


def _evaluate_composite_regex(rule: RuleDefinition, file_path: str, content: str) -> list[Finding]:
    """Require ALL patterns in all_patterns to match — produce one finding per file if so."""
    compiled = []
    for pat_str in rule.all_patterns:
        try:
            compiled.append(re.compile(pat_str))
        except re.error:
            logger.warning("Invalid regex %r in composite all_patterns for rule %s — skipped", pat_str, rule.id)
            return []

    first_match = None
    for pat in compiled:
        m = pat.search(content)
        if m is None:
            return []  # At least one pattern didn't match — no finding
        if first_match is None:
            first_match = m

    if first_match is None:
        return []

    line_no = content[:first_match.start()].count("\n") + 1
    lines = content.splitlines()
    snippet = lines[line_no - 1] if line_no <= len(lines) else ""
    meta = _regulatory_metadata(rule)
    confidence = _estimate_confidence(file_path, snippet)

    return [
        Finding(
            finding_id=f"{rule.id}-{file_path}:{line_no}",
            rule_id=rule.id,
            severity=Severity(rule.severity),
            message=f"{rule.name}: {rule.description}" if rule.description else rule.name,
            evidence=Evidence(file=file_path, lines=[line_no], snippet=snippet),
            suggestion=rule.remediation_guidance,
            confidence=confidence,
            deterministic=confidence == 1.0,
            **meta,
        )
    ]


def _evaluate_ast(rule: RuleDefinition, file_path: str, content: str) -> list[Finding]:
    """Run an AST check against source code and return findings.

    Dispatch priority:
    1. If ``rule.query`` is set → tree-sitter query (any supported language).
    2. If ``rule.ast_check`` is set → built-in Python AST check function.
    3. Otherwise → warning and skip.
    """
    if rule.query:
        return _evaluate_treesitter(rule, file_path, content)

    from guard.rules.ast_checks import AST_CHECKS

    check_name = rule.ast_check
    if not check_name:
        logger.warning("AST rule %s has no ast_check or query specified — skipped", rule.id)
        return []

    check_fn = AST_CHECKS.get(check_name)
    if check_fn is None:
        logger.warning("Unknown ast_check %r in rule %s — skipped", check_name, rule.id)
        return []

    try:
        tree = ast.parse(content, filename=file_path)
    except SyntaxError:
        logger.debug("Syntax error parsing %s — skipping AST rule %s", file_path, rule.id)
        return []

    source_lines = content.splitlines()
    issues = check_fn(tree, source_lines, rule.params)
    meta = _regulatory_metadata(rule)

    findings: list[Finding] = []
    for issue in issues:
        findings.append(
            Finding(
                finding_id=f"{rule.id}-{file_path}:{issue.line}",
                rule_id=rule.id,
                severity=Severity(rule.severity),
                message=f"{rule.name}: {issue.message}",
                evidence=Evidence(
                    file=file_path,
                    lines=[issue.line],
                    snippet=issue.snippet,
                ),
                suggestion=rule.remediation_guidance,
                confidence=1.0,
                deterministic=True,
                **meta,
            )
        )
    return findings


# ---------------------------------------------------------------------------
# LLM rule evaluation
# ---------------------------------------------------------------------------

_llm_provider_cache: dict[str, Any] = {}
_llm_cache_lock = threading.Lock()


def _get_configured_llm() -> Any | None:
    """Return a cached LLM provider instance based on env vars, or None if unconfigured."""
    import os

    provider_name = os.environ.get("GUARD_LLM_PROVIDER", "stub")
    if provider_name in ("stub", "", None):
        return None

    cache_key = f"{provider_name}:{os.environ.get('GUARD_LLM_MODEL', '')}:{os.environ.get('GUARD_LLM_BASE_URL', '')}"
    with _llm_cache_lock:
        if cache_key in _llm_provider_cache:
            return _llm_provider_cache[cache_key]

        try:
            if provider_name == "anthropic":
                from guard.providers.llm_anthropic import LLMAnthropic
                llm = LLMAnthropic(model=os.environ.get("GUARD_LLM_MODEL") or None)
            elif provider_name in ("openai", "ollama"):
                from guard.providers.llm_openai import LLMOpenAI
                llm = LLMOpenAI(
                    model=os.environ.get("GUARD_LLM_MODEL") or None,
                    base_url=os.environ.get("GUARD_LLM_BASE_URL") or None,
                )
            else:
                logger.warning("Unknown LLM provider %r — skipping llm rules", provider_name)
                return None
            _llm_provider_cache[cache_key] = llm
            return llm
        except Exception as exc:  # pragma: no cover
            logger.warning("Failed to instantiate LLM provider %r: %s", provider_name, exc)
            return None


_LLM_RULE_SYSTEM_PROMPT = """\
You are a code reviewer enforcing a specific coding standard rule.
Your job is to find violations of the rule described below — nothing else.
Be precise: only flag clear violations, not hypothetical ones.
Respond ONLY with valid JSON — no explanation outside the JSON object.\
"""

_LLM_RULE_USER_TEMPLATE = """\
Rule ID: {rule_id}
Rule name: {rule_name}
Description: {description}
Remediation: {remediation}

Find all violations of this rule in the {language} file below.
For each violation provide the 1-based line number and a one-sentence explanation.

Respond with this JSON format:
{{"violations": [{{"line": <int>, "message": "<string>"}}]}}
If no violations are found respond: {{"violations": []}}

File: {file_path}
```
{content}
```\
"""

_LLM_RULE_CONFIDENCE = 0.75
_LLM_MAX_FILE_CHARS = 12_000  # truncate large files to stay within context


def _evaluate_llm_rule(
    rule: RuleDefinition,
    root: Path,
    rel_path: str,
    llm: Any,
) -> list[Finding]:
    """Send *rel_path* to the LLM and return findings for the given rule."""
    import os

    abs_path = root / rel_path
    try:
        content = abs_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []

    max_chars = int(rule.params.get("llm_max_chars", _LLM_MAX_FILE_CHARS))
    truncated = content[:max_chars]
    if len(content) > max_chars:
        truncated += f"\n... [truncated at {max_chars} chars] ..."

    ext = os.path.splitext(rel_path)[1].lstrip(".")
    language = ext or "code"

    user_msg = _LLM_RULE_USER_TEMPLATE.format(
        rule_id=rule.id,
        rule_name=rule.name,
        description=rule.description or rule.name,
        remediation=rule.remediation_guidance or "",
        language=language,
        file_path=rel_path,
        content=truncated,
    )

    try:
        result = llm.analyze(user_msg, {"file": rel_path, "content": truncated})
    except Exception as exc:  # pragma: no cover
        logger.warning("LLM rule %s failed on %s: %s", rule.id, rel_path, exc)
        return []

    violations = result.get("violations") or result.get("findings") or []
    if not violations:
        return []

    meta = _regulatory_metadata(rule)
    lines = content.splitlines()
    findings: list[Finding] = []
    seen: set[int] = set()

    for v in violations:
        if not isinstance(v, dict):
            continue
        line_no = int(v.get("line", 0))
        if line_no <= 0 or line_no in seen:
            continue
        seen.add(line_no)
        snippet = lines[line_no - 1].strip() if line_no <= len(lines) else ""
        message = v.get("message") or v.get("explanation") or rule.name

        findings.append(Finding(
            finding_id=f"{rule.id}-llm-{rel_path}:{line_no}",
            rule_id=rule.id,
            severity=Severity(rule.severity),
            message=f"{rule.name}: {message}",
            evidence=Evidence(file=rel_path, lines=[line_no], snippet=snippet),
            suggestion=rule.remediation_guidance,
            confidence=_LLM_RULE_CONFIDENCE,
            deterministic=False,
            **meta,
        ))

    return findings


def _evaluate_treesitter(rule: RuleDefinition, file_path: str, content: str) -> list[Finding]:
    """Run a tree-sitter query rule against *content* and return findings."""
    from guard.rules.treesitter_checks import run_query

    language = rule.language
    if not language:
        logger.warning("AST rule %s has a query but no language — skipped", rule.id)
        return []

    issues = run_query(language, rule.query, content)
    if not issues:
        return []

    meta = _regulatory_metadata(rule)
    findings: list[Finding] = []
    seen: set[tuple[str, int]] = set()   # deduplicate by (file, line)

    for issue in issues:
        key = (file_path, issue.line)
        if key in seen:
            continue
        seen.add(key)

        node_detail = f" ({issue.node_text!r})" if issue.node_text else ""
        message = f"{rule.name}: {rule.description}{node_detail}" if rule.description else f"{rule.name}{node_detail}"

        findings.append(
            Finding(
                finding_id=f"{rule.id}-{file_path}:{issue.line}",
                rule_id=rule.id,
                severity=Severity(rule.severity),
                message=message,
                evidence=Evidence(
                    file=file_path,
                    lines=[issue.line],
                    snippet=issue.snippet,
                ),
                suggestion=rule.remediation_guidance,
                confidence=1.0,
                deterministic=True,
                **meta,
            )
        )
    return findings
