"""Anthropic Claude LLM provider for AI-augmented code scanning."""

from __future__ import annotations

import json
import logging
import os
from typing import Any

import requests

from guard.providers.llm_base import LLMProvider

logger = logging.getLogger(__name__)

_DEFAULT_MODEL = "claude-sonnet-4-20250514"
_API_URL = "https://api.anthropic.com/v1/messages"


class LLMAnthropic(LLMProvider):
    """LLM provider that calls the Anthropic Messages API."""

    def __init__(self, model: str | None = None) -> None:
        self._model = model or os.environ.get("ANTHROPIC_MODEL", _DEFAULT_MODEL)
        self._api_key = os.environ.get("ANTHROPIC_API_KEY", "")

    def analyze(self, prompt: str, context: dict[str, Any]) -> dict[str, Any]:
        """Send *prompt* and *context* to Claude and return parsed findings."""
        if not self._api_key:
            logger.warning("ANTHROPIC_API_KEY not set — returning empty results")
            return {"findings": [], "summary": "No API key configured.", "confidence": 0.0}

        file_content = context.get("content", "")
        if file_content:
            user_message = f"{prompt}\n\nFile: {context.get('file', '(unknown)')}\n\n```\n{file_content}\n```"
        else:
            user_message = prompt

        headers = {
            "x-api-key": self._api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }
        body = {
            "model": self._model,
            "max_tokens": 4096,
            "messages": [{"role": "user", "content": user_message}],
        }

        try:
            resp = requests.post(_API_URL, json=body, headers=headers, timeout=120)
        except requests.RequestException as exc:
            logger.warning("Anthropic API request failed: %s", exc)
            return {"findings": [], "summary": f"API error: {exc}", "confidence": 0.0}

        if resp.status_code != 200:
            logger.warning("Anthropic API returned %d: %s", resp.status_code, resp.text[:200])
            return {"findings": [], "summary": f"API error ({resp.status_code})", "confidence": 0.0}

        data = resp.json()
        text = ""
        for block in data.get("content", []):
            if block.get("type") == "text":
                text += block["text"]

        return self._parse_response(text)

    def chat(self, messages: list[dict[str, str]], system: str = "") -> str:
        """Multi-turn chat via the Anthropic Messages API."""
        if not self._api_key:
            return "Error: ANTHROPIC_API_KEY not set. Please configure your API key."

        headers = {
            "x-api-key": self._api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }
        body: dict[str, Any] = {
            "model": self._model,
            "max_tokens": 4096,
            "messages": [{"role": m["role"], "content": m["content"]} for m in messages],
        }
        if system:
            body["system"] = system

        try:
            resp = requests.post(_API_URL, json=body, headers=headers, timeout=120)
        except requests.RequestException as exc:
            return f"Error communicating with Anthropic API: {exc}"

        if resp.status_code != 200:
            return f"Anthropic API error ({resp.status_code}): {resp.text[:200]}"

        data = resp.json()
        text = ""
        for block in data.get("content", []):
            if block.get("type") == "text":
                text += block["text"]
        return text

    @staticmethod
    def _parse_response(text: str) -> dict[str, Any]:
        """Extract a JSON object from the model's text response."""
        # Try to find a JSON block in the response
        start = text.find("{")
        end = text.rfind("}") + 1
        if start == -1 or end == 0:
            return {"findings": [], "summary": text[:500], "confidence": 0.0}

        try:
            result = json.loads(text[start:end])
        except json.JSONDecodeError:
            return {"findings": [], "summary": text[:500], "confidence": 0.0}

        if "findings" not in result:
            result["findings"] = []
        return result
