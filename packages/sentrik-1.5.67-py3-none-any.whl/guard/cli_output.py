"""Rich-based CLI output helpers for styled, coloured terminal output."""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.theme import Theme

# ---------------------------------------------------------------------------
# Theme & console
# ---------------------------------------------------------------------------

SEV_STYLES = {
    "critical": "bold red",
    "high": "dark_orange",
    "medium": "yellow",
    "low": "blue",
    "info": "dim",
}

GUARD_THEME = Theme(
    {
        "success": "green",
        "error": "bold red",
        "warning": "yellow",
        "hint": "dim cyan",
        "header": "bold white",
        **{f"sev.{k}": v for k, v in SEV_STYLES.items()},
    }
)

console = Console(theme=GUARD_THEME, highlight=False)

# ---------------------------------------------------------------------------
# Styled output helpers
# ---------------------------------------------------------------------------


def print_header(title: str) -> None:
    console.print(f"\n[header]{title}[/header]")


def print_success(msg: str) -> None:
    console.print(f"[success]{msg}[/success]")


def print_error(msg: str) -> None:
    console.print(f"[error]{msg}[/error]")


def print_warning(msg: str) -> None:
    console.print(f"[warning]{msg}[/warning]")


def print_hint(msg: str) -> None:
    console.print(f"[hint]{msg}[/hint]")


# ---------------------------------------------------------------------------
# Rich error context printing
# ---------------------------------------------------------------------------


def print_error_context(ctx) -> None:
    """Print a rich, actionable error message with contextual guidance.

    Args:
        ctx: An ErrorContext object from guard.core.error_helper.
    """
    console.print(f"\n[error]ERROR:[/error] {ctx.message}\n")
    console.print(f"  [warning]Why:[/warning] {ctx.root_cause}\n")

    if ctx.suggested_actions:
        console.print("  [hint]What to do:[/hint]")
        for action in ctx.suggested_actions:
            console.print(f"    {action}")

    if ctx.example_command:
        console.print(f"\n  [hint]Example:[/hint] {ctx.example_command}")

    if ctx.docs_hint:
        console.print(f"\n  [hint]{ctx.docs_hint}[/hint]")

    console.print()


# ---------------------------------------------------------------------------
# Tables
# ---------------------------------------------------------------------------


def severity_label(sev: str) -> str:
    """Return a Rich-markup styled severity string."""
    style = SEV_STYLES.get(sev, "dim")
    return f"[{style}]{sev}[/{style}]"


def scan_summary_table(by_severity: dict[str, int]) -> None:
    """Print a severity summary table."""
    table = Table(show_header=True, header_style="bold", box=None, padding=(0, 2))
    table.add_column("Severity", style="bold")
    table.add_column("Count", justify="right")
    for sev in ("critical", "high", "medium", "low", "info"):
        count = by_severity.get(sev, 0)
        if count > 0:
            style = SEV_STYLES.get(sev, "dim")
            table.add_row(f"[{style}]{sev}[/{style}]", f"[{style}]{count}[/{style}]")
    console.print(table)


def top_files_table(findings: list[dict], limit: int = 5) -> None:
    """Print top files by finding count."""
    counts: dict[str, int] = {}
    for f in findings:
        ev = f.get("evidence") or {}
        fp = ev.get("file", "")
        if fp:
            counts[fp] = counts.get(fp, 0) + 1
    if not counts:
        return
    sorted_files = sorted(counts.items(), key=lambda x: x[1], reverse=True)[:limit]
    table = Table(show_header=True, header_style="bold", box=None, padding=(0, 2))
    table.add_column("File")
    table.add_column("Findings", justify="right")
    for fp, count in sorted_files:
        table.add_row(fp, str(count))
    console.print(table)


def top_findings_table(findings: list[dict], limit: int = 5) -> None:
    """Print top critical/high findings with details.

    Shows the most severe findings so users can immediately see what needs fixing.
    """
    # Filter to critical and high, then sort by severity
    sev_order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    severe = [
        f for f in findings
        if f.get("severity") in ("critical", "high")
    ]
    if not severe:
        return
    severe.sort(key=lambda f: sev_order.get(f.get("severity", "info"), 99))
    top = severe[:limit]

    console.print()
    table = Table(
        show_header=True, header_style="bold", box=None, padding=(0, 2),
        title="[bold]Top Findings[/bold]",
    )
    table.add_column("Severity", width=10)
    table.add_column("Rule", style="cyan", width=22)
    table.add_column("File", width=30)
    table.add_column("Message", no_wrap=False)

    for f in top:
        sev = f.get("severity", "info")
        rule_id = f.get("rule_id", "unknown")
        ev = f.get("evidence") or {}
        file_path = ev.get("file", "")
        lines = ev.get("lines", [])
        msg = f.get("message", "")[:60]

        # Add line numbers to file path
        if lines:
            file_display = f"{file_path}:{lines[0]}"
        else:
            file_display = file_path

        table.add_row(severity_label(sev), rule_id, file_display, msg)

        # Show remediation guidance inline
        guidance = f.get("remediation_guidance") or f.get("suggestion") or ""
        if guidance:
            std = f.get("standard", "")
            clause = f.get("clause", "")
            ref = f" [dim]({std} {clause})[/dim]" if std else ""
            table.add_row("", "", "", f"[dim italic]Fix: {guidance[:120]}{'...' if len(guidance) > 120 else ''}{ref}[/dim italic]")

    console.print(table)
    remaining = len(severe) - limit
    if remaining > 0:
        console.print(f"  [hint]...and {remaining} more critical/high finding(s). Run [bold]sentrik dashboard[/bold] for full details.[/hint]")


def traceability_table(matrix: dict) -> None:
    """Print a traceability matrix summary."""
    reqs = matrix.get("requirements", [])
    summary = matrix.get("summary", {})

    # Requirement coverage table
    table = Table(
        show_header=True, header_style="bold", box=None, padding=(0, 2),
        title="[bold]Traceability Matrix[/bold]",
    )
    table.add_column("Requirement", style="cyan", width=12)
    table.add_column("Title", width=40, no_wrap=False)
    table.add_column("Defined", justify="center", width=8)
    table.add_column("Implemented", justify="center", width=12)
    table.add_column("Files", width=40, no_wrap=False)

    for req in reqs:
        defined = "[green]Yes[/green]" if req["defined"] else "[red]No[/red]"
        impl = "[green]Yes[/green]" if req["implemented"] else "[red]No[/red]"
        files = ", ".join(req["files"][:3])
        if len(req["files"]) > 3:
            files += f" (+{len(req['files']) - 3} more)"
        table.add_row(req["id"], req.get("title", ""), defined, impl, files)

    console.print()
    console.print(table)

    # Coverage summary
    cov = summary.get("coverage_pct", 0)
    total = summary.get("total_requirements", 0)
    implemented = summary.get("implemented", 0)
    color = "green" if cov >= 90 else "yellow" if cov >= 70 else "red"
    console.print(
        f"\n  Coverage: [{color}]{cov}%[/{color}] ({implemented}/{total} requirements implemented)"
    )

    # Unimplemented requirements
    unimpl = matrix.get("unimplemented", [])
    if unimpl:
        console.print(f"\n  [warning]Unimplemented requirements ({len(unimpl)}):[/warning]")
        for u in unimpl:
            console.print(f"    [red]{u['id']}[/red]: {u.get('title', '')}")

    # Unlinked files (unknown refs)
    unlinked = matrix.get("unlinked_files", [])
    if unlinked:
        console.print(f"\n  [warning]Files referencing undefined requirements ({len(unlinked)}):[/warning]")
        for u in unlinked:
            refs = ", ".join(u["unknown_refs"])
            console.print(f"    {u['file']}: [red]{refs}[/red]")

    console.print()


def compliance_score_panel(score_data: dict) -> None:
    """Print a panel showing the compliance score as a percentage."""
    score = score_data.get("score", 0.0)
    rules_passed = score_data.get("rules_passed", 0)
    rules_total = score_data.get("rules_total", 0)

    if score >= 90:
        color = "green"
    elif score >= 70:
        color = "yellow"
    else:
        color = "red"

    console.print(
        Panel(
            f"[bold {color}]{score}%[/bold {color}]\n"
            f"{rules_passed} of {rules_total} rules passed",
            title="Compliance Score",
            border_style=color,
        )
    )


def gate_result_panel(passed: bool, counts: dict[str, int]) -> None:
    """Print a green PASSED or red FAILED panel."""
    if passed:
        console.print(Panel("[bold green]GATE PASSED[/bold green]", border_style="green"))
    else:
        parts = []
        for sev in ("critical", "high", "medium", "low", "info"):
            n = counts.get(sev, 0)
            if n > 0:
                style = SEV_STYLES.get(sev, "dim")
                parts.append(f"[{style}]{sev}={n}[/{style}]")
        detail = "  ".join(parts)
        console.print(
            Panel(
                f"[bold red]GATE FAILED[/bold red]\n{detail}",
                border_style="red",
            )
        )


def rules_table(rules: list[dict]) -> None:
    """Print a formatted rules table."""
    table = Table(show_header=True, header_style="bold", box=None, padding=(0, 2))
    table.add_column("ID", style="cyan")
    table.add_column("Type")
    table.add_column("Severity")
    table.add_column("Name")
    for r in rules:
        rid = r.get("id", "?")
        rtype = r.get("type", "?")
        sev = r.get("severity", "?")
        name = r.get("name", "")
        desc = r.get("description", "")
        autofix = r.get("autofix", "")
        label = name
        if desc:
            label = f"{name}: {desc}"
        if autofix:
            label += f" [autofix: {autofix}]"
        table.add_row(rid, rtype, severity_label(sev), label)
    console.print(table)
    console.print(f"\nTotal: {len(rules)} rule(s)")


# ---------------------------------------------------------------------------
# Post-command hints — dynamic, context-aware
# ---------------------------------------------------------------------------

HINTS = {
    "init": "Next: [bold]sentrik scan[/bold] — run your first scan\n  Docs: [link=https://docs.sentrik.dev]docs.sentrik.dev[/link]",
    "scan": "Next: [bold]sentrik gate[/bold] — enforce quality gates\n  Docs: [link=https://docs.sentrik.dev]docs.sentrik.dev[/link]",
    "gate_passed": "Gate passed! Ready to commit.\n  View findings: [bold]sentrik dashboard[/bold] | Docs: [link=https://docs.sentrik.dev]docs.sentrik.dev[/link]",
    "gate_failed": "Fix {critical} critical and {high} high finding(s), then re-run [bold]sentrik gate[/bold].\n  Docs: [link=https://docs.sentrik.dev]docs.sentrik.dev[/link]",
    "reconcile": "{count} work item(s) synced. View in dashboard: [bold]sentrik dashboard[/bold]\n  Docs: [link=https://docs.sentrik.dev/guides/ci-cd-integration]docs.sentrik.dev[/link]",
    "validate_config": "Next: [bold]sentrik scan[/bold]",
    "migrate": "Next: [bold]sentrik validate-config[/bold] — verify the migrated config",
    "context": "Context written. AI agents can now read [bold]out/agent_context.json[/bold]",
    "trace": "Next: [bold]sentrik reconcile --dry-run[/bold] — sync findings to your backlog\n  Or: [bold]sentrik verify-reqs[/bold] — check for requirement drift",
    "pull_reqs": "Next: [bold]sentrik verify-reqs[/bold] — check pulled requirements match code\n  Or: [bold]sentrik trace[/bold] — view full traceability matrix",
    "generate_reqs": "Next: [bold]sentrik verify-reqs[/bold] — check code matches requirements\n  Or: [bold]sentrik trace[/bold] — view full traceability matrix",
    "verify_reqs": "Next: [bold]sentrik reconcile[/bold] — create work items for drift findings\n  Or: [bold]sentrik generate-reqs[/bold] — generate requirements for untracked code",
    "apply_patches": "Next: [bold]sentrik scan[/bold] — re-scan to verify fixes\n  Then: [bold]sentrik gate[/bold] — check if gate passes now",
    "list_packs": "Add a pack: [bold]sentrik add-pack <pack-id>[/bold]\n  Docs: [link=https://docs.sentrik.dev/standards-packs/overview]docs.sentrik.dev[/link]",
    "add_pack": "Next: [bold]sentrik scan[/bold] — scan with the new pack enabled",
    "remove_pack": "Next: [bold]sentrik scan[/bold] — re-scan without the removed pack",
    "approve": "Next: [bold]sentrik gate[/bold] — re-run gate to check approval status",
    "export_audit": "Share the audit bundle with your QA or regulatory team",
    "license": "Next: [bold]sentrik scan[/bold] — start scanning\n  Docs: [link=https://docs.sentrik.dev]docs.sentrik.dev[/link]",
    "compliance_report": "Share this report with your QA or regulatory team\n  Or: [bold]sentrik export-audit[/bold] — full audit bundle for submission",
    "history_report": "Share this historical report with auditors or QA\n  Or: [bold]sentrik history-report --list[/bold] — see all available runs",
    "trust_center": "Share this page publicly or embed on your website\n  JSON output: [bold]sentrik trust-center --json[/bold]",
    "evidence_export": "Share this evidence package with auditors\n  JSON output: [bold]sentrik evidence-export -f \"SOC2\" --json[/bold]\n  All frameworks: [bold]sentrik evidence-export --all[/bold]",
    "watch": "Watching for changes... Press Ctrl+C to stop\n  Or: [bold]sentrik watch --interval 300[/bold] — scan every 5 minutes",
    "sbom": "Include this SBOM in your release artifacts or share with customers\n  SPDX format: [bold]sentrik sbom --format spdx[/bold]",
    "vulns": "Review and remediate vulnerable dependencies\n  JSON output: [bold]sentrik vulns --json[/bold]\n  Generate SBOM: [bold]sentrik sbom[/bold]",
    "licenses": "Review copyleft dependencies before distributing your software\n  JSON output: [bold]sentrik licenses --json[/bold]\n  Copyleft only: [bold]sentrik licenses --copyleft-only[/bold]",
    "org_dashboard": "HTML report: [bold]sentrik org-dashboard --output report.html[/bold]\n  JSON output: [bold]sentrik org-dashboard --json[/bold]",
    "impact": "Next: [bold]sentrik scan[/bold] — run a full scan on the affected files\n  Or: [bold]sentrik gate --git-range origin/main...HEAD[/bold] — enforce gate on PR diff",
    "analyze_cpp": "Next: [bold]sentrik scan[/bold] — run a full scan including C/C++ findings\n  Enable in config: [bold]cpp_analysis_enabled: true[/bold]",
    "check_arch": "Next: [bold]sentrik scan[/bold] — architecture rules are also checked during scans\n  Init rules: [bold]sentrik check-arch --init[/bold]",
    "grc_push": "Push compliance evidence automatically: add [bold]grc_webhook_url[/bold] to your config\n  Test connectivity: [bold]sentrik grc-push --test[/bold]\n  Supported platforms: Drata, Vanta, Secureframe, or any webhook",
    "check_policies": "Next: [bold]sentrik scan[/bold] — run a full scan (includes policy checks)\n  Edit policies: [bold]policies.yaml[/bold] or [bold].sentrik/policies.yaml[/bold]",
    "check_inline": "Use the SDK in your AI agent: [bold]from guard.sdk import check_code, get_compliance_context[/bold]\n  API: [bold]POST /api/sdk/check[/bold] or [bold]GET /api/sdk/context?filename=src/main.cpp[/bold]",
}


def get_smart_hint(command: str, context: dict | None = None) -> str:
    """Generate a context-aware post-command hint.

    Extends the basic hint templates with dynamic guidance based on
    actual scan results, governance decisions, and available actions.
    """
    ctx = context or {}

    if command == "scan":
        count = ctx.get("findings_count", 0)
        if count == 0:
            return "No findings — your code looks clean! Next: [bold]sentrik gate[/bold]"
        autofix_count = ctx.get("autofixable_count", 0)
        parts = [f"Next: [bold]sentrik gate[/bold] — enforce quality gates"]
        if autofix_count > 0:
            parts.append(
                f"[bold]{autofix_count}[/bold] finding(s) can be auto-fixed: [bold]sentrik apply-patches[/bold]"
            )
        parts.append("Docs: [link=https://docs.sentrik.dev]docs.sentrik.dev[/link]")
        return "\n  ".join(parts)

    if command == "gate_failed":
        critical = ctx.get("critical", 0)
        high = ctx.get("high", 0)
        parts = [f"Fix {critical} critical and {high} high finding(s), then re-run [bold]sentrik gate[/bold]."]

        # Show top rule IDs causing failures
        top_rules = ctx.get("top_rules", [])
        if top_rules:
            rule_list = ", ".join(top_rules[:3])
            parts.append(f"Top issues: [bold]{rule_list}[/bold]")

        # Governance context
        if ctx.get("governance_blocked"):
            reason = ctx.get("governance_reason", "Human review required")
            parts.append(f"Governance: {reason}")

        # Autofix availability
        autofix_count = ctx.get("autofixable_count", 0)
        if autofix_count > 0:
            parts.append(f"[bold]{autofix_count}[/bold] can be auto-fixed: [bold]sentrik apply-patches[/bold]")

        parts.append("View all findings: [bold]sentrik dashboard[/bold]")
        parts.append("Docs: [link=https://docs.sentrik.dev]docs.sentrik.dev[/link]")
        return "\n  ".join(parts)

    if command == "gate_passed":
        return "Gate passed! Ready to commit.\n  View findings: [bold]sentrik dashboard[/bold] | Docs: [link=https://docs.sentrik.dev]docs.sentrik.dev[/link]"

    if command == "reconcile":
        count = ctx.get("count", 0)
        created = ctx.get("created", 0)
        updated = ctx.get("updated", 0)
        closed = ctx.get("closed", 0)
        parts = [f"{count} work item(s) synced"]
        if created:
            parts[0] += f" ({created} created, {updated} updated, {closed} closed)"
        parts.append("View in dashboard: [bold]sentrik dashboard[/bold]")
        return ". ".join(parts)

    # Fall back to static hints
    return HINTS.get(command, "")


def print_post_hint(command: str, **kwargs: object) -> None:
    """Print a contextual next-step hint.

    If a 'context' dict is provided in kwargs, uses smart hints.
    Otherwise falls back to static template hints for backward compatibility.
    """
    context = kwargs.pop("context", None)
    if context and isinstance(context, dict):
        msg = get_smart_hint(command, context)
    else:
        template = HINTS.get(command, "")
        if not template:
            return
        msg = template.format(**kwargs) if kwargs else template
    if msg:
        console.print(f"\n[hint]{msg}[/hint]")


def compliance_file_map(findings: list[dict], changed_files: list[str] | None = None) -> None:
    """Print a compact file → compliance framework mapping.

    Shows which frameworks cover each changed file based on findings.
    Only prints if changed_files is provided (PR/diff mode).
    """
    if not changed_files:
        return

    # Build file → frameworks mapping from findings
    file_frameworks: dict[str, set[str]] = {}
    for f in findings:
        ev = f.get("evidence", {})
        file_path = ev.get("file", "") if isinstance(ev, dict) else ""
        standard = f.get("standard", "")
        if file_path and standard and not f.get("is_obligation"):
            file_frameworks.setdefault(file_path, set()).add(standard)

    if not file_frameworks:
        return

    console.print("\n[dim]Compliance coverage:[/dim]")
    for fp in sorted(file_frameworks.keys()):
        fws = ", ".join(sorted(file_frameworks[fp]))
        console.print(f"  [dim]{fp}[/dim] -> [bold]{fws}[/bold]")

    # Show uncovered files
    covered = set(file_frameworks.keys())
    uncovered = [f for f in changed_files if f not in covered]
    if uncovered and len(uncovered) <= 5:
        for fp in uncovered:
            console.print(f"  [dim]{fp}[/dim] -> [dim](no compliance coverage)[/dim]")
    elif uncovered:
        console.print(f"  [dim]... and {len(uncovered)} file(s) with no compliance coverage[/dim]")
    console.print()


def suggest_suppressions(findings: list[dict], threshold: int = 3) -> None:
    """Suggest suppression rules for rules that fire repeatedly on test files.

    If a rule triggers *threshold* or more times on files matching common
    test patterns, prints a YAML snippet the user can add to config.
    """
    from collections import Counter

    test_patterns = ("test_", "_test.", "/tests/", "/test/", "spec_", "_spec.")
    rule_test_counts: Counter[str] = Counter()

    for f in findings:
        file_path = ""
        ev = f.get("evidence", {})
        if isinstance(ev, dict):
            file_path = ev.get("file", "")
        elif hasattr(ev, "file"):
            file_path = ev.file
        if any(p in file_path.lower() for p in test_patterns):
            rule_test_counts[f.get("rule_id", "")] += 1

    suggestions = [(rule, count) for rule, count in rule_test_counts.items() if count >= threshold and rule]
    if not suggestions:
        return

    console.print("\n[dim]Suppression suggestions (rules firing repeatedly in test files):[/dim]")
    console.print("[dim]  suppressions:[/dim]")
    for rule, count in sorted(suggestions, key=lambda x: -x[1]):
        console.print(f'[dim]    - rule_id: "{rule}"[/dim]')
        console.print(f'[dim]      file_pattern: "tests/**"[/dim]')
        console.print(f'[dim]      reason: "Fires {count}x in test files"[/dim]')
