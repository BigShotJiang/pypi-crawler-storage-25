"""Main scan pipeline — orchestrates providers, rules engine, and artifact output."""

from __future__ import annotations

import json
import logging
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter

logger = logging.getLogger(__name__)

from guard import __version__
from guard.config import GuardConfig
from guard.core.models import Finding, GateResult, RunMetadata, Severity
from guard.core.cache import ScanCache
from guard.core.metrics import MetricsCollector
from guard.core.patcher import generate_patches, write_patches
from guard.core.renderer import render_next_actions, render_report
from guard.core.traceability import extract_work_item_ids, link_findings_to_work_items
from guard.providers.scanners_base import ScannersProvider
from guard.reporters.factory import build_reporters
from guard.rules.engine import RulesEngine


from typing import Callable


_SEVERITY_WEIGHTS = {
    "critical": 10.0,
    "high": 5.0,
    "medium": 2.0,
    "low": 0.5,
    "info": 0.0,
}


def calculate_compliance_score(
    findings: list[Finding],
    rules_count: int,
) -> dict:
    """Calculate a severity-weighted compliance score.

    The score accounts for both *how many* rules failed and *how severe*
    the failures are.  A single critical finding drags the score down more
    than ten low findings.

    Obligation findings (``is_obligation=True``) are excluded — they appear
    in reports but are not counted against compliance.

    Scoring:
    - Base: percentage of rules with zero findings (0-100)
    - Penalty: each finding subtracts a severity-weighted amount
      (critical=10, high=5, medium=2, low=0.5, info=0)
    - Penalty is scaled relative to total rules so large rule sets
      aren't unfairly penalized
    - Final score is clamped to 0-100

    Returns a dict with ``score``, ``rules_total``, ``rules_passed``,
    ``rules_failed``, ``severity_penalty``, and ``blocking_findings``.
    """
    if rules_count == 0:
        return {
            "score": 100.0, "rules_total": 0, "rules_passed": 0,
            "rules_failed": 0, "severity_penalty": 0.0, "blocking_findings": 0,
        }

    code_findings = [f for f in findings if not f.is_obligation]
    failed_rule_ids: set[str] = set()
    severity_penalty = 0.0
    blocking = 0

    for f in code_findings:
        failed_rule_ids.add(f.rule_id)
        sev = f.severity.value if hasattr(f.severity, "value") else str(f.severity)
        weight = _SEVERITY_WEIGHTS.get(sev, 1.0)
        severity_penalty += weight
        if sev in ("critical", "high"):
            blocking += 1

    rules_failed = len(failed_rule_ids)
    rules_passed = rules_count - rules_failed

    # Base score: percentage of rules passing
    base_score = (rules_passed / rules_count) * 100

    # Severity penalty: proportional to rule count, capped at half the base score
    # This ensures a project with 85% rules passing never shows 0% —
    # the severity penalty reduces it but can't erase the passing rules
    penalty_scale = min(1.0, 20.0 / max(rules_count, 1))
    weighted_penalty = min(severity_penalty * penalty_scale, base_score * 0.5)

    score = max(0.0, round(base_score - weighted_penalty, 1))

    return {
        "score": score,
        "rules_total": rules_count,
        "rules_passed": rules_passed,
        "rules_failed": rules_failed,
        "severity_penalty": round(weighted_penalty, 1),
        "blocking_findings": blocking,
    }


def run_scan(
    repo_root: str,
    config: GuardConfig,
    rules_engine: RulesEngine,
    scanner: ScannersProvider,
    changed_files: list[str] | None = None,
    branch: str | None = None,
    metrics_collector: MetricsCollector | None = None,
    progress_callback: Callable[[str, float], None] | None = None,
) -> list[Finding]:
    """Run the full scan pipeline and return all findings."""
    from guard.core.metrics import MetricsCollector

    collector = metrics_collector or MetricsCollector(
        parallel_workers=rules_engine._max_workers,
    )
    collector.start()

    findings: list[Finding] = []

    # Build cache if enabled
    cache: ScanCache | None = None
    if config.cache_enabled:
        cache = ScanCache(config.cache_dir)

    # Detect project languages for conditional obligation filtering
    try:
        from guard.core.auto_detect import detect_project
        _profile = detect_project(Path(repo_root))
        _project_languages = _profile.languages
    except Exception:
        _project_languages = None

    # Rules engine evaluation — emit per-file progress in the 0.20→0.34 range
    if progress_callback:
        progress_callback("rules_engine", 0.2)

    def _rules_file_progress(done: int, total: int) -> None:
        if progress_callback and total > 0:
            frac = done / total
            progress_callback("rules_engine", 0.2 + frac * 0.14)

    with collector.time_rules_engine():
        findings.extend(rules_engine.evaluate(
            repo_root, changed_files, cache=cache,
            scan_exclude=config.scan_exclude or None,
            project_languages=_project_languages,
            progress_callback=_rules_file_progress,
        ))

    # Record files scanned
    collector.metrics.files_scanned = rules_engine.files_scanned

    # Record per-agent metrics when using AgentOrchestrator
    from guard.core.orchestrator import AgentOrchestrator
    if isinstance(rules_engine, AgentOrchestrator):
        from guard.core.metrics import AgentMetrics
        for ar in rules_engine.agent_results:
            collector.metrics.agent_metrics.append(AgentMetrics(
                pack_id=ar.pack_id,
                duration_ms=ar.duration_ms,
                findings_count=len(ar.findings),
                files_scanned=ar.files_scanned,
                rule_count=ar.rule_count,
                error=ar.error,
            ))

    # Architecture rules enforcement (optional — runs if architecture.yaml exists)
    try:
        from guard.core.architecture import (
            check_architecture,
            load_arch_rules,
            violations_to_findings,
        )

        arch_rules = load_arch_rules()
        if arch_rules:
            if progress_callback:
                progress_callback("architecture", 0.35)
            arch_report = check_architecture(arch_rules, repo_root, changed_files)
            if arch_report.violations:
                findings.extend(violations_to_findings(arch_report.violations))
    except Exception:
        logger.debug("Architecture rules check failed", exc_info=True)

    # Policy-as-Code evaluation (if policies file exists)
    try:
        from guard.rules.policy_engine import (
            evaluate_policies,
            load_policies,
            policy_results_to_findings,
        )

        policies = load_policies()
        if policies:
            if progress_callback:
                progress_callback("policies", 0.38)
            policy_results = evaluate_policies(policies, repo_root, changed_files)
            policy_findings = policy_results_to_findings(policy_results)
            findings.extend(policy_findings)
    except Exception:
        logger.debug("Policy evaluation failed", exc_info=True)

    # Persist cache
    if cache is not None:
        cache.save()

    # C/C++ semantic analysis (optional)
    if config.cpp_analysis_enabled:
        if progress_callback:
            progress_callback("cpp_analysis", 0.4)
        try:
            from guard.core.cpp_analyzer import run_cpp_analysis
            cpp_results = run_cpp_analysis(
                repo_root,
                tool=config.cpp_analysis_tool,
                checks=config.cpp_analysis_checks,
                files=changed_files,
            )
            for cpp_result in cpp_results:
                findings.extend(cpp_result.findings)
                if cpp_result.errors:
                    for err in cpp_result.errors:
                        logger.warning("C/C++ analysis (%s): %s", cpp_result.tool, err)
        except Exception:
            logger.warning("C/C++ analysis failed", exc_info=True)

    # External scanner
    if progress_callback:
        progress_callback("scanner", 0.5)
    with collector.time_scanner():
        findings.extend(scanner.scan(repo_root, changed_files))

    # Always compute risk scores (lightweight, no license needed)
    try:
        from guard.ml.severity_estimator import extract_features, compute_score
        for i, f in enumerate(findings):
            if f.risk_score is None and not f.is_obligation:
                fv = extract_features(f)
                score = compute_score(fv)
                findings[i] = f.model_copy(update={"risk_score": {
                    "score": round(score, 3),
                    "exploitability": round(fv.exploitability, 3),
                    "blast_radius": round(fv.blast_radius, 3),
                    "data_sensitivity": round(fv.pattern_risk, 3),
                }})
    except Exception:
        pass  # Non-critical — skip if extraction fails

    # Heuristic severity rescoring
    if progress_callback:
        progress_callback("ml_severity", 0.7)
    if config.is_severity_rescoring_enabled:
        from guard.core.licensing import LicenseError, require_license

        try:
            require_license("ml", config.license_key)
            from guard.ml.severity_estimator import SeverityEstimator

            with collector.time_rescorer():
                estimator = SeverityEstimator()
                findings = estimator.estimate(findings)
        except LicenseError:
            pass  # ML not available at this tier; skip silently

    # LLM-powered confidence scoring (opt-in)
    if config.confidence_scoring_enabled and config.llm_provider != "stub":
        if progress_callback:
            progress_callback("confidence_scoring", 0.75)
        try:
            from guard.core.confidence_scorer import score_findings
            from guard.providers.factory import build_llm

            llm = build_llm(config)
            findings = score_findings(
                findings, llm,
                max_findings=config.confidence_scoring_max_findings,
            )
        except Exception:
            logger.warning("LLM confidence scoring failed — using heuristic scores", exc_info=True)

    # Suppression filter
    total_before_suppression = len(findings)
    suppressed_count = 0
    if config.suppressions:
        from guard.core.suppression import filter_suppressed
        findings, suppressed = filter_suppressed(findings, config.suppressions)
        suppressed_count = len(suppressed)

    # Traceability: link findings to work items extracted from branch name
    if progress_callback:
        progress_callback("traceability", 0.85)
    if branch:
        work_item_ids = extract_work_item_ids(branch)
        link_findings_to_work_items(findings, work_item_ids)

    collector.record_findings(findings)
    collector.metrics.suppressed_count = suppressed_count
    collector.metrics.total_before_suppression = total_before_suppression
    collector.stop()

    # Write metrics alongside other artifacts
    collector.metrics.save(config.output_dir)

    return findings


def write_artifacts(
    findings: list[Finding],
    config: GuardConfig,
    command: str,
    exit_code: int,
    duration_ms: float,
    changed_files: list[str] | None = None,
    repo_root: str = "",
    autofix_map: dict[str, str] | None = None,
    replacement_map: dict[str, str] | None = None,
    rules: list[dict] | None = None,
) -> Path:
    """Write all output artifacts to the output directory."""
    out = Path(config.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    patches_dir = out / "patches"
    patches_dir.mkdir(exist_ok=True)

    # Archive previous findings and metrics to history/
    _archive_history(out)

    # findings.json
    with open(out / "findings.json", "w", encoding="utf-8") as f:
        json.dump([fi.model_dump() for fi in findings], f, indent=2)

    # report.md
    with open(out / "report.md", "w", encoding="utf-8") as f:
        f.write(render_report(findings))

    # next_actions.md
    with open(out / "next_actions.md", "w", encoding="utf-8") as f:
        f.write(render_next_actions(findings))

    # run_metadata.json
    metadata = RunMetadata(
        run_id=str(uuid.uuid4()),
        timestamp=datetime.now(timezone.utc).isoformat(),
        guard_version=__version__,
        command=command,
        exit_code=exit_code,
        findings_count=len(findings),
        duration_ms=duration_ms,
        scoped_files=changed_files,
    )
    with open(out / "run_metadata.json", "w", encoding="utf-8") as f:
        json.dump(metadata.model_dump(), f, indent=2)

    # Generate patches for auto-fixable findings
    if repo_root and autofix_map:
        patches = generate_patches(findings, repo_root, autofix_map, replacement_map)
        write_patches(patches, patches_dir)

    # Generate reporter outputs (html, junit, sarif, etc.)
    reporters = build_reporters(config.reporters)
    for reporter in reporters:
        ext = reporter.extension
        report_path = out / f"report{ext}"
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(reporter.render(findings))

    # Auto-generate compliance reports for each framework found in findings.
    # Remove stale reports from previously-enabled packs first.
    try:
        from guard.reporters.compliance_report import generate_compliance_report, list_frameworks

        # Delete any compliance report from a prior scan that no longer has findings
        for stale in out.glob("compliance-report-*.html"):
            stale.unlink(missing_ok=True)

        frameworks = list_frameworks(findings)
        for fw in frameworks:
            slug = fw.lower().replace(" ", "-").replace("/", "-")
            report_path = out / f"compliance-report-{slug}.html"
            html = generate_compliance_report(findings, framework=fw)
            with open(report_path, "w", encoding="utf-8") as f:
                f.write(html)
        logger.debug("Compliance reports generated for: %s", frameworks or ["(none — no rules with standard/clause)"])
    except Exception:
        logger.warning("Compliance report generation failed", exc_info=True)  # Don't fail the scan

    # Auto-generate compliance evidence map alongside the compliance reports
    if rules:
        try:
            from guard.core.evidence_mapper import build_compliance_map, generate_evidence_html

            cmap = build_compliance_map(
                repo_root, rules=rules, findings=findings,
                scan_exclude=config.scan_exclude or [],
            )
            html = generate_evidence_html(cmap)
            with open(out / "evidence-map.html", "w", encoding="utf-8") as f:
                f.write(html)
            # Write fresh JSON cache so the dashboard serves correct data immediately
            import json as _json
            (out / "compliance-map.json").write_text(
                _json.dumps(cmap.to_dict(), indent=2), encoding="utf-8"
            )
            logger.debug("Evidence map generated")
        except Exception:
            logger.warning("Evidence map generation failed", exc_info=True)  # Don't fail the scan

    return out


def evaluate_gate(findings: list[Finding], config: GuardConfig) -> GateResult:
    """Determine pass/fail based on finding severities and config.

    Obligation findings (``is_obligation=True``) are excluded from gate
    evaluation — they appear in reports but never cause gate failure.
    """
    gate_findings = [f for f in findings if not f.is_obligation]

    counts = {s: 0 for s in Severity}
    for f in gate_findings:
        counts[f.severity] += 1

    fail_severities = {Severity(s) for s in config.gate_fail_on}
    has_failures = any(counts[s] > 0 for s in fail_severities)

    return GateResult(
        passed=not has_failures,
        total_findings=len(gate_findings),
        critical=counts[Severity.CRITICAL],
        high=counts[Severity.HIGH],
        medium=counts[Severity.MEDIUM],
        low=counts[Severity.LOW],
        info=counts[Severity.INFO],
    )


def build_autofix_map(rules: list[dict]) -> dict[str, str]:
    """Build a mapping of rule_id → autofix strategy from raw rule dicts."""
    result: dict[str, str] = {}
    for r in rules:
        rule_id = r.get("id")
        autofix = r.get("autofix")
        if rule_id and autofix:
            result[rule_id] = autofix
    return result


def build_replacement_map(rules: list[dict]) -> dict[str, str]:
    """Build a mapping of rule_id → replacement text for replace_match strategy."""
    result: dict[str, str] = {}
    for r in rules:
        rule_id = r.get("id")
        replacement = r.get("autofix_replacement")
        if rule_id and replacement is not None:
            result[rule_id] = replacement
    return result


def run_scan_and_write(
    repo_root: str,
    config: GuardConfig,
    rules_engine: RulesEngine,
    scanner: ScannersProvider,
    command: str = "scan",
    changed_files: list[str] | None = None,
    branch: str | None = None,
    autofix_map: dict[str, str] | None = None,
    replacement_map: dict[str, str] | None = None,
    progress_callback: Callable[[str, float], None] | None = None,
) -> tuple[list[Finding], GateResult, Path]:
    """Convenience: run scan, evaluate gate, write artifacts, return results."""
    start = perf_counter()
    findings = run_scan(
        repo_root, config, rules_engine, scanner, changed_files,
        branch=branch, progress_callback=progress_callback,
    )
    if progress_callback:
        progress_callback("writing", 0.95)
    gate = evaluate_gate(findings, config)

    # Async approval gate: if gate failed and async_approval is enabled,
    # create an approval request so a security-lead can approve/reject.
    if not gate.passed:
        try:
            approval_config = config.get_async_approval_config()
            if approval_config.enabled:
                from guard.core.approvals import create_approval_request
                approval = create_approval_request(gate, approval_config)
                gate.approval_id = approval.id
                gate.pending_approval = True
        except (ImportError, ValueError, KeyError):
            pass  # Approval feature unavailable — continue normally

    # Calculate compliance score
    rules_count = len(rules_engine._rules)
    compliance = calculate_compliance_score(findings, rules_count)

    duration_ms = (perf_counter() - start) * 1000
    exit_code = 0 if gate.passed else 1
    out = write_artifacts(
        findings, config, command, exit_code, duration_ms, changed_files,
        repo_root=repo_root, autofix_map=autofix_map, replacement_map=replacement_map,
        rules=rules_engine._rules,
    )

    # Append compliance score to scan_metrics.json and run_metadata.json
    for fname in ("scan_metrics.json", "run_metadata.json"):
        fpath = out / fname
        if fpath.exists():
            try:
                data = json.loads(fpath.read_text(encoding="utf-8"))
                data["compliance_score"] = compliance
                with open(fpath, "w", encoding="utf-8") as fp:
                    json.dump(data, fp, indent=2)
            except (json.JSONDecodeError, OSError):
                pass

    # Record to long-term metrics DB
    try:
        from guard.core.metrics_db import MetricsDB

        metrics_json_path = out / "scan_metrics.json"
        metadata_json_path = out / "run_metadata.json"

        # Build run_metadata dict from the files we just wrote
        db_run_meta: dict = {}
        if metadata_json_path.exists():
            db_run_meta = json.loads(metadata_json_path.read_text(encoding="utf-8"))
        db_run_meta.setdefault("run_id", str(uuid.uuid4()))
        db_run_meta.setdefault("timestamp", datetime.now(timezone.utc).isoformat())
        db_run_meta["command"] = command
        db_run_meta["duration_ms"] = duration_ms

        # Read files_scanned from metrics file
        if metrics_json_path.exists():
            scan_metrics_data = json.loads(metrics_json_path.read_text(encoding="utf-8"))
            db_run_meta["files_scanned"] = scan_metrics_data.get("files_scanned", 0)
            findings_by_sev = scan_metrics_data.get("findings_by_severity", {})
        else:
            findings_by_sev = {}

        db_path = Path(config.output_dir).parent / ".sentrik" / "local" / "metrics.db"
        # If output_dir is inside .sentrik already, use it directly
        sentrik_local = Path(".sentrik") / "local" / "metrics.db"

        db = MetricsDB(sentrik_local)
        try:
            db.record_scan(
                run_metadata=db_run_meta,
                findings_summary=findings_by_sev,
                compliance_score=compliance,
                gate_passed=gate.passed,
            )
        finally:
            db.close()
    except Exception:
        logger.debug("Failed to record scan to metrics DB", exc_info=True)

    # GRC platform integration: push compliance evidence
    try:
        from guard.core.grc_integration import (
            build_gate_payload,
            build_scan_payload,
            maybe_push_grc_event,
        )

        project_name = Path(repo_root).name if repo_root else "unknown"

        # Push scan_complete event
        scan_payload = build_scan_payload(
            findings_summary=compliance.get("severity_penalty", {}),
            compliance_score=compliance,
            project_name=project_name,
        )
        maybe_push_grc_event(config, "scan_complete", scan_payload)

        # Push gate_passed or gate_failed event
        gate_event = "gate_passed" if gate.passed else "gate_failed"
        gate_payload = build_gate_payload(gate, project_name)
        maybe_push_grc_event(config, gate_event, gate_payload)
    except Exception:
        logger.debug("GRC push failed", exc_info=True)

    if progress_callback:
        progress_callback("complete", 1.0)
    return findings, gate, out


def get_current_run_id(output_dir: str | Path) -> str | None:
    """Read the run_id from the current run_metadata.json."""
    metadata_path = Path(output_dir) / "run_metadata.json"
    if not metadata_path.exists():
        return None
    try:
        meta = json.loads(metadata_path.read_text(encoding="utf-8"))
        return meta.get("run_id")
    except (json.JSONDecodeError, OSError):
        return None


def export_audit_bundle(output_dir: Path, bundle_path: Path | None = None) -> Path:
    """Create a zip file containing all scan artifacts for auditors.

    Args:
        output_dir: Directory where scan artifacts live (typically ``out/``).
        bundle_path: Optional explicit path for the zip file. When *None*,
            the bundle is written to ``output_dir / audit-bundle-YYYY-MM-DD.zip``.

    Returns:
        Path to the created zip file.
    """
    import zipfile

    if bundle_path is None:
        date_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        bundle_path = output_dir / f"audit-bundle-{date_str}.zip"

    # Files to include (skip any that don't exist)
    artifact_names = [
        "findings.json",
        "run_metadata.json",
        "scan_metrics.json",
        "report.html",
        "report.sarif.json",
        "report.junit.xml",
        "report.csv",
        "report.md",
    ]

    with zipfile.ZipFile(bundle_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for name in artifact_names:
            artifact = output_dir / name
            if artifact.exists():
                zf.write(artifact, arcname=name)

        # Include history/ directory for trend data
        history_dir = output_dir / "history"
        if history_dir.exists() and history_dir.is_dir():
            for history_file in sorted(history_dir.iterdir()):
                if history_file.is_file():
                    zf.write(history_file, arcname=f"history/{history_file.name}")

    return bundle_path


def _archive_history(out: Path, max_history: int = 20) -> None:
    """Archive previous findings, metrics, and metadata to history/ dir.

    Only archives when findings have changed since the last archived run,
    keeping the trend line meaningful. The audit log (separate from history)
    still records every scan regardless.

    Also writes a manifest entry linking the run_id to the archived files
    so historical runs can be looked up by ID later.
    """
    import shutil

    history_dir = out / "history"
    findings_file = out / "findings.json"
    metrics_file = out / "scan_metrics.json"
    metadata_file = out / "run_metadata.json"

    if not findings_file.exists() and not metrics_file.exists():
        return

    # Check if findings have changed since last archived run
    skip_archive = False
    if metrics_file.exists() and history_dir.exists():
        try:
            current_metrics = json.loads(metrics_file.read_text(encoding="utf-8"))
            current_by_sev = current_metrics.get("findings_by_severity", {})
            archived = sorted(history_dir.glob("scan_metrics_*.json"))
            if archived:
                prev_metrics = json.loads(archived[-1].read_text(encoding="utf-8"))
                prev_by_sev = prev_metrics.get("findings_by_severity", {})
                if current_by_sev == prev_by_sev:
                    logger.debug("Findings unchanged since last archive — skipping history entry")
                    skip_archive = True
        except (json.JSONDecodeError, OSError):
            pass  # On any error, archive anyway

    if not skip_archive:
        history_dir.mkdir(exist_ok=True)
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")

        # Read run_id from previous run's metadata (if it exists)
        run_id = None
        run_timestamp = None
        command = None
        findings_count = None
        if metadata_file.exists():
            try:
                meta = json.loads(metadata_file.read_text(encoding="utf-8"))
                run_id = meta.get("run_id")
                run_timestamp = meta.get("timestamp")
                command = meta.get("command")
                findings_count = meta.get("findings_count")
            except (json.JSONDecodeError, OSError):
                pass

        archived_files = {}
        if findings_file.exists():
            name = f"findings_{ts}.json"
            shutil.copy2(findings_file, history_dir / name)
            archived_files["findings"] = name
        if metrics_file.exists():
            name = f"scan_metrics_{ts}.json"
            shutil.copy2(metrics_file, history_dir / name)
            archived_files["metrics"] = name
        if metadata_file.exists():
            name = f"run_metadata_{ts}.json"
            shutil.copy2(metadata_file, history_dir / name)
            archived_files["metadata"] = name

        # Write manifest entry linking run_id → archived files
        if run_id and archived_files:
            manifest_entry = {
                "run_id": run_id,
                "timestamp": run_timestamp or ts,
                "command": command,
                "findings_count": findings_count,
                "archived_at": ts,
                "files": archived_files,
            }
            try:
                import tempfile as _tmpfile
                manifest_path = history_dir / "manifest.jsonl"
                # Atomic append: read existing, append, write to temp, rename
                existing = ""
                if manifest_path.exists():
                    existing = manifest_path.read_text(encoding="utf-8")
                new_content = existing + json.dumps(manifest_entry) + "\n"
                fd, tmp_path = _tmpfile.mkstemp(
                    dir=str(history_dir), suffix=".tmp",
                )
                try:
                    with os.fdopen(fd, "w", encoding="utf-8") as f:
                        f.write(new_content)
                    Path(tmp_path).replace(manifest_path)
                except BaseException:
                    Path(tmp_path).unlink(missing_ok=True)
                    raise
            except OSError:
                pass

    # Retention: keep only the latest N entries (always runs)
    for pattern in ("findings_*.json", "scan_metrics_*.json", "run_metadata_*.json"):
        files = sorted(history_dir.glob(pattern))
        while len(files) > max_history:
            files.pop(0).unlink(missing_ok=True)

    # Trim manifest to match retention
    _trim_manifest(history_dir, max_history)


def _trim_manifest(history_dir: Path, max_entries: int = 20) -> None:
    """Keep only the latest *max_entries* lines in the manifest."""
    import tempfile as _tmpfile
    manifest_path = history_dir / "manifest.jsonl"
    if not manifest_path.exists():
        return
    try:
        lines = manifest_path.read_text(encoding="utf-8").strip().splitlines()
        if len(lines) > max_entries:
            lines = lines[-max_entries:]
            new_content = "\n".join(lines) + "\n"
            fd, tmp_path = _tmpfile.mkstemp(
                dir=str(history_dir), suffix=".tmp",
            )
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    f.write(new_content)
                Path(tmp_path).replace(manifest_path)
            except BaseException:
                Path(tmp_path).unlink(missing_ok=True)
                raise
    except OSError:
        pass


def list_historical_runs(output_dir: str | Path) -> list[dict]:
    """List all historical scan runs available for report generation.

    Returns a list of dicts with run_id, timestamp, command, findings_count,
    sorted newest-first.
    """
    history_dir = Path(output_dir) / "history"
    manifest_path = history_dir / "manifest.jsonl"
    if not manifest_path.exists():
        return []

    runs = []
    try:
        for line in manifest_path.read_text(encoding="utf-8").strip().splitlines():
            if line.strip():
                runs.append(json.loads(line))
    except (json.JSONDecodeError, OSError):
        return []

    runs.reverse()  # newest first
    return runs


def load_historical_findings(output_dir: str | Path, run_id: str) -> list[Finding] | None:
    """Load findings from a historical run by run_id.

    Returns a list of Finding objects, or None if the run_id is not found.
    """
    history_dir = Path(output_dir) / "history"
    manifest_path = history_dir / "manifest.jsonl"
    if not manifest_path.exists():
        return None

    # Find the manifest entry for this run_id
    target_entry = None
    try:
        for line in manifest_path.read_text(encoding="utf-8").strip().splitlines():
            if line.strip():
                entry = json.loads(line)
                if entry.get("run_id") == run_id:
                    target_entry = entry
    except (json.JSONDecodeError, OSError):
        return None

    if target_entry is None:
        return None

    findings_file = target_entry.get("files", {}).get("findings")
    if not findings_file:
        return None

    findings_path = history_dir / findings_file
    if not findings_path.exists():
        return None

    try:
        raw = json.loads(findings_path.read_text(encoding="utf-8"))
        return [Finding.model_validate(f) for f in raw]
    except (json.JSONDecodeError, OSError, ValueError):
        return None


def load_historical_metadata(output_dir: str | Path, run_id: str) -> dict | None:
    """Load run metadata from a historical run by run_id."""
    history_dir = Path(output_dir) / "history"
    manifest_path = history_dir / "manifest.jsonl"
    if not manifest_path.exists():
        return None

    target_entry = None
    try:
        for line in manifest_path.read_text(encoding="utf-8").strip().splitlines():
            if line.strip():
                entry = json.loads(line)
                if entry.get("run_id") == run_id:
                    target_entry = entry
    except (json.JSONDecodeError, OSError):
        return None

    if target_entry is None:
        return None

    metadata_file = target_entry.get("files", {}).get("metadata")
    if not metadata_file:
        return None

    metadata_path = history_dir / metadata_file
    if not metadata_path.exists():
        return None

    try:
        return json.loads(metadata_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None
