"""Compliance evidence mapper — finds code that *satisfies* requirements.

While the rules engine finds violations, this module finds evidence of
compliance: code locations where requirements ARE implemented correctly.

This enables audit-ready evidence reports:
  "File auth.py:45 implements AES-256 encryption, satisfying HIPAA §164.312(a)(2)(iv)"
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from guard.core.repo_reader import list_files
from guard.rules.rule_schema import RuleDefinition

logger = logging.getLogger(__name__)


@dataclass
class ComplianceEvidence:
    """A code location that satisfies a compliance requirement."""

    rule_id: str
    rule_name: str
    standard: str
    clause: str
    file: str
    line: int
    snippet: str
    message: str
    rule_type: str
    pack_id: str = ""


@dataclass
class RuleStatus:
    """Compliance status for a single rule."""

    rule_id: str
    rule_name: str
    standard: str
    clause: str
    rule_type: str
    status: str  # "met", "violated", "not_applicable", "manual_review"
    evidence: list[ComplianceEvidence] = field(default_factory=list)
    violations: int = 0
    files_checked: int = 0
    pack_id: str = ""
    description: str = ""
    remediation_guidance: str = ""


@dataclass
class ComplianceMap:
    """Full compliance evidence map for a project."""

    rules: list[RuleStatus] = field(default_factory=list)

    @property
    def met_count(self) -> int:
        return sum(1 for r in self.rules if r.status == "met")

    @property
    def violated_count(self) -> int:
        return sum(1 for r in self.rules if r.status == "violated")

    @property
    def manual_count(self) -> int:
        return sum(1 for r in self.rules if r.status == "manual_review")

    @property
    def not_applicable_count(self) -> int:
        return sum(1 for r in self.rules if r.status == "not_applicable")

    @property
    def total(self) -> int:
        return len(self.rules)

    @property
    def coverage_percent(self) -> float:
        applicable = self.met_count + self.violated_count
        if applicable == 0:
            return 100.0
        return round(self.met_count / applicable * 100, 1)

    def to_dict(self) -> dict[str, Any]:
        return {
            "summary": {
                "total_rules": self.total,
                "met": self.met_count,
                "violated": self.violated_count,
                "manual_review": self.manual_count,
                "not_applicable": self.not_applicable_count,
                "coverage_percent": self.coverage_percent,
            },
            "rules": [
                {
                    "rule_id": r.rule_id,
                    "rule_name": r.rule_name,
                    "standard": r.standard,
                    "clause": r.clause,
                    "rule_type": r.rule_type,
                    "status": r.status,
                    "pack_id": r.pack_id,
                    "description": r.description,
                    "violations": r.violations,
                    "files_checked": r.files_checked,
                    "evidence": [
                        {
                            "file": e.file,
                            "line": e.line,
                            "snippet": e.snippet,
                            "message": e.message,
                        }
                        for e in r.evidence
                    ],
                }
                for r in self.rules
            ],
        }


def _validate_rule(rule_dict: dict) -> RuleDefinition | None:
    """Validate and return a RuleDefinition, or None if invalid."""
    try:
        return RuleDefinition(**rule_dict)
    except Exception:
        return None


def _regulatory_meta(rule: RuleDefinition) -> tuple[str, str]:
    """Extract standard and clause from a rule."""
    return rule.standard or "", rule.clause or ""


def build_compliance_map(
    repo_root: str,
    rules: list[dict[str, Any]],
    findings: list[Any] | None = None,
    scan_exclude: list[str] | None = None,
) -> ComplianceMap:
    """Build a compliance evidence map by evaluating rules for evidence.

    For each rule:
    - required_pattern: check if the required pattern IS present → evidence
    - regex: check if the violation pattern is ABSENT → evidence (clean)
    - file_policy: check if the policy check PASSES → evidence
    - documentation_obligation: always manual_review
    """
    root = Path(repo_root)
    cmap = ComplianceMap()

    # Pre-compute exclude prefixes once for reuse throughout
    exclude_prefixes = _normalize_excludes(scan_exclude) if scan_exclude else []

    # Filter findings to exclude paths — findings.json may contain stale entries
    # from directories that have since been added to scan_exclude
    if findings and exclude_prefixes:
        def _finding_file(f: Any) -> str:
            if hasattr(f, "evidence"):
                ev = f.evidence
                return (ev.get("file", "") if isinstance(ev, dict) else getattr(ev, "file", "")) or ""
            return (f.get("evidence", {}) or {}).get("file", "") or ""

        findings = [f for f in findings if not _is_excluded(_finding_file(f), exclude_prefixes)]

    # Index remaining violations by rule_id for quick lookup
    violation_counts: dict[str, int] = {}
    if findings:
        for f in findings:
            rid = f.rule_id if hasattr(f, "rule_id") else f.get("rule_id", "")
            violation_counts[rid] = violation_counts.get(rid, 0) + 1

    for rule_dict in rules:
        rule = _validate_rule(rule_dict)
        if rule is None:
            continue

        standard, clause = _regulatory_meta(rule)
        pack_id = rule_dict.get("pack_id", "")

        # Documentation obligations — search for doc files that satisfy them
        if rule.type == "documentation_obligation":
            doc_evidence = _collect_documentation_evidence(
                rule, root, standard, clause, pack_id, scan_exclude=scan_exclude
            )
            status = "met" if doc_evidence else "manual_review"
            cmap.rules.append(RuleStatus(
                rule_id=rule.id,
                rule_name=rule.name,
                standard=standard,
                clause=clause,
                rule_type=rule.type,
                status=status,
                evidence=doc_evidence,
                pack_id=pack_id,
                description=rule.description or "",
                remediation_guidance=rule.remediation_guidance or "",
            ))
            continue

        # Requirement verification is project-level
        if rule.type == "requirement_verification":
            continue

        # Collect files for this rule (use pre-computed prefixes)
        paths = _collect_files(root, rule.file_glob, scan_exclude, _prefixes=exclude_prefixes)

        if not paths:
            cmap.rules.append(RuleStatus(
                rule_id=rule.id,
                rule_name=rule.name,
                standard=standard,
                clause=clause,
                rule_type=rule.type,
                status="not_applicable",
                files_checked=0,
                pack_id=pack_id,
                description=rule.description or "",
            ))
            continue

        evidence_list: list[ComplianceEvidence] = []
        violation_count = violation_counts.get(rule.id, 0)

        if rule.type == "required_pattern":
            evidence_list = _collect_required_pattern_evidence(
                rule, root, paths, standard, clause, pack_id
            )
        elif rule.type == "regex":
            evidence_list = _collect_regex_evidence(
                rule, root, paths, standard, clause, pack_id
            )
        elif rule.type == "file_policy":
            evidence_list = _collect_file_policy_evidence(
                rule, root, paths, standard, clause, pack_id
            )
        elif rule.type == "ast":
            evidence_list = _collect_ast_evidence(
                rule, root, paths, standard, clause, pack_id
            )

        # Determine status
        if evidence_list and violation_count == 0:
            status = "met"
        elif violation_count > 0:
            status = "violated"
        elif not evidence_list and violation_count == 0:
            # No evidence found but no violations either (e.g., regex rule with no matches)
            status = "met"
        else:
            status = "violated"

        cmap.rules.append(RuleStatus(
            rule_id=rule.id,
            rule_name=rule.name,
            standard=standard,
            clause=clause,
            rule_type=rule.type,
            status=status,
            evidence=evidence_list,
            violations=violation_count,
            files_checked=len(paths),
            pack_id=pack_id,
            description=rule.description or "",
            remediation_guidance=rule.remediation_guidance or "",
        ))

    return cmap


def _is_excluded(path: str, prefixes: list[str]) -> bool:
    """Return True if path matches any excluded prefix, exact path, or glob pattern.

    Handles:
    - Directory prefixes:  ``external/`` matches ``external/lib/foo.cpp``
    - Exact file paths:    ``src/gen.cpp`` matches ``src/gen.cpp`` exactly
    - Glob (no slash):     ``*.md`` matches any ``.md`` file at any depth
    - Glob (with slash):   ``docs/*.md`` matches ``.md`` files only under ``docs/``
    - Windows backslashes and case-insensitive comparison on Windows
    - Leading ``./`` on either the path or the prefix
    """
    import fnmatch
    import os
    normalized = path.replace("\\", "/")
    if normalized.startswith("./"):
        normalized = normalized[2:]
    if os.name == "nt":
        normalized = normalized.lower()
    for pfx in prefixes:
        if "*" in pfx or "?" in pfx:
            # Glob pattern — not normalized with trailing slash
            if "/" not in pfx:
                # No slash → match filename at any depth (like .gitignore semantics)
                filename = normalized.rsplit("/", 1)[-1]
                if fnmatch.fnmatch(filename, pfx):
                    return True
            else:
                # Has slash → match against full relative path
                if fnmatch.fnmatch(normalized, pfx):
                    return True
        else:
            # Directory prefix match (pfx ends with /)
            if normalized.startswith(pfx):
                return True
            # Exact file path match
            if normalized == pfx.rstrip("/"):
                return True
    return False


def _normalize_excludes(scan_exclude: list[str]) -> list[str]:
    """Normalize exclude patterns.

    - Directory/exact paths get a trailing slash appended for prefix matching.
    - Glob patterns (containing ``*`` or ``?``) are kept as-is (no trailing slash).
    - Leading ``./`` is stripped. Backslashes are converted to forward slashes.
    - Lowercased on Windows for case-insensitive matching.
    """
    import os
    prefixes = []
    for p in scan_exclude:
        p = p.replace("\\", "/")
        if p.startswith("./"):
            p = p[2:]
        # Leave glob patterns as-is; add trailing slash only for prefix/exact entries
        if "*" not in p and "?" not in p:
            p = p.rstrip("/") + "/"
        if os.name == "nt":
            p = p.lower()
        prefixes.append(p)
    return prefixes


def _collect_files(
    root: Path,
    file_glob: str,
    scan_exclude: list[str] | None,
    _prefixes: list[str] | None = None,
) -> list[str]:
    """Collect files matching the rule's glob pattern, respecting scan_exclude."""
    paths = list_files(root, file_glob)
    prefixes = _prefixes if _prefixes is not None else (_normalize_excludes(scan_exclude) if scan_exclude else [])
    if prefixes:
        paths = [p for p in paths if not _is_excluded(p, prefixes)]
    return paths


def _collect_required_pattern_evidence(
    rule: RuleDefinition,
    root: Path,
    paths: list[str],
    standard: str,
    clause: str,
    pack_id: str,
) -> list[ComplianceEvidence]:
    """For required_pattern rules, find WHERE the required pattern exists."""
    if not rule.pattern:
        return []
    try:
        pattern = re.compile(rule.pattern, re.MULTILINE)
    except re.error:
        return []

    evidence: list[ComplianceEvidence] = []
    for rel_path in paths:
        abs_path = root / rel_path
        try:
            content = abs_path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, PermissionError, OSError):
            continue

        for match in pattern.finditer(content):
            line_no = content[: match.start()].count("\n") + 1
            lines = content.splitlines()
            snippet = lines[line_no - 1] if line_no <= len(lines) else ""
            evidence.append(ComplianceEvidence(
                rule_id=rule.id,
                rule_name=rule.name,
                standard=standard,
                clause=clause,
                file=rel_path,
                line=line_no,
                snippet=snippet.strip(),
                message=f"Implements {rule.name}: {match.group(0)[:80]}",
                rule_type=rule.type,
                pack_id=pack_id,
            ))
            # One evidence per file is enough
            break

    return evidence


def _collect_regex_evidence(
    rule: RuleDefinition,
    root: Path,
    paths: list[str],
    standard: str,
    clause: str,
    pack_id: str,
) -> list[ComplianceEvidence]:
    """For regex rules, evidence = files that DON'T match the violation pattern.

    Additionally, look for positive counter-patterns when available.
    For example, if the rule bans MD5, look for SHA-256/bcrypt as evidence.
    """
    if not rule.pattern and not rule.all_patterns:
        return []

    try:
        if rule.all_patterns:
            patterns = [re.compile(p) for p in rule.all_patterns]
        else:
            patterns = [re.compile(rule.pattern)]
    except re.error:
        return []

    # Count clean files (no violation)
    clean_count = 0
    for rel_path in paths:
        abs_path = root / rel_path
        try:
            content = abs_path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, PermissionError, OSError):
            continue

        has_violation = False
        if rule.all_patterns:
            has_violation = all(p.search(content) for p in patterns)
        else:
            has_violation = bool(patterns[0].search(content))

        if not has_violation:
            clean_count += 1

    if clean_count == len(paths):
        return [ComplianceEvidence(
            rule_id=rule.id,
            rule_name=rule.name,
            standard=standard,
            clause=clause,
            file="(project-wide)",
            line=0,
            snippet="",
            message=f"No violations of {rule.name} across {clean_count} file(s)",
            rule_type=rule.type,
            pack_id=pack_id,
        )]

    return []


def _collect_file_policy_evidence(
    rule: RuleDefinition,
    root: Path,
    paths: list[str],
    standard: str,
    clause: str,
    pack_id: str,
) -> list[ComplianceEvidence]:
    """For file_policy rules, evidence = files that pass the policy check."""
    from guard.rules.engine import (
        _check_max_lines,
        _check_must_contain_pattern,
        _check_must_not_import,
        _check_starts_with_docstring,
        _check_max_function_count,
    )

    CHECK_MAP = {
        "starts_with_docstring": _check_starts_with_docstring,
        "max_lines": _check_max_lines,
        "must_contain_pattern": _check_must_contain_pattern,
        "must_not_import": _check_must_not_import,
        "max_function_count": _check_max_function_count,
    }

    check_name = rule.params.get("check") if rule.params else None
    check_fn = CHECK_MAP.get(check_name) if check_name else None
    if not check_fn:
        return []

    evidence: list[ComplianceEvidence] = []
    for rel_path in paths:
        abs_path = root / rel_path
        try:
            content = abs_path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, PermissionError, OSError):
            continue

        passed, _ = check_fn(content, rule.params or {})
        if passed:
            evidence.append(ComplianceEvidence(
                rule_id=rule.id,
                rule_name=rule.name,
                standard=standard,
                clause=clause,
                file=rel_path,
                line=1,
                snippet="",
                message=f"File passes {rule.name} policy check",
                rule_type=rule.type,
                pack_id=pack_id,
            ))

    return evidence


def _collect_ast_evidence(
    rule: RuleDefinition,
    root: Path,
    paths: list[str],
    standard: str,
    clause: str,
    pack_id: str,
) -> list[ComplianceEvidence]:
    """For AST rules, evidence = files with no AST violations."""
    # AST checks are complex — we simply report clean files
    evidence: list[ComplianceEvidence] = []
    for rel_path in paths:
        if not rel_path.endswith(".py"):
            continue
        abs_path = root / rel_path
        try:
            content = abs_path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, PermissionError, OSError):
            continue

        # Try to parse and verify no violations would be produced
        try:
            import ast
            ast.parse(content)
            evidence.append(ComplianceEvidence(
                rule_id=rule.id,
                rule_name=rule.name,
                standard=standard,
                clause=clause,
                file=rel_path,
                line=1,
                snippet="",
                message=f"File passes {rule.name} AST check",
                rule_type=rule.type,
                pack_id=pack_id,
            ))
        except SyntaxError:
            continue

    return evidence


_DOC_GLOBS = [
    "**/*.md", "**/*.adoc", "**/*.rst", "**/*.txt",
    "**/*.doc", "**/*.docx", "**/*.pdf",
    "**/docs/**", "**/documentation/**",
]

_DOC_EXTENSIONS = {".md", ".adoc", ".rst", ".txt"}


def _collect_documentation_evidence(
    rule: RuleDefinition,
    root: Path,
    standard: str,
    clause: str,
    pack_id: str,
    scan_exclude: list[str] | None = None,
) -> list[ComplianceEvidence]:
    """Search documentation files for content that satisfies an obligation.

    Looks for .md, .adoc, .rst, .txt files containing keywords from
    the rule name and description.
    """
    # Build search terms from rule name and description
    name_words = set(rule.name.lower().replace("-", " ").replace("_", " ").split())
    desc_words = set()
    if rule.description:
        desc_words = set(rule.description.lower().split())

    # Filter to meaningful keywords (4+ chars, skip common words)
    stop_words = {
        "must", "shall", "should", "with", "that", "this", "have", "from",
        "been", "were", "will", "does", "each", "file", "code", "rule",
        "into", "when", "only", "also", "than", "more", "less", "over",
        "under", "about", "between", "through", "during", "before", "after",
        "require", "required", "requires", "ensure", "include", "including",
    }
    keywords = {
        w for w in (name_words | desc_words)
        if len(w) >= 4 and w not in stop_words
    }

    if not keywords:
        return []

    evidence: list[ComplianceEvidence] = []

    # Search documentation files
    for glob in ["**/*.md", "**/*.adoc", "**/*.rst", "**/*.txt"]:
        try:
            doc_files = list_files(root, glob)
        except Exception:
            continue

        if scan_exclude:
            prefixes = _normalize_excludes(scan_exclude)
            doc_files = [p for p in doc_files if not _is_excluded(p, prefixes)]

        for rel_path in doc_files:
            abs_path = root / rel_path
            if abs_path.stat().st_size > 500_000:  # Skip very large files
                continue
            try:
                content = abs_path.read_text(encoding="utf-8").lower()
            except (UnicodeDecodeError, PermissionError, OSError):
                continue

            # Count how many keywords match
            matched = [kw for kw in keywords if kw in content]
            if len(matched) >= min(2, len(keywords)):
                # Find the first matching line for context
                lines = content.splitlines()
                match_line = 1
                snippet = ""
                for i, line in enumerate(lines):
                    if any(kw in line for kw in matched):
                        match_line = i + 1
                        snippet = line.strip()[:120]
                        break

                evidence.append(ComplianceEvidence(
                    rule_id=rule.id,
                    rule_name=rule.name,
                    standard=standard,
                    clause=clause,
                    file=rel_path,
                    line=match_line,
                    snippet=snippet,
                    message=f"Documentation found matching: {', '.join(matched[:5])}",
                    rule_type=rule.type,
                    pack_id=pack_id,
                ))
                break  # One doc file per rule is enough

    return evidence


def generate_evidence_html(cmap: ComplianceMap) -> str:
    """Generate an HTML report showing compliance evidence."""
    met = cmap.met_count
    violated = cmap.violated_count
    manual = cmap.manual_count
    na = cmap.not_applicable_count
    coverage = cmap.coverage_percent

    # Group by standard
    by_standard: dict[str, list[RuleStatus]] = {}
    for r in cmap.rules:
        key = r.standard or "General"
        if key not in by_standard:
            by_standard[key] = []
        by_standard[key].append(r)

    status_icon = {
        "met": '<span style="color:#22c55e;font-weight:700">MET</span>',
        "violated": '<span style="color:#ef4444;font-weight:700">VIOLATED</span>',
        "manual_review": '<span style="color:#f59e0b;font-weight:700">MANUAL</span>',
        "not_applicable": '<span style="color:#6b7280">N/A</span>',
    }

    rows = ""
    for std_name in sorted(by_standard.keys()):
        rules = by_standard[std_name]
        rows += f'<tr class="std-header"><td colspan="5"><strong>{std_name}</strong></td></tr>\n'
        for r in sorted(rules, key=lambda x: x.rule_id):
            icon = status_icon.get(r.status, r.status)
            ev_detail = ""
            if r.evidence:
                ev_items = []
                for e in r.evidence[:3]:
                    loc = f"{e.file}:{e.line}" if e.line else e.file
                    ev_items.append(f"<code>{loc}</code> — {e.message}")
                ev_detail = "<br>".join(ev_items)
                if len(r.evidence) > 3:
                    ev_detail += f"<br><em>...and {len(r.evidence) - 3} more</em>"
            elif r.status == "violated":
                ev_detail = f"{r.violations} violation(s) found"
            elif r.status == "manual_review":
                ev_detail = "Requires manual verification"

            rows += (
                f'<tr>'
                f'<td>{r.rule_id}</td>'
                f'<td>{r.clause}</td>'
                f'<td>{r.rule_name}</td>'
                f'<td>{icon}</td>'
                f'<td>{ev_detail}</td>'
                f'</tr>\n'
            )

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Sentrik Compliance Evidence Map</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; margin: 0; padding: 24px; background: #0d1117; color: #e6edf3; }}
  h1 {{ font-size: 1.8rem; margin-bottom: 8px; }}
  .summary {{ display: flex; gap: 16px; margin: 24px 0; flex-wrap: wrap; }}
  .card {{ background: #161b22; border: 1px solid #30363d; border-radius: 8px; padding: 16px 20px; min-width: 120px; }}
  .card .num {{ font-size: 2rem; font-weight: 700; }}
  .card .label {{ font-size: 0.85rem; color: #8b949e; }}
  .green {{ color: #22c55e; }}
  .red {{ color: #ef4444; }}
  .yellow {{ color: #f59e0b; }}
  .gray {{ color: #6b7280; }}
  .coverage {{ font-size: 3rem; font-weight: 800; }}
  table {{ width: 100%; border-collapse: collapse; margin-top: 24px; }}
  th {{ text-align: left; padding: 10px; background: #161b22; border-bottom: 2px solid #30363d; font-size: 0.85rem; text-transform: uppercase; color: #8b949e; }}
  td {{ padding: 8px 10px; border-bottom: 1px solid #21262d; font-size: 0.9rem; vertical-align: top; }}
  tr:hover {{ background: #161b22; }}
  .std-header td {{ background: #0d1117; padding: 12px 10px 6px; border-bottom: 1px solid #30363d; }}
  code {{ background: #21262d; padding: 2px 6px; border-radius: 3px; font-size: 0.85rem; }}
  em {{ color: #8b949e; }}
</style>
</head>
<body>

<h1>Compliance Evidence Map</h1>
<p style="color:#8b949e">Generated by Sentrik</p>

<div class="summary">
  <div class="card"><div class="coverage {'green' if coverage >= 80 else 'yellow' if coverage >= 50 else 'red'}">{coverage}%</div><div class="label">Coverage</div></div>
  <div class="card"><div class="num green">{met}</div><div class="label">Requirements Met</div></div>
  <div class="card"><div class="num red">{violated}</div><div class="label">Violated</div></div>
  <div class="card"><div class="num yellow">{manual}</div><div class="label">Manual Review</div></div>
  <div class="card"><div class="num gray">{na}</div><div class="label">Not Applicable</div></div>
</div>

<table>
<thead>
<tr><th>Rule</th><th>Clause</th><th>Requirement</th><th>Status</th><th>Evidence</th></tr>
</thead>
<tbody>
{rows}
</tbody>
</table>

</body>
</html>"""
