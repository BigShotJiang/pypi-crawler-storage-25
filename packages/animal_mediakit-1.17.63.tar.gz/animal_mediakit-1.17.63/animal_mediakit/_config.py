import os
from pathlib import Path

GATEWAY_BASE_URL: str = os.environ.get(
    "ANIMAL_GATEWAY_URL", "https://animal-gateway.kxxxl.com"
)

TOKEN_DIR: Path = Path(
    os.environ.get(
        "ANIMAL_MEDIAKIT_TOKEN_DIR",
        str(Path.home() / ".config" / "animal-mediakit"),
    )
)

TOKEN_FILE: Path = TOKEN_DIR / "credentials.json"
PENDING_SSO_FILE: Path = TOKEN_DIR / "pending_sso.json"

CLI_JWT_EXPIRATION_HOURS: int = int(
    os.environ.get("ANIMAL_MEDIAKIT_JWT_EXPIRATION_HOURS", "168")
)

EXPIRY_BUFFER_SECS: int = 300

VIDEO_POLL_INTERVAL_SECS: int = 10
VIDEO_POLL_TIMEOUT_SECS: int = 600

SSO_POLL_INTERVAL_SECS: int = 2
SSO_POLL_TIMEOUT_SECS: int = 300

VOD_POLL_INTERVAL_SECS: int = 15
VOD_POLL_TIMEOUT_SECS: int = 600
