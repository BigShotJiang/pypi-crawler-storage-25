from __future__ import annotations

import os
from pathlib import Path
from typing import Optional, Tuple

from PIL import Image


def _open(src: str | Path) -> Image.Image:
    return Image.open(str(src))


def _save(img: Image.Image, dst: str | Path, quality: Optional[int] = None) -> None:
    dst = Path(dst)
    dst.parent.mkdir(parents=True, exist_ok=True)
    fmt = dst.suffix.lstrip(".").upper()
    if fmt == "JPG":
        fmt = "JPEG"
    save_kwargs: dict = {"format": fmt} if fmt else {}
    if quality is not None and fmt in ("JPEG", "WEBP"):
        save_kwargs["quality"] = quality
    img.save(str(dst), **save_kwargs)


def get_info(src: str | Path) -> dict:
    img = _open(src)
    stat = os.stat(str(src))
    return {
        "width": img.width,
        "height": img.height,
        "format": img.format or Path(str(src)).suffix.lstrip(".").upper(),
        "mode": img.mode,
        "file_size_bytes": stat.st_size,
    }


def crop(src: str | Path, rect: Tuple[int, int, int, int], dst: str | Path) -> dict:
    x, y, w, h = rect
    img = _open(src)
    cropped = img.crop((x, y, x + w, y + h))
    _save(cropped, dst)
    return get_info(dst)


def resize(
    src: str | Path,
    dst: str | Path,
    width: Optional[int] = None,
    height: Optional[int] = None,
    scale: Optional[float] = None,
) -> dict:
    img = _open(src)
    if scale is not None:
        new_w = int(img.width * scale)
        new_h = int(img.height * scale)
    elif width and height:
        new_w, new_h = width, height
    elif width:
        ratio = width / img.width
        new_w, new_h = width, int(img.height * ratio)
    elif height:
        ratio = height / img.height
        new_w, new_h = int(img.width * ratio), height
    else:
        raise ValueError("resize requires width, height, or scale")
    resized = img.resize((new_w, new_h), Image.LANCZOS)
    _save(resized, dst)
    return get_info(dst)


def flip(src: str | Path, direction: str, dst: str | Path) -> dict:
    img = _open(src)
    if direction == "horizontal":
        flipped = img.transpose(Image.FLIP_LEFT_RIGHT)
    elif direction == "vertical":
        flipped = img.transpose(Image.FLIP_TOP_BOTTOM)
    else:
        raise ValueError(f"direction must be 'horizontal' or 'vertical', got: {direction}")
    _save(flipped, dst)
    return get_info(dst)


def rotate(src: str | Path, angle: int, dst: str | Path) -> dict:
    img = _open(src)
    rotated = img.rotate(angle, expand=True)
    _save(rotated, dst)
    return get_info(dst)


def convert_format(src: str | Path, fmt: str, dst: str | Path) -> dict:
    img = _open(src)
    if img.mode in ("RGBA", "P") and fmt.upper() in ("JPEG", "JPG"):
        img = img.convert("RGB")
    _save(img, dst)
    return get_info(dst)


def compress(src: str | Path, quality: int, dst: str | Path) -> dict:
    img = _open(src)
    if img.mode in ("RGBA", "P"):
        fmt = Path(str(dst)).suffix.lstrip(".").upper()
        if fmt in ("JPEG", "JPG"):
            img = img.convert("RGB")
    _save(img, dst, quality=quality)
    return get_info(dst)
