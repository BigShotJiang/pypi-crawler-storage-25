from __future__ import annotations

import json
import sys
import time
from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class OperationResult:
    status: str
    operation: str
    output: Optional[str] = None
    metadata: dict = field(default_factory=dict)
    provider: Optional[str] = None
    model: Optional[str] = None
    duration_ms: int = 0
    error_code: Optional[str] = None
    message: Optional[str] = None
    details: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        d: dict[str, Any] = {"status": self.status, "operation": self.operation}
        if self.output is not None:
            d["output"] = self.output
        if self.metadata:
            d["metadata"] = self.metadata
        if self.provider:
            d["provider"] = self.provider
        if self.model:
            d["model"] = self.model
        if self.duration_ms:
            d["duration_ms"] = self.duration_ms
        if self.error_code:
            d["error_code"] = self.error_code
        if self.message:
            d["message"] = self.message
        if self.details:
            d["details"] = self.details
        return d


class OutputFormatter:
    def __init__(self, json_mode: bool = False):
        self.json_mode = json_mode

    def success(self, result: OperationResult) -> None:
        if self.json_mode:
            print(json.dumps(result.to_dict(), ensure_ascii=False))
        else:
            print(f"✅ {result.operation}")
            if result.output:
                print(f"   输出: {result.output}")
            if result.metadata:
                for k, v in result.metadata.items():
                    print(f"   {k}: {v}")
            if result.duration_ms:
                print(f"   耗时: {result.duration_ms}ms")

    def error(self, result: OperationResult) -> None:
        if self.json_mode:
            print(json.dumps(result.to_dict(), ensure_ascii=False))
        else:
            print(f"❌ {result.operation}: {result.message}", file=sys.stderr)
            if result.details:
                print(f"   详情: {result.details}", file=sys.stderr)
        sys.exit(1)


_start_time: float = 0.0


def start_timer() -> None:
    global _start_time
    _start_time = time.monotonic()


def elapsed_ms() -> int:
    return int((time.monotonic() - _start_time) * 1000)
