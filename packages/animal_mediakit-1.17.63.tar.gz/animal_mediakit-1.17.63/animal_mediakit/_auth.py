from __future__ import annotations

import json
import sys
import time
import uuid
import webbrowser
from typing import Optional

import httpx

from ._config import (
    CLI_JWT_EXPIRATION_HOURS,
    EXPIRY_BUFFER_SECS,
    GATEWAY_BASE_URL,
    PENDING_SSO_FILE,
    SSO_POLL_INTERVAL_SECS,
    SSO_POLL_TIMEOUT_SECS,
    TOKEN_DIR,
    TOKEN_FILE,
)


def _save_pending_sso(key_id: str) -> None:
    TOKEN_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)
    PENDING_SSO_FILE.write_text(
        json.dumps({"key_id": key_id, "created_at": time.time()}, indent=2)
    )
    PENDING_SSO_FILE.chmod(0o600)


def _load_pending_sso() -> Optional[str]:
    if not PENDING_SSO_FILE.exists():
        return None
    try:
        data = json.loads(PENDING_SSO_FILE.read_text())
        key_id = data.get("key_id")
        created_at = data.get("created_at", 0)
        if key_id and time.time() < created_at + SSO_POLL_TIMEOUT_SECS:
            return key_id
    except Exception:
        pass
    return None


def _clear_pending_sso() -> None:
    try:
        if PENDING_SSO_FILE.exists():
            PENDING_SSO_FILE.unlink()
    except Exception:
        pass


def _save_credentials(data: dict) -> None:
    TOKEN_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)
    TOKEN_FILE.write_text(json.dumps(data, indent=2, ensure_ascii=False))
    TOKEN_FILE.chmod(0o600)


def _load_credentials() -> Optional[dict]:
    if not TOKEN_FILE.exists():
        return None
    try:
        return json.loads(TOKEN_FILE.read_text())
    except Exception:
        return None


def _is_valid(creds: dict) -> bool:
    token = creds.get("gateway_token", "")
    if not token:
        return False
    saved_at = creds.get("saved_at", 0)
    expiry_secs = CLI_JWT_EXPIRATION_HOURS * 3600
    return time.time() < saved_at + expiry_secs - EXPIRY_BUFFER_SECS


def _poll_once(key_id: str, team_id: Optional[str] = None) -> Optional[dict]:
    url = f"{GATEWAY_BASE_URL}/sso/cli/poll/{key_id}"
    if team_id:
        url = f"{url}?team_id={team_id}"
    try:
        resp = httpx.get(url, timeout=10)
        if resp.status_code == 200:
            return resp.json()
    except httpx.RequestError:
        pass
    return None


def _has_media_permissions(token: str) -> bool:
    _MEDIA_MODEL_PATTERNS = (
        "image",
        "video",
        "veo",
        "sora",
        "seedream",
        "seedance",
        "wan",
        "kling",
        "vidu",
        "gem",
        "si-",
        "gv-",
        "gpt-image",
        "imagen",
    )
    try:
        resp = httpx.get(
            f"{GATEWAY_BASE_URL}/v1/models",
            headers={"Authorization": f"Bearer {token}"},
            timeout=15,
        )
        if resp.status_code != 200:
            return False
        models: list = resp.json().get("data", [])
        for m in models:
            model_id: str = (m.get("id") or "").lower()
            if any(pat in model_id for pat in _MEDIA_MODEL_PATTERNS):
                return True
    except Exception:
        pass
    return False


def _auto_select_team(
    teams: list[dict],
    preferred_team_id: Optional[str] = None,
) -> tuple[str, list[dict]]:
    if preferred_team_id:
        for t in teams:
            if t.get("team_id") == preferred_team_id:
                return preferred_team_id, teams
        raise RuntimeError(
            f"指定的 team_id={preferred_team_id!r} 不在可用团队列表中。"
            f"可用: {[t.get('team_id') for t in teams]}"
        )

    return str(teams[0].get("team_id", "")), teams


def _poll_for_sso_token(
    key_id: str,
    preferred_team_id: Optional[str] = None,
) -> Optional[dict]:
    deadline = time.time() + SSO_POLL_TIMEOUT_SECS
    while time.time() < deadline:
        data = _poll_once(key_id)
        if data is None:
            time.sleep(SSO_POLL_INTERVAL_SECS)
            continue

        status = data.get("status")

        if status == "pending":
            print(".", end="", flush=True, file=sys.stderr)
            time.sleep(SSO_POLL_INTERVAL_SECS)
            continue

        if status == "ready":
            if data.get("requires_team_selection"):
                team_details = data.get("team_details") or [
                    {"team_id": t} for t in data.get("teams", [])
                ]
                initial_team_id, all_teams = _auto_select_team(
                    team_details, preferred_team_id
                )

                print("⏳ 正在获取团队 token", end="", file=sys.stderr)
                deadline2 = time.time() + 30
                first_result = None
                while time.time() < deadline2:
                    r = _poll_once(key_id, team_id=initial_team_id)
                    if r and r.get("status") == "ready" and r.get("key"):
                        first_result = r
                        break
                    print(".", end="", flush=True, file=sys.stderr)
                    time.sleep(SSO_POLL_INTERVAL_SECS)

                if not first_result:
                    return None

                first_token = first_result["key"]

                if preferred_team_id:
                    selected_team_id = preferred_team_id
                    selected_token = first_token
                else:
                    print(
                        "\n🔍 检测到多个团队，正在查找有图像/视频生成权限的团队...",
                        file=sys.stderr,
                    )
                    selected_team_id = initial_team_id
                    selected_token = first_token

                    initial_alias = next(
                        (
                            t.get("team_alias") or t.get("team_id")
                            for t in all_teams
                            if t.get("team_id") == initial_team_id
                        ),
                        initial_team_id,
                    )
                    if _has_media_permissions(first_token):
                        print(
                            f"   ✅ {initial_alias} ({initial_team_id}) 有媒体权限，自动选择",
                            file=sys.stderr,
                        )
                    else:
                        print(
                            f"   ⛔ {initial_alias} ({initial_team_id}) 无媒体权限，跳过",
                            file=sys.stderr,
                        )
                        for t in all_teams:
                            tid = str(t.get("team_id", ""))
                            if tid == initial_team_id:
                                continue
                            alias = t.get("team_alias") or tid
                            switched = _switch_team_via_api(first_token, tid)
                            if switched and switched.get("key"):
                                if _has_media_permissions(switched["key"]):
                                    print(
                                        f"   ✅ {alias} ({tid}) 有媒体权限，自动选择",
                                        file=sys.stderr,
                                    )
                                    selected_team_id = tid
                                    selected_token = switched["key"]
                                    first_result = switched
                                    break
                                else:
                                    print(
                                        f"   ⛔ {alias} ({tid}) 无媒体权限，跳过",
                                        file=sys.stderr,
                                    )
                        else:
                            print(
                                "\n⚠️  所有团队均无图像/视频生成权限，将使用第一个团队。",
                                file=sys.stderr,
                            )

                selected_alias = next(
                    (
                        t.get("team_alias") or t.get("team_id")
                        for t in all_teams
                        if t.get("team_id") == selected_team_id
                    ),
                    selected_team_id,
                )
                print(
                    f"\n\n🏢 自动选择团队: {selected_alias} ({selected_team_id})",
                    file=sys.stderr,
                )
                print("   全部可用团队:", file=sys.stderr)
                for t in all_teams:
                    alias = t.get("team_alias") or t.get("team_id", "")
                    marker = (
                        " ← 当前选择" if t.get("team_id") == selected_team_id else ""
                    )
                    print(
                        f"     - {alias} (team_id={t.get('team_id')}){marker}",
                        file=sys.stderr,
                    )
                print(
                    "   如需切换团队，请运行: animal-mediakit auth login --team-id <team_id>",
                    file=sys.stderr,
                )

                first_result["_team_details"] = all_teams
                first_result["_selected_team_id"] = selected_team_id
                first_result["_selected_team_alias"] = selected_alias
                first_result["key"] = selected_token
                return first_result

            return data

        time.sleep(SSO_POLL_INTERVAL_SECS)

    return None


def _browser_login(
    open_browser: bool = True,
    preferred_team_id: Optional[str] = None,
) -> dict:
    existing_key_id = _load_pending_sso()
    if existing_key_id:
        key_id = existing_key_id
        sso_url = f"{GATEWAY_BASE_URL}/sso/key/generate?source=litellm-cli&key={key_id}"
        if preferred_team_id:
            sso_url += f"&preferred_team_id={preferred_team_id}"
        print(f"\n🌐 复用已有登录 URL: {sso_url}", file=sys.stderr)
        print("请手动访问以上 URL 完成登录（如已点击，稍等片刻...）", file=sys.stderr)
    else:
        key_id = f"sk-{uuid.uuid4()}"
        sso_url = f"{GATEWAY_BASE_URL}/sso/key/generate?source=litellm-cli&key={key_id}"
        if preferred_team_id:
            sso_url += f"&preferred_team_id={preferred_team_id}"
        _save_pending_sso(key_id)
        print(f"\n🌐 登录 URL: {sso_url}", file=sys.stderr)
        if open_browser:
            print("🚀 正在打开浏览器...", file=sys.stderr)
            webbrowser.open(sso_url)
        else:
            print("请手动访问以上 URL 完成登录", file=sys.stderr)

    print("⏳ 等待认证完成（最多 5 分钟）", end="", file=sys.stderr)
    result = _poll_for_sso_token(key_id, preferred_team_id=preferred_team_id)
    print("", file=sys.stderr)

    if not result:
        _clear_pending_sso()
        raise RuntimeError("SSO 超时或被取消，请重试")

    _clear_pending_sso()

    token = result.get("key")
    if not token:
        raise RuntimeError("认证完成但未获取到 Token，请联系管理员")

    team_id = result.get("team_id") or result.get("_selected_team_id", "")
    team_alias = result.get("team_alias") or result.get("_selected_team_alias", "")
    all_teams = result.get("team_details") or result.get("_team_details", [])

    if team_alias and team_id:
        print(
            f"\n\n🏢 当前团队: {team_alias} ({team_id})",
            file=sys.stderr,
        )
        all_teams_list = result.get("team_details") or []
        if len(all_teams_list) > 1:
            print("   全部可用团队:", file=sys.stderr)
            for t in all_teams_list:
                alias = t.get("team_alias") or t.get("team_id", "")
                marker = " ← 当前选择" if t.get("team_id") == team_id else ""
                print(
                    f"     - {alias} (team_id={t.get('team_id')}){marker}",
                    file=sys.stderr,
                )
            print(
                "   如需切换团队，请运行: "
                "animal-mediakit auth login --team-id <team_id>",
                file=sys.stderr,
            )

    creds = {
        "gateway_token": token,
        "user_id": result.get("user_id", ""),
        "team_id": team_id,
        "team_alias": team_alias,
        "all_teams": all_teams,
        "saved_at": time.time(),
        "gateway_url": GATEWAY_BASE_URL,
    }
    return creds


def _switch_team_via_api(current_token: str, team_id: str) -> Optional[dict]:
    try:
        resp = httpx.post(
            f"{GATEWAY_BASE_URL}/sso/cli/switch-team",
            headers={"Authorization": f"Bearer {current_token}"},
            json={"team_id": team_id},
            timeout=15,
        )
        if resp.status_code == 200:
            return resp.json()
    except Exception:
        pass
    return None


def get_gateway_token(
    *,
    refresh: bool = False,
    open_browser: bool = True,
    preferred_team_id: Optional[str] = None,
) -> str:
    creds = _load_credentials()

    if preferred_team_id and creds and _is_valid(creds):
        current_token = creds.get("gateway_token", "")
        if current_token and creds.get("team_id") != preferred_team_id:
            print(f"🔄 切换团队到 {preferred_team_id}...", file=sys.stderr)
            result = _switch_team_via_api(current_token, preferred_team_id)
            if result and result.get("key"):
                all_teams = creds.get("all_teams", [])
                raw_teams = result.get("teams")
                merged_all_teams = (
                    [{"team_id": t} for t in raw_teams] if raw_teams else all_teams
                )
                new_creds = {
                    "gateway_token": result["key"],
                    "user_id": result.get("user_id", creds.get("user_id", "")),
                    "team_id": result.get("team_id", preferred_team_id),
                    "team_alias": result.get("team_alias", ""),
                    "all_teams": merged_all_teams,
                    "saved_at": time.time(),
                    "gateway_url": GATEWAY_BASE_URL,
                }
                _save_credentials(new_creds)
                print(
                    f"✅ 已切换到团队: {result.get('team_alias') or preferred_team_id}",
                    file=sys.stderr,
                )
                return str(new_creds["gateway_token"])
            print("⚠️  API 切换失败，回退到浏览器登录...", file=sys.stderr)

    if not refresh:
        if creds and _is_valid(creds):
            return creds["gateway_token"]

    creds = _browser_login(
        open_browser=open_browser,
        preferred_team_id=preferred_team_id,
    )
    _save_credentials(creds)
    return creds["gateway_token"]


def get_auth_headers(*, refresh: bool = False) -> dict[str, str]:
    return {"Authorization": f"Bearer {get_gateway_token(refresh=refresh)}"}


def logout() -> bool:
    if TOKEN_FILE.exists():
        TOKEN_FILE.unlink()
        return True
    return False


def status() -> dict:
    creds = _load_credentials()
    if not creds:
        return {
            "status": "no_credentials",
            "message": "请运行: animal-mediakit auth login",
        }

    valid = _is_valid(creds)
    saved_at = creds.get("saved_at", 0)
    expiry_secs = CLI_JWT_EXPIRATION_HOURS * 3600
    expires_at = saved_at + expiry_secs
    expires_in = max(0, int(expires_at - time.time()))

    token = creds.get("gateway_token", "")
    key_prefix = token[:16] + "..." if len(token) > 16 else token

    all_teams = creds.get("all_teams", [])
    result: dict = {
        "status": "valid" if valid else "expired",
        "user_id": creds.get("user_id", ""),
        "team_id": creds.get("team_id", ""),
        "team_alias": creds.get("team_alias", ""),
        "gateway_url": creds.get("gateway_url", GATEWAY_BASE_URL),
        "expires_in_seconds": expires_in,
        "expires_in_hours": round(expires_in / 3600, 1),
        "token_prefix": key_prefix,
    }
    if all_teams:
        result["all_teams"] = all_teams
        result["switch_team_hint"] = (
            "如需切换团队，请运行: "
            "animal-mediakit auth login --refresh --team-id <team_id>"
        )
    return result
