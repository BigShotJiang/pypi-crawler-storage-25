from __future__ import annotations

from pathlib import Path
from typing import Optional

from .._output import OperationResult, elapsed_ms, start_timer
from ..providers.openai import openai_image_edit

DEFAULT_EDIT_MODEL = "openai/gpt-image-1.5"


def run_edit_image(
    prompt: str,
    image_path: Optional[str | Path] = None,
    output: str | Path = "output.png",
    model: str = DEFAULT_EDIT_MODEL,
    mask_path: Optional[str | Path] = None,
    size: str = "1024x1024",
    ref_images: Optional[list[str | Path]] = None,
) -> OperationResult:
    start_timer()
    output = Path(output)

    images = openai_image_edit(
        prompt=prompt,
        image_path=image_path,
        model=model,
        mask_path=mask_path,
        size=size,
        ref_images=ref_images,
    )

    if not images:
        raise RuntimeError("图像编辑接口未返回数据")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(images[0])
    ms = elapsed_ms()
    from ..local.image import get_info
    meta = get_info(output)
    meta["prompt"] = prompt
    if image_path:
        meta["source_image"] = str(image_path)
    if mask_path:
        meta["mask"] = str(mask_path)
    if ref_images:
        meta["ref_images"] = [str(p) for p in ref_images]
    return OperationResult(
        status="success",
        operation="edit.image",
        output=str(output),
        metadata=meta,
        provider="openai",
        model=model,
        duration_ms=ms,
    )
