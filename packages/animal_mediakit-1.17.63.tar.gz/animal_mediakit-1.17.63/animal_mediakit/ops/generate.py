from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

from .._output import OperationResult, elapsed_ms, start_timer
from ..providers._base import download_file
from ..providers.alibaba import (
    dashscope_image_generate,
    dashscope_video_poll,
    dashscope_video_submit,
)
from ..providers.gemini import (
    generate_image,
    generate_video_veo,
    veo_video_poll,
)
from ..providers.openai import (
    openai_image_generate,
    openai_video_download,
    openai_video_poll,
    openai_video_submit,
)
from ..providers.volcengine import (
    ark_image_generate,
    ark_video_poll,
    ark_video_submit,
)
from ..providers.tencent_vod import (
    parse_vod_model,
    vod_face_info,
    vod_image_submit,
    vod_task_poll,
    vod_video_submit,
)

import os as _os

DEFAULT_IMAGE_MODEL = _os.environ.get(
    "MEDIAKIT_DEFAULT_IMAGE_MODEL", "gemini/gemini-2.5-flash-image"
)
DEFAULT_VIDEO_MODEL = _os.environ.get(
    "MEDIAKIT_DEFAULT_VIDEO_MODEL", "gemini/veo-2.0-generate-001"
)
DEFAULT_ARK_IMAGE_MODEL = "doubao-seedream-5-0-260128"
DEFAULT_SEEDANCE_MODEL = "doubao-seedance-2-0-260128"


def _get_provider(model: str) -> str:
    if model.startswith("vod/"):
        return "tencent_vod"
    if model in ("tencent/gpt-image-2",):
        return "openai"
    if model.startswith(("openai/", "azure/", "gpt-image", "sora")):
        return "openai"
    if model.startswith(("dashscope/", "wan", "qwen")):
        return "alibaba"
    if model.startswith(("ep-", "doubao-", "seedance", "seedream")):
        return "volcengine"
    return "gemini"


def _is_ark_model(model: str) -> bool:
    return model.startswith(("ep-", "doubao-", "seedance", "seedream"))


def run_generate_image(
    prompt: str,
    output: str | Path,
    model: str = DEFAULT_IMAGE_MODEL,
    size: str = "1024x1024",
    negative_prompt: Optional[str] = None,
    seed: Optional[int] = None,
    guidance_scale: Optional[float] = None,
    quality: Optional[str] = None,
    background: Optional[str] = None,
    style: Optional[str] = None,
    output_format: Optional[str] = None,
    prompt_extend: Optional[bool] = None,
    ref_images: Optional[list[str | Path]] = None,
    aspect_ratio: Optional[str] = None,
    image_size: Optional[str] = None,
) -> OperationResult:
    start_timer()
    output = Path(output)
    provider = _get_provider(model)

    if provider == "openai":
        kwargs: dict = {"prompt": prompt, "model": model, "size": size}
        if quality:
            kwargs["quality"] = quality
        if background:
            kwargs["background"] = background
        if style:
            kwargs["style"] = style
        if output_format:
            kwargs["output_format"] = output_format
        images = openai_image_generate(**kwargs)
    elif provider == "alibaba":
        ds_size = size.replace("x", "*")
        kwargs = {"prompt": prompt, "model": model, "size": ds_size}
        if seed is not None:
            kwargs["seed"] = seed
        if prompt_extend is not None:
            kwargs["prompt_extend"] = prompt_extend
        images = dashscope_image_generate(**kwargs)
    elif provider == "volcengine":
        images = ark_image_generate(
            prompt=prompt,
            model=model,
            size=size,
            negative_prompt=negative_prompt,
            seed=seed,
            guidance_scale=guidance_scale,
        )
    elif provider == "tencent_vod":
        model_name, model_version = parse_vod_model(model)
        task_id = vod_image_submit(
            prompt=prompt,
            model_name=model_name,
            model_version=model_version,
            resolution=size.replace("x", "P").split("P")[0] + "P"
            if "x" in size
            else size,
            negative_prompt=negative_prompt,
        )
        print("", file=sys.stderr)
        result_data = vod_task_poll(task_id)
        print("", file=sys.stderr)
        image_url = _extract_vod_image_url(result_data)
        if not image_url:
            raise RuntimeError(f"VOD 生图完成但未找到下载地址，响应: {result_data}")
        download_file(image_url, output)
        ms = elapsed_ms()
        from ..local.image import get_info

        meta = get_info(output)
        meta["prompt"] = prompt
        meta["task_id"] = task_id
        if negative_prompt:
            meta["negative_prompt"] = negative_prompt
        return OperationResult(
            status="success",
            operation="generate.image",
            output=str(output),
            metadata=meta,
            provider=provider,
            model=model,
            duration_ms=ms,
        )
    else:
        images = generate_image(
            prompt=prompt,
            model=model,
            size=size,
            ref_images=ref_images,
            aspect_ratio=aspect_ratio,
            image_size=image_size,
        )

    if not images:
        raise RuntimeError("图像生成接口未返回数据")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(images[0])
    ms = elapsed_ms()
    from ..local.image import get_info

    meta = get_info(output)
    meta["prompt"] = prompt
    if negative_prompt:
        meta["negative_prompt"] = negative_prompt
    if seed is not None:
        meta["seed"] = seed
    return OperationResult(
        status="success",
        operation="generate.image",
        output=str(output),
        metadata=meta,
        provider=provider,
        model=model,
        duration_ms=ms,
    )


def _extract_ark_video_url(result_data: dict) -> Optional[str]:
    content = result_data.get("content")
    if isinstance(content, dict):
        for key in ("video_url", "file_url", "url"):
            if content.get(key):
                return content[key]
    elif isinstance(content, list):
        for item in content:
            if item.get("type") == "video_url":
                url = item.get("video_url", {}).get("url")
                if url:
                    return url
    for key in ("video_url", "url", "output_url"):
        if result_data.get(key):
            return result_data[key]
    return None


def _extract_ark_last_frame_url(result_data: dict) -> Optional[str]:
    content = result_data.get("content")
    if isinstance(content, dict):
        return content.get("last_frame_url")
    return None


def _extract_dashscope_video_url(result_data: dict) -> Optional[str]:
    output = result_data.get("output", {})
    video_url = output.get("video_url")
    if video_url:
        return video_url
    for item in output.get("results", []):
        url = item.get("url") or item.get("video_url")
        if url:
            return url
    return None


def _extract_vod_image_url(task_detail: dict) -> Optional[str]:
    result = task_detail.get("result", {})
    # Flat response (legacy / gateway-normalized)
    if result.get("image_url"):
        return result["image_url"]
    for fi in result.get("file_infos", []):
        url = fi.get("file_url") or fi.get("FileUrl") or fi.get("url")
        if url:
            return url
    # DescribeTaskDetail nested structure: result.AigcImageTask.Output.FileInfos
    for task_key in ("AigcImageTask", "SceneAigcImageTask"):
        task_obj = result.get(task_key) or {}
        output = task_obj.get("Output") or {}
        for fi in output.get("FileInfos") or []:
            url = fi.get("FileUrl") or fi.get("file_url") or fi.get("url")
            if url:
                return url
    return None


def _extract_vod_video_url(task_detail: dict) -> Optional[str]:
    result = task_detail.get("result", {})
    # Flat response (legacy / gateway-normalized)
    if result.get("video_url"):
        return result["video_url"]
    for fi in result.get("file_infos", []):
        url = fi.get("file_url") or fi.get("FileUrl") or fi.get("url")
        if url:
            return url
    # DescribeTaskDetail nested structure: result.AigcVideoTask.Output.FileInfos
    for task_key in ("AigcVideoTask", "SceneAigcVideoTask"):
        task_obj = result.get(task_key) or {}
        output = task_obj.get("Output") or {}
        for fi in output.get("FileInfos") or []:
            url = fi.get("FileUrl") or fi.get("file_url") or fi.get("url")
            if url:
                return url
    return None


def run_generate_video(
    prompt: str,
    output: str | Path,
    model: str = DEFAULT_VIDEO_MODEL,
    from_image: Optional[str | Path] = None,
    duration: int = 5,
    aspect_ratio: str = "16:9",
    *,
    generate_audio: bool = False,
    ref_images: Optional[list[str | Path]] = None,
    ref_videos: Optional[list[str | Path]] = None,
    ref_audios: Optional[list[str | Path]] = None,
    image_role: str = "first_frame",
    watermark: bool = False,
    return_last_frame: bool = False,
    web_search: bool = False,
    size: Optional[str] = None,
    resolution: Optional[str] = None,
    seed: Optional[int] = None,
    enhance_switch: Optional[str] = None,
    scene_type: Optional[str] = None,
    ext_info: Optional[str] = None,
) -> OperationResult:
    start_timer()
    output = Path(output)
    provider = _get_provider(model)

    if provider == "openai":
        video_id = openai_video_submit(
            prompt=prompt,
            model=model,
            size=size or "1920x1080",
            duration_seconds=duration,
            aspect_ratio=aspect_ratio,
            input_reference=from_image,
        )
        print("", file=sys.stderr)
        openai_video_poll(video_id)
        print("", file=sys.stderr)
        video_bytes = openai_video_download(video_id)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_bytes(video_bytes)
        ms = elapsed_ms()
        meta: dict = {
            "file_size_bytes": output.stat().st_size,
            "prompt": prompt,
            "duration_seconds": duration,
            "aspect_ratio": aspect_ratio,
        }
        return OperationResult(
            status="success",
            operation="generate.video",
            output=str(output),
            metadata=meta,
            provider=provider,
            model=model,
            duration_ms=ms,
        )

    if provider == "alibaba":
        ds_size = (size or "1280*720").replace("x", "*")
        task_id = dashscope_video_submit(
            prompt=prompt,
            model=model,
            size=ds_size,
            duration=duration,
            from_image=from_image,
        )
        print("", file=sys.stderr)
        result_data = dashscope_video_poll(task_id)
        print("", file=sys.stderr)
        video_url = _extract_dashscope_video_url(result_data)
        if not video_url:
            raise RuntimeError(
                f"DashScope 视频生成完成但未找到下载地址，响应: {result_data}"
            )
        download_file(video_url, output)
        ms = elapsed_ms()
        meta = {
            "file_size_bytes": output.stat().st_size,
            "prompt": prompt,
            "duration_seconds": duration,
        }
        return OperationResult(
            status="success",
            operation="generate.video",
            output=str(output),
            metadata=meta,
            provider=provider,
            model=model,
            duration_ms=ms,
        )

    if provider == "tencent_vod":
        model_name, model_version = parse_vod_model(model)
        fi_list = None
        if from_image:
            fi_list = [{"type": "Url", "url": str(from_image)}]

        task_id = vod_video_submit(
            prompt=prompt,
            model_name=model_name,
            model_version=model_version,
            file_infos=fi_list,
            duration=duration,
            aspect_ratio=aspect_ratio,
            resolution=size or "1080P",
            audio_generation="Enabled" if generate_audio else None,
            enhance_switch=enhance_switch,
            scene_type=scene_type,
            ext_info=ext_info,
        )
        print("", file=sys.stderr)
        result_data = vod_task_poll(task_id)
        print("", file=sys.stderr)
        video_url = _extract_vod_video_url(result_data)
        if not video_url:
            raise RuntimeError(f"VOD 视频生成完成但未找到下载地址，响应: {result_data}")
        download_file(video_url, output)
        ms = elapsed_ms()
        meta = {
            "file_size_bytes": output.stat().st_size,
            "prompt": prompt,
            "task_id": task_id,
            "duration_seconds": duration,
            "aspect_ratio": aspect_ratio,
        }
        if generate_audio:
            meta["generate_audio"] = True
        return OperationResult(
            status="success",
            operation="generate.video",
            output=str(output),
            metadata=meta,
            provider=provider,
            model=model,
            duration_ms=ms,
        )

    if model.startswith("gemini/veo") or model.startswith("veo"):
        task_data = generate_video_veo(prompt=prompt, model=model, seconds=duration)
        video_id = task_data.get("id")
        if not video_id:
            raise RuntimeError(f"Veo 未返回 video_id，响应: {task_data}")

        print("", file=sys.stderr)
        result_data = veo_video_poll(video_id)
        print("", file=sys.stderr)

        video_url = None
        for item in result_data.get("data", []):
            video_url = item.get("url") or item.get("video_url")
            if video_url:
                break
        if not video_url:
            video_url = result_data.get("url") or result_data.get("video_url")

        provider = "gemini"
        last_frame_url = None
    else:
        task_id = ark_video_submit(
            prompt=prompt,
            model=model,
            from_image=from_image,
            duration=duration,
            aspect_ratio=aspect_ratio,
            generate_audio=generate_audio,
            ref_images=ref_images,
            ref_videos=ref_videos,
            ref_audios=ref_audios,
            image_role=image_role,
            watermark=watermark,
            return_last_frame=return_last_frame,
            web_search=web_search,
            resolution=resolution,
            seed=seed,
        )

        print("", file=sys.stderr)
        result_data = ark_video_poll(task_id)
        print("", file=sys.stderr)

        video_url = _extract_ark_video_url(result_data)
        last_frame_url = (
            _extract_ark_last_frame_url(result_data) if return_last_frame else None
        )
        provider = "volcengine"

    if not video_url:
        raise RuntimeError(f"视频生成完成但未找到下载地址，响应: {result_data}")

    download_file(video_url, output)
    ms = elapsed_ms()
    file_size = output.stat().st_size

    meta = {
        "file_size_bytes": file_size,
        "prompt": prompt,
        "duration_seconds": duration,
        "aspect_ratio": aspect_ratio,
    }
    if generate_audio:
        meta["generate_audio"] = True

    if last_frame_url:
        last_frame_path = output.with_name(output.stem + "_lastframe.png")
        download_file(last_frame_url, last_frame_path)
        meta["last_frame"] = str(last_frame_path)

    return OperationResult(
        status="success",
        operation="generate.video",
        output=str(output),
        metadata=meta,
        provider=provider,
        model=model,
        duration_ms=ms,
    )


def run_generate_lipsync(
    video_path: str | Path,
    audio_path: str | Path,
    output: str | Path,
    model: str = "vod/kling-2.6",
) -> OperationResult:
    start_timer()
    output = Path(output)
    model_name, model_version = parse_vod_model(model)

    from ..providers._base import _encode_media

    video_data, video_mime = _encode_media(video_path)
    face_result = vod_face_info([{"type": "Url", "url": str(video_path)}])
    session_id = face_result.get("session_id", "")

    import json

    audio_data, audio_mime = _encode_media(audio_path)
    ext_info = json.dumps({"session_id": session_id})
    fi = [
        {"type": "Url", "url": str(video_path), "category": "Video"},
        {"type": "Url", "url": str(audio_path), "category": "Audio"},
    ]
    task_id = vod_video_submit(
        prompt="",
        model_name=model_name,
        model_version=model_version,
        file_infos=fi,
        scene_type="lip_sync",
        ext_info=ext_info,
    )
    print("", file=sys.stderr)
    result_data = vod_task_poll(task_id)
    print("", file=sys.stderr)
    video_url = _extract_vod_video_url(result_data)
    if not video_url:
        raise RuntimeError(f"对口型生成完成但未找到下载地址，响应: {result_data}")
    download_file(video_url, output)
    ms = elapsed_ms()
    return OperationResult(
        status="success",
        operation="generate.lipsync",
        output=str(output),
        metadata={
            "task_id": task_id,
            "session_id": session_id,
            "file_size_bytes": output.stat().st_size,
        },
        provider="tencent_vod",
        model=model,
        duration_ms=ms,
    )


def run_generate_avatar(
    image_path: str | Path,
    audio_path: str | Path,
    output: str | Path,
    model: str = "vod/kling-2.6",
) -> OperationResult:
    start_timer()
    output = Path(output)
    model_name, model_version = parse_vod_model(model)

    import json

    fi = [{"type": "Url", "url": str(image_path), "category": "Image"}]
    ext_info = json.dumps({"sound_file": str(audio_path)})
    task_id = vod_video_submit(
        prompt="",
        model_name=model_name,
        model_version=model_version,
        file_infos=fi,
        scene_type="avatar_i2v",
        ext_info=ext_info,
    )
    print("", file=sys.stderr)
    result_data = vod_task_poll(task_id)
    print("", file=sys.stderr)
    video_url = _extract_vod_video_url(result_data)
    if not video_url:
        raise RuntimeError(f"数字人生成完成但未找到下载地址，响应: {result_data}")
    download_file(video_url, output)
    ms = elapsed_ms()
    return OperationResult(
        status="success",
        operation="generate.avatar",
        output=str(output),
        metadata={"task_id": task_id, "file_size_bytes": output.stat().st_size},
        provider="tencent_vod",
        model=model,
        duration_ms=ms,
    )


def run_generate_scene_image(
    prompt: str,
    output: str | Path,
    model: str = "vod/gem-3.0",
) -> OperationResult:
    start_timer()
    output = Path(output)
    model_name, model_version = parse_vod_model(model)

    from ..providers.tencent_vod import vod_scene_image_submit

    task_id = vod_scene_image_submit(
        prompt=prompt, model_name=model_name, model_version=model_version
    )
    print("", file=sys.stderr)
    result_data = vod_task_poll(task_id)
    print("", file=sys.stderr)
    image_url = _extract_vod_image_url(result_data)
    if not image_url:
        raise RuntimeError(f"场景化生图完成但未找到下载地址，响应: {result_data}")
    download_file(image_url, output)
    ms = elapsed_ms()
    from ..local.image import get_info

    meta = get_info(output)
    meta["prompt"] = prompt
    meta["task_id"] = task_id
    return OperationResult(
        status="success",
        operation="generate.scene-image",
        output=str(output),
        metadata=meta,
        provider="tencent_vod",
        model=model,
        duration_ms=ms,
    )
