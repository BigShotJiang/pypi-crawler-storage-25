from __future__ import annotations

from pathlib import Path

from .._output import OperationResult, elapsed_ms, start_timer
from ..providers.alibaba import dashscope_chat_with_image
from ..providers.gemini import chat_with_image
from ..providers.openai import openai_chat_with_image

DEFAULT_ANALYZE_MODEL = "gemini/gemini-2.5-flash"


def _get_vision_provider(model: str) -> str:
    if model.startswith(("openai/", "gpt-5", "gpt-4")):
        return "openai"
    if model.startswith(("dashscope/", "qwen")):
        return "alibaba"
    return "gemini"


def run_analyze_image(
    image_path: str | Path,
    prompt: str,
    model: str = DEFAULT_ANALYZE_MODEL,
) -> OperationResult:
    start_timer()
    provider = _get_vision_provider(model)

    if provider == "openai":
        text, usage = openai_chat_with_image(prompt=prompt, image_path=image_path, model=model)
    elif provider == "alibaba":
        text, usage = dashscope_chat_with_image(prompt=prompt, image_path=image_path, model=model)
    else:
        text, usage = chat_with_image(prompt=prompt, image_path=image_path, model=model)

    ms = elapsed_ms()
    return OperationResult(
        status="success",
        operation="analyze.image",
        metadata={
            "response": text,
            "prompt_tokens": usage.get("prompt_tokens", 0),
            "completion_tokens": usage.get("completion_tokens", 0),
            "total_tokens": usage.get("total_tokens", 0),
        },
        provider=provider,
        model=model,
        duration_ms=ms,
    )
