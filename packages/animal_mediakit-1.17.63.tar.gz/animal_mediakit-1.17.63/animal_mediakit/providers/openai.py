from __future__ import annotations

import base64
import sys
import time
from pathlib import Path
from typing import Optional

import httpx

from .._config import (
    GATEWAY_BASE_URL,
    VIDEO_POLL_INTERVAL_SECS,
    VIDEO_POLL_TIMEOUT_SECS,
)
from ._base import _encode_image, _headers, _HTTP_TIMEOUT, _raise_for_status
from .._auth import get_auth_headers


def _strip_prefix(model: str) -> str:
    if model.startswith("openai/"):
        return model[len("openai/") :]
    return model


_GPT_IMAGE_2_MODELS = {"openai/gpt-image-2", "azure/gpt-image-2", "tencent/gpt-image-2", "gpt-image-2"}


def openai_image_generate(
    prompt: str,
    model: str = "openai/gpt-image-1.5",
    size: str = "1024x1024",
    n: int = 1,
    quality: Optional[str] = None,
    background: Optional[str] = None,
    style: Optional[str] = None,
    output_format: str = "png",
) -> list[bytes]:
    # gpt-image-2 does not support "auto" quality; default to "medium" when unspecified
    if quality is None:
        quality = "medium" if model in _GPT_IMAGE_2_MODELS else "auto"

    payload: dict = {
        "model": model,
        "prompt": prompt,
        "n": n,
        "size": size,
        "quality": quality,
        "response_format": "b64_json",
    }
    if background is not None:
        payload["background"] = background
    if style is not None:
        payload["style"] = style
    if output_format != "png":
        payload["output_format"] = output_format

    resp = httpx.post(
        f"{GATEWAY_BASE_URL}/v1/images/generations",
        headers=_headers(),
        json=payload,
        timeout=_HTTP_TIMEOUT,
    )
    _raise_for_status(resp)
    data = resp.json()
    images: list[bytes] = []
    for item in data.get("data", []):
        b64 = item.get("b64_json", "")
        if b64:
            images.append(base64.b64decode(b64))
        elif item.get("url"):
            img_resp = httpx.get(item["url"], timeout=60)
            img_resp.raise_for_status()
            images.append(img_resp.content)
    return images


def openai_image_edit(
    prompt: str,
    image_path: Optional[str | Path] = None,
    model: str = "openai/gpt-image-1.5",
    mask_path: Optional[str | Path] = None,
    size: str = "1024x1024",
    ref_images: Optional[list[str | Path]] = None,
) -> list[bytes]:
    headers = get_auth_headers()

    files: list = []

    if ref_images:
        for ref_path in ref_images:
            img_bytes = Path(ref_path).read_bytes()
            files.append(("image[]", (Path(ref_path).name, img_bytes, "image/jpeg")))
    elif image_path is not None:
        files.append(("image", (Path(image_path).name, Path(image_path).read_bytes(), "image/png")))

    if mask_path is not None:
        files.append(("mask", (Path(mask_path).name, Path(mask_path).read_bytes(), "image/png")))

    data = {
        "model": model,
        "prompt": prompt,
        "size": size,
    }

    resp = httpx.post(
        f"{GATEWAY_BASE_URL}/v1/images/edits",
        headers=headers,
        files=files,
        data=data,
        timeout=300.0,
    )
    _raise_for_status(resp)
    result = resp.json()
    images: list[bytes] = []
    for item in result.get("data", []):
        b64 = item.get("b64_json", "")
        if b64:
            images.append(base64.b64decode(b64))
        elif item.get("url"):
            img_resp = httpx.get(item["url"], timeout=60)
            img_resp.raise_for_status()
            images.append(img_resp.content)
    return images


def openai_video_submit(
    prompt: str,
    model: str = "openai/sora-2-pro",
    size: str = "1920x1080",
    duration_seconds: int = 10,
    aspect_ratio: str = "16:9",
    input_reference: Optional[str | Path] = None,
) -> str:
    payload: dict = {
        "model": _strip_prefix(model),
        "prompt": prompt,
        "size": size,
        "duration_seconds": duration_seconds,
        "aspect_ratio": aspect_ratio,
    }
    if input_reference is not None:
        b64_data, mime = _encode_image(input_reference)
        payload["input_reference"] = {
            "type": "image_url",
            "image_url": {"url": f"data:{mime};base64,{b64_data}"},
        }

    resp = httpx.post(
        f"{GATEWAY_BASE_URL}/openai/v1/videos",
        headers=_headers(),
        json=payload,
        timeout=_HTTP_TIMEOUT,
    )
    _raise_for_status(resp)
    data = resp.json()
    video_id = data.get("id") or data.get("video_id")
    if not video_id:
        raise RuntimeError(f"OpenAI 未返回 video_id，响应: {data}")
    return video_id


def openai_video_poll(video_id: str) -> dict:
    url = f"{GATEWAY_BASE_URL}/openai/v1/videos/{video_id}"
    deadline = time.time() + VIDEO_POLL_TIMEOUT_SECS
    while time.time() < deadline:
        resp = httpx.get(url, headers=_headers(), timeout=30)
        _raise_for_status(resp)
        data = resp.json()
        status = data.get("status", "")
        if status == "completed":
            return data
        if status in ("failed", "cancelled"):
            raise RuntimeError(f"OpenAI 视频生成失败: {data.get('error', data)}")
        print(".", end="", flush=True, file=sys.stderr)
        time.sleep(VIDEO_POLL_INTERVAL_SECS)
    raise RuntimeError(f"OpenAI 视频生成超时（{VIDEO_POLL_TIMEOUT_SECS}s）")


def openai_video_download(video_id: str) -> bytes:
    resp = httpx.get(
        f"{GATEWAY_BASE_URL}/openai/v1/videos/{video_id}/content",
        headers=_headers(),
        timeout=_HTTP_TIMEOUT,
    )
    _raise_for_status(resp)
    return resp.content


def openai_chat_with_image(
    prompt: str,
    image_path: str | Path,
    model: str = "openai/gpt-5",
) -> tuple[str, dict]:
    b64_data, mime = _encode_image(image_path)
    payload = {
        "model": model,
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:{mime};base64,{b64_data}"},
                    },
                    {"type": "text", "text": prompt},
                ],
            }
        ],
    }
    resp = httpx.post(
        f"{GATEWAY_BASE_URL}/v1/chat/completions",
        headers=_headers(),
        json=payload,
        timeout=_HTTP_TIMEOUT,
    )
    _raise_for_status(resp)
    data = resp.json()
    text = data["choices"][0]["message"]["content"]
    usage = data.get("usage", {})
    return text, usage
