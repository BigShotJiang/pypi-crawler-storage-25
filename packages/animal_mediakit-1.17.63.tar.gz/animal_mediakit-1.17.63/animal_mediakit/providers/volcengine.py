from __future__ import annotations

import base64
import sys
import time
from pathlib import Path
from typing import Optional

import httpx

from .._config import (
    GATEWAY_BASE_URL,
    VIDEO_POLL_INTERVAL_SECS,
    VIDEO_POLL_TIMEOUT_SECS,
)
from ._base import _encode_image, _encode_media, _headers, _HTTP_TIMEOUT, _raise_for_status


def ark_image_generate(
    prompt: str,
    model: str,
    size: str = "1024x1024",
    n: int = 1,
    negative_prompt: Optional[str] = None,
    seed: Optional[int] = None,
    guidance_scale: Optional[float] = None,
) -> list[bytes]:
    payload: dict = {
        "model": model,
        "prompt": prompt,
        "n": n,
        "size": size,
        "response_format": "b64_json",
    }
    if negative_prompt:
        payload["negative_prompt"] = negative_prompt
    if seed is not None:
        payload["seed"] = seed
    if guidance_scale is not None:
        payload["guidance_scale"] = guidance_scale

    resp = httpx.post(
        f"{GATEWAY_BASE_URL}/ark/api/v3/images/generations",
        headers=_headers(),
        json=payload,
        timeout=_HTTP_TIMEOUT,
    )
    _raise_for_status(resp)
    data = resp.json()
    images: list[bytes] = []
    for item in data.get("data", []):
        b64 = item.get("b64_json", "")
        if b64:
            images.append(base64.b64decode(b64))
        elif item.get("url"):
            img_resp = httpx.get(item["url"], timeout=60)
            img_resp.raise_for_status()
            images.append(img_resp.content)
    return images


def ark_video_submit(
    prompt: str,
    model: str = "doubao-seedance-2-0-260128",
    from_image: Optional[str | Path] = None,
    duration: int = 5,
    aspect_ratio: str = "16:9",
    *,
    generate_audio: bool = False,
    ref_images: Optional[list[str | Path]] = None,
    ref_videos: Optional[list[str | Path]] = None,
    ref_audios: Optional[list[str | Path]] = None,
    image_role: str = "first_frame",
    watermark: bool = False,
    return_last_frame: bool = False,
    web_search: bool = False,
    resolution: Optional[str] = None,
    seed: Optional[int] = None,
) -> str:
    # Seedance API 不支持同时传入首帧图（from_image）和参考图（ref_images）。
    # 当两者都指定时，自动将 from_image 合并到 ref_images 首位，并在 prompt
    # 中注入说明，告知模型第一张参考图为首帧，实现透明兼容。
    if from_image and ref_images:
        ref_images = [from_image, *ref_images]
        from_image = None
        prompt = f"[第一张参考图为视频首帧] {prompt}"

    content: list[dict] = [{"type": "text", "text": prompt}]

    if from_image:
        b64_data, mime = _encode_image(from_image)
        item: dict = {
            "type": "image_url",
            "image_url": {"url": f"data:{mime};base64,{b64_data}"},
        }
        if image_role != "first_frame":
            item["role"] = image_role
        content.insert(0, item)

    for ref_img in ref_images or []:
        b64_data, mime = _encode_image(ref_img)
        content.append(
            {
                "type": "image_url",
                "image_url": {"url": f"data:{mime};base64,{b64_data}"},
                "role": "reference_image",
            }
        )

    for ref_vid in ref_videos or []:
        b64_data, mime = _encode_media(ref_vid)
        content.append(
            {
                "type": "video_url",
                "video_url": {"url": f"data:{mime};base64,{b64_data}"},
                "role": "reference_video",
            }
        )

    for ref_aud in ref_audios or []:
        b64_data, mime = _encode_media(ref_aud)
        content.append(
            {
                "type": "audio_url",
                "audio_url": {"url": f"data:{mime};base64,{b64_data}"},
                "role": "reference_audio",
            }
        )

    payload: dict = {
        "model": model,
        "content": content,
        "duration": duration,
        "ratio": aspect_ratio,
    }

    if generate_audio:
        payload["generate_audio"] = True
    if not watermark:
        payload["watermark"] = False
    if return_last_frame:
        payload["return_last_frame"] = True
    if web_search:
        payload["tools"] = [{"type": "web_search"}]
    if resolution:
        payload["resolution"] = resolution
    if seed is not None:
        payload["seed"] = seed

    resp = httpx.post(
        f"{GATEWAY_BASE_URL}/ark/api/v3/contents/generations/tasks",
        headers=_headers(),
        json=payload,
        timeout=60,
    )
    _raise_for_status(resp)
    data = resp.json()
    task_id = data.get("id") or data.get("task_id")
    if not task_id:
        raise RuntimeError(f"Seedance 未返回 task_id，响应: {data}")
    return task_id


def ark_video_poll(task_id: str) -> dict:
    url = f"{GATEWAY_BASE_URL}/ark/api/v3/contents/generations/tasks/{task_id}"
    deadline = time.time() + VIDEO_POLL_TIMEOUT_SECS
    while time.time() < deadline:
        resp = httpx.get(url, headers=_headers(), timeout=30)
        _raise_for_status(resp)
        data = resp.json()
        status = data.get("status", "")
        if status in ("succeeded", "completed"):
            return data
        if status in ("failed", "cancelled"):
            raise RuntimeError(f"视频生成任务失败: {data.get('error', data)}")
        print(".", end="", flush=True, file=sys.stderr)
        time.sleep(VIDEO_POLL_INTERVAL_SECS)
    raise RuntimeError(f"视频生成超时（{VIDEO_POLL_TIMEOUT_SECS}s）")
