from __future__ import annotations

import httpx

from .._auth import get_auth_headers
from .._config import GATEWAY_BASE_URL

from ._base import download_file, _raise_for_status  # noqa: F401
from .gemini import (  # noqa: F401
    chat_with_image,
    generate_image,
    generate_video_veo,
    veo_video_poll,
)
from .volcengine import (  # noqa: F401
    ark_image_generate,
    ark_video_poll,
    ark_video_submit,
)
from .tencent_vod import (  # noqa: F401
    parse_vod_model,
    vod_image_submit,
    vod_video_submit,
    vod_task_poll,
    vod_face_info,
    vod_create_element,
    vod_scene_image_submit,
    vod_enhance_submit,
)


def list_models() -> list[dict]:
    resp = httpx.get(
        f"{GATEWAY_BASE_URL}/v1/models",
        headers=get_auth_headers(),
        timeout=30,
    )
    _raise_for_status(resp)
    return resp.json().get("data", [])
