from __future__ import annotations

import base64
import json
import logging
import os
import time as _time
from pathlib import Path

import httpx

from .._auth import get_auth_headers
from .._config import GATEWAY_BASE_URL

_HTTP_TIMEOUT = 120


def _headers() -> dict[str, str]:
    h = get_auth_headers()
    h["Content-Type"] = "application/json"
    return h


def _encode_image(image_path: str | Path) -> tuple[str, str]:
    path = Path(image_path)
    suffix = path.suffix.lower().lstrip(".")
    mime_map = {
        "jpg": "image/jpeg",
        "jpeg": "image/jpeg",
        "png": "image/png",
        "gif": "image/gif",
        "webp": "image/webp",
    }
    mime = mime_map.get(suffix, "image/jpeg")
    data = base64.standard_b64encode(path.read_bytes()).decode()
    return data, mime


def _encode_media(media_path: str | Path) -> tuple[str, str]:
    path = Path(media_path)
    suffix = path.suffix.lower().lstrip(".")
    mime_map = {
        "jpg": "image/jpeg",
        "jpeg": "image/jpeg",
        "png": "image/png",
        "gif": "image/gif",
        "webp": "image/webp",
        "mp4": "video/mp4",
        "mov": "video/quicktime",
        "avi": "video/x-msvideo",
        "mp3": "audio/mpeg",
        "wav": "audio/wav",
        "aac": "audio/aac",
        "ogg": "audio/ogg",
        "flac": "audio/flac",
    }
    mime = mime_map.get(suffix, "application/octet-stream")
    data = base64.standard_b64encode(path.read_bytes()).decode()
    return data, mime


def _raise_for_status(resp: httpx.Response) -> None:
    """Like resp.raise_for_status() but includes the response body in the error message."""
    if resp.is_success:
        return
    # Try to extract structured error detail from JSON response
    detail = ""
    try:
        body = resp.json()
        # Common error shapes from various providers
        if isinstance(body, dict):
            err = body.get("error", {})
            if isinstance(err, dict):
                detail = err.get("message") or err.get("code") or ""
            if not detail:
                detail = body.get("message") or body.get("detail") or body.get("error_msg") or ""
            if not detail:
                detail = json.dumps(body, ensure_ascii=False)[:500]
    except Exception:
        detail = resp.text[:500] if resp.text else ""
    raise httpx.HTTPStatusError(
        f"{resp.status_code} {resp.reason_phrase} for url '{resp.url}'\nResponse body: {detail}",
        request=resp.request,
        response=resp,
    )


def download_file(url: str, dst: str | Path) -> None:
    dst = Path(dst)
    dst.parent.mkdir(parents=True, exist_ok=True)
    with httpx.stream("GET", url, timeout=120) as resp:
        resp.raise_for_status()
        with open(dst, "wb") as f:
            for chunk in resp.iter_bytes(chunk_size=65536):
                f.write(chunk)


_logger = logging.getLogger("animal_mediakit")

_MAX_RETRIES = int(os.environ.get("MEDIAKIT_HTTP_MAX_RETRIES", "3"))
_RETRY_BASE_DELAY = float(os.environ.get("MEDIAKIT_HTTP_RETRY_DELAY", "2.0"))


class GatewayError(RuntimeError):
    """User-friendly error from gateway."""

    def __init__(self, message: str, status_code: int = 0):
        self.status_code = status_code
        super().__init__(message)


def gateway_request(
    method: str,
    path: str,
    *,
    json: dict | None = None,
    timeout: int = _HTTP_TIMEOUT,
) -> httpx.Response:
    """Send request to gateway with retry and friendly error messages."""
    url = f"{GATEWAY_BASE_URL}{path}"
    last_exc = None
    for attempt in range(_MAX_RETRIES + 1):
        try:
            resp = httpx.request(
                method,
                url,
                headers=_headers(),
                json=json,
                timeout=timeout,
            )
            if resp.status_code == 429:
                if attempt < _MAX_RETRIES:
                    delay = _RETRY_BASE_DELAY * (2**attempt)
                    _logger.warning(
                        f"限流 (429)，{delay}s 后重试 ({attempt + 1}/{_MAX_RETRIES})"
                    )
                    _time.sleep(delay)
                    continue
                raise GatewayError("服务限流，请稍后重试", 429)
            if resp.status_code >= 500:
                if attempt < _MAX_RETRIES:
                    delay = _RETRY_BASE_DELAY * (2**attempt)
                    _logger.warning(
                        f"服务错误 ({resp.status_code})，{delay}s 后重试 ({attempt + 1}/{_MAX_RETRIES})"
                    )
                    _time.sleep(delay)
                    continue
            resp.raise_for_status()
            return resp
        except httpx.HTTPStatusError as e:
            detail = ""
            try:
                body = e.response.json()
                detail = body.get("detail", "")
            except Exception:
                pass
            code = e.response.status_code
            if code == 401:
                raise GatewayError(
                    "认证失败，请运行: uv run scripts/cli.py auth login", code
                )
            if code == 403:
                raise GatewayError(
                    "当前团队无此模型权限。\n"
                    "  查看可用团队: uv run scripts/cli.py auth status\n"
                    "  切换团队:     uv run scripts/cli.py auth login --refresh --team-id <team_id>",
                    code,
                )
            if code == 502 and detail:
                raise GatewayError(f"供应商错误: {detail}", code)
            if code == 503:
                raise GatewayError("服务未配置，请联系管理员", code)
            raise GatewayError(
                f"请求失败 ({code}): {detail or e.response.text[:200]}", code
            )
        except httpx.ConnectError:
            if attempt < _MAX_RETRIES:
                delay = _RETRY_BASE_DELAY * (2**attempt)
                _logger.warning(
                    f"网络连接失败，{delay}s 后重试 ({attempt + 1}/{_MAX_RETRIES})"
                )
                _time.sleep(delay)
                last_exc = GatewayError("网络连接失败，请检查网络")
                continue
            raise GatewayError("网络连接失败，请检查网络")
        except httpx.TimeoutException:
            raise GatewayError("请求超时，请稍后重试")
    raise last_exc or GatewayError("请求失败")
