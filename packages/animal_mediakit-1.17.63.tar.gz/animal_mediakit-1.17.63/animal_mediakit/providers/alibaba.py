from __future__ import annotations

import sys
import time
from pathlib import Path
from typing import Optional

import httpx

from .._config import (
    GATEWAY_BASE_URL,
    VIDEO_POLL_INTERVAL_SECS,
    VIDEO_POLL_TIMEOUT_SECS,
)
from ._base import _encode_image, _headers, _HTTP_TIMEOUT, _raise_for_status


def _strip_prefix(model: str) -> str:
    if model.startswith("dashscope/"):
        return model[len("dashscope/"):]
    return model


def dashscope_image_generate(
    prompt: str,
    model: str = "dashscope/wan2.6-image",
    size: str = "1024*1024",
    n: int = 1,
    prompt_extend: bool = True,
    seed: Optional[int] = None,
) -> list[bytes]:
    parameters: dict = {
        "size": size,
        "n": n,
        "prompt_extend": prompt_extend,
        "enable_interleave": True,
    }
    if seed is not None:
        parameters["seed"] = seed

    payload = {
        "model": _strip_prefix(model),
        "input": {
            "messages": [
                {"role": "user", "content": [{"text": prompt}]}
            ]
        },
        "parameters": parameters,
    }
    resp = httpx.post(
        f"{GATEWAY_BASE_URL}/dashscope/api/v1/services/aigc/multimodal-generation/generation",
        headers=_headers(),
        json=payload,
        timeout=_HTTP_TIMEOUT,
    )
    _raise_for_status(resp)
    data = resp.json()
    images: list[bytes] = []
    for item in data.get("output", {}).get("results", []):
        url = item.get("url")
        if url:
            img_resp = httpx.get(url, timeout=60)
            img_resp.raise_for_status()
            images.append(img_resp.content)
    return images


def dashscope_video_submit(
    prompt: str,
    model: str = "dashscope/wan2.6-t2v",
    size: str = "1280*720",
    duration: int = 5,
    from_image: Optional[str | Path] = None,
) -> str:
    input_data: dict = {"prompt": prompt}
    if from_image:
        b64_data, mime = _encode_image(from_image)
        input_data["img_url"] = f"data:{mime};base64,{b64_data}"

    payload = {
        "model": _strip_prefix(model),
        "input": input_data,
        "parameters": {
            "size": size,
            "duration": duration,
        },
    }

    headers = _headers()
    headers["X-DashScope-Async"] = "enable"

    resp = httpx.post(
        f"{GATEWAY_BASE_URL}/dashscope/api/v1/services/aigc/video-generation/video-synthesis",
        headers=headers,
        json=payload,
        timeout=_HTTP_TIMEOUT,
    )
    _raise_for_status(resp)
    data = resp.json()
    task_id = data.get("output", {}).get("task_id")
    if not task_id:
        raise RuntimeError(f"DashScope 未返回 task_id，响应: {data}")
    return task_id


def dashscope_video_poll(task_id: str) -> dict:
    url = f"{GATEWAY_BASE_URL}/dashscope/api/v1/tasks/{task_id}"
    deadline = time.time() + VIDEO_POLL_TIMEOUT_SECS
    while time.time() < deadline:
        resp = httpx.get(url, headers=_headers(), timeout=30)
        _raise_for_status(resp)
        data = resp.json()
        status = data.get("output", {}).get("task_status", "")
        if status == "SUCCEEDED":
            return data
        if status == "FAILED":
            raise RuntimeError(f"DashScope 视频生成失败: {data.get('output', data)}")
        print(".", end="", flush=True, file=sys.stderr)
        time.sleep(VIDEO_POLL_INTERVAL_SECS)
    raise RuntimeError(f"DashScope 视频生成超时（{VIDEO_POLL_TIMEOUT_SECS}s）")


def dashscope_chat_with_image(
    prompt: str,
    image_path: str | Path,
    model: str = "dashscope/qwen3-vl-plus",
) -> tuple[str, dict]:
    b64_data, mime = _encode_image(image_path)
    payload = {
        "model": _strip_prefix(model),
        "messages": [
            {
                "role": "user",
                "content": [
                    {"type": "image_url",
                     "image_url": {"url": f"data:{mime};base64,{b64_data}"}},
                    {"type": "text", "text": prompt},
                ],
            }
        ],
    }
    resp = httpx.post(
        f"{GATEWAY_BASE_URL}/dashscope/compatible-mode/v1/chat/completions",
        headers=_headers(),
        json=payload,
        timeout=_HTTP_TIMEOUT,
    )
    _raise_for_status(resp)
    data = resp.json()
    text = data["choices"][0]["message"]["content"]
    usage = data.get("usage", {})
    return text, usage
