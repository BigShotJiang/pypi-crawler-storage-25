"""Tencent Cloud VOD AIGC provider — proxied through animal-gateway."""
from __future__ import annotations

import sys
import time
from typing import Optional

import httpx

from .._config import (
    GATEWAY_BASE_URL,
    VOD_POLL_INTERVAL_SECS,
    VOD_POLL_TIMEOUT_SECS,
)
from ._base import _headers, _raise_for_status

# ── Model name parsing ──

# Maps CLI prefix to Tencent VOD ModelName
_MODEL_NAME_MAP: dict[str, str] = {
    "kling": "Kling",
    "vidu": "Vidu",
    "gem": "GEM",
    "hailuo": "Hailuo",
    "seedance": "Seedance",
    "gv": "GV",
    "og": "OG",
    "os": "OS",
    "si": "SI",
    "jimeng": "Jimeng",
    "hunyuan": "Hunyuan",
    "qwen": "Qwen",
}

_VERSION_CASE_MAP: dict[str, str] = {
    "omni": "Omni",
    "pro": "Pro",
    "lite": "Lite",
    "fast": "fast",
    "turbo": "turbo",
    "max": "max",
    "mix": "mix",
}


def _normalize_version(version: str) -> str:
    """Normalize known version suffixes to correct case.
    E.g., '3.0-omni' → '3.0-Omni', '1.5-pro' → '1.5-Pro'
    """
    parts = version.split("-")
    normalized = []
    for part in parts:
        lower = part.lower()
        normalized.append(_VERSION_CASE_MAP.get(lower, part))
    return "-".join(normalized)


def parse_vod_model(model: str) -> tuple[str, str]:
    """Parse 'vod/kling-3.0-omni' → ('Kling', '3.0-Omni').

    Convention: vod/<name>-<version> where <name> is the longest matching
    prefix from _MODEL_NAME_MAP, and <version> is the remainder.
    """
    raw = model.removeprefix("vod/")
    # Try longest prefix first
    for prefix in sorted(_MODEL_NAME_MAP.keys(), key=len, reverse=True):
        if raw.startswith(prefix + "-"):
            version = raw[len(prefix) + 1:]  # skip the "-"
            return _MODEL_NAME_MAP[prefix], _normalize_version(version)
        if raw == prefix:
            raise ValueError(f"Model '{model}' missing version (e.g., vod/{prefix}-3.0)")
    raise ValueError(f"Unknown VOD model prefix in '{model}'. Known: {', '.join(sorted(_MODEL_NAME_MAP.keys()))}")


# ── Image generation ──

def vod_image_submit(
    prompt: str,
    model_name: str,
    model_version: str,
    *,
    file_infos: Optional[list[dict]] = None,
    resolution: Optional[str] = None,
    aspect_ratio: Optional[str] = None,
    storage_mode: str = "Temporary",
    negative_prompt: Optional[str] = None,
) -> str:
    """Submit image generation task. Returns task_id."""
    payload: dict = {
        "model_name": model_name,
        "model_version": model_version,
    }
    if prompt:
        payload["prompt"] = prompt
    if file_infos:
        payload["file_infos"] = file_infos
    if negative_prompt:
        payload["negative_prompt"] = negative_prompt

    output_config: dict = {"storage_mode": storage_mode}
    if resolution:
        output_config["resolution"] = resolution
    if aspect_ratio:
        output_config["aspect_ratio"] = aspect_ratio
    payload["output_config"] = output_config

    resp = httpx.post(
        f"{GATEWAY_BASE_URL}/vod/v1/image",
        headers=_headers(),
        json=payload,
        timeout=60,
    )
    _raise_for_status(resp)
    data = resp.json()
    task_id = data.get("task_id")
    if not task_id:
        raise RuntimeError(f"VOD 未返回 task_id，响应: {data}")
    return task_id


# ── Video generation ──

def vod_video_submit(
    prompt: str,
    model_name: str,
    model_version: str,
    *,
    file_infos: Optional[list[dict]] = None,
    last_frame_url: Optional[str] = None,
    resolution: Optional[str] = None,
    duration: Optional[int] = None,
    aspect_ratio: Optional[str] = None,
    storage_mode: str = "Temporary",
    audio_generation: Optional[str] = None,
    enhance_switch: Optional[str] = None,
    enhance_prompt: Optional[str] = None,
    scene_type: Optional[str] = None,
    ext_info: Optional[str] = None,
) -> str:
    """Submit video generation task. Returns task_id."""
    payload: dict = {
        "model_name": model_name,
        "model_version": model_version,
    }
    if prompt:
        payload["prompt"] = prompt
    if file_infos:
        payload["file_infos"] = file_infos
    if last_frame_url:
        payload["last_frame_url"] = last_frame_url
    if enhance_prompt:
        payload["enhance_prompt"] = enhance_prompt
    if scene_type:
        payload["scene_type"] = scene_type
    if ext_info:
        payload["ext_info"] = ext_info

    output_config: dict = {"storage_mode": storage_mode}
    if resolution:
        output_config["resolution"] = resolution
    if duration is not None:
        output_config["duration"] = duration
    if aspect_ratio:
        output_config["aspect_ratio"] = aspect_ratio
    if audio_generation:
        output_config["audio_generation"] = audio_generation
    if enhance_switch:
        output_config["enhance_switch"] = enhance_switch
    payload["output_config"] = output_config

    resp = httpx.post(
        f"{GATEWAY_BASE_URL}/vod/v1/video",
        headers=_headers(),
        json=payload,
        timeout=60,
    )
    _raise_for_status(resp)
    data = resp.json()
    task_id = data.get("task_id")
    if not task_id:
        raise RuntimeError(f"VOD 未返回 task_id，响应: {data}")
    return task_id


# ── Task polling ──

def vod_task_poll(task_id: str) -> dict:
    """Poll task until completion. Returns full task detail."""
    url = f"{GATEWAY_BASE_URL}/vod/v1/task/{task_id}"
    deadline = time.time() + VOD_POLL_TIMEOUT_SECS
    while time.time() < deadline:
        resp = httpx.get(url, headers=_headers(), timeout=30)
        _raise_for_status(resp)
        data = resp.json()
        status = data.get("status", "")
        if status == "FINISH":
            return data
        if status == "FAIL":
            err_msg = data.get('message') or data.get('error_code') or str(data)
            raise RuntimeError(f"VOD 任务失败 (task_id={task_id}): {err_msg}")
        print(".", end="", flush=True, file=sys.stderr)
        time.sleep(VOD_POLL_INTERVAL_SECS)
    raise RuntimeError(
        f"VOD 任务超时（{VOD_POLL_TIMEOUT_SECS}s），task_id={task_id}，"
        f"可稍后手动查询: animal-mediakit task status {task_id}"
    )


# ── Face info (lip sync prerequisite) ──

def vod_face_info(file_infos: list[dict]) -> dict:
    """Get face info from video for lip-sync. Returns {session_id, face_info_list}."""
    resp = httpx.post(
        f"{GATEWAY_BASE_URL}/vod/v1/face-info",
        headers=_headers(),
        json={"file_infos": file_infos},
        timeout=60,
    )
    _raise_for_status(resp)
    return resp.json()


# ── Custom element ──

def vod_create_element(
    name: str,
    description: str,
    frontal_image_url: str,
) -> str:
    """Create custom subject element. Returns element_id."""
    resp = httpx.post(
        f"{GATEWAY_BASE_URL}/vod/v1/element",
        headers=_headers(),
        json={
            "element_name": name,
            "element_description": description,
            "element_frontal_image": frontal_image_url,
        },
        timeout=60,
    )
    _raise_for_status(resp)
    data = resp.json()
    return data["element_id"]


# ── Scene image ──

def vod_scene_image_submit(
    prompt: str,
    model_name: str,
    model_version: str,
    **kwargs,
) -> str:
    """Submit scene-based image generation (e-commerce). Returns task_id."""
    payload: dict = {
        "model_name": model_name,
        "model_version": model_version,
        "prompt": prompt,
    }
    payload.update(kwargs)
    resp = httpx.post(
        f"{GATEWAY_BASE_URL}/vod/v1/scene-image",
        headers=_headers(),
        json=payload,
        timeout=60,
    )
    _raise_for_status(resp)
    return resp.json()["task_id"]


# ── Video enhancement ──

def vod_enhance_submit(file_id: str, template_id: int = 101540) -> str:
    """Submit video super-resolution enhancement. Returns task_id."""
    resp = httpx.post(
        f"{GATEWAY_BASE_URL}/vod/v1/enhance",
        headers=_headers(),
        json={"file_id": file_id, "template_id": template_id},
        timeout=60,
    )
    _raise_for_status(resp)
    return resp.json()["task_id"]
