from __future__ import annotations

import base64
import io
import sys
import time
from pathlib import Path
from typing import Any, Optional

import httpx

from .._auth import get_auth_headers, get_gateway_token
from .._config import (
    GATEWAY_BASE_URL,
    VIDEO_POLL_INTERVAL_SECS,
    VIDEO_POLL_TIMEOUT_SECS,
)
from ._base import _HTTP_TIMEOUT, _raise_for_status

_REF_MAX_EDGE = 1024
_REF_JPEG_QUALITY = 75


def _compress_ref_image(image_path: str | Path) -> tuple[str, str]:
    from PIL import Image

    path = Path(image_path)
    img = Image.open(path).convert("RGB")
    w, h = img.size
    if max(w, h) > _REF_MAX_EDGE:
        scale = _REF_MAX_EDGE / max(w, h)
        img = img.resize((int(w * scale), int(h * scale)), Image.Resampling.LANCZOS)
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=_REF_JPEG_QUALITY)
    return base64.b64encode(buf.getvalue()).decode(), "image/jpeg"


def _parse_aspect_ratio(size: str) -> str:
    size_to_ratio = {
        "1024x1024": "1:1",
        "1792x1024": "16:9",
        "1024x1792": "9:16",
        "1216x832": "3:2",
        "832x1216": "2:3",
    }
    if size in size_to_ratio:
        return size_to_ratio[size]
    parts = size.lower().split("x")
    if len(parts) == 2:
        try:
            w, h = int(parts[0]), int(parts[1])
            from math import gcd
            g = gcd(w, h)
            return f"{w // g}:{h // g}"
        except ValueError:
            pass
    return "1:1"


def _gemini_headers(token: str) -> dict[str, str]:
    return {
        "Content-Type": "application/json",
        "x-goog-api-key": token,
    }


def _gemini_generate_content_url(model: str) -> str:
    bare = model.removeprefix("gemini/")
    return f"{GATEWAY_BASE_URL}/gemini/v1beta/models/{bare}:generateContent"


def generate_image(
    prompt: str,
    model: str = "gemini/gemini-2.5-flash-image",
    size: str = "1024x1024",
    ref_images: Optional[list[str | Path]] = None,
    aspect_ratio: Optional[str] = None,
    image_size: Optional[str] = None,
) -> list[bytes]:
    """Generate image(s) via LiteLLM /v1/images/generations pipeline.

    Routes through LiteLLM proxy for cost tracking, budget enforcement,
    callbacks and rate limiting. LiteLLM internally uses Gemini's native
    generateContent API via GoogleImageGenConfig.
    """
    resolved_aspect_ratio = aspect_ratio if aspect_ratio is not None else _parse_aspect_ratio(size)

    payload: dict[str, Any] = {
        "model": model,
        "prompt": prompt,
        "aspect_ratio": resolved_aspect_ratio,
    }
    if image_size is not None:
        payload["image_size"] = image_size

    if ref_images:
        encoded_refs = []
        for ref_path in ref_images:
            b64, mime = _compress_ref_image(ref_path)
            encoded_refs.append({"mime_type": mime, "data": b64})
        payload["ref_images"] = encoded_refs

    headers = get_auth_headers()
    headers["Content-Type"] = "application/json"

    resp = httpx.post(
        f"{GATEWAY_BASE_URL}/v1/images/generations",
        headers=headers,
        json=payload,
        timeout=_HTTP_TIMEOUT,
    )
    _raise_for_status(resp)
    data = resp.json()

    images: list[bytes] = []
    for item in data.get("data", []):
        b64 = item.get("b64_json", "")
        if b64:
            images.append(base64.b64decode(b64))
    return images


def generate_video_veo(
    prompt: str,
    model: str = "gemini/veo-2.0-generate-001",
    seconds: int = 5,
) -> dict[str, Any]:
    from ._base import _headers
    payload = {"model": model, "prompt": prompt, "seconds": str(seconds)}
    resp = httpx.post(
        f"{GATEWAY_BASE_URL}/v1/videos",
        headers=_headers(),
        json=payload,
        timeout=_HTTP_TIMEOUT,
    )
    _raise_for_status(resp)
    return resp.json()


def veo_video_poll(video_id: str) -> dict[str, Any]:
    from ._base import _headers
    url = f"{GATEWAY_BASE_URL}/v1/videos/{video_id}"
    deadline = time.time() + VIDEO_POLL_TIMEOUT_SECS
    while time.time() < deadline:
        resp = httpx.get(url, headers=_headers(), timeout=30)
        _raise_for_status(resp)
        data = resp.json()
        status = data.get("status", "")
        if status == "completed":
            return data
        if status in ("failed", "cancelled"):
            raise RuntimeError(f"Veo 视频生成失败: {data.get('error', data)}")
        print(".", end="", flush=True, file=sys.stderr)
        time.sleep(VIDEO_POLL_INTERVAL_SECS)
    raise RuntimeError(f"Veo 视频生成超时（{VIDEO_POLL_TIMEOUT_SECS}s）")


def chat_with_image(
    prompt: str,
    image_path: str | Path,
    model: str = "gemini/gemini-2.5-flash",
) -> tuple[str, dict[str, Any]]:
    token = get_gateway_token()

    path = Path(image_path)
    suffix = path.suffix.lower().lstrip(".")
    mime_map = {
        "jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png",
        "gif": "image/gif", "webp": "image/webp",
    }
    mime = mime_map.get(suffix, "image/jpeg")
    image_b64 = base64.b64encode(path.read_bytes()).decode()

    payload: dict[str, Any] = {
        "contents": [
            {
                "role": "user",
                "parts": [
                    {"inline_data": {"mime_type": mime, "data": image_b64}},
                    {"text": prompt},
                ],
            }
        ],
    }

    url = _gemini_generate_content_url(model)
    resp = httpx.post(url, headers=_gemini_headers(token), json=payload, timeout=_HTTP_TIMEOUT)
    _raise_for_status(resp)
    data = resp.json()

    text = ""
    for candidate in data.get("candidates", []):
        for part in candidate.get("content", {}).get("parts", []):
            if "text" in part:
                text += part["text"]

    usage = data.get("usageMetadata", {})
    return text, usage
