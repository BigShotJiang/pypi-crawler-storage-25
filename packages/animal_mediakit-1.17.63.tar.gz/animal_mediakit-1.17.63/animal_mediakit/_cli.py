from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Optional

import click
from rich.console import Console

from ._auth import get_gateway_token, logout as _logout, status as _auth_status
from ._output import OperationResult, OutputFormatter

console = Console(stderr=True)


def _get_version() -> str:
    try:
        from importlib.metadata import version
        return version("animal-mediakit")
    except Exception:
        pass
    # fallback: read pyproject.toml (dev mode)
    try:
        import tomllib  # Python 3.11+
    except ImportError:
        try:
            import tomli as tomllib  # type: ignore[no-redef]
        except ImportError:
            return "unknown"
    pyproject = Path(__file__).parent.parent / "pyproject.toml"
    if pyproject.exists():
        with open(pyproject, "rb") as f:
            data = tomllib.load(f)
        return data.get("project", {}).get("version", "unknown")
    return "unknown"


@click.group()
@click.option(
    "--json",
    "json_output",
    is_flag=True,
    default=False,
    help="以 JSON 格式输出结果（大模型调用时使用）",
)
@click.version_option(version=_get_version(), prog_name="animal-mediakit")
@click.pass_context
def main(ctx: click.Context, json_output: bool) -> None:
    ctx.ensure_object(dict)
    ctx.obj["json"] = json_output
    ctx.obj["fmt"] = OutputFormatter(json_mode=json_output)


@main.group()
def auth() -> None:
    pass


@auth.command("login")
@click.option("--no-browser", is_flag=True, help="不自动打开浏览器，打印 URL 手动访问")
@click.option("--refresh", is_flag=True, help="忽略本地缓存，强制重新登录")
@click.option(
    "--team-id",
    "team_id",
    default=None,
    help="指定登录后使用的团队 ID（默认自动选第一个）",
)
def auth_login(no_browser: bool, refresh: bool, team_id: str) -> None:
    from ._auth import get_gateway_token

    try:
        token = get_gateway_token(
            refresh=refresh,
            open_browser=not no_browser,
            preferred_team_id=team_id,
        )
        click.echo(f"\n✅ 登录成功！Token: {token[:20]}...")
    except Exception as e:
        click.echo(f"❌ 登录失败: {e}", err=True)
        sys.exit(1)


@auth.command("logout")
def auth_logout() -> None:
    if _logout():
        click.echo("✅ 已登出，本地凭证已清除")
    else:
        click.echo("ℹ️  本地无凭证")


@auth.command("status")
@click.pass_context
def auth_status(ctx: click.Context) -> None:
    s = _auth_status()
    if ctx.obj and ctx.obj.get("json"):
        click.echo(json.dumps(s, ensure_ascii=False))
    else:
        for k, v in s.items():
            click.echo(f"  {k}: {v}")


@auth.command("ping")
@click.pass_context
def auth_ping(ctx: click.Context) -> None:
    from .providers.gateway import list_models

    try:
        models = list_models()
        count = len(models)
        if ctx.obj and ctx.obj.get("json"):
            click.echo(json.dumps({"status": "ok", "model_count": count}))
        else:
            click.echo(f"✅ animal-gateway 连通正常，可用模型 {count} 个")
    except Exception as e:
        if ctx.obj and ctx.obj.get("json"):
            click.echo(json.dumps({"status": "error", "message": str(e)}))
        else:
            click.echo(f"❌ 连接失败: {e}", err=True)
        sys.exit(1)


@main.command("models")
@click.option(
    "--capability",
    "capability",
    type=click.Choice(["image", "video", "analyze", "edit", "all"]),
    default="all",
    help="按能力过滤: image/video/analyze/edit/all（默认: all）",
)
@click.pass_context
def models_cmd(ctx: click.Context, capability: str) -> None:
    """列出 animal-gateway 上可用的 AI 模型，按能力分类。"""
    from .providers.gateway import list_models

    # Allow-lists: exactly which model IDs to surface per capability.
    # Maintained in sync with extensions/animal-mediakit/docs/models-review.md
    _IMAGE_ALLOW: set[str] = {
        "azure/gpt-image-2",
        "gemini/gemini-2.5-flash-image",
        "gemini/gemini-3-pro-image-preview",
        "gemini/gemini-3.1-flash-image-preview",
        "gemini/imagen-3.0-generate-002",
        "gemini/imagen-4.0-fast-generate-001",
        "gemini/imagen-4.0-generate-001",
        "gemini/imagen-4.0-ultra-generate-001",
        "openai/gpt-image-1.5",
        "tencent/gpt-image-2",
        "vod/gem-3.1",
        "vod/hunyuan-3.0",
        "vod/jimeng-4.0",
        "vod/kling-3.0",
        "vod/kling-3.0-omni",
        "vod/si-5.0-lite",
        "vod/vidu-q3",
    }
    _VIDEO_ALLOW: set[str] = {
        "Seedance-2.0",
        "gemini/lyria-3-pro-preview",
        "gemini/veo-2.0-generate-001",
        "gemini/veo-3.1-generate-001",
        "vod/gv-3.1",
        "vod/hailuo-2.3",
        "vod/kling-3.0",
        "vod/kling-3.0-omni",
        "vod/os-3.0",
        "vod/seedance-1.5-pro",
        "vod/vidu-q3",
    }
    _ANALYZE_ALLOW: set[str] = {
        "gemini/gemini-3.1-flash-lite-preview",
        "gemini/gemini-3.1-pro-preview",
        "qwen3-vl-8b-thinking",
        "tencent/gemini-3-flash-preview",
        "tencent/gemini-3.1-pro-preview",
    }
    _EDIT_ALLOW: set[str] = {
        "azure/gpt-image-2",
        "openai/gpt-image-1.5",
    }

    # (capability, model_id) -> (hint, [recommended params])
    # hint: short label shown after ★; params: CLI flags shown in parentheses
    # Maintained in sync with extensions/animal-mediakit/docs/models-review.md
    _RECOMMENDED: dict[tuple[str, str], tuple[str, list[str]]] = {
        ("image",   "gemini/gemini-3.1-flash-image-preview"):  ("最新最快",       []),
        ("image",   "gemini/imagen-4.0-generate-001"):         ("高质量写实",     []),
        ("image",   "tencent/gpt-image-2"):                    ("OpenAI gpt-image-2 经腾讯代理", ["--quality medium"]),
        ("video",   "Seedance-2.0"):                           ("国内访问稳定",   []),
        ("video",   "gemini/veo-3.1-generate-001"):            ("最新一代",       []),
        ("video",   "vod/kling-3.0"):                          ("综合能力强",     []),
        ("analyze", "gemini/gemini-3.1-flash-lite-preview"):   ("轻量快速",       []),
        ("edit",    "azure/gpt-image-2"):                      ("支持 inpainting", ["--mask mask.png"]),
    }

    _VOD_KNOWN: list[dict] = [
        {"id": "vod/gem-3.1"},
        {"id": "vod/gv-3.1"},
        {"id": "vod/hailuo-2.3"},
        {"id": "vod/hunyuan-3.0"},
        {"id": "vod/jimeng-4.0"},
        {"id": "vod/kling-3.0"},
        {"id": "vod/kling-3.0-omni"},
        {"id": "vod/os-3.0"},
        {"id": "vod/seedance-1.5-pro"},
        {"id": "vod/si-5.0-lite"},
        {"id": "vod/vidu-q3"},
    ]

    try:
        all_models = list_models()
    except Exception as e:
        click.echo(f"❌ 获取模型列表失败: {e}", err=True)
        sys.exit(1)

    all_allow = _IMAGE_ALLOW | _VIDEO_ALLOW | _ANALYZE_ALLOW | _EDIT_ALLOW
    gateway_ids = {m["id"] for m in all_models}
    vod_extra = [m for m in _VOD_KNOWN if m["id"] not in gateway_ids]
    candidate_ids = {m["id"] for m in (all_models + vod_extra)} & all_allow

    _CAP_ALLOW = {
        "image": _IMAGE_ALLOW,
        "video": _VIDEO_ALLOW,
        "analyze": _ANALYZE_ALLOW,
        "edit": _EDIT_ALLOW,
    }
    buckets: dict[str, list[str]] = {cap: [] for cap in _CAP_ALLOW}
    for mid in candidate_ids:
        for cap, allow_set in _CAP_ALLOW.items():
            if mid in allow_set:
                buckets[cap].append(mid)
    for k in buckets:
        buckets[k] = sorted(set(buckets[k]))

    if ctx.obj and ctx.obj.get("json"):
        payload = buckets if capability == "all" else {capability: buckets.get(capability, [])}
        click.echo(json.dumps(payload, ensure_ascii=False))
        return

    _LABELS = {
        "image": "🖼️  图像生成",
        "video": "🎬  视频生成",
        "analyze": "🔍  图像理解",
        "edit":  "✏️  图像编辑",
    }
    categories = list(_LABELS) if capability == "all" else [capability]
    total = 0
    for cat in categories:
        items = buckets.get(cat, [])
        if not items:
            continue
        click.echo(f"\n{_LABELS.get(cat, cat)}  ({len(items)})")
        for mid in items:
            rec = _RECOMMENDED.get((cat, mid))
            if rec:
                hint, params = rec
                suffix = f"  ({hint})"
                if params:
                    suffix += f"  推荐参数: {' '.join(params)}"
                click.echo(f"  ★ {mid}{suffix}")
            else:
                click.echo(f"    {mid}")
        total += len(items)
    click.echo(f"\n共 {total} 个精选模型（gateway 总模型数: {len(all_models)}）")


@main.group()
def image() -> None:
    pass


def _image_output(ctx: click.Context, result: OperationResult) -> None:
    fmt: OutputFormatter = ctx.obj["fmt"]
    if result.status == "success":
        fmt.success(result)
    else:
        fmt.error(result)


@image.command("info")
@click.argument("file", type=click.Path(exists=True))
@click.pass_context
def image_info(ctx: click.Context, file: str) -> None:
    from .local.image import get_info
    from ._output import start_timer, elapsed_ms

    start_timer()
    meta = get_info(file)
    ms = elapsed_ms()
    result = OperationResult(
        status="success",
        operation="image.info",
        output=file,
        metadata=meta,
        duration_ms=ms,
    )
    _image_output(ctx, result)


@image.command("crop")
@click.argument("file", type=click.Path(exists=True))
@click.option("--rect", required=True, help="X,Y,W,H (左上角坐标 + 宽高，像素)")
@click.option("-o", "--output", required=True, help="输出路径")
@click.pass_context
def image_crop(ctx: click.Context, file: str, rect: str, output: str) -> None:
    from .local.image import crop
    from ._output import start_timer, elapsed_ms

    start_timer()
    try:
        x, y, w, h = [int(v) for v in rect.split(",")]
    except ValueError:
        click.echo("❌ --rect 格式应为 X,Y,W,H，例如 100,100,500,400", err=True)
        sys.exit(1)
    meta = crop(file, (x, y, w, h), output)
    ms = elapsed_ms()
    result = OperationResult(
        status="success",
        operation="image.crop",
        output=output,
        metadata=meta,
        duration_ms=ms,
    )
    _image_output(ctx, result)


@image.command("resize")
@click.argument("file", type=click.Path(exists=True))
@click.option("-o", "--output", required=True)
@click.option("--width", type=int, default=None)
@click.option("--height", type=int, default=None)
@click.option("--scale", type=float, default=None, help="缩放比例，例如 0.5")
@click.pass_context
def image_resize(ctx, file, output, width, height, scale):
    from .local.image import resize
    from ._output import start_timer, elapsed_ms

    start_timer()
    meta = resize(file, output, width=width, height=height, scale=scale)
    ms = elapsed_ms()
    result = OperationResult(
        status="success",
        operation="image.resize",
        output=output,
        metadata=meta,
        duration_ms=ms,
    )
    _image_output(ctx, result)


@image.command("flip")
@click.argument("file", type=click.Path(exists=True))
@click.option("-o", "--output", required=True)
@click.option(
    "--direction", type=click.Choice(["horizontal", "vertical"]), default="horizontal"
)
@click.pass_context
def image_flip(ctx, file, output, direction):
    from .local.image import flip
    from ._output import start_timer, elapsed_ms

    start_timer()
    meta = flip(file, direction, output)
    ms = elapsed_ms()
    result = OperationResult(
        status="success",
        operation="image.flip",
        output=output,
        metadata=meta,
        duration_ms=ms,
    )
    _image_output(ctx, result)


@image.command("rotate")
@click.argument("file", type=click.Path(exists=True))
@click.option("-o", "--output", required=True)
@click.option("--angle", type=int, default=90, help="旋转角度（逆时针）：90, 180, 270")
@click.pass_context
def image_rotate(ctx, file, output, angle):
    from .local.image import rotate
    from ._output import start_timer, elapsed_ms

    start_timer()
    meta = rotate(file, angle, output)
    ms = elapsed_ms()
    result = OperationResult(
        status="success",
        operation="image.rotate",
        output=output,
        metadata=meta,
        duration_ms=ms,
    )
    _image_output(ctx, result)


@image.command("convert")
@click.argument("file", type=click.Path(exists=True))
@click.option("-o", "--output", required=True)
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["jpg", "jpeg", "png", "webp", "gif", "bmp"]),
    required=True,
)
@click.pass_context
def image_convert(ctx, file, output, fmt):
    from .local.image import convert_format
    from ._output import start_timer, elapsed_ms

    start_timer()
    meta = convert_format(file, fmt, output)
    ms = elapsed_ms()
    result = OperationResult(
        status="success",
        operation="image.convert",
        output=output,
        metadata=meta,
        duration_ms=ms,
    )
    _image_output(ctx, result)


@image.command("compress")
@click.argument("file", type=click.Path(exists=True))
@click.option("-o", "--output", required=True)
@click.option(
    "--quality",
    type=click.IntRange(1, 100),
    default=80,
    help="质量 1-100（仅 JPEG/WEBP 有效）",
)
@click.pass_context
def image_compress(ctx, file, output, quality):
    from .local.image import compress
    from ._output import start_timer, elapsed_ms

    start_timer()
    meta = compress(file, quality, output)
    ms = elapsed_ms()
    result = OperationResult(
        status="success",
        operation="image.compress",
        output=output,
        metadata=meta,
        duration_ms=ms,
    )
    _image_output(ctx, result)


@main.group()
def generate() -> None:
    pass


@generate.command("image")
@click.argument("prompt")
@click.option("-o", "--output", required=True, help="输出图像路径，如 ./out.png")
@click.option(
    "--model",
    default="gemini/gemini-2.5-flash-image",
    help="模型: gemini/*, openai/gpt-image-1.5, azure/gpt-image-2, tencent/gpt-image-2, doubao-seedream-*, dashscope/wan2.6-image, vod/gem-3.1, vod/kling-3.0, vod/si-5.0-lite",
)
@click.option("--size", default="1024x1024", help="图像尺寸，如 1024x1024")
@click.option(
    "--negative-prompt",
    "negative_prompt",
    default=None,
    help="反向提示词（仅火山引擎模型有效）",
)
@click.option(
    "--seed", type=int, default=None, help="随机种子（火山引擎/DashScope 有效）"
)
@click.option(
    "--guidance-scale", type=float, default=None, help="引导系数（仅火山引擎模型有效）"
)
@click.option(
    "--quality",
    default=None,
    help="图像质量: auto/low/medium/high/hd（仅 OpenAI 有效）",
)
@click.option(
    "--background",
    default=None,
    help="背景: transparent（仅 OpenAI gpt-image 有效，需 png/webp 格式）",
)
@click.option("--style", default=None, help="风格: vivid/natural（仅 OpenAI 有效）")
@click.option(
    "--output-format",
    "output_format",
    default=None,
    help="输出格式: png/jpeg/webp（仅 OpenAI 有效）",
)
@click.option(
    "--no-prompt-extend",
    "prompt_extend_off",
    is_flag=True,
    default=False,
    help="禁用自动扩写提示词（仅 DashScope 有效）",
)
@click.option(
    "--aspect-ratio",
    "aspect_ratio",
    default=None,
    help="Gemini 图像宽高比，如 16:9、9:16、1:1（优先于 --size）",
)
@click.option(
    "--image-size",
    "image_size",
    default=None,
    help="Gemini 图像分辨率：512 / 1K / 2K / 4K（仅 Gemini 原生 API 有效）",
)
@click.option(
    "--ref-image",
    "ref_images",
    multiple=True,
    type=click.Path(exists=True),
    help="参考图（可多次指定，Gemini 有效）",
)
@click.pass_context
def generate_image_cmd(
    ctx,
    prompt,
    output,
    model,
    size,
    negative_prompt,
    seed,
    guidance_scale,
    quality,
    background,
    style,
    output_format,
    prompt_extend_off,
    ref_images,
    aspect_ratio,
    image_size,
):
    from .ops.generate import run_generate_image

    fmt: OutputFormatter = ctx.obj["fmt"]
    try:
        kwargs: dict = {
            "prompt": prompt,
            "output": output,
            "model": model,
            "size": size,
        }
        if negative_prompt:
            kwargs["negative_prompt"] = negative_prompt
        if seed is not None:
            kwargs["seed"] = seed
        if guidance_scale is not None:
            kwargs["guidance_scale"] = guidance_scale
        if quality:
            kwargs["quality"] = quality
        if background:
            kwargs["background"] = background
        if style:
            kwargs["style"] = style
        if output_format:
            kwargs["output_format"] = output_format
        if prompt_extend_off:
            kwargs["prompt_extend"] = False
        if ref_images:
            kwargs["ref_images"] = list(ref_images)
        if aspect_ratio:
            kwargs["aspect_ratio"] = aspect_ratio
        if image_size:
            kwargs["image_size"] = image_size
        result = run_generate_image(**kwargs)
        fmt.success(result)
    except Exception as e:
        _handle_ai_error(ctx, "generate.image", e)


@generate.command("video")
@click.argument("prompt")
@click.option("-o", "--output", required=True, help="输出视频路径，如 ./out.mp4")
@click.option(
    "--model",
    default="gemini/veo-2.0-generate-001",
    help="视频模型: gemini/veo-*, doubao-seedance-*, openai/sora-*, dashscope/wan2.6-t2v, vod/kling-3.0, vod/vidu-q3-mix, vod/gv-3.1",
)
@click.option(
    "--from-image",
    "from_image",
    default=None,
    type=click.Path(exists=True),
    help="图生视频：提供首帧/参考图路径",
)
@click.option(
    "--duration", type=int, default=5, help="视频时长（秒）：4-20，-1 为模型自动决定"
)
@click.option(
    "--aspect-ratio",
    default="16:9",
    type=click.Choice(["16:9", "9:16", "1:1", "4:3", "3:4", "21:9", "adaptive"]),
)
@click.option(
    "--audio/--no-audio",
    "generate_audio",
    default=False,
    help="生成同步音频（Seedance 2.0）",
)
@click.option(
    "--ref-image",
    "ref_images",
    multiple=True,
    type=click.Path(exists=True),
    help="参考图（可多次指定，Seedance 2.0）",
)
@click.option(
    "--ref-video",
    "ref_videos",
    multiple=True,
    type=click.Path(exists=True),
    help="参考视频（可多次指定，Seedance 2.0）",
)
@click.option(
    "--ref-audio",
    "ref_audios",
    multiple=True,
    type=click.Path(exists=True),
    help="参考音频（可多次指定，Seedance 2.0）",
)
@click.option(
    "--image-role",
    type=click.Choice(["first_frame", "last_frame", "reference_image"]),
    default="first_frame",
    help="--from-image 的角色（Seedance 2.0）",
)
@click.option("--watermark/--no-watermark", default=False, help="添加水印")
@click.option(
    "--last-frame",
    "return_last_frame",
    is_flag=True,
    default=False,
    help="同时保存最后一帧（Seedance 2.0）",
)
@click.option(
    "--web-search",
    "web_search",
    is_flag=True,
    default=False,
    help="允许模型联网搜索参考素材（Seedance 2.0）",
)
@click.option(
    "--size", default=None, help="视频分辨率，如 1920x1080（OpenAI/DashScope）"
)
@click.option(
    "--resolution",
    type=click.Choice(["480p", "720p", "1080p"]),
    default=None,
    help="视频分辨率（Seedance 2.0）：480p/720p/1080p，默认 720p",
)
@click.option("--seed", "video_seed", type=int, default=None, help="随机种子（Seedance 2.0，用于复现生成结果）")
@click.option(
    "--enhance",
    "vod_enhance",
    is_flag=True,
    default=False,
    help="启用画质增强（仅 VOD 模型有效）",
)
@click.option(
    "--scene-type", "vod_scene_type", default=None, help="场景类型（仅 VOD 模型有效）"
)
@click.option(
    "--ext-info",
    "vod_ext_info",
    default=None,
    help="扩展信息 JSON 字符串（仅 VOD 模型有效）",
)
@click.pass_context
def generate_video_cmd(
    ctx,
    prompt,
    output,
    model,
    from_image,
    duration,
    aspect_ratio,
    generate_audio,
    ref_images,
    ref_videos,
    ref_audios,
    image_role,
    watermark,
    return_last_frame,
    web_search,
    size,
    resolution,
    video_seed,
    vod_enhance,
    vod_scene_type,
    vod_ext_info,
):
    from .ops.generate import run_generate_video

    fmt: OutputFormatter = ctx.obj["fmt"]
    try:
        kwargs: dict = dict(
            prompt=prompt,
            output=output,
            model=model,
            from_image=from_image,
            duration=duration,
            aspect_ratio=aspect_ratio,
            generate_audio=generate_audio,
            ref_images=list(ref_images) if ref_images else None,
            ref_videos=list(ref_videos) if ref_videos else None,
            ref_audios=list(ref_audios) if ref_audios else None,
            image_role=image_role,
            watermark=watermark,
            return_last_frame=return_last_frame,
            web_search=web_search,
            size=size,
            resolution=resolution,
            seed=video_seed,
        )
        if vod_enhance:
            kwargs["enhance_switch"] = "Enabled"
        if vod_scene_type:
            kwargs["scene_type"] = vod_scene_type
        if vod_ext_info:
            kwargs["ext_info"] = vod_ext_info
        result = run_generate_video(**kwargs)
        fmt.success(result)
    except Exception as e:
        _handle_ai_error(ctx, "generate.video", e)


@generate.command("lipsync")
@click.option(
    "--video",
    "video_path",
    required=True,
    type=click.Path(exists=True),
    help="输入视频路径",
)
@click.option(
    "--audio",
    "audio_path",
    required=True,
    type=click.Path(exists=True),
    help="音频路径",
)
@click.option("-o", "--output", required=True, help="输出视频路径")
@click.option("--model", default="vod/kling-2.6", help="模型: vod/kling-*")
@click.pass_context
def generate_lipsync_cmd(ctx, video_path, audio_path, output, model):
    from .ops.generate import run_generate_lipsync

    fmt: OutputFormatter = ctx.obj["fmt"]
    try:
        result = run_generate_lipsync(
            video_path=video_path,
            audio_path=audio_path,
            output=output,
            model=model,
        )
        fmt.success(result)
    except Exception as e:
        _handle_ai_error(ctx, "generate.lipsync", e)


@generate.command("avatar")
@click.option(
    "--image",
    "image_path",
    required=True,
    type=click.Path(exists=True),
    help="人物图片路径",
)
@click.option(
    "--audio",
    "audio_path",
    required=True,
    type=click.Path(exists=True),
    help="音频路径",
)
@click.option("-o", "--output", required=True, help="输出视频路径")
@click.option("--model", default="vod/kling-2.6", help="模型: vod/kling-*")
@click.pass_context
def generate_avatar_cmd(ctx, image_path, audio_path, output, model):
    from .ops.generate import run_generate_avatar

    fmt: OutputFormatter = ctx.obj["fmt"]
    try:
        result = run_generate_avatar(
            image_path=image_path,
            audio_path=audio_path,
            output=output,
            model=model,
        )
        fmt.success(result)
    except Exception as e:
        _handle_ai_error(ctx, "generate.avatar", e)


@generate.command("scene-image")
@click.argument("prompt")
@click.option("-o", "--output", required=True, help="输出图像路径")
@click.option("--model", default="vod/gem-3.0", help="场景化生图模型: vod/*")
@click.pass_context
def generate_scene_image_cmd(ctx, prompt, output, model):
    from .ops.generate import run_generate_scene_image

    fmt: OutputFormatter = ctx.obj["fmt"]
    try:
        result = run_generate_scene_image(prompt=prompt, output=output, model=model)
        fmt.success(result)
    except Exception as e:
        _handle_ai_error(ctx, "generate.scene-image", e)


@generate.command("edit")
@click.argument("file", type=click.Path(exists=True), required=False)
@click.option("--prompt", required=True, help="描述期望的编辑效果")
@click.option("-o", "--output", required=True, help="输出图像路径")
@click.option(
    "--model", default="openai/gpt-image-1.5", help="编辑模型: openai/gpt-image-1.5, azure/gpt-image-2"
)
@click.option(
    "--mask",
    "mask_path",
    default=None,
    type=click.Path(exists=True),
    help="蒙版图片路径（PNG，透明区域为编辑区域）",
)
@click.option("--size", default="1024x1024", help="输出尺寸")
@click.option(
    "--ref-image",
    "ref_images",
    multiple=True,
    type=click.Path(exists=True),
    help="参考图路径（可多次传入，仅 gpt-image-2 支持多张）",
)
@click.pass_context
def generate_edit_cmd(ctx, file, prompt, output, model, mask_path, size, ref_images):
    from .ops.edit import run_edit_image

    fmt: OutputFormatter = ctx.obj["fmt"]
    if not file and not ref_images:
        raise click.UsageError("必须提供底图 FILE 或至少一张 --ref-image 参考图")
    try:
        result = run_edit_image(
            prompt=prompt,
            image_path=file,
            output=output,
            model=model,
            mask_path=mask_path,
            size=size,
            ref_images=list(ref_images) if ref_images else None,
        )
        fmt.success(result)
    except Exception as e:
        _handle_ai_error(ctx, "edit.image", e)


@main.command("analyze")
@click.argument("file", type=click.Path(exists=True))
@click.option(
    "--prompt", default="请详细描述这张图片的内容", help="对图像提出的问题或描述请求"
)
@click.option(
    "--model",
    default="gemini/gemini-2.5-flash",
    help="Vision 模型: gemini/*, openai/gpt-5, dashscope/qwen3-vl-plus",
)
@click.pass_context
def analyze_cmd(ctx, file, prompt, model):
    from .ops.analyze import run_analyze_image

    fmt: OutputFormatter = ctx.obj["fmt"]
    try:
        result = run_analyze_image(image_path=file, prompt=prompt, model=model)
        if ctx.obj.get("json"):
            fmt.success(result)
        else:
            click.echo(result.metadata.get("response", ""))
            click.echo(
                f"\n[{model} | tokens: {result.metadata.get('total_tokens', 0)} | {result.duration_ms}ms]",
                err=True,
            )
    except Exception as e:
        _handle_ai_error(ctx, "analyze.image", e)


@main.group()
def element() -> None:
    """VOD 自定义主体管理"""
    pass


@element.command("create")
@click.option("--name", required=True, help="主体名称")
@click.option("--description", required=True, help="主体描述")
@click.option("--image", "image_url", required=True, help="正面照 URL")
@click.pass_context
def element_create_cmd(ctx, name, description, image_url):
    from .providers.tencent_vod import vod_create_element

    fmt: OutputFormatter = ctx.obj["fmt"]
    try:
        element_id = vod_create_element(
            name=name, description=description, frontal_image_url=image_url
        )
        result = OperationResult(
            status="success",
            operation="element.create",
            metadata={"element_id": element_id, "name": name},
            provider="tencent_vod",
        )
        fmt.success(result)
    except Exception as e:
        _handle_ai_error(ctx, "element.create", e)


@main.command("enhance")
@click.option("--file-id", required=True, help="VOD 文件 ID")
@click.option(
    "--template-id", type=int, default=101540, help="超分模板 ID (默认: 真人1080P)"
)
@click.option("-o", "--output", default=None, help="输出路径（可选）")
@click.pass_context
def enhance_cmd(ctx, file_id, template_id, output):
    from .providers.tencent_vod import vod_enhance_submit, vod_task_poll
    from .providers._base import download_file

    fmt: OutputFormatter = ctx.obj["fmt"]
    try:
        task_id = vod_enhance_submit(file_id=file_id, template_id=template_id)
        click.echo(f"任务已提交: {task_id}", err=True)
        result_data = vod_task_poll(task_id)
        r = result_data.get("result", {})
        video_url = None
        for fi in r.get("file_infos", []):
            video_url = fi.get("file_url") or fi.get("url")
            if video_url:
                break
        if output and video_url:
            download_file(video_url, output)
        result = OperationResult(
            status="success",
            operation="enhance",
            output=output or "",
            metadata={
                "task_id": task_id,
                "video_url": video_url,
                "template_id": template_id,
            },
            provider="tencent_vod",
        )
        fmt.success(result)
    except Exception as e:
        _handle_ai_error(ctx, "enhance", e)


def _handle_ai_error(ctx: click.Context, operation: str, exc: Exception) -> None:
    fmt: OutputFormatter = ctx.obj["fmt"]
    result = OperationResult(
        status="error",
        operation=operation,
        error_code="API_ERROR",
        message=str(exc),
    )
    fmt.error(result)
