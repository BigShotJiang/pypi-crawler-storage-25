"""animal-mediakit: AI 图像/视频生成 + 本地图像处理 CLI 工具"""

__version__ = "0.1.0"
