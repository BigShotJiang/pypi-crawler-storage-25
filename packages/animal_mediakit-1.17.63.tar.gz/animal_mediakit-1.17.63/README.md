# animal-mediakit

AI 图像/视频生成 + 本地图像处理 CLI 工具，通过 animal-gateway 统一调用多家 AI 供应商模型。

## 快速开始

```bash
cd extensions/animal-mediakit
uv sync
uv run animal-mediakit auth login
uv run animal-mediakit auth ping
```

## 供应商支持矩阵

| 能力 | Gemini | OpenAI | Volcengine | DashScope | 腾讯云 VOD |
|------|--------|--------|------------|-----------|-----------|
| 生图 | gemini-2.5-flash-image | gpt-image-1.5 / azure/gpt-image-2 / tencent/gpt-image-2 | Seedream 5.0 | Wan 2.6 | GEM/SI/Kling/Vidu/Jimeng/Hunyuan/Qwen/OG(gpt-image-2) |
| 生视频 | Veo 2.0 | Sora 2 | Seedance 2.0 | Wan 2.6 T2V | Kling/Vidu/Hailuo/Seedance/GV/OS |
| 图生视频 | - | - | - | - | Kling/Vidu/GV (首帧/参考) |
| 图片编辑 | - | gpt-image-1.5 | - | - | - |
| 图片分析 | Gemini Vision | GPT-5 Vision | - | Qwen3-VL | - |
| 对口型 | - | - | - | - | Kling (lip_sync) |
| 数字人 | - | - | - | - | Kling (avatar_i2v) |
| 场景化生图 | - | - | - | - | 电商场景 |
| 超分增强 | - | - | - | - | ProcessMedia |

## CLI 命令参考

### 认证

```bash
animal-mediakit auth login              # SSO 登录
animal-mediakit auth logout             # 登出
animal-mediakit auth status             # 查看当前认证状态
animal-mediakit auth ping               # 测试 gateway 连通性
```

### AI 图像生成

```bash
animal-mediakit generate image "prompt" -o out.png --model gemini/gemini-2.5-flash-image
animal-mediakit generate image "prompt" -o out.png --model openai/gpt-image-1.5
animal-mediakit generate image "prompt" -o out.png --model azure/gpt-image-2
animal-mediakit generate image "prompt" -o out.png --model tencent/gpt-image-2
animal-mediakit generate image "prompt" -o out.png --model doubao-seedream-5-0-260128
animal-mediakit generate image "prompt" -o out.png --model dashscope/wan2.6-image
animal-mediakit generate image "prompt" -o out.png --model vod/gem-3.1
animal-mediakit generate image "prompt" -o out.png --model vod/kling-3.0
animal-mediakit generate image "prompt" -o out.png --model vod/og-image2_low
animal-mediakit generate image "prompt" -o out.png --model vod/og-image2_high
```

### AI 视频生成

```bash
animal-mediakit generate video "prompt" -o out.mp4 --model gemini/veo-2.0-generate-001
animal-mediakit generate video "prompt" -o out.mp4 --model openai/sora-2.0
animal-mediakit generate video "prompt" -o out.mp4 --model doubao-seedance-2-0-260128
animal-mediakit generate video "prompt" -o out.mp4 --model vod/kling-3.0 --duration 5
animal-mediakit generate video "prompt" -o out.mp4 --model vod/gv-3.1 --audio
```

### VOD 高级场景

```bash
# 图生视频（首帧参考）
animal-mediakit generate video "prompt" -o out.mp4 --model vod/kling-3.0 --from-image ref.jpg

# 对口型
animal-mediakit generate lipsync --video input.mp4 --audio voice.mp3 -o out.mp4

# 数字人
animal-mediakit generate avatar --image person.png --audio speech.mp3 -o out.mp4

# 场景化生图（电商）
animal-mediakit generate scene-image "product on marble" --model vod/gem-3.0 -o out.png

# 超分增强
animal-mediakit enhance --file-id xxx -o enhanced.mp4
```

### 自定义主体

```bash
animal-mediakit element create --name "my-cat" --description "orange tabby" --image https://example.com/cat.jpg
```

### 图片编辑

```bash
animal-mediakit generate edit photo.jpg --prompt "把天空变成日落" -o edited.jpg
animal-mediakit generate edit photo.jpg --prompt "移除背景" -o edited.png --mask mask.png
```

### 图片分析

```bash
animal-mediakit analyze photo.jpg --prompt "描述这张图片"
animal-mediakit analyze photo.jpg --model openai/gpt-5 --prompt "这是什么品种的猫？"
```

### 本地图像处理

```bash
animal-mediakit image info photo.jpg
animal-mediakit image crop photo.jpg --rect 100,100,500,400 -o cropped.jpg
animal-mediakit image resize photo.jpg --width 800 -o resized.jpg
animal-mediakit image flip photo.jpg --direction horizontal -o flipped.jpg
animal-mediakit image rotate photo.jpg --angle 90 -o rotated.jpg
animal-mediakit image convert photo.jpg --format webp -o photo.webp
animal-mediakit image compress photo.jpg --quality 80 -o compressed.jpg
```

## 环境变量

| 变量 | 说明 | 默认值 |
|------|------|--------|
| `MEDIAKIT_DEFAULT_IMAGE_MODEL` | 默认图像生成模型 | `gemini/gemini-2.5-flash-image` |
| `MEDIAKIT_DEFAULT_VIDEO_MODEL` | 默认视频生成模型 | `gemini/veo-2.0-generate-001` |
| `MEDIAKIT_HTTP_MAX_RETRIES` | HTTP 请求最大重试次数 | `3` |
| `MEDIAKIT_HTTP_RETRY_DELAY` | 重试基础延迟（秒） | `2.0` |

## 测试

```bash
uv run pytest tests/ -x                          # 单元测试
uv run pytest tests/ -m integration -v -s        # 集成测试（需要有效凭证）
```

## 详细文档

- [CLI 命令参考](docs/cli-reference.md)
- [认证流程说明](docs/auth-flow.md)
- [上游服务关联与维护指南](docs/upstream-services.md)
- [VOD AIGC 集成测试报告](docs/test-results-vod-aigc.md)
- [Skill 集成](SKILL.md)
