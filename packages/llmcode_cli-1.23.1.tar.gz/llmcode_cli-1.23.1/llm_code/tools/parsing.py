"""Dual-track tool call parsing: native API format and XML tag format.

Two XML formats are supported, tried in order:

1. **JSON-payload format** (the original llm-code XML protocol):
   ``<tool_call>{"tool": "NAME", "args": {...}}</tool_call>``

2. **Hermes function-calling format** (Qwen3, NousHermes, and most
   tool-fine-tuned local models served via vLLM without
   ``--enable-auto-tool-choice``):
   ``<tool_call>``
   ``  <function=NAME>``
   ``    <parameter=KEY>``
   ``    VALUE``
   ``    </parameter>``
   ``  </function>``
   ``</tool_call>``
"""
from __future__ import annotations

import dataclasses
import json
import re
import uuid

_XML_TOOL_CALL_RE = re.compile(
    r"<tool_call>(.*?)</tool_call>",
    re.DOTALL,
)
_HERMES_FUNCTION_RE = re.compile(
    r"<function=([^>\s]+)\s*>(.*?)</function>",
    re.DOTALL,
)
# Template-truncated form. Some chat templates (notably vLLM-served Qwen3
# in tool-calling mode) inject "<tool_call>\n<function=" as the assistant
# prompt PREFIX. The model continues with "NAME>...params...</function>",
# so the streamed body of <tool_call> starts with the bare function name
# followed by ">" (or directly by "{" for JSON-args variants) instead of
# with "<function=NAME>". Match identifier characters only at the start
# (so a literal "<function>" with no name still fails this regex and
# the body falls through to "no parse"). The separator can be:
#   - ``>``     — classic truncated form (PR #15, PR #16)
#   - ``{``     — variant 4 emits ``web_search{"args": ...}`` with no
#     ``>`` between name and JSON (captured 2026-04-08 from Qwen3.5)
_HERMES_FUNCTION_TRUNCATED_RE = re.compile(
    r"^\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*(?:>|(?=\{))(.*?)(?:</function>|\Z)",
    re.DOTALL,
)
_HERMES_PARAMETER_RE = re.compile(
    r"<parameter=([^>\s]+)\s*>(.*?)</parameter>",
    re.DOTALL,
)

# Variant 5 — bare name-as-tag form, emitted by Qwen3.5-122B on some
# vLLM chat template configurations where NEITHER ``<tool_call>`` NOR
# ``<function=NAME>`` appears in the stream. The on-wire shape is:
#
#     <web_search>{"query": "今日熱門新聞", "max_results": 3}</web_search>
#
# The closing tag may NOT match the opening tag — observed in the wild:
#
#     <web_search>{"query": "今日熱門新聞", "max_results": 3}</search>
#
# That is: the function name IS the XML tag itself, and the body is
# a JSON object of args. The leading ``<`` may also be missing in
# terminal renderings (and possibly in the actual stream when the
# chat template prefix-injected it as a prompt prefix), so the regex
# makes the opening ``<`` optional.
#
# Name capture is a conservative Python-identifier regex so this
# variant only triggers when the tag name looks like a real function
# name (no dashes, no dots, no numbers at the start). Combined with
# the "only try when no <tool_call> matches were found" guard in
# ``_parse_xml`` and the JSON-must-parse-as-dict check in
# ``_parse_bare_name_tag``, false positives on legitimate XML-ish
# content are effectively impossible.
# Closing tag may differ from opening tag — Qwen3.5 sometimes emits
# ``<web_search>JSON</search>`` (truncated closer). We capture the
# opening name and accept ANY ``</identifier>`` as closer.
_HERMES_BARE_NAME_TAG_RE = re.compile(
    r"<?([a-zA-Z_][a-zA-Z0-9_]*)>\s*(\{.*?\})\s*</[a-zA-Z_][a-zA-Z0-9_]*>",
    re.DOTALL,
)

# Tag names variant 5 must NEVER interpret as a tool call, even when
# the body is valid JSON. These are reserved by the protocol and
# already handled by earlier parser stages — matching them here
# would double-count or re-interpret a malformed wrapper as its own
# tool named "tool_call".
_VARIANT_5_RESERVED_NAMES: frozenset[str] = frozenset({
    "tool_call",
    "think",
    "function",
    "parameter",
})


@dataclasses.dataclass(frozen=True)
class ParsedToolCall:
    id: str
    name: str
    args: dict
    source: str  # "native" | "xml_tag"


def parse_tool_calls(
    response_text: str,
    native_tool_calls: list[dict] | None,
    known_tool_names: set[str] | frozenset[str] | None = None,
) -> list[ParsedToolCall]:
    """Parse tool calls from either native API format or XML tags in text.

    If native_tool_calls is a non-empty list, parse those (native track).
    Otherwise, fall back to scanning response_text for ``<tool_call>``
    tags. Both JSON-payload and Hermes-function formats are accepted; we
    try JSON first (cheaper) and fall back to Hermes if that fails.

    ``known_tool_names`` restricts the bare ``<NAME>JSON</NAME>`` variant
    5 fallback to tags whose name matches a registered tool. Callers
    without a tool registry (e.g. tests) can pass ``None`` and the
    variant runs unrestricted — keep in mind that permissive mode can
    match ``<p>{"a":1}</p>`` and similar HTML-ish content as a false
    positive, so production callers should always pass the set.
    """
    if native_tool_calls:
        return _parse_native(native_tool_calls)
    return _parse_xml(response_text, known_tool_names)


def _parse_native(native: list[dict]) -> list[ParsedToolCall]:
    result: list[ParsedToolCall] = []
    for call in native:
        call_id = call.get("id", str(uuid.uuid4()))
        name = call.get("name", "")
        args = call.get("input", {})
        if not name:
            continue
        result.append(ParsedToolCall(id=call_id, name=name, args=args, source="native"))
    return result


def _parse_xml(
    text: str,
    known_tool_names: set[str] | frozenset[str] | None = None,
) -> list[ParsedToolCall]:
    """Scan the response text for tool calls, accepting the JSON-payload
    and Hermes function-calling formats inside ``<tool_call>`` blocks,
    plus the bare ``<NAME>JSON</NAME>`` variant from Qwen3.5 vLLM chat
    templates that omit the ``<tool_call>`` wrapping entirely."""
    result: list[ParsedToolCall] = []
    for match in _XML_TOOL_CALL_RE.finditer(text):
        raw = match.group(1).strip()
        # Try JSON-payload format first (cheaper).
        parsed = _parse_json_payload(raw)
        if parsed is None:
            # Fall back to Hermes function-calling format.
            parsed = _parse_hermes_block(raw)
        if parsed is not None:
            result.append(parsed)

    # Variant 5 fallback: if no ``<tool_call>`` wrapper was found, try
    # the bare ``<NAME>JSON</NAME>`` variant. Only triggered when the
    # standard wrappers return nothing, so existing cases stay on the
    # fast path and the false-positive risk from random XML-ish
    # content is minimized.
    if not result:
        result.extend(_parse_bare_name_tag(text, known_tool_names))
    return result


def _parse_bare_name_tag(
    text: str,
    known_tool_names: set[str] | frozenset[str] | None = None,
) -> list[ParsedToolCall]:
    """Variant 5 — parse bare ``<NAME>JSON</NAME>`` tool calls.

    Only called from ``_parse_xml`` when no ``<tool_call>`` wrapper
    match was found, so the fast path for well-formed emissions is
    untouched. Each match must contain a JSON object body; scalars,
    lists, and invalid JSON are rejected as false-positive guards.

    When ``known_tool_names`` is provided, tag names not in the set
    are rejected — this is the production guard against false
    positives like ``<p>{"a":1}</p>`` that the identifier-only regex
    would otherwise capture. Callers without a registry (e.g. tests)
    can pass ``None`` for permissive matching.

    Also handles common arg-nesting shapes the same way the existing
    Hermes truncated-JSON variant does:

    1. ``{"key": "value", ...}``          — args at top level
    2. ``{"args": {"key": "value"}}``     — args nested under "args"
    3. ``{"arguments": {"key": "value"}}`` — args nested under "arguments"
    """
    result: list[ParsedToolCall] = []
    for match in _HERMES_BARE_NAME_TAG_RE.finditer(text):
        name = match.group(1)
        if name in _VARIANT_5_RESERVED_NAMES:
            continue
        if known_tool_names is not None and name not in known_tool_names:
            continue
        body = match.group(2).strip()
        try:
            data = json.loads(body)
        except json.JSONDecodeError:
            continue
        if not isinstance(data, dict):
            continue
        # Unwrap common nesting shapes. If the body is already flat
        # args, pass it through.
        if isinstance(data.get("args"), dict):
            args = data["args"]
        elif isinstance(data.get("arguments"), dict):
            args = data["arguments"]
        else:
            args = data
        result.append(
            ParsedToolCall(
                id=str(uuid.uuid4()),
                name=name,
                args=args,
                source="xml_tag",
            )
        )
    return result


def _parse_json_payload(raw: str) -> ParsedToolCall | None:
    """Parse the original llm-code JSON payload format.

    ``{"tool": "NAME", "args": {...}}`` — args defaults to ``{}``.
    Returns None if the block isn't valid JSON or has no ``tool`` key.
    """
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return None
    if not isinstance(data, dict):
        return None
    name = data.get("tool")
    if not name:
        return None
    args = data.get("args", {})
    if not isinstance(args, dict):
        args = {}
    return ParsedToolCall(
        id=str(uuid.uuid4()), name=name, args=args, source="xml_tag"
    )


def _parse_hermes_block(raw: str) -> ParsedToolCall | None:
    """Parse the Hermes function-calling format used by Qwen3, NousHermes,
    and most vLLM-served tool-fine-tuned local models.

    Three sub-formats are supported:

    1. **Full form** — ``<function=NAME>`` opens, ``<parameter=KEY>VALUE</parameter>``
       blocks repeat, ``</function>`` closes.
    2. **Template-truncated form** — vLLM-served Qwen3 chat template
       injects ``<tool_call>\\n<function=`` as the assistant prompt
       prefix, so the streamed body of ``<tool_call>`` starts directly
       with the bare function name followed by ``>`` (e.g.
       ``web_search>...``). Parameters are still ``<parameter=...>``
       blocks.
    3. **Truncated + JSON args form** — same template-truncation as #2,
       but the body after ``NAME>`` is a JSON object instead of
       ``<parameter=...>`` blocks. The JSON may be at the top level
       (e.g. ``{"command": "ls"}``) or nested under ``args`` /
       ``arguments`` (e.g. ``{"args": {"query": "...", "max_results": 3}}``).
       This is what local Qwen3 sometimes emits when the chat template
       primes the model with the ``<function=`` prefix but the model's
       fine-tune produces JSON rather than parameter tags.

    Parameter values are stripped of leading/trailing whitespace; internal
    whitespace (including newlines) is preserved so multi-line content
    (e.g. file bodies) round-trips correctly.

    Returns None if no form matches.
    """
    # Try full form first.
    fn_match = _HERMES_FUNCTION_RE.search(raw)
    if fn_match:
        name = fn_match.group(1).strip()
        body = fn_match.group(2)
    else:
        # Fall back to template-truncated form.
        trunc_match = _HERMES_FUNCTION_TRUNCATED_RE.match(raw)
        if not trunc_match:
            return None
        name = trunc_match.group(1).strip()
        body = trunc_match.group(2)
    if not name:
        return None
    args = _parse_hermes_args(body)
    return ParsedToolCall(
        id=str(uuid.uuid4()), name=name, args=args, source="xml_tag"
    )


def _parse_hermes_args(body: str) -> dict:
    """Extract args from a Hermes function body.

    Strategy (in order):
    1. ``<parameter=KEY>VALUE</parameter>`` blocks. If any present, use them.
    2. JSON object payload — if the body (after stripping any trailing
       ``</function>``) parses as a JSON dict, use it. If the dict has an
       ``args`` or ``arguments`` key whose value is also a dict, prefer
       the inner dict (so ``{"args": {"query": "x"}}`` → ``{"query": "x"}``).
    3. Otherwise return ``{}`` — caller still gets a valid ParsedToolCall
       with the function name, just no args.
    """
    # 1) parameter blocks
    args: dict = {}
    for param_match in _HERMES_PARAMETER_RE.finditer(body):
        key = param_match.group(1).strip()
        value = param_match.group(2).strip()
        if key:
            args[key] = value
    if args:
        return args

    # 2) JSON payload — strip trailing XML closing tag if present, then
    # find the first '{' and try to parse from there to the matching '}'.
    # The closing tag may be </function>, </search>, </web_search>, etc.
    candidate = body.strip()
    _trail_tag = re.search(r"</[a-zA-Z_][a-zA-Z0-9_]*>\s*$", candidate)
    if _trail_tag:
        candidate = candidate[: _trail_tag.start()].strip()
    if not candidate.startswith("{"):
        # Try to find the first '{' anywhere in the body — handles
        # leading whitespace/newlines that strip() didn't catch.
        brace_idx = candidate.find("{")
        if brace_idx == -1:
            return {}
        candidate = candidate[brace_idx:]
    try:
        data = json.loads(candidate)
    except json.JSONDecodeError:
        return {}
    if not isinstance(data, dict):
        return {}
    # Prefer wrapped 'args' / 'arguments' dict if present
    for wrapper in ("args", "arguments"):
        inner = data.get(wrapper)
        if isinstance(inner, dict):
            return inner
    return data
