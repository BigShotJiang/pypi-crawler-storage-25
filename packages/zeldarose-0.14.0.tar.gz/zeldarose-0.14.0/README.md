# Zelda Rose

[![Latest PyPI version](https://img.shields.io/pypi/v/zeldarose.svg)](https://pypi.org/project/zeldarose)

A straightforward trainer for transformer-based models.

## Installation

Simply install with pipx

```bash
pipx install zeldarose
```

## Train MLM models

Here is a short example of training first a tokenizer, then a transformer MLM model:

```bash
TOKENIZERS_PARALLELISM=true zeldarose tokenizer --vocab-size 4096 --out-path local/tokenizer  --model-name "my-muppet" tests/fixtures/raw.txt
zeldarose 
transformer --tokenizer local/tokenizer --pretrained-model flaubert/flaubert_small_cased --out-dir local/muppet --val-text tests/fixtures/raw.txt tests/fixtures/raw.txt
```

See [the documentation](https://mgrobol.codeberg.page/zeldarose) for more details!

## Citation

If you use Zelda Rose, please cite it as :

> Loïc Grobol. 2023. ‘Zelda Rose: A Tool for Hassle-Free Training of Transformer Models’. Paper
> presented at NLP OSS, Singapore, Indonesia. Proceedings of the 3rd Workshop for Natural Language
> Processing Open Source Software. <https://hal.science/hal-04262806>.

## Licence

This software is released under the
[EUPL 1.2](https://interoperable-europe.ec.europa.eu/collection/eupl/eupl-text-eupl-12) or later,
with some files released under compatible free licences, see [LICENCE.md](LICENCE.md) for the
details.
