## Distributed training

This is somewhat tricky, you have several options

- If you are running in a SLURM cluster use `--strategy ddp` and invoke via `srun`

  - You might want to preprocess your data first outside the main compute allocation. The
    `--profile` option might be abused for that purpose, since it won't run a full training, but
    will run any data preprocessing you ask for. It might also be beneficial at this step to load a
    placeholder model such as
    [RoBERTa-minuscule](https://huggingface.co/lgrobol/roberta-minuscule/tree/main) to avoid running
    out of memory, since the only thing that matter for this preprocessing is the tokenizer.

- Otherwise, you have two options

  - Run with `--strategy ddp_spawn`, which uses `multiprocessing.spawn` to start the process swarm
    (tested, but possibly slower and more limited, see `pytorch-lightning` doc)
  - Run with `--strategy ddp` and start with `torch.distributed.launch` with `--use_env` and
    `--no_python` (untested)

## Other hints

- Data management relies on 🤗 datasets and use their cache management system. To run in a clear
  environment, you might have to check the cache directory pointed to by the`HF_DATASETS_CACHE`
  environment variable.