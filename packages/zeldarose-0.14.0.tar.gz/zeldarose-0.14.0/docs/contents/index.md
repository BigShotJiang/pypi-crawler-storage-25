# 🌹 Zelda Rose 🌹

[![Latest PyPI version](https://img.shields.io/pypi/v/zeldarose.svg)](https://pypi.org/project/zeldarose)

A straightforward trainer for transformer-based models. In others words:
[a teacher of muppets](https://muppet.fandom.com/wiki/Zelda_Rose).

> Zelda Rose is a command line interface for pretraining transformer-based models. Its purpose is to
> enable an easy start for users interested in training these ubiquitous models, but unable or
> unwilling to engage with more comprehensive — but more complex — frameworks and the complex
> interactions between libraries for managing models, datasets and computations. Training a model
> requires no code on the user's part and produce models directly compatible with the 🤗 ecosystem,
> allowing quick and easy distribution and reuse. A particular care is given to lowering the cost of
> maintainability and future-proofing, by making the code as modular as possible and taking
> advantage of third-party libraries to limit ad-hoc code to the strict minimum. (Grobol,
> [2023](https://hal.science/hal-04262806))

## Getting Started

Check out [Get started](pages/get_started.md).

## Bugs and contributions

Please send them via
[![Codeberg logo](assets/codeberg.svg) Codeberg](https://codeberg.org/mgrobol/zeldarose).

## Citation

If you use Zelda Rose, please cite it as :

> Loïc Grobol. 2023. ‘Zelda Rose: A Tool for Hassle-Free Training of Transformer Models’. Paper
> presented at NLP OSS, Singapore, Indonesia. Proceedings of the 3rd Workshop for Natural Language
> Processing Open Source Software. <https://hal.science/hal-04262806>.

<details><summary>BibLaTeX</summary>
```bibtex
@inproceedings{grobol2023ZeldaRoseTool,
  title = {Zelda {{Rose}}: A Tool for Hassle-Free Training of Transformer Models},
  shorttitle = {Zelda {{Rose}}},
  booktitle = {Proceedings of the 3rd {{Workshop}} for {{Natural Language Processing Open Source Software}}},
  author = {Grobol, Loïc},
  date = {2023-12},
  url = {https://hal.science/hal-04262806},
  urldate = {2023-10-31},
  eventtitle = {{{NLP OSS}}},
}
```
</details>

<details><summary>CSL JSON</summary>
```json
{
  "id":"grobol2023ZeldaRoseTool",
  "accessed":{"date-parts":[["2023",10,31]]},
  "author":[{"family":"Grobol","given":"Loïc"}],
  "citation-key":"grobol2023ZeldaRoseTool",
  "container-title":"Proceedings of the 3rd Workshop for Natural Language Processing Open Source Software",
  "event-place":"Singapore, Indonesia",
  "event-title":"NLP OSS",
  "issued":{"date-parts":[["2023",12]]},
  "title":"Zelda Rose: a tool for hassle-free training of transformer models",
  "type":"paper-conference",
  "URL":"https://hal.science/hal-04262806"
}
```
</details>
