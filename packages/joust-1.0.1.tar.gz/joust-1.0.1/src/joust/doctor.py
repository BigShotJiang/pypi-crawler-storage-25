"""Diagnosis and cleanup for joust state.

``doctor`` looks for common kinds of drift between joust's state, git's
view of worktrees/branches, and the filesystem:

  - **Stale active pointer.** ``$JOUST_HOME/active.json`` names a run whose
    ``manifest.json`` no longer exists on disk (e.g. the user ran
    ``rm -rf ~/.joust`` or the run dir was in ``/tmp`` and got wiped).

  - **Missing worktrees.** A manifest variant's recorded ``worktree`` path
    no longer exists on disk. Nothing to fix — the worktree is already
    gone — but joust should still tell you so you aren't confused.

  - **Orphan joust branches.** Git has a local branch named
    ``joust/<run-id>/variant-<NN>`` whose ``run-id`` does not appear in
    any manifest for this repo. That's almost always an abandoned run.

Every check emits an :class:`Issue`. The doctor command collects them,
prints them, and — if ``--fix`` is passed — asks each issue whether it
has a ``fix`` function and runs it.
"""

from __future__ import annotations

import dataclasses
import pathlib
import re
import subprocess
from dataclasses import dataclass, field
from typing import Callable

from . import gitops, paths, store


JOUST_BRANCH_RE = re.compile(r"^joust/(?P<run_id>[^/]+)/variant-\d+$")


@dataclass
class Issue:
    kind: str
    message: str
    fix: Callable[[], None] | None = None

    @property
    def fixable(self) -> bool:
        return self.fix is not None


def _known_run_ids_for_repo(repo_path: pathlib.Path) -> set[str]:
    """Return every run_id whose manifest is for the given repo path."""
    runs_root = paths.state_root() / "runs"
    known: set[str] = set()
    if not runs_root.exists():
        return known
    for slug_dir in runs_root.iterdir():
        if not slug_dir.is_dir():
            continue
        for run_dir in slug_dir.iterdir():
            if not (run_dir / "manifest.json").exists():
                continue
            try:
                m = store.load(slug_dir.name, run_dir.name)
            except Exception:
                continue
            if m.repo_path == str(repo_path):
                known.add(m.run_id)
    return known


def _local_joust_branches(repo: pathlib.Path) -> list[str]:
    try:
        out = subprocess.run(
            ["git", "for-each-ref", "--format=%(refname:short)", "refs/heads/joust/"],
            cwd=str(repo),
            capture_output=True,
            text=True,
            check=True,
        ).stdout
    except subprocess.CalledProcessError:
        return []
    return [line.strip() for line in out.splitlines() if line.strip()]


def diagnose(repo: pathlib.Path) -> list[Issue]:
    """Return a list of issues found. Empty list means healthy."""
    issues: list[Issue] = []

    # 1. Stale active pointer: active.json names a run with no manifest.
    active = store.get_active(str(repo))
    if active is not None:
        slug, run_id = active
        if not paths.manifest_path(slug, run_id).exists():
            def _clear_active(repo_path=str(repo)) -> None:
                store.clear_active(repo_path)

            issues.append(
                Issue(
                    kind="stale-active-pointer",
                    message=(
                        f"active pointer references {slug}/{run_id} but its "
                        f"manifest no longer exists"
                    ),
                    fix=_clear_active,
                )
            )

    # 2. Missing worktrees referenced by manifests for this repo.
    runs_root = paths.state_root() / "runs"
    if runs_root.exists():
        for slug_dir in runs_root.iterdir():
            if not slug_dir.is_dir():
                continue
            for run_dir in slug_dir.iterdir():
                if not (run_dir / "manifest.json").exists():
                    continue
                try:
                    m = store.load(slug_dir.name, run_dir.name)
                except Exception:
                    continue
                if m.repo_path != str(repo):
                    continue
                for v in m.variants:
                    if v.worktree and not pathlib.Path(v.worktree).exists():
                        issues.append(
                            Issue(
                                kind="missing-worktree",
                                message=(
                                    f"{m.slug}/{m.run_id} variant {v.id} "
                                    f"worktree missing at {v.worktree}"
                                ),
                                # no auto-fix; the worktree is already gone
                            )
                        )

    # 3. Orphan joust branches.
    known = _known_run_ids_for_repo(repo)
    for branch in _local_joust_branches(repo):
        m = JOUST_BRANCH_RE.match(branch)
        if not m:
            continue
        branch_run_id = m.group("run_id")
        if branch_run_id not in known:
            def _delete_branch(b: str = branch, r: pathlib.Path = repo) -> None:
                gitops.delete_branch(r, b, force=True)
                # also prune any worktree registrations that referenced it
                try:
                    gitops.worktree_prune(r)
                except gitops.GitError:
                    pass

            issues.append(
                Issue(
                    kind="orphan-branch",
                    message=f"orphan joust branch {branch} (run {branch_run_id} unknown)",
                    fix=_delete_branch,
                )
            )

    return issues


def apply_fixes(issues: list[Issue]) -> tuple[int, int]:
    """Run fix() on every fixable issue. Returns (fixed, skipped)."""
    fixed = 0
    skipped = 0
    for issue in issues:
        if issue.fixable:
            issue.fix()  # type: ignore[misc]
            fixed += 1
        else:
            skipped += 1
    return fixed, skipped
