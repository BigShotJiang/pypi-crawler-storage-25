"""Filesystem layout for Joust state.

All Joust state lives under ``$JOUST_HOME`` (default ``~/.joust``).

    $JOUST_HOME/
      active.json                       # maps repo-slug -> active run_id
      runs/
        <slug>/
          <run-id>/
            manifest.json               # the contract
            events.jsonl                # append-only event log
            worktrees/
              variant-01/               # git worktree (one per variant)
              variant-02/
              ...
            artifacts/
              variant-01/               # optional evidence files
"""

from __future__ import annotations

import os
import pathlib


def state_root() -> pathlib.Path:
    """Return the root directory for Joust state."""
    env = os.environ.get("JOUST_HOME")
    if env:
        return pathlib.Path(env).expanduser()
    return pathlib.Path.home() / ".joust"


def active_pointer() -> pathlib.Path:
    return state_root() / "active.json"


def run_dir(slug: str, run_id: str) -> pathlib.Path:
    return state_root() / "runs" / slug / run_id


def manifest_path(slug: str, run_id: str) -> pathlib.Path:
    return run_dir(slug, run_id) / "manifest.json"


def events_path(slug: str, run_id: str) -> pathlib.Path:
    return run_dir(slug, run_id) / "events.jsonl"


def worktrees_dir(slug: str, run_id: str) -> pathlib.Path:
    return run_dir(slug, run_id) / "worktrees"


def variant_worktree(slug: str, run_id: str, variant_id: str) -> pathlib.Path:
    return worktrees_dir(slug, run_id) / variant_id


def artifacts_dir(slug: str, run_id: str, variant_id: str) -> pathlib.Path:
    return run_dir(slug, run_id) / "artifacts" / variant_id
