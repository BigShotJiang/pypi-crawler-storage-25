"""Deterministic rendering helpers.

Joust itself never calls an LLM. When the agent needs a prompt (e.g. for
``scenarios suggest`` or ``judge``), we emit a static, checked-in playbook
— the same discipline Magellan uses. When we need to show state to a human,
we emit a small markdown table.
"""

from __future__ import annotations

import textwrap

from .store import Manifest, Variant


# ---------------------------------------------------------------------------
# Static playbooks (printed verbatim to stdout)
# ---------------------------------------------------------------------------


def suggest_playbook(
    goal: str,
    count: int,
    prior_runs: list[Manifest] | None = None,
) -> str:
    """Render the scenario brainstorming playbook.

    When ``prior_runs`` is non-empty, appends a block naming each prior
    run's slug, goal, and picked variant (or status) so the agent can
    avoid reinventing angles that have already been explored.
    """
    base = textwrap.dedent(
        f"""\
        # Joust scenario brainstorming

        Goal: {goal}

        Come up with {count} distinct angles to prototype this feature. Each
        angle should differ in one or more of:

          - Product scope           (minimal happy path  <->  power-user)
          - UX paradigm             (guided wizard       <->  direct manipulation)
          - Architectural stance    (client-heavy        <->  server-heavy)
          - Tech/library choice     (boring defaults     <->  novel approach)
          - Assumption about users  (novice              <->  expert)

        Avoid near-duplicates. Each should be defensible as "the right answer"
        under some set of product priorities.

        For each angle, pick a short kebab-case name (3-5 words) and write a
        1-3 sentence description, then register it:

            joust scenarios add "short-name" --description "one to three sentences"

        After adding all {count}, run `joust scenarios list` to review them,
        then ask the human to approve with `joust scenarios approve --yes`
        (this is a required gate — agents cannot skip it). Once approved,
        run `joust lock` to materialize worktrees.
        """
    )
    if not prior_runs:
        return base
    return base + _prior_runs_block(prior_runs)


def _prior_runs_block(prior_runs: list[Manifest]) -> str:
    lines = [
        "",
        "## Prior runs for this repo",
        "",
        "Read these before proposing angles — avoid reinventing something",
        "that already lost, and look for gaps the prior runs did not cover.",
        "",
    ]
    for m in prior_runs:
        lines.append(f"  {m.slug}/{m.run_id}  goal: \"{m.goal}\"")
        if m.picked:
            try:
                picked = m.variant(m.picked)
                lines.append(f"    picked: {picked.id} ({picked.name})")
            except KeyError:
                lines.append(f"    picked: {m.picked}")
        else:
            lines.append("    (no winner picked yet)")
        scenario_names = ", ".join(v.name for v in m.variants)
        if scenario_names:
            lines.append(f"    scenarios: {scenario_names}")
        lines.append("")
    return "\n".join(lines)


def runner_playbook() -> str:
    return textwrap.dedent(
        """\
        # Joust runner selection

        Joust does not know which agent runner or model you want to use for
        the subagents that will implement each variant. Ask the user. A
        suggested question:

            "Which model should the N subagents run as?
               - opus    (strongest, most expensive — default)
               - sonnet  (balanced)
               - haiku   (cheapest, fastest)"

        Once the user answers, record the choice:

            joust runner set --runner claude-code --model <opus|sonnet|haiku>

        The runner and model will be written to the manifest and printed in
        each variant's PROMPT.md. When you dispatch subagents later, use the
        recorded model. Joust does not spawn subagents itself — you do, with
        whatever mechanism your runner supports (e.g. the Agent tool in
        Claude Code with the `model` parameter set).

        If the user wants a different model for a specific variant (e.g.
        "use opus for the complex variant and haiku for the throwaway"),
        record the override BEFORE `joust lock`:

            joust runner override variant-02 --model opus

        You can override as many variants as you like; unoverridden variants
        inherit the run-level default. `joust runner show` lists the current
        default and any overrides. Each variant's PROMPT.md will show the
        effective model (override if set, else the default).
        """
    )


_DEFAULT_RUBRIC_DESCRIPTIONS = {
    "correctness": "does it actually solve the goal?",
    "simplicity": "is the design minimal for what it does?",
    "fit": "does it match the scenario's stated angle?",
    "extensibility": "could this be grown into production?",
}


def judge_playbook(manifest: Manifest) -> str:
    rubric = manifest.rubric
    max_name = max((len(d) for d in rubric), default=0)

    rubric_lines: list[str] = []
    for dim in rubric:
        desc = _DEFAULT_RUBRIC_DESCRIPTIONS.get(dim)
        if desc:
            rubric_lines.append(f"       {dim.ljust(max_name)}  - {desc}")
        else:
            rubric_lines.append(f"       {dim}")

    score_example = " ".join(f"--dim {dim}=N" for dim in rubric)

    lines = [
        "# Joust judgment",
        "",
        f"Goal: {manifest.goal}",
        "",
        "You are judging the following variants. For each one:",
        "",
        "  1. cd into its worktree and read RATIONALE.md plus the actual code",
        "  2. Build/run it if the scenario calls for that",
        "  3. Score it across the rubric dimensions (1-5, higher is better):",
        "",
        *rubric_lines,
        "",
        "  4. Record the scores with:",
        "",
        "       joust score <variant-id> \\",
        f"           {score_example} \\",
        "           --rationale \"2-4 sentences of reasoning\"",
        "",
        "Variants:",
        "",
    ]
    for v in manifest.variants:
        lines.append(f"  - {v.id}  [{v.status}]  {v.name}")
        lines.append(f"      desc:     {v.description}")
        if v.worktree:
            lines.append(f"      worktree: {v.worktree}")
        latest = v.latest_record()
        if latest:
            lines.append(f"      summary:  {latest.summary}")
        lines.append("")
    lines.append(
        "When all variants have scores, run `joust compare` to see the table, "
        "then let the human run `joust pick <variant-id>`."
    )
    return "\n".join(lines)


def variant_prompt(manifest: Manifest, variant: Variant, total: int) -> str:
    runner_line = manifest.runner or "unspecified"
    # Per-variant override beats run-level default.
    effective_model = variant.model or manifest.model or "unspecified"
    model_line = effective_model
    return textwrap.dedent(
        f"""\
        # Joust variant: {variant.id} - {variant.name}

        You are one of {total} parallel agents exploring different
        implementations of the same feature. Do NOT look at or coordinate with
        other variants. Work only inside this worktree.

        ## Goal
        {manifest.goal}

        ## Your specific angle
        {variant.description}

        ## Environment
        - Worktree:  {variant.worktree}
        - Branch:    {variant.branch}
        - Base:      {manifest.base_ref} @ {manifest.base_sha[:12]}
        - Run id:    {manifest.run_id}
        - Runner:    {runner_line}
        - Model:     {model_line}

        ## What to produce
        1. A runnable prototype (not production) that demonstrates your angle.
        2. A `RATIONALE.md` at the worktree root explaining:
             - What you built and why
             - Tradeoffs you made
             - What would need to change to ship it

        ## Important
        - Do NOT push. The worktree has no remote; joust manages branches locally.
        - Do NOT run any joust commands other than `joust record`.

        ## Reporting back
        When you are done, from anywhere, run:

            joust record {variant.id} --status built \\
                --summary "1-2 sentences describing what you built"

        If you hit a blocker:

            joust record {variant.id} --status failed \\
                --summary "why you could not finish"

        You may attach artifacts (screenshots, logs) with:

            joust record {variant.id} --artifact path/to/file.png
        """
    )


# ---------------------------------------------------------------------------
# Tables for humans
# ---------------------------------------------------------------------------


def list_table(manifest: Manifest) -> str:
    rows = [("ID", "NAME", "STATUS", "BRANCH", "SUMMARY")]
    for v in manifest.variants:
        latest = v.latest_record()
        summary = (latest.summary if latest else "") or ""
        if len(summary) > 48:
            summary = summary[:45] + "..."
        rows.append(
            (
                v.id,
                v.name,
                v.status,
                v.branch or "-",
                summary or "-",
            )
        )
    return _format_table(rows)


def compare_table(manifest: Manifest) -> str:
    # Collect all dimension keys across variants to keep columns consistent.
    dimensions: list[str] = []
    for v in manifest.variants:
        score = v.latest_score()
        if score:
            for key in score.dimensions:
                if key not in dimensions:
                    dimensions.append(key)

    header = ["ID", "NAME", "STATUS", *dimensions, "TOTAL", "RATIONALE"]
    rows: list[tuple[str, ...]] = [tuple(header)]
    for v in manifest.variants:
        score = v.latest_score()
        dim_cells = [
            str(score.dimensions.get(d, "-")) if score else "-" for d in dimensions
        ]
        total = str(score.total) if score else "-"
        rationale = (score.rationale if score else "") or ""
        if len(rationale) > 60:
            rationale = rationale[:57] + "..."
        rows.append(
            tuple(
                [
                    v.id,
                    v.name,
                    v.status,
                    *dim_cells,
                    total,
                    rationale or "-",
                ]
            )
        )
    return _format_table(rows)


def _format_table(rows: list[tuple[str, ...]]) -> str:
    if not rows:
        return ""
    widths = [max(len(str(row[i])) for row in rows) for i in range(len(rows[0]))]
    lines = []
    for i, row in enumerate(rows):
        line = "  ".join(str(cell).ljust(widths[j]) for j, cell in enumerate(row))
        lines.append(line.rstrip())
        if i == 0:
            lines.append("  ".join("-" * w for w in widths))
    return "\n".join(lines)
