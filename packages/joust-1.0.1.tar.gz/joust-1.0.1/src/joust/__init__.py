"""Joust: parallel prototype orchestrator for coding agents."""

__version__ = "0.1.0"
