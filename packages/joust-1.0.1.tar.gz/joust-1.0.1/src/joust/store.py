"""Persistent state for Joust runs.

A run is a single exploration of a feature: one goal, N scenarios, N worktrees,
optional scores, and a pick. State is a single ``manifest.json`` per run plus an
append-only ``events.jsonl`` log. There is no database.

The active-run pointer (``$JOUST_HOME/active.json``) maps a repo slug to a run
id so commands like ``joust record`` know which run to mutate without the user
passing ``--run-id`` on every invocation.
"""

from __future__ import annotations

import contextlib
import dataclasses
import datetime as dt
import fcntl
import json
import os
import secrets
from dataclasses import dataclass, field
from typing import Any, Generator

from . import paths

SCHEMA_VERSION = 1

DEFAULT_RUBRIC: tuple[str, ...] = (
    "correctness",
    "simplicity",
    "fit",
    "extensibility",
)

# Status lifecycle for a variant:
#   pending  -> scenario added, no worktree yet
#   ready    -> worktree created after `joust lock`
#   in_progress -> agent started work (recorded)
#   built    -> agent finished successfully (recorded)
#   failed   -> agent recorded a blocker
#   judged   -> scores attached
#   picked   -> this variant won
#   archived -> worktree and branch cleaned up
VARIANT_STATES = (
    "pending",
    "ready",
    "in_progress",
    "built",
    "failed",
    "judged",
    "picked",
    "archived",
)


def utcnow_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def new_run_id() -> str:
    """Short, sortable-ish run id."""
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%y%m%d-%H%M%S")
    return f"{stamp}-{secrets.token_hex(2)}"


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class Record:
    at: str
    status: str
    summary: str = ""
    artifacts: list[str] = field(default_factory=list)


@dataclass
class Score:
    at: str
    judge: str = "agent"
    dimensions: dict[str, int] = field(default_factory=dict)
    rationale: str = ""

    @property
    def total(self) -> int:
        return sum(self.dimensions.values())


@dataclass
class Variant:
    id: str
    name: str
    description: str
    status: str = "pending"
    branch: str | None = None
    worktree: str | None = None
    prompt_path: str | None = None
    # Per-variant model override. When None, the variant inherits
    # ``Manifest.model``. Set via ``joust runner override``.
    model: str | None = None
    added_at: str = field(default_factory=utcnow_iso)
    records: list[Record] = field(default_factory=list)
    scores: list[Score] = field(default_factory=list)

    def latest_record(self) -> Record | None:
        return self.records[-1] if self.records else None

    def latest_score(self) -> Score | None:
        return self.scores[-1] if self.scores else None


@dataclass
class Manifest:
    version: int
    run_id: str
    slug: str
    goal: str
    base_ref: str
    base_sha: str
    repo_path: str
    created_at: str
    approved_at: str | None = None
    locked_at: str | None = None
    picked: str | None = None
    merged_at: str | None = None
    # Runner metadata: which agent runner + model will drive subagents.
    # Joust doesn't validate these; it just records what the driver declares.
    runner: str | None = None
    model: str | None = None
    # Rubric dimensions used for `joust score` and the judge playbook.
    # Defaults to the historical 4-dim rubric so pre-customization runs
    # load unchanged. Custom rubrics are declared at `joust init` time
    # and cannot be changed after lock.
    rubric: list[str] = field(default_factory=lambda: list(DEFAULT_RUBRIC))
    variants: list[Variant] = field(default_factory=list)

    # ---------- serialization ----------

    def to_dict(self) -> dict[str, Any]:
        return {
            "version": self.version,
            "run_id": self.run_id,
            "slug": self.slug,
            "goal": self.goal,
            "base_ref": self.base_ref,
            "base_sha": self.base_sha,
            "repo_path": self.repo_path,
            "created_at": self.created_at,
            "approved_at": self.approved_at,
            "locked_at": self.locked_at,
            "picked": self.picked,
            "merged_at": self.merged_at,
            "runner": self.runner,
            "model": self.model,
            "rubric": list(self.rubric),
            "variants": [
                {
                    "id": v.id,
                    "name": v.name,
                    "description": v.description,
                    "status": v.status,
                    "branch": v.branch,
                    "worktree": v.worktree,
                    "prompt_path": v.prompt_path,
                    "model": v.model,
                    "added_at": v.added_at,
                    "records": [dataclasses.asdict(r) for r in v.records],
                    "scores": [dataclasses.asdict(s) for s in v.scores],
                }
                for v in self.variants
            ],
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Manifest":
        variants = []
        for v in data.get("variants", []):
            variants.append(
                Variant(
                    id=v["id"],
                    name=v["name"],
                    description=v["description"],
                    status=v.get("status", "pending"),
                    branch=v.get("branch"),
                    worktree=v.get("worktree"),
                    prompt_path=v.get("prompt_path"),
                    model=v.get("model"),
                    added_at=v.get("added_at", utcnow_iso()),
                    records=[Record(**r) for r in v.get("records", [])],
                    scores=[Score(**s) for s in v.get("scores", [])],
                )
            )
        return cls(
            version=data["version"],
            run_id=data["run_id"],
            slug=data["slug"],
            goal=data["goal"],
            base_ref=data["base_ref"],
            base_sha=data["base_sha"],
            repo_path=data["repo_path"],
            created_at=data["created_at"],
            approved_at=data.get("approved_at"),
            locked_at=data.get("locked_at"),
            picked=data.get("picked"),
            merged_at=data.get("merged_at"),
            runner=data.get("runner"),
            model=data.get("model"),
            rubric=list(data.get("rubric") or DEFAULT_RUBRIC),
            variants=variants,
        )

    # ---------- lookup ----------

    def variant(self, variant_id: str) -> Variant:
        for v in self.variants:
            if v.id == variant_id:
                return v
        raise KeyError(f"no such variant: {variant_id}")

    def next_variant_id(self) -> str:
        return f"variant-{len(self.variants) + 1:02d}"


# ---------------------------------------------------------------------------
# IO
# ---------------------------------------------------------------------------


def save(manifest: Manifest) -> None:
    path = paths.manifest_path(manifest.slug, manifest.run_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(manifest.to_dict(), indent=2, sort_keys=False))
    os.replace(tmp, path)


def load(slug: str, run_id: str) -> Manifest:
    path = paths.manifest_path(slug, run_id)
    if not path.exists():
        raise FileNotFoundError(f"no manifest at {path}")
    data = json.loads(path.read_text())
    return Manifest.from_dict(data)


@contextlib.contextmanager
def locked_manifest(slug: str, run_id: str) -> Generator[Manifest, None, None]:
    """Context manager that holds an exclusive lock while reading/writing the manifest."""
    lock_path = paths.manifest_path(slug, run_id).with_suffix(".lock")
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    lock_fd = open(lock_path, "w")
    try:
        fcntl.flock(lock_fd, fcntl.LOCK_EX)
        manifest = load(slug, run_id)
        yield manifest
        save(manifest)
    finally:
        fcntl.flock(lock_fd, fcntl.LOCK_UN)
        lock_fd.close()


def list_for_repo(repo_path: str) -> list[Manifest]:
    """Return every manifest whose ``repo_path`` matches, ordered by creation.

    Skips malformed manifests silently — a corrupted run should not bring
    down commands that merely want to enumerate history.
    """
    runs_root = paths.state_root() / "runs"
    if not runs_root.exists():
        return []
    out: list[Manifest] = []
    for slug_dir in sorted(runs_root.iterdir()):
        if not slug_dir.is_dir():
            continue
        for run_dir in sorted(slug_dir.iterdir()):
            if not (run_dir / "manifest.json").exists():
                continue
            try:
                m = load(slug_dir.name, run_dir.name)
            except Exception:
                continue
            if m.repo_path == repo_path:
                out.append(m)
    out.sort(key=lambda m: m.created_at)
    return out


def append_event(manifest: Manifest, kind: str, **fields: Any) -> None:
    path = paths.events_path(manifest.slug, manifest.run_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    entry = {"at": utcnow_iso(), "kind": kind, **fields}
    with path.open("a") as fh:
        fh.write(json.dumps(entry) + "\n")


# ---------------------------------------------------------------------------
# Active-run pointer
#
# Keyed by absolute repo path so two repos can use the same slug without
# stepping on each other. Value is a (slug, run_id) pair identifying the
# currently-active run for that repo.
# ---------------------------------------------------------------------------


def load_active_map() -> dict[str, dict[str, str]]:
    path = paths.active_pointer()
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text())
    except json.JSONDecodeError:
        return {}
    if not isinstance(data, dict):
        return {}
    return data


def save_active_map(mapping: dict[str, dict[str, str]]) -> None:
    path = paths.active_pointer()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(mapping, indent=2))


def set_active(repo_path: str, slug: str, run_id: str) -> None:
    mapping = load_active_map()
    mapping[repo_path] = {"slug": slug, "run_id": run_id}
    save_active_map(mapping)


def get_active(repo_path: str) -> tuple[str, str] | None:
    entry = load_active_map().get(repo_path)
    if not entry:
        return None
    return entry["slug"], entry["run_id"]


def clear_active(repo_path: str) -> None:
    mapping = load_active_map()
    mapping.pop(repo_path, None)
    save_active_map(mapping)
