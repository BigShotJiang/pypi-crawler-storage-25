"""Thin wrapper around git commands. No magic, just subprocess.

Joust never calls git plumbing directly from the CLI layer; it goes through
these functions. That keeps test mocking trivial and surfaces error messages
consistently.
"""

from __future__ import annotations

import pathlib
import subprocess


class GitError(RuntimeError):
    pass


def _run(args: list[str], cwd: pathlib.Path | None = None) -> str:
    try:
        result = subprocess.run(
            ["git", *args],
            cwd=str(cwd) if cwd else None,
            check=True,
            capture_output=True,
            text=True,
        )
    except FileNotFoundError as exc:
        raise GitError("git is not installed or not on PATH") from exc
    except subprocess.CalledProcessError as exc:
        stderr = (exc.stderr or "").strip()
        raise GitError(f"git {' '.join(args)} failed: {stderr}") from exc
    return result.stdout.strip()


def toplevel(cwd: pathlib.Path | None = None) -> pathlib.Path:
    """Return the top-level directory of the current git repository.

    Note: for a linked worktree, this returns the worktree's own root, not
    the main repo. Use ``main_repo_toplevel`` when you want the canonical
    repo path (e.g. for keying the active-run pointer).
    """
    return pathlib.Path(_run(["rev-parse", "--show-toplevel"], cwd=cwd))


def main_repo_toplevel(cwd: pathlib.Path | None = None) -> pathlib.Path:
    """Return the main repo's top-level directory, even from a linked worktree.

    Uses ``git rev-parse --git-common-dir`` which always points at the main
    repo's ``.git`` directory regardless of whether we're in the main
    worktree or a linked one. The parent of that is the main repo root.
    """
    common = pathlib.Path(
        _run(["rev-parse", "--path-format=absolute", "--git-common-dir"], cwd=cwd)
    )
    # common is typically `<repo>/.git`; .parent is `<repo>`.
    # In the (rare) bare-repo case, common IS the repo, so .parent is fine too.
    return common.parent


def current_branch(cwd: pathlib.Path | None = None) -> str:
    return _run(["rev-parse", "--abbrev-ref", "HEAD"], cwd=cwd)


def rev_parse(ref: str, cwd: pathlib.Path | None = None) -> str:
    return _run(["rev-parse", ref], cwd=cwd)


def ref_exists(ref: str, cwd: pathlib.Path | None = None) -> bool:
    try:
        _run(["rev-parse", "--verify", "--quiet", ref], cwd=cwd)
        return True
    except GitError:
        return False


def add_worktree(
    repo: pathlib.Path,
    target: pathlib.Path,
    branch: str,
    base_sha: str,
) -> None:
    """Create a new worktree at ``target`` on a new branch ``branch`` from ``base_sha``."""
    target.parent.mkdir(parents=True, exist_ok=True)
    _run(
        ["worktree", "add", "-b", branch, str(target), base_sha],
        cwd=repo,
    )


def remove_worktree(repo: pathlib.Path, target: pathlib.Path, force: bool = False) -> None:
    args = ["worktree", "remove", str(target)]
    if force:
        args.insert(2, "--force")
    _run(args, cwd=repo)


def delete_branch(repo: pathlib.Path, branch: str, force: bool = False) -> None:
    _run(["branch", "-D" if force else "-d", branch], cwd=repo)


def worktree_prune(repo: pathlib.Path) -> None:
    _run(["worktree", "prune"], cwd=repo)


def checkout(repo: pathlib.Path, branch: str) -> None:
    _run(["checkout", branch], cwd=repo)


def merge_branch(repo: pathlib.Path, branch: str) -> None:
    """Merge branch into the currently checked-out branch."""
    _run(["merge", branch, "--no-edit"], cwd=repo)


def diff_stat(repo: pathlib.Path, base: str, head: str) -> str:
    """Return a short diff summary between two refs."""
    return _run(["diff", "--shortstat", f"{base}...{head}"], cwd=repo)


def changed_files(repo: pathlib.Path, base: str, head: str) -> list[str]:
    out = _run(["diff", "--name-only", f"{base}...{head}"], cwd=repo)
    return [line for line in out.splitlines() if line.strip()]
