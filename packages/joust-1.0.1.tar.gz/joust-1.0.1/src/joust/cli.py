"""Joust CLI entry point.

The ``--help`` text on this app IS the documentation for agents. A fresh
agent should be able to run ``joust --help`` followed by ``joust <cmd> --help``
and drive an entire run without reading the source.
"""

from __future__ import annotations

import json
import pathlib
import shutil
import sys
from importlib.metadata import PackageNotFoundError, version as _pkg_version
from typing import Optional

import typer

from . import doctor as doctor_mod
from . import gitops, paths, render, store


def _resolve_version() -> str:
    """Return the installed package version, or '0.0.0+unknown' if not installed."""
    try:
        return _pkg_version("joust")
    except PackageNotFoundError:
        return "0.0.0+unknown"


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"joust {_resolve_version()}")
        raise typer.Exit()

app = typer.Typer(
    name="joust",
    no_args_is_help=True,
    add_completion=False,
    help=(
        "Parallel prototype orchestrator for coding agents.\n\n"
        "Workflow:\n"
        "  1. joust init <slug> --goal '...'\n"
        "  2. joust scenarios add ... (or: joust scenarios suggest)\n"
        "  3. joust runner set --runner claude-code --model opus\n"
        "     joust runner override variant-02 --model haiku   # optional, per-variant\n"
        "  4. joust scenarios approve --yes   # HUMAN GATE 1\n"
        "  5. joust lock                  # materializes worktrees + prompts\n"
        "  6. Agents run in each worktree and call `joust record`\n"
        "  7. joust judge                 # prints rubric playbook\n"
        "  8. joust score <variant> ...   # one call per variant\n"
        "  9. joust compare               # human-readable table\n"
        " 10. joust pick <variant> --yes  # HUMAN GATE 2\n\n"
        "Joust never calls an LLM itself. It only manages worktrees, state, "
        "and prompts. Any agent runner (Claude Code, Codex, a shell script) "
        "can drive it."
    ),
)

scenarios_app = typer.Typer(
    name="scenarios",
    no_args_is_help=True,
    help="Add, list, remove, or brainstorm scenarios for the active run.",
)
app.add_typer(scenarios_app, name="scenarios")

runner_app = typer.Typer(
    name="runner",
    no_args_is_help=True,
    help="Declare which agent runner and model will drive the subagents.",
)
app.add_typer(runner_app, name="runner")

rubric_app = typer.Typer(
    name="rubric",
    no_args_is_help=True,
    help="Inspect the active run's rubric dimensions (set at `joust init`).",
)
app.add_typer(rubric_app, name="rubric")


@rubric_app.command("show")
def rubric_show() -> None:
    """Print the rubric dimensions for the active run, one per line."""
    _, manifest = _load_active(None, None)
    typer.echo("rubric:")
    for dim in manifest.rubric:
        typer.echo(f"  - {dim}")


@app.callback()
def _main(
    version: Optional[bool] = typer.Option(
        None,
        "--version",
        "-V",
        callback=_version_callback,
        is_eager=True,
        help="Print the joust version and exit.",
    ),
) -> None:
    """Root callback. Exists solely to host the --version flag."""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _ensure_gitignore_entry(gitignore: pathlib.Path, entry: str) -> None:
    """Append *entry* to *gitignore* if it isn't already present."""
    if gitignore.exists():
        content = gitignore.read_text()
        if entry in content.splitlines():
            return
        if not content.endswith("\n"):
            content += "\n"
    else:
        content = ""
    gitignore.write_text(content + entry + "\n")


def _repo_path() -> pathlib.Path:
    """Return the canonical main repo path, even when invoked from a worktree.

    Joust keys the active-run pointer by the main repo path so that commands
    run from inside a variant worktree (which git considers a different
    toplevel) still resolve to the same run.
    """
    try:
        return gitops.main_repo_toplevel()
    except gitops.GitError as exc:
        typer.echo(f"error: {exc}", err=True)
        raise typer.Exit(2)


def _resolve_active(
    slug: Optional[str], run_id: Optional[str]
) -> tuple[pathlib.Path, str, str]:
    repo = _repo_path()
    if slug and run_id:
        return repo, slug, run_id
    active = store.get_active(str(repo))
    if not active:
        typer.echo(
            "error: no active joust run for this repo. Start one with "
            "`joust init <slug> --goal ...` or pass --slug/--run-id.",
            err=True,
        )
        raise typer.Exit(2)
    a_slug, a_run = active
    return repo, slug or a_slug, run_id or a_run


def _load_active(
    slug: Optional[str], run_id: Optional[str]
) -> tuple[pathlib.Path, store.Manifest]:
    repo, s, r = _resolve_active(slug, run_id)
    try:
        manifest = store.load(s, r)
    except FileNotFoundError as exc:
        typer.echo(f"error: {exc}", err=True)
        raise typer.Exit(2)
    return repo, manifest


# ---------------------------------------------------------------------------
# init
# ---------------------------------------------------------------------------


@app.command()
def init(
    slug: str = typer.Argument(
        ...,
        help="Short human-readable name for this run, e.g. 'feature-search-v2'.",
    ),
    goal: str = typer.Option(
        ...,
        "--goal",
        help="One-paragraph description of the feature you're exploring.",
    ),
    base: str = typer.Option(
        "HEAD",
        "--base",
        help="Git ref to branch all variants from. Defaults to HEAD.",
    ),
    rubric: Optional[str] = typer.Option(
        None,
        "--rubric",
        help=(
            "Comma-separated rubric dimensions for `joust score` and the "
            "judge playbook. Defaults to "
            "'correctness,simplicity,fit,extensibility'."
        ),
    ),
) -> None:
    """Start a new run. Records the goal, base commit, and sets it active."""
    repo = _repo_path()
    if not gitops.ref_exists(base, cwd=repo):
        typer.echo(f"error: base ref '{base}' does not exist", err=True)
        raise typer.Exit(2)
    base_sha = gitops.rev_parse(base, cwd=repo)
    base_ref = base if base != "HEAD" else gitops.current_branch(cwd=repo)

    if rubric is not None:
        dims = [d.strip() for d in rubric.split(",") if d.strip()]
        if not dims:
            typer.echo(
                "error: --rubric must list at least one dimension",
                err=True,
            )
            raise typer.Exit(2)
        seen: set[str] = set()
        for d in dims:
            if d in seen:
                typer.echo(
                    f"error: duplicate rubric dimension '{d}'",
                    err=True,
                )
                raise typer.Exit(2)
            seen.add(d)
        rubric_list = dims
    else:
        rubric_list = list(store.DEFAULT_RUBRIC)

    run_id = store.new_run_id()
    manifest = store.Manifest(
        version=store.SCHEMA_VERSION,
        run_id=run_id,
        slug=slug,
        goal=goal,
        base_ref=base_ref,
        base_sha=base_sha,
        repo_path=str(repo),
        created_at=store.utcnow_iso(),
        rubric=rubric_list,
    )
    store.save(manifest)
    store.append_event(
        manifest,
        "init",
        goal=goal,
        base_ref=base_ref,
        base_sha=base_sha,
        rubric=rubric_list,
    )
    store.set_active(str(repo), slug, run_id)

    typer.echo(f"initialized run {slug}/{run_id}")
    typer.echo(f"  base:     {base_ref} @ {base_sha[:12]}")
    typer.echo(f"  state:    {paths.run_dir(slug, run_id)}")
    typer.echo("")
    typer.echo("next: add scenarios with `joust scenarios add <name> --description ...`")
    typer.echo("      or brainstorm with `joust scenarios suggest --count 3`")


# ---------------------------------------------------------------------------
# scenarios
# ---------------------------------------------------------------------------


@scenarios_app.command("add")
def scenarios_add(
    name: str = typer.Argument(..., help="Short kebab-case name, e.g. 'minimal-mvp'."),
    description: str = typer.Option(
        ...,
        "--description",
        "-d",
        help="1-3 sentence description of the angle this variant takes.",
    ),
) -> None:
    """Register a new scenario. Must be called before `joust lock`."""
    repo, slug, run_id = _resolve_active(None, None)
    with store.locked_manifest(slug, run_id) as manifest:
        if manifest.locked_at:
            typer.echo(
                "error: run is already locked; add scenarios before `joust lock`",
                err=True,
            )
            raise typer.Exit(2)
        if manifest.approved_at:
            typer.echo(
                "error: scenarios are already approved; `joust scenarios add` is blocked",
                err=True,
            )
            raise typer.Exit(2)
        existing = [v for v in manifest.variants if v.name == name]
        if existing:
            typer.echo(f"error: scenario name '{name}' already exists ({existing[0].id})", err=True)
            raise typer.Exit(2)
        variant = store.Variant(
            id=manifest.next_variant_id(),
            name=name,
            description=description,
        )
        manifest.variants.append(variant)
    store.append_event(
        manifest, "scenario_add", variant_id=variant.id, name=name, description=description
    )
    typer.echo(f"added {variant.id}  {name}")


@scenarios_app.command("list")
def scenarios_list() -> None:
    """List scenarios in the active run."""
    _, manifest = _load_active(None, None)
    if not manifest.variants:
        typer.echo("(no scenarios yet)")
        return
    for v in manifest.variants:
        typer.echo(f"{v.id}  [{v.status}]  {v.name}")
        typer.echo(f"    {v.description}")


@scenarios_app.command("remove")
def scenarios_remove(
    variant_id: str = typer.Argument(..., help="Variant id, e.g. 'variant-02'."),
) -> None:
    """Remove a scenario. Only works before `joust lock`."""
    repo, slug, run_id = _resolve_active(None, None)
    with store.locked_manifest(slug, run_id) as manifest:
        if manifest.locked_at:
            typer.echo("error: cannot remove after lock", err=True)
            raise typer.Exit(2)
        if manifest.approved_at:
            typer.echo(
                "error: scenarios are already approved; cannot remove", err=True
            )
            raise typer.Exit(2)
        before = len(manifest.variants)
        manifest.variants = [v for v in manifest.variants if v.id != variant_id]
        if len(manifest.variants) == before:
            typer.echo(f"error: no such variant: {variant_id}", err=True)
            raise typer.Exit(2)
    store.append_event(manifest, "scenario_remove", variant_id=variant_id)
    typer.echo(f"removed {variant_id}")


@scenarios_app.command("approve")
def scenarios_approve(
    confirm: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help="Required. Explicit confirmation that a human is approving.",
    ),
) -> None:
    """Human gate. Approves the scenario set before materializing worktrees.

    Refuses without ``--yes`` so an agent cannot silently lock a run with
    scenarios it made up. After approval, ``joust scenarios add/remove`` is
    blocked and ``joust lock`` is unblocked.
    """
    if not confirm:
        typer.echo(
            "error: `joust scenarios approve` is a human-only gate. Re-run with --yes.",
            err=True,
        )
        raise typer.Exit(2)
    _, slug, run_id = _resolve_active(None, None)
    with store.locked_manifest(slug, run_id) as manifest:
        if not manifest.variants:
            typer.echo("error: no scenarios to approve", err=True)
            raise typer.Exit(2)
        if manifest.approved_at:
            typer.echo(f"already approved at {manifest.approved_at}")
            return
        manifest.approved_at = store.utcnow_iso()
    store.append_event(
        manifest, "approve", variants=[v.id for v in manifest.variants]
    )
    typer.echo(f"approved {len(manifest.variants)} scenarios")
    for v in manifest.variants:
        typer.echo(f"  {v.id}  {v.name}")
    typer.echo("")
    typer.echo("next: `joust lock` to materialize worktrees")


@scenarios_app.command("suggest")
def scenarios_suggest(
    count: int = typer.Option(3, "--count", "-n", help="How many angles to brainstorm."),
) -> None:
    """Print a brainstorming playbook for the agent to fill in.

    Joust never calls an LLM. This command prints a static template; the
    calling agent reads it, thinks of `count` distinct angles, and runs
    `joust scenarios add` once per angle. When prior runs exist for this
    repo, the playbook also lists their slugs, goals, and picked variants
    so the agent can avoid reinventing angles that already lost.
    """
    repo, manifest = _load_active(None, None)
    prior_runs = [
        m for m in store.list_for_repo(str(repo))
        if m.run_id != manifest.run_id
    ]
    typer.echo(render.suggest_playbook(manifest.goal, count, prior_runs))


# ---------------------------------------------------------------------------
# runner
# ---------------------------------------------------------------------------


@runner_app.command("suggest")
def runner_suggest() -> None:
    """Print a playbook telling the agent to ask the user which model to use.

    Joust does not pick the runner or model itself. Read this output, ask
    the user the question verbatim (or close to it), then record the answer
    with `joust runner set`.
    """
    # Load to verify there's an active run, but we don't use the manifest.
    _load_active(None, None)
    typer.echo(render.runner_playbook())


@runner_app.command("set")
def runner_set(
    runner: str = typer.Option(
        ...,
        "--runner",
        help="Agent runner identifier, e.g. 'claude-code', 'codex', 'shell'.",
    ),
    model: str = typer.Option(
        ...,
        "--model",
        help="Model identifier as understood by the runner, e.g. 'opus'.",
    ),
) -> None:
    """Record the runner and model for the active run.

    Both fields are free text — joust does not validate them. Whatever you
    pass ends up in the manifest and in every variant's PROMPT.md.
    """
    _, slug, run_id = _resolve_active(None, None)
    with store.locked_manifest(slug, run_id) as manifest:
        if manifest.locked_at:
            typer.echo(
                "error: run is already locked; runner/model cannot be changed",
                err=True,
            )
            raise typer.Exit(2)
        manifest.runner = runner
        manifest.model = model
    store.append_event(manifest, "runner_set", runner=runner, model=model)
    typer.echo(f"runner: {runner}")
    typer.echo(f"model:  {model}")


@runner_app.command("override")
def runner_override(
    variant_id: str = typer.Argument(
        ..., help="Variant id whose model you want to override, e.g. 'variant-02'."
    ),
    model: str = typer.Option(
        ..., "--model", help="Model for this variant only (free text; not validated)."
    ),
) -> None:
    """Set a per-variant model, overriding the run-level default.

    Only overrides ``model``; the runner (e.g. ``claude-code``) always
    stays at the run level because you typically do not mix runners
    within a single run. Use this to run one variant on opus and another
    on haiku, for example. Must be called before `joust lock`.
    """
    _, slug, run_id = _resolve_active(None, None)
    with store.locked_manifest(slug, run_id) as manifest:
        if manifest.locked_at:
            typer.echo(
                "error: run is already locked; overrides cannot be changed",
                err=True,
            )
            raise typer.Exit(2)
        try:
            variant = manifest.variant(variant_id)
        except KeyError as exc:
            typer.echo(f"error: {exc}", err=True)
            raise typer.Exit(2)
        variant.model = model
    store.append_event(
        manifest, "runner_override", variant_id=variant_id, model=model
    )
    typer.echo(f"{variant_id}: model={model} (overrides run default)")


@runner_app.command("show")
def runner_show() -> None:
    """Print the active run's runner, default model, and any per-variant overrides."""
    _, manifest = _load_active(None, None)
    typer.echo(f"runner: {manifest.runner or '(unset)'}")
    typer.echo(f"model:  {manifest.model or '(unset)'}")
    overrides = [(v.id, v.model) for v in manifest.variants if v.model]
    if overrides:
        typer.echo("overrides:")
        for vid, m in overrides:
            typer.echo(f"  {vid}: {m}")


# ---------------------------------------------------------------------------
# lock
# ---------------------------------------------------------------------------


@app.command()
def lock() -> None:
    """Materialize worktrees and per-variant prompt files.

    Creates one git worktree per scenario under
    ``$JOUST_HOME/runs/<slug>/<run-id>/worktrees/<variant-id>`` on a new
    branch ``joust/<run-id>/<variant-id>`` rooted at the recorded base SHA.
    Writes a ``PROMPT.md`` into each worktree that the subagent should read
    as its task brief.

    After lock, scenarios cannot be added or removed.
    """
    repo, slug, run_id = _resolve_active(None, None)
    with store.locked_manifest(slug, run_id) as manifest:
        if manifest.locked_at:
            typer.echo("error: already locked", err=True)
            raise typer.Exit(2)
        if not manifest.variants:
            typer.echo("error: add at least one scenario before locking", err=True)
            raise typer.Exit(2)
        if not manifest.approved_at:
            typer.echo(
                "error: scenarios are not approved. A human must run "
                "`joust scenarios approve --yes` before locking.",
                err=True,
            )
            raise typer.Exit(2)

        total = len(manifest.variants)
        for variant in manifest.variants:
            branch = f"joust/{manifest.run_id}/{variant.id}"
            target = paths.variant_worktree(manifest.slug, manifest.run_id, variant.id)
            try:
                gitops.add_worktree(repo, target, branch, manifest.base_sha)
            except gitops.GitError as exc:
                typer.echo(f"error: {exc}", err=True)
                raise typer.Exit(2)
            variant.branch = branch
            variant.worktree = str(target)
            variant.status = "ready"
            prompt_path = target / "PROMPT.md"
            prompt_path.write_text(render.variant_prompt(manifest, variant, total))
            variant.prompt_path = str(prompt_path)
            # Ensure PROMPT.md is git-ignored so subagents doing `git add .`
            # don't commit joust infrastructure into the variant branch.
            gitignore_path = target / ".gitignore"
            _ensure_gitignore_entry(gitignore_path, "PROMPT.md")
            typer.echo(f"  {variant.id:12s}  {branch}  ->  {target}")

        manifest.locked_at = store.utcnow_iso()
    store.append_event(manifest, "lock", variants=len(manifest.variants))
    typer.echo("")
    typer.echo(f"locked {len(manifest.variants)} variants")
    if manifest.runner and manifest.model:
        typer.echo(f"runner:  {manifest.runner}  model: {manifest.model}")
    else:
        typer.echo(
            "warn: runner/model not set. Subagents will run with whatever "
            "default your driver picks. Use `joust runner suggest` next time."
        )
    typer.echo("next: dispatch one subagent per worktree. Each subagent should")
    typer.echo("      read PROMPT.md at its worktree root and call `joust record`")
    typer.echo("      when done.")


# ---------------------------------------------------------------------------
# list / status
# ---------------------------------------------------------------------------


@app.command("list")
def list_cmd() -> None:
    """Show variants in the active run as a table."""
    _, manifest = _load_active(None, None)
    if not manifest.variants:
        typer.echo("(no variants)")
        return
    typer.echo(render.list_table(manifest))


@app.command()
def status() -> None:
    """Show run-level status: goal, base, lock state, variant counts."""
    _, manifest = _load_active(None, None)
    counts: dict[str, int] = {}
    for v in manifest.variants:
        counts[v.status] = counts.get(v.status, 0) + 1
    typer.echo(f"run:      {manifest.slug}/{manifest.run_id}")
    typer.echo(f"goal:     {manifest.goal}")
    typer.echo(f"base:     {manifest.base_ref} @ {manifest.base_sha[:12]}")
    typer.echo(f"approved: {manifest.approved_at or 'no'}")
    typer.echo(f"locked:   {manifest.locked_at or 'no'}")
    typer.echo(f"runner:   {manifest.runner or '(unset)'}")
    typer.echo(f"model:    {manifest.model or '(unset)'}")
    typer.echo(f"picked:   {manifest.picked or 'no'}")
    typer.echo(f"variants: {len(manifest.variants)}")
    for state, n in sorted(counts.items()):
        typer.echo(f"  {state:12s} {n}")


# ---------------------------------------------------------------------------
# record
# ---------------------------------------------------------------------------


_RECORD_STATES = {"in_progress", "built", "failed"}


@app.command()
def record(
    variant_id: str = typer.Argument(..., help="Variant id, e.g. 'variant-01'."),
    status: Optional[str] = typer.Option(
        None,
        "--status",
        help="One of: in_progress, built, failed.",
    ),
    summary: Optional[str] = typer.Option(
        None,
        "--summary",
        help="1-2 sentences describing what was built or why it failed.",
    ),
    artifact: Optional[pathlib.Path] = typer.Option(
        None,
        "--artifact",
        exists=True,
        dir_okay=False,
        help="Optional evidence file to copy into the run's artifacts/ dir.",
    ),
) -> None:
    """Agent-facing progress report for a variant.

    Call this from inside a worktree (or anywhere) when the subagent finishes
    its implementation. You may call it multiple times; each call appends a
    record. The variant's status is set to the most recent non-empty status.
    """
    if status and status not in _RECORD_STATES:
        typer.echo(
            f"error: --status must be one of {sorted(_RECORD_STATES)}", err=True
        )
        raise typer.Exit(2)

    _, slug, run_id = _resolve_active(None, None)
    with store.locked_manifest(slug, run_id) as manifest:
        try:
            variant = manifest.variant(variant_id)
        except KeyError as exc:
            typer.echo(f"error: {exc}", err=True)
            raise typer.Exit(2)

        artifacts: list[str] = []
        if artifact:
            dest_dir = paths.artifacts_dir(manifest.slug, manifest.run_id, variant.id)
            dest_dir.mkdir(parents=True, exist_ok=True)
            dest = dest_dir / artifact.name
            shutil.copy2(artifact, dest)
            artifacts.append(str(dest))

        rec = store.Record(
            at=store.utcnow_iso(),
            status=status or variant.status,
            summary=summary or "",
            artifacts=artifacts,
        )
        variant.records.append(rec)
        if status:
            variant.status = status
    store.append_event(
        manifest,
        "record",
        variant_id=variant.id,
        status=rec.status,
        summary=rec.summary,
        artifacts=artifacts,
    )
    typer.echo(f"recorded {variant.id} -> {variant.status}")


# ---------------------------------------------------------------------------
# diff
# ---------------------------------------------------------------------------


@app.command()
def diff(
    variant_id: str = typer.Argument(..., help="Variant id, e.g. 'variant-01'."),
) -> None:
    """Show a human-readable diff summary for a variant vs. the base commit.

    Displays the variant name, list of changed files, and a shortstat summary.
    Requires the run to be locked first (so branches exist to diff against).
    """
    repo, manifest = _load_active(None, None)
    if not manifest.locked_at:
        typer.echo("error: run is not locked yet; run `joust lock` first", err=True)
        raise typer.Exit(2)
    try:
        variant = manifest.variant(variant_id)
    except KeyError as exc:
        typer.echo(f"error: {exc}", err=True)
        raise typer.Exit(2)
    if not variant.branch:
        typer.echo(
            f"error: variant {variant_id} has no branch (run not locked?)",
            err=True,
        )
        raise typer.Exit(2)

    files = gitops.changed_files(repo, manifest.base_sha, variant.branch)
    stat = gitops.diff_stat(repo, manifest.base_sha, variant.branch)

    typer.echo(f"variant: {variant.id}  ({variant.name})")
    if not files:
        typer.echo("no changes")
        return
    typer.echo("changed files:")
    for f in files:
        typer.echo(f"  {f}")
    typer.echo(stat)


# ---------------------------------------------------------------------------
# judge / score
# ---------------------------------------------------------------------------


@app.command()
def judge() -> None:
    """Print a judging playbook for the agent to work through.

    Refuses to run until every variant has been recorded as ``built`` or
    ``failed``. Like ``scenarios suggest``, this is a static template — the
    agent reads it and calls ``joust score`` for each variant.
    """
    _, manifest = _load_active(None, None)
    pending = [
        v for v in manifest.variants if v.status not in ("built", "failed", "judged")
    ]
    if pending:
        names = ", ".join(v.id for v in pending)
        typer.echo(
            f"error: these variants are not ready to judge: {names}", err=True
        )
        typer.echo(
            "       each variant must have `joust record --status built|failed` first",
            err=True,
        )
        raise typer.Exit(2)
    typer.echo(render.judge_playbook(manifest))


@app.command()
def score(
    variant_id: str = typer.Argument(...),
    correctness: Optional[int] = typer.Option(
        None, "--correctness", min=1, max=5,
        help="Legacy shortcut for default rubric's correctness dim.",
    ),
    simplicity: Optional[int] = typer.Option(
        None, "--simplicity", min=1, max=5,
        help="Legacy shortcut for default rubric's simplicity dim.",
    ),
    fit: Optional[int] = typer.Option(
        None, "--fit", min=1, max=5,
        help="Legacy shortcut for default rubric's fit dim.",
    ),
    extensibility: Optional[int] = typer.Option(
        None, "--extensibility", min=1, max=5,
        help="Legacy shortcut for default rubric's extensibility dim.",
    ),
    dim: list[str] = typer.Option(
        [], "--dim",
        help=(
            "Rubric dimension as name=value (1-5). Repeatable. Preferred "
            "over the legacy per-dimension flags. For custom rubrics "
            "(declared via `joust init --rubric ...`) this is the only form."
        ),
    ),
    rationale: str = typer.Option(
        ..., "--rationale", help="2-4 sentences explaining the scores."
    ),
    judge_name: str = typer.Option(
        "agent", "--judge", help="Identifier for who/what assigned the scores."
    ),
) -> None:
    """Attach rubric scores and a written rationale to a variant.

    Scores must cover exactly the run's declared rubric dimensions. Two
    equivalent input forms (for the default rubric):

        joust score variant-01 --correctness 4 --simplicity 5 \\
            --fit 5 --extensibility 2 --rationale "..."

        joust score variant-01 \\
            --dim correctness=4 --dim simplicity=5 \\
            --dim fit=5 --dim extensibility=2 --rationale "..."

    Custom rubrics must use the --dim form.
    """
    _, slug, run_id = _resolve_active(None, None)
    with store.locked_manifest(slug, run_id) as manifest:
        try:
            variant = manifest.variant(variant_id)
        except KeyError as exc:
            typer.echo(f"error: {exc}", err=True)
            raise typer.Exit(2)

        dims = _collect_score_dims(
            manifest.rubric,
            legacy={
                "correctness": correctness,
                "simplicity": simplicity,
                "fit": fit,
                "extensibility": extensibility,
            },
            dim_entries=dim,
        )

        s = store.Score(
            at=store.utcnow_iso(),
            judge=judge_name,
            dimensions=dims,
            rationale=rationale,
        )
        variant.scores.append(s)
        if variant.status in ("built", "failed"):
            variant.status = "judged"
    store.append_event(
        manifest,
        "score",
        variant_id=variant.id,
        judge=judge_name,
        dimensions=dims,
        total=s.total,
    )
    typer.echo(f"scored {variant.id}: total={s.total} by {judge_name}")


def _collect_score_dims(
    rubric: list[str],
    legacy: dict[str, Optional[int]],
    dim_entries: list[str],
) -> dict[str, int]:
    """Merge --dim entries and legacy per-dim flags into a validated dict.

    Rules:
      - The resulting keys must equal ``rubric`` exactly.
      - Legacy flags are only honored when the rubric contains that name
        (i.e. the default 4-dim rubric). Legacy flags set against a custom
        rubric are an error.
      - --dim name=value entries: value must parse as an int in [1, 5].
      - Duplicate --dim entries for the same key are an error (no silent
        last-write-wins).
    """
    collected: dict[str, int] = {}

    for entry in dim_entries:
        if "=" not in entry:
            typer.echo(
                f"error: --dim must be name=value, got {entry!r}",
                err=True,
            )
            raise typer.Exit(2)
        name, _, raw = entry.partition("=")
        name = name.strip()
        raw = raw.strip()
        if not name:
            typer.echo("error: --dim name is empty", err=True)
            raise typer.Exit(2)
        try:
            value = int(raw)
        except ValueError:
            typer.echo(
                f"error: --dim {name}={raw!r} is not an integer",
                err=True,
            )
            raise typer.Exit(2)
        if not 1 <= value <= 5:
            typer.echo(
                f"error: --dim {name}={value} out of range [1, 5]",
                err=True,
            )
            raise typer.Exit(2)
        if name in collected:
            typer.echo(
                f"error: --dim {name} specified more than once",
                err=True,
            )
            raise typer.Exit(2)
        collected[name] = value

    for name, val in legacy.items():
        if val is None:
            continue
        if name not in rubric:
            typer.echo(
                f"error: --{name} is a legacy flag for the default rubric; "
                f"this run's rubric is {rubric!r}. Use --dim instead.",
                err=True,
            )
            raise typer.Exit(2)
        if name in collected:
            typer.echo(
                f"error: --{name} and --dim {name} both specified",
                err=True,
            )
            raise typer.Exit(2)
        collected[name] = val

    extra = sorted(set(collected) - set(rubric))
    missing = sorted(set(rubric) - set(collected))
    if extra:
        typer.echo(
            f"error: unknown rubric dim(s): {', '.join(extra)}. "
            f"This run's rubric is {rubric!r}.",
            err=True,
        )
        raise typer.Exit(2)
    if missing:
        typer.echo(
            f"error: missing rubric dim(s): {', '.join(missing)}. "
            f"Provide all of {rubric!r}.",
            err=True,
        )
        raise typer.Exit(2)
    return collected


# ---------------------------------------------------------------------------
# compare
# ---------------------------------------------------------------------------


@app.command()
def compare() -> None:
    """Render a comparison table of every variant with its latest score."""
    _, manifest = _load_active(None, None)
    if not manifest.variants:
        typer.echo("(no variants)")
        return
    typer.echo(render.compare_table(manifest))


# ---------------------------------------------------------------------------
# pick
# ---------------------------------------------------------------------------


@app.command()
def pick(
    variant_id: str = typer.Argument(..., help="Variant id to mark as the winner."),
    confirm: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help="Required. Explicit confirmation that a human is running this command.",
    ),
) -> None:
    """Completion gate. Marks a variant as picked. Humans only.

    Joust refuses to run this without ``--yes`` so that a subagent cannot
    silently declare a winner. The user is the final arbiter.
    """
    if not confirm:
        typer.echo(
            "error: `joust pick` is a human-only gate. Re-run with --yes.",
            err=True,
        )
        raise typer.Exit(2)
    _, slug, run_id = _resolve_active(None, None)
    with store.locked_manifest(slug, run_id) as manifest:
        try:
            variant = manifest.variant(variant_id)
        except KeyError as exc:
            typer.echo(f"error: {exc}", err=True)
            raise typer.Exit(2)
        manifest.picked = variant.id
        variant.status = "picked"
    store.append_event(manifest, "pick", variant_id=variant.id)
    typer.echo(f"picked {variant.id} ({variant.name})")
    typer.echo(f"  branch:   {variant.branch}")
    typer.echo(f"  worktree: {variant.worktree}")
    typer.echo("")
    typer.echo("To merge the winner into your working branch:")
    typer.echo(f"  git merge {variant.branch}")
    typer.echo("Then run `joust archive --prune` to clean up the losing branches.")


# ---------------------------------------------------------------------------
# archive
# ---------------------------------------------------------------------------


@app.command()
def archive(
    prune: bool = typer.Option(
        False,
        "--prune",
        help="Also delete the losing git branches. Destructive.",
    ),
) -> None:
    """Remove losing worktrees. With --prune, also deletes losing branches.

    The picked variant (if any) is left alone. Runs with no pick will archive
    every variant.
    """
    repo, slug, run_id = _resolve_active(None, None)
    with store.locked_manifest(slug, run_id) as manifest:
        keep = manifest.picked
        removed: list[str] = []
        for v in manifest.variants:
            if v.id == keep:
                continue
            if v.worktree and pathlib.Path(v.worktree).exists():
                try:
                    gitops.remove_worktree(repo, pathlib.Path(v.worktree), force=True)
                except gitops.GitError as exc:
                    typer.echo(f"warn: {exc}", err=True)
            if prune and v.branch:
                try:
                    gitops.delete_branch(repo, v.branch, force=True)
                except gitops.GitError as exc:
                    typer.echo(f"warn: {exc}", err=True)
            v.status = "archived"
            removed.append(v.id)
        try:
            gitops.worktree_prune(repo)
        except gitops.GitError:
            pass
    store.append_event(manifest, "archive", variants=removed, pruned=prune)
    typer.echo(f"archived {len(removed)} variants")


# ---------------------------------------------------------------------------
# merge
# ---------------------------------------------------------------------------


@app.command()
def merge(
    confirm: bool = typer.Option(False, "--yes", "-y", help="Required. Explicit confirmation."),
) -> None:
    """Merge the picked variant's branch into the base branch. Humans only.

    After ``joust pick``, this command checks out the base branch, merges
    the winning variant's branch, records a ``merge`` event, and sets
    ``manifest.merged_at``.  Requires ``--yes`` as a human gate.
    """
    if not confirm:
        typer.echo(
            "error: `joust merge` is a human-only gate. Re-run with --yes.",
            err=True,
        )
        raise typer.Exit(2)
    repo, slug, run_id = _resolve_active(None, None)
    with store.locked_manifest(slug, run_id) as manifest:
        if not manifest.picked:
            typer.echo(
                "error: no variant has been picked yet. Run `joust pick <variant> --yes` first.",
                err=True,
            )
            raise typer.Exit(2)
        variant = manifest.variant(manifest.picked)
        try:
            gitops.checkout(repo, manifest.base_ref)
            gitops.merge_branch(repo, variant.branch)
        except gitops.GitError as exc:
            typer.echo(f"error: {exc}", err=True)
            raise typer.Exit(2)
        manifest.merged_at = store.utcnow_iso()
    store.append_event(
        manifest,
        "merge",
        variant_id=variant.id,
        branch=variant.branch,
        base_ref=manifest.base_ref,
    )
    typer.echo(f"merged {variant.id} ({variant.name}) into {manifest.base_ref}")


# ---------------------------------------------------------------------------
# housekeeping: use / runs / report
# ---------------------------------------------------------------------------


@app.command()
def use(
    slug: str = typer.Argument(..., help="Run slug."),
    run_id: str = typer.Argument(..., help="Run id."),
) -> None:
    """Set the active run for the current repo."""
    repo = _repo_path()
    try:
        store.load(slug, run_id)
    except FileNotFoundError as exc:
        typer.echo(f"error: {exc}", err=True)
        raise typer.Exit(2)
    store.set_active(str(repo), slug, run_id)
    typer.echo(f"active: {slug}/{run_id}")


@app.command()
def runs() -> None:
    """List runs for the current repo (by inspecting each manifest)."""
    repo = _repo_path()
    runs_root = paths.state_root() / "runs"
    if not runs_root.exists():
        typer.echo("(no runs)")
        return
    active = store.get_active(str(repo))
    found = False
    for slug_dir in sorted(runs_root.iterdir()):
        if not slug_dir.is_dir():
            continue
        for run_dir in sorted(slug_dir.iterdir()):
            manifest_file = run_dir / "manifest.json"
            if not manifest_file.exists():
                continue
            try:
                m = store.load(slug_dir.name, run_dir.name)
            except Exception:
                continue
            if m.repo_path != str(repo):
                continue
            marker = "*" if active and active == (m.slug, m.run_id) else " "
            typer.echo(f"{marker} {m.slug}/{m.run_id}  [{m.locked_at and 'locked' or 'open'}]  {m.goal[:60]}")
            found = True
    if not found:
        typer.echo("(no runs for this repo)")


@app.command()
def doctor(
    fix: bool = typer.Option(
        False,
        "--fix",
        help="Attempt to fix each detected issue. Destructive for orphan branches.",
    ),
) -> None:
    """Diagnose drift between joust state, git, and the filesystem.

    Checks for stale active pointers, missing variant worktrees, and orphan
    joust branches. Exits 0 if healthy, non-zero if issues were found. With
    --fix, runs each issue's automatic cleanup where available and re-runs
    the diagnosis, so you get an exit code that reflects the post-fix state.

    Example:

        joust doctor              # report only
        joust doctor --fix        # report and clean up orphan branches etc.
    """
    repo = _repo_path()
    issues = doctor_mod.diagnose(repo)
    if not issues:
        typer.echo("healthy: no issues found")
        return

    for issue in issues:
        marker = "fixable" if issue.fixable else "no auto-fix"
        typer.echo(f"  [{issue.kind}] ({marker}) {issue.message}")

    if not fix:
        typer.echo("")
        typer.echo(f"{len(issues)} issue(s) found. Run `joust doctor --fix` to clean up.")
        raise typer.Exit(1)

    fixed, skipped = doctor_mod.apply_fixes(issues)
    typer.echo("")
    typer.echo(f"fixed {fixed} issue(s), {skipped} left alone (no auto-fix)")
    # Re-diagnose so the exit code reflects reality.
    remaining = doctor_mod.diagnose(repo)
    if remaining:
        typer.echo(f"{len(remaining)} issue(s) still present after fix")
        raise typer.Exit(1)


@app.command()
def report() -> None:
    """Print filesystem paths for the active run (manifest, events, worktrees)."""
    _, manifest = _load_active(None, None)
    rd = paths.run_dir(manifest.slug, manifest.run_id)
    typer.echo(f"run dir:  {rd}")
    typer.echo(f"manifest: {paths.manifest_path(manifest.slug, manifest.run_id)}")
    typer.echo(f"events:   {paths.events_path(manifest.slug, manifest.run_id)}")
    typer.echo(f"worktrees:")
    for v in manifest.variants:
        typer.echo(f"  {v.id}  {v.worktree or '(not locked)'}")


# ---------------------------------------------------------------------------
# log
# ---------------------------------------------------------------------------


@app.command("log")
def log_cmd(
    last: Optional[int] = typer.Option(None, "--last", "-n", help="Show only the last N events."),
    json_output: bool = typer.Option(False, "--json", help="Print raw JSON lines."),
) -> None:
    """Print the event log for the active run in a human-readable format.

    Each event shows its timestamp, kind, and any notable extra fields.
    Use ``--json`` to get raw JSON lines (useful for piping/debugging).
    Use ``--last N`` to see only the most recent N events.
    """
    _, manifest = _load_active(None, None)
    events_file = paths.events_path(manifest.slug, manifest.run_id)
    if not events_file.exists():
        typer.echo("(no events)")
        return

    raw_lines = events_file.read_text().splitlines()
    events = []
    for line in raw_lines:
        line = line.strip()
        if not line:
            continue
        events.append(json.loads(line))

    if not events:
        typer.echo("(no events)")
        return

    if last is not None:
        events = events[-last:]

    skip_keys = {"at", "kind"}
    for ev in events:
        if json_output:
            typer.echo(json.dumps(ev))
        else:
            at = ev.get("at", "")
            kind = ev.get("kind", "")
            extras = {k: v for k, v in ev.items() if k not in skip_keys}
            extra_str = "  ".join(f'{k}="{v}"' if isinstance(v, str) else f"{k}={v}" for k, v in extras.items())
            parts = [f"[{at}]", f" {kind}"]
            if extra_str:
                parts.append(f"  {extra_str}")
            typer.echo("".join(parts))


if __name__ == "__main__":
    app()
