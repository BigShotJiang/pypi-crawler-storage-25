"""End-to-end smoke test for the joust CLI.

Creates a throwaway git repo + JOUST_HOME in tmp, then runs the full pipeline
via typer's CliRunner: init -> scenarios add -> lock -> record -> score ->
compare -> pick -> archive. Asserts the final manifest state matches.
"""

from __future__ import annotations

import json
import os
import pathlib
import shutil
import subprocess

import pytest
from typer.testing import CliRunner

from joust.cli import app
from joust import paths, render, store


def _git(*args: str, cwd: pathlib.Path) -> None:
    subprocess.run(
        ["git", "-c", "commit.gpgsign=false", *args],
        cwd=str(cwd),
        check=True,
        capture_output=True,
    )


@pytest.fixture
def repo(tmp_path: pathlib.Path, monkeypatch: pytest.MonkeyPatch) -> pathlib.Path:
    """Isolated git repo + JOUST_HOME, with cwd set inside the repo."""
    joust_home = tmp_path / "joust-home"
    monkeypatch.setenv("JOUST_HOME", str(joust_home))

    repo_dir = tmp_path / "repo"
    repo_dir.mkdir()
    _git("init", "-q", cwd=repo_dir)
    _git("config", "user.email", "test@example.com", cwd=repo_dir)
    _git("config", "user.name", "test", cwd=repo_dir)
    (repo_dir / "README.md").write_text("hello\n")
    _git("add", ".", cwd=repo_dir)
    _git("commit", "-q", "-m", "init", cwd=repo_dir)

    monkeypatch.chdir(repo_dir)
    return repo_dir


def test_version_flag_prints_package_version() -> None:
    """`joust --version` prints the installed package version and exits 0.

    The assertion keys on ``importlib.metadata.version("joust")`` so the
    test stays correct when the version is bumped in pyproject.toml.
    """
    from importlib.metadata import version as pkg_version

    runner = CliRunner()
    r = runner.invoke(app, ["--version"])
    assert r.exit_code == 0, r.output
    expected = pkg_version("joust")
    assert expected in r.output, (
        f"expected version {expected!r} in output: {r.output!r}"
    )


def test_full_workflow(repo: pathlib.Path) -> None:
    runner = CliRunner()

    r = runner.invoke(app, ["init", "feat", "--goal", "Explore feature X"])
    assert r.exit_code == 0, r.output
    assert "initialized run feat" in r.output

    for name, desc in [
        ("minimal", "Smallest viable implementation"),
        ("power", "Exposes every config surface"),
        ("opinionated", "No config, strong defaults"),
    ]:
        r = runner.invoke(app, ["scenarios", "add", name, "-d", desc])
        assert r.exit_code == 0, r.output

    r = runner.invoke(app, ["scenarios", "list"])
    assert r.exit_code == 0
    assert "variant-01" in r.output and "variant-03" in r.output

    # lock must refuse before approval
    r = runner.invoke(app, ["lock"])
    assert r.exit_code != 0
    assert "not approved" in r.output

    # approve requires --yes
    r = runner.invoke(app, ["scenarios", "approve"])
    assert r.exit_code != 0
    assert "human-only gate" in r.output

    r = runner.invoke(app, ["scenarios", "approve", "--yes"])
    assert r.exit_code == 0, r.output
    assert "approved 3 scenarios" in r.output

    r = runner.invoke(app, ["lock"])
    assert r.exit_code == 0, r.output
    assert "locked 3 variants" in r.output

    # PROMPT.md and worktrees should exist
    for variant_id in ("variant-01", "variant-02", "variant-03"):
        active = store.get_active(str(repo))
        assert active is not None
        slug, run_id = active
        wt = paths.variant_worktree(slug, run_id, variant_id)
        assert wt.exists(), f"missing worktree: {wt}"
        assert (wt / "PROMPT.md").exists()

    # Record progress
    r = runner.invoke(
        app, ["record", "variant-01", "--status", "built", "--summary", "ok"]
    )
    assert r.exit_code == 0, r.output
    r = runner.invoke(
        app, ["record", "variant-02", "--status", "built", "--summary", "ok"]
    )
    assert r.exit_code == 0
    r = runner.invoke(
        app, ["record", "variant-03", "--status", "failed", "--summary", "blocked"]
    )
    assert r.exit_code == 0

    # judge should now succeed because all variants are built/failed
    r = runner.invoke(app, ["judge"])
    assert r.exit_code == 0, r.output
    assert "Joust judgment" in r.output

    # Score each variant
    for vid, correctness in [("variant-01", 4), ("variant-02", 5), ("variant-03", 1)]:
        r = runner.invoke(
            app,
            [
                "score",
                vid,
                "--correctness", str(correctness),
                "--simplicity", "3",
                "--fit", "3",
                "--extensibility", "3",
                "--rationale", "ok",
            ],
        )
        assert r.exit_code == 0, r.output

    r = runner.invoke(app, ["compare"])
    assert r.exit_code == 0
    assert "TOTAL" in r.output and "variant-01" in r.output

    # pick requires --yes
    r = runner.invoke(app, ["pick", "variant-01"])
    assert r.exit_code != 0
    assert "human-only gate" in r.output

    r = runner.invoke(app, ["pick", "variant-01", "--yes"])
    assert r.exit_code == 0, r.output

    # archive losers
    r = runner.invoke(app, ["archive", "--prune"])
    assert r.exit_code == 0, r.output
    assert "archived 2 variants" in r.output

    # winner's worktree should still exist
    active = store.get_active(str(repo))
    assert active is not None
    slug, run_id = active
    winner_wt = paths.variant_worktree(slug, run_id, "variant-01")
    assert winner_wt.exists()
    loser_wt = paths.variant_worktree(slug, run_id, "variant-02")
    assert not loser_wt.exists()

    # manifest should reflect final state
    m = store.load(slug, run_id)
    assert m.picked == "variant-01"
    assert m.variant("variant-01").status == "picked"
    assert m.variant("variant-02").status == "archived"

    # events.jsonl should contain the full timeline
    events_file = paths.events_path(slug, run_id)
    assert events_file.exists()
    events = [json.loads(line) for line in events_file.read_text().splitlines()]
    kinds = [e["kind"] for e in events]
    assert kinds[0] == "init"
    assert "lock" in kinds
    assert "pick" in kinds
    assert "archive" in kinds


def test_lock_refuses_without_scenarios(repo: pathlib.Path) -> None:
    runner = CliRunner()
    r = runner.invoke(app, ["init", "feat", "--goal", "x"])
    assert r.exit_code == 0
    r = runner.invoke(app, ["lock"])
    assert r.exit_code != 0
    assert "at least one scenario" in r.output


def test_judge_refuses_before_record(repo: pathlib.Path) -> None:
    runner = CliRunner()
    runner.invoke(app, ["init", "feat", "--goal", "x"])
    runner.invoke(app, ["scenarios", "add", "a", "-d", "first"])
    runner.invoke(app, ["scenarios", "approve", "--yes"])
    runner.invoke(app, ["lock"])
    r = runner.invoke(app, ["judge"])
    assert r.exit_code != 0
    assert "not ready to judge" in r.output


def test_doctor_reports_healthy_after_init(repo: pathlib.Path) -> None:
    runner = CliRunner()
    runner.invoke(app, ["init", "feat", "--goal", "x"])
    runner.invoke(app, ["scenarios", "add", "one", "-d", "first"])
    runner.invoke(app, ["scenarios", "approve", "--yes"])
    runner.invoke(app, ["lock"])
    r = runner.invoke(app, ["doctor"])
    assert r.exit_code == 0, r.output
    assert "healthy" in r.output.lower()


def test_doctor_detects_and_fixes_stale_active_pointer(
    repo: pathlib.Path,
) -> None:
    """If a user `rm -rf`s the run dir, the active pointer goes stale.
    doctor should report it non-zero; doctor --fix should clear it."""
    runner = CliRunner()
    runner.invoke(app, ["init", "feat", "--goal", "x"])
    active = store.get_active(str(repo))
    assert active is not None
    slug, run_id = active
    # Vandalize state
    shutil.rmtree(paths.run_dir(slug, run_id))

    r = runner.invoke(app, ["doctor"])
    assert r.exit_code != 0
    assert "stale" in r.output.lower() or "missing" in r.output.lower()

    r = runner.invoke(app, ["doctor", "--fix"])
    assert r.exit_code == 0, r.output
    assert store.get_active(str(repo)) is None

    # Now doctor is green again
    r = runner.invoke(app, ["doctor"])
    assert r.exit_code == 0


def test_doctor_detects_and_fixes_orphan_joust_branches(
    repo: pathlib.Path,
) -> None:
    """A branch matching joust/<run-id>/variant-* that isn't referenced by
    any manifest is an orphan (e.g. from an aborted run). doctor --fix
    should delete it."""
    runner = CliRunner()
    runner.invoke(app, ["init", "feat", "--goal", "x"])
    runner.invoke(app, ["scenarios", "add", "one", "-d", "first"])
    runner.invoke(app, ["scenarios", "approve", "--yes"])
    runner.invoke(app, ["lock"])

    # Create a dangling branch for a fake run id
    subprocess.run(
        ["git", "-c", "commit.gpgsign=false", "branch",
         "joust/fakerun/variant-99", "HEAD"],
        cwd=str(repo),
        check=True,
    )

    r = runner.invoke(app, ["doctor"])
    assert r.exit_code != 0
    assert "orphan" in r.output.lower()
    assert "fakerun" in r.output

    r = runner.invoke(app, ["doctor", "--fix"])
    assert r.exit_code == 0, r.output

    result = subprocess.run(
        ["git", "branch", "--list", "joust/fakerun/variant-99"],
        cwd=str(repo),
        capture_output=True,
        text=True,
        check=True,
    )
    assert result.stdout.strip() == "", "orphan branch should be deleted"


def test_per_variant_model_override(repo: pathlib.Path) -> None:
    """A variant-level model override beats the run-level default and shows
    up in that variant's PROMPT.md. Other variants inherit the default."""
    runner = CliRunner()
    runner.invoke(app, ["init", "feat", "--goal", "x"])
    runner.invoke(app, ["scenarios", "add", "one", "-d", "first angle"])
    runner.invoke(app, ["scenarios", "add", "two", "-d", "second angle"])
    runner.invoke(
        app, ["runner", "set", "--runner", "claude-code", "--model", "opus"]
    )

    r = runner.invoke(
        app, ["runner", "override", "variant-02", "--model", "sonnet"]
    )
    assert r.exit_code == 0, r.output
    assert "variant-02" in r.output and "sonnet" in r.output

    runner.invoke(app, ["scenarios", "approve", "--yes"])
    runner.invoke(app, ["lock"])

    active = store.get_active(str(repo))
    assert active is not None
    slug, run_id = active
    p1 = (paths.variant_worktree(slug, run_id, "variant-01") / "PROMPT.md").read_text()
    p2 = (paths.variant_worktree(slug, run_id, "variant-02") / "PROMPT.md").read_text()
    assert "Model:     opus" in p1, "variant-01 should inherit the run-level model"
    assert "Model:     sonnet" in p2, "variant-02 should use its override"

    # `runner show` should list overrides
    r = runner.invoke(app, ["runner", "show"])
    assert r.exit_code == 0
    assert "overrides" in r.output
    assert "variant-02" in r.output and "sonnet" in r.output


def test_runner_set_and_prompt_includes_model(repo: pathlib.Path) -> None:
    runner = CliRunner()
    runner.invoke(app, ["init", "feat", "--goal", "x"])
    runner.invoke(app, ["scenarios", "add", "one", "-d", "first angle"])

    # Record runner choice before locking
    r = runner.invoke(
        app, ["runner", "set", "--runner", "claude-code", "--model", "opus"]
    )
    assert r.exit_code == 0, r.output
    assert "runner: claude-code" in r.output
    assert "model:  opus" in r.output

    # `runner suggest` prints its playbook
    r = runner.invoke(app, ["runner", "suggest"])
    assert r.exit_code == 0
    assert "Joust runner selection" in r.output

    runner.invoke(app, ["scenarios", "approve", "--yes"])
    r = runner.invoke(app, ["lock"])
    assert r.exit_code == 0, r.output
    assert "runner:  claude-code" in r.output

    # PROMPT.md should include the runner + model lines
    active = store.get_active(str(repo))
    assert active is not None
    slug, run_id = active
    prompt_file = paths.variant_worktree(slug, run_id, "variant-01") / "PROMPT.md"
    prompt_text = prompt_file.read_text()
    assert "Runner:    claude-code" in prompt_text
    assert "Model:     opus" in prompt_text


def test_lock_warns_when_runner_unset(repo: pathlib.Path) -> None:
    runner = CliRunner()
    runner.invoke(app, ["init", "feat", "--goal", "x"])
    runner.invoke(app, ["scenarios", "add", "one", "-d", "first angle"])
    runner.invoke(app, ["scenarios", "approve", "--yes"])
    r = runner.invoke(app, ["lock"])
    assert r.exit_code == 0
    assert "warn: runner/model not set" in r.output


def test_record_from_inside_worktree(
    repo: pathlib.Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Regression: `joust record` called from inside a linked worktree must
    resolve to the same active run as `joust record` called from the main
    repo. Git considers the worktree a different toplevel, so joust keys
    the active pointer on the main-repo path (via --git-common-dir)."""
    runner = CliRunner()
    runner.invoke(app, ["init", "feat", "--goal", "x"])
    runner.invoke(app, ["scenarios", "add", "one", "-d", "only variant"])
    runner.invoke(app, ["scenarios", "approve", "--yes"])
    runner.invoke(app, ["lock"])

    active = store.get_active(str(repo))
    assert active is not None
    slug, run_id = active
    wt = paths.variant_worktree(slug, run_id, "variant-01")
    assert wt.exists()

    # Cd into the worktree and record — this used to fail because the
    # worktree has its own `git rev-parse --show-toplevel`.
    monkeypatch.chdir(wt)
    r = runner.invoke(
        app, ["record", "variant-01", "--status", "built", "--summary", "from wt"]
    )
    assert r.exit_code == 0, r.output
    assert "recorded variant-01 -> built" in r.output

    m = store.load(slug, run_id)
    v = m.variant("variant-01")
    assert v.status == "built"
    assert v.latest_record().summary == "from wt"


def test_suggest_playbook_mentions_approve(repo: pathlib.Path) -> None:
    """The suggest playbook must mention `joust scenarios approve --yes` so
    agents following it don't skip the human gate before locking."""
    runner = CliRunner()
    runner.invoke(app, ["init", "feat", "--goal", "x"])
    r = runner.invoke(app, ["scenarios", "suggest"])
    assert r.exit_code == 0
    assert "scenarios approve" in r.output, (
        "suggest playbook must mention the approval step"
    )


def test_suggest_playbook_lists_prior_runs(repo: pathlib.Path) -> None:
    """When prior runs exist for this repo, `scenarios suggest` must surface
    their slug, goal, and picked variant so the agent can avoid reinventing
    angles that have already been tried."""
    runner = CliRunner()
    # First run: complete it end-to-end so there's a picked variant
    runner.invoke(app, ["init", "feat-rate-limit", "--goal", "Add rate limiting"])
    runner.invoke(app, ["scenarios", "add", "token-bucket", "-d", "first"])
    runner.invoke(app, ["scenarios", "add", "sliding-window", "-d", "second"])
    runner.invoke(app, ["scenarios", "approve", "--yes"])
    runner.invoke(app, ["lock"])
    runner.invoke(
        app, ["record", "variant-01", "--status", "built", "--summary", "ok"]
    )
    runner.invoke(
        app, ["record", "variant-02", "--status", "built", "--summary", "ok"]
    )
    for vid in ("variant-01", "variant-02"):
        runner.invoke(
            app,
            [
                "score", vid,
                "--correctness", "4", "--simplicity", "4",
                "--fit", "4", "--extensibility", "4",
                "--rationale", "ok",
            ],
        )
    runner.invoke(app, ["pick", "variant-01", "--yes"])

    # Second run: suggest should list the first as a prior
    runner.invoke(app, ["init", "feat-cache", "--goal", "Add caching"])
    r = runner.invoke(app, ["scenarios", "suggest"])
    assert r.exit_code == 0, r.output
    assert "feat-rate-limit" in r.output, (
        f"expected prior run slug in output:\n{r.output}"
    )
    assert "Add rate limiting" in r.output, (
        f"expected prior run goal in output:\n{r.output}"
    )
    # The picked variant (token-bucket / variant-01) should be identifiable
    assert "token-bucket" in r.output or "variant-01" in r.output, (
        f"expected picked variant identity in output:\n{r.output}"
    )


def test_rubric_defaults_to_four_standard_dimensions(repo: pathlib.Path) -> None:
    """Without --rubric, a run inherits the historical 4-dim rubric so
    every test predating customization keeps working unchanged."""
    runner = CliRunner()
    r = runner.invoke(app, ["init", "feat", "--goal", "x"])
    assert r.exit_code == 0, r.output
    slug, run_id = store.get_active(str(repo))
    m = store.load(slug, run_id)
    assert m.rubric == ["correctness", "simplicity", "fit", "extensibility"]


def test_init_rubric_sets_custom_dimensions(repo: pathlib.Path) -> None:
    """`joust init --rubric a,b,c` stores the dimensions on the manifest."""
    runner = CliRunner()
    r = runner.invoke(
        app, ["init", "feat", "--goal", "x", "--rubric", "speed,readability"]
    )
    assert r.exit_code == 0, r.output
    slug, run_id = store.get_active(str(repo))
    m = store.load(slug, run_id)
    assert m.rubric == ["speed", "readability"]


def test_rubric_show_prints_dimensions(repo: pathlib.Path) -> None:
    """`joust rubric show` prints the current run's rubric one per line."""
    runner = CliRunner()
    runner.invoke(
        app, ["init", "feat", "--goal", "x", "--rubric", "speed,readability,ops"]
    )
    r = runner.invoke(app, ["rubric", "show"])
    assert r.exit_code == 0, r.output
    for dim in ("speed", "readability", "ops"):
        assert dim in r.output, f"expected {dim} in output:\n{r.output}"


def test_judge_playbook_templates_from_rubric(repo: pathlib.Path) -> None:
    """The judge playbook lists the manifest's rubric dimensions, not a
    hardcoded list. Custom rubric names must appear; the historical ones
    must NOT leak through."""
    runner = CliRunner()
    runner.invoke(
        app, ["init", "feat", "--goal", "x", "--rubric", "speed,readability"]
    )
    runner.invoke(app, ["scenarios", "add", "a", "-d", "first"])
    runner.invoke(app, ["scenarios", "approve", "--yes"])
    runner.invoke(app, ["lock"])
    runner.invoke(
        app, ["record", "variant-01", "--status", "built", "--summary", "ok"]
    )
    r = runner.invoke(app, ["judge"])
    assert r.exit_code == 0, r.output
    assert "speed" in r.output, f"custom rubric dim missing from judge:\n{r.output}"
    assert "readability" in r.output, (
        f"custom rubric dim missing from judge:\n{r.output}"
    )
    assert "extensibility" not in r.output, (
        "default rubric dims must not leak into a custom-rubric judge playbook"
    )


def test_score_accepts_dim_syntax_for_custom_rubric(repo: pathlib.Path) -> None:
    """`joust score --dim name=value` works against a custom rubric."""
    runner = CliRunner()
    runner.invoke(
        app, ["init", "feat", "--goal", "x", "--rubric", "speed,readability"]
    )
    runner.invoke(app, ["scenarios", "add", "a", "-d", "first"])
    runner.invoke(app, ["scenarios", "approve", "--yes"])
    runner.invoke(app, ["lock"])
    runner.invoke(
        app, ["record", "variant-01", "--status", "built", "--summary", "ok"]
    )
    r = runner.invoke(
        app,
        [
            "score", "variant-01",
            "--dim", "speed=4",
            "--dim", "readability=5",
            "--rationale", "fast and readable",
        ],
    )
    assert r.exit_code == 0, r.output
    assert "total=9" in r.output
    slug, run_id = store.get_active(str(repo))
    m = store.load(slug, run_id)
    latest = m.variant("variant-01").latest_score()
    assert latest is not None
    assert latest.dimensions == {"speed": 4, "readability": 5}


def test_score_rejects_dims_not_in_custom_rubric(repo: pathlib.Path) -> None:
    """Score must reject `--dim` entries whose names aren't in the run's
    declared rubric, with an actionable error message."""
    runner = CliRunner()
    runner.invoke(
        app, ["init", "feat", "--goal", "x", "--rubric", "speed,readability"]
    )
    runner.invoke(app, ["scenarios", "add", "a", "-d", "first"])
    runner.invoke(app, ["scenarios", "approve", "--yes"])
    runner.invoke(app, ["lock"])
    runner.invoke(
        app, ["record", "variant-01", "--status", "built", "--summary", "ok"]
    )
    r = runner.invoke(
        app,
        [
            "score", "variant-01",
            "--dim", "speed=4",
            "--dim", "readability=5",
            "--dim", "not-in-rubric=3",
            "--rationale", "has unknown dim",
        ],
    )
    assert r.exit_code != 0, (
        f"score should reject unknown dimension:\n{r.output}"
    )
    assert "not-in-rubric" in r.output


def test_suggest_playbook_has_no_prior_runs_block_on_first_run(
    repo: pathlib.Path,
) -> None:
    """When this is the first run for the repo, suggest must NOT print a
    prior-runs block — distinguishes the empty case from an actual list."""
    runner = CliRunner()
    runner.invoke(app, ["init", "feat-solo", "--goal", "First ever"])
    r = runner.invoke(app, ["scenarios", "suggest"])
    assert r.exit_code == 0, r.output
    assert "Prior runs" not in r.output, (
        f"expected no 'Prior runs' block when no priors exist:\n{r.output}"
    )


def test_duplicate_scenario_name_rejected(repo: pathlib.Path) -> None:
    runner = CliRunner()
    runner.invoke(app, ["init", "feat", "--goal", "x"])
    r = runner.invoke(app, ["scenarios", "add", "minimal", "-d", "first"])
    assert r.exit_code == 0, r.output

    # Adding the same name again should fail
    r = runner.invoke(app, ["scenarios", "add", "minimal", "-d", "second"])
    assert r.exit_code != 0
    assert "already exists" in r.output

    # Adding a different name should still work
    r = runner.invoke(app, ["scenarios", "add", "power", "-d", "third"])
    assert r.exit_code == 0, r.output


def test_diff_shows_changes(repo: pathlib.Path) -> None:
    """After lock + a commit in the worktree, `joust diff` shows the changed file."""
    runner = CliRunner()
    runner.invoke(app, ["init", "feat", "--goal", "Explore feature X"])
    runner.invoke(app, ["scenarios", "add", "minimal", "-d", "Smallest viable"])
    runner.invoke(app, ["scenarios", "approve", "--yes"])
    runner.invoke(app, ["lock"])

    active = store.get_active(str(repo))
    assert active is not None
    slug, run_id = active
    wt = paths.variant_worktree(slug, run_id, "variant-01")

    # Make a commit in the worktree
    (wt / "new_file.py").write_text("print('hello')\n")
    _git("add", ".", cwd=wt)
    _git("commit", "-q", "-m", "add new_file", cwd=wt)

    r = runner.invoke(app, ["diff", "variant-01"])
    assert r.exit_code == 0, r.output
    assert "new_file.py" in r.output


def test_diff_refuses_before_lock(repo: pathlib.Path) -> None:
    """Calling diff before lock gives an error because there's no branch yet."""
    runner = CliRunner()
    runner.invoke(app, ["init", "feat", "--goal", "Explore feature X"])
    runner.invoke(app, ["scenarios", "add", "minimal", "-d", "Smallest viable"])

    r = runner.invoke(app, ["diff", "variant-01"])
    assert r.exit_code != 0
    assert "not locked" in r.output.lower() or "lock" in r.output.lower()


def test_diff_no_changes_yet(repo: pathlib.Path) -> None:
    """After lock but before any commits, diff shows 'no changes'."""
    runner = CliRunner()
    runner.invoke(app, ["init", "feat", "--goal", "Explore feature X"])
    runner.invoke(app, ["scenarios", "add", "minimal", "-d", "Smallest viable"])
    runner.invoke(app, ["scenarios", "approve", "--yes"])
    runner.invoke(app, ["lock"])

    r = runner.invoke(app, ["diff", "variant-01"])
    assert r.exit_code == 0, r.output
    assert "no changes" in r.output.lower()


def test_log_shows_events(repo: pathlib.Path) -> None:
    """joust log shows init and scenario_add events after init + add scenario."""
    runner = CliRunner()
    runner.invoke(app, ["init", "feat", "--goal", "Explore feature X"])
    runner.invoke(app, ["scenarios", "add", "minimal", "-d", "Smallest viable"])

    r = runner.invoke(app, ["log"])
    assert r.exit_code == 0, r.output
    assert "init" in r.output
    assert "scenario_add" in r.output


def test_log_json_flag(repo: pathlib.Path) -> None:
    """joust log --json outputs valid JSON lines."""
    runner = CliRunner()
    runner.invoke(app, ["init", "feat", "--goal", "Explore feature X"])

    r = runner.invoke(app, ["log", "--json"])
    assert r.exit_code == 0, r.output
    lines = [line for line in r.output.strip().splitlines() if line.strip()]
    assert len(lines) >= 1
    for line in lines:
        parsed = json.loads(line)
        assert "kind" in parsed
        assert "at" in parsed


def test_log_last_flag(repo: pathlib.Path) -> None:
    """joust log --last 1 shows only the most recent event."""
    runner = CliRunner()
    runner.invoke(app, ["init", "feat", "--goal", "Explore feature X"])
    runner.invoke(app, ["scenarios", "add", "minimal", "-d", "Smallest viable"])
    runner.invoke(app, ["scenarios", "add", "power", "-d", "All the knobs"])

    r = runner.invoke(app, ["log", "--last", "1"])
    assert r.exit_code == 0, r.output
    assert "scenario_add" in r.output
    assert "init" not in r.output


def test_merge_completes_workflow(repo: pathlib.Path) -> None:
    """Full pipeline: init -> scenarios add -> approve -> lock -> record -> pick -> merge --yes."""
    runner = CliRunner()

    r = runner.invoke(app, ["init", "feat", "--goal", "Explore feature X"])
    assert r.exit_code == 0, r.output

    r = runner.invoke(app, ["scenarios", "add", "minimal", "-d", "Smallest viable"])
    assert r.exit_code == 0, r.output

    r = runner.invoke(app, ["scenarios", "approve", "--yes"])
    assert r.exit_code == 0, r.output

    r = runner.invoke(app, ["lock"])
    assert r.exit_code == 0, r.output

    # Make a commit in the variant worktree so there's something to merge
    active = store.get_active(str(repo))
    assert active is not None
    slug, run_id = active
    wt = paths.variant_worktree(slug, run_id, "variant-01")
    (wt / "feature.py").write_text("print('hello from variant')\n")
    _git("add", ".", cwd=wt)
    _git("commit", "-q", "-m", "add feature.py", cwd=wt)

    r = runner.invoke(
        app, ["record", "variant-01", "--status", "built", "--summary", "ok"]
    )
    assert r.exit_code == 0, r.output

    r = runner.invoke(app, ["pick", "variant-01", "--yes"])
    assert r.exit_code == 0, r.output

    r = runner.invoke(app, ["merge", "--yes"])
    assert r.exit_code == 0, r.output
    assert "merged" in r.output.lower()

    # Verify manifest has merged_at set
    m = store.load(slug, run_id)
    assert m.merged_at is not None

    # Verify git log on the base branch contains the variant's commit
    result = subprocess.run(
        ["git", "log", "--oneline", m.base_ref],
        cwd=str(repo),
        capture_output=True,
        text=True,
        check=True,
    )
    assert "add feature.py" in result.stdout

    # Verify the merged file exists on the base branch
    result = subprocess.run(
        ["git", "show", f"{m.base_ref}:feature.py"],
        cwd=str(repo),
        capture_output=True,
        text=True,
        check=True,
    )
    assert "hello from variant" in result.stdout


def test_merge_refuses_without_pick(repo: pathlib.Path) -> None:
    """joust merge --yes should fail if no variant has been picked."""
    runner = CliRunner()

    r = runner.invoke(app, ["init", "feat", "--goal", "x"])
    assert r.exit_code == 0, r.output

    r = runner.invoke(app, ["scenarios", "add", "a", "-d", "first"])
    assert r.exit_code == 0, r.output

    r = runner.invoke(app, ["scenarios", "approve", "--yes"])
    assert r.exit_code == 0, r.output

    r = runner.invoke(app, ["lock"])
    assert r.exit_code == 0, r.output

    r = runner.invoke(app, ["merge", "--yes"])
    assert r.exit_code != 0
    assert "no variant has been picked" in r.output.lower() or "pick" in r.output.lower()


def test_merge_requires_yes_flag(repo: pathlib.Path) -> None:
    """joust merge without --yes should fail with human-only gate message."""
    runner = CliRunner()

    r = runner.invoke(app, ["init", "feat", "--goal", "x"])
    assert r.exit_code == 0, r.output

    r = runner.invoke(app, ["scenarios", "add", "a", "-d", "first"])
    assert r.exit_code == 0, r.output

    r = runner.invoke(app, ["scenarios", "approve", "--yes"])
    assert r.exit_code == 0, r.output

    r = runner.invoke(app, ["lock"])
    assert r.exit_code == 0, r.output

    r = runner.invoke(
        app, ["record", "variant-01", "--status", "built", "--summary", "ok"]
    )
    assert r.exit_code == 0, r.output

    r = runner.invoke(app, ["pick", "variant-01", "--yes"])
    assert r.exit_code == 0, r.output

    r = runner.invoke(app, ["merge"])
    assert r.exit_code != 0
    assert "human-only gate" in r.output


def test_locked_manifest_saves_on_exit(repo: pathlib.Path) -> None:
    """Use store.locked_manifest as a context manager; modify manifest.goal
    inside the with block, then reload and verify the change persisted."""
    runner = CliRunner()
    runner.invoke(app, ["init", "feat", "--goal", "original goal"])
    active = store.get_active(str(repo))
    assert active is not None
    slug, run_id = active

    with store.locked_manifest(slug, run_id) as manifest:
        manifest.goal = "updated goal"

    reloaded = store.load(slug, run_id)
    assert reloaded.goal == "updated goal"


def test_locked_manifest_concurrent_safety(repo: pathlib.Path) -> None:
    """Spawn 2 threads that each call `joust record` for the same variant.
    After both complete, the variant should have 2 records (not 1)."""
    import threading

    runner = CliRunner()
    runner.invoke(app, ["init", "feat", "--goal", "x"])
    runner.invoke(app, ["scenarios", "add", "one", "-d", "first"])
    runner.invoke(app, ["scenarios", "approve", "--yes"])
    runner.invoke(app, ["lock"])

    active = store.get_active(str(repo))
    assert active is not None
    slug, run_id = active

    results = []

    def record_variant(summary):
        r = runner.invoke(
            app, ["record", "variant-01", "--status", "built", "--summary", summary]
        )
        results.append(r)

    t1 = threading.Thread(target=record_variant, args=("from thread 1",))
    t2 = threading.Thread(target=record_variant, args=("from thread 2",))
    t1.start()
    t2.start()
    t1.join()
    t2.join()

    m = store.load(slug, run_id)
    v = m.variant("variant-01")
    assert len(v.records) == 2, f"expected 2 records, got {len(v.records)}"


def test_cannot_add_scenarios_after_approve(repo: pathlib.Path) -> None:
    runner = CliRunner()
    runner.invoke(app, ["init", "feat", "--goal", "x"])
    runner.invoke(app, ["scenarios", "add", "a", "-d", "first"])
    r = runner.invoke(app, ["scenarios", "approve", "--yes"])
    assert r.exit_code == 0
    r = runner.invoke(app, ["scenarios", "add", "b", "-d", "second"])
    assert r.exit_code != 0
    assert "already approved" in r.output
    r = runner.invoke(app, ["scenarios", "remove", "variant-01"])
    assert r.exit_code != 0
    assert "already approved" in r.output


def test_lock_creates_gitignore_for_prompt_md(repo: pathlib.Path) -> None:
    """After `joust lock`, each worktree should have a .gitignore that
    excludes PROMPT.md so subagents doing `git add .` don't commit it."""
    runner = CliRunner()
    runner.invoke(app, ["init", "feat", "--goal", "x"])
    runner.invoke(app, ["scenarios", "add", "one", "-d", "first"])
    runner.invoke(app, ["scenarios", "approve", "--yes"])
    r = runner.invoke(app, ["lock"])
    assert r.exit_code == 0, r.output

    active = store.get_active(str(repo))
    assert active is not None
    slug, run_id = active
    wt = paths.variant_worktree(slug, run_id, "variant-01")
    gitignore = wt / ".gitignore"
    assert gitignore.exists(), ".gitignore should be created by lock"
    content = gitignore.read_text()
    assert "PROMPT.md" in content, ".gitignore should exclude PROMPT.md"


def test_lock_appends_to_existing_gitignore(repo: pathlib.Path) -> None:
    """If the repo already has a .gitignore, lock should preserve it and
    append the PROMPT.md exclusion."""
    runner = CliRunner()
    # Create a .gitignore in the repo before locking
    (repo / ".gitignore").write_text("*.pyc\n__pycache__/\n")
    _git("add", ".", cwd=repo)
    _git("commit", "-q", "-m", "add gitignore", cwd=repo)

    runner.invoke(app, ["init", "feat", "--goal", "x"])
    runner.invoke(app, ["scenarios", "add", "one", "-d", "first"])
    runner.invoke(app, ["scenarios", "approve", "--yes"])
    r = runner.invoke(app, ["lock"])
    assert r.exit_code == 0, r.output

    active = store.get_active(str(repo))
    assert active is not None
    slug, run_id = active
    wt = paths.variant_worktree(slug, run_id, "variant-01")
    gitignore = wt / ".gitignore"
    content = gitignore.read_text()
    assert "*.pyc" in content, "existing .gitignore content should be preserved"
    assert "PROMPT.md" in content, "PROMPT.md should be appended"


def test_variant_prompt_says_do_not_push(repo: pathlib.Path) -> None:
    """The variant PROMPT.md should tell subagents not to push, since the
    worktree may not have a remote configured."""
    runner = CliRunner()
    runner.invoke(app, ["init", "feat", "--goal", "x"])
    runner.invoke(app, ["scenarios", "add", "one", "-d", "first"])
    runner.invoke(
        app, ["runner", "set", "--runner", "claude-code", "--model", "opus"]
    )
    runner.invoke(app, ["scenarios", "approve", "--yes"])
    r = runner.invoke(app, ["lock"])
    assert r.exit_code == 0, r.output

    active = store.get_active(str(repo))
    assert active is not None
    slug, run_id = active
    wt = paths.variant_worktree(slug, run_id, "variant-01")
    prompt_text = (wt / "PROMPT.md").read_text()
    assert "do not" in prompt_text.lower() and "push" in prompt_text.lower(), \
        "PROMPT.md should instruct agents not to push"


def test_suggest_playbook_mentions_approve_step() -> None:
    """The suggest playbook must mention `joust scenarios approve` so agents
    don't skip the human gate and go straight to `joust lock`."""
    text = render.suggest_playbook("Build feature X", 3)
    assert "approve" in text.lower(), \
        "suggest playbook should mention the approve step"
