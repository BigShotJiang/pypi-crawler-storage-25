"""Unit tests for the e2e harness helpers.

The e2e/ directory is not a Python package and is not installed; we add it
to sys.path so these tests can import the helpers directly.
"""

from __future__ import annotations

import pathlib
import sys

E2E_DIR = pathlib.Path(__file__).parent.parent / "e2e"
sys.path.insert(0, str(E2E_DIR))

import harness  # noqa: E402


def test_variants_not_recorded_all_built() -> None:
    m = {
        "variants": [
            {"id": "variant-01", "status": "built"},
            {"id": "variant-02", "status": "built"},
        ]
    }
    assert harness.variants_not_recorded(m) == []


def test_variants_not_recorded_failed_counts_as_recorded() -> None:
    """A `failed` status still means the subagent called `joust record`,
    so strict mode should not abort on it."""
    m = {
        "variants": [
            {"id": "variant-01", "status": "built"},
            {"id": "variant-02", "status": "failed"},
        ]
    }
    assert harness.variants_not_recorded(m) == []


def test_variants_not_recorded_ready_is_unrecorded() -> None:
    m = {
        "variants": [
            {"id": "variant-01", "status": "built"},
            {"id": "variant-02", "status": "ready"},
        ]
    }
    assert harness.variants_not_recorded(m) == ["variant-02"]


def test_variants_not_recorded_multiple_unrecorded() -> None:
    m = {
        "variants": [
            {"id": "variant-01", "status": "ready"},
            {"id": "variant-02", "status": "in_progress"},
            {"id": "variant-03", "status": "built"},
        ]
    }
    assert harness.variants_not_recorded(m) == ["variant-01", "variant-02"]


def test_variants_not_recorded_judged_counts_as_recorded() -> None:
    """A `judged` variant was previously `built` or `failed`, then scored.
    It should count as recorded so strict mode doesn't reject it."""
    m = {
        "variants": [
            {"id": "variant-01", "status": "judged"},
            {"id": "variant-02", "status": "built"},
        ]
    }
    assert harness.variants_not_recorded(m) == []


def test_variants_not_recorded_picked_counts_as_recorded() -> None:
    """A `picked` variant has been through the full pipeline and should
    definitely count as recorded."""
    m = {
        "variants": [
            {"id": "variant-01", "status": "picked"},
            {"id": "variant-02", "status": "archived"},
        ]
    }
    assert harness.variants_not_recorded(m) == []


def test_committed_files_returns_changed_files(tmp_path: pathlib.Path) -> None:
    """Verify committed_files lists files added on a branch past a base."""
    import subprocess

    repo = tmp_path / "repo"
    repo.mkdir()
    subprocess.run(["git", "init", "-q"], cwd=str(repo), check=True)
    subprocess.run(
        ["git", "config", "commit.gpgsign", "false"], cwd=str(repo), check=True
    )
    subprocess.run(
        ["git", "config", "user.email", "t@t.com"], cwd=str(repo), check=True
    )
    subprocess.run(
        ["git", "config", "user.name", "test"], cwd=str(repo), check=True
    )
    (repo / "base.txt").write_text("base\n")
    subprocess.run(["git", "add", "."], cwd=str(repo), check=True)
    subprocess.run(["git", "commit", "-q", "-m", "init"], cwd=str(repo), check=True)
    base_sha = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=str(repo),
        capture_output=True,
        text=True,
        check=True,
    ).stdout.strip()

    subprocess.run(
        ["git", "checkout", "-b", "feature"], cwd=str(repo), check=True
    )
    (repo / "new.txt").write_text("new\n")
    subprocess.run(["git", "add", "."], cwd=str(repo), check=True)
    subprocess.run(
        ["git", "commit", "-q", "-m", "add new"], cwd=str(repo), check=True
    )

    files = harness.committed_files(str(repo), base_sha, "feature")
    assert "new.txt" in files
    assert "base.txt" not in files
