# Joust v1 Readiness Design

Date: 2026-04-19
Status: approved, implementation in progress

## Goal

Ship joust as a public, installable tool. Three-release path:

- **v0.2.0** — repo public + PyPI release (hygiene-only, no new features)
- **v0.3.0** — non-trivial demo + one or two feature-polish items
- **v1.0.0** — Claude Code plugin that puts `joust` on PATH

## Non-goals

- Slash commands, skills, or any UX wrapper on top of the CLI. Joust follows
  the "`--help` is the onboarding" principle (Simon Willison's
  showboat/rodney pattern). The agent reads `joust --help` and drives the
  workflow directly. The plugin layer is distribution only.
- Rewriting any existing command. The current feature surface is the v1
  feature surface.
- A documentation site. README + in-tree docs are sufficient for v1.

## v0.2.0 — hygiene + PyPI (this milestone)

Scope: make the repo safe to point at and the package safe to install.

1. `LICENSE` file on disk (MIT, matching `pyproject.toml`).
2. `joust --version` (TDD — this is a new feature that ships in v0.2.0).
3. `pyproject.toml` PyPI metadata: project URLs (Homepage, Source,
   Issues), classifiers, explicit `readme` pointer, version bump to 0.2.0.
4. README refresh: document `joust diff`, `joust log`, `joust merge` (all
   landed upstream but not yet in README); update Status section.
5. `.github/workflows/ci.yml`: pytest on push and PR. Python 3.11, 3.12, 3.13.
   macOS + Linux.

Not in v0.2.0: PyPI publish workflow (trusted publishing setup can come
with the tag-and-release step, outside the code PR). Actual PyPI upload is
a manual step after the branch merges.

## v0.3.0 — demo + feature polish

Scope: make the public release *believable*. Two tracks:

**Demo track.** One end-to-end example that isn't `greet(name)`. Candidate:
a refactor-style problem ("split a 400-line module three different ways"),
because the variants diverge visibly, the rubric dimensions genuinely
differ, and it reflects a real decision developers face. Artifacts live
under `docs/examples/` and are referenced from the README walkthrough.

**Feature-polish track.** Two items, both TDD:

- Rubric customization — let a run declare its own dimensions (via
  `joust init --rubric correctness,simplicity` or a config hook), so joust
  is useful for non-coding prototypes. Today the 4 dimensions are hardcoded
  in `score`, `judge_playbook`, and `compare_table`.
- Richer `scenarios suggest` playbook — surface prior run slugs/goals so
  the agent doesn't reinvent angles that already lost. Today the playbook
  is static.

Test-module split (`test_smoke.py` → `test_diff.py`, `test_log.py`,
`test_merge.py`, `test_locking.py`) is opt-in code-health work; decide at
v0.3.0 start whether it's in scope.

## v1.0.0 — Claude Code plugin

Scope: a minimal plugin that ensures `joust` is on PATH inside a Claude
Code project. Two candidate distribution mechanisms — decide at v1.0.0
start:

- **uvx trampoline.** Plugin ships a hook that runs `uvx joust` on
  session start. No install step beyond enabling the plugin. Requires PyPI.
- **Bundled wheel.** Plugin ships the wheel itself; installation places
  `joust` on PATH directly. Works offline; larger plugin.

No slash commands. No skill. The plugin README instructs the user to
prompt: "run `joust --help` and spin up N variants of feature X." The
agent takes it from there.

## Open questions (defer to their milestone)

- Which PyPI account / organization owns `joust`? (v0.2.0 blocker
  before actual upload, but not before the branch merges.)
- Which repo hosts the Claude Code plugin? Same repo as the CLI, or a
  sibling `joust-plugin` repo? (v1.0.0 decision.)
- Version discipline: semver with real guarantees, or 0.x semantics until
  real users show up? (Decide at v1.0.0.)
