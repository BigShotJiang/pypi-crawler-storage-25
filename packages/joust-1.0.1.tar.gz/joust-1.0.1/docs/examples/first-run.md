# First run: three rate-limit variants on a Flask endpoint

A walkthrough of a realistic joust run. The goal is non-trivial: three
different rate-limiting strategies on a `/api/search` endpoint. The
variants diverge on algorithm, not on coding style, so the rubric
actually has to work. We'll use a custom rubric that matches what a
human operator cares about — `correctness,simplicity,ops,fit` — swapping
the default `extensibility` for `ops` (how hard is this to run in prod?).

> Every output block below is lightly abridged for readability. The CLI
> format, playbook text, and table rendering are the real ones you'll
> see when you follow along against a repo of your own.

---

## 1. Initialize the run

```
$ joust init flask-ratelimit --goal "Rate-limit /api/search — survive a burst of 200 rps from a single IP" --rubric correctness,simplicity,ops,fit
initialized run flask-ratelimit/260419-094512-a1b2
  base:     main @ d2849a0bd7e1
  state:    /home/you/.joust/runs/flask-ratelimit/260419-094512-a1b2

next: add scenarios with `joust scenarios add <name> --description ...`
      or brainstorm with `joust scenarios suggest --count 3`
```

`joust --help` is self-documenting. A fresh agent running it will see
the workflow and know what comes next.

## 2. Brainstorm scenarios

```
$ joust scenarios suggest --count 3
# Joust scenario brainstorming

Goal: Rate-limit /api/search — survive a burst of 200 rps from a single IP

Come up with 3 distinct angles to prototype this feature. Each
angle should differ in one or more of:

  - Product scope           (minimal happy path  <->  power-user)
  - UX paradigm             (guided wizard       <->  direct manipulation)
  - Architectural stance    (client-heavy        <->  server-heavy)
  - Tech/library choice     (boring defaults     <->  novel approach)
  - Assumption about users  (novice              <->  expert)

Avoid near-duplicates. Each should be defensible as "the right answer"
under some set of product priorities.

For each angle, pick a short kebab-case name (3-5 words) and write a
1-3 sentence description, then register it:

    joust scenarios add "short-name" --description "one to three sentences"

After adding all 3, run `joust scenarios list` to review them,
then ask the human to approve with `joust scenarios approve --yes`
(this is a required gate — agents cannot skip it). Once approved,
run `joust lock` to materialize worktrees.
```

The agent registers three distinct angles:

```
$ joust scenarios add token-bucket -d "Per-IP token bucket in process memory. Flask-Limiter default backend. Zero infra dependencies; resets on restart."
added variant-01  token-bucket

$ joust scenarios add sliding-window -d "Redis-backed sliding window counter. Shared across workers. Needs Redis in the compose file but works under horizontal scale."
added variant-02  sliding-window

$ joust scenarios add nginx-frontend -d "Delegate to nginx limit_req in the reverse proxy. Flask sees nothing. No Python code touched; config only."
added variant-03  nginx-frontend
```

## 3. Pick a model, then approve

```
$ joust runner set --runner claude-code --model sonnet
runner: claude-code
model:  sonnet

$ joust scenarios approve --yes
approved 3 scenarios
  variant-01  token-bucket
  variant-02  sliding-window
  variant-03  nginx-frontend

next: `joust lock` to materialize worktrees
```

The `--yes` gate is non-negotiable. An agent alone cannot move past this
point.

## 4. Lock — materialize worktrees

```
$ joust lock
  variant-01    joust/260419-094512-a1b2/variant-01  ->  /home/you/.joust/runs/flask-ratelimit/260419-094512-a1b2/worktrees/variant-01
  variant-02    joust/260419-094512-a1b2/variant-02  ->  ...worktrees/variant-02
  variant-03    joust/260419-094512-a1b2/variant-03  ->  ...worktrees/variant-03

locked 3 variants
runner:  claude-code  model: sonnet
next: dispatch one subagent per worktree. Each subagent should
      read PROMPT.md at its worktree root and call `joust record`
      when done.
```

Each worktree has a generated `PROMPT.md` that the subagent reads as
its brief. It names the variant's angle, the goal, the environment,
and the exact `joust record` incantation to call when finished.

## 5. Subagents work in parallel

Three subagents, each in their own worktree, touch only their own
files. They don't see each other. From this session's perspective, the
drive is:

```python
for variant in ("variant-01", "variant-02", "variant-03"):
    # Claude Code's Agent tool, isolation="worktree"
    spawn(
        cwd=wt_path(variant),
        prompt=read(wt_path(variant) / "PROMPT.md"),
        model="sonnet",
    )
```

Each subagent commits its changes and calls `joust record`:

```
$ joust record variant-01 --status built --summary "Flask-Limiter with in-memory backend, 100 req/min per IP. 12 lines."
recorded variant-01 -> built

$ joust record variant-02 --status built --summary "Redis sliding-window, 120 req/min per IP, shared across gunicorn workers. Needs REDIS_URL env."
recorded variant-02 -> built

$ joust record variant-03 --status built --summary "nginx limit_req_zone in conf.d/ratelimit.conf. Flask untouched. Needs rate-limit header passthrough."
recorded variant-03 -> built
```

## 6. Judge

`joust judge` prints a playbook whose rubric is drawn from the run's
declared `--rubric`:

```
$ joust judge
# Joust judgment

Goal: Rate-limit /api/search — survive a burst of 200 rps from a single IP

You are judging the following variants. For each one:

  1. cd into its worktree and read RATIONALE.md plus the actual code
  2. Build/run it if the scenario calls for that
  3. Score it across the rubric dimensions (1-5, higher is better):

       correctness  - does it actually solve the goal?
       simplicity   - is the design minimal for what it does?
       ops
       fit          - does it match the scenario's stated angle?

  4. Record the scores with:

       joust score <variant-id> \
           --dim correctness=N --dim simplicity=N --dim ops=N --dim fit=N \
           --rationale "2-4 sentences of reasoning"

Variants:

  - variant-01  [built]  token-bucket
      desc:     Per-IP token bucket in process memory. ...
      worktree: ...worktrees/variant-01
      summary:  Flask-Limiter with in-memory backend, 100 req/min per IP. 12 lines.
  - variant-02  [built]  sliding-window
      desc:     Redis-backed sliding window counter. ...
      worktree: ...worktrees/variant-02
      summary:  Redis sliding-window, 120 req/min per IP, ...
  - variant-03  [built]  nginx-frontend
      desc:     Delegate to nginx limit_req in the reverse proxy. ...
      worktree: ...worktrees/variant-03
      summary:  nginx limit_req_zone in conf.d/ratelimit.conf. ...

When all variants have scores, run `joust compare` to see the table,
then let the human run `joust pick <variant-id>`.
```

Note that `ops` has no description line — the default-rubric
descriptions only apply to the four historical names. Custom
dimensions are printed bare.

## 7. Score each variant

```
$ joust score variant-01 \
    --dim correctness=4 --dim simplicity=5 --dim ops=4 --dim fit=5 \
    --rationale "Straightforward, no infra. Loses correctness because memory backend resets on deploy, which flask-limiter docs warn about."
scored variant-01: total=18 by agent

$ joust score variant-02 \
    --dim correctness=5 --dim simplicity=3 --dim ops=3 --dim fit=5 \
    --rationale "Correct across workers and restarts. Simplicity and ops suffer because we now have a Redis dependency in the hot path."
scored variant-02: total=16 by agent

$ joust score variant-03 \
    --dim correctness=5 --dim simplicity=4 --dim ops=5 --dim fit=3 \
    --rationale "nginx does this in production all day. Off-box and invisible to Flask. Fit suffers because the goal implied an application-level fix, not infrastructure."
scored variant-03: total=17 by agent
```

## 8. Compare

```
$ joust compare
ID          NAME            STATUS  correctness  simplicity  ops  fit  TOTAL  RATIONALE
----------  --------------  ------  -----------  ----------  ---  ---  -----  ---------------------------------------------------------
variant-01  token-bucket    judged  4            5           4    5    18     Straightforward, no infra. Loses correctness because m...
variant-02  sliding-window  judged  5            3           3    5    16     Correct across workers and restarts. Simplicity and op...
variant-03  nginx-frontend  judged  5            4           5    3    17     nginx does this in production all day. Off-box and in...
```

Totals disagree. That's the point — the rubric forces the human to
look at axes they might not have weighted the same way.

## 9. Pick, merge, archive — humans only

```
$ joust pick variant-01 --yes
picked variant-01 (token-bucket)
  branch:   joust/260419-094512-a1b2/variant-01
  worktree: ...worktrees/variant-01

To merge the winner into your working branch:
  git merge joust/260419-094512-a1b2/variant-01
Then run `joust archive --prune` to clean up the losing branches.

$ joust merge --yes
merged joust/260419-094512-a1b2/variant-01 into main
(fast-forward)

$ joust archive --prune
archived 2 variants
```

The winning worktree stays on disk until archived manually; the losers
are wiped. `joust log` prints the full event timeline for the run
afterwards if you want an audit trail.

## 10. Next time

A subsequent run on the same repo sees the prior run in its suggest
playbook:

```
$ joust init feat-autocomplete --goal "Add search autocomplete"
...
$ joust scenarios suggest
# Joust scenario brainstorming
...
## Prior runs for this repo

Read these before proposing angles — avoid reinventing something
that already lost, and look for gaps the prior runs did not cover.

  flask-ratelimit/260419-094512-a1b2  goal: "Rate-limit /api/search — survive a burst of 200 rps from a single IP"
    picked: variant-01 (token-bucket)
    scenarios: token-bucket, sliding-window, nginx-frontend
```

The agent now knows `token-bucket` won last time and `nginx-frontend`
lost — useful context when thinking about architectural stance.

---

## What this shows

- `--rubric` lets you pick the axes that matter for *your* decision,
  not the four the tool picked for you.
- Three variants with genuinely different tradeoffs produce a
  genuinely interesting comparison table. The totals don't match what
  a single developer would have guessed.
- The human gates (`approve`, `pick`, `merge`) keep the agent from
  silently locking a bad rubric or declaring a winner it likes.
- Everything is auditable: `manifest.json`, `events.jsonl`, and the
  per-variant `RATIONALE.md` on disk.

Try it against a small feature on a throwaway branch. Three variants,
30 minutes, real model tokens. You'll know within one run whether it
earns a place in your workflow.
