# Installing joust as a Claude Code plugin

The joust plugin puts the `joust` CLI on PATH when a Claude Code session
starts in the project where the plugin is enabled. No slash commands,
no skills, no hidden agent wrappers — joust's `--help` text is the
onboarding, and your agent reads it directly.

Typical interaction after install:

> **You:** Run `joust --help` and spin up three variants of
> the caching feature we talked about.

That's it. The agent follows the workflow joust prints.

## Install

Add the joust marketplace, then install the plugin:

```
/plugin marketplace add nclandrei/joust
/plugin install joust@joust
```

Then restart the session (or `/clear`) so the SessionStart hook fires.
On first run the hook will install `joust` via whichever package
manager is available (`uv tool`, `pipx`, or `pip --user`) — after that
it's a no-op that verifies `joust` is on PATH.

### Alternative: manual install

If you'd rather manage installs yourself, skip the plugin and run one of:

```
uv tool install joust          # recommended
pipx install joust
pip install --user joust
```

Then prompt your agent exactly as above.

## What the plugin does

Contents of `plugin/` in this repo:

```
plugin/
├── .claude-plugin/
│   └── plugin.json          # manifest — declares the SessionStart hook
└── scripts/
    └── ensure-joust.sh      # idempotent install / PATH check
```

- `plugin.json` registers one `SessionStart` hook with matcher
  `startup|resume|clear` and a 120 s timeout.
- `ensure-joust.sh` checks `command -v joust`, exits 0 immediately if
  present, otherwise tries `uv`, `pipx`, and `pip --user` in that order.
  Failures are non-fatal — the hook prints an actionable install hint
  and returns 0 so your session isn't blocked.

## Troubleshooting

- **`joust: command not found` after install.** The install succeeded
  but PATH wasn't refreshed. Run `hash -r` in your shell, or open a new
  session. If using `uv tool install`, ensure `~/.local/bin` (or
  `$XDG_BIN_HOME`) is on PATH.
- **Hook timed out.** 120 s is a generous budget for the PyPI install
  on a cold system; if your network is slow enough to exceed it,
  install manually once and the hook will fast-path thereafter.
- **Hook not firing.** Verify the plugin is installed
  (`/plugin list`) and try `/clear` to trigger the `clear` matcher.

## Not included on purpose

The plugin does not ship slash commands, skills, agents, or any other
UX layer. That's deliberate: joust is designed so that `joust --help`
is the complete operator's manual for agents. Wrapping it in bespoke
commands would duplicate information that already lives in the CLI
and drift against it. If you find yourself writing a wrapper, the
better move is a PR against joust's `--help` text.
