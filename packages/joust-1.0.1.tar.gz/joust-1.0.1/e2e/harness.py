"""Pure helpers for the e2e harness so they can be unit-tested.

The script `run_e2e.py` imports from this module and does the orchestration
(subprocess, tmpdir management, real claude invocation). Everything that
can be tested in isolation lives here.
"""

from __future__ import annotations

from typing import Any


# Variant states that mean "the subagent reported back" (or progressed
# past that point). `judged`, `picked`, and `archived` are downstream
# states that imply the agent DID record earlier.
RECORDED_STATES = frozenset({"built", "failed", "judged", "picked", "archived"})


def committed_files(repo_path: str, base_sha: str, branch: str) -> list[str]:
    """Return filenames committed on *branch* past *base_sha*.

    Uses ``git diff --name-only`` so the result is a flat list of paths
    relative to the repo root. The caller can assert that infrastructure
    files like ``PROMPT.md`` are absent.
    """
    import subprocess

    result = subprocess.run(
        ["git", "diff", "--name-only", f"{base_sha}...{branch}"],
        cwd=repo_path,
        capture_output=True,
        text=True,
        check=True,
    )
    return [line.strip() for line in result.stdout.splitlines() if line.strip()]


def variants_not_recorded(manifest: dict[str, Any]) -> list[str]:
    """Return ids of variants whose status is not in ``RECORDED_STATES``.

    Given a loaded manifest JSON, returns the list of variant ids that the
    e2e harness should treat as "subagent did not self-report". An empty
    list means every variant is either built or failed.
    """
    return [
        v["id"]
        for v in manifest.get("variants", [])
        if v.get("status") not in RECORDED_STATES
    ]
