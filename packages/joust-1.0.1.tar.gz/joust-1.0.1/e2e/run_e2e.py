"""End-to-end test for joust driving real Claude Code subagents.

This is NOT a pytest test. It hits the real Anthropic API and costs tokens.
Run it manually when you want to verify the whole pipeline works with a real
model:

    python projects/joust/e2e/run_e2e.py
    python projects/joust/e2e/run_e2e.py --model sonnet   # spend more
    python projects/joust/e2e/run_e2e.py --lenient        # allow fallback
    python projects/joust/e2e/run_e2e.py --keep           # leave scratch dirs

What it does:

  1. Creates a throwaway git repo in /tmp with a hello.py starter file.
  2. Runs the full joust workflow: init -> scenarios add -> approve ->
     runner set -> lock -> dispatch subagents -> record -> judge -> score ->
     compare -> pick -> archive.
  3. Each subagent is `claude -p --model <model>` with cwd set to the
     variant's worktree and PATH extended so `joust` is available. The
     prompt is the variant's PROMPT.md plus one instruction to actually
     edit hello.py.
  4. By default, runs in STRICT mode: if any subagent fails to call
     `joust record` itself, the harness aborts non-zero. Pass `--lenient`
     to fall back to a harness-side `joust record` and keep the pipeline
     moving — useful when prototyping joust changes against a flaky model.
  5. Asserts final state: each non-failed variant's branch has a new commit,
     the winner's worktree still exists after archive, losers are gone.

Defaults: 2 variants, haiku, strict mode, ~$0.01-0.05 per run.
"""

from __future__ import annotations

import argparse
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile
import textwrap

# Make sibling harness.py importable regardless of how this script is run.
sys.path.insert(0, str(pathlib.Path(__file__).parent))
import harness  # noqa: E402


CLAUDE = "/opt/claude-code/bin/claude"
PROJECT = pathlib.Path(__file__).resolve().parents[1]
JOUST_BIN = PROJECT / ".venv" / "bin" / "joust"


# ---------------------------------------------------------------------------
# shell helpers
# ---------------------------------------------------------------------------


class RunResult:
    def __init__(self, rc: int, out: str, err: str) -> None:
        self.rc = rc
        self.out = out
        self.err = err

    def ok(self) -> bool:
        return self.rc == 0


def sh(
    *args: str,
    cwd: pathlib.Path | None = None,
    env: dict[str, str] | None = None,
    check: bool = True,
    timeout: int = 60,
) -> RunResult:
    print(f"  $ {' '.join(args)}{'  (cwd=' + str(cwd) + ')' if cwd else ''}")
    r = subprocess.run(
        args,
        cwd=str(cwd) if cwd else None,
        env=env,
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    if r.stdout.strip():
        for line in r.stdout.strip().splitlines()[:20]:
            print(f"    | {line}")
    if check and r.returncode != 0:
        print(f"  ! exit={r.returncode}")
        if r.stderr.strip():
            for line in r.stderr.strip().splitlines()[:20]:
                print(f"    ! {line}")
        raise SystemExit(f"command failed: {' '.join(args)}")
    return RunResult(r.returncode, r.stdout, r.stderr)


def joust(*args: str, env: dict[str, str], cwd: pathlib.Path, check: bool = True) -> RunResult:
    return sh(str(JOUST_BIN), *args, cwd=cwd, env=env, check=check)


# ---------------------------------------------------------------------------
# scratch repo
# ---------------------------------------------------------------------------


def make_repo(tmp: pathlib.Path) -> pathlib.Path:
    repo = tmp / "repo"
    repo.mkdir()
    sh("git", "init", "-q", cwd=repo)
    sh("git", "config", "commit.gpgsign", "false", cwd=repo)
    sh("git", "config", "user.email", "e2e@joust.test", cwd=repo)
    sh("git", "config", "user.name", "joust-e2e", cwd=repo)
    (repo / "hello.py").write_text(
        textwrap.dedent(
            """\
            # TODO: add a greet(name) function that returns "Hello, <name>!"
            """
        )
    )
    sh("git", "add", ".", cwd=repo)
    sh("git", "commit", "-q", "-m", "initial", cwd=repo)
    return repo


# ---------------------------------------------------------------------------
# claude driver
# ---------------------------------------------------------------------------


DISPATCH_INSTRUCTIONS = textwrap.dedent(
    """

    ## Task (appended by e2e harness)
    Edit hello.py so that `greet(name)` returns exactly `"Hello, <name>!"`
    (capitalized "Hello", followed by a comma, a space, the name, then an
    exclamation mark). Keep it consistent with your angle above. Then
    commit with `git add hello.py && git commit -m "impl greet"`.

    After you commit, run this command verbatim (it is already on PATH):

        joust record {variant_id} --status built --summary "<1-2 sentences>"

    If you hit a blocker, run:

        joust record {variant_id} --status failed --summary "<why>"

    Do not run any other joust commands.
    """
)


# Explicit tool allowlist for subagents. No auto-accept escape hatch: the
# subagent can only read/edit files in its worktree, and only run `git` and
# `joust` subcommands via Bash. It cannot, e.g., `git push`, `rm -rf`, or
# touch anything outside its cwd.
SUBAGENT_ALLOWED_TOOLS = "Read Edit Write Bash(git:*) Bash(joust:*) Bash(ls:*) Bash(cat:*)"


def dispatch_subagent(
    worktree: pathlib.Path,
    variant_id: str,
    model: str,
    env: dict[str, str],
) -> RunResult:
    prompt = (worktree / "PROMPT.md").read_text()
    prompt += DISPATCH_INSTRUCTIONS.format(variant_id=variant_id)
    print(f"\n=== dispatching subagent for {variant_id} in {worktree} ===")
    r = subprocess.run(
        [
            CLAUDE,
            "-p",
            "--model",
            model,
            "--allowedTools",
            SUBAGENT_ALLOWED_TOOLS,
            "--",
            prompt,
        ],
        cwd=str(worktree),
        env=env,
        capture_output=True,
        text=True,
        timeout=300,
    )
    print(f"  claude exit={r.returncode}")
    if r.stdout.strip():
        for line in r.stdout.strip().splitlines()[-10:]:
            print(f"    out| {line}")
    if r.stderr.strip():
        for line in r.stderr.strip().splitlines()[-10:]:
            print(f"    err| {line}")
    return RunResult(r.returncode, r.stdout, r.stderr)


# ---------------------------------------------------------------------------
# assertions
# ---------------------------------------------------------------------------


def assert_branch_has_commit_past_base(
    repo: pathlib.Path, branch: str, base_sha: str
) -> bool:
    r = subprocess.run(
        ["git", "rev-list", "--count", f"{base_sha}..{branch}"],
        cwd=str(repo),
        capture_output=True,
        text=True,
        check=True,
    )
    count = int(r.stdout.strip())
    return count > 0


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="haiku", help="Model to run subagents as.")
    parser.add_argument(
        "--keep",
        action="store_true",
        help="Do not delete the scratch repo or JOUST_HOME after the run.",
    )
    parser.add_argument(
        "--lenient",
        action="store_true",
        help=(
            "Allow harness-side `joust record` fallback when a subagent "
            "fails to self-report. Default is strict (abort non-zero)."
        ),
    )
    args = parser.parse_args()
    strict = not args.lenient

    if not JOUST_BIN.exists():
        print(f"error: joust not installed. Run `uv pip install -e .` in {PROJECT}.")
        return 2
    if not os.path.exists(CLAUDE):
        print(f"error: claude binary not found at {CLAUDE}")
        return 2

    # Safety: refuse to run if the harness is somehow about to operate
    # anywhere near the main research repo. The scratch dir is always under
    # /tmp, and claude is invoked with cwd=<scratch worktree>, so this
    # should be a tautology — but make it explicit.
    research_root = pathlib.Path("/home/user/research").resolve()
    harness_cwd = pathlib.Path.cwd().resolve()
    if harness_cwd == research_root or research_root in harness_cwd.parents:
        print(
            f"warn: harness launched from inside {research_root}; "
            f"this is fine because subagents run in /tmp scratch dirs only."
        )

    tmp = pathlib.Path(tempfile.mkdtemp(prefix="joust-e2e-"))
    home = tmp / "joust-home"
    print(f"\n>> scratch root: {tmp}")
    print(f">> JOUST_HOME:   {home}")
    print(f">> model:        {args.model}")

    env = dict(os.environ)
    env["JOUST_HOME"] = str(home)
    # Put joust's venv bin on PATH so the subagent can call `joust record`.
    env["PATH"] = f"{JOUST_BIN.parent}:{env.get('PATH', '')}"

    try:
        repo = make_repo(tmp)

        # Phase 1: brainstorm, approve, lock
        print("\n--- phase 1: configure run ---")
        joust("init", "feat-greet", "--goal", "Implement greet(name) in hello.py", env=env, cwd=repo)
        joust(
            "scenarios", "add", "minimal-fstring",
            "-d", "One-line f-string inside greet(). Zero ceremony.",
            env=env, cwd=repo,
        )
        joust(
            "scenarios", "add", "class-based",
            "-d", "A Greeter class with a greet(name) method wrapping an f-string.",
            env=env, cwd=repo,
        )
        joust(
            "runner", "set", "--runner", "claude-code", "--model", args.model,
            env=env, cwd=repo,
        )
        joust("scenarios", "approve", "--yes", env=env, cwd=repo)
        joust("lock", env=env, cwd=repo)

        # Grab the manifest paths we'll need
        base_sha = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=str(repo), capture_output=True, text=True, check=True,
        ).stdout.strip()
        active_file = home / "active.json"
        import json
        active = json.loads(active_file.read_text())[str(repo)]
        slug = active["slug"]
        run_id = active["run_id"]
        wt_root = home / "runs" / slug / run_id / "worktrees"
        print(f"\n>> slug/run_id:  {slug}/{run_id}")
        print(f">> worktrees:    {wt_root}")

        # Phase 2: dispatch real subagents
        print("\n--- phase 2: dispatch subagents ---")
        results: dict[str, RunResult] = {}
        for variant_id in ("variant-01", "variant-02"):
            wt = wt_root / variant_id
            results[variant_id] = dispatch_subagent(wt, variant_id, args.model, env)

        # Phase 3: verify each subagent called `joust record` on its own.
        print("\n--- phase 3: verify records ---")
        joust("list", env=env, cwd=repo)
        manifest_file = home / "runs" / slug / run_id / "manifest.json"
        manifest = json.loads(manifest_file.read_text())
        variant_status = {v["id"]: v["status"] for v in manifest["variants"]}
        print(f"  manifest status: {variant_status}")

        unrecorded = harness.variants_not_recorded(manifest)
        if unrecorded:
            if strict:
                print(
                    f"\n>> STRICT: these variants failed to self-report: "
                    f"{unrecorded}"
                )
                print(
                    ">> This is a regression. Either the subagent did not call "
                    "`joust record`, its invocation crashed, or the PROMPT.md "
                    "instructions are not being followed. Re-run with --lenient "
                    "to use harness-side fallback while debugging."
                )
                return 1
            print(f"  ! lenient mode: falling back for {unrecorded}")
            for vid in unrecorded:
                joust(
                    "record", vid, "--status", "built",
                    "--summary", "fallback: harness recorded on behalf of agent",
                    env=env, cwd=repo,
                )

        # Phase 4: score, compare, pick, archive
        print("\n--- phase 4: judge / score / pick / archive ---")
        joust("judge", env=env, cwd=repo, check=False)  # prints playbook
        for vid, c, s in [("variant-01", 5, 5), ("variant-02", 5, 3)]:
            joust(
                "score", vid,
                "--correctness", str(c),
                "--simplicity", str(s),
                "--fit", "5",
                "--extensibility", "3",
                "--rationale", "e2e harness scored mechanically",
                env=env, cwd=repo,
            )
        joust("compare", env=env, cwd=repo)
        joust("pick", "variant-01", "--yes", env=env, cwd=repo)
        joust("archive", "--prune", env=env, cwd=repo)

        # Phase 5: assertions
        print("\n--- phase 5: assertions ---")
        failures: list[str] = []
        # Winner's worktree still exists
        winner_wt = wt_root / "variant-01"
        if not winner_wt.exists():
            failures.append("winner worktree was archived")
        # Loser's worktree gone
        loser_wt = wt_root / "variant-02"
        if loser_wt.exists():
            failures.append("loser worktree was not archived")
        # Winner's branch has commits past base
        winner_branch = f"joust/{run_id}/variant-01"
        if not assert_branch_has_commit_past_base(repo, winner_branch, base_sha):
            failures.append(f"winner branch {winner_branch} has no commits past base")
        # PROMPT.md should NOT appear in the variant diff (it should be
        # gitignored so the subagent doesn't accidentally commit it).
        for vid in ("variant-01", "variant-02"):
            branch = f"joust/{run_id}/{vid}"
            try:
                files = harness.committed_files(str(repo), base_sha, branch)
                if "PROMPT.md" in files:
                    failures.append(f"{vid}: PROMPT.md was committed (should be gitignored)")
            except Exception:
                pass  # branch may have been pruned (variant-02)

        if failures:
            print("\n>> FAILURES:")
            for f in failures:
                print(f"   - {f}")
            return 1
        print("\n>> all assertions passed")
        print(">> e2e OK")
        return 0
    finally:
        if not args.keep:
            shutil.rmtree(tmp, ignore_errors=True)
            print(f"\n>> cleaned up {tmp}")
        else:
            print(f"\n>> keeping scratch at {tmp}")


if __name__ == "__main__":
    sys.exit(main())
