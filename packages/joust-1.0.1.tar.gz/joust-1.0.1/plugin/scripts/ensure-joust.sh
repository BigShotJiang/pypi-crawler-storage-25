#!/usr/bin/env bash
# Ensure the `joust` CLI is on PATH for this Claude Code session.
#
# Installs via `uv tool install joust` on first run (idempotent —
# subsequent runs are no-ops once the binary is on PATH). Falls back to
# pipx, then `pip install --user`. Never blocks the session: failures
# print a diagnostic and exit 0 so you can install manually.
set -u

if command -v joust >/dev/null 2>&1; then
  exit 0
fi

echo "joust not on PATH — attempting install..." >&2

try_install() {
  local tool="$1"
  shift
  if command -v "$tool" >/dev/null 2>&1; then
    if "$@"; then
      echo "joust installed via $tool" >&2
      return 0
    fi
    echo "warn: $tool could not install joust" >&2
  fi
  return 1
}

try_install uv   uv tool install joust   && exit 0
try_install pipx pipx install joust      && exit 0
try_install pip  pip install --user joust && exit 0

cat >&2 <<'EOF'
warn: could not install joust automatically. Install one way:

  uv tool install joust      # recommended, fastest
  pipx install joust
  pip install --user joust

Then re-run or reopen your session. Once `joust --help` works,
prompt your agent with something like:

  "Run joust --help, then spin up 3 variants of <feature>."
EOF
exit 0
