# joust Claude Code plugin

Makes the `joust` CLI available inside any Claude Code session where
this plugin is enabled. See [`../docs/plugin.md`](../docs/plugin.md) for
the install guide and the rationale for keeping the plugin minimal.

## Quick install

```
/plugin marketplace add nclandrei/joust
/plugin install joust@joust
```

## What's here

- `.claude-plugin/plugin.json` — the plugin manifest, including a
  SessionStart hook that runs `scripts/ensure-joust.sh`.
- `scripts/ensure-joust.sh` — idempotent install / PATH check.

No slash commands, no skills, no agents — joust's `--help` is the
operator's manual.
