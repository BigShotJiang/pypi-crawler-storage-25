#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import copy

from typing import Any

from AnyQt.QtCore import pyqtSignal, QObject

from aps.common.scripts.script_data import ScriptData
from aps.common.singleton import synchronized_method

from aps.beamline_driver.motion_management.facade import MotorsInfoLegacy, IMotionManager
from aps.beamline_driver.motion_management.motion_manager_factory import create_motion_manager

from aps.ai.beamline_controller.legacy.common.legacy_keys import Keys

from aps.ai.beamline_controller.legacy.execution.execution_initialization_parameters import set_ini_from_initialization_parameters, generate_initialization_parameters_from_ini

from aps.ai.beamline_controller.legacy.execution.agent_initialization_manager import AgentInitializationManager

class IConfigurationManager():
    def get_configuration(self) -> ScriptData: raise NotImplementedError
    def save_configuration(self, initialization_parameters: ScriptData): raise NotImplementedError
    def load_motors_info(self,   initialization_parameters: ScriptData, return_motion_manager=False) -> MotorsInfoLegacy: raise NotImplementedError()
    def save_motors_info(self, new_motors_info: MotorsInfoLegacy, initialization_parameters: ScriptData, motion_manager=None): raise NotImplementedError()

class AbstractConfigurationManager(AgentInitializationManager, IConfigurationManager):
    def __init__(self, application_name: str, working_directory: str, beamline_id: str, **kwargs):
        super(AbstractConfigurationManager, self).__init__(application_name, working_directory, beamline_id, **kwargs)

    # ----------------------------------------------------------------------------
    #
    # CONFIGURATION
    #
    # ----------------------------------------------------------------------------

    def _get_beam_manager_pointers(self, initialization_parameters, transfer=False):
        platforms    = initialization_parameters.get_parameter("platforms")
        platform     = initialization_parameters.get_parameter(("platform" if not transfer else "platform_to"))
        platform_key = platforms[int(platform)]

        beam_manager_types         = initialization_parameters.get_parameter("beam_manager_types")
        beam_manager_type          = initialization_parameters.get_parameter(("beam_manager_type" if not transfer else "beam_manager_type_to"))
        beam_manager_type_key      = beam_manager_types[int(beam_manager_type)]
        beam_manager_configuration = initialization_parameters.get_parameter("beam_manager_configuration")

        beam_manager_type_configuration  = beam_manager_configuration[beam_manager_type_key]
        beam_manager_ids                 = beam_manager_type_configuration["beam_manager_ids"]
        if not transfer: beam_manager_id = beam_manager_type_configuration["beam_manager_id"]
        else:            beam_manager_id = initialization_parameters.get_parameter("beam_manager_id_to")
        beam_manager_id_key              = beam_manager_ids[int(beam_manager_id)]

        return beam_manager_id_key, beam_manager_type_key, platform_key

    def _get_motion_manager_and_pointers(self, initialization_parameters: ScriptData) -> tuple[IMotionManager, Any, Any, Any]:
        beam_manager_id_key, beam_manager_type_key, platform_key = self._get_beam_manager_pointers(initialization_parameters)

        motion_manager_full_id = Keys.compose_manager_key(beamline_id=self._beamline_id,
                                                          platform=platform_key,
                                                          beam_manager_type=beam_manager_type_key,
                                                          beam_manager_id=beam_manager_id_key,
                                                          manager_key=Keys.Managers.MotionManager) \
            if platform_key == Keys.Platforms.DigitalTwin else \
            Keys.compose_manager_key(beamline_id=self._beamline_id,
                                     platform=platform_key,
                                     manager_key=Keys.Managers.MotionManager)

        try:
            motion_manager = create_motion_manager(motion_manager_id=motion_manager_full_id)
        except:
            raise ValueError(f"Motion Manager {motion_manager_full_id} not supported")

        return motion_manager, beam_manager_id_key, beam_manager_type_key, platform_key

    def get_configuration(self) -> ScriptData:
        return generate_initialization_parameters_from_ini(ini=self._ini)

    def save_configuration(self, initialization_parameters: ScriptData):
        set_ini_from_initialization_parameters(initialization_parameters, self._ini)
        self._ini.push()

    def load_motors_info(self, initialization_parameters: ScriptData, return_motion_manager=False) -> MotorsInfoLegacy:
        motion_manager, _, _, _ = self._get_motion_manager_and_pointers(initialization_parameters)

        if not return_motion_manager: return copy.deepcopy(motion_manager.get_motors_info())
        else:                         return copy.deepcopy(motion_manager.get_motors_info()), motion_manager

    def save_motors_info(self, new_motors_info: MotorsInfoLegacy, initialization_parameters: ScriptData, motion_manager=None):
        motion_manager, beam_manager_id_key, beam_manager_type_key, platform_key = self._get_motion_manager_and_pointers(initialization_parameters)

        motion_manager_full_id = Keys.compose_manager_key(beamline_id=self._beamline_id,
                                                          platform=platform_key,
                                                          beam_manager_type=beam_manager_type_key,
                                                          beam_manager_id=beam_manager_id_key,
                                                          manager_key=Keys.Managers.MotionManager) \
            if platform_key == Keys.Platforms.DigitalTwin else \
                                 Keys.compose_manager_key(beamline_id=self._beamline_id,
                                                          platform=platform_key,
                                                          manager_key=Keys.Managers.MotionManager)

        if motion_manager is None:
            try: motion_manager = create_motion_manager(motion_manager_id=motion_manager_full_id)
            except: raise ValueError(f"Motion Manager {motion_manager_full_id} not supported")

        current_motors_info = motion_manager.get_motors_info()
        for motor_id in current_motors_info.get_motor_ids():
            current_motors_info.add_motor_info(motor_id, copy.deepcopy(new_motors_info.get_motor_info(motor_id)))

        motion_manager.to_json(f"beamline_{self._beamline_id}_motion_manager.json")

 # ----------------------------------------------------------------------------
 # ----------------------------------------------------------------------------
 # ----------------------------------------------------------------------------
 # ----------------------------------------------------------------------------

# EXECUTION AS SCRIPT OR BLUESKY PLAN
class ConfigurationManager(AbstractConfigurationManager):
    def __init__(self, application_name: str, working_directory: str, beamline_id: str, **kwargs):
        super(ConfigurationManager, self).__init__(application_name, working_directory, beamline_id, **kwargs)

# QT APPLICATION: BATCH OR GUI
class QtConfigurationManager(AbstractConfigurationManager, QObject):
    configuration_saved = pyqtSignal()
    motors_info_saved   = pyqtSignal()

    def __init__(self, application_name: str, working_directory: str, beamline_id: str, **kwargs):
        QObject.__init__(self)
        AbstractConfigurationManager.__init__(self, application_name, working_directory, beamline_id, **kwargs)

    @synchronized_method
    def save_motors_info(self, new_motors_info: MotorsInfoLegacy, initialization_parameters: ScriptData, motion_manager=None):
        super(QtConfigurationManager, self).save_motors_info(new_motors_info, initialization_parameters)
        self.motors_info_saved.emit()

    @synchronized_method
    def save_configuration(self, initialization_parameters: ScriptData):
        super(QtConfigurationManager, self).save_configuration(initialization_parameters)
        self.configuration_saved.emit()

