#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #

import sys

import numpy as np

from aps.common.plot import gui
from aps.common.plot.gui import MessageDialog
from aps.common.widgets.generic_widget import GenericWidget
from aps.common.widgets.congruence import *
from aps.common.singleton import synchronized_method
from aps.common.scripts.script_data import ScriptData

from matplotlib.figure import Figure
from matplotlib.ticker import FuncFormatter
import cmasher as cmm
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar

from AnyQt.QtWidgets import QHBoxLayout, QVBoxLayout, QTableWidget, QTableWidgetItem, QScrollArea
from AnyQt.QtCore import QRect, Qt
from AnyQt.QtGui import QFont, QPalette, QColor, QGuiApplication

from aps.ai.beamline_controller.legacy.common.legacy_keys import Keys
from aps.ai.beamline_controller.legacy.agent.optimization.facade import WarmStartStrategy, WarmStartDataType
from aps.ai.beamline_controller.legacy.agent.optimization.decorators.direct_beam_image_decorator import DirectBeamImageOptimizationCriteria
from aps.ai.beamline_controller.legacy.agent.optimization.decorators.wavefront_analysis_decorator import WavefrontAnalysisOptimizationCriteria
from aps.ai.beamline_controller.legacy.agent.optimization.decorators.speckle_analysis_decorator import SpeckleAnalysisOptimizationCriteria

from aps.beamline_driver.motion_management.facade import MotorsInfoLegacy, MotorInfoLegacy, Units, MotorType
from aps.beamline_driver.beam_management.abstract_beam_manager import DirectBeamImageProperties, WavefrontAnalysisProperties, SpeckleAnalysisProperties

class BeamlineControllerWidget(GenericWidget):
    def __init__(self, parent, application_name=None, **kwargs):
        self._log_stream_widget             = kwargs["log_stream_widget"]
        self._working_directory             = kwargs["working_directory"]
        self._beamline_id                   = kwargs["beamline_id"]
        self._available_beam_managers       = kwargs["available_beam_managers"]
        self._initialization_parameters     = kwargs["initialization_parameters"]

        # METHODS
        self._start_ai_agent                                         = kwargs["start_ai_agent_method"]
        self._close                                                  = kwargs["close_method"]
        self._abort                                                  = kwargs["abort_method"]
        self._get_result                                             = kwargs["get_result_method"]
        self._get_initialization_parameters                          = kwargs["get_initialization_parameters_method"]
        self._get_pareto_trial_number                                = kwargs["get_pareto_trial_number_method"]
        self._get_trial                                              = kwargs["get_trial_method"]
        self._get_optimization_history                               = kwargs["get_optimization_history_method"]
        self._move_motors_to_trial_data                              = kwargs["move_motors_to_trial_data_method"]
        self._load_motors_info                                       = kwargs["load_motors_info_method"]
        self._save_motors_info                                       = kwargs["save_motors_info_method"]
        self._set_current_motor_positions_as_initial_points          = kwargs["set_current_motor_positions_as_initial_points"]
        self._move_motors_to_initial_points                          = kwargs["move_motors_to_initial_points"]
        self._transfer_current_position_to_beam_manager_search_space = kwargs["transfer_current_position_to_beam_manager_search_space"]

        self._set_values_from_initialization_parameters()

        self.total_iterations_i  = 0
        self.total_iterations_f  = 0
        self.pareto_events       = None
        self.pareto_selection_2  = 0
        self.selected_event      = 0
        self.use_range           = 0
        self.xrange_i            = 0.0
        self.xrange_f            = 0.0
        self.yrange_i            = 0.0
        self.yrange_f            = 0.0

        self.motors = 0
        self.search_range_from = 0.0
        self.search_range_to   = 0.0
        self.search_transfer_range_from = 0.0
        self.search_transfer_range_to   = 0.0
        self.initial_position  = 0.0
        self.shift_from_ideal  = 0.0
        self.boundary_from     = 0.0
        self.boundary_to       = 0.0
        self.resolution        = 0.0
        self.repeatability     = 0.0
        self.legacy_id_get     = "<>"
        self.legacy_id_set     = "<>"
        self.units             = 0
        self.motor_type        = 0
        self.optimized         = 1

        self.__current_motors_info: MotorsInfoLegacy = None

        super(BeamlineControllerWidget, self).__init__(parent=parent, application_name=application_name, **kwargs)

        self.__is_init = True

    def _set_values_from_initialization_parameters(self):
        self.working_directory = self._working_directory
        self.beamline_id       = self._beamline_id

        initialization_parameters: ScriptData = self._initialization_parameters

        # protected/private elements are for storing information and won't be used as fields
        # public elements are fields

        self.real_time_data      = initialization_parameters.get_parameter("real_time_data", 0)
        self.capture_stdout      = initialization_parameters.get_parameter("capture_stdout", 0)
        self.save_beams          = initialization_parameters.get_parameter("save_beams", 1)

        self._ai_types_combo_items = initialization_parameters.get_parameter("ai_types_combo")
        self._ai_types             = initialization_parameters.get_parameter("ai_types")
        self.ai_type               = initialization_parameters.get_parameter("ai_type", 0)

        # -------------------------------- Optimization

        self._optimizer_types_combo_items = initialization_parameters.get_parameter("optimizer_types_combo")
        self._optimizer_types    = initialization_parameters.get_parameter("optimizer_types")
        self.optimizer_type     = initialization_parameters.get_parameter("optimizer_type", 0)

        self._optimizer_type_configuration = initialization_parameters.get_parameter("optimizer_type_configuration")
        self._warm_start_configuration     = initialization_parameters.get_parameter("warm_start_configuration")
        self._neural_network_configuration = initialization_parameters.get_parameter("neural_network_configuration")

        self._optimizer_names_combo_items = {optimizer_type: self._optimizer_type_configuration[optimizer_type]["names_combo"] for optimizer_type in self._optimizer_types}
        self._optimizer_names             = {optimizer_type: self._optimizer_type_configuration[optimizer_type]["names"]       for optimizer_type in self._optimizer_types}

        self.optimizer_name_mobo = self._optimizer_type_configuration[Keys.OptimizerType.MOBO].get("name", 0)
        self.optimizer_name_sonl = self._optimizer_type_configuration[Keys.OptimizerType.SONL].get("name", 0)
        self.optimizer_name_sobo = self._optimizer_type_configuration[Keys.OptimizerType.SOBO].get("name", 0)

        optimizer_name_key_mobo = self._optimizer_names[Keys.OptimizerType.MOBO][int(self.optimizer_name_mobo)]
        optimizer_name_key_sonl = self._optimizer_names[Keys.OptimizerType.SONL][int(self.optimizer_name_sonl)]
        optimizer_name_key_sobo = self._optimizer_names[Keys.OptimizerType.SOBO][int(self.optimizer_name_sobo)]

        optimizer_configuration_mobo = self._optimizer_type_configuration[Keys.OptimizerType.MOBO]["optimizer_configuration"]
        optimizer_configuration_sonl = self._optimizer_type_configuration[Keys.OptimizerType.SONL]["optimizer_configuration"]
        optimizer_configuration_sobo = self._optimizer_type_configuration[Keys.OptimizerType.SOBO]["optimizer_configuration"]

        self._acquisition_function_mobo_combo_items = {name : optimizer_configuration_mobo[name].get("acquisition_functions") for name in self._optimizer_names[Keys.OptimizerType.MOBO]}
        self._acquisition_function_sobo_combo_items = {name : optimizer_configuration_sobo[name].get("acquisition_functions") for name in self._optimizer_names[Keys.OptimizerType.SOBO]}

        self.acquisition_function_mobo = optimizer_configuration_mobo[optimizer_name_key_mobo].get("acquisition_function", 0)
        self.sobol_iterations_mobo     = optimizer_configuration_mobo[optimizer_name_key_mobo].get("sobol_iterations", 20)
        self.mobo_iterations           = optimizer_configuration_mobo[optimizer_name_key_mobo].get("mobo_iterations", 100)
        self.pareto_selection          = optimizer_configuration_mobo[optimizer_name_key_mobo].get("pareto_selection", 0)

        self.max_iterations            = optimizer_configuration_sonl[optimizer_name_key_sonl].get("max_iterations", 50)
        self.x_absolute_change         = optimizer_configuration_sonl[optimizer_name_key_sonl].get("x_absolute_change", 1e-8)
        self.f_absolute_change         = optimizer_configuration_sonl[optimizer_name_key_sonl].get("f_absolute_change", 1e-8)

        self.acquisition_function_sobo = optimizer_configuration_sobo[optimizer_name_key_sobo].get("acquisition_function", 0)
        self.sobol_iterations_sobo     = optimizer_configuration_sobo[optimizer_name_key_sobo].get("sobol_iterations", 20)
        self.sobo_iterations           = optimizer_configuration_sobo[optimizer_name_key_sobo].get("sobo_iterations", 100)

        self.move_motors_on_best_trial = initialization_parameters.get_parameter("move_motors_on_best_trial", 0)

        self._optimization_types_combo_items = initialization_parameters.get_parameter("optimization_types_combo")
        self.optimization_type               = initialization_parameters.get_parameter("optimization_type", 0)

        self._warm_start_home_directory_types_combo_items = self._warm_start_configuration.get("warm_start_home_directory_types_combo")
        self._warm_start_data_types_combo_items           = self._warm_start_configuration.get("warm_start_data_types_combo")
        self._warm_start_strategies_combo_items           = self._warm_start_configuration.get("warm_start_strategies_combo")
        self._warm_start_strategies                       = self._warm_start_configuration.get("warm_start_strategies")

        self.warm_start_home_directory_type              = self._warm_start_configuration.get("warm_start_home_directory_type", 0)
        self.warm_start_home_directory                   = self._warm_start_configuration.get("warm_start_home_directory", os.path.abspath(os.curdir))
        self.warm_start_data_type                        = self._warm_start_configuration.get("warm_start_data_type", WarmStartDataType.PARETO_FRONTIERS)
        self.warm_start_strategy                         = self._warm_start_configuration.get("warm_start_strategy", WarmStartStrategy.MAXIMUM_EXTENSION)

        self._warm_start_expansion_factors               = self._warm_start_configuration.get("warm_start_expansion_factors", {self._warm_start_strategies[0] : [0.0, 0.01],
                                                                                                                               self._warm_start_strategies[1] : [0.1, 1.5]})

        warm_start_expansion_factors = self._warm_start_expansion_factors[self._warm_start_strategies[self.warm_start_strategy]]

        self.warm_start_search_space_expansion_factor  = warm_start_expansion_factors[0]
        self.warm_start_loss_expansion_factor          = warm_start_expansion_factors[1]

        self.use_warm_start_search_space                 = self._warm_start_configuration.get("use_warm_start_search_space", 1)
        self.use_warm_start_hypervolume_reference_points = self._warm_start_configuration.get("use_warm_start_hypervolume_reference_points", 1)

        self.save_warm_start_data                        = int(initialization_parameters.get_parameter("save_warm_start_data", 0))

        # -------------------------------- NN

        self._neural_network_model_from_combo_items           = self._neural_network_configuration.get("neural_network_model_from_combo")
        self._neural_network_data_types_combo_items           = self._neural_network_configuration.get("neural_network_data_types_combo")

        self.neural_network_model_from          = self._neural_network_configuration.get("neural_network_model_from", 0)
        self.neural_network_trained_model_file  = self._neural_network_configuration.get("neural_network_trained_model_file", "")
        self.neural_network_home_directory      = self._neural_network_configuration.get("neural_network_home_directory", os.path.abspath(os.curdir))
        self.neural_network_data_type           = self._neural_network_configuration.get("neural_network_data_type", 2)

        neural_network_parameters = self._neural_network_configuration.get("neural_network_parameters", {})

        self.learning_rate    = neural_network_parameters.get("learning_rate", 1e-6)
        self.weight_decay     = neural_network_parameters.get("weight_decay", 1e-5)
        self.total_epochs     = neural_network_parameters.get("total_epochs", 5000)
        self.patience         = neural_network_parameters.get("patience", 50)
        self.train_batch_size = neural_network_parameters.get("train_batch_size", 2048)


        # -------------------------------- Optimization Criteria

        self._platform_combo_items = initialization_parameters.get_parameter("platforms_combo")

        self._platforms = initialization_parameters.get_parameter("platforms")
        self.platform   = initialization_parameters.get_parameter("platform", 1)

        self._beam_manager_type_combo_items = initialization_parameters.get_parameter("beam_manager_types_combo")

        self._beam_manager_types = initialization_parameters.get_parameter("beam_manager_types")
        self.beam_manager_type = initialization_parameters.get_parameter("beam_manager_type", 0)
        beam_manager_type_key = self._beam_manager_types[int(self.beam_manager_type)]

        self._beam_manager_configuration = initialization_parameters.get_parameter("beam_manager_configuration")

        self.beam_manager_id              = self._beam_manager_configuration[beam_manager_type_key]["beam_manager_id"]

        self.platform_to          = self.platform
        self.beam_manager_type_to = self.beam_manager_type
        self.beam_manager_id_to   = self.beam_manager_id

    def _get_beam_manager_item_keys(self, item_key):
        platform_key          = self._platforms[int(self.platform)]
        beam_manager_type_key = self._beam_manager_types[int(self.beam_manager_type)]

        beam_manager_type_configuration = self._beam_manager_configuration[beam_manager_type_key]
        beam_manager_ids    = beam_manager_type_configuration["beam_manager_ids"]

        if self.beam_manager_id < len(beam_manager_ids):
            beam_manager_id_key = beam_manager_ids[int(self.beam_manager_id)]
        else:
            self.beam_manager_id = 0
            beam_manager_id_key  = beam_manager_ids[0]

        item = beam_manager_type_configuration[item_key][platform_key].get(beam_manager_id_key, {})

        return platform_key, beam_manager_type_key, beam_manager_id_key, item

    def _get_objectives_keys(self):
        return self._get_beam_manager_item_keys("objectives")

    def _get_properties_keys(self):
        return self._get_beam_manager_item_keys("properties")

    def get_acquisition_functions_mobo_combo_items(self):
        optimizer_name_key_mobo = self._optimizer_names[Keys.OptimizerType.MOBO][int(self.optimizer_name_mobo)]

        return self._acquisition_function_mobo_combo_items[optimizer_name_key_mobo]

    def get_acquisition_functions_sobo_combo_items(self):
        optimizer_name_key_sobo = self._optimizer_names[Keys.OptimizerType.SOBO][int(self.optimizer_name_sobo)]

        return self._acquisition_function_sobo_combo_items[optimizer_name_key_sobo]

    def get_plot_tab_name(self): return self._beamline_id + " Optics Controller: Multi-Stage AI-driven Autoalignment System"

    def build_widget(self, **kwargs):
        geom = QGuiApplication.primaryScreen().availableGeometry()

        try:    widget_width = kwargs["widget_width"]
        except: widget_width = min(1450, geom.width()*0.98)
        try:    widget_height = kwargs["widget_height"]
        except:
            if sys.platform == 'darwin' : widget_height = min(750, geom.height()*0.95)
            else:                         widget_height = min(850, geom.height()*0.95)
        self.setGeometry(QRect(10, 10, widget_width, widget_height))
        self.setFixedWidth(int(widget_width))
        self.setFixedHeight(int(widget_height))

        layout = QHBoxLayout()
        layout.setAlignment(Qt.AlignLeft)
        self.setLayout(layout)

        main_box_width = 450

        main_box = gui.widgetBox(self, "", width=main_box_width, height=self.height() - 20)

        self._out_box     = gui.widgetBox(self, "", width=self.width() - main_box_width - 20, height=self.height() - 20, orientation="vertical")
        self._bl_box      = gui.widgetBox(self._out_box, "", width=self._out_box.width(), height=50)

        tab_box    = gui.widgetBox(self._out_box, "", width=self._out_box.width(), height=self._out_box.height() - 55, orientation="vertical")
        self._out_tab_widget = gui.tabWidget(tab_box)

        self._out_tab_0 = gui.createTabPage(self._out_tab_widget, "Log")
        self._out_tab_1 = gui.createTabPage(self._out_tab_widget, "Result")
        self._out_tab_2 = gui.createTabPage(self._out_tab_widget, "Process History")

        self._log_box     = gui.widgetBox(self._out_tab_0, "Log", width=tab_box.width() - 20, height=tab_box.height() - 40)
        self._result_box  = gui.widgetBox(self._out_tab_1, "")
        self._history_box = gui.widgetBox(self._out_tab_2, "")

        self._result_figure = Figure(figsize=[9.65, 5.9], constrained_layout=True)
        self._result_figure_canvas = FigureCanvas(self._result_figure)
        self._result_scroll = QScrollArea(self._result_box)
        self._result_scroll.setWidget(self._result_figure_canvas)
        self._result_box.layout().addWidget(NavigationToolbar(self._result_figure_canvas, self))
        self._result_box.layout().addWidget(self._result_scroll)

        self._history_figure_canvas = FigureCanvas(Figure(figsize=[14, 10], constrained_layout=True))
        self._history_scroll = QScrollArea(self._history_box)
        self._history_scroll.setWidget(self._history_figure_canvas)
        self._history_box.layout().addWidget(NavigationToolbar(self._history_figure_canvas, self))
        self._history_box.layout().addWidget(self._history_scroll)

        self.le_beamline_id = gui.lineEdit(self._bl_box, self, "beamline_id", " ", labelWidth=self._out_box.width(), controlWidth=100, orientation='horizontal', valueType=str)
        self.le_beamline_id.setReadOnly(True)
        font = QFont(self.le_beamline_id.font())
        font.setBold(True)
        font.setItalic(False)
        font.setPixelSize(25)
        self.le_beamline_id.setFont(font)
        self.le_beamline_id.setAlignment(Qt.AlignRight)
        self.le_beamline_id.setStyleSheet("QLineEdit {color : darkgreen; background : rgb(243, 240, 160); text-align : right}")

        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignCenter)
        self._log_box.setLayout(layout)
        if not self._log_stream_widget is None:
            self._log_box.layout().addWidget(self._log_stream_widget.get_widget())
            self._log_stream_widget.set_widget_size(width=self._log_box.width() - 15, height=self._log_box.height() - 35)
        else:
            self._log_box.layout().addWidget(QLabel("Log on file only"))


        button_box = gui.widgetBox(main_box, "", width=main_box.width(), orientation='horizontal')
        button_box.layout().setAlignment(Qt.AlignCenter)

        self._start_ai_agent_button = gui.button(button_box, None, "Start AI Agent", callback=self._optimize_callback, width=int(0.33 * main_box.width() - 3), height=35)
        abort_button          = gui.button(button_box, None, "Interrupt", callback=self._abort_callback, width=int(0.33*main_box.width()-3), height=35)
        exit_button           = gui.button(button_box, None, "Exit GUI", callback=self._close_callback, width=int(0.34*main_box.width()-3), height=35)

        font = QFont(abort_button.font())
        font.setBold(True)
        abort_button.setFont(font)
        palette = QPalette(abort_button.palette())
        palette.setColor(QPalette.ButtonText, QColor('Red'))
        abort_button.setPalette(palette)

        font = QFont(exit_button.font())
        font.setBold(False)
        font.setItalic(True)
        exit_button.setFont(font)
        palette = QPalette(exit_button.palette())
        palette.setColor(QPalette.ButtonText, QColor('Dark Blue'))
        exit_button.setPalette(palette)

        gui.separator(main_box)

        tab_widget = gui.tabWidget(main_box)
        ai_settings_tab      = gui.createTabPage(tab_widget, "AI Settings")
        driver_settings_tab  = gui.createTabPage(tab_widget, "Driver Settings")
        results_analysis_tab = gui.createTabPage(tab_widget, "Result Analysis")
        general_settings_tab = gui.createTabPage(tab_widget, "General Settings")

        labels_width = 350

        # ------------------------------------------------------------
        # AI SETTING
        ai_box_1 = gui.widgetBox(ai_settings_tab, "AI", width=main_box.width() - 15, height=main_box.height() - 90, orientation='vertical', addSpace=False)

        if sys.platform == 'darwin':
            general_setting_box_1 = gui.widgetBox(general_settings_tab, "GUI", width=main_box.width() - 15, height=140, orientation='vertical', addSpace=False)
            general_setting_box_2 = gui.widgetBox(general_settings_tab, "Runtime", width=main_box.width() - 15, height=100, orientation='vertical', addSpace=False)
        else:
            general_setting_box_1 = gui.widgetBox(general_settings_tab, "GUI", width=main_box.width() - 15, height=150, orientation='vertical', addSpace=False)
            general_setting_box_2 = gui.widgetBox(general_settings_tab, "Runtime", width=main_box.width() - 15, height=110, orientation='vertical', addSpace=False)

        # -------------------------

        self.cb_ai_type = gui.comboBox(ai_box_1, self, "ai_type", label="AI Type", items=["Optimization", "Neural Network"], orientation="horizontal", callback=self._set_ai_type)

        gui.separator(ai_box_1)

        if sys.platform == 'darwin':
            self._opt_box = gui.widgetBox(ai_box_1, "", width=ai_box_1.width() - 20, height=265, orientation='vertical', addSpace=False)
            self._nn_box  = gui.widgetBox(ai_box_1, "Neural Network Setting", width=ai_box_1.width() - 20, height=265, orientation='vertical', addSpace=False)
        else:
            self._opt_box = gui.widgetBox(ai_box_1, "", width=ai_box_1.width() - 20, height=295, orientation='vertical', addSpace=False)
            self._nn_box  = gui.widgetBox(ai_box_1, "Neural Network Setting", width=ai_box_1.width() - 20, height=295, orientation='vertical', addSpace=False)

        # -------------------------------- Optimization

        tab_widget = gui.tabWidget(self._opt_box)

        self._opt_tab      = gui.createTabPage(tab_widget, "Optimization Setting")
        self._transfer_tab = gui.createTabPage(tab_widget, "Transfer Learning")

        self.cb_optimizer_type = gui.comboBox(self._opt_tab, self, "optimizer_type", label="Optimizer Type", labelWidth=250,
                                              items=self._optimizer_types_combo_items, orientation="horizontal",
                                              callback=self._set_optimizer_type)

        self._mobo_optimizers_box_1 = gui.widgetBox(self._opt_tab, "", width=ai_box_1.width() - 32, height=23, orientation='vertical', addSpace=False)
        self._sonl_optimizers_box_1   = gui.widgetBox(self._opt_tab, "", width=ai_box_1.width() - 32, height=23, orientation='vertical', addSpace=False)
        self._sobo_optimizers_box_1 = gui.widgetBox(self._opt_tab, "", width=ai_box_1.width() - 32, height=23, orientation='vertical', addSpace=False)

        self.cb_mobo_optimizers = gui.comboBox(self._mobo_optimizers_box_1, self, "optimizer_name_mobo", label="Optimizer Name", items=self._optimizer_names_combo_items[Keys.OptimizerType.MOBO], orientation="horizontal", callback=self._set_optimizer_name)
        self.cb_sonl_optimizers = gui.comboBox(self._sonl_optimizers_box_1, self, "optimizer_name_sonl", label="Optimizer Name", items=self._optimizer_names_combo_items[Keys.OptimizerType.SONL], orientation="horizontal", callback=self._set_optimizer_name)
        self.cb_sobo_optimizers = gui.comboBox(self._sobo_optimizers_box_1, self, "optimizer_name_sobo", label="Optimizer Name", items=self._optimizer_names_combo_items[Keys.OptimizerType.SOBO], orientation="horizontal", callback=self._set_optimizer_name)

        # MOBO -----------------------------

        if sys.platform == 'darwin':
            self._mobo_optimizers_box_2 = gui.widgetBox(self._opt_tab, "", width=ai_box_1.width() - 32, height=105, orientation='vertical', addSpace=False)
        else:
            self._mobo_optimizers_box_2 = gui.widgetBox(self._opt_tab, "", width=ai_box_1.width() - 32, height=125, orientation='vertical', addSpace=False)

        self.cb_acquisition_function_mobo_1 = gui.comboBox(self._mobo_optimizers_box_2, self, "acquisition_function_mobo", label="Acquisition Function", items=[], orientation="horizontal")
        self.le_sobol_iterations_mobo_1     = gui.lineEdit(self._mobo_optimizers_box_2, self, "sobol_iterations_mobo", "Sobol iterations", labelWidth=labels_width, orientation='horizontal', controlWidth=50, valueType=int)
        self.le_mobo_iterations_1           = gui.lineEdit(self._mobo_optimizers_box_2, self, "mobo_iterations", "MOBO iterations", labelWidth=labels_width, orientation='horizontal', controlWidth=50, valueType=int)
        self.cb_pareto_selection_1          = gui.comboBox(self._mobo_optimizers_box_2, self, "pareto_selection", label="Pareto Best Trial", items=["Nash Equilibrium", "Most Intense", "Narrowest", "Closest to Center"], orientation="horizontal", callback=self._set_pareto_selection_1)

        if sys.platform == 'darwin':
            self._mobo_optimizers_box_3 = gui.widgetBox(self._opt_tab, "", width=ai_box_1.width() - 32, height=105, orientation='vertical', addSpace=False)
        else:
            self._mobo_optimizers_box_3 = gui.widgetBox(self._opt_tab, "", width=ai_box_1.width() - 32, height=125, orientation='vertical', addSpace=False)

        self.cb_acquisition_function_mobo_2 = gui.comboBox(self._mobo_optimizers_box_3, self, "acquisition_function_mobo", label="Acquisition Function", items=[], orientation="horizontal")
        self.le_sobol_iterations_mobo_2     = gui.lineEdit(self._mobo_optimizers_box_3, self, "sobol_iterations_mobo", "Random iterations", labelWidth=labels_width, orientation='horizontal', controlWidth=50, valueType=int)
        self.le_mobo_iterations_2           = gui.lineEdit(self._mobo_optimizers_box_3, self, "mobo_iterations", "MOBO iterations", labelWidth=labels_width, orientation='horizontal', controlWidth=50, valueType=int)

        # SONL -----------------------------

        if sys.platform == 'darwin':
            self._sonl_optimizers_box_2 = gui.widgetBox(self._opt_tab, "", width=ai_box_1.width() - 32, height=105, orientation='vertical', addSpace=False)
        else:
            self._sonl_optimizers_box_2 = gui.widgetBox(self._opt_tab, "", width=ai_box_1.width() - 32, height=125, orientation='vertical', addSpace=False)

        self.le_max_iterations    = gui.lineEdit(self._sonl_optimizers_box_2, self, "max_iterations", "Max iterations per Step", labelWidth=labels_width, orientation='horizontal', controlWidth=50, valueType=int)
        self.le_x_absolute_change = gui.lineEdit(self._sonl_optimizers_box_2, self, "x_absolute_change", "X Absolute Change", labelWidth=labels_width, orientation='horizontal', controlWidth=50, valueType=float)
        self.le_f_absolute_change = gui.lineEdit(self._sonl_optimizers_box_2, self, "f_absolute_change", "F Absolute Change", labelWidth=labels_width, orientation='horizontal', controlWidth=50, valueType=float)

        # SOBO -----------------------------

        if sys.platform == 'darwin':
            self._sobo_optimizers_box_2 = gui.widgetBox(self._opt_tab, "", width=ai_box_1.width() - 32, height=105, orientation='vertical', addSpace=False)
        else:
            self._sobo_optimizers_box_2 = gui.widgetBox(self._opt_tab, "", width=ai_box_1.width() - 32, height=125, orientation='vertical', addSpace=False)

        self.cb_acquisition_function_sobo = gui.comboBox(self._sobo_optimizers_box_2, self, "acquisition_function_sobo", label="Acquisition Function", items=[], orientation="horizontal")
        self.le_sobol_iterations_sobo     = gui.lineEdit(self._sobo_optimizers_box_2, self, "sobol_iterations_sobo", "Sobol iterations", labelWidth=labels_width, orientation='horizontal', controlWidth=50, valueType=int)
        self.le_sobo_iterations           = gui.lineEdit(self._sobo_optimizers_box_2, self, "sobo_iterations", "SOBO iterations", labelWidth=labels_width, orientation='horizontal', controlWidth=50, valueType=int)

        # -----------------------------

        self.cb_optimization_type    = gui.comboBox(self._opt_tab, self, "optimization_type", label="Optimization Type", items=self._optimization_types_combo_items, orientation="horizontal", callback=self._set_optimization_type)
        self.cb_save_warm_start_data = gui.comboBox(self._opt_tab, self, "save_warm_start_data", label="Save Results as Warm Start", labelWidth=labels_width, items=["No", "Yes"], orientation="horizontal")

        # ---------------------------------------------------
        # Transfer learning

        self._ws_box = gui.widgetBox(self._transfer_tab, "", width=ai_box_1.width() - 32, height=240, orientation='vertical', addSpace=False)

        self.cb_warm_start_home_directory_type = gui.comboBox(self._ws_box, self, "warm_start_home_directory_type", label="Warm Start Home Directory", items=self._warm_start_home_directory_types_combo_items, orientation="horizontal", callback=self._set_warm_start_home_directory_type)

        self._warm_start_home_directory_box = gui.widgetBox(self._ws_box, "", width=ai_box_1.width() - 32, orientation='horizontal', addSpace=False)
        self.le_warm_start_home_directory   = gui.lineEdit(self._warm_start_home_directory_box, self, "warm_start_home_directory", "Data From", orientation='horizontal', valueType=str)
        gui.button(self._warm_start_home_directory_box, self, "...", width=30, callback=self._set_warm_start_home_directory)

        self.cb_warm_start_data_type                        = gui.comboBox(self._ws_box, self, "warm_start_data_type", label="Warm Start Data Type", items=self._warm_start_data_types_combo_items, orientation="horizontal", callback=self._set_warm_start_data_type)
        self.cb_use_warm_start_search_space                 = gui.comboBox(self._ws_box, self, "use_warm_start_search_space", label="Warm Start Search Space", labelWidth=labels_width, items=["No", "Yes"], orientation="horizontal")
        self.cb_use_warm_start_hypervolume_reference_points = gui.comboBox(self._ws_box, self, "use_warm_start_hypervolume_reference_points", label="Warm Start Hypervolume Reference Points", labelWidth=labels_width, items=["No", "Yes"], orientation="horizontal")
        self.cb_warm_start_strategy                         = gui.comboBox(self._ws_box, self, "warm_start_strategy", label="Warm Start Strategy", labelWidth=labels_width, items=self._warm_start_strategies_combo_items, orientation="horizontal", callback=self._set_warm_start_strategy)

        self.le_warm_start_search_space_expansion_factor = gui.lineEdit(self._ws_box, self, "warm_start_search_space_expansion_factor", "Search Space Coefficient", labelWidth=labels_width, orientation='horizontal', controlWidth=50, valueType=float)
        self.le_warm_start_loss_expansion_factor         = gui.lineEdit(self._ws_box, self, "warm_start_loss_expansion_factor", "Loss Coefficient", labelWidth=labels_width, orientation='horizontal', controlWidth=50, valueType=float)

        # -------------------------------- NN

        self.cb_neural_network_model_from = gui.comboBox(self._nn_box, self, "neural_network_model_from", label="Neural Network model from", labelWidth=250,
                                                         items=self._neural_network_model_from_combo_items, orientation="horizontal",
                                                         callback=self._set_neural_network_model_from)

        gui.separator(self._nn_box)

        self._neural_network_model_box_1   = gui.widgetBox(self._nn_box, "", width=ai_box_1.width() - 41, height=280, orientation='vertical', addSpace=False)
        self._neural_network_model_box_2   = gui.widgetBox(self._nn_box, "", width=ai_box_1.width() - 41, height=280, orientation='vertical', addSpace=False)

        self._neural_network_home_directory_box = gui.widgetBox(self._neural_network_model_box_1, "", width=ai_box_1.width() - 41, orientation='horizontal', addSpace=False)
        self.le_neural_network_home_directory  = gui.lineEdit(self._neural_network_home_directory_box, self, "neural_network_home_directory", "Data From", orientation='horizontal', valueType=str)
        gui.button(self._neural_network_home_directory_box, self, "...", width=30, callback=self._set_neural_network_home_directory)

        self.cb_neural_network_data_type = gui.comboBox(self._neural_network_model_box_1, self, "neural_network_data_type", label="Training Data Type", items=self._neural_network_data_types_combo_items, orientation="horizontal", callback=self._set_warm_start_data_type)

        gui.lineEdit(self._neural_network_model_box_1, self, "learning_rate",    "Learning Rate", labelWidth=labels_width-30, orientation='horizontal', valueType=float)
        gui.lineEdit(self._neural_network_model_box_1, self, "weight_decay",     "Weight Decay",  labelWidth=labels_width-30, orientation='horizontal', valueType=float)
        gui.lineEdit(self._neural_network_model_box_1, self, "total_epochs",     "Epochs",        labelWidth=labels_width-30, orientation='horizontal', valueType=int)
        gui.lineEdit(self._neural_network_model_box_1, self, "patience",         "Patience",      labelWidth=labels_width-30, orientation='horizontal', valueType=int)
        gui.lineEdit(self._neural_network_model_box_1, self, "train_batch_size", "Batch Size",    labelWidth=labels_width-30, orientation='horizontal', valueType=int)

        self._neural_network_trained_model_file_box = gui.widgetBox(self._neural_network_model_box_2, "", width=ai_box_1.width() - 41, orientation='horizontal', addSpace=False)
        self.le_neural_network_trained_model_file  = gui.lineEdit(self._neural_network_trained_model_file_box, self, "neural_network_trained_model_file", "Trained model", orientation='horizontal', valueType=str)
        gui.button(self._neural_network_trained_model_file_box, self, "...", width=30, callback=self._set_neural_network_trained_model_file)

        # ---------------------------------------------------

        gui.separator(ai_box_1)

        self.cb_platform          = gui.comboBox(ai_box_1, self, "platform", label="Platform", items=self._platform_combo_items, orientation="horizontal", callback=self._set_optimization_key)
        self.cb_beam_manager_type = gui.comboBox(ai_box_1, self, "beam_manager_type", label="Beam Properties", items=self._beam_manager_type_combo_items, orientation="horizontal", callback=self._set_optimization_key)
        self.cb_beam_manager_id   = gui.comboBox(ai_box_1, self, "beam_manager_id", label="Detector", items=[], orientation="horizontal", callback=self._set_objective_table)

        self._criteria_tab_widget = gui.tabWidget(ai_box_1)
        tab_0 = gui.createTabPage(self._criteria_tab_widget, "Objectives")
        tab_1 = gui.createTabPage(self._criteria_tab_widget, "Properties")

        self._objective_table = QTableWidget()
        self._property_table  = QTableWidget()
        tab_0.layout().addWidget(self._objective_table)
        tab_1.layout().addWidget(self._property_table)

        # ------------------------------------------------------------
        # Driver Setting

        driver_box_1 = gui.widgetBox(driver_settings_tab, "Driver", width=main_box.width() - 15, height=main_box.height() - 95, orientation='vertical', addSpace=False)

        gui.button(driver_box_1, None, "Load Motors Info from current settings", callback=self._load_motors_info_from_current_setting, width=0.95*driver_box_1.width(), height=30)

        gui.separator(driver_box_1, height=10)

        self.cb_motors = gui.comboBox(driver_box_1, self, "motors", label="Motors", items=[], orientation="horizontal", callback=self._get_current_motor)

        gui.separator(driver_box_1)

        self.driver_box_input = gui.widgetBox(driver_box_1, "", width=driver_box_1.width() - 25, orientation='vertical', addSpace=False)

        self.cb_motor_type = gui.comboBox(self.driver_box_input, self, "motor_type", label="Type",  items=MotorType.get_labels_list(), orientation="horizontal", callback=self._set_current_motor)
        self.cb_units      = gui.comboBox(self.driver_box_input, self, "units",      label="Units", items=Units.get_labels_list(), orientation="horizontal", callback=self._set_current_motor)

        box = gui.widgetBox(self.driver_box_input, "", width=self.driver_box_input.width(), height=30, orientation='horizontal', addSpace=False)
        self.le_boundary_from = gui.lineEdit(box, self, value="boundary_from", label="Boundary:                    From", labelWidth=170, orientation='horizontal', controlWidth=100, valueType=float, callback=self._set_current_motor)
        self.le_boundary_to   = gui.lineEdit(box, self, value="boundary_to",   label="  To",           labelWidth=30,  orientation='horizontal', controlWidth=100, valueType=float, callback=self._set_current_motor)

        box = gui.widgetBox(self.driver_box_input, "", width=self.driver_box_input.width(), height=30, orientation='horizontal', addSpace=False)
        self.le_search_range_from = gui.lineEdit(box, self, "search_range_from", label="Search Range:             From", labelWidth=170, orientation='horizontal', controlWidth=100, valueType=float, callback=self._set_current_motor)
        self.le_search_range_to   = gui.lineEdit(box, self, "search_range_to",   label="  To", labelWidth=30, orientation='horizontal', controlWidth=100, valueType=float, callback=self._set_current_motor)

        box = gui.widgetBox(self.driver_box_input, "", width=self.driver_box_input.width(), height=30, orientation='horizontal', addSpace=False)
        self.le_search_transfer_range_from = gui.lineEdit(box, self, "search_transfer_range_from",     "Search Transfer Range: From", labelWidth=170, orientation='horizontal', controlWidth=100, valueType=float, callback=self._set_current_motor)
        self.le_search_transfer_range_to   = gui.lineEdit(box, self, "search_transfer_range_to", "  To", labelWidth=30, orientation='horizontal', controlWidth=100, valueType=float, callback=self._set_current_motor)

        self.le_initial_position  = gui.lineEdit(self.driver_box_input, self, "initial_position",  "Initial Position", labelWidth=300, orientation='horizontal', valueType=float, callback=self._set_current_motor)
        self.le_resolution        = gui.lineEdit(self.driver_box_input, self, "resolution",        "Step/Resolution",  labelWidth=300, orientation='horizontal', valueType=float, callback=self._set_current_motor)
        self.le_repeatability     = gui.lineEdit(self.driver_box_input, self, "repeatability",     "Repeatability",  labelWidth=300, orientation='horizontal', valueType=float, callback=self._set_current_motor)
        self.le_shift_from_ideal  = gui.lineEdit(self.driver_box_input, self, "shift_from_ideal",  "Shift from Ideal", labelWidth=300, orientation='horizontal', valueType=float, callback=self._set_current_motor)

        box = gui.widgetBox(self.driver_box_input, "", width=self.driver_box_input.width(), height=30, orientation='horizontal', addSpace=False)
        self.le_legacy_id_get = gui.lineEdit(box, self, "legacy_id_get", "Legacy ID: Read", labelWidth=95, orientation='horizontal', controlWidth=130, valueType=str, callback=self._set_current_motor)
        self.le_legacy_id_set = gui.lineEdit(box, self, "legacy_id_set", "  Write",         labelWidth=40, orientation='horizontal', controlWidth=130, valueType=str, callback=self._set_current_motor)

        self.cb_optimized = gui.checkBox(driver_box_1, self, "optimized", "Optimized", callback=self._set_current_motor)

        gui.separator(driver_box_1, height=10)

        save_button = gui.button(driver_box_1, None, "Save Motors Info", callback=self._save_motors_info_from_current_setting, width=0.95*driver_box_1.width(), height=40)

        font = QFont(save_button.font())
        font.setBold(True)
        font.setItalic(False)
        save_button.setFont(font)
        palette = QPalette(save_button.palette())
        palette.setColor(QPalette.ButtonText, QColor('Dark Blue'))
        save_button.setPalette(palette)

        gui.separator(driver_box_1, height=10)

        gui.button(driver_box_1, None, "Set Current Positions as Initial", callback=self._set_current_motor_positions_as_initial_points_of_motors_info, width=0.95*driver_box_1.width(), height=30)
        gui.button(driver_box_1, None, "Move Motors to Initial Positions", callback=self._move_motors_to_initial_points_of_motors_info, width=0.95*driver_box_1.width(), height=30)

        # ------------------------------------------------------------
        # Result Analysis

        if sys.platform == 'darwin': result_box_1 = gui.widgetBox(results_analysis_tab, "Current Result", width=main_box.width()-15, height=530, orientation='vertical', addSpace=False)
        else:                        result_box_1 = gui.widgetBox(results_analysis_tab, "Current Result", width=main_box.width()-15, height=560, orientation='vertical', addSpace=False)

        self.le_total_iterations_i = gui.lineEdit(result_box_1, self, "total_iterations_i", "Initial trial", labelWidth=labels_width, orientation='horizontal', valueType=int)
        self.le_total_iterations_i.setReadOnly(True)
        self.le_total_iterations_i.setStyleSheet("QLineEdit {color : black; background : rgb(243, 240, 160)}")
        self.le_total_iterations_f = gui.lineEdit(result_box_1, self, "total_iterations_f", "Final trial", labelWidth=labels_width, orientation='horizontal', valueType=int)
        self.le_total_iterations_f.setReadOnly(True)
        self.le_total_iterations_f.setStyleSheet("QLineEdit {color : black; background : rgb(243, 240, 160)}")

        self._pareto_events_box = gui.widgetBox(result_box_1, "", width=result_box_1.width() - 20, height=80, orientation='vertical', addSpace=False)

        pareto_ta_box = gui.widgetBox(self._pareto_events_box, "", width=result_box_1.width()- 20, height=50, orientation='horizontal', addSpace=False)
        gui.widgetLabel(pareto_ta_box, "Pareto Frontier", labelWidth=100)
        self.ta_pareto_events = gui.textArea(height=50, width=310, noWrap=False, readOnly=True)
        pareto_ta_box.layout().addWidget(self.ta_pareto_events)

        self.cb_pareto_selection_2 = gui.comboBox(self._pareto_events_box, self, "pareto_selection_2", label="Pareto Best Trial", items=["Nash Equilibrium", "Most Intense", "Narrowest", "Closest to Origin"], orientation="horizontal", callback=self._set_pareto_selection_2)

        gui.separator(result_box_1)

        self.le_selected_event     = gui.lineEdit(result_box_1, self, "selected_event", "Selected trial", labelWidth=labels_width, orientation='horizontal', valueType=int)
        self.cb_use_range          = gui.comboBox(result_box_1, self, "use_range", label="Plotting Range", labelWidth=300, items=["No", "Yes"], orientation="horizontal", callback=self._set_use_range)

        self.use_range_box_1 = gui.widgetBox(result_box_1, "", width=result_box_1.width(), height=60, orientation='horizontal', addSpace=False)
        self.use_range_box_2 = gui.widgetBox(result_box_1, "", width=result_box_1.width(), height=60, orientation='vertical', addSpace=False)

        box = gui.widgetBox(self.use_range_box_2, "", width=result_box_1.width(), height=30, orientation='horizontal', addSpace=False)
        self.le_xrange_i = gui.lineEdit(box, self, "xrange_i", "                    H Range from", labelWidth=170, orientation='horizontal', controlWidth=100, valueType=float)
        self.le_xrange_f = gui.lineEdit(box, self, "xrange_f", "  to", labelWidth=30, orientation='horizontal', controlWidth=100, valueType=float)

        box = gui.widgetBox(self.use_range_box_2, "", width=result_box_1.width(), height=30, orientation='horizontal', addSpace=False)
        self.le_yrange_i = gui.lineEdit(box, self, "yrange_i", "                    V Range from", labelWidth=170, orientation='horizontal', controlWidth=100, valueType=float)
        self.le_yrange_f = gui.lineEdit(box, self, "yrange_f", "  to", labelWidth=30, orientation='horizontal', controlWidth=100, valueType=float)

        gui.button(result_box_1, None, "Show Trial", callback=self._show_trial, width=result_box_1.width()-20)
        gui.separator(result_box_1, height=4)
        gui.button(result_box_1, None, "Move Motors to Selected Trial", callback=self._move_motors_to_selected_trial, width=result_box_1.width()-20)

        gui.separator(result_box_1, height=10)
        gui.button(result_box_1, None, "Transfer Selected Trial Motor Position as new Search Space", callback=self._transfer_selected_trial_motor_position, width=result_box_1.width()-20)

        box = gui.widgetBox(result_box_1, "Detector to Transfer", width=result_box_1.width()-20, height=120, orientation='vertical', addSpace=False)

        self.cb_platform_to          = gui.comboBox(box, self, "platform_to", label="Platform", items=self._platform_combo_items, orientation="horizontal", callback=self._set_optimization_key_to)
        self.cb_beam_manager_type_to = gui.comboBox(box, self, "beam_manager_type_to", label="Beam Properties", items=self._beam_manager_type_combo_items, orientation="horizontal", callback=self._set_optimization_key_to)
        self.cb_beam_manager_id_to   = gui.comboBox(box, self, "beam_manager_id_to", label="Detector", items=[], orientation="horizontal")

        # ------------------------------------------------------------
        # GENERAL SETTING
        self.cb_real_time_data = gui.checkBox(general_setting_box_1, self, "real_time_data", "Show Plots", callback=self._set_real_time_data)
        self.cb_capture_stdout = gui.checkBox(general_setting_box_1, self, "capture_stdout", "Capture StdOut")
        self.cb_save_beams     = gui.checkBox(general_setting_box_1, self, "save_beams", "Save Beam Data")

        self.le_working_directory = gui.lineEdit(general_setting_box_2, self, "working_directory", label="Working Directory", labelWidth=labels_width, valueType=str, orientation="vertical")
        self.le_working_directory.setReadOnly(True)

        self._set_ai_type()
        self._set_optimization_key()
        self._set_use_range()
        self._set_optimization_key_to()
        self._set_real_time_data()

        self.__is_init = False

    # -------------------------------------------------------------
    # GUI Setters

    def _set_neural_network_model_from(self):
        self._neural_network_model_box_1.setVisible(self.neural_network_model_from==0)
        self._neural_network_model_box_2.setVisible(self.neural_network_model_from==1)

    def _set_neural_network_home_directory(self):
        self.le_neural_network_home_directory.setText(
            gui.selectDirectoryFromDialog(self,
                                          previous_directory_path=self.neural_network_home_directory,
                                          start_directory=self.neural_network_home_directory)
        )

    def _set_neural_network_trained_model_file(self):
        self.le_neural_network_trained_model_file.setText(
            gui.selectFileFromDialog(self,
                                     previous_file_path=self.neural_network_trained_model_file,
                                     start_directory=self.neural_network_home_directory)
        )

    def _set_warm_start_home_directory_type(self):
        self._warm_start_home_directory_box.setEnabled(self.warm_start_home_directory_type==1)

    def _set_warm_start_home_directory(self):
        self.le_warm_start_home_directory.setText(
            gui.selectDirectoryFromDialog(self,
                                          previous_directory_path=self.warm_start_home_directory,
                                          start_directory=self.warm_start_home_directory)
        )

    def _set_warm_start_data_type(self):
        pass

    def _set_warm_start_strategy(self):
        warm_start_expansion_factors = self._warm_start_expansion_factors[self._warm_start_strategies[self.warm_start_strategy]]

        self.le_warm_start_search_space_expansion_factor.setText(str(warm_start_expansion_factors[0]))
        self.le_warm_start_loss_expansion_factor.setText(str(warm_start_expansion_factors[1]))

        self.le_warm_start_search_space_expansion_factor.setEnabled(self.warm_start_strategy==1)

    def _set_optimization_key(self):
        beam_manager_type_key           = self._beam_manager_types[int(self.beam_manager_type)]
        beam_manager_type_configuration = self._beam_manager_configuration[beam_manager_type_key]

        self.cb_beam_manager_id.clear()
        self.cb_beam_manager_id.addItems(beam_manager_type_configuration["beam_manager_ids_combo"])

        self.beam_manager_id = 0

        self._set_objective_table()
        self._set_property_table()

    def _set_optimization_key_to(self):
        beam_manager_type_key           = self._beam_manager_types[int(self.beam_manager_type_to)]
        beam_manager_type_configuration = self._beam_manager_configuration[beam_manager_type_key]

        self.cb_beam_manager_id_to.clear()
        self.cb_beam_manager_id_to.addItems(beam_manager_type_configuration["beam_manager_ids_combo"])

        self.beam_manager_id_to = 0

    def _set_objective_table(self):
        if   self.beam_manager_type == 0: criteria = DirectBeamImageOptimizationCriteria.to_list()
        elif self.beam_manager_type == 1: criteria = WavefrontAnalysisOptimizationCriteria.to_list()
        elif self.beam_manager_type == 2: criteria = SpeckleAnalysisOptimizationCriteria.to_list()
        else:                             criteria = [] # work in progress

        _, _, _, objectives = self._get_objectives_keys()

        self._objective_table.clear()
        self._objective_table.setColumnCount(5)
        self._objective_table.setHorizontalHeaderLabels(['Objective', 'Reference', 'Boundary', 'Weight', 'Exit'])
        font = self._objective_table.horizontalHeader().font()
        font.setPixelSize(10)
        self._objective_table.horizontalHeader().setFont(font)
        self._objective_table.setRowCount(len(criteria))
        self._objective_table.setColumnWidth(0, 200)
        self._objective_table.setColumnWidth(1, 55)
        self._objective_table.setColumnWidth(2, 55)
        self._objective_table.setColumnWidth(3, 55)
        self._objective_table.setColumnWidth(4, 55)

        for row, criterion in zip(range(len(criteria)), criteria):
            cb_criterion = QTableWidgetItem(criterion)
            cb_criterion.setText(criterion)
            font = cb_criterion.font()
            font.setPixelSize(10)
            cb_criterion.setFont(font)
            cb_criterion.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
            cb_criterion.setCheckState(Qt.Checked if criterion in objectives.keys() else Qt.Unchecked)
            self._objective_table.setItem(row, 0, cb_criterion)

            reference = str(objectives[criterion][0]) if criterion in objectives.keys() else "0.0"
            le_reference = QTableWidgetItem(reference)
            le_reference.setText(reference)
            font = le_reference.font()
            font.setPixelSize(10)
            le_reference.setFont(font)
            le_reference.setFlags(Qt.ItemIsEditable | Qt.ItemIsEnabled)
            self._objective_table.setItem(row, 1, le_reference)

            boundary = str(objectives[criterion][1]) if criterion in objectives.keys() else "0.0"
            le_boundary = QTableWidgetItem(boundary)
            le_boundary.setText(boundary)
            font = le_boundary.font()
            font.setPixelSize(10)
            le_boundary.setFont(font)
            le_boundary.setFlags(Qt.ItemIsEditable | Qt.ItemIsEnabled)
            self._objective_table.setItem(row, 2, le_boundary)

            weight = str(objectives[criterion][2]) if criterion in objectives.keys() else "1.0"
            le_weight = QTableWidgetItem(weight)
            le_weight.setText(weight)
            font = le_weight.font()
            font.setPixelSize(10)
            le_weight.setFont(font)
            le_weight.setFlags(Qt.ItemIsEditable | Qt.ItemIsEnabled)
            self._objective_table.setItem(row, 3, le_weight)

            exit = str(objectives[criterion][3]) if criterion in objectives.keys() else "0.0"
            le_exit = QTableWidgetItem(exit)
            le_exit.setText(exit)
            font = le_exit.font()
            font.setPixelSize(10)
            le_exit.setFont(font)
            le_exit.setFlags(Qt.ItemIsEditable | Qt.ItemIsEnabled)
            self._objective_table.setItem(row, 4, le_exit)

    def _set_property_table(self):
        if   self.beam_manager_type == 0: criteria = DirectBeamImageProperties.to_list()
        elif self.beam_manager_type == 1: criteria = WavefrontAnalysisProperties.to_list()
        elif self.beam_manager_type == 2: criteria = SpeckleAnalysisProperties.to_list()
        else:                             criteria = [] # work in progress

        _, _, _, properties = self._get_properties_keys()

        self._property_table.clear()
        self._property_table.setColumnCount(2)
        self._property_table.setHorizontalHeaderLabels(['Property', 'Target Value'])
        font = self._property_table.horizontalHeader().font()
        font.setPixelSize(10)
        self._property_table.horizontalHeader().setFont(font)
        self._property_table.setRowCount(len(criteria))
        self._property_table.setColumnWidth(0, 200)
        self._property_table.setColumnWidth(1, 110)

        for row, criterion in zip(range(len(criteria)), criteria):
            cb_criterion = QTableWidgetItem(criterion)
            cb_criterion.setText(criterion)
            font = cb_criterion.font()
            font.setPixelSize(10)
            cb_criterion.setFont(font)
            cb_criterion.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
            cb_criterion.setCheckState(Qt.Checked if criterion in properties.keys() else Qt.Unchecked)
            self._property_table.setItem(row, 0, cb_criterion)

            target = str(properties[criterion][0]) if criterion in properties.keys() else "0.0"
            le_target = QTableWidgetItem(target)
            le_target.setText(target)
            font = le_target.font()
            font.setPixelSize(10)
            le_target.setFont(font)
            le_target.setFlags(Qt.ItemIsEditable | Qt.ItemIsEnabled)
            self._property_table.setItem(row, 1, le_target)

    def _set_real_time_data(self):
        self._out_tab_1.setEnabled(self.real_time_data == 1)
        self._result_box.setVisible(self.real_time_data == 1)
        self._out_tab_2.setEnabled(self.real_time_data == 1)
        self._history_box.setVisible(self.real_time_data == 1)

    def _set_ai_type(self):
        self._opt_box.setVisible(self.ai_type==0)
        self._nn_box.setVisible(self.ai_type==1)

        self._pareto_events_box.setVisible(False)

        if self.ai_type==0:
            self._set_optimizer_type()
            self._objective_table.setEnabled(True)
            self._property_table.setEnabled(False)
            self._criteria_tab_widget.setCurrentIndex(0)
        elif self.ai_type==1:
            self._set_neural_network_model_from()
            self._objective_table.setEnabled(False)
            self._property_table.setEnabled(True)
            self._criteria_tab_widget.setCurrentIndex(1)


    def _set_optimizer_type(self):
        self._mobo_optimizers_box_1.setVisible(self.optimizer_type == 0)
        self._sonl_optimizers_box_1.setVisible(self.optimizer_type == 1)
        self._sobo_optimizers_box_1.setVisible(self.optimizer_type == 2)
        self._mobo_optimizers_box_2.setVisible(self.optimizer_type == 0)
        self._mobo_optimizers_box_3.setVisible(self.optimizer_type == 0)
        self._sonl_optimizers_box_2.setVisible(self.optimizer_type == 1)
        self._sobo_optimizers_box_2.setVisible(self.optimizer_type == 2)

        self._pareto_events_box.setVisible(self.optimizer_type == 0)

        self._set_optimizer_name()
        if not self.__is_init: self._set_save_warm_start_data()

    def _set_optimizer_name(self):
        if self.optimizer_type == 0:
            self._mobo_optimizers_box_2.setVisible(False)
            self._mobo_optimizers_box_3.setVisible(False)

            if self.optimizer_name_mobo in [0, 1]: # AX, Optuna
                self._mobo_optimizers_box_2.setVisible(True)
                self.cb_acquisition_function_mobo_1.clear()
                self.cb_acquisition_function_mobo_1.addItems(self.get_acquisition_functions_mobo_combo_items())
                self.cb_acquisition_function_mobo_1.setCurrentIndex(self.acquisition_function_mobo)
            else:
                self._mobo_optimizers_box_3.setVisible(True)
                self.cb_acquisition_function_mobo_2.clear()
                self.cb_acquisition_function_mobo_2.addItems(self.get_acquisition_functions_mobo_combo_items())
                self.cb_acquisition_function_mobo_2.setCurrentIndex(self.acquisition_function_mobo)

            if self.optimizer_name_mobo in [1, 2]:  # Optuna, BLOPTools
                self.optimization_type = 0
                self.cb_optimization_type.setCurrentIndex(0)
                self.le_sobol_iterations_mobo_1.setEnabled(True)
                self._transfer_tab.setEnabled(False)
            else:
                self.cb_optimization_type.setEnabled(True)
                self._set_optimization_type()
        elif self.optimizer_type == 1:
            if self.optimizer_name_sonl == 0:
                self.cb_optimization_type.setEnabled(True)
                self._set_optimization_type()
            else:
                self.optimization_type = 0
                self.cb_optimization_type.setCurrentIndex(0)
                self._transfer_tab.setEnabled(False)
        elif self.optimizer_type == 2:
            self._sobo_optimizers_box_2.setVisible(True)

            self.cb_acquisition_function_sobo.clear()
            self.cb_acquisition_function_sobo.addItems(self.get_acquisition_functions_sobo_combo_items())
            self.cb_acquisition_function_sobo.setCurrentIndex(self.acquisition_function_sobo)

            self.cb_optimization_type.setEnabled(True)
            self._set_optimization_type()

    def _set_optimization_type(self):
        if self.optimization_type==0: # Full Start
            self.le_sobol_iterations_mobo_1.setEnabled(True)
            self.le_sobol_iterations_mobo_2.setEnabled(True)
            self.le_sobol_iterations_sobo.setEnabled(True)

            self._transfer_tab.setEnabled(False)
        else:
            self.le_sobol_iterations_mobo_1.setEnabled(False)
            self.le_sobol_iterations_mobo_2.setEnabled(False)
            self.le_sobol_iterations_sobo.setEnabled(False)
            self._transfer_tab.setEnabled(True)

            if self.optimizer_type == 0: # MOBO
                self.cb_warm_start_home_directory_type.setEnabled(True)

                self.cb_use_warm_start_search_space.setEnabled(True)
                self.cb_use_warm_start_hypervolume_reference_points.setEnabled(True)
                self.le_warm_start_loss_expansion_factor.setEnabled(True)
            else:
                self.warm_start_home_directory_type = 1
                self.cb_warm_start_home_directory_type.setCurrentIndex(1)
                self.cb_warm_start_home_directory_type.setEnabled(False)

                self.cb_use_warm_start_search_space.setEnabled(False)
                self.cb_use_warm_start_hypervolume_reference_points.setEnabled(False)
                self.le_warm_start_loss_expansion_factor.setEnabled(False)

            self._set_warm_start_home_directory_type()
            self._set_warm_start_data_type()
            self._set_warm_start_strategy()

        if not self.__is_init: self._set_save_warm_start_data()

    def _set_save_warm_start_data(self):
        if self.optimization_type==0: # Full Start
            if self.optimizer_type == 0:
                self.save_warm_start_data = 1
                self.cb_save_warm_start_data.setCurrentIndex(1)
            else:
                self.save_warm_start_data = 0
                self.cb_save_warm_start_data.setCurrentIndex(0)
        else:
            self.save_warm_start_data = 0
            self.cb_save_warm_start_data.setCurrentIndex(0)

    def _set_pareto_selection_1(self):
        self.cb_pareto_selection_2.setCurrentIndex(self.cb_pareto_selection_1.currentIndex())

    def _set_pareto_selection_2(self):
        self.le_selected_event.setText(str(self._get_pareto_trial_number(pareto_selection=self.pareto_selection_2)))

    def _set_use_range(self):
        self.use_range_box_1.setVisible(self.use_range==0)
        self.use_range_box_2.setVisible(self.use_range==1)

    # -------------------------------------------------------------

    def _refresh_widget(self):
        self.le_total_iterations_i.setText(str(self.total_iterations_i))
        self.le_total_iterations_f.setText(str(self.total_iterations_f))
        self.le_selected_event.setText(str(self.selected_event))
        self.ta_pareto_events.setText("" if self.pareto_events is None else str(self.pareto_events))

    def _load_motors_info_from_current_setting(self):
        try:
            self._collect_initialization_parameters(raise_errors=False)
            self.__current_motors_info: MotorsInfoLegacy = self._load_motors_info(self._initialization_parameters)

            self.cb_motors.clear()
            for motor_id in self.__current_motors_info.get_motor_ids(): self.cb_motors.addItem(str(motor_id))
            self._get_current_motor()

        except ValueError as error:
            MessageDialog.message(self, title="Input Error", message=error.args[0], type="critical", width=500)
        except Exception as exception:
            MessageDialog.message(self, title="Unexpected Exception", message=exception.args[0], type="critical", width=700)

    def _get_current_motor(self):
        try:
            current_motor_id        = self.cb_motors.currentText()
            initialization_parameters = self._initialization_parameters

            platforms             = initialization_parameters.get_parameter("platforms")
            platform_key          = platforms[self.cb_platform.currentIndex()]
            beam_manager_types    = initialization_parameters.get_parameter("beam_manager_types")
            beam_manager_type_key = beam_manager_types[self.cb_beam_manager_type.currentIndex()]

            beam_manager_type_configuration = initialization_parameters.get_parameter("beam_manager_configuration")[beam_manager_type_key]
            beam_manager_ids                = beam_manager_type_configuration["beam_manager_ids"]
            beam_manager_id_key             = beam_manager_ids[self.cb_beam_manager_id.currentIndex()]

            motor_info: MotorInfoLegacy = self.__current_motors_info.get_motor_info(motor_id=current_motor_id)

            search_range          = motor_info.search_range_by_key(beam_manager_type=beam_manager_type_key, platform=platform_key, beam_manager_id=beam_manager_id_key)
            search_transfer_range = motor_info.search_transfer_range_by_key(beam_manager_type=beam_manager_type_key, platform=platform_key, beam_manager_id=beam_manager_id_key)
            initial_position      = motor_info.initial_position_by_key(beam_manager_type=beam_manager_type_key, platform=platform_key, beam_manager_id=beam_manager_id_key)
            boundaries            = motor_info.boundaries_by_key(platform_key)
            legacy_ids            = motor_info.legacy_ids
            optimized             = motor_info.optimized_by_key(beam_manager_type=beam_manager_type_key, platform=platform_key, beam_manager_id=beam_manager_id_key)

            self.motor_type        = motor_info.type.value - 1
            self.units             = motor_info.units.value - 1
            self.search_range_from = search_range[0]
            self.search_range_to   = search_range[1]
            self.search_transfer_range_from = search_transfer_range[0]
            self.search_transfer_range_to   = search_transfer_range[1]
            self.initial_position  = initial_position
            self.boundary_from     = boundaries[0]
            self.boundary_to       = boundaries[1]
            self.resolution        = motor_info.resolution
            self.repeatability     = motor_info.repeatability
            self.shift_from_ideal  = motor_info.shift_from_ideal
            self.legacy_id_get     = legacy_ids[0]
            self.legacy_id_set     = legacy_ids[1]
            self.optimized         = 1 if optimized else 0

            self.cb_motor_type.setCurrentIndex(motor_info.type.value - 1)
            self.cb_units.setCurrentIndex(motor_info.units.value - 1)
            self.le_search_range_from.setText(str(search_range[0]))
            self.le_search_range_to.setText(str(search_range[1]))
            self.le_search_transfer_range_from.setText(str(search_transfer_range[0]))
            self.le_search_transfer_range_to.setText(str(search_transfer_range[1]))
            self.le_initial_position.setText(str(initial_position))
            self.le_boundary_from.setText(str(boundaries[0]))
            self.le_boundary_to.setText(str(boundaries[1]))
            self.le_resolution.setText(str(motor_info.resolution))
            self.le_repeatability.setText(str(motor_info.repeatability))
            self.le_shift_from_ideal.setText(str(motor_info.shift_from_ideal))
            self.le_legacy_id_get.setText(str(legacy_ids[1]))
            self.le_legacy_id_set.setText(str(legacy_ids[0]))
            self.cb_optimized.setChecked(optimized)

        except ValueError as error:
            MessageDialog.message(self, title="Input Error", message=error.args[0], type="critical", width=500)
        except Exception as exception:
            MessageDialog.message(self, title="Unexpected Exception", message=exception.args[0], type="critical", width=700)

    def _set_current_motor(self):
        if self.__current_motors_info is None: return

        try:
            current_motor_id        = self.cb_motors.currentText()

            initialization_parameters = self._initialization_parameters

            platforms = initialization_parameters.get_parameter("platforms")
            platform_key = platforms[self.cb_platform.currentIndex()]
            beam_manager_types = initialization_parameters.get_parameter("beam_manager_types")
            beam_manager_type_key = beam_manager_types[self.cb_beam_manager_type.currentIndex()]

            beam_manager_type_configuration = initialization_parameters.get_parameter("beam_manager_configuration")[beam_manager_type_key]
            beam_manager_ids = beam_manager_type_configuration["beam_manager_ids"]
            beam_manager_id_key = beam_manager_ids[self.cb_beam_manager_id.currentIndex()]

            dictionary              = self.__current_motors_info.get_motor_info(motor_id=current_motor_id).to_dictionary()

            dictionary["search_range"][beam_manager_type_key][platform_key][beam_manager_id_key]          = [self.search_range_from, self.search_range_to]
            dictionary["search_transfer_range"][beam_manager_type_key][platform_key][beam_manager_id_key] = [self.search_transfer_range_from, self.search_transfer_range_to]
            dictionary["boundaries"][platform_key]                                                        = [self.boundary_from, self.boundary_to]
            dictionary["initial_position"][beam_manager_type_key][platform_key][beam_manager_id_key]      = self.initial_position
            dictionary["resolution"]                                                                      = self.resolution
            dictionary["repeatability"]                                                                   = self.repeatability
            dictionary["shift_from_ideal"]                                                                = self.shift_from_ideal
            dictionary["legacy_ids"]                                                                      = [self.legacy_id_set, self.legacy_id_get]
            dictionary["type"]                                                                            = self.motor_type + 1
            dictionary["units"]                                                                           = self.units + 1
            dictionary["optimized"][beam_manager_type_key][platform_key][beam_manager_id_key]             = self.optimized == 1

            self.__current_motors_info.add_motor_info(current_motor_id, MotorInfoLegacy.from_dictionary(dictionary))
        except ValueError as error:
            MessageDialog.message(self, title="Input Error", message=error.args[0], type="critical", width=500)
        except Exception as exception:
            MessageDialog.message(self, title="Unexpected Exception", message=exception.args[0], type="critical", width=700)

        self.driver_box_input.setEnabled(self.optimized==1)

    def _save_motors_info_from_current_setting(self):
        if self.__current_motors_info is None: return

        try:
            if ConfirmDialog.confirmed(self,
                                       title="Confirm saving motors info from current settings",
                                       message="Confirm saving motors info from current settings?"):
                self._save_motors_info(self.__current_motors_info, self._initialization_parameters)
        except ValueError as error:
            MessageDialog.message(self, title="Input Error", message=error.args[0], type="critical", width=500)
        except Exception as exception:
            MessageDialog.message(self, title="Unexpected Exception", message=exception.args[0], type="critical", width=700)

    def _set_current_motor_positions_as_initial_points_of_motors_info(self):
        if self.__current_motors_info is None: return

        try:
            if ConfirmDialog.confirmed(self,
                                       title="Confirm setting initial position from current motor positions",
                                       message="Confirm setting initial position from current motor positions?"):
                self._set_current_motor_positions_as_initial_points(self.__current_motors_info, self._initialization_parameters)
                self._get_current_motor()

        except ValueError as error:
            MessageDialog.message(self, title="Input Error", message=error.args[0], type="critical", width=500)
        except Exception as exception:
            MessageDialog.message(self, title="Unexpected Exception", message=exception.args[0], type="critical", width=700)


    def _move_motors_to_initial_points_of_motors_info(self):
        if self.__current_motors_info is None: return

        try:
            if ConfirmDialog.confirmed(self,
                                       title="Confirm moving motors to initial positions of the current settings",
                                       message="Confirm moving motors to initial positions of the current settings?"):
                self._move_motors_to_initial_points(self.__current_motors_info, self._initialization_parameters)
        except ValueError as error:
            MessageDialog.message(self, title="Input Error", message=error.args[0], type="critical", width=500)
        except Exception as exception:
            MessageDialog.message(self, title="Unexpected Exception", message=exception.args[0], type="critical", width=700)


    def _optimize_callback(self, **kwargs):
        try:
            if self.ai_type == 0 and self.save_warm_start_data == 1:
                if not ConfirmDialog.confirmed(self,
                                               title="Confirm saving data for transfer learning",
                                               message="Do you confirm saving the data of this run for transfer learning?"):
                    self.cb_save_warm_start_data.setCurrentIndex(0)
                    self.save_warm_start_data = 0

            self._start_ai_agent_button.setEnabled(False)
            self._out_tab_widget.setCurrentIndex(0)
            self._collect_initialization_parameters()

            self._start_ai_agent(self._initialization_parameters, **kwargs)
        except ValueError as error:
            MessageDialog.message(self, title="Input Error", message=error.args[0], type="critical", width=500)
        except Exception as exception:
            MessageDialog.message(self, title="Unexpected Exception", message=exception.args[0], type="critical", width=700)

    def _collect_initialization_parameters(self, raise_errors=True):
        initialization_parameters: ScriptData = self._initialization_parameters

        platform_key, beam_manager_type_key, beam_manager_id_key, objectives = self._check_fields(raise_errors)

        initialization_parameters.set_parameter("real_time_data", self.real_time_data)
        initialization_parameters.set_parameter("capture_stdout", self.capture_stdout)
        initialization_parameters.set_parameter("save_beams", self.save_beams)

        initialization_parameters.set_parameter("ai_type", self.ai_type)
        initialization_parameters.set_parameter("optimizer_type", self.optimizer_type)
        initialization_parameters.set_parameter("save_warm_start_data", self.save_warm_start_data)

        self._optimizer_type_configuration[Keys.OptimizerType.MOBO]["name"] = self.optimizer_name_mobo
        self._optimizer_type_configuration[Keys.OptimizerType.SONL]["name"] = self.optimizer_name_sonl

        optimizer_name_key_mobo = self._optimizer_names[Keys.OptimizerType.MOBO][int(self.optimizer_name_mobo)]
        optimizer_name_key_sonl = self._optimizer_names[Keys.OptimizerType.SONL][int(self.optimizer_name_sonl)]
        optimizer_name_key_sobo = self._optimizer_names[Keys.OptimizerType.SOBO][int(self.optimizer_name_sobo)]

        optimizer_configuration_mobo = self._optimizer_type_configuration[Keys.OptimizerType.MOBO]["optimizer_configuration"]
        optimizer_configuration_sonl = self._optimizer_type_configuration[Keys.OptimizerType.SONL]["optimizer_configuration"]
        optimizer_configuration_sobo = self._optimizer_type_configuration[Keys.OptimizerType.SOBO]["optimizer_configuration"]

        optimizer_configuration_mobo[optimizer_name_key_mobo]["acquisition_function"] = self.acquisition_function_mobo
        optimizer_configuration_mobo[optimizer_name_key_mobo]["sobol_iterations"]     = self.sobol_iterations_mobo
        optimizer_configuration_mobo[optimizer_name_key_mobo]["mobo_iterations"]      = self.mobo_iterations
        optimizer_configuration_mobo[optimizer_name_key_mobo]["pareto_selection"]     = self.pareto_selection
        optimizer_configuration_sonl[optimizer_name_key_sonl]["max_iterations"]       = self.max_iterations
        optimizer_configuration_sonl[optimizer_name_key_sonl]["x_absolute_change"]    = self.x_absolute_change
        optimizer_configuration_sonl[optimizer_name_key_sonl]["f_absolute_change"]    = self.f_absolute_change
        optimizer_configuration_sobo[optimizer_name_key_sobo]["acquisition_function"] = self.acquisition_function_sobo
        optimizer_configuration_sobo[optimizer_name_key_sobo]["sobol_iterations"]     = self.sobol_iterations_sobo
        optimizer_configuration_sobo[optimizer_name_key_sobo]["sobo_iterations"]      = self.sobo_iterations

        initialization_parameters.set_parameter("move_motors_on_best_trial", self.move_motors_on_best_trial)
        initialization_parameters.set_parameter("optimization_type", self.optimization_type)

        self._warm_start_configuration["warm_start_home_directory_type"] = self.warm_start_home_directory_type
        self._warm_start_configuration["warm_start_home_directory"]      = self.warm_start_home_directory
        self._warm_start_configuration["warm_start_data_type"]           = self.warm_start_data_type
        self._warm_start_configuration["warm_start_strategy"]            = self.warm_start_strategy

        self._warm_start_configuration["warm_start_expansion_factors"][self._warm_start_strategies[self.warm_start_strategy]] = [self.warm_start_search_space_expansion_factor,
                                                                                                                                 self.warm_start_loss_expansion_factor]

        self._warm_start_configuration["use_warm_start_search_space"]                 = self.use_warm_start_search_space
        self._warm_start_configuration["use_warm_start_hypervolume_reference_points"] = self.use_warm_start_hypervolume_reference_points

        initialization_parameters.set_parameter("save_warm_start_data",  self.save_warm_start_data)

        self._neural_network_configuration["neural_network_model_from"]          = self.neural_network_model_from
        self._neural_network_configuration["neural_network_trained_model_file"]  = self.neural_network_trained_model_file
        self._neural_network_configuration["neural_network_home_directory"]      = self.neural_network_home_directory
        self._neural_network_configuration["neural_network_data_type"]           = self.neural_network_data_type

        neural_network_parameters = {}
        neural_network_parameters["learning_rate"]    = self.learning_rate
        neural_network_parameters["weight_decay"]     = self.weight_decay
        neural_network_parameters["total_epochs"]     = self.total_epochs
        neural_network_parameters["patience"]         = self.patience
        neural_network_parameters["train_batch_size"] = self.train_batch_size

        self._neural_network_configuration["neural_network_parameters"] = neural_network_parameters

        initialization_parameters.set_parameter("platform",          self.platform)
        initialization_parameters.set_parameter("beam_manager_type", self.beam_manager_type)

        self._beam_manager_configuration[beam_manager_type_key]["beam_manager_id"] = self.beam_manager_id

        # Objectives are update while editing or every time a click is done? This is with a click (only writing the one belonging to the key
        self._beam_manager_configuration[beam_manager_type_key]["objectives"][platform_key][beam_manager_id_key] = self._get_objectives(raise_errors=raise_errors and self.ai_type==0)
        self._beam_manager_configuration[beam_manager_type_key]["properties"][platform_key][beam_manager_id_key] = self._get_properties(raise_errors=raise_errors and self.ai_type==1)

    def _get_objectives(self, raise_errors=True):
        objectives = {}
        is_empty = True
        for row_index in range(self._objective_table.rowCount()):
            criterion_item = self._objective_table.item(row_index, 0)
            reference_item = self._objective_table.item(row_index, 1)
            boundary_item  = self._objective_table.item(row_index, 2)
            weight_item    = self._objective_table.item(row_index, 3)
            exit_item      = self._objective_table.item(row_index, 4)

            if criterion_item.checkState() == Qt.Checked:
                if not check_number(reference_item.text()): raise ValueError(f"Reference (row {row_index + 1}) is not numeric")
                if not check_number(boundary_item.text()):  raise ValueError(f"Boundary (row {row_index + 1}) is not numeric")
                if not check_number(weight_item.text()):    raise ValueError(f"Weight (row {row_index + 1}) is not numeric")
                if not check_number(exit_item.text()):      raise ValueError(f"Exit (row {row_index + 1}) is not numeric")
                is_empty = False
                objectives[criterion_item.text()] = [reference_item.text(), boundary_item.text(), weight_item.text(), exit_item.text()]

        if is_empty and raise_errors: raise ValueError("No beam properties selected")

        return objectives

    def _get_properties(self, raise_errors=True):
        properties = {}
        is_empty = True
        for row_index in range(self._property_table.rowCount()):
            property_item = self._property_table.item(row_index, 0)
            target_item = self._property_table.item(row_index, 1)

            if property_item.checkState() == Qt.Checked:
                if not check_number(target_item.text()): raise ValueError(f"Target Value (row {row_index + 1}) is not numeric")
                is_empty = False
                properties[property_item.text()] = [target_item.text()]

        if is_empty and raise_errors: raise ValueError("No beam properties selected")

        return properties

    def _abort_callback(self):
        if ConfirmDialog.confirmed(self, "Confirm interruption of AI Agent?"):
            self._collect_initialization_parameters(raise_errors=False)
            self._abort()

    def _close_callback(self):
        if ConfirmDialog.confirmed(self, "Confirm Exit?"):
            self._collect_initialization_parameters(raise_errors=False)
            self._close(self._initialization_parameters)

    def _check_fields(self, raise_errors=True):
        platform_key, beam_manager_type_key, beam_manager_id_key, objectives = self._get_objectives_keys()

        platform_name          = self.cb_platform.currentText()
        beam_manager_type_name = self.cb_beam_manager_type.currentText()
        beam_manager_id_name   = self.cb_beam_manager_id.currentText()

        if len(list(self._available_beam_managers.get(platform_key, {}).keys())) == 0 and raise_errors:
            raise ValueError(f"{platform_name} platform not available (no beam/motion managers are configured)")

        if not beam_manager_id_key in self._available_beam_managers[platform_key][beam_manager_type_key] and raise_errors:
            raise ValueError(f"{beam_manager_type_name} Beam Manager with Detector {beam_manager_id_name} not configured for {platform_name} platform")

        if self.ai_type==0:
            if self.optimizer_type == 0:
                if not check_positive(self.sobol_iterations_mobo, strictly=False): raise ValueError("Sobol iterations should be a number \u2265 0")
                if not check_positive(self.mobo_iterations, strictly=False): raise ValueError("MOBO iterations should be a number \u2265 0")
            elif self.optimizer_type == 1:
                if not check_positive(self.max_iterations, strictly=True): raise ValueError("Max iterations should be a number > 0")
                if not check_positive(self.x_absolute_change, strictly=True): raise ValueError("X Absolute Change should be a number > 0")
                if not check_positive(self.f_absolute_change, strictly=True): raise ValueError("F Absolute Change should be a number > 0")
            elif self.optimizer_type == 2:
                if not check_positive(self.sobol_iterations_sobo, strictly=False): raise ValueError("Sobol iterations should be a number \u2265 0")
                if not check_positive(self.sobo_iterations, strictly=False): raise ValueError("SOBO iterations should be a number \u2265 0")

        #TODO:
        # CHECK IF NEEDED ERRORS FROM OTHER/NEW NUMERICAL FIELDS

        return platform_key, beam_manager_type_key, beam_manager_id_key, objectives

    @synchronized_method
    def optimization_completed(self):
        try:
            ai_result                 = self._get_result()
            initialization_parameters = self._get_initialization_parameters() # these are the initialization parameters actually used by the agent, it's safer and more consistent

            if not ai_result is None:
                if initialization_parameters.get_parameter("ai_type") == 0:  # optimization
                    if initialization_parameters.get_parameter("optimizer_type") == 0:  # MOBO
                       optimization_result_data, pareto_front_data, best_trial_data = ai_result

                       if not optimization_result_data is None and not optimization_result_data.is_empty():
                           self.total_iterations_i = optimization_result_data.get_trial_numbers()[0]
                           self.total_iterations_f = optimization_result_data.get_trial_numbers()[-1]
                           if not pareto_front_data is None and not pareto_front_data.is_empty():
                               self.pareto_events      = pareto_front_data.get_trial_numbers()
                               self.selected_event     = best_trial_data.trial_number
                           else:
                               self.pareto_events  = None
                               self.selected_event = self.total_iterations_f

                       if self.real_time_data == 1:
                           self._plot_trial()
                           self._plot_history()
                           self._out_tab_widget.setCurrentIndex(1)
                    elif initialization_parameters.get_parameter("optimizer_type") in [1, 2]:  # NL / SOBO:
                        optimization_result_data, best_trial_data = ai_result

                        if not optimization_result_data is None and not optimization_result_data.is_empty():
                            self.total_iterations_i = optimization_result_data.get_trial_numbers()[0]
                            self.total_iterations_f = optimization_result_data.get_trial_numbers()[-1]
                            self.selected_event     = best_trial_data.trial_number

                        if self.real_time_data == 1:
                            self._plot_trial()
                            self._plot_history()
                            self._out_tab_widget.setCurrentIndex(1)
                elif initialization_parameters.get_parameter("ai_type") == 1: # Neural Network
                    if not ai_result is None:
                        self.total_iterations_i = 1
                        self.total_iterations_f = 1
                        self.pareto_events = None
                        self.selected_event = self.total_iterations_f

                    if self.real_time_data == 1:
                        self._plot_trial(1)
                        self._out_tab_widget.setCurrentIndex(1)


                else:
                    pass
        except Exception as exception:
            MessageDialog.message(self, title="Unexpected Exception", message=exception.args[0], type="critical", width=700)

        self._refresh_widget()
        self._enable_buttons(True)

    @synchronized_method
    def _enable_buttons(self, enabled):
        self._start_ai_agent_button.setEnabled(enabled)

    def _show_trial(self):
        self._plot_trial()
        self._out_tab_widget.setCurrentIndex(1)

    def _move_motors_to_selected_trial(self):
        initialization_parameters = self._get_initialization_parameters()
        initialization_parameters = initialization_parameters if not initialization_parameters is None else self._initialization_parameters
        if initialization_parameters is None: return

        trial_data, _  = self._get_trial(self.selected_event, initialization_parameters)

        self._move_motors_to_trial_data(trial_data)

        self._out_tab_widget.setCurrentIndex(0)

    def _transfer_selected_trial_motor_position(self):
        initialization_parameters = self._get_initialization_parameters()
        initialization_parameters = initialization_parameters if not initialization_parameters is None else self._initialization_parameters
        if initialization_parameters is None: return

        initialization_parameters.set_parameter("platform_to",          self.platform_to)
        initialization_parameters.set_parameter("beam_manager_type_to", self.beam_manager_type_to)
        initialization_parameters.set_parameter("beam_manager_id_to",   self.beam_manager_id_to)

        self._transfer_current_position_to_beam_manager_search_space(initialization_parameters)

        self._out_tab_widget.setCurrentIndex(0)

    def _plot_trial(self, ai_type=0):
        initialization_parameters = self._get_initialization_parameters()
        initialization_parameters = initialization_parameters if not initialization_parameters is None else self._initialization_parameters
        if initialization_parameters is None: return

        if ai_type == 0:   trial_index = self.selected_event
        elif ai_type == 1: trial_index = 1

        trial_data, beam_properties = self._get_trial(trial_index, initialization_parameters)

        mode = "image"

        if  beam_properties.has_parameter("beam_histogram"):
            beam_histogram = beam_properties.get_parameter("beam_histogram")
            hh             = beam_histogram.get_parameter("coordinate_h")
            vv             = beam_histogram.get_parameter("coordinate_v")
            mode = "image"
        #elif beam_properties.has_parameter("intensity_histogram"):
        #    beam_histogram = beam_properties.get_parameter("intensity_histogram")
        #    hh             = beam_histogram.get_parameter("coordinate_h")
        #    vv             = beam_histogram.get_parameter("coordinate_v")
        #    mode = "image"
        elif beam_properties.has_parameter("intensity_histogram_h"):
            beam_histogram_h = beam_properties.get_parameter("intensity_histogram_h")
            beam_histogram_v = beam_properties.get_parameter("intensity_histogram_v")
            hh = beam_properties.get_parameter("coordinate_h")
            vv = beam_properties.get_parameter("coordinate_v")
            mode = "scan"
        elif beam_properties.has_parameter("beam_histogram_h"):
            beam_histogram_h = beam_properties.get_parameter("beam_histogram_h")
            beam_histogram_v = beam_properties.get_parameter("beam_histogram_v")
            hh               = beam_properties.get_parameter("coordinate_h")
            vv               = beam_properties.get_parameter("coordinate_v")
            mode = "scan"
        elif beam_properties.has_parameter("speckle_data_h"):
            beam_histogram_h = beam_properties.get_parameter("speckle_data_h")
            beam_histogram_v = beam_properties.get_parameter("speckle_data_v")
            hh               = beam_properties.get_parameter("coordinate_h")
            vv               = beam_properties.get_parameter("coordinate_v")
            mode = "speckle"

        output_data = trial_data.loss_function if ai_type==0 else trial_data.beam_properties

        def custom_formatter(x, pos): return f'{x:.2f}'

        if self.use_range==0:
            xrange = None
            yrange = None
        else:
            xrange = [self.xrange_i, self.xrange_f]
            yrange = [self.yrange_i, self.yrange_f]

        if mode == "image":
            data_2D = beam_histogram.get_parameter("histogram").T

            if xrange is None: xrange = [np.min(hh), np.max(hh)]
            if yrange is None: yrange = [np.min(vv), np.max(vv)]

            fig = self._result_figure
            fig.clear()

            ax_1, ax_2 = fig.subplots(1, 2, gridspec_kw={'width_ratios': [2, 1]})
            ax_2.set_axis_off()

            image = ax_1.pcolormesh(hh, vv, data_2D, cmap=cmm.sunburst_r, rasterized=True)
            ax_1.set_xlim(xrange[0], xrange[1])
            ax_1.set_ylim(yrange[0], yrange[1])
            ax_1.set_xticks(np.linspace(xrange[0], xrange[1], 11, endpoint=True))
            ax_1.set_yticks(np.linspace(yrange[0], yrange[1], 11, endpoint=True))
            ax_1.xaxis.set_major_formatter(FuncFormatter(custom_formatter))
            ax_1.yaxis.set_major_formatter(FuncFormatter(custom_formatter))
            ax_1.axhline(0, color="gray", ls="--", linewidth=1, alpha=0.7)
            ax_1.axvline(0, color="gray", ls="--", linewidth=1, alpha=0.7)
            ax_1.set_xlabel("Horizontal ($\\mu$m)")
            ax_1.set_ylabel("Vertical ($\\mu$m)")

            cbar = fig.colorbar(mappable=image, ax=ax_1, pad=0.01, aspect=30, shrink=0.6)

            ax_1.set_aspect("equal")
            ax_1.text(0.02, 0.95, str(trial_index), fontsize=10, color="blue", transform=ax_1.transAxes)

            cbar.ax.text(0.5, 1.05, "pI", transform=cbar.ax.transAxes, ha="center", va="bottom", fontsize=10, color="black")

            text = f"Alignement Criteria ({'Objective Function' if ai_type==0 else 'Beam Properties'})\n"

            criteria = list(output_data.keys())
            criteria = [(x + (' ' * (len(max(criteria, key=len)) - len(x)))) for x in criteria]

            for criterion in criteria:
                if    "negative-log" in criterion or "integral" in criterion: um = ""
                else: um = "$\\mu$m"
                text += "\n" + rf"{criterion:<6}  = {output_data[criterion.strip()] : 3.6f} {um}"

            ax_2.text(0.01, 0.5, text, color="black", alpha=0.9, fontsize=9, fontname="Courier", bbox=dict(facecolor="white", edgecolor="gray", alpha=0.7), transform=ax_2.transAxes)
        elif mode == "scan":
            if xrange is None: xrange = [np.min(hh), np.max(hh)]
            if yrange is None: yrange = [np.min(vv), np.max(vv)]

            fig = self._result_figure
            fig.clear()

            ax_1, ax_2, ax_3 = fig.subplots(1, 3, gridspec_kw={'width_ratios': [2.0, 2.0, 1.0]}, sharey=True)
            ax_3.set_axis_off()

            ax_1.set_xlim(xrange[0], xrange[1])
            ax_1.set_xticks(np.linspace(xrange[0], xrange[1], 11, endpoint=True))
            ax_1.xaxis.set_major_formatter(FuncFormatter(custom_formatter))
            ax_1.axvline(0, color="gray", ls="--", linewidth=1, alpha=0.7)
            ax_1.set_xlabel("Horizontal ($\\mu$m)")
            ax_1.set_ylabel("Intensity")
            ax_1.plot(hh, beam_histogram_h)

            ax_2.set_xlim(yrange[0], yrange[1])
            ax_2.set_xticks(np.linspace(yrange[0], yrange[1], 11, endpoint=True))
            ax_2.xaxis.set_major_formatter(FuncFormatter(custom_formatter))
            ax_2.axvline(0, color="gray", ls="--", linewidth=1, alpha=0.7)
            ax_2.set_xlabel("Vertical ($\\mu$m)")
            ax_2.plot(vv, beam_histogram_v)

            ax_1.text(0.02, 0.95, str(trial_index), fontsize=10, color="blue", transform=ax_1.transAxes)

            text = f"Alignement Criteria ({'Objective Function' if ai_type==0 else 'Beam Properties'})\n"

            criteria = list(output_data.keys())
            criteria = [(x + (' ' * (len(max(criteria, key=len)) - len(x)))) for x in criteria]

            for criterion in criteria:
                if    "negative-log" in criterion or "integral" in criterion: um = ""
                else: um = "$\\mu$m"
                text += "\n" + rf"{criterion:<6}  = {output_data[criterion.strip()] : 3.6f} {um}"

            ax_3.text(0.01, 0.5, text, color="black", alpha=0.9, fontsize=9, fontname="Courier",
                      bbox=dict(facecolor="white", edgecolor="gray", alpha=0.7), transform=ax_3.transAxes)
        elif mode == "speckle":
            if xrange is None: xrange = [np.min(hh), np.max(hh)]
            if yrange is None: yrange = [np.min(vv), np.max(vv)]

            fig = self._result_figure
            fig.clear()

            ax_1, ax_2, ax_3 = fig.subplots(1, 3, gridspec_kw={'width_ratios': [2.0, 2.0, 1.0]}, sharey=False)
            ax_3.set_axis_off()

            ax_1.set_xlim(xrange[0], xrange[1])
            ax_1.set_ylim(np.min(beam_histogram_h), np.max(beam_histogram_h))
            ax_1.set_xticks(np.linspace(xrange[0], xrange[1], 11, endpoint=True))
            ax_1.xaxis.set_major_formatter(FuncFormatter(custom_formatter))
            ax_1.axvline(0, color="gray", ls="--", linewidth=1, alpha=0.7)
            ax_1.set_xlabel("Horizontal (pixels)")
            ax_1.set_ylabel("Speckle Amplitude")
            ax_1.plot(hh, beam_histogram_h)

            ax_2.set_xlim(yrange[0], yrange[1])
            ax_1.set_ylim(np.min(beam_histogram_v), np.max(beam_histogram_v))
            ax_2.set_xticks(np.linspace(yrange[0], yrange[1], 11, endpoint=True))
            ax_2.xaxis.set_major_formatter(FuncFormatter(custom_formatter))
            ax_2.axvline(0, color="gray", ls="--", linewidth=1, alpha=0.7)
            ax_2.set_xlabel("Vertical (pixels)")
            ax_2.plot(vv, beam_histogram_v)

            ax_1.text(0.02, 0.95, str(trial_index), fontsize=10, color="blue", transform=ax_1.transAxes)

            text = f"Alignement Criteria ({'Objective Function' if ai_type==0 else 'Beam Properties'})\n"

            criteria = list(output_data.keys())
            criteria = [(x + (' ' * (len(max(criteria, key=len)) - len(x)))) for x in criteria]

            for criterion in criteria:
                um = "$\\mu$m"
                text += "\n" + rf"{criterion:<6}  = {output_data[criterion.strip()] : 3.6f} {um}"

            ax_3.text(0.01, 0.5, text, color="black", alpha=0.9, fontsize=9, fontname="Courier",
                      bbox=dict(facecolor="white", edgecolor="gray", alpha=0.7), transform=ax_3.transAxes)

        self._result_figure_canvas.draw()

    def _plot_history(self):
        self._history_figure_canvas.figure = self._get_optimization_history()
        self._history_figure_canvas.draw()

