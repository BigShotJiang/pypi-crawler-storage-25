#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import sys

from AnyQt.QtCore import QObject

from aps.common.widgets.context_widget import PlottingProperties, DefaultMainWindow
from aps.common.plotter import get_registered_plotter_instance

from aps.ai.beamline_controller.legacy.execution.execution_manager import QtExecutionManager
from aps.ai.beamline_controller.legacy.gui.beamline_controller_widget import BeamlineControllerWidget

APPLICATION_NAME = "Beamline Controller"
SHOW_MAIN        = APPLICATION_NAME + ": Main"

class IBeamlineController():
    def show_beamline_controller(self, plotting_properties=PlottingProperties(), **kwargs): raise NotImplementedError()

def create_beamline_controller(working_directory, beamline_id, log_stream_widget=None, **kwargs):
    return _BeamlineController(working_directory=working_directory,
                               beamline_id=beamline_id,
                               log_stream_widget=log_stream_widget, **kwargs)

class _BeamlineController(QtExecutionManager, IBeamlineController):
    def __init__(self, working_directory, beamline_id, log_stream_widget = None, **kwargs):
        super(_BeamlineController, self).__init__(APPLICATION_NAME, working_directory, beamline_id, **kwargs)

        self._log_stream_widget = log_stream_widget

    def reload_utils(self):
        super(_BeamlineController, self).reload_utils()

        self._plotter = get_registered_plotter_instance(application_name=APPLICATION_NAME)

    def show_beamline_controller(self, plotting_properties=PlottingProperties(), **kwargs):
        if self._plotter.is_active():
            add_context_label = plotting_properties.get_parameter("add_context_label", False)
            use_unique_id     = plotting_properties.get_parameter("use_unique_id", False)

            self._plotter.register_context_window(SHOW_MAIN,
                                                  context_window=DefaultMainWindow(title=SHOW_MAIN),
                                                  use_unique_id=use_unique_id)

            self._plotter.push_plot_on_context(SHOW_MAIN, BeamlineControllerWidget, None,
                                               log_stream_widget=self._log_stream_widget,
                                               working_directory=self._working_directory,
                                               beamline_id=self._beamline_id,
                                               available_beam_managers=self.get_available_beam_managers(),
                                               initialization_parameters=self.get_configuration(),
                                               start_ai_agent_method=self.start_ai_agent,
                                               close_method=self.close,
                                               abort_method=self.abort,
                                               get_result_method=self.get_current_result,
                                               get_initialization_parameters_method=self.get_current_initialization_parameters,
                                               get_trial_method=self.get_trial,
                                               get_pareto_trial_number_method=self.get_pareto_trial_number,
                                               get_optimization_history_method=self.get_optimization_history,
                                               finish_method=self.finish,
                                               move_motors_to_trial_data_method=self.move_motors_to_trial_data,
                                               set_current_motor_positions_as_initial_points=self.set_current_motor_positions_as_initial_points,
                                               move_motors_to_initial_points=self.move_motors_to_initial_points,
                                               transfer_current_position_to_beam_manager_search_space=self.transfer_current_position_to_beam_manager_search_space,
                                               load_motors_info_method=self.load_motors_info,
                                               save_motors_info_method=self.save_motors_info,
                                               allows_saving=False,
                                               **kwargs)
            widget                        = self._plotter.get_plots_of_context(SHOW_MAIN)[0]
            optimization_completed_method = getattr(widget, "optimization_completed")

            self._connect_agent_completed(optimization_completed_method)

            self._plotter.draw_context(SHOW_MAIN, add_context_label=add_context_label, unique_id=None, **kwargs)
            self._plotter.raise_context_window(context_key=SHOW_MAIN, stay_on_top=False)
        else:
            self.start_ai_agent(self.get_configuration(), is_active_gui=False)

    def close(self, initialization_parameters):
        self.save_configuration(initialization_parameters)

        if self._plotter.is_active(): self._plotter.get_context_container_widget(context_key=SHOW_MAIN).parent().close()

        sys.exit(0)
