#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import abc
import os
from typing import List

from aps.ai.beamline_controller.legacy.agent.optimization.facade import OptimizationInputParameters, OptimizationExecutionParameters, \
    OptimizationResult, OptimizationResultItem, WarmStartDataType, WarmStartStrategy, Beam
from aps.ai.beamline_controller.legacy.agent.facade import Fidelity, ERROR_LOSS


# -------------------------------------------------------------
# USER INPUT
# -------------------------------------------------------------

class BayesianOptimizationInputParameters(OptimizationInputParameters):
    def __init__(self,
                 acquisition_function=None,
                 sobol_trials=10,
                 bo_trials=10,
                 motors_to_optimize=None,
                 beam_manager_type: str = None,
                 platform: str          = None,
                 beam_manager_id: str   = None,
                 random_seed=2124,
                 **kwargs):
        super(BayesianOptimizationInputParameters, self).__init__(motors_to_optimize=motors_to_optimize,
                                                                  beam_manager_type=beam_manager_type,
                                                                  platform=platform,
                                                                  beam_manager_id=beam_manager_id,
                                                                  random_seed=random_seed, **kwargs)
        self.__acquisition_function = acquisition_function
        self.__sobol_trials         = sobol_trials
        self.__bo_trials            = bo_trials

    @property
    def acquisition_function(self): return self.__acquisition_function

    @property
    def sobol_trials(self): return self.__sobol_trials

    @property
    def bo_trials(self): return self.__bo_trials

import multiprocessing

class BayesianOptimizationExecutionParameters(OptimizationExecutionParameters):
    def __init__(self,
                 home_directory: str = os.curdir,
                 do_batch_optimization: bool = False,
                 batch_size: int = min(1, multiprocessing.cpu_count()-2),
                 do_warm_start: bool = False,
                 warm_start_home_directory: str = os.curdir,
                 warm_start_data_type: int = WarmStartDataType.PARETO_FRONTIERS,
                 warm_start_strategy: int = WarmStartStrategy.MAXIMUM_EXTENSION,
                 warm_start_expansion_factors: list = [0.1, 1.5],
                 use_warm_start_search_space: bool = True,
                 use_warm_start_hypervolume_reference_points: bool = True,
                 save_warm_start_data: bool = True,
                 use_exit_strategy: bool = False,
                 exit_loss_function: dict = {},
                 convergence_threshold: float = 0.01,
                 patience: int = 5,
                 move_motors_on_best_trial: bool = False):
        super(BayesianOptimizationExecutionParameters, self).__init__(home_directory=home_directory,
                                                                      do_warm_start=do_warm_start,
                                                                      warm_start_home_directory=warm_start_home_directory,
                                                                      warm_start_data_type=warm_start_data_type,
                                                                      warm_start_strategy=warm_start_strategy,
                                                                      warm_start_expansion_factors=warm_start_expansion_factors,
                                                                      use_warm_start_search_space=use_warm_start_search_space,
                                                                      save_warm_start_data=save_warm_start_data,
                                                                      use_exit_strategy=use_exit_strategy,
                                                                      exit_loss_function=exit_loss_function)
        self.__do_batch_optimization = do_batch_optimization
        if self.__do_batch_optimization: self.__batch_size = batch_size
        else:                            self.__batch_size = 1

        self.__use_warm_start_hypervolume_reference_points = use_warm_start_hypervolume_reference_points
        self.__pareto_data_directory                       = os.path.join(home_directory, "pareto_fronts")

        if not os.path.exists(self.__pareto_data_directory): os.makedirs(self.__pareto_data_directory)

        self.__convegence_threshold = convergence_threshold
        self.__patience             = patience

        self.__move_motors_on_best_trial = move_motors_on_best_trial


    @property
    def do_batch_optimization(self) -> bool: return self.__do_batch_optimization

    @property
    def batch_size(self) -> int: return self.__batch_size

    @property
    def use_warm_start_hypervolume_reference_points(self) -> bool: return self.__use_warm_start_hypervolume_reference_points

    @property
    def pareto_data_directory(self) -> str: return self.__pareto_data_directory

    @property
    def convergence_threshold(self) -> float: return self.__convegence_threshold

    @property
    def patience(self) -> int: return self.__patience

    @property
    def move_motors_on_best_trial(self) -> bool: return self.__move_motors_on_best_trial

# -------------------------------------------------------------
# Optimization Output
# -------------------------------------------------------------

class OptimizationTrialStatus:
    COMPLETED = 0
    FAILED    = 1

class Sampling:
    QUASI_RANDOM = 0
    OPTIMIZED    = 1

from time import time
import numpy as np

class BayesianOptimizationResultItem(OptimizationResultItem):
    def __init__(self,
                 trial_number: int = 0,
                 start_time:float = time(),
                 end_time: float  = time(),
                 fidelity: int = Fidelity.LOW,
                 status: int = OptimizationTrialStatus.COMPLETED,
                 motor_positions: dict = {},  # motor_id : position
                 loss_function: dict = {},  # {optimization_criterion : loss }
                 scalar_loss: float = np.nan,
                 sampling: int = Sampling.OPTIMIZED,
                 beam: Beam = None,
                 beam_string: str = None):
        super(BayesianOptimizationResultItem, self).__init__(trial_number=trial_number,
                                                             start_time=start_time,
                                                             end_time=end_time,
                                                             fidelity=fidelity,
                                                             motor_positions=motor_positions,
                                                             loss_function=loss_function,
                                                             beam=beam,
                                                             beam_string=beam_string)
        self.__status   = status
        self.__sampling = sampling
        self.__scalar_loss = scalar_loss

    @property
    def status(self) -> int: return self.__status

    @property
    def sampling(self) -> int: return self.__sampling

    @status.setter
    def status(self, value): self.__status = value

    @sampling.setter
    def sampling(self, value): self.__sampling = value

    @property
    def scalar_loss(self) -> float: return self.__scalar_loss

    @scalar_loss.setter
    def scalar_loss(self, value): self.__scalar_loss = value

    @property
    def headers(self) -> list:
        headers = super(BayesianOptimizationResultItem, self).headers
        headers.append("scalar_loss")
        headers.append("status")
        headers.append("sampling")
        return headers

    def to_dictionary(self) -> dict:
        dict             = super(BayesianOptimizationResultItem, self).to_dictionary()
        try:    dict["scalar_loss"] = self.scalar_loss
        except: pass
        dict["status"]      = self.status
        dict["sampling"]    = self.sampling
        return dict

    def __str__(self):
        return str(self.to_dictionary())

    @classmethod
    def from_dictionary(cls, dictionary: dict):
        return BayesianOptimizationResultItem(trial_number=dictionary["trial_number"],
                                              start_time=float(dictionary.get("start_time", 0.0)),
                                              end_time=float(dictionary.get("end_time", 0.0)),
                                              fidelity=int(dictionary.get("fidelity"), Fidelity.LOW),
                                              motor_positions={key[:-5]: dictionary[key] for key in dictionary.keys() if key.endswith("-(MP)")},
                                              loss_function={key[:-5]: dictionary[key] for key in dictionary.keys() if key.endswith("-(LF)")},
                                              scalar_loss=dictionary.get("scalar_loss", np.nan),
                                              status=dictionary.get("status", OptimizationTrialStatus.COMPLETED),
                                              sampling=dictionary.get("sampling", Sampling.OPTIMIZED),
                                              beam_string=dictionary["beam"])

class BayesianOptimizationResult(OptimizationResult):
    def __init__(self,
                 optimization_items: List[BayesianOptimizationResultItem]=None):
        super(BayesianOptimizationResult, self).__init__(optimization_items)

    def __str__(self):
        text = ""
        for item in self.get_optimization_items(): text += str(item) + "\n"
        return text[:-1] if len(text) > 1 else text

    def get_scalar_losses(self) -> List[int]:
        return [item.scalar_loss for item in self.get_optimization_items()]

    def get_statuses(self, trial_numbers: list = None) -> List[int]:
        return [item.status for item in self.get_optimization_items(trial_numbers)]

    def get_samplings(self, trial_numbers: list = None) -> List[int]:
        return [item.sampling for item in self.get_optimization_items(trial_numbers)]

    def set_statuses(self, status = OptimizationTrialStatus.COMPLETED, trial_numbers: list = None) -> List[int]:
        for item in self.get_optimization_items(trial_numbers): item.status = status

    def set_samplings(self, sampling = Sampling.OPTIMIZED, trial_numbers: list = None) -> List[int]:
        for item in self.get_optimization_items(trial_numbers): item.sampling = sampling

    def get_best_trial(self) -> BayesianOptimizationResultItem:
        return self.get_optimization_items()[np.argmin(self.get_scalar_losses())]

    # ----------------------------------------------------
    # WARM START METHODS
    #

    # on subclasses the return is removed. It is necessary only in this particular call to super.
    def initialize_warm_start_data(self, current_search_range: dict, strategy: int = WarmStartStrategy.MAXIMUM_EXTENSION, expansion_factors: list = [0.1, 1.5], **kwargs):
        self.__warm_start_hypervolume_reference_points = super(BayesianOptimizationResult, self).initialize_warm_start_data(current_search_range, strategy, expansion_factors, **kwargs)

    def _get_warm_start_filters(self, **kwargs):
        excluded_data = kwargs.get("excluded_data", "default")

        if excluded_data   == "sobol":          return {"status" : (OptimizationTrialStatus.FAILED, "e"), "sampling" : (Sampling.QUASI_RANDOM, "e")}
        elif excluded_data in ["mobo", "sobo"]: return {"status" : (OptimizationTrialStatus.FAILED, "e"), "sampling" : (Sampling.OPTIMIZED, "e")}
        else:                                   return {"status" : (OptimizationTrialStatus.FAILED, "e")}

    def get_warm_start_hypervolume_reference_points(self) -> dict: return self.__warm_start_hypervolume_reference_points

    @classmethod
    def from_csv(cls, file_name):
        return super(BayesianOptimizationResult, cls).from_csv(file_name, item_class=BayesianOptimizationResultItem)

