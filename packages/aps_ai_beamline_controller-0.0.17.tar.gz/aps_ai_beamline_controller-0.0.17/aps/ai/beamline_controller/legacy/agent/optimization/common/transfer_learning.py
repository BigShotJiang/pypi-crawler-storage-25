#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import os
from aps.common.io.serialization import from_pickle
from aps.beamline_driver.motion_management.facade import MotorsInfoLegacy
from aps.ai.beamline_controller.legacy.agent.optimization.facade import WarmStartDataType, WarmStartStrategy, OptimizationCriteria
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.facade import BayesianOptimizationResult, BayesianOptimizationResultItem

def get_warm_start_data(motors_to_optimize,
                        optimization_criteria: OptimizationCriteria,
                        warm_start_home_directory: str = os.path.abspath(os.curdir),
                        warm_start_data_type: int = WarmStartDataType.PARETO_FRONTIERS,
                        warm_start_strategy: int = WarmStartStrategy.MAXIMUM_EXTENSION,
                        warm_start_expansion_factors: list = [0.0, 0.01],
                        default_search_range: dict = {},
                        motors_info: MotorsInfoLegacy = None,
                        warm_start_data_class: type = BayesianOptimizationResult,
                        warm_start_item_class: type = BayesianOptimizationResultItem,
                        **kwargs):
    if warm_start_data_type == WarmStartDataType.PARETO_FRONTIERS:
        warm_start_data = BayesianOptimizationResult()
        warm_start_data_directory = os.path.join(warm_start_home_directory, "pareto_fronts")
        warm_start_suffix = kwargs.get("warm_start_suffix", "_pareto.pkl")
        warm_start_data_class = BayesianOptimizationResult
        warm_start_item_class = BayesianOptimizationResultItem
    elif warm_start_data_type in [WarmStartDataType.WHOLE_DATASETS_NO_MOBO, WarmStartDataType.WHOLE_DATASETS_NO_SOBOL, WarmStartDataType.WHOLE_DATASETS_ALL]:
        if warm_start_data_class is None or warm_start_item_class is None: raise ValueError("Warm Start data types not specified")
        warm_start_data = warm_start_data_class()
        warm_start_data_directory = os.path.join(warm_start_home_directory, "ml_data")
        warm_start_suffix = kwargs.get("warm_start_suffix", "_ml.pkl")
    else:
        raise ValueError("Warm Start Data Type not recognized")

    trial_number = -1

    for element in os.listdir(warm_start_data_directory):
        if element.lower().endswith(warm_start_suffix):
            current_warm_start_data = from_pickle(os.path.join(warm_start_data_directory, element), obj_class=warm_start_data_class)

            for warm_start_element in current_warm_start_data.get_warm_start_subset(**kwargs):
                warm_start_element: BayesianOptimizationResultItem = warm_start_element
                motor_positions = warm_start_element.motor_positions
                loss_function   = warm_start_element.loss_function

                shared_motor_ids             = set(list(motors_to_optimize)).intersection(motor_positions.keys())
                shared_optimization_criteria = set(optimization_criteria.names).intersection(loss_function.keys())
                # COMPATIBILITY CONDITIONS:
                # - All the motors in the current optimization must be present in the warm start data
                # - All the optimization criteria in the current optimization must be present in the warm start data
                are_motors_compatible = len(shared_motor_ids) >= len(motors_to_optimize)
                is_loss_function_compatible = len(shared_optimization_criteria) >= len(optimization_criteria.names)

                if are_motors_compatible and is_loss_function_compatible:
                    if not motors_info is None:
                        motor_positions = {motor_id: motors_info.get_motor_info(motor_id).apply_resolution(position=motor_positions[motor_id]) for motor_id in motors_to_optimize}
                    else:
                        motor_positions = {motor_id: motor_positions[motor_id] for motor_id in motors_to_optimize}
                    loss_function = {optimization_criterion: loss_function[optimization_criterion] for optimization_criterion in optimization_criteria.names}

                    trial_number += 1

                    optimization_item = warm_start_item_class(trial_number=trial_number,
                                                              motor_positions=motor_positions,
                                                              loss_function=loss_function)
                    # RETRO-COMPATIBILITY
                    if hasattr(warm_start_element, "fidelity") and hasattr(optimization_item, "fidelity"): optimization_item.fidelity = warm_start_element.fidelity
                    if hasattr(warm_start_element, "status") and hasattr(optimization_item, "status"):     optimization_item.status   = warm_start_element.status
                    if hasattr(warm_start_element, "sampling") and hasattr(optimization_item, "sampling"): optimization_item.sampling = warm_start_element.sampling

                    warm_start_data.add_optimization_item(optimization_item)

    warm_start_data.initialize_warm_start_data(current_search_range=default_search_range,
                                               strategy=warm_start_strategy,
                                               expansion_factors=warm_start_expansion_factors,
                                               **kwargs)

    return warm_start_data