#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import abc
import copy
import os

from matplotlib.figure import Figure
from typing import List, Type

from aps.ai.beamline_controller.legacy.common.utility import datetime_string
from aps.beamline_driver.beam_management.facade import IBeamManager, BeamProperties, Beam
from aps.beamline_driver.motion_management.facade import IMotionManager, Movement, MethodCallingType

from aps.ai.beamline_controller.legacy.agent.optimization.facade import IOptimizer, IHypervolumeManager, \
    OptimizationCriteria, OptimizationExecutionParameters, OptimizationInputParameters, OptimizationInitParameters, \
    OptimizationResult, OptimizationResultItem, WarmStartDataType
from aps.ai.beamline_controller.legacy.agent.facade import Format, IAgentListener
from aps.ai.beamline_controller.legacy.agent.optimization.common import plot_utility
from aps.ai.beamline_controller.legacy.agent.optimization.common.transfer_learning import get_warm_start_data

class AbstractOptimizer(IOptimizer):
    def __init__(self, optimization_listener : IAgentListener, **kwargs):
        self._optimization_listener = optimization_listener
        self.__interrupted = None

    def initialize_driver(self,
                          beam_manager : IBeamManager,
                          motion_manager : IMotionManager):
        self._beam_manager            = beam_manager
        self._motion_manager          = motion_manager

        if self.requires_run_engine():
            setattr(self, "optimize", self.__optimize_generator)
            setattr(self, "_move_motors", self.__move_motors_generator)
            setattr(self, "_get_current_motors_positions", self.__get_current_motors_positions_generator)
        else:
            setattr(self, "optimize",                      self.__optimize)
            setattr(self, "_move_motors",                  self.__move_motors)
            setattr(self, "_get_current_motors_positions", self.__get_current_motors_positions)

    def initialize_optimization(self,
                                hypervolume_manager: IHypervolumeManager = None,
                                **kwargs):
        self._hypervolume_manager     = hypervolume_manager

        self._optimization_criteria: OptimizationCriteria           = None
        self._execution_parameters: OptimizationExecutionParameters = None
        self._input_parameters: OptimizationInputParameters         = None
        self._optimization_parameters: OptimizationInitParameters   = None
        self._current_raw_data: dict                                = {}
        self._optimization_result: OptimizationResult               = None
        self._current_timestamps: dict                              = None
        self.__interrupted                                          = False

    @property
    def interrupt(self): return self.__interrupted
    @interrupt.setter
    def interrupt(self, value: bool): self.__interrupted = value

    def requires_run_engine(self):
        return self._beam_manager.method_calling_type() == MethodCallingType.GENERATOR or \
               self._motion_manager.method_calling_type() == MethodCallingType.GENERATOR

    # -----------------------------------------------------------------------
    # -----------------------------------------------------------------------
    # -----------------------------------------------------------------------
    # BLUESKY DYNAMIC MANAGEMENT -> PRIVATE METHODS
    # -----------------------------------------------------------------------
    # -----------------------------------------------------------------------
    # -----------------------------------------------------------------------

    def __optimize_init(self,
                        optimization_criteria : OptimizationCriteria,
                        execution_parameters: OptimizationExecutionParameters,
                        input_parameters : OptimizationInputParameters,
                        **kwargs):
        if not input_parameters.is_partial_optimization: input_parameters.motors_to_optimize = self._get_all_motor_ids()

        self._optimization_criteria   = optimization_criteria
        self._execution_parameters    = execution_parameters
        self._input_parameters        = input_parameters
        self._optimization_parameters = self._hypervolume_manager.get_optimization_parameters(optimization_criteria, input_parameters, **kwargs)
        self._current_timestamps      = {}
        self._current_raw_data        = {}

        self.interrupt = False

        self._manage_transfer_learning_input(**kwargs)

    def _get_raw_data_type(self) -> Type: return Beam

    # -----------------------------------------------------------------------

    def __optimize_end(self, optimization_result: OptimizationResult, **kwargs):
        self._optimization_result = optimization_result

        self._optimization_result.set_timestamps(self._current_timestamps)
        if   self._get_raw_data_type() == Beam: self._optimization_result.set_beams(self._current_raw_data)
        elif self._get_raw_data_type() == str:  self._optimization_result.set_beam_hex_strings(self._current_raw_data)
        else: raise ValueError("Raw data type not supported")

        self._manage_transfer_learning_output(**kwargs)

    # -----------------------------------------------------------------------

    def __optimize(self,
                 optimization_criteria : OptimizationCriteria,
                 execution_parameters: OptimizationExecutionParameters,
                 input_parameters : OptimizationInputParameters,
                 **kwargs):
        self.__optimize_init(optimization_criteria, execution_parameters, input_parameters, **kwargs)

        if not self.requires_run_engine():
            if input_parameters.get_parameter("move_motor_to_initial_positions", True):
                motors_to_optimize = self._motion_manager.get_motors_info().get_motor_ids_to_optimize(beam_manager_type=input_parameters.beam_manager_type,
                                                                                                             platform=input_parameters.platform,
                                                                                                             beam_manager_id=input_parameters.beam_manager_id)

                self._move_motors(self._motion_manager.get_motors_info().get_initial_positions(beam_manager_type=input_parameters.beam_manager_type,
                                                                                                      platform=input_parameters.platform,
                                                                                                      beam_manager_id=input_parameters.beam_manager_id,
                                                                                                      motor_ids=motors_to_optimize))

            optimization_result = self._optimize(**kwargs)
        else: raise ValueError("This operator should be called as: RE(optimizer.optimize_bluesky())")

        self.__optimize_end(optimization_result, **kwargs)

    # -----------------------------------------------------------------------

    def __optimize_generator(self,
                             optimization_criteria : OptimizationCriteria,
                             execution_parameters: OptimizationExecutionParameters,
                             input_parameters : OptimizationInputParameters,
                             **kwargs):
        self.__optimize_init(optimization_criteria, execution_parameters, input_parameters, **kwargs)

        if self.requires_run_engine():
            if input_parameters.get_parameter("move_motor_to_initial_positions", True):
                motors_to_optimize = self._motion_manager.get_motors_info().get_motor_ids_to_optimize(beam_manager_type=input_parameters.beam_manager_type,
                                                                                                             platform=input_parameters.platform,
                                                                                                             beam_manager_id=input_parameters.beam_manager_id)

                initial_motor_positions = self._motion_manager.get_motors_info().get_initial_positions(beam_manager_type=input_parameters.beam_manager_type,
                                                                                                              platform=input_parameters.platform,
                                                                                                              beam_manager_id=input_parameters.beam_manager_id,
                                                                                                              motor_ids=motors_to_optimize)

                yield from self._move_motors(initial_motor_positions)

            optimization_result = yield from self._optimize(**kwargs)
        else: raise ValueError("This operator should be called as optimizer.optimize())")

        self.__optimize_end(optimization_result, **kwargs)

    # -----------------------------------------------------------------------

    @abc.abstractmethod
    def _optimize(self, **kwargs) -> OptimizationResult: raise NotImplementedError

    # ---------------------------------------------------------------------
    # TRANSFER LEARNING
    # ---------------------------------------------------------------------

    def _manage_transfer_learning_input(self, **kwargs):
        if self._execution_parameters.do_warm_start:
            motors_to_optimize = self._input_parameters.motors_to_optimize
            beam_manager_type  = self._input_parameters.beam_manager_type
            platform           = self._input_parameters.platform
            beam_manager_id    = self._input_parameters.beam_manager_id
            motors_info        = copy.deepcopy(self._motion_manager.get_motors_info())

            if self._execution_parameters.warm_start_data_type == WarmStartDataType.WHOLE_DATASETS_NO_SOBOL: kwargs["excluded_data"] = "sobol"
            elif self._execution_parameters.warm_start_data_type == WarmStartDataType.WHOLE_DATASETS_NO_MOBO: kwargs["excluded_data"] = "mobo"
            else: kwargs["excluded_data"] = "default"

            search_ranges = motors_info.get_search_ranges(motor_ids=motors_to_optimize,
                                                          beam_manager_type=beam_manager_type,
                                                          platform=platform,
                                                          beam_manager_id=beam_manager_id)

            self._warm_start_data = get_warm_start_data(motors_to_optimize=motors_to_optimize,
                                                        optimization_criteria=self._optimization_criteria,
                                                        warm_start_home_directory=self._execution_parameters.warm_start_home_directory,
                                                        warm_start_data_type=self._execution_parameters.warm_start_data_type,
                                                        warm_start_strategy=self._execution_parameters.warm_start_strategy,
                                                        warm_start_expansion_factors=self._execution_parameters.warm_start_expansion_factors,
                                                        default_search_range=search_ranges,
                                                        motors_info=motors_info,
                                                        **kwargs)
        else:
            self._warm_start_data = None

    def _manage_transfer_learning_output(self, **kwargs):
        execution_parameters = self._execution_parameters

        if execution_parameters.save_warm_start_data:
            optimization_result = self._optimization_result
            ml_data_directory = execution_parameters.ml_data_directory

            if not (optimization_result is None or optimization_result.is_empty()):
                try: optimization_result.to_pickle(os.path.join(ml_data_directory, f"{self._get_ml_file_prefix()}_{self._get_date_string()}_ml.pkl"))
                except: print("ML data not saved")

    @classmethod
    @abc.abstractmethod
    def _get_ml_file_prefix(cls) -> str: raise NotImplementedError

    # ---------------------------------------------------------------------
    # POST-PROCESSING
    # ---------------------------------------------------------------------

    def get_optimization_result_data(self, **kwargs) -> OptimizationResult: return self._optimization_result

    def get_trial_data(self, trial_index: int, **kwargs) -> (OptimizationResultItem, BeamProperties):
        trial_data = self._optimization_result.get_optimization_item(trial_index)

        if kwargs.get("check_beam", False): beam_properties = self._get_beam_properties(trial_data.trial_number, trial_data.beam, f"trial_{trial_index}.png", **kwargs)
        else:                               beam_properties = None

        return trial_data, beam_properties

    def _get_beam_properties(self, trial_number, beam: Beam, file_name: str="beam_image.png", **kwargs) -> BeamProperties:
        beam_properties = None

        if not beam is None:
            beam_properties = self._beam_manager.get_beam_properties(beam,
                                                                     show_beam=kwargs.get("show_beam", False),
                                                                     save_image=kwargs.get("save_image", False),
                                                                     directory_name=self._execution_parameters.experiment_output_directory,
                                                                     trial_num=trial_number,
                                                                     file_name=file_name)
        return beam_properties

    # ------------------------------------------------------------------------------
    #  SAVE TO FILE AND PLOTS
    # ------------------------------------------------------------------------------

    def save_optimization_result(self, format=Format.PICKLE, **kwargs):
        if self._optimization_result is None: raise ValueError("There aren't any results to save")

        save_beams = self._input_parameters.get_parameter("save_beams", default=True)

        file_name = os.path.join(self._execution_parameters.experiment_output_directory,
                                 f"{self._get_result_file_prefix()}_optimization_results_{self._get_date_string()}")

        if not save_beams:
            beam_string_data = self._optimization_result.get_beam_hex_strings()
            self._optimization_result.set_beam_hex_strings(beam_string_data={trial_number: None for trial_number in self._optimization_result.get_trial_numbers()})

        try:
            if   format == Format.CSV:    self._optimization_result.to_csv(file_name=file_name + ".csv")
            elif format == Format.PICKLE: self._optimization_result.to_pickle(file_name=file_name + ".pkl")
            elif format == Format.JSON:   self._optimization_result.to_json(file_name=file_name + ".json")
            else: raise ValueError("Format not supported")
        except Exception as e:
            print("Results not saved: " + str(e))

        if not save_beams:
            self._optimization_result.set_beam_hex_strings(beam_string_data=beam_string_data)

    @classmethod
    @abc.abstractmethod
    def _get_result_file_prefix(cls) -> str: raise NotImplementedError

    def plot_optimization_history(self, optimization_criteria: OptimizationCriteria = None,
                                  plot_images: bool=True,
                                  save_images: bool=False,
                                  **kwargs) -> Figure:
        return plot_utility.plot_optimization_history(optimization_result=self._optimization_result,
                                                      optimization_criteria=self._optimization_criteria if optimization_criteria is None else optimization_criteria,
                                                      plot_images=plot_images,
                                                      save_images=save_images,
                                                      output_directory=self._execution_parameters.experiment_output_directory,
                                                      file_name_prefix=self._get_result_file_prefix(),
                                                      **kwargs)

    def plot_optimization_history_correlations(self, optimization_criteria: OptimizationCriteria = None,
                                               plot_images: bool=True,
                                               save_images: bool=False,
                                               **kwargs) -> List[Figure]:
        return plot_utility.plot_optimization_history_correlations(optimization_result=self._optimization_result,
                                                                   optimization_criteria=self._optimization_criteria if optimization_criteria is None else optimization_criteria,
                                                                   plot_images=plot_images,
                                                                   save_images=save_images,
                                                                   output_directory=self._execution_parameters.experiment_output_directory,
                                                                   file_name_prefix=self._get_result_file_prefix(),
                                                                   **kwargs)

    # ---------------------------------------------------------------------
    # MOTOR MOTION PROTECTED METHODS
    # ---------------------------------------------------------------------

    def _get_all_motor_ids(self):
        return self._motion_manager.get_motors_info().get_motor_ids()

    def _check_motor_positions(self, suggested_motor_positions, current_motors_positions):
        motors_info = self._motion_manager.get_motors_info()
        for motor_id in suggested_motor_positions:
            motor_info = motors_info.get_motor_info(motor_id)

            if motor_info.repeatability > 0.0:
                reference_value = motor_info.repeatability
                reference_text = "repeatability"
            else:
                reference_value = motor_info.resolution
                reference_text = "resolution"

            if abs(suggested_motor_positions[motor_id] - current_motors_positions[motor_id]) > 10 * reference_value:
                return False, f"Motor {motor_id} is not correctly positioned (offset > 10*{reference_text})"

        return True, None

    # -----------------------------------------------------------------------
    # BLUESKY DYNAMIC MANAGEMENT -> PRIVATE METHODS
    # -----------------------------------------------------------------------

    @abc.abstractmethod
    def _move_motors(self, motor_positions): raise NotImplementedError("run initialize_driver first")
    @abc.abstractmethod
    def _get_current_motors_positions(self): raise NotImplementedError("run initialize_driver first")

    def __move_motors(self, motor_positions):
        self._motion_manager.move_motors(motor_positions, Movement.ABSOLUTE)

    def __move_motors_generator(self, motor_positions):
        yield from self._motion_manager.move_motors(motor_positions, Movement.ABSOLUTE)

    def __get_current_motors_positions(self):
        return self._motion_manager.get_motor_positions(self._input_parameters.motors_to_optimize)

    def __get_current_motors_positions_generator(self):
        positions = yield from self._motion_manager.get_motor_positions(self._input_parameters.motors_to_optimize)
        return positions

    @classmethod
    def _get_date_string(cls): return datetime_string()