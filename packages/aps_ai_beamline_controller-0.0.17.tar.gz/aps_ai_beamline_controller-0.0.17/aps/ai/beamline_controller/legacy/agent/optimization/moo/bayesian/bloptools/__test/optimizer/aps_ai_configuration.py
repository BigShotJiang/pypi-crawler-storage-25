#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #

import os
from typing import List

from aps.common.initializer import get_registered_ini_instance, register_ini_instance, IniMode

from aps.common.reflection import get_class_full_name, instance_for_name, get_class_name_and_module
from aps.common.data_structures import DictionaryWrapper

from aps.ai.beamline_controller.legacy.gui.bl.optics_controller import APPLICATION_NAME
from aps.ai.beamline_controller.legacy.initialization.facade import NullAgentInitializer
from aps.ai.beamline_controller.legacy.initialization.agent_initializer_factory import initialize_agent_initializer_factory, create_agent_initializer

from aps.beamline_driver.beam_management.beam_manager_factory import initialize_beam_manager_factory, create_beam_manager
from aps.beamline_driver.motion_management.motion_manager_factory import initialize_motion_manager_factory, create_motion_manager
from aps.ai.beamline_controller.legacy.agent.optimization.hypervolume_manager_factory import initialize_hypervolume_manager_factory, create_hypervolume_manager
from aps.ai.beamline_controller.legacy.agent.optimization.optimizer_factory import initialize_optimizer_factory
from aps.ai.beamline_controller.legacy.agent.agent_listener_factory import initialize_agent_listener_factory

from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.bloptools.hypervolume_manager import BlopToolsDirectBeamImageHypervolumeManager, BlopToolsWavefrontAnalysisHypervolumeManager
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.bloptools.optimizer import BlopToolsOptimizer
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.bloptools.optimization_listener import BlopToolsOptimizationListener

BEAMLINE_ID="8-ID"

try:
    from epics import ca
    ca.finalize_libca()
except:
    pass

os.chdir("/TEST_DIR/GUI/8-ID")

def get_objectives_from_ini(values_list : List[str]):
    objectives = {}
    for item in values_list:
        tokens = item.split(sep=":")
        criterion = tokens[0].strip()
        values    = tokens[1].split(sep=";")
        reference = values[0][1:].strip()
        boundary  = values[1].strip()
        weight    = values[2].strip()
        exit      = values[3][:-1].strip()

        objectives[criterion] = [reference, boundary, weight, exit]

    return objectives


class APS_AI_Objects():
    def __init__(self,
                 objectives,
                 motion_manager,
                 beam_manager,
                 hypervolume_manager):
        self.__objectives          = objectives
        self.__motion_manager      = motion_manager
        self.__beam_manager        = beam_manager
        self.__hypervolume_manager = hypervolume_manager

    @property
    def objectives(self): return self.__objectives
    @property
    def motion_manager(self): return self.__motion_manager
    @property
    def beam_manager(self): return self.__beam_manager
    @property
    def hypervolume_manager(self): return self.__hypervolume_manager

def initialize_aps_ai():
    register_ini_instance(IniMode.LOCAL_FILE, ini_file_name=".optics-controller.ini", application_name=APPLICATION_NAME)
    ini = get_registered_ini_instance(APPLICATION_NAME)

    initialize_agent_initializer_factory(classes={BEAMLINE_ID: get_class_full_name(NullAgentInitializer)})

    motion_manager_args = {}
    beam_manager_args = {"nbins_h": ini.get_int_from_ini("Beam-Manager", "nbins_h", default=2001),
                         "nbins_v": ini.get_int_from_ini("Beam-Manager", "nbins_v", default=2001),
                         "xrange": ini.get_list_from_ini("Beam-Manager", "xrange", type=float, default=[-100e-6, 100e-6]),
                         "yrange": ini.get_list_from_ini("Beam-Manager", "xrange", type=float, default=[-100e-6, 100e-6])}

    motion_manager_json_file = os.path.join(os.path.abspath(os.getcwd()), f"optical_system_{BEAMLINE_ID}_motion_manager.json")
    if os.path.exists(motion_manager_json_file): motion_manager_args["json_file"] = motion_manager_json_file
    beam_manager_json_file = os.path.join(os.path.abspath(os.getcwd()), f"optical_system_{BEAMLINE_ID}_beam_manager.json")
    if os.path.exists(beam_manager_json_file): beam_manager_args["json_file"] = beam_manager_json_file

    beam_profile_digital_twin_class, beam_profile_digital_twin_module = get_class_name_and_module(ini.get_string_from_ini("Initialization", "beam_profile_digital_twin", default=None))
    wavefront_analysis_digital_twin_class, wavefront_analysis_digital_twin_module = get_class_name_and_module(ini.get_string_from_ini("Initialization", "wavefront_analysis_digital_twin", default=None))

    digital_twin_args = {"motors_configuration_json_file": motion_manager_json_file}
    digital_twin_args.update(beam_manager_args)
    digital_twin_args.update(motion_manager_args)

    digital_twin_args.update({"beam_manager_id": "DT-BP"})
    beam_profile_digital_twin = instance_for_name(module_name=beam_profile_digital_twin_module,
                                                  class_name=beam_profile_digital_twin_class,
                                                  digital_twin_init_parameters=DictionaryWrapper(**digital_twin_args))
    digital_twin_args.update({"beam_manager_id": "DT-WA"})
    wavefront_analysis_digital_twin = instance_for_name(module_name=wavefront_analysis_digital_twin_module,
                                                        class_name=wavefront_analysis_digital_twin_class,
                                                        digital_twin_init_parameters=DictionaryWrapper(**digital_twin_args))

    initialize_motion_manager_factory(classes={}, instances={BEAMLINE_ID + "-" + beam_profile_digital_twin.get_beam_manager_id(): beam_profile_digital_twin,
                                                             BEAMLINE_ID + "-" + wavefront_analysis_digital_twin.get_beam_manager_id(): wavefront_analysis_digital_twin})
    initialize_beam_manager_factory(classes={}, instances={BEAMLINE_ID + "-" + beam_profile_digital_twin.get_beam_manager_id(): beam_profile_digital_twin,
                                                           BEAMLINE_ID + "-" + wavefront_analysis_digital_twin.get_beam_manager_id(): wavefront_analysis_digital_twin})
    initialize_hypervolume_manager_factory(classes={"BLOPTools-BP": get_class_full_name(BlopToolsDirectBeamImageHypervolumeManager),
                                                    "BlopTools-WA": get_class_full_name(BlopToolsWavefrontAnalysisHypervolumeManager)})
    initialize_optimizer_factory(classes={"BLOPTools": get_class_full_name(BlopToolsOptimizer)})

    initialize_agent_listener_factory(classes={"BLOPTools" : get_class_full_name(BlopToolsOptimizationListener)})

    agent_initializer = create_agent_initializer(agent_initializer_id=BEAMLINE_ID)
    agent_initializer.preliminary_setup()

    return APS_AI_Objects(objectives          = get_objectives_from_ini(ini.get_list_from_ini("AI", "objectives", default=[], type=str)),
                          motion_manager      = create_motion_manager(motion_manager_id=BEAMLINE_ID + "-DT-BP", **motion_manager_args),
                          beam_manager        = create_beam_manager(beam_manager_id=BEAMLINE_ID + "-DT-BP", **beam_manager_args),
                          hypervolume_manager = create_hypervolume_manager(hypervolume_manager_id="BLOPTools-BP"))

