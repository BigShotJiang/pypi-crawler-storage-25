#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import os
from typing import List
import numpy as np

from matplotlib.figure import Figure
from matplotlib import colors
import cmasher as cmm

from aps.ai.beamline_controller.legacy.agent.optimization.facade import OptimizationCriteria, OptimizationResult

def plot_optimization_history(optimization_result: OptimizationResult,
                              optimization_criteria: OptimizationCriteria,
                              plot_images: bool = True,
                              save_images: bool = False,
                              output_directory = os.path.abspath(os.getcwd()),
                              file_name_prefix = "current",
                              **kwargs) -> Figure:
    plt             = kwargs.get("plt", None)
    loss_null_value = kwargs.get("loss_null_value", np.nan)

    if not plt: fig = Figure(figsize=(12, 10))
    else:       fig = plt.figure(figsize=(12, 10))

    ranges = kwargs.get("ranges", {})
    trials = kwargs.get("trials", [0, -1])

    if not (optimization_result is None or optimization_result.is_empty()):
        for idx in range(optimization_criteria.number):
            optimization_criterion = optimization_criteria.names[idx]
            objective_mean = [(loss_function[optimization_criterion] if len(loss_function) > 0 else loss_null_value) for loss_function in optimization_result.get_loss_functions().values()]
            fig.add_subplot(optimization_criteria.number, 1, idx + 1)
            fig.gca().scatter(optimization_result.get_trial_numbers()[trials[0]: trials[1]], objective_mean[trials[0]: trials[1]], marker='o')
            fig.gca().set_xlabel("Iteration")
            fig.gca().set_ylabel(optimization_criterion)

            ylim = ranges.get(optimization_criterion, None)
            if not ylim is None:  fig.gca().set_ylim(ylim[0], ylim[-1])

            fig.gca().set_title("Objective Value vs. Iteration")
            fig.gca().grid(True)
            fig.gca().legend(loc="best")

        fig.subplots_adjust(hspace=0.5)

        if save_images:
            fig.savefig(os.path.join(os.path.abspath(output_directory), f"{file_name_prefix}_optimization_history.png"))
            fig.canvas.draw_idle()
        if plot_images:
            if not plt: fig.show()
            else:       plt.show()

    return fig

def plot_optimization_history_correlations(optimization_result: OptimizationResult,
                                           optimization_criteria: OptimizationCriteria,
                                           plot_images: bool = True,
                                           save_images: bool = False,
                                           output_directory = os.path.abspath(os.getcwd()),
                                           file_name_prefix = "current",
                                           **kwargs) -> List[Figure]:
    plt             = kwargs.get("plt", None)
    loss_null_value = kwargs.get("loss_null_value", np.nan)
    if plt: fignum = kwargs.pop("fignum", 1)

    figs = []

    if not (optimization_result is None or optimization_result.is_empty()):
        trial_numbers = optimization_result.get_trial_numbers()
        loss_history  = optimization_result.get_loss_functions().values()

        for obj_x, obj_y in optimization_criteria.criteria_pairs:
            # Extract data
            objx_val = np.array([(loss_function[obj_x] if len(loss_function) > 0 else loss_null_value) for loss_function in loss_history])
            objy_val = np.array([(loss_function[obj_y] if len(loss_function) > 0 else loss_null_value) for loss_function in loss_history])
            # Create figure and axis
            if not plt: fig = Figure(figsize=(6, 5), constrained_layout=True)
            else:
                fig = plt.figure(fignum, figsize=(6, 5), constrained_layout=True)
                fignum += 1

            ax  = fig.subplots()
            # Plot data on ax

            scatter_args = {key : kwargs.get(key) for key in kwargs.keys() if not key=="plt"}

            sc1 = ax.scatter(objx_val, objy_val, c=trial_numbers, cmap=cmm.tropical_r, marker="o", alpha=0.5,
                             norm=colors.Normalize(0, len(trial_numbers)), **scatter_args)

            if (np.all(objx_val > 0)): ax.set_xscale("log")
            if (np.all(objy_val > 0)): ax.set_yscale("log")
            ax.set_xlabel(f"{obj_x},(mm)", fontsize=12)
            ax.set_ylabel(f"{obj_y},(mm)", fontsize=12)
            cbar = fig.colorbar(mappable=sc1, pad=0.03, aspect=25, shrink=0.75, location="right")
            cbar.ax.text(0.5, 1.02, "Trial", transform=cbar.ax.transAxes, ha='center', va='bottom')

            if save_images:
                fig.savefig(os.path.join(os.path.abspath(output_directory), f"{file_name_prefix}_loss_function_{obj_x}_vs_{obj_y}.png"))
                fig.canvas.draw_idle()
            if plot_images:
                if not plt: fig.show()
                else:       plt.show()

            figs.append(fig)

    if not plt: return figs
    else:       return figs, fignum
