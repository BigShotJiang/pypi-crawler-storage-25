#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import os.path
from time import time
import numpy as np
from warnings import warn
from typing import List

from aps.ai.beamline_controller.legacy.agent.optimization.facade import OptimizationInputParameters, OptimizationExecutionParameters,\
    OptimizationResult, OptimizationResultItem, WarmStartDataType, WarmStartStrategy
from aps.ai.beamline_controller.legacy.agent.facade import Fidelity
from aps.beamline_driver.beam_management.facade import Beam

# -------------------------------------------------------------
# USER INPUT
# -------------------------------------------------------------

class NonLinearOptimizationInputParameters(OptimizationInputParameters):
    def __init__(self,
                 method=None,
                 max_iteration=100,
                 motors_to_optimize=None,
                 beam_manager_type: str = None,
                 platform: str          = None,
                 beam_manager_id: str   = None,
                 random_seed=2124,
                 **kwargs):
        super(NonLinearOptimizationInputParameters, self).__init__(motors_to_optimize=motors_to_optimize,
                                                                   beam_manager_type=beam_manager_type,
                                                                   platform=platform,
                                                                   beam_manager_id=beam_manager_id,
                                                                   random_seed=random_seed,
                                                                   **kwargs)

        self.__method = method
        self.__max_iteration = max_iteration

    @property
    def method(self): return self.__method

    @property
    def max_iteration(self): return self.__max_iteration

class NonLinearOptimizationExecutionParameters(OptimizationExecutionParameters):
    def __init__(self,
                 home_directory: str = os.curdir,
                 do_warm_start=False,
                 warm_start_home_directory: str = os.curdir,
                 warm_start_strategy=WarmStartStrategy.MAXIMUM_EXTENSION,
                 warm_start_expansion_factors = [0.0, 0.01],
                 warm_start_data_type: int = WarmStartDataType.PARETO_FRONTIERS,
                 save_warm_start_data: bool = False,
                 use_exit_strategy: bool = False,
                 exit_loss_function: dict = {}):
        super(NonLinearOptimizationExecutionParameters, self).__init__(home_directory=home_directory,
                                                                       do_warm_start=do_warm_start,
                                                                       warm_start_home_directory=warm_start_home_directory,
                                                                       warm_start_strategy=warm_start_strategy,
                                                                       warm_start_expansion_factors=warm_start_expansion_factors,
                                                                       warm_start_data_type=warm_start_data_type,
                                                                       use_warm_start_search_space=True,
                                                                       save_warm_start_data=save_warm_start_data,
                                                                       use_exit_strategy=use_exit_strategy,
                                                                       exit_loss_function=exit_loss_function)

class NonlinearOptimizationResultItem(OptimizationResultItem):
    def __init__(self,
                 trial_number: int = 0,
                 start_time:float = time(),
                 end_time: float  = time(),
                 fidelity: int = Fidelity.LOW,
                 motor_positions: dict = {},  # {motor_id : position}
                 loss_function: dict = {},    # {optimization_criterion : loss }
                 loss: float = np.nan,
                 beam: Beam = None,
                 beam_string: str = None):
        super(NonlinearOptimizationResultItem, self).__init__(trial_number=trial_number,
                                                              start_time=start_time,
                                                              end_time=end_time,
                                                              fidelity=fidelity,
                                                              motor_positions=motor_positions,
                                                              loss_function=loss_function,
                                                              beam=beam,
                                                              beam_string=beam_string)
        self.__loss = loss

    @property
    def loss(self) -> float: return self.__loss

    @property
    def headers(self) -> list:
        headers = super(NonlinearOptimizationResultItem, self).headers
        headers.append("loss")
        return headers

    def to_dictionary(self) -> dict:
        dict = super(NonlinearOptimizationResultItem, self).to_dictionary()
        dict["loss"] = self.loss
        return dict

    @classmethod
    def from_dictionary(cls, dictionary: dict):
        return NonlinearOptimizationResultItem(trial_number=int(dictionary["trial_number"]),
                                               start_time=float(dictionary.get("start_time", 0.0)),
                                               end_time=float(dictionary.get("end_time", 0.0)),
                                               fidelity=int(dictionary.get("fidelity"), Fidelity.LOW),
                                               motor_positions={key[:-5]: float(dictionary[key]) for key in dictionary.keys() if key.endswith("-(MP)")},
                                               loss_function={key[:-5]: float(dictionary[key]) for key in dictionary.keys() if key.endswith("-(LF)")},
                                               loss=dictionary.get("loss", np.nan),
                                               beam_string=dictionary["beam"])

class NonlinearOptimizationResult(OptimizationResult):
    def __init__(self, optimization_items: List[NonlinearOptimizationResultItem]=None):
        super(NonlinearOptimizationResult, self).__init__(optimization_items)

    def get_losses(self) -> List[int]:
        return [item.loss for item in self.get_optimization_items()]

    def get_best_trial(self) -> NonlinearOptimizationResultItem:
        return self.get_optimization_items()[-1]

    # on subclasses the return is removed. It is necessary only in this particular call to super.
    def initialize_warm_start_data(self, current_search_range: dict, strategy: int = WarmStartStrategy.MAXIMUM_EXTENSION, expansion_factors: list = [0.1, 1.5], **kwargs):
        warn("Non-linear optimization result should not be used to initialize warm start data")

        super(NonlinearOptimizationResult, self).initialize_warm_start_data(current_search_range, **kwargs)
