#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import os
import time

from databroker import Broker
from databroker.assets.utils import install_sentinels
from bluesky.callbacks.best_effort import BestEffortCallback
from bluesky.run_engine import RunEngine

VERBOSE = True

def get_data_broker():
    data_broker = Broker.named("temp")
    try:    install_sentinels(data_broker.reg.config, version=1)
    except: pass

    return data_broker

RE = RunEngine({})
data_broker = get_data_broker()
RE.subscribe(BestEffortCallback())
RE.subscribe(data_broker.insert)

from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.bloptools.__test.optimizer.aps_ai_configuration import initialize_aps_ai, BEAMLINE_ID

from aps.ai.beamline_controller.legacy.agent.optimization.facade import OptimizationCriteria
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.facade import BayesianOptimizationExecutionParameters, BayesianOptimizationInputParameters
from aps.beamline_driver.beam_management.beam_manager_factory import create_beam_manager
from aps.beamline_driver.motion_management.motion_manager_factory import create_motion_manager
from aps.ai.beamline_controller.legacy.agent.agent_listener_factory import create_agent_listener
from aps.ai.beamline_controller.legacy.agent.optimization.optimizer_factory import create_optimizer
from aps.ai.beamline_controller.legacy.agent.optimization.hypervolume_manager_factory import create_hypervolume_manager

# ------------------------------------------------------------------------
# this call hides all that is necessary from the APS.AI framework
# to create Bluesky entities to be used by BLOPTools
# ------------------------------------------------------------------------

aps_ai_objects = initialize_aps_ai()

platform          = "DT"
beam_manager_type = "BP"
optimizer_name    = "BLOPTools"

id = BEAMLINE_ID + "-" + platform + "-" + beam_manager_type

motion_manager = create_motion_manager(motion_manager_id=id)
beam_manager   = create_beam_manager(beam_manager_id=id)

hypervolume_reference_points = {}
optimization_criteria_reference_values = {}
optimization_criteria_weights = {}
exit_loss_function = {}

objectives = aps_ai_objects.objectives

for optimization_criterion in objectives.keys():
    values = objectives[optimization_criterion]
    optimization_criteria_reference_values[optimization_criterion] = float(values[0])
    hypervolume_reference_points[optimization_criterion] = float(values[1])
    optimization_criteria_weights[optimization_criterion] = float(values[2])
    if float(values[3]) != 0.0: exit_loss_function[optimization_criterion] = float(values[3])

use_exit_strategy = False
warm_start = False

acquisition_function = "qei"
selection_algorithm = None

hypervolume_manager_args = {"hypervolume_reference_points": hypervolume_reference_points,
                            "optimization_criteria_reference_values": optimization_criteria_reference_values,
                            "optimization_criteria_constraints": {},  # no constrained optimzer for now
                            "optimization_criteria_weights": optimization_criteria_weights}
hypervolume_manager = create_hypervolume_manager(hypervolume_manager_id=optimizer_name + "-" + beam_manager_type, **hypervolume_manager_args)

home_directory = os.path.join(os.path.abspath(os.getcwd()),
                              f"{optimizer_name}-{platform}-{beam_manager_type}-cr{len(objectives.keys())}" + ("-ws" if warm_start else ""))

sobol_trials = 10
bo_trials = 50

if not warm_start:
    execution_parameters = BayesianOptimizationExecutionParameters(do_warm_start=False,
                                                                   home_directory=home_directory,
                                                                   use_exit_strategy=use_exit_strategy,
                                                                   exit_loss_function=exit_loss_function)
    input_parameters = BayesianOptimizationInputParameters(acquisition_function=acquisition_function,
                                                           sobol_trials=sobol_trials,
                                                           bo_trials=bo_trials,
                                                           motors_to_optimize=None,
                                                           random_seed=int(time.time()))
else:
    execution_parameters = BayesianOptimizationExecutionParameters(do_warm_start=True,
                                                                   use_warm_start_search_space=True,
                                                                   use_warm_start_hypervolume_reference_points=True,
                                                                   warm_start_hypervolume_reference_points_coefficient=0.05,
                                                                   home_directory=home_directory,
                                                                   use_exit_strategy=use_exit_strategy,
                                                                   exit_loss_function=exit_loss_function)
    input_parameters = BayesianOptimizationInputParameters(acquisition_function=acquisition_function,
                                                           bo_trials=bo_trials,
                                                           motors_to_optimize=None,
                                                           random_seed=int(time.time()))

optimizer_kwargs = {}
optimizer_kwargs["verbose"] = VERBOSE
optimizer_kwargs["data_broker"] = data_broker

optimizer = create_optimizer(optimizer_id=optimizer_name,
                             optimization_listener=create_agent_listener(listener_id=optimizer_name), **{})

optimizer.initialize_driver(beam_manager, motion_manager)
optimizer.initialize_optimization(hypervolume_manager, **optimizer_kwargs)

RE(optimizer.optimize(optimization_criteria=OptimizationCriteria(list(objectives.keys())),
                      execution_parameters=execution_parameters,
                      input_parameters=input_parameters, **{}))

optimization_result_data = optimizer.get_optimization_result_data()

print([f"Total duration: {round(optimization_result_data.get_optimization_duration(), 1)} sec"])

optimizer.save_optimization_result()
optimizer.plot_optimization_history(**{"plot_images": False, "save_images": True})
optimizer.plot_optimization_history_correlations(**{"plot_images": False, "save_images": True})

pareto_front_data = optimizer.get_pareto_front_data()

if not pareto_front_data is None and not pareto_front_data.is_empty():
    optimizer.save_pareto_front()
    optimizer.plot_pareto_front(**{"plot_images": False, "save_images": True})
    best_trial_data, _ = optimizer.get_best_trial_data(algorithm=selection_algorithm, move_motors=True,
                                                       **{"check_beam": True, "show_beam": False, "save_image": True})
else:
    best_trial_data = None


