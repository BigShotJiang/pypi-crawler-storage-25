#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #

from typing import Type

from torch import Tensor, Size
from torch.nn import Sequential, Linear, ReLU, Module

from gpytorch.models.exact_gp import ExactGP
from gpytorch.distributions.multivariate_normal import MultivariateNormal
from gpytorch.utils.grid import ScaleToBounds
from gpytorch.kernels import GridInterpolationKernel, ScaleKernel, RBFKernel
from gpytorch.means import ConstantMean
from gpytorch.likelihoods import Likelihood, GaussianLikelihood

from botorch.models.gpytorch import BatchedMultiOutputGPyTorchModel
from botorch.models.model import FantasizeMixin

class NNFeatureExtractor(Sequential):
    """MLP feature extractor"""
    def __init__(self, input_dimension, output_dimension, hidden_dimensions=[1000, 500, 50]):
        """Initializes a feature extractor module"""
        super(NNFeatureExtractor, self).__init__()
        if hidden_dimensions is None: hidden_dimensions = [1000, 500, 50]
        hidden_dimensions.append(output_dimension)
        self.add_module("linear1", Linear(input_dimension, hidden_dimensions[0]))
        for i, h in enumerate(hidden_dimensions[1:]):
            self.add_module('relu{}'.format(i+1), ReLU())
            self.add_module('linear{}'.format(i+2), Linear(hidden_dimensions[i], h))

class DeepKernelGPModel(BatchedMultiOutputGPyTorchModel, ExactGP, FantasizeMixin):
    """DKL GPR module"""
    def __init__(self,
                 train_X: Tensor,
                 train_Y: Tensor,
                 likelihood: Type[Likelihood] = None,
                 feature_extractor: Type[Module] = None,
                 output_dimension: int = None,
                 grid_size: int = 50) -> None:
        """
        Initializes DKL GP module
        """
        super(DeepKernelGPModel, self).__init__(train_X, train_Y, likelihood if not likelihood is None else GaussianLikelihood())

        batch_dimension = train_Y.size(0)

        output_dimension  = batch_dimension if output_dimension is None else output_dimension
        feature_extractor = NNFeatureExtractor() if feature_extractor is None else feature_extractor

        self.mean_module  = ConstantMean(batch_shape=Size([batch_dimension]))
        self.covar_module = GridInterpolationKernel(base_kernel = ScaleKernel(RBFKernel(ard_num_dims=output_dimension,
                                                                                        batch_shape=Size([batch_dimension])),
                                                                              batch_shape=Size([batch_dimension])),
                                                    num_dims=output_dimension,
                                                    grid_size=grid_size)
        self.feature_extractor = feature_extractor
        self.scale_to_bounds   = ScaleToBounds(-1., 1.)

    def forward(self, x: Tensor) -> MultivariateNormal:
        """
        Forward pass
        """
        # Pass data through a neural network
        embedded_x = self.feature_extractor(x)
        embedded_x = self.scale_to_bounds(embedded_x)

        # Standard GP part
        mean_x  = self.mean_module(embedded_x)
        covar_x = self.covar_module(embedded_x)

        return MultivariateNormal(mean_x, covar_x)


