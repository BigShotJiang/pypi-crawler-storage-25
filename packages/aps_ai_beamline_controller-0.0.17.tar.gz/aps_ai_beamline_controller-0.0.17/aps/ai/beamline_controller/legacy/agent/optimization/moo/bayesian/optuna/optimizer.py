#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
###########################################################################
# Author: Saugat Kandel
#
# this code was in the module optuna_optimizer.py
###########################################################################

import warnings
from time import time

from optuna import create_study, TrialPruned
from optuna.trial import Trial
from optuna.samplers import PartialFixedSampler
from optuna.exceptions import ExperimentalWarning

from aps.ai.beamline_controller.legacy.agent.facade import IAgentListener
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.facade import MOBOBayesianOptimizationInputParameters, MOBOBayesianOptimizationResult
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.abstract_optimizer import MOBOAbstractBayesianOptimizer
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.optuna.botorch.botorch_sampler import BoTorchSampler

warnings.filterwarnings("ignore", category=ExperimentalWarning)

class OptunaOptimizer(MOBOAbstractBayesianOptimizer):
    def __init__(self, optimization_listener : IAgentListener, **kwargs):
        super(OptunaOptimizer, self).__init__(optimization_listener, **kwargs)

    # ------------------------------------------------------------------------------
    #  AbstractBayesianOptimizer implementation
    # ------------------------------------------------------------------------------

    def _create_optimization_agent(self, **kwargs):
        execution_parameters  = self._execution_parameters
        input_parameters      = self._input_parameters

        if execution_parameters.do_warm_start:     raise ValueError("do_warm_start not supported by Optuna Optimizer")
        if execution_parameters.use_exit_strategy: raise ValueError("use_exit_strategy not supported by Optuna Optimizer")

        optimization_parameters = self._optimization_parameters
        initial_motor_positions = self._motion_manager.get_motor_positions(input_parameters.motors_to_optimize)
        
        input_parameters.set_parameter("optimization_criteria_constraints",  optimization_parameters.get_parameter("optimization_criteria_constraints"))

        optional_parameters = {}
        optional_parameters["constraints_func"] = optimization_parameters.get_parameter("constraints_function") if optimization_parameters.get_parameter("has_constraints") else None
        optional_parameters["n_startup_trials"] = 0
        optional_parameters["seed"] = input_parameters.random_seed
        optional_parameters["mean_module"] = None
        optional_parameters["covar_module"] = None

        if not input_parameters.is_partial_optimization:
            sampler = BoTorchSampler(candidates_func=optimization_parameters.get_parameter("acquisition_function"), **optional_parameters)
        else:
            sampler = PartialFixedSampler(fixed_params={k: initial_motor_positions[k] for k in self._motion_manager.get_motors_info().get_motor_ids() if k not in input_parameters.motors_to_optimize},
                                          base_sampler=BoTorchSampler(candidates_func=optimization_parameters.get_parameter("acquisition_function"), **optional_parameters))

        study = create_study(sampler=sampler, directions=optimization_parameters.get_parameter("optimization_directions").values())
        study.enqueue_trial(initial_motor_positions)
        
        return study

    def _run_optimization(self, **kwargs):
        study                     = self._optimization_agent
        input_parameters          = self._input_parameters
        objective_function        = lambda t: self.__objective_function(t)
        self.__current_timestamps = {}

        study.optimize(objective_function, n_trials=input_parameters.bo_trials)

        return input_parameters.bo_trials, self.__current_timestamps

    # ------------------------------------------------------------------------------
    #  OBJECTIVE FUNCTION
    # ------------------------------------------------------------------------------

    def __objective_function(self, trial: Trial):
        optimization_criteria     = self._optimization_criteria
        input_parameters          = self._input_parameters
        motors_to_optimize        = input_parameters.motors_to_optimize
        suggested_motor_positions = self.__get_suggested_motor_positions(trial, input_parameters)

        self.__current_timestamps[trial.number] = [time(), time()]

        def manage_error(current_motors_positions, error_message):
            error_loss = self._hypervolume_manager.get_error_loss_function(optimization_criteria)

            self._optimization_listener.feedback(trial, motors_to_optimize, current_motors_positions, error_loss)
            self.__prune_trial(trial, suggested_motor_positions, current_motors_positions, error_message)

            return error_loss

        try:
            self._move_motors(suggested_motor_positions)
            current_motors_positions = self._get_current_motors_positions()

            motor_ok, error_message = self._check_motor_positions(suggested_motor_positions, current_motors_positions)

            if not motor_ok: return manage_error(current_motors_positions, error_message)
        except Exception as e:
            return manage_error(current_motors_positions, "Unexpected error while setting motors: " + str(e))

        try:
            beam_properties = self._beam_manager.get_beam_properties(self._beam_manager.get_beam())

            if beam_properties.get_parameter("is_empty_beam"): return manage_error(current_motors_positions, "Beam is Empty")

            loss, error, message =  self._hypervolume_manager.evaluate_loss_function(beam_properties, optimization_criteria)
            self._hypervolume_manager.set_trial_constraints(input_parameters.get_parameter("optimization_criteria_constraints"), beam_properties, trial)

            if error > 0:
                return manage_error(current_motors_positions, message)
            else:
                self._optimization_listener.feedback(trial, motors_to_optimize, current_motors_positions, loss)

                return loss
        except Exception as e:
           return manage_error(current_motors_positions, "Unexpected error: " + str(e))

    def __get_suggested_motor_positions(self, trial, input_parameters: MOBOBayesianOptimizationInputParameters):
        motors_info = self._motion_manager.get_motors_info()

        suggested_motor_positions = {}
        for motor_id in input_parameters.motors_to_optimize:
            motor_info = motors_info.get_motor_info(motor_id)
            search_range = [float(item) for item in motor_info.search_range]

            resolution = round(motor_info.resolution, 7)  # rounding is needed to clean python long digits
            low  = search_range[0]
            high = ((search_range[1] - search_range[0]) // resolution) * resolution + low

            suggested_motor_positions[motor_id] = trial.suggest_float(name=motor_id,
                                                                      low=round(low, 7),
                                                                      high=round(high, 7),
                                                                      step=resolution)
        return suggested_motor_positions

    def __prune_trial(self, trial, suggested_motor_positions, current_motors_positions, message):
        text = "Pruning trial with parameters: " + str(trial.params) + "\n"
        text += "for the following reason: " + message + "\n\n"
        text += "Suggested Motors Positions: " + str(suggested_motor_positions) + "\n"
        text += "Actual Motors Positions   : " + str(current_motors_positions)

        raise TrialPruned(text)

    # ---------------------------------------------------------------------
    # WARM-START
    # ---------------------------------------------------------------------

    @classmethod
    def _get_pareto_file_prefix(cls) -> str: return "optuna_experiment"

    @classmethod
    def _get_ml_file_prefix(cls) -> str: return cls._get_pareto_file_prefix()

    def _manage_transfer_learning_input(self, **kwargs):
        if self._execution_parameters.do_warm_start: raise NotImplementedError("BlopTools does not support warm start")
        else:                                        self._warm_start_data = None

    # ------------------------------------------------------------------------------
    #  SAVE TO FILE AND PLOTS
    # ------------------------------------------------------------------------------

    @classmethod
    def _get_result_file_prefix(cls) -> str: return cls._get_pareto_file_prefix()

    '''
    def load_optimization_result(self, file_path: str, optimization_criteria: OptimizationCriteria, n_trials: int = None) -> Study:
        trials = joblib.load(file_path)

        if not n_trials is None: trials = trials[: min(n_trials, len(trials))]
        dist_mins = {}
        dist_maxes = {}
        for trial in trials:
            for td, tdval in trial.distributions.items():
                dist_mins.setdefault(td, tdval.low)
                dist_maxes.setdefault(td, tdval.high)
                dist_mins[td] = np.minimum(dist_mins[td], trial.params[td])
                dist_maxes[td] = np.maximum(dist_maxes[td], trial.params[td])

        for trial in trials:
            for td, tdval in trial.distributions.items():
                tdval.step = None
                tdval.high = dist_maxes[td]
                tdval.low  = dist_mins[td]

        optimizer_initialization = self._hypervolume_manager.get_optimizer_initialization(optimization_criteria)

        self._current_optimization_agent = create_study(directions=optimizer_initialization.get_parameter("optimization_directions").values())
        self._current_optimization_agent.add_trials(trials)
        self._current_pareto_front_data = self._hypervolume_manager.extract_pareto_front_data(self._current_optimization_agent, optimization_criteria)
    '''
