import time
import os
from datetime import datetime

from aps.ai.beamline_controller.legacy.agent.machine_learning.deep_kernel_model.example_code.runyu.bo_modular import AxNNOptimizer, OptimizationMode, TrainingDataInfo, SimpleCustomGP

try:
    from epics import ca
    ca.finalize_libca()
except:
    pass

current_datetime   = datetime.fromtimestamp(int(time.time()))
formatted_datetime = current_datetime.strftime("%H-%M_%d-%m-%Y")

optimization_parameters = {'optimization_mode'          : OptimizationMode.BOM_DEFAULT,   # THIS IS THE MASTER SWITCH,
                           'training_data_info'         : {'fidelity': TrainingDataInfo.FIDELITY_LOW,
                                                           'size'    : TrainingDataInfo.SIZE_10},
                           'training_data_directory'    : os.path.abspath('/Users/runyu/Documents/Notebook_DKL/s4_110k_8ID_March_24.json'),
                           'custom_gp_model'            : SimpleCustomGP,
                           'pre_trained_gp_model'       : None,
                           'custom_acquisition_function': None,
                           'trained_gp_model'           : None,
                           'sobol_trials'               : 10,
                           'bo_trials'                  : 10,
                           'json_results_directory'     : 'DEFAULT',
                           'warm_start'                 : False,
                           'save_results_to_json'       : True,
                           'json_file_name'             : f'DEFAULT_30_MOO_5_{formatted_datetime}'}

bom_default_class = AxNNOptimizer(input_parameters = optimization_parameters)
# ax_nn_optimizer.ax_client_bom_optimize()
bom_default_class.optimize()
bom_default_class.plot_results()