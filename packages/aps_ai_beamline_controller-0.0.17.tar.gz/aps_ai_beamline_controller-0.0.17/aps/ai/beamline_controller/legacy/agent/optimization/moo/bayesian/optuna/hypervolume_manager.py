#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import abc

import numpy as np
from optuna.trial import Trial, FrozenTrial, TrialState
from optuna.study import Study
from typing import List

from aps.beamline_driver.beam_management.facade import BeamProperties
from aps.ai.beamline_controller.legacy.agent.optimization.facade import OptimizationCriteria, OptimizationDirection, OptimizationInitParameters
from aps.ai.beamline_controller.legacy.agent.facade import ERROR_LOSS
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.facade import MOBOBayesianOptimizationInputParameters, MOBOBayesianOptimizationResult, MOBOBayesianOptimizationResultItem, MOBOOptimizationTrialStatus, Sampling
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.abstract_hypervolume_manager import MOBOAbstractBayesianHypervolumeManager, TrialNumbersFilter

from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.optuna.botorch.botorch_acquisition_functions import \
    qei_candidates_func, \
    qnei_candidates_func, \
    qehvi_candidates_func, \
    qnehvi_candidates_func, \
    qparego_candidates_func, \
    qnparego_candidates_func

class IOptunaHypervolumeManager():
    @abc.abstractmethod
    def set_trial_constraints(self, optimization_criterion_constraints : dict, beam_properties : BeamProperties, trial : Trial): raise NotImplementedError

class AbstractOptunaHypervolumeManager(MOBOAbstractBayesianHypervolumeManager, IOptunaHypervolumeManager):
    def __init__(self,
                 hypervolume_reference_points: dict,
                 optimization_criteria_constraints: dict = {},
                 optimization_criteria_reference_values: dict = {},
                 optimization_criteria_weights: dict = {}):
        MOBOAbstractBayesianHypervolumeManager.__init__(self,
                                                    hypervolume_reference_points,
                                                    optimization_criteria_constraints,
                                                    optimization_criteria_reference_values,
                                                    optimization_criteria_weights)
    def _get_managed_acquisition_functions(self) -> dict:
        return {"qEI":       qei_candidates_func,
                "qNEI":      qnei_candidates_func,
                "qEHVI":     qehvi_candidates_func,
                "qNEHVI":    qnehvi_candidates_func,
                "qPAREGO":   qparego_candidates_func,
                "Automatic": qnparego_candidates_func}

    def _get_hypervolume_reference_point(self, optimization_criterion : str, optimization_direction=OptimizationDirection.MINIMIZE) -> float:
        value = np.abs(self._hypervolume_reference_points.get(optimization_criterion, 0.0))
        value = -1*value if optimization_direction == OptimizationDirection.MINIMIZE else value

        return value

    '''
    from IHypervolumeManager interface
    '''
    def get_optimizer_initialization(self,
                                     optimization_criteria: OptimizationCriteria,
                                     input_parameters : MOBOBayesianOptimizationInputParameters,
                                     **kwargs) -> OptimizationInitParameters:
        optimizer_initialization    = super(AbstractOptunaHypervolumeManager, self).get_optimizer_initialization(optimization_criteria, input_parameters, **kwargs)
        optuna_acquisition_function = optimizer_initialization.get_parameter("acquisition_function")

        def acquisition_function_internal(*args, **kwargs):
            return optuna_acquisition_function(*args,
                                               reference_points=list(self._hypervolume_reference_points.values()),
                                               **kwargs)

        def constraints_function(trial : Trial):
            values = []
            for optimization_criterion in self._optimization_criteria_constraints.keys():
                values.append(trial.user_attrs[f"{optimization_criterion}_constraint"])

            return values

        optimizer_initialization.set_parameter("acquisition_function", acquisition_function_internal)
        optimizer_initialization.set_parameter("constraints_function", constraints_function)

        return optimizer_initialization


    def _initialize_loss_container(self) -> list:
        return []

    def _add_to_loss_container(self, optimization_criterion : str, loss_container : list, current_loss : float):
        loss_container.append(current_loss)

    '''
    from IOptunaHypervolumeManager interface
    '''

    def set_trial_constraints(self, optimization_criteria_constraints : dict, beam_properties : BeamProperties, trial : Trial):
        for optimization_criterion, threshold in optimization_criteria_constraints.items():
            trial.set_user_attr(f"{optimization_criterion}_constraint", self._get_constraint_value(beam_properties, optimization_criterion, threshold))

    def _get_constraint_value(self, beam_properties: BeamProperties, optimization_criterion: str, threshold: float = None):
        value = self._get_optimization_criterion_value(beam_properties, optimization_criterion)

        if self._optimization_directions[optimization_criterion] == OptimizationDirection.MINIMIZE: value = -2 * (value < threshold) + 1
        else:                                                                                       value = -2 * (value > threshold) + 1

        return value

    '''
    from IBayesianHypervolumeManager interface
    '''
    def get_error_loss_function(self, optimization_criteria) -> list:
        return np.full(optimization_criteria.number, ERROR_LOSS).tolist()

    def get_native_pareto_front(self, optimization_agent : Study, optimization_criteria : OptimizationCriteria) -> List[FrozenTrial]:
        return optimization_agent.best_trials

    def extract_pareto_front_data(self, optimization_agent, optimization_criteria: OptimizationCriteria, trial_numbers: list = None, trial_numbers_filter: int = TrialNumbersFilter.EXCLUDE, native_pareto_front: List[FrozenTrial] = None) -> MOBOBayesianOptimizationResult:
        native_pareto_front = self.get_native_pareto_front(optimization_agent, optimization_criteria) if native_pareto_front is None else native_pareto_front

        return self.__get_optimization_result_from_trials(native_pareto_front, optimization_criteria, trial_numbers, trial_numbers_filter)

    def get_native_optimization_result(self, optimization_agent: Study) -> List[FrozenTrial]:
        return optimization_agent.trials

    def extract_optimization_result_data(self, optimization_agent, optimization_criteria: OptimizationCriteria, trial_numbers: list = None, trial_numbers_filter: int = TrialNumbersFilter.EXCLUDE, native_optimization_result: List[FrozenTrial] = None):
        native_optimization_result = self.get_native_optimization_result(optimization_agent) if native_optimization_result is None else native_optimization_result

        return self.__get_optimization_result_from_trials(native_optimization_result, optimization_criteria, trial_numbers, trial_numbers_filter)

    def __get_optimization_result_from_trials(self, native_trials: List[FrozenTrial], optimization_criteria: OptimizationCriteria, trial_numbers: list = None, trial_numbers_filter: int = TrialNumbersFilter.EXCLUDE) -> MOBOBayesianOptimizationResult:
        native_trial_numbers = [native_trials[index].number for index in range(len(native_trials))]

        if not trial_numbers is None and trial_numbers_filter == TrialNumbersFilter.EXCLUDE:
            trial_numbers = [trial_number for trial_number in native_trial_numbers if trial_number not in trial_numbers]

        def get_status(trial_status: TrialState):
            return MOBOOptimizationTrialStatus.COMPLETED if trial_status == TrialState.COMPLETE else MOBOOptimizationTrialStatus.FAILED

        optimization_result_data = MOBOBayesianOptimizationResult()
        for index in range(len(native_trials)):
            trial = native_trials[index]

            if trial_numbers is None or trial.number in trial_numbers:
                optimization_result_data.add_optimization_item(MOBOBayesianOptimizationResultItem(trial_number=trial.number,
                                                                                              status=get_status(trial.state),
                                                                                              motor_positions=trial.params,
                                                                                              sampling=Sampling.OPTIMIZED, # no sobol for optuna
                                                                                              loss_function={optimization_criterion : value for optimization_criterion, value in zip(optimization_criteria.names, trial.values)}))

        return optimization_result_data

from aps.ai.beamline_controller.legacy.agent.optimization.decorators.direct_beam_image_decorator import DirectBeamImageHyperVolumeManagerDecorator

class OptunaDirectBeamImageHypervolumeManager(DirectBeamImageHyperVolumeManagerDecorator, AbstractOptunaHypervolumeManager):
    def __init__(self,
                 hypervolume_reference_points: dict,
                 optimization_criteria_constraints: dict = {},
                 optimization_criteria_reference_values: dict = {},
                 optimization_criteria_weights: dict = {}):
        DirectBeamImageHyperVolumeManagerDecorator.__init__(self)
        AbstractOptunaHypervolumeManager.__init__(self,
                                                  hypervolume_reference_points,
                                                  optimization_criteria_constraints,
                                                  optimization_criteria_reference_values,
                                                  optimization_criteria_weights)



