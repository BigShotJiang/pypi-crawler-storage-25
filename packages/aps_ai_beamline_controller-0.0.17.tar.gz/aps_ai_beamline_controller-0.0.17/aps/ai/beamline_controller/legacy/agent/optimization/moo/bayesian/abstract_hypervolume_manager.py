#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import abc
from typing import Any
from aps.ai.beamline_controller.legacy.agent.optimization.facade import OptimizationCriteria
from aps.ai.beamline_controller.legacy.agent.optimization.common.bayesian.abstract_hypervolume_manager import AbstractBayesianHypervolumeManager, TrialNumbersFilter
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.facade import SelectionAlgorithm, MOBOBayesianOptimizationResult
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.common import pareto

class IMOBOBayesianHypervolumeManager():
    @abc.abstractmethod
    def get_best_trial_number(self, optimization_agent, optimization_criteria: OptimizationCriteria, algorithm=SelectionAlgorithm.NASH_EQUILIBRIUM, pareto_front_data: MOBOBayesianOptimizationResult = None) -> int: raise NotImplementedError
    @abc.abstractmethod
    def get_native_pareto_front(self, optimization_agent, optimization_criteria : OptimizationCriteria) -> Any: raise NotImplementedError
    @abc.abstractmethod
    def extract_pareto_front_data(self, optimization_agent, optimization_criteria: OptimizationCriteria, trial_numbers: list = None, trial_numbers_filter: int = TrialNumbersFilter.EXCLUDE, native_pareto_front: Any = None) -> MOBOBayesianOptimizationResult: raise NotImplementedError

class MOBOAbstractBayesianHypervolumeManager(AbstractBayesianHypervolumeManager, IMOBOBayesianHypervolumeManager):
    def __init__(self,
                 hypervolume_reference_points : dict,
                 optimization_criteria_constraints : dict = {},
                 optimization_criteria_reference_values : dict = {},
                 optimization_criteria_weights : dict = {}):
        super(MOBOAbstractBayesianHypervolumeManager, self).__init__(hypervolume_reference_points,
                                                                     optimization_criteria_constraints,
                                                                     optimization_criteria_reference_values,
                                                                     optimization_criteria_weights)

    '''
    from IMOBOBayesianHypervolumeManager interface
    '''

    def get_best_trial_number(self, optimization_agent, optimization_criteria: OptimizationCriteria, algorithm=SelectionAlgorithm.NASH_EQUILIBRIUM, pareto_front_data: MOBOBayesianOptimizationResult = None) -> int:
        return pareto.get_best_trial_number(pareto_front_data=self.extract_pareto_front_data(optimization_agent, optimization_criteria) if pareto_front_data is None else pareto_front_data,
                                            optimization_result_data=self.extract_optimization_result_data(optimization_agent, optimization_criteria),
                                            optimization_criteria=optimization_criteria,
                                            optimization_criteria_weights=self._optimization_criteria_weights,
                                            optimization_initialization=self._optimization_initialization,
                                            algorithm=algorithm)