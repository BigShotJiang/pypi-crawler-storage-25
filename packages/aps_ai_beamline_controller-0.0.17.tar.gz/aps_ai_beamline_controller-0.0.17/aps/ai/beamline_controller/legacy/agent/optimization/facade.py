#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import abc
import json, csv
import os.path
from time import time
from typing import Any, List
import itertools
import traceback
import numpy as np
import copy

from aps.common.data_structures import DictionaryWrapper
from aps.common.io.serialization import from_pickle, to_pickle
from aps.beamline_driver.beam_management.facade import BeamProperties, Beam

from aps.ai.beamline_controller.legacy.common.utility import datetime_string
from aps.ai.beamline_controller.legacy.agent.facade import Fidelity, ERROR_LOSS, Format

class OptimizationDirection:
    MINIMIZE = "minimize"
    MAXIMIZE = "maximize"

class WarmStartDataType:
    PARETO_FRONTIERS        = 0
    WHOLE_DATASETS_NO_SOBOL = 1
    WHOLE_DATASETS_NO_MOBO  = 2
    WHOLE_DATASETS_ALL      = 3
    PRETRAINED_MODEL        = 4

class WarmStartStrategy:
    MAXIMUM_EXTENSION = 0
    EXPANDED_MINIMUM  = 1

class OptimizationCriteria():
    def __init__(self, optimization_criteria_list : list):
        self.__optimization_criteria_list = optimization_criteria_list if not optimization_criteria_list is None else []

    @property
    def names(self): return self.__optimization_criteria_list
    @property
    def number(self): return len(self.__optimization_criteria_list)
    @property
    def criteria_pairs(self): return list(itertools.combinations(self.names, 2))

class OptimizationInputParameters(DictionaryWrapper):
    def __init__(self,
                 motors_to_optimize: list = None,
                 beam_manager_type: str = None,
                 platform: str          = None,
                 beam_manager_id: str   = None,
                 random_seed: int = 2124,
                 **kwargs):
        self.__motors_to_optimize      = motors_to_optimize
        self.__beam_manager_type       = beam_manager_type
        self.__platform                = platform
        self.__beam_manager_id         = beam_manager_id
        self.__random_seed             = random_seed
        self.__is_partial_optimization = not motors_to_optimize is None

        super(OptimizationInputParameters, self).__init__(**kwargs)

    @property
    def motors_to_optimize(self) -> list: return self.__motors_to_optimize
    @motors_to_optimize.setter
    def motors_to_optimize(self, value: list): self.__motors_to_optimize = value

    @property
    def beam_manager_type(self) -> str: return self.__beam_manager_type
    @beam_manager_type.setter
    def beam_manager_type(self, value: str): self.__beam_manager_type = value
    @property
    def platform(self) -> str: return self.__platform
    @platform.setter
    def platform(self, value: str): self.__platform = value
    @property
    def beam_manager_id(self) -> str: return self.__beam_manager_id
    @beam_manager_id.setter
    def beam_manager_id(self, value: str): self.__beam_manager_id = value
    @property
    def is_partial_optimization(self) -> bool: return self.__is_partial_optimization
    @property
    def random_seed(self) -> int: return self.__random_seed

class OptimizationExecutionParameters():
    def __init__(self,
                 home_directory: str=os.curdir,
                 do_warm_start=False,
                 warm_start_home_directory: str = os.curdir,
                 warm_start_data_type: int = WarmStartDataType.PARETO_FRONTIERS,
                 warm_start_strategy: int = WarmStartStrategy.MAXIMUM_EXTENSION,
                 warm_start_expansion_factors: list = [0.1, 1.5],
                 use_warm_start_search_space: bool = True,
                 save_warm_start_data: bool = True,
                 use_exit_strategy = False,
                 exit_loss_function = Any):
        self.__home_directory               = os.path.abspath(home_directory)
        self.__do_warm_start                = do_warm_start
        self.__warm_start_home_directory    = os.path.abspath(warm_start_home_directory)
        self.__warm_start_data_type         = warm_start_data_type
        self.__warm_start_strategy          = warm_start_strategy
        self.__warm_start_expansion_factors = warm_start_expansion_factors
        self.__use_warm_start_search_space  = use_warm_start_search_space
        self.__save_warm_start_data         = save_warm_start_data
        self.__use_exit_strategy            = use_exit_strategy
        self.__exit_loss_function           = exit_loss_function
        self.__experiment_output_directory  = os.path.join(home_directory, f"optimization_run_{datetime_string()}")
        self.__ml_data_directory = os.path.join(home_directory, "ml_data")

        if not os.path.exists(self.__experiment_output_directory): os.makedirs(self.__experiment_output_directory)
        if not os.path.exists(self.__ml_data_directory):           os.makedirs(self.__ml_data_directory)


    @property
    def home_directory(self) -> str: return self.__home_directory
    @property
    def experiment_output_directory(self) -> str: return self.__experiment_output_directory
    @property
    def do_warm_start(self) -> bool: return self.__do_warm_start
    @property
    def warm_start_home_directory(self) -> str: return self.__warm_start_home_directory
    @property
    def warm_start_data_type(self) -> int: return self.__warm_start_data_type
    @property
    def warm_start_strategy(self) -> int: return self.__warm_start_strategy
    @property
    def warm_start_expansion_factors(self) -> list: return self.__warm_start_expansion_factors
    @property
    def use_warm_start_search_space(self) -> bool: return self.__use_warm_start_search_space
    @property
    def save_warm_start_data(self) -> bool: return self.__save_warm_start_data
    @property
    def use_exit_strategy(self) -> bool: return self.__use_exit_strategy
    @property
    def exit_loss_function(self) -> dict: return self.__exit_loss_function
    @property
    def ml_data_directory(self) -> str: return self.__ml_data_directory


class OptimizationInitParameters(DictionaryWrapper):
    def __init__(self, **kwargs):
        super(OptimizationInitParameters, self).__init__(**kwargs)

# ------------------------------------------------
# DATA CONTAINER
# ------------------------------------------------

class OptimizationResultItem():
    def __init__(self,
                 trial_number: int = 0,
                 start_time:float = time(),
                 end_time: float  = time(),
                 fidelity: int = Fidelity.LOW,
                 motor_positions: dict = {},  # {motor_id : position}
                 loss_function: dict = {},  # {optimization_criterion : loss }
                 beam: Beam = None,
                 beam_string: str = None):
        self.__trial_number = trial_number
        self.__start_time = start_time
        self.__end_time = end_time
        self.__fidelity = fidelity
        self.__motor_positions = motor_positions
        self.__loss_function = loss_function
        self.__beam_string = beam_string if beam is None else beam.serialize()

    @property
    def trial_number(self) -> int: return self.__trial_number
    @property
    def start_time(self) -> float: return self.__start_time
    @property
    def end_time(self) -> float: return self.__end_time
    @property
    def fidelity(self) -> int: return self.__fidelity
    @property
    def motor_positions(self) -> dict: return self.__motor_positions
    @property
    def loss_function(self) -> dict: return self.__loss_function
    @property
    def beam_hex_string(self) -> str: return self.__beam_string
    @property
    def beam(self) -> Beam: return None if self.__beam_string is None else Beam.deserialize(self.__beam_string)

    @start_time.setter
    def start_time(self, value): self.__start_time = value
    @end_time.setter
    def end_time(self, value): self.__end_time = value
    @fidelity.setter
    def fidelity(self, value): self.__fidelity = value
    @beam.setter
    def beam(self, value): self.__beam_string = None if value is None else value.serialize()
    @beam_hex_string.setter
    def beam_hex_string(self, value): self.__beam_string = value

    @property
    def headers(self) -> list:
        headers = ["trial_number", "start_time", "end_time", "fidelity"]
        headers.extend([f"{key}-(MP)" for key in self.motor_positions.keys()])
        headers.extend([f"{key}-(LF)" for key in self.loss_function.keys()])
        headers.append("beam")

        return headers

    def to_dictionary(self) -> dict:
        dict = {"trial_number" : self.trial_number,
                "start_time" : self.start_time,
                "end_time" : self.end_time,
                "fidelity": self.fidelity}
        dict.update({f"{key}-(MP)": self.motor_positions[key] for key in self.motor_positions.keys()})
        dict.update({f"{key}-(LF)": (self.loss_function[key] if not self.loss_function[key] is None else ERROR_LOSS) for key in self.loss_function.keys()})
        dict["beam"] = self.__beam_string # hex string

        return dict

    @classmethod
    def from_dictionary(cls, dictionary: dict):
        return OptimizationResultItem(trial_number=int(dictionary["trial_number"]),
                                      start_time=float(dictionary.get("start_time", 0.0)),
                                      end_time=float(dictionary.get("end_time", 0.0)),
                                      fidelity=int(dictionary.get("fidelity"), Fidelity.LOW),
                                      motor_positions={key[:-5]: float(dictionary[key]) for key in dictionary.keys() if key.endswith("-(MP)")},
                                      loss_function={key[:-5]: float(dictionary[key]) for key in dictionary.keys() if key.endswith("-(LF)")},
                                      beam_string=dictionary["beam"])

class OptimizationResult():
    def __init__(self, optimization_items: List[OptimizationResultItem]=None):
        self.__optimization_items = {optimization_item.trial_number : optimization_item for optimization_item in optimization_items} if not optimization_items is None else {}
        self.__warm_start_search_ranges = None

    def add_optimization_item(self, optimization_item: OptimizationResultItem):
        if optimization_item.trial_number in self.__optimization_items.keys(): raise ValueError(f"Optimization result already contains the trial #{optimization_item.trial_number}")

        self.__optimization_items[optimization_item.trial_number] = optimization_item

    def add_optimization_items(self, optimization_items: List[OptimizationResultItem]):
        if not optimization_items is None:
            original_items = copy.deepcopy(self.__optimization_items)
            try:
                for optimization_item in optimization_items: self.add_optimization_item(optimization_item)
            except Exception as e:
                self.__optimization_items = original_items
                raise ValueError("The original content has been restored because of the following exception: " + e.__class__.__qualname__ + ": " + str(e))

    def get_optimization_item(self, trial_number : int) -> OptimizationResultItem:
        return self.__optimization_items.get(trial_number, None)

    def get_optimization_items(self, trial_numbers: list = None) -> List[OptimizationResultItem]:
        if trial_numbers is None: return list(self.__optimization_items.values())
        else:                     return [item for item in self.__optimization_items.values() if item.trial_number in trial_numbers]

    def get_trial_numbers(self) -> List[int]:
        return list(self.__optimization_items.keys())

    def get_start_times(self, trial_numbers: list = None) -> dict:
        return {item.trial_number : item.start_time for item in self.get_optimization_items(trial_numbers)}

    def get_end_times(self, trial_numbers: list = None) -> dict:
        return {item.trial_number : item.end_time for item in self.get_optimization_items(trial_numbers)}

    def set_timestamps(self, timestamps: dict):
        for trial_number in timestamps.keys():
            item = self.get_optimization_item(trial_number)
            if not item is None:
                timestamp = timestamps[trial_number]
                item.start_time = timestamp[0]
                item.end_time   = timestamp[1]

    def get_fidelities(self, trial_numbers: list = None) -> dict:
        return {item.trial_number : item.fidelity for item in self.get_optimization_items(trial_numbers)}

    def set_fidelity(self, fidelity: int = Fidelity.LOW, trial_numbers: list = None):
        for item in self.get_optimization_items(trial_numbers): item.fidelity = fidelity

    def get_optimization_duration(self,trial_numbers: list = None) -> float:
        try:
            trial_numbers = self.get_trial_numbers() if trial_numbers is None else trial_numbers

            return self.get_optimization_item(trial_numbers[-1]).end_time - \
                   self.get_optimization_item(trial_numbers[0]).start_time
        except:
            return 0.0

    def get_motor_positions(self, trial_numbers: list = None) -> dict:
        return {item.trial_number : item.motor_positions for item in self.get_optimization_items(trial_numbers)}

    def get_loss_functions(self, trial_numbers: list = None) -> dict:
        return {item.trial_number : item.loss_function for item in self.get_optimization_items(trial_numbers)}

    def get_beams(self, trial_numbers: list = None) -> dict:
        return {item.trial_number : item.beam for item in self.get_optimization_items(trial_numbers)}

    def set_beams(self, beam_data: dict):
        for trial_number in beam_data.keys():
            item = self.get_optimization_item(trial_number)
            if not item is None: item.beam = beam_data[trial_number]

    def get_beam_hex_strings(self, trial_numbers: list = None) -> dict:
        return {item.trial_number : item.beam_hex_string for item in self.get_optimization_items(trial_numbers)}

    def set_beam_hex_strings(self, beam_string_data: dict):
        for trial_number in beam_string_data.keys():
            item = self.get_optimization_item(trial_number)
            if not item is None: item.beam_hex_string = beam_string_data[trial_number]

    def get_number_of_items(self) -> int:
        return len(self.__optimization_items)

    def is_empty(self):
        return self.get_number_of_items() == 0

    def get_subset(self, filters: dict = {"fidelity" : (Fidelity.HIGH, "i")}) -> List[OptimizationResultItem]:
        trial_numbers = self.get_trial_numbers()

        if not filters is None:
            for filter_attribute in filters.keys():
                filter_value, flag = filters[filter_attribute]
                if flag == "i":
                    if type(filter_value) == list: trial_numbers = np.array(trial_numbers)[np.where(np.array([getattr(item, filter_attribute) for item in self.get_optimization_items(trial_numbers)]) in filter_value)]
                    else:                          trial_numbers = np.array(trial_numbers)[np.where(np.array([getattr(item, filter_attribute) for item in self.get_optimization_items(trial_numbers)]) == filter_value)]
                elif flag == "e":
                    if type(filter_value) == list: trial_numbers = np.array(trial_numbers)[np.where(np.array([getattr(item, filter_attribute) for item in self.get_optimization_items(trial_numbers)]) not in filter_value)]
                    else:                          trial_numbers = np.array(trial_numbers)[np.where(np.array([getattr(item, filter_attribute) for item in self.get_optimization_items(trial_numbers)]) != filter_value)]

        return self.get_optimization_items(trial_numbers)

    @property
    def headers(self) -> list :
        if not self.is_empty(): return self.get_optimization_items()[0].headers
        else: return None

    def to_dictionary_list(self, trial_numbers: list = None):
        if not self.is_empty(): return [item.to_dictionary() for item in self.get_optimization_items(trial_numbers)]
        else: return None

    def to_pickle(self, file_name):
        to_pickle(self, file_name)

    @classmethod
    def from_pickle(cls, file_name):
        return from_pickle(file_name, obj_class=cls)

    def to_csv(self, file_name):
        if self.is_empty(): raise ValueError("There are no data to save")

        try:
            with open(file_name, 'w') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=self.headers)
                writer.writeheader()
                writer.writerows(self.to_dictionary_list())
        except Exception as e:
            traceback.print_exc()
            print(f'Error while saving csv file: {e}')
        else:
            print(f'Successfully saved CSV file to {file_name}')

    @classmethod
    def from_csv(cls, file_name, item_class=OptimizationResultItem):
        optimization_result = OptimizationResult()
        try:
            with open(file_name, 'r') as csvfile:
                reader = csv.DictReader(csvfile)
                for row in reader: optimization_result.add_optimization_item(item_class.from_dictionary(row))
        except Exception as e:
            traceback.print_exc()
            print(f'Error while reading csv file: {e}')
        else:
            return optimization_result

    def to_json(self, file_name):
        if self.is_empty(): raise ValueError("There are no data to save")

        try:
            with open(file_name, 'w') as jsonfile: json.dump(self.to_dictionary_list(), jsonfile)
        except Exception as e:
            traceback.print_exc()
            print(f'Error while saving json file: {e}')
        else:
            print(f'Successfully saved json file to {file_name}')

    @classmethod
    def from_json(cls, file_name, item_class=OptimizationResultItem):
        optimization_result = OptimizationResult()
        try:
            with open(file_name, 'r') as jsonfile:
                data = json.load(jsonfile)
                for item in data: optimization_result.add_optimization_item(item_class.from_dictionary(item))
        except Exception as e:
            traceback.print_exc()
            print(f'Error while reading csv file: {e}')
        else:
            return optimization_result

    def get_warm_start_subset(self, **kwargs):
        return self.get_subset(self._get_warm_start_filters(**kwargs))

    def initialize_warm_start_data(self, current_search_range: dict, strategy: int = WarmStartStrategy.MAXIMUM_EXTENSION, expansion_factors=[0.1, 1.5], coefficient=0.01, **kwargs):
        self.__warm_start_search_ranges = copy.deepcopy(current_search_range)

        if self.is_empty(): raise ValueError("Warm start data can be initialized from an empty result")

        item = self.get_optimization_item(self.get_trial_numbers()[0])

        optimization_criteria = item.loss_function.keys()
        motors_to_optimize    = item.motor_positions.keys()

        warm_start_motor_positions = {motor_id: [] for motor_id in motors_to_optimize}

        if strategy == WarmStartStrategy.MAXIMUM_EXTENSION:
            warm_start_loss_functions = {optimization_criterion: [] for optimization_criterion in optimization_criteria}

            for optimization_item in self.get_optimization_items():
                for motor_id in motors_to_optimize:                  warm_start_motor_positions[motor_id].append(optimization_item.motor_positions[motor_id])
                for optimization_criterion in optimization_criteria: warm_start_loss_functions[optimization_criterion].append(optimization_item.loss_function[optimization_criterion])

            warm_start_loss_function_info = {}
            for optimization_criterion in optimization_criteria:
                loss = max(warm_start_loss_functions[optimization_criterion])
                warm_start_loss_function_info[optimization_criterion] = loss * ((1.0 + expansion_factors[0]) if loss > 0 else (1 - expansion_factors[0]))

            for motor_id in motors_to_optimize:
                warm_start_motor_position_range = [min(warm_start_motor_positions[motor_id]), max(warm_start_motor_positions[motor_id])]
                warm_start_search_space_range = self.__warm_start_search_ranges[motor_id]

                if warm_start_motor_position_range[0] > warm_start_search_space_range[0]: warm_start_search_space_range[0] = warm_start_motor_position_range[0]
                if warm_start_motor_position_range[1] < warm_start_search_space_range[1]: warm_start_search_space_range[1] = warm_start_motor_position_range[1]

                self.__warm_start_search_ranges[motor_id] = warm_start_search_space_range  # this should be redundant
        elif strategy == WarmStartStrategy.EXPANDED_MINIMUM:
            minimum_loss = np.inf
            warm_start_search_space_ranges = {motor_id : [] for motor_id in motors_to_optimize}
            motor_extensions               = {motor_id : (current_search_range[motor_id][1] - current_search_range[motor_id][0]) for motor_id in motors_to_optimize}
            warm_start_loss_function_info  = {optimization_criterion: minimum_loss for optimization_criterion in optimization_criteria}

            for optimization_item in self.get_optimization_items():
                total_loss = sum([optimization_item.loss_function[optimization_criterion] for optimization_criterion in optimization_criteria])

                if total_loss < minimum_loss:
                    minimum_loss = total_loss

                    for optimization_criterion in optimization_criteria:
                        warm_start_loss_function_info[optimization_criterion] = optimization_item.loss_function[optimization_criterion]

                    for motor_id in motors_to_optimize:
                        motor_position  = optimization_item.motor_positions[motor_id]
                        motor_extension = expansion_factors[0]*motor_extensions[motor_id]
                        warm_start_search_space_ranges[motor_id] = [round(motor_position - motor_extension, 8),
                                                                    round(motor_position + motor_extension, 8)]

            for optimization_criterion in optimization_criteria:
                loss = warm_start_loss_function_info[optimization_criterion]
                warm_start_loss_function_info[optimization_criterion] = (loss * expansion_factors[1]) if loss > 0 else (loss /expansion_factors[1])

            self.__warm_start_search_ranges = warm_start_search_space_ranges
        else:
            raise ValueError(f"Warm Start strategy {strategy} not recognized")

        # Inspection of the search space and correction of anomalies
        for motor_id in motors_to_optimize:
            ws_search_range   = self.__warm_start_search_ranges[motor_id]
            curr_search_range = copy.deepcopy(current_search_range[motor_id])

            # restore defaults in case of problems
            if len(ws_search_range) == 0 or (ws_search_range[0] == ws_search_range[1]):
                self.__warm_start_search_ranges[motor_id] = curr_search_range
                print("Warning: warm start search space has been reset for motor " + motor_id)
            else:
                # restore previous search space in case the new one expands it
                if ws_search_range[0] < curr_search_range[0]: ws_search_range[0] = curr_search_range[0]
                if ws_search_range[1] > curr_search_range[1]: ws_search_range[1] = curr_search_range[1]
                # redundant...
                self.__warm_start_search_ranges[motor_id] = ws_search_range

        return warm_start_loss_function_info

    def _get_warm_start_filters(self, **kwargs): return None

    def get_warm_start_search_ranges(self) -> dict: return self.__warm_start_search_ranges

    def get_warm_start_search_spaces(self, motion_manager) -> dict:
        motors_info = motion_manager.get_motors_info()

        return {motor_id: [round(item, motors_info.get_motor_info(motor_id).digits) for item in \
                           np.arange(start=float(self.__warm_start_search_ranges[motor_id][0]),
                                     stop=float(self.__warm_start_search_ranges[motor_id][1]),
                                     step=motors_info.get_motor_info(motor_id).resolution)] for motor_id in self.__warm_start_search_ranges.keys()}


# ************************************************************
# Note: The concept of "Hypervolume" belongs to Bayesian optimization, but
# it is not improper to extend it to all the optimizations.
# We consider a HyperVolumeManager any entity that can initialize the optimizer and
# provide the loss of each optimization iteration.
# ************************************************************

from matplotlib.figure import Figure

class IOptimizer():
    @abc.abstractmethod
    def requires_run_engine(self, *args, **kwargs): raise NotImplementedError
    @abc.abstractmethod
    def initialize_driver(self, *args, **kwargs): raise NotImplementedError
    @abc.abstractmethod
    def initialize_optimization(self, *args, **kwargs): raise NotImplementedError
    @abc.abstractmethod
    def optimize(self, *args, **kwargs): raise NotImplementedError

    # ---------------------------------------------------------------------
    # POST-PROCESSING
    # ---------------------------------------------------------------------

    @abc.abstractmethod
    def get_optimization_result_data(self, **kwargs) -> OptimizationResult: raise NotImplementedError
    @abc.abstractmethod
    def get_trial_data(self, trial_index: int, **kwargs) -> (OptimizationResultItem, BeamProperties): raise NotImplementedError
    @abc.abstractmethod
    def get_best_trial_data(self, *args, **kwargs) -> (OptimizationResultItem, BeamProperties): return NotImplementedError
    @abc.abstractmethod
    def move_motors_to_trial_data(self, trial_data : OptimizationResultItem, **kwargs): return NotImplementedError

    # ------------------------------------------------------------------------------
    #  SAVE TO FILE AND PLOTS
    # ------------------------------------------------------------------------------
    @abc.abstractmethod
    def save_optimization_result(self, format=Format.CSV, **kwargs): raise NotImplementedError
    @abc.abstractmethod
    def plot_optimization_history(self, optimization_criteria: OptimizationCriteria = None, plot_images: bool=True, save_images: bool=False, **kwargs) -> Figure: raise NotImplementedError
    @abc.abstractmethod
    def plot_optimization_history_correlations(self, optimization_criteria: OptimizationCriteria = None,  plot_images: bool=True,  save_images: bool=False, **kwargs) -> List[Figure]: raise NotImplementedError


class IHypervolumeManager():
    @abc.abstractmethod
    def get_optimization_parameters(self,
                                    optimization_criteria : OptimizationCriteria,
                                    input_parameters : OptimizationInputParameters,
                                    **kwargs) -> OptimizationInitParameters: raise NotImplementedError

    @abc.abstractmethod
    def evaluate_loss_function(self,
                               beam_properties : BeamProperties,
                               optimization_criteria : OptimizationCriteria,
                               **kwargs) -> (Any, int, str): raise NotImplementedError

