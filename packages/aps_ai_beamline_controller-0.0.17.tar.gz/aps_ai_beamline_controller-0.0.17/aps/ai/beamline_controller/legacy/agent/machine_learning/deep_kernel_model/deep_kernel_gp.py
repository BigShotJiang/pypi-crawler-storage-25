#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
from typing import Type

import torch
from torch import Tensor, Size
from torch.nn import  Module

from botorch.models.gpytorch import GPyTorchModel

from gpytorch.models import ExactGP
from gpytorch.distributions.multivariate_normal import MultivariateNormal
from gpytorch.utils.grid import ScaleToBounds
from gpytorch.kernels import GridInterpolationKernel, ScaleKernel, RBFKernel
from gpytorch.means import ConstantMean
from gpytorch.likelihoods import Likelihood, GaussianLikelihood
from gpytorch.mlls.exact_marginal_log_likelihood import ExactMarginalLogLikelihood

from aps.ai.beamline_controller.legacy.agent.machine_learning import GPU_DEVICE
from aps.ai.beamline_controller.legacy.agent.machine_learning.neural_networks.tandem_neural_network import LinearNN

class LinearNNFeatureExtractor(LinearNN):
    def __init__(self,
                 input_dim=8,
                 output_dim=5,
                 neurons_per_layer=[1000, 500, 50]):
        super(LinearNNFeatureExtractor, self).__init__(input_dim, output_dim, neurons_per_layer)

class DeepKernelExactGP(ExactGP, GPyTorchModel):
    _num_outputs = 1  # to inform GPyTorchModel API

    def __init__(self,
                 train_X: Tensor,
                 train_Y: Tensor,
                 likelihood_class: Type[Likelihood] = None,
                 likelihood_options: dict = None,
                 feature_extractor_class: Type[Module] = None,
                 feature_extractor_options: dict = {},
                 output_dimension: int = -1,
                 grid_size: int = 100):
        if GPU_DEVICE is not None:
            train_X = train_X.to(GPU_DEVICE).float()
            train_Y = train_Y.to(GPU_DEVICE).float()

            self._device = GPU_DEVICE
        else:
            self._device = torch.device('cpu')

        super().__init__(train_X, train_Y.squeeze(-1), likelihood_class(**likelihood_options) if not likelihood_class is None else GaussianLikelihood())

        self.mean_module  = ConstantMean().to(self._device).float()
        self.covar_module = GridInterpolationKernel(base_kernel = ScaleKernel(base_kernel=RBFKernel(ard_num_dims=output_dimension)),
                                                    num_dims    = output_dimension,
                                                    grid_size   = grid_size).to(self._device).float()
        self.feature_extractor = feature_extractor_class(**feature_extractor_options).to(self._device)
        self.train_feature_extractor()
        
        self.scale_to_bounds   = ScaleToBounds(-1., 1.)

    def forward(self, x):
        x           = x.to(self._device).float()
        projected_x = self.feature_extractor(x).to(self._device)
        projected_x = self.scale_to_bounds(projected_x)

        mean_x      = self.mean_module(projected_x)
        covar_x     = self.covar_module(projected_x)

        return MultivariateNormal(mean=mean_x, covariance_matrix=covar_x)

    @property
    def device(self) -> torch.device:
        return self._device

    def train_feature_extractor(self, iterations=100, lr=0.01):
        self.feature_extractor.train()

        optimizer = torch.optim.Adam(self.parameters(), lr=lr)
        mll       = ExactMarginalLogLikelihood(self.likelihood, self)

        for i in range(iterations):
            optimizer.zero_grad()
            output = self(self.train_inputs)
            loss = -mll(output, self.train_targets.squeeze())
            loss.backward()
            optimizer.step()

        print(f"Training completed with Loss = {loss.item()}")

        # Set the model into evaluation mode.
        self.feature_extractor.eval()
