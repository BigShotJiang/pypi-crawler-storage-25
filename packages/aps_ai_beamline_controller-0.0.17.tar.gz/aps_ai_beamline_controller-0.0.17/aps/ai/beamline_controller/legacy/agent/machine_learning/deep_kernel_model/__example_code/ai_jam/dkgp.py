#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #

import numpy as np
import torch
import torch.nn as nn

from ax import Models
from ax.service.ax_client import AxClient
from ax.modelbridge.generation_strategy import GenerationStrategy, GenerationStep


# -------------------------------------------------------------------
# 1. Define the Multi-Objective Evaluation Function
# -------------------------------------------------------------------
def multi_objective_evaluation(parameters):
    # Get parameters (assumed to lie in [0,1])
    x1 = parameters["x1"]
    x2 = parameters["x2"]
    # Branin function (scaled: x1 in [0,1] -> [-5,10], x2 in [0,1] -> [0,15])
    x1_scaled = 15 * x1 - 5
    x2_scaled = 15 * x2
    a = 1.0
    b = 5.1 / (4 * np.pi ** 2)
    c = 5 / np.pi
    r = 6.0
    s = 10.0
    t = 1 / (8 * np.pi)
    branin_val = a * (x2_scaled - b * x1_scaled ** 2 + c * x1_scaled - r) ** 2 + s * (1 - t) * np.cos(x1_scaled) + s
    # Squared Euclidean distance from the center (0.5, 0.5)
    distance_val = (x1 - 0.5) ** 2 + (x2 - 0.5) ** 2
    return {"branin": (branin_val, 0.0), "distance": (distance_val, 0.0)}


# -------------------------------------------------------------------
# 2. Define a Custom Deep Kernel GP Model Builder for Multi-Objective Optimization
# -------------------------------------------------------------------
def custom_dkgp_model(experiment, data, **kwargs):
    """
    This custom model builder takes Ax Data and returns a ModelListGP
    built from two SingleTaskDeepKernelGP models (one per objective),
    each using a simple neural network feature extractor.
    """
    import torch
    from botorch.models import SingleTaskDeepKernelGP
    from botorch.models.model_list_gp_regression import ModelListGP
    from gpytorch.mlls import ExactMarginalLogLikelihood
    from botorch.fit import fit_gpytorch_mll

    # Extract data from the Ax DataFrame
    df = data.df
    X_list, Y_list = [], []
    for _, row in df.iterrows():
        X_list.append([row["x1"], row["x2"]])
        # Order of objectives is assumed to be ["branin", "distance"]
        Y_list.append([row["branin"], row["distance"]])
    X = torch.tensor(X_list, dtype=torch.float32)
    Y = torch.tensor(Y_list, dtype=torch.float32)

    # Define a simple neural network feature extractor
    class FeatureExtractor(nn.Module):
        def __init__(self, input_dim, output_dim=4):
            super().__init__()
            self.net = nn.Sequential(
                nn.Linear(input_dim, 16),
                nn.ReLU(),
                nn.Linear(16, output_dim)
            )

        def forward(self, x):
            return self.net(x)

    feat1 = FeatureExtractor(input_dim=2, output_dim=4)
    feat2 = FeatureExtractor(input_dim=2, output_dim=4)

    model1 = SingleTaskDeepKernelGP(X, Y[:, 0:1], feature_extractor=feat1)
    model2 = SingleTaskDeepKernelGP(X, Y[:, 1:2], feature_extractor=feat2)

    # Fit each model (using their marginal log likelihood)
    mll1 = ExactMarginalLogLikelihood(model1.likelihood, model1)
    fit_gpytorch_mll(mll1)
    mll2 = ExactMarginalLogLikelihood(model2.likelihood, model2)
    fit_gpytorch_mll(mll2)

    model_list = ModelListGP(model1, model2)

    return model_list


# -------------------------------------------------------------------
# 3. Set Up the Ax Experiment Using AxClient and a Generation Strategy
# -------------------------------------------------------------------
ax_client = AxClient(enforce_sequential_optimization=False)
ax_client.create_experiment(
    name="branin_multiobj_dkgp",
    parameters=[
        {"name": "x1", "type": "range", "bounds": [0.0, 1.0]},
        {"name": "x2", "type": "range", "bounds": [0.0, 1.0]},
    ],
    objective_name=["branin", "distance"],
    minimize=True,  # Both objectives are to be minimized
    evaluation_function=multi_objective_evaluation,
)

# Define a generation strategy with two steps:
# Step 1: 5 Sobol trials.
# Step 2: BOTORCH_MODULAR using our custom DKGP model and qNEHVI acquisition.
gs = GenerationStrategy(steps=[
    GenerationStep(
        model=Models.SOBOL,
        num_trials=5,
        min_trials_observed=5,
        max_trials=5,
    ),
    GenerationStep(
        model=Models.BOTORCH_MODULAR,
        num_trials=-1,
        min_trials_observed=5,
        max_parallelism=1,
        model_kwargs={},  # No additional kwargs here.
        model_gen_options={
            "custom_model": custom_dkgp_model,
            "acquisition_function": "qNEHVI",
            # Objective thresholds should be dominated by all observed outcomes.
            # These thresholds define the hypervolume reference point.
            "objective_thresholds": [6.0, 0.5],
        },
    ),
])
ax_client.set_generation_strategy(gs)

# -------------------------------------------------------------------
# 4. Run a Number of Optimization Trials
# -------------------------------------------------------------------
# Here we run 10 additional trials after the initial Sobol steps.
for _ in range(10):
    parameters, trial_index = ax_client.get_next_trial()
    print(f"Trial {trial_index} parameters: {parameters}")
    ax_client.complete_trial(trial_index=trial_index, raw_data=multi_objective_evaluation(parameters))

# -------------------------------------------------------------------
# 5. Retrieve and Display the Best (Pareto Optimal) Points
# -------------------------------------------------------------------
best_points = ax_client.get_best_parameters(objective_weight=None, objective_thresholds=[6.0, 0.5])
print("Best (Pareto optimal) points:", best_points)

# Print the full experiment data as a DataFrame.
print(ax_client.experiment.fetch_data().df)
