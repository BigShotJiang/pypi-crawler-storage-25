#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import os
from random import random
from typing import Any, Dict, List, Optional, Type
import pandas as pd

from torch import Tensor
from torch.nn import  Module

from gpytorch.likelihoods import Likelihood
from gpytorch.mlls import MarginalLogLikelihood
from gpytorch.mlls.exact_marginal_log_likelihood import ExactMarginalLogLikelihood

from aps.common.io.serialization import from_pickle

from aps.ai.beamline_controller.legacy.agent.machine_learning.surrogates.ax.ax_custom_surrogate import AxCustomSurrogate
from aps.ai.beamline_controller.legacy.agent.machine_learning.deep_kernel_model.deep_kernel_gp import DeepKernelExactGP
from aps.ai.beamline_controller.legacy.agent.optimization.facade import OptimizationResult
from aps.ai.beamline_controller.legacy.agent.optimization.common.bayesian.facade import BayesianOptimizationResultItem

class DeepKernelSurrogate(AxCustomSurrogate):
    def __init__(self,
                 motors_to_optimize: list,
                 optimization_criteria: list,
                 exclusion_ranges: dict = {},
                 input_data_directory: str = os.curdir,
                 number_of_datasets = -1,
                 excluded_sampling = None,
                 likelihood_class: Type[Likelihood] = None,
                 likelihood_options: dict = None,
                 feature_extractor_class: Type[Module] = None,
                 feature_extractor_options: dict = {},
                 output_dimension = 5,
                 grid_size = 100,
                 mll_class: Type[MarginalLogLikelihood] = ExactMarginalLogLikelihood,
                 mll_options: Optional[Dict[str, Any]] = None):
        motors_positions, loss_functions = self._load_dkl_training_data(motors_to_optimize,
                                                                        optimization_criteria,
                                                                        exclusion_ranges,
                                                                        input_data_directory,
                                                                        number_of_datasets,
                                                                        excluded_sampling)
        model_options = {"train_X": motors_positions,
                         "train_Y": loss_functions,
                         "likelihood_class" : likelihood_class,
                         "likelihood_options": likelihood_options,
                         "feature_extractor_class": feature_extractor_class,
                         "feature_extractor_class_options": feature_extractor_options,
                         "output_dimension": output_dimension,
                         "grid_size": grid_size}

        super(DeepKernelSurrogate, self).__init__(
            botorch_model_class=DeepKernelExactGP,
            model_options=model_options,
            mll_class=mll_class,
            mll_options=mll_options,
            allow_batched_models=True)

    def _load_dkl_training_data(self,
                                motors_to_optimize,
                                optimization_criteria,
                                exclusion_ranges,
                                input_data_directory,
                                number_of_datasets,
                                excluded_sampling
                                ):
        optimization_result_files  = [os.path.join(input_data_directory, f) for f in os.listdir(input_data_directory) if f.endswith('.pkl')]

        if number_of_datasets >= len(optimization_result_files): number_of_datasets = -1

        indexes = range(len(optimization_result_files)) if number_of_datasets == -1 else \
            [random.randint(0, len(optimization_result_files)-1) for _ in range(number_of_datasets)]

        loaded_data_dict_list = []
        n_loaded_datasets = 0
        for index in indexes:
            file_path = optimization_result_files[index]
            optimization_result: OptimizationResult = from_pickle(file_path)
            n_loaded_datasets += 1

            for item in optimization_result.get_optimization_items():
                original_item = item.to_dictionary()

                try: item_dict = {mp: original_item[mp + "-(MP)"] for mp in motors_to_optimize}
                except KeyError as e: raise ValueError(f"The optimization result in {file_path} does not contain the requested motor {e}")

                skip = False
                for optimization_criterion in optimization_criteria:
                    exclusion_range = exclusion_ranges.get(optimization_criterion, None)

                    try: loss_function_value = original_item[optimization_criterion + "-(LF)"]
                    except: raise ValueError(f"The optimization result in {file_path} can't provide the requested optimization criterion {optimization_criterion}")

                    if not exclusion_range is None and \
                            (loss_function_value < exclusion_range[0] or loss_function_value > exclusion_range[1]):

                        if isinstance(item, BayesianOptimizationResultItem): skip = item.sampling == excluded_sampling
                        else:                                                skip = True
                        if skip: break

                    item_dict[optimization_criterion] = loss_function_value

                if not skip: loaded_data_dict_list.append(item_dict)

        data_frame = pd.DataFrame(loaded_data_dict_list)

        tensor_motors_positions = Tensor(data_frame.loc[:, motors_to_optimize].values).float()
        tensor_loss_functions   = Tensor(data_frame.loc[:, optimization_criteria].values).float()

        return tensor_motors_positions, tensor_loss_functions


