#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import traceback
import warnings
from time import time

from ax.service.ax_client import AxClient
from ax.service.utils.instantiation import ObjectiveProperties
from ax.modelbridge.generation_strategy import GenerationStrategy, GenerationStep
from ax.models.random.sobol import SobolGenerator

from ax.modelbridge.factory import get_sobol

from aps.beamline_driver.beam_management.facade import IBeamManager
from aps.beamline_driver.motion_management.facade import IMotionManager
from aps.ai.beamline_controller.legacy.agent.facade import IAgentListener
from aps.ai.beamline_controller.legacy.agent.optimization.facade import OptimizationDirection, OptimizationCriteria, OptimizationInitParameters, WarmStartDataType
from aps.ai.beamline_controller.legacy.agent.optimization.soo.bayesian.facade import SOBOBayesianOptimizationExecutionParameters, SOBOBayesianOptimizationInputParameters
from aps.ai.beamline_controller.legacy.agent.optimization.soo.bayesian.abstract_optimizer import SOBOAbstractBayesianOptimizer

class AxOptimizer(SOBOAbstractBayesianOptimizer):
    def __init__(self, optimization_listener : IAgentListener, **kwargs):
        super(AxOptimizer, self).__init__(optimization_listener, **kwargs)

    def initialize_driver(self,
                          beam_manager : IBeamManager,
                          motion_manager : IMotionManager):
        super(AxOptimizer, self).initialize_driver(beam_manager, motion_manager)

        if self.requires_run_engine(): setattr(self, "_run_optimization", self.__run_optimization_generator)
        else:                          setattr(self, "_run_optimization", self.__run_optimization)

    # ------------------------------------------------------------------------------
    #  AbstractBayesianOptimizer implementation
    # ------------------------------------------------------------------------------

    def _create_optimization_agent(self, **kwargs):
        warnings.filterwarnings('ignore')

        optimization_criteria: OptimizationCriteria                       = self._optimization_criteria
        execution_parameters: SOBOBayesianOptimizationExecutionParameters = self._execution_parameters
        input_parameters: SOBOBayesianOptimizationInputParameters         = self._input_parameters
        optimization_parameters: OptimizationInitParameters               = self._optimization_parameters

        motors_to_optimize        = input_parameters.motors_to_optimize
        use_discrete_search_space = input_parameters.get_parameter("use_discrete_search_space", default=True)

        # ---------------------------------------------------------------
        # parameters list
        #

        if execution_parameters.do_warm_start:
            if execution_parameters.warm_start_data_type == WarmStartDataType.PRETRAINED_MODEL:
                raise NotImplementedError("Pretrained Model are not supported by this optimizer, yet")
            else:
                if execution_parameters.use_warm_start_search_space: # in case of warm start, the beam_manager_id is embedded in the directory
                    search_ranges = self._warm_start_data.get_warm_start_search_ranges()
                    if use_discrete_search_space: search_spaces = self._warm_start_data.get_warm_start_search_spaces(self._motion_manager)
                else:
                    search_ranges = self._motion_manager.get_motors_info().get_search_ranges(motor_ids=motors_to_optimize,
                                                                                                    beam_manager_type=input_parameters.beam_manager_type,
                                                                                                    platform=input_parameters.platform,
                                                                                                    beam_manager_id=input_parameters.beam_manager_id)
                    if use_discrete_search_space: search_spaces = self._motion_manager.get_motors_info().get_search_spaces(motor_ids=motors_to_optimize,
                                                                                                                                  beam_manager_type=input_parameters.beam_manager_type,
                                                                                                                                  platform=input_parameters.platform,
                                                                                                                                  beam_manager_id=input_parameters.beam_manager_id)
        else:
            search_ranges = self._motion_manager.get_motors_info().get_search_ranges(motor_ids=motors_to_optimize,
                                                                                            beam_manager_type=input_parameters.beam_manager_type,
                                                                                            platform=input_parameters.platform,
                                                                                            beam_manager_id=input_parameters.beam_manager_id)
            if use_discrete_search_space: search_spaces = self._motion_manager.get_motors_info().get_search_spaces(motor_ids=motors_to_optimize,
                                                                                                                          beam_manager_type=input_parameters.beam_manager_type,
                                                                                                                          platform=input_parameters.platform,
                                                                                                                          beam_manager_id=input_parameters.beam_manager_id)

        if use_discrete_search_space:
            parameters_list = []
            for motor_id in motors_to_optimize:
                if len(search_spaces[motor_id]) <= 1000:
                    parameters_list.append(dict(name=motor_id,
                                                type="choice",
                                                values=search_spaces[motor_id],
                                                value_type='float',
                                                is_ordered=True))
                else:
                    parameters_list.append(dict(name=motor_id,
                                                type="range",
                                                bounds=search_ranges[motor_id],
                                                value_type='float'))
        else:
            parameters_list = [dict(name=motor_id,
                                    type="range",
                                    bounds=search_ranges[motor_id],
                                    value_type='float') for motor_id in motors_to_optimize]

        # ---------------------------------------------------------------
        # objectives

        hypervolume_reference_points = optimization_parameters.get_parameter("hypervolume_reference_points")
        hypervolume_reference_point  = 0.0

        for optimization_criterion in optimization_criteria.names:
            optimization_direction = optimization_parameters.get_parameter("optimization_directions")[optimization_criterion]

            if optimization_direction != OptimizationDirection.MINIMIZE: raise ValueError("Optimization Criteria in SOBO can only be minimized")

            if execution_parameters.do_warm_start and execution_parameters.use_warm_start_hypervolume_reference_points:
                warm_start_hypervolume_reference_points = self._warm_start_data.get_warm_start_hypervolume_reference_points()
                hypervolume_reference_point  += warm_start_hypervolume_reference_points.get(optimization_criterion,
                                                                                           optimization_parameters.get_parameter("hypervolume_reference_points")[optimization_criterion])
            else:
                hypervolume_reference_point += hypervolume_reference_points[optimization_criterion]

        objective = ObjectiveProperties(minimize=True, threshold=hypervolume_reference_point)


        message = ["**************************************************"]
        if execution_parameters.do_warm_start:
            message.append("Warm Start: True (attached " + str(self._warm_start_data.get_number_of_items()) + " trials)")
        else:
            message.append("Warm Start: False")
        message.append("Search Space:")
        message.extend([" - " + motor_id + ":" + str(search_ranges[motor_id]) for motor_id in motors_to_optimize])
        message.append("Hypervolume reference point: " + str(hypervolume_reference_point))
        message.append("**************************************************")
        self._optimization_listener.feedback(None, None, None, None, None, message=message)

        # ---------------------------------------------------------------
        # Creation of the AxClient

        steps                  = []
        acquisition_function   = optimization_parameters.get_parameter("acquisition_function")
        name                   = 'Ax_SOO_experiment'

        if not execution_parameters.do_batch_optimization:
            sobol_step_args          = {}
            bo_step_args             = {}
            generation_strategy_args = {}
        else:
            max_parallelism = min(1, execution_parameters.batch_size)
            sobol_step_args          = {"max_parallelism" : max_parallelism}
            bo_step_args             = {"max_parallelism" : max_parallelism}
            generation_strategy_args = {"use_batch_trials" : True, "max_parallelism_cap": max_parallelism, "max_parallelism_override" : None}

        if execution_parameters.do_warm_start:
            name += '_warm_start'
        else:
            sobol_trials = max(input_parameters.sobol_trials, optimization_criteria.number*3)
            self._optimization_listener.feedback(None, None, None, None, None, message=[f"Nr of Sobol Trials: {input_parameters.sobol_trials} -> {sobol_trials} (adjusted)"])
            steps.append(GenerationStep(model=get_sobol, num_trials=sobol_trials, **sobol_step_args))

        self._optimization_listener.feedback(None, None, None, None, None, message=[f"Nr of SOBO Trials: {input_parameters.bo_trials}"])
        try:                   self._optimization_listener.feedback(None, None, None, None, None, message=[f"****** Acquisition Function: {acquisition_function.__qualname__} ******"])
        except AttributeError: self._optimization_listener.feedback(None, None, None, None, None, message=[f"****** Acquisition Function: {acquisition_function} ******"])

        steps.append(GenerationStep(model=acquisition_function,
                                    num_trials=input_parameters.bo_trials,
                                    **bo_step_args))

        ax_client = AxClient(generation_strategy=GenerationStrategy(steps=steps, **generation_strategy_args),
                             random_seed=input_parameters.random_seed,
                             verbose_logging=kwargs.get("verbose_logging", False))

        ax_client.create_experiment(name                          = name,
                                    parameters                    = parameters_list,
                                    objectives                    ={"scalar_loss" : objective},
                                    overwrite_existing_experiment = True)

        return ax_client

    # ------------------------------------------------------------------------------

    def __run_optimization(self, **kwargs) -> (int, dict):
        ax_client                 = self._optimization_agent
        execution_parameters      = self._execution_parameters
        input_parameters          = self._input_parameters
        current_timestamps        = {}
        current_raw_data          = {}
        exit_strategy_fulfilled   = False
        current_model_bridge_name = None
        loss_functions = {}

        new_model_index, trials_to_execute = self.__manage_transfer_learning_initialization(execution_parameters, input_parameters)

        for i in range(trials_to_execute):
            if self.interrupt or exit_strategy_fulfilled: break

            suggested_motor_positions, trial_index, current_model_bridge_name = self.__get_suggested_motor_positions(ax_client=ax_client,
                                                                                                                     current_model_bridge_name=current_model_bridge_name,
                                                                                                                     current_timestamps=current_timestamps)
            loss_function, error_message                                      = self.__evaluate_suggested_motor_positions(suggested_motor_positions=suggested_motor_positions,
                                                                                                                          trial_index=trial_index,
                                                                                                                          current_raw_data=current_raw_data)
            loss_functions[trial_index] = loss_function
            exit_strategy_fulfilled, trials_to_execute                        = self.__process_and_complete_trial(ax_client=ax_client,
                                                                                                                  error_message=error_message,
                                                                                                                  execution_parameters=execution_parameters,
                                                                                                                  exit_strategy_fulfilled=exit_strategy_fulfilled,
                                                                                                                  loss_function=loss_function,
                                                                                                                  trial_index=trial_index,
                                                                                                                  trials_to_execute=trials_to_execute)

        self._hypervolume_manager.set_loss_function_from_optimization(loss_functions)

        if execution_parameters.do_warm_start: return trials_to_execute + new_model_index, current_timestamps, current_raw_data
        else:                                  return trials_to_execute,                   current_timestamps, current_raw_data

    def __run_optimization_generator(self, **kwargs) -> (int, dict):
        ax_client               = self._optimization_agent
        execution_parameters    = self._execution_parameters
        input_parameters        = self._input_parameters
        current_timestamps      = {}
        current_raw_data        = {}
        exit_strategy_fulfilled   = False
        current_model_bridge_name = None
        loss_functions = {}

        new_model_index, trials_to_execute = self.__manage_transfer_learning_initialization(execution_parameters, input_parameters)

        for i in range(trials_to_execute):
            if self.interrupt or exit_strategy_fulfilled: break

            suggested_motor_positions, trial_index, current_model_bridge_name = self.__get_suggested_motor_positions(ax_client=ax_client,
                                                                                                                     current_model_bridge_name=current_model_bridge_name,
                                                                                                                     current_timestamps=current_timestamps)
            loss_function, error_message                                      = yield from self.__evaluate_suggested_motor_positions_bluesky(suggested_motor_positions=suggested_motor_positions,
                                                                                                                                             trial_index=trial_index,
                                                                                                                                             current_raw_data=current_raw_data)
            loss_functions[trial_index] = loss_function
            exit_strategy_fulfilled, trials_to_execute                        = self.__process_and_complete_trial(ax_client=ax_client,
                                                                                                                  error_message=error_message,
                                                                                                                  execution_parameters=execution_parameters,
                                                                                                                  exit_strategy_fulfilled=exit_strategy_fulfilled,
                                                                                                                  loss_function=loss_function,
                                                                                                                  trial_index=trial_index,
                                                                                                                  trials_to_execute=trials_to_execute)
        self._hypervolume_manager.set_loss_function_from_optimization(loss_functions)

        if execution_parameters.do_warm_start: return trials_to_execute + new_model_index, current_timestamps, current_raw_data
        else:                                  return trials_to_execute,                   current_timestamps, current_raw_data

    # ------------------------------------------------------------------------------
    #  OBJECTIVE FUNCTION METHODS
    # ------------------------------------------------------------------------------

    def __get_suggested_motor_positions(self, ax_client, current_model_bridge_name, current_timestamps):
        suggested_motor_positions, trial_index = ax_client.get_next_trial()
        current_timestamps[trial_index] = [time(), time()]

        model_bridge = ax_client.generation_strategy.current_step.fitted_model
        model_bridge_name = model_bridge.__class__.__qualname__

        if model_bridge_name != current_model_bridge_name:
            message = []
            message.append(f'**************************************************')
            message.append(f'Now BoTorch model starts at trial {trial_index}')
            message.append(f'BoTorchModel:         {ax_client.generation_strategy.model.model.__class__.__qualname__}')
            message.append(f'BoTorch GP type:      {"None" if isinstance(ax_client.generation_strategy.model.model, SobolGenerator) else ax_client.generation_strategy.model.model.model.__class__.__qualname__}')
            try:    message.append(f'Acquisition function: {"Sobol Random" if isinstance(ax_client.generation_strategy.model.model, SobolGenerator) else ax_client.generation_strategy.current_step.model.__qualname__}')
            except: message.append(f'Acquisition function: {"Sobol Random" if isinstance(ax_client.generation_strategy.model.model, SobolGenerator) else ax_client.generation_strategy.current_step.model}')
            message.append(f'**************************************************')
            self._optimization_listener.feedback(None, None, None, None, None, message=message)

        current_model_bridge_name = model_bridge_name

        return suggested_motor_positions, trial_index, current_model_bridge_name

    def __manage_transfer_learning_initialization(self, execution_parameters, input_parameters):
        if execution_parameters.do_warm_start:
            trials_to_execute = input_parameters.bo_trials
            new_model_index = self._warm_start_data.get_number_of_items() if not execution_parameters.warm_start_data_type == WarmStartDataType.PRETRAINED_MODEL else 0
        else:
            trials_to_execute = input_parameters.bo_trials + input_parameters.sobol_trials
            new_model_index = input_parameters.sobol_trials
        return new_model_index, trials_to_execute

    def __manage_error(self, trial_index, optimization_criteria, motors_to_optimize, suggested_motor_positions, current_motors_positions):
        error_loss = self._hypervolume_manager.get_error_loss_function(optimization_criteria)

        self._optimization_listener.feedback(trial_index=trial_index,
                                             suggested_motor_positions=suggested_motor_positions,
                                             motors_to_optimize=motors_to_optimize,
                                             motor_positions=current_motors_positions,
                                             current_loss=error_loss)
        return error_loss["scalar_loss"]

    def __evaluate_suggested_motor_positions(self, suggested_motor_positions, trial_index, current_raw_data):
        optimization_criteria = self._optimization_criteria
        motors_to_optimize    = self._input_parameters.motors_to_optimize

        current_raw_data[trial_index] = None

        try:
            self._move_motors(suggested_motor_positions)
            current_motors_positions = self._get_current_motors_positions()

            motor_ok, error_message = self._check_motor_positions(suggested_motor_positions, current_motors_positions)

            if not motor_ok: return self.__manage_error(trial_index,
                                                        optimization_criteria,
                                                        motors_to_optimize,
                                                        suggested_motor_positions,
                                                        current_motors_positions), \
                                    error_message
        except Exception as e:
            traceback.print_exc()
            return self.__manage_error(trial_index,
                                       optimization_criteria,
                                       motors_to_optimize,
                                       suggested_motor_positions,
                                       None), \
                   "Unexpected error while setting motors: " + str(e)

        try:
            beam            = self._beam_manager.get_beam()
            beam_properties = self._beam_manager.get_beam_properties(beam)

            current_raw_data[trial_index] = beam

            if beam_properties.get_parameter("is_empty_beam"):
                return  self.__manage_error(trial_index,
                                            optimization_criteria,
                                            motors_to_optimize,
                                            suggested_motor_positions,
                                            current_motors_positions), \
                        "Beam is Empty"

            loss, error, message = self._hypervolume_manager.evaluate_loss_function(beam_properties, optimization_criteria)

            if error > 0:
                return self.__manage_error(trial_index,
                                           optimization_criteria,
                                           motors_to_optimize,
                                           suggested_motor_positions,
                                           current_motors_positions), \
                       message if not message is None else "Error in calculating the loss function"
            else:
                self._optimization_listener.feedback(trial_index,
                                                     suggested_motor_positions,
                                                     motors_to_optimize,
                                                     current_motors_positions,
                                                     current_loss=loss)
                return loss, None
        except Exception as e:
            traceback.print_exc()
            return self.__manage_error(trial_index,
                                       optimization_criteria,
                                       motors_to_optimize,
                                       suggested_motor_positions,
                                       current_motors_positions), \
                   "Unexpected error while analyzing the beam: " + str(e)

    def __evaluate_suggested_motor_positions_bluesky(self, suggested_motor_positions, trial_index, current_raw_data):
        optimization_criteria = self._optimization_criteria
        motors_to_optimize    = self._input_parameters.motors_to_optimize

        current_raw_data[trial_index] = None

        try:
            yield from self._move_motors(suggested_motor_positions)
            current_motors_positions = yield from self._get_current_motors_positions()

            motor_ok, error_message = self._check_motor_positions(suggested_motor_positions, current_motors_positions)

            if not motor_ok: return self.__manage_error(trial_index,
                                                        optimization_criteria,
                                                        motors_to_optimize,
                                                        suggested_motor_positions,
                                                        current_motors_positions), \
                                    error_message
        except Exception as e:
            traceback.print_exc()
            return self.__manage_error(trial_index,
                                       optimization_criteria,
                                       motors_to_optimize,
                                       suggested_motor_positions,
                                       None), \
                   "Unexpected error while setting motors: " + str(e)

        try:
            beam            = yield from self._beam_manager.get_beam()
            beam_properties = self._beam_manager.get_beam_properties(beam)

            current_raw_data[trial_index] = beam

            if beam_properties.get_parameter("is_empty_beam"):
                return  self.__manage_error(trial_index,
                                            optimization_criteria,
                                            motors_to_optimize,
                                            suggested_motor_positions,
                                            current_motors_positions), \
                        "Beam is Empty"

            loss, error, message = self._hypervolume_manager.evaluate_loss_function(beam_properties, optimization_criteria)

            if error > 0:
                return self.__manage_error(trial_index,
                                           optimization_criteria,
                                           motors_to_optimize,
                                           suggested_motor_positions,
                                           current_motors_positions), \
                       error_message
            else:
                self._optimization_listener.feedback(trial_index,
                                                     suggested_motor_positions,
                                                     motors_to_optimize,
                                                     current_motors_positions,
                                                     current_loss=loss)
                return loss, None
        except Exception as e:
            traceback.print_exc()
            return self.__manage_error(trial_index,
                                       optimization_criteria,
                                       motors_to_optimize,
                                       suggested_motor_positions,
                                       current_motors_positions), \
                   "Unexpected error while analyzing the beam: " + str(e)

    def __process_and_complete_trial(self, ax_client, error_message, execution_parameters, exit_strategy_fulfilled, loss_function, trial_index, trials_to_execute):
        if error_message is None:
            ax_client.complete_trial(trial_index=trial_index, raw_data={"scalar_loss" : loss_function["scalar_loss"]})

            if execution_parameters.use_exit_strategy:
                exit_loss_function = execution_parameters.exit_loss_function
                exit_strategy_fulfilled = True
                if type(exit_loss_function) == float:
                    exit_strategy_fulfilled = loss_function["scalar_loss"] < exit_loss_function
                elif type(exit_loss_function) == dict:
                    for optimization_criterion in loss_function.keys():
                        if optimization_criterion == "scalar_loss":
                            continue
                        elif loss_function[optimization_criterion] > execution_parameters.exit_loss_function[optimization_criterion]:
                            exit_strategy_fulfilled = False
                            break
                if exit_strategy_fulfilled: trials_to_execute = trial_index + 1
        else:
            self._optimization_listener.feedback(trial_index, None, None, None, None, message=error_message)
            ax_client.abandon_trial(trial_index=trial_index, reason=error_message)
        return exit_strategy_fulfilled, trials_to_execute


    # ---------------------------------------------------------------------
    # WARM-START
    # ---------------------------------------------------------------------

    @classmethod
    def _get_pareto_file_prefix(cls) -> str: return "ax_sobo_experiment"

    @classmethod
    def _get_ml_file_prefix(cls) -> str: return cls._get_pareto_file_prefix()

    def _manage_transfer_learning_input(self, **kwargs):
        if self._execution_parameters.do_warm_start: raise NotImplementedError("BlopTools does not support warm start")
        else:                                        self._warm_start_data = None

    # ------------------------------------------------------------------------------
    #  SAVE TO FILE AND PLOTS
    # ------------------------------------------------------------------------------

    @classmethod
    def _get_result_file_prefix(cls) -> str: return cls._get_pareto_file_prefix()


