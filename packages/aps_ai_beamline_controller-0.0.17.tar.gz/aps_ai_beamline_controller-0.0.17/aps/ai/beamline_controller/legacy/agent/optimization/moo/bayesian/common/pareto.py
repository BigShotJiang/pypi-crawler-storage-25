#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import numpy as np

from aps.ai.beamline_controller.legacy.agent.optimization.decorators.direct_beam_image_decorator import DirectBeamImageOptimizationCriteria
from aps.ai.beamline_controller.legacy.agent.optimization.decorators.wavefront_analysis_decorator import WavefrontAnalysisOptimizationCriteria
from aps.ai.beamline_controller.legacy.agent.optimization.decorators.speckle_analysis_decorator import SpeckleAnalysisOptimizationCriteria

from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.facade import SelectionAlgorithm, BayesianOptimizationResult, BayesianOptimizationResultItem, OptimizationTrialStatus
from aps.ai.beamline_controller.legacy.agent.optimization.facade import OptimizationCriteria, OptimizationDirection

def get_closeness(optimization_result: BayesianOptimizationResult, optimization_criteria: OptimizationCriteria, optimization_criteria_weights: dict={}, optimization_initialization: dict={}):
    trials            = optimization_result.get_optimization_items()
    n_trials          = optimization_result.get_number_of_items()
    all_values        = np.ones((n_trials, optimization_criteria.number))

    loss_functions = trials[0].loss_function.keys()
    for ti in range(n_trials): all_values[ti, :] = trials[ti].loss_function.values()

    weights = {}
    for optimization_criterion in optimization_criteria.names:
        weight = optimization_criteria_weights.get(optimization_criterion, 1.0)
        weight *= 1 if optimization_initialization[optimization_criterion].optimization_direction == OptimizationDirection.MINIMIZE else -1
        weights[optimization_criterion] = weight

    F = all_values / np.sqrt(np.sum(all_values, axis=0) ** 2)
    v = F * [weights[loss_function] for loss_function in loss_functions]

    # assuming minimization only
    A_plus = np.amin(v, axis=0, keepdims=True)
    A_minus = np.amax(v, axis=0, keepdims=True)

    s_plus = np.sqrt(np.sum((v - A_plus) ** 2, axis=0))
    s_minus = np.sqrt(np.sum((v - A_minus) ** 2, axis=0))

    return s_minus / (s_plus + s_minus)

def dominates(trial0: BayesianOptimizationResultItem, trial1: BayesianOptimizationResultItem) -> bool:
    def _normalize_value(value: float, direction: str) -> float:
        if value is None: value = float("inf")
        if direction == OptimizationDirection.MAXIMIZE: value = -value
        return value

    values0 = trial0.loss_function.values()
    values1 = trial1.loss_function.values()
    directions = [OptimizationDirection.MINIMIZE for loss_function in trial0.loss_function.keys()]

    assert values0 is not None
    assert values1 is not None

    if len(values0) != len(values1):    raise ValueError("Trials with different numbers of objectives cannot be compared.")
    if len(values0) != len(directions): raise ValueError("The number of the values and the number of the objectives are mismatched.")

    if trial0.status != OptimizationTrialStatus.COMPLETED: return False
    if trial1.status != OptimizationTrialStatus.COMPLETED: return True

    normalized_values0 = [_normalize_value(v, d) for v, d in zip(values0, directions)]
    normalized_values1 = [_normalize_value(v, d) for v, d in zip(values1, directions)]

    if normalized_values0 == normalized_values1: return False

    return all(v0 <= v1 for v0, v1 in zip(normalized_values0, normalized_values1))

# code for pareto front (composed of all solutions)
def calculate_dominated_trials(optimization_result_1: BayesianOptimizationResult,
                               optimization_result_2: BayesianOptimizationResult):
    trial_set_1 = optimization_result_1.get_optimization_items()
    trial_set_2 = optimization_result_2.get_optimization_items()

    n_dominated = []
    for t1 in trial_set_1:
        nd = 0
        for t2 in trial_set_2:
            if t2.status != OptimizationTrialStatus.COMPLETED: continue
            if dominates(t1, t2): nd += 1
        n_dominated.append(nd)

    return n_dominated

def get_best_trial_number(pareto_front_data: BayesianOptimizationResult,
                          optimization_result_data: BayesianOptimizationResult,
                          optimization_criteria: OptimizationCriteria,
                          optimization_criteria_weights: dict = {},
                          optimization_initialization: dict = {},
                          algorithm=SelectionAlgorithm.NASH_EQUILIBRIUM) -> int:
    if pareto_front_data.is_empty(): raise Exception("Pareto Front is empty")

    if algorithm == SelectionAlgorithm.NASH_EQUILIBRIUM: idx = np.argmax(calculate_dominated_trials(pareto_front_data, optimization_result_data))
    elif algorithm == SelectionAlgorithm.TOPSIS:         idx = np.argmax(get_closeness(pareto_front_data, optimization_criteria, optimization_criteria_weights, optimization_initialization))
    elif algorithm == SelectionAlgorithm.MOST_INTENSE:
        if  DirectBeamImageOptimizationCriteria.NEGATIVE_LOG_PEAK_INTENSITY in optimization_criteria.names:        criterion = DirectBeamImageOptimizationCriteria.NEGATIVE_LOG_PEAK_INTENSITY
        elif DirectBeamImageOptimizationCriteria.LOG_WEIGHTED_INTEGRAL_INTENSITY in optimization_criteria.names:   criterion = DirectBeamImageOptimizationCriteria.LOG_WEIGHTED_INTEGRAL_INTENSITY
        elif WavefrontAnalysisOptimizationCriteria.NEGATIVE_LOG_INTENSITY_MAXIMUM in optimization_criteria.names:  criterion = WavefrontAnalysisOptimizationCriteria.NEGATIVE_LOG_INTENSITY_MAXIMUM
        elif WavefrontAnalysisOptimizationCriteria.LOG_WEIGHTED_INTENSITY_INTEGRAL in optimization_criteria.names: criterion = WavefrontAnalysisOptimizationCriteria.LOG_WEIGHTED_INTENSITY_INTEGRAL
        else: raise ValueError("No optimization criteria related to intensity")

        idx = np.argmin([item.loss_function[criterion] for item in pareto_front_data.get_optimization_items()])
    elif algorithm == SelectionAlgorithm.NARROWEST:
        criterion = None
        if   DirectBeamImageOptimizationCriteria.SIGMA_SPHERICAL in optimization_criteria.names:               criterion = DirectBeamImageOptimizationCriteria.SIGMA_SPHERICAL
        elif DirectBeamImageOptimizationCriteria.FWHM_SPHERICAL in optimization_criteria.names:                criterion = DirectBeamImageOptimizationCriteria.FWHM_SPHERICAL
        elif DirectBeamImageOptimizationCriteria.SIGMA_CONVOLUTION in optimization_criteria.names:             criterion = DirectBeamImageOptimizationCriteria.SIGMA_CONVOLUTION
        elif DirectBeamImageOptimizationCriteria.FWHM_CONVOLUTION in optimization_criteria.names:              criterion = DirectBeamImageOptimizationCriteria.FWHM_CONVOLUTION
        elif WavefrontAnalysisOptimizationCriteria.INTENSITY_SIGMA_SPHERICAL in optimization_criteria.names:   criterion = WavefrontAnalysisOptimizationCriteria.INTENSITY_SIGMA_SPHERICAL
        elif WavefrontAnalysisOptimizationCriteria.INTENSITY_FWHM_SPHERICAL in optimization_criteria.names:    criterion = WavefrontAnalysisOptimizationCriteria.INTENSITY_FWHM_SPHERICAL
        elif WavefrontAnalysisOptimizationCriteria.INTENSITY_SIGMA_CONVOLUTION in optimization_criteria.names: criterion = WavefrontAnalysisOptimizationCriteria.INTENSITY_SIGMA_CONVOLUTION
        elif WavefrontAnalysisOptimizationCriteria.INTENSITY_FWHM_CONVOLUTION in optimization_criteria.names:  criterion = WavefrontAnalysisOptimizationCriteria.INTENSITY_FWHM_CONVOLUTION

        if not criterion is None: idx = np.argmin(np.abs([item.loss_function[criterion] for item in pareto_front_data.get_optimization_items()]))
        else:
            criterion_1 = criterion_2 = None
            if   DirectBeamImageOptimizationCriteria.SIGMA_H in optimization_criteria.names:             criterion_1 = DirectBeamImageOptimizationCriteria.SIGMA_H
            elif DirectBeamImageOptimizationCriteria.FWHM_H in optimization_criteria.names:              criterion_1 = DirectBeamImageOptimizationCriteria.FWHM_H
            elif WavefrontAnalysisOptimizationCriteria.INTENSITY_SIGMA_H in optimization_criteria.names: criterion_1 = WavefrontAnalysisOptimizationCriteria.INTENSITY_SIGMA_H
            elif WavefrontAnalysisOptimizationCriteria.INTENSITY_FWHM_H in optimization_criteria.names:  criterion_1 = WavefrontAnalysisOptimizationCriteria.INTENSITY_FWHM_H
            elif SpeckleAnalysisOptimizationCriteria.FWHM_H in optimization_criteria.names:              criterion_1 = SpeckleAnalysisOptimizationCriteria.FWHM_H

            if   DirectBeamImageOptimizationCriteria.SIGMA_V in optimization_criteria.names:             criterion_2 = DirectBeamImageOptimizationCriteria.SIGMA_V
            elif DirectBeamImageOptimizationCriteria.FWHM_V in optimization_criteria.names:              criterion_2 = DirectBeamImageOptimizationCriteria.FWHM_V
            elif WavefrontAnalysisOptimizationCriteria.INTENSITY_SIGMA_V in optimization_criteria.names: criterion_2 = WavefrontAnalysisOptimizationCriteria.INTENSITY_SIGMA_V
            elif WavefrontAnalysisOptimizationCriteria.INTENSITY_FWHM_V in optimization_criteria.names:  criterion_2 = WavefrontAnalysisOptimizationCriteria.INTENSITY_FWHM_V
            elif SpeckleAnalysisOptimizationCriteria.FWHM_V in optimization_criteria.names:              criterion_2 = SpeckleAnalysisOptimizationCriteria.FWHM_V

            if criterion_1 is None and criterion_2 is None: raise ValueError("No optimization criteria associated to size")
            elif criterion_1 is None: idx = np.argmin(np.abs([item.loss_function[criterion_2] for item in pareto_front_data.get_optimization_items()]))
            elif criterion_2 is None: idx = np.argmin(np.abs([item.loss_function[criterion_1] for item in pareto_front_data.get_optimization_items()]))
            else:                     idx = np.argmin([item.loss_function[criterion_1]**2 + item.loss_function[criterion_2]**2 for item in pareto_front_data.get_optimization_items()])
    elif algorithm == SelectionAlgorithm.CLOSEST_TO_CENTER:
        criterion = None
        if   DirectBeamImageOptimizationCriteria.PEAK_LOCATION_SPHERICAL in optimization_criteria.names:             criterion = DirectBeamImageOptimizationCriteria.PEAK_LOCATION_SPHERICAL
        elif DirectBeamImageOptimizationCriteria.CENTROID_SPHERICAL in optimization_criteria.names:                  criterion = DirectBeamImageOptimizationCriteria.CENTROID_SPHERICAL
        elif WavefrontAnalysisOptimizationCriteria.INTENSITY_CENTROID_SPHERICAL in optimization_criteria.names:      criterion = WavefrontAnalysisOptimizationCriteria.INTENSITY_CENTROID_SPHERICAL

        if not criterion is None:
            idx = np.argmin(np.abs([item.loss_function[criterion] for item in pareto_front_data.get_optimization_items()]))
        else:
            criterion_1 = criterion_2 = None
            criterion_3 = criterion_4 = None

            if   DirectBeamImageOptimizationCriteria.PEAK_LOCATION_H in optimization_criteria.names:             criterion_1 = DirectBeamImageOptimizationCriteria.PEAK_LOCATION_H
            elif DirectBeamImageOptimizationCriteria.CENTROID_H in optimization_criteria.names:                  criterion_1 = DirectBeamImageOptimizationCriteria.CENTROID_H
            elif WavefrontAnalysisOptimizationCriteria.INTENSITY_CENTROID_H in optimization_criteria.names:      criterion_1 = WavefrontAnalysisOptimizationCriteria.INTENSITY_CENTROID_H

            if   DirectBeamImageOptimizationCriteria.PEAK_LOCATION_V in optimization_criteria.names:             criterion_2 = DirectBeamImageOptimizationCriteria.PEAK_LOCATION_V
            elif DirectBeamImageOptimizationCriteria.CENTROID_V in optimization_criteria.names:                  criterion_2 = DirectBeamImageOptimizationCriteria.CENTROID_V
            elif WavefrontAnalysisOptimizationCriteria.INTENSITY_CENTROID_V in optimization_criteria.names:      criterion_2 = WavefrontAnalysisOptimizationCriteria.INTENSITY_CENTROID_V

            if WavefrontAnalysisOptimizationCriteria.FOCUS_Z_POSITION_H in optimization_criteria.names:          criterion_3 = WavefrontAnalysisOptimizationCriteria.FOCUS_Z_POSITION_H
            if WavefrontAnalysisOptimizationCriteria.FOCUS_Z_POSITION_V in optimization_criteria.names:          criterion_4 = WavefrontAnalysisOptimizationCriteria.FOCUS_Z_POSITION_V

            if criterion_3 is None and criterion_4 is None:
                if criterion_1 is None and criterion_2 is None: raise ValueError("No criteria associated to Distance from Center")
                elif criterion_1 is None: centering_function = np.abs([item.loss_function[criterion_2] for item in pareto_front_data.get_optimization_items()])
                elif criterion_2 is None: centering_function = np.abs([item.loss_function[criterion_1] for item in pareto_front_data.get_optimization_items()])
                else:                     centering_function = [item.loss_function[criterion_1]**2 + item.loss_function[criterion_2]**2 for item in pareto_front_data.get_optimization_items()]
            else:
                if criterion_1 is None and criterion_2 is None:
                    if   criterion_3 is None: centering_function = np.abs([item.loss_function[criterion_4] for item in pareto_front_data.get_optimization_items()])
                    elif criterion_4 is None: centering_function = np.abs([item.loss_function[criterion_3] for item in pareto_front_data.get_optimization_items()])
                    else:                     centering_function = [item.loss_function[criterion_3]**2 + item.loss_function[criterion_4]**2 for item in pareto_front_data.get_optimization_items()]
                else:
                    if criterion_1 is None:
                        if criterion_3 is None:   centering_function = [item.loss_function[criterion_4]**2 + item.loss_function[criterion_2]**2 for item in pareto_front_data.get_optimization_items()]
                        elif criterion_4 is None: centering_function = [item.loss_function[criterion_3]**2 + item.loss_function[criterion_2]**2 for item in pareto_front_data.get_optimization_items()]
                        else:                     centering_function = [item.loss_function[criterion_3]**2 + item.loss_function[criterion_4]**2 + item.loss_function[criterion_2]**2 for item in pareto_front_data.get_optimization_items()]
                    elif criterion_2 is None:
                        if criterion_3 is None:   centering_function = [item.loss_function[criterion_4]**2 + item.loss_function[criterion_1]**2 for item in pareto_front_data.get_optimization_items()]
                        elif criterion_4 is None: centering_function = [item.loss_function[criterion_3]**2 + item.loss_function[criterion_1]**2 for item in pareto_front_data.get_optimization_items()]
                        else:                     centering_function = [item.loss_function[criterion_3]**2 + item.loss_function[criterion_4]**2 + item.loss_function[criterion_1]**2 for item in pareto_front_data.get_optimization_items()]
                    else:
                        if criterion_3 is None:   centering_function = [item.loss_function[criterion_4]**2 + item.loss_function[criterion_1]**2 + item.loss_function[criterion_2]**2 for item in pareto_front_data.get_optimization_items()]
                        elif criterion_4 is None: centering_function = [item.loss_function[criterion_3]**2 + item.loss_function[criterion_1]**2 + item.loss_function[criterion_2]**2 for item in pareto_front_data.get_optimization_items()]
                        else:                     centering_function = [item.loss_function[criterion_3]**2 + item.loss_function[criterion_4]**2 + item.loss_function[criterion_1]**2 + item.loss_function[criterion_2]**2 for item in pareto_front_data.get_optimization_items()]

            idx = np.argmin(centering_function)

    else: raise ValueError("algorithm not recognized")

    return pareto_front_data.get_optimization_items()[idx].trial_number
