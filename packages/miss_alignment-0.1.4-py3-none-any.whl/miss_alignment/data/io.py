import pickle
import time
import torch
import mrcfile
from pathlib import Path

from warpylib import TiltSeries
from warpylib.ops import rescale
from dataclasses import dataclass, replace


@dataclass(kw_only=True, frozen=True)
class TiltSeriesData:
    # required variables
    xml_metadata_path: Path

    def replace(self, **kwargs):
        return replace(self, **kwargs)

    @property
    def xml_filename(self) -> str:
        return self.xml_metadata_path.stem

    def load_metadata_and_stack(
        self, downsample=1, retry_on_read_error=False
    ) -> tuple[TiltSeries, torch.Tensor, float]:
        metadata, images, pixel_size = _load_metadata_and_stack(
            self.xml_metadata_path,
            downsample=downsample,
            retry_on_read_error=retry_on_read_error,
        )
        return metadata, images, pixel_size

    def save_metadata_to_xml(self, tilt_series: TiltSeries) -> None:
        tilt_series.save_meta(self.xml_metadata_path)


def _validate_tilt_series_dimensions(tilt_series: TiltSeries, path: Path) -> None:
    """Validate that image and volume dimensions are present and non-zero."""
    image_dims = tilt_series.image_dimensions_physical
    volume_dims = tilt_series.volume_dimensions_physical

    if image_dims is None or image_dims.numel() == 0:
        raise ValueError(
            f"XML metadata at {path} is missing 'ImageDimensionsAngstrom'."
        )
    if volume_dims is None or volume_dims.numel() == 0:
        raise ValueError(
            f"XML metadata at {path} is missing 'VolumeDimensionsAngstrom'."
        )
    if torch.any(image_dims == 0):
        raise ValueError(
            f"XML metadata at {path} has zero values in "
            f"'ImageDimensionsAngstrom': {image_dims.tolist()}"
        )
    if torch.any(volume_dims == 0):
        raise ValueError(
            f"XML metadata at {path} has zero values in "
            f"'VolumeDimensionsAngstrom': {volume_dims.tolist()}"
        )


def _load_metadata_and_stack(
    metadata_path: Path,
    downsample: int = 1,
    retry_on_read_error: bool = False,
) -> tuple[TiltSeries, torch.Tensor, float]:
    # load metadata
    tilt_series = TiltSeries(metadata_path)
    _validate_tilt_series_dimensions(tilt_series, metadata_path)

    stack_path = tilt_series.tilt_stack_path

    if retry_on_read_error:
        # Retry on transient short-read errors from the filesystem (e.g. GPFS).
        # Multiple reconstruction workers may open the same file simultaneously,
        # causing the filesystem to return fewer bytes than expected.
        # Only ValueErrors whose message contains "read" indicate a short read;
        # other ValueErrors (corrupt file, bad mode) are permanent and re-raised.
        _max_retries = 5
        for _attempt in range(_max_retries):
            try:
                with mrcfile.open(stack_path) as mrc:
                    images = torch.tensor(mrc.data)
                    stack_pixel_size = float(mrc.voxel_size.x)
                break
            except ValueError as e:
                if "read" not in str(e) or _attempt == _max_retries - 1:
                    raise
                time.sleep(0.05 * (2**_attempt))
    else:
        with mrcfile.open(stack_path) as mrc:
            images = torch.tensor(mrc.data)
            stack_pixel_size = float(mrc.voxel_size.x)

    pixel_size = stack_pixel_size
    if downsample > 1:
        pixel_size = stack_pixel_size * downsample
        images = rescale(
            images,
            size=(
                (images.shape[-2] // downsample + 1) // 2 * 2,
                (images.shape[-1] // downsample + 1) // 2 * 2,
            ),
        )

    # set rounding factors
    tilt_series.size_rounding_factors = torch.tensor(
        [
            (images.shape[-1] * pixel_size) / tilt_series.image_dimensions_physical[0],
            (images.shape[-2] * pixel_size) / tilt_series.image_dimensions_physical[1],
            1.0,  # Z dimension (not used for 2D images)
        ],
        dtype=torch.float32,
    )
    return tilt_series, images, pixel_size


def convert_pickle_to_xml_helper(
    pickle_data_path: Path,
    stack_pixel_size: float,
    original_pixel_size: float,
    original_stack_shape: tuple[int, int],
    volume_shape: tuple[int, int, int],
    data_directory: Path,
) -> tuple[TiltSeriesData, Path]:
    """
    Convert a pickle file containing tilt-series data to XML format.

    Parameters
    ----------
    pickle_data_path : Path
        Path to the pickle file containing tilt-series data.
    stack_pixel_size : float
        Pixel size of the stack in Angstroms.
    original_pixel_size : float
        Original pixel size before any rescaling in Angstroms.
    original_stack_shape : tuple[int, int]
        Original stack shape as (width, height) in pixels.
    volume_shape : tuple[int, int, int]
        Volume shape as (x, y, z) in pixels.
    data_directory : Path
        Path to write directory.

    Returns
    -------
    tuple[TiltSeriesData, Path]
        TiltSeriesData object and path to the created XML file.
    """
    # read the pickle
    with open(pickle_data_path, "rb") as infile:
        data_dict = pickle.load(infile)
    images = data_dict["tilt_series"]
    n_tilts, _, _ = images.shape

    # prepare output paths
    tilt_series_name = pickle_data_path.stem
    xml_path = data_directory / f"{tilt_series_name}.xml"

    # initialize a fresh warpylib TiltSeries with path
    tilt_series = TiltSeries(
        path=xml_path,
        n_tilts=n_tilts,
    )

    # Get the stack path from warpylib (this follows warpylib's directory structure)
    stack_path = Path(tilt_series.tilt_stack_path)
    # Create the directory structure for the stack
    stack_path.parent.mkdir(parents=True, exist_ok=True)
    tilt_series.angles = data_dict["tilt_angles"]

    # Handle scalar tilt_axis_angle by expanding to array
    tilt_axis_angle = data_dict["tilt_axis_angle"]
    if tilt_axis_angle.ndim == 0:  # scalar tensor
        tilt_axis_angle = torch.full((n_tilts,), tilt_axis_angle.item())
    tilt_series.tilt_axis_angles = tilt_axis_angle

    axis_offsets_angstrom = data_dict["sample_translations"] * stack_pixel_size
    tilt_series.tilt_axis_offset_y = axis_offsets_angstrom[:, 0].clone()
    tilt_series.tilt_axis_offset_x = axis_offsets_angstrom[:, 1].clone()

    # Set physical dimensions
    tilt_series.image_dimensions_physical = torch.tensor(
        [
            original_stack_shape[0] * original_pixel_size,
            original_stack_shape[1] * original_pixel_size,
        ],
        dtype=torch.float32,
    )
    tilt_series.volume_dimensions_physical = torch.tensor(
        [
            volume_shape[0] * stack_pixel_size,
            volume_shape[1] * stack_pixel_size,
            volume_shape[2] * stack_pixel_size,
        ],
        dtype=torch.float32,
    )

    # Write MRC stack
    with mrcfile.new(stack_path, overwrite=True) as mrc:
        mrc.set_data(images.cpu().numpy())
        mrc.voxel_size = stack_pixel_size

    # Create TiltSeriesData and save metadata to XML
    new_tilt_series_data = TiltSeriesData(
        xml_metadata_path=xml_path,
    )
    new_tilt_series_data.save_metadata_to_xml(tilt_series)

    return new_tilt_series_data, xml_path
