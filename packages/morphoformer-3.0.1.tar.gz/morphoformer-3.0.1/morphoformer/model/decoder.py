"""Decoder stack: causal SelfAttn -> CrossAttn -> FFN with adapters and KV cache."""

from __future__ import annotations

import torch
import torch.nn as nn
from torch.utils.checkpoint import checkpoint as gradient_checkpoint

from torchblocks import registry


class DecoderLayer(nn.Module):
    def __init__(
        self,
        d_model: int,
        num_heads: int,
        num_kv_heads: int,
        dim_ff: int,
        dropout: float = 0.1,
        adapter_bottleneck: int = 128,
        norm_type: str = "rmsnorm",
        attention_type: str = "gqa",
        feedforward_type: str = "swiglu",
        adapter_type: str = "language_conditioned",
    ) -> None:
        super().__init__()
        norm_cls = registry.get("norm", norm_type)
        attn_cls = registry.get("attention", attention_type)
        cross_cls = registry.get("attention", "cross")
        ff_cls = registry.get("feedforward", feedforward_type)
        adapter_cls = registry.get("adapter", adapter_type)

        self.self_attn_norm = norm_cls(d_model)
        self.self_attn = attn_cls(d_model, num_heads, num_kv_heads, dropout)
        self.self_attn_adapter = adapter_cls(d_model, adapter_bottleneck)

        self.cross_attn_norm = norm_cls(d_model)
        self.cross_attn = cross_cls(d_model, num_heads, num_kv_heads, dropout)
        self.cross_attn_adapter = adapter_cls(d_model, adapter_bottleneck)

        self.ffn_norm = norm_cls(d_model)
        self.ffn = ff_cls(d_model, dim_ff, dropout)
        self.ffn_adapter = adapter_cls(d_model, adapter_bottleneck)

    def forward(
        self,
        x: torch.Tensor,
        memory: torch.Tensor,
        rope_cos: torch.Tensor,
        rope_sin: torch.Tensor,
        lang_embed: torch.Tensor,
        self_attn_mask: torch.Tensor | None = None,
        cross_attn_mask: torch.Tensor | None = None,
        self_kv_cache: tuple[torch.Tensor, torch.Tensor] | None = None,
        cross_kv_cache: tuple[torch.Tensor, torch.Tensor] | None = None,
    ) -> tuple[
        torch.Tensor,
        tuple[torch.Tensor, torch.Tensor],
        tuple[torch.Tensor, torch.Tensor],
    ]:
        attn_out, new_self_cache = self.self_attn(
            self.self_attn_norm(x), rope_cos, rope_sin, self_attn_mask, self_kv_cache,
        )
        x = x + attn_out
        x = self.self_attn_adapter(x, lang_embed)

        cross_out, new_cross_cache = self.cross_attn(
            self.cross_attn_norm(x), memory, cross_attn_mask, cross_kv_cache,
        )
        x = x + cross_out
        x = self.cross_attn_adapter(x, lang_embed)

        x = x + self.ffn(self.ffn_norm(x))
        x = self.ffn_adapter(x, lang_embed)
        return x, new_self_cache, new_cross_cache


class Decoder(nn.Module):
    def __init__(
        self,
        num_layers: int,
        d_model: int,
        num_heads: int,
        num_kv_heads: int,
        dim_ff: int,
        dropout: float = 0.1,
        adapter_bottleneck: int = 128,
        norm_type: str = "rmsnorm",
        attention_type: str = "gqa",
        feedforward_type: str = "swiglu",
        adapter_type: str = "language_conditioned",
    ) -> None:
        super().__init__()
        self.num_layers = num_layers
        self.layers = nn.ModuleList([
            DecoderLayer(
                d_model, num_heads, num_kv_heads, dim_ff, dropout,
                adapter_bottleneck, norm_type, attention_type,
                feedforward_type, adapter_type,
            )
            for _ in range(num_layers)
        ])
        norm_cls = registry.get("norm", norm_type)
        self.final_norm = norm_cls(d_model)
        self._gradient_checkpointing = False

    def enable_gradient_checkpointing(self) -> None:
        self._gradient_checkpointing = True

    def disable_gradient_checkpointing(self) -> None:
        self._gradient_checkpointing = False

    def forward(
        self,
        x: torch.Tensor,
        memory: torch.Tensor,
        rope_cos: torch.Tensor,
        rope_sin: torch.Tensor,
        lang_embed: torch.Tensor,
        self_attn_mask: torch.Tensor | None = None,
        cross_attn_mask: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """Training forward pass (no KV cache)."""
        for layer in self.layers:
            if self._gradient_checkpointing and self.training:
                def _layer_fn(layer_ref, *args):
                    out, _, _ = layer_ref(*args)
                    return out
                x = gradient_checkpoint(
                    _layer_fn, layer, x, memory, rope_cos, rope_sin,
                    lang_embed, self_attn_mask, cross_attn_mask, None, None,
                    use_reentrant=False,
                )
            else:
                x, _, _ = layer(
                    x, memory, rope_cos, rope_sin, lang_embed,
                    self_attn_mask, cross_attn_mask,
                )
        return self.final_norm(x)

    def forward_cached(
        self,
        x: torch.Tensor,
        memory: torch.Tensor,
        rope_cos: torch.Tensor,
        rope_sin: torch.Tensor,
        lang_embed: torch.Tensor,
        self_caches: list[tuple[torch.Tensor, torch.Tensor] | None],
        cross_caches: list[tuple[torch.Tensor, torch.Tensor] | None],
        self_attn_mask: torch.Tensor | None = None,
        cross_attn_mask: torch.Tensor | None = None,
    ) -> tuple[
        torch.Tensor,
        list[tuple[torch.Tensor, torch.Tensor]],
        list[tuple[torch.Tensor, torch.Tensor]],
    ]:
        """Inference forward pass with KV cache (token-by-token generation)."""
        new_self_caches = []
        new_cross_caches = []
        for idx, layer in enumerate(self.layers):
            x, self_cache, cross_cache = layer(
                x, memory, rope_cos, rope_sin, lang_embed,
                self_attn_mask, cross_attn_mask,
                self_caches[idx], cross_caches[idx],
            )
            new_self_caches.append(self_cache)
            new_cross_caches.append(cross_cache)
        return self.final_norm(x), new_self_caches, new_cross_caches
