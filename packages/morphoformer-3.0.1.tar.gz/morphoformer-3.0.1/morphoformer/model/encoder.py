"""Encoder stack: SelfAttn -> Conv -> FFN with language-conditioned adapters."""

from __future__ import annotations

import torch
import torch.nn as nn
from torch.utils.checkpoint import checkpoint as gradient_checkpoint

from torchblocks import registry


class EncoderLayer(nn.Module):
    def __init__(
        self,
        d_model: int,
        num_heads: int,
        num_kv_heads: int,
        dim_ff: int,
        dropout: float = 0.1,
        conv_kernel: int = 7,
        adapter_bottleneck: int = 128,
        norm_type: str = "rmsnorm",
        attention_type: str = "gqa",
        feedforward_type: str = "swiglu",
        conv_type: str = "local",
        adapter_type: str = "language_conditioned",
    ) -> None:
        super().__init__()
        norm_cls = registry.get("norm", norm_type)
        attn_cls = registry.get("attention", attention_type)
        ff_cls = registry.get("feedforward", feedforward_type)
        conv_cls = registry.get("conv", conv_type)
        adapter_cls = registry.get("adapter", adapter_type)

        self.self_attn_norm = norm_cls(d_model)
        self.self_attn = attn_cls(d_model, num_heads, num_kv_heads, dropout)
        self.attn_adapter = adapter_cls(d_model, adapter_bottleneck)

        self.conv_norm = norm_cls(d_model)
        self.conv = conv_cls(d_model, conv_kernel, dropout)

        self.ffn_norm = norm_cls(d_model)
        self.ffn = ff_cls(d_model, dim_ff, dropout)
        self.ffn_adapter = adapter_cls(d_model, adapter_bottleneck)

    def forward(
        self,
        x: torch.Tensor,
        rope_cos: torch.Tensor,
        rope_sin: torch.Tensor,
        lang_embed: torch.Tensor,
        attn_mask: torch.Tensor | None = None,
    ) -> torch.Tensor:
        attn_out, _ = self.self_attn(self.self_attn_norm(x), rope_cos, rope_sin, attn_mask)
        x = x + attn_out
        x = self.attn_adapter(x, lang_embed)

        x = x + self.conv(self.conv_norm(x))

        x = x + self.ffn(self.ffn_norm(x))
        x = self.ffn_adapter(x, lang_embed)
        return x


class Encoder(nn.Module):
    def __init__(
        self,
        num_layers: int,
        d_model: int,
        num_heads: int,
        num_kv_heads: int,
        dim_ff: int,
        dropout: float = 0.1,
        conv_kernel: int = 7,
        adapter_bottleneck: int = 128,
        norm_type: str = "rmsnorm",
        attention_type: str = "gqa",
        feedforward_type: str = "swiglu",
        conv_type: str = "local",
        adapter_type: str = "language_conditioned",
    ) -> None:
        super().__init__()
        self.layers = nn.ModuleList([
            EncoderLayer(
                d_model, num_heads, num_kv_heads, dim_ff, dropout,
                conv_kernel, adapter_bottleneck,
                norm_type, attention_type, feedforward_type,
                conv_type, adapter_type,
            )
            for _ in range(num_layers)
        ])
        norm_cls = registry.get("norm", norm_type)
        self.final_norm = norm_cls(d_model)
        self._gradient_checkpointing = False

    def enable_gradient_checkpointing(self) -> None:
        self._gradient_checkpointing = True

    def disable_gradient_checkpointing(self) -> None:
        self._gradient_checkpointing = False

    def forward(
        self,
        x: torch.Tensor,
        rope_cos: torch.Tensor,
        rope_sin: torch.Tensor,
        lang_embed: torch.Tensor,
        attn_mask: torch.Tensor | None = None,
    ) -> torch.Tensor:
        for layer in self.layers:
            if self._gradient_checkpointing and self.training:
                x = gradient_checkpoint(
                    layer, x, rope_cos, rope_sin, lang_embed, attn_mask,
                    use_reentrant=False,
                )
            else:
                x = layer(x, rope_cos, rope_sin, lang_embed, attn_mask)
        return self.final_norm(x)
