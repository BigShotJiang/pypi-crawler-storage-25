"""Structured morphological feature encoder.

Encodes a set of categorical features (e.g. V, IND, PRS, 3, SG) into a
single d_model vector instead of character-level string processing.
"""

from __future__ import annotations

import torch
import torch.nn as nn

from torchblocks.registry import register


@register("morph_encoder", "pooled")
class PooledMorphEncoder(nn.Module):
    """Embed features, mean-pool over valid positions, and project to d_model."""

    def __init__(
        self,
        feature_vocab_size: int,
        d_model: int,
        max_features: int = 12,
        padding_idx: int = 0,
    ) -> None:
        super().__init__()
        self.feature_embedding = nn.Embedding(feature_vocab_size, d_model, padding_idx=padding_idx)
        self.projection = nn.Linear(d_model, d_model, bias=False)
        self.max_features = max_features

    def forward(
        self,
        feature_ids: torch.Tensor,
        feature_mask: torch.Tensor,
    ) -> torch.Tensor:
        """
        Args:
            feature_ids: ``(batch, max_features)`` — feature token IDs.
            feature_mask: ``(batch, max_features)`` — 1.0 for valid, 0.0 for padding.
        Returns:
            ``(batch, d_model)`` — one vector per sample.
        """
        embedded = self.feature_embedding(feature_ids)
        embedded = embedded * feature_mask.unsqueeze(-1)
        count = feature_mask.sum(dim=1, keepdim=True).clamp(min=1)
        pooled = embedded.sum(dim=1) / count
        return self.projection(pooled)


@register("morph_encoder", "attention")
class AttentionMorphEncoder(nn.Module):
    """Encode features via a learnable query and cross-attention."""

    def __init__(
        self,
        feature_vocab_size: int,
        d_model: int,
        max_features: int = 12,
        padding_idx: int = 0,
        num_heads: int = 4,
    ) -> None:
        super().__init__()
        self.feature_embedding = nn.Embedding(feature_vocab_size, d_model, padding_idx=padding_idx)
        self.query = nn.Parameter(torch.randn(1, 1, d_model) * 0.02)
        self.cross_attn = nn.MultiheadAttention(d_model, num_heads, batch_first=True)
        self.max_features = max_features

    def forward(
        self,
        feature_ids: torch.Tensor,
        feature_mask: torch.Tensor,
    ) -> torch.Tensor:
        embedded = self.feature_embedding(feature_ids)
        batch_size = feature_ids.size(0)
        query = self.query.expand(batch_size, -1, -1)
        key_padding_mask = feature_mask == 0.0
        output, _ = self.cross_attn(query, embedded, embedded, key_padding_mask=key_padding_mask)
        return output.squeeze(1)
