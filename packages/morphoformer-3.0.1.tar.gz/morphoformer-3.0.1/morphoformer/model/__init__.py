"""MorphFormer model: imports torchblocks to trigger @register decorators."""

import torchblocks  # noqa: F401 — triggers all @register decorators

from torchblocks import get, list_modules
from morphoformer.model.transformer import MorphFormer
from morphoformer.model.encoder import Encoder, EncoderLayer
from morphoformer.model.decoder import Decoder, DecoderLayer
from morphoformer.model.morph_encoder import PooledMorphEncoder, AttentionMorphEncoder
