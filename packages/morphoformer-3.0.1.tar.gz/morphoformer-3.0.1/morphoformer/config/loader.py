"""TOML serialization: load/save for FullConfig."""

from __future__ import annotations

from pathlib import Path

from morphoformer.config.schema import (
    FullConfig, ModelConfig, DataConfig, TrainingConfig,
    EncoderConfig, DecoderConfig, MorphEncoderConfig, CheckpointConfig,
)

try:
    import tomllib
except ModuleNotFoundError:
    import tomli as tomllib  # type: ignore[no-redef]


def _merge_dataclass(cls, data: dict):
    """Instantiate *cls* from *data*, silently dropping unknown keys."""
    import dataclasses
    field_names = {f.name for f in dataclasses.fields(cls)}
    filtered = {k: v for k, v in data.items() if k in field_names}
    return cls(**filtered)


def load_config(path: str | Path) -> FullConfig:
    path = Path(path)
    with open(path, "rb") as file:
        raw = tomllib.load(file)

    model_raw = raw.get("model", {})
    encoder_raw = model_raw.pop("encoder", {})
    decoder_raw = model_raw.pop("decoder", {})
    morph_raw = model_raw.pop("morph_encoder", {})

    training_raw = raw.get("training", {})
    checkpoint_raw = training_raw.pop("checkpoint", {})

    return FullConfig(
        model=ModelConfig(
            **{k: v for k, v in model_raw.items() if k in ModelConfig.__dataclass_fields__},
            encoder=_merge_dataclass(EncoderConfig, encoder_raw),
            decoder=_merge_dataclass(DecoderConfig, decoder_raw),
            morph_encoder=_merge_dataclass(MorphEncoderConfig, morph_raw),
        ),
        data=_merge_dataclass(DataConfig, raw.get("data", {})),
        training=TrainingConfig(
            **{k: v for k, v in training_raw.items() if k in TrainingConfig.__dataclass_fields__},
            checkpoint=_merge_dataclass(CheckpointConfig, checkpoint_raw),
        ),
    )


def _format_toml_value(value) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, str):
        return f'"{value}"'
    if isinstance(value, float):
        return f"{value}"
    return str(value)


def save_config(config: FullConfig, path: str | Path) -> None:
    path = Path(path)
    data = config.to_dict()
    lines: list[str] = []

    def _write_section(section_data: dict, prefix: str = "") -> None:
        scalars = {}
        tables = {}
        for key, value in section_data.items():
            if isinstance(value, dict):
                tables[key] = value
            else:
                scalars[key] = value

        if prefix:
            lines.append(f"\n[{prefix}]")
        for key, value in scalars.items():
            lines.append(f"{key} = {_format_toml_value(value)}")

        for key, value in tables.items():
            full_key = f"{prefix}.{key}" if prefix else key
            _write_section(value, full_key)

    _write_section(data)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
