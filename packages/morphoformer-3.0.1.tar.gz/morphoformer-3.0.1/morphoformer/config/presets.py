"""Model presets (small / medium / large) scaled for 35+ languages."""

from __future__ import annotations

from morphoformer.config.schema import ModelConfig, EncoderConfig, DecoderConfig, MorphEncoderConfig


# ~7M params
_SMALL = ModelConfig(
    d_model=384,
    num_heads=6,
    num_kv_heads=2,
    dim_ff=1024,
    dropout=0.15,
    encoder=EncoderConfig(num_layers=4, conv_kernel=5, adapter_bottleneck=64),
    decoder=DecoderConfig(num_layers=3, adapter_bottleneck=64),
    morph_encoder=MorphEncoderConfig(type="pooled"),
)

# ~45M params
_MEDIUM = ModelConfig(
    d_model=512,
    num_heads=8,
    num_kv_heads=2,
    dim_ff=1376,
    dropout=0.15,
    encoder=EncoderConfig(num_layers=8, conv_kernel=7, adapter_bottleneck=128),
    decoder=DecoderConfig(num_layers=6, adapter_bottleneck=128),
    morph_encoder=MorphEncoderConfig(type="pooled"),
)

# ~120M params, requires >= 8 GB VRAM
_LARGE = ModelConfig(
    d_model=768,
    num_heads=12,
    num_kv_heads=4,
    dim_ff=2048,
    dropout=0.1,
    encoder=EncoderConfig(num_layers=10, conv_kernel=7, adapter_bottleneck=192),
    decoder=DecoderConfig(num_layers=8, adapter_bottleneck=192),
    morph_encoder=MorphEncoderConfig(type="attention"),
)

PRESETS: dict[str, ModelConfig] = {
    "small": _SMALL,
    "medium": _MEDIUM,
    "large": _LARGE,
}


def get_preset(name: str) -> ModelConfig:
    if name not in PRESETS:
        available = ", ".join(PRESETS)
        raise KeyError(f"Preset '{name}' not found. Available: {available}")
    return PRESETS[name]
