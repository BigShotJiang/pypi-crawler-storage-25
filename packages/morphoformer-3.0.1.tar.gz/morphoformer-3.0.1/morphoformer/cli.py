"""Command-line interface for MorphFormer.

Subcommands: train, infer, serve, download, modules, init-config.
Entry point registered as ``morphoformer`` console script.
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

import torch

from chartoken import CharVocab, FeatureVocab
from sigmorphon import MorphDataset, load_tsv, load_tsv_pattern

from morphoformer.config import (
    FullConfig, ModelConfig, DataConfig, TrainingConfig,
    EncoderConfig, DecoderConfig, MorphEncoderConfig, CheckpointConfig,
    load_config, save_config, get_preset,
)
from morphoformer.config.loader import _merge_dataclass


DEVICE_CHOICES = ("auto", "cpu", "cuda", "rocm", "xpu", "mps")


def _resolve_device(device_arg: str) -> torch.device:
    if device_arg == "cpu":
        return torch.device("cpu")
    if device_arg == "cuda":
        if not torch.cuda.is_available():
            print("CUDA not available.", file=sys.stderr)
            sys.exit(1)
        return torch.device("cuda")
    if device_arg == "rocm":
        if not torch.cuda.is_available() or getattr(torch.version, "hip", None) is None:
            print("ROCm not available.", file=sys.stderr)
            sys.exit(1)
        return torch.device("cuda")
    if device_arg == "xpu":
        if not (hasattr(torch, "xpu") and torch.xpu.is_available()):
            print("Intel XPU not available.", file=sys.stderr)
            sys.exit(1)
        return torch.device("xpu")
    if device_arg == "mps":
        if not (hasattr(torch.backends, "mps") and torch.backends.mps.is_available()):
            print("Apple MPS not available.", file=sys.stderr)
            sys.exit(1)
        return torch.device("mps")
    # auto: CUDA -> XPU -> MPS -> CPU
    if torch.cuda.is_available():
        return torch.device("cuda")
    if hasattr(torch, "xpu") and torch.xpu.is_available():
        return torch.device("xpu")
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def _build_model_from_config(config, char_vocab_size, feature_vocab_size):
    from morphoformer.model import MorphFormer

    mc = config.model
    return MorphFormer(
        char_vocab_size=char_vocab_size,
        feature_vocab_size=feature_vocab_size,
        num_languages=mc.num_languages,
        d_model=mc.d_model,
        num_heads=mc.num_heads,
        num_kv_heads=mc.num_kv_heads,
        num_encoder_layers=mc.encoder.num_layers,
        num_decoder_layers=mc.decoder.num_layers,
        dim_ff=mc.dim_ff,
        dropout=mc.dropout,
        max_positions=mc.max_positions,
        conv_kernel=mc.encoder.conv_kernel,
        enc_adapter_bottleneck=mc.encoder.adapter_bottleneck,
        dec_adapter_bottleneck=mc.decoder.adapter_bottleneck,
        max_features=mc.morph_encoder.max_features,
        enc_norm_type=mc.encoder.norm,
        dec_norm_type=mc.decoder.norm,
        enc_attention_type=mc.encoder.attention,
        dec_attention_type=mc.decoder.attention,
        enc_feedforward_type=mc.encoder.feedforward,
        dec_feedforward_type=mc.decoder.feedforward,
        conv_type=mc.encoder.conv,
        enc_adapter_type=mc.encoder.adapter,
        dec_adapter_type=mc.decoder.adapter,
        morph_encoder_type=mc.morph_encoder.type,
    )


def _restore_config(config_dict: dict) -> FullConfig:
    """Reconstruct a FullConfig from a checkpoint state dict."""
    mc = config_dict["model"]
    model_scalars = {k: v for k, v in mc.items() if k not in ("encoder", "decoder", "morph_encoder")}
    training_raw = config_dict.get("training", {})
    training_scalars = {k: v for k, v in training_raw.items() if k != "checkpoint"}
    return FullConfig(
        model=_merge_dataclass(ModelConfig, {
            **model_scalars,
            "encoder": _merge_dataclass(EncoderConfig, mc.get("encoder", {})),
            "decoder": _merge_dataclass(DecoderConfig, mc.get("decoder", {})),
            "morph_encoder": _merge_dataclass(MorphEncoderConfig, mc.get("morph_encoder", {})),
        }),
        data=_merge_dataclass(DataConfig, config_dict.get("data", {})),
        training=_merge_dataclass(TrainingConfig, {
            **training_scalars,
            "checkpoint": _merge_dataclass(CheckpointConfig, training_raw.get("checkpoint", {})),
        }),
    )


def cmd_train(args: argparse.Namespace) -> None:
    from trainkit import format_bytes
    from morphoformer.training import Trainer

    if args.config:
        config = load_config(args.config)
    else:
        config = FullConfig()

    if args.preset:
        config.model = get_preset(args.preset)

    if args.data:
        config.data.train_path = args.data
    if args.val:
        config.data.val_path = args.val
    if args.epochs is not None:
        config.training.epochs = args.epochs
    if args.batch is not None:
        config.training.batch_size = args.batch
    if args.lr is not None:
        config.training.lr = args.lr
    if args.device:
        config.training.device = args.device
    if args.pin_memory is not None:
        config.data.pin_memory = args.pin_memory
    if args.prefetch_factor is not None:
        config.data.prefetch_factor = args.prefetch_factor

    if not config.data.train_path:
        print("Specify --data or train_path in config", file=sys.stderr)
        sys.exit(1)

    print(f"Loading data: {config.data.train_path}", flush=True)

    train_path = config.data.train_path
    if "*" in train_path or "?" in train_path or "[" in train_path:
        rows = load_tsv_pattern(train_path)
    else:
        rows = load_tsv(train_path)

    if not rows:
        print("No data found", file=sys.stderr)
        sys.exit(1)
    print(f"  {len(rows)} rows", flush=True)

    all_texts = [lemma for lemma, _, _, _ in rows] + [surface for _, _, surface, _ in rows]
    char_vocab = CharVocab.from_texts(all_texts)

    all_tags = [tags for _, tags, _, _ in rows]
    feature_vocab = FeatureVocab.from_tags(all_tags)

    all_langs = sorted({lang for _, _, _, lang in rows})
    lang_to_id = {lang: idx for idx, lang in enumerate(all_langs)}
    config.model.num_languages = max(len(all_langs), config.model.num_languages)

    print(
        f"  char_vocab={char_vocab.size}  feat_vocab={feature_vocab.size}  "
        f"langs={len(all_langs)} {all_langs}",
        flush=True,
    )

    print("Encoding...", end=" ", flush=True)
    dataset = MorphDataset(
        rows, char_vocab, feature_vocab, lang_to_id,
        max_len=config.data.max_len,
        max_features=config.model.morph_encoder.max_features,
        pin_memory=config.data.pin_memory,
    )
    print(f"done ({format_bytes(dataset.memory_bytes())} RAM)", flush=True)

    import morphoformer.model  # noqa: F401 — trigger registry
    model = _build_model_from_config(config, char_vocab.size, feature_vocab.size)

    device = _resolve_device(config.training.device)
    print(f"Device: {device}", flush=True)

    resume_checkpoint = None
    if config.training.checkpoint.resume:
        resume_path = Path(config.training.checkpoint.resume)
        if not resume_path.exists():
            print(f"Checkpoint not found: {resume_path}", file=sys.stderr)
            sys.exit(1)
        print(f"Loading checkpoint: {resume_path}", flush=True)
        resume_checkpoint = torch.load(resume_path, map_location="cpu", weights_only=False)

    trainer = Trainer(model, config, char_vocab, feature_vocab, lang_to_id, device, resume_checkpoint)
    trainer.train(dataset)


def cmd_infer(args: argparse.Namespace) -> None:
    import morphoformer.model  # noqa: F401 — trigger registry
    from morphoformer.inference import greedy_decode

    checkpoint = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    char_vocab = CharVocab.from_dict(checkpoint["char_vocab"])
    feature_vocab = FeatureVocab.from_dict(checkpoint["feature_vocab"])
    lang_to_id = checkpoint["lang_to_id"]
    config = _restore_config(checkpoint["config"])

    model = _build_model_from_config(config, char_vocab.size, feature_vocab.size)
    device = _resolve_device(args.device)
    model = model.to(device)
    model.load_state_dict(checkpoint["model"])
    model.eval()

    tags = args.morph.split(";")
    lang_id = lang_to_id.get(args.lang, 0)

    result = greedy_decode(
        model, char_vocab, feature_vocab, args.word, tags, lang_id,
        device=device,
        max_len=config.data.max_len,
        max_out=config.data.max_out,
        max_features=config.model.morph_encoder.max_features,
    )
    print(result)


def cmd_serve(args: argparse.Namespace) -> None:
    import morphoformer.model  # noqa: F401 — trigger registry
    from morphoformer.inference import greedy_decode

    # Force UTF-8 on stdout/stderr/stdin to avoid cp1251 encoding errors on Windows
    if sys.stdout.encoding != "utf-8":
        sys.stdout.reconfigure(encoding="utf-8")
    if sys.stderr.encoding != "utf-8":
        sys.stderr.reconfigure(encoding="utf-8")
    if sys.stdin.encoding != "utf-8":
        sys.stdin.reconfigure(encoding="utf-8")

    checkpoint = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    char_vocab = CharVocab.from_dict(checkpoint["char_vocab"])
    feature_vocab = FeatureVocab.from_dict(checkpoint["feature_vocab"])
    lang_to_id = checkpoint["lang_to_id"]
    config = _restore_config(checkpoint["config"])

    model = _build_model_from_config(config, char_vocab.size, feature_vocab.size)
    device = _resolve_device(args.device)
    model = model.to(device)
    model.load_state_dict(checkpoint["model"])
    model.eval()

    print(f"Device: {device}")
    print(f"Languages: {list(lang_to_id.keys())}")
    print("Format: WORD FEATURES [LANG]  or  WORD|FEATURES[|LANG]")
    interactive = sys.stdin.isatty()
    if interactive:
        print("Empty line or Ctrl+C to quit.\n", flush=True)
    else:
        print("Empty line or Ctrl+C to quit.", flush=True)

    try:
        while True:
            try:
                if interactive:
                    line = input("> ").strip()
                else:
                    line = sys.stdin.readline()
                    if not line:
                        break
                    line = line.strip()
            except EOFError:
                break
            if not line:
                break

            if "|" in line:
                parts = line.split("|")
            else:
                parts = line.split(None, 2)

            if len(parts) < 2:
                print("  expected: WORD FEATURES [LANG]", file=sys.stderr)
                continue

            word = parts[0]
            tags = parts[1].split(";")
            lang = parts[2] if len(parts) > 2 else next(iter(lang_to_id), "unk")
            lang_id = lang_to_id.get(lang, 0)

            start_time = time.perf_counter()
            result = greedy_decode(
                model, char_vocab, feature_vocab, word, tags, lang_id,
                device=device,
                max_len=config.data.max_len,
                max_out=config.data.max_out,
                max_features=config.model.morph_encoder.max_features,
            )
            elapsed_ms = (time.perf_counter() - start_time) * 1000
            print(f"  {result}  ({elapsed_ms:.1f}ms)")
    except KeyboardInterrupt:
        print()


def cmd_download(args: argparse.Namespace) -> None:
    from sigmorphon import download_all, merge_tsv, get_available_languages, DATASETS

    out_dir = Path(args.out_dir)

    if args.lang == "all":
        languages = ["all"]
    else:
        languages = args.lang.split(",")
        available_langs = get_available_languages()
        invalid_langs = [lang for lang in languages if lang not in available_langs and lang not in DATASETS]
        if invalid_langs:
            print(f"Warning: these languages may not be available: {', '.join(invalid_langs)}", file=sys.stderr)
            print(f"Available languages: {', '.join(sorted(available_langs))}", file=sys.stderr)

    download_all(languages, out_dir)

    if args.merge:
        train_files = list(out_dir.glob("*_train.tsv"))
        if train_files:
            merged = out_dir / "merged_train.tsv"
            count = merge_tsv(train_files, merged)
            print(f"Merged: {merged} ({count} rows)", flush=True)


def cmd_modules(args: argparse.Namespace) -> None:
    import morphoformer.model  # noqa: F401 — trigger registry
    from torchblocks import list_modules

    all_modules = list_modules()
    for category, names in sorted(all_modules.items()):
        print(f"[{category}]")
        for name in names:
            print(f"  {name}")
        print()


def cmd_init_config(args: argparse.Namespace) -> None:
    out_path = Path(args.out)
    config = FullConfig()
    if args.preset:
        config.model = get_preset(args.preset)
    save_config(config, out_path)
    print(f"Config saved: {out_path}", flush=True)


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        prog="morphoformer",
        description="MorphFormer: multilingual morphological reinflection.",
    )
    subparsers = parser.add_subparsers(dest="cmd", required=True)

    # --- train ---
    train_p = subparsers.add_parser("train", help="train model")
    train_p.add_argument("--config", type=str, default=None, help="path to .toml config")
    train_p.add_argument("--preset", type=str, default=None, choices=["small", "medium", "large"],
                         help="model preset (overrides model section)")
    train_p.add_argument("--data", type=str, default=None, help="training .tsv path (supports wildcards)")
    train_p.add_argument("--val", type=str, default=None, help="validation .tsv path")
    train_p.add_argument("--epochs", type=int, default=None, help="number of training epochs")
    train_p.add_argument("--batch", type=int, default=None, help="batch size")
    train_p.add_argument("--lr", type=float, default=None, help="learning rate")
    train_p.add_argument("--device", type=str, default="auto", choices=DEVICE_CHOICES, help="compute device")
    train_p.add_argument("--pin-memory", type=lambda x: x.lower() == "true", default=None, dest="pin_memory",
                         help="pin tensors to CUDA memory")
    train_p.add_argument("--prefetch-factor", type=int, default=None, dest="prefetch_factor",
                         help="number of batches to prefetch")
    train_p.set_defaults(func=cmd_train)

    # --- infer ---
    infer_p = subparsers.add_parser("infer", help="run inference from checkpoint")
    infer_p.add_argument("--checkpoint", type=str, required=True, help="path to .pt checkpoint")
    infer_p.add_argument("--word", type=str, required=True, help="lemma to reinflect")
    infer_p.add_argument("--morph", type=str, required=True, help="features separated by ;")
    infer_p.add_argument("--lang", type=str, default="unk", help="language code (ISO 639-3)")
    infer_p.add_argument("--device", type=str, default="auto", choices=DEVICE_CHOICES, help="compute device")
    infer_p.set_defaults(func=cmd_infer)

    # --- serve ---
    serve_p = subparsers.add_parser("serve", help="interactive REPL")
    serve_p.add_argument("--checkpoint", type=str, required=True, help="path to .pt checkpoint")
    serve_p.add_argument("--device", type=str, default="auto", choices=DEVICE_CHOICES, help="compute device")
    serve_p.set_defaults(func=cmd_serve)

    # --- download ---
    dl_p = subparsers.add_parser("download", help="download SigMorphon/UniMorph data")
    dl_p.add_argument("--lang", type=str, default="all", help="comma-separated languages or 'all'")
    dl_p.add_argument("--out-dir", type=str, default="data/collections", dest="out_dir",
                       help="output directory for downloaded data")
    dl_p.add_argument("--merge", action="store_true", help="merge train files into one")
    dl_p.set_defaults(func=cmd_download)

    # --- modules ---
    mod_p = subparsers.add_parser("modules", help="list registered modules")
    mod_p.set_defaults(func=cmd_modules)

    # --- init-config ---
    init_p = subparsers.add_parser("init-config", help="generate TOML config template")
    init_p.add_argument("--preset", type=str, default=None, choices=["small", "medium", "large"],
                         help="base preset for config")
    init_p.add_argument("--out", type=str, default="config.toml", help="output path for config file")
    init_p.set_defaults(func=cmd_init_config)

    parsed = parser.parse_args(argv)
    parsed.func(parsed)


if __name__ == "__main__":
    main()
