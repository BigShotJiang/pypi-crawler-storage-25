from morphoformer.cli import main

main()
