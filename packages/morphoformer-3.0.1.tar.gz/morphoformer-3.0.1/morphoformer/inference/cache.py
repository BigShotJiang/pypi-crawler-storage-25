"""KV cache for autoregressive token generation."""

from __future__ import annotations

from dataclasses import dataclass, field

import torch


@dataclass
class KVCache:
    """Self-attention caches grow each step; cross-attention caches are fixed after the first pass."""
    self_caches: list[tuple[torch.Tensor, torch.Tensor] | None] = field(default_factory=list)
    cross_caches: list[tuple[torch.Tensor, torch.Tensor] | None] = field(default_factory=list)

    @classmethod
    def empty(cls, num_layers: int) -> KVCache:
        return cls(
            self_caches=[None] * num_layers,
            cross_caches=[None] * num_layers,
        )

    def update(
        self,
        new_self: list[tuple[torch.Tensor, torch.Tensor]],
        new_cross: list[tuple[torch.Tensor, torch.Tensor]],
    ) -> None:
        self.self_caches = list(new_self)
        self.cross_caches = list(new_cross)
