"""Greedy decoding with KV cache: encoder runs once, decoder runs token-by-token."""

from __future__ import annotations

import torch

from chartoken import CharVocab, FeatureVocab, SOS, EOS
from morphoformer.model.transformer import MorphFormer
from morphoformer.inference.cache import KVCache


@torch.no_grad()
def greedy_decode(
    model: MorphFormer,
    char_vocab: CharVocab,
    feature_vocab: FeatureVocab,
    lemma: str,
    tags: list[str],
    lang_id: int,
    *,
    device: torch.device,
    max_len: int,
    max_out: int,
    max_features: int = 12,
) -> str:
    model.eval()

    source = char_vocab.encode(lemma, max_len=max_len, device=device).unsqueeze(0)
    lang_ids = torch.tensor([lang_id], dtype=torch.long, device=device)
    feat_ids, feat_mask = feature_vocab.encode_tensor(
        tags, max_features=max_features, device=device,
    )
    feat_ids = feat_ids.unsqueeze(0)
    feat_mask = feat_mask.unsqueeze(0)

    memory, source_padding_mask = model.encode(source, lang_ids, feat_ids, feat_mask)
    lang_embed = model.lang_embedding(lang_ids)

    cross_attn_mask = (
        MorphFormer._pad_to_attn_mask(source_padding_mask)
        if source_padding_mask.any() else None
    )

    cache = KVCache.empty(model.decoder.num_layers)
    decoder_input = torch.full((1, 1), SOS, dtype=torch.long, device=device)
    output_ids: list[int] = []

    for step in range(max_out):
        hidden = model.char_embedding(decoder_input) * model.embed_scale
        hidden = hidden + lang_embed.unsqueeze(1)

        total_len = step + 1
        rope_cos, rope_sin = model.rope(total_len, device)
        if step > 0:
            rope_cos = rope_cos[-1:, :]
            rope_sin = rope_sin[-1:, :]

        decoded, new_self, new_cross = model.decoder.forward_cached(
            hidden, memory, rope_cos, rope_sin, lang_embed,
            cache.self_caches, cache.cross_caches,
            self_attn_mask=None,
            cross_attn_mask=cross_attn_mask,
        )
        cache.update(new_self, new_cross)

        logits = model.output_projection(decoded[:, -1, :])
        next_token_id = int(logits.argmax(dim=-1).item())

        if next_token_id == EOS:
            break
        output_ids.append(next_token_id)
        decoder_input = torch.tensor([[next_token_id]], dtype=torch.long, device=device)

    return char_vocab.decode(output_ids)
