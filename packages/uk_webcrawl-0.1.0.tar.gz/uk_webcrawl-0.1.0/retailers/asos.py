import requests

from WebCrawl.retailers.base import Category, RequestSpec, RetailerPlugin

NAV_URL = "https://www.asos.com/api/fashion/navigation/v2/tree/navigation?country=GB&keyStoreDataversion=qx71qrg-45&lang=en-GB"
SEARCH_URL = "https://www.asos.com/api/product/search/v2/categories/{category_id}"


class AsosPlugin(RetailerPlugin):
    name = "asos"
    display_name = "ASOS"

    def get_headers(self) -> dict:
        return {
            "accept": "application/json, text/plain, */*",
            "accept-language": "en-GB,en;q=0.9,en-US;q=0.8",
            "asos-c-name": "^@asosteam/asos-web-site-chrome-publisher",
            "asos-c-plat": "web",
            "asos-c-ver": "13.0.0-254-bbb04a66",
            "asos-cid": "b69a22fb-2b8d-4ec1-bb2f-8deb12c7e459",
            "dnt": "1",
            "referer": "https://www.asos.com/women/",
            "sec-ch-ua": '"Chromium";v="146", "Not-A.Brand";v="24", "Microsoft Edge";v="146"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0",
        }

    def get_categories(self, session: requests.Session) -> list[Category]:
        resp = session.get(NAV_URL, timeout=15)
        resp.raise_for_status()
        tree = resp.json()

        seen: set[int] = set()
        categories: list[Category] = []

        def walk(nodes: list[dict], parent: str = "") -> None:
            for node in nodes:
                title = node.get("content", {}).get("title", "")
                link = node.get("link") or {}
                cat_id = link.get("categoryId")
                if cat_id and cat_id not in seen:
                    seen.add(cat_id)
                    categories.append(
                        Category(
                            id=str(cat_id),
                            name=title,
                            parent=parent,
                        )
                    )
                walk(node.get("children", []), parent=title or parent)

        walk(tree)
        return categories

    def build_request(self, category: Category, page_size: int, offset: int) -> RequestSpec:
        return RequestSpec(
            method="GET",
            url=SEARCH_URL.format(category_id=category.id),
            params={
                "store": "COM",
                "lang": "en-GB",
                "currency": "GBP",
                "country": "GB",
                "limit": page_size,
                "offset": offset,
            },
        )

    def parse_response(self, data: dict, category: Category) -> tuple[list[dict], int]:
        products = data.get("products", [])
        total = data.get("itemCount", 0)
        return products, total

    def get_page_size(self) -> int:
        return 200
