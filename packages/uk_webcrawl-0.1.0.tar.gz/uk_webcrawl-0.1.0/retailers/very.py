from WebCrawl.retailers.base import Category, RequestSpec, RetailerPlugin

HOMEPAGE = "https://www.very.co.uk/"
API_URL = "https://www.very.co.uk/api/product-discovery-browse/browse/group_id/{group_id}"

CATEGORY_SLUGS = [
    ("womens-dresses", "Women - Dresses"),
    ("womens-tops", "Women - Tops"),
    ("womens-trousers-leggings", "Women - Trousers"),
    ("womens-jeans", "Women - Jeans"),
    ("womens-coats-jackets", "Women - Coats & Jackets"),
    ("womens-knitwear", "Women - Knitwear"),
    ("womens-skirts", "Women - Skirts"),
    ("womens-shorts", "Women - Shorts"),
    ("womens-jumpsuits-playsuits", "Women - Jumpsuits"),
    ("womens-swimwear", "Women - Swimwear"),
    ("womens-lingerie", "Women - Lingerie"),
    ("womens-nightwear", "Women - Nightwear"),
    ("womens-sportswear", "Women - Sportswear"),
    ("womens-shoes", "Women - Shoes"),
    ("womens-accessories", "Women - Accessories"),
    ("womens-bags", "Women - Bags"),
    ("mens-t-shirts-vests", "Men - T-Shirts"),
    ("mens-shirts", "Men - Shirts"),
    ("mens-trousers", "Men - Trousers"),
    ("mens-jeans", "Men - Jeans"),
    ("mens-coats-jackets", "Men - Coats & Jackets"),
    ("mens-knitwear", "Men - Knitwear"),
    ("mens-shoes", "Men - Shoes"),
    ("mens-sportswear", "Men - Sportswear"),
    ("kids-girls-clothing", "Kids - Girls"),
    ("kids-boys-clothing", "Kids - Boys"),
    ("home-furniture", "Home - Furniture"),
    ("electricals-laptops", "Electricals - Laptops"),
]


class VeryPlugin(RetailerPlugin):
    name = "very"
    display_name = "Very"

    def get_headers(self) -> dict:
        return {
            "accept": "application/json, text/plain, */*",
            "referer": "https://www.very.co.uk/",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "x-brand": "very",
        }

    @property
    def needs_chrome_tls(self) -> bool:
        return True

    def get_categories(self, session) -> list[Category]:
        api_headers = dict(session.headers)
        session.headers.update(
            {
                "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "sec-fetch-dest": "document",
                "sec-fetch-mode": "navigate",
                "sec-fetch-site": "none",
                "sec-fetch-user": "?1",
            }
        )
        session.get(HOMEPAGE, timeout=15)
        session.headers = api_headers
        return [
            Category(id=slug, name=name, parent=name.split(" - ")[0])
            for slug, name in CATEGORY_SLUGS
        ]

    def before_category(self, session, category: Category) -> None:
        """Re-warm Akamai cookies before each category."""
        api_headers = dict(session.headers)
        session.headers.update(
            {
                "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "sec-fetch-dest": "document",
                "sec-fetch-mode": "navigate",
                "sec-fetch-site": "none",
                "sec-fetch-user": "?1",
            }
        )
        session.get(HOMEPAGE, timeout=15)
        session.headers = api_headers

    def build_request(self, category: Category, page_size: int, offset: int) -> RequestSpec:
        page = (offset // page_size) + 1
        return RequestSpec(
            method="GET",
            url=API_URL.format(group_id=category.id),
            params={
                "num_results_per_page": page_size,
                "page": page,
            },
        )

    def parse_response(self, data: dict, category: Category) -> tuple[list[dict], int]:
        response = data.get("response", {})
        products = response.get("product_list", [])
        total = response.get("meta", {}).get("num_results", 0)
        return products, total

    def get_page_size(self) -> int:
        return 96
