import json
import re

from WebCrawl.retailers.base import Category, RequestSpec, RetailerPlugin

BASE_URL = "https://www.johnlewis.com"

CATEGORY_PATHS = [
    ("women/womens-dresses/c600001506", "Women - Dresses"),
    ("women/womens-tops-t-shirts/c600001658", "Women - Tops"),
    ("women/womens-coats-jackets/c50000234", "Women - Coats & Jackets"),
    ("women/womens-knitwear/c50000233", "Women - Knitwear"),
    ("women/womens-jeans/c50000236", "Women - Jeans"),
    ("women/womens-trousers-leggings/c50000237", "Women - Trousers"),
    ("women/womens-skirts/c50000235", "Women - Skirts"),
    ("women/womens-jumpsuits-playsuits/c600001510", "Women - Jumpsuits"),
    ("women/womens-swimwear-beachwear/c50000242", "Women - Swimwear"),
    ("women/womens-lingerie-underwear/c50000246", "Women - Lingerie"),
    ("women/womens-nightwear/c50000247", "Women - Nightwear"),
    ("women/womens-sportswear/c50000243", "Women - Sportswear"),
    ("women/womens-shoes/c50000249", "Women - Shoes"),
    ("women/womens-accessories/c50000250", "Women - Accessories"),
    ("women/womens-bags-handbags/c50000262", "Women - Bags"),
    ("men/mens-shirts/c50000209", "Men - Shirts"),
    ("men/mens-t-shirts/c600001547", "Men - T-Shirts"),
    ("men/mens-trousers/c50000213", "Men - Trousers"),
    ("men/mens-jeans/c50000212", "Men - Jeans"),
    ("men/mens-knitwear/c50000210", "Men - Knitwear"),
    ("men/mens-coats-jackets/c50000207", "Men - Coats & Jackets"),
    ("men/mens-suits/c50000214", "Men - Suits"),
    ("men/mens-shorts/c50000211", "Men - Shorts"),
    ("men/mens-shoes/c50000222", "Men - Shoes"),
    ("men/mens-sportswear/c50000216", "Men - Sportswear"),
    ("men/mens-accessories/c50000223", "Men - Accessories"),
    ("electricals/computing/laptops/c50000362", "Electricals - Laptops"),
    ("home-garden/home-furnishings/c50000488", "Home - Furnishings"),
    ("beauty/c50000002", "Beauty"),
]


class JohnLewisPlugin(RetailerPlugin):
    name = "john_lewis"
    display_name = "John Lewis"

    def get_headers(self) -> dict:
        return {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-GB,en;q=0.9",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0",
        }

    @property
    def needs_chrome_tls(self) -> bool:
        return True

    def get_categories(self, session) -> list[Category]:
        session.get(f"{BASE_URL}/", timeout=15)
        return [
            Category(id=path, name=name, parent=name.split(" - ")[0])
            for path, name in CATEGORY_PATHS
        ]

    def build_request(self, category: Category, page_size: int, offset: int) -> RequestSpec:
        page = (offset // page_size) + 1
        url = f"{BASE_URL}/{category.id}"
        params = {}
        if page > 1:
            params["page"] = page
        return RequestSpec(method="GET", url=url, params=params)

    @property
    def response_is_html(self) -> bool:
        return True

    def parse_response(self, data: dict, category: Category) -> tuple[list[dict], int]:
        raise NotImplementedError("John Lewis uses HTML parsing")

    def parse_html(self, html: str, category: Category) -> tuple[list[dict], int]:
        m = re.search(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>', html, re.DOTALL)
        if not m:
            return [], 0

        nd = json.loads(m.group(1))
        pld = nd.get("props", {}).get("pageProps", {}).get("productListingData", {})

        products = pld.get("products", [])
        total_results = pld.get("results", 0)

        return products, total_results

    def get_page_size(self) -> int:
        return 27
