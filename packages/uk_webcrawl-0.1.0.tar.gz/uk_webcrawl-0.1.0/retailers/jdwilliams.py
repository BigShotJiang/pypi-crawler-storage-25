from WebCrawl.retailers.base import Category, RequestSpec, RetailerPlugin

HOMEPAGE = "https://www.jdwilliams.co.uk/"
API_URL = "https://www.jdwilliams.co.uk/api/shop/search"

CATEGORY_PATHS = [
    ("/shop/c/womens", "Women"),
    ("/shop/c/womens/dresses", "Women - Dresses"),
    ("/shop/c/womens/tops-t-shirts", "Women - Tops"),
    ("/shop/c/womens/trousers-shorts", "Women - Trousers"),
    ("/shop/c/womens/jeans", "Women - Jeans"),
    ("/shop/c/womens/blouses-shirts", "Women - Blouses"),
    ("/shop/c/womens/knitwear", "Women - Knitwear"),
    ("/shop/c/womens/coats-jackets", "Women - Coats & Jackets"),
    ("/shop/c/womens/skirts", "Women - Skirts"),
    ("/shop/c/womens/jumpsuits", "Women - Jumpsuits"),
    ("/shop/c/womens/swimwear", "Women - Swimwear"),
    ("/shop/c/womens/nightwear", "Women - Nightwear"),
    ("/shop/c/lingerie", "Lingerie"),
    ("/shop/c/footwear", "Footwear"),
    ("/shop/c/mens", "Men"),
    ("/shop/c/home", "Home"),
    ("/shop/c/beauty", "Beauty"),
    ("/shop/c/electricals", "Electricals"),
]


class JDWilliamsPlugin(RetailerPlugin):
    name = "jdwilliams"
    display_name = "JD Williams"

    def get_headers(self) -> dict:
        return {
            "accept": "*/*",
            "referer": "https://www.jdwilliams.co.uk/",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "same-origin",
            "sec-fetch-site": "same-origin",
        }

    @property
    def needs_chrome_tls(self) -> bool:
        return True

    def get_categories(self, session) -> list[Category]:
        api_headers = dict(session.headers)
        session.headers.update(
            {
                "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "sec-fetch-dest": "document",
                "sec-fetch-mode": "navigate",
                "sec-fetch-site": "none",
                "sec-fetch-user": "?1",
            }
        )
        session.get(HOMEPAGE, timeout=15)
        session.headers = api_headers
        return [
            Category(id=path, name=name, parent=name.split(" - ")[0])
            for path, name in CATEGORY_PATHS
        ]

    def before_category(self, session, category: Category) -> None:
        """Re-warm Akamai cookies before each category to prevent session expiry."""
        api_headers = dict(session.headers)
        session.headers.update(
            {
                "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "sec-fetch-dest": "document",
                "sec-fetch-mode": "navigate",
                "sec-fetch-site": "none",
                "sec-fetch-user": "?1",
            }
        )
        session.get(HOMEPAGE, timeout=15)
        session.headers = api_headers

    def build_request(self, category: Category, page_size: int, offset: int) -> RequestSpec:
        page = (offset // page_size) + 1
        path = category.id
        if page > 1:
            path = f"{category.id}/page-{page}"
        return RequestSpec(
            method="GET",
            url=API_URL,
            params={
                "currentRelativeUrl": path,
                "referrerFullUrl": "https://www.jdwilliams.co.uk" + category.id,
            },
        )

    def parse_response(self, data: dict, category: Category) -> tuple[list[dict], int]:
        products = data.get("products", [])
        total = data.get("productCount", 0)
        return products, total

    def get_page_size(self) -> int:
        return 48
