import urllib.parse

from WebCrawl.retailers.base import Category, RequestSpec, RetailerPlugin

HOMEPAGE = "https://www.primark.com/en-gb/"
API_URL = "https://api001-arh.primark.com/bff-cae-green"
SHA256_HASH = "3cd7900849277a5c5a81004be10d0a0a073b05fd2200c8b6c52aa3b20d86c744"

CATEGORIES = [
    ("women/clothing", "Women - Clothing"),
    ("women/dresses", "Women - Dresses"),
    ("women/tops", "Women - Tops"),
    ("women/trousers", "Women - Trousers"),
    ("women/jeans", "Women - Jeans"),
    ("women/skirts", "Women - Skirts"),
    ("women/knitwear", "Women - Knitwear"),
    ("women/coats-and-jackets", "Women - Coats & Jackets"),
    ("women/shorts", "Women - Shorts"),
    ("women/swimwear", "Women - Swimwear"),
    ("women/lingerie", "Women - Lingerie"),
    ("women/nightwear", "Women - Nightwear"),
    ("women/activewear", "Women - Activewear"),
    ("women/shoes", "Women - Shoes"),
    ("women/accessories", "Women - Accessories"),
    ("men/clothing", "Men - Clothing"),
    ("men/t-shirts", "Men - T-Shirts"),
    ("men/shirts", "Men - Shirts"),
    ("men/trousers", "Men - Trousers"),
    ("men/jeans", "Men - Jeans"),
    ("men/hoodies-and-sweatshirts", "Men - Hoodies"),
    ("men/shorts", "Men - Shorts"),
    ("men/coats-and-jackets", "Men - Coats & Jackets"),
    ("men/shoes", "Men - Shoes"),
    ("kids/girls", "Kids - Girls"),
    ("kids/boys", "Kids - Boys"),
]


class PrimarkPlugin(RetailerPlugin):
    name = "primark"
    display_name = "Primark"

    @property
    def needs_chrome_tls(self) -> bool:
        return True

    def get_headers(self) -> dict:
        return {
            "accept": "*/*",
            "content-type": "application/json",
            "origin": "https://www.primark.com",
            "referer": "https://www.primark.com/",
        }

    def get_categories(self, session) -> list[Category]:
        api_headers = dict(session.headers)
        session.headers.update(
            {
                "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "sec-fetch-dest": "document",
                "sec-fetch-mode": "navigate",
                "sec-fetch-site": "none",
                "sec-fetch-user": "?1",
            }
        )
        session.get(HOMEPAGE, timeout=15)
        session.headers = api_headers
        return [
            Category(id=slug, name=name, parent=name.split(" - ")[0]) for slug, name in CATEGORIES
        ]

    def before_category(self, session, category: Category) -> None:
        """Re-warm cookies before each category."""
        api_headers = dict(session.headers)
        session.headers.update(
            {
                "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "sec-fetch-dest": "document",
                "sec-fetch-mode": "navigate",
                "sec-fetch-site": "none",
                "sec-fetch-user": "?1",
            }
        )
        session.get(HOMEPAGE, timeout=15)
        session.headers = api_headers

    def build_request(self, category: Category, page_size: int, offset: int) -> RequestSpec:
        q_value = category.id.replace("/", "%2F")
        variables = (
            f'{{"q":"{q_value}","efq":null,"start":{offset},"rows":{page_size},'
            f'"locale":"en-gb","categorySlug":"{category.id}","fq":null,"sort":"",'
            f'"brUid2":"dummy","brRefUrl":"https://www.primark.com/en-gb/c/{category.id}"}}'
        )
        extensions = f'{{"persistedQuery":{{"version":1,"sha256Hash":"{SHA256_HASH}"}}}}'

        query = urllib.parse.urlencode(
            {
                "operationName": "getPlpProducts",
                "variables": variables,
                "extensions": extensions,
            }
        )
        return RequestSpec(
            method="GET",
            url=f"{API_URL}?{query}",
        )

    def parse_response(self, data: dict, category: Category) -> tuple[list[dict], int]:
        nav = data.get("data", {}).get("categoryNavItem")
        if not nav:
            return [], 0
        pd = nav.get("props", {}).get("productsData", {})
        products = pd.get("products", [])
        total = pd.get("numFound", 0)
        if not products:
            response = pd.get("response", {})
            products = response.get("docs", [])
            total = response.get("numFound", 0)
        return products, total

    def get_page_size(self) -> int:
        return 48
