from abc import ABC, abstractmethod
from dataclasses import dataclass

import requests


@dataclass
class Category:
    id: str
    name: str
    parent: str = ""


@dataclass
class RequestSpec:
    """Describes an HTTP request. Supports both GET and POST (for GraphQL retailers)."""

    method: str
    url: str
    json_body: dict | None = None
    params: dict | None = None


class RetailerPlugin(ABC):
    """Base class every retailer must implement."""

    name: str = ""
    display_name: str = ""

    @abstractmethod
    def get_headers(self) -> dict:
        """Return HTTP headers for this retailer's API."""

    @abstractmethod
    def get_categories(self, session: requests.Session) -> list[Category]:
        """Fetch and return all scrapeable categories."""

    @abstractmethod
    def build_request(self, category: Category, page_size: int, offset: int) -> RequestSpec:
        """Build the request for one page of results."""

    @abstractmethod
    def parse_response(self, data: dict, category: Category) -> tuple[list[dict], int]:
        """Parse API response. Returns (list_of_raw_products, total_item_count)."""

    def get_page_size(self) -> int:
        """Override to set a retailer-specific max page size. 0 = use config default."""
        return 0

    @property
    def response_is_html(self) -> bool:
        """Return True if the API returns HTML instead of JSON (e.g. M&S __NEXT_DATA__)."""
        return False

    @property
    def needs_chrome_tls(self) -> bool:
        """Return True to use the Rust chrome-fetch binary for Chrome TLS fingerprint."""
        return False

    def parse_html(self, html: str, category: Category) -> tuple[list[dict], int]:
        """Parse raw HTML response. Only called when response_is_html is True."""
        raise NotImplementedError

    def before_category(self, session, category: Category) -> None:  # noqa: B027
        """Called before scraping each category. Use for session refresh/warmup."""
