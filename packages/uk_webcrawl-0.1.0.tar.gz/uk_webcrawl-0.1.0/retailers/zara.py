import requests

from WebCrawl.retailers.base import Category, RequestSpec, RetailerPlugin

CATEGORIES_URL = "https://www.zara.com/uk/en/categories?ajax=true"
PRODUCTS_URL = "https://www.zara.com/uk/en/category/{category_id}/products?ajax=true"


class ZaraPlugin(RetailerPlugin):
    name = "zara"
    display_name = "Zara"

    def get_headers(self) -> dict:
        return {
            "Accept": "application/json",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0",
        }

    def get_categories(self, session: requests.Session) -> list[Category]:
        resp = session.get(CATEGORIES_URL, timeout=15)
        resp.raise_for_status()
        data = resp.json()

        categories: list[Category] = []
        seen: set[int] = set()

        def walk(nodes: list[dict], parent: str = "") -> None:
            for node in nodes:
                cat_id = node.get("id")
                name = node.get("name", "").strip()
                seo = node.get("seo", {})
                section = node.get("sectionName", "")

                if cat_id and cat_id not in seen and seo and not seo.get("irrelevant"):
                    seen.add(cat_id)
                    categories.append(
                        Category(
                            id=str(cat_id),
                            name=f"{section} - {name}" if section and name else (name or section),
                            parent=parent,
                        )
                    )

                walk(node.get("subcategories", []), parent=name or parent)

        walk(data.get("categories", []))
        return categories

    def build_request(self, category: Category, page_size: int, offset: int) -> RequestSpec:
        return RequestSpec(
            method="GET",
            url=PRODUCTS_URL.format(category_id=category.id),
        )

    def parse_response(self, data: dict, category: Category) -> tuple[list[dict], int]:
        products: list[dict] = []
        for group in data.get("productGroups", []):
            for element in group.get("elements", []):
                for cc in element.get("commercialComponents", []):
                    if cc.get("type") == "Product":
                        products.append(cc)

        return products, len(products)

    def get_page_size(self) -> int:
        return 10000
