import json
import re

import requests

from WebCrawl.retailers.base import Category, RequestSpec, RetailerPlugin

BASE_URL = "https://www.marksandspencer.com"

CATEGORY_PATHS = [
    ("l/women/dresses", "Women - Dresses"),
    ("l/women/tops", "Women - Tops"),
    ("l/women/trousers-leggings", "Women - Trousers & Leggings"),
    ("l/women/jeans", "Women - Jeans"),
    ("l/women/skirts", "Women - Skirts"),
    ("l/women/knitwear", "Women - Knitwear"),
    ("l/women/coats-jackets", "Women - Coats & Jackets"),
    ("l/women/jumpsuits", "Women - Jumpsuits"),
    ("l/women/shorts", "Women - Shorts"),
    ("l/women/swimwear-beachwear", "Women - Swimwear"),
    ("l/women/lingerie", "Women - Lingerie"),
    ("l/women/nightwear", "Women - Nightwear"),
    ("l/women/sportswear", "Women - Sportswear"),
    ("l/women/shoes-boots", "Women - Shoes"),
    ("l/women/accessories", "Women - Accessories"),
    ("l/women/bags-accessories", "Women - Bags"),
    ("l/men/shirts", "Men - Shirts"),
    ("l/men/trousers", "Men - Trousers"),
    ("l/men/jeans", "Men - Jeans"),
    ("l/men/suits", "Men - Suits"),
    ("l/men/knitwear", "Men - Knitwear"),
    ("l/men/coats-jackets", "Men - Coats & Jackets"),
    ("l/men/t-shirts-polos", "Men - T-Shirts"),
    ("l/men/shorts", "Men - Shorts"),
    ("l/men/shoes-boots", "Men - Shoes"),
    ("l/men/sportswear", "Men - Sportswear"),
    ("l/men/underwear-socks", "Men - Underwear"),
    ("l/men/nightwear", "Men - Nightwear"),
    ("l/kids/girls", "Kids - Girls"),
    ("l/kids/boys", "Kids - Boys"),
    ("l/home", "Home"),
    ("l/beauty", "Beauty"),
]


class MarksAndSpencerPlugin(RetailerPlugin):
    name = "marks_and_spencer"
    display_name = "M&S"

    def get_headers(self) -> dict:
        return {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-GB,en;q=0.9",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0",
        }

    def get_categories(self, session: requests.Session) -> list[Category]:
        return [
            Category(id=path, name=name, parent=path.split("/")[1] if "/" in path else "")
            for path, name in CATEGORY_PATHS
        ]

    def build_request(self, category: Category, page_size: int, offset: int) -> RequestSpec:
        page = (offset // page_size) + 1
        url = f"{BASE_URL}/{category.id}"
        params = {}
        if page > 1:
            params["page"] = page
        return RequestSpec(method="GET", url=url, params=params)

    @property
    def response_is_html(self) -> bool:
        return True

    def parse_response(self, data: dict, category: Category) -> tuple[list[dict], int]:
        raise NotImplementedError("M&S uses HTML parsing")

    def parse_html(self, html: str, category: Category) -> tuple[list[dict], int]:
        """Parse __NEXT_DATA__ from M&S HTML response."""
        m = re.search(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>', html, re.DOTALL)
        if not m:
            return [], 0

        nd = json.loads(m.group(1))
        pp = nd.get("props", {}).get("pageProps", {})
        fed = pp.get("serverSideGqlResponseFed", {})
        results = fed.get("productPageData", {}).get("search", {}).get("results", {})

        products = results.get("products", [])
        total = results.get("totalItems", 0)

        return products, total

    def get_page_size(self) -> int:
        return 48
