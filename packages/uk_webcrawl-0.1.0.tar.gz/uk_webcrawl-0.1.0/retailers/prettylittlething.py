import requests

from WebCrawl.retailers.base import Category, RequestSpec, RetailerPlugin

ALGOLIA_URL = "https://pbl6wqh9vl-dsn.algolia.net/1/indexes/*/queries"
ALGOLIA_APP_ID = "PBL6WQH9VL"
ALGOLIA_API_KEY = "e04aa870d44f183562de099096c4a04f"
INDEX_NAME = "prettylittlething-dbz-prod"

TOP_LEVEL_SLUGS = [
    "womens-new-in",
    "womens-dresses",
    "womens-tops",
    "womens-bottoms",
    "womens-co-ords",
    "womens-coats-jackets",
    "womens-jeans",
    "womens-knitwear",
    "womens-skirts",
    "womens-trousers",
    "womens-shorts",
    "womens-playsuits-jumpsuits",
    "womens-hoodies-sweatshirts",
    "womens-activewear",
    "womens-swimwear",
    "womens-lingerie",
    "womens-nightwear",
    "womens-loungewear",
    "womens-denim",
    "womens-shoes",
    "womens-accessories",
    "womens-jewellery",
    "womens-petite",
    "womens-plus-size",
    "womens-tall",
    "womens-maternity",
    "womens-occasion",
    "womens-partywear",
    "womens-sale",
    "womens-beachwear",
    "womens-suits",
    "womens-shape",
    "womens-holiday",
    "womens-race-day",
    "womens-wedding",
    "womens-festival",
]


class PrettyLittleThingPlugin(RetailerPlugin):
    name = "prettylittlething"
    display_name = "PLT"

    def get_headers(self) -> dict:
        return {
            "content-type": "application/json",
            "origin": "https://www.prettylittlething.com",
            "referer": "https://www.prettylittlething.com/",
            "x-algolia-api-key": ALGOLIA_API_KEY,
            "x-algolia-application-id": ALGOLIA_APP_ID,
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0",
        }

    def get_categories(self, session: requests.Session) -> list[Category]:
        body = {
            "requests": [
                {
                    "indexName": INDEX_NAME,
                    "params": "hitsPerPage=0&page=0&facets=%5B%22categorySlugs%22%5D&maxValuesPerFacet=1000",
                }
            ]
        }
        resp = session.post(
            ALGOLIA_URL,
            params={"x-algolia-agent": "Algolia for JavaScript (4.23.3)"},
            json=body,
            timeout=15,
        )
        resp.raise_for_status()
        result = resp.json()["results"][0]
        all_slugs = result.get("facets", {}).get("categorySlugs", {})

        categories: list[Category] = []
        seen: set[str] = set()
        for slug in TOP_LEVEL_SLUGS:
            if slug in all_slugs and slug not in seen:
                seen.add(slug)
                name = slug.replace("-", " ").replace("womens ", "Women - ").title()
                categories.append(Category(id=slug, name=name, parent="Women"))

        return categories

    def build_request(self, category: Category, page_size: int, offset: int) -> RequestSpec:
        page = offset // page_size
        params_str = (
            f"facetFilters=%5B%22categorySlugs%3A{category.id}%22%5D"
            f"&hitsPerPage={page_size}"
            f"&page={page}"
        )
        return RequestSpec(
            method="POST",
            url=ALGOLIA_URL,
            params={"x-algolia-agent": "Algolia for JavaScript (4.23.3)"},
            json_body={
                "requests": [
                    {
                        "indexName": INDEX_NAME,
                        "params": params_str,
                    }
                ]
            },
        )

    def parse_response(self, data: dict, category: Category) -> tuple[list[dict], int]:
        result = data.get("results", [{}])[0]
        products = result.get("hits", [])
        total = result.get("nbHits", 0)
        return products, total

    def get_page_size(self) -> int:
        return 1000
