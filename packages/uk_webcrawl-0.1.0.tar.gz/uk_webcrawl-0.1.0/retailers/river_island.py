import requests

from WebCrawl.retailers.base import Category, RequestSpec, RetailerPlugin

GRAPHQL_URL = "https://api-v2.riverisland.com/graphql"
SHA256_HASH = "f019cee3e1d99efbaec7743e347843b23c3979b10c3ebdc3e505eb2ed4258fdc"

CATEGORY_PATHS = [
    ("women", "Women"),
    ("women/dresses", "Women - Dresses"),
    ("women/tops", "Women - Tops"),
    ("women/jeans", "Women - Jeans"),
    ("women/skirts", "Women - Skirts"),
    ("women/trousers", "Women - Trousers"),
    ("women/knitwear", "Women - Knitwear"),
    ("women/shirts-blouses", "Women - Shirts & Blouses"),
    ("women/shorts", "Women - Shorts"),
    ("women/jumpsuits-playsuits", "Women - Jumpsuits & Playsuits"),
    ("women/swimwear-beachwear", "Women - Swimwear"),
    ("women/activewear", "Women - Activewear"),
    ("women/lingerie-nightwear", "Women - Lingerie"),
    ("women/accessories", "Women - Accessories"),
    ("women/bags-purses", "Women - Bags"),
    ("women/jewellery", "Women - Jewellery"),
    ("women/new-in", "Women - New In"),
    ("women/sale", "Women - Sale"),
    ("men", "Men"),
    ("men/shirts", "Men - Shirts"),
    ("men/jeans", "Men - Jeans"),
    ("men/trousers-chinos", "Men - Trousers"),
    ("men/knitwear", "Men - Knitwear"),
    ("men/hoodies-sweatshirts", "Men - Hoodies"),
    ("men/shorts", "Men - Shorts"),
    ("men/swimwear", "Men - Swimwear"),
    ("men/accessories", "Men - Accessories"),
    ("men/new-in", "Men - New In"),
    ("men/sale", "Men - Sale"),
    ("girls", "Girls"),
    ("boys", "Boys"),
]


class RiverIslandPlugin(RetailerPlugin):
    name = "river_island"
    display_name = "River Island"

    def get_headers(self) -> dict:
        return {
            "Content-Type": "application/json",
            "Origin": "https://www.riverisland.com",
            "Referer": "https://www.riverisland.com/",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0",
        }

    def get_categories(self, session: requests.Session) -> list[Category]:
        return [
            Category(id=path, name=name, parent=path.split("/")[0]) for path, name in CATEGORY_PATHS
        ]

    def build_request(self, category: Category, page_size: int, offset: int) -> RequestSpec:
        page = (offset // page_size) + 1
        return RequestSpec(
            method="POST",
            url=GRAPHQL_URL,
            json_body={
                "operationName": "ProductsAndFacets",
                "variables": {
                    "getFacets": False,
                    "isBrowser": True,
                    "keyword": "",
                    "path": category.id,
                    "page": page,
                    "pageSize": page_size,
                    "refinementsQuery": "",
                    "sort": "",
                    "isSearch": False,
                    "host": "www.riverisland.com",
                    "countryCode": "GB",
                    "currencyCode": "GBP",
                    "searchRuleId": "",
                    "searchSegmentId": "",
                    "subRuleId": "",
                    "subRuleType": "",
                    "utcEmbargoDate": "",
                    "utmCampaign": None,
                    "utmMedium": None,
                    "clusterId": None,
                },
                "extensions": {
                    "persistedQuery": {
                        "version": 1,
                        "sha256Hash": SHA256_HASH,
                    }
                },
            },
        )

    def parse_response(self, data: dict, category: Category) -> tuple[list[dict], int]:
        paf = data.get("data", {}).get("productsAndFacets", {})
        products = paf.get("listProducts", [])
        total = paf.get("totalCount", 0)
        return products, total

    def get_page_size(self) -> int:
        return 200
