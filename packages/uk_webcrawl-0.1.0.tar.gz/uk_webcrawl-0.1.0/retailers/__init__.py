from WebCrawl.retailers.asos import AsosPlugin
from WebCrawl.retailers.base import RetailerPlugin
from WebCrawl.retailers.hm import HMPlugin
from WebCrawl.retailers.jdwilliams import JDWilliamsPlugin
from WebCrawl.retailers.john_lewis import JohnLewisPlugin
from WebCrawl.retailers.marks_and_spencer import MarksAndSpencerPlugin
from WebCrawl.retailers.prettylittlething import PrettyLittleThingPlugin
from WebCrawl.retailers.primark import PrimarkPlugin
from WebCrawl.retailers.river_island import RiverIslandPlugin
from WebCrawl.retailers.very import VeryPlugin
from WebCrawl.retailers.zara import ZaraPlugin

REGISTRY: dict[str, type[RetailerPlugin]] = {
    "asos": AsosPlugin,
    "very": VeryPlugin,
    "jdwilliams": JDWilliamsPlugin,
    "marks_and_spencer": MarksAndSpencerPlugin,
    "john_lewis": JohnLewisPlugin,
    "prettylittlething": PrettyLittleThingPlugin,
    "zara": ZaraPlugin,
    "river_island": RiverIslandPlugin,
    "hm": HMPlugin,
    "primark": PrimarkPlugin,
}


def get_retailer(name: str) -> RetailerPlugin:
    cls = REGISTRY.get(name)
    if cls is None:
        available = ", ".join(sorted(REGISTRY.keys()))
        raise ValueError(f"Unknown retailer '{name}'. Available: {available}")
    return cls()


def list_retailers() -> list[str]:
    return sorted(REGISTRY.keys())
