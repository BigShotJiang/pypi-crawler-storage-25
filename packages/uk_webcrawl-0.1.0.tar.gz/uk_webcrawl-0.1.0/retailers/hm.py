import requests

from WebCrawl.retailers.base import Category, RequestSpec, RetailerPlugin

API_URL = "https://api.hm.com/search-services/v1/en_gb/listing/resultpage"

CATEGORIES = [
    ("ladies_dresses", "/ladies/shop-by-product/dresses", "Women - Dresses"),
    ("ladies_tops", "/ladies/shop-by-product/tops", "Women - Tops"),
    ("ladies_trousers", "/ladies/shop-by-product/trousers", "Women - Trousers"),
    ("ladies_jeans", "/ladies/shop-by-product/jeans", "Women - Jeans"),
    ("ladies_skirts", "/ladies/shop-by-product/skirts", "Women - Skirts"),
    ("ladies_knitwear", "/ladies/shop-by-product/knitwear", "Women - Knitwear"),
    ("ladies_jacketscoats", "/ladies/shop-by-product/jackets-and-coats", "Women - Coats & Jackets"),
    ("ladies_shorts", "/ladies/shop-by-product/shorts", "Women - Shorts"),
    ("ladies_swimwear", "/ladies/shop-by-product/swimwear", "Women - Swimwear"),
    ("ladies_lingerie", "/ladies/shop-by-product/lingerie", "Women - Lingerie"),
    ("ladies_sportswear", "/ladies/shop-by-product/sportswear", "Women - Sportswear"),
    ("ladies_shoes", "/ladies/shop-by-product/shoes", "Women - Shoes"),
    ("ladies_accessories", "/ladies/shop-by-product/accessories", "Women - Accessories"),
    ("men_tshirts", "/men/shop-by-product/t-shirts-and-tanks", "Men - T-Shirts"),
    ("men_shirts", "/men/shop-by-product/shirts", "Men - Shirts"),
    ("men_trousers", "/men/shop-by-product/trousers", "Men - Trousers"),
    ("men_jeans", "/men/shop-by-product/jeans", "Men - Jeans"),
    ("men_jacketscoats", "/men/shop-by-product/jackets-and-coats", "Men - Coats & Jackets"),
    ("men_hoodies", "/men/shop-by-product/hoodies-and-sweatshirts", "Men - Hoodies"),
    ("men_shorts", "/men/shop-by-product/shorts", "Men - Shorts"),
    ("men_shoes", "/men/shop-by-product/shoes", "Men - Shoes"),
    ("men_sportswear", "/men/shop-by-product/sportswear", "Men - Sportswear"),
    ("men_underwear", "/men/shop-by-product/underwear", "Men - Underwear"),
]


class HMPlugin(RetailerPlugin):
    name = "hm"
    display_name = "H&M"

    def get_headers(self) -> dict:
        return {
            "accept": "application/json",
            "origin": "https://www2.hm.com",
            "referer": "https://www2.hm.com/",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0",
        }

    def get_categories(self, session: requests.Session) -> list[Category]:
        return [
            Category(id=cat_id, name=name, parent=name.split(" - ")[0])
            for cat_id, _, name in CATEGORIES
        ]

    def build_request(self, category: Category, page_size: int, offset: int) -> RequestSpec:
        page = (offset // page_size) + 1
        page_id = ""
        for cat_id, pid, _ in CATEGORIES:
            if cat_id == category.id:
                page_id = pid
                break

        return RequestSpec(
            method="GET",
            url=API_URL,
            params={
                "pageSource": "PLP",
                "page": page,
                "sort": "RELEVANCE",
                "pageId": page_id,
                "page-size": page_size,
                "categoryId": category.id,
                "touchPoint": "TABLET",
                "skipStockCheck": "false",
            },
        )

    def parse_response(self, data: dict, category: Category) -> tuple[list[dict], int]:
        products = data.get("plpList", {}).get("productList", [])
        pagination = data.get("pagination", {})
        total_pages = pagination.get("totalPages", 0)
        page_size = len(products)
        total = total_pages * page_size if total_pages and page_size else len(products)
        return products, total

    def get_page_size(self) -> int:
        return 72
