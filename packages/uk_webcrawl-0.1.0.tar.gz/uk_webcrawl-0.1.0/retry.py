import random
import time

import requests


class ScrapeError(Exception):
    pass


def fetch_with_retry(
    session,
    method: str,
    url: str,
    *,
    params: dict | None = None,
    json_body: dict | None = None,
    timeout: int = 30,
    max_retries: int = 3,
    backoff_factor: float = 1.5,
    retry_on: tuple[int, ...] = (429, 500, 502, 503, 504),
):
    """Fetch with exponential backoff and jitter. Respects Retry-After on 429."""
    last_error: Exception | None = None

    for attempt in range(max_retries + 1):
        try:
            if method.upper() == "POST":
                resp = session.post(url, json=json_body, params=params, timeout=timeout)
            else:
                resp = session.get(url, params=params, timeout=timeout)

            if resp.status_code == 200:
                return resp

            if resp.status_code in retry_on and attempt < max_retries:
                wait = _get_wait(resp, attempt, backoff_factor)
                time.sleep(wait)
                continue

            resp.raise_for_status()

        except (requests.RequestException, ConnectionError, OSError) as e:
            last_error = e
            if attempt < max_retries:
                wait = backoff_factor * (2**attempt) + random.uniform(0, 1)
                time.sleep(wait)
                continue

    raise ScrapeError(f"Failed after {max_retries + 1} attempts: {url}") from last_error


def _get_wait(resp, attempt: int, backoff_factor: float) -> float:
    """Calculate wait time, respecting Retry-After header if present."""
    retry_after = resp.headers.get("Retry-After")
    if retry_after:
        try:
            return float(retry_after) + random.uniform(0, 1)
        except ValueError:
            pass
    return backoff_factor * (2**attempt) + random.uniform(0, 1)


def jitter(min_s: float, max_s: float) -> None:
    time.sleep(random.uniform(min_s, max_s))
