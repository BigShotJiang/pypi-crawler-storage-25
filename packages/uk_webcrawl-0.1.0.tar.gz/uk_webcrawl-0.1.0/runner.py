from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date
from pathlib import Path

from WebCrawl.config import CrawlerConfig
from WebCrawl.engine import RetailerStats, ScrapeEngine
from WebCrawl.resume import ResumeState
from WebCrawl.retailers import get_retailer
from WebCrawl.writers import JsonlWriter

RETAILERS = [
    "asos",
    "very",
    "jdwilliams",
    "marks_and_spencer",
    "john_lewis",
    "prettylittlething",
    "zara",
    "river_island",
    "hm",
    "primark",
]

DEFAULT_CONFIG_PATH = Path(__file__).parent / "config.yaml"


def _scrape_one(name: str, config: CrawlerConfig, out_dir: Path, today: str) -> RetailerStats:
    plugin = get_retailer(name)
    retailer_cfg = config.get_retailer_config(name)
    out_path = out_dir / f"{name}_{today}.jsonl"
    state_path = out_dir / f"{name}.state.json"

    writer = JsonlWriter(out_path)
    state = ResumeState.load(state_path)
    stats = RetailerStats(
        retailer_name=plugin.display_name,
        out_path=str(out_path),
        start_time=time.time(),
    )
    engine = ScrapeEngine(plugin, retailer_cfg, writer, state, stats)
    engine.run()
    return stats


def run_all(
    retailers: list[str] | None = None,
    config_path: str | Path | None = None,
    output_dir: str | Path = "output",
    max_workers: int | None = None,
) -> None:
    """Run the scrape pipeline for the given retailers in parallel.

    Args:
        retailers: list of registry keys to scrape; defaults to all 10 (RETAILERS).
        config_path: path to a YAML config; defaults to the bundled WebCrawl/config.yaml.
        output_dir: where JSONL output and resume state live; created if missing.
        max_workers: thread pool size; defaults to one worker per retailer.
    """
    retailers = retailers if retailers is not None else RETAILERS
    config_path = Path(config_path) if config_path else DEFAULT_CONFIG_PATH
    config = CrawlerConfig.load(config_path)

    out_dir = Path(output_dir)
    out_dir.mkdir(exist_ok=True)
    today = date.today().isoformat()

    enabled = [r for r in retailers if config.get_retailer_config(r).enabled]
    print(f"Starting {len(enabled)} retailers: {', '.join(enabled)}")

    workers = max_workers or len(enabled)
    start = time.time()

    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(_scrape_one, name, config, out_dir, today): name for name in enabled}
        for fut in as_completed(futures):
            name = futures[fut]
            try:
                stats = fut.result()
                print(f"[done] {name}: {stats.products_written:,} products, {stats.errors} errors")
            except Exception as e:
                print(f"[fail] {name}: {e}")

    print(f"\nAll retailers finished in {time.time() - start:.0f}s")
