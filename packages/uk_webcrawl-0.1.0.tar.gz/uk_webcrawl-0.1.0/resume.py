from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path


class ResumeState:
    """Tracks scrape progress so a killed run can resume."""

    def __init__(self, path: Path):
        self._path = path
        self.started_at: str = datetime.now().isoformat()
        self.completed_categories: set[str] = set()
        self.current_category: str | None = None
        self.current_offset: int = 0
        self.total_products_written: int = 0

    @classmethod
    def load(cls, path: str | Path) -> ResumeState:
        path = Path(path)
        state = cls(path)
        if path.exists():
            try:
                raw = json.loads(path.read_text(encoding="utf-8"))
                state.started_at = raw.get("started_at", state.started_at)
                state.completed_categories = set(raw.get("completed_categories", []))
                state.current_category = raw.get("current_category")
                state.current_offset = raw.get("current_offset", 0)
                state.total_products_written = raw.get("total_products_written", 0)
            except (json.JSONDecodeError, KeyError):
                pass
        return state

    def should_skip(self, category_id: str) -> bool:
        return category_id in self.completed_categories

    def get_resume_offset(self, category_id: str) -> int:
        if self.current_category == category_id:
            return self.current_offset
        return 0

    def set_progress(self, category_id: str, offset: int, products_written: int) -> None:
        self.current_category = category_id
        self.current_offset = offset
        self.total_products_written = products_written
        self.save()

    def mark_category_done(self, category_id: str) -> None:
        self.completed_categories.add(category_id)
        self.current_category = None
        self.current_offset = 0
        self.save()

    def save(self) -> None:
        data = {
            "started_at": self.started_at,
            "completed_categories": sorted(self.completed_categories),
            "current_category": self.current_category,
            "current_offset": self.current_offset,
            "total_products_written": self.total_products_written,
        }
        self._path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self._path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
        tmp.replace(self._path)

    def cleanup(self) -> None:
        """Remove the state file on clean completion."""
        if self._path.exists():
            self._path.unlink()
