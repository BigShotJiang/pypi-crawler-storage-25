"""Python wrapper for the chrome-fetch Rust binary.

Provides a Session-like interface that uses the Rust binary (BoringSSL / Chrome
TLS fingerprint) for HTTP requests.
"""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path
from typing import Any
from urllib.parse import urlencode

_BINARY_NAMES = [
    "chrome-fetch.exe",
    "chrome-fetch",
]
_SEARCH_PATHS = [
    Path(__file__).parent / "rust" / "target" / "release",
    Path(__file__).parent / "rust" / "target" / "debug",
    Path.cwd() / "WebCrawl" / "rust" / "target" / "release",
    Path.cwd() / "WebCrawl" / "rust" / "target" / "debug",
    Path.cwd() / "crawler" / "rust" / "target" / "release",
    Path.cwd() / "crawler" / "rust" / "target" / "debug",
]


def _find_binary() -> str | None:
    """Find the chrome-fetch binary."""
    for search_dir in _SEARCH_PATHS:
        for name in _BINARY_NAMES:
            path = search_dir / name
            if path.exists():
                return str(path)
    return shutil.which("chrome-fetch")


class Response:
    """Minimal response object matching requests.Response interface."""

    def __init__(self, data: dict):
        self.status_code: int = data.get("status", 0)
        self.headers: dict[str, str] = data.get("headers", {})
        self.text: str = data.get("body", "")
        self.url: str = data.get("url", "")
        self.cookies: dict[str, str] = data.get("cookies", {})
        self._error: str | None = data.get("error")

    def json(self) -> Any:
        return json.loads(self.text)

    @property
    def ok(self) -> bool:
        return 200 <= self.status_code < 400

    def raise_for_status(self) -> None:
        if self._error:
            raise ConnectionError(self._error)
        if not self.ok:
            raise ConnectionError(f"HTTP {self.status_code}")


class ChromeSession:
    """HTTP session using the chrome-fetch Rust binary for Chrome TLS fingerprint."""

    def __init__(self):
        self._binary = _find_binary()
        self.headers: dict[str, str] = {}
        self.cookies: dict[str, str] = {}

    @property
    def available(self) -> bool:
        return self._binary is not None

    def _call(
        self,
        method: str,
        url: str,
        *,
        params: dict | None = None,
        json_body: dict | None = None,
        timeout: int = 30,
    ) -> Response:
        if not self._binary:
            raise RuntimeError(
                "chrome-fetch binary not found. Build it with:\n"
                "  cd crawler/rust && cargo build --release"
            )

        if params:
            sep = "&" if "?" in url else "?"
            url = url + sep + urlencode(params)

        request_data = {
            "url": url,
            "method": method.upper(),
            "headers": self.headers,
            "cookies": self.cookies,
            "body": json.dumps(json_body) if json_body else None,
            "follow_redirects": True,
        }

        if json_body and "Content-Type" not in self.headers:
            request_data["headers"]["Content-Type"] = "application/json"

        result = subprocess.run(
            [self._binary],
            input=json.dumps(request_data),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout + 10,
        )

        if result.returncode != 0:
            return Response(
                {
                    "status": 0,
                    "error": f"chrome-fetch error: {result.stderr[:500]}",
                }
            )

        try:
            data = json.loads(result.stdout)
        except json.JSONDecodeError:
            return Response(
                {
                    "status": 0,
                    "error": f"Invalid output: {result.stdout[:200]}",
                }
            )

        self.cookies.update(data.get("cookies", {}))

        return Response(data)

    def get(self, url: str, *, params: dict | None = None, timeout: int = 30) -> Response:
        return self._call("GET", url, params=params, timeout=timeout)

    def post(
        self,
        url: str,
        *,
        json: dict | None = None,
        params: dict | None = None,
        timeout: int = 30,
    ) -> Response:
        return self._call("POST", url, params=params, json_body=json, timeout=timeout)
