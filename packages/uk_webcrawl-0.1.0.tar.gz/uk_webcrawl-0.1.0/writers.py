import json
from pathlib import Path


class JsonlWriter:
    """Streaming JSONL writer that flushes periodically."""

    def __init__(self, path: str | Path, flush_every: int = 50):
        self._path = Path(path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._file = self._path.open("a", encoding="utf-8")
        self._flush_every = flush_every
        self._count = 0
        self._since_flush = 0

    def write(self, record: dict) -> None:
        self._file.write(json.dumps(record) + "\n")
        self._count += 1
        self._since_flush += 1
        if self._since_flush >= self._flush_every:
            self._file.flush()
            self._since_flush = 0

    @property
    def count(self) -> int:
        return self._count

    @property
    def path(self) -> Path:
        return self._path

    def file_size_mb(self) -> float:
        try:
            return self._path.stat().st_size / 1024 / 1024
        except OSError:
            return 0.0

    def close(self) -> None:
        if not self._file.closed:
            self._file.flush()
            self._file.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
