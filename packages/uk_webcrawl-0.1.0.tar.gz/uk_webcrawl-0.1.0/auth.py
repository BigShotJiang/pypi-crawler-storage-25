"""Parse curl commands and store session cookies/headers for retailers."""

from __future__ import annotations

import json
import re
from pathlib import Path

AUTH_DIR = Path("output/.auth")


def parse_curl(curl_str: str) -> dict:
    """Parse a curl command string into headers and cookies."""
    curl_str = curl_str.replace("^\n", " ").replace("^\r\n", " ")
    curl_str = re.sub(r"\^(.)", r"\1", curl_str)
    curl_str = curl_str.replace("\\\n", " ")

    url_match = re.search(r'curl\s+["\']?(https?://[^\s"\']+)', curl_str)
    url = url_match.group(1) if url_match else ""

    headers: dict[str, str] = {}
    for m in re.finditer(r'-H\s+["\']([^"\']+)["\']', curl_str):
        h = m.group(1)
        if ":" in h:
            key, val = h.split(":", 1)
            headers[key.strip()] = val.strip()

    cookies: dict[str, str] = {}
    cookie_match = re.search(r'-b\s+["\']([^"\']+)["\']', curl_str)
    cookie_str = (
        cookie_match.group(1) if cookie_match else headers.pop("Cookie", headers.pop("cookie", ""))
    )

    if cookie_str:
        for pair in cookie_str.split(";"):
            pair = pair.strip()
            if "=" in pair:
                k, v = pair.split("=", 1)
                cookies[k.strip()] = v.strip()

    return {
        "url": url,
        "headers": headers,
        "cookies": cookies,
    }


def save_auth(retailer_name: str, auth_data: dict) -> Path:
    """Save parsed auth data for a retailer."""
    AUTH_DIR.mkdir(parents=True, exist_ok=True)
    path = AUTH_DIR / f"{retailer_name}.json"
    path.write_text(json.dumps(auth_data, indent=2), encoding="utf-8")
    return path


def load_auth(retailer_name: str) -> dict | None:
    """Load stored auth data for a retailer, if it exists."""
    path = AUTH_DIR / f"{retailer_name}.json"
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return None


def list_auth() -> list[str]:
    """List retailers that have stored auth."""
    if not AUTH_DIR.exists():
        return []
    return [p.stem for p in AUTH_DIR.glob("*.json")]


def apply_auth_to_session(session, retailer_name: str) -> bool:
    """Apply stored cookies/headers to a requests.Session. Returns True if auth was found."""
    auth = load_auth(retailer_name)
    if not auth:
        return False

    session.headers.update(auth.get("headers", {}))
    for name, value in auth.get("cookies", {}).items():
        session.cookies.set(name, value)

    return True
