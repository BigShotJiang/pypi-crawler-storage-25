from __future__ import annotations

from pathlib import Path

import yaml
from pydantic import BaseModel


class RetailerConfig(BaseModel):
    enabled: bool = True
    page_size: int = 200
    jitter_min: float = 1.0
    jitter_max: float = 3.5
    request_timeout: int = 30
    max_retries: int = 3
    backoff_factor: float = 1.5


class OutputConfig(BaseModel):
    directory: str = "output"
    filename_template: str = "{retailer}_{date}.jsonl"


class CrawlerConfig(BaseModel):
    output: OutputConfig = OutputConfig()
    default_retailer: RetailerConfig = RetailerConfig()
    retailers: dict[str, RetailerConfig] = {}

    def get_retailer_config(self, name: str) -> RetailerConfig:
        """Merge default config with retailer-specific overrides."""
        base = self.default_retailer.model_dump()
        overrides = self.retailers.get(name)
        if overrides:
            base.update(overrides.model_dump(exclude_unset=True))
        return RetailerConfig(**base)

    @classmethod
    def load(cls, path: str | Path = "config.yaml") -> CrawlerConfig:
        p = Path(path)
        if not p.exists():
            return cls()
        with p.open(encoding="utf-8") as f:
            raw = yaml.safe_load(f) or {}
        raw.pop("ui", None)
        return cls(**raw)
