from __future__ import annotations

from dataclasses import dataclass, field

import requests

from WebCrawl.auth import apply_auth_to_session
from WebCrawl.config import RetailerConfig
from WebCrawl.resume import ResumeState
from WebCrawl.retailers.base import RetailerPlugin
from WebCrawl.retry import ScrapeError, fetch_with_retry, jitter
from WebCrawl.writers import JsonlWriter


@dataclass
class RetailerStats:
    """Mutable stats object shared between engine thread and UI thread."""

    retailer_name: str = ""
    categories_total: int = 0
    categories_done: int = 0
    products_total: int = 0
    products_written: int = 0
    requests_made: int = 0
    errors: int = 0
    current_category: str = ""
    last_error: str = ""
    recent: list[str] = field(default_factory=list)
    out_path: str = ""
    start_time: float = 0.0
    finished: bool = False


class ScrapeEngine:
    """Scrape loop for a single retailer. Designed to run in its own thread."""

    def __init__(
        self,
        plugin: RetailerPlugin,
        config: RetailerConfig,
        writer: JsonlWriter,
        state: ResumeState,
        stats: RetailerStats,
    ):
        self.plugin = plugin
        self.config = config
        self.writer = writer
        self.state = state
        self.stats = stats
        if plugin.needs_chrome_tls:
            from WebCrawl.chrome_fetch import ChromeSession

            self.session = ChromeSession()
            self.session.headers.update(plugin.get_headers())
        else:
            self.session = requests.Session()
            self.session.headers.update(plugin.get_headers())
            apply_auth_to_session(self.session, plugin.name)

    def _get_product_id(self, product: dict) -> str | None:
        """Extract a unique ID from a product dict for deduplication."""
        for key in ("id", "productId", "product_id", "pid", "objectID", "item_id", "productCode"):
            val = product.get(key)
            if val:
                return str(val)
        return None

    def run(self) -> None:
        self._seen_ids: set[str] = set()
        try:
            categories = self.plugin.get_categories(self.session)
            self.stats.categories_total = len(categories)

            for cat in categories:
                if self.state.should_skip(cat.id):
                    self.stats.categories_done += 1
                    continue

                self.stats.current_category = f"{cat.name} (id: {cat.id})"

                try:
                    self.plugin.before_category(self.session, cat)
                    n = self._scrape_category(cat)
                    self.stats.products_total += n
                    self.stats.recent.append(f"[green]+[/green] {cat.name}: {n:,} products")
                except ScrapeError as e:
                    self.stats.errors += 1
                    self.stats.last_error = str(e)
                    self.stats.recent.append(f"[red]x[/red] {cat.name}: {e}")
                except Exception as e:
                    self.stats.errors += 1
                    self.stats.last_error = str(e)
                    self.stats.recent.append(f"[red]x[/red] {cat.name}: {e}")

                self.state.mark_category_done(cat.id)
                self.stats.categories_done += 1
                jitter(self.config.jitter_min, self.config.jitter_max)

        finally:
            self.stats.finished = True
            self.stats.current_category = ""
            self.writer.close()
            self.state.cleanup()

    def _scrape_category(self, cat) -> int:
        page_size = self.plugin.get_page_size() or self.config.page_size
        offset = self.state.get_resume_offset(cat.id)
        written = 0

        while True:
            req = self.plugin.build_request(cat, page_size, offset)
            resp = fetch_with_retry(
                self.session,
                req.method,
                req.url,
                params=req.params,
                json_body=req.json_body,
                timeout=self.config.request_timeout,
                max_retries=self.config.max_retries,
                backoff_factor=self.config.backoff_factor,
            )
            self.stats.requests_made += 1

            if self.plugin.response_is_html:
                products, total = self.plugin.parse_html(resp.text, cat)
            else:
                products, total = self.plugin.parse_response(resp.json(), cat)

            if not products:
                break

            for product in products:
                pid = self._get_product_id(product)
                if pid and pid in self._seen_ids:
                    continue
                if pid:
                    self._seen_ids.add(pid)
                self.writer.write(
                    {
                        "category_id": cat.id,
                        "category_name": cat.name,
                        "product": product,
                    }
                )
                written += 1
                self.stats.products_written += 1

            self.state.set_progress(cat.id, offset + page_size, self.writer.count)
            offset += page_size

            if offset >= total:
                break

            jitter(self.config.jitter_min, self.config.jitter_max)

        return written
