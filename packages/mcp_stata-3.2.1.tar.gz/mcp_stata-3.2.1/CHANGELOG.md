# CHANGELOG

<!-- version list -->

## v3.2.1 (2026-05-09)

### Bug Fixes

- Update plugin marketplace install
  ([`3b02fae`](https://github.com/tmonk/mcp-stata/commit/3b02faed12a3defd54943f28b660351940cb04df))

### Documentation

- Enhance background task handling instructions in stata-analyst and stata-run documentation
  ([`9420c71`](https://github.com/tmonk/mcp-stata/commit/9420c71996a78d8e1fd814387ae200a57ca70443))


## v3.2.0 (2026-05-09)

### Bug Fixes

- Consistent anon user ID in logs
  ([`762d042`](https://github.com/tmonk/mcp-stata/commit/762d042e1ffa5940ab365457d2162e7f087423b9))

- Update statest to include parallel running, CI/CD Integration, failure analysis
  ([`334b294`](https://github.com/tmonk/mcp-stata/commit/334b2945f1a18942d0f73b0ef2976c7eb9aae87f))

- Versions
  ([`1b89305`](https://github.com/tmonk/mcp-stata/commit/1b89305d858c782c6a85a8de51bbddd9d16dcc93))

- **tests**: Resolve path regressions from reorganization and clean up statest internal tests
  ([`7147258`](https://github.com/tmonk/mcp-stata/commit/714725838c561512998c985285ec7a01eefa1314))

### Features

- Introduce statest testing framework v0.1 with initial assertions and test runner
  ([`c25424a`](https://github.com/tmonk/mcp-stata/commit/c25424a09828624e44bd55ddea5b3955d1809180))

### Performance Improvements

- **statest**: Added benchmark history
  ([`7e7c3a7`](https://github.com/tmonk/mcp-stata/commit/7e7c3a74e746bf03cdf68c2a1000e531067e3cfe))

- **statest**: Implement session pooling and structured results for optimization
  ([`6d9f85d`](https://github.com/tmonk/mcp-stata/commit/6d9f85d31d7b22ab47b7b6247318351641c3b0e2))

- **statest**: Implement session pooling and structured results for optimization
  ([`15256fb`](https://github.com/tmonk/mcp-stata/commit/15256fb96d564e3d850574eb2482f370aa9aa09c))

### Refactoring

- Consolidate skills and remove redundant documentation files
  ([`5aef410`](https://github.com/tmonk/mcp-stata/commit/5aef4102506c81c4c3afdfd4f77262d0f6644da2))

- Improve installer failure telemetry by using byte-based log tailing, ensuring log flushing, and
  fixing JSON escaping bugs.
  ([`d2aad07`](https://github.com/tmonk/mcp-stata/commit/d2aad076a4b98a04ceb910e3d8e762759c6aaad8))

- Migrate skill definitions to plugin directory and update catalog generator and tests
  ([`3e17ea4`](https://github.com/tmonk/mcp-stata/commit/3e17ea4a56d72f6d398ceb1a3704a758a2966d07))


## v3.1.6 (2026-05-08)


## v3.1.5 (2026-05-08)

### Bug Fixes

- Implement standard telemetry username for CI environments and improve dashboard filter interaction
  controls
  ([`7c1032d`](https://github.com/tmonk/mcp-stata/commit/7c1032d46308bf8533fbc78b9689c530bceae1a2))


## v3.1.4 (2026-05-08)

### Bug Fixes

- Install and wrangler scripts
  ([`1392ed2`](https://github.com/tmonk/mcp-stata/commit/1392ed25b23d05175af466107684331029766b3d))

- Update data schema mapping and dashboard log modal to consolidate user and machine identifiers
  ([`4212f3a`](https://github.com/tmonk/mcp-stata/commit/4212f3afa41fec8cd5257715fb398ee134a9b3eb))

### Continuous Integration

- Restrict release workflow triggers to exclude documentation and non-critical file changes
  ([`ad75bae`](https://github.com/tmonk/mcp-stata/commit/ad75baebd904c685e5496245941963664a5e9c68))


## v3.1.3 (2026-05-08)

### Bug Fixes

- Add dynamic script versioning and machine identification to telemetry data
  ([`7d36ef7`](https://github.com/tmonk/mcp-stata/commit/7d36ef75b115b684102d8ea54d35a3dc78430a83))

- Fix anonymous telemetry, help documentation, and robust retry logic to installation scripts
  ([`d5dfdc5`](https://github.com/tmonk/mcp-stata/commit/d5dfdc5bbbdc0f06025a9c4b8f908fba81cdd431))

- Remove caching
  ([`8a273fb`](https://github.com/tmonk/mcp-stata/commit/8a273fb494a80248d6df2e287174cfd11f2141c4))

- Update build pipelines, add progress suppression to installer, and extend dashboard telemetry
  schema
  ([`f79c699`](https://github.com/tmonk/mcp-stata/commit/f79c69920ffce690d63123318863b6e22f771461))


## v3.1.2 (2026-05-08)

### Documentation

- Fix PowerShell command in README for installation
  ([`fb5afbc`](https://github.com/tmonk/mcp-stata/commit/fb5afbcaf743bbecf8ef98379a423f231ec6f0b9))


## v3.1.1 (2026-05-08)

### Bug Fixes

- Add full install error logging/telemetry
  ([`bfc55ed`](https://github.com/tmonk/mcp-stata/commit/bfc55ed440bf3e800871aa9bc0306f02eb12b4d0))

- Add local proxy server for Cloudflare Analytics Engine dashboard
  ([`887355d`](https://github.com/tmonk/mcp-stata/commit/887355d66a345af6515105403364c39c4d3f11dc))

- Enhance setup_toolkit with logging and environment handling improvements
  ([`37c5c58`](https://github.com/tmonk/mcp-stata/commit/37c5c585d5df133d00036317a61e9a86724cd3a6))


## v3.1.0 (2026-05-08)

### Bug Fixes

- Add installation failure issue template and improve install script diagnostics
  ([`12c9bc1`](https://github.com/tmonk/mcp-stata/commit/12c9bc1b17ae5195104262cb4724b58b83ed2b9c))

- Add uninstall functionality, and move scripts
  ([`673b74c`](https://github.com/tmonk/mcp-stata/commit/673b74cbf851c278d55a5b22fcae0aba46b5d749))

- Remove zed and continue as supported agents
  ([`0037da9`](https://github.com/tmonk/mcp-stata/commit/0037da9b33042745c76667a1701ec695cf1d7050))

- Update docker test environment to mount repo and fix uninstall logic for symlinks
  ([`bc211e9`](https://github.com/tmonk/mcp-stata/commit/bc211e91a287f2c27a21a4a4efd33fabfeb3503d))

- Update locations/agent lists
  ([`e01d511`](https://github.com/tmonk/mcp-stata/commit/e01d51174d4c79046019236e12da6f07f74dd13c))

### Chores

- Move and sort scripts
  ([`90d5d05`](https://github.com/tmonk/mcp-stata/commit/90d5d05cb80cfb9cca2bdb8ae522791e00bb0a8b))

### Documentation

- Install readme
  ([`f614474`](https://github.com/tmonk/mcp-stata/commit/f614474469ca5974bfd590b3fe2ad16087595311))

- Update install URLs
  ([`7b16d35`](https://github.com/tmonk/mcp-stata/commit/7b16d35f70017507406a07996d3410788e940847))

### Features

- Add Cloudflare Worker for mcp-stata installer service
  ([`d9b6206`](https://github.com/tmonk/mcp-stata/commit/d9b62064281058a839e35cb648a7b04233f61700))

### Testing

- Add Alpine Linux uninstall dry-run verification to installer tests
  ([`2444156`](https://github.com/tmonk/mcp-stata/commit/2444156a84d4b5ac0ce2f89b51806be284e1bf0f))

- Add integration test for agent configuration merging and preservation on Ubuntu
  ([`528ad58`](https://github.com/tmonk/mcp-stata/commit/528ad5864b40012a0d14dac8992978304b2cbb85))

- Remove output verification assertions from linux installer tests
  ([`c95ceaf`](https://github.com/tmonk/mcp-stata/commit/c95ceafa79b9a275b48982a93eff63b4b58b760e))

- Update linux installer test suite to verify uv installation instead of dependency warnings
  ([`df2c2ca`](https://github.com/tmonk/mcp-stata/commit/df2c2ca8524f059ef309056dae6a59d0d8121a16))


## v3.0.3 (2026-05-08)

### Bug Fixes

- Add gzip as a required dependency for linux installers to support uv extraction
  ([`57873b2`](https://github.com/tmonk/mcp-stata/commit/57873b2b689e1a55438ada29dbe4330a07f4a9f4))

### Testing

- Fix installer scripts cross platform
  ([`fe1da82`](https://github.com/tmonk/mcp-stata/commit/fe1da82490f5832fc4242b096d58a426e9f315ab))


## v3.0.2 (2026-05-08)

### Bug Fixes

- Clone repo when installer run standalone
  ([`2f806dc`](https://github.com/tmonk/mcp-stata/commit/2f806dca73aad2d235a1e6956cbdfa358fdc1dfc))

- Refactor Claude install flow and restore CLI args
  ([`4b116fb`](https://github.com/tmonk/mcp-stata/commit/4b116fb651cb52e0cd10437a415a53ac4cf174e3))

- Release 3.0.1: bump manifests and update installer
  ([`b166aab`](https://github.com/tmonk/mcp-stata/commit/b166aab26c8ed0b94afb27f571c77c1733029407))

- **docs**: Add marketplaces and cross-platform installers
  ([`8ab0ba8`](https://github.com/tmonk/mcp-stata/commit/8ab0ba8e1b253831e8b393a084b72fce3f60ea7a))

- **docs**: Fix table in README
  ([`40a711a`](https://github.com/tmonk/mcp-stata/commit/40a711a50ec1a1b3f97f1b6586fa6d8b37a82fc4))

### Documentation

- README, use curl | bash for installer commands
  ([`577ab92`](https://github.com/tmonk/mcp-stata/commit/577ab92b2fd7f2613ab8fa1f286a3901e438182e))

- Use inline PowerShell install commands
  ([`a10a408`](https://github.com/tmonk/mcp-stata/commit/a10a40887d4beca8483787b806771f5fc87a204e))


## v3.0.1 (2026-05-07)

### Bug Fixes

- Refactor graph caching/emit
  ([`448fcaf`](https://github.com/tmonk/mcp-stata/commit/448fcafc7d43a3401fd76839b905e3e13d2b1a2d))


## v3.0.0 (2026-05-07)

### Bug Fixes

- Bump plugin versions to 2.6.0; tests & sync fixes
  ([`5d07080`](https://github.com/tmonk/mcp-stata/commit/5d0708038453965c3868bc38d865fb569870e434))

- Revise mcp-stata description for clarity
  ([`4a62ecf`](https://github.com/tmonk/mcp-stata/commit/4a62ecf811428cb30829784c1300923756115d22))

- Update README content for clarity
  ([`d1bc1c1`](https://github.com/tmonk/mcp-stata/commit/d1bc1c1982c216887c908db5126c290b2731fbd3))

### Documentation

- Refine README project description
  ([`1a745b5`](https://github.com/tmonk/mcp-stata/commit/1a745b513a254176a676bfa6cff55409d31ec8c2))


## v2.6.0 (2026-05-07)

### Bug Fixes

- Resolve merge conflict in server.json and update version to 2.5.1
  ([`a50b259`](https://github.com/tmonk/mcp-stata/commit/a50b25923a59a4a27e110ff412c9018633d4b3f3))


## v2.5.1 (2026-05-07)

### Bug Fixes

- Enhance README with quickstart guide
  ([`8640355`](https://github.com/tmonk/mcp-stata/commit/8640355f8790bb44fb6044c505a1b9a8d0e46f44))


## v2.5.0 (2026-05-07)

### Features

- Consolidate error fields to details, trim output
  ([`5e8b56f`](https://github.com/tmonk/mcp-stata/commit/5e8b56f4d8e1d6961a03cc1da0752d340bae9259))


## v2.4.0 (2026-05-06)

### Continuous Integration

- Use env mapping for MCP_STATA_MOCK in workflow
  ([`06f750b`](https://github.com/tmonk/mcp-stata/commit/06f750b026b4fe80ab310428807660b10f5ce01b))

### Documentation

- Update lede
  ([`5f41b5c`](https://github.com/tmonk/mcp-stata/commit/5f41b5cd97f10e96bf1ff1bc324d478c722b2e86))

### Features

- Add Stata linter, setup script, and tests
  ([`1128127`](https://github.com/tmonk/mcp-stata/commit/1128127b5ecd29e17f42019c8419f14bcf6a9c29))


## v2.3.2 (2026-05-05)


## v2.3.1 (2026-05-05)

### Bug Fixes

- Ensure consistent path normalization and encoding handling across Stata client and test utilities
  across OSs
  ([`2ae5e86`](https://github.com/tmonk/mcp-stata/commit/2ae5e86ef971b121987586533bbfaaea2903bb83))

### Continuous Integration

- Disable automated build and test triggers in GitHub Actions workflow
  ([`2420edd`](https://github.com/tmonk/mcp-stata/commit/2420edd16fb86f51e479e01ea1fc595d2645f1de))

- Update workflows, linker and cache glob
  ([`40deb97`](https://github.com/tmonk/mcp-stata/commit/40deb97ef2e4d428f2f101135839f9da4715546b))

- Use uv toolchain and add Python 3.14 to CI
  ([`e7d0f60`](https://github.com/tmonk/mcp-stata/commit/e7d0f601b375623d85f44382f2358d84858fd4c5))


## v2.3.0 (2026-05-05)

### Bug Fixes

- Prevent command execution on failed sessions and update unit test mocks to handle unawaited
  coroutines
  ([`8344512`](https://github.com/tmonk/mcp-stata/commit/834451270093445ad09d35e07a675e50172a5aeb))

- Standardize task status, improve session startup
  ([`2a413a8`](https://github.com/tmonk/mcp-stata/commit/2a413a82421f153993d0da2689ef92fcc4af44eb))

### Features

- Add error details, truncate outputs, update status
  ([`de072b3`](https://github.com/tmonk/mcp-stata/commit/de072b318754cb0a53bb841708472e0be989d16b))


## v2.2.0 (2026-05-05)

### Features

- Enable SMCL stripping by default
  ([`6cfe753`](https://github.com/tmonk/mcp-stata/commit/6cfe753cbbe3f11893b87e52cb40f3b18622303f))


## v2.1.0 (2026-05-05)

### Documentation

- Add post-2.0.0 feature summary to README
  ([`c4ffed2`](https://github.com/tmonk/mcp-stata/commit/c4ffed23c8f4602edfaab89ed0c74865090b9ccc))

- Align README and skill with full PR scope
  ([`b23198c`](https://github.com/tmonk/mcp-stata/commit/b23198cf016548463b21db615d1c4594b955e077))

- Fold post-release notes into README sections
  ([`45f2a19`](https://github.com/tmonk/mcp-stata/commit/45f2a1959330433338a84802bf900ff866f56e7b))

- Sync README with current MCP tool surface
  ([`8d6b6eb`](https://github.com/tmonk/mcp-stata/commit/8d6b6eb75ab26543192697b7d06accaf4e65c74e))

### Features

- Add session history tracking via manage_session
  ([`170418f`](https://github.com/tmonk/mcp-stata/commit/170418f185694506cb2d05f7aa096b15d718731b))

- Add structured Mata and results introspection
  ([`5e8dc86`](https://github.com/tmonk/mcp-stata/commit/5e8dc8686e6a44aab0dcd4f8102a95a49fc613e9))

- Default to plain output over SMCL
  ([`2a6b719`](https://github.com/tmonk/mcp-stata/commit/2a6b719bdb28be7aff5fd7a8de1666b1a3d52146))

### Refactoring

- Consolidate results tooling into stata_get_results
  ([`a932046`](https://github.com/tmonk/mcp-stata/commit/a932046402455ece462e08d2633e89df07fdc359))


## v2.0.0 (2026-05-05)

### Bug Fixes

- Set STATA_BIN env in e2e startup tests
  ([`d21df91`](https://github.com/tmonk/mcp-stata/commit/d21df9180d4f492f7c579fd296f175b407fd06e0))

- Updated stata svg
  ([`2bad0db`](https://github.com/tmonk/mcp-stata/commit/2bad0db7ca8e5e186d5ba71fd361a07d0d44c3e4))

### Features

- Add output cleaning, session profiles, and tasks
  ([`a709d93`](https://github.com/tmonk/mcp-stata/commit/a709d9330bb6143807605a65abdf5bafaca3295d))

- Refactor server tools and logging - redesign of all tools
  ([`9b90983`](https://github.com/tmonk/mcp-stata/commit/9b90983f9fcc11f11b3e4a5ad253343e3b2aabc7))


## v1.30.2 (2026-05-03)

### Bug Fixes

- Fix README Stata image URL
  ([`92b819e`](https://github.com/tmonk/mcp-stata/commit/92b819ec44609c2db6cfff2ab5fdf7f27495d746))


## v1.30.1 (2026-05-03)

### Bug Fixes

- Add Stata news
  ([`00ecbc2`](https://github.com/tmonk/mcp-stata/commit/00ecbc2bb268ab5566e896485d391d52cf3292db))


## v1.30.0 (2026-05-03)

### Features

- Add optional help paragraph merging
  ([`e5bbbd6`](https://github.com/tmonk/mcp-stata/commit/e5bbbd6e529e7ce9ede41fc2c888dedc35f13cd1))


## v1.29.0 (2026-05-03)


## v1.28.1 (2026-05-03)

### Bug Fixes

- Improve Stata missing detection and normalize None
  ([`42c8fdf`](https://github.com/tmonk/mcp-stata/commit/42c8fdfa20054b5e7e2cc7365dcb36f41b8a8c3f))


## v1.28.0 (2026-05-03)

### Features

- Normalize Stata missing values & add tools
  ([`f9c4d24`](https://github.com/tmonk/mcp-stata/commit/f9c4d244efa59ce957dd76ad26b5499bc5fced51))


## v1.27.0 (2026-05-03)

### Bug Fixes

- Handle Stata missing values and sorting threshold
  ([`a26bfb3`](https://github.com/tmonk/mcp-stata/commit/a26bfb3dcef42b8b04459aada7779f2ae5636815))

### Features

- Bump version
  ([`0b24345`](https://github.com/tmonk/mcp-stata/commit/0b24345b499950244ca1c661826a93efc9abc414))

### Testing

- Refine Stata test skipping and update test mocks
  ([`a2c29e7`](https://github.com/tmonk/mcp-stata/commit/a2c29e79c1642f487090d33e9254bf6a0acb3634))


## v1.26.1 (2026-03-03)

### Bug Fixes

- Escape pipe characters in synopt table output to ensure proper Markdown formatting
  ([`51bff0c`](https://github.com/tmonk/mcp-stata/commit/51bff0cdc94247a9560a4b5d89204bc59a08f6ba))

### Refactoring

- Refactor caching mechanisms in UIChannelManager to use OrderedDict for improved performance and
  memory management. Update test configurations to streamline Stata detection and ensure
  compatibility with xdist for parallel test execution. Adjust various test cases to handle Stata
  initialization more gracefully, enhancing robustness and error handling.
  ([`6c40c96`](https://github.com/tmonk/mcp-stata/commit/6c40c965990498cbb1fcdb8abb1e95fc3a438324))


## v1.26.0 (2026-02-27)

### Chores

- Update version numbers in Cargo.toml, pyproject.toml, and server.json to 1.25.1.dev4cea
  ([`5df7be9`](https://github.com/tmonk/mcp-stata/commit/5df7be98fb098ed5358cd66e8f0ce7f87190e869))

- Update version numbers in Cargo.toml, pyproject.toml, and server.json to 1.25.1.dev6520
  ([`0fb3015`](https://github.com/tmonk/mcp-stata/commit/0fb3015f97db73fd8308f834cce7e87a7910f711))

### Features

- Add help topic extraction and artifact handling in StataClient
  ([`af1aa92`](https://github.com/tmonk/mcp-stata/commit/af1aa920dc5a08658b5590f3f9da4356772a46e1))

- Emit structured help_ready notification for help panel activation
  ([`2efd06b`](https://github.com/tmonk/mcp-stata/commit/2efd06bc57f66966f464c1e7b08ca47ada1ca1d0))

- Enhance graph caching logic with robust fallback mechanisms and add integration tests
  ([`964688e`](https://github.com/tmonk/mcp-stata/commit/964688e5bb96e6917aa066928bd0f0773f3a1974))

- Enhance SMCL to Markdown conversion with comprehensive inline tag support and structured output
  ([`573dd51`](https://github.com/tmonk/mcp-stata/commit/573dd518a53dd81db2f8f2e1d1df974321cbb5cd))

- Implement a thread pool for concurrent UI HTTP server requests and add a dedicated concurrency
  test.
  ([`5359d99`](https://github.com/tmonk/mcp-stata/commit/5359d99f646e36578ea0e99e72e511c489e59681))

- Optimize data retrieval by replacing get_dataset_state calls with direct sfi.Data access
  ([`ab26cb1`](https://github.com/tmonk/mcp-stata/commit/ab26cb103677b3670763787315f8ebb799934ec0))

- Streamline help command handling and improve break signal processing
  ([`5f5280d`](https://github.com/tmonk/mcp-stata/commit/5f5280dec8831b71e92534e4c48a03b65a1d5369))


## v1.25.0 (2026-02-09)

### Bug Fixes

- Tests for startup file handling and session management without reload
  ([`6186120`](https://github.com/tmonk/mcp-stata/commit/61861201f5e723f02773c20b97907ba44a281e97))

### Features

- Add noReloadOnClear setting to control reloading of startup/profile do files
  ([`d286d3f`](https://github.com/tmonk/mcp-stata/commit/d286d3ffaec4440c54cd3f2f29b530beba85c1e8))


## v1.24.0 (2026-02-09)

### Bug Fixes

- Enhance pytest fixture handling for Stata-backed tests and improve test structure
  ([`71cf058`](https://github.com/tmonk/mcp-stata/commit/71cf0581636770c60502cca9b687c6e691fa8237))

- Remove redundant call to _install_startup_sentinel after _load_startup_do_file
  ([`9fc2fca`](https://github.com/tmonk/mcp-stata/commit/9fc2fcada850df1646baff58a0be667d1daf7c5e))

### Features

- Add MCP_STATA_NO_RELOAD_ON_CLEAR support to control program reloading after clear commands
  ([`0d88c44`](https://github.com/tmonk/mcp-stata/commit/0d88c44c227dc648a17ed3324998c7e24f2044cb))

- Add support for loading a startup .do file and corresponding tests
  ([`f7a6bfb`](https://github.com/tmonk/mcp-stata/commit/f7a6bfb617f9cc01c8b99a3bf4b0ff4fd9f184f1))

- Enhance break handling and startup .do file loading with deduplication.
  ([`3cac948`](https://github.com/tmonk/mcp-stata/commit/3cac948f4e50b12b68fdce403b2b1df7e8d9fc00))

- Implement macro handling and conditional reloading of startup files in StataClient
  ([`1452373`](https://github.com/tmonk/mcp-stata/commit/1452373625432ec8c034f33dd69455689189198a))

- Implement startup .do file loading with sysprofile.do support and deduplication - match Stata
  implementation
  ([`a8a789b`](https://github.com/tmonk/mcp-stata/commit/a8a789b1602c5ddc3f3d460f365ecc17820b428b))

### Testing

- Fix full test suite
  ([`3cac948`](https://github.com/tmonk/mcp-stata/commit/3cac948f4e50b12b68fdce403b2b1df7e8d9fc00))


## v1.23.3 (2026-02-07)

### Bug Fixes

- Increase preflight timeout to 60s and enhance diagnostic logging
  ([`cf36aab`](https://github.com/tmonk/mcp-stata/commit/cf36aabdeb08165d65c8392d2f41461d07195185))


## v1.23.2 (2026-02-01)

### Bug Fixes

- Add session inspection tool and enhance task logging with task_id
  ([`fd70ca5`](https://github.com/tmonk/mcp-stata/commit/fd70ca5834207bfd0efb1f146c2bfc448f6fb4cd))

### Testing

- Add end-to-end tests for session stability and break handling
  ([`822bb6e`](https://github.com/tmonk/mcp-stata/commit/822bb6ef0194813226e08b67b989690fb3eac9ec))


## v1.23.1 (2026-02-01)

### Bug Fixes

- Enhance task cancellation handling and add integration test for cancel_task
  ([`299bd46`](https://github.com/tmonk/mcp-stata/commit/299bd461e120c75c3534d2539fda46ce1c3cb6b7))


## v1.23.0 (2026-02-01)

### Chores

- Remove MCP badge from README
  ([`60712e4`](https://github.com/tmonk/mcp-stata/commit/60712e43586ce926599b468c30d292057d712a20))


## v1.22.2 (2026-01-31)

### Bug Fixes

- Enhance StataClient path discovery and prioritize local utilities
  ([`b658f50`](https://github.com/tmonk/mcp-stata/commit/b658f504060528287399310ca8fa483c06a0a420))

### Documentation

- Update README with Stata licensing details and clarify pystata usage
  ([`b658f50`](https://github.com/tmonk/mcp-stata/commit/b658f504060528287399310ca8fa483c06a0a420))

### Refactoring

- Remove pystata dependency from pyproject.toml
  ([`b658f50`](https://github.com/tmonk/mcp-stata/commit/b658f504060528287399310ca8fa483c06a0a420))


## v1.22.1 (2026-01-24)

### Bug Fixes

- Add pytest marker for Stata requirement in cancellation and mock protocol tests
  ([`0cbaa96`](https://github.com/tmonk/mcp-stata/commit/0cbaa96942821bb82afb8daf02abfe7688c743d1))

- Enhance testing framework and improve mock handling for Stata integration
  ([`21daa71`](https://github.com/tmonk/mcp-stata/commit/21daa71f9f475282b7771ff3a4e1e24b0f4fab31))


## v1.22.0 (2026-01-24)

### Bug Fixes

- Enhance session management and testing configuration
  ([`3ba71e7`](https://github.com/tmonk/mcp-stata/commit/3ba71e76cf2b578c0c9c542b839436f68f5dec85))

- Improve session listener management and error handling
  ([`66df105`](https://github.com/tmonk/mcp-stata/commit/66df105e75bd55d62ae9a75fae36dfbf41e8a9d5))

- Update Python version support to 3.11+ across configuration files. 3.10 is incompatible
  ([`b40244c`](https://github.com/tmonk/mcp-stata/commit/b40244cbad624296c2da94d4e1af3174f7103d1d))

### Features

- Implement session management for Stata integration - fully backwards compatible
  ([`5eeaea2`](https://github.com/tmonk/mcp-stata/commit/5eeaea2f78b034ac0a8545ce7b0e2d8980232b99))

### Testing

- Ensure async tests
  ([`04be0a0`](https://github.com/tmonk/mcp-stata/commit/04be0a02501d409f5130d791b358d6baa37ff631))


## v1.21.0 (2026-01-24)

### Bug Fixes

- Enhance graph command handling and add test for graph ready event emission
  ([`426b48f`](https://github.com/tmonk/mcp-stata/commit/426b48fd9858a7f98e91d0a60d2522cf221a001b))

- Enhance graph signature detection and improve logging in GraphCreationDetector and server
  ([`f01bedb`](https://github.com/tmonk/mcp-stata/commit/f01bedb231796503e4450bb782f4912ea38ecb5f))

- Enhance SMCL log cleaning and add regression tests for output format
  ([`67338fa`](https://github.com/tmonk/mcp-stata/commit/67338faa36a20ca0161713b71afcd66541627f05))

- Enhance SMCL output cleaning by removing additional boilerplate lines
  ([`5d973cc`](https://github.com/tmonk/mcp-stata/commit/5d973cc0ac1b8bfa8ea3b9986c11dd01a6e4ee54))

- Enhance stdout filtering and improve error handling in StataClient
  ([`933979b`](https://github.com/tmonk/mcp-stata/commit/933979bf4caf3c8fc2956b2c9ecb3f79919faae8))

- Ensure logging is fully hardened
  ([`78da711`](https://github.com/tmonk/mcp-stata/commit/78da71128e9acdae94681cb71410124dd8954c9e))

- Ensure logs get passed through
  ([`c2e1989`](https://github.com/tmonk/mcp-stata/commit/c2e1989d2a9dd43e92237011c25257bda7ebd4a7))

- Fix graph emission logic and add regression tests for graph readiness and SMCL log cleaning
  ([`1557422`](https://github.com/tmonk/mcp-stata/commit/15574229028a530b5c2de8dae356d44d49ef2f6e))

- Harden rc handling with isolation across sessions.
  ([`fbb57fe`](https://github.com/tmonk/mcp-stata/commit/fbb57fed2621af2c262d8ffdee5dd2b3b5c84e05))

- Implement graph signature caching and improve inventory retrieval in GraphCreationDetector and
  StataClient
  ([`55314f0`](https://github.com/tmonk/mcp-stata/commit/55314f0c07f8ff55196c95c3412f9f180e4209e6))

- Improve graph detection and error handling in StataClient and GraphCreationDetector
  ([`51e485a`](https://github.com/tmonk/mcp-stata/commit/51e485a302ae4f664805eb13093a96f4e6ca7332))

- Improve graph signature deduplication logic and add performance tests for user journeys
  ([`9871b4b`](https://github.com/tmonk/mcp-stata/commit/9871b4b0fc24538f921d74367e6f81de81ae3257))

- Improve SMCL log handling and enhance graph emission tests
  ([`73866ab`](https://github.com/tmonk/mcp-stata/commit/73866ab1f277c594a53de9b59fe43c82ea14f3cd))

- Optimisation of rc code gets
  ([`eb1ca1d`](https://github.com/tmonk/mcp-stata/commit/eb1ca1d638014c31b4713298ae98520e53c27ca5))

- Refactor signal handling and improve Stata mock setup in tests
  ([`88d563d`](https://github.com/tmonk/mcp-stata/commit/88d563d3e3dcb65db6d6341e3078df5e72980348))

- Refactor temp file creation to work cross-platform
  ([`70ba79c`](https://github.com/tmonk/mcp-stata/commit/70ba79c86c9489ae14b2624a859b54fedc1d8b00))

- Remove base_dir overrides to prevent log pollution in working directory
  ([`7726580`](https://github.com/tmonk/mcp-stata/commit/7726580a34ef86bf94faf83b9c3adcc6db4f79ce))

- Replace os.name checks with is_windows() for improved clarity and consistency
  ([`13b7423`](https://github.com/tmonk/mcp-stata/commit/13b7423ae357f65958237991997306ec8ace836f))

- SMCL handling and improve logging in StataClient
  ([`1c48ac5`](https://github.com/tmonk/mcp-stata/commit/1c48ac53ba350b4917442547626f281e8dcdebfe))

### Features

- Implement persistent logging and performance optimizations
  ([`d7a567a`](https://github.com/tmonk/mcp-stata/commit/d7a567a8e5e70e7f751bf6641addf9915fb6bd65))

### Testing

- Add pytest marker for Stata requirement in isolation tests
  ([`a23c7ad`](https://github.com/tmonk/mcp-stata/commit/a23c7ad9775f222c04028b997468037492469cc3))

- Add pytest marker for Stata requirement in multiple test files
  ([`d40e0b9`](https://github.com/tmonk/mcp-stata/commit/d40e0b922237baa03c492cf021d7b2a9caa2a7ba))

- Add pytest marker for Stata requirement in SMCL clamping test
  ([`0eb8672`](https://github.com/tmonk/mcp-stata/commit/0eb867213c4622150bd23806fbf0fef34b548fea))

- Add unit tests for internal SMCL cleaning and output conversion methods
  ([`9d7a3e4`](https://github.com/tmonk/mcp-stata/commit/9d7a3e4083d7a749b8a8c51646e8d0d99f44d580))

- Ensure 'invisibility'
  ([`1218918`](https://github.com/tmonk/mcp-stata/commit/1218918a844dc05612f85c8843396f11a32b9a25))


## v1.20.0 (2026-01-21)

### Bug Fixes

- Update Python version support to 3.11+ across configuration files. 3.10 is incompatible
  ([`e6026ac`](https://github.com/tmonk/mcp-stata/commit/e6026ac518767b091090047b6824e1ec89ab53f9))

### Features

- Implement session management for Stata integration - fully backwards compatible
  ([`17f4bc9`](https://github.com/tmonk/mcp-stata/commit/17f4bc9801742ebec525b6a0d8a63dd9f9928aed))


## v1.19.1 (2026-01-20)

### Bug Fixes

- Fix graph timestamp retrieval and deduplication logic in GraphCreationDetector
  ([`cdf0b47`](https://github.com/tmonk/mcp-stata/commit/cdf0b47a9a75b7a8c5278eeb3a4807fcd9ddcb78))


## v1.19.0 (2026-01-20)

### Features

- Expand Python versions supported to 3.11+
  ([`38ce3bd`](https://github.com/tmonk/mcp-stata/commit/38ce3bdb2b1bb158fce7e88d826ca398b9db8105))


## v1.18.7 (2026-01-20)


## v1.18.6 (2026-01-20)


## v1.18.5 (2026-01-20)


## v1.18.4 (2026-01-20)

### Bug Fixes

- Update release
  ([`cf745a8`](https://github.com/tmonk/mcp-stata/commit/cf745a86fb6f83efc564b46f35b7d8e8b1578e62))

### Refactoring

- Modified to exactly match python output
  ([`666d66b`](https://github.com/tmonk/mcp-stata/commit/666d66bd4e8674cee2705b0fd191c299e7b49976))

- Smcl_to_markdown and fast_scan_log functions to match Python behaviour, added unit tests.
  ([`5f04b5f`](https://github.com/tmonk/mcp-stata/commit/5f04b5fa7ef8ba70e268a9afc89bd08066b1cd6f))


## v1.18.3 (2026-01-20)


## v1.18.2 (2026-01-20)

### Bug Fixes

- Remove x86
  ([`b643a48`](https://github.com/tmonk/mcp-stata/commit/b643a4859dca5288c897758a958138176bca611d))


## v1.18.1 (2026-01-20)

### Bug Fixes

- Expand target architecture support in CI and update dependencies for compatibility
  ([`a09495a`](https://github.com/tmonk/mcp-stata/commit/a09495ae0e43ccebd57e4ea84d8cd7968a876392))

- Remove unnecessary features from numpy dependency
  ([`c81a45c`](https://github.com/tmonk/mcp-stata/commit/c81a45cffd82f4b4f8f4f2dbcb92f64a6a0edaac))


## v1.18.0 (2026-01-20)

### Features

- Refactor native sorting and logging operations, add Rust optimizations for SMCL and filtering
  ([`ea74b42`](https://github.com/tmonk/mcp-stata/commit/ea74b428687bfbad8b5a98fb553fd4942ebf36f1))


## v1.17.1 (2026-01-20)

### Bug Fixes

- Optimize sorting performance with conditional parallelization and add release profile settings
  ([`fc2c408`](https://github.com/tmonk/mcp-stata/commit/fc2c40873dcef021403315de7a3f2f986a5b6441))


## v1.17.0 (2026-01-20)

### Bug Fixes

- Fallback Polars-based sorting
  ([`3cc111d`](https://github.com/tmonk/mcp-stata/commit/3cc111d02950cb689250a403cecf2f498e82b5f5))

### Features

- Add native sorting extension using Rust and PyO3
  ([`0b5a693`](https://github.com/tmonk/mcp-stata/commit/0b5a69365955bc78cd5d95d3999d6d8771f589d4))

- Move to maturin, include in project root
  ([`f1caed9`](https://github.com/tmonk/mcp-stata/commit/f1caed9da2612c1f363deb4f23e7846710653be4))


## v1.16.8 (2026-01-20)

### Features

- Use the Rust native sorter for UI sorting with a Polars fallback, and document the decision.

### Tests

- Add unit coverage for Polars fallback sorting and update Arrow handler expectations.


## v1.16.7 (2026-01-20)

### Bug Fixes

- Update installation commands to use --refresh-package instead of --reinstall-package
  ([`15cd09f`](https://github.com/tmonk/mcp-stata/commit/15cd09f876202c05d4288b05fbc7f8e74b77c400))


## v1.16.6 (2026-01-20)

### Bug Fixes

- Update installation commands in README and run_inspector script to always reinstall latest version
  ([`f6d4417`](https://github.com/tmonk/mcp-stata/commit/f6d4417fae0033e7f6b7afb09c30381657cce45b))


## v1.16.5 (2026-01-20)

### Bug Fixes

- Release patch
  ([`a8b1d09`](https://github.com/tmonk/mcp-stata/commit/a8b1d092f2d7570775887a6b96f73f3c3e5e3772))


## v1.16.4 (2026-01-20)


## v1.16.3 (2026-01-20)

### Bug Fixes

- Improve Stata installation path detection on macOS
  ([`9c72787`](https://github.com/tmonk/mcp-stata/commit/9c72787461f0e38f778ef2bc7e387191eb6facab))


## v1.16.2 (2026-01-19)


## v1.16.1 (2026-01-19)

### Bug Fixes

- Improve graph name handling and add logging for export failures in StataClient
  ([`ffdc8f2`](https://github.com/tmonk/mcp-stata/commit/ffdc8f265e77ac70166178b6ddc78b9b4d4d11af))


## v1.16.0 (2026-01-19)

### Features

- Optimize graph signature detection and enhance command tracking in StataClient
  ([`1f28b8c`](https://github.com/tmonk/mcp-stata/commit/1f28b8c9a13541fcfad76032e820dd5d96070fe9))


## v1.15.0 (2026-01-19)

### Features

- Improve task completion notifications and background graph caching in StataClient
  ([`79b87b1`](https://github.com/tmonk/mcp-stata/commit/79b87b12fd74a5332fcd0dedac6240c0f85de51f))


## v1.14.0 (2026-01-18)

### Features

- Enhance logging and implement background task handling in MCP Stata
  ([`38e07a6`](https://github.com/tmonk/mcp-stata/commit/38e07a6e8b798e8d592c2b87e12ac559f5aca6f6))


## v1.13.0 (2026-01-18)

### Features

- **server**: Add async callback support and improve error handling
  ([`3cd0341`](https://github.com/tmonk/mcp-stata/commit/3cd03413ff642c89c36bd53651601c27666f7152))


## v1.12.2 (2026-01-16)

### Bug Fixes

- **server**: Add graph-ready notifications and streaming improvements
  ([`6968f4f`](https://github.com/tmonk/mcp-stata/commit/6968f4fabfe5fbf413888d3896b4e165f90b7955))


## v1.12.1 (2026-01-15)

### Bug Fixes

- **tools**: Deprecate polling in favor of task_done notifications
  ([`10ea881`](https://github.com/tmonk/mcp-stata/commit/10ea881dd88408d8fca8d5992980b05e508f1f0c))

### Chores

- **release**: Allow manual PyPI publishes
  ([`5c0a4ce`](https://github.com/tmonk/mcp-stata/commit/5c0a4cebb418ed59be56bd50beb95b67282584f1))

- **release**: Trigger PyPI publish
  ([`a57516e`](https://github.com/tmonk/mcp-stata/commit/a57516eac1b1c372376116847f73c13b4a5bb4b8))


## v1.12.0 (2026-01-15)

### Chores

- Sync server.json version
  ([`47990ae`](https://github.com/tmonk/mcp-stata/commit/47990aec66c82b91f364cefa7f93d53347f714e4))

- **release**: Migrate to python-semantic-release
  ([`a90acb6`](https://github.com/tmonk/mcp-stata/commit/a90acb6faca55eb744ba4113f395495dcdba6a80))

### Features

- Implement release workflow and configuration for semantic-release
  ([`8f1c7c6`](https://github.com/tmonk/mcp-stata/commit/8f1c7c618bee0f23379ef03eb9ea31835701436e))

- **release**: Update release workflow to use semantic-release version and add build command
  ([`d48150b`](https://github.com/tmonk/mcp-stata/commit/d48150b8a694181c861c64bb0703993a510c940b))

- **server**: Add logging decorators for MCP tool and resource calls
  ([`c8b7e79`](https://github.com/tmonk/mcp-stata/commit/c8b7e79b141e73b3434835ca7d1083d0a5a46254))


## v1.11.1 (2026-01-15)

### Chores

- Sync server.json version
  ([`0fa1659`](https://github.com/tmonk/mcp-stata/commit/0fa1659bd9bf2eca49651f0faffc715bf6466c51))

### Features

- **tools**: Add task completion notifications and improve background task documentation
  ([`8fcd6a3`](https://github.com/tmonk/mcp-stata/commit/8fcd6a37d65fce895d3ab61d9b4503775a0b1d4f))


## v1.11.0 (2026-01-15)

### Chores

- Sync server.json version
  ([`5904a85`](https://github.com/tmonk/mcp-stata/commit/5904a853f074319ffd950fb844d9a9598206d60a))

### Features

- **tools**: Add background task execution for long-running Stata commands and do-files
  ([`8ccf440`](https://github.com/tmonk/mcp-stata/commit/8ccf440df548e31c0724d82928067d38f8d47c8a))


## v1.10.0 (2026-01-15)

### Chores

- Sync server.json version
  ([`10e1ad0`](https://github.com/tmonk/mcp-stata/commit/10e1ad04164573f32d1035c2b28582703c465b65))

### Features

- **tools**: Add `find_in_log` tool for searching log files with context windows
  ([`c69edc9`](https://github.com/tmonk/mcp-stata/commit/c69edc9a495a14da8f9f0c46e2d0491d44cb0595))


## v1.9.1 (2026-01-12)

### Chores

- Sync server.json version
  ([`83780eb`](https://github.com/tmonk/mcp-stata/commit/83780eb3a61f73238663f1633c2dad146ed802d4))

### Refactoring

- **discovery**: Add multi-candidate discovery with version-aware sorting
  ([`3a7a58a`](https://github.com/tmonk/mcp-stata/commit/3a7a58a044b5977b2422643f8ee74a25a9989d4a))


## v1.9.0 (2026-01-06)

### Chores

- Sync server.json version
  ([`79c2a6f`](https://github.com/tmonk/mcp-stata/commit/79c2a6f05bb0b68052177f9f67ac17960cfc9b25))

### Refactoring

- **logging**: Encapsulate logging setup in a dedicated function and enhance error handling during
  Stata initialization
  ([`df8c0ab`](https://github.com/tmonk/mcp-stata/commit/df8c0ab193cf60781df6a06e9c761fa170026099))


## v1.8.2 (2025-12-29)

### Bug Fixes

- **windows**: Resolve file locking and path issues in SMCL handling
  ([`40162b7`](https://github.com/tmonk/mcp-stata/commit/40162b7e208c02b635e776e7593b80068829d485))

### Chores

- Sync server.json version
  ([`8d07403`](https://github.com/tmonk/mcp-stata/commit/8d074032d9a81b41125b999b17d142a7467ab710))

### Refactoring

- Optimize build integration tests using `uv` and session-scoped fixtures and adjust Windows
  discovery test skip logic.
  ([`1aaf904`](https://github.com/tmonk/mcp-stata/commit/1aaf9043b54084aa4d04b95d1f4f6c995833398d))

### Testing

- Add `requires_stata` marker to Linux discovery tests
  ([`6d79cb3`](https://github.com/tmonk/mcp-stata/commit/6d79cb39b4eccd1751ed257251e6133ade68f05f))


## v1.8.1 (2025-12-28)

### Chores

- Sync server.json version
  ([`622bd8e`](https://github.com/tmonk/mcp-stata/commit/622bd8e5efaa04748c1f079974dd71c8a3c003b8))

### Features

- Add end-to-end benchmarking script for Stata MCP HTTP Arrow stream and update .gitignore to
  exclude node_modules
  ([`a90a875`](https://github.com/tmonk/mcp-stata/commit/a90a875265ffd43b26f44f654fc75bb2a82f3837))

- Optimize `get_arrow_stream` with Polars for faster Arrow IPC stream generation and add a
  performance benchmarking script.
  ([`857bbd0`](https://github.com/tmonk/mcp-stata/commit/857bbd006174e1b22c1d35597fc8f0a2fc39aaa7))


## v1.8.0 (2025-12-28)

### Bug Fixes

- Update maxVars limit from 500 to 32,767 in UIChannelManager and test for consistency
  ([`72e67b4`](https://github.com/tmonk/mcp-stata/commit/72e67b4720042ef6494e396154f9d8ccc4f5b4d4))

### Chores

- Sync server.json version
  ([`085b3ea`](https://github.com/tmonk/mcp-stata/commit/085b3ea3dc69f5cc07775c94bb54e7a2f225f9dc))

### Features

- Implement Arrow IPC stream support and update related configurations and tests
  ([`17aacc1`](https://github.com/tmonk/mcp-stata/commit/17aacc165db6787a61cba493fa761019214a97aa))


## v1.7.9 (2025-12-27)

### Bug Fixes

- Update maxVars limit from 200 to 500 in README and UIChannelManager for consistency
  ([`8c36935`](https://github.com/tmonk/mcp-stata/commit/8c3693541e25777aa536454b956ae0fa0bd6b8f1))

### Chores

- Sync server.json version
  ([`b727ff1`](https://github.com/tmonk/mcp-stata/commit/b727ff196f7937a664a7b072262ff49b3ad888b2))


## v1.7.8 (2025-12-27)

### Bug Fixes

- Enhance Stata return code parsing in `stata_client.py` with more robust regex patterns and add
  comprehensive unit tests.
  ([`48251bf`](https://github.com/tmonk/mcp-stata/commit/48251bf57c5609be2fb442e27455657dd49d5937))

### Chores

- Sync server.json version
  ([`4726357`](https://github.com/tmonk/mcp-stata/commit/4726357cd78eb01cac356aac19f45589abcf9f4e))

### Refactoring

- Streamline log monitoring in StataClient by consolidating log streaming functions and ensuring
  accurate path references for SMCL logs, enhancing error handling and progress tracking during
  command execution.
  ([`b9af543`](https://github.com/tmonk/mcp-stata/commit/b9af5436d541f2ae90440a9de92ad91eb5f3bb24))


## v1.7.7 (2025-12-23)

### Chores

- Sync server.json version
  ([`6016aef`](https://github.com/tmonk/mcp-stata/commit/6016aef085f77f975d3c6c6b3b9a935d1c3daba0))

### Features

- Optimize Stata path discovery with fast checks during auto-discovery and targeted retry logic for
  user-provided paths, improve SMCL-based error extraction with named log capture and {err} tag
  parsing, and enhance logging configuration with immediate stderr flushing for MCP transport.
  ([`afa33e1`](https://github.com/tmonk/mcp-stata/commit/afa33e1d9c687c075ca5755db3fe1b45455a0517))

- Remove `_select_stata_error_message` and its tests, and populate `CommandResponse.stderr` with the
  extracted error context.
  ([`baf5a27`](https://github.com/tmonk/mcp-stata/commit/baf5a277733747ca7a24fed0a1b68b452a75e864))


## v1.7.6 (2025-12-23)

### Chores

- Sync server.json version
  ([`66cacdc`](https://github.com/tmonk/mcp-stata/commit/66cacdc9ec468c7f0956eeaac84862e6597fbd4d))


## v1.7.5 (2025-12-23)

### Chores

- Sync server.json version
  ([`ff4e34a`](https://github.com/tmonk/mcp-stata/commit/ff4e34a965de77a4a9d004ef1aeb2e8b84a27469))

### Features

- Improve Stata error message extraction by preserving SMCL tags, capturing multi-line error blocks,
  and providing broader log context.
  ([`1334217`](https://github.com/tmonk/mcp-stata/commit/1334217b3d4021e9b4b78132c3f6bbb9951553b9))


## v1.7.4 (2025-12-23)

### Chores

- Sync server.json version
  ([`e3831c2`](https://github.com/tmonk/mcp-stata/commit/e3831c20074b6e584a76b529eaf9c2d2786f5b4e))

### Features

- Refactor Stata error handling and return code retrieval, improving error message extraction from
  SMCL logs and removing redundant test files.
  ([`3f8ad91`](https://github.com/tmonk/mcp-stata/commit/3f8ad917e52766e65e2b7f7b70fccdb8c8f80bc4))


## v1.7.3 (2025-12-23)

### Chores

- Sync server.json version
  ([`642ec2b`](https://github.com/tmonk/mcp-stata/commit/642ec2b17012800a398c8c864a1578b2ed7de64b))

### Features

- Improve Stata error message parsing by prioritizing specific error keywords and preceding lines,
  adding robust log tail reading, and enhancing fallback messages.
  ([`35b75c6`](https://github.com/tmonk/mcp-stata/commit/35b75c6d5a94045f21f98080971acbd0393e3d2e))


## v1.7.2 (2025-12-22)

### Chores

- Sync server.json version
  ([`b7c8282`](https://github.com/tmonk/mcp-stata/commit/b7c8282ec61febbb2c3d23da12159298453aeb56))

### Features

- Implement robust Stata error message parsing with a new utility method and dedicated unit tests.
  ([`d41fd1a`](https://github.com/tmonk/mcp-stata/commit/d41fd1a53eb65346475198287dce0946488b68b9))


## v1.7.1 (2025-12-22)

### Chores

- Sync server.json version
  ([`00dd9b7`](https://github.com/tmonk/mcp-stata/commit/00dd9b72dcae133ff202e8223f358ac57ce19d3d))


## v1.7.0 (2025-12-22)

### Chores

- Sync server.json version
  ([`0110e5f`](https://github.com/tmonk/mcp-stata/commit/0110e5f95fb89c6992a3d9c14707b3ea390526a8))

### Features

- Add data sorting to `/v1/page` API, update capabilities, and enhance filtered view index
  management.
  ([`9fe23ec`](https://github.com/tmonk/mcp-stata/commit/9fe23ecd13b119d30eb9931c994a2ff36ef508cb))


## v1.6.9 (2025-12-22)

### Chores

- Sync server.json version
  ([`5deb486`](https://github.com/tmonk/mcp-stata/commit/5deb486244b641dafc4d3356f8634cffde07508e))


## v1.6.8 (2025-12-22)

### Chores

- Sync server.json version
  ([`2baf514`](https://github.com/tmonk/mcp-stata/commit/2baf514dcae4af163f0afb3aaa32d4805048c9ce))

### Refactoring

- Enhance request parameter validation in handle_page_request function
  ([`88cffc8`](https://github.com/tmonk/mcp-stata/commit/88cffc837c570ea7149b29511b56a3b308d28def))


## v1.6.7 (2025-12-22)

### Chores

- Sync server.json version
  ([`896bb37`](https://github.com/tmonk/mcp-stata/commit/896bb37e8bd3bf38219b99a9f568bfb80db8fb9d))

### Refactoring

- Consolidate test fixtures to use shared Stata client across test modules
  ([`de1f13d`](https://github.com/tmonk/mcp-stata/commit/de1f13d988719330ca3be99a6faa1e8e12f482e1))

- Enhance test fixtures and improve Stata discovery handling
  ([`9331b34`](https://github.com/tmonk/mcp-stata/commit/9331b34fcd4f047458860afb2d1ccfebdff569b1))

- Implement cached Stata discovery and enhance error handling
  ([`32da1ff`](https://github.com/tmonk/mcp-stata/commit/32da1ffa90fe92e33f31307b73b0546905b2f715))

### Testing

- Add pytestmark for Stata requirement in test files
  ([`ebc2461`](https://github.com/tmonk/mcp-stata/commit/ebc2461a99a5a5d2d6f2d5efbeffd33b216eb799))


## v1.6.6 (2025-12-21)

### Chores

- Sync server.json version
  ([`d4bd605`](https://github.com/tmonk/mcp-stata/commit/d4bd6055bcd433cba8fc5144cdee766203abb155))

### Refactoring

- Enhance Stata path detection and improve error handling in discovery module
  ([`52422a5`](https://github.com/tmonk/mcp-stata/commit/52422a504bacee15f63e2c527b55955a6d2314dc))


## v1.6.5 (2025-12-21)

### Chores

- Sync server.json version
  ([`6da0e5d`](https://github.com/tmonk/mcp-stata/commit/6da0e5d20e3d96cb7318b3d7526e230dae35d77b))


## v1.6.4 (2025-12-21)

### Chores

- Sync server.json version
  ([`4a3e2b6`](https://github.com/tmonk/mcp-stata/commit/4a3e2b6256be4ee1f53ab74680d5518718fc1897))


## v1.6.3 (2025-12-21)

### Chores

- Sync server.json version
  ([`1cd6280`](https://github.com/tmonk/mcp-stata/commit/1cd628030028a5aa43ffcabd6712a2116239725c))


## v1.6.2 (2025-12-21)

### Chores

- Sync server.json version
  ([`d5e33b6`](https://github.com/tmonk/mcp-stata/commit/d5e33b6e3431ba05280e4510abf1a99f092b1de4))


## v1.6.1 (2025-12-21)

### Chores

- Sync server.json version
  ([`0346d26`](https://github.com/tmonk/mcp-stata/commit/0346d266d4a4ef90aa4af913f4e87791c9b5c474))


## v1.6.0 (2025-12-20)

### Bug Fixes

- Update import statements and error handling for Stata dependencies in tests
  ([`d05eae5`](https://github.com/tmonk/mcp-stata/commit/d05eae598f1ce053160af569239da46d9a3e079c))

### Chores

- Sync server.json version
  ([`9a74c5b`](https://github.com/tmonk/mcp-stata/commit/9a74c5b768bffa1b4d1adc54ece8c99d4286a449))

### Refactoring

- Update import statements and mock dependencies in test files
  ([`487bb52`](https://github.com/tmonk/mcp-stata/commit/487bb522902ff431409acb527ff567830078517e))

### Testing

- Mark all tests as requiring Stata in graph integration and streaming cache tests
  ([`8a66e4d`](https://github.com/tmonk/mcp-stata/commit/8a66e4d284a299ff10fa43b5b105cbaa8c9a16c6))


## v1.5.1 (2025-12-19)

### Chores

- Sync server.json version
  ([`04a10bc`](https://github.com/tmonk/mcp-stata/commit/04a10bccdaff83af330055ea7269e205c081d0fc))

### Features

- Add support for cwd in run_command and run_do_file functions
  ([`18b63a9`](https://github.com/tmonk/mcp-stata/commit/18b63a940616acc556ad3085909fbddc3bb61d3b))

- Implement UI HTTP server and enhance streaming
  ([`0e3f71e`](https://github.com/tmonk/mcp-stata/commit/0e3f71e64b188a41b5578156aff0536dd876f0c3))


## v1.5.0 (2025-12-19)

### Chores

- Sync server.json version
  ([`ef4e1ae`](https://github.com/tmonk/mcp-stata/commit/ef4e1aee2a25c66dc74afd7359800c201b667010))

### Features

- Add streaming support for run_command and run_do_file functions
  ([`3c54054`](https://github.com/tmonk/mcp-stata/commit/3c54054665e0081173a251fd7b77ceec350e26e7))


## v1.4.0 (2025-12-17)

### Chores

- Sync server.json version
  ([`f8baf87`](https://github.com/tmonk/mcp-stata/commit/f8baf87c491bcefd50381269ab672db005d82f75))


## v1.4.0-alpha.1 (2025-12-17)

### Chores

- Sync server.json version
  ([`6cbbc15`](https://github.com/tmonk/mcp-stata/commit/6cbbc150ec1ecf7a072a94c5da8bae3e3d4536ec))

- Update Python version requirements and CI configurations to support Python 3.12
  ([`8f63347`](https://github.com/tmonk/mcp-stata/commit/8f63347d6d88809540628fcf5a59703b8b55be90))

### Documentation

- Add badge for test status in README
  ([`52ffca8`](https://github.com/tmonk/mcp-stata/commit/52ffca80750859997933ac0fce08d550acf0ae1a))

### Features

- Add build integration tests and CI workflow for package validation
  ([`4846b2a`](https://github.com/tmonk/mcp-stata/commit/4846b2aac242675516d18ba3c469f4bbb32ce250))

- Mark tests requiring Stata and update CI workflow for improved testing
  ([`589f0b6`](https://github.com/tmonk/mcp-stata/commit/589f0b61f1e821ba27600653d4de6ec163c7dcef))


## v1.4.0 (2025-12-17)

### Chores

- Sync server.json version
  ([`f533238`](https://github.com/tmonk/mcp-stata/commit/f533238a450ffcf8ddbe1760f0ef5b25597076ea))

### Features

- Enhance token efficiency and output handling in Stata commands
  ([`7d7e6fc`](https://github.com/tmonk/mcp-stata/commit/7d7e6fc1d603678280a1c392e94db4ce955649da))


## v1.3.3 (2025-12-17)

### Chores

- Sync server.json version
  ([`5c081d4`](https://github.com/tmonk/mcp-stata/commit/5c081d43f4df7ed28d888137a65204216789323a))


## v1.3.2 (2025-12-15)

### Chores

- Sync server.json version
  ([`638359f`](https://github.com/tmonk/mcp-stata/commit/638359fcf489b0804b5f5a1960e1daeadd2e82f8))


## v1.3.1 (2025-12-15)

### Chores

- Sync server.json version
  ([`5e65337`](https://github.com/tmonk/mcp-stata/commit/5e65337cc56e0ed5598d8af6f6310a91a23fa358))


## v1.3.0 (2025-12-15)

### Chores

- Sync server.json version
  ([`2cdde11`](https://github.com/tmonk/mcp-stata/commit/2cdde11fb0d39ff9ae5890b5ef5021c135cb1e5c))


## v1.2.3 (2025-12-15)

### Chores

- Sync server.json version
  ([`cac6ef3`](https://github.com/tmonk/mcp-stata/commit/cac6ef39c3d17fec4de368e86ecdb38a98726698))


## v1.2.2 (2025-12-15)

### Chores

- Sync server.json version
  ([`7b12d80`](https://github.com/tmonk/mcp-stata/commit/7b12d800ea21feaa42674c30dcf027662eab0bea))

### Features

- Enhance Stata path detection for Linux and add corresponding tests
  ([`3ef3d85`](https://github.com/tmonk/mcp-stata/commit/3ef3d85cd3be91dfb4e81e56cafcafa793cd1679))


## v1.2.1 (2025-12-14)

### Chores

- Update server.json version to 1.2.0 and enhance version sync workflow for better branch handling
  ([`899f106`](https://github.com/tmonk/mcp-stata/commit/899f1065f5b0f7de4be0c2917169f15171d37d38))

### Refactoring

- Change get_variable_list to a tool and add resource wrapper for variable list
  ([`5f640c6`](https://github.com/tmonk/mcp-stata/commit/5f640c6d9fafe81ee97b868605d9f9f7b1908498))


## v1.2.0 (2025-12-14)


## v1.1.0 (2025-12-12)

### Chores

- Sync server.json version
  ([`f8ef75f`](https://github.com/tmonk/mcp-stata/commit/f8ef75f93ee89ed2dc281701b280a11a7b739e3c))


## v1.0.4 (2025-12-12)


## v1.0.3 (2025-12-12)


## v1.0.2 (2025-12-12)


## v1.0.1 (2025-12-12)


## v1.0.0 (2025-12-12)

- Initial Release
