"""
Panda Ronin — Tool Registry
工具注册表：标准工具 + 网络工具
"""

from __future__ import annotations

import os
import subprocess
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable


@dataclass
class Tool:
    name: str
    description: str
    parameters: dict
    handler: Callable
    is_mutating: bool = False
    never_parallel: bool = False

    @property
    def schema(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": self.parameters,
        }

    def execute(self, **kwargs) -> str:
        try:
            result = self.handler(**kwargs)
            return str(result) if result is not None else "完成"
        except Exception as e:
            return f"[错误] {type(e).__name__}: {e}"


class ToolRegistry:
    def __init__(self):
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool) -> "ToolRegistry":
        self._tools[tool.name] = tool
        return self

    def get(self, name: str) -> Tool | None:
        return self._tools.get(name)

    def get_schemas(self) -> list[dict]:
        return [t.schema for t in self._tools.values()]

    def dispatch(self, name: str, args: dict) -> str:
        tool = self.get(name)
        if not tool:
            return f"[错误] 未知工具：{name}"
        return tool.execute(**args)


# ── 工具处理函数 ──────────────────────────────────────────────────

def _bash(command: str, timeout: int = 30, cwd: str = None) -> str:
    # 安全检查
    BLOCKED = ["rm -rf /", "format c:", ":(){ :|:& };:"]
    for b in BLOCKED:
        if b in command.lower():
            return f"[安全阻止] 危险命令：{b}"

    result = subprocess.run(
        command, shell=True,
        capture_output=True, text=True,
        timeout=timeout, cwd=cwd or os.getcwd(),
    )
    out = result.stdout
    if result.returncode != 0:
        out += f"\n[exit:{result.returncode}]\n{result.stderr}"
    return out[:4000] or "(无输出)"


def _read_file(path: str, offset: int = 1, limit: int = 200) -> str:
    p = Path(path)
    if not p.exists():
        return f"[错误] 文件不存在：{path}"
    lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
    start = max(0, offset - 1)
    selected = lines[start:start + limit]
    result = "\n".join(f"{start+i+1:4d}│ {l}" for i, l in enumerate(selected))
    if len(lines) > start + limit:
        result += f"\n... 共 {len(lines)} 行"
    return result


def _write_file(path: str, content: str) -> str:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    return f"已写入 {path}（{len(content)} 字符）"


def _glob_files(pattern: str, base_dir: str = ".") -> str:
    matches = sorted(Path(base_dir).glob(pattern))
    if not matches:
        return f"未找到匹配 '{pattern}' 的文件"
    return "\n".join(str(m) for m in matches[:100])


def _grep(pattern: str, path: str, recursive: bool = True) -> str:
    import re
    results = []
    p = Path(path)
    files = p.rglob("*") if recursive and p.is_dir() else [p]
    for f in files:
        if not f.is_file():
            continue
        try:
            for i, line in enumerate(
                f.read_text(encoding="utf-8", errors="replace").splitlines(), 1
            ):
                if re.search(pattern, line):
                    results.append(f"{f}:{i}: {line.strip()}")
        except Exception:
            pass
    return "\n".join(results[:200]) or f"未找到匹配 '{pattern}'"


def _web_fetch(url: str, timeout: int = 15) -> str:
    """获取网页内容（纯文本）"""
    try:
        # 优先用 requests
        import requests
        resp = requests.get(
            url, timeout=timeout,
            headers={"User-Agent": "Mozilla/5.0 PandaRonin/0.1"},
        )
        # 尝试用 markdownify 转换 HTML
        try:
            from markdownify import markdownify
            return markdownify(resp.text)[:8000]
        except ImportError:
            import re
            text = re.sub(r"<[^>]+>", "", resp.text)
            return text[:8000]
    except ImportError:
        req = urllib.request.Request(
            url, headers={"User-Agent": "Mozilla/5.0 PandaRonin/0.1"}
        )
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read().decode("utf-8", errors="replace")[:8000]
    except Exception as e:
        return f"[错误] 无法获取 {url}: {e}"


def _web_search(query: str, num_results: int = 5) -> str:
    """使用 DuckDuckGo 搜索（无需 API key）"""
    try:
        from duckduckgo_search import DDGS
        with DDGS() as ddgs:
            results = list(ddgs.text(query, max_results=num_results))
        if not results:
            return "无搜索结果"
        lines = []
        for i, r in enumerate(results, 1):
            lines.append(f"{i}. {r.get('title', '')}")
            lines.append(f"   {r.get('href', '')}")
            lines.append(f"   {r.get('body', '')[:200]}")
        return "\n".join(lines)
    except ImportError:
        # 降级到 urllib
        import urllib.parse, re
        encoded = urllib.parse.quote(query)
        url = f"https://html.duckduckgo.com/html/?q={encoded}"
        req = urllib.request.Request(
            url, headers={"User-Agent": "Mozilla/5.0"}
        )
        with urllib.request.urlopen(req, timeout=10) as r:
            html = r.read().decode("utf-8", errors="replace")
        titles = re.findall(r'class="result__title"[^>]*>(.*?)</a>', html)
        urls = re.findall(r'class="result__url"[^>]*>(.*?)</span>', html)
        results_list = []
        for i, (t, u) in enumerate(zip(titles[:num_results], urls[:num_results]), 1):
            results_list.append(f"{i}. {re.sub('<[^>]+>', '', t).strip()}\n   {u.strip()}")
        return "\n".join(results_list) or "无结果"
    except Exception as e:
        return f"[错误] 搜索失败：{e}"


# ── 标准工具集 ────────────────────────────────────────────────────

STANDARD_TOOLS: list[Tool] = [
    Tool(
        name="bash",
        description="执行 shell 命令。每次独立 shell，30s 超时。危险命令会被阻止。",
        parameters={
            "type": "object",
            "properties": {
                "command": {"type": "string"},
                "timeout": {"type": "integer", "default": 30},
                "cwd": {"type": "string"},
            },
            "required": ["command"],
        },
        handler=_bash,
        is_mutating=True, never_parallel=True,
    ),
    Tool(
        name="read_file",
        description="读取文件内容（带行号）。支持 offset/limit 分段读取。",
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "offset": {"type": "integer", "default": 1},
                "limit": {"type": "integer", "default": 200},
            },
            "required": ["path"],
        },
        handler=_read_file,
    ),
    Tool(
        name="write_file",
        description="将内容写入文件（覆盖）。自动创建目录。",
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "content": {"type": "string"},
            },
            "required": ["path", "content"],
        },
        handler=_write_file,
        is_mutating=True,
    ),
    Tool(
        name="glob",
        description="按 glob 模式查找文件，如 '**/*.py'",
        parameters={
            "type": "object",
            "properties": {
                "pattern": {"type": "string"},
                "base_dir": {"type": "string", "default": "."},
            },
            "required": ["pattern"],
        },
        handler=_glob_files,
    ),
    Tool(
        name="grep",
        description="在文件/目录中搜索正则表达式，返回匹配行",
        parameters={
            "type": "object",
            "properties": {
                "pattern": {"type": "string"},
                "path": {"type": "string"},
                "recursive": {"type": "boolean", "default": True},
            },
            "required": ["pattern", "path"],
        },
        handler=_grep,
    ),
    Tool(
        name="web_fetch",
        description="获取网页内容（自动转为纯文本/Markdown）",
        parameters={
            "type": "object",
            "properties": {
                "url": {"type": "string"},
                "timeout": {"type": "integer", "default": 15},
            },
            "required": ["url"],
        },
        handler=_web_fetch,
    ),
    Tool(
        name="web_search",
        description="使用 DuckDuckGo 搜索（无需 API key）",
        parameters={
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "num_results": {"type": "integer", "default": 5},
            },
            "required": ["query"],
        },
        handler=_web_search,
    ),
]


def create_default_registry() -> ToolRegistry:
    registry = ToolRegistry()
    for tool in STANDARD_TOOLS:
        registry.register(tool)
    return registry
