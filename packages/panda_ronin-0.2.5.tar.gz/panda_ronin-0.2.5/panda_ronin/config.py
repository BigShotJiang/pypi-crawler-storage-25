"""
Panda Ronin — Configuration
Loads from config.yaml + environment variables
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

try:
    import yaml
    def _load_yaml(path: Path) -> dict:
        with open(path, encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
except ImportError:
    def _load_yaml(path: Path) -> dict:
        return {}


@dataclass
class LLMConfig:
    model: str = "anthropic/claude-sonnet-4-6"
    api_key: str = ""
    base_url: str = ""          # 自定义 endpoint（兼容 OpenAI 协议的国内模型用）
    max_tokens: int = 4096
    temperature: float = 1.0


@dataclass
class LifecycleConfig:
    tick_interval_seconds: int = 300
    hp_decay_per_tick: float = 0.5
    energy_decay_per_tick: float = 1.0
    social_decay_per_tick: float = 0.8
    wisdom_decay_per_tick: float = 0.1
    home_dir: str = "~/.panda-ronin"


@dataclass
class TelegramConfig:
    enabled: bool = False
    bot_token: str = ""
    allowed_chat_ids: list[int] = field(default_factory=list)


@dataclass
class FeishuConfig:
    enabled: bool = False
    app_id: str = ""
    app_secret: str = ""
    verification_token: str = ""
    encrypt_key: str = ""


@dataclass
class DingtalkConfig:
    enabled: bool = False
    app_key: str = ""
    app_secret: str = ""
    webhook_url: str = ""


@dataclass
class WecomConfig:
    enabled: bool = False
    corp_id: str = ""
    corp_secret: str = ""
    agent_id: str = ""


@dataclass
class QQConfig:
    enabled: bool = False
    app_id: str = ""
    app_token: str = ""
    guild_id: str = ""


@dataclass
class HttpConfig:
    enabled: bool = True
    host: str = "0.0.0.0"
    port: int = 8080
    api_key: str = ""


@dataclass
class Config:
    llm: LLMConfig = field(default_factory=LLMConfig)
    lifecycle: LifecycleConfig = field(default_factory=LifecycleConfig)
    telegram: TelegramConfig = field(default_factory=TelegramConfig)
    feishu: FeishuConfig = field(default_factory=FeishuConfig)
    dingtalk: DingtalkConfig = field(default_factory=DingtalkConfig)
    wecom: WecomConfig = field(default_factory=WecomConfig)
    qq: QQConfig = field(default_factory=QQConfig)
    http: HttpConfig = field(default_factory=HttpConfig)

    @classmethod
    def load(cls, config_path: str | Path | None = None) -> "Config":
        cfg = cls()
        if config_path is None:
            config_path = Path("config.yaml")
        config_path = Path(config_path)
        if config_path.exists():
            cfg._apply_dict(_load_yaml(config_path))
        cfg._apply_env()
        return cfg

    def _apply_dict(self, data: dict):
        if not data:
            return
        # 支持旧的 anthropic: 键名，方便迁移
        llm_data = data.get("llm") or data.get("anthropic", {})
        if llm_data.get("model"):     self.llm.model = llm_data["model"]
        if llm_data.get("api_key"):   self.llm.api_key = llm_data["api_key"]
        if llm_data.get("base_url"):  self.llm.base_url = llm_data["base_url"]
        if llm_data.get("max_tokens"):self.llm.max_tokens = int(llm_data["max_tokens"])

        lc = data.get("lifecycle", {})
        if lc.get("tick_interval_seconds"):
            self.lifecycle.tick_interval_seconds = int(lc["tick_interval_seconds"])
        if lc.get("home_dir"):
            self.lifecycle.home_dir = lc["home_dir"]

        for platform, obj in [
            ("telegram", self.telegram), ("feishu", self.feishu),
            ("dingtalk", self.dingtalk), ("wecom", self.wecom),
            ("qq", self.qq), ("http", self.http),
        ]:
            for k, v in data.get(platform, {}).items():
                if hasattr(obj, k):
                    setattr(obj, k, v)

    def _apply_env(self):
        # 通用 LLM key（优先级最高）
        if v := os.getenv("LLM_API_KEY"):
            self.llm.api_key = v
        if v := os.getenv("LLM_MODEL"):
            self.llm.model = v
        if v := os.getenv("LLM_BASE_URL"):
            self.llm.base_url = v

        # 各厂商专属 key（自动按 model 前缀匹配）
        if not self.llm.api_key:
            prefix = self.llm.model.split("/")[0].lower() if "/" in self.llm.model else ""
            _key_map = {
                "anthropic":  os.getenv("ANTHROPIC_API_KEY", ""),
                "openai":     os.getenv("OPENAI_API_KEY", ""),
                "deepseek":   os.getenv("DEEPSEEK_API_KEY", ""),
                "dashscope":  os.getenv("DASHSCOPE_API_KEY", ""),   # 通义千问
                "qwen":       os.getenv("DASHSCOPE_API_KEY", ""),
                "zhipuai":    os.getenv("ZHIPUAI_API_KEY", ""),     # 智谱
                "moonshot":   os.getenv("MOONSHOT_API_KEY", ""),    # Kimi
                "baidu":      os.getenv("QIANFAN_API_KEY", ""),     # 文心
                "gemini":     os.getenv("GEMINI_API_KEY", ""),
                "mistral":    os.getenv("MISTRAL_API_KEY", ""),
                "groq":       os.getenv("GROQ_API_KEY", ""),
                "ollama":     "ollama",                              # 本地无需 key
            }
            self.llm.api_key = _key_map.get(prefix, "")

        # 平台 keys
        if v := os.getenv("TELEGRAM_BOT_TOKEN"):
            self.telegram.bot_token = v; self.telegram.enabled = True
        if v := os.getenv("FEISHU_APP_ID"):
            self.feishu.app_id = v
        if v := os.getenv("FEISHU_APP_SECRET"):
            self.feishu.app_secret = v; self.feishu.enabled = True
        if v := os.getenv("DINGTALK_APP_KEY"):
            self.dingtalk.app_key = v
        if v := os.getenv("DINGTALK_APP_SECRET"):
            self.dingtalk.app_secret = v; self.dingtalk.enabled = True
        if v := os.getenv("WECOM_CORP_ID"):
            self.wecom.corp_id = v
        if v := os.getenv("WECOM_CORP_SECRET"):
            self.wecom.corp_secret = v; self.wecom.enabled = True
        if v := os.getenv("QQ_APP_ID"):
            self.qq.app_id = v
        if v := os.getenv("QQ_APP_TOKEN"):
            self.qq.app_token = v; self.qq.enabled = True
        if v := os.getenv("HTTP_API_KEY"):
            self.http.api_key = v
        if v := os.getenv("HTTP_PORT"):
            self.http.port = int(v)