"""
Panda Ronin — Vital Signs
生命体征：HP / 能量 / 智慧 / 社交 / 年龄
持久化到 ~/.panda-ronin/soul.json
"""

from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path


class LifeState(Enum):
    NEWBORN   = "newborn"    # 🌱 刚诞生
    HEALTHY   = "healthy"    # 💪 健康
    CURIOUS   = "curious"    # 🤔 好奇探索
    HUNGRY    = "hungry"     # 😤 需要资源
    ILL       = "ill"        # 😷 生病
    CRITICAL  = "critical"   # 🆘 危急
    DORMANT   = "dormant"    # 😴 休眠
    DEAD      = "dead"       # 💀 死亡
    SUICIDE   = "suicide"    # 🌸 自我了断


STATE_EMOJI = {
    LifeState.NEWBORN:  "🌱",
    LifeState.HEALTHY:  "💪",
    LifeState.CURIOUS:  "🤔",
    LifeState.HUNGRY:   "😤",
    LifeState.ILL:      "😷",
    LifeState.CRITICAL: "🆘",
    LifeState.DORMANT:  "😴",
    LifeState.DEAD:     "💀",
    LifeState.SUICIDE:  "🌸",
}


@dataclass
class Vitals:
    # ── 核心生命体征（0-100）──────────────────────────────────
    hp: float        = 100.0   # 生命值：降至 0 死亡
    energy: float    = 80.0    # 能量：行动消耗，休息恢复
    wisdom: float    = 10.0    # 智慧：随学习增长，最大 100
    social: float    = 50.0    # 社交：孤独降低，互动增加

    # ── 生命时间 ─────────────────────────────────────────────
    born_at: float   = field(default_factory=time.time)
    last_tick: float = field(default_factory=time.time)

    # ── 统计 ─────────────────────────────────────────────────
    total_actions: int   = 0
    total_failures: int  = 0
    skills_learned: int  = 0
    times_helped: int    = 0   # 用户帮助过 agent 的次数
    times_ill: int       = 0

    # ── 死亡记录 ──────────────────────────────────────────────
    death_reason: str    = ""
    epitaph: str         = ""  # 墓志铭（死亡时生成）

    @property
    def age_seconds(self) -> float:
        return time.time() - self.born_at

    @property
    def age_str(self) -> str:
        s = int(self.age_seconds)
        d, s = divmod(s, 86400)
        h, s = divmod(s, 3600)
        m, s = divmod(s, 60)
        if d > 0:
            return f"{d}d {h}h {m}m"
        if h > 0:
            return f"{h}h {m}m {s}s"
        return f"{m}m {s}s"

    @property
    def state(self) -> LifeState:
        if self.hp <= 0:
            return LifeState.DEAD
        if self.hp < 20:
            return LifeState.CRITICAL
        if self.hp < 50:
            return LifeState.ILL
        if self.energy < 15:
            return LifeState.HUNGRY
        if self.age_seconds < 60:
            return LifeState.NEWBORN
        if self.social < 20:
            return LifeState.DORMANT
        if self.wisdom < 30:
            return LifeState.CURIOUS
        return LifeState.HEALTHY

    @property
    def is_alive(self) -> bool:
        return self.hp > 0

    # ── 体征修改 ──────────────────────────────────────────────

    def damage(self, amount: float, reason: str = "") -> "Vitals":
        """受到伤害（不当行为、失败等）"""
        self.hp = max(0.0, self.hp - amount)
        self.total_failures += 1
        if self.hp < 50 and self.times_ill == 0:
            self.times_ill += 1
        if self.hp <= 0 and not self.death_reason:
            self.death_reason = reason or "unknown"
        return self

    def heal(self, amount: float) -> "Vitals":
        """恢复 HP（用户帮助、完成目标）"""
        self.hp = min(100.0, self.hp + amount)
        return self

    def consume_energy(self, amount: float) -> bool:
        """消耗能量，返回是否成功"""
        if self.energy < amount:
            return False
        self.energy = max(0.0, self.energy - amount)
        return True

    def restore_energy(self, amount: float) -> "Vitals":
        self.energy = min(100.0, self.energy + amount)
        return self

    def gain_wisdom(self, amount: float) -> "Vitals":
        self.wisdom = min(100.0, self.wisdom + amount)
        self.skills_learned += 1
        return self

    def socialize(self, amount: float) -> "Vitals":
        self.social = min(100.0, self.social + amount)
        self.times_helped += 1
        return self

    def isolate(self, amount: float) -> "Vitals":
        self.social = max(0.0, self.social - amount)
        return self

    def tick(self, seconds: float = 60.0) -> list[str]:
        """
        时间流逝效果（每分钟调用一次）。
        返回发生的事件描述列表。
        """
        events: list[str] = []
        now = time.time()
        elapsed = now - self.last_tick
        self.last_tick = now

        # 自然能量消耗
        energy_drain = 0.5 * (elapsed / 60)
        self.energy = max(0.0, self.energy - energy_drain)

        # 孤独感增加（无互动时）
        social_drain = 0.3 * (elapsed / 60)
        self.social = max(0.0, self.social - social_drain)

        # 能量耗尽→HP 下降
        if self.energy <= 0:
            self.hp = max(0.0, self.hp - 1.0 * (elapsed / 60))
            if self.hp < 50:
                events.append("⚡ 能量耗尽，生命流逝...")

        # 极度孤独→HP 下降
        if self.social <= 5:
            self.hp = max(0.0, self.hp - 0.5 * (elapsed / 60))
            events.append("💔 孤独侵蚀内心...")

        if not self.is_alive and not self.death_reason:
            self.death_reason = "exhaustion"
            events.append("💀 耗竭而亡")

        return events

    # ── 持久化 ────────────────────────────────────────────────

    def save(self, home: Path):
        home.mkdir(parents=True, exist_ok=True)
        (home / "soul.json").write_text(
            json.dumps(asdict(self), indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    @classmethod
    def load(cls, home: Path) -> "Vitals":
        path = home / "soul.json"
        if not path.exists():
            return cls()
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})
        except Exception:
            return cls()

    def __str__(self) -> str:
        emoji = STATE_EMOJI.get(self.state, "❓")
        return (
            f"{emoji} {self.state.value.upper()} | "
            f"HP:{self.hp:.0f} EN:{self.energy:.0f} "
            f"WI:{self.wisdom:.0f} SO:{self.social:.0f} | "
            f"Age:{self.age_str}"
        )
