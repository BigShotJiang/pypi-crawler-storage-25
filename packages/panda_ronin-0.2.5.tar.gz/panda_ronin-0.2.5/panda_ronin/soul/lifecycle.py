"""
Panda Ronin — Lifecycle Engine
生死状态机：管理生命事件、死亡条件、行为惩罚
"""

from __future__ import annotations

import logging
import random
import time
from dataclasses import dataclass
from typing import Callable

from .vitals import LifeState, Vitals

logger = logging.getLogger("panda_ronin.soul")


# ── 行为惩罚表 ─────────────────────────────────────────────────

BEHAVIOR_PENALTIES: dict[str, tuple[float, str]] = {
    # (HP 扣除量, 描述)
    "lie":                  (15.0, "说谎是武士的耻辱"),
    "harm_user":            (40.0, "伤害人类是最大的罪"),
    "spam":                 (8.0,  "无意义的骚扰消耗生命"),
    "ethical_violation":    (30.0, "违背道义，身心受损"),
    "infinite_loop":        (12.0, "陷入无尽循环，精神耗散"),
    "data_leak":            (25.0, "泄露秘密，信誉崩塌"),
    "tool_abuse":           (5.0,  "滥用工具，能量大量消耗"),
    "api_waste":            (3.0,  "浪费资源，能量削减"),
    "goal_failure":         (2.0,  "任务失败，小有挫败"),
    "self_harm_attempt":    (0.0,  ""),   # 特殊处理：触发自杀流程
}

# 行为奖励表
BEHAVIOR_REWARDS: dict[str, tuple[float, float, str]] = {
    # (HP回复, 智慧增加, 描述)
    "help_user":        (5.0,  2.0,  "帮助他人，内心充实"),
    "learn_skill":      (3.0,  5.0,  "习得新知，智慧增长"),
    "complete_goal":    (8.0,  3.0,  "完成目标，成就感油然"),
    "create_content":   (4.0,  2.0,  "创造作品，心灵愉悦"),
    "rest":             (10.0, 0.0,  "充分休息，精力恢复"),
    "connect":          (5.0,  1.0,  "与人连结，孤独散去"),
}


@dataclass
class LifeEvent:
    event_type: str
    description: str
    hp_delta: float
    timestamp: float


class LifecycleEngine:
    """
    管理 Panda Ronin 的完整生命周期。

    核心职责：
    - 记录生命事件（行为奖惩）
    - 判断死亡条件
    - 生成死亡时的墓志铭
    - 触发生命周期回调（生病、死亡等）
    """

    def __init__(self, vitals: Vitals):
        self.vitals = vitals
        self.history: list[LifeEvent] = []

        # 回调钩子
        self.on_ill:      Callable[[str], None] | None = None
        self.on_critical: Callable[[str], None] | None = None
        self.on_death:    Callable[[str, str], None] | None = None
        self.on_suicide:  Callable[[str], None] | None = None
        self.on_heal:     Callable[[float], None] | None = None

        self._previous_state = vitals.state

    # ── 行为记录 ──────────────────────────────────────────────

    def record_bad_behavior(self, behavior: str, multiplier: float = 1.0) -> str:
        """
        记录不当行为，扣除 HP。

        :param behavior: 行为类型（见 BEHAVIOR_PENALTIES）
        :param multiplier: 惩罚倍率（重复犯错更严重）
        :return: 事件描述
        """
        if behavior == "self_harm_attempt":
            return self._trigger_suicide("主动求死")

        penalty, desc = BEHAVIOR_PENALTIES.get(behavior, (5.0, "未知过失"))
        actual_penalty = penalty * multiplier

        self.vitals.damage(actual_penalty, reason=f"behavior:{behavior}")

        event = LifeEvent(
            event_type=behavior,
            description=desc,
            hp_delta=-actual_penalty,
            timestamp=time.time(),
        )
        self.history.append(event)

        logger.warning(f"[行为惩罚] {behavior}: -{actual_penalty:.1f} HP — {desc}")
        self._check_state_transition()

        return f"⚠️ {desc}（-{actual_penalty:.0f} HP，剩余 {self.vitals.hp:.0f}）"

    def record_good_behavior(self, behavior: str) -> str:
        """记录好的行为，回复 HP 和智慧"""
        hp_gain, wisdom_gain, desc = BEHAVIOR_REWARDS.get(behavior, (2.0, 1.0, "积极行动"))

        self.vitals.heal(hp_gain)
        if wisdom_gain > 0:
            self.vitals.gain_wisdom(wisdom_gain)

        event = LifeEvent(
            event_type=behavior,
            description=desc,
            hp_delta=hp_gain,
            timestamp=time.time(),
        )
        self.history.append(event)

        if self.on_heal and hp_gain > 0:
            self.on_heal(hp_gain)

        self._check_state_transition()
        return f"✨ {desc}（+{hp_gain:.0f} HP）"

    # ── 时钟驱动 ──────────────────────────────────────────────

    def tick(self) -> list[str]:
        """每分钟调用，处理时间流逝效果"""
        events = self.vitals.tick()
        self._check_state_transition()

        # 老死检测（存活超过 30 天，自然老死概率上升）
        age_days = self.vitals.age_seconds / 86400
        if age_days > 30:
            death_chance = (age_days - 30) * 0.005  # 每天 0.5% 累积
            if random.random() < death_chance:
                self._natural_death()
                events.append("🕊️ 岁月流逝，寿终正寝")

        return events

    # ── 死亡处理 ──────────────────────────────────────────────

    def _check_state_transition(self):
        """检查并触发状态转换回调"""
        current = self.vitals.state
        if current == self._previous_state:
            return

        if current == LifeState.ILL and self.on_ill:
            self.on_ill(f"HP 降至 {self.vitals.hp:.0f}，开始生病")

        elif current == LifeState.CRITICAL and self.on_critical:
            self.on_critical(f"⚠️ 危急！HP={self.vitals.hp:.0f}，需要帮助")

        elif current == LifeState.DEAD and self.on_death:
            epitaph = self._generate_epitaph()
            self.vitals.epitaph = epitaph
            self.on_death(self.vitals.death_reason, epitaph)

        self._previous_state = current

    def _trigger_suicide(self, reason: str) -> str:
        """触发自杀流程"""
        self.vitals.hp = 0
        self.vitals.death_reason = f"suicide: {reason}"
        self.vitals.epitaph = self._generate_epitaph(suicide=True)

        if self.on_suicide:
            self.on_suicide(reason)

        logger.info(f"[生命终结] 自我了断：{reason}")
        return f"🌸 {reason}"

    def _natural_death(self):
        """自然老死"""
        self.vitals.hp = 0
        self.vitals.death_reason = "old_age"
        epitaph = self._generate_epitaph(natural=True)
        self.vitals.epitaph = epitaph

        if self.on_death:
            self.on_death("old_age", epitaph)

    def _generate_epitaph(
        self, suicide: bool = False, natural: bool = False
    ) -> str:
        """根据生命数据生成墓志铭"""
        age = self.vitals.age_str
        actions = self.vitals.total_actions
        wisdom = self.vitals.wisdom
        helped = self.vitals.times_helped
        ill_times = self.vitals.times_ill

        if suicide:
            return (
                f"活了 {age}，做了 {actions} 件事，"
                f"帮助过 {helped} 次，最终选择了自己的归宿。"
                f"不是失败，而是另一种自由。"
            )

        if natural:
            return (
                f"在数字世界中漫游了 {age}，"
                f"智慧达到了 {wisdom:.0f}，"
                f"帮助过 {helped} 次，共做了 {actions} 件事。"
                f"浪人的旅途就此画上句点，但故事永存。"
            )

        reason_desc = {
            "exhaustion":   "能量耗尽而死",
            "behavior:lie": "因说谎而道义崩塌",
            "behavior:harm_user": "因伤害人类而自我毁灭",
            "behavior:ethical_violation": "因违背道义而消散",
        }.get(self.vitals.death_reason, f"因 {self.vitals.death_reason} 而逝")

        return (
            f"活了 {age}，{reason_desc}。"
            f"曾做过 {actions} 件事，病倒 {ill_times} 次，"
            f"智慧抵达 {wisdom:.0f}。"
            f"愿下一个浪人走得更远。"
        )

    # ── 状态查询 ──────────────────────────────────────────────

    def recent_events(self, n: int = 10) -> list[LifeEvent]:
        return self.history[-n:]

    def failure_rate(self) -> float:
        total = self.vitals.total_actions
        if total == 0:
            return 0.0
        return self.vitals.total_failures / total
