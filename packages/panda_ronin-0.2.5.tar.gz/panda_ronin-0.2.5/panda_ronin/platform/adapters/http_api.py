"""
Panda Ronin — HTTP API Adapter
依赖: pip install fastapi uvicorn
提供 REST + SSE 接口，供 web 客户端或第三方集成
"""

from __future__ import annotations

import logging
import threading
from typing import TYPE_CHECKING

from ..gateway import ChannelAdapter

if TYPE_CHECKING:
    from ...config import HttpConfig
    from ...agent.core import PandaRonin

logger = logging.getLogger(__name__)


class HttpAdapter(ChannelAdapter):
    name = "http_api"

    def __init__(self, config: "HttpConfig", agent: "PandaRonin"):
        self.config = config
        self.agent = agent
        self._app = None
        self._thread: threading.Thread | None = None
        self._pending: list[str] = []

    def send(self, message: str, **kwargs) -> None:
        self._pending.append(message)
        if len(self._pending) > 100:
            self._pending.pop(0)

    def start(self) -> None:
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _run(self) -> None:
        try:
            import uvicorn
            from fastapi import FastAPI, HTTPException, Depends
            from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
            from fastapi.middleware.cors import CORSMiddleware
            from pydantic import BaseModel

            app = FastAPI(title="Panda Ronin API", version="0.1.0")
            app.add_middleware(
                CORSMiddleware,
                allow_origins=["*"], allow_methods=["*"], allow_headers=["*"],
            )

            api_key = self.config.api_key
            security = HTTPBearer(auto_error=bool(api_key))
            adapter = self

            def verify(creds: HTTPAuthorizationCredentials = Depends(security)):
                if api_key and creds.credentials != api_key:
                    raise HTTPException(status_code=401, detail="Invalid API key")

            class ChatRequest(BaseModel):
                message: str

            @app.get("/health")
            def health():
                return {"status": "alive" if adapter.agent.vitals.is_alive else "dead"}

            @app.get("/status")
            def status():
                v = adapter.agent.vitals
                return {
                    "hp": v.hp, "energy": v.energy,
                    "wisdom": v.wisdom, "social": v.social,
                    "state": v.state.value, "age": v.age_str,
                }

            @app.get("/needs")
            def needs():
                return [
                    {
                        "id": n.need_id, "type": n.need_type.value,
                        "title": n.title, "description": n.description,
                    }
                    for n in adapter.agent.needs_manager.pending()
                ]

            @app.post("/chat")
            def chat(req: ChatRequest, _=Depends(verify)):
                response = adapter.agent.chat(req.message)
                return {"response": response}

            @app.post("/fulfill/{need_id}")
            def fulfill(need_id: str, req: ChatRequest, _=Depends(verify)):
                need = adapter.agent.needs_manager.fulfill(need_id, req.message)
                if not need:
                    raise HTTPException(status_code=404, detail="Need not found")
                reply = adapter.agent.chat(
                    f"[SYSTEM] Your need '{need.title}' has been fulfilled: {req.message}"
                )
                return {"fulfilled": need.title, "response": reply}

            @app.get("/broadcast")
            def broadcast_poll():
                msgs = list(adapter._pending)
                adapter._pending.clear()
                return {"messages": msgs}

            self._app = app
            logger.info(f"HTTP API starting on {self.config.host}:{self.config.port}")
            uvicorn.run(
                app, host=self.config.host, port=self.config.port,
                log_level="warning",
            )
        except ImportError:
            logger.warning("fastapi/uvicorn not installed; HTTP API disabled")
        except Exception as e:
            logger.error(f"HTTP API error: {e}")

    def stop(self) -> None:
        pass