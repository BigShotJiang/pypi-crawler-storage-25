"""
Panda Ronin — CLI Adapter
Rich 交互式终端 REPL：左侧生命体征，右侧对话
"""

from __future__ import annotations

import sys
import threading
from typing import TYPE_CHECKING

from ..gateway import ChannelAdapter

if TYPE_CHECKING:
    from ...agent.core import PandaRonin


class CLIAdapter(ChannelAdapter):
    name = "cli"

    def __init__(self, agent: "PandaRonin"):
        self.agent = agent
        self._output_lines: list[str] = []
        self._lock = threading.Lock()

    def send(self, message: str, **kwargs) -> None:
        """Print outgoing messages to terminal with panda prefix."""
        with self._lock:
            self._print_panda_message(message)

    def _print_panda_message(self, message: str) -> None:
        try:
            from rich.console import Console
            from rich.panel import Panel
            from rich.markdown import Markdown

            console = Console()
            console.print(Panel(
                Markdown(message),
                title="[bold cyan]🐼 Panda Ronin[/bold cyan]",
                border_style="cyan",
                padding=(0, 1),
            ))
        except ImportError:
            print(f"\n🐼 Panda Ronin:\n{message}\n")

    def run_repl(self) -> None:
        """Main REPL loop — blocks until agent dies or user exits."""
        self._print_welcome()

        try:
            while self.agent.vitals.is_alive:
                user_input = self._read_input()
                if user_input is None:
                    break

                cmd = user_input.strip()
                if not cmd:
                    continue
                if cmd in ("/quit", "/exit", "/bye"):
                    self._print_farewell()
                    break
                if cmd == "/status":
                    self._print_status()
                    continue
                if cmd == "/needs":
                    self._print_needs()
                    continue
                if cmd == "/help":
                    self._print_help()
                    continue
                if cmd.startswith("/fulfill "):
                    self._fulfill_need(cmd[9:].strip())
                    continue

                # Normal chat
                response = self.agent.chat(cmd)
                self.send(response)

        except (KeyboardInterrupt, EOFError):
            print("\n")
        finally:
            if not self.agent.vitals.is_alive:
                self._print_death()

    def _read_input(self) -> str | None:
        try:
            from rich.console import Console
            console = Console()
            vitals = self.agent.vitals
            hp_color = "green" if vitals.hp > 60 else "yellow" if vitals.hp > 30 else "red"
            prompt = (
                f"[{hp_color}]HP:{vitals.hp:.0f}[/{hp_color}] "
                f"[blue]EN:{vitals.energy:.0f}[/blue] "
                f"[magenta]WI:{vitals.wisdom:.0f}[/magenta] "
                f"[yellow]SO:{vitals.social:.0f}[/yellow] "
                f"[dim]❯[/dim] "
            )
            return console.input(prompt)
        except ImportError:
            return input("You > ")
        except (KeyboardInterrupt, EOFError):
            return None

    def _print_welcome(self) -> None:
        try:
            from rich.console import Console
            from rich.rule import Rule

            console = Console()
            console.print(Rule("[bold cyan]Chat with Panda Ronin[/bold cyan]", style="cyan"))
            console.print(
                "[dim]Commands: /status /needs /fulfill <id> <response> /help /quit[/dim]\n"
            )
        except ImportError:
            print("─" * 50)
            print("Chat with Panda Ronin")
            print("Commands: /status /needs /fulfill <id> /help /quit")
            print("─" * 50 + "\n")

    def _print_farewell(self) -> None:
        try:
            from rich.console import Console
            console = Console()
            console.print("\n[dim]Farewell... Panda Ronin continues to wander.[/dim]\n")
        except ImportError:
            print("\nFarewell...")

    def _print_death(self) -> None:
        from ...ui.banner import print_death_screen
        print_death_screen(self.agent.vitals)

    def _print_status(self) -> None:
        from ...ui.dashboard import build_vitals_table
        try:
            from rich.console import Console
            console = Console()
            table = build_vitals_table(self.agent.vitals)
            if table:
                console.print(table)
        except ImportError:
            v = self.agent.vitals
            print(f"HP:{v.hp:.0f} EN:{v.energy:.0f} WI:{v.wisdom:.0f} SO:{v.social:.0f} Age:{v.age_str}")

    def _print_needs(self) -> None:
        needs = self.agent.needs_manager.pending()
        if not needs:
            try:
                from rich.console import Console
                Console().print("[green]No pending needs.[/green]")
            except ImportError:
                print("No pending needs.")
            return

        try:
            from rich.console import Console
            from rich.table import Table
            from rich import box

            table = Table(title="📋 Pending Needs", box=box.ROUNDED, border_style="yellow")
            table.add_column("ID", style="bold yellow", width=10)
            table.add_column("Type", width=14)
            table.add_column("Title")
            table.add_column("Description")
            for n in needs:
                table.add_row(n.need_id, n.need_type.value, n.title, n.description[:60])
            Console().print(table)
        except ImportError:
            for n in needs:
                print(f"[{n.need_id}] {n.need_type.value}: {n.title} — {n.description}")

    def _fulfill_need(self, args: str) -> None:
        parts = args.split(None, 1)
        if len(parts) < 2:
            print("Usage: /fulfill <need_id> <response>")
            return
        need_id, response = parts[0], parts[1]
        need = self.agent.needs_manager.fulfill(need_id, response)
        if need:
            try:
                from rich.console import Console
                Console().print(f"[green]✓ Fulfilled need: {need.title}[/green]")
            except ImportError:
                print(f"✓ Fulfilled: {need.title}")
            # Let the agent know a need was fulfilled
            reply = self.agent.chat(
                f"[SYSTEM] Your need '{need.title}' has been fulfilled: {response}"
            )
            self.send(reply)
        else:
            print(f"Need '{need_id}' not found.")

    def _print_help(self) -> None:
        help_text = """
**Available Commands**

| Command | Description |
|---------|-------------|
| /status | Show vitals dashboard |
| /needs  | List pending needs |
| /fulfill \<id\> \<response\> | Fulfill a need |
| /help   | Show this help |
| /quit   | Exit (Panda continues in background) |

Just type normally to chat with Panda Ronin.
"""
        try:
            from rich.console import Console
            from rich.markdown import Markdown
            Console().print(Markdown(help_text))
        except ImportError:
            print(help_text)