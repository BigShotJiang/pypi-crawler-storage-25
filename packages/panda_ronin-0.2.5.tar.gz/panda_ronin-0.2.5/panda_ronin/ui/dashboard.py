"""
Panda Ronin — Real-time Dashboard
Rich Live 面板：实时显示生命体征
"""

from __future__ import annotations


def build_vitals_table(vitals):
    """构建生命体征 Rich Table"""
    try:
        from rich.table import Table
        from rich.text import Text
        from rich import box
        from ..soul.vitals import LifeState, STATE_EMOJI

        def bar(v, width=20):
            filled = int(width * v / 100)
            if v > 60:
                color = "green"
            elif v > 30:
                color = "yellow"
            else:
                color = "red"
            return Text("█" * filled + "░" * (width - filled), style=color)

        state = vitals.state
        emoji = STATE_EMOJI.get(state, "❓")

        table = Table(
            title=f"{emoji} Panda Ronin  [{state.value.upper()}]  Age: {vitals.age_str}",
            box=box.ROUNDED,
            border_style="cyan",
            show_header=False,
            padding=(0, 1),
        )
        # 拆成 4 列：图标 | 名称 | 进度条 | 数值
        # no_wrap=True 防止 emoji 宽度导致换行
        table.add_column("", width=3,  no_wrap=True)
        table.add_column("", width=7,  no_wrap=True, style="bold")
        table.add_column("", width=22, no_wrap=True)
        table.add_column("", width=8,  no_wrap=True, justify="right")

        table.add_row("❤️",  "HP",     bar(vitals.hp),     f"{vitals.hp:.0f}/100")
        table.add_row("⚡",  "Energy", bar(vitals.energy), f"{vitals.energy:.0f}/100")
        table.add_row("🧠",  "Wisdom", bar(vitals.wisdom), f"{vitals.wisdom:.0f}/100")
        table.add_row("💬",  "Social", bar(vitals.social), f"{vitals.social:.0f}/100")

        return table

    except ImportError:
        return None


def live_dashboard(vitals, refresh_seconds: float = 2.0):
    """启动 Rich Live 实时仪表板（阻塞）"""
    try:
        from rich.live import Live
        import time

        with Live(refresh_per_second=1 / refresh_seconds, screen=False) as live:
            while vitals.is_alive:
                table = build_vitals_table(vitals)
                if table:
                    live.update(table)
                time.sleep(refresh_seconds)

    except ImportError:
        pass
