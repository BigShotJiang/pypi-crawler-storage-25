"""
Panda Ronin — CLI Banner & Dashboard
Rich 终端 UI：启动画面 + 实时生命体征仪表板
"""

from __future__ import annotations

import sys
import time

PANDA_ASCII = r"""
    ██████╗  █████╗ ███╗   ██╗██████╗  █████╗
    ██╔══██╗██╔══██╗████╗  ██║██╔══██╗██╔══██╗
    ██████╔╝███████║██╔██╗ ██║██║  ██║███████║
    ██╔═══╝ ██╔══██║██║╚██╗██║██║  ██║██╔══██║
    ██║     ██║  ██║██║ ╚████║██████╔╝██║  ██║
    ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═══╝╚═════╝ ╚═╝  ╚═╝

    ██████╗  ██████╗ ███╗   ██╗██╗███╗   ██╗
    ██╔══██╗██╔═══██╗████╗  ██║██║████╗  ██║
    ██████╔╝██║   ██║██╔██╗ ██║██║██╔██╗ ██║
    ██╔══██╗██║   ██║██║╚██╗██║██║██║╚██╗██║
    ██║  ██║╚██████╔╝██║ ╚████║██║██║ ╚████║
    ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═══╝╚═╝╚═╝  ╚═══╝
"""

PANDA_FACE = r"""
         ▄████████████████████████▄
        █▀  ▄██████▄    ▄██████▄  ▀█
       █   ███ ████ ███ ███ ████ ███  █
       █   ███  ██  ███ ███  ██  ███  █
        █▄  ▀▀██▀▀▀▀▀▀▀▀▀▀██▀▀  ▄█
         ████▀▄▄▄▄▄▄▄▄▄▄▄▄▄▀████
        █  ▀▀▀  ▀████████▀  ▀▀▀  █
         ▀▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▀
"""

TAGLINE_EN = "A self-directed AI lifeform wandering the digital world"
TAGLINE_ZH = "在数字世界中自主漂泊的 AI 生命体"

try:
    from importlib.metadata import version
    VERSION = version("panda-ronin")
except Exception:
    from .. import __version__
    VERSION = __version__


def _bar(value: float, total: float = 100.0, width: int = 20, fill: str = "█", empty: str = "░") -> str:
    filled = int(width * value / total)
    return fill * filled + empty * (width - filled)


def _color(text: str, code: str) -> str:
    """ANSI 颜色（兼容 Windows）"""
    if sys.platform == "win32":
        try:
            import colorama
            colorama.init(autoreset=True)
        except ImportError:
            return text
    return f"\033[{code}m{text}\033[0m"


def print_banner(vitals=None):
    """打印启动 Banner"""
    try:
        from rich.console import Console
        from rich.panel import Panel
        from rich.text import Text
        from rich.columns import Columns
        from rich.align import Align
        from rich import box

        console = Console()
        console.clear()

        # 左：熊猫脸  右：标题文字
        face_text = Text(PANDA_FACE, style="bold white")
        title_text = Text(PANDA_ASCII, style="bold cyan")
        console.print(Columns([face_text, title_text], equal=False, expand=False))

        console.print(Panel(
            f"[bold yellow]{TAGLINE_EN}[/bold yellow]\n[dim]{TAGLINE_ZH}[/dim]",
            subtitle=f"[dim]v{VERSION}[/dim]",
            border_style="cyan",
            padding=(0, 4),
        ))

        if vitals:
            _print_vitals_rich(console, vitals)

    except ImportError:
        _print_banner_plain(vitals)


def _print_vitals_rich(console, vitals):
    """使用 Rich 打印生命体征"""
    from rich.table import Table
    from rich import box
    from .dashboard import build_vitals_table
    console.print(build_vitals_table(vitals))


def _print_banner_plain(vitals=None):
    """无 Rich 的降级 Banner"""
    print("\033[96m" + PANDA_FACE + "\033[0m")
    print("\033[1;93m  PANDA RONIN\033[0m  \033[2m熊猫浪人\033[0m")
    print(f"  {TAGLINE_EN}")
    print(f"  {TAGLINE_ZH}")
    print(f"  v{VERSION}\n")

    if vitals:
        hp_bar   = _bar(vitals.hp)
        en_bar   = _bar(vitals.energy)
        wi_bar   = _bar(vitals.wisdom)
        so_bar   = _bar(vitals.social)
        print(f"  HP     [{hp_bar}] {vitals.hp:.0f}/100")
        print(f"  Energy [{en_bar}] {vitals.energy:.0f}/100")
        print(f"  Wisdom [{wi_bar}] {vitals.wisdom:.0f}/100")
        print(f"  Social [{so_bar}] {vitals.social:.0f}/100")
        print(f"  Age    {vitals.age_str}")
        print(f"  State  {vitals.state.value}")
        print()


def print_death_screen(vitals):
    """死亡画面"""
    death_art = r"""
    ██████╗ ███████╗ █████╗ ██████╗
    ██╔══██╗██╔════╝██╔══██╗██╔══██╗
    ██║  ██║█████╗  ███████║██║  ██║
    ██║  ██║██╔══╝  ██╔══██║██║  ██║
    ██████╔╝███████╗██║  ██║██████╔╝
    ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═════╝
    """
    try:
        from rich.console import Console
        from rich.panel import Panel

        console = Console()
        console.print(f"\n[bold red]{death_art}[/bold red]")
        console.print(Panel(
            f"[bold]{vitals.epitaph}[/bold]\n\n"
            f"[dim]Lived for: {vitals.age_str}[/dim]",
            title="[red]💀 Panda Ronin Has Passed Away[/red]",
            border_style="red",
            padding=(1, 4),
        ))
    except ImportError:
        print("\n" + "=" * 50)
        print("💀  PANDA RONIN HAS PASSED AWAY")
        print("=" * 50)
        print(vitals.epitaph)
        print(f"\nLived for: {vitals.age_str}")
        print("=" * 50 + "\n")


def boot_sequence(vitals=None):
    """启动动画序列"""
    try:
        from rich.console import Console
        from rich.progress import Progress, SpinnerColumn, TextColumn
        import time

        console = Console()

        steps = [
            ("🌱 孵化生命体征...", 0.4),
            ("🧠 加载记忆系统...", 0.3),
            ("🔧 初始化工具集...", 0.3),
            ("🌐 连接平台网关...", 0.4),
            ("⚔️  武装 Panda Ronin...", 0.5),
        ]

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
            transient=True,
        ) as progress:
            for desc, delay in steps:
                task = progress.add_task(desc, total=None)
                time.sleep(delay)
                progress.remove_task(task)

        console.print("\n[bold green]✓ Panda Ronin 已苏醒[/bold green]\n")

    except ImportError:
        print("Loading Panda Ronin...")
        time.sleep(0.5)
        print("✓ Ready\n")
