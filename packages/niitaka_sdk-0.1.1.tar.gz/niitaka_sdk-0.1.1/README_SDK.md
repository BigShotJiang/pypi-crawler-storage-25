# Niitaka SDK

**AI agent observability and control plane — one import away.**

Niitaka instruments your AI agents to capture every LLM call, tool invocation, and decision trace. Connect to the [Niitaka dashboard](https://niitaka.ai) to run experiments, enforce guardrails, and version your agents — without changing your agent code.

## Install

```bash
pip install niitaka-sdk                    # core
pip install "niitaka-sdk[openai]"          # + OpenAI
pip install "niitaka-sdk[anthropic]"       # + Anthropic
pip install "niitaka-sdk[all]"             # all providers
```

## Quick start

```python
import niitaka
import os

niitaka.configure(
    api_key=os.getenv("NIITAKA_API_KEY"),
    api_url="https://api.niitaka.ai",      # or your self-hosted URL
)

# Instrument your LLM provider (pick one or more)
niitaka.instrument_openai()
niitaka.instrument_anthropic()
niitaka.instrument_gemini()
niitaka.instrument_groq()

# Wrap your agent run in a session
with niitaka.start_session(goal="Summarise this document", agent_id="my-agent"):
    response = client.chat.completions.create(...)  # auto-logged
```

Every call inside `start_session` is automatically traced — latency, token usage, cost, errors, and tool calls.

## Providers

| Provider | Extra | Import |
|---|---|---|
| OpenAI | `niitaka-sdk[openai]` | `niitaka.instrument_openai()` |
| Anthropic | `niitaka-sdk[anthropic]` | `niitaka.instrument_anthropic()` |
| Google Gemini | `niitaka-sdk[gemini]` | `niitaka.instrument_gemini()` |
| Groq | `niitaka-sdk[groq]` | `niitaka.instrument_groq()` |
| LangChain | `niitaka-sdk[langchain]` | `from niitaka import NiitakaCallbackHandler` |

## LangChain

```python
from niitaka import NiitakaCallbackHandler
import niitaka

with niitaka.start_session(goal="...", agent_id="lc-agent"):
    chain.invoke({"input": "..."}, config={"callbacks": [NiitakaCallbackHandler()]})
```

## Runtime config

Niitaka can push model, temperature, and guardrail config to your agent at runtime — no redeploy needed:

```python
config = niitaka.get_runtime_config(agent_id="my-agent")
# config["llm"]["model"], config["guardrails"]["cost_limit_usd"], ...
```

## Links

- **Dashboard**: [niitaka.ai](https://niitaka.ai)
- **Docs**: [docs.niitaka.ai](https://docs.niitaka.ai)
- **Support**: hello@niitaka.ai
