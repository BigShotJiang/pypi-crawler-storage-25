"""sdk/pricing.py — LLM model pricing table and cost calculation.

This module provides the hardcoded baseline pricing used when the backend is
unreachable. The backend's ``pricing`` table takes precedence at runtime —
the SDK fetches it at session start and passes it to ``calculate_cost`` as
``pricing_overrides``.

Prices are in **USD per 1 million tokens** (input / output separately).
Update ``PRICING_VERSION`` whenever the table is revised.

Sources (as of 2026-04):
  https://openai.com/api/pricing
  https://www.anthropic.com/pricing
  https://ai.google.dev/pricing
  https://console.groq.com/docs/openai
"""
from __future__ import annotations

import re
from typing import Dict, Optional, Tuple

# Bump this when prices are updated so callers can detect staleness.
PRICING_VERSION = "2026-04"

# ---------------------------------------------------------------------------
# Baseline pricing table — input/output cost per 1 million tokens (USD)
# ---------------------------------------------------------------------------
_SDK_PRICING: Dict[str, Dict[str, float]] = {
    # ── OpenAI GPT-4o family ───────────────────────────────────────────────
    "gpt-4o":              {"input": 2.50,  "output": 10.00},
    "gpt-4o-mini":         {"input": 0.15,  "output": 0.60},
    "gpt-4o-audio":        {"input": 2.50,  "output": 10.00},  # text tokens only
    # ── OpenAI o-series ────────────────────────────────────────────────────
    "o1":                  {"input": 15.00, "output": 60.00},
    "o1-mini":             {"input": 3.00,  "output": 12.00},
    "o1-pro":              {"input": 150.0, "output": 600.0},
    "o3":                  {"input": 10.00, "output": 40.00},
    "o3-mini":             {"input": 1.10,  "output": 4.40},
    # ── OpenAI GPT-4 legacy ────────────────────────────────────────────────
    "gpt-4-turbo":         {"input": 10.00, "output": 30.00},
    "gpt-4":               {"input": 30.00, "output": 60.00},
    # ── OpenAI GPT-3.5 ────────────────────────────────────────────────────
    "gpt-3.5-turbo":       {"input": 0.50,  "output": 1.50},

    # ── Anthropic Claude 4.6 ─────────────────────────────────────────────
    "claude-opus-4-6":      {"input": 15.00, "output": 75.00},
    "claude-sonnet-4-6":    {"input": 3.00,  "output": 15.00},
    # ── Anthropic Claude 4.5 ─────────────────────────────────────────────
    "claude-haiku-4-5":     {"input": 0.80,  "output": 4.00},
    # ── Anthropic Claude 4 ────────────────────────────────────────────────
    "claude-opus-4":        {"input": 15.00, "output": 75.00},
    "claude-sonnet-4":      {"input": 3.00,  "output": 15.00},
    # ── Anthropic Claude 3.7 ─────────────────────────────────────────────
    "claude-3-7-sonnet":    {"input": 3.00,  "output": 15.00},
    # ── Anthropic Claude 3.5 ─────────────────────────────────────────────
    "claude-3-5-sonnet":    {"input": 3.00,  "output": 15.00},
    "claude-3-5-haiku":     {"input": 0.80,  "output": 4.00},
    # ── Anthropic Claude 3 ────────────────────────────────────────────────
    "claude-3-opus":        {"input": 15.00, "output": 75.00},
    "claude-3-sonnet":      {"input": 3.00,  "output": 15.00},
    "claude-3-haiku":       {"input": 0.25,  "output": 1.25},

    # ── Google Gemini 2.x / 2.5 ──────────────────────────────────────────
    "gemini-2.5-pro":       {"input": 1.25,  "output": 10.00},
    "gemini-2.5-flash":     {"input": 0.15,  "output": 0.60},
    "gemini-2.0-flash":     {"input": 0.10,  "output": 0.40},
    # ── Google Gemini 1.5 ─────────────────────────────────────────────────
    "gemini-1.5-pro":       {"input": 1.25,  "output": 5.00},
    "gemini-1.5-flash":     {"input": 0.075, "output": 0.30},
    "gemini-1.5-flash-8b":  {"input": 0.0375,"output": 0.15},

    # ── Groq (hosted open models) ─────────────────────────────────────────
    "llama-3.3-70b-versatile":  {"input": 0.59, "output": 0.79},
    "llama-3.1-70b-versatile":  {"input": 0.59, "output": 0.79},
    "llama-3.1-8b-instant":     {"input": 0.05, "output": 0.08},
    "llama3-70b-8192":          {"input": 0.59, "output": 0.79},
    "llama3-8b-8192":           {"input": 0.05, "output": 0.08},
    "mixtral-8x7b-32768":       {"input": 0.24, "output": 0.24},
    "gemma2-9b-it":             {"input": 0.20, "output": 0.20},
}

# Used when a model is not in the table — clearly labelled as estimated.
_FALLBACK_MODEL = "gpt-4o-mini"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def normalize_model(name: str) -> str:
    """Normalise a model identifier to the canonical key used in the table.

    Strips:
      - Leading/trailing whitespace
      - Version date suffixes  ``gpt-4o-2024-08-06`` → ``gpt-4o``
      - Numeric snapshot suffixes  ``gpt-3.5-turbo-0125`` → ``gpt-3.5-turbo``
      - ``-preview`` / ``-latest`` suffixes
    """
    name = name.lower().strip()
    # Remove provider prefix for models passed as "anthropic/claude-3-5-sonnet" etc.
    for prefix in ("anthropic/", "google/", "groq/", "openai/"):
        if name.startswith(prefix):
            name = name[len(prefix):]
            break
    # Date suffix: -YYYY-MM-DD  (e.g. claude-3-5-sonnet-20241022, gpt-4o-2024-08-06)
    name = re.sub(r"-\d{4}-\d{2}-\d{2}$", "", name)
    # Numeric snapshot suffix: -001, -0125, -1106, etc. (3-4 digits)
    name = re.sub(r"-\d{3,4}$", "", name)
    # Anthropic 8-digit date suffix: -20241022
    name = re.sub(r"-\d{8}$", "", name)
    # Word suffixes
    name = re.sub(r"-(preview|latest|turbo-instruct)$", "", name)
    return name


def get_pricing(
    model: str,
    overrides: Optional[Dict[str, Dict[str, float]]] = None,
) -> Tuple[Optional[Dict[str, float]], str]:
    """Return ``(rates_dict, source)`` for *model*.

    *source* is one of:
      ``"backend"``     — from the backend pricing table (most up-to-date)
      ``"sdk_default"`` — from this module's hardcoded table
      ``"estimated"``   — unknown model; using fallback rates

    Args:
        model:     Raw model name as returned by the provider (e.g. ``"gpt-4o-2024-08-06"``).
        overrides: Optional dict fetched from ``GET /pricing`` at session start,
                   keyed by normalised model name.
    """
    normalized = normalize_model(model)

    if overrides and normalized in overrides:
        return overrides[normalized], "backend"

    if normalized in _SDK_PRICING:
        return _SDK_PRICING[normalized], "sdk_default"

    return _SDK_PRICING[_FALLBACK_MODEL], "estimated"


def calculate_cost(
    model: str,
    prompt_tokens: int,
    completion_tokens: int,
    overrides: Optional[Dict[str, Dict[str, float]]] = None,
) -> Tuple[float, dict]:
    """Compute the cost in USD for one LLM call.

    Args:
        model:             Model identifier (raw, will be normalised).
        prompt_tokens:     Number of input tokens consumed.
        completion_tokens: Number of output tokens generated.
        overrides:         Backend pricing dict (``{model: {input, output}}``).
                           When provided, backend prices win over SDK defaults.

    Returns:
        ``(total_cost_usd, meta)`` where *meta* is a dict suitable for storing
        in the event's metadata JSONB::

            {
                "prompt_tokens":     int,
                "completion_tokens": int,
                "total_tokens":      int,
                "input_cost":        float,
                "output_cost":       float,
                "pricing_source":    "backend" | "sdk_default" | "estimated",
                "pricing_version":   str,
            }
    """
    rates, source = get_pricing(model, overrides)

    input_cost  = (prompt_tokens    / 1_000_000) * rates["input"]
    output_cost = (completion_tokens / 1_000_000) * rates["output"]
    total       = input_cost + output_cost

    meta = {
        "prompt_tokens":     prompt_tokens,
        "completion_tokens": completion_tokens,
        "total_tokens":      prompt_tokens + completion_tokens,
        "input_cost":        round(input_cost,  8),
        "output_cost":       round(output_cost, 8),
        "pricing_source":    source,
        "pricing_version":   PRICING_VERSION,
    }

    return round(total, 8), meta


def sdk_pricing_as_overrides() -> Dict[str, Dict[str, float]]:
    """Return the SDK table in the same shape as the backend override dict.

    Useful for seeding the backend's ``pricing`` table on first startup.
    """
    return {
        model: {"input": rates["input"], "output": rates["output"]}
        for model, rates in _SDK_PRICING.items()
    }
