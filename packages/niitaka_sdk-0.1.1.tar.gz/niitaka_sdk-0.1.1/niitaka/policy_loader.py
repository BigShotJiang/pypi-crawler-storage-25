"""policy_loader.py — load, validate, and normalise policy files (YAML or JSON).

Policy file format (YAML example):

    version: "1"
    policies:
      - agent_id: stock_pulse
        type: cost_limit
        priority: 10
        condition:
          cost_exceeded: 2.0
        action:
          type: abort

      - agent_id: stock_pulse
        type: retry
        priority: 5
        condition:
          on_error: true
        action:
          max_retries: 3
          backoff_seconds: 2.0

Supported types: cost_limit, step_limit, retry, fallback
JSON files (.json) are also accepted — same structure, no `version` key required.
"""
from __future__ import annotations

import json
import os
from typing import Dict, List, Optional

from sdk.policy_schemas import KNOWN_TYPES, validate_policy_config, PolicyValidationError


class PolicyFileError(ValueError):
    """Raised when a policy file is malformed or fails validation."""


def _parse_raw(path: str) -> dict:
    """Read and parse a YAML or JSON file into a plain dict."""
    ext = os.path.splitext(path)[1].lower()
    with open(path, "r", encoding="utf-8") as fh:
        content = fh.read()

    if ext in (".yaml", ".yml"):
        try:
            import yaml  # pyyaml
        except ImportError as exc:
            raise PolicyFileError(
                "pyyaml is required to load .yaml policy files: pip install pyyaml"
            ) from exc
        data = yaml.safe_load(content)
    elif ext == ".json":
        data = json.loads(content)
    else:
        raise PolicyFileError(
            f"Unsupported policy file extension '{ext}'. Use .yaml or .json."
        )

    if not isinstance(data, dict):
        raise PolicyFileError(f"Policy file must be a YAML/JSON object, got {type(data).__name__}")
    return data


def _validate_entry(entry: dict, idx: int) -> None:
    """Raise PolicyFileError if a policy entry is missing required fields or
    fails JSON Schema validation for its type."""
    for field in ("agent_id", "type", "condition", "action"):
        if field not in entry:
            raise PolicyFileError(
                f"Policy entry #{idx}: missing required field '{field}'"
            )
    if entry["type"] not in KNOWN_TYPES:
        raise PolicyFileError(
            f"Policy entry #{idx}: unknown type '{entry['type']}'. "
            f"Allowed: {', '.join(sorted(KNOWN_TYPES))}"
        )
    if not isinstance(entry.get("condition"), dict):
        raise PolicyFileError(f"Policy entry #{idx}: 'condition' must be a mapping")
    if not isinstance(entry.get("action"), dict):
        raise PolicyFileError(f"Policy entry #{idx}: 'action' must be a mapping")

    # Deep schema validation
    config = {"condition": entry["condition"], "action": entry["action"]}
    try:
        validate_policy_config(entry["type"], config)
    except PolicyValidationError as exc:
        raise PolicyFileError(f"Policy entry #{idx}: {exc}") from exc


def load_policy_file(path: str) -> List[dict]:
    """Load *path* and return a list of normalised policy dicts.

    Each returned dict matches the format used internally by NiitakaClient:
        {
            "agent_id": str,
            "type": str,
            "condition": dict,
            "action": dict,
            "priority": int,
            "source": "file",
        }

    Raises PolicyFileError on parse or validation failure.
    """
    if not os.path.isfile(path):
        raise PolicyFileError(f"Policy file not found: {path}")

    data = _parse_raw(path)
    raw_entries = data.get("policies", [])
    if not isinstance(raw_entries, list):
        raise PolicyFileError("'policies' key must be a list")

    policies: List[dict] = []
    for i, entry in enumerate(raw_entries, start=1):
        if not isinstance(entry, dict):
            raise PolicyFileError(f"Policy entry #{i} must be a mapping, got {type(entry).__name__}")
        _validate_entry(entry, i)
        policies.append({
            "agent_id":  str(entry["agent_id"]),
            "type":      str(entry["type"]),
            "condition": dict(entry["condition"]),
            "action":    dict(entry["action"]),
            "priority":  int(entry.get("priority", 0)),
            "source":    "file",
        })

    return policies


def group_by_agent(policies: List[dict]) -> Dict[str, List[dict]]:
    """Return policies keyed by agent_id — used by the CLI push command."""
    result: Dict[str, List[dict]] = {}
    for p in policies:
        result.setdefault(p["agent_id"], []).append(p)
    return result


def policies_for_agent(all_policies: List[dict], agent_id: str) -> Optional[List[dict]]:
    """Return file policies for *agent_id*, or None if the agent isn't in the file.

    None (not an empty list) signals "agent not covered by this file — fall back to DB".
    """
    matched = [p for p in all_policies if p["agent_id"] == agent_id]
    return matched if matched else None


def to_yaml_string(policies: List[dict]) -> str:
    """Serialise a list of policy dicts back to a YAML string (for `pull`)."""
    try:
        import yaml
    except ImportError as exc:
        raise PolicyFileError("pyyaml is required: pip install pyyaml") from exc

    entries = []
    for p in policies:
        entry = {
            "agent_id":  p.get("agent_id"),
            "type":      p.get("type"),
            "priority":  p.get("priority", 0),
            "condition": p.get("condition", p.get("config", {}).get("condition", {})),
            "action":    p.get("action",    p.get("config", {}).get("action", {})),
        }
        entries.append(entry)

    return yaml.dump(
        {"version": "1", "policies": entries},
        default_flow_style=False,
        allow_unicode=True,
        sort_keys=False,
    )
