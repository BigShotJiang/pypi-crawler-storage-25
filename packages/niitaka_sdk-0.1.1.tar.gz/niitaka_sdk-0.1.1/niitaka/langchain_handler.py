"""sdk/langchain_handler.py — LangChain callback handler for Niitaka.

Drop-in observability for any LangChain application.

Usage::

    from sdk.langchain_handler import NiitakaCallbackHandler
    import sdk.client as niitaka

    niitaka.configure(api_key="...", api_url="http://localhost:8000")
    handler = NiitakaCallbackHandler()

    with niitaka.start_session(goal="...", agent_id="my-agent"):
        # Pass the handler in the LangChain config dict
        chain.invoke({"input": "..."}, config={"callbacks": [handler]})

Do NOT call ``instrument_openai()`` alongside this handler — the callback
already logs LLM events from the LangChain response object, with richer
chain context.  Using both would double-log every LLM call.

How it works
------------
LangChain (including LangGraph) fires lifecycle callbacks for every chain,
LLM call, and tool invocation in the order they execute.

In LangChain 1.x / LangGraph all callbacks within one graph execution share
the same ``run_id``, so parent-child links via run-id mapping are unreliable.
Instead, ``NiitakaCallbackHandler`` manages ``_event_stack`` directly:

1. ``on_chain_start`` at depth 1 (the root invocation) creates a Niitaka
   ``decision`` event and **pushes** its id onto ``_event_stack``.
2. All ``log_llm`` / ``log_tool`` / ``log_error`` calls made during the
   agent run inherit that parent automatically (``log_event`` reads
   ``_event_stack[-1]`` as the parent).
3. ``on_chain_end`` at depth 0 (matching the root entry) **pops** the id
   off ``_event_stack``, closing the scope cleanly.

The resulting Niitaka event tree looks like::

    [decision]  chain: AgentExecutor
      [llm]     gpt-4o-mini  (first reasoning step)
      [tool]    calculator   (tool call)
      [llm]     gpt-4o-mini  (final answer step)
"""
from __future__ import annotations

import time
from typing import Any, List, Optional
from uuid import UUID

try:
    from langchain_core.callbacks import BaseCallbackHandler
    from langchain_core.messages import BaseMessage
    from langchain_core.outputs import LLMResult
except ImportError as _err:
    raise ImportError(
        "NiitakaCallbackHandler requires langchain-core. "
        "Install it with: pip install langchain-core"
    ) from _err

from .client import client, _event_stack
from .instrumentation import _cost_from_tokens


# ── Internal helpers ──────────────────────────────────────────────────────────

def _chain_name(serialized: dict | None) -> str:
    """Extract a human-readable chain name from a LangChain serialized object.

    ``serialized`` can be ``None`` in LangGraph — handled gracefully.
    """
    if not serialized:
        return "chain"
    name = serialized.get("name")
    if name:
        return name
    id_list = serialized.get("id", [])
    if id_list:
        return id_list[-1]  # e.g. ['langchain', 'chains', 'SequentialChain']
    return "chain"


def _messages_to_str(messages: List[List[BaseMessage]]) -> str:
    """Flatten batched message lists to a readable string for event input."""
    parts: list[str] = []
    for batch in messages:
        for msg in batch:
            role    = getattr(msg, "type", "message")
            content = getattr(msg, "content", "")
            if isinstance(content, list):
                content = " ".join(
                    p.get("text", "") if isinstance(p, dict) else str(p)
                    for p in content
                )
            parts.append(f"{role}: {content}")
    return "\n".join(parts)


def _extract_llm_output(response: LLMResult) -> str:
    """Pull the text content out of an LLMResult."""
    try:
        gen = response.generations[0][0]
        if hasattr(gen, "message"):
            content = gen.message.content
            if isinstance(content, list):
                return " ".join(
                    p.get("text", "") if isinstance(p, dict) else str(p)
                    for p in content
                )
            return str(content)
        return str(getattr(gen, "text", ""))
    except (IndexError, AttributeError):
        return ""


def _extract_tokens(response: LLMResult) -> tuple[int, int]:
    """Extract (prompt_tokens, completion_tokens) from an LLMResult."""
    llm_out    = response.llm_output or {}
    usage      = llm_out.get("token_usage") or llm_out.get("usage") or {}
    prompt_t   = usage.get("prompt_tokens") or usage.get("input_tokens") or 0
    comp_t     = usage.get("completion_tokens") or usage.get("output_tokens") or 0
    return int(prompt_t), int(comp_t)


# ── Handler ───────────────────────────────────────────────────────────────────

class NiitakaCallbackHandler(BaseCallbackHandler):
    """LangChain ``BaseCallbackHandler`` that logs every run to Niitaka.

    Manages ``_event_stack`` directly using a chain-depth counter:

    - Depth 1 (root chain entry) → create root ``decision`` event, push onto stack.
    - All subsequent LLM / tool / error events inherit the root parent.
    - Depth 0 (root chain exit) → pop root event off the stack.

    Thread-safety: LangChain calls callbacks synchronously in the invoking
    thread for sync chains, so stack mutation is safe for single-threaded
    agent usage.

    Attributes:
        _chain_depth:
            Tracks how many ``on_chain_start`` calls we're nested inside.
            Depth 1 is the outermost/root chain.
        _root_event_id:
            The Niitaka event id of the root decision node currently on the
            stack, or ``None`` when no chain is active.
        _llm_starts:
            Stores ``{"time": float, "input": str}`` keyed by ``run_id``
            so ``on_llm_end`` can compute latency and log the input.
        _tool_starts:
            Stores ``{"time": float, "input": str, "name": str}`` keyed by
            ``run_id`` so ``on_tool_end`` can log the full tool call.
    """

    def __init__(self) -> None:
        super().__init__()
        self._chain_depth:   int            = 0
        self._root_event_id: Optional[int]  = None
        self._llm_starts:    dict[UUID, dict] = {}
        self._tool_starts:   dict[UUID, dict] = {}

    # ── Chain callbacks ───────────────────────────────────────────────────────

    def on_chain_start(
        self,
        serialized: dict[str, Any] | None,
        inputs: dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """At the root invocation (depth 1) create a decision event and push it
        onto ``_event_stack`` so all child events are parented correctly.
        """
        self._chain_depth += 1
        if self._chain_depth == 1:
            try:
                name     = _chain_name(serialized)
                event_id = client.log_decision(output=f"chain: {name}")
                if event_id is not None:
                    _event_stack.append(event_id)
                    self._root_event_id = event_id
            except Exception as e:
                print(f"Niitaka on_chain_start failed: {e}")

    def on_chain_end(
        self,
        outputs: dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """At root chain exit, pop the decision event off ``_event_stack``."""
        self._chain_depth -= 1
        if self._chain_depth == 0 and self._root_event_id is not None:
            try:
                if _event_stack and _event_stack[-1] == self._root_event_id:
                    _event_stack.pop()
            except Exception as e:
                print(f"Niitaka on_chain_end failed: {e}")
            self._root_event_id = None

    def on_chain_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Log a chain-level error then close the root scope."""
        try:
            client.log_error(f"{type(error).__name__}: {error}")
        except Exception as e:
            print(f"Niitaka on_chain_error (log) failed: {e}")

        # Clean up the root scope so the stack stays consistent
        self._chain_depth = max(0, self._chain_depth - 1)
        if self._chain_depth == 0 and self._root_event_id is not None:
            try:
                if _event_stack and _event_stack[-1] == self._root_event_id:
                    _event_stack.pop()
            except Exception:
                pass
            self._root_event_id = None

    # ── LLM / chat-model callbacks ────────────────────────────────────────────

    def on_llm_start(
        self,
        serialized: dict[str, Any] | None,
        prompts: list[str],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Record start time and text prompts for completion-style LLMs."""
        self._llm_starts[run_id] = {
            "time":  time.time(),
            "input": "\n---\n".join(prompts),
        }

    def on_chat_model_start(
        self,
        serialized: dict[str, Any] | None,
        messages: list[list[BaseMessage]],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Record start time and formatted messages for chat models."""
        self._llm_starts[run_id] = {
            "time":  time.time(),
            "input": _messages_to_str(messages),
        }

    def on_llm_end(
        self,
        response: LLMResult,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Log the completed LLM call with token counts and calculated cost."""
        start_info = self._llm_starts.pop(run_id, {})
        duration   = time.time() - start_info.get("time", time.time())

        model_name      = (response.llm_output or {}).get("model_name", "")
        prompt_t, comp_t = _extract_tokens(response)
        cost, token_meta = _cost_from_tokens(model_name, prompt_t, comp_t)
        output_text     = _extract_llm_output(response)

        metadata = {
            "provider":   "langchain",
            "model":      model_name,
            "latency":    duration,
            "streaming":  False,
            "status":     "success",
            "error_type": None,
            **token_meta,
        }

        try:
            client.log_llm(
                input=start_info.get("input", ""),
                output=output_text,
                cost=cost,
                metadata=metadata,
            )
        except Exception as e:
            print(f"Niitaka on_llm_end failed: {e}")

    def on_llm_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Log an LLM-level error."""
        self._llm_starts.pop(run_id, None)
        try:
            client.log_error(f"{type(error).__name__}: {error}")
        except Exception as e:
            print(f"Niitaka on_llm_error failed: {e}")

    # ── Tool callbacks ────────────────────────────────────────────────────────

    def on_tool_start(
        self,
        serialized: dict[str, Any] | None,
        input_str: str,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Record the tool name, input string, and start time."""
        self._tool_starts[run_id] = {
            "time":  time.time(),
            "input": input_str,
            "name":  (serialized or {}).get("name", "tool"),
        }

    def on_tool_end(
        self,
        output: Any,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Log the completed tool call as a Niitaka tool event."""
        start_info = self._tool_starts.pop(run_id, {})
        try:
            client.log_tool(
                input=start_info.get("input", ""),
                output=str(output),
            )
        except Exception as e:
            print(f"Niitaka on_tool_end failed: {e}")

    def on_tool_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Log a tool-level error."""
        self._tool_starts.pop(run_id, None)
        try:
            client.log_error(f"{type(error).__name__}: {error}")
        except Exception as e:
            print(f"Niitaka on_tool_error failed: {e}")
