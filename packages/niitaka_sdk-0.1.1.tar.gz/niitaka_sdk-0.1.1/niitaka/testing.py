import time
from .client import log_llm


def fake_llm_call(prompt):
    start = time.time()

    # simulate latency
    time.sleep(0.2)

    response = f"Fake response to: {prompt}"

    duration = time.time() - start

    log_llm(
        input=prompt,
        output=response,
        metadata={
            "model": "fake-llm",
            "latency": duration,
        },
        cost=0,
    )

    return response