"""Niitaka CLI — manage policy files.

Usage:
    python -m sdk.cli push <policy-file> [--url URL] [--key KEY] [--dry-run]
    python -m sdk.cli pull [--agent AGENT_ID] [--url URL] [--key KEY] [-o FILE]
    python -m sdk.cli validate <policy-file>
    python -m sdk.cli history [--agent AGENT_ID] [--limit N] [--url URL] [--key KEY]

Commands
--------
push        Upload policies from a YAML/JSON file to the backend DB.
            By default replaces all existing policies for each agent in the file.

pull        Download current DB policies for one or all agents and print as YAML.
            Use -o to write to a file instead of stdout.

validate    Parse and validate a policy file without contacting the backend.

history     Show the policy audit log — who changed what and when.
            Use --agent to filter to a specific agent.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

import requests


# ── Helpers ───────────────────────────────────────────────────────────────────

def _headers(key: str) -> dict:
    h = {"Content-Type": "application/json"}
    if key:
        h["X-API-Key"] = key
    return h


def _base_url(url: str) -> str:
    return url.rstrip("/")


# ── Commands ──────────────────────────────────────────────────────────────────

def cmd_validate(args: argparse.Namespace) -> int:
    from sdk.policy_loader import load_policy_file, PolicyFileError
    try:
        policies = load_policy_file(args.file)
    except PolicyFileError as exc:
        print(f"[ERROR] {exc}", file=sys.stderr)
        return 1

    from collections import Counter
    counts = Counter(p["agent_id"] for p in policies)
    print(f"✓ Valid policy file — {len(policies)} policies across {len(counts)} agent(s):")
    for agent_id, n in sorted(counts.items()):
        print(f"   {agent_id}: {n} rule(s)")
    return 0


def cmd_push(args: argparse.Namespace) -> int:
    from sdk.policy_loader import load_policy_file, group_by_agent, PolicyFileError

    # Validate file first
    try:
        policies = load_policy_file(args.file)
    except PolicyFileError as exc:
        print(f"[ERROR] {exc}", file=sys.stderr)
        return 1

    grouped = group_by_agent(policies)
    base = _base_url(args.url)
    headers = _headers(args.key)

    print(f"[niitaka push] {args.file} → {base}")
    print(f"  Agents: {', '.join(sorted(grouped))}")

    if args.dry_run:
        print("  [dry-run] No changes made.")
        return 0

    # Build import payload: list of policy objects with agent_id + config
    payload_policies = []
    for p in policies:
        payload_policies.append({
            "agent_id":  p["agent_id"],
            "type":      p["type"],
            "config": {
                "condition": p["condition"],
                "action":    p["action"],
                "priority":  p["priority"],
            },
        })

    try:
        resp = requests.post(
            f"{base}/policies/import",
            headers=headers,
            json={"policies": payload_policies, "replace": True},
            timeout=15,
        )
        resp.raise_for_status()
    except requests.HTTPError as exc:
        print(f"[ERROR] Backend returned {exc.response.status_code}: {exc.response.text}",
              file=sys.stderr)
        return 1
    except requests.RequestException as exc:
        print(f"[ERROR] Could not reach backend at {base}: {exc}", file=sys.stderr)
        return 1

    result = resp.json()
    print(f"  ✓ Imported {result.get('imported', '?')} policies "
          f"(replaced {result.get('deleted', '?')} existing)")
    for agent_id, n in sorted(result.get("by_agent", {}).items()):
        print(f"     {agent_id}: {n} rule(s) written")
    return 0


def cmd_pull(args: argparse.Namespace) -> int:
    from sdk.policy_loader import to_yaml_string

    base = _base_url(args.url)
    headers = _headers(args.key)

    if args.agent:
        # Single agent
        try:
            resp = requests.get(f"{base}/policies/{args.agent}", headers=headers, timeout=10)
            resp.raise_for_status()
        except requests.RequestException as exc:
            print(f"[ERROR] {exc}", file=sys.stderr)
            return 1
        raw = resp.json()
        # Attach agent_id (not in per-agent response)
        for p in raw:
            p["agent_id"] = args.agent
    else:
        # All policies
        try:
            resp = requests.get(f"{base}/policies", headers=headers, timeout=10)
            resp.raise_for_status()
        except requests.RequestException as exc:
            print(f"[ERROR] {exc}", file=sys.stderr)
            return 1
        raw = resp.json()

    if not raw:
        print("# No policies found.", file=sys.stderr)
        return 0

    yaml_text = to_yaml_string(raw)

    if args.output:
        with open(args.output, "w", encoding="utf-8") as fh:
            fh.write(yaml_text)
        print(f"[niitaka pull] Wrote {len(raw)} policies to {args.output}")
    else:
        sys.stdout.write(yaml_text)

    return 0


def cmd_history(args: argparse.Namespace) -> int:
    base    = _base_url(args.url)
    headers = _headers(args.key)

    url = f"{base}/policies/audit"
    if args.agent:
        url = f"{base}/policies/audit/{args.agent}"
    url += f"?limit={args.limit}"

    try:
        resp = requests.get(url, headers=headers, timeout=10)
        resp.raise_for_status()
    except requests.RequestException as exc:
        print(f"[ERROR] {exc}", file=sys.stderr)
        return 1

    entries = resp.json()
    if not entries:
        print("No audit log entries found.")
        return 0

    # Column widths
    W_TIME   = 20
    W_AGENT  = 20
    W_ACTION = 8
    W_TYPE   = 12
    W_SOURCE = 6

    header = (
        f"{'Timestamp':<{W_TIME}}  "
        f"{'Agent':<{W_AGENT}}  "
        f"{'Action':<{W_ACTION}}  "
        f"{'Type':<{W_TYPE}}  "
        f"{'Src':<{W_SOURCE}}"
    )
    print(header)
    print("─" * len(header))

    for e in entries:
        ts = e.get("created_at", "")
        # Trim to readable format: "2026-04-12T14:32:01"
        if ts and "T" in ts:
            ts = ts[:19].replace("T", " ")

        action  = e.get("action", "")
        agent   = (e.get("agent_id") or "")[:W_AGENT]
        ptype   = (e.get("policy_type") or "—")[:W_TYPE]
        source  = (e.get("source") or "")[:W_SOURCE]

        print(
            f"{ts:<{W_TIME}}  "
            f"{agent:<{W_AGENT}}  "
            f"{action:<{W_ACTION}}  "
            f"{ptype:<{W_TYPE}}  "
            f"{source:<{W_SOURCE}}"
        )

    print(f"\n{len(entries)} entries")
    return 0


# ── Argument parser ───────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m sdk.cli",
        description="Niitaka policy file manager",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # Shared backend args
    def add_backend_args(p: argparse.ArgumentParser) -> None:
        p.add_argument("--url", default=os.getenv("NIITAKA_BACKEND_URL", "http://localhost:8000"),
                       help="Backend URL (default: $NIITAKA_BACKEND_URL or http://localhost:8000)")
        p.add_argument("--key", default=os.getenv("NIITAKA_API_KEY", ""),
                       help="API key (default: $NIITAKA_API_KEY)")

    # validate
    p_val = sub.add_parser("validate", help="Validate a policy file without hitting the backend")
    p_val.add_argument("file", help="Path to policy YAML or JSON file")

    # push
    p_push = sub.add_parser("push", help="Upload policy file to backend DB")
    p_push.add_argument("file", help="Path to policy YAML or JSON file")
    p_push.add_argument("--dry-run", action="store_true",
                        help="Validate and show what would be pushed, but make no changes")
    add_backend_args(p_push)

    # pull
    p_pull = sub.add_parser("pull", help="Download policies from backend as YAML")
    p_pull.add_argument("--agent", default=None, help="Filter to a single agent_id")
    p_pull.add_argument("-o", "--output", default=None, help="Write to file instead of stdout")
    add_backend_args(p_pull)

    # history
    p_hist = sub.add_parser("history", help="Show the policy audit log")
    p_hist.add_argument("--agent", default=None, help="Filter to a single agent_id")
    p_hist.add_argument("--limit", type=int, default=50,
                        help="Max entries to show (default: 50)")
    add_backend_args(p_hist)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    dispatch = {"validate": cmd_validate, "push": cmd_push, "pull": cmd_pull, "history": cmd_history}
    sys.exit(dispatch[args.command](args))


if __name__ == "__main__":
    main()
