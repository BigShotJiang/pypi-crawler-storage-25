import operator
import random
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from pydantic import BaseModel

OPS = {
    ">": operator.gt,
    "<": operator.lt,
    ">=": operator.ge,
    "<=": operator.le,
    "==": operator.eq,
}


# ── Evaluation stage ──────────────────────────────────────────────────────────

class EvaluationStage(str, Enum):
    """Identifies when in the execution lifecycle a policy was evaluated."""

    PRE_EXECUTION = "pre_execution"
    ON_ERROR = "on_error"
    POST_SUCCESS = "post_success"


# ── Typed context contract ────────────────────────────────────────────────────

class PolicyContext(BaseModel):
    """Strict schema for the context dict passed to evaluate_policies.

    All fields are always present so policy conditions never hit a missing-key
    branch.  Callers build this from _session_state before each evaluation.
    """

    error_type: Optional[str] = None
    attempts: int = 0
    total_steps: int = 0
    fallback_used: bool = False
    cost: float = 0.0


# ── Resolution reason ─────────────────────────────────────────────────────────

class ResolutionReason(str, Enum):
    """Structured reason code for how a conflict was resolved.

    Using an enum instead of free text makes UI filtering and aggregation
    straightforward.
    """

    NO_MATCH = "no_match"
    HIGHER_PRECEDENCE = "higher_precedence"   # stop beats retry, etc.
    HIGHER_PRIORITY = "higher_priority"        # same type, higher priority wins
    ONLY_MATCH = "only_match"                  # single action type, no conflict


# ── Action hierarchy ──────────────────────────────────────────────────────────

# Fixed action hierarchy — non-negotiable precedence.
# stop    : must override everything (safety boundary)
# fallback: strategic shift — abandon the failing path
# retry   : local recovery — try again on same path
# ignore  : lowest signal — no action taken
ACTION_PRECEDENCE = ["stop", "fallback", "retry", "ignore"]


# ── Data classes ──────────────────────────────────────────────────────────────

@dataclass
class Action:
    """Normalized action produced by a matched policy."""

    type: str                                    # "stop" | "fallback" | "retry" | "ignore"
    priority: int                                # higher priority wins within the same type
    params: dict = field(default_factory=dict)   # e.g. {"max_retries": 5} or {"model": "gpt-4"}
    policy_id: Optional[str] = None              # originating policy id
    policy_type: Optional[str] = None            # originating policy type (for tracing)


@dataclass
class ResolutionTrace:
    """Records how resolve_actions() arrived at the final decision."""

    candidate_actions: list        # all action dicts from all matched policies
    winning_type: Optional[str]    # the type that won by precedence
    winner: Optional[dict]         # the final selected action serialized as a dict
    resolution_reason: str         # ResolutionReason enum value (stored as string)


# ── Condition matching ────────────────────────────────────────────────────────

def _parse_condition(expr: str) -> tuple:
    """Parse a comparison expression like '>=10.0' into (op_fn, float_value).

    Checks longest operators first to avoid '>=' being parsed as '>'.
    """
    for op in (">=", "<=", ">", "<", "=="):
        if expr.startswith(op):
            try:
                return OPS[op], float(expr[len(op):])
            except ValueError:
                return None, None
    return None, None


def _match_condition(condition: dict, context: dict) -> bool:
    """Return True only when every key/value pair in condition matches context.

    Special boolean keys handled explicitly before numeric/string comparison:
      ``on_error: true``  — matches when ``context["error_type"]`` is not None.
      ``on_error: false`` — matches when ``context["error_type"]`` is None.
    These are used by the ``retry`` and ``fallback`` policy types whose schema
    uses ``on_error`` as a trigger flag rather than a raw context field.
    """
    for key, expected in condition.items():

        # ── on_error boolean shorthand ─────────────────────────────────────────
        if key == "on_error" and isinstance(expected, bool):
            has_error = context.get("error_type") is not None
            if has_error != expected:
                return False
            continue

        actual = context.get(key)

        # string equality — no operator prefix
        if isinstance(expected, str) and not any(
            expected.startswith(op) for op in (">=", "<=", ">", "<", "==")
        ):
            if actual != expected:
                return False

        # numeric comparison
        else:
            op_fn, value = _parse_condition(str(expected))
            if op_fn is None or actual is None:
                return False
            try:
                if not op_fn(float(actual), value):
                    return False
            except (TypeError, ValueError):
                return False

    return True


# ── Core evaluation ───────────────────────────────────────────────────────────

def evaluate_policies(
    policies: list,
    context: PolicyContext,
    stage: EvaluationStage,
) -> list:
    """Evaluate all policies against a typed PolicyContext for a given stage.

    Returns ALL matched Action objects — not just the winner.
    Pass the result to resolve_actions() to get the final decision.

    The stage parameter is currently recorded in traces for observability;
    future iterations can use it to restrict which policies fire per stage.
    """
    matched: list[Action] = []
    context_dict = context.model_dump()

    for policy in policies:
        condition = policy.get("condition")
        action_cfg = policy.get("action")

        if not condition or not action_cfg:
            continue

        if _match_condition(condition, context_dict):
            # on_errors filtering: if the action specifies a non-empty list of error
            # type names, only match when context["error_type"] is in that list.
            on_errors = action_cfg.get("on_errors") or []
            if on_errors and context_dict.get("error_type") not in on_errors:
                continue

            print("✅ POLICY MATCHED:", policy)
            policy_type = policy.get("policy_type", policy.get("type", ""))

            # For ``retry`` and ``fallback`` policy types the schema omits the
            # ``action.type`` key (it's implied by the policy type itself).
            # Inject it so the engine can route correctly.
            implied_action_type = {"retry": "retry", "fallback": "fallback"}.get(policy_type)
            action_type = action_cfg.get("type") or implied_action_type or "ignore"

            matched.append(Action(
                type=action_type,
                priority=policy.get("priority", 0),
                params={k: v for k, v in action_cfg.items() if k != "type"},
                policy_id=str(policy.get("id", "")),
                policy_type=policy_type,
            ))

    return matched


# ── Conflict resolution ───────────────────────────────────────────────────────

def resolve_actions(actions: list) -> tuple:
    """Deterministically resolve a list of candidate actions into a single final decision.

    Resolution algorithm:
      1. Group candidates by action type.
      2. Pick the highest-precedence type (stop > fallback > retry > ignore).
      3. Within the winning type, pick the highest-priority action.

    Returns (selected_action | None, ResolutionTrace).
    """
    if not actions:
        return None, ResolutionTrace(
            candidate_actions=[],
            winning_type=None,
            winner=None,
            resolution_reason=ResolutionReason.NO_MATCH,
        )

    candidate_dicts = [
        {
            "type": a.type,
            "priority": a.priority,
            "params": a.params,
            "policy_id": a.policy_id,
            "policy_type": a.policy_type,
        }
        for a in actions
    ]

    grouped: dict = {}
    for a in actions:
        grouped.setdefault(a.type, []).append(a)

    for action_type in ACTION_PRECEDENCE:
        if action_type not in grouped:
            continue

        candidates = grouped[action_type]
        selected = max(candidates, key=lambda a: a.priority)

        winner_dict = {
            "type": selected.type,
            "priority": selected.priority,
            "params": selected.params,
            "policy_id": selected.policy_id,
            "policy_type": selected.policy_type,
        }

        if len(grouped) > 1:
            reason = ResolutionReason.HIGHER_PRECEDENCE
        elif len(candidates) > 1:
            reason = ResolutionReason.HIGHER_PRIORITY
        else:
            reason = ResolutionReason.ONLY_MATCH

        return selected, ResolutionTrace(
            candidate_actions=candidate_dicts,
            winning_type=action_type,
            winner=winner_dict,
            resolution_reason=reason,
        )

    # Unreachable if ACTION_PRECEDENCE covers all known types, but kept for safety.
    return None, ResolutionTrace(
        candidate_actions=candidate_dicts,
        winning_type=None,
        winner=None,
        resolution_reason=ResolutionReason.NO_MATCH,
    )
