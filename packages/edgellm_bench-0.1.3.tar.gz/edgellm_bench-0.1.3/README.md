# edgellm-bench

CLI tool for benchmarking TensorRT Edge-LLM models. Automates the full pipeline: **download ONNX model -> build TensorRT engine -> run benchmark**.

Supports standard LLM, VLM (vision-language model backbone), and Eagle speculative decoding models.

## Prerequisites

- Python >= 3.10
- TensorRT Edge-LLM SDK built (`llm_build`, `llm_bench`, `llm_inference` executables)
- NVIDIA GPU with TensorRT support
- Network access to NAS server (for model download)

## Setup

```bash
# From the edgellm-bench directory
pip install -e .
```

### Environment Variables (optional)

| Variable | Description | Default |
|----------|-------------|---------|
| `BUILD_DIR` | Directory containing `llm_build` / `llm_bench` / `llm_inference` | `build` |
| `LLM_SDK_DIR` | Edge-LLM SDK root (uses `$LLM_SDK_DIR/build`) | — |
| `TRT_PACKAGE_DIR` | TensorRT package dir (sets `LD_LIBRARY_PATH`) | — |

You can also pass `--build-dir` explicitly on each command.

## Commands

```
edgellm-bench list    List available models and precisions from NAS
edgellm-bench run     Download, build, and benchmark (one command)
edgellm-bench infer   Run end-to-end inference on pre-built engines
```

## Usage

### List available models

```bash
edgellm-bench list
edgellm-bench list --json
```

### Standard LLM benchmark (download + build + bench)

Runs `llm_bench` for kernel-level **prefill + decode** performance.

```bash
# FP16
edgellm-bench run --model Qwen3-0.6B --precision llm-fp16-fp16

# Quantized (fp8, nvfp4, int4_awq)
edgellm-bench run --model Qwen3-0.6B --precision llm-fp8-fp16
edgellm-bench run --model Qwen3-0.6B --precision llm-nvfp4-fp16
edgellm-bench run --model Qwen3-0.6B --precision llm-int4_awq-fp16

# VLM backbone (LLM part of vision-language models)
edgellm-bench run --model InternVL3-1B --precision llm-fp8-fp16

# Single mode only
edgellm-bench run --model Qwen3-0.6B --precision llm-fp16-fp16 --mode decode
```

### Eagle speculative decoding benchmark (single command)

When `--precision` starts with `llm-base-*`, Eagle mode is activated automatically:
1. Downloads both base and draft ONNX models
2. Builds both engines into a shared directory
3. Runs `llm_inference --eagle` with 100 MT-Bench prompts for end-to-end decode perf

```bash
# Single command — builds both base + draft, then runs eagle inference
edgellm-bench run --model Qwen3-1.7B --precision llm-base-nvfp4-fp16

# Custom draft precision (default: auto-derived as draft-eagle3-<quant>-<lmhead>)
edgellm-bench run --model Qwen3-1.7B --precision llm-base-nvfp4-fp16 \
    --draft-precision draft-eagle3-fp16-fp16

# Control generation length
edgellm-bench run --model Qwen3-1.7B --precision llm-base-nvfp4-fp16 \
    --max-generate-length 1024
```

Output includes acceptance rate and tokens/s:
```
Eagle mode: base=llm-base-nvfp4-fp16  draft=draft-eagle3-nvfp4-fp16

eagle_inference (MT-Bench, 100 prompts):
  Warmup: 10  Max Generate Length: 512
  Total Tokens: 51200  Iterations: 12800
  Prefill: 2345.6 tokens/s
  >>> Acceptance Rate: 0.78  |  Decode: 156.3 tokens/s
  Peak Memory: 1234.5 MB
```

### End-to-end inference benchmark (pre-built engines)

Use `infer` when you already have built engines and want to run `llm_inference` directly.

```bash
# Eagle inference
edgellm-bench infer --engine-dir ~/.cache/edgellm-bench/engines/Qwen3-1.7B/eagle --eagle

# Standard inference
edgellm-bench infer --engine-dir ~/.cache/edgellm-bench/engines/Qwen3-0.6B/llm-fp16-fp16

# Custom input file instead of built-in MT-Bench prompts
edgellm-bench infer --engine-dir /path/to/engines --eagle --input-file my_prompts.json

# Pass extra flags to llm_inference
edgellm-bench infer --engine-dir /path/to/engines --eagle \
    --extra-infer-args --draftTopK=20 --draftStep=8
```

### Benchmark parameters

```bash
# Standard LLM kernel benchmark
edgellm-bench run --model Qwen3-0.6B --precision llm-fp16-fp16 \
    --iterations 100 \
    --warmup 10 \
    --input-len 1024 \
    --max-seq-len 4096 \
    --max-input-len 2048

# Eagle inference benchmark
edgellm-bench run --model Qwen3-1.7B --precision llm-base-nvfp4-fp16 \
    --warmup 3 \
    --max-generate-length 512
```

Note: In Eagle mode, `--iterations`, `--input-len`, and `--mode` are ignored (a warning is printed).
Eagle uses `--warmup` and `--max-generate-length` instead.

### Skip steps

```bash
# Skip download (reuse cached ONNX)
edgellm-bench run --model Qwen3-0.6B --precision llm-fp16-fp16 --skip-download

# Skip download and build (reuse cached engine, benchmark only)
edgellm-bench run --model Qwen3-0.6B --precision llm-fp16-fp16 --skip-download --skip-build
```

### Pass extra args to underlying executables

```bash
# Extra args for llm_build
edgellm-bench run --model Qwen3-0.6B --precision llm-fp16-fp16 \
    --extra-build-args --maxBatchSize=4

# Extra args for llm_bench (standard mode)
edgellm-bench run --model Qwen3-0.6B --precision llm-fp16-fp16 \
    --extra-bench-args --dumpDetailedLayerProfile

# Extra args for llm_inference (Eagle mode)
edgellm-bench run --model Qwen3-1.7B --precision llm-base-nvfp4-fp16 \
    --extra-infer-args --draftTopK=20 --verifyTreeSize=80
```

## Precision String Format

The `--precision` flag follows this naming convention:

| Pattern | Type | Example |
|---------|------|---------|
| `llm-<quant>-<lmhead>` | Standard LLM | `llm-fp16-fp16`, `llm-fp8-fp16`, `llm-nvfp4-fp16` |
| `llm-<quant>-<lmhead>-fp8kv` | LLM with FP8 KV cache | `llm-nvfp4-fp16-fp8kv` |
| `llm-<quant>-<lmhead>-rvs<N>` | LLM with reduced vocab | `llm-fp16-fp16-rvs16384` |
| `llm-base-<quant>-<lmhead>` | Eagle base model | `llm-base-fp8-fp16`, `llm-base-nvfp4-fp16` |
| `draft-eagle3-<quant>-<lmhead>` | Eagle draft model | `draft-eagle3-fp16-fp16` |
| `visual-<quant>` | Vision encoder (ViT) | `visual-fp16`, `visual-fp8` |

Supported quantization types: `fp16`, `fp8`, `nvfp4`, `int4_awq`, `mxfp8`, `int8_sq`.

## Auto-detection

The tool automatically detects model type from the precision string and selects the appropriate workflow:

| Precision pattern | Build flag | Benchmark tool | Default mode |
|-------------------|-----------|---------------|--------------|
| `llm-base-*` (Eagle) | `--eagleBase` | `llm_inference --eagle` | MT-Bench 100 prompts |
| `draft-*` (Eagle draft only) | `--eagleDraft` | `llm_bench` | `eagle_draft_prefill` |
| `llm-*` (standard) | — | `llm_bench` | `prefill` + `decode` |

For Eagle base models, the draft precision is auto-derived:
`llm-base-<quant>-<lmhead>` -> `draft-eagle3-<quant>-<lmhead>`

## Cache Layout

```
~/.cache/edgellm-bench/
  onnx/
    <model>/<precision>/         # Downloaded ONNX files
  engines/
    <model>/<precision>/         # Standard engines + bench logs
    <model>/eagle/               # Eagle engines (base + draft together)
```

Use `rm -rf ~/.cache/edgellm-bench` to clear all cached data.

## Project Structure

```
edgellm_bench/
  __main__.py          CLI entry point (list, run, infer subcommands)
  config.py            Default parameters and path resolution
  nas_client.py        NAS server client (list + download ONNX models)
  engine_builder.py    Wraps llm_build for TensorRT engine building
  benchmark_runner.py  Wraps llm_bench for kernel-level benchmarks
  inference_runner.py  Wraps llm_inference for end-to-end inference benchmarks
  utils.py             Shared utilities (executable finder, env setup, eagle helpers)
```
