import os
from pathlib import Path

DEFAULT_NAS_BASE_URL = (
    "http://dlswqa-nas.nvidia.com:8080/mobile/data/modelopt-trt-data/"
    "drive-llm/modelopt-0.39.0/tensorrt-edge-llm-release-0.6.0/"
)

DEFAULT_CACHE_DIR = Path("tmp")
DEFAULT_ONNX_DIR = DEFAULT_CACHE_DIR / "onnx"
DEFAULT_ENGINE_DIR = DEFAULT_CACHE_DIR / "engines"

# Directories to skip when listing precision variants
IGNORED_SUBDIRS = {"quantized", "quantized-base", "quantized-kvcache", "quantized-draft"}

# Default benchmark parameters
DEFAULT_MAX_SEQ_LEN = 4096
DEFAULT_MAX_BATCH_SIZE = 1
DEFAULT_MAX_INPUT_LEN = 2048
DEFAULT_BATCH_SIZE = 1
DEFAULT_WARMUP = 10
DEFAULT_ITERATIONS = 100
DEFAULT_INPUT_LEN = 1024


def get_build_dir():
    """Resolve build directory from env vars or default."""
    build_dir = os.environ.get("BUILD_DIR")
    if build_dir:
        return build_dir
    llm_sdk_dir = os.environ.get("LLM_SDK_DIR")
    if llm_sdk_dir:
        return os.path.join(llm_sdk_dir, "build")
    return "build"


def _parse_cmake_cache(build_dir, variable):
    """Extract a variable value from CMakeCache.txt in the build directory."""
    cache_file = os.path.join(build_dir, "CMakeCache.txt")
    if not os.path.isfile(cache_file):
        return None
    prefix = f"{variable}:"
    with open(cache_file) as f:
        for line in f:
            if line.startswith(prefix):
                # Format: VAR_NAME:TYPE=VALUE
                _, _, value = line.partition("=")
                return value.strip()
    return None


def get_trt_lib_paths():
    """Get TensorRT library paths for LD_LIBRARY_PATH.

    Checks (in order):
    1. TRT_PACKAGE_DIR env var  — explicit override
    2. TRT_PACKAGE_DIR from CMakeCache.txt — auto-detected from build dir
    3. LLM_SDK_DIR/lib          — SDK-bundled TRT libs
    4. <build_dir>/../lib       — libs relative to the build directory

    Returns a list of existing directories.
    """
    paths = []
    build_dir = get_build_dir()

    def _add(d):
        if d and os.path.isdir(d) and d not in paths:
            paths.append(d)

    # 1. Explicit env var
    trt_dir = os.environ.get("TRT_PACKAGE_DIR")
    if trt_dir:
        _add(os.path.join(trt_dir, "lib"))

    # 2. Auto-detect from CMakeCache.txt in the build directory
    if build_dir:
        cmake_trt = _parse_cmake_cache(build_dir, "TRT_PACKAGE_DIR")
        if cmake_trt:
            _add(os.path.join(cmake_trt, "lib"))

    # 3. SDK-level lib/
    llm_sdk_dir = os.environ.get("LLM_SDK_DIR")
    if llm_sdk_dir:
        _add(os.path.join(llm_sdk_dir, "lib"))

    # 4. Infer from build dir: build/ sits inside the SDK root, so ../lib
    if build_dir:
        _add(os.path.normpath(os.path.join(build_dir, os.pardir, "lib")))

    return paths
