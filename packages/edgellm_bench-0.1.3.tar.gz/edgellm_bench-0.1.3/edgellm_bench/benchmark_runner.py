"""Benchmark runner — wraps the llm_bench C++ executable."""

import os
import re
import subprocess
import sys

from .config import get_build_dir
from .utils import find_executable, get_subprocess_env, has_eagle_engines, is_eagle_base, is_eagle_draft


def _parse_benchmark_output(output: str) -> dict:
    """Parse benchmark output for performance metrics.

    Parses from the "Bench Config" and "Results" sections to get the actual
    bench parameters (not the engine's max capabilities).
    """
    metrics = {}

    # Parse from "Results:" section at end of output
    results_match = re.search(r"Results:(.+)", output, re.DOTALL)
    results_section = results_match.group(1) if results_match else output

    avg_match = re.search(r"Avg Time:\s*([\d.]+)\s*ms", results_section)
    if avg_match:
        metrics["avg_time_ms"] = float(avg_match.group(1))

    mode_match = re.search(r"Mode:\s*(\w+)", results_section)
    if mode_match:
        metrics["mode"] = mode_match.group(1)

    # Parse from "Bench Config:" section for actual bench parameters
    bench_section_match = re.search(r"Bench Config:(.+?)(?:Mode [A-Z]|Running Benchmark)", output, re.DOTALL)
    bench_section = bench_section_match.group(1) if bench_section_match else output

    for pattern, key in [
        (r"Batch Size:\s*(\d+)", "batch_size"),
        (r"Iterations:\s*(\d+)", "iterations"),
        (r"Input Len:\s*(\d+)", "input_len"),
        (r"Verify Tree Size:\s*(\d+)", "verify_tree_size"),
        (r"Draft Tree Size:\s*(\d+)", "draft_tree_size"),
    ]:
        match = re.search(pattern, bench_section)
        if match:
            metrics[key] = int(match.group(1))

    # Compute throughput in Python based on mode and parsed parameters
    mode = metrics.get("mode", "")
    avg_ms = metrics.get("avg_time_ms", 0)
    batch_size = metrics.get("batch_size", 1)
    if avg_ms > 0:
        if mode in ("prefill", "eagle_draft_prefill"):
            tokens_per_iter = metrics.get("input_len", 0) * batch_size
        elif mode == "decode":
            tokens_per_iter = 1 * batch_size
        elif mode == "eagle_verify":
            tokens_per_iter = metrics.get("verify_tree_size", 0) * batch_size
        elif mode == "eagle_draft_proposal":
            tokens_per_iter = metrics.get("draft_tree_size", 0) * batch_size
        else:
            tokens_per_iter = 0
        if tokens_per_iter > 0:
            metrics["throughput_tokens_per_sec"] = tokens_per_iter * 1000.0 / avg_ms

    return metrics


def _parse_engine_config(output: str) -> dict:
    """Extract engine config from llm_bench output."""
    config = {}
    section = re.search(r"Base Engine Config:(.+?)Bench Config:", output, re.DOTALL)
    if not section:
        return config
    text = section.group(1)
    for pattern, key in [
        (r"Layers:\s*(\d+)", "layers"),
        (r"KV Heads:\s*(\d+)", "kv_heads"),
        (r"Head Dim:\s*(\d+)", "head_dim"),
        (r"Hidden Size:\s*(\d+)", "hidden_size"),
        (r"Vocab Size:\s*(\d+)", "vocab_size"),
        (r"Max Supported Batch Size:\s*(\d+)", "max_batch_size"),
        (r"Max Supported Input Length:\s*(\d+)", "max_input_len"),
        (r"Max KV Cache Capacity:\s*(\d+)", "max_kv_cache"),
        (r"Eagle Enable:\s*(\w+)", "eagle_enable"),
    ]:
        match = re.search(pattern, text)
        if match:
            val = match.group(1)
            config[key] = val if key == "eagle_enable" else int(val)
    return config


def _default_modes_for_precision(precision: str) -> list[str]:
    """Return the default benchmark modes for a given precision string.

    Eagle base  -> ['eagle_verify']
    Eagle draft -> ['eagle_draft_prefill']
    Standard    -> ['prefill', 'decode']
    """
    if not precision:
        return ["prefill", "decode"]
    if is_eagle_base(precision):
        return ["eagle_verify"]
    if is_eagle_draft(precision):
        return ["eagle_draft_prefill"]
    return ["prefill", "decode"]


def _run_single_benchmark(
    llm_bench: str,
    engine_dir: str,
    batch_size: int,
    warmup: int,
    iterations: int,
    mode: str,
    input_len: int | None,
    extra_args: list | None,
) -> dict:
    """Run a single benchmark invocation for one mode."""
    cmd = [
        llm_bench,
        f"--engineDir={engine_dir}",
        f"--batchSize={batch_size}",
        f"--warmup={warmup}",
        f"--iterations={iterations}",
        f"--mode={mode}",
    ]

    # Add required tree size args for eagle modes
    if mode == "eagle_verify":
        cmd.append("--verifyTreeSize=60")
    elif mode in ("eagle_draft_proposal", "eagle_draft_prefill"):
        cmd.append("--draftTreeSize=10")
    if input_len is not None:
        cmd.append(f"--inputLen={input_len}")
    if extra_args:
        cmd.extend(extra_args)

    log_path = os.path.join(engine_dir, f"bench_{mode}.log")

    try:
        with open(log_path, "w") as log_file:
            log_file.write(f"$ {' '.join(cmd)}\n\n")
            proc = subprocess.Popen(
                cmd,
                env=get_subprocess_env(),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )
            output_lines = []
            for line in proc.stdout:
                log_file.write(line)
                log_file.flush()
                output_lines.append(line)
            proc.wait(timeout=600)
        output = "".join(output_lines)
        if proc.returncode != 0:
            # Print last 20 lines to terminal on failure
            print(f"  FAILED (exit code {proc.returncode}). Last lines:")
            for line in output_lines[-20:]:
                sys.stdout.write(f"    {line}")
            return {
                "success": False,
                "output": output,
                "error": f"llm_bench exited with code {proc.returncode}",
                "metrics": {},
                "engine_config": {},
                "log_path": log_path,
                "cmd": " ".join(cmd),
            }
        metrics = _parse_benchmark_output(output)
        engine_config = _parse_engine_config(output)
        return {
            "success": True,
            "output": output,
            "error": None,
            "metrics": metrics,
            "engine_config": engine_config,
            "log_path": log_path,
            "cmd": " ".join(cmd),
        }
    except subprocess.TimeoutExpired:
        proc.kill()
        return {"success": False, "output": "", "error": "Benchmark timed out (600s)",
                "metrics": {}, "engine_config": {}, "log_path": log_path, "cmd": " ".join(cmd)}
    except Exception as e:
        return {"success": False, "output": "", "error": str(e),
                "metrics": {}, "engine_config": {}, "log_path": log_path, "cmd": " ".join(cmd)}


def run_benchmark(
    engine_dir: str,
    build_dir: str = None,
    batch_size: int = 1,
    warmup: int = 10,
    iterations: int = 100,
    mode: str = None,
    input_len: int = None,
    precision: str = None,
    extra_args: list = None,
) -> dict:
    """Run benchmark for a model.

    For Eagle base models with both engines present: uses llm_inference --eagle
    to collect end-to-end prefill and decode perf (MT-Bench prompts).

    For standard models (or explicit mode override): uses llm_bench for
    kernel-level benchmarks (prefill + decode).
    """
    if build_dir is None:
        build_dir = get_build_dir()

    # Eagle auto-detection: use llm_inference for e2e perf when both engines exist
    if mode is None and is_eagle_base(precision) and has_eagle_engines(engine_dir):
        from .inference_runner import run_eagle_inference

        return run_eagle_inference(
            engine_dir=engine_dir,
            build_dir=build_dir,
            warmup=warmup,
            batch_size=batch_size,
            extra_args=extra_args,
        )

    llm_bench = find_executable(build_dir, "llm_bench")

    # Determine which modes to run
    if mode is not None:
        modes = [mode]
    else:
        modes = _default_modes_for_precision(precision)

    all_output = []
    all_metrics = {}
    results = []  # collect (mode, result) for final summary

    for i, m in enumerate(modes):
        result = _run_single_benchmark(
            llm_bench=llm_bench,
            engine_dir=engine_dir,
            batch_size=batch_size,
            warmup=warmup,
            iterations=iterations,
            mode=m,
            input_len=input_len,
            extra_args=extra_args,
        )

        all_output.append(result["output"])
        results.append((m, result))

        if not result["success"]:
            return {
                "success": False,
                "output": "\n".join(all_output),
                "error": f"[mode={m}] {result['error']}",
                "metrics": all_metrics,
            }

        # Prefix metrics with mode name when running multiple modes
        if len(modes) > 1:
            for key, value in result["metrics"].items():
                all_metrics[f"{m}/{key}"] = value
        else:
            all_metrics = result["metrics"]

    # Print clean summary to terminal
    # Engine config (from first mode)
    first_result = results[0][1]
    ec = first_result.get("engine_config", {})
    if ec:
        print(f"\nEngine: {engine_dir}")
        print(f"  Layers: {ec.get('layers', '?')}  Hidden: {ec.get('hidden_size', '?')}  "
              f"KV Heads: {ec.get('kv_heads', '?')}  Head Dim: {ec.get('head_dim', '?')}  "
              f"Vocab: {ec.get('vocab_size', '?')}")
        print(f"  Max Batch: {ec.get('max_batch_size', '?')}  "
              f"Max Input: {ec.get('max_input_len', '?')}  "
              f"Max KV Cache: {ec.get('max_kv_cache', '?')}  "
              f"Eagle: {ec.get('eagle_enable', '?')}")

    # Per-mode results
    for m, result in results:
        metrics = result["metrics"]
        avg = metrics.get("avg_time_ms", "?")
        tps = metrics.get("throughput_tokens_per_sec", "?")
        bs = metrics.get("batch_size", "?")
        iters = metrics.get("iterations", "?")
        il = metrics.get("input_len", "?")
        log = result.get("log_path", "?")
        # Tokens per step depends on mode
        if m == "decode":
            tokens_per_step = 1
        elif m == "eagle_verify":
            tokens_per_step = metrics.get("verify_tree_size", "?")
        elif m == "eagle_draft_proposal":
            tokens_per_step = metrics.get("draft_tree_size", "?")
        else:
            tokens_per_step = il
        print(f"\n{m}:")
        print(f"  Batch Size: {bs}  Tokens/Step: {tokens_per_step}  Iterations: {iters}")
        print(f"  log: {log}")
        print(f"  >>> \033[1mAvg Time: {avg} ms  |  Perf: {tps} tokens/s\033[0m")

    return {
        "success": True,
        "output": "\n".join(all_output),
        "error": None,
        "metrics": all_metrics,
    }
