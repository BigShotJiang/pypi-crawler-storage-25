"""CLI entry point for edgellm-bench."""

import argparse
import json
import os
import sys

from .benchmark_runner import run_benchmark
from .config import (
    DEFAULT_BATCH_SIZE,
    DEFAULT_ENGINE_DIR,
    DEFAULT_INPUT_LEN,
    DEFAULT_ITERATIONS,
    DEFAULT_MAX_BATCH_SIZE,
    DEFAULT_MAX_INPUT_LEN,
    DEFAULT_MAX_SEQ_LEN,
    DEFAULT_NAS_BASE_URL,
    DEFAULT_ONNX_DIR,
    DEFAULT_WARMUP,
    get_build_dir,
)
from .engine_builder import build_engine
from .inference_runner import run_eagle_inference, run_standard_inference
from .nas_client import download_model, list_models
from .utils import derive_draft_precision, is_eagle_base


def _format_precision(precision_str):
    """Parse a precision string and return a human-readable description.

    Precision string formats:
      llm-<model>-<lmhead>[-extra...]              -> "LLM    model=<model>  lm_head=<lmhead>"
      llm-base-<model>-<lmhead>[-extra...]          -> "Base   model=<model>  lm_head=<lmhead>"
      draft-<type>-<model>-<lmhead>[-extra...]       -> "Draft  type=<type>  model=<model>  lm_head=<lmhead>"
      visual-<prec>                                  -> "ViT    model=<prec>"

    Known extra suffixes:
      rvsN   -> reduced_vocab_size=N
      fp8kv  -> fp8kv
    """
    parts = precision_str.split("-")
    component = parts[0]

    def _parse_extras(extra_parts):
        """Parse extra suffix parts into human-readable tags."""
        tags = []
        for part in extra_parts:
            if part.startswith("rvs"):
                tags.append(f"reduced_vocab={part[3:]}")
            else:
                tags.append(part)
        return ("  " + "  ".join(tags)) if tags else ""

    # Eagle base: llm-base-<model>-<lmhead>[-extras]
    if component == "llm" and len(parts) >= 4 and parts[1] == "base":
        model_prec = parts[2]
        lmhead_prec = parts[3]
        extras = _parse_extras(parts[4:])
        return f"Base   model={model_prec:<10s} lm_head={lmhead_prec:<10s}{extras}"

    # Eagle draft: draft-<type>-<model>-<lmhead>[-extras]
    if component == "draft" and len(parts) >= 4:
        draft_type = parts[1]
        model_prec = parts[2]
        lmhead_prec = parts[3]
        extras = _parse_extras(parts[4:])
        return f"Draft  {draft_type:<8s} model={model_prec:<10s} lm_head={lmhead_prec:<10s}{extras}"

    # Standard LLM: llm-<model>-<lmhead>[-extras]
    if component == "llm" and len(parts) >= 3:
        model_prec = parts[1]
        lmhead_prec = parts[2]
        extras = _parse_extras(parts[3:])
        return f"LLM    model={model_prec:<10s} lm_head={lmhead_prec:<10s}{extras}"

    # Visual: visual-<prec>
    if component == "visual" and len(parts) >= 2:
        extras = _parse_extras(parts[2:])
        return f"ViT    model={parts[1]}{extras}"

    return precision_str


def cmd_list(args):
    """Handle 'edgellm-bench list' command."""
    print(f"Fetching model list from {args.url} ...")
    models = list_models(args.url)

    if not models:
        print("No models found.")
        return 1

    if args.json:
        print(json.dumps(models, indent=2))
        return 0

    # Print as a formatted table
    print(f"\n{'Model':<45} {'Type':<7} {'Precision'}")
    print("-" * 100)
    for model_name in sorted(models.keys()):
        precisions = models[model_name]
        for i, p in enumerate(precisions):
            name_col = model_name if i == 0 else ""
            formatted = _format_precision(p)
            print(f"{name_col:<45} {formatted}")
        print()  # blank line between models
    print(f"Total: {len(models)} models")
    return 0


def cmd_run(args):
    """Handle 'edgellm-bench run' command."""
    build_dir = args.build_dir or get_build_dir()
    download_dir = args.download_dir or str(DEFAULT_ONNX_DIR)
    engine_base_dir = args.engine_dir or str(DEFAULT_ENGINE_DIR)

    is_eagle = is_eagle_base(args.precision)

    if is_eagle:
        return _cmd_run_eagle(args, build_dir, download_dir, engine_base_dir)

    return _cmd_run_standard(args, build_dir, download_dir, engine_base_dir)


def _cmd_run_standard(args, build_dir, download_dir, engine_base_dir):
    """Standard (non-eagle) run: download, build, benchmark."""
    onnx_dir = os.path.join(download_dir, args.model, args.precision)
    engine_dir = os.path.join(engine_base_dir, args.model, args.precision)

    # Step 1: Download ONNX model
    if not args.skip_download:
        print(f"\n=== Step 1/3: Downloading {args.model}/{args.precision} ===")
        try:
            onnx_dir = download_model(
                model_name=args.model,
                precision=args.precision,
                dest_dir=download_dir,
                base_url=args.url,
            )
        except Exception as e:
            print(f"Download failed: {e}", file=sys.stderr)
            return 1
    else:
        print(f"\n=== Step 1/3: Download skipped (using {onnx_dir}) ===")
        if not os.path.isdir(onnx_dir):
            print(f"Error: ONNX directory not found: {onnx_dir}", file=sys.stderr)
            return 1

    # Step 2: Build engine
    if not args.skip_build:
        print(f"\n=== Step 2/3: Building engine ===")
        result = build_engine(
            onnx_dir=onnx_dir,
            engine_dir=engine_dir,
            build_dir=build_dir,
            max_seq_len=args.max_seq_len,
            max_batch_size=args.max_batch_size,
            max_input_len=args.max_input_len,
            precision=args.precision,
            extra_args=args.extra_build_args,
        )
        if not result["success"]:
            print(f"Engine build failed: {result['error']}", file=sys.stderr)
            return 1
    else:
        print(f"\n=== Step 2/3: Build skipped (using {engine_dir}) ===")
        if not os.path.isdir(engine_dir):
            print(f"Error: Engine directory not found: {engine_dir}", file=sys.stderr)
            return 1

    # Step 3: Run benchmark
    print(f"\n=== Step 3/3: Running benchmark ===")
    result = run_benchmark(
        engine_dir=engine_dir,
        build_dir=build_dir,
        batch_size=args.batch_size,
        warmup=args.warmup,
        iterations=args.iterations,
        mode=args.mode,
        input_len=args.input_len,
        precision=args.precision,
        extra_args=args.extra_bench_args,
    )

    if not result["success"]:
        print(f"Benchmark failed: {result['error']}", file=sys.stderr)
        return 1

    return 0


def _cmd_run_eagle(args, build_dir, download_dir, engine_base_dir):
    """Eagle run: download + build both base & draft, then llm_inference --eagle."""
    base_precision = args.precision
    draft_precision = getattr(args, "draft_precision", None) or derive_draft_precision(base_precision)
    if not draft_precision:
        print(f"Error: Cannot derive draft precision from {base_precision}", file=sys.stderr)
        return 1

    engine_dir = os.path.join(engine_base_dir, args.model, "eagle")

    base_onnx = os.path.join(download_dir, args.model, base_precision)
    draft_onnx = os.path.join(download_dir, args.model, draft_precision)

    # Warn about args that are ignored in Eagle mode
    ignored = []
    if args.mode:
        ignored.append("--mode")
    if args.input_len != DEFAULT_INPUT_LEN:
        ignored.append("--input-len")
    if args.iterations != DEFAULT_ITERATIONS:
        ignored.append("--iterations")
    if ignored:
        print(f"Warning: Eagle mode ignores: {', '.join(ignored)} (using llm_inference instead of llm_bench)")

    print(f"\nEagle mode: base={base_precision}  draft={draft_precision}")
    print(f"Engine dir: {engine_dir}")

    # Step 1: Download base ONNX
    if not args.skip_download:
        print(f"\n=== Step 1/5: Downloading base {args.model}/{base_precision} ===")
        try:
            base_onnx = download_model(
                model_name=args.model,
                precision=base_precision,
                dest_dir=download_dir,
                base_url=args.url,
            )
        except Exception as e:
            print(f"Base download failed: {e}", file=sys.stderr)
            return 1

        # Step 2: Download draft ONNX
        print(f"\n=== Step 2/5: Downloading draft {args.model}/{draft_precision} ===")
        try:
            draft_onnx = download_model(
                model_name=args.model,
                precision=draft_precision,
                dest_dir=download_dir,
                base_url=args.url,
            )
        except Exception as e:
            print(f"Draft download failed: {e}", file=sys.stderr)
            return 1
    else:
        print(f"\n=== Step 1-2/5: Download skipped ===")
        for label, path in [("Base ONNX", base_onnx), ("Draft ONNX", draft_onnx)]:
            if not os.path.isdir(path):
                print(f"Error: {label} not found: {path}", file=sys.stderr)
                return 1

    # Step 3: Build base engine
    if not args.skip_build:
        print(f"\n=== Step 3/5: Building base engine ===")
        result = build_engine(
            onnx_dir=base_onnx,
            engine_dir=engine_dir,
            build_dir=build_dir,
            max_seq_len=args.max_seq_len,
            max_batch_size=args.max_batch_size,
            max_input_len=args.max_input_len,
            precision=base_precision,
            extra_args=args.extra_build_args,
        )
        if not result["success"]:
            print(f"Base engine build failed: {result['error']}", file=sys.stderr)
            return 1

        # Step 4: Build draft engine
        print(f"\n=== Step 4/5: Building draft engine ===")
        result = build_engine(
            onnx_dir=draft_onnx,
            engine_dir=engine_dir,
            build_dir=build_dir,
            max_seq_len=args.max_seq_len,
            max_batch_size=args.max_batch_size,
            max_input_len=args.max_input_len,
            precision=draft_precision,
            extra_args=args.extra_build_args,
        )
        if not result["success"]:
            print(f"Draft engine build failed: {result['error']}", file=sys.stderr)
            return 1
    else:
        print(f"\n=== Step 3-4/5: Build skipped (using {engine_dir}) ===")
        if not os.path.isdir(engine_dir):
            print(f"Error: Engine directory not found: {engine_dir}", file=sys.stderr)
            return 1

    # Step 5: Run eagle inference benchmark
    print(f"\n=== Step 5/5: Running Eagle inference benchmark ===")
    result = run_eagle_inference(
        engine_dir=engine_dir,
        build_dir=build_dir,
        warmup=args.warmup,
        max_generate_length=args.max_generate_length,
        batch_size=args.batch_size,
        extra_args=args.extra_infer_args,
    )

    if not result["success"]:
        print(f"Eagle benchmark failed: {result['error']}", file=sys.stderr)
        return 1

    return 0


def cmd_infer(args):
    """Handle 'edgellm-bench infer' command."""
    build_dir = args.build_dir or get_build_dir()
    engine_dir = args.engine_dir

    if not os.path.isdir(engine_dir):
        print(f"Error: Engine directory not found: {engine_dir}", file=sys.stderr)
        return 1

    print(f"\n=== Running inference benchmark ===")
    print(f"Engine: {engine_dir}")

    if args.eagle:
        result = run_eagle_inference(
            engine_dir=engine_dir,
            build_dir=build_dir,
            input_file=args.input_file,
            warmup=args.warmup,
            max_generate_length=args.max_generate_length,
            batch_size=args.batch_size,
            extra_args=args.extra_infer_args,
        )
    else:
        result = run_standard_inference(
            engine_dir=engine_dir,
            build_dir=build_dir,
            input_file=args.input_file,
            warmup=args.warmup,
            max_generate_length=args.max_generate_length,
            batch_size=args.batch_size,
            extra_args=args.extra_infer_args,
        )

    if not result["success"]:
        print(f"Inference failed: {result['error']}", file=sys.stderr)
        return 1

    return 0


def main():
    parser = argparse.ArgumentParser(
        prog="edgellm-bench",
        description="TensorRT Edge-LLM Benchmark Tool",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # --- list ---
    list_parser = subparsers.add_parser("list", help="List available models and precisions")
    list_parser.add_argument(
        "--url", default=DEFAULT_NAS_BASE_URL, help="NAS base URL"
    )
    list_parser.add_argument(
        "--json", action="store_true", help="Output in JSON format"
    )

    # --- run ---
    run_parser = subparsers.add_parser(
        "run",
        help="Download, build, and benchmark a model",
        description=(
            "Download ONNX model, build TensorRT engine, and run benchmark.\n\n"
            "For Eagle models (--precision llm-base-*): automatically downloads and builds\n"
            "both base and draft engines, then runs llm_inference --eagle with MT-Bench\n"
            "prompts for end-to-end decode perf (acceptance rate + tokens/s).\n\n"
            "For standard models: runs llm_bench for kernel-level prefill + decode benchmarks."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    run_parser.add_argument(
        "--model", required=True, help="Model name (e.g., Qwen2.5-7B-Instruct)"
    )
    run_parser.add_argument(
        "--precision", required=True,
        help="Precision variant (e.g., llm-fp16-fp16, llm-base-nvfp4-fp16 for Eagle)",
    )
    run_parser.add_argument(
        "--draft-precision",
        help="Draft precision for Eagle (auto-derived from --precision if not set)",
    )
    run_parser.add_argument("--build-dir", help="Build directory with C++ executables")
    run_parser.add_argument("--download-dir", help="Directory to download ONNX models")
    run_parser.add_argument(
        "--engine-dir",
        help="Base directory for engines (actual path: <engine-dir>/<model>/<precision>)",
    )
    run_parser.add_argument(
        "--max-seq-len", type=int, default=DEFAULT_MAX_SEQ_LEN, help="Max sequence length"
    )
    run_parser.add_argument(
        "--max-batch-size", type=int, default=DEFAULT_MAX_BATCH_SIZE, help="Max batch size for engine"
    )
    run_parser.add_argument(
        "--max-input-len", type=int, default=DEFAULT_MAX_INPUT_LEN, help="Max input length for engine"
    )
    run_parser.add_argument(
        "--batch-size", type=int, default=DEFAULT_BATCH_SIZE, help="Batch size for benchmark"
    )
    run_parser.add_argument(
        "--warmup", type=int, default=DEFAULT_WARMUP, help="Warmup iterations"
    )
    run_parser.add_argument(
        "--iterations", type=int, default=DEFAULT_ITERATIONS,
        help="Benchmark iterations (standard mode only, ignored for Eagle)",
    )
    run_parser.add_argument(
        "--mode",
        help="Benchmark mode: prefill, decode, eagle_verify, eagle_draft_prefill (standard mode only)",
    )
    run_parser.add_argument(
        "--input-len", type=int, default=DEFAULT_INPUT_LEN,
        help="Input sequence length (standard mode only, default: %(default)s)",
    )
    run_parser.add_argument(
        "--max-generate-length", type=int, default=512,
        help="Max tokens to generate per request (Eagle mode only, default: 512)",
    )
    run_parser.add_argument("--skip-download", action="store_true", help="Skip ONNX download")
    run_parser.add_argument("--skip-build", action="store_true", help="Skip engine build")
    run_parser.add_argument("--url", default=DEFAULT_NAS_BASE_URL, help="NAS base URL")
    run_parser.add_argument(
        "--extra-build-args", nargs="*", default=None,
        help="Extra arguments passed to llm_build",
    )
    run_parser.add_argument(
        "--extra-bench-args", nargs="*", default=None,
        help="Extra arguments passed to llm_bench (standard mode only)",
    )
    run_parser.add_argument(
        "--extra-infer-args", nargs="*", default=None,
        help="Extra arguments passed to llm_inference (Eagle mode only)",
    )

    # --- infer ---
    infer_parser = subparsers.add_parser(
        "infer", help="Run end-to-end inference benchmark (Eagle or standard) using MT-Bench prompts"
    )
    infer_parser.add_argument(
        "--engine-dir", required=True,
        help="Engine directory (for Eagle: must contain both base and draft engines)",
    )
    infer_parser.add_argument("--build-dir", help="Build directory with C++ executables")
    infer_parser.add_argument(
        "--eagle", action="store_true",
        help="Enable Eagle speculative decoding mode",
    )
    infer_parser.add_argument(
        "--input-file",
        help="Input JSON file for llm_inference (generates MT-Bench prompts if not provided)",
    )
    infer_parser.add_argument(
        "--warmup", type=int, default=3, help="Number of warmup runs (default: 3)",
    )
    infer_parser.add_argument(
        "--max-generate-length", type=int, default=512,
        help="Max tokens to generate per request (default: 512)",
    )
    infer_parser.add_argument(
        "--batch-size", type=int, default=DEFAULT_BATCH_SIZE, help="Batch size (default: 1)",
    )
    infer_parser.add_argument(
        "--extra-infer-args", nargs="*", default=None,
        help="Extra arguments passed to llm_inference",
    )

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        return 1

    if args.command == "list":
        return cmd_list(args)
    elif args.command == "run":
        return cmd_run(args)
    elif args.command == "infer":
        return cmd_infer(args)

    return 0


if __name__ == "__main__":
    sys.exit(main())
