"""Engine builder — wraps the llm_build C++ executable."""

import os
import subprocess
import sys

from .config import get_build_dir
from .utils import find_executable, get_subprocess_env, is_eagle_base, is_eagle_draft


def _detect_engine_filename(precision: str) -> str:
    """Determine engine filename based on precision string.

    Eagle base models produce 'eagle_base.engine',
    Eagle draft models produce 'eagle_draft.engine',
    standard LLMs produce 'llm.engine'.
    """
    if is_eagle_draft(precision):
        return "eagle_draft.engine"
    if is_eagle_base(precision):
        return "eagle_base.engine"
    return "llm.engine"


def _create_bench_symlinks(engine_dir: str, precision: str | None) -> None:
    """Create symlinks so llm_bench finds eagle engines by expected names.

    llm_bench expects:
      eagle_verify mode   -> llm.engine + config.json
      eagle_draft_* mode  -> eagle_draft.engine + draft_config.json

    llm_build produces:
      --eagleBase  -> eagle_base.engine + base_config.json
      --eagleDraft -> eagle_draft.engine + draft_config.json  (already correct)
    """
    if not precision or not is_eagle_base(precision):
        return

    symlink_map = {
        "llm.engine": "eagle_base.engine",
        "config.json": "base_config.json",
    }
    for link_name, target_name in symlink_map.items():
        link_path = os.path.join(engine_dir, link_name)
        target_path = os.path.join(engine_dir, target_name)
        if os.path.exists(target_path) and not os.path.exists(link_path):
            os.symlink(target_name, link_path)
            print(f"  Symlinked {link_name} -> {target_name}")


def build_engine(
    onnx_dir: str,
    engine_dir: str,
    build_dir: str = None,
    max_seq_len: int = 4096,
    max_batch_size: int = 1,
    max_input_len: int = 2048,
    precision: str = None,
    extra_args: list = None,
) -> dict:
    """Build a TensorRT engine from ONNX model.

    Args:
        onnx_dir: Directory containing model.onnx and related files.
        engine_dir: Output directory for the built engine.
        build_dir: Build directory containing C++ executables.
        max_seq_len: Maximum sequence length (KV cache capacity).
        max_batch_size: Maximum batch size.
        max_input_len: Maximum input length.
        precision: Precision string (e.g., 'llm-base-fp8-fp16', 'draft-eagle3-fp16-fp16').
        extra_args: Additional command-line arguments for llm_build.

    Returns:
        dict with 'success', 'output', 'error' keys.
    """
    if build_dir is None:
        build_dir = get_build_dir()

    llm_build = find_executable(build_dir, "llm_build")
    os.makedirs(engine_dir, exist_ok=True)

    # Check if engine already exists (filename depends on model type)
    engine_filename = _detect_engine_filename(precision) if precision else "llm.engine"
    engine_file = os.path.join(engine_dir, engine_filename)
    if os.path.exists(engine_file):
        print(f"Engine already exists at {engine_file}, skipping build.")
        return {"success": True, "output": "Engine already exists", "error": None}

    cmd = [
        llm_build,
        f"--onnxDir={onnx_dir}",
        f"--engineDir={engine_dir}",
        f"--maxInputLen={max_input_len}",
        f"--maxKVCacheCapacity={max_seq_len}",
    ]

    # Auto-detect Eagle flags from precision string
    if precision:
        if is_eagle_draft(precision):
            cmd.append("--eagleDraft")
        elif is_eagle_base(precision):
            cmd.append("--eagleBase")

    if extra_args:
        cmd.extend(extra_args)

    log_path = os.path.join(engine_dir, "build.log")
    print(f"Building engine... (log: {log_path})")
    print(f"  cmd: {' '.join(cmd)}")

    try:
        with open(log_path, "w") as log_file:
            log_file.write(f"$ {' '.join(cmd)}\n\n")
            proc = subprocess.Popen(
                cmd,
                env=get_subprocess_env(),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )
            output_lines = []
            for line in proc.stdout:
                log_file.write(line)
                log_file.flush()
                output_lines.append(line)
            proc.wait(timeout=1200)
        output = "".join(output_lines)
        if proc.returncode != 0:
            # Print last 20 lines to terminal on failure
            print(f"Build FAILED (exit code {proc.returncode}). Last lines:")
            for line in output_lines[-20:]:
                sys.stdout.write(f"  {line}")
            return {
                "success": False,
                "output": output,
                "error": f"llm_build exited with code {proc.returncode}",
            }

        # Create symlinks so llm_bench can find the engine files.
        _create_bench_symlinks(engine_dir, precision)

        print(f"Build complete: {engine_file}")
        return {"success": True, "output": output, "error": None}
    except subprocess.TimeoutExpired:
        proc.kill()
        return {"success": False, "output": "", "error": "Engine build timed out (1200s)"}
    except Exception as e:
        return {"success": False, "output": "", "error": str(e)}
