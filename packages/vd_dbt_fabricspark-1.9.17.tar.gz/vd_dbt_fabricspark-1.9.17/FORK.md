# Fork Divergence — vd-dbt-fabricspark

Forked from [microsoft/dbt-fabricspark](https://github.com/microsoft/dbt-fabricspark).
Goal: keep this fork as thin as possible. Everything that isn't a hard
fork-only feature should land in upstream as a PR.

**Upstream baseline**: `microsoft/dbt-fabricspark` `main` @ commit `61509e8`
(includes v1.9.6 + the post-release incremental fix).
**Fork version**: `vd-dbt-fabricspark==1.9.17`

## Active fork divergence

### `external_token` auth method

**Files**: `src/dbt/adapters/fabricspark/livysession.py`,
`src/dbt/adapters/fabricspark/credentials.py`,
`tests/unit/test_external_token.py`

A generic HTTP token-broker auth: the adapter calls a configured HTTP
endpoint and receives a JSON document containing the bearer token. Used
by Vibedata Studio's local-dev path, where the IDE runs an OAuth helper
on `localhost` that refreshes Fabric tokens.

Profile fields:

```yaml
fabricspark:
  outputs:
    dev:
      type: fabricspark
      authentication: external_token
      external_token_url: "{{ env_var('TOKEN_URL') }}"
      # all of the following are optional
      external_token_method: "GET"             # default GET
      external_token_params:
        user_id: "{{ env_var('USER_ID') }}"
      external_token_headers:
        X-Bootstrap: "{{ env_var('BOOTSTRAP_TOKEN') }}"
      external_token_response_path: "access_token"   # JSON path to token
      external_token_expires_in_path: "expires_in"   # JSON path to TTL
```

The Fabric API scope (`AZURE_CREDENTIAL_SCOPE`) is auto-added to
`external_token_params` under key `scope` unless explicitly overridden.

## Upstream issues / PRs filed by us

| Repo | # | Title | Status |
|---|---|---|---|
| `microsoft/dbt-fabricspark` | [#158](https://github.com/microsoft/dbt-fabricspark/pull/158) | F7 — defensive parsing of optional fields in Fabric Livy SessionResponse | OPEN |
| `microsoft/dbt-fabricspark` | [#160](https://github.com/microsoft/dbt-fabricspark/pull/160) | `token_command` auth method (subprocess-based credential refresh) | OPEN |
| `microsoft/dbt-fabricspark` | [#162](https://github.com/microsoft/dbt-fabricspark/issues/162) | (Issue) Cross-workspace `--defer` fails — 4-part naming gap | OPEN |
| `microsoft/dbt-fabricspark` | [#163](https://github.com/microsoft/dbt-fabricspark/issues/163) | (Issue) `LivySessionConnectionWrapper` missing `fetchmany` | OPEN |
| `microsoft/dbt-fabricspark` | [#164](https://github.com/microsoft/dbt-fabricspark/pull/164) | Add `fetchmany` to `LivySessionConnectionWrapper` (fixes #163) | OPEN |

If Microsoft merges these, the corresponding pieces drop out of any future fork patch we'd need.

PRs are filed under the company GitHub identity (`pradipsodha-acceleratedata`) via the company fork (`accelerate-data/vd-dbt-fabricspark-v2`).
