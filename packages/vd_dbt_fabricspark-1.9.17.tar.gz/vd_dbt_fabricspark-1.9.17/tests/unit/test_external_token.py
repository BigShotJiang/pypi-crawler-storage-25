"""Tests for the fork-only external_token auth method.

Covers get_external_access_token (HTTP token-broker auth) and the
get_headers dispatch case for authentication=external_token.
"""
import time
from unittest.mock import MagicMock, patch

import pytest
import requests
from azure.core.credentials import AccessToken
from dbt_common.exceptions import DbtRuntimeError

from dbt.adapters.fabricspark.livysession import (
    _walk_json_path,
    get_external_access_token,
    get_headers,
)


# ---------------------------------------------------------------------------
# _walk_json_path
# ---------------------------------------------------------------------------


def test_walk_json_path_top_level():
    assert _walk_json_path({"a": "x"}, "a") == "x"


def test_walk_json_path_nested():
    assert _walk_json_path({"data": {"token": "x"}}, "data.token") == "x"


def test_walk_json_path_missing_returns_none():
    assert _walk_json_path({"a": 1}, "b") is None


def test_walk_json_path_through_non_dict_returns_none():
    assert _walk_json_path({"a": "string"}, "a.b") is None


# ---------------------------------------------------------------------------
# get_external_access_token
# ---------------------------------------------------------------------------


def _creds(**overrides):
    creds = MagicMock()
    creds.external_token_url = "http://localhost:9999/token"
    creds.external_token_method = "GET"
    creds.external_token_params = None
    creds.external_token_headers = None
    creds.external_token_response_path = "access_token"
    creds.external_token_expires_in_path = "expires_in"
    for k, v in overrides.items():
        setattr(creds, k, v)
    return creds


def _resp(status=200, json_body=None, text=""):
    r = MagicMock()
    r.status_code = status
    r.json.return_value = json_body if json_body is not None else {}
    r.text = text
    return r


@patch("dbt.adapters.fabricspark.livysession.requests.request")
def test_external_token_happy_path(mock_req):
    mock_req.return_value = _resp(200, {"access_token": "tok-123", "expires_in": 1800})
    before = int(time.time())

    tok = get_external_access_token(_creds())

    assert isinstance(tok, AccessToken)
    assert tok.token == "tok-123"
    assert before + 1800 <= tok.expires_on <= int(time.time()) + 1800
    # scope is added to params automatically
    call_kwargs = mock_req.call_args.kwargs
    assert call_kwargs["params"]["scope"]


@patch("dbt.adapters.fabricspark.livysession.requests.request")
def test_external_token_user_params_and_headers_passed_through(mock_req):
    mock_req.return_value = _resp(200, {"access_token": "x", "expires_in": 60})

    creds = _creds(
        external_token_params={"user_id": "alice"},
        external_token_headers={"X-Custom": "yes"},
    )
    get_external_access_token(creds)

    call_kwargs = mock_req.call_args.kwargs
    assert call_kwargs["params"]["user_id"] == "alice"
    assert call_kwargs["headers"]["X-Custom"] == "yes"
    # scope still injected
    assert "scope" in call_kwargs["params"]


@patch("dbt.adapters.fabricspark.livysession.requests.request")
def test_external_token_nested_response_path(mock_req):
    mock_req.return_value = _resp(
        200, {"data": {"jwt": "deep-tok", "ttl": 7200}}
    )
    creds = _creds(
        external_token_response_path="data.jwt",
        external_token_expires_in_path="data.ttl",
    )

    tok = get_external_access_token(creds)
    assert tok.token == "deep-tok"
    # expires_on is approximately now + 7200
    assert tok.expires_on >= int(time.time()) + 7100


@patch("dbt.adapters.fabricspark.livysession.requests.request")
def test_external_token_missing_url_raises(mock_req):
    creds = _creds(external_token_url=None)
    with pytest.raises(DbtRuntimeError, match="external_token_url"):
        get_external_access_token(creds)
    mock_req.assert_not_called()


@patch("dbt.adapters.fabricspark.livysession.requests.request")
def test_external_token_connection_error_wrapped(mock_req):
    mock_req.side_effect = requests.exceptions.ConnectionError("refused")
    with pytest.raises(DbtRuntimeError, match="could not reach"):
        get_external_access_token(_creds())


@patch("dbt.adapters.fabricspark.livysession.requests.request")
def test_external_token_http_error_includes_body(mock_req):
    mock_req.return_value = _resp(403, {}, text="Forbidden: localhost only")
    with pytest.raises(DbtRuntimeError, match="HTTP 403"):
        get_external_access_token(_creds())


@patch("dbt.adapters.fabricspark.livysession.requests.request")
def test_external_token_response_missing_token_raises(mock_req):
    mock_req.return_value = _resp(200, {"foo": "bar"})
    with pytest.raises(DbtRuntimeError, match="missing token at path"):
        get_external_access_token(_creds())


@patch("dbt.adapters.fabricspark.livysession.requests.request")
def test_external_token_default_expiry_when_field_missing(mock_req):
    mock_req.return_value = _resp(200, {"access_token": "x"})  # no expires_in
    tok = get_external_access_token(_creds())
    # default 3600
    assert tok.expires_on >= int(time.time()) + 3500


# ---------------------------------------------------------------------------
# get_headers dispatch
# ---------------------------------------------------------------------------


def test_get_headers_dispatches_external_token():
    """authentication='external_token' routes to get_external_access_token."""
    import dbt.adapters.fabricspark.livysession as mod
    mod.accessToken = None  # reset module-level cache

    creds = MagicMock()
    creds.is_local_mode = False
    creds.authentication = "external_token"

    with patch.object(
        mod, "get_external_access_token",
        return_value=AccessToken(token="ext-tok", expires_on=9999999999),
    ) as mock_fn:
        headers = get_headers(creds)

    mock_fn.assert_called_once_with(creds)
    assert headers["Authorization"] == "Bearer ext-tok"
