"""EventBuilder — a fluent HeraldEvent builder with sane defaults.

WHY tests need this: HeraldEvent has many required fields (event_id,
trace_id, span_id, run_id, timestamp_ns, etc.) and a unit test usually
cares about only one or two. EventBuilder.create() returns a valid
event with deterministic defaults; tests override only what they want
to assert on.
"""

from __future__ import annotations

import secrets
from typing import Any

from .._models import HeraldEvent


class EventBuilder:
    """Fluent factory for HeraldEvent instances in tests.

    Usage:
        event = EventBuilder.create(name="my_tool", attributes={"k": "v"})
        # event has every required field filled in with valid defaults.

    The defaults are intentionally constant where possible (fixed
    timestamps, deterministic IDs would also work but secrets.token_bytes
    is fine for tests that do not assert on ID values).
    """

    # WHY classmethods and not module-level functions: keeps every test
    # fixture under one named handle (EventBuilder) rather than scattered
    # free functions. Reads as `EventBuilder.create(...)` which is what
    # plugin authors expect from the .NET sink-author guide convention.

    @classmethod
    def create(
        cls,
        *,
        event_id: str | None = None,
        trace_id: bytes | None = None,
        span_id: bytes | None = None,
        parent_span_id: bytes | None = None,
        run_id: str | None = None,
        kind: str = "tool",
        name: str = "test_event",
        timestamp_ns: int = 1_735_689_600_000_000_000,
        duration_ns: int | None = None,
        attributes: dict[str, Any] | None = None,
        resource: dict[str, Any] | None = None,
        severity: str = "INFO",
        chain_kind: str = "telemetry",
    ) -> HeraldEvent:
        """Build a HeraldEvent with sane defaults for tests.

        WHY a fixed default timestamp_ns: tests that check "the event's
        timestamp is X" should not race against wall-clock movement.
        The default is January 1 2025 in nanoseconds, far enough from
        zero to avoid edge cases in any future code that special-cases
        a zero timestamp.
        """
        return HeraldEvent(
            event_id=event_id or "01HQXY1234ABCD",
            trace_id=trace_id or secrets.token_bytes(16),
            span_id=span_id or secrets.token_bytes(8),
            parent_span_id=parent_span_id,
            run_id=run_id or "01HQRUNTESTXYZ",
            kind=kind,
            name=name,
            timestamp_ns=timestamp_ns,
            duration_ns=duration_ns,
            attributes=attributes or {},
            resource=resource or {},
            severity=severity,  # type: ignore[arg-type]
            chain_kind=chain_kind,  # type: ignore[arg-type]
        )
