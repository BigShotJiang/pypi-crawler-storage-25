"""MemoryBuffer — an IBuffer-shaped deque, no disk, for unit tests.

WHY tests need this: SqliteBuffer (the production buffer) opens a file,
runs PRAGMA setup, and fsyncs on audit writes. That is correct in
production and wrong in tests — a unit test that just wants to verify
"my code emitted three events" should not pay the SQLite cost or care
about disk state.

MemoryBuffer is a deque-backed stand-in. write() costs ~50 ns vs
~3-5 µs for SqliteBuffer NORMAL inserts; tests run faster and there is
no temp-file cleanup.
"""

from __future__ import annotations

from collections import deque
from typing import Any


class MemoryBuffer:
    """In-memory IBuffer implementation. Holds events in a deque and
    tracks which sequence numbers have been marked sent.

    Not crash-safe. Not durable. Designed for tests that want to assert
    on what got written, not how durably it was written.
    """

    def __init__(self) -> None:
        # WHY a deque and not a list: O(1) appends and pops from both
        # ends. Append-on-write, pop-on-drain. Lists would degrade
        # under high write rates in benchmarks.
        self._events: deque[tuple[int, Any, str]] = deque()
        self._next_seq: int = 1
        self._sent_seqs: set[int] = set()

    async def write(self, event: Any, sync_mode: str = "NORMAL") -> None:
        """Append an event with the given sync mode tag. The deque
        records (seq, event, sync_mode) so tests can assert on the
        sync_mode an event was written under."""
        seq = self._next_seq
        self._next_seq += 1
        self._events.append((seq, event, sync_mode))

    async def drain_unsent(self, batch_size: int) -> list[Any]:
        """Return up to batch_size events not yet marked sent."""
        result: list[Any] = []
        for seq, event, _ in self._events:
            if seq in self._sent_seqs:
                continue
            result.append(event)
            if len(result) >= batch_size:
                break
        return result

    async def mark_sent(self, seq_range: range) -> None:
        """Record that events in the given sequence range shipped."""
        self._sent_seqs.update(seq_range)

    # ---- Test helpers (not part of the IBuffer protocol) ----------------

    def all_events(self) -> list[Any]:
        """Return every event written, in order. For test assertions."""
        return [event for _, event, _ in self._events]

    def events_with_sync_mode(self, sync_mode: str) -> list[Any]:
        """Return events that were written with the given sync mode.
        Useful for asserting "audit events used FULL"."""
        return [event for _, event, mode in self._events if mode == sync_mode]

    def __len__(self) -> int:
        return len(self._events)
