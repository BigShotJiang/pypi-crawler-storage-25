"""Public testing fixtures for plugin authors and SDK users.

WHY this exists from v0.1: every plugin author wants the same fixtures —
a frozen clock, an in-memory buffer, a recording exporter, a fluent
event builder, a fake HTTP transport. Shipping them in core means
plugin authors do not reinvent five identical fixtures per test suite.

These ARE part of the public surface. Customers can use them too
(e.g. building integration tests for their own agent code that doesn't
require a real Herald.Server).

Re-exports:
  EventBuilder      — fluent HeraldEvent builder with sane defaults
  FrozenClock       — IClock with manual advance(timedelta)
  MemoryBuffer      — IBuffer backed by a deque, no disk
  RecordingExporter — IExporter that captures every batch for assertions
  FakeHttpTransport — drop-in for httpx.AsyncClient transports
"""

from __future__ import annotations

from .buffer import MemoryBuffer
from .builders import EventBuilder
from .clock import FrozenClock
from .exporter import RecordingExporter
from .http import FakeHttpRequest, FakeHttpTransport

__all__ = [
    "EventBuilder",
    "FakeHttpRequest",
    "FakeHttpTransport",
    "FrozenClock",
    "MemoryBuffer",
    "RecordingExporter",
]
