"""FakeHttpTransport — drop-in for httpx.AsyncClient transports in tests.

WHY tests need this: integrations like httpx, openai, anthropic, fastapi
all eventually make HTTP calls. Unit tests want to assert "my code made
a POST to /v1/messages with this body" without a real network endpoint.
FakeHttpTransport implements the httpx transport protocol so an httpx
client can be constructed against it and the test asserts on the
recorded requests.

The implementation is intentionally minimal: it records the request and
returns a configurable response. Tests that need richer behavior can
subclass.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class FakeHttpRequest:
    """One captured HTTP request. The fields mirror httpx.Request shape
    but stay decoupled from any specific httpx version so tests do not
    break when httpx APIs evolve."""

    method: str
    url: str
    headers: dict[str, str]
    body: bytes


@dataclass
class FakeHttpTransport:
    """Records every request, returns a canned response.

    Usage in a test:

        transport = FakeHttpTransport(default_status=201)
        # ... wire transport into the integration under test ...
        # assert on transport.requests after the integration ran.
    """

    requests: list[FakeHttpRequest] = field(default_factory=list)
    """Every request the integration made, in order."""

    default_status: int = 200
    """Status code returned for any request unless overridden."""

    default_body: bytes = b"{}"
    """Body returned for any request unless overridden."""

    default_headers: dict[str, str] = field(
        default_factory=lambda: {"content-type": "application/json"}
    )
    """Headers returned with every response."""

    def record(self, request: FakeHttpRequest) -> None:
        """Append a request to the captured list. Integrations adapt
        their transport calls into FakeHttpRequest and call this."""
        self.requests.append(request)

    def respond(
        self,
        *,
        status: int | None = None,
        body: bytes | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Return a response shape integrations can adapt to httpx
        Response or any other client library. Returns a plain dict so
        FakeHttpTransport stays library-agnostic."""
        return {
            "status_code": status if status is not None else self.default_status,
            "body": body if body is not None else self.default_body,
            "headers": headers if headers is not None else dict(self.default_headers),
        }

    def reset(self) -> None:
        """Clear captured requests. Useful between phases of a test."""
        self.requests.clear()
