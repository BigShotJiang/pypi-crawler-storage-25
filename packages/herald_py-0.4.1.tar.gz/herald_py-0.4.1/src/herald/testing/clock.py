"""FrozenClock — an IClock that returns a fixed time, advanceable on demand.

WHY tests need this: production code paths that read the wall clock
introduce variance into per-event timing assertions. With FrozenClock,
the test sets the time once and explicitly advances it; assertions
become deterministic ("after advance(1ms), the span duration is exactly
1_000_000 ns").
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import timedelta


@dataclass
class FrozenClock:
    """An IClock returning a fixed nanosecond value.

    Construct with the starting time and call advance() to move forward.
    Tests can also reset() to return to the original value.
    """

    now_ns_value: int = 0
    """The current time in nanoseconds. Mutated by advance()."""

    _initial_ns: int = 0
    """Original value passed at construction; reset() restores this."""

    def __post_init__(self) -> None:
        # WHY a separate field for the initial value: __init__ sets
        # now_ns_value, but reset() needs to know the starting point.
        # Capturing it in __post_init__ keeps the dataclass simple while
        # supporting reset.
        self._initial_ns = self.now_ns_value

    def now_ns(self) -> int:
        """Return the current frozen time in nanoseconds."""
        return self.now_ns_value

    def advance(self, delta: timedelta | int) -> None:
        """Move forward by `delta`.

        Accepts either a timedelta or a raw nanosecond count. A
        timedelta is converted using its total_seconds * 1e9, rounded.
        """
        ns = (
            int(delta.total_seconds() * 1_000_000_000)
            if isinstance(delta, timedelta)
            else int(delta)
        )
        if ns < 0:
            raise ValueError("FrozenClock.advance(delta) requires delta >= 0")
        self.now_ns_value += ns

    def reset(self) -> None:
        """Return to the value the clock was constructed with."""
        self.now_ns_value = self._initial_ns
