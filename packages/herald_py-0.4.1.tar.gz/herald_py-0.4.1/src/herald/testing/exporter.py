"""RecordingExporter — an IExporter that captures every batch.

WHY tests need this: the production exporter (OtlpExporter) opens a gRPC
channel and ships bytes. Unit tests want to assert "my code shipped a
batch of 3 events with these attributes" without spinning up a real
server. RecordingExporter just appends each batch to a list; tests
assert on the list.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class RecordingExporter:
    """Captures every batch sent through it.

    Tests inspect `batches` to assert on what shipped:

        exporter = RecordingExporter()
        await runtime.emit(...)
        assert len(exporter.batches) == 1
        assert len(exporter.batches[0]) == 3  # three events in the batch
    """

    batches: list[list[Any]] = field(default_factory=list)
    """One entry per export_batch call. Tests read this directly."""

    fail_next: bool = False
    """If True, the next export_batch raises RuntimeError. Useful for
    testing retry / circuit-breaker behavior in the drain coordinator."""

    fail_count: int = 0
    """Number of total failures induced. Read after a test to confirm
    the retry path got exercised."""

    async def export_batch(self, events: list[Any]) -> None:
        """Record the batch. Raise if fail_next is set."""
        if self.fail_next:
            self.fail_next = False
            self.fail_count += 1
            raise RuntimeError(
                "RecordingExporter.fail_next was True — induced failure"
            )
        # WHY list(events) and not events directly: callers can mutate
        # their batch after handing it to us. Storing a copy means
        # later assertions see exactly what was shipped at the moment
        # of the call.
        self.batches.append(list(events))

    def all_events(self) -> list[Any]:
        """Flatten every batch into one list. Convenient for "did
        anything in particular ship?" assertions."""
        return [event for batch in self.batches for event in batch]

    def reset(self) -> None:
        """Clear captured batches. Useful for reusing one exporter
        across multiple test phases."""
        self.batches.clear()
        self.fail_next = False
        self.fail_count = 0
