"""HeraldSettings — the single source of truth for SDK configuration.

WHY pydantic-settings: every configure() argument should also be readable
from an HERALD_* environment variable, with consistent precedence and
validation. pydantic-settings is the standard mechanism: subclass
BaseSettings, declare fields with validators, set the env_prefix, and
every keyword argument and every env var goes through one validation
path.

WHY one settings class and not several: split classes encourage drift
(env_prefix not consistent across them, defaults defined in two places).
One class with sub-namespaces (durability_*, redact_*, safety_*) keeps
the surface unified while staying readable.

Precedence (highest wins):
  1. Keyword arguments to configure()
  2. Environment variables HERALD_*
  3. Defaults in this file

Customers see only configure(); plugin authors and the runtime see
HeraldSettings directly.
"""

from __future__ import annotations

from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

# Type aliases for the readable Literals — keeps the field defs short.
# "files" is the rolling-NDJSON backend that mirrors the .NET FileManager
# plan. "memory" is fast and in-process; default for tests and for
# customers who do not need on-disk durability.
DurabilityMode = Literal["memory", "files"]
WireFormat = Literal["otlp", "herald"]
DropPolicy = Literal["oldest_telemetry_first", "oldest_any_first", "halt_on_audit_loss"]
SafetyPassMode = Literal["on", "off"]


class HeraldSettings(BaseSettings):
    """Process-wide SDK configuration.

    Every field maps to an HERALD_* env var (e.g. backend → HERALD_BACKEND).
    Pydantic validates Literals, range bounds, and types; configure() raises
    a clear error on the first invalid value.
    """

    # WHY frozen=True: settings are immutable for the process lifetime.
    # Mutating settings after configure() is the leading source of
    # "configuration drift" bugs. Pydantic enforces immutability so the
    # bug class never ships.
    model_config = SettingsConfigDict(
        env_prefix="HERALD_",
        frozen=True,
        extra="forbid",
        case_sensitive=False,
    )

    # ---- Service identity ------------------------------------------------

    backend: str | None = Field(default=None)
    """OTLP/gRPC endpoint URL — the Herald.Server ingest. None means
    "no remote backend; events stay local in the buffer." Useful for
    development and for fully-disconnected workloads."""

    api_key: str | None = Field(default=None)
    """Bearer token Herald.Server uses to authenticate the SDK."""

    service: str | None = Field(default=None)
    """Customer-supplied service name. Surfaces in OTel resource
    attributes as `service.name`."""

    environment: str = Field(default="development")
    """Customer-supplied environment label (production, staging, etc.).
    Surfaces in OTel resource attributes as `deployment.environment`."""

    # ---- Local durability ------------------------------------------------

    durability: DurabilityMode = Field(default="memory")
    """How events are held between capture and drain. "memory" is fast
    and crash-loses everything; "sqlite" is the production default."""

    durability_path: str | None = Field(default=None)
    """Directory for the SQLite buffer file. Required when
    durability="sqlite". The buffer file lives at <path>/herald.db."""

    durability_max_bytes: int = Field(default=512 * 1024 * 1024, gt=0)
    """Cap on the SQLite buffer size. When the cap is reached, the drop
    policy decides which events to evict."""

    durability_drop_policy: DropPolicy = Field(default="oldest_telemetry_first")
    """When the buffer is full, which events get dropped. "halt_on_audit_loss"
    raises rather than dropping any audit event."""

    halt_on_audit_loss: bool = Field(default=True)
    """If True, audit() raises HeraldDurabilityError when the chain
    cannot be persisted. If False, the loss is recorded to the
    FailureSink and audit() returns. Default True — compliance customers
    cannot tolerate silent audit loss."""

    # ---- Wire format and drain ------------------------------------------

    wire: WireFormat = Field(default="otlp")
    """Serialization format on the wire. "otlp" is the OpenTelemetry
    standard. "herald" is the Herald-extension format used when shipping
    to herald.cloud or Herald.Server."""

    sample_rate: float = Field(default=1.0, ge=0.0, le=1.0)
    """Telemetry sampling rate, 0.0 to 1.0. Audit events bypass sampling
    regardless. Default 1.0 = capture everything."""

    # ---- Redaction -------------------------------------------------------

    redact: dict[str, str] = Field(default_factory=dict)
    """Field-name redaction rules: {"card_number": "last4", "ssn": "hash"}.
    See SDKPrinciples §9 for the available strategies. These rules
    complement Pydantic redact() markers and the safety pass."""

    safety_pass: SafetyPassMode = Field(default="on")
    """The universal-PII safety pass over free-text values. Default ON.
    Customers running >100 kHz workloads can opt out per-process; the
    server safety net continues regardless."""

    safety_patterns_path: str | None = Field(default=None)
    """Optional path to a tenant-managed pattern bundle TOML file.
    Patterns from this file extend (do not replace) the seven
    universal patterns shipped in the SDK."""

    safety_bundle_endpoint: str | None = Field(default=None)
    """Optional Herald.Server URL the SDK polls for pattern bundle
    updates. Lets tenants ship new patterns centrally without SDK
    redeploys."""

    safety_bundle_poll_seconds: int = Field(default=3600, gt=0)
    """How often the SDK polls safety_bundle_endpoint. Default 1 hour."""


# WHY a module-level holder and not a singleton class: the runtime is the
# singleton; settings is a frozen value the runtime captures at configure()
# time. Tests and the runtime composition root build settings instances
# directly and pass them through; no hidden global mutation.
_active_settings: HeraldSettings | None = None


def active() -> HeraldSettings:
    """Return the settings the runtime is currently using. Raises if
    configure() has not been called yet."""
    if _active_settings is None:
        raise RuntimeError(
            "herald.configure() has not been called. Call configure(...) "
            "at process start before any record() / audit() calls."
        )
    return _active_settings


def _set_active(settings: HeraldSettings) -> None:
    """Internal: install settings as active. Called by configure() in
    _config.py; not meant for customer use."""
    global _active_settings
    _active_settings = settings


def _reset_active_for_testing() -> None:
    """Internal: clear active settings. Pytest fixtures call this
    between tests so configure() in one test does not leak state to
    the next."""
    global _active_settings
    _active_settings = None
