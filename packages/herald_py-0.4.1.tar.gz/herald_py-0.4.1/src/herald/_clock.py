"""SystemClock — the production IClock implementation.

WHY this is its own file: every event factory threads through Clock.
Tests inject FrozenClock from herald.testing; production injects
SystemClock. Keeping the production impl tiny and isolated makes the
seam obvious.
"""

from __future__ import annotations

import time


class SystemClock:
    """Real wall-clock IClock. Returns nanoseconds since the Unix epoch.

    WHY time.time_ns() and not time.time(): time_ns gives nanosecond
    resolution without float precision loss. At 100 kHz event rates
    float-second timestamps can collide between events captured in the
    same nanosecond bucket; nanosecond integers cannot.
    """

    def now_ns(self) -> int:
        return time.time_ns()
