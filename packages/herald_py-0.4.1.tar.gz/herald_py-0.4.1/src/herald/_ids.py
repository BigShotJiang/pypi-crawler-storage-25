"""UlidGenerator — the production IIdGenerator implementation.

WHY three different shapes for IDs:

  - run_id is a string, Herald-specific. ULIDs are sortable by time
    (the first six bytes are the millisecond timestamp), which makes
    "events from this run, in order" cheap. Sortable run_ids also
    give the audit ledger natural ordering without an extra index.

  - trace_id is bytes (16), to match OpenTelemetry's W3C Trace Context
    spec. Tools that already speak OTel can ingest Herald events
    without translation. Random rather than ULID-derived: the OTel
    spec mandates random for unlinkability.

  - span_id is bytes (8), again OTel-compatible. Random.

Tests can inject a deterministic IIdGenerator from a future
herald.testing.ids fixture; production uses UlidGenerator everywhere.
"""

from __future__ import annotations

import secrets

from ulid import ULID


class UlidGenerator:
    """The production ID generator: ULIDs for run_id, random bytes
    for trace_id and span_id.

    WHY a class and not a module-level function: holds a place for
    future state (e.g. a CSPRNG seed override for testing) and matches
    the IIdGenerator protocol shape so the runtime can swap in a fake
    cleanly.
    """

    def new_run_id(self) -> str:
        """Return a fresh ULID stringified — 26 chars, sortable, URL-safe."""
        return str(ULID())

    def new_trace_id(self) -> bytes:
        """Return 16 random bytes — OTel-compatible trace_id.

        WHY random and not ULID-derived: OTel's W3C Trace Context spec
        treats trace_id as opaque random. Using ULID here would leak the
        trace start time; some compliance contexts care about that.
        """
        return secrets.token_bytes(16)

    def new_span_id(self) -> bytes:
        """Return 8 random bytes — OTel-compatible span_id."""
        return secrets.token_bytes(8)
