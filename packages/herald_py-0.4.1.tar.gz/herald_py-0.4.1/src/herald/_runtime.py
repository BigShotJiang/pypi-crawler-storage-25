"""_HeraldRuntime — the composition root the entire SDK orchestrates around.

WHY a single runtime singleton: every emit path (decorators, span(),
record(), audit()) needs the same Clock, IdGenerator, redactor, buffer,
exporter, and failure sink. Threading them through every call would
either pollute every public signature or rely on globals scattered
across modules. One named runtime, owned by this file, captured at
configure() time, used everywhere.

WHY this file is short despite its importance: the runtime is mostly
glue. Clock + IdGenerator + buffer + emit. Each piece is its own
module; the runtime just wires them together and exposes one method
the public surface calls.

WHY placeholder Null* implementations for chain/redactor/exporter:
M2 wires the capture path; M3-M6 swap each placeholder for the real
thing. Names like NullChainWriter say truthfully "this does nothing
yet" rather than pretending the work is done. When M4 lands the real
HmacChainWriter, the runtime swaps it in and every existing capture
test continues to pass without source changes.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass
from typing import Any, cast

from ._buffer import FileBuffer, InMemoryBuffer
from ._clock import SystemClock
from ._context import current_run_id
from ._ids import UlidGenerator
from ._models import HeraldEvent
from ._protocols import (
    IChainWriter,
    IClock,
    IExporter,
    IFailureSink,
    IIdGenerator,
    IRedactor,
)
from ._settings import HeraldSettings

# ---------------------------------------------------------------------------
# Placeholder implementations of the protocols not yet implemented
# ---------------------------------------------------------------------------


class NullChainWriter:
    """No-op IChainWriter. Telemetry events use this in production;
    audit events use this until M4 lands HmacChainWriter."""

    def write_audit_chain(self, event: Any, run_id: str) -> Any:
        return None


class PassThroughRedactor:
    """No-op IRedactor. Real redaction lands in M5."""

    def redact(self, event: Any) -> Any:
        return event


class NullExporter:
    """No-op IExporter. Real OTLP export lands in M6.

    WHY the method exists at all: the drain coordinator iterates
    exporters during shutdown. A NullExporter that accepts the call
    and does nothing keeps the drain code path clean until M6.
    """

    async def export_batch(self, events: list[Any]) -> None:
        return None


@dataclass
class StderrFailureSink:
    """Default IFailureSink: writes one line per failure to stderr.

    WHY default to stderr and not silence: a failed emit is a real
    operability signal — silencing it would let bugs hide. stderr is
    the lowest-friction place to put it; production deployments swap
    in a Sentry-shaped sink via configure().
    """

    rate_limit_per_second: int = 10

    def report(self, error: BaseException, context: dict[str, Any]) -> None:
        # WHY no rate limiting yet: M2 ships the simplest possible
        # default. M10 (operability) expands this to real rate limiting
        # and self-telemetry events. Until then a flood of failures
        # writes a flood of stderr lines, which is correct loudness for
        # a development environment.
        sys.stderr.write(
            f"herald: failure: {type(error).__name__}: {error} ({context})\n"
        )


# WHY this Union shape: the runtime holds either an InMemoryBuffer
# (default, fast, in-process) or a FileBuffer (rolling NDJSON files
# on disk). Both expose write_sync; tests inspect events via either
# .events (InMemoryBuffer) or .read_*_events() (FileBuffer).
_BufferLike = InMemoryBuffer | FileBuffer


# ---------------------------------------------------------------------------
# The runtime itself
# ---------------------------------------------------------------------------


@dataclass
class _HeraldRuntime:
    """The composition root. Holds one instance of each Phase 1 seam.

    WHY a dataclass: the runtime is effectively just a tuple of
    components plus an emit method. dataclass keeps the construction
    site readable.
    """

    settings: HeraldSettings
    clock: IClock
    id_gen: IIdGenerator
    buffer: _BufferLike
    redactor: IRedactor
    chain_writer: IChainWriter
    exporter: IExporter
    failures: IFailureSink

    def emit(
        self,
        *,
        kind: str,
        name: str,
        attributes: dict[str, Any] | None = None,
        severity: str = "INFO",
        chain_kind: str = "telemetry",
        duration_ns: int | None = None,
        span_id: bytes | None = None,
        trace_id: bytes | None = None,
        parent_span_id: bytes | None = None,
    ) -> HeraldEvent:
        """Build, redact, optionally chain, and durably write one event.

        Returns the built event so callers (decorators, span() context
        managers) can read fields like span_id afterwards. The emitted
        event is persisted to the buffer; the drain coordinator (M6)
        ships it later.

        WHY a fall-through orphan run_id: a stray @herald.tool called
        without an enclosing @herald.agent still emits an event — but
        with a fresh run_id created here. That keeps every captured
        event linked to *some* run, even if it was a misuse, and makes
        debugging "where did this orphan event come from" tractable.
        """
        try:
            run_id = current_run_id() or self.id_gen.new_run_id()
            # WHY parent_span_id is the value the caller passed,
            # period: the @agent boundary genuinely has no parent and
            # passes None. Falling back to current_parent_span_id()
            # here would re-read the contextvar from inside the
            # caller's just-pushed span_scope and return the caller's
            # own span_id. Every caller (decorator wrapper, span(),
            # aspan(), record(), audit()) is responsible for reading
            # the contextvar at the right moment and passing the
            # result to us; emit() trusts what it gets.

            event = HeraldEvent(
                event_id=self.id_gen.new_run_id(),
                trace_id=trace_id or self.id_gen.new_trace_id(),
                span_id=span_id or self.id_gen.new_span_id(),
                parent_span_id=parent_span_id,
                run_id=run_id,
                kind=kind,
                name=name,
                timestamp_ns=self.clock.now_ns(),
                duration_ns=duration_ns,
                attributes=attributes or {},
                severity=severity,  # type: ignore[arg-type]
                chain_kind=chain_kind,  # type: ignore[arg-type]
            )

            # WHY cast: IRedactor.redact returns Any (the protocol
            # accepts any event-like shape), but our internal call
            # site only ever passes a HeraldEvent and the return is
            # always a HeraldEvent. cast tells mypy what we know.
            event = cast(HeraldEvent, self.redactor.redact(event))

            # WHY chain only on audit kind: telemetry events skip the
            # MAC computation entirely (NullChainWriter for the runtime
            # default; M4's HmacChainWriter will be invoked here when
            # chain_kind == "audit"). Saves ~250 ns per telemetry event
            # and matches SDKPrinciples §1's audit-grade contract:
            # tamper-evidence is for the audit channel.
            if chain_kind == "audit":
                self.chain_writer.write_audit_chain(event, run_id)

            sync_mode = "FULL" if chain_kind == "audit" else "NORMAL"
            self.buffer.write_sync(event, sync_mode=sync_mode)

            return event
        except Exception as exc:
            self.failures.report(exc, {"kind": kind, "name": name})
            raise


def _build_buffer(settings: HeraldSettings) -> _BufferLike:
    """Pick the right buffer for the settings.durability mode.

    "memory" (default): InMemoryBuffer — fast, in-process, no disk.
    "files": FileBuffer — rolling NDJSON on disk, two channels.
    """
    if settings.durability == "files":
        return FileBuffer(settings)
    # Default and "memory" share the same shape.
    return InMemoryBuffer()


def _build_runtime(settings: HeraldSettings) -> _HeraldRuntime:
    """Assemble a runtime from settings.

    Reads top-to-bottom: clock, ids, redactor (placeholder), chain
    (placeholder), buffer (memory or files per settings), exporter
    (placeholder), failure sink. Later milestones replace each
    placeholder with the real thing; the assembly site changes by
    one line per swap.
    """
    return _HeraldRuntime(
        settings=settings,
        clock=SystemClock(),
        id_gen=UlidGenerator(),
        buffer=_build_buffer(settings),
        redactor=PassThroughRedactor(),
        chain_writer=NullChainWriter(),
        exporter=NullExporter(),
        failures=StderrFailureSink(),
    )


# ---------------------------------------------------------------------------
# Process-wide runtime singleton
# ---------------------------------------------------------------------------


_active_runtime: _HeraldRuntime | None = None


def active_runtime() -> _HeraldRuntime:
    """Return the runtime configured for this process. Raises if
    configure() has not been called yet."""
    if _active_runtime is None:
        raise RuntimeError(
            "herald.configure() has not been called. Call configure(...) "
            "at process start before any record(), audit(), or @herald "
            "decorator usage."
        )
    return _active_runtime


def _set_active_runtime(runtime: _HeraldRuntime | None) -> None:
    """Internal: install or clear the active runtime. configure() calls
    this from _config.py; tests reset it between cases."""
    global _active_runtime
    _active_runtime = runtime
