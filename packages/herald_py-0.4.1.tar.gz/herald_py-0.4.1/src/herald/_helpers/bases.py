"""Five Protocol / Base ABC pairs — Sink, Enricher, Filter, Formatter, Processor.

WHY both a Protocol AND a Base for each: authors who want full control
implement the raw Protocol; authors who want sensible defaults inherit the
Base. Both routes work; the Base is just convenience.

WHY these five and not more: they are the surfaces every later milestone
populates. Sinks are obvious. Enrichers add fields (GenAI semconv, ML
context). Filters drop events that should not ship. Formatters convert to
wire formats other than OTLP. Processors are catch-all transformers.
Anything beyond these five probably belongs server-side, not in the SDK.

Each Base supplies the same three defaults: to_config() round-trip,
manifest() lookup, and a sensible no-op fallback for the main verb. Reading
one Base teaches the reader all five.
"""

from __future__ import annotations

import sys
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Protocol, runtime_checkable

from .manifest import ComponentManifest, load_manifest_toml


def _resolve_default_manifest(cls: type) -> ComponentManifest:
    """Read manifest.toml alongside the module file of `cls`.

    WHY this lives here as a small private helper: the Base ABCs all need
    the same "find my manifest.toml" behavior. Centralizing it here keeps
    every Base's manifest() one-liner identical.

    WHY a fallback synthetic manifest: first-party Phase 1 components do
    not yet ship manifest.toml files. Returning a synthetic manifest with
    just the kind keeps tests and herald doctor functional until later
    milestones add real manifests per component.
    """
    module_name = cls.__module__
    module = sys.modules.get(module_name)
    module_file = getattr(module, "__file__", None) if module else None
    if module_file is None:
        return ComponentManifest(
            name=getattr(cls, "kind", cls.__name__),
            description=cls.__doc__ or cls.__name__,
        )

    manifest_path = Path(module_file).parent / "manifest.toml"
    if not manifest_path.exists():
        return ComponentManifest(
            name=getattr(cls, "kind", cls.__name__),
            description=cls.__doc__ or cls.__name__,
        )

    return load_manifest_toml(manifest_path)


# ---------------------------------------------------------------------------
# Sink — receives events and disposes of them (network, file, etc.)
# ---------------------------------------------------------------------------


@runtime_checkable
class Sink(Protocol):
    """Anywhere events go to leave the SDK. OTLP/gRPC, Splunk, S3, etc."""

    kind: str
    """Registry key — must match the kind under which the class is registered."""

    async def log(self, event: Any) -> None:
        """Ship a single event."""
        ...

    def to_config(self) -> dict[str, Any]:
        """Return a dict that, fed back into the registry, recreates an
        equivalent instance. Required for hot-reload and herald doctor."""
        ...


class BaseSink(ABC):
    """Default Sink implementation. Override `log` only; everything else
    is supplied.

    WHY a Base alongside the Protocol: 90% of sinks just want to ship
    events and let the SDK handle the rest. Inheriting from BaseSink
    means a sink author writes one method (log) and gets the defaults
    for free.
    """

    kind: str = "base"

    @abstractmethod
    async def log(self, event: Any) -> None:
        """Ship one event. Subclasses must implement."""
        ...

    async def batch_log(self, events: list[Any]) -> None:
        """Default batch implementation: loop over `log`. The drain
        coordinator detects sinks that override this with a real batch
        path (via hasattr check) and uses it for performance."""
        for event in events:
            await self.log(event)

    def to_config(self) -> dict[str, Any]:
        """Default: return only the kind. Subclasses override to add
        their own knobs."""
        return {"kind": self.kind}

    def manifest(self) -> Any:
        """Default: read manifest.toml from the directory containing the
        subclass module. Subclasses can override to provide a manifest
        programmatically."""
        return _resolve_default_manifest(type(self))


# ---------------------------------------------------------------------------
# Enricher — adds fields to an event (GenAI semconv, model context, etc.)
# ---------------------------------------------------------------------------


@runtime_checkable
class Enricher(Protocol):
    """Adds context fields to events as they pass through the pipeline."""

    kind: str

    def enrich(self, event: Any) -> Any:
        """Return an event with additional fields. May return the same
        instance if no enrichment applies."""
        ...

    def to_config(self) -> dict[str, Any]: ...


class BaseEnricher(ABC):
    """Default Enricher: subclasses override `enrich`. Returning the same
    event unchanged is a valid no-op."""

    kind: str = "base"

    @abstractmethod
    def enrich(self, event: Any) -> Any: ...

    def to_config(self) -> dict[str, Any]:
        return {"kind": self.kind}

    def manifest(self) -> Any:
        return _resolve_default_manifest(type(self))


# ---------------------------------------------------------------------------
# Filter — decides whether an event should continue through the pipeline
# ---------------------------------------------------------------------------


@runtime_checkable
class Filter(Protocol):
    """A predicate over events. True means keep, False means drop."""

    kind: str

    def allow(self, event: Any) -> bool: ...

    def to_config(self) -> dict[str, Any]: ...


class BaseFilter:
    """Default Filter: allow-by-default. Subclasses override `allow`
    when they want to reject.

    WHY not ABC: the default `allow` is concrete (returns True). There
    is no abstract method that subclasses must implement. Inheriting
    from ABC without an abstract method is a ruff B024 anti-pattern.

    WHY allow-by-default: the SDK does not silently drop events. A
    subclass that wants to drop must explicitly say so. Default-deny
    would be a foot-gun.
    """

    kind: str = "base"

    def allow(self, event: Any) -> bool:
        """Default: accept everything. Override to reject."""
        return True

    def to_config(self) -> dict[str, Any]:
        return {"kind": self.kind}

    def manifest(self) -> Any:
        return _resolve_default_manifest(type(self))


# ---------------------------------------------------------------------------
# Formatter — converts an event to a wire format (OTLP, ECS, etc.)
# ---------------------------------------------------------------------------


@runtime_checkable
class Formatter(Protocol):
    """Converts an in-memory event to a serialized wire payload."""

    kind: str

    def format(self, event: Any) -> bytes: ...

    def to_config(self) -> dict[str, Any]: ...


class BaseFormatter(ABC):
    """Default Formatter: subclasses must implement `format`. No safe
    default exists for serialization."""

    kind: str = "base"

    @abstractmethod
    def format(self, event: Any) -> bytes: ...

    def to_config(self) -> dict[str, Any]:
        return {"kind": self.kind}

    def manifest(self) -> Any:
        return _resolve_default_manifest(type(self))


# ---------------------------------------------------------------------------
# Processor — generic event transformer
# ---------------------------------------------------------------------------


@runtime_checkable
class Processor(Protocol):
    """Transforms events. Catch-all when an Enricher or Filter does not
    fit the use case."""

    kind: str

    def process(self, event: Any) -> Any: ...

    def to_config(self) -> dict[str, Any]: ...


class BaseProcessor:
    """Default Processor: pass-through. Subclasses override `process`
    when they want to transform.

    WHY not ABC: the default `process` is concrete (returns the event
    unchanged). No abstract method, so ABC inheritance is dead weight.
    """

    kind: str = "base"

    def process(self, event: Any) -> Any:
        """Default: return the event unchanged."""
        return event

    def to_config(self) -> dict[str, Any]:
        return {"kind": self.kind}

    def manifest(self) -> Any:
        return _resolve_default_manifest(type(self))
