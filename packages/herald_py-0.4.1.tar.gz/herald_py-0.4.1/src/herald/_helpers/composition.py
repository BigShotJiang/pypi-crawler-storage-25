"""Composite[T] and compose() — the two ways Herald assembles components.

WHY two helpers and not one: they solve different problems.

  - Composite[T] dispatches one call to many components (an enricher chain
    runs every enricher in order). Order matters; failure of one stops or
    continues based on policy.

  - compose() wraps a single inner component in a stack of decorators
    (the drain coordinator is `circuit_breaker(retry(batch(exporter)))`).
    The decorators do not run independently; each delegates to the next.

Both shapes appear repeatedly in the SDK. Naming them and shipping them
once means later milestones do not reinvent either pattern.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Generic, TypeVar

T = TypeVar("T")


class Composite(Generic[T]):
    """Multi-instance dispatcher: holds a list of T and exposes them as
    one T-like surface.

    The actual dispatch behavior depends on what T is — an Enricher
    composite iterates and applies each enricher in order; a Filter
    composite chains predicates with logical AND. Composite itself is the
    storage and iteration mechanism; subclasses or wrappers add the
    per-component-type dispatch logic.

    WHY a class and not a list: exposes .add() and iteration through one
    named shape that reads as a single component to the runtime. Later
    integrations register Composite instances with the runtime exactly
    like single components.
    """

    def __init__(self, components: list[T] | None = None) -> None:
        # WHY a private list: callers should use .add() so we can later
        # add validation (no duplicates, type checks, etc.) without an API
        # change. Direct list access leaks the internals.
        self._components: list[T] = list(components) if components else []

    def add(self, component: T) -> None:
        """Append a component. Order is preserved; later components run
        after earlier ones."""
        self._components.append(component)

    def extend(self, components: list[T]) -> None:
        """Append several components at once."""
        self._components.extend(components)

    def __iter__(self):  # type: ignore[no-untyped-def]
        """Iterate the contained components in registration order."""
        return iter(self._components)

    def __len__(self) -> int:
        return len(self._components)

    def __bool__(self) -> bool:
        return bool(self._components)


def compose(
    inner: T,
    decorators: list[Callable[[T], T]],
) -> T:
    """Wrap `inner` in a stack of decorators applied right-to-left.

    Reading order matches the semantics: the first decorator in the list
    is the outermost, the last is the innermost (closest to inner).

    Example — the drain coordinator from SDKPrinciples §11 seam #3:

        drain = compose(
            inner=OtlpExporter(),
            decorators=[circuit_breaker, retry, batch],
        )
        # produces: circuit_breaker(retry(batch(OtlpExporter())))

    WHY a function and not a class: the result IS the inner type T
    (decorated, but still shaped like an exporter). A Composed[T] class
    would force callers to unwrap; a function returns the same shape the
    runtime already speaks.

    WHY right-to-left application: matches how readers write the
    composition. The first decorator listed is the one a request hits
    first — the outermost. Reversing this would surprise every reviewer.
    """
    result = inner
    # WHY reversed(): apply innermost first so the outer wraps it. The
    # listed order is read as "outer first" but the application order is
    # "inner first" — composing is the small place that flips the two.
    for decorator in reversed(decorators):
        result = decorator(result)
    return result
