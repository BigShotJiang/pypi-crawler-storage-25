"""Generic kind-string registry for sinks, enrichers, filters, formatters,
processors, and any future component class.

WHY one generic class instead of five hand-rolled Registry classes: every
later integration registers itself by a kind string ("otlp", "splunk", etc.)
and the runtime resolves that string to a class. If we wrote a separate
Registry per component type, plugin authors would have five subtly-different
APIs to learn. One Registry[T] class, parametrized by the component type,
gives every registry the same shape — so the reader who reads the sink
registry already knows how the enricher registry behaves.

WHY a class and not a module-level dict: Registry tracks the component type
parameter for static typing, supports decorators, supports entry-point
discovery, and exposes a single .resolve() method consumers bind to. A bare
dict cannot do typed retrieval cleanly.

Usage:

    from herald._helpers.registry import Registry, register

    sinks: Registry[type[Sink]] = Registry("sink")

    @register("otlp", sinks)
    class OtlpSink: ...

    cls = sinks.resolve("otlp")  # type: type[Sink]
"""

from __future__ import annotations

from collections.abc import Callable, Iterable
from importlib.metadata import entry_points
from typing import Generic, TypeVar

T = TypeVar("T")


class RegistryError(Exception):
    """Raised when a registry operation fails (duplicate kind, missing kind, etc.)."""


class Registry(Generic[T]):
    """Maps kind strings to component classes (or factories).

    The registry stores whatever T is — usually a class but it can be any
    callable that produces a component. The runtime resolves a kind string
    from configuration ("otlp", "sqlite", etc.) to the registered T and
    instantiates it.

    WHY a name on the registry: error messages read clearly. "Unknown
    sink kind: 'foo'" is much more useful than "Unknown kind: 'foo'".
    """

    def __init__(self, name: str) -> None:
        self._name = name
        # WHY a private dict: we want to expose .resolve() / .register()
        # as the only mutation paths. Direct dict access from callers
        # would let bugs slip in (overwrite a kind, drop a key) that the
        # public API explicitly prevents.
        self._items: dict[str, T] = {}

    @property
    def name(self) -> str:
        """The registry's name, used in error messages."""
        return self._name

    def register(self, kind: str, item: T, *, replace: bool = False) -> T:
        """Register `item` under `kind`. Returns `item` so this composes
        cleanly with decorators (see the @register helper below).

        WHY replace defaults to False: silent overwrites are the leading
        cause of "why is the wrong sink active?" bugs. Plugin authors
        who genuinely want to override pass replace=True explicitly.
        """
        if not kind:
            raise RegistryError(f"{self._name} kind must be a non-empty string")

        if kind in self._items and not replace:
            raise RegistryError(
                f"{self._name} kind {kind!r} is already registered. "
                f"Pass replace=True if the override is intentional."
            )

        self._items[kind] = item
        return item

    def resolve(self, kind: str) -> T:
        """Return the item registered under `kind`. Raises RegistryError
        if the kind is unknown."""
        try:
            return self._items[kind]
        except KeyError:
            known = ", ".join(sorted(self._items)) or "(empty registry)"
            raise RegistryError(
                f"unknown {self._name} kind {kind!r}. Known kinds: {known}"
            ) from None

    def kinds(self) -> Iterable[str]:
        """Iterate the registered kinds. Useful for `herald doctor`-style
        introspection."""
        return tuple(self._items.keys())

    def __contains__(self, kind: str) -> bool:
        return kind in self._items

    def __len__(self) -> int:
        return len(self._items)

    def __repr__(self) -> str:
        return f"Registry(name={self._name!r}, kinds={sorted(self._items)})"


def register(kind: str, registry: Registry[T], *, replace: bool = False) -> Callable[[T], T]:
    """Decorator over a class or factory to register it under `kind`.

    Composes cleanly with @dataclass, @final, and other class decorators.
    The decorated object is returned unchanged so import-time wiring does
    not surprise the reader.

    Example:
        @register("otlp", sinks)
        class OtlpSink: ...

    WHY a free function and not Registry.decorate(): the explicit
    `register(kind, registry)` form reads top-to-bottom — kind first,
    registry second — which is the same order a reader scans. Forms like
    `sinks.register("otlp")(OtlpSink)` invert that.
    """

    def _wrap(item: T) -> T:
        return registry.register(kind, item, replace=replace)

    return _wrap


def discover_entry_points(group: str, registry: Registry[T]) -> int:
    """Walk Python entry points in `group` and register each into `registry`.

    Returns the count of registered items. Plugin packages declare their
    entry points in their own pyproject.toml, e.g.:

        [project.entry-points."herald.sinks"]
        otlp = "herald_otlp:OtlpSink"

    At configure() time the runtime calls discover_entry_points("herald.sinks",
    sinks_registry) and every installed plugin shows up automatically — no
    explicit register() calls in user code.

    WHY entry points and not a discover-by-import-name scheme: entry points
    are the canonical Python plugin mechanism. Datadog, OpenTelemetry, and
    setuptools itself all use them. Reusing the convention means plugin
    authors do not learn a Herald-specific discovery system.
    """
    count = 0
    # WHY group= keyword: importlib.metadata.entry_points() in Python 3.10+
    # supports filtering by group via keyword argument. Older positional
    # forms are deprecated.
    for ep in entry_points(group=group):
        # WHY ep.load() and not eval: load() goes through the proper
        # importlib resolution and respects sys.path. Plugin authors trust
        # the same import mechanics they use everywhere.
        item = ep.load()
        registry.register(ep.name, item)
        count += 1
    return count
