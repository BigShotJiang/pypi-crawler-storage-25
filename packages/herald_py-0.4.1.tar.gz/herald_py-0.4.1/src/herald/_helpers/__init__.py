"""The named helpers used everywhere in the SDK.

These are the pieces every later component composes from. They are NOT part
of the public surface — customers compose against `herald` directly. Plugin
authors compose against the helpers re-exported through `herald.testing`
and (in later milestones) `herald.integrations`.

Modules:
  registry     — Generic kind-string Registry[T] + @register decorator.
  manifest     — ComponentManifest Pydantic record + load_manifest_toml.
  composition  — Composite[T] dispatcher + compose() decorator-stack helper.
  bases        — Five Protocol/Base ABC pairs with shared defaults.

WHY the catalog stays small (24 named pieces total across all milestones):
the vocabulary is closed on purpose. Every plugin author learns the same
12 helpers; every code review rejects re-implementations of any of them.
See SDKPrinciples §4 for the catalog and the rejected anti-patterns list.
"""

from __future__ import annotations
