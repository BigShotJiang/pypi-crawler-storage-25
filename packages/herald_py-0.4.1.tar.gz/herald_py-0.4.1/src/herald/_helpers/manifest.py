"""ComponentManifest — the metadata every Herald component carries.

WHY every component has a manifest: `herald doctor`, the future dashboard,
OTLP coexistence detection, and the plugin-author guide all need a
consistent way to ask "what is this component, what does it do, what
versions does it support?" Without a shared shape, every consumer of that
information would have to write bespoke per-component readers.

WHY Pydantic and not a dataclass: validation at boundaries. A manifest
loaded from a TOML file should fail loudly on a typo'd field name; a
dataclass would silently drop unknown fields. Pydantic ConfigDict
(extra="forbid") makes manifests a tight contract.

Usage:

    manifest = ComponentManifest(
        name="otlp",
        description="OpenTelemetry OTLP/gRPC exporter",
        vendor="Herald",
        version="1.0.0",
    )

    # Or load from a TOML file alongside the component:
    manifest = load_manifest_toml(__file__)
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

# WHY this dance: tomllib is stdlib in 3.11+. On 3.10 we depend on the
# `tomli` package (declared in pyproject.toml as a python_version<3.11
# conditional). Both expose the same load() / loads() API so the rest of
# this module is identical.
if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib


class ComponentManifest(BaseModel):
    """One component's self-description.

    Fields beyond name/description/vendor/version are optional and exist
    so future tooling does not need a manifest format change to use them.
    Phase 1 components fill in name/description/vendor/version; later
    milestones populate capabilities, limitations, and config_schema as
    the manifest format earns more consumers.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    name: str = Field(min_length=1)
    """Short kind string. Must match the registry key the component
    registers under (e.g. "otlp" matches sinks.register("otlp", ...))."""

    description: str = Field(min_length=1)
    """One-line human-readable description — shows up in `herald doctor`."""

    vendor: str = Field(default="Herald")
    """Who maintains the component. "Herald" for first-party, customer
    name or org for third-party plugins."""

    version: str = Field(default="0.0.0")
    """SemVer string. Matches the plugin package version, not the SDK
    version it targets."""

    min_sdk_version: str | None = Field(default=None)
    """Lowest herald-py version this component supports. None means no
    minimum. Used by `herald doctor` to flag version-skew at startup."""

    capabilities: tuple[str, ...] = Field(default=())
    """Free-form tags describing what the component can do. Examples:
    "batch", "streaming", "audit". Used by the runtime to opt into
    optional behaviors (e.g. drain coordinator detects "batch" and uses
    batch_log instead of looping over log)."""

    limitations: tuple[str, ...] = Field(default=())
    """Free-form tags describing what the component cannot do. Surface
    by `herald doctor` so operators see "splunk_sink: limitations:
    no-tls-1.0" without having to read the source."""

    config_schema: dict[str, Any] | None = Field(default=None)
    """Optional JSON Schema describing the component's config knobs.
    A future dashboard renders a form from this. Phase 1 ships
    components with config_schema=None; later milestones fill it in."""


def load_manifest_toml(package_or_path: str | Path) -> ComponentManifest:
    """Read a manifest.toml file alongside the given path and return a
    ComponentManifest.

    Convention: a component's TOML manifest lives at `manifest.toml` in
    the same directory as its `__init__.py`. Pass `__file__` from the
    component module to find it.

    WHY TOML and not JSON: TOML is human-edited (plugin authors write
    these by hand). The `tomllib` module ships in stdlib from 3.11; on
    3.10 we use `tomli` (declared as a conditional dep in pyproject.toml)
    transparently — see the import block at the top of this file.
    """
    path = Path(package_or_path)
    # WHY this resolution: callers pass __file__ from a module, which is
    # the path to that module's .py file. We want the manifest in the
    # same directory.
    if path.is_file():
        path = path.parent
    manifest_path = path / "manifest.toml"

    if not manifest_path.exists():
        raise FileNotFoundError(
            f"no manifest.toml at {manifest_path} — every Herald "
            f"component must ship one (see SDKPrinciples §11 seam #2)"
        )

    with manifest_path.open("rb") as f:
        data = tomllib.load(f)

    # WHY the [component] table: TOML files often contain other tables
    # (tool-specific config, test data). The manifest goes under a
    # specific [component] table to keep the file usable for other
    # purposes if the plugin author wants.
    if "component" not in data:
        raise ValueError(
            f"{manifest_path}: missing required [component] table"
        )

    return ComponentManifest(**data["component"])
