"""Public configure() entry point — a thin wrapper over HeraldSettings.

WHY this file is now small: M1 moved the actual settings shape into
_settings.py (as HeraldSettings, a pydantic-settings BaseSettings).
This file kept the configure() / active() / HeraldConfig public names
the rest of the SDK already imports, but every one of them now
delegates to _settings.

Sync-callable; safe to invoke from async code. configure() runs once at
process start before any async work begins, so it does not block an
event loop.
"""

from __future__ import annotations

from typing import Any

from . import _settings as _settings_mod
from ._settings import (
    DropPolicy,
    DurabilityMode,
    HeraldSettings,
    SafetyPassMode,
    WireFormat,
)

# Backwards-compatible alias. Older internal code imported HeraldConfig;
# the new name is HeraldSettings. Both point at the same class.
HeraldConfig = HeraldSettings


def configure(**kwargs: Any) -> None:
    """Set process-wide SDK configuration.

    Every keyword arg corresponds to a HeraldSettings field. Environment
    variables HERALD_* fill in any unset values. See _settings.py for
    the full field list and SDKPrinciples §16 for the env-var matrix.

    Pydantic raises ValidationError on invalid values (unknown
    durability mode, sample_rate outside [0, 1], non-positive
    durability_max_bytes, etc.). The error message names the offending
    field — pass it through to the customer unchanged.

    WHY configure() now also builds the runtime: M2 wires the capture
    path into a single composition root in _runtime.py. configure()
    becomes the place that builds it once, installs it as the
    process-wide singleton, and unblocks every emit path.
    """
    # Local import to avoid a circular import at module load time —
    # _runtime imports _settings and _models, both of which the
    # public surface chain back to.
    from . import _runtime as _runtime_mod

    settings = HeraldSettings(**kwargs)
    _settings_mod._set_active(settings)
    _runtime_mod._set_active_runtime(_runtime_mod._build_runtime(settings))


def active() -> HeraldSettings:
    """Return the settings the runtime is currently using. Raises if
    configure() has not been called yet."""
    return _settings_mod.active()


__all__ = [
    "DropPolicy",
    "DurabilityMode",
    "HeraldConfig",
    "HeraldSettings",
    "SafetyPassMode",
    "WireFormat",
    "active",
    "configure",
]
