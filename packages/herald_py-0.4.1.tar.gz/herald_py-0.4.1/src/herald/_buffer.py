"""Buffer implementations for the runtime.

Two production buffer shapes:

  - InMemoryBuffer: holds events in a list. Default. Fast for unit
    tests and for customers who do not need on-disk durability.

  - FileBuffer: persists events to rolling NDJSON files via FileManager.
    Telemetry events go to one channel (no per-event fsync); audit
    events go to a separate channel with fsync after every line.

Both satisfy the runtime's expected `write_sync(event, sync_mode)`
contract. The runtime swaps between them based on
`HeraldSettings.durability` ("memory" or "files").

WHY a sync-only contract here in M3: SDKPrinciples §1 says record()
and audit() are sync-callable. The full IBuffer protocol (with async
write / drain_unsent / mark_sent) lights up in M6 when the OTLP
exporter and drain coordinator land. M3's buffer is sync-write +
periodic-flush; the async drain loop is M6's concern.

WHY two channels (telemetry + audit) in FileBuffer: different fsync
policies and different retention. Audit events fsync per row for the
durability promise; telemetry events fsync periodically for
performance. Mixing them in one file forces one policy to win.

NDJSON on-disk format — the cross-language contract:

  - One canonical-JSON event per line, encoded UTF-8.
  - The encoder uses orjson with OPT_SORT_KEYS for byte-level
    determinism (required for the future audit-chain MAC).
  - bytes fields (trace_id, span_id, parent_span_id) serialise to
    base64 per Pydantic v2 model_config ser_json_bytes="base64".
  - Empty / None fields are omitted (orjson default).

The .NET FileManager (when it lands) reads the same file shape.
"""

from __future__ import annotations

import threading
from pathlib import Path
from typing import Any

import orjson

from ._files import FileManager, FileManagerPolicy
from ._models import HeraldEvent
from ._settings import HeraldSettings


def serialize_event(event: HeraldEvent) -> bytes:
    """Serialise one event to canonical NDJSON bytes (one event, no trailing newline).

    WHY orjson with OPT_SORT_KEYS: deterministic byte output is the
    foundation of the audit chain MAC (M4). Two implementations that
    serialise the same event must produce identical bytes. orjson
    with sorted keys gives that across Python versions and across
    Python and .NET (when the C# side picks a sorted-keys encoder).

    WHY model_dump(mode='json'): the HeraldEvent model has bytes
    fields (trace_id, span_id, parent_span_id) that the model_config
    serialises as base64 strings via ser_json_bytes="base64". Plain
    model_dump() returns those as raw bytes which orjson cannot
    encode. mode='json' applies the model's JSON encoders so we get
    a dict of JSON-ready scalars that orjson handles cleanly.
    """
    return orjson.dumps(
        event.model_dump(mode="json"),
        option=orjson.OPT_SORT_KEYS,
    )


class InMemoryBuffer:
    """The default buffer: an in-memory list of events.

    Used by tests and by customers who do not need on-disk durability.
    Replaces the M2 `_PendingBuffer` placeholder.
    """

    def __init__(self) -> None:
        self.events: list[HeraldEvent] = []

    def write_sync(self, event: HeraldEvent, sync_mode: str = "NORMAL") -> None:
        # WHY the sync_mode parameter is accepted but ignored: it is
        # part of the buffer contract (FileBuffer honours it). This
        # impl just appends. Tests that want to assert on sync_mode
        # use a different fixture.
        del sync_mode
        self.events.append(event)


class FileBuffer:
    """Persists events to two rolling-NDJSON channels — telemetry + audit.

    Each channel owns its own `FileManager`. The two channels share a
    parent directory but live in subdirectories so retention is
    independent.

    Layout under `directory_path`:

      <dir>/telemetry/events-2026-05-05.1.ndjson
      <dir>/telemetry/events-2026-05-05.2.ndjson      (rolled)
      <dir>/audit/audit-2026-05-05.1.ndjson           (fsync per line)
      <dir>/audit/audit-2026-05-04.1.ndjson           (rolled)

    WHY separate FileManagers per channel: the durability and
    retention policies differ. Telemetry can be lossy under pressure;
    audit cannot. One FileManager per channel keeps the policies
    independent and matches SDKPrinciples §9's "audit channel is
    different" framing.
    """

    def __init__(self, settings: HeraldSettings) -> None:
        if settings.durability_path is None:
            raise ValueError(
                "FileBuffer requires durability_path to be set in HeraldSettings"
            )
        # WHY one parent + two children: separate retention per channel,
        # and operators / dashboards can browse one tree to see both.
        base = Path(settings.durability_path)

        self._telemetry = FileManager(
            FileManagerPolicy(
                directory=str(base / "telemetry"),
                file_name_template="events-{date}.{seq}",
                extension=".ndjson",
                interval="Daily",
                # WHY split the bytes cap roughly in half between
                # channels: durability_max_bytes is the operator's
                # total budget for the buffer. Audit gets the smaller
                # half because audit volume is 1-5% of telemetry per
                # SDKPrinciples §7.
                max_bytes_per_file=None,  # rely on time-based rolling
                total_size_cap_bytes=int(settings.durability_max_bytes * 0.95),
                clean_roll_on_startup=True,
            )
        )

        self._audit = FileManager(
            FileManagerPolicy(
                directory=str(base / "audit"),
                file_name_template="audit-{date}.{seq}",
                extension=".ndjson",
                interval="Daily",
                max_bytes_per_file=None,
                total_size_cap_bytes=int(settings.durability_max_bytes * 0.05),
                clean_roll_on_startup=True,
            )
        )

        # WHY a lock around channel selection: writes to the two
        # channels are independent inside their own FileManagers, but
        # we want the channel-selection + write to be one atomic step
        # from the caller's perspective.
        self._lock = threading.Lock()

    @property
    def telemetry_path(self) -> str:
        """Active telemetry NDJSON file path."""
        return self._telemetry.active_path

    @property
    def audit_path(self) -> str:
        """Active audit NDJSON file path."""
        return self._audit.active_path

    def write_sync(self, event: HeraldEvent, sync_mode: str = "NORMAL") -> None:
        """Persist one event to the right channel.

        sync_mode "FULL" forces an fsync after the line lands. The
        runtime sets FULL for audit events; NORMAL otherwise. The
        contract: when this returns, the bytes are at least in the OS
        write cache; when sync_mode=FULL, they are on disk.
        """
        line = serialize_event(event)
        target = self._audit if event.chain_kind == "audit" else self._telemetry

        with self._lock:
            target.append_line(line.decode("utf-8"))
            # WHY fsync per audit row: SDKPrinciples §1 — audit()
            # returns only after the event is durably on disk. NORMAL
            # mode skips the fsync; the OS may flush at its own pace.
            if sync_mode == "FULL":
                target.flush()

    def close(self) -> None:
        """Close both channel FileManagers."""
        with self._lock:
            self._telemetry.close()
            self._audit.close()

    # ---- Test / inspection helpers (not part of the runtime contract) ---

    def read_telemetry_events(self) -> list[dict[str, Any]]:
        """Read every event currently written to the active telemetry file.

        Helper for tests that assert "what got written?". Returns the
        parsed JSON of each NDJSON line in the active file. Rolled
        files are not included.
        """
        return _read_ndjson(Path(self._telemetry.active_path))

    def read_audit_events(self) -> list[dict[str, Any]]:
        """Read every event currently written to the active audit file."""
        return _read_ndjson(Path(self._audit.active_path))


def _read_ndjson(path: Path) -> list[dict[str, Any]]:
    """Parse one NDJSON file into a list of dicts. Test helper only."""
    if not path.exists():
        return []
    with path.open("rb") as f:
        return [orjson.loads(line) for line in f if line.strip()]
