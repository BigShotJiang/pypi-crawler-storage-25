"""Public decorators: @agent, @tool, @llm_call.

WHY each decorator is a span-builder, not a function-tracer: the SDK
captures *the call* — its inputs, outputs, timing, and any error
that bubbled out — as one event. Wrapping the function as a span
lets the body run normally; the decorator handles capture entirely
around it.

Three decorators, three meanings:

  - @agent — top-level boundary of an agent run. Sets up the run_id
    that everything inside shares. Has no parent span.

  - @tool — anything the agent can invoke. Opens a child span under
    whatever span_stack is currently active.

  - @llm_call — manual model invocations outside the auto-instrumented
    LLM SDKs. Adds GenAI semconv attributes (gen_ai.request.model and
    gen_ai.system) so the captured event reads like a native
    instrumentation.

WHY both sync and async wrappers: customer agents are written in a
mix. We detect the wrapped function's async-ness once at decoration
time and pick the right wrapper. The cost is a tiny amount of
imports complexity here in exchange for one decorator API that works
on both shapes.
"""

from __future__ import annotations

import asyncio
import functools
from collections.abc import Awaitable, Callable, Iterator
from contextlib import contextmanager
from typing import Any, ParamSpec, TypeVar, overload

from ._context import current_parent_span_id, run_scope, span_scope
from ._runtime import active_runtime

P = ParamSpec("P")
R = TypeVar("R")


def agent(
    *,
    name: str,
    version: str | None = None,
) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Mark a function as the top-level boundary of an agent run.

    Every event captured inside the decorated function — including
    @herald.tool calls, span() blocks, record() / audit() emissions —
    shares the same run_id. If the agent function calls itself
    recursively or is invoked twice, each top-level invocation gets
    its own run_id; nested invocations from inside an active run
    share the outer run's id.
    """
    extra: dict[str, Any] = {}
    if version is not None:
        extra["agent.version"] = version
    return _make_decorator(kind="agent", name=name, extra=extra, opens_run=True)


def tool(
    *,
    name: str,
) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Mark a function as a tool the agent can invoke.

    Opens a child span under the current span_stack. If called outside
    any @herald.agent boundary, the runtime synthesizes an orphan
    run_id so the tool event still has a run to belong to (and the
    failure sink notes the misuse)."""
    return _make_decorator(kind="tool", name=name, extra={}, opens_run=False)


def llm_call(
    *,
    model: str,
    provider: str | None = None,
) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Mark a function as a manual LLM invocation outside auto-instrumented SDKs.

    Tags the captured event with OTel GenAI semantic-convention
    attributes — `gen_ai.request.model` and `gen_ai.system` — so
    OTel-aware backends ingest it identically to an auto-instrumented
    OpenAI or Anthropic call.
    """
    extra: dict[str, Any] = {"gen_ai.request.model": model}
    if provider is not None:
        extra["gen_ai.system"] = provider
    return _make_decorator(kind="llm_call", name=model, extra=extra, opens_run=False)


def _make_decorator(
    *,
    kind: str,
    name: str,
    extra: dict[str, Any],
    opens_run: bool,
) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Build a decorator that captures the call as a span.

    WHY this helper exists: the three public decorators differ only in
    `kind`, `name`, and whether they open a fresh run. Centralizing
    the wrapping logic here means the open / time / build-event /
    pop-on-exit flow is implemented once and reused.
    """

    @overload
    def decorator(fn: Callable[P, Awaitable[R]]) -> Callable[P, Awaitable[R]]: ...
    @overload
    def decorator(fn: Callable[P, R]) -> Callable[P, R]: ...

    def decorator(fn: Callable[P, Any]) -> Callable[P, Any]:
        if asyncio.iscoroutinefunction(fn):
            return _wrap_async(fn, kind=kind, name=name, extra=extra, opens_run=opens_run)
        return _wrap_sync(fn, kind=kind, name=name, extra=extra, opens_run=opens_run)

    return decorator


def _wrap_sync(
    fn: Callable[P, R],
    *,
    kind: str,
    name: str,
    extra: dict[str, Any],
    opens_run: bool,
) -> Callable[P, R]:
    @functools.wraps(fn)
    def sync_wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
        rt = active_runtime()
        span_id = rt.id_gen.new_span_id()
        # WHY parent is captured BEFORE span_scope: once we push our own
        # span_id, current_parent_span_id() would return our own id, not
        # the enclosing parent's. Reading it here freezes the right
        # parent for the eventual emit.
        parent_span_id = current_parent_span_id()
        start_ns = rt.clock.now_ns()

        # WHY two nested context managers: opens_run sets the run_id
        # for the entire body if this is an @agent boundary; span_scope
        # pushes the new span_id onto the stack so any inner @tool or
        # span() finds it as their parent. Both reset on exception
        # because they are contextmanagers — no try/finally needed
        # around them.
        with _maybe_run_scope(rt, opens_run), span_scope(span_id):
            try:
                return fn(*args, **kwargs)
            finally:
                duration_ns = rt.clock.now_ns() - start_ns
                # WHY duration is computed BEFORE emit but the emit
                # itself is in the finally: we want the captured event
                # to record the actual time the body took, even if it
                # raised. The exception still propagates after emit.
                rt.emit(
                    kind=kind,
                    name=name,
                    attributes=dict(extra),
                    duration_ns=duration_ns,
                    span_id=span_id,
                    parent_span_id=parent_span_id,
                )

    return sync_wrapper


def _wrap_async(
    fn: Callable[P, Awaitable[R]],
    *,
    kind: str,
    name: str,
    extra: dict[str, Any],
    opens_run: bool,
) -> Callable[P, Awaitable[R]]:
    @functools.wraps(fn)
    async def async_wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
        rt = active_runtime()
        span_id = rt.id_gen.new_span_id()
        # See sync_wrapper note — capture parent before push.
        parent_span_id = current_parent_span_id()
        start_ns = rt.clock.now_ns()

        with _maybe_run_scope(rt, opens_run), span_scope(span_id):
            try:
                return await fn(*args, **kwargs)
            finally:
                duration_ns = rt.clock.now_ns() - start_ns
                rt.emit(
                    kind=kind,
                    name=name,
                    attributes=dict(extra),
                    duration_ns=duration_ns,
                    span_id=span_id,
                    parent_span_id=parent_span_id,
                )

    return async_wrapper


# WHY a context-manager helper: the @agent path wants run_scope; @tool
# and @llm_call want a no-op. A single helper that returns either
# avoids duplicating the full wrapper twice.


@contextmanager
def _maybe_run_scope(rt: Any, opens_run: bool) -> Iterator[None]:
    if not opens_run:
        yield
        return
    # WHY we always mint a fresh run_id at the @agent boundary: if a
    # second @agent runs inside an active run (recursion or unusual
    # composition), the outer run's identity should not be inherited.
    # Each top-level @agent invocation is conceptually one "run."
    new_run_id = rt.id_gen.new_run_id()
    with run_scope(new_run_id):
        yield
