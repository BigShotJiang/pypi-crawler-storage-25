"""The two ContextVars Herald uses to thread run identity across calls.

WHY only two ContextVars:

  - _RUN_ID — the current agent run's identifier. Set when @herald.agent
    opens; read by every tool / span / record / audit inside the run.

  - _SPAN_STACK — a tuple of active span IDs, in entry order. The last
    element is the immediate parent of any span opened next.

WHY ContextVar and not threading.local: ContextVar correctly propagates
across asyncio tasks (each task gets its own independent context branch)
while threading.local does not. Agents commonly fan out via
asyncio.gather, and the run_id MUST stay attached to each branch.

WHY a tuple for _SPAN_STACK and not a list: ContextVar values are
inherited by reference. If the parent context's stack were a mutable
list, a child task that did `stack.append(span_id)` would silently
mutate the parent. Tuples force every push/pop to produce a new tuple,
giving each context branch its own immutable view.

WHY this file owns the declarations: every other module imports the
ContextVars from here. Spreading declarations across files is the
classic source of "why isn't run_id propagating?" bugs — two modules
end up with two different ContextVar instances under the same name.
"""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
from contextvars import ContextVar

# WHY default=None for run_id: outside any @herald.agent boundary the
# run_id is genuinely absent. Code that reads it must handle None
# explicitly — e.g. a stray @herald.tool called without an enclosing
# agent gets a synthetic "orphan" run_id, not None silently propagated.
_RUN_ID: ContextVar[str | None] = ContextVar("herald.run_id", default=None)

# WHY default=(): an empty tuple is a valid stack (no parent span). The
# decorators check len(stack) > 0 to find a parent.
_SPAN_STACK: ContextVar[tuple[bytes, ...]] = ContextVar(
    "herald.span_stack", default=()
)


def current_run_id() -> str | None:
    """Return the current run_id, or None if not inside an agent run."""
    return _RUN_ID.get()


def current_span_stack() -> tuple[bytes, ...]:
    """Return the current span stack (innermost-last)."""
    return _SPAN_STACK.get()


def current_parent_span_id() -> bytes | None:
    """Return the immediate parent span id, or None at the root."""
    stack = _SPAN_STACK.get()
    return stack[-1] if stack else None


@contextmanager
def run_scope(run_id: str) -> Iterator[None]:
    """Set _RUN_ID for the duration of the with block. Restores the
    previous value on exit, even if the block raises.

    WHY a contextmanager and not bare ContextVar.set + reset: the
    contextmanager pattern guarantees reset on exception, which the
    decorator paths rely on for correctness under errors.
    """
    token = _RUN_ID.set(run_id)
    try:
        yield
    finally:
        _RUN_ID.reset(token)


@contextmanager
def span_scope(span_id: bytes) -> Iterator[None]:
    """Push `span_id` onto the span stack for the duration of the with
    block. Pops on exit, even if the block raises."""
    stack = _SPAN_STACK.get()
    new_stack = (*stack, span_id)
    token = _SPAN_STACK.set(new_stack)
    try:
        yield
    finally:
        _SPAN_STACK.reset(token)
