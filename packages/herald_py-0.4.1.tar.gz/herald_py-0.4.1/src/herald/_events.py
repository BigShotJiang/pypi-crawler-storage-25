"""Public event APIs: record() and audit().

Both are sync-callable so customer code can call them from any
context — sync function, async function, library code that does not
know whether it is in an event loop. Inside the runtime, both end up
emitting through the same _HeraldRuntime.emit() path with different
chain_kind tags.

WHY record() and audit() are separate functions instead of a single
emit(level=...): the audit channel has a fundamentally different
contract — durable on disk before return, tamper-evident chain. The
two-name API makes the contract visible in customer code: a reader
sees `herald.audit(...)` and knows that line is the audit promise.
"""

from __future__ import annotations

from typing import Any

from ._context import current_parent_span_id
from ._runtime import active_runtime


def record(
    *,
    event: str,
    level: str = "info",
    **attributes: Any,
) -> None:
    """Emit an arbitrary structured telemetry event.

    The captured event has kind="record", chain_kind="telemetry", and
    severity derived from `level`. Subject to sampling per
    HeraldSettings.sample_rate.

    WHY level is a string and not an enum: the public API stays
    string-typed for ergonomics. The runtime maps it to the Severity
    Literal on the HeraldEvent. Invalid values are caught by Pydantic
    validation when the event is built.
    """
    severity = level.upper()
    rt = active_runtime()
    # WHY read the contextvar here and pass it explicitly: the runtime
    # emit() does not consult the contextvar for parent_span_id (see
    # _runtime.py for the reasoning). The caller is the one who knows
    # whether it pushed a span before emit, so the caller is the one
    # who reads the contextvar at the right moment.
    rt.emit(
        kind="record",
        name=event,
        attributes=dict(attributes),
        severity=severity,
        chain_kind="telemetry",
        parent_span_id=current_parent_span_id(),
    )


def audit(
    *,
    event: str,
    **attributes: Any,
) -> None:
    """Emit an audit-channel event with synchronous durability and
    chain-of-custody.

    Bypasses sampling. The runtime writes with sync_mode="FULL" so
    the on-disk fsync completes before this call returns. The chain
    writer extends the per-run audit chain.

    Customer-visible contract: this call is blocking; expect 1-10 ms
    typical, up to ~100 ms under disk contention. The latency cost is
    deliberate — it is what the durability guarantee buys.
    """
    rt = active_runtime()
    rt.emit(
        kind="audit",
        name=event,
        attributes=dict(attributes),
        severity="AUDIT",
        chain_kind="audit",
        parent_span_id=current_parent_span_id(),
    )


def hash_inputs(*values: Any) -> str:
    """Compute a stable SHA-256 over canonical JSON of the given values.

    WHY this exists: customers writing custom enrichers sometimes want
    a deterministic content-hash of their tool inputs so two runs with
    the same input look like the same case. We expose the same
    canonical-JSON + SHA-256 the chain writer uses.

    Phase 1 returns an empty string until M4 wires the canonical-JSON
    helper. Tests that check this return path should expect "" for now.
    """
    # WHY this stays a stub through M2: the canonical JSON helper
    # lives in _crypto/canonical.py which lands in M4. Adding this
    # function now means the public surface stays stable from v0.1
    # forward; the implementation fills in at M4.
    _ = values
    return ""
