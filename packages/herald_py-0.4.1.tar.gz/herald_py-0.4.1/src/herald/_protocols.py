"""The seven seams Herald.Py composes around.

Every internal component the runtime owns is described by a Protocol in this
file. Tests swap implementations without monkey-patching production code; the
runtime composition root in _runtime.py wires concrete instances together at
configure() time.

WHY one file for all protocols: the protocols ARE the architecture. Reading
this file teaches a new contributor the entire shape of the SDK in under
five minutes. Splitting them across files would scatter the contract.

WHY PEP 544 Protocol and not abc.ABC: Protocols are structural typing, so a
class does not have to inherit from the protocol to satisfy it. That keeps
test fixtures (FrozenClock, MemoryBuffer) free of inheritance plumbing while
mypy still proves the substitution is valid.

These protocols are not part of the public surface. They live in `_protocols`
on purpose — customers compose against the public surface in `herald/`,
plugin authors compose against the named helpers in `herald/_helpers/`, and
only the runtime itself touches the protocols directly.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

# WHY runtime_checkable on every Protocol below: it allows isinstance(x, IFoo)
# checks at runtime. Mostly useful in tests and in the runtime composition
# root, which inspects components for optional capabilities (e.g. does this
# sink also implement IBatchedSink?). Cost is small; benefit is real.

# ---------------------------------------------------------------------------
# Time and identity — the deterministic seams
# ---------------------------------------------------------------------------


@runtime_checkable
class IClock(Protocol):
    """Source of "now" for every event factory.

    WHY a protocol and not time.time(): tests freeze time so per-event
    timing is deterministic. Production injects SystemClock; tests inject
    FrozenClock from herald.testing. Without this seam every test that
    checked an emitted timestamp would have to monkey-patch the time
    module, which is fragile across pytest runs.
    """

    def now_ns(self) -> int:
        """Return the current time as nanoseconds since the Unix epoch."""
        ...


@runtime_checkable
class IIdGenerator(Protocol):
    """Source of run, span, and trace identifiers.

    WHY one protocol for all three: tests want a single seam to swap when
    they need deterministic IDs. Splitting into IRunIdGen, ISpanIdGen,
    etc. would force tests to inject three fakes when one fixture would do.

    WHY the byte sizes here: 16 bytes for trace_id and 8 bytes for span_id
    match OpenTelemetry's W3C Trace Context spec. Herald wires through the
    same shapes so OTel-aware backends ingest events without translation.
    """

    def new_run_id(self) -> str:
        """A short, sortable string identifying one agent run."""
        ...

    def new_span_id(self) -> bytes:
        """Eight random bytes, OTel-compatible."""
        ...

    def new_trace_id(self) -> bytes:
        """Sixteen random bytes, OTel-compatible."""
        ...


# ---------------------------------------------------------------------------
# Event flow — capture, redact, sign, durably hold, ship
# ---------------------------------------------------------------------------


@runtime_checkable
class IRedactor(Protocol):
    """Applies the three client-side redaction mechanisms to an event.

    Implementations honor:

      1. Pydantic redact() markers on declared fields.
      2. Field-name rules from HeraldSettings.redact.
      3. The universal safety pass over free-text values.

    See SDKPrinciples.md §9 for the full contract — what each layer
    catches and why.
    """

    def redact(self, event: Any) -> Any:
        """Return a redacted copy of the event. Never mutates the input."""
        ...


@runtime_checkable
class IChainWriter(Protocol):
    """Extends the per-run audit chain by one entry.

    WHY a separate seam from IBuffer: telemetry events skip the chain
    entirely (NullChainWriter); audit events compute a MAC chained against
    the previous audit row for the same run_id (HmacChainWriter). The two
    paths share buffer plumbing but have different chain semantics.

    The contract — captured in SDKPrinciples §1: audit() returns only
    after the chain entry is written and the buffer write is durable on
    this host.
    """

    def write_audit_chain(self, event: Any, run_id: str) -> Any:
        """Compute payload_hash + MAC; return the new AuditChainEntry."""
        ...


@runtime_checkable
class IBuffer(Protocol):
    """Local-first durable storage for events between capture and drain.

    The production implementation (SqliteBuffer) uses WAL mode with
    per-statement synchronous=NORMAL for telemetry and synchronous=FULL
    for audit. The test stand-in (MemoryBuffer) is a deque, so unit tests
    do not pay the disk cost.

    WHY async on write/drain/mark_sent: capture happens on whatever loop
    the customer's code is running on; the drain coordinator runs as its
    own asyncio task. Both call into IBuffer concurrently. Sync APIs
    would force one to block the other.
    """

    async def write(self, event: Any, sync_mode: str = "NORMAL") -> None:
        """Persist one event. sync_mode is "NORMAL" or "FULL" (audit-only)."""
        ...

    async def drain_unsent(self, batch_size: int) -> list[Any]:
        """Read up to batch_size un-shipped events ordered by seq."""
        ...

    async def mark_sent(self, seq_range: range) -> None:
        """Record that a batch of events shipped successfully. Called by
        the drain coordinator after the exporter acks."""
        ...


@runtime_checkable
class IExporter(Protocol):
    """Ships a batch of events off-process — usually OTLP/gRPC.

    WHY a list and not a stream: the drain coordinator collects a batch
    from the buffer, hands it to the exporter once, and waits for the
    ack. Streaming would couple buffer iteration to network latency.

    WHY ExportResult and not a bool: failure modes have different
    recovery semantics — retry vs. drop vs. circuit-break — and the
    drain decorator stack needs the distinction.
    """

    async def export_batch(self, events: list[Any]) -> Any:
        """Ship the batch. Return an ExportResult describing success or
        the failure mode."""
        ...


# ---------------------------------------------------------------------------
# Operability — the seam for "the SDK is observable about itself"
# ---------------------------------------------------------------------------


@runtime_checkable
class IFailureSink(Protocol):
    """Where every internal exception lands.

    WHY a separate seam: customers want Herald failures to flow into
    their existing error tracker (Sentry, Datadog) without touching SDK
    code. The default implementation is StderrFailureSink with
    rate-limiting; production deployments swap in a richer one via
    configure().
    """

    def report(self, error: BaseException, context: dict[str, Any]) -> None:
        """Record one internal failure. Must not raise — this is the
        floor under everything else."""
        ...
