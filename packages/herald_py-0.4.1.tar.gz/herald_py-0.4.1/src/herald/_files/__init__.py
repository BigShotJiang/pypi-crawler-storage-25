"""File-based local durability — Python port of the rolling-files contract.

The contract this package implements is defined in the rolling-files
specification on the .NET side, currently at
`Modules/Core/docs/rolling-files.md` in the Herald repo (the
implementing class is moving to its own standalone project; the spec
location may follow it). The on-disk format is the **cross-language
contract**: Python writes events to NDJSON files in a deterministic
shape, and the .NET FileManager reads / writes the same files
identically.

The byte-level contract this package produces is documented in
`docs/on-disk-format.md` in the Herald.Py repo, version-stamped so
breaking changes are visible.

WHY one façade: every customer-facing concern (rolling, retention,
atomic writes, crash recovery, compression hooks) goes through the
single `FileManager` class. Sinks, buffers, and any other consumer
sees one named thing.

WHY mirroring the .NET spec instead of inventing a Python-native
shape: the on-disk artifact must be readable by browser dashboards
and desktop tools regardless of which language wrote it. One contract,
two implementations, the same files on disk.

Phase 1 of M3 (this milestone) ships:
  - Façade + policy record + hooks
  - Token substitution
  - Time + size rolling
  - Retention (count + total size + age)
  - Atomic close-and-rename on roll
  - Startup scanner for crash recovery

Deferred to later passes:
  - Compression (gzip/brotli) on roll
  - Disk-full strategy (Drop / Fallback)
  - Shared-write (multi-process advisory lock)
  - Message-count rolling
"""

from __future__ import annotations

from .hooks import FileManagerHooks
from .manager import FileManager, RolledFileInfo
from .policy import FileManagerPolicy, RollingInterval

# WHY a programmatic version constant: the docs describe the byte
# format; the constant lets readers (browser dashboards, desktop
# tools, the .NET FileManager) check at runtime which format the
# writer was speaking. v1 is the initial locked version per
# docs/on-disk-format.md. Bumping this constant is the visible
# signal that the format has changed in a non-additive way.
ON_DISK_FORMAT_VERSION = "v1"
"""The byte-level format version this package writes. See
`docs/on-disk-format.md` for the full contract."""


__all__ = [
    "ON_DISK_FORMAT_VERSION",
    "FileManager",
    "FileManagerHooks",
    "FileManagerPolicy",
    "RolledFileInfo",
    "RollingInterval",
]
