"""FileManager — the single public façade consumers see.

Mirrors the FileManager façade from the rolling-files spec
(MMPWorks.RollingFiles on the .NET side). Sinks, the SDK buffer,
and any other byte-producing consumer constructs one of these and
calls into it for every file action. Single class on the outside;
helpers in `_files/_*.py` underneath.

Public surface (matches the .NET plan one-for-one):

  active_path           — current file the writer is appending to
  active_bytes          — bytes written since the active file opened
  active_period_start   — UTC timestamp the current period began
  append_line(line)     — convenience: append text + newline
  append_bytes(b)       — primary: append raw bytes
  flush()               — user-driven fsync
  roll_now(reason=None) — force a roll
  list_rolled()         — list of RolledFileInfo for sealed files
  close()               — close the active file, run final hooks

Threading: a single threading.Lock around the active stream. The lock
covers append + roll-decision + write so a roll cannot race with an
append. Pruning runs at most once per roll and the actual delete calls
happen outside the lock (filesystem latency is unbounded).

What this class does NOT own (per the plan):
  - Rendering — sinks render their event to text or bytes, not us.
  - Format-specific framing — ndjson newlines, protobuf length
    prefixes, CSV headers all live in the consumer.
  - Filtering — separate concern, runs upstream.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from . import _path as path_helper
from . import _period as period_helper
from . import _pruner as pruner_helper
from . import _scanner as scanner
from ._active import ActiveFileStream
from .hooks import DiskFullEvent, FileManagerHooks
from .policy import FileManagerPolicy


@dataclass(frozen=True)
class RolledFileInfo:
    """Metadata for one sealed (rolled) file. What `list_rolled()` returns.

    Field names mirror the planned C# `RolledFileInfo` record.
    """

    path: str
    """Absolute path to the rolled file on disk."""

    period_start: datetime
    """UTC timestamp of the period the file covers."""

    size_bytes: int
    """Size of the file in bytes."""


class FileManager:
    """Rolling-file manager: byte-in, bytes-on-disk.

    Construct once per writable destination. Reuse across the
    lifetime of the process. Call close() during shutdown so the
    active file gets sealed cleanly.
    """

    def __init__(
        self,
        policy: FileManagerPolicy,
        hooks: FileManagerHooks | None = None,
    ) -> None:
        self._policy = policy
        self._hooks = hooks or FileManagerHooks()

        # WHY a Lock and not RLock: every public method enters the
        # lock once. If a hook re-enters a public method we want to
        # see the deadlock immediately rather than mask a re-entrancy
        # bug with RLock's silent permissiveness.
        self._lock = threading.Lock()

        # Pre-expand static tokens once. Per-roll work is just {date}
        # and {seq} substitution.
        self._directory = path_helper.expand_static_tokens(
            policy.directory, policy.path_tokens
        )
        self._template = path_helper.expand_static_tokens(
            policy.file_name_template, policy.path_tokens
        )
        self._directory_path = Path(self._directory)
        self._directory_path.mkdir(parents=True, exist_ok=True)

        # Period + sequence state for the currently-active file.
        # Both update on every roll.
        self._period_start: datetime = self._compute_period_start(self._now())
        self._sequence: int = 1

        # Crash recovery: seal any leftover active file from a
        # previous process before opening our own.
        if policy.clean_roll_on_startup:
            self._seal_leftover_partial()

        self._active = self._open_active()
        if self._hooks.on_open_active is not None:
            self._hooks.on_open_active(str(self._active.path))

        # WHY a counter for messages: max_messages_per_file is in the
        # policy shape (C# Phase 9). M3 does not enforce it, but the
        # counter exists so flipping the enforcement on later requires
        # zero changes to append paths.
        self._messages_in_active: int = 0

        self._closed = False

    # ---- Public properties ---------------------------------------------

    @property
    def active_path(self) -> str:
        """Absolute path to the current active file."""
        return str(self._active.path)

    @property
    def active_bytes(self) -> int:
        """Bytes written to the current active file since it opened."""
        return self._active.bytes_written

    @property
    def active_period_start(self) -> datetime:
        """UTC start of the current rolling period."""
        return self._period_start

    # ---- Public append API ---------------------------------------------

    def append_line(self, line: str) -> None:
        """Convenience: append `line` plus a single \\n.

        WHY a separate method from append_bytes: NDJSON is the
        primary consumer of this class. Adding the newline here
        eliminates one easy-to-forget framing bug at every call site.
        """
        # Ensure exactly one trailing newline regardless of what the
        # caller passes.
        data = (
            line.encode("utf-8")
            if line.endswith("\n")
            else (line + "\n").encode("utf-8")
        )
        self.append_bytes(data)

    def append_bytes(self, data: bytes) -> None:
        """Append raw bytes to the active file. Roll first if needed."""
        with self._lock:
            self._roll_if_needed_locked()
            try:
                self._active.append(data)
                self._messages_in_active += 1
            except OSError as exc:
                # M3 ships only DiskFullStrategy=Stop. The hook fires
                # for observability; the exception still raises so the
                # caller decides what to do.
                if self._hooks.on_disk_full is not None:
                    self._hooks.on_disk_full(
                        DiskFullEvent(
                            path=str(self._active.path),
                            bytes_attempted=len(data),
                            error=exc,
                        )
                    )
                raise

    # ---- Public lifecycle ----------------------------------------------

    def flush(self) -> None:
        """Force everything written so far to disk (fsync)."""
        with self._lock:
            self._active.fsync()

    def roll_now(self, reason: str | None = None) -> None:
        """Force a roll regardless of size or time triggers.

        `reason` is observability-only; it gets logged but does not
        affect the rolled-file naming.
        """
        with self._lock:
            self._roll_locked(reason or "manual")

    def list_rolled(self) -> list[RolledFileInfo]:
        """Return metadata for every sealed (rolled) file in the directory.

        Excludes the active file. Returned in newest-first order.
        """
        # WHY don't take the lock: this is read-only and reflects
        # filesystem state which is shared with other processes
        # anyway. A consistent snapshot would require locking the
        # filesystem, which we cannot.
        candidates = pruner_helper.list_rolled_candidates(
            self._directory_path,
            extension=self._policy.extension,
            exclude=[self._active.path],
        )
        # Sort newest-first.
        candidates.sort(key=lambda c: c.mtime, reverse=True)
        return [
            RolledFileInfo(
                path=str(c.path),
                period_start=c.mtime,  # mtime ≈ seal time; close enough for listings
                size_bytes=c.size_bytes,
            )
            for c in candidates
        ]

    def close(self) -> None:
        """Close the active file. Idempotent."""
        with self._lock:
            if self._closed:
                return
            self._active.close()
            self._closed = True

    def __enter__(self) -> FileManager:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    # ---- Internal helpers (everything below requires the lock) ---------

    def _now(self) -> datetime:
        """Single source of "what time is it now?" Override in tests."""
        return datetime.now(tz=timezone.utc)

    def _compute_period_start(self, now: datetime) -> datetime:
        return period_helper.get_period_start(
            now,
            self._policy.interval,
            start_minute=self._policy.start_minute,
            capture_duration_minutes=self._policy.capture_duration_minutes,
        )

    def _build_path(self, period_start: datetime, sequence: int) -> Path:
        """Build the full path for a given period + sequence."""
        return path_helper.build_full_path(
            self._policy,
            period_start=period_start,
            sequence=sequence,
            expanded_directory=self._directory,
            expanded_template=self._template,
        )

    def _open_active(self) -> ActiveFileStream:
        """Open the active file at the current period and sequence."""
        # WHY check existing files first: a process that restarts
        # mid-period must either resume the existing active file or
        # bump the sequence. Today we always start fresh — we sealed
        # any partial in __init__'s startup scanner, so the path we're
        # opening here should not exist.
        path = self._build_path(self._period_start, self._sequence)
        return ActiveFileStream(path)

    def _seal_leftover_partial(self) -> None:
        """If a previous process crashed mid-write, seal its file."""
        expected_active = self._build_path(self._period_start, self._sequence)
        partial = scanner.find_partial_active_file(
            self._directory_path,
            extension=self._policy.extension,
            expected_active_path=expected_active,
        )
        if partial is None:
            return

        # Find the next available sequence to give the sealed file a
        # unique name.
        seal_sequence = self._next_available_sequence(self._period_start)

        def _build_sealed_target() -> Path:
            return self._build_path(self._period_start, seal_sequence)

        sealed_path = scanner.seal_partial_active(
            partial,
            sealed_target_builder=_build_sealed_target,
        )
        scanner.stamp_partial_with_seal_marker(sealed_path, self._now())
        # We just consumed seq N for the partial; bump our own pointer
        # so when we open our own file we use the next free seq.
        self._sequence = seal_sequence + 1

    def _next_available_sequence(self, period_start: datetime) -> int:
        """Find the smallest sequence number not yet on disk for this period."""
        # Linear probe — sequences within a period are small (rolls
        # happen on size or time). Walking from 1 upward is fine.
        for candidate in range(1, 10_000):
            if not self._build_path(period_start, candidate).exists():
                return candidate
        # Defensive: 10k rolls in one period is pathological; raise
        # rather than overwrite.
        raise RuntimeError(
            f"FileManager: no available sequence in period {period_start} "
            f"under directory {self._directory}"
        )

    def _roll_if_needed_locked(self) -> None:
        """Decide whether to roll based on size or period change.

        Caller must hold the lock.
        """
        now = self._now()
        new_period = self._compute_period_start(now)

        # Period change wins over size — a daily roll at midnight
        # should fire whether or not the file is at the size cap.
        if new_period != self._period_start:
            self._roll_locked("period")
            return

        if (
            self._policy.max_bytes_per_file is not None
            and self._active.bytes_written >= self._policy.max_bytes_per_file
        ):
            self._roll_locked("size")
            return

        # max_messages_per_file is on the policy but not enforced yet
        # (Phase 9). Counter is maintained so future enforcement is a
        # one-line change.

    def _roll_locked(self, reason: str) -> None:
        """Atomically seal the active file and open a new one.

        Caller must hold the lock.
        """
        if self._hooks.on_pre_roll is not None:
            self._hooks.on_pre_roll(str(self._active.path))

        # The active file is already at its final path (no temp+rename
        # is needed since the path itself is the target — date and
        # sequence are baked into the filename). Just close it durably.
        self._active.fsync()
        sealed_path = self._active.path
        self._active.close()

        if self._hooks.on_post_roll is not None:
            self._hooks.on_post_roll(str(sealed_path))

        # Decide the next active file's period + sequence.
        now = self._now()
        new_period = self._compute_period_start(now)
        if new_period != self._period_start:
            # Period rolled forward; reset sequence.
            self._period_start = new_period
            self._sequence = 1
        else:
            # Same period (size-driven roll); next sequence.
            self._sequence += 1

        self._active = self._open_active()
        self._messages_in_active = 0

        if self._hooks.on_open_active is not None:
            self._hooks.on_open_active(str(self._active.path))

        # Run retention pruning after every roll. WHY here and not
        # in a separate thread: rolls happen rarely; pruning under
        # the lock for a fraction of a second is acceptable. The
        # actual delete calls happen inside `prune` which runs
        # them sequentially.
        self._prune_after_roll()

        # `reason` is observability-only — passed in case a future
        # logger or self-telemetry hook wants it.
        del reason

    def _prune_after_roll(self) -> None:
        """Run one prune pass. Caller holds the lock."""
        pruner_helper.prune(
            self._directory_path,
            extension=self._policy.extension,
            exclude=[self._active.path],
            max_retained_files=self._policy.max_retained_files,
            total_size_cap_bytes=self._policy.total_size_cap_bytes,
            retention_days=self._policy.retention_days,
            now=self._now(),
            on_prune=self._hooks.on_prune,
        )
