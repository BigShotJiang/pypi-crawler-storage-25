"""FileManagerHooks — optional callbacks operators wire into the file lifecycle.

Mirrors the hooks record from the rolling-files spec
(MMPWorks.RollingFiles on the .NET side). Every hook is
optional; the FileManager runs cleanly without any of them.

WHY hooks are dataclass slots and not Pydantic: hooks hold callable
objects, not data. Pydantic happily accepts callables but tries to
serialise them, which is wrong here. A dataclass with a few
optional Callable fields is the right shape.

The hook contracts:

  - on_open_active(path)       — fires after the active file opens.
                                  Use to write a header line.
  - on_pre_roll(path)          — fires before a roll. The given path
                                  is the active file about to seal.
  - on_post_roll(path)         — fires after the rolled file is sealed
                                  on disk. Compression and integrity
                                  sealing both hang here in later
                                  milestones.
  - on_prune(path) -> bool     — fires before a prune. Return True to
                                  allow the delete; False to keep the
                                  file (used by the Durable Buffer
                                  pattern from the .NET plan).
  - on_disk_full(reason)       — fires on a disk-full event.

WHY hooks are sync, not async: every hook runs around a small file
operation, with its own lock held. Async hooks would let arbitrary
customer code yield while the lock is held, defeating the lock's
purpose. Compression hangs off `on_post_roll` and runs on a
background thread the worker manages, not on the hook itself.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass


@dataclass
class DiskFullEvent:
    """Information passed to on_disk_full when the filesystem refuses a write."""

    path: str
    """The file path the SDK was trying to write to."""

    bytes_attempted: int
    """How many bytes the failed append tried to write."""

    error: BaseException | None = None
    """The OSError or other exception that surfaced the disk-full
    condition."""


@dataclass
class FileManagerHooks:
    """Optional callbacks for the FileManager lifecycle. All None by default."""

    on_open_active: Callable[[str], None] | None = None
    """Fires after the active file opens. Receives the absolute path."""

    on_pre_roll: Callable[[str], None] | None = None
    """Fires just before a roll. Receives the active file path that
    is about to seal."""

    on_post_roll: Callable[[str], None] | None = None
    """Fires after the rolled file is sealed on disk. Receives the
    rolled-file path. Compression and integrity sealing hang here in
    later milestones."""

    on_prune: Callable[[str], bool] | None = None
    """Fires before a prune deletes a rolled file. Receives the
    candidate path. Return True to delete; False to keep. None means
    delete (the default policy)."""

    on_disk_full: Callable[[DiskFullEvent], None] | None = None
    """Fires on a disk-full event. Receives a DiskFullEvent describing
    the attempted write."""
