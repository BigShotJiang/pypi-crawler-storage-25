"""Retention pruning — count + total-size + age, "tightest wins."

Mirrors `RollingFilePruner.cs` from the .NET side. Three independent
caps; whichever bites first removes the oldest rolled files.

WHY three caps and not one master cap: operators have different
constraints and want them enforced together.
  - max_retained_files: "I never want more than 30 files in this dir."
  - total_size_cap_bytes: "I have 5 GB of audit space; never blow past it."
  - retention_days: "Compliance says nothing older than 14 days."

Any of the three can fire independently. The pruner enumerates rolled
files, sorts by mtime, and walks the list until every cap is satisfied.

WHY the pruner does NOT delete the active file: the FileManager owns
the active file handle. Pruning the active path under it would
corrupt subsequent writes. The pruner only sees files that have been
sealed (rolled).
"""

from __future__ import annotations

import logging
import os
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class _CandidateFile:
    """One rolled file the pruner is considering. Internal record."""

    path: Path
    size_bytes: int
    mtime: datetime


def list_rolled_candidates(
    directory: Path,
    *,
    extension: str,
    exclude: Iterable[Path] = (),
) -> list[_CandidateFile]:
    """Enumerate rolled files under `directory` matching `extension`.

    Files in `exclude` (typically the active file) are skipped.

    WHY a directory listing per call and not a watched cache: rolls
    happen at the speed of human perception — minutes to days apart.
    The directory listing cost is irrelevant; a watched cache adds
    state that can drift on filesystem-level moves.
    """
    if not directory.exists():
        return []

    excluded = {p.resolve() for p in exclude}
    candidates: list[_CandidateFile] = []

    for entry in directory.iterdir():
        if not entry.is_file():
            continue
        if entry.suffix != extension and not entry.name.endswith(extension):
            # WHY both checks: extension might be ".ndjson" but a
            # compressed file would be ".ndjson.gz" — we want to
            # match either form.
            continue
        if entry.resolve() in excluded:
            continue
        try:
            stat = entry.stat()
        except OSError:
            # Race with another process or permission issue. Skip the
            # file rather than crashing pruning.
            continue
        candidates.append(
            _CandidateFile(
                path=entry,
                size_bytes=stat.st_size,
                mtime=datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc),
            )
        )

    return candidates


def select_for_pruning(
    candidates: list[_CandidateFile],
    *,
    max_retained_files: int | None,
    total_size_cap_bytes: int | None,
    retention_days: int | None,
    now: datetime,
) -> list[_CandidateFile]:
    """Decide which candidates to delete given the three caps.

    Returns the subset of `candidates` that should be removed. The
    surviving subset honours every cap that is not None.

    WHY oldest-first deletion: there is no "delete from the middle"
    sensible policy for log-shaped data. Older = more deletable.
    """
    # Sort newest-first so we keep the freshest files and drop the
    # oldest first. Ties on mtime (rare) are broken by name to keep
    # the order deterministic across runs and platforms.
    sorted_newest_first = sorted(
        candidates, key=lambda c: (c.mtime, c.path.name), reverse=True
    )

    keep: list[_CandidateFile] = []
    drop: list[_CandidateFile] = []
    running_total = 0
    cutoff = (
        now - timedelta(days=retention_days) if retention_days is not None else None
    )

    for cand in sorted_newest_first:
        # Cap 1: too old?
        if cutoff is not None and cand.mtime < cutoff:
            drop.append(cand)
            continue

        # Cap 2: count cap reached?
        if max_retained_files is not None and len(keep) >= max_retained_files:
            drop.append(cand)
            continue

        # Cap 3: total size cap reached?
        if (
            total_size_cap_bytes is not None
            and running_total + cand.size_bytes > total_size_cap_bytes
        ):
            drop.append(cand)
            continue

        keep.append(cand)
        running_total += cand.size_bytes

    return drop


def prune(
    directory: Path,
    *,
    extension: str,
    exclude: Iterable[Path],
    max_retained_files: int | None,
    total_size_cap_bytes: int | None,
    retention_days: int | None,
    now: datetime,
    on_prune: Callable[[str], bool] | None = None,
) -> list[Path]:
    """Run one prune pass. Returns the list of paths actually deleted.

    The on_prune hook (if given) is asked for each candidate; it can
    veto deletion by returning False (the Durable Buffer pattern).

    Errors during a single delete are logged but do not stop the
    pruner — partial pruning is better than an exception that abandons
    the whole pass.
    """
    candidates = list_rolled_candidates(
        directory, extension=extension, exclude=exclude
    )
    if not candidates:
        return []

    selected = select_for_pruning(
        candidates,
        max_retained_files=max_retained_files,
        total_size_cap_bytes=total_size_cap_bytes,
        retention_days=retention_days,
        now=now,
    )

    deleted: list[Path] = []
    for cand in selected:
        if on_prune is not None and not on_prune(str(cand.path)):
            # The hook said to keep this file. Skip it.
            continue
        try:
            os.unlink(cand.path)
            deleted.append(cand.path)
        except OSError as exc:
            # WHY warn-and-continue: a partial prune is better than
            # zero pruning. The next prune pass will retry.
            logger.warning("herald: prune failed for %s: %s", cand.path, exc)

    return deleted
