"""Token expansion + filename construction.

Mirrors `RollingFilePathBuilder.cs` plus the future `PathTemplate`
helper from the .NET plan. Token rules are the same on both sides so
filenames written by Python and .NET are byte-identical given the
same policy + period + sequence.

Token table (expanded once at FileManager construction except where
noted):

  {date}      — period-aware date string. Re-expanded per period.
                Format: Hourly  = yyyy-MM-dd_HH
                        Daily   = yyyy-MM-dd
                        Custom  = yyyy-MM-dd_HH-mm
                        None    = empty string
  {seq}       — rotation sequence as decimal. Re-expanded per roll.
  {hostname}  — from policy.path_tokens or os.uname().nodename
  {service}   — from policy.path_tokens; required when used
  {tenant}    — from policy.path_tokens; required when used
  {pid}       — current process ID

Anything else in {curly_braces} is left untouched so the template
shape never breaks unknown extensions.
"""

from __future__ import annotations

import os
import re
import socket
from datetime import datetime
from pathlib import Path

from .policy import FileManagerPolicy, RollingInterval

# WHY a compiled regex at module level: the template scanner runs on
# every roll. Pre-compiling keeps the cost negligible.
_TOKEN_RE = re.compile(r"\{(?P<name>[a-zA-Z_][a-zA-Z0-9_]*)\}")


def expand_static_tokens(template: str, tokens: dict[str, str]) -> str:
    """Replace static tokens ({hostname}, {pid}, custom path_tokens).

    Leaves dynamic tokens ({date}, {seq}) alone — those are filled in
    per roll by `build_filename` below.

    WHY two-pass expansion: the directory and the file_name_template
    each have static tokens (hostname, service) that resolve once, and
    dynamic tokens (date, seq) that resolve per roll. Doing both in
    one pass would re-resolve hostname per roll, which is wasted work
    and a possible source of mid-run drift if the hostname changes.
    """
    # Default values that always resolve regardless of policy.
    defaults: dict[str, str] = {
        "hostname": socket.gethostname(),
        "pid": str(os.getpid()),
    }
    # Customer-supplied tokens win over defaults.
    merged: dict[str, str] = {**defaults, **tokens}

    def _replace(match: re.Match[str]) -> str:
        name = match.group("name")
        # Leave {date} and {seq} alone — they resolve per-roll.
        if name in ("date", "seq"):
            return match.group(0)
        # Unknown tokens are left as-is. Operators see them in the
        # filename and recognise the bug rather than getting a silent
        # empty-string substitution.
        return merged.get(name, match.group(0))

    return _TOKEN_RE.sub(_replace, template)


def format_period_date(
    period_start: datetime,
    interval: RollingInterval,
    *,
    file_name_suffix: str | None = None,
) -> str:
    """Return the {date} substitution for the given period.

    Matches the .NET RollingFilePathBuilder format strings exactly:
      Hourly: yyyy-MM-dd_HH
      Daily:  yyyy-MM-dd
      Custom: yyyy-MM-dd_HH-mm
      None:   empty string

    A custom file_name_suffix (strftime format) overrides the default.
    """
    if file_name_suffix:
        # WHY strftime translation: file_name_suffix is documented as
        # "strftime-style." Operators write it once, both languages
        # honour it through their respective stdlib formatters.
        return period_start.strftime(file_name_suffix)

    if interval == "Hourly":
        return period_start.strftime("%Y-%m-%d_%H")
    if interval == "Daily":
        return period_start.strftime("%Y-%m-%d")
    if interval == "Custom":
        return period_start.strftime("%Y-%m-%d_%H-%M")
    # None — no date in the filename
    return ""


def build_filename(
    *,
    template_with_static_tokens_expanded: str,
    period_start: datetime,
    interval: RollingInterval,
    sequence: int,
    extension: str,
    file_name_suffix: str | None,
) -> str:
    """Build the leaf filename (no directory) for a given period and sequence.

    The template at this point has every static token already expanded
    by `expand_static_tokens`. {date} and {seq} are still pending.
    """
    date_str = format_period_date(
        period_start, interval, file_name_suffix=file_name_suffix
    )

    # WHY str(sequence) directly: matches the plan's example
    # `name-2026-05-05.1.log` where seq is always shown. Cleaner than
    # the existing C# `_seq` only-when-greater-than-1 convention; the
    # plan recommends the always-shown form for clarity.
    seq_str = str(sequence)

    name = template_with_static_tokens_expanded.replace("{date}", date_str)
    name = name.replace("{seq}", seq_str)

    return f"{name}{extension}"


def build_full_path(
    policy: FileManagerPolicy,
    *,
    period_start: datetime,
    sequence: int,
    expanded_directory: str,
    expanded_template: str,
) -> Path:
    """Compose the full Path: directory / filename."""
    leaf = build_filename(
        template_with_static_tokens_expanded=expanded_template,
        period_start=period_start,
        interval=policy.interval,
        sequence=sequence,
        extension=policy.extension,
        file_name_suffix=policy.file_name_suffix,
    )
    return Path(expanded_directory) / leaf
