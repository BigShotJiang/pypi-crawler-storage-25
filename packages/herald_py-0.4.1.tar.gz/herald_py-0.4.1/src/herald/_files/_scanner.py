"""StartupScanner — seal a partial active file from a previous crash.

Mirrors the planned `StartupScanner` from the rolling-files spec
(MMPWorks.RollingFiles on the .NET side). Runs once at FileManager
construction when policy.clean_roll_on_startup is True (the default).

WHY this is necessary: a process that crashed mid-write leaves an
active file on disk. The next process that opens the same directory
must NOT just append to that file — it would mix events from two
different process lifetimes, with potentially incompatible
canonical-JSON shapes if the SDK version changed. The right behaviour
is to seal the leftover file as a rolled file (with the next available
sequence) and start fresh.

WHY this happens at startup, not on every roll: rolls are predictable
events the FileManager owns. A leftover active file is an
out-of-band condition that only matters across process boundaries.
"""

from __future__ import annotations

import logging
import os
from collections.abc import Callable
from datetime import datetime
from pathlib import Path

logger = logging.getLogger(__name__)


def find_partial_active_file(
    directory: Path,
    *,
    extension: str,
    expected_active_path: Path,
) -> Path | None:
    """Look for a leftover active file from a previous crashed process.

    A "partial" active file is one that exists on disk under the path
    we are about to open. If the file exists and has bytes in it, we
    treat it as "needs sealing."

    Returns the partial path if one exists, or None if the directory
    is clean.
    """
    if not expected_active_path.exists():
        return None
    try:
        size = expected_active_path.stat().st_size
    except OSError:
        return None
    # A zero-byte active file is harmless; just open it normally.
    if size == 0:
        return None
    return expected_active_path


def seal_partial_active(
    partial: Path,
    *,
    sealed_target_builder: Callable[[], Path],
) -> Path:
    """Atomically rename a partial active file to a fresh sealed name.

    `sealed_target_builder` is a callable that produces the next
    available rolled-file Path, given the current sequence number it
    queries from disk. The FileManager passes its own sequence-finding
    helper here.

    WHY this is a callback: the path-construction logic lives in
    `_path.py` and depends on the policy. Passing a builder keeps the
    scanner narrowly focused on "find + rename + log."
    """
    target: Path = sealed_target_builder()
    target.parent.mkdir(parents=True, exist_ok=True)

    # The atomic rename. Same primitive as ActiveFileStream.seal_to.
    # Crash-safe: a crash between the call and the kernel completing
    # the rename leaves either the source or the target in place,
    # never both.
    os.replace(str(partial), str(target))
    logger.info(
        "herald: sealed leftover active file %s -> %s on startup",
        partial,
        target,
    )
    return target


def stamp_partial_with_seal_marker(path: Path, when: datetime) -> None:
    """Touch the sealed file's mtime so retention treats it as a fresh
    rolled file, not as an old artifact from whenever the original
    process started writing.

    WHY this matters: retention by age uses mtime. Without this, a
    file written across many days could fall outside the retention
    window the moment it is sealed, and the very next prune would
    delete it. Stamping mtime to the seal time gives operators a
    sensible "this rolled file is fresh as of recovery."
    """
    try:
        ts = when.timestamp()
        os.utime(path, (ts, ts))
    except OSError as exc:
        # Non-fatal — the rename succeeded; the mtime is cosmetic.
        logger.warning(
            "herald: could not set mtime on sealed file %s: %s", path, exc
        )
