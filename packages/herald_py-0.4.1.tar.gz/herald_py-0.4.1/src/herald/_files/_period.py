"""Pure period-start calculation for rolling intervals.

Mirrors `RollingFilePeriod.cs` on the .NET side line for line. Same
input + interval + custom-window math gives the same period-start
time. Cross-language consistency is exact: a Python writer and a .NET
writer pointed at the same clock produce files with matching
boundaries.

Stateless module. No I/O, no globals.
"""

from __future__ import annotations

from datetime import datetime, timezone

from .policy import RollingInterval


def get_period_start(
    now: datetime,
    interval: RollingInterval,
    *,
    start_minute: int = 0,
    capture_duration_minutes: int = 60,
) -> datetime:
    """Return the start of the current rolling period.

    For "None" interval, returns datetime.min — files never roll on
    time alone (size or count caps may still trigger).

    For Hourly / Daily, the period is the obvious clock-aligned hour
    or day in UTC.

    For Custom, windows of `capture_duration_minutes` start at
    `start_minute` past the hour and repeat. The returned period is
    the start of the window containing `now`.

    WHY UTC for Hourly/Daily: filenames embed the period date. UTC
    avoids the ambiguity of DST transitions (a "daily" period in
    local time has a 23-hour or 25-hour day twice a year) and keeps
    cross-region replicas in sync. Operators read UTC; they have
    tools for that.
    """
    # WHY datetime.min sentinel for "None": calling code can compare
    # the period-start across rolls; using a constant past-min value
    # means "never rolled by time" trivially fails any equality check.
    if interval == "None":
        return datetime.min.replace(tzinfo=timezone.utc)

    # Force UTC throughout — see WHY note above.
    now_utc = now.astimezone(timezone.utc) if now.tzinfo else now.replace(tzinfo=timezone.utc)

    if interval == "Hourly":
        return now_utc.replace(minute=0, second=0, microsecond=0)

    if interval == "Daily":
        return now_utc.replace(hour=0, minute=0, second=0, microsecond=0)

    # Custom window math, identical to the C# RollingFilePeriod.cs
    return _get_custom_period_start(now_utc, start_minute, capture_duration_minutes)


def _get_custom_period_start(
    now_utc: datetime, start_minute: int, capture_duration_minutes: int
) -> datetime:
    """Find the start of the custom window containing `now_utc`.

    Mirrors `GetCustomPeriodStart` in the C# helper. The math walks
    minutes-since-midnight forward from `start_minute`, picks the
    window index, and snaps back to the window's start minute.
    """
    if capture_duration_minutes <= 0:
        capture_duration_minutes = 60
    start_minute = max(0, min(59, start_minute))

    total_minutes = now_utc.hour * 60 + now_utc.minute
    minutes_since_start = total_minutes - start_minute
    if minutes_since_start < 0:
        # The day's first window starts before today's start_minute.
        # Wrap to the previous calendar day's last window equivalent.
        minutes_since_start += 24 * 60

    window_index = minutes_since_start // capture_duration_minutes
    window_start_total_minutes = (
        start_minute + (window_index * capture_duration_minutes)
    ) % (24 * 60)

    return now_utc.replace(
        hour=window_start_total_minutes // 60,
        minute=window_start_total_minutes % 60,
        second=0,
        microsecond=0,
    )
