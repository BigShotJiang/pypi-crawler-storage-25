"""FileManagerPolicy — every knob that shapes file behaviour, in one record.

Mirrors the policy record from the rolling-files spec
(MMPWorks.RollingFiles on the .NET side). Field names are the
Python-idiomatic snake_case form of the C# PascalCase originals. The
shape and semantics are identical so a JSON Schema generated from
either side validates the other.

WHY Pydantic and not a dataclass: validation at boundaries. Operators
will eventually hand-edit policy files (TOML or JSON); a dataclass
silently accepts unknown fields and out-of-range values. Pydantic's
`extra="forbid"` and the per-field constraints catch mistakes early.

WHY frozen=True: a policy is captured once at startup and used for
the lifetime of the FileManager. Mutating it later is the leading
source of "wait, why is the rolling cadence wrong?" bugs.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

# WHY a Literal: matches the C# RollingInterval enum exactly. JSON
# Schema export round-trips identical strings either side.
RollingInterval = Literal["None", "Hourly", "Daily", "Custom"]
"""When a new file starts. None = never roll on time; size/count caps
still trigger rolls."""

CompressionMode = Literal["None", "Gzip", "Brotli"]
"""Compression applied to rolled (sealed) files. None ships in M3;
Gzip and Brotli are accepted in the policy shape so future C# / Python
versions add them without a wire-format break."""

DiskFullStrategy = Literal["Stop", "Drop", "Fallback"]
"""What happens when the filesystem refuses a write. M3 ships only
`Stop` (raise on next append). Drop and Fallback land in a later
pass; the field exists so config files can carry them today."""


class FileManagerPolicy(BaseModel):
    """Every operator-facing knob for a rolling file destination.

    Construct one per writable destination — telemetry channel, audit
    channel, sample sink, etc. Each FileManager owns its own policy.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    # ---- Section 1: Where & What ---------------------------------------

    directory: str
    """Absolute directory where files land. Tokens like {hostname},
    {service}, {tenant}, {pid} are expanded once at FileManager
    construction; never re-expanded mid-run."""

    file_name_template: str = Field(default="events-{date}.{seq}")
    """Filename template before the extension. {date} expands to the
    period-aware date string (Hourly: yyyy-MM-dd_HH; Daily: yyyy-MM-dd;
    Custom: yyyy-MM-dd_HH-mm). {seq} expands to the rotation sequence
    starting at 1. Other tokens come from path_tokens."""

    extension: str = Field(default=".ndjson")
    """File extension including the dot. Compression suffix
    (e.g. .gz) is appended on top by the compression worker when
    enabled."""

    active_file_name: str | None = Field(default=None)
    """Optional fixed name for the active (currently-being-written)
    file. When set, the active file uses this name; on roll it is
    renamed to follow the template. Useful for tail-friendly
    operations. None means active file uses the same template."""

    path_tokens: dict[str, str] = Field(default_factory=dict)
    """Extra token replacements for the directory and template:
    {"service": "refund-agent", "hostname": "host-7"}."""

    # ---- Section 2: When to Roll ---------------------------------------

    interval: RollingInterval = Field(default="Daily")
    """Time-based roll trigger."""

    max_bytes_per_file: int | None = Field(default=None, gt=0)
    """Roll on size when the active file exceeds this many bytes.
    None disables the size trigger."""

    max_messages_per_file: int | None = Field(default=None, gt=0)
    """Roll on count when this many appends have happened to the
    active file. None disables the count trigger. Not enforced in M3
    (Phase 9); the field exists so policy files carry it now."""

    start_minute: int = Field(default=0, ge=0, le=59)
    """For Custom interval: minute past the hour where windows begin."""

    capture_duration_minutes: int = Field(default=60, gt=0)
    """For Custom interval: how long a window lasts."""

    file_name_suffix: str | None = Field(default=None)
    """Optional strftime-style format string overriding the default
    per-interval date format."""

    locale: str | None = Field(default=None)
    """Optional locale for date formatting. Ignored by Python (we use
    strftime which is locale-aware via the OS); kept on the policy so
    cross-language config round-trips."""

    # ---- Section 3: What to Keep ---------------------------------------

    max_retained_files: int | None = Field(default=None, gt=0)
    """Keep at most this many rolled (sealed) files. Older files are
    pruned. None disables the count cap."""

    total_size_cap_bytes: int | None = Field(default=None, gt=0)
    """Total bytes across all rolled files. Older files are pruned
    until the cap is met. None disables the total-size cap."""

    retention_days: int | None = Field(default=None, gt=0)
    """Maximum age of any rolled file in days. None disables the age cap."""

    # ---- Section 4: How to Preserve ------------------------------------

    compression: CompressionMode = Field(default="None")
    """Compression applied to rolled files. M3 ships None; Gzip /
    Brotli land in a later pass. Accepted in the policy today so
    config files carry forward without a break."""

    share_for_writing: bool = Field(default=False)
    """Allow multiple processes to write the same directory via OS
    advisory lock. Not enforced in M3 (Phase 8)."""

    clean_roll_on_startup: bool = Field(default=True)
    """Seal a pre-existing active file from a previous crash on
    startup. Default True — recovery is the right behaviour by
    default."""

    # ---- Section 5: When Things Go Wrong -------------------------------

    disk_full: DiskFullStrategy = Field(default="Stop")
    """What happens when the filesystem refuses a write. M3 ships
    only Stop (raise on next append). Drop / Fallback in a later
    pass; the field exists so config files carry them now."""

    fallback_sink_name: str | None = Field(default=None)
    """For DiskFullStrategy=Fallback: the name of the sink to route
    to. Not enforced in M3."""
