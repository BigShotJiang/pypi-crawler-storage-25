"""ActiveFileStream — the lifecycle of one currently-being-written file.

Mirrors the planned `ActiveFileStream` helper from the rolling-files
spec (MMPWorks.RollingFiles on the .NET side). Holds the open file
handle, tracks bytes written, fsyncs on demand, and seals the file
atomically on roll.

WHY a separate class from FileManager: FileManager orchestrates many
concerns (rolling decisions, retention, hooks). ActiveFileStream is
just "one file, currently open, append bytes." Splitting them keeps
each concern small and testable.

WHY append mode and not seek-write: append-mode opens have a kernel
guarantee on POSIX that writes are atomic up to a certain size
(PIPE_BUF, typically 4 KB). For NDJSON lines that fit, we get
process-level atomicity for free. On Windows the guarantee is weaker
but the lock the FileManager holds around the append eliminates the
race anyway.
"""

from __future__ import annotations

import os
from pathlib import Path


class ActiveFileStream:
    """One open file being appended to. Owns the OS file descriptor.

    Public surface:
      - path           : Path to the file (read-only after construction)
      - bytes_written  : count of bytes written through this handle
      - append(data)   : append bytes; updates bytes_written
      - fsync()        : durable on-disk for everything written so far
      - close()        : flush + close; idempotent
      - seal_to(target): atomic rename — closes the file and moves it
                         to the target path. Use during roll.
    """

    def __init__(self, path: Path) -> None:
        # WHY Path operations before opening: we want any directory
        # creation error to surface here, not on the first write.
        self._path = path
        path.parent.mkdir(parents=True, exist_ok=True)

        # WHY "ab" (append-binary) and not "a": the SDK writes bytes;
        # text mode does line-ending translation on Windows which
        # would corrupt our canonical-JSON-with-newline framing.
        # buffering=0 means unbuffered — every write goes to the OS
        # immediately. Higher-level fsync coalescing happens in the
        # buffer, not here.
        # WHY noqa SIM115: ActiveFileStream owns the file handle for
        # its lifetime. The handle is closed in close() / seal_to(),
        # not at the end of __init__. A context manager would force
        # premature close.
        self._fd = open(path, mode="ab", buffering=0)  # noqa: SIM115

        # WHY tell() at open time: a FileManager that opens a file
        # that already exists (because it was rolled-into mid-period)
        # needs to know how many bytes are there for size-cap
        # decisions.
        self._bytes_written = self._fd.tell()

        self._closed = False

    @property
    def path(self) -> Path:
        return self._path

    @property
    def bytes_written(self) -> int:
        return self._bytes_written

    def append(self, data: bytes) -> None:
        """Append bytes. Caller is responsible for line framing."""
        if self._closed:
            raise RuntimeError(
                f"ActiveFileStream({self._path}) is closed; cannot append"
            )
        self._fd.write(data)
        self._bytes_written += len(data)

    def fsync(self) -> None:
        """Force durable on-disk for all bytes written so far.

        WHY os.fsync(fd) and not file.flush(): flush() pushes to the
        OS but the OS may still cache before disk. fsync() is the
        kernel-level "actually wait for disk" call we need for the
        audit-grade durability promise.
        """
        if self._closed:
            return
        # flush before fsync — flush pushes Python's userspace buffer
        # to the OS file descriptor; fsync pushes the OS cache to disk.
        # Both are needed in this order.
        self._fd.flush()
        os.fsync(self._fd.fileno())

    def close(self) -> None:
        """Idempotent close. Safe to call multiple times."""
        if self._closed:
            return
        try:
            self._fd.flush()
        finally:
            self._fd.close()
            self._closed = True

    def seal_to(self, target: Path) -> Path:
        """Atomically close this file and move it to `target`.

        Returns the final path. After seal_to() returns, the original
        path no longer exists (or is empty); the bytes are at `target`.

        WHY this exists: when a roll happens, the active file becomes
        a sealed (rolled) file under a new name. Doing close + rename
        atomically — the rename is the OS-level atomic step — means a
        crash mid-roll either leaves the source where it was or the
        target where it should be, never a half-renamed file.
        """
        # Make sure all our bytes are durable BEFORE we rename. A
        # crash between "close the source" and "rename" would leave
        # the bytes at the source path with no rolled file — recovery
        # picks that up via the StartupScanner.
        self.fsync()
        self.close()

        target.parent.mkdir(parents=True, exist_ok=True)

        # WHY os.replace and not os.rename: os.replace is the
        # cross-platform atomic-rename-allowing-overwrite primitive.
        # os.rename's behaviour on Windows when the target exists
        # is "raise"; os.replace replaces. We never want to overwrite
        # an existing rolled file anyway (target paths are uniquely
        # named), so the difference is mostly defensive.
        os.replace(self._path, target)
        return target
