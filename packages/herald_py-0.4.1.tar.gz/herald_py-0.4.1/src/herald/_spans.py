"""span() context manager and aspan() async context manager.

WHY two flavors: customer agents are split between sync and async
code. span() works inside def, aspan() inside async def. Both have
the same shape: open a child span, time the body, attach extra
attributes if asked, close.

The handle returned from each lets the caller add fields mid-span:

    with herald.span("my_step", initial="value") as s:
        result = compute()
        s.attach(result_count=len(result))
"""

from __future__ import annotations

from collections.abc import AsyncIterator, Iterator
from contextlib import asynccontextmanager, contextmanager
from typing import Any

from ._context import current_parent_span_id, span_scope
from ._runtime import active_runtime


class _SpanHandle:
    """Mid-span field bag. Customer code calls .attach(**fields) to
    add attributes to the event the span will eventually emit.

    WHY a handle and not a dict: the handle hides the runtime details
    and lets us add behavior later (e.g. .set_status(), .add_link())
    without breaking the public API.
    """

    def __init__(self) -> None:
        self.attributes: dict[str, Any] = {}

    def attach(self, **attributes: Any) -> None:
        """Merge attributes into the span's eventual event payload."""
        self.attributes.update(attributes)


@contextmanager
def span(name: str, **attributes: Any) -> Iterator[_SpanHandle]:
    """Open a synchronous span as a child of the current run.

    The captured event has kind="span" and includes both the
    attributes passed at open time and any attached via the handle
    inside the block.

    Outside an @herald.agent boundary the runtime synthesizes an
    orphan run_id so the span still has a run to belong to.
    """
    rt = active_runtime()
    span_id = rt.id_gen.new_span_id()
    # WHY parent is captured BEFORE span_scope: see _decorators.py for
    # the same pattern. Once we push our span_id the
    # current_parent_span_id() helper would return our own id.
    parent_span_id = current_parent_span_id()
    start_ns = rt.clock.now_ns()
    handle = _SpanHandle()
    handle.attach(**attributes)

    with span_scope(span_id):
        try:
            yield handle
        finally:
            duration_ns = rt.clock.now_ns() - start_ns
            rt.emit(
                kind="span",
                name=name,
                attributes=handle.attributes,
                duration_ns=duration_ns,
                span_id=span_id,
                parent_span_id=parent_span_id,
            )


@asynccontextmanager
async def aspan(name: str, **attributes: Any) -> AsyncIterator[_SpanHandle]:
    """Open an async span as a child of the current run.

    Same shape as span() but works inside async def code. The body
    can await freely; the handle is the same _SpanHandle.
    """
    rt = active_runtime()
    span_id = rt.id_gen.new_span_id()
    # WHY parent is captured BEFORE span_scope: see _decorators.py for
    # the same pattern. Once we push our span_id the
    # current_parent_span_id() helper would return our own id.
    parent_span_id = current_parent_span_id()
    start_ns = rt.clock.now_ns()
    handle = _SpanHandle()
    handle.attach(**attributes)

    with span_scope(span_id):
        try:
            yield handle
        finally:
            duration_ns = rt.clock.now_ns() - start_ns
            rt.emit(
                kind="span",
                name=name,
                attributes=handle.attributes,
                duration_ns=duration_ns,
                span_id=span_id,
                parent_span_id=parent_span_id,
            )
