"""FileManager — façade-level integration tests."""

from __future__ import annotations

from pathlib import Path

from herald._files import FileManager, FileManagerHooks, FileManagerPolicy


def _basic_policy(directory: Path) -> FileManagerPolicy:
    return FileManagerPolicy(
        directory=str(directory),
        file_name_template="events-{date}.{seq}",
        extension=".ndjson",
        interval="Daily",
    )


def test_active_path_is_under_directory(tmp_path: Path) -> None:
    with FileManager(_basic_policy(tmp_path)) as fm:
        assert Path(fm.active_path).parent == tmp_path
        assert fm.active_path.endswith(".ndjson")
        assert fm.active_bytes == 0


def test_append_line_writes_with_newline(tmp_path: Path) -> None:
    with FileManager(_basic_policy(tmp_path)) as fm:
        fm.append_line("first")
        fm.append_line("second\n")  # explicit newline ignored
        fm.flush()
        content = Path(fm.active_path).read_text()
    # Both lines have exactly one trailing newline.
    assert content == "first\nsecond\n"


def test_append_bytes_writes_raw(tmp_path: Path) -> None:
    with FileManager(_basic_policy(tmp_path)) as fm:
        fm.append_bytes(b"hello")
        fm.append_bytes(b" world")
        fm.flush()
        content = Path(fm.active_path).read_bytes()
    assert content == b"hello world"


def test_active_bytes_tracks_writes(tmp_path: Path) -> None:
    with FileManager(_basic_policy(tmp_path)) as fm:
        fm.append_bytes(b"hello")
        assert fm.active_bytes == 5
        fm.append_bytes(b" world")
        assert fm.active_bytes == 11


def test_size_based_roll(tmp_path: Path) -> None:
    """Writing past max_bytes_per_file produces a rolled file."""
    policy = FileManagerPolicy(
        directory=str(tmp_path),
        file_name_template="events-{date}.{seq}",
        extension=".ndjson",
        interval="Daily",
        max_bytes_per_file=10,
    )
    with FileManager(policy) as fm:
        first_path = fm.active_path
        # Write past the cap.
        for _ in range(5):
            fm.append_bytes(b"abcdef\n")  # 7 bytes each — third write triggers roll
        second_path = fm.active_path

    # Active path should have changed across the roll.
    assert first_path != second_path
    rolled = list(tmp_path.glob("events-*.ndjson"))
    # At least 2 files (the rolled and the active) should exist.
    assert len(rolled) >= 2


def test_roll_now_forces_roll(tmp_path: Path) -> None:
    with FileManager(_basic_policy(tmp_path)) as fm:
        first_path = fm.active_path
        fm.append_line("before roll")
        fm.roll_now()
        second_path = fm.active_path
        fm.append_line("after roll")

    assert first_path != second_path
    # The rolled (first) file should still exist with its content.
    rolled_content = Path(first_path).read_text()
    assert rolled_content == "before roll\n"


def test_list_rolled_returns_sealed_files(tmp_path: Path) -> None:
    with FileManager(_basic_policy(tmp_path)) as fm:
        fm.append_line("a")
        fm.roll_now()
        fm.append_line("b")
        fm.roll_now()
        fm.append_line("c")
        rolled = fm.list_rolled()

    # Two rolls -> two rolled files (the third is the active one,
    # which list_rolled excludes).
    assert len(rolled) == 2
    # Both rolled files have the expected sizes (one byte content + newline).
    for info in rolled:
        assert info.size_bytes == 2  # "a\n" or "b\n"


def test_hooks_fire_around_open_and_roll(tmp_path: Path) -> None:
    opens: list[str] = []
    pre_rolls: list[str] = []
    post_rolls: list[str] = []

    hooks = FileManagerHooks(
        on_open_active=opens.append,
        on_pre_roll=pre_rolls.append,
        on_post_roll=post_rolls.append,
    )

    with FileManager(_basic_policy(tmp_path), hooks) as fm:
        fm.append_line("first")
        fm.roll_now()
        fm.append_line("second")

    # on_open_active fires twice (initial + after the roll).
    assert len(opens) == 2
    # on_pre_roll and on_post_roll each fire once (the manual roll).
    assert len(pre_rolls) == 1
    assert len(post_rolls) == 1
    # The pre_roll path == the post_roll path (same file, sealed).
    assert pre_rolls[0] == post_rolls[0]


def test_retention_drops_oldest(tmp_path: Path) -> None:
    """A roll triggers pruning. With max_retained_files=2, the third
    roll drops the oldest sealed file."""
    policy = FileManagerPolicy(
        directory=str(tmp_path),
        file_name_template="events-{date}.{seq}",
        extension=".ndjson",
        interval="Daily",
        max_retained_files=2,
    )
    with FileManager(policy) as fm:
        # Three rolls produce three sealed files; the cap of 2 means
        # only two survive after the last prune pass.
        for i in range(4):
            fm.append_line(f"line-{i}")
            fm.roll_now()

        rolled = fm.list_rolled()

    assert len(rolled) <= 2


def test_close_is_idempotent(tmp_path: Path) -> None:
    fm = FileManager(_basic_policy(tmp_path))
    fm.append_line("x")
    fm.close()
    fm.close()  # second call is a no-op


def test_startup_scanner_seals_partial(tmp_path: Path) -> None:
    """Pre-existing active file from a 'crashed' previous process gets
    sealed on construction; the new FileManager gets a fresh sequence."""
    # Use a first FileManager to populate the active path with bytes,
    # then write extra bytes directly to simulate a crash where the
    # writer never had a chance to seal the file cleanly.
    with FileManager(_basic_policy(tmp_path)) as fm1:
        partial_path = fm1.active_path
        Path(partial_path).write_text("partial bytes\n")
    # Re-open with clean_roll_on_startup=True (the default) and expect
    # a fresh active file at a higher sequence.
    with FileManager(_basic_policy(tmp_path)) as fm2:
        assert fm2.active_path != partial_path
        # The new active file uses a higher sequence.
        assert ".2." in fm2.active_path or ".3." in fm2.active_path
        # The original path is gone — the scanner renamed the partial
        # to a sealed (rolled) name. Verify the bytes survived under
        # the new name by walking the directory.
        sealed_files = list(tmp_path.glob("events-*.ndjson"))
        # Two files: the new active (empty) and the sealed (with bytes).
        # Find the one with bytes.
        with_bytes = [p for p in sealed_files if p.stat().st_size > 0]
        assert len(with_bytes) >= 1
        # Confirm the partial bytes survived through the rename.
        contents = [p.read_text() for p in with_bytes]
        assert any("partial bytes" in c for c in contents)
