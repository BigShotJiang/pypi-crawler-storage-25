"""Verify each Protocol shape works for both production and test stand-ins.

WHY this matters: Protocols only fail at runtime when isinstance is called
or when the runtime tries to use a method that does not exist. Catching
shape mismatches in unit tests is much cheaper than catching them in
integration tests where the failure surfaces deep in the pipeline.
"""

from __future__ import annotations

from herald._protocols import (
    IBuffer,
    IChainWriter,
    IClock,
    IExporter,
    IFailureSink,
    IIdGenerator,
    IRedactor,
)
from herald.testing import FrozenClock, MemoryBuffer, RecordingExporter


def test_frozen_clock_satisfies_iclock() -> None:
    clock = FrozenClock(now_ns_value=1_000_000_000)
    assert isinstance(clock, IClock)
    assert clock.now_ns() == 1_000_000_000


def test_memory_buffer_satisfies_ibuffer() -> None:
    buffer = MemoryBuffer()
    assert isinstance(buffer, IBuffer)


def test_recording_exporter_satisfies_iexporter() -> None:
    exporter = RecordingExporter()
    assert isinstance(exporter, IExporter)


def test_protocol_classes_are_runtime_checkable() -> None:
    """Every protocol must be runtime_checkable so the runtime can
    inspect components for optional capabilities."""
    protocols = (
        IClock,
        IIdGenerator,
        IBuffer,
        IChainWriter,
        IRedactor,
        IExporter,
        IFailureSink,
    )
    for protocol in protocols:
        # WHY this check: @runtime_checkable sets _is_runtime_protocol
        # on the protocol class. Without it isinstance raises.
        assert getattr(protocol, "_is_runtime_protocol", False), (
            f"{protocol.__name__} missing @runtime_checkable"
        )


def test_random_object_does_not_satisfy_iclock() -> None:
    """Sanity: a class without now_ns() should not satisfy IClock."""

    class NotAClock:
        pass

    assert not isinstance(NotAClock(), IClock)
