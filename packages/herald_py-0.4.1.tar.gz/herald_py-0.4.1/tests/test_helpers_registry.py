"""Registry[T] — generic, decorator-driven, entry-point-aware."""

from __future__ import annotations

import pytest

from herald._helpers.registry import Registry, RegistryError, register


def test_register_and_resolve() -> None:
    reg: Registry[type] = Registry("test")

    @register("foo", reg)
    class Foo:
        pass

    assert reg.resolve("foo") is Foo
    assert "foo" in reg
    assert len(reg) == 1


def test_resolve_unknown_kind_raises_with_known_kinds_listed() -> None:
    reg: Registry[type] = Registry("sink")
    reg.register("a", str)
    reg.register("b", int)

    with pytest.raises(RegistryError) as exc_info:
        reg.resolve("missing")

    msg = str(exc_info.value)
    assert "sink" in msg
    assert "'missing'" in msg
    assert "a, b" in msg


def test_duplicate_register_raises_unless_replace() -> None:
    reg: Registry[type] = Registry("test")
    reg.register("foo", str)

    with pytest.raises(RegistryError, match="already registered"):
        reg.register("foo", int)

    # WHY explicit replace: silent overrides cause hard-to-trace bugs.
    # Plugin authors who genuinely want to override pass replace=True.
    reg.register("foo", int, replace=True)
    assert reg.resolve("foo") is int


def test_empty_kind_rejected() -> None:
    reg: Registry[type] = Registry("test")
    with pytest.raises(RegistryError, match="non-empty"):
        reg.register("", str)


def test_kinds_iterates_registered_keys() -> None:
    reg: Registry[type] = Registry("test")
    reg.register("a", str)
    reg.register("b", int)
    assert sorted(reg.kinds()) == ["a", "b"]


def test_repr_is_useful() -> None:
    reg: Registry[type] = Registry("test")
    reg.register("a", str)
    rep = repr(reg)
    assert "test" in rep
    assert "a" in rep
