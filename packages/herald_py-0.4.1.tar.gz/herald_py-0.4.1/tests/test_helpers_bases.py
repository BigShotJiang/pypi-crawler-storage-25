"""Five Protocol / Base ABC pairs — defaults work as documented."""

from __future__ import annotations

import asyncio

from herald._helpers.bases import (
    BaseEnricher,
    BaseFilter,
    BaseFormatter,
    BaseProcessor,
    BaseSink,
    Enricher,
    Filter,
    Formatter,
    Processor,
    Sink,
)


def test_base_sink_defaults() -> None:
    """BaseSink supplies to_config and a loop-based batch_log fallback."""

    class TestSink(BaseSink):
        kind = "test_sink"

        def __init__(self) -> None:
            self.logged: list[object] = []

        async def log(self, event: object) -> None:
            self.logged.append(event)

    sink = TestSink()
    assert isinstance(sink, Sink)
    assert sink.to_config() == {"kind": "test_sink"}

    async def _go() -> None:
        await sink.batch_log(["a", "b", "c"])

    asyncio.run(_go())
    assert sink.logged == ["a", "b", "c"]


def test_base_enricher_defaults() -> None:
    class StaticEnricher(BaseEnricher):
        kind = "static"

        def enrich(self, event: dict[str, str]) -> dict[str, str]:
            return {**event, "enriched": "yes"}

    enricher = StaticEnricher()
    assert isinstance(enricher, Enricher)
    assert enricher.to_config() == {"kind": "static"}
    assert enricher.enrich({"a": "1"}) == {"a": "1", "enriched": "yes"}


def test_base_filter_allows_by_default() -> None:
    """Default BaseFilter accepts everything. Subclasses that want to
    drop must explicitly say so. This is a coding rule — default-deny
    would be a foot-gun."""

    class AcceptAll(BaseFilter):
        kind = "accept_all"

    f = AcceptAll()
    assert isinstance(f, Filter)
    assert f.allow("anything") is True


def test_base_filter_can_reject() -> None:
    class RejectEvens(BaseFilter):
        kind = "reject_evens"

        def allow(self, event: int) -> bool:
            return event % 2 == 1

    f = RejectEvens()
    assert f.allow(1) is True
    assert f.allow(2) is False


def test_base_formatter_requires_override() -> None:
    """BaseFormatter has no safe default for serialization. Subclasses
    must implement format()."""

    class JsonFormatter(BaseFormatter):
        kind = "json"

        def format(self, event: object) -> bytes:
            return repr(event).encode()

    fm = JsonFormatter()
    assert isinstance(fm, Formatter)
    assert fm.format({"k": "v"}) == b"{'k': 'v'}"


def test_base_processor_passthrough_default() -> None:
    class IdentityProcessor(BaseProcessor):
        kind = "identity"

    p = IdentityProcessor()
    assert isinstance(p, Processor)
    assert p.process({"a": 1}) == {"a": 1}


def test_default_manifest_falls_back_when_no_toml() -> None:
    """Components without a manifest.toml get a synthetic manifest
    derived from their kind and docstring. Lets first-party Phase 1
    components work before they ship real manifests."""

    class TestSink(BaseSink):
        """A test sink."""

        kind = "test_sink"

        async def log(self, event: object) -> None:
            pass

    manifest = TestSink().manifest()
    assert manifest.name == "test_sink"
    # Description falls back to the docstring or class name
    assert manifest.description in ("A test sink.", "TestSink")
