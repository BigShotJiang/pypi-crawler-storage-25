"""ContextVar propagation across spans and asyncio tasks."""

from __future__ import annotations

import asyncio

from herald._context import (
    current_parent_span_id,
    current_run_id,
    current_span_stack,
    run_scope,
    span_scope,
)


def test_default_run_id_is_none() -> None:
    assert current_run_id() is None


def test_default_span_stack_is_empty() -> None:
    assert current_span_stack() == ()


def test_run_scope_sets_and_restores_run_id() -> None:
    assert current_run_id() is None
    with run_scope("RUN-A"):
        assert current_run_id() == "RUN-A"
    assert current_run_id() is None


def test_run_scope_resets_on_exception() -> None:
    try:
        with run_scope("RUN-A"):
            raise RuntimeError("boom")
    except RuntimeError:
        pass
    assert current_run_id() is None


def test_span_scope_pushes_and_pops() -> None:
    assert current_span_stack() == ()
    span_a = b"a" * 8
    span_b = b"b" * 8
    with span_scope(span_a):
        assert current_span_stack() == (span_a,)
        assert current_parent_span_id() == span_a
        with span_scope(span_b):
            assert current_span_stack() == (span_a, span_b)
            assert current_parent_span_id() == span_b
        assert current_span_stack() == (span_a,)
    assert current_span_stack() == ()


def test_span_scope_resets_on_exception() -> None:
    span_a = b"a" * 8
    try:
        with span_scope(span_a):
            raise ValueError("x")
    except ValueError:
        pass
    assert current_span_stack() == ()


def test_asyncio_tasks_get_independent_branches() -> None:
    """The most important property: ContextVar values must propagate
    into asyncio.gather'd tasks but each task's mutations stay local
    to its own context branch. If this is wrong, parallel tools share
    state and run_ids tangle."""
    observed: list[tuple[str | None, tuple[bytes, ...]]] = []

    async def worker(label: str) -> None:
        # Each worker pushes its own span; observed should record the
        # outer run_id and the worker's own pushed stack.
        with span_scope(label.encode().ljust(8, b"\x00")):
            await asyncio.sleep(0)  # yield to the loop
            observed.append((current_run_id(), current_span_stack()))

    async def driver() -> None:
        with run_scope("RUN-PARENT"):
            await asyncio.gather(
                worker("a"),
                worker("b"),
                worker("c"),
            )

    asyncio.run(driver())

    # All three workers see the same run_id (parent)
    run_ids = {entry[0] for entry in observed}
    assert run_ids == {"RUN-PARENT"}

    # Each worker has its own one-element span stack
    assert len(observed) == 3
    for _, stack in observed:
        assert len(stack) == 1
