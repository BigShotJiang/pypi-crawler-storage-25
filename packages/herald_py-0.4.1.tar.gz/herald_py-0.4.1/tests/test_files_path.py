"""Token expansion + filename construction."""

from __future__ import annotations

from datetime import datetime, timezone

from herald._files._path import (
    build_filename,
    build_full_path,
    expand_static_tokens,
    format_period_date,
)
from herald._files.policy import FileManagerPolicy


def test_static_tokens_resolve_hostname_and_pid() -> None:
    out = expand_static_tokens("logs/{hostname}/{pid}/herald", {})
    # Both tokens get filled in from the OS.
    assert "{hostname}" not in out
    assert "{pid}" not in out


def test_custom_tokens_win_over_defaults() -> None:
    out = expand_static_tokens(
        "{hostname}/{service}", {"hostname": "fake-host", "service": "agent"}
    )
    assert out == "fake-host/agent"


def test_dynamic_tokens_left_alone() -> None:
    """{date} and {seq} resolve later, per-roll. Static expansion
    must not touch them."""
    out = expand_static_tokens("events-{date}.{seq}", {})
    assert out == "events-{date}.{seq}"


def test_unknown_token_left_in_place() -> None:
    """Unknown tokens are visible in the output so operators
    notice the typo. Silent empty-string substitution would hide
    bugs."""
    out = expand_static_tokens("logs/{not_a_real_token}/x", {})
    assert "{not_a_real_token}" in out


def test_format_period_date_daily() -> None:
    p = datetime(2026, 5, 5, 0, 0, tzinfo=timezone.utc)
    assert format_period_date(p, "Daily") == "2026-05-05"


def test_format_period_date_hourly() -> None:
    p = datetime(2026, 5, 5, 14, 0, tzinfo=timezone.utc)
    assert format_period_date(p, "Hourly") == "2026-05-05_14"


def test_format_period_date_custom() -> None:
    p = datetime(2026, 5, 5, 14, 30, tzinfo=timezone.utc)
    assert format_period_date(p, "Custom") == "2026-05-05_14-30"


def test_format_period_date_none_is_empty() -> None:
    p = datetime(2026, 5, 5, tzinfo=timezone.utc)
    assert format_period_date(p, "None") == ""


def test_format_period_date_custom_suffix_overrides() -> None:
    p = datetime(2026, 5, 5, 14, 30, tzinfo=timezone.utc)
    assert format_period_date(p, "Daily", file_name_suffix="%Y%m%d") == "20260505"


def test_build_filename_combines_template_date_seq_extension() -> None:
    name = build_filename(
        template_with_static_tokens_expanded="events-{date}.{seq}",
        period_start=datetime(2026, 5, 5, tzinfo=timezone.utc),
        interval="Daily",
        sequence=1,
        extension=".ndjson",
        file_name_suffix=None,
    )
    assert name == "events-2026-05-05.1.ndjson"


def test_build_filename_higher_sequence() -> None:
    name = build_filename(
        template_with_static_tokens_expanded="events-{date}.{seq}",
        period_start=datetime(2026, 5, 5, tzinfo=timezone.utc),
        interval="Daily",
        sequence=7,
        extension=".ndjson",
        file_name_suffix=None,
    )
    assert name == "events-2026-05-05.7.ndjson"


def test_build_full_path_joins_directory(tmp_path) -> None:  # type: ignore[no-untyped-def]
    policy = FileManagerPolicy(directory=str(tmp_path), interval="Daily")
    p = build_full_path(
        policy,
        period_start=datetime(2026, 5, 5, tzinfo=timezone.utc),
        sequence=1,
        expanded_directory=str(tmp_path),
        expanded_template="events-{date}.{seq}",
    )
    assert p.parent == tmp_path
    assert p.name == "events-2026-05-05.1.ndjson"
