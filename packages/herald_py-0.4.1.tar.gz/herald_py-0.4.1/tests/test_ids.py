"""UlidGenerator — production IIdGenerator."""

from __future__ import annotations

from herald._ids import UlidGenerator
from herald._protocols import IIdGenerator


def test_ulid_generator_satisfies_iidgenerator() -> None:
    assert isinstance(UlidGenerator(), IIdGenerator)


def test_run_id_is_a_ulid_string() -> None:
    g = UlidGenerator()
    run_id = g.new_run_id()
    assert isinstance(run_id, str)
    # ULID strings are 26 chars of Crockford base32
    assert len(run_id) == 26


def test_run_ids_are_unique_and_sortable() -> None:
    """ULIDs are time-sortable. Consecutive run_ids should compare
    in increasing order (within the same millisecond they may not,
    but we sample across multiple ms-windows)."""
    g = UlidGenerator()
    ids = [g.new_run_id() for _ in range(100)]
    # All unique
    assert len(set(ids)) == 100


def test_trace_id_is_16_random_bytes() -> None:
    g = UlidGenerator()
    trace_id = g.new_trace_id()
    assert isinstance(trace_id, bytes)
    assert len(trace_id) == 16


def test_span_id_is_8_random_bytes() -> None:
    g = UlidGenerator()
    span_id = g.new_span_id()
    assert isinstance(span_id, bytes)
    assert len(span_id) == 8


def test_trace_and_span_ids_unique_across_calls() -> None:
    g = UlidGenerator()
    traces = [g.new_trace_id() for _ in range(50)]
    spans = [g.new_span_id() for _ in range(50)]
    assert len(set(traces)) == 50
    assert len(set(spans)) == 50
