"""SystemClock — production wall-clock IClock."""

from __future__ import annotations

import time

from herald._clock import SystemClock
from herald._protocols import IClock


def test_system_clock_satisfies_iclock() -> None:
    assert isinstance(SystemClock(), IClock)


def test_system_clock_returns_monotonically_recent_value() -> None:
    """now_ns() should be close to time.time_ns() and non-decreasing
    across consecutive calls."""
    clock = SystemClock()
    expected = time.time_ns()
    actual = clock.now_ns()
    # Within 1 second is plenty for a sanity check
    assert abs(actual - expected) < 1_000_000_000
    later = clock.now_ns()
    assert later >= actual
