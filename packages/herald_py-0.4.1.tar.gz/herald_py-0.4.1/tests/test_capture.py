"""Headline M2 acceptance test: end-to-end capture through the runtime.

What this proves:
  - @herald.agent opens a fresh run_id and captures an "agent" event.
  - @herald.tool inside an agent captures a "tool" event with the same
    run_id and the agent's span as parent.
  - Nested @herald.tool calls share the run_id; span_stack grows.
  - asyncio.gather of multiple tools does not tangle run_ids; each
    branch is independent.
  - herald.span() and aspan() capture "span" events.
  - herald.record() and herald.audit() capture with the right
    chain_kind tags.
  - Exceptions inside a captured body still emit the event and
    propagate the exception.
"""

from __future__ import annotations

import asyncio

import pytest

import herald
from herald._runtime import _set_active_runtime, active_runtime
from herald._settings import _reset_active_for_testing


def setup_function() -> None:
    _reset_active_for_testing()
    _set_active_runtime(None)


def teardown_function() -> None:
    _reset_active_for_testing()
    _set_active_runtime(None)


def test_agent_decorator_opens_run_and_captures() -> None:
    herald.configure()

    @herald.agent(name="my_agent", version="1.2.3")
    def run_agent() -> str:
        return "ok"

    assert run_agent() == "ok"

    rt = active_runtime()
    events = rt.buffer.events
    assert len(events) == 1
    agent_event = events[0]
    assert agent_event.kind == "agent"
    assert agent_event.name == "my_agent"
    assert agent_event.attributes.get("agent.version") == "1.2.3"
    assert agent_event.run_id  # fresh run_id assigned
    assert agent_event.parent_span_id is None  # top of the run
    assert agent_event.duration_ns is not None
    assert agent_event.duration_ns >= 0


def test_tool_inside_agent_inherits_run_id_and_has_parent() -> None:
    herald.configure()

    @herald.tool(name="lookup")
    def lookup(x: int) -> int:
        return x * 2

    @herald.agent(name="parent_agent")
    def parent() -> int:
        return lookup(7)

    assert parent() == 14

    events = active_runtime().buffer.events
    # Order: tool finishes first (inner), agent finishes after (outer).
    assert len(events) == 2
    tool_event = events[0]
    agent_event = events[1]

    assert tool_event.kind == "tool"
    assert tool_event.name == "lookup"
    assert agent_event.kind == "agent"

    # run_id propagated
    assert tool_event.run_id == agent_event.run_id

    # tool's parent is the agent's span
    assert tool_event.parent_span_id == agent_event.span_id
    # agent has no parent
    assert agent_event.parent_span_id is None


def test_nested_tools_chain_through_span_stack() -> None:
    herald.configure()

    @herald.tool(name="inner")
    def inner() -> str:
        return "leaf"

    @herald.tool(name="middle")
    def middle() -> str:
        return inner()

    @herald.agent(name="root_agent")
    def root() -> str:
        return middle()

    root()

    events = active_runtime().buffer.events
    # Order of completion: inner, middle, agent
    assert [e.name for e in events] == ["inner", "middle", "root_agent"]
    inner_e, middle_e, agent_e = events

    # All share the same run_id
    rid = agent_e.run_id
    assert all(e.run_id == rid for e in events)

    # Span chain: agent <- middle <- inner
    assert agent_e.parent_span_id is None
    assert middle_e.parent_span_id == agent_e.span_id
    assert inner_e.parent_span_id == middle_e.span_id


def test_asyncio_gather_keeps_run_ids_per_branch_isolated() -> None:
    """asyncio.gather under one agent: each parallel tool must
    inherit the same run_id, and each tool's span_id must be unique.
    No state tangling between sibling branches."""
    herald.configure()

    @herald.tool(name="parallel_tool")
    async def worker(label: str) -> str:
        await asyncio.sleep(0)  # yield to scheduler
        return label

    @herald.agent(name="fanout_agent")
    async def fanout() -> list[str]:
        return await asyncio.gather(worker("a"), worker("b"), worker("c"))

    result = asyncio.run(fanout())
    assert result == ["a", "b", "c"]

    events = active_runtime().buffer.events
    # 3 tools + 1 agent = 4 events
    assert len(events) == 4

    agent_events = [e for e in events if e.kind == "agent"]
    tool_events = [e for e in events if e.kind == "tool"]
    assert len(agent_events) == 1
    assert len(tool_events) == 3

    rid = agent_events[0].run_id
    # All three tools see the parent run_id
    assert all(e.run_id == rid for e in tool_events)

    # Each tool has the agent as parent (because they all open under
    # the agent's span scope, even though they run concurrently)
    for tool_event in tool_events:
        assert tool_event.parent_span_id == agent_events[0].span_id

    # Span IDs are all unique
    span_ids = [e.span_id for e in events]
    assert len(set(span_ids)) == 4


def test_span_context_manager_captures() -> None:
    herald.configure()

    @herald.agent(name="a1")
    def go() -> None:
        with herald.span("inner_step", a=1) as s:
            s.attach(b=2)

    go()

    events = active_runtime().buffer.events
    span_e = next(e for e in events if e.kind == "span")
    assert span_e.name == "inner_step"
    assert span_e.attributes == {"a": 1, "b": 2}


def test_aspan_async_context_manager_captures() -> None:
    herald.configure()

    @herald.agent(name="a1")
    async def go() -> None:
        async with herald.aspan("async_step", k="v") as s:
            s.attach(more=True)

    asyncio.run(go())

    events = active_runtime().buffer.events
    span_e = next(e for e in events if e.kind == "span")
    assert span_e.name == "async_step"
    assert span_e.attributes == {"k": "v", "more": True}


def test_record_emits_with_telemetry_chain_kind() -> None:
    herald.configure()

    @herald.agent(name="a1")
    def go() -> None:
        herald.record(event="custom_metric", level="info", value=42)

    go()
    events = active_runtime().buffer.events
    rec = next(e for e in events if e.kind == "record")
    assert rec.name == "custom_metric"
    assert rec.attributes == {"value": 42}
    assert rec.severity == "INFO"
    assert rec.chain_kind == "telemetry"


def test_audit_emits_with_audit_chain_kind() -> None:
    herald.configure()

    @herald.agent(name="a1")
    def go() -> None:
        herald.audit(event="refund_decision", decision="deny")

    go()
    events = active_runtime().buffer.events
    aud = next(e for e in events if e.kind == "audit")
    assert aud.name == "refund_decision"
    assert aud.attributes == {"decision": "deny"}
    assert aud.severity == "AUDIT"
    assert aud.chain_kind == "audit"


def test_exception_in_body_still_emits_and_propagates() -> None:
    """If the wrapped body raises, the captured event must still be
    emitted (with the duration up to the failure point) and the
    exception must propagate to the caller."""
    herald.configure()

    @herald.tool(name="will_fail")
    def boom() -> None:
        raise RuntimeError("intentional")

    with pytest.raises(RuntimeError, match="intentional"):
        boom()

    events = active_runtime().buffer.events
    assert len(events) == 1
    assert events[0].name == "will_fail"
    assert events[0].duration_ns is not None


def test_llm_call_decorator_attaches_genai_attributes() -> None:
    herald.configure()

    @herald.llm_call(model="claude-opus-4-7", provider="anthropic")
    def call() -> str:
        return "response"

    call()
    events = active_runtime().buffer.events
    assert events[0].kind == "llm_call"
    assert events[0].name == "claude-opus-4-7"
    assert events[0].attributes["gen_ai.request.model"] == "claude-opus-4-7"
    assert events[0].attributes["gen_ai.system"] == "anthropic"
