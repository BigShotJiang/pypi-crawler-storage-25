"""Buffer implementations: InMemoryBuffer and FileBuffer.

FileBuffer is the M3 capstone — verifies the runtime can capture
events end-to-end through the rolling-NDJSON file backend.
"""

from __future__ import annotations

from pathlib import Path

import herald
from herald._buffer import FileBuffer, InMemoryBuffer, serialize_event
from herald._runtime import active_runtime
from herald.testing import EventBuilder


def test_on_disk_format_version_is_v1() -> None:
    """The byte-level format version is 'v1' as locked at v0.4.0.

    Bumping this constant is a visible signal of a non-additive
    format change and requires an ADR + migration note per
    docs/on-disk-format.md's Versioning Policy section.
    """
    from herald._files import ON_DISK_FORMAT_VERSION

    assert ON_DISK_FORMAT_VERSION == "v1"


def test_inmemory_buffer_appends() -> None:
    buf = InMemoryBuffer()
    e = EventBuilder.create(name="x")
    buf.write_sync(e)
    assert buf.events == [e]


def test_serialize_event_is_orjson_compatible() -> None:
    """Bytes fields must serialise as base64 (Pydantic config), not raw."""
    e = EventBuilder.create(name="x")
    blob = serialize_event(e)
    assert isinstance(blob, bytes)
    # NDJSON has no trailing newline at the serialise step (manager adds it).
    assert b"\n" not in blob
    # Bytes are base64-encoded; raw 0x00 bytes from trace_id should not appear.
    # (Random bytes can include any byte, but base64 alphabet is ASCII-only.)


def test_serialize_event_is_deterministic() -> None:
    """Same event in -> same bytes out. Foundation of the audit chain."""
    e = EventBuilder.create(name="x", attributes={"b": 1, "a": 2})
    a = serialize_event(e)
    b = serialize_event(e)
    assert a == b


def test_file_buffer_writes_telemetry_and_audit_to_separate_channels(tmp_path: Path) -> None:
    """Telemetry and audit events land in different subdirectories with
    different filenames."""
    herald.configure(durability="files", durability_path=str(tmp_path))

    @herald.agent(name="capture_agent")
    def go() -> None:
        herald.record(event="step", value=1)
        herald.audit(event="critical", decision="allow")

    go()

    buf = active_runtime().buffer
    assert isinstance(buf, FileBuffer)

    telemetry = buf.read_telemetry_events()
    audit = buf.read_audit_events()

    # The agent + record both produce telemetry events; audit produces 1.
    assert len(telemetry) == 2
    assert len(audit) == 1
    assert audit[0]["chain_kind"] == "audit"
    assert audit[0]["name"] == "critical"

    # Files live under tmp_path/telemetry/ and tmp_path/audit/.
    assert (tmp_path / "telemetry").is_dir()
    assert (tmp_path / "audit").is_dir()

    buf.close()


def test_file_buffer_audit_path_is_fsynced(tmp_path: Path) -> None:
    """An audit() call returns only after the bytes are durable.
    We can't easily test fsync from Python, but we can verify the
    file exists and is non-empty by the time audit() returns."""
    herald.configure(durability="files", durability_path=str(tmp_path))

    @herald.agent(name="auditing_agent")
    def go() -> None:
        herald.audit(event="must_be_on_disk")

    go()

    buf = active_runtime().buffer
    assert isinstance(buf, FileBuffer)

    # Read the file directly, not via the test helper, to verify the
    # bytes hit the FS path the buffer claims they did.
    content = Path(buf.audit_path).read_text()
    assert "must_be_on_disk" in content

    buf.close()


def test_file_buffer_requires_durability_path() -> None:
    """FileBuffer construction without durability_path raises clearly."""
    import pytest

    from herald._settings import HeraldSettings

    s = HeraldSettings(durability="files")  # durability_path None
    with pytest.raises(ValueError, match="durability_path"):
        FileBuffer(s)


def test_file_buffer_round_trip_event_shape(tmp_path: Path) -> None:
    """An event written and read back has every captured field intact —
    the cross-language contract starts here. The .NET FileManager
    (when it lands) reads files of this exact shape."""
    herald.configure(durability="files", durability_path=str(tmp_path))

    @herald.tool(name="my_tool")
    def the_tool() -> int:
        return 42

    @herald.agent(name="run")
    def run() -> int:
        return the_tool()

    run()

    buf = active_runtime().buffer
    assert isinstance(buf, FileBuffer)
    events = buf.read_telemetry_events()
    # Two telemetry events: tool, agent.
    assert len(events) == 2

    # Required fields present on every captured event.
    required = {
        "event_id", "trace_id", "span_id", "run_id", "kind", "name",
        "timestamp_ns", "attributes", "severity", "chain_kind",
    }
    for e in events:
        missing = required - set(e.keys())
        assert not missing, f"event missing fields: {missing}"

    # Tool's parent_span_id == agent's span_id (M2 contract still holds).
    tool = next(e for e in events if e["kind"] == "tool")
    agent = next(e for e in events if e["kind"] == "agent")
    assert tool["parent_span_id"] == agent["span_id"]

    buf.close()


def test_inmemory_buffer_is_default(tmp_path: Path) -> None:
    """Without durability='files', the runtime gets InMemoryBuffer."""
    del tmp_path  # not used; the parametrized fixture is just for symmetry
    herald.configure()  # default durability="memory"
    rt = active_runtime()
    assert isinstance(rt.buffer, InMemoryBuffer)
