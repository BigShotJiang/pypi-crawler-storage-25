"""Composite[T] dispatcher + compose() decorator-stack helper."""

from __future__ import annotations

from collections.abc import Callable

from herald._helpers.composition import Composite, compose


def test_composite_iterates_in_registration_order() -> None:
    composite: Composite[int] = Composite([1, 2])
    composite.add(3)
    assert list(composite) == [1, 2, 3]


def test_composite_extend() -> None:
    composite: Composite[str] = Composite(["a"])
    composite.extend(["b", "c"])
    assert list(composite) == ["a", "b", "c"]


def test_composite_truthiness() -> None:
    empty: Composite[int] = Composite()
    assert not empty
    populated: Composite[int] = Composite([1])
    assert populated
    assert len(populated) == 1


def test_compose_applies_decorators_outermost_first() -> None:
    """The first decorator listed is the outermost — the one a request
    hits first. Easy to get backwards if the implementation is wrong."""
    log: list[str] = []

    def make_decorator(label: str) -> Callable[[Callable[[], str]], Callable[[], str]]:
        def decorator(inner: Callable[[], str]) -> Callable[[], str]:
            def wrapped() -> str:
                log.append(f"enter {label}")
                result = inner()
                log.append(f"exit {label}")
                return result

            return wrapped

        return decorator

    def base() -> str:
        log.append("base")
        return "ok"

    # WHY this order: "outer" is listed first, "inner" last. A request hits
    # outer.enter, then middle.enter, then inner.enter, then base, then
    # the exits in reverse.
    decorated = compose(
        base,
        decorators=[make_decorator("outer"), make_decorator("middle"), make_decorator("inner")],
    )
    result = decorated()

    assert result == "ok"
    assert log == [
        "enter outer",
        "enter middle",
        "enter inner",
        "base",
        "exit inner",
        "exit middle",
        "exit outer",
    ]


def test_compose_with_no_decorators_returns_inner_unchanged() -> None:
    def inner() -> int:
        return 42

    assert compose(inner, decorators=[])() == 42
