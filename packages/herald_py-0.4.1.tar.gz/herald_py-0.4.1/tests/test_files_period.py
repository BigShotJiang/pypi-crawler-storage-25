"""RollingFilePeriod math — same boundaries as the .NET helper."""

from __future__ import annotations

from datetime import datetime, timezone

from herald._files._period import get_period_start


def test_none_interval_returns_min() -> None:
    """Interval=None means files never roll on time alone; the
    sentinel is datetime.min so equality checks always fail."""
    now = datetime(2026, 5, 5, 12, 30, tzinfo=timezone.utc)
    p = get_period_start(now, "None")
    assert p < now


def test_hourly_snaps_to_hour() -> None:
    now = datetime(2026, 5, 5, 12, 37, 45, tzinfo=timezone.utc)
    p = get_period_start(now, "Hourly")
    assert p == datetime(2026, 5, 5, 12, 0, tzinfo=timezone.utc)


def test_daily_snaps_to_midnight_utc() -> None:
    now = datetime(2026, 5, 5, 23, 59, 59, tzinfo=timezone.utc)
    p = get_period_start(now, "Daily")
    assert p == datetime(2026, 5, 5, 0, 0, tzinfo=timezone.utc)


def test_naive_datetime_is_treated_as_utc() -> None:
    """Helpers without tzinfo: assume UTC. Tests the cross-language
    contract — both Python and .NET reason in UTC."""
    naive = datetime(2026, 5, 5, 5, 0)
    p = get_period_start(naive, "Daily")
    assert p == datetime(2026, 5, 5, 0, 0, tzinfo=timezone.utc)


def test_custom_30min_windows_starting_at_15() -> None:
    """30-min windows that start at :15 each hour."""
    # 12:15 -> window starts at 12:15
    now = datetime(2026, 5, 5, 12, 15, tzinfo=timezone.utc)
    p = get_period_start(now, "Custom", start_minute=15, capture_duration_minutes=30)
    assert p == datetime(2026, 5, 5, 12, 15, tzinfo=timezone.utc)

    # 12:44 -> still in 12:15-12:44 window
    now = datetime(2026, 5, 5, 12, 44, tzinfo=timezone.utc)
    p = get_period_start(now, "Custom", start_minute=15, capture_duration_minutes=30)
    assert p == datetime(2026, 5, 5, 12, 15, tzinfo=timezone.utc)

    # 12:45 -> next window starts
    now = datetime(2026, 5, 5, 12, 45, tzinfo=timezone.utc)
    p = get_period_start(now, "Custom", start_minute=15, capture_duration_minutes=30)
    assert p == datetime(2026, 5, 5, 12, 45, tzinfo=timezone.utc)


def test_custom_window_before_start_minute_wraps() -> None:
    """At 00:10 with start_minute=15: we are in the window that
    started yesterday at 23:45 (the last window before our start
    point on this day's clock). The math snaps to the same minute
    on the same day; cross-day wrap is a separate concern handled
    by Daily rolling."""
    now = datetime(2026, 5, 5, 0, 10, tzinfo=timezone.utc)
    p = get_period_start(now, "Custom", start_minute=15, capture_duration_minutes=30)
    # Mirrors the C# math — minutes_since_start += 24*60 wraps on
    # the same day. Result is in the day's last 30-min window
    # (23:45 today, expressed as a same-day timestamp).
    assert p.minute in (45,)


def test_custom_clamps_invalid_args() -> None:
    """capture_duration <= 0 falls back to 60; start_minute clamps to [0,59]."""
    now = datetime(2026, 5, 5, 12, 30, tzinfo=timezone.utc)
    p = get_period_start(now, "Custom", start_minute=-5, capture_duration_minutes=0)
    # start_minute -5 clamps to 0; capture 0 falls back to 60.
    assert p == datetime(2026, 5, 5, 12, 0, tzinfo=timezone.utc)
