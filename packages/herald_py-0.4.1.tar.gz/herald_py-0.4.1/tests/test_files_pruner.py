"""Retention pruning — count + total-size + age."""

from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone
from pathlib import Path

from herald._files._pruner import _CandidateFile, prune, select_for_pruning


def _candidate(path: str, size: int, mtime: datetime) -> _CandidateFile:
    return _CandidateFile(path=Path(path), size_bytes=size, mtime=mtime)


def test_no_caps_keeps_everything() -> None:
    now = datetime(2026, 5, 5, tzinfo=timezone.utc)
    cands = [
        _candidate("a", 100, now - timedelta(days=1)),
        _candidate("b", 100, now - timedelta(days=2)),
    ]
    drop = select_for_pruning(
        cands,
        max_retained_files=None,
        total_size_cap_bytes=None,
        retention_days=None,
        now=now,
    )
    assert drop == []


def test_count_cap_drops_oldest() -> None:
    now = datetime(2026, 5, 5, tzinfo=timezone.utc)
    cands = [
        _candidate("a", 100, now - timedelta(days=1)),
        _candidate("b", 100, now - timedelta(days=2)),
        _candidate("c", 100, now - timedelta(days=3)),
    ]
    drop = select_for_pruning(
        cands,
        max_retained_files=2,
        total_size_cap_bytes=None,
        retention_days=None,
        now=now,
    )
    # Keep newest 2 (a, b); drop oldest (c).
    assert {p.path.name for p in drop} == {"c"}


def test_age_cap_drops_too_old() -> None:
    now = datetime(2026, 5, 5, tzinfo=timezone.utc)
    cands = [
        _candidate("recent", 100, now - timedelta(days=1)),
        _candidate("old", 100, now - timedelta(days=20)),
    ]
    drop = select_for_pruning(
        cands,
        max_retained_files=None,
        total_size_cap_bytes=None,
        retention_days=14,
        now=now,
    )
    assert {p.path.name for p in drop} == {"old"}


def test_size_cap_drops_oldest_until_under() -> None:
    now = datetime(2026, 5, 5, tzinfo=timezone.utc)
    cands = [
        _candidate("a", 600, now - timedelta(hours=1)),  # newest
        _candidate("b", 600, now - timedelta(hours=2)),
        _candidate("c", 600, now - timedelta(hours=3)),  # oldest
    ]
    # Total = 1800, cap = 1500. Keep newest 2 (1200 < 1500); drop c.
    drop = select_for_pruning(
        cands,
        max_retained_files=None,
        total_size_cap_bytes=1500,
        retention_days=None,
        now=now,
    )
    assert {p.path.name for p in drop} == {"c"}


def test_caps_compose_tightest_wins() -> None:
    """count=2 says keep 2; size=1200 says keep 2 (each 600); age=10
    says drop the 11-day-old. All three converge here."""
    now = datetime(2026, 5, 5, tzinfo=timezone.utc)
    cands = [
        _candidate("a", 600, now - timedelta(days=1)),
        _candidate("b", 600, now - timedelta(days=5)),
        _candidate("c", 600, now - timedelta(days=11)),  # too old AND beyond count
    ]
    drop = select_for_pruning(
        cands,
        max_retained_files=2,
        total_size_cap_bytes=2000,
        retention_days=10,
        now=now,
    )
    assert {p.path.name for p in drop} == {"c"}


def test_prune_actually_deletes_files(tmp_path: Path) -> None:
    """End-to-end: create files on disk, call prune, verify the
    selected files are gone."""
    now = datetime.now(tz=timezone.utc)

    keep = tmp_path / "keep.ndjson"
    drop = tmp_path / "drop.ndjson"
    keep.write_text("recent")
    drop.write_text("old")

    # Backdate `drop`'s mtime so it falls outside the age cap.
    old_ts = (now - timedelta(days=30)).timestamp()
    os.utime(drop, (old_ts, old_ts))

    deleted = prune(
        tmp_path,
        extension=".ndjson",
        exclude=[],
        max_retained_files=None,
        total_size_cap_bytes=None,
        retention_days=14,
        now=now,
    )

    assert keep.exists()
    assert not drop.exists()
    assert deleted == [drop]


def test_prune_respects_exclude_list(tmp_path: Path) -> None:
    """The active file must never be pruned even when older than the
    cap — pruning the file out from under the writer would corrupt
    subsequent writes."""
    now = datetime.now(tz=timezone.utc)

    active = tmp_path / "active.ndjson"
    rolled = tmp_path / "rolled.ndjson"
    active.write_text("active")
    rolled.write_text("rolled")

    # Both files are old per the age cap.
    old_ts = (now - timedelta(days=30)).timestamp()
    os.utime(active, (old_ts, old_ts))
    os.utime(rolled, (old_ts, old_ts))

    deleted = prune(
        tmp_path,
        extension=".ndjson",
        exclude=[active],
        max_retained_files=None,
        total_size_cap_bytes=None,
        retention_days=14,
        now=now,
    )

    assert active.exists()
    assert not rolled.exists()
    assert deleted == [rolled]


def test_on_prune_hook_can_veto(tmp_path: Path) -> None:
    """on_prune returning False keeps the file (Durable Buffer pattern)."""
    now = datetime.now(tz=timezone.utc)

    candidate = tmp_path / "old.ndjson"
    candidate.write_text("x")
    old_ts = (now - timedelta(days=30)).timestamp()
    os.utime(candidate, (old_ts, old_ts))

    def _veto(_: str) -> bool:
        return False  # never delete

    deleted = prune(
        tmp_path,
        extension=".ndjson",
        exclude=[],
        max_retained_files=None,
        total_size_cap_bytes=None,
        retention_days=1,
        now=now,
        on_prune=_veto,
    )

    assert candidate.exists()
    assert deleted == []
