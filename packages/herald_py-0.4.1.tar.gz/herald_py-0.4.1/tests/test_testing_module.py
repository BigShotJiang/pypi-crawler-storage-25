"""Public herald.testing fixtures behave as documented."""

from __future__ import annotations

import asyncio
from datetime import timedelta

from herald.testing import (
    EventBuilder,
    FakeHttpRequest,
    FakeHttpTransport,
    FrozenClock,
    MemoryBuffer,
    RecordingExporter,
)
from herald.testing.http import FakeHttpRequest as DirectFakeHttpRequest


def test_frozen_clock_advances_by_timedelta() -> None:
    clock = FrozenClock(now_ns_value=0)
    clock.advance(timedelta(milliseconds=5))
    assert clock.now_ns() == 5_000_000


def test_frozen_clock_advances_by_int_nanoseconds() -> None:
    clock = FrozenClock(now_ns_value=100)
    clock.advance(50)
    assert clock.now_ns() == 150


def test_frozen_clock_rejects_negative_advance() -> None:
    clock = FrozenClock()
    try:
        clock.advance(-1)
    except ValueError:
        return
    raise AssertionError("expected ValueError on negative advance")


def test_frozen_clock_reset() -> None:
    clock = FrozenClock(now_ns_value=1000)
    clock.advance(500)
    assert clock.now_ns() == 1500
    clock.reset()
    assert clock.now_ns() == 1000


def test_memory_buffer_round_trip() -> None:
    buffer = MemoryBuffer()

    async def _go() -> list[object]:
        await buffer.write("first", sync_mode="NORMAL")
        await buffer.write("second", sync_mode="FULL")
        await buffer.write("third", sync_mode="NORMAL")
        return await buffer.drain_unsent(batch_size=10)

    drained = asyncio.run(_go())
    assert drained == ["first", "second", "third"]
    assert buffer.events_with_sync_mode("FULL") == ["second"]
    assert len(buffer) == 3


def test_memory_buffer_mark_sent_excludes_from_drain() -> None:
    buffer = MemoryBuffer()

    async def _go() -> list[object]:
        await buffer.write("a")
        await buffer.write("b")
        await buffer.mark_sent(range(1, 2))  # mark first event
        return await buffer.drain_unsent(batch_size=10)

    remaining = asyncio.run(_go())
    assert remaining == ["b"]


def test_recording_exporter_captures_batches() -> None:
    exporter = RecordingExporter()

    async def _go() -> None:
        await exporter.export_batch(["a", "b"])
        await exporter.export_batch(["c"])

    asyncio.run(_go())
    assert len(exporter.batches) == 2
    assert exporter.batches[0] == ["a", "b"]
    assert exporter.batches[1] == ["c"]
    assert exporter.all_events() == ["a", "b", "c"]


def test_recording_exporter_can_simulate_failure() -> None:
    exporter = RecordingExporter()
    exporter.fail_next = True

    async def _go() -> None:
        try:
            await exporter.export_batch(["a"])
        except RuntimeError:
            return
        raise AssertionError("expected RuntimeError")

    asyncio.run(_go())
    assert exporter.fail_count == 1
    assert exporter.fail_next is False  # reset after the induced failure
    assert exporter.batches == []  # the failed batch was not recorded


def test_event_builder_creates_valid_event() -> None:
    """EventBuilder.create() produces a HeraldEvent with every required
    field filled in."""
    event = EventBuilder.create(name="my_tool")
    assert event.name == "my_tool"
    assert len(event.trace_id) == 16
    assert len(event.span_id) == 8
    assert event.run_id


def test_event_builder_overrides() -> None:
    event = EventBuilder.create(
        name="custom",
        attributes={"k": "v"},
        severity="WARN",
    )
    assert event.attributes == {"k": "v"}
    assert event.severity == "WARN"


def test_fake_http_transport_records_requests() -> None:
    transport = FakeHttpTransport(default_status=201)
    transport.record(FakeHttpRequest(method="POST", url="/x", headers={}, body=b"{}"))
    assert len(transport.requests) == 1
    assert transport.requests[0].method == "POST"

    response = transport.respond()
    assert response["status_code"] == 201

    transport.reset()
    assert transport.requests == []
    # Confirm the public re-export and the direct module path are the
    # same class — defends against accidentally publishing a copy.
    assert DirectFakeHttpRequest is FakeHttpRequest
