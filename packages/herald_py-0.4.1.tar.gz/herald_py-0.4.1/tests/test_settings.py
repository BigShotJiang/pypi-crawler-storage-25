"""HeraldSettings — env-var loading, validation, immutability."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

import herald
from herald._settings import HeraldSettings, _reset_active_for_testing, active


def setup_function() -> None:
    """Reset active settings before every test so configure() in one
    test does not leak into the next."""
    _reset_active_for_testing()


def teardown_function() -> None:
    _reset_active_for_testing()


def test_default_settings_instantiable() -> None:
    s = HeraldSettings()
    assert s.environment == "development"
    assert s.durability == "memory"
    assert s.sample_rate == 1.0
    assert s.safety_pass == "on"
    assert s.halt_on_audit_loss is True


def test_kwargs_override_defaults() -> None:
    s = HeraldSettings(
        backend="https://localhost:4317",
        service="my-agent",
        durability="files",
        durability_path="/tmp/herald",
        sample_rate=0.5,
    )
    assert s.backend == "https://localhost:4317"
    assert s.service == "my-agent"
    assert s.durability == "files"
    assert s.sample_rate == 0.5


def test_env_vars_picked_up(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HERALD_BACKEND", "https://from-env:4317")
    monkeypatch.setenv("HERALD_SERVICE", "from-env-service")
    monkeypatch.setenv("HERALD_SAMPLE_RATE", "0.25")
    s = HeraldSettings()
    assert s.backend == "https://from-env:4317"
    assert s.service == "from-env-service"
    assert s.sample_rate == 0.25


def test_kwargs_beat_env_vars(monkeypatch: pytest.MonkeyPatch) -> None:
    """Precedence: kwargs > env vars > defaults."""
    monkeypatch.setenv("HERALD_BACKEND", "https://env:4317")
    s = HeraldSettings(backend="https://kwargs:4317")
    assert s.backend == "https://kwargs:4317"


def test_invalid_durability_mode_raises() -> None:
    with pytest.raises(ValidationError):
        HeraldSettings(durability="badmode")  # type: ignore[arg-type]


def test_invalid_sample_rate_raises() -> None:
    with pytest.raises(ValidationError):
        HeraldSettings(sample_rate=2.0)
    with pytest.raises(ValidationError):
        HeraldSettings(sample_rate=-0.1)


def test_invalid_durability_max_bytes_raises() -> None:
    with pytest.raises(ValidationError):
        HeraldSettings(durability_max_bytes=0)
    with pytest.raises(ValidationError):
        HeraldSettings(durability_max_bytes=-1)


def test_settings_are_frozen() -> None:
    """Once constructed, settings cannot be mutated. This prevents
    configuration drift bugs after configure() returns."""
    s = HeraldSettings()
    with pytest.raises(ValidationError):
        s.environment = "production"  # type: ignore[misc]


def test_unknown_field_rejected() -> None:
    """extra='forbid' makes typo'd kwargs surface immediately."""
    with pytest.raises(ValidationError):
        HeraldSettings(typo_field="x")  # type: ignore[call-arg]


def test_configure_then_active_returns_same_settings() -> None:
    herald.configure(service="test-service", environment="staging")
    s = active()
    assert s.service == "test-service"
    assert s.environment == "staging"


def test_active_raises_before_configure() -> None:
    with pytest.raises(RuntimeError, match="configure"):
        active()
