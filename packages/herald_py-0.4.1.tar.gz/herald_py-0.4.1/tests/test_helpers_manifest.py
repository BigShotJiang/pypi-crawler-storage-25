"""ComponentManifest validation + load_manifest_toml."""

from __future__ import annotations

from pathlib import Path

import pytest
from pydantic import ValidationError

from herald._helpers.manifest import ComponentManifest, load_manifest_toml


def test_manifest_minimum_fields() -> None:
    manifest = ComponentManifest(name="otlp", description="OTLP exporter")
    assert manifest.name == "otlp"
    assert manifest.vendor == "Herald"
    assert manifest.version == "0.0.0"
    assert manifest.capabilities == ()


def test_manifest_rejects_empty_name() -> None:
    with pytest.raises(ValidationError):
        ComponentManifest(name="", description="x")


def test_manifest_rejects_unknown_field() -> None:
    """Pydantic extra='forbid' is what makes manifest.toml typos loud."""
    with pytest.raises(ValidationError):
        ComponentManifest(name="x", description="y", typo="z")  # type: ignore[call-arg]


def test_manifest_is_frozen() -> None:
    """Frozen manifests cannot be mutated after construction —
    important so a manifest cached at startup does not change later."""
    manifest = ComponentManifest(name="x", description="y")
    with pytest.raises(ValidationError):
        manifest.name = "z"  # type: ignore[misc]


def test_load_manifest_toml(tmp_path: Path) -> None:
    """Round-trip: write a TOML file, load it, get the same shape."""
    toml_text = '''
[component]
name = "test-sink"
description = "Test sink for unit tests"
vendor = "TestVendor"
version = "1.2.3"
capabilities = ["batch"]
'''
    toml_path = tmp_path / "manifest.toml"
    toml_path.write_text(toml_text, encoding="utf-8")

    manifest = load_manifest_toml(tmp_path)
    assert manifest.name == "test-sink"
    assert manifest.vendor == "TestVendor"
    assert manifest.version == "1.2.3"
    assert manifest.capabilities == ("batch",)


def test_load_manifest_toml_accepts_file_arg(tmp_path: Path) -> None:
    """Convenience: callers can pass __file__ from a component module."""
    (tmp_path / "manifest.toml").write_text(
        '[component]\nname="x"\ndescription="y"\n', encoding="utf-8"
    )
    fake_module_file = tmp_path / "__init__.py"
    fake_module_file.write_text("", encoding="utf-8")

    manifest = load_manifest_toml(fake_module_file)
    assert manifest.name == "x"


def test_load_manifest_missing_file_raises(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError, match=r"manifest\.toml"):
        load_manifest_toml(tmp_path)


def test_load_manifest_missing_component_table(tmp_path: Path) -> None:
    (tmp_path / "manifest.toml").write_text(
        "[other]\nfoo='bar'\n", encoding="utf-8"
    )
    with pytest.raises(ValueError, match=r"\[component\] table"):
        load_manifest_toml(tmp_path)
