"""Test isolation fixtures.

WHY this file exists: ContextVars persist across pytest tests within
one Python process unless explicitly reset. Tests that use
@herald.agent or @herald.tool push values onto _RUN_ID and _SPAN_STACK
that survive into the next test, breaking parent_span_id assertions.

The autouse fixture below resets both ContextVars at the start of
every test and restores them on teardown — so every test sees an
empty span stack and no run_id, regardless of what ran before it.
"""

from __future__ import annotations

from collections.abc import Iterator

import pytest

from herald._context import _RUN_ID, _SPAN_STACK
from herald._runtime import _set_active_runtime
from herald._settings import _reset_active_for_testing


@pytest.fixture(autouse=True)
def _reset_herald_state() -> Iterator[None]:
    """Clear runtime + ContextVars before and after every test.

    WHY both before and after: before guards against leaks from the
    previous test (especially important on the first test). After
    guards against leaks INTO subsequent tests if this test raises
    mid-block (the with-style ContextVar reset uses a token, not the
    set-and-reset pattern, so this is robust).
    """
    run_token = _RUN_ID.set(None)
    span_token = _SPAN_STACK.set(())
    _set_active_runtime(None)
    _reset_active_for_testing()
    try:
        yield
    finally:
        _RUN_ID.reset(run_token)
        _SPAN_STACK.reset(span_token)
        _set_active_runtime(None)
        _reset_active_for_testing()
