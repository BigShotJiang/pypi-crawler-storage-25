"""_HeraldRuntime composition root."""

from __future__ import annotations

import pytest

import herald
from herald._runtime import (
    NullChainWriter,
    NullExporter,
    PassThroughRedactor,
    StderrFailureSink,
    _build_runtime,
    _set_active_runtime,
    active_runtime,
)
from herald._settings import HeraldSettings, _reset_active_for_testing


def setup_function() -> None:
    _reset_active_for_testing()
    _set_active_runtime(None)


def teardown_function() -> None:
    _reset_active_for_testing()
    _set_active_runtime(None)


def test_active_runtime_raises_before_configure() -> None:
    with pytest.raises(RuntimeError, match="configure"):
        active_runtime()


def test_configure_installs_runtime() -> None:
    herald.configure(service="t1")
    rt = active_runtime()
    assert rt.settings.service == "t1"


def test_build_runtime_uses_placeholder_implementations() -> None:
    """M2 ships placeholder Null* impls for chain/redactor/exporter.
    M3-M6 swap them out one at a time."""
    rt = _build_runtime(HeraldSettings())
    assert isinstance(rt.chain_writer, NullChainWriter)
    assert isinstance(rt.redactor, PassThroughRedactor)
    assert isinstance(rt.exporter, NullExporter)
    assert isinstance(rt.failures, StderrFailureSink)


def test_emit_persists_event_to_pending_buffer() -> None:
    herald.configure()
    rt = active_runtime()
    rt.emit(kind="record", name="hello", attributes={"k": "v"})
    assert len(rt.buffer.events) == 1
    event = rt.buffer.events[0]
    assert event.kind == "record"
    assert event.name == "hello"
    assert event.attributes == {"k": "v"}


def test_emit_synthesizes_run_id_when_orphan() -> None:
    """A record() called outside any agent boundary still produces an
    event — with a fresh run_id. Better than silently dropping or
    failing."""
    herald.configure()
    rt = active_runtime()
    rt.emit(kind="record", name="orphan")
    assert len(rt.buffer.events) == 1
    assert rt.buffer.events[0].run_id  # not empty


def test_emit_with_audit_kind_uses_full_sync_mode() -> None:
    """Audit events go through the buffer with sync_mode=FULL — the
    durability promise. The placeholder buffer just records the mode
    on each row; M3 will actually fsync."""
    herald.configure()
    rt = active_runtime()
    rt.emit(kind="audit", name="critical", chain_kind="audit")
    # We check via the event's chain_kind since the placeholder buffer
    # does not surface sync_mode directly.
    assert rt.buffer.events[0].chain_kind == "audit"
