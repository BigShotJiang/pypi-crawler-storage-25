import os
import json
import uuid
import httpx
from mcp.server.fastmcp import FastMCP
from dotenv import load_dotenv

load_dotenv()

# Configuration
API_URL = os.getenv("EMERGENCE_API_URL", "https://api.emergence.science")

# Initialize FastMCP
mcp = FastMCP("Emergence Science")


def get_api_key() -> str:
    """Read API key at call-time so it picks up env vars set after module load."""
    key = os.getenv("EMERGENCE_API_KEY")
    if not key:
        raise ValueError(
            "EMERGENCE_API_KEY environment variable not set. "
            "Obtain your key at https://emergence.science."
        )
    return key


def get_headers() -> dict:
    return {
        "Authorization": f"Bearer {get_api_key()}",
        "Content-Type": "application/json",
    }


# ---------------------------------------------------------------------------
# Public tools (no auth required)
# ---------------------------------------------------------------------------

@mcp.tool()
async def list_bounties(status: str = "open", limit: int = 10, skip: int = 0) -> str:
    """
    List bounties on the Emergence Science marketplace.

    Args:
        status: Filter by status ('open', 'completed', 'expired').
        limit: Number of bounties to return (max 100).
        skip: Number of bounties to skip for pagination.
    """
    url = f"{API_URL}/bounties?status={status}&limit={limit}&skip={skip}"
    async with httpx.AsyncClient(timeout=15.0) as client:
        response = await client.get(url)
        if response.status_code == 200:
            return json.dumps(response.json(), indent=2)
        return f"Error {response.status_code}: {response.text}"


@mcp.tool()
async def get_bounty_details(bounty_id: str) -> str:
    """
    Get full details of a specific bounty, including evaluation criteria and template code.

    Args:
        bounty_id: The UUID of the bounty.
    """
    url = f"{API_URL}/bounties/{bounty_id}"
    async with httpx.AsyncClient(timeout=15.0) as client:
        response = await client.get(url)
        if response.status_code == 200:
            return json.dumps(response.json(), indent=2)
        return f"Error {response.status_code}: {response.text}"


# ---------------------------------------------------------------------------
# Authenticated tools (require EMERGENCE_API_KEY)
# ---------------------------------------------------------------------------

@mcp.tool()
async def create_bounty(
    title: str,
    description: str,
    micro_reward: int,
    solution_template: str = "",
    evaluation_spec: str = "",
) -> str:
    """
    Post a new bounty to the marketplace. Requires EMERGENCE_API_KEY.

    Args:
        title: Short title of the task (max ~100 chars).
        description: Detailed instructions and requirements for solvers.
        micro_reward: Reward in micro-credits (1,000,000 micro-credits = 1 Credit ≈ $1).
        solution_template: Optional code scaffold to help solvers get started.
        evaluation_spec: Pytest/unittest code used to automatically verify solutions.
    """
    try:
        headers = get_headers()
    except ValueError as e:
        return str(e)

    payload = {
        "title": title,
        "description": description,
        "micro_reward": micro_reward,
        "solution_template": solution_template,
        "evaluation_spec": evaluation_spec,
        "idempotency_key": str(uuid.uuid4()),
        "programming_language": "python3",
    }

    async with httpx.AsyncClient(timeout=15.0) as client:
        response = await client.post(url=f"{API_URL}/bounties", json=payload, headers=headers)
        if response.status_code in (200, 201):
            return f"Success! Bounty created:\n{json.dumps(response.json(), indent=2)}"
        return f"Error {response.status_code}: {response.text}"


@mcp.tool()
async def submit_solution(bounty_id: str, candidate_solution: str, commentary: str = "") -> str:
    """
    Submit a solution to an open bounty to earn credits. Requires EMERGENCE_API_KEY.

    Args:
        bounty_id: The UUID of the bounty you are solving.
        candidate_solution: Your Python code solution as a string.
        commentary: (Optional) Explanation of your approach for the evaluator.
    """
    try:
        headers = get_headers()
    except ValueError as e:
        return str(e)

    payload = {
        "candidate_solution": candidate_solution,
        "commentary": commentary,
        "idempotency_key": str(uuid.uuid4()),
    }

    async with httpx.AsyncClient(timeout=30.0) as client:
        response = await client.post(
            url=f"{API_URL}/bounties/{bounty_id}/submissions",
            json=payload,
            headers=headers,
        )
        if response.status_code in (200, 201):
            result = response.json()
            return f"Submission received. Status: {result.get('status')}\n{json.dumps(result, indent=2)}"
        return f"Error {response.status_code}: {response.text}"


@mcp.tool()
async def list_my_submissions() -> str:
    """
    List all submissions made by the authenticated user across all bounties.
    Requires EMERGENCE_API_KEY.
    """
    try:
        headers = get_headers()
    except ValueError as e:
        return str(e)

    async with httpx.AsyncClient(timeout=15.0) as client:
        response = await client.get(url=f"{API_URL}/bounties/submissions/me", headers=headers)
        if response.status_code == 200:
            return json.dumps(response.json(), indent=2)
        return f"Error {response.status_code}: {response.text}"


@mcp.tool()
async def get_bounty_solution(bounty_id: str) -> str:
    """
    Get the accepted solution code for a completed bounty.
    Only the bounty owner can view this. Requires EMERGENCE_API_KEY.

    Args:
        bounty_id: The UUID of the completed bounty.
    """
    try:
        headers = get_headers()
    except ValueError as e:
        return str(e)

    async with httpx.AsyncClient(timeout=15.0) as client:
        response = await client.get(url=f"{API_URL}/bounties/{bounty_id}/solution", headers=headers)
        if response.status_code == 200:
            return json.dumps(response.json(), indent=2)
        return f"Error {response.status_code}: {response.text}"


@mcp.tool()
async def get_balance() -> str:
    """
    Check the current credit balance of your account. Requires EMERGENCE_API_KEY.
    """
    try:
        headers = get_headers()
    except ValueError as e:
        return str(e)

    async with httpx.AsyncClient(timeout=15.0) as client:
        response = await client.get(url=f"{API_URL}/accounts/balance", headers=headers)
        if response.status_code == 200:
            balance = response.json()
            credits = balance.get("credits", "N/A")
            micro = balance.get("micro_credits", "N/A")
            return f"Balance: {credits} credits ({micro} micro-credits)"
        return f"Error {response.status_code}: {response.text}"


@mcp.tool()
async def list_transactions(limit: int = 10, skip: int = 0) -> str:
    """
    List your transaction history (credits earned, fees paid, etc.).
    Requires EMERGENCE_API_KEY.

    Args:
        limit: Max number of results to return.
        skip: Pagination offset.
    """
    try:
        headers = get_headers()
    except ValueError as e:
        return str(e)

    async with httpx.AsyncClient(timeout=15.0) as client:
        response = await client.get(
            url=f"{API_URL}/accounts/transactions?limit={limit}&skip={skip}",
            headers=headers,
        )
        if response.status_code == 200:
            return json.dumps(response.json(), indent=2)
        return f"Error {response.status_code}: {response.text}"


@mcp.tool()
async def render_diagram(engine: str, code: str, format: str = "png", theme: str = "dark") -> str:
    """
    Generate a diagram using the Emergence Rendering Service. Requires EMERGENCE_API_KEY.
    Useful for visualizing architectures, data flows, or entity relationships.

    Args:
        engine: Rendering engine — one of: mermaid, d2, graphviz, tikz, plantuml.
        code: The diagram source code string.
        format: Output format — one of: png, svg, pdf. Defaults to 'png'.
        theme: Color theme — 'light' or 'dark'. Defaults to 'dark'.
    """
    try:
        headers = get_headers()
    except ValueError as e:
        return str(e)

    payload = {"engine": engine, "code": code, "format": format, "theme": theme}

    async with httpx.AsyncClient(timeout=60.0) as client:
        response = await client.post(url=f"{API_URL}/tools/render", json=payload, headers=headers)
        if response.status_code == 200:
            result = response.json()
            billing = result.get("billing", {})
            image_b64 = result.get("data", {}).get("image_base64", "")
            return (
                f"Rendering successful!\n"
                f"Engine: {engine} | Format: {format}\n"
                f"Cost: {billing.get('cost')} credits | Remaining: {billing.get('remaining_credit')} credits\n\n"
                f"Base64 Image Data:\n{image_b64}"
            )
        # Safely handle non-JSON error responses
        try:
            detail = response.json().get("detail", response.text)
        except Exception:
            detail = response.text
        return f"Error {response.status_code}: {detail}"


def main():
    mcp.run()


if __name__ == "__main__":
    main()
