from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Callable, Dict, Optional, Sequence, Tuple

import torch


@dataclass(frozen=True)
class FunctionMeta:
    name: str
    dim: int
    bounds: Sequence[Tuple[float, float]]
    category: Optional[str] = None
    global_minimum: Optional[float] = None
    note: Optional[str] = None
    source_url: Optional[str] = None


class TorchBenchmark(ABC):
    """
    Base class for differentiable benchmark functions.

    Conventions
    -----------
    - input x: shape (dim,)
    - output: scalar tensor, shape ()
    - all computations must use torch ops only
    """

    def __init__(
            self,
            dim: int,
            bounds: Sequence[Tuple[float, float]] | Tuple[float, float],
            *,
            name: str,
            category: Optional[str] = None,
            global_minimum: Optional[float] = None,
            note: Optional[str] = None,
            source_url: Optional[str] = None,
            device: Optional[torch.device] = None,
            dtype: torch.dtype = torch.float64,
    ) -> None:
        if dim <= 0:
            raise ValueError("dim must be positive")

        if isinstance(bounds, tuple) and len(bounds) == 2:
            bounds = [bounds] * dim
        if len(bounds) != dim:
            raise ValueError("bounds length must equal dim")

        self.meta = FunctionMeta(
            name=name,
            dim=dim,
            bounds=tuple(bounds),
            category=category,
            global_minimum=global_minimum,
            note=note,
            source_url=source_url,
        )
        self.device = device
        self.dtype = dtype

    @property
    def dim(self) -> int:
        return self.meta.dim

    def _as_x(self, x: torch.Tensor) -> torch.Tensor:
        x = torch.as_tensor(x, device=self.device, dtype=self.dtype)
        if x.ndim != 1 or x.numel() != self.dim:
            raise ValueError(f"{self.meta.name} expects x.shape == ({self.dim},)")
        return x

    @abstractmethod
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Return scalar tensor f(x)."""
        raise NotImplementedError

    def __call__(self, x: torch.Tensor) -> torch.Tensor:
        x = self._as_x(x)
        y = self.forward(x)
        if y.ndim != 0:
            raise ValueError("forward must return a scalar tensor")
        return y

    # ---------- first-order ----------
    def grad(self, x: torch.Tensor, create_graph: bool = False) -> torch.Tensor:
        """
        Default gradient via autograd.
        Override this if an analytic gradient is cheap and important.
        """
        x = self._as_x(x).detach().clone().requires_grad_(True)
        y = self.forward(x)
        (g,) = torch.autograd.grad(y, x, create_graph=create_graph)
        return g

    def value_and_grad(
            self, x: torch.Tensor, create_graph: bool = False
    ) -> tuple[torch.Tensor, torch.Tensor]:
        x = self._as_x(x).detach().clone().requires_grad_(True)
        y = self.forward(x)
        (g,) = torch.autograd.grad(y, x, create_graph=create_graph)
        return y, g

    # ---------- second-order ----------
    def hessian(self, x: torch.Tensor) -> torch.Tensor:
        """
        Default Hessian via torch.func.hessian.
        """
        x = self._as_x(x)

        def f(inp: torch.Tensor) -> torch.Tensor:
            return self.forward(inp)

        return torch.func.hessian(f)(x)

    def hvp(self, x: torch.Tensor, v: torch.Tensor) -> torch.Tensor:
        """
        Hessian-vector product.
        Usually preferable to forming dense Hessian for larger dim.
        """
        x = self._as_x(x)
        v = torch.as_tensor(v, device=x.device, dtype=x.dtype)
        if v.shape != x.shape:
            raise ValueError("v must have the same shape as x")

        def f(inp: torch.Tensor) -> torch.Tensor:
            return self.forward(inp)

        _, hv = torch.autograd.functional.hvp(f, x, v)
        return hv

    # ---------- utilities ----------
    def sample(
            self,
            n: int = 1,
            *,
            device: Optional[torch.device] = None,
            dtype: Optional[torch.dtype] = None,
            generator: Optional[torch.Generator] = None,
    ) -> torch.Tensor:
        device = device or self.device
        dtype = dtype or self.dtype

        cols = []
        for lo, hi in self.meta.bounds:
            u = torch.rand(n, device=device, dtype=dtype, generator=generator)
            cols.append(lo + (hi - lo) * u)
        return torch.stack(cols, dim=1)

    def project_to_bounds(self, x: torch.Tensor) -> torch.Tensor:
        x = self._as_x(x)
        lows = torch.tensor([b[0] for b in self.meta.bounds], device=x.device, dtype=x.dtype)
        highs = torch.tensor([b[1] for b in self.meta.bounds], device=x.device, dtype=x.dtype)
        return torch.clamp(x, lows, highs)

class BenchmarkRegistry:
    _builders: Dict[str, Callable[..., TorchBenchmark]] = {}

    @classmethod
    def register(cls, *names: str):
        def deco(builder: Callable[..., TorchBenchmark]):
            for name in names:
                key = cls._norm(name)
                if key in cls._builders:
                    raise KeyError(f"Duplicate registration: {name}")
                cls._builders[key] = builder
            return builder
        return deco

    @classmethod
    def create(cls, name: str, **kwargs) -> TorchBenchmark:
        key = cls._norm(name)
        if key not in cls._builders:
            raise KeyError(f"Unknown benchmark: {name}")
        return cls._builders[key](**kwargs)

    @classmethod
    def available(cls) -> list[str]:
        return sorted(cls._builders.keys())

    @staticmethod
    def _norm(name: str) -> str:
        return (
            name.lower()
            .replace("_", "")
            .replace("-", "")
            .replace(" ", "")
        )


# Import benchmarks for their registration side effects.
from . import func as _func  # noqa: F401,E402
