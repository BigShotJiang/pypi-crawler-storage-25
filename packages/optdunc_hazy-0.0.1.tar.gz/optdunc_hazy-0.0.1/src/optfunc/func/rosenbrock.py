from typing import Optional

import torch

from ..functional import BenchmarkRegistry, TorchBenchmark


@BenchmarkRegistry.register("rosenbrock")
class Rosenbrock(TorchBenchmark):
    def __init__(
            self,
            dim: int = 2,
            *,
            device: Optional[torch.device] = None,
            dtype: torch.dtype = torch.float64,
    ) -> None:
        if dim < 2:
            raise ValueError("Rosenbrock expects dim >= 2")

        super().__init__(
            dim=dim,
            bounds=(-5.0, 10.0),
            name="Rosenbrock",
            category="Valley-Shaped",
            global_minimum=0.0,
            note="Global minimizer at x_i = 1 for all i.",
            source_url="https://www.sfu.ca/~ssurjano/rosen.html",
            device=device,
            dtype=dtype,
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self._as_x(x)
        return torch.sum(100.0 * (x[1:] - x[:-1] ** 2) ** 2 + (x[:-1] - 1.0) ** 2)
