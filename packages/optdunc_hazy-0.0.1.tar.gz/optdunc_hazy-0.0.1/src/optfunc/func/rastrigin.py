import math
from typing import Optional

import torch

from ..functional import BenchmarkRegistry, TorchBenchmark


@BenchmarkRegistry.register("rastrigin")
class Rastrigin(TorchBenchmark):
    def __init__(
            self,
            dim: int = 2,
            *,
            a: float = 10.0,
            device: Optional[torch.device] = None,
            dtype: torch.dtype = torch.float64,
    ) -> None:
        super().__init__(
            dim=dim,
            bounds=(-5.12, 5.12),
            name="Rastrigin",
            category="Many Local Minima",
            global_minimum=0.0,
            note="Global minimizer at x_i = 0 for all i.",
            source_url="https://www.sfu.ca/~ssurjano/rastr.html",
            device=device,
            dtype=dtype,
        )
        self.a = a

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self._as_x(x)
        return self.a * self.dim + torch.sum(x ** 2 - self.a * torch.cos(2.0 * math.pi * x))
