from typing import Optional

import torch

from ..functional import BenchmarkRegistry, TorchBenchmark


@BenchmarkRegistry.register("dixonprice")
class DixonPrice(TorchBenchmark):
    def __init__(
            self,
            dim: int = 2,
            *,
            device: Optional[torch.device] = None,
            dtype: torch.dtype = torch.float64,
    ) -> None:
        super().__init__(
            dim=dim,
            bounds=(-10.0, 10.0),
            name="Dixon-Price",
            category="Valley-Shaped",
            global_minimum=0.0,
            note="Global minimizer starts at x_1 = 1 and follows the standard recursive Dixon-Price optimum.",
            source_url="https://www.sfu.ca/~ssurjano/dixonpr.html",
            device=device,
            dtype=dtype,
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self._as_x(x)
        value = (x[0] - 1.0) ** 2
        if self.dim == 1:
            return value

        idx = torch.arange(2, self.dim + 1, device=x.device, dtype=x.dtype)
        return value + torch.sum(idx * (2.0 * x[1:] ** 2 - x[:-1]) ** 2)
