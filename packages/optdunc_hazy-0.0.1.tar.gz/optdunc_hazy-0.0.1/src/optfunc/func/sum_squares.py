from typing import Optional

import torch

from ..functional import BenchmarkRegistry, TorchBenchmark


@BenchmarkRegistry.register("sumsquares")
class SumSquares(TorchBenchmark):
    def __init__(
            self,
            dim: int = 2,
            *,
            device: Optional[torch.device] = None,
            dtype: torch.dtype = torch.float64,
    ) -> None:
        super().__init__(
            dim=dim,
            bounds=(-10.0, 10.0),
            name="Sum Squares",
            category="Bowl-Shaped",
            global_minimum=0.0,
            note="Also called the Axis Parallel Hyper-Ellipsoid; minimizer at x_i = 0 for all i.",
            source_url="https://www.sfu.ca/~ssurjano/sumsqu.html",
            device=device,
            dtype=dtype,
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self._as_x(x)
        idx = torch.arange(1, self.dim + 1, device=x.device, dtype=x.dtype)
        return torch.sum(idx * x ** 2)
