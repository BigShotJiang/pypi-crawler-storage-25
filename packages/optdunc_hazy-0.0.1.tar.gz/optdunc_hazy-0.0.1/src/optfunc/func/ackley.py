# -*- coding: utf-8 -*-
r"""
@File    : src\func\ackley.py
@Time    : 2026-4-17 下午 2:06
@Author  : hazy
@Desc    : 

-----
https://www.sfu.ca/~ssurjano/ackley.html

"""

import math
from typing import Optional

import torch

from ..functional import BenchmarkRegistry, TorchBenchmark


@BenchmarkRegistry.register("ackley")
class Ackley(TorchBenchmark):
    def __init__(
            self,
            dim: int = 2,
            *,
            a: float = 20.0,
            b: float = 0.2,
            c: float = 2 * math.pi,
            device: Optional[torch.device] = None,
            dtype: torch.dtype = torch.float64,
    ) -> None:
        super().__init__(
            dim=dim,
            bounds=(-32.768, 32.768),
            name="Ackley",
            category="Many Local Minima",
            global_minimum=0.0,
            note="Global minimizer at x_i = 0 for all i.",
            source_url="https://www.sfu.ca/~ssurjano/ackley.html",
            device=device,
            dtype=dtype,
        )
        self.a = a
        self.b = b
        self.c = c

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self._as_x(x)
        mean_sq = torch.mean(x**2)
        mean_cos = torch.mean(torch.cos(self.c * x))
        term1 = -self.a * torch.exp(-self.b * torch.sqrt(mean_sq))
        term2 = -torch.exp(mean_cos)
        return term1 + term2 + self.a + math.e
