from typing import Optional

import torch

from ..functional import BenchmarkRegistry, TorchBenchmark


@BenchmarkRegistry.register("sphere")
class Sphere(TorchBenchmark):
    def __init__(
            self,
            dim: int = 2,
            *,
            device: Optional[torch.device] = None,
            dtype: torch.dtype = torch.float64,
    ) -> None:
        super().__init__(
            dim=dim,
            bounds=(-5.12, 5.12),
            name="Sphere",
            category="Bowl-Shaped",
            global_minimum=0.0,
            note="Global minimizer at x_i = 0 for all i.",
            source_url="https://www.sfu.ca/~ssurjano/spheref.html",
            device=device,
            dtype=dtype,
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self._as_x(x)
        return torch.sum(x ** 2)
