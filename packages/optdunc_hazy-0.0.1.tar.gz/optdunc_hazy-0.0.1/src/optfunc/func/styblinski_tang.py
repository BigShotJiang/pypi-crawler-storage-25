from typing import Optional

import torch

from ..functional import BenchmarkRegistry, TorchBenchmark


@BenchmarkRegistry.register("styblinskitang")
class StyblinskiTang(TorchBenchmark):
    def __init__(
            self,
            dim: int = 2,
            *,
            device: Optional[torch.device] = None,
            dtype: torch.dtype = torch.float64,
    ) -> None:
        super().__init__(
            dim=dim,
            bounds=(-5.0, 5.0),
            name="Styblinski-Tang",
            category="Other",
            global_minimum=-39.16599 * dim,
            note="Global minimizer near x_i = -2.903534 for all i.",
            source_url="https://www.sfu.ca/~ssurjano/stybtang.html",
            device=device,
            dtype=dtype,
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self._as_x(x)
        return 0.5 * torch.sum(x ** 4 - 16.0 * x ** 2 + 5.0 * x)
