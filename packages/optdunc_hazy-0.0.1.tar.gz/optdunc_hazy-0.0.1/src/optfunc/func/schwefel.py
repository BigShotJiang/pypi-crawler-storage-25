from typing import Optional

import torch

from ..functional import BenchmarkRegistry, TorchBenchmark


@BenchmarkRegistry.register("schwefel")
class Schwefel(TorchBenchmark):
    def __init__(
            self,
            dim: int = 2,
            *,
            bias: float = 418.9828872724338,
            device: Optional[torch.device] = None,
            dtype: torch.dtype = torch.float64,
    ) -> None:
        super().__init__(
            dim=dim,
            bounds=(-500.0, 500.0),
            name="Schwefel",
            category="Many Local Minima",
            global_minimum=0.0,
            note="Global minimizer near x_i = 420.968746 for all i.",
            source_url="https://www.sfu.ca/~ssurjano/schwef.html",
            device=device,
            dtype=dtype,
        )
        self.bias = bias

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self._as_x(x)
        return self.bias * self.dim - torch.sum(x * torch.sin(torch.sqrt(torch.abs(x))))
