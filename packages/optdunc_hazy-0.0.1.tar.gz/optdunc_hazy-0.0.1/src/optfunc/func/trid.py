from typing import Optional

import torch

from ..functional import BenchmarkRegistry, TorchBenchmark


@BenchmarkRegistry.register("trid")
class Trid(TorchBenchmark):
    def __init__(
            self,
            dim: int = 2,
            *,
            device: Optional[torch.device] = None,
            dtype: torch.dtype = torch.float64,
    ) -> None:
        bound = float(dim ** 2)
        global_minimum = -dim * (dim + 4) * (dim - 1) / 6.0
        super().__init__(
            dim=dim,
            bounds=(-bound, bound),
            name="Trid",
            category="Bowl-Shaped",
            global_minimum=global_minimum,
            note="Global minimizer is x_i = i * (d + 1 - i) in 1-based indexing.",
            source_url="https://www.sfu.ca/~ssurjano/trid.html",
            device=device,
            dtype=dtype,
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self._as_x(x)
        return torch.sum((x - 1.0) ** 2) - torch.sum(x[1:] * x[:-1])
