from typing import Optional

import torch

from ..functional import BenchmarkRegistry, TorchBenchmark


@BenchmarkRegistry.register("griewank")
class Griewank(TorchBenchmark):
    def __init__(
            self,
            dim: int = 2,
            *,
            device: Optional[torch.device] = None,
            dtype: torch.dtype = torch.float64,
    ) -> None:
        super().__init__(
            dim=dim,
            bounds=(-600.0, 600.0),
            name="Griewank",
            category="Many Local Minima",
            global_minimum=0.0,
            note="Global minimizer at x_i = 0 for all i.",
            source_url="https://www.sfu.ca/~ssurjano/griewank.html",
            device=device,
            dtype=dtype,
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self._as_x(x)
        idx = torch.arange(1, self.dim + 1, device=x.device, dtype=x.dtype)
        sum_term = torch.sum(x ** 2) / 4000.0
        prod_term = torch.prod(torch.cos(x / torch.sqrt(idx)))
        return 1.0 + sum_term - prod_term
