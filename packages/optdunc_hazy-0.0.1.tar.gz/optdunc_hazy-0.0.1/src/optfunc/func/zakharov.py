from typing import Optional

import torch

from ..functional import BenchmarkRegistry, TorchBenchmark


@BenchmarkRegistry.register("zakharov")
class Zakharov(TorchBenchmark):
    def __init__(
            self,
            dim: int = 2,
            *,
            device: Optional[torch.device] = None,
            dtype: torch.dtype = torch.float64,
    ) -> None:
        super().__init__(
            dim=dim,
            bounds=(-5.0, 10.0),
            name="Zakharov",
            category="Plate-Shaped",
            global_minimum=0.0,
            note="Global minimizer at x_i = 0 for all i.",
            source_url="https://www.sfu.ca/~ssurjano/zakharov.html",
            device=device,
            dtype=dtype,
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self._as_x(x)
        idx = torch.arange(1, self.dim + 1, device=x.device, dtype=x.dtype)
        linear_term = 0.5 * torch.sum(idx * x)
        return torch.sum(x ** 2) + linear_term ** 2 + linear_term ** 4
