import math
from typing import Optional

import torch

from ..functional import BenchmarkRegistry, TorchBenchmark


@BenchmarkRegistry.register("levy")
class Levy(TorchBenchmark):
    def __init__(
            self,
            dim: int = 2,
            *,
            device: Optional[torch.device] = None,
            dtype: torch.dtype = torch.float64,
    ) -> None:
        super().__init__(
            dim=dim,
            bounds=(-10.0, 10.0),
            name="Levy",
            category="Many Local Minima",
            global_minimum=0.0,
            note="Global minimizer at x_i = 1 for all i.",
            source_url="https://www.sfu.ca/~ssurjano/levy.html",
            device=device,
            dtype=dtype,
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self._as_x(x)
        w = 1.0 + (x - 1.0) / 4.0

        term1 = torch.sin(math.pi * w[0]) ** 2
        term3 = (w[-1] - 1.0) ** 2 * (1.0 + torch.sin(2.0 * math.pi * w[-1]) ** 2)

        if self.dim == 1:
            return term1 + term3

        wi = w[:-1]
        term2 = torch.sum((wi - 1.0) ** 2 * (1.0 + 10.0 * torch.sin(math.pi * wi + 1.0) ** 2))
        return term1 + term2 + term3
