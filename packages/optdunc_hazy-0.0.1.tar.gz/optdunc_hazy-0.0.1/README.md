# optfunc

`optfunc` provides differentiable benchmark functions for unconstrained
optimization experiments, along with pytest-oriented checks you can reuse when
validating an optimizer against known global minima.

## Install

```bash
pip install "optdunc-hazy[torch-cpu]"
```

Then import it with:

```python
import optfunc
```

## Local development

```bash
uv build --no-sources
uv run pytest
```

## Release flow

1. Update the package version in `pyproject.toml`, or run `uv version <version> --frozen`.
2. Create and push a Git tag named `v<version>`.
3. CNB will publish that tag to PyPI through the `tag_push` pipeline.

Benchmark definitions are adapted from [SFU's optimization benchmark
collection](https://www.sfu.ca/~ssurjano/optimization.html).
