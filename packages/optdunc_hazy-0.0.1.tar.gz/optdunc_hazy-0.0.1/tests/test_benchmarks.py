import math
from collections.abc import Callable

import pytest

torch = pytest.importorskip("torch")

from optfunc.functional import BenchmarkRegistry


def _zeros(dim: int) -> torch.Tensor:
    return torch.zeros(dim, dtype=torch.float64)


def _ones(dim: int) -> torch.Tensor:
    return torch.ones(dim, dtype=torch.float64)


def _dixon_price_minimizer(dim: int) -> torch.Tensor:
    x = torch.empty(dim, dtype=torch.float64)
    x[0] = 1.0
    for i in range(1, dim):
        x[i] = torch.sqrt(x[i - 1] / 2.0)
    return x


def _trid_minimizer(dim: int) -> torch.Tensor:
    idx = torch.arange(1, dim + 1, dtype=torch.float64)
    return idx * (dim + 1 - idx)


def _schwefel_minimizer(dim: int) -> torch.Tensor:
    return torch.full((dim,), 420.9687462275036, dtype=torch.float64)


def _styblinski_tang_minimizer(dim: int) -> torch.Tensor:
    return torch.full((dim,), -2.903534, dtype=torch.float64)


KNOWN_MINIMA_CASES = [
    ("ackley", 5, _zeros, 1e-10, None),
    ("dixonprice", 5, _dixon_price_minimizer, 1e-10, 1e-6),
    ("griewank", 6, _zeros, 1e-12, 1e-8),
    ("levy", 5, _ones, 1e-10, 1e-6),
    ("rastrigin", 6, _zeros, 1e-10, 1e-6),
    ("rosenbrock", 5, _ones, 1e-10, 1e-6),
    ("rotatedhyperellipsoid", 6, _zeros, 1e-12, 1e-8),
    ("schwefel", 4, _schwefel_minimizer, 1e-5, None),
    ("sphere", 8, _zeros, 1e-12, 1e-8),
    ("styblinskitang", 5, _styblinski_tang_minimizer, 2e-3, None),
    ("sumsquares", 8, _zeros, 1e-12, 1e-8),
    ("trid", 6, _trid_minimizer, 1e-10, 1e-6),
    ("zakharov", 7, _zeros, 1e-12, 1e-8),
]


OPTIMIZER_SMOKE_CASES = [
    ("sphere", 8, _zeros, 0.75, 0.05, 250, 1e-6, 2e-3),
    ("sumsquares", 8, _zeros, 0.75, 0.05, 300, 1e-6, 2e-3),
    ("rotatedhyperellipsoid", 6, _zeros, 0.75, 0.05, 350, 1e-5, 2e-3),
    ("zakharov", 6, _zeros, 0.50, 0.04, 400, 1e-6, 2e-3),
    ("rosenbrock", 4, _ones, 0.25, 0.02, 1200, 5e-4, 5e-2),
]


def _make_nearby_start(name: str, dim: int, point_fn: Callable[[int], torch.Tensor], amplitude: float) -> torch.Tensor:
    x_star = point_fn(dim)
    offsets = torch.linspace(-amplitude, amplitude, dim, dtype=torch.float64)
    if name == "rosenbrock":
        offsets = torch.full((dim,), amplitude, dtype=torch.float64)
    return x_star + offsets


def _run_adam(
        benchmark,
        x0: torch.Tensor,
        *,
        lr: float,
        steps: int,
) -> tuple[torch.Tensor, float, float]:
    x = x0.clone().detach().requires_grad_(True)
    optimizer = torch.optim.Adam([x], lr=lr)

    initial_value = benchmark(x.detach()).item()
    for _ in range(steps):
        optimizer.zero_grad()
        loss = benchmark(x)
        loss.backward()
        optimizer.step()
        with torch.no_grad():
            x.copy_(benchmark.project_to_bounds(x.detach()))

    final_x = x.detach().clone()
    final_value = benchmark(final_x).item()
    return final_x, initial_value, final_value


def test_registry_contains_new_multidimensional_benchmarks() -> None:
    available = set(BenchmarkRegistry.available())
    expected = {
        "ackley",
        "dixonprice",
        "griewank",
        "levy",
        "rastrigin",
        "rosenbrock",
        "rotatedhyperellipsoid",
        "schwefel",
        "sphere",
        "styblinskitang",
        "sumsquares",
        "trid",
        "zakharov",
    }
    assert expected.issubset(available)


@pytest.mark.parametrize(
    ("name", "dim", "point_fn", "value_tol", "grad_tol"),
    KNOWN_MINIMA_CASES,
)
def test_known_global_minimizers(
        name: str,
        dim: int,
        point_fn: Callable[[int], torch.Tensor],
        value_tol: float,
        grad_tol: float | None,
) -> None:
    benchmark = BenchmarkRegistry.create(name, dim=dim)
    x_star = point_fn(dim)
    value = benchmark(x_star)

    assert benchmark.meta.source_url
    assert benchmark.meta.note
    assert torch.isfinite(value)
    assert value.item() == pytest.approx(benchmark.meta.global_minimum, abs=value_tol)

    if grad_tol is not None:
        grad = benchmark.grad(x_star)
        grad_norm = torch.linalg.vector_norm(grad).item()
        assert math.isfinite(grad_norm)
        assert grad_norm == pytest.approx(0.0, abs=grad_tol)


@pytest.mark.parametrize(
    ("name", "dim", "point_fn", "amplitude", "lr", "steps", "value_tol", "x_tol"),
    OPTIMIZER_SMOKE_CASES,
)
def test_adam_can_refine_nearby_point(
        name: str,
        dim: int,
        point_fn: Callable[[int], torch.Tensor],
        amplitude: float,
        lr: float,
        steps: int,
        value_tol: float,
        x_tol: float,
) -> None:
    # This is a smoke test for autograd wiring and basic local descent,
    # not a proof that Adam can globally solve every benchmark.
    benchmark = BenchmarkRegistry.create(name, dim=dim)
    x_star = point_fn(dim)
    x0 = _make_nearby_start(name, dim, point_fn, amplitude)
    x0 = benchmark.project_to_bounds(x0)

    final_x, initial_value, final_value = _run_adam(benchmark, x0, lr=lr, steps=steps)

    assert final_value < initial_value
    assert final_value == pytest.approx(benchmark.meta.global_minimum, abs=value_tol)
    assert torch.max(torch.abs(final_x - x_star)).item() < x_tol
