#!/usr/bin/env python3

from setuptools import setup, find_packages


setup(name='python_misc_utils',
      version='0.24',
      description='A collection of Python utility APIs',
      author='Davide Libenzi',
      packages=find_packages(),
      package_data={
          'py_misc_utils': [
              # Paths from py_misc_utils/ subfolder ...
          ],
      },
      include_package_data=True,
      install_requires=[
          'numpy',
          'pandas',
          'psutil',
          'pyyaml',
      ],
      extras_require={
          'fs': [
              'boto3',
              'bs4',
              'ftputil',
              'google-cloud-storage',
              'pyarrow',
          ],
      },
      )

