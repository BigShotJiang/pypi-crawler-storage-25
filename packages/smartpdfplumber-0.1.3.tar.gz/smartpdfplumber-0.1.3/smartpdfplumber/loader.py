import pathlib
from io import BufferedReader, BytesIO
from typing import Union
from langchain_community.document_loaders.blob_loaders import Blob
from smartpdfplumber.parser.pdf_parser import PDFPlumberParser

class SmartPDFLoader:
    def __init__(self, path_or_fp: Union[str, pathlib.Path, BufferedReader, BytesIO], **parser_kwargs):
        self.path_or_fp = path_or_fp
        self.parser = PDFPlumberParser(**parser_kwargs)

    def load(self):
        if isinstance(self.path_or_fp, (str, pathlib.Path)):
            blob = Blob.from_path(str(self.path_or_fp))
        else:
            blob = Blob.from_data(self.path_or_fp.read())
        return list(self.parser.lazy_parse(blob))