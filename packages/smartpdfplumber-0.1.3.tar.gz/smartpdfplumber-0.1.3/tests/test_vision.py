from smartpdfplumber.vision.image_analyzer import ImageAnalyzer
from dotenv import load_dotenv

def test_image_analyzer():
    load_dotenv()
    images = [
        "assets/images/Im5.png",
        # "assets/images/Im6.png",
    ]

    for image in images:
        analyzer = ImageAnalyzer(image=image, inference="groq_ai")
        print(analyzer.analyze_image())