"""Tests for doc-quality. Run: pytest tests/ -v"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from doc_quality import (
    CorpusProfiler,
    DataCard,
    DocumentProfile,
    DocumentProfiler,
    IssueType,
    QualityLevel,
    deduplicate,
    find_duplicates,
)
from doc_quality.scorer import (
    compute_quality_score,
    score_boilerplate,
    score_chunk_risk,
    score_encoding,
    score_sentence_quality,
    score_table_integrity,
    score_text_density,
    score_uniqueness,
)

# ── Sample texts ───────────────────────────────────────────────

CLEAN_TEXT = """
Retrieval-Augmented Generation (RAG) is a technique that grounds LLM outputs in retrieved documents.
The system retrieves relevant passages from a knowledge base, then uses those passages as context
for the language model to generate an accurate, factual response.

Chunking strategy significantly affects retrieval quality. Research shows that recursive chunking
preserves more semantic coherence than fixed-size splitting. The choice of strategy should be
informed by document structure and query patterns.

This approach reduces hallucination by anchoring responses to source material.
It is especially useful for domain-specific applications where accuracy is critical.
""".strip() * 3

BOILERPLATE_TEXT = """
CONFIDENTIAL NOTICE. All rights reserved. Copyright 2026.
This document is for internal use only. Unauthorised use prohibited.
Page 1 of 1. Tel: 020 7123 4567. Email: info@example.com.
Privacy policy applies. Cookie policy in effect. Disclaimer.

CONFIDENTIAL NOTICE. All rights reserved. Copyright 2026.
This document is for internal use only. Unauthorised use prohibited.
""".strip()

ENCODING_GARBAGE = (
    "Hello \ufffd\ufffd\ufffd world \ufffd\ufffd test \ufffd\ufffd\ufffd\ufffd content here"
)

REPETITIVE_TEXT = "\n".join(["This exact line appears many times in the document."] * 30)

SHORT_TEXT = "Hi."

TABLE_TEXT = """
Summary of results:

| Model       | Recall | Precision | F1    |
|-------------|--------|-----------|-------|
| Recursive   | 0.857  | 0.733     | 0.790 |
| Paragraph   | 0.810  | 0.700     | 0.752 |
| Fixed       | 0.762  | 0.667     | 0.711 |

All models were evaluated on the same corpus.
""".strip()

NEAR_DUPLICATE_A = "The UK government published a new AI strategy in April 2026 focusing on safety."
NEAR_DUPLICATE_B = (
    "The UK government published a new AI strategy in April 2026 focusing on safety and innovation."
)


# ── Scorer tests ───────────────────────────────────────────────


class TestEncodingScorer:
    def test_clean_text_high_score(self):
        score, issues = score_encoding(CLEAN_TEXT)
        assert score > 0.9
        assert len(issues) == 0

    def test_garbage_text_low_score(self):
        score, issues = score_encoding(ENCODING_GARBAGE)
        assert score < 0.9
        assert len(issues) > 0

    def test_replacement_chars_flagged(self):
        _, issues = score_encoding("Normal \ufffd\ufffd\ufffd text")
        assert any(i.issue_type == IssueType.ENCODING_ARTIFACTS for i in issues)

    def test_empty_text(self):
        score, issues = score_encoding("")
        assert score == 1.0
        assert len(issues) == 0

    def test_score_range(self):
        score, _ = score_encoding(CLEAN_TEXT)
        assert 0.0 <= score <= 1.0


class TestTextDensityScorer:
    def test_clean_text_high_density(self):
        score, issues = score_text_density(CLEAN_TEXT)
        assert score > 0.5
        assert len(issues) == 0

    def test_empty_text_fails(self):
        _, issues = score_text_density("")
        assert any(i.issue_type == IssueType.LOW_TEXT_DENSITY for i in issues)

    def test_score_range(self):
        score, _ = score_text_density(CLEAN_TEXT)
        assert 0.0 <= score <= 1.0


class TestBoilerplateScorer:
    def test_clean_text_low_boilerplate(self):
        _, ratio, issues = score_boilerplate(CLEAN_TEXT)
        assert ratio < 0.15

    def test_boilerplate_text_detected(self):
        _, ratio, issues = score_boilerplate(BOILERPLATE_TEXT)
        assert ratio > 0.15
        assert any(i.issue_type == IssueType.HIGH_BOILERPLATE for i in issues)

    def test_ratio_range(self):
        _, ratio, _ = score_boilerplate(CLEAN_TEXT)
        assert 0.0 <= ratio <= 1.0

    def test_score_range(self):
        score, _, _ = score_boilerplate(CLEAN_TEXT)
        assert 0.0 <= score <= 1.0


class TestUniquenessScorer:
    def test_unique_text_high_score(self):
        # CLEAN_TEXT is tripled so uniqueness is ~57% -- use a single-copy text
        single = CLEAN_TEXT[: len(CLEAN_TEXT) // 3]
        score, ratio, issues = score_uniqueness(single)
        assert ratio > 0.7
        assert len(issues) == 0

    def test_repetitive_text_detected(self):
        _, ratio, issues = score_uniqueness(REPETITIVE_TEXT)
        assert ratio < 0.5
        assert any(i.issue_type == IssueType.REPETITIVE_CONTENT for i in issues)

    def test_ratio_range(self):
        _, ratio, _ = score_uniqueness(CLEAN_TEXT)
        assert 0.0 <= ratio <= 1.0

    def test_short_text_no_issues(self):
        _, _, issues = score_uniqueness("Hello world")
        assert len(issues) == 0


class TestSentenceScorer:
    def test_clean_text_has_sentences(self):
        _, count, _ = score_sentence_quality(CLEAN_TEXT)
        assert count >= 1

    def test_short_text_flagged(self):
        _, _, issues = score_sentence_quality(SHORT_TEXT)
        assert any(i.issue_type == IssueType.SHORT_DOCUMENT for i in issues)

    def test_score_range(self):
        score, _, _ = score_sentence_quality(CLEAN_TEXT)
        assert 0.0 <= score <= 1.0

    def test_empty_text(self):
        _, count, _ = score_sentence_quality("")
        assert count == 0


class TestTableIntegrityScorer:
    def test_clean_text_no_tables(self):
        score, has_tables, _ = score_table_integrity(CLEAN_TEXT)
        assert not has_tables
        assert score == 1.0

    def test_table_detected(self):
        _, has_tables, _ = score_table_integrity(TABLE_TEXT)
        assert has_tables

    def test_score_range(self):
        score, _, _ = score_table_integrity(TABLE_TEXT)
        assert 0.0 <= score <= 1.0


class TestChunkRiskScorer:
    def test_risk_range(self):
        risk, _ = score_chunk_risk(CLEAN_TEXT)
        assert 0.0 <= risk <= 1.0

    def test_empty_text_zero_risk(self):
        risk, _ = score_chunk_risk("")
        assert risk == 0.0


class TestComputeQualityScore:
    def test_all_perfect_high_score(self):
        assert compute_quality_score(1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0) >= 95.0

    def test_all_zero_low_score(self):
        assert compute_quality_score(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0) < 10.0

    def test_score_range(self):
        score = compute_quality_score(0.8, 0.9, 0.7, 0.8, 0.7, 1.0, 0.2)
        assert 0.0 <= score <= 100.0


# ── DocumentProfiler tests ─────────────────────────────────────


class TestDocumentProfiler:
    @pytest.fixture
    def profiler(self):
        return DocumentProfiler()

    def test_clean_text_passes_or_warns(self, profiler):
        profile = profiler.profile(CLEAN_TEXT, name="clean.txt")
        assert isinstance(profile, DocumentProfile)
        assert profile.quality_level in (QualityLevel.PASS, QualityLevel.WARN)

    def test_garbage_text_warns_or_fails(self, profiler):
        profile = profiler.profile(ENCODING_GARBAGE, name="garbage.txt")
        assert profile.quality_level in (QualityLevel.WARN, QualityLevel.FAIL)

    def test_profile_has_all_fields(self, profiler):
        profile = profiler.profile(CLEAN_TEXT, name="doc.txt")
        assert profile.name == "doc.txt"
        assert profile.quality_score >= 0
        assert profile.word_count > 0
        assert profile.char_count > 0
        assert profile.token_estimate > 0

    def test_boilerplate_detected(self, profiler):
        profile = profiler.profile(BOILERPLATE_TEXT, name="bp.txt")
        assert profile.boilerplate_ratio > 0.1

    def test_repetitive_content_detected(self, profiler):
        profile = profiler.profile(REPETITIVE_TEXT, name="rep.txt")
        assert profile.unique_line_ratio < 0.5

    def test_table_detected(self, profiler):
        assert profiler.profile(TABLE_TEXT, name="table.txt").has_tables

    def test_short_document_has_issues(self, profiler):
        assert profiler.profile(SHORT_TEXT, name="short.txt").issue_count > 0

    def test_quality_score_range(self, profiler):
        profile = profiler.profile(CLEAN_TEXT)
        assert 0.0 <= profile.quality_score <= 100.0

    def test_passes_property(self, profiler):
        profile = profiler.profile(CLEAN_TEXT)
        assert profile.passes == (profile.quality_level == QualityLevel.PASS)

    def test_high_severity_issues(self, profiler):
        profile = profiler.profile(ENCODING_GARBAGE)
        assert isinstance(profile.high_severity_issues, list)

    def test_repr(self, profiler):
        profile = profiler.profile(CLEAN_TEXT, name="test.txt")
        assert "DocumentProfile" in repr(profile)
        assert "test.txt" in repr(profile)

    def test_custom_thresholds(self):
        strict = DocumentProfiler(pass_threshold=90.0, warn_threshold=70.0)
        profile = strict.profile(CLEAN_TEXT)
        assert isinstance(profile.quality_level, QualityLevel)


# ── Deduplicator tests ─────────────────────────────────────────


class TestFindDuplicates:
    def test_identical_docs_detected(self):
        docs = {"a.txt": CLEAN_TEXT, "b.txt": CLEAN_TEXT}
        pairs = find_duplicates(docs, threshold=0.85)
        assert len(pairs) == 1
        assert pairs[0].is_exact

    def test_near_duplicates_detected(self):
        docs = {"a.txt": NEAR_DUPLICATE_A, "b.txt": NEAR_DUPLICATE_B}
        pairs = find_duplicates(docs, threshold=0.7)
        assert len(pairs) >= 1

    def test_different_docs_no_duplicates(self):
        docs = {"rag.txt": CLEAN_TEXT, "bp.txt": BOILERPLATE_TEXT}
        pairs = find_duplicates(docs, threshold=0.85)
        assert len(pairs) == 0

    def test_single_doc_no_duplicates(self):
        assert find_duplicates({"only.txt": CLEAN_TEXT}, threshold=0.85) == []

    def test_similarity_range(self):
        docs = {"a.txt": CLEAN_TEXT, "b.txt": CLEAN_TEXT}
        for pair in find_duplicates(docs, threshold=0.5):
            assert 0.0 <= pair.similarity <= 1.0

    def test_sorted_descending(self):
        docs = {
            "a.txt": CLEAN_TEXT,
            "b.txt": CLEAN_TEXT,
            "c.txt": NEAR_DUPLICATE_A,
            "d.txt": NEAR_DUPLICATE_B,
        }
        pairs = find_duplicates(docs, threshold=0.5)
        for i in range(len(pairs) - 1):
            assert pairs[i].similarity >= pairs[i + 1].similarity

    def test_repr(self):
        docs = {"a.txt": CLEAN_TEXT, "b.txt": CLEAN_TEXT}
        pairs = find_duplicates(docs)
        if pairs:
            assert "DuplicatePair" in repr(pairs[0])


class TestDeduplicate:
    def test_removes_duplicate(self):
        docs = {"a.txt": CLEAN_TEXT, "b.txt": CLEAN_TEXT, "c.txt": BOILERPLATE_TEXT}
        clean, _ = deduplicate(docs, threshold=0.85)
        assert len(clean) < len(docs)

    def test_keeps_unique(self):
        docs = {"a.txt": CLEAN_TEXT, "b.txt": BOILERPLATE_TEXT}
        clean, _ = deduplicate(docs, threshold=0.85)
        assert "a.txt" in clean and "b.txt" in clean

    def test_returns_removed_pairs(self):
        docs = {"a.txt": CLEAN_TEXT, "b.txt": CLEAN_TEXT}
        _, removed = deduplicate(docs, threshold=0.85)
        assert len(removed) >= 1


# ── CorpusProfiler tests ───────────────────────────────────────


class TestCorpusProfiler:
    @pytest.fixture
    def profiler(self):
        return CorpusProfiler(corpus_name="test_corpus")

    @pytest.fixture
    def sample_corpus(self):
        return {
            "clean.txt": CLEAN_TEXT,
            "boilerplate.txt": BOILERPLATE_TEXT,
            "table.txt": TABLE_TEXT,
            "repetitive.txt": REPETITIVE_TEXT,
        }

    def test_returns_corpus_report(self, profiler, sample_corpus):
        from doc_quality.models import CorpusReport

        report = profiler.profile(sample_corpus)
        assert isinstance(report, CorpusReport)

    def test_correct_total(self, profiler, sample_corpus):
        assert profiler.profile(sample_corpus).total == len(sample_corpus)

    def test_all_documents_profiled(self, profiler, sample_corpus):
        report = profiler.profile(sample_corpus)
        assert {p.name for p in report.profiles} == set(sample_corpus.keys())

    def test_pass_rate_range(self, profiler, sample_corpus):
        report = profiler.profile(sample_corpus)
        assert 0.0 <= report.pass_rate <= 1.0

    def test_avg_score_range(self, profiler, sample_corpus):
        report = profiler.profile(sample_corpus)
        assert 0.0 <= report.avg_quality_score <= 100.0

    def test_duplicates_detected(self, profiler):
        corpus = {"a.txt": CLEAN_TEXT, "b.txt": CLEAN_TEXT, "c.txt": BOILERPLATE_TEXT}
        report = profiler.profile(corpus)
        assert len(report.duplicates) >= 1

    def test_data_card_generated(self, profiler, sample_corpus):
        report = profiler.profile(sample_corpus)
        assert isinstance(report.data_card, DataCard)
        assert report.data_card.document_count == len(sample_corpus)

    def test_summary_is_string(self, profiler, sample_corpus):
        summary = profiler.profile(sample_corpus).summary()
        assert isinstance(summary, str) and "DOC-QUALITY" in summary

    def test_failed_documents_list(self, profiler, sample_corpus):
        assert isinstance(profiler.profile(sample_corpus).failed_documents, list)

    def test_warned_documents_list(self, profiler, sample_corpus):
        assert isinstance(profiler.profile(sample_corpus).warned_documents, list)

    def test_repr(self, profiler, sample_corpus):
        assert "CorpusReport" in repr(profiler.profile(sample_corpus))

    def test_on_progress_callback(self, profiler, sample_corpus):
        calls = []
        profiler.profile(sample_corpus, on_progress=lambda n, d, t: calls.append((n, d, t)))
        assert len(calls) == len(sample_corpus)

    def test_profile_directory(self, profiler, tmp_path):
        (tmp_path / "doc1.txt").write_text(CLEAN_TEXT)
        (tmp_path / "doc2.txt").write_text(BOILERPLATE_TEXT)
        assert profiler.profile_directory(str(tmp_path)).total == 2

    def test_empty_corpus(self, profiler):
        report = profiler.profile({})
        assert report.total == 0 and report.pass_rate == 0.0


# ── DataCard tests ─────────────────────────────────────────────


class TestDataCard:
    @pytest.fixture
    def card(self):
        return DataCard(
            corpus_name="test",
            document_count=10,
            total_tokens=50000,
            total_words=40000,
            quality_summary={"pass": 7, "warn": 2, "fail": 1},
            avg_quality_score=78.5,
            duplicate_pairs=2,
            avg_boilerplate=0.12,
            recommended_strategy="recursive",
            warnings=["1 document failed quality check"],
            generated_at="2026-04-09T12:00:00+00:00",
        )

    def test_to_markdown_returns_string(self, card):
        assert isinstance(card.to_markdown(), str)

    def test_markdown_contains_key_fields(self, card):
        md = card.to_markdown()
        assert "10" in md
        assert "50,000" in md
        assert "78.5" in md
        assert "recursive" in md
        assert "Pass: 7" in md

    def test_markdown_contains_warnings(self, card):
        assert "1 document failed" in card.to_markdown()

    def test_repr(self, card):
        assert "DataCard" in repr(card) and "test" in repr(card)
