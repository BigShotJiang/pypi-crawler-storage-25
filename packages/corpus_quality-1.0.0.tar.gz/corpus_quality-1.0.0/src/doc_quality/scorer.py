"""Document quality scoring — all heuristic, zero external dependencies."""

from __future__ import annotations

import re
from collections import Counter

from doc_quality.models import IssueType, QualityIssue

_BOILERPLATE_PATTERNS = [
    r"all rights reserved",
    r"confidential(?:ity)?\s+notice",
    r"this (?:document|page|report) (?:is|was|contains)",
    r"for internal use only",
    r"page \d+ of \d+",
    r"copyright \d{4}",
    r"(?:tel|fax|email|www)\s*[:\.]",
    r"registered (?:office|address|company)",
    r"terms and conditions",
    r"privacy policy",
    r"cookie policy",
    r"all information (?:is|are) (?:subject|provided)",
    r"disclaimer",
    r"unauthori[sz]ed (?:use|access|reproduction)",
]
_BOILERPLATE_RE = re.compile("|".join(_BOILERPLATE_PATTERNS), re.IGNORECASE)

_ARTIFACT_PATTERNS = [
    r"\ufffd",
    r"[\x00-\x08\x0b\x0c\x0e-\x1f]",
    r"(?:\?\?){3,}",
]
_ARTIFACT_RE = re.compile("|".join(_ARTIFACT_PATTERNS))

_TABLE_PATTERNS = [
    r"\|.+\|.+\|",
    r"\+[-+]+\+",
]
_TABLE_RE = re.compile("|".join(_TABLE_PATTERNS), re.MULTILINE)

_SENTENCE_END = re.compile(r"[.!?]\s+[A-Z]|[.!?]\s*$", re.MULTILINE)


def score_encoding(text: str) -> tuple[float, list[QualityIssue]]:
    """Score text encoding quality. Returns (0-1, issues)."""
    issues: list[QualityIssue] = []
    if not text:
        return 1.0, issues
    artifact_matches = _ARTIFACT_RE.findall(text)
    artifact_ratio = len(artifact_matches) / max(len(text), 1)
    replacement_chars = text.count("\ufffd")
    replacement_ratio = replacement_chars / max(len(text), 1)
    if replacement_ratio > 0.01:
        issues.append(
            QualityIssue(
                issue_type=IssueType.ENCODING_ARTIFACTS,
                severity="high",
                description=(
                    f"Unicode replacement characters found ({replacement_chars:,} occurrences"
                    " -- likely a failed PDF extraction)"
                ),
                value=replacement_ratio,
                threshold=0.01,
            )
        )
    elif artifact_ratio > 0.005:
        issues.append(
            QualityIssue(
                issue_type=IssueType.ENCODING_ARTIFACTS,
                severity="medium",
                description=f"Encoding artifacts detected ({len(artifact_matches)} occurrences)",
                value=artifact_ratio,
                threshold=0.005,
            )
        )
    score = max(0.0, 1.0 - artifact_ratio * 20)
    return round(score, 4), issues


def score_text_density(text: str) -> tuple[float, list[QualityIssue]]:
    """Score ratio of meaningful text vs whitespace. Returns (0-1, issues)."""
    issues: list[QualityIssue] = []
    if not text:
        return 0.0, [
            QualityIssue(
                issue_type=IssueType.LOW_TEXT_DENSITY, severity="high", description="Empty document"
            )
        ]
    non_whitespace = sum(1 for c in text if not c.isspace())
    density = non_whitespace / len(text)
    alpha = sum(1 for c in text if c.isalpha())
    alpha_ratio = alpha / max(non_whitespace, 1)
    if density < 0.3:
        issues.append(
            QualityIssue(
                issue_type=IssueType.LOW_TEXT_DENSITY,
                severity="high",
                description=f"Very low text density ({density:.0%}) -- document may be mostly whitespace",
                value=density,
                threshold=0.3,
            )
        )
    elif density < 0.5:
        issues.append(
            QualityIssue(
                issue_type=IssueType.LOW_TEXT_DENSITY,
                severity="medium",
                description=f"Low text density ({density:.0%})",
                value=density,
                threshold=0.5,
            )
        )
    if alpha_ratio < 0.4 and len(text) > 200:
        issues.append(
            QualityIssue(
                issue_type=IssueType.STRUCTURAL_NOISE,
                severity="medium",
                description=f"Low alphabetic ratio ({alpha_ratio:.0%}) -- mostly numbers or symbols",
                value=alpha_ratio,
                threshold=0.4,
            )
        )
    score = min(1.0, density * alpha_ratio * 2)
    return round(score, 4), issues


def score_boilerplate(text: str) -> tuple[float, float, list[QualityIssue]]:
    """Score boilerplate ratio. Returns (quality_score, boilerplate_ratio, issues)."""
    issues: list[QualityIssue] = []
    if not text:
        return 1.0, 0.0, issues
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    if not lines:
        return 1.0, 0.0, issues
    boilerplate_lines = sum(1 for ln in lines if _BOILERPLATE_RE.search(ln))
    ratio = boilerplate_lines / len(lines)
    if ratio > 0.30:
        issues.append(
            QualityIssue(
                issue_type=IssueType.HIGH_BOILERPLATE,
                severity="high",
                description=f"High boilerplate ratio ({ratio:.0%})",
                value=ratio,
                threshold=0.30,
            )
        )
    elif ratio > 0.15:
        issues.append(
            QualityIssue(
                issue_type=IssueType.HIGH_BOILERPLATE,
                severity="medium",
                description=f"Moderate boilerplate ratio ({ratio:.0%})",
                value=ratio,
                threshold=0.15,
            )
        )
    score = max(0.0, 1.0 - ratio * 2)
    return round(score, 4), round(ratio, 4), issues


def score_uniqueness(text: str) -> tuple[float, float, list[QualityIssue]]:
    """Score line uniqueness. Returns (quality_score, unique_line_ratio, issues)."""
    issues: list[QualityIssue] = []
    lines = [ln.strip().lower() for ln in text.splitlines() if len(ln.strip()) > 10]
    if len(lines) < 3:
        return 1.0, 1.0, issues
    ratio = len(set(lines)) / len(lines)
    if ratio < 0.5:
        issues.append(
            QualityIssue(
                issue_type=IssueType.REPETITIVE_CONTENT,
                severity="high",
                description=f"High content repetition -- only {ratio:.0%} of lines are unique",
                value=ratio,
                threshold=0.5,
            )
        )
    elif ratio < 0.7:
        issues.append(
            QualityIssue(
                issue_type=IssueType.REPETITIVE_CONTENT,
                severity="medium",
                description=f"Moderate repetition ({ratio:.0%} unique lines)",
                value=ratio,
                threshold=0.7,
            )
        )
    score = min(1.0, ratio * 1.2)
    return round(score, 4), round(ratio, 4), issues


def score_sentence_quality(text: str) -> tuple[float, int, list[QualityIssue]]:
    """Score sentence structure quality. Returns (quality_score, sentence_count, issues)."""
    issues: list[QualityIssue] = []
    if not text:
        return 0.5, 0, issues
    words_early = text.split()
    if len(words_early) < 50:
        issues.append(
            QualityIssue(
                issue_type=IssueType.SHORT_DOCUMENT,
                severity="medium",
                description=(
                    f"Very short document ({len(words_early)} words)"
                    " -- may not provide useful retrieval context"
                ),
                value=float(len(words_early)),
                threshold=50.0,
            )
        )
    if len(text) < 50:
        return 0.5, 0, issues
    sentence_endings = len(_SENTENCE_END.findall(text))
    word_count = len(words_early)
    if word_count > 50:
        expected = word_count / 17
        sentence_ratio = sentence_endings / expected
        if sentence_ratio < 0.2:
            issues.append(
                QualityIssue(
                    issue_type=IssueType.POOR_SENTENCE_RATIO,
                    severity="medium",
                    description="Very few complete sentences detected -- may be a list or failed extraction",
                    value=sentence_ratio,
                    threshold=0.2,
                )
            )
    score = min(1.0, max(0.0, 0.5 + sentence_endings / max(word_count / 10, 1) * 0.5))
    return round(score, 4), sentence_endings, issues


def score_table_integrity(text: str) -> tuple[float, bool, list[QualityIssue]]:
    """Detect tables and score integrity. Returns (integrity_score, has_tables, issues)."""
    issues: list[QualityIssue] = []
    has_tables = bool(_TABLE_RE.search(text))
    if not has_tables:
        return 1.0, False, issues
    pipe_rows = [ln for ln in text.splitlines() if ln.count("|") >= 2]
    if pipe_rows:
        col_counts = [ln.count("|") for ln in pipe_rows]
        most_common = Counter(col_counts).most_common(1)[0][0]
        inconsistent = sum(1 for c in col_counts if abs(c - most_common) > 1)
        inconsistency_ratio = inconsistent / len(col_counts)
        if inconsistency_ratio > 0.3:
            issues.append(
                QualityIssue(
                    issue_type=IssueType.TABLE_CORRUPTION,
                    severity="medium",
                    description=f"Table column structure inconsistent ({inconsistency_ratio:.0%} of rows)",
                    value=inconsistency_ratio,
                    threshold=0.3,
                )
            )
            return round(1.0 - inconsistency_ratio, 4), True, issues
    return 1.0, True, issues


def score_chunk_risk(text: str) -> tuple[float, list[QualityIssue]]:
    """Score risk that chunking will break content badly. Returns (risk 0-1, issues)."""
    issues: list[QualityIssue] = []
    if not text:
        return 0.0, issues
    lines = text.splitlines()
    if len(lines) < 3:
        return 0.0, issues
    avg_line_len = sum(len(ln) for ln in lines) / len(lines)
    long_line_risk = min(1.0, avg_line_len / 500)
    para_breaks = text.count("\n\n")
    para_density = para_breaks / max(len(lines), 1)
    para_risk = max(0.0, 1.0 - para_density * 10)
    table_risk = 0.3 if bool(_TABLE_RE.search(text)) else 0.0
    risk = long_line_risk * 0.4 + para_risk * 0.4 + table_risk * 0.2
    if risk > 0.6:
        issues.append(
            QualityIssue(
                issue_type=IssueType.CHUNK_BOUNDARY_RISK,
                severity="medium",
                description="High chunk boundary risk -- use paragraph or recursive chunking strategy",
                value=risk,
                threshold=0.6,
            )
        )
    elif risk > 0.4:
        issues.append(
            QualityIssue(
                issue_type=IssueType.CHUNK_BOUNDARY_RISK,
                severity="low",
                description="Moderate chunk boundary risk -- consider recursive chunking",
                value=risk,
                threshold=0.4,
            )
        )
    return round(risk, 4), issues


def compute_quality_score(
    encoding_score: float,
    density_score: float,
    boilerplate_score: float,
    uniqueness_score: float,
    sentence_score: float,
    table_score: float,
    chunk_risk: float,
) -> float:
    """Compute weighted overall quality score (0-100)."""
    raw = (
        encoding_score * 0.25
        + density_score * 0.20
        + uniqueness_score * 0.20
        + sentence_score * 0.15
        + boilerplate_score * 0.10
        + table_score * 0.05
        + (1.0 - chunk_risk) * 0.05
    )
    return round(raw * 100, 2)
