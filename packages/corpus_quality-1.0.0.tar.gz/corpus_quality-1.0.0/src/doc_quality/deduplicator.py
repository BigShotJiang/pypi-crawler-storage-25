"""Near-duplicate detection using shingle-based Jaccard similarity."""

from __future__ import annotations

import re

from doc_quality.models import DuplicatePair


def _normalise(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r"[^\w\s]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _shingles(text: str, k: int = 5) -> set[str]:
    words = text.split()
    if len(words) < k:
        return set(words)
    return {" ".join(words[i : i + k]) for i in range(len(words) - k + 1)}


def _jaccard(set_a: set, set_b: set) -> float:
    if not set_a or not set_b:
        return 0.0
    intersection = len(set_a & set_b)
    union = len(set_a | set_b)
    return intersection / union if union > 0 else 0.0


def find_duplicates(
    documents: dict[str, str],
    threshold: float = 0.85,
    exact_threshold: float = 0.99,
    shingle_size: int = 5,
) -> list[DuplicatePair]:
    """
    Find near-duplicate documents in a corpus using shingle-based Jaccard similarity.

    Args:
        documents:       Dict of {name: text}
        threshold:       Minimum similarity to flag as near-duplicate
        exact_threshold: Similarity above this treated as exact duplicate
        shingle_size:    Number of words per shingle

    Returns:
        List of DuplicatePair objects sorted by similarity descending
    """
    names = list(documents.keys())
    shingle_sets: dict[str, set[str]] = {
        name: _shingles(_normalise(text), k=shingle_size) for name, text in documents.items()
    }
    pairs: list[DuplicatePair] = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            sim = _jaccard(shingle_sets[names[i]], shingle_sets[names[j]])
            if sim >= threshold:
                pairs.append(
                    DuplicatePair(
                        doc_a=names[i],
                        doc_b=names[j],
                        similarity=round(sim, 4),
                        is_exact=sim >= exact_threshold,
                    )
                )
    pairs.sort(key=lambda p: p.similarity, reverse=True)
    return pairs


def deduplicate(
    documents: dict[str, str],
    threshold: float = 0.85,
) -> tuple[dict[str, str], list[DuplicatePair]]:
    """
    Remove near-duplicate documents, keeping the first in each pair.

    Returns:
        Tuple of (deduplicated_documents, removed_duplicate_pairs)
    """
    pairs = find_duplicates(documents, threshold=threshold)
    to_remove: set[str] = set()
    for pair in pairs:
        if pair.doc_a not in to_remove and pair.doc_b not in to_remove:
            to_remove.add(pair.doc_b)
    clean = {name: text for name, text in documents.items() if name not in to_remove}
    removed = [p for p in pairs if p.doc_b in to_remove]
    return clean, removed
