"""doc-quality CLI."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> None:
    p = argparse.ArgumentParser(
        prog="doc-quality",
        description="Profile document quality before embedding. Zero dependencies.",
    )
    sub = p.add_subparsers(dest="command", required=True)

    p_profile = sub.add_parser("profile", help="Profile a single document")
    p_profile.add_argument("file", help="Text file to profile")
    p_profile.add_argument("--json", action="store_true", dest="json_out")

    p_corpus = sub.add_parser("corpus", help="Profile a directory of documents")
    p_corpus.add_argument("directory", help="Directory containing text files")
    p_corpus.add_argument("--name", default="corpus")
    p_corpus.add_argument("--threshold", type=float, default=75.0)
    p_corpus.add_argument("--dup-threshold", type=float, default=0.85)
    p_corpus.add_argument("--data-card", action="store_true")
    p_corpus.add_argument("--json", action="store_true", dest="json_out")

    p_dedup = sub.add_parser("deduplicate", help="Find near-duplicate documents")
    p_dedup.add_argument("directory")
    p_dedup.add_argument("--threshold", type=float, default=0.85)
    p_dedup.add_argument("--json", action="store_true", dest="json_out")

    args = p.parse_args()

    if args.command == "profile":
        from doc_quality import DocumentProfiler

        text = Path(args.file).read_text(encoding="utf-8", errors="replace")
        profile = DocumentProfiler().profile(text, name=Path(args.file).name)
        if args.json_out:
            print(
                json.dumps(
                    {
                        "name": profile.name,
                        "quality_score": profile.quality_score,
                        "quality_level": profile.quality_level.value,
                        "word_count": profile.word_count,
                        "token_estimate": profile.token_estimate,
                        "boilerplate_ratio": profile.boilerplate_ratio,
                        "chunk_risk_score": profile.chunk_risk_score,
                        "issues": [
                            {
                                "type": i.issue_type.value,
                                "severity": i.severity,
                                "description": i.description,
                            }
                            for i in profile.issues
                        ],
                    },
                    indent=2,
                )
            )
        else:
            icons = {"pass": "OK", "warn": "WARN", "fail": "FAIL"}
            icon = icons.get(profile.quality_level.value, "?")
            print(f"\n[{icon}] {profile.name}")
            print(f"   Score:         {profile.quality_score:.1f}/100")
            print(f"   Words:         {profile.word_count:,}")
            print(f"   Tokens (est.): {profile.token_estimate:,}")
            print(f"   Boilerplate:   {profile.boilerplate_ratio:.0%}")
            print(f"   Chunk risk:    {profile.chunk_risk_score:.0%}")
            if profile.issues:
                print(f"\n   Issues ({len(profile.issues)}):")
                for issue in profile.issues:
                    print(f"   [{issue.severity.upper()}] {issue.description}")
            print()

    elif args.command == "corpus":
        from doc_quality import CorpusProfiler

        profiler = CorpusProfiler(
            pass_threshold=args.threshold,
            corpus_name=args.name,
            duplicate_threshold=args.dup_threshold,
            verbose=True,
        )
        report = profiler.profile_directory(args.directory)
        if args.data_card:
            print(report.data_card.to_markdown())
        elif args.json_out:
            print(
                json.dumps(
                    {
                        "total": report.total,
                        "pass": report.pass_count,
                        "warn": report.warn_count,
                        "fail": report.fail_count,
                        "pass_rate": report.pass_rate,
                        "avg_quality_score": report.avg_quality_score,
                        "duplicate_pairs": len(report.duplicates),
                        "recommended_strategy": report.data_card.recommended_strategy,
                        "warnings": report.data_card.warnings,
                    },
                    indent=2,
                )
            )
        else:
            print(report.summary())

    elif args.command == "deduplicate":
        from doc_quality import find_duplicates

        docs: dict[str, str] = {}
        base = Path(args.directory)
        for path in sorted(base.rglob("*.txt")):
            docs[str(path.relative_to(base))] = path.read_text(encoding="utf-8", errors="replace")
        for path in sorted(base.rglob("*.md")):
            docs[str(path.relative_to(base))] = path.read_text(encoding="utf-8", errors="replace")

        pairs = find_duplicates(docs, threshold=args.threshold)
        if args.json_out:
            print(
                json.dumps(
                    [
                        {
                            "doc_a": pair.doc_a,
                            "doc_b": pair.doc_b,
                            "similarity": pair.similarity,
                            "exact": pair.is_exact,
                        }
                        for pair in pairs
                    ],
                    indent=2,
                )
            )
        elif pairs:
            print(f"\n  Found {len(pairs)} duplicate pair(s):\n")
            for pair in pairs:
                kind = "EXACT" if pair.is_exact else f"NEAR ({pair.similarity:.0%})"
                print(f"  [{kind}] {pair.doc_a}  <->  {pair.doc_b}")
            print()
        else:
            print("\n  No duplicates found.\n")


if __name__ == "__main__":
    main()
