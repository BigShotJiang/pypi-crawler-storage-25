"""
doc-quality
===========
Document quality profiler for ML pipelines.
Score, deduplicate, and validate your corpus before embedding.
Zero mandatory dependencies.

Quick start:
    from doc_quality import CorpusProfiler, DocumentProfiler

    profiler = DocumentProfiler()
    profile = profiler.profile(text, name="report.pdf")
    print(profile.quality_score)
    print(profile.issues)

    corpus = CorpusProfiler(corpus_name="my_rag_corpus")
    report = corpus.profile({"doc1.txt": text1, "doc2.txt": text2})
    print(report.summary())
    print(report.data_card.to_markdown())

    report = corpus.profile_directory("./documents/")
"""

from doc_quality.deduplicator import deduplicate, find_duplicates
from doc_quality.models import (
    CorpusReport,
    DataCard,
    DocumentProfile,
    DuplicatePair,
    IssueType,
    QualityIssue,
    QualityLevel,
)
from doc_quality.profiler import CorpusProfiler, DocumentProfiler

__version__ = "1.0.0"
__author__ = "Linda Oraegbunam"
__all__ = [
    "DocumentProfiler",
    "CorpusProfiler",
    "DocumentProfile",
    "CorpusReport",
    "DataCard",
    "DuplicatePair",
    "QualityIssue",
    "QualityLevel",
    "IssueType",
    "find_duplicates",
    "deduplicate",
]
