"""DocumentProfiler and CorpusProfiler — main entry points."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

from doc_quality.deduplicator import find_duplicates
from doc_quality.models import (
    CorpusReport,
    DataCard,
    DocumentProfile,
    DuplicatePair,
    QualityLevel,
)
from doc_quality.scorer import (
    compute_quality_score,
    score_boilerplate,
    score_chunk_risk,
    score_encoding,
    score_sentence_quality,
    score_table_integrity,
    score_text_density,
    score_uniqueness,
)


class DocumentProfiler:
    """
    Profile the quality of a single document.

    Example:
        profiler = DocumentProfiler()
        profile = profiler.profile(text, name="report.pdf")
        print(profile.quality_score)
        print(profile.issues)
    """

    def __init__(self, pass_threshold: float = 75.0, warn_threshold: float = 50.0) -> None:
        self.pass_threshold = pass_threshold
        self.warn_threshold = warn_threshold

    def profile(self, text: str, name: str = "document") -> DocumentProfile:
        """
        Profile the quality of a single document.

        Args:
            text: Plain text content
            name: Document identifier

        Returns:
            DocumentProfile with all quality metrics
        """
        all_issues = []
        encoding_score, enc_issues = score_encoding(text)
        density_score, density_issues = score_text_density(text)
        bp_score, bp_ratio, bp_issues = score_boilerplate(text)
        uniq_score, uniq_ratio, uniq_issues = score_uniqueness(text)
        sent_score, sent_count, sent_issues = score_sentence_quality(text)
        table_score, has_tables, tbl_issues = score_table_integrity(text)
        chunk_risk, chunk_issues = score_chunk_risk(text)

        all_issues.extend(enc_issues)
        all_issues.extend(density_issues)
        all_issues.extend(bp_issues)
        all_issues.extend(uniq_issues)
        all_issues.extend(sent_issues)
        all_issues.extend(tbl_issues)
        all_issues.extend(chunk_issues)

        quality_score = compute_quality_score(
            encoding_score=encoding_score,
            density_score=density_score,
            boilerplate_score=bp_score,
            uniqueness_score=uniq_score,
            sentence_score=sent_score,
            table_score=table_score,
            chunk_risk=chunk_risk,
        )

        if quality_score >= self.pass_threshold:
            quality_level = QualityLevel.PASS
        elif quality_score >= self.warn_threshold:
            quality_level = QualityLevel.WARN
        else:
            quality_level = QualityLevel.FAIL

        return DocumentProfile(
            name=name,
            quality_score=quality_score,
            quality_level=quality_level,
            char_count=len(text),
            word_count=len(text.split()),
            sentence_count=sent_count,
            token_estimate=max(1, len(text) // 4),
            line_count=len(text.splitlines()),
            unique_line_ratio=uniq_ratio,
            boilerplate_ratio=bp_ratio,
            text_density=density_score,
            encoding_score=encoding_score,
            sentence_quality=sent_score,
            has_tables=has_tables,
            table_integrity=table_score,
            chunk_risk_score=chunk_risk,
            issues=all_issues,
        )


class CorpusProfiler:
    """
    Profile the quality of an entire document corpus.

    Example:
        profiler = CorpusProfiler()
        report = profiler.profile({"doc1.txt": text1, "doc2.txt": text2})
        print(report.summary())
        print(report.data_card.to_markdown())

        report = profiler.profile_directory("./documents/")
    """

    def __init__(
        self,
        pass_threshold: float = 75.0,
        warn_threshold: float = 50.0,
        duplicate_threshold: float = 0.85,
        corpus_name: str = "corpus",
        verbose: bool = False,
    ) -> None:
        self.pass_threshold = pass_threshold
        self.warn_threshold = warn_threshold
        self.duplicate_threshold = duplicate_threshold
        self.corpus_name = corpus_name
        self.verbose = verbose
        self._doc_profiler = DocumentProfiler(pass_threshold, warn_threshold)

    def profile(
        self,
        documents: dict[str, str],
        on_progress: Callable[[str, int, int], None] | None = None,
    ) -> CorpusReport:
        """
        Profile a corpus of documents.

        Args:
            documents:   Dict of {document_name: text_content}
            on_progress: Optional callback(name, done, total)

        Returns:
            CorpusReport with per-document profiles, duplicates, and data card
        """
        profiles: list[DocumentProfile] = []
        for i, name in enumerate(documents):
            on_progress and on_progress(name, i + 1, len(documents))
            self._log(f"  Profiling {name} ({i + 1}/{len(documents)})...")
            profiles.append(self._doc_profiler.profile(documents[name], name=name))

        self._log("  Checking for duplicates...")
        duplicates = find_duplicates(documents, threshold=self.duplicate_threshold)
        data_card = self._build_data_card(profiles, duplicates, documents)
        return CorpusReport(profiles=profiles, duplicates=duplicates, data_card=data_card)

    def profile_directory(
        self,
        directory: str,
        extensions: list[str] | None = None,
        encoding: str = "utf-8",
        errors: str = "replace",
    ) -> CorpusReport:
        """Profile all text files in a directory."""
        if extensions is None:
            extensions = [".txt", ".md", ".rst", ".csv", ".html", ".htm", ".json"]
        docs: dict[str, str] = {}
        base = Path(directory)
        for ext in extensions:
            for path in sorted(base.rglob(f"*{ext}")):
                try:
                    text = path.read_text(encoding=encoding, errors=errors)
                    docs[str(path.relative_to(base))] = text
                except Exception as exc:
                    self._log(f"  Warning: could not read {path}: {exc}")
        self._log(f"  Found {len(docs)} documents in {directory}")
        return self.profile(docs)

    def _build_data_card(
        self,
        profiles: list[DocumentProfile],
        duplicates: list[DuplicatePair],
        documents: dict[str, str],
    ) -> DataCard:
        total_tokens = sum(p.token_estimate for p in profiles)
        total_words = sum(p.word_count for p in profiles)
        avg_score = sum(p.quality_score for p in profiles) / len(profiles) if profiles else 0.0
        avg_boilerplate = (
            sum(p.boilerplate_ratio for p in profiles) / len(profiles) if profiles else 0.0
        )

        quality_summary = {
            "pass": sum(1 for p in profiles if p.quality_level == QualityLevel.PASS),
            "warn": sum(1 for p in profiles if p.quality_level == QualityLevel.WARN),
            "fail": sum(1 for p in profiles if p.quality_level == QualityLevel.FAIL),
        }

        ext_counts: dict[str, int] = {}
        for name in documents:
            ext = Path(name).suffix.lower() or "unknown"
            ext_counts[ext] = ext_counts.get(ext, 0) + 1
        doc_types = [
            f"{ext} ({count})" for ext, count in sorted(ext_counts.items(), key=lambda x: -x[1])
        ]

        avg_chunk_risk = (
            sum(p.chunk_risk_score for p in profiles) / len(profiles) if profiles else 0.0
        )
        has_tables = any(p.has_tables for p in profiles)

        if has_tables:
            strategy = "paragraph (preserves table structure)"
        elif avg_chunk_risk > 0.5:
            strategy = "recursive (high boundary risk detected)"
        elif avg_boilerplate > 0.2:
            strategy = "paragraph (skip boilerplate sections)"
        else:
            strategy = "recursive (good default for this corpus)"

        warnings: list[str] = []
        if quality_summary["fail"] > 0:
            warnings.append(
                f"{quality_summary['fail']} document(s) scored FAIL -- review before embedding"
            )
        if duplicates:
            exact = sum(1 for d in duplicates if d.is_exact)
            near = len(duplicates) - exact
            if exact:
                warnings.append(f"{exact} exact duplicate pair(s) -- remove before indexing")
            if near:
                warnings.append(f"{near} near-duplicate pair(s) -- may cause redundant chunks")
        if avg_boilerplate > 0.25:
            warnings.append(
                f"High average boilerplate ({avg_boilerplate:.0%}) -- consider stripping"
            )

        return DataCard(
            corpus_name=self.corpus_name,
            document_count=len(profiles),
            total_tokens=total_tokens,
            total_words=total_words,
            document_types=doc_types,
            quality_summary=quality_summary,
            avg_quality_score=round(avg_score, 2),
            duplicate_pairs=len(duplicates),
            avg_boilerplate=round(avg_boilerplate, 4),
            recommended_strategy=strategy,
            warnings=warnings,
            generated_at=datetime.now(timezone.utc).isoformat(),
        )

    def _log(self, msg: str) -> None:
        if self.verbose:
            print(msg)
