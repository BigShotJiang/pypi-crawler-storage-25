from __future__ import annotations

import threading
import time
from pathlib import Path
from typing import Any, Callable, Dict, List

from .utils import atomic_write_json, default_storage_dir, read_json_file


class EventQueue:
    """
    Thread-safe queue with optional disk persistence.

    send_fn signature:
      send_fn(batch: list[dict]) -> tuple[bool, list[dict]]
    Returns:
      (success, retry_events)
    """

    def __init__(
        self,
        flush_interval: float = 2.0,
        max_batch: int = 10,
        max_queue_size: int = 5000,
        queue_file_path: str | None = None,
    ) -> None:
        self.flush_interval = max(0.2, float(flush_interval))
        self.max_batch = max(1, int(max_batch))
        self.max_queue_size = max(1, int(max_queue_size))
        self.queue_file_path = Path(queue_file_path) if queue_file_path else default_storage_dir() / "events.queue.json"

        self._queue: List[Dict[str, Any]] = []
        self._lock = threading.Lock()
        self._running = False
        self._thread: threading.Thread | None = None

        self._load_from_disk()

    @property
    def size(self) -> int:
        with self._lock:
            return len(self._queue)

    def add(self, event: Dict[str, Any]) -> None:
        with self._lock:
            if len(self._queue) >= self.max_queue_size:
                self._queue.pop(0)
            self._queue.append(event)
            self._persist_locked()

    def add_many_front(self, events: List[Dict[str, Any]]) -> None:
        if not events:
            return

        with self._lock:
            self._queue = list(events) + self._queue
            if len(self._queue) > self.max_queue_size:
                self._queue = self._queue[-self.max_queue_size :]
            self._persist_locked()

    def get_batch(self) -> List[Dict[str, Any]]:
        with self._lock:
            batch = self._queue[: self.max_batch]
            self._queue = self._queue[self.max_batch :]
            self._persist_locked()
            return batch

    def flush_once(
        self,
        send_fn: Callable[[List[Dict[str, Any]]], tuple[bool, List[Dict[str, Any]]]],
    ) -> bool:
        batch = self.get_batch()
        if not batch:
            return False

        success, retry_events = send_fn(batch)
        if retry_events:
            self.add_many_front(retry_events)
        return success

    def start(
        self,
        send_fn: Callable[[List[Dict[str, Any]]], tuple[bool, List[Dict[str, Any]]]],
    ) -> None:
        if self._running:
            return

        self._running = True

        def loop() -> None:
            while self._running:
                time.sleep(self.flush_interval)
                self.flush_once(send_fn)

        self._thread = threading.Thread(target=loop, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._running = False

    def _load_from_disk(self) -> None:
        payload = read_json_file(self.queue_file_path, fallback=[])
        if isinstance(payload, list):
            self._queue = [item for item in payload if isinstance(item, dict)]

    def _persist_locked(self) -> None:
        atomic_write_json(self.queue_file_path, self._queue)
