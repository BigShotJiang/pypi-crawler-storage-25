from __future__ import annotations

import json
import os
import tempfile
import time
import uuid
from pathlib import Path
from typing import Any


def generate_device_id() -> str:
    return str(uuid.uuid4())


def generate_event_id() -> str:
    return str(uuid.uuid4())


def now_ts() -> int:
    return int(time.time() * 1000)


def default_storage_dir() -> Path:
    return Path.home() / ".lumina"


def ensure_parent_dir(file_path: Path) -> None:
    file_path.parent.mkdir(parents=True, exist_ok=True)


def read_json_file(file_path: Path, fallback: Any) -> Any:
    if not file_path.exists():
        return fallback

    try:
        with file_path.open("r", encoding="utf-8") as handle:
            return json.load(handle)
    except Exception:
        return fallback


def atomic_write_json(file_path: Path, payload: Any) -> None:
    ensure_parent_dir(file_path)

    with tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        delete=False,
        dir=str(file_path.parent),
    ) as handle:
        json.dump(payload, handle)
        temp_path = Path(handle.name)

    os.replace(str(temp_path), str(file_path))


def load_or_create_device_id(device_id_path: str | None = None) -> str:
    path = Path(device_id_path) if device_id_path else default_storage_dir() / "device_id"

    if path.exists():
        try:
            value = path.read_text(encoding="utf-8").strip()
            if value:
                return value
        except Exception:
            pass

    value = generate_device_id()
    ensure_parent_dir(path)
    path.write_text(value, encoding="utf-8")
    return value


def compute_backoff_seconds(
    attempt: int,
    base_seconds: float = 0.5,
    max_seconds: float = 8.0,
) -> float:
    if attempt <= 0:
        return 0.0

    delay = base_seconds * (2 ** (attempt - 1))
    return min(delay, max_seconds)
