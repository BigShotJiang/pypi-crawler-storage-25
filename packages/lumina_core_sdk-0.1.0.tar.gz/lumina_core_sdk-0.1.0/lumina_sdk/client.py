from __future__ import annotations

import hashlib
import json
import threading
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from .queue import EventQueue
from .utils import (
    atomic_write_json,
    compute_backoff_seconds,
    default_storage_dir,
    generate_event_id,
    load_or_create_device_id,
    now_ts,
    read_json_file,
)

Hook = Callable[[Dict[str, Any]], None]


class LuminaError(Exception):
    """Base error for SDK failures."""


class LuminaConfigurationError(LuminaError):
    """Raised when client is configured incorrectly."""


class LuminaTransportError(LuminaError):
    """Raised on network transport failures."""


class LuminaHTTPError(LuminaError):
    """Raised when server returns non-2xx response."""

    def __init__(self, status_code: int, message: str, payload: Any | None = None) -> None:
        super().__init__(message)
        self.status_code = int(status_code)
        self.payload = payload


class Lumina:
    def __init__(
        self,
        api_key: str,
        trader_id: str,
        org_id: str | None = None,
        base_url: str = "https://api.lumina-core.com",
        timeout: float = 5.0,
        flush_interval: float = 2.0,
        max_batch: int = 10,
        max_retries: int = 5,
        storage_dir: str | None = None,
        max_queue_size: int = 5000,
        auto_start: bool = True,
    ) -> None:
        if not api_key:
            raise LuminaConfigurationError("api_key is required")
        if not trader_id:
            raise LuminaConfigurationError("trader_id is required")

        self.api_key = api_key
        self.trader_id = trader_id
        self.org_id = (org_id or "").strip() or None
        self.base_url = base_url.rstrip("/")
        self.timeout = float(timeout)
        self.max_retries = max(0, int(max_retries))
        self.retryable_status_codes = {408, 429, 500, 502, 503, 504}

        self.storage_dir = Path(storage_dir) if storage_dir else default_storage_dir()
        self.storage_dir.mkdir(parents=True, exist_ok=True)

        self.device_id = load_or_create_device_id(str(self.storage_dir / "device_id"))
        self.dead_letter_path = self.storage_dir / "dead_letter.queue.json"

        self._hooks: Dict[str, List[Hook]] = {}
        self._hooks_lock = threading.Lock()

        self._mouse_lock = threading.Lock()
        self._mouse_listener = None
        self._mouse_thread: threading.Thread | None = None
        self._mouse_running = False
        self._mouse_move_count = 0
        self._mouse_click_count = 0

        self.queue = EventQueue(
            flush_interval=flush_interval,
            max_batch=max_batch,
            max_queue_size=max_queue_size,
            queue_file_path=str(self.storage_dir / "events.queue.json"),
        )

        if auto_start:
            self.queue.start(self._send_batch)

    # Public API
    def on(self, event_name: str, callback: Hook) -> None:
        if not event_name:
            raise LuminaConfigurationError("event_name is required")
        if not callable(callback):
            raise LuminaConfigurationError("callback must be callable")

        with self._hooks_lock:
            self._hooks.setdefault(event_name, []).append(callback)

    def off(self, event_name: str, callback: Hook) -> None:
        with self._hooks_lock:
            callbacks = self._hooks.get(event_name, [])
            self._hooks[event_name] = [cb for cb in callbacks if cb is not callback]

    def track(self, event: Dict[str, Any]) -> str:
        if not isinstance(event, dict):
            raise LuminaConfigurationError("event must be a dict")

        event_type = str(event.get("type") or "custom")
        ts = now_ts()

        payload = {
            "trader_id": self.trader_id,
            "device_id": self.device_id,
            "timestamp": ts,
            "event": event,
        }

        envelope = self._build_event_envelope(event_type=event_type, ts=ts, payload=payload)
        self.queue.add(envelope)

        self._emit("EVENT_QUEUED", {"event_id": envelope["id"], "queue_size": self.queue.size})

        if self._contains_critical(event):
            self._emit("CRITICAL", {"source": "track", "event": envelope})

        return str(envelope["id"])

    def flush(self, max_cycles: int = 50) -> int:
        sent_cycles = 0
        for _ in range(max(1, int(max_cycles))):
            if self.queue.size <= 0:
                break
            self.queue.flush_once(self._send_batch)
            sent_cycles += 1
        return sent_cycles

    def shutdown(self, flush: bool = True) -> None:
        if flush:
            self.flush(max_cycles=max(10, self.max_retries + 5))
        self.stop_auto_track_mouse()
        self.queue.stop()

    def get_state(self) -> Dict[str, Any]:
        query = urlencode({"traderId": self.trader_id})

        try:
            payload = self._request("GET", f"/api/v1/behavior/state?{query}", retries=1)
        except LuminaHTTPError as exc:
            if exc.status_code == 404:
                payload = self._request("GET", "/api/behavior/summary", retries=1)
            else:
                raise

        if self._contains_critical(payload):
            self._emit("CRITICAL", {"source": "state", "state": payload})

        return payload

    def get_health(self) -> Dict[str, Any]:
        return self._request("GET", "/api/v1/health", retries=1)

    def evaluate(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        return self._request("POST", "/api/v1/engine/evaluate", payload=payload, retries=1)

    def get_error_analytics(self, top_n: int = 20) -> Dict[str, Any]:
        query = urlencode({"top_n": max(1, min(int(top_n), 100))})
        return self._request("GET", f"/api/v1/analytics/errors?{query}", retries=1)

    def get_enterprise_demo(self) -> Dict[str, Any]:
        return self._request("GET", "/api/v1/engine/demo/enterprise", retries=1)

    def auto_track_mouse(self, emit_interval_seconds: float = 2.0) -> None:
        if self._mouse_running:
            return

        try:
            from pynput import mouse  # type: ignore
        except Exception as exc:
            raise LuminaConfigurationError(
                "auto_track_mouse requires pynput. Install with: pip install pynput"
            ) from exc

        self._mouse_running = True
        emit_interval_seconds = max(0.25, float(emit_interval_seconds))

        def on_move(_x: int, _y: int) -> None:
            with self._mouse_lock:
                self._mouse_move_count += 1

        def on_click(_x: int, _y: int, _button: Any, pressed: bool) -> None:
            if not pressed:
                return
            with self._mouse_lock:
                self._mouse_click_count += 1

        self._mouse_listener = mouse.Listener(on_move=on_move, on_click=on_click)
        self._mouse_listener.start()

        def emit_loop() -> None:
            while self._mouse_running:
                time.sleep(emit_interval_seconds)

                with self._mouse_lock:
                    moves = self._mouse_move_count
                    clicks = self._mouse_click_count
                    self._mouse_move_count = 0
                    self._mouse_click_count = 0

                if moves <= 0 and clicks <= 0:
                    continue

                self.track(
                    {
                        "type": "mouse_activity",
                        "moves": moves,
                        "clicks": clicks,
                        "window_ms": int(emit_interval_seconds * 1000),
                    }
                )

        self._mouse_thread = threading.Thread(target=emit_loop, daemon=True)
        self._mouse_thread.start()

        self._emit("AUTO_TRACK_STARTED", {"mode": "mouse"})

    def stop_auto_track_mouse(self) -> None:
        self._mouse_running = False
        listener = self._mouse_listener
        if listener is not None:
            try:
                listener.stop()
            except Exception:
                pass
        self._mouse_listener = None

    # Internal: queue flush callback
    def _send_batch(self, batch: List[Dict[str, Any]]) -> Tuple[bool, List[Dict[str, Any]]]:
        due_events, deferred_events = self._split_due_events(batch)

        if not due_events:
            return False, deferred_events

        body_events = [self._strip_internal_fields(event) for event in due_events]

        try:
            self._request(
                "POST",
                "/api/v1/events/batch",
                payload={"events": body_events},
                retries=1,
            )
            self._emit(
                "BATCH_SENT",
                {
                    "count": len(body_events),
                    "queue_size": self.queue.size,
                },
            )
            return True, deferred_events
        except LuminaHTTPError as exc:
            retryable = exc.status_code in self.retryable_status_codes
            retry_events, dead_events = self._partition_retryable(due_events, retryable)

            if dead_events:
                self._write_dead_letter(dead_events, reason=f"HTTP {exc.status_code}")

            all_retry = deferred_events + retry_events
            if all_retry:
                self._emit("RETRY_SCHEDULED", {"count": len(all_retry), "reason": str(exc)})

            self._emit("ERROR", {"type": "http", "status": exc.status_code, "message": str(exc)})
            return False, all_retry
        except LuminaTransportError as exc:
            retry_events, dead_events = self._partition_retryable(due_events, True)

            if dead_events:
                self._write_dead_letter(dead_events, reason="transport_error")

            all_retry = deferred_events + retry_events
            if all_retry:
                self._emit("RETRY_SCHEDULED", {"count": len(all_retry), "reason": str(exc)})

            self._emit("ERROR", {"type": "transport", "message": str(exc)})
            return False, all_retry
        except Exception as exc:
            retry_events, dead_events = self._partition_retryable(due_events, True)

            if dead_events:
                self._write_dead_letter(dead_events, reason="unexpected_send_error")

            all_retry = deferred_events + retry_events
            self._emit("ERROR", {"type": "unexpected", "message": str(exc)})
            return False, all_retry

    # Internal: networking
    def _request(
        self,
        method: str,
        path: str,
        payload: Optional[Dict[str, Any]] = None,
        retries: int = 0,
    ) -> Dict[str, Any]:
        url = f"{self.base_url}{path}"
        headers = {"Accept": "application/json"}

        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
            headers["x-api-key"] = self.api_key
        if self.org_id:
            headers["x-org-id"] = self.org_id

        body_bytes = None
        if payload is not None:
            headers["Content-Type"] = "application/json"
            body_bytes = json.dumps(payload).encode("utf-8")

        attempts = max(0, int(retries)) + 1

        for attempt in range(1, attempts + 1):
            request = Request(url=url, method=method, headers=headers, data=body_bytes)

            try:
                with urlopen(request, timeout=self.timeout) as response:
                    raw = response.read().decode("utf-8")
                    return self._maybe_parse_json(raw) if raw else {}
            except HTTPError as exc:
                response_body = exc.read().decode("utf-8", errors="replace") if exc.fp else ""
                parsed_payload = self._maybe_parse_json(response_body)
                message = self._extract_error_message(parsed_payload, default=f"HTTP {exc.code}")
                error = LuminaHTTPError(status_code=exc.code, message=message, payload=parsed_payload)

                if exc.code in self.retryable_status_codes and attempt < attempts:
                    time.sleep(compute_backoff_seconds(attempt))
                    continue
                raise error
            except (URLError, TimeoutError, OSError) as exc:
                if attempt < attempts:
                    time.sleep(compute_backoff_seconds(attempt))
                    continue
                raise LuminaTransportError(f"Network request failed: {method} {path}: {exc}") from exc

        raise LuminaTransportError(f"Network request failed: {method} {path}")

    # Internal: helpers
    def _build_event_envelope(self, event_type: str, ts: int, payload: Dict[str, Any]) -> Dict[str, Any]:
        event_id = generate_event_id()
        hash_input = json.dumps(
            {
                "id": event_id,
                "type": event_type,
                "ts": ts,
                "payload": payload,
            },
            sort_keys=True,
            separators=(",", ":"),
        )
        event_hash = hashlib.sha256(hash_input.encode("utf-8")).hexdigest()

        return {
            "id": event_id,
            "type": event_type,
            "ts": ts,
            "payload": payload,
            "hash": event_hash,
            "device_id": self.device_id,
            "_attempt": 0,
            "_next_retry_at": 0,
        }

    def _split_due_events(self, events: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
        now = now_ts()
        due: List[Dict[str, Any]] = []
        deferred: List[Dict[str, Any]] = []

        for item in events:
            next_retry_at = int(item.get("_next_retry_at") or 0)
            if next_retry_at <= now:
                due.append(item)
            else:
                deferred.append(item)

        return due, deferred

    def _partition_retryable(
        self,
        events: List[Dict[str, Any]],
        retryable: bool,
    ) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
        if not events:
            return [], []

        retry_events: List[Dict[str, Any]] = []
        dead_events: List[Dict[str, Any]] = []
        now = now_ts()

        for item in events:
            next_attempt = int(item.get("_attempt") or 0) + 1
            if retryable and next_attempt <= self.max_retries:
                cloned = dict(item)
                cloned["_attempt"] = next_attempt
                delay_seconds = compute_backoff_seconds(next_attempt)
                cloned["_next_retry_at"] = now + int(delay_seconds * 1000)
                retry_events.append(cloned)
            else:
                dead_events.append(item)

        return retry_events, dead_events

    def _strip_internal_fields(self, event: Dict[str, Any]) -> Dict[str, Any]:
        return {k: v for k, v in event.items() if not k.startswith("_")}

    def _write_dead_letter(self, events: List[Dict[str, Any]], reason: str) -> None:
        if not events:
            return

        existing = read_json_file(self.dead_letter_path, fallback=[])
        if not isinstance(existing, list):
            existing = []

        for event in events:
            existing.append(
                {
                    "ts": now_ts(),
                    "reason": reason,
                    "event": self._strip_internal_fields(event),
                }
            )

        atomic_write_json(self.dead_letter_path, existing)
        self._emit("DEAD_LETTER", {"count": len(events), "reason": reason})

    def _emit(self, event_name: str, payload: Dict[str, Any]) -> None:
        callbacks: List[Hook]
        with self._hooks_lock:
            callbacks = list(self._hooks.get(event_name, []))

        for callback in callbacks:
            try:
                callback(payload)
            except Exception:
                # Hooks must never crash the SDK runtime.
                pass

    def _maybe_parse_json(self, text: str) -> Any:
        if not text:
            return None

        try:
            return json.loads(text)
        except Exception:
            return {"raw": text}

    def _extract_error_message(self, payload: Any, default: str) -> str:
        if isinstance(payload, dict):
            for key in ("message", "detail", "error"):
                value = payload.get(key)
                if isinstance(value, str) and value.strip():
                    return value
        if isinstance(payload, str) and payload.strip():
            return payload
        return default

    def _contains_critical(self, value: Any) -> bool:
        if isinstance(value, dict):
            for item in value.values():
                if self._contains_critical(item):
                    return True
            return False

        if isinstance(value, list):
            for item in value:
                if self._contains_critical(item):
                    return True
            return False

        if isinstance(value, str):
            return value.strip().upper() == "CRITICAL"

        return False


class LuminaClient(Lumina):
    """Backward-compatible alias for existing imports."""

