from __future__ import annotations

import sys
from pathlib import Path

SDK_ROOT = Path(__file__).resolve().parents[1]
if str(SDK_ROOT) not in sys.path:
    sys.path.insert(0, str(SDK_ROOT))

from lumina_sdk import Lumina
import lumina_sdk.client as client_module


class _DummyResponse:
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def read(self):
        return b"{}"


def test_track_enqueues_event(tmp_path):
    sdk = Lumina(
        api_key="test-key",
        trader_id="TR_001",
        org_id="org_demo_001",
        auto_start=False,
        storage_dir=str(tmp_path),
    )

    event_id = sdk.track({"type": "planned_entry"})
    assert sdk.queue.size == 1

    batch = sdk.queue.get_batch()
    assert len(batch) == 1
    assert batch[0]["id"] == event_id


def test_request_sends_org_header(monkeypatch, tmp_path):
    captured = {}

    def _fake_urlopen(request, timeout=0):
        captured["headers"] = dict(request.header_items())
        return _DummyResponse()

    monkeypatch.setattr(client_module, "urlopen", _fake_urlopen)

    sdk = Lumina(
        api_key="test-key",
        trader_id="TR_001",
        org_id="org_demo_001",
        auto_start=False,
        storage_dir=str(tmp_path),
    )

    sdk.get_health()

    headers = {k.lower(): v for k, v in captured["headers"].items()}
    assert headers.get("x-org-id") == "org_demo_001"
