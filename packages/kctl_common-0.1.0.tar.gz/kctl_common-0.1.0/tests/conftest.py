"""Shared test configuration."""
