"""Decay engine."""
