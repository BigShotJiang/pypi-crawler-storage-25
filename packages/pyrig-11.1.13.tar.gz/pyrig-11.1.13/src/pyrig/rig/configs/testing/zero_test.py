"""Configuration for test_zero.py placeholder test.

Generates test_zero.py with empty test_zero() function to ensure pytest runs
successfully even when no other tests exist. Triggers pyrig's scoped fixtures.

See Also:
    pyrig.rig.tests.fixtures
"""

from pyrig.rig.configs.base.python_test import PythonTestConfigFile


class ZeroTestConfigFile(PythonTestConfigFile):
    '''Manages test_zero.py.

    Generates test_zero.py with empty test_zero() function to ensure pytest runs
    successfully even when no other tests exist. Triggers pyrig's scoped fixtures.

    Examples:
        Generate test_zero.py::

            ZeroTestConfigFile.I.validate()

        Generated test::

            """Contains an empty test."""

            def test_zero() -> None:
                """Empty test.

                Exists so that when no tests are written yet the base
                fixtures are executed.
                """

    See Also:
        pyrig.rig.tests.fixtures
        pyrig.rig.configs.testing.main_test.MainTestConfigFile
    '''

    def stem(self) -> str:
        """Return the filename stem."""
        return "test_zero"

    def lines(self) -> list[str]:
        """Get the placeholder test content.

        Returns:
            List of lines with empty test function.
        """
        return [
            '"""Contains an empty test."""',
            "",
            "",
            "def test_zero() -> None:",
            '    """Empty test.',
            "",
            "    Exists so that when no tests are written yet the base fixtures are executed.",  # noqa: E501
            '    """',
            "",
        ]
