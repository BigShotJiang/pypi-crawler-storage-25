"""
Shortcuts tests package.
"""
