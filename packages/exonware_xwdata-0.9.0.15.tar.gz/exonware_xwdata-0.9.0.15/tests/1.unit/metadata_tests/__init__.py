"""
Metadata tests package.
"""
