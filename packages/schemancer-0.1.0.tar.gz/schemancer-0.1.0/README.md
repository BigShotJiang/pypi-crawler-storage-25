# schemancer

`schemancer` scans a flat folder of CSV, TSV, and Parquet files, infers a
registry, adds conservative relationship hints, and generates a standalone
Python package with SQLAlchemy models and load helpers.

## CLI

```bash
schemancer scan <source-dir> --registry-out <path>
schemancer infer-relationships <registry-path>
schemancer generate <registry-path> --output-dir <dir> --package-name <name>
schemancer build <source-dir> --output-dir <dir> --package-name <name>
```

## Example With `test_data`

From the repo root:

```bash
schemancer scan --registry-out new_schema ~/CODE/schemancer/test_data
```

If `new_schema` is an existing directory, this writes:

```text
new_schema/registry.json
```

Then infer relationships into the same file:

```bash
schemancer infer-relationships new_schema/registry.json
```

Generate a standalone package:

```bash
schemancer generate new_schema/registry.json --output-dir generated --package-name my_schema
```

Or do the whole flow in one command:

```bash
schemancer build /Users/z3061723/Documents/CODE/schemancer/test_data --output-dir generated --package-name my_schema
```

After generation, the package will be at:

```text
generated/my_schema
```

## Development

```bash
uv run --extra dev pytest
```
