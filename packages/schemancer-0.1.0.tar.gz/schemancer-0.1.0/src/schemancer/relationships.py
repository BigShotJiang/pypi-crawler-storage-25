from __future__ import annotations

from pathlib import Path

from .profiling import load_normalised_dataframe
from .registry import Registry, RelationshipCandidate, TableProfile
from .utils import split_multi_value


def _value_set(table: TableProfile, column_name: str) -> set[str]:
    path = Path(table.source.path)
    df = load_normalised_dataframe(
        path,
        table.source.format,
        table.source.delimiter,
        table.source.encoding,
    )
    if column_name not in df.columns:
        return set()
    values = set()
    for raw in df[column_name].dropna().tolist():
        values.add(str(raw).strip())
    values.discard("")
    return values


def _multi_value_set(table: TableProfile, column_name: str) -> set[str]:
    path = Path(table.source.path)
    df = load_normalised_dataframe(
        path,
        table.source.format,
        table.source.delimiter,
        table.source.encoding,
    )
    if column_name not in df.columns:
        return set()
    values: set[str] = set()
    for raw in df[column_name].dropna().tolist():
        values.update(split_multi_value(raw))
    return values


def _overlap_ratio(left: set[str], right: set[str]) -> float:
    if not left or not right:
        return 0.0
    return len(left & right) / min(len(left), len(right))


def infer_relationships(registry: Registry) -> Registry:
    candidates: list[RelationshipCandidate] = []
    tables = list(registry.tables.values())

    for source in tables:
        for target in tables:
            if source.table_name == target.table_name:
                continue
            if target.row_hash_fallback or len(target.merge_key_columns) != 1:
                continue

            target_key = target.merge_key_columns[0]
            target_values = _value_set(target, target_key)
            target_profile = target.columns[target_key]
            if target_profile.nullable or target_profile.distinct_count != target.row_count:
                continue

            for column_name, column in source.columns.items():
                if column_name in source.denormalised_columns:
                    continue
                if column_name != target_key:
                    continue
                overlap = _overlap_ratio(_value_set(source, column_name), target_values)
                if overlap < 0.8:
                    continue
                candidates.append(
                    RelationshipCandidate(
                        source_table=source.table_name,
                        source_columns=[column_name],
                        target_table=target.table_name,
                        target_columns=[target_key],
                        kind="direct",
                        cardinality_hint="many_to_one",
                        confidence=round(0.7 + min(overlap, 1.0) * 0.25, 3),
                        evidence_summary={
                            "overlap_ratio": round(overlap, 3),
                            "source_distinct_count": source.columns[column_name].distinct_count,
                            "target_distinct_count": target_profile.distinct_count,
                            "target_unique_non_null": True,
                        },
                    )
                )

            for group in source.normalisation_groups:
                if len(group.columns) != 1:
                    continue
                group_key = group.columns[0]
                if group_key != target_key:
                    continue
                overlap = _overlap_ratio(_multi_value_set(source, group_key), target_values)
                if overlap < 0.6:
                    continue
                candidates.append(
                    RelationshipCandidate(
                        source_table=source.table_name,
                        source_columns=[group_key],
                        target_table=target.table_name,
                        target_columns=[target_key],
                        kind="denormalised_map",
                        cardinality_hint="many_to_many",
                        confidence=round(0.6 + min(overlap, 1.0) * 0.3, 3),
                        evidence_summary={
                            "overlap_ratio": round(overlap, 3),
                            "group_columns": group.columns,
                            "target_unique_non_null": True,
                        },
                    )
                )

    registry.relationship_candidates = sorted(
        candidates,
        key=lambda candidate: (
            candidate.source_table,
            candidate.target_table,
            candidate.source_columns,
        ),
    )
    return registry
