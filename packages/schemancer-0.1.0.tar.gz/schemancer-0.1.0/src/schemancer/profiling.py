from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from itertools import combinations
from pathlib import Path
from typing import Any

import pandas as pd
import pyarrow.dataset as ds

from .discovery import discover_sources
from .registry import (
    ColumnProfile,
    MergeKeyCandidate,
    NormalisationGroup,
    Registry,
    TableProfile,
)
from .utils import (
    BOOLEAN_LIKE,
    canonicalise_scalar,
    identifier_name_score,
    normalise_column_name,
    split_multi_value,
    table_to_class,
)

STRING_LENGTH_THRESHOLD = 255
SAMPLE_LIMIT = 8


@dataclass
class ColumnAccumulator:
    source_names: set[str] = field(default_factory=set)
    distinct_values: set[str] = field(default_factory=set)
    sample_values: list[str] = field(default_factory=list)
    null_count: int = 0
    non_null_count: int = 0
    max_length: int = 0
    bool_like: bool = True
    int_like: bool = True
    float_like: bool = True
    datetime_like_hits: int = 0
    datetime_like_total: int = 0
    identifier_value_hits: int = 0
    identifier_value_total: int = 0
    multi_value_hits: int = 0

    def add(self, value: Any, *, source_name: str) -> None:
        self.source_names.add(source_name)
        scalar = canonicalise_scalar(value)
        if scalar is None:
            self.null_count += 1
            return

        self.non_null_count += 1
        text = str(scalar)
        self.max_length = max(self.max_length, len(text))
        self.distinct_values.add(text)
        if len(self.sample_values) < SAMPLE_LIMIT and text not in self.sample_values:
            self.sample_values.append(text)

        lower = text.lower()
        if lower not in BOOLEAN_LIKE:
            self.bool_like = False
        if not _is_int_string(text):
            self.int_like = False
        if not _is_float_string(text):
            self.float_like = False

        self.datetime_like_total += 1
        if _looks_like_datetime(text):
            self.datetime_like_hits += 1

        self.identifier_value_total += 1
        if _looks_like_identifier_value(text):
            self.identifier_value_hits += 1

        if _looks_denormalised_text(text):
            self.multi_value_hits += 1


def _is_int_string(value: str) -> bool:
    if value.startswith(("+", "-")):
        value = value[1:]
    return value.isdigit()


def _is_float_string(value: str) -> bool:
    try:
        float(value)
    except ValueError:
        return False
    return True


def _looks_like_datetime(value: str) -> bool:
    if not any(char in value for char in "-/:T "):
        return False
    parsed = pd.to_datetime(pd.Series([value]), errors="coerce")
    return bool(parsed.notna().iloc[0])


def _looks_like_identifier_value(value: str) -> bool:
    if len(value) <= 2:
        return False
    if value.isdigit():
        return True
    if any(char.isdigit() for char in value) and any(char.isalpha() for char in value):
        return True
    if "_" in value or "-" in value:
        return True
    return False


def _looks_denormalised_text(value: str) -> bool:
    if "|" not in value and ";" not in value:
        return False
    parts = split_multi_value(value)
    return len(parts) >= 2


def _iter_batches(
    path: Path,
    fmt: str,
    delimiter: str | None,
    encoding: str | None,
    chunksize: int = 5_000,
):
    if fmt in {"csv", "tsv"}:
        reader = pd.read_csv(
            path,
            sep=delimiter or ",",
            chunksize=chunksize,
            dtype=str,
            encoding=encoding or "utf-8",
            keep_default_na=False,
            na_values=["", "NA", "N/A", "None", "null"],
        )
        yield from reader
        return

    dataset = ds.dataset(path, format="parquet")
    for batch in dataset.to_batches(batch_size=chunksize):
        yield batch.to_pandas()


def load_normalised_dataframe(
    path: Path,
    fmt: str,
    delimiter: str | None,
    encoding: str | None,
) -> pd.DataFrame:
    frames = []
    for batch in _iter_batches(path, fmt, delimiter, encoding):
        frames.append(normalise_dataframe(batch))
    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def normalise_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    renamed: dict[str, str] = {}
    for column in df.columns:
        renamed[str(column)] = normalise_column_name(str(column))
    out = df.rename(columns=renamed).copy()
    return out


def infer_logical_type(acc: ColumnAccumulator) -> str:
    if acc.non_null_count == 0:
        return "String"
    if acc.bool_like:
        return "Boolean"
    if acc.int_like:
        return "Integer"
    if acc.float_like and not acc.int_like:
        return "Float"
    if acc.datetime_like_total and acc.datetime_like_hits / acc.datetime_like_total >= 0.9:
        return "DateTime"
    return "Text" if acc.max_length > STRING_LENGTH_THRESHOLD else "String"


def infer_identifier_likeness(name: str, acc: ColumnAccumulator) -> float:
    name_score = identifier_name_score(name)
    value_score = (
        acc.identifier_value_hits / acc.identifier_value_total
        if acc.identifier_value_total
        else 0.0
    )
    return round((name_score * 0.6) + (value_score * 0.4), 3)


def infer_denormalised_columns(columns: dict[str, ColumnProfile]) -> list[str]:
    return sorted(
        [
            column.name
            for column in columns.values()
            if column.looks_denormalised
            and column.logical_type in {"String", "Text"}
        ]
    )


def infer_normalisation_groups(df: pd.DataFrame, denormalised_columns: list[str]) -> list[NormalisationGroup]:
    if not denormalised_columns:
        return []

    token_counts: dict[str, list[int]] = {}
    for column in denormalised_columns:
        counts: list[int] = []
        for value in df[column].tolist() if column in df.columns else []:
            parts = split_multi_value(value)
            counts.append(len(parts))
        token_counts[column] = counts

    adjacency: dict[str, set[str]] = defaultdict(set)
    for left, right in combinations(denormalised_columns, 2):
        prefix_left = "_".join(left.split("_")[:-1])
        prefix_right = "_".join(right.split("_")[:-1])
        if not prefix_left or prefix_left != prefix_right:
            continue
        if token_counts[left] and token_counts[left] == token_counts[right]:
            adjacency[left].add(right)
            adjacency[right].add(left)

    visited: set[str] = set()
    groups: list[NormalisationGroup] = []
    for column in denormalised_columns:
        if column in visited:
            continue
        stack = [column]
        component: list[str] = []
        while stack:
            item = stack.pop()
            if item in visited:
                continue
            visited.add(item)
            component.append(item)
            stack.extend(sorted(adjacency[item] - visited))
        groups.append(NormalisationGroup(columns=sorted(component)))
    return groups


def infer_merge_keys(df: pd.DataFrame, columns: dict[str, ColumnProfile], denormalised_columns: list[str]) -> tuple[list[MergeKeyCandidate], list[str], bool]:
    if df.empty:
        return [], [], True

    eligible = [
        column.name
        for column in columns.values()
        if column.name not in denormalised_columns
        and column.logical_type in {"Integer", "Boolean", "DateTime", "String"}
        and column.logical_type != "Text"
    ]

    candidates: list[MergeKeyCandidate] = []

    for column_name in eligible:
        series = df[column_name]
        if series.isna().any():
            continue
        if series.duplicated().any():
            continue
        score = min(0.99, 0.65 + columns[column_name].identifier_likeness * 0.3)
        candidates.append(
            MergeKeyCandidate(
                columns=[column_name],
                score=round(score, 3),
                reason="single non-null unique column",
            )
        )

    ranked = sorted(
        eligible,
        key=lambda name: (columns[name].identifier_likeness, -columns[name].max_length),
        reverse=True,
    )[:5]

    for size in (2, 3):
        for combo in combinations(ranked, size):
            subset = df[list(combo)]
            if subset.isna().any(axis=1).any():
                continue
            if subset.duplicated().any():
                continue
            avg_id_score = sum(columns[name].identifier_likeness for name in combo) / len(combo)
            score = min(0.97, 0.7 + avg_id_score * 0.2 - (size - 1) * 0.03)
            candidates.append(
                MergeKeyCandidate(
                    columns=list(combo),
                    score=round(score, 3),
                    reason="composite non-null unique columns",
                )
            )

    candidates.sort(key=lambda candidate: (candidate.score, -len(candidate.columns)), reverse=True)
    if candidates and candidates[0].score >= 0.72:
        chosen = candidates[0].columns
        return candidates, chosen, False
    return candidates, [], True


def profile_table(source) -> TableProfile:
    path = Path(source.path)
    accumulators: dict[str, ColumnAccumulator] = defaultdict(ColumnAccumulator)
    row_count = 0

    for batch in _iter_batches(path, source.format, source.delimiter, source.encoding):
        batch = normalise_dataframe(batch)
        row_count += len(batch.index)
        for column in batch.columns:
            for value in batch[column].tolist():
                accumulators[column].add(value, source_name=str(column))

    df = load_normalised_dataframe(path, source.format, source.delimiter, source.encoding)

    columns: dict[str, ColumnProfile] = {}
    for name, acc in accumulators.items():
        logical_type = infer_logical_type(acc)
        columns[name] = ColumnProfile(
            name=name,
            source_names=sorted(acc.source_names),
            logical_type=logical_type,  # type: ignore[arg-type]
            nullable=acc.null_count > 0,
            max_length=acc.max_length,
            distinct_count=len(acc.distinct_values),
            null_count=acc.null_count,
            non_null_count=acc.non_null_count,
            identifier_likeness=infer_identifier_likeness(name, acc),
            looks_denormalised=acc.multi_value_hits > 0,
            sample_values=acc.sample_values,
        )

    denormalised_columns = infer_denormalised_columns(columns)
    normalisation_groups = infer_normalisation_groups(df, denormalised_columns)
    candidate_merge_keys, merge_key_columns, row_hash_fallback = infer_merge_keys(
        df,
        columns,
        denormalised_columns,
    )

    return TableProfile(
        table_name=source.table_name,
        class_name=table_to_class(source.table_name),
        source=source,
        columns=columns,
        row_count=row_count,
        denormalised_columns=denormalised_columns,
        normalisation_groups=normalisation_groups,
        candidate_merge_keys=candidate_merge_keys,
        merge_key_columns=merge_key_columns,
        row_hash_fallback=row_hash_fallback,
    )


def scan_sources(source_dir: str | Path) -> Registry:
    sources, summary = discover_sources(source_dir)
    tables = {source.table_name: profile_table(source) for source in sources}
    return Registry(
        version="0.1",
        source_root=str(Path(source_dir).expanduser().resolve()),
        tables=tables,
        relationship_candidates=[],
        summary=summary,
    )
