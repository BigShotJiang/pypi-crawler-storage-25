from __future__ import annotations

import argparse
from pathlib import Path

from .codegen import build_package, generate_package
from .profiling import scan_sources
from .relationships import infer_relationships
from .registry import Registry


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="schemancer")
    subparsers = parser.add_subparsers(dest="command", required=True)

    scan_parser = subparsers.add_parser("scan")
    scan_parser.add_argument("source_dir")
    scan_parser.add_argument("--registry-out", required=True)

    rel_parser = subparsers.add_parser("infer-relationships")
    rel_parser.add_argument("registry_path")
    rel_parser.add_argument("--registry-out")

    generate_parser = subparsers.add_parser("generate")
    generate_parser.add_argument("registry_path")
    generate_parser.add_argument("--output-dir", required=True)
    generate_parser.add_argument("--package-name", required=True)

    build_parser = subparsers.add_parser("build")
    build_parser.add_argument("source_dir")
    build_parser.add_argument("--output-dir", required=True)
    build_parser.add_argument("--package-name", required=True)

    return parser


def main(argv: list[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)

    if args.command == "scan":
        registry = scan_sources(args.source_dir)
        registry.write_json(args.registry_out)
        return 0

    if args.command == "infer-relationships":
        registry = Registry.read_json(args.registry_path)
        infer_relationships(registry)
        registry.write_json(args.registry_out or args.registry_path)
        return 0

    if args.command == "generate":
        registry = Registry.read_json(args.registry_path)
        generate_package(registry, args.output_dir, args.package_name)
        return 0

    if args.command == "build":
        build_package(args.source_dir, args.output_dir, args.package_name)
        return 0

    return 1
