from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Literal

from .utils import json_dumps

LogicalType = Literal["Integer", "Float", "Boolean", "DateTime", "String", "Text"]
SourceFormat = Literal["csv", "tsv", "parquet"]
RelationshipKind = Literal["direct", "denormalised_map"]
CardinalityHint = Literal["many_to_one", "many_to_many"]


@dataclass
class SourceFileSpec:
    path: str
    file_name: str
    format: SourceFormat
    table_name: str
    delimiter: str | None = None
    encoding: str | None = None


@dataclass
class ColumnProfile:
    name: str
    source_names: list[str]
    logical_type: LogicalType
    nullable: bool
    max_length: int
    distinct_count: int
    null_count: int
    non_null_count: int
    identifier_likeness: float
    looks_denormalised: bool
    sample_values: list[str] = field(default_factory=list)


@dataclass
class MergeKeyCandidate:
    columns: list[str]
    score: float
    reason: str


@dataclass
class NormalisationGroup:
    columns: list[str]


@dataclass
class TableProfile:
    table_name: str
    class_name: str
    source: SourceFileSpec
    columns: dict[str, ColumnProfile]
    row_count: int
    denormalised_columns: list[str]
    normalisation_groups: list[NormalisationGroup]
    candidate_merge_keys: list[MergeKeyCandidate]
    merge_key_columns: list[str]
    row_hash_fallback: bool


@dataclass
class RelationshipCandidate:
    source_table: str
    source_columns: list[str]
    target_table: str
    target_columns: list[str]
    kind: RelationshipKind
    cardinality_hint: CardinalityHint
    confidence: float
    evidence_summary: dict[str, Any]


@dataclass
class GenerationDefaults:
    string_length_threshold: int = 255


@dataclass
class RegistrySummary:
    included_files: list[str]
    ignored_files: list[str]
    source_file_count: int
    table_count: int


@dataclass
class Registry:
    version: str
    source_root: str
    tables: dict[str, TableProfile]
    relationship_candidates: list[RelationshipCandidate]
    generation_defaults: GenerationDefaults = field(default_factory=GenerationDefaults)
    summary: RegistrySummary | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def to_json(self) -> str:
        return json_dumps(self.to_dict())

    @staticmethod
    def _resolve_output_path(path: str | Path) -> Path:
        resolved = Path(path)
        if resolved.exists() and resolved.is_dir():
            return resolved / "registry.json"
        if resolved.parent and not resolved.parent.exists():
            resolved.parent.mkdir(parents=True, exist_ok=True)
        return resolved

    def write_json(self, path: str | Path) -> Path:
        resolved = self._resolve_output_path(path)
        resolved.write_text(self.to_json(), encoding="utf-8")
        return resolved

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "Registry":
        tables: dict[str, TableProfile] = {}
        for table_name, table_raw in raw["tables"].items():
            columns = {
                column_name: ColumnProfile(**column_raw)
                for column_name, column_raw in table_raw["columns"].items()
            }
            tables[table_name] = TableProfile(
                table_name=table_raw["table_name"],
                class_name=table_raw["class_name"],
                source=SourceFileSpec(**table_raw["source"]),
                columns=columns,
                row_count=table_raw["row_count"],
                denormalised_columns=list(table_raw["denormalised_columns"]),
                normalisation_groups=[
                    NormalisationGroup(**group)
                    for group in table_raw.get("normalisation_groups", [])
                ],
                candidate_merge_keys=[
                    MergeKeyCandidate(**candidate)
                    for candidate in table_raw.get("candidate_merge_keys", [])
                ],
                merge_key_columns=list(table_raw["merge_key_columns"]),
                row_hash_fallback=bool(table_raw["row_hash_fallback"]),
            )

        summary_raw = raw.get("summary")
        summary = RegistrySummary(**summary_raw) if summary_raw else None

        return cls(
            version=raw["version"],
            source_root=raw["source_root"],
            tables=tables,
            relationship_candidates=[
                RelationshipCandidate(**candidate)
                for candidate in raw.get("relationship_candidates", [])
            ],
            generation_defaults=GenerationDefaults(**raw.get("generation_defaults", {})),
            summary=summary,
        )

    @classmethod
    def read_json(cls, path: str | Path) -> "Registry":
        import json

        return cls.from_dict(json.loads(Path(path).read_text(encoding="utf-8")))
