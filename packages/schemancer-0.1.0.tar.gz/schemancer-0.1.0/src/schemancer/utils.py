from __future__ import annotations

import json
import keyword
import re
from collections.abc import Iterable
from pathlib import Path
from typing import Any

PYTHON_KEYWORDS = set(keyword.kwlist)
RESERVED_COLUMN_NAMES = {"id", "_sg_row_hash"}
BOOLEAN_LIKE = {"true", "false", "t", "f", "yes", "no", "y", "n", "0", "1"}
IDENTIFIER_NAME_TOKENS = {"id", "key", "code", "uuid", "identifier", "name"}


def snake_case(value: str) -> str:
    text = value.strip()
    text = text.replace(".", "_").replace(" ", "_").replace("-", "_")
    text = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", text)
    text = re.sub(r"[^0-9A-Za-z_]+", "_", text)
    text = re.sub(r"_+", "_", text)
    return text.strip("_").lower() or "_"


def safe_identifier(
    value: str,
    *,
    reserved: set[str] | None = None,
) -> str:
    ident = snake_case(value)
    if ident and ident[0].isdigit():
        ident = f"_{ident}"
    if ident in PYTHON_KEYWORDS:
        ident = f"{ident}_field"
    if reserved and ident in reserved:
        ident = f"{ident}_field"
    return ident or "_"


def table_to_class(table_name: str) -> str:
    return "".join(part.capitalize() for part in snake_case(table_name).split("_"))


def normalise_table_name(file_name: str) -> str:
    base = Path(file_name).name
    parts = base.split(".")
    if len(parts) > 1:
        base = ".".join(parts[:-1])
    return safe_identifier(base)


def normalise_column_name(column_name: str) -> str:
    return safe_identifier(column_name, reserved=RESERVED_COLUMN_NAMES)


def split_multi_value(value: Any) -> list[str]:
    if value is None:
        return []
    text = str(value).strip()
    if not text or text.lower() in {"nan", "none", "<na>"}:
        return []
    parts = re.split(r"[|;]", text)
    return [part.strip() for part in parts if part.strip()]


def canonicalise_scalar(value: Any) -> Any:
    if value is None:
        return None
    text = str(value).strip()
    if text == "" or text.lower() in {"nan", "none", "<na>", "null"}:
        return None
    return text


def canonical_json_hash(payload: dict[str, Any]) -> str:
    import hashlib

    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def json_dumps(data: Any) -> str:
    return json.dumps(data, indent=2, sort_keys=True)


def shared_prefix(columns: Iterable[str]) -> str:
    pieces = [snake_case(col).split("_") for col in columns]
    if not pieces:
        return ""
    prefix: list[str] = []
    for parts in zip(*pieces):
        if len(set(parts)) != 1:
            break
        prefix.append(parts[0])
    return "_".join(prefix)


def identifier_name_score(name: str) -> float:
    parts = set(snake_case(name).split("_"))
    if not parts:
        return 0.0
    if parts & IDENTIFIER_NAME_TOKENS:
        return 1.0
    if len(parts) == 1 and "type" not in parts:
        return 0.35
    return 0.1
