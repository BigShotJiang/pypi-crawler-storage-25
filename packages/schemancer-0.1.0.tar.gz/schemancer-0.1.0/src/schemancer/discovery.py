from __future__ import annotations

import csv
from pathlib import Path

import chardet

from .registry import RegistrySummary, SourceFileSpec
from .utils import normalise_table_name

SUPPORTED_SUFFIXES = {
    ".csv": ("csv", ","),
    ".tsv": ("tsv", "\t"),
    ".parquet": ("parquet", None),
}


class DiscoveryError(ValueError):
    """Raised when source discovery finds an unsafe or ambiguous layout."""


def _detect_encoding(path: Path) -> str:
    detected = chardet.detect(path.read_bytes()[:8192])
    encoding = detected.get("encoding") or "utf-8"
    if encoding.lower() == "ascii":
        return "utf-8"
    return encoding


def _detect_delimiter(path: Path, encoding: str) -> str:
    sample = path.read_text(encoding=encoding, errors="replace")[:8192]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",\t;|")
        return str(dialect.delimiter)
    except csv.Error:
        first_line = sample.splitlines()[0] if sample else ""
        counts = {
            ",": first_line.count(","),
            "\t": first_line.count("\t"),
            ";": first_line.count(";"),
            "|": first_line.count("|"),
        }
        delimiter, _ = max(counts.items(), key=lambda item: item[1])
        return delimiter if counts[delimiter] > 0 else ","


def discover_sources(source_dir: str | Path) -> tuple[list[SourceFileSpec], RegistrySummary]:
    root = Path(source_dir).expanduser().resolve()
    if not root.exists() or not root.is_dir():
        raise DiscoveryError(f"Source directory does not exist: {root}")

    included: list[SourceFileSpec] = []
    ignored: list[str] = []
    seen_tables: dict[str, str] = {}

    for entry in sorted(root.iterdir(), key=lambda item: item.name.lower()):
        if not entry.is_file():
            ignored.append(entry.name)
            continue

        suffix = entry.suffix.lower()
        spec = SUPPORTED_SUFFIXES.get(suffix)
        if spec is None:
            ignored.append(entry.name)
            continue

        fmt, delimiter = spec
        encoding = None
        if suffix in {".csv", ".tsv"}:
            encoding = _detect_encoding(entry)
            delimiter = _detect_delimiter(entry, encoding)
            fmt = "tsv" if delimiter == "\t" else "csv"
        table_name = normalise_table_name(entry.name)

        if table_name in seen_tables:
            first = seen_tables[table_name]
            raise DiscoveryError(
                f"Normalised table-name collision for '{entry.name}' and '{first}' -> '{table_name}'"
            )
        seen_tables[table_name] = entry.name

        included.append(
            SourceFileSpec(
                path=str(entry),
                file_name=entry.name,
                format=fmt,  # type: ignore[arg-type]
                table_name=table_name,
                delimiter=delimiter,
                encoding=encoding,
            )
        )

    summary = RegistrySummary(
        included_files=[source.file_name for source in included],
        ignored_files=ignored,
        source_file_count=len(included),
        table_count=len(included),
    )
    return included, summary
