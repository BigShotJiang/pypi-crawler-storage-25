from __future__ import annotations

import importlib
import json
import sys
from pathlib import Path

import pandas as pd
import pytest
from sqlalchemy import create_engine, func, select
from sqlalchemy.orm import Session

from schemancer.cli import main as cli_main
from schemancer.codegen import build_package
from schemancer.discovery import DiscoveryError, discover_sources
from schemancer.profiling import scan_sources
from schemancer.registry import Registry
from schemancer.relationships import infer_relationships


def _write_test_dataset(root: Path) -> None:
    root.mkdir(parents=True, exist_ok=True)

    pd.DataFrame(
        {
            "Study Code": ["S1", "S2"],
            "Title": ["Study One", "Study Two"],
            "Start Date": ["2024-01-01", "2024-02-15"],
        }
    ).to_csv(root / "studies.tsv", sep="\t", index=False)

    pd.DataFrame(
        {
            "Condition Code": ["C1", "C2", "C3"],
            "Description": [
                "Condition one",
                "Condition two",
                "Condition three",
            ],
        }
    ).to_parquet(root / "conditions.parquet", index=False)

    pd.DataFrame(
        {
            "Variant Code": ["V1", "V2"],
            "Study Code": ["S1", "S2"],
            "Condition Code": ["C1|C2", "C2"],
            "Score": [1.5, 2.0],
            "Active": ["yes", "no"],
        }
    ).to_csv(root / "variants.csv", index=False)


def test_discovery_handles_mixed_flat_folder(tmp_path: Path) -> None:
    (tmp_path / "canonical.triples.csv").write_text("a,b\n1,2\n", encoding="utf-8")
    (tmp_path / "study eligibility.tsv").write_text("a\tb\n1\t2\n", encoding="utf-8")
    (tmp_path / "concept.csv").write_text("a\tb\n1\t2\n", encoding="utf-8")
    (tmp_path / "notes.txt").write_text("ignore me\n", encoding="utf-8")
    (tmp_path / "nested").mkdir()

    sources, summary = discover_sources(tmp_path)
    source_by_name = {source.file_name: source for source in sources}

    assert [source.table_name for source in sources] == [
        "canonical_triples",
        "concept",
        "study_eligibility",
    ]
    assert source_by_name["concept.csv"].format == "tsv"
    assert source_by_name["concept.csv"].delimiter == "\t"
    assert "notes.txt" in summary.ignored_files
    assert "nested" in summary.ignored_files


def test_discovery_rejects_colliding_normalised_names(tmp_path: Path) -> None:
    (tmp_path / "study.table.csv").write_text("a\n1\n", encoding="utf-8")
    (tmp_path / "study table.csv").write_text("a\n1\n", encoding="utf-8")

    with pytest.raises(DiscoveryError):
        discover_sources(tmp_path)


def test_scan_sources_infers_types_and_merge_keys(tmp_path: Path) -> None:
    _write_test_dataset(tmp_path)

    registry = scan_sources(tmp_path)
    variants = registry.tables["variants"]
    studies = registry.tables["studies"]

    assert variants.columns["score"].logical_type == "Float"
    assert variants.columns["active"].logical_type == "Boolean"
    assert studies.columns["start_date"].logical_type == "DateTime"
    assert variants.denormalised_columns == ["condition_code"]
    assert variants.merge_key_columns == ["variant_code"]
    assert studies.merge_key_columns == ["study_code"]
    assert variants.row_hash_fallback is False


def test_infer_relationships_is_conservative_and_detects_denorm_map(tmp_path: Path) -> None:
    _write_test_dataset(tmp_path)

    registry = infer_relationships(scan_sources(tmp_path))
    rels = {
        (rel.source_table, tuple(rel.source_columns), rel.target_table, rel.kind): rel
        for rel in registry.relationship_candidates
    }

    direct = rels[("variants", ("study_code",), "studies", "direct")]
    denorm = rels[("variants", ("condition_code",), "conditions", "denormalised_map")]

    assert direct.confidence >= 0.8
    assert denorm.confidence >= 0.6
    assert direct.evidence_summary["target_unique_non_null"] is True


def test_cli_round_trip_scan_infer_generate(tmp_path: Path) -> None:
    _write_test_dataset(tmp_path / "source")
    registry_path = tmp_path / "registry.json"
    output_dir = tmp_path / "generated"

    assert cli_main(["scan", str(tmp_path / "source"), "--registry-out", str(registry_path)]) == 0
    assert cli_main(["infer-relationships", str(registry_path)]) == 0
    assert cli_main(
        [
            "generate",
            str(registry_path),
            "--output-dir",
            str(output_dir),
            "--package-name",
            "generated_schema",
        ]
    ) == 0

    raw = json.loads(registry_path.read_text(encoding="utf-8"))
    assert "relationship_candidates" in raw
    assert (output_dir / "generated_schema" / "src" / "generated_schema" / "models.py").exists()


def test_generated_package_loads_into_sqlite_end_to_end(tmp_path: Path) -> None:
    orm_loader_src = Path("/Users/z3061723/Documents/CODE/orm-loader/src")
    if not orm_loader_src.exists():
        pytest.skip("Local orm-loader checkout is not available")

    source_dir = tmp_path / "source"
    _write_test_dataset(source_dir)
    registry, package_root = build_package(source_dir, tmp_path / "dist", "generated_schema")

    assert registry.tables["variants"].merge_key_columns == ["variant_code"]
    assert (package_root / "src" / "generated_schema" / "registry.json").exists()

    sys.path.insert(0, str(package_root / "src"))
    sys.path.insert(0, str(orm_loader_src))
    try:
        generated_schema = importlib.import_module("generated_schema.schema")
        models = importlib.import_module("generated_schema.models")

        engine = create_engine("sqlite:///:memory:")
        generated_schema.create_all(engine)

        with Session(engine) as session:
            first = generated_schema.load_all(session, source_dir, merge_strategy="replace")
            second = generated_schema.load_all(session, source_dir, merge_strategy="replace")

            assert first["variants"] == 2
            assert second["variants"] == 2
            assert session.scalar(select(func.count(models.Studies.id))) == 2
            assert session.scalar(select(func.count(models.Conditions.id))) == 3
            assert session.scalar(select(func.count(models.Variants.id))) == 2
            assert session.scalar(select(func.count(models.VariantsConditionCodeMap.parent_id))) == 3

            variant = session.execute(
                select(models.Variants).where(models.Variants.variant_code == "V1")
            ).scalar_one()
            assert variant.study_code_studies_obj is not None
            assert sorted(condition.condition_code for condition in variant.condition_code_conditions_objects) == [
                "C1",
                "C2",
            ]
    finally:
        sys.path.remove(str(package_root / "src"))
        sys.path.remove(str(orm_loader_src))
        for name in [
            "generated_schema",
            "generated_schema.base",
            "generated_schema.models",
            "generated_schema.schema",
            "generated_schema.cli",
        ]:
            sys.modules.pop(name, None)


def test_registry_json_round_trip(tmp_path: Path) -> None:
    _write_test_dataset(tmp_path)
    registry = infer_relationships(scan_sources(tmp_path))
    path = tmp_path / "registry.json"
    registry.write_json(path)

    loaded = Registry.read_json(path)

    assert loaded.tables["studies"].merge_key_columns == ["study_code"]
    assert len(loaded.relationship_candidates) == len(registry.relationship_candidates)


def test_registry_write_json_supports_directory_output(tmp_path: Path) -> None:
    _write_test_dataset(tmp_path / "source")
    registry = scan_sources(tmp_path / "source")
    out_dir = tmp_path / "new_schema"
    out_dir.mkdir()

    written = registry.write_json(out_dir)

    assert written == out_dir / "registry.json"
    assert written.exists()
    loaded = Registry.read_json(written)
    assert set(loaded.tables) == set(registry.tables)
