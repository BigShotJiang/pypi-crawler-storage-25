from .timeline_db import TimelineDB

class ExoContext:
    def __init__(self, db: TimelineDB):
        self.db = db

    def build_from_query(self, query: str) -> str:
        results = self.db.search_text(query)
        if not results:
            return ""
        
        context_lines = []
        for res in results:
            context_lines.append(f"[{res['source']}] {res['content']}")
            
        return "\n".join(context_lines)
