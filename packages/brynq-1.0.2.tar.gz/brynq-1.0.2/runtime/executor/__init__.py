"""
Runtime Plan Executor — Dumb-but-reliable execution engine.

Receives signed execution plans from Brynq Cloud and executes them step by step.
Routes each step to the correct bridge (local/cloud/agent), captures outputs,
and reports metadata (never content) back to the cloud.

This runs on the user's machine. It is deliberately simple and robust.
"""

from .plan_executor import (
    ExecutionPlan,
    ExecutionStep,
    ExecutionResult,
    StepResult,
    PlanExecutor,
    validate_signature,
    validate_ttl,
    sign_plan,
)
from .context import resolve_context
from .local_bridge import LocalBridge, BridgeResponse
from .cloud_bridge import CloudBridge
from .agent_bridge import AgentBridge

# plan_validator depends on cloud-side modules that may not be present on the
# runtime yet.  Import defensively so the rest of the package stays usable.
try:
    from .plan_validator import (
        validate_plan,
        PlanValidationError,
        PlanExpiredError,
        PlanTamperedError,
    )
except ImportError:
    pass

__all__ = [
    "ExecutionPlan",
    "ExecutionStep",
    "ExecutionResult",
    "StepResult",
    "PlanExecutor",
    "resolve_context",
    "LocalBridge",
    "CloudBridge",
    "AgentBridge",
    "BridgeResponse",
    "validate_signature",
    "validate_ttl",
    "sign_plan",
    "validate_plan",
    "PlanValidationError",
    "PlanExpiredError",
    "PlanTamperedError",
]
