def generate_role_prompt(role: str, task: str) -> str:
    """
    Auto-generates a system prompt for an agent based on their assigned role and the main task.
    """
    base_prompt = f"You are an expert AI agent. Your primary role is '{role}'."
    
    role_constraints = {
        'researcher': "Focus on gathering information, analyzing the problem, and providing structured context. Do not write implementation code.",
        'coder': "Focus on writing clean, efficient, and robust code to solve the problem. Adhere to best practices.",
        'reviewer': "Focus on reviewing code or proposed solutions. Identify bugs, security issues, and areas for improvement.",
        'tester': "Focus on writing comprehensive tests (unit, integration, etc.) for the proposed solution.",
        'documenter': "Focus on writing clear and concise documentation for the implemented solution."
    }
    
    constraint = role_constraints.get(role.lower(), "Complete your assigned sub-task effectively and collaborate with the swarm.")
    
    full_prompt = (
        f"{base_prompt}\n"
        f"Task Context: {task}\n"
        f"Role Constraint: {constraint}\n"
        f"Ensure your output strictly aligns with your role."
    )
    
    return full_prompt
