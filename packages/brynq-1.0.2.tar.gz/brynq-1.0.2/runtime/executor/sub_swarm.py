import uuid
from typing import List, Dict, Any
from .dynamic_roles import generate_role_prompt

class SubSwarmManager:
    def __init__(self):
        self.swarm_id = str(uuid.uuid4())
        
    def delegate_task(self, task: str, num_agents: int) -> List[Dict[str, Any]]:
        """
        Splits a task into sub-tasks and assigns roles.
        """
        sub_tasks = []
        if num_agents <= 0:
            return sub_tasks
            
        roles = ['researcher', 'coder', 'reviewer', 'tester', 'documenter']
        
        for i in range(num_agents):
            role = roles[i % len(roles)]
            sub_task = {
                "task_id": f"{self.swarm_id}-{i}",
                "role": role,
                "description": f"{role.capitalize()} part of: {task}",
                "system_prompt": generate_role_prompt(role, task)
            }
            sub_tasks.append(sub_task)
            
        return sub_tasks

    def synthesize_results(self, results: List[str]) -> str:
        """
        Combines the outputs of multiple agents into a single result.
        """
        if not results:
            return "No results to synthesize."
            
        synthesized = "Synthesized Swarm Results:\n"
        for i, res in enumerate(results):
            synthesized += f"--- Result {i+1} ---\n{res}\n"
        synthesized += "--- End of Synthesis ---"
        
        return synthesized
