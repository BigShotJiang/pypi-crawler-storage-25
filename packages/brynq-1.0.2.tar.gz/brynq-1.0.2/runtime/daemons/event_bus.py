import threading
from collections import defaultdict

class EventBus:
    def __init__(self):
        self._subscribers = defaultdict(list)
        self._lock = threading.Lock()

    def subscribe(self, event_type, handler):
        with self._lock:
            self._subscribers[event_type].append(handler)

    def publish(self, event_type, data):
        with self._lock:
            handlers = list(self._subscribers.get(event_type, []))
        
        for handler in handlers:
            try:
                threading.Thread(target=handler, args=(data,), daemon=True).start()
            except Exception:
                pass
