"""
Brynq Runtime — The Hands.

Executes plans created by the cloud. Never decides what to do —
only how to do it (call Ollama, call Claude, call an agent).

Subpackages:
    executor — Plan validation, step-by-step execution
    vault    — Local encrypted key storage (user's API keys)
    reporter — Execution metadata telemetry (timing, tokens, no content)
    sandbox  — Filesystem + network isolation for local agents
"""
