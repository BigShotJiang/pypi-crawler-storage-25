class ScreenObserver:
    def __init__(self):
        self.frame_count = 0

    def capture_frame(self):
        self.frame_count += 1
        # Mocking a frame as a 2D list
        return [[self.frame_count, self.frame_count], [self.frame_count, self.frame_count]]

    def detect_changes(self, old_frame, new_frame):
        if not old_frame or not new_frame:
            return True
        
        if len(old_frame) != len(new_frame):
            return True
            
        for row_idx in range(len(old_frame)):
            if len(old_frame[row_idx]) != len(new_frame[row_idx]):
                return True
            for col_idx in range(len(old_frame[row_idx])):
                if old_frame[row_idx][col_idx] != new_frame[row_idx][col_idx]:
                    return True
        return False
