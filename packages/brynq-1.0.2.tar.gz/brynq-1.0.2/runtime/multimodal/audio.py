class AudioStreamer:
    def __init__(self):
        self.is_listening = False
        self.processed_chunks = 0

    def start_listening(self):
        self.is_listening = True
        return "Started listening to audio stream."

    def stop_listening(self):
        self.is_listening = False
        return "Stopped listening to audio stream."

    def process_chunk(self, chunk: bytes) -> dict:
        if not self.is_listening:
            raise RuntimeError("Cannot process chunk: not listening.")
        
        self.processed_chunks += 1
        return {
            "chunk_size": len(chunk),
            "status": "processed",
            "chunk_index": self.processed_chunks
        }
