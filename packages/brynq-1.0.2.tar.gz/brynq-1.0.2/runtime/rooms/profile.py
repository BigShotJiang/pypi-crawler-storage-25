import os
import json
from typing import Dict, Any

PROFILE_FILE = os.path.expanduser("~/.brynq/profile.json")

class LocalProfileManager:
    def __init__(self):
        self.profile = {
            "user_id": "",
            "username": "LocalUser",
            "bio": "",
            "visibility": {"models": True, "compute": False, "bio": True}
        }
        self.load()

    def load(self):
        if os.path.exists(PROFILE_FILE):
            try:
                with open(PROFILE_FILE, "r") as f:
                    self.profile.update(json.load(f))
            except Exception:
                pass
        else:
            self.save()

    def save(self):
        os.makedirs(os.path.dirname(PROFILE_FILE), exist_ok=True)
        with open(PROFILE_FILE, "w") as f:
            json.dump(self.profile, f, indent=2)

    def get(self) -> Dict[str, Any]:
        return self.profile

    def update(self, **kwargs):
        for k, v in kwargs.items():
            if k == "visibility" and isinstance(v, dict):
                self.profile["visibility"].update(v)
            else:
                self.profile[k] = v
        self.save()

local_profile = LocalProfileManager()
