from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
import time
import uuid

@dataclass
class Member:
    user_id: str
    username: str
    role: str = "member"  # "admin" | "member"
    status: str = "online"  # "online" | "away" | "offline"
    models: List[str] = field(default_factory=list)
    compute: Dict[str, Any] = field(default_factory=dict)
    joined_at: str = field(default_factory=lambda: time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))

@dataclass
class Room:
    room_id: str
    host_id: str
    host_address: str
    name: str = "Unnamed Room"
    room_code: str = ""
    members: List[Member] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
    max_members: int = 10
    ttl: int = 86400  # 24 hours in seconds

@dataclass
class Profile:
    user_id: str
    username: str
    online: bool = False
    bio: str = ""
    models: List[str] = field(default_factory=list)
    compute: Dict[str, Any] = field(default_factory=dict)
    rooms_hosted: int = 0
    visibility: Dict[str, bool] = field(default_factory=lambda: {"models": True, "compute": False, "bio": True})

@dataclass
class ChatMessage:
    room_id: str
    sender_id: str
    sender_name: str
    content: str
    type: str = "chat"  # "chat" | "command" | "system"
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: str = field(default_factory=lambda: time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))

@dataclass
class TaskEvent:
    room_id: str
    task_id: str
    assigned_to: str
    model: str
    result: str = ""
    status: str = "dispatched"  # "dispatched" | "running" | "completed" | "failed"
    progress: float = 0.0
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
