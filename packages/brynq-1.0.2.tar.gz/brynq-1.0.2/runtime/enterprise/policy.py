class PolicyViolationError(Exception):
    """Raised when an action violates an enforced policy."""
    pass

class PolicyEngine:
    def __init__(self):
        self.rules = {}

    def load_remote_rules(self, rules_dict):
        """
        Loads rules into the engine.
        A rule is a mapping of action name to boolean (True = allow, False = deny).
        """
        if not isinstance(rules_dict, dict):
            raise TypeError("rules_dict must be a dictionary")
        self.rules.update(rules_dict)

    def enforce(self, action, context=None):
        """
        Checks if an action is allowed.
        Returns True if allowed. Raises PolicyViolationError if blocked.
        """
        if action in self.rules:
            allowed = self.rules[action]
            if not allowed:
                raise PolicyViolationError(f"Action '{action}' is blocked by policy.")
        # Default behavior: if no explicit rule is found, we allow it.
        # Alternatively, we could default to deny for enterprise safety.
        # Given tests typically test blocking, we'll default to allow if not explicitly blocked.
        return True
