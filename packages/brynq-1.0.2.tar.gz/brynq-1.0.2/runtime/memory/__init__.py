"""Brynq persistent memory subsystem — all data stays local."""
from typing import Any

def __getattr__(name: str) -> Any:
    import importlib
    if name == "VectorStore":
        return getattr(importlib.import_module(".vector_store", __name__), "VectorStore")
    if name == "ProjectMemory":
        return getattr(importlib.import_module(".project", __name__), "ProjectMemory")
    if name == "ConversationMemory":
        return getattr(importlib.import_module(".conversation", __name__), "ConversationMemory")
    if name == "PeopleMemory":
        return getattr(importlib.import_module(".people", __name__), "PeopleMemory")
    if name == "DecisionMemory":
        return getattr(importlib.import_module(".decision", __name__), "DecisionMemory")
    if name == "OutcomeMemory":
        return getattr(importlib.import_module(".outcome", __name__), "OutcomeMemory")
    if name == "MemoryManager":
        return getattr(importlib.import_module(".manager", __name__), "MemoryManager")
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
