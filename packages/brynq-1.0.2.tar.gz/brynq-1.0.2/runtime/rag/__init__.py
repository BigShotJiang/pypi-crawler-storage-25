# Re-export the public API from the original rag module so existing
# imports (``from runtime.rag import add_file, query, ...``) keep working.
from runtime.rag.tfidf import (  # noqa: F401
    add_file,
    build_context,
    list_files,
    query,
    remove_file,
    _tokenize,
    _compute_tf,
    _cosine_similarity,
)
