# Brynq v0.420.69
__version__ = '0.420.69'
BUILD_DATE = '2026-03-28'

def get_version():
    return __version__
