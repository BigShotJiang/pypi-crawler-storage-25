from .empathy import UserState

class CadenceAdjuster:
    def modify_prompt(self, prompt: str, state: str) -> str:
        if state == UserState.FRUSTRATED.value:
            directive = "[Cadence Directive: The user appears frustrated. Provide clear, direct, and empathetic responses. Do not lecture. Prioritize immediate solutions.]\n"
            return directive + prompt
        elif state == UserState.EXPLORING.value:
            directive = "[Cadence Directive: The user is in an exploratory mood. Provide open-ended suggestions, encourage their ideas, and expand on possibilities.]\n"
            return directive + prompt
        else:
            return prompt
