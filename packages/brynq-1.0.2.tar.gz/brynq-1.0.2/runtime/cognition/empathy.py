from enum import Enum
import re

class UserState(Enum):
    FRUSTRATED = "FRUSTRATED"
    EXPLORING = "EXPLORING"
    NEUTRAL = "NEUTRAL"

class UserStateDetector:
    def __init__(self):
        self.frustrated_keywords = [
            r"\b(ugh|annoying|stupid|fail|error|broken|fix|shit|fuck|damn|hate)\b",
            r"\b(why isn't this working|this is taking too long|i am getting tired|crap)\b"
        ]
        self.exploring_keywords = [
            r"\b(what if|maybe|how about|could we|explore|try|experiment|i wonder|how does)\b",
            r"\b(perhaps|curious)\b"
        ]
        self.frustrated_pattern = re.compile("|".join(self.frustrated_keywords), re.IGNORECASE)
        self.exploring_pattern = re.compile("|".join(self.exploring_keywords), re.IGNORECASE)

    def analyze_sentiment(self, history: str) -> str:
        if self.frustrated_pattern.search(history):
            return UserState.FRUSTRATED.value
        if self.exploring_pattern.search(history):
            return UserState.EXPLORING.value
        return UserState.NEUTRAL.value
