"""
Brynq Runtime — Execution Reporter.

Reports execution metadata (timing, token counts, success/failure) back to
the Brynq Cloud for quality improvement. NEVER sends user content, model
outputs, prompts, or API keys.

Submodules:
    privacy  — Whitelist-based sanitization that strips anything potentially user-related
    metrics  — Batched, retry-safe report submission to cloud
"""

from .privacy import sanitize_report, SanitizedReport
from .metrics import ExecutionReporter, StepMetrics, PlanMetrics

__all__ = [
    "sanitize_report",
    "SanitizedReport",
    "ExecutionReporter",
    "StepMetrics",
    "PlanMetrics",
]
