import requests
from typing import List, Dict, Any

class GlobalKnowledgeBase:
    def __init__(self, endpoint: str = "https://api.brynq.ai/v1/search"):
        self.endpoint = endpoint

    def query_global_mind(self, query: str) -> List[Dict[str, Any]]:
        """
        Query the global mind using the provided endpoint.
        """
        response = requests.post(self.endpoint, json={"query": query})
        response.raise_for_status()
        return response.json().get("results", [])
