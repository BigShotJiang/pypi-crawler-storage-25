class TerraformGenerator:
    """Generates Terraform configurations."""

    def generate_aws_stack(self, services: list[str]) -> str:
        """Generates HCL syntax for an AWS stack based on requested services."""
        blocks = [
            'provider "aws" {',
            '  region = "us-east-1"',
            '}'
        ]
        
        for i, service in enumerate(services):
            if service.lower() == 'ecs':
                blocks.append(f'''
resource "aws_ecs_cluster" "app_cluster_{i}" {{
  name = "app-cluster-{i}"
}}''')
            elif service.lower() == 'rds':
                blocks.append(f'''
resource "aws_db_instance" "app_db_{i}" {{
  allocated_storage = 20
  engine            = "postgres"
  instance_class    = "db.t3.micro"
}}''')
        
        return "\n".join(blocks)

    def generate_nginx_conf(self, domain: str) -> str:
        """Generates Nginx configuration for a given domain."""
        return f'''server {{
    listen 80;
    server_name {domain};

    location / {{
        proxy_pass http://localhost:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }}
}}'''
