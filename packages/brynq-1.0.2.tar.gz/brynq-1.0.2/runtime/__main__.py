"""Allow running Brynq with: python -m runtime"""
from runtime.cli import main

if __name__ == "__main__":
    main()
