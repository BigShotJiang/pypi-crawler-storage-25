from typing import Dict, Any

class CloudProvisioner:
    def __init__(self):
        # Mock pricing data
        self.pricing = {
            "t3.micro": 0.0104,
            "t3.medium": 0.0416,
            "m5.large": 0.096,
            "c5.large": 0.085,
            "c5.xlarge": 0.170
        }
        
    def estimate_cost(self, architecture: Dict[str, Any]) -> float:
        """Estimate the total cost for a given architecture."""
        total_cost = 0.0
        instances = architecture.get("instances", [])
        
        for instance in instances:
            instance_type = instance.get("type")
            hours = instance.get("hours", 1)
            count = instance.get("count", 1)
            
            # Default to 0.1 per hour if unknown type
            price_per_hour = self.pricing.get(instance_type, 0.1)
            total_cost += price_per_hour * hours * count
            
        return total_cost

    def provision_mock_aws_spot(self, instance_type: str, max_price: float) -> Dict[str, Any]:
        """Attempt to provision a mock AWS spot instance."""
        market_price = self.pricing.get(instance_type, 0.1)
        
        if max_price >= market_price:
            return {
                "status": "success",
                "instance_id": f"i-mock-{instance_type.replace('.', '')}",
                "price_paid": market_price
            }
        else:
            return {
                "status": "failed",
                "reason": "Price too low, spot request unfulfilled"
            }
