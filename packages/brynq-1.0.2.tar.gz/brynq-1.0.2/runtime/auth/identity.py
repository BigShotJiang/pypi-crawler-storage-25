class NotLoggedInError(Exception):
    pass

class IdentityManager:
    def __init__(self):
        self.token = None

    def login(self, api_key: str):
        if not api_key:
            raise ValueError("API key is required")
        # Mock validation and setting token
        self.token = f"dummy_token_{api_key}"
        return True

    def get_auth_header(self) -> dict:
        if not self.token:
            raise NotLoggedInError("User is not logged in")
        return {"Authorization": f"Bearer {self.token}"}
