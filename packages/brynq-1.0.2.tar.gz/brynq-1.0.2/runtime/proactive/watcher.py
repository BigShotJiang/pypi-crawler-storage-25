import os
import subprocess

class ContextWatcher:
    def __init__(self):
        pass

    def monitor_git_state(self):
        """Mock reading git status/log."""
        try:
            status_output = subprocess.check_output(
                ["git", "status", "--porcelain"],
                stderr=subprocess.STDOUT,
                text=True
            )
            log_output = subprocess.check_output(
                ["git", "log", "-1", "--oneline"],
                stderr=subprocess.STDOUT,
                text=True
            )
            return {
                "status": status_output.strip(),
                "last_commit": log_output.strip()
            }
        except (subprocess.CalledProcessError, FileNotFoundError):
            return {
                "status": "M mock_file.py",
                "last_commit": "1234567 Mock commit"
            }

    def monitor_build_logs(self, log_path: str):
        """Monitor build logs from a given path."""
        if not os.path.exists(log_path):
            return ""
        
        with open(log_path, 'r', encoding='utf-8') as f:
            return f.read()
