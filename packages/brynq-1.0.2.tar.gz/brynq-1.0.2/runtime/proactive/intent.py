class IntentPredictor:
    def __init__(self):
        # Simple keyword-based intent mapping
        self.intent_rules = {
            "Fix merge conflict": ["merge conflict", "conflict in", "automatic merge failed"],
            "Fix build error": ["error:", "build failed", "compilation error", "traceback"],
            "Run tests": ["test failed", "failing tests", "assertionerror"],
            "Commit changes": ["untracked files", "changes not staged", "changes to be committed"]
        }

    def predict_need(self, context: str):
        """Predicts user intention based on context keywords."""
        if not context:
            return {"intent": "Unknown", "confidence": 0.0}

        context_lower = context.lower()
        best_intent = "Unknown"
        best_confidence = 0.0

        for intent, keywords in self.intent_rules.items():
            matches = sum(1 for kw in keywords if kw.lower() in context_lower)
            if matches > 0:
                confidence = min(1.0, matches * 0.4)
                if confidence > best_confidence:
                    best_confidence = confidence
                    best_intent = intent

        return {
            "intent": best_intent,
            "confidence": best_confidence
        }
