import random

class AgentForge:
    def spawn_generation(self, base_prompt: str, size: int) -> list[dict]:
        mutations = [
            " Be concise.", " Think step-by-step.", " Act as an expert.",
            " Provide code examples.", " Ask clarifying questions."
        ]
        generation = []
        for i in range(size):
            if i == 0:
                generation.append({"prompt": base_prompt, "id": i})
            else:
                mutation = random.choice(mutations)
                generation.append({"prompt": base_prompt + mutation, "id": i})
        return generation
