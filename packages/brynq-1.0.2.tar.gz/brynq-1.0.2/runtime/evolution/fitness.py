import random

class FitnessEvaluator:
    def evaluate_population(self, population: list[dict], benchmark_task: str) -> list[dict]:
        evaluated = []
        for agent in population:
            # Dummy score between 0 and 100
            score = random.uniform(0, 100)
            evaluated_agent = agent.copy()
            evaluated_agent["score"] = score
            evaluated_agent["benchmark_task"] = benchmark_task
            evaluated.append(evaluated_agent)
        return evaluated

    def select_winners(self, evaluated_population: list[dict], top_k: int) -> list[dict]:
        # Sort by score descending
        sorted_population = sorted(evaluated_population, key=lambda x: x.get("score", 0), reverse=True)
        return sorted_population[:top_k]
