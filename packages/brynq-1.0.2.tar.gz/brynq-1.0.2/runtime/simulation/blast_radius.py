from typing import List, Tuple

class BlastRadiusAnalyzer:
    def analyze_diff(self, diff_text: str) -> Tuple[List[str], float]:
        """
        Parses a mock git diff and returns a list of affected files and a severity score.
        """
        affected_files = set()
        additions = 0
        deletions = 0
        
        for line in diff_text.splitlines():
            if line.startswith('+++ b/'):
                affected_files.add(line[6:].strip())
            elif line.startswith('--- a/'):
                path = line[6:].strip()
                if path != '/dev/null':
                    affected_files.add(path)
            elif line.startswith('+') and not line.startswith('+++'):
                additions += 1
            elif line.startswith('-') and not line.startswith('---'):
                deletions += 1
                
        severity = len(affected_files) * 1.0 + (additions + deletions) * 0.1
        
        return sorted(list(affected_files)), round(severity, 2)
