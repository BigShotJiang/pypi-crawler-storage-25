"""
Brynq Protocol — Shared plan format between cloud and runtime.

This is the wire contract: ExecutionPlan + PlanStep + HMAC signing.
Vendored into the runtime so it can run independently from the cloud repo.
Pure stdlib — zero external dependencies.
"""

from .schema import ExecutionPlan, PlanStep, PROTOCOL_VERSION
from .serializer import serialize_plan, deserialize_plan
from .signer import sign_plan, verify_plan, is_expired

__all__ = [
    "ExecutionPlan",
    "PlanStep",
    "PROTOCOL_VERSION",
    "serialize_plan",
    "deserialize_plan",
    "sign_plan",
    "verify_plan",
    "is_expired",
]
