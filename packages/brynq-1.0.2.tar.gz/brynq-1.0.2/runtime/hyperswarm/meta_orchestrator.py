import uuid
import re
from typing import List, Dict, Any

class HyperSwarmOrchestrator:
    def __init__(self):
        self.managers = {}

    def decompose_goal(self, goal: str) -> List[str]:
        """
        Splits a large string into sub-goals heuristically.
        """
        if not goal or not str(goal).strip():
            return []
            
        goal = str(goal).strip()
        
        # Heuristic 1: Explicit numbered or bulleted lines
        lines = [line.strip() for line in goal.split('\n') if line.strip()]
        if len(lines) > 1:
            return lines
            
        # Heuristic 2: Sentences separated by periods.
        # Use regex to split by period followed by space or end of string.
        sentences = [s.strip() for s in re.split(r'\.\s+|\.$', goal) if s.strip()]
        if sentences:
            return sentences
            
        # Fallback: just return the goal
        return [goal]

    def spawn_managers(self, subgoals: List[str]) -> List[Dict[str, Any]]:
        """
        Spawns managers for a list of subgoals.
        """
        spawned = []
        for subgoal in subgoals:
            manager_id = str(uuid.uuid4())
            manager = {
                "id": manager_id,
                "goal": subgoal,
                "status": "initialized"
            }
            self.managers[manager_id] = manager
            spawned.append(manager)
        return spawned
