"""
Brynq Runtime — Agent Sandbox.

Filesystem, network, and resource isolation for 3rd-party agents
running on the user's machine. A malicious agent must not be able
to read user files, phone home to unknown servers, or hog resources.

Modules:
    agent_sandbox   — Install / start / stop / uninstall lifecycle
    agent_protocol  — Standard HTTP API contract every local agent must expose
"""

from .agent_sandbox import (
    AgentSandbox,
    InstalledAgent,
    RunningAgent,
    SandboxError,
)
from .agent_protocol import (
    AgentExecuteRequest,
    AgentExecuteResponse,
    AgentHealthResponse,
    AgentInfoResponse,
    AGENT_PROTOCOL_VERSION,
)

__all__ = [
    "AgentSandbox",
    "InstalledAgent",
    "RunningAgent",
    "SandboxError",
    "AgentExecuteRequest",
    "AgentExecuteResponse",
    "AgentHealthResponse",
    "AgentInfoResponse",
    "AGENT_PROTOCOL_VERSION",
]
