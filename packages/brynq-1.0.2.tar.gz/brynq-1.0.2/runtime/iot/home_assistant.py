import logging
from typing import Dict, Any

logger = logging.getLogger(__name__)

class HomeAssistantAdapter:
    def __init__(self, base_url: str = "http://localhost:8123", token: str = "mock_token"):
        self.base_url = base_url
        self.token = token
        self._mock_state: Dict[str, str] = {}

    def toggle_device(self, device_id: str, state: str) -> Dict[str, Any]:
        """
        Toggles a device state.
        In a real implementation, this would make a REST/WS call to Home Assistant.
        For this mock, it formats the payload and updates internal state.
        """
        if state not in ('on', 'off'):
            raise ValueError("State must be 'on' or 'off'")
            
        payload = {
            "entity_id": device_id,
            "state": state
        }
        
        logger.info(f"Toggling device {device_id} to {state} with payload: {payload}")
        self._mock_state[device_id] = state
        
        return {
            "status": "success",
            "device_id": device_id,
            "state": state,
            "api_payload": payload
        }
