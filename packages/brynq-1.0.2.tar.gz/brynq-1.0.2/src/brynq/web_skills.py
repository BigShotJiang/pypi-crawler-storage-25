import requests
from bs4 import BeautifulSoup
from duckduckgo_search import DDGS

def search_web(query: str, max_results: int = 5) -> str:
    try:
        results = list(DDGS().text(query, max_results=max_results))
        if not results: return 'No results found for your query.'
        return '\n\n'.join([f"Title: {r.get('title')}\nURL: {r.get('href')}\nSnippet: {r.get('body')}" for r in results])
    except Exception as e:
        return f"Error performing web search: {e}"

def scrape_url(url: str) -> str:
    try:
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
        response = requests.get(url, headers=headers, timeout=10)
        soup = BeautifulSoup(response.text, 'html.parser')
        for script in soup(['script', 'style', 'nav', 'footer', 'header']): 
            script.extract()
        text = soup.get_text(separator=' ', strip=True)
        words = text.split()
        if len(words) > 3000: 
            text = ' '.join(words[:3000]) + '\n\n[SYSTEM NOTICE: CONTENT TRUNCATED FOR LENGTH]'
        return text
    except Exception as e:
        return f"Error scraping URL: {e}"
