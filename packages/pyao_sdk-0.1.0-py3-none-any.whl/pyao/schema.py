"""
Data classes for AO SDK.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Any, Union

# We'll keep cryptography imports optional; if encryption is not used,
# the class can still be imported without needing cryptography.
try:
    from cryptography.hazmat.primitives.asymmetric.rsa import RSAPublicKey
except ImportError:
    # Define a placeholder if cryptography is not installed
    RSAPublicKey = Any


@dataclass
class Tag:
    """A key-value tag for AO messages."""
    name: str
    value: str


@dataclass
class SendMessageOptions:
    """
    Optional settings for sending a message.

    Attributes:
        encrypt_with_rsa: RSA public key of the recipient to encrypt the message.
            If provided, the message data will be encrypted using hybrid encryption.
    """
    encrypt_with_rsa: Optional[RSAPublicKey] = None


@dataclass
class ResponseCu:
    """
    Response from a Compute Unit (CU) after a dry run or message result.

    Attributes:
        output: The output of the process (string or JSON).
        messages: List of messages emitted by the process during execution.
        spawns: List of spawned processes.
        error: Error message, if any.
        gas_used: Gas consumed during execution.
    """
    output: Any = ""           # can be string or parsed JSON
    messages: List[Any] = field(default_factory=list)
    spawns: List[Any] = field(default_factory=list)
    error: Optional[str] = None
    gas_used: int = 0


@dataclass
class ResponseMu:
    """
    Response from a Message Unit (MU) after submitting a data item.

    Attributes:
        id: The ID of the submitted message (usually the data item ID).
    """
    id: str = ""