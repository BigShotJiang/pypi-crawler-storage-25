"""
pyao – Python SDK for AO (Arweave Oracles)

A simple, Pythonic SDK to interact with the AO protocol on Arweave.
"""

# Public API
from .client import Client
from .signer import ARSigner
from .schema import Tag, SendMessageOptions, ResponseCu
from .encrypt import base64url_encode, base64url_decode
from .errors import (
    Error,
    SigningError,
    RequestError,
    TimeoutError,
    EncryptionError,
    DataItemError,
)

# Version
__version__ = "0.1.0"

# Define what gets imported with "from pyao import *"
__all__ = [
    "Client",
    "ARSigner",
    "Tag",
    "SendMessageOptions",
    "ResponseCu",
    "base64url_encode",
    "base64url_decode",
    "Error",
    "SigningError",
    "RequestError",
    "TimeoutError",
    "EncryptionError",
    "DataItemError",
]