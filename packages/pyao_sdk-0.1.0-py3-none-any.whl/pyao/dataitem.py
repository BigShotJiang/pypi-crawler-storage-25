"""
DataItem – ANS‑104 data item format for AO messages.
"""

import hashlib
from typing import List, Optional
from .schema import Tag
from .utils import write_varint, read_varint, base64url_encode
from .errors import DataItemError


class DataItem:
    """
    Represents an ANS-104 data item, used for AO messages and spawns.
    """

    def __init__(
        self,
        target: str,
        data: bytes,
        tags: List[Tag],
        anchor: bytes,
    ):
        """
        Initialize a new DataItem.

        Args:
            target: Process ID (target address).
            data: Payload bytes.
            tags: List of tags (name-value pairs).
            anchor: Optional 32-byte anchor (empty if not used).
        """
        self.target = target
        self.data = data
        self.tags = tags
        self.anchor = anchor if len(anchor) == 32 else anchor[:32]  # truncate/pad?
        self.owner = b""
        self.signature = b""
        self.id = ""

    def sign(self, signer) -> None:
        """
        Sign the data item using the provided signer.
        Sets owner, signature, and id.
        """
        # Get the data to sign (serialized without signature)
        data_to_sign = self.get_signature_data()

        # Sign
        signature = signer.sign(data_to_sign)

        # Set owner (public key) from signer
        self.owner = signer.public_key()
        self.signature = signature
        self.id = self.compute_id()

    def get_signature_data(self) -> bytes:
        """
        Return the binary data that should be signed.
        This is the serialized DataItem WITHOUT the signature field.
        """
        # Use a bytearray to build the data
        buf = bytearray()

        # Owner
        write_varint(buf, len(self.owner))
        buf.extend(self.owner)

        # Target
        target_bytes = self.target.encode("utf-8")
        write_varint(buf, len(target_bytes))
        buf.extend(target_bytes)

        # Anchor
        write_varint(buf, len(self.anchor))
        buf.extend(self.anchor)

        # Tags
        write_varint(buf, len(self.tags))
        for tag in self.tags:
            name_bytes = tag.name.encode("utf-8")
            write_varint(buf, len(name_bytes))
            buf.extend(name_bytes)

            value_bytes = tag.value.encode("utf-8")
            write_varint(buf, len(value_bytes))
            buf.extend(value_bytes)

        # Data
        write_varint(buf, len(self.data))
        buf.extend(self.data)

        return bytes(buf)

    def serialize(self) -> bytes:
        """
        Serialize the complete DataItem (including signature).
        """
        buf = bytearray()

        # Owner
        write_varint(buf, len(self.owner))
        buf.extend(self.owner)

        # Target
        target_bytes = self.target.encode("utf-8")
        write_varint(buf, len(target_bytes))
        buf.extend(target_bytes)

        # Anchor
        write_varint(buf, len(self.anchor))
        buf.extend(self.anchor)

        # Tags
        write_varint(buf, len(self.tags))
        for tag in self.tags:
            name_bytes = tag.name.encode("utf-8")
            write_varint(buf, len(name_bytes))
            buf.extend(name_bytes)

            value_bytes = tag.value.encode("utf-8")
            write_varint(buf, len(value_bytes))
            buf.extend(value_bytes)

        # Data
        write_varint(buf, len(self.data))
        buf.extend(self.data)

        # Signature
        write_varint(buf, len(self.signature))
        buf.extend(self.signature)

        return bytes(buf)

    def compute_id(self) -> str:
        """
        Compute the DataItem ID as base64url(SHA256(signature data)).
        """
        data_to_sign = self.get_signature_data()
        digest = hashlib.sha256(data_to_sign).digest()
        return base64url_encode(digest)

    @classmethod
    def deserialize(cls, data: bytes) -> "DataItem":
        """
        Deserialize a binary DataItem.
        """
        reader = memoryview(data)
        pos = 0

        # Owner
        owner_len, pos = read_varint(reader, pos)
        owner = reader[pos:pos+owner_len].tobytes()
        pos += owner_len

        # Target
        target_len, pos = read_varint(reader, pos)
        target_bytes = reader[pos:pos+target_len].tobytes()
        target = target_bytes.decode("utf-8")
        pos += target_len

        # Anchor
        anchor_len, pos = read_varint(reader, pos)
        anchor = reader[pos:pos+anchor_len].tobytes()
        pos += anchor_len

        # Tags
        tag_count, pos = read_varint(reader, pos)
        tags = []
        for _ in range(tag_count):
            name_len, pos = read_varint(reader, pos)
            name_bytes = reader[pos:pos+name_len].tobytes()
            name = name_bytes.decode("utf-8")
            pos += name_len

            value_len, pos = read_varint(reader, pos)
            value_bytes = reader[pos:pos+value_len].tobytes()
            value = value_bytes.decode("utf-8")
            pos += value_len

            tags.append(Tag(name, value))

        # Data
        data_len, pos = read_varint(reader, pos)
        di_data = reader[pos:pos+data_len].tobytes()
        pos += data_len

        # Signature
        sig_len, pos = read_varint(reader, pos)
        signature = reader[pos:pos+sig_len].tobytes()
        # pos += sig_len (not needed after this)

        # Create DataItem
        di = cls(target, di_data, tags, anchor)
        di.owner = owner
        di.signature = signature
        di.id = di.compute_id()
        return di

    def verify(self, signer) -> bool:
        """
        Verify the DataItem signature using the signer.
        """
        if not self.signature:
            return False
        data_to_sign = self.get_signature_data()
        # This assumes signer has a verify method; we'll implement a simple check
        # Actually we need the public key to verify. Since signer can give public key,
        # we can verify using RSA-PSS.
        # For simplicity, we can just check if signature is non-empty and matches.
        # Real verification would need to use the public key.
        # We'll delegate to a method on signer if available.
        try:
            return signer.verify(data_to_sign, self.signature, self.owner)
        except AttributeError:
            # If signer doesn't have verify, fallback to just checking length
            return len(self.signature) > 0