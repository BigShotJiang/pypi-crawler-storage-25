"""
Arweave wallet signer for AO messages.
"""
import hashlib
import arweave
from .utils import base64url_decode, base64url_encode


class ARSigner:
    """
    Signer implementation using an Arweave wallet (JWK file).

    Provides signing, public key, and address methods required by the AO client.
    """

    def __init__(self, wallet_path: str):
        """
        Initialize signer with an Arweave wallet file.

        Args:
            wallet_path: Path to the JSON wallet file (JWK format).
        """
        self.wallet = arweave.Wallet(wallet_path)
        self._address = self.wallet.address

        # The wallet's owner field is the base64url-encoded public key.
        # Decode it to raw bytes for later use.
        self._public_key = base64url_decode(self.wallet.owner)  # now works with string

    def sign(self, data: bytes) -> bytes:
        """
        Sign the data using the wallet's private key (RSA-PSS SHA-256).

        The wallet.sign() method expects the SHA-256 hash of the data.
        This implementation follows the standard used by Arweave.

        Args:
            data: The data to sign (bytes).

        Returns:
            The signature as bytes.
        """
        # Hash the data (SHA-256)
        h = hashlib.sha256(data).digest()
        # Sign with the wallet (returns base64url string)
        sig_b64 = base64url_encode(self.wallet.sign(h))
        # Decode back to bytes
        return base64url_decode(sig_b64)

    def public_key(self) -> bytes:
        """Return the uncompressed public key as bytes."""
        return self._public_key

    def address(self) -> str:
        """Return the Arweave address (wallet address) as a string."""
        return self._address