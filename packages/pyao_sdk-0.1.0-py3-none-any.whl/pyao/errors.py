"""
Custom exceptions for the AO SDK.
"""

class Error(Exception):
    """Base exception for all AO SDK errors."""
    pass


class SigningError(Error):
    """Raised when signing fails (e.g., invalid key, signing operation error)."""
    pass


class RequestError(Error):
    """Raised when an HTTP request fails (network error, non‑2xx status)."""
    pass


class TimeoutError(Error):
    """Raised when an operation times out (e.g., waiting for a message result)."""
    pass


class EncryptionError(Error):
    """Raised when encryption or decryption fails."""
    pass


class DataItemError(Error):
    """Raised when data item serialisation, deserialisation, or validation fails."""
    pass