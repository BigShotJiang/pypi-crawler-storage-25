"""
Hybrid encryption (RSA‑OAEP + AES‑GCM) and base64url helpers.
"""

import os
import base64
from typing import Tuple

from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend

# Constants
AES_KEY_SIZE = 32          # AES-256
GCM_NONCE_SIZE = 12        # recommended for GCM


def base64url_encode(data: bytes) -> str:
    """
    Encode bytes to base64url without padding.
    """
    return base64.urlsafe_b64encode(data).rstrip(b'=').decode('ascii')


def base64url_decode(s: str) -> bytes:
    """
    Decode a base64url string to bytes, adding padding if needed.
    """
    # Add padding if necessary
    padding_needed = 4 - (len(s) % 4)
    if padding_needed != 4:
        s += '=' * padding_needed
    return base64.urlsafe_b64decode(s)


def encrypt_payload(
    plaintext: bytes,
    rsa_pub_key: rsa.RSAPublicKey,
) -> Tuple[bytes, bytes, bytes]:
    """
    Encrypt data using hybrid encryption: AES‑GCM + RSA‑OAEP.

    Generates a random AES‑256 key and GCM nonce, encrypts the plaintext,
    then encrypts the AES key with the RSA public key using OAEP with SHA‑256.

    Args:
        plaintext: The data to encrypt.
        rsa_pub_key: Recipient's RSA public key (cryptography object).

    Returns:
        A tuple (encrypted_data, encrypted_key, nonce) all as bytes.
    """
    # Generate random AES‑256 key and nonce
    aes_key = os.urandom(AES_KEY_SIZE)
    nonce = os.urandom(GCM_NONCE_SIZE)

    # Encrypt data with AES‑GCM
    aesgcm = AESGCM(aes_key)
    encrypted_data = aesgcm.encrypt(nonce, plaintext, None)  # no associated data

    # Encrypt AES key with RSA‑OAEP
    encrypted_key = rsa_pub_key.encrypt(
        aes_key,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None,
        ),
    )

    # Clear sensitive data from memory (not strictly necessary in Python,
    # but can help; we overwrite the variable)
    # aes_key = b'\x00' * AES_KEY_SIZE  # optional

    return encrypted_data, encrypted_key, nonce


def decrypt_payload(
    encrypted_data: bytes,
    encrypted_key: bytes,
    nonce: bytes,
    rsa_priv_key: rsa.RSAPrivateKey,
) -> bytes:
    """
    Decrypt data using hybrid decryption: RSA‑OAEP to recover AES key,
    then AES‑GCM to decrypt the data.

    Args:
        encrypted_data: The AES‑GCM encrypted data (includes authentication tag).
        encrypted_key: The RSA‑OAEP encrypted AES key.
        nonce: The GCM nonce used during encryption.
        rsa_priv_key: Recipient's RSA private key (cryptography object).

    Returns:
        The decrypted plaintext bytes.
    """
    # Decrypt AES key with RSA‑OAEP
    aes_key = rsa_priv_key.decrypt(
        encrypted_key,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None,
        ),
    )

    # Decrypt data with AES‑GCM
    aesgcm = AESGCM(aes_key)
    plaintext = aesgcm.decrypt(nonce, encrypted_data, None)

    # Clear sensitive key from memory
    # aes_key = b'\x00' * AES_KEY_SIZE  # optional

    return plaintext