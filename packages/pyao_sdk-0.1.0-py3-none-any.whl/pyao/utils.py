"""
Low‑level utilities for binary encoding, base64url, and hashing.
"""

import base64
import hashlib
from typing import Tuple, Union


# ============================================================================
# Varint encoding/decoding (LEB128)
# ============================================================================

def write_varint(buf: bytearray, value: int) -> None:
    """
    Write a varint (LEB128) into a bytearray.
    """
    while True:
        byte = value & 0x7F
        value >>= 7
        if value == 0:
            buf.append(byte)
            break
        buf.append(byte | 0x80)


def read_varint(data: Union[bytes, memoryview], pos: int) -> Tuple[int, int]:
    """
    Read a varint from a bytes-like object starting at position `pos`.
    Returns (value, new_position).
    """
    value = 0
    shift = 0
    while True:
        if pos >= len(data):
            raise ValueError("Unexpected end of data while reading varint")
        b = data[pos]
        pos += 1
        value |= (b & 0x7F) << shift
        shift += 7
        if (b & 0x80) == 0:
            break
    return value, pos


def len_varint(value: int) -> int:
    """
    Return the number of bytes needed to encode `value` as a varint.
    """
    if value == 0:
        return 1
    # Count bytes
    count = 0
    while value > 0:
        value >>= 7
        count += 1
    return count


# ============================================================================
# Base64url (RFC 4648) – no padding
# ============================================================================

def base64url_encode(data: bytes) -> str:
    """
    Encode bytes to base64url without padding.
    """
    return base64.urlsafe_b64encode(data).rstrip(b'=').decode('ascii')


def base64url_decode(s: str) -> bytes:
    """
    Decode a base64url string to bytes, adding padding if needed.
    """
    # Add padding if necessary
    padding_needed = 4 - (len(s) % 4)
    if padding_needed != 4:
        s += '=' * padding_needed
    return base64.urlsafe_b64decode(s)


# ============================================================================
# Hashing
# ============================================================================

def sha256(data: bytes) -> bytes:
    """
    Return SHA‑256 hash of the input data.
    """
    return hashlib.sha256(data).digest()