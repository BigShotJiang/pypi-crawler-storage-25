"""
AO Client – main interface for interacting with the AO protocol.
"""

import json
import time
import base64
import hashlib
from typing import List, Dict, Optional, Union, Any, Tuple
from urllib.parse import urljoin, urlparse

import requests

from .signer import ARSigner
from .dataitem import DataItem
from .encrypt import encrypt_payload, decrypt_payload, base64url_encode, base64url_decode
from .schema import Tag, SendMessageOptions, ResponseCu
from .errors import (
    Error,
    RequestError,
    TimeoutError,
    EncryptionError,
    DataItemError,
)


# Default URLs (mainnet)
DEFAULT_MU = "https://mu.forward.computer"
DEFAULT_CU = "https://cu.forward.computer"
DEFAULT_SU = "https://scheduler.forward.computer"
DEFAULT_COMPUTE_GATEWAY = "https://push.forward.computer"

# Timeouts (seconds)
DEFAULT_REQUEST_TIMEOUT = 30
DEFAULT_POLL_INTERVAL = 2


class Client:
    """Main AO client for sending messages, spawning processes, and querying state."""

    def __init__(
        self,
        signer: ARSigner,
        mu: Optional[str] = None,
        cu: Optional[str] = None,
        su: Optional[str] = None,
        compute_gateway: Optional[str] = None,
    ):
        """
        Initialise the client.

        Args:
            signer: An ARSigner instance (Arweave wallet).
            mu: Custom MU URL (defaults to mainnet).
            cu: Custom CU URL (defaults to mainnet).
            su: Custom SU URL (defaults to mainnet).
            compute_gateway: Custom compute gateway URL (defaults to mainnet).
        """
        self.signer = signer
        self.mu = mu or DEFAULT_MU
        self.cu = cu or DEFAULT_CU
        self.su = su or DEFAULT_SU
        self.compute_gateway = compute_gateway or DEFAULT_COMPUTE_GATEWAY

        # Ensure URLs do not have trailing slash
        self.mu = self.mu.rstrip("/")
        self.cu = self.cu.rstrip("/")
        self.su = self.su.rstrip("/")
        self.compute_gateway = self.compute_gateway.rstrip("/")

        # Default tags for every message
        self.default_tags = [
            Tag("Data-Protocol", "ao"),
            Tag("Variant", "ao.TN.1"),
            Tag("SDK", "pyao/0.1.0"),
        ]

    def _build_data_item(
        self,
        target: str,
        data: bytes,
        tags: List[Tag],
        anchor: Optional[bytes] = None,
    ) -> DataItem:
        """Create and sign a DataItem."""
        # Merge default tags with user tags
        all_tags = self.default_tags.copy()
        all_tags.extend(tags)

        # Create data item
        di = DataItem(
            target=target,
            data=data,
            tags=all_tags,
            anchor=anchor or b"",
        )

        # Sign
        di.sign(self.signer)
        return di

    def _post_binary(self, url: str, data: bytes) -> Dict[str, Any]:
        """POST binary data to a URL and return JSON response."""
        try:
            resp = requests.post(
                url,
                data=data,
                headers={"Content-Type": "application/octet-stream"},
                timeout=DEFAULT_REQUEST_TIMEOUT,
            )
            resp.raise_for_status()
            return resp.json()
        except requests.RequestException as e:
            raise RequestError(f"HTTP request failed: {e}") from e
        except json.JSONDecodeError as e:
            raise RequestError(f"Invalid JSON response: {e}") from e

    def send_message(
        self,
        process_id: str,
        data: bytes,
        tags: List[Tag],
        anchor: Optional[bytes] = None,
        options: Optional[SendMessageOptions] = None,
    ) -> str:
        """
        Send a message to an AO process.

        Args:
            process_id: The process ID (target).
            data: Message payload (bytes).
            tags: List of tags (key-value pairs).
            anchor: Optional 32-byte anchor.
            options: Optional send options (e.g., encryption).

        Returns:
            The data item ID (message ID) of the sent message.
        """
        # Apply encryption if requested
        if options and options.encrypt_with_rsa:
            pub_key = options.encrypt_with_rsa
            encrypted_data, encrypted_key, nonce = encrypt_payload(data, pub_key)

            # Replace data with encrypted payload
            data = encrypted_data

            # Add encryption tags
            tags.extend([
                Tag("Encrypted-Key", base64url_encode(encrypted_key)),
                Tag("Nonce", base64url_encode(nonce)),
                Tag("Encryption-Algorithm", "AES-GCM+RSA-OAEP"),
            ])

        # Build and sign data item
        di = self._build_data_item(process_id, data, tags, anchor)

        # Send to MU
        url = f"{self.mu}/submit"
        response = self._post_binary(url, di.serialize())
        # Some MU endpoints return {"id": ...}
        # We return the data item ID, not the MU's ID (but they are often the same)
        return di.id

    def spawn_process(
        self,
        module_tx_id: str,
        data: bytes,
        tags: List[Tag],
        anchor: Optional[bytes] = None,
        scheduler: Optional[str] = None,
    ) -> str:
        """
        Spawn a new process from a module.

        Args:
            module_tx_id: Transaction ID of the module to spawn.
            data: Initial state data (bytes).
            tags: List of tags (key-value pairs).
            anchor: Optional 32-byte anchor.
            scheduler: Optional scheduler address (defaults to mainnet scheduler).

        Returns:
            The process ID (data item ID) of the spawned process.
        """
        # Add required tags
        spawn_tags = tags.copy()
        spawn_tags.append(Tag("Type", "Process"))
        spawn_tags.append(Tag("Module", module_tx_id))
        if scheduler:
            spawn_tags.append(Tag("Scheduler", scheduler))
        else:
            spawn_tags.append(Tag("Scheduler", self.su.split("://")[1]))  # bare address?

        # Build and sign data item (target is empty for spawn)
        di = self._build_data_item("", data, spawn_tags, anchor)

        # Send to MU
        url = f"{self.mu}/submit"
        self._post_binary(url, di.serialize())
        return di.id

    def dry_run(
        self,
        process_id: str,
        data: bytes,
        tags: List[Tag],
        anchor: Optional[bytes] = None,
        owner: Optional[str] = None,
    ) -> ResponseCu:
        """
        Simulate a message (dry run) without committing it.

        Args:
            process_id: The process ID.
            data: Message payload (bytes).
            tags: List of tags (key-value pairs).
            anchor: Optional anchor (bytes).
            owner: Optional owner address (defaults to signer's address).

        Returns:
            ResponseCu object containing output, messages, spawns, etc.
        """
        # Convert tags to list of dicts
        tag_dicts = [{"name": t.name, "value": t.value} for t in tags]

        # Owner defaults to signer's address
        if owner is None:
            owner = self.signer.address()

        # Prepare payload
        payload = {
            "Target": process_id,
            "Owner": owner,
            "Anchor": base64url_encode(anchor) if anchor else "",
            "Data": base64url_encode(data) if data else "",
            "Tags": tag_dicts,
        }

        # Send request
        url = f"{self.cu}/dry-run?process-id={process_id}"
        try:
            resp = requests.post(
                url,
                json=payload,
                timeout=DEFAULT_REQUEST_TIMEOUT,
            )
            resp.raise_for_status()
            result = resp.json()
        except requests.RequestException as e:
            raise RequestError(f"Dry-run request failed: {e}") from e
        except json.JSONDecodeError as e:
            raise RequestError(f"Invalid JSON response: {e}") from e

        # Parse result into ResponseCu
        # The CU returns fields: Output, Messages, Spawns, Error, GasUsed
        output = result.get("Output", "")
        messages = result.get("Messages", [])
        spawns = result.get("Spawns", [])
        error = result.get("Error")
        gas_used = result.get("GasUsed", 0)

        # Convert messages/spawns to DataItem objects? Might be left as dicts for simplicity.
        return ResponseCu(
            output=output,
            messages=messages,
            spawns=spawns,
            error=error,
            gas_used=gas_used,
        )

    def get_compute(self, process_id: str, path: str) -> bytes:
        """
        Fetch raw compute data from the process.

        Args:
            process_id: The process ID.
            path: The compute path (e.g., "counter").

        Returns:
            Raw bytes of the response.
        """
        # Construct URL: /<process-id>~process@1.0/compute/<path>
        # Note: process version is typically "1.0"
        url = f"{self.compute_gateway}/{process_id}~process@1.0/compute/{path}"
        try:
            resp = requests.get(url, timeout=DEFAULT_REQUEST_TIMEOUT)
            resp.raise_for_status()
            return resp.content
        except requests.RequestException as e:
            raise RequestError(f"Compute request failed: {e}") from e

    def get_compute_string(self, process_id: str, path: str) -> str:
        """Fetch compute data as a UTF-8 string."""
        return self.get_compute(process_id, path).decode("utf-8")

    def get_compute_json(self, process_id: str, path: str) -> Any:
        """Fetch compute data as parsed JSON."""
        data = self.get_compute(process_id, path)
        try:
            return json.loads(data)
        except json.JSONDecodeError as e:
            raise RequestError(f"Invalid JSON in compute response: {e}") from e

    def wait_for_result(
        self,
        message_id: str,
        process_id: str,
        timeout: float = 30,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
    ) -> ResponseCu:
        """
        Poll the CU until a result is available for the given message.

        Args:
            message_id: The message ID (data item ID).
            process_id: The process ID.
            timeout: Maximum time to wait (seconds).
            poll_interval: Time between polls (seconds).

        Returns:
            ResponseCu object containing the result.

        Raises:
            TimeoutError: If result not available within timeout.
        """
        start = time.time()
        while time.time() - start < timeout:
            try:
                # GET /result/<message_id>?process-id=<process_id>
                url = f"{self.cu}/result/{message_id}?process-id={process_id}"
                resp = requests.get(url, timeout=DEFAULT_REQUEST_TIMEOUT)
                if resp.status_code == 200:
                    result = resp.json()
                    # The result may have "Error" or "Output" fields
                    output = result.get("Output", "")
                    messages = result.get("Messages", [])
                    spawns = result.get("Spawns", [])
                    error = result.get("Error")
                    gas_used = result.get("GasUsed", 0)
                    return ResponseCu(
                        output=output,
                        messages=messages,
                        spawns=spawns,
                        error=error,
                        gas_used=gas_used,
                    )
                elif resp.status_code == 404:
                    # Not ready yet
                    time.sleep(poll_interval)
                    continue
                else:
                    # Some other error
                    resp.raise_for_status()
            except requests.RequestException as e:
                # If it's a temporary network issue, we might retry, but for simplicity we raise
                raise RequestError(f"Error polling result: {e}") from e
            except json.JSONDecodeError as e:
                raise RequestError(f"Invalid JSON in result: {e}") from e

        raise TimeoutError(f"Result not available after {timeout} seconds")

    def decrypt_response(
        self,
        encrypted_data_b64: str,
        encrypted_key_b64: str,
        nonce_b64: str,
        rsa_private_key,
    ) -> bytes:
        """
        Decrypt an encrypted response using the recipient's RSA private key.

        Args:
            encrypted_data_b64: Base64url-encoded encrypted data.
            encrypted_key_b64: Base64url-encoded encrypted AES key.
            nonce_b64: Base64url-encoded nonce.
            rsa_private_key: RSA private key (cryptography object) for decryption.

        Returns:
            Decrypted plaintext bytes.
        """
        encrypted_data = base64url_decode(encrypted_data_b64)
        encrypted_key = base64url_decode(encrypted_key_b64)
        nonce = base64url_decode(nonce_b64)

        return decrypt_payload(encrypted_data, encrypted_key, nonce, rsa_private_key)