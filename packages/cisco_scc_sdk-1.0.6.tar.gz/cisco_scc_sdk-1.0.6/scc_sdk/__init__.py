# Copyright (c) 2026 Cisco Systems, Inc. and its affiliates
# SPDX-License-Identifier: Apache-2.0

"""
Cisco Security Cloud Control Python SDK
"""

from .client import Client
from .exceptions import (
    SCCError,
    AuthenticationError,
    NotFoundError,
    ValidationError,
    ForbiddenError,
    ServerError,
)

__version__ = "1.0.0"
__all__ = [
    "Client",
    "SCCError",
    "AuthenticationError",
    "NotFoundError",
    "ValidationError",
    "ForbiddenError",
    "ServerError",
]
