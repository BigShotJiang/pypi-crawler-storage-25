# Copyright (c) 2026 Cisco Systems, Inc. and its affiliates
# SPDX-License-Identifier: Apache-2.0

"""
Roles resource handler
"""

from typing import List, Dict, Any, Optional
from .base import BaseResource


class RolesResource(BaseResource):
    """
    Handler for role-related API endpoints.
    
    Example:
        >>> client = Client(access_token="token")
        >>> roles = client.roles.list(org_id="org-uuid")
        >>> role = client.roles.get(org_id="org-uuid", role_id="role-uuid")
        >>> result = client.roles.patch(org_id="org-uuid", role_id="role-uuid", users=[...])

    Spec examples:
        list response:
            {"roles": [{"id": "6280494d-dd0f-4655-b558-111111111114", "displayName": "Test platform product 2 display name", "type": "STATIC"}]}
        patch request:
            {"users": [{"operation": "add", "id": "abc@xyz.com"}], "groups": [{"operation": "remove", "id": "04d2f118-6519-759h-bg56-c367e59ad756"}]}
        patch response:
            {"results": [{"id": "550e8400-e29b-41d4-a716-446655440000", "type": "user", "operation": "add", "status": "success"}]}
    """
    
    def list(
        self,
        org_id: str,
        type: Optional[str] = None,
        user: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        List all roles for an organization.
        
        Args:
            org_id: The organization UUID
            type: Optional filter by role type (CUSTOM, BUNDLED, STATIC)
            user: Optional user ID to fetch roles assigned to a specific user
        
        Returns:
            Dictionary containing list of roles
        """
        params = {}
        
        if type:
            params["type"] = type
        if user:
            params["user"] = user
        
        return self.client.get(f"organizations/{org_id}/roles", params=params)
    
    def get(self, org_id: str, role_id: str) -> Dict[str, Any]:
        """
        Get a specific role by ID.
        
        Args:
            org_id: The organization UUID
            role_id: The role UUID
        
        Returns:
            Role dictionary
        """
        return self.client.get(f"organizations/{org_id}/roles/{role_id}")
    
    def patch(
        self,
        org_id: str,
        role_id: str,
        users: Optional[List[Dict[str, str]]] = None,
        groups: Optional[List[Dict[str, str]]] = None
    ) -> Dict[str, Any]:
        """
        Update role assignments by adding or removing users and groups.
        
        Args:
            org_id: The organization UUID
            role_id: The role UUID
            users: List of user operations with 'operation' (add/remove) and 'id' (user UUID)
            groups: List of group operations with 'operation' (add/remove) and 'id' (group UUID)
        
        Returns:
            Operation results dictionary
        
        Example:
            >>> client.roles.patch(
            ...     org_id="org-uuid",
            ...     role_id="role-uuid",
            ...     users=[{"operation": "add", "id": "user-uuid"}],
            ...     groups=[{"operation": "remove", "id": "group-uuid"}]
            ... )
        """
        data = {}
        
        if users:
            data["users"] = users
        if groups:
            data["groups"] = groups
        
        return self.client.patch(f"organizations/{org_id}/roles/{role_id}", json=data)
    
    def get_assigned_roles(self, org_id: str, group_id: str) -> Dict[str, Any]:
        """
        Get assigned roles by group.
        
        Args:
            org_id: The organization UUID
            group_id: The group UUID
        
        Returns:
            Dictionary containing list of assigned roles
        """
        return self.client.get(f"organizations/{org_id}/adminGroups/{group_id}/roles")