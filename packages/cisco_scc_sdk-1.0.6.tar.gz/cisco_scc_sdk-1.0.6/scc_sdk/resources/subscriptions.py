# Copyright (c) 2026 Cisco Systems, Inc. and its affiliates
# SPDX-License-Identifier: Apache-2.0

"""
Subscriptions resource handler
"""

from typing import List, Dict, Any, Optional
from .base import BaseResource


class SubscriptionsResource(BaseResource):
    """
    Handler for subscription-related API endpoints.
    
    Example:
        >>> client = Client(access_token="token")
        >>> subs = client.subscriptions.list(org_id="org-uuid")
        >>> sub = client.subscriptions.get(org_id="org-uuid", subscription_id="sub-uuid")
        >>> new_sub = client.subscriptions.create(org_id="org-uuid", claim_code="XXXX-XXXX")

    Spec examples:
        create request:
            {"claimCode": "PHJZ-DWMF-ZBYH-FYMB", "products": [{"id": "da7d78a9-2db0-4fbc-a4bd-0565cd05a349", "useExistingTenant": false, "regionCode": "GLOBAL", "regionDescription": "Global"}]}
        create response:
            {"id": "3742d652-6740-489c-b628-143f00690fea", "name": "Sub008842110397382", "created": "2025-02-03T07:04:54Z", "isTrial": false}
        patch request:
            {"entitlements": [{"id": "E3S-AIDEF-ADV", "quantity": 10}], "useExistingTenantsForProducts": ["8a9f43fa-f8f5-4aac-8d0b-380cf6656255"]}
    """
    
    def list(
        self,
        org_id: str,
        name: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        List all subscriptions for an organization.
        
        Args:
            org_id: The organization UUID
            name: Optional subscription name filter
        
        Returns:
            Dictionary containing list of subscriptions
        """
        params = {}
        if name:
            params["name"] = name
        
        return self.client.get(f"organizations/{org_id}/subscriptions", params=params)
    
    def get(self, org_id: str, subscription_id: str) -> Dict[str, Any]:
        """
        Get a specific subscription by ID.
        
        Args:
            org_id: The organization UUID
            subscription_id: The subscription UUID
        
        Returns:
            Subscription dictionary
        """
        return self.client.get(f"organizations/{org_id}/subscriptions/{subscription_id}")
    
    def create(
        self,
        org_id: str,
        claim_code: str,
        type: Optional[str] = None,
        products: Optional[List[Dict[str, Any]]] = None
    ) -> Dict[str, Any]:
        """
        Create a new subscription using a claim code.
        
        Args:
            org_id: The organization UUID
            claim_code: Claim code for subscription creation
            type: Subscription type (trial, free, paid). Defaults to paid if not specified.
            products: Optional list of products to provision with configuration
                Each product dict should contain: id, useExistingTenant, regionCode, regionDescription
        
        Returns:
            Created subscription dictionary
        """
        data = {
            "claimCode": claim_code,
        }
        
        if type:
            data["type"] = type
        if products:
            data["products"] = products
        
        return self.client.post(f"organizations/{org_id}/subscriptions", json=data)
    
    def update(
        self,
        org_id: str,
        subscription_id: str,
        product_id: str,
        status: bool,
        source_instance_id: Optional[str] = None,
        region_code: Optional[str] = None,
        initial_admin: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Update a subscription (activate/deactivate product).
        
        Args:
            org_id: The organization UUID
            subscription_id: The subscription UUID
            product_id: The product UUID
            status: True to activate, False to deactivate
            source_instance_id: Source instance ID for using existing tenant
            region_code: Product region code (NAM, EMEA, APAC, US, GLOBAL)
            initial_admin: Initial admin email for new tenant provisioning
        
        Returns:
            Updated subscription dictionary
        """
        data = {
            "productId": product_id,
            "status": status
        }
        
        if source_instance_id:
            data["sourceInstanceId"] = source_instance_id
        if region_code:
            data["regionCode"] = region_code
        if initial_admin:
            data["initialAdmin"] = initial_admin
        
        return self.client.put(
            f"organizations/{org_id}/subscriptions/{subscription_id}",
            json=data
        )
    
    def patch(
        self,
        org_id: str,
        subscription_id: str,
        entitlements: List[Dict[str, Any]],
        use_existing_tenants_for_products: Optional[List[str]] = None,
        use_existing_tenants: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Patch a subscription (update entitlement quantities for managed orgs).
        
        Args:
            org_id: The managed organization UUID
            subscription_id: The subscription UUID
            entitlements: List of entitlements with id and quantity
            use_existing_tenants_for_products: Optional list of product UUIDs whose
                existing tenants should be attached during license sharing
            use_existing_tenants: Deprecated alias for use_existing_tenants_for_products
        
        Returns:
            Updated subscription dictionary
        
        Example:
            >>> client.subscriptions.patch(
            ...     org_id="org-uuid",
            ...     subscription_id="sub-uuid",
            ...     entitlements=[{"id": "E3S-AIDEF-ADV", "quantity": 10}],
            ...     use_existing_tenants=["8a9f43fa-f8f5-4aac-8d0b-380cf6656255"]
            ... )
        """
        data = {"entitlements": entitlements}
        tenant_ids = use_existing_tenants_for_products
        if tenant_ids is None:
            tenant_ids = use_existing_tenants

        if tenant_ids:
            data["useExistingTenantsForProducts"] = tenant_ids
        
        return self.client.patch(
            f"organizations/{org_id}/subscriptions/{subscription_id}",
            json=data
        )
    
    def read_claim_code(self, org_id: str, claim_code: str) -> Dict[str, Any]:
        """
        Read and validate claim code details.
        
        Args:
            org_id: The organization UUID
            claim_code: Claim code to validate
        
        Returns:
            Claim code information dictionary
        """
        data = {"claimCode": claim_code}
        return self.client.post(
            f"organizations/{org_id}/subscriptions/claimInfo",
            json=data
        )
