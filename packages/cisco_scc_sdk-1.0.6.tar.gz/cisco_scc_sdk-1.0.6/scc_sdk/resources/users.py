# Copyright (c) 2026 Cisco Systems, Inc. and its affiliates
# SPDX-License-Identifier: Apache-2.0

"""
Users resource handler
"""

from typing import List, Dict, Any, Optional
from .base import BaseResource


class UsersResource(BaseResource):
    """
    Handler for user-related API endpoints.
    
    Example:
        >>> client = Client(access_token="token")
        >>> users = client.users.list(org_id="org-uuid")
        >>> user = client.users.get(org_id="org-uuid", user_id="user-uuid")
        >>> client.users.invite(org_id="org-uuid", email="user@example.com")

    Spec examples:
        list response:
            {"users": [{"id": "00u2k67hy1xf3mRxG0h8", "email": "john.doe@example.com", "firstName": "John", "lastName": "Doe", "status": "ACTIVE"}]}
        patch request:
            {"users": [{"email": "john.doe@example.com", "operation": "invite", "firstName": "John", "lastName": "Doe", "isAdmin": true}]}
        patch response:
            {"results": [{"id": "john.doe@example.com", "type": "user", "operation": "invite", "status": "success"}]}
    """
    
    def list(
        self,
        org_id: str,
        status: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        List all users for an organization.
        
        Args:
            org_id: The organization UUID
            status: Optional filter by user status (ACTIVE, INACTIVE, PENDING)
        
        Returns:
            Dictionary containing list of users
        """
        params = {}
        
        if status:
            params["status"] = status
        
        return self.client.get(f"organizations/{org_id}/users", params=params)
    
    def get(self, org_id: str, user_id: str) -> Dict[str, Any]:
        """
        Get a specific user by ID.
        
        Args:
            org_id: The organization UUID
            user_id: The user UUID
        
        Returns:
            User dictionary
        """
        return self.client.get(f"organizations/{org_id}/users/{user_id}")
    
    def update(
        self,
        org_id: str,
        user_id: str,
        first_name: Optional[str] = None,
        last_name: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Update a user's information.
        
        Args:
            org_id: The organization UUID
            user_id: The user UUID
            first_name: New first name
            last_name: New last name
        
        Returns:
            Updated user dictionary
        """
        data = {}
        
        if first_name:
            data["firstName"] = first_name
        if last_name:
            data["lastName"] = last_name
        
        return self.client.put(f"organizations/{org_id}/users/{user_id}", json=data)
    
    def patch(
        self,
        org_id: str,
        users: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Perform user operations (invite, enable, disable, remove, etc.).
        
        Args:
            org_id: The organization UUID
            users: List of user operations with 'operation' and user details
        
        Returns:
            Operation results dictionary
        
        Example:
            >>> client.users.patch(
            ...     org_id="org-uuid",
            ...     users=[{
            ...         "email": "user@example.com",
            ...         "operation": "invite",
            ...         "firstName": "John",
            ...         "lastName": "Doe"
            ...     }]
            ... )
        """
        # Validate reset_mfa operations have factorId
        for user in users:
            if user.get("operation") == "reset_mfa" and "factorId" not in user:
                raise ValueError("factorId is required for reset_mfa operation")
        
        data = {"users": users}
        return self.client.patch(f"organizations/{org_id}/users", json=data)
    
    def get_groups(self, org_id: str, user_id: str) -> Dict[str, Any]:
        """
        Get all groups that a user belongs to.
        
        Args:
            org_id: The organization UUID
            user_id: The user UUID
        
        Returns:
            Dictionary containing list of groups
        """
        return self.client.get(f"organizations/{org_id}/users/{user_id}/groups")
    
    # Convenience methods for common operations
    def invite(
        self,
        org_id: str,
        email: str,
        first_name: Optional[str] = None,
        last_name: Optional[str] = None,
        is_admin: Optional[bool] = None
    ) -> Dict[str, Any]:
        """
        Invite a user to the organization.
        
        Args:
            org_id: The organization UUID
            email: User email address
            first_name: User's first name
            last_name: User's last name
            is_admin: Whether user should be an admin
        
        Returns:
            Operation results dictionary
        """
        user_data = {
            "email": email,
            "operation": "invite"
        }
        
        if first_name:
            user_data["firstName"] = first_name
        if last_name:
            user_data["lastName"] = last_name
        if is_admin is not None:
            user_data["isAdmin"] = is_admin
        
        return self.patch(org_id=org_id, users=[user_data])
    
    def enable(self, org_id: str, email: str) -> Dict[str, Any]:
        """
        Enable a user.
        
        Args:
            org_id: The organization UUID
            email: User email address
        
        Returns:
            Operation results dictionary
        """
        return self.patch(
            org_id=org_id,
            users=[{"email": email, "operation": "enable"}]
        )
    
    def disable(self, org_id: str, email: str) -> Dict[str, Any]:
        """
        Disable a user.
        
        Args:
            org_id: The organization UUID
            email: User email address
        
        Returns:
            Operation results dictionary
        """
        return self.patch(
            org_id=org_id,
            users=[{"email": email, "operation": "disable"}]
        )
    
    def remove(self, org_id: str, email: str) -> Dict[str, Any]:
        """
        Remove a user from the organization.
        
        Args:
            org_id: The organization UUID
            email: User email address
        
        Returns:
            Operation results dictionary
        """
        return self.patch(
            org_id=org_id,
            users=[{"email": email, "operation": "remove"}]
        )
    
    def resend_email_invite(self, org_id: str, email: str) -> Dict[str, Any]:
        """
        Resend email invitation to a user.
        
        Args:
            org_id: The organization UUID
            email: User email address
        
        Returns:
            Operation results dictionary
        """
        return self.patch(
            org_id=org_id,
            users=[{"email": email, "operation": "resend_email_invite"}]
        )
    
    def reset_password(self, org_id: str, email: str) -> Dict[str, Any]:
        """
        Reset a user's password.
        
        Args:
            org_id: The organization UUID
            email: User email address
        
        Returns:
            Operation results dictionary
        """
        return self.patch(
            org_id=org_id,
            users=[{"email": email, "operation": "reset_password"}]
        )
    
    def reset_mfa(
        self,
        org_id: str,
        email: str,
        factor_id: str
    ) -> Dict[str, Any]:
        """
        Reset a user's MFA factor.
        
        Args:
            org_id: The organization UUID
            email: User email address
            factor_id: MFA factor ID to reset
        
        Returns:
            Operation results dictionary
        """
        return self.patch(
            org_id=org_id,
            users=[{
                "email": email,
                "factorId": factor_id,
                "operation": "reset_mfa"
            }]
        )
    
    def get_users(self, org_id: str, group_id: str) -> Dict[str, Any]:
        """
        Get users in a specific group.
        
        Args:
            org_id: The organization UUID
            group_id: The group UUID
        
        Returns:
            Dictionary containing list of users in the group
        """
        return self.client.get(f"organizations/{org_id}/adminGroups/{group_id}/users")