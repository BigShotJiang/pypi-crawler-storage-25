# Copyright (c) 2026 Cisco Systems, Inc. and its affiliates
# SPDX-License-Identifier: Apache-2.0

"""
Tests for resource request shaping.
"""

from scc_sdk.resources.groups import GroupsResource
from scc_sdk.resources.roles import RolesResource
from scc_sdk.resources.subscriptions import SubscriptionsResource
from scc_sdk.resources.users import UsersResource


class DummyClient:
    """Minimal client stub for verifying resource requests."""

    def __init__(self):
        self.calls = []

    def get(self, endpoint, params=None):
        self.calls.append(("GET", endpoint, params))
        return {}

    def patch(self, endpoint, json=None):
        self.calls.append(("PATCH", endpoint, json))
        return {}


def test_groups_list_supports_pagination_params():
    client = DummyClient()

    GroupsResource(client).list(
        org_id="org-123",
        max=50,
        cursor="cursor-1",
    )

    assert client.calls == [
        ("GET", "organizations/org-123/adminGroups", {"max": 50, "cursor": "cursor-1"})
    ]


def test_roles_list_supports_user_filter():
    client = DummyClient()

    RolesResource(client).list(
        org_id="org-123",
        type="STATIC",
        user="00u2k67hy1xf3mRxG0h8",
    )

    assert client.calls == [
        (
            "GET",
            "organizations/org-123/roles",
            {"type": "STATIC", "user": "00u2k67hy1xf3mRxG0h8"},
        )
    ]


def test_subscriptions_patch_uses_spec_field_name():
    client = DummyClient()

    SubscriptionsResource(client).patch(
        org_id="org-123",
        subscription_id="sub-456",
        entitlements=[{"id": "E3S-AIDEF-ADV", "quantity": 10}],
        use_existing_tenants_for_products=["8a9f43fa-f8f5-4aac-8d0b-380cf6656255"],
    )

    assert client.calls == [
        (
            "PATCH",
            "organizations/org-123/subscriptions/sub-456",
            {
                "entitlements": [{"id": "E3S-AIDEF-ADV", "quantity": 10}],
                "useExistingTenantsForProducts": [
                    "8a9f43fa-f8f5-4aac-8d0b-380cf6656255"
                ],
            },
        )
    ]


def test_users_invite_supports_is_admin():
    client = DummyClient()

    UsersResource(client).invite(
        org_id="org-123",
        email="john.doe@example.com",
        first_name="John",
        last_name="Doe",
        is_admin=True,
    )

    assert client.calls == [
        (
            "PATCH",
            "organizations/org-123/users",
            {
                "users": [
                    {
                        "email": "john.doe@example.com",
                        "operation": "invite",
                        "firstName": "John",
                        "lastName": "Doe",
                        "isAdmin": True,
                    }
                ]
            },
        )
    ]


def test_users_reset_password_and_reset_mfa():
    client = DummyClient()
    resource = UsersResource(client)

    resource.reset_password(org_id="org-123", email="john.doe@example.com")
    resource.reset_mfa(
        org_id="org-123",
        email="john.doe@example.com",
        factor_id="uft2odnt5ez9xSslf0h8",
    )

    assert client.calls == [
        (
            "PATCH",
            "organizations/org-123/users",
            {"users": [{"email": "john.doe@example.com", "operation": "reset_password"}]},
        ),
        (
            "PATCH",
            "organizations/org-123/users",
            {
                "users": [
                    {
                        "email": "john.doe@example.com",
                        "factorId": "uft2odnt5ez9xSslf0h8",
                        "operation": "reset_mfa",
                    }
                ]
            },
        ),
    ]


def test_users_patch_requires_factor_id_for_reset_mfa():
    resource = UsersResource(DummyClient())

    try:
        resource.patch(
            org_id="org-123",
            users=[{"email": "john.doe@example.com", "operation": "reset_mfa"}],
        )
    except ValueError as exc:
        assert str(exc) == "factorId is required for reset_mfa operation"
    else:
        raise AssertionError("Expected ValueError for reset_mfa without factorId")
