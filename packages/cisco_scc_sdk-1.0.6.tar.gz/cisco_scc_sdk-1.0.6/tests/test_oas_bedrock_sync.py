# Copyright (c) 2026 Cisco Systems, Inc. and its affiliates
# SPDX-License-Identifier: Apache-2.0

"""
Tests for the OAS Bedrock sync helper.
"""

import sys
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path


MODULE_PATH = (
    Path(__file__).resolve().parents[1] / "tools" / "oas_bedrock_sync.py"
)
SPEC = spec_from_file_location("oas_bedrock_sync", MODULE_PATH)
MODULE = module_from_spec(SPEC)
assert SPEC.loader is not None
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


def test_format_duration_uses_hms_layout():
    assert MODULE.format_duration(3661) == "01:01:01"


def test_normalize_tag_maps_special_cases():
    assert MODULE.normalize_tag("Admin Groups") == "groups"
    assert MODULE.normalize_tag("Refresh Token") == "tokens"
    assert MODULE.normalize_tag("Organizations") == "organizations"


def test_extract_operations_from_document_reads_basic_fields(tmp_path):
    spec_path = tmp_path / "sample.yaml"
    spec_path.write_text("openapi: 3.1.0\npaths: {}\n", encoding="utf-8")
    document = {
        "paths": {
            "/organizations/{orgId}/users": {
                "get": {
                    "tags": ["Users"],
                    "operationId": "listUsers",
                    "summary": "List users",
                    "parameters": [
                        {"name": "status", "in": "query"},
                    ],
                },
                "patch": {
                    "tags": ["Users"],
                    "operationId": "patchUsers",
                    "summary": "Patch users",
                    "requestBody": {
                        "content": {
                            "application/json": {
                                "schema": {
                                    "properties": {
                                        "users": {"type": "array"},
                                    }
                                }
                            }
                        }
                    },
                },
            }
        }
    }

    operations = MODULE.extract_operations_from_document(spec_path, document)

    assert len(operations) == 2
    assert operations[0].parameters == ["status"]
    assert operations[1].request_body_fields == ["users"]


def test_build_gap_report_flags_missing_resource_file():
    operations = [
        MODULE.OperationSummary(
            spec_path="specs/test.yaml",
            tag="New Thing",
            method="GET",
            path="/new-things",
            operation_id="listNewThings",
            summary="List new things",
            parameters=[],
            request_body_fields=[],
        )
    ]

    report = MODULE.build_gap_report(operations, resource_inventory={})

    assert report["new_things"]["missing_files"] == ["New Thing"]


def test_infer_expected_methods_covers_nested_getters():
    operations = [
        MODULE.OperationSummary(
            spec_path="specs/test.yaml",
            tag="Admin Groups",
            method="GET",
            path="/organizations/{orgId}/adminGroups/{groupId}/roles",
            operation_id="getAssignedRoles",
            summary="Get assigned roles",
            parameters=[],
            request_body_fields=[],
        ),
        MODULE.OperationSummary(
            spec_path="specs/test.yaml",
            tag="Admin Groups",
            method="PATCH",
            path="/organizations/{orgId}/adminGroups/{groupId}",
            operation_id="patchGroup",
            summary="Patch group",
            parameters=[],
            request_body_fields=[],
        ),
    ]

    inferred = MODULE.infer_expected_methods(operations)

    assert "get_assigned_roles" in inferred
    assert "patch" in inferred


def test_trim_context_content_preserves_head_and_tail():
    content = "A" * 30 + "B" * 30 + "C" * 30

    trimmed = MODULE.trim_context_content(content, max_chars=40)

    assert trimmed.startswith("A" * 20)
    assert trimmed.endswith("C" * 20)
    assert "truncated" in trimmed


def test_select_relevant_context_paths_prioritizes_matching_resources(tmp_path):
    candidates = {
        "README.md": tmp_path / "README.md",
        "scc_sdk/client.py": tmp_path / "scc_sdk" / "client.py",
        "scc_sdk/resources/users.py": tmp_path / "scc_sdk" / "resources" / "users.py",
        "scc_sdk/resources/roles.py": tmp_path / "scc_sdk" / "resources" / "roles.py",
        "examples/users_example.py": tmp_path / "examples" / "users_example.py",
        "examples/roles_example.py": tmp_path / "examples" / "roles_example.py",
        "tests/test_resources.py": tmp_path / "tests" / "test_resources.py",
    }
    operations = [
        MODULE.OperationSummary(
            spec_path="specs/test.yaml",
            tag="Users",
            method="GET",
            path="/organizations/{orgId}/users",
            operation_id="listUsers",
            summary="List users",
            parameters=[],
            request_body_fields=[],
        )
    ]

    selected = MODULE.select_relevant_context_paths(candidates, operations)

    assert "scc_sdk/resources/users.py" in selected[:8]
    assert "examples/users_example.py" in selected[:8]


def test_parse_bedrock_json_handles_fenced_json():
    parsed = MODULE.parse_bedrock_json(
        "```json\n{\"summary\":\"ok\",\"should_apply\":false,\"changes\":[],\"notes\":[]}\n```"
    )

    assert parsed["summary"] == "ok"


def test_parse_bedrock_json_raises_custom_error_for_truncated_payload():
    try:
        MODULE.parse_bedrock_json("{\"summary\":\"broken")
    except MODULE.BedrockResponseParseError as exc:
        assert "Failed to parse Bedrock response as JSON" in str(exc)
        assert exc.raw_text == "{\"summary\":\"broken"
    else:
        raise AssertionError("Expected BedrockResponseParseError for truncated JSON")


def test_parse_arguments_defaults_to_apply_mode():
    args = MODULE.parse_arguments([])

    assert args.mode == "apply"
