# Copyright (c) 2026 Cisco Systems, Inc. and its affiliates
# SPDX-License-Identifier: Apache-2.0

"""
Extended tests for resource request shaping - coverage improvements.
"""

from scc_sdk.resources.groups import GroupsResource
from scc_sdk.resources.roles import RolesResource
from scc_sdk.resources.subscriptions import SubscriptionsResource
from scc_sdk.resources.users import UsersResource
from scc_sdk.resources.organizations import OrganizationsResource


class DummyClient:
    """Minimal client stub for verifying resource requests."""

    def __init__(self):
        self.calls = []

    def get(self, endpoint, params=None):
        self.calls.append(("GET", endpoint, params))
        return {}

    def patch(self, endpoint, json=None):
        self.calls.append(("PATCH", endpoint, json))
        return {}

    def post(self, endpoint, json=None):
        self.calls.append(("POST", endpoint, json))
        return {}

    def put(self, endpoint, json=None):
        self.calls.append(("PUT", endpoint, json))
        return {}

    def delete(self, endpoint):
        self.calls.append(("DELETE", endpoint))
        return {}


# Organizations tests
def test_organizations_list_with_filters():
    client = DummyClient()
    OrganizationsResource(client).list(
        name="Acme",
        type="MANAGED",
        region_code="NAM",
        country_code="US",
        manager_org_id="mgr-123",
        max=50,
        cursor="cursor-1",
        sort_by="name",
        order="ASC",
    )
    assert client.calls == [
        (
            "GET",
            "organizations",
            {
                "name": "Acme",
                "type": "MANAGED",
                "regionCode": "NAM",
                "countryCode": "US",
                "managerOrgId": "mgr-123",
                "max": 50,
                "cursor": "cursor-1",
                "sortBy": "name",
                "order": "ASC",
            },
        )
    ]


def test_organizations_get():
    client = DummyClient()
    OrganizationsResource(client).get(org_id="org-123")
    assert client.calls == [("GET", "organizations/org-123", None)]


def test_organizations_create():
    client = DummyClient()
    OrganizationsResource(client).create(
        name="New Org",
        region_code="EMEA",
        type="MANAGED",
    )
    assert client.calls == [
        (
            "POST",
            "organizations",
            {"name": "New Org", "regionCode": "EMEA", "type": "MANAGED"},
        )
    ]


def test_organizations_update():
    client = DummyClient()
    OrganizationsResource(client).update(
        org_id="org-123",
        name="Updated Org",
    )
    assert client.calls == [
        (
            "PUT",
            "organizations/org-123",
            {"name": "Updated Org"},
        )
    ]


# Groups tests
def test_groups_get():
    client = DummyClient()
    GroupsResource(client).get(org_id="org-123", group_id="grp-456")
    assert client.calls == [("GET", "organizations/org-123/adminGroups/grp-456", None)]


def test_groups_create_with_description():
    client = DummyClient()
    GroupsResource(client).create(
        org_id="org-123",
        name="Admins",
        description="Admin group",
        applies_to="all",
    )
    assert client.calls == [
        (
            "POST",
            "organizations/org-123/adminGroups",
            {"name": "Admins", "description": "Admin group", "appliesTo": "all"},
        )
    ]


def test_groups_update():
    client = DummyClient()
    GroupsResource(client).update(
        org_id="org-123",
        group_id="grp-456",
        name="Super Admins",
        description="Super admin group",
    )
    assert client.calls == [
        (
            "PUT",
            "organizations/org-123/adminGroups/grp-456",
            {"name": "Super Admins", "description": "Super admin group"},
        )
    ]


def test_groups_delete():
    client = DummyClient()
    GroupsResource(client).delete(org_id="org-123", group_id="grp-456")
    assert client.calls == [("DELETE", "organizations/org-123/adminGroups/grp-456")]


def test_groups_patch_add_users():
    client = DummyClient()
    GroupsResource(client).patch(
        org_id="org-123",
        group_id="grp-456",
        users=[{"operation": "add", "id": "user@example.com"}],
    )
    assert client.calls == [
        (
            "PATCH",
            "organizations/org-123/adminGroups/grp-456",
            {"users": [{"operation": "add", "id": "user@example.com"}]},
        )
    ]


def test_groups_patch_remove_managed_orgs():
    client = DummyClient()
    GroupsResource(client).patch(
        org_id="org-123",
        group_id="grp-456",
        managed_orgs=[{"operation": "remove", "id": "org-789"}],
    )
    assert client.calls == [
        (
            "PATCH",
            "organizations/org-123/adminGroups/grp-456",
            {"managedOrg": [{"operation": "remove", "id": "org-789"}]},
        )
    ]


def test_groups_get_managed_organizations():
    client = DummyClient()
    GroupsResource(client).get_managed_organizations(org_id="org-123", group_id="grp-456")
    assert client.calls == [
        ("GET", "organizations/org-123/adminGroups/grp-456/managedOrgs", None)
    ]


def test_groups_get_assigned_roles():
    client = DummyClient()
    GroupsResource(client).get_assigned_roles(org_id="org-123", group_id="grp-456")
    assert client.calls == [
          ("GET", "organizations/org-123/adminGroups/grp-456/roles", None)
    ]


# Roles tests
def test_roles_get():
    client = DummyClient()
    RolesResource(client).get(org_id="org-123", role_id="role-456")
    assert client.calls == [("GET", "organizations/org-123/roles/role-456", None)]


def test_roles_list_with_no_filters():
    client = DummyClient()
    RolesResource(client).list(org_id="org-123")
    assert client.calls == [("GET", "organizations/org-123/roles", {})]


# Subscriptions tests
def test_subscriptions_list_with_name_filter():
    client = DummyClient()
    SubscriptionsResource(client).list(org_id="org-123", name="Premium")
    assert client.calls == [
        ("GET", "organizations/org-123/subscriptions", {"name": "Premium"})
    ]


def test_subscriptions_get():
    client = DummyClient()
    SubscriptionsResource(client).get(org_id="org-123", subscription_id="sub-456")
    assert client.calls == [
        ("GET", "organizations/org-123/subscriptions/sub-456", None)
    ]


def test_subscriptions_create_with_products():
    client = DummyClient()
    SubscriptionsResource(client).create(
        org_id="org-123",
        claim_code="ABCD-EFGH-IJKL-MNOP",
        type="MANAGED",
        products=[{"id": "prod-123", "regionCode": "NAM"}],
    )
    assert client.calls == [
        (
            "POST",
            "organizations/org-123/subscriptions",
            {
                "claimCode": "ABCD-EFGH-IJKL-MNOP",
                "type": "MANAGED",
                "products": [{"id": "prod-123", "regionCode": "NAM"}],
            },
        )
    ]


def test_subscriptions_update_product_activation():
    client = DummyClient()
    SubscriptionsResource(client).update(
        org_id="org-123",
        subscription_id="sub-456",
        product_id="prod-789",
        status=True,
        region_code="NAM",
        source_instance_id="instance-123",
        initial_admin="admin@example.com",
    )
    assert client.calls == [
        (
            "PUT",
            "organizations/org-123/subscriptions/sub-456",
            {
                "productId": "prod-789",
                "status": True,
                "regionCode": "NAM",
                "sourceInstanceId": "instance-123",
                "initialAdmin": "admin@example.com",
            },
        )
    ]


# Users additional tests
def test_users_disable():
    client = DummyClient()
    UsersResource(client).disable(org_id="org-123", email="user@example.com")
    assert client.calls == [
        (
            "PATCH",
            "organizations/org-123/users",
            {"users": [{"email": "user@example.com", "operation": "disable"}]},
        )
    ]


def test_users_enable():
    client = DummyClient()
    UsersResource(client).enable(org_id="org-123", email="user@example.com")
    assert client.calls == [
        (
            "PATCH",
            "organizations/org-123/users",
            {"users": [{"email": "user@example.com", "operation": "enable"}]},
        )
    ]


def test_users_remove():
    client = DummyClient()
    UsersResource(client).remove(org_id="org-123", email="user@example.com")
    assert client.calls == [
        (
            "PATCH",
            "organizations/org-123/users",
            {"users": [{"email": "user@example.com", "operation": "remove"}]},
        )
    ]


def test_users_resend_email_invite():
    client = DummyClient()
    UsersResource(client).resend_email_invite(org_id="org-123", email="user@example.com")
    assert client.calls == [
        (
            "PATCH",
            "organizations/org-123/users",
            {"users": [{"email": "user@example.com", "operation": "resend_email_invite"}]},
        )
    ]


def test_users_reset_mfa_explicit():
    client = DummyClient()
    UsersResource(client).reset_mfa(
        org_id="org-123",
        email="user@example.com",
        factor_id="factor-456",
    )
    assert client.calls == [
        (
            "PATCH",
            "organizations/org-123/users",
            {"users": [{"email": "user@example.com", "factorId": "factor-456", "operation": "reset_mfa"}]},
        )
    ]


def test_users_update_partial():
    client = DummyClient()
    UsersResource(client).update(
        org_id="org-123",
        user_id="user-456",
        first_name="John",
    )
    assert client.calls == [
        ("PUT", "organizations/org-123/users/user-456", {"firstName": "John"})
    ]


def test_users_get():
    client = DummyClient()
    UsersResource(client).get(org_id="org-123", user_id="user-456")
    assert client.calls == [("GET", "organizations/org-123/users/user-456", None)]


def test_users_list_with_filters():
    client = DummyClient()
    UsersResource(client).list(org_id="org-123", status="ACTIVE")
    assert client.calls == [
        ("GET", "organizations/org-123/users", {"status": "ACTIVE"})
    ]


def test_users_get_groups():
    client = DummyClient()
    UsersResource(client).get_groups(org_id="org-123", user_id="user-456")
    assert client.calls == [
        ("GET", "organizations/org-123/users/user-456/groups", None)
    ]
