import lazy_loader

__version__ = '2026.4.1'

"""Lazy imports as described in https://scientific-python.org/specs/spec-0001"""
__getattr__, __dir__, __all__ = lazy_loader.attach_stub(__name__, __file__)


def set_jit(enabled: bool = False):
    """Enable numba-jitting some functions at import time.

    As modules are loaded lazily, enable jitting like so::

        import qutil
        qutil.set_jit(True)
        import qutil.math  # has some jitted functions

    Alternatively, set the ``QUTIL_JIT_ENABLED`` environment variable.

    """
    import importlib
    if enabled and importlib.util.find_spec('numba') is None:
        raise RuntimeError('Could not find numba; jit disabled')

    import os
    os.environ["QUTIL_JIT_ENABLED"] = str(bool(enabled))


def get_jit_enabled() -> bool:
    """Queries if jitting is enabled."""
    import os
    return bool(os.environ.get("QUTIL_JIT_ENABLED", False))


del lazy_loader
