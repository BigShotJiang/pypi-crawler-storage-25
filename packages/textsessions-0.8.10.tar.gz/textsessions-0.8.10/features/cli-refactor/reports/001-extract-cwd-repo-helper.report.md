# Report: 001 — Extract CWD→repo detection helper
Date: 2026-04-20T00:00:00Z
Status: DONE

## Changes
- 524547a refactor: extract _resolve_repo_from_cwd helper, add regression tests (textsessions)

## Test results
- textsessions: 175 passed, 1 skipped (0 failed)

## Notes for next prompt
- `_resolve_repo_from_cwd` lives at module level in `src/textsessions/cli.py`, before the `@click.group()` decorator
- It accepts an optional `add_hint` kwarg to preserve the differing second error line between `new_cmd` ("Add it with: textsessions add .") and `sessions_cmd` ("Run: textsessions add .")
- The warning message (parent repo match) is identical in both callers and is emitted inside the helper
- `sessions_cmd` uses `_resolve_repo_from_cwd(config)` (default hint) and then reads `.label` from the result; `new_cmd` passes `add_hint="Add it with: textsessions add ."`
