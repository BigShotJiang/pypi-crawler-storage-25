# Report: 003 — CLI tag/rename commands: use mutate_index
Date: 2026-04-20T00:00:00Z
Status: DONE

## Changes
- b2a56bf refactor: rename_cmd and tag_cmd use mutate_index (textsessions)

## Test results
- textsessions: 175 passed, 1 skipped

## Notes for next prompt
- Both `rename_cmd` and `tag_cmd` now use `mutate_index(rk, s.id, fn)` instead of
  the manual load/mutate/save/write-tsv pattern.
- A closure captures the post-mutation state (name / tags) needed for the echo line,
  since `mutate_index` returns None.
- Imports for `load_index`, `save_index`, `write_legacy_tsv` were removed from both
  commands; only `mutate_index` (plus the do_* helpers) is imported.
- No behaviour change; `do_rename`/`do_tag`/`do_untag` mutate the dict in place so
  skipping the return-value reassignment is safe.
