# Report: 002 — Split scan-ghosts into subfunctions
Date: 2026-04-20T00:00:00Z
Status: DONE

## Changes
- 37386eb refactor: split scan_ghosts into private subfunctions (textsessions)

## Test results
- textsessions: 175 passed, 1 skipped

## Notes for next prompt
- Five helpers extracted: `_scan_ghosts_keep`, `_scan_ghosts_keep_all`, `_scan_ghosts_report`, `_scan_ghosts_delete`, `_scan_ghosts_archive`
- `scan_ghosts` is now a thin dispatcher (~30 lines)
- `_scan_ghosts_report` handles both `--json` and the human-readable table (early return on `as_json`); the dispatcher checks `as_json` after the call to avoid double-return logic
- No behaviour changes; all existing tests pass unchanged
