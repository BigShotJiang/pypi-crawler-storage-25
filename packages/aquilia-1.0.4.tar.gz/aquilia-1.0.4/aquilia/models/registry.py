"""
Aquilia Model Registry -- global registry for all Model subclasses.

Tracks all concrete models, resolves forward FK/M2M references,
creates tables, and manages the global database connection.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..db.engine import AquiliaDatabase
    from .base import Model

logger = logging.getLogger("aquilia.models.registry")

__all__ = ["ModelRegistry"]


class ModelRegistry:
    """
    Global registry for all Model subclasses.

    Replaces the old AMDL-based ModelRegistry.
    Tracks all concrete models and resolves forward references.
    """

    _models: dict[str, type[Model]] = {}
    _db: AquiliaDatabase | None = None
    _app_models: dict[str, dict[str, type[Model]]] = {}  # app_label → {name → cls}

    @classmethod
    def register(cls, model_cls: type[Model]) -> None:
        """Register a model class."""
        name = model_cls.__name__
        cls._models[name] = model_cls

        # Track by app_label
        app = getattr(model_cls._meta, "app_label", "") or ""
        if app not in cls._app_models:
            cls._app_models[app] = {}
        cls._app_models[app][name] = model_cls

        # Resolve any pending forward FK references
        cls._resolve_relations()

    @classmethod
    def get(cls, name: str) -> type[Model] | None:
        """Get model class by name."""
        return cls._models.get(name)

    @classmethod
    def all_models(cls) -> dict[str, type[Model]]:
        """Get all registered models."""
        return dict(cls._models)

    @classmethod
    def get_app_models(cls, app_label: str) -> dict[str, type[Model]]:
        """Get all models for a specific app."""
        return dict(cls._app_models.get(app_label, {}))

    @classmethod
    def set_database(cls, db: AquiliaDatabase) -> None:
        """Set global database for all models."""
        cls._db = db
        for model_cls in cls._models.values():
            model_cls._db = db

    @classmethod
    def get_database(cls) -> AquiliaDatabase | None:
        return cls._db

    @classmethod
    def _resolve_relations(cls) -> None:
        """Resolve forward-referenced model names in FK/M2M fields."""
        from .fields_module import RelationField

        for model_cls in cls._models.values():
            for field in model_cls._fields.values():
                if isinstance(field, RelationField) and isinstance(field.to, str):
                    field.resolve_model(cls._models)

    @classmethod
    async def create_tables(cls, db: AquiliaDatabase | None = None) -> list[str]:
        """
        Create tables for all registered models in topological order.

        FK target tables are created before tables that reference them.
        """
        target_db = db or cls._db
        if not target_db:
            from ..faults.domains import DatabaseConnectionFault

            raise DatabaseConnectionFault(
                url="(none)",
                reason="No database configured for ModelRegistry. "
                "Call ModelRegistry.set_database(db) before create_tables().",
            )

        # Build dependency graph and topologically sort
        ordered = cls._topological_sort()
        dialect = getattr(target_db, "dialect", "sqlite")

        statements: list[str] = []
        for model_cls in ordered:
            if model_cls._meta.abstract:
                continue
            if not model_cls._meta.managed:
                continue

            # Create main table
            sql = model_cls.generate_create_table_sql(dialect=dialect)
            await target_db.execute(sql)
            statements.append(sql)

            # Create indexes
            for idx_sql in model_cls.generate_index_sql(dialect=dialect):
                try:
                    await target_db.execute(idx_sql)
                except Exception as idx_exc:
                    # MySQL error 1061 = Duplicate key name (index already
                    # exists).  MySQL lacks CREATE INDEX IF NOT EXISTS, so
                    # we silently skip this.
                    _orig = getattr(idx_exc, "__cause__", idx_exc)
                    _args = getattr(_orig, "args", ())
                    if _args and _args[0] == 1061:
                        pass  # index already exists on MySQL -- silently skip
                    else:
                        raise
                statements.append(idx_sql)

            # Create M2M junction tables
            for m2m_sql in model_cls.generate_m2m_sql(dialect=dialect):
                await target_db.execute(m2m_sql)
                statements.append(m2m_sql)

        return statements

    @classmethod
    def _topological_sort(cls) -> list[type[Model]]:
        """
        Sort registered models in topological order based on FK dependencies.

        Models with no FK dependencies come first. Models that reference
        other models come after their targets.
        """
        from .fields_module import ForeignKey, OneToOneField

        # Build adjacency: model_name -> set of dependency model names
        deps: dict[str, set] = {}
        name_to_cls: dict[str, type[Model]] = {}

        for name, model_cls in cls._models.items():
            if model_cls._meta.abstract or not model_cls._meta.managed:
                continue
            name_to_cls[name] = model_cls
            deps[name] = set()
            for field in model_cls._fields.values():
                if isinstance(field, (ForeignKey, OneToOneField)):
                    target = field.to if isinstance(field.to, str) else field.to.__name__
                    # Only add dependency if target is a registered model
                    # and not a self-reference
                    if target != name and target in cls._models:
                        deps[name].add(target)

        # Kahn's algorithm for topological sort
        in_degree: dict[str, int] = {n: 0 for n in deps}
        for node, node_deps in deps.items():
            for dep in node_deps:
                if dep in in_degree:
                    in_degree[dep] = in_degree.get(dep, 0)

        # Count incoming edges
        reverse_adj: dict[str, list[str]] = {n: [] for n in deps}
        for node, node_deps in deps.items():
            for dep in node_deps:
                if dep in reverse_adj:
                    reverse_adj[dep].append(node)

        in_degree = {n: len(d) for n, d in deps.items()}

        queue = [n for n, deg in in_degree.items() if deg == 0]
        ordered: list[type[Model]] = []

        while queue:
            node = queue.pop(0)
            if node in name_to_cls:
                ordered.append(name_to_cls[node])
            for dependent in reverse_adj.get(node, []):
                in_degree[dependent] -= 1
                if in_degree[dependent] == 0:
                    queue.append(dependent)

        # Add any remaining models (circular FK -- nullable breaks the cycle)
        for name, model_cls in name_to_cls.items():
            if model_cls not in ordered:
                ordered.append(model_cls)

        return ordered

    @classmethod
    async def drop_tables(cls, db: AquiliaDatabase | None = None) -> list[str]:
        """Drop all registered model tables (dangerous!)."""
        target_db = db or cls._db
        if not target_db:
            from ..faults.domains import DatabaseConnectionFault

            raise DatabaseConnectionFault(
                url="(none)",
                reason="No database configured for ModelRegistry. "
                "Call ModelRegistry.set_database(db) before drop_tables().",
            )

        statements: list[str] = []
        for model_cls in reversed(list(cls._models.values())):
            if model_cls._meta.abstract:
                continue
            sql = f'DROP TABLE IF EXISTS "{model_cls._table_name}"'
            await target_db.execute(sql)
            statements.append(sql)

        return statements

    @classmethod
    def reset(cls) -> None:
        """Clear registry (for testing)."""
        cls._models.clear()
        cls._app_models.clear()
        cls._db = None

    @classmethod
    def check_constraints(cls) -> list[str]:
        """
        Validate all model constraints and return a list of issues.

        Checks:
        - FK targets exist
        - M2M targets exist
        - No duplicate table names
        - No circular FK chains without nullable break
        """
        issues: list[str] = []
        table_names: dict[str, str] = {}  # table → model name

        from .fields_module import ForeignKey, ManyToManyField

        for name, model_cls in cls._models.items():
            if model_cls._meta.abstract:
                continue

            tbl = model_cls._table_name
            if tbl in table_names:
                issues.append(f"Duplicate table '{tbl}': {name} and {table_names[tbl]}")
            table_names[tbl] = name

            for fname, field in model_cls._fields.items():
                if isinstance(field, ForeignKey):
                    target = field.to if isinstance(field.to, str) else field.to.__name__
                    if target not in cls._models:
                        issues.append(f"{name}.{fname}: FK target '{target}' not registered")
                elif isinstance(field, ManyToManyField):
                    target = field.to if isinstance(field.to, str) else field.to.__name__
                    if target not in cls._models:
                        issues.append(f"{name}.{fname}: M2M target '{target}' not registered")

        return issues

    # ── Lifecycle hooks (DI compatibility) ───────────────────────────

    async def on_startup(self) -> None:
        if ModelRegistry._models:
            await ModelRegistry.create_tables()

    async def on_shutdown(self) -> None:
        pass
