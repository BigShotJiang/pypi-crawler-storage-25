"""Aquilate CLI - Main Entry Point.

The `aq` command provides manifest-driven project orchestration.

Commands:
    init     - Create new workspace or module
    add      - Add module to workspace
    generate - Generate controllers and services
    validate - Static validation of manifests
    compile  - Compile manifests to artifacts
    run      - Development server with hot-reload
    serve    - Production server
    freeze   - Freeze generated artifacts
    inspect  - Query compiled artifacts
    migrate  - Convert legacy projects
    doctor   - Diagnose workspace issues
    version  - Show version information
"""

import contextlib
import sys
from pathlib import Path

# ── Windows UTF-8 fix ────────────────────────────────────────────────────────
# On Windows the default stdout/stderr codec is 'charmap' which cannot encode
# most Unicode characters used for CLI glyphs (arrows, boxes, checkmarks …).
# Reconfigure both streams to UTF-8 if possible; if the stream doesn't support
# reconfigure (e.g. it's been redirected) we swap it for a UTF-8 wrapper so
# the rest of the code never has to worry about the codec.
if sys.platform == "win32":
    import io

    for _stream_name in ("stdout", "stderr"):
        _stream = getattr(sys, _stream_name)
        if hasattr(_stream, "reconfigure"):
            with contextlib.suppress(Exception):
                _stream.reconfigure(encoding="utf-8", errors="replace")
        elif hasattr(_stream, "buffer"):
            with contextlib.suppress(Exception):
                setattr(
                    sys,
                    _stream_name,
                    io.TextIOWrapper(
                        _stream.buffer,
                        encoding="utf-8",
                        errors="replace",
                        line_buffering=_stream.line_buffering,
                    ),
                )
# ─────────────────────────────────────────────────────────────────────────────

import re as _re

import click

from . import __cli_name__, __version__
from .utils.colors import (
    _BULLET,
    _CHECK,
    _CROSS,
    accent,
    banner,
    bold,
    bullet,
    dim,
    error,
    info,
    kv,
    next_steps,
    panel,
    section,
    step,
    success,
    table,
    tree_item,
    warning,
)
from .utils.prompts import (
    ask,
    confirm,
    flow_header,
    multi_select,
    recap,
    select,
)

_DEFAULT_DB_URL = "sqlite:///db.sqlite3"

# ═══════════════════════════════════════════════════════════════════════════
# Workspace guard -- block operational commands when no workspace.py present
# ═══════════════════════════════════════════════════════════════════════════

# Commands that do NOT require a workspace.py to exist:
_NO_WORKSPACE_REQUIRED = frozenset(
    {
        "init",
        "version",
        "--version",
        "--help",
        "help",
        "doctor",
    }
)


def _require_workspace(ctx: click.Context) -> None:
    """Abort if workspace.py is not found in the current directory.

    Allows a small set of commands (``init``, ``version``, ``doctor``)
    to run without a workspace.  Everything else requires the file.
    Also skips the check when ``--help`` is requested.
    """
    # Never block --help output
    if ctx.resilient_parsing or "--help" in (ctx.params or {}):
        return
    # Check sys.argv for --help (covers Click's eager help handling)
    import sys as _sys

    if "--help" in _sys.argv or "-h" in _sys.argv:
        return

    # Walk up the invocation chain to find the actual sub-command name
    parts: list[str] = []
    c: click.Context | None = ctx
    while c is not None:
        if c.info_name and c.info_name not in ("cli", "aq"):
            parts.insert(0, c.info_name)
        c = c.parent
    top = parts[0] if parts else ""

    if top in _NO_WORKSPACE_REQUIRED:
        return

    # During Click's own --help processing, invoked_subcommand is set before
    # the sub-command callback fires.  At the root level when there's no
    # sub-command yet, skip the check.
    if not top:
        return

    workspace_file = Path("workspace.py")
    if not workspace_file.exists():
        click.echo()
        error(f"  {_CROSS} No workspace.py found in the current directory.")
        click.echo()
        info("  Run 'aq init workspace <name>' to create a new Aquilia workspace first.")
        click.echo()
        raise SystemExit(1)


def _detect_workspace_db_url() -> str:
    """Auto-detect the database URL from workspace.py in the current directory.

    Scans workspace.py for ``.database(url="...")`` or
    ``Integration.database(url="...")`` patterns first.  If not found,
    looks for typed config patterns like ``MysqlConfig(...)``,
    ``PostgresConfig(...)``, or ``OracleConfig(...)`` and reconstructs
    the URL from the extracted parameters.

    Falls back to the framework default ``sqlite:///db.sqlite3``.
    """
    workspace_file = Path("workspace.py")
    if not workspace_file.exists():
        return _DEFAULT_DB_URL
    try:
        text = workspace_file.read_text(encoding="utf-8")
        # Match .database(url="<url>") or .database(url='<url>')
        m = _re.search(r'\.database\(\s*url\s*=\s*["\']([^"\']+)["\']', text)
        if m:
            return m.group(1)

        # Match typed config: MysqlConfig(...), PostgresConfig(...), OracleConfig(...)
        cfg_match = _re.search(
            r"(Mysql|Postgres|Oracle)Config\s*\((.*?)\)",
            text,
            _re.DOTALL,
        )
        if cfg_match:
            backend = cfg_match.group(1).lower()
            block = cfg_match.group(2)

            def _extract(key: str, default: str = "") -> str:
                m = _re.search(rf'{key}\s*=\s*["\']([^"\']*)["\']', block)
                return m.group(1) if m else default

            def _extract_int(key: str, default: int = 0) -> int:
                m = _re.search(rf"{key}\s*=\s*(\d+)", block)
                return int(m.group(1)) if m else default

            host = _extract("host", "localhost")
            user = _extract("user", "")
            password = _extract("password", "")
            # Support both name= and database= aliases
            name = _extract("name") or _extract("database") or _extract("service_name")

            if backend == "mysql":
                port = _extract_int("port", 3306)
                scheme = "mysql"
            elif backend == "postgres":
                port = _extract_int("port", 5432)
                scheme = "postgresql"
            elif backend == "oracle":
                port = _extract_int("port", 1521)
                scheme = "oracle"
            else:
                return _DEFAULT_DB_URL

            creds = f"{user}:{password}@" if user else ""
            return f"{scheme}://{creds}{host}:{port}/{name}"
    except Exception:
        pass
    return _DEFAULT_DB_URL


# ═══════════════════════════════════════════════════════════════════════════
# Custom Click help formatter
# ═══════════════════════════════════════════════════════════════════════════


class AquiliaGroup(click.Group):
    """Click group subclass with branded help output."""

    # Command categories for grouped display
    _CATEGORIES = {
        "Scaffold": ["init", "add", "generate"],
        "Develop": ["run", "validate", "compile", "test", "discover", "doctor"],
        "Production": ["serve", "freeze"],
        "Database": ["db"],
        "Admin": ["admin"],
        "Inspect": ["inspect", "manifest", "analytics"],
        "Subsystems": ["ws", "cache", "mail", "i18n"],
        "MLOps": ["pack", "model", "mlops-deploy", "observe", "export", "plugin", "lineage", "experiment"],
        "Deploy": ["deploy-gen", "artifact"],
        "Migration": ["migrate"],
    }

    def format_help(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        """Override to add Aquilia branding to the top-level help."""
        # Only show the full banner for the root group
        if ctx.parent is None:
            banner("Aquilia", subtitle=f"v{__version__}  {_CHECK}  manifest-driven framework CLI")
            click.echo()

        super().format_help(ctx, formatter)

    def format_commands(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        """Format command listing with categorised groups."""
        commands_map = {}
        for subcommand in self.list_commands(ctx):
            cmd = self.get_command(ctx, subcommand)
            if cmd is None or cmd.hidden:
                continue
            help_text = cmd.get_short_help_str(limit=48)
            commands_map[subcommand] = help_text

        if not commands_map:
            return

        # Try categorised output for root group
        if ctx.parent is None:
            categorised: set[str] = set()
            max_len = max(len(c) for c in commands_map) + 2

            for cat_name, cat_cmds in self._CATEGORIES.items():
                matched = [(c, commands_map[c]) for c in cat_cmds if c in commands_map]
                if not matched:
                    continue
                with formatter.section(click.style(cat_name, fg="cyan", bold=True)):
                    for name, help_text in matched:
                        padded = name.ljust(max_len)
                        styled_name = click.style(padded, fg="green")
                        formatter.write(f"  {styled_name} {help_text}\n")
                        categorised.add(name)

            # Any uncategorised commands
            uncategorised = [(c, h) for c, h in commands_map.items() if c not in categorised]
            if uncategorised:
                with formatter.section(click.style("Other", fg="cyan", bold=True)):
                    for name, help_text in uncategorised:
                        padded = name.ljust(max_len)
                        styled_name = click.style(padded, fg="green")
                        formatter.write(f"  {styled_name} {help_text}\n")
        else:
            # Subgroups: simple listing
            with formatter.section(click.style("Commands", fg="cyan", bold=True)):
                max_len = max(len(c) for c in commands_map) + 2
                for name, help_text in commands_map.items():
                    padded = name.ljust(max_len)
                    styled_name = click.style(padded, fg="green")
                    formatter.write(f"  {styled_name} {help_text}\n")


@click.group(cls=AquiliaGroup)
@click.version_option(version=__version__, prog_name=__cli_name__)
@click.option("--verbose", "-v", is_flag=True, help="Verbose output (show debug details, full tracebacks)")
@click.option("--quiet", "-q", is_flag=True, help="Minimal output (suppress banners & decorations)")
@click.option("--debug", is_flag=True, help="Enable debug mode (full stack traces on errors)")
@click.option("--no-color", is_flag=True, help="Disable coloured output")
@click.pass_context
def cli(ctx, verbose: bool, quiet: bool, debug: bool, no_color: bool):
    """Manifest-driven, artifact-first project orchestration.

    \b
    Quick start:
      aq init workspace my-api
      aq add module users
      aq validate
      aq run
    """
    ctx.ensure_object(dict)
    ctx.obj["verbose"] = verbose
    ctx.obj["quiet"] = quiet
    ctx.obj["debug"] = debug
    ctx.obj["no_color"] = no_color

    # Disable click/ANSI colour if requested
    if no_color:
        ctx.color = False

    # Workspace guard -- operational commands require workspace.py
    _require_workspace(ctx)


# ============================================================================
# Commands
# ============================================================================


@cli.group(cls=AquiliaGroup)
def init():
    """Initialize new workspace or module."""
    pass


@init.command("workspace")
@click.argument("name", required=False, default=None)
@click.option("--minimal", is_flag=True, help="Minimal setup (no examples)")
@click.option("--template", type=str, help="Use template (api, service, monolith)")
@click.option("--yes", "-y", is_flag=True, help="Skip interactive prompts and use defaults")
@click.pass_context
def init_workspace(ctx, name: str | None, minimal: bool, template: str | None, yes: bool):
    """
    Create a new Aquilia workspace.

    When run without arguments, starts an interactive setup wizard with
    styled prompts. Pass --yes to skip prompts and use defaults.

    Examples:
      aq init workspace                    # Interactive mode
      aq init workspace my-api             # Interactive with name pre-filled
      aq init workspace my-api --minimal   # Non-interactive minimal
      aq init workspace my-api -y          # Non-interactive with defaults
    """
    from .commands.init import create_workspace

    interactive = not yes and sys.stdin.isatty()

    # ── Interactive flow ─────────────────────────────────────────────
    if interactive:
        flow_header(
            "create-aquilia",
            "Scaffold an Aquilia workspace in seconds.",
        )

        # 1. Project name
        if not name:
            name = ask("Project name", default="my-api", required=True, validator=_validate_name)
        else:
            click.echo(
                f"  {click.style('◆', fg='cyan')} {click.style('Project name', fg='white', bold=True)} {click.style('…', dim=True)} {click.style(name, fg='cyan')}"
            )

        # 2. Template
        if not template:
            template_choice = select(
                "Template",
                [
                    ("none", "Blank workspace -- start from scratch"),
                    ("api", "REST API -- routes, JSON responses, CORS"),
                    ("service", "Microservice -- lightweight, single-purpose"),
                    ("monolith", "Monolith -- full-featured, batteries included"),
                ],
                default=0,
            )
            template = None if template_choice == "none" else template_choice

        # 3. Minimal mode
        if not minimal:
            minimal = not confirm("Include full project structure?", default=True)

        # 4. Features to include
        if not minimal:
            features = multi_select(
                "Include",
                [
                    ("Dockerfile", "Container deployment", True),
                    ("docker-compose", "Multi-container orchestration", True),
                    ("Makefile", "Build automation targets", True),
                    ("README", "Project documentation", True),
                    (".gitignore", "Git ignore rules", True),
                    ("tests", "Test directory with conftest", True),
                ],
            )

            include_docker = "Dockerfile" in features or "docker-compose" in features
            include_makefile = "Makefile" in features
            include_readme = "README" in features
            include_gitignore = ".gitignore" in features
            include_tests = "tests" in features
        else:
            include_docker = False
            include_makefile = False
            include_readme = False
            include_gitignore = True
            include_tests = True

        # 5. License
        license_choice = select(
            "License",
            [
                ("none", "No license file"),
                ("MIT", "MIT License"),
                ("Apache-2.0", "Apache License 2.0"),
                ("BSD-3", "BSD 3-Clause License"),
            ],
            default=0,
        )
        include_license = None if license_choice == "none" else license_choice

        # 6. Confirmation
        recap(
            [
                ("Name", name),
                ("Template", template or "none"),
                ("Mode", "minimal" if minimal else "full"),
                ("Docker", "yes" if include_docker else "no"),
                ("Makefile", "yes" if include_makefile else "no"),
                ("README", "yes" if include_readme else "no"),
                ("Tests", "yes" if include_tests else "no"),
                ("License", include_license or "none"),
            ],
            title="Configuration",
        )

        if not confirm("Scaffold project?", default=True):
            click.echo()
            info("  Cancelled.")
            return

    else:
        # Non-interactive defaults
        if not name:
            error(f"  {_CROSS} Project name is required in non-interactive mode")
            sys.exit(1)
        name_err = _validate_name(name)
        if name_err:
            error(f"  {_CROSS} Invalid workspace name: {name_err}")
            sys.exit(1)
        include_docker = not minimal
        include_makefile = not minimal
        include_readme = not minimal
        include_gitignore = True
        include_tests = True
        include_license = None

    # ── Generate ─────────────────────────────────────────────────────
    try:
        workspace_path = create_workspace(
            name=name,
            minimal=minimal,
            template=template,
            verbose=ctx.obj["verbose"],
            include_docker=include_docker,
            include_readme=include_readme,
            include_makefile=include_makefile,
            include_tests=include_tests,
            include_gitignore=include_gitignore,
            include_license=include_license,
        )

        if not ctx.obj["quiet"]:
            click.echo()
            banner("Aquilia", subtitle=f"Workspace created  {_CHECK}")
            click.echo()

            section("Project")
            kv("Name", name)
            kv("Location", str(workspace_path))
            if template:
                kv("Template", template)
            kv("Mode", "minimal" if minimal else "full")
            click.echo()

            section("Generated Files")
            tree_item("workspace.py", depth=0)
            tree_item("starter.py", depth=0)
            tree_item(".env.example", depth=0)
            tree_item(".editorconfig", depth=0)
            if include_gitignore:
                tree_item(".gitignore", depth=0)
            tree_item("requirements.txt", depth=0)
            if include_tests:
                tree_item("tests/", depth=0)
                tree_item("conftest.py", depth=1)
                tree_item("test_smoke.py", depth=1, last=True)
            if not minimal:
                if include_makefile:
                    tree_item("Makefile", depth=0)
                if include_docker:
                    tree_item("Dockerfile", depth=0)
                    tree_item("docker-compose.yml", depth=0)
            if include_license:
                tree_item("LICENSE", depth=0, last=True)
            click.echo()

            next_steps(
                [
                    f"cd {name}",
                    "cp .env.example .env",
                    "pip install -r requirements.txt",
                    "aq add module <module_name>",
                    "make run" if include_makefile else "aq run",
                ]
            )

    except Exception as e:
        error(f"  {_CROSS} Failed to create workspace: {e}")
        sys.exit(1)


def _validate_name(value: str) -> str | None:
    """Validate a workspace/module name.

    Names must:
    - Be at least 2 characters
    - Start with a **lowercase** letter (uppercase is rejected to keep
      filesystem paths, Python package names, and route prefixes consistent)
    - Contain only lowercase letters, digits, hyphens, and underscores
    - Be at most 64 characters
    """
    import re as _vre

    if not value or len(value.strip()) < 2:
        return "Name must be at least 2 characters"
    if value[0].isupper():
        return "Name must start with a lowercase letter (no capitals allowed)"
    if not _vre.match(r"^[a-z][a-z0-9_-]*$", value):
        return (
            "Name must start with a lowercase letter and contain only lowercase letters, digits, hyphens, underscores"
        )
    if len(value) > 64:
        return "Name must be 64 characters or fewer"
    return None


def _validate_strong_password(password: str) -> str | None:
    """Return an error message if *password* does not meet strength requirements.

    A strong password must:
    - Be at least 8 characters long
    - Contain at least one uppercase letter
    - Contain at least one lowercase letter
    - Contain at least one digit
    - Contain at least one special character (!@#$%^&*…)
    """
    import re as _pre

    if not password or len(password) < 8:
        return "Password must be at least 8 characters"
    if not _pre.search(r"[A-Z]", password):
        return "Password must contain at least one uppercase letter"
    if not _pre.search(r"[a-z]", password):
        return "Password must contain at least one lowercase letter"
    if not _pre.search(r"[0-9]", password):
        return "Password must contain at least one digit"
    if not _pre.search(r"[^A-Za-z0-9]", password):
        return "Password must contain at least one special character (e.g. !@#$%^&*)"
    return None


async def _check_admin_user_unique(
    db,
    username: str,
    email: str,
) -> tuple[str | None, str | None]:
    """Check whether *username* and *email* already exist in admin_users.

    Returns a tuple ``(username_error, email_error)`` where each element is
    either an error string or ``None`` if the value is available.
    """
    username_err: str | None = None
    email_err: str | None = None
    try:
        row = await db.fetch_one(
            "SELECT id FROM aq_admin_users WHERE username = :u",
            {"u": username},
        )
        if row:
            username_err = f"Username '{username}' is already taken"
    except Exception:
        pass  # Table may not exist yet -- skip the check
    try:
        row = await db.fetch_one(
            "SELECT id FROM aq_admin_users WHERE email = :e",
            {"e": email},
        )
        if row:
            email_err = f"Email '{email}' is already registered"
    except Exception:
        pass
    return username_err, email_err


@cli.group(cls=AquiliaGroup)
def add():
    """Add module to workspace."""
    pass


@add.command("module")
@click.argument("name", required=False, default=None)
@click.option("--depends-on", multiple=True, help="Module dependencies")
@click.option("--fault-domain", type=str, help="Custom fault domain")
@click.option("--route-prefix", type=str, help="Route prefix (default: /name)")
@click.option("--with-tests", is_flag=True, help="Generate test routes")
@click.option("--minimal", is_flag=True, help="Generate minimal module (controller + manifest only)")
@click.option("--no-docker", is_flag=True, help="Skip auto-generating Docker files")
@click.option("--yes", "-y", is_flag=True, help="Skip interactive prompts and use defaults")
@click.pass_context
def add_module(
    ctx,
    name: str | None,
    depends_on: tuple,
    fault_domain: str | None,
    route_prefix: str | None,
    with_tests: bool,
    minimal: bool,
    no_docker: bool,
    yes: bool,
):
    """
    Add a new module to the workspace.

    When run without arguments, starts an interactive setup wizard.
    Pass --yes to skip prompts and use defaults.

    By default also generates Dockerfile and docker-compose.yml if they
    don't exist yet.  Use --no-docker to skip.

    Examples:
      aq add module                        # Interactive mode
      aq add module users                  # Interactive with name pre-filled
      aq add module users -y               # Non-interactive with defaults
      aq add module products --depends-on=users
      aq add module admin --fault-domain=ADMIN --route-prefix=/api/admin
    """
    from .commands.add import add_module as _add_module

    interactive = not yes and sys.stdin.isatty()

    # ── Interactive flow ─────────────────────────────────────────────
    if interactive:
        flow_header(
            "add module",
            "Add a new module to this workspace.",
        )

        # 1. Module name
        if not name:
            name = ask("Module name", required=True, validator=_validate_name, hint="e.g. users, products, auth")
        else:
            click.echo(
                f"  {click.style('◆', fg='cyan')} {click.style('Module name', fg='white', bold=True)} {click.style('…', dim=True)} {click.style(name, fg='cyan')}"
            )

        # 2. Route prefix
        if not route_prefix:
            default_prefix = f"/{name}"
            route_prefix = ask("Route prefix", default=default_prefix)

        # 3. Module type
        if not minimal:
            module_type = select(
                "Module type",
                [
                    ("full", "Full module -- controllers, services, faults, models"),
                    ("minimal", "Minimal -- controller + manifest only"),
                ],
                default=0,
            )
            minimal = module_type == "minimal"

        # 4. Fault domain
        if not fault_domain and not minimal:
            fault_domain = ask("Fault domain", default=name.upper(), hint="Used for error classification")

        # 5. Features
        if not minimal:
            module_features = multi_select(
                "Include",
                [
                    ("tests", "Test routes file", False),
                    ("docker", "Auto-generate Docker files", True),
                ],
            )
            with_tests = "tests" in module_features
            no_docker = "docker" not in module_features

        # 6. Dependencies -- discover existing modules
        if not depends_on:
            workspace_root = Path.cwd()
            modules_dir = workspace_root / "modules"
            existing_mods = []
            if modules_dir.exists():
                existing_mods = [
                    d.name
                    for d in sorted(modules_dir.iterdir())
                    if d.is_dir() and (d / "manifest.py").exists() and d.name != name
                ]
            if existing_mods:
                dep_choices = [(m, "", False) for m in existing_mods]
                depends_on = tuple(multi_select("Dependencies", dep_choices))

        # 7. Confirmation
        recap(
            [
                ("Module", name),
                ("Route prefix", route_prefix or f"/{name}"),
                ("Type", "minimal" if minimal else "full"),
                ("Fault domain", fault_domain or name.upper()),
                ("Tests", "yes" if with_tests else "no"),
                ("Docker", "skip" if no_docker else "auto"),
                ("Dependencies", ", ".join(depends_on) if depends_on else "none"),
            ],
            title="Module Configuration",
        )

        if not confirm("Add module?", default=True):
            click.echo()
            info("  Cancelled.")
            return

    else:
        if not name:
            error(f"  {_CROSS} Module name is required in non-interactive mode")
            sys.exit(1)
        name_err = _validate_name(name)
        if name_err:
            error(f"  {_CROSS} Invalid module name: {name_err}")
            sys.exit(1)

    # ── Generate ─────────────────────────────────────────────────────
    try:
        _add_module(
            name=name,
            depends_on=list(depends_on),
            fault_domain=fault_domain,
            route_prefix=route_prefix,
            with_tests=with_tests,
            minimal=minimal,
            no_docker=no_docker,
            verbose=ctx.obj["verbose"],
        )

        if not ctx.obj["quiet"]:
            click.echo()
            success(f"  {_CHECK} Module '{name}' added successfully")
            click.echo()

            section("Module Details")
            kv("Name", name)
            kv("Location", f"modules/{name}/")
            kv("Route Prefix", route_prefix or f"/{name}")
            if depends_on:
                kv("Dependencies", ", ".join(depends_on))
            if fault_domain:
                kv("Fault Domain", fault_domain)
            kv("Type", "minimal" if minimal else "full")
            click.echo()

            section("Generated Files")
            tree_item("__init__.py", depth=0)
            tree_item("manifest.py", depth=0)
            tree_item("controllers.py", depth=0)
            if not minimal:
                tree_item("services.py", depth=0)
                tree_item("faults.py", depth=0)
                tree_item("models/", depth=0)
            if with_tests:
                tree_item("test_routes.py", depth=0, last=True)
            else:
                items = ["__init__.py", "manifest.py", "controllers.py"]
                if not minimal:
                    items.extend(["services.py", "faults.py", "models/"])
                # Mark last item
            click.echo()

            steps = [
                f"Edit modules/{name}/controllers.py",
            ]
            if not minimal:
                steps.append(f"Add services in modules/{name}/services.py")
            steps.extend(["aq run", "aq validate"])
            next_steps(steps)

    except Exception as e:
        error(f"  {_CROSS} Failed to add module: {e}")
        sys.exit(1)


@cli.group(cls=AquiliaGroup)
def generate():
    """Generate code from templates."""
    pass


@generate.command("controller")
@click.argument("name")
@click.option("--prefix", type=str, help="Route prefix (default: /name)")
@click.option("--resource", type=str, help="Resource name (default: name)")
@click.option("--simple", is_flag=True, help="Generate simple controller")
@click.option("--with-lifecycle", is_flag=True, help="Include lifecycle hooks")
@click.option("--test", is_flag=True, help="Generate test/demo controller")
@click.option("--output", type=click.Path(), help="Output directory")
@click.pass_context
def generate_controller(
    ctx,
    name: str,
    prefix: str | None,
    resource: str | None,
    simple: bool,
    with_lifecycle: bool,
    test: bool,
    output: str | None,
):
    """
    Generate a new controller.

    Examples:
      aq generate controller Users
      aq generate controller Products --prefix=/api/products
      aq generate controller Health --simple
      aq generate controller Admin --with-lifecycle
      aq generate controller Test --test
      aq generate controller Admin --output=apps/admin/
    """
    from .generators.controller import generate_controller as _generate_controller

    try:
        file_path = _generate_controller(
            name=name,
            output_dir=output or "controllers",
            prefix=prefix,
            resource=resource,
            simple=simple,
            with_lifecycle=with_lifecycle,
            test=test,
        )

        if not ctx.obj["quiet"]:
            click.echo()
            success(f"  {_CHECK} Generated controller '{name}'")
            click.echo()
            section("Controller")
            kv("Name", f"{name}Controller")
            kv("Location", str(file_path))
            if with_lifecycle:
                kv("Lifecycle", "on_startup, on_request, on_response")
            if test:
                kv("Type", "Test/Demo controller")
            click.echo()
            next_steps(
                [
                    f"Register in manifest: controllers = ['{file_path.parent.name}.{file_path.stem}:{name}Controller']",
                    "Implement your business logic",
                    "aq run",
                ]
            )

    except Exception as e:
        error(f"  {_CROSS} Failed to generate controller: {e}")
        sys.exit(1)


@cli.command("validate")
@click.option("--strict", is_flag=True, help="Strict validation (prod-level)")
@click.option("--module", type=str, help="Validate single module")
@click.option("--json", "as_json", is_flag=True, help="Output results as JSON")
@click.pass_context
def validate(ctx, strict: bool, module: str | None, as_json: bool):
    """
    Validate workspace manifests.

    Examples:
      aq validate
      aq validate --strict
      aq validate --module=users
      aq validate --json
    """
    from .commands.validate import validate_workspace

    try:
        result = validate_workspace(
            strict=strict,
            module_filter=module,
            verbose=ctx.obj["verbose"],
        )

        if as_json:
            import json as _json

            click.echo(
                _json.dumps(
                    {
                        "valid": result.is_valid,
                        "modules": result.module_count,
                        "routes": result.route_count,
                        "providers": result.provider_count,
                        "fingerprint": str(result.fingerprint)[:24] if result.fingerprint else None,
                        "faults": result.faults if hasattr(result, "faults") else [],
                        "warnings": result.warnings if hasattr(result, "warnings") else [],
                    },
                    indent=2,
                )
            )
            if not result.is_valid:
                sys.exit(1)
            return

        if not ctx.obj["quiet"]:
            click.echo()
            if result.is_valid:
                success(f"  {_CHECK} Validation passed")
                click.echo()
                section("Summary")
                kv("Modules", str(result.module_count))
                kv("Routes", str(result.route_count))
                kv("DI Providers", str(result.provider_count))
                if result.fingerprint:
                    kv("Fingerprint", str(result.fingerprint)[:24])
                # Show warnings even when valid
                if hasattr(result, "warnings") and result.warnings:
                    click.echo()
                    section("Warnings")
                    for w in result.warnings:
                        bullet(w, fg="yellow")
            else:
                error(f"  {_CROSS} Validation failed")
                click.echo()
                section("Errors")
                for fault in result.faults:
                    bullet(fault, fg="red")
                if hasattr(result, "warnings") and result.warnings:
                    click.echo()
                    section("Warnings")
                    for w in result.warnings:
                        bullet(w, fg="yellow")
                sys.exit(1)

    except Exception as e:
        error(f"  {_CROSS} Validation error: {e}")
        sys.exit(1)


@cli.command("compile")
@click.option("--watch", is_flag=True, help="Watch for changes")
@click.option("--output", type=click.Path(), help="Output directory")
@click.pass_context
def compile(ctx, watch: bool, output: str | None):
    """
    Compile manifests to artifacts.

    Examples:
      aq compile
      aq compile --watch
      aq compile --output=dist/
    """
    from .commands.compile import compile_workspace

    try:
        artifacts = compile_workspace(
            output_dir=output,
            watch=watch,
            verbose=ctx.obj["verbose"],
        )

        if not ctx.obj["quiet"]:
            click.echo()
            success(f"  {_CHECK} Compilation complete")
            click.echo()
            section("Artifacts")
            kv("Count", str(len(artifacts)))
            for artifact in artifacts:
                tree_item(str(artifact))

    except Exception as e:
        error(f"  {_CROSS} Compilation failed: {e}")
        sys.exit(1)


@cli.command("run")
@click.option("--mode", type=click.Choice(["dev", "test"]), default="dev", help="Runtime mode")
@click.option("--port", type=int, default=None, help="Server port (default: from workspace.py AquilaConfig, or 8000)")
@click.option(
    "--host", type=str, default=None, help="Server host (default: from workspace.py AquilaConfig, or 127.0.0.1)"
)
@click.option(
    "--reload/--no-reload", default=None, help="Enable hot-reload (default: from workspace.py AquilaConfig, or True)"
)
@click.option("--skip-checks", is_flag=True, help="Skip pre-flight dependency checks")
@click.pass_context
def run(ctx, mode: str, port, host, reload, skip_checks: bool):
    """
    Start development server.

    Runs admin pre-flight checks automatically when admin integration
    is detected in workspace.py. Use --skip-checks to bypass.

    Examples:
      aq run
      aq run --port=3000
      aq run --mode=test --no-reload
      aq run --skip-checks
    """
    from .commands.run import run_dev_server

    # ── Admin pre-flight checks ──────────────────────────────────────
    if not skip_checks:
        workspace_file = Path("workspace.py")
        if workspace_file.exists():
            ws_content = workspace_file.read_text(encoding="utf-8")
            active_lines = "\n".join(line for line in ws_content.splitlines() if not line.strip().startswith("#"))
            if "Integration.admin(" in active_lines:
                # Check session support
                has_sessions = (
                    ".sessions(" in active_lines
                    or "Integration.sessions(" in active_lines
                    or "Integration.auth(" in active_lines
                )
                if not has_sessions:
                    click.echo()
                    warning(
                        "  ! Admin integration detected but sessions are NOT configured.\n"
                        "    Admin login will NOT work without session support.\n"
                        "    Run 'aq admin setup' to auto-configure everything.\n"
                        "    Or:  'aq admin check' for full diagnostics.\n"
                        "    Use --skip-checks to suppress this warning."
                    )
                    click.echo()

    try:
        run_dev_server(
            mode=mode,
            host=host,
            port=port,
            reload=reload,
            verbose=ctx.obj["verbose"],
        )

    except KeyboardInterrupt:
        if not ctx.obj["quiet"]:
            click.echo()
            info(f"  {_CHECK} Server stopped gracefully")
    except Exception as e:
        error(f"  {_CROSS} Server error: {e}")
        sys.exit(1)


@cli.command("serve")
@click.option(
    "--workers", type=int, default=None, help="Number of workers (default: from workspace.py AquilaConfig, or 1)"
)
@click.option(
    "--bind", type=str, default=None, help="Bind address (default: from workspace.py AquilaConfig, or 0.0.0.0:8000)"
)
@click.option("--use-gunicorn", is_flag=True, help="Use gunicorn with UvicornWorker (recommended for production)")
@click.option("--timeout", type=int, default=120, help="Worker timeout in seconds (gunicorn only)")
@click.option("--graceful-timeout", type=int, default=30, help="Graceful shutdown timeout (gunicorn only)")
@click.pass_context
def serve(ctx, workers, bind, use_gunicorn: bool, timeout: int, graceful_timeout: int):
    """
    Start production server.

    Uses uvicorn by default. Pass --use-gunicorn for production
    deployments with gunicorn process management and UvicornWorker.

    Examples:
      aq serve
      aq serve --workers=4
      aq serve --use-gunicorn --workers=4
      aq serve --bind=0.0.0.0:8080 --use-gunicorn --timeout=180
    """
    from .commands.serve import serve_production

    try:
        serve_production(
            workers=workers,
            bind=bind,
            verbose=ctx.obj["verbose"],
            use_gunicorn=use_gunicorn,
            timeout=timeout,
            graceful_timeout=graceful_timeout,
        )

    except KeyboardInterrupt:
        if not ctx.obj["quiet"]:
            click.echo()
            info(f"  {_CHECK} Server stopped")
    except Exception as e:
        error(f"  {_CROSS} Server error: {e}")
        sys.exit(1)


@cli.command("freeze")
@click.option("--output", type=click.Path(), help="Output directory")
@click.option("--sign", is_flag=True, help="Sign artifacts")
@click.pass_context
def freeze(ctx, output: str | None, sign: bool):
    """
    Freeze generated artifacts for production integrity checks.

    Examples:
      aq freeze
      aq freeze --output=dist/
      aq freeze --sign
    """
    from .commands.freeze import freeze_artifacts

    try:
        fingerprint = freeze_artifacts(
            output_dir=output,
            sign=sign,
            verbose=ctx.obj["verbose"],
        )

        if not ctx.obj["quiet"]:
            click.echo()
            success(f"  {_CHECK} Artifacts frozen")
            kv("Fingerprint", fingerprint)

    except Exception as e:
        error(f"  {_CROSS} Freeze failed: {e}")
        sys.exit(1)


@cli.group(cls=AquiliaGroup)
def manifest():
    """Manage module manifests."""
    pass


@manifest.command("update")
@click.argument("module")
@click.option("--check", is_flag=True, help="Fail if manifest is out of sync (CI mode)")
@click.option("--freeze", is_flag=True, help="Disable auto-discovery after Sync (Strict mode)")
@click.pass_context
def manifest_update(ctx, module: str, check: bool, freeze: bool):
    """
    Update manifest with auto-discovered resources.

    Scans the module for controllers and services, then explicitly
    writes them into manifest.py.

    Examples:
      aq manifest update mymod
      aq manifest update mymod --check   # For CI
      aq manifest update mymod --freeze  # For Prod
    """
    from .commands.manifest import update_manifest

    try:
        # Resolve workspace root (assume cwd)
        workspace_root = Path.cwd()

        update_manifest(
            module_name=module,
            workspace_root=workspace_root,
            check=check,
            freeze=freeze,
            verbose=ctx.obj["verbose"],
        )

    except Exception as e:
        error(f"  {_CROSS} Manifest update failed: {e}")
        sys.exit(1)


# Import and register add command group


@cli.group(cls=AquiliaGroup)
def inspect():
    """Inspect compiled artifacts."""
    pass


@inspect.command("routes")
@click.pass_context
def inspect_routes(ctx):
    """Show compiled routes."""
    from .commands.inspect import inspect_routes as _inspect_routes

    try:
        _inspect_routes(verbose=ctx.obj["verbose"])
    except Exception as e:
        error(f"  {_CROSS} Inspection failed: {e}")
        sys.exit(1)


@inspect.command("di")
@click.pass_context
def inspect_di(ctx):
    """Show DI graph."""
    from .commands.inspect import inspect_di as _inspect_di

    try:
        _inspect_di(verbose=ctx.obj["verbose"])
    except Exception as e:
        error(f"  {_CROSS} Inspection failed: {e}")
        sys.exit(1)


@inspect.command("modules")
@click.pass_context
def inspect_modules(ctx):
    """List all modules."""
    from .commands.inspect import inspect_modules as _inspect_modules

    try:
        _inspect_modules(verbose=ctx.obj["verbose"])
    except Exception as e:
        error(f"  {_CROSS} Inspection failed: {e}")
        sys.exit(1)


@inspect.command("faults")
@click.pass_context
def inspect_faults(ctx):
    """Show fault domains."""
    from .commands.inspect import inspect_faults as _inspect_faults

    try:
        _inspect_faults(verbose=ctx.obj["verbose"])
    except Exception as e:
        error(f"  {_CROSS} Inspection failed: {e}")
        sys.exit(1)


@inspect.command("config")
@click.pass_context
def inspect_config(ctx):
    """Show resolved configuration."""
    from .commands.inspect import inspect_config as _inspect_config

    try:
        _inspect_config(verbose=ctx.obj["verbose"])
    except Exception as e:
        error(f"  {_CROSS} Inspection failed: {e}")
        sys.exit(1)


@cli.command("migrate")
@click.argument("source", type=click.Choice(["legacy"]))
@click.option("--dry-run", is_flag=True, help="Preview migration")
@click.pass_context
def migrate(ctx, source: str, dry_run: bool):
    """
    Migrate from legacy layout.

    Examples:
      aq migrate legacy --dry-run
      aq migrate legacy
    """
    from .commands.migrate import migrate_legacy

    try:
        result = migrate_legacy(
            dry_run=dry_run,
            verbose=ctx.obj["verbose"],
        )

        if not ctx.obj["quiet"]:
            click.echo()
            if dry_run:
                warning(f"  {_CHECK} Migration preview:")
            else:
                success(f"  {_CHECK} Migration complete:")

            for item in result.changes:
                bullet(str(item))

    except Exception as e:
        error(f"  {_CROSS} Migration failed: {e}")
        sys.exit(1)


@cli.command("doctor")
@click.option("--json", "as_json", is_flag=True, help="Output results as JSON")
@click.pass_context
def doctor(ctx, as_json: bool):
    """Diagnose workspace issues.

    Performs comprehensive health checks across all layers:
    environment, workspace structure, manifests, Aquilary pipeline,
    integrations, and deployment readiness.

    Examples:
      aq doctor
      aq doctor -v
      aq doctor --json
    """
    from .commands.doctor import diagnose_workspace

    try:
        issues = diagnose_workspace(verbose=ctx.obj["verbose"])

        if as_json:
            import json as _json

            click.echo(
                _json.dumps(
                    {
                        "healthy": len(issues) == 0,
                        "issue_count": len(issues),
                        "issues": issues,
                    },
                    indent=2,
                )
            )
            return

        click.echo()
        if not issues:
            banner("Aquilia Doctor", subtitle=f"Workspace is healthy  {_CHECK}")
        else:
            warning(f"  Found {len(issues)} issue(s):")
            click.echo()
            section("Issues")
            for issue in issues:
                bullet(issue, fg="yellow")
            click.echo()
            next_steps(
                [
                    "Fix the issues above",
                    "aq doctor -v  (verbose details)",
                    "aq validate --strict  (full pipeline check)",
                ]
            )

    except Exception as e:
        error(f"  {_CROSS} Diagnosis failed: {e}")
        if ctx.obj.get("debug"):
            import traceback

            traceback.print_exc()
        sys.exit(1)


# ============================================================================
# WebSocket management
# ============================================================================


@cli.group(cls=AquiliaGroup)
def ws():
    """WebSocket management commands."""
    pass


@ws.command("inspect")
@click.option("--artifacts-dir", type=click.Path(), default="artifacts", help="Artifacts directory")
@click.pass_context
def ws_inspect(ctx, artifacts_dir: str):
    """Inspect compiled WebSocket namespaces."""
    from .commands.ws import cmd_ws_inspect

    try:
        cmd_ws_inspect({"artifacts_dir": artifacts_dir})
    except Exception as e:
        error(f"  {_CROSS} WS inspect failed: {e}")
        sys.exit(1)


@ws.command("broadcast")
@click.option("--namespace", required=True, help="Namespace")
@click.option("--room", default=None, help="Room (optional)")
@click.option("--event", required=True, help="Event name")
@click.option("--payload", default="{}", help="JSON payload")
@click.pass_context
def ws_broadcast(ctx, namespace: str, room: str | None, event: str, payload: str):
    """Broadcast message to namespace or room."""
    from .commands.ws import cmd_ws_broadcast

    try:
        cmd_ws_broadcast({"namespace": namespace, "room": room, "event": event, "payload": payload})
    except Exception as e:
        error(f"  {_CROSS} WS broadcast failed: {e}")
        sys.exit(1)


@ws.command("gen-client")
@click.option("--lang", default="ts", help="Language (ts)")
@click.option("--out", required=True, help="Output file")
@click.option("--artifacts-dir", type=click.Path(), default="artifacts", help="Artifacts directory")
@click.pass_context
def ws_gen_client(ctx, lang: str, out: str, artifacts_dir: str):
    """Generate TypeScript client SDK from compiled WebSocket artifacts."""
    from .commands.ws import cmd_ws_gen_client

    try:
        cmd_ws_gen_client({"lang": lang, "out": out, "artifacts_dir": artifacts_dir})
    except Exception as e:
        error(f"  {_CROSS} WS gen-client failed: {e}")
        sys.exit(1)


@ws.command("purge-room")
@click.option("--namespace", required=True, help="Namespace")
@click.option("--room", required=True, help="Room to purge")
@click.option("--redis-url", default=None, help="Redis URL (optional)")
@click.pass_context
def ws_purge_room(ctx, namespace: str, room: str, redis_url: str | None):
    """Purge a room's state from the adapter.

    Examples:\n      aq ws purge-room --namespace /chat --room room1
    """
    from .commands.ws import cmd_ws_purge_room

    try:
        cmd_ws_purge_room({"namespace": namespace, "room": room, "redis_url": redis_url})
    except Exception as e:
        error(f"  {_CROSS} WS purge-room failed: {e}")
        sys.exit(1)


@ws.command("kick")
@click.option("--conn", required=True, help="Connection ID to disconnect")
@click.option("--reason", default="kicked by admin", help="Reason for kick")
@click.option("--redis-url", default=None, help="Redis URL (optional)")
@click.pass_context
def ws_kick(ctx, conn: str, reason: str, redis_url: str | None):
    """Kick (disconnect) a WebSocket connection.

    Examples:\n      aq ws kick --conn abc-123 --reason "violated rules"
    """
    from .commands.ws import cmd_ws_kick

    try:
        cmd_ws_kick({"conn": conn, "reason": reason, "redis_url": redis_url})
    except Exception as e:
        error(f"  {_CROSS} WS kick failed: {e}")
        sys.exit(1)


# ============================================================================
# Discovery
# ============================================================================


@cli.command("discover")
@click.option("--path", type=click.Path(), default=None, help="Workspace path")
@click.option("--sync", is_flag=True, help="Auto-sync discovered components into manifest.py files")
@click.option("--dry-run", is_flag=True, help="Preview sync changes without writing (use with --sync)")
@click.option("--json", "as_json", is_flag=True, help="Output results as JSON")
@click.pass_context
def discover(ctx, path: str | None, sync: bool, dry_run: bool, as_json: bool):
    """Inspect auto-discovered modules in workspace.

    Examples:
      aq discover
      aq discover --sync
      aq discover --sync --dry-run
      aq discover --json
    """
    from .commands.discover import DiscoveryInspector

    try:
        workspace_root = Path(path) if path else Path.cwd()
        inspector = DiscoveryInspector(workspace_root.name, str(workspace_root))
        inspector.inspect(
            verbose=ctx.obj["verbose"],
            sync=sync,
            dry_run=dry_run,
        )
    except Exception as e:
        error(f"  {_CROSS} Discovery failed: {e}")
        if ctx.obj.get("debug"):
            import traceback

            traceback.print_exc()
        sys.exit(1)


# ============================================================================
# Analytics
# ============================================================================


@cli.command("analytics")
@click.option("--path", type=click.Path(), default=None, help="Workspace path")
@click.pass_context
def analytics(ctx, path: str | None):
    """Run discovery analytics and show health report."""
    from .commands.analytics import DiscoveryAnalytics, print_analysis_report

    try:
        workspace_root = Path(path) if path else Path.cwd()
        analyser = DiscoveryAnalytics(workspace_root.name, str(workspace_root))
        analysis = analyser.analyze()
        print_analysis_report(analysis)
    except Exception as e:
        error(f"  {_CROSS} Analytics failed: {e}")
        sys.exit(1)


# ============================================================================
# Mail
# ============================================================================


@cli.group(cls=AquiliaGroup)
def mail():
    """AquilaMail -- test, inspect, and validate mail configuration."""
    pass


@mail.command("check")
@click.pass_context
def mail_check(ctx):
    """
    Validate mail configuration and report issues.

    Examples:
      aq mail check
    """
    from .commands.mail import cmd_mail_check

    try:
        cmd_mail_check(verbose=ctx.obj["verbose"])
    except Exception as e:
        error(f"  {_CROSS} mail check failed: {e}")
        sys.exit(1)


@mail.command("send-test")
@click.argument("to")
@click.option("--subject", type=str, default=None, help="Email subject")
@click.option("--body", type=str, default=None, help="Email body")
@click.pass_context
def mail_send_test(ctx, to: str, subject: str | None, body: str | None):
    """
    Send a test email to verify mail provider configuration.

    Examples:
      aq mail send-test user@example.com
      aq mail send-test user@example.com --subject="Hello"
    """
    from .commands.mail import cmd_mail_send_test

    try:
        cmd_mail_send_test(
            to=to,
            subject=subject,
            body=body,
            verbose=ctx.obj["verbose"],
        )
    except Exception as e:
        error(f"  {_CROSS} mail send-test failed: {e}")
        sys.exit(1)


@mail.command("inspect")
@click.pass_context
def mail_inspect(ctx):
    """
    Display current mail configuration as JSON.

    Examples:
      aq mail inspect
    """
    from .commands.mail import cmd_mail_inspect

    try:
        cmd_mail_inspect(verbose=ctx.obj["verbose"])
    except Exception as e:
        error(f"  {_CROSS} mail inspect failed: {e}")
        sys.exit(1)


# ============================================================================
# Cache
# ============================================================================


@cli.group(cls=AquiliaGroup)
def cache():
    """AquilaCache -- check, inspect, clear, and view cache stats."""
    pass


@cache.command("check")
@click.pass_context
def cache_check(ctx):
    """
    Validate cache configuration and test backend connectivity.

    Examples:
      aq cache check
    """
    from .commands.cache import cmd_cache_check

    try:
        cmd_cache_check(verbose=ctx.obj["verbose"])
    except Exception as e:
        error(f"  {_CROSS} cache check failed: {e}")
        sys.exit(1)


@cache.command("inspect")
@click.pass_context
def cache_inspect(ctx):
    """
    Display current cache configuration as JSON.

    Examples:
      aq cache inspect
    """
    from .commands.cache import cmd_cache_inspect

    try:
        cmd_cache_inspect(verbose=ctx.obj["verbose"])
    except Exception as e:
        error(f"  {_CROSS} cache inspect failed: {e}")
        sys.exit(1)


@cache.command("stats")
@click.pass_context
def cache_stats(ctx):
    """
    Display cache statistics from trace diagnostics.

    Examples:
      aq cache stats
    """
    from .commands.cache import cmd_cache_stats

    try:
        cmd_cache_stats(verbose=ctx.obj["verbose"])
    except Exception as e:
        error(f"  {_CROSS} cache stats failed: {e}")
        sys.exit(1)


@cache.command("clear")
@click.option("--namespace", "-n", type=str, default=None, help="Clear only this namespace")
@click.pass_context
def cache_clear(ctx, namespace: str | None):
    """
    Clear all or namespace-scoped cache entries.

    Examples:
      aq cache clear
      aq cache clear --namespace http
    """
    from .commands.cache import cmd_cache_clear

    try:
        cmd_cache_clear(namespace=namespace, verbose=ctx.obj["verbose"])
    except Exception as e:
        error(f"  {_CROSS} cache clear failed: {e}")
        sys.exit(1)


# ============================================================================
# I18n (Internationalization)
# ============================================================================


@cli.group(cls=AquiliaGroup)
def i18n():
    """AquilaI18n -- init, check, inspect, extract, coverage, and compile."""
    pass


@i18n.command("init")
@click.option("--locales", "-l", type=str, default="en", help="Comma-separated locale list (e.g. en,fr,de)")
@click.option("--directory", "-d", type=str, default="locales", help="Base directory for locale files")
@click.option("--format", "-f", type=click.Choice(["json", "yaml"]), default="json", help="Translation file format")
@click.pass_context
def i18n_init(ctx, locales: str, directory: str, format: str):
    """
    Initialize i18n in the current workspace.

    Creates locales/ directory with starter translation files.

    Examples:
      aq i18n init
      aq i18n init --locales en,fr,de,ja
      aq i18n init --directory translations --format yaml
    """
    from .commands.i18n import cmd_i18n_init

    try:
        cmd_i18n_init(
            locales=locales,
            directory=directory,
            format=format,
            verbose=ctx.obj["verbose"],
        )
    except Exception as e:
        error(f"  {_CROSS} i18n init failed: {e}")
        sys.exit(1)


@i18n.command("check")
@click.pass_context
def i18n_check(ctx):
    """
    Validate i18n configuration and catalog structure.

    Examples:
      aq i18n check
    """
    from .commands.i18n import cmd_i18n_check

    try:
        cmd_i18n_check(verbose=ctx.obj["verbose"])
    except Exception as e:
        error(f"  {_CROSS} i18n check failed: {e}")
        sys.exit(1)


@i18n.command("inspect")
@click.pass_context
def i18n_inspect(ctx):
    """
    Display current i18n configuration as JSON.

    Examples:
      aq i18n inspect
    """
    from .commands.i18n import cmd_i18n_inspect

    try:
        cmd_i18n_inspect()
    except Exception as e:
        error(f"  {_CROSS} i18n inspect failed: {e}")
        sys.exit(1)


@i18n.command("extract")
@click.option("--source-dirs", "-s", type=str, default="modules,controllers", help="Comma-separated source directories")
@click.option("--output", "-o", type=str, default="locales/en/messages.json", help="Output file path")
@click.option("--no-merge", is_flag=True, default=False, help="Overwrite output instead of merging")
@click.pass_context
def i18n_extract(ctx, source_dirs: str, output: str, no_merge: bool):
    """
    Extract translation keys from source files.

    Scans Python and Jinja2 template files for _(), _n(), i18n.t(), etc.

    Examples:
      aq i18n extract
      aq i18n extract --source-dirs modules,templates --output locales/en/messages.json
    """
    from .commands.i18n import cmd_i18n_extract

    try:
        cmd_i18n_extract(
            source_dirs=source_dirs,
            output=output,
            merge=not no_merge,
            verbose=ctx.obj["verbose"],
        )
    except Exception as e:
        error(f"  {_CROSS} i18n extract failed: {e}")
        sys.exit(1)


@i18n.command("coverage")
@click.pass_context
def i18n_coverage(ctx):
    """
    Show translation coverage per locale.

    Reports percentage of default locale keys translated in each locale.

    Examples:
      aq i18n coverage
    """
    from .commands.i18n import cmd_i18n_coverage

    try:
        cmd_i18n_coverage(verbose=ctx.obj["verbose"])
    except Exception as e:
        error(f"  {_CROSS} i18n coverage failed: {e}")
        sys.exit(1)


@i18n.command("compile")
@click.option("--directory", "directory", type=str, default="locales", help="Source locales directory")
@click.option("--output", "output", type=str, default=None, help="Output directory for compiled catalogs")
@click.pass_context
def i18n_compile(ctx, directory: str, output: str | None):
    """
    Compile JSON locale files to CROUS format.

    Produces `.crous` catalogs for faster startup and lookup.

    Examples:
      aq i18n compile
      aq i18n compile --directory locales
      aq i18n compile --directory locales --output artifacts/locales
    """
    from .commands.i18n import cmd_i18n_compile

    try:
        cmd_i18n_compile(
            directory=directory,
            output=output,
            verbose=ctx.obj["verbose"],
        )
    except Exception as e:
        error(f"  {_CROSS} i18n compile failed: {e}")
        sys.exit(1)


# ============================================================================
# Database / Models
# ============================================================================


@cli.group(cls=AquiliaGroup)
def db():
    """Database and model ORM commands."""
    pass


@db.command("makemigrations")
@click.option("--app", type=str, default=None, help="Restrict to specific module/app")
@click.option("--migrations-dir", type=click.Path(), default="migrations", help="Migrations directory")
@click.option("--dsl/--no-dsl", default=True, help="Use new DSL format (default: True)")
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["python", "crous"]),
    default="crous",
    help="Migration file format -- crous (binary, default) or python",
)
@click.pass_context
def db_makemigrations(ctx, app: str | None, migrations_dir: str, dsl: bool, fmt: str):
    """
    Generate migration files from Python Model definitions.

    Uses CROUS binary format by default for compact, efficient migration
    storage.  Pass ``--format=python`` for human-readable DSL files.

    Examples:
      aq db makemigrations
      aq db makemigrations --app=products
      aq db makemigrations --format=python
      aq db makemigrations --no-dsl    # Legacy raw-SQL format
    """
    from .commands.model_cmds import cmd_makemigrations

    try:
        cmd_makemigrations(
            app=app,
            migrations_dir=migrations_dir,
            verbose=ctx.obj["verbose"],
            use_dsl=dsl,
            migration_format=fmt,
        )
    except Exception as e:
        error(f"  {_CROSS} makemigrations failed: {e}")
        sys.exit(1)


@db.command("migrate")
@click.option("--migrations-dir", type=click.Path(), default="migrations", help="Migrations directory")
@click.option("--database-url", type=str, default=None, help="Database URL (auto-detected from workspace.py)")
@click.option("--database", type=str, default=None, help="Database alias (for multi-db)")
@click.option("--target", type=str, default=None, help='Target revision (or "zero" to rollback all)')
@click.option("--fake", is_flag=True, help="Mark migrations as applied without running SQL")
@click.option("--plan", is_flag=True, help="Preview SQL without executing (dry-run)")
@click.pass_context
def db_migrate(
    ctx, migrations_dir: str, database_url: str | None, database: str | None, target: str | None, fake: bool, plan: bool
):
    """
    Apply pending migrations to the database.

    The database URL is auto-detected from workspace.py if not specified.

    Examples:
      aq db migrate
      aq db migrate --database-url=sqlite:///prod.db
      aq db migrate --fake                # Mark as applied without running
      aq db migrate --plan                # Preview SQL only
      aq db migrate --target=zero
    """
    from .commands.model_cmds import cmd_migrate

    # Auto-detect database URL from workspace.py if not provided
    if database_url is None:
        database_url = _detect_workspace_db_url()

    try:
        cmd_migrate(
            migrations_dir=migrations_dir,
            database_url=database_url,
            target=target,
            verbose=ctx.obj["verbose"],
            fake=fake,
            plan=plan,
            database=database,
        )
    except Exception as e:
        error(f"  {_CROSS} migrate failed: {e}")
        sys.exit(1)


@db.command("dump")
@click.option("--emit", type=click.Choice(["python", "sql"]), default="python", help="Output format")
@click.option("--output-dir", type=click.Path(), default=None, help="Output directory")
@click.pass_context
def db_dump(ctx, emit: str, output_dir: str | None):
    """
    Dump model schema -- annotated Python overview or raw SQL DDL.

    Examples:
      aq db dump
      aq db dump --emit=sql
      aq db dump --output-dir=generated/
    """
    from .commands.model_cmds import cmd_model_dump

    try:
        cmd_model_dump(
            emit=emit,
            output_dir=output_dir,
            verbose=ctx.obj["verbose"],
        )
    except Exception as e:
        error(f"  {_CROSS} dump failed: {e}")
        sys.exit(1)


@db.command("shell")
@click.option("--database-url", type=str, default=None, help="Database URL (auto-detected from workspace.py)")
@click.pass_context
def db_shell(ctx, database_url: str | None):
    """
    Open an async REPL with models pre-loaded.

    All discovered Model classes, Q query builder, and ModelRegistry
    are available in the shell namespace.

    Examples:
      aq db shell
      aq db shell --database-url=sqlite:///prod.db
    """
    from .commands.model_cmds import cmd_shell

    if database_url is None:
        database_url = _detect_workspace_db_url()

    try:
        cmd_shell(
            database_url=database_url,
            verbose=ctx.obj["verbose"],
        )
    except Exception as e:
        error(f"  {_CROSS} shell failed: {e}")
        sys.exit(1)


@db.command("inspectdb")
@click.option("--database-url", type=str, default=None, help="Database URL (auto-detected from workspace.py)")
@click.option("--table", type=str, multiple=True, help="Specific tables to inspect")
@click.option("--output", type=click.Path(), default=None, help="Output file path")
@click.pass_context
def db_inspectdb(ctx, database_url: str | None, table: tuple, output: str | None):
    """
    Introspect database and generate Model definitions.

    Reads the database schema and emits Python Model class
    definitions that mirror the existing tables.

    Examples:
      aq db inspectdb
      aq db inspectdb --table=users --table=orders
      aq db inspectdb --output=models/generated.py
    """
    from .commands.model_cmds import cmd_inspectdb

    if database_url is None:
        database_url = _detect_workspace_db_url()

    try:
        tables = list(table) if table else None
        result = cmd_inspectdb(
            database_url=database_url,
            tables=tables,
            verbose=ctx.obj["verbose"],
        )
        if output and result:
            Path(output).parent.mkdir(parents=True, exist_ok=True)
            Path(output).write_text(result, encoding="utf-8")
            click.echo(click.style(f"  {_CHECK} Models written to {output}", fg="green"))
    except Exception as e:
        error(f"  {_CROSS} inspectdb failed: {e}")
        sys.exit(1)


@db.command("showmigrations")
@click.option("--migrations-dir", type=click.Path(), default="migrations", help="Migrations directory")
@click.option("--database-url", type=str, default=None, help="Database URL (auto-detected from workspace.py)")
@click.option("--database", type=str, default=None, help="Database alias")
@click.pass_context
def db_showmigrations(ctx, migrations_dir: str, database_url: str | None, database: str | None):
    """
    Show all migrations and their applied/pending status.

    Examples:
      aq db showmigrations
      aq db showmigrations --migrations-dir=db/migrations
    """
    from .commands.model_cmds import cmd_showmigrations

    if database_url is None:
        database_url = _detect_workspace_db_url()

    try:
        cmd_showmigrations(
            migrations_dir=migrations_dir,
            database_url=database_url,
            verbose=ctx.obj["verbose"],
        )
    except Exception as e:
        error(f"  {_CROSS} showmigrations failed: {e}")
        sys.exit(1)


@db.command("sqlmigrate")
@click.argument("migration_name")
@click.option("--migrations-dir", type=click.Path(), default="migrations", help="Migrations directory")
@click.option("--database", type=str, default=None, help="Database alias")
@click.pass_context
def db_sqlmigrate(ctx, migration_name: str, migrations_dir: str, database: str | None):
    """
    Display SQL statements for a specific migration.

    Supports both DSL and legacy migrations. For DSL migrations,
    compiles operations to SQL for the target backend.

    Examples:
      aq db sqlmigrate 20260217_210454
      aq db sqlmigrate 0002 --migrations-dir=db/migrations
    """
    from .commands.model_cmds import cmd_sqlmigrate

    try:
        cmd_sqlmigrate(
            migration_name=migration_name,
            migrations_dir=migrations_dir,
            verbose=ctx.obj["verbose"],
        )
    except Exception as e:
        error(f"  {_CROSS} sqlmigrate failed: {e}")
        sys.exit(1)


@db.command("status")
@click.option("--database-url", type=str, default=None, help="Database URL (auto-detected from workspace.py)")
@click.pass_context
def db_status(ctx, database_url: str | None):
    """
    Show database status -- tables, row counts, columns.

    Examples:
      aq db status
      aq db status --database-url=sqlite:///prod.db
    """
    from .commands.model_cmds import cmd_db_status

    if database_url is None:
        database_url = _detect_workspace_db_url()

    try:
        cmd_db_status(
            database_url=database_url,
            verbose=ctx.obj["verbose"],
        )
    except Exception as e:
        error(f"  {_CROSS} status failed: {e}")
        sys.exit(1)


# ============================================================================
# MLOps commands
# ============================================================================

from .commands.mlops_cmds import (
    deploy_group,
    experiment_group,
    export_group,
    lineage_group,
    model_group,
    observe_group,
    pack_group,
    plugin_group,
)

cli.add_command(pack_group)
cli.add_command(model_group)
cli.add_command(deploy_group)
cli.add_command(observe_group)
cli.add_command(export_group)
cli.add_command(plugin_group)
cli.add_command(lineage_group)
cli.add_command(experiment_group)


# ============================================================================
# Artifact commands
# ============================================================================

from .commands.artifacts import artifact_group

cli.add_command(artifact_group)


# ============================================================================
# Deploy / Production file generators
# ============================================================================

from .commands.deploy_gen import deploy_gen_group

cli.add_command(deploy_gen_group)


# ============================================================================
# Cloud provider management (aq provider login/logout/status)
# ============================================================================

import contextlib

from .commands.provider import provider_group

cli.add_command(provider_group)


# ============================================================================
# Test command
# ============================================================================


@cli.command("test")
@click.argument("paths", nargs=-1, type=click.Path())
@click.option("-k", "--pattern", type=str, default=None, help="Only run tests matching pattern")
@click.option("-m", "--markers", type=str, default=None, help="Only run tests matching markers")
@click.option("--coverage", is_flag=True, help="Collect coverage")
@click.option("--coverage-html", is_flag=True, help="Generate HTML coverage report")
@click.option("--failfast", "-x", is_flag=True, help="Stop on first failure")
@click.pass_context
def test(
    ctx, paths: tuple, pattern: str | None, markers: str | None, coverage: bool, coverage_html: bool, failfast: bool
):
    """
    Run the test suite with Aquilia-aware defaults.

    Sets AQUILIA_ENV=test, auto-discovers test directories,
    and configures pytest-asyncio.

    Examples:
      aq test
      aq test tests/test_users.py
      aq test -k "test_login"
      aq test --coverage
      aq test --failfast -v
    """
    from .commands.test import run_tests

    exit_code = run_tests(
        paths=list(paths) if paths else None,
        pattern=pattern,
        verbose=ctx.obj.get("verbose", False),
        coverage=coverage,
        coverage_html=coverage_html,
        failfast=failfast,
        markers=markers,
    )
    sys.exit(exit_code)


# ============================================================================
# Admin commands
# ============================================================================


@cli.group(cls=AquiliaGroup)
def admin():
    """Admin dashboard management and diagnostics."""
    pass


@admin.command("check")
@click.option("--fix", is_flag=True, help="Auto-fix missing configuration by uncommenting workspace.py sections")
@click.option("--json", "as_json", is_flag=True, help="Output results as JSON")
@click.pass_context
def admin_check(ctx, fix: bool, as_json: bool):
    """
    Pre-flight check for admin dashboard dependencies.

    Validates that all required integrations (sessions, database,
    static files, templates) are properly configured in workspace.py
    before starting the server.

    Run this BEFORE 'aq run' to catch configuration issues early.

    Examples:
      aq admin check
      aq admin check --fix
      aq admin check --json
    """
    workspace_file = Path("workspace.py")
    if not workspace_file.exists():
        error(f"  {_CROSS} workspace.py not found")
        sys.exit(1)

    content = workspace_file.read_text(encoding="utf-8")

    # Remove comment-only lines for active config detection
    active_lines = "\n".join(line for line in content.splitlines() if not line.strip().startswith("#"))

    checks: list[dict] = []

    # 1. Admin integration enabled?
    admin_enabled = "Integration.admin(" in active_lines
    checks.append(
        {
            "name": "Admin Integration",
            "status": "ok" if admin_enabled else "fail",
            "detail": "Integration.admin() is configured"
            if admin_enabled
            else (
                "Integration.admin() not found in workspace.py. "
                "Add: .integrate(Integration.admin(url_prefix='/admin', auto_discover=True))"
            ),
        }
    )

    if not admin_enabled:
        # No point checking dependencies if admin isn't even enabled
        if as_json:
            import json as _json

            click.echo(_json.dumps({"passed": False, "checks": checks}, indent=2))
        else:
            click.echo()
            banner("AquilAdmin", subtitle="Pre-flight Check")
            click.echo()
            error(f"  {_CROSS} Admin integration is not enabled in workspace.py")
            click.echo()
            next_steps(
                [
                    "Add .integrate(Integration.admin(...)) to workspace.py",
                    "aq admin check",
                ]
            )
        sys.exit(1)

    # 2. Sessions enabled?
    sessions_active = ".sessions(" in active_lines or "Integration.sessions(" in active_lines
    auth_active = "Integration.auth(" in active_lines
    has_session_support = sessions_active or auth_active
    checks.append(
        {
            "name": "Sessions",
            "status": "ok" if has_session_support else "fail",
            "detail": (
                ("Sessions via .sessions()" if sessions_active else "Sessions via Integration.auth()")
                if has_session_support
                else (
                    "Sessions are NOT configured. Admin login requires sessions. "
                    "Uncomment .sessions(...) in workspace.py or enable Integration.auth()"
                )
            ),
        }
    )

    # 3. Database configured?
    db_active = "Integration.database(" in active_lines
    db_has_url = bool(_re.search(r'url\s*=\s*["\']', active_lines))
    if db_active and db_has_url:
        db_status = "ok"
        db_detail = "Database integration with URL configured"
    elif db_active:
        db_status = "warn"
        db_detail = "Database integration enabled but no URL specified (using default sqlite)"
    else:
        db_status = "warn"
        db_detail = "No database integration found. Admin users are stored in admin_users table"
    checks.append({"name": "Database", "status": db_status, "detail": db_detail})

    # 4. Static files configured?
    static_active = "Integration.static_files(" in active_lines
    checks.append(
        {
            "name": "Static Files",
            "status": "ok" if static_active else "warn",
            "detail": (
                "Static files middleware configured"
                if static_active
                else "Static files not configured. Admin CSS/JS may not load. "
                'Add: .integrate(Integration.static_files(directories={"/static": "static"}))'
            ),
        }
    )

    # 5. Templates configured?
    templates_active = "Integration.templates" in active_lines or "TemplateEngine" in active_lines
    checks.append(
        {
            "name": "Templates",
            "status": "ok" if templates_active else "warn",
            "detail": (
                "Template engine configured"
                if templates_active
                else "Template engine not explicitly configured in workspace.py. "
                "Admin uses its built-in TemplateEngine but user templates "
                "won't resolve. Add: .integrate(Integration.templates(directories=['templates']))"
            ),
        }
    )
    # Infrastructure: Docker and kubectl availability
    import shutil

    docker_path = shutil.which("docker")
    kubectl_path = shutil.which("kubectl")
    checks.append(
        {
            "name": "Docker CLI",
            "status": "ok" if docker_path else "warn",
            "detail": (
                f"docker found at {docker_path}"
                if docker_path
                else "Docker CLI not found. Containers page will be disabled. Install Docker to enable full functionality."
            ),
        }
    )
    checks.append(
        {
            "name": "kubectl CLI",
            "status": "ok" if kubectl_path else "warn",
            "detail": (
                f"kubectl found at {kubectl_path}"
                if kubectl_path
                else "kubectl CLI not found. Pods page will be disabled. Install kubectl to enable full functionality."
            ),
        }
    )

    # 6. Superuser exists?
    has_superuser = False
    su_detail = "Unknown (cannot check without database connection)"
    try:
        import asyncio as _aio

        database_url = _detect_workspace_db_url()

        async def _check_su():
            from aquilia.db.engine import configure_database

            db = configure_database(database_url)
            await db.connect()
            try:
                result = await db.fetch_one("SELECT COUNT(*) as cnt FROM aq_admin_users WHERE role = 'superadmin'")
                return result["cnt"] if result else 0
            finally:
                await db.disconnect()

        count = _aio.run(_check_su())
        has_superuser = count > 0
        su_detail = (
            f"{count} superuser(s) found" if has_superuser else ("No superusers found. Run: aq admin createsuperuser")
        )
    except Exception:
        su_detail = (
            "Could not check (database not accessible or table missing). Run: aq db migrate && aq admin createsuperuser"
        )
    checks.append(
        {
            "name": "Superuser",
            "status": "ok" if has_superuser else "warn",
            "detail": su_detail,
        }
    )

    # 7. assets/ directory exists?
    assets_dir = Path("assets")
    has_assets = assets_dir.is_dir()
    checks.append(
        {
            "name": "Admin Assets",
            "status": "ok" if has_assets else "info",
            "detail": (
                f"assets/ directory found ({len(list(assets_dir.iterdir()))} files)"
                if has_assets
                else "assets/ directory not found (admin will use default styles)"
            ),
        }
    )

    # ── Output ───────────────────────────────────────────────────────
    all_passed = all(c["status"] in ("ok", "info") for c in checks)
    has_failures = any(c["status"] == "fail" for c in checks)

    if as_json:
        import json as _json

        click.echo(
            _json.dumps(
                {
                    "passed": all_passed,
                    "has_failures": has_failures,
                    "checks": checks,
                },
                indent=2,
            )
        )
    else:
        click.echo()
        banner("AquilAdmin", subtitle="Pre-flight Check")
        click.echo()

        _status_icons = {"ok": _CHECK, "fail": _CROSS, "warn": "!", "info": _BULLET}
        _status_colors = {"ok": "green", "fail": "red", "warn": "yellow", "info": "cyan"}

        for c in checks:
            icon = _status_icons.get(c["status"], "?")
            color = _status_colors.get(c["status"], "white")
            name_styled = click.style(f"{c['name']}:", bold=True)
            icon_styled = click.style(f"  {icon}", fg=color)
            click.echo(f"{icon_styled} {name_styled}")
            if ctx.obj.get("verbose") or c["status"] in ("fail", "warn"):
                dim(f"      {c['detail']}")

        click.echo()
        if has_failures:
            error(f"  {_CROSS} Pre-flight check FAILED -- fix the errors above before running aq run")
            click.echo()
            if not has_session_support:
                panel(
                    [
                        "The admin dashboard requires session support.",
                        "",
                        "  Quick fix:   aq admin setup",
                        "  Manual fix:  Uncomment .sessions(...) in workspace.py",
                        "",
                        "  Or add this to your workspace.py:",
                        "",
                        "    from datetime import timedelta",
                        "    from aquilia.sessions import SessionPolicy, TransportPolicy",
                        "",
                        "    .sessions(",
                        "        policies=[",
                        '            SessionPolicy(name="default",',
                        "                ttl=timedelta(days=7),",
                        "                idle_timeout=timedelta(hours=1),",
                        "                transport=TransportPolicy(",
                        '                    cookie_name="aquilia_admin_session",',
                        "                    cookie_secure=False,",
                        "                    cookie_httponly=True,",
                        '                    cookie_samesite="lax",',
                        "                ),",
                        "            ),",
                        "        ],",
                        "    )",
                    ],
                    title="Required: Enable Sessions",
                    fg="yellow",
                )
            sys.exit(1)
        elif any(c["status"] == "warn" for c in checks):
            warning("  ! Pre-flight check passed with warnings")
        else:
            success(f"  {_CHECK} All pre-flight checks passed")
        click.echo()

    # ── Auto-fix ─────────────────────────────────────────────────────
    if fix and not has_session_support:
        # Uncomment the .sessions(...) block
        if "# .sessions(" in content:
            fixed = content.replace("# .sessions(", ".sessions(")
            # Uncomment lines within the sessions block
            lines = fixed.splitlines()
            in_sessions_block = False
            fixed_lines = []
            for line in lines:
                stripped = line.lstrip()
                if ".sessions(" in line and not stripped.startswith("#"):
                    in_sessions_block = True
                    fixed_lines.append(line)
                    continue
                if in_sessions_block:
                    if stripped.startswith("# ") and (
                        "policies=" in stripped
                        or "SessionPolicy" in stripped
                        or "ttl=" in stripped
                        or "idle_timeout=" in stripped
                        or "]," in stripped
                        or ")," in stripped
                        or ")" in stripped
                    ):
                        # Uncomment
                        fixed_lines.append(line.replace("# ", "", 1))
                    else:
                        fixed_lines.append(line)
                    if stripped.rstrip().endswith(")") and "SessionPolicy" not in stripped:
                        in_sessions_block = False
                else:
                    fixed_lines.append(line)

            workspace_file.write_text("\n".join(fixed_lines), encoding="utf-8")
            success(f"  {_CHECK} Auto-fixed: Uncommented .sessions(...) in workspace.py")
            click.echo()
            next_steps(
                [
                    "Review workspace.py to verify the sessions config",
                    "aq admin check",
                    "aq run",
                ]
            )


@admin.command("createsuperuser")
@click.option("--username", prompt=click.style("  Username", fg="cyan", bold=True), help="Admin username")
@click.option("--email", prompt=click.style("  Email", fg="cyan", bold=True), help="Admin email (required)")
@click.option(
    "--password",
    prompt=click.style("  Password", fg="cyan", bold=True),
    hide_input=True,
    confirmation_prompt=click.style("  Confirm password", fg="cyan", bold=True),
    help="Admin password",
)
@click.option("--first-name", default=None, help="First name (optional)")
@click.option("--last-name", default=None, help="Last name (optional)")
@click.option("--no-input", is_flag=True, hidden=True, help="Non-interactive mode (requires all options)")
@click.pass_context
def admin_createsuperuser(
    ctx, username: str, email: str, password: str, first_name: str | None, last_name: str | None, no_input: bool
):
    """
    Create an admin superuser in the database.

    Stores credentials securely using Argon2id/PBKDF2 password hashing
    in the admin_users table.

    Requires ``aq db migrate`` to have been run first to create the
    admin_users table.

    Examples:
      aq admin createsuperuser
      aq admin createsuperuser --username=admin --email=admin@site.com --password=secret
      aq admin createsuperuser --first-name=John --last-name=Doe
    """
    import asyncio
    import time as _ctime

    click.echo()
    banner("Aquilia", subtitle="Admin Superuser Setup")
    click.echo()

    # ── Re-prompt until valid (handles ctx.invoke() with empty defaults) ──
    while not username or len(username.strip()) < 2:
        username = click.prompt(
            click.style("  Username", fg="cyan", bold=True),
            default="",
            show_default=False,
            prompt_suffix=" ",
        ).strip()
        if not username or len(username.strip()) < 2:
            error(f"  {_CROSS} Username must be at least 2 characters")

    username = username.strip()

    while not email or "@" not in email or "." not in email.split("@")[-1]:
        email = click.prompt(
            click.style("  Email", fg="cyan", bold=True),
            default="",
            show_default=False,
            prompt_suffix=" ",
        ).strip()
        if not email or "@" not in email or "." not in email.split("@")[-1]:
            error(f"  {_CROSS} A valid email address is required")

    while True:
        pw_err = _validate_strong_password(password) if password else "Password is required"
        if not pw_err:
            break
        password = click.prompt(
            click.style("  Password", fg="cyan", bold=True),
            default="",
            show_default=False,
            hide_input=True,
            confirmation_prompt=click.style("  Confirm password", fg="cyan", bold=True),
            prompt_suffix=" ",
        )
        pw_err = _validate_strong_password(password)
        if pw_err:
            error(f"  {_CROSS} {pw_err}")

    # ── Optional profile fields (interactive) ────────────────────────
    interactive = sys.stdin.isatty() and not no_input
    extra_fields = {}

    if interactive:
        section("Profile (optional -- press Enter to skip)")
        if first_name is None:
            first_name = (
                click.prompt(click.style("  First name", fg="cyan"), default="", show_default=False).strip() or None
            )
        if last_name is None:
            last_name = (
                click.prompt(click.style("  Last name", fg="cyan"), default="", show_default=False).strip() or None
            )
        phone = click.prompt(click.style("  Phone", fg="cyan"), default="", show_default=False).strip() or None
        bio = click.prompt(click.style("  Bio", fg="cyan"), default="", show_default=False).strip() or None
        timezone = (
            click.prompt(click.style("  Timezone", fg="cyan"), default="UTC", show_default=False).strip() or "UTC"
        )
        locale = click.prompt(click.style("  Locale", fg="cyan"), default="en", show_default=False).strip() or "en"
        click.echo()

        if phone:
            extra_fields["phone"] = phone
        if bio:
            extra_fields["bio"] = bio
        if timezone and timezone != "UTC":
            extra_fields["timezone"] = timezone
        if locale and locale != "en":
            extra_fields["locale"] = locale
    else:
        phone = bio = timezone = locale = None

    if first_name:
        extra_fields["first_name"] = first_name
    if last_name:
        extra_fields["last_name"] = last_name

    section("Credentials")
    kv("Username", username)
    kv("Email", email)
    kv("Password", click.style("*" * len(password), dim=True))
    if first_name:
        kv("First Name", first_name)
    if last_name:
        kv("Last Name", last_name)
    if phone:
        kv("Phone", phone)
    click.echo()

    # ── Create superuser ─────────────────────────────────────────────
    step(1, "Connecting to database...")

    async def _create():
        # Connect to the database and register with ORM
        database_url = _detect_workspace_db_url()
        try:
            from aquilia.db.engine import configure_database

            db = configure_database(database_url)
            await db.connect()
        except Exception:
            db = None

        try:
            from aquilia.admin.models import (
                AdminAPIKey,
                AdminAuditEntry,
                AdminPreference,
                AdminUser,
            )

            if db is None:
                from aquilia.faults.domains import DatabaseConnectionFault

                raise DatabaseConnectionFault(
                    backend="unknown",
                    reason=("No database connection available. Run 'aq db migrate' first to set up the database."),
                )

            # Auto-ensure admin tables exist (safety net).
            # The admin models live in the framework, not the workspace,
            # so users may not have run makemigrations for them yet.
            _admin_models = [
                AdminUser,
                AdminAuditEntry,
                AdminAPIKey,
                AdminPreference,
            ]
            _dialect = getattr(db, "dialect", "sqlite")
            for _model in _admin_models:
                try:
                    create_sql = _model.generate_create_table_sql(dialect=_dialect)
                    await db.execute(create_sql)
                    # Create indexes
                    for idx_sql in _model.generate_index_sql(dialect=_dialect):
                        await db.execute(idx_sql)
                    # Create M2M tables
                    for m2m_sql in _model.generate_m2m_sql(dialect=_dialect):
                        await db.execute(m2m_sql)
                except Exception:
                    pass  # Table already exists -- that's fine

            # ── DB uniqueness check ───────────────────────────────────────
            uname_err, email_err = await _check_admin_user_unique(db, username, email)
            if uname_err or email_err:
                msgs = [m for m in (uname_err, email_err) if m]
                from aquilia.faults.domains import ConfigInvalidFault

                raise ConfigInvalidFault(
                    key="admin.user",
                    reason="\n".join(msgs),
                )

            # ORM-based creation
            try:
                user = await AdminUser.create_superuser(
                    username=username,
                    password=password,
                    email=email,
                    **extra_fields,
                )
                return True, str(getattr(user, "pk", "?"))
            except Exception as e:
                err_msg = str(e).lower()
                if "unique constraint" in err_msg and "username" in err_msg:
                    from aquilia.faults.domains import ConfigInvalidFault

                    raise ConfigInvalidFault(
                        key="admin.username",
                        reason=(
                            f"Username '{username}' already exists. "
                            "Choose a different username or update the existing user."
                        ),
                    ) from e
                if "unique constraint" in err_msg and "email" in err_msg:
                    from aquilia.faults.domains import ConfigInvalidFault

                    raise ConfigInvalidFault(
                        key="admin.email",
                        reason=(
                            f"Email '{email}' is already registered to another admin account. "
                            "Use a different email address."
                        ),
                    ) from e
                if "unique constraint" in err_msg:
                    from aquilia.faults.domains import ConfigInvalidFault

                    raise ConfigInvalidFault(
                        key="admin.user",
                        reason=("A user with that username or email already exists. Choose different credentials."),
                    ) from e
                from aquilia.faults.domains import DatabaseFault

                raise DatabaseFault(
                    operation="create_superuser",
                    reason=(
                        f"Failed to create superuser: {e}\n"
                        "Ensure 'aq db makemigrations' and 'aq db migrate' have been run first."
                    ),
                ) from e
        finally:
            if db is not None:
                with contextlib.suppress(Exception):
                    await db.disconnect()

    t0 = _ctime.monotonic()
    try:
        ok, pk_info = asyncio.run(_create())
    except Exception as e:
        click.echo()
        err_str = str(e)
        error(f"  {_CROSS} {err_str}")
        click.echo()
        _is_dup = any(w in err_str.lower() for w in ("already exists", "already taken", "already registered"))
        if not _is_dup:
            panel(
                [
                    "Troubleshooting:",
                    "",
                    "1. Ensure the database is running",
                    "2. Run: aq db makemigrations",
                    "3. Run: aq db migrate",
                    "4. Then retry: aq admin createsuperuser",
                ],
                title="Help",
                fg="red",
            )
        else:
            panel(
                [
                    "The username or email you specified is already in use.",
                    "",
                    "• Use a different --username or --email",
                    "• Or run: aq admin listusers  to see existing accounts",
                ],
                title="Duplicate User",
                fg="yellow",
            )
        sys.exit(1)

    elapsed = (_ctime.monotonic() - t0) * 1000

    if not ctx.obj.get("quiet"):
        step(2, "Hashing password with Argon2id/PBKDF2...")
        step(3, "Writing to admin_users table...")
        click.echo()

        # ── Success banner ───────────────────────────────────────────
        success(f"  {_CHECK} Superuser created successfully!")
        click.echo()

        # ── Details panel ────────────────────────────────────────────
        section("Account Details")
        kv("Username", username)
        kv("Email", email)
        if first_name:
            kv("First Name", first_name)
        if last_name:
            kv("Last Name", last_name)
        kv("Role", click.style("superadmin", fg="magenta", bold=True))
        kv("Storage", "Database (admin_users table)")
        kv("Password", "Hashed (Argon2id/PBKDF2)")
        kv("Created in", f"{elapsed:.0f}ms")
        click.echo()

        # ── Permissions ──────────────────────────────────────────────
        section("Permissions")
        bullet("Full admin dashboard access", fg="green")
        bullet("Create, read, update, delete all models", fg="green")
        bullet("Manage users, groups, and permissions", fg="green")
        bullet("View audit logs", fg="green")
        click.echo()

        # ── Next steps ───────────────────────────────────────────────
        next_steps(
            [
                "aq admin check",
                "aq run",
                "Visit http://localhost:8000/admin/",
                f"Log in with username '{username}' and your password",
            ]
        )


@admin.command("createstaff")
@click.option("--username", prompt=click.style("  Username", fg="cyan", bold=True), help="Staff username")
@click.option("--email", prompt=click.style("  Email", fg="cyan", bold=True), help="Staff email (required)")
@click.option(
    "--password",
    prompt=click.style("  Password", fg="cyan", bold=True),
    hide_input=True,
    confirmation_prompt=click.style("  Confirm password", fg="cyan", bold=True),
    help="Staff password",
)
@click.option("--first-name", default=None, help="First name (optional)")
@click.option("--last-name", default=None, help="Last name (optional)")
@click.option("--no-input", is_flag=True, hidden=True, help="Non-interactive mode (requires all options)")
@click.pass_context
def admin_createstaff(
    ctx, username: str, email: str, password: str, first_name: str | None, last_name: str | None, no_input: bool
):
    """
    Create an admin staff user in the database.

    Staff users have limited dashboard access compared to superusers.
    They cannot manage other admin users or modify permissions unless
    explicitly granted.

    Requires ``aq db migrate`` to have been run first.

    Examples:
      aq admin createstaff
      aq admin createstaff --username=editor --email=editor@site.com --password=secret
      aq admin createstaff --first-name=Jane --last-name=Smith
    """
    import asyncio
    import time as _ctime

    click.echo()
    banner("Aquilia", subtitle="Admin Staff User Setup")
    click.echo()

    # ── Re-prompt until valid (handles ctx.invoke() with empty defaults) ──
    while not username or len(username.strip()) < 2:
        username = click.prompt(
            click.style("  Username", fg="cyan", bold=True),
            default="",
            show_default=False,
            prompt_suffix=" ",
        ).strip()
        if not username or len(username.strip()) < 2:
            error(f"  {_CROSS} Username must be at least 2 characters")

    username = username.strip()

    while not email or "@" not in email or "." not in email.split("@")[-1]:
        email = click.prompt(
            click.style("  Email", fg="cyan", bold=True),
            default="",
            show_default=False,
            prompt_suffix=" ",
        ).strip()
        if not email or "@" not in email or "." not in email.split("@")[-1]:
            error(f"  {_CROSS} A valid email address is required")

    while True:
        pw_err = _validate_strong_password(password) if password else "Password is required"
        if not pw_err:
            break
        password = click.prompt(
            click.style("  Password", fg="cyan", bold=True),
            default="",
            show_default=False,
            hide_input=True,
            confirmation_prompt=click.style("  Confirm password", fg="cyan", bold=True),
            prompt_suffix=" ",
        )
        pw_err = _validate_strong_password(password)
        if pw_err:
            error(f"  {_CROSS} {pw_err}")

    # ── Optional profile fields (interactive) ────────────────────────
    interactive = sys.stdin.isatty() and not no_input
    extra_fields = {}

    if interactive:
        section("Profile (optional -- press Enter to skip)")
        if first_name is None:
            first_name = (
                click.prompt(click.style("  First name", fg="cyan"), default="", show_default=False).strip() or None
            )
        if last_name is None:
            last_name = (
                click.prompt(click.style("  Last name", fg="cyan"), default="", show_default=False).strip() or None
            )
        phone = click.prompt(click.style("  Phone", fg="cyan"), default="", show_default=False).strip() or None
        bio = click.prompt(click.style("  Bio", fg="cyan"), default="", show_default=False).strip() or None
        timezone = (
            click.prompt(click.style("  Timezone", fg="cyan"), default="UTC", show_default=False).strip() or "UTC"
        )
        locale = click.prompt(click.style("  Locale", fg="cyan"), default="en", show_default=False).strip() or "en"
        click.echo()

        if phone:
            extra_fields["phone"] = phone
        if bio:
            extra_fields["bio"] = bio
        if timezone and timezone != "UTC":
            extra_fields["timezone"] = timezone
        if locale and locale != "en":
            extra_fields["locale"] = locale
    else:
        phone = bio = timezone = locale = None

    if first_name:
        extra_fields["first_name"] = first_name
    if last_name:
        extra_fields["last_name"] = last_name

    section("Credentials")
    kv("Username", username)
    kv("Email", email)
    kv("Password", click.style("*" * len(password), dim=True))
    if first_name:
        kv("First Name", first_name)
    if last_name:
        kv("Last Name", last_name)
    if phone:
        kv("Phone", phone)
    click.echo()

    # ── Create staff user ────────────────────────────────────────────
    step(1, "Connecting to database...")

    async def _create():
        database_url = _detect_workspace_db_url()
        try:
            from aquilia.db.engine import configure_database

            db = configure_database(database_url)
            await db.connect()
        except Exception:
            db = None

        try:
            from aquilia.admin.models import (
                AdminAPIKey,
                AdminAuditEntry,
                AdminPreference,
                AdminUser,
            )

            if db is None:
                from aquilia.faults.domains import DatabaseConnectionFault

                raise DatabaseConnectionFault(
                    backend="unknown",
                    reason=("No database connection available. Run 'aq db migrate' first to set up the database."),
                )

            _admin_models = [
                AdminUser,
                AdminAuditEntry,
                AdminAPIKey,
                AdminPreference,
            ]
            _dialect = getattr(db, "dialect", "sqlite")
            for _model in _admin_models:
                try:
                    create_sql = _model.generate_create_table_sql(dialect=_dialect)
                    await db.execute(create_sql)
                    for idx_sql in _model.generate_index_sql(dialect=_dialect):
                        await db.execute(idx_sql)
                    for m2m_sql in _model.generate_m2m_sql(dialect=_dialect):
                        await db.execute(m2m_sql)
                except Exception:
                    pass

            # ── DB uniqueness check ───────────────────────────────────────
            uname_err, email_err = await _check_admin_user_unique(db, username, email)
            if uname_err or email_err:
                msgs = [m for m in (uname_err, email_err) if m]
                from aquilia.faults.domains import ConfigInvalidFault

                raise ConfigInvalidFault(
                    key="admin.user",
                    reason="\n".join(msgs),
                )

            try:
                user = await AdminUser.create_staff_user(
                    username=username,
                    password=password,
                    email=email,
                    **extra_fields,
                )
                return True, str(getattr(user, "pk", "?"))
            except Exception as e:
                err_msg = str(e).lower()
                if "unique constraint" in err_msg and "username" in err_msg:
                    from aquilia.faults.domains import ConfigInvalidFault

                    raise ConfigInvalidFault(
                        key="admin.username",
                        reason=(
                            f"Username '{username}' already exists. "
                            "Choose a different username or update the existing user."
                        ),
                    ) from e
                if "unique constraint" in err_msg and "email" in err_msg:
                    from aquilia.faults.domains import ConfigInvalidFault

                    raise ConfigInvalidFault(
                        key="admin.email",
                        reason=(
                            f"Email '{email}' is already registered to another admin account. "
                            "Use a different email address."
                        ),
                    ) from e
                if "unique constraint" in err_msg:
                    from aquilia.faults.domains import ConfigInvalidFault

                    raise ConfigInvalidFault(
                        key="admin.user",
                        reason=("A user with that username or email already exists. Choose different credentials."),
                    ) from e
                from aquilia.faults.domains import DatabaseFault

                raise DatabaseFault(
                    operation="create_staff_user",
                    reason=(
                        f"Failed to create staff user: {e}\n"
                        "Ensure 'aq db makemigrations' and 'aq db migrate' have been run first."
                    ),
                ) from e
        finally:
            if db is not None:
                with contextlib.suppress(Exception):
                    await db.disconnect()

    t0 = _ctime.monotonic()
    try:
        ok, pk_info = asyncio.run(_create())
    except Exception as e:
        click.echo()
        err_str = str(e)
        error(f"  {_CROSS} {err_str}")
        click.echo()
        _is_dup = any(w in err_str.lower() for w in ("already exists", "already taken", "already registered"))
        if not _is_dup:
            panel(
                [
                    "Troubleshooting:",
                    "",
                    "1. Ensure the database is running",
                    "2. Run: aq db makemigrations",
                    "3. Run: aq db migrate",
                    "4. Then retry: aq admin createstaff",
                ],
                title="Help",
                fg="red",
            )
        else:
            panel(
                [
                    "The username or email you specified is already in use.",
                    "",
                    "• Use a different --username or --email",
                    "• Or run: aq admin listusers  to see existing accounts",
                ],
                title="Duplicate User",
                fg="yellow",
            )
        sys.exit(1)

    elapsed = (_ctime.monotonic() - t0) * 1000

    if not ctx.obj.get("quiet"):
        step(2, "Hashing password with Argon2id/PBKDF2...")
        step(3, "Writing to admin_users table...")
        click.echo()

        success(f"  {_CHECK} Staff user created successfully!")
        click.echo()

        section("Account Details")
        kv("Username", username)
        kv("Email", email)
        if first_name:
            kv("First Name", first_name)
        if last_name:
            kv("Last Name", last_name)
        kv("Role", click.style("staff", fg="yellow", bold=True))
        kv("Storage", "Database (admin_users table)")
        kv("Password", "Hashed (Argon2id/PBKDF2)")
        kv("Created in", f"{elapsed:.0f}ms")
        click.echo()

        section("Permissions")
        bullet("Admin dashboard access (limited)", fg="yellow")
        bullet("View and edit assigned models", fg="yellow")
        bullet("Cannot manage admin users", fg="yellow")
        bullet("Cannot modify system permissions", fg="yellow")
        click.echo()

        next_steps(
            [
                "aq admin check",
                "aq run",
                "Visit http://localhost:8000/admin/",
                f"Log in with username '{username}' and your password",
                "Grant additional permissions via superuser account",
            ]
        )


@admin.command("listusers")
@click.option("--database-url", type=str, default=None, help="Database URL")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
@click.option("--active-only", is_flag=True, help="Show only active users")
@click.pass_context
def admin_listusers(ctx, database_url: str | None, as_json: bool, active_only: bool):
    """
    List all admin users.

    Examples:
      aq admin listusers
      aq admin listusers --json
      aq admin listusers --active-only
    """
    import asyncio

    if database_url is None:
        database_url = _detect_workspace_db_url()

    async def _list():
        from aquilia.db.engine import configure_database

        db = configure_database(database_url)
        await db.connect()
        try:
            query = "SELECT id, username, email, is_active, role, created_at, last_login_at FROM aq_admin_users"
            if active_only:
                query += " WHERE is_active = 1"
            query += " ORDER BY created_at DESC"
            rows = await db.fetch_all(query)
            return [dict(r) for r in rows]
        finally:
            await db.disconnect()

    try:
        users = asyncio.run(_list())
    except Exception as e:
        error(f"  {_CROSS} Failed to list users: {e}")
        if ctx.obj.get("verbose"):
            import traceback

            traceback.print_exc()
        sys.exit(1)

    if as_json:
        import json as _json

        # Convert datetime objects to strings
        for u in users:
            for k, v in u.items():
                if hasattr(v, "isoformat"):
                    u[k] = v.isoformat()
        click.echo(_json.dumps(users, indent=2))
        return

    if not ctx.obj.get("quiet"):
        click.echo()
        section(f"Admin Users ({len(users)})")
        click.echo()

        if not users:
            info("  No admin users found. Run: aq admin createsuperuser")
        else:
            headers = ["ID", "Username", "Email", "Active", "Role", "Joined"]
            rows_data = []
            for u in users:
                joined = u.get("created_at", "")
                if hasattr(joined, "strftime"):
                    joined = joined.strftime("%Y-%m-%d")
                role = u.get("role", "staff")
                role_display = {
                    "superadmin": click.style("superadmin", fg="magenta", bold=True),
                    "staff": click.style("staff", fg="yellow"),
                    "viewer": click.style("viewer", fg="cyan"),
                }.get(role, role)
                rows_data.append(
                    [
                        str(u.get("id", "?"))[:8],
                        u.get("username", ""),
                        u.get("email", ""),
                        _CHECK if u.get("is_active") else _CROSS,
                        role_display,
                        str(joined)[:10],
                    ]
                )
            table(headers, rows_data)
        click.echo()


@admin.command("changepassword")
@click.argument("username")
@click.option(
    "--password",
    prompt=click.style("  New password", fg="cyan", bold=True),
    hide_input=True,
    confirmation_prompt=click.style("  Confirm password", fg="cyan", bold=True),
    help="New password",
)
@click.option("--database-url", type=str, default=None, help="Database URL")
@click.pass_context
def admin_changepassword(ctx, username: str, password: str, database_url: str | None):
    """
    Change an admin user's password.

    Examples:
      aq admin changepassword admin
      aq admin changepassword admin --password=newsecret
    """
    import asyncio

    if database_url is None:
        database_url = _detect_workspace_db_url()

    pw_err = _validate_strong_password(password)
    if pw_err:
        error(f"  {_CROSS} {pw_err}")
        info("  Requirements: ≥8 chars, uppercase, lowercase, digit, special character")
        sys.exit(1)

    async def _change():
        from aquilia.auth.hashing import PasswordHasher
        from aquilia.db.engine import configure_database

        db = configure_database(database_url)
        await db.connect()
        try:
            hasher = PasswordHasher()
            hashed = hasher.hash(password)
            await db.execute(
                "UPDATE aq_admin_users SET password_hash = :hash WHERE username = :username",
                {"hash": hashed, "username": username},
            )
            # Check if user was found
            row = await db.fetch_one(
                "SELECT id FROM aq_admin_users WHERE username = :username",
                {"username": username},
            )
            return row is not None
        finally:
            await db.disconnect()

    try:
        found = asyncio.run(_change())
    except Exception as e:
        error(f"  {_CROSS} Failed to change password: {e}")
        sys.exit(1)

    if found:
        click.echo()
        success(f"  {_CHECK} Password changed for user '{username}'")
        click.echo()
    else:
        error(f"  {_CROSS} User '{username}' not found")
        sys.exit(1)


@admin.command("setup")
@click.option("--non-interactive", "-y", is_flag=True, help="Skip confirmation prompts")
@click.option("--database-url", type=str, default=None, help="Database URL to use (default: sqlite:///db.sqlite3)")
@click.pass_context
def admin_setup(ctx, non_interactive: bool, database_url: str | None):
    """
    Auto-configure all admin dependencies in workspace.py.

    This is the one-stop command to get the admin dashboard running.
    It performs every step needed:

    \b
      1. Ensures .sessions(...) is enabled in workspace.py
      2. Ensures Integration.admin(...) is present
      3. Ensures Integration.database(...) is present (uncomments or injects)
      4. Ensures Integration.static_files(...) is present
      5. Adds the required imports (SessionPolicy, timedelta)
      6. Runs database migrations for admin tables
      7. Prompts to create a superuser if none exists

    Examples:
      aq admin setup
      aq admin setup -y
      aq admin setup --database-url=postgresql://...
    """
    import asyncio
    import textwrap

    click.echo()
    banner("AquilAdmin", subtitle="Auto-Setup")
    click.echo()

    workspace_file = Path("workspace.py")
    if not workspace_file.exists():
        error(f"  {_CROSS} workspace.py not found -- run 'aq init workspace <name>' first")
        sys.exit(1)

    content = workspace_file.read_text(encoding="utf-8")
    original_content = content

    # Remove comment-only lines for active config detection
    def _active(text: str) -> str:
        return "\n".join(line for line in text.splitlines() if not line.strip().startswith("#"))

    active = _active(content)
    changes_made: list[str] = []

    # ── Step 1: Ensure required imports ──────────────────────────────
    step(1, "Checking imports...")
    # Check only actual import lines (not comments) to avoid false positives
    # when class names appear inside commented-out config blocks.
    import_lines = "\n".join(
        line
        for line in content.splitlines()
        if (line.strip().startswith("from ") or line.strip().startswith("import ")) and not line.strip().startswith("#")
    )
    needed_imports: list[str] = []
    if "timedelta" not in import_lines:
        needed_imports.append("from datetime import timedelta")
    if "SessionPolicy" not in import_lines:
        needed_imports.append("from aquilia.sessions import SessionPolicy")
    if "TransportPolicy" not in import_lines:
        needed_imports.append("from aquilia.sessions import TransportPolicy")
    if "PersistencePolicy" not in import_lines:
        needed_imports.append("from aquilia.sessions import PersistencePolicy")
    if "ConcurrencyPolicy" not in import_lines:
        needed_imports.append("from aquilia.sessions import ConcurrencyPolicy")

    if needed_imports:
        # Insert after the last import line
        lines = content.splitlines()
        last_import_idx = 0
        for i, line in enumerate(lines):
            stripped = line.strip()
            if stripped.startswith("from ") or stripped.startswith("import "):
                if not stripped.startswith("#"):
                    last_import_idx = i

        for imp in needed_imports:
            lines.insert(last_import_idx + 1, imp)
            last_import_idx += 1
            changes_made.append(f"Added import: {imp}")

        content = "\n".join(lines)
        active = _active(content)
        success(f"    {_CHECK} Added {len(needed_imports)} import(s)")
    else:
        dim(f"    {_CHECK} Imports already present")

    # ── Step 2: Ensure sessions are enabled ──────────────────────────
    step(2, "Checking sessions config...")
    has_sessions = ".sessions(" in active or "Integration.sessions(" in active or "Integration.auth(" in active
    if not has_sessions:
        # Check if there's a commented-out .sessions block we can uncomment
        if "# .sessions(" in content:
            # Uncomment the entire .sessions(...) block
            lines = content.splitlines()
            in_sessions_block = False
            brace_depth = 0
            for i, line in enumerate(lines):
                stripped = line.lstrip()
                if not in_sessions_block and stripped.startswith("# .sessions("):
                    lines[i] = line.replace("# .sessions(", ".sessions(", 1)
                    in_sessions_block = True
                    brace_depth = line.count("(") - line.count(")")
                    continue
                if in_sessions_block:
                    if stripped.startswith("# "):
                        lines[i] = line.replace("# ", "", 1)
                    brace_depth += line.count("(") - line.count(")")
                    if brace_depth <= 0:
                        in_sessions_block = False

            content = "\n".join(lines)
            active = _active(content)
            changes_made.append("Uncommented .sessions(...) block")
            success(f"    {_CHECK} Uncommented .sessions(...) block")
        else:
            # Inject a sessions block before the admin integration or at the end
            sessions_block = textwrap.dedent("""\

    # Sessions -- required for admin login
    .sessions(
        policies=[
            SessionPolicy(
                name="default",
                ttl=timedelta(days=7),
                idle_timeout=timedelta(hours=1),
                absolute_timeout=timedelta(days=30),
                rotate_on_use=False,
                rotate_on_privilege_change=True,
                fingerprint_binding=False,
                scope="user",
                persistence=PersistencePolicy(
                    enabled=True,
                    store_name="default",
                    write_through=True,
                    compress=False,
                ),
                concurrency=ConcurrencyPolicy(
                    max_sessions_per_principal=5,
                    behavior_on_limit="evict_oldest",
                ),
                transport=TransportPolicy(
                    cookie_name="aquilia_admin_session",
                    cookie_secure=False,
                    cookie_httponly=True,
                    cookie_samesite="lax",
                ),
            ),
        ],
    )""")
            # Find the admin integration line or the closing ')'
            lines = content.splitlines()
            insert_idx = None
            for i, line in enumerate(lines):
                if "Integration.admin(" in line and not line.lstrip().startswith("#"):
                    insert_idx = i
                    break
            if insert_idx is None:
                # Insert before the last ')'
                for i in range(len(lines) - 1, -1, -1):
                    if lines[i].strip() == ")":
                        insert_idx = i
                        break
            if insert_idx is not None:
                for j, sline in enumerate(sessions_block.splitlines()):
                    lines.insert(insert_idx + j, sline)
                content = "\n".join(lines)
                active = _active(content)
                changes_made.append("Injected .sessions(...) block")
                success(f"    {_CHECK} Injected .sessions(...) config")
            else:
                warning("    ! Could not find insertion point -- add .sessions() manually")
    else:
        dim(f"    {_CHECK} Sessions already configured")

    # ── Step 3: Ensure Integration.admin(...) ────────────────────────
    step(3, "Checking admin integration...")
    if "Integration.admin(" not in active:
        if "# .integrate(Integration.admin(" in content or "#.integrate(Integration.admin(" in content:
            # Uncomment it
            content = _re.sub(
                r"#\s*\.integrate\(Integration\.admin\(",
                ".integrate(Integration.admin(",
                content,
                count=1,
            )
            # Also uncomment any following commented lines until closing ))
            lines = content.splitlines()
            in_admin_block = False
            for i, line in enumerate(lines):
                if ".integrate(Integration.admin(" in line and not line.lstrip().startswith("#"):
                    in_admin_block = True
                    continue
                if in_admin_block:
                    stripped = line.lstrip()
                    if stripped.startswith("# "):
                        lines[i] = line.replace("# ", "", 1)
                    if "))" in line:
                        in_admin_block = False
            content = "\n".join(lines)
            active = _active(content)
            changes_made.append("Uncommented Integration.admin(...)")
            success(f"    {_CHECK} Uncommented admin integration")
        else:
            # Inject admin integration before the closing ')'
            admin_block = textwrap.dedent("""\

    # Admin Dashboard
    .integrate(Integration.admin(
        url_prefix="/admin",
        site_title="Admin",
        auto_discover=True,
    ))""")
            lines = content.splitlines()
            for i in range(len(lines) - 1, -1, -1):
                if lines[i].strip() == ")":
                    for j, sline in enumerate(admin_block.splitlines()):
                        lines.insert(i + j, sline)
                    break
            content = "\n".join(lines)
            active = _active(content)
            changes_made.append("Injected Integration.admin(...)")
            success(f"    {_CHECK} Injected admin integration")
    else:
        dim(f"    {_CHECK} Admin integration already configured")

    # ── Step 4: Ensure Integration.database(...) ─────────────────────
    step(4, "Checking database integration...")
    if "Integration.database(" not in active:
        # Try to uncomment a commented-out database integration line first
        if "# .integrate(Integration.database(" in content or "#.integrate(Integration.database(" in content:
            content = _re.sub(
                r"#\s*\.integrate\(Integration\.database\(",
                ".integrate(Integration.database(",
                content,
                count=1,
            )
            # Uncomment any immediately following commented lines until closing ))
            lines = content.splitlines()
            in_db_block = False
            for i, line in enumerate(lines):
                if ".integrate(Integration.database(" in line and not line.lstrip().startswith("#"):
                    in_db_block = True
                    if "))" in line:
                        in_db_block = False
                    continue
                if in_db_block:
                    stripped = line.lstrip()
                    if stripped.startswith("# "):
                        lines[i] = line.replace("# ", "", 1)
                    if "))" in line:
                        in_db_block = False
            content = "\n".join(lines)
            active = _active(content)
            changes_made.append("Uncommented Integration.database(...)")
            success(f"    {_CHECK} Uncommented database integration")
        else:
            # Inject database integration before sessions or admin block, or before closing ')'
            db_url_val = database_url or "sqlite:///db.sqlite3"
            db_block = textwrap.dedent(f"""\

    # Database
    .integrate(Integration.database(url="{db_url_val}"))""")
            lines = content.splitlines()
            insert_idx = None
            # Prefer inserting before the sessions block
            for i, line in enumerate(lines):
                if ".sessions(" in line and not line.lstrip().startswith("#"):
                    insert_idx = i
                    break
            # Fall back to before the admin integration
            if insert_idx is None:
                for i, line in enumerate(lines):
                    if "Integration.admin(" in line and not line.lstrip().startswith("#"):
                        insert_idx = i
                        break
            # Last resort: before the closing ')'
            if insert_idx is None:
                for i in range(len(lines) - 1, -1, -1):
                    if lines[i].strip() == ")":
                        insert_idx = i
                        break
            if insert_idx is not None:
                for j, sline in enumerate(db_block.splitlines()):
                    lines.insert(insert_idx + j, sline)
                content = "\n".join(lines)
                active = _active(content)
                changes_made.append("Injected Integration.database(...)")
                success(f"    {_CHECK} Injected database integration (url={db_url_val})")
            else:
                warning("    ! Could not find insertion point -- add Integration.database() manually")
    else:
        dim(f"    {_CHECK} Database integration present")

    # ── Step 5: Ensure Integration.static_files(...) ─────────────────
    step(5, "Checking static files integration...")
    if "Integration.static_files(" not in active:
        warning("    ! No static files integration -- admin CSS/JS may not load")
        info('      Add: .integrate(Integration.static_files(directories={"/static": "static"}))')
    else:
        dim(f"    {_CHECK} Static files integration present")

    # ── Write workspace.py if changed ────────────────────────────────
    if content != original_content:
        click.echo()
        section("Changes to workspace.py")
        for change in changes_made:
            bullet(change, fg="green")
        click.echo()

        if not non_interactive:
            if not click.confirm(click.style("  Apply these changes to workspace.py?", bold=True), default=True):
                info(f"  {_CROSS} Aborted -- no changes written")
                sys.exit(0)

        workspace_file.write_text(content, encoding="utf-8")
        success(f"  {_CHECK} workspace.py updated")
    else:
        click.echo()
        dim(f"  {_CHECK} workspace.py already fully configured")

    # ── Step 6: Ensure admin tables exist ────────────────────────────
    click.echo()
    step(6, "Ensuring admin database tables...")

    db_url = database_url or _detect_workspace_db_url()

    async def _ensure_tables():
        try:
            from aquilia.db.engine import configure_database

            db = configure_database(db_url)
            await db.connect()
        except Exception as e:
            return False, f"Database connection failed: {e}"

        try:
            from aquilia.admin.models import (
                AdminGroup,
                AdminLogEntry,
                AdminPermission,
                AdminSession,
                AdminUser,
                ContentType,
            )

            _admin_models = [
                ContentType,
                AdminPermission,
                AdminGroup,
                AdminUser,
                AdminLogEntry,
                AdminSession,
            ]
            _dialect = getattr(db, "dialect", "sqlite")
            created = 0
            for _model in _admin_models:
                try:
                    create_sql = _model.generate_create_table_sql(dialect=_dialect)
                    await db.execute(create_sql)
                    for idx_sql in _model.generate_index_sql(dialect=_dialect):
                        await db.execute(idx_sql)
                    for m2m_sql in _model.generate_m2m_sql(dialect=_dialect):
                        await db.execute(m2m_sql)
                    created += 1
                except Exception:
                    pass  # Table already exists
            return True, f"{created} table(s) checked/created"
        finally:
            with contextlib.suppress(Exception):
                await db.disconnect()

    try:
        ok, detail = asyncio.run(_ensure_tables())
        if ok:
            success(f"    {_CHECK} {detail}")
        else:
            warning(f"    ! {detail}")
    except Exception as e:
        warning(f"    ! Could not ensure tables: {e}")
        info("      Run 'aq db migrate' manually")

    # ── Step 7: Check for superuser ──────────────────────────────────
    step(7, "Checking for superuser...")

    async def _check_su():
        try:
            from aquilia.db.engine import configure_database

            db = configure_database(db_url)
            await db.connect()
            try:
                result = await db.fetch_one("SELECT COUNT(*) as cnt FROM aq_admin_users WHERE role = 'superadmin'")
                return result["cnt"] if result else 0
            finally:
                await db.disconnect()
        except Exception:
            return -1  # Unknown

    try:
        su_count = asyncio.run(_check_su())
    except Exception:
        su_count = -1

    if su_count > 0:
        dim(f"    {_CHECK} {su_count} superuser(s) found")
    elif su_count == 0:
        warning("    ! No superusers found")
        if not non_interactive:
            if click.confirm(click.style("  Create a superuser now?", bold=True), default=True):
                # Invoke the createsuperuser command
                ctx.invoke(admin_createsuperuser)
                return
        else:
            info("      Run 'aq admin createsuperuser' to create one")
    else:
        dim("    ? Could not check (run 'aq db migrate' first)")

    # ── Done ─────────────────────────────────────────────────────────
    click.echo()
    success(f"  {_CHECK} Admin setup complete!")
    click.echo()
    next_steps(
        [
            "aq admin check          (verify configuration)",
            "aq run                  (start the dev server)",
            "Visit http://localhost:8000/admin/",
        ]
    )


@admin.command("status")
@click.option("--database-url", type=str, default=None, help="Database URL")
@click.pass_context
def admin_status(ctx, database_url: str | None):
    """
    Show admin dashboard status and registered models.

    Examples:
      aq admin status
    """
    from aquilia.admin import AdminSite, autodiscover

    if database_url is None:
        database_url = _detect_workspace_db_url()

    site = AdminSite.default()
    site.initialize()
    autodiscover()

    if not ctx.obj.get("quiet"):
        click.echo()
        banner("AquilAdmin", subtitle="Dashboard Status")
        click.echo()

        section("Registered Models")
        models = site.get_registered_models()
        if models:
            for model_name, admin_obj in sorted(models.items()):
                admin_class_name = admin_obj.__class__.__name__
                display_fields = ", ".join(admin_obj.get_list_display()[:5])
                kv(f"  {model_name}", f"{admin_class_name}  fields=[{display_fields}]")
        else:
            info("  No models registered. Run autodiscover() in workspace.py")
        click.echo()

        section("Configuration")
        kv("Admin Auth", "Database (admin_users table)")
        kv("Dashboard URL", "/admin/")
        kv("Audit Log", f"{site.audit_log.count()} entries")
        click.echo()


@admin.command("audit")
@click.option("--limit", type=int, default=50, help="Number of entries to show")
@click.option("--action", type=str, default=None, help="Filter by action type")
@click.option("--user", type=str, default=None, help="Filter by username")
@click.pass_context
def admin_audit(ctx, limit: int, action: str | None, user: str | None):
    """
    View admin audit trail.

    Examples:
      aq admin audit
      aq admin audit --limit=100
      aq admin audit --action=CREATE
      aq admin audit --user=admin
    """
    from aquilia.admin import AdminAction, AdminSite

    site = AdminSite.default()

    filter_action = None
    if action:
        try:
            filter_action = AdminAction(action.lower())
        except ValueError:
            error(f"  {_CROSS} Unknown action: {action}")
            click.echo(f"  Valid actions: {', '.join(a.value for a in AdminAction)}")
            sys.exit(1)

    entries = site.audit_log.get_entries(
        limit=limit,
        action=filter_action,
        user_id=user,
    )

    if not ctx.obj.get("quiet"):
        click.echo()
        section(f"Admin Audit Trail ({len(entries)} entries)")
        click.echo()

        if not entries:
            info("  No audit entries found")
        else:
            for entry in entries:
                ts = entry.timestamp.strftime("%Y-%m-%d %H:%M:%S")
                status_icon = _CHECK if entry.success else _CROSS
                model_info = f" on {entry.model_name}" if entry.model_name else ""
                click.echo(
                    f"  {dim(ts)}  {status_icon}  "
                    f"{bold(entry.action.value.upper())}{model_info}  "
                    f"by {accent(entry.username)}"
                )
                if entry.error_message:
                    click.echo(f"           {error(entry.error_message)}")
        click.echo()


def main():
    """Entry point for `aq` command."""
    cli(obj={})


if __name__ == "__main__":
    main()
