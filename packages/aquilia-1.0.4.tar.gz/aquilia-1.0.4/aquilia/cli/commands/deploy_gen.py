"""
Deploy CLI commands -- ``aq deploy`` group.

Production-ready deployment file generators **and executor** for Aquilia
workspaces.  Each sub-command generates a specific deployment artefact:

    aq deploy                -- Interactive wizard (generate + execute)
    aq deploy dockerfile     -- Dockerfile (production / dev / mlops)
    aq deploy compose        -- docker-compose.yml
    aq deploy kubernetes     -- Full Kubernetes manifest suite
    aq deploy nginx          -- Nginx reverse-proxy configuration
    aq deploy ci             -- CI/CD pipeline (GitHub Actions / GitLab CI)
    aq deploy monitoring     -- Prometheus + Grafana provisioning
    aq deploy env            -- .env.example template
    aq deploy makefile       -- Makefile with dev/build/deploy targets
    aq deploy all            -- Generate everything at once
    aq deploy render         -- Deploy to Render PaaS (one command)

Running ``aq deploy`` with **no** sub-command launches an interactive
wizard (like ``aq init``) that lets you pick which artefacts to generate,
configure options, and optionally **execute** the deployment (docker image build,
docker compose up, kubectl apply, monitoring stack, etc.).

All generators introspect the live workspace to detect enabled components
and tailor the output accordingly.

Flags:
    --force              Overwrite existing files (default: skip existing)
    --dry-run            Preview what would be generated without writing
"""

from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

import click

from ..utils.colors import (
    _ARROW,
    _BOLT,
    _CHECK,
    _CLOUD,
    _CROSS,
    _EYE,
    _GEAR,
    _GLOBE,
    _KEY,
    _PKG,
    _ROCKET,
    _SPARK,
    _WARN,
    banner,
    detail_card,
    dim,
    error,
    file_dry,
    file_skipped,
    file_written,
    info,
    kv,
    next_steps,
    phase_header,
    rule,
    section,
    status_line,
    success,
    table,
    warning,
)
from ..utils.prompts import (
    ask,
    confirm,
    flow_done,
    multi_select,
    recap,
    select,
)


def _get_ctx(workspace_root: Path) -> dict:
    """Introspect the live workspace and return a deployment context."""
    from ..generators.deployment import WorkspaceIntrospector

    return WorkspaceIntrospector(workspace_root).introspect()


def _write_file(
    path: Path,
    content: str,
    *,
    label: str,
    verbose: bool,
    force: bool = False,
    dry_run: bool = False,
) -> bool:
    """Write content to a file, creating parent directories.

    Returns True if the file was written, False if skipped.
    """
    if path.exists() and not force:
        file_skipped(label, reason="exists, use --force")
        return False

    if dry_run:
        file_dry(label)
        return True

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    file_written(label, verbose=verbose, path=str(path))
    return True


def deploy_options(f):
    """Decorator to add shared --force and --dry-run options to subcommands."""
    import functools

    @click.option("--force", "-f", is_flag=True, help="Overwrite existing files")
    @click.option("--dry-run", is_flag=True, help="Preview without writing files")
    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        return f(*args, **kwargs)

    return wrapper


# ═══════════════════════════════════════════════════════════════════════════
# Execution helpers -- run containers, compose, k8s, monitoring
# ═══════════════════════════════════════════════════════════════════════════


def _has_command(name: str) -> bool:
    """Check whether a CLI tool is available on PATH."""
    return shutil.which(name) is not None


def _run(cmd: list[str], *, label: str, cwd: Path, dry_run: bool = False) -> bool:
    """Run a shell command with styled output.

    Returns True on success, False on failure.
    """
    display = " ".join(cmd)
    if dry_run:
        dim(f"  [dry-run] {display}")
        return True

    info(f"  $ {display}")
    try:
        result = subprocess.run(
            cmd,
            cwd=str(cwd),
            capture_output=False,
            text=True,
        )
        if result.returncode == 0:
            success(f"  {_CHECK} {label}")
            return True
        else:
            error(f"  {_CROSS} {label} failed (exit {result.returncode})")
            return False
    except FileNotFoundError:
        error(f"  {_CROSS} Command not found: {cmd[0]}")
        return False
    except Exception as e:
        error(f"  {_CROSS} {label} error: {e}")
        return False


def _exec_docker_build(workspace_root: Path, wctx: dict, *, dry_run: bool = False) -> bool:
    """Build the Docker image."""
    name = wctx["name"]
    tag = f"{name}:latest"
    dockerfile = workspace_root / "Dockerfile"
    if not dockerfile.exists() and not dry_run:
        warning("  Dockerfile not found -- skipping build")
        return False
    return _run(
        ["docker", "build", "-t", tag, "."],
        label=f"Docker image built: {tag}",
        cwd=workspace_root,
        dry_run=dry_run,
    )


def _exec_compose_up(
    workspace_root: Path, *, detach: bool = True, monitoring: bool = False, dry_run: bool = False
) -> bool:
    """Bring up docker compose stack."""
    compose_file = workspace_root / "docker-compose.yml"
    if not compose_file.exists() and not dry_run:
        warning("  docker-compose.yml not found -- skipping")
        return False
    cmd = ["docker", "compose"]
    if monitoring:
        cmd.extend(["--profile", "monitoring"])
    cmd.append("up")
    if detach:
        cmd.append("-d")
    return _run(
        cmd,
        label="Docker Compose stack started",
        cwd=workspace_root,
        dry_run=dry_run,
    )


def _k8s_cluster_reachable() -> bool:
    """Return True if the current kubectl context has a reachable API server.

    Runs ``kubectl cluster-info --request-timeout=3s`` and checks the exit
    code.  Suppresses all output so the check is silent.
    """
    try:
        result = subprocess.run(
            ["kubectl", "cluster-info", "--request-timeout=3s"],
            capture_output=True,
            timeout=5,
        )
        return result.returncode == 0
    except Exception:
        return False


def _exec_k8s_apply(workspace_root: Path, *, namespace: str = "", dry_run: bool = False):
    """Apply Kubernetes manifests via kustomize.

    Returns:
        True  -- manifests applied successfully
        False -- kubectl exited non-zero (real failure)
        None  -- skipped (no cluster reachable / missing k8s dir / no kubectl)
    """
    if dry_run:
        dim("  [dry-run] kubectl apply -k k8s/")
        return True

    k8s_dir = workspace_root / "k8s"
    if not k8s_dir.exists():
        warning("  k8s/ directory not found -- skipping")
        return None

    if not _has_command("kubectl"):
        warning("  kubectl not found on PATH -- skipping k8s apply")
        return None

    info("  Checking cluster connectivity...")
    if not _k8s_cluster_reachable():
        warning("  No Kubernetes cluster reachable (kubectl cluster-info failed).")
        dim("  Manifests are ready in k8s/ -- apply when a cluster is available:")
        dim("    kubectl apply -k k8s/")
        if namespace:
            dim(f"    kubectl apply -k k8s/ -n {namespace}")
        return None  # not a hard error -- manifests were generated fine

    cmd = ["kubectl", "apply", "-k", "k8s/", "--validate=false"]
    if namespace:
        cmd.extend(["-n", namespace])
    return _run(
        cmd,
        label="Kubernetes manifests applied",
        cwd=workspace_root,
        dry_run=False,
    )


def _exec_compose_audit(workspace_root: Path, *, dry_run: bool = False) -> bool:
    """Audit running compose services (ps + health)."""
    compose_file = workspace_root / "docker-compose.yml"
    if not compose_file.exists() and not dry_run:
        return False
    return _run(
        ["docker", "compose", "ps", "--format", "table"],
        label="Compose service audit",
        cwd=workspace_root,
        dry_run=dry_run,
    )


def _exec_monitoring_up(workspace_root: Path, *, dry_run: bool = False) -> bool:
    """Start monitoring stack via compose profile."""
    compose_file = workspace_root / "docker-compose.yml"
    if not compose_file.exists() and not dry_run:
        warning("  docker-compose.yml not found -- cannot start monitoring")
        return False
    return _run(
        ["docker", "compose", "--profile", "monitoring", "up", "-d"],
        label="Monitoring stack started (Prometheus + Grafana)",
        cwd=workspace_root,
        dry_run=dry_run,
    )


# ═══════════════════════════════════════════════════════════════════════════
# Click group
# ═══════════════════════════════════════════════════════════════════════════


@click.group("deploy", invoke_without_command=True)
@click.option("--force", "-f", is_flag=True, help="Overwrite existing files")
@click.option("--dry-run", is_flag=True, help="Preview without writing files")
@click.option("--yes", "-y", is_flag=True, help="Skip interactive prompts, use defaults")
@click.pass_context
def deploy_gen_group(ctx, force: bool, dry_run: bool, yes: bool):
    """Generate & execute production deployment files.

    Interactive wizard:
      aq deploy              # Full interactive setup + execute
      aq deploy -y           # Non-interactive generate + deploy
      aq deploy --dry-run    # Preview what would happen

    Sub-commands:
      aq deploy dockerfile
      aq deploy compose --monitoring
      aq deploy kubernetes
      aq deploy all
      aq deploy all --force
      aq deploy all --dry-run

    """
    ctx.ensure_object(dict)
    ctx.obj["force"] = force
    ctx.obj["dry_run"] = dry_run

    # If a sub-command was given, delegate to it
    if ctx.invoked_subcommand is not None:
        return

    # ── Interactive deploy wizard ────────────────────────────────────
    _interactive_deploy(ctx, force=force, dry_run=dry_run, yes=yes)


# ═══════════════════════════════════════════════════════════════════════════
# Interactive deploy wizard
# ═══════════════════════════════════════════════════════════════════════════


def _interactive_deploy(
    ctx: click.Context,
    *,
    force: bool,
    dry_run: bool,
    yes: bool,
) -> None:
    """Full interactive deployment wizard.

    Steps:
      1. Introspect workspace
      2. Select artefacts to generate
      3. Configure options (CI provider, monitoring, dev mode, …)
      4. Review & confirm
      5. Generate files
      6. Optionally execute deployment
    """
    from ..generators.deployment import (
        CIGenerator,
        ComposeGenerator,
        DockerfileGenerator,
        EnvGenerator,
        GrafanaGenerator,
        KubernetesGenerator,
        MakefileGenerator,
        NginxGenerator,
        PrometheusGenerator,
    )

    workspace_root = Path.cwd()
    verbose = ctx.obj.get("verbose", False)
    interactive = not yes and sys.stdin.isatty()
    written = 0

    # ── 1. Introspect workspace ──────────────────────────────────────
    try:
        wctx = _get_ctx(workspace_root)
    except Exception as e:
        error(f"  {_CROSS} Workspace introspection failed: {e}")
        sys.exit(1)

    name = wctx["name"]

    if interactive:
        click.echo()
        banner(
            "Aquilia Deploy",
            subtitle="Generate & execute production deployment for your workspace",
            icon=_ROCKET,
            fg="magenta",
        )
        click.echo()

        # Show detected workspace info
        phase_header(1, "Workspace detected", icon=_PKG)

        detail_card(
            "Workspace",
            [
                ("Name", name),
                ("Source", "live introspection"),
                ("Modules", str(wctx.get("module_count", 0))),
                ("DB driver", wctx.get("db_driver", "none")),
                ("Python", wctx.get("python_version", "3.12")),
                ("Cache", "yes" if wctx.get("has_cache") else "no"),
                ("WebSockets", "yes" if wctx.get("has_websockets") else "no"),
                ("MLOps", "yes" if wctx.get("has_mlops") else "no"),
            ],
            icon=_GEAR,
        )
        click.echo()

        # ── 2. Select artefacts ──────────────────────────────────────
        phase_header(2, "Select artefacts", icon=_PKG)
        artefacts = multi_select(
            "Artefacts to generate",
            [
                ("dockerfile", "Dockerfile (prod + dev + mlops)", True),
                ("compose", "docker-compose.yml (full stack)", True),
                ("kubernetes", "Kubernetes manifests (k8s/)", False),
                ("nginx", "Nginx reverse-proxy config", False),
                ("ci", "CI/CD pipeline (GitHub/GitLab)", True),
                ("monitoring", "Prometheus + Grafana provisioning", True),
                ("env", ".env.example template", True),
                ("makefile", "Makefile (dev/build/deploy targets)", True),
            ],
        )

        if not artefacts:
            info("  No artefacts selected -- nothing to do.")
            return

        # ── 3. Configure options ─────────────────────────────────────
        phase_header(3, "Configure options", icon=_GEAR)

        # CI provider (only if ci selected)
        ci_provider = "github"
        if "ci" in artefacts:
            ci_provider = select(
                "CI/CD provider",
                [
                    ("github", "GitHub Actions"),
                    ("gitlab", "GitLab CI/CD"),
                    ("both", "Both providers"),
                ],
                default=0,
            )

        # Dev mode dockerfiles
        include_dev = False
        if "dockerfile" in artefacts:
            include_dev = confirm("Generate dev Dockerfile? (hot-reload)", default=True)

        # Monitoring in compose
        include_monitoring = "monitoring" in artefacts
        if "compose" in artefacts and not include_monitoring:
            include_monitoring = confirm("Include monitoring services in Compose?", default=False)

        # Output directory
        output_dir = ask(
            "Output directory",
            default=".",
            hint="relative to workspace root",
        )

        # ── 4. Execution options ─────────────────────────────────────
        phase_header(4, "Execution options", icon=_BOLT)

        exec_actions = multi_select(
            "After generating, execute",
            [
                ("docker-build", "Build Docker image", "dockerfile" in artefacts),
                ("compose-up", "Start Docker Compose stack", "compose" in artefacts),
                ("k8s-apply", "Apply Kubernetes manifests (kubectl)", "kubernetes" in artefacts),
                ("monitoring-up", "Start monitoring (Prometheus+Grafana)", include_monitoring),
                ("compose-audit", "Audit running services (docker ps)", "compose" in artefacts),
            ],
        )

        # ── 5. Review & confirm ─────────────────────────────────────
        phase_header(5, "Review & confirm", icon=_EYE)
        recap(
            [
                ("Workspace", name),
                ("Artefacts", ", ".join(artefacts)),
                ("CI provider", ci_provider if "ci" in artefacts else "—"),
                ("Dev Dockerfile", "yes" if include_dev else "no"),
                ("Monitoring", "yes" if include_monitoring else "no"),
                ("Output", output_dir),
                ("Execute", ", ".join(exec_actions) if exec_actions else "none"),
                ("Force", "yes" if force else "no"),
                ("Dry run", "yes" if dry_run else "no"),
            ],
            title="Deploy configuration",
        )

        if not confirm("Proceed with deployment?", default=True):
            click.echo()
            info("  Cancelled.")
            return

    else:
        # ── Non-interactive defaults ─────────────────────────────────
        artefacts = [
            "dockerfile",
            "compose",
            "kubernetes",
            "nginx",
            "ci",
            "monitoring",
            "env",
            "makefile",
        ]
        ci_provider = "github"
        include_dev = True
        include_monitoring = True
        output_dir = "."
        exec_actions = ["docker-build", "compose-up", "compose-audit"]

    # ── 6. Generate files ────────────────────────────────────────────
    out = Path(output_dir)

    click.echo()
    banner(f"Deploy: {name}", subtitle="DRY RUN" if dry_run else "Generating deployment suite", icon=_PKG, fg="magenta")
    click.echo()

    # -- Dockerfiles --
    if "dockerfile" in artefacts:
        section("Docker")
        docker_gen = DockerfileGenerator(wctx)
        if _write_file(
            out / "Dockerfile",
            docker_gen.generate_dockerfile(),
            label="Dockerfile (production)",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1
        if _write_file(
            out / ".dockerignore",
            docker_gen.generate_dockerignore(),
            label=".dockerignore",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1
        if include_dev and _write_file(
            out / "Dockerfile.dev",
            docker_gen.generate_dockerfile_dev(),
            label="Dockerfile.dev (development)",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1
        if wctx.get("has_mlops") and _write_file(
            out / "Dockerfile.mlops",
            docker_gen.generate_dockerfile_mlops(),
            label="Dockerfile.mlops (model-serving)",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1
        click.echo()

    # -- Compose --
    if "compose" in artefacts:
        section("Docker Compose")
        compose_gen = ComposeGenerator(wctx)
        if _write_file(
            out / "docker-compose.yml",
            compose_gen.generate_compose(include_monitoring=include_monitoring),
            label="docker-compose.yml",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1
        if include_dev and _write_file(
            out / "docker-compose.dev.yml",
            compose_gen.generate_compose_dev(),
            label="docker-compose.dev.yml (dev override)",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1
        click.echo()

    # -- Kubernetes --
    if "kubernetes" in artefacts:
        section("Kubernetes")
        k8s_gen = KubernetesGenerator(wctx)
        manifests = k8s_gen.generate_all()
        for filename, content in manifests.items():
            if _write_file(
                out / "k8s" / filename, content, label=f"k8s/{filename}", verbose=verbose, force=force, dry_run=dry_run
            ):
                written += 1

        kustomize_resources = "\n".join(f"  - {f}" for f in sorted(manifests.keys()))
        kustomize_content = (
            f"apiVersion: kustomize.config.k8s.io/v1beta1\n"
            f"kind: Kustomization\n"
            f"namespace: {name}\n\n"
            f"labels:\n"
            f"  - pairs:\n"
            f"      app.kubernetes.io/name: {name}\n"
            f"      app.kubernetes.io/managed-by: aquilia-cli\n\n"
            f"resources:\n{kustomize_resources}\n"
        )
        if _write_file(
            out / "k8s" / "kustomization.yaml",
            kustomize_content,
            label="k8s/kustomization.yaml",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1
        click.echo()

    # -- Nginx --
    if "nginx" in artefacts:
        section("Nginx")
        nginx_gen = NginxGenerator(wctx)
        if _write_file(
            out / "deploy" / "nginx" / "nginx.conf",
            nginx_gen.generate_nginx_conf(),
            label="deploy/nginx/nginx.conf",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1
        if not dry_run:
            (out / "deploy" / "nginx" / "ssl").mkdir(parents=True, exist_ok=True)
        if _write_file(
            out / "deploy" / "nginx" / "ssl" / ".gitkeep",
            "",
            label="deploy/nginx/ssl/.gitkeep",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1
        click.echo()

    # -- CI/CD --
    if "ci" in artefacts:
        section("CI/CD")
        ci_gen = CIGenerator(wctx)
        if ci_provider in ("github", "both") and _write_file(
            out / ".github" / "workflows" / "ci.yml",
            ci_gen.generate_github_actions(),
            label=".github/workflows/ci.yml",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1
        if ci_provider in ("gitlab", "both") and _write_file(
            out / ".gitlab-ci.yml",
            ci_gen.generate_gitlab_ci(),
            label=".gitlab-ci.yml",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1
        click.echo()

    # -- Monitoring --
    if "monitoring" in artefacts:
        section("Monitoring")
        prom_gen = PrometheusGenerator(wctx)
        if _write_file(
            out / "deploy" / "prometheus" / "prometheus.yml",
            prom_gen.generate_prometheus_yml(),
            label="deploy/prometheus/prometheus.yml",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1
        graf_gen = GrafanaGenerator(wctx)
        if _write_file(
            out / "deploy" / "grafana" / "provisioning" / "datasources" / "datasource.yml",
            graf_gen.generate_datasource(),
            label="deploy/grafana/.../datasource.yml",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1
        if _write_file(
            out / "deploy" / "grafana" / "provisioning" / "dashboards" / "dashboards.yml",
            graf_gen.generate_dashboard_provisioning(),
            label="deploy/grafana/.../dashboards.yml",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1
        click.echo()

    # -- Env --
    if "env" in artefacts:
        section("Environment")
        env_gen = EnvGenerator(wctx)
        if _write_file(
            out / ".env.example",
            env_gen.generate_env_example(),
            label=".env.example",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1
        click.echo()

    # -- Makefile --
    if "makefile" in artefacts:
        section("Makefile")
        mk_gen = MakefileGenerator(wctx)
        if _write_file(
            out / "Makefile",
            mk_gen.generate_makefile(),
            label="Makefile",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1
        click.echo()

    # -- Generation summary --
    rule()
    click.echo()
    if dry_run:
        info(f"  {written} file(s) would be generated")
    else:
        success(f"  {_CHECK} {written} file(s) generated for '{name}' {_SPARK}")
    click.echo()

    # ── 7. Execute deployment ────────────────────────────────────────
    if exec_actions and not dry_run:
        rule()
        banner(f"Execute: {name}", subtitle="Running deployment actions", icon=_BOLT, fg="cyan")
        click.echo()

        exec_ok = 0
        exec_fail = 0
        exec_skip = 0

        if "docker-build" in exec_actions:
            section("Docker Build")
            if not _has_command("docker"):
                warning("  Docker not found on PATH -- skipping build")
                exec_fail += 1
            elif _exec_docker_build(workspace_root, wctx, dry_run=dry_run):
                exec_ok += 1
            else:
                exec_fail += 1
            click.echo()

        if "compose-up" in exec_actions:
            section("Docker Compose Up")
            if not _has_command("docker"):
                warning("  Docker not found on PATH -- skipping compose")
                exec_fail += 1
            elif _exec_compose_up(
                workspace_root,
                monitoring=include_monitoring and "monitoring-up" in exec_actions,
                dry_run=dry_run,
            ):
                exec_ok += 1
            else:
                exec_fail += 1
            click.echo()

        if "k8s-apply" in exec_actions:
            section("Kubernetes Apply")
            k8s_result = _exec_k8s_apply(workspace_root, namespace=name, dry_run=dry_run)
            if k8s_result is True:
                exec_ok += 1
            elif k8s_result is None:
                exec_skip += 1  # no cluster -- not a failure
            else:
                exec_fail += 1
            click.echo()

        if "monitoring-up" in exec_actions and "compose-up" not in exec_actions:
            # Only start monitoring separately if compose-up didn't already
            section("Monitoring Stack")
            if not _has_command("docker"):
                warning("  Docker not found on PATH -- skipping monitoring")
                exec_fail += 1
            elif _exec_monitoring_up(workspace_root, dry_run=dry_run):
                exec_ok += 1
            else:
                exec_fail += 1
            click.echo()

        if "compose-audit" in exec_actions:
            section("Service Audit")
            if _has_command("docker"):
                _exec_compose_audit(workspace_root, dry_run=dry_run)
                exec_ok += 1
            else:
                warning("  Docker not found on PATH -- skipping audit")
                exec_fail += 1
            click.echo()

        # Execution summary
        rule()
        click.echo()
        if exec_fail == 0:
            success(f"  {_CHECK} All {exec_ok} action(s) completed successfully {_SPARK}")
        elif exec_ok == 0 and exec_fail == 0:
            info(f"  {exec_skip} action(s) skipped (no cluster / tool unavailable)")
        else:
            parts = [f"{exec_ok} succeeded"]
            if exec_skip:
                parts.append(f"{exec_skip} skipped")
            if exec_fail:
                parts.append(f"{exec_fail} failed")
            warning(f"  {', '.join(parts)}")
        click.echo()

    elif exec_actions and dry_run:
        rule()
        click.echo()
        info(f"  [dry-run] {len(exec_actions)} action(s) would be executed:")
        for action in exec_actions:
            dim(f"    {_ARROW} {action}")
        click.echo()

    # ── 8. Next steps ────────────────────────────────────────────────
    tips: list[str] = []
    if "env" in artefacts:
        tips.append("cp .env.example .env && edit .env")
    if "compose" in artefacts and "compose-up" not in exec_actions:
        tips.append("docker compose up -d")
    if "kubernetes" in artefacts and "k8s-apply" not in exec_actions:
        tips.append("kubectl apply -k k8s/")
    if "makefile" in artefacts:
        tips.append("make help")
    if "monitoring" in artefacts:
        tips.append("Open Grafana at http://localhost:3000 (admin/admin)")
    if tips:
        next_steps(tips)
        click.echo()

    flow_done("Deployment complete.")


# ═══════════════════════════════════════════════════════════════════════════
# aq deploy dockerfile
# ═══════════════════════════════════════════════════════════════════════════


@deploy_gen_group.command("dockerfile")
@click.option("--dev", "dev_mode", is_flag=True, help="Generate development Dockerfile (with hot-reload)")
@click.option("--mlops", "mlops_mode", is_flag=True, help="Generate MLOps model-serving Dockerfile")
@click.option("--output", "-o", type=click.Path(), default=".", help="Output directory")
@deploy_options
@click.pass_context
def deploy_dockerfile(ctx, dev_mode: bool, mlops_mode: bool, output: str, force: bool, dry_run: bool):
    """
    Generate production-ready Dockerfiles.

    Creates a multi-stage Dockerfile optimised for Aquilia with
    non-root user, health-checks, tini init, BuildKit cache mounts,
    and artifact compilation.

    Examples:
      aq deploy dockerfile
      aq deploy dockerfile --dev
      aq deploy dockerfile --mlops
      aq deploy dockerfile --dev --mlops   # Generate all variants
      aq deploy -f dockerfile              # Force overwrite
    """
    from ..generators.deployment import DockerfileGenerator

    workspace_root = Path.cwd()
    out = Path(output)
    verbose = ctx.obj.get("verbose", False)
    force = force or ctx.obj.get("force", False)
    dry_run = dry_run or ctx.obj.get("dry_run", False)

    try:
        wctx = _get_ctx(workspace_root)
        gen = DockerfileGenerator(wctx)

        action = "DRY RUN" if dry_run else "Generating"
        section(f"{action}: Dockerfiles for '{wctx['name']}'")

        kv("Modules", str(wctx.get("module_count", 0)))
        kv("DB driver", wctx.get("db_driver", "none"))
        kv("Python", wctx.get("python_version", "3.12"))
        click.echo()

        # Always generate production Dockerfile + .dockerignore
        if not dev_mode or mlops_mode:
            _write_file(
                out / "Dockerfile",
                gen.generate_dockerfile(),
                label="Dockerfile (production)",
                verbose=verbose,
                force=force,
                dry_run=dry_run,
            )
            _write_file(
                out / ".dockerignore",
                gen.generate_dockerignore(),
                label=".dockerignore",
                verbose=verbose,
                force=force,
                dry_run=dry_run,
            )

        if dev_mode:
            _write_file(
                out / "Dockerfile.dev",
                gen.generate_dockerfile_dev(),
                label="Dockerfile.dev (development)",
                verbose=verbose,
                force=force,
                dry_run=dry_run,
            )
            if not mlops_mode:
                _write_file(
                    out / ".dockerignore",
                    gen.generate_dockerignore(),
                    label=".dockerignore",
                    verbose=verbose,
                    force=force,
                    dry_run=dry_run,
                )

        if mlops_mode or wctx.get("has_mlops"):
            _write_file(
                out / "Dockerfile.mlops",
                gen.generate_dockerfile_mlops(),
                label="Dockerfile.mlops (model-serving)",
                verbose=verbose,
                force=force,
                dry_run=dry_run,
            )

        click.echo()
        next_steps(
            [
                "docker build -t myapp .",
                "docker run -p 8000:8000 myapp",
            ]
        )

    except Exception as e:
        error(f"  {_CROSS} Dockerfile generation failed: {e}")
        sys.exit(1)


# ═══════════════════════════════════════════════════════════════════════════
# aq deploy compose
# ═══════════════════════════════════════════════════════════════════════════


@deploy_gen_group.command("compose")
@click.option("--dev", "dev_mode", is_flag=True, help="Also generate docker-compose.dev.yml")
@click.option("--monitoring", is_flag=True, help="Include Prometheus + Grafana services")
@click.option("--output", "-o", type=click.Path(), default=".", help="Output directory")
@deploy_options
@click.pass_context
def deploy_compose(ctx, dev_mode: bool, monitoring: bool, output: str, force: bool, dry_run: bool):
    """
    Generate docker-compose.yml for the workspace.

    Auto-detects services: PostgreSQL, MySQL, Redis, MLOps model server,
    Nginx, monitoring, and mail based on your workspace configuration.
    Uses compose profiles for optional services (mlops, monitoring, dev).

    Examples:
      aq deploy compose
      aq deploy compose --monitoring
      aq deploy compose --dev
      aq deploy -f compose   # Force overwrite
    """
    from ..generators.deployment import ComposeGenerator

    workspace_root = Path.cwd()
    out = Path(output)
    verbose = ctx.obj.get("verbose", False)
    force = force or ctx.obj.get("force", False)
    dry_run = dry_run or ctx.obj.get("dry_run", False)

    try:
        wctx = _get_ctx(workspace_root)
        gen = ComposeGenerator(wctx)

        action = "DRY RUN" if dry_run else "Generating"
        section(f"{action}: Docker Compose for '{wctx['name']}'")

        _write_file(
            out / "docker-compose.yml",
            gen.generate_compose(include_monitoring=monitoring),
            label="docker-compose.yml",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        )

        if dev_mode:
            _write_file(
                out / "docker-compose.dev.yml",
                gen.generate_compose_dev(),
                label="docker-compose.dev.yml",
                verbose=verbose,
                force=force,
                dry_run=dry_run,
            )

        click.echo()
        next_steps(
            [
                "docker compose up -d",
                "docker compose --profile proxy up -d        # Include Nginx",
                "docker compose --profile monitoring up -d   # Include Prometheus + Grafana",
                "docker compose logs -f app",
            ]
        )

    except Exception as e:
        error(f"  {_CROSS} Compose generation failed: {e}")
        sys.exit(1)


# ═══════════════════════════════════════════════════════════════════════════
# aq deploy kubernetes
# ═══════════════════════════════════════════════════════════════════════════


@deploy_gen_group.command("kubernetes")
@click.option("--output", "-o", type=click.Path(), default="k8s", help="Output directory")
@click.option("--mlops", is_flag=True, help="Force include MLOps manifests")
@deploy_options
@click.pass_context
def deploy_kubernetes(ctx, output: str, mlops: bool, force: bool, dry_run: bool):
    """
    Generate production Kubernetes manifests.

    Generates namespace, deployment, service, ingress, HPA, PDB,
    network policy, configmap, secret, service account, PVC,
    CronJob for maintenance, and init containers for DB readiness.
    Includes MLOps manifests if mlops components are detected.

    Examples:
      aq deploy kubernetes
      aq deploy kubernetes -o deploy/k8s
      aq deploy kubernetes --mlops
    """
    from ..generators.deployment import KubernetesGenerator

    workspace_root = Path.cwd()
    out = Path(output)
    verbose = ctx.obj.get("verbose", False)
    force = force or ctx.obj.get("force", False)
    dry_run = dry_run or ctx.obj.get("dry_run", False)

    try:
        wctx = _get_ctx(workspace_root)
        if mlops:
            wctx["has_mlops"] = True

        gen = KubernetesGenerator(wctx)

        action = "DRY RUN" if dry_run else "Generating"
        section(f"{action}: Kubernetes manifests for '{wctx['name']}'")

        manifests = gen.generate_all()
        for filename, content in manifests.items():
            _write_file(out / filename, content, label=filename, verbose=verbose, force=force, dry_run=dry_run)

        # Generate kustomization.yaml
        kustomize_resources = "\n".join(f"  - {f}" for f in sorted(manifests.keys()))
        kustomize_content = (
            f"# Kustomize configuration for {wctx['name']}\n"
            f"# Generated by: aq deploy kubernetes\n\n"
            f"apiVersion: kustomize.config.k8s.io/v1beta1\n"
            f"kind: Kustomization\n\n"
            f"namespace: {wctx['name']}\n\n"
            f"labels:\n"
            f"  - pairs:\n"
            f"      app.kubernetes.io/name: {wctx['name']}\n"
            f"      app.kubernetes.io/managed-by: aquilia-cli\n\n"
            f"resources:\n{kustomize_resources}\n"
        )
        _write_file(
            out / "kustomization.yaml",
            kustomize_content,
            label="kustomization.yaml",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        )

        click.echo()
        kv("Manifests", str(len(manifests)))
        click.echo()
        next_steps(
            [
                f"kubectl apply -k {output}/",
                f"kustomize build {output}/ | kubectl apply -f -",
            ]
        )

    except Exception as e:
        error(f"  {_CROSS} Kubernetes generation failed: {e}")
        sys.exit(1)


# ═══════════════════════════════════════════════════════════════════════════
# aq deploy nginx
# ═══════════════════════════════════════════════════════════════════════════


@deploy_gen_group.command("nginx")
@click.option("--output", "-o", type=click.Path(), default="deploy/nginx", help="Output directory")
@deploy_options
@click.pass_context
def deploy_nginx(ctx, output: str, force: bool, dry_run: bool):
    """
    Generate Nginx reverse-proxy configuration.

    Includes rate-limiting, security headers (HSTS, CSP, XSS), gzip,
    WebSocket upgrade support, upstream keepalive, and MLOps proxy
    if detected. HTTPS block included (commented) with modern TLS config.

    Examples:
      aq deploy nginx
      aq deploy nginx -o config/nginx
    """
    from ..generators.deployment import NginxGenerator

    workspace_root = Path.cwd()
    out = Path(output)
    verbose = ctx.obj.get("verbose", False)
    force = force or ctx.obj.get("force", False)
    dry_run = dry_run or ctx.obj.get("dry_run", False)

    try:
        wctx = _get_ctx(workspace_root)
        gen = NginxGenerator(wctx)

        action = "DRY RUN" if dry_run else "Generating"
        section(f"{action}: Nginx config for '{wctx['name']}'")

        _write_file(
            out / "nginx.conf",
            gen.generate_nginx_conf(),
            label="nginx.conf",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        )

        # Create ssl directory placeholder
        if not dry_run:
            ssl_dir = out / "ssl"
            ssl_dir.mkdir(parents=True, exist_ok=True)
            _write_file(
                ssl_dir / ".gitkeep",
                "",
                label="ssl/.gitkeep (placeholder)",
                verbose=verbose,
                force=force,
                dry_run=dry_run,
            )

        click.echo()
        next_steps(
            [
                "Place TLS certificates in deploy/nginx/ssl/",
                "Uncomment HTTPS block in nginx.conf",
            ]
        )

    except Exception as e:
        error(f"  {_CROSS} Nginx generation failed: {e}")
        sys.exit(1)


# ═══════════════════════════════════════════════════════════════════════════
# aq deploy ci
# ═══════════════════════════════════════════════════════════════════════════


@deploy_gen_group.command("ci")
@click.option("--provider", type=click.Choice(["github", "gitlab"]), default="github", help="CI provider")
@click.option("--output", "-o", type=click.Path(), default=None, help="Output directory")
@deploy_options
@click.pass_context
def deploy_ci(ctx, provider: str, output: str | None, force: bool, dry_run: bool):
    """
    Generate CI/CD pipeline configuration.

    Creates a CI/CD workflow with lint, test, security scan, build,
    and deploy stages. Includes Trivy container scanning, dependency
    auditing, and Aquilia-specific validation steps.

    Supported providers:
      --provider=github   GitHub Actions (default)
      --provider=gitlab   GitLab CI/CD

    Examples:
      aq deploy ci
      aq deploy ci --provider=github
      aq deploy ci --provider=gitlab
    """
    from ..generators.deployment import CIGenerator

    workspace_root = Path.cwd()
    verbose = ctx.obj.get("verbose", False)
    force = force or ctx.obj.get("force", False)
    dry_run = dry_run or ctx.obj.get("dry_run", False)

    try:
        wctx = _get_ctx(workspace_root)
        gen = CIGenerator(wctx)

        action = "DRY RUN" if dry_run else "Generating"
        section(f"{action}: CI/CD pipeline for '{wctx['name']}' ({provider})")

        if provider == "github":
            out_dir = Path(output) if output else workspace_root / ".github" / "workflows"
            _write_file(
                out_dir / "ci.yml",
                gen.generate_github_actions(),
                label=".github/workflows/ci.yml",
                verbose=verbose,
                force=force,
                dry_run=dry_run,
            )
        elif provider == "gitlab":
            out_dir = Path(output) if output else workspace_root
            _write_file(
                out_dir / ".gitlab-ci.yml",
                gen.generate_gitlab_ci(),
                label=".gitlab-ci.yml",
                verbose=verbose,
                force=force,
                dry_run=dry_run,
            )

        click.echo()
        next_steps(
            [
                "Review the generated workflow",
                "Configure secrets in repository settings",
                "Push to trigger CI",
            ]
        )

    except Exception as e:
        error(f"  {_CROSS} CI generation failed: {e}")
        sys.exit(1)


# ═══════════════════════════════════════════════════════════════════════════
# aq deploy monitoring
# ═══════════════════════════════════════════════════════════════════════════


@deploy_gen_group.command("monitoring")
@click.option("--output", "-o", type=click.Path(), default="deploy", help="Output base directory")
@deploy_options
@click.pass_context
def deploy_monitoring(ctx, output: str, force: bool, dry_run: bool):
    """
    Generate monitoring configuration (Prometheus + Grafana).

    Creates Prometheus scrape config and Grafana provisioning files
    for Aquilia app and MLOps model server metrics.

    Prometheus scrape targets are auto-configured based on detected
    modules (app metrics, model-server, Redis, Postgres exporters).

    Examples:
      aq deploy monitoring
      aq deploy monitoring -o infra/
      aq deploy monitoring --force
    """
    from ..generators.deployment import GrafanaGenerator, PrometheusGenerator

    workspace_root = Path.cwd()
    out = Path(output)
    verbose = ctx.obj.get("verbose", False)
    force = force or ctx.obj.get("force", False)
    dry_run = dry_run or ctx.obj.get("dry_run", False)

    try:
        wctx = _get_ctx(workspace_root)

        action = "DRY RUN" if dry_run else "Generating"
        section(f"{action}: Monitoring for '{wctx['name']}'")

        prom_gen = PrometheusGenerator(wctx)
        _write_file(
            out / "prometheus" / "prometheus.yml",
            prom_gen.generate_prometheus_yml(),
            label="prometheus/prometheus.yml",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        )

        graf_gen = GrafanaGenerator(wctx)
        _write_file(
            out / "grafana" / "provisioning" / "datasources" / "datasource.yml",
            graf_gen.generate_datasource(),
            label="grafana/provisioning/datasources/datasource.yml",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        )
        _write_file(
            out / "grafana" / "provisioning" / "dashboards" / "dashboards.yml",
            graf_gen.generate_dashboard_provisioning(),
            label="grafana/provisioning/dashboards/dashboards.yml",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        )

        click.echo()
        next_steps(
            [
                "aq deploy compose --monitoring",
                "docker compose up -d prometheus grafana",
                "Open Grafana at http://localhost:3000 (admin/admin)",
            ]
        )

    except Exception as e:
        error(f"  {_CROSS} Monitoring generation failed: {e}")
        sys.exit(1)


# ═══════════════════════════════════════════════════════════════════════════
# aq deploy env
# ═══════════════════════════════════════════════════════════════════════════


@deploy_gen_group.command("env")
@click.option("--output", "-o", type=click.Path(), default=".", help="Output directory")
@deploy_options
@click.pass_context
def deploy_env(ctx, output: str, force: bool, dry_run: bool):
    """
    Generate .env.example template with all Aquilia settings.

    Scans the workspace for enabled components and generates
    a comprehensive environment variable template. Includes
    db-driver-aware DATABASE_URL defaults, telemetry, CORS,
    and monitoring sections when relevant.

    Examples:
      aq deploy env
      aq deploy env --force
    """
    from ..generators.deployment import EnvGenerator

    workspace_root = Path.cwd()
    out = Path(output)
    verbose = ctx.obj.get("verbose", False)
    force = force or ctx.obj.get("force", False)
    dry_run = dry_run or ctx.obj.get("dry_run", False)

    try:
        wctx = _get_ctx(workspace_root)
        gen = EnvGenerator(wctx)

        action = "DRY RUN" if dry_run else "Generating"
        section(f"{action}: .env.example for '{wctx['name']}'")

        _write_file(
            out / ".env.example",
            gen.generate_env_example(),
            label=".env.example",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        )

        click.echo()
        kv("DB driver", wctx.get("db_driver", "sqlite"))
        click.echo()
        next_steps(
            [
                "cp .env.example .env",
                "Fill in real secrets -- never commit .env",
            ]
        )

    except Exception as e:
        error(f"  {_CROSS} Env generation failed: {e}")
        sys.exit(1)


# ═══════════════════════════════════════════════════════════════════════════
# aq deploy all
# ═══════════════════════════════════════════════════════════════════════════


@deploy_gen_group.command("all")
@click.option("--output", "-o", type=click.Path(), default=".", help="Output base directory")
@click.option("--monitoring", is_flag=True, default=True, help="Include monitoring (default: yes)")
@click.option("--ci-provider", type=click.Choice(["github", "gitlab", "both"]), default="github", help="CI/CD provider")
@deploy_options
@click.pass_context
def deploy_all(ctx, output: str, monitoring: bool, ci_provider: str, force: bool, dry_run: bool):
    """
    Generate ALL deployment files at once.

    Creates Dockerfile, docker-compose.yml, Kubernetes manifests,
    Nginx config, CI/CD pipeline(s), Makefile, monitoring, and
    .env template.  Respects --force and --dry-run flags.

    Examples:
      aq deploy all
      aq deploy all -o deploy/
      aq deploy all --ci-provider=both --force
    """
    from ..generators.deployment import (
        CIGenerator,
        ComposeGenerator,
        DockerfileGenerator,
        EnvGenerator,
        GrafanaGenerator,
        KubernetesGenerator,
        MakefileGenerator,
        NginxGenerator,
        PrometheusGenerator,
    )

    workspace_root = Path.cwd()
    out = Path(output)
    verbose = ctx.obj.get("verbose", False)
    force = force or ctx.obj.get("force", False)
    dry_run = dry_run or ctx.obj.get("dry_run", False)
    written = 0  # track files written

    try:
        wctx = _get_ctx(workspace_root)
        name = wctx["name"]

        action = "DRY RUN" if dry_run else "Generating"
        banner(f"Deploy: {name}", subtitle=f"{action} full deployment suite")
        click.echo()

        # -- Dockerfiles --
        section("Docker")
        docker_gen = DockerfileGenerator(wctx)
        if _write_file(
            out / "Dockerfile",
            docker_gen.generate_dockerfile(),
            label="Dockerfile",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1
        if _write_file(
            out / "Dockerfile.dev",
            docker_gen.generate_dockerfile_dev(),
            label="Dockerfile.dev",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1
        if _write_file(
            out / ".dockerignore",
            docker_gen.generate_dockerignore(),
            label=".dockerignore",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1
        if wctx.get("has_mlops") and _write_file(
            out / "Dockerfile.mlops",
            docker_gen.generate_dockerfile_mlops(),
            label="Dockerfile.mlops",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1

        # -- Compose --
        click.echo()
        section("Docker Compose")
        compose_gen = ComposeGenerator(wctx)
        if _write_file(
            out / "docker-compose.yml",
            compose_gen.generate_compose(include_monitoring=monitoring),
            label="docker-compose.yml",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1
        if _write_file(
            out / "docker-compose.dev.yml",
            compose_gen.generate_compose_dev(),
            label="docker-compose.dev.yml",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1

        # -- Kubernetes --
        click.echo()
        section("Kubernetes")
        k8s_gen = KubernetesGenerator(wctx)
        manifests = k8s_gen.generate_all()
        for filename, content in manifests.items():
            if _write_file(
                out / "k8s" / filename, content, label=f"k8s/{filename}", verbose=verbose, force=force, dry_run=dry_run
            ):
                written += 1

        kustomize_resources = "\n".join(f"  - {f}" for f in sorted(manifests.keys()))
        kustomize_content = (
            f"apiVersion: kustomize.config.k8s.io/v1beta1\n"
            f"kind: Kustomization\n"
            f"namespace: {name}\n\n"
            f"labels:\n"
            f"  - pairs:\n"
            f"      app.kubernetes.io/name: {name}\n"
            f"      app.kubernetes.io/managed-by: aquilia-cli\n\n"
            f"resources:\n{kustomize_resources}\n"
        )
        if _write_file(
            out / "k8s" / "kustomization.yaml",
            kustomize_content,
            label="k8s/kustomization.yaml",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1

        # -- Nginx --
        click.echo()
        section("Nginx")
        nginx_gen = NginxGenerator(wctx)
        if _write_file(
            out / "deploy" / "nginx" / "nginx.conf",
            nginx_gen.generate_nginx_conf(),
            label="deploy/nginx/nginx.conf",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1
        if not dry_run:
            (out / "deploy" / "nginx" / "ssl").mkdir(parents=True, exist_ok=True)
        if _write_file(
            out / "deploy" / "nginx" / "ssl" / ".gitkeep",
            "",
            label="deploy/nginx/ssl/.gitkeep",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1

        # -- CI/CD --
        click.echo()
        section("CI/CD")
        ci_gen = CIGenerator(wctx)
        if ci_provider in ("github", "both") and _write_file(
            out / ".github" / "workflows" / "ci.yml",
            ci_gen.generate_github_actions(),
            label=".github/workflows/ci.yml",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1
        if ci_provider in ("gitlab", "both") and _write_file(
            out / ".gitlab-ci.yml",
            ci_gen.generate_gitlab_ci(),
            label=".gitlab-ci.yml",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1

        # -- Monitoring --
        if monitoring:
            click.echo()
            section("Monitoring")
            prom_gen = PrometheusGenerator(wctx)
            if _write_file(
                out / "deploy" / "prometheus" / "prometheus.yml",
                prom_gen.generate_prometheus_yml(),
                label="deploy/prometheus/prometheus.yml",
                verbose=verbose,
                force=force,
                dry_run=dry_run,
            ):
                written += 1
            graf_gen = GrafanaGenerator(wctx)
            if _write_file(
                out / "deploy" / "grafana" / "provisioning" / "datasources" / "datasource.yml",
                graf_gen.generate_datasource(),
                label="deploy/grafana/provisioning/datasources/datasource.yml",
                verbose=verbose,
                force=force,
                dry_run=dry_run,
            ):
                written += 1
            if _write_file(
                out / "deploy" / "grafana" / "provisioning" / "dashboards" / "dashboards.yml",
                graf_gen.generate_dashboard_provisioning(),
                label="deploy/grafana/provisioning/dashboards/dashboards.yml",
                verbose=verbose,
                force=force,
                dry_run=dry_run,
            ):
                written += 1

        # -- Env --
        click.echo()
        section("Environment")
        env_gen = EnvGenerator(wctx)
        if _write_file(
            out / ".env.example",
            env_gen.generate_env_example(),
            label=".env.example",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1

        # -- Makefile --
        click.echo()
        section("Makefile")
        mk_gen = MakefileGenerator(wctx)
        if _write_file(
            out / "Makefile",
            mk_gen.generate_makefile(),
            label="Makefile",
            verbose=verbose,
            force=force,
            dry_run=dry_run,
        ):
            written += 1

        # -- Summary --
        click.echo()
        rule()
        click.echo()
        if dry_run:
            info(f"  {written} file(s) would be generated")
        else:
            success(f"  {_CHECK} {written} file(s) generated for '{name}'")
        click.echo()

        next_steps(
            [
                "cp .env.example .env && edit .env",
                "make docker-up                (Docker Compose)",
                "make k8s-apply                (Kubernetes)",
                "make help                     (see all targets)",
            ]
        )

        click.echo()
        section("Generated structure")

        # Build structure listing
        structure = [
            ("Dockerfile", "Production (multi-stage, BuildKit)"),
            ("Dockerfile.dev", "Development (hot-reload)"),
            (".dockerignore", "Build context exclusions"),
        ]
        if wctx.get("has_mlops"):
            structure.append(("Dockerfile.mlops", "MLOps model server"))
        structure += [
            ("docker-compose.yml", "Full service stack (profiles)"),
            ("docker-compose.dev.yml", "Dev override"),
            ("k8s/", f"Kubernetes manifests ({len(manifests)} files)"),
            ("deploy/nginx/", "Nginx reverse-proxy (TLS-ready)"),
        ]
        if monitoring:
            structure.append(("deploy/prometheus/", "Prometheus config"))
            structure.append(("deploy/grafana/", "Grafana provisioning"))
        if ci_provider in ("github", "both"):
            structure.append((".github/workflows/", "GitHub Actions pipeline"))
        if ci_provider in ("gitlab", "both"):
            structure.append((".gitlab-ci.yml", "GitLab CI/CD pipeline"))
        structure += [
            (".env.example", "Environment template"),
            ("Makefile", "Dev/deploy task runner"),
        ]

        table(
            headers=["File", "Description"],
            rows=[(f, d) for f, d in structure],
            col_widths=[28, 40],
        )

    except Exception as e:
        error(f"  {_CROSS} Full deployment generation failed: {e}")
        sys.exit(1)


# ═══════════════════════════════════════════════════════════════════════════
# aq deploy makefile
# ═══════════════════════════════════════════════════════════════════════════


@deploy_gen_group.command("makefile")
@click.option("--output", "-o", type=click.Path(), default=".", help="Output directory")
@deploy_options
@click.pass_context
def deploy_makefile(ctx, output: str, force: bool, dry_run: bool):
    """
    Generate a self-documenting Makefile for dev & ops tasks.

    Includes targets for running, testing, linting, Docker build/up/down,
    Kubernetes apply/delete, database migrations, and deployment file
    generation.  Run `make help` to see all targets.

    Examples:
      aq deploy makefile
      aq deploy makefile --force
    """
    from ..generators.deployment import MakefileGenerator

    workspace_root = Path.cwd()
    out = Path(output)
    verbose = ctx.obj.get("verbose", False)
    force = force or ctx.obj.get("force", False)
    dry_run = dry_run or ctx.obj.get("dry_run", False)

    try:
        wctx = _get_ctx(workspace_root)
        action = "DRY RUN" if dry_run else "Generating"
        section(f"{action}: Makefile for '{wctx['name']}'")

        gen = MakefileGenerator(wctx)
        _write_file(
            out / "Makefile", gen.generate_makefile(), label="Makefile", verbose=verbose, force=force, dry_run=dry_run
        )

        click.echo()
        next_steps(
            [
                "make help          # see all available targets",
                "make dev           # start dev server",
                "make docker-up     # bring up compose stack",
            ]
        )

    except Exception as e:
        error(f"  {_CROSS} Makefile generation failed: {e}")
        sys.exit(1)


# ═══════════════════════════════════════════════════════════════════════════
# aq deploy render — One-command PaaS deployment
# ═══════════════════════════════════════════════════════════════════════════


@deploy_gen_group.command("render")
@click.option("--image", "-i", type=str, default=None, help="Docker image to deploy (e.g. registry/myapp:latest)")
@click.option(
    "--region", "-r", type=str, default=None, help="Deployment region (oregon, frankfurt, ohio, virginia, singapore)"
)
@click.option(
    "--plan",
    type=click.Choice(
        [
            "free",
            "starter",
            "standard",
            "pro",
            "pro_plus",
            "pro_max",
            "pro_ultra",
        ]
    ),
    default=None,
    help="Render plan",
)
@click.option("--num-instances", type=int, default=None, help="Number of instances")
@click.option("--service-name", type=str, default=None, help="Render service name (default: workspace name)")
@click.option("--destroy", is_flag=True, help="Destroy the deployed service")
@click.option("--status", "show_status", is_flag=True, help="Show deployment status")
@deploy_options
@click.pass_context
def deploy_render(
    ctx,
    image: str | None,
    region: str | None,
    plan: str | None,
    num_instances: int | None,
    service_name: str | None,
    destroy: bool,
    show_status: bool,
    force: bool,
    dry_run: bool,
):
    """Deploy to Render PaaS with a single command.

    Builds your Docker image, pushes it, creates the Render service,
    syncs env vars, and waits for the deployment to go live.

    Requires authentication first:
      aq provider login render

    \\b
    Examples:
      aq deploy render                                # Interactive deploy
      aq deploy render --image ghcr.io/me/app:v1      # Deploy specific image
      aq deploy render --region frankfurt --plan pro   # Frankfurt, pro plan
      aq deploy render --num-instances 3               # 3 instances
      aq deploy render --status                        # Check deployment status
      aq deploy render --destroy                       # Tear down service
      aq deploy render --dry-run                       # Preview without deploying
    """
    from aquilia.providers.render.client import RenderClient
    from aquilia.providers.render.deployer import RenderDeployer
    from aquilia.providers.render.store import RenderCredentialStore
    from aquilia.providers.render.types import (
        RenderDeployConfig,
        RenderPlan,
    )

    workspace_root = Path.cwd()
    dry_run = dry_run or ctx.obj.get("dry_run", False)
    force = force or ctx.obj.get("force", False)

    # ── Auth gate ────────────────────────────────────────────────────
    store = RenderCredentialStore()
    if not store.is_configured():
        error(f"  {_CROSS} Not authenticated with Render.")
        info("  Run: aq provider login render")
        sys.exit(1)

    token = store.load()
    if not token:
        error(f"  {_CROSS} Could not decrypt Render credentials.")
        info("  Re-authenticate: aq provider login render")
        sys.exit(1)

    client = RenderClient(token=token)

    # ── Introspect workspace ─────────────────────────────────────────
    try:
        wctx = _get_ctx(workspace_root)
    except Exception as e:
        error(f"  {_CROSS} Workspace introspection failed: {e}")
        sys.exit(1)

    ws_name = service_name or wctx.get("name", "aquilia-app")

    # ── Status mode ──────────────────────────────────────────────────
    if show_status:
        _render_show_status(client, wctx, ws_name)
        return

    # ── Destroy mode ─────────────────────────────────────────────────
    if destroy:
        _render_destroy(client, ws_name)
        return

    # ── Configure deployment ─────────────────────────────────────────
    banner("Deploy to Render", subtitle=f"Service: {ws_name}", icon=_ROCKET, fg="magenta")
    click.echo()

    # Resolve image name
    if not image:
        interactive = sys.stdin.isatty()
        if interactive:
            image = ask(
                "Docker image",
                default=f"docker.io/{ws_name}:latest",
                hint="registry/name:tag",
            )
        else:
            image = f"docker.io/{ws_name}:latest"

    # Resolve region
    if not region:
        stored_region = store.get_default_region()
        if interactive:
            region = select(
                "Deployment region",
                [
                    ("oregon", "Oregon (US West)"),
                    ("frankfurt", "Frankfurt (EU)"),
                    ("ohio", "Ohio (US East)"),
                    ("virginia", "Virginia (US East)"),
                    ("singapore", "Singapore (Asia)"),
                ],
                default=["oregon", "frankfurt", "ohio", "virginia", "singapore"].index(stored_region)
                if stored_region in ["oregon", "frankfurt", "ohio", "virginia", "singapore"]
                else 0,
            )
        else:
            region = stored_region

    # Resolve plan
    render_plan = RenderPlan.STARTER
    if plan:
        try:
            render_plan = RenderPlan(plan)
        except ValueError:
            render_plan = RenderPlan.STARTER
    elif interactive:
        plan_choice = select(
            "Render plan",
            [
                ("free", "Free (shared CPU, 512MB RAM)"),
                ("starter", "Starter (0.5 CPU, 512MB RAM)"),
                ("standard", "Standard (1 CPU, 2GB RAM)"),
                ("pro", "Pro (2 CPU, 4GB RAM)"),
                ("pro_plus", "Pro Plus (4 CPU, 8GB RAM)"),
            ],
            default=1,
        )
        try:
            render_plan = RenderPlan(plan_choice)
        except ValueError:
            render_plan = RenderPlan.STARTER

    # Resolve instances
    instances = num_instances or 1
    if not num_instances and interactive:
        instances = int(ask("Number of instances", default="1"))

    # ── Build deployment config ──────────────────────────────────────
    config = RenderDeployConfig.from_workspace_context(
        wctx,
        image=image,
        region=region,
        plan=render_plan,
        num_instances=instances,
    )
    config.service_name = ws_name

    # ── Review ───────────────────────────────────────────────────────
    click.echo()
    detail_card(
        "Deployment Configuration",
        [
            ("Service", config.service_name),
            ("Image", config.image),
            ("Region", config.region),
            ("Plan", config.plan.value),
            ("Instances", str(config.num_instances)),
            ("Port", str(config.port)),
            ("Health check", config.health_check_path),
            ("Env vars", str(len(config.env_vars))),
        ],
        icon=_ROCKET,
        fg="magenta",
    )
    click.echo()

    generated_vars = [v for v in config.env_vars if v.generate_value == "yes"]
    if generated_vars:
        section(f"Auto-generated secrets ({len(generated_vars)})")
        for gv in generated_vars:
            status_line(_KEY, gv.key, "auto-generated", value_fg="yellow")
        click.echo()

    if interactive and not force and not confirm("Deploy to Render?", default=True):
        info("  Cancelled.")
        return

    # ── Execute deployment ───────────────────────────────────────────
    click.echo()
    rule()
    banner(
        f"Deploying: {ws_name}",
        subtitle="DRY RUN" if dry_run else "Executing deployment pipeline",
        icon=_BOLT,
        fg="cyan",
    )
    click.echo()

    def on_step(phase: str, message: str):
        if phase == "done":
            success(f"  {_CHECK} {message}")
        elif "failed" in message.lower() or "error" in message.lower():
            error(f"  {_CROSS} {message}")
        else:
            status_line(_GEAR, phase, message)

    deployer = RenderDeployer(
        client=client,
        workspace_root=workspace_root,
        config=config,
        on_step=on_step,
        dry_run=dry_run,
    )

    result = deployer.deploy()

    click.echo()
    rule()
    click.echo()

    if result.success:
        success(f"  {_CHECK} Deployment successful! {_SPARK}")
        if result.url:
            click.echo()
            detail_card(
                "Live",
                [("URL", result.url)],
                icon=_GLOBE,
                fg="green",
            )
        click.echo()
        next_steps(
            [
                "aq deploy render --status            # Check deployment status",
                f"aq provider render env set ... -s {ws_name}  # Add env vars",
                "aq deploy render --destroy           # Tear down",
            ]
        )
    else:
        error(f"  {_CROSS} Deployment failed.")
        if result.errors:
            click.echo()
            for err in result.errors:
                error(f"    {_CROSS} {err}")
        click.echo()
        next_steps(
            [
                "Check the error messages above",
                "Verify your Dockerfile builds successfully: docker build .",
                "Check Render dashboard: https://dashboard.render.com",
            ]
        )
        if not dry_run:
            sys.exit(1)


def _render_show_status(client, wctx: dict, service_name: str) -> None:
    """Show deployment status for the Render service."""
    from aquilia.providers.render.deployer import RenderDeployer
    from aquilia.providers.render.types import RenderDeployConfig

    config = RenderDeployConfig(service_name=service_name)
    deployer = RenderDeployer(client, Path.cwd(), config)
    status = deployer.status()

    click.echo()
    banner(f"Render · {service_name}", subtitle="Deployment status", icon=_EYE, fg="cyan")
    click.echo()

    if status["status"] == "not_deployed":
        info(f"  {_ARROW} Service not found on Render.")
        click.echo()
        next_steps(["aq deploy render  # Deploy your workspace"])
        return

    if status["status"] == "error":
        error(f"  {_CROSS} {status.get('error', 'Unknown error')}")
        return

    # Status badge
    svc_status = status.get("service_status", "unknown")
    if svc_status in ("live", "deployed"):
        st_display = click.style(f"● {svc_status}", fg="green")
    elif svc_status in ("deploying", "building"):
        st_display = click.style(f"● {svc_status}", fg="cyan")
    elif svc_status in ("failed", "error"):
        st_display = click.style(f"● {svc_status}", fg="red")
    else:
        st_display = click.style(f"○ {svc_status}", fg="yellow")

    detail_card(
        "Service",
        [
            ("Status", st_display),
            ("Service ID", status.get("service_id", "—")),
            ("Plan", status.get("plan", "—")),
            ("Region", status.get("region", "—")),
            ("Suspended", status.get("suspended", "—")),
            ("URL", status.get("url", "—")),
        ],
        icon=_CLOUD,
    )

    latest = status.get("latest_deploy")
    if latest:
        click.echo()
        deploy_status = latest.get("status", "unknown")
        if deploy_status in ("live", "deployed"):
            ds = click.style(f"● {deploy_status}", fg="green")
        elif deploy_status in ("building", "deploying"):
            ds = click.style(f"● {deploy_status}", fg="cyan")
        else:
            ds = click.style(f"○ {deploy_status}", fg="yellow")

        detail_card(
            "Latest Deploy",
            [
                ("Deploy ID", latest.get("id", "—")),
                ("Status", ds),
                ("Created", latest.get("created_at", "—")),
            ],
            icon=_ROCKET,
            fg="green",
        )
    click.echo()


def _render_destroy(client, service_name: str) -> None:
    """Destroy a deployed Render service."""
    from aquilia.providers.render.deployer import RenderDeployer
    from aquilia.providers.render.types import RenderDeployConfig

    click.echo()
    banner(f"Destroy · {service_name}", subtitle="Permanently delete service and all resources", icon=_WARN, fg="red")
    click.echo()

    detail_card(
        "Danger Zone",
        [
            ("Service", service_name),
            ("Action", "Permanently delete"),
            ("Deploys", "All removed"),
            ("Reversible", "No"),
        ],
        icon=_WARN,
        fg="red",
    )
    click.echo()

    if not confirm(f"Destroy '{service_name}'?", default=False):
        info(f"  {_ARROW} Cancelled.")
        return

    config = RenderDeployConfig(service_name=service_name)
    deployer = RenderDeployer(client, Path.cwd(), config)

    if deployer.destroy():
        click.echo()
        success(f"  {_CHECK} Service '{service_name}' destroyed.")
    else:
        click.echo()
        error(f"  {_CROSS} Failed to destroy service.")
        sys.exit(1)
