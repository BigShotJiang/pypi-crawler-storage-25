"""Storage adapter implementations."""
