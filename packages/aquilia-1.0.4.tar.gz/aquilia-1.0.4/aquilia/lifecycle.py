"""
Lifecycle Coordinator - Orchestrates startup and shutdown hooks.

This module manages the application lifecycle, ensuring that hooks are called
in the correct order (following dependency graph) with proper error handling
and rollback capabilities.
"""

import inspect
import logging
from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum
from typing import Any, Protocol, cast

logger = logging.getLogger("aquilia.lifecycle")


class _AppContextLike(Protocol):
    name: str
    on_startup: Callable[..., Any] | None
    on_shutdown: Callable[..., Any] | None
    config_namespace: dict[str, Any] | None


class _RuntimeMetaLike(Protocol):
    app_contexts: list[_AppContextLike]


class _RuntimeLike(Protocol):
    meta: _RuntimeMetaLike
    di_containers: dict[str, Any]


class _ConfigLike(Protocol):
    def get(self, key: str, default: Any = None) -> Any: ...

    def to_dict(self) -> dict[str, Any]: ...


class LifecyclePhase(Enum):
    """Lifecycle phases."""

    INIT = "init"
    STARTING = "starting"
    READY = "ready"
    STOPPING = "stopping"
    STOPPED = "stopped"
    ERROR = "error"


@dataclass
class LifecycleEvent:
    """Event emitted during lifecycle transitions."""

    phase: LifecyclePhase
    app_name: str | None = None
    message: str | None = None
    error: Exception | None = None


class LifecycleError(Exception):
    """Raised when lifecycle operation fails."""

    pass


class LifecycleCoordinator:
    """
    Coordinates application lifecycle across multiple apps.

    Responsibilities:
    - Execute startup hooks in dependency order
    - Execute shutdown hooks in reverse order
    - Handle errors and perform rollback
    - Track lifecycle state
    - Emit lifecycle events
    """

    def __init__(self, runtime: Any, config: _ConfigLike | None = None):
        """
        Initialize coordinator.

        Args:
            runtime: RuntimeRegistry with app_contexts
            config: Optional config for hook parameters
        """
        self.runtime = runtime
        self.config = config
        self.phase = LifecyclePhase.INIT
        self.started_apps: list[str] = []
        self.event_handlers: list[Callable[[LifecycleEvent], None]] = []
        self.logger = logger

    def on_event(self, handler: Callable[[LifecycleEvent], None]):
        """
        Register event handler.

        Args:
            handler: Callable that receives LifecycleEvent
        """
        self.event_handlers.append(handler)

    def _emit_event(self, event: LifecycleEvent):
        """Emit lifecycle event to all handlers."""
        for handler in self.event_handlers:
            try:
                handler(event)
            except Exception as e:
                self.logger.error(f"Event handler error: {e}")

    async def startup(self):
        """
        Execute startup hooks for all apps in dependency order.

        Raises:
            LifecycleError: If any startup hook fails
        """
        if self.phase != LifecyclePhase.INIT:
            raise LifecycleError(f"Cannot start from phase {self.phase.value}. Must be in INIT phase.")

        self.phase = LifecyclePhase.STARTING
        self._emit_event(LifecycleEvent(LifecyclePhase.STARTING))

        try:
            base_container = next(iter(self.runtime.di_containers.values()), None)

            # 1. Execute global workspace-level startup hook if present
            global_startup = self.config.get("on_startup") if self.config else None
            if global_startup:
                hook = self._resolve_hook(global_startup)
                if hook:
                    if inspect.iscoroutinefunction(hook):
                        await hook(self.config.to_dict() if self.config else {}, base_container)
                    else:
                        hook(self.config.to_dict() if self.config else {}, base_container)

            # 2. Execute app-level hooks
            # Apps are already in topological order from registry
            for ctx in self.runtime.meta.app_contexts:
                await self._startup_app(ctx)

            self.phase = LifecyclePhase.READY
            self._emit_event(LifecycleEvent(LifecyclePhase.READY))

        except Exception as e:
            self.phase = LifecyclePhase.ERROR
            self._emit_event(LifecycleEvent(LifecyclePhase.ERROR, message="Startup failed", error=e))
            self.logger.error(f"Startup failed: {e}")

            # Rollback - shutdown already started apps
            await self.shutdown()

            raise LifecycleError(f"Startup failed: {e}") from e

    async def _startup_app(self, ctx: _AppContextLike):
        """
        Execute startup hook for a single app.

        Args:
            ctx: AppContext with on_startup hook
        """
        app_name = ctx.name

        if ctx.on_startup is None:
            # No startup hook - skip
            self.started_apps.append(app_name)
            return

        try:
            # Get config namespace for this app
            config_ns = ctx.config_namespace or {}

            # Get DI container for this app
            di_container = self.runtime.di_containers.get(app_name)

            # Start DI container (runs provider startup hooks)
            if di_container and hasattr(di_container, "startup"):
                await di_container.startup()

            # Call startup hook
            hook = ctx.on_startup
            if inspect.iscoroutinefunction(hook):
                await hook(config_ns, di_container)
            else:
                hook(config_ns, di_container)

            self.started_apps.append(app_name)
            self._emit_event(LifecycleEvent(LifecyclePhase.STARTING, app_name=app_name, message=f"{app_name} started"))

        except Exception as e:
            self.logger.error(f"     {app_name} startup failed: {e}")
            raise LifecycleError(f"Startup failed for app '{app_name}': {e}") from e

    async def shutdown(self):
        """
        Execute shutdown hooks for all started apps in reverse order.

        Does not raise exceptions - logs errors and continues cleanup.
        """
        if self.phase == LifecyclePhase.STOPPED:
            return

        self.phase = LifecyclePhase.STOPPING
        self._emit_event(LifecycleEvent(LifecyclePhase.STOPPING))

        # 1. Shutdown in reverse order
        for app_name in reversed(self.started_apps):
            await self._shutdown_app(app_name)

        # 2. Execute global workspace-level shutdown hook if present
        global_shutdown = self.config.get("on_shutdown") if self.config else None
        if global_shutdown:
            try:
                base_container = next(iter(self.runtime.di_containers.values()), None)
                hook = self._resolve_hook(global_shutdown)
                if hook:
                    if inspect.iscoroutinefunction(hook):
                        await hook(self.config.to_dict() if self.config else {}, base_container)
                    else:
                        hook(self.config.to_dict() if self.config else {}, base_container)
            except Exception as e:
                self.logger.error(f"Global shutdown hook error: {e}")

        self.phase = LifecyclePhase.STOPPED
        self._emit_event(LifecycleEvent(LifecyclePhase.STOPPED))

    async def _shutdown_app(self, app_name: str):
        """
        Execute shutdown hook for a single app.

        Args:
            app_name: Name of app to shutdown
        """
        # Find app context
        ctx = next((c for c in self.runtime.meta.app_contexts if c.name == app_name), None)

        if ctx is None or ctx.on_shutdown is None:
            return

        try:
            # Get config namespace
            config_ns = ctx.config_namespace or {}

            # Get DI container
            di_container = self.runtime.di_containers.get(app_name)

            # Call shutdown hook
            hook = ctx.on_shutdown
            if inspect.iscoroutinefunction(hook):
                await hook(config_ns, di_container)
            else:
                hook(config_ns, di_container)

            self._emit_event(LifecycleEvent(LifecyclePhase.STOPPING, app_name=app_name, message=f"{app_name} stopped"))

        except Exception as e:
            # Log but don't raise - continue cleanup
            self.logger.error(f"     {app_name} shutdown error: {e}")
            self._emit_event(
                LifecycleEvent(
                    LifecyclePhase.STOPPING, app_name=app_name, message=f"{app_name} shutdown error", error=e
                )
            )

    async def restart(self):
        """Restart the application (shutdown then startup)."""
        await self.shutdown()
        self.phase = LifecyclePhase.INIT
        self.started_apps.clear()
        await self.startup()

    def get_status(self) -> dict[str, Any]:
        """
        Get current lifecycle status.

        Returns:
            Status dict with phase and started apps
        """
        return {
            "phase": self.phase.value,
            "started_apps": self.started_apps.copy(),
            "total_apps": len(self.runtime.meta.app_contexts),
        }

    def _resolve_hook(self, hook: Any) -> Callable[..., Any] | None:
        """Resolve hook string or return callable."""
        if hook is None:
            return None
        if callable(hook):
            return cast(Callable[..., Any], hook)

        if not isinstance(hook, str):
            return None

        import importlib

        try:
            if ":" in hook:
                mod_path, func_name = hook.split(":", 1)
            else:
                mod_path, func_name = hook.rsplit(".", 1)

            module = importlib.import_module(mod_path)
            resolved = getattr(module, func_name)
            if callable(resolved):
                return cast(Callable[..., Any], resolved)
            self.logger.error(f"Resolved lifecycle hook '{hook}' is not callable")
            return None
        except (ImportError, AttributeError, ValueError) as e:
            self.logger.error(f"Failed to resolve lifecycle hook '{hook}': {e}")
            return None


class LifecycleManager:
    """
    High-level lifecycle manager with context manager support.

    Usage:
        async with LifecycleManager(runtime, config) as manager:
            # Apps are started
            await run_server()
        # Apps automatically shutdown
    """

    def __init__(self, runtime: Any, config: _ConfigLike | None = None):
        """
        Initialize manager.

        Args:
            runtime: RuntimeRegistry
            config: Optional config
        """
        self.coordinator = LifecycleCoordinator(runtime, config)

    async def __aenter__(self):
        """Start lifecycle on context entry."""
        await self.coordinator.startup()
        return self.coordinator

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Stop lifecycle on context exit."""
        await self.coordinator.shutdown()
        return False  # Don't suppress exceptions

    def on_event(self, handler: Callable[[LifecycleEvent], None]):
        """Register event handler."""
        self.coordinator.on_event(handler)
        return self


def create_lifecycle_coordinator(runtime: Any, config: Any = None) -> LifecycleCoordinator:
    """
    Factory function to create lifecycle coordinator.

    Args:
        runtime: RuntimeRegistry with app_contexts
        config: Optional config

    Returns:
        Configured LifecycleCoordinator
    """
    return LifecycleCoordinator(runtime, config)
