"""
Template Engine - Core async-capable Jinja2 template rendering engine.

Provides:
- Async rendering with streaming support
- Bytecode caching for performance
- Sandboxed execution by default
- Framework-aware context injection
- Response integration
"""

from collections.abc import AsyncIterator, Callable, Mapping
from typing import TYPE_CHECKING, Any, Optional

from jinja2 import Template

from .bytecode_cache import BytecodeCache, InMemoryBytecodeCache
from .context import create_template_context
from .extensions import StaticTagExtension
from .loader import TemplateLoader
from .security import SandboxPolicy, TemplateSandbox, create_safe_filters, create_safe_globals

if TYPE_CHECKING:
    from aquilia.controller.base import RequestCtx
    from aquilia.response import Response


class TemplateEngine:
    """
    Async-capable Jinja2 template engine.

    Features:
    - Sandboxed execution with security policies
    - Bytecode caching for performance
    - Async rendering and streaming
    - Framework context injection
    - Response integration

    Args:
        loader: Template loader
        bytecode_cache: Bytecode cache (default: in-memory)
        autoescape: Enable HTML autoescaping
        sandbox: Enable sandbox (recommended)
        sandbox_policy: Security policy for sandbox
        globals: Custom global variables/functions
        filters: Custom filters
        tests: Custom tests
        extensions: Jinja2 extensions to enable

    Example:
        loader = TemplateLoader(["/path/to/templates"])
        engine = TemplateEngine(loader)

        html = await engine.render("profile.html", {"user": user})
        response = engine.render_to_response("profile.html", {"user": user})
    """

    def __init__(
        self,
        loader: TemplateLoader,
        *,
        bytecode_cache: BytecodeCache | None = None,
        autoescape: bool = True,
        sandbox: bool = True,
        sandbox_policy: SandboxPolicy | None = None,
        globals: dict[str, Any] | None = None,
        filters: dict[str, Callable] | None = None,
        tests: dict[str, Callable] | None = None,
        extensions: list | None = None,
        enable_async: bool = True,
    ):
        self.loader = loader
        self.bytecode_cache = bytecode_cache or InMemoryBytecodeCache()
        self.sandbox = sandbox
        extension_list = self._with_default_extensions(extensions)

        # Create sandbox if enabled
        if sandbox:
            self._sandbox = TemplateSandbox(policy=sandbox_policy or SandboxPolicy.strict())

            # Register custom filters
            safe_filters = create_safe_filters()
            for name, func in safe_filters.items():
                self._sandbox.register_filter(name, func)

            if filters:
                for name, func in filters.items():
                    self._sandbox.register_filter(name, func)

            # Register custom tests
            if tests:
                for name, func in tests.items():
                    self._sandbox.register_test(name, func)

            # Register custom globals
            safe_globals = create_safe_globals()
            for name, value in safe_globals.items():
                self._sandbox.register_global(name, value)

            if globals:
                for name, value in globals.items():
                    self._sandbox.register_global(name, value)

            # Create sandboxed environment
            self.env = self._sandbox.create_environment(
                loader=self.loader,
                bytecode_cache=self.bytecode_cache,
                extensions=extension_list,
                enable_async=enable_async,
            )
        else:
            # Create standard environment
            from jinja2 import Environment, select_autoescape

            self.env = Environment(
                loader=self.loader,
                bytecode_cache=self.bytecode_cache,
                autoescape=select_autoescape(
                    enabled_extensions=["html", "htm", "xml"],
                    default_for_string=True,
                )
                if autoescape
                else False,
                extensions=extension_list,
                enable_async=enable_async,
            )

            # Register custom filters
            if filters:
                self.env.filters.update(filters)

            # Register custom tests
            if tests:
                self.env.tests.update(tests)

            # Register custom globals
            if globals:
                self.env.globals.update(globals)

        # Default URL fallbacks used by helpers and template tags.
        self.env.aquilia_static_prefix = "/static"
        self.env.aquilia_media_prefix = "/media"
        if "static" not in self.env.globals:
            self.env.globals["static"] = self._default_static_url
        if "static_url" not in self.env.globals:
            self.env.globals["static_url"] = self._default_static_url
        if "asset" not in self.env.globals:
            self.env.globals["asset"] = self._default_asset_url
        if "asset_url" not in self.env.globals:
            self.env.globals["asset_url"] = self._default_asset_url
        if "media" not in self.env.globals:
            self.env.globals["media"] = self._default_media_url
        if "media_url" not in self.env.globals:
            self.env.globals["media_url"] = self._default_media_url

        # Template cache (in addition to bytecode cache)
        self._template_cache: dict[str, Template] = {}
        self._cache_enabled = True

    def _with_default_extensions(self, extensions: list | None) -> list:
        """Ensure Aquilia's core template extensions are always enabled."""
        ext_list = list(extensions or [])
        if StaticTagExtension not in ext_list and "aquilia.templates.extensions.StaticTagExtension" not in ext_list:
            ext_list.append(StaticTagExtension)
        return ext_list

    @staticmethod
    def _default_static_url(path: Any) -> str:
        return TemplateEngine._default_prefixed_url("/static", path)

    @staticmethod
    def _default_asset_url(path: Any) -> str:
        return TemplateEngine._default_prefixed_url("/static", path)

    @staticmethod
    def _default_media_url(path: Any) -> str:
        return TemplateEngine._default_prefixed_url("/media", path)

    @staticmethod
    def _default_prefixed_url(prefix: str, path: Any) -> str:
        normalized = "" if path is None else str(path).lstrip("/")
        return f"{prefix}/{normalized}"

    async def render(
        self, template_name: str, context: Mapping[str, Any] | None = None, request_ctx: Optional["RequestCtx"] = None
    ) -> str:
        """
        Render template asynchronously.

        Args:
            template_name: Template name (namespace-aware)
            context: Template variables
            request_ctx: Request context (for injecting request/session/identity)

        Returns:
            Rendered HTML string

        Raises:
            TemplateNotFound: If template doesn't exist
            TemplateSyntaxError: If template has syntax errors
        """
        # Build template context
        template_context = create_template_context(
            user_context=dict(context) if context else None, request_ctx=request_ctx
        )

        # Get template
        template = self.get_template(template_name)

        # Render async
        rendered = await template.render_async(**template_context.to_dict())

        return rendered

    def render_sync(
        self, template_name: str, context: Mapping[str, Any] | None = None, request_ctx: Optional["RequestCtx"] = None
    ) -> str:
        """
        Render template synchronously.

        Use only when async not available. Prefer async render().
        """
        # Build template context
        template_context = create_template_context(
            user_context=dict(context) if context else None, request_ctx=request_ctx
        )

        # Get template
        template = self.get_template(template_name)

        # Render sync
        return template.render(**template_context.to_dict())

    async def stream(
        self, template_name: str, context: Mapping[str, Any] | None = None, request_ctx: Optional["RequestCtx"] = None
    ) -> AsyncIterator[bytes]:
        """
        Stream template rendering.

        Yields chunks of rendered content as bytes for streaming responses.

        Args:
            template_name: Template name
            context: Template variables
            request_ctx: Request context

        Yields:
            Chunks of rendered content as bytes
        """
        # Build template context
        template_context = create_template_context(
            user_context=dict(context) if context else None, request_ctx=request_ctx
        )

        # Get template
        template = self.get_template(template_name)

        # Generate async
        async for chunk in template.generate_async(**template_context.to_dict()):
            yield chunk.encode("utf-8")

    async def render_to_response(
        self,
        template_name: str,
        context: Mapping[str, Any] | None = None,
        *,
        status: int = 200,
        headers: dict[str, str] | None = None,
        content_type: str = "text/html; charset=utf-8",
        request_ctx: Optional["RequestCtx"] = None,
    ) -> "Response":
        """
        Render template and return Response object.

        Convenience method for controller integration.

        Args:
            template_name: Template name
            context: Template variables
            status: HTTP status code
            headers: Additional headers
            content_type: Content-Type header
            request_ctx: Request context

        Returns:
            Response object with rendered content
        """
        # Import here to avoid circular dependency
        from aquilia.response import Response

        # Render the template
        html_content = await self.render(template_name, context, request_ctx)

        # Create response with rendered content
        return Response(content=html_content, status=status, headers=headers, media_type=content_type)

    def template_stream_response(
        self,
        template_name: str,
        context: Mapping[str, Any] | None = None,
        *,
        status: int = 200,
        headers: dict[str, str] | None = None,
        content_type: str = "text/html; charset=utf-8",
        request_ctx: Optional["RequestCtx"] = None,
    ) -> "Response":
        """
        Render template as streaming response.

        Args:
            template_name: Template name
            context: Template variables
            status: HTTP status code
            headers: Additional headers
            content_type: Content-Type header
            request_ctx: Request context

        Returns:
            Response object with streaming content
        """
        from aquilia.response import Response

        return Response.stream(self.stream(template_name, context, request_ctx), media_type=content_type)

    def get_template(self, name: str) -> Template:
        """
        Get template by name.

        Uses template cache for performance.

        Args:
            name: Template name

        Returns:
            Jinja2 Template object
        """
        if self._cache_enabled and name in self._template_cache:
            return self._template_cache[name]

        template = self.env.get_template(name)

        if self._cache_enabled:
            self._template_cache[name] = template

        return template

    def invalidate_cache(self, template_name: str | None = None) -> None:
        """
        Invalidate template cache.

        Args:
            template_name: Specific template to invalidate (None = all)
        """
        if template_name:
            self._template_cache.pop(template_name, None)

            # Also invalidate bytecode cache
            if hasattr(self.bytecode_cache, "invalidate"):
                self.bytecode_cache.invalidate(template_name)
        else:
            self._template_cache.clear()
            self.bytecode_cache.clear()

    def list_templates(self) -> list[str]:
        """
        List all available templates.

        Returns:
            List of template names
        """
        return self.loader.list_templates()

    def register_filter(self, name: str, func: Callable) -> None:
        """
        Register custom filter.

        Args:
            name: Filter name
            func: Filter function
        """
        if self.sandbox:
            self._sandbox.register_filter(name, func)
        self.env.filters[name] = func

    def register_test(self, name: str, func: Callable) -> None:
        """
        Register custom test.

        Args:
            name: Test name
            func: Test function
        """
        if self.sandbox:
            self._sandbox.register_test(name, func)
        self.env.tests[name] = func

    def register_global(self, name: str, value: Any) -> None:
        """
        Register global variable/function.

        Args:
            name: Global name
            value: Global value
        """
        if self.sandbox:
            self._sandbox.register_global(name, value)
        self.env.globals[name] = value
