"""Assemble captured media into a spec-compliant vCon JSON object."""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

from vcon_laptop.capture.audio import CapturedAudio
from vcon_laptop.capture.screenshot import CapturedScreenshot
from vcon_laptop.capture.video import CapturedVideo
from vcon_laptop.config import Config

log = logging.getLogger(__name__)

VCON_VERSION = "0.0.1"


def _sha512_hash(filepath: Path) -> str:
    """Compute sha512-base64url content hash per the vCon spec."""
    h = hashlib.sha512()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    digest_b64url = base64.urlsafe_b64encode(h.digest()).decode().rstrip("=")
    return f"sha512-{digest_b64url}"


def _file_to_base64url(filepath: Path) -> str:
    with open(filepath, "rb") as f:
        return base64.urlsafe_b64encode(f.read()).decode()


def _file_url(filepath: Path) -> str:
    return filepath.resolve().as_uri()


def build_vcon(
    config: Config,
    session_id: str,
    session_start: str,
    screenshots: List[CapturedScreenshot] | None = None,
    audio: CapturedAudio | None = None,
    video: CapturedVideo | None = None,
) -> Dict[str, Any]:
    """Build a complete vCon dict from captured session data.

    Follows the vCon spec (draft-ietf-vcon-vcon-core) and the patterns
    defined in vcon-speckit.
    """
    now = datetime.now(timezone.utc).isoformat()
    vcon_uuid = str(uuid.uuid4())

    # ── Party ─────────────────────────────────────────────────
    party: Dict[str, Any] = {"name": config.user_name or "anonymous"}
    if config.user_email:
        party["mailto"] = config.user_email
    if config.user_tel:
        party["tel"] = config.user_tel
    party["validation"] = "self" if config.user_name else "anonymous"

    extensions: List[str] = ["role"]
    party["role"] = "agent"

    # ── Dialogs ───────────────────────────────────────────────
    dialogs: List[Dict[str, Any]] = []

    # Screenshots
    for cap in screenshots or []:
        dialog = _screenshot_dialog(cap, config.media_storage)
        dialogs.append(dialog)

    # Audio
    if audio and audio.path.exists():
        dialogs.append(_audio_dialog(audio, config.media_storage))

    # Video
    if video and video.path.exists():
        dialogs.append(_video_dialog(video, config.media_storage))

    # ── Tags attachment ───────────────────────────────────────
    tags_body: Dict[str, Any] = {
        "source": "laptop_adapter",
        "session_id": session_id,
        "capture_sources": config.capture_sources,
        "screenshot_count": len(screenshots or []),
        "has_audio": audio is not None,
        "has_video": video is not None,
    }
    if audio:
        tags_body["audio_duration_seconds"] = round(audio.duration, 2)
    if video:
        tags_body["video_duration_seconds"] = round(video.duration, 2)
        tags_body["video_resolution"] = f"{video.width}x{video.height}"

    attachments: List[Dict[str, Any]] = [
        {
            "purpose": "tags",
            "start": session_start,
            "party": 0,
            "dialog": 0,
            "body": json.dumps(tags_body),
            "encoding": "json",
        }
    ]

    # ── Assemble ──────────────────────────────────────────────
    vcon: Dict[str, Any] = {
        "vcon": VCON_VERSION,
        "uuid": vcon_uuid,
        "created_at": session_start,
        "updated_at": now,
        "subject": f"Laptop recording session {session_id}",
        "extensions": extensions,
        "parties": [party],
        "dialog": dialogs,
        "analysis": [],
        "attachments": attachments,
    }

    return vcon


# ── Dialog helpers ────────────────────────────────────────────────


def _screenshot_dialog(cap: CapturedScreenshot, storage: str) -> Dict[str, Any]:
    dialog: Dict[str, Any] = {
        "type": "recording",
        "start": cap.timestamp,
        "parties": [0],
        "originator": 0,
        "mediatype": "image/png",
        "filename": cap.path.name,
    }
    if storage == "inline":
        dialog["body"] = _file_to_base64url(cap.path)
        dialog["encoding"] = "base64url"
    else:
        dialog["url"] = _file_url(cap.path)
        dialog["content_hash"] = _sha512_hash(cap.path)
    return dialog


def _audio_dialog(cap: CapturedAudio, storage: str) -> Dict[str, Any]:
    dialog: Dict[str, Any] = {
        "type": "recording",
        "start": cap.timestamp,
        "duration": round(cap.duration, 2),
        "parties": [0],
        "originator": 0,
        "mediatype": "audio/wav",
        "filename": cap.path.name,
    }
    if storage == "inline":
        dialog["body"] = _file_to_base64url(cap.path)
        dialog["encoding"] = "base64url"
    else:
        dialog["url"] = _file_url(cap.path)
        dialog["content_hash"] = _sha512_hash(cap.path)
    return dialog


def _video_dialog(cap: CapturedVideo, storage: str) -> Dict[str, Any]:
    dialog: Dict[str, Any] = {
        "type": "recording",
        "start": cap.timestamp,
        "duration": round(cap.duration, 2),
        "parties": [0],
        "originator": 0,
        "mediatype": "video/mp4",
        "filename": cap.path.name,
    }
    if storage == "inline":
        dialog["body"] = _file_to_base64url(cap.path)
        dialog["encoding"] = "base64url"
    else:
        dialog["url"] = _file_url(cap.path)
        dialog["content_hash"] = _sha512_hash(cap.path)
    return dialog
