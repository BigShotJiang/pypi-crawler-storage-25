"""Configuration loaded from environment / .env file."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import List

from dotenv import load_dotenv


def _bool(val: str) -> bool:
    return val.strip().lower() in ("1", "true", "yes")


def _csv(val: str) -> List[str]:
    return [v.strip() for v in val.split(",") if v.strip()]


@dataclass(frozen=True)
class Config:
    # Capture
    capture_sources: List[str] = field(default_factory=lambda: ["screenshot", "audio", "video"])
    screenshot_interval: float = 5.0
    audio_sample_rate: int = 44100
    video_fps: int = 1
    video_resolution: tuple[int, int] | None = None

    # Session
    output_directory: Path = field(default_factory=lambda: Path("./sessions"))
    max_session_duration: float = 0.0  # 0 = unlimited
    max_capture_mb: float = 0.0  # 0 = unlimited

    # Party identity
    user_name: str = ""
    user_email: str = ""
    user_tel: str = ""

    # Conserver
    conserver_url: str = ""
    conserver_api_token: str = ""
    conserver_header_name: str = "x-conserver-api-token"
    ingress_lists: List[str] = field(default_factory=list)

    # Media storage mode
    media_storage: str = "external"  # "external" | "inline"

    # Analysis — AI keys & models
    ollama_url: str = "http://localhost:11434"
    ollama_model: str = "gemma3:4b"
    anthropic_api_key: str = ""
    openai_api_key: str = ""
    analysis_model: str = "claude-sonnet-4-20250514"
    openai_vision_model: str = "gpt-4o-mini"
    whisper_model: str = "mlx-community/whisper-small-mlx"

    # Obsidian vault export
    obsidian_vault_path: str = ""
    obsidian_folder: str = "Recordings"

    @property
    def post_enabled(self) -> bool:
        return bool(self.conserver_url)

    @property
    def analysis_enabled(self) -> bool:
        """True if any AI tool is available (Ollama / mlx-whisper need no key)."""
        import os

        # Ollama and mlx-whisper work locally with no key
        if self.ollama_url:
            return True
        try:
            import mlx_whisper  # noqa: F401
            return True
        except ImportError:
            pass
        return bool(
            self.anthropic_api_key
            or self.openai_api_key
            or os.getenv("ANTHROPIC_API_KEY")
            or os.getenv("OPENAI_API_KEY")
        )

    @property
    def obsidian_enabled(self) -> bool:
        return bool(self.obsidian_vault_path)

    @property
    def screenshot_enabled(self) -> bool:
        return "screenshot" in self.capture_sources

    @property
    def audio_enabled(self) -> bool:
        return "audio" in self.capture_sources

    @property
    def video_enabled(self) -> bool:
        return "video" in self.capture_sources


def load_config(env_path: str | Path | None = None) -> Config:
    """Load configuration from environment variables, optionally from a .env file."""
    if env_path:
        load_dotenv(env_path)
    else:
        load_dotenv()  # searches CWD and parents

    resolution = os.getenv("VIDEO_RESOLUTION", "").strip()
    video_res = None
    if resolution and "x" in resolution.lower():
        parts = resolution.lower().split("x")
        video_res = (int(parts[0]), int(parts[1]))

    return Config(
        capture_sources=_csv(os.getenv("CAPTURE_SOURCES", "screenshot,audio,video")),
        screenshot_interval=float(os.getenv("SCREENSHOT_INTERVAL", "5")),
        audio_sample_rate=int(os.getenv("AUDIO_SAMPLE_RATE", "44100")),
        video_fps=int(os.getenv("VIDEO_FPS", "1")),
        video_resolution=video_res,
        output_directory=Path(os.getenv("OUTPUT_DIRECTORY", "./sessions")),
        max_session_duration=float(os.getenv("MAX_SESSION_DURATION", "0")),
        max_capture_mb=float(os.getenv("MAX_CAPTURE_MB", "0")),
        user_name=os.getenv("USER_NAME", ""),
        user_email=os.getenv("USER_EMAIL", ""),
        user_tel=os.getenv("USER_TEL", ""),
        conserver_url=os.getenv("CONSERVER_URL", ""),
        conserver_api_token=os.getenv("CONSERVER_API_TOKEN", ""),
        conserver_header_name=os.getenv("CONSERVER_HEADER_NAME", "x-conserver-api-token"),
        ingress_lists=_csv(os.getenv("INGRESS_LISTS", "")),
        media_storage=os.getenv("MEDIA_STORAGE", "external"),
        ollama_url=os.getenv("OLLAMA_URL", "http://localhost:11434"),
        ollama_model=os.getenv("OLLAMA_MODEL", "gemma3:4b"),
        anthropic_api_key=os.getenv("ANTHROPIC_API_KEY", ""),
        openai_api_key=os.getenv("OPENAI_API_KEY", ""),
        analysis_model=os.getenv("ANALYSIS_MODEL", "claude-sonnet-4-20250514"),
        openai_vision_model=os.getenv("OPENAI_VISION_MODEL", "gpt-4o-mini"),
        whisper_model=os.getenv("WHISPER_MODEL", "mlx-community/whisper-small-mlx"),
        obsidian_vault_path=os.getenv("OBSIDIAN_VAULT_PATH", ""),
        obsidian_folder=os.getenv("OBSIDIAN_FOLDER", "Recordings"),
    )
