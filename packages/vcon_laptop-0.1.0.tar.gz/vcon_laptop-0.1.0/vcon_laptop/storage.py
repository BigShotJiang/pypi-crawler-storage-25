"""Save a vCon dict to disk as JSON."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict

log = logging.getLogger(__name__)


def save_vcon(vcon: Dict[str, Any], session_dir: Path) -> Path:
    """Write the vCon JSON to ``<session_dir>/session.vcon.json`` and return the path."""
    session_dir.mkdir(parents=True, exist_ok=True)
    path = session_dir / "session.vcon.json"
    with open(path, "w", encoding="utf-8") as f:
        json.dump(vcon, f, indent=2, ensure_ascii=False)
    log.debug("Wrote vCon (%d bytes) to %s", path.stat().st_size, path)
    return path
