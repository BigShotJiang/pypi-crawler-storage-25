"""CLI entry point for vcon-laptop."""

from __future__ import annotations

import argparse
import logging
import signal
import threading

from vcon_laptop.config import load_config
from vcon_laptop.session import Session

log = logging.getLogger("vcon_laptop")

_shutdown = threading.Event()


def _on_signal(signum: int, _frame: object) -> None:
    name = signal.Signals(signum).name
    log.info("Received %s — stopping session", name)
    _shutdown.set()


def _wait_for_any(*events: threading.Event, timeout: float | None = None) -> None:
    """Block until any of *events* is set, or *timeout* elapses."""
    # Poll at 0.25 s — fast enough to feel responsive
    elapsed = 0.0
    step = 0.25
    while True:
        for ev in events:
            if ev.is_set():
                return
        if timeout is not None and elapsed >= timeout:
            return
        _shutdown.wait(step)
        if _shutdown.is_set():
            return
        elapsed += step


def cli() -> None:
    parser = argparse.ArgumentParser(
        prog="vcon-laptop",
        description="Record laptop activity (screenshots, audio, webcam) into a vCon.",
    )
    parser.add_argument("--env", default=None, help="Path to .env file (default: auto-discover)")
    parser.add_argument(
        "--sources",
        default=None,
        help="Override CAPTURE_SOURCES (comma-separated: screenshot,audio,video)",
    )
    parser.add_argument(
        "--duration",
        type=float,
        default=None,
        help="Max recording duration in seconds (overrides MAX_SESSION_DURATION)",
    )
    parser.add_argument("--output", default=None, help="Override OUTPUT_DIRECTORY")
    parser.add_argument(
        "--max-mb",
        type=float,
        default=None,
        help="Max capture size in MB (overrides MAX_CAPTURE_MB)",
    )
    parser.add_argument("-v", "--verbose", action="store_true", help="Enable debug logging")
    args = parser.parse_args()

    # Logging
    level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
        datefmt="%H:%M:%S",
    )

    # Config
    config = load_config(args.env)

    # CLI overrides
    overrides: dict = {}
    if args.sources:
        overrides["capture_sources"] = [s.strip() for s in args.sources.split(",")]
    if args.duration is not None:
        overrides["max_session_duration"] = args.duration
    if args.output:
        from pathlib import Path

        overrides["output_directory"] = Path(args.output)
    if args.max_mb is not None:
        overrides["max_capture_mb"] = args.max_mb

    if overrides:
        from dataclasses import asdict

        from vcon_laptop.config import Config

        config = Config(**{**asdict(config), **overrides})

    # Signal handling
    signal.signal(signal.SIGINT, _on_signal)
    signal.signal(signal.SIGTERM, _on_signal)

    # Start session
    session = Session(config)
    session.start()

    print(f"\nRecording session {session.session_id}")
    print(f"  Sources : {', '.join(config.capture_sources)}")
    print(f"  Output  : {session.session_dir}")
    if config.max_capture_mb:
        print(f"  Max size: {config.max_capture_mb} MB")
    if config.max_session_duration:
        print(f"  Max dur : {config.max_session_duration}s")
    if config.analysis_enabled:
        print(f"  Analysis: transcription + image description")
    if config.obsidian_enabled:
        print(f"  Obsidian: {config.obsidian_vault_path}/{config.obsidian_folder}")
    if config.post_enabled:
        print(f"  Post to : {config.conserver_url}")
    print("\nPress Ctrl+C to stop.\n")

    # Wait for shutdown OR budget exceeded
    timeout = config.max_session_duration if config.max_session_duration > 0 else None
    _wait_for_any(_shutdown, session.budget_exceeded, timeout=timeout)

    # Stop and build vCon
    vcon = session.stop()

    dialog_count = len(vcon.get("dialog", []))
    analysis_count = len(vcon.get("analysis", []))
    print(f"\nSession complete.")
    print(f"  vCon UUID : {vcon['uuid']}")
    print(f"  Dialogs   : {dialog_count}")
    print(f"  Analyses  : {analysis_count}")
    print(f"  Saved to  : {session.session_dir / 'session.vcon.json'}")


if __name__ == "__main__":
    cli()
