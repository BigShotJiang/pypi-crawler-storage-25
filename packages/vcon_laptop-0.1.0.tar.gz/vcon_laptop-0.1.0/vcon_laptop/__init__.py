"""vcon-laptop — record laptop activity into vCon objects."""

__version__ = "0.1.0"
