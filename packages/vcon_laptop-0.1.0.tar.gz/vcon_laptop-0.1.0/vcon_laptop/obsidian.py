"""Export a vCon recording session as an Obsidian vault note with linked media."""

from __future__ import annotations

import json
import logging
import shutil
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List

from vcon_laptop.config import Config

log = logging.getLogger(__name__)


def export_to_obsidian(
    vcon: Dict[str, Any],
    config: Config,
    session_dir: Path,
) -> Path:
    """Copy media into the vault and create a markdown note. Returns the note path."""
    vault = Path(config.obsidian_vault_path)
    folder = vault / config.obsidian_folder
    folder.mkdir(parents=True, exist_ok=True)

    # Session timestamp for filenames
    created = vcon.get("created_at", "")
    try:
        dt = datetime.fromisoformat(created)
        date_slug = dt.strftime("%Y-%m-%d")
        time_slug = dt.strftime("%H-%M")
        title = f"{date_slug} {time_slug} Recording"
    except (ValueError, TypeError):
        title = f"Recording {vcon.get('uuid', 'unknown')[:8]}"
        date_slug = "unknown"

    # Media destination inside vault
    media_dir = folder / "attachments" / vcon.get("uuid", "session")[:12]
    media_dir.mkdir(parents=True, exist_ok=True)

    # Copy media files and build a manifest
    media_map: Dict[str, Path] = {}  # original filename -> vault-relative path
    _copy_media(session_dir, media_dir, media_map, vault)

    # Gather analysis
    transcript = _get_analysis_text(vcon, "transcript")
    summary = _get_analysis_text(vcon, "summary")
    descriptions = _get_screenshot_descriptions(vcon)
    tags_body = _get_tags(vcon)

    # Build markdown
    md = _build_markdown(
        vcon=vcon,
        title=title,
        date_slug=date_slug,
        transcript=transcript,
        summary=summary,
        descriptions=descriptions,
        tags_body=tags_body,
        media_map=media_map,
    )

    note_path = folder / f"{title}.md"
    # Avoid overwriting — append counter if needed
    counter = 1
    while note_path.exists():
        counter += 1
        note_path = folder / f"{title} ({counter}).md"

    note_path.write_text(md, encoding="utf-8")
    log.info("Obsidian note written to %s", note_path)
    return note_path


# ── helpers ──────────────────────────────────────────────────


def _copy_media(
    session_dir: Path,
    media_dir: Path,
    media_map: Dict[str, Path],
    vault: Path,
) -> None:
    """Copy all media files from session_dir into media_dir."""
    patterns = ["*.png", "*.wav", "*.mp4", "*.jpg", "*.webm"]
    for pat in patterns:
        for src in session_dir.rglob(pat):
            dst = media_dir / src.name
            shutil.copy2(src, dst)
            # Store vault-relative path for Obsidian links
            media_map[src.name] = dst.relative_to(vault)
            log.debug("Copied %s -> %s", src.name, dst)


def _get_analysis_text(vcon: Dict[str, Any], analysis_type: str) -> str:
    for a in vcon.get("analysis", []):
        if a.get("type") == analysis_type:
            return a.get("body", "")
    return ""


def _get_screenshot_descriptions(vcon: Dict[str, Any]) -> Dict[int, str]:
    """Map dialog index -> description text from analysis entries."""
    result: Dict[int, str] = {}
    for a in vcon.get("analysis", []):
        if a.get("schema") == "screenshot-description-v1" and a.get("dialog") is not None:
            result[a["dialog"]] = a.get("body", "")
    return result


def _get_tags(vcon: Dict[str, Any]) -> Dict[str, Any]:
    for att in vcon.get("attachments", []):
        if att.get("purpose") == "tags":
            try:
                return json.loads(att.get("body", "{}"))
            except (json.JSONDecodeError, TypeError):
                pass
    return {}


def _build_markdown(
    vcon: Dict[str, Any],
    title: str,
    date_slug: str,
    transcript: str,
    summary: str,
    descriptions: Dict[int, str],
    tags_body: Dict[str, Any],
    media_map: Dict[str, Path],
) -> str:
    lines: List[str] = []

    # ── YAML frontmatter ──────────────────────────────────────
    lines.append("---")
    lines.append(f"uuid: {vcon.get('uuid', '')}")
    lines.append(f"date: {date_slug}")
    lines.append(f"created_at: {vcon.get('created_at', '')}")

    duration_parts: List[str] = []
    if tags_body.get("audio_duration_seconds"):
        duration_parts.append(f"audio {tags_body['audio_duration_seconds']}s")
    if tags_body.get("video_duration_seconds"):
        duration_parts.append(f"video {tags_body['video_duration_seconds']}s")
    if duration_parts:
        lines.append(f"duration: {', '.join(duration_parts)}")

    lines.append(f"screenshots: {tags_body.get('screenshot_count', 0)}")
    lines.append("tags: [vcon, recording, laptop]")
    lines.append("---")
    lines.append("")

    # ── Title ─────────────────────────────────────────────────
    lines.append(f"# {title}")
    lines.append("")

    # ── Summary ───────────────────────────────────────────────
    if summary:
        lines.append("## Summary")
        lines.append("")
        lines.append(summary)
        lines.append("")

    # ── Transcription ─────────────────────────────────────────
    if transcript:
        lines.append("## Transcription")
        lines.append("")
        lines.append(transcript)
        lines.append("")

    # ── Screenshots ───────────────────────────────────────────
    dialogs = vcon.get("dialog", [])
    screenshot_dialogs = [
        (i, d) for i, d in enumerate(dialogs) if d.get("mediatype") == "image/png"
    ]
    if screenshot_dialogs:
        lines.append("## Screenshots")
        lines.append("")
        for dialog_idx, dialog in screenshot_dialogs:
            ts = dialog.get("start", "")
            try:
                dt = datetime.fromisoformat(ts)
                time_label = dt.strftime("%H:%M:%S")
            except (ValueError, TypeError):
                time_label = ts

            filename = dialog.get("filename", "")
            lines.append(f"### {time_label}")
            lines.append("")

            # Obsidian image embed
            if filename in media_map:
                vault_rel = media_map[filename]
                lines.append(f"![[{vault_rel}]]")
            else:
                lines.append(f"*{filename}*")
            lines.append("")

            # Description from analysis
            desc = descriptions.get(dialog_idx)
            if desc:
                lines.append(f"> {desc}")
                lines.append("")

    # ── Audio ─────────────────────────────────────────────────
    audio_file = "audio.wav"
    if audio_file in media_map:
        lines.append("## Audio")
        lines.append("")
        lines.append(f"![[{media_map[audio_file]}]]")
        lines.append("")

    # ── Video ─────────────────────────────────────────────────
    video_file = "camera.mp4"
    if video_file in media_map:
        lines.append("## Video")
        lines.append("")
        lines.append(f"![[{media_map[video_file]}]]")
        lines.append("")

    # ── Metadata ──────────────────────────────────────────────
    lines.append("## Metadata")
    lines.append("")
    lines.append(f"- **vCon UUID**: `{vcon.get('uuid', '')}`")
    lines.append(f"- **Session**: `{tags_body.get('session_id', '')}`")
    lines.append(f"- **Sources**: {', '.join(tags_body.get('capture_sources', []))}")
    if tags_body.get("audio_duration_seconds"):
        lines.append(f"- **Audio duration**: {tags_body['audio_duration_seconds']}s")
    if tags_body.get("video_duration_seconds"):
        res = tags_body.get("video_resolution", "")
        lines.append(f"- **Video duration**: {tags_body['video_duration_seconds']}s ({res})")
    lines.append(f"- **Screenshots**: {tags_body.get('screenshot_count', 0)}")
    lines.append("")

    return "\n".join(lines)
