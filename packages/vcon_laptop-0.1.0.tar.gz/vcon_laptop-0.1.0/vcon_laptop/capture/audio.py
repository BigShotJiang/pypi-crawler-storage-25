"""Continuous microphone recording to WAV using sounddevice + soundfile."""

from __future__ import annotations

import logging
import threading
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

log = logging.getLogger(__name__)


@dataclass
class CapturedAudio:
    path: Path
    timestamp: str  # ISO 8601
    duration: float  # seconds
    sample_rate: int
    channels: int


class AudioCapture:
    """Records microphone audio to a WAV file for the duration of a session."""

    def __init__(self, session_dir: Path, sample_rate: int = 44100, channels: int = 1):
        self.session_dir = session_dir
        self.sample_rate = sample_rate
        self.channels = channels
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._result: CapturedAudio | None = None

    def start(self) -> None:
        self.session_dir.mkdir(parents=True, exist_ok=True)
        self._stop.clear()
        self._result = None
        self._thread = threading.Thread(target=self._run, daemon=True, name="audio")
        self._thread.start()
        log.info("Audio capture started (rate=%d, channels=%d)", self.sample_rate, self.channels)

    def stop(self) -> CapturedAudio | None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=15)
        log.info(
            "Audio capture stopped (duration=%.1fs)",
            self._result.duration if self._result else 0,
        )
        return self._result

    def _run(self) -> None:
        try:
            import queue

            import sounddevice as sd
            import soundfile as sf
        except ImportError:
            log.error("sounddevice/soundfile not installed — cannot capture audio")
            return

        filepath = self.session_dir / "audio.wav"
        ts = datetime.now(timezone.utc)
        frames_written = 0
        audio_q: queue.Queue = queue.Queue()

        def _callback(indata, frames, time_info, status):
            if status:
                log.debug("Audio status: %s", status)
            audio_q.put(indata.copy())

        try:
            with sf.SoundFile(
                str(filepath),
                mode="w",
                samplerate=self.sample_rate,
                channels=self.channels,
                format="WAV",
                subtype="PCM_16",
            ) as f:
                with sd.InputStream(
                    samplerate=self.sample_rate,
                    channels=self.channels,
                    dtype="int16",
                    callback=_callback,
                ):
                    while not self._stop.is_set():
                        try:
                            data = audio_q.get(timeout=0.5)
                            f.write(data)
                            frames_written += len(data)
                        except queue.Empty:
                            pass

                    # Drain remaining queued data
                    while not audio_q.empty():
                        data = audio_q.get_nowait()
                        f.write(data)
                        frames_written += len(data)

            duration = frames_written / self.sample_rate
            self._result = CapturedAudio(
                path=filepath,
                timestamp=ts.isoformat(),
                duration=duration,
                sample_rate=self.sample_rate,
                channels=self.channels,
            )
        except Exception:
            log.exception("Audio capture failed")
