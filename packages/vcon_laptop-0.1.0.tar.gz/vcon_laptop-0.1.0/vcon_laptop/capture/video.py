"""Webcam video recording to MP4 using OpenCV."""

from __future__ import annotations

import logging
import threading
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

log = logging.getLogger(__name__)


@dataclass
class CapturedVideo:
    path: Path
    timestamp: str  # ISO 8601
    duration: float  # seconds
    fps: float
    width: int
    height: int


class VideoCapture:
    """Records webcam video to an MP4 file for the duration of a session."""

    def __init__(
        self,
        session_dir: Path,
        fps: int = 15,
        resolution: tuple[int, int] | None = None,
        device: int = 0,
    ):
        self.session_dir = session_dir
        self.fps = fps
        self.resolution = resolution
        self.device = device
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._result: CapturedVideo | None = None
        # Opened on main thread for macOS camera authorization
        self._cap = None
        self._writer = None
        self._w = 0
        self._h = 0

    def start(self) -> None:
        """Open camera on the main thread (required for macOS auth), then start recording."""
        self.session_dir.mkdir(parents=True, exist_ok=True)
        self._stop.clear()
        self._result = None

        try:
            import cv2
        except ImportError:
            log.error("opencv-python not installed — cannot capture video")
            return

        self._cap = cv2.VideoCapture(self.device)
        if not self._cap.isOpened():
            log.error(
                "Cannot open webcam device %d. "
                "Grant Camera permission to Terminal in System Settings > Privacy & Security.",
                self.device,
            )
            self._cap = None
            return

        if self.resolution:
            self._cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.resolution[0])
            self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.resolution[1])

        self._w = int(self._cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self._h = int(self._cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

        filepath = self.session_dir / "camera.mp4"
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        self._writer = cv2.VideoWriter(str(filepath), fourcc, self.fps, (self._w, self._h))

        if not self._writer.isOpened():
            log.error("Cannot create video writer")
            self._cap.release()
            self._cap = None
            return

        self._thread = threading.Thread(target=self._run, daemon=True, name="video")
        self._thread.start()
        log.info("Video capture started (fps=%d, %dx%d)", self.fps, self._w, self._h)

    def stop(self) -> CapturedVideo | None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=15)
        log.info(
            "Video capture stopped (duration=%.1fs)",
            self._result.duration if self._result else 0,
        )
        return self._result

    def _run(self) -> None:
        import cv2  # already validated in start()

        filepath = self.session_dir / "camera.mp4"
        ts = datetime.now(timezone.utc)
        frame_count = 0
        frame_interval = 1.0 / self.fps

        try:
            while not self._stop.is_set():
                ret, frame = self._cap.read()
                if not ret:
                    log.warning("Failed to read frame from webcam")
                    break
                self._writer.write(frame)
                frame_count += 1
                self._stop.wait(frame_interval)
        except Exception:
            log.exception("Video capture error")
        finally:
            self._writer.release()
            self._cap.release()

        duration = frame_count / self.fps if self.fps else 0
        self._result = CapturedVideo(
            path=filepath,
            timestamp=ts.isoformat(),
            duration=duration,
            fps=self.fps,
            width=self._w,
            height=self._h,
        )
