"""Periodic screen capture using mss (cross-platform) with macOS screencapture fallback."""

from __future__ import annotations

import logging
import platform
import subprocess
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import List

log = logging.getLogger(__name__)


@dataclass
class CapturedScreenshot:
    path: Path
    timestamp: str  # ISO 8601
    width: int = 0
    height: int = 0


class ScreenshotCapture:
    """Takes periodic screenshots and writes PNGs to the session directory."""

    def __init__(self, session_dir: Path, interval: float = 5.0):
        self.session_dir = session_dir / "screenshots"
        self.interval = interval
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self.captures: List[CapturedScreenshot] = []
        self._lock = threading.Lock()

    def start(self) -> None:
        self.session_dir.mkdir(parents=True, exist_ok=True)
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, daemon=True, name="screenshot")
        self._thread.start()
        log.info("Screenshot capture started (interval=%.1fs)", self.interval)

    def stop(self) -> List[CapturedScreenshot]:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=10)
        log.info("Screenshot capture stopped (%d captures)", len(self.captures))
        return list(self.captures)

    def _run(self) -> None:
        seq = 0
        while not self._stop.is_set():
            try:
                cap = self._take(seq)
                if cap:
                    with self._lock:
                        self.captures.append(cap)
                    seq += 1
            except Exception:
                log.exception("Screenshot capture error")
            self._stop.wait(self.interval)

    def _take(self, seq: int) -> CapturedScreenshot | None:
        ts = datetime.now(timezone.utc)
        filename = f"screen_{seq:05d}.png"
        filepath = self.session_dir / filename

        if platform.system() == "Darwin":
            return self._take_macos(filepath, ts)
        return self._take_mss(filepath, ts)

    def _take_macos(self, filepath: Path, ts: datetime) -> CapturedScreenshot | None:
        """Use macOS screencapture for reliable full-display capture."""
        try:
            subprocess.run(
                ["screencapture", "-x", "-t", "png", str(filepath)],
                check=True,
                timeout=10,
            )
            # Read dimensions via Pillow if available, else leave 0
            w, h = 0, 0
            try:
                from PIL import Image

                with Image.open(filepath) as img:
                    w, h = img.size
            except Exception:
                pass
            return CapturedScreenshot(
                path=filepath, timestamp=ts.isoformat(), width=w, height=h
            )
        except FileNotFoundError:
            log.warning("screencapture not found, falling back to mss")
            return self._take_mss(filepath, ts)
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as exc:
            log.debug("screencapture failed (%s), falling back to mss", exc)
            return self._take_mss(filepath, ts)

    def _take_mss(self, filepath: Path, ts: datetime) -> CapturedScreenshot | None:
        """Cross-platform capture via mss."""
        try:
            import mss
            import mss.tools

            with mss.mss() as sct:
                monitor = sct.monitors[0]  # combined virtual screen
                img = sct.grab(monitor)
                mss.tools.to_png(img.rgb, img.size, output=str(filepath))
                return CapturedScreenshot(
                    path=filepath,
                    timestamp=ts.isoformat(),
                    width=img.width,
                    height=img.height,
                )
        except ImportError:
            log.error("mss is not installed — cannot capture screenshots")
            return None
