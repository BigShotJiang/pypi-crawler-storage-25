"""Post-capture analysis: transcribe audio, describe screenshots, summarize session.

Results are added as ``analysis`` entries in the vCon, following the spec:
  - type: transcript | summary | report
  - vendor + product required
  - body is always a string

Priority order:
  - Audio transcription: mlx-whisper (local) → OpenAI Whisper API
  - Image description:   Ollama (local) → Anthropic Claude API
  - Session summary:     Ollama (local) → Anthropic Claude API
"""

from __future__ import annotations

import base64
import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Tuple

import httpx

from vcon_laptop.config import Config

log = logging.getLogger(__name__)

_IMAGE_PROMPT = (
    "Describe what is visible on this computer screenshot. "
    "Focus on: the active application, what the user is working on, "
    "and any notable content. Be concise — 2-3 sentences max."
)


# ── public entry point ────────────────────────────────────────


def run_analysis(
    vcon: Dict[str, Any],
    config: Config,
    session_dir: Path,
) -> Dict[str, Any]:
    """Run all configured analysis steps and append results to *vcon*."""
    analyses: List[Dict[str, Any]] = list(vcon.get("analysis", []))

    # 1. Transcribe audio (mlx-whisper local, or OpenAI API fallback)
    audio_text = ""
    audio_path = session_dir / "audio.wav"
    if audio_path.exists():
        log.info("Transcribing audio ...")
        text, vendor, product = _transcribe_audio(audio_path, config)
        if text:
            audio_text = text
            analyses.append({
                "type": "transcript",
                "dialog": _find_dialog_index(vcon, "audio/wav"),
                "vendor": vendor,
                "product": product,
                "body": audio_text,
                "encoding": "none",
            })
            log.info("Transcription complete via %s (%d chars)", vendor, len(audio_text))

    # 2. Describe screenshots (Ollama local → Anthropic fallback)
    descriptions: List[Dict[str, str]] = []
    screenshot_dialogs = [
        (i, d)
        for i, d in enumerate(vcon.get("dialog", []))
        if d.get("mediatype") == "image/png"
    ]
    if screenshot_dialogs:
        log.info("Describing %d screenshots ...", len(screenshot_dialogs))
        for dialog_idx, dialog in screenshot_dialogs:
            filepath = _resolve_dialog_file(dialog, session_dir)
            if not filepath or not filepath.exists():
                continue
            desc, vendor, product = _describe_image(filepath, config)
            if desc:
                descriptions.append({"dialog_index": dialog_idx, "text": desc})
                analyses.append({
                    "type": "report",
                    "dialog": dialog_idx,
                    "vendor": vendor,
                    "product": product,
                    "schema": "screenshot-description-v1",
                    "body": desc,
                    "encoding": "none",
                })
        log.info("Described %d screenshots", len(descriptions))

    # 3. Session summary
    if audio_text or descriptions:
        log.info("Generating session summary ...")
        summary, vendor, product = _generate_summary(audio_text, descriptions, config)
        if summary:
            analyses.append({
                "type": "summary",
                "vendor": vendor,
                "product": product,
                "schema": "session-summary-v1",
                "body": summary,
                "encoding": "none",
            })
            log.info("Summary complete via %s", vendor)

    vcon["analysis"] = analyses
    return vcon


# ── audio transcription ──────────────────────────────────────


def _transcribe_audio(
    audio_path: Path, config: Config
) -> Tuple[str, str, str]:
    """Returns (text, vendor, product). mlx-whisper first, then OpenAI API."""

    text = _transcribe_mlx(audio_path, config)
    if text:
        return text, "mlx-community", config.whisper_model

    if config.openai_api_key:
        text = _transcribe_openai(audio_path, config)
        if text:
            return text, "OpenAI", "whisper-1"

    return "", "", ""


def _transcribe_mlx(audio_path: Path, config: Config) -> str:
    try:
        import mlx_whisper

        log.info("Transcribing with mlx-whisper (model=%s) ...", config.whisper_model)
        result = mlx_whisper.transcribe(
            str(audio_path),
            path_or_hf_repo=config.whisper_model,
            word_timestamps=False,
        )
        return result.get("text", "").strip()
    except ImportError:
        log.debug("mlx-whisper not installed, trying fallback")
        return ""
    except Exception:
        log.exception("mlx-whisper transcription failed")
        return ""


def _transcribe_openai(audio_path: Path, config: Config) -> str:
    try:
        from openai import OpenAI

        log.info("Transcribing with OpenAI Whisper API ...")
        client = OpenAI(api_key=config.openai_api_key)
        with open(audio_path, "rb") as f:
            resp = client.audio.transcriptions.create(model="whisper-1", file=f)
        return resp.text
    except ImportError:
        log.debug("openai package not installed")
        return ""
    except Exception:
        log.exception("OpenAI transcription failed")
        return ""


# ── image description ────────────────────────────────────────


def _describe_image(
    image_path: Path, config: Config
) -> Tuple[str, str, str]:
    """Returns (description, vendor, product). Ollama → OpenAI → Anthropic."""

    desc = _describe_image_ollama(image_path, config)
    if desc:
        return desc, "Ollama", config.ollama_model

    if config.openai_api_key:
        desc = _describe_image_openai(image_path, config)
        if desc:
            return desc, "OpenAI", config.openai_vision_model

    if _anthropic_available(config):
        desc = _describe_image_anthropic(image_path, config)
        if desc:
            return desc, "Anthropic", config.analysis_model

    return "", "", ""


def _describe_image_ollama(image_path: Path, config: Config) -> str:
    """Describe an image using a local Ollama vision model."""
    if not config.ollama_url:
        return ""
    try:
        img_b64 = _resize_image_b64(image_path, max_width=1280)

        resp = httpx.post(
            f"{config.ollama_url}/api/chat",
            json={
                "model": config.ollama_model,
                "stream": False,
                "messages": [
                    {
                        "role": "user",
                        "content": _IMAGE_PROMPT,
                        "images": [img_b64],
                    }
                ],
            },
            timeout=httpx.Timeout(connect=10, read=600, write=30, pool=10),
        )
        resp.raise_for_status()
        data = resp.json()
        return data.get("message", {}).get("content", "").strip()
    except httpx.ConnectError:
        log.debug("Ollama not reachable at %s", config.ollama_url)
        return ""
    except Exception:
        log.exception("Ollama image description failed for %s", image_path.name)
        return ""


def _describe_image_anthropic(image_path: Path, config: Config) -> str:
    try:
        import anthropic

        client = _make_anthropic_client(config)
        img_data = _resize_image_b64(image_path, max_width=1280)

        resp = client.messages.create(
            model=config.analysis_model,
            max_tokens=300,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": "image/jpeg",
                                "data": img_data,
                            },
                        },
                        {"type": "text", "text": _IMAGE_PROMPT},
                    ],
                }
            ],
        )
        return resp.content[0].text
    except ImportError:
        log.debug("anthropic package not installed")
        return ""
    except Exception:
        log.exception("Anthropic image description failed for %s", image_path.name)
        return ""


def _describe_image_openai(image_path: Path, config: Config) -> str:
    """Describe an image using OpenAI GPT-4o vision."""
    try:
        from openai import OpenAI

        client = OpenAI(api_key=config.openai_api_key)
        img_b64 = _resize_image_b64(image_path, max_width=1280)

        resp = client.chat.completions.create(
            model=config.openai_vision_model,
            max_tokens=300,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{img_b64}",
                                "detail": "low",
                            },
                        },
                        {"type": "text", "text": _IMAGE_PROMPT},
                    ],
                }
            ],
        )
        return resp.choices[0].message.content.strip()
    except ImportError:
        log.debug("openai package not installed")
        return ""
    except Exception:
        log.exception("OpenAI image description failed for %s", image_path.name)
        return ""


# ── session summary ──────────────────────────────────────────


def _generate_summary(
    transcript: str,
    descriptions: List[Dict[str, str]],
    config: Config,
) -> Tuple[str, str, str]:
    """Returns (summary, vendor, product). Ollama → OpenAI → Anthropic."""

    prompt = _build_summary_prompt(transcript, descriptions)

    text = _summary_ollama(prompt, config)
    if text:
        return text, "Ollama", config.ollama_model

    if config.openai_api_key:
        text = _summary_openai(prompt, config)
        if text:
            return text, "OpenAI", config.openai_vision_model

    if _anthropic_available(config):
        text = _summary_anthropic(prompt, config)
        if text:
            return text, "Anthropic", config.analysis_model

    return "", "", ""


def _build_summary_prompt(transcript: str, descriptions: List[Dict[str, str]]) -> str:
    parts: List[str] = []
    if transcript:
        parts.append(f"Audio transcription:\n{transcript}")
    if descriptions:
        desc_lines = "\n".join(
            f"- Screenshot {d['dialog_index']}: {d['text']}" for d in descriptions
        )
        parts.append(f"Screenshot descriptions:\n{desc_lines}")
    return "\n\n".join(parts) + (
        "\n\nBased on the above, write a brief summary (3-5 sentences) "
        "of what the user was doing during this recording session."
    )


def _summary_ollama(prompt: str, config: Config) -> str:
    if not config.ollama_url:
        return ""
    try:
        resp = httpx.post(
            f"{config.ollama_url}/api/chat",
            json={
                "model": config.ollama_model,
                "stream": False,
                "messages": [{"role": "user", "content": prompt}],
            },
            timeout=httpx.Timeout(connect=10, read=300, write=10, pool=10),
        )
        resp.raise_for_status()
        return resp.json().get("message", {}).get("content", "").strip()
    except httpx.ConnectError:
        log.debug("Ollama not reachable at %s", config.ollama_url)
        return ""
    except Exception:
        log.exception("Ollama summary generation failed")
        return ""


def _summary_openai(prompt: str, config: Config) -> str:
    try:
        from openai import OpenAI

        client = OpenAI(api_key=config.openai_api_key)
        resp = client.chat.completions.create(
            model=config.openai_vision_model,
            max_tokens=400,
            messages=[{"role": "user", "content": prompt}],
        )
        return resp.choices[0].message.content.strip()
    except Exception:
        log.exception("OpenAI summary generation failed")
        return ""


def _summary_anthropic(prompt: str, config: Config) -> str:
    try:
        import anthropic

        client = _make_anthropic_client(config)
        resp = client.messages.create(
            model=config.analysis_model,
            max_tokens=400,
            messages=[{"role": "user", "content": prompt}],
        )
        return resp.content[0].text
    except Exception:
        log.exception("Anthropic summary generation failed")
        return ""


# ── helpers ──────────────────────────────────────────────────


def _anthropic_available(config: Config) -> bool:
    try:
        import anthropic  # noqa: F401
    except ImportError:
        return False
    import os

    return bool(config.anthropic_api_key or os.getenv("ANTHROPIC_API_KEY"))


def _make_anthropic_client(config: Config):
    import anthropic

    if config.anthropic_api_key:
        return anthropic.Anthropic(api_key=config.anthropic_api_key)
    return anthropic.Anthropic()


def _find_dialog_index(vcon: Dict[str, Any], mediatype: str) -> int | None:
    for i, d in enumerate(vcon.get("dialog", [])):
        if d.get("mediatype") == mediatype:
            return i
    return None


def _resize_image_b64(image_path: Path, max_width: int = 1280) -> str:
    """Downscale an image and return base64-encoded JPEG. Keeps aspect ratio."""
    import io

    from PIL import Image

    with Image.open(image_path) as img:
        if img.width > max_width:
            ratio = max_width / img.width
            new_size = (max_width, int(img.height * ratio))
            img = img.resize(new_size, Image.LANCZOS)
        if img.mode == "RGBA":
            img = img.convert("RGB")
        buf = io.BytesIO()
        img.save(buf, format="JPEG", quality=80)
        return base64.standard_b64encode(buf.getvalue()).decode()


def _resolve_dialog_file(dialog: Dict[str, Any], session_dir: Path) -> Path | None:
    url = dialog.get("url", "")
    if url.startswith("file://"):
        return Path(url.removeprefix("file://"))
    filename = dialog.get("filename")
    if filename:
        for candidate in [session_dir / filename, session_dir / "screenshots" / filename]:
            if candidate.exists():
                return candidate
    return None
