"""Session manager — orchestrates capture threads and produces a vCon on stop."""

from __future__ import annotations

import logging
import threading
import time
import uuid
from pathlib import Path
from datetime import datetime, timezone
from typing import Any, Dict

from vcon_laptop.builder import build_vcon
from vcon_laptop.capture.audio import AudioCapture, CapturedAudio
from vcon_laptop.capture.screenshot import CapturedScreenshot, ScreenshotCapture
from vcon_laptop.capture.video import CapturedVideo, VideoCapture
from vcon_laptop.config import Config
from vcon_laptop.poster import post_vcon
from vcon_laptop.storage import save_vcon

log = logging.getLogger(__name__)


def _dir_size_mb(path: Path) -> float:
    """Sum of all file sizes under *path*, in MB."""
    total = sum(f.stat().st_size for f in path.rglob("*") if f.is_file())
    return total / (1024 * 1024)


class Session:
    """A single recording session.

    Usage::

        session = Session(config)
        session.start()
        # ... user works ...
        session.stop()   # builds vCon, saves, optionally posts
    """

    def __init__(self, config: Config):
        self.config = config
        self.session_id = (
            datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "_" + uuid.uuid4().hex[:8]
        )
        self.session_dir = config.output_directory / self.session_id
        self.start_time: str = ""

        self._screenshot: ScreenshotCapture | None = None
        self._audio: AudioCapture | None = None
        self._video: VideoCapture | None = None

        # Set externally or by the size monitor to signal "stop recording"
        self.budget_exceeded = threading.Event()
        self._monitor_thread: threading.Thread | None = None

    # ── lifecycle ─────────────────────────────────────────────

    def start(self) -> None:
        """Start all configured capture sources."""
        self.session_dir.mkdir(parents=True, exist_ok=True)
        self.start_time = datetime.now(timezone.utc).isoformat()

        log.info("Session %s starting (dir=%s)", self.session_id, self.session_dir)

        if self.config.screenshot_enabled:
            self._screenshot = ScreenshotCapture(
                session_dir=self.session_dir,
                interval=self.config.screenshot_interval,
            )
            self._screenshot.start()

        if self.config.audio_enabled:
            self._audio = AudioCapture(
                session_dir=self.session_dir,
                sample_rate=self.config.audio_sample_rate,
            )
            self._audio.start()

        if self.config.video_enabled:
            self._video = VideoCapture(
                session_dir=self.session_dir,
                fps=self.config.video_fps,
                resolution=self.config.video_resolution,
            )
            self._video.start()

        # Size monitor
        if self.config.max_capture_mb > 0:
            self._monitor_thread = threading.Thread(
                target=self._monitor_size, daemon=True, name="size-monitor"
            )
            self._monitor_thread.start()

        log.info("Session %s is recording", self.session_id)

    def stop(self) -> Dict[str, Any]:
        """Stop all captures, build and persist the vCon. Returns the vCon dict."""
        log.info("Session %s stopping ...", self.session_id)

        screenshots: list[CapturedScreenshot] = []
        audio: CapturedAudio | None = None
        video: CapturedVideo | None = None

        if self._screenshot:
            screenshots = self._screenshot.stop()
        if self._audio:
            audio = self._audio.stop()
        if self._video:
            video = self._video.stop()

        # Build the vCon
        vcon = build_vcon(
            config=self.config,
            session_id=self.session_id,
            session_start=self.start_time,
            screenshots=screenshots,
            audio=audio,
            video=video,
        )

        # Save to disk
        vcon_path = save_vcon(vcon, self.session_dir)
        log.info("vCon saved to %s", vcon_path)

        # ── Analysis (transcription + image descriptions) ─────
        if self.config.analysis_enabled:
            try:
                from vcon_laptop.analyze import run_analysis

                vcon = run_analysis(vcon, self.config, self.session_dir)
                # Re-save with analysis entries
                save_vcon(vcon, self.session_dir)
                log.info("Analysis complete and vCon updated")
            except Exception:
                log.exception("Analysis step failed (vCon saved without analysis)")

        # ── Obsidian export ───────────────────────────────────
        if self.config.obsidian_enabled:
            try:
                from vcon_laptop.obsidian import export_to_obsidian

                note_path = export_to_obsidian(vcon, self.config, self.session_dir)
                log.info("Obsidian note created at %s", note_path)
            except Exception:
                log.exception("Obsidian export failed")

        # ── Post to conserver ─────────────────────────────────
        if self.config.post_enabled:
            try:
                post_vcon(vcon, self.config)
                log.info("vCon posted to %s", self.config.conserver_url)
            except Exception:
                log.exception("Failed to post vCon to conserver")

        log.info(
            "Session %s complete — %d screenshots, audio=%s, video=%s",
            self.session_id,
            len(screenshots),
            "yes" if audio else "no",
            "yes" if video else "no",
        )
        return vcon

    # ── size monitor ──────────────────────────────────────────

    def _monitor_size(self) -> None:
        limit = self.config.max_capture_mb
        while not self.budget_exceeded.is_set():
            size = _dir_size_mb(self.session_dir)
            if size >= limit:
                log.warning(
                    "Capture budget exceeded (%.1f MB >= %.1f MB limit) — stopping",
                    size,
                    limit,
                )
                self.budget_exceeded.set()
                return
            time.sleep(2)
