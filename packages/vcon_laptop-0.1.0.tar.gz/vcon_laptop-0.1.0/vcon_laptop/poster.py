"""POST a vCon to a conserver endpoint over HTTP."""

from __future__ import annotations

import logging
from typing import Any, Dict

import httpx

from vcon_laptop.config import Config

log = logging.getLogger(__name__)

POST_TIMEOUT = 60  # seconds


def post_vcon(vcon: Dict[str, Any], config: Config) -> None:
    """POST the vCon JSON to the configured conserver URL.

    Raises on HTTP errors so the caller can decide how to handle them.
    """
    if not config.conserver_url:
        return

    headers: Dict[str, str] = {"Content-Type": "application/json"}
    if config.conserver_api_token:
        headers[config.conserver_header_name] = config.conserver_api_token

    params: Dict[str, str] = {}
    if config.ingress_lists:
        params["ingress_list"] = ",".join(config.ingress_lists)

    url = config.conserver_url

    log.info("Posting vCon %s to %s", vcon.get("uuid", "?"), url)

    resp = httpx.post(
        url,
        json=vcon,
        headers=headers,
        params=params,
        timeout=POST_TIMEOUT,
    )
    resp.raise_for_status()
    log.info("Conserver responded %d", resp.status_code)
