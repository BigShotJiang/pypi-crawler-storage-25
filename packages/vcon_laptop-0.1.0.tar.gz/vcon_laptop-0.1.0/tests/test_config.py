"""Tests for config loading."""

from pathlib import Path

from vcon_laptop.config import Config, load_config


class TestConfigDefaults:
    def test_default_capture_sources(self):
        c = Config()
        assert c.capture_sources == ["screenshot", "audio", "video"]

    def test_default_video_fps_is_low(self):
        c = Config()
        assert c.video_fps == 1

    def test_default_ollama_model(self):
        c = Config()
        assert c.ollama_model == "gemma3:4b"

    def test_default_whisper_model(self):
        c = Config()
        assert c.whisper_model == "mlx-community/whisper-small-mlx"

    def test_default_media_storage(self):
        c = Config()
        assert c.media_storage == "external"


class TestConfigProperties:
    def test_post_enabled_false_by_default(self):
        c = Config()
        assert c.post_enabled is False

    def test_post_enabled_true_when_url_set(self):
        c = Config(conserver_url="https://example.com/vcon")
        assert c.post_enabled is True

    def test_obsidian_enabled_false_by_default(self):
        c = Config()
        assert c.obsidian_enabled is False

    def test_obsidian_enabled_true_when_path_set(self):
        c = Config(obsidian_vault_path="/some/vault")
        assert c.obsidian_enabled is True

    def test_screenshot_enabled(self):
        c = Config(capture_sources=["screenshot"])
        assert c.screenshot_enabled is True
        assert c.audio_enabled is False
        assert c.video_enabled is False

    def test_analysis_enabled_with_ollama(self):
        c = Config(ollama_url="http://localhost:11434")
        assert c.analysis_enabled is True

    def test_analysis_enabled_without_anything(self):
        c = Config(ollama_url="")
        # May be True if mlx_whisper is installed in test env
        # Just check it doesn't crash
        _ = c.analysis_enabled


class TestLoadConfig:
    def test_load_from_env_file(self, tmp_path: Path):
        env_file = tmp_path / ".env"
        env_file.write_text(
            "CAPTURE_SOURCES=screenshot\n"
            "VIDEO_FPS=2\n"
            "MAX_CAPTURE_MB=50\n"
            "USER_NAME=TestUser\n"
            "OLLAMA_URL=\n"
        )
        c = load_config(env_file)
        assert c.capture_sources == ["screenshot"]
        assert c.video_fps == 2
        assert c.max_capture_mb == 50.0
        assert c.user_name == "TestUser"
        assert c.ollama_url == ""

    def test_video_resolution_parsing(self, tmp_path: Path):
        env_file = tmp_path / ".env"
        env_file.write_text("VIDEO_RESOLUTION=1280x720\n")
        c = load_config(env_file)
        assert c.video_resolution == (1280, 720)

    def test_video_resolution_blank(self, tmp_path: Path, monkeypatch):
        monkeypatch.delenv("VIDEO_RESOLUTION", raising=False)
        env_file = tmp_path / ".env"
        env_file.write_text("VIDEO_RESOLUTION=\n")
        c = load_config(env_file)
        assert c.video_resolution is None
