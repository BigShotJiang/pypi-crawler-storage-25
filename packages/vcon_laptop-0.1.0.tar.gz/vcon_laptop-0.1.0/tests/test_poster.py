"""Tests for HTTP posting to conserver."""

from unittest.mock import patch, MagicMock

import httpx
import pytest

from vcon_laptop.config import Config
from vcon_laptop.poster import post_vcon


class TestPostVcon:
    def test_skips_when_no_url(self):
        config = Config(conserver_url="")
        # Should return without error
        post_vcon({"uuid": "test"}, config)

    @patch("vcon_laptop.poster.httpx.post")
    def test_posts_json(self, mock_post: MagicMock):
        mock_post.return_value = MagicMock(status_code=200)
        mock_post.return_value.raise_for_status = MagicMock()

        config = Config(conserver_url="https://example.com/vcon")
        vcon = {"uuid": "test-123", "vcon": "0.0.1"}
        post_vcon(vcon, config)

        mock_post.assert_called_once()
        call_kwargs = mock_post.call_args
        assert call_kwargs.kwargs["json"] == vcon
        assert "Content-Type" in call_kwargs.kwargs["headers"]

    @patch("vcon_laptop.poster.httpx.post")
    def test_sends_api_token(self, mock_post: MagicMock):
        mock_post.return_value = MagicMock(status_code=200)
        mock_post.return_value.raise_for_status = MagicMock()

        config = Config(
            conserver_url="https://example.com/vcon",
            conserver_api_token="secret-token",
            conserver_header_name="x-conserver-api-token",
        )
        post_vcon({"uuid": "t"}, config)

        headers = mock_post.call_args.kwargs["headers"]
        assert headers["x-conserver-api-token"] == "secret-token"

    @patch("vcon_laptop.poster.httpx.post")
    def test_sends_ingress_list(self, mock_post: MagicMock):
        mock_post.return_value = MagicMock(status_code=200)
        mock_post.return_value.raise_for_status = MagicMock()

        config = Config(
            conserver_url="https://example.com/vcon",
            ingress_lists=["transcribe", "analyze"],
        )
        post_vcon({"uuid": "t"}, config)

        params = mock_post.call_args.kwargs["params"]
        assert params["ingress_list"] == "transcribe,analyze"

    @patch("vcon_laptop.poster.httpx.post")
    def test_raises_on_http_error(self, mock_post: MagicMock):
        mock_post.return_value = MagicMock(status_code=500)
        mock_post.return_value.raise_for_status.side_effect = httpx.HTTPStatusError(
            "Server Error", request=MagicMock(), response=MagicMock()
        )

        config = Config(conserver_url="https://example.com/vcon")
        with pytest.raises(httpx.HTTPStatusError):
            post_vcon({"uuid": "t"}, config)
