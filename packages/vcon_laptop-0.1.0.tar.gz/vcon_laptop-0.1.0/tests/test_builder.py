"""Tests for vCon builder."""

import json
from pathlib import Path

from vcon_laptop.builder import VCON_VERSION, _sha512_hash, build_vcon
from vcon_laptop.capture.audio import CapturedAudio
from vcon_laptop.capture.screenshot import CapturedScreenshot
from vcon_laptop.capture.video import CapturedVideo
from vcon_laptop.config import Config


class TestBuildVcon:
    def test_minimal_vcon_structure(self, default_config: Config):
        vcon = build_vcon(
            config=default_config,
            session_id="test-session",
            session_start="2026-04-12T12:00:00+00:00",
        )
        assert vcon["vcon"] == VCON_VERSION
        assert "uuid" in vcon
        assert vcon["created_at"] == "2026-04-12T12:00:00+00:00"
        assert vcon["extensions"] == ["role"]
        assert len(vcon["parties"]) == 1
        assert vcon["parties"][0]["role"] == "agent"
        assert vcon["dialog"] == []
        assert vcon["analysis"] == []
        assert len(vcon["attachments"]) == 1

    def test_party_anonymous_when_no_name(self, default_config: Config):
        vcon = build_vcon(config=default_config, session_id="s", session_start="t")
        party = vcon["parties"][0]
        assert party["name"] == "anonymous"
        assert party["validation"] == "anonymous"

    def test_party_with_identity(self):
        config = Config(user_name="Alice", user_email="a@b.com", user_tel="+1555")
        vcon = build_vcon(config=config, session_id="s", session_start="t")
        party = vcon["parties"][0]
        assert party["name"] == "Alice"
        assert party["mailto"] == "a@b.com"
        assert party["tel"] == "+1555"
        assert party["validation"] == "self"

    def test_screenshot_dialog_external(self, default_config: Config, sample_png: Path):
        cap = CapturedScreenshot(
            path=sample_png, timestamp="2026-04-12T12:00:01+00:00", width=200, height=100
        )
        vcon = build_vcon(
            config=default_config,
            session_id="s",
            session_start="t",
            screenshots=[cap],
        )
        assert len(vcon["dialog"]) == 1
        d = vcon["dialog"][0]
        assert d["type"] == "recording"
        assert d["mediatype"] == "image/png"
        assert d["filename"] == "screen_00000.png"
        assert d["url"].startswith("file://")
        assert d["content_hash"].startswith("sha512-")
        assert "body" not in d

    def test_screenshot_dialog_inline(self, sample_png: Path):
        config = Config(media_storage="inline")
        cap = CapturedScreenshot(
            path=sample_png, timestamp="2026-04-12T12:00:01+00:00", width=200, height=100
        )
        vcon = build_vcon(config=config, session_id="s", session_start="t", screenshots=[cap])
        d = vcon["dialog"][0]
        assert d["encoding"] == "base64url"
        assert len(d["body"]) > 0
        assert "url" not in d

    def test_audio_dialog(self, default_config: Config, sample_wav: Path):
        audio = CapturedAudio(
            path=sample_wav,
            timestamp="2026-04-12T12:00:00+00:00",
            duration=10.5,
            sample_rate=44100,
            channels=1,
        )
        vcon = build_vcon(
            config=default_config, session_id="s", session_start="t", audio=audio
        )
        assert len(vcon["dialog"]) == 1
        d = vcon["dialog"][0]
        assert d["mediatype"] == "audio/wav"
        assert d["duration"] == 10.5

    def test_video_dialog(self, tmp_session_dir: Path, default_config: Config):
        # Create a dummy mp4 file
        mp4 = tmp_session_dir / "camera.mp4"
        mp4.write_bytes(b"\x00" * 100)
        video = CapturedVideo(
            path=mp4,
            timestamp="2026-04-12T12:00:00+00:00",
            duration=5.0,
            fps=1,
            width=1920,
            height=1080,
        )
        vcon = build_vcon(
            config=default_config, session_id="s", session_start="t", video=video
        )
        d = vcon["dialog"][-1]
        assert d["mediatype"] == "video/mp4"
        assert d["duration"] == 5.0

    def test_tags_attachment(self, default_config: Config, sample_wav: Path):
        audio = CapturedAudio(
            path=sample_wav, timestamp="t", duration=3.0, sample_rate=44100, channels=1
        )
        vcon = build_vcon(
            config=default_config, session_id="sess1", session_start="t", audio=audio
        )
        att = vcon["attachments"][0]
        assert att["purpose"] == "tags"
        assert att["party"] == 0
        assert att["dialog"] == 0
        assert att["encoding"] == "json"
        tags = json.loads(att["body"])
        assert tags["source"] == "laptop_adapter"
        assert tags["session_id"] == "sess1"
        assert tags["audio_duration_seconds"] == 3.0

    def test_combined_dialog_ordering(
        self, default_config: Config, sample_png: Path, sample_wav: Path
    ):
        cap = CapturedScreenshot(path=sample_png, timestamp="t1")
        audio = CapturedAudio(
            path=sample_wav, timestamp="t2", duration=1.0, sample_rate=44100, channels=1
        )
        vcon = build_vcon(
            config=default_config,
            session_id="s",
            session_start="t",
            screenshots=[cap],
            audio=audio,
        )
        assert len(vcon["dialog"]) == 2
        assert vcon["dialog"][0]["mediatype"] == "image/png"
        assert vcon["dialog"][1]["mediatype"] == "audio/wav"


class TestSha512Hash:
    def test_hash_format(self, sample_png: Path):
        h = _sha512_hash(sample_png)
        assert h.startswith("sha512-")
        assert len(h) > 10

    def test_hash_deterministic(self, sample_png: Path):
        assert _sha512_hash(sample_png) == _sha512_hash(sample_png)
