"""Tests for vCon storage (save to disk)."""

import json
from pathlib import Path

from vcon_laptop.storage import save_vcon


class TestSaveVcon:
    def test_creates_file(self, tmp_path: Path):
        vcon = {"vcon": "0.0.1", "uuid": "test"}
        path = save_vcon(vcon, tmp_path)
        assert path.exists()
        assert path.name == "session.vcon.json"

    def test_valid_json_output(self, tmp_path: Path):
        vcon = {"vcon": "0.0.1", "uuid": "test", "parties": []}
        path = save_vcon(vcon, tmp_path)
        loaded = json.loads(path.read_text())
        assert loaded == vcon

    def test_creates_parent_dirs(self, tmp_path: Path):
        deep = tmp_path / "a" / "b" / "c"
        vcon = {"vcon": "0.0.1"}
        path = save_vcon(vcon, deep)
        assert path.exists()

    def test_overwrites_existing(self, tmp_path: Path):
        save_vcon({"version": 1}, tmp_path)
        path = save_vcon({"version": 2}, tmp_path)
        loaded = json.loads(path.read_text())
        assert loaded["version"] == 2

    def test_unicode_content(self, tmp_path: Path):
        vcon = {"subject": "Café résumé 日本語"}
        path = save_vcon(vcon, tmp_path)
        loaded = json.loads(path.read_text(encoding="utf-8"))
        assert loaded["subject"] == "Café résumé 日本語"
