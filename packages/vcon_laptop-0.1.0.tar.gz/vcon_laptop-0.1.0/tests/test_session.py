"""Tests for session lifecycle."""

import json
import time
from pathlib import Path
from unittest.mock import MagicMock, patch

from vcon_laptop.config import Config
from vcon_laptop.session import Session, _dir_size_mb


class TestDirSizeMb:
    def test_empty_dir(self, tmp_path: Path):
        assert _dir_size_mb(tmp_path) == 0.0

    def test_with_files(self, tmp_path: Path):
        (tmp_path / "a.bin").write_bytes(b"\x00" * 1024 * 1024)  # 1 MB
        size = _dir_size_mb(tmp_path)
        assert 0.9 < size < 1.1


class TestSession:
    def _make_config(self, tmp_path: Path, **overrides) -> Config:
        defaults = dict(
            capture_sources=[],
            output_directory=tmp_path,
            ollama_url="",
            anthropic_api_key="",
            openai_api_key="",
        )
        defaults.update(overrides)
        return Config(**defaults)

    def test_session_creates_directory(self, tmp_path: Path):
        config = self._make_config(tmp_path)
        session = Session(config)
        session.start()
        assert session.session_dir.exists()
        session.stop()

    def test_session_produces_vcon(self, tmp_path: Path):
        config = self._make_config(tmp_path)
        session = Session(config)
        session.start()
        vcon = session.stop()
        assert "uuid" in vcon
        assert "dialog" in vcon
        assert "parties" in vcon

    def test_session_saves_json(self, tmp_path: Path):
        config = self._make_config(tmp_path)
        session = Session(config)
        session.start()
        session.stop()
        vcon_path = session.session_dir / "session.vcon.json"
        assert vcon_path.exists()
        data = json.loads(vcon_path.read_text())
        assert data["vcon"] == "0.0.1"

    def test_budget_exceeded_event(self, tmp_path: Path):
        config = self._make_config(tmp_path, max_capture_mb=0.001)  # tiny budget
        session = Session(config)
        session.start()
        # Write a file to exceed budget
        (session.session_dir / "big.bin").write_bytes(b"\x00" * 2048)
        # Wait for monitor to detect
        time.sleep(3)
        assert session.budget_exceeded.is_set()
        session.stop()

    @patch("vcon_laptop.session.post_vcon")
    def test_posts_when_configured(self, mock_post: MagicMock, tmp_path: Path):
        config = self._make_config(
            tmp_path, conserver_url="https://example.com/vcon"
        )
        session = Session(config)
        session.start()
        session.stop()
        mock_post.assert_called_once()

    @patch("vcon_laptop.session.post_vcon")
    def test_no_post_without_url(self, mock_post: MagicMock, tmp_path: Path):
        config = self._make_config(tmp_path)
        session = Session(config)
        session.start()
        session.stop()
        mock_post.assert_not_called()
