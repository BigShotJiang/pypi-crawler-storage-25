"""Tests for Obsidian vault export."""

import json
from pathlib import Path

from vcon_laptop.config import Config
from vcon_laptop.obsidian import (
    _build_markdown,
    _get_analysis_text,
    _get_screenshot_descriptions,
    _get_tags,
    export_to_obsidian,
)


class TestExportToObsidian:
    def test_creates_note_file(
        self, sample_vcon: dict, tmp_session_dir: Path, tmp_path: Path, sample_png: Path
    ):
        vault = tmp_path / "vault"
        config = Config(obsidian_vault_path=str(vault), obsidian_folder="Recordings")
        note = export_to_obsidian(sample_vcon, config, tmp_session_dir)
        assert note.exists()
        assert note.suffix == ".md"
        assert "Recording" in note.stem

    def test_copies_media_files(
        self, sample_vcon: dict, tmp_session_dir: Path, tmp_path: Path, sample_png: Path, sample_wav: Path
    ):
        vault = tmp_path / "vault"
        config = Config(obsidian_vault_path=str(vault), obsidian_folder="Recordings")
        export_to_obsidian(sample_vcon, config, tmp_session_dir)

        # Should have copied the PNG and WAV
        attachments_dir = vault / "Recordings" / "attachments"
        media_files = list(attachments_dir.rglob("*"))
        filenames = {f.name for f in media_files if f.is_file()}
        assert "screen_00000.png" in filenames
        assert "audio.wav" in filenames

    def test_frontmatter_present(
        self, sample_vcon: dict, tmp_session_dir: Path, tmp_path: Path, sample_png: Path
    ):
        vault = tmp_path / "vault"
        config = Config(obsidian_vault_path=str(vault), obsidian_folder="Recordings")
        note = export_to_obsidian(sample_vcon, config, tmp_session_dir)
        content = note.read_text()
        assert content.startswith("---\n")
        assert "uuid: test-uuid-1234" in content
        assert "tags: [vcon, recording, laptop]" in content

    def test_no_overwrite(
        self, sample_vcon: dict, tmp_session_dir: Path, tmp_path: Path, sample_png: Path
    ):
        vault = tmp_path / "vault"
        config = Config(obsidian_vault_path=str(vault), obsidian_folder="Recordings")
        note1 = export_to_obsidian(sample_vcon, config, tmp_session_dir)
        note2 = export_to_obsidian(sample_vcon, config, tmp_session_dir)
        assert note1 != note2
        assert "(2)" in note2.stem

    def test_includes_analysis_sections(
        self, sample_vcon: dict, tmp_session_dir: Path, tmp_path: Path, sample_png: Path
    ):
        sample_vcon["analysis"] = [
            {"type": "transcript", "body": "Hello world", "vendor": "test"},
            {"type": "summary", "body": "User was working.", "vendor": "test"},
            {
                "type": "report",
                "dialog": 0,
                "schema": "screenshot-description-v1",
                "body": "A terminal window",
                "vendor": "test",
            },
        ]
        vault = tmp_path / "vault"
        config = Config(obsidian_vault_path=str(vault), obsidian_folder="Recordings")
        note = export_to_obsidian(sample_vcon, config, tmp_session_dir)
        content = note.read_text()
        assert "## Summary" in content
        assert "User was working." in content
        assert "## Transcription" in content
        assert "Hello world" in content
        assert "> A terminal window" in content


class TestHelpers:
    def test_get_analysis_text(self):
        vcon = {
            "analysis": [
                {"type": "transcript", "body": "some text"},
                {"type": "summary", "body": "a summary"},
            ]
        }
        assert _get_analysis_text(vcon, "transcript") == "some text"
        assert _get_analysis_text(vcon, "summary") == "a summary"
        assert _get_analysis_text(vcon, "missing") == ""

    def test_get_screenshot_descriptions(self):
        vcon = {
            "analysis": [
                {"type": "report", "schema": "screenshot-description-v1", "dialog": 0, "body": "desc0"},
                {"type": "report", "schema": "screenshot-description-v1", "dialog": 2, "body": "desc2"},
                {"type": "summary", "body": "not this"},
            ]
        }
        result = _get_screenshot_descriptions(vcon)
        assert result == {0: "desc0", 2: "desc2"}

    def test_get_tags(self):
        vcon = {
            "attachments": [
                {"purpose": "tags", "body": '{"source": "test", "count": 5}', "encoding": "json"}
            ]
        }
        tags = _get_tags(vcon)
        assert tags["source"] == "test"
        assert tags["count"] == 5

    def test_get_tags_empty(self):
        assert _get_tags({"attachments": []}) == {}

    def test_build_markdown_screenshot_wikilinks(self):
        vcon = {
            "uuid": "abc",
            "created_at": "2026-04-12T12:00:00+00:00",
            "dialog": [
                {
                    "type": "recording",
                    "start": "2026-04-12T12:00:01+00:00",
                    "mediatype": "image/png",
                    "filename": "shot.png",
                }
            ],
        }
        media_map = {"shot.png": Path("Recordings/attachments/abc/shot.png")}
        md = _build_markdown(
            vcon=vcon,
            title="Test",
            date_slug="2026-04-12",
            transcript="",
            summary="",
            descriptions={},
            tags_body={"screenshot_count": 1, "capture_sources": ["screenshot"]},
            media_map=media_map,
        )
        assert "![[Recordings/attachments/abc/shot.png]]" in md
