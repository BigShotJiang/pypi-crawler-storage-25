"""Tests for analysis pipeline (all API calls mocked)."""

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from vcon_laptop.analyze import (
    _find_dialog_index,
    _resize_image_b64,
    _resolve_dialog_file,
    run_analysis,
)
from vcon_laptop.config import Config


class TestRunAnalysis:
    def test_no_analysis_without_providers(self, sample_vcon: dict, tmp_session_dir: Path):
        config = Config(ollama_url="", anthropic_api_key="", openai_api_key="")
        result = run_analysis(sample_vcon, config, tmp_session_dir)
        assert result["analysis"] == []

    @patch("vcon_laptop.analyze._transcribe_mlx")
    def test_mlx_transcription_added(
        self, mock_mlx: MagicMock, sample_vcon: dict, tmp_session_dir: Path, sample_wav: Path
    ):
        mock_mlx.return_value = "Hello world"
        config = Config(ollama_url="", anthropic_api_key="", openai_api_key="")
        result = run_analysis(sample_vcon, config, tmp_session_dir)

        transcripts = [a for a in result["analysis"] if a["type"] == "transcript"]
        assert len(transcripts) == 1
        assert transcripts[0]["body"] == "Hello world"
        assert transcripts[0]["vendor"] == "mlx-community"
        assert transcripts[0]["encoding"] == "none"

    @patch("vcon_laptop.analyze._describe_image_ollama")
    def test_ollama_descriptions_added(
        self,
        mock_ollama: MagicMock,
        sample_vcon: dict,
        tmp_session_dir: Path,
        sample_png: Path,
    ):
        mock_ollama.return_value = "A terminal window"
        config = Config(ollama_url="http://localhost:11434", anthropic_api_key="", openai_api_key="")
        result = run_analysis(sample_vcon, config, tmp_session_dir)

        reports = [a for a in result["analysis"] if a["type"] == "report"]
        assert len(reports) == 1
        assert reports[0]["body"] == "A terminal window"
        assert reports[0]["vendor"] == "Ollama"
        assert reports[0]["schema"] == "screenshot-description-v1"
        assert reports[0]["dialog"] == 0

    @patch("vcon_laptop.analyze._summary_ollama")
    @patch("vcon_laptop.analyze._describe_image_ollama")
    def test_summary_generated_after_descriptions(
        self,
        mock_desc: MagicMock,
        mock_summary: MagicMock,
        sample_vcon: dict,
        tmp_session_dir: Path,
        sample_png: Path,
    ):
        mock_desc.return_value = "Code editor visible"
        mock_summary.return_value = "User was writing code."
        config = Config(ollama_url="http://localhost:11434")
        result = run_analysis(sample_vcon, config, tmp_session_dir)

        summaries = [a for a in result["analysis"] if a["type"] == "summary"]
        assert len(summaries) == 1
        assert summaries[0]["body"] == "User was writing code."

    @patch("vcon_laptop.analyze._describe_image_ollama", return_value="")
    @patch("vcon_laptop.analyze._describe_image_openai", return_value="OpenAI desc")
    def test_fallback_ollama_to_openai(
        self,
        mock_openai: MagicMock,
        mock_ollama: MagicMock,
        sample_vcon: dict,
        tmp_session_dir: Path,
        sample_png: Path,
    ):
        config = Config(ollama_url="http://localhost:11434", openai_api_key="sk-test")
        result = run_analysis(sample_vcon, config, tmp_session_dir)

        reports = [a for a in result["analysis"] if a["type"] == "report"]
        assert len(reports) == 1
        assert reports[0]["vendor"] == "OpenAI"

    @patch("vcon_laptop.analyze._describe_image_ollama", return_value="")
    @patch("vcon_laptop.analyze._describe_image_openai", return_value="")
    @patch("vcon_laptop.analyze._describe_image_anthropic", return_value="Claude desc")
    def test_fallback_to_anthropic(
        self,
        mock_anthropic: MagicMock,
        mock_openai: MagicMock,
        mock_ollama: MagicMock,
        sample_vcon: dict,
        tmp_session_dir: Path,
        sample_png: Path,
    ):
        config = Config(
            ollama_url="http://localhost:11434",
            openai_api_key="sk-test",
            anthropic_api_key="sk-ant-test",
        )
        result = run_analysis(sample_vcon, config, tmp_session_dir)

        reports = [a for a in result["analysis"] if a["type"] == "report"]
        assert len(reports) == 1
        assert reports[0]["vendor"] == "Anthropic"

    def test_no_summary_without_content(self, tmp_session_dir: Path):
        """No summary generated when there are no descriptions or transcription."""
        vcon = {
            "dialog": [],
            "analysis": [],
            "attachments": [],
        }
        config = Config(ollama_url="http://localhost:11434")
        result = run_analysis(vcon, config, tmp_session_dir)
        summaries = [a for a in result["analysis"] if a["type"] == "summary"]
        assert len(summaries) == 0


class TestResizeImage:
    def test_downsizes_large_image(self, sample_png: Path):
        # sample_png is 200x100, so max_width=100 should shrink it
        b64 = _resize_image_b64(sample_png, max_width=100)
        assert len(b64) > 0

    def test_preserves_small_image(self, sample_png: Path):
        # 200px wide, max_width=1280 — should not resize
        b64 = _resize_image_b64(sample_png, max_width=1280)
        assert len(b64) > 0

    def test_converts_rgba_to_rgb(self, sample_png: Path):
        import base64
        import io
        from PIL import Image

        b64 = _resize_image_b64(sample_png, max_width=1280)
        data = base64.standard_b64decode(b64)
        img = Image.open(io.BytesIO(data))
        assert img.mode == "RGB"  # not RGBA


class TestHelpers:
    def test_find_dialog_index_found(self):
        vcon = {"dialog": [{"mediatype": "image/png"}, {"mediatype": "audio/wav"}]}
        assert _find_dialog_index(vcon, "audio/wav") == 1

    def test_find_dialog_index_not_found(self):
        vcon = {"dialog": [{"mediatype": "image/png"}]}
        assert _find_dialog_index(vcon, "video/mp4") is None

    def test_resolve_dialog_file_from_url(self, sample_png: Path):
        dialog = {"url": f"file://{sample_png}"}
        result = _resolve_dialog_file(dialog, sample_png.parent.parent)
        assert result == sample_png

    def test_resolve_dialog_file_from_filename(self, sample_png: Path):
        session_dir = sample_png.parent.parent  # tmp_session_dir
        dialog = {"filename": "screen_00000.png"}
        result = _resolve_dialog_file(dialog, session_dir)
        assert result is not None
        assert result.name == "screen_00000.png"

    def test_resolve_dialog_file_missing(self, tmp_session_dir: Path):
        dialog = {"filename": "nonexistent.png"}
        result = _resolve_dialog_file(dialog, tmp_session_dir)
        assert result is None
