version 1.0

task regenie_step1 {
    input {
        File phenotype_file
        File covariate_file
        File bed_file
        File bim_file
        File fam_file
        File keep_variant_file
        File keep_sample_file
        String prefix
        String phenoColString
        Boolean isbinary
        String covar_col_list = "age,age_2,age_sex,genetic_pca1,genetic_pca2,genetic_pca3,genetic_pca4,genetic_pca5,genetic_pca6,genetic_pca7,genetic_pca8,genetic_pca9,genetic_pca10"
        String cat_covar_list = "genetic_sex"
    }

    command <<<
        mkdir -p step1

        regenie \
            --step 1 \
            --bed ~{sub(bed_file, "\\.bed$", "")} \
            --extract ~{keep_variant_file} \
            --keep ~{keep_sample_file} \
            --phenoFile ~{phenotype_file} \
            --covarFile ~{covariate_file} \
            --phenoColList ~{phenoColString} \
            --covarColList ~{covar_col_list} \
            --catCovarList ~{cat_covar_list} \
            ~{if isbinary then "--bt" else ""} \
            --bsize 1000 \
            --lowmem \
            --lowmem-prefix "regenie_tmp_preds_~{prefix}" \
            --out "~{prefix}_pheno"
    >>>

    output {
        File pred_file = "~{prefix}_pheno_pred.list"
        File log_file = "~{prefix}_pheno.log"
        Array[File] loco_files = glob("*.loco")
    }

    runtime {
        memory: "32 GiB"
        cpu: 15
        disks: "local-disk 400 HDD"
        docker: "us-central1-docker.pkg.dev/all-of-us-rw-prod/aou-rw-gar-remote-repo-docker-prod/shengqh/regenie:latest"
    }
}

task regenie_step2 {
    input {
        File phenotype_file
        File? covariate_file
        File? bgen_file
        File? sample_file
        File? index_file
        File? set_file
        File? anno_file
        File? aaf_file
        File? mask_file
        File? target_bed
        File? target_bim
        File? target_fam
        File? extract_file
        File? pred_file
        Array[File]? loco_files
        String prefix
        String chrm
        String phenoColString
        Boolean isbinary
        Boolean interaction_mode = false
        Boolean skip_association = false
        Boolean write_mask = false
        Boolean ignore_pred = false
        String? extract_setlist
        String? interaction_snp
        File? interaction_bed
        File? interaction_bim
        File? interaction_fam
        Boolean interaction_file_reffirst = false
        Boolean no_condtl = false
        Boolean force_condtl = false
        String covar_col_list = "age,age_2,age_sex,genetic_pca1,genetic_pca2,genetic_pca3,genetic_pca4,genetic_pca5,genetic_pca6,genetic_pca7,genetic_pca8,genetic_pca9,genetic_pca10"
        String cat_covar_list = "genetic_sex"
    }

    command <<<
        for file in ~{sep=' ' select_first([loco_files, []])}; do
            mv "${file}" .
        done

        ~{if interaction_mode then "test -f " + select_first([target_bim]) else "true"}
        ~{if interaction_mode then "test -f " + select_first([target_fam]) else "true"}
        ~{if defined(interaction_bim) then "test -f " + select_first([interaction_bim]) else "true"}
        ~{if defined(interaction_fam) then "test -f " + select_first([interaction_fam]) else "true"}

        regenie \
            --step 2 \
            ~{if interaction_mode then "--bed " + sub(select_first([target_bed]), "\\.bed$", "") else "--bgen " + select_first([bgen_file])} \
            ~{if interaction_mode then "" else "--ref-first"} \
            ~{if interaction_mode then "" else "--sample " + select_first([sample_file])} \
            ~{if interaction_mode then "" else "--bgi " + select_first([index_file])} \
            --phenoFile ~{phenotype_file} \
            ~{if defined(covariate_file) then "--covarFile " + select_first([covariate_file]) else ""} \
            --phenoColList ~{phenoColString} \
            ~{if defined(covariate_file) then "--covarColList " + covar_col_list else ""} \
            ~{if defined(covariate_file) then "--catCovarList " + cat_covar_list else ""} \
            ~{if interaction_mode then "" else "--set-list " + select_first([set_file])} \
            ~{if interaction_mode then "" else "--anno-file " + select_first([anno_file])} \
            ~{if interaction_mode then "" else "--aaf-file " + select_first([aaf_file])} \
            ~{if interaction_mode then "" else "--mask-def " + select_first([mask_file])} \
            ~{if defined(pred_file) then "--pred " + select_first([pred_file]) else ""} \
            --minMAC ~{if interaction_mode then "5" else "1"} \
            --aaf-bins 0.01,0.001 \
            --bsize 200 \
            ~{if write_mask then "--write-mask" else ""} \
            ~{if skip_association then "--skip-test" else ""} \
            ~{if ignore_pred then "--ignore-pred" else ""} \
            ~{if interaction_mode && defined(extract_file) then "--extract " + select_first([extract_file]) else ""} \
            ~{if !interaction_mode && defined(extract_setlist) then "--extract-setlist " + select_first([extract_setlist]) else ""} \
            ~{if interaction_mode && defined(interaction_snp) then "--interaction-snp " + select_first([interaction_snp]) else ""} \
            ~{if interaction_mode && defined(interaction_bed) then "--interaction-file bed," + sub(select_first([interaction_bed]), "\\.bed$", "") else ""} \
            ~{if interaction_mode && interaction_file_reffirst then "--interaction-file-reffirst" else ""} \
            ~{if interaction_mode && no_condtl then "--no-condtl" else ""} \
            ~{if interaction_mode && force_condtl then "--force-condtl" else ""} \
            ~{if isbinary then "--bt --firth --approx --pThresh 0.05" else ""} \
            --out "~{prefix}_pheno_chr~{chrm}"
    >>>

    output {
        File log_file = "~{prefix}_pheno_chr~{chrm}.log"
        Array[File] output_results = glob("*.regenie")
        Array[File] mask_beds = glob("*_masks.bed")
        Array[File] mask_bims = glob("*_masks.bim")
        Array[File] mask_fams = glob("*_masks.fam")
    }

    runtime {
        memory: "16 GB"
        cpu: 4
        disks: "local-disk 200 HDD"
        docker: "us-central1-docker.pkg.dev/all-of-us-rw-prod/aou-rw-gar-remote-repo-docker-prod/shengqh/regenie:latest"
    }
}

task merge_regenie_outputs {
  input {
    Array[Array[File]] step2_outputs
    String prefix
    Array[String] phenoColList
    Array[String] chrs
    String first_chr = chrs[0]
  }

  command <<<
    for file in ~{sep=' ' flatten(step2_outputs)}; do
        mv "${file}" .
    done

    for pheno_name in ~{sep=' ' phenoColList}; do
        echo "Merging Regenie results for phenotype: ${pheno_name}"
        # Extract header from first chromosome file
        grep -v '^#' ~{prefix}_pheno_chr~{first_chr}_${pheno_name}.regenie | head -n 1 > ${pheno_name}.txt
        # Append all non-header lines for all chromosomes
        for chr in ~{sep=' ' chrs}; do
          grep -v '^#' ~{prefix}_pheno_chr${chr}_${pheno_name}.regenie | grep -v '^CHROM' >> ${pheno_name}.txt
        done
    done
  >>>

  output {
    Array[File] merged_files = glob("*.txt")
  }

  runtime {
    memory: "8 GB"
    cpu: 2
    disks: "local-disk 100 HDD"
    docker: "us-central1-docker.pkg.dev/all-of-us-rw-prod/aou-rw-gar-remote-repo-docker-prod/shengqh/regenie:latest"
  }
}

workflow regenie_workflow {
    input {
        Boolean isbinary
        Boolean run_step1
        Boolean skip_association = false
        Boolean write_mask = false
        Boolean ignore_pred = false
        Boolean interaction_mode = false
        String prefix

        File phenotype_file
        File? covariate_file
        Array[String] phenoColList
        String phenoColString

        File? bed_file
        File? bim_file
        File? fam_file
        File? keep_variant_file
        File? keep_sample_file

        Array[String] chrs
        Array[File]? bgen_files
        Array[File]? sample_files
        Array[File]? index_files
        Array[File]? set_files
        Array[File]? anno_files
        Array[File]? aaf_files
        Array[File]? mask_files
        Array[File]? target_bed_files
        Array[File]? target_bim_files
        Array[File]? target_fam_files
        File? extract_file

        File? pred_file
        Array[File]? loco_files
        String? extract_setlist
        String? interaction_snp
        File? interaction_bed
        File? interaction_bim
        File? interaction_fam
        Boolean interaction_file_reffirst = false
        Boolean no_condtl = false
        Boolean force_condtl = false
    }

    if (run_step1) {
        call regenie_step1 {
            input:
                phenotype_file = phenotype_file,
                covariate_file = select_first([covariate_file]),
                bed_file = select_first([bed_file]),
                bim_file = select_first([bim_file]),
                fam_file = select_first([fam_file]),
                keep_variant_file = select_first([keep_variant_file]),
                keep_sample_file = select_first([keep_sample_file]),
                prefix = prefix,
                phenoColString = phenoColString,
                isbinary = isbinary
        }
    }

    if (!interaction_mode) {
        scatter (i in range(length(chrs))) {
            call regenie_step2 as regenie_step2_burden {
                input:
                    phenotype_file = phenotype_file,
                    covariate_file = covariate_file,
                    bgen_file = select_first([bgen_files])[i],
                    sample_file = select_first([sample_files])[i],
                    index_file = select_first([index_files])[i],
                    set_file = select_first([set_files])[i],
                    anno_file = select_first([anno_files])[i],
                    aaf_file = select_first([aaf_files])[i],
                    mask_file = select_first([mask_files])[i],
                    pred_file = if run_step1 then regenie_step1.pred_file else pred_file,
                    loco_files = if run_step1 then regenie_step1.loco_files else loco_files,
                    prefix = prefix,
                    chrm = chrs[i],
                    phenoColString = phenoColString,
                    isbinary = isbinary,
                    interaction_mode = false,
                    skip_association = skip_association,
                    write_mask = write_mask,
                    ignore_pred = ignore_pred,
                    extract_setlist = extract_setlist
            }
        }
    }

    if (interaction_mode) {
        scatter (i in range(length(chrs))) {
            call regenie_step2 as regenie_step2_interaction {
                input:
                    phenotype_file = phenotype_file,
                    covariate_file = covariate_file,
                    target_bed = select_first([target_bed_files])[i],
                    target_bim = select_first([target_bim_files])[i],
                    target_fam = select_first([target_fam_files])[i],
                    extract_file = extract_file,
                    pred_file = if run_step1 then regenie_step1.pred_file else pred_file,
                    loco_files = if run_step1 then regenie_step1.loco_files else loco_files,
                    prefix = prefix,
                    chrm = chrs[i],
                    phenoColString = phenoColString,
                    isbinary = isbinary,
                    interaction_mode = true,
                    ignore_pred = ignore_pred,
                    interaction_snp = interaction_snp,
                    interaction_bed = interaction_bed,
                    interaction_bim = interaction_bim,
                    interaction_fam = interaction_fam,
                    interaction_file_reffirst = interaction_file_reffirst,
                    no_condtl = no_condtl,
                    force_condtl = force_condtl
            }
        }
    }

    if (!skip_association && !interaction_mode) {
        call merge_regenie_outputs as merge_regenie_outputs_burden {
            input:
                step2_outputs = select_first([regenie_step2_burden.output_results, []]),
                prefix = prefix,
                phenoColList = phenoColList,
                chrs = chrs
        }
    }

    if (!skip_association && interaction_mode) {
        call merge_regenie_outputs as merge_regenie_outputs_interaction {
            input:
                step2_outputs = select_first([regenie_step2_interaction.output_results, []]),
                prefix = prefix,
                phenoColList = phenoColList,
                chrs = chrs
        }
    }

    output {
        Array[File] merged_outputs = if skip_association then [] else select_first([merge_regenie_outputs_burden.merged_files, merge_regenie_outputs_interaction.merged_files])
        Array[File] mask_beds = if interaction_mode then [] else flatten(select_first([regenie_step2_burden.mask_beds, []]))
        Array[File] mask_bims = if interaction_mode then [] else flatten(select_first([regenie_step2_burden.mask_bims, []]))
        Array[File] mask_fams = if interaction_mode then [] else flatten(select_first([regenie_step2_burden.mask_fams, []]))
    }
}
