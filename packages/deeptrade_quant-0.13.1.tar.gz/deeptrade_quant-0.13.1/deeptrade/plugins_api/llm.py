"""LLM调参契约 — 插件作者唯一需要 import 的 LLM 调参类型。

v0.7：Stage 概念彻底退出框架。框架的 ``LLMClient.complete_json`` 不再认识
stage 名字，由调用方直接传入一个已解析好的 ``StageProfile`` 实例；预设档名
（``fast / balanced / quality``）保留为框架级用户配置（``app.profile``），
但**预设档 → 各 stage tuning 的映射表归插件自己维护**。

v0.12：新增 ``LLMReplayPolicy`` / ``LLMReplayMiss`` 公开导出，配合
``LLMClient.complete_json(..., replay=..., stage=..., schema_version=...,
input_fingerprint=...)`` 启用框架级 LLM 响应重放缓存。详见
:mod:`deeptrade.core.llm_replay` 的 module docstring。

插件作者用法：

    from deeptrade.plugins_api import StageProfile, LLMReplayPolicy

    PROFILES: dict[str, dict[str, StageProfile]] = {
        "fast":     {"my_stage": StageProfile(thinking=False, ...)},
        "balanced": {"my_stage": StageProfile(thinking=True,  ...)},
        "quality":  {"my_stage": StageProfile(thinking=True,  ...)},
    }

    def resolve_profile(preset: str, stage: str) -> StageProfile:
        return PROFILES[preset][stage]

随后在 pipeline 中：

    prof = resolve_profile(rt.config.get_app_config().app_profile, "my_stage")
    obj, _ = llm.complete_json(
        system=..., user=..., schema=..., profile=prof,
        stage="my_stage", schema_version="v1",
        input_fingerprint=plugin_computed_hash,
        replay=LLMReplayPolicy(),   # default: read + write enabled
    )
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Literal

from pydantic import BaseModel, ConfigDict, Field

# Re-export the replay types as part of the public plugin API.
from deeptrade.core.llm_replay import LLMReplayMiss, LLMReplayPolicy

if TYPE_CHECKING:  # pragma: no cover — type-only
    from deeptrade.core.config import AppConfig

__all__ = [
    "LLMReplayMiss",
    "LLMReplayPolicy",
    "StageProfile",
    "policy_from_app_config",
    "policy_from_env",
]


class StageProfile(BaseModel):
    """单次 LLM 调用的调参档：四字段对应 OpenAI Chat Completions 协议参数。

    ``thinking`` / ``reasoning_effort`` 在不支持思维链的 provider 上由 transport
    静默丢弃(DeepSeek/Qwen/Kimi/Doubao/GLM/... 各家支持情况不同)。
    """

    model_config = ConfigDict(extra="forbid")

    thinking: bool
    reasoning_effort: Literal["low", "medium", "high"]
    temperature: float = Field(ge=0.0, le=2.0)
    max_output_tokens: int = Field(ge=1024, le=384_000)


# ---------------------------------------------------------------------------
# Environment-driven policy override
# ---------------------------------------------------------------------------


_ENV_TRUTHY = {"1", "true", "yes", "on"}


def _env_flag(name: str) -> bool:
    return os.environ.get(name, "").strip().lower() in _ENV_TRUTHY


def policy_from_app_config(app_config: AppConfig) -> LLMReplayPolicy:
    """Construct an :class:`LLMReplayPolicy` from framework config keys.

    Reads ``llm.replay.enabled`` / ``llm.replay.write`` / ``llm.replay.ttl_days``
    from the materialized :class:`AppConfig` and packages them into a policy
    instance plugins can pass to :func:`LLMClient.complete_json`.

    Semantics:

    * ``read_enabled = llm.replay.enabled``
    * ``write_enabled = llm.replay.enabled AND llm.replay.write``
      — turning off ``enabled`` also disables writes; ``write=false`` while
      ``enabled=true`` allows reads-only (useful on a follower instance
      reading a primary's cache).
    * ``replay_only = False`` — this helper does not encode the
      "fail-fast on miss" semantic; that's a per-invocation policy and
      is exposed only via :meth:`LLMReplayPolicy.replay_only_` or the
      :envvar:`DEEPTRADE_REPLAY_ONLY` env var (see :func:`policy_from_env`).
    * ``ttl_days`` is taken verbatim.

    Typical usage::

        cfg = ctx.config.get_app_config()
        policy = policy_from_env(policy_from_app_config(cfg))

    The ``policy_from_env`` wrapper then layers env-var overrides on top.
    """
    enabled = bool(app_config.llm_replay_enabled)
    write = enabled and bool(app_config.llm_replay_write)
    return LLMReplayPolicy(
        read_enabled=enabled,
        write_enabled=write,
        ttl_days=app_config.llm_replay_ttl_days,
    )


def policy_from_env(base: LLMReplayPolicy | None = None) -> LLMReplayPolicy:
    """Resolve the effective replay policy from environment variables.

    The framework intentionally does NOT intercept plugin CLI argv (the
    plugin dispatch path uses ``ignore_unknown_options=True``), so global
    overrides land here. Plugins that want a uniform UX expose their own
    ``--fresh-llm`` / ``--no-llm-replay`` / ``--replay-only`` switches
    and translate them by calling :func:`policy_from_env` (or by setting
    these environment variables before constructing :class:`LLMReplayPolicy`).

    Env variables (each accepts ``1`` / ``true`` / ``yes`` / ``on``):

    * ``DEEPTRADE_REPLAY_ONLY``    — highest priority. Returns
      :meth:`LLMReplayPolicy.replay_only_`.
    * ``DEEPTRADE_NO_LLM_REPLAY``  — returns :meth:`LLMReplayPolicy.disabled`.
    * ``DEEPTRADE_FRESH_LLM``      — returns :meth:`LLMReplayPolicy.fresh`.

    Conflicts resolve in the order above (REPLAY_ONLY > NO_REPLAY >
    FRESH). When none is set, ``base`` (or a default
    :class:`LLMReplayPolicy`) is returned unchanged.
    """
    if _env_flag("DEEPTRADE_REPLAY_ONLY"):
        return LLMReplayPolicy.replay_only_()
    if _env_flag("DEEPTRADE_NO_LLM_REPLAY"):
        return LLMReplayPolicy.disabled()
    if _env_flag("DEEPTRADE_FRESH_LLM"):
        return LLMReplayPolicy.fresh()
    return base if base is not None else LLMReplayPolicy()
