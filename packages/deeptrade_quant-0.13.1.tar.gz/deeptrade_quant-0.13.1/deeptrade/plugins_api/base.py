"""Plugin contract — api_version "1" (legacy) and "2" (v0.6+).

A plugin is a Python class implementing this Protocol. The framework loads it
via the dotted entrypoint declared in the YAML metadata. The framework knows
NOTHING about the plugin's domain semantics; the plugin owns its own command
parsing, execution, persistence, and output.

``PluginContext`` is the minimal services bundle the framework hands to every
plugin's ``validate_static`` (during install). v0.6 ``api_version="2"``
plugins ALSO receive it at dispatch time, removing the need to reach into
``deeptrade.core.*`` from plugin code.

Dispatch signatures by ``api_version``:

* ``"1"`` — ``def dispatch(self, argv: list[str]) -> int`` (legacy).
  Plugin reaches back into ``deeptrade.core.*`` for DB / config / etc.
* ``"2"`` — ``def dispatch(self, ctx: PluginContext, argv: list[str]) -> int``.
  Framework hands the same ``PluginContext`` shape ``validate_static``
  gets, so plugins can stay on the public surface.

Both versions remain supported; v0.6 does NOT deprecate v1.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

if TYPE_CHECKING:  # pragma: no cover
    from deeptrade.core.config import ConfigService
    from deeptrade.core.db import Database
    from deeptrade.core.run_metadata import RunArtifact, RunMetadata
    from deeptrade.plugins_api.metadata import PluginMetadata


@dataclass
class PluginContext:
    """Minimal services bundle the framework hands to a plugin's
    ``validate_static`` (during install).

    v0.10 H4 — plugins SHOULD construct richer services
    (``LLMManager`` / ``TushareClient``) via the ``make_llm_manager`` /
    ``make_tushare_client`` factory helpers below. The raw ``db`` /
    ``config`` fields remain on the public surface for legacy api_version=2
    plugins, but new code should not need them: the factories handle every
    common wiring (DB handle, config service, plugin_id stamping, run_id
    propagation) and return types exported from :mod:`deeptrade.plugins_api`,
    so plugins never need to import ``deeptrade.core.*``.
    """

    db: Database
    config: ConfigService
    plugin_id: str | None = None
    # Internal: lazily-built ``LLMManager``. Plugins access via
    # :meth:`make_llm_manager`; the manager itself caches per-(name, run_id).
    _llm_manager: Any = field(default=None, repr=False, compare=False)
    # Internal: lazily-built ``RunMetadataStore``. Plugins access via the
    # ``set_run_*`` / ``add_run_artifact`` / ``get_run_metadata`` / ``list_run_artifacts``
    # helpers; the store is per-context (i.e. per-plugin_id).
    _run_metadata_store: Any = field(default=None, repr=False, compare=False)

    def make_llm_manager(self) -> Any:
        """Return the framework's ``LLMManager`` for this context.

        The manager is cached on the context for the lifetime of a single
        plugin dispatch. The return type is ``LLMManager`` (also exported
        as :class:`deeptrade.plugins_api.LLMManager`) — plugins should use
        the ``plugins_api`` import path so they don't reach into ``deeptrade.core``.
        """
        if self._llm_manager is None:
            from deeptrade.core.llm_manager import LLMManager  # noqa: PLC0415

            self._llm_manager = LLMManager(self.db, self.config)
        return self._llm_manager

    def make_report_uploader(self, *, run_id: str | None = None) -> Any:
        """Return a framework-level :class:`ReportUploader` bound to this context.

        The uploader reads ``report.upload.enabled / url / timeout / token``
        from :class:`ConfigService` at call time and writes one
        ``report_uploads`` audit row per upload. ``run_id`` is stamped onto
        every audit row so uploads can be correlated with ``reports/<run_id>/``.

        The return type is :class:`deeptrade.plugins_api.ReportUploader` —
        plugins should use the ``plugins_api`` import path so they don't reach
        into ``deeptrade.core``.
        """
        from deeptrade.core.report_uploader import ReportUploader  # noqa: PLC0415

        return ReportUploader(
            self.db,
            self.config,
            plugin_id=self.plugin_id or "__framework__",
            run_id=run_id,
        )

    def make_tushare_client(
        self,
        *,
        intraday: bool = False,
        max_retries: int = 7,
        run_id: str | None = None,
        event_cb: Callable[[str, str, dict[str, Any]], None] | None = None,
        cache_overrides: dict[str, str] | None = None,
    ) -> Any:
        """Build a ``TushareClient`` wired to this context.

        Reads ``tushare.token`` / ``tushare.rps`` from
        :class:`ConfigService`, stamps the call audit with ``plugin_id``
        and ``run_id`` (so :data:`tushare_calls` rows can be correlated
        with ``reports/<run_id>/``), and selects the production SDK
        transport. ``cache_overrides`` mirrors
        ``deeptrade_plugin.yaml::permissions.tushare_apis.cache_overrides``;
        plugin authors pass the resolved dict directly.

        Raises ``RuntimeError`` when ``tushare.token`` is not configured.
        """
        from deeptrade.core.tushare_client import (  # noqa: PLC0415
            CacheClass,
            TushareClient,
            TushareSDKTransport,
        )

        token = self.config.get("tushare.token")
        if not token:
            raise RuntimeError(
                "tushare.token is not configured; run `deeptrade config set-tushare`"
            )
        app_cfg = self.config.get_app_config()
        plugin_id = self.plugin_id or "__framework__"
        typed_overrides: dict[str, CacheClass] | None = (
            dict(cache_overrides) if cache_overrides else None  # type: ignore[arg-type]
        )
        return TushareClient(
            self.db,
            TushareSDKTransport(str(token)),
            plugin_id=plugin_id,
            rps=app_cfg.tushare_rps,
            intraday=intraday,
            max_retries=max_retries,
            event_cb=event_cb,
            cache_overrides=typed_overrides,
            run_id=run_id,
        )

    # ------------------------------------------------------------------
    # v0.12 — run metadata API (cross-plugin reproducibility)
    # ------------------------------------------------------------------
    #
    # These methods write to framework-owned ``run_metadata`` and
    # ``run_artifacts`` tables. They are independent of (and run in
    # parallel with) the plugin's own ``<prefix>_runs`` table — plugins
    # MUST continue to maintain their own run records for business
    # state. Use these helpers so cross-plugin tooling
    # (``deeptrade run compare`` / ``deeptrade run show``) can correlate
    # runs without joining against plugin-private tables.

    def _run_store(self) -> Any:
        """Return the lazily-built :class:`RunMetadataStore` for this context.

        Cached on the context dataclass. Raises :class:`RuntimeError`
        when ``plugin_id`` is missing — the run metadata tables are
        keyed by ``(plugin_id, run_id)`` and there is no sensible
        sentinel for "anonymous plugin".
        """
        if not self.plugin_id:
            raise RuntimeError(
                "run metadata API requires a PluginContext with plugin_id; "
                "this context is anonymous (typically only happens during "
                "framework self-checks, not plugin dispatch)"
            )
        if self._run_metadata_store is None:
            from deeptrade.core.run_metadata import RunMetadataStore  # noqa: PLC0415

            self._run_metadata_store = RunMetadataStore(self.db, plugin_id=self.plugin_id)
        return self._run_metadata_store

    def set_run_key_date(self, run_id: str, key_date: date | str | None) -> None:
        """Upsert ``run_metadata.key_date`` (typically ``trade_date``).

        Idempotent — call once after the plugin resolves the real date
        (e.g. after Step 0 of a pipeline that takes ``trade_date=null``
        as input). The same value re-applied is a no-op.

        ``key_date=None`` is allowed and writes NULL — useful to clear
        a provisional value.
        """
        self._run_store().set_key_date(run_id, key_date)

    def set_run_input_fingerprint(
        self,
        run_id: str,
        fingerprint: str,
        payload: Any | None = None,
    ) -> None:
        """Upsert ``run_metadata.input_fingerprint`` (+ optional canonical payload).

        ``fingerprint`` is opaque — plugins typically compute it via
        :func:`deeptrade.core.fingerprint.hash_json` over the dict of
        business inputs that produced the run. ``payload`` is that same
        dict (or any JSON-encodable subset); when provided we persist
        its :func:`canonical_json` so ``run compare`` can show field
        diffs. Pass ``payload=None`` when payload size is prohibitive.
        """
        self._run_store().set_input_fingerprint(run_id, fingerprint, payload)

    def add_run_artifact(
        self,
        run_id: str,
        *,
        name: str,
        path: str | Path,
        sha256: str | None = None,
    ) -> Any:
        """Record an artifact file produced by ``run_id``. Returns the persisted
        :class:`RunArtifact`.

        When ``sha256`` is ``None`` the framework streams the file at
        ``path`` through :func:`hash_file` to compute it; the file must
        exist on disk in that case. Pass ``sha256`` explicitly when the
        artifact lives somewhere the framework cannot read (e.g. an
        already-uploaded report URL).

        Re-adding the same ``name`` for the same run REPLACES the prior
        row with a fresh ``artifact_id`` — convenient when a plugin
        regenerates an artifact mid-run.
        """
        return self._run_store().add_artifact(run_id, name=name, path=path, sha256=sha256)

    def get_run_metadata(self, run_id: str) -> RunMetadata | None:
        """Return the ``run_metadata`` row for this plugin / ``run_id``.

        Returns ``None`` when the row does not exist (e.g. the plugin
        never called ``set_run_*``).
        """
        return self._run_store().get(run_id)

    def list_run_artifacts(self, run_id: str) -> list[RunArtifact]:
        """Return all artifacts recorded for this plugin / ``run_id``,
        ordered by ``name``. Empty list when no artifacts exist."""
        return self._run_store().list_artifacts(run_id)


@runtime_checkable
class Plugin(Protocol):
    """The minimal interface a plugin entrypoint class must satisfy."""

    metadata: PluginMetadata

    def validate_static(self, ctx: PluginContext) -> None:
        """Post-install self-check. MUST NOT touch the network.

        Called once by the framework during ``deeptrade plugin install``. Use
        it to verify required tables exist, required config keys are present,
        and the entrypoint class loads cleanly. Raise on failure to abort
        install (the framework will roll back).
        """

    def dispatch(self, *args: object) -> int:
        """CLI dispatch entry point.

        Signature depends on ``metadata.api_version``:

        * ``"1"`` — ``dispatch(self, argv: list[str]) -> int``.
        * ``"2"`` — ``dispatch(self, ctx: PluginContext, argv: list[str]) -> int``.

        ``argv`` is the remaining command-line tail after the framework strips
        the leading ``<plugin_id>`` token. For example, when the user runs
        ``deeptrade limit-up-board run --force-sync``, the plugin receives
        ``argv == ['run', '--force-sync']``.

        The plugin owns parsing, ``--help`` rendering, execution, persistence,
        and output. Returns the process exit code (0 = success).

        The Protocol is declared variadic so ``isinstance(obj, Plugin)`` works
        for both v1 and v2 implementations — ``runtime_checkable`` only
        verifies attribute presence, never argument arity. The framework's
        ``cli._dispatch`` decides which form to call based on
        ``metadata.api_version``.
        """
