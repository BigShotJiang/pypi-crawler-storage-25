"""`deeptrade db llm-cache` subcommand group — inspect / list / purge the
framework LLM replay cache.

The cache itself is written transparently by ``LLMClient.complete_json``
when a non-disabled :class:`LLMReplayPolicy` is in effect (v0.12). This
CLI surface is purely operational: it lets the user inspect what is
cached, list recent entries for a plugin, and prune stale rows.

Safety: ``purge`` is the only destructive verb. It requires ``--yes``
and at least one filter (``--plugin`` / ``--stage`` / ``--before``)
because the store-layer ``ReplayCacheStore.purge()`` already refuses
to delete with no filter — the CLI surfaces that contract instead of
papering over it.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta

import typer
from rich.console import Console
from rich.table import Table

from deeptrade.core import paths
from deeptrade.core.db import Database
from deeptrade.core.llm_replay import ReplayCacheStore

app = typer.Typer(
    help="LLM replay cache 管理 — list / purge / inspect。",
    no_args_is_help=True,
)

_console = Console()


def _short(s: str | None, n: int = 12) -> str:
    if s is None:
        return "—"
    return s if len(s) <= n else s[:n] + "…"


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------


@app.command("list")
def cmd_list(
    plugin: str | None = typer.Option(None, "--plugin", "-p", help="按 plugin_id 过滤"),
    stage: str | None = typer.Option(None, "--stage", "-s", help="按 stage 过滤"),
    limit: int = typer.Option(20, "--limit", "-l", help="最多列出 N 条（按 created_at DESC）"),
    offset: int = typer.Option(0, "--offset", help="跳过前 N 条"),
    format_: str = typer.Option(
        "human",
        "--format",
        "-f",
        help="输出格式：human（默认）/ json",
    ),
) -> None:
    """列出最近的 LLM replay cache 条目。"""
    db = Database(paths.db_path())
    try:
        store = ReplayCacheStore(db)
        entries = list(
            store.iter_entries(plugin_id=plugin, stage=stage, limit=limit, offset=offset)
        )
    finally:
        db.close()

    if format_.lower() == "json":
        typer.echo(
            json.dumps(
                [
                    {
                        "cache_key": e.cache_key,
                        "plugin_id": e.plugin_id,
                        "stage": e.stage,
                        "provider": e.provider,
                        "model": e.model,
                        "prompt_hash": e.prompt_hash,
                        "schema_version": e.schema_version,
                        "source_run_id": e.source_run_id,
                        "created_at": e.created_at.isoformat(),
                    }
                    for e in entries
                ],
                ensure_ascii=False,
                indent=2,
            )
        )
        return

    if not entries:
        _console.print("[dim]no cache entries match[/dim]")
        return

    t = Table(title=f"llm_replay_cache ({len(entries)} of … most recent)", show_lines=False)
    t.add_column("cache_key")
    t.add_column("plugin_id")
    t.add_column("stage")
    t.add_column("provider")
    t.add_column("model")
    t.add_column("schema_v")
    t.add_column("source_run")
    t.add_column("created_at")
    for e in entries:
        t.add_row(
            _short(e.cache_key),
            e.plugin_id,
            e.stage,
            e.provider,
            _short(e.model, 24),
            e.schema_version,
            _short(e.source_run_id, 12) if e.source_run_id else "—",
            e.created_at.isoformat(sep=" ", timespec="seconds"),
        )
    _console.print(t)


# ---------------------------------------------------------------------------
# purge
# ---------------------------------------------------------------------------


@app.command("purge")
def cmd_purge(
    plugin: str | None = typer.Option(None, "--plugin", "-p", help="按 plugin_id 过滤"),
    stage: str | None = typer.Option(None, "--stage", "-s", help="按 stage 过滤"),
    before_days: int | None = typer.Option(
        None,
        "--before",
        "-b",
        help="只删除 created_at 早于 N 天前的条目（N >= 0）",
    ),
    yes: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help="跳过交互确认；高风险写动作，必须显式开启",
    ),
) -> None:
    """删除符合过滤条件的 LLM replay cache 行。

    至少要给一个过滤器（plugin / stage / before），且必须带 ``--yes``。
    没有过滤器时框架层会拒绝执行，避免误清全表。
    """
    if plugin is None and stage is None and before_days is None:
        typer.echo(
            "✘ 拒绝执行：必须至少提供一个过滤器（--plugin / --stage / --before）。\n"
            "  框架层不允许无条件清空全部 cache。"
        )
        raise typer.Exit(2)
    if not yes:
        typer.echo("✘ 这是高风险写动作。请加 `--yes` 显式确认。")
        raise typer.Exit(2)

    db = Database(paths.db_path())
    try:
        store = ReplayCacheStore(db)
        deleted = store.purge(plugin_id=plugin, stage=stage, before_days=before_days)
    finally:
        db.close()
    typer.echo(f"✔ purged {deleted} cache row(s)")


# ---------------------------------------------------------------------------
# inspect
# ---------------------------------------------------------------------------


@app.command("inspect")
def cmd_inspect(
    cache_key: str = typer.Argument(
        ...,
        help="cache_key 全串或唯一前缀（默认 12 字符即可定位）",
    ),
    full: bool = typer.Option(
        False,
        "--full",
        help="展开 response_json 全文（默认仅展示前 200 字符）",
    ),
    format_: str = typer.Option(
        "human",
        "--format",
        "-f",
        help="输出格式：human（默认）/ json",
    ),
) -> None:
    """打印单条 cache row 的全部字段。

    支持前缀匹配：传 ``deeptrade db llm-cache inspect 8c5043c1`` 即可，
    只要该前缀在表中唯一即解析为完整 cache_key；歧义时退出并列出候选。
    """
    db = Database(paths.db_path())
    try:
        rows = db.fetchall(
            "SELECT cache_key, plugin_id, stage, provider, model, prompt_hash, "
            "profile_json, schema_name, schema_version, input_fingerprint, "
            "request_fingerprint_json, response_json, response_meta_json, "
            "source_run_id, source_call_id, created_at "
            "FROM llm_replay_cache WHERE cache_key LIKE ?",
            (cache_key + "%",),
        )
    finally:
        db.close()

    if not rows:
        typer.echo(f"✘ 未找到 cache_key 前缀为 {cache_key!r} 的条目")
        raise typer.Exit(2)
    if len(rows) > 1:
        typer.echo(f"✘ 前缀 {cache_key!r} 命中多条 ({len(rows)})，请提供更长前缀。候选：")
        for r in rows:
            typer.echo(f"  {r[0]}  plugin_id={r[1]}  stage={r[2]}  created_at={r[15]}")
        raise typer.Exit(2)

    (
        full_key,
        plugin_id,
        stage,
        provider,
        model,
        prompt_hash,
        profile_json,
        schema_name,
        schema_version,
        input_fingerprint,
        request_fp_json,
        response_json,
        response_meta_json,
        source_run_id,
        source_call_id,
        created_at,
    ) = rows[0]

    response_dict = json.loads(response_json)
    response_meta = json.loads(response_meta_json)
    profile = json.loads(profile_json)
    request_fp = json.loads(request_fp_json)

    if format_.lower() == "json":
        payload = {
            "cache_key": full_key,
            "plugin_id": plugin_id,
            "stage": stage,
            "provider": provider,
            "model": model,
            "prompt_hash": prompt_hash,
            "profile": profile,
            "schema_name": schema_name,
            "schema_version": schema_version,
            "input_fingerprint": input_fingerprint,
            "request_fingerprint": request_fp,
            "response": response_dict if full else _truncate_response(response_dict),
            "response_meta": response_meta,
            "source_run_id": source_run_id,
            "source_call_id": source_call_id,
            "created_at": created_at.isoformat()
            if hasattr(created_at, "isoformat")
            else created_at,
        }
        typer.echo(json.dumps(payload, ensure_ascii=False, indent=2, default=str))
        return

    _console.print(f"[bold]cache_key[/bold]         {full_key}")
    _console.print(f"[bold]plugin_id[/bold]         {plugin_id}")
    _console.print(f"[bold]stage[/bold]             {stage}")
    _console.print(f"[bold]provider[/bold]          {provider}")
    _console.print(f"[bold]model[/bold]             {model}")
    _console.print(f"[bold]schema[/bold]            {schema_name} ({schema_version})")
    _console.print(f"[bold]prompt_hash[/bold]       {prompt_hash}")
    _console.print(f"[bold]input_fingerprint[/bold] {input_fingerprint or '—'}")
    _console.print(f"[bold]source_run_id[/bold]     {source_run_id or '—'}")
    _console.print(f"[bold]source_call_id[/bold]    {source_call_id or '—'}")
    _console.print(f"[bold]created_at[/bold]        {created_at}")
    _console.print("[bold]profile[/bold]")
    _console.print(json.dumps(profile, ensure_ascii=False, indent=2))
    _console.print("[bold]response_meta[/bold]")
    _console.print(json.dumps(response_meta, ensure_ascii=False, indent=2))
    _console.print("[bold]response[/bold]")
    body = response_dict if full else _truncate_response(response_dict)
    _console.print(json.dumps(body, ensure_ascii=False, indent=2))


def _truncate_response(obj: object) -> object:
    """Truncate a parsed response payload for human inspection.

    Strings longer than 200 characters render as ``"<first 200>…"``;
    nested containers recurse. Lists past 10 elements collapse to ``[…]``.
    """
    if isinstance(obj, str):
        return obj if len(obj) <= 200 else obj[:200] + "…"
    if isinstance(obj, dict):
        return {k: _truncate_response(v) for k, v in obj.items()}
    if isinstance(obj, list):
        if len(obj) > 10:
            return [_truncate_response(x) for x in obj[:10]] + [f"… ({len(obj) - 10} more)"]
        return [_truncate_response(x) for x in obj]
    return obj


# Unused but kept for future "stats" verb; silences mypy on unused import.
_ = (datetime, timedelta)
