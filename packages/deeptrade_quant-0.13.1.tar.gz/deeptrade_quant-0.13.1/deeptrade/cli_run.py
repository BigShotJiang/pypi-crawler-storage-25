"""`deeptrade run` subcommand group — cross-plugin run inspection.

Reads ONLY the framework-level cross-plugin tables written by the v0.12
:class:`PluginContext` API:

* ``run_metadata``  — key date / input fingerprint / canonical input payload
* ``run_artifacts`` — sha256 + path + size per artifact
* ``llm_calls``     — per-call audit (including the v0.12 cache / replay
                      / repair-retry columns)

The framework deliberately does NOT own a unified "runs" table; each
plugin keeps its own ``<prefix>_runs`` with business state. ``deeptrade
run compare`` / ``deeptrade run show`` work uniformly across plugins
because they only read the metadata subset every plugin is expected to
populate.

``run_id`` is plugin-defined and not guaranteed unique across plugins;
when the same ``run_id`` appears for multiple ``plugin_id`` values the
CLI requires ``--plugin`` to disambiguate.
"""

from __future__ import annotations

import json
from collections import OrderedDict
from dataclasses import dataclass
from datetime import datetime
from typing import Any

import typer
from rich.console import Console
from rich.table import Table

from deeptrade.core import paths
from deeptrade.core.db import Database

app = typer.Typer(
    help="跨插件 run 维度的查询与对比（v0.12 复现性基础设施配套 CLI）。",
    no_args_is_help=True,
)

_console = Console()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class _RunRow:
    plugin_id: str
    run_id: str
    key_date: Any
    input_fingerprint: str | None
    input_payload: Any | None
    created_at: datetime
    updated_at: datetime


@dataclass(frozen=True)
class _LLMCall:
    call_id: str
    stage: str | None
    provider: str | None
    model: str | None
    prompt_hash: str | None
    final_prompt_hash: str | None
    cache_hit: bool | None
    validation_status: str | None
    attempt_count: int | None
    source_call_id: str | None


@dataclass(frozen=True)
class _Artifact:
    name: str
    path: str
    sha256: str
    size_bytes: int | None


def _open_db() -> Database:
    return Database(paths.db_path())


def _find_runs(db: Database, run_id: str, plugin: str | None) -> list[_RunRow]:
    if plugin is not None:
        rows = db.fetchall(
            "SELECT plugin_id, run_id, key_date, input_fingerprint, "
            "input_payload_json, created_at, updated_at "
            "FROM run_metadata WHERE plugin_id = ? AND run_id = ?",
            (plugin, run_id),
        )
    else:
        rows = db.fetchall(
            "SELECT plugin_id, run_id, key_date, input_fingerprint, "
            "input_payload_json, created_at, updated_at "
            "FROM run_metadata WHERE run_id = ?",
            (run_id,),
        )
    return [
        _RunRow(
            plugin_id=r[0],
            run_id=r[1],
            key_date=r[2],
            input_fingerprint=r[3],
            input_payload=json.loads(r[4]) if r[4] else None,
            created_at=r[5],
            updated_at=r[6],
        )
        for r in rows
    ]


def _resolve_single_run(db: Database, run_id: str, plugin: str | None) -> _RunRow:
    """Resolve ``run_id`` (+ optional ``plugin``) to exactly one row.

    Exits 2 with a friendly message on ambiguity / not-found.
    """
    rows = _find_runs(db, run_id, plugin)
    if not rows:
        if plugin is not None:
            typer.echo(f"✘ 未找到 run_metadata 行：plugin_id={plugin!r}, run_id={run_id!r}")
        else:
            typer.echo(f"✘ 未找到 run_metadata 行：run_id={run_id!r}（任意 plugin）")
        raise typer.Exit(2)
    if len(rows) > 1:
        plugins = sorted({r.plugin_id for r in rows})
        typer.echo(
            f"✘ run_id={run_id!r} 在多个插件下都存在：{plugins}\n"
            f"  使用 `--plugin <plugin_id>` 明确选择其中一个"
        )
        raise typer.Exit(2)
    return rows[0]


def _llm_calls_for(db: Database, plugin_id: str, run_id: str) -> list[_LLMCall]:
    rows = db.fetchall(
        "SELECT call_id, stage, model, prompt_hash, final_prompt_hash, "
        "cache_hit, validation_status, attempt_count, source_call_id "
        "FROM llm_calls WHERE plugin_id = ? AND run_id = ? "
        "ORDER BY created_at, call_id",
        (plugin_id, run_id),
    )
    return [
        _LLMCall(
            call_id=str(r[0]),
            stage=r[1],
            # ``provider`` is not (yet) a column on llm_calls; the model
            # string is the closest stable provider identifier we have
            # at audit time. compare matches on (stage, model).
            provider=None,
            model=r[2],
            prompt_hash=r[3],
            final_prompt_hash=r[4],
            cache_hit=r[5],
            validation_status=r[6],
            attempt_count=r[7],
            source_call_id=str(r[8]) if r[8] else None,
        )
        for r in rows
    ]


def _artifacts_for(db: Database, plugin_id: str, run_id: str) -> list[_Artifact]:
    rows = db.fetchall(
        "SELECT name, path, sha256, size_bytes FROM run_artifacts "
        "WHERE plugin_id = ? AND run_id = ? ORDER BY name",
        (plugin_id, run_id),
    )
    return [_Artifact(name=r[0], path=r[1], sha256=r[2], size_bytes=r[3]) for r in rows]


def _short(s: str | None, n: int = 12) -> str:
    if s is None:
        return "—"
    return s if len(s) <= n else s[:n] + "…"


# ---------------------------------------------------------------------------
# `deeptrade run show`
# ---------------------------------------------------------------------------


@app.command("show")
def cmd_show(
    run_id: str = typer.Argument(..., help="要查看的 run_id（plugin-defined string）"),
    plugin: str | None = typer.Option(
        None,
        "--plugin",
        "-p",
        help="按插件 ID 过滤；run_id 在多插件下同名时必须使用",
    ),
    format_: str = typer.Option(
        "human",
        "--format",
        "-f",
        help="输出格式：human（默认）/ json",
    ),
) -> None:
    """打印一个 run 的框架元数据（key_date / fingerprint / artifacts / llm_calls）。"""
    db = _open_db()
    try:
        run = _resolve_single_run(db, run_id, plugin)
        calls = _llm_calls_for(db, run.plugin_id, run.run_id)
        artifacts = _artifacts_for(db, run.plugin_id, run.run_id)
    finally:
        db.close()

    if format_.lower() == "json":
        payload = {
            "plugin_id": run.plugin_id,
            "run_id": run.run_id,
            "key_date": run.key_date.isoformat()
            if hasattr(run.key_date, "isoformat")
            else run.key_date,
            "input_fingerprint": run.input_fingerprint,
            "input_payload": run.input_payload,
            "created_at": run.created_at.isoformat(),
            "updated_at": run.updated_at.isoformat(),
            "llm_calls": [
                {
                    "call_id": c.call_id,
                    "stage": c.stage,
                    "model": c.model,
                    "prompt_hash": c.prompt_hash,
                    "final_prompt_hash": c.final_prompt_hash,
                    "cache_hit": c.cache_hit,
                    "validation_status": c.validation_status,
                    "attempt_count": c.attempt_count,
                    "source_call_id": c.source_call_id,
                }
                for c in calls
            ],
            "artifacts": [
                {"name": a.name, "path": a.path, "sha256": a.sha256, "size_bytes": a.size_bytes}
                for a in artifacts
            ],
        }
        typer.echo(json.dumps(payload, ensure_ascii=False, indent=2, default=str))
        return

    _console.print(f"[bold]plugin_id[/bold]   {run.plugin_id}")
    _console.print(f"[bold]run_id[/bold]      {run.run_id}")
    _console.print(f"[bold]key_date[/bold]    {run.key_date or '—'}")
    _console.print(f"[bold]fingerprint[/bold] {_short(run.input_fingerprint, 64) or '—'}")
    _console.print(f"[bold]created_at[/bold]  {run.created_at}")
    _console.print(f"[bold]updated_at[/bold]  {run.updated_at}")

    if calls:
        t = Table(title=f"LLM calls ({len(calls)})", show_lines=False)
        t.add_column("stage")
        t.add_column("model")
        t.add_column("status")
        t.add_column("cache")
        t.add_column("attempts")
        t.add_column("prompt")
        t.add_column("final")
        for c in calls:
            t.add_row(
                c.stage or "—",
                c.model or "—",
                c.validation_status or "—",
                "hit" if c.cache_hit else "miss",
                str(c.attempt_count) if c.attempt_count is not None else "—",
                _short(c.prompt_hash),
                _short(c.final_prompt_hash),
            )
        _console.print(t)
    else:
        _console.print("[dim]no llm_calls recorded for this run[/dim]")

    if artifacts:
        t = Table(title=f"Artifacts ({len(artifacts)})", show_lines=False)
        t.add_column("name")
        t.add_column("sha256")
        t.add_column("size")
        t.add_column("path")
        for a in artifacts:
            t.add_row(
                a.name,
                _short(a.sha256),
                str(a.size_bytes) if a.size_bytes is not None else "—",
                a.path,
            )
        _console.print(t)
    else:
        _console.print("[dim]no artifacts recorded for this run[/dim]")


# ---------------------------------------------------------------------------
# `deeptrade run compare`
# ---------------------------------------------------------------------------


def _diff_basic(a: _RunRow, b: _RunRow) -> list[tuple[str, Any, Any]]:
    """Compare the deterministic basic fields.

    Note ``created_at`` / ``updated_at`` are deliberately excluded: two
    runs by definition execute at different times, so reporting that
    timestamps differ is noise. The point of ``run compare`` is "did
    the same inputs produce the same outputs", not "are these the same
    physical execution".
    """
    out: list[tuple[str, Any, Any]] = []
    for field, av, bv in (
        ("plugin_id", a.plugin_id, b.plugin_id),
        ("key_date", a.key_date, b.key_date),
    ):
        if av != bv:
            out.append((field, av, bv))
    return out


def _diff_fingerprint(a: _RunRow, b: _RunRow) -> dict[str, Any]:
    out: dict[str, Any] = {}
    if a.input_fingerprint != b.input_fingerprint:
        out["fingerprint"] = (a.input_fingerprint, b.input_fingerprint)
    if a.input_payload != b.input_payload:
        out["payload_changed_keys"] = _diff_keys(a.input_payload, b.input_payload)
    return out


def _diff_keys(a: Any, b: Any) -> Any:
    """Return a small dict highlighting where two dicts diverge at the top
    level. For non-dict / mismatched-type payloads, return the raw pair."""
    if not isinstance(a, dict) or not isinstance(b, dict):
        return {"a": a, "b": b}
    keys = sorted(set(a.keys()) | set(b.keys()))
    diff: dict[str, Any] = {}
    for k in keys:
        if a.get(k) != b.get(k):
            diff[k] = {"a": a.get(k), "b": b.get(k)}
    return diff


def _pair_calls(
    a: list[_LLMCall], b: list[_LLMCall]
) -> list[tuple[tuple[str, str | None], _LLMCall | None, _LLMCall | None]]:
    """Pair LLM calls by (stage, model). Order: first stage's first appearance."""
    keyed_a: dict[tuple[str, str | None], _LLMCall] = OrderedDict(
        ((c.stage or "—", c.model), c) for c in a
    )
    keyed_b: dict[tuple[str, str | None], _LLMCall] = OrderedDict(
        ((c.stage or "—", c.model), c) for c in b
    )
    all_keys: list[tuple[str, str | None]] = []
    seen: set[tuple[str, str | None]] = set()
    for k in list(keyed_a.keys()) + list(keyed_b.keys()):
        if k in seen:
            continue
        seen.add(k)
        all_keys.append(k)
    return [(k, keyed_a.get(k), keyed_b.get(k)) for k in all_keys]


def _diff_artifacts(
    a: list[_Artifact], b: list[_Artifact]
) -> list[tuple[str, _Artifact | None, _Artifact | None]]:
    keyed_a = {x.name: x for x in a}
    keyed_b = {x.name: x for x in b}
    names = sorted(set(keyed_a) | set(keyed_b))
    return [(n, keyed_a.get(n), keyed_b.get(n)) for n in names]


@app.command("compare")
def cmd_compare(
    run_a: str = typer.Argument(..., help="第一个 run_id"),
    run_b: str = typer.Argument(..., help="第二个 run_id"),
    plugin: str | None = typer.Option(
        None,
        "--plugin",
        "-p",
        help="按插件 ID 过滤双方；run_id 在多插件下同名时必须使用",
    ),
    format_: str = typer.Option(
        "human",
        "--format",
        "-f",
        help="输出格式：human（默认）/ json",
    ),
) -> None:
    """对比两个 run 的框架元数据：基本信息 / 输入指纹 / LLM 调用 / artifact 摘要。

    不强制两个 run 来自同一插件；跨插件比较时只对齐公共维度。每段都列出
    A / B 双方，不一致处显眼标注。
    """
    db = _open_db()
    try:
        a = _resolve_single_run(db, run_a, plugin)
        b = _resolve_single_run(db, run_b, plugin)
        a_calls = _llm_calls_for(db, a.plugin_id, a.run_id)
        b_calls = _llm_calls_for(db, b.plugin_id, b.run_id)
        a_arts = _artifacts_for(db, a.plugin_id, a.run_id)
        b_arts = _artifacts_for(db, b.plugin_id, b.run_id)
    finally:
        db.close()

    basic = _diff_basic(a, b)
    fp = _diff_fingerprint(a, b)
    paired_calls = _pair_calls(a_calls, b_calls)
    artifact_pairs = _diff_artifacts(a_arts, b_arts)

    if format_.lower() == "json":
        payload = {
            "a": {"plugin_id": a.plugin_id, "run_id": a.run_id},
            "b": {"plugin_id": b.plugin_id, "run_id": b.run_id},
            "basic_diff": [
                {"field": f, "a": _json_safe(av), "b": _json_safe(bv)} for f, av, bv in basic
            ],
            "fingerprint_diff": fp if fp else None,
            "llm_calls": [
                {
                    "stage": k[0],
                    "model": k[1],
                    "a": _call_json(ca),
                    "b": _call_json(cb),
                    "match": _calls_match(ca, cb),
                }
                for k, ca, cb in paired_calls
            ],
            "artifacts": [
                {
                    "name": n,
                    "a": _artifact_json(aa),
                    "b": _artifact_json(bb),
                    "match": _artifacts_equal(aa, bb),
                }
                for n, aa, bb in artifact_pairs
            ],
        }
        typer.echo(json.dumps(payload, ensure_ascii=False, indent=2, default=str))
        return

    # Human-readable: four sections.
    _console.rule("[bold]basic")
    _console.print(f"[bold]A[/bold]  plugin_id={a.plugin_id}  run_id={a.run_id}")
    _console.print(f"[bold]B[/bold]  plugin_id={b.plugin_id}  run_id={b.run_id}")
    if not basic:
        _console.print("[green]✓ basic fields equal[/green]")
    else:
        for field, av, bv in basic:
            _console.print(f"[red]✗ {field}[/red]: A={av!r}  B={bv!r}")

    _console.rule("[bold]input fingerprint")
    if not fp:
        _console.print(
            f"[green]✓ fingerprint identical[/green]  ({_short(a.input_fingerprint, 64) or '—'})"
        )
    else:
        if "fingerprint" in fp:
            af, bf = fp["fingerprint"]
            _console.print(f"[red]✗ fingerprint[/red]: A={_short(af, 64)}  B={_short(bf, 64)}")
        if "payload_changed_keys" in fp:
            _console.print("[red]✗ payload diff[/red]:")
            _console.print(
                json.dumps(fp["payload_changed_keys"], ensure_ascii=False, indent=2, default=str)
            )

    _console.rule("[bold]llm calls")
    if not paired_calls:
        _console.print("[dim]no llm_calls in either run[/dim]")
    else:
        t = Table(show_lines=False)
        t.add_column("stage")
        t.add_column("model")
        t.add_column("A status")
        t.add_column("A cache")
        t.add_column("A prompt")
        t.add_column("B status")
        t.add_column("B cache")
        t.add_column("B prompt")
        t.add_column("match")
        for (stage, model), ca, cb in paired_calls:
            match = _calls_match(ca, cb)
            t.add_row(
                stage,
                model or "—",
                ca.validation_status if ca else "—",
                ("hit" if ca and ca.cache_hit else "miss") if ca else "—",
                _short(ca.prompt_hash) if ca else "—",
                cb.validation_status if cb else "—",
                ("hit" if cb and cb.cache_hit else "miss") if cb else "—",
                _short(cb.prompt_hash) if cb else "—",
                "[green]✓[/green]" if match else "[red]✗[/red]",
            )
        _console.print(t)

    _console.rule("[bold]artifacts")
    if not artifact_pairs:
        _console.print("[dim]no artifacts recorded for either run[/dim]")
    else:
        t = Table(show_lines=False)
        t.add_column("name")
        t.add_column("A sha256")
        t.add_column("B sha256")
        t.add_column("match")
        for name, aa, bb in artifact_pairs:
            same = _artifacts_equal(aa, bb)
            t.add_row(
                name,
                _short(aa.sha256) if aa else "—",
                _short(bb.sha256) if bb else "—",
                "[green]✓[/green]" if same else "[red]✗[/red]",
            )
        _console.print(t)


def _json_safe(v: Any) -> Any:
    if hasattr(v, "isoformat"):
        return v.isoformat()
    return v


def _call_json(c: _LLMCall | None) -> dict[str, Any] | None:
    if c is None:
        return None
    return {
        "validation_status": c.validation_status,
        "cache_hit": c.cache_hit,
        "prompt_hash": c.prompt_hash,
        "final_prompt_hash": c.final_prompt_hash,
        "attempt_count": c.attempt_count,
    }


def _artifact_json(a: _Artifact | None) -> dict[str, Any] | None:
    if a is None:
        return None
    return {"sha256": a.sha256, "size_bytes": a.size_bytes, "path": a.path}


def _calls_match(a: _LLMCall | None, b: _LLMCall | None) -> bool:
    if a is None or b is None:
        return False
    return (
        a.prompt_hash == b.prompt_hash
        and a.final_prompt_hash == b.final_prompt_hash
        and a.validation_status == b.validation_status
    )


def _artifacts_equal(a: _Artifact | None, b: _Artifact | None) -> bool:
    if a is None or b is None:
        return False
    return a.sha256 == b.sha256
