"""LLM response replay cache — framework-level reproducibility infrastructure.

This module provides the data plane for the LLM replay mechanism:

* :class:`LLMReplayPolicy` — value object describing read/write/replay-only
  intent for one ``complete_json`` call. Public API (re-exported by
  :mod:`deeptrade.plugins_api.llm`).
* :class:`LLMReplayMiss` — exception raised when ``replay_only=True`` and
  the cache key is absent. Public API.
* :class:`ReplayCacheStore` — thin DAO over the ``llm_replay_cache`` DuckDB
  table. Framework-internal; plugins never instantiate it directly.

The recipe used to derive ``cache_key`` is the canonical contract:

    cache_key = sha256(canonical_json({
        "v":                 FRAMEWORK_LLM_CACHE_VERSION,
        "plugin_id":         <str>,
        "stage":             <str>,
        "provider":          <str>,
        "model":             <str>,
        "system_sha256":     <hex>,
        "user_sha256":       <hex>,
        "profile":           {"temperature", "max_output_tokens",
                              "thinking", "reasoning_effort"},
        "schema_name":       <str>,
        "schema_version":    <str>,
        "input_fingerprint": <hex | None>,
    }))

Any change to this recipe — adding a field, dropping a field, changing
how a field normalizes — MUST bump :data:`FRAMEWORK_LLM_CACHE_VERSION`
so legacy cache entries miss instead of being interpreted under the new
rules.
"""

from __future__ import annotations

import json
from collections.abc import Iterator
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, ConfigDict

from deeptrade.core.fingerprint import canonical_json, hash_json

if TYPE_CHECKING:  # pragma: no cover — type-only
    from deeptrade.core.db import Database
    from deeptrade.plugins_api.llm import StageProfile


__all__ = [
    "FRAMEWORK_LLM_CACHE_VERSION",
    "CacheEntry",
    "CacheEntrySummary",
    "LLMReplayMiss",
    "LLMReplayPolicy",
    "ReplayCacheStore",
]


# Bumping this constant invalidates EVERY existing cache row across all
# plugins. Reserved for breaking changes to the cache_key recipe — see
# module docstring. Adding a new optional field that defaults to None
# does NOT require a bump, because the same recipe applied to old inputs
# produces the same key.
FRAMEWORK_LLM_CACHE_VERSION: str = "1"


# ---------------------------------------------------------------------------
# Public API: policy + miss exception
# ---------------------------------------------------------------------------


class LLMReplayPolicy(BaseModel):
    """How one ``LLMClient.complete_json`` call should interact with the cache.

    Default is **read-and-write enabled** — this is the recommended
    everyday mode. The convenience constructors cover the three common
    overrides:

    * :meth:`disabled` — bypass cache entirely (no read, no write). Useful
      when the caller knows the response will change every time
      (e.g. streaming heartbeat probes).
    * :meth:`fresh` — skip cache read, still write on success. The standard
      "I want to ask the LLM again, but next run should reuse mine."
    * :meth:`replay_only_` — read-only; raise :class:`LLMReplayMiss` on a
      cache miss instead of calling the provider. Used by offline
      reproduction / CI / diff-mode runs that must never spend tokens.

    ``cache_namespace`` defaults to ``plugin_id`` (the framework fills
    this in when building the effective policy); tests may override it
    to isolate fixtures from real cache rows.

    ``ttl_days`` is checked at read time; an entry older than ``ttl_days``
    is treated as a miss (and not deleted — purge is a separate command).
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    read_enabled: bool = True
    write_enabled: bool = True
    replay_only: bool = False
    cache_namespace: str | None = None
    ttl_days: int | None = None

    @classmethod
    def disabled(cls) -> LLMReplayPolicy:
        return cls(read_enabled=False, write_enabled=False)

    @classmethod
    def fresh(cls) -> LLMReplayPolicy:
        return cls(read_enabled=False, write_enabled=True)

    @classmethod
    def replay_only_(cls) -> LLMReplayPolicy:
        # Trailing underscore avoids shadowing the ``replay_only`` field
        # while still reading as the natural verb on the classmethod.
        return cls(read_enabled=True, write_enabled=False, replay_only=True)

    @property
    def any_cache_active(self) -> bool:
        """True when this call needs cache_key materialization (read OR write)."""
        return self.read_enabled or self.write_enabled


class LLMReplayMiss(Exception):
    """Raised when ``LLMReplayPolicy.replay_only=True`` and the cache misses.

    Attributes hint the operator at *which* lookup missed so they can
    decide whether to bump ``schema_version``, change profile, or
    drop ``replay_only``.
    """

    def __init__(
        self,
        *,
        cache_key: str,
        plugin_id: str | None = None,
        stage: str | None = None,
        message: str | None = None,
    ) -> None:
        self.cache_key = cache_key
        self.plugin_id = plugin_id
        self.stage = stage
        super().__init__(
            message
            or (
                f"replay-only LLM call missed cache "
                f"(plugin_id={plugin_id!r}, stage={stage!r}, "
                f"cache_key={cache_key[:12]!r}...)"
            )
        )


# ---------------------------------------------------------------------------
# Store
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CacheEntry:
    """Materialized result of a successful cache read.

    The store re-validates ``response_json`` against the caller's Pydantic
    schema; ``response_dict`` is the parsed JSON before validation,
    ``response_meta`` is the audit dict from the original successful call.
    """

    cache_key: str
    response_dict: Any
    response_meta: dict[str, Any]
    source_run_id: str | None
    source_call_id: str | None
    created_at: datetime
    schema_version: str
    stage: str


@dataclass(frozen=True)
class CacheEntrySummary:
    """Light row for listing — no payloads."""

    cache_key: str
    plugin_id: str
    stage: str
    provider: str
    model: str
    prompt_hash: str
    schema_version: str
    source_run_id: str | None
    created_at: datetime


class ReplayCacheStore:
    """Thin DAO over the ``llm_replay_cache`` DuckDB table.

    Not thread-safe in its own right; relies on
    :class:`~deeptrade.core.db.Database`'s single-writer RLock for
    serialization. All methods are short transactions (read or single
    INSERT/DELETE).
    """

    def __init__(self, db: Database) -> None:
        self._db = db

    # --- key derivation ------------------------------------------------

    @staticmethod
    def make_cache_key(
        *,
        plugin_id: str,
        stage: str,
        provider: str,
        model: str,
        system_sha256: str,
        user_sha256: str,
        profile: StageProfile,
        schema_name: str,
        schema_version: str,
        input_fingerprint: str | None,
    ) -> tuple[str, dict[str, Any]]:
        """Compute ``cache_key`` AND return the fingerprint dict.

        Returns ``(cache_key, request_fingerprint_dict)``. The dict is
        the canonical-JSON-able payload that produced the hash; callers
        persist it verbatim into ``request_fingerprint_json`` so the
        recipe is auditable from the row alone.

        Argument constraints (raise ``ValueError``):
            * ``plugin_id`` / ``stage`` / ``provider`` / ``model`` /
              ``schema_name`` / ``schema_version`` must be non-empty.
            * ``profile`` must be a :class:`StageProfile`.
            * ``input_fingerprint`` is optional.
        """
        for label, value in (
            ("plugin_id", plugin_id),
            ("stage", stage),
            ("provider", provider),
            ("model", model),
            ("schema_name", schema_name),
            ("schema_version", schema_version),
            ("system_sha256", system_sha256),
            ("user_sha256", user_sha256),
        ):
            if not isinstance(value, str) or not value:
                raise ValueError(f"make_cache_key: {label!r} must be a non-empty str")
        # Local import — avoid circular import with deeptrade.plugins_api.llm,
        # which re-exports LLMReplayPolicy/LLMReplayMiss from this module.
        from deeptrade.plugins_api.llm import StageProfile  # noqa: PLC0415

        if not isinstance(profile, StageProfile):
            raise ValueError(
                f"make_cache_key: profile must be a StageProfile, got {type(profile).__name__}"
            )

        fingerprint: dict[str, Any] = {
            "v": FRAMEWORK_LLM_CACHE_VERSION,
            "plugin_id": plugin_id,
            "stage": stage,
            "provider": provider,
            "model": model,
            "system_sha256": system_sha256,
            "user_sha256": user_sha256,
            "profile": {
                "temperature": profile.temperature,
                "max_output_tokens": profile.max_output_tokens,
                "thinking": profile.thinking,
                "reasoning_effort": profile.reasoning_effort,
            },
            "schema_name": schema_name,
            "schema_version": schema_version,
            "input_fingerprint": input_fingerprint,
        }
        return hash_json(fingerprint), fingerprint

    # --- read ----------------------------------------------------------

    def lookup(self, cache_key: str, *, ttl_days: int | None = None) -> CacheEntry | None:
        """Return the entry for ``cache_key`` or ``None`` (miss / expired).

        ``ttl_days`` is enforced here: an entry whose ``created_at`` is
        older than ``ttl_days`` reports a miss but is NOT deleted (purge
        is a separate command).
        """
        row = self._db.fetchone(
            "SELECT cache_key, stage, schema_version, response_json, response_meta_json, "
            "source_run_id, source_call_id, created_at "
            "FROM llm_replay_cache WHERE cache_key = ?",
            (cache_key,),
        )
        if row is None:
            return None
        (
            key,
            stage,
            schema_version,
            response_json,
            response_meta_json,
            source_run_id,
            source_call_id,
            created_at,
        ) = row
        if ttl_days is not None and ttl_days >= 0:
            if not isinstance(created_at, datetime):
                # DuckDB returns datetime; defensive fallback for None.
                return None
            if datetime.now() - created_at > timedelta(days=ttl_days):
                return None
        return CacheEntry(
            cache_key=key,
            response_dict=json.loads(response_json),
            response_meta=json.loads(response_meta_json),
            source_run_id=source_run_id,
            source_call_id=source_call_id,
            created_at=created_at,
            schema_version=schema_version,
            stage=stage,
        )

    # --- write ---------------------------------------------------------

    def store(
        self,
        *,
        cache_key: str,
        plugin_id: str,
        stage: str,
        provider: str,
        model: str,
        prompt_hash: str,
        profile: StageProfile,
        schema_name: str,
        schema_version: str,
        input_fingerprint: str | None,
        request_fingerprint: dict[str, Any],
        response_dict: Any,
        response_meta: dict[str, Any],
        source_run_id: str | None,
        source_call_id: str | None,
    ) -> None:
        """Upsert a cache row keyed by ``cache_key``.

        Re-writing the same key (e.g. a manual ``--fresh-llm`` after
        provider-side change) is allowed; the most recent write wins.
        DuckDB's ``INSERT ... ON CONFLICT (cache_key) DO UPDATE`` is the
        canonical mechanism; falling back to delete+insert keeps this
        portable to older DuckDB versions if needed.
        """
        profile_json = canonical_json(
            {
                "temperature": profile.temperature,
                "max_output_tokens": profile.max_output_tokens,
                "thinking": profile.thinking,
                "reasoning_effort": profile.reasoning_effort,
            }
        )
        request_fp_json = canonical_json(request_fingerprint)
        response_json = canonical_json(response_dict)
        response_meta_json = canonical_json(response_meta)

        with self._db.transaction():
            self._db.execute(
                "INSERT INTO llm_replay_cache("
                "cache_key, plugin_id, stage, provider, model, prompt_hash, "
                "profile_json, schema_name, schema_version, input_fingerprint, "
                "request_fingerprint_json, response_json, response_meta_json, "
                "source_run_id, source_call_id"
                ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) "
                "ON CONFLICT (cache_key) DO UPDATE SET "
                "  plugin_id = EXCLUDED.plugin_id, "
                "  stage = EXCLUDED.stage, "
                "  provider = EXCLUDED.provider, "
                "  model = EXCLUDED.model, "
                "  prompt_hash = EXCLUDED.prompt_hash, "
                "  profile_json = EXCLUDED.profile_json, "
                "  schema_name = EXCLUDED.schema_name, "
                "  schema_version = EXCLUDED.schema_version, "
                "  input_fingerprint = EXCLUDED.input_fingerprint, "
                "  request_fingerprint_json = EXCLUDED.request_fingerprint_json, "
                "  response_json = EXCLUDED.response_json, "
                "  response_meta_json = EXCLUDED.response_meta_json, "
                "  source_run_id = EXCLUDED.source_run_id, "
                "  source_call_id = EXCLUDED.source_call_id, "
                "  created_at = now()",  # DuckDB rejects bare CURRENT_TIMESTAMP in ON CONFLICT SET
                (
                    cache_key,
                    plugin_id,
                    stage,
                    provider,
                    model,
                    prompt_hash,
                    profile_json,
                    schema_name,
                    schema_version,
                    input_fingerprint,
                    request_fp_json,
                    response_json,
                    response_meta_json,
                    source_run_id,
                    source_call_id,
                ),
            )

    # --- ops -----------------------------------------------------------

    def purge(
        self,
        *,
        plugin_id: str | None = None,
        stage: str | None = None,
        before_days: int | None = None,
    ) -> int:
        """Delete cache rows matching the given filters. Returns row count.

        At least one filter MUST be supplied — purging the entire cache
        in one call would be a footgun and the CLI ``db llm-cache purge``
        wrapper enforces the same guarantee at the UX layer. Here we
        raise ``ValueError`` rather than letting an empty WHERE through.
        """
        if plugin_id is None and stage is None and before_days is None:
            raise ValueError(
                "purge: refuse to delete with no filter — pass plugin_id, stage, "
                "or before_days (use TRUNCATE manually if a full wipe is really wanted)"
            )
        where: list[str] = []
        params: list[Any] = []
        if plugin_id is not None:
            where.append("plugin_id = ?")
            params.append(plugin_id)
        if stage is not None:
            where.append("stage = ?")
            params.append(stage)
        if before_days is not None:
            if before_days < 0:
                raise ValueError("purge: before_days must be >= 0")
            cutoff = datetime.now() - timedelta(days=before_days)
            where.append("created_at < ?")
            params.append(cutoff)
        sql = "DELETE FROM llm_replay_cache WHERE " + " AND ".join(where)
        with self._db.transaction():
            before = self._db.fetchone("SELECT COUNT(*) FROM llm_replay_cache")
            self._db.execute(sql, params)
            after = self._db.fetchone("SELECT COUNT(*) FROM llm_replay_cache")
        b = int(before[0]) if before else 0
        a = int(after[0]) if after else 0
        return b - a

    def iter_entries(
        self,
        *,
        plugin_id: str | None = None,
        stage: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> Iterator[CacheEntrySummary]:
        """Yield light summaries for ``db llm-cache list``."""
        if limit <= 0:
            raise ValueError("iter_entries: limit must be > 0")
        if offset < 0:
            raise ValueError("iter_entries: offset must be >= 0")

        where: list[str] = []
        params: list[Any] = []
        if plugin_id is not None:
            where.append("plugin_id = ?")
            params.append(plugin_id)
        if stage is not None:
            where.append("stage = ?")
            params.append(stage)
        sql = (
            "SELECT cache_key, plugin_id, stage, provider, model, prompt_hash, "
            "schema_version, source_run_id, created_at "
            "FROM llm_replay_cache"
        )
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY created_at DESC LIMIT ? OFFSET ?"
        params.extend([limit, offset])
        for row in self._db.fetchall(sql, params):
            yield CacheEntrySummary(
                cache_key=row[0],
                plugin_id=row[1],
                stage=row[2],
                provider=row[3],
                model=row[4],
                prompt_hash=row[5],
                schema_version=row[6],
                source_run_id=row[7],
                created_at=row[8],
            )
