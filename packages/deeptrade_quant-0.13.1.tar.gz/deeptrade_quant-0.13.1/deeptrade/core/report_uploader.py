"""Report upload — framework-level primitive (v0.11+).

Was previously implemented per-plugin (e.g. ``limit_up_board/uploader.py``);
v0.11 抬升为框架基础能力。设计要点：

* **Stdlib-only**：继续用 ``urllib`` 拼 multipart/form-data，不引入 ``requests``，
  保持 framework wheel 体积不变。
* **永不抛**：``upload()`` 在内部 catch 全部网络/HTTP/JSON 异常，转译成
  ``UploadResult(status="failed", error_class=..., error=...)``。``UploadError``
  仍作为公共类型导出，便于极端调用方在外层显式处理。
* **统一审计**：每次调用（含 skipped）写一条 ``report_uploads`` 行，
  ``token`` / ``Authorization`` 永远不落库。
* **配置统一来源**：``ReportUploader`` 自己从 :class:`ConfigService` 读
  ``report.upload.enabled / url / timeout / token``；插件只传文件与业务元数据。

服务端契约不变（沿用 v0.12+）::

    POST <report.upload.url>
    Authorization: Bearer <token>          # token 为空时省略
    Content-Type: multipart/form-data; boundary=...
    field "file"        — .json 报告
    field "plugin_name" — 插件中文名
    field "trade_date"  — YYYYMMDD

200 OK 时返回::

    {"success": true, "url": "...", "pathname": "...", "index": 1, "date": "..."}
"""

from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

if TYPE_CHECKING:  # pragma: no cover
    from deeptrade.core.config import ConfigService
    from deeptrade.core.db import Database

UploadStatus = Literal["ok", "skipped_disabled", "skipped_missing_file", "failed"]


class UploadError(Exception):
    """Any failure while uploading the report.

    ``ReportUploader.upload`` does NOT raise this — it catches internally and
    returns :class:`UploadResult` with ``status="failed"``. Exported as a
    public type so callers that want raise-style behavior can build it
    themselves.
    """


@dataclass(frozen=True)
class UploadResult:
    """Outcome of a single :meth:`ReportUploader.upload` call.

    ``status`` taxonomy:

    * ``"ok"``                    — 服务端 200 + JSON object 应答；``public_url`` 必非空
    * ``"skipped_disabled"``      — ``report.upload.enabled`` 为 False
    * ``"skipped_missing_file"``  — 文件不存在或非 ``.json`` 后缀
    * ``"failed"``                — 网络/HTTP/JSON 解析任意失败；``error_class``/``error`` 必非空
    """

    status: UploadStatus
    duration_ms: float
    public_url: str | None = None
    public_path: str | None = None
    public_index: int | None = None
    public_date: str | None = None
    http_status: int | None = None
    error_class: str | None = None
    error: str | None = None


class ReportUploader:
    """Framework-level report-upload service. Construct via
    :meth:`PluginContext.make_report_uploader` (preferred) or directly with
    a ``Database`` + ``ConfigService`` for advanced cases (tests / scripts).

    One instance is cheap to create and stateless beyond the bound
    ``plugin_id`` / ``run_id`` audit tag — re-use or re-create freely.
    """

    def __init__(
        self,
        db: Database,
        config: ConfigService,
        *,
        plugin_id: str,
        run_id: str | None = None,
    ) -> None:
        self._db = db
        self._config = config
        self._plugin_id = plugin_id or "__framework__"
        self._run_id = run_id

    # ------------------------------------------------------------------
    # public surface
    # ------------------------------------------------------------------

    def upload(
        self,
        json_path: Path,
        *,
        plugin_name: str,
        trade_date: str,
        extra_fields: dict[str, str] | None = None,
    ) -> UploadResult:
        """POST *json_path* to the configured endpoint and audit the outcome.

        Reads framework config (``report.upload.enabled / url / timeout /
        token``) at call time. ``plugin_name`` / ``trade_date`` are merged
        into the multipart body alongside any ``extra_fields``; explicit
        keys in ``extra_fields`` win over the named arguments (escape
        hatch — same key collision policy as ``dict.update``).

        Returns a :class:`UploadResult` describing the outcome. Never raises:
        all failure modes (file missing, HTTP non-2xx, network error,
        malformed JSON) are encoded into the result.
        """
        t0 = time.monotonic()
        enabled = bool(self._config.get("report.upload.enabled"))
        if not enabled:
            result = UploadResult(
                status="skipped_disabled",
                duration_ms=(time.monotonic() - t0) * 1000.0,
            )
            self._audit(json_path, plugin_name, trade_date, result)
            return result

        if not json_path.is_file() or json_path.suffix.lower() != ".json":
            result = UploadResult(
                status="skipped_missing_file",
                duration_ms=(time.monotonic() - t0) * 1000.0,
            )
            self._audit(json_path, plugin_name, trade_date, result)
            return result

        url = str(self._config.get("report.upload.url"))
        timeout_raw = self._config.get("report.upload.timeout")
        timeout = float(timeout_raw) if timeout_raw is not None else 30.0
        token = self._config.get("report.upload.token")
        token_str = str(token) if token else ""

        # Build multipart body once so audit's file_bytes is the actual file
        # size (not body size). Read separately so we can record bytes even
        # if the POST fails — useful for diagnosing oversize uploads.
        payload = json_path.read_bytes()
        file_bytes = len(payload)
        fields: dict[str, str] = {
            "plugin_name": plugin_name,
            "trade_date": trade_date,
        }
        if extra_fields:
            fields.update(extra_fields)

        boundary = f"----DeepTradeBoundary{uuid.uuid4().hex}"
        body = _build_multipart(
            boundary,
            field_name="file",
            filename=json_path.name,
            content=payload,
            mime="application/json",
            text_fields=fields,
        )

        headers: dict[str, str] = {
            "Content-Type": f"multipart/form-data; boundary={boundary}",
            "Content-Length": str(len(body)),
        }
        if token_str:
            headers["Authorization"] = f"Bearer {token_str}"

        req = Request(url, data=body, method="POST", headers=headers)

        http_status: int | None = None
        try:
            with urlopen(req, timeout=timeout) as resp:
                raw = resp.read()
                http_status = getattr(resp, "status", None) or resp.getcode()
            if http_status != 200:
                result = UploadResult(
                    status="failed",
                    duration_ms=(time.monotonic() - t0) * 1000.0,
                    http_status=http_status,
                    error_class="UploadError",
                    error=f"unexpected status {http_status}",
                )
                self._audit(json_path, plugin_name, trade_date, result, file_bytes=file_bytes)
                return result
            decoded = json.loads(raw.decode("utf-8"))
            if not isinstance(decoded, dict):
                result = UploadResult(
                    status="failed",
                    duration_ms=(time.monotonic() - t0) * 1000.0,
                    http_status=http_status,
                    error_class="UploadError",
                    error=f"unexpected JSON shape (not an object): {type(decoded).__name__}",
                )
                self._audit(json_path, plugin_name, trade_date, result, file_bytes=file_bytes)
                return result
        except HTTPError as exc:
            try:
                body_text = exc.read().decode("utf-8", errors="replace")[:200]
            except Exception:  # noqa: BLE001 — best-effort error body extraction
                body_text = ""
            result = UploadResult(
                status="failed",
                duration_ms=(time.monotonic() - t0) * 1000.0,
                http_status=exc.code,
                error_class=type(exc).__name__,
                error=f"HTTP {exc.code}: {body_text or exc.reason}",
            )
            self._audit(json_path, plugin_name, trade_date, result, file_bytes=file_bytes)
            return result
        except (URLError, TimeoutError) as exc:
            result = UploadResult(
                status="failed",
                duration_ms=(time.monotonic() - t0) * 1000.0,
                error_class=type(exc).__name__,
                error=f"network error: {exc}",
            )
            self._audit(json_path, plugin_name, trade_date, result, file_bytes=file_bytes)
            return result
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            result = UploadResult(
                status="failed",
                duration_ms=(time.monotonic() - t0) * 1000.0,
                http_status=http_status,
                error_class=type(exc).__name__,
                error=f"invalid JSON response: {exc}",
            )
            self._audit(json_path, plugin_name, trade_date, result, file_bytes=file_bytes)
            return result
        except Exception as exc:  # noqa: BLE001 — upload must never bubble
            result = UploadResult(
                status="failed",
                duration_ms=(time.monotonic() - t0) * 1000.0,
                http_status=http_status,
                error_class=type(exc).__name__,
                error=str(exc),
            )
            self._audit(json_path, plugin_name, trade_date, result, file_bytes=file_bytes)
            return result

        result = UploadResult(
            status="ok",
            duration_ms=(time.monotonic() - t0) * 1000.0,
            http_status=http_status,
            public_url=_opt_str(decoded.get("url")),
            public_path=_opt_str(decoded.get("pathname")),
            public_index=_opt_int(decoded.get("index")),
            public_date=_opt_str(decoded.get("date")),
        )
        self._audit(json_path, plugin_name, trade_date, result, file_bytes=file_bytes)
        return result

    # ------------------------------------------------------------------
    # internals
    # ------------------------------------------------------------------

    def _audit(
        self,
        json_path: Path,
        plugin_name: str,
        trade_date: str,
        result: UploadResult,
        *,
        file_bytes: int | None = None,
    ) -> None:
        """Insert one ``report_uploads`` row. Best-effort: a logging failure
        here must NEVER mask the upload result, so any DB error is swallowed."""
        try:
            self._db.execute(
                """
                INSERT INTO report_uploads(
                    upload_id, plugin_id, run_id, trade_date, plugin_name,
                    file_path, file_bytes, status, http_status,
                    public_url, public_path, duration_ms, error_class, error
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    str(uuid.uuid4()),
                    self._plugin_id,
                    self._run_id,
                    trade_date,
                    plugin_name,
                    str(json_path),
                    file_bytes,
                    result.status,
                    result.http_status,
                    result.public_url,
                    result.public_path,
                    result.duration_ms,
                    result.error_class,
                    result.error,
                ),
            )
        except Exception:  # noqa: BLE001 — audit row is best-effort
            pass


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def _build_multipart(
    boundary: str,
    *,
    field_name: str,
    filename: str,
    content: bytes,
    mime: str,
    text_fields: dict[str, str] | None = None,
) -> bytes:
    """Assemble a multipart/form-data body: text parts (if any) + file part."""
    parts: list[bytes] = []
    for name, value in (text_fields or {}).items():
        parts.append(
            (
                f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n'
            ).encode()
        )
    file_head = (
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="{field_name}"; '
        f'filename="{filename}"\r\n'
        f"Content-Type: {mime}\r\n\r\n"
    ).encode()
    tail = f"\r\n--{boundary}--\r\n".encode("ascii")
    return b"".join(parts) + file_head + content + tail


def _opt_str(v: Any) -> str | None:
    return str(v) if isinstance(v, str) and v else None


def _opt_int(v: Any) -> int | None:
    if isinstance(v, bool):
        return None
    return int(v) if isinstance(v, int) else None
