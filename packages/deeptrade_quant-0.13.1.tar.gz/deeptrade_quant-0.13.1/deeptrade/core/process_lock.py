"""Cross-process advisory lock for framework write operations.

DuckDB enforces single-writer at the database-file level, but the framework
mutates state outside the DB too: the plugin install tree under
``~/.deeptrade/plugins/installed/``, dep snapshots, and the registry cache.
Two concurrent ``deeptrade plugin install`` invocations would race on those
directories even when DuckDB rejects the second connection.

Implementation: stdlib only — ``fcntl.flock`` on POSIX, ``msvcrt.locking``
on Windows. The lock file (``~/.deeptrade/writers.lock``) is created lazily
and persists across invocations; the advisory lock itself is released when
the owning process exits, even on hard crash.

Scope: wrap ``PluginManager.install / upgrade / uninstall``. The lock is NOT
held during ``Database()`` open (auto-migrate runs there and would serialize
every read-only CLI command); DuckDB's own file lock already covers writes
to the schema_migrations table.
"""

from __future__ import annotations

import sys
import time
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import IO, Any

from deeptrade.core import paths

LOCK_FILENAME = "writers.lock"
DEFAULT_TIMEOUT_SECONDS = 30.0


class ProcessLockTimeoutError(RuntimeError):
    """Another DeepTrade process is holding the framework write lock.

    Raised when the wait exceeds ``timeout``. The hint embedded in the
    message names the lock file so the user can stat it or, in the rare
    case of a stuck lock, remove it manually.
    """


@contextmanager
def framework_lock(
    *, timeout: float = DEFAULT_TIMEOUT_SECONDS, lock_path: Path | None = None
) -> Iterator[None]:
    """Acquire the framework's process-level write lock.

    Use around plugin install / upgrade / uninstall. The lock is advisory:
    only callers that take it are serialized. The yield runs while the
    lock is held; on context exit the lock is released even if the wrapped
    block raised.
    """
    resolved = lock_path
    if resolved is None:
        paths.ensure_layout()
        resolved = paths.home_dir() / LOCK_FILENAME
    resolved.parent.mkdir(parents=True, exist_ok=True)

    fh: IO[Any] = open(resolved, "a+")  # noqa: SIM115 — closed in finally
    try:
        deadline = time.monotonic() + timeout
        while True:
            try:
                _try_lock(fh)
                break
            except (BlockingIOError, OSError):
                if time.monotonic() >= deadline:
                    raise ProcessLockTimeoutError(
                        f"another DeepTrade process is modifying {paths.home_dir()}; "
                        f"waited {timeout:.0f}s on {resolved}. Retry once the other "
                        f"CLI command finishes, or remove the lock file manually if "
                        f"no other deeptrade process is running."
                    ) from None
                time.sleep(0.1)
        try:
            yield
        finally:
            _unlock(fh)
    finally:
        fh.close()


def _try_lock(fh: IO[Any]) -> None:
    if sys.platform == "win32":
        import msvcrt  # noqa: PLC0415

        msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
    else:
        import fcntl  # noqa: PLC0415

        fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)


def _unlock(fh: IO[Any]) -> None:
    if sys.platform == "win32":
        import msvcrt  # noqa: PLC0415

        try:
            msvcrt.locking(fh.fileno(), msvcrt.LK_UNLCK, 1)
        except OSError:
            pass
    else:
        import fcntl  # noqa: PLC0415

        fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
