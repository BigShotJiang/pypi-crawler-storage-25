"""Canonical serialization and content-addressed hashing for framework reproducibility.

This module is the **base layer** under the LLM replay cache and the
cross-plugin ``run_metadata`` API. Every cache key, every run input
fingerprint, every artifact hash flows through one of the five public
helpers here. The rules in this module are therefore frozen as a versioned
contract: if any rule changes (e.g. how a ``datetime`` is encoded), the
LLM replay cache's ``FRAMEWORK_LLM_CACHE_VERSION`` must be bumped so
historical cache entries miss instead of being interpreted with the new
rules.

Public API
----------

``canonical_json(obj) -> str``
    Deterministic JSON encoding. Keys sorted, ASCII not forced, separators
    tight, with explicit handling for ``datetime`` / ``Decimal`` / numpy
    scalars / pandas timestamps / ``BaseModel`` instances / bytes.

``hash_json(obj) -> str``
    ``sha256(canonical_json(obj))`` — the only correct way to hash a Python
    object across processes.

``hash_text(text) -> str``
    ``sha256(text.encode("utf-8"))``.

``hash_dataframe(df, *, sort_by, columns=None) -> str``
    DataFrame hash; ``sort_by`` is REQUIRED to remove row-order ambiguity.

``hash_file(path, *, chunk_size=1 MiB) -> str``
    Streaming file hash.

Strict rules (intentional, do NOT relax silently)
-------------------------------------------------

* ``float('nan')`` / ``float('inf')`` raise ``ValueError``. NaN/Inf have
  no canonical JSON encoding; allowing them would let two ``hash_json``
  calls on the "same" object on different platforms produce different
  strings.
* ``set`` / ``frozenset`` / ``dict_keys`` / generators raise
  ``TypeError``. Sets carry no order; callers must convert to a
  deterministically-sorted list first.
* Naive ``datetime`` / ``date`` are encoded as ISO-8601 *without* a "Z"
  suffix. Aware datetimes use the offset they carry. The encoding does
  NOT silently coerce timezone — callers worried about cross-zone
  comparability are expected to normalize before hashing.
* ``hash_dataframe`` requires an explicit ``sort_by`` argument; an
  unsorted DataFrame has no canonical row order.
"""

from __future__ import annotations

import base64
import hashlib
import json
import math
from collections.abc import Sequence
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel

if TYPE_CHECKING:  # pragma: no cover — pandas is plugin-runtime only
    import pandas as pd


__all__ = [
    "canonical_json",
    "hash_json",
    "hash_text",
    "hash_dataframe",
    "hash_file",
]


# Module-private sentinel for "unsupported type"; raising directly keeps
# the public surface (canonical_json) free of an extension hook in v1.
class _NotEncodable(TypeError):
    """Internal — translated to ``TypeError`` at the public boundary."""


def _to_canonical(obj: Any) -> Any:
    """Convert ``obj`` to a tree of JSON-native values (dict/list/str/int/float/bool/None).

    The result is a Python object that ``json.dumps`` with the canonical
    arguments can encode reproducibly. Every conversion is value-only —
    we never preserve class identity in the encoding.
    """
    # Fast path for JSON-native primitives
    if obj is None or isinstance(obj, bool):
        return obj
    if isinstance(obj, int):
        # bool is also int — handled above
        return obj
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError(
                "canonical_json: NaN/Inf are not encodable; "
                "callers must replace them with None or a sentinel before hashing"
            )
        return obj
    if isinstance(obj, str):
        return obj

    # Decimal — preserve the literal string form so 1.10 != 1.1
    if isinstance(obj, Decimal):
        return str(obj)

    # bytes / bytearray — base64-encode (deterministic, RFC 4648)
    if isinstance(obj, (bytes, bytearray)):
        return base64.b64encode(bytes(obj)).decode("ascii")

    # Reject pandas NaT before the datetime branch — NaT is an
    # ``isinstance(datetime)`` *and* its ``isoformat()`` returns the
    # literal string "NaT" instead of raising. Allowing that through
    # would silently hash all NaT values to the same key as the string
    # "NaT", a textbook reproducibility bug.
    if type(obj).__name__ == "NaTType":
        raise ValueError("canonical_json: pandas NaT is not encodable")

    # datetime BEFORE date: datetime IS a date, isinstance(d, date) is True
    if isinstance(obj, datetime):
        # isoformat keeps timezone offset if present; naive datetimes
        # serialize without one. We do NOT silently coerce.
        return obj.isoformat()
    if isinstance(obj, date):
        return obj.isoformat()

    # Pydantic v2 BaseModel — recurse on model_dump(mode="json")
    if isinstance(obj, BaseModel):
        # mode="json" already coerces datetime/Decimal to strings; we
        # still recurse so any nested non-standard scalar is normalized.
        return _to_canonical(obj.model_dump(mode="json"))

    # numpy / pandas scalars — best-effort via .item() without import
    # numpy at module load. Detect by attribute (``item`` + ``dtype``).
    if hasattr(obj, "dtype") and hasattr(obj, "item") and not isinstance(obj, (list, tuple)):
        try:
            return _to_canonical(obj.item())
        except (ValueError, TypeError):
            pass  # fall through

    # Dict — keys must be strings; the json.dumps sort_keys=True does the
    # actual sorting on the encoded result, but we still recurse here so
    # the value tree is normalized first.
    if isinstance(obj, dict):
        out: dict[str, Any] = {}
        for k, v in obj.items():
            if not isinstance(k, str):
                # Non-string keys would force int->str coercion at encode
                # time which is platform-stable but obscures intent.
                # Reject explicitly.
                raise TypeError(
                    f"canonical_json: dict keys must be str, got {type(k).__name__} ({k!r})"
                )
            out[k] = _to_canonical(v)
        return out

    # Tuple / list — preserve order, recurse element-wise
    if isinstance(obj, (list, tuple)):
        return [_to_canonical(x) for x in obj]

    # Sets and generators — no canonical order, reject explicitly
    if isinstance(obj, (set, frozenset)):
        raise TypeError(
            "canonical_json: set/frozenset has no deterministic order; "
            "convert to a sorted list before hashing"
        )
    if hasattr(obj, "__iter__") and hasattr(obj, "__next__"):
        raise TypeError(
            "canonical_json: generators / iterators are not encodable; "
            "materialize and sort before hashing"
        )

    # dict_keys / dict_values / dict_items — view types, no canonical order
    type_name = type(obj).__name__
    if type_name in {"dict_keys", "dict_values", "dict_items"}:
        raise TypeError(
            f"canonical_json: {type_name} has no deterministic order; "
            "materialize to a sorted list before hashing"
        )

    raise _NotEncodable(
        f"canonical_json: unsupported type {type(obj).__module__}.{type(obj).__name__}"
    )


def canonical_json(obj: Any) -> str:
    """Return a deterministic JSON encoding of ``obj``.

    Two invocations on equal Python values, in any process and on any
    platform, MUST produce byte-identical strings. The rules are:

    * dict keys sorted lexicographically
    * ``ensure_ascii=False`` — unicode characters pass through unchanged
    * tight separators ``(",", ":")`` — no whitespace
    * NaN / Inf raise ``ValueError`` (no ``allow_nan`` escape hatch)
    * set / generator / dict_view types raise ``TypeError``
    """
    try:
        normalized = _to_canonical(obj)
    except _NotEncodable as exc:
        raise TypeError(str(exc)) from None
    return json.dumps(
        normalized,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )


def hash_json(obj: Any) -> str:
    """Return ``sha256(canonical_json(obj))`` as a lowercase hex string."""
    return hashlib.sha256(canonical_json(obj).encode("utf-8")).hexdigest()


def hash_text(text: str) -> str:
    """Return ``sha256(text.encode("utf-8"))`` as a lowercase hex string."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def hash_dataframe(
    df: pd.DataFrame,
    *,
    sort_by: Sequence[str],
    columns: Sequence[str] | None = None,
) -> str:
    """Hash a DataFrame after canonical row sort + column projection.

    ``sort_by`` is REQUIRED. Hashing an unsorted DataFrame yields a value
    that depends on row insertion order, which is rarely what the caller
    wants and is the most common reproducibility bug. If the caller really
    has no key, they should hash the row count + a hash of each row
    independently — but that is *not* this function's job.

    ``columns`` projects to a subset before hashing; if omitted, the union
    of all DataFrame columns and ``sort_by`` is used, ordered by
    ``sort_by`` first, then the remaining columns sorted alphabetically.
    Any ``sort_by`` entry missing from the DataFrame raises ``KeyError``.

    Returns ``sha256`` lowercase hex.
    """
    # Lazy import — pandas is plugin-runtime only (see plugins_api/__init__.py).
    import pandas as pd  # noqa: PLC0415

    if not isinstance(df, pd.DataFrame):
        raise TypeError(f"hash_dataframe: expected pandas DataFrame, got {type(df).__name__}")
    if not sort_by:
        raise ValueError(
            "hash_dataframe: sort_by is required (an unsorted DataFrame has no canonical order)"
        )
    sort_by_list = list(sort_by)
    missing = [c for c in sort_by_list if c not in df.columns]
    if missing:
        raise KeyError(f"hash_dataframe: sort_by columns not in DataFrame: {missing}")

    if columns is None:
        remaining = sorted(c for c in df.columns if c not in sort_by_list)
        effective_columns = sort_by_list + remaining
    else:
        effective_columns = list(columns)
        missing_cols = [c for c in effective_columns if c not in df.columns]
        if missing_cols:
            raise KeyError(f"hash_dataframe: columns not in DataFrame: {missing_cols}")

    projected = df.loc[:, effective_columns].sort_values(sort_by_list).reset_index(drop=True)

    hasher = hashlib.sha256()
    # Header line — column order is part of the canonical input
    hasher.update(canonical_json(effective_columns).encode("utf-8"))
    hasher.update(b"\n")
    # Per-row: convert to list-of-values, pass each through _to_canonical
    # so timestamps / Decimals / numpy scalars normalize consistently.
    # Using .to_dict("records") would re-introduce per-row dict ordering
    # questions; sort_keys handles it but the per-row list form is simpler.
    for row in projected.itertuples(index=False, name=None):
        hasher.update(canonical_json(list(row)).encode("utf-8"))
        hasher.update(b"\n")
    return hasher.hexdigest()


def hash_file(path: str | Path, *, chunk_size: int = 1 << 20) -> str:
    """Stream-hash a file with ``sha256``. Returns lowercase hex.

    ``chunk_size`` defaults to 1 MiB; tune down for tests, up for very
    large artifacts. Raises ``FileNotFoundError`` / ``OSError`` like an
    open() call would.
    """
    p = Path(path)
    hasher = hashlib.sha256()
    with p.open("rb") as fh:
        while True:
            chunk = fh.read(chunk_size)
            if not chunk:
                break
            hasher.update(chunk)
    return hasher.hexdigest()
