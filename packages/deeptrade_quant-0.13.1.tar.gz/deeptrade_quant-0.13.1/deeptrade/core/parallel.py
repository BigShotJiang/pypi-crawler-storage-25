"""Stable-ordered parallel helper for multi-worker patterns.

The framework's reproducibility contract requires that the final
collection of provider results — used by report rendering, peer input,
and DB persistence — appears in a canonical order, independent of how
fast any individual worker finished. At the same time, dashboards want
real-time events emitted as workers complete (so the user sees "kimi
done in 2.3s" while deepseek is still running).

:func:`run_parallel_ordered` separates the two concerns:

* It runs ``worker_fn`` on each provider concurrently inside a
  ``ThreadPoolExecutor``.
* Completion events fire **in completion order** via the optional
  ``on_complete`` callback — perfect for "as-they-arrive" UI events.
* The returned list maps 1-1 with the ``providers`` input order — so
  the caller's serialization / report / peer-input code is deterministic.

This helper is intentionally LLM-agnostic. The name ``provider`` is
inherited from the obvious caller (multi-provider LLM debate) but any
string identifier works — workers are dispatched by the values in
``providers`` and the result list is keyed by their positions.
"""

from __future__ import annotations

import logging
import time
from collections.abc import Callable, Sequence
from concurrent.futures import (
    ThreadPoolExecutor,
    as_completed,
)
from concurrent.futures import (
    TimeoutError as FutureTimeoutError,
)
from dataclasses import dataclass
from typing import Generic, TypeVar

logger = logging.getLogger(__name__)


T = TypeVar("T")


__all__ = [
    "ProviderWorkResult",
    "run_parallel_ordered",
]


@dataclass(frozen=True)
class ProviderWorkResult(Generic[T]):
    """The outcome of one worker invocation.

    ``ok=True`` implies ``result`` carries the worker's return value and
    ``error`` is ``None``. ``ok=False`` implies the worker raised (or
    timed out) and ``error`` carries the exception instance; ``result``
    is ``None`` in that case.

    ``elapsed_ms`` is wallclock time observed by the orchestrator,
    measured from job submission to result resolution. It is a good
    proxy for "how long did this worker actually take" but is NOT a
    pure CPU / I/O time — submissions to a saturated pool can sit in
    the queue for a few ms before starting.
    """

    provider: str
    ok: bool
    result: T | None
    error: BaseException | None
    elapsed_ms: int


def run_parallel_ordered(
    providers: Sequence[str],
    worker_fn: Callable[[str], T],
    *,
    max_workers: int | None = None,
    on_complete: Callable[[ProviderWorkResult[T]], None] | None = None,
    timeout: float | None = None,
) -> list[ProviderWorkResult[T]]:
    """Run ``worker_fn(provider)`` for every provider in parallel.

    Returns a list of :class:`ProviderWorkResult` in the **input order**
    of ``providers`` — i.e. ``result[i].provider == providers[i]``.

    Real-time completion events are dispatched via ``on_complete``,
    one call per provider in **completion order**. Callers commonly
    use this hook to push dashboard updates; the canonical-ordered
    return value drives persistence / report rendering.

    A worker that raises any ``Exception`` (or ``BaseException``)
    produces a ``ProviderWorkResult(ok=False, error=...)`` rather than
    halting the batch — failures are surfaced to the caller, who
    decides whether to fail-fast or aggregate partial results.

    ``timeout`` (seconds) is a wallclock bound on the entire batch.
    When it elapses, any provider that has not yet finished is
    recorded as ``ok=False`` with a :class:`concurrent.futures.TimeoutError`.
    The framework attempts to ``cancel()`` pending futures (those
    not yet started by the executor); already-running workers
    continue to run in the background — Python's
    ``ThreadPoolExecutor`` does not support interrupting a running
    thread. Callers needing hard kill semantics should run workers
    in subprocesses, not threads.

    Edge cases:

    * Empty ``providers`` → returns ``[]`` and never builds an executor.
    * ``providers`` may contain duplicates; each is dispatched as a
      separate call to ``worker_fn`` and produces its own result row.
    * ``max_workers=None`` defers to ``ThreadPoolExecutor``'s default
      (``min(32, os.cpu_count() + 4)`` on 3.8+).
    """
    if not providers:
        return []

    results: list[ProviderWorkResult[T] | None] = [None] * len(providers)
    t_batch_start = time.monotonic()

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_index: dict = {
            executor.submit(worker_fn, provider): idx for idx, provider in enumerate(providers)
        }

        def _consume(fut, *, deadline_reached: bool = False) -> None:
            idx = future_to_index[fut]
            provider = providers[idx]
            elapsed_ms = int((time.monotonic() - t_batch_start) * 1000)
            try:
                if deadline_reached and not fut.done():
                    raise FutureTimeoutError(
                        f"worker for provider {provider!r} did not finish within timeout"
                    )
                value = fut.result(timeout=0 if deadline_reached else None)
                result = ProviderWorkResult(
                    provider=provider,
                    ok=True,
                    result=value,
                    error=None,
                    elapsed_ms=elapsed_ms,
                )
            except BaseException as exc:  # noqa: BLE001 — surface every failure mode
                result = ProviderWorkResult(
                    provider=provider,
                    ok=False,
                    result=None,
                    error=exc,
                    elapsed_ms=elapsed_ms,
                )
            results[idx] = result
            if on_complete is not None:
                try:
                    on_complete(result)
                except Exception as cb_err:  # noqa: BLE001 — callback errors must not abort
                    logger.warning(
                        "run_parallel_ordered: on_complete raised for provider=%r: %s",
                        provider,
                        cb_err,
                    )

        try:
            for fut in as_completed(future_to_index.keys(), timeout=timeout):
                _consume(fut)
        except FutureTimeoutError:
            # Deadline reached — mark each unfinished slot as a timeout
            # result. Then attempt to cancel pending futures so we don't
            # block the executor shutdown longer than necessary.
            for fut, idx in future_to_index.items():
                if results[idx] is None:
                    fut.cancel()
                    _consume(fut, deadline_reached=True)

    # Every slot is filled by now (consume covers both success and
    # timeout paths). The cast keeps mypy happy.
    final: list[ProviderWorkResult[T]] = []
    for idx, r in enumerate(results):
        if r is None:
            # Should be unreachable, but defend the contract: a worker
            # that completed AFTER the timeout dispatch raced past the
            # None check. Synthesize a TimeoutError in that case rather
            # than returning None to the caller.
            final.append(
                ProviderWorkResult(
                    provider=providers[idx],
                    ok=False,
                    result=None,
                    error=FutureTimeoutError("worker result lost between completion and dispatch"),
                    elapsed_ms=int((time.monotonic() - t_batch_start) * 1000),
                )
            )
        else:
            final.append(r)
    return final
