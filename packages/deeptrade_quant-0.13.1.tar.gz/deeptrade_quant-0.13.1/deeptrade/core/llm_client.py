"""LLM client (OpenAI-compatible protocol, multi-provider).

v0.7 — stage 概念彻底退出框架。``complete_json`` 不再认识 stage 名字，
由调用方直接传入一个已解析好的 ``StageProfile``。预设档（``fast/balanced/
quality``）保留为框架级用户配置（``app.profile``），但**预设档 → 各 stage
tuning 的映射表归插件自己维护**（详见 ``deeptrade.plugins_api.llm``）。

v0.6 — renamed from ``deepseek_client.py`` to reflect framework-level role.
The same client now backs every provider configured in ``llm.providers``
(DeepSeek / Qwen / Kimi / Doubao / GLM / Yi / SiliconFlow / OpenRouter, ...)
— they all speak the OpenAI Chat Completions wire format. Real heterogeneous
protocols (Anthropic native, Gemini native) will land later as a separate
transport plugin type; this module assumes OpenAI-compatible.

Construction is not normally done by plugins directly — use
``deeptrade.core.llm_manager.LLMManager.get_client(name, ...)``.

DESIGN §10.2 + the M3/F3/F5 hard constraints from v0.3 review:

    * **No tool calls EVER** — ``chat.completions.create()`` is invoked
      without any ``tools`` / ``tool_choice`` / ``functions`` parameter, and
      plugins are not handed a ``chat_with_tools`` surface.
    * **Caller-supplied profile**: each ``complete_json`` call carries a
      ``StageProfile`` (thinking / reasoning_effort / temperature /
      max_output_tokens). Framework does not look up profiles by stage name.
    * **JSON-only**: ``response_format={"type": "json_object"}`` + Pydantic
      double-validate; one retry on JSON / Pydantic failure, then re-raise.
    * **Audit**: each call is persisted to ``llm_calls`` (request_json,
      response_json, prompt_hash, validation_status, plugin_id).

Transports:
    OpenAICompatTransport  — base class; OpenAI-compatible chat completion API.
        Subclasses ``_provider_extra_body()`` to translate ``StageProfile.thinking``
        into each provider's wire shape (DashScope's ``enable_thinking`` boolean,
        Claude-on-OAI-compat's ``thinking={"type":"enabled"}``, etc.).
    GenericOpenAITransport — providers without a thinking dial (Kimi/DeepSeek/
        OpenRouter/...); ``thinking`` flag is silently dropped per the
        plugins_api/llm.py contract.
    DashScopeTransport     — Alibaba Qwen on DashScope. qwen3.x defaults to
        thinking=ON, so we MUST pass ``enable_thinking`` explicitly for both
        True and False — otherwise the plugin's "thinking off" preset is
        ineffective and runs hit the per-call timeout.
    RecordedTransport      — tests; FIFO-replays canned responses.

Routing: ``_select_transport_class(base_url)`` picks the right subclass via a
small framework-internal substring table. Unknown base_urls fall back to
GenericOpenAITransport. Insertion of a new provider type = one entry in
``_TRANSPORT_BY_BASE_URL`` + one subclass; configuration-layer schemas are
unaffected on purpose (the dialect is not user-tunable).
"""

from __future__ import annotations

import json
import logging
import time
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from pydantic import BaseModel, ValidationError
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from deeptrade.core.db import Database
from deeptrade.core.fingerprint import hash_text
from deeptrade.core.llm_replay import (
    LLMReplayMiss,
    LLMReplayPolicy,
    ReplayCacheStore,
)
from deeptrade.plugins_api.llm import StageProfile

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class LLMError(Exception):
    """Base for LLM client errors."""


class LLMTransportError(LLMError):
    """Network / SDK error — transient, retried by tenacity."""


class LLMValidationError(LLMError):
    """JSON parse or Pydantic validation failure."""


class LLMEmptyResponseError(LLMValidationError):
    """The model returned no visible content (``message.content`` was empty
    or None). Distinct from a JSON parse error so callers can show a clearer
    message and the retry path can append a "skip extended reasoning" hint
    instead of resending the same prompt that already produced nothing."""


class LLMConfigError(LLMError):
    """Misconfiguration at call time, e.g. enabling replay without supplying
    ``stage`` / ``schema_version``. Distinguished from ``LLMValidationError``
    so callers can branch: validation failures may retry / fall back, but a
    config error is the caller's bug to fix."""


# ---------------------------------------------------------------------------
# Transport abstraction
# ---------------------------------------------------------------------------


@dataclass
class LLMResponse:
    """Normalized response shape regardless of transport."""

    text: str
    input_tokens: int
    output_tokens: int


class LLMTransport(ABC):
    """Carrier for one chat completion call."""

    @abstractmethod
    def chat(
        self,
        *,
        model: str,
        system: str,
        user: str,
        temperature: float,
        max_tokens: int,
        thinking: bool,
        reasoning_effort: str,
    ) -> LLMResponse:
        """Send one chat. MUST NOT pass tools/tool_choice/functions."""


class OpenAICompatTransport(LLMTransport):
    """Production transport base — OpenAI-compatible chat completion.

    Subclasses override ``_provider_extra_body()`` to inject provider-specific
    knobs (notably the various flavors of the "thinking" dial). The default
    implementation returns ``{}``: appropriate for OpenAI-compatible providers
    that don't recognize a thinking concept, where ``StageProfile.thinking``
    is silently dropped per the plugins_api/llm.py contract.

    v0.6 — ``supports_reasoning_effort`` (class attribute) gates whether
    ``reasoning_effort`` from :class:`StageProfile` is forwarded to the
    provider. Default ``False``: most OpenAI-compatible Chinese providers
    (DeepSeek / Kimi / Qwen non-reasoning models / Doubao) either ignore
    the field or reject it as a 400, so we drop it by default. Subclasses
    override to ``True`` only when the provider has documented support.
    """

    # v0.6 H5 — see class docstring. The default is False; OpenAI-official
    # is the only known transport that flips it to True.
    supports_reasoning_effort: bool = False

    def __init__(self, api_key: str, base_url: str, timeout: int) -> None:
        from openai import OpenAI  # noqa: PLC0415

        self._client = OpenAI(api_key=api_key, base_url=base_url, timeout=timeout)

    def _provider_extra_body(self, *, thinking: bool) -> dict[str, Any]:
        """Provider-specific keys merged into ``extra_body``. Default: none."""
        del thinking  # base class has no provider knobs
        return {}

    def _adjust_temperature(self, *, model: str, temperature: float) -> float:
        """Provider/model-specific temperature sanitization hook.

        Default: identity. Subclasses override to clamp / force temperature
        for models with server-side hard constraints (e.g. Moonshot reasoning
        variants that only accept ``temperature == 1``).
        """
        del model  # base class has no per-model constraints
        return temperature

    def chat(
        self,
        *,
        model: str,
        system: str,
        user: str,
        temperature: float,
        max_tokens: int,
        thinking: bool,
        reasoning_effort: str,
    ) -> LLMResponse:
        """Send one chat as a server-sent-event stream and accumulate the
        deltas into a single :class:`LLMResponse`.

        Streaming is the only supported wire mode (v0.9+). Moonshot's
        official guidance explicitly warns that long non-streaming
        generations are killed by intermediate gateways that interpret a
        long "no headers yet" pause as a dead connection. Streaming makes
        the server emit ``200 OK`` + SSE headers within ~1 s, so no
        gateway treats the request as a zombie regardless of how long
        generation takes. The framework still returns a single
        ``LLMResponse``; audit log, retry, and plugin code are unaffected.

        ``stream_options={"include_usage": True}`` — every OpenAI-compatible
        provider currently in scope (OpenAI, Moonshot, DeepSeek, DashScope,
        Doubao, GLM, Yi, OpenRouter, SiliconFlow) returns ``usage`` on the
        final chunk when this is set. The final chunk in usage mode has
        ``choices=[]`` and ``usage`` populated.
        """
        from openai import APIError, APITimeoutError  # noqa: PLC0415

        adjusted_temperature = self._adjust_temperature(model=model, temperature=temperature)
        if adjusted_temperature != temperature:
            logger.info(
                "transport adjusted temperature for model=%s: %.3f -> %.3f",
                model,
                temperature,
                adjusted_temperature,
            )

        kwargs: dict[str, Any] = {
            "model": model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "response_format": {"type": "json_object"},
            "temperature": adjusted_temperature,
            "max_tokens": max_tokens,
            "stream": True,
            "stream_options": {"include_usage": True},
        }
        # v0.6 H5 — only send ``reasoning_effort`` when the transport
        # declares support AND the caller actually supplied a non-empty
        # value. Sending it unconditionally was the v0.5 default and is
        # the dominant failure mode on Chinese OpenAI-compat providers.
        if self.supports_reasoning_effort and reasoning_effort:
            kwargs["reasoning_effort"] = reasoning_effort
        extra_body = self._provider_extra_body(thinking=thinking)
        if extra_body:
            kwargs["extra_body"] = extra_body

        # ⚠ HARD CONSTRAINT (M3): we MUST NOT pass tools/tool_choice/functions.
        # If a future maintainer adds them, the no-tools test in V0.5 fails.

        parts: list[str] = []
        usage: Any = None
        try:
            stream = self._client.chat.completions.create(**kwargs)
            for chunk in stream:
                # In include_usage mode the final chunk carries usage and
                # an empty choices list. Earlier chunks carry one choice
                # whose delta.content may be None (role-only opener) or a
                # text fragment.
                if chunk.choices:
                    delta = chunk.choices[0].delta
                    if delta is not None and delta.content:
                        parts.append(delta.content)
                if getattr(chunk, "usage", None) is not None:
                    usage = chunk.usage
        except (APITimeoutError, APIError) as e:
            # Errors raised during create() (header phase) or while
            # iterating the stream (body phase) both surface as
            # LLMTransportError so tenacity in _transport_call retries.
            raise LLMTransportError(str(e)) from e

        return LLMResponse(
            text="".join(parts),
            input_tokens=int(getattr(usage, "prompt_tokens", 0) or 0),
            output_tokens=int(getattr(usage, "completion_tokens", 0) or 0),
        )


class GenericOpenAITransport(OpenAICompatTransport):
    """OpenAI-compatible providers without a thinking dial.

    Catch-all for providers like DeepSeek, Kimi, Doubao, GLM, Yi, OpenRouter, …
    The ``thinking`` flag from ``StageProfile`` is silently dropped here per
    the contract documented in ``plugins_api/llm.py``.
    """


class DashScopeTransport(OpenAICompatTransport):
    """Alibaba DashScope (Qwen family).

    qwen3.x defaults to thinking=ON; the only way to actually disable it is to
    send ``enable_thinking=False`` explicitly. Sending nothing leaves thinking
    on, which can blow past the per-call timeout for high-output prompts (the
    model burns its budget on internal reasoning before any visible content).
    Therefore we always emit ``enable_thinking`` — both for True and False.
    """

    def _provider_extra_body(self, *, thinking: bool) -> dict[str, Any]:
        return {"enable_thinking": thinking}


class MoonshotTransport(OpenAICompatTransport):
    """Moonshot Kimi (``api.moonshot.cn``).

    Reasoning-variant models (``kimi-k2-thinking`` / ``kimi-k2.5`` /
    ``kimi-k2.6``) have a server-side hard constraint: ``temperature`` MUST
    equal a model-specific fixed value (1.0 for thinking variants, 0.6 for
    ``kimi-for-coding``). Any other value returns HTTP 400 ``invalid
    temperature``.

    Non-reasoning Moonshot models accept the full ``[0, 1]`` range; values
    above 1 also 400. We handle both: forced equality on known reasoning
    variants, then fall through to range clamp for everyone else.

    ``_FORCED_TEMPERATURE`` uses **prefix** match so that dated revisions
    (``kimi-k2.6-1106``, ``kimi-k2-thinking-128k``, …) inherit the same
    constraint without a code change. Only include models with confirmed
    server-side enforcement, not just "recommended" values.

    Note: the international site (``api.moonshot.ai``) shares the same
    constraints — add a routing-table entry there if/when the framework
    supports it.
    """

    # model-name prefix → forced temperature value
    _FORCED_TEMPERATURE: tuple[tuple[str, float], ...] = (
        ("kimi-k2-thinking", 1.0),
        ("kimi-k2.5", 1.0),
        ("kimi-k2.6", 1.0),
        ("kimi-for-coding", 0.6),
    )

    def _adjust_temperature(self, *, model: str, temperature: float) -> float:
        for prefix, forced in self._FORCED_TEMPERATURE:
            if model.startswith(prefix):
                return forced
        # Moonshot accepts only [0, 1] across the whole API; upper-clamp guards
        # non-reasoning models (moonshot-v1-*, kimi-k2-instruct-*) against a
        # StageProfile that goes above 1.0 (the Pydantic field allows up to 2).
        return min(temperature, 1.0)


class OpenAIOfficialTransport(OpenAICompatTransport):
    """OpenAI's own ``api.openai.com`` endpoint.

    Only this transport documents support for the ``reasoning_effort``
    parameter (on the o1 / o3 reasoning family); flipping the base-class
    flag here makes ``OpenAICompatTransport.chat`` forward the value from
    :class:`StageProfile`. Other OpenAI-compatible providers either ignore
    the field or 400 on it, so they keep the base-class default (False).
    """

    supports_reasoning_effort = True


# ---------------------------------------------------------------------------
# Transport routing (framework-internal)
# ---------------------------------------------------------------------------

# base_url substring → transport class. Substring (not strict host) is fine
# because each entry's pattern is anchored to the provider's well-known domain
# and tolerates port / path / version variations. New entries land here and
# nowhere else; user-facing config has no "dialect" knob on purpose.
_TRANSPORT_BY_BASE_URL: tuple[tuple[str, type[OpenAICompatTransport]], ...] = (
    ("dashscope.aliyuncs.com", DashScopeTransport),
    ("api.moonshot.cn", MoonshotTransport),
    ("api.openai.com", OpenAIOfficialTransport),
)


def _select_transport_class(base_url: str) -> type[OpenAICompatTransport]:
    """Pick the OpenAI-compat transport subclass for a provider's base_url.

    Substring match against ``_TRANSPORT_BY_BASE_URL``; unknown base_urls fall
    back to ``GenericOpenAITransport`` (which silently drops thinking flags).
    """
    for pattern, cls in _TRANSPORT_BY_BASE_URL:
        if pattern in base_url:
            return cls
    return GenericOpenAITransport


class RecordedTransport(LLMTransport):
    """Test transport — FIFO-replays pre-registered responses.

    Use ``register(response)`` to seed; each ``chat()`` call pops one entry.
    """

    def __init__(self) -> None:
        self._queue: list[LLMResponse | Exception] = []
        # last-seen kwargs the test can introspect (M3 no-tools test relies on this)
        self.last_call_kwargs: dict[str, Any] = {}

    def register(self, response: LLMResponse | Exception) -> None:
        self._queue.append(response)

    def chat(
        self,
        *,
        model: str,
        system: str,
        user: str,
        temperature: float,
        max_tokens: int,
        thinking: bool,
        reasoning_effort: str,
    ) -> LLMResponse:
        self.last_call_kwargs = {
            "model": model,
            "system": system,
            "user": user,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "thinking": thinking,
            "reasoning_effort": reasoning_effort,
        }
        if not self._queue:
            raise LLMTransportError("RecordedTransport: no more queued responses")
        entry = self._queue.pop(0)
        if isinstance(entry, Exception):
            raise entry
        return entry


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------


class LLMClient:
    def __init__(
        self,
        db: Database,
        transport: LLMTransport,
        *,
        model: str,
        provider: str | None = None,
        plugin_id: str | None = None,
        run_id: str | None = None,
        audit_full_payload: bool = False,
        reports_dir: Path | None = None,
    ) -> None:
        self._db = db
        self._transport = transport
        self._model = model
        # v0.12 — provider name is required for replay cache_key derivation
        # (a single ``model`` string can be served by multiple providers).
        # Kept optional in the signature so existing direct-construction
        # tests and callers that don't use replay continue to work; only
        # the replay path enforces a non-empty value.
        self._provider = provider
        self._plugin_id = plugin_id
        self._run_id = run_id
        # F-M2 — when False (default), DB rows keep just hash + response excerpt;
        # full payloads ALWAYS go to reports_dir/llm_calls.jsonl (set by caller).
        self._audit_full = audit_full_payload
        self._reports_dir = reports_dir

    # --- main entry ----------------------------------------------------

    def complete_json(
        self,
        *,
        system: str,
        user: str,
        schema: type[BaseModel],
        profile: StageProfile,
        envelope_defaults: dict[str, Any] | None = None,
        replay: LLMReplayPolicy | None = None,
        stage: str | None = None,
        schema_version: str | None = None,
        input_fingerprint: str | None = None,
    ) -> tuple[BaseModel, dict[str, Any]]:
        """Send a JSON-mode chat and validate against `schema`.

        ``profile`` (required) — caller-resolved per-call tuning. Plugins
        own the preset → stage profile mapping; the framework just consumes
        the four fields (thinking, reasoning_effort, temperature,
        max_output_tokens).

        ``envelope_defaults`` (optional) — top-level keys to inject when
        the LLM omits them. Useful for caller-controlled metadata like
        ``stage`` / ``trade_date`` / ``batch_no``. Only fills keys missing
        from the parsed payload, never overwrites.

        ``replay`` (v0.12) — optional :class:`LLMReplayPolicy` controlling
        whether this call reads from / writes to the framework LLM replay
        cache (see :mod:`deeptrade.core.llm_replay`). Default ``None``
        means **caching disabled**, preserving pre-v0.12 behavior for
        callers that haven't migrated. Plugins that want caching must
        explicitly pass a non-disabled policy AND supply ``stage`` /
        ``schema_version``.

        ``stage`` / ``schema_version`` / ``input_fingerprint`` (v0.12) —
        cache-key inputs. ``stage`` and ``schema_version`` are required
        when ``replay`` is active (any read or write); ``input_fingerprint``
        is the plugin-computed business-input hash (typically via
        :func:`deeptrade.core.fingerprint.hash_json` over candidate /
        evidence inputs). May be ``None`` if the caller is OK with a
        coarser cache key.

        Returns ``(validated_model, meta)`` where ``meta`` includes:
            input_tokens / output_tokens / latency_ms / prompt_hash
            attempt_count / final_prompt_hash / first_error_class /
            repair_hint_hash / call_id
            cache_hit / cache_key / source_run_id / source_call_id /
            tokens_from_cache (only when cache_hit=True)

        Raises:
            LLMValidationError    — JSON or Pydantic still failing after 1 retry
            LLMEmptyResponseError — model returned empty content twice
            LLMTransportError     — transport-level error after retries
            LLMReplayMiss         — replay_only mode and the cache missed
            LLMConfigError        — replay enabled without stage / schema_version
        """
        effective_policy = replay if replay is not None else LLMReplayPolicy.disabled()

        cache_key: str | None = None
        request_fingerprint: dict[str, Any] | None = None
        if effective_policy.any_cache_active:
            if not stage:
                raise LLMConfigError(
                    "complete_json: stage is required when LLM replay cache is active"
                )
            if not schema_version:
                raise LLMConfigError(
                    "complete_json: schema_version is required when LLM replay cache is active"
                )
            if not self._provider:
                raise LLMConfigError(
                    "complete_json: provider name is not configured on LLMClient "
                    "but replay cache is active — pass provider=<name> at construction "
                    "or obtain the client via LLMManager.get_client()"
                )
            cache_key, request_fingerprint = ReplayCacheStore.make_cache_key(
                plugin_id=self._plugin_id or "__framework__",
                stage=stage,
                provider=self._provider,
                model=self._model,
                system_sha256=hash_text(system),
                user_sha256=hash_text(user),
                profile=profile,
                schema_name=schema.__name__,
                schema_version=schema_version,
                input_fingerprint=input_fingerprint,
            )

        # --- cache read ---------------------------------------------------
        if effective_policy.read_enabled and cache_key is not None:
            store = ReplayCacheStore(self._db)
            hit = store.lookup(cache_key, ttl_days=effective_policy.ttl_days)
            if hit is not None:
                return self._serve_from_cache(
                    hit=hit,
                    system=system,
                    user=user,
                    schema=schema,
                    cache_key=cache_key,
                    stage=stage,
                    schema_version=schema_version,
                    input_fingerprint=input_fingerprint,
                )

        # --- replay_only miss --------------------------------------------
        if effective_policy.replay_only:
            assert cache_key is not None  # any_cache_active implies cache_key set
            return self._raise_replay_miss(
                system=system,
                user=user,
                cache_key=cache_key,
                stage=stage,
                schema_version=schema_version,
                input_fingerprint=input_fingerprint,
            )

        # --- real provider call (with repair retry) ----------------------
        obj, meta = self._with_retry(
            system,
            user,
            schema,
            profile,
            envelope_defaults,
            stage=stage,
            schema_version=schema_version,
            input_fingerprint=input_fingerprint,
            cache_key=cache_key,
        )
        meta["cache_hit"] = False
        meta["cache_key"] = cache_key
        meta["source_run_id"] = None
        meta["source_call_id"] = None

        # --- cache write -------------------------------------------------
        if (
            effective_policy.write_enabled
            and cache_key is not None
            and request_fingerprint is not None
        ):
            store = ReplayCacheStore(self._db)
            assert stage is not None and schema_version is not None
            assert self._provider is not None
            store.store(
                cache_key=cache_key,
                plugin_id=self._plugin_id or "__framework__",
                stage=stage,
                provider=self._provider,
                model=self._model,
                prompt_hash=meta["prompt_hash"],
                profile=profile,
                schema_name=schema.__name__,
                schema_version=schema_version,
                input_fingerprint=input_fingerprint,
                request_fingerprint=request_fingerprint,
                response_dict=obj.model_dump(mode="json"),
                response_meta={
                    # Strip ephemeral / per-call fields before persisting; we
                    # want the cached meta to describe the original real
                    # call's audit footprint, not anything cache-derived.
                    k: v
                    for k, v in meta.items()
                    if k
                    in {
                        "input_tokens",
                        "output_tokens",
                        "latency_ms",
                        "prompt_hash",
                        "attempt_count",
                        "final_prompt_hash",
                        "first_error_class",
                        "repair_hint_hash",
                    }
                },
                source_run_id=self._run_id,
                source_call_id=meta.get("call_id"),
            )

        return obj, meta

    # --- replay helpers ------------------------------------------------

    def _serve_from_cache(
        self,
        *,
        hit: Any,  # CacheEntry — type imported lazily to avoid coupling
        system: str,
        user: str,
        schema: type[BaseModel],
        cache_key: str,
        stage: str | None,
        schema_version: str | None,
        input_fingerprint: str | None,
    ) -> tuple[BaseModel, dict[str, Any]]:
        """Reconstruct (obj, meta) from a cache hit and write the ``cached``
        audit row.

        Re-validates the cached response against the caller's schema so a
        schema-tightening change still rejects stale entries instead of
        silently returning an incompatible payload.
        """
        obj = schema.model_validate(hit.response_dict)
        original = hit.response_meta or {}
        cached_input_tokens = int(original.get("input_tokens", 0) or 0)
        cached_output_tokens = int(original.get("output_tokens", 0) or 0)
        prompt_hash = hash_text(system + user)
        call_id = str(uuid.uuid4())
        attempt_count = int(original.get("attempt_count", 1) or 1)
        final_prompt_hash = original.get("final_prompt_hash")
        first_error_class = original.get("first_error_class")
        repair_hint_hash = original.get("repair_hint_hash")

        meta: dict[str, Any] = {
            "input_tokens": cached_input_tokens,
            "output_tokens": cached_output_tokens,
            "latency_ms": 0,  # served from cache; provider call latency is N/A
            "prompt_hash": prompt_hash,
            "attempt_count": attempt_count,
            "final_prompt_hash": final_prompt_hash,
            "first_error_class": first_error_class,
            "repair_hint_hash": repair_hint_hash,
            "call_id": call_id,
            "cache_hit": True,
            "cache_key": cache_key,
            "source_run_id": hit.source_run_id,
            "source_call_id": hit.source_call_id,
            "tokens_from_cache": True,
        }
        # Response payload for audit — re-serialize from the validated dict
        # to keep JSONL deterministic regardless of how the model originally
        # framed its JSON output.
        response_text = json.dumps(hit.response_dict, ensure_ascii=False)
        self._record_call(
            call_id=call_id,
            prompt_hash=prompt_hash,
            request_system=system,
            request_user=user,
            response_text=response_text,
            input_tokens=cached_input_tokens,
            output_tokens=cached_output_tokens,
            latency_ms=0,
            validation_status="cached",
            error=None,
            cache_hit=True,
            cache_key=cache_key,
            source_run_id=hit.source_run_id,
            source_call_id=hit.source_call_id,
            stage=stage,
            schema_version=schema_version,
            input_fingerprint=input_fingerprint,
            attempt_count=attempt_count,
            final_prompt_hash=final_prompt_hash,
            repair_hint_hash=repair_hint_hash,
            first_error_class=first_error_class,
            tokens_from_cache=True,
        )
        return obj, meta

    def _raise_replay_miss(
        self,
        *,
        system: str,
        user: str,
        cache_key: str,
        stage: str | None,
        schema_version: str | None,
        input_fingerprint: str | None,
    ) -> tuple[BaseModel, dict[str, Any]]:
        """Record a ``replay_miss`` audit row and raise :class:`LLMReplayMiss`.

        The audit row preserves the fact that an attempted call was
        intentionally suppressed by ``replay_only`` mode — important when
        reproducing a run offline and reasoning about why no provider
        invocation showed up.
        """
        prompt_hash = hash_text(system + user)
        call_id = str(uuid.uuid4())
        self._record_call(
            call_id=call_id,
            prompt_hash=prompt_hash,
            request_system=system,
            request_user=user,
            response_text="",
            input_tokens=0,
            output_tokens=0,
            latency_ms=0,
            validation_status="replay_miss",
            error=None,
            cache_hit=False,
            cache_key=cache_key,
            source_run_id=None,
            source_call_id=None,
            stage=stage,
            schema_version=schema_version,
            input_fingerprint=input_fingerprint,
            attempt_count=0,
            final_prompt_hash=None,
            repair_hint_hash=None,
            first_error_class=None,
        )
        raise LLMReplayMiss(
            cache_key=cache_key,
            plugin_id=self._plugin_id,
            stage=stage,
        )

    @staticmethod
    def _retry_hint_for(error: Exception, schema: type[BaseModel] | None = None) -> str:
        """Pick a corrective hint for the second attempt based on what failed.

        v0.10 — hints are framework-agnostic. Earlier revisions name-dropped
        strategy-specific fields (``ts_code`` / ``score`` / ``strength_level``)
        in the ValidationError branch, which leaked plugin domain semantics
        into the framework. The schema-derived hint enumerates required field
        names when a Pydantic ``schema`` is supplied, so plugins of any domain
        get the same kind of nudge without the framework hard-coding them."""
        if isinstance(error, LLMEmptyResponseError):
            return (
                "\n\n⚠ 上一次响应为空。请直接输出符合 schema 的 JSON，"
                "不要进行扩展推理或 markdown 包裹；只返回最终的 JSON 对象。"
            )
        if isinstance(error, json.JSONDecodeError):
            return (
                "\n\n⚠ 上一次响应不是合法 JSON。请只返回 JSON 对象，"
                "不要使用代码块标记 ``` 或前后缀。"
            )
        if isinstance(error, ValidationError):
            required = LLMClient._required_field_names(schema) if schema is not None else []
            if required:
                names = "、".join(required)
                return (
                    f"\n\n⚠ 上一次响应缺少必填字段或字段值非法。请严格按照系统消息中的"
                    f"【输出格式】填写每一个字段，必填字段（不可省略）：{names}。"
                )
            return (
                "\n\n⚠ 上一次响应缺少必填字段或字段值非法。请严格按照系统消息中的"
                "【输出格式】填写每一个字段，不要省略任何字段。"
            )
        return ""

    @staticmethod
    def _required_field_names(schema: type[BaseModel]) -> list[str]:
        """Return the schema's required field names. Pydantic v2 marks a
        field required when ``is_required()`` returns True; nullable optional
        fields with explicit defaults are skipped."""
        try:
            return [name for name, info in schema.model_fields.items() if info.is_required()]
        except Exception:  # noqa: BLE001 — schema introspection is best-effort
            return []

    @retry(
        retry=retry_if_exception_type(LLMTransportError),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=10),
        reraise=True,
    )
    def _transport_call(self, system: str, user: str, profile: StageProfile) -> LLMResponse:
        return self._transport.chat(
            model=self._model,
            system=system,
            user=user,
            temperature=profile.temperature,
            max_tokens=profile.max_output_tokens,
            thinking=profile.thinking,
            reasoning_effort=profile.reasoning_effort,
        )

    def _with_retry(
        self,
        system: str,
        user: str,
        schema: type[BaseModel],
        profile: StageProfile,
        envelope_defaults: dict[str, Any] | None = None,
        *,
        stage: str | None = None,
        schema_version: str | None = None,
        input_fingerprint: str | None = None,
        cache_key: str | None = None,
    ) -> tuple[BaseModel, dict[str, Any]]:
        """Two attempts: one retry on JSON / Pydantic / empty-response failure.

        Empty responses (``response.text`` blank) are detected separately:
        the second-attempt user prompt gets an appended hint asking the
        model to emit JSON directly without extended reasoning, since
        re-sending the identical prompt has zero new information.

        v0.12 — audit rows carry the v0.12 audit columns (stage,
        schema_version, input_fingerprint, attempt_count, first_error_class,
        repair_hint_hash, final_prompt_hash) so cross-run compare /
        history queries work uniformly even when the call did not use
        the replay cache.
        """
        prompt_hash = hash_text(system + user)

        last_err: Exception | None = None
        last_response: LLMResponse | None = None
        current_user = user
        first_error_class: str | None = None
        repair_hint_hash: str | None = None
        for attempt in (1, 2):
            t0 = time.monotonic()
            response = self._transport_call(system, current_user, profile)
            latency_ms = int((time.monotonic() - t0) * 1000)
            last_response = response
            final_prompt_hash = hash_text(system + current_user)

            # Detect empty content BEFORE trying to parse — the JSON error
            # otherwise surfaces as a misleading "Expecting value at line 1
            # column 1 (char 0)" with no signal that the model returned
            # nothing visible at all.
            empty = (response.text or "").strip() == ""
            try:
                if empty:
                    raise LLMEmptyResponseError(
                        f"model returned empty content "
                        f"(input_tokens={response.input_tokens}, "
                        f"output_tokens={response.output_tokens}, latency_ms={latency_ms}); "
                        "common causes: extended reasoning consumed the output budget, "
                        "max_output_tokens too low, or model-side content filter."
                    )
                payload = json.loads(response.text)
                if envelope_defaults and isinstance(payload, dict):
                    for k, v in envelope_defaults.items():
                        payload.setdefault(k, v)
                obj = schema.model_validate(payload)
            except (json.JSONDecodeError, ValidationError, LLMEmptyResponseError) as e:
                last_err = e
                if attempt == 1:
                    first_error_class = type(e).__name__
                call_id = str(uuid.uuid4())
                self._record_call(
                    call_id=call_id,
                    prompt_hash=prompt_hash,
                    request_system=system,
                    request_user=current_user,
                    response_text=response.text,
                    input_tokens=response.input_tokens,
                    output_tokens=response.output_tokens,
                    latency_ms=latency_ms,
                    validation_status="retry" if attempt == 1 else "failed",
                    error=f"{type(e).__name__}: {e}",
                    cache_hit=False,
                    cache_key=cache_key,
                    source_run_id=None,
                    source_call_id=None,
                    stage=stage,
                    schema_version=schema_version,
                    input_fingerprint=input_fingerprint,
                    attempt_count=attempt,
                    final_prompt_hash=final_prompt_hash,
                    repair_hint_hash=None,  # no hint applied to this attempt yet
                    first_error_class=first_error_class,
                )
                # On retry, attach a corrective hint tailored to the failure
                # mode. Same prompt twice is wasted budget.
                if attempt == 1:
                    hint = self._retry_hint_for(e, schema)
                    current_user = user + hint
                    repair_hint_hash = hash_text(hint) if hint else None
                continue
            else:
                call_id = str(uuid.uuid4())
                self._record_call(
                    call_id=call_id,
                    prompt_hash=prompt_hash,
                    request_system=system,
                    request_user=current_user,
                    response_text=response.text,
                    input_tokens=response.input_tokens,
                    output_tokens=response.output_tokens,
                    latency_ms=latency_ms,
                    validation_status="ok",
                    error=None,
                    cache_hit=False,
                    cache_key=cache_key,
                    source_run_id=None,
                    source_call_id=None,
                    stage=stage,
                    schema_version=schema_version,
                    input_fingerprint=input_fingerprint,
                    attempt_count=attempt,
                    final_prompt_hash=final_prompt_hash,
                    repair_hint_hash=repair_hint_hash,
                    first_error_class=first_error_class,
                )
                return obj, {
                    "input_tokens": response.input_tokens,
                    "output_tokens": response.output_tokens,
                    "latency_ms": latency_ms,
                    "prompt_hash": prompt_hash,
                    "attempt_count": attempt,
                    "final_prompt_hash": final_prompt_hash,
                    "first_error_class": first_error_class,
                    "repair_hint_hash": repair_hint_hash,
                    "call_id": call_id,
                }

        # both attempts failed — preserve the specific error subclass so callers
        # (and tests) can branch on whether the model returned empty vs. invalid.
        assert last_err is not None
        tail = (last_response.text if last_response else "")[:200]
        msg = f"validation failed after retry; last error: {last_err}; last response (truncated): {tail}"
        if isinstance(last_err, LLMEmptyResponseError):
            raise LLMEmptyResponseError(msg) from last_err
        raise LLMValidationError(msg) from last_err

    # --- audit log ----------------------------------------------------

    def _record_call(
        self,
        *,
        call_id: str | None = None,
        prompt_hash: str,
        request_system: str,
        request_user: str,
        response_text: str,
        input_tokens: int,
        output_tokens: int,
        latency_ms: int,
        validation_status: str,
        error: str | None,
        # v0.12 — extended audit columns. All default-None so existing
        # internal callers (none after this refactor, but kept defensive)
        # produce DB rows with NULL/FALSE for the new columns.
        cache_hit: bool = False,
        cache_key: str | None = None,
        source_run_id: str | None = None,
        source_call_id: str | None = None,
        stage: str | None = None,
        schema_version: str | None = None,
        input_fingerprint: str | None = None,
        attempt_count: int = 1,
        final_prompt_hash: str | None = None,
        repair_hint_hash: str | None = None,
        first_error_class: str | None = None,
        tokens_from_cache: bool = False,
    ) -> None:
        if call_id is None:
            call_id = str(uuid.uuid4())
        # F-M2 — write FULL payload to reports/<run_id>/llm_calls.jsonl regardless
        # of audit_full_payload (DB lean is just a storage optimization, not an
        # audit gap). The DB row may be lean or full per audit_full_payload.
        self._append_jsonl(
            call_id=call_id,
            prompt_hash=prompt_hash,
            request_system=request_system,
            request_user=request_user,
            response_text=response_text,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            latency_ms=latency_ms,
            validation_status=validation_status,
            error=error,
            cache_hit=cache_hit,
            cache_key=cache_key,
            source_run_id=source_run_id,
            source_call_id=source_call_id,
            stage=stage,
            schema_version=schema_version,
            input_fingerprint=input_fingerprint,
            attempt_count=attempt_count,
            final_prompt_hash=final_prompt_hash,
            repair_hint_hash=repair_hint_hash,
            first_error_class=first_error_class,
            tokens_from_cache=tokens_from_cache,
        )
        if self._audit_full:
            request_json = json.dumps(
                {"system": request_system, "user": request_user},
                ensure_ascii=False,
            )
            response_payload = response_text
        else:
            # Lean mode: store user-prompt size + first 200 chars of response.
            request_json = json.dumps(
                {
                    "system_len": len(request_system),
                    "user_len": len(request_user),
                    "audit": "lean",
                },
                ensure_ascii=False,
            )
            response_payload = (response_text or "")[:200]
        self._db.execute(
            "INSERT INTO llm_calls("
            "call_id, run_id, plugin_id, model, prompt_hash, "
            "input_tokens, output_tokens, latency_ms, request_json, response_json, "
            "validation_status, error, "
            "cache_hit, cache_key, source_run_id, source_call_id, "
            "stage, schema_version, input_fingerprint, "
            "attempt_count, final_prompt_hash, repair_hint_hash, first_error_class"
            ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                call_id,
                self._run_id,
                self._plugin_id,
                self._model,
                prompt_hash,
                input_tokens,
                output_tokens,
                latency_ms,
                request_json,
                response_payload,
                validation_status,
                error,
                cache_hit,
                cache_key,
                source_run_id,
                source_call_id,
                stage,
                schema_version,
                input_fingerprint,
                attempt_count,
                final_prompt_hash,
                repair_hint_hash,
                first_error_class,
            ),
        )

    def _append_jsonl(
        self,
        *,
        call_id: str,
        prompt_hash: str,
        request_system: str,
        request_user: str,
        response_text: str,
        input_tokens: int,
        output_tokens: int,
        latency_ms: int,
        validation_status: str,
        error: str | None,
        cache_hit: bool = False,
        cache_key: str | None = None,
        source_run_id: str | None = None,
        source_call_id: str | None = None,
        stage: str | None = None,
        schema_version: str | None = None,
        input_fingerprint: str | None = None,
        attempt_count: int = 1,
        final_prompt_hash: str | None = None,
        repair_hint_hash: str | None = None,
        first_error_class: str | None = None,
        tokens_from_cache: bool = False,
    ) -> None:
        """F-M2 — write the FULL prompt/response to llm_calls.jsonl always.
        DB lean-mode is purely a storage optimization; audit must be reproducible
        from the jsonl file in the report directory.

        v0.12 — JSONL row now carries the cache / replay audit fields so
        ``llm_calls.jsonl`` is a self-contained replay-aware audit log:
        downstream tooling can tell apart real provider calls from cache
        hits / replay misses without joining against ``llm_calls`` /
        ``llm_replay_cache``.
        """
        if self._reports_dir is None:
            return
        try:
            self._reports_dir.mkdir(parents=True, exist_ok=True)
            with (self._reports_dir / "llm_calls.jsonl").open("a", encoding="utf-8") as fh:
                fh.write(
                    json.dumps(
                        {
                            "call_id": call_id,
                            "run_id": self._run_id,
                            "plugin_id": self._plugin_id,
                            "model": self._model,
                            "prompt_hash": prompt_hash,
                            "input_tokens": input_tokens,
                            "output_tokens": output_tokens,
                            "latency_ms": latency_ms,
                            "system": request_system,
                            "user": request_user,
                            "response": response_text,
                            "validation_status": validation_status,
                            "error": error,
                            # v0.12 cache / replay audit
                            "cache_hit": cache_hit,
                            "cache_key": cache_key,
                            "source_run_id": source_run_id,
                            "source_call_id": source_call_id,
                            "stage": stage,
                            "schema_version": schema_version,
                            "input_fingerprint": input_fingerprint,
                            "attempt_count": attempt_count,
                            "final_prompt_hash": final_prompt_hash,
                            "repair_hint_hash": repair_hint_hash,
                            "first_error_class": first_error_class,
                            "tokens_from_cache": tokens_from_cache,
                        },
                        ensure_ascii=False,
                    )
                    + "\n"
                )
        except Exception as e:  # noqa: BLE001 — never let audit IO crash the run
            logger.warning("failed to write llm_calls.jsonl: %s", e)
