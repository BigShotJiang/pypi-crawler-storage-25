-- v0.12 — extend llm_calls with replay-aware audit columns.
--
-- All new columns are NULL-able (or default FALSE/1) so historical rows
-- are unaffected and pre-v0.12 readers continue to work — the new
-- columns simply read as NULL/FALSE.
--
-- Column notes:
--   cache_hit          : TRUE when this call was served from
--                        ``llm_replay_cache`` without invoking the
--                        provider. ``validation_status='cached'`` is the
--                        canonical signal; ``cache_hit`` is a redundant
--                        boolean kept for cheap filtering / analytics.
--   cache_key          : the cache row consulted (whether it hit or
--                        was written). NULL for replay-disabled calls.
--   source_run_id      : on cache_hit=TRUE, the run that originally
--                        wrote this cache entry. Lets compare /
--                        history surface "this run B reused result
--                        from run A".
--   source_call_id     : the llm_calls.call_id from the original
--                        write. Same semantics.
--   stage              : plugin-supplied stage name (mirrors
--                        llm_replay_cache.stage).
--   schema_version     : plugin-supplied schema_version string.
--   input_fingerprint  : plugin-supplied business-input fingerprint.
--   attempt_count      : 1 on first-try success; 2 on repair-retry
--                        success; matches the number of provider
--                        invocations this audit row corresponds to.
--                        For cached rows attempt_count is the value
--                        from the original successful write (so
--                        analytics on "how many real calls happened"
--                        stay correct when summed over the cache
--                        write rows only).
--   final_prompt_hash  : sha256(system + final_user). Diverges from
--                        prompt_hash when repair retry mutates the
--                        user prompt with a corrective hint.
--   repair_hint_hash   : sha256 of the appended hint text on a
--                        successful repair retry; NULL when no hint
--                        was needed.
--   first_error_class  : on repair-retry success, the Python class
--                        name of the first-attempt exception
--                        (``LLMValidationError`` / ``LLMEmptyResponseError``
--                        / ``ValidationError`` / ``JSONDecodeError``).
--
-- validation_status (existing column) value set is extended at the
-- application layer (no DB constraint change):
--   ok | retry | failed   — pre-v0.12 values, unchanged
--   cached                — served from llm_replay_cache (no provider call)
--   replay_miss           — replay_only policy requested but cache miss
--                           (no provider call either; surfaced for audit)

ALTER TABLE llm_calls ADD COLUMN cache_hit         BOOLEAN DEFAULT FALSE;
ALTER TABLE llm_calls ADD COLUMN cache_key         VARCHAR;
ALTER TABLE llm_calls ADD COLUMN source_run_id     VARCHAR;
ALTER TABLE llm_calls ADD COLUMN source_call_id    VARCHAR;
ALTER TABLE llm_calls ADD COLUMN stage             VARCHAR;
ALTER TABLE llm_calls ADD COLUMN schema_version    VARCHAR;
ALTER TABLE llm_calls ADD COLUMN input_fingerprint VARCHAR;
ALTER TABLE llm_calls ADD COLUMN attempt_count     INTEGER DEFAULT 1;
ALTER TABLE llm_calls ADD COLUMN final_prompt_hash VARCHAR;
ALTER TABLE llm_calls ADD COLUMN repair_hint_hash  VARCHAR;
ALTER TABLE llm_calls ADD COLUMN first_error_class VARCHAR;
