-- v0.12 — framework-level cross-plugin run metadata.
--
-- The framework does NOT own a unified "runs" table — each plugin keeps
-- its own ``<prefix>_runs`` with business-specific columns. This table
-- holds only the metadata subset that is cross-plugin meaningful: a key
-- date (e.g. trade_date), an opaque input fingerprint, and the canonical
-- input payload. ``deeptrade run compare`` / ``run show`` join against
-- this table so they work uniformly regardless of plugin domain.
--
-- ``set_run_key_date`` / ``set_run_input_fingerprint`` / ``add_run_artifact``
-- on ``PluginContext`` are the only supported way for plugins to write
-- these tables; do NOT have plugins INSERT directly so the framework can
-- evolve the storage shape later.
--
-- Column notes (run_metadata):
--   plugin_id          : owner. Composite PK with run_id.
--   run_id             : plugin-defined string. The framework does not
--                        validate format; insertion-time uniqueness is
--                        enforced only within a (plugin_id, run_id) pair.
--   key_date           : business-meaningful date (typically the
--                        trade_date / target_date being analyzed). Stored
--                        as DATE so compare can range-query.
--   input_fingerprint  : sha256 hex string the plugin computed via
--                        ``hash_json`` / ``hash_dataframe`` over its
--                        business inputs. Opaque to the framework.
--   input_payload_json : the canonical-JSON dict that produced
--                        ``input_fingerprint``. Stored verbatim so
--                        ``run compare`` can show field-level diffs.
--                        Plugins may omit (NULL) if size is prohibitive.
--
-- Column notes (run_artifacts):
--   artifact_id  : DuckDB sequence (auto). Surrogate PK so compare can
--                  cite a stable handle.
--   name         : plugin-defined logical name (e.g. "summary.md",
--                  "round1_strong_targets.json"). UNIQUE within
--                  (plugin_id, run_id, name).
--   path         : filesystem path the plugin saved the artifact to.
--                  Stored as the literal string the plugin passed in
--                  — the framework does not normalize or resolve.
--   sha256       : hex digest. Computed by the framework via
--                  ``hash_file`` if the plugin passed ``sha256=None``.
--   size_bytes   : os.path.getsize at write time.

CREATE TABLE IF NOT EXISTS run_metadata (
    plugin_id           VARCHAR NOT NULL,
    run_id              VARCHAR NOT NULL,
    key_date            DATE,
    input_fingerprint   VARCHAR,
    input_payload_json  VARCHAR,
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (plugin_id, run_id)
);

CREATE INDEX IF NOT EXISTS idx_run_metadata_key_date
    ON run_metadata(plugin_id, key_date);

CREATE SEQUENCE IF NOT EXISTS run_artifacts_id_seq;

CREATE TABLE IF NOT EXISTS run_artifacts (
    artifact_id  BIGINT PRIMARY KEY DEFAULT nextval('run_artifacts_id_seq'),
    plugin_id    VARCHAR NOT NULL,
    run_id       VARCHAR NOT NULL,
    name         VARCHAR NOT NULL,
    path         VARCHAR NOT NULL,
    sha256       VARCHAR NOT NULL,
    size_bytes   BIGINT,
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (plugin_id, run_id, name)
);

CREATE INDEX IF NOT EXISTS idx_run_artifacts_run
    ON run_artifacts(plugin_id, run_id);
