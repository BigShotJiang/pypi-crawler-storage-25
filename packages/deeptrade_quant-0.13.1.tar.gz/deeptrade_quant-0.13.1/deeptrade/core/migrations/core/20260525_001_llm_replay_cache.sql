-- v0.12 — framework-level LLM response replay cache.
--
-- Underpins cross-plugin reproducibility: any plugin that calls
-- ``LLMClient.complete_json(..., replay=...)`` with a non-disabled policy
-- writes successful responses here and reads them back on identical
-- inputs. Owned by the framework so the table is consistent for compare
-- / inspect / purge across plugins; not a plugin-private table.
--
-- Column notes:
--   cache_key                : sha256(canonical_json({plugin_id, stage,
--                              provider, model, system_sha256, user_sha256,
--                              profile, schema_name, schema_version,
--                              input_fingerprint, framework cache version})).
--                              Hex string. The exact recipe lives in
--                              ``deeptrade.core.llm_replay``; any change
--                              to the recipe MUST bump
--                              ``FRAMEWORK_LLM_CACHE_VERSION`` so legacy
--                              entries miss instead of being misread.
--   plugin_id                : owner. ``__framework__`` for any
--                              framework-internal calls.
--   stage                    : plugin-defined stage name (e.g.
--                              "screening" / "prediction"). Free-form
--                              non-empty string.
--   provider / model         : LLM identity. ``model`` is the literal
--                              model string sent to the transport — if
--                              the provider silently upgrades the model
--                              behind the same string, the cache will
--                              still hit. Users who want to bust the
--                              cache after a vendor-side change use
--                              ``--fresh-llm`` or the purge command.
--   prompt_hash              : sha256(system + user). Audit aid; NOT
--                              the cache key (which also includes
--                              profile / schema / fingerprint).
--   profile_json             : canonical JSON of {temperature,
--                              max_output_tokens, thinking,
--                              reasoning_effort}.
--   schema_name              : ``schema.__name__`` of the Pydantic model
--                              validated against. Aids audit; cache key
--                              already includes schema_version.
--   schema_version           : caller-supplied version string. Bumping
--                              this is how plugins invalidate cache
--                              after a schema-breaking change.
--   input_fingerprint        : caller-supplied opaque hash representing
--                              upstream business inputs. Optional
--                              (NULL allowed) but recommended.
--   request_fingerprint_json : the full canonical-JSON dict that was
--                              hashed to produce cache_key. Stored for
--                              audit / `db llm-cache inspect`; never read
--                              for cache logic.
--   response_json            : canonical-JSON encoding of the validated
--                              Pydantic model. Replay path re-validates
--                              this via ``schema.model_validate`` so any
--                              future schema-tightening is caught.
--   response_meta_json       : tokens / latency / final_prompt_hash /
--                              attempt_count from the original call.
--                              Surfaced back to callers with
--                              ``cache_hit=true`` in meta.
--   source_run_id            : the run_id that produced this cache row.
--   source_call_id           : llm_calls.call_id that produced this row.
--   created_at               : write time.

CREATE TABLE IF NOT EXISTS llm_replay_cache (
    cache_key                VARCHAR PRIMARY KEY,
    plugin_id                VARCHAR NOT NULL,
    stage                    VARCHAR NOT NULL,
    provider                 VARCHAR NOT NULL,
    model                    VARCHAR NOT NULL,
    prompt_hash              VARCHAR NOT NULL,
    profile_json             VARCHAR NOT NULL,
    schema_name              VARCHAR NOT NULL,
    schema_version           VARCHAR NOT NULL,
    input_fingerprint        VARCHAR,
    request_fingerprint_json VARCHAR NOT NULL,
    response_json            VARCHAR NOT NULL,
    response_meta_json       VARCHAR NOT NULL,
    source_run_id            VARCHAR,
    source_call_id           VARCHAR,
    created_at               TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_llm_replay_plugin_stage
    ON llm_replay_cache(plugin_id, stage, provider, model, prompt_hash);

CREATE INDEX IF NOT EXISTS idx_llm_replay_created_at
    ON llm_replay_cache(created_at);
