-- v0.10 H3 — Tushare audit now covers failure paths.
--
-- The pre-existing row schema only captured (plugin_id, api_name, params_hash,
-- rows, latency_ms, called_at). That made successful calls auditable but
-- discarded everything about HTTP 429s, 5xx, timeouts, unauthorized rejections,
-- retry chains and cache fallback. The new columns close that gap:
--
--   status        : outcome of THIS single transport attempt — ok | rate_limit |
--                   server_error | transport_error | unauthorized |
--                   unknown_error | fallback (synthetic, see cache_action)
--   error_type    : fully-qualified Python exception class (NULL on success)
--   error_message : trimmed str(e) for the failure (NULL on success)
--   attempt_no    : 1-based counter within the tenacity retry chain;
--                   1 for one-shot calls, 2..N for retried attempts.
--   run_id        : caller-supplied UUID; lets users correlate Tushare calls
--                   with the run-level reports/<run_id>/ tree.
--   cache_action  : 'fresh' (just fetched), 'fallback' (served from cache
--                   after upstream 5xx) or NULL when the attempt did not
--                   produce a payload (rate-limit / unauthorized / etc.).
--
-- DuckDB only allows one ADD COLUMN per ALTER TABLE statement.
ALTER TABLE tushare_calls ADD COLUMN status        VARCHAR;
ALTER TABLE tushare_calls ADD COLUMN error_type    VARCHAR;
ALTER TABLE tushare_calls ADD COLUMN error_message VARCHAR;
ALTER TABLE tushare_calls ADD COLUMN attempt_no    INTEGER;
ALTER TABLE tushare_calls ADD COLUMN run_id        VARCHAR;
ALTER TABLE tushare_calls ADD COLUMN cache_action  VARCHAR;

-- Backfill historical rows: every row that existed before this migration
-- represents a SUCCESSFUL one-shot transport call (the only path that wrote
-- to tushare_calls pre-v0.10). Mark them as such so post-migration reads
-- can rely on status NOT being NULL.
UPDATE tushare_calls SET status = 'ok', attempt_no = 1, cache_action = 'fresh'
WHERE status IS NULL;
