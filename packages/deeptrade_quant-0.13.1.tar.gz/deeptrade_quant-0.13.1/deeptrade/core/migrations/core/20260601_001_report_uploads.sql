-- v0.11 — report_uploads audit table.
--
-- Framework-level table that records every ReportUploader.upload() call —
-- success, skipped, and failed alike. Mirrors the (plugin_id, run_id) keying
-- convention used by `llm_calls` / `tushare_calls` so cross-table queries by
-- run stay uniform.
--
-- Column notes:
--   status        : 'ok' | 'skipped_disabled' | 'skipped_missing_file' | 'failed'
--                   — see UploadResult.status in deeptrade.core.report_uploader.
--   http_status   : last-seen HTTP status code (NULL when no request was sent,
--                   e.g. skipped paths or pre-flight network failure).
--   public_url    : server-returned permalink on 'ok'. NULL otherwise.
--   public_path   : server-returned pathname on 'ok'. NULL otherwise.
--   file_bytes    : size of the JSON payload that was POSTed; NULL on
--                   skipped_* (file wasn't read).
--   error_class   : Python exception class name on 'failed' (e.g. URLError,
--                   HTTPError, UploadError, TimeoutError).
--   error         : trimmed str(exc) for the failure (NULL on success/skipped).
--
-- ⚠ The uploader explicitly does NOT log `token` / `Authorization` headers
-- into this table. Anyone joining `report_uploads` for analytics can trust
-- that no row contains the bearer token.
CREATE TABLE IF NOT EXISTS report_uploads (
    upload_id    UUID PRIMARY KEY,
    plugin_id    VARCHAR NOT NULL,
    run_id       VARCHAR,
    trade_date   VARCHAR,
    plugin_name  VARCHAR,
    file_path    VARCHAR NOT NULL,
    file_bytes   BIGINT,
    status       VARCHAR NOT NULL,
    http_status  INTEGER,
    public_url   VARCHAR,
    public_path  VARCHAR,
    duration_ms  DOUBLE,
    error_class  VARCHAR,
    error        VARCHAR,
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
