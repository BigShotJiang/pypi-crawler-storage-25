"""Cross-plugin run metadata — DAO over ``run_metadata`` and ``run_artifacts``.

The framework deliberately does NOT own a unified "runs" table; each
plugin keeps its own ``<prefix>_runs`` with business-specific columns
and a state machine. These tables hold only the metadata subset that
is cross-plugin meaningful and is read by ``deeptrade run compare`` /
``deeptrade run show``:

* ``run_metadata``  — key date (e.g. trade_date), input fingerprint,
                      and the canonical input payload JSON.
* ``run_artifacts`` — file artifacts written by a run (sha256-keyed
                      so compare can show byte-level identity).

Both tables are keyed by ``(plugin_id, run_id)``. The plugin's own
``<prefix>_runs`` is the authoritative business state; this table is
purely a *side-channel* for cross-plugin observability.

Public DAO: :class:`RunMetadataStore`. The everyday surface lives on
:class:`deeptrade.plugins_api.PluginContext` as thin facades; plugins
should call ``ctx.set_run_key_date(...)`` rather than instantiating the
store directly. The dataclasses :class:`RunMetadata` /
:class:`RunArtifact` are re-exported from :mod:`deeptrade.plugins_api`
as the return type of the read methods.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from deeptrade.core.fingerprint import canonical_json, hash_file

if TYPE_CHECKING:  # pragma: no cover — type-only
    from deeptrade.core.db import Database


__all__ = [
    "RunArtifact",
    "RunMetadata",
    "RunMetadataStore",
]


# ---------------------------------------------------------------------------
# Public dataclasses
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class RunMetadata:
    """A row from ``run_metadata``.

    ``input_payload`` is the parsed JSON dict from
    ``run_metadata.input_payload_json``; ``None`` when the plugin did
    not persist a payload alongside its fingerprint.
    """

    plugin_id: str
    run_id: str
    key_date: date | None
    input_fingerprint: str | None
    input_payload: Any | None
    created_at: datetime
    updated_at: datetime


@dataclass(frozen=True)
class RunArtifact:
    """A row from ``run_artifacts``."""

    artifact_id: int
    plugin_id: str
    run_id: str
    name: str
    path: str
    sha256: str
    size_bytes: int | None
    created_at: datetime


# ---------------------------------------------------------------------------
# Store
# ---------------------------------------------------------------------------


class RunMetadataStore:
    """Thin DAO over ``run_metadata`` and ``run_artifacts``.

    All write methods are UPSERTs so callers may legitimately invoke
    them more than once (e.g. set_run_key_date once after sync, and
    again later after Step 0 firms up the real trade_date). Reads
    return ``None`` / empty list when the row does not exist; they
    never raise.
    """

    def __init__(self, db: Database, *, plugin_id: str) -> None:
        if not plugin_id:
            raise ValueError("RunMetadataStore: plugin_id must be a non-empty string")
        self._db = db
        self._plugin_id = plugin_id

    # ------------------------------------------------------------------
    # run_metadata
    # ------------------------------------------------------------------

    def set_key_date(self, run_id: str, key_date: date | str | None) -> None:
        """Upsert ``run_metadata.key_date`` for this ``(plugin_id, run_id)``.

        Passing ``key_date=None`` is allowed and EXPLICITLY writes NULL —
        useful when an earlier provisional date should be cleared. A
        plain ISO-8601 string ('YYYY-MM-DD') is also accepted; DuckDB's
        DATE column parses it on insert.
        """
        if not run_id:
            raise ValueError("set_key_date: run_id must be a non-empty string")
        normalized: date | str | None
        if isinstance(key_date, date):
            normalized = key_date
        elif isinstance(key_date, str):
            normalized = key_date
        elif key_date is None:
            normalized = None
        else:
            raise TypeError(
                f"set_key_date: key_date must be date | str | None, got {type(key_date).__name__}"
            )
        with self._db.transaction():
            self._db.execute(
                "INSERT INTO run_metadata(plugin_id, run_id, key_date) "
                "VALUES (?, ?, ?) "
                "ON CONFLICT (plugin_id, run_id) DO UPDATE SET "
                "  key_date = EXCLUDED.key_date, "
                "  updated_at = now()",
                (self._plugin_id, run_id, normalized),
            )

    def set_input_fingerprint(
        self,
        run_id: str,
        fingerprint: str,
        payload: Any | None = None,
    ) -> None:
        """Upsert ``input_fingerprint`` (+ optional canonical payload).

        ``fingerprint`` is opaque to the framework — typically the plugin
        computed it via :func:`deeptrade.core.fingerprint.hash_json` over
        its business inputs. ``payload`` is the matching object the
        fingerprint was derived from; we store its canonical-JSON
        encoding so ``deeptrade run compare`` can show field-level
        diffs. Pass ``payload=None`` when size is prohibitive — the
        fingerprint alone is still enough for compare to flag identity.
        """
        if not run_id:
            raise ValueError("set_input_fingerprint: run_id must be a non-empty string")
        if not isinstance(fingerprint, str) or not fingerprint:
            raise ValueError("set_input_fingerprint: fingerprint must be a non-empty string")
        payload_json = canonical_json(payload) if payload is not None else None
        with self._db.transaction():
            self._db.execute(
                "INSERT INTO run_metadata(plugin_id, run_id, input_fingerprint, input_payload_json) "
                "VALUES (?, ?, ?, ?) "
                "ON CONFLICT (plugin_id, run_id) DO UPDATE SET "
                "  input_fingerprint = EXCLUDED.input_fingerprint, "
                "  input_payload_json = EXCLUDED.input_payload_json, "
                "  updated_at = now()",
                (self._plugin_id, run_id, fingerprint, payload_json),
            )

    def get(self, run_id: str) -> RunMetadata | None:
        """Return the ``run_metadata`` row, or ``None`` if absent."""
        row = self._db.fetchone(
            "SELECT plugin_id, run_id, key_date, input_fingerprint, "
            "input_payload_json, created_at, updated_at "
            "FROM run_metadata WHERE plugin_id = ? AND run_id = ?",
            (self._plugin_id, run_id),
        )
        if row is None:
            return None
        plugin_id, run_id_v, key_date_v, fingerprint, payload_json, created_at, updated_at = row
        return RunMetadata(
            plugin_id=plugin_id,
            run_id=run_id_v,
            key_date=key_date_v,
            input_fingerprint=fingerprint,
            input_payload=json.loads(payload_json) if payload_json else None,
            created_at=created_at,
            updated_at=updated_at,
        )

    # ------------------------------------------------------------------
    # run_artifacts
    # ------------------------------------------------------------------

    def add_artifact(
        self,
        run_id: str,
        *,
        name: str,
        path: str | Path,
        sha256: str | None = None,
    ) -> RunArtifact:
        """Insert (or replace) an artifact row. Returns the persisted row.

        When ``sha256`` is ``None`` the file at ``path`` is streamed
        through :func:`deeptrade.core.fingerprint.hash_file` to compute
        it. If the file is missing AND ``sha256`` is ``None`` we raise
        :class:`FileNotFoundError` — the framework refuses to record an
        unverifiable artifact.

        ``size_bytes`` is best-effort: ``os.path.getsize`` when the file
        exists, else ``None``. We do not error on missing-file-but-
        sha256-supplied because the plugin may legitimately be recording
        an artifact whose path is a URL or pseudo-path.

        ``(plugin_id, run_id, name)`` is UNIQUE; re-adding the same name
        REPLACES the prior row (new artifact_id, new created_at).
        """
        if not run_id:
            raise ValueError("add_artifact: run_id must be a non-empty string")
        if not name:
            raise ValueError("add_artifact: name must be a non-empty string")
        path_str = str(path)
        if sha256 is None:
            sha256 = hash_file(path)
        size_bytes: int | None
        try:
            size_bytes = os.path.getsize(path_str)
        except OSError:
            size_bytes = None

        with self._db.transaction():
            # No native ON CONFLICT path here because the surrogate
            # ``artifact_id`` is the primary key while ``(plugin_id, run_id,
            # name)`` is the natural key. DELETE+INSERT keeps surrogate
            # semantics intact: every replacement gets a fresh id, which
            # downstream tooling can use to detect "I overwrote this".
            self._db.execute(
                "DELETE FROM run_artifacts WHERE plugin_id = ? AND run_id = ? AND name = ?",
                (self._plugin_id, run_id, name),
            )
            self._db.execute(
                "INSERT INTO run_artifacts("
                "plugin_id, run_id, name, path, sha256, size_bytes"
                ") VALUES (?, ?, ?, ?, ?, ?)",
                (self._plugin_id, run_id, name, path_str, sha256, size_bytes),
            )
            row = self._db.fetchone(
                "SELECT artifact_id, plugin_id, run_id, name, path, sha256, "
                "size_bytes, created_at "
                "FROM run_artifacts "
                "WHERE plugin_id = ? AND run_id = ? AND name = ?",
                (self._plugin_id, run_id, name),
            )
        assert row is not None, "add_artifact: insert succeeded but row missing"
        return RunArtifact(
            artifact_id=int(row[0]),
            plugin_id=row[1],
            run_id=row[2],
            name=row[3],
            path=row[4],
            sha256=row[5],
            size_bytes=int(row[6]) if row[6] is not None else None,
            created_at=row[7],
        )

    def list_artifacts(self, run_id: str) -> list[RunArtifact]:
        """Return all artifacts for ``(plugin_id, run_id)``, ordered by name."""
        rows = self._db.fetchall(
            "SELECT artifact_id, plugin_id, run_id, name, path, sha256, "
            "size_bytes, created_at "
            "FROM run_artifacts "
            "WHERE plugin_id = ? AND run_id = ? "
            "ORDER BY name",
            (self._plugin_id, run_id),
        )
        return [
            RunArtifact(
                artifact_id=int(r[0]),
                plugin_id=r[1],
                run_id=r[2],
                name=r[3],
                path=r[4],
                sha256=r[5],
                size_bytes=int(r[6]) if r[6] is not None else None,
                created_at=r[7],
            )
            for r in rows
        ]
