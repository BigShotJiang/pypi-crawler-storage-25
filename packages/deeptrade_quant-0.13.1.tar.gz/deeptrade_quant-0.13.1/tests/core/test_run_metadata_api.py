"""v0.12 — PluginContext.set_run_*  / add_run_artifact / get_run_metadata.

Exercises the framework-level cross-plugin run-metadata API exposed on
:class:`deeptrade.plugins_api.PluginContext`. The DAO underneath
(:class:`deeptrade.core.run_metadata.RunMetadataStore`) is the
implementation we are validating; ``PluginContext`` is the public
surface plugins import.
"""

from __future__ import annotations

from datetime import date, datetime
from pathlib import Path

import pytest

from deeptrade.core.config import ConfigService
from deeptrade.core.db import Database
from deeptrade.core.fingerprint import hash_file, hash_json
from deeptrade.plugins_api import (
    PluginContext,
    RunArtifact,
    RunMetadata,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


RUN_ID = "00000000-0000-0000-0000-0000000000a1"


@pytest.fixture
def db(tmp_path: Path) -> Database:
    return Database(tmp_path / "runmeta.duckdb")


@pytest.fixture
def config(db: Database) -> ConfigService:
    return ConfigService(db)


@pytest.fixture
def ctx(db: Database, config: ConfigService) -> PluginContext:
    return PluginContext(db=db, config=config, plugin_id="test-plugin")


# ---------------------------------------------------------------------------
# set_run_key_date
# ---------------------------------------------------------------------------


def test_set_run_key_date_creates_row(ctx: PluginContext, db: Database) -> None:
    ctx.set_run_key_date(RUN_ID, date(2026, 5, 24))
    row = db.fetchone(
        "SELECT plugin_id, run_id, key_date FROM run_metadata WHERE plugin_id=? AND run_id=?",
        ("test-plugin", RUN_ID),
    )
    assert row == ("test-plugin", RUN_ID, date(2026, 5, 24))


def test_set_run_key_date_idempotent(ctx: PluginContext, db: Database) -> None:
    ctx.set_run_key_date(RUN_ID, date(2026, 5, 24))
    ctx.set_run_key_date(RUN_ID, date(2026, 5, 24))
    rows = db.fetchall(
        "SELECT key_date FROM run_metadata WHERE plugin_id=? AND run_id=?",
        ("test-plugin", RUN_ID),
    )
    # exactly one row, same value — UPSERT collapsed the duplicate.
    assert rows == [(date(2026, 5, 24),)]


def test_set_run_key_date_overrides_prior(ctx: PluginContext, db: Database) -> None:
    ctx.set_run_key_date(RUN_ID, date(2026, 5, 24))
    ctx.set_run_key_date(RUN_ID, date(2026, 5, 25))
    row = db.fetchone(
        "SELECT key_date FROM run_metadata WHERE plugin_id=? AND run_id=?",
        ("test-plugin", RUN_ID),
    )
    assert row == (date(2026, 5, 25),)


def test_set_run_key_date_accepts_iso_string(ctx: PluginContext) -> None:
    ctx.set_run_key_date(RUN_ID, "2026-05-24")
    meta = ctx.get_run_metadata(RUN_ID)
    assert meta is not None
    assert meta.key_date == date(2026, 5, 24)


def test_set_run_key_date_none_writes_null(ctx: PluginContext) -> None:
    ctx.set_run_key_date(RUN_ID, date(2026, 5, 24))
    ctx.set_run_key_date(RUN_ID, None)
    meta = ctx.get_run_metadata(RUN_ID)
    assert meta is not None
    assert meta.key_date is None


def test_set_run_key_date_rejects_bad_type(ctx: PluginContext) -> None:
    with pytest.raises(TypeError, match="date \\| str \\| None"):
        ctx.set_run_key_date(RUN_ID, 20260524)  # type: ignore[arg-type]


def test_set_run_key_date_rejects_empty_run_id(ctx: PluginContext) -> None:
    with pytest.raises(ValueError, match="run_id"):
        ctx.set_run_key_date("", date(2026, 5, 24))


# ---------------------------------------------------------------------------
# set_run_input_fingerprint
# ---------------------------------------------------------------------------


def test_set_run_input_fingerprint_with_payload(ctx: PluginContext, db: Database) -> None:
    payload = {"trade_date": "2026-05-24", "candidates": ["A", "B"]}
    fingerprint = hash_json(payload)
    ctx.set_run_input_fingerprint(RUN_ID, fingerprint, payload)
    row = db.fetchone(
        "SELECT input_fingerprint, input_payload_json FROM run_metadata "
        "WHERE plugin_id=? AND run_id=?",
        ("test-plugin", RUN_ID),
    )
    assert row is not None
    assert row[0] == fingerprint
    # Payload persisted as canonical JSON — keys sorted, tight separators.
    assert row[1] == '{"candidates":["A","B"],"trade_date":"2026-05-24"}'


def test_set_run_input_fingerprint_without_payload(ctx: PluginContext, db: Database) -> None:
    ctx.set_run_input_fingerprint(RUN_ID, "deadbeef")
    row = db.fetchone(
        "SELECT input_fingerprint, input_payload_json FROM run_metadata "
        "WHERE plugin_id=? AND run_id=?",
        ("test-plugin", RUN_ID),
    )
    assert row == ("deadbeef", None)


def test_set_run_input_fingerprint_rejects_empty(ctx: PluginContext) -> None:
    with pytest.raises(ValueError, match="fingerprint"):
        ctx.set_run_input_fingerprint(RUN_ID, "")


def test_independent_writes_do_not_clobber_each_other(
    ctx: PluginContext,
) -> None:
    """``set_run_key_date`` and ``set_run_input_fingerprint`` upsert
    DIFFERENT columns. The second call must not blank out the first."""
    ctx.set_run_key_date(RUN_ID, date(2026, 5, 24))
    ctx.set_run_input_fingerprint(RUN_ID, "fp1", {"x": 1})
    meta = ctx.get_run_metadata(RUN_ID)
    assert meta is not None
    assert meta.key_date == date(2026, 5, 24)
    assert meta.input_fingerprint == "fp1"
    assert meta.input_payload == {"x": 1}


def test_reverse_order_does_not_clobber(ctx: PluginContext) -> None:
    """Same as above but the order is fingerprint→key_date."""
    ctx.set_run_input_fingerprint(RUN_ID, "fp1", {"x": 1})
    ctx.set_run_key_date(RUN_ID, date(2026, 5, 24))
    meta = ctx.get_run_metadata(RUN_ID)
    assert meta is not None
    assert meta.key_date == date(2026, 5, 24)
    assert meta.input_fingerprint == "fp1"
    assert meta.input_payload == {"x": 1}


# ---------------------------------------------------------------------------
# get_run_metadata
# ---------------------------------------------------------------------------


def test_get_run_metadata_missing_returns_none(ctx: PluginContext) -> None:
    assert ctx.get_run_metadata(RUN_ID) is None


def test_get_run_metadata_returns_typed_dataclass(ctx: PluginContext) -> None:
    ctx.set_run_key_date(RUN_ID, date(2026, 5, 24))
    ctx.set_run_input_fingerprint(RUN_ID, "fp1", {"k": "v"})
    meta = ctx.get_run_metadata(RUN_ID)
    assert isinstance(meta, RunMetadata)
    assert meta.plugin_id == "test-plugin"
    assert meta.run_id == RUN_ID
    assert meta.key_date == date(2026, 5, 24)
    assert meta.input_fingerprint == "fp1"
    assert meta.input_payload == {"k": "v"}
    assert isinstance(meta.created_at, datetime)
    assert isinstance(meta.updated_at, datetime)


# ---------------------------------------------------------------------------
# Plugin isolation — one plugin's writes don't leak to another
# ---------------------------------------------------------------------------


def test_plugin_isolation(db: Database, config: ConfigService) -> None:
    a = PluginContext(db=db, config=config, plugin_id="plugin-A")
    b = PluginContext(db=db, config=config, plugin_id="plugin-B")
    a.set_run_key_date(RUN_ID, date(2026, 5, 24))
    b.set_run_key_date(RUN_ID, date(2026, 6, 30))
    meta_a = a.get_run_metadata(RUN_ID)
    meta_b = b.get_run_metadata(RUN_ID)
    assert meta_a is not None and meta_a.key_date == date(2026, 5, 24)
    assert meta_b is not None and meta_b.key_date == date(2026, 6, 30)


# ---------------------------------------------------------------------------
# Anonymous context (plugin_id=None) — must raise
# ---------------------------------------------------------------------------


def test_anonymous_context_raises(db: Database, config: ConfigService) -> None:
    anon = PluginContext(db=db, config=config, plugin_id=None)
    with pytest.raises(RuntimeError, match="plugin_id"):
        anon.set_run_key_date(RUN_ID, date(2026, 5, 24))
    with pytest.raises(RuntimeError, match="plugin_id"):
        anon.set_run_input_fingerprint(RUN_ID, "fp")
    with pytest.raises(RuntimeError, match="plugin_id"):
        anon.get_run_metadata(RUN_ID)


# ---------------------------------------------------------------------------
# add_run_artifact / list_run_artifacts
# ---------------------------------------------------------------------------


def test_add_run_artifact_auto_hashes_file(ctx: PluginContext, tmp_path: Path) -> None:
    p = tmp_path / "summary.md"
    p.write_text("hello deeptrade", encoding="utf-8")
    artifact = ctx.add_run_artifact(RUN_ID, name="summary.md", path=p)
    assert isinstance(artifact, RunArtifact)
    assert artifact.name == "summary.md"
    assert artifact.path == str(p)
    assert artifact.sha256 == hash_file(p)
    assert artifact.size_bytes == len(b"hello deeptrade")
    assert artifact.artifact_id > 0


def test_add_run_artifact_accepts_explicit_sha256(ctx: PluginContext, tmp_path: Path) -> None:
    """When the caller passes ``sha256`` we do NOT re-read the file."""
    artifact = ctx.add_run_artifact(
        RUN_ID,
        name="external",
        path="https://example.com/report.json",  # non-filesystem path
        sha256="a" * 64,
    )
    assert artifact.sha256 == "a" * 64
    # size_bytes is None because the path isn't a real file.
    assert artifact.size_bytes is None


def test_add_run_artifact_replace_on_same_name(ctx: PluginContext, tmp_path: Path) -> None:
    a = tmp_path / "x.txt"
    a.write_text("v1")
    first = ctx.add_run_artifact(RUN_ID, name="x.txt", path=a)
    a.write_text("v2")
    second = ctx.add_run_artifact(RUN_ID, name="x.txt", path=a)
    # New artifact_id (replace semantics), new sha256.
    assert second.artifact_id != first.artifact_id
    assert second.sha256 != first.sha256
    arts = ctx.list_run_artifacts(RUN_ID)
    # Only one row for the same name — the replacement wins.
    assert len(arts) == 1
    assert arts[0].artifact_id == second.artifact_id


def test_add_run_artifact_missing_file_no_sha_raises(ctx: PluginContext, tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError):
        ctx.add_run_artifact(RUN_ID, name="ghost", path=tmp_path / "nope")


def test_add_run_artifact_rejects_empty_name(ctx: PluginContext, tmp_path: Path) -> None:
    p = tmp_path / "f.bin"
    p.write_bytes(b"x")
    with pytest.raises(ValueError, match="name"):
        ctx.add_run_artifact(RUN_ID, name="", path=p)


def test_list_run_artifacts_empty(ctx: PluginContext) -> None:
    assert ctx.list_run_artifacts(RUN_ID) == []


def test_list_run_artifacts_ordered_by_name(ctx: PluginContext, tmp_path: Path) -> None:
    for name in ("zeta.md", "alpha.md", "mu.md"):
        p = tmp_path / name
        p.write_text(name)
        ctx.add_run_artifact(RUN_ID, name=name, path=p)
    arts = ctx.list_run_artifacts(RUN_ID)
    assert [a.name for a in arts] == ["alpha.md", "mu.md", "zeta.md"]


def test_artifact_unique_constraint_per_plugin_run(
    db: Database, config: ConfigService, tmp_path: Path
) -> None:
    """Two plugins recording an artifact with the same logical name and
    the same run_id must coexist — uniqueness is scoped to
    (plugin_id, run_id, name)."""
    a = PluginContext(db=db, config=config, plugin_id="plugin-A")
    b = PluginContext(db=db, config=config, plugin_id="plugin-B")
    p = tmp_path / "shared.md"
    p.write_text("payload")
    a.add_run_artifact(RUN_ID, name="shared.md", path=p)
    b.add_run_artifact(RUN_ID, name="shared.md", path=p)
    assert len(a.list_run_artifacts(RUN_ID)) == 1
    assert len(b.list_run_artifacts(RUN_ID)) == 1


def test_artifact_isolation_across_runs(ctx: PluginContext, tmp_path: Path) -> None:
    """Two different run_ids under the same plugin can each have their
    own artifact named 'summary.md' — the UNIQUE includes run_id."""
    p = tmp_path / "summary.md"
    p.write_text("payload")
    other_run = "00000000-0000-0000-0000-0000000000a2"
    ctx.add_run_artifact(RUN_ID, name="summary.md", path=p)
    ctx.add_run_artifact(other_run, name="summary.md", path=p)
    assert len(ctx.list_run_artifacts(RUN_ID)) == 1
    assert len(ctx.list_run_artifacts(other_run)) == 1


# ---------------------------------------------------------------------------
# Store is cached on context
# ---------------------------------------------------------------------------


def test_run_store_cached_on_context(ctx: PluginContext) -> None:
    store_a = ctx._run_store()
    store_b = ctx._run_store()
    assert store_a is store_b
