"""v0.11 — ReportUploader unit tests.

Covers the public contract of :class:`deeptrade.core.report_uploader.ReportUploader`:

* Gate paths (``enabled=False`` / missing file / wrong suffix) return the
  right ``UploadResult.status`` and still write an audit row.
* Happy path issues a single POST with the configured token bearer, parses
  the JSON body, returns ``status="ok"``, and audits ``public_url`` etc.
* Failure paths (HTTPError / URLError / TimeoutError / malformed JSON /
  non-2xx status / token-empty) all encode into ``UploadResult`` rather than
  raising, and ``report_uploads`` records ``error_class`` / ``error``.
* ``token`` never leaks: neither the audit row nor any captured stack trace
  may contain the configured bearer string.

The uploader is stdlib-only, so ``urlopen`` is the single monkeypatch seam.
"""

from __future__ import annotations

import dataclasses
import io
import json
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError

import pytest

from deeptrade.core.config import ConfigService
from deeptrade.core.db import Database
from deeptrade.core.report_uploader import (
    ReportUploader,
    UploadError,
    UploadResult,
    _build_multipart,
)
from deeptrade.core.secrets import SecretStore

UPLOAD_MODULE = "deeptrade.core.report_uploader"
SAMPLE_TOKEN = "test-bearer-do-not-leak"  # noqa: S105 — fixture sentinel
SAMPLE_PLUGIN = "test-plugin"


# ---------------------------------------------------------------------------
# fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def db(tmp_path: Path) -> Database:
    return Database(tmp_path / "test.duckdb")


@pytest.fixture
def config(db: Database) -> ConfigService:
    return ConfigService(db, secret_store=SecretStore(db, force_plaintext=True))


@pytest.fixture
def report_file(tmp_path: Path) -> Path:
    p = tmp_path / "summary.json"
    p.write_text(json.dumps({"hello": "world"}), encoding="utf-8")
    return p


def _make_uploader(
    db: Database, config: ConfigService, *, run_id: str | None = None
) -> ReportUploader:
    return ReportUploader(db, config, plugin_id=SAMPLE_PLUGIN, run_id=run_id)


def _audit_rows(db: Database) -> list[dict[str, Any]]:
    cols = [
        "upload_id",
        "plugin_id",
        "run_id",
        "trade_date",
        "plugin_name",
        "file_path",
        "file_bytes",
        "status",
        "http_status",
        "public_url",
        "public_path",
        "duration_ms",
        "error_class",
        "error",
    ]
    rows = db.fetchall("SELECT " + ", ".join(cols) + " FROM report_uploads ORDER BY created_at")
    return [dict(zip(cols, r, strict=True)) for r in rows]


class _FakeResponse(io.BytesIO):
    """Minimal stand-in for the ``urlopen`` context-manager result."""

    def __init__(self, body: bytes, status: int = 200) -> None:
        super().__init__(body)
        self.status = status

    def getcode(self) -> int:
        return self.status

    def __enter__(self) -> _FakeResponse:
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()


# ---------------------------------------------------------------------------
# A. gate paths
# ---------------------------------------------------------------------------


def test_disabled_skips_request_and_audits(
    db: Database, config: ConfigService, report_file: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """enabled=False (default) → no HTTP call, status=skipped_disabled, one audit row."""
    called = []
    monkeypatch.setattr(
        f"{UPLOAD_MODULE}.urlopen",
        lambda *a, **kw: called.append((a, kw)) or _FakeResponse(b"{}"),
    )
    result = _make_uploader(db, config).upload(report_file, plugin_name="X", trade_date="20260601")
    assert result.status == "skipped_disabled"
    assert called == []  # uploader must short-circuit before urlopen
    rows = _audit_rows(db)
    assert len(rows) == 1
    assert rows[0]["status"] == "skipped_disabled"
    assert rows[0]["plugin_id"] == SAMPLE_PLUGIN
    assert rows[0]["file_bytes"] is None  # file not read on the skipped path


def test_missing_file_returns_skipped(db: Database, config: ConfigService, tmp_path: Path) -> None:
    config.set("report.upload.enabled", True)
    result = _make_uploader(db, config).upload(
        tmp_path / "does-not-exist.json", plugin_name="X", trade_date="20260601"
    )
    assert result.status == "skipped_missing_file"


def test_wrong_suffix_returns_skipped(db: Database, config: ConfigService, tmp_path: Path) -> None:
    config.set("report.upload.enabled", True)
    p = tmp_path / "summary.txt"
    p.write_text("hi", encoding="utf-8")
    result = _make_uploader(db, config).upload(p, plugin_name="X", trade_date="20260601")
    assert result.status == "skipped_missing_file"


# ---------------------------------------------------------------------------
# B. happy path
# ---------------------------------------------------------------------------


def test_ok_path_posts_with_bearer_and_parses_response(
    db: Database, config: ConfigService, report_file: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    config.set("report.upload.enabled", True)
    config.set("report.upload.url", "https://example.invalid/api/reports/upload")
    config.set("report.upload.timeout", 5.0)
    config.set("report.upload.token", SAMPLE_TOKEN)

    captured: dict[str, Any] = {}

    def fake_urlopen(req: Any, timeout: float = 0.0) -> _FakeResponse:
        captured["url"] = req.full_url
        captured["headers"] = dict(req.header_items())
        captured["data"] = req.data
        captured["timeout"] = timeout
        body = json.dumps(
            {
                "success": True,
                "url": "https://blob.example/x.json",
                "pathname": "reports/2026-06-01/1.json",
                "index": 1,
                "date": "2026-06-01",
            }
        ).encode("utf-8")
        return _FakeResponse(body, status=200)

    monkeypatch.setattr(f"{UPLOAD_MODULE}.urlopen", fake_urlopen)

    result = _make_uploader(db, config, run_id="run-abc").upload(
        report_file,
        plugin_name="测试策略",
        trade_date="20260601",
        extra_fields={"strategy_version": "0.1"},
    )

    assert result.status == "ok"
    assert result.public_url == "https://blob.example/x.json"
    assert result.public_path == "reports/2026-06-01/1.json"
    assert result.public_index == 1
    assert result.public_date == "2026-06-01"
    assert result.http_status == 200
    assert result.duration_ms >= 0.0

    # Authorization MUST be present and use the configured token.
    auth_header = {k.lower(): v for k, v in captured["headers"].items()}.get("authorization")
    assert auth_header == f"Bearer {SAMPLE_TOKEN}"
    # multipart body includes plugin_name + trade_date + extra_fields + the file
    body = captured["data"]
    assert b'name="plugin_name"' in body and "测试策略".encode() in body
    assert b'name="trade_date"' in body and b"20260601" in body
    assert b'name="strategy_version"' in body and b"0.1" in body
    assert b'name="file"; filename="summary.json"' in body
    assert captured["timeout"] == 5.0

    # Audit row
    rows = _audit_rows(db)
    assert len(rows) == 1
    row = rows[0]
    assert row["status"] == "ok"
    assert row["public_url"] == "https://blob.example/x.json"
    assert row["run_id"] == "run-abc"
    assert row["http_status"] == 200
    assert row["plugin_name"] == "测试策略"
    assert row["file_bytes"] == report_file.stat().st_size

    # Token must NOT appear anywhere in the audit table.
    full_audit = json.dumps(row, default=str)
    assert SAMPLE_TOKEN not in full_audit


def test_empty_token_omits_authorization_header(
    db: Database, config: ConfigService, report_file: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    config.set("report.upload.enabled", True)
    # explicitly do NOT set report.upload.token → anonymous

    captured: dict[str, Any] = {}

    def fake_urlopen(req: Any, timeout: float = 0.0) -> _FakeResponse:
        captured["headers"] = dict(req.header_items())
        return _FakeResponse(json.dumps({"url": "https://x", "pathname": "p"}).encode(), 200)

    monkeypatch.setattr(f"{UPLOAD_MODULE}.urlopen", fake_urlopen)

    result = _make_uploader(db, config).upload(report_file, plugin_name="X", trade_date="20260601")
    assert result.status == "ok"
    lower = {k.lower() for k in captured["headers"]}
    assert "authorization" not in lower


# ---------------------------------------------------------------------------
# C. failure paths — never raise
# ---------------------------------------------------------------------------


def test_http_error_yields_failed_result(
    db: Database, config: ConfigService, report_file: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    config.set("report.upload.enabled", True)

    def fake_urlopen(req: Any, timeout: float = 0.0) -> Any:
        raise HTTPError(
            url=req.full_url,
            code=403,
            msg="Forbidden",
            hdrs=None,  # type: ignore[arg-type]
            fp=io.BytesIO(b'{"detail":"nope"}'),
        )

    monkeypatch.setattr(f"{UPLOAD_MODULE}.urlopen", fake_urlopen)

    result = _make_uploader(db, config).upload(report_file, plugin_name="X", trade_date="20260601")
    assert result.status == "failed"
    assert result.http_status == 403
    assert result.error_class == "HTTPError"
    assert result.error and "403" in result.error

    rows = _audit_rows(db)
    assert rows[-1]["status"] == "failed"
    assert rows[-1]["http_status"] == 403


def test_url_error_yields_failed_result(
    db: Database, config: ConfigService, report_file: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    config.set("report.upload.enabled", True)

    def fake_urlopen(req: Any, timeout: float = 0.0) -> Any:
        raise URLError("DNS failure")

    monkeypatch.setattr(f"{UPLOAD_MODULE}.urlopen", fake_urlopen)
    result = _make_uploader(db, config).upload(report_file, plugin_name="X", trade_date="20260601")
    assert result.status == "failed"
    assert result.error_class == "URLError"
    assert result.http_status is None


def test_timeout_yields_failed_result(
    db: Database, config: ConfigService, report_file: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    config.set("report.upload.enabled", True)

    def fake_urlopen(req: Any, timeout: float = 0.0) -> Any:
        raise TimeoutError("slow upstream")

    monkeypatch.setattr(f"{UPLOAD_MODULE}.urlopen", fake_urlopen)
    result = _make_uploader(db, config).upload(report_file, plugin_name="X", trade_date="20260601")
    assert result.status == "failed"
    assert result.error_class == "TimeoutError"


def test_non_200_status_yields_failed_result(
    db: Database, config: ConfigService, report_file: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    config.set("report.upload.enabled", True)
    monkeypatch.setattr(
        f"{UPLOAD_MODULE}.urlopen",
        lambda *a, **kw: _FakeResponse(b'{"ok":false}', status=502),
    )
    result = _make_uploader(db, config).upload(report_file, plugin_name="X", trade_date="20260601")
    assert result.status == "failed"
    assert result.http_status == 502
    assert result.error_class == "UploadError"


def test_non_json_response_yields_failed_result(
    db: Database, config: ConfigService, report_file: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    config.set("report.upload.enabled", True)
    monkeypatch.setattr(
        f"{UPLOAD_MODULE}.urlopen",
        lambda *a, **kw: _FakeResponse(b"<html>nope</html>", status=200),
    )
    result = _make_uploader(db, config).upload(report_file, plugin_name="X", trade_date="20260601")
    assert result.status == "failed"
    assert result.error_class == "JSONDecodeError"


def test_non_dict_json_yields_failed_result(
    db: Database, config: ConfigService, report_file: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    config.set("report.upload.enabled", True)
    monkeypatch.setattr(
        f"{UPLOAD_MODULE}.urlopen",
        lambda *a, **kw: _FakeResponse(b"[1,2,3]", status=200),
    )
    result = _make_uploader(db, config).upload(report_file, plugin_name="X", trade_date="20260601")
    assert result.status == "failed"
    assert result.error_class == "UploadError"


# ---------------------------------------------------------------------------
# D. helpers + types
# ---------------------------------------------------------------------------


def test_build_multipart_preserves_order_and_terminates() -> None:
    body = _build_multipart(
        "B",
        field_name="file",
        filename="a.json",
        content=b"{}",
        mime="application/json",
        text_fields={"k1": "v1", "k2": "v2"},
    )
    assert body.startswith(b"--B\r\n")
    assert b"k1" in body and b"v1" in body
    assert b"k2" in body and b"v2" in body
    assert body.endswith(b"\r\n--B--\r\n")


def test_upload_error_is_public_type() -> None:
    """``UploadError`` is exported so callers that want to raise can build it."""
    err = UploadError("boom")
    assert isinstance(err, Exception)


def test_upload_result_is_immutable() -> None:
    r = UploadResult(status="ok", duration_ms=1.0)
    with pytest.raises(dataclasses.FrozenInstanceError):
        r.status = "failed"  # type: ignore[misc]


# ---------------------------------------------------------------------------
# E. integration — PluginContext factory
# ---------------------------------------------------------------------------


def test_plugin_context_factory_wires_uploader(
    db: Database, config: ConfigService, report_file: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from deeptrade.plugins_api import PluginContext

    config.set("report.upload.enabled", True)
    monkeypatch.setattr(
        f"{UPLOAD_MODULE}.urlopen",
        lambda *a, **kw: _FakeResponse(
            json.dumps({"url": "https://x", "pathname": "p"}).encode(), 200
        ),
    )

    ctx = PluginContext(db=db, config=config, plugin_id="ctx-plugin")
    uploader = ctx.make_report_uploader(run_id="run-xyz")
    result = uploader.upload(report_file, plugin_name="N", trade_date="20260601")
    assert result.status == "ok"

    rows = _audit_rows(db)
    assert rows[-1]["plugin_id"] == "ctx-plugin"
    assert rows[-1]["run_id"] == "run-xyz"
