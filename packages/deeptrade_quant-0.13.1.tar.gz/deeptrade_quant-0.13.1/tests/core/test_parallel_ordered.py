"""v0.12 — tests for ``deeptrade.core.parallel.run_parallel_ordered``.

The helper has TWO ordering contracts that must be kept independently:

* **Result list order** matches the ``providers`` input — this is what
  reports / persistence / peer-input code relies on for reproducibility.
* **on_complete callback order** is the order workers finished — used
  by dashboards for "as-they-arrive" updates.

These tests pin both. They also cover partial failure, timeout, and the
edge cases (empty list, duplicates).
"""

from __future__ import annotations

import threading
import time
from concurrent.futures import TimeoutError as FutureTimeoutError

import pytest

from deeptrade.core.parallel import ProviderWorkResult, run_parallel_ordered

# ---------------------------------------------------------------------------
# Result ordering
# ---------------------------------------------------------------------------


def test_empty_providers_returns_empty_list() -> None:
    called = False

    def _w(_p: str) -> int:
        nonlocal called
        called = True
        return 0

    out = run_parallel_ordered([], _w)
    assert out == []
    assert called is False


def test_results_ordered_by_input_even_when_completion_is_reversed() -> None:
    """Slow-fast-slow-fast pattern: completion order != input order; the
    returned list MUST mirror the input order.
    """
    # Map provider name → sleep seconds before returning.
    delays = {"a": 0.20, "b": 0.05, "c": 0.15, "d": 0.02}

    def _w(p: str) -> str:
        time.sleep(delays[p])
        return p.upper()

    providers = ["a", "b", "c", "d"]
    out = run_parallel_ordered(providers, _w, max_workers=4)
    assert [r.provider for r in out] == providers
    assert [r.result for r in out] == ["A", "B", "C", "D"]
    assert all(r.ok for r in out)
    assert all(r.error is None for r in out)


def test_on_complete_fires_in_completion_order(monkeypatch: pytest.MonkeyPatch) -> None:
    delays = {"slow": 0.20, "medium": 0.10, "fast": 0.02}

    def _w(p: str) -> str:
        time.sleep(delays[p])
        return p

    events: list[str] = []
    lock = threading.Lock()

    def _on_complete(r: ProviderWorkResult[str]) -> None:
        with lock:
            events.append(r.provider)

    providers = ["slow", "medium", "fast"]
    out = run_parallel_ordered(providers, _w, on_complete=_on_complete, max_workers=3)

    # Returned list is in INPUT order.
    assert [r.provider for r in out] == providers
    # Callback was fired in COMPLETION order — fast → medium → slow.
    assert events == ["fast", "medium", "slow"]


def test_on_complete_called_once_per_provider() -> None:
    counts: dict[str, int] = {}
    lock = threading.Lock()

    def _on_complete(r: ProviderWorkResult[int]) -> None:
        with lock:
            counts[r.provider] = counts.get(r.provider, 0) + 1

    out = run_parallel_ordered(["a", "b", "c"], lambda p: len(p), on_complete=_on_complete)
    assert len(out) == 3
    assert counts == {"a": 1, "b": 1, "c": 1}


# ---------------------------------------------------------------------------
# Partial failure
# ---------------------------------------------------------------------------


def test_one_worker_raises_others_complete() -> None:
    def _w(p: str) -> str:
        if p == "boom":
            raise RuntimeError("intentional")
        return p.upper()

    out = run_parallel_ordered(["a", "boom", "c"], _w)
    assert [r.provider for r in out] == ["a", "boom", "c"]
    assert out[0].ok is True and out[0].result == "A"
    assert out[1].ok is False
    assert isinstance(out[1].error, RuntimeError)
    assert str(out[1].error) == "intentional"
    assert out[1].result is None
    assert out[2].ok is True and out[2].result == "C"


def test_on_complete_runs_for_failures_too() -> None:
    seen: list[tuple[str, bool]] = []
    lock = threading.Lock()

    def _w(p: str) -> str:
        if p == "boom":
            raise ValueError("nope")
        return p

    def _on_complete(r: ProviderWorkResult[str]) -> None:
        with lock:
            seen.append((r.provider, r.ok))

    run_parallel_ordered(["a", "boom"], _w, on_complete=_on_complete, max_workers=2)
    by_provider = dict(seen)
    assert by_provider == {"a": True, "boom": False}


def test_on_complete_exception_does_not_kill_batch(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """A buggy callback must not abort processing of remaining results.
    The helper logs the callback error at WARNING; everything else still
    proceeds."""

    def _on_complete(_: ProviderWorkResult[int]) -> None:
        raise RuntimeError("buggy callback")

    with caplog.at_level("WARNING"):
        out = run_parallel_ordered(["a", "b", "c"], lambda p: len(p), on_complete=_on_complete)

    assert all(r.ok for r in out)
    assert [r.provider for r in out] == ["a", "b", "c"]
    # WARN was emitted 3 times — one per provider.
    warnings = [rec for rec in caplog.records if "on_complete raised" in rec.message]
    assert len(warnings) == 3


# ---------------------------------------------------------------------------
# Timeout behaviour
# ---------------------------------------------------------------------------


def test_timeout_marks_unfinished_workers() -> None:
    def _w(p: str) -> str:
        if p == "fast":
            return "FAST"
        time.sleep(5.0)  # way past the timeout
        return "SHOULD-NOT-RETURN"

    out = run_parallel_ordered(["fast", "slow"], _w, max_workers=2, timeout=0.25)
    assert [r.provider for r in out] == ["fast", "slow"]
    assert out[0].ok is True and out[0].result == "FAST"
    assert out[1].ok is False
    assert isinstance(out[1].error, FutureTimeoutError)


def test_timeout_zero_workers_finished_all_marked_timeout() -> None:
    def _w(_p: str) -> str:
        time.sleep(2.0)
        return "DONE"

    out = run_parallel_ordered(["a", "b"], _w, max_workers=2, timeout=0.10)
    assert all(not r.ok for r in out)
    assert all(isinstance(r.error, FutureTimeoutError) for r in out)
    # provider names still align with input order
    assert [r.provider for r in out] == ["a", "b"]


def test_no_timeout_waits_for_slow_workers() -> None:
    def _w(p: str) -> str:
        if p == "slow":
            time.sleep(0.30)
        return p.upper()

    t0 = time.monotonic()
    out = run_parallel_ordered(["slow", "fast"], _w, max_workers=2)
    elapsed = time.monotonic() - t0
    # Should be roughly the slow worker's wait, not aborted.
    assert elapsed >= 0.25
    assert out[0].ok and out[1].ok


# ---------------------------------------------------------------------------
# elapsed_ms is populated and roughly monotonic per completion order
# ---------------------------------------------------------------------------


def test_elapsed_ms_is_nonnegative_and_increasing_with_delay() -> None:
    delays = {"a": 0.02, "b": 0.20}

    def _w(p: str) -> str:
        time.sleep(delays[p])
        return p

    out = run_parallel_ordered(["a", "b"], _w, max_workers=2)
    by_provider = {r.provider: r.elapsed_ms for r in out}
    assert by_provider["a"] >= 0
    assert by_provider["b"] >= by_provider["a"]


# ---------------------------------------------------------------------------
# Duplicates / parametric inputs
# ---------------------------------------------------------------------------


def test_duplicate_providers_each_dispatched_once() -> None:
    call_log: list[str] = []
    lock = threading.Lock()

    def _w(p: str) -> str:
        with lock:
            call_log.append(p)
        return p.upper()

    out = run_parallel_ordered(["x", "x", "y"], _w)
    assert [r.provider for r in out] == ["x", "x", "y"]
    assert [r.result for r in out] == ["X", "X", "Y"]
    # Each input position triggered exactly one worker call.
    assert sorted(call_log) == ["x", "x", "y"]


def test_single_provider() -> None:
    out = run_parallel_ordered(["only"], lambda p: f"hi {p}")
    assert len(out) == 1
    assert out[0].provider == "only"
    assert out[0].ok is True
    assert out[0].result == "hi only"


# ---------------------------------------------------------------------------
# Determinism across runs
# ---------------------------------------------------------------------------


def test_result_order_deterministic_across_repeated_runs() -> None:
    """Even when completion is shuffled by sleep jitter, the result order
    is locked to input order."""
    providers = ["p1", "p2", "p3", "p4", "p5"]

    def _w(p: str) -> str:
        # Pseudo-jitter: deterministic by name, but varied.
        time.sleep(0.03 if p in {"p1", "p3"} else 0.01)
        return p

    for _ in range(3):
        out = run_parallel_ordered(providers, _w, max_workers=5)
        assert [r.provider for r in out] == providers
        assert all(r.ok for r in out)
