"""v0.12 — llm.replay.* config keys + policy_from_app_config helper.

Pins:

* Defaults: ``enabled=True``, ``write=True``, ``ttl_days=None``.
* env > app_config > default precedence (same contract every other
  config key follows).
* String coercion from env vars: ``true / false / yes / no / 1 / 0``
  for booleans; ``"" / null / none`` → ``None`` and integer literal
  otherwise for ``ttl_days``.
* ``policy_from_app_config`` translates the keys into an
  :class:`LLMReplayPolicy` with the documented "write requires read"
  rule (``write_enabled=False`` whenever ``enabled=False``).
"""

from __future__ import annotations

from pathlib import Path

import pytest
from pydantic import ValidationError

from deeptrade.core.config import AppConfig, ConfigService
from deeptrade.core.db import Database
from deeptrade.plugins_api import LLMReplayPolicy, policy_from_app_config

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def db(tmp_path: Path) -> Database:
    return Database(tmp_path / "config.duckdb")


@pytest.fixture
def svc(db: Database, monkeypatch: pytest.MonkeyPatch) -> ConfigService:
    # Strip any inherited env vars so tests see the documented defaults.
    for k in (
        "DEEPTRADE_LLM_REPLAY_ENABLED",
        "DEEPTRADE_LLM_REPLAY_WRITE",
        "DEEPTRADE_LLM_REPLAY_TTL_DAYS",
    ):
        monkeypatch.delenv(k, raising=False)
    return ConfigService(db)


# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------


def test_defaults(svc: ConfigService) -> None:
    cfg = svc.get_app_config()
    assert cfg.llm_replay_enabled is True
    assert cfg.llm_replay_write is True
    assert cfg.llm_replay_ttl_days is None


def test_get_returns_defaults(svc: ConfigService) -> None:
    assert svc.get("llm.replay.enabled") is True
    assert svc.get("llm.replay.write") is True
    assert svc.get("llm.replay.ttl_days") is None


# ---------------------------------------------------------------------------
# app_config (write via .set)
# ---------------------------------------------------------------------------


def test_set_persists_and_overrides_default(svc: ConfigService) -> None:
    svc.set("llm.replay.enabled", False)
    cfg = svc.get_app_config()
    assert cfg.llm_replay_enabled is False
    # Other keys untouched.
    assert cfg.llm_replay_write is True
    assert cfg.llm_replay_ttl_days is None


def test_set_ttl_days(svc: ConfigService) -> None:
    svc.set("llm.replay.ttl_days", 30)
    cfg = svc.get_app_config()
    assert cfg.llm_replay_ttl_days == 30


def test_set_ttl_days_rejects_negative(svc: ConfigService) -> None:
    with pytest.raises(ValidationError):
        svc.set("llm.replay.ttl_days", -1)


def test_source_of_reports_app_config_after_set(svc: ConfigService) -> None:
    svc.set("llm.replay.enabled", False)
    assert svc.source_of("llm.replay.enabled") == "app_config"


def test_source_of_default_when_unset(svc: ConfigService) -> None:
    assert svc.source_of("llm.replay.enabled") == "default"


# ---------------------------------------------------------------------------
# env var coercion
# ---------------------------------------------------------------------------


def test_env_overrides_app_config(svc: ConfigService, monkeypatch: pytest.MonkeyPatch) -> None:
    svc.set("llm.replay.enabled", True)
    monkeypatch.setenv("DEEPTRADE_LLM_REPLAY_ENABLED", "false")
    cfg = svc.get_app_config()
    assert cfg.llm_replay_enabled is False
    assert svc.source_of("llm.replay.enabled") == "env"


@pytest.mark.parametrize(
    "raw,expected",
    [
        ("1", True),
        ("true", True),
        ("TRUE", True),
        ("yes", True),
        ("on", True),
        ("0", False),
        ("false", False),
        ("False", False),
        ("no", False),
        ("off", False),
        ("", False),
    ],
)
def test_env_bool_coercion(
    svc: ConfigService, monkeypatch: pytest.MonkeyPatch, raw: str, expected: bool
) -> None:
    monkeypatch.setenv("DEEPTRADE_LLM_REPLAY_ENABLED", raw)
    cfg = svc.get_app_config()
    assert cfg.llm_replay_enabled is expected


def test_env_ttl_days_integer(svc: ConfigService, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DEEPTRADE_LLM_REPLAY_TTL_DAYS", "42")
    cfg = svc.get_app_config()
    assert cfg.llm_replay_ttl_days == 42


@pytest.mark.parametrize("raw", ["", "none", "NULL", "None"])
def test_env_ttl_days_null_aliases(
    svc: ConfigService, monkeypatch: pytest.MonkeyPatch, raw: str
) -> None:
    # Pre-seed a non-null DB value to make the override observable.
    svc.set("llm.replay.ttl_days", 10)
    monkeypatch.setenv("DEEPTRADE_LLM_REPLAY_TTL_DAYS", raw)
    cfg = svc.get_app_config()
    assert cfg.llm_replay_ttl_days is None


def test_env_ttl_days_garbage_raises(svc: ConfigService, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DEEPTRADE_LLM_REPLAY_TTL_DAYS", "abc")
    with pytest.raises(ValueError):
        svc.get_app_config()


# ---------------------------------------------------------------------------
# known_keys / list_all surface the new keys
# ---------------------------------------------------------------------------


def test_known_keys_includes_replay_keys() -> None:
    from deeptrade.core.config import known_keys

    keys = known_keys()
    assert "llm.replay.enabled" in keys
    assert "llm.replay.write" in keys
    assert "llm.replay.ttl_days" in keys


def test_list_all_includes_replay_keys(svc: ConfigService) -> None:
    rows = {k: (v, src) for (k, v, src) in svc.list_all()}
    assert rows["llm.replay.enabled"] == (True, "default")
    assert rows["llm.replay.write"] == (True, "default")
    assert rows["llm.replay.ttl_days"] == (None, "default")


# ---------------------------------------------------------------------------
# policy_from_app_config
# ---------------------------------------------------------------------------


def test_policy_from_app_config_default() -> None:
    p = policy_from_app_config(AppConfig())
    assert p == LLMReplayPolicy(read_enabled=True, write_enabled=True, ttl_days=None)


def test_policy_from_app_config_disabled() -> None:
    """When enabled=False, write_enabled also forces to False even if
    write=True in config — disabling reads also disables writes (no point
    writing to a cache nobody will read from)."""
    p = policy_from_app_config(AppConfig(llm_replay_enabled=False))
    assert p.read_enabled is False
    assert p.write_enabled is False


def test_policy_from_app_config_read_only() -> None:
    """``write=False`` while ``enabled=True`` → reads-only mode (consumer
    of another instance's cache, e.g. CI replay)."""
    p = policy_from_app_config(AppConfig(llm_replay_write=False))
    assert p.read_enabled is True
    assert p.write_enabled is False


def test_policy_from_app_config_ttl_passes_through() -> None:
    p = policy_from_app_config(AppConfig(llm_replay_ttl_days=90))
    assert p.ttl_days == 90


def test_policy_from_app_config_replay_only_not_encoded() -> None:
    """``replay_only`` is intentionally NOT a config key — it's an
    invocation-level choice (CI, offline reproduction). The helper
    must always leave it False so callers don't accidentally enable
    fail-fast globally via app_config."""
    p = policy_from_app_config(AppConfig())
    assert p.replay_only is False
