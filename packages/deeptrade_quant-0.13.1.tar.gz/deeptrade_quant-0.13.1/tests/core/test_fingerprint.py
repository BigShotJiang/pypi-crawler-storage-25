"""Tests for ``deeptrade.core.fingerprint``.

These tests freeze the canonical encoding rules. If any test here fails
after a code change in ``fingerprint.py``, that almost always means the
LLM replay cache's ``FRAMEWORK_LLM_CACHE_VERSION`` must be bumped too —
historical cache entries cannot be interpreted by the new rules.
"""

from __future__ import annotations

import json
import subprocess
import sys
from datetime import UTC, date, datetime
from decimal import Decimal
from pathlib import Path

import pandas as pd
import pytest
from pydantic import BaseModel

from deeptrade.core.fingerprint import (
    canonical_json,
    hash_dataframe,
    hash_file,
    hash_json,
    hash_text,
)

# ---------------------------------------------------------------------------
# canonical_json — primitive / container behavior
# ---------------------------------------------------------------------------


def test_canonical_json_sorts_keys_recursively() -> None:
    obj1 = {"b": 1, "a": {"y": 2, "x": [3, {"d": 4, "c": 5}]}}
    obj2 = {"a": {"x": [3, {"c": 5, "d": 4}], "y": 2}, "b": 1}
    assert canonical_json(obj1) == canonical_json(obj2)
    # Re-encoding the result yields the same string (idempotent).
    assert canonical_json(json.loads(canonical_json(obj1))) == canonical_json(obj1)


def test_canonical_json_uses_tight_separators_no_whitespace() -> None:
    s = canonical_json({"a": 1, "b": [2, 3]})
    assert s == '{"a":1,"b":[2,3]}'


def test_canonical_json_preserves_unicode_without_escape() -> None:
    # ensure_ascii=False — Chinese characters must NOT be escaped.
    assert canonical_json({"msg": "限价单"}) == '{"msg":"限价单"}'


def test_canonical_json_rejects_nan_and_inf() -> None:
    with pytest.raises(ValueError, match="NaN/Inf"):
        canonical_json({"x": float("nan")})
    with pytest.raises(ValueError, match="NaN/Inf"):
        canonical_json([float("inf")])


def test_canonical_json_rejects_set_and_generator() -> None:
    with pytest.raises(TypeError, match="set/frozenset"):
        canonical_json({1, 2, 3})
    with pytest.raises(TypeError, match="generators"):
        canonical_json(x for x in range(3))


def test_canonical_json_rejects_dict_view_types() -> None:
    d = {"a": 1, "b": 2}
    with pytest.raises(TypeError, match="dict_keys"):
        canonical_json(d.keys())
    with pytest.raises(TypeError, match="dict_values"):
        canonical_json(d.values())


def test_canonical_json_rejects_non_string_keys() -> None:
    with pytest.raises(TypeError, match="dict keys must be str"):
        canonical_json({1: "one"})


def test_canonical_json_decimal_keeps_literal_form() -> None:
    # 1.10 != 1.1 — the literal trailing zero is part of the canonical form.
    assert canonical_json({"price": Decimal("1.10")}) == '{"price":"1.10"}'
    assert canonical_json({"price": Decimal("1.1")}) == '{"price":"1.1"}'


def test_canonical_json_bytes_base64() -> None:
    assert canonical_json({"blob": b"\x00\xff"}) == '{"blob":"AP8="}'


def test_canonical_json_tuple_treated_as_list() -> None:
    assert canonical_json((1, 2, 3)) == "[1,2,3]"


# ---------------------------------------------------------------------------
# canonical_json — datetime / date
# ---------------------------------------------------------------------------


def test_canonical_json_naive_datetime_iso_no_z() -> None:
    out = canonical_json({"ts": datetime(2026, 5, 24, 12, 30, 45)})
    assert out == '{"ts":"2026-05-24T12:30:45"}'


def test_canonical_json_aware_datetime_keeps_offset() -> None:
    out = canonical_json({"ts": datetime(2026, 5, 24, 12, 0, 0, tzinfo=UTC)})
    assert out == '{"ts":"2026-05-24T12:00:00+00:00"}'


def test_canonical_json_date_iso() -> None:
    assert canonical_json({"d": date(2026, 5, 24)}) == '{"d":"2026-05-24"}'


# ---------------------------------------------------------------------------
# canonical_json — pydantic / numpy / pandas
# ---------------------------------------------------------------------------


class _SampleModel(BaseModel):
    name: str
    score: float
    when: datetime


def test_canonical_json_pydantic_model_recurses_via_model_dump() -> None:
    m = _SampleModel(name="abc", score=0.5, when=datetime(2026, 5, 24, 0, 0, 0))
    # Same content via plain dict must hash to the same string.
    plain = {"name": "abc", "score": 0.5, "when": datetime(2026, 5, 24, 0, 0, 0)}
    assert canonical_json(m) == canonical_json(plain)


def test_canonical_json_numpy_scalars() -> None:
    np = pytest.importorskip("numpy")
    obj = {"a": np.int64(7), "b": np.float64(0.25), "c": np.bool_(True)}
    out = canonical_json(obj)
    # Compare against the plain-Python equivalent — types collapse via .item().
    assert out == canonical_json({"a": 7, "b": 0.25, "c": True})


def test_canonical_json_numpy_nan_rejected() -> None:
    np = pytest.importorskip("numpy")
    with pytest.raises(ValueError, match="NaN/Inf"):
        canonical_json({"x": float(np.nan)})


def test_canonical_json_pandas_timestamp() -> None:
    ts = pd.Timestamp("2026-05-24T12:00:00")
    out = canonical_json({"t": ts})
    # pandas Timestamp.isoformat() format — assert exact equality.
    assert out == '{"t":"2026-05-24T12:00:00"}'


def test_canonical_json_pandas_nat_rejected() -> None:
    with pytest.raises(ValueError, match="NaT"):
        canonical_json({"t": pd.NaT})


# ---------------------------------------------------------------------------
# hash_json / hash_text
# ---------------------------------------------------------------------------


def test_hash_json_is_sha256_of_canonical_json() -> None:
    import hashlib

    obj = {"a": 1, "b": [2, 3]}
    expected = hashlib.sha256(canonical_json(obj).encode("utf-8")).hexdigest()
    assert hash_json(obj) == expected


def test_hash_text_simple() -> None:
    import hashlib

    assert hash_text("hello") == hashlib.sha256(b"hello").hexdigest()


# ---------------------------------------------------------------------------
# hash_dataframe
# ---------------------------------------------------------------------------


def test_hash_dataframe_requires_sort_by() -> None:
    df = pd.DataFrame({"a": [1, 2], "b": [3, 4]})
    with pytest.raises(ValueError, match="sort_by is required"):
        hash_dataframe(df, sort_by=[])


def test_hash_dataframe_missing_sort_by_column() -> None:
    df = pd.DataFrame({"a": [1, 2], "b": [3, 4]})
    with pytest.raises(KeyError, match="sort_by columns not in DataFrame"):
        hash_dataframe(df, sort_by=["c"])


def test_hash_dataframe_row_order_independent() -> None:
    df1 = pd.DataFrame({"ts_code": ["B", "A", "C"], "v": [2, 1, 3]})
    df2 = pd.DataFrame({"ts_code": ["A", "B", "C"], "v": [1, 2, 3]})
    df3 = pd.DataFrame({"ts_code": ["C", "B", "A"], "v": [3, 2, 1]})
    h1 = hash_dataframe(df1, sort_by=["ts_code"])
    h2 = hash_dataframe(df2, sort_by=["ts_code"])
    h3 = hash_dataframe(df3, sort_by=["ts_code"])
    assert h1 == h2 == h3


def test_hash_dataframe_changes_with_value() -> None:
    df1 = pd.DataFrame({"ts_code": ["A", "B"], "v": [1, 2]})
    df2 = pd.DataFrame({"ts_code": ["A", "B"], "v": [1, 99]})
    assert hash_dataframe(df1, sort_by=["ts_code"]) != hash_dataframe(df2, sort_by=["ts_code"])


def test_hash_dataframe_projects_columns() -> None:
    df = pd.DataFrame({"ts_code": ["A", "B"], "v": [1, 2], "noise": [9, 8]})
    h_with_noise = hash_dataframe(df, sort_by=["ts_code"])
    h_without_noise = hash_dataframe(df, sort_by=["ts_code"], columns=["ts_code", "v"])
    assert h_with_noise != h_without_noise


def test_hash_dataframe_handles_timestamps_and_decimals() -> None:
    df = pd.DataFrame(
        {
            "ts_code": ["A", "B"],
            "when": [pd.Timestamp("2026-05-24"), pd.Timestamp("2026-05-25")],
            "px": [Decimal("1.10"), Decimal("2.50")],
        }
    )
    h = hash_dataframe(df, sort_by=["ts_code"])
    # Same df hashed twice on this process must match.
    assert h == hash_dataframe(df, sort_by=["ts_code"])


# ---------------------------------------------------------------------------
# hash_file
# ---------------------------------------------------------------------------


def test_hash_file_small(tmp_path: Path) -> None:
    import hashlib

    p = tmp_path / "a.bin"
    p.write_bytes(b"deeptrade")
    assert hash_file(p) == hashlib.sha256(b"deeptrade").hexdigest()


def test_hash_file_chunked_matches_whole(tmp_path: Path) -> None:
    import hashlib

    # > one chunk to exercise the streaming loop
    blob = b"x" * (3 * 1024 * 1024 + 17)
    p = tmp_path / "big.bin"
    p.write_bytes(blob)
    assert hash_file(p, chunk_size=64 * 1024) == hashlib.sha256(blob).hexdigest()


def test_hash_file_missing_raises(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError):
        hash_file(tmp_path / "nope.bin")


# ---------------------------------------------------------------------------
# Cross-process stability
# ---------------------------------------------------------------------------


def test_hash_json_stable_across_subprocess(tmp_path: Path) -> None:
    """A fresh Python interpreter must produce the same hash as this one.

    Guards against PYTHONHASHSEED / dict-ordering / locale leakage in the
    canonical encoding.
    """
    script = tmp_path / "child.py"
    script.write_text(
        "from deeptrade.core.fingerprint import hash_json\n"
        "import sys\n"
        'sys.stdout.write(hash_json({"b":1,"a":[2,3],"c":"限价"}))\n',
        encoding="utf-8",
    )
    parent = hash_json({"b": 1, "a": [2, 3], "c": "限价"})
    proc = subprocess.run(
        [sys.executable, str(script)],
        capture_output=True,
        text=True,
        check=True,
    )
    assert proc.stdout.strip() == parent
