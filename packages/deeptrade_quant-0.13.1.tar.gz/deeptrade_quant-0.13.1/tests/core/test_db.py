"""Core schema invariants — framework-only tables (Plan A pure isolation).

The framework owns ONLY:
    app_config, secret_store, schema_migrations,
    plugins, plugin_tables, plugin_schema_migrations,
    llm_calls, llm_replay_cache (v0.12),
    run_metadata (v0.12), run_artifacts (v0.12),
    tushare_sync_state, tushare_calls, report_uploads

All business / strategy data is plugin-owned.
"""

from __future__ import annotations

from pathlib import Path

import pytest
from typer.testing import CliRunner

from deeptrade.cli import app
from deeptrade.core.db import Database, apply_core_migrations


@pytest.fixture
def fresh_db(tmp_path: Path) -> Database:
    # auto_migrate=False keeps the "fresh" semantics tests depend on: each
    # test exercises apply_core_migrations explicitly to assert what it does.
    return Database(tmp_path / "test.duckdb", auto_migrate=False)


# --- init creates DB + dirs ----------------------------------------------


def test_init_creates_db_file_and_dirs(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setenv("DEEPTRADE_HOME", str(tmp_path))
    runner = CliRunner()
    result = runner.invoke(app, ["init", "--no-prompts"])
    assert result.exit_code == 0, result.stdout
    assert (tmp_path / "deeptrade.duckdb").is_file()
    assert (tmp_path / "logs").is_dir()


def test_init_is_idempotent(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setenv("DEEPTRADE_HOME", str(tmp_path))
    runner = CliRunner()
    runner.invoke(app, ["init", "--no-prompts"])
    result = runner.invoke(app, ["init", "--no-prompts"])
    assert result.exit_code == 0


# --- migrations record version --------------------------------------------


def test_apply_core_migrations_records_version(fresh_db: Database) -> None:
    """Framework owns no business tables."""
    applied = apply_core_migrations(fresh_db)
    assert applied == [
        "20260509_001",
        "20260512_001",
        "20260515_002",
        "20260524_001",
        "20260525_001",
        "20260525_002",
        "20260525_003",
        "20260601_001",
    ]
    rows = fresh_db.fetchall("SELECT version FROM schema_migrations ORDER BY version")
    assert tuple(rows) == (
        ("20260509_001",),
        ("20260512_001",),
        ("20260515_002",),
        ("20260524_001",),
        ("20260525_001",),
        ("20260525_002",),
        ("20260525_003",),
        ("20260601_001",),
    )


def test_apply_core_migrations_skips_applied_versions(fresh_db: Database) -> None:
    apply_core_migrations(fresh_db)
    second = apply_core_migrations(fresh_db)
    assert second == []


# --- framework tables exist; business tables do NOT -----------------------


def test_framework_owns_only_minimal_table_set(fresh_db: Database) -> None:
    apply_core_migrations(fresh_db)
    tables = {
        r[0]
        for r in fresh_db.fetchall(
            "SELECT table_name FROM information_schema.tables WHERE table_schema='main'"
        )
    }
    expected = {
        "app_config",
        "secret_store",
        "schema_migrations",
        "plugins",
        "plugin_tables",
        "plugin_schema_migrations",
        "llm_calls",
        "llm_replay_cache",
        "run_metadata",
        "run_artifacts",
        "tushare_sync_state",
        "tushare_calls",
        "report_uploads",
    }
    assert tables == expected, f"unexpected drift: {tables - expected} missing: {expected - tables}"


# --- tushare_sync_state has plugin_id in PK (Plan A pure isolation) -------


def test_tushare_sync_state_has_plugin_id_column_and_pk(fresh_db: Database) -> None:
    apply_core_migrations(fresh_db)
    cols = [
        r[0]
        for r in fresh_db.fetchall(
            "SELECT column_name FROM information_schema.columns "
            "WHERE table_name='tushare_sync_state' ORDER BY ordinal_position"
        )
    ]
    # plugin_id is the first PK column
    assert cols[0] == "plugin_id"
    assert "data_completeness" in cols


def test_tushare_sync_state_default_data_completeness(fresh_db: Database) -> None:
    apply_core_migrations(fresh_db)
    fresh_db.execute(
        "INSERT INTO tushare_sync_state(plugin_id, api_name, trade_date, status) "
        "VALUES (?, ?, ?, ?)",
        ("test-plugin", "stock_basic", "*", "ok"),
    )
    row = fresh_db.fetchone(
        "SELECT data_completeness FROM tushare_sync_state WHERE api_name='stock_basic'"
    )
    assert row is not None and row[0] == "final"


def test_tushare_calls_has_plugin_id_column(fresh_db: Database) -> None:
    apply_core_migrations(fresh_db)
    cols = {
        r[0]
        for r in fresh_db.fetchall(
            "SELECT column_name FROM information_schema.columns WHERE table_name='tushare_calls'"
        )
    }
    assert "plugin_id" in cols


# --- Database.__init__ auto-migrate (v0.4.2) -----------------------------


def test_database_init_runs_pending_migrations(tmp_path: Path) -> None:
    """A fresh Database() with default auto_migrate=True applies every core
    migration on first open — no separate `db upgrade` call needed."""
    db = Database(tmp_path / "auto.duckdb")
    try:
        rows = db.fetchall("SELECT version FROM schema_migrations ORDER BY version")
        assert tuple(rows) == (
            ("20260509_001",),
            ("20260512_001",),
            ("20260515_002",),
            ("20260524_001",),
            ("20260525_001",),
            ("20260525_002",),
            ("20260525_003",),
            ("20260601_001",),
        )
    finally:
        db.close()


def test_database_init_auto_migrate_false_skips(tmp_path: Path) -> None:
    """auto_migrate=False is the documented opt-out for the CLI's
    `db init` / `db upgrade` commands that want to collect the applied
    list themselves."""
    db = Database(tmp_path / "manual.duckdb", auto_migrate=False)
    try:
        rows = db.fetchall(
            "SELECT table_name FROM information_schema.tables "
            "WHERE table_schema='main' AND table_name='schema_migrations'"
        )
        assert rows == []
    finally:
        db.close()


def test_database_init_env_var_skips_auto_migrate(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """DEEPTRADE_SKIP_AUTO_MIGRATE=1 is the recovery escape hatch."""
    monkeypatch.setenv("DEEPTRADE_SKIP_AUTO_MIGRATE", "1")
    db = Database(tmp_path / "skip.duckdb")
    try:
        rows = db.fetchall(
            "SELECT table_name FROM information_schema.tables "
            "WHERE table_schema='main' AND table_name='schema_migrations'"
        )
        assert rows == []
    finally:
        db.close()


def test_database_init_migration_failure_propagates(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """A failing migration must bubble out of Database() as a hard error so
    callers can't proceed against a half-migrated schema."""
    from deeptrade.core import db as db_module

    boom = RuntimeError("synthetic migration failure")

    def _failing(_db: Database) -> list[str]:
        raise boom

    monkeypatch.setattr(db_module, "apply_core_migrations", _failing)

    with pytest.raises(RuntimeError, match="synthetic migration failure"):
        Database(tmp_path / "broken.duckdb")


def test_apply_core_migrations_on_populated_llm_calls(tmp_path: Path) -> None:
    """Regression: ``20260525_002`` (11 ALTER TABLE ADD COLUMN on llm_calls)
    must succeed when run against an existing populated llm_calls table.

    DuckDB 1.5.x raises ``Failed to commit: Attempting to modify table X
    but another transaction has altered this table`` if a single transaction
    issues many ALTER TABLE ADD COLUMN statements on a populated table.
    apply_core_migrations runs each statement auto-committed to avoid this.
    """
    from deeptrade.core.db import _list_core_migrations, _split_sql_statements

    db_file = tmp_path / "populated.duckdb"
    db = Database(db_file, auto_migrate=False)
    try:
        # Apply only the pre-v0.12 migrations, then populate llm_calls so the
        # subsequent ADD COLUMN batch sees a non-empty table — the exact
        # condition that triggers the DuckDB commit failure.
        early = {
            "20260509_001",
            "20260512_001",
            "20260515_002",
            "20260524_001",
            "20260525_001",
        }
        for version, sql_text in _list_core_migrations():
            if version not in early:
                continue
            for stmt in _split_sql_statements(sql_text):
                db.execute(stmt)
            db.execute(
                "INSERT INTO schema_migrations(version) VALUES (?)",
                (version,),
            )
        import uuid

        for _ in range(50):
            db.execute(
                "INSERT INTO llm_calls(call_id, plugin_id, model, "
                "prompt_hash, validation_status) VALUES (?, ?, ?, ?, ?)",
                (str(uuid.uuid4()), "test-plugin", "gpt-4", "h" * 64, "ok"),
            )
    finally:
        db.close()

    db = Database(db_file)
    try:
        applied = {r[0] for r in db.fetchall("SELECT version FROM schema_migrations")}
        assert "20260525_002" in applied
        assert "20260525_003" in applied
        cols = {
            r[0]
            for r in db.fetchall(
                "SELECT column_name FROM information_schema.columns WHERE table_name='llm_calls'"
            )
        }
        for new_col in (
            "cache_hit",
            "cache_key",
            "source_run_id",
            "source_call_id",
            "stage",
            "schema_version",
            "input_fingerprint",
            "attempt_count",
            "final_prompt_hash",
            "repair_hint_hash",
            "first_error_class",
        ):
            assert new_col in cols, f"missing column added by 20260525_002: {new_col}"
        row = db.fetchone("SELECT COUNT(*) FROM llm_calls")
        assert row is not None and row[0] == 50
    finally:
        db.close()


def test_apply_core_migrations_idempotent_on_partial_add_column(tmp_path: Path) -> None:
    """If a migration was partially applied (some ALTER ADD COLUMN succeeded)
    but the version was never recorded, re-running must complete without
    raising — ``column already exists`` is treated as a no-op so the rest of
    the migration can finish.
    """
    from deeptrade.core.db import _list_core_migrations, _split_sql_statements

    db_file = tmp_path / "partial.duckdb"
    db = Database(db_file, auto_migrate=False)
    try:
        early = {
            "20260509_001",
            "20260512_001",
            "20260515_002",
            "20260524_001",
            "20260525_001",
        }
        for version, sql_text in _list_core_migrations():
            if version not in early:
                continue
            for stmt in _split_sql_statements(sql_text):
                db.execute(stmt)
            db.execute(
                "INSERT INTO schema_migrations(version) VALUES (?)",
                (version,),
            )
        # Manually pre-add two of the columns from 20260525_002 — simulates
        # a previous run that crashed mid-migration before recording.
        db.execute("ALTER TABLE llm_calls ADD COLUMN cache_hit BOOLEAN DEFAULT FALSE")
        db.execute("ALTER TABLE llm_calls ADD COLUMN cache_key VARCHAR")
    finally:
        db.close()

    db = Database(db_file)
    try:
        applied = {r[0] for r in db.fetchall("SELECT version FROM schema_migrations")}
        assert "20260525_002" in applied
        cols = {
            r[0]
            for r in db.fetchall(
                "SELECT column_name FROM information_schema.columns WHERE table_name='llm_calls'"
            )
        }
        assert "first_error_class" in cols
    finally:
        db.close()


def test_legacy_tushare_cache_wiped_on_first_open(tmp_path: Path) -> None:
    """v0.4.1 introduced a wrapped tushare cache payload format and a
    migration that drops the legacy table. Auto-migrate must apply that
    migration on first open so a pre-0.4.1 DB doesn't poison the v0.4.1+
    reader. Regression-locks the TypeError reported against
    `deeptrade limit-up-board lgb train`.
    """
    db_file = tmp_path / "legacy.duckdb"

    # Stage 1: simulate a pre-0.4.1 DB — only the very first migration is on
    # record, and the legacy cache table has a bare-array payload row.
    db = Database(db_file, auto_migrate=False)
    try:
        # Apply only the v0.4.0 migration (init schema) by name; intentionally
        # leave the v0.4.1 drop migration unrecorded.
        from deeptrade.core.db import _list_core_migrations

        for version, sql_text in _list_core_migrations():
            if version != "20260509_001":
                continue
            with db.transaction():
                db.execute(sql_text)
                db.execute(
                    "INSERT INTO schema_migrations(version) VALUES (?)",
                    (version,),
                )
        db.execute(
            "CREATE TABLE tushare_cache_blob ("
            "  plugin_id VARCHAR NOT NULL,"
            "  api_name VARCHAR NOT NULL,"
            "  trade_date VARCHAR NOT NULL,"
            "  params_hash VARCHAR NOT NULL,"
            "  payload_json VARCHAR NOT NULL,"
            "  cached_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
            "  PRIMARY KEY (plugin_id, api_name, trade_date, params_hash)"
            ")"
        )
        db.execute(
            "INSERT INTO tushare_cache_blob(plugin_id, api_name, trade_date, "
            "params_hash, payload_json) VALUES (?, ?, ?, ?, ?)",
            ("legacy-plugin", "trade_cal", "*", "0" * 64, '[{"cal_date":"20260101"}]'),
        )
    finally:
        db.close()

    # Stage 2: re-open with auto_migrate=True → the drop migration must run
    # and the legacy table must be gone.
    db = Database(db_file)
    try:
        rows = db.fetchall(
            "SELECT table_name FROM information_schema.tables "
            "WHERE table_schema='main' AND table_name='tushare_cache_blob'"
        )
        assert rows == [], "legacy tushare_cache_blob should be dropped by auto-migrate"
        applied = {r[0] for r in db.fetchall("SELECT version FROM schema_migrations")}
        assert "20260512_001" in applied
    finally:
        db.close()
