"""Tests for ``deeptrade.core.llm_replay`` — policy, store, and env policy.

The cache_key recipe is part of the framework contract; the tests here
freeze the rules. Any failure after editing ``llm_replay.py`` strongly
suggests ``FRAMEWORK_LLM_CACHE_VERSION`` needs to bump.
"""

from __future__ import annotations

import time
from datetime import datetime, timedelta
from pathlib import Path

import pytest
from pydantic import ValidationError

from deeptrade.core.db import Database
from deeptrade.core.fingerprint import hash_text
from deeptrade.core.llm_replay import (
    FRAMEWORK_LLM_CACHE_VERSION,
    CacheEntry,
    LLMReplayMiss,
    LLMReplayPolicy,
    ReplayCacheStore,
)
from deeptrade.plugins_api import policy_from_env
from deeptrade.plugins_api.llm import StageProfile

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def db(tmp_path: Path) -> Database:
    return Database(tmp_path / "replay.duckdb")


@pytest.fixture
def store(db: Database) -> ReplayCacheStore:
    return ReplayCacheStore(db)


@pytest.fixture
def base_profile() -> StageProfile:
    return StageProfile(
        thinking=False,
        reasoning_effort="low",
        temperature=0.2,
        max_output_tokens=2048,
    )


def _make_kwargs(
    *,
    profile: StageProfile,
    plugin_id: str = "test_plugin",
    stage: str = "screening",
    provider: str = "deepseek",
    model: str = "deepseek-chat",
    system: str = "you are a helpful assistant",
    user: str = "rank these stocks",
    schema_version: str = "v1",
    input_fingerprint: str | None = "deadbeef",
) -> dict[str, object]:
    return {
        "plugin_id": plugin_id,
        "stage": stage,
        "provider": provider,
        "model": model,
        "system_sha256": hash_text(system),
        "user_sha256": hash_text(user),
        "profile": profile,
        "schema_name": "MySchema",
        "schema_version": schema_version,
        "input_fingerprint": input_fingerprint,
    }


# ---------------------------------------------------------------------------
# LLMReplayPolicy
# ---------------------------------------------------------------------------


def test_policy_default_is_read_and_write() -> None:
    p = LLMReplayPolicy()
    assert p.read_enabled and p.write_enabled and not p.replay_only
    assert p.any_cache_active


def test_policy_disabled_helpers() -> None:
    d = LLMReplayPolicy.disabled()
    assert not d.read_enabled and not d.write_enabled
    assert not d.any_cache_active

    f = LLMReplayPolicy.fresh()
    assert not f.read_enabled and f.write_enabled
    assert f.any_cache_active

    r = LLMReplayPolicy.replay_only_()
    assert r.read_enabled and not r.write_enabled and r.replay_only
    assert r.any_cache_active


def test_policy_is_frozen() -> None:
    p = LLMReplayPolicy()
    # Pydantic v2 raises ValidationError on assignment to a frozen model.
    with pytest.raises(ValidationError):
        p.read_enabled = False  # type: ignore[misc]


def test_policy_rejects_unknown_field() -> None:
    # ConfigDict(extra="forbid") — unknown kwargs raise ValidationError.
    with pytest.raises(ValidationError):
        LLMReplayPolicy(foo=1)  # type: ignore[call-arg]


# ---------------------------------------------------------------------------
# LLMReplayMiss
# ---------------------------------------------------------------------------


def test_replay_miss_message_includes_short_key() -> None:
    exc = LLMReplayMiss(cache_key="a" * 64, plugin_id="p", stage="s")
    assert "a" * 12 in str(exc)
    assert "p" in str(exc) and "s" in str(exc)
    assert exc.cache_key == "a" * 64


# ---------------------------------------------------------------------------
# make_cache_key
# ---------------------------------------------------------------------------


def test_make_cache_key_stable_for_same_inputs(base_profile: StageProfile) -> None:
    kwargs = _make_kwargs(profile=base_profile)
    k1, fp1 = ReplayCacheStore.make_cache_key(**kwargs)  # type: ignore[arg-type]
    k2, fp2 = ReplayCacheStore.make_cache_key(**kwargs)  # type: ignore[arg-type]
    assert k1 == k2
    assert fp1 == fp2
    assert fp1["v"] == FRAMEWORK_LLM_CACHE_VERSION


def test_make_cache_key_changes_with_profile_temperature(
    base_profile: StageProfile,
) -> None:
    kwargs = _make_kwargs(profile=base_profile)
    k_base, _ = ReplayCacheStore.make_cache_key(**kwargs)  # type: ignore[arg-type]

    other = base_profile.model_copy(update={"temperature": 0.0})
    kwargs2 = _make_kwargs(profile=other)
    k_other, _ = ReplayCacheStore.make_cache_key(**kwargs2)  # type: ignore[arg-type]
    assert k_base != k_other


def test_make_cache_key_changes_with_model(base_profile: StageProfile) -> None:
    kwargs = _make_kwargs(profile=base_profile)
    k_base, _ = ReplayCacheStore.make_cache_key(**kwargs)  # type: ignore[arg-type]
    kwargs2 = _make_kwargs(profile=base_profile, model="deepseek-reasoner")
    k_other, _ = ReplayCacheStore.make_cache_key(**kwargs2)  # type: ignore[arg-type]
    assert k_base != k_other


def test_make_cache_key_changes_with_schema_version(base_profile: StageProfile) -> None:
    kwargs = _make_kwargs(profile=base_profile)
    k_base, _ = ReplayCacheStore.make_cache_key(**kwargs)  # type: ignore[arg-type]
    kwargs2 = _make_kwargs(profile=base_profile, schema_version="v2")
    k_other, _ = ReplayCacheStore.make_cache_key(**kwargs2)  # type: ignore[arg-type]
    assert k_base != k_other


def test_make_cache_key_changes_with_input_fingerprint(base_profile: StageProfile) -> None:
    kwargs = _make_kwargs(profile=base_profile, input_fingerprint="aaaa")
    k_a, _ = ReplayCacheStore.make_cache_key(**kwargs)  # type: ignore[arg-type]
    kwargs2 = _make_kwargs(profile=base_profile, input_fingerprint="bbbb")
    k_b, _ = ReplayCacheStore.make_cache_key(**kwargs2)  # type: ignore[arg-type]
    assert k_a != k_b


def test_make_cache_key_input_fingerprint_none_distinct_from_empty(
    base_profile: StageProfile,
) -> None:
    k_none, _ = ReplayCacheStore.make_cache_key(  # type: ignore[arg-type]
        **_make_kwargs(profile=base_profile, input_fingerprint=None)
    )
    k_empty, _ = ReplayCacheStore.make_cache_key(  # type: ignore[arg-type]
        **_make_kwargs(profile=base_profile, input_fingerprint="")
    )
    # None vs "" must hash differently — both are valid call shapes.
    assert k_none != k_empty


def test_make_cache_key_rejects_empty_strings(base_profile: StageProfile) -> None:
    with pytest.raises(ValueError, match="plugin_id"):
        ReplayCacheStore.make_cache_key(
            **{**_make_kwargs(profile=base_profile), "plugin_id": ""}  # type: ignore[arg-type]
        )
    with pytest.raises(ValueError, match="stage"):
        ReplayCacheStore.make_cache_key(
            **{**_make_kwargs(profile=base_profile), "stage": ""}  # type: ignore[arg-type]
        )
    with pytest.raises(ValueError, match="schema_version"):
        ReplayCacheStore.make_cache_key(
            **{**_make_kwargs(profile=base_profile), "schema_version": ""}  # type: ignore[arg-type]
        )


def test_make_cache_key_rejects_non_stageprofile(base_profile: StageProfile) -> None:
    kwargs = _make_kwargs(profile=base_profile)
    kwargs["profile"] = {"temperature": 0.0, "max_output_tokens": 2048}  # type: ignore[assignment]
    with pytest.raises(ValueError, match="StageProfile"):
        ReplayCacheStore.make_cache_key(**kwargs)  # type: ignore[arg-type]


def test_make_cache_key_includes_framework_version(base_profile: StageProfile) -> None:
    _, fp = ReplayCacheStore.make_cache_key(  # type: ignore[arg-type]
        **_make_kwargs(profile=base_profile)
    )
    assert fp["v"] == FRAMEWORK_LLM_CACHE_VERSION


# ---------------------------------------------------------------------------
# Store: lookup / store roundtrip
# ---------------------------------------------------------------------------


def test_lookup_miss_returns_none(store: ReplayCacheStore) -> None:
    assert store.lookup("nonexistent") is None


def test_store_and_lookup_roundtrip(store: ReplayCacheStore, base_profile: StageProfile) -> None:
    kwargs = _make_kwargs(profile=base_profile)
    cache_key, fingerprint = ReplayCacheStore.make_cache_key(**kwargs)  # type: ignore[arg-type]
    response = {"ts_code": "000001", "score": 0.85, "rationale": "金融板块强势"}
    meta = {
        "input_tokens": 1200,
        "output_tokens": 80,
        "latency_ms": 850,
        "prompt_hash": "abcd",
        "attempt_count": 1,
        "final_prompt_hash": "abcd",
    }
    store.store(
        cache_key=cache_key,
        plugin_id="test_plugin",
        stage="screening",
        provider="deepseek",
        model="deepseek-chat",
        prompt_hash="abcd",
        profile=base_profile,
        schema_name="MySchema",
        schema_version="v1",
        input_fingerprint="deadbeef",
        request_fingerprint=fingerprint,
        response_dict=response,
        response_meta=meta,
        source_run_id="run-123",
        source_call_id="call-456",
    )
    hit = store.lookup(cache_key)
    assert hit is not None
    assert isinstance(hit, CacheEntry)
    assert hit.cache_key == cache_key
    assert hit.response_dict == response
    assert hit.response_meta == meta
    assert hit.source_run_id == "run-123"
    assert hit.source_call_id == "call-456"
    assert hit.stage == "screening"
    assert hit.schema_version == "v1"
    assert isinstance(hit.created_at, datetime)


def test_store_upserts_on_same_key(store: ReplayCacheStore, base_profile: StageProfile) -> None:
    kwargs = _make_kwargs(profile=base_profile)
    cache_key, fingerprint = ReplayCacheStore.make_cache_key(**kwargs)  # type: ignore[arg-type]
    common = dict(
        cache_key=cache_key,
        plugin_id="test_plugin",
        stage="screening",
        provider="deepseek",
        model="deepseek-chat",
        prompt_hash="abcd",
        profile=base_profile,
        schema_name="MySchema",
        schema_version="v1",
        input_fingerprint="deadbeef",
        request_fingerprint=fingerprint,
    )
    store.store(
        **common,
        response_dict={"v": 1},
        response_meta={"attempt_count": 1},
        source_run_id="run-1",
        source_call_id="call-1",
    )
    store.store(
        **common,
        response_dict={"v": 2},
        response_meta={"attempt_count": 2},
        source_run_id="run-2",
        source_call_id="call-2",
    )
    hit = store.lookup(cache_key)
    assert hit is not None
    assert hit.response_dict == {"v": 2}
    assert hit.source_run_id == "run-2"


# ---------------------------------------------------------------------------
# TTL
# ---------------------------------------------------------------------------


def test_lookup_respects_ttl(
    store: ReplayCacheStore, base_profile: StageProfile, db: Database
) -> None:
    kwargs = _make_kwargs(profile=base_profile)
    cache_key, fingerprint = ReplayCacheStore.make_cache_key(**kwargs)  # type: ignore[arg-type]
    store.store(
        cache_key=cache_key,
        plugin_id="test_plugin",
        stage="screening",
        provider="deepseek",
        model="deepseek-chat",
        prompt_hash="abcd",
        profile=base_profile,
        schema_name="MySchema",
        schema_version="v1",
        input_fingerprint="deadbeef",
        request_fingerprint=fingerprint,
        response_dict={"ok": True},
        response_meta={},
        source_run_id="r",
        source_call_id="c",
    )
    # Backdate the row so it appears 5 days old.
    five_days_ago = datetime.now() - timedelta(days=5)
    db.execute(
        "UPDATE llm_replay_cache SET created_at = ? WHERE cache_key = ?",
        (five_days_ago, cache_key),
    )
    # TTL larger than age: still a hit.
    assert store.lookup(cache_key, ttl_days=30) is not None
    # TTL smaller than age: treated as miss.
    assert store.lookup(cache_key, ttl_days=1) is None
    # TTL of None disables expiry.
    assert store.lookup(cache_key, ttl_days=None) is not None


# ---------------------------------------------------------------------------
# Purge
# ---------------------------------------------------------------------------


def _seed(
    store: ReplayCacheStore,
    base_profile: StageProfile,
    *,
    plugin_id: str,
    stage: str,
    user: str,
) -> str:
    kwargs = _make_kwargs(
        profile=base_profile,
        plugin_id=plugin_id,
        stage=stage,
        user=user,
    )
    cache_key, fingerprint = ReplayCacheStore.make_cache_key(**kwargs)  # type: ignore[arg-type]
    store.store(
        cache_key=cache_key,
        plugin_id=plugin_id,
        stage=stage,
        provider="deepseek",
        model="deepseek-chat",
        prompt_hash="abcd",
        profile=base_profile,
        schema_name="MySchema",
        schema_version="v1",
        input_fingerprint="deadbeef",
        request_fingerprint=fingerprint,
        response_dict={"hi": user},
        response_meta={},
        source_run_id="r",
        source_call_id="c",
    )
    return cache_key


def test_purge_refuses_unfiltered(store: ReplayCacheStore) -> None:
    with pytest.raises(ValueError, match="refuse to delete with no filter"):
        store.purge()


def test_purge_by_plugin(store: ReplayCacheStore, base_profile: StageProfile, db: Database) -> None:
    _seed(store, base_profile, plugin_id="p1", stage="s1", user="u1")
    _seed(store, base_profile, plugin_id="p1", stage="s2", user="u2")
    _seed(store, base_profile, plugin_id="p2", stage="s1", user="u3")
    count = store.purge(plugin_id="p1")
    assert count == 2
    remaining = db.fetchone("SELECT COUNT(*) FROM llm_replay_cache")
    assert remaining and remaining[0] == 1


def test_purge_by_stage(store: ReplayCacheStore, base_profile: StageProfile) -> None:
    _seed(store, base_profile, plugin_id="p1", stage="s1", user="u1")
    _seed(store, base_profile, plugin_id="p2", stage="s1", user="u2")
    _seed(store, base_profile, plugin_id="p1", stage="s2", user="u3")
    count = store.purge(stage="s1")
    assert count == 2


def test_purge_before_days(
    store: ReplayCacheStore, base_profile: StageProfile, db: Database
) -> None:
    k_old = _seed(store, base_profile, plugin_id="p1", stage="s1", user="old")
    k_new = _seed(store, base_profile, plugin_id="p1", stage="s2", user="new")
    db.execute(
        "UPDATE llm_replay_cache SET created_at = ? WHERE cache_key = ?",
        (datetime.now() - timedelta(days=10), k_old),
    )
    count = store.purge(before_days=7)
    assert count == 1
    assert store.lookup(k_old) is None
    assert store.lookup(k_new) is not None


def test_purge_negative_days_rejected(store: ReplayCacheStore) -> None:
    with pytest.raises(ValueError, match="before_days must be >= 0"):
        store.purge(before_days=-1)


# ---------------------------------------------------------------------------
# iter_entries
# ---------------------------------------------------------------------------


def test_iter_entries_orders_most_recent_first(
    store: ReplayCacheStore, base_profile: StageProfile
) -> None:
    k1 = _seed(store, base_profile, plugin_id="p", stage="s", user="u1")
    # Small sleep so created_at strictly differs (DuckDB TIMESTAMP has µs).
    time.sleep(0.01)
    k2 = _seed(store, base_profile, plugin_id="p", stage="s", user="u2")
    rows = list(store.iter_entries(plugin_id="p", limit=10))
    assert [r.cache_key for r in rows] == [k2, k1]


def test_iter_entries_filters_by_plugin_and_stage(
    store: ReplayCacheStore, base_profile: StageProfile
) -> None:
    _seed(store, base_profile, plugin_id="p1", stage="s1", user="u1")
    _seed(store, base_profile, plugin_id="p2", stage="s1", user="u2")
    _seed(store, base_profile, plugin_id="p1", stage="s2", user="u3")
    rows_p1 = list(store.iter_entries(plugin_id="p1"))
    assert {r.stage for r in rows_p1} == {"s1", "s2"}
    rows_p1_s1 = list(store.iter_entries(plugin_id="p1", stage="s1"))
    assert len(rows_p1_s1) == 1
    assert rows_p1_s1[0].stage == "s1"


def test_iter_entries_rejects_bad_pagination(store: ReplayCacheStore) -> None:
    with pytest.raises(ValueError, match="limit must be > 0"):
        next(store.iter_entries(limit=0))
    with pytest.raises(ValueError, match="offset must be >= 0"):
        next(store.iter_entries(offset=-1))


# ---------------------------------------------------------------------------
# policy_from_env
# ---------------------------------------------------------------------------


def test_policy_from_env_default(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("DEEPTRADE_FRESH_LLM", raising=False)
    monkeypatch.delenv("DEEPTRADE_NO_LLM_REPLAY", raising=False)
    monkeypatch.delenv("DEEPTRADE_REPLAY_ONLY", raising=False)
    p = policy_from_env()
    assert p == LLMReplayPolicy()


def test_policy_from_env_fresh(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("DEEPTRADE_REPLAY_ONLY", raising=False)
    monkeypatch.delenv("DEEPTRADE_NO_LLM_REPLAY", raising=False)
    monkeypatch.setenv("DEEPTRADE_FRESH_LLM", "1")
    assert policy_from_env() == LLMReplayPolicy.fresh()


def test_policy_from_env_disabled(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("DEEPTRADE_REPLAY_ONLY", raising=False)
    monkeypatch.setenv("DEEPTRADE_NO_LLM_REPLAY", "true")
    assert policy_from_env() == LLMReplayPolicy.disabled()


def test_policy_from_env_replay_only(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DEEPTRADE_REPLAY_ONLY", "yes")
    assert policy_from_env() == LLMReplayPolicy.replay_only_()


def test_policy_from_env_replay_only_wins_over_others(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # Conflict resolution order: REPLAY_ONLY > NO_LLM_REPLAY > FRESH_LLM.
    monkeypatch.setenv("DEEPTRADE_REPLAY_ONLY", "1")
    monkeypatch.setenv("DEEPTRADE_NO_LLM_REPLAY", "1")
    monkeypatch.setenv("DEEPTRADE_FRESH_LLM", "1")
    assert policy_from_env() == LLMReplayPolicy.replay_only_()


def test_policy_from_env_falsey_values_ignored(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DEEPTRADE_FRESH_LLM", "0")
    monkeypatch.setenv("DEEPTRADE_NO_LLM_REPLAY", "false")
    monkeypatch.setenv("DEEPTRADE_REPLAY_ONLY", "no")
    assert policy_from_env() == LLMReplayPolicy()


def test_policy_from_env_respects_base(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("DEEPTRADE_FRESH_LLM", raising=False)
    monkeypatch.delenv("DEEPTRADE_NO_LLM_REPLAY", raising=False)
    monkeypatch.delenv("DEEPTRADE_REPLAY_ONLY", raising=False)
    base = LLMReplayPolicy(ttl_days=30, cache_namespace="ns")
    assert policy_from_env(base) is base
