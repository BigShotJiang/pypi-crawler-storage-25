"""v0.12 — LLM replay cache integration in ``LLMClient.complete_json``.

These tests exercise the read / replay-only / write / repair-retry
branches end-to-end against a ``RecordedTransport`` so we can assert
that:

* a cache hit returns the original validated object without invoking
  the transport (the queue stays full),
* a ``replay_only`` miss raises :class:`LLMReplayMiss` and still leaves
  the transport untouched,
* successful real calls write the cache row, and the next call with
  the same inputs serves from cache,
* changing profile / schema_version / input_fingerprint invalidates
  the cache,
* repair-retry success persists the *final* prompt to cache, so a
  second identical call doesn't replay the bad first attempt,
* ``LLMConfigError`` fires when replay is active but the caller did
  not supply ``stage`` / ``schema_version``.

Existing pre-v0.12 tests (no ``replay`` argument) keep their original
semantics; this file is additive.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from pydantic import BaseModel, ConfigDict, Field

from deeptrade.core.db import Database
from deeptrade.core.llm_client import (
    LLMClient,
    LLMConfigError,
    LLMResponse,
    LLMTransport,
    RecordedTransport,
)
from deeptrade.plugins_api import (
    LLMReplayMiss,
    LLMReplayPolicy,
    StageProfile,
)

# Shared profile — temperature/thinking values mirror the limit-up-board
# "fast / screening" tuning the real plugin uses.
PROFILE = StageProfile(
    thinking=False, reasoning_effort="medium", temperature=0.1, max_output_tokens=32768
)


class _Schema(BaseModel):
    model_config = ConfigDict(extra="forbid")
    candidates: list[str] = Field(default_factory=list)


def _ok(
    text: str = '{"candidates":["a","b"]}', *, in_tok: int = 100, out_tok: int = 50
) -> LLMResponse:
    return LLMResponse(text=text, input_tokens=in_tok, output_tokens=out_tok)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def db(tmp_path: Path) -> Database:
    return Database(tmp_path / "replay-client.duckdb")


@pytest.fixture
def transport() -> RecordedTransport:
    return RecordedTransport()


@pytest.fixture
def client(db: Database, transport: RecordedTransport) -> LLMClient:
    return LLMClient(
        db,
        transport,
        model="deepseek-chat",
        provider="deepseek",
        plugin_id="test-plugin",
        run_id="00000000-0000-0000-0000-0000000000a1",
    )


# ---------------------------------------------------------------------------
# Config error guards
# ---------------------------------------------------------------------------


def test_replay_active_without_stage_raises(
    client: LLMClient, transport: RecordedTransport
) -> None:
    transport.register(_ok())
    with pytest.raises(LLMConfigError, match="stage"):
        client.complete_json(
            system="s",
            user="u",
            schema=_Schema,
            profile=PROFILE,
            replay=LLMReplayPolicy(),
        )


def test_replay_active_without_schema_version_raises(
    client: LLMClient, transport: RecordedTransport
) -> None:
    transport.register(_ok())
    with pytest.raises(LLMConfigError, match="schema_version"):
        client.complete_json(
            system="s",
            user="u",
            schema=_Schema,
            profile=PROFILE,
            replay=LLMReplayPolicy(),
            stage="screening",
        )


def test_replay_active_without_provider_raises(db: Database, transport: RecordedTransport) -> None:
    # Construct a client WITHOUT provider — direct construction is the
    # only path that hits this; LLMManager.get_client always supplies one.
    cli = LLMClient(db, transport, model="deepseek-chat", plugin_id="p")
    transport.register(_ok())
    with pytest.raises(LLMConfigError, match="provider"):
        cli.complete_json(
            system="s",
            user="u",
            schema=_Schema,
            profile=PROFILE,
            replay=LLMReplayPolicy(),
            stage="screening",
            schema_version="v1",
        )


def test_disabled_replay_does_not_require_stage(
    client: LLMClient, transport: RecordedTransport
) -> None:
    # The default ``replay=None`` is disabled; no stage / schema_version
    # needed, behavior matches pre-v0.12 callers exactly.
    transport.register(_ok())
    obj, meta = client.complete_json(system="s", user="u", schema=_Schema, profile=PROFILE)
    assert isinstance(obj, _Schema)
    assert "cache_hit" not in meta or meta["cache_hit"] is False


# ---------------------------------------------------------------------------
# Cache hit / write
# ---------------------------------------------------------------------------


def _call(client: LLMClient, *, replay: LLMReplayPolicy | None = None, **extra: object) -> tuple:
    return client.complete_json(
        system="s",
        user="u",
        schema=_Schema,
        profile=PROFILE,
        stage="screening",
        schema_version="v1",
        input_fingerprint="fp1",
        replay=replay if replay is not None else LLMReplayPolicy(),
        **extra,  # type: ignore[arg-type]
    )


def test_first_call_writes_cache_second_hits(
    client: LLMClient, transport: RecordedTransport, db: Database
) -> None:
    transport.register(_ok())
    obj1, meta1 = _call(client)
    assert meta1["cache_hit"] is False
    assert meta1["cache_key"] is not None

    # Queue is empty now — a second invocation MUST be served from cache,
    # otherwise it would raise from the empty RecordedTransport queue.
    obj2, meta2 = _call(client)
    assert obj2.model_dump() == obj1.model_dump()
    assert meta2["cache_hit"] is True
    assert meta2["cache_key"] == meta1["cache_key"]
    assert meta2["source_run_id"] == "00000000-0000-0000-0000-0000000000a1"
    assert meta2["source_call_id"] == meta1["call_id"]
    assert meta2["tokens_from_cache"] is True

    # Cache row written to the framework table.
    row = db.fetchone(
        "SELECT plugin_id, stage, provider, model, schema_version, input_fingerprint "
        "FROM llm_replay_cache"
    )
    assert row == ("test-plugin", "screening", "deepseek", "deepseek-chat", "v1", "fp1")

    # Audit: two llm_calls rows, ok then cached.
    statuses = [
        r[0] for r in db.fetchall("SELECT validation_status FROM llm_calls ORDER BY created_at")
    ]
    assert statuses == ["ok", "cached"]
    cache_hit_row = db.fetchone(
        "SELECT cache_hit, source_call_id FROM llm_calls WHERE validation_status='cached'"
    )
    assert cache_hit_row is not None
    assert cache_hit_row[0] is True
    assert cache_hit_row[1] == meta1["call_id"]


def test_cache_hit_skips_transport_invocation(
    client: LLMClient, transport: RecordedTransport
) -> None:
    transport.register(_ok())
    _call(client)
    # Don't register more — the second call must NOT touch the transport.
    obj, meta = _call(client)
    assert isinstance(obj, _Schema)
    assert meta["cache_hit"] is True


def test_disabled_policy_neither_reads_nor_writes(
    client: LLMClient, transport: RecordedTransport, db: Database
) -> None:
    transport.register(_ok())
    _call(client, replay=LLMReplayPolicy.disabled())
    row = db.fetchone("SELECT COUNT(*) FROM llm_replay_cache")
    assert row is not None and row[0] == 0

    # A subsequent disabled call also must NOT hit cache (no previous write anyway).
    transport.register(_ok())
    _, meta = _call(client, replay=LLMReplayPolicy.disabled())
    assert meta["cache_hit"] is False


def test_fresh_skips_read_but_writes(
    client: LLMClient, transport: RecordedTransport, db: Database
) -> None:
    # First call — write cache.
    transport.register(_ok())
    _call(client)
    cache_count_after_first = db.fetchone("SELECT COUNT(*) FROM llm_replay_cache")
    assert cache_count_after_first is not None and cache_count_after_first[0] == 1

    # Fresh call — would normally hit cache, but read_enabled=False forces
    # a real provider call. Queue another canned response.
    transport.register(_ok(text='{"candidates":["fresh"]}'))
    obj, meta = _call(client, replay=LLMReplayPolicy.fresh())
    assert meta["cache_hit"] is False
    assert obj.candidates == ["fresh"]

    # The cache row was overwritten with the fresh result.
    row = db.fetchone("SELECT response_json FROM llm_replay_cache")
    assert row is not None
    assert json.loads(row[0]) == {"candidates": ["fresh"]}


# ---------------------------------------------------------------------------
# replay_only
# ---------------------------------------------------------------------------


def test_replay_only_miss_raises_and_records_audit(
    client: LLMClient, transport: RecordedTransport, db: Database
) -> None:
    with pytest.raises(LLMReplayMiss):
        _call(client, replay=LLMReplayPolicy.replay_only_())
    # Transport must NOT have been touched.
    assert transport.last_call_kwargs == {}
    # Audit row recorded with replay_miss.
    row = db.fetchone("SELECT validation_status, cache_hit, cache_key FROM llm_calls")
    assert row is not None
    assert row[0] == "replay_miss"
    assert row[1] is False
    assert row[2] is not None  # cache_key was still computed


def test_replay_only_hit_serves_from_cache(client: LLMClient, transport: RecordedTransport) -> None:
    # Seed cache via a normal call.
    transport.register(_ok())
    _call(client)
    # Now replay-only — must hit cache without invoking the transport.
    obj, meta = _call(client, replay=LLMReplayPolicy.replay_only_())
    assert meta["cache_hit"] is True
    assert isinstance(obj, _Schema)


# ---------------------------------------------------------------------------
# Cache key invalidation
# ---------------------------------------------------------------------------


def test_profile_change_misses_cache(client: LLMClient, transport: RecordedTransport) -> None:
    transport.register(_ok())
    _call(client)
    # Different temperature → cache miss.
    other_profile = PROFILE.model_copy(update={"temperature": 0.0})
    transport.register(_ok(text='{"candidates":["t0"]}'))
    obj, meta = client.complete_json(
        system="s",
        user="u",
        schema=_Schema,
        profile=other_profile,
        stage="screening",
        schema_version="v1",
        input_fingerprint="fp1",
        replay=LLMReplayPolicy(),
    )
    assert meta["cache_hit"] is False
    assert obj.candidates == ["t0"]


def test_schema_version_change_misses_cache(
    client: LLMClient, transport: RecordedTransport
) -> None:
    transport.register(_ok())
    _call(client)
    transport.register(_ok(text='{"candidates":["v2"]}'))
    obj, meta = client.complete_json(
        system="s",
        user="u",
        schema=_Schema,
        profile=PROFILE,
        stage="screening",
        schema_version="v2",  # bumped
        input_fingerprint="fp1",
        replay=LLMReplayPolicy(),
    )
    assert meta["cache_hit"] is False
    assert obj.candidates == ["v2"]


def test_input_fingerprint_change_misses_cache(
    client: LLMClient, transport: RecordedTransport
) -> None:
    transport.register(_ok())
    _call(client)
    transport.register(_ok(text='{"candidates":["fp2"]}'))
    obj, meta = client.complete_json(
        system="s",
        user="u",
        schema=_Schema,
        profile=PROFILE,
        stage="screening",
        schema_version="v1",
        input_fingerprint="fp2",  # bumped
        replay=LLMReplayPolicy(),
    )
    assert meta["cache_hit"] is False
    assert obj.candidates == ["fp2"]


# ---------------------------------------------------------------------------
# Repair retry
# ---------------------------------------------------------------------------


def test_repair_retry_persists_final_response(
    client: LLMClient, transport: RecordedTransport, db: Database
) -> None:
    # First attempt fails JSON parsing; second attempt succeeds.
    transport.register(LLMResponse(text="not json{", input_tokens=10, output_tokens=4))
    transport.register(_ok())
    obj, meta = _call(client)

    # Meta reflects the repair sequence.
    assert meta["attempt_count"] == 2
    assert meta["first_error_class"] == "JSONDecodeError"
    assert meta["repair_hint_hash"] is not None
    assert meta["final_prompt_hash"] != meta["prompt_hash"]
    assert obj.candidates == ["a", "b"]

    # Audit: retry → ok.
    statuses = [
        r[0] for r in db.fetchall("SELECT validation_status FROM llm_calls ORDER BY created_at")
    ]
    assert statuses == ["retry", "ok"]

    # Cache row carries the final (repaired) response.
    row = db.fetchone("SELECT response_json, response_meta_json FROM llm_replay_cache")
    assert row is not None
    assert json.loads(row[0]) == {"candidates": ["a", "b"]}
    cached_meta = json.loads(row[1])
    assert cached_meta["attempt_count"] == 2
    assert cached_meta["first_error_class"] == "JSONDecodeError"

    # Second call replays without invoking transport.
    obj2, meta2 = _call(client)
    assert meta2["cache_hit"] is True
    assert obj2.candidates == ["a", "b"]
    assert meta2["attempt_count"] == 2  # propagated from cached meta


# ---------------------------------------------------------------------------
# Backward-compatible behavior: pre-v0.12 callers
# ---------------------------------------------------------------------------


def test_legacy_call_path_unaffected(
    client: LLMClient, transport: RecordedTransport, db: Database
) -> None:
    """Plugins that pre-date v0.12 pass no replay / stage / schema_version.
    Behavior must match pre-v0.12: real provider call every time, no cache
    writes, no audit-row schema regression."""
    transport.register(_ok())
    obj, meta = client.complete_json(system="legacy", user="u", schema=_Schema, profile=PROFILE)
    assert isinstance(obj, _Schema)
    assert "prompt_hash" in meta
    cache_count = db.fetchone("SELECT COUNT(*) FROM llm_replay_cache")
    assert cache_count is not None and cache_count[0] == 0

    # validation_status remains "ok" on the audit row.
    row = db.fetchone("SELECT validation_status, cache_hit FROM llm_calls")
    assert row is not None
    assert row[0] == "ok"
    assert row[1] is False


# ---------------------------------------------------------------------------
# JSONL audit (when reports_dir is set)
# ---------------------------------------------------------------------------


def test_jsonl_audit_includes_cache_fields(tmp_path: Path) -> None:
    db = Database(tmp_path / "jsonl.duckdb")
    transport = RecordedTransport()
    reports_dir = tmp_path / "reports" / "00000000-0000-0000-0000-0000000000a2"
    cli = LLMClient(
        db,
        transport,
        model="deepseek-chat",
        provider="deepseek",
        plugin_id="p",
        run_id="00000000-0000-0000-0000-0000000000a2",
        reports_dir=reports_dir,
    )
    transport.register(_ok())
    cli.complete_json(
        system="s",
        user="u",
        schema=_Schema,
        profile=PROFILE,
        stage="screening",
        schema_version="v1",
        input_fingerprint="fp1",
        replay=LLMReplayPolicy(),
    )
    cli.complete_json(  # cache hit
        system="s",
        user="u",
        schema=_Schema,
        profile=PROFILE,
        stage="screening",
        schema_version="v1",
        input_fingerprint="fp1",
        replay=LLMReplayPolicy(),
    )
    jsonl = (reports_dir / "llm_calls.jsonl").read_text(encoding="utf-8").splitlines()
    assert len(jsonl) == 2
    row1 = json.loads(jsonl[0])
    row2 = json.loads(jsonl[1])
    assert row1["cache_hit"] is False
    assert row1["stage"] == "screening"
    assert row1["schema_version"] == "v1"
    assert row1["input_fingerprint"] == "fp1"
    assert row1["attempt_count"] == 1
    assert row2["cache_hit"] is True
    assert row2["tokens_from_cache"] is True
    assert row2["source_call_id"] == row1["call_id"]


# ---------------------------------------------------------------------------
# Cross-client cache sharing (same provider/model + matching fingerprint)
# ---------------------------------------------------------------------------


def test_cache_shared_across_clients_same_provider(
    db: Database, transport: RecordedTransport
) -> None:
    """A second client built on the SAME db / provider / model should hit
    the cache written by the first — caching is a framework-level service,
    not a per-LLMClient one."""
    cli_a = LLMClient(
        db,
        transport,
        model="deepseek-chat",
        provider="deepseek",
        plugin_id="p",
        run_id="00000000-0000-0000-0000-0000000000b1",
    )
    cli_b = LLMClient(
        db,
        transport,
        model="deepseek-chat",
        provider="deepseek",
        plugin_id="p",
        run_id="00000000-0000-0000-0000-0000000000b2",
    )
    transport.register(_ok())
    cli_a.complete_json(
        system="s",
        user="u",
        schema=_Schema,
        profile=PROFILE,
        stage="screening",
        schema_version="v1",
        input_fingerprint="fp1",
        replay=LLMReplayPolicy(),
    )
    # No more queued responses — cli_b must hit cache.
    _, meta = cli_b.complete_json(
        system="s",
        user="u",
        schema=_Schema,
        profile=PROFILE,
        stage="screening",
        schema_version="v1",
        input_fingerprint="fp1",
        replay=LLMReplayPolicy(),
    )
    assert meta["cache_hit"] is True
    assert meta["source_run_id"] == "00000000-0000-0000-0000-0000000000b1"


# ---------------------------------------------------------------------------
# Stub transport that asserts it is never called — extra paranoia for
# replay_only and cache-hit paths.
# ---------------------------------------------------------------------------


class _ExplodingTransport(LLMTransport):
    def chat(self, **_kw: object) -> LLMResponse:  # type: ignore[override]
        raise AssertionError(
            "transport.chat() was invoked but the test expected a cache hit / replay miss"
        )


def test_cache_hit_path_does_not_call_transport(db: Database, tmp_path: Path) -> None:
    seeder_transport = RecordedTransport()
    cli_seed = LLMClient(
        db,
        seeder_transport,
        model="m",
        provider="prov",
        plugin_id="p",
        run_id="00000000-0000-0000-0000-0000000000c1",
    )
    seeder_transport.register(_ok())
    cli_seed.complete_json(
        system="s",
        user="u",
        schema=_Schema,
        profile=PROFILE,
        stage="screening",
        schema_version="v1",
        input_fingerprint="fp1",
        replay=LLMReplayPolicy(),
    )
    # New client wired with an exploding transport.
    cli = LLMClient(
        db,
        _ExplodingTransport(),
        model="m",
        provider="prov",
        plugin_id="p",
        run_id="00000000-0000-0000-0000-0000000000c2",
    )
    obj, meta = cli.complete_json(
        system="s",
        user="u",
        schema=_Schema,
        profile=PROFILE,
        stage="screening",
        schema_version="v1",
        input_fingerprint="fp1",
        replay=LLMReplayPolicy(),
    )
    assert meta["cache_hit"] is True
    assert isinstance(obj, _Schema)
