"""CLI logging bootstrap tests — v0.10 H1.

Verifies that invoking any framework command calls ``setup_logging()`` so the
``~/.deeptrade/logs/deeptrade.log`` rotating file handler is wired up.
``app.log_level`` configured in the DB is read; when the DB is missing the
CLI silently falls back to ``INFO`` so first-run init still succeeds.
"""

from __future__ import annotations

import logging
from pathlib import Path

import pytest
from typer.testing import CliRunner

from deeptrade.cli import app
from deeptrade.core.config import ConfigService
from deeptrade.core.db import Database, apply_core_migrations


def _reset_root_logger() -> None:
    root = logging.getLogger()
    for h in list(root.handlers):
        root.removeHandler(h)
    root.setLevel(logging.WARNING)


@pytest.fixture(autouse=True)
def _restore_logging() -> None:
    yield
    _reset_root_logger()


def test_cli_init_creates_log_file_and_handlers(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setenv("DEEPTRADE_HOME", str(tmp_path))
    runner = CliRunner()
    result = runner.invoke(app, ["init", "--no-prompts"])
    assert result.exit_code == 0, result.output

    log_file = tmp_path / "logs" / "deeptrade.log"
    assert log_file.exists(), "setup_logging() should open the rotating file handler"

    root = logging.getLogger()
    deeptrade_handlers = [h for h in root.handlers if getattr(h, "_deeptrade", False)]
    assert deeptrade_handlers, "CLI must install the rotating + stderr handler pair"


def test_cli_picks_up_configured_log_level(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setenv("DEEPTRADE_HOME", str(tmp_path))
    db_path = tmp_path / "deeptrade.duckdb"
    db = Database(db_path)
    apply_core_migrations(db)
    ConfigService(db).set("app.log_level", "DEBUG")
    db.close()

    runner = CliRunner()
    result = runner.invoke(app, ["plugin", "list"])
    assert result.exit_code == 0, result.output

    assert logging.getLogger().level == logging.DEBUG, (
        "CLI bootstrap should apply the persisted app.log_level"
    )


def test_cli_logging_survives_missing_db(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """A fresh checkout has no DB yet at the callback's bootstrap moment;
    logging must still come up at INFO before ``init`` creates the DB."""
    monkeypatch.setenv("DEEPTRADE_HOME", str(tmp_path))
    # Sanity check the precondition: the DB file does not exist before invocation.
    assert not (tmp_path / "deeptrade.duckdb").exists()
    runner = CliRunner()
    result = runner.invoke(app, ["init", "--no-prompts"])
    assert result.exit_code == 0, result.output
    assert logging.getLogger().level == logging.INFO
