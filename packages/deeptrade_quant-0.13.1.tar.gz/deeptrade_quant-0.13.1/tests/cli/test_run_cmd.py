"""v0.13 — ``deeptrade run show`` / ``deeptrade run compare`` CLI tests.

End-to-end via Typer's :class:`CliRunner`. Each test seeds the framework
tables directly via :class:`PluginContext` (the same path real plugins
take), then invokes the CLI and inspects stdout / exit code.
"""

from __future__ import annotations

import json
from datetime import date
from pathlib import Path

import pytest
from typer.testing import CliRunner

from deeptrade.cli import app
from deeptrade.core.config import ConfigService
from deeptrade.core.db import Database
from deeptrade.plugins_api import PluginContext

RUN_A = "00000000-0000-0000-0000-0000000000a1"
RUN_B = "00000000-0000-0000-0000-0000000000a2"


@pytest.fixture
def home(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> Path:
    monkeypatch.setenv("DEEPTRADE_HOME", str(tmp_path))
    runner = CliRunner()
    result = runner.invoke(app, ["init", "--no-prompts"])
    assert result.exit_code == 0, result.stdout
    return tmp_path


def _ctx(home: Path, plugin_id: str = "demo-plugin") -> tuple[PluginContext, Database]:
    db = Database(home / "deeptrade.duckdb")
    return PluginContext(db=db, config=ConfigService(db), plugin_id=plugin_id), db


def _seed_run(
    home: Path,
    *,
    plugin_id: str,
    run_id: str,
    key_date: date,
    fingerprint: str,
    payload: dict,
    artifacts: list[tuple[str, str]] | None = None,
) -> None:
    """Populate run_metadata + run_artifacts. ``artifacts`` is a list of
    ``(name, sha256)`` tuples; the file under ``path`` is a fake on-disk
    artifact created in ``home``."""
    ctx, db = _ctx(home, plugin_id)
    try:
        ctx.set_run_key_date(run_id, key_date)
        ctx.set_run_input_fingerprint(run_id, fingerprint, payload)
        for name, content in artifacts or []:
            p = home / f"{plugin_id}-{run_id}-{name}"
            p.write_text(content, encoding="utf-8")
            ctx.add_run_artifact(run_id, name=name, path=p)
    finally:
        db.close()


def _seed_llm_call(
    home: Path,
    *,
    plugin_id: str,
    run_id: str,
    stage: str,
    model: str,
    prompt_hash: str,
    final_prompt_hash: str | None = None,
    cache_hit: bool = False,
    validation_status: str = "ok",
    attempt_count: int = 1,
    source_call_id: str | None = None,
) -> str:
    import uuid

    call_id = str(uuid.uuid4())
    db = Database(home / "deeptrade.duckdb")
    try:
        db.execute(
            "INSERT INTO llm_calls(call_id, run_id, plugin_id, model, prompt_hash, "
            "validation_status, cache_hit, stage, attempt_count, "
            "final_prompt_hash, source_call_id) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                call_id,
                run_id,
                plugin_id,
                model,
                prompt_hash,
                validation_status,
                cache_hit,
                stage,
                attempt_count,
                final_prompt_hash or prompt_hash,
                source_call_id,
            ),
        )
    finally:
        db.close()
    return call_id


# ---------------------------------------------------------------------------
# `run show`
# ---------------------------------------------------------------------------


def test_run_show_human_format_runs(home: Path) -> None:
    """Human format renders via Rich; in a CliRunner the table columns are
    cropped at the test terminal width (~80 cols), so we only assert that
    the command exits 0 and the header fields (which sit on their own
    lines, not in a table) are present. Content correctness is covered by
    the JSON-format test."""
    _seed_run(
        home,
        plugin_id="demo",
        run_id=RUN_A,
        key_date=date(2026, 5, 24),
        fingerprint="a" * 64,
        payload={"trade_date": "2026-05-24", "candidates": ["A", "B"]},
        artifacts=[("summary.md", "hello"), ("targets.json", '{"k":1}')],
    )
    _seed_llm_call(
        home,
        plugin_id="demo",
        run_id=RUN_A,
        stage="screening",
        model="deepseek-chat",
        prompt_hash="b" * 64,
    )

    runner = CliRunner()
    result = runner.invoke(app, ["run", "show", RUN_A])
    assert result.exit_code == 0, result.stdout
    # Header lines are not table cells; they always render in full.
    assert "demo" in result.stdout
    assert RUN_A in result.stdout
    assert "2026-05-24" in result.stdout


def test_run_show_json_format(home: Path) -> None:
    _seed_run(
        home,
        plugin_id="demo",
        run_id=RUN_A,
        key_date=date(2026, 5, 24),
        fingerprint="a" * 64,
        payload={"k": "v"},
    )
    runner = CliRunner()
    result = runner.invoke(app, ["run", "show", RUN_A, "--format", "json"])
    assert result.exit_code == 0, result.stdout
    payload = json.loads(result.stdout)
    assert payload["plugin_id"] == "demo"
    assert payload["run_id"] == RUN_A
    assert payload["key_date"] == "2026-05-24"
    assert payload["input_fingerprint"] == "a" * 64
    assert payload["input_payload"] == {"k": "v"}


def test_run_show_missing_exits_2(home: Path) -> None:
    runner = CliRunner()
    result = runner.invoke(app, ["run", "show", RUN_A])
    assert result.exit_code == 2
    assert "未找到" in result.stdout


def test_run_show_ambiguous_requires_plugin(home: Path) -> None:
    """Same run_id under two plugins → must require --plugin."""
    for pid in ("plugin-A", "plugin-B"):
        _seed_run(
            home,
            plugin_id=pid,
            run_id=RUN_A,
            key_date=date(2026, 5, 24),
            fingerprint="f",
            payload={"p": pid},
        )
    runner = CliRunner()
    result = runner.invoke(app, ["run", "show", RUN_A])
    assert result.exit_code == 2
    assert "多个插件" in result.stdout
    assert "plugin-A" in result.stdout and "plugin-B" in result.stdout

    ok = runner.invoke(app, ["run", "show", RUN_A, "--plugin", "plugin-A"])
    assert ok.exit_code == 0, ok.stdout
    assert "plugin-A" in ok.stdout


# ---------------------------------------------------------------------------
# `run compare`
# ---------------------------------------------------------------------------


def test_run_compare_identical_runs(home: Path) -> None:
    """A run vs. itself (different run_id, identical fingerprint + same
    LLM calls + same artifacts) → all sections report equal."""
    common_payload = {"x": 1, "y": ["a", "b"]}
    common_fp = "f" * 64
    for run_id in (RUN_A, RUN_B):
        _seed_run(
            home,
            plugin_id="demo",
            run_id=run_id,
            key_date=date(2026, 5, 24),
            fingerprint=common_fp,
            payload=common_payload,
        )
        _seed_llm_call(
            home,
            plugin_id="demo",
            run_id=run_id,
            stage="screening",
            model="deepseek-chat",
            prompt_hash="p1" * 32,
        )

    runner = CliRunner()
    result = runner.invoke(app, ["run", "compare", RUN_A, RUN_B])
    assert result.exit_code == 0, result.stdout
    assert "basic fields equal" in result.stdout
    assert "fingerprint identical" in result.stdout


def test_run_compare_fingerprint_diff(home: Path) -> None:
    _seed_run(
        home,
        plugin_id="demo",
        run_id=RUN_A,
        key_date=date(2026, 5, 24),
        fingerprint="aaaaaaaa" + "a" * 56,
        payload={"k": 1},
    )
    _seed_run(
        home,
        plugin_id="demo",
        run_id=RUN_B,
        key_date=date(2026, 5, 24),
        fingerprint="bbbbbbbb" + "b" * 56,
        payload={"k": 2},
    )
    runner = CliRunner()
    result = runner.invoke(app, ["run", "compare", RUN_A, RUN_B])
    assert result.exit_code == 0, result.stdout
    assert "fingerprint" in result.stdout
    # JSON variant also surfaces the payload diff.
    js = runner.invoke(app, ["run", "compare", RUN_A, RUN_B, "--format", "json"])
    assert js.exit_code == 0, js.stdout
    payload = json.loads(js.stdout)
    assert payload["fingerprint_diff"]["fingerprint"][0].startswith("aaaaaaaa")
    assert payload["fingerprint_diff"]["fingerprint"][1].startswith("bbbbbbbb")
    assert payload["fingerprint_diff"]["payload_changed_keys"] == {"k": {"a": 1, "b": 2}}


def test_run_compare_artifact_diff(home: Path) -> None:
    _seed_run(
        home,
        plugin_id="demo",
        run_id=RUN_A,
        key_date=date(2026, 5, 24),
        fingerprint="f",
        payload={"k": 1},
        artifacts=[("summary.md", "v1")],
    )
    _seed_run(
        home,
        plugin_id="demo",
        run_id=RUN_B,
        key_date=date(2026, 5, 24),
        fingerprint="f",
        payload={"k": 1},
        artifacts=[("summary.md", "v2")],
    )
    runner = CliRunner()
    result = runner.invoke(app, ["run", "compare", RUN_A, RUN_B, "--format", "json"])
    assert result.exit_code == 0, result.stdout
    payload = json.loads(result.stdout)
    arts = {a["name"]: a for a in payload["artifacts"]}
    assert arts["summary.md"]["match"] is False
    assert arts["summary.md"]["a"]["sha256"] != arts["summary.md"]["b"]["sha256"]


def test_run_compare_llm_call_cache_hit(home: Path) -> None:
    """B reuses A's cache — match should be True (same prompt_hash and
    final_prompt_hash + matching validation_status semantics)."""
    for run_id in (RUN_A, RUN_B):
        _seed_run(
            home,
            plugin_id="demo",
            run_id=run_id,
            key_date=date(2026, 5, 24),
            fingerprint="f",
            payload={"k": 1},
        )
    call_id_a = _seed_llm_call(
        home,
        plugin_id="demo",
        run_id=RUN_A,
        stage="screening",
        model="deepseek-chat",
        prompt_hash="p" * 64,
        validation_status="ok",
    )
    # B's call is the cached audit row — same prompt_hash, validation_status='cached'.
    _seed_llm_call(
        home,
        plugin_id="demo",
        run_id=RUN_B,
        stage="screening",
        model="deepseek-chat",
        prompt_hash="p" * 64,
        validation_status="cached",
        cache_hit=True,
        source_call_id=call_id_a,
    )
    runner = CliRunner()
    result = runner.invoke(app, ["run", "compare", RUN_A, RUN_B, "--format", "json"])
    assert result.exit_code == 0, result.stdout
    payload = json.loads(result.stdout)
    calls = payload["llm_calls"]
    assert len(calls) == 1
    assert calls[0]["a"]["cache_hit"] is False
    assert calls[0]["b"]["cache_hit"] is True
    # validation_status differs → match is False, even though prompt hashes line up.
    assert calls[0]["match"] is False


def test_run_compare_missing_run_exits_2(home: Path) -> None:
    runner = CliRunner()
    result = runner.invoke(app, ["run", "compare", RUN_A, RUN_B])
    assert result.exit_code == 2
    assert "未找到" in result.stdout
