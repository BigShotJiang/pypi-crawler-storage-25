"""v0.13 — ``deeptrade db llm-cache`` CLI tests.

The cache itself is populated through ``ReplayCacheStore.store()`` (the
same path ``LLMClient.complete_json`` takes); we wire a small helper
here to seed it directly rather than driving a full ``complete_json``
roundtrip — tests for that flow live in ``test_llm_client_replay.py``.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta
from pathlib import Path

import pytest
from typer.testing import CliRunner

from deeptrade.cli import app
from deeptrade.core.db import Database
from deeptrade.core.llm_replay import ReplayCacheStore
from deeptrade.plugins_api import StageProfile

PROFILE = StageProfile(
    thinking=False,
    reasoning_effort="low",
    temperature=0.1,
    max_output_tokens=2048,
)


@pytest.fixture
def home(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> Path:
    monkeypatch.setenv("DEEPTRADE_HOME", str(tmp_path))
    runner = CliRunner()
    result = runner.invoke(app, ["init", "--no-prompts"])
    assert result.exit_code == 0, result.stdout
    return tmp_path


def _seed_cache(
    home: Path,
    *,
    plugin_id: str = "demo",
    stage: str = "screening",
    user: str = "rank these",
    schema_version: str = "v1",
    response_dict: dict | None = None,
) -> str:
    """Seed one cache row. Returns the cache_key (full 64-hex string)."""
    from deeptrade.core.fingerprint import hash_text

    db = Database(home / "deeptrade.duckdb")
    try:
        store = ReplayCacheStore(db)
        cache_key, fingerprint = store.make_cache_key(
            plugin_id=plugin_id,
            stage=stage,
            provider="deepseek",
            model="deepseek-chat",
            system_sha256=hash_text("system"),
            user_sha256=hash_text(user),
            profile=PROFILE,
            schema_name="MySchema",
            schema_version=schema_version,
            input_fingerprint="fp1",
        )
        store.store(
            cache_key=cache_key,
            plugin_id=plugin_id,
            stage=stage,
            provider="deepseek",
            model="deepseek-chat",
            prompt_hash="p" * 64,
            profile=PROFILE,
            schema_name="MySchema",
            schema_version=schema_version,
            input_fingerprint="fp1",
            request_fingerprint=fingerprint,
            response_dict=response_dict or {"candidates": ["A", "B"]},
            response_meta={
                "input_tokens": 100,
                "output_tokens": 50,
                "latency_ms": 800,
                "attempt_count": 1,
            },
            source_run_id="00000000-0000-0000-0000-0000000000a1",
            source_call_id="00000000-0000-0000-0000-0000000000c1",
        )
    finally:
        db.close()
    return cache_key


def _backdate(home: Path, cache_key: str, days_ago: int) -> None:
    db = Database(home / "deeptrade.duckdb")
    try:
        db.execute(
            "UPDATE llm_replay_cache SET created_at = ? WHERE cache_key = ?",
            (datetime.now() - timedelta(days=days_ago), cache_key),
        )
    finally:
        db.close()


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------


def test_list_empty(home: Path) -> None:
    runner = CliRunner()
    result = runner.invoke(app, ["db", "llm-cache", "list"])
    assert result.exit_code == 0, result.stdout
    assert "no cache entries match" in result.stdout


def test_list_json_format(home: Path) -> None:
    key = _seed_cache(home, plugin_id="alpha", stage="screening")
    runner = CliRunner()
    result = runner.invoke(app, ["db", "llm-cache", "list", "--format", "json"])
    assert result.exit_code == 0, result.stdout
    rows = json.loads(result.stdout)
    assert len(rows) == 1
    assert rows[0]["cache_key"] == key
    assert rows[0]["plugin_id"] == "alpha"
    assert rows[0]["stage"] == "screening"


def test_list_filters_by_plugin(home: Path) -> None:
    _seed_cache(home, plugin_id="alpha")
    _seed_cache(home, plugin_id="beta")
    runner = CliRunner()
    result = runner.invoke(
        app, ["db", "llm-cache", "list", "--plugin", "alpha", "--format", "json"]
    )
    assert result.exit_code == 0, result.stdout
    rows = json.loads(result.stdout)
    assert [r["plugin_id"] for r in rows] == ["alpha"]


def test_list_filters_by_stage(home: Path) -> None:
    _seed_cache(home, stage="screening")
    _seed_cache(home, stage="prediction", user="another")
    runner = CliRunner()
    result = runner.invoke(
        app, ["db", "llm-cache", "list", "--stage", "prediction", "--format", "json"]
    )
    assert result.exit_code == 0, result.stdout
    rows = json.loads(result.stdout)
    assert [r["stage"] for r in rows] == ["prediction"]


# ---------------------------------------------------------------------------
# purge
# ---------------------------------------------------------------------------


def test_purge_requires_filter(home: Path) -> None:
    _seed_cache(home)
    runner = CliRunner()
    result = runner.invoke(app, ["db", "llm-cache", "purge", "--yes"])
    assert result.exit_code == 2
    assert "至少提供一个过滤器" in result.stdout


def test_purge_requires_yes_flag(home: Path) -> None:
    _seed_cache(home)
    runner = CliRunner()
    result = runner.invoke(app, ["db", "llm-cache", "purge", "--plugin", "demo"])
    assert result.exit_code == 2
    assert "--yes" in result.stdout


def test_purge_by_plugin(home: Path) -> None:
    _seed_cache(home, plugin_id="alpha")
    _seed_cache(home, plugin_id="beta")
    runner = CliRunner()
    result = runner.invoke(app, ["db", "llm-cache", "purge", "--plugin", "alpha", "--yes"])
    assert result.exit_code == 0, result.stdout
    assert "purged 1" in result.stdout

    # The beta row survives.
    rows = json.loads(runner.invoke(app, ["db", "llm-cache", "list", "--format", "json"]).stdout)
    assert [r["plugin_id"] for r in rows] == ["beta"]


def test_purge_by_before_days(home: Path) -> None:
    fresh = _seed_cache(home, plugin_id="alpha", user="new")
    stale = _seed_cache(home, plugin_id="alpha", user="old")
    _backdate(home, stale, days_ago=10)

    runner = CliRunner()
    result = runner.invoke(app, ["db", "llm-cache", "purge", "--before", "7", "--yes"])
    assert result.exit_code == 0, result.stdout
    assert "purged 1" in result.stdout

    rows = json.loads(runner.invoke(app, ["db", "llm-cache", "list", "--format", "json"]).stdout)
    keys = {r["cache_key"] for r in rows}
    assert fresh in keys
    assert stale not in keys


# ---------------------------------------------------------------------------
# inspect
# ---------------------------------------------------------------------------


def test_inspect_full_key_json(home: Path) -> None:
    key = _seed_cache(home, plugin_id="alpha", stage="screening")
    runner = CliRunner()
    result = runner.invoke(app, ["db", "llm-cache", "inspect", key, "--format", "json"])
    assert result.exit_code == 0, result.stdout
    payload = json.loads(result.stdout)
    assert payload["cache_key"] == key
    assert payload["plugin_id"] == "alpha"
    assert payload["stage"] == "screening"
    assert payload["response"] == {"candidates": ["A", "B"]}
    assert payload["response_meta"]["input_tokens"] == 100


def test_inspect_prefix_unique(home: Path) -> None:
    key = _seed_cache(home)
    runner = CliRunner()
    result = runner.invoke(app, ["db", "llm-cache", "inspect", key[:12], "--format", "json"])
    assert result.exit_code == 0, result.stdout
    payload = json.loads(result.stdout)
    assert payload["cache_key"] == key


def test_inspect_no_match(home: Path) -> None:
    runner = CliRunner()
    result = runner.invoke(app, ["db", "llm-cache", "inspect", "deadbeef"])
    assert result.exit_code == 2
    assert "未找到" in result.stdout


def test_inspect_ambiguous_prefix(home: Path) -> None:
    """Seed two cache rows that share a prefix and verify the CLI refuses
    to pick. The seeded rows have controlled distinct cache_keys here."""
    db = Database(home / "deeptrade.duckdb")
    try:
        from deeptrade.core.fingerprint import canonical_json

        for suffix in ("aaaa", "bbbb"):
            db.execute(
                "INSERT INTO llm_replay_cache("
                "cache_key, plugin_id, stage, provider, model, prompt_hash, "
                "profile_json, schema_name, schema_version, "
                "request_fingerprint_json, response_json, response_meta_json"
                ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    "shared12" + suffix * 14,  # all share prefix "shared12"
                    "demo",
                    "screening",
                    "p",
                    "m",
                    "ph",
                    canonical_json({}),
                    "S",
                    "v1",
                    canonical_json({}),
                    canonical_json({}),
                    canonical_json({}),
                ),
            )
    finally:
        db.close()
    runner = CliRunner()
    result = runner.invoke(app, ["db", "llm-cache", "inspect", "shared12"])
    assert result.exit_code == 2
    assert "命中多条" in result.stdout
    assert result.stdout.count("shared12") >= 3  # the message + each candidate


def test_inspect_truncates_long_response_by_default(home: Path) -> None:
    """A response payload >200 chars should render truncated unless --full."""
    long_text = "x" * 500
    key = _seed_cache(home, response_dict={"text": long_text})
    runner = CliRunner()
    result = runner.invoke(app, ["db", "llm-cache", "inspect", key, "--format", "json"])
    assert result.exit_code == 0, result.stdout
    payload = json.loads(result.stdout)
    assert payload["response"]["text"].endswith("…")
    assert len(payload["response"]["text"]) <= 201  # 200 + ellipsis

    full = runner.invoke(app, ["db", "llm-cache", "inspect", key, "--full", "--format", "json"])
    full_payload = json.loads(full.stdout)
    assert full_payload["response"]["text"] == long_text
