"""Ensure the project version is consistent across the three places it appears.

v0.10 M5 — CHANGELOG history shows multiple releases where ``__init__.py`` and
``pyproject.toml`` drifted (the wheel uploaded with a stale filename) and the
README badge stayed pinned to an old version. This test fails CI whenever any
of those three disagree so the release flow can't skip a sync step.
"""

from __future__ import annotations

import re
import tomllib
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[1]


def _pyproject_version() -> str:
    with (_REPO_ROOT / "pyproject.toml").open("rb") as fh:
        data = tomllib.load(fh)
    return str(data["project"]["version"])


def _init_version() -> str:
    text = (_REPO_ROOT / "deeptrade" / "__init__.py").read_text(encoding="utf-8")
    match = re.search(r'^__version__\s*=\s*[\'"]([^\'"]+)[\'"]', text, re.MULTILINE)
    assert match is not None, "__version__ not found in deeptrade/__init__.py"
    return match.group(1)


def _readme_badge_version() -> str:
    text = (_REPO_ROOT / "README.md").read_text(encoding="utf-8")
    match = re.search(r"version-([0-9][^-\s]*)-blue", text)
    assert match is not None, "version badge not found in README.md"
    return match.group(1)


def test_version_is_consistent_across_sources() -> None:
    pyproject = _pyproject_version()
    init = _init_version()
    badge = _readme_badge_version()
    assert pyproject == init, (
        f"pyproject.toml version {pyproject!r} != deeptrade/__init__.py __version__ "
        f"{init!r}; bump both together before tagging (see AGENTS.md release flow)."
    )
    assert pyproject == badge, (
        f"pyproject.toml version {pyproject!r} != README badge {badge!r}; "
        f"update the README badge as part of the release commit."
    )
