from __future__ import annotations

import hashlib
import json
import socket
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from .builtin import phase5_fixture_dataset
from .model import normalize_dataset


def _now_utc() -> str:
    return datetime.now(UTC).strftime("%Y-%m-%d %H:%M:%S UTC")


def _runtime_host() -> str:
    hostname = socket.gethostname()
    try:
        host_ip = socket.gethostbyname(hostname)
    except OSError:
        host_ip = "unresolved"
    return f"{hostname} ({host_ip})"


def _load_json(path: str) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _load_entries_jsonl(path: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        rows.append(json.loads(line))
    return rows


def _sha256_file(path: str) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while True:
            chunk = handle.read(65536)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def collect_fixture_phase5(name: str | None = None) -> dict[str, Any]:
    dataset = phase5_fixture_dataset()
    if name:
        dataset["dataset_name"] = name
    dataset["collected_at"] = _now_utc()
    return normalize_dataset(dataset)


def collect_from_json(path: str, name: str | None = None) -> dict[str, Any]:
    dataset = normalize_dataset(_load_json(path))
    if name:
        dataset["dataset_name"] = name
    if not dataset["collected_at"]:
        dataset["collected_at"] = _now_utc()
    return dataset


def collect_from_bundle_dir(path: str, name: str | None = None) -> dict[str, Any]:
    bundle = Path(path)
    metadata = _load_json(str(bundle / "metadata.json"))
    entries_path = bundle / "entries.json"
    if entries_path.exists():
        entries = _load_json(str(entries_path))
    else:
        entries = _load_entries_jsonl(str(bundle / "entries.jsonl"))

    dataset = {
        "dataset_name": name or metadata.get("dataset_name") or bundle.name,
        "dataset_kind": "bundle_dir",
        "collected_at": _now_utc(),
        "window": {
            "start": metadata.get("window_start", ""),
            "end": metadata.get("window_end", ""),
            "duration": metadata.get("duration", ""),
            "evidence_host": metadata.get("evidence_host", ""),
            "primary_actor": metadata.get("primary_actor", ""),
            "absolute_db_position_asc": metadata.get("absolute_db_position_asc", ""),
            "absolute_db_position_desc": metadata.get("absolute_db_position_desc", ""),
            "exclusion_note": metadata.get("exclusion_note", ""),
            "chain_route_status": metadata.get("chain_route_status", ""),
        },
        "surface_labels": _load_json(str(bundle / "surface_labels.json")) if (bundle / "surface_labels.json").exists() else [],
        "nis2_context": _load_json(str(bundle / "nis2_context.json")) if (bundle / "nis2_context.json").exists() else {},
        "time_source_status": _load_json(str(bundle / "time_source.json")) if (bundle / "time_source.json").exists() else {},
        "artifact_hashes": _load_json(str(bundle / "artifact_hashes.json")) if (bundle / "artifact_hashes.json").exists() else {},
        "entries": entries,
        "canonical_examples": _load_json(str(bundle / "canonical_examples.json")) if (bundle / "canonical_examples.json").exists() else [],
    }
    return normalize_dataset(dataset)


def collect_runtime_dataset(
    name: str,
    evidence_host: str | None,
    actor: str | None,
    window_start: str | None,
    window_end: str | None,
    duration: str | None,
    db_asc: str | None,
    db_desc: str | None,
    chain_route_status: str | None,
    exclusion_note: str | None,
    surface_labels: list[str],
    entry_json: str | None,
    entry_jsonl: str | None,
    artifact_paths: list[str],
    time_source_json: str | None,
    nis2_json: str | None,
    canonical_json: str | None,
) -> dict[str, Any]:
    entries: list[dict[str, Any]] = []
    if entry_json:
        entries = list(_load_json(entry_json))
    elif entry_jsonl:
        entries = _load_entries_jsonl(entry_jsonl)

    artifact_hashes = {path: _sha256_file(path) for path in artifact_paths}
    time_source = _load_json(time_source_json) if time_source_json else {
        "evidence_server": evidence_host or _runtime_host(),
        "evidence_server_ntp_synced": None,
        "primary_ordering_model": "TIBET causal / logical ordering",
        "causal_clock_note": (
            "TIBET ordering should be treated as the primary causal lane "
            "until stronger host clock evidence is supplied."
        ),
        "advisory": (
            "This dataset was collected without a dedicated time-source "
            "adapter payload. Supply --time-source-json for drift-aware output."
        ),
    }

    dataset = {
        "dataset_name": name,
        "dataset_kind": "runtime_collect",
        "collected_at": _now_utc(),
        "window": {
            "start": window_start or "",
            "end": window_end or "",
            "duration": duration or "",
            "evidence_host": evidence_host or _runtime_host(),
            "primary_actor": actor or "",
            "absolute_db_position_asc": db_asc or "",
            "absolute_db_position_desc": db_desc or "",
            "exclusion_note": exclusion_note or "",
            "chain_route_status": chain_route_status or "",
        },
        "surface_labels": surface_labels,
        "nis2_context": _load_json(nis2_json) if nis2_json else {},
        "time_source_status": time_source,
        "artifact_hashes": artifact_hashes,
        "entries": entries,
        "canonical_examples": _load_json(canonical_json) if canonical_json else [],
    }
    return normalize_dataset(dataset)
