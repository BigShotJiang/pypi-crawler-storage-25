from __future__ import annotations

import json

from tibet_bom.collect import collect_fixture_phase5, collect_runtime_dataset
from tibet_bom.fixtures import PHASE5_DB_BACKSOLVE
from tibet_bom.render import render_info, render_json
from tibet_bom.store import get_dataset, list_datasets, save_dataset


def _install_fixture_dataset(monkeypatch, tmp_path):
    monkeypatch.setenv("TIBET_BOM_HOME", str(tmp_path / "tibet-bom-home"))
    dataset = collect_fixture_phase5()
    save_dataset(dataset, set_active=True)
    return get_dataset()


def test_fixture_and_runtime_window_are_synced(monkeypatch, tmp_path) -> None:
    dataset = _install_fixture_dataset(monkeypatch, tmp_path)
    payload = json.loads(render_json(dataset))

    assert payload["window"]["absolute_db_position_asc"] == "407-423"
    assert payload["fixture"]["positions"]["absolute_db"]["ascending"] == "407-423"
    assert payload["fixture"]["window"]["end_utc"] == "2026-05-04T12:29:39.537104"
    assert len(payload["fixture"]["rows"]) == 17


def test_time_source_is_causality_first(monkeypatch, tmp_path) -> None:
    dataset = _install_fixture_dataset(monkeypatch, tmp_path)
    payload = json.loads(render_json(dataset))
    time_source = payload["time_source_status"]

    assert time_source["primary_ordering_model"] == "TIBET causal / logical ordering"
    assert "Lamport-like logical clock structure" in time_source["causal_clock_note"]
    assert "causal ordering" in time_source["advisory"]


def test_info_separates_runtime_from_evidence_host(monkeypatch, tmp_path) -> None:
    dataset = _install_fixture_dataset(monkeypatch, tmp_path)
    info = render_info(dataset)

    assert "Runtime:" in info
    assert "Evidence host:  P520 staging (10.0.100.2)" in info
    assert "192.168.4.85" not in info


def test_last_fixture_row_matches_final_phase5_event() -> None:
    last = PHASE5_DB_BACKSOLVE["rows"][-1]

    assert last["token_id"] == "b206bb78-b71b-4654-91fb-6baf605f0f42"
    assert last["pos_asc"] == 423
    assert last["pos_desc"] == 282
    assert last["created_at"] == "2026-05-04T12:29:39.537104"


def test_runtime_collect_can_store_custom_dataset(monkeypatch, tmp_path) -> None:
    monkeypatch.setenv("TIBET_BOM_HOME", str(tmp_path / "tibet-bom-home"))
    entries_file = tmp_path / "entries.json"
    entries_file.write_text(
        json.dumps(
            [
                {
                    "bom_id": "TIBET-BOM-900",
                    "view": "security_violation",
                    "position": 1,
                    "timestamp_utc": "2026-05-08 12:00:00 UTC",
                    "classification": "bewaken",
                    "endpoint": "/api/test",
                    "note": "Synthetic test event",
                }
            ]
        ),
        encoding="utf-8",
    )

    dataset = collect_runtime_dataset(
        name="runtime-test",
        evidence_host="lab-host",
        actor="127.0.0.1",
        window_start="2026-05-08 12:00:00 UTC",
        window_end="2026-05-08 12:00:01 UTC",
        duration="1 second",
        db_asc="1-1",
        db_desc="1-1",
        chain_route_status="manual",
        exclusion_note="none",
        surface_labels=["test surface"],
        entry_json=str(entries_file),
        entry_jsonl=None,
        artifact_paths=[],
        time_source_json=None,
        nis2_json=None,
        canonical_json=None,
    )
    save_dataset(dataset, set_active=True)
    active = get_dataset()
    names = [item["name"] for item in list_datasets()]

    assert active["dataset_name"] == "runtime-test"
    assert active["window"]["evidence_host"] == "lab-host"
    assert len(active["entries"]) == 1
    assert "runtime-test" in names
