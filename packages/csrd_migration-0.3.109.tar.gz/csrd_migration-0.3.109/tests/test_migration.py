"""Tests for csrd.migration — Migration dataclass and MigrationRunner."""

import pytest

from csrd.migration import Migration, MigrationRunner
from csrd.repository import SQLiteAdapter

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
async def adapter(tmp_path):
    """Provide a connected SQLiteAdapter backed by a temp file."""
    db_path = str(tmp_path / "test.db")
    adapter = SQLiteAdapter(db_path)
    await adapter.connect()
    yield adapter
    await adapter.close()


MIGRATIONS = [
    Migration(
        version="001",
        description="create users table",
        up="CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT NOT NULL)",
        down="DROP TABLE users",
    ),
    Migration(
        version="002",
        description="add email column",
        up="ALTER TABLE users ADD COLUMN email TEXT",
        down=(
            "CREATE TABLE users_backup (id INTEGER PRIMARY KEY, username TEXT NOT NULL);"
            "INSERT INTO users_backup SELECT id, username FROM users;"
            "DROP TABLE users;"
            "ALTER TABLE users_backup RENAME TO users;"
        ),
    ),
]


# ---------------------------------------------------------------------------
# Migration dataclass
# ---------------------------------------------------------------------------


class TestMigration:
    def test_frozen(self):
        m = Migration(version="001", description="test", up="SELECT 1", down="SELECT 1")
        with pytest.raises(AttributeError):
            m.version = "002"  # type: ignore[misc]

    def test_fields(self):
        m = Migration(version="001", description="test", up="UP", down="DOWN")
        assert m.version == "001"
        assert m.description == "test"
        assert m.up == "UP"
        assert m.down == "DOWN"


# ---------------------------------------------------------------------------
# MigrationRunner
# ---------------------------------------------------------------------------


class TestMigrationRunner:
    async def test_apply_all_creates_table_and_applies(self, adapter):
        runner = MigrationRunner()
        applied = await runner.apply_all(adapter, MIGRATIONS)

        assert len(applied) == 2
        assert applied[0].version == "001"
        assert applied[1].version == "002"

        # Verify the users table was actually created with both columns
        row = await adapter.fetch_one(
            "SELECT sql FROM sqlite_master WHERE type='table' AND name='users'"
        )
        assert row is not None
        assert "email" in row["sql"]

    async def test_apply_all_is_idempotent(self, adapter):
        runner = MigrationRunner()
        first = await runner.apply_all(adapter, MIGRATIONS)
        second = await runner.apply_all(adapter, MIGRATIONS)

        assert len(first) == 2
        assert len(second) == 0  # nothing new to apply

    async def test_apply_all_incremental(self, adapter):
        runner = MigrationRunner()

        # Apply only first migration
        applied1 = await runner.apply_all(adapter, MIGRATIONS[:1])
        assert len(applied1) == 1

        # Now apply both — only second should be new
        applied2 = await runner.apply_all(adapter, MIGRATIONS)
        assert len(applied2) == 1
        assert applied2[0].version == "002"

    async def test_current_version_empty(self, adapter):
        runner = MigrationRunner()
        version = await runner.current_version(adapter)
        assert version is None

    async def test_current_version_after_apply(self, adapter):
        runner = MigrationRunner()
        await runner.apply_all(adapter, MIGRATIONS)
        version = await runner.current_version(adapter)
        assert version == "002"

    async def test_current_version_partial(self, adapter):
        runner = MigrationRunner()
        await runner.apply_all(adapter, MIGRATIONS[:1])
        version = await runner.current_version(adapter)
        assert version == "001"

    async def test_pending_all(self, adapter):
        runner = MigrationRunner()
        pending = await runner.pending(adapter, MIGRATIONS)
        assert len(pending) == 2

    async def test_pending_after_apply(self, adapter):
        runner = MigrationRunner()
        await runner.apply_all(adapter, MIGRATIONS[:1])
        pending = await runner.pending(adapter, MIGRATIONS)
        assert len(pending) == 1
        assert pending[0].version == "002"

    async def test_pending_none(self, adapter):
        runner = MigrationRunner()
        await runner.apply_all(adapter, MIGRATIONS)
        pending = await runner.pending(adapter, MIGRATIONS)
        assert len(pending) == 0

    async def test_tracking_table_records(self, adapter):
        runner = MigrationRunner()
        await runner.apply_all(adapter, MIGRATIONS)

        rows = await adapter.fetch_all(
            "SELECT version, description FROM _csrd_migrations ORDER BY version"
        )
        assert len(rows) == 2
        assert rows[0]["version"] == "001"
        assert rows[0]["description"] == "create users table"
        assert rows[1]["version"] == "002"
        assert rows[1]["description"] == "add email column"

    async def test_empty_migration_list(self, adapter):
        runner = MigrationRunner()
        applied = await runner.apply_all(adapter, [])
        assert applied == []
        assert await runner.current_version(adapter) is None

    async def test_rollback_all(self, adapter):
        runner = MigrationRunner()
        await runner.apply_all(adapter, MIGRATIONS)
        assert await runner.current_version(adapter) == "002"

        rolled_back = await runner.rollback(adapter, MIGRATIONS)
        assert len(rolled_back) == 2
        # Rolled back in reverse order: 002 first, then 001
        assert rolled_back[0].version == "002"
        assert rolled_back[1].version == "001"
        assert await runner.current_version(adapter) is None

    async def test_rollback_to_version(self, adapter):
        runner = MigrationRunner()
        await runner.apply_all(adapter, MIGRATIONS)

        rolled_back = await runner.rollback(adapter, MIGRATIONS, to_version="001")
        assert len(rolled_back) == 1
        assert rolled_back[0].version == "002"
        assert await runner.current_version(adapter) == "001"

    async def test_rollback_nothing_applied(self, adapter):
        runner = MigrationRunner()
        rolled_back = await runner.rollback(adapter, MIGRATIONS)
        assert rolled_back == []

    async def test_reapply_all(self, adapter):
        runner = MigrationRunner()
        await runner.apply_all(adapter, MIGRATIONS)

        # Insert data to prove tables exist
        await adapter.execute(
            "INSERT INTO users (id, username, email) VALUES (1, 'alice', 'a@b.com')"
        )

        reapplied = await runner.reapply_all(adapter, MIGRATIONS)
        assert len(reapplied) == 2
        assert await runner.current_version(adapter) == "002"

        # Table was recreated — data is gone but schema is fresh
        rows = await adapter.fetch_all("SELECT * FROM users")
        assert len(rows) == 0

    async def test_reapply_on_fresh_db(self, adapter):
        runner = MigrationRunner()
        reapplied = await runner.reapply_all(adapter, MIGRATIONS)
        assert len(reapplied) == 2
        assert await runner.current_version(adapter) == "002"

    async def test_rollback_then_apply_incremental(self, adapter):
        runner = MigrationRunner()
        await runner.apply_all(adapter, MIGRATIONS)

        # Roll back to 001, then re-apply — only 002 should be applied
        await runner.rollback(adapter, MIGRATIONS, to_version="001")
        applied = await runner.apply_all(adapter, MIGRATIONS)
        assert len(applied) == 1
        assert applied[0].version == "002"
