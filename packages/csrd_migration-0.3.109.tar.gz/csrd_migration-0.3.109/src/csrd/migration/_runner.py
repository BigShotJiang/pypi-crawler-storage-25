"""Migration runner — applies and tracks schema migrations."""

import logging

from csrd.repository import ABCDatabaseAdapter

from ._migration import Migration

logger = logging.getLogger(__name__)

_MIGRATIONS_TABLE = "_csrd_migrations"

_CREATE_TABLE_SQL = f"""
CREATE TABLE IF NOT EXISTS {_MIGRATIONS_TABLE} (
    version  VARCHAR(255) PRIMARY KEY,
    description TEXT NOT NULL,
    applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
)
"""


class MigrationRunner:
    """Apply and track versioned schema migrations.

    The runner creates a ``_csrd_migrations`` tracking table automatically.
    Already-applied migrations are skipped (idempotent).

    Usage::

        runner = MigrationRunner()
        await runner.apply_all(adapter, migrations)
    """

    async def _ensure_table(self, adapter: ABCDatabaseAdapter) -> None:
        """Create the migrations tracking table if it doesn't exist."""
        await adapter.execute(_CREATE_TABLE_SQL)

    async def _applied_versions(self, adapter: ABCDatabaseAdapter) -> set[str]:
        """Return the set of already-applied migration versions."""
        rows = await adapter.fetch_all(f"SELECT version FROM {_MIGRATIONS_TABLE}")
        return {row["version"] for row in rows}

    @staticmethod
    async def _execute_sql(adapter: ABCDatabaseAdapter, sql: str) -> None:
        """Execute SQL that may contain multiple semicolon-separated statements."""
        for statement in sql.split(";"):
            statement = statement.strip()
            if statement:
                await adapter.execute(statement)

    async def apply_all(
        self,
        adapter: ABCDatabaseAdapter,
        migrations: list[Migration],
    ) -> list[Migration]:
        """Apply all pending migrations in list order.

        Returns the list of migrations that were actually applied
        (empty if everything was already up-to-date).
        """
        await self._ensure_table(adapter)
        applied = await self._applied_versions(adapter)

        newly_applied: list[Migration] = []
        for migration in migrations:
            if migration.version in applied:
                continue
            await self._execute_sql(adapter, migration.up)
            await adapter.insert(
                _MIGRATIONS_TABLE,
                {"version": migration.version, "description": migration.description},
            )
            newly_applied.append(migration)
            logger.info(
                "Applied migration %s: %s",
                migration.version,
                migration.description,
            )

        return newly_applied

    async def rollback(
        self,
        adapter: ABCDatabaseAdapter,
        migrations: list[Migration],
        *,
        to_version: str | None = None,
    ) -> list[Migration]:
        """Roll back applied migrations in reverse order.

        Parameters
        ----------
        adapter:
            The database adapter to execute ``down`` SQL against.
        migrations:
            The full ordered migration list (needed to find ``down`` SQL).
        to_version:
            Roll back until this version is the current version.
            Pass ``None`` to roll back **all** applied migrations.

        Returns the list of migrations that were actually rolled back.
        """
        await self._ensure_table(adapter)
        applied = await self._applied_versions(adapter)

        # Build lookup from version to migration
        by_version = {m.version: m for m in migrations}

        # Sort applied versions descending so we undo newest first
        to_rollback = sorted(applied, reverse=True)

        rolled_back: list[Migration] = []
        for version in to_rollback:
            if to_version is not None and version <= to_version:
                break
            migration = by_version.get(version)
            if migration is None:
                logger.warning(
                    "Migration %s is recorded as applied but not in the "
                    "provided migration list — skipping rollback",
                    version,
                )
                continue
            await self._execute_sql(adapter, migration.down)
            await adapter.execute(
                f"DELETE FROM {_MIGRATIONS_TABLE} WHERE version = :version",
                {"version": version},
            )
            rolled_back.append(migration)
            logger.info(
                "Rolled back migration %s: %s",
                migration.version,
                migration.description,
            )

        return rolled_back

    async def reapply_all(
        self,
        adapter: ABCDatabaseAdapter,
        migrations: list[Migration],
    ) -> list[Migration]:
        """Roll back all migrations then re-apply them.

        This is a non-destructive schema reset: tables are dropped and
        recreated via the ``down`` / ``up`` SQL in each migration.
        User data in those tables **will** be lost, but the database
        volume itself is preserved (no ``docker compose down -v`` needed).

        Returns the list of freshly applied migrations.
        """
        await self.rollback(adapter, migrations)
        return await self.apply_all(adapter, migrations)

    async def current_version(
        self,
        adapter: ABCDatabaseAdapter,
    ) -> str | None:
        """Return the latest applied migration version, or ``None``."""
        await self._ensure_table(adapter)
        row = await adapter.fetch_one(
            f"SELECT version FROM {_MIGRATIONS_TABLE} ORDER BY version DESC LIMIT 1"
        )
        return row["version"] if row else None

    async def pending(
        self,
        adapter: ABCDatabaseAdapter,
        migrations: list[Migration],
    ) -> list[Migration]:
        """Return migrations not yet applied, preserving list order."""
        await self._ensure_table(adapter)
        applied = await self._applied_versions(adapter)
        return [m for m in migrations if m.version not in applied]
