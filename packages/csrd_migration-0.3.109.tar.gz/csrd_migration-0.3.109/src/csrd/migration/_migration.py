"""Frozen dataclass representing a single versioned schema change."""

from dataclasses import dataclass


@dataclass(frozen=True)
class Migration:
    """A single versioned database schema change.

    Migrations are applied in list order by :class:`MigrationRunner`.
    Each migration must have a unique ``version`` string.

    Parameters
    ----------
    version
        Unique version identifier (e.g. ``"001"``, ``"002"``).
        Compared lexicographically — use zero-padded numbers.
    description
        Human-readable description of the change.
    up
        SQL statement(s) to apply the migration.
    down
        SQL statement(s) to revert the migration.
    """

    version: str
    description: str
    up: str
    down: str
