# Package metadata
__version__ = "0.1.1"
__author__ = "Predrag Mandic <predrag@nul.one>"
