import click
from click import ClickException

from . import __version__
from .prompt import run_prompt

@click.group()
@click.version_option(version=__version__, prog_name="rawai")
@click.option(
    "--debug",
    "-d",
    default=None,
    help=f"enable debug",
)
@click.pass_context
def cli(ctx, debug):
    """
    rawai - Recursive Agent Workflow for AI
    """
    ctx.ensure_object(dict)

@cli.command("run")
@click.pass_context
def run(ctx):
    """
    run prompt mode
    """
    run_prompt()


