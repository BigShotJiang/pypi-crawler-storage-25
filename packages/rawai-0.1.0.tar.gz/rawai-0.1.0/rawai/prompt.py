from prompt_toolkit import prompt

def run_prompt():
    while True:
        answer = prompt('Give me some input: ')
        print('You said: %s' % answer)
        if answer.strip().lower() == "q":
            break

