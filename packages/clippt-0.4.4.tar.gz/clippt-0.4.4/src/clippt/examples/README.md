## List of examples

- **clippt/presentation.toml** – A self-describing presentation

- **fibonacci/presentation.toml** – Vibe-coded implementation of the fibonacci series in many languages to show the syntax-highlighting features

- **fibonacci-inline.toml** – Version of the above, with all slides fully embedded in the configuration file.

- **data/presentation.toml** – Show a few data tables. 

- **run_presentation.py** – Example of how to run a presentation from a Python script.

- **execute_before.toml** – Example of how to execute code before a slide is displayed.
