import json
import logging
import re
import uuid
from pathlib import Path, PurePosixPath
from shlex import quote
from tempfile import gettempdir
from typing import Any, Callable, Union

from agi_cluster.agi_distributor import deployment_dask_support
from agi_env import AgiEnv


logger = logging.getLogger(__name__)

_REMOTE_RAPIDS_CHECK_EXCEPTIONS = (ConnectionError, OSError, RuntimeError)
_REMOTE_PLATFORM_PROBE_EXCEPTIONS = (OSError, RuntimeError, ValueError)
_REMOTE_COMMAND_EXCEPTIONS = (OSError, RuntimeError)
_LEGACY_INTEL_MACOS_DEPENDENCY_SPECS = ("numba==0.62.1", "pyarrow==17.0.0")
_SSHFS_INSTALL_HINT = (
    "sshfs is required to mount AGI_CLUSTER_SHARE on this worker. "
    "Install sshfs first: Debian/Ubuntu: sudo apt-get install -y sshfs; "
    "macOS: install macFUSE/FUSE-T SSHFS and ensure sshfs is visible to non-interactive SSH."
)
_SSHFS_OPTIONS = (
    "reconnect",
    "ServerAliveInterval=15",
    "ServerAliveCountMax=3",
    "BatchMode=yes",
    "StrictHostKeyChecking=yes",
    "noexec",
)
_REMOTE_PATH_PREFIX = 'export PATH="$HOME/.local/bin:/usr/local/bin:/opt/homebrew/bin:$PATH"; '


def _resolve_local_share_path(value: str, env: Any) -> Path:
    path = Path(value).expanduser()
    if path.is_absolute():
        return path.resolve(strict=False)
    home = getattr(env, "home_abs", None)
    base = Path(home).expanduser() if home else Path.home()
    return (base / path).resolve(strict=False)


def _remote_share_assignment(value: str) -> str:
    cleaned = value.strip() or "clustershare"
    if cleaned.startswith("~/"):
        return '"$HOME"/' + quote(cleaned[2:])
    if cleaned == "~":
        return '"$HOME"'
    if PurePosixPath(cleaned).is_absolute():
        return quote(cleaned)
    return '"$HOME"/' + quote(cleaned)


def _sshfs_options_args() -> str:
    return " ".join(f"-o {quote(option)}" for option in _SSHFS_OPTIONS)


def _remote_share_unmount_snippet() -> str:
    return (
        "if command -v fusermount3 >/dev/null 2>&1; then "
        "fusermount3 -u \"$REMOTE_CLUSTER_SHARE\" || true; "
        "elif command -v fusermount >/dev/null 2>&1; then "
        "fusermount -u \"$REMOTE_CLUSTER_SHARE\" || true; "
        "else umount \"$REMOTE_CLUSTER_SHARE\" || true; fi"
    )


def _home_relative_share_setting(value: str, env: Any) -> str:
    cleaned = str(value or "").strip() or "clustershare"
    normalized = cleaned.replace("\\", "/")

    for raw_home in (getattr(env, "home_abs", None), Path.home()):
        if not raw_home:
            continue
        try:
            home = Path(raw_home).expanduser().resolve(strict=False)
            candidate = Path(cleaned).expanduser()
            if candidate.is_absolute():
                relative = candidate.resolve(strict=False).relative_to(home)
                if relative.parts:
                    return relative.as_posix()
        except (OSError, RuntimeError, TypeError, ValueError):
            continue

    home_match = re.match(r"^(?:[A-Za-z]:)?/(?:Users|home)/[^/]+/(.+)$", normalized)
    if home_match:
        return home_match.group(1)
    return cleaned


def _scheduler_host_from_state(agi_cls: Any) -> str:
    raw_host = getattr(agi_cls, "_scheduler_ip", None) or getattr(agi_cls, "_scheduler", None) or ""
    host = str(raw_host).strip()
    if host.startswith("tcp://"):
        host = host.removeprefix("tcp://")
    if "@" in host:
        host = host.rsplit("@", 1)[-1]
    if host.startswith("[") and "]" in host:
        return host[1:].split("]", 1)[0]
    if host.count(":") == 1:
        host = host.rsplit(":", 1)[0]
    return host


def _scheduler_ssh_target(agi_cls: Any, env: Any) -> str:
    host = _scheduler_host_from_state(agi_cls)
    if not host:
        return ""
    user = str(getattr(env, "user", "") or "").strip()
    return f"{user}@{host}" if user else host


def _remote_env_update_command(remote_share: str) -> str:
    line = f"AGI_CLUSTER_SHARE={remote_share!r}"
    return f"mkdir -p \"$HOME/.agilab\" && printf '%s\\n' {quote(line)} > \"$HOME/.agilab/.env\""


def _remote_share_mount_command(
    *,
    scheduler_target: str,
    local_share: Path,
    remote_share: str,
) -> str:
    source = f"{scheduler_target}:{local_share.as_posix()}"
    sshfs_options = _sshfs_options_args()
    unmount_snippet = _remote_share_unmount_snippet()
    return (
        _REMOTE_PATH_PREFIX
        + "set -e; "
        "mkdir -p \"$HOME/.agilab\"; "
        "if ! command -v sshfs >/dev/null 2>&1; then "
        f"printf '%s\\n' {quote(_SSHFS_INSTALL_HINT)} >&2; exit 70; "
        "fi; "
        "REMOTE_CLUSTER_SHARE="
        + _remote_share_assignment(remote_share)
        + "; "
        f"SCHEDULER_CLUSTER_SHARE={quote(source)}; "
        "mkdir -p \"$REMOTE_CLUSTER_SHARE\"; "
        "MOUNT_LINE=$(mount | grep -F -- \"$REMOTE_CLUSTER_SHARE\" || true); "
        "if [ -n \"$MOUNT_LINE\" ]; then "
        "if printf '%s\\n' \"$MOUNT_LINE\" | grep -F -- \"$SCHEDULER_CLUSTER_SHARE\" >/dev/null 2>&1 "
        "&& test -d \"$REMOTE_CLUSTER_SHARE\" && test -w \"$REMOTE_CLUSTER_SHARE\"; then "
        "echo \"already mounted: $REMOTE_CLUSTER_SHARE\"; "
        "else "
        "echo \"stale, unexpected, or unwritable SSHFS mount: $REMOTE_CLUSTER_SHARE; remounting\" >&2; "
        + unmount_snippet
        + "; "
        f"sshfs \"$SCHEDULER_CLUSTER_SHARE\" \"$REMOTE_CLUSTER_SHARE\" {sshfs_options}; "
        "fi; "
        "else "
        f"sshfs \"$SCHEDULER_CLUSTER_SHARE\" \"$REMOTE_CLUSTER_SHARE\" {sshfs_options}; "
        "fi; "
        "test -d \"$REMOTE_CLUSTER_SHARE\" && test -w \"$REMOTE_CLUSTER_SHARE\""
    )


async def _prepare_remote_cluster_share(
    agi_cls: Any,
    ip: str,
    env: Any,
    remote_share: str,
    *,
    log: Any = logger,
) -> None:
    local_share_raw = (
        str(getattr(env, "AGI_CLUSTER_SHARE", "") or "")
        or str(getattr(env, "envars", {}).get("AGI_CLUSTER_SHARE", "") if isinstance(getattr(env, "envars", None), dict) else "")
        or remote_share
    )
    local_share = _resolve_local_share_path(local_share_raw, env)
    local_share.mkdir(parents=True, exist_ok=True)

    scheduler_target = _scheduler_ssh_target(agi_cls, env)
    if not scheduler_target:
        raise RuntimeError("Cannot mount AGI_CLUSTER_SHARE on remote worker: scheduler host is unknown.")

    remote_share_setting = _home_relative_share_setting(remote_share, env)
    await agi_cls.exec_ssh(ip, _remote_env_update_command(remote_share_setting))
    mount_cmd = _remote_share_mount_command(
        scheduler_target=scheduler_target,
        local_share=local_share,
        remote_share=remote_share_setting,
    )
    if getattr(env, "verbose", 0) > 0:
        log.info("Mounting scheduler AGI_CLUSTER_SHARE on remote worker %s with SSHFS", ip)
    await agi_cls.exec_ssh(ip, mount_cmd)


def _parse_version_prefix(version: str) -> tuple[int, ...]:
    parts: list[int] = []
    for raw_part in version.strip().split("."):
        digits = ""
        for char in raw_part:
            if not char.isdigit():
                break
            digits += char
        if not digits:
            break
        parts.append(int(digits))
    return tuple(parts)


def _is_legacy_intel_macos(system: str, machine: str, product_version: str) -> bool:
    if system.strip().lower() != "darwin":
        return False
    if machine.strip().lower() not in {"x86_64", "amd64"}:
        return False

    version_parts = _parse_version_prefix(product_version)
    if len(version_parts) < 2:
        return False

    major, minor = version_parts[:2]
    return major == 10 and minor <= 15


def _remote_platform_probe_command() -> str:
    return (
        "printf '%s\\n' "
        '"$(uname -s 2>/dev/null || true)" '
        '"$(uname -m 2>/dev/null || true)" '
        '"$(sw_vers -productVersion 2>/dev/null || true)"'
    )


def _parse_remote_platform_probe(output: str) -> tuple[str, str, str]:
    lines = [line.strip() for line in output.splitlines()]
    padded = (lines + ["", "", ""])[:3]
    return padded[0], padded[1], padded[2]


def _remote_rapids_probe_command(uv: str, pyvers: str, cli: PurePosixPath | Path) -> str:
    return f"{uv} run --no-sync -p {quote(str(pyvers))} python {quote(cli.as_posix())} rapids-probe"


def _parse_remote_rapids_probe(output: str) -> bool:
    for raw_line in reversed(output.splitlines()):
        line = raw_line.strip()
        if not line:
            continue
        start = line.find("{")
        end = line.rfind("}")
        if start < 0 or end < start:
            continue
        try:
            payload = json.loads(line[start : end + 1])
        except json.JSONDecodeError:
            continue
        if not isinstance(payload, dict):
            continue
        return bool(payload.get("rapids_capable"))
    raise ValueError(f"Remote RAPIDS probe did not return JSON: {output!r}")


async def _remote_rapids_capability(
    agi_cls: Any,
    ip: str,
    *,
    uv: str,
    pyvers: str,
    cli: PurePosixPath | Path,
) -> bool:
    result = await agi_cls.exec_ssh(ip, _remote_rapids_probe_command(uv, pyvers, cli))
    return _parse_remote_rapids_probe(result)


async def _legacy_intel_macos_dependency_specs(agi_cls: Any, ip: str, *, log: Any = logger) -> tuple[str, ...]:
    try:
        probe = await agi_cls.exec_ssh(ip, _remote_platform_probe_command())
    except ConnectionError:
        raise
    except _REMOTE_PLATFORM_PROBE_EXCEPTIONS as exc:
        log.warning("Could not probe remote worker platform on %s; skipping legacy macOS pins: %s", ip, exc)
        return ()

    system, machine, product_version = _parse_remote_platform_probe(probe)
    if not _is_legacy_intel_macos(system, machine, product_version):
        return ()

    log.warning(
        "Detected legacy Intel macOS worker %s (%s %s); pre-pinning worker dependencies: %s",
        ip,
        machine,
        product_version,
        ", ".join(_LEGACY_INTEL_MACOS_DEPENDENCY_SPECS),
    )
    return _LEGACY_INTEL_MACOS_DEPENDENCY_SPECS


async def _remote_project_has_pip(agi_cls: Any, ip: str, *, uv: str, wenv_rel: Path, pyvers: str) -> bool:
    try:
        await agi_cls.exec_ssh(
            ip,
            f'{uv} --project {wenv_rel.as_posix()} run -p {pyvers} python -c "import pip"',
        )
    except ConnectionError:
        raise
    except _REMOTE_COMMAND_EXCEPTIONS:
        return False
    return True


def _latest_artifact_match(root: Path, pattern: str) -> Path | None:
    matches = sorted(root.glob(pattern), key=lambda candidate: candidate.name)
    if not matches:
        return None
    return max(matches, key=lambda candidate: (candidate.stat().st_mtime_ns, candidate.name))


async def deploy_remote_worker(
    agi_cls: Any,
    ip: str,
    env: Any,
    wenv_rel: Path,
    option: str,
    *,
    worker_site_packages_dir_fn: Callable[..., Path | PurePosixPath],
    staged_uv_sources_pth_content_fn: Callable[..., str],
    set_env_var_fn: Callable[..., Any] = AgiEnv.set_env_var,
    log: Any = logger,
) -> None:
    """Install packages and bootstrap a remote worker environment."""

    del option

    wenv_rel = env.wenv_rel
    dist_abs = env.dist_abs
    pyvers = env.pyvers_worker
    cmd_prefix = env.envars.get(f"{ip}_CMD_PREFIX", "")
    uv = cmd_prefix + env.uv_worker

    if agi_cls._workers_data_path:
        await _prepare_remote_cluster_share(
            agi_cls,
            ip,
            env,
            str(agi_cls._workers_data_path),
            log=log,
        )

    if env.is_source_env:
        egg_file = _latest_artifact_match(dist_abs, f"{env.target_worker}*.egg")
        if egg_file is None:
            egg_file = _latest_artifact_match(dist_abs, f"{env.app}*.egg")
        if egg_file is None:
            log.error(f"searching for {dist_abs / env.target_worker}*.egg or {dist_abs / env.app}*.egg")
            raise FileNotFoundError(f"no existing egg file in {dist_abs / env.target_worker}* or {dist_abs / env.app}*")

        wenv = env.agi_env / "dist"
        env_whl = _latest_artifact_match(wenv, "agi_env*.whl")
        if env_whl is None:
            raise FileNotFoundError(f"no existing whl file in {wenv / 'agi_env*'}")

        wenv = env.agi_node / "dist"
        node_whl = _latest_artifact_match(wenv, "agi_node*.whl")
        if node_whl is None:
            raise FileNotFoundError(f"no existing whl file in {wenv / 'agi_node*'}")

        dist_remote = wenv_rel / "dist"
        log.info(f"mkdir {dist_remote}")
        await agi_cls.exec_ssh(ip, f"mkdir -p '{dist_remote}'")
        await agi_cls.send_files(env, ip, [egg_file], wenv_rel)
        await agi_cls.send_files(env, ip, [node_whl, env_whl], dist_remote)
    else:
        egg_file = _latest_artifact_match(dist_abs, f"{env.target_worker}*.egg")
        if egg_file is None:
            egg_file = _latest_artifact_match(dist_abs, f"{env.app}*.egg")
        if egg_file is None:
            log.error(f"searching for {dist_abs / env.target_worker}*.egg or {dist_abs / env.app}*.egg")
            raise FileNotFoundError(f"no existing egg file in {dist_abs / env.target_worker}* or {dist_abs / env.app}*")

        await agi_cls.send_files(env, ip, [egg_file], wenv_rel)
        env_whl = None
        node_whl = None

    hw_rapids_capable = False
    cli = env.wenv_rel.parent / "cli.py"
    if agi_cls._rapids_enabled:
        try:
            hw_rapids_capable = await _remote_rapids_capability(
                agi_cls,
                ip,
                uv=uv,
                pyvers=pyvers,
                cli=cli,
            )
        except _REMOTE_RAPIDS_CHECK_EXCEPTIONS:
            log.error(f"rapids is requested but not supported by node [{ip}]")
            raise

        env.hw_rapids_capable = hw_rapids_capable
        if hw_rapids_capable:
            set_env_var_fn(ip, "hw_rapids_capable")
        else:
            set_env_var_fn(ip, "no_rapids_hw")
        log.info(f"Rapids-capable GPU[{ip}]: {hw_rapids_capable}")

    cmd = f"{uv} run -p {pyvers} python  {cli.as_posix()} unzip {wenv_rel.as_posix()}"
    await agi_cls.exec_ssh(ip, cmd)

    if await _remote_project_has_pip(agi_cls, ip, uv=uv, wenv_rel=wenv_rel, pyvers=pyvers):
        log.info("[%s] pip is already available in %s; skipping ensurepip.", ip, wenv_rel.as_posix())
    else:
        cmd = f"{uv} --project {wenv_rel.as_posix()} run -p {pyvers} python -m ensurepip"
        await agi_cls.exec_ssh(ip, cmd)

    compatibility_specs = await _legacy_intel_macos_dependency_specs(agi_cls, ip, log=log)
    if compatibility_specs:
        quoted_specs = " ".join(quote(spec) for spec in compatibility_specs)
        cmd = f"{uv} --project {wenv_rel.as_posix()} add -p {pyvers} {quoted_specs}"
        await agi_cls.exec_ssh(ip, cmd)

    if env.is_source_env:
        if env_whl is None or node_whl is None:
            raise RuntimeError("source environment remote deployment requires local agi-env and agi-node wheels")
        env_pck: Union[str, Path] = wenv_rel / "dist" / env_whl.name
        node_pck: Union[str, Path] = wenv_rel / "dist" / node_whl.name
    else:
        env_pck = "agi-env"
        node_pck = "agi-node"

    def _pkg_ref(pkg: Union[str, Path]) -> str:
        return pkg.as_posix() if isinstance(pkg, Path) else str(pkg)

    core_package_refs = " ".join(quote(_pkg_ref(pkg)) for pkg in (env_pck, node_pck))
    cmd = f"{uv} --project {wenv_rel.as_posix()} add -p {pyvers} --upgrade {core_package_refs}"
    await agi_cls.exec_ssh(ip, cmd)

    if deployment_dask_support.dask_mode_enabled(agi_cls):
        cmd = deployment_dask_support.dask_runtime_install_command(
            uv,
            PurePosixPath(wenv_rel.as_posix()),
            pyvers=pyvers,
        )
        await agi_cls.exec_ssh(ip, cmd)

    remote_site_packages = worker_site_packages_dir_fn(
        PurePosixPath(wenv_rel.as_posix()),
        pyvers,
        windows=False,
    )
    remote_uv_sources = PurePosixPath(wenv_rel.as_posix()) / "_uv_sources"
    pth_content = staged_uv_sources_pth_content_fn(remote_site_packages, remote_uv_sources)
    tmp_pth = Path(gettempdir()) / f"agilab_uv_sources_{uuid.uuid4().hex}.pth"
    tmp_pth.write_text(pth_content, encoding="utf-8")
    try:
        await agi_cls.exec_ssh(ip, f"mkdir -p '{remote_site_packages.as_posix()}'")
        await agi_cls.send_file(
            env,
            ip,
            tmp_pth,
            remote_site_packages / "agilab_uv_sources.pth",
        )
    finally:
        try:
            tmp_pth.unlink()
        except FileNotFoundError:
            pass

    cmd = f"{uv} --project {wenv_rel.as_posix()}  run --no-sync -p {pyvers} python {cli.as_posix()} unzip {wenv_rel.as_posix()}"
    await agi_cls.exec_ssh(ip, cmd)

    cmd = (
        f"{uv} --project {wenv_rel.as_posix()} run --no-sync -p {pyvers} python -m "
        f"{env.post_install_rel} {wenv_rel.stem}"
    )
    await agi_cls.exec_ssh(ip, cmd)

    if env.verbose > 1:
        cmd = (
            f"{uv} --project '{wenv_rel.as_posix()}' run --no-sync -p {pyvers} python -m "
            f"agi_node.agi_dispatcher.build  --app-path  '{wenv_rel.as_posix()}' build_ext -b '{wenv_rel.as_posix()}'"
        )
    else:
        cmd = (
            f"{uv} --project '{wenv_rel.as_posix()}' run --no-sync -p {pyvers} python -m "
            f"agi_node.agi_dispatcher.build --app-path '{wenv_rel.as_posix()}' -q build_ext -b '{wenv_rel.as_posix()}'"
        )
    await agi_cls.exec_ssh(ip, cmd)
