import logging
from types import TracebackType
from typing import Any, Self

import httpx
from httpx import HTTPError

from snakestack.httpx.exceptions import RequestHTTPError
from snakestack.httpx.model import SnakeHttpResponse

logger = logging.getLogger(__name__)


class SnakeHttpClient:

    def __init__(
        self: Self,
        base_url: str,
        verify_ssl: bool = True,
    ) -> None:
        self._base_url = base_url
        self.client = httpx.AsyncClient(
            base_url=base_url,
            verify=verify_ssl,
        )

    async def handle(
        self: Self,
        method: str,
        url: str,
        content: str | bytes | None = None,
        data: dict[str, Any] | None = None,
        files: dict[str, Any] | None = None,
        json: Any | None = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        cookies: dict[str, str] | None = None,
        auth: Any | None = None,
        follow_redirects: bool = False,
        timeout: float | httpx.Timeout | None = None,
        extensions: dict[str, Any] | None = None,
    ) -> SnakeHttpResponse:
        try:
            response = await self.client.request(
                method=method,
                url=url,
                content=content,
                data=data,
                files=files,
                json=json,
                params=params,
                headers=headers,
                cookies=cookies,
                auth=auth,
                follow_redirects=follow_redirects,
                timeout=timeout,
                extensions=extensions,
            )
            response.raise_for_status()

            return SnakeHttpResponse(
                status_code=response.status_code,
                data=self._parse_body(response),
                headers=dict(response.headers),
                raw=response,
            )
        except HTTPError as error:
            exc = RequestHTTPError(api=f"{self._base_url}{url}", original_exception=error)
            logger.debug("Request failed %s", exc.get_details().model_dump_json())
            raise exc

    def _parse_body(self: Self, response: httpx.Response) -> Any:
        try:
            return response.json()
        except Exception:
            return response.text

    async def __aenter__(self: Self) -> Self:
        return self

    async def __aexit__(
        self: Self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self.client.aclose()
