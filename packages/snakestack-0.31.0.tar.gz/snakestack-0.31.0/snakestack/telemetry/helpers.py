import inspect
from functools import wraps
from typing import Any, Callable, TypeVar, cast

try:
    from opentelemetry import trace
    from opentelemetry.trace import SpanKind
except ImportError:
    raise RuntimeError("Telemetry extra is not installed. Run `pip install snakestack[telemetry]`.")

from snakestack.telemetry.decorators import managed_span

F = TypeVar("F", bound=Callable[..., Any])


def get_current_span() -> trace.Span:
    return trace.get_current_span()


def get_tracer(name: str, version: str = "1.0.0") -> trace.Tracer:
    return trace.get_tracer(name, version)


def set_span_attributes(span: trace.Span | None = None, **kwargs: Any) -> None:
    if span is None:
        span = trace.get_current_span()

    processed: dict[str, Any] = {}
    for key, value in kwargs.items():
        if value is None:
            processed[key] = "null"
        elif isinstance(value, (bool, str, bytes, int, float)):
            processed[key] = value
        elif isinstance(value, (list, tuple)):
            processed[key] = [str(i) if i is not None else "null" for i in value]
        else:
            processed[key] = str(value)

    span.set_attributes(processed)


def instrumented_span(span_name: str, kind: SpanKind = SpanKind.INTERNAL) -> Callable[[F], F]:
    def decorator(func: F) -> F:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            with managed_span(span_name, kind):
                return func(*args, **kwargs)

        @wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            with managed_span(span_name, kind):
                return await func(*args, **kwargs)

        if inspect.iscoroutinefunction(func):
            return cast(F, async_wrapper)
        return cast(F, wrapper)

    return decorator
