from contextlib import contextmanager
from typing import Generator

try:
    from opentelemetry import trace
    from opentelemetry.trace import Span, SpanKind, Status, StatusCode
except ImportError:
    raise RuntimeError("Telemetry extra is not installed. Run `pip install snakestack[telemetry]`.")


@contextmanager
def managed_span(name: str, kind: SpanKind) -> Generator[Span, None, None]:
    tracer = trace.get_tracer(__name__)
    with tracer.start_as_current_span(name, kind=kind) as span:
        try:
            yield span
            span.set_status(Status(StatusCode.OK))
        except Exception as e:
            span.record_exception(e)
            span.set_status(Status(StatusCode.ERROR))
            raise
