from enum import Enum, StrEnum


class LogLevel(int, Enum):
    CRITICAL = 50
    ERROR = 40
    WARNING = 30
    INFO = 20
    DEBUG = 10
    NOT_SET = 0


class LogFormatter(StrEnum):
    DEFAULT = "default"
    JSON = "json"
    WITH_REQUEST_ID = "with_request_id"


class LogFilters(StrEnum):
    REQUEST_ID = "request_id"
    EXCLUDED_NAME = "excluded_name"
    PATH_FILTER = "path_filter"
