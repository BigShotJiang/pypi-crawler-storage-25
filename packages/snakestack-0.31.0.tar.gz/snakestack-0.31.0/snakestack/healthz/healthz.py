import inspect
import logging
import socket
import time
from datetime import UTC, datetime
from typing import Awaitable, Callable, Self

from .model import CheckModel, HealthCheckModel, PingModel

logger = logging.getLogger(__name__)


class SnakeHealthCheck:

    UPTIME_DIR = "/proc/uptime"

    def __init__(
        self: Self,
        service_name: str,
        service_version: str,
        service_environment: str,
    ) -> None:
        self._checks: dict[str, Callable[[], bool | Awaitable[bool]]] = {}
        self._service_name = service_name
        self._service_version = service_version
        self._service_environment = service_environment

    async def ping(self: Self) -> PingModel:
        return PingModel(
            name=self._service_name,
            version=self._service_version,
        )

    async def is_healthy(self: Self) -> HealthCheckModel:
        result: dict[str, CheckModel] = {}
        timestamp = datetime.now(UTC).isoformat()
        uptime = self._uptime()

        checks: list[bool] = []
        for name, check_fn in self._checks.items():
            start_check = time.perf_counter()
            ok, error = await self._safe_call(fn=check_fn)
            latency = round((time.perf_counter() - start_check) * 1000, 2)

            result[name] = CheckModel(
                ok=ok,
                latency_ms=latency,
                error=error or None,
            )
            checks.append(ok)

        all_ok = bool(checks) and all(checks)

        total_latency = sum(dep.latency_ms for dep in result.values())
        return HealthCheckModel(
            service_name=self._service_name,
            version=self._service_version,
            environment=self._service_environment,
            host=socket.gethostname(),
            timestamp=timestamp,
            uptime=uptime,
            status=all_ok,
            latency_ms=total_latency,
            details=result,
        )

    async def _safe_call(
        self: Self, fn: Callable[[], bool | Awaitable[bool]]
    ) -> tuple[bool, str | None]:
        try:
            if inspect.iscoroutinefunction(fn):
                result = await fn()
            else:
                result = fn()
            return bool(result), None
        except Exception as error:
            logger.exception("Error on health check function", exc_info=error)
            return False, str(error)

    def add_check(self: Self, name: str, func: Callable[[], bool | Awaitable[bool]]) -> None:
        if name in self._checks:
            logger.warning("Health check '%s' is already registered and will be ignored.", name)
            return
        self._checks[name] = func

    def _uptime(self: Self) -> str | None:
        try:
            with open(self.UPTIME_DIR) as f:
                uptime_seconds = float(f.readline().split()[0])
                hours, remainder = divmod(int(uptime_seconds), 3600)
                minutes, seconds = divmod(remainder, 60)
                return f"{hours}h {minutes}m {seconds}s"
        except Exception:
            return None
