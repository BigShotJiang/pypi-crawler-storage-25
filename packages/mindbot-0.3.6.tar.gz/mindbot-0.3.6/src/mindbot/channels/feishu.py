"""Feishu/Lark channel implementation using lark-oapi SDK with WebSocket long connection."""

import asyncio
import json
import os
import re
import threading
from collections import OrderedDict
from pathlib import Path
from typing import Any

from loguru import logger

from mindbot.bus.events import OutboundMessage
from mindbot.bus.queue import MessageBus
from mindbot.channels.base import BaseChannel

try:
    import lark_oapi as lark
    from lark_oapi.api.im.v1 import (
        CreateFileRequest,
        CreateFileRequestBody,
        CreateImageRequest,
        CreateImageRequestBody,
        CreateMessageRequest,
        CreateMessageRequestBody,
        CreateMessageReactionRequest,
        CreateMessageReactionRequestBody,
        Emoji,
        P2ImMessageReceiveV1,
    )
    FEISHU_AVAILABLE = True
except ImportError:
    FEISHU_AVAILABLE = False
    lark = None
    Emoji = None
    CreateMessageRequest = None
    CreateMessageRequestBody = None
    CreateMessageReactionRequest = None
    CreateMessageReactionRequestBody = None
    P2ImMessageReceiveV1 = Any
    CreateFileRequest = None
    CreateFileRequestBody = None
    CreateImageRequest = None
    CreateImageRequestBody = None

# Message type display mapping
MSG_TYPE_MAP = {
    "image": "[image]",
    "audio": "[audio]",
    "file": "[file]",
    "sticker": "[sticker]",
}


def _extract_post_text(content_json: dict) -> str:
    """Extract plain text from Feishu post (rich text) message content.

    Supports two formats:
    1. Direct format: {"title": "...", "content": [...]}
    2. Localized format: {"zh_cn": {"title": "...", "content": [...]}}
    """

    def extract_from_lang(lang_content: dict) -> str | None:
        if not isinstance(lang_content, dict):
            return None
        title = lang_content.get("title", "")
        content_blocks = lang_content.get("content", [])
        if not isinstance(content_blocks, list):
            return None
        text_parts = []
        if title:
            text_parts.append(title)
        for block in content_blocks:
            if not isinstance(block, list):
                continue
            for element in block:
                if isinstance(element, dict):
                    tag = element.get("tag")
                    if tag == "text":
                        text_parts.append(element.get("text", ""))
                    elif tag == "a":
                        text_parts.append(element.get("text", ""))
                    elif tag == "at":
                        text_parts.append(f"@{element.get('user_name', 'user')}")
        return " ".join(text_parts).strip() if text_parts else None

    # Try direct format first
    if "content" in content_json:
        result = extract_from_lang(content_json)
        if result:
            return result

    # Try localized format
    for lang_key in ("zh_cn", "en_us", "ja_jp"):
        lang_content = content_json.get(lang_key)
        result = extract_from_lang(lang_content)
        if result:
            return result

    return ""


class FeishuChannel(BaseChannel):
    """
    Feishu/Lark channel using WebSocket long connection.

    Uses WebSocket to receive events - no public IP or webhook required.

    Requires:
    - App ID and App Secret from Feishu Open Platform
    - Bot capability enabled
    - Event subscription enabled (im.message.receive_v1)
    """

    name = "feishu"

    def __init__(self, config: Any, bus: MessageBus):
        super().__init__(config, bus)
        self._client: Any = None
        self._ws_client: Any = None
        self._ws_thread: threading.Thread | None = None
        self._processed_message_ids: OrderedDict[str, None] = OrderedDict()  # Ordered dedup cache
        self._loop: asyncio.AbstractEventLoop | None = None

    async def start(self) -> None:
        """Start the Feishu bot with WebSocket long connection."""
        if not FEISHU_AVAILABLE:
            logger.error("Feishu SDK not installed. Run: pip install lark-oapi")
            return

        app_id = getattr(self.config, "app_id", None)
        app_secret = getattr(self.config, "app_secret", None)

        if not app_id or not app_secret:
            logger.error("Feishu app_id and app_secret not configured")
            return

        self._running = True
        self._loop = asyncio.get_running_loop()

        # Create Lark client for sending messages
        self._client = (
            lark.Client.builder()
            .app_id(app_id)
            .app_secret(app_secret)
            .log_level(lark.LogLevel.INFO)
            .build()
        )

        encrypt_key = getattr(self.config, "encrypt_key", "") or ""
        verification_token = getattr(self.config, "verification_token", "") or ""

        # Create event handler (only register message receive, ignore other events)
        event_handler = (
            lark.EventDispatcherHandler.builder(encrypt_key, verification_token)
            .register_p2_im_message_receive_v1(self._on_message_sync)
            .build()
        )

        # Create WebSocket client for long connection
        self._ws_client = lark.ws.Client(
            app_id,
            app_secret,
            event_handler=event_handler,
            log_level=lark.LogLevel.INFO,
        )

        # Start WebSocket client in a separate thread with its own event loop.
        # lark.ws.Client.start() uses a module-level `loop` that calls
        # run_until_complete(), so we must create a fresh loop in this thread
        # and patch the module variable before calling start().
        def run_ws():
            import lark_oapi.ws.client as _ws_mod

            ws_loop = asyncio.new_event_loop()
            asyncio.set_event_loop(ws_loop)
            _ws_mod.loop = ws_loop  # patch module-level loop

            while self._running:
                try:
                    logger.info("Feishu WebSocket connecting...")
                    self._ws_client.start()
                except Exception as e:
                    logger.error(f"Feishu WebSocket error: {e}")
                if self._running:
                    import time

                    logger.info("Reconnecting in 5 seconds...")
                    time.sleep(5)

            ws_loop.close()

        self._ws_thread = threading.Thread(target=run_ws, daemon=True)
        self._ws_thread.start()

        logger.info("Feishu bot started with WebSocket long connection")
        logger.info("No public IP required - using WebSocket to receive events")
        logger.info(f"App ID: {app_id}")

        # Keep running until stopped
        while self._running:
            await asyncio.sleep(1)

    async def stop(self) -> None:
        """Stop the Feishu bot."""
        self._running = False
        # Close the WebSocket connection directly; lark-oapi ws Client
        # has no stop() method.
        if self._ws_client and self._ws_client._conn:
            try:
                import lark_oapi.ws.client as _ws_mod
                ws_loop = _ws_mod.loop
                if ws_loop.is_running():
                    ws_loop.call_soon_threadsafe(
                        lambda: asyncio.ensure_future(self._ws_client._disconnect(), loop=ws_loop)
                    )
            except Exception as e:
                logger.warning(f"Error disconnecting Feishu WebSocket: {e}")
        logger.info("Feishu bot stopped")

    def _add_reaction_sync(self, message_id: str, emoji_type: str) -> None:
        """Sync helper for adding reaction (runs in thread pool)."""
        try:
            request = (
                CreateMessageReactionRequest.builder()
                .message_id(message_id)
                .request_body(
                    CreateMessageReactionRequestBody.builder()
                    .reaction_type(Emoji.builder().emoji_type(emoji_type).build())
                    .build()
                )
                .build()
            )

            response = self._client.im.v1.message_reaction.create(request)

            if not response.success():
                logger.warning(
                    f"Failed to add reaction: code={response.code}, msg={response.msg}"
                )
            else:
                logger.debug(f"Added {emoji_type} reaction to message {message_id}")
        except Exception as e:
            logger.warning(f"Error adding reaction: {e}")

    async def _add_reaction(self, message_id: str, emoji_type: str = "THUMBSUP") -> None:
        """
        Add a reaction emoji to a message (non-blocking).

        Common emoji types: THUMBSUP, OK, EYES, DONE, OnIt, HEART
        """
        if not self._client or not Emoji:
            return

        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, self._add_reaction_sync, message_id, emoji_type)

    # Regex to match markdown tables (header + separator + data rows)
    _TABLE_RE = re.compile(
        r"((?:^[ \t]*\|.+\|[ \t]*\n)(?:^[ \t]*\|[-:\s|]+\|[ \t]*\n)(?:^[ \t]*\|.+\|[ \t]*\n?)+)",
        re.MULTILINE,
    )

    _HEADING_RE = re.compile(r"^(#{1,6})\s+(.+)$", re.MULTILINE)

    _CODE_BLOCK_RE = re.compile(r"(```[\s\S]*?```)", re.MULTILINE)

    _IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".ico", ".tiff", ".tif"}
    _FILE_TYPE_MAP = {
        ".pdf": "pdf",
        ".doc": "doc",
        ".docx": "doc",
        ".xls": "xls",
        ".xlsx": "xls",
        ".ppt": "ppt",
        ".pptx": "ppt",
        ".mp4": "mp4",
        ".opus": "opus",
    }

    @staticmethod
    def _parse_md_table(table_text: str) -> dict | None:
        """Parse a markdown table into a Feishu table element."""
        lines = [l.strip() for l in table_text.strip().split("\n") if l.strip()]
        if len(lines) < 3:
            return None
        split = lambda l: [c.strip() for c in l.strip("|").split("|")]
        headers = split(lines[0])
        rows = [split(l) for l in lines[2:]]
        columns = [
            {"tag": "column", "name": f"c{i}", "display_name": h, "width": "auto"}
            for i, h in enumerate(headers)
        ]
        return {
            "tag": "table",
            "page_size": len(rows) + 1,
            "columns": columns,
            "rows": [
                {f"c{i}": r[i] if i < len(r) else "" for i in range(len(headers))}
                for r in rows
            ],
        }

    def _build_card_elements(self, content: str) -> list[dict]:
        """Split content into div/markdown + table elements for Feishu card."""
        elements, last_end = [], 0
        for m in self._TABLE_RE.finditer(content):
            before = content[last_end : m.start()]
            if before.strip():
                elements.extend(self._split_headings(before))
            elements.append(
                self._parse_md_table(m.group(1))
                or {"tag": "markdown", "content": m.group(1)}
            )
            last_end = m.end()
        remaining = content[last_end:]
        if remaining.strip():
            elements.extend(self._split_headings(remaining))
        return elements or [{"tag": "markdown", "content": content}]

    def _split_headings(self, content: str) -> list[dict]:
        """Split content by headings, converting headings to div elements."""
        protected = content
        code_blocks = []
        for m in self._CODE_BLOCK_RE.finditer(content):
            code_blocks.append(m.group(1))
            protected = protected.replace(
                m.group(1), f"\x00CODE{len(code_blocks) - 1}\x00", 1
            )

        elements = []
        last_end = 0
        for m in self._HEADING_RE.finditer(protected):
            before = protected[last_end : m.start()].strip()
            if before:
                elements.append({"tag": "markdown", "content": before})
            level = len(m.group(1))
            text = m.group(2).strip()
            elements.append(
                {
                    "tag": "div",
                    "text": {
                        "tag": "lark_md",
                        "content": f"**{text}**",
                    },
                }
            )
            last_end = m.end()
        remaining = protected[last_end:].strip()
        if remaining:
            elements.append({"tag": "markdown", "content": remaining})

        for i, cb in enumerate(code_blocks):
            for el in elements:
                if el.get("tag") == "markdown":
                    el["content"] = el["content"].replace(f"\x00CODE{i}\x00", cb)

        return elements or [{"tag": "markdown", "content": content}]

    @staticmethod
    def _resolve_receive_id_type(chat_id: str) -> str:
        """Infer Feishu receive_id_type from the outgoing chat identifier."""
        return "chat_id" if chat_id.startswith("oc_") else "open_id"

    @classmethod
    def _message_type_for_path(cls, file_path: str) -> str:
        """Map a local file path to the native Feishu outbound message type."""
        ext = Path(file_path).suffix.lower()
        return "image" if ext in cls._IMAGE_EXTS else "file"

    @classmethod
    def _file_type_for_upload(cls, file_path: str) -> str:
        """Map a file extension to Feishu upload file type."""
        ext = Path(file_path).suffix.lower()
        return cls._FILE_TYPE_MAP.get(ext, "stream")

    def _upload_image_sync(self, file_path: str) -> str | None:
        """Upload an image file and return its Feishu image key."""
        if not self._client or CreateImageRequest is None or CreateImageRequestBody is None:
            logger.warning("Feishu image upload is unavailable because the SDK is not fully initialized")
            return None

        try:
            with open(file_path, "rb") as file_obj:
                request = (
                    CreateImageRequest.builder()
                    .request_body(
                        CreateImageRequestBody.builder()
                        .image_type("message")
                        .image(file_obj)
                        .build()
                    )
                    .build()
                )
                response = self._client.im.v1.image.create(request)
        except Exception as exc:
            logger.error(f"Error uploading Feishu image {file_path}: {exc}")
            return None

        if not response.success():
            logger.error(
                f"Failed to upload Feishu image: code={response.code}, msg={response.msg}, "
                f"log_id={response.get_log_id()}"
            )
            return None

        return response.data.image_key

    def _upload_file_sync(self, file_path: str) -> str | None:
        """Upload a generic file and return its Feishu file key."""
        if not self._client or CreateFileRequest is None or CreateFileRequestBody is None:
            logger.warning("Feishu file upload is unavailable because the SDK is not fully initialized")
            return None

        file_name = os.path.basename(file_path)
        file_type = self._file_type_for_upload(file_path)

        try:
            with open(file_path, "rb") as file_obj:
                request = (
                    CreateFileRequest.builder()
                    .request_body(
                        CreateFileRequestBody.builder()
                        .file_type(file_type)
                        .file_name(file_name)
                        .file(file_obj)
                        .build()
                    )
                    .build()
                )
                response = self._client.im.v1.file.create(request)
        except Exception as exc:
            logger.error(f"Error uploading Feishu file {file_path}: {exc}")
            return None

        if not response.success():
            logger.error(
                f"Failed to upload Feishu file: code={response.code}, msg={response.msg}, "
                f"log_id={response.get_log_id()}"
            )
            return None

        return response.data.file_key

    def _send_message_sync(
        self,
        receive_id_type: str,
        receive_id: str,
        msg_type: str,
        content: str,
    ) -> bool:
        """Send a single Feishu message synchronously."""
        if not self._client or CreateMessageRequest is None or CreateMessageRequestBody is None:
            return False

        try:
            request = (
                CreateMessageRequest.builder()
                .receive_id_type(receive_id_type)
                .request_body(
                    CreateMessageRequestBody.builder()
                    .receive_id(receive_id)
                    .msg_type(msg_type)
                    .content(content)
                    .build()
                )
                .build()
            )
            response = self._client.im.v1.message.create(request)
        except Exception as exc:
            logger.error(f"Error sending Feishu {msg_type} message: {exc}")
            return False

        if not response.success():
            logger.error(
                f"Failed to send Feishu {msg_type} message: code={response.code}, msg={response.msg}, "
                f"log_id={response.get_log_id()}"
            )
            return False

        logger.debug(f"Feishu {msg_type} message sent to {receive_id}")
        return True

    async def _send_content_message(self, receive_id_type: str, msg: OutboundMessage) -> None:
        """Send the textual part of an outbound message as a Feishu card."""
        if not msg.content or not msg.content.strip():
            # Fallback: always send something so the user isn't left waiting
            card = {
                "config": {"wide_screen_mode": True},
                "elements": [{"tag": "markdown", "content": "（处理完成，无文本内容）"}],
            }
        else:
            card = {
                "config": {"wide_screen_mode": True},
                "elements": self._build_card_elements(msg.content),
            }

        card = {
            "config": {"wide_screen_mode": True},
            "elements": self._build_card_elements(msg.content),
        }
        content = json.dumps(card, ensure_ascii=False)
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(
            None,
            self._send_message_sync,
            receive_id_type,
            msg.chat_id,
            "interactive",
            content,
        )

    async def _send_media_attachment(self, receive_id_type: str, chat_id: str, file_path: str) -> None:
        """Upload a local attachment and send it as a native Feishu message."""
        candidate = Path(file_path).expanduser()
        if not candidate.is_file():
            logger.warning(f"Feishu attachment must be an existing local file: {file_path}")
            return

        message_type = self._message_type_for_path(str(candidate))
        loop = asyncio.get_running_loop()

        if message_type == "image":
            image_key = await loop.run_in_executor(None, self._upload_image_sync, str(candidate))
            if not image_key:
                return
            payload = json.dumps({"image_key": image_key}, ensure_ascii=False)
        else:
            file_key = await loop.run_in_executor(None, self._upload_file_sync, str(candidate))
            if not file_key:
                return
            payload = json.dumps({"file_key": file_key}, ensure_ascii=False)

        await loop.run_in_executor(
            None,
            self._send_message_sync,
            receive_id_type,
            chat_id,
            message_type,
            payload,
        )

    async def send(self, msg: OutboundMessage) -> None:
        """Send a message through Feishu."""
        if not self._client:
            logger.warning("Feishu client not initialized")
            return

        try:
            receive_id_type = self._resolve_receive_id_type(msg.chat_id)

            await self._send_content_message(receive_id_type, msg)

            for file_path in msg.media:
                await self._send_media_attachment(receive_id_type, msg.chat_id, file_path)

        except Exception as e:
            logger.error(f"Error sending Feishu message: {e}")

    def _on_message_sync(self, data: "P2ImMessageReceiveV1") -> None:
        """
        Sync handler for incoming messages (called from WebSocket thread).
        Schedules async handling in the main event loop.
        """
        logger.info(f"[Feishu WS] Received event via WebSocket: {data}")
        if self._loop and self._loop.is_running():
            asyncio.run_coroutine_threadsafe(self._on_message(data), self._loop)

    async def _on_message(self, data: "P2ImMessageReceiveV1") -> None:
        """Handle incoming message from Feishu."""
        try:
            logger.info("[Feishu] Processing message...")
            event = data.event
            message = event.message
            sender = event.sender

            # Deduplication check
            message_id = message.message_id
            if message_id in self._processed_message_ids:
                return
            self._processed_message_ids[message_id] = None

            # Trim cache: keep most recent 500 when exceeds 1000
            while len(self._processed_message_ids) > 1000:
                self._processed_message_ids.popitem(last=False)

            # Skip bot messages
            sender_type = sender.sender_type
            if sender_type == "bot":
                return

            sender_id = sender.sender_id.open_id if sender.sender_id else "unknown"
            chat_id = message.chat_id
            chat_type = message.chat_type  # "p2p" or "group"
            msg_type = message.message_type

            logger.info(
                f"[Feishu] Message: sender_id={sender_id}, chat_id={chat_id}, "
                f"chat_type={chat_type}, msg_type={msg_type}"
            )

            # Add reaction to indicate "seen"
            await self._add_reaction(message_id, "THUMBSUP")

            # Parse message content
            if msg_type == "text":
                try:
                    content = json.loads(message.content).get("text", "")
                except json.JSONDecodeError:
                    content = message.content or ""
            elif msg_type == "post":
                try:
                    content_json = json.loads(message.content)
                    content = _extract_post_text(content_json)
                except (json.JSONDecodeError, TypeError):
                    content = message.content or ""
            else:
                content = MSG_TYPE_MAP.get(msg_type, f"[{msg_type}]")

            if not content:
                logger.warning(f"[Feishu] Empty content, skipping message")
                return

            logger.info(f"[Feishu] Content: {content[:100]}...")

            # Forward to message bus
            reply_to = chat_id if chat_type == "group" else sender_id
            logger.info(f"[Feishu] Forwarding to message bus: reply_to={reply_to}")
            await self._handle_message(
                sender_id=sender_id,
                chat_id=reply_to,
                content=content,
                metadata={
                    "message_id": message_id,
                    "chat_type": chat_type,
                    "msg_type": msg_type,
                },
            )
            logger.info("[Feishu] Message forwarded to bus successfully")

        except Exception as e:
            logger.error(f"Error processing Feishu message: {e}")
