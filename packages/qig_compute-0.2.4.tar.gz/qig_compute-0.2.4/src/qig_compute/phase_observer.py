"""
Phase Observer — threshold-free coherence detection for bridge measurement.

Replaces the Hilbert-envelope amplitude cutoff (which makes the bridge
exponent protocol-dependent) with frequency-stability-based coherence
detection.

The observer declares decoherence when the instantaneous phase velocity
becomes erratic (std exceeds mean × threshold over a sliding window).
This is a global, preregistered rule — not tuned per run.

Bridge measurement stack:
  1. Phase observer detects coherence window
  2. Continuous phase accumulation counts cycles (not zero-crossings)
  3. Mean angular frequency from coherent phase velocity
  4. τ = phase_cycles / ω

Source: EXP-042 rerun analysis (2026-04-11).
Validated: bridge direction +1.29 (threshold-free) at L=4 h=3.0.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.signal import hilbert


@dataclass
class PhaseObserverResult:
    """Result of phase-observer bridge measurement."""
    coherent_cycles: float        # continuous phase cycles before decoherence
    omega_mean: float             # mean angular frequency in coherent window
    tau: float                    # coherent_cycles / omega_mean
    decoherence_time: float       # time when coherence was lost
    coherence_lost: bool          # True if decoherence detected before t_max
    phase_velocity_std: float     # std of phase velocity at decoherence
    n_total_steps: int
    n_coherent_steps: int


def phase_observe(
    signal: np.ndarray,
    dt: float,
    coherence_threshold: float = 2.0,
    window: int = 20,
    min_coherent_steps: int = 10,
) -> PhaseObserverResult:
    """Detect coherence window from phase stability, not amplitude.

    The observer rule is GLOBAL and PREREGISTERED:
      Decoherence = phase velocity std > coherence_threshold × |mean|
      over a sliding window of `window` steps.

    Args:
        signal: Time series (ΔX from ground state, or local energy)
        dt: Time step
        coherence_threshold: std/|mean| ratio that triggers decoherence (default 2.0)
        window: Sliding window size for coherence check (default 20 steps)
        min_coherent_steps: Minimum steps before checking coherence (default 10)

    Returns:
        PhaseObserverResult with coherent cycles, omega, tau, decoherence time
    """
    sig = signal - np.mean(signal)
    n = len(sig)

    if n < min_coherent_steps + window:
        return PhaseObserverResult(
            coherent_cycles=0, omega_mean=0, tau=0,
            decoherence_time=0, coherence_lost=False,
            phase_velocity_std=0, n_total_steps=n, n_coherent_steps=0,
        )

    # Hilbert analytic signal → unwrapped phase → instantaneous frequency
    analytic = hilbert(sig)
    phase = np.unwrap(np.angle(analytic))
    phase_vel = np.diff(phase) / dt  # instantaneous angular frequency

    # Sliding window coherence check
    decoherence_idx = len(phase_vel)
    coherence_lost = False
    final_std = 0.0

    for i in range(max(window, min_coherent_steps), len(phase_vel)):
        w = phase_vel[i - window:i]
        mean_w = abs(np.mean(w))
        std_w = np.std(w)

        if mean_w > 0.1 and std_w > coherence_threshold * mean_w:
            decoherence_idx = i
            coherence_lost = True
            final_std = float(std_w)
            break

    # Coherent phase accumulation
    coherent_phase = phase[:decoherence_idx + 1]
    total_cycles = abs(coherent_phase[-1] - coherent_phase[0]) / (2 * np.pi)

    # Mean angular frequency from coherent window
    omega_mean = abs(np.mean(phase_vel[:decoherence_idx])) if decoherence_idx > 0 else 0

    # Bridge timescale
    tau = total_cycles / omega_mean if omega_mean > 0 else 0

    return PhaseObserverResult(
        coherent_cycles=round(float(total_cycles), 4),
        omega_mean=round(float(omega_mean), 4),
        tau=round(float(tau), 6),
        decoherence_time=round(float(decoherence_idx * dt), 4),
        coherence_lost=coherence_lost,
        phase_velocity_std=round(float(final_std), 4),
        n_total_steps=n,
        n_coherent_steps=decoherence_idx,
    )


def bridge_exponent_phase(
    signals: dict[float, np.ndarray],
    dt: float,
    J_min: float = 1.5,
    coherence_threshold: float = 2.0,
    window: int = 20,
) -> tuple[float | None, float | None, dict]:
    """Compute bridge exponent from phase observer across J values.

    Args:
        signals: {J: signal_array} for each coupling value
        dt: time step
        J_min: minimum J for fit (exclude weak coupling)
        coherence_threshold: observer coherence threshold
        window: observer sliding window

    Returns:
        (exponent, R², per_J_results)
    """
    per_J = {}
    Js_fit = []
    taus_fit = []

    for J in sorted(signals.keys()):
        result = phase_observe(signals[J], dt, coherence_threshold, window)
        per_J[J] = {
            "cycles": result.coherent_cycles,
            "omega": result.omega_mean,
            "tau": result.tau,
            "decoherence_time": result.decoherence_time,
            "coherence_lost": result.coherence_lost,
        }

        if J >= J_min and result.tau > 0:
            Js_fit.append(J)
            taus_fit.append(result.tau)

    if len(Js_fit) < 3:
        return None, None, per_J

    Js = np.array(Js_fit)
    taus = np.array(taus_fit)
    coeffs = np.polyfit(np.log(Js), np.log(taus), 1)
    exponent = float(coeffs[0])

    # R²
    predicted = np.exp(np.polyval(coeffs, np.log(Js)))
    ss_res = np.sum((taus - predicted) ** 2)
    ss_tot = np.sum((taus - np.mean(taus)) ** 2)
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else 0

    return round(exponent, 4), round(float(r2), 6), per_J
