"""
OPT-001: Site-local QFI for ED wavefunctions.

Instead of computing the full N×N QFI matrix (N² inner products),
compute only the elements needed for curvature at a target site.

The metric tensor at site (r,c) uses F elements connecting that site
to its nearest neighbours. The Christoffel symbols use finite-difference
derivatives of the metric, requiring neighbours of neighbours (d≤2).

For the full curvature at one site, we need generators within d≤2 of
the target on the lattice. At L=5 (N=25): ~13 generators instead of 25.
At L=6 (N=36): ~13 instead of 36. Savings grow with L.

Physics support: screening law ξ=0.618 (frozen). Sites beyond d=3
contribute <5% to curvature at the target. d≤2 captures the metric
and its first derivatives.

Validated: must match full QFI extraction at L=3,4 before deployment.
"""

from __future__ import annotations

import numpy as np
from scipy.sparse import csr_matrix


def site_local_generators(
    target_site: int,
    L: int,
    Xs: list[csr_matrix],
    max_distance: int = 3,
    pbc: bool = True,
) -> tuple[list[int], list[csr_matrix]]:
    """Select generators within max_distance of target site.

    Args:
        target_site: ED flat index of the target site
        L: Lattice size (N = L²)
        Xs: Full list of N X-operators
        max_distance: Manhattan distance cutoff (default 2)
        pbc: Periodic boundary conditions

    Returns:
        (selected_indices, selected_generators): indices into Xs and the generators
    """
    N = L * L
    tr, tc = target_site // L, target_site % L

    selected = []
    for s in range(N):
        r, c = s // L, s % L
        if pbc:
            dr = min(abs(r - tr), L - abs(r - tr))
            dc = min(abs(c - tc), L - abs(c - tc))
        else:
            dr = abs(r - tr)
            dc = abs(c - tc)
        d = dr + dc
        if d <= max_distance:
            selected.append(s)

    return selected, [Xs[s] for s in selected]


def site_local_qfi(
    psi: np.ndarray,
    target_site: int,
    L: int,
    Xs: list[csr_matrix],
    max_distance: int = 3,
    pbc: bool = True,
) -> tuple[np.ndarray, list[int]]:
    """Compute QFI only for generators near the target site.

    Returns a smaller QFI matrix (n_local × n_local) and the
    mapping from local indices to global site indices.

    Args:
        psi: Dense ED wavefunction
        target_site: site to compute curvature at
        L: lattice size
        Xs: full list of X operators
        max_distance: generator cutoff (default 2)
        pbc: periodic boundary conditions

    Returns:
        (F_local, site_indices): local QFI and index mapping
    """
    indices, generators = site_local_generators(
        target_site, L, Xs, max_distance, pbc
    )

    n = len(generators)
    psi_col = psi.reshape(-1, 1)
    dpsis = [(-1j * (G @ psi_col)) for G in generators]
    projs = [(d.conj().T @ psi_col)[0, 0] for d in dpsis]

    F = np.zeros((n, n), dtype=float)
    for i in range(n):
        for j in range(i, n):
            inner = (dpsis[i].conj().T @ dpsis[j])[0, 0]
            term = inner - projs[i] * projs[j].conjugate()
            F[i, j] = 4.0 * float(np.real(term))
            F[j, i] = F[i, j]

    return F, indices


def site_local_curvature(
    psi: np.ndarray,
    target_site: int,
    L: int,
    J: float,
    h: float,
    Xs: list[csr_matrix],
    Zs: list[csr_matrix],
    max_distance: int = 3,
    pbc: bool = True,
) -> tuple[float, float]:
    """Compute dG and dT at target site using site-local QFI.

    This is the OPT-001 optimised version of compute_tensors + extract_dG_dT
    that only computes generators within max_distance of the target.

    Args:
        psi: perturbed wavefunction
        target_site: site to extract curvature at
        L, J, h: lattice parameters
        Xs, Zs: site operators
        max_distance: generator cutoff

    Returns:
        (trace_G, trace_T): Einstein tensor trace and stress-energy trace at target
    """
    from qigv.geometry.curvature import metric_tensor_from_qfi, ricci_tensor_2d, einstein_tensor_2d
    from qigv.geometry.stress_energy import stress_energy_tensor_2d_tfim

    N = L * L

    # Site-local QFI
    F_local, indices = site_local_qfi(psi, target_site, L, Xs, max_distance, pbc)

    # Embed into full N×N with Yukawa predicted fill for unmeasured sites
    from qig_compute.screening_pipeline import _embed_with_predicted_fill
    tr, tc = target_site // L, target_site % L
    distances = {}
    for s in range(N):
        r, c = s // L, s % L
        if pbc:
            dr = min(abs(r - tr), L - abs(r - tr))
            dc = min(abs(c - tc), L - abs(c - tc))
        else:
            dr, dc = abs(r - tr), abs(c - tc)
        distances[s] = dr + dc

    F_full = _embed_with_predicted_fill(
        F_local, indices, N, distances, target_site, 0.618
    )

    # Full curvature pipeline on the embedded QFI
    g = metric_tensor_from_qfi(F_full, L)
    R = ricci_tensor_2d(g)
    G = einstein_tensor_2d(R, g)

    # Stress-energy (always computed from full state, cheap)
    T = stress_energy_tensor_2d_tfim(psi, L, J, h, Xs, Zs)

    tr, tc = target_site // L, target_site % L
    trace_G = float(np.trace(G[tr, tc]))
    trace_T = float(np.trace(T[tr, tc]))

    return trace_G, trace_T
