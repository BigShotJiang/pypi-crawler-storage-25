"""
Prediction tracking — every shortcut produces a prediction.

Principle: If you didn't measure it, predict it. If you predicted it,
say so. When you later measure it, compare.

Every result carries three columns per observable:
  measured  — actual computed value (None if skipped)
  predicted — predicted value from physics (None if measured)
  source    — how the prediction was made

This keeps us honest when comparing and provides ease of mind for
external users. The prediction→measurement gap is trackable over time.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

import numpy as np


class MeasurementStatus(Enum):
    MEASURED = "measured"
    PREDICTED = "predicted"
    PENDING = "pending_verification"


@dataclass
class SiteResult:
    """Result at a single site with measurement/prediction tracking."""
    site: int
    row: int
    col: int
    distance: int
    region: str  # "measured" or "predicted"

    measured_value: float | None = None
    predicted_value: float | None = None
    prediction_source: str | None = None
    prediction_params: dict = field(default_factory=dict)

    verified: bool = False
    verification_error: float | None = None

    @property
    def status(self) -> MeasurementStatus:
        if self.measured_value is not None and self.predicted_value is not None:
            return MeasurementStatus.PENDING
        elif self.measured_value is not None:
            return MeasurementStatus.MEASURED
        elif self.predicted_value is not None:
            return MeasurementStatus.PREDICTED
        return MeasurementStatus.PENDING

    @property
    def value(self) -> float | None:
        """Best available value — measured if available, else predicted."""
        return self.measured_value if self.measured_value is not None else self.predicted_value

    def verify(self, actual: float) -> float:
        """Compare prediction with actual measurement. Returns error %."""
        if self.predicted_value is None:
            return 0.0
        self.measured_value = actual
        self.verified = True
        if self.predicted_value != 0:
            self.verification_error = abs(actual - self.predicted_value) / abs(self.predicted_value) * 100
        else:
            self.verification_error = abs(actual) * 100
        return self.verification_error


@dataclass
class PredictionReport:
    """Complete report with measured + predicted sites."""
    sites: list[SiteResult] = field(default_factory=list)
    fit_params: dict = field(default_factory=dict)
    constitutive_derivations: dict = field(default_factory=dict)

    @property
    def n_measured(self) -> int:
        return sum(1 for s in self.sites if s.measured_value is not None)

    @property
    def n_predicted(self) -> int:
        return sum(1 for s in self.sites if s.predicted_value is not None and s.measured_value is None)

    @property
    def n_verified(self) -> int:
        return sum(1 for s in self.sites if s.verified)

    @property
    def mean_prediction_error(self) -> float | None:
        errors = [s.verification_error for s in self.sites if s.verification_error is not None]
        return float(np.mean(errors)) if errors else None

    def format_table(self) -> str:
        """Format as a human-readable table."""
        lines = []
        lines.append(f"{'Site':>6s} {'d':>3s} {'Measured':>12s} {'Predicted':>12s} "
                     f"{'Source':>20s} {'Status':>10s} {'Error%':>8s}")
        lines.append("-" * 75)

        for s in sorted(self.sites, key=lambda x: (x.distance, x.site)):
            meas = f"{s.measured_value:.6f}" if s.measured_value is not None else "—"
            pred = f"{s.predicted_value:.6f}" if s.predicted_value is not None else "—"
            src = s.prediction_source or "—"
            status = s.status.value
            err = f"{s.verification_error:.2f}%" if s.verification_error is not None else "—"
            lines.append(f"{s.site:>6d} {s.distance:>3d} {meas:>12s} {pred:>12s} "
                        f"{src:>20s} {status:>10s} {err:>8s}")

        lines.append("-" * 75)
        lines.append(f"Measured: {self.n_measured}  Predicted: {self.n_predicted}  "
                     f"Verified: {self.n_verified}")
        if self.mean_prediction_error is not None:
            lines.append(f"Mean prediction error: {self.mean_prediction_error:.2f}%")

        if self.constitutive_derivations:
            lines.append(f"\nConstitutive Derivations (G = κT):")
            for key, val in self.constitutive_derivations.items():
                lines.append(f"  {key}: {val}")

        return "\n".join(lines)

    def to_dict(self) -> dict:
        """Serialise for JSON output."""
        return {
            "sites": [
                {
                    "site": s.site, "row": s.row, "col": s.col,
                    "distance": s.distance, "region": s.region,
                    "measured": s.measured_value,
                    "predicted": s.predicted_value,
                    "prediction_source": s.prediction_source,
                    "prediction_params": s.prediction_params,
                    "status": s.status.value,
                    "verified": s.verified,
                    "verification_error_pct": s.verification_error,
                }
                for s in self.sites
            ],
            "summary": {
                "n_measured": self.n_measured,
                "n_predicted": self.n_predicted,
                "n_verified": self.n_verified,
                "mean_prediction_error_pct": self.mean_prediction_error,
            },
            "fit_params": self.fit_params,
            "constitutive_derivations": self.constitutive_derivations,
        }


def build_prediction_report(
    measured_sites: list[dict],
    all_sites: list[dict],
    fit_A: float,
    fit_xi: float,
    center_site: int,
    L: int,
) -> PredictionReport:
    """Build a prediction report from measured + unmeasured sites.

    Args:
        measured_sites: list of {"site": int, "row": int, "col": int,
                                  "distance": int, "value": float}
        all_sites: list of {"site": int, "row": int, "col": int,
                            "distance": int} for ALL sites including unmeasured
        fit_A: Yukawa amplitude from Gauss-Newton fit on measured shells
        fit_xi: Yukawa screening length from fit
        center_site: defect site index
        L: lattice size
    """
    measured_lookup = {s["site"]: s for s in measured_sites}
    report = PredictionReport(
        fit_params={"A": round(fit_A, 6), "xi": round(fit_xi, 6),
                    "center": center_site, "L": L},
    )

    for s in all_sites:
        site_id = s["site"]
        d = s["distance"]

        if site_id in measured_lookup:
            report.sites.append(SiteResult(
                site=site_id, row=s["row"], col=s["col"],
                distance=d, region="measured",
                measured_value=measured_lookup[site_id]["value"],
            ))
        else:
            predicted = fit_A * np.exp(-d / fit_xi) if fit_xi > 0 else 0.0
            report.sites.append(SiteResult(
                site=site_id, row=s["row"], col=s["col"],
                distance=d, region="predicted",
                predicted_value=round(predicted, 8),
                prediction_source=f"Yukawa: {fit_A:.4f}×exp(-d/{fit_xi:.4f})",
                prediction_params={"A": fit_A, "xi": fit_xi, "d": d},
            ))

    return report


def add_constitutive_derivation(
    report: PredictionReport,
    xi_T: float,
    xi_T_r2: float,
    ratio_at_reference_L: float,
    reference_L: int,
    kappa: float = 63.79,
) -> PredictionReport:
    """Add constitutive law derivation: ξ_G = ξ_T × (ξ_G/ξ_T ratio).

    Uses frozen G = κT to derive ξ_G from ξ_T when direct curvature
    extraction is numerically unstable.
    """
    xi_G_derived = xi_T * ratio_at_reference_L
    phi_inv = 2.0 / (1 + np.sqrt(5))
    error_vs_phi = abs(xi_G_derived - phi_inv) / phi_inv * 100

    report.constitutive_derivations = {
        "xi_T": round(xi_T, 6),
        "xi_T_R2": round(xi_T_r2, 6),
        "ratio_reference_L": reference_L,
        "ratio_value": round(ratio_at_reference_L, 6),
        "xi_G_derived": round(xi_G_derived, 6),
        "phi_inv": round(phi_inv, 6),
        "error_vs_phi_pct": round(error_vs_phi, 4),
        "kappa_used": kappa,
        "method": f"ξ_G = ξ_T × (ξ_G/ξ_T at L={reference_L}) via G=κT (R²>0.97)",
        "status": "DERIVED — pending direct curvature confirmation",
    }

    return report
