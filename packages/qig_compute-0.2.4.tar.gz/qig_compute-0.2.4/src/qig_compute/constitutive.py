"""
Constitutive derivation: G from T via G = κT.

When the curvature pipeline (QFI → metric → Christoffel → Ricci) is
numerically unstable (as at L=6), use the frozen constitutive law
to derive curvature quantities from stress-energy.

G = κT is the most frozen law in the programme (R² > 0.97, L=3-7).
If T is measured cleanly (MPS expectation values, always stable),
then G = κT gives curvature without touching the QFI pipeline.

Source: EXP-000 series, frozen fact, κ* = 63.79 ± 0.90.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


KAPPA_STAR = 63.79  # frozen constitutive constant
KAPPA_ERROR = 0.90  # ± error


@dataclass
class ConstitutiveResult:
    """Result of constitutive derivation at each site."""
    per_site: list[dict]
    xi_G_derived: float | None
    xi_T_direct: float | None
    ratio: float | None
    method: str
    kappa_used: float


def derive_dG_from_dT(
    T_base: np.ndarray,
    T_pert: np.ndarray,
    L: int,
    kappa: float = KAPPA_STAR,
    xi_ratio: float | None = None,
    ratio_reference_L: int | None = None,
    measure_sites: list[tuple] | None = None,
) -> ConstitutiveResult:
    """Derive dG at each site from dT via constitutive law.

    Args:
        T_base: Stress-energy tensor at base parameters (L, L, 2, 2)
        T_pert: Stress-energy tensor at perturbed parameters (L, L, 2, 2)
        L: Lattice size
        kappa: Constitutive constant (default: frozen κ* = 63.79)
        measure_sites: Optional list of (ed_idx, row, col, distance)

    Returns:
        ConstitutiveResult with per-site dG, dT, and screening fits
    """
    per_site = []

    if measure_sites is None:
        measure_sites = [
            (r * L + c, r, c, 0)
            for r in range(L) for c in range(L)
        ]

    for ed_idx, row, col, dist in measure_sites:
        dT = float(np.trace(T_pert[row, col]) - np.trace(T_base[row, col]))
        dG = kappa * dT  # G = κT → dG = κ × dT

        per_site.append({
            "row": row, "col": col, "distance": dist,
            "dT": round(dT, 8),
            "dG_constitutive": round(dG, 8),
            "source": "constitutive (G = κT)",
        })

    # Fit screening lengths from shell profiles
    by_dist_G = {}
    by_dist_T = {}
    for s in per_site:
        d = s["distance"]
        by_dist_G.setdefault(d, []).append(abs(s["dG_constitutive"]))
        by_dist_T.setdefault(d, []).append(abs(s["dT"]))

    xi_T = _fit_yukawa(by_dist_T)

    # dG = κ × dT → same decay rate → ξ_G_constitutive = ξ_T.
    # But the curvature pipeline (QFI→metric→Ricci) geometrically amplifies
    # the spatial profile, giving ξ_G_direct ≠ ξ_T. The ratio must be
    # MEASURED at a reference L where the curvature pipeline works, then
    # transferred. NOT hardcoded — that would be a hack.
    if xi_ratio is not None and xi_T is not None:
        xi_G_derived = xi_T * xi_ratio
        method = (f"ξ_G = ξ_T × {xi_ratio:.4f} (measured ratio from L={ratio_reference_L}). "
                  f"dG = κ×dT with κ = {kappa}. "
                  f"Ratio accounts for geometric amplification in curvature pipeline.")
    elif xi_T is not None:
        xi_G_derived = xi_T  # best we can do without ratio
        method = (f"ξ_G = ξ_T (no ratio provided — assumes curvature tracks stress-energy 1:1). "
                  f"This is a LOWER BOUND. Provide xi_ratio from a reference L for accuracy.")
    else:
        xi_G_derived = None
        method = "Insufficient data for screening length fit."

    return ConstitutiveResult(
        per_site=per_site,
        xi_G_derived=round(xi_G_derived, 6) if xi_G_derived else None,
        xi_T_direct=round(xi_T, 6) if xi_T else None,
        ratio=xi_ratio,
        method=method,
        kappa_used=kappa,
    )


def _fit_yukawa(by_dist: dict[int, list[float]]) -> float | None:
    """Fit Yukawa decay with Gauss-Newton refinement."""
    distances = sorted(d for d in by_dist if d >= 1)
    if len(distances) < 2:
        return None

    ds = np.array(distances, dtype=float)
    vals = np.array([float(np.mean(by_dist[d])) for d in distances])

    if np.any(vals <= 0):
        return None

    # Log-linear initial guess
    log_vals = np.log(vals)
    coeffs = np.polyfit(ds, log_vals, 1)
    if coeffs[0] >= 0:
        return None

    A = float(np.exp(coeffs[1]))
    xi = float(-1.0 / coeffs[0])

    # Gauss-Newton refinement
    for _ in range(10):
        pred = A * np.exp(-ds / xi)
        res = vals - pred
        J = np.column_stack([
            np.exp(-ds / xi),
            A * ds / xi**2 * np.exp(-ds / xi),
        ])
        try:
            delta = np.linalg.lstsq(J, res, rcond=None)[0]
            A += float(delta[0])
            xi += float(delta[1])
            if xi <= 0:
                xi = float(-1.0 / coeffs[0])
                break
        except np.linalg.LinAlgError:
            break

    return xi
