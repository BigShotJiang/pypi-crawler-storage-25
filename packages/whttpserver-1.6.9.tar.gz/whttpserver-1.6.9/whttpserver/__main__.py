# -*- coding: utf-8 -*-
from flask import Flask, request, send_from_directory, render_template, redirect, url_for, jsonify
import os
import argparse
import stat
import time
import sys
import json

app = Flask(__name__,
            template_folder=os.path.join(os.path.dirname(__file__), 'templates'))

# The default directory is the current directory when the command is started.
app.config['UPLOAD_FOLDER'] = os.path.abspath(os.path.dirname(__file__))

app.config['TEMPLATES_AUTO_RELOAD'] = True

# 增加最大文件大小限制
app.config['MAX_CONTENT_LENGTH'] = 1000 * 2000 * 1024 * 1024  # 2000GB

def get_file_owner(filepath):
    if sys.platform == "win32":
        return ""
    else:
        import pwd
        stat_info = os.stat(filepath)
        return pwd.getpwuid(stat_info.st_uid).pw_name

def get_filemode(st_mode):
    is_dir = 'd' if stat.S_ISDIR(st_mode) else '-'
    perm = ''
    for who in 'USR', 'GRP', 'OTH':
        for what in 'R', 'W', 'X':
            perm += what.lower() if st_mode & getattr(stat, 'S_I' + what + who) else '-'
    return is_dir + perm

def list_files(directory):
    try:
        return [{'name': f, 'is_dir': os.path.isdir(os.path.join(directory, f))} for f in os.listdir(directory)]
    except OSError:
        return []

def list_directory_contents(req_path, directory):
    entries = os.listdir(directory)
    directories = []
    files = []
    data = []

    for entry in entries:
        if entry.startswith('.'):
            continue
        path = os.path.join(directory, entry)
        stat_info = os.stat(path)
        permissions = get_filemode(stat_info.st_mode)
        owner = get_file_owner(path)
        group = stat_info.st_gid
        try:
            if sys.platform != "win32":
                group = ""
            else:
                import grp
                group = grp.getgrgid(stat_info.st_gid).gr_name
        except:
            print("Failed to get group name for gid: " + str(stat_info.st_gid))
        size = stat_info.st_size
        if size > 1024 * 1024 * 1024: 
            size = "%.2f GB" % (size/1024.0/1024.0/1024.0)
        elif size > 1024 * 1024:
            size = "%.2f MB" % (size/1024.0/1024.0)
        elif size > 1024:
            size = "%.2f KB" % (size/1024.0)
        else:
            size = "%.2f B" % (size)
        mtime = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(stat_info.st_mtime))
        
        href = ""
        file_type = "dir" if os.path.isdir(path) else "file"
        if file_type == "dir":
            directories.append((permissions, owner, group, size, mtime, entry, href))
            href = "/"+req_path+entry+"/"
        else:
            files.append((permissions, owner, group, size, mtime, entry, href))
            file_ext = entry.split('.')[-1].lower()
            if file_ext in ['html', 'txt', 'sh', 'scala', 'py', 'js', 'css', 'json', 'md', 'yml', 'yaml', 'ini','conf']:
                action = "edit"
            elif file_ext in ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg', 'ico', 'mp4', 'avi', 'mov', 'wmv', 'flv', 'webm', 'mkv', 'mp3', 'wav', 'flac', 'aac', 'ogg', 'wma']:
                action = "view"
            else:
                action = "download"
            href = "/"+action+"/"+req_path+entry
        
        data.append({
            'permissions': permissions,
            'owner': owner,
            'group': group,
            'size': size,
            'mtime': mtime,
            'name': entry,
            'href': href,
            'type': file_type
        })
    data.sort(key=lambda x: (x['type'] != 'dir', x['name']))
    return data

@app.route('/edit/<path:filename>', methods=['GET', 'POST'])
def edit_file(filename):
    abs_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    
    if request.method == 'POST':
        # save file
        new_content = request.form['content']
        with open(abs_path, 'w') as file:
            file.write(new_content)
        return redirect(url_for('dir_listing', req_path=os.path.dirname(filename)))
    
    # read file
    with open(abs_path, 'r') as file:
        content = file.read()
    
    return render_template('edit_file.html', filename=filename, content=content, parent_path="/"+os.path.dirname(filename))

@app.route('/', defaults={'req_path': ''})
@app.route('/<path:req_path>')
def dir_listing(req_path):
    parent_path = "/"+os.path.dirname(req_path)
    
    if req_path and not req_path.endswith('/'):
        req_path += '/'

    abs_path = os.path.join(app.config['UPLOAD_FOLDER'], req_path)

    if not os.path.exists(abs_path):
        return 'Path not found'

    data = list_directory_contents(req_path, abs_path)
    dir1 = app.config['UPLOAD_FOLDER']
    the_path = dir1 +"/"+ req_path
    the_path = the_path.replace("//", "/")
    print("the_path: %s, req_path: %s, parent_path: %s" % (the_path, req_path, parent_path))
    
    return render_template('index.html', data=data, the_path=the_path, req_path=req_path, parent_path=parent_path)

@app.route('/download/<path:req_path>')
def download_file(req_path):
    abs_parent_path = os.path.abspath(app.config['UPLOAD_FOLDER'])
    return send_from_directory(abs_parent_path, req_path, as_attachment=True)

@app.route('/view/<path:req_path>')
def view_file(req_path):
    abs_parent_path = os.path.abspath(app.config['UPLOAD_FOLDER'])
    return send_from_directory(abs_parent_path, req_path, as_attachment=False)

@app.route('/upload', methods=['POST'])
def upload_file():
    req_path = request.args.get('path', '')
    req_path = req_path.lstrip('/')
    abs_path = os.path.join(app.config['UPLOAD_FOLDER'], req_path)

    if not os.path.exists(abs_path):
        os.makedirs(abs_path)

    if 'file' not in request.files:
        return 'No file part'
    file = request.files['file']
    if file.filename == '':
        return 'No selected file'
    if file:
        filename = file.filename
        file.save(os.path.join(abs_path, filename))
        return 'File uploaded successfully to: {}'.format(os.path.join(abs_path, filename))

@app.route('/upload_ajax', methods=['POST'])
def upload_file_ajax():
    """处理AJAX上传请求，支持进度反馈"""
    try:
        req_path = request.args.get('path', '')
        # 去掉前导斜杠，确保是相对路径，防止路径穿越
        req_path = req_path.lstrip('/')
        abs_path = os.path.join(app.config['UPLOAD_FOLDER'], req_path)

        if not os.path.exists(abs_path):
            os.makedirs(abs_path)

        if 'file' not in request.files:
            return jsonify({'success': False, 'message': '没有选择文件'})
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'success': False, 'message': '没有选择文件'})
        
        if file:
            filename = file.filename
            # 确保文件名安全
            filename = os.path.basename(filename)
            file_path = os.path.join(abs_path, filename)
            file.save(file_path)
            
            # 获取文件详细信息用于前端动态展示
            stat_info = os.stat(file_path)
            permissions = get_filemode(stat_info.st_mode)
            owner = get_file_owner(file_path)
            try:
                if sys.platform != "win32":
                    group = ""
                else:
                    import grp
                    group = grp.getgrgid(stat_info.st_gid).gr_name
            except:
                group = str(stat_info.st_gid)
            
            size = stat_info.st_size
            if size > 1024 * 1024 * 1024:
                size_str = "%.2f GB" % (size/1024.0/1024.0/1024.0)
            elif size > 1024 * 1024:
                size_str = "%.2f MB" % (size/1024.0/1024.0)
            elif size > 1024:
                size_str = "%.2f KB" % (size/1024.0)
            else:
                size_str = "%.2f B" % (size)
            mtime = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(stat_info.st_mtime))
            
            file_ext = filename.split('.')[-1].lower()
            if file_ext in ['html', 'txt', 'sh', 'scala', 'py', 'js', 'css', 'json', 'md', 'yml', 'yaml', 'ini', 'conf']:
                action = "edit"
            elif file_ext in ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg', 'ico', 'mp4', 'avi', 'mov', 'wmv', 'flv', 'webm', 'mkv', 'mp3', 'wav', 'flac', 'aac', 'ogg', 'wma']:
                action = "view"
            else:
                action = "download"
            href = "/" + action + "/" + req_path + filename

            response_data = {
                'success': True,    
                'message': '文件上传成功: {}'.format(filename),
                'file_info': {
                    'name': filename,
                    'permissions': permissions,
                    'owner': owner,
                    'group': str(group),
                    'size': size_str,
                    'mtime': mtime,
                    'href': href,
                    'type': 'file'
                }
            }
            return app.response_class(
                response=json.dumps(response_data),
                status=200,
                mimetype='application/json'
            )
    
    except Exception as e:
        error_data = {'success': False, 'message': '上传失败: {}'.format(str(e))}
        return app.response_class(
            response=json.dumps(error_data),
            status=500,
            mimetype='application/json'
        )

@app.errorhandler(413)
def too_large(e):
    """处理文件过大的错误"""
    error_data = {
        'success': False, 
        'message': '文件过大，最大支持2000MB。当前文件可能超过了限制。'
    }
    return app.response_class(
        response=json.dumps(error_data),
        status=413,
        mimetype='application/json'
    )


def upload_to_server(server, files, path):
    """通过命令行上传文件到远程 whttpserver"""
    try:
        # Python 2/3 兼容
        try:
            from urllib.request import Request, urlopen
            from urllib.parse import urlencode, quote
            from urllib.error import URLError, HTTPError
        except ImportError:
            from urllib2 import Request, urlopen, URLError, HTTPError
            from urllib import urlencode, quote

        server = server.rstrip('/')
        upload_url = server + '/upload_ajax?path=' + quote(path, safe='/')

        for filepath in files:
            if not os.path.isfile(filepath):
                print('跳过 (不存在): ' + filepath)
                continue

            filename = os.path.basename(filepath)
            filesize = os.path.getsize(filepath)

            # 格式化大小
            if filesize > 1024 * 1024 * 1024:
                size_str = "%.2f GB" % (filesize / 1024.0 / 1024.0 / 1024.0)
            elif filesize > 1024 * 1024:
                size_str = "%.2f MB" % (filesize / 1024.0 / 1024.0)
            elif filesize > 1024:
                size_str = "%.2f KB" % (filesize / 1024.0)
            else:
                size_str = "%.2f B" % filesize

            print('上传中: %s (%s) ...' % (filename, size_str))

            # 构建 multipart/form-data
            boundary = '----WebKitFormBoundary' + str(int(time.time() * 1000))
            
            with open(filepath, 'rb') as f:
                file_data = f.read()

            # 标准 multipart 格式
            body = b''
            body += ('--' + boundary + '\r\n').encode('utf-8')
            body += ('Content-Disposition: form-data; name="file"; filename="' + filename + '"\r\n').encode('utf-8')
            body += b'Content-Type: application/octet-stream\r\n'
            body += b'\r\n'
            body += file_data
            body += b'\r\n'
            body += ('--' + boundary + '--\r\n').encode('utf-8')

            req = Request(upload_url, data=body)
            req.add_header('Content-Type', 'multipart/form-data; boundary=' + boundary)

            try:
                resp = urlopen(req)
                resp_body = resp.read().decode('utf-8')
                result = json.loads(resp_body)
                if result.get('success'):
                    print('  ✓ ' + result.get('message', '上传成功'))
                else:
                    print('  ✗ ' + result.get('message', '上传失败'))
            except HTTPError as e:
                print('  ✗ HTTP错误 %d' % e.code)
            except URLError as e:
                print('  ✗ 连接失败: ' + str(e.reason))

    except Exception as e:
        print('上传出错: ' + str(e))
        sys.exit(1)


def _looks_like_server(arg):
    """判断参数是否像服务器地址，如 192.168.1.1:25000 或 http://host:port"""
    if arg.startswith('http://') or arg.startswith('https://'):
        return True
    # IP:port 或 hostname:port 格式
    import re
    if re.match(r'^[\w.\-]+:\d+$', arg):
        return True
    return False


def main():
    # 先检查是否是简化上传模式: whttpserver <server> <files...>
    # 或者带 upload 子命令的模式
    raw_args = sys.argv[1:]

    # 简化上传模式: 第一个参数看起来像服务器地址，后面跟文件
    if len(raw_args) >= 2 and _looks_like_server(raw_args[0]):
        server = raw_args[0]
        if not server.startswith('http://') and not server.startswith('https://'):
            server = 'http://' + server
        
        # 解析可选的 --path 参数
        path = ''
        files = []
        i = 1
        while i < len(raw_args):
            if raw_args[i] in ('--path', '-p') and i + 1 < len(raw_args):
                path = raw_args[i + 1]
                i += 2
            else:
                files.append(raw_args[i])
                i += 1
        
        if files:
            upload_to_server(server, files, path)
            return
    
    parser = argparse.ArgumentParser(
        description="Simple HTTP Server with upload support",
        epilog="上传简化用法: whttpserver <IP:端口> [--path <目录>] <文件...>\n"
               "  例: whttpserver 192.168.1.102:25000 file1.txt file2.txt",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    subparsers = parser.add_subparsers(dest='command')

    # serve 子命令（也是默认行为）
    serve_parser = subparsers.add_parser('serve', help='启动 HTTP 文件服务')
    serve_parser.add_argument("--port", type=int, default=25000, help="Port to serve on")
    serve_parser.add_argument("--dir", type=str, default=os.getcwd(), help="Directory to serve")
    serve_parser.add_argument("--debug", type=bool, default=True, help="Debug mode")

    # upload 子命令（保留完整模式）
    upload_parser = subparsers.add_parser('upload', help='上传文件到远程 whttpserver')
    upload_parser.add_argument("--server", "-s", type=str, required=True, help="服务器地址，如 http://192.168.1.100:25000")
    upload_parser.add_argument("--path", "-p", type=str, default="", help="上传到服务器的目标相对目录路径，如 subdir/（留空则上传到根目录）")
    upload_parser.add_argument("files", nargs='+', help="要上传的文件")

    args = parser.parse_args()

    if args.command is None or args.command == 'serve':
        if args.command is None:
            parser2 = argparse.ArgumentParser(description="Simple HTTP Server")
            parser2.add_argument("--port", type=int, default=25000, help="Port to serve on")
            parser2.add_argument("--dir", type=str, default=os.getcwd(), help="Directory to serve")
            parser2.add_argument("--debug", type=bool, default=True, help="Debug mode")
            args = parser2.parse_args()

        app.config['UPLOAD_FOLDER'] = args.dir
        print("default start command: ")
        print("whttpserver --port 25000  --dir %s --debug True " % args.dir)
        app.run(host='0.0.0.0', port=args.port, debug=args.debug)

    elif args.command == 'upload':
        server = args.server
        if not server.startswith('http://') and not server.startswith('https://'):
            server = 'http://' + server
        upload_to_server(server, args.files, args.path)
    
if __name__ == '__main__':
    main()
 
