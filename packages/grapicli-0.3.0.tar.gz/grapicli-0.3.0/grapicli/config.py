"""Configuration loading from environment variables."""

import os
from pathlib import Path

from dotenv import load_dotenv

# Look for .env in the project root (two levels up from this file)
_env_path = Path(__file__).parent.parent / ".env"
load_dotenv(dotenv_path=_env_path)


def get_graylog_url() -> str:
    url = os.getenv("GRAYLOG_URL")
    if not url:
        raise ValueError(
            "GRAYLOG_URL is not set.\n\n"
            "  Set it in a .env file in your working directory:\n\n"
            "    echo 'export GRAYLOG_URL=https://your-graylog-server' >> .env\n\n"
            "  Or export it directly in your shell:\n\n"
            "    export GRAYLOG_URL=https://your-graylog-server"
        )
    return url.rstrip("/")


def get_graylog_token() -> str:
    token = os.getenv("GRAYLOG_TOKEN")
    if not token:
        raise ValueError(
            "GRAYLOG_TOKEN is not set.\n\n"
            "  Set it in a .env file in your working directory:\n\n"
            "    echo 'export GRAYLOG_TOKEN=your_api_token_here' >> .env\n\n"
            "  Or export it directly in your shell:\n\n"
            "    export GRAYLOG_TOKEN=your_api_token_here\n\n"
            "  To generate a token: Graylog web UI → System → Users and Teams\n"
            "                       → Edit Profile → API Tokens"
        )
    return token
