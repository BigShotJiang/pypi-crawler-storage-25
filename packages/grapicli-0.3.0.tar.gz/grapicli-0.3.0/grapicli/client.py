"""Graylog API client."""

from datetime import datetime, timezone
from typing import Any

import requests

from .config import get_graylog_token, get_graylog_url


class GraylogClient:
    def __init__(self) -> None:
        self.base_url = get_graylog_url()
        self.token = get_graylog_token()
        self.session = requests.Session()
        # Graylog token auth: username=<token>, password="token"
        self.session.auth = (self.token, "token")
        self.session.headers.update({"Accept": "application/json"})

    def search_relative(
        self,
        query: str,
        range_seconds: int,
        limit: int,
        fields: str | None = None,
        sort: str | None = None,
    ) -> dict[str, Any]:
        """Search using a relative time range (last N seconds)."""
        params: dict[str, Any] = {
            "query": query,
            "range": range_seconds,
            "limit": limit,
        }
        if fields:
            params["fields"] = fields
        if sort:
            params["sort"] = sort

        resp = self.session.get(
            f"{self.base_url}/api/search/universal/relative",
            params=params,
        )
        resp.raise_for_status()
        return resp.json()

    def search_absolute(
        self,
        query: str,
        from_dt: datetime,
        to_dt: datetime,
        limit: int,
        fields: str | None = None,
        sort: str | None = None,
    ) -> dict[str, Any]:
        """Search using an absolute time range."""

        def fmt(dt: datetime) -> str:
            # Ensure UTC and format as ISO 8601
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")

        params: dict[str, Any] = {
            "query": query,
            "from": fmt(from_dt),
            "to": fmt(to_dt),
            "limit": limit,
        }
        if fields:
            params["fields"] = fields
        if sort:
            params["sort"] = sort

        resp = self.session.get(
            f"{self.base_url}/api/search/universal/absolute",
            params=params,
        )
        resp.raise_for_status()
        return resp.json()
