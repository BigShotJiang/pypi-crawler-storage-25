__version__ = "0.62.1"
__author__ = "pengyeqin"
__email__ = "xxbj433@qq.com"

from .reasoning.logical import LogicalReasoning
from .reasoning.common_sense import CommonSense
from .reasoning.decision import DecisionReasoning
from .reasoning.metacognition import MetaCognition
from .reasoning.active_learning import ActiveLearning

def hello():
    print("Hello from ub-clean-test!")