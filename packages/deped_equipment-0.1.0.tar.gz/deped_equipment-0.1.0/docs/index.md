# DepEd Equipment

`deped-equipment` builds an equipment-focused SQLite database from DepEd inventory CSV exports. It depends on lookup data from `deped-dcp-template`, an entity artifact from `deped-entity`, and a personnel artifact produced by `deped-hr`.

## What This Package Owns

- Equipment row cleaning and normalization
- Canonicalization of brands, models, units, categories, acquisition modes, acquisition sources, and DCP year values
- Review-driven DCP attribution normalization layered on top of `lookups.db`
- Review-driven equipment location normalization layered on top of in-repo aliases
- Review-driven supplier and disposition-status normalization layered on top of in-repo aliases
- Equipment-domain entity loading
- Accountable-person resolution against a personnel snapshot
- Equipment-owned SQL views and audit outputs

This package is the source of truth for the `equipment.db` artifact only.

## Inputs

- A equipment CSV export under `data/`
- A lookup database produced by `deped-dcp-template`
- A personnel database produced by `deped-hr`
- An entity database produced by `deped-entity`

## Outputs

- `artifacts/equipment.db`
- `artifacts/equipment_dimension_issues.txt`

## Main Commands

Build the lookup database:

```sh
uv run deped-dcp-template extract \
--templates-dir templates \
--output artifacts/lookups.db
```

Build the personnel database:

```sh
uv run hr build \
--personnel data/2026-03-31-personnel.csv \
--lookups artifacts/lookups.db \
--db artifacts/personnel.db
```

Build the equipment database:

```sh
uv run equipment build \
--equipment data/2026-03-30-equipment.csv \
--lookups artifacts/lookups.db \
--entities-db artifacts/entities.db \
--personnel-db artifacts/personnel.db \
--db artifacts/equipment.db
```

Audit a built database:

```sh
uv run equipment audit \
--db artifacts/equipment.db
```

## Behavioral Notes

- Entity loading remains artifact-driven. This package consumes the `entities.db` artifact using the same upstream contract as `deped-hr`.
- Personnel linking remains artifact-driven. This package consumes the `personnel.db` artifact and reuses shared helpers from `deped-hr` and `deped-dcp-template` where appropriate.
- Ambiguous person matches are preserved as ambiguous rather than guessed.
- Unmapped dimension values are written to `artifacts/equipment_dimension_issues.txt`.
- DCP attribution is curated in-repo through `src/deped_equipment/dictionaries/dcp_attribution_dictionary.csv`. Official `lookups.db.dcp_packages` rows seed named-package canonicals but do not replace review.
- Equipment location is curated in-repo through `src/deped_equipment/dictionaries/equipment_location_dictionary.csv`.
- Supplier and disposition-status normalization are curated in-repo through `src/deped_equipment/dictionaries/`.
- Other systems should consume `equipment.db` as an artifact instead of importing internal modules.
