# Data Contract

The `deped_equipment` package owns the structure and semantics of the equipment artifact.

## Core Tables

The SQLite schema includes these primary tables:

- `entities`
- `entity_aliases`
- `equipment`
- `equipment_dimension_issues`
- `equipment_brands`
- `equipment_models`
- `equipment_locations`
- `equipment_suppliers`
- `equipment_disposition_statuses`
- `equipment_source_of_funds`
- `equipment_conditions`
- `equipment_units`
- `equipment_categories`
- `equipment_acquisition_modes`
- `equipment_acquisition_sources`
- `equipment_dcp_attributions`
- `equipment_dcp_attribution_aliases`
- `equipment_dcp_packages`
- `equipment_dcp_years`
- `date_parse_errors`
- `build_runs`

## Views

The build creates the following equipment-owned views:

- `v_equipment_enriched`
- `v_equipment_value_per_school`
- `v_equipment_condition_summary`
- `v_link_resolution_coverage`
- `v_dimension_canonicalization_coverage`
- `v_equipment_dimension_issue_summary`
- `v_unresolved_dimension_values`
- `v_dcp_attribution_unclassified`
- `v_equipment_location_unclassified`
- `v_supplier_unclassified`
- `v_disposition_status_unclassified`
- `v_source_of_funds_unclassified`
- `v_equipment_condition_unclassified`

These views are part of the artifact contract exposed to downstream consumers.

## Build Metadata

`build_runs` records provenance for each build, including:

- Build type
- Schema version
- Source file names
- Source file hashes
- Final row counts
- Completion timestamp

## Personnel Linking

Personnel resolution reads from a supplied `personnel.db` artifact. During the build:

- equipment rows attempt to match accountable personnel through the artifact
- exact matches are linked directly
- ambiguous or unresolved matches remain visible for audit

## Data Quality Signals

The artifact captures quality issues in two ways:

- `equipment_dimension_issues` stores unresolved canonicalization cases
- `v_link_resolution_coverage` and related views expose matching gaps and coverage summaries

## DCP Attribution Contract

The artifact keeps DCP source provenance and reviewed normalization separate:

- `equipment.dcp_package_raw` stores the exact source text from the CSV.
- `equipment.dcp_attribution_id` points to the reviewed canonical procurement-attribution row when a reviewed mapping exists.
- `equipment.dcp_attribution_type` stores the resolved attribution label type or a row classification such as `non_dcp`, `invalid_placeholder`, or `unclassified`.
- `v_equipment_enriched.dcp_package_name` remains available as a backward-compatible alias of the new canonical attribution name.

Canonical DCP attribution rows are built from:

- official `lookups.db.dcp_packages` seed rows
- the reviewed in-repo dictionary at `src/deped_equipment/dictionaries/dcp_attribution_dictionary.csv`

## Equipment Location Contract

The artifact keeps equipment-location source provenance and reviewed normalization separate:

- `equipment.equipment_location` stores the exact source text from the CSV.
- `equipment.equipment_location_id` points to the reviewed canonical location row when a reviewed mapping exists.
- `equipment.equipment_location_type` distinguishes reviewed mappings from generic invalid values and unresolved locations.
- `v_equipment_enriched.equipment_location_name` exposes the canonical location grouping when present.

Canonical equipment location rows are built from the reviewed in-repo dictionary at `src/deped_equipment/dictionaries/equipment_location_dictionary.csv`.

## Supplier Contract

The artifact keeps supplier source provenance and reviewed normalization separate:

- `equipment.supplier` stores the exact source text from the CSV.
- `equipment.supplier_id` points to the reviewed canonical supplier row when a reviewed mapping exists.
- `equipment.supplier_type` distinguishes reviewed mappings from internal/non-supplier values and unresolved suppliers.
- `v_equipment_enriched.supplier_name` exposes the canonical supplier name when present.

Canonical supplier rows are built from the reviewed in-repo dictionary at `src/deped_equipment/dictionaries/supplier_dictionary.csv`.

## Disposition Status Contract

The artifact keeps disposition-status source provenance and reviewed normalization separate:

- `equipment.disposition_status` stores the exact source text from the CSV.
- `equipment.disposition_status_id` points to the reviewed canonical disposition row when a reviewed mapping exists.
- `equipment.disposition_status_type` distinguishes reviewed mappings from invalid raw values and unresolved statuses.
- `v_equipment_enriched.disposition_status_name` exposes the canonical disposition label when present.

Canonical disposition rows are built from the reviewed in-repo dictionary at `src/deped_equipment/dictionaries/disposition_status_dictionary.csv`.

## Source Of Funds Contract

The artifact keeps source-of-funds provenance and reviewed normalization separate:

- `equipment.source_of_funds` stores the exact source text from the CSV.
- `equipment.source_of_funds_id` points to the reviewed canonical source-of-funds row when a reviewed mapping exists.
- `equipment.source_of_funds_type` distinguishes reviewed mappings from invalid raw values and unresolved fund sources.
- `v_equipment_enriched.source_of_funds_name` exposes the canonical fund-source label when present.

Canonical source-of-funds rows are built from the reviewed in-repo dictionary at `src/deped_equipment/dictionaries/source_of_funds_dictionary.csv`.

## Equipment Condition Contract

The artifact keeps equipment-condition provenance and reviewed normalization separate:

- `equipment.equipment_condition` stores the exact source text from the CSV.
- `equipment.equipment_condition_id` points to the reviewed canonical condition row when a reviewed mapping exists.
- `equipment.equipment_condition_type` distinguishes reviewed mappings from invalid raw values and unresolved conditions.
- `v_equipment_enriched.equipment_condition_name` exposes the canonical condition label when present.

Canonical equipment-condition rows are built from the reviewed in-repo dictionary at `src/deped_equipment/dictionaries/equipment_condition_dictionary.csv`.
