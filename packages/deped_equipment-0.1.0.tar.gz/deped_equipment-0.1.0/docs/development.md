# Development

## Local Setup

Install project dependencies with `uv` and work from the repository root.

The package code lives under `src/deped_equipment`.

## Tests

Run the test suite:

```sh
uv run pytest -q
```

Current test coverage is focused on:

- normalization rules in `tests/test_equipment_cleaners.py`
- database build behavior in `tests/test_equipment_build.py`

## Documentation

This repository uses Zensical for documentation. The site configuration lives in `zensical.toml`, and Markdown sources live in `docs/`.

The DCP attribution review workflow is documented in `docs/dcp-attribution-curation.md`.

Build the documentation site locally with:

```sh
uv run zensical build
```

## Publishing

The `justfile` includes a `publish` target that builds and publishes the Python package:

```sh
just publish
```

This expects the appropriate PyPI token to be available in the environment.
