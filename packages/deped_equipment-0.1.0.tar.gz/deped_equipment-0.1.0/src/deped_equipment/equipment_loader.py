"""Equipment row loading pipeline."""

from __future__ import annotations

import sqlite3
from collections import Counter
from pathlib import Path
from typing import cast

from deped_dcp_template.cleaners import (
    canonicalize_equipment_dimension,
    clean_text,
    normalize_equipment_category,
    normalize_equipment_item,
    normalize_identifier,
    normalize_low_cardinality_dimension,
    normalize_school_id,
    parse_cost,
    parse_date,
    parse_float,
    to_bool_int,
)
from deped_dcp_template.constants import BATCH_SIZE, EQUIPMENT_SOURCE
from deped_dcp_template.entities import build_natural_key, determine_entity_type
from deped_dcp_template.io import iter_csv_rows
from deped_dcp_template.personnel import flush_batch, maybe_log_date_error
from rich.progress import Progress, TaskID

from .csv_rows import row_get
from .dcp_attribution import (
    classify_dcp_attribution_value,
    normalize_dcp_attribution_review_key,
)
from .disposition_normalization import (
    classify_disposition_value,
    normalize_disposition_review_key,
)
from .equipment_columns import DATE_ERROR_COLUMNS, EQUIPMENT_COLUMNS, ISSUE_COLUMNS
from .equipment_condition_normalization import (
    classify_equipment_condition_value,
    normalize_equipment_condition_review_key,
)
from .location_normalization import (
    classify_equipment_location_value,
    normalize_equipment_location_review_key,
)
from .personnel_resolution import resolve_person_reference
from .source_of_funds_normalization import (
    classify_source_of_funds_value,
    normalize_source_of_funds_review_key,
)
from .supplier_normalization import (
    classify_supplier_value,
    normalize_supplier_review_key,
)
from .types import (
    DateErrorRow,
    DateParseCandidate,
    EntityLookup,
    EquipmentInsertRow,
    EquipmentIssueCounter,
    EquipmentIssueRow,
    LookupMaps,
    PersonnelResolutionLookups,
)


def log_equipment_dimension_issue(
    issue_counts: EquipmentIssueCounter,
    issue_rows: list[EquipmentIssueRow],
    *,
    dimension_name: str,
    issue_type: str | None,
    raw_value: str | None,
    source_file: str,
    source_row_num: int,
    source_record_id: int | None,
) -> None:
    """Record a classified equipment-dimension issue for audits and QA views."""
    if raw_value is None or issue_type is None:
        return
    issue_counts[(dimension_name, issue_type, raw_value)] += 1
    issue_rows.append(
        (
            dimension_name,
            issue_type,
            raw_value,
            source_file,
            source_row_num,
            source_record_id,
        )
    )


def _flush_pending_rows(
    conn: sqlite3.Connection,
    rows: list[EquipmentInsertRow],
    issue_rows: list[EquipmentIssueRow],
    date_errors: list[DateErrorRow],
) -> None:
    flush_batch(conn, "equipment", list(EQUIPMENT_COLUMNS), rows)
    flush_batch(
        conn,
        "equipment_dimension_issues",
        list(ISSUE_COLUMNS),
        cast(list[tuple[object, ...]], issue_rows),
    )
    flush_batch(
        conn,
        "date_parse_errors",
        list(DATE_ERROR_COLUMNS),
        cast(list[tuple[object, ...]], date_errors),
    )


def resolve_dcp_attribution(
    lookup_maps: LookupMaps, dcp_package_raw: str | None, is_non_dcp: int | None
) -> tuple[int | None, str | None, str | None, int | None, str | None]:
    dcp_attribution_review_key = normalize_dcp_attribution_review_key(dcp_package_raw)
    dcp_attribution_type, dcp_issue = classify_dcp_attribution_value(
        dcp_package_raw,
        is_non_dcp=bool(is_non_dcp),
    )
    canonical_dcp_attribution = None
    if dcp_attribution_review_key is not None:
        canonical_dcp_attribution = lookup_maps[
            "equipment_dcp_attribution_aliases"
        ].get(dcp_attribution_review_key)
    dcp_attribution_id = None
    dcp_package_id = None
    if canonical_dcp_attribution is not None:
        dcp_attribution_id = lookup_maps["equipment_dcp_attributions"].get(
            canonical_dcp_attribution
        )
        dcp_package_id = lookup_maps["equipment_dcp_packages"].get(
            canonical_dcp_attribution
        )
        dcp_attribution_type = lookup_maps["equipment_dcp_attribution_types"].get(
            canonical_dcp_attribution,
            dcp_attribution_type,
        )
        dcp_issue = None
    return (
        dcp_attribution_id,
        dcp_attribution_type,
        dcp_attribution_review_key,
        dcp_package_id,
        dcp_issue,
    )


def resolve_equipment_location(
    lookup_maps: LookupMaps, equipment_location_raw: str | None
) -> tuple[int | None, str | None, str | None, str | None]:
    equipment_location_review_key = normalize_equipment_location_review_key(
        equipment_location_raw
    )
    equipment_location_type, equipment_location_issue = (
        classify_equipment_location_value(equipment_location_raw)
    )
    canonical_equipment_location = None
    if equipment_location_review_key is not None:
        canonical_equipment_location = lookup_maps["equipment_location_aliases"].get(
            equipment_location_review_key
        )
    equipment_location_id = None
    if canonical_equipment_location is not None:
        equipment_location_id = lookup_maps["equipment_locations"].get(
            canonical_equipment_location
        )
        equipment_location_type = "reviewed_location"
        equipment_location_issue = None
    return (
        equipment_location_id,
        equipment_location_type,
        equipment_location_review_key,
        equipment_location_issue,
    )


def resolve_supplier(
    lookup_maps: LookupMaps, supplier_raw: str | None
) -> tuple[int | None, str | None, str | None, str | None]:
    supplier_review_key = normalize_supplier_review_key(supplier_raw)
    supplier_type, supplier_issue = classify_supplier_value(supplier_raw)
    canonical_supplier = None
    if supplier_review_key is not None:
        canonical_supplier = lookup_maps["equipment_supplier_aliases"].get(
            supplier_review_key
        )
    supplier_id = None
    if canonical_supplier is not None:
        supplier_id = lookup_maps["equipment_suppliers"].get(canonical_supplier)
        supplier_type = "reviewed_supplier"
        supplier_issue = None
    return supplier_id, supplier_type, supplier_review_key, supplier_issue


def resolve_disposition_status(
    lookup_maps: LookupMaps, disposition_status_raw: str | None
) -> tuple[int | None, str | None, str | None, str | None]:
    disposition_status_review_key = normalize_disposition_review_key(
        disposition_status_raw
    )
    disposition_status_type, disposition_status_issue = classify_disposition_value(
        disposition_status_raw
    )
    canonical_status = None
    if disposition_status_review_key is not None:
        canonical_status = lookup_maps["equipment_disposition_status_aliases"].get(
            disposition_status_review_key
        )
    disposition_status_id = None
    if canonical_status is not None:
        disposition_status_id = lookup_maps["equipment_disposition_statuses"].get(
            canonical_status
        )
        disposition_status_type = "reviewed_disposition"
        disposition_status_issue = None
    return (
        disposition_status_id,
        disposition_status_type,
        disposition_status_review_key,
        disposition_status_issue,
    )


def resolve_source_of_funds(
    lookup_maps: LookupMaps, source_of_funds_raw: str | None
) -> tuple[int | None, str | None, str | None, str | None]:
    source_of_funds_review_key = normalize_source_of_funds_review_key(
        source_of_funds_raw
    )
    source_of_funds_type, source_of_funds_issue = classify_source_of_funds_value(
        source_of_funds_raw
    )
    canonical_fund = None
    if source_of_funds_review_key is not None:
        canonical_fund = lookup_maps["equipment_source_of_funds_aliases"].get(
            source_of_funds_review_key
        )
    source_of_funds_id = None
    if canonical_fund is not None:
        source_of_funds_id = lookup_maps["equipment_source_of_funds"].get(
            canonical_fund
        )
        source_of_funds_type = "reviewed_source_of_funds"
        source_of_funds_issue = None
    return (
        source_of_funds_id,
        source_of_funds_type,
        source_of_funds_review_key,
        source_of_funds_issue,
    )


def resolve_equipment_condition(
    lookup_maps: LookupMaps, equipment_condition_raw: str | None
) -> tuple[int | None, str | None, str | None, str | None]:
    equipment_condition_review_key = normalize_equipment_condition_review_key(
        equipment_condition_raw
    )
    equipment_condition_type, equipment_condition_issue = (
        classify_equipment_condition_value(equipment_condition_raw)
    )
    canonical_condition = None
    if equipment_condition_review_key is not None:
        canonical_condition = lookup_maps["equipment_condition_aliases"].get(
            equipment_condition_review_key
        )
    equipment_condition_id = None
    if canonical_condition is not None:
        equipment_condition_id = lookup_maps["equipment_conditions"].get(
            canonical_condition
        )
        equipment_condition_type = "reviewed_equipment_condition"
        equipment_condition_issue = None
    return (
        equipment_condition_id,
        equipment_condition_type,
        equipment_condition_review_key,
        equipment_condition_issue,
    )


def load_equipment(
    conn: sqlite3.Connection,
    path: str | Path,
    entity_lookup: EntityLookup,
    lookup_maps: LookupMaps,
    resolution_lookups: PersonnelResolutionLookups,
    progress: Progress | None = None,
) -> EquipmentIssueCounter:
    """Load cleaned equipment data into SQLite."""
    issue_counts: EquipmentIssueCounter = Counter()
    rows: list[EquipmentInsertRow] = []
    date_errors: list[DateErrorRow] = []
    issue_rows: list[EquipmentIssueRow] = []
    loaded_entity_ids: set[int] = set()
    source_file = Path(path).name
    task_id: TaskID | None = None
    if progress is not None:
        task_id = progress.add_task(
            f"Load equipment: {Path(path).name} (0 rows)",
            total=Path(path).stat().st_size,
        )

    for source_row_num, row in iter_csv_rows(path, progress, task_id):
        entity_type = determine_entity_type(
            row_get(row, "governance_level", "Governance Level")
        )
        school_id = normalize_school_id(row_get(row, "school_id", "School ID"))
        region = clean_text(row_get(row, "region_name", "region", "Region"))
        division = clean_text(row_get(row, "division_name", "division", "Division"))
        source_record_id = normalize_school_id(row_get(row, "record_id", "ID"))
        natural_key = build_natural_key(entity_type, school_id, region, division)
        entity_id = entity_lookup.get(natural_key)
        if entity_id is None:
            log_equipment_dimension_issue(
                issue_counts,
                issue_rows,
                dimension_name="entity",
                issue_type="missing_upstream_entity",
                raw_value=natural_key,
                source_file=source_file,
                source_row_num=source_row_num,
                source_record_id=source_record_id,
            )
            continue
        loaded_entity_ids.add(entity_id)
        accountable_officer = clean_text(
            row_get(row, "accountable_officer", "Accountable Officer")
        )
        custodian_end_user = clean_text(
            row_get(row, "end_user", "Custodian / End User")
        )
        received_by = clean_text(row_get(row, "received_by", "Received by"))
        (
            accountable_personnel_id,
            accountable_normalized_name,
            accountable_employee_id,
            accountable_link_status,
        ) = resolve_person_reference(
            accountable_officer,
            entity_id,
            entity_type,
            region,
            division,
            resolution_lookups,
        )
        (
            custodian_personnel_id,
            custodian_normalized_name,
            custodian_employee_id,
            custodian_link_status,
        ) = resolve_person_reference(
            custodian_end_user,
            entity_id,
            entity_type,
            region,
            division,
            resolution_lookups,
        )
        (
            received_by_personnel_id,
            received_by_normalized_name,
            received_by_employee_id,
            received_by_link_status,
        ) = resolve_person_reference(
            received_by,
            entity_id,
            entity_type,
            region,
            division,
            resolution_lookups,
        )

        category_raw = clean_text(row_get(row, "category", "Category"))
        category_name = normalize_equipment_category(category_raw)
        item_raw = clean_text(row_get(row, "item", "Item"))
        unit_raw = clean_text(row_get(row, "uom", "Unit of Measure"))
        brand_raw = clean_text(
            row_get(row, "brand_manufacturer", "Brand / Manufacturer")
        )
        model_raw = clean_text(row_get(row, "model", "Model"))
        dcp_package_raw = clean_text(row_get(row, "dcp_package", "DCP Package"))
        dcp_year_package_raw = clean_text(
            row_get(row, "dcp_year", "DCP Year Package ", "DCP Year Package")
        )
        mode_raw = clean_text(row_get(row, "mode_acquisition", "Mode of Acquisition"))
        source_raw = clean_text(
            row_get(row, "source_acquisition", "Source of Acquisition")
        )
        equipment_location_raw = clean_text(
            row_get(row, "equipment_location", "Equipment Location")
        )
        supplier_raw = clean_text(
            row_get(
                row, "supplier", "Supplier / Distributor", "Supplier / Distributor "
            )
        )
        source_of_funds_raw = clean_text(
            row_get(row, "source_fund", "Source of Funds", "Source of Funds\n")
        )
        equipment_condition_raw = clean_text(
            row_get(
                row,
                "equipment_condition",
                "erquipment_condition",
                "Equipment Condition",
            )
        )
        disposition_status_raw = clean_text(
            row_get(
                row,
                "disposition_status",
                "Accountability / Disposition Status",
                "Accountability / Disposition Status ",
            )
        )

        item_id = lookup_maps["equipment_items"].get(normalize_equipment_item(item_raw))
        unit_id = lookup_maps["equipment_units"].get(
            normalize_low_cardinality_dimension("unit", unit_raw)
        )
        brand_name, brand_issue = canonicalize_equipment_dimension("brand", brand_raw)
        brand_id = lookup_maps["equipment_brands"].get(brand_name)
        _, model_issue = canonicalize_equipment_dimension("model", model_raw)
        model_id = None
        is_non_dcp = to_bool_int(row_get(row, "non_dcp", "Non-DCP"))
        (
            dcp_attribution_id,
            dcp_attribution_type,
            dcp_attribution_review_key,
            dcp_package_id,
            dcp_issue,
        ) = resolve_dcp_attribution(
            lookup_maps,
            dcp_package_raw,
            is_non_dcp,
        )
        dcp_year_package_id = lookup_maps["equipment_dcp_years"].get(
            normalize_low_cardinality_dimension("dcp_year", dcp_year_package_raw)
        )
        mode_name, mode_issue = canonicalize_equipment_dimension(
            "acquisition_mode", mode_raw
        )
        mode_id = lookup_maps["equipment_acquisition_modes"].get(mode_name)
        source_name, source_issue = canonicalize_equipment_dimension(
            "acquisition_source", source_raw
        )
        source_id = lookup_maps["equipment_acquisition_sources"].get(source_name)
        (
            equipment_location_id,
            equipment_location_type,
            equipment_location_review_key,
            equipment_location_issue,
        ) = resolve_equipment_location(lookup_maps, equipment_location_raw)
        supplier_id, supplier_type, supplier_review_key, supplier_issue = (
            resolve_supplier(lookup_maps, supplier_raw)
        )
        (
            source_of_funds_id,
            source_of_funds_type,
            source_of_funds_review_key,
            source_of_funds_issue,
        ) = resolve_source_of_funds(lookup_maps, source_of_funds_raw)
        (
            equipment_condition_id,
            equipment_condition_type,
            equipment_condition_review_key,
            equipment_condition_issue,
        ) = resolve_equipment_condition(lookup_maps, equipment_condition_raw)
        (
            disposition_status_id,
            disposition_status_type,
            disposition_status_review_key,
            disposition_status_issue,
        ) = resolve_disposition_status(lookup_maps, disposition_status_raw)

        log_equipment_dimension_issue(
            issue_counts,
            issue_rows,
            dimension_name="brand",
            issue_type=brand_issue,
            raw_value=brand_raw,
            source_file=source_file,
            source_row_num=source_row_num,
            source_record_id=source_record_id,
        )
        log_equipment_dimension_issue(
            issue_counts,
            issue_rows,
            dimension_name="model",
            issue_type=model_issue,
            raw_value=model_raw,
            source_file=source_file,
            source_row_num=source_row_num,
            source_record_id=source_record_id,
        )
        log_equipment_dimension_issue(
            issue_counts,
            issue_rows,
            dimension_name="dcp_attribution",
            issue_type=dcp_issue,
            raw_value=dcp_package_raw,
            source_file=source_file,
            source_row_num=source_row_num,
            source_record_id=source_record_id,
        )
        log_equipment_dimension_issue(
            issue_counts,
            issue_rows,
            dimension_name="mode_of_acquisition",
            issue_type=mode_issue,
            raw_value=mode_raw,
            source_file=source_file,
            source_row_num=source_row_num,
            source_record_id=source_record_id,
        )
        log_equipment_dimension_issue(
            issue_counts,
            issue_rows,
            dimension_name="source_of_acquisition",
            issue_type=source_issue,
            raw_value=source_raw,
            source_file=source_file,
            source_row_num=source_row_num,
            source_record_id=source_record_id,
        )
        log_equipment_dimension_issue(
            issue_counts,
            issue_rows,
            dimension_name="equipment_location",
            issue_type=equipment_location_issue,
            raw_value=equipment_location_raw,
            source_file=source_file,
            source_row_num=source_row_num,
            source_record_id=source_record_id,
        )
        log_equipment_dimension_issue(
            issue_counts,
            issue_rows,
            dimension_name="supplier",
            issue_type=supplier_issue,
            raw_value=supplier_raw,
            source_file=source_file,
            source_row_num=source_row_num,
            source_record_id=source_record_id,
        )
        log_equipment_dimension_issue(
            issue_counts,
            issue_rows,
            dimension_name="source_of_funds",
            issue_type=source_of_funds_issue,
            raw_value=source_of_funds_raw,
            source_file=source_file,
            source_row_num=source_row_num,
            source_record_id=source_record_id,
        )
        log_equipment_dimension_issue(
            issue_counts,
            issue_rows,
            dimension_name="equipment_condition",
            issue_type=equipment_condition_issue,
            raw_value=equipment_condition_raw,
            source_file=source_file,
            source_row_num=source_row_num,
            source_record_id=source_record_id,
        )
        log_equipment_dimension_issue(
            issue_counts,
            issue_rows,
            dimension_name="disposition_status",
            issue_type=disposition_status_issue,
            raw_value=disposition_status_raw,
            source_file=source_file,
            source_row_num=source_row_num,
            source_record_id=source_record_id,
        )

        acquisition_date = parse_date(
            row_get(row, "received_date", "Acquisition / Received Date")
        )
        date_accountable_officer = parse_date(
            row_get(
                row,
                "date_assigned_accountable_officer",
                "Date assigned to / received by Accountable Officer",
            )
        )
        date_custodian = parse_date(
            row_get(
                row,
                "date_assigned_end_user",
                "Date assigned to / received by Custodian / End User",
            )
        )
        date_received_new = parse_date(
            row_get(
                row,
                "date_received_new_accountable",
                "Date received by New Accountable Officer / Custodian / End User",
            )
        )
        end_of_warranty = parse_date(
            row_get(row, "end_warranty_date", "End of Warranty")
        )

        date_parse_candidates: tuple[DateParseCandidate, ...] = (
            (
                "acquisition_date",
                row_get(row, "received_date", "Acquisition / Received Date"),
                acquisition_date,
            ),
            (
                "date_accountable_officer",
                row_get(
                    row,
                    "date_assigned_accountable_officer",
                    "Date assigned to / received by Accountable Officer",
                ),
                date_accountable_officer,
            ),
            (
                "date_custodian",
                row_get(
                    row,
                    "date_assigned_end_user",
                    "Date assigned to / received by Custodian / End User",
                ),
                date_custodian,
            ),
            (
                "date_received_new",
                row_get(
                    row,
                    "date_received_new_accountable",
                    "Date received by New Accountable Officer / Custodian / End User",
                ),
                date_received_new,
            ),
            (
                "end_of_warranty",
                row_get(row, "end_warranty_date", "End of Warranty"),
                end_of_warranty,
            ),
        )
        for column_name, raw_value, parsed_value in date_parse_candidates:
            maybe_log_date_error(
                cast(list[tuple[object, ...]], date_errors),
                EQUIPMENT_SOURCE,
                source_file,
                source_row_num,
                source_record_id,
                column_name,
                raw_value,
                parsed_value,
            )

        rows.append(
            (
                entity_id,
                school_id,
                accountable_personnel_id,
                custodian_personnel_id,
                received_by_personnel_id,
                clean_text(row_get(row, "property_no", "Property No.")),
                clean_text(
                    row_get(row, "old_property_no", "Old / Previous Property No.")
                ),
                clean_text(row_get(row, "serial_number", "Serial Number")),
                item_id,
                item_raw,
                clean_text(row_get(row, "other_item", "Other Item")),
                unit_id,
                unit_raw,
                brand_id,
                brand_raw,
                model_id,
                model_raw,
                clean_text(row_get(row, "specifications", "Specifications")),
                is_non_dcp,
                dcp_attribution_id,
                dcp_attribution_type,
                dcp_attribution_review_key,
                dcp_package_id,
                dcp_package_raw,
                dcp_year_package_id,
                dcp_year_package_raw,
                lookup_maps["equipment_categories"][category_name],
                category_raw,
                clean_text(row_get(row, "classification", "Classification")),
                normalize_identifier(row_get(row, "gl_sl_code", "GL-SL Code")),
                clean_text(row_get(row, "uacs", "UACS")),
                parse_cost(row_get(row, "acquisition_cost", "Acquisition Cost")),
                acquisition_date,
                parse_float(
                    row_get(row, "estimated_useful_life", "Estimated Useful Life")
                ),
                mode_id,
                mode_raw,
                source_id,
                source_raw,
                clean_text(row_get(row, "donor", "Donor")),
                source_of_funds_id,
                source_of_funds_type,
                source_of_funds_review_key,
                source_of_funds_raw,
                clean_text(row_get(row, "allotment_class", "Allotment Class")),
                clean_text(row_get(row, "pm_plan", "Procurement Management Plan")),
                clean_text(
                    row_get(row, "supporting_documents1", "Supporting Documents")
                ),
                clean_text(row_get(row, "or_si_dr_iar_no", "OR / SI / DR / IAR No.")),
                clean_text(row_get(row, "transaction_type", "Transaction Type")),
                accountable_officer,
                accountable_normalized_name,
                accountable_employee_id,
                accountable_link_status,
                date_accountable_officer,
                custodian_end_user,
                custodian_normalized_name,
                custodian_employee_id,
                custodian_link_status,
                date_custodian,
                received_by,
                received_by_normalized_name,
                received_by_employee_id,
                received_by_link_status,
                date_received_new,
                clean_text(
                    row_get(row, "supporting_documents2", "Supporting Documents 2")
                )
                or clean_text(
                    row_get(row, "supporting_documents1", "Supporting Documents")
                ),
                clean_text(
                    row_get(
                        row, "par_ics_rrsp_rs_wmr_no", "PAR / ICS / RRSP / RS / WMR No."
                    )
                ),
                supplier_id,
                supplier_type,
                supplier_review_key,
                supplier_raw,
                to_bool_int(row_get(row, "under_warranty", "Under Warranty")),
                end_of_warranty,
                equipment_location_id,
                equipment_location_type,
                equipment_location_review_key,
                equipment_location_raw,
                to_bool_int(row_get(row, "non_functional", "Non-Functional")),
                equipment_condition_id,
                equipment_condition_type,
                equipment_condition_review_key,
                equipment_condition_raw,
                disposition_status_id,
                disposition_status_type,
                disposition_status_review_key,
                disposition_status_raw,
                clean_text(row_get(row, "remarks", "Remarks")),
                source_file,
                source_row_num,
                source_record_id,
            )
        )

        if len(rows) >= BATCH_SIZE:
            _flush_pending_rows(conn, rows, issue_rows, date_errors)
            conn.commit()
            rows.clear()
            date_errors.clear()
            issue_rows.clear()

    _flush_pending_rows(conn, rows, issue_rows, date_errors)
    if loaded_entity_ids:
        conn.executemany(
            "UPDATE entities SET has_equipment = 1 WHERE entity_id = ?",
            [(entity_id,) for entity_id in sorted(loaded_entity_ids)],
        )
    conn.commit()
    if progress is not None and task_id is not None:
        progress.update(task_id, completed=Path(path).stat().st_size)
    return issue_counts
