from __future__ import annotations

import csv
import re
import unicodedata
from dataclasses import dataclass
from importlib.resources import files

from deped_dcp_template.cleaners import clean_text

_INVALID_PATTERNS = (
    re.compile(r"\bnot applicable\b"),
    re.compile(r"\bnone on record\b"),
    re.compile(r"\bno document"),
    re.compile(r"\binventory custodian slip\b"),
    re.compile(r"\bdelivery receipt\b"),
    re.compile(r"^\d+$"),
)


@dataclass(frozen=True)
class SourceOfFundsAliasRecord:
    alias_value: str
    normalized_alias_value: str
    canonical_name: str


def normalize_source_of_funds_review_key(value: str | None) -> str | None:
    text = clean_text(value)
    if text is None:
        return None
    normalized = unicodedata.normalize("NFKC", text).casefold()
    normalized = normalized.replace("&", " and ")
    normalized = re.sub(r"[‐‑–—−]+", "-", normalized)
    normalized = re.sub(r"[^a-z0-9]+", " ", normalized)
    normalized = re.sub(r"\s+", " ", normalized).strip()
    return normalized or None


def classify_source_of_funds_value(
    raw_value: str | None,
) -> tuple[str | None, str | None]:
    text = clean_text(raw_value)
    if text is not None:
        lowered = text.casefold()
        for pattern in _INVALID_PATTERNS:
            if pattern.search(lowered):
                return "invalid_source_of_funds_value", "invalid_source_of_funds_value"
    review_key = normalize_source_of_funds_review_key(raw_value)
    if review_key is None:
        return None, None
    return "unclassified", "unclassified"


def load_reviewed_source_of_funds_aliases() -> list[SourceOfFundsAliasRecord]:
    dictionary_path = files("deped_equipment").joinpath(
        "dictionaries/source_of_funds_dictionary.csv"
    )
    aliases: list[SourceOfFundsAliasRecord] = []
    with dictionary_path.open("r", encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle):
            review_status = (clean_text(row.get("review_status")) or "approved").lower()
            if review_status != "approved":
                continue
            alias_value = clean_text(row.get("alias_value"))
            canonical_name = clean_text(row.get("canonical_name"))
            if alias_value is None or canonical_name is None:
                continue
            normalized_alias_value = clean_text(row.get("normalized_alias_value")) or (
                normalize_source_of_funds_review_key(alias_value)
            )
            if normalized_alias_value is None:
                continue
            aliases.append(
                SourceOfFundsAliasRecord(
                    alias_value=alias_value,
                    normalized_alias_value=normalized_alias_value,
                    canonical_name=canonical_name,
                )
            )
    return sorted(
        aliases, key=lambda row: (row.normalized_alias_value, row.alias_value)
    )
