from __future__ import annotations

import csv
import re
import unicodedata
from dataclasses import dataclass
from importlib.resources import files

from deped_dcp_template.cleaners import clean_text

_INVALID_PATTERNS = (
    re.compile(r"^\d{2}/\d{2}/\d{4}$"),
    re.compile(r"^[✓0]$"),
)


@dataclass(frozen=True)
class EquipmentDispositionAliasRecord:
    alias_value: str
    normalized_alias_value: str
    canonical_name: str


def normalize_disposition_review_key(value: str | None) -> str | None:
    text = clean_text(value)
    if text is None:
        return None
    normalized = unicodedata.normalize("NFKC", text).casefold()
    normalized = re.sub(r"[‐‑–—−]+", "-", normalized)
    normalized = normalized.replace("&", " and ")
    normalized = re.sub(r"[^a-z0-9]+", " ", normalized)
    normalized = re.sub(r"\s+", " ", normalized).strip()
    return normalized or None


def classify_disposition_value(raw_value: str | None) -> tuple[str | None, str | None]:
    text = clean_text(raw_value)
    if text is not None:
        for pattern in _INVALID_PATTERNS:
            if pattern.search(text):
                return "invalid_disposition_value", "invalid_disposition_value"
    review_key = normalize_disposition_review_key(raw_value)
    if review_key is None:
        return None, None
    return "unclassified", "unclassified"


def load_reviewed_disposition_aliases() -> list[EquipmentDispositionAliasRecord]:
    dictionary_path = files("deped_equipment").joinpath(
        "dictionaries/disposition_status_dictionary.csv"
    )
    aliases: list[EquipmentDispositionAliasRecord] = []
    with dictionary_path.open("r", encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle):
            review_status = (clean_text(row.get("review_status")) or "approved").lower()
            if review_status != "approved":
                continue
            alias_value = clean_text(row.get("alias_value"))
            canonical_name = clean_text(row.get("canonical_name"))
            if alias_value is None or canonical_name is None:
                continue
            normalized_alias_value = clean_text(row.get("normalized_alias_value")) or (
                normalize_disposition_review_key(alias_value)
            )
            if normalized_alias_value is None:
                continue
            aliases.append(
                EquipmentDispositionAliasRecord(
                    alias_value=alias_value,
                    normalized_alias_value=normalized_alias_value,
                    canonical_name=canonical_name,
                )
            )
    return sorted(
        aliases, key=lambda row: (row.normalized_alias_value, row.alias_value)
    )
