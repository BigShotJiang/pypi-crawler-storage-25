from __future__ import annotations

import sqlite3
from contextlib import closing
from pathlib import Path
from typing import cast

import click
from rich.console import Console
from rich.progress import Progress

from .entities import load_entities
from .equipment import load_equipment
from .schema import (
    build_personnel_resolution_lookups,
    complete_build_run,
    create_indexes,
    create_schema,
    create_views,
    seed_lookup_tables,
    seed_personnel_snapshot,
    start_build_run,
)
from .types import EquipmentIssueCounter

CONSOLE = Console(stderr=True)


def prepare_output_db(db_path: str | Path) -> None:
    base = Path(db_path)
    for suffix in ("", "-wal", "-shm"):
        candidate = Path(f"{base}{suffix}")
        if candidate.exists():
            candidate.unlink()


def write_equipment_dimension_issues(
    path: str | Path, issue_counts: EquipmentIssueCounter
) -> None:
    with open(path, "w", encoding="utf-8") as handle:
        for (dimension_name, issue_type, raw_value), count in sorted(
            issue_counts.items(),
            key=lambda item: (-item[1], item[0][0], item[0][1], item[0][2]),
        ):
            handle.write(f"{count}\t{dimension_name}\t{issue_type}\t{raw_value}\n")


def build_equipment_db(
    equipment_path: str | Path,
    lookups_path: str | Path,
    entities_db_path: str | Path,
    personnel_db_path: str | Path,
    db_path: str | Path,
) -> None:
    with CONSOLE.status("Preparing equipment build...", spinner="dots"):
        prepare_output_db(db_path)
    with closing(sqlite3.connect(db_path)) as conn:
        with CONSOLE.status("Preparing equipment build...", spinner="dots"):
            create_schema(conn)
            build_run_id = start_build_run(
                conn,
                equipment_path,
                lookups_path,
                entities_db_path,
                personnel_db_path,
            )
            lookup_maps = seed_lookup_tables(conn, lookups_path, equipment_path)
        progress = Progress(console=CONSOLE)
        with progress:
            entity_lookup = load_entities(
                conn,
                entities_path=entities_db_path,
                personnel_db_path=personnel_db_path,
            )
            seed_personnel_snapshot(conn, personnel_db_path)
            resolution_lookups = build_personnel_resolution_lookups(
                personnel_db_path,
                entity_lookup,
            )
            issue_counts = load_equipment(
                conn,
                equipment_path,
                entity_lookup,
                lookup_maps,
                resolution_lookups,
                progress,
            )
        with CONSOLE.status("Finalizing equipment build...", spinner="dots"):
            create_indexes(conn)
            create_views(conn)
            complete_build_run(conn, build_run_id)
            write_equipment_dimension_issues(
                Path(db_path).with_name("equipment_dimension_issues.txt"),
                issue_counts,
            )


@click.group()
def main() -> None:
    """Equipment database utilities."""


@main.command("build")
@click.option(
    "--equipment", required=True, type=click.Path(exists=True, dir_okay=False)
)
@click.option("--lookups", required=True, type=click.Path(exists=True, dir_okay=False))
@click.option(
    "--entities-db", required=True, type=click.Path(exists=True, dir_okay=False)
)
@click.option(
    "--personnel-db", required=True, type=click.Path(exists=True, dir_okay=False)
)
@click.option("--db", "db_path", required=True, type=click.Path(dir_okay=False))
def build_command(
    equipment: str, lookups: str, entities_db: str, personnel_db: str, db_path: str
) -> None:
    build_equipment_db(equipment, lookups, entities_db, personnel_db, db_path)
    click.echo(db_path)


@main.command("audit")
@click.option(
    "--db", "db_path", required=True, type=click.Path(exists=True, dir_okay=False)
)
def audit_command(db_path: str) -> None:
    with CONSOLE.status("Auditing equipment database...", spinner="dots"):
        with closing(sqlite3.connect(db_path)) as conn:
            total_row = conn.execute("SELECT COUNT(*) FROM equipment").fetchone()
            issues_row = conn.execute(
                "SELECT COUNT(*) FROM equipment_dimension_issues"
            ).fetchone()
            if total_row is None or issues_row is None:
                raise RuntimeError("Audit queries returned no rows")
            total = cast(int, total_row[0])
            issues = cast(int, issues_row[0])
    click.echo(f"equipment_rows={total}")
    click.echo(f"dimension_issues={issues}")


if __name__ == "__main__":
    main()
