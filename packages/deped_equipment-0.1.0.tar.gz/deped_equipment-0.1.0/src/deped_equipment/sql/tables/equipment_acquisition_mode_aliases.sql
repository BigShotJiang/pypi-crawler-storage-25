CREATE TABLE equipment_acquisition_mode_aliases (
    alias_value TEXT PRIMARY KEY,
    canonical_mode_id INTEGER NOT NULL REFERENCES equipment_acquisition_modes(id)
);
