CREATE TABLE build_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    build_type TEXT NOT NULL,
    started_at TEXT NOT NULL,
    completed_at TEXT NULL,
    schema_version TEXT NOT NULL,
    lookups_source_file TEXT NOT NULL,
    lookups_source_hash TEXT NOT NULL,
    entities_source_file TEXT NOT NULL,
    entities_source_hash TEXT NOT NULL,
    personnel_source_file TEXT NOT NULL,
    personnel_source_hash TEXT NOT NULL,
    equipment_source_file TEXT NOT NULL,
    equipment_source_hash TEXT NOT NULL,
    equipment_source_rows INTEGER NOT NULL,
    entity_count INTEGER NULL,
    personnel_count INTEGER NULL,
    equipment_count INTEGER NULL
);
