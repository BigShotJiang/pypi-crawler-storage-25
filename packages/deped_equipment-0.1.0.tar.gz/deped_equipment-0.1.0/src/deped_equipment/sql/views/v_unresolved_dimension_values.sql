CREATE VIEW v_unresolved_dimension_values AS
SELECT 'unit_of_measure' AS dimension_name, unit_of_measure_raw AS raw_value, COUNT(*) AS row_count
FROM equipment
WHERE unit_of_measure_raw IS NOT NULL AND unit_of_measure_id IS NULL
GROUP BY unit_of_measure_raw
UNION ALL
SELECT 'dcp_package', dcp_package_raw, COUNT(*)
FROM equipment
WHERE dcp_package_raw IS NOT NULL AND dcp_attribution_id IS NULL
GROUP BY dcp_package_raw
UNION ALL
SELECT 'dcp_attribution', dcp_package_raw, COUNT(*)
FROM equipment
WHERE dcp_package_raw IS NOT NULL AND dcp_attribution_id IS NULL
GROUP BY dcp_package_raw
UNION ALL
SELECT 'dcp_year', dcp_year_package_raw, COUNT(*)
FROM equipment
WHERE dcp_year_package_raw IS NOT NULL AND dcp_year_package_id IS NULL
GROUP BY dcp_year_package_raw
UNION ALL
SELECT 'mode_of_acquisition', mode_of_acquisition_raw, COUNT(*)
FROM equipment
WHERE mode_of_acquisition_raw IS NOT NULL AND mode_of_acquisition_id IS NULL
GROUP BY mode_of_acquisition_raw
UNION ALL
SELECT 'source_of_acquisition', source_of_acquisition_raw, COUNT(*)
FROM equipment
WHERE source_of_acquisition_raw IS NOT NULL AND source_of_acquisition_id IS NULL
GROUP BY source_of_acquisition_raw
UNION ALL
SELECT 'equipment_location', equipment_location, COUNT(*)
FROM equipment
WHERE equipment_location IS NOT NULL AND equipment_location_id IS NULL
GROUP BY equipment_location
UNION ALL
SELECT 'supplier', supplier, COUNT(*)
FROM equipment
WHERE supplier IS NOT NULL AND supplier_id IS NULL
GROUP BY supplier
UNION ALL
SELECT 'disposition_status', disposition_status, COUNT(*)
FROM equipment
WHERE disposition_status IS NOT NULL AND disposition_status_id IS NULL
GROUP BY disposition_status
UNION ALL
SELECT 'source_of_funds', source_of_funds, COUNT(*)
FROM equipment
WHERE source_of_funds IS NOT NULL AND source_of_funds_id IS NULL
GROUP BY source_of_funds;
