from __future__ import annotations

import csv
import re
import unicodedata
from dataclasses import dataclass
from importlib.resources import files

from deped_dcp_template.cleaners import clean_text

_INVALID_PATTERNS = (
    re.compile(r"\bnot applicable\b"),
    re.compile(r"^[✓0-9]+$"),
    re.compile(r"\binventory custodian slip\b"),
    re.compile(r"\bunable to locate\b"),
    re.compile(r"\bnot found\b"),
    re.compile(r"\bstolen\b"),
    re.compile(r"\breturned\b"),
    re.compile(r"\btransferred\b"),
)


@dataclass(frozen=True)
class EquipmentConditionAliasRecord:
    alias_value: str
    normalized_alias_value: str
    canonical_name: str


def normalize_equipment_condition_review_key(value: str | None) -> str | None:
    text = clean_text(value)
    if text is None:
        return None
    normalized = unicodedata.normalize("NFKC", text).casefold()
    normalized = normalized.replace("&", " and ")
    normalized = re.sub(r"[‐‑–—−]+", "-", normalized)
    normalized = re.sub(r"[^a-z0-9]+", " ", normalized)
    normalized = re.sub(r"\s+", " ", normalized).strip()
    return normalized or None


def classify_equipment_condition_value(
    raw_value: str | None,
) -> tuple[str | None, str | None]:
    text = clean_text(raw_value)
    if text is not None:
        lowered = text.casefold()
        for pattern in _INVALID_PATTERNS:
            if pattern.search(lowered):
                return (
                    "invalid_equipment_condition_value",
                    "invalid_equipment_condition_value",
                )
    review_key = normalize_equipment_condition_review_key(raw_value)
    if review_key is None:
        return None, None
    return "unclassified", "unclassified"


def load_reviewed_equipment_condition_aliases() -> list[EquipmentConditionAliasRecord]:
    dictionary_path = files("deped_equipment").joinpath(
        "dictionaries/equipment_condition_dictionary.csv"
    )
    aliases: list[EquipmentConditionAliasRecord] = []
    with dictionary_path.open("r", encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle):
            review_status = (clean_text(row.get("review_status")) or "approved").lower()
            if review_status != "approved":
                continue
            alias_value = clean_text(row.get("alias_value"))
            canonical_name = clean_text(row.get("canonical_name"))
            if alias_value is None or canonical_name is None:
                continue
            normalized_alias_value = clean_text(row.get("normalized_alias_value")) or (
                normalize_equipment_condition_review_key(alias_value)
            )
            if normalized_alias_value is None:
                continue
            aliases.append(
                EquipmentConditionAliasRecord(
                    alias_value=alias_value,
                    normalized_alias_value=normalized_alias_value,
                    canonical_name=canonical_name,
                )
            )
    return sorted(
        aliases, key=lambda row: (row.normalized_alias_value, row.alias_value)
    )
