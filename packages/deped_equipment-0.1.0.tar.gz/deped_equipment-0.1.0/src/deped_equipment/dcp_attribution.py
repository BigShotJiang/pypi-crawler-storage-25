from __future__ import annotations

import csv
import re
import unicodedata
from dataclasses import dataclass
from importlib.resources import files

from deped_dcp_template.cleaners import clean_text

_BATCH_PATTERN = re.compile(r"\bbatch\s+(\d{1,3})\b")
_PACKAGE_PATTERN = re.compile(r"\bpackage\s+(\d{1,2})\b")
_YEAR_PATTERN = re.compile(r"\b(19|20)\d{2}\b")
_NON_DCP_PATTERN = re.compile(r"\bnon\s*dcp\b")
_RAW_INVALID_PLACEHOLDERS = frozenset({"✓"})


@dataclass(frozen=True)
class DcpAttributionCanonicalRecord:
    canonical_name: str
    canonical_type: str
    lookup_code: str | None
    lookup_name: str | None
    program_year: int | None
    batch_number: int | None
    package_number: int | None
    review_status: str
    notes: str | None


@dataclass(frozen=True)
class DcpAttributionAliasRecord:
    alias_value: str
    normalized_alias_value: str
    canonical_name: str


def normalize_dcp_attribution_review_key(value: str | None) -> str | None:
    text = clean_text(value)
    if text is None:
        return None
    normalized = unicodedata.normalize("NFKC", text).casefold()
    normalized = re.sub(r"[‐‑–—−]+", "-", normalized)
    normalized = normalized.replace("&", " and ")
    normalized = re.sub(r"\be[\s-]?learning\b", "elearning", normalized)
    normalized = re.sub(r"\be[\s-]?classroom\b", "eclassroom", normalized)
    normalized = re.sub(r"\bbatch\s*(?:no|number)\.?\s*", "batch ", normalized)
    normalized = re.sub(r"\bbatch\s*#\s*", "batch ", normalized)
    normalized = re.sub(r"\bdcp\s+project\b", "dcp", normalized)
    normalized = re.sub(r"[^a-z0-9]+", " ", normalized)
    normalized = re.sub(r"\s+", " ", normalized).strip()
    if normalized.startswith("batch "):
        normalized = f"dcp {normalized}"
    return normalized or None


_INVALID_PLACEHOLDER_REVIEW_KEYS = frozenset(
    filter(
        None,
        (
            normalize_dcp_attribution_review_key(value)
            for value in (
                "0",
                "n/a",
                "na",
                "not applicable",
                "others",
                "other",
                "dcp package",
                "nil",
                "none",
                "null",
                "check",
                "✓",
            )
        ),
    )
)


def classify_dcp_attribution_value(
    raw_value: str | None, *, is_non_dcp: bool
) -> tuple[str | None, str | None]:
    text = clean_text(raw_value)
    if text in _RAW_INVALID_PLACEHOLDERS:
        return "invalid_placeholder", "invalid_placeholder"
    review_key = normalize_dcp_attribution_review_key(raw_value)
    if is_non_dcp:
        return "non_dcp", None
    if review_key is None:
        return None, None
    if _NON_DCP_PATTERN.search(review_key):
        return "non_dcp", None
    if review_key in _INVALID_PLACEHOLDER_REVIEW_KEYS:
        return "invalid_placeholder", "invalid_placeholder"
    return "unclassified", "unclassified"


def infer_dcp_attribution_metadata(
    canonical_name: str,
) -> tuple[str, int | None, int | None, int | None]:
    review_key = normalize_dcp_attribution_review_key(canonical_name) or ""
    batch_match = _BATCH_PATTERN.search(review_key)
    package_match = _PACKAGE_PATTERN.search(review_key)
    year_match = _YEAR_PATTERN.search(review_key)
    batch_number = int(batch_match.group(1)) if batch_match else None
    package_number = int(package_match.group(1)) if package_match else None
    program_year = int(year_match.group(0)) if year_match else None
    if batch_number is not None and (
        program_year is not None or package_number is not None
    ):
        canonical_type = "hybrid_label"
    elif batch_number is not None:
        canonical_type = "batch_label"
    elif program_year is not None and package_number is not None:
        canonical_type = "hybrid_label"
    else:
        canonical_type = "named_package"
    return canonical_type, program_year, batch_number, package_number


def load_reviewed_dcp_attribution_dictionary() -> tuple[
    list[DcpAttributionCanonicalRecord],
    list[DcpAttributionAliasRecord],
]:
    dictionary_path = files("deped_equipment").joinpath(
        "dictionaries/dcp_attribution_dictionary.csv"
    )
    canonicals: dict[str, DcpAttributionCanonicalRecord] = {}
    aliases: dict[str, DcpAttributionAliasRecord] = {}
    with dictionary_path.open("r", encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle):
            canonical_name = clean_text(row.get("canonical_name"))
            if canonical_name is None:
                continue
            review_status = (clean_text(row.get("review_status")) or "approved").lower()
            if review_status != "approved":
                continue
            inferred_type, inferred_year, inferred_batch, inferred_package = (
                infer_dcp_attribution_metadata(canonical_name)
            )
            canonical = DcpAttributionCanonicalRecord(
                canonical_name=canonical_name,
                canonical_type=clean_text(row.get("canonical_type")) or inferred_type,
                lookup_code=clean_text(row.get("lookup_code")),
                lookup_name=None,
                program_year=_parse_optional_int(row.get("program_year"))
                or inferred_year,
                batch_number=_parse_optional_int(row.get("batch_number"))
                or inferred_batch,
                package_number=_parse_optional_int(row.get("package_number"))
                or inferred_package,
                review_status=review_status,
                notes=clean_text(row.get("notes")),
            )
            _merge_canonical_record(canonicals, canonical)
            alias_value = clean_text(row.get("alias_value")) or canonical_name
            normalized_alias_value = clean_text(row.get("normalized_alias_value")) or (
                normalize_dcp_attribution_review_key(alias_value)
            )
            if normalized_alias_value is None:
                continue
            aliases[normalized_alias_value] = DcpAttributionAliasRecord(
                alias_value=alias_value,
                normalized_alias_value=normalized_alias_value,
                canonical_name=canonical_name,
            )
    return sorted(canonicals.values(), key=lambda row: row.canonical_name), sorted(
        aliases.values(),
        key=lambda row: (row.normalized_alias_value, row.alias_value),
    )


def _merge_canonical_record(
    canonicals: dict[str, DcpAttributionCanonicalRecord],
    record: DcpAttributionCanonicalRecord,
) -> None:
    existing = canonicals.get(record.canonical_name)
    if existing is None:
        canonicals[record.canonical_name] = record
        return
    canonicals[record.canonical_name] = DcpAttributionCanonicalRecord(
        canonical_name=record.canonical_name,
        canonical_type=existing.canonical_type,
        lookup_code=existing.lookup_code or record.lookup_code,
        lookup_name=existing.lookup_name or record.lookup_name,
        program_year=existing.program_year or record.program_year,
        batch_number=existing.batch_number or record.batch_number,
        package_number=existing.package_number or record.package_number,
        review_status=existing.review_status,
        notes=existing.notes or record.notes,
    )


def _parse_optional_int(value: str | None) -> int | None:
    text = clean_text(value)
    if text is None:
        return None
    return int(text)
