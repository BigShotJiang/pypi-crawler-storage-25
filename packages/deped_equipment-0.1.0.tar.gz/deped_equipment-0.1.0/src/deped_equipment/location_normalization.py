from __future__ import annotations

import csv
import re
import unicodedata
from dataclasses import dataclass
from importlib.resources import files

from deped_dcp_template.cleaners import clean_text

_ALS_PATTERN = re.compile(r"\bals\b")
_CLASSROOM_PATTERN = re.compile(
    r"\b(classroom|class room|classrooms|grade\s+\d+(\s+classroom|\s+room)?|kinder(garten)?\s+(classroom|room)|grade\s+\d+\s+room)\b"
)
_ICT_LAB_PATTERN = re.compile(
    r"\b(ict|computer|comlab|eclassroom|e room|e-room|laboratory|laboratories|lab)\b"
)
_PRINCIPAL_PATTERN = re.compile(r"\b(principal|school head)\b")
_FACULTY_PATTERN = re.compile(r"\bfaculty\b")
_STOCK_ROOM_PATTERN = re.compile(
    r"\b(stock\s*room|storage\s*room|stockroom|supply\s*room|supply\s*office|property\s*room|physical facilities room)\b"
)
_LIB_PATTERN = re.compile(r"\b(library|e library|e-library|lib)\b")
_ADMIN_PATTERN = re.compile(
    r"\b(admin(istrative)?|office|division office|sdo|accounting office|cid|sgod)\b"
)
_GENERIC_INVALID_PATTERN = re.compile(
    r"\b(school|elementary school|high school|building|teacher)\b"
)


@dataclass(frozen=True)
class EquipmentLocationAliasRecord:
    alias_value: str
    normalized_alias_value: str
    canonical_name: str


def normalize_equipment_location_review_key(value: str | None) -> str | None:
    text = clean_text(value)
    if text is None:
        return None
    normalized = unicodedata.normalize("NFKC", text).casefold()
    normalized = re.sub(r"[‐‑–—−]+", "-", normalized)
    normalized = normalized.replace("&", " and ")
    normalized = re.sub(r"\be[\s-]?classroom\b", "eclassroom", normalized)
    normalized = re.sub(r"\be[\s-]?library\b", "elibrary", normalized)
    normalized = re.sub(r"\bprincipal'?s\b", "principal", normalized)
    normalized = re.sub(r"[^a-z0-9]+", " ", normalized)
    normalized = re.sub(r"\s+", " ", normalized).strip()
    return normalized or None


def classify_equipment_location_value(
    raw_value: str | None,
) -> tuple[str | None, str | None]:
    review_key = normalize_equipment_location_review_key(raw_value)
    if review_key is None:
        return None, None
    if _GENERIC_INVALID_PATTERN.search(review_key):
        if not (
            _CLASSROOM_PATTERN.search(review_key)
            or _ICT_LAB_PATTERN.search(review_key)
            or _PRINCIPAL_PATTERN.search(review_key)
            or _FACULTY_PATTERN.search(review_key)
            or _STOCK_ROOM_PATTERN.search(review_key)
            or _LIB_PATTERN.search(review_key)
            or _ADMIN_PATTERN.search(review_key)
            or _ALS_PATTERN.search(review_key)
        ):
            return "invalid_generic_location", "invalid_generic_location"
    return "unclassified", "unclassified"


def infer_equipment_location_canonical(review_key: str | None) -> str | None:
    if review_key is None:
        return None
    if _ALS_PATTERN.search(review_key):
        return "als"
    if _LIB_PATTERN.search(review_key):
        return "lib"
    if _PRINCIPAL_PATTERN.search(review_key):
        return "principal"
    if _FACULTY_PATTERN.search(review_key):
        return "faculty"
    if _STOCK_ROOM_PATTERN.search(review_key):
        return "stock room"
    if _CLASSROOM_PATTERN.search(review_key):
        return "classroom"
    if _ICT_LAB_PATTERN.search(review_key):
        return "ict/lab"
    if _ADMIN_PATTERN.search(review_key):
        return "admin/office"
    return None


def load_reviewed_equipment_location_aliases() -> list[EquipmentLocationAliasRecord]:
    dictionary_path = files("deped_equipment").joinpath(
        "dictionaries/equipment_location_dictionary.csv"
    )
    aliases: list[EquipmentLocationAliasRecord] = []
    with dictionary_path.open("r", encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle):
            review_status = (clean_text(row.get("review_status")) or "approved").lower()
            if review_status != "approved":
                continue
            alias_value = clean_text(row.get("alias_value"))
            canonical_name = clean_text(row.get("canonical_name"))
            if alias_value is None or canonical_name is None:
                continue
            normalized_alias_value = clean_text(row.get("normalized_alias_value")) or (
                normalize_equipment_location_review_key(alias_value)
            )
            if normalized_alias_value is None:
                continue
            aliases.append(
                EquipmentLocationAliasRecord(
                    alias_value=alias_value,
                    normalized_alias_value=normalized_alias_value,
                    canonical_name=canonical_name,
                )
            )
    return sorted(
        aliases, key=lambda row: (row.normalized_alias_value, row.alias_value)
    )
