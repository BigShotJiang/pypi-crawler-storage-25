from __future__ import annotations

import csv
import re
import unicodedata
from dataclasses import dataclass
from importlib.resources import files

from deped_dcp_template.cleaners import clean_text

_INTERNAL_SUPPLIER_PATTERNS = (
    re.compile(r"\bdeped\b"),
    re.compile(r"\bcentral office\b"),
    re.compile(r"\bdivision office\b"),
    re.compile(r"\bsdo\b"),
    re.compile(r"\blgu\b"),
    re.compile(r"\bnot applicable\b"),
)


@dataclass(frozen=True)
class EquipmentSupplierAliasRecord:
    alias_value: str
    normalized_alias_value: str
    canonical_name: str


def normalize_supplier_review_key(value: str | None) -> str | None:
    text = clean_text(value)
    if text is None:
        return None
    normalized = unicodedata.normalize("NFKC", text).casefold()
    normalized = normalized.replace("&", " and ")
    normalized = re.sub(r"[‐‑–—−]+", "-", normalized)
    normalized = re.sub(r"\bincorporated\b", "inc", normalized)
    normalized = re.sub(r"\bphilippines\b", "phils", normalized)
    normalized = re.sub(r"\bcorporation\b", "corp", normalized)
    normalized = re.sub(r"\bmarketing\b", "mktg", normalized)
    normalized = re.sub(r"\bjv\b", "joint venture", normalized)
    normalized = re.sub(r"[^a-z0-9]+", " ", normalized)
    normalized = re.sub(r"\s+", " ", normalized).strip()
    return normalized or None


def classify_supplier_value(raw_value: str | None) -> tuple[str | None, str | None]:
    review_key = normalize_supplier_review_key(raw_value)
    if review_key is None:
        return None, None
    for pattern in _INTERNAL_SUPPLIER_PATTERNS:
        if pattern.search(review_key):
            return "internal_or_non_supplier", "internal_or_non_supplier"
    return "unclassified", "unclassified"


def load_reviewed_supplier_aliases() -> list[EquipmentSupplierAliasRecord]:
    dictionary_path = files("deped_equipment").joinpath(
        "dictionaries/supplier_dictionary.csv"
    )
    aliases: list[EquipmentSupplierAliasRecord] = []
    with dictionary_path.open("r", encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle):
            review_status = (clean_text(row.get("review_status")) or "approved").lower()
            if review_status != "approved":
                continue
            alias_value = clean_text(row.get("alias_value"))
            canonical_name = clean_text(row.get("canonical_name"))
            if alias_value is None or canonical_name is None:
                continue
            normalized_alias_value = clean_text(row.get("normalized_alias_value")) or (
                normalize_supplier_review_key(alias_value)
            )
            if normalized_alias_value is None:
                continue
            aliases.append(
                EquipmentSupplierAliasRecord(
                    alias_value=alias_value,
                    normalized_alias_value=normalized_alias_value,
                    canonical_name=canonical_name,
                )
            )
    return sorted(
        aliases, key=lambda row: (row.normalized_alias_value, row.alias_value)
    )
