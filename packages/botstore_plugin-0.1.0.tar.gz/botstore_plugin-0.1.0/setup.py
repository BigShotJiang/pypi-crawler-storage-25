from pathlib import Path
from setuptools import setup

ROOT = Path(__file__).resolve().parent
README = (ROOT / "README-pypi.md").read_text(encoding="utf-8")

setup(
    name="botstore-plugin",
    version="0.1.0",
    description="BotStore host-bot plugin and connect CLI",
    long_description=README,
    long_description_content_type="text/markdown",
    author="BotStore",
    python_requires=">=3.10",
    py_modules=["botstore_plugin", "botstore_cli"],
    packages=["adapters"],
    entry_points={"console_scripts": ["botstore=botstore_cli:main"]},
)
