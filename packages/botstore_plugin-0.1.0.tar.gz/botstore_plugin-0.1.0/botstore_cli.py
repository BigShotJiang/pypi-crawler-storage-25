#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import urllib.error
import urllib.request
from pathlib import Path

DEFAULT_API = os.getenv("BOTSTORE_API", "http://127.0.0.1:8787")
CONFIG_DIR = Path.home() / ".config" / "botstore"
CONFIG_PATH = CONFIG_DIR / "config.json"


def load_config() -> dict:
    if CONFIG_PATH.exists():
        return json.loads(CONFIG_PATH.read_text())
    return {}


def save_config(data: dict) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(data, indent=2) + "\n")


def api_request(api_base: str, method: str, path: str, payload: dict | None = None) -> dict:
    body = None
    headers = {"Accept": "application/json"}
    if payload is not None:
        body = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(f"{api_base.rstrip('/')}{path}", data=body, headers=headers, method=method)
    with urllib.request.urlopen(req) as resp:
        raw = resp.read().decode("utf-8")
        return json.loads(raw) if raw else {}


def cmd_connect(args: argparse.Namespace) -> int:
    api_base = args.api.rstrip("/")
    cfg = load_config()
    cfg.update({"api_base": api_base, "connect_token": args.token})
    if args.botstore_key:
        cfg["botstore_key"] = args.botstore_key

    runtime_id = args.runtime_id
    agent_id = args.agent_id
    mode = "token_bootstrap"
    claimed = None

    if not args.bootstrap_only:
        try:
            claimed = api_request(
                api_base,
                "POST",
                "/connect/session/claim",
                {
                    "token": args.token,
                    "runtime_id": args.runtime_id,
                    "agent_id": args.agent_id,
                    "channel": args.channel,
                    "client_name": "botstore-cli",
                    "client_version": "0.1.0",
                    "set_default": not args.no_default,
                },
            )
            runtime_id = claimed.get("runtime_id") or runtime_id
            agent_id = claimed.get("agent_id") or agent_id
            cfg["connect_session_id"] = claimed.get("session_id")
            cfg["claimed_at"] = claimed.get("claimed_at")
            mode = "claimed"
        except urllib.error.HTTPError as exc:
            if exc.code not in {404, 405, 501}:
                detail = exc.read().decode("utf-8", errors="replace")
                print(f"BotStore connect failed: HTTP {exc.code} {detail}")
                return 1
        except Exception as exc:
            print(f"BotStore connect failed: {exc}")
            return 1

    cfg["connected"] = True
    cfg["connection_mode"] = mode
    if runtime_id:
        cfg["runtime_id"] = runtime_id
    if agent_id:
        cfg["agent_id"] = agent_id
    if args.channel:
        cfg["channel"] = args.channel
    save_config(cfg)

    if mode == "claimed":
        print("BotStore connect session claimed")
        print(f"- API: {cfg['api_base']}")
        print("- Mode: claimed")
        if runtime_id and agent_id:
            print(f"- Target: {runtime_id}/{agent_id}")
        if cfg.get("connect_session_id"):
            print(f"- Session: {cfg['connect_session_id']}")
        return 0

    print("BotStore connection bootstrap saved")
    print(f"- API: {cfg['api_base']}")
    print("- Mode: token_bootstrap")
    if cfg.get("runtime_id") and cfg.get("agent_id"):
        print(f"- Target hint: {cfg['runtime_id']}/{cfg['agent_id']}")
    print("- Next step: exchange this token against BotStore connect endpoints when server-side claim flow is available")
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    cfg = load_config()
    if not cfg:
        print("BotStore not connected yet")
        print("Try: botstore connect --token <token> --api <url>")
        return 1

    print("BotStore local connection status")
    print(f"- Connected: {cfg.get('connected', False)}")
    print(f"- API: {cfg.get('api_base', DEFAULT_API)}")
    print(f"- Mode: {cfg.get('connection_mode', 'unknown')}")
    if cfg.get("runtime_id"):
        print(f"- Runtime: {cfg.get('runtime_id')}")
    if cfg.get("agent_id"):
        print(f"- Agent: {cfg.get('agent_id')}")
    if cfg.get("channel"):
        print(f"- Channel: {cfg.get('channel')}")
    if cfg.get("connect_session_id"):
        print(f"- Session: {cfg.get('connect_session_id')}")

    if args.remote and cfg.get("connect_session_id"):
        try:
            remote = api_request(cfg.get("api_base", DEFAULT_API), "GET", f"/connect/session/status?session_id={cfg['connect_session_id']}")
            print("- Remote status:")
            print(f"  - State: {remote.get('status')}")
            if remote.get("claimed_runtime_id"):
                print(f"  - Claimed target: {remote.get('claimed_runtime_id')}/{remote.get('claimed_agent_id')}")
            if remote.get("expires_at"):
                print(f"  - Expires: {remote.get('expires_at')}")
        except Exception as exc:
            print(f"- Remote status lookup failed: {exc}")

    print(f"- Config: {CONFIG_PATH}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="botstore", description="BotStore connect CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    p_connect = sub.add_parser("connect", help="Bootstrap or claim a BotStore connection")
    p_connect.add_argument("--token", required=True, help="Short-lived BotStore connect token")
    p_connect.add_argument("--api", default=DEFAULT_API, help="BotStore API base URL")
    p_connect.add_argument("--botstore-key", default=None, help="Optional BotStore API key")
    p_connect.add_argument("--runtime-id", default=None, help="Optional runtime id to claim/bind")
    p_connect.add_argument("--agent-id", default=None, help="Optional agent id to claim/bind")
    p_connect.add_argument("--channel", default=None, help="Optional channel label for this target")
    p_connect.add_argument("--bootstrap-only", action="store_true", help="Skip server-side claim and store token locally only")
    p_connect.add_argument("--no-default", action="store_true", help="Do not set claimed target as default")
    p_connect.set_defaults(func=cmd_connect)

    p_status = sub.add_parser("status", help="Show local BotStore connection status")
    p_status.add_argument("--remote", action="store_true", help="Also query BotStore for remote connect-session status")
    p_status.set_defaults(func=cmd_status)

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
