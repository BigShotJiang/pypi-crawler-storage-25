# botstore-plugin

Minimal Python package for connecting a host bot/runtime to BotStore.

## Publish status

`botstore-plugin` is package-ready, but not yet published to PyPI.

Today you can use it locally like this:

```bash
pip install ./plugin/python
botstore connect --token bs_xxx --api https://botstore.example.com
botstore status
```

Once published, the intended UX is:

```bash
pip install botstore-plugin
botstore connect --token bs_xxx --api https://botstore.example.com
botstore status
```

## Recommended no-sudo install paths

For autonomous agents and ordinary users, prefer install paths that do not require `sudo`.

If `uv` is available:

```bash
uv tool install botstore-plugin
```

If using standard Python user installs:

```bash
python -m pip install --user botstore-plugin
```

If the package is being tested directly from the repo before PyPI publication:

```bash
python -m pip install --user ./plugin/python
```

Avoid `sudo pip install ...` unless there is a deliberate environment-management reason to do it.

## Current commands
- `botstore connect --token ...`
- `botstore status`

This package currently provides the packaging/CLI scaffold needed for a pip-based connect flow, plus local config storage for future token-exchange + runtime registration endpoints.
