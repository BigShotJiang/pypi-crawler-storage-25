"""JAX integration — convert episodes and windows to JAX arrays."""

from __future__ import annotations

from typing import Any, Iterator

import numpy as np

try:
    import jax
    import jax.numpy as jnp
except ImportError:
    raise ImportError(
        "JAX is required for traceplane.jax. "
        "Install it with: pip install traceplane[jax]"
    )

from traceplane.dataset import TrajectoryDataset
from traceplane.windowing import WindowedDataset


def episodes_to_jax(
    dataset: TrajectoryDataset,
) -> list[dict[str, Any]]:
    """Convert all episodes to dicts of JAX arrays.

    Returns a list of dicts, each containing:
        - ``actions``: jax array (T, action_dim)
        - ``timestamps``: jax array (T,)
        - observation keys: jax arrays
        - ``episode_id``: str
        - ``metadata``: dict
    """
    results = []
    for ep in dataset:
        item: dict[str, Any] = {
            "episode_id": ep.episode_id,
            "metadata": ep.metadata,
            "actions": jnp.array(ep.actions, dtype=jnp.float32),
            "timestamps": jnp.array(ep.timestamps, dtype=jnp.float64),
        }
        for key, arr in ep.observations.items():
            item[key] = jnp.array(arr, dtype=jnp.float32)
        results.append(item)
    return results


def windowed_iterator(
    dataset: TrajectoryDataset,
    obs_horizon: int = 2,
    action_horizon: int = 16,
    stride: int = 1,
    batch_size: int = 64,
    shuffle: bool = True,
    seed: int = 0,
) -> Iterator[dict[str, Any]]:
    """Yield batched training windows as dicts of JAX arrays.

    Args:
        dataset: Source trajectory dataset.
        obs_horizon: Observation history length.
        action_horizon: Action prediction horizon.
        stride: Window stride.
        batch_size: Batch size.
        shuffle: Shuffle sample order.
        seed: Random seed for shuffling.

    Yields:
        Dicts with ``obs_history`` (dict of jax arrays), ``action_chunk``
        (jax array), ``episode_ids`` (list[str]), ``timesteps`` (list[int]).
    """
    windowed = WindowedDataset(
        dataset,
        obs_horizon=obs_horizon,
        action_horizon=action_horizon,
        stride=stride,
    )

    indices = np.arange(len(windowed))
    if shuffle:
        rng = np.random.default_rng(seed)
        rng.shuffle(indices)

    for start in range(0, len(indices), batch_size):
        batch_indices = indices[start : start + batch_size]
        windows = [windowed[int(i)] for i in batch_indices]

        # Collate
        obs_keys = set()
        for w in windows:
            obs_keys.update(w.obs_history.keys())

        batch: dict[str, Any] = {
            "episode_ids": [w.episode_id for w in windows],
            "timesteps": [w.timestep for w in windows],
            "action_chunk": jnp.stack(
                [jnp.array(w.action_chunk, dtype=jnp.float32) for w in windows]
            ),
            "obs_history": {},
        }
        for key in obs_keys:
            arrays = [
                jnp.array(w.obs_history.get(key, np.zeros((obs_horizon, 1))), dtype=jnp.float32)
                for w in windows
            ]
            batch["obs_history"][key] = jnp.stack(arrays)

        yield batch
