"""traceplane mix — recipe-based dataset compiler.

Defines reproducible dataset mixtures from multiple sources with
provenance tracking, tier balancing, and task weighting.

Usage::

    from traceplane.mix import compile_mix, MixRecipe, MixSource

    recipe = MixRecipe(
        name="training_v3",
        sources=[
            MixSource(path="/data/real", weight=0.7, tier="task_specific"),
            MixSource(path="/data/sim", weight=0.3, tier="pretraining"),
        ],
        total_episodes=1000,
    )
    result = compile_mix(recipe)
    result.print()
    result.save_recipe("recipe.json")
"""

from __future__ import annotations

import json
import random
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np

from traceplane import report


@dataclass
class MixSource:
    """A dataset source in a mix recipe."""
    path: str
    weight: float = 1.0       # relative sampling weight
    tier: str | None = None   # "pretraining", "task_specific", "recovery"
    tag: str | None = None    # freeform provenance tag (e.g. "sim", "real", "augmented")
    max_episodes: int | None = None  # cap on episodes from this source
    task_filter: str | None = None   # only include episodes matching this task


@dataclass
class MixRecipe:
    """A reproducible dataset mixture specification."""
    name: str
    sources: list[MixSource]
    total_episodes: int | None = None  # target count (None = use all)
    seed: int = 42
    description: str = ""


@dataclass
class SelectedEpisode:
    source_path: str
    source_index: int   # index within source dataset
    episode_id: str
    task_label: str
    length: int
    tier: str | None
    tag: str | None


@dataclass
class MixResult:
    recipe_name: str
    total_episodes: int = 0
    total_frames: int = 0
    sources_used: int = 0
    episodes: list[SelectedEpisode] = field(default_factory=list)

    # Per-source breakdown
    source_counts: list[tuple[str, int]] = field(default_factory=list)
    tier_counts: list[tuple[str, int]] = field(default_factory=list)
    tag_counts: list[tuple[str, int]] = field(default_factory=list)
    task_counts: list[tuple[str, int]] = field(default_factory=list)

    def print(self) -> None:
        print(f"\n{'='*60}")
        print(f"  traceplane mix — {self.recipe_name}")
        print(f"{'='*60}")
        print(f"  Total episodes: {self.total_episodes}")
        print(f"  Total frames:   {self.total_frames:,}")
        print(f"  Sources:        {self.sources_used}")
        print()

        if self.source_counts:
            print(f"  Per source:")
            for name, count in self.source_counts:
                print(f"    {name:<30} {count:>5}")
            print()

        if self.tier_counts:
            print(f"  Per tier:")
            for tier, count in self.tier_counts:
                print(f"    {tier:<20} {count:>5}")
            print()

        if self.task_counts:
            print(f"  Tasks ({len(self.task_counts)} unique):")
            for task, count in self.task_counts[:10]:
                print(f"    {task:<35} {count:>5}")
            if len(self.task_counts) > 10:
                print(f"    ... and {len(self.task_counts) - 10} more")

        print(f"\n{'='*60}\n")

    def to_html(self, path: str) -> None:
        body = _render_html(self)
        html = report.html_document(f"Mix Report — {self.recipe_name}", body)
        Path(path).write_text(html)

    def save_recipe(self, path: str) -> None:
        """Save the recipe + selected indices for reproducibility."""
        Path(path).write_text(json.dumps({
            "recipe_name": self.recipe_name,
            "total_episodes": self.total_episodes,
            "total_frames": self.total_frames,
            "episodes": [
                {
                    "source": ep.source_path,
                    "index": ep.source_index,
                    "episode_id": ep.episode_id,
                    "task": ep.task_label,
                    "length": ep.length,
                    "tier": ep.tier,
                    "tag": ep.tag,
                }
                for ep in self.episodes
            ],
        }, indent=2))

    def episode_indices_by_source(self) -> dict[str, list[int]]:
        """Return {source_path: [indices]} for loading."""
        by_source: dict[str, list[int]] = {}
        for ep in self.episodes:
            by_source.setdefault(ep.source_path, []).append(ep.source_index)
        return by_source


def compile_mix(recipe: MixRecipe) -> MixResult:
    """Compile a dataset mix from a recipe.

    Args:
        recipe: The :class:`MixRecipe` specifying sources and weights.

    Returns:
        A :class:`MixResult` with the selected episodes.
    """
    from traceplane.lerobot_reader import LeRobotReader

    rng = random.Random(recipe.seed)
    result = MixResult(recipe_name=recipe.name)

    # Load candidates from each source
    all_candidates: list[tuple[MixSource, list[SelectedEpisode]]] = []

    for source in recipe.sources:
        try:
            reader = LeRobotReader(source.path)
        except Exception:
            continue

        candidates: list[SelectedEpisode] = []
        indices = list(range(len(reader)))
        if source.max_episodes:
            indices = indices[:source.max_episodes]

        for idx in indices:
            ep = reader[idx]
            task = ep.metadata.get("task_label", "")

            # Apply task filter
            if source.task_filter and source.task_filter.lower() not in task.lower():
                continue

            candidates.append(SelectedEpisode(
                source_path=source.path,
                source_index=ep.metadata.get("episode_index", idx),
                episode_id=ep.episode_id,
                task_label=task,
                length=ep.length,
                tier=source.tier,
                tag=source.tag,
            ))

        all_candidates.append((source, candidates))

    if not all_candidates:
        return result

    # Weighted sampling
    target = recipe.total_episodes
    if target is None:
        # Use all candidates
        for _, candidates in all_candidates:
            result.episodes.extend(candidates)
    else:
        # Compute per-source quotas based on weights
        total_weight = sum(s.weight for s, _ in all_candidates)
        for source, candidates in all_candidates:
            quota = int((source.weight / total_weight) * target)
            quota = min(quota, len(candidates))

            rng.shuffle(candidates)
            result.episodes.extend(candidates[:quota])

    # Compute stats
    result.total_episodes = len(result.episodes)
    result.total_frames = sum(ep.length for ep in result.episodes)
    result.sources_used = len(set(ep.source_path for ep in result.episodes))

    source_counter: Counter[str] = Counter()
    tier_counter: Counter[str] = Counter()
    tag_counter: Counter[str] = Counter()
    task_counter: Counter[str] = Counter()

    for ep in result.episodes:
        source_counter[Path(ep.source_path).name] += 1
        if ep.tier:
            tier_counter[ep.tier] += 1
        if ep.tag:
            tag_counter[ep.tag] += 1
        if ep.task_label:
            task_counter[ep.task_label] += 1

    result.source_counts = source_counter.most_common()
    result.tier_counts = tier_counter.most_common()
    result.tag_counts = tag_counter.most_common()
    result.task_counts = task_counter.most_common()

    return result


def load_recipe(path: str) -> MixRecipe:
    """Load a recipe from a JSON file.

    Expected format::

        {
            "name": "training_v3",
            "total_episodes": 1000,
            "seed": 42,
            "sources": [
                {"path": "/data/real", "weight": 0.7, "tier": "task_specific"},
                {"path": "/data/sim", "weight": 0.3, "tag": "sim"}
            ]
        }
    """
    data = json.loads(Path(path).read_text())
    sources = [
        MixSource(
            path=s["path"],
            weight=s.get("weight", 1.0),
            tier=s.get("tier"),
            tag=s.get("tag"),
            max_episodes=s.get("max_episodes"),
            task_filter=s.get("task_filter"),
        )
        for s in data.get("sources", [])
    ]
    return MixRecipe(
        name=data.get("name", "unnamed"),
        sources=sources,
        total_episodes=data.get("total_episodes"),
        seed=data.get("seed", 42),
        description=data.get("description", ""),
    )


# ---------------------------------------------------------------------------
# HTML report
# ---------------------------------------------------------------------------

def _render_html(result: MixResult) -> str:
    stats = "".join([
        report.stat_card(str(result.total_episodes), "Total episodes"),
        report.stat_card(f"{result.total_frames:,}", "Total frames"),
        report.stat_card(str(result.sources_used), "Sources"),
        report.stat_card(str(len(result.task_counts)), "Unique tasks"),
    ])

    # Source distribution
    source_html = ""
    if result.source_counts:
        source_html = f"""<h2>Per-Source Distribution</h2>
<div class="card">{report.distribution_chart(result.source_counts)}</div>"""

    # Tier distribution
    tier_html = ""
    if result.tier_counts:
        tier_html = f"""<h2>Data Tier Distribution</h2>
<div class="card">{report.distribution_chart(result.tier_counts)}</div>"""

    # Tag distribution (sim/real/augmented)
    tag_html = ""
    if result.tag_counts:
        tag_html = f"""<h2>Data Source Tags</h2>
<div class="card">{report.distribution_chart(result.tag_counts)}</div>"""

    # Task distribution
    task_html = ""
    if result.task_counts:
        task_html = f"""<h2>Task Distribution</h2>
<div class="card">{report.distribution_chart(result.task_counts[:20])}</div>"""

    return f"""
<h1>Mix Report</h1>
<p class="subtitle">{result.recipe_name}</p>

<div class="stats-row">{stats}</div>

{source_html}
{tier_html}
{tag_html}
{task_html}

<div class="recommendation">
  <strong>Reproducibility:</strong> Save with <code>result.save_recipe("recipe.json")</code>.
  Reload with <code>traceplane.mix.load_recipe("recipe.json")</code>.
</div>
"""
