"""traceplane coverage — coverage-gap analysis and collection recommendations.

Computes distribution maps over tasks, action space regions, episode lengths,
and embodiments. Supports cross-dataset analysis. Identifies gaps and
recommends what data to collect next.

Usage::

    from traceplane.coverage import analyze_coverage
    result = analyze_coverage(["/data/dataset1", "/data/dataset2"])
    result.print()
    result.to_html("coverage_report.html")
"""

from __future__ import annotations

import json
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np

from traceplane import report


@dataclass
class GapRecommendation:
    category: str  # "task", "length", "action_space", "embodiment"
    message: str
    priority: str  # "high", "medium", "low"


@dataclass
class DatasetSummary:
    path: str
    episode_count: int
    format_version: str
    robot_type: str
    fps: float


@dataclass
class CoverageResult:
    dataset_paths: list[str]
    datasets: list[DatasetSummary] = field(default_factory=list)
    total_episodes: int = 0
    total_frames: int = 0

    # Distribution maps
    task_distribution: list[tuple[str, int]] = field(default_factory=list)
    length_distribution: list[tuple[str, int]] = field(default_factory=list)
    embodiment_distribution: list[tuple[str, int]] = field(default_factory=list)
    action_dim_distribution: list[tuple[str, int]] = field(default_factory=list)
    dataset_distribution: list[tuple[str, int]] = field(default_factory=list)

    # Action space coverage
    action_space_coverage: float = 0.0  # 0-1, fraction of bins occupied
    action_dim: int = 0

    # Gaps and recommendations
    recommendations: list[GapRecommendation] = field(default_factory=list)

    def print(self) -> None:
        print(f"\n{'='*60}")
        print(f"  traceplane coverage — {len(self.dataset_paths)} dataset(s)")
        print(f"{'='*60}")
        print(f"  Total episodes:  {self.total_episodes}")
        print(f"  Total frames:    {self.total_frames:,}")
        print(f"  Datasets:        {len(self.datasets)}")
        print()

        if self.task_distribution:
            print(f"  Tasks ({len(self.task_distribution)} unique):")
            for task, count in self.task_distribution[:10]:
                print(f"    {task:<40} {count:>5}")
            if len(self.task_distribution) > 10:
                print(f"    ... and {len(self.task_distribution) - 10} more")
            print()

        if self.recommendations:
            print(f"  Recommendations:")
            for r in self.recommendations:
                icon = {"high": "!!!", "medium": "!!", "low": "!"}.get(r.priority, "!")
                print(f"    [{icon}] [{r.category}] {r.message}")
            print()

        print(f"{'='*60}\n")

    def to_html(self, path: str) -> None:
        body = _render_html(self)
        html = report.html_document(
            f"Coverage Report — {len(self.dataset_paths)} dataset(s)",
            body,
        )
        Path(path).write_text(html)

    def to_dict(self) -> dict[str, Any]:
        return {
            "dataset_paths": self.dataset_paths,
            "total_episodes": self.total_episodes,
            "total_frames": self.total_frames,
            "datasets": [
                {"path": d.path, "episodes": d.episode_count,
                 "format": d.format_version, "robot": d.robot_type}
                for d in self.datasets
            ],
            "task_distribution": dict(self.task_distribution),
            "length_distribution": dict(self.length_distribution),
            "embodiment_distribution": dict(self.embodiment_distribution),
            "action_dim_distribution": dict(self.action_dim_distribution),
            "action_space_coverage": round(self.action_space_coverage, 4),
            "recommendations": [
                {"category": r.category, "message": r.message, "priority": r.priority}
                for r in self.recommendations
            ],
        }


def analyze_coverage(
    paths: list[str],
    max_episodes_per_dataset: int | None = None,
    action_bins: int = 10,
) -> CoverageResult:
    """Analyze coverage across one or more datasets.

    Args:
        paths: List of dataset root paths.
        max_episodes_per_dataset: Max episodes to sample per dataset.
        action_bins: Number of bins per dimension for action space coverage.

    Returns:
        A :class:`CoverageResult` with distributions, gaps, and recommendations.
    """
    from traceplane.lerobot_reader import LeRobotReader

    result = CoverageResult(dataset_paths=paths)

    all_tasks: Counter[str] = Counter()
    all_lengths: list[int] = []
    all_embodiments: Counter[str] = Counter()
    all_action_dims: Counter[int] = Counter()
    all_actions: list[np.ndarray] = []
    dataset_episode_counts: Counter[str] = Counter()

    for ds_path in paths:
        try:
            reader = LeRobotReader(ds_path)
        except Exception as e:
            continue

        info = reader.info
        robot_type = info.get("robot_type", "unknown")
        ds_name = Path(ds_path).name

        result.datasets.append(DatasetSummary(
            path=ds_path,
            episode_count=len(reader),
            format_version=reader.version,
            robot_type=robot_type or "unknown",
            fps=reader.fps,
        ))

        indices = list(range(len(reader)))
        if max_episodes_per_dataset:
            indices = indices[:max_episodes_per_dataset]

        for idx in indices:
            ep = reader[idx]
            task = ep.metadata.get("task_label", "unknown")
            if task:
                all_tasks[task] += 1
            all_lengths.append(ep.length)
            all_embodiments[robot_type or "unknown"] += 1
            dataset_episode_counts[ds_name] += 1

            if ep.actions.ndim == 2 and ep.actions.shape[0] > 0:
                all_action_dims[ep.actions.shape[1]] += 1
                all_actions.append(ep.actions)

            result.total_episodes += 1
            result.total_frames += ep.length

    # Build distributions
    result.task_distribution = all_tasks.most_common()
    result.embodiment_distribution = all_embodiments.most_common()
    result.action_dim_distribution = [
        (f"{dim}D", count) for dim, count in sorted(all_action_dims.items())
    ]
    result.dataset_distribution = dataset_episode_counts.most_common()

    # Length distribution (bucketed)
    if all_lengths:
        result.length_distribution = _bucket_lengths(all_lengths)

    # Action space coverage (group by dimension to avoid concat mismatch)
    if all_actions:
        # Use only the most common action dimension
        dim_counts: Counter[int] = Counter()
        for a in all_actions:
            if a.ndim == 2:
                dim_counts[a.shape[1]] += 1
        if dim_counts:
            most_common_dim = dim_counts.most_common(1)[0][0]
            filtered = [a for a in all_actions if a.ndim == 2 and a.shape[1] == most_common_dim]
            if filtered:
                result.action_space_coverage, result.action_dim = _compute_action_coverage(
                    filtered, action_bins
                )

    # Generate recommendations
    result.recommendations = _generate_recommendations(result, all_tasks, all_lengths)

    return result


def _bucket_lengths(lengths: list[int]) -> list[tuple[str, int]]:
    """Bucket episode lengths into ranges."""
    if not lengths:
        return []

    arr = np.array(lengths)
    p25, p50, p75, p95 = np.percentile(arr, [25, 50, 75, 95])

    buckets: Counter[str] = Counter()
    for l in lengths:
        if l < 10:
            buckets["< 10"] += 1
        elif l < 50:
            buckets["10-49"] += 1
        elif l < 100:
            buckets["50-99"] += 1
        elif l < 200:
            buckets["100-199"] += 1
        elif l < 500:
            buckets["200-499"] += 1
        elif l < 1000:
            buckets["500-999"] += 1
        else:
            buckets["1000+"] += 1

    order = ["< 10", "10-49", "50-99", "100-199", "200-499", "500-999", "1000+"]
    return [(k, buckets.get(k, 0)) for k in order if buckets.get(k, 0) > 0]


def _compute_action_coverage(
    actions_list: list[np.ndarray],
    n_bins: int,
) -> tuple[float, int]:
    """Estimate action space coverage via binning."""
    if not actions_list:
        return 0.0, 0

    # Stack all actions
    all_actions = np.concatenate(actions_list, axis=0)
    action_dim = all_actions.shape[1]

    # Normalize to [0, 1] per dimension
    mins = np.min(all_actions, axis=0)
    maxs = np.max(all_actions, axis=0)
    ranges = maxs - mins + 1e-8
    normalized = (all_actions - mins) / ranges

    # Bin each dimension and count unique bin combinations
    # Use a subset of dimensions if too many (avoid memory explosion)
    dims_to_use = min(action_dim, 6)
    binned = np.floor(normalized[:, :dims_to_use] * n_bins).astype(int)
    binned = np.clip(binned, 0, n_bins - 1)

    # Count unique bin combinations
    unique_bins = set(map(tuple, binned))
    total_bins = n_bins ** dims_to_use
    coverage = len(unique_bins) / total_bins

    return float(coverage), action_dim


def _generate_recommendations(
    result: CoverageResult,
    task_counts: Counter[str],
    lengths: list[int],
) -> list[GapRecommendation]:
    """Generate collection recommendations from coverage analysis."""
    recs: list[GapRecommendation] = []

    # Task imbalance
    if task_counts:
        counts = list(task_counts.values())
        max_count = max(counts)
        min_count = min(counts)

        if max_count > 10 * min_count and len(task_counts) > 1:
            least = task_counts.most_common()[-1]
            most = task_counts.most_common()[0]
            recs.append(GapRecommendation(
                "task",
                f"Severe task imbalance: '{most[0]}' has {most[1]} episodes "
                f"but '{least[0]}' has only {least[1]}. "
                f"Collect more episodes for underrepresented tasks.",
                "high",
            ))

        # Single-episode tasks
        single_tasks = [t for t, c in task_counts.items() if c == 1]
        if single_tasks:
            examples = single_tasks[:3]
            recs.append(GapRecommendation(
                "task",
                f"{len(single_tasks)} task(s) have only 1 episode "
                f"(e.g. {', '.join(repr(t) for t in examples)}). "
                f"Add more demonstrations for these tasks or remove them.",
                "medium",
            ))

    # Low task diversity
    if len(task_counts) < 3 and result.total_episodes > 50:
        recs.append(GapRecommendation(
            "task",
            f"Only {len(task_counts)} unique task(s) across {result.total_episodes} "
            f"episodes. Adding task diversity improves policy generalization.",
            "high",
        ))

    # Length distribution
    if lengths:
        arr = np.array(lengths)
        very_short = int(np.sum(arr < 10))
        if very_short > 0:
            recs.append(GapRecommendation(
                "length",
                f"{very_short} episode(s) have fewer than 10 frames — "
                f"likely too short to contain a meaningful trajectory.",
                "medium",
            ))

    # Action space coverage
    if result.action_space_coverage < 0.1 and result.action_space_coverage > 0:
        recs.append(GapRecommendation(
            "action_space",
            f"Action space coverage is only {result.action_space_coverage*100:.1f}%. "
            f"Episodes cluster in a small region. Collect demonstrations "
            f"that explore different parts of the action space.",
            "high",
        ))

    # Single embodiment
    if len(result.embodiment_distribution) == 1 and result.total_episodes > 100:
        recs.append(GapRecommendation(
            "embodiment",
            f"All episodes use a single embodiment "
            f"('{result.embodiment_distribution[0][0]}'). "
            f"Cross-embodiment data improves transfer.",
            "low",
        ))

    # No recommendations = things look good
    if not recs:
        recs.append(GapRecommendation(
            "general",
            "Coverage looks healthy. No major gaps detected.",
            "low",
        ))

    return recs


# ---------------------------------------------------------------------------
# HTML report
# ---------------------------------------------------------------------------

def _render_html(result: CoverageResult) -> str:
    # Stats row
    stats = "".join([
        report.stat_card(str(result.total_episodes), "Total episodes"),
        report.stat_card(f"{result.total_frames:,}", "Total frames"),
        report.stat_card(str(len(result.datasets)), "Datasets"),
        report.stat_card(str(len(result.task_distribution)), "Unique tasks"),
        report.stat_card(
            f"{result.action_space_coverage*100:.1f}%",
            "Action coverage",
        ),
    ])

    # Dataset table
    ds_rows = ""
    for ds in result.datasets:
        ds_rows += f"""<tr>
  <td>{Path(ds.path).name}</td>
  <td>{ds.episode_count}</td>
  <td>{ds.format_version}</td>
  <td>{ds.robot_type}</td>
  <td>{ds.fps} Hz</td>
</tr>"""

    ds_table = f"""<table>
<thead><tr><th>Dataset</th><th>Episodes</th><th>Format</th><th>Robot</th><th>FPS</th></tr></thead>
<tbody>{ds_rows}</tbody></table>""" if result.datasets else ""

    # Recommendations
    rec_html = ""
    for r in result.recommendations:
        color = {
            "high": "var(--red)",
            "medium": "var(--yellow)",
            "low": "var(--cyan)",
        }.get(r.priority, "var(--cyan)")
        priority_badge = report.badge(
            r.priority.upper(),
            {"high": "fail", "medium": "warn", "low": "info"}.get(r.priority, "info"),
        )
        rec_html += f"""<div class="recommendation" style="border-left-color:{color}">
  {priority_badge} <strong>[{r.category}]</strong> {r.message}
</div>"""

    return f"""
<h1>Coverage Report</h1>
<p class="subtitle">{len(result.dataset_paths)} dataset(s) analyzed</p>

<div class="stats-row">{stats}</div>

<h2>Datasets</h2>
<div class="card">{ds_table}</div>

<h2>Task Distribution</h2>
<div class="card">
  {report.distribution_chart(result.task_distribution[:20])}
</div>

<h2>Episode Length Distribution</h2>
<div class="card">
  {report.distribution_chart(result.length_distribution)}
</div>

{"<h2>Embodiment Distribution</h2>" + '<div class="card">' + report.distribution_chart(result.embodiment_distribution) + "</div>" if len(result.embodiment_distribution) > 1 else ""}

{"<h2>Per-Dataset Distribution</h2>" + '<div class="card">' + report.distribution_chart(result.dataset_distribution) + "</div>" if len(result.dataset_distribution) > 1 else ""}

<h2>Action Dimensions</h2>
<div class="card">
  {report.distribution_chart(result.action_dim_distribution)}
</div>

<h2>Recommendations</h2>
{rec_html}
"""
