"""CLI entry point for diffusion policy training."""

from __future__ import annotations

import argparse
import sys


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        description="Train a diffusion policy with Traceplane",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("dataset_path", help="Path to LeRobot dataset")

    # Data options
    parser.add_argument("--sql-filter", help="SQL WHERE clause to filter episodes (requires API)")
    parser.add_argument("--api-url", default="http://localhost:8000", help="Traceplane API URL")
    parser.add_argument("--episodes", type=int, nargs="+", help="Specific episode indices to use")

    # Windowing
    parser.add_argument("--obs-horizon", type=int, default=2, help="Observation history length")
    parser.add_argument("--action-horizon", type=int, default=16, help="Action prediction horizon")
    parser.add_argument("--stride", type=int, default=1, help="Window stride")

    # Model
    parser.add_argument("--model-dim", type=int, default=256, help="U-Net hidden dim")
    parser.add_argument("--model-depth", type=int, default=4, help="U-Net depth")
    parser.add_argument("--diffusion-steps", type=int, default=100, help="DDPM steps")

    # Training
    parser.add_argument("--epochs", type=int, default=100, help="Number of epochs")
    parser.add_argument("--batch-size", type=int, default=64, help="Batch size")
    parser.add_argument("--lr", type=float, default=1e-4, help="Learning rate")
    parser.add_argument("--seed", type=int, default=42, help="Random seed")
    parser.add_argument("--num-workers", type=int, default=0, help="DataLoader workers")
    parser.add_argument("--val-split", type=float, default=0.1, help="Validation split fraction")

    # Normalization
    parser.add_argument("--no-normalize", action="store_true", help="Disable normalization")
    parser.add_argument("--stats-path", help="Path to stats.json")

    # Output
    parser.add_argument("--output-dir", default="./training_output", help="Output directory")
    parser.add_argument("--log-every", type=int, default=10, help="Log every N steps")
    parser.add_argument("--save-every", type=int, default=10, help="Save every N epochs")
    parser.add_argument("--eval-every", type=int, default=10, help="Evaluate every N epochs")

    # Resume
    parser.add_argument("--resume", help="Path to checkpoint to resume from")

    args = parser.parse_args(argv)

    from traceplane.training.config import TrainConfig
    from traceplane.training.trainer import Trainer

    config = TrainConfig(
        dataset_path=args.dataset_path,
        sql_filter=args.sql_filter,
        api_url=args.api_url,
        episode_indices=args.episodes,
        obs_horizon=args.obs_horizon,
        action_horizon=args.action_horizon,
        stride=args.stride,
        model_dim=args.model_dim,
        model_depth=args.model_depth,
        diffusion_steps=args.diffusion_steps,
        num_epochs=args.epochs,
        batch_size=args.batch_size,
        lr=args.lr,
        seed=args.seed,
        num_workers=args.num_workers,
        val_split=args.val_split,
        normalize=not args.no_normalize,
        stats_path=args.stats_path,
        output_dir=args.output_dir,
        log_every=args.log_every,
        save_every=args.save_every,
        eval_every=args.eval_every,
    )

    trainer = Trainer(config)
    trainer.setup()

    if args.resume:
        trainer.load_checkpoint(args.resume)

    trainer.train()


if __name__ == "__main__":
    main()
