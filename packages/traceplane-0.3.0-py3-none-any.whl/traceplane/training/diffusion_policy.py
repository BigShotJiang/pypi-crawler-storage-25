"""Diffusion Policy — 1D temporal U-Net with DDPM noise schedule.

Implements the state-conditioned diffusion policy architecture from
Chi et al. "Diffusion Policy" (RSS 2023), simplified for proprioceptive
(state-only) conditioning without a vision encoder.
"""

from __future__ import annotations

import math

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    from torch import Tensor
except ImportError:
    raise ImportError(
        "PyTorch is required for traceplane.training. "
        "Install it with: pip install traceplane[training]"
    )


def _next_power_of_2(n: int) -> int:
    if n <= 1:
        return 1
    return 1 << (n - 1).bit_length()


class SinusoidalPosEmbed(nn.Module):
    """Sinusoidal positional embedding for diffusion timestep."""

    def __init__(self, dim: int):
        super().__init__()
        self.dim = dim

    def forward(self, t: Tensor) -> Tensor:
        device = t.device
        half = self.dim // 2
        emb = math.log(10000) / (half - 1)
        emb = torch.exp(torch.arange(half, device=device) * -emb)
        emb = t[:, None].float() * emb[None, :]
        return torch.cat([emb.sin(), emb.cos()], dim=-1)


class ConditionalResBlock1d(nn.Module):
    """1D residual block with FiLM conditioning.

    Two Conv1d layers with GroupNorm and SiLU activation.
    Condition vector modulates via scale/shift (FiLM).
    """

    def __init__(self, in_ch: int, out_ch: int, cond_dim: int):
        super().__init__()
        self.norm1 = nn.GroupNorm(min(8, in_ch), in_ch)
        self.conv1 = nn.Conv1d(in_ch, out_ch, kernel_size=3, padding=1)
        self.norm2 = nn.GroupNorm(min(8, out_ch), out_ch)
        self.conv2 = nn.Conv1d(out_ch, out_ch, kernel_size=3, padding=1)
        self.cond_proj = nn.Linear(cond_dim, out_ch * 2)
        self.shortcut = nn.Conv1d(in_ch, out_ch, 1) if in_ch != out_ch else nn.Identity()

    def forward(self, x: Tensor, cond: Tensor) -> Tensor:
        h = F.silu(self.norm1(x))
        h = self.conv1(h)
        h = self.norm2(h)
        # FiLM conditioning: scale and shift
        scale, shift = self.cond_proj(cond).chunk(2, dim=-1)
        h = h * (1 + scale[:, :, None]) + shift[:, :, None]
        h = F.silu(h)
        h = self.conv2(h)
        return h + self.shortcut(x)


class DownBlock1d(nn.Module):
    def __init__(self, in_ch: int, out_ch: int, cond_dim: int):
        super().__init__()
        self.res = ConditionalResBlock1d(in_ch, out_ch, cond_dim)
        self.pool = nn.MaxPool1d(2)

    def forward(self, x: Tensor, cond: Tensor) -> tuple[Tensor, Tensor]:
        h = self.res(x, cond)
        return self.pool(h), h  # downsampled, skip


class UpBlock1d(nn.Module):
    def __init__(self, in_ch: int, out_ch: int, cond_dim: int):
        super().__init__()
        # in_ch is doubled because of skip connection concatenation
        self.res = ConditionalResBlock1d(in_ch, out_ch, cond_dim)
        self.up = nn.Upsample(scale_factor=2, mode="nearest")

    def forward(self, x: Tensor, skip: Tensor, cond: Tensor) -> Tensor:
        x = self.up(x)
        # Handle size mismatch from non-power-of-2 temporal dims
        if x.shape[-1] != skip.shape[-1]:
            x = F.pad(x, (0, skip.shape[-1] - x.shape[-1]))
        x = torch.cat([x, skip], dim=1)
        return self.res(x, cond)


class TemporalUNet(nn.Module):
    """1D U-Net over the temporal dimension of action sequences.

    Down path halves temporal resolution at each level, up path
    restores it with skip connections.
    """

    def __init__(
        self,
        action_dim: int,
        cond_dim: int,
        model_dim: int = 256,
        depth: int = 4,
    ):
        super().__init__()
        self.input_proj = nn.Conv1d(action_dim, model_dim, 1)
        self.output_proj = nn.Conv1d(model_dim, action_dim, 1)

        # Build channel schedule: model_dim, model_dim*2, model_dim*4, ...
        channels = [model_dim * (2**i) for i in range(depth)]

        # Down blocks
        self.down_blocks = nn.ModuleList()
        for i in range(depth - 1):
            self.down_blocks.append(DownBlock1d(channels[i], channels[i + 1], cond_dim))

        # Bottleneck
        self.bottleneck = ConditionalResBlock1d(channels[-1], channels[-1], cond_dim)

        # Up blocks (reverse order, doubled input channels for skip connections)
        self.up_blocks = nn.ModuleList()
        for i in range(depth - 2, -1, -1):
            self.up_blocks.append(UpBlock1d(channels[i + 1] * 2, channels[i], cond_dim))

    def forward(self, x: Tensor, cond: Tensor) -> Tensor:
        # x: (B, action_dim, T), cond: (B, cond_dim)
        h = self.input_proj(x)

        skips = []
        for block in self.down_blocks:
            h, skip = block(h, cond)
            skips.append(skip)

        h = self.bottleneck(h, cond)

        for block, skip in zip(self.up_blocks, reversed(skips)):
            h = block(h, skip, cond)

        return self.output_proj(h)


class DiffusionPolicy(nn.Module):
    """Diffusion Policy for robot action prediction.

    Predicts action chunks conditioned on observation history using
    a denoising diffusion probabilistic model (DDPM) with a 1D
    temporal U-Net backbone.

    Args:
        action_dim: Dimension of action vectors.
        state_dim: Dimension of proprioceptive state vectors.
        obs_horizon: Number of observation history frames.
        action_horizon: Number of action frames to predict.
        model_dim: Hidden dimension of U-Net.
        model_depth: Number of down/up blocks.
        diffusion_steps: Number of DDPM noise steps.
        beta_start: Starting noise level.
        beta_end: Ending noise level.
    """

    def __init__(
        self,
        action_dim: int,
        state_dim: int,
        obs_horizon: int = 2,
        action_horizon: int = 16,
        model_dim: int = 256,
        model_depth: int = 4,
        diffusion_steps: int = 100,
        beta_start: float = 1e-4,
        beta_end: float = 0.02,
    ):
        super().__init__()
        self.action_dim = action_dim
        self.action_horizon = action_horizon
        self.diffusion_steps = diffusion_steps

        # Pad temporal dim to next power of 2 for U-Net
        self._padded_horizon = _next_power_of_2(action_horizon)

        # Condition encoder: flatten obs history -> condition vector
        cond_input_dim = obs_horizon * state_dim
        cond_dim = model_dim
        self.cond_encoder = nn.Sequential(
            nn.Linear(cond_input_dim, cond_dim),
            nn.SiLU(),
            nn.Linear(cond_dim, cond_dim),
        )

        # Timestep embedding
        self.time_embed = nn.Sequential(
            SinusoidalPosEmbed(model_dim),
            nn.Linear(model_dim, cond_dim),
            nn.SiLU(),
            nn.Linear(cond_dim, cond_dim),
        )

        # U-Net backbone
        self.unet = TemporalUNet(
            action_dim=action_dim,
            cond_dim=cond_dim,
            model_dim=model_dim,
            depth=model_depth,
        )

        # DDPM noise schedule
        betas = torch.linspace(beta_start, beta_end, diffusion_steps)
        alphas = 1.0 - betas
        alpha_bar = torch.cumprod(alphas, dim=0)

        self.register_buffer("betas", betas)
        self.register_buffer("alphas", alphas)
        self.register_buffer("alpha_bar", alpha_bar)
        self.register_buffer("sqrt_alpha_bar", torch.sqrt(alpha_bar))
        self.register_buffer("sqrt_one_minus_alpha_bar", torch.sqrt(1.0 - alpha_bar))

    def _pad_temporal(self, x: Tensor) -> Tensor:
        """Pad action sequence to next power of 2."""
        if self._padded_horizon > self.action_horizon:
            pad_len = self._padded_horizon - self.action_horizon
            x = F.pad(x, (0, pad_len))
        return x

    def _unpad_temporal(self, x: Tensor) -> Tensor:
        """Remove temporal padding."""
        return x[:, :, : self.action_horizon]

    def forward(self, obs_cond: Tensor, noised_action: Tensor, timestep: Tensor) -> Tensor:
        """Predict noise given noised action and observation condition.

        Args:
            obs_cond: Flattened observation history, (B, obs_horizon * state_dim).
            noised_action: Noised action chunk, (B, action_horizon, action_dim).
            timestep: Diffusion timestep, (B,) integers.

        Returns:
            Predicted noise, (B, action_horizon, action_dim).
        """
        cond = self.cond_encoder(obs_cond) + self.time_embed(timestep)

        # (B, T, D) -> (B, D, T) for Conv1d
        x = noised_action.transpose(1, 2)
        x = self._pad_temporal(x)
        x = self.unet(x, cond)
        x = self._unpad_temporal(x)
        return x.transpose(1, 2)  # (B, T, D)

    def compute_loss(self, obs_cond: Tensor, action: Tensor) -> Tensor:
        """Compute training loss: MSE between predicted and actual noise.

        Args:
            obs_cond: Flattened observation history, (B, obs_horizon * state_dim).
            action: Ground truth action chunk, (B, action_horizon, action_dim).

        Returns:
            Scalar MSE loss.
        """
        B = action.shape[0]
        # Sample random timesteps
        t = torch.randint(0, self.diffusion_steps, (B,), device=action.device)
        # Sample noise
        noise = torch.randn_like(action)
        # Forward diffusion: add noise to action
        sqrt_ab = self.sqrt_alpha_bar[t][:, None, None]
        sqrt_omab = self.sqrt_one_minus_alpha_bar[t][:, None, None]
        noised_action = sqrt_ab * action + sqrt_omab * noise
        # Predict noise
        pred_noise = self.forward(obs_cond, noised_action, t)
        return F.mse_loss(pred_noise, noise)

    @torch.no_grad()
    def predict_action(self, obs_cond: Tensor) -> Tensor:
        """Generate action chunk via iterative DDPM denoising.

        Args:
            obs_cond: Flattened observation history, (B, obs_horizon * state_dim).

        Returns:
            Predicted action chunk, (B, action_horizon, action_dim).
        """
        B = obs_cond.shape[0]
        device = obs_cond.device
        # Start from pure noise
        x = torch.randn(B, self.action_horizon, self.action_dim, device=device)

        for i in reversed(range(self.diffusion_steps)):
            t = torch.full((B,), i, device=device, dtype=torch.long)
            pred_noise = self.forward(obs_cond, x, t)

            alpha = self.alphas[i]
            alpha_bar_t = self.alpha_bar[i]
            beta = self.betas[i]

            # DDPM update step
            x = (1.0 / torch.sqrt(alpha)) * (
                x - (beta / torch.sqrt(1.0 - alpha_bar_t)) * pred_noise
            )

            # Add noise for all steps except the last
            if i > 0:
                noise = torch.randn_like(x)
                x = x + torch.sqrt(beta) * noise

        return x
