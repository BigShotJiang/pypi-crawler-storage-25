"""Diffusion policy training module for Traceplane."""

from traceplane.training.config import TrainConfig
from traceplane.training.diffusion_policy import DiffusionPolicy
from traceplane.training.normalization import (
    NormalizationStats,
    Normalizer,
    compute_stats,
    load_stats_from_lerobot,
)
from traceplane.training.trainer import Trainer
from traceplane.training.eval import evaluate_policy

__all__ = [
    "TrainConfig",
    "DiffusionPolicy",
    "NormalizationStats",
    "Normalizer",
    "Trainer",
    "compute_stats",
    "load_stats_from_lerobot",
    "evaluate_policy",
]
