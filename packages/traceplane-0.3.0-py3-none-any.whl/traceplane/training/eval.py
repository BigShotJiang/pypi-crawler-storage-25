"""Offline evaluation for diffusion policy."""

from __future__ import annotations

from typing import Any

try:
    import torch
    from torch.utils.data import DataLoader
except ImportError:
    raise ImportError(
        "PyTorch is required for traceplane.training. "
        "Install it with: pip install traceplane[training]"
    )

from traceplane.training.diffusion_policy import DiffusionPolicy
from traceplane.training.normalization import Normalizer


def evaluate_policy(
    policy: DiffusionPolicy,
    normalizer: Normalizer | None,
    val_loader: DataLoader,
    device: torch.device,
) -> dict[str, float]:
    """Compute evaluation metrics on validation data.

    Runs the full denoising loop and compares predicted actions to
    ground truth. Reports MSE in both normalized and original spaces.

    Returns:
        Dict with keys: mse, mse_denorm, mae_denorm.
    """
    policy.eval()
    total_mse = 0.0
    total_mse_denorm = 0.0
    total_mae_denorm = 0.0
    total_samples = 0

    for batch in val_loader:
        obs_hist = batch["obs_history"]
        state = obs_hist.get("state")
        if state is None:
            continue

        state = state.to(device)
        action_gt = batch["action_chunk"].to(device)

        # Normalize
        if normalizer is not None:
            state_norm = normalizer.normalize_state(state)
            action_norm = normalizer.normalize_action(action_gt)
        else:
            state_norm = state
            action_norm = action_gt

        obs_cond = state_norm.flatten(start_dim=1)
        pred_action_norm = policy.predict_action(obs_cond)

        # MSE in normalized space
        mse = (pred_action_norm - action_norm).pow(2).mean().item()

        # Denormalize and compute error in original space
        if normalizer is not None:
            pred_action = normalizer.denormalize_action(pred_action_norm)
        else:
            pred_action = pred_action_norm

        mse_denorm = (pred_action - action_gt).pow(2).mean().item()
        mae_denorm = (pred_action - action_gt).abs().mean().item()

        B = action_gt.shape[0]
        total_mse += mse * B
        total_mse_denorm += mse_denorm * B
        total_mae_denorm += mae_denorm * B
        total_samples += B

    if total_samples == 0:
        return {"mse": 0.0, "mse_denorm": 0.0, "mae_denorm": 0.0}

    return {
        "mse": total_mse / total_samples,
        "mse_denorm": total_mse_denorm / total_samples,
        "mae_denorm": total_mae_denorm / total_samples,
    }
