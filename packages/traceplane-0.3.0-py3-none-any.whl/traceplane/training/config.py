"""Training configuration."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class TrainConfig:
    """Configuration for diffusion policy training.

    Args:
        dataset_path: Path to LeRobot dataset (local or remote).
        storage_options: fsspec options for remote storage.
        episode_indices: Subset of episodes to use, or None for all.
        sql_filter: SQL WHERE clause to filter episodes (requires running API).
        api_url: Traceplane API URL for SQL-filtered loading.
        obs_horizon: Observation history length (frames).
        action_horizon: Action prediction horizon (frames).
        stride: Window stride between samples.
        normalize: Whether to normalize actions and states.
        stats_path: Path to stats.json; auto-detected from dataset if None.
        state_dim: State dimension; auto-detected from data if None.
        action_dim: Action dimension; auto-detected from data if None.
        diffusion_steps: Number of DDPM diffusion steps.
        model_dim: Hidden dimension of U-Net.
        model_depth: Number of down/up blocks in U-Net.
        batch_size: Training batch size.
        lr: Learning rate.
        weight_decay: AdamW weight decay.
        num_epochs: Total training epochs.
        ema_decay: EMA decay rate for model weights.
        grad_clip: Max gradient norm for clipping.
        num_workers: DataLoader worker processes.
        seed: Random seed.
        output_dir: Directory for checkpoints and metrics.
        log_every: Log metrics every N steps.
        save_every: Save checkpoint every N epochs.
        eval_every: Evaluate every N epochs.
        val_split: Fraction of episodes for validation.
    """

    # Data
    dataset_path: str = ""
    storage_options: dict[str, Any] | None = None
    episode_indices: list[int] | None = None
    sql_filter: str | None = None
    api_url: str = "http://localhost:8000"

    # Windowing
    obs_horizon: int = 2
    action_horizon: int = 16
    stride: int = 1

    # Normalization
    normalize: bool = True
    stats_path: str | None = None

    # Model
    state_dim: int | None = None
    action_dim: int | None = None
    diffusion_steps: int = 100
    model_dim: int = 256
    model_depth: int = 4

    # Training
    batch_size: int = 64
    lr: float = 1e-4
    weight_decay: float = 1e-6
    num_epochs: int = 100
    ema_decay: float = 0.995
    grad_clip: float = 1.0
    num_workers: int = 0
    seed: int = 42

    # Checkpointing + logging
    output_dir: str = "./training_output"
    log_every: int = 10
    save_every: int = 10
    eval_every: int = 10
    val_split: float = 0.1
