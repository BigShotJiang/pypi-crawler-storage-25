"""Training loop for diffusion policy."""

from __future__ import annotations

import copy
import dataclasses
import json
import os
import time
from pathlib import Path
from typing import Any

import numpy as np

try:
    import torch
    import torch.nn as nn
    from torch.utils.data import DataLoader
except ImportError:
    raise ImportError(
        "PyTorch is required for traceplane.training. "
        "Install it with: pip install traceplane[training]"
    )

from traceplane.dataset import TrajectoryDataset
from traceplane.lerobot_reader import LeRobotReader
from traceplane.torch import make_dataloader
from traceplane.training.config import TrainConfig
from traceplane.training.diffusion_policy import DiffusionPolicy
from traceplane.training.eval import evaluate_policy
from traceplane.training.normalization import (
    Normalizer,
    compute_stats,
    load_stats_from_lerobot,
)


class Trainer:
    """Orchestrates diffusion policy training.

    Handles data loading (with optional SQL filtering), normalization,
    model creation, training loop, checkpointing, and evaluation.
    """

    def __init__(self, config: TrainConfig):
        self.config = config
        self.device = self._pick_device()
        self.policy: DiffusionPolicy | None = None
        self.normalizer: Normalizer | None = None
        self.optimizer: torch.optim.Optimizer | None = None
        self.ema_weights: dict[str, torch.Tensor] = {}
        self.train_loader: DataLoader | None = None
        self.val_loader: DataLoader | None = None
        self.global_step = 0
        self.start_epoch = 0

    @staticmethod
    def _pick_device() -> torch.device:
        if torch.cuda.is_available():
            return torch.device("cuda")
        if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
            return torch.device("mps")
        return torch.device("cpu")

    def setup(self) -> None:
        """Load data, build model, prepare for training."""
        torch.manual_seed(self.config.seed)
        np.random.seed(self.config.seed)

        # 1. Load dataset
        dataset = self._load_dataset()

        # 2. Train/val split
        n_total = len(dataset)
        n_val = max(1, int(n_total * self.config.val_split))
        n_train = n_total - n_val

        all_ids = dataset.episode_ids()
        rng = np.random.RandomState(self.config.seed)
        indices = rng.permutation(n_total)
        train_ids = [all_ids[i] for i in indices[:n_train]]
        val_ids = [all_ids[i] for i in indices[n_train:]]

        train_dataset = dataset.filter(train_ids)
        val_dataset = dataset.filter(val_ids)

        print(f"Dataset: {n_total} episodes ({n_train} train, {n_val} val)")

        # 3. Normalization
        if self.config.normalize:
            stats = None
            if self.config.stats_path:
                stats = load_stats_from_lerobot(self.config.stats_path)
            if stats is None:
                stats = load_stats_from_lerobot(self.config.dataset_path)
            if stats is None:
                print("Computing normalization stats from dataset...")
                stats = compute_stats(train_dataset)
            self.normalizer = Normalizer(stats).to(self.device)
            print(f"Normalization: minmax, action_dim={len(stats.action_min)}, state_dim={len(stats.state_min)}")

        # 4. Create dataloaders
        self.train_loader = make_dataloader(
            train_dataset,
            obs_horizon=self.config.obs_horizon,
            action_horizon=self.config.action_horizon,
            stride=self.config.stride,
            batch_size=self.config.batch_size,
            shuffle=True,
            num_workers=self.config.num_workers,
        )
        self.val_loader = make_dataloader(
            val_dataset,
            obs_horizon=self.config.obs_horizon,
            action_horizon=self.config.action_horizon,
            stride=self.config.stride,
            batch_size=self.config.batch_size,
            shuffle=False,
            num_workers=self.config.num_workers,
        )

        # 5. Auto-detect dims from first batch
        sample_batch = next(iter(self.train_loader))
        state_dim = self.config.state_dim
        action_dim = self.config.action_dim
        if state_dim is None:
            state = sample_batch["obs_history"].get("state")
            if state is not None:
                state_dim = state.shape[-1]
            else:
                raise ValueError("No 'state' key in obs_history — set state_dim manually")
        if action_dim is None:
            action_dim = sample_batch["action_chunk"].shape[-1]

        print(f"Model: state_dim={state_dim}, action_dim={action_dim}, "
              f"obs_horizon={self.config.obs_horizon}, action_horizon={self.config.action_horizon}")

        # 6. Create model
        self.policy = DiffusionPolicy(
            action_dim=action_dim,
            state_dim=state_dim,
            obs_horizon=self.config.obs_horizon,
            action_horizon=self.config.action_horizon,
            model_dim=self.config.model_dim,
            model_depth=self.config.model_depth,
            diffusion_steps=self.config.diffusion_steps,
        ).to(self.device)

        n_params = sum(p.numel() for p in self.policy.parameters())
        print(f"Parameters: {n_params:,}")

        # 7. Optimizer
        self.optimizer = torch.optim.AdamW(
            self.policy.parameters(),
            lr=self.config.lr,
            weight_decay=self.config.weight_decay,
        )

        # 8. EMA
        self.ema_weights = {
            name: param.data.clone()
            for name, param in self.policy.named_parameters()
        }

        # 9. Output directory
        os.makedirs(os.path.join(self.config.output_dir, "checkpoints"), exist_ok=True)

        print(f"Device: {self.device}")
        print(f"Training samples: {len(self.train_loader.dataset)}")
        print(f"Validation samples: {len(self.val_loader.dataset)}")

    def _load_dataset(self) -> TrajectoryDataset:
        """Load dataset, optionally with SQL filtering."""
        if self.config.sql_filter:
            try:
                from traceplane.query import TraceplaneClient

                client = TraceplaneClient(self.config.api_url)
                print(f"SQL filter: {self.config.sql_filter}")
                dataset = client.sql_and_load(
                    dataset_path=self.config.dataset_path,
                    name="train_data",
                    sql_filter=self.config.sql_filter,
                    storage_options=self.config.storage_options,
                )
                return dataset
            except Exception as e:
                print(f"Warning: SQL filtering failed ({e}), falling back to full dataset")

        return LeRobotReader(
            self.config.dataset_path,
            storage_options=self.config.storage_options,
            episode_indices=self.config.episode_indices,
        )

    def train(self) -> None:
        """Run the training loop."""
        if self.policy is None:
            raise RuntimeError("Call setup() before train()")

        metrics_path = os.path.join(self.config.output_dir, "metrics.jsonl")
        print(f"\nStarting training for {self.config.num_epochs} epochs...")

        for epoch in range(self.start_epoch, self.config.num_epochs):
            self.policy.train()
            epoch_loss = 0.0
            epoch_steps = 0

            for batch in self.train_loader:
                state = batch["obs_history"]["state"].to(self.device)
                action = batch["action_chunk"].to(self.device)

                if self.normalizer is not None:
                    state = self.normalizer.normalize_state(state)
                    action = self.normalizer.normalize_action(action)

                obs_cond = state.flatten(start_dim=1)
                loss = self.policy.compute_loss(obs_cond, action)

                self.optimizer.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(self.policy.parameters(), self.config.grad_clip)
                self.optimizer.step()

                # EMA update
                with torch.no_grad():
                    for name, param in self.policy.named_parameters():
                        self.ema_weights[name].mul_(self.config.ema_decay).add_(
                            param.data, alpha=1 - self.config.ema_decay
                        )

                epoch_loss += loss.item()
                epoch_steps += 1
                self.global_step += 1

                if self.global_step % self.config.log_every == 0:
                    avg = epoch_loss / epoch_steps
                    print(f"  epoch {epoch+1} step {self.global_step} loss={loss.item():.6f} avg={avg:.6f}")

            avg_loss = epoch_loss / max(epoch_steps, 1)

            # Evaluation
            val_metrics: dict[str, float] = {}
            if (epoch + 1) % self.config.eval_every == 0:
                # Swap in EMA weights for evaluation
                orig_weights = self._swap_ema_weights()
                val_metrics = evaluate_policy(
                    self.policy, self.normalizer, self.val_loader, self.device
                )
                self._restore_weights(orig_weights)
                print(f"  [eval] mse={val_metrics['mse']:.6f} "
                      f"mse_denorm={val_metrics['mse_denorm']:.6f} "
                      f"mae_denorm={val_metrics['mae_denorm']:.6f}")

            # Log metrics
            metric_entry = {
                "epoch": epoch + 1,
                "step": self.global_step,
                "train_loss": avg_loss,
                "timestamp": time.time(),
                **{f"val_{k}": v for k, v in val_metrics.items()},
            }
            with open(metrics_path, "a") as f:
                f.write(json.dumps(metric_entry) + "\n")

            print(f"Epoch {epoch+1}/{self.config.num_epochs} — loss={avg_loss:.6f}")

            # Checkpoint
            if (epoch + 1) % self.config.save_every == 0:
                self.save_checkpoint(epoch + 1, self.global_step)

        # Final checkpoint
        self.save_checkpoint(self.config.num_epochs, self.global_step)
        print(f"\nTraining complete. Output: {self.config.output_dir}")

    def _swap_ema_weights(self) -> dict[str, torch.Tensor]:
        """Swap model weights with EMA weights, return originals."""
        orig = {}
        for name, param in self.policy.named_parameters():
            orig[name] = param.data.clone()
            param.data.copy_(self.ema_weights[name])
        return orig

    def _restore_weights(self, orig: dict[str, torch.Tensor]) -> None:
        for name, param in self.policy.named_parameters():
            param.data.copy_(orig[name])

    def save_checkpoint(self, epoch: int, step: int) -> None:
        ckpt_dir = os.path.join(self.config.output_dir, "checkpoints")
        path = os.path.join(ckpt_dir, f"epoch_{epoch}.pt")
        latest = os.path.join(ckpt_dir, "latest.pt")

        ckpt = {
            "epoch": epoch,
            "step": step,
            "model_state_dict": self.policy.state_dict(),
            "ema_state_dict": self.ema_weights,
            "optimizer_state_dict": self.optimizer.state_dict(),
            "config": dataclasses.asdict(self.config),
        }
        if self.normalizer is not None:
            ckpt["normalizer"] = self.normalizer.state_dict()

        torch.save(ckpt, path)
        torch.save(ckpt, latest)
        print(f"  Checkpoint saved: {path}")

    def load_checkpoint(self, path: str) -> None:
        """Resume training from a checkpoint."""
        ckpt = torch.load(path, map_location=self.device, weights_only=False)
        self.policy.load_state_dict(ckpt["model_state_dict"])
        self.optimizer.load_state_dict(ckpt["optimizer_state_dict"])
        self.ema_weights = ckpt["ema_state_dict"]
        self.start_epoch = ckpt["epoch"]
        self.global_step = ckpt["step"]
        if "normalizer" in ckpt and self.normalizer is not None:
            self.normalizer = Normalizer.from_state_dict(ckpt["normalizer"]).to(self.device)
        print(f"Resumed from epoch {self.start_epoch}, step {self.global_step}")
