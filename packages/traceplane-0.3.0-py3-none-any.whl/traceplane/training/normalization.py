"""Dataset statistics and normalization for diffusion policy training."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

try:
    import torch
    from torch import Tensor
except ImportError:
    raise ImportError(
        "PyTorch is required for traceplane.training. "
        "Install it with: pip install traceplane[training]"
    )

from traceplane.dataset import TrajectoryDataset


@dataclass
class NormalizationStats:
    """Per-dimension statistics for actions and states."""

    action_min: np.ndarray
    action_max: np.ndarray
    action_mean: np.ndarray
    action_std: np.ndarray
    state_min: np.ndarray
    state_max: np.ndarray
    state_mean: np.ndarray
    state_std: np.ndarray


def load_stats_from_lerobot(dataset_path: str | Path) -> NormalizationStats | None:
    """Try to load stats from a LeRobot dataset's meta/stats.json.

    Returns None if the file doesn't exist or can't be parsed.
    """
    stats_file = Path(dataset_path) / "meta" / "stats.json"
    if not stats_file.exists():
        return None

    with open(stats_file) as f:
        raw = json.load(f)

    def _to_array(key: str, stat: str) -> np.ndarray | None:
        entry = raw.get(key)
        if entry is None:
            return None
        val = entry.get(stat)
        if val is None:
            return None
        return np.array(val, dtype=np.float32)

    action_min = _to_array("action", "min")
    action_max = _to_array("action", "max")
    action_mean = _to_array("action", "mean")
    action_std = _to_array("action", "std")
    state_min = _to_array("observation.state", "min")
    state_max = _to_array("observation.state", "max")
    state_mean = _to_array("observation.state", "mean")
    state_std = _to_array("observation.state", "std")

    if action_min is None or state_min is None:
        return None

    # Fill missing stats with reasonable defaults
    if action_mean is None:
        action_mean = (action_min + action_max) / 2
    if action_std is None:
        action_std = (action_max - action_min) / 4 + 1e-6
    if state_mean is None:
        state_mean = (state_min + state_max) / 2
    if state_std is None:
        state_std = (state_max - state_min) / 4 + 1e-6

    return NormalizationStats(
        action_min=action_min,
        action_max=action_max,
        action_mean=action_mean,
        action_std=action_std,
        state_min=state_min,
        state_max=state_max,
        state_mean=state_mean,
        state_std=state_std,
    )


def compute_stats(
    dataset: TrajectoryDataset,
    max_episodes: int | None = None,
) -> NormalizationStats:
    """Compute normalization statistics from a dataset via streaming.

    Uses Welford's online algorithm for numerically stable mean/variance.
    """
    n_action = 0
    n_state = 0
    action_sum = None
    action_sq_sum = None
    action_min_val = None
    action_max_val = None
    state_sum = None
    state_sq_sum = None
    state_min_val = None
    state_max_val = None

    count = min(len(dataset), max_episodes) if max_episodes else len(dataset)
    for i in range(count):
        ep = dataset[i]

        # Actions
        if ep.actions.ndim == 2 and ep.actions.shape[0] > 0:
            a = ep.actions.astype(np.float64)
            if action_sum is None:
                action_sum = np.zeros(a.shape[1], dtype=np.float64)
                action_sq_sum = np.zeros(a.shape[1], dtype=np.float64)
                action_min_val = np.full(a.shape[1], np.inf)
                action_max_val = np.full(a.shape[1], -np.inf)
            action_sum += a.sum(axis=0)
            action_sq_sum += (a**2).sum(axis=0)
            action_min_val = np.minimum(action_min_val, a.min(axis=0))
            action_max_val = np.maximum(action_max_val, a.max(axis=0))
            n_action += a.shape[0]

        # State observations
        state = ep.observations.get("state")
        if state is not None and state.ndim == 2 and state.shape[0] > 0:
            s = state.astype(np.float64)
            if state_sum is None:
                state_sum = np.zeros(s.shape[1], dtype=np.float64)
                state_sq_sum = np.zeros(s.shape[1], dtype=np.float64)
                state_min_val = np.full(s.shape[1], np.inf)
                state_max_val = np.full(s.shape[1], -np.inf)
            state_sum += s.sum(axis=0)
            state_sq_sum += (s**2).sum(axis=0)
            state_min_val = np.minimum(state_min_val, s.min(axis=0))
            state_max_val = np.maximum(state_max_val, s.max(axis=0))
            n_state += s.shape[0]

    if action_sum is None or n_action == 0:
        raise ValueError("No action data found in dataset")

    action_mean = action_sum / n_action
    action_var = action_sq_sum / n_action - action_mean**2
    action_std = np.sqrt(np.maximum(action_var, 0)) + 1e-6

    if state_sum is not None and n_state > 0:
        state_mean = state_sum / n_state
        state_var = state_sq_sum / n_state - state_mean**2
        state_std = np.sqrt(np.maximum(state_var, 0)) + 1e-6
    else:
        # No state observations — use action dims as fallback
        state_min_val = action_min_val
        state_max_val = action_max_val
        state_mean = action_mean
        state_std = action_std

    return NormalizationStats(
        action_min=action_min_val.astype(np.float32),
        action_max=action_max_val.astype(np.float32),
        action_mean=action_mean.astype(np.float32),
        action_std=action_std.astype(np.float32),
        state_min=state_min_val.astype(np.float32),
        state_max=state_max_val.astype(np.float32),
        state_mean=state_mean.astype(np.float32),
        state_std=state_std.astype(np.float32),
    )


class Normalizer:
    """Normalize and denormalize actions/states for diffusion policy training.

    Supports two modes:
        - ``minmax``: maps to [-1, 1] using min/max bounds (default)
        - ``zscore``: zero-mean unit-variance using mean/std
    """

    def __init__(self, stats: NormalizationStats, mode: str = "minmax"):
        self.mode = mode
        self._stats = stats

        # Convert to tensors (registered as non-parameter state)
        self._action_min = torch.tensor(stats.action_min, dtype=torch.float32)
        self._action_max = torch.tensor(stats.action_max, dtype=torch.float32)
        self._action_mean = torch.tensor(stats.action_mean, dtype=torch.float32)
        self._action_std = torch.tensor(stats.action_std, dtype=torch.float32)
        self._state_min = torch.tensor(stats.state_min, dtype=torch.float32)
        self._state_max = torch.tensor(stats.state_max, dtype=torch.float32)
        self._state_mean = torch.tensor(stats.state_mean, dtype=torch.float32)
        self._state_std = torch.tensor(stats.state_std, dtype=torch.float32)

    def to(self, device: torch.device) -> "Normalizer":
        """Move all tensors to the given device."""
        self._action_min = self._action_min.to(device)
        self._action_max = self._action_max.to(device)
        self._action_mean = self._action_mean.to(device)
        self._action_std = self._action_std.to(device)
        self._state_min = self._state_min.to(device)
        self._state_max = self._state_max.to(device)
        self._state_mean = self._state_mean.to(device)
        self._state_std = self._state_std.to(device)
        return self

    def normalize_action(self, action: Tensor) -> Tensor:
        if self.mode == "minmax":
            range_ = self._action_max - self._action_min + 1e-6
            return 2.0 * (action - self._action_min) / range_ - 1.0
        else:
            return (action - self._action_mean) / self._action_std

    def denormalize_action(self, action: Tensor) -> Tensor:
        if self.mode == "minmax":
            range_ = self._action_max - self._action_min + 1e-6
            return (action + 1.0) / 2.0 * range_ + self._action_min
        else:
            return action * self._action_std + self._action_mean

    def normalize_state(self, state: Tensor) -> Tensor:
        if self.mode == "minmax":
            range_ = self._state_max - self._state_min + 1e-6
            return 2.0 * (state - self._state_min) / range_ - 1.0
        else:
            return (state - self._state_mean) / self._state_std

    def denormalize_state(self, state: Tensor) -> Tensor:
        if self.mode == "minmax":
            range_ = self._state_max - self._state_min + 1e-6
            return (state + 1.0) / 2.0 * range_ + self._state_min
        else:
            return state * self._state_std + self._state_mean

    def state_dict(self) -> dict[str, Any]:
        return {
            "mode": self.mode,
            "action_min": self._action_min.cpu().numpy().tolist(),
            "action_max": self._action_max.cpu().numpy().tolist(),
            "action_mean": self._action_mean.cpu().numpy().tolist(),
            "action_std": self._action_std.cpu().numpy().tolist(),
            "state_min": self._state_min.cpu().numpy().tolist(),
            "state_max": self._state_max.cpu().numpy().tolist(),
            "state_mean": self._state_mean.cpu().numpy().tolist(),
            "state_std": self._state_std.cpu().numpy().tolist(),
        }

    @classmethod
    def from_state_dict(cls, d: dict[str, Any]) -> "Normalizer":
        stats = NormalizationStats(
            action_min=np.array(d["action_min"], dtype=np.float32),
            action_max=np.array(d["action_max"], dtype=np.float32),
            action_mean=np.array(d["action_mean"], dtype=np.float32),
            action_std=np.array(d["action_std"], dtype=np.float32),
            state_min=np.array(d["state_min"], dtype=np.float32),
            state_max=np.array(d["state_max"], dtype=np.float32),
            state_mean=np.array(d["state_mean"], dtype=np.float32),
            state_std=np.array(d["state_std"], dtype=np.float32),
        )
        return cls(stats, mode=d.get("mode", "minmax"))
