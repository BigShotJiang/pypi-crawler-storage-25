"""traceplane split — generalization-aware train/eval split builder.

Creates holdout splits by object, scene, task, embodiment, or operator.
Detects leakage between training and evaluation sets.

Usage::

    from traceplane.split import build_split
    result = build_split("/path/to/dataset", holdout_by="task", test_fraction=0.2)
    result.print()
    result.to_html("split_report.html")
"""

from __future__ import annotations

import json
import random
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np

from traceplane import report


@dataclass
class LeakageIssue:
    dimension: str  # what leaked: "task", "object", "scene", etc.
    value: str      # the specific value that appears in both sets
    train_count: int
    test_count: int


@dataclass
class SplitResult:
    dataset_path: str
    holdout_by: str
    total_episodes: int = 0
    train_count: int = 0
    test_count: int = 0
    train_indices: list[int] = field(default_factory=list)
    test_indices: list[int] = field(default_factory=list)

    # Per-dimension overlap analysis
    leakage_issues: list[LeakageIssue] = field(default_factory=list)

    # Distribution comparison
    train_task_dist: list[tuple[str, int]] = field(default_factory=list)
    test_task_dist: list[tuple[str, int]] = field(default_factory=list)
    train_length_stats: dict[str, float] = field(default_factory=dict)
    test_length_stats: dict[str, float] = field(default_factory=dict)

    # Coverage summary
    held_out_values: list[str] = field(default_factory=list)

    @property
    def has_leakage(self) -> bool:
        return len(self.leakage_issues) > 0

    def print(self) -> None:
        print(f"\n{'='*60}")
        print(f"  traceplane split — {self.dataset_path}")
        print(f"{'='*60}")
        print(f"  Holdout by:     {self.holdout_by}")
        print(f"  Total episodes: {self.total_episodes}")
        print(f"  Train:          {self.train_count} ({self.train_count/max(self.total_episodes,1)*100:.0f}%)")
        print(f"  Test:           {self.test_count} ({self.test_count/max(self.total_episodes,1)*100:.0f}%)")
        print()

        if self.held_out_values:
            print(f"  Held-out {self.holdout_by}(s): {', '.join(self.held_out_values[:10])}")
            print()

        if self.leakage_issues:
            print(f"  LEAKAGE DETECTED: {len(self.leakage_issues)} overlap(s)")
            for issue in self.leakage_issues[:10]:
                print(f"    [{issue.dimension}] '{issue.value}' in train ({issue.train_count}) AND test ({issue.test_count})")
        else:
            print(f"  No leakage detected across {self.holdout_by}.")

        print(f"\n{'='*60}\n")

    def to_html(self, path: str) -> None:
        body = _render_html(self)
        html = report.html_document(f"Split Report — {self.dataset_path}", body)
        Path(path).write_text(html)

    def to_dict(self) -> dict[str, Any]:
        return {
            "dataset_path": self.dataset_path,
            "holdout_by": self.holdout_by,
            "total_episodes": self.total_episodes,
            "train_count": self.train_count,
            "test_count": self.test_count,
            "train_indices": self.train_indices,
            "test_indices": self.test_indices,
            "has_leakage": self.has_leakage,
            "leakage_issues": [
                {"dimension": l.dimension, "value": l.value,
                 "train_count": l.train_count, "test_count": l.test_count}
                for l in self.leakage_issues
            ],
            "held_out_values": self.held_out_values,
        }

    def save_indices(self, path: str) -> None:
        """Save train/test indices to a JSON file for reproducibility."""
        Path(path).write_text(json.dumps({
            "holdout_by": self.holdout_by,
            "train_indices": self.train_indices,
            "test_indices": self.test_indices,
            "held_out_values": self.held_out_values,
        }, indent=2))


def build_split(
    path: str,
    holdout_by: str = "task",
    test_fraction: float = 0.2,
    max_episodes: int | None = None,
    seed: int = 42,
    check_leakage_on: list[str] | None = None,
) -> SplitResult:
    """Build a generalization-aware train/eval split.

    Args:
        path: Path to dataset root.
        holdout_by: Dimension to hold out. One of:
            "task", "episode", "random", or a metadata key.
        test_fraction: Fraction of data (or unique values) for the test set.
        max_episodes: Max episodes to load.
        seed: Random seed for reproducibility.
        check_leakage_on: Additional dimensions to check for leakage.
            Default: ["task"].

    Returns:
        A :class:`SplitResult` with train/test indices and leakage analysis.
    """
    from traceplane.lerobot_reader import LeRobotReader

    rng = random.Random(seed)
    reader = LeRobotReader(path)
    result = SplitResult(dataset_path=path, holdout_by=holdout_by)

    indices = list(range(len(reader)))
    if max_episodes:
        indices = indices[:max_episodes]

    # Load episode metadata
    episodes: list[dict[str, Any]] = []
    for idx in indices:
        ep = reader[idx]
        episodes.append({
            "index": idx,
            "episode_index": ep.metadata.get("episode_index", idx),
            "task_label": ep.metadata.get("task_label", "unknown"),
            "robot_type": ep.metadata.get("robot_type", "unknown"),
            "length": ep.length,
        })

    result.total_episodes = len(episodes)

    if not episodes:
        return result

    # Build the split
    if holdout_by == "random" or holdout_by == "episode":
        # Simple random split
        shuffled = list(range(len(episodes)))
        rng.shuffle(shuffled)
        split_idx = int(len(shuffled) * (1 - test_fraction))
        train_ep_indices = shuffled[:split_idx]
        test_ep_indices = shuffled[split_idx:]
    else:
        # Group by holdout dimension, then hold out entire groups
        groups: defaultdict[str, list[int]] = defaultdict(list)
        for i, ep in enumerate(episodes):
            key = ep.get(holdout_by, ep.get("task_label", "unknown"))
            groups[key].append(i)

        group_keys = list(groups.keys())
        rng.shuffle(group_keys)

        # Hold out groups until we reach test_fraction
        test_target = int(len(episodes) * test_fraction)
        test_ep_indices: list[int] = []
        held_out: list[str] = []
        for key in group_keys:
            if len(test_ep_indices) >= test_target:
                break
            test_ep_indices.extend(groups[key])
            held_out.append(key)

        train_ep_indices = [i for i in range(len(episodes)) if i not in set(test_ep_indices)]
        result.held_out_values = held_out

    # Store indices (original episode indices, not list positions)
    result.train_indices = [episodes[i]["episode_index"] for i in train_ep_indices]
    result.test_indices = [episodes[i]["episode_index"] for i in test_ep_indices]
    result.train_count = len(train_ep_indices)
    result.test_count = len(test_ep_indices)

    # Compute distributions
    train_eps = [episodes[i] for i in train_ep_indices]
    test_eps = [episodes[i] for i in test_ep_indices]

    train_tasks = Counter(ep["task_label"] for ep in train_eps)
    test_tasks = Counter(ep["task_label"] for ep in test_eps)
    result.train_task_dist = train_tasks.most_common()
    result.test_task_dist = test_tasks.most_common()

    train_lengths = [ep["length"] for ep in train_eps]
    test_lengths = [ep["length"] for ep in test_eps]
    if train_lengths:
        arr = np.array(train_lengths, dtype=float)
        result.train_length_stats = {"mean": float(np.mean(arr)), "std": float(np.std(arr))}
    if test_lengths:
        arr = np.array(test_lengths, dtype=float)
        result.test_length_stats = {"mean": float(np.mean(arr)), "std": float(np.std(arr))}

    # Leakage detection
    leakage_dims = check_leakage_on or ["task_label"]
    if holdout_by not in leakage_dims and holdout_by not in ("random", "episode"):
        leakage_dims.append(holdout_by)

    for dim in leakage_dims:
        train_values = Counter(ep.get(dim, "unknown") for ep in train_eps)
        test_values = Counter(ep.get(dim, "unknown") for ep in test_eps)

        overlap = set(train_values.keys()) & set(test_values.keys())
        # For the holdout dimension, overlap IS leakage
        # For other dimensions, overlap is informational (not necessarily leakage)
        if dim == holdout_by or dim == "task_label":
            for val in overlap:
                if val and val != "unknown":
                    result.leakage_issues.append(LeakageIssue(
                        dimension=dim,
                        value=val,
                        train_count=train_values[val],
                        test_count=test_values[val],
                    ))

    return result


# ---------------------------------------------------------------------------
# HTML report
# ---------------------------------------------------------------------------

def _render_html(result: SplitResult) -> str:
    total = max(result.total_episodes, 1)

    stats = "".join([
        report.stat_card(str(result.total_episodes), "Total episodes"),
        report.stat_card(f"{result.train_count} ({result.train_count/total*100:.0f}%)", "Train"),
        report.stat_card(f"{result.test_count} ({result.test_count/total*100:.0f}%)", "Test"),
        report.stat_card(
            "CLEAN" if not result.has_leakage else f"{len(result.leakage_issues)} issues",
            "Leakage",
        ),
    ])

    # Held out values
    holdout_html = ""
    if result.held_out_values:
        holdout_html = f"""<h2>Held-out {result.holdout_by}(s)</h2>
<div class="card">
  <p>The following {result.holdout_by} values are <strong>only</strong> in the test set:</p>
  <p>{', '.join(f'<code>{v}</code>' for v in result.held_out_values)}</p>
</div>"""

    # Leakage
    leakage_html = ""
    if result.leakage_issues:
        rows = ""
        for l in result.leakage_issues:
            rows += f"""<tr>
  <td>{l.dimension}</td>
  <td><code>{l.value}</code></td>
  <td style="text-align:right">{l.train_count}</td>
  <td style="text-align:right">{l.test_count}</td>
  <td>{report.badge("LEAK", "fail")}</td>
</tr>"""
        leakage_html = f"""<h2>Leakage Analysis</h2>
<div class="card" style="overflow-x:auto">
  <table>
  <thead><tr><th>Dimension</th><th>Value</th><th style="text-align:right">In Train</th><th style="text-align:right">In Test</th><th>Status</th></tr></thead>
  <tbody>{rows}</tbody></table>
</div>"""
    else:
        leakage_html = f"""<h2>Leakage Analysis</h2>
<div class="recommendation" style="border-left-color:var(--green)">
  {report.badge("CLEAN", "pass")} No leakage detected. Train and test sets have no overlap on <strong>{result.holdout_by}</strong>.
</div>"""

    # Task distributions side by side
    task_html = ""
    if result.train_task_dist or result.test_task_dist:
        task_html = f"""<h2>Task Distribution</h2>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem">
  <div class="card">
    <h3>Train ({result.train_count} episodes)</h3>
    {report.distribution_chart(result.train_task_dist[:10])}
  </div>
  <div class="card">
    <h3>Test ({result.test_count} episodes)</h3>
    {report.distribution_chart(result.test_task_dist[:10])}
  </div>
</div>"""

    # Length comparison
    length_html = ""
    if result.train_length_stats and result.test_length_stats:
        length_html = f"""<h2>Length Comparison</h2>
<div class="card">
<table>
<thead><tr><th></th><th style="text-align:right">Train</th><th style="text-align:right">Test</th></tr></thead>
<tbody>
<tr><td>Mean</td><td style="text-align:right">{result.train_length_stats.get('mean', 0):.0f}</td><td style="text-align:right">{result.test_length_stats.get('mean', 0):.0f}</td></tr>
<tr><td>Std</td><td style="text-align:right">{result.train_length_stats.get('std', 0):.0f}</td><td style="text-align:right">{result.test_length_stats.get('std', 0):.0f}</td></tr>
</tbody></table></div>"""

    return f"""
<h1>Split Report</h1>
<p class="subtitle">{result.dataset_path} &mdash; holdout by <strong>{result.holdout_by}</strong></p>

<div class="stats-row">{stats}</div>

{holdout_html}
{leakage_html}
{task_html}
{length_html}

<div class="recommendation">
  <strong>Reproducibility:</strong> Save indices with <code>result.save_indices("split.json")</code>
  to recreate this exact split.
</div>
"""
