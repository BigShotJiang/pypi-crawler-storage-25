"""Core dataset abstractions."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterator, Sequence

import numpy as np


@dataclass
class Episode:
    """A single trajectory episode.

    Attributes:
        episode_id: Unique identifier (e.g. "episode_000042").
        observations: Dict of observation arrays keyed by modality.
            Common keys: "state" (proprioception), "action", image camera names.
            Each value is shape (T, D) for vectors or (T, H, W, C) for images.
        actions: Action array, shape (T, action_dim).
        timestamps: Monotonic timestamps in seconds, shape (T,).
        metadata: Arbitrary episode metadata (task label, fps, success, etc.).
    """

    episode_id: str
    observations: dict[str, np.ndarray] = field(default_factory=dict)
    actions: np.ndarray = field(default_factory=lambda: np.empty((0,)))
    timestamps: np.ndarray = field(default_factory=lambda: np.empty((0,)))
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def length(self) -> int:
        """Number of timesteps."""
        if self.actions.ndim >= 1 and self.actions.shape[0] > 0:
            return self.actions.shape[0]
        if self.timestamps.ndim >= 1 and self.timestamps.shape[0] > 0:
            return self.timestamps.shape[0]
        for v in self.observations.values():
            if hasattr(v, "shape") and v.shape[0] > 0:
                return v.shape[0]
        return 0

    @property
    def action_dim(self) -> int:
        if self.actions.ndim == 2:
            return self.actions.shape[1]
        return 0


class TrajectoryDataset:
    """Abstract base for trajectory datasets.

    Subclasses must implement ``__len__`` and ``__getitem__``.
    """

    def __len__(self) -> int:
        raise NotImplementedError

    def __getitem__(self, idx: int) -> Episode:
        raise NotImplementedError

    def __iter__(self) -> Iterator[Episode]:
        for i in range(len(self)):
            yield self[i]

    def episode_ids(self) -> list[str]:
        """Return all episode IDs in order."""
        raise NotImplementedError

    def filter(self, episode_ids: Sequence[str]) -> "FilteredDataset":
        """Return a view containing only the specified episodes."""
        return FilteredDataset(self, list(episode_ids))


class FilteredDataset(TrajectoryDataset):
    """A filtered view over another dataset."""

    def __init__(self, parent: TrajectoryDataset, episode_ids: list[str]):
        self._parent = parent
        self._ids = episode_ids
        # Build index map: episode_id -> parent index
        parent_ids = parent.episode_ids()
        self._id_to_idx = {eid: i for i, eid in enumerate(parent_ids)}
        self._indices = [self._id_to_idx[eid] for eid in episode_ids if eid in self._id_to_idx]

    def __len__(self) -> int:
        return len(self._indices)

    def __getitem__(self, idx: int) -> Episode:
        return self._parent[self._indices[idx]]

    def episode_ids(self) -> list[str]:
        return [self._ids[i] for i in range(len(self._indices))]
