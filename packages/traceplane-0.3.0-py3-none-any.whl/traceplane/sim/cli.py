"""CLI entry points for Isaac Sim integration."""

from __future__ import annotations

import argparse


def main_viz(argv: list[str] | None = None) -> None:
    """CLI for retarget visualization (Phase 1)."""
    parser = argparse.ArgumentParser(
        description="Visualize retarget results in Isaac Sim",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    # Data source (pick one)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--dataset-path", help="Replay episode from LeRobot dataset")
    source.add_argument("--episode-path", help="Replay hand data from JSONL file")
    source.add_argument("--live", action="store_true", help="Stream from retarget API")

    # Options
    parser.add_argument("--embodiment-id", default="franka_panda", help="Robot preset")
    parser.add_argument("--episode-index", type=int, default=0, help="Episode to replay")
    parser.add_argument("--calibration-id", help="Calibration ID (for hand replay/live)")
    parser.add_argument("--api-url", default="http://localhost:8000", help="Traceplane API URL")
    parser.add_argument("--headless", action="store_true", help="Run without viewport")
    parser.add_argument("--ik-solver", default="differential", choices=["differential"])
    parser.add_argument("--playback-speed", type=float, default=1.0, help="Speed multiplier")
    parser.add_argument("--record-video", action="store_true", help="Save viewport to MP4")
    parser.add_argument("--video-path", default="./sim_replay.mp4")
    parser.add_argument("--usd-path", help="Custom robot USD asset path")

    args = parser.parse_args(argv)

    from traceplane.sim.config import VisualizerConfig
    from traceplane.sim.visualizer import RetargetVisualizer

    config = VisualizerConfig(
        api_url=args.api_url,
        embodiment_id=args.embodiment_id,
        headless=args.headless,
        usd_path=args.usd_path,
        dataset_path=args.dataset_path,
        episode_index=args.episode_index,
        episode_path=args.episode_path,
        live=args.live,
        calibration_id=args.calibration_id,
        ik_solver=args.ik_solver,
        playback_speed=args.playback_speed,
        record_video=args.record_video,
        video_path=args.video_path,
    )

    viz = RetargetVisualizer(config)
    try:
        viz.setup()
        viz.run()
    finally:
        viz.teardown()


def main_eval(argv: list[str] | None = None) -> None:
    """CLI for policy evaluation (Phase 2)."""
    parser = argparse.ArgumentParser(
        description="Evaluate a diffusion policy in Isaac Sim",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    parser.add_argument("checkpoint_path", help="Path to policy checkpoint (.pt)")

    parser.add_argument("--embodiment-id", default="franka_panda", help="Robot preset")
    parser.add_argument("--task", default="pick_place_cube", choices=["pick_place_cube"])
    parser.add_argument("--num-episodes", type=int, default=50, help="Evaluation episodes")
    parser.add_argument("--max-steps", type=int, default=300, help="Max steps per episode")
    parser.add_argument("--seed", type=int, default=42, help="Random seed")
    parser.add_argument("--headless", action="store_true", default=True, help="Run without viewport")
    parser.add_argument("--no-headless", action="store_false", dest="headless")
    parser.add_argument("--output-dir", default="./eval_output", help="Report output directory")
    parser.add_argument("--no-ema", action="store_false", dest="use_ema", help="Use raw weights")
    parser.add_argument("--obs-horizon", type=int, default=2)
    parser.add_argument("--action-horizon", type=int, default=16)
    parser.add_argument("--api-url", default="http://localhost:8000")
    parser.add_argument("--usd-path", help="Custom robot USD asset path")

    args = parser.parse_args(argv)

    from traceplane.sim.config import EvalConfig
    from traceplane.sim.evaluator import SimEvaluator

    config = EvalConfig(
        api_url=args.api_url,
        embodiment_id=args.embodiment_id,
        headless=args.headless,
        usd_path=args.usd_path,
        checkpoint_path=args.checkpoint_path,
        task=args.task,
        num_episodes=args.num_episodes,
        max_steps=args.max_steps,
        seed=args.seed,
        output_dir=args.output_dir,
        use_ema=args.use_ema,
        obs_horizon=args.obs_horizon,
        action_horizon=args.action_horizon,
    )

    evaluator = SimEvaluator(config)
    try:
        evaluator.setup()
        evaluator.evaluate()
    finally:
        evaluator.teardown()


if __name__ == "__main__":
    main_eval()
