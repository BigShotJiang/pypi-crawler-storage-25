"""Robot handle — loads USD asset and wraps Isaac Sim articulation.

Driven by an ``EmbodimentProfile`` loaded from the shared YAML registry under
``traceplane/schemas/embodiments/``. The profile supplies both action/state
dimensions and an optional ``usd_path`` (consumed here). Runtime-specific
transforms from raw articulation joints into the profile's canonical state
vector live in ``_extract_state`` / ``_apply_action`` and dispatch on
``profile.id``.
"""

from __future__ import annotations

from typing import Any

import numpy as np

from traceplane.embodiments import EmbodimentProfile, get_profile
from traceplane.sim._compat import ensure_isaacsim
from traceplane.sim.config import SimConfig


def _quat_xyzw_to_wxyz(q: np.ndarray) -> np.ndarray:
    """Convert quaternion from Traceplane (x,y,z,w) to Isaac Sim (w,x,y,z)."""
    return np.array([q[3], q[0], q[1], q[2]])


def _quat_wxyz_to_xyzw(q: np.ndarray) -> np.ndarray:
    """Convert quaternion from Isaac Sim (w,x,y,z) to Traceplane (x,y,z,w)."""
    return np.array([q[1], q[2], q[3], q[0]])


class RobotHandle:
    """Wraps an Isaac Sim robot articulation, driven by an embodiment profile.

    USD path resolution order:
        1. ``config.usd_path`` (CLI override)
        2. ``profile.usd_path`` (YAML default)
        3. Error — no asset known for this embodiment.
    """

    def __init__(
        self,
        world: Any,
        config: SimConfig,
        profile: EmbodimentProfile | None = None,
    ):
        ensure_isaacsim()
        from omni.isaac.core.utils.nucleus import get_assets_root_path
        from omni.isaac.core.robots import Robot

        self._world = world
        self._config = config
        self._profile = profile or get_profile(config.embodiment_id)

        usd_path = self._resolve_usd_path(get_assets_root_path())

        self._robot = world.scene.add(
            Robot(
                prim_path="/World/Robot",
                usd_path=usd_path,
                name="robot",
            )
        )

    def _resolve_usd_path(self, assets_root: str | None) -> str:
        if self._config.usd_path:
            return self._config.usd_path
        if self._profile.usd_path:
            relative = self._profile.usd_path
            if relative.startswith("/Isaac/") and assets_root:
                return assets_root + relative
            return relative
        raise ValueError(
            f"No USD path available for embodiment '{self._profile.id}'. "
            f"Add `usd_path` to its YAML profile or pass --usd-path."
        )

    # -- Lifecycle -----------------------------------------------------------

    def initialize(self) -> None:
        """Call after ``world.reset()`` to initialize the articulation controller."""
        self._robot.initialize()
        self._controller = self._robot.get_articulation_controller()

    @property
    def profile(self) -> EmbodimentProfile:
        return self._profile

    # -- Raw articulation accessors -----------------------------------------

    def get_joint_positions(self) -> np.ndarray:
        return self._robot.get_joint_positions()

    def get_joint_velocities(self) -> np.ndarray:
        return self._robot.get_joint_velocities()

    def get_ee_pose(self) -> tuple[np.ndarray, np.ndarray]:
        """End-effector pose as ``(position[3], quaternion_xyzw[4])``.

        Per-embodiment EE prim paths live in ``_EE_PRIMS`` below. Falls back to
        the robot's world pose if the named prim is missing.
        """
        from omni.isaac.core.utils.transformations import get_world_transform_xform
        import omni.usd

        stage = omni.usd.get_context().get_stage()
        ee_prim_path = _EE_PRIMS.get(self._profile.id)
        if ee_prim_path is not None:
            ee_prim = stage.GetPrimAtPath(ee_prim_path)
            if ee_prim.IsValid():
                pos, quat_wxyz = get_world_transform_xform(ee_prim)
                return np.array(pos), _quat_wxyz_to_xyzw(np.array(quat_wxyz))

        pos = self._robot.get_world_pose()
        return np.array(pos[0]), _quat_wxyz_to_xyzw(np.array(pos[1]))

    # -- Profile-aware state / action ---------------------------------------

    def get_obs_state(self) -> np.ndarray:
        """State vector matching ``profile.state_dim``."""
        return self._extract_state(self.get_joint_positions())

    def _extract_state(self, positions: np.ndarray) -> np.ndarray:
        """Map raw articulation joint positions to the canonical state vector.

        Franka: Isaac exposes 9 joints (7 arm + 2 fingers) but the profile's
        state vector is 8-dim, where the last dim is total finger width. Other
        embodiments currently pass through the first ``state_dim`` joints.
        """
        if self._profile.id == "franka_panda":
            if positions.shape[0] < 9:
                raise RuntimeError(
                    f"Franka articulation expected 9 joints, got {positions.shape[0]}"
                )
            arm = positions[:7]
            finger_width = np.array([positions[7] + positions[8]])
            return np.concatenate([arm, finger_width]).astype(np.float32)
        return positions[: self._profile.state_dim].astype(np.float32)

    def set_joint_positions(self, positions: np.ndarray) -> None:
        """Set target joint positions directly (no profile projection)."""
        self._controller.apply_action(joint_positions=positions)

    def set_gripper(self, width: float) -> None:
        """Set gripper target. Franka splits the width across both fingers;
        other embodiments write ``width`` to the first prismatic gripper joint.
        """
        if self._profile.id == "franka_panda":
            positions = self.get_joint_positions()
            if positions.shape[0] < 9:
                return
            half = float(width) / 2.0
            positions[7] = half
            positions[8] = half
            self._controller.apply_action(joint_positions=positions)
            return

        gripper_group = self._profile.group("gripper")
        if gripper_group is None or not gripper_group.joints:
            return
        action_idx = gripper_group.joints[0].action_index
        positions = self.get_joint_positions()
        if action_idx >= positions.shape[0]:
            return
        positions[action_idx] = float(width)
        self._controller.apply_action(joint_positions=positions)


# Per-embodiment end-effector prim path inside the spawned USD. Add as more
# robots get sim scenes wired up.
_EE_PRIMS: dict[str, str] = {
    "franka_panda": "/World/Robot/panda_hand",
}
