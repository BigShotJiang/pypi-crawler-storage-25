"""Centralized import guard for Isaac Sim dependencies."""

_INSTALL_MSG = (
    "Isaac Sim is required for traceplane.sim. "
    "Install it with:\n"
    "  pip install isaacsim==5.* --extra-index-url https://pypi.nvidia.com\n"
    "Or run: scripts/setup_isaac_sim.sh"
)


def ensure_isaacsim() -> None:
    """Raise ImportError if isaacsim is not available."""
    try:
        import isaacsim  # noqa: F401
    except ImportError:
        raise ImportError(_INSTALL_MSG)
