"""IK controller adapter for Isaac Sim.

Converts EE pose targets (from the Traceplane retarget API) to joint
positions using Isaac Sim's DifferentialIKController.

Handles quaternion convention conversion:
Traceplane uses (x, y, z, w), Isaac Sim uses (w, x, y, z).
"""

from __future__ import annotations

from typing import Any

import numpy as np

from traceplane.sim._compat import ensure_isaacsim
from traceplane.sim.robot import RobotHandle, _quat_xyzw_to_wxyz


class IKController:
    """Wraps Isaac Sim's IK solver for EE pose → joint angle conversion.

    Args:
        robot: The robot handle.
        solver: IK solver type ("differential" or "rmpflow").
    """

    def __init__(self, robot: RobotHandle, solver: str = "differential"):
        ensure_isaacsim()
        self._robot = robot
        self._solver = solver
        self._ik = None

    def initialize(self) -> None:
        """Initialize the IK solver. Call after robot.initialize()."""
        if self._solver == "differential":
            from omni.isaac.core.controllers import DifferentialIKController

            self._ik = DifferentialIKController(
                name="ik_controller",
                robot_articulation=self._robot._robot,
            )
        else:
            raise ValueError(f"Unknown IK solver: {self._solver}")

    def solve(
        self,
        target_pos: np.ndarray,
        target_quat_xyzw: np.ndarray,
    ) -> np.ndarray | None:
        """Solve IK for a target EE pose.

        Args:
            target_pos: Target position (3,) in robot base frame.
            target_quat_xyzw: Target orientation as quaternion (x,y,z,w).

        Returns:
            Joint positions (n_arm_joints,) or None if IK fails.
        """
        if self._ik is None:
            raise RuntimeError("Call initialize() first")

        # Convert to Isaac Sim quaternion convention (w,x,y,z)
        target_quat_wxyz = _quat_xyzw_to_wxyz(target_quat_xyzw)

        try:
            action = self._ik.forward(
                target_end_effector_position=target_pos,
                target_end_effector_orientation=target_quat_wxyz,
            )
            joint_positions = action.joint_positions
            if joint_positions is not None:
                return np.array(joint_positions)
        except Exception:
            pass

        return None
