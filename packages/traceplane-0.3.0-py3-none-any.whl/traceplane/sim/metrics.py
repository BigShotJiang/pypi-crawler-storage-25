"""Evaluation metrics — pure numpy, no Isaac Sim dependency."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np


@dataclass
class EpisodeResult:
    """Metrics from a single evaluation episode."""

    success: bool
    steps: int
    seed: int
    joint_positions: np.ndarray  # (T, n_joints)
    ee_positions: np.ndarray  # (T, 3)
    actions: np.ndarray  # (T, action_dim)
    joint_limit_violations: int = 0


@dataclass
class EvalReport:
    """Aggregate evaluation report across multiple episodes."""

    num_episodes: int
    success_rate: float
    mean_steps: float
    mean_smoothness: float
    total_joint_violations: int
    episode_results: list[EpisodeResult] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "num_episodes": self.num_episodes,
            "success_rate": self.success_rate,
            "mean_steps": self.mean_steps,
            "mean_smoothness": self.mean_smoothness,
            "total_joint_violations": self.total_joint_violations,
            "episodes": [
                {
                    "success": r.success,
                    "steps": r.steps,
                    "seed": r.seed,
                    "joint_limit_violations": r.joint_limit_violations,
                    "smoothness": compute_smoothness(r.actions),
                }
                for r in self.episode_results
            ],
        }


def compute_smoothness(actions: np.ndarray) -> float:
    """Mean L2 norm of consecutive action deltas.

    Lower = smoother trajectory. Returns 0.0 for single-step episodes.
    """
    if actions.ndim < 2 or actions.shape[0] < 2:
        return 0.0
    deltas = np.diff(actions, axis=0)
    return float(np.mean(np.linalg.norm(deltas, axis=1)))


def count_joint_violations(
    positions: np.ndarray,
    limits: list[tuple[float, float]],
) -> int:
    """Count timesteps where any joint exceeds its limits.

    Args:
        positions: (T, n_joints) joint position array.
        limits: Per-joint (lower, upper) bounds.

    Returns:
        Total number of (timestep, joint) violations.
    """
    violations = 0
    n_joints = min(positions.shape[1], len(limits))
    for j in range(n_joints):
        lower, upper = limits[j]
        violations += int(np.sum(positions[:, j] < lower))
        violations += int(np.sum(positions[:, j] > upper))
    return violations


def compile_report(results: list[EpisodeResult]) -> EvalReport:
    """Compile individual episode results into an aggregate report."""
    if not results:
        return EvalReport(
            num_episodes=0,
            success_rate=0.0,
            mean_steps=0.0,
            mean_smoothness=0.0,
            total_joint_violations=0,
        )

    successes = sum(1 for r in results if r.success)
    smoothness_vals = [compute_smoothness(r.actions) for r in results]
    total_violations = sum(r.joint_limit_violations for r in results)

    return EvalReport(
        num_episodes=len(results),
        success_rate=successes / len(results),
        mean_steps=np.mean([r.steps for r in results]).item(),
        mean_smoothness=np.mean(smoothness_vals).item(),
        total_joint_violations=total_violations,
        episode_results=results,
    )
