"""Write simulated rollouts to disk as canonical LeRobot v2 datasets.

The writer produces a directory that can be read back with
``traceplane.lerobot_reader.LeRobotReader`` and validated with
``traceplane check``. Output layout::

    {output_dir}/
      meta/
        info.json       # written at close()
        tasks.jsonl     # written at close()
        episodes.jsonl  # written at close()
      data/
        chunk-000/
          episode_000000.parquet
          episode_000001.parquet
          ...

This closes the loop from sim-eval back into the Traceplane lakehouse: rollouts
become canonical episodes instead of throwaway JSON reports.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq

from traceplane.embodiments import EmbodimentProfile


# LeRobot v2 uses a codebase_version string of "v2.0" in meta/info.json.
_CODEBASE_VERSION = "v2.0"


class SimEpisodeWriter:
    """Accumulates simulated episodes and writes a LeRobot v2 dataset on close.

    Thread-unsafe: call ``add_episode`` from a single thread. Each episode is
    flushed to its own parquet file inside a chunked data directory; metadata
    files are written when ``close()`` is called.

    Args:
        output_dir: Destination directory. Created if missing. Should be empty
            for a clean dataset; existing contents are not cleared.
        profile: Embodiment profile describing the action/state vector layout.
            ``action_dim``/``state_dim`` must match the arrays passed to
            ``add_episode``.
        fps: Sampling rate of the rollouts, used to fill info.json.
        task: Human-readable task label (e.g. ``"pick and place the cube"``).
            Stored in tasks.jsonl and referenced by each episode.
        chunk_size: Episodes per chunk directory (default 1000, matching
            upstream LeRobot convention).
        source: Optional free-form source tag (e.g. ``"sim"``, ``"isaac_lab"``)
            recorded in info.json for provenance. Not interpreted downstream.
    """

    def __init__(
        self,
        output_dir: str | Path,
        profile: EmbodimentProfile,
        fps: float,
        task: str = "",
        chunk_size: int = 1000,
        source: str = "sim",
    ):
        if fps <= 0:
            raise ValueError(f"fps must be positive, got {fps}")
        if chunk_size <= 0:
            raise ValueError(f"chunk_size must be positive, got {chunk_size}")

        self._output_dir = Path(output_dir)
        self._profile = profile
        self._fps = float(fps)
        self._task = task
        self._chunk_size = int(chunk_size)
        self._source = source

        self._episode_index = 0
        self._total_frames = 0
        self._episode_records: list[dict[str, Any]] = []
        self._closed = False

        (self._output_dir / "meta").mkdir(parents=True, exist_ok=True)
        (self._output_dir / "data").mkdir(parents=True, exist_ok=True)

    @property
    def episode_count(self) -> int:
        return self._episode_index

    @property
    def total_frames(self) -> int:
        return self._total_frames

    def add_episode(
        self,
        actions: np.ndarray,
        states: np.ndarray,
        timestamps: np.ndarray | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> int:
        """Append one episode to the dataset.

        Args:
            actions: Array of shape ``(T, action_dim)``.
            states: Array of shape ``(T, state_dim)``.
            timestamps: Optional array of shape ``(T,)`` in seconds. If
                omitted, uniform ``1/fps`` spacing is used.
            metadata: Optional extra fields to record on the episode entry in
                ``episodes.jsonl`` (e.g. ``{"success": True, "seed": 42}``).

        Returns:
            The episode index assigned to this episode (starts at 0).

        Raises:
            RuntimeError: if the writer is closed.
            ValueError: on shape/dim mismatch or zero-length arrays.
        """
        if self._closed:
            raise RuntimeError("SimEpisodeWriter is closed")

        actions = np.asarray(actions)
        states = np.asarray(states)

        if actions.ndim != 2:
            raise ValueError(f"actions must be 2D (T, action_dim), got shape {actions.shape}")
        if states.ndim != 2:
            raise ValueError(f"states must be 2D (T, state_dim), got shape {states.shape}")

        n_frames = actions.shape[0]
        if n_frames == 0:
            raise ValueError("refusing to write an empty episode (T=0)")
        if states.shape[0] != n_frames:
            raise ValueError(
                f"actions and states must share T; got {n_frames} vs {states.shape[0]}"
            )
        if actions.shape[1] != self._profile.action_dim:
            raise ValueError(
                f"action_dim mismatch: profile expects {self._profile.action_dim}, "
                f"got {actions.shape[1]}"
            )
        if states.shape[1] != self._profile.state_dim:
            raise ValueError(
                f"state_dim mismatch: profile expects {self._profile.state_dim}, "
                f"got {states.shape[1]}"
            )

        if timestamps is None:
            timestamps = np.arange(n_frames, dtype=np.float64) / self._fps
        else:
            timestamps = np.asarray(timestamps, dtype=np.float64)
            if timestamps.shape != (n_frames,):
                raise ValueError(
                    f"timestamps must have shape ({n_frames},), got {timestamps.shape}"
                )

        ep_index = self._episode_index
        chunk_index = ep_index // self._chunk_size
        frame_offset = self._total_frames

        columns: dict[str, pa.Array] = {}
        for i in range(self._profile.action_dim):
            columns[f"action_{i}"] = pa.array(actions[:, i].astype(np.float32))
        for i in range(self._profile.state_dim):
            columns[f"observation.state_{i}"] = pa.array(states[:, i].astype(np.float32))
        columns["timestamp"] = pa.array(timestamps)
        columns["frame_index"] = pa.array(np.arange(n_frames, dtype=np.int64))
        columns["episode_index"] = pa.array(np.full(n_frames, ep_index, dtype=np.int64))
        columns["index"] = pa.array(
            np.arange(frame_offset, frame_offset + n_frames, dtype=np.int64)
        )

        table = pa.table(columns)

        chunk_dir = self._output_dir / "data" / f"chunk-{chunk_index:03d}"
        chunk_dir.mkdir(parents=True, exist_ok=True)
        parquet_path = chunk_dir / f"episode_{ep_index:06d}.parquet"
        pq.write_table(table, parquet_path)

        record: dict[str, Any] = {
            "episode_index": ep_index,
            "tasks": [0],
            "length": n_frames,
        }
        if metadata:
            for k, v in metadata.items():
                if k in record:
                    raise ValueError(f"metadata cannot override reserved key: {k}")
                record[k] = _jsonable(v)
        self._episode_records.append(record)

        self._episode_index += 1
        self._total_frames += n_frames
        return ep_index

    def close(self) -> None:
        """Finalize the dataset by writing ``meta/info.json``, ``tasks.jsonl``,
        and ``episodes.jsonl``. Idempotent: safe to call more than once."""
        if self._closed:
            return

        meta_dir = self._output_dir / "meta"

        total_chunks = max(1, (self._episode_index + self._chunk_size - 1) // self._chunk_size)
        info = {
            "codebase_version": _CODEBASE_VERSION,
            "robot_type": self._profile.id,
            "total_episodes": self._episode_index,
            "total_frames": self._total_frames,
            "total_tasks": 1,
            "total_videos": 0,
            "total_chunks": total_chunks,
            "chunks_size": self._chunk_size,
            "fps": self._fps,
            "splits": {"train": f"0:{self._episode_index}"},
            "data_path": "data/chunk-{episode_chunk:03d}/episode_{episode_index:06d}.parquet",
            "source": self._source,
            "embodiment": {
                "id": self._profile.id,
                "action_dim": self._profile.action_dim,
                "state_dim": self._profile.state_dim,
            },
        }
        with open(meta_dir / "info.json", "w") as f:
            json.dump(info, f, indent=2)

        with open(meta_dir / "tasks.jsonl", "w") as f:
            f.write(json.dumps({"task_index": 0, "task": self._task}) + "\n")

        with open(meta_dir / "episodes.jsonl", "w") as f:
            for record in self._episode_records:
                f.write(json.dumps(record) + "\n")

        self._closed = True

    # Context manager support ------------------------------------------------

    def __enter__(self) -> SimEpisodeWriter:
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if exc_type is None:
            self.close()


def _jsonable(value: Any) -> Any:
    """Coerce numpy scalars/arrays to plain Python for JSON serialization."""
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, (np.bool_,)):
        return bool(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    return value


__all__ = ["SimEpisodeWriter"]
