"""Task scenes for policy evaluation in Isaac Sim."""

from __future__ import annotations

from typing import Any

import numpy as np

from traceplane.sim._compat import ensure_isaacsim


class PickPlaceCubeScene:
    """Pick-and-place task with a cube on a table.

    The cube starts at a random position on the table surface.
    Success = cube is within 3cm of the target location and stable.
    """

    CUBE_SIZE = 0.04  # 4cm cube
    TABLE_HEIGHT = 0.4
    TARGET_POS = np.array([0.4, 0.0, TABLE_HEIGHT + CUBE_SIZE / 2])
    SUCCESS_THRESHOLD = 0.03  # 3cm

    def __init__(self, world: Any):
        ensure_isaacsim()
        from omni.isaac.core.objects import DynamicCuboid, FixedCuboid

        self._world = world

        # Table
        self._table = world.scene.add(
            FixedCuboid(
                prim_path="/World/Table",
                name="table",
                position=np.array([0.4, 0.0, self.TABLE_HEIGHT / 2]),
                scale=np.array([0.6, 0.8, self.TABLE_HEIGHT]),
                color=np.array([0.4, 0.3, 0.2]),
            )
        )

        # Manipulation cube
        self._cube = world.scene.add(
            DynamicCuboid(
                prim_path="/World/Cube",
                name="cube",
                position=np.array([0.4, 0.0, self.TABLE_HEIGHT + self.CUBE_SIZE]),
                scale=np.array([self.CUBE_SIZE] * 3),
                color=np.array([0.8, 0.2, 0.2]),
                mass=0.05,
            )
        )

        # Visual target marker
        self._target = world.scene.add(
            FixedCuboid(
                prim_path="/World/Target",
                name="target",
                position=self.TARGET_POS,
                scale=np.array([self.CUBE_SIZE, self.CUBE_SIZE, 0.002]),
                color=np.array([0.2, 0.8, 0.2]),
            )
        )

    def setup(self, seed: int) -> None:
        """Randomize cube starting position for a new episode."""
        rng = np.random.RandomState(seed)
        x = rng.uniform(0.25, 0.55)
        y = rng.uniform(-0.2, 0.2)
        z = self.TABLE_HEIGHT + self.CUBE_SIZE
        self._cube.set_world_pose(
            position=np.array([x, y, z]),
            orientation=np.array([1, 0, 0, 0]),  # wxyz identity
        )
        self._cube.set_linear_velocity(np.zeros(3))
        self._cube.set_angular_velocity(np.zeros(3))

    def reset(self, seed: int) -> None:
        """Alias for setup."""
        self.setup(seed)

    def get_cube_pose(self) -> tuple[np.ndarray, np.ndarray]:
        """Get cube position and orientation (wxyz)."""
        pos, quat = self._cube.get_world_pose()
        return np.array(pos), np.array(quat)

    def check_success(self) -> bool:
        """Check if cube is at target location and stable."""
        pos, _ = self.get_cube_pose()
        dist = np.linalg.norm(pos - self.TARGET_POS)
        vel = np.linalg.norm(self._cube.get_linear_velocity())
        return dist < self.SUCCESS_THRESHOLD and vel < 0.05
