"""Isaac Sim integration for Traceplane — visualization and policy evaluation.

This package requires Isaac Sim to be installed separately.
Import is lazy: this module can be imported without Isaac Sim for
pip install and introspection. Isaac Sim is only required when
constructing classes.

Setup:
    pip install isaacsim==5.* --extra-index-url https://pypi.nvidia.com
    pip install -e ".[sim]"
"""

from traceplane.sim.config import SimConfig, VisualizerConfig, EvalConfig
from traceplane.sim.metrics import (
    EpisodeResult,
    EvalReport,
    compile_report,
    compute_smoothness,
    count_joint_violations,
)

__all__ = [
    "SimConfig",
    "VisualizerConfig",
    "EvalConfig",
    "EpisodeResult",
    "EvalReport",
    "compile_report",
    "compute_smoothness",
    "count_joint_violations",
]
