"""Phase 1: Retarget visualization in Isaac Sim.

Replays retargeted hand poses or dataset episodes through a simulated
robot, providing visual validation of the capture → retarget pipeline.
"""

from __future__ import annotations

import sys
import time
from typing import Any

import numpy as np

from traceplane.sim._compat import ensure_isaacsim
from traceplane.sim.config import VisualizerConfig


class RetargetVisualizer:
    """Visualize retarget results or episode replays in Isaac Sim.

    Supports three data sources:
        - Dataset replay: plays back joint actions from a LeRobot dataset
        - Episode path: replays hand data through the retarget API
        - Live stream: real-time retarget from the Traceplane API
    """

    def __init__(self, config: VisualizerConfig):
        ensure_isaacsim()
        self._config = config
        self._app = None
        self._world = None
        self._robot = None
        self._ik = None

    def setup(self) -> None:
        """Launch Isaac Sim, load robot, initialize IK."""
        from isaacsim import SimulationApp
        from omni.isaac.core import World

        from traceplane.sim.robot import RobotHandle
        from traceplane.sim.controller import IKController

        self._app = SimulationApp({
            "headless": self._config.headless,
            "width": 1280,
            "height": 720,
        })

        self._world = World(
            physics_dt=self._config.physics_dt,
            rendering_dt=self._config.rendering_dt,
            stage_units_in_meters=1.0,
        )

        # Add ground plane
        self._world.scene.add_default_ground_plane()

        # Load robot
        self._robot = RobotHandle(self._world, self._config)

        # Reset world to initialize physics
        self._world.reset()
        self._robot.initialize()

        # Initialize IK controller
        self._ik = IKController(self._robot, self._config.ik_solver)
        self._ik.initialize()

        print(f"Isaac Sim ready — {self._config.embodiment_id}", file=sys.stderr)

    def visualize_retarget_result(self, result: dict[str, Any]) -> None:
        """Apply a single retarget result to the simulated robot.

        Args:
            result: Dict with ``ee_pose_robot_frame`` and ``gripper_command``
                    (as returned by the retarget API).
        """
        ee_pose = result.get("ee_pose_robot_frame", {})
        pos = np.array(ee_pose.get("translation", [0.3, 0, 0.5]))
        quat_xyzw = np.array(ee_pose.get("rotation", [0, 0, 0, 1]))

        # IK solve
        joint_angles = self._ik.solve(pos, quat_xyzw)
        if joint_angles is not None:
            self._robot.set_joint_positions(joint_angles)

        # Gripper
        gripper = result.get("gripper_command")
        if gripper is not None:
            self._robot.set_gripper(float(gripper))

        self._world.step(render=not self._config.headless)

    def replay_dataset_episode(self) -> None:
        """Replay an episode from a LeRobot dataset (direct joint control)."""
        from traceplane.lerobot_reader import LeRobotReader

        reader = LeRobotReader(
            self._config.dataset_path,
            episode_indices=[self._config.episode_index],
        )
        if len(reader) == 0:
            print("No episodes found", file=sys.stderr)
            return

        episode = reader[0]
        fps = episode.metadata.get("fps", 30.0)
        dt = 1.0 / (fps * self._config.playback_speed)
        T = episode.length

        print(f"Replaying episode {self._config.episode_index} "
              f"({T} steps at {fps}fps)", file=sys.stderr)

        for t in range(T):
            action = episode.actions[t]
            # Assume action matches joint ordering for this embodiment
            arm_joints = action[:7] if len(action) >= 7 else action
            self._robot.set_joint_positions(arm_joints)

            if len(action) >= 8:
                self._robot.set_gripper(float(action[7]))

            self._world.step(render=not self._config.headless)
            time.sleep(max(0, dt - self._config.physics_dt))

        print("Replay complete", file=sys.stderr)

    def replay_hand_episode(self) -> None:
        """Replay hand data from a JSONL file through the retarget API."""
        import json
        from traceplane.query import TraceplaneClient

        client = TraceplaneClient(self._config.api_url)

        if not self._config.calibration_id:
            raise ValueError("--calibration-id required for hand episode replay")

        with open(self._config.episode_path) as f:
            lines = f.readlines()

        print(f"Replaying {len(lines)} hand frames", file=sys.stderr)

        for line in lines:
            frame = json.loads(line.strip())
            joints = frame.get("joints", [])
            if not joints:
                continue

            result = client.retarget(
                calibration_id=self._config.calibration_id,
                embodiment_id=self._config.embodiment_id,
                hand_joints=joints,
                target_group="arm",
            )
            self.visualize_retarget_result(result)

        print("Hand replay complete", file=sys.stderr)

    def stream_live(self) -> None:
        """Stream live retarget results (placeholder for XR integration)."""
        print("Live streaming mode — press Ctrl+C to stop", file=sys.stderr)
        print("(Waiting for retarget API calls...)", file=sys.stderr)

        # In a real implementation, this would poll the API or
        # receive WebSocket updates. For now, just keep the sim running.
        try:
            while True:
                self._world.step(render=not self._config.headless)
        except KeyboardInterrupt:
            print("\nStopped", file=sys.stderr)

    def run(self) -> None:
        """Main entry point — select data source and start visualization."""
        if self._config.dataset_path:
            self.replay_dataset_episode()
        elif self._config.episode_path:
            self.replay_hand_episode()
        elif self._config.live:
            self.stream_live()
        else:
            print("No data source specified. Use --dataset-path, "
                  "--episode-path, or --live", file=sys.stderr)

    def teardown(self) -> None:
        """Clean up Isaac Sim."""
        if self._app:
            self._app.close()
