"""Action chunking and observation windowing for training."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

from traceplane.dataset import Episode, TrajectoryDataset


@dataclass
class Window:
    """A training sample: observation history + action chunk at one timestep.

    Attributes:
        episode_id: Source episode.
        timestep: Center timestep index within the episode.
        obs_history: Dict of observation arrays, each shape (obs_horizon, D).
        action_chunk: Action array, shape (action_horizon, action_dim).
        metadata: Episode metadata.
    """

    episode_id: str
    timestep: int
    obs_history: dict[str, np.ndarray]
    action_chunk: np.ndarray
    metadata: dict[str, Any]


class WindowedDataset:
    """Slide a window over episodes to produce training samples.

    This is the interface training loops actually use: each sample is
    (obs_history, action_chunk) at a given timestep.

    Args:
        dataset: Source trajectory dataset.
        obs_horizon: Number of past observation frames (inclusive of current).
        action_horizon: Number of future action frames to predict.
        stride: Step between consecutive windows within an episode.
    """

    def __init__(
        self,
        dataset: TrajectoryDataset,
        obs_horizon: int = 2,
        action_horizon: int = 16,
        stride: int = 1,
    ):
        self._dataset = dataset
        self._obs_horizon = obs_horizon
        self._action_horizon = action_horizon
        self._stride = stride

        # Pre-compute the global index: (episode_idx, timestep)
        self._index: list[tuple[int, int]] = []
        for ep_idx in range(len(dataset)):
            ep = dataset[ep_idx]
            T = ep.length
            if T == 0:
                continue
            # Valid timesteps: need obs_horizon-1 past frames and
            # action_horizon future frames
            start = self._obs_horizon - 1
            end = T - self._action_horizon + 1
            for t in range(start, max(start, end), self._stride):
                self._index.append((ep_idx, t))

    def __len__(self) -> int:
        return len(self._index)

    def __getitem__(self, idx: int) -> Window:
        ep_idx, t = self._index[idx]
        ep = self._dataset[ep_idx]

        # Observation history: [t - obs_horizon + 1, ..., t]
        obs_start = t - self._obs_horizon + 1
        obs_history: dict[str, np.ndarray] = {}
        for key, arr in ep.observations.items():
            if arr.ndim >= 1 and arr.shape[0] > t:
                obs_history[key] = arr[obs_start : t + 1]

        # Action chunk: [t, ..., t + action_horizon - 1]
        action_end = min(t + self._action_horizon, ep.length)
        action_chunk = ep.actions[t:action_end]

        # Pad if we're near the end
        if action_chunk.shape[0] < self._action_horizon:
            pad_len = self._action_horizon - action_chunk.shape[0]
            if action_chunk.ndim == 2:
                pad = np.repeat(action_chunk[-1:], pad_len, axis=0)
            else:
                pad = np.repeat(action_chunk[-1:], pad_len)
            action_chunk = np.concatenate([action_chunk, pad], axis=0)

        return Window(
            episode_id=ep.episode_id,
            timestep=t,
            obs_history=obs_history,
            action_chunk=action_chunk,
            metadata=ep.metadata,
        )

    @property
    def obs_horizon(self) -> int:
        return self._obs_horizon

    @property
    def action_horizon(self) -> int:
        return self._action_horizon
