"""PyTorch integration — Dataset and DataLoader wrappers."""

from __future__ import annotations

from typing import Any

import numpy as np

try:
    import torch
    from torch.utils.data import Dataset as TorchDataset, DataLoader
except ImportError:
    raise ImportError(
        "PyTorch is required for traceplane.torch. "
        "Install it with: pip install traceplane[torch]"
    )

from traceplane.dataset import TrajectoryDataset
from traceplane.windowing import WindowedDataset, Window


class EpisodeDataset(TorchDataset):
    """PyTorch Dataset that yields full episodes as dicts of tensors.

    Each item is a dict with:
        - ``actions``: (T, action_dim)
        - ``timestamps``: (T,)
        - ``episode_id``: str
        - ``metadata``: dict
        - observation keys: (T, D)
    """

    def __init__(self, dataset: TrajectoryDataset):
        self._dataset = dataset

    def __len__(self) -> int:
        return len(self._dataset)

    def __getitem__(self, idx: int) -> dict[str, Any]:
        ep = self._dataset[idx]
        item: dict[str, Any] = {
            "episode_id": ep.episode_id,
            "metadata": ep.metadata,
            "actions": torch.from_numpy(np.asarray(ep.actions, dtype=np.float32)),
            "timestamps": torch.from_numpy(
                np.asarray(ep.timestamps, dtype=np.float64)
            ),
        }
        for key, arr in ep.observations.items():
            item[key] = torch.from_numpy(np.asarray(arr, dtype=np.float32))
        return item


class WindowDataset(TorchDataset):
    """PyTorch Dataset that yields windowed training samples.

    Each item is a dict with:
        - ``obs_history``: dict of tensors, each (obs_horizon, D)
        - ``action_chunk``: (action_horizon, action_dim)
        - ``episode_id``: str
        - ``timestep``: int
    """

    def __init__(self, windowed: WindowedDataset):
        self._windowed = windowed

    def __len__(self) -> int:
        return len(self._windowed)

    def __getitem__(self, idx: int) -> dict[str, Any]:
        w = self._windowed[idx]
        item: dict[str, Any] = {
            "episode_id": w.episode_id,
            "timestep": w.timestep,
            "action_chunk": torch.from_numpy(
                np.asarray(w.action_chunk, dtype=np.float32)
            ),
            "obs_history": {
                key: torch.from_numpy(np.asarray(arr, dtype=np.float32))
                for key, arr in w.obs_history.items()
            },
        }
        return item


def make_dataloader(
    dataset: TrajectoryDataset,
    obs_horizon: int = 2,
    action_horizon: int = 16,
    stride: int = 1,
    batch_size: int = 64,
    shuffle: bool = True,
    num_workers: int = 0,
    **kwargs: Any,
) -> DataLoader:
    """Create a PyTorch DataLoader with windowed training samples.

    This is the recommended entry point for training.

    Args:
        dataset: Source trajectory dataset (e.g. ``LeRobotReader``).
        obs_horizon: Observation history length.
        action_horizon: Action prediction horizon.
        stride: Window stride.
        batch_size: Batch size.
        shuffle: Shuffle samples.
        num_workers: DataLoader workers.
        **kwargs: Extra args passed to ``DataLoader``.

    Returns:
        A PyTorch ``DataLoader`` yielding batched training dicts.
    """
    windowed = WindowedDataset(
        dataset,
        obs_horizon=obs_horizon,
        action_horizon=action_horizon,
        stride=stride,
    )
    torch_ds = WindowDataset(windowed)
    return DataLoader(
        torch_ds,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        **kwargs,
    )
