"""traceplane segment — segment-level scoring and salvage.

Scores sub-episode segments rather than whole episodes. Salvages good
segments from otherwise poor episodes. Supports weighted segment export.

Usage::

    from traceplane.segment import segment_curate
    result = segment_curate("/path/to/dataset", window_size=50, stride=25)
    result.print()
    result.to_html("segment_report.html")
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np

from traceplane import report


@dataclass
class SegmentScore:
    episode_id: str
    episode_index: int
    start_frame: int
    end_frame: int
    length: int
    smoothness: float
    energy: float      # action energy (mean L2 norm) — filters idle segments
    composite: float
    recommendation: str  # "keep", "salvage", "drop"


@dataclass
class SegmentResult:
    dataset_path: str
    total_episodes: int = 0
    total_segments: int = 0
    keep_segments: int = 0
    salvage_segments: int = 0
    drop_segments: int = 0
    episodes_with_salvage: int = 0  # episodes where some segments are good
    segments: list[SegmentScore] = field(default_factory=list)

    @property
    def salvage_rate(self) -> float:
        """Fraction of segments salvaged from otherwise poor episodes."""
        return self.salvage_segments / max(self.total_segments, 1)

    def print(self) -> None:
        print(f"\n{'='*60}")
        print(f"  traceplane segment — {self.dataset_path}")
        print(f"{'='*60}")
        print(f"  Episodes:           {self.total_episodes}")
        print(f"  Segments scored:    {self.total_segments}")
        print(f"  Keep:               {self.keep_segments}")
        print(f"  Salvage:            {self.salvage_segments} (from {self.episodes_with_salvage} episodes)")
        print(f"  Drop:               {self.drop_segments}")
        print()

        if self.segments:
            print(f"  {'Episode':<16} {'Frames':<12} {'Smooth':>7} {'Energy':>7} {'Score':>7} {'Rec':<8}")
            print(f"  {'-'*16} {'-'*12} {'-'*7} {'-'*7} {'-'*7} {'-'*8}")
            for s in self.segments[:20]:
                frames = f"{s.start_frame}-{s.end_frame}"
                print(f"  {s.episode_id:<16} {frames:<12} {s.smoothness:>7.2f} {s.energy:>7.2f} {s.composite:>7.2f} {s.recommendation:<8}")
            if len(self.segments) > 20:
                print(f"  ... and {len(self.segments) - 20} more")

        print(f"\n{'='*60}\n")

    def to_html(self, path: str) -> None:
        body = _render_html(self)
        html = report.html_document(f"Segment Curation — {self.dataset_path}", body)
        Path(path).write_text(html)

    def to_dict(self) -> dict[str, Any]:
        return {
            "dataset_path": self.dataset_path,
            "total_episodes": self.total_episodes,
            "total_segments": self.total_segments,
            "keep_segments": self.keep_segments,
            "salvage_segments": self.salvage_segments,
            "drop_segments": self.drop_segments,
            "episodes_with_salvage": self.episodes_with_salvage,
            "segments": [
                {
                    "episode_id": s.episode_id,
                    "episode_index": s.episode_index,
                    "start_frame": s.start_frame,
                    "end_frame": s.end_frame,
                    "smoothness": round(s.smoothness, 4),
                    "energy": round(s.energy, 4),
                    "composite": round(s.composite, 4),
                    "recommendation": s.recommendation,
                }
                for s in self.segments
            ],
        }

    def salvaged_spans(self) -> list[dict[str, Any]]:
        """Return spans to keep (both 'keep' and 'salvage' segments)."""
        return [
            {
                "episode_index": s.episode_index,
                "start_frame": s.start_frame,
                "end_frame": s.end_frame,
                "score": s.composite,
            }
            for s in self.segments
            if s.recommendation in ("keep", "salvage")
        ]


def segment_curate(
    path: str,
    window_size: int = 50,
    stride: int = 25,
    max_episodes: int | None = None,
    keep_threshold: float = 0.6,
    drop_threshold: float = 0.3,
    min_energy: float = 0.01,
) -> SegmentResult:
    """Score and curate at the segment level.

    Slides a window across each episode's action trajectory, scores each
    segment independently, and identifies salvageable segments from
    poor episodes.

    Args:
        path: Path to dataset root.
        window_size: Segment length in frames.
        stride: Step size between segments.
        max_episodes: Max episodes to process.
        keep_threshold: Composite score above this → "keep".
        drop_threshold: Composite score below this → "drop".
        min_energy: Minimum action energy to not be considered idle.

    Returns:
        A :class:`SegmentResult` with per-segment scores.
    """
    from traceplane.lerobot_reader import LeRobotReader

    reader = LeRobotReader(path)
    result = SegmentResult(dataset_path=path, total_episodes=len(reader))

    indices = list(range(len(reader)))
    if max_episodes:
        indices = indices[:max_episodes]
    result.total_episodes = len(indices)

    # First pass: compute episode-level quality for salvage detection
    episode_composites: dict[int, float] = {}

    all_segments: list[SegmentScore] = []

    for idx in indices:
        ep = reader[idx]
        actions = ep.actions
        ep_index = ep.metadata.get("episode_index", idx)

        if actions.ndim < 2 or actions.shape[0] < window_size:
            continue

        ep_segments: list[SegmentScore] = []

        # Slide window across episode
        for start in range(0, actions.shape[0] - window_size + 1, stride):
            end = start + window_size
            segment = actions[start:end]

            smoothness = _segment_smoothness(segment)
            energy = _segment_energy(segment)

            composite = 0.6 * smoothness + 0.4 * min(energy / 0.5, 1.0)

            ep_segments.append(SegmentScore(
                episode_id=ep.episode_id,
                episode_index=ep_index,
                start_frame=start,
                end_frame=end,
                length=window_size,
                smoothness=smoothness,
                energy=energy,
                composite=composite,
                recommendation="",  # set below
            ))

        # Episode-level composite (mean of segment scores)
        if ep_segments:
            ep_composite = np.mean([s.composite for s in ep_segments])
            episode_composites[ep_index] = float(ep_composite)

            # Classify segments
            has_salvage = False
            for seg in ep_segments:
                if seg.energy < min_energy:
                    seg.recommendation = "drop"  # idle segment
                elif seg.composite >= keep_threshold:
                    if ep_composite >= keep_threshold:
                        seg.recommendation = "keep"
                    else:
                        seg.recommendation = "salvage"
                        has_salvage = True
                elif seg.composite <= drop_threshold:
                    seg.recommendation = "drop"
                else:
                    if ep_composite < drop_threshold:
                        seg.recommendation = "salvage" if seg.composite > drop_threshold else "drop"
                        if seg.recommendation == "salvage":
                            has_salvage = True
                    else:
                        seg.recommendation = "keep"

            if has_salvage:
                result.episodes_with_salvage += 1

            all_segments.extend(ep_segments)

    # Sort by composite score
    all_segments.sort(key=lambda s: s.composite, reverse=True)
    result.segments = all_segments
    result.total_segments = len(all_segments)
    result.keep_segments = sum(1 for s in all_segments if s.recommendation == "keep")
    result.salvage_segments = sum(1 for s in all_segments if s.recommendation == "salvage")
    result.drop_segments = sum(1 for s in all_segments if s.recommendation == "drop")

    return result


def _segment_smoothness(actions: np.ndarray) -> float:
    """Compute smoothness for an action segment."""
    if actions.shape[0] < 4:
        return 0.5

    velocity = np.diff(actions, axis=0)
    acceleration = np.diff(velocity, axis=0)
    jerk = np.diff(acceleration, axis=0)

    mean_jerk = np.mean(np.abs(jerk))
    mean_vel = np.mean(np.abs(velocity)) + 1e-8

    normalized_jerk = mean_jerk / mean_vel
    return float(np.clip(1.0 / (1.0 + normalized_jerk), 0, 1))


def _segment_energy(actions: np.ndarray) -> float:
    """Compute action energy (mean L2 norm of velocity)."""
    if actions.shape[0] < 2:
        return 0.0
    velocity = np.diff(actions, axis=0)
    norms = np.linalg.norm(velocity, axis=1)
    return float(np.mean(norms))


# ---------------------------------------------------------------------------
# HTML report
# ---------------------------------------------------------------------------

def _render_html(result: SegmentResult) -> str:
    total = max(result.total_segments, 1)

    stats = "".join([
        report.stat_card(str(result.total_episodes), "Episodes"),
        report.stat_card(str(result.total_segments), "Segments"),
        report.stat_card(str(result.keep_segments), "Keep"),
        report.stat_card(str(result.salvage_segments), "Salvage"),
        report.stat_card(str(result.drop_segments), "Drop"),
    ])

    # Segment table
    rows = ""
    for s in result.segments[:50]:
        rec_badge = {
            "keep": report.badge("KEEP", "pass"),
            "salvage": report.badge("SALVAGE", "warn"),
            "drop": report.badge("DROP", "fail"),
        }.get(s.recommendation, "")

        rows += f"""<tr>
  <td>{s.episode_id}</td>
  <td>{s.start_frame}-{s.end_frame}</td>
  <td>{report.score_pill(s.smoothness)}</td>
  <td>{report.score_pill(min(s.energy / 0.5, 1.0))}</td>
  <td>{report.score_pill(s.composite)}</td>
  <td>{rec_badge}</td>
</tr>"""

    table = f"""<table>
<thead><tr><th>Episode</th><th>Frames</th><th>Smooth</th><th>Energy</th><th>Score</th><th>Rec</th></tr></thead>
<tbody>{rows}</tbody></table>"""

    # Score distribution
    buckets = [0] * 10
    for s in result.segments:
        b = min(int(s.composite * 10), 9)
        buckets[b] += 1
    dist_items = [(f"{i/10:.1f}-{(i+1)/10:.1f}", buckets[i]) for i in range(10)]

    salvage_pct = result.salvage_segments / total * 100

    return f"""
<h1>Segment Curation Report</h1>
<p class="subtitle">{result.dataset_path}</p>

<div class="stats-row">{stats}</div>

<div class="recommendation">
  <strong>Salvage opportunity:</strong> {result.salvage_segments} segments ({salvage_pct:.1f}%)
  from {result.episodes_with_salvage} episode(s) contain good data that would be lost
  with episode-level filtering. Use <code>result.salvaged_spans()</code> to extract them.
</div>

<h2>Score Distribution</h2>
<div class="card">{report.distribution_chart(dist_items)}</div>

<h2>Segments</h2>
<div class="card" style="overflow-x:auto">{table}</div>
"""
