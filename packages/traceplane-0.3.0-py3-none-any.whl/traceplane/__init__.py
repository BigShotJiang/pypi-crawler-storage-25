"""Traceplane — streaming dataloader for robotics trajectory datasets.

Quick start::

    import traceplane

    # Connect to the platform (or set TRACEPLANE_API_URL / TRACEPLANE_API_KEY)
    tp = traceplane.connect("https://api.traceplane.ai", api_key="tp_...")

    # Register & query
    tp.register("my_dataset", "/path/to/dataset")
    rows = tp.sql_rows("SELECT * FROM my_dataset WHERE success = true")

    # Load locally
    ds = traceplane.load("hf://lerobot/bridge_v2")
    for episode in ds:
        print(episode.episode_id, episode.actions.shape)
"""

from __future__ import annotations

import os
from typing import Any

from traceplane.dataset import Episode, TrajectoryDataset
from traceplane.lerobot_reader import LeRobotReader
from traceplane.windowing import WindowedDataset
from traceplane.query import TraceplaneClient
from traceplane.check import check_dataset, CheckReport
from traceplane.fix import fix_dataset, FixResult
from traceplane.curate import curate_dataset, CurationResult
from traceplane.coverage import analyze_coverage, CoverageResult
from traceplane.evaluate import evaluate_rollouts, EvalResult
from traceplane.publish import publish_dataset, PublishResult
from traceplane.split import build_split, SplitResult
from traceplane.segment import segment_curate, SegmentResult
from traceplane.mix import compile_mix, load_recipe, MixRecipe, MixSource, MixResult

__version__ = "0.2.0"

__all__ = [
    "Episode",
    "TrajectoryDataset",
    "LeRobotReader",
    "WindowedDataset",
    "TraceplaneClient",
    "connect",
    "load",
    "check_dataset",
    "CheckReport",
    "fix_dataset",
    "FixResult",
    "curate_dataset",
    "CurationResult",
    "analyze_coverage",
    "CoverageResult",
    "evaluate_rollouts",
    "EvalResult",
    "publish_dataset",
    "PublishResult",
    "build_split",
    "SplitResult",
    "segment_curate",
    "SegmentResult",
    "compile_mix",
    "load_recipe",
    "MixRecipe",
    "MixSource",
    "MixResult",
]


def connect(
    url: str | None = None,
    api_key: str | None = None,
    timeout: int = 30,
) -> TraceplaneClient:
    """Create a client connected to the Traceplane API.

    Args:
        url: API base URL. Falls back to ``TRACEPLANE_API_URL`` env var,
            then ``https://api.traceplane.ai``.
        api_key: API key. Falls back to ``TRACEPLANE_API_KEY`` env var.
        timeout: Request timeout in seconds.

    Returns:
        A configured :class:`TraceplaneClient`.

    Example::

        import traceplane
        tp = traceplane.connect()
        tp.sql_rows("SELECT COUNT(*) FROM my_dataset")
    """
    resolved_url = url or os.environ.get(
        "TRACEPLANE_API_URL", "https://api.traceplane.ai"
    )
    resolved_key = api_key or os.environ.get("TRACEPLANE_API_KEY")
    return TraceplaneClient(
        base_url=resolved_url,
        timeout=timeout,
        api_key=resolved_key,
    )


def load(
    path: str,
    episode_indices: list[int] | None = None,
    storage_options: dict[str, Any] | None = None,
) -> LeRobotReader:
    """Load a LeRobot dataset from a local or remote path.

    Args:
        path: Path to dataset root — local path, ``s3://``, ``gs://``,
            or ``hf://user/dataset``.
        episode_indices: Load only these episodes (default: all).
        storage_options: fsspec options for remote paths.

    Returns:
        A :class:`LeRobotReader` ready for iteration.

    Example::

        import traceplane
        ds = traceplane.load("/data/g1-grasp")
        print(len(ds))  # number of episodes
    """
    return LeRobotReader(
        path,
        episode_indices=episode_indices,
        storage_options=storage_options,
    )
