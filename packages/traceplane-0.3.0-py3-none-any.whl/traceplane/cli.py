"""Traceplane CLI — command-line interface for the platform.

Usage::

    traceplane check /path/to/dataset
    traceplane fix /path/to/dataset --regenerate-stats --fix-metadata
    traceplane curate /path/to/dataset --html report.html
    traceplane coverage /path/to/dataset1 /path/to/dataset2 --html report.html
    traceplane eval --training /data/train --rollouts /data/rollouts --html report.html
    traceplane info /path/to/dataset
    traceplane register my_dataset /path/to/dataset
    traceplane sql "SELECT COUNT(*) FROM my_dataset"
    traceplane upload my_dataset /path/to/parquet/dir
    traceplane embodiments
"""

from __future__ import annotations

import argparse
import json
import sys

import traceplane


def _client() -> traceplane.TraceplaneClient:
    return traceplane.connect()


def cmd_check(args: argparse.Namespace) -> None:
    """Run QA checks on a local dataset."""
    from traceplane.check import check_dataset

    report = check_dataset(
        args.path,
        max_episodes=args.max_episodes,
        check_data=not args.metadata_only,
    )
    report.print()

    if args.json:
        report.to_json(args.json)
        print(f"  Report saved to {args.json}")

    if not report.passed:
        sys.exit(1)


def cmd_fix(args: argparse.Namespace) -> None:
    """Auto-fix common dataset issues."""
    from traceplane.fix import fix_dataset

    do_all = args.all
    result = fix_dataset(
        args.path,
        delete_bad=do_all or args.delete_bad,
        regenerate_stats=do_all or args.regenerate_stats,
        fix_metadata=do_all or args.fix_metadata,
        reindex=do_all or args.reindex,
        dry_run=args.dry_run,
    )
    result.print()

    if args.dry_run and result.changes_made:
        print("  (dry run — no changes written. Remove --dry-run to apply.)")


def cmd_curate(args: argparse.Namespace) -> None:
    """Score episodes and produce keep/review/drop recommendations."""
    from traceplane.curate import curate_dataset

    result = curate_dataset(
        args.path,
        max_episodes=args.max_episodes,
        keep_threshold=args.keep_threshold,
        drop_threshold=args.drop_threshold,
    )
    result.print()

    if args.html:
        result.to_html(args.html)
        print(f"  HTML report saved to {args.html}")

    if args.json:
        from pathlib import Path
        Path(args.json).write_text(json.dumps(result.to_dict(), indent=2))
        print(f"  JSON report saved to {args.json}")


def cmd_coverage(args: argparse.Namespace) -> None:
    """Analyze coverage across one or more datasets."""
    from traceplane.coverage import analyze_coverage

    result = analyze_coverage(
        args.paths,
        max_episodes_per_dataset=args.max_episodes,
    )
    result.print()

    if args.html:
        result.to_html(args.html)
        print(f"  HTML report saved to {args.html}")

    if args.json:
        from pathlib import Path
        Path(args.json).write_text(json.dumps(result.to_dict(), indent=2))
        print(f"  JSON report saved to {args.json}")


def cmd_eval(args: argparse.Namespace) -> None:
    """Compare rollout data against training data."""
    from traceplane.evaluate import evaluate_rollouts

    result = evaluate_rollouts(
        training_path=args.training,
        rollout_path=args.rollouts,
        max_episodes=args.max_episodes,
    )
    result.print()

    if args.html:
        result.to_html(args.html)
        print(f"  HTML report saved to {args.html}")

    if args.json:
        from pathlib import Path
        Path(args.json).write_text(json.dumps(result.to_dict(), indent=2))
        print(f"  JSON report saved to {args.json}")


def cmd_publish(args: argparse.Namespace) -> None:
    """Export dataset with QA card and optionally push to HuggingFace."""
    from traceplane.publish import publish_dataset

    result = publish_dataset(
        args.path,
        output_path=args.output,
        repo_id=args.repo_id,
        push=args.push,
        run_qa=not args.skip_qa,
        description=args.description,
        license=args.license,
        private=args.private,
    )
    result.print()


def cmd_split(args: argparse.Namespace) -> None:
    """Build generalization-aware train/eval splits."""
    from traceplane.split import build_split

    result = build_split(
        args.path,
        holdout_by=args.holdout_by,
        test_fraction=args.test_fraction,
        max_episodes=args.max_episodes,
        seed=args.seed,
    )
    result.print()

    if args.html:
        result.to_html(args.html)
        print(f"  HTML report saved to {args.html}")

    if args.save:
        result.save_indices(args.save)
        print(f"  Split indices saved to {args.save}")


def cmd_segment(args: argparse.Namespace) -> None:
    """Segment-level curation: score and salvage sub-episode segments."""
    from traceplane.segment import segment_curate

    result = segment_curate(
        args.path,
        window_size=args.window_size,
        stride=args.stride,
        max_episodes=args.max_episodes,
    )
    result.print()

    if args.html:
        result.to_html(args.html)
        print(f"  HTML report saved to {args.html}")


def cmd_mix(args: argparse.Namespace) -> None:
    """Compile a dataset mix from a recipe file."""
    from traceplane.mix import load_recipe, compile_mix

    recipe = load_recipe(args.recipe)
    result = compile_mix(recipe)
    result.print()

    if args.html:
        result.to_html(args.html)
        print(f"  HTML report saved to {args.html}")

    if args.save:
        result.save_recipe(args.save)
        print(f"  Recipe + indices saved to {args.save}")


def cmd_info(args: argparse.Namespace) -> None:
    """Show dataset info (local, no API required)."""
    ds = traceplane.load(args.path)
    print(f"Dataset:  {args.path}")
    print(f"Episodes: {len(ds)}")
    if len(ds) > 0:
        ep = ds[0]
        print(f"Actions:  shape={ep.actions.shape}")
        if ep.states is not None:
            print(f"States:   shape={ep.states.shape}")
        print(f"FPS:      {ep.fps}")


def cmd_register(args: argparse.Namespace) -> None:
    """Register a dataset in the SQL engine."""
    client = _client()
    result = client.register(
        args.name,
        args.path,
        include_data=not args.metadata_only,
    )
    print(json.dumps(result, indent=2))


def cmd_sql(args: argparse.Namespace) -> None:
    """Run a SQL query."""
    client = _client()
    rows = client.sql_rows(args.query)
    print(json.dumps(rows, indent=2))


def cmd_tables(args: argparse.Namespace) -> None:
    """List registered tables."""
    client = _client()
    for table in client.tables():
        print(table)


def cmd_upload(args: argparse.Namespace) -> None:
    """Upload a dataset to the platform."""
    client = _client()
    result = client.upload_dataset(args.name, args.path)
    print(f"Uploaded {result['files_uploaded']} file(s)")


def cmd_embodiments(args: argparse.Namespace) -> None:
    """List available embodiment presets."""
    client = _client()
    presets = client.list_embodiments()
    for p in presets:
        print(f"  {p['id']:20s}  {p.get('display_name', '')}  ({p.get('action_dim', '?')} DoF)")


def cmd_health(args: argparse.Namespace) -> None:
    """Check API health."""
    client = _client()
    result = client.health()
    print(json.dumps(result, indent=2))


def cmd_profile(args: argparse.Namespace) -> None:
    """Show profile statistics for a registered table."""
    client = _client()
    result = client.profile(args.table)
    print(json.dumps(result, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="traceplane",
        description="Traceplane — data infrastructure for robotics trajectories",
    )
    sub = parser.add_subparsers(dest="command")

    # check
    p = sub.add_parser("check", help="Run QA checks on a local dataset")
    p.add_argument("path", help="Path to dataset root")
    p.add_argument("--max-episodes", type=int, default=None,
                   help="Max episodes to sample for data checks")
    p.add_argument("--metadata-only", action="store_true",
                   help="Only check metadata, skip data file reads")
    p.add_argument("--json", metavar="FILE",
                   help="Save report as JSON to this file")

    # fix
    p = sub.add_parser("fix", help="Auto-fix common dataset issues")
    p.add_argument("path", help="Path to dataset root")
    p.add_argument("--all", action="store_true",
                   help="Run all fixes")
    p.add_argument("--delete-bad", action="store_true",
                   help="Delete zero-byte Parquet/video files")
    p.add_argument("--regenerate-stats", action="store_true",
                   help="Recompute stats from actual data")
    p.add_argument("--fix-metadata", action="store_true",
                   help="Fix info.json (episode count, action dim)")
    p.add_argument("--reindex", action="store_true",
                   help="Reindex episode manifest from data files")
    p.add_argument("--dry-run", action="store_true",
                   help="Show what would change without writing")

    # curate
    p = sub.add_parser("curate", help="Score episodes and recommend keep/review/drop")
    p.add_argument("path", help="Path to dataset root")
    p.add_argument("--max-episodes", type=int, default=None,
                   help="Max episodes to score")
    p.add_argument("--keep-threshold", type=float, default=0.6,
                   help="Score above this = keep (default: 0.6)")
    p.add_argument("--drop-threshold", type=float, default=0.3,
                   help="Score below this = drop (default: 0.3)")
    p.add_argument("--html", metavar="FILE",
                   help="Save HTML report to this file")
    p.add_argument("--json", metavar="FILE",
                   help="Save JSON report to this file")

    # coverage
    p = sub.add_parser("coverage", help="Analyze coverage gaps across datasets")
    p.add_argument("paths", nargs="+", help="Paths to one or more dataset roots")
    p.add_argument("--max-episodes", type=int, default=None,
                   help="Max episodes per dataset")
    p.add_argument("--html", metavar="FILE",
                   help="Save HTML report to this file")
    p.add_argument("--json", metavar="FILE",
                   help="Save JSON report to this file")

    # eval
    p = sub.add_parser("eval", help="Compare rollout data against training data")
    p.add_argument("--training", required=True,
                   help="Path to training dataset")
    p.add_argument("--rollouts", required=True,
                   help="Path to rollout/evaluation dataset")
    p.add_argument("--max-episodes", type=int, default=None,
                   help="Max episodes per dataset")
    p.add_argument("--html", metavar="FILE",
                   help="Save HTML report to this file")
    p.add_argument("--json", metavar="FILE",
                   help="Save JSON report to this file")

    # publish
    p = sub.add_parser("publish", help="Export dataset with QA card, push to HuggingFace")
    p.add_argument("path", help="Path to dataset root")
    p.add_argument("--output", metavar="DIR",
                   help="Export directory (default: {path}/_export)")
    p.add_argument("--repo-id", metavar="ORG/NAME",
                   help="HuggingFace repo ID for upload")
    p.add_argument("--push", action="store_true",
                   help="Upload to HuggingFace Hub")
    p.add_argument("--skip-qa", action="store_true",
                   help="Skip QA check before publishing")
    p.add_argument("--description", help="Dataset description")
    p.add_argument("--license", default="apache-2.0",
                   help="License (default: apache-2.0)")
    p.add_argument("--private", action="store_true",
                   help="Make Hub repo private")

    # split
    p = sub.add_parser("split", help="Build generalization-aware train/eval splits")
    p.add_argument("path", help="Path to dataset root")
    p.add_argument("--holdout-by", default="task",
                   help="Dimension to hold out: task, episode, random (default: task)")
    p.add_argument("--test-fraction", type=float, default=0.2,
                   help="Fraction for test set (default: 0.2)")
    p.add_argument("--max-episodes", type=int, default=None)
    p.add_argument("--seed", type=int, default=42,
                   help="Random seed (default: 42)")
    p.add_argument("--html", metavar="FILE",
                   help="Save HTML report")
    p.add_argument("--save", metavar="FILE",
                   help="Save split indices to JSON")

    # segment
    p = sub.add_parser("segment", help="Segment-level curation and salvage")
    p.add_argument("path", help="Path to dataset root")
    p.add_argument("--window-size", type=int, default=50,
                   help="Segment length in frames (default: 50)")
    p.add_argument("--stride", type=int, default=25,
                   help="Step between segments (default: 25)")
    p.add_argument("--max-episodes", type=int, default=None)
    p.add_argument("--html", metavar="FILE",
                   help="Save HTML report")

    # mix
    p = sub.add_parser("mix", help="Compile dataset mix from recipe")
    p.add_argument("recipe", help="Path to recipe JSON file")
    p.add_argument("--html", metavar="FILE",
                   help="Save HTML report")
    p.add_argument("--save", metavar="FILE",
                   help="Save compiled recipe + indices")

    # info
    p = sub.add_parser("info", help="Show local dataset info")
    p.add_argument("path", help="Path to dataset")

    # register
    p = sub.add_parser("register", help="Register dataset in SQL engine")
    p.add_argument("name", help="Table name")
    p.add_argument("path", help="Dataset path on server")
    p.add_argument("--metadata-only", action="store_true")

    # sql
    p = sub.add_parser("sql", help="Run SQL query")
    p.add_argument("query", help="SQL query string")

    # tables
    sub.add_parser("tables", help="List registered tables")

    # upload
    p = sub.add_parser("upload", help="Upload dataset to platform")
    p.add_argument("name", help="Dataset name")
    p.add_argument("path", help="Local path to Parquet directory")

    # embodiments
    sub.add_parser("embodiments", help="List robot embodiment presets")

    # health
    sub.add_parser("health", help="Check API health")

    # profile
    p = sub.add_parser("profile", help="Profile a registered table")
    p.add_argument("table", help="Table name")

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(1)

    commands = {
        "check": cmd_check,
        "fix": cmd_fix,
        "curate": cmd_curate,
        "coverage": cmd_coverage,
        "eval": cmd_eval,
        "publish": cmd_publish,
        "split": cmd_split,
        "segment": cmd_segment,
        "mix": cmd_mix,
        "info": cmd_info,
        "register": cmd_register,
        "sql": cmd_sql,
        "tables": cmd_tables,
        "upload": cmd_upload,
        "embodiments": cmd_embodiments,
        "health": cmd_health,
        "profile": cmd_profile,
    }
    commands[args.command](args)


if __name__ == "__main__":
    main()
