"""traceplane eval — evaluation studio for comparing training and rollout data.

Stores rollout episodes alongside training data, compares distributions,
tracks success rates, and builds failure taxonomies.

Usage::

    from traceplane.evaluate import evaluate_rollouts
    result = evaluate_rollouts(
        training_path="/data/training_set",
        rollout_path="/data/rollouts",
    )
    result.print()
    result.to_html("eval_report.html")
"""

from __future__ import annotations

import json
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np

from traceplane import report


@dataclass
class DistributionShift:
    dimension: str
    training_mean: float
    rollout_mean: float
    shift_magnitude: float  # abs difference in std units
    assessment: str  # "ok", "warning", "critical"


@dataclass
class FailureCategory:
    label: str
    count: int
    fraction: float
    example_episodes: list[str]


@dataclass
class EvalResult:
    training_path: str
    rollout_path: str

    # Summary stats
    training_episodes: int = 0
    rollout_episodes: int = 0
    training_frames: int = 0
    rollout_frames: int = 0

    # Success metrics
    rollout_success_rate: float = 0.0
    rollout_successes: int = 0
    rollout_failures: int = 0
    rollout_unknown: int = 0

    # Distribution comparison
    shifts: list[DistributionShift] = field(default_factory=list)
    max_shift: float = 0.0

    # Failure analysis
    failure_categories: list[FailureCategory] = field(default_factory=list)

    # Action distribution comparison
    training_action_stats: dict[str, Any] = field(default_factory=dict)
    rollout_action_stats: dict[str, Any] = field(default_factory=dict)

    # Length comparison
    training_length_stats: dict[str, float] = field(default_factory=dict)
    rollout_length_stats: dict[str, float] = field(default_factory=dict)

    def print(self) -> None:
        print(f"\n{'='*60}")
        print(f"  traceplane eval")
        print(f"{'='*60}")
        print(f"  Training:  {self.training_episodes} episodes, {self.training_frames:,} frames")
        print(f"  Rollouts:  {self.rollout_episodes} episodes, {self.rollout_frames:,} frames")
        print()
        print(f"  Success rate:  {self.rollout_success_rate*100:.1f}%")
        print(f"    Successes:   {self.rollout_successes}")
        print(f"    Failures:    {self.rollout_failures}")
        print(f"    Unknown:     {self.rollout_unknown}")
        print()

        if self.shifts:
            critical = [s for s in self.shifts if s.assessment == "critical"]
            warning = [s for s in self.shifts if s.assessment == "warning"]
            print(f"  Distribution shift: {len(critical)} critical, {len(warning)} warning")
            for s in self.shifts[:10]:
                icon = {"critical": "X", "warning": "!", "ok": " "}.get(s.assessment, " ")
                print(f"    [{icon}] {s.dimension}: train={s.training_mean:.3f} → rollout={s.rollout_mean:.3f} (shift={s.shift_magnitude:.2f}σ)")
            print()

        if self.failure_categories:
            print(f"  Failure categories:")
            for fc in self.failure_categories:
                print(f"    {fc.label:<30} {fc.count:>4} ({fc.fraction*100:.1f}%)")
            print()

        print(f"{'='*60}\n")

    def to_html(self, path: str) -> None:
        body = _render_html(self)
        html = report.html_document("Evaluation Report", body)
        Path(path).write_text(html)

    def to_dict(self) -> dict[str, Any]:
        return {
            "training_path": self.training_path,
            "rollout_path": self.rollout_path,
            "training_episodes": self.training_episodes,
            "rollout_episodes": self.rollout_episodes,
            "rollout_success_rate": round(self.rollout_success_rate, 4),
            "shifts": [
                {"dimension": s.dimension, "shift": round(s.shift_magnitude, 4), "assessment": s.assessment}
                for s in self.shifts
            ],
            "failure_categories": [
                {"label": fc.label, "count": fc.count, "fraction": round(fc.fraction, 4)}
                for fc in self.failure_categories
            ],
        }


def evaluate_rollouts(
    training_path: str,
    rollout_path: str,
    max_episodes: int | None = None,
    shift_warning_threshold: float = 1.0,
    shift_critical_threshold: float = 2.0,
) -> EvalResult:
    """Compare rollout data against training data.

    Args:
        training_path: Path to training dataset.
        rollout_path: Path to rollout/evaluation dataset.
        max_episodes: Max episodes to load per dataset.
        shift_warning_threshold: Std devs of shift to flag as warning.
        shift_critical_threshold: Std devs of shift to flag as critical.

    Returns:
        An :class:`EvalResult` with comparison metrics.
    """
    from traceplane.lerobot_reader import LeRobotReader

    result = EvalResult(training_path=training_path, rollout_path=rollout_path)

    # Load training data
    train_reader = LeRobotReader(training_path)
    rollout_reader = LeRobotReader(rollout_path)

    train_indices = list(range(len(train_reader)))
    rollout_indices = list(range(len(rollout_reader)))
    if max_episodes:
        train_indices = train_indices[:max_episodes]
        rollout_indices = rollout_indices[:max_episodes]

    # Collect episode data
    train_actions, train_lengths = [], []
    for idx in train_indices:
        ep = train_reader[idx]
        result.training_episodes += 1
        result.training_frames += ep.length
        train_lengths.append(ep.length)
        if ep.actions.ndim == 2 and ep.actions.shape[0] > 0:
            train_actions.append(ep.actions)

    rollout_actions, rollout_lengths = [], []
    rollout_tasks: Counter[str] = Counter()
    failure_reasons: Counter[str] = Counter()
    success_count, fail_count, unknown_count = 0, 0, 0

    for idx in rollout_indices:
        ep = rollout_reader[idx]
        result.rollout_episodes += 1
        result.rollout_frames += ep.length
        rollout_lengths.append(ep.length)
        task = ep.metadata.get("task_label", "unknown")
        rollout_tasks[task] += 1

        if ep.actions.ndim == 2 and ep.actions.shape[0] > 0:
            rollout_actions.append(ep.actions)

        # Success tracking (from metadata if available)
        success = ep.metadata.get("success")
        if success is True:
            success_count += 1
        elif success is False:
            fail_count += 1
            reason = ep.metadata.get("failure_reason", "unknown")
            failure_reasons[reason] += 1
        else:
            unknown_count += 1

    result.rollout_successes = success_count
    result.rollout_failures = fail_count
    result.rollout_unknown = unknown_count
    total_known = success_count + fail_count
    result.rollout_success_rate = success_count / total_known if total_known > 0 else 0.0

    # Length stats
    if train_lengths:
        arr = np.array(train_lengths, dtype=float)
        result.training_length_stats = {
            "mean": float(np.mean(arr)),
            "std": float(np.std(arr)),
            "min": float(np.min(arr)),
            "max": float(np.max(arr)),
        }
    if rollout_lengths:
        arr = np.array(rollout_lengths, dtype=float)
        result.rollout_length_stats = {
            "mean": float(np.mean(arr)),
            "std": float(np.std(arr)),
            "min": float(np.min(arr)),
            "max": float(np.max(arr)),
        }

    # Distribution shift analysis
    if train_actions and rollout_actions:
        result.shifts = _compute_distribution_shift(
            train_actions, rollout_actions,
            shift_warning_threshold, shift_critical_threshold,
        )
        if result.shifts:
            result.max_shift = max(s.shift_magnitude for s in result.shifts)

        # Action stats
        all_train = np.concatenate(train_actions, axis=0)
        all_rollout = np.concatenate(rollout_actions, axis=0)
        result.training_action_stats = {
            "mean": np.mean(all_train, axis=0).tolist(),
            "std": np.std(all_train, axis=0).tolist(),
        }
        result.rollout_action_stats = {
            "mean": np.mean(all_rollout, axis=0).tolist(),
            "std": np.std(all_rollout, axis=0).tolist(),
        }

    # Failure categories
    if failure_reasons:
        total_failures = sum(failure_reasons.values())
        result.failure_categories = [
            FailureCategory(
                label=reason,
                count=count,
                fraction=count / total_failures,
                example_episodes=[],  # Would need episode IDs
            )
            for reason, count in failure_reasons.most_common()
        ]

    return result


def _compute_distribution_shift(
    train_actions: list[np.ndarray],
    rollout_actions: list[np.ndarray],
    warn_thresh: float,
    crit_thresh: float,
) -> list[DistributionShift]:
    """Compare per-dimension distributions between training and rollout."""
    all_train = np.concatenate(train_actions, axis=0)
    all_rollout = np.concatenate(rollout_actions, axis=0)

    # Ensure same dimensionality
    dim = min(all_train.shape[1], all_rollout.shape[1])

    shifts = []
    for d in range(dim):
        t_mean = float(np.mean(all_train[:, d]))
        t_std = float(np.std(all_train[:, d])) + 1e-8
        r_mean = float(np.mean(all_rollout[:, d]))

        shift_mag = abs(r_mean - t_mean) / t_std

        if shift_mag >= crit_thresh:
            assessment = "critical"
        elif shift_mag >= warn_thresh:
            assessment = "warning"
        else:
            assessment = "ok"

        shifts.append(DistributionShift(
            dimension=f"action[{d}]",
            training_mean=t_mean,
            rollout_mean=r_mean,
            shift_magnitude=shift_mag,
            assessment=assessment,
        ))

    # Sort by shift magnitude (worst first)
    shifts.sort(key=lambda s: s.shift_magnitude, reverse=True)
    return shifts


# ---------------------------------------------------------------------------
# HTML report
# ---------------------------------------------------------------------------

def _render_html(result: EvalResult) -> str:
    # Success rate color
    sr = result.rollout_success_rate
    sr_color = "var(--green)" if sr >= 0.8 else ("var(--yellow)" if sr >= 0.5 else "var(--red)")

    stats = "".join([
        report.stat_card(str(result.training_episodes), "Training episodes"),
        report.stat_card(str(result.rollout_episodes), "Rollout episodes"),
        report.stat_card(f"{sr*100:.1f}%", "Success rate"),
        report.stat_card(f"{result.max_shift:.2f}σ", "Max shift"),
    ])

    # Success breakdown
    total_known = result.rollout_successes + result.rollout_failures
    success_items = [
        ("Success", result.rollout_successes),
        ("Failure", result.rollout_failures),
    ]
    if result.rollout_unknown > 0:
        success_items.append(("Unknown", result.rollout_unknown))

    # Distribution shifts table
    shift_rows = ""
    for s in result.shifts:
        badge_var = {"critical": "fail", "warning": "warn", "ok": "pass"}.get(s.assessment, "info")
        shift_rows += f"""<tr>
  <td>{s.dimension}</td>
  <td style="text-align:right">{s.training_mean:.4f}</td>
  <td style="text-align:right">{s.rollout_mean:.4f}</td>
  <td style="text-align:right">{s.shift_magnitude:.2f}σ</td>
  <td>{report.badge(s.assessment.upper(), badge_var)}</td>
</tr>"""

    shift_table = f"""<table>
<thead><tr><th>Dimension</th><th style="text-align:right">Training μ</th><th style="text-align:right">Rollout μ</th><th style="text-align:right">Shift</th><th>Status</th></tr></thead>
<tbody>{shift_rows}</tbody></table>""" if result.shifts else "<p>No action data to compare.</p>"

    # Failure categories
    failure_html = ""
    if result.failure_categories:
        fc_items = [(fc.label, fc.count) for fc in result.failure_categories]
        failure_html = f"""<h2>Failure Taxonomy</h2>
<div class="card">{report.distribution_chart(fc_items)}</div>"""

    # Length comparison
    length_html = ""
    if result.training_length_stats and result.rollout_length_stats:
        t = result.training_length_stats
        r = result.rollout_length_stats
        length_html = f"""<h2>Episode Length Comparison</h2>
<div class="card">
<table>
<thead><tr><th></th><th style="text-align:right">Training</th><th style="text-align:right">Rollout</th></tr></thead>
<tbody>
<tr><td>Mean</td><td style="text-align:right">{t['mean']:.0f}</td><td style="text-align:right">{r['mean']:.0f}</td></tr>
<tr><td>Std</td><td style="text-align:right">{t['std']:.0f}</td><td style="text-align:right">{r['std']:.0f}</td></tr>
<tr><td>Min</td><td style="text-align:right">{t['min']:.0f}</td><td style="text-align:right">{r['min']:.0f}</td></tr>
<tr><td>Max</td><td style="text-align:right">{t['max']:.0f}</td><td style="text-align:right">{r['max']:.0f}</td></tr>
</tbody></table></div>"""

    # Overall assessment
    critical_shifts = sum(1 for s in result.shifts if s.assessment == "critical")
    if sr >= 0.8 and critical_shifts == 0:
        assessment = report.badge("HEALTHY", "pass") + " Policy is performing well. No major distribution shifts detected."
    elif sr >= 0.5 or critical_shifts <= 2:
        assessment = report.badge("ATTENTION", "warn") + f" Success rate is {sr*100:.0f}%. {critical_shifts} action dimension(s) show significant distribution shift."
    else:
        assessment = report.badge("CRITICAL", "fail") + f" Success rate is {sr*100:.0f}% with {critical_shifts} critical distribution shifts. Review training data quality and coverage."

    return f"""
<h1>Evaluation Report</h1>
<p class="subtitle">Training: {result.training_path}<br>Rollouts: {result.rollout_path}</p>

<div class="stats-row">{stats}</div>

<div class="recommendation">{assessment}</div>

<h2>Success Breakdown</h2>
<div class="card">
  {report.distribution_chart(success_items)}
</div>

<h2>Distribution Shift Analysis</h2>
<div class="card" style="overflow-x:auto">
  {shift_table}
</div>

{failure_html}

{length_html}
"""
