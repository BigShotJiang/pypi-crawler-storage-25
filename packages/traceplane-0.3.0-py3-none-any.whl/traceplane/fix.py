"""traceplane fix — auto-repair common dataset issues.

Operates on local LeRobot v2/v3 datasets. All modifications are logged
and a before/after diff is printed.

Usage::

    from traceplane.fix import fix_dataset
    result = fix_dataset("/path/to/dataset", regenerate_stats=True)
    result.print()
"""

from __future__ import annotations

import json
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
import pyarrow.parquet as pq


@dataclass
class FixAction:
    code: str
    description: str


@dataclass
class FixResult:
    dataset_path: str
    actions: list[FixAction] = field(default_factory=list)
    episodes_deleted: int = 0
    stats_regenerated: bool = False
    metadata_patched: bool = False

    @property
    def changes_made(self) -> bool:
        return len(self.actions) > 0

    def print(self) -> None:
        print(f"\n{'='*60}")
        print(f"  traceplane fix — {self.dataset_path}")
        print(f"{'='*60}")

        if not self.actions:
            print("  No changes needed.")
        else:
            print(f"  {len(self.actions)} fix(es) applied:\n")
            for action in self.actions:
                print(f"  [*] {action.code}")
                print(f"      {action.description}")
                print()

        if self.episodes_deleted > 0:
            print(f"  Episodes deleted: {self.episodes_deleted}")
        if self.stats_regenerated:
            print(f"  Stats regenerated: yes")
        if self.metadata_patched:
            print(f"  Metadata patched: yes")

        print(f"{'='*60}\n")

    def to_dict(self) -> dict[str, Any]:
        return {
            "dataset_path": self.dataset_path,
            "changes_made": self.changes_made,
            "actions": [{"code": a.code, "description": a.description} for a in self.actions],
            "episodes_deleted": self.episodes_deleted,
            "stats_regenerated": self.stats_regenerated,
            "metadata_patched": self.metadata_patched,
        }


def fix_dataset(
    path: str,
    delete_bad: bool = False,
    regenerate_stats: bool = False,
    fix_metadata: bool = False,
    reindex: bool = False,
    dry_run: bool = False,
) -> FixResult:
    """Auto-fix common dataset issues.

    Args:
        path: Path to dataset root.
        delete_bad: Remove zero-byte Parquet files and their episodes.
        regenerate_stats: Recompute stats.json from actual data.
        fix_metadata: Fix info.json (episode count, action_dim) from data.
        reindex: Reindex episode manifest after deletions.
        dry_run: Report what would change without writing.

    Returns:
        A :class:`FixResult` describing all changes made.
    """
    root = Path(path)
    result = FixResult(dataset_path=str(root))

    info_path = root / "meta" / "info.json"
    if not info_path.exists():
        return result

    info = json.loads(info_path.read_text())
    is_v3 = info.get("codebase_version", "").startswith("v3") or (root / "meta" / "episodes").is_dir()

    if delete_bad:
        _fix_delete_bad(root, info, is_v3, result, dry_run)

    if fix_metadata:
        _fix_metadata(root, info, is_v3, result, dry_run)

    if reindex:
        _fix_reindex(root, info, is_v3, result, dry_run)

    if regenerate_stats:
        _fix_regenerate_stats(root, info, is_v3, result, dry_run)

    return result


# ---------------------------------------------------------------------------
# Delete bad episodes
# ---------------------------------------------------------------------------

def _fix_delete_bad(
    root: Path,
    info: dict[str, Any],
    is_v3: bool,
    result: FixResult,
    dry_run: bool,
) -> None:
    data_dir = root / "data"
    if not data_dir.exists():
        return

    parquet_files = list(data_dir.rglob("*.parquet"))
    zero_byte = [f for f in parquet_files if f.stat().st_size == 0]

    if not zero_byte:
        return

    for zf in zero_byte:
        result.actions.append(FixAction(
            "DELETE_ZERO_BYTE",
            f"{'Would delete' if dry_run else 'Deleted'} zero-byte file: {zf.relative_to(root)}",
        ))
        if not dry_run:
            zf.unlink()
            result.episodes_deleted += 1

    # Also check for zero-byte videos
    videos_dir = root / "videos"
    if videos_dir.exists():
        video_files = list(videos_dir.rglob("*.mp4"))
        zero_vids = [f for f in video_files if f.stat().st_size == 0]
        for zv in zero_vids:
            result.actions.append(FixAction(
                "DELETE_ZERO_VIDEO",
                f"{'Would delete' if dry_run else 'Deleted'} zero-byte video: {zv.relative_to(root)}",
            ))
            if not dry_run:
                zv.unlink()


# ---------------------------------------------------------------------------
# Fix metadata
# ---------------------------------------------------------------------------

def _fix_metadata(
    root: Path,
    info: dict[str, Any],
    is_v3: bool,
    result: FixResult,
    dry_run: bool,
) -> None:
    info_path = root / "meta" / "info.json"
    changed = False

    # Count actual episodes
    actual_count = _count_actual_episodes(root, is_v3)
    declared_count = info.get("total_episodes", 0)

    if actual_count > 0 and actual_count != declared_count:
        result.actions.append(FixAction(
            "FIX_EPISODE_COUNT",
            f"total_episodes: {declared_count} -> {actual_count}",
        ))
        info["total_episodes"] = actual_count
        changed = True

    # Detect actual action dim from data
    data_dir = root / "data"
    if data_dir.exists():
        actual_dim = _detect_action_dim(data_dir, is_v3)
        if actual_dim is not None:
            features = info.get("features", {})
            action_spec = features.get("action", {})
            declared_shape = action_spec.get("shape")

            if declared_shape:
                declared_dim = declared_shape[-1] if isinstance(declared_shape, list) else declared_shape
                if declared_dim != actual_dim:
                    result.actions.append(FixAction(
                        "FIX_ACTION_DIM",
                        f"action shape: {declared_shape} -> [{actual_dim}]",
                    ))
                    if "features" not in info:
                        info["features"] = {}
                    if "action" not in info["features"]:
                        info["features"]["action"] = {}
                    info["features"]["action"]["shape"] = [actual_dim]
                    changed = True

    if changed and not dry_run:
        # Backup original
        backup = info_path.with_suffix(".json.bak")
        if not backup.exists():
            shutil.copy2(info_path, backup)
        info_path.write_text(json.dumps(info, indent=2) + "\n")
        result.metadata_patched = True


# ---------------------------------------------------------------------------
# Reindex episodes
# ---------------------------------------------------------------------------

def _fix_reindex(
    root: Path,
    info: dict[str, Any],
    is_v3: bool,
    result: FixResult,
    dry_run: bool,
) -> None:
    if is_v3:
        # v3 reindexing is more complex (Parquet manifests). Skip for now.
        return

    episodes_path = root / "meta" / "episodes.jsonl"
    data_dir = root / "data"
    if not episodes_path.exists() or not data_dir.exists():
        return

    # Find all actual episode parquet files
    parquet_files = sorted(data_dir.rglob("episode_*.parquet"))
    actual_indices: set[int] = set()
    for pf in parquet_files:
        if pf.stat().st_size == 0:
            continue
        try:
            idx = int(pf.stem.split("_")[-1])
            actual_indices.add(idx)
        except ValueError:
            continue

    # Read current manifest
    current_episodes = []
    for line in episodes_path.read_text().splitlines():
        if not line.strip():
            continue
        try:
            current_episodes.append(json.loads(line))
        except json.JSONDecodeError:
            continue

    current_indices = {ep.get("episode_index", -1) for ep in current_episodes}

    # Check for mismatches
    in_manifest_not_data = current_indices - actual_indices
    in_data_not_manifest = actual_indices - current_indices

    if not in_manifest_not_data and not in_data_not_manifest:
        return

    if in_manifest_not_data:
        result.actions.append(FixAction(
            "REINDEX_REMOVE_ORPHANS",
            f"{'Would remove' if dry_run else 'Removed'} {len(in_manifest_not_data)} "
            f"manifest entries with no data file",
        ))

    if in_data_not_manifest:
        result.actions.append(FixAction(
            "REINDEX_ADD_MISSING",
            f"{'Would add' if dry_run else 'Added'} {len(in_data_not_manifest)} "
            f"data files missing from manifest",
        ))

    if not dry_run:
        # Rebuild manifest from actual data
        new_episodes = [ep for ep in current_episodes
                        if ep.get("episode_index", -1) in actual_indices]

        # Add any missing entries (basic metadata only)
        existing_indices = {ep.get("episode_index") for ep in new_episodes}
        for idx in sorted(in_data_not_manifest):
            if idx not in existing_indices:
                pf = _find_episode_parquet(data_dir, idx)
                length = 0
                if pf:
                    try:
                        table = pq.read_table(str(pf))
                        length = len(table)
                    except Exception:
                        pass
                new_episodes.append({
                    "episode_index": idx,
                    "length": length,
                })

        new_episodes.sort(key=lambda ep: ep.get("episode_index", 0))

        backup = episodes_path.with_suffix(".jsonl.bak")
        if not backup.exists():
            shutil.copy2(episodes_path, backup)

        with open(episodes_path, "w") as f:
            for ep in new_episodes:
                f.write(json.dumps(ep) + "\n")


# ---------------------------------------------------------------------------
# Regenerate stats
# ---------------------------------------------------------------------------

def _fix_regenerate_stats(
    root: Path,
    info: dict[str, Any],
    is_v3: bool,
    result: FixResult,
    dry_run: bool,
) -> None:
    data_dir = root / "data"
    if not data_dir.exists():
        return

    parquet_files = sorted(data_dir.rglob("*.parquet"))
    valid_files = [f for f in parquet_files if f.stat().st_size > 0]
    if not valid_files:
        return

    # Collect all numeric columns across files
    all_data: dict[str, list[np.ndarray]] = {}

    for pf in valid_files:
        try:
            table = pq.read_table(str(pf))
            for col_name in table.column_names:
                col = table.column(col_name)
                try:
                    arr = col.to_numpy()
                    if arr.dtype.kind in ("f", "i", "u"):  # float, int, uint
                        if col_name not in all_data:
                            all_data[col_name] = []
                        all_data[col_name].append(arr)
                except (ValueError, TypeError):
                    # Nested/list columns — try to stack
                    if is_v3 and col_name in ("action", "observation.state"):
                        try:
                            stacked = np.stack([
                                np.array(row.as_py(), dtype=np.float32)
                                for row in col
                            ])
                            if col_name not in all_data:
                                all_data[col_name] = []
                            all_data[col_name].append(stacked)
                        except Exception:
                            pass
        except Exception:
            continue

    if not all_data:
        return

    # Compute stats
    stats: dict[str, dict[str, list[float]]] = {}
    for col_name, arrays in all_data.items():
        combined = np.concatenate(arrays, axis=0)
        if combined.ndim == 1:
            combined = combined.reshape(-1, 1)

        mean = np.nanmean(combined, axis=0).tolist()
        std = np.nanstd(combined, axis=0).tolist()
        min_val = np.nanmin(combined, axis=0).tolist()
        max_val = np.nanmax(combined, axis=0).tolist()

        stats[col_name] = {
            "mean": mean,
            "std": std,
            "min": min_val,
            "max": max_val,
        }

    result.actions.append(FixAction(
        "REGENERATE_STATS",
        f"{'Would regenerate' if dry_run else 'Regenerated'} stats for "
        f"{len(stats)} column(s) from {len(valid_files)} file(s)",
    ))

    if not dry_run:
        stats_path = root / "meta" / "stats.json"
        backup = stats_path.with_suffix(".json.bak")
        if stats_path.exists() and not backup.exists():
            shutil.copy2(stats_path, backup)
        stats_path.write_text(json.dumps(stats, indent=2) + "\n")
        result.stats_regenerated = True


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _count_actual_episodes(root: Path, is_v3: bool) -> int:
    if is_v3:
        ep_dir = root / "meta" / "episodes"
        if not ep_dir.is_dir():
            return 0
        count = 0
        for pf in ep_dir.rglob("*.parquet"):
            try:
                table = pq.read_table(str(pf))
                count += len(table)
            except Exception:
                pass
        return count
    else:
        episodes_path = root / "meta" / "episodes.jsonl"
        if not episodes_path.exists():
            return 0
        return sum(1 for line in episodes_path.read_text().splitlines() if line.strip())


def _detect_action_dim(data_dir: Path, is_v3: bool) -> int | None:
    parquet_files = sorted(data_dir.rglob("*.parquet"))
    for pf in parquet_files[:3]:
        if pf.stat().st_size == 0:
            continue
        try:
            table = pq.read_table(str(pf))
            cols = table.column_names
            if is_v3 and "action" in cols:
                col = table.column("action")
                if len(col) > 0:
                    first = col[0].as_py()
                    if isinstance(first, list):
                        return len(first)
            else:
                act_cols = [c for c in cols if c.startswith("action")]
                if act_cols:
                    return len(act_cols)
        except Exception:
            continue
    return None


def _find_episode_parquet(data_dir: Path, idx: int) -> Path | None:
    filename = f"episode_{idx:06d}.parquet"
    flat = data_dir / filename
    if flat.exists():
        return flat
    chunk = data_dir / f"chunk-{idx // 1000:03d}" / filename
    if chunk.exists():
        return chunk
    return None
