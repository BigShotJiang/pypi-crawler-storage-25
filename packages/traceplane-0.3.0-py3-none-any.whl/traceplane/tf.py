"""TensorFlow integration — convert to tf.data.Dataset."""

from __future__ import annotations

from typing import Any

import numpy as np

try:
    import tensorflow as tf
except ImportError:
    raise ImportError(
        "TensorFlow is required for traceplane.tf. "
        "Install it with: pip install traceplane[tf]"
    )

from traceplane.dataset import TrajectoryDataset
from traceplane.windowing import WindowedDataset


def to_tf_dataset(
    dataset: TrajectoryDataset,
    obs_horizon: int = 2,
    action_horizon: int = 16,
    stride: int = 1,
    batch_size: int = 64,
    shuffle_buffer: int = 1000,
) -> tf.data.Dataset:
    """Create a ``tf.data.Dataset`` of windowed training samples.

    Args:
        dataset: Source trajectory dataset.
        obs_horizon: Observation history length.
        action_horizon: Action prediction horizon.
        stride: Window stride.
        batch_size: Batch size.
        shuffle_buffer: Buffer size for ``tf.data.Dataset.shuffle()``.

    Returns:
        A ``tf.data.Dataset`` yielding ``(obs_dict, action_chunk)`` tuples.
    """
    windowed = WindowedDataset(
        dataset,
        obs_horizon=obs_horizon,
        action_horizon=action_horizon,
        stride=stride,
    )

    # Probe first sample to determine shapes and keys
    if len(windowed) == 0:
        raise ValueError("No training windows available (dataset may be too short)")

    sample = windowed[0]
    obs_keys = sorted(sample.obs_history.keys())

    def generator():
        for i in range(len(windowed)):
            w = windowed[i]
            obs = {
                key: np.asarray(w.obs_history.get(key, np.zeros((obs_horizon, 1))), dtype=np.float32)
                for key in obs_keys
            }
            action = np.asarray(w.action_chunk, dtype=np.float32)
            yield obs, action

    # Build output signature
    obs_sig = {}
    for key in obs_keys:
        arr = sample.obs_history[key]
        obs_sig[key] = tf.TensorSpec(shape=arr.shape, dtype=tf.float32)

    action_sig = tf.TensorSpec(
        shape=(action_horizon, sample.action_chunk.shape[-1] if sample.action_chunk.ndim == 2 else 1),
        dtype=tf.float32,
    )

    ds = tf.data.Dataset.from_generator(
        generator,
        output_signature=(obs_sig, action_sig),
    )

    if shuffle_buffer > 0:
        ds = ds.shuffle(shuffle_buffer)

    ds = ds.batch(batch_size).prefetch(tf.data.AUTOTUNE)
    return ds
