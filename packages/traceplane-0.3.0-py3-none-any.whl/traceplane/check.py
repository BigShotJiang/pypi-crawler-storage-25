"""traceplane check — local dataset QA without a server.

Validates LeRobot v2/v3 datasets for structural integrity, metadata
consistency, and data quality. Produces a report with actionable findings.

Usage::

    from traceplane.check import check_dataset
    report = check_dataset("/path/to/dataset")
    report.print()
    report.to_json("qa_report.json")
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

import numpy as np
import pyarrow.parquet as pq


class Severity(str, Enum):
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


@dataclass
class Issue:
    code: str
    severity: Severity
    message: str
    episode: str | None = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "code": self.code,
            "severity": self.severity.value,
            "message": self.message,
        }
        if self.episode:
            d["episode"] = self.episode
        return d


@dataclass
class CheckReport:
    dataset_path: str
    format_version: str = ""
    total_episodes: int = 0
    episodes_checked: int = 0
    issues: list[Issue] = field(default_factory=list)

    @property
    def errors(self) -> list[Issue]:
        return [i for i in self.issues if i.severity == Severity.ERROR]

    @property
    def warnings(self) -> list[Issue]:
        return [i for i in self.issues if i.severity == Severity.WARNING]

    @property
    def passed(self) -> bool:
        return len(self.errors) == 0

    def print(self) -> None:
        """Print human-readable report to stdout."""
        print(f"\n{'='*60}")
        print(f"  traceplane check — {self.dataset_path}")
        print(f"{'='*60}")
        print(f"  Format:    {self.format_version}")
        print(f"  Episodes:  {self.total_episodes} declared, {self.episodes_checked} checked")
        print(f"  Result:    {'PASS' if self.passed else 'FAIL'}")
        print(f"  Errors:    {len(self.errors)}")
        print(f"  Warnings:  {len(self.warnings)}")
        print()

        if not self.issues:
            print("  No issues found.")
        else:
            for issue in self.issues:
                icon = "X" if issue.severity == Severity.ERROR else "!"
                ep = f" [{issue.episode}]" if issue.episode else ""
                print(f"  [{icon}] {issue.code}{ep}")
                print(f"      {issue.message}")
                print()

        print(f"{'='*60}\n")

    def to_dict(self) -> dict[str, Any]:
        return {
            "dataset_path": self.dataset_path,
            "format_version": self.format_version,
            "total_episodes": self.total_episodes,
            "episodes_checked": self.episodes_checked,
            "passed": self.passed,
            "error_count": len(self.errors),
            "warning_count": len(self.warnings),
            "issues": [i.to_dict() for i in self.issues],
        }

    def to_json(self, path: str | None = None) -> str:
        text = json.dumps(self.to_dict(), indent=2)
        if path:
            Path(path).write_text(text)
        return text


def check_dataset(
    path: str,
    max_episodes: int | None = None,
    check_data: bool = True,
) -> CheckReport:
    """Run all QA checks on a LeRobot dataset.

    Args:
        path: Path to dataset root directory.
        max_episodes: Max episodes to sample for data checks (default: all).
        check_data: Whether to read Parquet data files (slower but thorough).

    Returns:
        A :class:`CheckReport` with all findings.
    """
    root = Path(path)
    report = CheckReport(dataset_path=str(root))

    # ---- Phase 1: Metadata checks ----
    info = _check_metadata(root, report)
    if info is None:
        return report

    # ---- Phase 2: Episode manifest checks ----
    episodes = _check_episode_manifest(root, info, report)

    # ---- Phase 3: Stats checks ----
    _check_stats(root, info, report)

    # ---- Phase 4: Data file checks ----
    if check_data and episodes:
        sample = episodes[:max_episodes] if max_episodes else episodes
        _check_data_files(root, info, sample, report)
        report.episodes_checked = len(sample)
    else:
        report.episodes_checked = 0

    # ---- Phase 5: Video file checks ----
    _check_video_files(root, info, report)

    return report


# ---------------------------------------------------------------------------
# Phase 1: Metadata
# ---------------------------------------------------------------------------

def _check_metadata(root: Path, report: CheckReport) -> dict[str, Any] | None:
    info_path = root / "meta" / "info.json"
    if not info_path.exists():
        report.issues.append(Issue(
            "META_MISSING",
            Severity.ERROR,
            f"meta/info.json not found at {root}",
        ))
        return None

    try:
        info = json.loads(info_path.read_text())
    except (json.JSONDecodeError, UnicodeDecodeError) as e:
        report.issues.append(Issue(
            "META_INVALID_JSON",
            Severity.ERROR,
            f"meta/info.json is not valid JSON: {e}",
        ))
        return None

    # Detect version
    codebase_version = info.get("codebase_version", "")
    is_v3 = codebase_version.startswith("v3") or (root / "meta" / "episodes").is_dir()
    report.format_version = "lerobot_v3" if is_v3 else "lerobot_v2"

    # Required fields
    required = ["fps", "total_episodes"]
    for f in required:
        if f not in info:
            report.issues.append(Issue(
                "META_MISSING_FIELD",
                Severity.ERROR,
                f"meta/info.json missing required field '{f}'",
            ))

    # FPS sanity
    fps = info.get("fps")
    if fps is not None:
        if not isinstance(fps, (int, float)) or fps <= 0:
            report.issues.append(Issue(
                "META_BAD_FPS",
                Severity.ERROR,
                f"fps={fps} is invalid (must be positive number)",
            ))
        elif fps > 500:
            report.issues.append(Issue(
                "META_HIGH_FPS",
                Severity.WARNING,
                f"fps={fps} is unusually high — verify sensor configuration",
            ))

    # Total episodes
    total = info.get("total_episodes", 0)
    report.total_episodes = total
    if total == 0:
        report.issues.append(Issue(
            "META_ZERO_EPISODES",
            Severity.WARNING,
            "total_episodes is 0 — dataset may be empty or metadata is wrong",
        ))

    # Robot type
    if not info.get("robot_type"):
        report.issues.append(Issue(
            "META_NO_ROBOT_TYPE",
            Severity.WARNING,
            "robot_type not set — embodiment is unknown",
        ))

    # Features / action space documentation
    features = info.get("features")
    if features and isinstance(features, dict):
        if "action" not in features:
            report.issues.append(Issue(
                "META_NO_ACTION_SPEC",
                Severity.WARNING,
                "features dict exists but 'action' key missing — action space undocumented",
            ))
    elif not features:
        report.issues.append(Issue(
            "META_NO_FEATURES",
            Severity.INFO,
            "no 'features' dict in info.json — column schema undocumented",
        ))

    return info


# ---------------------------------------------------------------------------
# Phase 2: Episode manifest
# ---------------------------------------------------------------------------

def _check_episode_manifest(
    root: Path,
    info: dict[str, Any],
    report: CheckReport,
) -> list[dict[str, Any]]:
    is_v3 = report.format_version == "lerobot_v3"
    episodes: list[dict[str, Any]] = []

    if is_v3:
        ep_dir = root / "meta" / "episodes"
        if not ep_dir.is_dir():
            report.issues.append(Issue(
                "MANIFEST_MISSING",
                Severity.ERROR,
                "v3 dataset missing meta/episodes/ directory",
            ))
            return []
        parquet_files = sorted(ep_dir.rglob("*.parquet"))
        if not parquet_files:
            report.issues.append(Issue(
                "MANIFEST_EMPTY",
                Severity.ERROR,
                "meta/episodes/ contains no parquet files",
            ))
            return []
        for pf in parquet_files:
            try:
                table = pq.read_table(str(pf))
                df = table.to_pandas()
                for _, row in df.iterrows():
                    episodes.append({
                        "episode_index": int(row["episode_index"]),
                        "length": int(row.get("length", 0)),
                    })
            except Exception as e:
                report.issues.append(Issue(
                    "MANIFEST_READ_ERROR",
                    Severity.ERROR,
                    f"Failed to read {pf.name}: {e}",
                ))
    else:
        episodes_path = root / "meta" / "episodes.jsonl"
        if not episodes_path.exists():
            report.issues.append(Issue(
                "MANIFEST_MISSING",
                Severity.WARNING,
                "meta/episodes.jsonl not found — episode manifest missing",
            ))
            return []
        for i, line in enumerate(episodes_path.read_text().splitlines()):
            if not line.strip():
                continue
            try:
                episodes.append(json.loads(line))
            except json.JSONDecodeError as e:
                report.issues.append(Issue(
                    "MANIFEST_PARSE_ERROR",
                    Severity.ERROR,
                    f"episodes.jsonl line {i+1} is invalid JSON: {e}",
                ))

    # Count mismatch
    declared = info.get("total_episodes", 0)
    found = len(episodes)
    if declared > 0 and found != declared:
        report.issues.append(Issue(
            "EPISODE_COUNT_MISMATCH",
            Severity.ERROR,
            f"info.json says {declared} episodes but manifest has {found}",
        ))

    # Duplicate episode indices
    indices = [ep.get("episode_index", -1) for ep in episodes]
    seen: set[int] = set()
    dupes: list[int] = []
    for idx in indices:
        if idx in seen:
            dupes.append(idx)
        seen.add(idx)
    if dupes:
        report.issues.append(Issue(
            "DUPLICATE_EPISODE_IDS",
            Severity.ERROR,
            f"{len(dupes)} duplicate episode index(es): {dupes[:10]}{'...' if len(dupes)>10 else ''}",
        ))

    # Zero-length episodes
    zero_length = [ep for ep in episodes if ep.get("length", 0) == 0]
    if zero_length:
        report.issues.append(Issue(
            "ZERO_LENGTH_EPISODES",
            Severity.WARNING,
            f"{len(zero_length)} episode(s) have length=0",
        ))

    return episodes


# ---------------------------------------------------------------------------
# Phase 3: Stats
# ---------------------------------------------------------------------------

def _check_stats(
    root: Path,
    info: dict[str, Any],
    report: CheckReport,
) -> None:
    is_v3 = report.format_version == "lerobot_v3"

    if is_v3:
        stats_path = root / "meta" / "stats.parquet"
    else:
        stats_path = root / "meta" / "stats.json"

    if not stats_path.exists():
        report.issues.append(Issue(
            "STATS_MISSING",
            Severity.WARNING,
            f"{'stats.parquet' if is_v3 else 'stats.json'} not found — "
            "normalization will fail or use incorrect defaults",
        ))
        return

    if is_v3:
        _check_stats_parquet(stats_path, report)
    else:
        _check_stats_json(stats_path, report)


def _check_stats_json(stats_path: Path, report: CheckReport) -> None:
    try:
        stats = json.loads(stats_path.read_text())
    except (json.JSONDecodeError, UnicodeDecodeError) as e:
        report.issues.append(Issue(
            "STATS_INVALID",
            Severity.ERROR,
            f"stats.json is not valid JSON: {e}",
        ))
        return

    for key, stat in stats.items():
        if not isinstance(stat, dict):
            continue

        for stat_name in ["mean", "std", "min", "max"]:
            values = stat.get(stat_name)
            if values is None:
                continue
            if isinstance(values, list):
                for i, v in enumerate(values):
                    if v is None or (isinstance(v, float) and (math.isnan(v) or math.isinf(v))):
                        report.issues.append(Issue(
                            "STATS_NAN_INF",
                            Severity.ERROR,
                            f"stats['{key}']['{stat_name}'][{i}] is {v} — "
                            "will cause NaN during normalization",
                        ))

        # Zero-variance check
        std_vals = stat.get("std")
        if isinstance(std_vals, list):
            zero_dims = [i for i, v in enumerate(std_vals)
                         if isinstance(v, (int, float)) and v == 0.0]
            if zero_dims:
                report.issues.append(Issue(
                    "STATS_ZERO_VARIANCE",
                    Severity.WARNING,
                    f"stats['{key}']['std'] has {len(zero_dims)} zero-variance "
                    f"dimension(s): {zero_dims[:5]}{'...' if len(zero_dims)>5 else ''} — "
                    "normalization will produce Inf",
                ))


def _check_stats_parquet(stats_path: Path, report: CheckReport) -> None:
    try:
        table = pq.read_table(str(stats_path))
    except Exception as e:
        report.issues.append(Issue(
            "STATS_READ_ERROR",
            Severity.ERROR,
            f"Failed to read stats.parquet: {e}",
        ))
        return

    df = table.to_pandas()
    for col in df.columns:
        values = df[col].values
        if hasattr(values, '__iter__'):
            for i, v in enumerate(values):
                if isinstance(v, (float, np.floating)):
                    if np.isnan(v) or np.isinf(v):
                        report.issues.append(Issue(
                            "STATS_NAN_INF",
                            Severity.ERROR,
                            f"stats.parquet column '{col}' row {i} is {v}",
                        ))


# ---------------------------------------------------------------------------
# Phase 4: Data files
# ---------------------------------------------------------------------------

def _check_data_files(
    root: Path,
    info: dict[str, Any],
    episodes: list[dict[str, Any]],
    report: CheckReport,
) -> None:
    is_v3 = report.format_version == "lerobot_v3"
    data_dir = root / "data"

    if not data_dir.exists():
        report.issues.append(Issue(
            "DATA_DIR_MISSING",
            Severity.ERROR,
            "data/ directory not found",
        ))
        return

    # Find all parquet files
    parquet_files = sorted(data_dir.rglob("*.parquet"))
    if not parquet_files:
        report.issues.append(Issue(
            "DATA_NO_PARQUET",
            Severity.ERROR,
            "no .parquet files found under data/",
        ))
        return

    # Check for zero-byte files
    zero_byte = [f for f in parquet_files if f.stat().st_size == 0]
    if zero_byte:
        names = [f.name for f in zero_byte[:5]]
        report.issues.append(Issue(
            "DATA_ZERO_BYTE",
            Severity.ERROR,
            f"{len(zero_byte)} zero-byte Parquet file(s): {names}"
            f"{'...' if len(zero_byte)>5 else ''}",
        ))

    # Sample read: check schema consistency and dimensions
    action_dims: set[int] = set()
    state_dims: set[int] = set()
    schemas: list[list[str]] = []

    sample_files = parquet_files[:min(10, len(parquet_files))]
    for pf in sample_files:
        if pf.stat().st_size == 0:
            continue
        try:
            table = pq.read_table(str(pf))
            cols = table.column_names
            schemas.append(sorted(cols))

            # Check action dimensions
            if is_v3 and "action" in cols:
                action_col = table.column("action")
                if len(action_col) > 0:
                    first = action_col[0].as_py()
                    if isinstance(first, list):
                        action_dims.add(len(first))
            else:
                act_cols = [c for c in cols if c.startswith("action")]
                if act_cols:
                    action_dims.add(len(act_cols))

            # Check state dimensions
            if is_v3 and "observation.state" in cols:
                state_col = table.column("observation.state")
                if len(state_col) > 0:
                    first = state_col[0].as_py()
                    if isinstance(first, list):
                        state_dims.add(len(first))
            else:
                st_cols = [c for c in cols if c.startswith("observation.state")]
                if st_cols:
                    state_dims.add(len(st_cols))

        except Exception as e:
            report.issues.append(Issue(
                "DATA_READ_ERROR",
                Severity.ERROR,
                f"Failed to read {pf.name}: {e}",
                episode=pf.stem,
            ))

    # Inconsistent action dims
    if len(action_dims) > 1:
        report.issues.append(Issue(
            "DATA_INCONSISTENT_ACTION_DIM",
            Severity.ERROR,
            f"Multiple action dimensions found across files: {sorted(action_dims)} — "
            "episodes may come from different robots",
        ))

    # Inconsistent state dims
    if len(state_dims) > 1:
        report.issues.append(Issue(
            "DATA_INCONSISTENT_STATE_DIM",
            Severity.WARNING,
            f"Multiple state dimensions found: {sorted(state_dims)}",
        ))

    # Schema drift
    if schemas:
        reference = schemas[0]
        drifted = [i for i, s in enumerate(schemas) if s != reference]
        if drifted:
            report.issues.append(Issue(
                "DATA_SCHEMA_DRIFT",
                Severity.ERROR,
                f"{len(drifted)} file(s) have different column schemas than the first file — "
                "data loader may fail or silently drop columns",
            ))

    # Action dim vs metadata
    features = info.get("features", {})
    if features and "action" in features:
        action_spec = features["action"]
        declared_shape = action_spec.get("shape")
        if declared_shape and action_dims:
            declared_dim = declared_shape[-1] if isinstance(declared_shape, list) else declared_shape
            actual_dim = next(iter(action_dims))
            if declared_dim != actual_dim:
                report.issues.append(Issue(
                    "DATA_ACTION_DIM_MISMATCH",
                    Severity.ERROR,
                    f"info.json declares action shape {declared_shape} "
                    f"(dim={declared_dim}) but data has dim={actual_dim}",
                ))


# ---------------------------------------------------------------------------
# Phase 5: Video files
# ---------------------------------------------------------------------------

def _check_video_files(
    root: Path,
    info: dict[str, Any],
    report: CheckReport,
) -> None:
    videos_dir = root / "videos"
    if not videos_dir.exists():
        return  # Not all datasets have videos

    video_files = list(videos_dir.rglob("*.mp4"))
    if not video_files:
        report.issues.append(Issue(
            "VIDEO_DIR_EMPTY",
            Severity.WARNING,
            "videos/ directory exists but contains no .mp4 files",
        ))
        return

    # Check for zero-byte videos
    zero_byte = [f for f in video_files if f.stat().st_size == 0]
    if zero_byte:
        names = [f.name for f in zero_byte[:5]]
        report.issues.append(Issue(
            "VIDEO_ZERO_BYTE",
            Severity.ERROR,
            f"{len(zero_byte)} zero-byte video file(s): {names}"
            f"{'...' if len(zero_byte)>5 else ''}",
        ))

    # Check video count vs episode count
    total_eps = info.get("total_episodes", 0)
    features = info.get("features", {})
    video_keys = [k for k, v in features.items()
                  if isinstance(v, dict) and v.get("video", False)]

    if video_keys and total_eps > 0:
        expected_videos = total_eps * len(video_keys)
        if len(video_files) < expected_videos:
            report.issues.append(Issue(
                "VIDEO_COUNT_MISMATCH",
                Severity.WARNING,
                f"Expected {expected_videos} videos ({total_eps} episodes x "
                f"{len(video_keys)} cameras) but found {len(video_files)}",
            ))
