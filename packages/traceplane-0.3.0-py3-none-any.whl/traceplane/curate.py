"""traceplane curate — policy-aware episode scoring and curation.

Scores each episode on computable proxy metrics (smoothness, outlier
detection, redundancy, diversity contribution) and produces keep/review/drop
recommendations.

Usage::

    from traceplane.curate import curate_dataset
    result = curate_dataset("/path/to/dataset")
    result.print()
    result.to_html("curation_report.html")
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np

from traceplane import report


@dataclass
class EpisodeScore:
    episode_id: str
    episode_index: int
    length: int
    task_label: str
    smoothness: float  # 0-1, higher = smoother
    outlier: float     # 0-1, higher = more normal (not outlier)
    redundancy: float  # 0-1, higher = more unique
    composite: float   # 0-1, weighted combination
    recommendation: str  # "keep", "review", "drop"


@dataclass
class CurationResult:
    dataset_path: str
    total_episodes: int = 0
    scored_episodes: int = 0
    keep_count: int = 0
    review_count: int = 0
    drop_count: int = 0
    scores: list[EpisodeScore] = field(default_factory=list)
    top_k: int | None = None

    def print(self) -> None:
        print(f"\n{'='*60}")
        print(f"  traceplane curate — {self.dataset_path}")
        print(f"{'='*60}")
        print(f"  Episodes scored:  {self.scored_episodes}")
        print(f"  Keep:             {self.keep_count}")
        print(f"  Review:           {self.review_count}")
        print(f"  Drop:             {self.drop_count}")
        print()

        if self.scores:
            print(f"  {'Episode':<20} {'Task':<25} {'Smooth':>7} {'Normal':>7} {'Unique':>7} {'Score':>7} {'Rec':<6}")
            print(f"  {'-'*20} {'-'*25} {'-'*7} {'-'*7} {'-'*7} {'-'*7} {'-'*6}")
            for s in self.scores[:20]:
                task = s.task_label[:24] if s.task_label else ""
                print(f"  {s.episode_id:<20} {task:<25} {s.smoothness:>7.2f} {s.outlier:>7.2f} {s.redundancy:>7.2f} {s.composite:>7.2f} {s.recommendation:<6}")
            if len(self.scores) > 20:
                print(f"  ... and {len(self.scores) - 20} more")
        print(f"\n{'='*60}\n")

    def to_html(self, path: str) -> None:
        body = _render_html(self)
        html = report.html_document(f"Curation Report — {self.dataset_path}", body)
        Path(path).write_text(html)

    def to_dict(self) -> dict[str, Any]:
        return {
            "dataset_path": self.dataset_path,
            "total_episodes": self.total_episodes,
            "scored_episodes": self.scored_episodes,
            "keep_count": self.keep_count,
            "review_count": self.review_count,
            "drop_count": self.drop_count,
            "scores": [
                {
                    "episode_id": s.episode_id,
                    "episode_index": s.episode_index,
                    "length": s.length,
                    "task_label": s.task_label,
                    "smoothness": round(s.smoothness, 4),
                    "outlier": round(s.outlier, 4),
                    "redundancy": round(s.redundancy, 4),
                    "composite": round(s.composite, 4),
                    "recommendation": s.recommendation,
                }
                for s in self.scores
            ],
        }

    def curated_indices(self) -> list[int]:
        """Return episode indices for 'keep' episodes."""
        return [s.episode_index for s in self.scores if s.recommendation == "keep"]


def curate_dataset(
    path: str,
    max_episodes: int | None = None,
    keep_threshold: float = 0.6,
    drop_threshold: float = 0.3,
    weights: dict[str, float] | None = None,
) -> CurationResult:
    """Score and curate episodes in a dataset.

    Args:
        path: Path to dataset root.
        max_episodes: Max episodes to score (default: all).
        keep_threshold: Composite score above this → "keep" (default: 0.6).
        drop_threshold: Composite score below this → "drop" (default: 0.3).
        weights: Custom weights for scoring dimensions.
            Keys: "smoothness", "outlier", "redundancy".
            Default: {"smoothness": 0.4, "outlier": 0.3, "redundancy": 0.3}.

    Returns:
        A :class:`CurationResult` with scored and ranked episodes.
    """
    from traceplane.lerobot_reader import LeRobotReader

    w = weights or {"smoothness": 0.4, "outlier": 0.3, "redundancy": 0.3}
    w_smooth = w.get("smoothness", 0.4)
    w_outlier = w.get("outlier", 0.3)
    w_redundancy = w.get("redundancy", 0.3)

    reader = LeRobotReader(path)
    result = CurationResult(dataset_path=path, total_episodes=len(reader))

    indices = list(range(len(reader)))
    if max_episodes:
        indices = indices[:max_episodes]

    # Phase 1: Load episode action data
    episode_data: list[dict[str, Any]] = []
    for idx in indices:
        ep = reader[idx]
        episode_data.append({
            "episode_id": ep.episode_id,
            "episode_index": ep.metadata.get("episode_index", idx),
            "length": ep.length,
            "task_label": ep.metadata.get("task_label", ""),
            "actions": ep.actions,
        })

    if not episode_data:
        return result

    # Phase 2: Compute per-episode metrics
    smoothness_scores = _compute_smoothness(episode_data)
    outlier_scores = _compute_outlier(episode_data)
    redundancy_scores = _compute_redundancy(episode_data)

    # Phase 3: Composite scoring and recommendations
    scores: list[EpisodeScore] = []
    for i, ep in enumerate(episode_data):
        smooth = smoothness_scores[i]
        outlier = outlier_scores[i]
        redundancy = redundancy_scores[i]

        composite = (
            w_smooth * smooth +
            w_outlier * outlier +
            w_redundancy * redundancy
        )

        if composite >= keep_threshold:
            rec = "keep"
        elif composite <= drop_threshold:
            rec = "drop"
        else:
            rec = "review"

        scores.append(EpisodeScore(
            episode_id=ep["episode_id"],
            episode_index=ep["episode_index"],
            length=ep["length"],
            task_label=ep["task_label"],
            smoothness=smooth,
            outlier=outlier,
            redundancy=redundancy,
            composite=composite,
            recommendation=rec,
        ))

    scores.sort(key=lambda s: s.composite, reverse=True)

    result.scored_episodes = len(scores)
    result.keep_count = sum(1 for s in scores if s.recommendation == "keep")
    result.review_count = sum(1 for s in scores if s.recommendation == "review")
    result.drop_count = sum(1 for s in scores if s.recommendation == "drop")
    result.scores = scores

    return result


# ---------------------------------------------------------------------------
# Scoring functions
# ---------------------------------------------------------------------------

def _compute_smoothness(episodes: list[dict[str, Any]]) -> list[float]:
    """Compute smoothness score for each episode based on normalized jerk."""
    scores = []
    for ep in episodes:
        actions = ep["actions"]
        if actions.ndim < 2 or actions.shape[0] < 3:
            scores.append(0.5)  # neutral for episodes too short to evaluate
            continue

        # Compute jerk (3rd finite difference)
        velocity = np.diff(actions, axis=0)
        acceleration = np.diff(velocity, axis=0)
        jerk = np.diff(acceleration, axis=0)

        if jerk.shape[0] == 0:
            scores.append(0.5)
            continue

        # Normalized jerk: mean absolute jerk / mean absolute velocity
        mean_jerk = np.mean(np.abs(jerk))
        mean_vel = np.mean(np.abs(velocity)) + 1e-8

        normalized_jerk = mean_jerk / mean_vel

        # Convert to 0-1 score (lower jerk = higher smoothness)
        # Use sigmoid-like mapping: score = 1 / (1 + nj)
        score = 1.0 / (1.0 + normalized_jerk)
        scores.append(float(np.clip(score, 0, 1)))

    return scores


def _compute_outlier(episodes: list[dict[str, Any]]) -> list[float]:
    """Compute outlier normality score (higher = more normal)."""
    # Compute mean action vector per episode
    mean_actions = []
    valid_mask = []
    for ep in episodes:
        actions = ep["actions"]
        if actions.ndim >= 2 and actions.shape[0] > 0:
            mean_actions.append(np.mean(actions, axis=0))
            valid_mask.append(True)
        else:
            mean_actions.append(None)
            valid_mask.append(False)

    valid_means = [m for m in mean_actions if m is not None]
    if len(valid_means) < 2:
        return [0.5] * len(episodes)

    # Stack and compute dataset-level statistics
    stacked = np.stack(valid_means)
    dataset_mean = np.mean(stacked, axis=0)
    dataset_std = np.std(stacked, axis=0) + 1e-8

    # Z-score distance from dataset mean
    scores = []
    for m, valid in zip(mean_actions, valid_mask):
        if not valid:
            scores.append(0.5)
            continue
        z = np.abs((m - dataset_mean) / dataset_std)
        mean_z = float(np.mean(z))
        # Convert to 0-1 score: lower z = more normal = higher score
        score = 1.0 / (1.0 + mean_z * 0.5)
        scores.append(float(np.clip(score, 0, 1)))

    return scores


def _compute_redundancy(episodes: list[dict[str, Any]]) -> list[float]:
    """Compute uniqueness score (higher = more unique, less redundant)."""
    # Compute feature vector per episode: [mean_action, std_action, length_norm]
    features = []
    valid_mask = []
    for ep in episodes:
        actions = ep["actions"]
        if actions.ndim >= 2 and actions.shape[0] > 0:
            mean_a = np.mean(actions, axis=0)
            std_a = np.std(actions, axis=0)
            feat = np.concatenate([mean_a, std_a])
            features.append(feat)
            valid_mask.append(True)
        else:
            features.append(None)
            valid_mask.append(False)

    valid_features = [f for f in features if f is not None]
    if len(valid_features) < 2:
        return [0.5] * len(episodes)

    stacked = np.stack(valid_features)

    # Normalize features
    f_mean = np.mean(stacked, axis=0)
    f_std = np.std(stacked, axis=0) + 1e-8
    normalized = (stacked - f_mean) / f_std

    # Compute pairwise cosine similarity via dot product of normalized vectors
    norms = np.linalg.norm(normalized, axis=1, keepdims=True) + 1e-8
    unit = normalized / norms

    scores = []
    valid_idx = 0
    for i, valid in enumerate(valid_mask):
        if not valid:
            scores.append(0.5)
            continue

        # Find max similarity to any other episode
        sims = unit @ unit[valid_idx]
        sims[valid_idx] = -1  # exclude self
        max_sim = float(np.max(sims))
        valid_idx += 1

        # Convert: low similarity = unique = high score
        # max_sim ranges from -1 to 1, map to 0-1 uniqueness score
        uniqueness = (1.0 - max_sim) / 2.0
        scores.append(float(np.clip(uniqueness, 0, 1)))

    return scores


# ---------------------------------------------------------------------------
# HTML report rendering
# ---------------------------------------------------------------------------

def _render_html(result: CurationResult) -> str:
    total = result.scored_episodes or 1

    # Stats row
    stats = "".join([
        report.stat_card(str(result.scored_episodes), "Episodes scored"),
        report.stat_card(str(result.keep_count), "Keep"),
        report.stat_card(str(result.review_count), "Review"),
        report.stat_card(str(result.drop_count), "Drop"),
        report.stat_card(f"{result.keep_count/total*100:.0f}%", "Keep rate"),
    ])

    # Score distribution summary
    avg_smooth = np.mean([s.smoothness for s in result.scores]) if result.scores else 0
    avg_outlier = np.mean([s.outlier for s in result.scores]) if result.scores else 0
    avg_redundancy = np.mean([s.redundancy for s in result.scores]) if result.scores else 0
    avg_composite = np.mean([s.composite for s in result.scores]) if result.scores else 0

    # Episode table
    table_rows = []
    for s in result.scores:
        rec_badge = {
            "keep": report.badge("KEEP", "pass"),
            "review": report.badge("REVIEW", "warn"),
            "drop": report.badge("DROP", "fail"),
        }.get(s.recommendation, "")

        task = s.task_label[:40] if s.task_label else ""
        table_rows.append(f"""<tr>
  <td>{s.episode_id}</td>
  <td title="{s.task_label}">{task}</td>
  <td style="text-align:right">{s.length}</td>
  <td>{report.score_pill(s.smoothness)}</td>
  <td>{report.score_pill(s.outlier)}</td>
  <td>{report.score_pill(s.redundancy)}</td>
  <td>{report.score_pill(s.composite)}</td>
  <td>{rec_badge}</td>
</tr>""")

    table = f"""<table>
<thead><tr>
  <th>Episode</th><th>Task</th><th style="text-align:right">Length</th>
  <th>Smooth</th><th>Normal</th><th>Unique</th><th>Score</th><th>Rec</th>
</tr></thead>
<tbody>
{"".join(table_rows)}
</tbody></table>"""

    # Composite score distribution (histogram-like)
    buckets = [0] * 10  # 0.0-0.1, 0.1-0.2, ...
    for s in result.scores:
        b = min(int(s.composite * 10), 9)
        buckets[b] += 1

    dist_items = [(f"{i/10:.1f}-{(i+1)/10:.1f}", buckets[i]) for i in range(10)]

    return f"""
<h1>Curation Report</h1>
<p class="subtitle">{result.dataset_path}</p>

<div class="stats-row">{stats}</div>

<h2>Score Averages</h2>
<div class="card">
  <div class="stats-row">
    {report.stat_card(f"{avg_smooth:.2f}", "Avg smoothness")}
    {report.stat_card(f"{avg_outlier:.2f}", "Avg normality")}
    {report.stat_card(f"{avg_redundancy:.2f}", "Avg uniqueness")}
    {report.stat_card(f"{avg_composite:.2f}", "Avg composite")}
  </div>
</div>

<h2>Score Distribution</h2>
<div class="card">
  {report.distribution_chart(dist_items)}
</div>

<h2>Episode Scores</h2>
<div class="card" style="overflow-x:auto">
  {table}
</div>

<div class="recommendation">
  <strong>Recommendation:</strong> Keep {result.keep_count} episodes ({result.keep_count/total*100:.0f}%),
  review {result.review_count} ({result.review_count/total*100:.0f}%),
  drop {result.drop_count} ({result.drop_count/total*100:.0f}%).
  Use <code>result.curated_indices()</code> to get the filtered episode list.
</div>
"""
