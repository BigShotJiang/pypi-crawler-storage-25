"""traceplane publish — export and push datasets to HuggingFace Hub.

Generates a LeRobot v3-compatible dataset layout with auto-generated
dataset cards, QA stats, and optional Hub upload.

Usage::

    from traceplane.publish import publish_dataset
    result = publish_dataset(
        "/path/to/dataset",
        repo_id="my-org/my-dataset",
        push=True,
    )
"""

from __future__ import annotations

import json
import shutil
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


@dataclass
class PublishResult:
    dataset_path: str
    output_path: str | None = None
    repo_id: str | None = None
    pushed: bool = False
    card_generated: bool = False
    files_exported: int = 0
    qa_summary: dict[str, Any] = field(default_factory=dict)

    def print(self) -> None:
        print(f"\n{'='*60}")
        print(f"  traceplane publish — {self.dataset_path}")
        print(f"{'='*60}")
        if self.output_path:
            print(f"  Export path:  {self.output_path}")
        print(f"  Files:        {self.files_exported}")
        print(f"  Dataset card: {'yes' if self.card_generated else 'no'}")
        if self.repo_id:
            print(f"  Repo:         {self.repo_id}")
            print(f"  Pushed:       {'yes' if self.pushed else 'no'}")
        if self.qa_summary:
            print(f"  QA result:    {self.qa_summary.get('result', 'unknown')}")
            print(f"  Errors:       {self.qa_summary.get('errors', 0)}")
            print(f"  Warnings:     {self.qa_summary.get('warnings', 0)}")
        print(f"{'='*60}\n")


def publish_dataset(
    path: str,
    output_path: str | None = None,
    repo_id: str | None = None,
    push: bool = False,
    run_qa: bool = True,
    description: str | None = None,
    tags: list[str] | None = None,
    license: str = "apache-2.0",
    citation: str | None = None,
    private: bool = False,
) -> PublishResult:
    """Publish a dataset: generate card, optionally run QA, push to Hub.

    Args:
        path: Source dataset root.
        output_path: Where to write the export (default: ``{path}_export``).
        repo_id: HuggingFace repo ID (e.g. "my-org/my-dataset").
            Required if ``push=True``.
        push: Whether to upload to HuggingFace Hub.
        run_qa: Run ``traceplane check`` before publishing.
        description: Dataset description for the card.
        tags: Tags for the dataset card.
        license: License identifier (default: apache-2.0).
        citation: BibTeX citation string.
        private: Whether the Hub repo should be private.

    Returns:
        A :class:`PublishResult` with export details.
    """
    root = Path(path)
    result = PublishResult(dataset_path=str(root))

    # Load info
    info_path = root / "meta" / "info.json"
    if not info_path.exists():
        raise FileNotFoundError(f"meta/info.json not found at {root}")

    info = json.loads(info_path.read_text())

    # Run QA if requested
    qa_summary: dict[str, Any] = {}
    if run_qa:
        from traceplane.check import check_dataset
        report = check_dataset(str(root), max_episodes=50)
        qa_summary = {
            "result": "PASS" if report.passed else "FAIL",
            "errors": len(report.errors),
            "warnings": len(report.warnings),
            "episodes_checked": report.episodes_checked,
            "issues": [i.to_dict() for i in report.issues[:10]],
        }
        result.qa_summary = qa_summary

    # Prepare export directory
    export_dir = Path(output_path) if output_path else root / "_export"
    if export_dir.exists() and export_dir != root:
        shutil.rmtree(export_dir)
    export_dir.mkdir(parents=True, exist_ok=True)

    # Copy dataset files
    files_copied = 0
    for subdir in ["meta", "data", "videos"]:
        src = root / subdir
        dst = export_dir / subdir
        if src.exists():
            if dst.exists():
                shutil.rmtree(dst)
            shutil.copytree(src, dst)
            files_copied += sum(1 for _ in dst.rglob("*") if _.is_file())

    result.files_exported = files_copied
    result.output_path = str(export_dir)

    # Generate dataset card
    card_content = _generate_dataset_card(
        info=info,
        qa_summary=qa_summary,
        description=description,
        tags=tags or [],
        license=license,
        citation=citation,
        dataset_path=str(root),
    )
    card_path = export_dir / "README.md"
    card_path.write_text(card_content)
    result.card_generated = True

    # Push to Hub
    if push and repo_id:
        result.repo_id = repo_id
        try:
            from huggingface_hub import HfApi
            api = HfApi()
            api.create_repo(repo_id, repo_type="dataset", private=private, exist_ok=True)
            api.upload_folder(
                folder_path=str(export_dir),
                repo_id=repo_id,
                repo_type="dataset",
                commit_message=f"Published via traceplane ({datetime.now(timezone.utc).strftime('%Y-%m-%d')})",
            )
            result.pushed = True
        except ImportError:
            raise ImportError(
                "huggingface-hub is required for pushing. "
                "Install with: pip install traceplane[hub]"
            )

    return result


def _generate_dataset_card(
    info: dict[str, Any],
    qa_summary: dict[str, Any],
    description: str | None,
    tags: list[str],
    license: str,
    citation: str | None,
    dataset_path: str,
) -> str:
    """Generate a HuggingFace-compatible dataset card (README.md)."""

    total_episodes = info.get("total_episodes", 0)
    fps = info.get("fps", "unknown")
    robot_type = info.get("robot_type", "unknown")
    codebase_version = info.get("codebase_version", "unknown")

    # YAML frontmatter
    all_tags = ["robotics", "trajectories", "lerobot", "traceplane"] + tags
    if robot_type and robot_type != "unknown":
        all_tags.append(robot_type)
    tags_yaml = "\n".join(f"  - {t}" for t in all_tags)

    desc = description or f"Robot learning dataset with {total_episodes} episodes at {fps}Hz."

    # QA badge
    if qa_summary:
        qa_result = qa_summary.get("result", "unknown")
        qa_badge = f"**QA Status:** {'PASS' if qa_result == 'PASS' else 'FAIL'} ({qa_summary.get('errors', 0)} errors, {qa_summary.get('warnings', 0)} warnings)"
    else:
        qa_badge = "**QA Status:** Not run"

    # Features table
    features = info.get("features", {})
    features_table = ""
    if features:
        rows = []
        for key, spec in features.items():
            if isinstance(spec, dict):
                shape = spec.get("shape", "")
                dtype = spec.get("dtype", "")
                rows.append(f"| `{key}` | {shape} | {dtype} |")
        if rows:
            features_table = "| Feature | Shape | Type |\n|---|---|---|\n" + "\n".join(rows)

    # QA issues
    qa_section = ""
    if qa_summary and qa_summary.get("issues"):
        issue_lines = []
        for issue in qa_summary["issues"][:5]:
            severity = issue.get("severity", "info").upper()
            code = issue.get("code", "")
            msg = issue.get("message", "")
            issue_lines.append(f"- **[{severity}]** `{code}`: {msg}")
        qa_section = "### QA Issues\n\n" + "\n".join(issue_lines)

    # Citation
    citation_section = ""
    if citation:
        citation_section = f"""## Citation

```bibtex
{citation}
```"""

    now = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    return f"""---
license: {license}
tags:
{tags_yaml}
task_categories:
  - robotics
size_categories:
  - {_size_category(total_episodes)}
---

# {Path(dataset_path).name}

{desc}

{qa_badge}

## Dataset Summary

| Property | Value |
|---|---|
| Episodes | {total_episodes:,} |
| FPS | {fps} |
| Robot | {robot_type} |
| Format | LeRobot {codebase_version} |
| Published | {now} |

{f"## Features" + chr(10) + chr(10) + features_table if features_table else ""}

## Usage

```python
import traceplane

# Load locally
ds = traceplane.load("{dataset_path}")

# Or run QA first
report = traceplane.check_dataset("{dataset_path}")
report.print()
```

## Quality Report

This dataset was validated with `traceplane check` before publishing.

{qa_section}

{citation_section}

---

*Published with [Traceplane](https://traceplane.ai) — data infrastructure for robotics trajectories.*
"""


def _size_category(n: int) -> str:
    if n < 100:
        return "n<1K"
    elif n < 1000:
        return "1K<n<10K"
    elif n < 10000:
        return "10K<n<100K"
    else:
        return "100K<n<1M"
