"""Read LeRobot v2 and v3 datasets from local or remote storage."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import fsspec
import numpy as np
import pyarrow.parquet as pq

from traceplane.dataset import Episode, TrajectoryDataset


class LeRobotReader(TrajectoryDataset):
    """Read a LeRobot v2 or v3 dataset.

    Supports local paths and any remote filesystem that ``fsspec`` can open
    (S3 via ``s3fs``, GCS via ``gcsfs``, HTTP, HuggingFace Hub, etc.).

    Automatically detects format version from ``meta/info.json``.

    Args:
        path: Dataset root path. Can be a local directory or a remote URI
            (e.g. ``s3://bucket/dataset``, ``hf://datasets/org/name``).
        storage_options: Extra kwargs passed to ``fsspec.filesystem()``.
            For S3: ``{"key": "...", "secret": "..."}``.
            For GCS: ``{"token": "..."}``.
        episode_indices: Optional subset of episode indices to load.
            If None, all episodes are available.
    """

    def __init__(
        self,
        path: str | Path,
        storage_options: dict[str, Any] | None = None,
        episode_indices: list[int] | None = None,
    ):
        self._path = str(path)
        self._storage_options = storage_options or {}

        # Determine filesystem
        self._fs, self._root = fsspec.core.url_to_fs(
            self._path, **self._storage_options
        )

        # Load dataset info
        self._info = self._read_json(self._join("meta", "info.json"))
        self._fps = self._info.get("fps", 30.0)
        self._total_episodes = self._info.get("total_episodes", 0)

        # Detect version
        codebase_version = self._info.get("codebase_version", "")
        self._is_v3 = codebase_version.startswith("v3") or self._fs.exists(
            self._join("meta", "episodes")
        )

        # Load tasks
        self._task_map: dict[int, str] = {}
        self._load_tasks()

        # Load episode metadata
        self._episodes: list[dict[str, Any]] = []
        self._load_episodes()

        # Filter to requested indices
        if episode_indices is not None:
            idx_set = set(episode_indices)
            self._episodes = [
                ep
                for ep in self._episodes
                if ep.get("episode_index", 0) in idx_set
            ]

        # For v3: cache the data parquet path per episode for efficient access
        if self._is_v3:
            self._v3_data_cache: dict[int, tuple[str, int, int]] = {}
            self._build_v3_data_index()

    # -- Init helpers ---------------------------------------------------------

    def _load_tasks(self) -> None:
        if self._is_v3:
            tasks_path = self._join("meta", "tasks.parquet")
            if self._fs.exists(tasks_path):
                table = pq.read_table(self._fs.open(tasks_path, "rb"))
                df = table.to_pandas()
                # v3: task text is the pandas index, task_index is a column
                for task_text, row in df.iterrows():
                    self._task_map[int(row["task_index"])] = str(task_text)
        else:
            tasks_path = self._join("meta", "tasks.jsonl")
            if self._fs.exists(tasks_path):
                for line in self._read_text(tasks_path).splitlines():
                    if not line.strip():
                        continue
                    entry = json.loads(line)
                    self._task_map[entry.get("task_index", 0)] = entry.get(
                        "task", ""
                    )

    def _load_episodes(self) -> None:
        if self._is_v3:
            # v3: meta/episodes/chunk-NNN/file-NNN.parquet
            ep_dir = self._join("meta", "episodes")
            parquet_files = sorted(self._fs.glob(ep_dir + "/**/*.parquet"))
            for pf in parquet_files:
                table = pq.read_table(self._fs.open(pf, "rb"))
                df = table.to_pandas()
                for _, row in df.iterrows():
                    ep = {
                        "episode_index": int(row["episode_index"]),
                        "length": int(row.get("length", 0)),
                    }
                    # Extract task indices
                    tasks_val = row.get("tasks")
                    if tasks_val is not None:
                        if hasattr(tasks_val, "tolist"):
                            ep["tasks"] = tasks_val.tolist()
                        elif isinstance(tasks_val, (list, np.ndarray)):
                            ep["tasks"] = list(tasks_val)
                        else:
                            ep["tasks"] = [int(tasks_val)]
                    # Store data file references for v3
                    if "data/chunk_index" in row.index:
                        ep["data_chunk_index"] = int(row["data/chunk_index"])
                    if "data/file_index" in row.index:
                        ep["data_file_index"] = int(row["data/file_index"])
                    if "dataset_from_index" in row.index:
                        ep["dataset_from_index"] = int(
                            row["dataset_from_index"]
                        )
                    if "dataset_to_index" in row.index:
                        ep["dataset_to_index"] = int(row["dataset_to_index"])
                    self._episodes.append(ep)
        else:
            # v2: meta/episodes.jsonl
            episodes_path = self._join("meta", "episodes.jsonl")
            if self._fs.exists(episodes_path):
                for line in self._read_text(episodes_path).splitlines():
                    if not line.strip():
                        continue
                    self._episodes.append(json.loads(line))

        # Fallback: generate from total_episodes if nothing loaded
        if not self._episodes and self._total_episodes > 0:
            self._episodes = [
                {"episode_index": i, "length": 0}
                for i in range(self._total_episodes)
            ]

    def _build_v3_data_index(self) -> None:
        """Build index: episode_index -> (parquet_path, from_row, to_row)."""
        for ep in self._episodes:
            ep_idx = ep["episode_index"]
            chunk_idx = ep.get("data_chunk_index", ep_idx // 1000)
            file_idx = ep.get("data_file_index", 0)
            from_idx = ep.get("dataset_from_index", 0)
            to_idx = ep.get("dataset_to_index", from_idx + ep.get("length", 0))
            path = self._join(
                "data",
                f"chunk-{chunk_idx:03d}",
                f"file-{file_idx:03d}.parquet",
            )
            self._v3_data_cache[ep_idx] = (path, from_idx, to_idx)

    # -- fsspec helpers -------------------------------------------------------

    def _join(self, *parts: str) -> str:
        return "/".join([self._root.rstrip("/"), *parts])

    def _read_json(self, path: str) -> dict:
        with self._fs.open(path, "r") as f:
            return json.load(f)

    def _read_text(self, path: str) -> str:
        with self._fs.open(path, "r") as f:
            return f.read()

    # -- Dataset interface ----------------------------------------------------

    def __len__(self) -> int:
        return len(self._episodes)

    def episode_ids(self) -> list[str]:
        return [
            f"episode_{ep.get('episode_index', i):06d}"
            for i, ep in enumerate(self._episodes)
        ]

    def __getitem__(self, idx: int) -> Episode:
        ep_meta = self._episodes[idx]
        ep_index = ep_meta.get("episode_index", idx)
        episode_id = f"episode_{ep_index:06d}"

        if self._is_v3:
            return self._load_v3_episode(ep_index, episode_id, ep_meta)
        else:
            return self._load_v2_episode(ep_index, episode_id, ep_meta)

    # -- v3 loading -----------------------------------------------------------

    def _load_v3_episode(
        self, ep_index: int, episode_id: str, ep_meta: dict
    ) -> Episode:
        cache = self._v3_data_cache.get(ep_index)
        if cache is None:
            return Episode(
                episode_id=episode_id,
                metadata=self._build_metadata(ep_meta),
            )

        parquet_path, from_idx, to_idx = cache

        if not self._fs.exists(parquet_path):
            return Episode(
                episode_id=episode_id,
                metadata=self._build_metadata(ep_meta),
            )

        # Read the full parquet and slice to this episode's rows
        table = pq.read_table(self._fs.open(parquet_path, "rb"))
        table = table.slice(from_idx, to_idx - from_idx)

        columns = table.column_names
        observations: dict[str, np.ndarray] = {}
        actions = np.empty((0,))
        timestamps = np.empty((0,))

        # v3: "action" is a single list column (nested array)
        if "action" in columns:
            action_col = table.column("action")
            rows = [np.array(row.as_py(), dtype=np.float32) for row in action_col if row.as_py() is not None]
            if rows:
                actions = np.stack(rows)

        # v3: "observation.state" is a single list column
        if "observation.state" in columns:
            state_col = table.column("observation.state")
            state_rows = [np.array(row.as_py(), dtype=np.float32) for row in state_col if row.as_py() is not None]
            if state_rows:
                observations["state"] = np.stack(state_rows)

        # Timestamps
        if "timestamp" in columns:
            ts_col = table.column("timestamp")
            timestamps = ts_col.to_numpy().astype(np.float64)

        return Episode(
            episode_id=episode_id,
            observations=observations,
            actions=actions,
            timestamps=timestamps,
            metadata=self._build_metadata(ep_meta),
        )

    # -- v2 loading -----------------------------------------------------------

    def _load_v2_episode(
        self, ep_index: int, episode_id: str, ep_meta: dict
    ) -> Episode:
        parquet_path = self._find_v2_parquet(ep_index)
        if parquet_path is None:
            return Episode(
                episode_id=episode_id,
                metadata=self._build_metadata(ep_meta),
            )

        table = pq.read_table(self._fs.open(parquet_path, "rb"))
        columns = table.column_names

        observations: dict[str, np.ndarray] = {}
        actions = np.empty((0,))
        timestamps = np.empty((0,))

        # v2: flattened action columns (action_0, action_1, ...)
        action_cols = sorted([c for c in columns if c.startswith("action")])
        if action_cols:
            action_arrays = [table.column(c).to_numpy() for c in action_cols]
            actions = (
                np.column_stack(action_arrays)
                if len(action_arrays) > 1
                else action_arrays[0].reshape(-1, 1)
            )

        # Timestamps
        if "timestamp" in columns:
            timestamps = table.column("timestamp").to_numpy().astype(np.float64)
        elif "index" in columns:
            indices = table.column("index").to_numpy().astype(np.float64)
            timestamps = indices / self._fps

        # v2: flattened state columns (observation.state_0, ...)
        state_cols = sorted(
            [c for c in columns if c.startswith("observation.state")]
        )
        if state_cols:
            state_arrays = [table.column(c).to_numpy() for c in state_cols]
            observations["state"] = (
                np.column_stack(state_arrays)
                if len(state_arrays) > 1
                else state_arrays[0].reshape(-1, 1)
            )

        return Episode(
            episode_id=episode_id,
            observations=observations,
            actions=actions,
            timestamps=timestamps,
            metadata=self._build_metadata(ep_meta),
        )

    def _find_v2_parquet(self, ep_index: int) -> str | None:
        """Locate per-episode parquet (v2 layout)."""
        filename = f"episode_{ep_index:06d}.parquet"

        flat = self._join("data", filename)
        if self._fs.exists(flat):
            return flat

        chunk_idx = ep_index // 1000
        chunked = self._join("data", f"chunk-{chunk_idx:03d}", filename)
        if self._fs.exists(chunked):
            return chunked

        return None

    # -- Shared helpers -------------------------------------------------------

    def _build_metadata(self, ep_meta: dict) -> dict[str, Any]:
        tasks = ep_meta.get("tasks", [])
        task_label = ""
        if tasks:
            first = tasks[0] if isinstance(tasks, list) else tasks
            if isinstance(first, str):
                # v3: tasks field contains task names directly
                task_label = first
            else:
                # v2: tasks field contains task indices
                task_label = self._task_map.get(int(first), "")

        version = "lerobot_v3" if self._is_v3 else "lerobot_v2"

        return {
            "fps": self._fps,
            "task_label": task_label,
            "length": ep_meta.get("length", 0),
            "episode_index": ep_meta.get("episode_index", 0),
            "source_format": version,
            "robot_type": self._info.get("robot_type", ""),
        }

    @property
    def fps(self) -> float:
        return self._fps

    @property
    def info(self) -> dict[str, Any]:
        return dict(self._info)

    @property
    def version(self) -> str:
        return "v3" if self._is_v3 else "v2"
