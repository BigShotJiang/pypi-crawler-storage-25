"""Shared embodiment profile registry.

Mirrors the types defined in the Rust ``common`` crate
(``crates/common/src/embodiment.rs``) and reads the same YAML files that Rust
consumes via ``include_str!``. Those files live at
``traceplane/schemas/embodiments/`` in the repo and are bundled into the
installed wheel under ``traceplane/embodiments/data/``.

Public API:
    - ``get_profile(id)`` — load one built-in profile
    - ``list_profiles()`` — list built-in profile IDs
    - ``load_profile_from_file(path)`` — load an arbitrary profile YAML
    - ``EmbodimentProfile``, ``JointGroup``, ``JointDef``, ``JointLimits``,
      ``MorphologyType``, ``JointType``
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

import yaml


class MorphologyType(str, Enum):
    MANIPULATION_ONLY = "manipulation_only"
    LOCO_MANIPULATION = "loco_manipulation"
    LOCOMOTION_ONLY = "locomotion_only"
    MOBILE = "mobile"
    CUSTOM = "custom"


class JointType(str, Enum):
    REVOLUTE = "revolute"
    PRISMATIC = "prismatic"
    CONTINUOUS = "continuous"
    FIXED = "fixed"


@dataclass
class JointLimits:
    lower: float
    upper: float
    max_velocity: float | None = None
    max_effort: float | None = None

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> JointLimits:
        return cls(
            lower=float(d["lower"]),
            upper=float(d["upper"]),
            max_velocity=_opt_float(d.get("max_velocity")),
            max_effort=_opt_float(d.get("max_effort")),
        )


@dataclass
class JointDef:
    name: str
    joint_type: JointType
    action_index: int
    state_index: int | None = None
    limits: JointLimits | None = None

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> JointDef:
        state_idx_raw = d.get("state_index")
        limits_raw = d.get("limits")
        return cls(
            name=str(d["name"]),
            joint_type=JointType(d["joint_type"]),
            action_index=int(d["action_index"]),
            state_index=int(state_idx_raw) if state_idx_raw is not None else None,
            limits=JointLimits.from_dict(limits_raw) if limits_raw is not None else None,
        )


@dataclass
class JointGroup:
    name: str
    joints: list[JointDef] = field(default_factory=list)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> JointGroup:
        return cls(
            name=str(d["name"]),
            joints=[JointDef.from_dict(j) for j in d.get("joints", [])],
        )

    def dof(self) -> int:
        return sum(1 for j in self.joints if j.joint_type != JointType.FIXED)

    def action_indices(self) -> list[int]:
        return [j.action_index for j in self.joints if j.joint_type != JointType.FIXED]


@dataclass
class EmbodimentProfile:
    id: str
    display_name: str
    morphology: MorphologyType
    action_dim: int
    state_dim: int
    groups: list[JointGroup] = field(default_factory=list)
    description: str | None = None
    model_url: str | None = None
    usd_path: str | None = None

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> EmbodimentProfile:
        return cls(
            id=str(d["id"]),
            display_name=str(d["display_name"]),
            morphology=MorphologyType(d["morphology"]),
            action_dim=int(d["action_dim"]),
            state_dim=int(d["state_dim"]),
            groups=[JointGroup.from_dict(g) for g in d.get("groups", [])],
            description=_opt_str(d.get("description")),
            model_url=_opt_str(d.get("model_url")),
            usd_path=_opt_str(d.get("usd_path")),
        )

    def total_dof(self) -> int:
        return sum(g.dof() for g in self.groups)

    def group(self, name: str) -> JointGroup | None:
        """Case-insensitive joint group lookup."""
        lower = name.lower()
        return next((g for g in self.groups if g.name.lower() == lower), None)

    def group_names(self) -> list[str]:
        return [g.name for g in self.groups]

    def group_action_indices(self, group_name: str) -> list[int] | None:
        g = self.group(group_name)
        return None if g is None else g.action_indices()


# --- Registry -------------------------------------------------------------

_PRESET_IDS: tuple[str, ...] = (
    "franka_panda",
    "aloha_v2",
    "unitree_g1",
    "unitree_h1",
    "ur5e",
    "kuka_iiwa",
    "xarm7",
    "stretch3",
)


def _opt_float(v: Any) -> float | None:
    return None if v is None else float(v)


def _opt_str(v: Any) -> str | None:
    return None if v is None else str(v)


def _find_schemas_dir() -> Path:
    """Locate the embodiment YAML directory.

    Supports two layouts:
    1. Installed wheel: bundled alongside this package as ``data/``.
    2. Editable / dev install: walk up to find the repo-root
       ``traceplane/schemas/embodiments/`` directory.
    """
    bundled = Path(__file__).parent / "data"
    if bundled.is_dir():
        return bundled
    cur = Path(__file__).resolve()
    for _ in range(10):
        cur = cur.parent
        for candidate in (
            cur / "schemas" / "embodiments",
            cur / "traceplane" / "schemas" / "embodiments",
        ):
            if candidate.is_dir():
                return candidate
    raise FileNotFoundError(
        "Could not find embodiment YAML schemas — expected either a bundled "
        "`data/` directory inside the traceplane.embodiments package or a "
        "repo-root `traceplane/schemas/embodiments/` directory."
    )


def load_profile_from_file(path: Path | str) -> EmbodimentProfile:
    """Load an embodiment profile from an arbitrary YAML file."""
    with open(path, "r") as f:
        data = yaml.safe_load(f)
    return EmbodimentProfile.from_dict(data)


def get_profile(profile_id: str) -> EmbodimentProfile:
    """Load a built-in embodiment profile by ID (e.g. ``"franka_panda"``)."""
    schemas_dir = _find_schemas_dir()
    path = schemas_dir / f"{profile_id}.yaml"
    if not path.exists():
        raise KeyError(f"unknown embodiment profile: {profile_id!r}")
    return load_profile_from_file(path)


def list_profiles() -> list[str]:
    """List built-in embodiment profile IDs in canonical order."""
    return list(_PRESET_IDS)


__all__ = [
    "EmbodimentProfile",
    "JointDef",
    "JointGroup",
    "JointLimits",
    "JointType",
    "MorphologyType",
    "get_profile",
    "list_profiles",
    "load_profile_from_file",
]
