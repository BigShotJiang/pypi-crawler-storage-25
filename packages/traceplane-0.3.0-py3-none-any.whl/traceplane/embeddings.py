"""Episode embedding computation for similarity search.

Computes per-episode feature vectors and writes them to Parquet for
use with the DataFusion ``vec_cosine_sim`` UDF.

Two strategies:
    - **Trajectory features** (always available): statistical aggregates
      of observation.state and action vectors per episode.
    - **Text embeddings** (optional, requires ``sentence-transformers``):
      encodes task_label strings with a pretrained language model.
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq

from traceplane.dataset import Episode
from traceplane.lerobot_reader import LeRobotReader


def compute_trajectory_embedding(episode: Episode) -> np.ndarray:
    """Compute a feature vector from an episode's state and action statistics.

    Concatenates [mean, std, min, max] per dimension for both
    observation.state and action, then L2-normalises.

    Returns:
        1-D float32 array.
    """
    parts: list[np.ndarray] = []

    # State features
    state = episode.observations.get("state")
    if state is not None and state.ndim == 2 and state.shape[0] > 0:
        parts.extend(_stat_features(state))

    # Action features
    if episode.actions.ndim == 2 and episode.actions.shape[0] > 0:
        parts.extend(_stat_features(episode.actions))

    if not parts:
        # Fallback: zero vector
        return np.zeros(1, dtype=np.float32)

    vec = np.concatenate(parts).astype(np.float32)

    # L2 normalise
    norm = np.linalg.norm(vec)
    if norm > 1e-8:
        vec /= norm

    return vec


def _stat_features(arr: np.ndarray) -> list[np.ndarray]:
    """Compute [mean, std, min, max] per dimension."""
    return [
        arr.mean(axis=0),
        arr.std(axis=0),
        arr.min(axis=0),
        arr.max(axis=0),
    ]


def compute_text_embeddings(
    labels: list[str],
    model_name: str = "sentence-transformers/all-MiniLM-L6-v2",
) -> np.ndarray:
    """Encode text labels with a sentence-transformer model.

    Returns:
        (N, D) float32 array of embeddings.
    """
    try:
        from sentence_transformers import SentenceTransformer
    except ImportError:
        raise ImportError(
            "sentence-transformers is required for text embeddings. "
            "Install with: pip install traceplane[embeddings]"
        )
    model = SentenceTransformer(model_name)
    embeddings = model.encode(labels, show_progress_bar=False, normalize_embeddings=True)
    return np.asarray(embeddings, dtype=np.float32)


def compute_embeddings(
    dataset_path: str,
    output_dir: str | None = None,
    include_text: bool = False,
    episode_indices: list[int] | None = None,
    storage_options: dict[str, Any] | None = None,
) -> str:
    """Compute episode embeddings and write to Parquet.

    Args:
        dataset_path: Path to a LeRobot dataset.
        output_dir: Output directory. Defaults to ``{dataset_path}/embeddings``.
        include_text: Also compute text embeddings from task labels.
        episode_indices: Subset of episodes. None = all.
        storage_options: fsspec options for remote datasets.

    Returns:
        Path to the written Parquet file.
    """
    reader = LeRobotReader(
        dataset_path,
        storage_options=storage_options,
        episode_indices=episode_indices,
    )

    n = len(reader)
    if n == 0:
        raise ValueError("Dataset has no episodes")

    print(f"Computing embeddings for {n} episodes...", file=sys.stderr)

    indices: list[int] = []
    labels: list[str] = []
    traj_embeddings: list[np.ndarray] = []

    for i in range(n):
        ep = reader[i]
        traj_emb = compute_trajectory_embedding(ep)
        traj_embeddings.append(traj_emb)

        # Extract episode index from metadata or ID
        ep_idx = ep.metadata.get("episode_index", i)
        if isinstance(ep_idx, str):
            try:
                ep_idx = int(ep_idx.split("_")[-1])
            except (ValueError, IndexError):
                ep_idx = i
        indices.append(int(ep_idx))
        labels.append(ep.metadata.get("task_label", ""))

        if (i + 1) % 50 == 0 or i == n - 1:
            print(f"  {i + 1}/{n}", file=sys.stderr)

    # Build arrow arrays
    traj_dim = traj_embeddings[0].shape[0]
    arrow_traj = pa.list_(pa.float32())

    columns: dict[str, Any] = {
        "episode_index": pa.array(indices, type=pa.int64()),
        "task_label": pa.array(labels, type=pa.utf8()),
        "trajectory_embedding": pa.array(
            [emb.tolist() for emb in traj_embeddings],
            type=arrow_traj,
        ),
    }

    # Optional text embeddings
    if include_text:
        unique_labels = list(set(labels))
        print(f"Computing text embeddings for {len(unique_labels)} unique labels...", file=sys.stderr)
        text_embs = compute_text_embeddings(unique_labels)
        label_to_emb = {lbl: text_embs[i] for i, lbl in enumerate(unique_labels)}
        text_vecs = [label_to_emb[lbl].tolist() for lbl in labels]
        columns["text_embedding"] = pa.array(
            text_vecs,
            type=pa.list_(pa.float32()),
        )

    table = pa.table(columns)

    # Write
    if output_dir is None:
        output_dir = os.path.join(dataset_path, "embeddings")
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, "episode_embeddings.parquet")
    pq.write_table(table, output_path)

    print(f"Written {n} embeddings ({traj_dim}-dim) to {output_path}", file=sys.stderr)
    return output_path


def main(argv: list[str] | None = None) -> None:
    """CLI entry point for embedding computation."""
    parser = argparse.ArgumentParser(
        description="Compute episode embeddings for similarity search",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("dataset_path", help="Path to LeRobot dataset")
    parser.add_argument("--output-dir", help="Output directory (default: {dataset_path}/embeddings)")
    parser.add_argument("--include-text", action="store_true", help="Compute text embeddings (requires sentence-transformers)")
    parser.add_argument("--episodes", type=int, nargs="+", help="Specific episode indices")

    args = parser.parse_args(argv)
    path = compute_embeddings(
        args.dataset_path,
        output_dir=args.output_dir,
        include_text=args.include_text,
        episode_indices=args.episodes,
    )
    print(path)


if __name__ == "__main__":
    main()
