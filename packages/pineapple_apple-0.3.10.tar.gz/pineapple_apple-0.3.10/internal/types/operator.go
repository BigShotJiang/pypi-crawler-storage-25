package types

import (
	"context"
	"fmt"
	"log"
)

// OperatorType represents the semantic type of an operator.
// It determines allowed OperatorOutput methods, DAG dependency rules,
// and Python DSL naming conventions.
type OperatorType string

const (
	OpTypeRecall    OperatorType = "Recall"
	OpTypeTransform OperatorType = "Transform"
	OpTypeFilter    OperatorType = "Filter"
	OpTypeMerge     OperatorType = "Merge"
	OpTypeReorder   OperatorType = "Reorder"
	OpTypeObserve   OperatorType = "Observe"
)

// validOperatorTypes is the set of allowed OperatorType values.
var validOperatorTypes = map[OperatorType]struct{}{
	OpTypeRecall:    {},
	OpTypeTransform: {},
	OpTypeFilter:    {},
	OpTypeMerge:     {},
	OpTypeReorder:   {},
	OpTypeObserve:   {},
}

// IsValidOperatorType returns true if t is a recognised operator type.
func IsValidOperatorType(t OperatorType) bool {
	_, ok := validOperatorTypes[t]
	return ok
}

// IsBarrier returns true if the operator type uses barrier DAG semantics.
func (t OperatorType) IsBarrier() bool {
	return t == OpTypeFilter || t == OpTypeMerge || t == OpTypeReorder
}

// ValidateOutput checks that the OperatorOutput only used methods allowed for
// this operator type. Returns an error describing the violation, or nil.
func (t OperatorType) ValidateOutput(out *OperatorOutput) error {
	hasCW := len(out.commonWrites) > 0
	hasIW := len(out.itemWrites) > 0
	hasAI := len(out.addedItems) > 0
	hasRI := len(out.removedItems) > 0
	hasIO := out.itemOrder != nil

	var violations []string

	switch t {
	case OpTypeRecall:
		if hasCW {
			violations = append(violations, "SetCommon")
		}
		if hasIW {
			violations = append(violations, "SetItem")
		}
		if hasRI {
			violations = append(violations, "RemoveItem")
		}
		if hasIO {
			violations = append(violations, "SetItemOrder")
		}
	case OpTypeTransform:
		if hasAI {
			violations = append(violations, "AddItem")
		}
		if hasRI {
			violations = append(violations, "RemoveItem")
		}
		if hasIO {
			violations = append(violations, "SetItemOrder")
		}
	case OpTypeFilter:
		if hasCW {
			violations = append(violations, "SetCommon")
		}
		if hasIW {
			violations = append(violations, "SetItem")
		}
		if hasAI {
			violations = append(violations, "AddItem")
		}
		if hasIO {
			violations = append(violations, "SetItemOrder")
		}
	case OpTypeMerge:
		if hasCW {
			violations = append(violations, "SetCommon")
		}
		if hasAI {
			violations = append(violations, "AddItem")
		}
		if hasIO {
			violations = append(violations, "SetItemOrder")
		}
	case OpTypeReorder:
		if hasCW {
			violations = append(violations, "SetCommon")
		}
		if hasIW {
			violations = append(violations, "SetItem")
		}
		if hasAI {
			violations = append(violations, "AddItem")
		}
		if hasRI {
			violations = append(violations, "RemoveItem")
		}
	case OpTypeObserve:
		if hasCW {
			violations = append(violations, "SetCommon")
		}
		if hasIW {
			violations = append(violations, "SetItem")
		}
		if hasAI {
			violations = append(violations, "AddItem")
		}
		if hasRI {
			violations = append(violations, "RemoveItem")
		}
		if hasIO {
			violations = append(violations, "SetItemOrder")
		}
	}

	if len(violations) > 0 {
		return fmt.Errorf("operator type %s must not call %v", t, violations)
	}
	return nil
}

// Operator is the interface all operators must implement.
type Operator interface {
	Init(params map[string]any) error
	Execute(ctx context.Context, input *OperatorInput, output *OperatorOutput) error
}

// MetadataAware is an optional interface for operators that need access to
// their declared input/output field names from $metadata. The engine calls
// SetMetadata after Init for operators that implement this interface.
type MetadataAware interface {
	SetMetadata(commonInput, commonOutput, itemInput, itemOutput []string)
}

// MetadataHolder stores the four DSL-declared field-name slices and provides
// a default SetMetadata implementation. Embed it in an operator struct to
// satisfy MetadataAware automatically:
//
//	type SortOp struct {
//	    pine.MetadataHolder
//	    ascending bool
//	}
//
// The operator can then access o.CommonInput, o.ItemInput, etc. directly.
type MetadataHolder struct {
	CommonInput  []string
	CommonOutput []string
	ItemInput    []string
	ItemOutput   []string
}

// SetMetadata implements MetadataAware.
func (m *MetadataHolder) SetMetadata(commonInput, commonOutput, itemInput, itemOutput []string) {
	m.CommonInput = commonInput
	m.CommonOutput = commonOutput
	m.ItemInput = itemInput
	m.ItemOutput = itemOutput
}

// DebugAware is an optional interface for operators that need access to
// their debug flag and operator name. The engine calls SetDebugInfo after
// Init for operators that implement this interface.
type DebugAware interface {
	SetDebugInfo(operatorName string, debug bool)
}

// DebugHolder stores the debug flag and operator name, and provides
// IsDebug / DebugLog helpers. Embed it in an operator struct to satisfy
// DebugAware automatically:
//
//	type MyOp struct {
//	    pine.MetadataHolder
//	    pine.DebugHolder
//	}
type DebugHolder struct {
	operatorName string
	debug        bool
}

// SetDebugInfo implements DebugAware.
func (d *DebugHolder) SetDebugInfo(operatorName string, debug bool) {
	d.operatorName = operatorName
	d.debug = debug
}

// IsDebug returns whether this operator has debug mode enabled.
func (d *DebugHolder) IsDebug() bool {
	return d.debug
}

// DebugLog prints a log line prefixed with the operator name.
// Only outputs when debug is enabled; silent otherwise.
func (d *DebugHolder) DebugLog(format string, args ...any) {
	if !d.debug {
		return
	}
	msg := fmt.Sprintf(format, args...)
	log.Printf("[pine:debug] operator=%q %s", d.operatorName, msg)
}

// ParamSpec describes a single operator parameter for schema validation.
type ParamSpec struct {
	Type        string // "string", "int64", "float64", "bool", "any"
	Required    bool
	Default     any
	Description string // Human-readable description (required by Register).
}

// OperatorSchema describes an operator type for registration and validation.
type OperatorSchema struct {
	Name        string
	Type        OperatorType // e.g. OpTypeRecall, OpTypeTransform (required by Register).
	Description string       // One-line summary of the operator (required by Register).
	Params      map[string]ParamSpec
}

// ResourceSchema describes a resource type for registration, codegen,
// and documentation generation. Symmetric with OperatorSchema.
type ResourceSchema struct {
	Name            string               // Resource type name (e.g. "feed_data").
	Description     string               // One-line summary.
	DefaultInterval int                  // Default refresh interval in seconds; 0 → 10min.
	Params          map[string]ParamSpec // Reuses operator ParamSpec.
}
