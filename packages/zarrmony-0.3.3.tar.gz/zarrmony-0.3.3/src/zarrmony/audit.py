"""Audit-trail metadata for converted Zarrs.

Every conversion writes ``attrs["zarrmony"]`` at the root of the output store,
recording: zarrmony version, the winning reader plugin (name, distribution,
source, version, match score), the input file's path / size / mtime / optional
SHA256, the conversion config the user passed, started/finished timestamps,
per-scene records returned by ``write_scene``, and any extractor-failure
warnings.

Stored as a top-level ``attrs.zarrmony`` (not under ``attrs.ome``) to keep the
spec-defined namespace clean. ``audit_schema_version`` is bumped whenever this
record's shape changes.
"""

from __future__ import annotations

import hashlib
from datetime import datetime
from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as pkg_version
from pathlib import Path
from typing import Any

from zarrmony import __version__
from zarrmony._storage import open_root_group
from zarrmony.readers.plugin import ReaderPlugin

AUDIT_SCHEMA_VERSION = 3


def _file_forensics(path: str | Path, *, checksum: bool = False) -> dict[str, Any]:
    p = Path(path)
    info: dict[str, Any] = {
        "path": str(p.resolve()),
        "exists": p.exists(),
    }
    if p.exists():
        st = p.stat()
        info["size_bytes"] = st.st_size
        info["mtime_iso"] = datetime.fromtimestamp(st.st_mtime).astimezone().isoformat()
        if checksum and p.is_file():
            h = hashlib.sha256()
            with open(p, "rb") as f:
                for chunk in iter(lambda: f.read(2**20), b""):
                    h.update(chunk)
            info["sha256"] = h.hexdigest()
    return info


def _try_pkg_version(pkg: str) -> str | None:
    try:
        return pkg_version(pkg)
    except PackageNotFoundError:
        return None


def _reader_plugin_record(
    plugin: ReaderPlugin | None,
    match_score: int | None,
    distribution: str | None,
) -> dict[str, Any] | None:
    if plugin is None:
        return None
    # Caller-supplied distribution wins (lets the catch-all default plugin
    # surface the actual bioio sub-package, e.g. ``bioio-ome-tiff``).
    actual_distribution = distribution if distribution is not None else plugin.distribution
    return {
        "name": plugin.name,
        "version": _try_pkg_version(actual_distribution) if actual_distribution else None,
        "source": plugin.source,
        "distribution": actual_distribution,
        "match_score": match_score,
    }


def build_audit_record(
    *,
    input_path: str | Path,
    reader_plugin: ReaderPlugin | None,
    match_score: int | None = None,
    distribution: str | None = None,
    config: dict[str, Any],
    started_at: datetime,
    finished_at: datetime,
    layout: str | None = None,
    per_scene: list[dict[str, Any]] | None = None,
    fields: list[dict[str, Any]] | None = None,
    plate: dict[str, Any] | None = None,
    metadata_warnings: list[dict[str, Any]] | None = None,
    checksum: bool = False,
) -> dict[str, Any]:
    """Assemble the audit-record dict written to ``attrs.zarrmony``.

    ``distribution`` overrides ``reader_plugin.distribution`` for the audit
    record only; pass it when the plugin's static ``distribution`` field is
    ``None`` (e.g. the catch-all default plugin) and the caller has dynamically
    resolved the actual underlying bioio sub-package.

    Per ADR-0004, plate-layout audits use ``fields`` + ``plate`` (and omit
    ``per_scene``); flat-layout audits keep using ``per_scene``. The top-level
    ``layout`` key is the discriminator consumers switch on.
    """
    record: dict[str, Any] = {
        "audit_schema_version": AUDIT_SCHEMA_VERSION,
        "version": __version__,
        "layout": layout,
        "reader_plugin": _reader_plugin_record(reader_plugin, match_score, distribution),
        "input": _file_forensics(input_path, checksum=checksum),
        "config": config,
        "conversion_started_at": started_at.isoformat(),
        "conversion_finished_at": finished_at.isoformat(),
        "metadata_warnings": metadata_warnings or [],
    }
    if fields is not None or plate is not None:
        record["fields"] = fields or []
        record["plate"] = plate or {}
    else:
        record["per_scene"] = per_scene or []
    return record


def write_audit_record(store_path: str | Path, audit: dict[str, Any]) -> None:
    """Set ``root.attrs["zarrmony"]`` to the audit dict.

    Lives outside ``attrs.ome`` to avoid shadowing spec-defined OME content.
    """
    root = open_root_group(store_path, mode="a")
    root.attrs["zarrmony"] = audit
