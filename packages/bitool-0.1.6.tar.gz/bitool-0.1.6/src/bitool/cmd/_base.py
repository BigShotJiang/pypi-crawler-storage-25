from __future__ import annotations

from abc import abstractmethod
from dataclasses import dataclass, field
from typing import Callable

from bitool.cmd._condition import Condition
from bitool.core import logger


@dataclass
class BaseCommand:
    """命令基类.

    提供命令的基础功能,包括条件检查、依赖管理和执行控制.
    所有自定义命令应继承此类并实现 run 方法.

    Attributes:
        name: 命令名称,用于标识和日志输出.
        description: 命令描述信息.
        allow_conditions: 允许条件列表, 所有条件满足时命令才会执行.
        forbid_conditions: 禁止条件列表, 任一条件满足时命令不会执行.
        dependencies: 依赖的命令名称列表.
    """

    name: str = "base"
    description: str = "base command"
    allow_conditions: list[Condition | tuple[Callable[[], bool], str]] = field(
        default_factory=list
    )
    forbid_conditions: list[Condition | tuple[Callable[[], bool], str]] = field(
        default_factory=list
    )
    dependencies: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        """数据类初始化后的处理.

        将传入的 tuple 或 Condition 对象统一转换为 Condition 对象.
        """
        # 将传入的 tuple 或 Condition 对象统一转换为 Condition 对象
        self.allow_conditions = [Condition.from_data(c) for c in self.allow_conditions]
        self.forbid_conditions = [
            Condition.from_data(c) for c in self.forbid_conditions
        ]

    @abstractmethod
    def run(self) -> bool:
        """运行命令.

        Returns:
            命令执行是否成功.

        Raises:
            NotImplementedError: 子类必须实现此方法.
        """
        raise NotImplementedError

    def validate_and_run(self) -> bool:
        """检查条件并运行命令.

        Returns:
            命令执行是否成功.如果条件不满足则返回 False.
        """
        if self.validate():
            return self.run()

        return False

    def validate(self) -> bool:
        """检查命令是否可以运行.

        验证允许条件和禁止条件:
        - 所有允许条件必须满足
        - 任何禁止条件都不能满足

        Returns:
            是否满足执行条件.
        """
        allow_results = [
            (c.func(), c.reason)
            for c in self.allow_conditions
            if isinstance(c, Condition)
        ]
        forbid_results = [
            (c.func(), c.reason)
            for c in self.forbid_conditions
            if isinstance(c, Condition)
        ]

        # 检查允许条件：所有条件都必须满足
        if not all(r for r, _ in allow_results):
            logger.warning(
                "命令 `%s` 条件不满足，跳过执行, 不满足项: %s",
                self.__class__.__name__,
                [reason for r, reason in allow_results if not r],
            )
            return False

        # 检查禁止条件：任何条件都不应满足
        if any(r for r, _ in forbid_results):
            logger.warning(
                "命令 `%s` 条件不满足，跳过执行, 禁止项: %s",
                self.__class__.__name__,
                [reason for r, reason in forbid_results if r],
            )
            return False

        return True
