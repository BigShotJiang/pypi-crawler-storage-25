"""JsonConfig 边界情况和原子写入测试."""

import contextlib
import json
import os
from pathlib import Path
from unittest.mock import patch

from bitool.core.config import JsonConfig


class TestJsonConfigEdgeCases:
    """测试边界情况."""

    def test_config_with_special_characters(self, tmp_path: Path) -> None:
        """测试包含特殊字符的配置."""

        class TestConfig(JsonConfig):
            NAME = "special_chars"

        config = TestConfig()

        # 设置包含特殊字符的值
        config.chinese = "中文测试"
        config.emoji = "🎉🚀"
        config.special = "!@#$%^&*()"

        # 保存配置
        config.save_to_json()

        # 验证可以正确读取
        assert config.chinese == "中文测试"
        assert config.emoji == "🎉🚀"
        assert config.special == "!@#$%^&*()"

    def test_config_directory_creation(self, tmp_path: Path) -> None:
        """测试配置目录自动创建."""
        nested_dir = tmp_path / "nested" / "dirs"

        class TestConfig(JsonConfig):
            NAME = "nested_config"
            ROOT_DIR = nested_dir

        # 实例化时应创建目录
        config = TestConfig()
        assert nested_dir.exists()

        # 配置文件应该在嵌套目录中
        expected_file = nested_dir / "nested_config.json"
        assert config._config_file == expected_file

    def test_default_name_from_class(self, tmp_path: Path) -> None:
        """测试从类名自动生成默认名称."""

        class MyCustomConfig(JsonConfig):
            pass

        config = MyCustomConfig()

        # 验证默认名称是从类名转换而来（去掉Config后缀，转为snake_case）
        assert config._default_name == "my_custom"

    def test_serialize_object_with_dict_error(self, tmp_path: Path) -> None:
        """测试序列化时__dict__访问异常的处理."""

        class BrokenDictClass:
            """一个__dict__属性访问会抛出异常的类."""

            @property
            def __dict__(self) -> None:  # type: ignore[override, return-value]
                raise AttributeError("Cannot access __dict__")

        class TestConfig(JsonConfig):
            NAME = "broken_dict"

        config = TestConfig()
        broken_obj = BrokenDictClass()

        # 测试_default_encoder处理异常的情况
        result = config._default_encoder(broken_obj)

        # 应该回退到字符串表示
        assert isinstance(result, str)

    def test_serialize_object_with_type_error_in_dict(self, tmp_path: Path) -> None:
        """测试序列化时__dict__访问抛出TypeError的处理."""

        class TypeErrorDictClass:
            """一个__dict__属性访问会抛出TypeError的类."""

            def __init__(self) -> None:
                self.value = "test"

        class TestConfig(JsonConfig):
            NAME = "type_error_dict"

        config = TestConfig()
        error_obj = TypeErrorDictClass()

        # 直接修改__dict__为不可访问的形式，测试isinstance检查失败的情况（覆盖行440）
        # 这种情况下不会抛出异常，而是isinstance检查失败，继续到行459

        # 测试_default_encoder处理对象（正常路径，覆盖行438-452）
        result = config._default_encoder(error_obj)

        # 应该返回包含类信息的字典（行448-452）
        assert isinstance(result, dict)
        # 验证字典包含期望的键值对（使用in避免类型检查错误）
        assert "__class__" in result
        assert "value" in result
        assert result["__class__"] == "TypeErrorDictClass"  # ty:ignore[invalid-argument-type]
        assert result["value"] == "test"  # ty:ignore[invalid-argument-type]

    def test_validate_circular_in_tuple(self, tmp_path: Path) -> None:
        """测试元组中的循环引用验证."""

        class TestConfig(JsonConfig):
            NAME = "circular_tuple"

        config = TestConfig()

        # 创建元组（元组本身不可变，但可以包含循环引用的列表）
        inner_list: list = []
        tpl = (inner_list,)
        inner_list.append(tpl)

        # 验证应该失败（检测到循环引用）
        assert config._validate_serializable(tpl) is False

    def test_validate_list_success(self, tmp_path: Path) -> None:
        """测试列表验证成功路径."""

        class TestConfig(JsonConfig):
            NAME = "valid_list"

        config = TestConfig()

        # 创建一个有效的列表（不触发循环引用）
        valid_list = [1, "two", 3.0, True, None]

        # 验证应该成功，覆盖列表验证的成功分支（行574）
        assert config._validate_serializable(valid_list) is True

    def test_validate_dict_success(self, tmp_path: Path) -> None:
        """测试字典验证成功路径."""

        class TestConfig(JsonConfig):
            NAME = "valid_dict"

        config = TestConfig()

        # 创建一个有效的字典（不触发循环引用）
        valid_dict = {"key1": "value1", "key2": 123}

        # 验证应该成功，覆盖字典验证的成功分支（行574）
        assert config._validate_serializable(valid_dict) is True

    def test_validate_basic_type_returns_true(self, tmp_path: Path) -> None:
        """测试基本类型验证直接返回True."""

        class TestConfig(JsonConfig):
            NAME = "basic_validate"

        config = TestConfig()

        # 基本类型应该直接返回True，覆盖行610
        assert config._validate_serializable("string") is True
        assert config._validate_serializable(123) is True
        assert config._validate_serializable(3.14) is True

    def test_validate_other_type_returns_true(self, tmp_path: Path) -> None:
        """测试其他类型验证返回True（会在编码时转换为字符串）."""

        class TestConfig(JsonConfig):
            NAME = "other_validate"

        config = TestConfig()

        # 其他类型（如自定义对象）应该返回True，覆盖行628
        # 因为_default_encoder会处理它们
        class CustomObj:
            pass

        obj = CustomObj()
        assert config._validate_serializable(obj) is True

    def test_save_to_json_os_error_with_backup(self, tmp_path: Path) -> None:
        """测试save_to_json遇到OSError时从备份恢复（覆盖行654-657）."""

        class TestConfig(JsonConfig):
            NAME = "save_oserror"

        # 首先创建正常配置和备份
        config1 = TestConfig()
        config1.test_key = "original_value"
        config1.save_to_json()

        # 验证备份文件存在且包含原始值
        backup_file = tmp_path / "save_oserror.json.bak"
        assert backup_file.exists()
        with open(backup_file, encoding="utf-8") as f:
            backup_data = json.load(f)
        assert backup_data.get("test_key") == "original_value"

        # 现在模拟save_to_json时失败（通过mock _atomic_write_config抛出OSError）
        config2 = TestConfig()
        config2.new_key = "new_value"

        # Mock原子写入失败，触发异常处理路径（行654-657）
        with patch.object(
            config2, "_atomic_write_config", side_effect=OSError("Write failed")
        ):
            # save_to_json应该捕获异常并尝试从备份恢复（行656-657）
            config2.save_to_json()

        # 验证备份文件仍然存在（恢复后应该保留）
        assert backup_file.exists()

    def test_create_backup_os_error(self, tmp_path: Path) -> None:
        """测试创建备份时的OSError处理."""

        class TestConfig(JsonConfig):
            NAME = "backup_oserror"

        config = TestConfig()
        config.test_key = "test_value"
        config.save_to_json()

        # Mock _backup_file.open 抛出 OSError（覆盖行668-669）
        config_file = tmp_path / "backup_oserror.json"
        tmp_path / "backup_oserror.json.bak"

        # 先确保配置文件存在
        assert config_file.exists()

        # Mock备份文件写入失败，但不应该抛出异常
        with patch.object(Path, "open", side_effect=OSError("Disk full")):
            # 不应该抛出异常，只是记录debug日志
            config._create_backup()

        # 验证不会因为这个错误而崩溃


class TestJsonConfigAtomicWrite:
    """测试原子写入功能."""

    def test_atomic_write_creates_temp_file(self, tmp_path: Path) -> None:
        """测试原子写入创建临时文件."""

        class TestConfig(JsonConfig):
            NAME = "atomic_write"

        config = TestConfig()
        config.test_key = "test_value"

        # 保存配置
        config.save_to_json()

        # 验证最终配置文件存在
        config_file = tmp_path / "atomic_write.json"
        assert config_file.exists()

        # 验证没有残留的临时文件
        temp_files = list(tmp_path.glob("*.tmp"))
        assert len(temp_files) == 0

    def test_atomic_write_permission_error_retry(self, tmp_path: Path) -> None:
        """测试原子写入时PermissionError的重试逻辑."""

        class TestConfig(JsonConfig):
            NAME = "atomic_retry"

        config = TestConfig()
        config.test_key = "test_value"

        # 创建一个占位配置文件并设置只读属性（Windows上模拟占用）
        config_file = tmp_path / "atomic_retry.json"
        config_file.write_text("existing content")

        # 在Windows上，我们模拟第一次删除失败，第二次成功
        call_count = [0]
        original_unlink = Path.unlink

        def mock_unlink(self_path: Path) -> None:
            call_count[0] += 1
            if call_count[0] == 1:
                # 第一次调用抛出PermissionError（模拟文件被占用）
                raise PermissionError("Access denied")
            # 第二次调用正常删除
            original_unlink(self_path)

        with patch.object(Path, "unlink", mock_unlink):
            # 保存配置，应该会在第一次失败后重试
            config.save_to_json()

        # 验证最终文件存在且包含正确的内容
        assert config_file.exists()

        with open(config_file, encoding="utf-8") as f:
            data = json.load(f)
        assert data["test_key"] == "test_value"

    def test_atomic_write_max_retries_exceeded(self, tmp_path: Path) -> None:
        """测试原子写入时达到最大重试次数（覆盖行391）."""

        class TestConfig(JsonConfig):
            NAME = "atomic_max_retry"

        config = TestConfig()
        config.test_key = "test_value"

        # 创建一个占位配置文件
        config_file = tmp_path / "atomic_max_retry.json"
        config_file.write_text("existing content")

        # Mock unlink总是失败，模拟文件一直被占用（覆盖行391的最后一次重试失败）

        def mock_unlink_always_fail(self_path: Path) -> None:
            # 总是抛出PermissionError
            raise PermissionError("Access denied - file in use")

        # 保存配置会在5次重试后失败，覆盖行391的raise语句
        with patch.object(Path, "unlink", mock_unlink_always_fail), contextlib.suppress(
            PermissionError
        ):
            config.save_to_json()

    def test_atomic_write_cleanup_on_error(self, tmp_path: Path) -> None:
        """测试原子写入错误时清理临时文件."""

        class TestConfig(JsonConfig):
            NAME = "atomic_cleanup"

        config = TestConfig()
        config.test_key = "test_value"

        # Mock os.replace 总是失败，触发异常处理路径（行397-410, 414-415）
        original_replace = os.replace
        replace_call_count = [0]

        def mock_replace(src: str, dst: str) -> None:
            replace_call_count[0] += 1
            # 总是抛出OSError模拟替换失败
            raise OSError("Replace failed")

        with patch("os.replace", mock_replace):
            # 保存配置会失败，但应该清理临时文件
            try:
                config.save_to_json()
            except OSError:
                pass  # 预期会失败
            finally:
                # 恢复原始函数
                os.replace = original_replace  # type: ignore[method-assign]

        # 验证没有残留的临时文件（应该被清理了）
        temp_files = list(tmp_path.glob("*.tmp"))
        assert len(temp_files) == 0, f"发现残留临时文件: {temp_files}"
