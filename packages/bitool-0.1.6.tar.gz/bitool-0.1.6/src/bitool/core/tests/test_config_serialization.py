"""JsonConfig 错误处理和序列化测试."""

import json
from decimal import Decimal
from pathlib import Path
from typing import Any

from bitool.core.config import JsonConfig


class TestJsonConfigErrorHandling:
    """测试错误处理路径."""

    def test_load_null_json(self, tmp_path: Path) -> None:
        """测试加载null值的JSON文件."""
        config_file = tmp_path / "null_test.json"
        with open(config_file, "w", encoding="utf-8") as f:
            f.write("null")

        class TestConfig(JsonConfig):
            NAME = "null_test"

        config = TestConfig()
        # 应该忽略null值，使用默认值
        assert config.attrs == {"NAME": "null_test"}

    def test_load_invalid_json_format(self, tmp_path: Path) -> None:
        """测试加载非dict类型的JSON."""
        config_file = tmp_path / "invalid_format.json"
        with open(config_file, "w", encoding="utf-8") as f:
            json.dump([1, 2, 3], f)  # 列表而非字典

        class TestConfig(JsonConfig):
            NAME = "invalid_format"

        config = TestConfig()
        # 应该忽略无效格式，使用默认值
        assert config.attrs == {"NAME": "invalid_format"}

    def test_load_os_error(self, tmp_path: Path) -> None:
        """测试读取文件时的OSError."""
        from unittest.mock import patch

        class TestConfig(JsonConfig):
            NAME = "os_error_test"

        config = TestConfig()

        # Mock open 方法抛出 OSError（需要在文件存在时触发）
        config_file = tmp_path / "os_error_test.json"
        config_file.write_text('{"key": "value"}')

        with patch.object(Path, "open", side_effect=OSError("Permission denied")):
            # 不应该抛出异常
            config.load_from_json()

        # 由于OSError，应该使用默认值（文件配置未加载）
        assert config.attrs == {"NAME": "os_error_test"}

    def test_restore_from_invalid_backup(self, tmp_path: Path) -> None:
        """测试从无效的备份文件恢复."""

        class TestConfig(JsonConfig):
            NAME = "invalid_backup"

        config = TestConfig()
        config.test_key = "test_value"
        config.save_to_json()

        # 破坏备份文件
        backup_file = tmp_path / "invalid_backup.json.bak"
        with open(backup_file, "w", encoding="utf-8") as f:
            f.write("invalid backup{{{")

        # 破坏配置文件
        config_file = tmp_path / "invalid_backup.json"
        with open(config_file, "w", encoding="utf-8") as f:
            f.write("invalid config{{{")

        # 重新加载，应该能处理备份也无效的情况
        config2 = TestConfig()
        # 不会抛出异常，但数据可能丢失
        assert hasattr(config2, "_file_attrs")

    def test_serialize_custom_object(self, tmp_path: Path) -> None:
        """测试自定义对象序列化."""

        class CustomClass:
            def __init__(self) -> None:
                self.name = "test"
                self.value = 123
                self._private = "hidden"

        class TestConfig(JsonConfig):
            NAME = "custom_obj"

        config = TestConfig()
        config.custom = CustomClass()

        # 保存配置
        config.save_to_json()

        # 验证文件可以正常读取
        config_file = tmp_path / "custom_obj.json"
        assert config_file.exists()

        with open(config_file, encoding="utf-8") as f:
            data = json.load(f)

        # 验证自定义对象被序列化
        assert data["custom"]["__class__"] == "CustomClass"
        assert data["custom"]["name"] == "test"
        assert data["custom"]["value"] == 123
        # 私有属性不应该被序列化
        assert "_private" not in data["custom"]

    def test_serialize_internal_class(self, tmp_path: Path) -> None:
        """测试内部类（以_开头）序列化."""

        class _InternalClass:
            def __init__(self) -> None:
                self.value = "internal"

        class TestConfig(JsonConfig):
            NAME = "internal_class"

        config = TestConfig()
        config.internal = _InternalClass()

        # 保存配置
        config.save_to_json()

        # 验证文件可以正常读取
        config_file = tmp_path / "internal_class.json"
        with open(config_file, encoding="utf-8") as f:
            data = json.load(f)

        # 内部类应该被转换为字符串
        assert isinstance(data["internal"], str)

    def test_serialize_type_object(self, tmp_path: Path) -> None:
        """测试type对象序列化."""

        class TestConfig(JsonConfig):
            NAME = "type_obj"

        config = TestConfig()

        # type对象是callable，会被_filter_serializable_attrs过滤掉
        # 直接测试_default_encoder方法
        encoded = config._default_encoder(str)

        # type对象应该被转换为字符串
        assert isinstance(encoded, str)
        assert "str" in encoded or "type" in encoded.lower()

    def test_serialize_path_object(self, tmp_path: Path) -> None:
        """测试Path对象序列化."""

        class TestConfig(JsonConfig):
            NAME = "path_obj"

        config = TestConfig()
        test_path = Path("/tmp/test")
        config._attrs["path_val"] = test_path  # ty:ignore[invalid-assignment]  # 直接设置避免被过滤

        # 保存配置
        config.save_to_json()

        config_file = tmp_path / "path_obj.json"
        with open(config_file, encoding="utf-8") as f:
            data = json.load(f)

        # Path应该被转换为字符串（跨平台兼容）
        assert "path_val" in data
        # Windows上会是 \tmp\test，Linux上是 /tmp/test
        assert data["path_val"] in ["/tmp/test", "\\tmp\\test", str(test_path)]


class TestJsonConfigCircularReference:
    """测试配置的序列化功能."""

    def test_serialize_complex_types(self, tmp_path: Path) -> None:
        """测试复杂类型的序列化."""

        class TestConfig(JsonConfig):
            NAME = "serialize_complex"

        config = TestConfig()

        # 设置复杂类型
        config.decimal_value = Decimal("123.456")
        config.complex_value = complex(1, 2)
        config.set_value = {1, 2, 3}
        config.bytes_value = b"test bytes"

        # 保存配置
        config.save_to_json()

        # 验证文件可以正常读取
        config_file = tmp_path / "serialize_complex.json"
        assert config_file.exists()

        with open(config_file, encoding="utf-8") as f:
            data = json.load(f)

        # 验证复杂类型被正确序列化
        assert data["decimal_value"] == 123.456
        assert data["complex_value"]["__complex__"] is True
        assert data["complex_value"]["real"] == 1.0
        assert data["complex_value"]["imag"] == 2.0
        assert set(data["set_value"]) == {1, 2, 3}
        assert data["bytes_value"] == "test bytes"

    def test_serialize_circular_reference(self, tmp_path: Path) -> None:
        """测试循环引用的处理."""

        class TestConfig(JsonConfig):
            NAME = "circular_ref"

        config = TestConfig()

        # 创建循环引用
        data: dict[str, Any] = {"key": "value"}
        data["self_ref"] = data  # 循环引用

        config.circular_data = data

        # 保存配置不应抛出异常
        config.save_to_json()

        # 验证文件存在
        config_file = tmp_path / "circular_ref.json"
        assert config_file.exists()
