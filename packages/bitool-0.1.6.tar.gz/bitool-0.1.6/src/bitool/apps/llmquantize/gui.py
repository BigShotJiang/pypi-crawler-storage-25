"""GGUF量化转换工具入口."""

from __future__ import annotations

import sys

from PySide2.QtWidgets import QApplication

from bitool.core import logger
from bitool.utils import execute

from .llmquantize import LLMQuantize


def main() -> None:
    """主程序入口."""
    app = QApplication(sys.argv)

    # 检查是否安装了 llama.cpp
    try:
        execute(["llama-quantize", "--help"])
    except FileNotFoundError:
        logger.error("错误:未找到 llama-quantize 工具")
        logger.error("请确保已编译 llama.cpp 并将 quantize 工具放在 llama.cpp/目录下")
        sys.exit(1)

    window = LLMQuantize()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
