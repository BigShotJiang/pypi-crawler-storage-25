# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'llmchat.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class Ui_LLMChat(object):
    def setupUi(self, LLMChat):
        if not LLMChat.objectName():
            LLMChat.setObjectName(u"LLMChat")
        LLMChat.resize(448, 482)
        self.verticalLayout_2 = QVBoxLayout(LLMChat)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.groupBox = QGroupBox(LLMChat)
        self.groupBox.setObjectName(u"groupBox")
        self.horizontalLayout = QHBoxLayout(self.groupBox)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.url_label = QLabel(self.groupBox)
        self.url_label.setObjectName(u"url_label")

        self.horizontalLayout.addWidget(self.url_label)

        self.url_edit = QLineEdit(self.groupBox)
        self.url_edit.setObjectName(u"url_edit")
        self.url_edit.setMinimumSize(QSize(240, 0))

        self.horizontalLayout.addWidget(self.url_edit)

        self.test_connection_button = QPushButton(self.groupBox)
        self.test_connection_button.setObjectName(u"test_connection_button")

        self.horizontalLayout.addWidget(self.test_connection_button)


        self.verticalLayout_2.addWidget(self.groupBox)

        self.groupBox_2 = QGroupBox(LLMChat)
        self.groupBox_2.setObjectName(u"groupBox_2")
        self.horizontalLayout_6 = QHBoxLayout(self.groupBox_2)
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.label = QLabel(self.groupBox_2)
        self.label.setObjectName(u"label")

        self.horizontalLayout_2.addWidget(self.label)

        self.max_token_spin = QSpinBox(self.groupBox_2)
        self.max_token_spin.setObjectName(u"max_token_spin")
        self.max_token_spin.setMaximum(999)

        self.horizontalLayout_2.addWidget(self.max_token_spin)


        self.horizontalLayout_6.addLayout(self.horizontalLayout_2)

        self.horizontalLayout_4 = QHBoxLayout()
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.label_3 = QLabel(self.groupBox_2)
        self.label_3.setObjectName(u"label_3")

        self.horizontalLayout_4.addWidget(self.label_3)

        self.top_p_spin = QDoubleSpinBox(self.groupBox_2)
        self.top_p_spin.setObjectName(u"top_p_spin")

        self.horizontalLayout_4.addWidget(self.top_p_spin)


        self.horizontalLayout_6.addLayout(self.horizontalLayout_4)

        self.horizontalLayout_5 = QHBoxLayout()
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.label_4 = QLabel(self.groupBox_2)
        self.label_4.setObjectName(u"label_4")

        self.horizontalLayout_5.addWidget(self.label_4)

        self.top_k_spin = QDoubleSpinBox(self.groupBox_2)
        self.top_k_spin.setObjectName(u"top_k_spin")

        self.horizontalLayout_5.addWidget(self.top_k_spin)


        self.horizontalLayout_6.addLayout(self.horizontalLayout_5)

        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.label_2 = QLabel(self.groupBox_2)
        self.label_2.setObjectName(u"label_2")

        self.horizontalLayout_3.addWidget(self.label_2)

        self.temperature_spin = QDoubleSpinBox(self.groupBox_2)
        self.temperature_spin.setObjectName(u"temperature_spin")

        self.horizontalLayout_3.addWidget(self.temperature_spin)


        self.horizontalLayout_6.addLayout(self.horizontalLayout_3)


        self.verticalLayout_2.addWidget(self.groupBox_2)

        self.groupBox_4 = QGroupBox(LLMChat)
        self.groupBox_4.setObjectName(u"groupBox_4")
        self.horizontalLayout_8 = QHBoxLayout(self.groupBox_4)
        self.horizontalLayout_8.setObjectName(u"horizontalLayout_8")
        self.input_edit = QLineEdit(self.groupBox_4)
        self.input_edit.setObjectName(u"input_edit")

        self.horizontalLayout_8.addWidget(self.input_edit)

        self.send_button = QPushButton(self.groupBox_4)
        self.send_button.setObjectName(u"send_button")

        self.horizontalLayout_8.addWidget(self.send_button)

        self.stop_button = QPushButton(self.groupBox_4)
        self.stop_button.setObjectName(u"stop_button")

        self.horizontalLayout_8.addWidget(self.stop_button)


        self.verticalLayout_2.addWidget(self.groupBox_4)

        self.groupBox_3 = QGroupBox(LLMChat)
        self.groupBox_3.setObjectName(u"groupBox_3")
        self.verticalLayout = QVBoxLayout(self.groupBox_3)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.history_list = QListWidget(self.groupBox_3)
        self.history_list.setObjectName(u"history_list")

        self.verticalLayout.addWidget(self.history_list)

        self.horizontalLayout_7 = QHBoxLayout()
        self.horizontalLayout_7.setObjectName(u"horizontalLayout_7")
        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_7.addItem(self.horizontalSpacer)

        self.clear_button = QPushButton(self.groupBox_3)
        self.clear_button.setObjectName(u"clear_button")

        self.horizontalLayout_7.addWidget(self.clear_button)


        self.verticalLayout.addLayout(self.horizontalLayout_7)


        self.verticalLayout_2.addWidget(self.groupBox_3)

        self.horizontalLayout_9 = QHBoxLayout()
        self.horizontalLayout_9.setObjectName(u"horizontalLayout_9")
        self.horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_9.addItem(self.horizontalSpacer_2)

        self.status_label = QLabel(LLMChat)
        self.status_label.setObjectName(u"status_label")

        self.horizontalLayout_9.addWidget(self.status_label)


        self.verticalLayout_2.addLayout(self.horizontalLayout_9)


        self.retranslateUi(LLMChat)

        QMetaObject.connectSlotsByName(LLMChat)
    # setupUi

    def retranslateUi(self, LLMChat):
        LLMChat.setWindowTitle(QCoreApplication.translate("LLMChat", u"LLMClient", None))
        self.groupBox.setTitle(QCoreApplication.translate("LLMChat", u"\u670d\u52a1\u5668\u8bbe\u7f6e", None))
        self.url_label.setText(QCoreApplication.translate("LLMChat", u"\u670d\u52a1\u5668\u5730\u5740:", None))
        self.test_connection_button.setText(QCoreApplication.translate("LLMChat", u"\u6d4b\u8bd5\u8fde\u63a5", None))
        self.groupBox_2.setTitle(QCoreApplication.translate("LLMChat", u"\u6a21\u578b\u53c2\u6570", None))
        self.label.setText(QCoreApplication.translate("LLMChat", u"\u6700\u5927\u4ee4\u724c\u6570:", None))
        self.label_3.setText(QCoreApplication.translate("LLMChat", u"Top-P", None))
        self.label_4.setText(QCoreApplication.translate("LLMChat", u"Top-K", None))
        self.label_2.setText(QCoreApplication.translate("LLMChat", u"\u6e29\u5ea6:", None))
        self.groupBox_4.setTitle(QCoreApplication.translate("LLMChat", u"\u7528\u6237\u8f93\u5165", None))
        self.send_button.setText(QCoreApplication.translate("LLMChat", u"\u53d1\u9001", None))
        self.stop_button.setText(QCoreApplication.translate("LLMChat", u"\u505c\u6b62", None))
        self.groupBox_3.setTitle(QCoreApplication.translate("LLMChat", u"\u4f1a\u8bdd\u5386\u53f2", None))
        self.clear_button.setText(QCoreApplication.translate("LLMChat", u"\u6e05\u7a7a\u5386\u53f2", None))
        self.status_label.setText(QCoreApplication.translate("LLMChat", u"\u72b6\u6001", None))
    # retranslateUi

