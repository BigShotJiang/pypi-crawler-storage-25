"""LLM Chat client application.

Provides a graphical interface client for streaming conversations with LLM servers.
Supports real-time streaming response display, connection testing, and parameter adjustment.

Note: This module is deprecated. Use widgets.llmchat.LLMChat instead.
"""

from __future__ import annotations

import sys

from PySide2.QtWidgets import QApplication

from bitool.gui import apply_theme

from .widgets.llmchat import LLMChat


def main() -> None:
    """Application entry point."""
    app = QApplication(sys.argv)

    # Use the new LLMChat widget
    window = LLMChat()
    apply_theme(window, "high_contrast")
    window.show()

    sys.exit(app.exec_())
