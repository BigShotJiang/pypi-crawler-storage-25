"""Connect module for threads."""

from __future__ import annotations

from urllib.error import URLError
from urllib.request import Request

from PySide2.QtCore import QThread, Signal

from bitool.core import logger
from bitool.network.url import urlopen_safe, validate_url

from ..conf import conf


class ConnectionTestWorker(QThread):
    """Server connection test worker thread.

    Tests whether the LLM server's health check endpoint is accessible in background thread.

    Signals:
        result_ready: Emitted when test completes, passes (success_flag, message_text)
    """

    result_ready = Signal(bool, str)

    def __init__(self, server_url: str) -> None:
        """Initialize connection test worker thread.

        Args:
            server_url: LLM server address
        """
        super().__init__()
        self.server_url = server_url

    def run(self) -> None:
        """Execute connection test by accessing server health check endpoint.

        Attempts to connect to the server's /health endpoint with a timeout.
        Emits result_ready signal with success status and descriptive message.

        Security: Validates URL scheme before making request to prevent SSRF attacks.
        """
        try:
            # SECURITY: Validate URL scheme to prevent SSRF and local file access (CWE-22)
            # Only http/https schemes are permitted
            if not validate_url(self.server_url):
                self.result_ready.emit(False, "Invalid URL scheme: Only http/https allowed")  # noqa: FBT003
                return

            # Create Request object with validated URL (safe after validation above)
            request = Request(f"{self.server_url}/health")  # noqa: S310

            # Open URL with validated scheme (double-checked in urlopen_safe)
            with urlopen_safe(request, timeout=conf.CONNECTION_TIMEOUT) as url_response:
                if url_response.status == 200:
                    self.result_ready.emit(True, "Connection successful!")  # noqa: FBT003
                else:
                    self.result_ready.emit(False, f"Connection failed: {url_response.status}")  # noqa: FBT003
        except URLError as e:
            logger.exception(f"Connection error: {e.reason}")
            self.result_ready.emit(False, f"Connection error: {e.reason}")  # noqa: FBT003
        except (OSError, RuntimeError):
            logger.exception("Request error")
            self.result_ready.emit(False, "Request error")  # noqa: FBT003
