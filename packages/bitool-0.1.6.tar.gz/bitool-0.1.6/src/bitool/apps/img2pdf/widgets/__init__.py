"""img2pdf widgets 模块."""
