# img2pdf

将目录中的图像转换为单个 PDF 文件.

## 功能特性

- 支持多种图像格式: JPG, JPEG, PNG, GIF, BMP, WebP, TIFF, ICO
- 自动验证图像文件(扩展名和文件头)
- 可选的图像规范化处理(自动旋转和缩放)
- 批量处理以优化内存使用
- 并行转换以提高性能
- 自动处理透明度(RGBA/LA/P 模式)
- 生成优化的 PDF 文件

## 安装

```bash
pip install img2pdf
```

## 使用方法

### 命令行

```bash
# 基本用法(使用当前目录)
img2pdf

# 指定目录
img2pdf /path/to/images

# 设置 DPI
img2pdf --dpi 300 /path/to/images

# 启用图像规范化(自动旋转和缩放)
img2pdf --normalize /path/to/images

# 禁用图像规范化
img2pdf --no-normalize /path/to/images
```

### 参数说明

- `directory`: 包含图像的目录路径(可选, 默认为当前目录)
- `--dpi`: PDF 的 DPI 设置(默认为 300)
- `--normalize`, `-n`: 启用图像规范化(缩放, 旋转)
- `--no-normalize`: 禁用图像规范化

## 图像规范化

启用 `--normalize` 选项时, 将执行以下操作:

1. **自动旋转**: 如果图像宽度大于高度, 则旋转 90 度转换为纵向
2. **自动缩放**: 如果图像小于页面尺寸, 则按比例放大
3. **居中放置**: 将图像居中放置在白色背景的页面上

## 页面尺寸

默认使用 A4 纸张尺寸(8.27 x 11.69 英寸), 根据 DPI 设置转换为像素.

## 示例

```python
from pathlib import Path
from pytola_office.img2pdf.cli import ImageToPDFRunner

# 创建转换器
runner = ImageToPDFRunner(
    root_dir=Path("/path/to/images"),
    dpi=300,
    normalize=True
)

# 执行转换
runner.run()
```

## 开发

### 运行测试

```bash
pytest tests/
```

### 代码质量

```bash
ruff check .
ruff format .
```
