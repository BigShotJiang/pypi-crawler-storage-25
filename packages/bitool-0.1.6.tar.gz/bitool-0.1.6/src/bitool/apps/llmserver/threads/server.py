"""Server worker thread for llmserver."""

from __future__ import annotations

import os
import shutil
from pathlib import Path

from PySide2.QtCore import QProcess, QThread, Signal

from bitool.core import logger


class ServerWorker(QThread):
    """LLM Server worker thread.

    Handles starting/stopping the llama-server process in background thread
    to avoid blocking UI main thread.

    Signals:
        started: Emitted when server starts successfully
        stopped: Emitted when server stops
        error_occurred: Emitted when error occurs, carries error message
        output_received: Emitted when output is received, carries output text
    """

    started = Signal()
    stopped = Signal()
    error_occurred = Signal(str)
    output_received = Signal(str)

    def __init__(self, model_path: str, port: int, threads: int) -> None:
        """Initialize server worker thread.

        Args:
            model_path: Path to GGUF model file
            port: Server port number
            threads: Number of threads to use
        """
        super().__init__()
        self.model_path = Path(model_path)
        self.port = port
        self.threads = threads
        self.process: QProcess | None = None
        self._is_running = True

    def run(self) -> None:
        """Execute server process."""
        try:
            # Validate model file
            if not self.model_path.exists():
                self.error_occurred.emit(f"Error: Model file not found: {self.model_path}")
                return

            if not self.model_path.is_file():
                self.error_occurred.emit(f"Error: Path is not a file: {self.model_path}")
                return

            if self.model_path.suffix.lower() != ".gguf":
                logger.warning(f"Model file does not have .gguf extension: {self.model_path}")

            # Check if llama-server is available
            llama_server_path = shutil.which("llama-server")
            if not llama_server_path:
                self.error_occurred.emit(
                    "Error: llama-server not found in PATH. Please install llama.cpp.",
                )
                return

            self.output_received.emit(f"Found llama-server at: {llama_server_path}\n")

            # Change to model directory
            try:
                os.chdir(str(self.model_path.parent))
            except OSError as e:
                self.error_occurred.emit(f"Error: Cannot access model directory: {e}")
                return

            # Build command
            cmd = [
                "llama-server",
                "--model",
                self.model_path.name,
                "--port",
                str(self.port),
                "--threads",
                str(self.threads),
            ]

            self.output_received.emit(f"Starting server: {' '.join(cmd)}\n")
            self.output_received.emit(f"Working directory: {self.model_path.parent}\n")

            # Create and configure process
            self.process = QProcess()
            self.process.setProgram(cmd[0])
            self.process.setArguments(cmd[1:])

            # Connect signals
            self.process.readyReadStandardOutput.connect(self._handle_stdout)
            self.process.readyReadStandardError.connect(self._handle_stderr)
            self.process.finished.connect(self._on_process_finished)

            # Start process
            self.process.start()
            if self.process.waitForStarted(5000):
                self.started.emit()
                # Keep event loop running
                self.exec_()
            else:
                self.error_occurred.emit(
                    f"Error: Failed to start server process. Error: {self.process.errorString()}",
                )

        except (OSError, RuntimeError) as e:
            logger.exception("Server error")
            self.error_occurred.emit(f"Start failed: {e!s}")

    def _handle_stdout(self) -> None:
        """Handle standard output."""
        if self.process:
            data = self.process.readAllStandardOutput()
            text = data.data().decode("utf-8", errors="replace")
            self.output_received.emit(text)

    def _handle_stderr(self) -> None:
        """Handle standard error."""
        if self.process:
            data = self.process.readAllStandardError()
            text = data.data().decode("utf-8", errors="replace")
            self.output_received.emit(text)

    def _on_process_finished(self, exit_code: int, exit_status: int) -> None:
        """Process finished callback."""
        status_msg = f"Server stopped. Exit code: {exit_code}, Status: {exit_status}"
        self.output_received.emit(f"\n{status_msg}\n")

        if exit_code != 0:
            self.output_received.emit("Note: Non-zero exit code may indicate an error.\n")

        self.stopped.emit()
        self.quit()

    def stop(self) -> None:
        """Stop server gracefully."""
        self._is_running = False
        if self.process and self.process.state() == QProcess.Running:
            self.process.terminate()
            if not self.process.waitForFinished(2000):
                self.process.kill()
                self.process.waitForFinished(1000)
