"""依赖库打包器."""

from __future__ import annotations

import subprocess
import time
from dataclasses import dataclass
from pathlib import Path

try:
    import tomllib  # ty:ignore[unresolved-import]
except ImportError:
    import tomli as tomllib  # type: ignore[import-not-found, no-redef]

from bitool.core import logger


@dataclass
class PyLibPackerConfig:
    """库打包配置.

    Attributes
    ----------
    cache_dir : Path | None
        缓存目录
    mirror : str
        PyPI 镜像源
    optimize : bool
        是否优化
    max_workers : int
        最大并发数
    """

    cache_dir: Path | None = None
    mirror: str = "aliyun"
    optimize: bool = True
    max_workers: int = 4


@dataclass
class PyLibPacker:
    """依赖库打包器.

    Attributes
    ----------
    working_dir : Path
        工作目录
    config : PyLibPackerConfig
        配置
    """

    working_dir: Path
    config: PyLibPackerConfig

    def run(self) -> bool:
        """执行打包.

        Returns
        -------
        bool
            是否成功
        """
        logger.info("正在打包依赖库...")
        start_time = time.perf_counter()

        try:
            # 读取项目依赖
            dependencies = self._get_dependencies()

            if not dependencies:
                logger.info("没有需要打包的依赖")
                return True

            # 下载依赖
            if not self._download_dependencies(dependencies):
                return False

            elapsed = time.perf_counter() - start_time
            logger.info(f"依赖库打包完成，耗时 {elapsed:.2f}秒")
            return True

        except Exception:
            logger.exception("依赖库打包失败")
            return False

    def _get_dependencies(self) -> list[str]:
        """获取项目依赖.

        Returns
        -------
        list[str]
            依赖列表
        """
        dependencies = []

        # 查找所有项目的 pyproject.toml
        pyproject_files = list(self.working_dir.glob("**/pyproject.toml"))

        for pyproject_file in pyproject_files:
            # 跳过 .cbuild 和 .venv 目录
            if ".cbuild" in str(pyproject_file) or ".venv" in str(pyproject_file):
                continue

            try:
                content = pyproject_file.read_text(encoding="utf-8")
                data = tomllib.loads(content)
                deps = data.get("project", {}).get("dependencies", [])
                dependencies.extend(deps)
            except Exception as e:
                logger.warning(f"读取 {pyproject_file} 失败: {e}")

        # 去重
        unique_deps = list(dict.fromkeys(dependencies))

        if unique_deps:
            logger.info(f"找到 {len(unique_deps)} 个依赖: {', '.join(unique_deps)}")
        else:
            logger.info("未找到任何依赖")

        return unique_deps

    def _download_dependencies(self, dependencies: list[str]) -> bool:
        """下载依赖.

        Parameters
        ----------
        dependencies : list[str]
            依赖列表

        Returns
        -------
        bool
            是否成功
        """
        if not dependencies:
            return True

        lib_dir = self.working_dir / ".cbuild" / "lib"
        lib_dir.mkdir(parents=True, exist_ok=True)

        # 构建 pip 命令 - 使用 install --target 直接安装到目标目录
        # 注意：不使用嵌入式 Python，因为它没有 pip
        # 注意：使用 --no-deps 避免安装不必要的依赖，子项目需要显式声明所有依赖
        cmd = ["pip", "install", "--target", str(lib_dir), "--no-deps"]

        # 添加镜像源
        if self.config.mirror == "aliyun":
            cmd.extend(["-i", "https://mirrors.aliyun.com/pypi/simple/"])
        elif self.config.mirror == "tsinghua":
            cmd.extend(["-i", "https://pypi.tuna.tsinghua.edu.cn/simple/"])

        cmd.extend(dependencies)

        logger.info(f"正在安装 {len(dependencies)} 个依赖到 {lib_dir}...")

        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)

            if result.returncode != 0:
                logger.error(f"安装依赖失败: {result.stderr}")
                return False

            logger.info(f"依赖安装完成: {lib_dir}")
            return True

        except subprocess.TimeoutExpired:
            logger.error("安装依赖超时")
            return False
        except Exception as e:
            logger.exception(f"安装依赖异常: {e}")
            return False
