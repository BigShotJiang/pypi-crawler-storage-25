"""PyPack CLI 和进度模块测试."""

from __future__ import annotations

from pathlib import Path

import pytest

from bitool.apps.pypack.progress import (
    ProgressBar,
    TaskReporter,
    format_file_size,
    format_time,
)


class TestCLI:
    """CLI 接口测试."""

    def test_version_command(self) -> None:
        """测试版本命令."""
        from bitool.apps.pypack.cli import PyPackSkill

        skill = PyPackSkill()
        exit_code = skill.run(["v"])
        assert exit_code == 0

    def test_list_command(self) -> None:
        """测试列表命令."""
        from bitool.apps.pypack.cli import PyPackSkill

        skill = PyPackSkill()
        # 应该不抛出异常
        exit_code = skill.run(["l"])
        assert exit_code == 0

    def test_invalid_command(self) -> None:
        """测试无效命令."""
        from bitool.apps.pypack.cli import PyPackSkill

        skill = PyPackSkill()
        exit_code = skill.run(["invalid"])
        assert exit_code == 1

    def test_no_command(self) -> None:
        """测试无命令."""
        from bitool.apps.pypack.cli import PyPackSkill

        skill = PyPackSkill()
        exit_code = skill.run([])
        assert exit_code == 1

    def test_clean_command(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """测试清理命令."""
        from bitool.apps.pypack.cli import PyPackSkill

        # 切换到临时目录
        monkeypatch.chdir(tmp_path)

        skill = PyPackSkill()
        exit_code = skill.run(["c"])
        assert exit_code == 0

    def test_run_project_without_name(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """测试运行项目但不指定名称."""
        from bitool.apps.pypack.cli import PyPackSkill

        monkeypatch.chdir(tmp_path)

        skill = PyPackSkill()
        exit_code = skill.run(["r"])
        # 应该失败，因为没有指定项目名称
        assert exit_code == 1

    @pytest.mark.parametrize("command", ["v", "version"])
    def test_version_variants(self, command: str) -> None:
        """测试版本命令的多种变体."""
        from bitool.apps.pypack.cli import PyPackSkill

        skill = PyPackSkill()
        exit_code = skill.run([command])
        assert exit_code == 0

    @pytest.mark.parametrize("command", ["l", "list", "ls"])
    def test_list_variants(self, command: str) -> None:
        """测试列表命令的多种变体."""
        from bitool.apps.pypack.cli import PyPackSkill

        skill = PyPackSkill()
        exit_code = skill.run([command])
        assert exit_code == 0

    @pytest.mark.parametrize("command", ["c", "clean"])
    def test_clean_variants(
        self, command: str, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """测试清理命令的多种变体."""
        from bitool.apps.pypack.cli import PyPackSkill

        monkeypatch.chdir(tmp_path)

        skill = PyPackSkill()
        exit_code = skill.run([command])
        assert exit_code == 0


class TestProgress:
    """进度模块测试."""

    def test_format_file_size_bytes(self) -> None:
        """测试文件大小格式化 - 字节."""
        assert format_file_size(0) == "0 B"
        assert format_file_size(512) == "512 B"
        assert format_file_size(1023) == "1023 B"

    def test_format_file_size_kb(self) -> None:
        """测试文件大小格式化 - KB."""
        assert format_file_size(1024) == "1.0 KB"
        assert format_file_size(1536) == "1.5 KB"
        assert format_file_size(10240) == "10.0 KB"

    def test_format_file_size_mb(self) -> None:
        """测试文件大小格式化 - MB."""
        assert format_file_size(1024 * 1024) == "1.0 MB"
        assert format_file_size(1024 * 1024 * 5) == "5.0 MB"

    def test_format_file_size_gb(self) -> None:
        """测试文件大小格式化 - GB."""
        assert format_file_size(1024 * 1024 * 1024) == "1.0 GB"
        assert format_file_size(1024 * 1024 * 1024 * 2) == "2.0 GB"

    @pytest.mark.parametrize(
        ("seconds", "expected"),
        [
            (0.5, "500ms"),
            (0.123, "123ms"),
            (1.5, "1.5s"),
            (30.0, "30.0s"),
            (59.9, "59.9s"),
            (60.0, "1m 0s"),
            (125.0, "2m 5s"),
            (3600.0, "1h 0m"),
            (7265.0, "2h 1m"),
        ],
    )
    def test_format_time(self, seconds: float, expected: str) -> None:
        """测试时间格式化."""
        assert format_time(seconds) == expected

    def test_progress_bar(self, capsys: pytest.CaptureFixture) -> None:
        """测试进度条."""
        bar = ProgressBar(total=10, desc="测试")
        bar.update(5)

        # 验证输出
        captured = capsys.readouterr()
        assert "测试" in captured.out
        assert "5/10" in captured.out

    def test_task_reporter(self) -> None:
        """测试任务报告器."""
        reporter = TaskReporter(total_tasks=3, desc="测试任务")
        assert reporter.total == 3
        assert reporter.current == 0

        reporter.start_task("任务1")
        reporter.complete_task(success=True, message="任务1完成")
        assert reporter.current == 1

        reporter.finish()
