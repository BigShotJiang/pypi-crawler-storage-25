"""PyPack 组件测试 - SourcePacker, Archiver, Loader, EmbedInstaller, LibPacker."""

from __future__ import annotations

from pathlib import Path

import pytest

from bitool.apps.pypack.components.archiver import PyArchiver
from bitool.apps.pypack.components.embedinstaller import (
    _DEFAULT_CACHE_DIR,
    EmbedInstaller,
)
from bitool.apps.pypack.components.libpacker import PyLibPacker, PyLibPackerConfig
from bitool.apps.pypack.components.loader import PyLoaderGenerator
from bitool.apps.pypack.components.sourcepacker import PySourcePacker


class TestSourcePacker:
    """PySourcePacker 测试."""

    def test_no_infinite_recursion(self, tmp_path: Path) -> None:
        """测试不会无限递归。"""
        # 创建项目结构
        project_dir = tmp_path / "testproject"
        project_dir.mkdir()
        (project_dir / "pyproject.toml").write_text(
            '[project]\nname = "testproject"\nversion = "1.0.0"\ndescription = "Test"'
        )
        (project_dir / "main.py").write_text('print("hello")')

        # 创建子目录和文件
        src_dir = project_dir / "src"
        src_dir.mkdir()
        (src_dir / "module.py").write_text('print("module")')

        # 打包器应该在复制时跳过 .cbuild 目录
        packer = PySourcePacker(root_dir=tmp_path)

        # 执行打包（不应该无限递归）
        success = packer.run()
        assert success is True

        # 验证 .cbuild 目录存在且包含项目
        cbuild_dir = tmp_path / ".cbuild"
        assert cbuild_dir.exists()

        # 验证 .cbuild 内部没有嵌套的 .cbuild
        nested_cbuild = cbuild_dir / "src" / "testproject" / ".cbuild"
        assert not nested_cbuild.exists(), "不应该有嵌套的 .cbuild 目录"

    def test_skip_cbuild_directory(self, tmp_path: Path) -> None:
        """测试跳过 .cbuild 目录。"""
        # 创建 .cbuild 目录和内部文件
        cbuild_dir = tmp_path / ".cbuild"
        cbuild_dir.mkdir()
        (cbuild_dir / "should_skip.txt").write_text("skip me")

        # 创建正常项目
        project_dir = tmp_path / "myproject"
        project_dir.mkdir()
        (project_dir / "pyproject.toml").write_text(
            '[project]\nname = "myproject"\nversion = "1.0.0"\ndescription = "Test"'
        )

        packer = PySourcePacker(root_dir=tmp_path)
        success = packer.run()
        assert success is True

    def test_scan_projects(self, tmp_path: Path) -> None:
        """测试项目扫描."""
        # 创建多个项目
        for i in range(3):
            project_dir = tmp_path / f"project{i}"
            project_dir.mkdir()
            (project_dir / "pyproject.toml").write_text(
                f'[project]\nname = "project{i}"\nversion = "1.0.0"'
            )

        # 创建应该在 .cbuild 中被跳过的项目
        cbuild_project = tmp_path / ".cbuild" / "skipped"
        cbuild_project.mkdir(parents=True)
        (cbuild_project / "pyproject.toml").write_text(
            '[project]\nname = "skipped"\nversion = "1.0.0"'
        )

        packer = PySourcePacker(root_dir=tmp_path)
        projects = packer._scan_projects()

        assert len(projects) == 3

    def test_should_ignore_patterns(self, tmp_path: Path) -> None:
        """测试忽略模式."""
        packer = PySourcePacker(root_dir=tmp_path)

        # 测试各种应该被忽略的模式
        assert packer._should_ignore(tmp_path / "__pycache__") is True
        assert packer._should_ignore(tmp_path / "test.pyc") is True
        assert packer._should_ignore(tmp_path / "test.pyo") is True
        assert packer._should_ignore(tmp_path / ".git") is True
        assert packer._should_ignore(tmp_path / ".pytest_cache") is True
        assert packer._should_ignore(tmp_path / "test.log") is True

        # 测试不应该被忽略的文件
        assert packer._should_ignore(tmp_path / "main.py") is False
        assert packer._should_ignore(tmp_path / "module.txt") is False

    def test_pack_project_with_src_layout(self, tmp_path: Path) -> None:
        """测试 src layout 项目打包."""
        # 创建 src layout 项目
        project_dir = tmp_path / "myapp"
        project_dir.mkdir()
        (project_dir / "pyproject.toml").write_text(
            '[project]\nname = "myapp"\nversion = "1.0.0"'
        )

        # 创建 src 子目录
        src_dir = project_dir / "src" / "mypackage"
        src_dir.mkdir(parents=True)
        (src_dir / "__init__.py").write_text("")
        (src_dir / "module.py").write_text("# module")

        packer = PySourcePacker(root_dir=tmp_path)
        size = packer._pack_project(project_dir)

        # 验证打包后的结构
        cbuild_src = tmp_path / ".cbuild" / "src" / "myapp" / "src" / "mypackage"
        assert cbuild_src.exists()
        assert (cbuild_src / "module.py").exists()
        assert size > 0

    def test_ensure_entry_file_from_scripts(self, tmp_path: Path) -> None:
        """测试从 scripts 配置创建入口文件."""
        project_dir = tmp_path / "myapp"
        project_dir.mkdir()
        (project_dir / "pyproject.toml").write_text(
            '[project]\nname = "myapp"\nversion = "1.0.0"\n'
            '[project.scripts]\nmyapp = "myapp.cli:main"'
        )

        source_dir = tmp_path / ".cbuild" / "src" / "myapp"
        source_dir.mkdir(parents=True)

        packer = PySourcePacker(root_dir=tmp_path)
        packer._ensure_entry_file(project_dir, source_dir)

        # 验证 main.py 已创建
        main_file = source_dir / "main.py"
        assert main_file.exists()
        content = main_file.read_text(encoding="utf-8")
        assert "myapp.cli" in content
        assert "main" in content

    def test_generate_main_from_script(self, tmp_path: Path) -> None:
        """测试生成 main.py 代码."""
        packer = PySourcePacker(root_dir=tmp_path)

        # 测试带冒号的脚本
        code = packer._generate_main_from_script("mymodule.cli:run")
        assert "from mymodule.cli import run" in code
        assert "sys.exit(run())" in code

        # 测试不带冒号的脚本
        code = packer._generate_main_from_script("mymodule.main")
        assert "from mymodule.main import main" in code


class TestArchiver:
    """PyArchiver 测试."""

    def test_archive_zip(self, tmp_path: Path) -> None:
        """测试 ZIP 归档."""
        # 创建构建目录
        build_dir = tmp_path / ".cbuild"
        build_dir.mkdir()
        (build_dir / "test.txt").write_text("test content")

        archiver = PyArchiver(root_dir=tmp_path, build_dir=build_dir)
        success = archiver.run("zip")

        assert success is True
        # 验证归档文件已创建
        archive_file = tmp_path / f"{tmp_path.name}_package.zip"
        assert archive_file.exists()

    def test_archive_tar(self, tmp_path: Path) -> None:
        """测试 TAR 归档."""
        build_dir = tmp_path / ".cbuild"
        build_dir.mkdir()
        (build_dir / "test.txt").write_text("test content")

        archiver = PyArchiver(root_dir=tmp_path, build_dir=build_dir)
        success = archiver.run("tar")

        assert success is True

    def test_archive_invalid_format(self, tmp_path: Path) -> None:
        """测试无效归档格式."""
        build_dir = tmp_path / ".cbuild"
        build_dir.mkdir()

        archiver = PyArchiver(root_dir=tmp_path, build_dir=build_dir)
        success = archiver.run("invalid")

        assert success is False

    def test_archive_missing_build_dir(self, tmp_path: Path) -> None:
        """测试构建目录不存在."""
        archiver = PyArchiver(root_dir=tmp_path)
        success = archiver.run("zip")

        assert success is False

    def test_archive_default_build_dir(self, tmp_path: Path) -> None:
        """测试默认构建目录."""
        build_dir = tmp_path / ".cbuild"
        build_dir.mkdir()
        (build_dir / "test.txt").write_text("content")

        # 不指定 build_dir，应该自动使用 .cbuild
        archiver = PyArchiver(root_dir=tmp_path)
        success = archiver.run("zip")

        assert success is True

    @pytest.mark.parametrize(
        "archive_format", ["zip", "tar", "gztar", "bztar", "xztar"]
    )
    def test_archive_formats(self, tmp_path: Path, archive_format: str) -> None:
        """测试各种归档格式."""
        build_dir = tmp_path / ".cbuild"
        build_dir.mkdir()
        (build_dir / "test.txt").write_text("content")

        archiver = PyArchiver(root_dir=tmp_path, build_dir=build_dir)
        success = archiver.run(archive_format)

        assert success is True


class TestLoaderGenerator:
    """PyLoaderGenerator 测试."""

    def test_generate_source_code(self, tmp_path: Path) -> None:
        """测试生成源代码."""
        python_exe = tmp_path / "python.exe"
        python_exe.touch()

        loader_gen = PyLoaderGenerator(
            root_dir=tmp_path,
            project_name="myapp",
            python_exe=python_exe,
            script_name="main.py",
            loader_type="console",
        )

        source_file = loader_gen._generate_source()

        assert source_file is not None
        assert source_file.exists()
        assert source_file.name == "myapp_loader.c"

        # 验证生成的 C 代码
        content = source_file.read_text(encoding="utf-8")
        assert "main(int argc" in content
        assert "CreateProcessA" in content

    def test_generate_gui_loader(self, tmp_path: Path) -> None:
        """测试生成 GUI 加载器."""
        python_exe = tmp_path / "python.exe"
        python_exe.touch()

        loader_gen = PyLoaderGenerator(
            root_dir=tmp_path,
            project_name="guiapp",
            python_exe=python_exe,
            loader_type="gui",
        )

        source_file = loader_gen._generate_source()

        assert source_file is not None
        content = source_file.read_text(encoding="utf-8")
        assert "guiapp" in content

    def test_generate_with_custom_script(self, tmp_path: Path) -> None:
        """测试自定义脚本名称."""
        python_exe = tmp_path / "python.exe"
        python_exe.touch()

        loader_gen = PyLoaderGenerator(
            root_dir=tmp_path,
            project_name="myapp",
            python_exe=python_exe,
            script_name="app.py",
        )

        source_file = loader_gen._generate_source()

        assert source_file is not None
        content = source_file.read_text(encoding="utf-8")
        assert "app.py" in content

    def test_compile_no_compiler(self, tmp_path: Path) -> None:
        """测试无编译器时的行为."""
        python_exe = tmp_path / "python.exe"
        python_exe.touch()

        source_file = tmp_path / "test.c"
        source_file.write_text("int main() { return 0; }")

        loader_gen = PyLoaderGenerator(
            root_dir=tmp_path, project_name="myapp", python_exe=python_exe
        )

        # 在没有编译器的环境下应该返回 None
        exe_file = loader_gen._compile(source_file)
        # 可能返回 None 或 Path（如果有编译器）
        assert exe_file is None or exe_file.exists()


class TestEmbedInstaller:
    """EmbedInstaller 测试."""

    def test_embed_dir_property(self, tmp_path: Path) -> None:
        """测试嵌入目录属性."""
        installer = EmbedInstaller(root_dir=tmp_path)
        expected_dir = tmp_path / ".cbuild" / "python"

        assert installer.embed_dir == expected_dir

    def test_arch_property(self, tmp_path: Path) -> None:
        """测试架构属性."""
        installer = EmbedInstaller(root_dir=tmp_path)
        arch = installer.arch
        # 应该是有效的架构名称
        assert arch in {"amd64", "arm64"}

    def test_cache_dir_property(self, tmp_path: Path) -> None:
        """测试缓存目录属性."""
        custom_cache = tmp_path / "custom_cache"
        installer = EmbedInstaller(root_dir=tmp_path, cache_dir=custom_cache)

        assert installer.actual_cache_dir == custom_cache

    def test_default_cache_dir(self, tmp_path: Path) -> None:
        """测试默认缓存目录."""
        installer = EmbedInstaller(root_dir=tmp_path)
        assert installer.actual_cache_dir == _DEFAULT_CACHE_DIR

    def test_offline_mode(self, tmp_path: Path) -> None:
        """测试离线模式."""
        # 使用空的临时缓存目录, 确保没有缓存文件
        empty_cache = tmp_path / "empty_cache"
        installer = EmbedInstaller(
            root_dir=tmp_path, offline=True, cache_dir=empty_cache
        )
        # 离线模式下，如果没有缓存应该返回 False
        success = installer.run()
        # 因为没有缓存且离线，应该失败
        assert success is False

    def test_already_installed(self, tmp_path: Path) -> None:
        """测试已安装的情况."""
        # 创建已安装的目录结构
        embed_dir = tmp_path / ".cbuild" / "python"
        embed_dir.mkdir(parents=True)
        (embed_dir / "python.exe").touch()

        installer = EmbedInstaller(root_dir=tmp_path)
        success = installer.run()
        assert success is True


class TestLibPacker:
    """PyLibPacker 测试."""

    def test_create_packer(self, tmp_path: Path) -> None:
        """测试创建打包器."""
        config = PyLibPackerConfig()
        packer = PyLibPacker(working_dir=tmp_path, config=config)

        assert packer.working_dir == tmp_path
        assert packer.config == config

    def test_packer_default_config(self, tmp_path: Path) -> None:
        """测试打包器默认配置."""
        config = PyLibPackerConfig()
        packer = PyLibPacker(working_dir=tmp_path, config=config)

        assert packer.working_dir == tmp_path

    def test_pack_empty_dependencies(self, tmp_path: Path) -> None:
        """测试空依赖列表."""
        config = PyLibPackerConfig()
        packer = PyLibPacker(working_dir=tmp_path, config=config)

        # run 不接受参数，直接调用即可
        success = packer.run()
        assert success is True

    def test_config_custom_values(self, tmp_path: Path) -> None:
        """测试自定义配置值."""
        config = PyLibPackerConfig(
            cache_dir=tmp_path / "cache",
            mirror="tsinghua",
            optimize=False,
            max_workers=8,
        )

        assert config.cache_dir == tmp_path / "cache"
        assert config.mirror == "tsinghua"
        assert config.optimize is False
        assert config.max_workers == 8

    def test_config_defaults(self) -> None:
        """测试配置默认值."""
        config = PyLibPackerConfig()
        assert config.cache_dir is None
        assert config.mirror == "aliyun"
        assert config.optimize is True
        assert config.max_workers == 4

    def test_packer_with_dependencies(self, tmp_path: Path) -> None:
        """测试有依赖的打包(使用 mock)."""
        from unittest.mock import patch

        config = PyLibPackerConfig()
        packer = PyLibPacker(working_dir=tmp_path, config=config)

        # Mock _get_dependencies 返回依赖列表
        with patch.object(
            packer, "_get_dependencies", return_value=["requests"]
        ), patch("subprocess.run") as mock_run:
            mock_run.return_value.returncode = 0
            success = packer.run()
            assert success is True
            # 验证调用了 pip download
            mock_run.assert_called_once()
