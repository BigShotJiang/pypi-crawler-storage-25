"""PyPack 模型测试 - Dependency, EntryFile, Project, Solution."""

from __future__ import annotations

from pathlib import Path

import pytest

from bitool.apps.pypack.models.dependency import Dependency
from bitool.apps.pypack.models.entryfile import EntryFile
from bitool.apps.pypack.models.project import Project, detect_entry_files, is_entry_file
from bitool.apps.pypack.models.solution import Solution


class TestDependency:
    """Dependency 模型测试."""

    def test_create_dependency(self) -> None:
        """测试创建依赖项."""
        dep = Dependency(name="requests", version=">=2.28.0")
        assert dep.name == "requests"
        assert dep.version == ">=2.28.0"
        assert dep.extras == []

    def test_dependency_str(self) -> None:
        """测试依赖项字符串表示."""
        dep = Dependency(name="requests", version=">=2.28.0")
        assert str(dep) == "requests>=2.28.0"

        dep_no_version = Dependency(name="requests")
        assert str(dep_no_version) == "requests"

    def test_dependency_to_dict(self) -> None:
        """测试依赖项转字典."""
        dep = Dependency(name="requests", version=">=2.28.0")
        d = dep.to_dict()
        assert d["name"] == "requests"
        assert d["version"] == ">=2.28.0"

    def test_dependency_from_string(self) -> None:
        """测试从字符串创建依赖项."""
        dep = Dependency.from_string("requests>=2.28.0")
        assert dep.name == "requests"
        assert dep.version == ">=2.28.0"

    @pytest.mark.parametrize(
        ("input_str", "expected_name", "expected_version"),
        [
            ("requests", "requests", None),
            ("requests>=2.28.0", "requests", ">=2.28.0"),
            ("requests==2.28.0", "requests", "==2.28.0"),
            ("requests>=2.28.0,<3.0.0", "requests", ">=2.28.0,<3.0.0"),
            ("numpy>=1.20", "numpy", ">=1.20"),
        ],
    )
    def test_dependency_parsing(
        self, input_str: str, expected_name: str, expected_version: str | None
    ) -> None:
        """测试依赖项解析."""
        dep = Dependency.from_string(input_str)

        assert dep.name == expected_name
        assert dep.version == expected_version

    def test_dependency_with_extras(self) -> None:
        """测试带额外依赖的依赖项."""
        dep = Dependency(name="requests", version=">=2.28.0", extras=["security"])

        assert dep.extras == ["security"]

    def test_dependency_dict_format(self) -> None:
        """测试依赖项字典格式."""
        dep = Dependency(name="requests", version=">=2.28.0", extras=["security"])
        d = dep.to_dict()

        assert d["name"] == "requests"
        assert d["version"] == ">=2.28.0"
        assert d["extras"] == ["security"]


class TestEntryFile:
    """EntryFile 模型测试."""

    def test_create_entry_file(self, tmp_path: Path) -> None:
        """测试创建入口文件."""
        source = tmp_path / "main.py"
        source.touch()

        entry = EntryFile(project_name="myapp", source_file=source)
        assert entry.project_name == "myapp"
        assert entry.source_file == source
        assert entry.output_stem == "main"

    def test_entry_file_with_project_root(self, tmp_path: Path) -> None:
        """测试带项目根目录的入口文件."""
        project_root = tmp_path / "myproject"
        project_root.mkdir()
        source = project_root / "src" / "main.py"
        source.parent.mkdir()
        source.touch()

        entry = EntryFile(
            project_name="myapp", source_file=source, project_root=project_root
        )
        assert entry.relative_path == Path("src/main.py")

    def test_entry_file_without_project_root(self, tmp_path: Path) -> None:
        """测试不带项目根目录的入口文件."""
        source = tmp_path / "app.py"
        source.touch()

        entry = EntryFile(project_name="myapp", source_file=source)
        assert entry.relative_path == "app.py"

    def test_entry_file_str(self, tmp_path: Path) -> None:
        """测试入口文件字符串表示."""
        source = tmp_path / "main.py"
        source.touch()

        entry = EntryFile(project_name="myapp", source_file=source)
        assert str(entry) == "myapp:main.py"

    def test_entry_file_to_dict(self, tmp_path: Path) -> None:
        """测试入口文件转字典."""
        source = tmp_path / "main.py"
        source.touch()

        entry = EntryFile(project_name="myapp", source_file=source)
        d = entry.to_dict()
        assert d["project_name"] == "myapp"
        assert d["source_file"] == str(source)
        assert d["output_stem"] == "main"

    @pytest.mark.parametrize(
        ("filename", "expected_stem"),
        [
            ("main.py", "main"),
            ("app.py", "app"),
            ("cli_tool.py", "cli_tool"),
            ("__main__.py", "__main__"),
        ],
    )
    def test_entry_file_output_stem(
        self, tmp_path: Path, filename: str, expected_stem: str
    ) -> None:
        """测试不同文件名的输出茎."""
        source = tmp_path / filename
        source.touch()

        entry = EntryFile(project_name="myapp", source_file=source)
        assert entry.output_stem == expected_stem


class TestProject:
    """Project 模型测试."""

    def test_create_project(self, tmp_path: Path) -> None:
        """测试创建项目."""
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text('[project]\nname = "test"\nversion = "1.0.0"')

        project = Project(
            name="test",
            version="1.0.0",
            description="Test project",
            project_dir=tmp_path,
            pyproject_file=pyproject,
            dependencies=["requests"],
        )

        assert project.name == "test"
        assert project.version == "1.0.0"
        assert len(project.dependencies) == 1

    def test_project_str(self, tmp_path: Path) -> None:
        """测试项目字符串表示."""
        pyproject = tmp_path / "pyproject.toml"
        project = Project(
            name="test",
            version="1.0.0",
            description="Test",
            project_dir=tmp_path,
            pyproject_file=pyproject,
        )
        assert "test==1.0.0" in str(project)

    def test_project_repr(self, tmp_path: Path) -> None:
        """测试项目 repr 表示."""
        pyproject = tmp_path / "pyproject.toml"
        project = Project(
            name="test",
            version="1.0.0",
            description="Test",
            project_dir=tmp_path,
            pyproject_file=pyproject,
            dependencies=["requests", "numpy"],
        )
        assert "test==1.0.0" in repr(project)
        assert "2 deps" in repr(project)

    def test_project_get_info(self, tmp_path: Path) -> None:
        """测试获取项目信息."""
        pyproject = tmp_path / "pyproject.toml"
        project = Project(
            name="test",
            version="1.0.0",
            description="Test project",
            project_dir=tmp_path,
            pyproject_file=pyproject,
            dependencies=["requests>=2.28.0", "numpy"],
        )

        info = project.get_project_info()
        assert info["name"] == "test"
        assert info["version"] == "1.0.0"
        assert info["description"] == "Test project"
        assert info["project_dir"] == str(tmp_path)
        assert len(info["dependencies"]) == 2
        assert "is_gui" in info

    @pytest.mark.parametrize(
        ("dependencies", "expected_gui"),
        [
            (["requests", "numpy"], False),
            (["PyQt5", "requests"], True),
            (["PySide6"], True),
            (["gui-framework"], True),
            (["desktop-app"], True),
        ],
    )
    def test_project_is_gui(
        self, tmp_path: Path, dependencies: list[str], expected_gui: bool
    ) -> None:
        """测试 GUI 项目判断."""
        pyproject = tmp_path / "pyproject.toml"
        project = Project(
            name="test",
            version="1.0.0",
            description="Test",
            project_dir=tmp_path,
            pyproject_file=pyproject,
            dependencies=dependencies,
        )
        assert project.is_gui_project == expected_gui

    def test_detect_entry_files(self, tmp_path: Path) -> None:
        """测试检测入口文件."""
        # 创建入口文件
        main_file = tmp_path / "main.py"
        main_file.write_text("def main():\n    pass")

        app_file = tmp_path / "app.py"
        app_file.write_text("if __name__ == '__main__':\n    pass")

        # 创建非入口文件
        (tmp_path / "module.py").write_text("def helper():\n    pass")

        entry_files = detect_entry_files(tmp_path, "myapp")

        assert len(entry_files) == 2

    def test_is_entry_file_with_main(self, tmp_path: Path) -> None:
        """测试入口文件判断 - main 函数."""
        main_file = tmp_path / "main.py"
        main_file.write_text("def main():\n    pass")

        assert is_entry_file(main_file) is True

    def test_is_entry_file_with_name_main(self, tmp_path: Path) -> None:
        """测试入口文件判断 - __name__ == '__main__'."""
        app_file = tmp_path / "app.py"
        app_file.write_text("if __name__ == '__main__':\n    print('hello')")

        assert is_entry_file(app_file) is True

    def test_is_not_entry_file(self, tmp_path: Path) -> None:
        """测试非入口文件."""
        module_file = tmp_path / "module.py"
        module_file.write_text("def helper():\n    pass")

        assert is_entry_file(module_file) is False


class TestSolution:
    """Solution 模型测试."""

    def test_scan_projects(self, tmp_path: Path) -> None:
        """测试扫描项目."""
        # 创建一个项目
        project_dir = tmp_path / "myproject"
        project_dir.mkdir()
        pyproject = project_dir / "pyproject.toml"
        pyproject.write_text(
            '[project]\nname = "myproject"\nversion = "1.0.0"\ndescription = "Test"'
        )

        solution = Solution.from_directory(tmp_path)
        assert len(solution.projects) == 1
        assert "myproject" in solution.projects

    def test_solution_repr(self, tmp_path: Path) -> None:
        """测试解决方案的 repr 表示."""
        project_dir = tmp_path / "myproject"
        project_dir.mkdir()
        (project_dir / "pyproject.toml").write_text(
            '[project]\nname = "myproject"\nversion = "1.0.0"'
        )

        solution = Solution.from_directory(tmp_path)
        repr_str = repr(solution)
        assert "Solution" in repr_str
        assert "projects: 1" in repr_str
        assert "time_used=" in repr_str

    def test_solution_elapsed_time(self, tmp_path: Path) -> None:
        """测试解决方案的耗时计算."""
        solution = Solution.from_directory(tmp_path)
        elapsed = solution.elapsed_time
        assert elapsed >= 0

    def test_solution_dependencies(self, tmp_path: Path) -> None:
        """测试获取所有依赖."""
        # 创建两个项目
        for i in range(2):
            project_dir = tmp_path / f"project{i}"
            project_dir.mkdir()
            deps = (
                'dependencies = ["requests", "numpy"]'
                if i == 0
                else 'dependencies = ["flask"]'
            )
            (project_dir / "pyproject.toml").write_text(
                f'[project]\nname = "project{i}"\nversion = "1.0.0"\n{deps}'
            )

        solution = Solution.from_directory(tmp_path)
        all_deps = solution.dependencies
        assert "requests" in all_deps
        assert "numpy" in all_deps
        assert "flask" in all_deps

    def test_find_matching_projects(self, tmp_path: Path) -> None:
        """测试查找匹配的项目."""
        for name in ["myapp-core", "myapp-ui", "other-project"]:
            project_dir = tmp_path / name
            project_dir.mkdir()
            (project_dir / "pyproject.toml").write_text(
                f'[project]\nname = "{name}"\nversion = "1.0.0"'
            )

        solution = Solution.from_directory(tmp_path)

        # 精确匹配
        matches = solution.find_matching_projects("myapp")
        assert len(matches) == 2
        assert "myapp-core" in matches
        assert "myapp-ui" in matches

        # 无匹配
        matches = solution.find_matching_projects("nonexistent")
        assert len(matches) == 0

        # 空模式
        matches = solution.find_matching_projects("")
        assert len(matches) == 0

    def test_resolve_project_name_exact(self, tmp_path: Path) -> None:
        """测试精确解析项目名称."""
        project_dir = tmp_path / "myapp"
        project_dir.mkdir()
        (project_dir / "pyproject.toml").write_text(
            '[project]\nname = "myapp"\nversion = "1.0.0"'
        )

        solution = Solution.from_directory(tmp_path)
        resolved = solution.resolve_project_name("myapp")
        assert resolved == "myapp"

    def test_resolve_project_name_fuzzy(self, tmp_path: Path) -> None:
        """测试模糊解析项目名称."""
        project_dir = tmp_path / "myapp-core"
        project_dir.mkdir()
        (project_dir / "pyproject.toml").write_text(
            '[project]\nname = "myapp-core"\nversion = "1.0.0"'
        )

        solution = Solution.from_directory(tmp_path)
        resolved = solution.resolve_project_name("myapp")
        assert resolved == "myapp-core"

    def test_resolve_project_name_auto_select(self, tmp_path: Path) -> None:
        """测试自动选择唯一项目."""
        project_dir = tmp_path / "only-project"
        project_dir.mkdir()
        (project_dir / "pyproject.toml").write_text(
            '[project]\nname = "only-project"\nversion = "1.0.0"'
        )

        solution = Solution.from_directory(tmp_path)
        resolved = solution.resolve_project_name(None)
        assert resolved == "only-project"

    def test_resolve_project_name_ambiguous(self, tmp_path: Path) -> None:
        """测试模糊匹配有多个结果时返回 None."""
        for name in ["myapp-core", "myapp-ui"]:
            project_dir = tmp_path / name
            project_dir.mkdir()
            (project_dir / "pyproject.toml").write_text(
                f'[project]\nname = "{name}"\nversion = "1.0.0"'
            )

        solution = Solution.from_directory(tmp_path)
        resolved = solution.resolve_project_name("myapp")
        assert resolved is None

    def test_scan_multiple_projects(self, tmp_path: Path) -> None:
        """测试扫描多个项目."""
        # 创建多个项目
        for i in range(3):
            project_dir = tmp_path / f"project{i}"
            project_dir.mkdir()
            (project_dir / "pyproject.toml").write_text(
                f'[project]\nname = "project{i}"\nversion = "1.0.{i}"\ndescription = "Test {i}"'
            )

        solution = Solution.from_directory(tmp_path)

        assert len(solution.projects) == 3
        for i in range(3):
            assert f"project{i}" in solution.projects

    def test_scan_exclude_patterns(self, tmp_path: Path) -> None:
        """测试排除模式."""
        # 创建应该被排除的项目
        excluded_dir = tmp_path / ".cbuild" / "project"
        excluded_dir.mkdir(parents=True)
        (excluded_dir / "pyproject.toml").write_text(
            '[project]\nname = "excluded"\nversion = "1.0.0"'
        )

        # 创建正常项目
        normal_dir = tmp_path / "normal"
        normal_dir.mkdir()
        (normal_dir / "pyproject.toml").write_text(
            '[project]\nname = "normal"\nversion = "1.0.0"'
        )

        solution = Solution.from_directory(tmp_path)

        assert len(solution.projects) == 1
        assert "normal" in solution.projects
        assert "excluded" not in solution.projects

    def test_scan_empty_directory(self, tmp_path: Path) -> None:
        """测试扫描空目录."""
        solution = Solution.from_directory(tmp_path)

        assert len(solution.projects) == 0
