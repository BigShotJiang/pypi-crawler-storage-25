"""PyPack 工作流和配置测试."""

from __future__ import annotations

from pathlib import Path

import pytest

from bitool.apps.pypack.config import PyPackConfig
from bitool.apps.pypack.workflow import PackageWorkflow, WorkflowConfig


class TestWorkflowConfig:
    """WorkflowConfig 测试."""

    def test_default_config(self, tmp_path: Path) -> None:
        """测试默认配置."""
        config = WorkflowConfig(directory=tmp_path)
        assert config.directory == tmp_path
        assert config.python_version == "3.8.10"
        assert config.loader_type == "console"
        assert config.max_concurrent == 4

    def test_custom_config(self, tmp_path: Path) -> None:
        """测试自定义配置."""
        config = WorkflowConfig(
            directory=tmp_path,
            python_version="3.10.0",
            loader_type="gui",
            max_concurrent=8,
        )
        assert config.python_version == "3.10.0"
        assert config.loader_type == "gui"
        assert config.max_concurrent == 8

    def test_dist_dir_property(self, tmp_path: Path) -> None:
        """测试分发目录属性."""
        config = WorkflowConfig(directory=tmp_path)

        assert config.dist_dir == tmp_path / "dist"

    def test_build_dir_property(self, tmp_path: Path) -> None:
        """测试构建目录属性."""
        config = WorkflowConfig(directory=tmp_path)

        assert config.build_dir == tmp_path / ".cbuild"

    @pytest.mark.parametrize(
        ("archive_type", "expected"),
        [("zip", "zip"), ("7z", "7z"), ("gztar", "gztar"), (None, None)],
    )
    def test_archive_type_config(
        self, tmp_path: Path, archive_type: str | None, expected: str | None
    ) -> None:
        """测试归档类型配置."""
        config = WorkflowConfig(directory=tmp_path, archive_type=archive_type)

        assert config.archive_type == expected


class TestPackageWorkflow:
    """PackageWorkflow 测试."""

    def test_list_projects(self, tmp_path: Path) -> None:
        """测试列出项目."""
        # 创建项目
        project_dir = tmp_path / "testproj"
        project_dir.mkdir()
        (project_dir / "pyproject.toml").write_text(
            '[project]\nname = "testproj"\nversion = "1.0.0"\ndescription = "Test"'
        )

        config = WorkflowConfig(directory=tmp_path)
        workflow = PackageWorkflow(root_dir=tmp_path, config=config)

        # 应该不抛出异常
        workflow.list_projects()

    def test_clean_project(self, tmp_path: Path) -> None:
        """测试清理项目."""
        # 创建构建目录
        build_dir = tmp_path / ".cbuild"
        build_dir.mkdir()
        (build_dir / "temp.txt").write_text("test")

        config = WorkflowConfig(directory=tmp_path)
        workflow = PackageWorkflow(root_dir=tmp_path, config=config)

        workflow.clean_project()
        assert not build_dir.exists()

    def test_run_project_not_found(self, tmp_path: Path) -> None:
        """测试运行不存在的项目."""
        config = WorkflowConfig(directory=tmp_path)
        workflow = PackageWorkflow(root_dir=tmp_path, config=config)

        # 应该不抛出异常
        workflow.run_project("nonexistent")

    def test_workflow_config_properties(self, tmp_path: Path) -> None:
        """测试工作流配置属性."""
        config = WorkflowConfig(directory=tmp_path)

        assert config.dist_dir == tmp_path / "dist"
        assert config.build_dir == tmp_path / ".cbuild"

    def test_workflow_solution_property(self, tmp_path: Path) -> None:
        """测试解决方案属性."""
        project_dir = tmp_path / "myapp"
        project_dir.mkdir()
        (project_dir / "pyproject.toml").write_text(
            '[project]\nname = "myapp"\nversion = "1.0.0"'
        )

        config = WorkflowConfig(directory=tmp_path)
        workflow = PackageWorkflow(root_dir=tmp_path, config=config)

        solution = workflow.solution
        assert len(solution.projects) == 1
        assert "myapp" in solution.projects

    def test_find_executable(self, tmp_path: Path) -> None:
        """测试查找可执行文件."""
        build_dir = tmp_path / ".cbuild"
        build_dir.mkdir()

        # 创建可执行文件
        exe = build_dir / "myapp.exe"
        exe.touch()

        config = WorkflowConfig(directory=tmp_path)
        workflow = PackageWorkflow(root_dir=tmp_path, config=config)

        found = workflow._find_executable("myapp")
        assert found == exe

    def test_find_executable_nested(self, tmp_path: Path) -> None:
        """测试查找嵌套的可执行文件."""
        build_dir = tmp_path / ".cbuild"
        project_build = build_dir / "src" / "myapp"
        project_build.mkdir(parents=True)

        exe = project_build / "myapp.exe"
        exe.touch()

        config = WorkflowConfig(directory=tmp_path)
        workflow = PackageWorkflow(root_dir=tmp_path, config=config)

        found = workflow._find_executable("myapp")
        assert found == exe

    def test_find_executable_not_found(self, tmp_path: Path) -> None:
        """测试找不到可执行文件."""
        config = WorkflowConfig(directory=tmp_path)
        workflow = PackageWorkflow(root_dir=tmp_path, config=config)

        found = workflow._find_executable("nonexistent")
        assert found is None

    @pytest.mark.parametrize(
        ("loader_type", "archive_type"),
        [("console", None), ("gui", None), ("console", "zip"), ("gui", "tar")],
    )
    def test_workflow_config_variants(
        self, tmp_path: Path, loader_type: str, archive_type: str | None
    ) -> None:
        """测试不同的工作流配置."""
        config = WorkflowConfig(
            directory=tmp_path, loader_type=loader_type, archive_type=archive_type
        )

        workflow = PackageWorkflow(root_dir=tmp_path, config=config)
        assert workflow.config.loader_type == loader_type
        assert workflow.config.archive_type == archive_type


class TestPyPackConfig:
    """PyPackConfig 测试."""

    def test_config_defaults(self) -> None:
        """测试配置默认值."""
        config = PyPackConfig()
        assert config.DEFAULT_PYTHON_VERSION == "3.8.10"
        assert config.DEFAULT_LOADER_TYPE == "console"
        assert config.DEFAULT_MIRROR == "aliyun"
        assert config.DEFAULT_MAX_WORKERS == 4

    def test_config_supported_formats(self) -> None:
        """测试支持的归档格式."""
        config = PyPackConfig()

        assert "zip" in config.ARCHIVE_FORMATS
        assert "7z" in config.ARCHIVE_FORMATS
        assert "tar" in config.ARCHIVE_FORMATS

    def test_config_supported_mirrors(self) -> None:
        """测试支持的镜像源."""
        config = PyPackConfig()

        assert "aliyun" in config.MIRRORS
        assert "tsinghua" in config.MIRRORS
        assert "pypi" in config.MIRRORS

    def test_config_loader_types(self) -> None:
        """测试支持的加载器类型."""
        config = PyPackConfig()

        assert "console" in config.LOADER_TYPES
        assert "gui" in config.LOADER_TYPES


class TestIntegration:
    """集成测试."""

    def test_full_workflow(self, tmp_path: Path) -> None:
        """测试完整工作流（不含实际下载）."""
        # 创建项目
        project_dir = tmp_path / "myapp"
        project_dir.mkdir()
        (project_dir / "pyproject.toml").write_text(
            '[project]\nname = "myapp"\nversion = "1.0.0"\ndescription = "Test app"'
        )
        (project_dir / "main.py").write_text('print("Hello")')

        config = WorkflowConfig(directory=tmp_path)
        workflow = PackageWorkflow(root_dir=tmp_path, config=config)

        # 测试列出项目
        workflow.list_projects()

        # 测试清理
        workflow.clean_project()

        # 应该不抛出异常
        assert True

    def test_workflow_with_archive(self, tmp_path: Path) -> None:
        """测试带归档的工作流配置."""
        config = WorkflowConfig(
            directory=tmp_path,
            archive_type="zip",
            python_version="3.10.0",
            loader_type="console",
        )

        PackageWorkflow(root_dir=tmp_path, config=config)

        assert config.archive_type == "zip"
        assert config.python_version == "3.10.0"

    def test_multiple_projects_workflow(self, tmp_path: Path) -> None:
        """测试多项目工作流."""
        # 创建多个项目
        for i in range(3):
            project_dir = tmp_path / f"project{i}"
            project_dir.mkdir()
            (project_dir / "pyproject.toml").write_text(
                f'[project]\nname = "project{i}"\nversion = "1.0.{i}"'
            )
            (project_dir / "main.py").write_text(f'print("Project {i}")')

        config = WorkflowConfig(directory=tmp_path)
        workflow = PackageWorkflow(root_dir=tmp_path, config=config)

        # 验证能扫描到所有项目
        solution = workflow.solution
        assert len(solution.projects) == 3

    def test_project_with_dependencies_workflow(self, tmp_path: Path) -> None:
        """测试带依赖的项目工作流."""
        project_dir = tmp_path / "myapp"
        project_dir.mkdir()
        (project_dir / "pyproject.toml").write_text(
            '[project]\nname = "myapp"\nversion = "1.0.0"\n'
            'dependencies = ["requests>=2.28.0", "numpy"]'
        )

        config = WorkflowConfig(directory=tmp_path)
        workflow = PackageWorkflow(root_dir=tmp_path, config=config)

        solution = workflow.solution
        project = solution.projects["myapp"]
        assert len(project.dependencies) == 2
        assert "requests>=2.28.0" in project.dependencies
