"""Configuration for widgets."""

# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'configdialog.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import resource_rc

class Ui_ConfigDialog(object):
    def setupUi(self, ConfigDialog):
        if not ConfigDialog.objectName():
            ConfigDialog.setObjectName(u"ConfigDialog")
        ConfigDialog.resize(720, 400)
        ConfigDialog.setMinimumSize(QSize(720, 400))
        self.verticalLayout = QVBoxLayout(ConfigDialog)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.tabWidget = QTabWidget(ConfigDialog)
        self.tabWidget.setObjectName(u"tabWidget")
        self.tabWidget.setMovable(False)
        self.tabUI = QWidget()
        self.tabUI.setObjectName(u"tabUI")
        self.horizontalLayout_3 = QHBoxLayout(self.tabUI)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.styles_tab = QGroupBox(self.tabUI)
        self.styles_tab.setObjectName(u"styles_tab")
        self.horizontalLayout_2 = QHBoxLayout(self.styles_tab)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.styles_list = QListView(self.styles_tab)
        self.styles_list.setObjectName(u"styles_list")

        self.horizontalLayout_2.addWidget(self.styles_list)


        self.horizontalLayout_3.addWidget(self.styles_tab)

        self.tabWidget.addTab(self.tabUI, "")
        self.tab = QWidget()
        self.tab.setObjectName(u"tab")
        self.horizontalLayout_4 = QHBoxLayout(self.tab)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.engines_list = QListView(self.tab)
        self.engines_list.setObjectName(u"engines_list")

        self.horizontalLayout_4.addWidget(self.engines_list)

        self.tabWidget.addTab(self.tab, "")
        self.rules_tab = QWidget()
        self.rules_tab.setObjectName(u"rules_tab")
        self.verticalLayout_3 = QVBoxLayout(self.rules_tab)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.rules_list = QListView(self.rules_tab)
        self.rules_list.setObjectName(u"rules_list")

        self.verticalLayout_3.addWidget(self.rules_list)

        self.tabWidget.addTab(self.rules_tab, "")
        self.ignore_dirs_tab = QWidget()
        self.ignore_dirs_tab.setObjectName(u"ignore_dirs_tab")
        self.verticalLayout_5 = QVBoxLayout(self.ignore_dirs_tab)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.ignore_dirs_list = QListView(self.ignore_dirs_tab)
        self.ignore_dirs_list.setObjectName(u"ignore_dirs_list")

        self.verticalLayout_5.addWidget(self.ignore_dirs_list)

        self.tabWidget.addTab(self.ignore_dirs_tab, "")
        self.ignore_extension_tab = QWidget()
        self.ignore_extension_tab.setObjectName(u"ignore_extension_tab")
        self.verticalLayout_7 = QVBoxLayout(self.ignore_extension_tab)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.ignore_extension_list = QListView(self.ignore_extension_tab)
        self.ignore_extension_list.setObjectName(u"ignore_extension_list")

        self.verticalLayout_7.addWidget(self.ignore_extension_list)

        self.tabWidget.addTab(self.ignore_extension_tab, "")

        self.verticalLayout.addWidget(self.tabWidget)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.spacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout.addItem(self.spacer)

        self.content_label = QLabel(ConfigDialog)
        self.content_label.setObjectName(u"content_label")

        self.horizontalLayout.addWidget(self.content_label)

        self.content_edit = QLineEdit(ConfigDialog)
        self.content_edit.setObjectName(u"content_edit")
        self.content_edit.setMinimumSize(QSize(0, 32))

        self.horizontalLayout.addWidget(self.content_edit)

        self.open_button = QPushButton(ConfigDialog)
        self.open_button.setObjectName(u"open_button")
        icon = QIcon()
        icon.addFile(u":/assets/icons/folder.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.open_button.setIcon(icon)
        self.open_button.setIconSize(QSize(32, 32))

        self.horizontalLayout.addWidget(self.open_button)

        self.add_button = QPushButton(ConfigDialog)
        self.add_button.setObjectName(u"add_button")
        icon1 = QIcon()
        icon1.addFile(u":/assets/icons/add.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.add_button.setIcon(icon1)
        self.add_button.setIconSize(QSize(32, 32))

        self.horizontalLayout.addWidget(self.add_button)

        self.remove_button = QPushButton(ConfigDialog)
        self.remove_button.setObjectName(u"remove_button")
        icon2 = QIcon()
        icon2.addFile(u":/assets/icons/remove.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.remove_button.setIcon(icon2)
        self.remove_button.setIconSize(QSize(32, 32))

        self.horizontalLayout.addWidget(self.remove_button)


        self.verticalLayout.addLayout(self.horizontalLayout)


        self.retranslateUi(ConfigDialog)

        self.tabWidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(ConfigDialog)
    # setupUi

    def retranslateUi(self, ConfigDialog):
        ConfigDialog.setWindowTitle(QCoreApplication.translate("ConfigDialog", u"\u8bbe\u7f6e", None))
        self.styles_tab.setTitle(QCoreApplication.translate("ConfigDialog", u"\u98ce\u683c", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tabUI), QCoreApplication.translate("ConfigDialog", u"\u754c\u9762", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab), QCoreApplication.translate("ConfigDialog", u"\u5206\u6790\u5f15\u64ce", None))
#if QT_CONFIG(tooltip)
        self.rules_list.setToolTip(QCoreApplication.translate("ConfigDialog", u"\u626b\u63cf\u89c4\u5219\u6e05\u5355\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.rules_tab), QCoreApplication.translate("ConfigDialog", u"\u89c4\u5219", None))
#if QT_CONFIG(tooltip)
        self.ignore_dirs_list.setToolTip(QCoreApplication.translate("ConfigDialog", u"\u6392\u9664\u7684\u6587\u4ef6\u5939\u6e05\u5355\uff0c\u5728\u5176\u4e2d\u7684\u6587\u4ef6\u5747\u76f4\u63a5\u8df3\u8fc7\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.ignore_dirs_tab), QCoreApplication.translate("ConfigDialog", u"\u6392\u9664\u6587\u4ef6\u5939", None))
#if QT_CONFIG(tooltip)
        self.ignore_extension_list.setToolTip(QCoreApplication.translate("ConfigDialog", u"\u6392\u9664\u7684\u6587\u4ef6\u540d\u6807\u8bc6\uff0c\u5305\u542b\u8be5\u6807\u8bc6\u7684\u6240\u6709\u6587\u4ef6\u4e00\u5f8b\u8df3\u8fc7\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.ignore_extension_tab), QCoreApplication.translate("ConfigDialog", u"\u6392\u9664\u6587\u4ef6\u7c7b\u578b", None))
        self.content_label.setText(QCoreApplication.translate("ConfigDialog", u"\u5185\u5bb9\uff1a", None))
#if QT_CONFIG(tooltip)
        self.content_edit.setToolTip(QCoreApplication.translate("ConfigDialog", u"\u589e\u52a0\u7684\u5185\u5bb9\u3002", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.open_button.setToolTip(QCoreApplication.translate("ConfigDialog", u"\u6253\u5f00\u6587\u4ef6\u76ee\u5f55\u4f5c\u4e3a\u5185\u5bb9\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.open_button.setText("")
#if QT_CONFIG(tooltip)
        self.add_button.setToolTip(QCoreApplication.translate("ConfigDialog", u"\u589e\u52a0\u9879\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.add_button.setText("")
#if QT_CONFIG(tooltip)
        self.remove_button.setToolTip(QCoreApplication.translate("ConfigDialog", u"\u5220\u9664\u9879\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.remove_button.setText("")
    # retranslateUi
