"""解析引擎可用性检测模块."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class EngineInfo:
    """解析引擎信息."""

    name: str
    description: str
    module_name: str
    file_extensions: list[str]
    optional: bool = True  # 是否为可选依赖


# 定义所有可用的解析引擎
ENGINES: list[EngineInfo] = [
    # PDF 解析引擎
    EngineInfo(
        name="PyMuPDF",
        description="高性能 PDF 和 XPS 文档解析库 (fitz)",
        module_name="fitz",
        file_extensions=["pdf"],
        optional=True,
    ),
    EngineInfo(
        name="pypdf",
        description="纯 Python PDF 解析库",
        module_name="pypdf",
        file_extensions=["pdf"],
        optional=True,
    ),
    # OCR 引擎
    EngineInfo(
        name="pytesseract",
        description="Tesseract OCR 引擎(图像文字识别)",
        module_name="pytesseract",
        file_extensions=["pdf", "jpg", "jpeg", "png", "gif", "bmp", "tiff"],
        optional=True,
    ),
    EngineInfo(
        name="PIL",
        description="Python Imaging Library (图像处理)",
        module_name="PIL",
        file_extensions=["jpg", "jpeg", "png", "gif", "bmp", "tiff"],
        optional=True,
    ),
    # Office 文档引擎
    EngineInfo(
        name="python-docx",
        description="Microsoft Word DOCX 文档解析",
        module_name="docx",
        file_extensions=["doc", "docx"],
        optional=True,
    ),
    EngineInfo(
        name="openpyxl",
        description="Microsoft Excel XLSX 文件解析",
        module_name="openpyxl",
        file_extensions=["xlsx", "xls"],
        optional=True,
    ),
    EngineInfo(
        name="python-pptx",
        description="Microsoft PowerPoint PPTX 演示文稿解析",
        module_name="pptx",
        file_extensions=["ppt", "pptx"],
        optional=True,
    ),
    # 其他文档格式
    EngineInfo(
        name="odfpy",
        description="OpenDocument Format (ODF) 解析",
        module_name="odf",
        file_extensions=["odt", "ods", "odp"],
        optional=True,
    ),
    EngineInfo(
        name="pyth",
        description="Rich Text Format (RTF) 解析",
        module_name="pyth",
        file_extensions=["rtf"],
        optional=True,
    ),
    EngineInfo(
        name="ebooklib",
        description="EPUB 电子书解析",
        module_name="ebooklib",
        file_extensions=["epub"],
        optional=True,
    ),
    EngineInfo(
        name="BeautifulSoup",
        description="HTML/XML 解析库",
        module_name="bs4",
        file_extensions=["html", "htm", "xml"],
        optional=True,
    ),
    # 压缩包引擎
    EngineInfo(
        name="rarfile",
        description="RAR 压缩包解析",
        module_name="rarfile",
        file_extensions=["rar"],
        optional=True,
    ),
    EngineInfo(name="py7zr", description="7Z 压缩包解析", module_name="py7zr", file_extensions=["7z"], optional=True),
]


def check_engine_availability(engine: EngineInfo) -> bool:
    """检查指定引擎是否可用.

    Args:
        engine: 引擎信息对象

    Returns
    -------
        如果引擎可用返回 True,否则返回 False
    """
    try:
        __import__(engine.module_name)
    except ImportError:
        return False
    else:
        return True


def get_available_engines() -> list[str]:
    """获取所有可用引擎的名称列表.

    Returns
    -------
        可用引擎名称列表
    """
    return [engine.name for engine in ENGINES if check_engine_availability(engine)]


def get_unavailable_engines() -> list[str]:
    """获取所有不可用引擎的名称列表.

    Returns
    -------
        不可用引擎名称列表
    """
    return [engine.name for engine in ENGINES if not check_engine_availability(engine)]


def get_engine_by_name(name: str) -> EngineInfo | None:
    """根据名称获取引擎信息.

    Args:
        name: 引擎名称

    Returns
    -------
        引擎信息对象,如果不存在则返回 None
    """
    for engine in ENGINES:
        if engine.name == name:
            return engine
    return None


def init_engine_config() -> tuple[list[str], list[str]]:
    """初始化引擎配置.

    Returns
    -------
        (可用引擎列表,默认启用的引擎列表)
    """
    available = get_available_engines()

    # 默认启用所有可用引擎
    default_enabled = available.copy()

    return available, default_enabled
