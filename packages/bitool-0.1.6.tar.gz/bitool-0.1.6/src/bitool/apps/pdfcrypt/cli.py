"""功能: 加密解密当前目录下的所有PDF文件.

本模块提供PDF文件加密和解密功能
支持强加密算法和批量处理
可配置密码和安全设置
"""

from __future__ import annotations

import argparse
import contextlib
from concurrent.futures import ThreadPoolExecutor, as_completed
from functools import partial
from pathlib import Path
from typing import Any, Callable, Final

import pypdf

from bitool.core import JsonConfig, logger

CWD: Final[Path] = Path.cwd()


__version__ = "1.0.0"
__build__ = "20260204"


class PDFCryptConfig(JsonConfig):
    """PDF加密解密操作配置"""

    MAX_WORKERS: int = 4
    MIN_PASSWORD_LENGTH: int = 6
    DEFAULT_PASSWORD: str = ""
    OUTPUT_SUFFIX_ENCRYPTED: str = ".enc.pdf"
    OUTPUT_SUFFIX_DECRYPTED: str = ".dec.pdf"


# Global configuration instance
conf = PDFCryptConfig()


def is_encrypted(filepath: Path) -> bool:
    """检查PDF文件是否已加密

    Args:
        filepath: PDF文件路径

    Returns
    -------
        bool: 文件已加密返回True, 否则返回False
    """
    try:
        return pypdf.PdfReader(filepath).is_encrypted
    except (OSError, ValueError, RuntimeError):
        logger.exception(f"检查加密状态失败 {filepath}")
        return False


def _validate_password_strength(password: str) -> None:
    """验证密码强度并在需要时记录警告

    Args:
        password: 待验证的密码
    """
    if len(password) < conf.MIN_PASSWORD_LENGTH:
        logger.warning(
            f"密码长度小于{conf.MIN_PASSWORD_LENGTH}字符, 建议使用更强的密码",
        )


def _setup_pdf_writer(reader: pypdf.PdfReader) -> pypdf.PdfWriter:
    """创建并配置包含读取器页面的PDF写入器

    Args:
        reader: 源PDF读取器

    Returns
    -------
        已配置的PDF写入器
    """
    writer = pypdf.PdfWriter()
    for page in reader.pages:
        writer.add_page(page)
    return writer


def _handle_output_file_conflict(filepath: Path) -> None:
    """如果输出文件已存在则记录警告

    Args:
        filepath: 目标文件路径
    """
    if filepath.exists():
        logger.warning(f"目标文件已存在, 将覆盖: {filepath}")


def _cleanup_resources(reader: pypdf.PdfReader | None = None, writer: pypdf.PdfWriter | None = None) -> None:
    """正确清理PDF资源

    Args:
        reader: 待关闭的PDF读取器
        writer: 待关闭的PDF写入器
    """
    if reader:
        with contextlib.suppress(Exception):
            reader.stream.close()
    # pypdf.PdfWriter has no explicit close method
    if writer:
        with contextlib.suppress(Exception):
            writer.close()


def encrypt_pdf(
    filepath: Path,
    password: str,
) -> tuple[Path, Path | None]:
    """加密单个PDF文件

    Args:
        filepath: 待加密的PDF文件路径
        password: 加密密码

    Returns
    -------
        包含原始文件路径和加密文件路径的元组(成功时)
    """
    # Validate password strength
    _validate_password_strength(password)

    reader = None
    writer = None
    enc_pdf_file = filepath.with_suffix(conf.OUTPUT_SUFFIX_ENCRYPTED)

    try:
        # 使用上下文管理器确保资源清理
        with filepath.open("rb") as input_file:
            reader = pypdf.PdfReader(input_file)
            writer = _setup_pdf_writer(reader)

            writer.encrypt(
                user_password=password,
                owner_password=password,
                use_128bit=True,
            )

            # 检查目标文件是否已存在
            _handle_output_file_conflict(enc_pdf_file)

            with enc_pdf_file.open("wb") as output_file:
                writer.write(output_file)
    except OSError:
        logger.exception(f"写入加密文件失败 [{enc_pdf_file.name}]")
        return filepath, None
    except (ValueError, RuntimeError):
        logger.exception(f"加密文件出错 [{filepath.name}]")
        return filepath, None
    else:
        logger.info(f"成功加密文件: {enc_pdf_file}")
        return filepath, enc_pdf_file
    finally:
        # 显式清理资源
        _cleanup_resources(reader, writer)


def _attempt_pdf_decryption(
    reader: pypdf.PdfReader,
    password: str,
    filepath: Path,
) -> bool:
    """尝试解密PDF文件并记录结果

    Args:
        reader: PDF读取器实例
        password: 解密密码
        filepath: PDF文件路径

    Returns
    -------
        解密成功返回True, 否则返回False
    """
    if reader.decrypt(password):
        logger.info(f"成功解密文件 [{filepath.name}]")
        return True
    logger.error(f"解密文件失败 [{filepath.name}], 密码错误")
    return False


def _copy_pdf_pages(reader: pypdf.PdfReader) -> pypdf.PdfWriter:
    """将读取器中的所有页面复制到新写入器

    Args:
        reader: 源PDF读取器

    Returns
    -------
        包含已复制页面的PDF写入器
    """
    writer = pypdf.PdfWriter()
    for page_num in range(len(reader.pages)):
        page = reader.pages[page_num]
        writer.add_page(page)
    return writer


def decrypt_pdf(
    filepath: Path,
    password: str,
) -> tuple[Path, Path | None]:
    """解密PDF文件

    Args:
        filepath: 待解密的PDF文件路径
        password: 解密密码

    Returns
    -------
        包含原始文件路径和解密文件路径的元组(成功时)
    """
    reader = None
    writer = None

    try:
        # 打开输入PDF文件
        with filepath.open("rb") as f:
            reader = pypdf.PdfReader(f)

            # 尝试解密文件
            if not _attempt_pdf_decryption(reader, password, filepath):
                return filepath, None

            # 创建新PDF写入器对象并复制页面
            writer = _copy_pdf_pages(reader)

            # 将解密后的PDF写入输出文件
            outfile = filepath.with_suffix(conf.OUTPUT_SUFFIX_DECRYPTED)

            # 检查目标文件是否已存在
            _handle_output_file_conflict(outfile)

            with outfile.open("wb") as output_file:
                writer.write(output_file)
                logger.info(f"已写入解密文件到 [{outfile}]")
                return filepath, outfile

    except OSError:
        logger.exception("写入解密文件失败")
        return filepath, None
    except (ValueError, RuntimeError):
        logger.exception(f"解密文件出错 [{filepath.name}]")
        return filepath, None
    finally:
        # 显式清理资源
        _cleanup_resources(reader, writer)


def list_pdf() -> tuple[list[Path], list[Path]]:
    """列出当前目录中的PDF文件

    Returns
    -------
        包含未加密和已加密PDF文件列表的元组
    """
    un_encrypted = [_ for _ in CWD.rglob("*.pdf") if not is_encrypted(_)]
    encrypted = [_ for _ in CWD.rglob("*.pdf") if is_encrypted(_)]

    logger.info(f"已加密文件: [green bold]{encrypted}")
    logger.info(f"未加密文件: [green bold]{un_encrypted}")
    return un_encrypted, encrypted


def run_batch(func: Callable[[Path], Any], files: list[Path]) -> None:
    """并发处理多个文件

    Args:
        func: 应用于每个文件的函数
        files: 待处理的文件列表
    """
    if not files:
        logger.info("无待处理文件")
        return

    logger.info(f"正在处理 {len(files)} 个文件...")

    with ThreadPoolExecutor(max_workers=conf.MAX_WORKERS) as executor:
        # 提交所有任务
        future_to_file = {executor.submit(func, file): file for file in files}

        # 处理已完成的任务
        for future in as_completed(future_to_file):
            file = future_to_file[future]
            try:
                result = future.result()
                if result[1]:  # 如果处理成功
                    logger.info(f"已完成: {file.name}")
                else:
                    logger.error(f"失败: {file.name}")
            except (OSError, RuntimeError, ValueError):
                logger.exception(f"处理 {file.name} 时出错")


def decrypt(password: str) -> None:
    """执行解密操作

    Args:
        password: 解密密码
    """
    _, encrypted_files = list_pdf()
    if not encrypted_files:
        logger.error(f"目录中未找到已加密的PDF文件: {CWD}")
        return

    dec_func = partial(decrypt_pdf, password=password)
    run_batch(dec_func, encrypted_files)


def encrypt(password: str) -> None:
    """执行加密操作

    Args:
        password: 加密密码
    """
    unencrypted_files, _ = list_pdf()
    if not unencrypted_files:
        logger.error(f"目录中未找到未加密的PDF文件: {CWD}")
        return

    enc_func = partial(encrypt_pdf, password=password)
    run_batch(enc_func, unencrypted_files)


def parse_args() -> argparse.Namespace:
    """解析命令行参数

    Returns
    -------
        已解析的参数命名空间
    """
    parser = argparse.ArgumentParser(
        description="加密解密当前目录中的PDF文件",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  pdfcrypt encrypt mypassword           # 加密所有未加密的PDF
  pdfcrypt decrypt mypassword           # 解密所有已加密的PDF
  pdfcrypt --help                       # 显示此帮助信息
        """,
    )

    parser.add_argument(
        "action",
        choices=["encrypt", "decrypt"],
        help="要执行的操作: 加密或解密PDF文件",
    )

    parser.add_argument("password", help="加密解密密")

    parser.add_argument(
        "--workers",
        type=int,
        default=4,
        help="并发工作线程数 (默认: 4)",
    )

    parser.add_argument(
        "-v",
        "--version",
        action="version",
        version=f"%(prog)s {__version__} (build {__build__})",
    )

    return parser.parse_args()


def main() -> None:
    """根据命令行参数运行加密解密操作"""
    args = parse_args()

    # 更新配置
    conf.MAX_WORKERS = args.workers
    conf.DEFAULT_PASSWORD = args.password

    # 执行请求的操作
    if args.action == "encrypt":
        encrypt(args.password)
    elif args.action == "decrypt":
        decrypt(args.password)
    else:
        logger.error(f"未知操作: {args.action}")


if __name__ == "__main__":
    main()
