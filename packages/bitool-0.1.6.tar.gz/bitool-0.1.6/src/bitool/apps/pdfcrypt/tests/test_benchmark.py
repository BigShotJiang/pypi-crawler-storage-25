"""pdfcrypt模块性能基准测试"""

from __future__ import annotations

import contextlib
import tempfile
from pathlib import Path
from typing import Generator

import pytest
from pypdf import PdfWriter

from ..cli import decrypt_pdf, encrypt_pdf


@pytest.fixture
def large_pdf_file() -> Generator[Path, None, None]:
    """创建较大的PDF文件用于性能测试"""
    with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp_file:
        writer = PdfWriter()
        # 创建多页PDF
        for _i in range(10):
            writer.add_blank_page(width=200, height=200)
        with Path(tmp_file.name).open("wb") as f:
            writer.write(f)
        file_path = Path(tmp_file.name)
        yield file_path
        # 清理 - 处理Windows文件锁定
        try:
            file_path.unlink(missing_ok=True)
        except PermissionError:
            # Windows上文件可能仍被锁定, 稍后重试
            import time

            time.sleep(0.1)
            with contextlib.suppress(PermissionError):
                file_path.unlink(missing_ok=True)


@pytest.fixture
def medium_pdf_file() -> Generator[Path, None, None]:
    """创建中等大小的PDF文件用于性能测试"""
    with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp_file:
        writer = PdfWriter()
        # 创建较少页面的PDF
        for _i in range(3):
            writer.add_blank_page(width=200, height=200)
        with Path(tmp_file.name).open("wb") as f:
            writer.write(f)
        file_path = Path(tmp_file.name)
        yield file_path
        # Cleanup - handle Windows file locking
        try:
            file_path.unlink(missing_ok=True)
        except PermissionError:
            # On Windows, file might still be locked, try again later
            import time

            time.sleep(0.1)
            with contextlib.suppress(PermissionError):
                file_path.unlink(missing_ok=True)


@pytest.fixture
def test_password() -> str:
    """提供用于加密解密操作的测试密码"""
    return "test_password_123"


class TestPerformanceBenchmarks:
    """性能基准测试"""

    @pytest.mark.benchmark(group="encryption")
    def test_encrypt_single_large_file(self, benchmark, large_pdf_file, test_password) -> None:
        """基准测试单个大PDF文件的加密"""

        def encrypt_operation() -> tuple[Path, Path | None]:
            return encrypt_pdf(large_pdf_file, test_password)

        result = benchmark(encrypt_operation)
        assert result[1] is not None  # Encrypted file should exist

    @pytest.mark.benchmark(group="encryption")
    def test_encrypt_single_medium_file(self, benchmark, medium_pdf_file, test_password) -> None:
        """基准测试单个中等PDF文件的加密"""

        def encrypt_operation() -> tuple[Path, Path | None]:
            return encrypt_pdf(medium_pdf_file, test_password)

        result = benchmark(encrypt_operation)
        assert result[1] is not None

    @pytest.mark.benchmark(group="decryption")
    def test_decrypt_single_file(self, benchmark, medium_pdf_file, test_password) -> None:
        """基准测试单个PDF文件的解密"""
        # 首先加密文件
        _, encrypted_file = encrypt_pdf(medium_pdf_file, test_password)
        assert encrypted_file is not None

        def decrypt_operation() -> tuple[Path, Path | None]:
            return decrypt_pdf(encrypted_file, test_password)

        result = benchmark(decrypt_operation)
        assert result[1] is not None  # Decrypted file should exist

    @pytest.mark.benchmark(group="operations")
    def test_complete_encrypt_decrypt_cycle(self, benchmark, medium_pdf_file, test_password) -> None:
        """基准测试完整的加密解密循环"""

        def complete_cycle() -> Path | None:
            # Encrypt
            _, encrypted = encrypt_pdf(medium_pdf_file, test_password)
            if encrypted is None:
                return None
            # Decrypt
            _, decrypted = decrypt_pdf(encrypted, test_password)
            return decrypted

        result = benchmark(complete_cycle)
        assert result is not None

    @pytest.mark.benchmark(group="memory")
    def test_memory_usage_during_encryption(self, benchmark, large_pdf_file, test_password) -> None:
        """基准测试加密期间的内存使用"""

        def encrypt_with_memory_tracking() -> tuple:
            return encrypt_pdf(large_pdf_file, test_password)

        result = benchmark(encrypt_with_memory_tracking)
        assert result[1] is not None


class TestScalability:
    """处理多文件的可扩展性测试"""

    @pytest.mark.parametrize("file_count", [1, 5, 10])
    @pytest.mark.benchmark(group="batch_processing")
    def test_multiple_file_encryption(self, benchmark, tmp_path: Path, file_count, test_password) -> None:
        """基准测试多文件加密"""
        files = []

        # 创建多个PDF文件
        for i in range(file_count):
            pdf_path = tmp_path / f"test_{i}.pdf"
            writer = PdfWriter()
            writer.add_blank_page(width=100, height=100)
            with Path(pdf_path).open("wb") as f:
                writer.write(f)
            files.append(pdf_path)

        def batch_encrypt() -> list[tuple[Path, Path | None]]:
            results = []
            for pdf_file in files:
                result = encrypt_pdf(pdf_file, test_password)
                results.append(result)
            return results

        results = benchmark(batch_encrypt)
        # 验证所有操作成功
        assert all(result[1] is not None for result in results)
