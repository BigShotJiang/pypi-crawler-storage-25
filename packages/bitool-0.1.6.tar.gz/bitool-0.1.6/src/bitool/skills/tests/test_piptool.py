"""pip工具模块的单元测试。

测试 piptool.py 中的各种命令操作, 包括安装、重新安装、下载、冻结依赖、卸载和升级pip。
"""

from __future__ import annotations

from typing import Generator
from unittest.mock import MagicMock, patch

import pytest

from bitool.cmd import RunCommand, RunShellCommand
from bitool.skills.piptool import PipTool, PipToolConfig


@pytest.fixture
def mock_scheduler() -> Generator[MagicMock, None, None]:
    """创建模拟的命令调度器。"""
    with patch("bitool.skills.piptool.CommandScheduler") as mock:
        mock_instance = MagicMock()
        mock.return_value = mock_instance
        yield mock_instance


@pytest.fixture
def mock_run_command() -> Generator[MagicMock, None, None]:
    """创建模拟的RunCommand。"""
    with patch("bitool.skills.piptool.RunCommand") as mock:
        yield mock


@pytest.fixture
def mock_run_shell_command() -> Generator[MagicMock, None, None]:
    """创建模拟的RunShellCommand。"""
    with patch("bitool.skills.piptool.RunShellCommand") as mock:
        yield mock


class TestPipToolConfig:
    """测试 PipToolConfig 配置类。"""

    def test_trusted_host(self) -> None:
        """测试可信主机配置。"""
        assert PipToolConfig.TRUSTED_HOST == [
            "--trusted-host",
            "mirrors.aliyun.com",
            "--index-url",
            "http://mirrors.aliyun.com/pypi/simple/",
        ]

    def test_package_dir(self) -> None:
        """测试包目录配置。"""
        assert PipToolConfig.PACKAGE_DIR == "packages"

    def test_requirements_file(self) -> None:
        """测试依赖文件配置。"""
        assert PipToolConfig.REQUIREMENTS_FILE == "requirements.txt"

    def test_config_instance(self) -> None:
        """测试配置实例。"""
        from bitool.skills.piptool import conf

        assert isinstance(conf, PipToolConfig)


class TestCreateSchedulerMap:
    """测试 PipTool 调度器。"""

    def test_create_default_scheduler_map(self) -> None:
        """测试创建默认的命令调度器映射。"""
        tool = PipTool()

        # 验证所有预期的操作都存在
        expected_keys = {"i", "r", "d", "f", "u", "up"}
        assert set(tool.list_commands()) == expected_keys

    @pytest.mark.parametrize(
        ("libnames", "use_requirements", "offline"),
        [
            (["requests"], False, False),
            (["requests", "flask"], False, True),
            (None, True, False),
            (None, True, True),
            ([], False, False),
        ],
    )
    def test_scheduler_map_with_different_params(
        self, libnames: list[str] | None, use_requirements: bool, offline: bool
    ) -> None:
        """测试不同参数组合下的调度器创建。"""
        tool = PipTool()
        tool._set_params(
            libnames or [], offline=offline, use_requirements=use_requirements
        )

        # 验证所有操作键都能获取调度器
        for action in ["i", "r", "d", "f", "u", "up"]:
            scheduler = tool.get_scheduler(action)
            assert scheduler is not None

    def test_install_command_with_libnames(self) -> None:
        """测试安装命令 - 使用库名列表。"""
        libnames = ["requests", "flask"]
        tool = PipTool()
        tool._set_params(libnames, offline=False)

        # 验证安装命令被正确创建
        install_scheduler = tool.get_scheduler("i")
        assert install_scheduler is not None
        assert len(install_scheduler.commands) == 1

        # 验证命令参数
        cmd = install_scheduler.commands[0]
        assert isinstance(cmd, RunCommand)
        assert isinstance(cmd.cmd, list)
        assert cmd.cmd[0] == "pip"
        assert cmd.cmd[1] == "install"
        # 应该包含可信主机和库名
        assert "--trusted-host" in cmd.cmd
        assert "requests" in cmd.cmd
        assert "flask" in cmd.cmd

    def test_install_command_offline(self) -> None:
        """测试离线模式安装命令。"""
        libnames = ["requests"]
        tool = PipTool()
        tool._set_params(libnames, offline=True)

        install_scheduler = tool.get_scheduler("i")
        assert install_scheduler is not None
        cmd = install_scheduler.commands[0]
        assert isinstance(cmd, RunCommand)
        assert isinstance(cmd.cmd, list)
        # 离线模式应该使用 --no-index 和 --find-links
        assert "--no-index" in cmd.cmd
        assert "--find-links" in cmd.cmd
        assert "." in cmd.cmd

    def test_install_command_with_requirements(self) -> None:
        """测试使用 requirements 文件的安装命令。"""
        tool = PipTool()
        tool._set_params([], use_requirements=True, offline=False)

        install_scheduler = tool.get_scheduler("i")
        assert install_scheduler is not None
        cmd = install_scheduler.commands[0]
        assert isinstance(cmd, RunCommand)
        assert isinstance(cmd.cmd, list)
        # 应该包含 -r 和 requirements.txt
        assert "-r" in cmd.cmd
        assert "requirements.txt" in cmd.cmd

    def test_reinstall_command(self) -> None:
        """测试重新安装命令。"""
        libnames = ["requests", "flask"]
        tool = PipTool()
        tool._set_params(libnames, offline=False)

        reinstall_scheduler = tool.get_scheduler("r")
        assert reinstall_scheduler is not None
        assert len(reinstall_scheduler.commands) == 2

        # 第一个命令应该是卸载
        uninstall_cmd = reinstall_scheduler.commands[0]
        assert isinstance(uninstall_cmd, RunCommand)
        assert isinstance(uninstall_cmd.cmd, list)
        assert uninstall_cmd.cmd[0] == "pip"
        assert uninstall_cmd.cmd[1] == "uninstall"
        assert "-y" in uninstall_cmd.cmd
        assert "requests" in uninstall_cmd.cmd
        assert "flask" in uninstall_cmd.cmd

        # 第二个命令应该是安装
        install_cmd = reinstall_scheduler.commands[1]
        assert isinstance(install_cmd, RunCommand)
        assert isinstance(install_cmd.cmd, list)
        assert install_cmd.cmd[0] == "pip"
        assert install_cmd.cmd[1] == "install"

    def test_download_command(self) -> None:
        """测试下载命令。"""
        libnames = ["requests"]
        tool = PipTool()
        tool._set_params(libnames, offline=False)

        download_scheduler = tool.get_scheduler("d")
        assert download_scheduler is not None
        assert len(download_scheduler.commands) == 1

        cmd = download_scheduler.commands[0]
        assert isinstance(cmd, RunCommand)
        assert isinstance(cmd.cmd, list)
        assert cmd.cmd[0] == "pip"
        assert cmd.cmd[1] == "download"
        assert "-d" in cmd.cmd
        assert "packages" in cmd.cmd  # PACKAGE_DIR

    def test_freeze_command(self) -> None:
        """测试冻结依赖命令。"""
        tool = PipTool()
        tool._set_params([], offline=False)

        freeze_scheduler = tool.get_scheduler("f")
        assert freeze_scheduler is not None
        assert len(freeze_scheduler.commands) == 1

        cmd = freeze_scheduler.commands[0]
        assert isinstance(cmd, RunShellCommand)
        # RunShellCommand 接收字符串命令
        assert "pip freeze" in cmd.shell_cmd
        assert "--exclude-editable" in cmd.shell_cmd
        assert "requirements.txt" in cmd.shell_cmd

    def test_uninstall_command(self) -> None:
        """测试卸载命令。"""
        libnames = ["requests", "flask"]
        tool = PipTool()
        tool._set_params(libnames)

        uninstall_scheduler = tool.get_scheduler("u")
        assert uninstall_scheduler is not None
        assert len(uninstall_scheduler.commands) == 1

        cmd = uninstall_scheduler.commands[0]
        assert isinstance(cmd, RunCommand)
        assert isinstance(cmd.cmd, list)
        assert cmd.cmd[0] == "pip"
        assert cmd.cmd[1] == "uninstall"
        assert "-y" in cmd.cmd
        assert "requests" in cmd.cmd
        assert "flask" in cmd.cmd

    def test_uninstall_command_with_wildcard(self) -> None:
        """测试卸载命令 - 通配符模式。"""
        libnames = ["pytola*"]
        tool = PipTool()
        tool._set_params(libnames)

        # Mock _get_installed_packages 返回一些测试数据
        with patch.object(
            tool,
            "_get_installed_packages",
            return_value=["pytola-core", "pytola-utils", "requests", "flask"],
        ):
            uninstall_scheduler = tool.get_scheduler("u")
            assert uninstall_scheduler is not None
            assert len(uninstall_scheduler.commands) == 1

            cmd = uninstall_scheduler.commands[0]
            assert isinstance(cmd, RunCommand)
            assert isinstance(cmd.cmd, list)
            assert cmd.cmd[0] == "pip"
            assert cmd.cmd[1] == "uninstall"
            assert "-y" in cmd.cmd
            # 应该匹配到 pytola-core 和 pytola-utils
            assert "pytola-core" in cmd.cmd
            assert "pytola-utils" in cmd.cmd
            # 不应该包含不匹配的包
            assert "requests" not in cmd.cmd
            assert "flask" not in cmd.cmd

    def test_uninstall_command_with_multiple_wildcards(self) -> None:
        """测试卸载命令 - 多个通配符模式。"""
        libnames = ["pytola*", "test*"]
        tool = PipTool()
        tool._set_params(libnames)

        # Mock _get_installed_packages 返回一些测试数据
        with patch.object(
            tool,
            "_get_installed_packages",
            return_value=[
                "pytola-core",
                "pytola-utils",
                "test-lib",
                "test-utils",
                "requests",
            ],
        ):
            uninstall_scheduler = tool.get_scheduler("u")
            assert uninstall_scheduler is not None
            assert len(uninstall_scheduler.commands) == 1

            cmd = uninstall_scheduler.commands[0]
            assert isinstance(cmd, RunCommand)
            assert isinstance(cmd.cmd, list)
            assert cmd.cmd[0] == "pip"
            assert cmd.cmd[1] == "uninstall"
            assert "-y" in cmd.cmd
            # 应该匹配到所有匹配的包
            assert "pytola-core" in cmd.cmd
            assert "pytola-utils" in cmd.cmd
            assert "test-lib" in cmd.cmd
            assert "test-utils" in cmd.cmd
            # 不应该包含不匹配的包
            assert "requests" not in cmd.cmd

    def test_uninstall_command_with_no_match(self) -> None:
        """测试卸载命令 - 无匹配的情况。"""
        libnames = ["nonexistent*"]
        tool = PipTool()
        tool._set_params(libnames)

        # Mock _get_installed_packages 返回一些测试数据，但没有匹配的
        with patch.object(
            tool, "_get_installed_packages", return_value=["requests", "flask"]
        ):
            uninstall_scheduler = tool.get_scheduler("u")
            assert uninstall_scheduler is not None
            # 没有匹配的包，应该返回空命令列表
            assert len(uninstall_scheduler.commands) == 0

    def test_uninstall_command_case_insensitive(self) -> None:
        """测试卸载命令 - 不区分大小写。"""
        libnames = ["PYTOLA*"]
        tool = PipTool()
        tool._set_params(libnames)

        # Mock _get_installed_packages 返回一些测试数据（小写）
        with patch.object(
            tool,
            "_get_installed_packages",
            return_value=["pytola-core", "pytola-utils", "requests"],
        ):
            uninstall_scheduler = tool.get_scheduler("u")
            assert uninstall_scheduler is not None
            assert len(uninstall_scheduler.commands) == 1

            cmd = uninstall_scheduler.commands[0]
            assert isinstance(cmd, RunCommand)
            assert isinstance(cmd.cmd, list)
            assert cmd.cmd[0] == "pip"
            assert cmd.cmd[1] == "uninstall"
            assert "-y" in cmd.cmd
            # 应该匹配到（不区分大小写）
            assert "pytola-core" in cmd.cmd
            assert "pytola-utils" in cmd.cmd

    def test_upgrade_pip_command(self) -> None:
        """测试升级 pip 命令。"""
        tool = PipTool()
        tool._set_params([], offline=False)

        upgrade_scheduler = tool.get_scheduler("up")
        assert upgrade_scheduler is not None
        assert len(upgrade_scheduler.commands) == 1

        cmd = upgrade_scheduler.commands[0]
        assert isinstance(cmd, RunCommand)
        assert isinstance(cmd.cmd, list)
        assert cmd.cmd[0] == "python"
        assert cmd.cmd[1] == "-m"
        assert cmd.cmd[2] == "pip"
        assert cmd.cmd[3] == "install"
        assert "--upgrade" in cmd.cmd
        assert "pip" in cmd.cmd


class TestMain:
    """测试 main 函数。"""

    def test_main_install_with_libnames(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """测试主函数 - 安装命令。"""
        import sys

        import bitool.skills.piptool as piptool_module

        # 模拟命令行参数
        monkeypatch.setattr(sys, "argv", ["piptool", "i", "requests"])

        # 模拟 scheduler.run
        with patch.object(piptool_module.CommandScheduler, "run") as mock_run:
            piptool_module.main()
            mock_run.assert_called_once()

    def test_main_reinstall_with_libnames(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """测试主函数 - 重新安装命令。"""
        import sys

        import bitool.skills.piptool as piptool_module

        monkeypatch.setattr(sys, "argv", ["piptool", "r", "requests", "flask"])

        with patch.object(piptool_module.CommandScheduler, "run") as mock_run:
            piptool_module.main()
            mock_run.assert_called_once()

    def test_main_download_with_libnames(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """测试主函数 - 下载命令。"""
        import sys

        import bitool.skills.piptool as piptool_module

        monkeypatch.setattr(sys, "argv", ["piptool", "d", "requests", "--offline"])

        with patch.object(piptool_module.CommandScheduler, "run") as mock_run:
            piptool_module.main()
            mock_run.assert_called_once()

    def test_main_freeze(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """测试主函数 - 冻结依赖命令。"""
        import sys

        import bitool.skills.piptool as piptool_module

        monkeypatch.setattr(sys, "argv", ["piptool", "f"])

        with patch.object(piptool_module.CommandScheduler, "run") as mock_run:
            piptool_module.main()
            mock_run.assert_called_once()

    def test_main_uninstall(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """测试主函数 - 卸载命令。"""
        import sys

        import bitool.skills.piptool as piptool_module

        monkeypatch.setattr(sys, "argv", ["piptool", "u", "requests"])

        with patch.object(piptool_module.CommandScheduler, "run") as mock_run:
            piptool_module.main()
            mock_run.assert_called_once()

    def test_main_upgrade_pip(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """测试主函数 - 升级 pip 命令。"""
        import sys

        import bitool.skills.piptool as piptool_module

        monkeypatch.setattr(sys, "argv", ["piptool", "up"])

        with patch.object(piptool_module.CommandScheduler, "run") as mock_run:
            piptool_module.main()
            mock_run.assert_called_once()

    def test_main_install_without_libnames_raises_error(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """测试主函数 - 安装时未指定库名应抛出错误。"""
        import sys

        import bitool.skills.piptool as piptool_module

        monkeypatch.setattr(sys, "argv", ["piptool", "i"])

        with pytest.raises(
            ValueError, match="请指定要安装的库名称，或使用 --requirements 参数"
        ):
            piptool_module.main()

    def test_main_install_with_requirements_flag(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """测试主函数 - 使用 requirements 标志的安装命令。"""
        import sys

        import bitool.skills.piptool as piptool_module

        monkeypatch.setattr(sys, "argv", ["piptool", "i", "--requirements"])

        with patch.object(piptool_module.CommandScheduler, "run") as mock_run:
            piptool_module.main()
            mock_run.assert_called_once()

    def test_main_invalid_action_raises_error(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """测试主函数 - 无效操作应抛出错误。"""
        import sys

        import bitool.skills.piptool as piptool_module

        # 注意: argparse 会在 parse_args 时就报错，所以直接测试 argv
        monkeypatch.setattr(sys, "argv", ["piptool", "invalid", "requests"])

        # argparse 会调用 sys.exit(2) 对于无效的选择
        with pytest.raises(SystemExit):
            piptool_module.main()

    def test_main_offline_mode(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """测试主函数 - 离线模式。"""
        import sys

        import bitool.skills.piptool as piptool_module

        monkeypatch.setattr(sys, "argv", ["piptool", "i", "requests", "-o"])

        with patch.object(piptool_module.CommandScheduler, "run") as mock_run:
            piptool_module.main()
            mock_run.assert_called_once()
