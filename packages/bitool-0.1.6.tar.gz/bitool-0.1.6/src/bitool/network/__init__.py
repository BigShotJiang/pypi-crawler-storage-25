"""pytola-core 的网络模块."""

from .url import urlopen_safe

__all__ = ["urlopen_safe"]
