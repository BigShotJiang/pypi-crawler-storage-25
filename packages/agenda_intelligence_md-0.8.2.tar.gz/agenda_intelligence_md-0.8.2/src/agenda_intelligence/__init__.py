"""Agenda Intelligence package."""

__version__ = "0.8.2"
