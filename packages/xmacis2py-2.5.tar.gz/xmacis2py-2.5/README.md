![image](https://github.com/user-attachments/assets/fb5ecdf9-bd51-4243-be7d-92af0952bfd8) ![image](https://github.com/user-attachments/assets/da1b43c0-2b6a-4a5c-9eb4-f08b30cab42b)

[![Conda Version](https://img.shields.io/conda/vn/conda-forge/xmacis2py.svg)](https://anaconda.org/conda-forge/xmacis2py)
![PyPI - Version](https://img.shields.io/pypi/v/xmacis2py)
<a href="https://anaconda.org/conda-forge/xmacis2py"> <img src="https://anaconda.org/conda-forge/xmacis2py/badges/latest_release_date.svg" /> </a>
<a href="https://anaconda.org/conda-forge/xmacis2py"> <img src="https://anaconda.org/conda-forge/xmacis2py/badges/platforms.svg" /> </a>
<a href="https://anaconda.org/conda-forge/xmacis2py"> <img src="https://anaconda.org/conda-forge/xmacis2py/badges/license.svg" /> </a>
[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.18227996.svg)](https://doi.org/10.5281/zenodo.18227996)

[![Conda Recipe](https://img.shields.io/badge/recipe-xmacis2py-green.svg)](https://anaconda.org/conda-forge/xmacis2py)


Anaconda Downloads:

[![Conda Downloads](https://img.shields.io/conda/dn/conda-forge/xmacis2py.svg)](https://anaconda.org/conda-forge/xmacis2py)

PIP Downloads:

![PyPI - Downloads](https://img.shields.io/pypi/dm/xmacis2py)

# xmACIS2Py

***(C) Eric J. Drewitz 2025-2026***

***ANNOUNCEMENT: xmACIS2Py < 2.0 is now depreciated and replaced with xmACIS2Py >= 2.0***

**How To Install**

Copy and paste either command into your terminal or anaconda prompt:

*Install via Anaconda*

`conda install xmacis2py`

*Install via pip*

`pip install xmacis2py`

**How To Update To The Latest Version**

Copy and paste either command into your terminal or anaconda prompt:

*Update via Anaconda*

***This is for users who initially installed xmACIS2Py through Anaconda***

`conda update xmacis2py`

*Update via pip*

***This is for users who initially installed xmACIS2Py through pip***

`pip install --upgrade xmacis2py`

### Documentation and Jupyter Lab Examples

**xmACIS2Py 2.0 Series Documentation and Jupyter Lab Tutorials**

**Jupyter Lab Tutorials**

1) [Data Access & Analysis](https://github.com/edrewitz/xmACIS2Py-Jupyter-Lab-Tutorials/blob/main/Tutorials/xmacis_analysis.ipynb)
2) [Graphical Summaries](https://github.com/edrewitz/xmACIS2Py-Jupyter-Lab-Tutorials/blob/main/Tutorials/xmacis_graphics.ipynb)
3) [Multi-Station Data Retrieval](https://github.com/edrewitz/xmACIS2Py-Jupyter-Lab-Tutorials/blob/main/Tutorials/acis_multi_station.ipynb)
4) [Retrieving Station Meta-Data](https://github.com/edrewitz/xmACIS2Py-Jupyter-Lab-Tutorials/blob/main/Tutorials/station_meta.ipynb)
5) [Retrieving 30-Year Climatological Normals and Departures From Normal](https://github.com/edrewitz/xmACIS2Py-Jupyter-Lab-Tutorials/blob/main/Tutorials/xmacis_normal_departure.ipynb)
6) [Calculating Daily Normals and Performing Analysis of ENSO Analog Years at KJFK](https://github.com/edrewitz/xmACIS2Py-Jupyter-Lab-Tutorials/blob/main/Tutorials/jfk_analysis.ipynb)
7) [Creating an ENSO Analog Composite for Temperatures Across the Pacific Northwest (Plotting xmACIS2 Data on a Map)](https://github.com/edrewitz/xmACIS2Py-Jupyter-Lab-Tutorials/blob/main/Tutorials/enso_study.ipynb)
8) [Creating an ENSO Analog Composite for Precipitation Across California and Nevada (Plotting xmACIS2 Data on a Map)](https://github.com/edrewitz/xmACIS2Py-Jupyter-Lab-Tutorials/blob/main/Tutorials/enso_precip.ipynb)

**Documentation**

***Data Access***

1) [Get Single Station Data](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/data_access.md#get_single_station_acis_data)
2) [Get Multi Station Data](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/data_access.md#get_multi_station_acis_data)
3) [Get Single Station Climate Normals](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/data_access.md#get_single_station_climate_normals)
4) [Get Multi Station Climate Normals](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/data_access.md#get_multi_station_climate_normals)
5) [Get Single Station Departures From Normal](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/data_access.md#get_single_station_departures)
6) [Get Multi Station Departures From Normal](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/data_access.md#get_multi_station_departures)
7) [Get Single Station Meta-Data](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/single_station_meta.md#single-station-meta-data)
8) [Get Multi Station Meta-Data](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/multi_station_meta.md#multi-station-meta-data)

***Analysis Tools***

1) [Period Mean](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/analysis_tools.md#period_mean)
2) [Period Median](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/analysis_tools.md#period_median)
3) [Period Mode](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/analysis_tools.md#period_mode)
4) [Period Percentile](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/analysis_tools.md#period_percentile)
5) [Period Standard Deviation](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/analysis_tools.md#period_standard_deviation)
6) [Period Variance](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/analysis_tools.md#period_variance)
7) [Period Skewness](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/analysis_tools.md#period_skewness)
8) [Period Kurtosis](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/analysis_tools.md#period_kurtosis)
9) [Period Maximum](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/analysis_tools.md#period_maximum)
10) [Period Minimum](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/analysis_tools.md#period_minimum)
11) [Period Sum](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/analysis_tools.md#period_sum)
12) [Period Rankings](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/analysis_tools.md#period_rankings)
13) [Running Sum](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/analysis_tools.md#running_sum)
14) [Running Mean](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/analysis_tools.md#running_mean)
15) [Detrend Data](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/analysis_tools.md#detrend_data)
16) [Number of Missing Days](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/analysis_tools.md#number_of_missing_days)
17) [Number of Days At Or Below Value](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/analysis_tools.md#number_of_days_at_or_below_value)
18) [Number of Days At Or Above Value](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/analysis_tools.md#number_of_days_at_or_above_value)
19) [Number of Days Below Value](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/analysis_tools.md#number_of_days_below_value)
20) [Number of Days Above Value](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/analysis_tools.md#number_of_days_above_value)
21) [Number of Days At Value](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/analysis_tools.md#number_of_days_at_value)
22) [Calculate Daily Normals](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/analysis_tools.md#calculate_daily_normals)
23) [Filter Analog Years](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/analysis_tools.md#filter_analog_years)
24) [Calculate Weighted Mean For Analog Years](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/analysis_tools.md#analog_weighted_mean)
25) [Calculate Weighted Percentile For Analog Years](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/analysis_tools.md#analog_weighted_percentile)
26) [Calculate Daily Departures From Normal](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/analysis_tools.md#calculate_daily_departures)

***Graphical Summaries***

1) [Compreheisive Temperature Summary](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/compreheisive_summary.md#comprehensive-temperature-summary)
2) [Maximum Temperature Summary](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/maximum_temperature_summary.md#maximum-temperature-summary)
3) [Minimum Temperature Summary](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/minimum_temperature_summary.md#minimum-temperature-summary)
4) [Average Temperature Summary](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/average_temperature_summary.md#average-temperature-summary)
5) [Average Temperature Departure Summary](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/average_temperature_departure_summary.md#average-temperature-departure-summary)
6) [Heating Degree Day Summary](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/heating_degree_day_summary.md#heating-degree-day-summary)
7) [Cooling Degree Day Summary](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/cooling_degree_day_summary.md#cooling-degree-day-summary)
8) [Growing Degree Day Summary](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/growing_degree_day_summary.md#growing-degree-day-summary)
9) [Precipitation Summary](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS2.0/precipitation_summary.md#precipitation-summary)


***xmACIS2Py Imports***

    """
    xmACIS2Py is a Python package that performs various statistical operations on ACIS2 Climate Data.
    
    xmACIS2Py also is a graphics library of various different xmACIS2 stat graphics.
    
    xmACIS2Py is powered by the xmACIS2 client in the WxData Python Library
    
    For more information on the xmACIS2 Client in the WxData Library, visit: https://pypi.org/project/wxdata/
    
    (C) Eric J. Drewitz 2025-2026
    """
    
    
    # This is the module to create xmACIS2 temperature graphics
    import xmacis2py.graphics.temperature as temperature
    
    # This is the module to create xmACIS2 precipitation graphics
    import xmacis2py.graphics.precipitation as precipitation
    
    # ACIS2 Data Access
    # - Single ACIS Station Data
    # - Multi ACIS Station Data
    # - Single ACIS Station 30-Year Climate Normals
    # - Multi ACIS Station 30-Year Climate Normals
    # - Single ACIS Station Departures from Normal
    # - Multi ACIS Station Departures from Normal.
    from xmacis2py.data_access.station_data import(
        get_single_station_acis_data,
        get_multi_station_acis_data,
        get_single_station_climate_normals,
        get_multi_station_climate_normals,
        get_single_station_departures,
        get_multi_station_departures
    )
    
    # ACIS2 Station Meta-Data
    # - Single Station
    # - Multi Station
    from xmacis2py.data_access.station_meta import (
        single_station_meta,
        multi_station_meta
    )
    
    
    """
    Module
    -------
    
    xmacis2py.analysis_tools.analysis
    
    Functions:
    - number_of_days_at_value
    - number_of_days_above_value
    - number_of_days_below_value
    - number_of_days_at_or_below_value
    - number_of_days_at_or_above_value
    - number_of_missing_days
    - period_mean
    - period_median
    - period_standard_deviation
    - period_mode
    - period_variance
    - period_skewness
    - period_kurtosis
    - period_maximum
    - period_minimum
    - period_sum
    - period_rankings
    - running_sum
    - running_mean
    - calculate_daily_normals
    - filter_analog_years
    - analog_weighted_mean
    - analog_weighted_percentile
    - calculate_daily_departures
    """
    import xmacis2py.analysis_tools.analysis as analysis



**Documentation For Legacy Users**

*[xmACIS2Py 1.0 Series (Depreciated/Legacy) Documentation and Jupyter Lab Tutorials](https://github.com/edrewitz/xmACIS2Py/blob/main/Documentation/xmACIS1.0/user_docs.md)*


#### References


1) **xmACIS2**: https://www.rcc-acis.org/docs_webservices.html 

2) **MetPy**: May, R. M., Goebbert, K. H., Thielen, J. E., Leeman, J. R., Camron, M. D., Bruick, Z., Bruning, E. C., Manser, R. P., Arms, S. C., and Marsh, P. T., 2022: MetPy: A Meteorological Python Library for Data Analysis and Visualization. Bull. Amer. Meteor. Soc., 103, E2273-E2284, https://doi.org/10.1175/BAMS-D-21-0125.1.

3) **NumPy**: Harris, C.R., Millman, K.J., van der Walt, S.J. et al. Array programming with NumPy. Nature 585, 357–362 (2020). DOI: 10.1038/s41586-020-2649-2. (Publisher link).

4) **Pandas**: Pandas: McKinney, W., & others. (2010). Data structures for statistical computing in python. In Proceedings of the 9th Python in Science Conference (Vol. 445, pp. 51–56).

5) **WxData**: Eric J. Drewitz. (2026). edrewitz/WxData: WxData 1.6 Released (WxData1.6). Zenodo. https://doi.org/10.5281/zenodo.19644125

6) **scipy**: Virtanen, P., Gommers, R., Oliphant, T.E. et al. SciPy 1.0: fundamental algorithms for scientific computing in Python. Nat Methods 17, 261–272 (2020). https://doi.org/10.1038/s41592-019-0686-2

7) **requests**: K. Reitz, "Requests: HTTP for Humans". Available: https://requests.readthedocs.io/.
