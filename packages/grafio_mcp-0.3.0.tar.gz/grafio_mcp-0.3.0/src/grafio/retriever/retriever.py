"""Main retrieval orchestrator — ties classifier, traversal, scoring, and assembly together."""

from __future__ import annotations

import time
import uuid
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..config import RetrievalConfig
    from ..db.connection import Database

from ..models import QueryTier
from ..server.schemas import (
    AnchorInfo,
    ContextNode,
    ContextQueryRequest,
    ContextQueryResponse,
    GitSignals,
    ImpactAnalysisRequest,
    ImpactAnalysisResponse,
    ImpactedNode,
    QueryStats,
    RelationshipPath,
)
from .anchoring import find_anchor_node
from .classifier import classify_query
from .context_assembler import assemble_context
from .graph_traversal import traverse, traverse_reverse
from .scorer import score_candidates


class Retriever:
    def __init__(self, db: Database, config: RetrievalConfig, root_paths: dict[str, Path]):
        self.db = db
        self.config = config
        self.root_paths = root_paths  # repo_id -> root path

    async def query(self, request: ContextQueryRequest) -> ContextQueryResponse:
        start = time.monotonic()
        root_path = self.root_paths.get(request.repo_id, Path("."))

        # 1. Find anchor node
        line = request.cursor_line or (
            request.selection.start_line if request.selection else 1
        )
        anchor = await find_anchor_node(self.db, request.repo_id, request.file_path, line)
        if not anchor:
            raise ValueError(f"No node found at {request.file_path}:{line}")

        # 2. Classify query
        tier = classify_query(request.query, anchor["kind"], request.options.tier)

        # 3. Retrieve based on tier with tighter limits
        include_tests = "test" in request.query.lower()

        if tier == QueryTier.LOCAL:
            candidates = await traverse(
                self.db,
                request.repo_id,
                [anchor["id"]],
                max_depth=1,
                max_candidates=8,
                include_tests=include_tests,
            )
            effective_max_nodes = min(request.options.max_nodes, 5)
        elif tier == QueryTier.NEIGHBORHOOD:
            candidates = await traverse(
                self.db,
                request.repo_id,
                [anchor["id"]],
                max_depth=2,
                max_candidates=30,
                include_tests=include_tests,
            )
            effective_max_nodes = min(request.options.max_nodes, 12)
        else:  # CROSS_CUTTING
            forward = await traverse(
                self.db,
                request.repo_id,
                [anchor["id"]],
                max_depth=3,
                max_candidates=80,
                include_tests=include_tests,
            )
            reverse = await traverse_reverse(
                self.db, request.repo_id, anchor["id"], max_depth=3
            )
            candidates = forward + reverse
            effective_max_nodes = min(request.options.max_nodes, 25)

        # 4. Score
        embedding_scores: dict[int, float] = {}
        scored = score_candidates(
            candidates, embedding_scores, request.query, self.config.scoring_weights
        )

        # 5. Assemble context bundle
        bundle = await assemble_context(
            anchor,
            scored,
            request.query,
            self.db,
            root_path,
            max_tokens=request.options.max_token_budget,
            max_nodes=effective_max_nodes,
            detail=request.options.detail,
        )

        # 6. Build response
        request_id = str(uuid.uuid4())
        query_time = int((time.monotonic() - start) * 1000)

        return ContextQueryResponse(
            request_id=request_id,
            tier=tier.value,
            anchor=AnchorInfo(
                node_id=anchor["id"],
                kind=anchor["kind"],
                fq_name=anchor["fq_name"],
                file_path=anchor["file_path"],
                start_line=anchor["start_line"],
                end_line=anchor["end_line"],
            ),
            high_level_summary=bundle["high_level_summary"],
            nodes=[
                ContextNode(
                    node_id=n["id"],
                    kind=n["kind"],
                    fq_name=n["fq_name"],
                    name=n["name"],
                    file_path=n["file_path"],
                    start_line=n["start_line"],
                    end_line=n["end_line"],
                    language=n["language"],
                    signature=n.get("signature"),
                    summary=n.get("summary"),
                    code_snippet=n.get("code_snippet"),
                    relevance_score=n.get("relevance_score", 0),
                    git_signals=GitSignals(
                        last_modified=n.get("last_modified_at"),
                        modification_count=n.get("modification_count", 0),
                        primary_author=n.get("primary_author"),
                    ),
                )
                for n in bundle["nodes"]
            ],
            paths=[
                RelationshipPath(
                    from_node=p["from_node"],
                    to_node=p["to_node"],
                    relations=p["relations"],
                    confidence=p["confidence"],
                )
                for p in bundle["paths"]
            ],
            stats=QueryStats(
                total_candidates=len(candidates),
                nodes_returned=len(bundle["nodes"]),
                estimated_tokens=bundle["estimated_tokens"],
                query_time_ms=query_time,
                retrieval_method=tier.value,
            ),
        )

    async def impact_analysis(self, request: ImpactAnalysisRequest) -> ImpactAnalysisResponse:
        """Analyze the impact of changing a node — who depends on it."""
        # Find the target node
        if request.node_id:
            target = await self.db.fetchone(
                "SELECT * FROM nodes WHERE id = ?", (request.node_id,)
            )
        elif request.file_path and request.line:
            target = await find_anchor_node(
                self.db, request.repo_id, request.file_path, request.line
            )
        elif request.symbol:
            target = await self.db.fetchone(
                "SELECT * FROM nodes WHERE repo_id = ? AND (fq_name = ? OR name = ?) LIMIT 1",
                (request.repo_id, request.symbol, request.symbol),
            )
        else:
            raise ValueError("Provide node_id, file_path+line, or symbol")

        if not target:
            raise ValueError("Target node not found")

        # Reverse traversal to find dependents
        candidates = await traverse_reverse(
            self.db, request.repo_id, target["id"], max_depth=request.depth
        )

        impacted = [
            ImpactedNode(
                node_id=c.node["id"],
                kind=c.node["kind"],
                fq_name=c.node["fq_name"],
                file_path=c.node["file_path"],
                start_line=c.node["start_line"],
                end_line=c.node["end_line"],
                impact_type=c.path[-1][0] if c.path else "unknown",
                distance=c.distance,
            )
            for c in candidates
        ]

        impact_paths = [
            RelationshipPath(
                from_node=c.path[0][1] if c.path else target["id"],
                to_node=c.node["id"],
                relations=[ek for ek, _ in c.path],
                confidence=c.max_edge_confidence,
            )
            for c in candidates
            if c.path
        ]

        files_affected = len({n.file_path for n in impacted})
        summary = (
            f"Changing `{target['fq_name']}` could impact {len(impacted)} symbols "
            f"across {files_affected} files up to {request.depth} hops away."
        )

        return ImpactAnalysisResponse(
            target_node=AnchorInfo(
                node_id=target["id"],
                kind=target["kind"],
                fq_name=target["fq_name"],
                file_path=target["file_path"],
                start_line=target["start_line"],
                end_line=target["end_line"],
            ),
            impacted_nodes=impacted,
            impact_paths=impact_paths,
            summary=summary,
        )
