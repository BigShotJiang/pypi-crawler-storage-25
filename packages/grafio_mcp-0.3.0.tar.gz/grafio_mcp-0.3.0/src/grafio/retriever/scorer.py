"""Hybrid scoring — ranks traversal candidates using multiple signals."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..config import ScoringWeights


@dataclass
class ScoredCandidate:
    node: dict
    total_score: float
    graph_distance_score: float
    embedding_similarity_score: float
    git_recency_score: float
    git_cochange_score: float
    node_kind_boost: float
    path: list[tuple[str, int]]
    max_edge_confidence: str = "high"


def _is_sibling_via_class(path: list[tuple[str, int]]) -> bool:
    """Check if this candidate was reached by going UP to a class then DOWN."""
    if len(path) < 2:
        return False
    # Pattern: consecutive OWNS edges indicate up-to-class then down-to-sibling
    edge_kinds = [p[0] for p in path]
    for i in range(len(edge_kinds) - 1):
        if edge_kinds[i] == "OWNS" and edge_kinds[i + 1] == "OWNS":
            return True
    return False


NODE_KIND_SCORES: dict[str, float] = {
    "function": 1.0,
    "method": 1.0,
    "class": 0.8,
    "struct": 0.8,
    "interface": 0.8,
    "trait": 0.8,
    "route": 0.9,
    "enum": 0.6,
    "type_alias": 0.6,
    "variable": 0.4,
    "constant": 0.4,
    "test": 0.3,
    "file": 0.1,
    "module": 0.2,
    "decorator": 0.5,
    "external": 0.3,
}


def score_candidates(
    candidates: list,  # list[TraversalCandidate]
    embedding_scores: dict[int, float],  # node_id -> similarity
    query: str,
    weights: ScoringWeights,
    now: datetime | None = None,
) -> list[ScoredCandidate]:
    """Score and rank candidates using hybrid signals."""
    if now is None:
        now = datetime.now(UTC)

    scored: list[ScoredCandidate] = []
    for c in candidates:
        node = c.node

        # 1. Graph distance score — exponential decay so depth-2 is clearly
        # separated from depth-1 (0.5 vs 0.25 instead of old 0.5 vs 0.33)
        graph_score = 1.0 / (2**c.distance)
        if c.max_edge_confidence == "high":
            graph_score *= 1.2

        # 2. Embedding similarity
        embed_score = embedding_scores.get(node["id"], 0.0)

        # 3. Git recency
        git_recency = 0.0
        if node.get("last_modified_at"):
            try:
                modified = datetime.fromisoformat(node["last_modified_at"])
                days = (now - modified).days
                git_recency = 1.0 / (1.0 + days / 30.0)
            except (ValueError, TypeError):
                pass

        # 4. Git co-change (captured in edge kind during traversal)
        cochange = 0.0
        for edge_kind, _ in c.path:
            if edge_kind == "CO_CHANGES":
                cochange = 0.8
                break

        # 5. Node kind boost
        kind_boost = NODE_KIND_SCORES.get(node["kind"], 0.5)
        if "test" in query.lower() and node.get("is_test"):
            kind_boost = 1.0

        total = (
            weights.graph_distance * graph_score
            + weights.embedding_similarity * embed_score
            + weights.git_recency * git_recency
            + weights.git_cochange * cochange
            + weights.node_kind_boost * kind_boost
        )

        # PENALTY: Sibling methods reached via class traversal
        if _is_sibling_via_class(c.path):
            total *= 0.15  # 85% penalty — siblings are almost always noise

        scored.append(
            ScoredCandidate(
                node=node,
                total_score=total,
                graph_distance_score=graph_score,
                embedding_similarity_score=embed_score,
                git_recency_score=git_recency,
                git_cochange_score=cochange,
                node_kind_boost=kind_boost,
                path=c.path,
                max_edge_confidence=c.max_edge_confidence,
            )
        )

    scored.sort(key=lambda s: s.total_score, reverse=True)
    return scored
