"""Weight tuning from user feedback — adjusts scoring weights based on positive/negative signals."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from ..config import ScoringWeights

if TYPE_CHECKING:
    from ..db.connection import Database


class RetrievalTuner:
    def __init__(self, db: Database) -> None:
        self.db = db

    async def analyze_feedback(
        self, repo_id: str, min_samples: int = 20
    ) -> ScoringWeights | None:
        """Analyze feedback and suggest weight adjustments.

        Returns tuned weights if enough samples exist, None otherwise.
        """
        feedback = await self.db.fetchall(
            "SELECT * FROM feedback WHERE repo_id = ? ORDER BY created_at DESC LIMIT 200",
            (repo_id,),
        )
        if len(feedback) < min_samples:
            return None

        positive = [f for f in feedback if f["rating"] == 2]
        negative = [f for f in feedback if f["rating"] == 1]

        if not positive or not negative:
            return None

        # Analyze what's different between positive and negative feedback
        pos_stats = await self._compute_context_stats(repo_id, positive)
        neg_stats = await self._compute_context_stats(repo_id, negative)

        # Start from current weights
        weights = ScoringWeights()
        delta = 0.05

        # Adjust graph_distance: if positive results had closer nodes, boost it
        if pos_stats["avg_distance"] < neg_stats["avg_distance"]:
            weights.graph_distance = min(0.5, weights.graph_distance + delta)
        else:
            weights.graph_distance = max(0.1, weights.graph_distance - delta)

        # Adjust git_recency: if positive results were more recent, boost it
        if pos_stats["avg_recency"] > neg_stats["avg_recency"]:
            weights.git_recency = min(0.4, weights.git_recency + delta)

        # Adjust git_cochange: if positive results had more co-change signal, boost it
        if pos_stats["avg_cochange"] > neg_stats["avg_cochange"]:
            weights.git_cochange = min(0.3, weights.git_cochange + delta)

        # Normalize weights to sum to 1.0
        total = (
            weights.graph_distance
            + weights.embedding_similarity
            + weights.git_recency
            + weights.git_cochange
            + weights.node_kind_boost
        )
        if total > 0:
            weights.graph_distance /= total
            weights.embedding_similarity /= total
            weights.git_recency /= total
            weights.git_cochange /= total
            weights.node_kind_boost /= total

        return weights

    async def _compute_context_stats(
        self, repo_id: str, feedback_items: list[dict[str, Any]]
    ) -> dict[str, float]:
        """Compute aggregate stats about context nodes in a feedback set."""
        total_distance = 0.0
        total_recency = 0.0
        total_cochange = 0.0
        count = 0

        now = datetime.now(UTC)

        for item in feedback_items:
            node_ids: list[int] = json.loads(item["context_node_ids"])
            anchor_id = item["anchor_node_id"]
            if anchor_id is None:
                continue

            for nid in node_ids:
                node = await self.db.fetchone(
                    "SELECT * FROM nodes WHERE id = ?", (nid,)
                )
                if not node:
                    continue

                # Distance from anchor (via direct edge)
                edge = await self.db.fetchone(
                    "SELECT * FROM edges WHERE repo_id = ? AND src_node_id = ? AND dst_node_id = ?",
                    (repo_id, anchor_id, nid),
                )
                total_distance += 1 if edge else 3
                count += 1

                # Recency signal
                if node.get("last_modified_at"):
                    try:
                        days = (
                            now - datetime.fromisoformat(node["last_modified_at"])
                        ).days
                        total_recency += 1.0 / (1.0 + days / 30.0)
                    except (ValueError, TypeError):
                        pass

                # Co-change signal
                cochange = await self.db.fetchone(
                    "SELECT weight FROM edges WHERE repo_id = ? "
                    "AND kind = 'CO_CHANGES' AND "
                    "((src_node_id = ? AND dst_node_id = ?) "
                    "OR (src_node_id = ? AND dst_node_id = ?))",
                    (repo_id, anchor_id, nid, nid, anchor_id),
                )
                if cochange:
                    total_cochange += cochange["weight"]

        count = max(count, 1)
        return {
            "avg_distance": total_distance / count,
            "avg_recency": total_recency / count,
            "avg_cochange": total_cochange / count,
        }

    async def apply_weights(self, repo_id: str, weights: ScoringWeights) -> None:
        """Store tuned weights as a repo config override."""
        config_json = json.dumps({"scoring_weights": weights.model_dump()})
        await self.db.execute(
            "UPDATE repositories SET config = ? WHERE id = ?",
            (config_json, repo_id),
        )
        await self.db.commit()

    async def get_repo_weights(self, repo_id: str) -> ScoringWeights:
        """Load repo-specific tuned weights, falling back to defaults."""
        repo = await self.db.fetchone(
            "SELECT config FROM repositories WHERE id = ?", (repo_id,)
        )
        if repo and repo.get("config"):
            try:
                config = json.loads(repo["config"])
                if "scoring_weights" in config:
                    return ScoringWeights(**config["scoring_weights"])
            except (json.JSONDecodeError, TypeError):
                pass
        return ScoringWeights()

    async def get_feedback_summary(self, repo_id: str) -> dict[str, str | int]:
        """Get a summary of feedback for a repo."""
        total = await self.db.fetchone(
            "SELECT COUNT(*) as count FROM feedback WHERE repo_id = ?",
            (repo_id,),
        )
        positive = await self.db.fetchone(
            "SELECT COUNT(*) as count FROM feedback WHERE repo_id = ? AND rating = 2",
            (repo_id,),
        )
        negative = await self.db.fetchone(
            "SELECT COUNT(*) as count FROM feedback WHERE repo_id = ? AND rating = 1",
            (repo_id,),
        )
        return {
            "repo_id": repo_id,
            "total_feedback": total["count"] if total else 0,
            "positive": positive["count"] if positive else 0,
            "negative": negative["count"] if negative else 0,
        }
