"""Query tier classifier — routes queries to LOCAL, NEIGHBORHOOD, or CROSS_CUTTING."""

from __future__ import annotations

from ..models import QueryTier

LOCAL_KEYWORDS = [
    # Existing
    "what does this",
    "explain this",
    "document this",
    "summarize this",
    "what is this",
    "refactor this",
    "optimize this",
    "add types to this",
    "type this",
    "annotate this",
    # Targeted trace / flow questions about a specific symbol
    "show me this",
    "trace this",
    "walk through this",
    "step through this",
    "step by step",
    "this method",
    "this function",
    "this class",
    "how does this method",
    "how does this function",
    "what does this method",
    "what does this function",
    "what does this do",
    "how does this work",
    "what happens in this",
    "what happens here",
    "flow of this method",
    "flow of this function",
    "line by line",
    "walk me through",
    "break down this",
    "breakdown of this",
    "logic of this",
    "logic in this",
    "this specific",
    "just this",
    "only this method",
    "only this function",
    # Debug / fix targeted questions
    "fix this",
    "bug in this",
    "error in this",
    "why does this",
    "why is this",
    "what's wrong with this",
    "what is wrong with this",
]

CROSS_CUTTING_KEYWORDS = [
    # Existing
    "impact",
    "break",
    "who uses",
    "all callers",
    "all references",
    "depend on",
    "end to end",
    "architecture",
    "entire flow",
    "trace the",
    "what will break",
    "affect",
    "downstream",
    "upstream",
    "across",
    "microservice",
    "every",
    "all files",
    # Broad discovery questions
    "everywhere",
    "all places",
    "entire codebase",
    "whole project",
    "across the project",
    "how many places",
    "find all",
    "list all",
    "complete flow",
    "full lifecycle",
    "from start to finish",
    "request lifecycle",
    "from the api to the database",
    "from controller to database",
    "from http to db",
]


def classify_query(query: str, anchor_kind: str, tier_override: str = "auto") -> QueryTier:
    """Classify a query into a retrieval tier."""
    if tier_override != "auto":
        return QueryTier(tier_override)

    q = query.lower()

    # Check cross-cutting first (broader intent overrides local phrasing)
    if any(k in q for k in CROSS_CUTTING_KEYWORDS):
        return QueryTier.CROSS_CUTTING

    # Check local (targeted questions about a specific symbol)
    if any(k in q for k in LOCAL_KEYWORDS):
        return QueryTier.LOCAL

    # Heuristic — if query mentions a specific file or line number,
    # it's probably a targeted (local) question
    if "line " in q or "line:" in q or ".ts:" in q or ".py:" in q or ".java:" in q:
        return QueryTier.LOCAL

    # Default to neighborhood
    return QueryTier.NEIGHBORHOOD
