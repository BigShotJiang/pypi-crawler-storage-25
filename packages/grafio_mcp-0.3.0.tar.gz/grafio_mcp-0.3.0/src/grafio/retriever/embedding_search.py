"""Embedding-based semantic search for retrieval augmentation."""

from __future__ import annotations

import struct
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..db.connection import Database


def cosine_similarity(a: list[float], b: list[float]) -> float:
    """Compute cosine similarity between two vectors."""
    dot = sum(x * y for x, y in zip(a, b, strict=True))
    mag_a = sum(x * x for x in a) ** 0.5
    mag_b = sum(x * x for x in b) ** 0.5
    if mag_a == 0 or mag_b == 0:
        return 0.0
    return dot / (mag_a * mag_b)


def decode_vector(blob: bytes, dimensions: int) -> list[float]:
    """Decode a BLOB-stored float32 vector."""
    return list(struct.unpack(f"{dimensions}f", blob))


async def search_by_embedding(
    db: Database,
    repo_id: str,
    query_vector: list[float],
    dimensions: int,
    top_k: int = 50,
) -> dict[int, float]:
    """Return node_id -> similarity scores for top-k nearest embeddings.

    This is a brute-force scan suitable for small-to-medium repos.
    For large repos, consider an ANN index (e.g. faiss).
    """
    rows = await db.fetchall(
        "SELECT node_id, vector FROM embeddings WHERE repo_id = ?",
        (repo_id,),
    )

    scores: list[tuple[int, float]] = []
    for row in rows:
        vec = decode_vector(row["vector"], dimensions)
        sim = cosine_similarity(query_vector, vec)
        scores.append((row["node_id"], sim))

    scores.sort(key=lambda x: x[1], reverse=True)
    return {node_id: sim for node_id, sim in scores[:top_k]}
