"""BFS graph traversal for collecting context candidates."""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..db.connection import Database

from ..models import EdgeKind


@dataclass
class TraversalCandidate:
    node: dict
    distance: int
    path: list[tuple[str, int]] = field(default_factory=list)  # (edge_kind, node_id) per hop
    max_edge_confidence: str = "high"
    arrived_via: str | None = None  # edge kind that brought us here


# Edge types to follow, in priority order
FORWARD_EDGE_KINDS = [
    EdgeKind.CALLS,
    EdgeKind.IMPLEMENTS,
    EdgeKind.EXTENDS,
    EdgeKind.USES_TYPE,
    EdgeKind.OWNS,
    EdgeKind.IMPORTS,
    EdgeKind.CO_CHANGES,
    EdgeKind.TESTS,
]


async def traverse(
    db: Database,
    repo_id: str,
    anchor_ids: list[int],
    max_depth: int = 2,
    max_candidates: int = 50,
    include_tests: bool = False,
) -> list[TraversalCandidate]:
    """BFS traversal from anchor node(s), collecting candidates."""
    visited: set[int] = set(anchor_ids)
    candidates: list[TraversalCandidate] = []

    # frontier items: (node_id, depth, path, arrived_via_edge_kind)
    frontier: deque[tuple[int, int, list[tuple[str, int]], str | None]] = deque(
        [(nid, 0, [], None) for nid in anchor_ids]
    )

    while frontier and len(candidates) < max_candidates:
        node_id, depth, path, arrived_via = frontier.popleft()

        if depth >= max_depth:
            continue

        # Get outgoing and incoming edges
        outgoing = await db.fetchall(
            """SELECT e.id AS edge_id, e.dst_node_id AS neighbor_id,
                      e.kind AS edge_kind, e.confidence, e.weight
               FROM edges e
               WHERE e.repo_id = ? AND e.src_node_id = ?
               ORDER BY e.weight DESC""",
            (repo_id, node_id),
        )
        incoming = await db.fetchall(
            """SELECT e.id AS edge_id, e.src_node_id AS neighbor_id,
                      e.kind AS edge_kind, e.confidence, e.weight
               FROM edges e
               WHERE e.repo_id = ? AND e.dst_node_id = ?
               ORDER BY e.weight DESC""",
            (repo_id, node_id),
        )

        # Process edges with direction-aware filtering
        all_edges: list[dict] = []
        for e in outgoing:
            all_edges.append({**e, "direction": "outgoing"})
        for e in incoming:
            all_edges.append({**e, "direction": "incoming"})

        depth_cap = 15 if depth == 0 else 25
        added_this_level = 0

        for edge in all_edges:
            if added_this_level >= depth_cap:
                break
            if len(candidates) >= max_candidates:
                break

            neighbor_id = edge["neighbor_id"]
            edge_kind = edge["edge_kind"]
            direction = edge["direction"]

            if neighbor_id in visited:
                continue

            # ========================================
            # CRITICAL: Sibling traversal prevention
            # ========================================

            # Rule 1: If we arrived at this node via OWNS (going UP from method to class),
            #          do NOT follow OWNS edges going DOWN (class to other methods).
            #          This prevents: anchor → class → sibling1, sibling2, sibling3...
            if arrived_via == "OWNS_UP" and edge_kind == "OWNS" and direction == "outgoing":
                continue

            # Rule 2: Following OWNS upward (method → class) is only useful from
            #          the anchor itself (depth 0). Don't go up again from depth > 0.
            if edge_kind == "OWNS" and direction == "incoming" and depth > 0:
                continue

            # Rule 3: Track whether this is an OWNS-UP traversal
            if edge_kind == "OWNS" and direction == "incoming":
                next_arrived_via = "OWNS_UP"
            else:
                next_arrived_via = edge_kind

            # ========================================
            # Standard pruning rules
            # ========================================

            neighbor = await db.fetchone(
                "SELECT * FROM nodes WHERE id = ?", (neighbor_id,)
            )
            if not neighbor:
                continue

            # Skip file-level and external nodes (no useful content)
            if neighbor["kind"] in ("file", "external"):
                continue

            # Skip test nodes unless query is about tests
            if neighbor["is_test"] and not include_tests:
                continue

            # Skip utility functions with very high fan-in (called by > 50 things)
            fan_in = await db.fetchone(
                "SELECT COUNT(*) as cnt FROM edges"
                " WHERE repo_id = ? AND dst_node_id = ?"
                " AND kind = 'CALLS'",
                (repo_id, neighbor_id),
            )
            if fan_in and fan_in["cnt"] > 50:
                continue

            visited.add(neighbor_id)
            new_path = path + [(edge_kind, neighbor_id)]

            candidate = TraversalCandidate(
                node=neighbor,
                distance=depth + 1,
                path=new_path,
                max_edge_confidence=edge["confidence"],
                arrived_via=next_arrived_via,
            )
            candidates.append(candidate)
            added_this_level += 1

            # Only add to frontier for further expansion if it's worth following
            if added_this_level < depth_cap:
                frontier.append((neighbor_id, depth + 1, new_path, next_arrived_via))

    return candidates


async def traverse_reverse(
    db: Database,
    repo_id: str,
    target_id: int,
    max_depth: int = 3,
) -> list[TraversalCandidate]:
    """Reverse traversal — follow incoming edges only."""
    visited: set[int] = {target_id}
    candidates: list[TraversalCandidate] = []
    frontier: deque[tuple[int, int, list[tuple[str, int]]]] = deque(
        [(target_id, 0, [])]
    )

    while frontier:
        node_id, depth, path = frontier.popleft()
        if depth >= max_depth:
            continue

        edges = await db.fetchall(
            """SELECT e.id AS edge_id, e.src_node_id, e.dst_node_id,
                      e.kind AS edge_kind, e.confidence, e.weight
               FROM edges e
               WHERE e.repo_id = ? AND e.dst_node_id = ?
                 AND e.kind IN (
                     'CALLS', 'IMPLEMENTS', 'USES_TYPE',
                     'TESTS', 'CO_CHANGES'
                 )
               ORDER BY e.weight DESC LIMIT 30""",
            (repo_id, node_id),
        )

        for edge in edges:
            caller_id = edge["src_node_id"]
            if caller_id in visited:
                continue

            caller = await db.fetchone(
                "SELECT * FROM nodes WHERE id = ?", (caller_id,)
            )
            if not caller:
                continue

            visited.add(caller_id)
            new_path = path + [(edge["edge_kind"], caller_id)]
            candidates.append(
                TraversalCandidate(
                    node=caller,
                    distance=depth + 1,
                    path=new_path,
                    max_edge_confidence=edge["confidence"],
                )
            )
            frontier.append((caller_id, depth + 1, new_path))

    return candidates
