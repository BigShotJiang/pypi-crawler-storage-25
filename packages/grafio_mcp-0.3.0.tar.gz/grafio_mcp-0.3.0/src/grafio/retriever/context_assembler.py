"""Context assembler — builds token-budget-aware context bundles."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pathlib import Path

    from ..db.connection import Database


def estimate_tokens(text: str) -> int:
    """Rough token estimation: ~4 chars per token for code."""
    return len(text) // 4


async def load_snippet(
    file_path: str,
    start_line: int,
    end_line: int,
    root_path: Path,
    context_lines: int = 3,
) -> str:
    """Load code snippet from file with optional context lines."""
    full_path = root_path / file_path
    if not full_path.exists():
        return ""
    lines = full_path.read_text(errors="replace").splitlines()
    start = max(0, start_line - 1 - context_lines)
    end = min(len(lines), end_line + context_lines)
    snippet_lines: list[str] = []
    for i in range(start, end):
        snippet_lines.append(f"{i + 1:4d} | {lines[i]}")
    return "\n".join(snippet_lines)


async def assemble_context(
    anchor: dict,
    scored_candidates: list,
    query: str,
    db: Database,
    root_path: Path,
    max_tokens: int = 8000,
    max_nodes: int = 25,
    detail: str = "code",
) -> dict:
    """Assemble a context bundle from scored candidates, respecting token budget.

    detail: "code" returns full code snippets, "signatures" returns only signatures.
    """
    signatures_only = detail == "signatures"
    bundle_nodes: list[dict] = []
    paths: list[dict] = []
    token_budget_used = 0

    # Anchor: full snippet in code mode, signature in signatures mode
    if signatures_only:
        anchor_snippet = anchor.get("signature") or anchor["name"]
    else:
        anchor_snippet = await load_snippet(
            anchor["file_path"], anchor["start_line"], anchor["end_line"], root_path
        )
    anchor_tokens = estimate_tokens(anchor_snippet)
    token_budget_used += anchor_tokens

    bundle_nodes.append(
        {
            **anchor,
            "code_snippet": anchor_snippet,
            "relevance_score": 1.0,
        }
    )

    # Sort candidates: depth-1 first, then depth-2+, within each group by score.
    # This ensures direct calls always get full snippets before transitive
    # dependencies start competing for token budget.
    sorted_candidates = sorted(
        scored_candidates,
        key=lambda sc: (len(sc.path), -sc.total_score),
    )

    # Add candidates in priority order
    seen_ids: set[int] = {anchor["id"]}
    anchor_file = anchor["file_path"]

    for sc in sorted_candidates[:max_nodes]:
        node = sc.node
        if node["id"] in seen_ids:
            continue
        seen_ids.add(node["id"])

        node_lines = node["end_line"] - node["start_line"] + 1

        # Skip parent class/module if anchor is already a method inside it —
        # the anchor snippet already shows the relevant code, and including
        # the entire class just dumps hundreds of lines of sibling methods.
        if (
            node["kind"] in ("class", "module", "struct", "interface")
            and node["file_path"] == anchor_file
            and node["start_line"] <= anchor["start_line"]
            and node["end_line"] >= anchor["end_line"]
        ):
            # Include as signature-only so the class name is visible
            sig = node.get("signature") or f"{node['kind']} {node['name']}"
            sig_tokens = estimate_tokens(sig)
            if token_budget_used + sig_tokens <= max_tokens:
                token_budget_used += sig_tokens
                bundle_nodes.append(
                    {**node, "code_snippet": sig, "relevance_score": sc.total_score}
                )
            continue

        # Signatures-only mode: skip code loading entirely
        if signatures_only:
            snippet = node.get("signature") or node["name"]
            snippet_tokens = estimate_tokens(snippet)
            if token_budget_used + snippet_tokens > max_tokens:
                continue
            token_budget_used += snippet_tokens
            bundle_nodes.append(
                {**node, "code_snippet": snippet, "relevance_score": sc.total_score}
            )
            if sc.path:
                paths.append(
                    {
                        "from_node": anchor["id"],
                        "to_node": node["id"],
                        "relations": [ek for ek, _ in sc.path],
                        "confidence": sc.max_edge_confidence,
                    }
                )
            continue

        # Determine snippet strategy based on remaining budget
        if token_budget_used < max_tokens * 2 // 3:
            # Full snippet if we have budget room
            snippet = await load_snippet(
                node["file_path"],
                node["start_line"],
                node["end_line"],
                root_path,
                context_lines=1,
            )
        elif token_budget_used < max_tokens * 9 // 10:
            # Compact: cap at 30 lines with context
            cap = min(node["end_line"], node["start_line"] + 30)
            snippet = await load_snippet(
                node["file_path"],
                node["start_line"],
                cap,
                root_path,
                context_lines=0,
            )
            remaining = node_lines - 30
            if remaining > 0:
                snippet += f"\n  ... ({remaining} more lines)"
        else:
            # Minimal: signature or name when nearly out of budget
            snippet = node.get("signature") or node["name"]

        snippet_tokens = estimate_tokens(snippet)
        if token_budget_used + snippet_tokens > max_tokens:
            # Try minimal fallback
            minimal = node.get("signature") or node["name"]
            minimal_tokens = estimate_tokens(minimal)
            if token_budget_used + minimal_tokens <= max_tokens:
                snippet = minimal
                snippet_tokens = minimal_tokens
            else:
                continue

        token_budget_used += snippet_tokens
        bundle_nodes.append(
            {
                **node,
                "code_snippet": snippet,
                "relevance_score": sc.total_score,
            }
        )

        # Record path from anchor to this node
        if sc.path:
            paths.append(
                {
                    "from_node": anchor["id"],
                    "to_node": node["id"],
                    "relations": [ek for ek, _ in sc.path],
                    "confidence": sc.max_edge_confidence,
                }
            )

    # Sibling enrichment: when the graph yields thin results (< 30% of budget
    # used), the anchor's dependencies are mostly external. Fill remaining
    # budget with sibling methods from the same class so the user gets a
    # complete picture of the service without needing a follow-up Read.
    if token_budget_used < max_tokens * 3 // 10 and anchor["kind"] == "method":
        siblings = await db.fetchall(
            "SELECT * FROM nodes WHERE repo_id = ? AND file_path = ? "
            "AND kind = 'method' AND id != ? ORDER BY start_line",
            (anchor["repo_id"], anchor["file_path"], anchor["id"]),
        )
        for sib in siblings:
            if sib["id"] in seen_ids:
                continue
            if token_budget_used >= max_tokens * 8 // 10:
                break
            seen_ids.add(sib["id"])
            snippet = await load_snippet(
                sib["file_path"], sib["start_line"], sib["end_line"],
                root_path, context_lines=0,
            )
            snippet_tokens = estimate_tokens(snippet)
            if token_budget_used + snippet_tokens > max_tokens:
                minimal = sib.get("signature") or sib["name"]
                snippet = minimal
                snippet_tokens = estimate_tokens(minimal)
                if token_budget_used + snippet_tokens > max_tokens:
                    continue
            token_budget_used += snippet_tokens
            bundle_nodes.append(
                {**sib, "code_snippet": snippet, "relevance_score": 0.10}
            )
            paths.append(
                {
                    "from_node": anchor["id"],
                    "to_node": sib["id"],
                    "relations": ["SIBLING"],
                    "confidence": "low",
                }
            )

    # Deduplicate paths
    seen_paths: set[tuple[int, int]] = set()
    unique_paths: list[dict] = []
    for p in paths:
        key = (p["from_node"], p["to_node"])
        if key not in seen_paths:
            seen_paths.add(key)
            unique_paths.append(p)

    # Lightweight reverse lookup: who calls the anchor? (names only, no code)
    callers = await db.fetchall(
        "SELECT n.name, n.fq_name, n.kind, n.file_path, n.start_line, n.is_test "
        "FROM edges e JOIN nodes n ON e.src_node_id = n.id "
        "WHERE e.dst_node_id = ? AND e.kind = 'CALLS' "
        "ORDER BY n.is_test ASC, n.name LIMIT 10",
        (anchor["id"],),
    )
    prod_callers = [c for c in callers if not c.get("is_test")]
    test_callers = [c for c in callers if c.get("is_test")]

    caller_section = ""
    if prod_callers:
        caller_section += "\n\nCalled by (production):"
        for c in prod_callers[:5]:
            caller_section += f"\n- `{c['fq_name']}` in {c['file_path']}:{c['start_line']}"
    if test_callers:
        caller_section += f"\n\nTest coverage: {len(test_callers)} test method"
        if len(test_callers) != 1:
            caller_section += "s"
        names = [c["name"] for c in test_callers[:3]]
        caller_section += f" ({', '.join(names)}"
        if len(test_callers) > 3:
            caller_section += f", +{len(test_callers) - 3} more"
        caller_section += ")"

    # Generate summary
    node_names = [n["name"] for n in bundle_nodes[:6]]
    summary = (
        f"The anchor is {anchor['kind']} `{anchor['fq_name']}`"
        f" in {anchor['file_path']}. "
        f"Context includes {len(bundle_nodes)} related symbols:"
        f" {', '.join(node_names)}."
        f"{caller_section}"
    )

    return {
        "nodes": bundle_nodes,
        "paths": unique_paths,
        "high_level_summary": summary,
        "estimated_tokens": token_budget_used,
    }
