"""Symbol anchoring — find the most specific node at a cursor/selection."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..db.connection import Database


async def find_anchor_node(
    db: Database, repo_id: str, file_path: str, line: int
) -> dict | None:
    """Find the most specific node at the given cursor position."""
    return await db.fetchone(
        """SELECT * FROM nodes
           WHERE repo_id = ? AND file_path = ? AND start_line <= ? AND end_line >= ?
           ORDER BY (end_line - start_line) ASC,
                    CASE kind WHEN 'method' THEN 0 WHEN 'function' THEN 1
                              WHEN 'class' THEN 2 ELSE 3 END ASC
           LIMIT 1""",
        (repo_id, file_path, line, line),
    )


async def find_anchor_nodes_in_range(
    db: Database, repo_id: str, file_path: str, start_line: int, end_line: int
) -> list[dict]:
    """Find all nodes overlapping a selection range."""
    return await db.fetchall(
        """SELECT * FROM nodes
           WHERE repo_id = ? AND file_path = ? AND start_line <= ? AND end_line >= ?
           ORDER BY (end_line - start_line) ASC""",
        (repo_id, file_path, end_line, start_line),
    )
