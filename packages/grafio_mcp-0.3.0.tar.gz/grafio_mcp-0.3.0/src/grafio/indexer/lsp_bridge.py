"""LSP client bridge for edge enrichment via JSON-RPC over stdio."""

from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

from grafio.models import Confidence, EdgeSource, Language

if TYPE_CHECKING:
    from grafio.db.connection import Database

logger = logging.getLogger(__name__)


@dataclass
class LspLocation:
    """A location returned by an LSP server."""

    file_path: str  # absolute path
    line: int  # 0-based
    character: int


LSP_SERVER_COMMANDS: dict[Language, tuple[str, list[str]]] = {
    Language.TYPESCRIPT: ("typescript-language-server", ["--stdio"]),
    Language.JAVASCRIPT: ("typescript-language-server", ["--stdio"]),
    Language.PYTHON: ("pylsp", []),
    Language.JAVA: ("jdtls", []),
    Language.GO: ("gopls", ["serve"]),
    Language.RUST: ("rust-analyzer", []),
}

_LANGUAGE_IDS: dict[Language, str] = {
    Language.TYPESCRIPT: "typescript",
    Language.JAVASCRIPT: "javascript",
    Language.PYTHON: "python",
    Language.JAVA: "java",
    Language.GO: "go",
    Language.RUST: "rust",
}


class LspClient:
    """JSON-RPC client communicating with an LSP server over stdio."""

    def __init__(self, language: Language, process: asyncio.subprocess.Process) -> None:
        self.language = language
        self.process = process
        self._request_id = 0
        self._pending: dict[int, asyncio.Future[Any]] = {}
        self._reader_task: asyncio.Task[None] | None = None

    @classmethod
    async def start(
        cls, language: Language, root_path: Path, timeout: float = 30.0
    ) -> LspClient:
        cmd, args = LSP_SERVER_COMMANDS.get(language, (None, None))  # type: ignore[misc]
        if cmd is None:
            raise ValueError(f"No LSP server configured for {language}")

        try:
            process = await asyncio.create_subprocess_exec(
                cmd,
                *args,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
        except FileNotFoundError:
            raise RuntimeError(
                f"LSP server '{cmd}' not found. Install it to enable enrichment."
            ) from None

        client = cls(language, process)
        client._reader_task = asyncio.create_task(client._read_responses())

        # Initialize handshake
        await client._send_request(
            "initialize",
            {
                "processId": None,
                "rootUri": root_path.as_uri(),
                "capabilities": {},
            },
            timeout=timeout,
        )
        await client._send_notification("initialized", {})
        return client

    async def shutdown(self) -> None:
        try:
            await self._send_request("shutdown", None, timeout=5.0)
            await self._send_notification("exit", None)
        except Exception:  # noqa: BLE001
            pass
        if self._reader_task:
            self._reader_task.cancel()
        if self.process.stdin:
            self.process.stdin.close()
        try:
            await asyncio.wait_for(self.process.wait(), timeout=5.0)
        except TimeoutError:
            self.process.kill()

    async def did_open(self, file_path: Path, language_id: str) -> None:
        content = file_path.read_text(errors="replace")
        await self._send_notification(
            "textDocument/didOpen",
            {
                "textDocument": {
                    "uri": file_path.as_uri(),
                    "languageId": language_id,
                    "version": 1,
                    "text": content,
                }
            },
        )

    async def did_close(self, file_path: Path) -> None:
        await self._send_notification(
            "textDocument/didClose",
            {"textDocument": {"uri": file_path.as_uri()}},
        )

    async def definition(
        self, file_path: Path, line: int, character: int
    ) -> list[LspLocation]:
        result = await self._send_request(
            "textDocument/definition",
            {
                "textDocument": {"uri": file_path.as_uri()},
                "position": {"line": line, "character": character},
            },
        )
        return self._parse_locations(result)

    async def references(
        self, file_path: Path, line: int, character: int
    ) -> list[LspLocation]:
        result = await self._send_request(
            "textDocument/references",
            {
                "textDocument": {"uri": file_path.as_uri()},
                "position": {"line": line, "character": character},
                "context": {"includeDeclaration": False},
            },
        )
        return self._parse_locations(result)

    async def call_hierarchy_incoming(
        self, file_path: Path, line: int, character: int
    ) -> list[dict[str, Any]]:
        items = await self._send_request(
            "textDocument/prepareCallHierarchy",
            {
                "textDocument": {"uri": file_path.as_uri()},
                "position": {"line": line, "character": character},
            },
        )
        if not items:
            return []
        result = await self._send_request(
            "callHierarchy/incomingCalls", {"item": items[0]}
        )
        return result or []

    async def call_hierarchy_outgoing(
        self, file_path: Path, line: int, character: int
    ) -> list[dict[str, Any]]:
        items = await self._send_request(
            "textDocument/prepareCallHierarchy",
            {
                "textDocument": {"uri": file_path.as_uri()},
                "position": {"line": line, "character": character},
            },
        )
        if not items:
            return []
        result = await self._send_request(
            "callHierarchy/outgoingCalls", {"item": items[0]}
        )
        return result or []

    # --- Private JSON-RPC methods ---

    async def _send_request(
        self, method: str, params: Any, timeout: float = 10.0
    ) -> Any:
        self._request_id += 1
        req_id = self._request_id
        msg = {"jsonrpc": "2.0", "id": req_id, "method": method, "params": params}

        loop = asyncio.get_running_loop()
        future: asyncio.Future[Any] = loop.create_future()
        self._pending[req_id] = future

        self._write_message(msg)

        try:
            return await asyncio.wait_for(future, timeout=timeout)
        except TimeoutError:
            self._pending.pop(req_id, None)
            logger.warning("LSP request timed out: %s", method)
            return None

    async def _send_notification(self, method: str, params: Any) -> None:
        msg = {"jsonrpc": "2.0", "method": method, "params": params}
        self._write_message(msg)

    def _write_message(self, msg: dict[str, Any]) -> None:
        body = json.dumps(msg)
        header = f"Content-Length: {len(body)}\r\n\r\n"
        stdin = self.process.stdin
        if stdin:
            stdin.write((header + body).encode())

    async def _read_responses(self) -> None:
        reader = self.process.stdout
        if not reader:
            return
        try:
            while True:
                # Read headers until blank line
                header = b""
                while b"\r\n\r\n" not in header:
                    chunk = await reader.read(1)
                    if not chunk:
                        return
                    header += chunk

                # Parse content length
                length = 0
                for line in header.decode().split("\r\n"):
                    if line.lower().startswith("content-length:"):
                        length = int(line.split(":")[1].strip())
                        break

                if length == 0:
                    continue

                # Read body
                body = await reader.readexactly(length)
                msg = json.loads(body)

                # Match response to pending request
                msg_id = msg.get("id")
                if msg_id is not None and msg_id in self._pending:
                    future = self._pending.pop(msg_id)
                    if not future.done():
                        if "error" in msg:
                            future.set_exception(
                                RuntimeError(msg["error"].get("message", "LSP error"))
                            )
                        else:
                            future.set_result(msg.get("result"))
        except (asyncio.CancelledError, ConnectionError):
            pass

    def _parse_locations(self, result: Any) -> list[LspLocation]:
        if result is None:
            return []
        if isinstance(result, dict):
            result = [result]
        locations: list[LspLocation] = []
        for loc in result:
            uri = loc.get("uri") or loc.get("targetUri", "")
            rng = loc.get("range") or loc.get("targetRange", {})
            start = rng.get("start", {})
            file_path = uri.replace("file://", "")
            locations.append(
                LspLocation(
                    file_path=file_path,
                    line=start.get("line", 0),
                    character=start.get("character", 0),
                )
            )
        return locations


class LspBridge:
    """Manages multiple LSP clients and resolves cross-file references."""

    def __init__(self) -> None:
        self._clients: dict[Language, LspClient] = {}

    async def start(
        self, root_path: Path, languages: list[Language], timeout: float = 30.0
    ) -> None:
        for lang in languages:
            try:
                client = await LspClient.start(lang, root_path, timeout)
                self._clients[lang] = client
                logger.info("Started LSP server for %s", lang.value)
            except (RuntimeError, FileNotFoundError, ValueError) as e:
                logger.warning("Could not start LSP for %s: %s", lang.value, e)

    async def shutdown(self) -> None:
        for client in self._clients.values():
            await client.shutdown()
        self._clients.clear()

    @property
    def available_languages(self) -> list[Language]:
        return list(self._clients.keys())

    async def resolve_unresolved_references(
        self, db: Database, repo_id: str, root_path: Path
    ) -> tuple[int, int]:
        """Resolve unresolved references using LSP. Returns (resolved, still_unresolved)."""
        refs = await db.fetchall(
            "SELECT * FROM unresolved_references WHERE repo_id = ?", (repo_id,)
        )
        resolved = 0
        still_unresolved = 0

        # Group by file for batch processing
        by_file: dict[str, list[dict[str, Any]]] = {}
        for ref in refs:
            by_file.setdefault(ref["file_path"], []).append(ref)

        for file_path, file_refs in by_file.items():
            abs_path = root_path / file_path
            if not abs_path.exists():
                still_unresolved += len(file_refs)
                continue

            # Determine language from the first node in this file
            lang_row = await db.fetchone(
                "SELECT language FROM nodes WHERE repo_id = ? AND file_path = ? LIMIT 1",
                (repo_id, file_path),
            )
            if not lang_row:
                still_unresolved += len(file_refs)
                continue

            lang = Language(lang_row["language"])
            client = self._clients.get(lang)
            if not client:
                still_unresolved += len(file_refs)
                continue

            lang_id = _LANGUAGE_IDS.get(lang, lang.value)

            try:
                await client.did_open(abs_path, lang_id)

                for ref in file_refs:
                    line_number = ref.get("line_number") or 0
                    locations = await client.definition(
                        abs_path, max(line_number - 1, 0), 0
                    )
                    if locations:
                        loc = locations[0]
                        # Convert absolute path back to relative
                        try:
                            rel_target = str(
                                Path(loc.file_path).relative_to(root_path)
                            )
                        except ValueError:
                            rel_target = loc.file_path

                        target_node = await self._find_node_at_location(
                            db, repo_id, rel_target, loc.line
                        )
                        if target_node:
                            src_id = ref["src_node_id"]
                            dst_id = target_node["id"]
                            if src_id != dst_id:
                                await db.execute(
                                    """INSERT OR IGNORE INTO edges
                                       (repo_id, src_node_id, dst_node_id, kind, confidence, source)
                                       VALUES (?, ?, ?, ?, ?, ?)""",
                                    (
                                        repo_id,
                                        src_id,
                                        dst_id,
                                        ref["edge_kind"],
                                        Confidence.HIGH.value,
                                        EdgeSource.LSP.value,
                                    ),
                                )
                            await db.execute(
                                "DELETE FROM unresolved_references WHERE id = ?",
                                (ref["id"],),
                            )
                            resolved += 1
                            continue
                    still_unresolved += 1

                await client.did_close(abs_path)
            except Exception:  # noqa: BLE001
                logger.warning("LSP error processing %s", file_path, exc_info=True)
                still_unresolved += len(file_refs)

        await db.commit()
        return resolved, still_unresolved

    async def enrich_call_hierarchy(
        self, db: Database, repo_id: str, root_path: Path
    ) -> int:
        """Add CALLS edges from LSP call hierarchy data."""
        edges_added = 0
        functions = await db.fetchall(
            "SELECT * FROM nodes WHERE repo_id = ? AND kind IN ('function', 'method')",
            (repo_id,),
        )

        # Group by file for batch open/close
        by_file: dict[str, list[dict[str, Any]]] = {}
        for fn in functions:
            by_file.setdefault(fn["file_path"], []).append(fn)

        for file_path, file_fns in by_file.items():
            abs_path = root_path / file_path
            if not abs_path.exists():
                continue

            lang = Language(file_fns[0]["language"])
            client = self._clients.get(lang)
            if not client:
                continue

            lang_id = _LANGUAGE_IDS.get(lang, lang.value)

            try:
                await client.did_open(abs_path, lang_id)

                for fn in file_fns:
                    outgoing = await client.call_hierarchy_outgoing(
                        abs_path, fn["start_line"] - 1, 0
                    )
                    for call in outgoing or []:
                        target = call.get("to", {})
                        target_uri = target.get("uri", "")
                        target_range = target.get("range", {}).get("start", {})

                        target_path = target_uri.replace("file://", "")
                        try:
                            rel_target = str(Path(target_path).relative_to(root_path))
                        except ValueError:
                            rel_target = target_path

                        target_node = await self._find_node_at_location(
                            db, repo_id, rel_target, target_range.get("line", 0)
                        )
                        if target_node and fn["id"] != target_node["id"]:
                            await db.execute(
                                """INSERT OR IGNORE INTO edges
                                   (repo_id, src_node_id, dst_node_id, kind, confidence, source)
                                   VALUES (?, ?, ?, 'CALLS', ?, ?)""",
                                (
                                    repo_id,
                                    fn["id"],
                                    target_node["id"],
                                    Confidence.HIGH.value,
                                    EdgeSource.LSP.value,
                                ),
                            )
                            edges_added += 1

                await client.did_close(abs_path)
            except Exception:  # noqa: BLE001
                logger.warning(
                    "Call hierarchy error for %s", file_path, exc_info=True
                )

        await db.commit()
        return edges_added

    async def _find_node_at_location(
        self, db: Database, repo_id: str, file_path: str, line: int
    ) -> dict[str, Any] | None:
        """Find the most specific node at a given file location."""
        return await db.fetchone(
            """SELECT * FROM nodes
               WHERE repo_id = ? AND file_path = ? AND start_line <= ? AND end_line >= ?
               ORDER BY (end_line - start_line) ASC LIMIT 1""",
            (repo_id, file_path, line + 1, line + 1),
        )
