"""Git history extraction for edge enrichment using pygit2."""

from __future__ import annotations

import json
import logging
import re
from collections import defaultdict
from datetime import UTC, datetime
from typing import TYPE_CHECKING

import pygit2

from grafio.models import Confidence, EdgeSource

if TYPE_CHECKING:
    from pathlib import Path

    from grafio.db.connection import Database

logger = logging.getLogger(__name__)


class GitEnricher:
    """Enriches the code graph with git-derived signals."""

    def __init__(self, root_path: Path) -> None:
        self.repo = pygit2.Repository(str(root_path))
        self.root_path = root_path

    async def enrich_nodes(self, db: Database, repo_id: str) -> int:
        """Enrich nodes with git blame data (modified_at, author, count)."""
        enriched = 0
        files = await db.fetchall(
            "SELECT DISTINCT file_path FROM nodes WHERE repo_id = ?", (repo_id,)
        )

        for file_row in files:
            file_path = file_row["file_path"]
            try:
                blame = self.repo.blame(file_path)
            except Exception:  # noqa: BLE001
                continue

            nodes = await db.fetchall(
                "SELECT id, start_line, end_line FROM nodes WHERE repo_id = ? AND file_path = ?",
                (repo_id, file_path),
            )

            for node in nodes:
                authors: dict[str, int] = defaultdict(int)
                latest_date: datetime | None = None

                for hunk in blame:
                    hunk_start = hunk.final_start_line_number
                    hunk_end = hunk_start + hunk.lines_in_hunk - 1
                    # Check overlap with node line range
                    if hunk_end >= node["start_line"] and hunk_start <= node["end_line"]:
                        sig = hunk.final_committer
                        author = sig.name if sig else "unknown"
                        authors[author] += hunk.lines_in_hunk
                        if sig:
                            commit_time = datetime.fromtimestamp(
                                sig.time, tz=UTC
                            )
                            if latest_date is None or commit_time > latest_date:
                                latest_date = commit_time

                if authors:
                    primary_author = max(authors, key=lambda a: authors[a])
                    await db.execute(
                        """UPDATE nodes SET last_modified_at = ?, primary_author = ?,
                           modification_count = ? WHERE id = ?""",
                        (
                            latest_date.isoformat() if latest_date else None,
                            primary_author,
                            sum(authors.values()),
                            node["id"],
                        ),
                    )
                    enriched += 1

        await db.commit()
        return enriched

    async def compute_cochange_edges(
        self,
        db: Database,
        repo_id: str,
        min_cochange_count: int = 3,
        lookback_commits: int = 200,
    ) -> int:
        """Create CO_CHANGES edges for files that frequently change together."""
        cochange_counts: dict[tuple[str, str], int] = defaultdict(int)

        try:
            head_target = self.repo.head.target
        except pygit2.GitError:
            logger.warning("No HEAD found in repository, skipping co-change analysis")
            return 0

        walker = self.repo.walk(head_target, pygit2.GIT_SORT_TIME)
        count = 0
        for commit in walker:
            if count >= lookback_commits:
                break
            count += 1

            if not commit.parents:
                continue
            diff = self.repo.diff(commit.parents[0], commit)
            changed_files = [delta.new_file.path for delta in diff.deltas]

            # Count co-changes for each pair
            for i, f1 in enumerate(changed_files):
                for f2 in changed_files[i + 1 :]:
                    key = tuple(sorted([f1, f2]))
                    cochange_counts[key] += 1  # type: ignore[index]

        # Create edges for pairs above threshold
        edges_created = 0
        max_count = max(cochange_counts.values()) if cochange_counts else 1

        for (file1, file2), co_count in cochange_counts.items():
            if co_count < min_cochange_count:
                continue

            # Find primary nodes in each file
            node1 = await db.fetchone(
                """SELECT id FROM nodes WHERE repo_id = ? AND file_path = ?
                   AND kind IN ('class', 'function', 'method') ORDER BY start_line LIMIT 1""",
                (repo_id, file1),
            )
            node2 = await db.fetchone(
                """SELECT id FROM nodes WHERE repo_id = ? AND file_path = ?
                   AND kind IN ('class', 'function', 'method') ORDER BY start_line LIMIT 1""",
                (repo_id, file2),
            )
            if node1 and node2 and node1["id"] != node2["id"]:
                if co_count >= 10:
                    confidence = Confidence.HIGH
                elif co_count >= 5:
                    confidence = Confidence.MEDIUM
                else:
                    confidence = Confidence.LOW

                weight = co_count / max_count
                metadata = json.dumps({"cochange_count": co_count})
                await db.execute(
                    """INSERT OR IGNORE INTO edges
                       (repo_id, src_node_id, dst_node_id, kind,
                        confidence, source, weight, metadata)
                       VALUES (?, ?, ?, 'CO_CHANGES', ?, ?, ?, ?)""",
                    (
                        repo_id,
                        node1["id"],
                        node2["id"],
                        confidence.value,
                        EdgeSource.GIT.value,
                        weight,
                        metadata,
                    ),
                )
                edges_created += 1

        await db.commit()
        return edges_created

    async def detect_test_targets(self, db: Database, repo_id: str) -> int:
        """Create TESTS edges linking test files to source files."""
        edges_created = 0

        test_nodes = await db.fetchall(
            """SELECT * FROM nodes WHERE repo_id = ? AND is_test = 1
               AND kind IN ('function', 'method', 'class')""",
            (repo_id,),
        )

        for test_node in test_nodes:
            test_path = test_node["file_path"]
            candidates: list[str] = []

            # Pattern: OrderService.test.ts -> OrderService.ts
            candidates.append(
                re.sub(r"\.(test|spec)\.(ts|tsx|js|jsx)$", r".\2", test_path)
            )
            # Pattern: test_order_service.py -> order_service.py
            candidates.append(
                test_path.replace("tests/", "src/").replace("test_", "")
            )
            # Pattern: OrderServiceTest.java -> OrderService.java
            candidates.append(
                re.sub(r"Test\.java$", ".java", test_path).replace(
                    "src/test/", "src/main/"
                )
            )
            # Pattern: order_service_test.go -> order_service.go
            candidates.append(re.sub(r"_test\.go$", ".go", test_path))
            # Pattern: tests/test_foo.py -> src/foo.py (Python convention)
            candidates.append(
                re.sub(r"^tests?/", "src/", test_path).replace("test_", "")
            )

            for candidate in candidates:
                if candidate == test_path:
                    continue
                source_node = await db.fetchone(
                    """SELECT id FROM nodes WHERE repo_id = ? AND file_path = ?
                       AND kind IN ('class', 'function', 'method')
                       ORDER BY start_line LIMIT 1""",
                    (repo_id, candidate),
                )
                if source_node and source_node["id"] != test_node["id"]:
                    await db.execute(
                        """INSERT OR IGNORE INTO edges
                           (repo_id, src_node_id, dst_node_id, kind, confidence, source)
                           VALUES (?, ?, ?, 'TESTS', ?, ?)""",
                        (
                            repo_id,
                            test_node["id"],
                            source_node["id"],
                            Confidence.MEDIUM.value,
                            EdgeSource.HEURISTIC.value,
                        ),
                    )
                    edges_created += 1
                    break

        await db.commit()
        return edges_created
