from __future__ import annotations

import os
from pathlib import Path
from typing import TYPE_CHECKING

from grafio.models import Language

if TYPE_CHECKING:
    from grafio.config import IndexingConfig


def walk_repo(
    root: Path,
    config: IndexingConfig,
    languages: list[str] | None = None,
) -> list[Path]:
    """Walk a repository and return paths to indexable source files."""
    results: list[Path] = []
    ignored_dirs = set(config.ignored_dirs)
    ignored_files = set(config.ignored_files)

    for dirpath, dirnames, filenames in os.walk(root):
        # Prune ignored directories in-place
        dirnames[:] = [d for d in dirnames if d not in ignored_dirs and not d.startswith(".")]

        for filename in filenames:
            if filename in ignored_files:
                continue

            filepath = Path(dirpath) / filename

            # Check extension against ignored list
            if any(filename.endswith(ext) for ext in config.ignored_extensions):
                continue

            # Check file size
            try:
                if filepath.stat().st_size > config.max_file_size_bytes:
                    continue
            except OSError:
                continue

            # Check if language is supported and optionally filtered
            ext = filepath.suffix.lstrip(".")
            lang = Language.from_extension(ext)
            if lang is None:
                continue

            if languages and lang.value not in languages:
                continue

            results.append(filepath)

    return sorted(results)
