from __future__ import annotations

from typing import TYPE_CHECKING

import tree_sitter_go
import tree_sitter_java
import tree_sitter_javascript
import tree_sitter_python
import tree_sitter_rust
import tree_sitter_typescript
from tree_sitter import Language as TSLanguage
from tree_sitter import Parser

from grafio.models import Language as LangEnum
from grafio.models import ParsedFile

from .languages.go import GoExtractor
from .languages.java import JavaExtractor
from .languages.python_lang import PythonExtractor
from .languages.rust_lang import RustExtractor
from .languages.typescript import TypeScriptExtractor

if TYPE_CHECKING:
    from pathlib import Path

    from .languages.base import LanguageExtractor

# Map language enum to tree-sitter language object
_LANGUAGE_MODULES = {
    LangEnum.TYPESCRIPT: tree_sitter_typescript.language_typescript(),
    LangEnum.JAVASCRIPT: tree_sitter_javascript.language(),
    LangEnum.PYTHON: tree_sitter_python.language(),
    LangEnum.JAVA: tree_sitter_java.language(),
    LangEnum.GO: tree_sitter_go.language(),
    LangEnum.RUST: tree_sitter_rust.language(),
}

# Map language enum to extractor class
_EXTRACTORS: dict[LangEnum, type[LanguageExtractor]] = {
    LangEnum.TYPESCRIPT: TypeScriptExtractor,
    LangEnum.JAVASCRIPT: TypeScriptExtractor,
    LangEnum.PYTHON: PythonExtractor,
    LangEnum.JAVA: JavaExtractor,
    LangEnum.GO: GoExtractor,
    LangEnum.RUST: RustExtractor,
}


class TreeSitterParser:
    """Parses source files using Tree-sitter and extracts nodes/edges."""

    def __init__(self, languages: list[LangEnum] | None = None):
        self._parsers: dict[LangEnum, Parser] = {}
        self._extractors: dict[LangEnum, LanguageExtractor] = {}

        for lang in languages or list(_LANGUAGE_MODULES.keys()):
            if lang in _LANGUAGE_MODULES:
                parser = Parser(TSLanguage(_LANGUAGE_MODULES[lang]))
                self._parsers[lang] = parser
                self._extractors[lang] = _EXTRACTORS[lang]()

    def parse_file(
        self, file_path: Path, language: LangEnum, rel_path: str | None = None
    ) -> ParsedFile | None:
        """Parse a single file and extract nodes + edges.

        Args:
            file_path: Absolute path to the file on disk (used for reading).
            language: The language to parse.
            rel_path: Relative path to use in FQ names. Falls back to str(file_path).
        """
        parser = self._parsers.get(language)
        extractor = self._extractors.get(language)
        if not parser or not extractor:
            return None

        try:
            source = file_path.read_bytes()
        except OSError:
            return None

        tree = parser.parse(source)
        path_for_fq = rel_path or str(file_path)
        nodes, edges = extractor.extract(tree, source, path_for_fq)

        return ParsedFile(
            file_path=path_for_fq,
            language=language,
            nodes=nodes,
            edges=edges,
        )
