from __future__ import annotations

import contextlib
import hashlib
import json
import logging
import time
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from grafio.models import (
    Confidence,
    EdgeSource,
    ExtractedEdge,
    ExtractedNode,
    IndexStats,
    Language,
    NodeKind,
)

from .treesitter import TreeSitterParser
from .walker import walk_repo

if TYPE_CHECKING:
    from pathlib import Path

    from grafio.config import GrafioConfig, IndexingConfig
    from grafio.db.connection import Database

logger = logging.getLogger(__name__)


class Indexer:
    """Top-level indexing orchestrator."""

    def __init__(self, db: Database, config: IndexingConfig):
        self.db = db
        self.config = config
        self.parser = TreeSitterParser()

    async def index_repo(
        self,
        repo_id: str,
        root: Path,
        languages: list[str] | None = None,
        force: bool = False,
    ) -> IndexStats:
        """Full index of a repository."""
        start = time.perf_counter()
        stats = IndexStats()

        # 1. Ensure repository record exists
        await self._ensure_repo(repo_id, root)

        # 2. Walk files
        files = walk_repo(root, self.config, languages)

        # 3. Process files in batches
        for file_path in files:
            ext = file_path.suffix.lstrip(".")
            lang = Language.from_extension(ext)
            if lang is None:
                stats.files_skipped += 1
                continue

            rel_path = str(file_path.relative_to(root))

            try:
                content = file_path.read_bytes()
            except OSError:
                stats.files_skipped += 1
                continue

            content_hash = hashlib.sha256(content).hexdigest()

            # Check if already indexed with same hash
            if not force:
                existing = await self.db.fetchone(
                    "SELECT content_hash FROM index_state WHERE repo_id = ? AND file_path = ?",
                    (repo_id, rel_path),
                )
                if existing and existing["content_hash"] == content_hash:
                    stats.files_skipped += 1
                    continue

            # Parse file with relative path for FQ names
            parsed = self.parser.parse_file(file_path, lang, rel_path=rel_path)
            if not parsed:
                stats.files_skipped += 1
                continue

            # Delete old nodes/edges for this file
            await self._delete_file_data(repo_id, rel_path)

            # Insert a FILE node to anchor IMPORTS edges
            file_node = ExtractedNode(
                kind=NodeKind.FILE,
                name=rel_path.rsplit("/", 1)[-1],
                fq_name=f"{rel_path}:<module>",
                start_line=1,
                end_line=1,
                visibility="public",
            )
            node_id_map: dict[str, int] = {}  # fq_name -> node_id
            file_node_id = await self._insert_node(
                repo_id, file_node, rel_path, lang, content_hash
            )
            node_id_map[file_node.fq_name] = file_node_id
            stats.nodes_created += 1

            # Insert extracted nodes
            for node in parsed.nodes:
                node_id = await self._insert_node(repo_id, node, rel_path, lang, content_hash)
                node_id_map[node.fq_name] = node_id
                stats.nodes_created += 1

            # Insert edges where both endpoints are in this file
            for edge in parsed.edges:
                src_id = node_id_map.get(edge.src_fq_name)
                dst_id = node_id_map.get(edge.dst_fq_name)
                if src_id and dst_id:
                    await self._insert_edge(repo_id, src_id, dst_id, edge)
                    stats.edges_created += 1
                else:
                    # Store as unresolved for cross-file resolution
                    src_id_val = src_id or node_id_map.get(edge.src_fq_name)
                    if src_id_val:
                        await self._insert_unresolved(
                            repo_id, src_id_val, edge, rel_path
                        )

            # Update index state
            await self._update_index_state(repo_id, rel_path, content_hash, len(parsed.nodes))
            stats.files_processed += 1

        # 4. Resolve cross-file edges
        resolved, unresolved = await self._resolve_edges(repo_id)
        stats.edges_created += resolved
        stats.unresolved_references = unresolved

        await self.db.commit()

        # 5. Update repo timestamps
        now = datetime.now(UTC).isoformat()
        await self.db.execute(
            "UPDATE repositories SET last_full_index_at = ?, updated_at = ? WHERE id = ?",
            (now, now, repo_id),
        )
        await self.db.commit()

        stats.duration_ms = int((time.perf_counter() - start) * 1000)
        return stats

    async def index_files(
        self,
        repo_id: str,
        changed: list[Path],
        deleted: list[Path],
        root_path: Path,
    ) -> IndexStats:
        """Incremental index of changed/deleted files."""
        stats = IndexStats()

        for path in deleted:
            rel_path = str(path.relative_to(root_path))
            await self._delete_file_data(repo_id, rel_path)
            stats.nodes_deleted += 1

        for path in changed:
            if not path.exists():
                continue
            ext = path.suffix.lstrip(".")
            lang = Language.from_extension(ext)
            if lang is None:
                continue

            rel_path = str(path.relative_to(root_path))
            content = path.read_bytes()
            content_hash = hashlib.sha256(content).hexdigest()

            await self._delete_file_data(repo_id, rel_path)
            parsed = self.parser.parse_file(path, lang, rel_path=rel_path)
            if parsed:
                node_id_map: dict[str, int] = {}
                for node in parsed.nodes:
                    node_id = await self._insert_node(repo_id, node, rel_path, lang, content_hash)
                    node_id_map[node.fq_name] = node_id
                    stats.nodes_created += 1

                for edge in parsed.edges:
                    src_id = node_id_map.get(edge.src_fq_name)
                    dst_id = node_id_map.get(edge.dst_fq_name)
                    if src_id and dst_id:
                        await self._insert_edge(repo_id, src_id, dst_id, edge)
                        stats.edges_created += 1
                    elif src_id:
                        # Cross-file edge — store for resolution
                        await self._insert_unresolved(
                            repo_id, src_id, edge, rel_path
                        )

            await self._update_index_state(
                repo_id, rel_path, content_hash, len(parsed.nodes) if parsed else 0
            )
            stats.files_processed += 1

        # Re-resolve edges
        resolved, unresolved = await self._resolve_edges(repo_id)
        stats.edges_created += resolved
        stats.unresolved_references = unresolved

        now = datetime.now(UTC).isoformat()
        await self.db.execute(
            "UPDATE repositories SET last_incremental_at = ?, updated_at = ? WHERE id = ?",
            (now, now, repo_id),
        )
        await self.db.commit()
        return stats

    async def enrich_repo(
        self,
        repo_id: str,
        root_path: Path,
        config: GrafioConfig,
    ) -> dict[str, Any]:
        """Run full enrichment pipeline after tree-sitter indexing."""
        from .git_enricher import GitEnricher
        from .lsp_bridge import LspBridge

        stats: dict[str, Any] = {
            "git_nodes": 0,
            "cochange_edges": 0,
            "test_edges": 0,
            "lsp_resolved": 0,
            "lsp_unresolved": 0,
            "lsp_call_edges": 0,
        }

        # Phase A: Git enrichment
        try:
            git = GitEnricher(root_path)
            stats["git_nodes"] = await git.enrich_nodes(self.db, repo_id)
            stats["cochange_edges"] = await git.compute_cochange_edges(
                self.db, repo_id
            )
            stats["test_edges"] = await git.detect_test_targets(self.db, repo_id)
        except Exception:  # noqa: BLE001
            logger.warning("Git enrichment failed", exc_info=True)

        # Phase B: LSP enrichment
        if config.lsp.enabled:
            languages = await self._get_repo_languages(repo_id)
            bridge = LspBridge()
            try:
                await bridge.start(root_path, languages)
                if bridge.available_languages:
                    r, u = await bridge.resolve_unresolved_references(
                        self.db, repo_id, root_path
                    )
                    stats["lsp_resolved"] = r
                    stats["lsp_unresolved"] = u
                    stats["lsp_call_edges"] = await bridge.enrich_call_hierarchy(
                        self.db, repo_id, root_path
                    )
            except Exception:  # noqa: BLE001
                logger.warning("LSP enrichment failed", exc_info=True)
            finally:
                await bridge.shutdown()

        return stats

    async def _get_repo_languages(self, repo_id: str) -> list[Language]:
        """Get list of languages present in the indexed repo."""
        rows = await self.db.fetchall(
            "SELECT DISTINCT language FROM nodes WHERE repo_id = ?",
            (repo_id,),
        )
        result: list[Language] = []
        for row in rows:
            with contextlib.suppress(ValueError):
                result.append(Language(row["language"]))
        return result

    # ---- Private helpers ----

    async def _ensure_repo(self, repo_id: str, root_path: Path) -> None:
        existing = await self.db.fetchone("SELECT id FROM repositories WHERE id = ?", (repo_id,))
        if not existing:
            await self.db.execute(
                "INSERT INTO repositories (id, root_path) VALUES (?, ?)",
                (repo_id, str(root_path)),
            )
            await self.db.commit()

    async def _insert_node(
        self,
        repo_id: str,
        node: ExtractedNode,
        file_path: str,
        lang: Language,
        content_hash: str,
    ) -> int:
        cursor = await self.db.execute(
            """INSERT INTO nodes
               (repo_id, kind, name, fq_name, file_path, start_line, end_line,
                language, signature, docstring, visibility, is_exported, is_test,
                content_hash, metadata)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                repo_id,
                node.kind.value,
                node.name,
                node.fq_name,
                file_path,
                node.start_line,
                node.end_line,
                lang.value,
                node.signature,
                node.docstring,
                node.visibility,
                int(node.is_exported),
                int(node.is_test),
                content_hash,
                json.dumps(node.metadata),
            ),
        )
        return cursor.lastrowid  # type: ignore[return-value]

    async def _insert_edge(
        self,
        repo_id: str,
        src_id: int,
        dst_id: int,
        edge: ExtractedEdge,
    ) -> None:
        await self.db.execute(
            """INSERT OR IGNORE INTO edges
               (repo_id, src_node_id, dst_node_id, kind, confidence, source)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (
                repo_id,
                src_id,
                dst_id,
                edge.kind.value,
                edge.confidence.value,
                edge.source.value,
            ),
        )

    async def _insert_unresolved(
        self,
        repo_id: str,
        src_node_id: int,
        edge: ExtractedEdge,
        file_path: str,
    ) -> None:
        await self.db.execute(
            """INSERT INTO unresolved_references
               (repo_id, src_node_id, dst_name, dst_fq_name, edge_kind, file_path)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (
                repo_id,
                src_node_id,
                edge.dst_name,
                edge.dst_fq_name,
                edge.kind.value,
                file_path,
            ),
        )

    async def _delete_file_data(self, repo_id: str, file_path: str) -> None:
        # Delete edges referencing nodes in this file
        await self.db.execute(
            """DELETE FROM edges WHERE repo_id = ? AND (
                src_node_id IN (SELECT id FROM nodes WHERE repo_id = ? AND file_path = ?) OR
                dst_node_id IN (SELECT id FROM nodes WHERE repo_id = ? AND file_path = ?)
            )""",
            (repo_id, repo_id, file_path, repo_id, file_path),
        )
        # Delete unresolved references from this file
        await self.db.execute(
            "DELETE FROM unresolved_references WHERE repo_id = ? AND file_path = ?",
            (repo_id, file_path),
        )
        # Delete nodes
        await self.db.execute(
            "DELETE FROM nodes WHERE repo_id = ? AND file_path = ?",
            (repo_id, file_path),
        )
        # Delete index state
        await self.db.execute(
            "DELETE FROM index_state WHERE repo_id = ? AND file_path = ?",
            (repo_id, file_path),
        )

    async def _update_index_state(
        self,
        repo_id: str,
        file_path: str,
        content_hash: str,
        node_count: int,
    ) -> None:
        now = datetime.now(UTC).isoformat()
        await self.db.execute(
            """INSERT OR REPLACE INTO index_state
               (repo_id, file_path, content_hash, last_indexed_at, node_count)
               VALUES (?, ?, ?, ?, ?)""",
            (repo_id, file_path, content_hash, now, node_count),
        )

    async def _resolve_edges(self, repo_id: str) -> tuple[int, int]:
        """Resolve cross-file edge references.

        Strategy:
        1. Exact FQ name match
        2. Simple name match within repo (downgraded confidence)
        3. Create phantom node for external dependencies
        4. Leave as unresolved
        """
        resolved = 0
        unresolved = 0

        refs = await self.db.fetchall(
            """SELECT id, src_node_id, dst_name, dst_fq_name, edge_kind, file_path
               FROM unresolved_references WHERE repo_id = ?""",
            (repo_id,),
        )

        for ref in refs:
            dst_fq = ref["dst_fq_name"]
            dst_name = ref["dst_name"]
            edge_kind = ref["edge_kind"]
            src_id = ref["src_node_id"]
            ref_id = ref["id"]

            # Strategy 1: exact fq_name match
            target = await self.db.fetchone(
                "SELECT id FROM nodes WHERE repo_id = ? AND fq_name = ?",
                (repo_id, dst_fq),
            )

            confidence = Confidence.HIGH

            # Strategy 2: name match
            if not target and dst_name:
                target = await self.db.fetchone(
                    "SELECT id FROM nodes WHERE repo_id = ? AND name = ? LIMIT 1",
                    (repo_id, dst_name),
                )
                confidence = Confidence.LOW

            if target:
                dst_id = target["id"]
                # Don't create self-edges
                if src_id != dst_id:
                    await self.db.execute(
                        """INSERT OR IGNORE INTO edges
                           (repo_id, src_node_id, dst_node_id, kind, confidence, source)
                           VALUES (?, ?, ?, ?, ?, ?)""",
                        (
                            repo_id,
                            src_id,
                            dst_id,
                            edge_kind,
                            confidence.value,
                            EdgeSource.TREESITTER.value,
                        ),
                    )
                    resolved += 1
                # Clean up resolved reference
                await self.db.execute(
                    "DELETE FROM unresolved_references WHERE id = ?",
                    (ref_id,),
                )
            else:
                # Strategy 3: Create phantom node for external dependencies
                if dst_fq and self._is_external_import(dst_fq):
                    phantom_id = await self._create_phantom_node(
                        repo_id, dst_name, dst_fq
                    )
                    if phantom_id and src_id != phantom_id:
                        await self.db.execute(
                            """INSERT OR IGNORE INTO edges
                               (repo_id, src_node_id, dst_node_id, kind, confidence, source)
                               VALUES (?, ?, ?, ?, 'low', 'heuristic')""",
                            (repo_id, src_id, phantom_id, edge_kind),
                        )
                        await self.db.execute(
                            "DELETE FROM unresolved_references WHERE id = ?",
                            (ref_id,),
                        )
                        resolved += 1
                        continue
                unresolved += 1

        return resolved, unresolved

    async def _create_phantom_node(
        self, repo_id: str, name: str, package_path: str
    ) -> int | None:
        """Create a placeholder node for an external dependency."""
        fq_name = f"[external:{package_path}].{name}"
        existing = await self.db.fetchone(
            "SELECT id FROM nodes WHERE repo_id = ? AND fq_name = ? AND kind = 'external'",
            (repo_id, fq_name),
        )
        if existing:
            return int(existing["id"])

        cursor = await self.db.execute(
            """INSERT INTO nodes
               (repo_id, kind, name, fq_name, file_path, start_line, end_line,
                language, content_hash, metadata)
               VALUES (?, 'external', ?, ?, ?, 0, 0, 'unknown', 'phantom', ?)""",
            (
                repo_id,
                name,
                fq_name,
                f"[external: {package_path}]",
                json.dumps({"external": True, "package": package_path}),
            ),
        )
        return cursor.lastrowid

    @staticmethod
    def _is_external_import(import_path: str) -> bool:
        """Check if an import points to an external package (not in this repo)."""
        # Relative imports are always internal
        if import_path.startswith(".") or import_path.startswith("/"):
            return False
        # Imports with common external package patterns
        # Node: non-relative like "express", "@nestjs/core"
        return import_path.startswith("@") or not any(
            c in import_path for c in ["./", "../", "/"]
        )
