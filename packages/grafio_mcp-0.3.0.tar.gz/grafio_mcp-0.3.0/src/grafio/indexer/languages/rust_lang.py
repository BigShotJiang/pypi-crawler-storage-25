from __future__ import annotations

from typing import TYPE_CHECKING

from grafio.models import (
    Confidence,
    EdgeKind,
    ExtractedEdge,
    ExtractedNode,
    Language,
    NodeKind,
)

from .base import LanguageExtractor

if TYPE_CHECKING:
    from tree_sitter import Node, Tree


class RustExtractor(LanguageExtractor):
    """Extracts nodes and edges from Rust source files."""

    def language(self) -> Language:
        return Language.RUST

    def extract(
        self, tree: Tree, source: bytes, file_path: str
    ) -> tuple[list[ExtractedNode], list[ExtractedEdge]]:
        nodes: list[ExtractedNode] = []
        edges: list[ExtractedEdge] = []
        self._walk(tree.root_node, source, file_path, nodes, edges, parent_fq=None)
        return nodes, edges

    def _walk(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
        parent_fq: str | None,
    ) -> None:
        if node.type == "function_item":
            self._extract_function(node, source, file_path, nodes, edges, parent_fq)
        elif node.type == "struct_item":
            self._extract_struct(node, source, file_path, nodes, edges, parent_fq)
        elif node.type == "enum_item":
            self._extract_enum(node, source, file_path, nodes, edges, parent_fq)
        elif node.type == "trait_item":
            self._extract_trait(node, source, file_path, nodes, edges, parent_fq)
        elif node.type == "impl_item":
            self._extract_impl(node, source, file_path, nodes, edges)
        elif node.type == "type_item":
            self._extract_type_alias(node, source, file_path, nodes, edges, parent_fq)
        elif node.type == "use_declaration":
            self._extract_use(node, source, file_path, edges)
        elif node.type == "mod_item":
            # Recurse into inline module bodies
            name_node = node.child_by_field_name("name")
            body = node.child_by_field_name("body")
            if name_node and body:
                mod_name = self._get_text(name_node, source)
                mod_fq = f"{parent_fq}::{mod_name}" if parent_fq else f"{file_path}:{mod_name}"
                for child in body.named_children:
                    self._walk(child, source, file_path, nodes, edges, mod_fq)
            return
        else:
            for child in node.named_children:
                self._walk(child, source, file_path, nodes, edges, parent_fq)

    # ---- Node extractors ----

    def _extract_function(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
        parent_fq: str | None,
    ) -> None:
        name_node = node.child_by_field_name("name")
        if not name_node:
            return
        name = self._get_text(name_node, source)
        fq_name = f"{parent_fq}::{name}" if parent_fq else f"{file_path}:{name}"

        params = node.child_by_field_name("parameters")
        return_type = node.child_by_field_name("return_type")
        sig = f"fn {name}"
        if params:
            sig += self._get_text(params, source)
        if return_type:
            sig += f" -> {self._get_text(return_type, source)}"

        visibility = self._get_visibility(node, source)
        is_test = self._has_test_attribute(node, source) or self._is_test_file(file_path)

        func_node = ExtractedNode(
            kind=NodeKind.FUNCTION,
            name=name,
            fq_name=fq_name,
            start_line=self._line(node),
            end_line=self._end_line(node),
            signature=sig,
            docstring=self._get_rust_doc(node, source),
            visibility=visibility,
            is_exported=visibility == "public",
            is_test=is_test,
        )
        nodes.append(func_node)

        body = node.child_by_field_name("body")
        if body:
            self._extract_calls(body, source, fq_name, edges)

    def _extract_struct(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
        parent_fq: str | None,
    ) -> None:
        name_node = node.child_by_field_name("name")
        if not name_node:
            return
        name = self._get_text(name_node, source)
        fq_name = f"{parent_fq}::{name}" if parent_fq else f"{file_path}:{name}"

        visibility = self._get_visibility(node, source)

        struct_node = ExtractedNode(
            kind=NodeKind.STRUCT,
            name=name,
            fq_name=fq_name,
            start_line=self._line(node),
            end_line=self._end_line(node),
            signature=f"struct {name}",
            docstring=self._get_rust_doc(node, source),
            visibility=visibility,
            is_exported=visibility == "public",
        )
        nodes.append(struct_node)

        # Extract field types as USES_TYPE edges
        body = node.child_by_field_name("body")
        if body:
            for field in body.named_children:
                if field.type == "field_declaration":
                    ft = field.child_by_field_name("type")
                    if ft:
                        self._add_type_edge(fq_name, ft, source, edges)

    def _extract_enum(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
        parent_fq: str | None,
    ) -> None:
        name_node = node.child_by_field_name("name")
        if not name_node:
            return
        name = self._get_text(name_node, source)
        fq_name = f"{parent_fq}::{name}" if parent_fq else f"{file_path}:{name}"

        visibility = self._get_visibility(node, source)

        enum_node = ExtractedNode(
            kind=NodeKind.ENUM,
            name=name,
            fq_name=fq_name,
            start_line=self._line(node),
            end_line=self._end_line(node),
            signature=f"enum {name}",
            docstring=self._get_rust_doc(node, source),
            visibility=visibility,
            is_exported=visibility == "public",
        )
        nodes.append(enum_node)

    def _extract_trait(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
        parent_fq: str | None,
    ) -> None:
        name_node = node.child_by_field_name("name")
        if not name_node:
            return
        name = self._get_text(name_node, source)
        fq_name = f"{parent_fq}::{name}" if parent_fq else f"{file_path}:{name}"

        visibility = self._get_visibility(node, source)

        trait_node = ExtractedNode(
            kind=NodeKind.TRAIT,
            name=name,
            fq_name=fq_name,
            start_line=self._line(node),
            end_line=self._end_line(node),
            signature=f"trait {name}",
            docstring=self._get_rust_doc(node, source),
            visibility=visibility,
            is_exported=visibility == "public",
        )
        nodes.append(trait_node)

        # Extract trait supertraits as EXTENDS
        for child in node.children:
            if child.type == "trait_bounds":
                for bound in child.named_children:
                    if bound.type == "type_identifier" or bound.type == "scoped_type_identifier":
                        bound_name = self._get_text(bound, source)
                        edges.append(
                            ExtractedEdge(
                                src_fq_name=fq_name,
                                dst_fq_name=bound_name,
                                dst_name=bound_name,
                                kind=EdgeKind.EXTENDS,
                                confidence=Confidence.HIGH,
                            )
                        )

    def _extract_impl(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
    ) -> None:
        """Extract impl blocks: impl Struct or impl Trait for Struct."""
        type_node = node.child_by_field_name("type")
        trait_node = node.child_by_field_name("trait")
        body = node.child_by_field_name("body")

        if not type_node:
            return

        struct_name = self._get_text(type_node, source)
        struct_fq = f"{file_path}:{struct_name}"

        # impl Trait for Struct → IMPLEMENTS edge
        if trait_node:
            trait_name = self._get_text(trait_node, source)
            edges.append(
                ExtractedEdge(
                    src_fq_name=struct_fq,
                    dst_fq_name=trait_name,
                    dst_name=trait_name,
                    kind=EdgeKind.IMPLEMENTS,
                    confidence=Confidence.HIGH,
                )
            )

        # Extract methods in impl block
        if body:
            for child in body.named_children:
                if child.type == "function_item":
                    self._extract_function(child, source, file_path, nodes, edges, struct_fq)
                    if nodes:
                        edges.append(
                            ExtractedEdge(
                                src_fq_name=struct_fq,
                                dst_fq_name=nodes[-1].fq_name,
                                dst_name=nodes[-1].name,
                                kind=EdgeKind.OWNS,
                                confidence=Confidence.HIGH,
                            )
                        )

    def _extract_type_alias(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
        parent_fq: str | None,
    ) -> None:
        name_node = node.child_by_field_name("name")
        if not name_node:
            return
        name = self._get_text(name_node, source)
        fq_name = f"{parent_fq}::{name}" if parent_fq else f"{file_path}:{name}"

        visibility = self._get_visibility(node, source)

        ta_node = ExtractedNode(
            kind=NodeKind.TYPE_ALIAS,
            name=name,
            fq_name=fq_name,
            start_line=self._line(node),
            end_line=self._end_line(node),
            signature=self._get_text(node, source).split("=")[0].strip(),
            docstring=self._get_rust_doc(node, source),
            visibility=visibility,
            is_exported=visibility == "public",
        )
        nodes.append(ta_node)

    def _extract_use(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        edges: list[ExtractedEdge],
    ) -> None:
        """Extract 'use' declarations as IMPORTS edges."""
        text = self._get_text(node, source).strip().rstrip(";")
        # Remove 'use ' prefix and 'pub ' prefix
        text = text.removeprefix("pub ").removeprefix("use ")

        # Handle grouped imports: use std::{io, fmt}
        if "{" in text:
            prefix = text[: text.index("{")]
            while prefix.endswith(":"):
                prefix = prefix[:-1]
            inner = text[text.index("{") + 1 : text.index("}")].strip()
            for item in inner.split(","):
                item = item.strip()
                if item:
                    full = f"{prefix}::{item}"
                    short = item.rsplit("::", 1)[-1]
                    edges.append(
                        ExtractedEdge(
                            src_fq_name=f"{file_path}:<module>",
                            dst_fq_name=full,
                            dst_name=short,
                            kind=EdgeKind.IMPORTS,
                            confidence=Confidence.HIGH,
                        )
                    )
        else:
            # Simple import: use std::io::Read
            path = text.split(" as ")[0].strip()
            short = path.rsplit("::", 1)[-1]
            edges.append(
                ExtractedEdge(
                    src_fq_name=f"{file_path}:<module>",
                    dst_fq_name=path,
                    dst_name=short,
                    kind=EdgeKind.IMPORTS,
                    confidence=Confidence.HIGH,
                )
            )

    # ---- Call extraction ----

    def _extract_calls(
        self,
        node: Node,
        source: bytes,
        caller_fq: str,
        edges: list[ExtractedEdge],
        imported_names: set[str] | None = None,
    ) -> None:
        if node.type == "call_expression":
            func_node = node.child_by_field_name("function")
            if func_node:
                callee = self._get_text(func_node, source)
                short = callee.rsplit("::", 1)[-1] if "::" in callee else callee
                if "." in short:
                    short = short.rsplit(".", 1)[-1]
                # For receiver, use the part before :: or .
                if "::" in callee:
                    receiver = callee.rsplit("::", 1)[0]
                elif "." in callee:
                    receiver = callee.rsplit(".", 1)[0]
                else:
                    receiver = None

                if self.should_extract_call(receiver, short, imported_names):
                    edges.append(
                        ExtractedEdge(
                            src_fq_name=caller_fq,
                            dst_fq_name=callee,
                            dst_name=short,
                            kind=EdgeKind.CALLS,
                            confidence=Confidence.MEDIUM,
                        )
                    )

        for child in node.children:
            self._extract_calls(child, source, caller_fq, edges, imported_names)

    # ---- Helpers ----

    def _get_visibility(self, node: Node, source: bytes) -> str:
        for child in node.children:
            if child.type == "visibility_modifier":
                text = self._get_text(child, source)
                if "pub(crate)" in text:
                    return "internal"
                if "pub" in text:
                    return "public"
        return "private"

    def _get_rust_doc(self, node: Node, source: bytes) -> str | None:
        """Collect consecutive /// doc comments above a node."""
        lines: list[str] = []
        prev = node.prev_named_sibling
        while prev and prev.type == "line_comment":
            text = self._get_text(prev, source).strip()
            if text.startswith("///"):
                lines.insert(0, text.removeprefix("///").strip())
                prev = prev.prev_named_sibling
            else:
                break
        return " ".join(lines) if lines else self._get_docstring_before(node, source)

    def _has_test_attribute(self, node: Node, source: bytes) -> bool:
        """Check if a function has #[test] or #[cfg(test)] attribute."""
        prev = node.prev_named_sibling
        while prev and prev.type == "attribute_item":
            text = self._get_text(prev, source)
            if "#[test]" in text or "#[cfg(test)]" in text:
                return True
            prev = prev.prev_named_sibling
        return False

    def _add_type_edge(
        self,
        src_fq: str,
        type_node: Node,
        source: bytes,
        edges: list[ExtractedEdge],
    ) -> None:
        """Add USES_TYPE edge for a type node if it's a user-defined type."""
        type_text = self._get_text(type_node, source).strip()
        # Strip references and common wrappers
        for prefix in ["&", "&mut ", "Box<", "Vec<", "Option<", "Result<", "Arc<", "Rc<"]:
            type_text = type_text.removeprefix(prefix)
        type_text = type_text.rstrip(">").strip()
        if type_text and type_text[0].isupper() and type_text not in ("String", "Self"):
            edges.append(
                ExtractedEdge(
                    src_fq_name=src_fq,
                    dst_fq_name=type_text,
                    dst_name=type_text,
                    kind=EdgeKind.USES_TYPE,
                    confidence=Confidence.MEDIUM,
                )
            )

    def _is_test_file(self, file_path: str) -> bool:
        return "/tests/" in file_path or file_path.endswith("_test.rs")
