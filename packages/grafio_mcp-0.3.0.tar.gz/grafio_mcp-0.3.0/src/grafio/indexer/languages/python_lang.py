from __future__ import annotations

from typing import TYPE_CHECKING

from grafio.models import (
    Confidence,
    EdgeKind,
    ExtractedEdge,
    ExtractedNode,
    Language,
    NodeKind,
)

from .base import LanguageExtractor

if TYPE_CHECKING:
    from tree_sitter import Node, Tree


class PythonExtractor(LanguageExtractor):
    """Extracts nodes and edges from Python source files."""

    def language(self) -> Language:
        return Language.PYTHON

    def extract(
        self, tree: Tree, source: bytes, file_path: str
    ) -> tuple[list[ExtractedNode], list[ExtractedEdge]]:
        nodes: list[ExtractedNode] = []
        edges: list[ExtractedEdge] = []
        imported_names = self._collect_imports(tree.root_node, source)
        self._walk(
            tree.root_node, source, file_path, nodes, edges,
            parent_fq=None, imported_names=imported_names,
        )
        return nodes, edges

    def _collect_imports(self, root: Node, source: bytes) -> set[str]:
        """Collect all imported names in a file for call filtering."""
        names: set[str] = set()
        for child in root.children:
            if child.type == "import_statement":
                for sub in child.named_children:
                    if sub.type == "dotted_name":
                        mod = self._get_text(sub, source)
                        names.add(mod.rsplit(".", 1)[-1])
                    elif sub.type == "aliased_import":
                        alias = sub.child_by_field_name("alias")
                        name_node = sub.child_by_field_name("name")
                        if alias:
                            names.add(self._get_text(alias, source))
                        elif name_node:
                            mod = self._get_text(name_node, source)
                            names.add(mod.rsplit(".", 1)[-1])
            elif child.type == "import_from_statement":
                module_name = child.child_by_field_name("module_name")
                for sub in child.named_children:
                    if sub.type == "dotted_name" and sub != module_name:
                        names.add(self._get_text(sub, source))
                    elif sub.type == "aliased_import":
                        alias = sub.child_by_field_name("alias")
                        name_node = sub.child_by_field_name("name")
                        if alias:
                            names.add(self._get_text(alias, source))
                        elif name_node:
                            names.add(self._get_text(name_node, source))
        return names

    def _walk(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
        parent_fq: str | None,
        imported_names: set[str] | None = None,
    ) -> None:
        if node.type == "class_definition":
            self._extract_class(node, source, file_path, nodes, edges, parent_fq, imported_names)
        elif node.type == "function_definition":
            self._extract_function(node, source, file_path, nodes, edges, parent_fq, imported_names)
        elif node.type in ("import_statement", "import_from_statement"):
            self._extract_import(node, source, file_path, edges)
        elif node.type == "decorated_definition":
            self._extract_decorated(
                node, source, file_path, nodes, edges, parent_fq, imported_names,
            )
        else:
            for child in node.named_children:
                self._walk(child, source, file_path, nodes, edges, parent_fq, imported_names)

    # ---- Node extractors ----

    def _extract_class(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
        parent_fq: str | None,
        imported_names: set[str] | None = None,
    ) -> None:
        name_node = node.child_by_field_name("name")
        if not name_node:
            return
        name = self._get_text(name_node, source)
        fq_name = f"{parent_fq}.{name}" if parent_fq else f"{file_path}:{name}"

        sig = f"class {name}"

        # Extract bases (superclasses)
        superclasses = node.child_by_field_name("superclasses")
        if superclasses:
            bases = []
            for child in superclasses.named_children:
                base = self._get_text(child, source)
                bases.append(base)
                # Skip common non-class bases
                if base not in ("ABC", "BaseModel", "str", "int", "Enum"):
                    edges.append(
                        ExtractedEdge(
                            src_fq_name=fq_name,
                            dst_fq_name=base,
                            dst_name=base,
                            kind=EdgeKind.EXTENDS,
                            confidence=Confidence.HIGH,
                        )
                    )
            if bases:
                sig += f"({', '.join(bases)})"

        docstring = self._extract_python_docstring(node, source)

        is_test = name.startswith("Test") or self._is_test_file(file_path)

        class_node = ExtractedNode(
            kind=NodeKind.CLASS,
            name=name,
            fq_name=fq_name,
            start_line=self._line(node),
            end_line=self._end_line(node),
            signature=sig,
            docstring=docstring,
            visibility="public" if not name.startswith("_") else "private",
            is_test=is_test,
        )
        nodes.append(class_node)

        # Extract methods
        body = node.child_by_field_name("body")
        if body:
            for child in body.named_children:
                if child.type == "function_definition":
                    self._extract_function(
                        child, source, file_path, nodes, edges, fq_name, imported_names,
                    )
                    if nodes:
                        edges.append(
                            ExtractedEdge(
                                src_fq_name=fq_name,
                                dst_fq_name=nodes[-1].fq_name,
                                dst_name=nodes[-1].name,
                                kind=EdgeKind.OWNS,
                                confidence=Confidence.HIGH,
                            )
                        )
                elif child.type == "decorated_definition":
                    self._extract_decorated(
                        child, source, file_path, nodes, edges, fq_name, imported_names,
                    )
                    # OWNS edge for the inner definition
                    if nodes and nodes[-1].fq_name.startswith(fq_name):
                        edges.append(
                            ExtractedEdge(
                                src_fq_name=fq_name,
                                dst_fq_name=nodes[-1].fq_name,
                                dst_name=nodes[-1].name,
                                kind=EdgeKind.OWNS,
                                confidence=Confidence.HIGH,
                            )
                        )

    def _extract_function(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
        parent_fq: str | None,
        imported_names: set[str] | None = None,
    ) -> None:
        name_node = node.child_by_field_name("name")
        if not name_node:
            return
        name = self._get_text(name_node, source)
        kind = NodeKind.METHOD if parent_fq else NodeKind.FUNCTION
        fq_name = f"{parent_fq}.{name}" if parent_fq else f"{file_path}:{name}"

        # Build signature
        params = node.child_by_field_name("parameters")
        return_type = node.child_by_field_name("return_type")
        sig = self._build_signature(name, params, return_type, source)

        # Extract type annotations from params for USES_TYPE edges
        if params:
            self._extract_type_refs_from_params(params, source, fq_name, edges)

        # Extract return type for RETURNS_TYPE edge
        if return_type:
            ret_text = self._get_text(return_type, source).strip()
            if not self._is_primitive(ret_text):
                edges.append(
                    ExtractedEdge(
                        src_fq_name=fq_name,
                        dst_fq_name=ret_text,
                        dst_name=ret_text,
                        kind=EdgeKind.RETURNS_TYPE,
                        confidence=Confidence.MEDIUM,
                    )
                )

        docstring = self._extract_python_docstring(node, source)

        is_test = name.startswith("test_") or self._is_test_file(file_path)

        # Visibility
        visibility = "public"
        if name.startswith("__") and name.endswith("__"):
            visibility = "public"  # dunder methods
        elif name.startswith("__"):
            visibility = "private"
        elif name.startswith("_"):
            visibility = "protected"

        func_node = ExtractedNode(
            kind=kind,
            name=name,
            fq_name=fq_name,
            start_line=self._line(node),
            end_line=self._end_line(node),
            signature=sig,
            docstring=docstring,
            visibility=visibility,
            is_test=is_test,
        )
        nodes.append(func_node)

        # Extract calls within the body
        body = node.child_by_field_name("body")
        if body:
            self._extract_calls(body, source, fq_name, edges, imported_names)

    def _extract_decorated(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
        parent_fq: str | None,
        imported_names: set[str] | None = None,
    ) -> None:
        """Handle decorated_definition: extract decorators + inner definition."""
        decorators: list[str] = []
        definition: Node | None = None

        for child in node.named_children:
            if child.type == "decorator":
                dec_text = self._get_text(child, source).lstrip("@").strip()
                dec_name = dec_text[: dec_text.index("(")] if "(" in dec_text else dec_text
                decorators.append(dec_name)
            elif child.type in ("function_definition", "class_definition"):
                definition = child

        if definition:
            before = len(nodes)
            self._walk(definition, source, file_path, nodes, edges, parent_fq, imported_names)

            # Add DECORATES edges for newly added nodes
            for n in nodes[before:]:
                for dec_name in decorators:
                    edges.append(
                        ExtractedEdge(
                            src_fq_name=dec_name,
                            dst_fq_name=n.fq_name,
                            dst_name=dec_name,
                            kind=EdgeKind.DECORATES,
                            confidence=Confidence.HIGH,
                        )
                    )

    def _extract_import(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        edges: list[ExtractedEdge],
    ) -> None:
        if node.type == "import_statement":
            # import foo, import foo.bar
            for child in node.named_children:
                if child.type == "dotted_name":
                    mod = self._get_text(child, source)
                    edges.append(
                        ExtractedEdge(
                            src_fq_name=f"{file_path}:<module>",
                            dst_fq_name=mod,
                            dst_name=mod.rsplit(".", 1)[-1],
                            kind=EdgeKind.IMPORTS,
                            confidence=Confidence.HIGH,
                        )
                    )
                elif child.type == "aliased_import":
                    name_node = child.child_by_field_name("name")
                    if name_node:
                        mod = self._get_text(name_node, source)
                        edges.append(
                            ExtractedEdge(
                                src_fq_name=f"{file_path}:<module>",
                                dst_fq_name=mod,
                                dst_name=mod.rsplit(".", 1)[-1],
                                kind=EdgeKind.IMPORTS,
                                confidence=Confidence.HIGH,
                            )
                        )
        elif node.type == "import_from_statement":
            # from foo import bar, baz
            module_name = node.child_by_field_name("module_name")
            mod = self._get_text(module_name, source) if module_name else ""

            for child in node.named_children:
                if child.type == "dotted_name" and child != module_name:
                    name = self._get_text(child, source)
                    edges.append(
                        ExtractedEdge(
                            src_fq_name=f"{file_path}:<module>",
                            dst_fq_name=f"{mod}.{name}" if mod else name,
                            dst_name=name,
                            kind=EdgeKind.IMPORTS,
                            confidence=Confidence.HIGH,
                        )
                    )
                elif child.type == "aliased_import":
                    name_node = child.child_by_field_name("name")
                    if name_node:
                        name = self._get_text(name_node, source)
                        edges.append(
                            ExtractedEdge(
                                src_fq_name=f"{file_path}:<module>",
                                dst_fq_name=f"{mod}.{name}" if mod else name,
                                dst_name=name,
                                kind=EdgeKind.IMPORTS,
                                confidence=Confidence.HIGH,
                            )
                        )

    # ---- Call extraction ----

    def _extract_calls(
        self,
        node: Node,
        source: bytes,
        caller_fq: str,
        edges: list[ExtractedEdge],
        imported_names: set[str] | None = None,
    ) -> None:
        if node.type == "call":
            func_node = node.child_by_field_name("function")
            if func_node:
                callee = self._get_text(func_node, source)
                parts = callee.rsplit(".", 1)
                if len(parts) == 2:
                    receiver, method_name = parts
                else:
                    receiver, method_name = None, parts[0]

                if self.should_extract_call(receiver, method_name, imported_names):
                    edges.append(
                        ExtractedEdge(
                            src_fq_name=caller_fq,
                            dst_fq_name=callee,
                            dst_name=method_name,
                            kind=EdgeKind.CALLS,
                            confidence=Confidence.MEDIUM,
                        )
                    )
        elif node.type == "raise_statement":
            # Extract THROWS edges
            for child in node.named_children:
                if child.type == "call":
                    func_node = child.child_by_field_name("function")
                    if func_node:
                        exc_name = self._get_text(func_node, source)
                        edges.append(
                            ExtractedEdge(
                                src_fq_name=caller_fq,
                                dst_fq_name=exc_name,
                                dst_name=exc_name,
                                kind=EdgeKind.THROWS,
                                confidence=Confidence.MEDIUM,
                            )
                        )

        for child in node.children:
            self._extract_calls(child, source, caller_fq, edges, imported_names)

    # ---- Helpers ----

    def _build_signature(
        self,
        name: str,
        params_node: Node | None,
        return_type_node: Node | None,
        source: bytes,
    ) -> str:
        sig = f"def {name}"
        if params_node:
            sig += self._get_text(params_node, source)
        if return_type_node:
            sig += f" -> {self._get_text(return_type_node, source)}"
        return sig

    def _extract_python_docstring(self, node: Node, source: bytes) -> str | None:
        """Extract docstring from the first statement of a class/function body."""
        body = node.child_by_field_name("body")
        if not body or not body.named_children:
            return None
        first = body.named_children[0]
        if first.type == "expression_statement":
            child = first.named_children[0] if first.named_children else None
            if child and child.type == "string":
                text = self._get_text(child, source)
                for q in ['"""', "'''"]:
                    text = text.removeprefix(q).removesuffix(q)
                return text.strip() or None
        return None

    def _extract_type_refs_from_params(
        self,
        params_node: Node,
        source: bytes,
        fq_name: str,
        edges: list[ExtractedEdge],
    ) -> None:
        for param in params_node.named_children:
            type_node = param.child_by_field_name("type")
            if type_node:
                type_name = self._get_text(type_node, source).strip()
                if not self._is_primitive(type_name) and type_name != "self":
                    edges.append(
                        ExtractedEdge(
                            src_fq_name=fq_name,
                            dst_fq_name=type_name,
                            dst_name=type_name,
                            kind=EdgeKind.USES_TYPE,
                            confidence=Confidence.MEDIUM,
                        )
                    )

    def _is_primitive(self, name: str) -> bool:
        return name.lower() in {
            "str", "int", "float", "bool", "none", "bytes",
            "list", "dict", "set", "tuple", "type", "any",
            "optional", "self", "cls",
        }

    def _is_test_file(self, file_path: str) -> bool:
        parts = file_path.replace("\\", "/").split("/")
        basename = parts[-1] if parts else ""
        return (
            "tests/" in file_path
            or "/test_" in file_path
            or basename.startswith("test_")
            or basename.endswith("_test.py")
        )
