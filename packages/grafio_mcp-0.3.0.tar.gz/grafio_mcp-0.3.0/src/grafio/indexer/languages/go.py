from __future__ import annotations

from typing import TYPE_CHECKING

from grafio.models import (
    Confidence,
    EdgeKind,
    ExtractedEdge,
    ExtractedNode,
    Language,
    NodeKind,
)

from .base import LanguageExtractor

if TYPE_CHECKING:
    from tree_sitter import Node, Tree


class GoExtractor(LanguageExtractor):
    """Extracts nodes and edges from Go source files."""

    def language(self) -> Language:
        return Language.GO

    def extract(
        self, tree: Tree, source: bytes, file_path: str
    ) -> tuple[list[ExtractedNode], list[ExtractedEdge]]:
        nodes: list[ExtractedNode] = []
        edges: list[ExtractedEdge] = []
        self._walk(tree.root_node, source, file_path, nodes, edges)
        return nodes, edges

    def _walk(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
    ) -> None:
        if node.type == "function_declaration":
            self._extract_function(node, source, file_path, nodes, edges)
        elif node.type == "method_declaration":
            self._extract_method(node, source, file_path, nodes, edges)
        elif node.type == "type_declaration":
            self._extract_type_decl(node, source, file_path, nodes, edges)
        elif node.type == "import_declaration":
            self._extract_import(node, source, file_path, edges)
        else:
            for child in node.named_children:
                self._walk(child, source, file_path, nodes, edges)

    # ---- Node extractors ----

    def _extract_function(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
    ) -> None:
        name_node = node.child_by_field_name("name")
        if not name_node:
            return
        name = self._get_text(name_node, source)
        fq_name = f"{file_path}:{name}"

        params = node.child_by_field_name("parameters")
        result = node.child_by_field_name("result")
        sig = f"func {name}"
        if params:
            sig += self._get_text(params, source)
        if result:
            sig += f" {self._get_text(result, source)}"

        is_exported = name[0].isupper() if name else False
        is_test = self._is_test_file(file_path) and name.startswith("Test")

        func_node = ExtractedNode(
            kind=NodeKind.FUNCTION,
            name=name,
            fq_name=fq_name,
            start_line=self._line(node),
            end_line=self._end_line(node),
            signature=sig,
            docstring=self._get_docstring_before(node, source),
            visibility="public" if is_exported else "private",
            is_exported=is_exported,
            is_test=is_test,
        )
        nodes.append(func_node)

        body = node.child_by_field_name("body")
        if body:
            self._extract_calls(body, source, fq_name, edges)

    def _extract_method(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
    ) -> None:
        name_node = node.child_by_field_name("name")
        if not name_node:
            return
        name = self._get_text(name_node, source)

        # Get receiver type
        receiver = node.child_by_field_name("receiver")
        receiver_type = ""
        if receiver:
            # Extract type name from parameter list
            for child in receiver.named_children:
                type_node = child.child_by_field_name("type")
                if type_node:
                    receiver_type = self._get_text(type_node, source).lstrip("*")
                    break

        fq_name = f"{file_path}:{receiver_type}.{name}" if receiver_type else f"{file_path}:{name}"

        params = node.child_by_field_name("parameters")
        result = node.child_by_field_name("result")
        sig = f"func ({receiver_type}) {name}" if receiver_type else f"func {name}"
        if params:
            sig += self._get_text(params, source)
        if result:
            sig += f" {self._get_text(result, source)}"

        is_exported = name[0].isupper() if name else False

        method_node = ExtractedNode(
            kind=NodeKind.METHOD,
            name=name,
            fq_name=fq_name,
            start_line=self._line(node),
            end_line=self._end_line(node),
            signature=sig,
            docstring=self._get_docstring_before(node, source),
            visibility="public" if is_exported else "private",
            is_exported=is_exported,
            is_test=self._is_test_file(file_path) and name.startswith("Test"),
        )
        nodes.append(method_node)

        # OWNS edge: receiver struct → method
        if receiver_type:
            edges.append(
                ExtractedEdge(
                    src_fq_name=f"{file_path}:{receiver_type}",
                    dst_fq_name=fq_name,
                    dst_name=name,
                    kind=EdgeKind.OWNS,
                    confidence=Confidence.HIGH,
                )
            )

        body = node.child_by_field_name("body")
        if body:
            self._extract_calls(body, source, fq_name, edges)

    def _extract_type_decl(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
    ) -> None:
        """Extract type declarations: struct, interface, type alias."""
        for spec in node.named_children:
            if spec.type != "type_spec":
                continue
            name_node = spec.child_by_field_name("name")
            type_node = spec.child_by_field_name("type")
            if not name_node or not type_node:
                continue

            name = self._get_text(name_node, source)
            fq_name = f"{file_path}:{name}"
            is_exported = name[0].isupper() if name else False

            if type_node.type == "struct_type":
                struct_node = ExtractedNode(
                    kind=NodeKind.STRUCT,
                    name=name,
                    fq_name=fq_name,
                    start_line=self._line(spec),
                    end_line=self._end_line(spec),
                    signature=f"type {name} struct",
                    docstring=self._get_docstring_before(node, source),
                    visibility="public" if is_exported else "private",
                    is_exported=is_exported,
                )
                nodes.append(struct_node)

                # Extract USES_TYPE edges from struct fields
                for field in type_node.named_children:
                    if field.type == "field_declaration":
                        ft = field.child_by_field_name("type")
                        if ft:
                            ft_name = self._get_text(ft, source).lstrip("*").lstrip("[]")
                            if ft_name and ft_name[0].isupper():
                                edges.append(
                                    ExtractedEdge(
                                        src_fq_name=fq_name,
                                        dst_fq_name=ft_name,
                                        dst_name=ft_name,
                                        kind=EdgeKind.USES_TYPE,
                                        confidence=Confidence.MEDIUM,
                                    )
                                )

            elif type_node.type == "interface_type":
                iface_node = ExtractedNode(
                    kind=NodeKind.INTERFACE,
                    name=name,
                    fq_name=fq_name,
                    start_line=self._line(spec),
                    end_line=self._end_line(spec),
                    signature=f"type {name} interface",
                    docstring=self._get_docstring_before(node, source),
                    visibility="public" if is_exported else "private",
                    is_exported=is_exported,
                )
                nodes.append(iface_node)

                # Embedded interfaces → EXTENDS
                for child in type_node.named_children:
                    if child.type == "type_identifier":
                        embedded = self._get_text(child, source)
                        edges.append(
                            ExtractedEdge(
                                src_fq_name=fq_name,
                                dst_fq_name=embedded,
                                dst_name=embedded,
                                kind=EdgeKind.EXTENDS,
                                confidence=Confidence.HIGH,
                            )
                        )
            else:
                # Type alias
                ta_node = ExtractedNode(
                    kind=NodeKind.TYPE_ALIAS,
                    name=name,
                    fq_name=fq_name,
                    start_line=self._line(spec),
                    end_line=self._end_line(spec),
                    signature=f"type {name} {self._get_text(type_node, source)}",
                    docstring=self._get_docstring_before(node, source),
                    visibility="public" if is_exported else "private",
                    is_exported=is_exported,
                )
                nodes.append(ta_node)

    def _extract_import(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        edges: list[ExtractedEdge],
    ) -> None:
        for child in node.named_children:
            if child.type == "import_spec_list":
                for spec in child.named_children:
                    if spec.type == "import_spec":
                        path_node = spec.child_by_field_name("path")
                        if path_node:
                            path = self._get_text(path_node, source).strip('"')
                            short = path.rsplit("/", 1)[-1]
                            edges.append(
                                ExtractedEdge(
                                    src_fq_name=f"{file_path}:<module>",
                                    dst_fq_name=path,
                                    dst_name=short,
                                    kind=EdgeKind.IMPORTS,
                                    confidence=Confidence.HIGH,
                                )
                            )
            elif child.type == "import_spec":
                path_node = child.child_by_field_name("path")
                if path_node:
                    path = self._get_text(path_node, source).strip('"')
                    short = path.rsplit("/", 1)[-1]
                    edges.append(
                        ExtractedEdge(
                            src_fq_name=f"{file_path}:<module>",
                            dst_fq_name=path,
                            dst_name=short,
                            kind=EdgeKind.IMPORTS,
                            confidence=Confidence.HIGH,
                        )
                    )

    # ---- Call extraction ----

    def _extract_calls(
        self,
        node: Node,
        source: bytes,
        caller_fq: str,
        edges: list[ExtractedEdge],
        imported_names: set[str] | None = None,
    ) -> None:
        if node.type == "call_expression":
            func_node = node.child_by_field_name("function")
            if func_node:
                callee = self._get_text(func_node, source)
                parts = callee.rsplit(".", 1)
                if len(parts) == 2:
                    receiver, method_name = parts
                else:
                    receiver, method_name = None, parts[0]

                if self.should_extract_call(receiver, method_name, imported_names):
                    edges.append(
                        ExtractedEdge(
                            src_fq_name=caller_fq,
                            dst_fq_name=callee,
                            dst_name=method_name,
                            kind=EdgeKind.CALLS,
                            confidence=Confidence.MEDIUM,
                        )
                    )

        for child in node.children:
            self._extract_calls(child, source, caller_fq, edges, imported_names)

    # ---- Helpers ----

    def _is_test_file(self, file_path: str) -> bool:
        return file_path.endswith("_test.go")
