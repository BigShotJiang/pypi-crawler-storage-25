from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tree_sitter import Node, Tree

    from grafio.models import ExtractedEdge, ExtractedNode, Language


class LanguageExtractor(ABC):
    """Base class for per-language AST extractors."""

    # Receivers that are built-in objects — never create CALLS edges to these
    BUILTIN_RECEIVERS: set[str] = {
        # JavaScript / TypeScript
        "console", "Math", "JSON", "Object", "Array", "String", "Number",
        "Boolean", "Date", "RegExp", "Error", "Promise", "Map", "Set",
        "WeakMap", "WeakSet", "Symbol", "Proxy", "Reflect", "Intl",
        "Buffer", "process", "global", "globalThis", "window", "document",
        "setTimeout", "setInterval", "clearTimeout", "clearInterval",
        "parseInt", "parseFloat", "isNaN", "isFinite", "fetch", "require",
        "URL", "URLSearchParams", "Headers", "Request", "Response",
        "FormData", "Blob", "File", "FileReader", "AbortController",
        "TextEncoder", "TextDecoder", "crypto", "performance",
        # Python
        "print", "len", "range", "enumerate", "zip", "map", "filter",
        "sorted", "reversed", "list", "dict", "set", "tuple", "str",
        "int", "float", "bool", "type", "isinstance", "hasattr",
        "getattr", "setattr", "delattr", "super", "property",
        "staticmethod", "classmethod", "open", "input", "repr",
        "hash", "id", "dir", "vars", "locals", "globals",
        "abs", "min", "max", "sum", "round", "pow", "divmod",
        "all", "any", "iter", "next", "callable", "format",
        "os", "sys", "re", "json", "math", "datetime",
        "logging", "pathlib", "collections", "itertools", "functools",
        "typing", "abc", "copy", "io", "subprocess", "shutil",
        # Java
        "System", "Arrays", "Collections", "Objects", "Optional",
        "Stream", "Collectors", "Integer", "Long", "Double", "Float",
        "Character", "Byte", "Short",
        "StringBuilder", "StringBuffer", "Thread", "Runnable",
        "Exception", "RuntimeException", "IllegalArgumentException",
        "NullPointerException", "IOException", "Class", "Enum",
        "Comparable", "Iterable", "Iterator", "List",
        "HashMap", "ArrayList", "HashSet", "LinkedList", "TreeMap",
        "ConcurrentHashMap", "AtomicInteger", "AtomicLong",
        "CompletableFuture", "ExecutorService", "Executors",
        "Logger", "LoggerFactory",
        # Go
        "fmt", "log", "strings", "strconv", "errors",
        "context", "sync", "time", "sort", "bytes", "regexp",
        "encoding", "net", "http", "filepath", "reflect", "testing",
        "xml", "csv",
        # Rust
        "println", "eprintln", "vec",
        "Box", "Rc", "Arc", "Option", "Result", "Ok", "Err",
        "Some", "None", "BTreeMap",
        "std", "core", "alloc",
    }

    # Method names that are almost certainly built-in, not user-defined
    BUILTIN_METHODS: set[str] = {
        # Collection methods (JS/Python/Java/Go)
        "push", "pop", "shift", "unshift", "splice", "slice", "concat",
        "map", "filter", "reduce", "forEach", "find", "findIndex",
        "some", "every", "includes", "indexOf", "lastIndexOf",
        "join", "sort", "reverse", "flat", "flatMap", "fill",
        "keys", "values", "entries", "from", "of", "isArray",
        "append", "extend", "insert", "remove", "clear", "copy",
        "count", "index", "add", "update", "discard",
        "difference", "intersection", "union", "issubset", "issuperset",
        "put", "putAll", "containsKey", "containsValue", "keySet",
        "entrySet", "isEmpty", "size", "toArray",
        "stream", "collect", "orElse", "orElseGet", "orElseThrow",
        "isPresent", "ifPresent", "ofNullable", "empty",
        # String methods
        "split", "trim", "trimStart", "trimEnd", "replace", "replaceAll",
        "match", "search", "test", "exec",
        "startsWith", "endsWith", "substring", "substr",
        "toLowerCase", "toUpperCase", "toLocaleLowerCase", "toLocaleUpperCase",
        "padStart", "padEnd", "repeat", "charAt", "charCodeAt", "codePointAt",
        "normalize", "localeCompare", "at",
        "strip", "lstrip", "rstrip", "lower", "upper", "title", "capitalize",
        "swapcase", "center", "ljust", "rjust", "zfill",
        "encode", "decode", "format", "format_map",
        "isdigit", "isalpha", "isalnum", "isspace", "isupper", "islower",
        "contains", "length",
        "equalsIgnoreCase", "compareTo", "matches", "intern",
        # Object / utility methods
        "toString", "valueOf", "hasOwnProperty", "isPrototypeOf",
        "propertyIsEnumerable", "toLocaleString", "toFixed", "toPrecision",
        "toJSON", "stringify", "parse",
        "assign", "create", "defineProperty", "defineProperties",
        "freeze", "seal", "preventExtensions", "getPrototypeOf",
        "setPrototypeOf", "getOwnPropertyDescriptor", "getOwnPropertyNames",
        "__repr__", "__str__", "__init__", "__del__", "__new__",
        "__eq__", "__ne__", "__lt__", "__gt__", "__le__", "__ge__",
        "__hash__", "__bool__", "__len__", "__iter__", "__next__",
        "__getitem__", "__setitem__", "__delitem__", "__contains__",
        "__enter__", "__exit__", "__call__", "__getattr__", "__setattr__",
        "equals", "hashCode", "getClass", "notify", "notifyAll", "wait",
        "clone", "finalize",
        # Promise / async methods
        "then", "catch", "finally", "resolve", "reject", "all", "race",
        "allSettled", "any",
        # Logging
        "log", "warn", "error", "info", "debug", "trace", "fatal",
        "warning", "critical", "exception",
        # I/O and lifecycle
        "close", "open", "read", "write", "flush", "seek",
        "listen", "bind", "connect", "accept", "send", "recv",
        "start", "stop", "run", "execute", "shutdown",
        "on", "off", "emit", "once", "addEventListener", "removeEventListener",
        "subscribe", "unsubscribe", "dispatch", "publish",
        # Type conversion / checking
        "Number", "String", "Boolean", "BigInt",
        "parseInt", "parseFloat",
        # Generic getters/setters that are too ambiguous
        "get", "set", "has", "delete",
        "getOrDefault", "putIfAbsent", "computeIfAbsent", "computeIfPresent",
        "next", "throw", "return",
    }

    def should_extract_call(
        self,
        receiver: str | None,
        method_name: str,
        imported_names: set[str] | None = None,
    ) -> bool:
        """Decide whether a call expression should become a CALLS edge."""
        # Skip empty or very short names (likely variables or operators)
        if not method_name or len(method_name) <= 1:
            return False

        # Skip names that are ALL_CAPS (likely constants, not functions)
        if method_name.isupper() and len(method_name) > 2:
            return False

        # Skip built-in methods
        if method_name in self.BUILTIN_METHODS:
            return False

        # Extract the root receiver (first part before any dots)
        if receiver:
            root_receiver = receiver.split(".")[0]
            # "this" and "self" are fine — they reference the current instance
            if root_receiver not in ("this", "self") and root_receiver in self.BUILTIN_RECEIVERS:
                return False

        # If we have import information, prefer calls to imported symbols
        if imported_names is not None and receiver:
            root_receiver = receiver.split(".")[0]
            if root_receiver not in ("this", "self") and root_receiver not in imported_names:
                return False

        return True

    @abstractmethod
    def language(self) -> Language: ...

    @abstractmethod
    def extract(
        self, tree: Tree, source: bytes, file_path: str
    ) -> tuple[list[ExtractedNode], list[ExtractedEdge]]: ...

    def _get_text(self, node: Node, source: bytes) -> str:
        """Extract text content of a tree-sitter node."""
        return source[node.start_byte : node.end_byte].decode("utf-8", errors="replace")

    def _get_docstring_before(self, node: Node, source: bytes) -> str | None:
        """Get comment/docstring immediately preceding a node."""
        prev = node.prev_named_sibling
        if prev and prev.type == "comment":
            text = self._get_text(prev, source).strip()
            for prefix in ["///", "//", "#", "/**", "/*", "*/", "*"]:
                text = text.removeprefix(prefix)
            return text.strip() or None
        return None

    def _line(self, node: Node) -> int:
        """1-based line number."""
        return node.start_point[0] + 1

    def _end_line(self, node: Node) -> int:
        """1-based end line number."""
        return node.end_point[0] + 1

    def _is_test_file(self, file_path: str) -> bool:
        return False

    def _find_children_by_type(self, node: Node, type_name: str) -> list[Node]:
        """Find all direct children of given type."""
        return [c for c in node.children if c.type == type_name]

    def _find_named_children_by_type(self, node: Node, type_name: str) -> list[Node]:
        """Find all named children of given type."""
        return [c for c in node.named_children if c.type == type_name]
