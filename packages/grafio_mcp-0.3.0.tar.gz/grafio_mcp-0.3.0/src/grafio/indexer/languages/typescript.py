from __future__ import annotations

from typing import TYPE_CHECKING

from grafio.models import (
    Confidence,
    EdgeKind,
    ExtractedEdge,
    ExtractedNode,
    Language,
    NodeKind,
)

from .base import LanguageExtractor

if TYPE_CHECKING:
    from tree_sitter import Node, Tree


class TypeScriptExtractor(LanguageExtractor):
    """Extracts nodes and edges from TypeScript/JavaScript source files."""

    def language(self) -> Language:
        return Language.TYPESCRIPT

    def extract(
        self, tree: Tree, source: bytes, file_path: str
    ) -> tuple[list[ExtractedNode], list[ExtractedEdge]]:
        nodes: list[ExtractedNode] = []
        edges: list[ExtractedEdge] = []
        imported_names = self._collect_imports(tree.root_node, source)
        self._walk(
            tree.root_node, source, file_path, nodes, edges,
            parent_fq=None, imported_names=imported_names,
        )
        return nodes, edges

    def _collect_imports(self, root: Node, source: bytes) -> set[str]:
        """Collect all imported names in a file for call filtering."""
        names: set[str] = set()
        for child in root.children:
            if child.type == "import_statement":
                for sub in child.named_children:
                    if sub.type == "import_clause":
                        for ic in sub.named_children:
                            if ic.type == "named_imports":
                                for spec in ic.named_children:
                                    if spec.type == "import_specifier":
                                        text = self._get_text(spec, source).strip()
                                        if " as " in text:
                                            # Use alias for matching
                                            names.add(text.split(" as ")[-1].strip())
                                        else:
                                            names.add(text)
                            elif ic.type == "identifier":
                                names.add(self._get_text(ic, source))
        return names

    def _walk(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
        parent_fq: str | None,
        imported_names: set[str] | None = None,
    ) -> None:
        if node.type == "class_declaration":
            self._extract_class(node, source, file_path, nodes, edges, parent_fq, imported_names)
        elif node.type == "function_declaration":
            self._extract_function(node, source, file_path, nodes, edges, parent_fq, imported_names)
        elif node.type == "interface_declaration":
            self._extract_interface(node, source, file_path, nodes, edges, parent_fq)
        elif node.type == "type_alias_declaration":
            self._extract_type_alias(node, source, file_path, nodes, edges, parent_fq)
        elif node.type == "enum_declaration":
            self._extract_enum(node, source, file_path, nodes, edges, parent_fq)
        elif node.type == "import_statement":
            self._extract_import(node, source, file_path, edges)
        elif node.type == "lexical_declaration":
            self._extract_variable_or_arrow(
                node, source, file_path, nodes, edges, parent_fq, imported_names,
            )
        elif node.type == "export_statement":
            for child in node.named_children:
                before = len(nodes)
                self._walk(child, source, file_path, nodes, edges, parent_fq, imported_names)
                # Mark newly added nodes as exported
                for n in nodes[before:]:
                    n.is_exported = True
            return
        else:
            for child in node.named_children:
                self._walk(child, source, file_path, nodes, edges, parent_fq, imported_names)

    # ---- Node extractors ----

    def _extract_class(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
        parent_fq: str | None,
        imported_names: set[str] | None = None,
    ) -> None:
        name_node = node.child_by_field_name("name")
        if not name_node:
            return
        name = self._get_text(name_node, source)
        fq_name = f"{parent_fq}.{name}" if parent_fq else f"{file_path}:{name}"

        # Build signature
        sig = f"class {name}"

        # Check heritage (extends, implements)
        for child in node.children:
            if child.type == "class_heritage":
                for clause in child.children:
                    if clause.type == "extends_clause":
                        for c in clause.named_children:
                            base_name = self._get_text(c, source)
                            sig += f" extends {base_name}"
                            edges.append(
                                ExtractedEdge(
                                    src_fq_name=fq_name,
                                    dst_fq_name=base_name,
                                    dst_name=base_name,
                                    kind=EdgeKind.EXTENDS,
                                    confidence=Confidence.HIGH,
                                )
                            )
                    elif clause.type == "implements_clause":
                        for c in clause.named_children:
                            iface_name = self._get_text(c, source)
                            sig += f" implements {iface_name}"
                            edges.append(
                                ExtractedEdge(
                                    src_fq_name=fq_name,
                                    dst_fq_name=iface_name,
                                    dst_name=iface_name,
                                    kind=EdgeKind.IMPLEMENTS,
                                    confidence=Confidence.HIGH,
                                )
                            )

        class_node = ExtractedNode(
            kind=NodeKind.CLASS,
            name=name,
            fq_name=fq_name,
            start_line=self._line(node),
            end_line=self._end_line(node),
            signature=sig,
            docstring=self._get_docstring_before(node, source),
            visibility="public",
            is_test=self._is_test_file(file_path),
        )
        nodes.append(class_node)

        # Extract methods inside the class body
        body = node.child_by_field_name("body")
        if body:
            pending_decorator: str | None = None
            for child in body.named_children:
                if child.type == "decorator":
                    dec_text = self._get_text(child, source).lstrip("@")
                    pending_decorator = dec_text
                    continue
                if child.type == "method_definition":
                    self._extract_method(
                        child, source, file_path, nodes, edges, fq_name, imported_names,
                    )
                    if nodes:
                        edges.append(
                            ExtractedEdge(
                                src_fq_name=fq_name,
                                dst_fq_name=nodes[-1].fq_name,
                                dst_name=nodes[-1].name,
                                kind=EdgeKind.OWNS,
                                confidence=Confidence.HIGH,
                            )
                        )
                    if pending_decorator:
                        edges.append(
                            ExtractedEdge(
                                src_fq_name=pending_decorator,
                                dst_fq_name=nodes[-1].fq_name if nodes else "",
                                dst_name=pending_decorator,
                                kind=EdgeKind.DECORATES,
                                confidence=Confidence.HIGH,
                            )
                        )
                        pending_decorator = None
                elif child.type == "public_field_definition":
                    pass  # Skip class fields for now
                else:
                    pending_decorator = None

    def _extract_method(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
        parent_fq: str,
        imported_names: set[str] | None = None,
    ) -> None:
        name_node = node.child_by_field_name("name")
        if not name_node:
            return
        name = self._get_text(name_node, source)
        fq_name = f"{parent_fq}.{name}"

        # Build signature
        params_node = node.child_by_field_name("parameters")
        return_type_node = node.child_by_field_name("return_type")
        sig = self._build_signature(name, params_node, return_type_node, source)

        # Extract type annotations from parameters for USES_TYPE edges
        if params_node:
            self._extract_type_refs_from_params(params_node, source, fq_name, edges)

        # Extract return type for RETURNS_TYPE edge
        if return_type_node:
            ret_type = self._get_text(return_type_node, source).lstrip(": ").strip()
            # Strip Promise<> wrapper
            inner = self._unwrap_generic(ret_type)
            if inner and not self._is_primitive(inner):
                edges.append(
                    ExtractedEdge(
                        src_fq_name=fq_name,
                        dst_fq_name=inner,
                        dst_name=inner,
                        kind=EdgeKind.RETURNS_TYPE,
                        confidence=Confidence.MEDIUM,
                    )
                )

        # Extract calls in body
        body = node.child_by_field_name("body")
        if body:
            self._extract_calls(body, source, fq_name, edges, imported_names)

        method_node = ExtractedNode(
            kind=NodeKind.METHOD,
            name=name,
            fq_name=fq_name,
            start_line=self._line(node),
            end_line=self._end_line(node),
            signature=sig,
            docstring=self._get_docstring_before(node, source),
            visibility=self._get_method_visibility(node, source),
            is_test=self._is_test_file(file_path),
        )
        nodes.append(method_node)

    def _extract_function(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
        parent_fq: str | None,
        imported_names: set[str] | None = None,
    ) -> None:
        name_node = node.child_by_field_name("name")
        if not name_node:
            return
        name = self._get_text(name_node, source)
        fq_name = f"{parent_fq}.{name}" if parent_fq else f"{file_path}:{name}"

        params_node = node.child_by_field_name("parameters")
        return_type_node = node.child_by_field_name("return_type")
        sig = self._build_signature(name, params_node, return_type_node, source)

        if params_node:
            self._extract_type_refs_from_params(params_node, source, fq_name, edges)

        body = node.child_by_field_name("body")
        if body:
            self._extract_calls(body, source, fq_name, edges, imported_names)

        func_node = ExtractedNode(
            kind=NodeKind.FUNCTION,
            name=name,
            fq_name=fq_name,
            start_line=self._line(node),
            end_line=self._end_line(node),
            signature=sig,
            docstring=self._get_docstring_before(node, source),
            visibility="public",
            is_test=self._is_test_file(file_path) or self._is_test_name(name),
        )
        nodes.append(func_node)

    def _extract_interface(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
        parent_fq: str | None,
    ) -> None:
        name_node = node.child_by_field_name("name")
        if not name_node:
            return
        name = self._get_text(name_node, source)
        fq_name = f"{parent_fq}.{name}" if parent_fq else f"{file_path}:{name}"

        sig = f"interface {name}"

        # Check extends
        for child in node.children:
            if child.type == "extends_type_clause":
                for c in child.named_children:
                    base = self._get_text(c, source)
                    sig += f" extends {base}"
                    edges.append(
                        ExtractedEdge(
                            src_fq_name=fq_name,
                            dst_fq_name=base,
                            dst_name=base,
                            kind=EdgeKind.EXTENDS,
                            confidence=Confidence.HIGH,
                        )
                    )

        iface_node = ExtractedNode(
            kind=NodeKind.INTERFACE,
            name=name,
            fq_name=fq_name,
            start_line=self._line(node),
            end_line=self._end_line(node),
            signature=sig,
            docstring=self._get_docstring_before(node, source),
            visibility="public",
        )
        nodes.append(iface_node)

    def _extract_type_alias(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
        parent_fq: str | None,
    ) -> None:
        name_node = node.child_by_field_name("name")
        if not name_node:
            return
        name = self._get_text(name_node, source)
        fq_name = f"{parent_fq}.{name}" if parent_fq else f"{file_path}:{name}"

        ta_node = ExtractedNode(
            kind=NodeKind.TYPE_ALIAS,
            name=name,
            fq_name=fq_name,
            start_line=self._line(node),
            end_line=self._end_line(node),
            signature=self._get_text(node, source).split("{")[0].strip().rstrip(";"),
            docstring=self._get_docstring_before(node, source),
            visibility="public",
        )
        nodes.append(ta_node)

    def _extract_enum(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
        parent_fq: str | None,
    ) -> None:
        name_node = node.child_by_field_name("name")
        if not name_node:
            return
        name = self._get_text(name_node, source)
        fq_name = f"{parent_fq}.{name}" if parent_fq else f"{file_path}:{name}"

        enum_node = ExtractedNode(
            kind=NodeKind.ENUM,
            name=name,
            fq_name=fq_name,
            start_line=self._line(node),
            end_line=self._end_line(node),
            signature=f"enum {name}",
            docstring=self._get_docstring_before(node, source),
            visibility="public",
        )
        nodes.append(enum_node)

    def _extract_variable_or_arrow(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
        parent_fq: str | None,
        imported_names: set[str] | None = None,
    ) -> None:
        """Extract const/let declarations — arrow functions become Function nodes."""
        for child in node.named_children:
            if child.type != "variable_declarator":
                continue
            name_node = child.child_by_field_name("name")
            value_node = child.child_by_field_name("value")
            if not name_node:
                continue

            name = self._get_text(name_node, source)
            fq_name = f"{parent_fq}.{name}" if parent_fq else f"{file_path}:{name}"

            if value_node and value_node.type == "arrow_function":
                # Arrow function → extract as Function
                params_node = value_node.child_by_field_name("parameters")
                return_type_node = value_node.child_by_field_name("return_type")
                sig = self._build_signature(name, params_node, return_type_node, source)

                body = value_node.child_by_field_name("body")
                if body:
                    self._extract_calls(body, source, fq_name, edges, imported_names)

                func_node = ExtractedNode(
                    kind=NodeKind.FUNCTION,
                    name=name,
                    fq_name=fq_name,
                    start_line=self._line(node),
                    end_line=self._end_line(node),
                    signature=sig,
                    docstring=self._get_docstring_before(node, source),
                    visibility="public",
                    is_test=self._is_test_file(file_path) or self._is_test_name(name),
                )
                nodes.append(func_node)
            else:
                # Regular variable — only extract if top-level
                if parent_fq is None:
                    var_node = ExtractedNode(
                        kind=NodeKind.VARIABLE,
                        name=name,
                        fq_name=fq_name,
                        start_line=self._line(node),
                        end_line=self._end_line(node),
                        visibility="public",
                    )
                    nodes.append(var_node)

    def _extract_import(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        edges: list[ExtractedEdge],
    ) -> None:
        """Extract import statements into IMPORTS edges."""
        # Find the source module path
        source_path: str | None = None
        for child in node.children:
            if child.type == "string":
                source_path = self._get_text(child, source).strip("\"'")
                break

        if not source_path:
            return

        # Find imported names
        import_clause = None
        for child in node.named_children:
            if child.type == "import_clause":
                import_clause = child
                break

        if not import_clause:
            return

        for child in import_clause.named_children:
            if child.type == "named_imports":
                for spec in child.named_children:
                    if spec.type == "import_specifier":
                        imported_name = self._get_text(spec, source).strip()
                        # Handle "X as Y" — take the original name
                        if " as " in imported_name:
                            imported_name = imported_name.split(" as ")[0].strip()
                        edges.append(
                            ExtractedEdge(
                                src_fq_name=f"{file_path}:<module>",
                                dst_fq_name=f"{source_path}:{imported_name}",
                                dst_name=imported_name,
                                kind=EdgeKind.IMPORTS,
                                confidence=Confidence.HIGH,
                            )
                        )
            elif child.type == "identifier":
                # Default import
                default_name = self._get_text(child, source)
                edges.append(
                    ExtractedEdge(
                        src_fq_name=f"{file_path}:<module>",
                        dst_fq_name=f"{source_path}:{default_name}",
                        dst_name=default_name,
                        kind=EdgeKind.IMPORTS,
                        confidence=Confidence.HIGH,
                    )
                )

    # ---- Call extraction ----

    def _extract_calls(
        self,
        node: Node,
        source: bytes,
        caller_fq: str,
        edges: list[ExtractedEdge],
        imported_names: set[str] | None = None,
    ) -> None:
        """Recursively find call_expression and new_expression in a subtree."""
        if node.type == "call_expression":
            func_node = node.child_by_field_name("function")
            if func_node:
                callee = self._get_text(func_node, source)
                # Parse receiver and method name
                parts = callee.rsplit(".", 1)
                if len(parts) == 2:
                    receiver, method_name = parts
                else:
                    receiver, method_name = None, parts[0]

                if self.should_extract_call(receiver, method_name, imported_names):
                    edges.append(
                        ExtractedEdge(
                            src_fq_name=caller_fq,
                            dst_fq_name=callee,
                            dst_name=method_name,
                            kind=EdgeKind.CALLS,
                            confidence=Confidence.MEDIUM,
                        )
                    )
        elif node.type == "new_expression":
            constructor = node.child_by_field_name("constructor")
            if constructor:
                class_name = self._get_text(constructor, source)
                if self.should_extract_call(None, class_name, imported_names):
                    edges.append(
                        ExtractedEdge(
                            src_fq_name=caller_fq,
                            dst_fq_name=class_name,
                            dst_name=class_name,
                            kind=EdgeKind.CALLS,
                            confidence=Confidence.MEDIUM,
                        )
                    )

        for child in node.children:
            self._extract_calls(child, source, caller_fq, edges, imported_names)

    # ---- Helpers ----

    def _build_signature(
        self,
        name: str,
        params_node: Node | None,
        return_type_node: Node | None,
        source: bytes,
    ) -> str:
        sig = name
        if params_node:
            sig += self._get_text(params_node, source)
        if return_type_node:
            sig += self._get_text(return_type_node, source)
        return sig

    def _extract_type_refs_from_params(
        self,
        params_node: Node,
        source: bytes,
        fq_name: str,
        edges: list[ExtractedEdge],
    ) -> None:
        """Walk parameter type annotations and emit USES_TYPE edges."""
        for param in params_node.named_children:
            type_ann = param.child_by_field_name("type")
            if type_ann:
                for ident in self._collect_type_identifiers(type_ann):
                    type_name = self._get_text(ident, source)
                    if not self._is_primitive(type_name):
                        edges.append(
                            ExtractedEdge(
                                src_fq_name=fq_name,
                                dst_fq_name=type_name,
                                dst_name=type_name,
                                kind=EdgeKind.USES_TYPE,
                                confidence=Confidence.MEDIUM,
                            )
                        )

    def _collect_type_identifiers(self, node: Node) -> list[Node]:
        """Recursively collect type_identifier nodes."""
        result: list[Node] = []
        if node.type == "type_identifier":
            result.append(node)
        for child in node.children:
            result.extend(self._collect_type_identifiers(child))
        return result

    def _get_method_visibility(self, node: Node, source: bytes) -> str:
        for child in node.children:
            if child.type == "accessibility_modifier":
                return self._get_text(child, source)
        return "public"

    def _unwrap_generic(self, type_str: str) -> str:
        """Unwrap Promise<X> → X, etc."""
        type_str = type_str.strip()
        if "<" in type_str and type_str.endswith(">"):
            inner = type_str[type_str.index("<") + 1 : -1]
            return inner.strip()
        return type_str

    def _is_primitive(self, name: str) -> bool:
        return name.lower() in {
            "string", "number", "boolean", "void", "null",
            "undefined", "any", "never", "unknown", "object",
            "bigint", "symbol", "int", "float", "bool",
        }

    def _is_test_file(self, file_path: str) -> bool:
        return any(p in file_path for p in [".test.", ".spec.", "__tests__/", "/tests/"])

    def _is_test_name(self, name: str) -> bool:
        return name.startswith("test") or name.startswith("Test")
