from __future__ import annotations

from typing import TYPE_CHECKING

from grafio.models import (
    Confidence,
    EdgeKind,
    ExtractedEdge,
    ExtractedNode,
    Language,
    NodeKind,
)

from .base import LanguageExtractor

if TYPE_CHECKING:
    from tree_sitter import Node, Tree


class JavaExtractor(LanguageExtractor):
    """Extracts nodes and edges from Java source files."""

    def language(self) -> Language:
        return Language.JAVA

    def extract(
        self, tree: Tree, source: bytes, file_path: str
    ) -> tuple[list[ExtractedNode], list[ExtractedEdge]]:
        nodes: list[ExtractedNode] = []
        edges: list[ExtractedEdge] = []
        # Detect package name for FQ naming
        package = self._detect_package(tree.root_node, source)
        self._walk(tree.root_node, source, file_path, nodes, edges, parent_fq=None, package=package)
        return nodes, edges

    def _walk(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
        parent_fq: str | None,
        package: str,
    ) -> None:
        if node.type == "class_declaration":
            self._extract_class(node, source, file_path, nodes, edges, parent_fq, package)
        elif node.type == "interface_declaration":
            self._extract_interface(node, source, file_path, nodes, edges, parent_fq, package)
        elif node.type == "enum_declaration":
            self._extract_enum(node, source, file_path, nodes, edges, parent_fq, package)
        elif node.type == "import_declaration":
            self._extract_import(node, source, file_path, edges)
        else:
            for child in node.named_children:
                self._walk(child, source, file_path, nodes, edges, parent_fq, package)

    # ---- Node extractors ----

    def _extract_class(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
        parent_fq: str | None,
        package: str,
    ) -> None:
        name_node = node.child_by_field_name("name")
        if not name_node:
            return
        name = self._get_text(name_node, source)

        if parent_fq:
            fq_name = f"{parent_fq}.{name}"
        elif package:
            fq_name = f"{package}.{name}"
        else:
            fq_name = f"{file_path}:{name}"

        visibility = self._get_visibility(node, source)
        sig = f"{visibility} class {name}".strip()

        # Superclass
        superclass = node.child_by_field_name("superclass")
        if superclass:
            # The superclass node contains "extends TypeName" — extract only the type
            for child in superclass.named_children:
                if child.type == "type_identifier" or child.type == "generic_type":
                    base = self._get_text(child, source).strip()
                    sig += f" extends {base}"
                    edges.append(
                        ExtractedEdge(
                            src_fq_name=fq_name,
                            dst_fq_name=base,
                            dst_name=base,
                            kind=EdgeKind.EXTENDS,
                            confidence=Confidence.HIGH,
                        )
                    )
                    break

        # Interfaces (super_interfaces → type_list → type_identifier)
        interfaces = node.child_by_field_name("interfaces")
        if interfaces:
            for child in interfaces.named_children:
                if child.type == "type_list":
                    for type_child in child.named_children:
                        iface = self._get_text(type_child, source).strip()
                        sig += f" implements {iface}"
                        edges.append(
                            ExtractedEdge(
                                src_fq_name=fq_name,
                                dst_fq_name=iface,
                                dst_name=iface,
                                kind=EdgeKind.IMPLEMENTS,
                                confidence=Confidence.HIGH,
                            )
                        )

        docstring = self._get_javadoc(node, source)
        is_test = self._is_test_file(file_path) or name.endswith("Test")

        class_node = ExtractedNode(
            kind=NodeKind.CLASS,
            name=name,
            fq_name=fq_name,
            start_line=self._line(node),
            end_line=self._end_line(node),
            signature=sig,
            docstring=docstring,
            visibility=visibility,
            is_test=is_test,
        )
        nodes.append(class_node)

        # Extract members
        body = node.child_by_field_name("body")
        if body:
            self._extract_class_members(body, source, file_path, nodes, edges, fq_name, package)

    def _extract_interface(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
        parent_fq: str | None,
        package: str,
    ) -> None:
        name_node = node.child_by_field_name("name")
        if not name_node:
            return
        name = self._get_text(name_node, source)

        if parent_fq:
            fq_name = f"{parent_fq}.{name}"
        elif package:
            fq_name = f"{package}.{name}"
        else:
            fq_name = f"{file_path}:{name}"

        visibility = self._get_visibility(node, source)
        sig = f"{visibility} interface {name}".strip()

        # Check extends
        for child in node.children:
            if child.type == "extends_interfaces":
                for c in child.named_children:
                    base = self._get_text(c, source).strip()
                    sig += f" extends {base}"
                    edges.append(
                        ExtractedEdge(
                            src_fq_name=fq_name,
                            dst_fq_name=base,
                            dst_name=base,
                            kind=EdgeKind.EXTENDS,
                            confidence=Confidence.HIGH,
                        )
                    )

        docstring = self._get_javadoc(node, source)

        iface_node = ExtractedNode(
            kind=NodeKind.INTERFACE,
            name=name,
            fq_name=fq_name,
            start_line=self._line(node),
            end_line=self._end_line(node),
            signature=sig,
            docstring=docstring,
            visibility=visibility,
        )
        nodes.append(iface_node)

        # Extract method signatures
        body = node.child_by_field_name("body")
        if body:
            self._extract_class_members(body, source, file_path, nodes, edges, fq_name, package)

    def _extract_enum(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
        parent_fq: str | None,
        package: str,
    ) -> None:
        name_node = node.child_by_field_name("name")
        if not name_node:
            return
        name = self._get_text(name_node, source)

        if parent_fq:
            fq_name = f"{parent_fq}.{name}"
        elif package:
            fq_name = f"{package}.{name}"
        else:
            fq_name = f"{file_path}:{name}"

        enum_node = ExtractedNode(
            kind=NodeKind.ENUM,
            name=name,
            fq_name=fq_name,
            start_line=self._line(node),
            end_line=self._end_line(node),
            signature=f"enum {name}",
            docstring=self._get_javadoc(node, source),
            visibility=self._get_visibility(node, source),
        )
        nodes.append(enum_node)

    _ROUTE_ANNOTATIONS = {
        "RequestMapping", "GetMapping", "PostMapping",
        "PutMapping", "DeleteMapping", "PatchMapping",
    }

    def _extract_class_members(
        self,
        body: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
        parent_fq: str,
        package: str,
    ) -> None:
        has_annotations: list[str] = []
        annotation_meta: dict[str, str] = {}
        for child in body.named_children:
            if child.type in ("marker_annotation", "annotation"):
                ann_name = ""
                for c in child.named_children:
                    if c.type == "identifier":
                        ann_name = self._get_text(c, source)
                        break
                if ann_name:
                    has_annotations.append(ann_name)
                    # Extract endpoint path from Spring mapping annotations
                    if ann_name in self._ROUTE_ANNOTATIONS:
                        path = self._extract_annotation_string_arg(child, source)
                        if path:
                            annotation_meta["endpoint"] = path
                            annotation_meta["http_method"] = (
                                ann_name.replace("Mapping", "").upper()
                                if ann_name != "RequestMapping"
                                else "REQUEST"
                            )
                continue

            if child.type == "method_declaration":
                self._extract_method(
                    child, source, file_path, nodes, edges,
                    parent_fq, has_annotations, annotation_meta,
                )
                has_annotations = []
                annotation_meta = {}
            elif child.type == "constructor_declaration":
                self._extract_constructor(
                    child, source, file_path, nodes, edges, parent_fq, has_annotations
                )
                has_annotations = []
                annotation_meta = {}
            elif child.type in ("class_declaration", "interface_declaration", "enum_declaration"):
                self._walk(child, source, file_path, nodes, edges, parent_fq, package)
                has_annotations = []
                annotation_meta = {}
            else:
                has_annotations = []
                annotation_meta = {}

    def _extract_annotation_string_arg(self, ann_node: Node, source: bytes) -> str | None:
        """Extract the first string literal argument from an annotation.

        Handles both @PostMapping("/path") and @PostMapping(value = "/path").
        """
        for child in ann_node.named_children:
            if child.type == "annotation_argument_list":
                for arg in child.named_children:
                    # Direct string: @PostMapping("/path")
                    if arg.type == "string_literal":
                        return self._get_text(arg, source).strip('"')
                    # Named value: @PostMapping(value = "/path")
                    if arg.type == "element_value_pair":
                        for val in arg.named_children:
                            if val.type == "string_literal":
                                return self._get_text(val, source).strip('"')
        return None

    def _extract_method(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
        parent_fq: str,
        annotations: list[str],
        annotation_meta: dict[str, str] | None = None,
    ) -> None:
        name_node = node.child_by_field_name("name")
        if not name_node:
            return
        name = self._get_text(name_node, source)
        fq_name = f"{parent_fq}.{name}"

        visibility = self._get_visibility(node, source)
        return_type = node.child_by_field_name("type")
        params = node.child_by_field_name("parameters")

        ret_str = self._get_text(return_type, source) if return_type else "void"
        params_str = self._get_text(params, source) if params else "()"
        sig = f"{visibility} {ret_str} {name}{params_str}".strip()

        # Extract annotations from modifiers (tree-sitter puts them there)
        modifiers = node.child_by_field_name("modifiers") or next(
            (c for c in node.children if c.type == "modifiers"), None
        )
        if modifiers:
            for mod_child in modifiers.named_children:
                if mod_child.type in ("annotation", "marker_annotation"):
                    ann_name = ""
                    for c in mod_child.named_children:
                        if c.type == "identifier":
                            ann_name = self._get_text(c, source)
                            break
                    if ann_name and ann_name not in annotations:
                        annotations.append(ann_name)
                    if ann_name in self._ROUTE_ANNOTATIONS:
                        path = self._extract_annotation_string_arg(
                            mod_child, source
                        )
                        if path and (annotation_meta is None or "endpoint" not in annotation_meta):
                            if annotation_meta is None:
                                annotation_meta = {}
                            annotation_meta["endpoint"] = path
                            annotation_meta["http_method"] = (
                                ann_name.replace("Mapping", "").upper()
                                if ann_name != "RequestMapping"
                                else "REQUEST"
                            )

        # RETURNS_TYPE edge
        _java_primitives = {
            "void", "int", "long", "double", "float",
            "boolean", "byte", "short", "char",
        }
        if return_type and ret_str not in _java_primitives:
            edges.append(
                ExtractedEdge(
                    src_fq_name=fq_name,
                    dst_fq_name=ret_str,
                    dst_name=ret_str,
                    kind=EdgeKind.RETURNS_TYPE,
                    confidence=Confidence.MEDIUM,
                )
            )

        # DECORATES edges for annotations
        for ann in annotations:
            edges.append(
                ExtractedEdge(
                    src_fq_name=ann,
                    dst_fq_name=fq_name,
                    dst_name=ann,
                    kind=EdgeKind.DECORATES,
                    confidence=Confidence.HIGH,
                )
            )

        # Check @Override
        is_override = "Override" in annotations

        docstring = self._get_javadoc(node, source)
        is_test = "Test" in annotations or self._is_test_file(file_path)

        meta: dict[str, object] = {}
        if is_override:
            meta["is_override"] = is_override
        if annotation_meta:
            meta.update(annotation_meta)

        method_node = ExtractedNode(
            kind=NodeKind.METHOD,
            name=name,
            fq_name=fq_name,
            start_line=self._line(node),
            end_line=self._end_line(node),
            signature=sig,
            docstring=docstring,
            visibility=visibility,
            is_test=is_test,
            metadata=meta,
        )
        nodes.append(method_node)

        # OWNS edge
        edges.append(
            ExtractedEdge(
                src_fq_name=parent_fq,
                dst_fq_name=fq_name,
                dst_name=name,
                kind=EdgeKind.OWNS,
                confidence=Confidence.HIGH,
            )
        )

        # OVERRIDES edge
        if is_override:
            edges.append(
                ExtractedEdge(
                    src_fq_name=fq_name,
                    dst_fq_name=f"<super>.{name}",
                    dst_name=name,
                    kind=EdgeKind.OVERRIDES,
                    confidence=Confidence.MEDIUM,
                )
            )

        # Extract calls in body
        body = node.child_by_field_name("body")
        if body:
            self._extract_calls(body, source, fq_name, edges)

        # Throws clause
        for child in node.children:
            if child.type == "throws":
                for exc in child.named_children:
                    if exc.type == "type_identifier":
                        exc_name = self._get_text(exc, source)
                        edges.append(
                            ExtractedEdge(
                                src_fq_name=fq_name,
                                dst_fq_name=exc_name,
                                dst_name=exc_name,
                                kind=EdgeKind.THROWS,
                                confidence=Confidence.HIGH,
                            )
                        )

    def _extract_constructor(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        nodes: list[ExtractedNode],
        edges: list[ExtractedEdge],
        parent_fq: str,
        annotations: list[str],
    ) -> None:
        name_node = node.child_by_field_name("name")
        name = self._get_text(name_node, source) if name_node else "<init>"
        fq_name = f"{parent_fq}.{name}"

        params = node.child_by_field_name("parameters")
        params_str = self._get_text(params, source) if params else "()"
        sig = f"{name}{params_str}"

        method_node = ExtractedNode(
            kind=NodeKind.METHOD,
            name=name,
            fq_name=fq_name,
            start_line=self._line(node),
            end_line=self._end_line(node),
            signature=sig,
            docstring=self._get_javadoc(node, source),
            visibility=self._get_visibility(node, source),
            metadata={"is_constructor": True},
        )
        nodes.append(method_node)

        edges.append(
            ExtractedEdge(
                src_fq_name=parent_fq,
                dst_fq_name=fq_name,
                dst_name=name,
                kind=EdgeKind.OWNS,
                confidence=Confidence.HIGH,
            )
        )

        body = node.child_by_field_name("body")
        if body:
            self._extract_calls(body, source, fq_name, edges)

    def _extract_import(
        self,
        node: Node,
        source: bytes,
        file_path: str,
        edges: list[ExtractedEdge],
    ) -> None:
        text = self._get_text(node, source).strip().rstrip(";")
        # "import com.example.Foo" or "import static com.example.Foo.bar"
        parts = text.split()
        if len(parts) >= 2:
            imported = parts[-1]
            short = imported.rsplit(".", 1)[-1]
            edges.append(
                ExtractedEdge(
                    src_fq_name=f"{file_path}:<module>",
                    dst_fq_name=imported,
                    dst_name=short,
                    kind=EdgeKind.IMPORTS,
                    confidence=Confidence.HIGH,
                )
            )

    # ---- Call extraction ----

    def _extract_calls(
        self,
        node: Node,
        source: bytes,
        caller_fq: str,
        edges: list[ExtractedEdge],
        imported_names: set[str] | None = None,
    ) -> None:
        if node.type == "method_invocation":
            name_node = node.child_by_field_name("name")
            if name_node:
                callee = self._get_text(name_node, source)
                obj = node.child_by_field_name("object")
                receiver = self._get_text(obj, source) if obj else None
                full = f"{receiver}.{callee}" if receiver else callee

                if self.should_extract_call(receiver, callee, imported_names):
                    edges.append(
                        ExtractedEdge(
                            src_fq_name=caller_fq,
                            dst_fq_name=full,
                            dst_name=callee,
                            kind=EdgeKind.CALLS,
                            confidence=Confidence.MEDIUM,
                        )
                    )
        elif node.type == "object_creation_expression":
            type_node = node.child_by_field_name("type")
            if type_node:
                class_name = self._get_text(type_node, source)
                if self.should_extract_call(None, class_name, imported_names):
                    edges.append(
                        ExtractedEdge(
                            src_fq_name=caller_fq,
                            dst_fq_name=class_name,
                            dst_name=class_name,
                            kind=EdgeKind.CALLS,
                            confidence=Confidence.MEDIUM,
                        )
                    )

        for child in node.children:
            self._extract_calls(child, source, caller_fq, edges, imported_names)

    # ---- Helpers ----

    def _detect_package(self, root: Node, source: bytes) -> str:
        for child in root.children:
            if child.type == "package_declaration":
                for c in child.named_children:
                    if c.type == "scoped_identifier" or c.type == "identifier":
                        return self._get_text(c, source)
        return ""

    def _get_visibility(self, node: Node, source: bytes) -> str:
        for child in node.children:
            if child.type == "modifiers":
                text = self._get_text(child, source)
                if "private" in text:
                    return "private"
                if "protected" in text:
                    return "protected"
                if "public" in text:
                    return "public"
        return "package"

    def _get_javadoc(self, node: Node, source: bytes) -> str | None:
        """Extract Javadoc comment preceding a node."""
        # Check for block_comment or line_comment siblings
        prev = node.prev_named_sibling
        if not prev:
            # Check non-named siblings
            idx = None
            parent = node.parent
            if parent:
                for i, child in enumerate(parent.children):
                    if child.id == node.id:
                        idx = i
                        break
                if idx and idx > 0:
                    prev_child = parent.children[idx - 1]
                    if prev_child.type in ("block_comment", "line_comment"):
                        text = self._get_text(prev_child, source)
                        return self._clean_javadoc(text)
        if prev and prev.type in ("block_comment", "line_comment"):
            text = self._get_text(prev, source)
            return self._clean_javadoc(text)
        return None

    def _clean_javadoc(self, text: str) -> str | None:
        text = text.strip()
        for prefix in ["/**", "/*", "*/", "*", "//"]:
            text = text.removeprefix(prefix).removesuffix(prefix)
        lines = []
        for line in text.splitlines():
            line = line.strip().lstrip("* ").strip()
            if line:
                lines.append(line)
        return " ".join(lines) if lines else None

    def _is_test_file(self, file_path: str) -> bool:
        return "src/test/" in file_path or "/test/" in file_path or "Test.java" in file_path
