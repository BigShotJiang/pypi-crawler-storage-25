from pathlib import Path

from pydantic import BaseModel
from pydantic_settings import BaseSettings


class ServerConfig(BaseModel):
    host: str = "127.0.0.1"
    port: int = 9742
    db_path: Path = Path.home() / ".grafio" / "graph.db"


class IndexingConfig(BaseModel):
    watch_enabled: bool = True
    watch_debounce_ms: int = 500
    ignored_dirs: list[str] = [
        ".git",
        "node_modules",
        "__pycache__",
        ".venv",
        "venv",
        "env",
        "target",
        "dist",
        "build",
        "out",
        ".next",
        ".nuxt",
        "vendor",
        "Pods",
        ".gradle",
        ".idea",
        ".vscode",
        ".mypy_cache",
        ".pytest_cache",
        ".tox",
        ".eggs",
        "coverage",
        ".nyc_output",
        ".cache",
        # Vendored/bundled dependency directories
        "lambda_build",
        "lambda_layer",
        "lambda_package",
        "site-packages",
        "lib",
        "libs",
        "third_party",
        "third-party",
        "bundled",
        ".serverless",
        ".aws-sam",
        "cdk.out",
    ]
    ignored_extensions: list[str] = [
        ".min.js",
        ".min.css",
        ".map",
        ".lock",
        ".pyc",
        ".pyo",
        ".class",
        ".o",
        ".so",
        ".dylib",
        ".wasm",
        ".png",
        ".jpg",
        ".gif",
        ".svg",
        ".ico",
        ".pdf",
        ".zip",
        ".tar",
        ".gz",
    ]
    ignored_files: list[str] = [
        "package-lock.json",
        "yarn.lock",
        "Cargo.lock",
    ]
    max_file_size_bytes: int = 1_000_000  # 1MB
    batch_size: int = 50


class ScoringWeights(BaseModel):
    graph_distance: float = 0.35
    embedding_similarity: float = 0.25
    git_recency: float = 0.20
    git_cochange: float = 0.10
    node_kind_boost: float = 0.10


class RetrievalConfig(BaseModel):
    default_max_nodes: int = 12
    default_max_token_budget: int = 6000
    default_depth: int = 2
    scoring_weights: ScoringWeights = ScoringWeights()


class LspServerConfig(BaseModel):
    language: str
    command: str
    args: list[str] = []


class LspConfig(BaseModel):
    enabled: bool = True
    timeout_ms: int = 10_000
    servers: list[LspServerConfig] = []


class EmbeddingConfig(BaseModel):
    enabled: bool = False
    provider: str = "openai"
    model: str = "text-embedding-3-small"
    api_key_env: str = "OPENAI_API_KEY"
    dimensions: int = 1536
    batch_size: int = 100


class GrafioConfig(BaseSettings):
    server: ServerConfig = ServerConfig()
    indexing: IndexingConfig = IndexingConfig()
    retrieval: RetrievalConfig = RetrievalConfig()
    lsp: LspConfig = LspConfig()
    embedding: EmbeddingConfig = EmbeddingConfig()

    model_config = {"env_prefix": "GRAFIO_", "env_nested_delimiter": "__"}


def load_config(config_path: Path | None = None) -> GrafioConfig:
    """Load config from TOML file with env var overrides."""
    default_path = Path.home() / ".grafio" / "config.toml"
    path = config_path or default_path

    if path.exists():
        import tomli

        with open(path, "rb") as f:
            data = tomli.load(f)
        return GrafioConfig(**data)
    return GrafioConfig()
