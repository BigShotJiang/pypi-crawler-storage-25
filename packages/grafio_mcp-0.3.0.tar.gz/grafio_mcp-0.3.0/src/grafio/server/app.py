from __future__ import annotations

import time
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from grafio.config import load_config
from grafio.db.connection import Database
from grafio.indexer.orchestrator import Indexer
from grafio.retriever.retriever import Retriever

from .request_cache import RequestCache
from .routes import context, feedback, graph, health, index


def create_app() -> FastAPI:
    """FastAPI application factory."""
    config = load_config()
    db = Database(config.server.db_path)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        await db.connect()
        # Load root_paths from DB so snippets work after daemon restart
        await _load_root_paths(app)
        yield
        await db.close()

    app = FastAPI(
        title="Grafio Code Intelligence",
        version="0.1.0",
        description="Code intelligence graph sidecar for AI coding assistants",
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Shared state
    app.state.config = config
    app.state.db = db
    app.state.indexer = Indexer(db=db, config=config.indexing)
    app.state.start_time = time.time()

    # Build root_paths from existing repos at startup (populated lazily via indexing)
    app.state.retriever = Retriever(db=db, config=config.retrieval, root_paths={})
    app.state.request_cache = RequestCache()

    # Register routes
    app.include_router(health.router, tags=["health"])
    app.include_router(index.router, prefix="/index", tags=["indexing"])
    app.include_router(context.router, prefix="/context", tags=["context"])
    app.include_router(graph.router, prefix="/graph", tags=["graph"])
    app.include_router(feedback.router, prefix="/feedback", tags=["feedback"])

    return app


async def _load_root_paths(app: FastAPI) -> None:
    """Populate retriever.root_paths from the repositories table on startup."""
    from pathlib import Path

    db = app.state.db
    repos = await db.fetchall("SELECT id, root_path FROM repositories")
    for repo in repos:
        root = Path(repo["root_path"])
        if root.exists():
            app.state.retriever.root_paths[repo["id"]] = root
