from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request

from grafio.db.edges import get_incoming_edges, get_outgoing_edges
from grafio.db.nodes import get_node_by_id, search_nodes
from grafio.server.schemas import (
    ContextNode,
    EdgeInfo,
    GitSignals,
    GraphSearchRequest,
    NodeDetailResponse,
)

router = APIRouter()


@router.post("/search")
async def graph_search(body: GraphSearchRequest, request: Request) -> list[dict]:
    """Search the code graph for nodes."""
    db = request.app.state.db
    return await search_nodes(
        db,
        body.repo_id,
        body.query,
        kinds=body.kinds,
        languages=body.languages,
        limit=body.limit,
    )


@router.get("/node/{node_id}", response_model=NodeDetailResponse)
async def get_node(node_id: int, request: Request) -> NodeDetailResponse:
    """Get full details for a node including edges."""
    db = request.app.state.db
    node = await get_node_by_id(db, node_id)
    if not node:
        raise HTTPException(status_code=404, detail="Node not found")

    incoming_raw = await get_incoming_edges(db, node_id)
    outgoing_raw = await get_outgoing_edges(db, node_id)

    incoming = [
        EdgeInfo(
            edge_id=e["id"],
            kind=e["kind"],
            confidence=e["confidence"],
            source=e["source"],
            other_node={
                "id": e["src_node_id"],
                "kind": e.get("src_kind", ""),
                "name": e.get("src_name", ""),
                "fq_name": e.get("src_fq_name", ""),
                "file_path": e.get("src_file_path", ""),
            },
        )
        for e in incoming_raw
    ]
    outgoing = [
        EdgeInfo(
            edge_id=e["id"],
            kind=e["kind"],
            confidence=e["confidence"],
            source=e["source"],
            other_node={
                "id": e["dst_node_id"],
                "kind": e.get("dst_kind", ""),
                "name": e.get("dst_name", ""),
                "fq_name": e.get("dst_fq_name", ""),
                "file_path": e.get("dst_file_path", ""),
            },
        )
        for e in outgoing_raw
    ]

    # Build code snippet from file
    code_snippet = ""
    try:
        from pathlib import Path

        repo = await db.fetchone(
            "SELECT root_path FROM repositories WHERE id = ?", (node["repo_id"],)
        )
        if repo:
            file_path = Path(repo["root_path"]) / node["file_path"]
            if file_path.exists():
                lines = file_path.read_text(errors="replace").splitlines()
                start = max(0, node["start_line"] - 1)
                end = min(len(lines), node["end_line"])
                code_snippet = "\n".join(lines[start:end])
    except Exception:  # noqa: BLE001
        pass

    return NodeDetailResponse(
        node=ContextNode(
            node_id=node["id"],
            kind=node["kind"],
            fq_name=node["fq_name"],
            name=node["name"],
            file_path=node["file_path"],
            start_line=node["start_line"],
            end_line=node["end_line"],
            language=node["language"],
            signature=node.get("signature"),
            relevance_score=1.0,
            git_signals=GitSignals(
                last_modified=node.get("last_modified_at"),
                modification_count=node.get("modification_count", 0),
                primary_author=node.get("primary_author"),
            ),
        ),
        incoming_edges=incoming,
        outgoing_edges=outgoing,
        code_snippet=code_snippet,
    )
