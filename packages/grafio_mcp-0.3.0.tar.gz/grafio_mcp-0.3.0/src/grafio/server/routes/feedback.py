from __future__ import annotations

import json

from fastapi import APIRouter, HTTPException, Request

from grafio.retriever.tuner import RetrievalTuner
from grafio.server.schemas import (
    FeedbackRequest,
    FeedbackSummaryResponse,
    TuneWeightsRequest,
    TuneWeightsResponse,
)

router = APIRouter()


@router.post("/submit")
async def submit_feedback(body: FeedbackRequest, request: Request) -> dict[str, str]:
    """Submit feedback for a context query result."""
    db = request.app.state.db
    cache = request.app.state.request_cache

    cached = cache.get(body.request_id)
    if not cached:
        raise HTTPException(
            404, "Request not found in cache. Feedback window may have expired."
        )

    await db.execute(
        """INSERT INTO feedback
           (repo_id, query_text, anchor_node_id, context_node_ids, tier, rating, response_time_ms)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (
            body.repo_id,
            cached.query_text,
            cached.anchor_node_id,
            json.dumps(cached.context_node_ids),
            cached.tier,
            body.rating,
            cached.response_time_ms,
        ),
    )
    await db.commit()
    return {"status": "accepted", "request_id": body.request_id}


@router.post("/tune", response_model=TuneWeightsResponse)
async def tune_weights(body: TuneWeightsRequest, request: Request) -> TuneWeightsResponse:
    """Analyze feedback and tune retrieval weights for a repo."""
    db = request.app.state.db
    tuner = RetrievalTuner(db)

    summary_data = await tuner.get_feedback_summary(body.repo_id)
    summary = FeedbackSummaryResponse(
        repo_id=str(summary_data["repo_id"]),
        total_feedback=int(summary_data["total_feedback"]),
        positive=int(summary_data["positive"]),
        negative=int(summary_data["negative"]),
    )
    weights = await tuner.analyze_feedback(body.repo_id, min_samples=body.min_samples)

    if weights is None:
        return TuneWeightsResponse(
            status="insufficient_data",
            weights=None,
            feedback_summary=summary,
        )

    await tuner.apply_weights(body.repo_id, weights)

    # Update the in-memory retriever weights
    retriever = request.app.state.retriever
    if retriever:
        retriever.config.scoring_weights = weights

    return TuneWeightsResponse(
        status="tuned",
        weights=weights.model_dump(),
        feedback_summary=summary,
    )


@router.get("/summary/{repo_id}", response_model=FeedbackSummaryResponse)
async def feedback_summary(repo_id: str, request: Request) -> FeedbackSummaryResponse:
    """Get feedback summary for a repo."""
    db = request.app.state.db
    tuner = RetrievalTuner(db)
    summary_data = await tuner.get_feedback_summary(repo_id)
    return FeedbackSummaryResponse(
        repo_id=str(summary_data["repo_id"]),
        total_feedback=int(summary_data["total_feedback"]),
        positive=int(summary_data["positive"]),
        negative=int(summary_data["negative"]),
    )
