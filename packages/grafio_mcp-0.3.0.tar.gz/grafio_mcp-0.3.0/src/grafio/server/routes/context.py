from __future__ import annotations

import hashlib
import logging
import time

from fastapi import APIRouter, HTTPException, Request

from grafio.server.request_cache import CachedRequest
from grafio.server.schemas import (
    ContextQueryRequest,
    ContextQueryResponse,
    ImpactAnalysisRequest,
    ImpactAnalysisResponse,
)

logger = logging.getLogger(__name__)
router = APIRouter()


async def _freshen_file(request: Request, repo_id: str, file_path: str) -> None:
    """Re-index a single file if it changed since last index.

    Compares the file's current content hash against the stored hash.
    If different, runs incremental indexing on that file before the query.
    This keeps the index fresh without a file watcher.
    """
    db = request.app.state.db
    retriever = request.app.state.retriever
    if not retriever:
        return
    root = retriever.root_paths.get(repo_id)
    if not root:
        return
    full_path = root / file_path
    if not full_path.exists():
        return

    # Check stored hash
    state = await db.fetchone(
        "SELECT content_hash FROM index_state WHERE repo_id = ? AND file_path = ?",
        (repo_id, file_path),
    )
    if not state:
        return  # File not indexed at all — don't block the query for a full index

    try:
        current_hash = hashlib.sha256(full_path.read_bytes()).hexdigest()
    except OSError:
        return

    if current_hash == state["content_hash"]:
        return  # File unchanged

    # File changed — run incremental re-index
    logger.info("Auto-freshening stale file: %s", file_path)
    indexer = request.app.state.indexer
    try:
        await indexer.index_files(
            repo_id, [full_path], [], root
        )
        await db.commit()
    except Exception:
        logger.exception("Auto-freshen failed for %s", file_path)


@router.post("/query", response_model=ContextQueryResponse)
async def query_context(
    request: Request, body: ContextQueryRequest
) -> ContextQueryResponse:
    """Query for context around a code location."""
    retriever = request.app.state.retriever
    if retriever is None:
        raise HTTPException(
            status_code=503, detail="Retriever not initialized"
        )

    # Auto-freshen the queried file if it changed on disk
    await _freshen_file(request, body.repo_id, body.file_path)

    try:
        response: ContextQueryResponse = await retriever.query(body)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e)) from None
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) from e

    # Cache the request for feedback linkage
    cache = request.app.state.request_cache
    cache.store(
        response.request_id,
        CachedRequest(
            query_text=body.query,
            anchor_node_id=response.anchor.node_id,
            context_node_ids=[n.node_id for n in response.nodes],
            tier=response.tier,
            response_time_ms=response.stats.query_time_ms,
            created_at=time.monotonic(),
        ),
    )

    return response


@router.post("/impact", response_model=ImpactAnalysisResponse)
async def impact_analyze(
    request: Request, body: ImpactAnalysisRequest
) -> ImpactAnalysisResponse:
    """Analyze the impact of changing a symbol."""
    retriever = request.app.state.retriever
    if retriever is None:
        raise HTTPException(
            status_code=503, detail="Retriever not initialized"
        )

    # Auto-freshen the queried file if provided
    if body.file_path:
        await _freshen_file(request, body.repo_id, body.file_path)

    try:
        result: ImpactAnalysisResponse = await retriever.impact_analysis(body)
        return result
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e)) from None
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) from e
