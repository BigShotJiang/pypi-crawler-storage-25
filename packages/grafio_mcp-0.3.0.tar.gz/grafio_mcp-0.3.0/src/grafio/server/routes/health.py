from __future__ import annotations

import time

from fastapi import APIRouter, Request

from grafio.server.schemas import HealthResponse, RepoInfo

router = APIRouter()


@router.get("/health", response_model=HealthResponse)
async def health_check(request: Request) -> HealthResponse:
    db = request.app.state.db
    start_time = request.app.state.start_time

    repos_raw = await db.fetchall(
        """SELECT r.id,
                  COALESCE((SELECT COUNT(*) FROM nodes WHERE repo_id = r.id), 0) as node_count,
                  COALESCE((SELECT COUNT(*) FROM edges WHERE repo_id = r.id), 0) as edge_count
           FROM repositories r"""
    )

    repos = [
        RepoInfo(id=r["id"], node_count=r["node_count"], edge_count=r["edge_count"])
        for r in repos_raw
    ]

    return HealthResponse(
        status="ok",
        version="0.1.0",
        uptime_seconds=round(time.time() - start_time, 2),
        repos=repos,
    )
