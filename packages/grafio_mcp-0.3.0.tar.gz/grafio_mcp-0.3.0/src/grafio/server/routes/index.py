from __future__ import annotations

import asyncio
import logging
import uuid
from pathlib import Path

from fastapi import APIRouter, Request

from grafio.server.schemas import (
    IndexStartRequest,
    IndexStartResponse,
    IndexStatsInfo,
    IndexStatusResponse,
    IndexUpdateRequest,
)

logger = logging.getLogger(__name__)

router = APIRouter()

# Track running index jobs
_running_jobs: dict[str, str] = {}  # job_id -> status


@router.post("/start", response_model=IndexStartResponse)
async def start_index(body: IndexStartRequest, request: Request) -> IndexStartResponse:
    """Start indexing a repository (runs in background)."""
    job_id = str(uuid.uuid4())
    indexer = request.app.state.indexer
    config = request.app.state.config
    root = Path(body.root_path).resolve()

    _running_jobs[job_id] = "indexing"

    async def _run_index() -> None:
        try:
            lang_list = body.languages
            stats = await indexer.index_repo(body.repo_id, root, lang_list, body.force)
            logger.info(
                "Index complete for %s: %d files, %d nodes, %d edges",
                body.repo_id,
                stats.files_processed,
                stats.nodes_created,
                stats.edges_created,
            )
            # Run enrichment
            _running_jobs[job_id] = "enriching"
            enrich_stats = await indexer.enrich_repo(body.repo_id, root, config)
            logger.info("Enrichment complete for %s: %s", body.repo_id, enrich_stats)
            # Register root path on retriever so context queries work
            if hasattr(request.app.state, "retriever") and request.app.state.retriever:
                request.app.state.retriever.root_paths[body.repo_id] = root
            _running_jobs[job_id] = "completed"
        except Exception:
            logger.exception("Indexing failed for %s", body.repo_id)
            _running_jobs[job_id] = "failed"

    asyncio.create_task(_run_index())
    return IndexStartResponse(job_id=job_id, status="started")


@router.post("/update")
async def update_index(body: IndexUpdateRequest, request: Request) -> dict:
    """Incremental index update for changed/deleted files."""
    indexer = request.app.state.indexer
    repo = await request.app.state.db.fetchone(
        "SELECT root_path FROM repositories WHERE id = ?", (body.repo_id,)
    )
    if not repo:
        from fastapi import HTTPException

        raise HTTPException(status_code=404, detail="Repository not found")

    root = Path(repo["root_path"])
    changed = [root / f for f in body.changed_files]
    deleted = [root / f for f in body.deleted_files]

    stats = await indexer.index_files(body.repo_id, changed, deleted, root)
    return {
        "files_processed": stats.files_processed,
        "nodes_created": stats.nodes_created,
        "edges_created": stats.edges_created,
    }


@router.get("/status/{repo_id}", response_model=IndexStatusResponse)
async def index_status(repo_id: str, request: Request) -> IndexStatusResponse:
    """Get indexing status for a repository."""
    db = request.app.state.db

    nodes = await db.fetchone(
        "SELECT COUNT(*) as cnt FROM nodes WHERE repo_id = ?", (repo_id,)
    )
    edges = await db.fetchone(
        "SELECT COUNT(*) as cnt FROM edges WHERE repo_id = ?", (repo_id,)
    )
    files = await db.fetchone(
        "SELECT COUNT(*) as cnt FROM index_state WHERE repo_id = ?", (repo_id,)
    )
    repo = await db.fetchone(
        "SELECT last_full_index_at, last_incremental_at FROM repositories WHERE id = ?",
        (repo_id,),
    )

    # Check if any jobs are running for this repo
    status = "idle"
    for _job_id, job_status in _running_jobs.items():
        if job_status in ("indexing", "enriching"):
            status = job_status
            break

    return IndexStatusResponse(
        repo_id=repo_id,
        status=status,
        progress=None,
        stats=IndexStatsInfo(
            node_count=nodes["cnt"] if nodes else 0,
            edge_count=edges["cnt"] if edges else 0,
            file_count=files["cnt"] if files else 0,
            last_full_index=repo["last_full_index_at"] if repo else None,
            last_incremental=repo["last_incremental_at"] if repo else None,
        ),
    )
