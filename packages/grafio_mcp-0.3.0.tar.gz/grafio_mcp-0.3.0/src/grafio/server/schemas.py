from pydantic import BaseModel

# --- Context Query ---


class SelectionRange(BaseModel):
    start_line: int
    end_line: int


class QueryOptions(BaseModel):
    max_nodes: int = 25
    max_token_budget: int = 8000
    include_snippets: bool = True
    include_summaries: bool = True
    depth: int = 2
    tier: str = "auto"
    detail: str = "code"  # "signatures" | "code"


class ContextQueryRequest(BaseModel):
    repo_id: str
    file_path: str
    selection: SelectionRange | None = None
    cursor_line: int | None = None
    query: str
    options: QueryOptions = QueryOptions()


class AnchorInfo(BaseModel):
    node_id: int
    kind: str
    fq_name: str
    file_path: str
    start_line: int
    end_line: int


class GitSignals(BaseModel):
    last_modified: str | None = None
    modification_count: int = 0
    primary_author: str | None = None


class ContextNode(BaseModel):
    node_id: int
    kind: str
    fq_name: str
    name: str
    file_path: str
    start_line: int
    end_line: int
    language: str
    signature: str | None = None
    summary: str | None = None
    code_snippet: str | None = None
    relevance_score: float
    git_signals: GitSignals = GitSignals()


class RelationshipPath(BaseModel):
    from_node: int
    to_node: int
    relations: list[str]
    confidence: str


class QueryStats(BaseModel):
    total_candidates: int
    nodes_returned: int
    estimated_tokens: int
    query_time_ms: int
    retrieval_method: str


class ContextQueryResponse(BaseModel):
    request_id: str
    tier: str
    anchor: AnchorInfo
    high_level_summary: str
    nodes: list[ContextNode]
    paths: list[RelationshipPath]
    stats: QueryStats


# --- Impact Analysis ---


class ImpactAnalysisRequest(BaseModel):
    repo_id: str
    node_id: int | None = None
    file_path: str | None = None
    line: int | None = None
    symbol: str | None = None
    depth: int = 3


class ImpactedNode(BaseModel):
    node_id: int
    kind: str
    fq_name: str
    file_path: str
    start_line: int
    end_line: int
    impact_type: str
    distance: int


class ImpactAnalysisResponse(BaseModel):
    target_node: AnchorInfo
    impacted_nodes: list[ImpactedNode]
    impact_paths: list[RelationshipPath]
    summary: str


# --- Indexing ---


class IndexStartRequest(BaseModel):
    repo_id: str
    root_path: str
    languages: list[str] | None = None
    force: bool = False


class IndexStartResponse(BaseModel):
    job_id: str
    status: str  # "started" | "already_running"


class IndexUpdateRequest(BaseModel):
    repo_id: str
    changed_files: list[str]
    deleted_files: list[str] = []


class IndexProgress(BaseModel):
    phase: str
    files_processed: int
    files_total: int
    percentage: float


class IndexStatsInfo(BaseModel):
    node_count: int
    edge_count: int
    file_count: int
    last_full_index: str | None = None
    last_incremental: str | None = None


class IndexStatusResponse(BaseModel):
    repo_id: str
    status: str  # "idle" | "indexing" | "enriching"
    progress: IndexProgress | None = None
    stats: IndexStatsInfo


# --- Graph Explorer ---


class EdgeInfo(BaseModel):
    edge_id: int
    kind: str
    confidence: str
    source: str
    other_node: dict


class NodeDetailResponse(BaseModel):
    node: ContextNode
    incoming_edges: list[EdgeInfo]
    outgoing_edges: list[EdgeInfo]
    code_snippet: str


class GraphSearchRequest(BaseModel):
    repo_id: str
    query: str
    kinds: list[str] | None = None
    languages: list[str] | None = None
    limit: int = 20


# --- Feedback ---


class FeedbackRequest(BaseModel):
    repo_id: str
    request_id: str
    rating: int  # 1 = bad, 2 = good


class FeedbackSummaryResponse(BaseModel):
    repo_id: str
    total_feedback: int
    positive: int
    negative: int


class TuneWeightsRequest(BaseModel):
    repo_id: str
    min_samples: int = 20


class TuneWeightsResponse(BaseModel):
    status: str  # "tuned" | "insufficient_data"
    weights: dict[str, float] | None = None
    feedback_summary: FeedbackSummaryResponse


# --- Health ---


class RepoInfo(BaseModel):
    id: str
    node_count: int
    edge_count: int


class HealthResponse(BaseModel):
    status: str
    version: str
    uptime_seconds: float
    repos: list[RepoInfo]
