"""In-memory cache of recent query results for feedback linkage."""

from __future__ import annotations

import time
from dataclasses import dataclass
from threading import Lock


@dataclass
class CachedRequest:
    query_text: str
    anchor_node_id: int
    context_node_ids: list[int]
    tier: str
    response_time_ms: int
    created_at: float


class RequestCache:
    """In-memory cache of recent query results for feedback linkage."""

    def __init__(self, max_age_seconds: int = 3600) -> None:
        self._cache: dict[str, CachedRequest] = {}
        self._lock = Lock()
        self._max_age = max_age_seconds

    def store(self, request_id: str, data: CachedRequest) -> None:
        with self._lock:
            self._cache[request_id] = data
            self._cleanup()

    def get(self, request_id: str) -> CachedRequest | None:
        with self._lock:
            return self._cache.get(request_id)

    def _cleanup(self) -> None:
        now = time.monotonic()
        expired = [
            k for k, v in self._cache.items() if now - v.created_at > self._max_age
        ]
        for k in expired:
            del self._cache[k]
