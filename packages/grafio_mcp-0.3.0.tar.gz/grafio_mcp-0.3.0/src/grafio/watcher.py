"""File system watcher for incremental re-indexing using watchdog."""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path

from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer

logger = logging.getLogger(__name__)


class _Handler(FileSystemEventHandler):
    """Forwards file events to an asyncio queue (thread-safe)."""

    def __init__(
        self,
        queue: asyncio.Queue[tuple[str, str]],
        loop: asyncio.AbstractEventLoop,
        ignored_dirs: set[str],
    ) -> None:
        self._queue = queue
        self._loop = loop
        self._ignored_dirs = ignored_dirs

    def _should_ignore(self, path: str) -> bool:
        return any(f"/{d}/" in path or path.endswith(f"/{d}") for d in self._ignored_dirs)

    def _enqueue(self, kind: str, path: str) -> None:
        self._loop.call_soon_threadsafe(self._queue.put_nowait, (kind, path))

    def on_modified(self, event: object) -> None:
        evt = event  # type: ignore[assignment]
        if not evt.is_directory and not self._should_ignore(evt.src_path):
            self._enqueue("modified", evt.src_path)

    def on_created(self, event: object) -> None:
        evt = event  # type: ignore[assignment]
        if not evt.is_directory and not self._should_ignore(evt.src_path):
            self._enqueue("created", evt.src_path)

    def on_deleted(self, event: object) -> None:
        evt = event  # type: ignore[assignment]
        if not evt.is_directory and not self._should_ignore(evt.src_path):
            self._enqueue("deleted", evt.src_path)


class FileWatcher:
    """Watches a directory for file changes and reports them with debouncing."""

    def __init__(
        self, root_path: Path, ignored_dirs: set[str], debounce_ms: int = 500
    ) -> None:
        self.root_path = root_path
        self._loop = asyncio.get_event_loop()
        self.queue: asyncio.Queue[tuple[str, str]] = asyncio.Queue()
        self._observer = Observer()
        handler = _Handler(self.queue, self._loop, ignored_dirs)
        self._observer.schedule(handler, str(root_path), recursive=True)
        self._debounce_s = debounce_ms / 1000

    def start(self) -> None:
        self._observer.start()
        logger.info("File watcher started for %s", self.root_path)

    def stop(self) -> None:
        self._observer.stop()
        self._observer.join()
        logger.info("File watcher stopped")

    async def get_changes(self) -> tuple[list[Path], list[Path]]:
        """Wait for changes, debounce, and return (changed, deleted) lists."""
        # Wait for first event
        kind, path = await self.queue.get()
        changed: set[Path] = set()
        deleted: set[Path] = set()

        if kind == "deleted":
            deleted.add(Path(path))
        else:
            changed.add(Path(path))

        # Debounce: collect more events for the debounce period
        try:
            while True:
                kind, path = await asyncio.wait_for(
                    self.queue.get(), timeout=self._debounce_s
                )
                p = Path(path)
                if kind == "deleted":
                    deleted.add(p)
                    changed.discard(p)
                else:
                    changed.add(p)
                    deleted.discard(p)
        except TimeoutError:
            pass

        return list(changed), list(deleted)
