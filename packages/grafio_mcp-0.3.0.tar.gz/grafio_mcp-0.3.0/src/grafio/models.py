from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum


class NodeKind(StrEnum):
    FILE = "file"
    MODULE = "module"
    CLASS = "class"
    INTERFACE = "interface"
    FUNCTION = "function"
    METHOD = "method"
    ENUM = "enum"
    STRUCT = "struct"
    TRAIT = "trait"
    TYPE_ALIAS = "type_alias"
    VARIABLE = "variable"
    CONSTANT = "constant"
    DECORATOR = "decorator"
    ROUTE = "route"
    TEST = "test"
    EXTERNAL = "external"


class EdgeKind(StrEnum):
    CALLS = "CALLS"
    IMPORTS = "IMPORTS"
    EXTENDS = "EXTENDS"
    IMPLEMENTS = "IMPLEMENTS"
    USES_TYPE = "USES_TYPE"
    OWNS = "OWNS"
    OVERRIDES = "OVERRIDES"
    DECORATES = "DECORATES"
    RETURNS_TYPE = "RETURNS_TYPE"
    PARAMETER_TYPE = "PARAMETER_TYPE"
    THROWS = "THROWS"
    HTTP_CALLS = "HTTP_CALLS"
    CO_CHANGES = "CO_CHANGES"
    TESTS = "TESTS"


class Confidence(StrEnum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class EdgeSource(StrEnum):
    TREESITTER = "treesitter"
    LSP = "lsp"
    GIT = "git"
    HEURISTIC = "heuristic"


class Language(StrEnum):
    TYPESCRIPT = "typescript"
    JAVASCRIPT = "javascript"
    PYTHON = "python"
    JAVA = "java"
    GO = "go"
    RUST = "rust"
    CSHARP = "c_sharp"
    PHP = "php"
    RUBY = "ruby"
    KOTLIN = "kotlin"
    C = "c"
    CPP = "cpp"

    @classmethod
    def from_extension(cls, ext: str) -> Language | None:
        mapping = {
            "ts": cls.TYPESCRIPT,
            "tsx": cls.TYPESCRIPT,
            "js": cls.JAVASCRIPT,
            "jsx": cls.JAVASCRIPT,
            "mjs": cls.JAVASCRIPT,
            "cjs": cls.JAVASCRIPT,
            "py": cls.PYTHON,
            "pyi": cls.PYTHON,
            "java": cls.JAVA,
            "go": cls.GO,
            "rs": cls.RUST,
            "cs": cls.CSHARP,
            "php": cls.PHP,
            "rb": cls.RUBY,
            "kt": cls.KOTLIN,
            "kts": cls.KOTLIN,
            "c": cls.C,
            "h": cls.C,
            "cpp": cls.CPP,
            "cc": cls.CPP,
            "cxx": cls.CPP,
            "hpp": cls.CPP,
            "hh": cls.CPP,
        }
        return mapping.get(ext)

    def tree_sitter_name(self) -> str:
        return self.value


class QueryTier(StrEnum):
    LOCAL = "local"
    NEIGHBORHOOD = "neighborhood"
    CROSS_CUTTING = "cross_cutting"


@dataclass
class ExtractedNode:
    kind: NodeKind
    name: str
    fq_name: str
    start_line: int
    end_line: int
    signature: str | None = None
    docstring: str | None = None
    visibility: str = "public"
    is_exported: bool = False
    is_test: bool = False
    metadata: dict = field(default_factory=dict)


@dataclass
class ExtractedEdge:
    src_fq_name: str
    dst_fq_name: str
    dst_name: str
    kind: EdgeKind
    confidence: Confidence = Confidence.MEDIUM
    source: EdgeSource = EdgeSource.TREESITTER


@dataclass
class ParsedFile:
    file_path: str
    language: Language
    nodes: list[ExtractedNode]
    edges: list[ExtractedEdge]


@dataclass
class IndexStats:
    files_processed: int = 0
    files_skipped: int = 0
    nodes_created: int = 0
    nodes_updated: int = 0
    nodes_deleted: int = 0
    edges_created: int = 0
    unresolved_references: int = 0
    duration_ms: int = 0
