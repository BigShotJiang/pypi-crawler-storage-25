from pathlib import Path

import typer

app = typer.Typer(name="grafio", help="Code intelligence graph builder")


@app.command()
def index(
    repo_id: str = typer.Option(..., help="Repository identifier"),
    root: Path = typer.Option(".", help="Path to repository root"),
    force: bool = typer.Option(False, help="Force full re-index"),
    languages: str | None = typer.Option(None, help="Comma-separated languages to index"),
):
    """Index a repository into the code graph."""
    import asyncio

    asyncio.run(_run_index(repo_id, root, force, languages))


async def _run_index(repo_id: str, root: Path, force: bool, languages: str | None):
    from .config import load_config
    from .db.connection import Database
    from .indexer.orchestrator import Indexer

    config = load_config()
    db = Database(config.server.db_path)
    await db.connect()
    try:
        indexer = Indexer(db=db, config=config.indexing)
        lang_list = languages.split(",") if languages else None
        stats = await indexer.index_repo(repo_id, root.resolve(), lang_list, force)
        typer.echo(
            f"Indexed {stats.files_processed} files: "
            f"{stats.nodes_created} nodes, {stats.edges_created} edges "
            f"({stats.unresolved_references} unresolved) "
            f"in {stats.duration_ms}ms"
        )
    finally:
        await db.close()


@app.command()
def enrich(
    repo_id: str = typer.Option(..., help="Repository identifier"),
    root: Path = typer.Option(".", help="Path to repository root"),
):
    """Run enrichment pipeline (git + LSP) on an already-indexed repo."""
    import asyncio

    asyncio.run(_run_enrich(repo_id, root))


async def _run_enrich(repo_id: str, root: Path):
    from .config import load_config
    from .db.connection import Database
    from .indexer.orchestrator import Indexer

    config = load_config()
    db = Database(config.server.db_path)
    await db.connect()
    try:
        indexer = Indexer(db=db, config=config.indexing)
        stats = await indexer.enrich_repo(repo_id, root.resolve(), config)
        typer.echo(f"Enrichment complete: {stats}")
    finally:
        await db.close()


@app.command()
def stats(repo_id: str = typer.Option(..., help="Repository identifier")):
    """Show index statistics."""
    import asyncio

    asyncio.run(_show_stats(repo_id))


async def _show_stats(repo_id: str):
    from .config import load_config
    from .db.connection import Database

    config = load_config()
    db = Database(config.server.db_path)
    await db.connect()
    try:
        nodes = await db.fetchone("SELECT COUNT(*) as cnt FROM nodes WHERE repo_id = ?", (repo_id,))
        edges = await db.fetchone("SELECT COUNT(*) as cnt FROM edges WHERE repo_id = ?", (repo_id,))
        files = await db.fetchone(
            "SELECT COUNT(*) as cnt FROM index_state WHERE repo_id = ?", (repo_id,)
        )
        unresolved = await db.fetchone(
            "SELECT COUNT(*) as cnt FROM unresolved_references WHERE repo_id = ?",
            (repo_id,),
        )

        # Edge breakdown by kind
        edge_kinds = await db.fetchall(
            "SELECT kind, COUNT(*) as cnt FROM edges WHERE repo_id = ? GROUP BY kind",
            (repo_id,),
        )
        # Edge breakdown by source
        edge_sources = await db.fetchall(
            "SELECT source, COUNT(*) as cnt FROM edges WHERE repo_id = ? GROUP BY source",
            (repo_id,),
        )

        typer.echo(f"Repo: {repo_id}")
        typer.echo(f"  Nodes: {nodes['cnt'] if nodes else 0}")
        typer.echo(f"  Edges: {edges['cnt'] if edges else 0}")
        typer.echo(f"  Files: {files['cnt'] if files else 0}")
        typer.echo(f"  Unresolved: {unresolved['cnt'] if unresolved else 0}")
        if edge_kinds:
            typer.echo("  Edges by kind:")
            for ek in edge_kinds:
                typer.echo(f"    {ek['kind']}: {ek['cnt']}")
        if edge_sources:
            typer.echo("  Edges by source:")
            for es in edge_sources:
                typer.echo(f"    {es['source']}: {es['cnt']}")
    finally:
        await db.close()


@app.command()
def serve(
    host: str = typer.Option("127.0.0.1", help="Bind host"),
    port: int = typer.Option(9742, help="Bind port"),
    no_watch: bool = typer.Option(False, help="Disable auto-watching indexed repos"),
):
    """Start the Grafio daemon server.

    By default, watches all indexed repos for file changes and auto-reindexes.
    Use --no-watch to disable.
    """
    import asyncio

    if no_watch:
        import uvicorn

        uvicorn.run(
            "grafio.server.app:create_app",
            host=host,
            port=port,
            factory=True,
            reload=False,
        )
    else:
        asyncio.run(_serve_with_watchers(host, port))


async def _serve_with_watchers(host: str, port: int):
    import asyncio

    import uvicorn

    from .config import load_config
    from .db.connection import Database
    from .indexer.orchestrator import Indexer
    from .watcher import FileWatcher

    config = load_config()
    db = Database(config.server.db_path)
    await db.connect()

    indexer = Indexer(db=db, config=config.indexing)
    ignored = set(config.indexing.ignored_dirs)
    debounce = config.indexing.watch_debounce_ms

    # Load all indexed repos from DB
    repos = await db.fetchall("SELECT id, root_path FROM repositories")
    watchers: list[FileWatcher] = []
    tasks: list[asyncio.Task] = []  # type: ignore[type-arg]

    for repo in repos:
        root = Path(repo["root_path"])
        if not root.exists():
            typer.echo(f"[watcher] Skipping {repo['id']} — path not found: {root}")
            continue
        repo_id = repo["id"]
        watcher = FileWatcher(root, ignored, debounce)
        watcher.start()
        watchers.append(watcher)

        async def _watch_loop(rid: str, w: FileWatcher, r: Path) -> None:
            while True:
                try:
                    changed, deleted = await w.get_changes()
                    if changed or deleted:
                        stats = await indexer.index_files(rid, changed, deleted, r)
                        typer.echo(
                            f"[watcher:{rid}] {stats.files_processed} files, "
                            f"{stats.nodes_created} nodes"
                        )
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    typer.echo(f"[watcher:{rid}] Error: {e}", err=True)

        tasks.append(asyncio.create_task(_watch_loop(repo_id, watcher, root)))
        typer.echo(f"[watcher] Watching {repo_id} at {root}")

    if not watchers:
        typer.echo("[watcher] No indexed repos found — watching disabled")

    uv_config = uvicorn.Config(
        "grafio.server.app:create_app",
        host=host,
        port=port,
        factory=True,
        reload=False,
    )
    server = uvicorn.Server(uv_config)

    try:
        await server.serve()
    finally:
        for t in tasks:
            t.cancel()
        for w in watchers:
            w.stop()
        await db.close()


if __name__ == "__main__":
    app()
