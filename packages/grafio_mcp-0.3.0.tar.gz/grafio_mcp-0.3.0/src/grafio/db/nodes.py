from __future__ import annotations

import hashlib
import json
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .connection import Database


async def upsert_node(
    db: Database,
    repo_id: str,
    kind: str,
    name: str,
    fq_name: str,
    file_path: str,
    start_line: int,
    end_line: int,
    language: str,
    signature: str | None = None,
    docstring: str | None = None,
    visibility: str = "public",
    is_exported: bool = False,
    is_test: bool = False,
    metadata: dict | None = None,
) -> int:
    """Insert or update a node, returning its id."""
    content = f"{kind}:{fq_name}:{start_line}:{end_line}:{signature or ''}"
    content_hash = hashlib.sha256(content.encode()).hexdigest()[:16]

    existing = await db.fetchone(
        "SELECT id, content_hash FROM nodes WHERE repo_id = ? AND fq_name = ? AND file_path = ?",
        (repo_id, fq_name, file_path),
    )

    if existing and existing["content_hash"] == content_hash:
        return existing["id"]

    if existing:
        await db.execute(
            """UPDATE nodes SET kind=?, name=?, start_line=?, end_line=?, language=?,
               signature=?, docstring=?, visibility=?, is_exported=?, is_test=?,
               content_hash=?, metadata=?, updated_at=datetime('now')
               WHERE id=?""",
            (
                kind,
                name,
                start_line,
                end_line,
                language,
                signature,
                docstring,
                visibility,
                int(is_exported),
                int(is_test),
                content_hash,
                json.dumps(metadata or {}),
                existing["id"],
            ),
        )
        return existing["id"]

    cursor = await db.execute(
        """INSERT INTO nodes (repo_id, kind, name, fq_name, file_path, start_line, end_line,
           language, signature, docstring, visibility, is_exported, is_test, content_hash, metadata)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            repo_id,
            kind,
            name,
            fq_name,
            file_path,
            start_line,
            end_line,
            language,
            signature,
            docstring,
            visibility,
            int(is_exported),
            int(is_test),
            content_hash,
            json.dumps(metadata or {}),
        ),
    )
    return cursor.lastrowid  # type: ignore[return-value]


async def delete_nodes_for_file(db: Database, repo_id: str, file_path: str) -> int:
    """Delete all nodes for a file. Returns count deleted."""
    result = await db.fetchone(
        "SELECT COUNT(*) as cnt FROM nodes WHERE repo_id = ? AND file_path = ?",
        (repo_id, file_path),
    )
    await db.execute(
        "DELETE FROM nodes WHERE repo_id = ? AND file_path = ?",
        (repo_id, file_path),
    )
    return result["cnt"] if result else 0


async def get_node_by_id(db: Database, node_id: int) -> dict | None:
    return await db.fetchone("SELECT * FROM nodes WHERE id = ?", (node_id,))


async def get_node_by_fqname(db: Database, repo_id: str, fq_name: str) -> dict | None:
    return await db.fetchone(
        "SELECT * FROM nodes WHERE repo_id = ? AND fq_name = ?",
        (repo_id, fq_name),
    )


async def search_nodes(
    db: Database,
    repo_id: str,
    query: str,
    kinds: list[str] | None = None,
    languages: list[str] | None = None,
    limit: int = 20,
) -> list[dict]:
    """Search nodes by name or fq_name pattern.

    - Excludes external nodes (no useful content)
    - Excludes test nodes by default (unless query mentions "test")
    - Splits multi-word queries so each word is matched independently
    - Filters common stop-words to reduce noise
    - Ranks results: name match > fq_name match > file_path match
    """
    words = query.split()

    # Filter out common stop-words that pollute search results
    stop_words = {
        "a", "an", "the", "of", "in", "for", "and", "or", "is", "to",
        "api", "endpoint", "get", "show", "find", "how", "what", "does",
        "me", "all", "this", "that", "with",
    }
    filtered = [w for w in words if w.lower() not in stop_words]
    if not filtered:
        filtered = words  # fall back to original if all filtered out

    include_tests = any(w.lower() == "test" for w in words)

    if len(filtered) <= 1:
        term = filtered[0]
        sql = (
            "SELECT * FROM nodes WHERE repo_id = ? "
            "AND kind != 'external' "
            "AND (name LIKE ? COLLATE NOCASE "
            "OR fq_name LIKE ? COLLATE NOCASE "
            "OR file_path LIKE ? COLLATE NOCASE "
            "OR metadata LIKE ? COLLATE NOCASE)"
        )
        pattern = f"%{term}%"
        params: list = [repo_id, pattern, pattern, pattern, pattern]
    else:
        word_clauses = []
        params = [repo_id]
        for w in filtered:
            pattern = f"%{w}%"
            word_clauses.append(
                "(name LIKE ? COLLATE NOCASE "
                "OR fq_name LIKE ? COLLATE NOCASE "
                "OR file_path LIKE ? COLLATE NOCASE "
                "OR metadata LIKE ? COLLATE NOCASE)"
            )
            params.extend([pattern, pattern, pattern, pattern])
        sql = (
            "SELECT * FROM nodes WHERE repo_id = ? "
            "AND kind != 'external' AND "
            + " AND ".join(word_clauses)
        )

    # Exclude test nodes unless query explicitly mentions tests
    if not include_tests:
        sql += " AND is_test = 0"

    if kinds:
        placeholders = ",".join("?" * len(kinds))
        sql += f" AND kind IN ({placeholders})"
        params.extend(kinds)

    if languages:
        placeholders = ",".join("?" * len(languages))
        sql += f" AND language IN ({placeholders})"
        params.extend(languages)

    # Rank: name match first, then fq_name, then file_path only
    first_term = filtered[0]
    sql += (
        " ORDER BY "
        "CASE WHEN name LIKE ? COLLATE NOCASE THEN 0 ELSE 1 END, "
        "kind, name"
    )
    params.append(f"%{first_term}%")

    sql += " LIMIT ?"
    params.append(limit)

    return await db.fetchall(sql, tuple(params))
