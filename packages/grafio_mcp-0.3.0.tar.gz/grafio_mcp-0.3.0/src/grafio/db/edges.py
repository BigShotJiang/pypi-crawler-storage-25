from __future__ import annotations

import json
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .connection import Database


async def upsert_edge(
    db: Database,
    repo_id: str,
    src_node_id: int,
    dst_node_id: int,
    kind: str,
    confidence: str = "high",
    source: str = "treesitter",
    weight: float = 1.0,
    metadata: dict | None = None,
) -> int:
    """Insert or update an edge, returning its id."""
    existing = await db.fetchone(
        "SELECT id FROM edges WHERE repo_id = ? "
        "AND src_node_id = ? AND dst_node_id = ? AND kind = ?",
        (repo_id, src_node_id, dst_node_id, kind),
    )

    if existing:
        await db.execute(
            """UPDATE edges SET confidence=?, source=?, weight=?, metadata=?
               WHERE id=?""",
            (confidence, source, weight, json.dumps(metadata or {}), existing["id"]),
        )
        return existing["id"]

    meta_json = json.dumps(metadata or {})
    cursor = await db.execute(
        """INSERT INTO edges
           (repo_id, src_node_id, dst_node_id, kind,
            confidence, source, weight, metadata)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (repo_id, src_node_id, dst_node_id, kind, confidence, source, weight, meta_json),
    )
    return cursor.lastrowid  # type: ignore[return-value]


async def delete_edges_for_node(db: Database, node_id: int) -> None:
    """Delete all edges where the given node is src or dst."""
    await db.execute(
        "DELETE FROM edges WHERE src_node_id = ? OR dst_node_id = ?",
        (node_id, node_id),
    )


async def get_outgoing_edges(db: Database, node_id: int) -> list[dict]:
    return await db.fetchall(
        """SELECT e.*, n.kind as dst_kind, n.name as dst_name, n.fq_name as dst_fq_name,
                  n.file_path as dst_file_path, n.start_line as dst_start_line
           FROM edges e JOIN nodes n ON e.dst_node_id = n.id
           WHERE e.src_node_id = ?""",
        (node_id,),
    )


async def get_incoming_edges(db: Database, node_id: int) -> list[dict]:
    return await db.fetchall(
        """SELECT e.*, n.kind as src_kind, n.name as src_name, n.fq_name as src_fq_name,
                  n.file_path as src_file_path, n.start_line as src_start_line
           FROM edges e JOIN nodes n ON e.src_node_id = n.id
           WHERE e.dst_node_id = ?""",
        (node_id,),
    )
