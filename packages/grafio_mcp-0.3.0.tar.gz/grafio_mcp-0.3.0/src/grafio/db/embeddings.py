from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .connection import Database


async def upsert_embedding(
    db: Database,
    node_id: int,
    repo_id: str,
    vector: bytes,
    model_name: str,
    dimensions: int,
) -> None:
    """Insert or update an embedding for a node."""
    await db.execute(
        """INSERT INTO embeddings (node_id, repo_id, vector, model_name, dimensions)
           VALUES (?, ?, ?, ?, ?)
           ON CONFLICT(node_id) DO UPDATE SET
               vector=excluded.vector, model_name=excluded.model_name,
               dimensions=excluded.dimensions, created_at=datetime('now')""",
        (node_id, repo_id, vector, model_name, dimensions),
    )


async def get_embedding(db: Database, node_id: int) -> dict | None:
    return await db.fetchone("SELECT * FROM embeddings WHERE node_id = ?", (node_id,))


async def get_all_embeddings(db: Database, repo_id: str) -> list[dict]:
    return await db.fetchall("SELECT * FROM embeddings WHERE repo_id = ?", (repo_id,))


async def delete_embedding(db: Database, node_id: int) -> None:
    await db.execute("DELETE FROM embeddings WHERE node_id = ?", (node_id,))
