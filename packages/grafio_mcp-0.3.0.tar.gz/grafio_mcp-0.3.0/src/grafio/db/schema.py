import aiosqlite

SCHEMA_SQL = """
-- Core graph tables
CREATE TABLE IF NOT EXISTS repositories (
    id TEXT PRIMARY KEY,
    root_path TEXT NOT NULL,
    default_branch TEXT DEFAULT 'main',
    last_full_index_at TEXT,
    last_incremental_at TEXT,
    config JSON DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS nodes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    repo_id TEXT NOT NULL,
    kind TEXT NOT NULL,
    name TEXT NOT NULL,
    fq_name TEXT NOT NULL,
    file_path TEXT NOT NULL,
    start_line INTEGER NOT NULL,
    end_line INTEGER NOT NULL,
    language TEXT NOT NULL,
    signature TEXT,
    docstring TEXT,
    summary TEXT,
    visibility TEXT DEFAULT 'public',
    is_exported INTEGER DEFAULT 0,
    is_test INTEGER DEFAULT 0,
    content_hash TEXT NOT NULL,
    metadata JSON DEFAULT '{}',
    last_modified_at TEXT,
    modification_count INTEGER DEFAULT 0,
    primary_author TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (repo_id) REFERENCES repositories(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS edges (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    repo_id TEXT NOT NULL,
    src_node_id INTEGER NOT NULL,
    dst_node_id INTEGER NOT NULL,
    kind TEXT NOT NULL,
    confidence TEXT NOT NULL DEFAULT 'high',
    source TEXT NOT NULL DEFAULT 'treesitter',
    weight REAL DEFAULT 1.0,
    metadata JSON DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (repo_id) REFERENCES repositories(id) ON DELETE CASCADE,
    FOREIGN KEY (src_node_id) REFERENCES nodes(id) ON DELETE CASCADE,
    FOREIGN KEY (dst_node_id) REFERENCES nodes(id) ON DELETE CASCADE,
    UNIQUE(repo_id, src_node_id, dst_node_id, kind)
);

CREATE TABLE IF NOT EXISTS embeddings (
    node_id INTEGER PRIMARY KEY,
    repo_id TEXT NOT NULL,
    vector BLOB NOT NULL,
    model_name TEXT NOT NULL,
    dimensions INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (node_id) REFERENCES nodes(id) ON DELETE CASCADE,
    FOREIGN KEY (repo_id) REFERENCES repositories(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    repo_id TEXT NOT NULL,
    query_text TEXT NOT NULL,
    anchor_node_id INTEGER,
    context_node_ids JSON NOT NULL,
    tier TEXT NOT NULL,
    rating INTEGER NOT NULL,
    response_time_ms INTEGER,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (repo_id) REFERENCES repositories(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS index_state (
    file_path TEXT NOT NULL,
    repo_id TEXT NOT NULL,
    content_hash TEXT NOT NULL,
    last_indexed_at TEXT NOT NULL,
    node_count INTEGER DEFAULT 0,
    PRIMARY KEY (repo_id, file_path),
    FOREIGN KEY (repo_id) REFERENCES repositories(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS unresolved_references (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    repo_id TEXT NOT NULL,
    src_node_id INTEGER NOT NULL,
    dst_name TEXT NOT NULL,
    dst_fq_name TEXT,
    edge_kind TEXT NOT NULL,
    file_path TEXT NOT NULL,
    line_number INTEGER,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (repo_id) REFERENCES repositories(id) ON DELETE CASCADE,
    FOREIGN KEY (src_node_id) REFERENCES nodes(id) ON DELETE CASCADE
);

-- Performance indexes
CREATE INDEX IF NOT EXISTS idx_nodes_repo_kind ON nodes(repo_id, kind);
CREATE INDEX IF NOT EXISTS idx_nodes_repo_file ON nodes(repo_id, file_path);
CREATE INDEX IF NOT EXISTS idx_nodes_repo_fqname ON nodes(repo_id, fq_name);
CREATE INDEX IF NOT EXISTS idx_nodes_repo_language ON nodes(repo_id, language);
CREATE INDEX IF NOT EXISTS idx_edges_repo_src ON edges(repo_id, src_node_id);
CREATE INDEX IF NOT EXISTS idx_edges_repo_dst ON edges(repo_id, dst_node_id);
CREATE INDEX IF NOT EXISTS idx_edges_repo_kind ON edges(repo_id, kind);
CREATE INDEX IF NOT EXISTS idx_edges_repo_src_kind ON edges(repo_id, src_node_id, kind);
CREATE INDEX IF NOT EXISTS idx_index_state_hash ON index_state(repo_id, content_hash);
"""


async def init_database(db_path: str) -> aiosqlite.Connection:
    """Initialize database with schema. Idempotent."""
    db = await aiosqlite.connect(db_path)
    await db.execute("PRAGMA journal_mode=WAL")
    await db.execute("PRAGMA foreign_keys=ON")
    await db.executescript(SCHEMA_SQL)
    await db.commit()
    return db
