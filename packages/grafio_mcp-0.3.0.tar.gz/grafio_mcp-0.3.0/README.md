# Grafio

Structural code knowledge graph for AI coding assistants.

Grafio indexes your codebase into a symbol-level graph and exposes it via MCP (Model Context Protocol) so AI assistants like Claude can understand cross-service flows, find callers, and analyze impact — without reading every file.

## Install

```bash
pip install grafio              # the daemon
npm install -g grafio-mcp       # the MCP bridge for Claude Code
```

## Quick start

```bash
# Start the daemon (auto-starts when Claude Code opens if grafio is on PATH)
grafio serve

# Index a repo
grafio index --repo-id my-project --root /path/to/my-project
```

Configure Claude Code — create `~/.claude/.mcp.json`:

```json
{
  "mcpServers": {
    "grafio": {
      "command": "grafio-mcp",
      "env": {
        "GRAFIO_URL": "http://127.0.0.1:9742"
      }
    }
  }
}
```

Restart Claude Code. Run `/mcp` to verify.

## What it does

- **`code_graph_context`** — understand a method + everything it calls across files
- **`code_graph_impact`** — find what breaks if you change a symbol
- **`code_graph_search`** — find symbols by name or REST endpoint path
- **`code_graph_update`** — incrementally reindex changed files

Claude automatically decides when to use Grafio vs Grep+Read based on the question.

## Supported languages

Java, TypeScript, JavaScript, Python, Go, Rust

## License

MIT
