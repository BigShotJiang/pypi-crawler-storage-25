"""
LangChain integration for Konstruct - Typed Knowledge Graph for AI Agents

This module provides LangChain-compatible retriever classes that use Konstruct's
knowledge graph engine with 19 typed relations, symmetry-based inference, and
token-budgeted advisory generation.

Usage:
    from langchain_konstruct import KonstructRetriever
    from langchain.chains import RetrievalQA
    from langchain_anthropic import ChatAnthropic

    retriever = KonstructRetriever(
        mcp_url="https://konstruct.aerware.ai/mcp",
        max_concepts=10,
        max_depth=2
    )

    # Load a knowledge pack
    retriever.load_pack_from_file("packs/yc-fundamentals.json")

    qa_chain = RetrievalQA.from_chain_type(
        llm=ChatAnthropic(model="claude-sonnet-4-20250514"),
        chain_type="stuff",
        retriever=retriever
    )

    response = qa_chain.invoke({"query": "What are common startup mistakes?"})

© 2026 AerwareAI - Proprietary
"""

from typing import List, Dict, Any, Optional
import json
import requests
from datetime import datetime

from langchain_core.retrievers import BaseRetriever
from langchain_core.documents import Document
from langchain_core.callbacks import CallbackManagerForRetrieverRun
from pydantic import BaseModel, Field


class KonstructRetriever(BaseRetriever, BaseModel):
    """
    LangChain retriever backed by Konstruct knowledge graph engine.

    This class provides a LangChain-compatible interface to Konstruct, which stores
    typed relationships between concepts and reasons about them via graph traversal.

    Features:
    - 19 typed relations (is_a, causes, requires, conflicts_with, etc.)
    - Symmetry-based edge inference (automatic reverse edges)
    - Causal & structural reasoning (deterministic, no LLM needed)
    - Token-budgeted advisory (300 tokens default, 3-section structure)
    - Framework triggering (questions, red flags, green lights)
    - Zero LLM dependency (pure graph traversal)

    Args:
        mcp_url: Konstruct MCP endpoint URL (default: hosted service)
        api_key: Optional API key for authenticated access (bypasses rate limits)
        max_concepts: Maximum concepts to return per query (default: 10)
        max_depth: Edge traversal depth (1 or 2, default: 2)
        max_advisory_tokens: Token budget for advisory generation (default: 300)
        category_filter: Optional category filter for concepts
        stage_filter: Optional stage filter for frameworks (design, implementation, testing, etc.)
        search_type: "advisory" (structured guidance) or "concepts" (raw concepts)
    """

    mcp_url: str = Field(
        default="https://konstruct.aerware.ai/mcp",
        description="Konstruct MCP endpoint URL"
    )
    api_key: Optional[str] = Field(default=None, description="API key for authenticated access")
    max_concepts: int = Field(default=10, description="Max concepts to return")
    max_depth: int = Field(default=2, description="Edge traversal depth (1-2)")
    max_advisory_tokens: int = Field(default=300, description="Token budget for advisory")
    category_filter: Optional[str] = Field(default=None, description="Filter by category")
    stage_filter: Optional[str] = Field(default=None, description="Filter by stage")
    search_type: str = Field(default="advisory", description="Return type: 'advisory' or 'concepts'")

    # Internal state
    _session: Optional[requests.Session] = None

    class Config:
        arbitrary_types_allowed = True

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._session = requests.Session()
        if self.api_key:
            self._session.headers.update({"Authorization": f"Bearer {self.api_key}"})
        self._session.headers.update({"Content-Type": "application/json"})

    def _call_mcp_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Any:
        """Call a Konstruct MCP tool via JSON-RPC 2.0."""
        payload = {
            "jsonrpc": "2.0",
            "id": int(datetime.now().timestamp() * 1000),
            "method": "tools/call",
            "params": {
                "name": tool_name,
                "arguments": arguments
            }
        }

        response = self._session.post(self.mcp_url, json=payload, timeout=10)
        response.raise_for_status()

        result = response.json()
        if "error" in result:
            raise RuntimeError(f"Konstruct MCP error: {result['error']}")

        return result.get("result", {})

    def _get_relevant_documents(
        self,
        query: str,
        *,
        run_manager: Optional[CallbackManagerForRetrieverRun] = None
    ) -> List[Document]:
        """
        Retrieve relevant documents from Konstruct knowledge graph.

        Args:
            query: Natural language context for knowledge retrieval
            run_manager: Callback manager (unused)

        Returns:
            List of Document objects with concept/advisory content
        """
        if self.search_type == "advisory":
            return self._get_advisory_documents(query)
        else:
            return self._get_concept_documents(query)

    def _get_advisory_documents(self, query: str) -> List[Document]:
        """
        Get structured advisory guidance as documents.

        Returns a single Document containing token-budgeted advisory with:
        - Key concepts (0-50% budget)
        - Key relationships (50-75% budget)
        - Framework guidance (75-100% budget)
        """
        try:
            result = self._call_mcp_tool("konstruct_advisory", {
                "context": query,
                "stage": self.stage_filter
            })

            advisory_text = result.get("advisory", "")

            if not advisory_text:
                return []

            # Return as single document
            return [Document(
                page_content=advisory_text,
                metadata={
                    "source": "konstruct_advisory",
                    "query": query,
                    "stage": self.stage_filter,
                    "token_budget": self.max_advisory_tokens
                }
            )]

        except Exception as e:
            print(f"[Konstruct] Warning: Failed to get advisory: {e}")
            return []

    def _get_concept_documents(self, query: str) -> List[Document]:
        """
        Get raw concepts and relationships as documents.

        Returns one Document per concept with metadata including edges and frameworks.
        """
        try:
            result = self._call_mcp_tool("konstruct_query", {
                "context": query,
                "max_concepts": self.max_concepts,
                "category": self.category_filter,
                "stage": self.stage_filter
            })

            concepts = result.get("concepts", [])
            edges = result.get("edges", [])
            frameworks = result.get("frameworks", [])

            if not concepts:
                return []

            # Convert concepts to documents
            documents = []

            for concept in concepts:
                # Format concept as document content
                content_lines = []
                content_lines.append(f"# {concept.get('name', 'Unknown')}")
                content_lines.append(f"**Category:** {concept.get('category', 'N/A')}")
                content_lines.append(f"**Importance:** {concept.get('importance', 0):.2f}")

                if concept.get('description'):
                    content_lines.append(f"\n{concept['description']}")

                if concept.get('tags'):
                    content_lines.append(f"\n**Tags:** {', '.join(concept['tags'])}")

                # Add related edges
                concept_edges = [
                    e for e in edges
                    if e.get('source') == concept.get('id') or e.get('target') == concept.get('id')
                ]

                if concept_edges:
                    content_lines.append("\n## Relationships")
                    for edge in concept_edges[:5]:  # Limit to top 5
                        relation = edge.get('relation', 'unknown')
                        if edge.get('source') == concept.get('id'):
                            content_lines.append(f"- **{relation}** → {edge.get('target', 'unknown')}")
                        else:
                            content_lines.append(f"- {edge.get('source', 'unknown')} → **{relation}**")

                # Add triggered frameworks
                concept_frameworks = [
                    f for f in frameworks
                    if concept.get('id') in f.get('trigger_concepts', []) or
                       concept.get('name') in f.get('trigger_concepts', [])
                ]

                if concept_frameworks:
                    content_lines.append("\n## Relevant Frameworks")
                    for fw in concept_frameworks[:2]:  # Limit to top 2
                        content_lines.append(f"\n### {fw.get('name', 'Unknown')}")
                        if fw.get('questions'):
                            content_lines.append("**Questions to consider:**")
                            for q in fw['questions'][:3]:
                                content_lines.append(f"- {q}")
                        if fw.get('red_flags'):
                            content_lines.append("**Red flags:**")
                            for rf in fw['red_flags'][:3]:
                                content_lines.append(f"- ⚠️ {rf}")
                        if fw.get('green_lights'):
                            content_lines.append("**Green lights:**")
                            for gl in fw['green_lights'][:3]:
                                content_lines.append(f"- ✅ {gl}")

                documents.append(Document(
                    page_content="\n".join(content_lines),
                    metadata={
                        "source": "konstruct_concept",
                        "concept_id": concept.get('id'),
                        "concept_name": concept.get('name'),
                        "category": concept.get('category'),
                        "importance": concept.get('importance'),
                        "edge_count": len(concept_edges),
                        "framework_count": len(concept_frameworks)
                    }
                ))

            return documents

        except Exception as e:
            print(f"[Konstruct] Warning: Failed to get concepts: {e}")
            return []

    def load_pack_from_file(self, pack_path: str) -> Dict[str, Any]:
        """
        Load a knowledge pack from JSON file.

        Args:
            pack_path: Path to knowledge pack JSON file

        Returns:
            LoadResult with counts of concepts, edges, inferred edges, frameworks
        """
        with open(pack_path, 'r') as f:
            pack_json = json.load(f)

        return self.load_pack(pack_json)

    def load_pack(self, pack_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Load a knowledge pack from dict.

        Args:
            pack_data: Knowledge pack as dict (id, name, concepts, edges, frameworks)

        Returns:
            LoadResult with counts of concepts, edges, inferred edges, frameworks
        """
        try:
            result = self._call_mcp_tool("konstruct_load_pack", {
                "pack_json": json.dumps(pack_data)
            })

            print(f"[Konstruct] Loaded pack '{pack_data.get('name', 'Unknown')}':")
            print(f"  - {result.get('concepts', 0)} concepts")
            print(f"  - {result.get('edges', 0)} edges ({result.get('inferred_edges', 0)} inferred)")
            print(f"  - {result.get('frameworks', 0)} frameworks")

            return result

        except Exception as e:
            print(f"[Konstruct] Warning: Failed to load pack: {e}")
            return {}

    def explore_concept(self, concept_id: str, depth: int = 2) -> List[Document]:
        """
        Explore relationships outward from a specific concept.

        Args:
            concept_id: ID of concept to explore from
            depth: Traversal depth (1 or 2)

        Returns:
            List of documents with connected concepts and edges
        """
        try:
            result = self._call_mcp_tool("konstruct_explore", {
                "concept_id": concept_id,
                "depth": depth
            })

            connections = result.get("connections", [])

            if not connections:
                return []

            # Format as document
            content_lines = [f"# Exploration from: {concept_id}\n"]

            for edge, concept in connections:
                relation = edge.get('relation', 'unknown')
                weight = edge.get('weight', 0)
                content_lines.append(
                    f"- **{relation}** (weight: {weight:.2f}) → {concept.get('name', 'Unknown')}"
                )
                if concept.get('description'):
                    content_lines.append(f"  {concept['description'][:100]}...")

            return [Document(
                page_content="\n".join(content_lines),
                metadata={
                    "source": "konstruct_explore",
                    "origin_concept": concept_id,
                    "depth": depth,
                    "connection_count": len(connections)
                }
            )]

        except Exception as e:
            print(f"[Konstruct] Warning: Failed to explore concept: {e}")
            return []

    def get_all_concepts(self, category: Optional[str] = None) -> List[Document]:
        """
        List all loaded concepts, optionally filtered by category.

        Args:
            category: Optional category filter

        Returns:
            List of documents with concept summaries
        """
        try:
            result = self._call_mcp_tool("konstruct_concepts", {
                "category": category
            })

            concepts = result.get("concepts", [])

            if not concepts:
                return []

            # Format as single document
            content_lines = ["# All Concepts\n"]
            for concept in concepts:
                content_lines.append(
                    f"- **{concept.get('name', 'Unknown')}** "
                    f"({concept.get('category', 'N/A')}, "
                    f"importance: {concept.get('importance', 0):.2f})"
                )

            return [Document(
                page_content="\n".join(content_lines),
                metadata={
                    "source": "konstruct_concepts",
                    "category": category,
                    "count": len(concepts)
                }
            )]

        except Exception as e:
            print(f"[Konstruct] Warning: Failed to get concepts: {e}")
            return []

    def get_stats(self) -> Dict[str, Any]:
        """Get knowledge graph statistics."""
        try:
            return self._call_mcp_tool("konstruct_stats", {})
        except Exception as e:
            print(f"[Konstruct] Warning: Failed to get stats: {e}")
            return {}


class KonstructCausalRetriever(KonstructRetriever):
    """
    Specialized retriever for causal reasoning queries.

    This retriever filters for causal and structural relations (causes, prevents,
    requires, enables, conflicts_with) to support "if X then Y" reasoning.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # Override search type to focus on concepts with causal edges
        self.search_type = "concepts"

    def _get_relevant_documents(
        self,
        query: str,
        *,
        run_manager: Optional[CallbackManagerForRetrieverRun] = None
    ) -> List[Document]:
        """Retrieve documents with emphasis on causal relationships."""
        # Get base documents
        documents = super()._get_relevant_documents(query, run_manager=run_manager)

        # Filter/rerank based on causal relation presence
        causal_relations = {"causes", "prevents", "requires", "enables", "conflicts_with", "amplifies", "diminishes"}

        for doc in documents:
            # Count causal edges in metadata
            if "edge_count" in doc.metadata:
                # This is a heuristic - in production, you'd actually parse the content
                # to count causal vs. non-causal edges
                causal_score = doc.metadata.get("edge_count", 0) * 0.5  # Rough estimate
                doc.metadata["causal_score"] = causal_score

        # Sort by causal score if available
        documents.sort(key=lambda d: d.metadata.get("causal_score", 0), reverse=True)

        return documents


# Export public API
__all__ = [
    "KonstructRetriever",
    "KonstructCausalRetriever",
]
