"""Tests for mihari.handlers."""

from __future__ import annotations

import logging
from unittest.mock import MagicMock, patch

import pytest

from mihari.handlers import MihariHandler, _to_mihari_level
from mihari.types import LogLevel


@pytest.fixture
def mock_transport():
    """Patch Transport so no real HTTP calls are made."""
    with patch("mihari.handlers.Transport") as mock_cls:
        instance = MagicMock()
        mock_cls.return_value = instance
        yield instance


class TestLevelMapping:
    """Verify stdlib level to Mihari level conversion."""

    @pytest.mark.parametrize(
        ("stdlib_level", "expected"),
        [
            (logging.DEBUG, LogLevel.DEBUG),
            (logging.INFO, LogLevel.INFO),
            (logging.WARNING, LogLevel.WARN),
            (logging.ERROR, LogLevel.ERROR),
            (logging.CRITICAL, LogLevel.FATAL),
        ],
    )
    def test_standard_levels(self, stdlib_level, expected):
        assert _to_mihari_level(stdlib_level) == expected

    def test_custom_high_level_maps_to_fatal(self):
        assert _to_mihari_level(60) == LogLevel.FATAL

    def test_custom_low_level_maps_to_debug(self):
        assert _to_mihari_level(5) == LogLevel.DEBUG


class TestMihariHandler:
    """Tests for the logging.Handler integration."""

    def test_emit_sends_to_transport(self, mock_transport):
        handler = MihariHandler(token="tok", endpoint="https://api.example.com")
        logger = logging.getLogger("test.emit")
        logger.addHandler(handler)
        logger.setLevel(logging.DEBUG)

        logger.info("hello from logging")

        mock_transport.send.assert_called_once()
        entry = mock_transport.send.call_args[0][0]
        assert entry["level"] == "info"
        assert entry["message"] == "hello from logging"
        assert entry["logger_name"] == "test.emit"

        logger.removeHandler(handler)

    def test_warning_maps_to_warn(self, mock_transport):
        handler = MihariHandler(token="tok", endpoint="https://api.example.com")
        logger = logging.getLogger("test.warn")
        logger.addHandler(handler)
        logger.setLevel(logging.DEBUG)

        logger.warning("disk usage high")

        entry = mock_transport.send.call_args[0][0]
        assert entry["level"] == "warn"

        logger.removeHandler(handler)

    def test_critical_maps_to_fatal(self, mock_transport):
        handler = MihariHandler(token="tok", endpoint="https://api.example.com")
        logger = logging.getLogger("test.fatal")
        logger.addHandler(handler)
        logger.setLevel(logging.DEBUG)

        logger.critical("system down")

        entry = mock_transport.send.call_args[0][0]
        assert entry["level"] == "fatal"

        logger.removeHandler(handler)

    def test_extra_fields_forwarded(self, mock_transport):
        handler = MihariHandler(token="tok", endpoint="https://api.example.com")
        logger = logging.getLogger("test.extra")
        logger.addHandler(handler)
        logger.setLevel(logging.DEBUG)

        logger.info("request", extra={"method": "POST", "path": "/api/v1"})

        entry = mock_transport.send.call_args[0][0]
        assert entry["method"] == "POST"
        assert entry["path"] == "/api/v1"

        logger.removeHandler(handler)

    def test_system_context_included(self, mock_transport):
        handler = MihariHandler(token="tok", endpoint="https://api.example.com")
        logger = logging.getLogger("test.ctx")
        logger.addHandler(handler)
        logger.setLevel(logging.DEBUG)

        logger.info("ctx check")

        entry = mock_transport.send.call_args[0][0]
        assert "hostname" in entry
        assert "pid" in entry

        logger.removeHandler(handler)

    def test_default_meta_included(self, mock_transport):
        handler = MihariHandler(
            token="tok",
            endpoint="https://api.example.com",
            default_meta={"service": "api"},
        )
        logger = logging.getLogger("test.meta")
        logger.addHandler(handler)
        logger.setLevel(logging.DEBUG)

        logger.info("meta check")

        entry = mock_transport.send.call_args[0][0]
        assert entry["service"] == "api"

        logger.removeHandler(handler)

    def test_close_flushes_transport(self, mock_transport):
        handler = MihariHandler(token="tok", endpoint="https://api.example.com")
        handler.close()
        mock_transport.close.assert_called_once()

    def test_handler_level_filtering(self, mock_transport):
        handler = MihariHandler(
            token="tok",
            endpoint="https://api.example.com",
            level=logging.WARNING,
        )
        logger = logging.getLogger("test.filter")
        logger.addHandler(handler)
        logger.setLevel(logging.DEBUG)

        logger.debug("should be filtered")
        logger.info("also filtered")
        logger.warning("should pass")

        assert mock_transport.send.call_count == 1
        entry = mock_transport.send.call_args[0][0]
        assert entry["level"] == "warn"

        logger.removeHandler(handler)

    def test_emit_handles_exception_gracefully(self, mock_transport):
        """If transport.send raises, handleError is called instead of crashing."""
        mock_transport.send.side_effect = RuntimeError("boom")
        handler = MihariHandler(token="tok", endpoint="https://api.example.com")
        logger = logging.getLogger("test.err")
        logger.addHandler(handler)
        logger.setLevel(logging.DEBUG)

        # Should not raise
        logger.info("this will fail internally")

        logger.removeHandler(handler)
