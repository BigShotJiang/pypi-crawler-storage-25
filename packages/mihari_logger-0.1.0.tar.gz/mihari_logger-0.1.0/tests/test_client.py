"""Tests for mihari.client."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from mihari.client import Mihari
from mihari.types import LogLevel


@pytest.fixture
def mock_transport():
    """Patch Transport so no real HTTP calls are made."""
    with patch("mihari.client.Transport") as mock_cls:
        instance = MagicMock()
        mock_cls.return_value = instance
        yield instance


class TestMihariClient:
    """Tests for the Mihari high-level client."""

    def test_info_sends_entry_with_correct_level(self, mock_transport):
        client = Mihari(token="tok", endpoint="https://api.example.com")
        client.info("hello world")

        mock_transport.send.assert_called_once()
        entry = mock_transport.send.call_args[0][0]
        assert entry["level"] == "info"
        assert entry["message"] == "hello world"
        assert "dt" in entry

    def test_warn_sends_warn_level(self, mock_transport):
        client = Mihari(token="tok", endpoint="https://api.example.com")
        client.warn("disk almost full")

        entry = mock_transport.send.call_args[0][0]
        assert entry["level"] == "warn"

    def test_error_sends_error_level(self, mock_transport):
        client = Mihari(token="tok", endpoint="https://api.example.com")
        client.error("connection refused")

        entry = mock_transport.send.call_args[0][0]
        assert entry["level"] == "error"

    def test_debug_sends_debug_level(self, mock_transport):
        client = Mihari(token="tok", endpoint="https://api.example.com")
        client.debug("tracing request")

        entry = mock_transport.send.call_args[0][0]
        assert entry["level"] == "debug"

    def test_fatal_sends_fatal_level(self, mock_transport):
        client = Mihari(token="tok", endpoint="https://api.example.com")
        client.fatal("out of memory")

        entry = mock_transport.send.call_args[0][0]
        assert entry["level"] == "fatal"

    def test_extra_kwargs_included_in_entry(self, mock_transport):
        client = Mihari(token="tok", endpoint="https://api.example.com")
        client.info("request handled", method="GET", status=200)

        entry = mock_transport.send.call_args[0][0]
        assert entry["method"] == "GET"
        assert entry["status"] == 200

    def test_system_context_auto_captured(self, mock_transport):
        client = Mihari(token="tok", endpoint="https://api.example.com")
        client.info("boot")

        entry = mock_transport.send.call_args[0][0]
        assert "hostname" in entry
        assert "pid" in entry
        assert "python_version" in entry
        assert "platform" in entry

    def test_default_meta_merged(self, mock_transport):
        client = Mihari(
            token="tok",
            endpoint="https://api.example.com",
            default_meta={"service": "web", "env": "prod"},
        )
        client.info("ping")

        entry = mock_transport.send.call_args[0][0]
        assert entry["service"] == "web"
        assert entry["env"] == "prod"

    def test_close_calls_transport_close(self, mock_transport):
        client = Mihari(token="tok", endpoint="https://api.example.com")
        client.close()
        mock_transport.close.assert_called_once()

    def test_close_is_idempotent(self, mock_transport):
        client = Mihari(token="tok", endpoint="https://api.example.com")
        client.close()
        client.close()
        # Only one call despite two close() invocations
        mock_transport.close.assert_called_once()

    def test_dt_is_iso8601(self, mock_transport):
        client = Mihari(token="tok", endpoint="https://api.example.com")
        client.info("check")

        entry = mock_transport.send.call_args[0][0]
        dt = entry["dt"]
        # Basic format check: 2024-01-01T00:00:00.000000Z
        assert dt.endswith("Z")
        assert "T" in dt
