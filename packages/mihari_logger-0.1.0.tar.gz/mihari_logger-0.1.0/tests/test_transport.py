"""Tests for mihari.transport."""

from __future__ import annotations

import gzip
import json
import threading
import time
from unittest.mock import MagicMock, patch

import httpx
import pytest

from mihari.transport import Transport


@pytest.fixture
def mock_client():
    """Patch httpx.Client to prevent real HTTP calls."""
    with patch("mihari.transport.httpx.Client") as mock_cls:
        instance = MagicMock()
        mock_cls.return_value = instance
        yield instance


def _make_transport(mock_client, **overrides):
    """Create a Transport with sensible test defaults."""
    config = {
        "batch_size": 3,
        "flush_interval": 60.0,  # long interval so periodic flush doesn't interfere
        "max_retries": 2,
        "base_delay": 0.01,
        "max_delay": 0.05,
        "gzip": False,
        "timeout": 5.0,
        **overrides,
    }
    return Transport(token="test-token", endpoint="https://api.example.com", config=config)


class TestTransportBatching:
    """Verify that entries are batched and flushed correctly."""

    def test_flush_sends_buffered_entries(self, mock_client):
        mock_client.post.return_value = httpx.Response(
            202, json={"status": "accepted", "count": 2}
        )
        t = _make_transport(mock_client, batch_size=10)

        t.send({"dt": "t1", "level": "info", "message": "a"})
        t.send({"dt": "t2", "level": "info", "message": "b"})
        assert mock_client.post.call_count == 0

        t.flush()
        assert mock_client.post.call_count == 1

        _, kwargs = mock_client.post.call_args
        body = json.loads(kwargs["content"])
        assert len(body) == 2
        t.close()

    def test_auto_flush_on_batch_size(self, mock_client):
        mock_client.post.return_value = httpx.Response(
            202, json={"status": "accepted", "count": 3}
        )
        t = _make_transport(mock_client, batch_size=3)

        t.send({"dt": "t1", "level": "info", "message": "a"})
        t.send({"dt": "t2", "level": "info", "message": "b"})
        assert mock_client.post.call_count == 0

        t.send({"dt": "t3", "level": "info", "message": "c"})
        assert mock_client.post.call_count == 1
        t.close()

    def test_flush_is_noop_when_empty(self, mock_client):
        t = _make_transport(mock_client)
        t.flush()
        mock_client.post.assert_not_called()
        t.close()


class TestTransportGzip:
    """Verify gzip compression."""

    def test_gzip_compression(self, mock_client):
        mock_client.post.return_value = httpx.Response(
            202, json={"status": "accepted", "count": 1}
        )
        t = _make_transport(mock_client, gzip=True, batch_size=1)

        t.send({"dt": "t1", "level": "info", "message": "compressed"})

        _, kwargs = mock_client.post.call_args
        assert kwargs["headers"]["Content-Encoding"] == "gzip"

        decompressed = gzip.decompress(kwargs["content"])
        body = json.loads(decompressed)
        assert body[0]["message"] == "compressed"
        t.close()

    def test_no_gzip_when_disabled(self, mock_client):
        mock_client.post.return_value = httpx.Response(
            202, json={"status": "accepted", "count": 1}
        )
        t = _make_transport(mock_client, gzip=False, batch_size=1)

        t.send({"dt": "t1", "level": "info", "message": "plain"})

        _, kwargs = mock_client.post.call_args
        assert "Content-Encoding" not in kwargs["headers"]
        t.close()


class TestTransportAuth:
    """Verify authorization header."""

    def test_bearer_token_in_header(self, mock_client):
        mock_client.post.return_value = httpx.Response(
            202, json={"status": "accepted", "count": 1}
        )
        t = _make_transport(mock_client, batch_size=1)

        t.send({"dt": "t1", "level": "info", "message": "auth"})

        _, kwargs = mock_client.post.call_args
        assert kwargs["headers"]["Authorization"] == "Bearer test-token"
        t.close()


class TestTransportRetry:
    """Verify retry with exponential backoff."""

    def test_retries_on_server_error(self, mock_client):
        mock_client.post.side_effect = [
            httpx.Response(500, text="Internal Server Error"),
            httpx.Response(202, json={"status": "accepted", "count": 1}),
        ]
        t = _make_transport(mock_client, batch_size=1)

        t.send({"dt": "t1", "level": "info", "message": "retry"})

        assert mock_client.post.call_count == 2
        t.close()

    def test_retries_on_transport_error(self, mock_client):
        mock_client.post.side_effect = [
            httpx.TransportError("connection reset"),
            httpx.Response(202, json={"status": "accepted", "count": 1}),
        ]
        t = _make_transport(mock_client, batch_size=1)

        t.send({"dt": "t1", "level": "info", "message": "retry"})

        assert mock_client.post.call_count == 2
        t.close()

    def test_no_retry_on_401(self, mock_client):
        mock_client.post.return_value = httpx.Response(
            401, json={"error": "Invalid or missing authentication token"}
        )
        t = _make_transport(mock_client, batch_size=1)

        t.send({"dt": "t1", "level": "info", "message": "bad auth"})

        assert mock_client.post.call_count == 1
        t.close()

    def test_gives_up_after_max_retries(self, mock_client):
        mock_client.post.return_value = httpx.Response(500, text="fail")
        t = _make_transport(mock_client, batch_size=1, max_retries=3)

        t.send({"dt": "t1", "level": "info", "message": "doomed"})

        assert mock_client.post.call_count == 3
        t.close()


class TestTransportEndpoint:
    """Verify correct endpoint URL construction."""

    def test_posts_to_logs_endpoint(self, mock_client):
        mock_client.post.return_value = httpx.Response(
            202, json={"status": "accepted", "count": 1}
        )
        t = _make_transport(mock_client, batch_size=1)

        t.send({"dt": "t1", "level": "info", "message": "url"})

        url = mock_client.post.call_args[0][0]
        assert url == "https://api.example.com/logs"
        t.close()

    def test_strips_trailing_slash(self, mock_client):
        mock_client.post.return_value = httpx.Response(
            202, json={"status": "accepted", "count": 1}
        )
        t = Transport(
            token="tok",
            endpoint="https://api.example.com/",
            config={"batch_size": 1, "flush_interval": 60.0, "gzip": False},
        )
        t.send({"dt": "t1", "level": "info", "message": "slash"})

        url = mock_client.post.call_args[0][0]
        assert url == "https://api.example.com/logs"
        t.close()


class TestTransportClose:
    """Verify graceful shutdown."""

    def test_close_flushes_remaining(self, mock_client):
        mock_client.post.return_value = httpx.Response(
            202, json={"status": "accepted", "count": 1}
        )
        t = _make_transport(mock_client, batch_size=100)

        t.send({"dt": "t1", "level": "info", "message": "leftover"})
        assert mock_client.post.call_count == 0

        t.close()
        assert mock_client.post.call_count == 1

    def test_send_after_close_raises(self, mock_client):
        t = _make_transport(mock_client)
        t.close()

        with pytest.raises(RuntimeError, match="closed"):
            t.send({"dt": "t1", "level": "info", "message": "nope"})


class TestTransportThreadSafety:
    """Basic thread-safety smoke tests."""

    def test_concurrent_sends(self, mock_client):
        mock_client.post.return_value = httpx.Response(
            202, json={"status": "accepted", "count": 1}
        )
        t = _make_transport(mock_client, batch_size=5)

        errors: list[Exception] = []

        def sender(n):
            try:
                for i in range(10):
                    t.send({"dt": f"t{n}-{i}", "level": "info", "message": f"msg-{n}-{i}"})
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=sender, args=(i,)) for i in range(4)]
        for th in threads:
            th.start()
        for th in threads:
            th.join()

        t.close()
        assert len(errors) == 0
        # All 40 entries should have been sent (via flush calls)
        total_sent = sum(
            len(json.loads(call.kwargs["content"]))
            for call in mock_client.post.call_args_list
        )
        assert total_sent == 40
