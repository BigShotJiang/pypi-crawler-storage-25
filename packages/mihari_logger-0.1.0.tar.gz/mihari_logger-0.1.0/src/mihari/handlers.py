"""Python ``logging.Handler`` integration for Mihari."""

from __future__ import annotations

import logging
from typing import Any

from mihari.transport import Transport
from mihari.types import LogLevel, TransportConfig, build_log_entry
from mihari.utils import iso_now, system_context

# Map stdlib log levels to Mihari levels.
_LEVEL_MAP: dict[int, LogLevel] = {
    logging.DEBUG: LogLevel.DEBUG,
    logging.INFO: LogLevel.INFO,
    logging.WARNING: LogLevel.WARN,
    logging.ERROR: LogLevel.ERROR,
    logging.CRITICAL: LogLevel.FATAL,
}


def _to_mihari_level(levelno: int) -> LogLevel:
    """Convert a stdlib numeric log level to a :class:`LogLevel`."""
    if levelno >= logging.CRITICAL:
        return LogLevel.FATAL
    if levelno >= logging.ERROR:
        return LogLevel.ERROR
    if levelno >= logging.WARNING:
        return LogLevel.WARN
    if levelno >= logging.INFO:
        return LogLevel.INFO
    return LogLevel.DEBUG


class MihariHandler(logging.Handler):
    """A :class:`logging.Handler` that forwards records to the Mihari API.

    Usage::

        import logging
        from mihari import MihariHandler

        handler = MihariHandler(
            token="my-token",
            endpoint="https://logs.example.com",
        )
        logging.basicConfig(handlers=[handler], level=logging.INFO)

        logger = logging.getLogger("myapp")
        logger.info("Application started", extra={"version": "1.2.0"})
    """

    def __init__(
        self,
        token: str,
        endpoint: str,
        *,
        level: int = logging.NOTSET,
        transport_config: TransportConfig | None = None,
        default_meta: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(level=level)
        self._transport = Transport(
            token=token,
            endpoint=endpoint,
            config=transport_config,
        )
        self._system_ctx = system_context()
        self._default_meta = default_meta or {}

    def emit(self, record: logging.LogRecord) -> None:
        """Format and ship a log record to Mihari."""
        try:
            mihari_level = _to_mihari_level(record.levelno)
            message = self.format(record)

            extra: dict[str, Any] = {
                **self._system_ctx,
                **self._default_meta,
                "logger_name": record.name,
            }

            # Pull user-supplied extra fields from the record. The stdlib
            # logger stores them directly on the LogRecord object.
            standard_attrs = logging.LogRecord(
                "", 0, "", 0, "", (), None
            ).__dict__.keys()
            for key, value in record.__dict__.items():
                if key not in standard_attrs and key != "message":
                    extra[key] = value

            entry = build_log_entry(
                level=mihari_level,
                message=message,
                timestamp=iso_now(),
                extra=extra,
            )
            self._transport.send(entry)
        except Exception:
            self.handleError(record)

    def close(self) -> None:
        """Flush buffered entries and release resources."""
        try:
            self._transport.close()
        finally:
            super().close()
