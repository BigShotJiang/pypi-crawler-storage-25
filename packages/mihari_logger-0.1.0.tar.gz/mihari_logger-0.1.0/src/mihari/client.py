"""Main Mihari client for log collection and transport."""

from __future__ import annotations

import atexit
from typing import Any

from mihari.transport import Transport
from mihari.types import LogLevel, TransportConfig, build_log_entry
from mihari.utils import iso_now, system_context


class Mihari:
    """High-level client for sending structured logs to the Mihari API.

    Usage::

        client = Mihari(token="my-token", endpoint="https://logs.example.com")
        client.info("Server started", port=8080)
        client.error("Connection failed", host="db.local", retries=3)
        client.close()  # or rely on atexit

    Auto-captured metadata (hostname, pid, python_version, platform) is
    attached to every log entry.
    """

    def __init__(
        self,
        token: str,
        endpoint: str,
        *,
        transport_config: TransportConfig | None = None,
        default_meta: dict[str, Any] | None = None,
    ) -> None:
        self._transport = Transport(
            token=token,
            endpoint=endpoint,
            config=transport_config,
        )
        self._system_ctx = system_context()
        self._default_meta = default_meta or {}
        self._closed = False

        atexit.register(self.close)

    # ------------------------------------------------------------------
    # Convenience log methods
    # ------------------------------------------------------------------

    def debug(self, message: str, **extra: Any) -> None:
        """Send a DEBUG-level log entry."""
        self._log(LogLevel.DEBUG, message, extra)

    def info(self, message: str, **extra: Any) -> None:
        """Send an INFO-level log entry."""
        self._log(LogLevel.INFO, message, extra)

    def warn(self, message: str, **extra: Any) -> None:
        """Send a WARN-level log entry."""
        self._log(LogLevel.WARN, message, extra)

    def error(self, message: str, **extra: Any) -> None:
        """Send an ERROR-level log entry."""
        self._log(LogLevel.ERROR, message, extra)

    def fatal(self, message: str, **extra: Any) -> None:
        """Send a FATAL-level log entry."""
        self._log(LogLevel.FATAL, message, extra)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self) -> None:
        """Flush remaining logs and release resources.

        Safe to call multiple times.
        """
        if self._closed:
            return
        self._closed = True
        self._transport.close()

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _log(self, level: LogLevel, message: str, extra: dict[str, Any]) -> None:
        merged_extra = {**self._system_ctx, **self._default_meta, **extra}
        entry = build_log_entry(
            level=level,
            message=message,
            timestamp=iso_now(),
            extra=merged_extra,
        )
        self._transport.send(entry)
