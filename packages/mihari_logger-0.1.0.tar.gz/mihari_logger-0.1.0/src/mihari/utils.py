"""Utility helpers for the Mihari log collection library."""

from __future__ import annotations

import os
import platform
import sys
from datetime import datetime, timezone


def iso_now() -> str:
    """Return the current UTC time as an ISO 8601 string with 'Z' suffix."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def system_context() -> dict[str, str]:
    """Gather auto-captured system metadata.

    Returns a dict with hostname, pid, python_version, and platform info.
    """
    return {
        "hostname": platform.node(),
        "pid": str(os.getpid()),
        "python_version": platform.python_version(),
        "platform": sys.platform,
        "arch": platform.machine(),
    }
