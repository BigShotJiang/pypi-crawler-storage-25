"""HTTP transport with batching, retry, and gzip compression."""

from __future__ import annotations

import gzip
import json
import logging
import threading
import time
from typing import Any

import httpx

from mihari.types import DEFAULT_TRANSPORT_CONFIG, TransportConfig

logger = logging.getLogger("mihari.transport")


class Transport:
    """Batched, thread-safe HTTP transport for shipping log entries.

    Collects log entries in an internal buffer and flushes them to the
    configured endpoint in batches.  A background thread performs
    periodic flushes so logs are delivered even when the batch-size
    threshold is not reached.

    All public methods are thread-safe.
    """

    def __init__(
        self,
        token: str,
        endpoint: str,
        config: TransportConfig | None = None,
    ) -> None:
        merged: TransportConfig = {**DEFAULT_TRANSPORT_CONFIG, **(config or {})}

        self._token = token
        self._endpoint = endpoint.rstrip("/")
        self._batch_size: int = merged.get("batch_size", 10)
        self._flush_interval: float = merged.get("flush_interval", 5.0)
        self._max_retries: int = merged.get("max_retries", 3)
        self._base_delay: float = merged.get("base_delay", 1.0)
        self._max_delay: float = merged.get("max_delay", 30.0)
        self._gzip: bool = merged.get("gzip", True)
        self._timeout: float = merged.get("timeout", 10.0)

        self._buffer: list[dict[str, Any]] = []
        self._lock = threading.Lock()
        self._closed = False

        self._client = httpx.Client(timeout=self._timeout)

        self._flush_thread = threading.Thread(
            target=self._periodic_flush,
            daemon=True,
            name="mihari-flush",
        )
        self._stop_event = threading.Event()
        self._flush_thread.start()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def send(self, entry: dict[str, Any]) -> None:
        """Add a log entry to the buffer.  Triggers a flush when the
        buffer reaches *batch_size*."""
        with self._lock:
            if self._closed:
                raise RuntimeError("Transport is closed; cannot send new entries")
            self._buffer.append(entry)
            should_flush = len(self._buffer) >= self._batch_size

        if should_flush:
            self.flush()

    def flush(self) -> None:
        """Flush all buffered entries to the remote endpoint."""
        with self._lock:
            if not self._buffer:
                return
            batch = list(self._buffer)
            self._buffer.clear()

        self._deliver(batch)

    def close(self) -> None:
        """Flush remaining entries and shut down the transport."""
        self._stop_event.set()
        self._flush_thread.join(timeout=self._flush_interval + 2)

        with self._lock:
            self._closed = True

        self.flush()
        self._client.close()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _periodic_flush(self) -> None:
        """Background loop that flushes the buffer at *flush_interval*."""
        while not self._stop_event.is_set():
            self._stop_event.wait(self._flush_interval)
            if not self._stop_event.is_set():
                try:
                    self.flush()
                except Exception:
                    logger.exception("Periodic flush failed")

    def _deliver(self, batch: list[dict[str, Any]]) -> None:
        """POST a batch of log entries with retry and optional gzip."""
        url = f"{self._endpoint}/logs"
        payload = json.dumps(batch).encode("utf-8")

        headers: dict[str, str] = {
            "Authorization": f"Bearer {self._token}",
            "Content-Type": "application/json",
        }

        if self._gzip:
            payload = gzip.compress(payload)
            headers["Content-Encoding"] = "gzip"

        delay = self._base_delay
        last_exc: Exception | None = None

        for attempt in range(1, self._max_retries + 1):
            try:
                response = self._client.post(url, content=payload, headers=headers)

                if response.status_code == 202:
                    logger.debug(
                        "Delivered %d entries (attempt %d)", len(batch), attempt
                    )
                    return

                if response.status_code == 401:
                    logger.error("Authentication failed: %s", response.text)
                    return

                # Retriable server error
                if response.status_code >= 500:
                    logger.warning(
                        "Server error %d on attempt %d/%d",
                        response.status_code,
                        attempt,
                        self._max_retries,
                    )
                else:
                    logger.error(
                        "Unexpected status %d: %s",
                        response.status_code,
                        response.text,
                    )
                    return

            except (httpx.TransportError, httpx.TimeoutException) as exc:
                last_exc = exc
                logger.warning(
                    "Transport error on attempt %d/%d: %s",
                    attempt,
                    self._max_retries,
                    exc,
                )

            if attempt < self._max_retries:
                time.sleep(delay)
                delay = min(delay * 2, self._max_delay)

        logger.error(
            "Failed to deliver %d entries after %d attempts (last error: %s)",
            len(batch),
            self._max_retries,
            last_exc,
        )
