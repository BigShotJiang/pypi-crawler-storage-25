"""Type definitions for the Mihari log collection library."""

from __future__ import annotations

from enum import Enum
from typing import Any, TypedDict


class LogLevel(str, Enum):
    """Log severity levels supported by Mihari."""

    DEBUG = "debug"
    INFO = "info"
    WARN = "warn"
    ERROR = "error"
    FATAL = "fatal"


class LogEntry(TypedDict, total=False):
    """A single log entry to be sent to the Mihari API.

    Required keys: dt, level, message.
    Additional metadata keys are allowed via extra fields.
    """

    dt: str
    level: str
    message: str


class IngestResponse(TypedDict):
    """Successful ingestion response from the API."""

    status: str
    count: int


class ErrorResponse(TypedDict):
    """Error response from the API."""

    error: str


class TransportConfig(TypedDict, total=False):
    """Configuration for the HTTP transport layer."""

    batch_size: int
    flush_interval: float
    max_retries: int
    base_delay: float
    max_delay: float
    gzip: bool
    timeout: float


DEFAULT_TRANSPORT_CONFIG: TransportConfig = {
    "batch_size": 10,
    "flush_interval": 5.0,
    "max_retries": 3,
    "base_delay": 1.0,
    "max_delay": 30.0,
    "gzip": True,
    "timeout": 10.0,
}


def build_log_entry(
    level: LogLevel,
    message: str,
    timestamp: str,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build a log entry dict with the required fields and optional extras.

    Returns a plain dict (not a TypedDict) so that arbitrary extra keys
    can be included alongside the required dt/level/message fields.
    """
    entry: dict[str, Any] = {
        "dt": timestamp,
        "level": level.value,
        "message": message,
    }
    if extra:
        entry.update(extra)
    return entry
