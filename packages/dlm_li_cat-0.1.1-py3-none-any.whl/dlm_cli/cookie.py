"""
Cookie 管理模块

提供 Cookie 测试、展示、缓存更新等完整功能。
严格遵循 script/family_search.py 和 utils/auto_search.py 中的现有逻辑。
"""

import time
import json
import random
from typing import List, Optional

import typer
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
from rich.panel import Panel
from rich import box

console = Console()


def get_cookie_status(cookie_obj, linkedin_class, timeout: int = 10) -> dict:
    """
    测试单个 cookie 有效性。
    遵循 linkedin_valid() 和 connect_linkedin() 中的逻辑。
    """
    result = {
        "id": cookie_obj.id,
        "user_id": cookie_obj.user_id,
        "linkedin_name": cookie_obj.linkedin.name,
        "username": cookie_obj.user.username,
        "status": "待测试",
        "error": None,
    }

    try:
        LK = linkedin_class()
        LK.connect(
            li_at=cookie_obj.LI_AT,
            jessionid=cookie_obj.JSESSIONID,
            name=cookie_obj.linkedin.name,
        )

        # 使用 Network.test_account() 验证账号状态
        test_result = LK.network.test_account()

        if test_result == 200:
            result["status"] = "有效"
        else:
            result["status"] = "无效"
            result["error"] = f"接口返回状态码: {test_result}"
    except Exception as e:
        result["status"] = "无效"
        result["error"] = str(e)

    return result


def show_cookies(
    project_dir: Optional[str] = None,
    show_invalid: bool = True,
    output_format: str = "table",
) -> None:
    """
    显示当前系统中所有 cookie 的状态。

    从数据库读取所有 Cookie 记录，并显示其详细信息。
    """
    from .core import init_django, get_models, console

    project_root = init_django(project_dir)
    models = get_models()

    cookies_qs = models.Cookie.objects.select_related("linkedin", "user").all()

    if not cookies_qs.exists():
        console.print("[yellow]⚠️ 数据库中没有任何 Cookie 记录[/]")
        return

    if output_format == "json":
        data_list = []
        for c in cookies_qs:
            data_list.append(
                {
                    "id": c.id,
                    "user_id": c.user_id,
                    "username": c.user.username,
                    "linkedin_name": c.linkedin.name,
                    "linkedin_link": c.linkedin.link,
                    "linkedin_active": c.linkedin.is_active,
                    "linkedin_valid": c.linkedin.is_valid,
                    "date": str(c.date),
                }
            )
        console.print(json.dumps(data_list, ensure_ascii=False, indent=2))
        return

    # Table 格式输出
    table = Table(
        title="📋 Cookie 列表",
        box=box.ROUNDED,
        header_style="bold cyan",
    )
    table.add_column("ID", style="dim", width=4)
    table.add_column("用户名", width=12)
    table.add_column("LinkedIn 名称", width=16)
    table.add_column("状态(模型)", width=10)
    table.add_column("活跃", width=6)
    table.add_column("创建日期", width=12)

    for c in cookies_qs:
        active_str = "[green]✅[/]" if c.linkedin.is_active else "[red]❌[/]"
        valid_str = "[green]有效[/]" if c.linkedin.is_valid else "[red]无效[/]"
        table.add_row(
            str(c.id),
            c.user.username,
            c.linkedin.name,
            valid_str,
            active_str,
            str(c.date),
        )

    console.print(table)
    console.print(f"\n[bold]总计:[/] {cookies_qs.count()} 条 Cookie 记录")


def test_cookies(
    project_dir: Optional[str] = None,
    cookie_ids: Optional[List[int]] = None,
) -> List[dict]:
    """
    测试 cookie 的有效性。

    遵循 script/get_available_cookies.py 中 get_cookies_schedule() 的行为:
    1. 遍历数据库中所有 Cookie（或指定 ID 的 Cookie）
    2. 实例化 LinkedIn 并连接
    3. 调用 Network.test_account() 验证
    4. 收集结果

    顺序逐个执行，每个 Cookie 测试间隔 2-3 秒，避免被 LinkedIn 识别为自动化行为。
    """
    from .core import init_django, get_models, get_linkedin, console

    project_root = init_django(project_dir)
    models = get_models()
    LinkedIn = get_linkedin()

    if cookie_ids:
        cookies_qs = models.Cookie.objects.filter(id__in=cookie_ids).select_related(
            "linkedin", "user"
        )
        if not cookies_qs.exists():
            console.print(
                f"[yellow]⚠️ 未找到指定 ID 的 Cookie: {cookie_ids}[/]"
            )
            return []
    else:
        cookies_qs = models.Cookie.objects.select_related("linkedin", "user").all()
        if not cookies_qs.exists():
            console.print("[yellow]⚠️ 数据库中没有任何 Cookie 记录[/]")
            return []

    results = []
    total = cookies_qs.count()
    console.print(
        f"\n[bold cyan]🔍 开始测试 {total} 个 Cookie 的有效性...[/]"
    )

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        console=console,
    ) as progress:
        task = progress.add_task(
            description="测试 Cookie...", total=total
        )

        # 顺序执行，每个 Cookie 测试间隔一定时间避免触发反爬虫
        for cookie in cookies_qs:
            result = get_cookie_status(cookie, LinkedIn)
            results.append(result)
            progress.update(task, advance=1)
            time.sleep(random.uniform(2, 3))

    # 统计结果
    valid_count = sum(1 for r in results if r["status"] == "有效")
    invalid_count = sum(1 for r in results if r["status"] == "无效")

    # 显示结果表格
    table = Table(
        title="📊 Cookie 测试结果",
        box=box.ROUNDED,
        header_style="bold cyan",
    )
    table.add_column("ID", style="dim", width=4)
    table.add_column("用户名", width=12)
    table.add_column("LinkedIn 名称", width=18)
    table.add_column("状态", width=8)
    table.add_column("错误信息", width=40)

    for r in sorted(results, key=lambda x: x["id"]):
        if r["status"] == "有效":
            status_str = "[green]✅ 有效[/]"
        else:
            status_str = "[red]❌ 无效[/]"
        table.add_row(
            str(r["id"]),
            r["username"],
            r["linkedin_name"],
            status_str,
            r.get("error", "") or "",
        )

    console.print(table)

    # 汇总面板
    summary = (
        f"[green]✅ 有效: {valid_count}[/]    "
        f"[red]❌ 无效: {invalid_count}[/]    "
        f"[bold]总计: {total}[/]"
    )
    console.print(
        Panel(summary, title="📈 测试汇总", border_style="blue")
    )

    return results


def update_cookies_cache(
    project_dir: Optional[str] = None,
    cookie_ids: Optional[List[int]] = None,
    test_first: bool = True,
) -> None:
    """
    将验证通过的 cookie 安全地存储到 Redis 缓存中。

    遵循 script/get_available_cookies.py 中 get_cookies() 的逻辑:
    1. 从数据库获取 Cookie 列表
    2. (可选) 逐个测试有效性
    3. 将有效 Cookie ID 存入 Redis 的 linkedin_cookies 列表
    4. 同时存入 AVAILABLE_COOKIES_LIST_SET
    """
    from .core import (
        init_django,
        get_models,
        get_linkedin,
        get_redis_cache,
        get_cookie_list_key,
        get_available_cookies_key,
        console,
    )

    project_root = init_django(project_dir)
    models = get_models()
    LinkedIn = get_linkedin()
    cache, pool = get_redis_cache()

    if cookie_ids:
        cookies_qs = models.Cookie.objects.filter(id__in=cookie_ids).select_related(
            "linkedin", "user"
        )
    else:
        cookies_qs = models.Cookie.objects.select_related("linkedin", "user").all()

    if not cookies_qs.exists():
        console.print("[yellow]⚠️ 没有找到任何 Cookie 记录[/]")
        return

    if test_first:
        console.print("[bold cyan]🔍 先测试 Cookie 有效性...[/]")
        results = test_cookies(project_dir, cookie_ids)
        valid_ids = [r["id"] for r in results if r["status"] == "有效"]
        if not valid_ids:
            console.print("[red]❌ 没有有效的 Cookie 可供缓存[/]")
            return
    else:
        valid_ids = [c.id for c in cookies_qs]

    # 更新 COOKIE_LIST_KEY (linkedin_cookies)
    cookie_list_key = get_cookie_list_key()
    try:
        cache.delete(cookie_list_key)
        if valid_ids:
            cache.lpush(cookie_list_key, *[str(v) for v in reversed(valid_ids)])
        console.print(
            f"[green]✅ 已将 {len(valid_ids)} 个有效 Cookie ID 写入 [bold]{cookie_list_key}[/][/]"
        )

        # 验证写入结果
        stored = cache.lrange(cookie_list_key, 0, -1)
        stored_ids = [s.decode("utf-8") for s in stored]
        console.print(f"   Redis 中当前 Cookie ID: {stored_ids}")
    except Exception as e:
        console.print(f"[bold red]❌ 写入 Redis 缓存失败: {e}[/]")
        raise typer.Exit(code=1)

    # 更新 AVAILABLE_COOKIES_LIST_SET
    available_set_key = get_available_cookies_key()
    try:
        cache.delete(available_set_key)
        if valid_ids:
            for vid in valid_ids:
                cache.sadd(available_set_key, str(vid))
        console.print(
            f"[green]✅ 已将 {len(valid_ids)} 个有效 Cookie ID 写入 Set [bold]{available_set_key}[/][/]"
        )
    except Exception as e:
        console.print(f"[yellow]⚠️ 写入 Set 缓存失败: {e}[/]")

    # 显示缓存更新结果
    console.print(
        Panel(
            f"[bold green]✅ 缓存更新完成[/]\n\n"
            f"  • 有效 Cookie 数: {len(valid_ids)}\n"
            f"  • Redis Key (list): {cookie_list_key}\n"
            f"  • Redis Key (set):  {available_set_key}",
            title="📦 缓存更新结果",
            border_style="green",
        )
    )

    cache.connection_pool.disconnect()
