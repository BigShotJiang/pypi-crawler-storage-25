"""
dlm-li-cat: 主 CLI 入口

使用 Typer 构建的命令行应用程序入口，聚合所有子命令。
"""

from typing import Optional, List
from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich import box

from . import __version__
from .core import init_django, console

app = typer.Typer(
    name="dlm-li-cat",
    help="LinkedIn Search CLI Tool - 管理并执行 LinkedIn 搜索任务",
    rich_markup_mode="rich",
    no_args_is_help=True,
    add_completion=False,
)

cookies_app = typer.Typer(
    name="cookies",
    help="Cookie 管理：展示、测试、更新缓存",
    no_args_is_help=True,
)
app.add_typer(cookies_app, name="cookies")


# ==============================================================================
# 版本信息
# ==============================================================================
def version_callback(value: bool):
    if value:
        console.print(f"[bold cyan]dlm-li-cat[/] v{__version__}")
        raise typer.Exit()


# ==============================================================================
# 全局选项
# ==============================================================================
@app.callback()
def main(
    ctx: typer.Context,
    version: bool = typer.Option(
        False,
        "--version",
        "-V",
        help="显示版本信息",
        callback=version_callback,
        is_eager=True,
    ),
    project_dir: Optional[str] = typer.Option(
        None,
        "--project-dir",
        "-d",
        help="项目根目录路径（默认自动探测）",
        envvar="DLM_CLI_PROJECT_DIR",
    ),
):
    """
    [bold]dlm-li-cat[/] - LinkedIn Search CLI Tool

    提供完整的 LinkedIn 搜索任务管理和执行能力。
    """
    # 全局 project_dir 存储在上下文 meta 中供子命令使用
    ctx.meta["project_dir"] = project_dir


# ==============================================================================
# cookies 子命令
# ==============================================================================
@cookies_app.command("show")
def cookies_show(
    ctx: typer.Context,
    show_invalid: bool = typer.Option(
        False, "--show-invalid", help="显示已失效的 Cookie（默认全部显示）"
    ),
    json_output: bool = typer.Option(
        False, "--json", "-j", help="以 JSON 格式输出"
    ),
):
    """📋 显示当前数据库中所有 Cookie 的详细信息"""
    from .cookie import show_cookies

    project_dir = ctx.meta.get("project_dir") if hasattr(ctx, "meta") else None
    show_cookies(
        project_dir=project_dir,
        show_invalid=show_invalid,
        output_format="json" if json_output else "table",
    )


@cookies_app.command("test")
def cookies_test(
    ctx: typer.Context,
    cookie_ids: Optional[str] = typer.Option(
        None,
        "--cookie-ids",
        "-i",
        help="指定要测试的 Cookie ID，逗号分隔（默认测试全部）",
    ),
):
    """🔍 测试 Cookie 有效性（顺序执行，避免被 LinkedIn 识别为自动化行为）"""
    from .cookie import test_cookies

    project_dir = ctx.meta.get("project_dir") if hasattr(ctx, "meta") else None
    ids = None
    if cookie_ids:
        try:
            ids = [int(x.strip()) for x in cookie_ids.split(",")]
        except ValueError:
            console.print("[red]❌ Cookie ID 格式错误，请用逗号分隔数字，例如: --cookie-ids 1,2,3[/]")
            raise typer.Exit(code=1)

    test_cookies(
        project_dir=project_dir,
        cookie_ids=ids,
    )


@cookies_app.command("update")
def cookies_update(
    ctx: typer.Context,
    cookie_ids: Optional[str] = typer.Option(
        None,
        "--cookie-ids",
        "-i",
        help="指定要缓存的 Cookie ID，逗号分隔（默认全部有效 Cookie）",
    ),
    skip_test: bool = typer.Option(
        False,
        "--skip-test",
        help="跳过有效性测试，直接缓存",
    ),
):
    """📦 将有效的 Cookie 安全存储到 Redis 缓存（顺序执行，避免被 LinkedIn 识别）"""
    from .cookie import update_cookies_cache

    project_dir = ctx.meta.get("project_dir") if hasattr(ctx, "meta") else None
    ids = None
    if cookie_ids:
        try:
            ids = [int(x.strip()) for x in cookie_ids.split(",")]
        except ValueError:
            console.print("[red]❌ Cookie ID 格式错误，请用逗号分隔数字[/]")
            raise typer.Exit(code=1)

    update_cookies_cache(
        project_dir=project_dir,
        cookie_ids=ids,
        test_first=not skip_test,
    )


# ==============================================================================
# search 子命令
# ==============================================================================
@app.command("search")
def search_command(
    ctx: typer.Context,
    keyword: str = typer.Option(
        ..., "--keyword", "-k", help="搜索关键词（必需）", show_default=False
    ),
    location: str = typer.Option(
        "",
        "--location",
        "-l",
        help="搜索地理位置编码，如 103644278(美国)",
    ),
    job_title: str = typer.Option(
        "",
        "--job-title",
        "-t",
        help="职位关键词，如 Engineer OR Scientist",
    ),
    company: str = typer.Option(
        "",
        "--company",
        "-c",
        help="公司名称，如 Nvidia",
    ),
    university: str = typer.Option(
        "",
        "--university",
        "-u",
        help="学校名称",
    ),
    family_name: str = typer.Option(
        "",
        "--family-name",
        "-f",
        help="要搜索的姓氏",
    ),
    network: str = typer.Option(
        "",
        "--network",
        "-n",
        help="人脉范围: F=好友, O=非好友, 留空=所有人",
    ),
    user_id: int = typer.Option(
        2,
        "--user-id",
        help="用户 ID（用于关联数据）",
    ),
    max_results: int = typer.Option(
        1000,
        "--max-results",
        "-m",
        help="每个姓氏最多获取的结果数",
    ),
    cookie_id: Optional[int] = typer.Option(
        None,
        "--cookie",
        help="指定使用特定的 Cookie ID（默认从 Redis 随机选取）",
        show_default=False,
    ),
):
    """
    🔍 执行 LinkedIn 搜索任务

    根据指定参数，遍历家族姓氏列表，在 LinkedIn 上搜索符合条件的候选人。
    """
    # 参数验证
    if network and network not in ("F", "O", ""):
        console.print("[red]❌ --network 只能为: F(好友), O(非好友), 留空(所有人)[/]")
        raise typer.Exit(code=1)

    from .search import run_search

    project_dir = ctx.meta.get("project_dir") if hasattr(ctx, "meta") else None

    run_search(
        keyword=keyword,
        location=location,
        job_title=job_title,
        company=company,
        university=university,
        family_name=family_name,
        network=network,
        current_user_id=user_id,
        project_dir=project_dir,
        max_results=max_results,
        cookie_id=cookie_id,
    )


# ==============================================================================
# init-family-names 子命令
# ==============================================================================
@app.command("init-names")
def init_family_names(
    ctx: typer.Context,
):
    """
    📝 初始化 Redis 中的家族姓氏列表

    从 django_settings.py 的 FAMILY_NAMES 中读取姓氏并写入 Redis。
    """
    from django.conf import settings
    from .core import init_django, get_redis_cache, console

    project_dir = ctx.meta.get("project_dir") if hasattr(ctx, "meta") else None
    project_root = init_django(project_dir)
    cache, pool = get_redis_cache()

    from .search import init_family_name as do_init
    names = do_init(cache, settings)

    console.print(
        Panel(
            f"[bold green]✅ 家族姓氏已成功写入 Redis[/]\n\n"
            f"  • Redis Key: [bold]name[/]\n"
            f"  • 姓氏数量:  {len(names)} 个\n"
            f"  • 范围:       {names[0]} ~ {names[-1]}",
            title="📝 初始化完成",
            border_style="green",
        )
    )
    pool.disconnect()


# ==============================================================================
# info 子命令
# ==============================================================================
@app.command("info")
def show_info(
    ctx: typer.Context,
):
    """
    ℹ️  显示项目环境信息

    展示数据库连接状态、Redis 状态、Cookie 数量等关键信息。
    """
    from .core import init_django, get_models, get_redis_cache, console
    from rich.table import Table

    try:
        project_root = init_django(
            ctx.meta.get("project_dir") if hasattr(ctx, "meta") else None
        )
        models = get_models()
        cache, pool = get_redis_cache()
    except Exception:
        return

    # 收集统计信息
    cookie_count = models.Cookie.objects.count()
    cookie_valid = models.Cookie.objects.filter(linkedin__is_valid=True).count()
    searchword_count = models.SearchWord.objects.count()
    candidate_count = models.CandidateList.objects.count()
    task_pending = models.SearwordChineseTask.objects.filter(status="待执行").count()
    task_completed = models.SearwordChineseTask.objects.filter(status="已完成").count()

    pool.disconnect()

    # 显示统计表
    table = Table(box=box.ROUNDED, title="📊 项目信息", header_style="bold cyan")
    table.add_column("指标", style="dim", width=20)
    table.add_column("数值", justify="right")

    table.add_row("项目路径", str(project_root))
    table.add_row("Cookie 总数", str(cookie_count))
    table.add_row("有效 Cookie", f"[green]{cookie_valid}[/]")
    table.add_row("搜索词数", str(searchword_count))
    table.add_row("候选人总数", f"[cyan]{candidate_count:,}[/]")
    table.add_row("待执行任务", f"[yellow]{task_pending}[/]")
    table.add_row("已完成任务", f"[green]{task_completed}[/]")

    console.print(table)
    console.print(
        Panel(
            "[green]✅ 环境正常[/]\n  Django 配置、Redis 连接、数据库连接均正常。",
            border_style="green",
        )
    )


# ==============================================================================
# 入口点
# ==============================================================================
if __name__ == "__main__":
    app()
