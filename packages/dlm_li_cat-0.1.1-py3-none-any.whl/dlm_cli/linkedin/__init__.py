"""
dlm-li-cat.linkedin - LinkedIn API 核心模块（内嵌子包）

提供 LinkedIn Voyager API 的封装，包括连接、搜索、网络操作等功能。
"""
