import pandas as pd
import requests
import time
import urllib
import datetime
import random
import math
import os
import json


basic_text = "Not defined, it should to allow user to connect"
key_text = "Connect key missing"
basic_error = "Not defined, it should return a Dataframe"
connect_error = "You should connect first"

LINKEDIN_API = "https://3hz1hdpnlf.eLINKEDIN_APIecute-api.eu-west-1.amazonaws.com/prod"

# LINKEDIN_API = "https://www.linkedin.com/voyager/api/"
DATE_FORMAT = "%Y-%m-%d"
DATETIME_FORMAT = "%Y-%m-%d %H:%M:%S"


class ConnectDriver:

    connected = False
    key = None
    raise_error = False

    def open_or_read(self, data):
        read_data = data
        try:
            read_data = open(data, "r").read()
        except OSError:
            pass
        return read_data

    def print_error(self, error):
        if self.raise_error:
            raise ValueError(error)
        else:
            print(error)

    def raise_for_error(self, raise_error=True):
        self.raise_error = raise_error

    def connect(self, key=None):
        self.key = key
        if self.key:
            self.connected = True
        else:
            self.print_error(key_text)
        return self

    def check_connect(self):
        if not self.connected:
            self.print_error(connect_error)

class InDriver(ConnectDriver):
    def convert_data_to_df(self, *args, **kwargs):
        return basic_error

    def get(self, *args, **kwargs) -> pd.DataFrame:
        self.check_connect()
        self.print_error(basic_error)

class OutDriver(ConnectDriver):
    def send(self, *args, **kwargs):
        self.check_connect()
        self.print_error(basic_error)
        return basic_error


class LinkedIn(InDriver, OutDriver):
    @property
    def short_wait(self):
        time.sleep(random.randint(2,5))

    @property
    def long_wait(self):
        time.sleep(random.randint(2, 10) + 3)

    def get_last_time_log(self):
        log_file = './src/logging.json'
        today = str(datetime.date.today())
        with open(log_file, 'r', encoding='utf-8') as file:
            js = json.loads(file.read())
            page,keyword = js['StartPage']
            if js.get(self.name)[1] == today:
                start = js.get(self.name)[0]
            else:
                start = 0
                js[self.name] = [start, today]
                update = json.dumps(js)
                print(update)
                with open(log_file, 'w', encoding='utf-8') as f:
                    f.write(update)
        return start,page,keyword


    def write_to_log(self,count,page,keyword):
        log_file = './src/logging.json'
        today = str(datetime.date.today())
        with open(log_file, 'r', encoding='utf-8') as file:
            js = json.loads(file.read())
            js[self.name] = [count, today]
            js["StartPage"] = [page, keyword]
            print(js)
            update = json.dumps(js)
            with open(log_file, 'w', encoding='utf-8') as f:
                f.write(update)

    deprecated = True

    @staticmethod
    def get_activity_id(url):
        return url.split("activity-")[-1].split("-")[0]

    def print_deprecated(self, new_funct):
        if self.deprected:
            print(f"This function is deprecated, please use {new_funct}")

    def get_profile_id(self, url):
        return url.rsplit("/in/")[-1].rsplit("/")[0]

    def get_profile_urn(self, url):
        lk_id = self.get_profile_id(url)
        res = requests.get(
            f"https://www.linkedin.com/voyager/api/identity/profiles/{lk_id}",
            cookies=self.cookies,
            headers=self.headers,
        )
        # Check if requests is successful
        try:
            res.raise_for_status()
            res_json = res.json()
            self.short_wait
            # print(res_json)
            return (
                res_json.get("data", {})
                    .get("entityUrn")
                    .replace("urn:li:fs_profile:", "")
            )
        except requests.HTTPError as e:
            return e

    def get_user_urn(self, profile_url):
        if profile_url.endswith("/"):
            profile_url = profile_url[:-1]
            print(profile_url)

        userid = profile_url.split('/')[-1]

        url = """https://www.linkedin.com/voyager/api/identity/dash/profiles?q=memberIdentity&memberIdentity={userid}"""
        formatted_url = url.format(userid=userid)
        urnfsd = None
        try:
            res = requests.get(formatted_url, headers=self.headers, cookies=self.cookies)
            data = res.json()['included'][0]
            urnfsd= data['entityUrn'][19:]
        except Exception as e:
            print(e)


        return urnfsd

    def get_birthdate(self, bd):
        if bd is None:
            return "No birthdate"
        bd_day = bd.get("day", "Day Unknown")
        bd_month = bd.get("month", "Month Unknown")
        bd_year = bd.get("year", "Year Unknown")
        return f"{bd_day}/{bd_month}/{bd_year}"

    def clear_occupation(self, occupation):
        if occupation is not None:
            occupation = occupation.strip().replace("\n", " ")
        return occupation

    def connect(self, li_at: str, jessionid: str,name:str):
        # Init lk attribute
        self.li_at = li_at
        self.jessionid = jessionid
        self.name = name

        # Init cookies
        self.cookies = {"li_at": self.li_at, "JSESSIONID": f'"{self.jessionid}"'}

        # Init headers
        self.headers = {
            "X-Li-Lang": "en_US",
            "Accept": "application/vnd.linkedin.normalized+json+2.1",
            "Cache-Control": "no-cache",
            "csrf-Token": self.jessionid.replace('"', ""),
            "X-Requested-With": "XMLHttpRequest",
            "X-Restli-Protocol-Version": "2.0.0",
        }

        # Init end point
        self.profile = Profile(self.cookies, self.headers)
        self.network = Network(self.cookies, self.headers)
        self.invitation = Invitation(self.cookies, self.headers)
        self.message = Message(self.cookies, self.headers)
        self.post = Post(self.cookies, self.headers)
        self.event = Event(self.cookies, self.headers)
        self.company = Company(self.cookies, self.headers)
        self.monitor = Monitor(self.cookies,self.headers)
        self.search = Search(self.cookies,self.headers,self.name)

        # Set connexion to active
        self.connected = True
        print('链接完成~')
        return self

    def logging_info(self):
        with open('logging.json','r',encoding='utf-8') as f:
            f.read()


class Monitor(LinkedIn):
    def __init__(self, cookies, headers):
        LinkedIn.__init__(self)
        self.cookies = cookies
        self.headers = headers

    # 判断名字是否是中文，如果是则返回True
    def is_Chinese(self, word):
        for ch in word:
            if "\u4e00" <= ch <= "\u9fff":
                return True
        return False

    def remove_friend(self,url):
        urn = self.get_profile_urn(url)
        data = {
            'connectionUrn': "urn:li:fsd_connection:{}".format(urn)
        }
        req_url = 'https://www.linkedin.com/voyager/api/relationships/dash/memberRelationships?action=removeFromMyConnections&decorationId=com.linkedin.voyager.dash.deco.relationships.MemberRelationship-29'
        res = requests.post(
            req_url,
            data=data,
            headers=self.headers,
            cookies=self.cookies,
        )
        self.long_wait
        try:
            res.raise_for_status()
            print('成功删除')
        except requests.HTTPError as e:
            print(e)
            return e


    def get_all_invitation(self,linkedin_name,start=0):
        start_page = start * 100
        req_url = f'https://www.linkedin.com/voyager/api/relationships/sentInvitationViewsV2?count=100&invitationType=CONNECTION&q=invitationType&start={start_page}'

        try:
            res = self.get_sent_invitation(linkedin_name,req_url)
            if not res:
                print('没有更多好友了')
                return {"data": "读取完成", "code": 201}
            return {"data": res, "code": 200}
        except Exception as e:
            print(e)
            return {"data": "出现问题了，建议重新试一下", "code": 404}



    def get_sent_invitation(self,linkedin_name,req_url):
        res = requests.get(req_url, cookies=self.cookies, headers=self.headers)
        lis = res.json().get('included')
        third = len(lis) // 3
        info_list,msg_list =  lis[:third], lis[third:third*2]
        all_list = []

        for index in range(third):
            lastName = info_list[index].get('lastName')
            firstName = info_list[index].get('firstName')
            entityUrn = info_list[index].get('entityUrn').replace('urn:li:fs_miniProfile:',"")
            publicIdentifier = "https://www.linkedin.com/in/{}/".format(info_list[index].get('publicIdentifier'))
            occupation = info_list[index].get('occupation')

            for i in msg_list:
                toMemberId = i.get('toMemberId')
                if entityUrn != toMemberId:
                    # print(toMemberId, entityUrn)
                    continue
                message = i.get('message')
                sentTime = i.get('sentTime')
                if sentTime:
                    sentTime = time.strftime(DATETIME_FORMAT, time.localtime(int(sentTime) / 1000))

                if self.is_Chinese(firstName) or self.is_Chinese(lastName):
                    name = "{}{}".format(lastName,firstName)
                else:
                    name = "{} {}".format(firstName,lastName)

                print(firstName,lastName,'名字', name)

                result = {
                    "profileID": entityUrn,
                    "linkedin": publicIdentifier,
                    "firstname": firstName,
                    "lastname": lastName,
                    "name": name,
                    "occupation": occupation,
                    # "industry": data.get("summary"),
                    # "location": data.get("geoLocationName") + data.get("locationName"),
                    "message":message,
                    "sendTime":sentTime,
                }

                all_list.append(result)

        return all_list



class Profile(LinkedIn):
    def __init__(self, cookies, headers):
        LinkedIn.__init__(self)
        self.cookies = cookies
        self.headers = headers

    def get_identity(self, url=None, urn=None):
        res_json = {}
        result = {}
        lk_id = self.get_profile_id(url)
        req_url = f"https://www.linkedin.com/voyager/api/identity/profiles/{lk_id}"
        res = requests.get(req_url, cookies=self.cookies, headers=self.headers)
        try:
            res.raise_for_status()
        except requests.HTTPError as e:
            print(e)
        else:
            res_json = res.json()
        # Parse json
        # print(res_json)
        data = res_json.get("data", {})

        print(data)
        location = ''
        if data.get("geoLocationName") and data.get("locationName"):
            location = data.get("geoLocationName") + " " + data.get("locationName")
        if data.get("geoLocationName"):
            location = data.get("geoLocationName")

        # if data.get("summary"):
        #     length = len(data.get("summary"))
        #     print(length)
        #     if length > 128:
        #         print(data.get("summary")[:128])

        result = {
            "profileID": data.get("entityUrn", "").replace("urn:li:fs_profile:", ""),
            "linkedin": "https://www.linkedin.com/in/{}/".format(lk_id),
            "firstname": data.get("firstName"),
            "lastname": data.get("lastName"),
            "name":data.get("firstName") + ' ' + data.get("lastName"),
            "occupation": data.get("headline"),
            "industry": data.get("summary"),
            "location": location,
        }

        return result

    def get_network(self, url=None, urn=None):
        res_json = {}
        result = {}
        lk_id = self.get_profile_id(url)
        req_url = f"https://www.linkedin.com/voyager/api/identity/profiles/{lk_id}/networkinfo"
        res = requests.get(req_url, cookies=self.cookies, headers=self.headers)
        try:
            res.raise_for_status()
        except requests.HTTPError as e:
            print(e)
        else:
            res_json = res.json()
        # Parse json
        data = res_json.get("data", {})
        result = {
            "PROFILE_URN": data.get("entityUrn", "").replace(
                "urn:li:fs_profileNetworkInfo:", ""
            ),
            "PROFILE_ID": lk_id,
            "DISTANCE": data.get("distance", {}).get("value"),
            "FOLLOWING": data.get("following"),
            "FOLLOWABLE": data.get("followable"),
            "FOLLOWERS_COUNT": data.get("followersCount"),
        }
        print(result)
        self.long_wait
        return pd.DataFrame([result])

    def get_contact(self, url=None, urn=None):
        res_json = {}
        result = {}
        lk_id = self.get_profile_id(url)
        req_url = f"https://www.linkedin.com/voyager/api/identity/profiles/{lk_id}/profileContactInfo"
        res = requests.get(req_url, cookies=self.cookies, headers=self.headers)
        try:
            res.raise_for_status()
        except requests.HTTPError as e:
            print(e)
        else:
            res_json = res.json()
        # Parse json
        data = res_json.get("data", {})
        # Specific
        connected_at = data.get("connectedAt")
        if connected_at is not None:
            connected_at = datetime.datetime.fromtimestamp(int(str(connected_at)[:-3])).strftime(
                "%Y-%m-%d %H:%M:%S"
            )
        lk_phone = None
        lk_phones = data.get("phoneNumbers")
        if lk_phones is not None:
            for rows in lk_phones:
                if rows["type"] == "MOBILE":
                    lk_phone = rows["number"]
                    break
        wechat_name = None
        wechat = data.get("weChatContactInfo")
        if wechat is not None:
            wechat_name = wechat.get('name')

        lk_twiter = None
        lk_twiters = data.get("twitterHandles")
        if lk_twiters is not None:
            for rows in lk_twiters:
                lk_twiter = rows["name"]
                break
        lk_urls = ""
        lk_websites = data.get("websites")
        if lk_websites is not None:
            for rows in lk_websites:
                lk_url = rows["url"]
                lk_urls = f"{lk_urls}{lk_url}, "
        result = {
            "urn": data.get("entityUrn", "").replace(
                "urn:li:fs_contactinfo:", ""
            ),
            "linkedin": 'https://www.linkedin.com/in/{}/'.format(lk_id),
            "email": data.get("emailAddress"),
            "wechat": wechat_name,
            "phone_number": lk_phone,
            "twitter": lk_twiter,
            "websites": lk_urls,
            "birthday": self.get_birthdate(data.get("birthDateOn")),
            "address": data.get("address"),

        }

        return result


    def get_resume(self, profile_url=None, profile_urn=None):
        res_json = {}
        if profile_urn is None:
            profile_urn = LinkedIn.get_profile_urn(self, profile_url)
            if profile_urn is None:
                return "Please enter a valid profile_url or profile_urn"

        LINKEDIN_BASE = "https://3hz1hdpnlf.execute-api.eu-west-1.amazonaws.com/prod"
        # LINKEDIN_BASE = "https://www.linkedin.com/voyager/api"
        req_url = f"{LINKEDIN_BASE}/profile/getResume?profile_urn={profile_urn}"
        headers = {"Content-Type": "application/json"}
        res = requests.post(req_url, json=self.cookies, headers=headers)
        print(res.status_code)
        if res.status_code == 403:
            print('403 禁止访问')
            return res.status_code
        # print(res.json())
        try:
            res.raise_for_status()
        except requests.HTTPError as e:
            return e
        else:
            res_json = res.json()
        # print(res_json)

        return pd.DataFrame(res_json)

    def get_posts_feed(
            self,
            profile_url,
            profile_id=None,
            count=1,
            limit=10,
            until={},
            sleep=True,
            pagination_token=None,
    ):
        """
        Return an dataframe object with 30 columns:
        - ACTIVITY_ID       object
        - PAGINATION_TOKEN  object
        - PUBLISHED_DATE    object
        - AUTHOR_NAME       object
        - SUBDESCRIPTION    object
        - TITLE             object
        - TEXT              object
        - CHARACTER_COUNT   int64
        - TAGS              object
        - TAGS_COUNT        int64
        - EMOJIS            object
        - EMOJIS_COUNT      int64
        - LINKS             object
        - LINKS_COUNT       int64
        - PROFILE_MENTION   object
        - COMPANY_MENTION   object
        - CONTENT           object
        - CONTENT_TITLE     object
        - CONTENT_URL       object
        - CONTENT_ID        object
        - IMAGE_URL         object
        - POLL_ID           object
        - POLL_QUESTION     object
        - POLL_RESULTS      object
        - POST_URL          object
        - VIEWS             int64
        - COMMENTS          int64
        - LIKES             int64
        - SHARES            int64
        - ENGAGEMENT_SCORE  float64

        Parameters
        ----------
        profile_url: str:
            Profile url from Linkedin.
            Example : "https://www.linkedin.com/in/florent-ravenel/"

        profile_id: str (default None):
            Linkedin unique profile id identifier
            Example : "ACoAABCNSioBW3YZHc2lBHVG0E_TXYWitQkmwog"

        count: int (default 1, max 100):
            Number of requests sent to LinkedIn API.
            (!) If count > 1, published date will not be returned.

        limit: int (default 10, unlimited=-1):
            Number of posts return by function. It will start with the most recent post.

        until: dict (default {})
            Dict to be set by end user to limit function:
            - key must a columns of the dataframe
            - value must exists in key columns
            Example : "{"POST_URL": "https://www.linkedin.com/posts/naas-ai_opensource-data-activity-6890025972754710529-akfv"

        sleep: boolean (default True):
            Sleeping time between function will be randomly between 3 to 5 seconds.

        pagination_token: str (default None):
            Token related to post used to start function from this post.
            If None, function starts from the last post.

        """
        # Get profile
        if profile_id is None:
            profile_id = LinkedIn.get_profile_urn(self, profile_url)
            if profile_id is None:
                return "Please enter a valid profile_url or profile_urn"
        # Until init
        until_check = False
        keys = []
        if isinstance(until, dict) and len(until) > 0:
            keys = [k for k, v in until.items()]
        # Loop init
        start = 0
        df = pd.DataFrame()
        while True:
            if limit != -1 and count > limit:
                limit = count
            if limit != -1 and start > limit - 1:
                break
            if pagination_token is not None:
                req_url = f"{LINKEDIN_API}/profile/getPostsFeed?profile_id={profile_id}&count={count}&pagination_token={pagination_token}"
            else:
                req_url = f"{LINKEDIN_API}/profile/getPostsFeed?profile_id={profile_id}&count={count}"
            headers = {"Content-Type": "application/json"}
            res = requests.post(req_url, json=self.cookies, headers=headers)
            try:
                res.raise_for_status()
            except requests.HTTPError as e:
                return e
            else:
                res_json = res.json()
            if len(res_json) == 0:
                break
            # Get response in dataframe
            tmp_df = pd.DataFrame(res_json)

            # Check until limit
            for k in keys:
                v = until.get(k)
                if k in tmp_df.columns:
                    values = tmp_df[k].astype(str).unique().tolist()
                    if str(v) in values:
                        until_check = True
                        break
            # Get pagination token + update start
            pagination_token = tmp_df.loc[0, "PAGINATION_TOKEN"]
            start += count

            # Concat dataframe
            df = pd.concat([df, tmp_df], axis=0)

            # Break if until condition is True
            if until_check:
                break
            # Time sleep to avoid linkedin ban
            if sleep:
                self.long_wait
        # Cleaning
        df.PUBLISHED_DATE = pd.to_datetime(df.PUBLISHED_DATE).dt.tz_localize(
            "Europe/Paris"
        )
        df.PUBLISHED_DATE = df.PUBLISHED_DATE.astype(str)
        return df.reset_index(drop=True)


class Network(LinkedIn):
    def __init__(self, cookies, headers):
        LinkedIn.__init__(self)
        self.cookies = cookies
        self.headers = headers

    def get_followers(self, start=0, count=100, limit=1000):
        limit_init = limit
        df_followers = pd.DataFrame()
        while True:
            if limit != -1 and limit < count:
                count = limit
            req_url = f"{LINKEDIN_API}/network/getFollowers?start={start}&count={count}&limit={limit}"
            headers = {"Content-Type": "application/json"}
            res = requests.post(req_url, json=self.cookies, headers=headers)
            try:
                res.raise_for_status()
            except requests.HTTPError:
                res_json = {}
            else:
                res_json = res.json()
            if len(res_json) == 0:
                break
            df = pd.DataFrame(res_json)
            df_followers = pd.concat([df_followers, df], axis=0)
            start += count
            if limit != -1:
                limit -= count
            self.short_wait
        df_followers = df_followers.drop_duplicates("PROFILE_URN").reset_index(
            drop=True
        )
        if limit != -1:
            df_followers = df_followers[:limit_init]
        return df_followers

    def get_connections(self, start=0, count=100, limit=1000):
        df_connections = pd.DataFrame()
        while True:
            if limit != -1 and limit < count:
                count = limit
            req_url = f"{LINKEDIN_API}/network/getConnections?start={start}&count={count}&limit={limit}"
            headers = {"Content-Type": "application/json"}
            res = requests.post(req_url, json=self.cookies, headers=headers)
            try:
                res.raise_for_status()
            except requests.HTTPError:
                res_json = {}
            else:
                res_json = res.json()
            if len(res_json) == 0:
                break
            df = pd.DataFrame(res_json)
            df_connections = pd.concat([df_connections, df], axis=0)
            start += count
            if limit != -1:
                limit -= count
            self.long_wait
        # print(df_connections)
        df_connections = df_connections.sort_values(
            by="CREATED_AT", ascending=False
        ).astype(str)
        return df_connections.drop_duplicates().reset_index(drop=True)

    # 判断名字是否是中文，如果是则返回True
    def is_Chinese(self, word):
        for ch in word:
            if "\u4e00" <= ch <= "\u9fff":
                return True
        return False

    def test_account(self,start=0,count=40):
        base_api = "https://www.linkedin.com/voyager/api/relationships/dash/connections?decorationId=com.linkedin.voyager.dash.deco.web.mynetwork.ConnectionListWithProfile-15"
        url = base_api + "&count={}&q=search&sortType=RECENTLY_ADDED&start={}".format(count, start)
        try:
            res = requests.get(url, cookies=self.cookies, headers=self.headers,timeout=5)
            if res.status_code == 200:
                return 200
        except Exception as e:
            print(e)
            return 404


    # 一键获取好友
    def get_friends(self,start=0,count=50):
        base_api = "https://www.linkedin.com/voyager/api/relationships/dash/connections?decorationId=com.linkedin.voyager.dash.deco.web.mynetwork.ConnectionListWithProfile-15"
        url = base_api + "&count={}&q=search&sortType=RECENTLY_ADDED&start={}".format(count,start)
        res = requests.get(url, cookies=self.cookies, headers=self.headers,)
        if not res.status_code == 200:
            return {"data":"请求失败, 请重新试一下或者检查Cookies","code":400}

        try:
            res.raise_for_status()
        except requests.HTTPError:
            res_json = {}
        else:
            res_json = res.json()

        # print(res_json)
        print(len(res_json['included']))

        friends_list = res_json['included']
        if not friends_list:
            print('没有更多好友了')
            return {"data":"读取完成","code":201}

        candlist = []

        for index,item in enumerate(friends_list):
            print(index,item)
            if item.get("lastName"):
                if item.get('profilePicture'):
                    try:
                        root_url = item['profilePicture']['displayImageReference']['vectorImage']['rootUrl']

                        end_url = item['profilePicture']['displayImageReference']['vectorImage']['artifacts'][0]['fileIdentifyingUrlPathSegment']
                        image_url = root_url + end_url
                        # print(f'图像地址:{image_url}')
                        item['image'] = image_url
                    except Exception as e:
                        print("Error func get_friend:",e)

                candlist.append(item)


        for j in candlist:
            urn = j.get("entityUrn").strip('urn:li:fsd_profile:')
            for i in friends_list:
                if i.get('createdAt'):
                    time_urn = i.get('entityUrn').strip('urn:li:fsd_connection:')
                    if urn == time_urn:
                        j['createdAt'] = i.get('createdAt')
        for i in candlist:
            i.pop('memorialized')
            i.pop('$recipeTypes')
            i.pop('$type')
            i.pop('profilePicture')
            # i.pop("$anti_abuse_metadata")

            if self.is_Chinese(i.get('firstName')) or self.is_Chinese(i.get('lastName')):
                i['name'] =  i.get('lastName') + i.get('firstName')
            else:
                i['name'] = i.get('firstName') + ' ' + i.get('lastName')

            i['firstname'] = i.get('firstName')
            i['lastname'] = i.get('lastName')
            i['occupation'] = i.get('headline')
            i['profileID'] = i.get('entityUrn').strip('urn:li:fsd_profile:')
            i['linkedin'] = 'https://www.linkedin.com/in/{}/'.format( i.get('publicIdentifier') )


            if i.get('createdAt'):
                i['connected_date'] = datetime.date.fromtimestamp(i.get('createdAt')/1000).strftime('%Y-%m-%d')
                i.pop('createdAt')
            else:
                i['connected_date'] = '2020-01-01'

            i.pop('entityUrn')
            i.pop('headline')
            i.pop('publicIdentifier')
            i.pop('lastName')
            i.pop('firstName')

        print("好友数目:", len(candlist))

        return {"code":200,"data":candlist}



class Invitation(LinkedIn):
    def __init__(self, cookies, headers):
        LinkedIn.__init__(self)
        self.cookies = cookies
        self.headers = headers


    def send(self,recipient_url=None, message="", recipient_urn=None,):
        if recipient_url is not None:
            recipient_urn = self.get_profile_urn(recipient_url)
        if recipient_urn is None:
            return True
        if message:
            message = ',"message":' '"' + message + '"'
        data = (
                (
                    '{"trackingId":"yvzykVorToqcOuvtxjSFMg==","invitations":[],"excludeInvitations":[],'
                    '"invitee":{"com.linkedin.voyager.growth.invitation.InviteeProfile":{"profileId":'
                )
                + '"'
                + recipient_urn
                + '"'
                + "}}"
                + message
                + "}"
        )
        head = self.headers
        head["accept"] = "application/vnd.linkedin.normalized+json+2.1"

        try:
            res = requests.post(
            "https://www.linkedin.com/voyager/api/growth/normInvitations",
            data=data.encode('utf-8').decode('latin1'),
            headers=head,
            cookies=self.cookies,
            )
            # self.long_wait
            res.raise_for_status()
            print(f"Invitation successfully sent !")
            return 200
        except requests.HTTPError as e:
            print(e)
            return 404

    # 更新版本发邀请消息的API
    def send_update(self,recipient_url=None, message="", recipient_urn=None,):
        print('New Version')
        if not recipient_urn:
            recipient_urn = self.get_user_urn(recipient_url)
            print("获取urn完成")
        print(recipient_urn)

        url = """https://www.linkedin.com/voyager/api/voyagerRelationshipsDashMemberRelationships?action=verifyQuotaAndCreate"""
        payload = {
            'inviteeProfileUrn': 'urn:li:fsd_profile:' + recipient_urn,
            'customMessage': message
        }

        head = self.headers
        head["accept"] = "application/vnd.linkedin.normalized+json+2.1"

        res = requests.post(url, headers=head, cookies=self.cookies, json=payload)

        try:
            res = requests.post(url, headers=head, cookies=self.cookies, json=payload)
            # self.long_wait
            res.raise_for_status()
            print(f"Invitation successfully sent !")
            return {"status":True,'data':'Invitation successfully sent!'}
        except requests.HTTPError as e:
            print(e)
            return {"status":False,'data':f'Invitation fail to send,errors:{e}!'}


class Message(LinkedIn):
    def __init__(self, cookies, headers):
        LinkedIn.__init__(self)
        self.cookies = cookies
        self.headers = headers

    def get_conversations(self, limit=-1, count=20):
        limit_max = 500
        params = {
            "limit": limit_max if limit > limit_max or limit == -1 else limit,
            "count": count,
        }
        headers = {"Content-Type": "application/json"}
        df_result = None
        while True:
            req_url = f"{LINKEDIN_API}/message/getConversations?{urllib.parse.urlencode(params, safe='(),')}"
            res = requests.post(req_url, json=self.cookies, headers=headers)
            print(res)
            if limit != -1:
                limit -= limit_max
                if limit < 0:
                    limit = 0
            try:
                res.raise_for_status()
            except requests.RequestException as e:
                return e
            else:
                res_json = res.json()
            if res.status_code != 200:
                return res.text
            print(res_json)
            df = pd.DataFrame(res_json)
            created_before = (
                                 (int)(
                                     datetime.datetime.strptime(
                                         df["LAST_ACTIVITY"].iloc[-1], DATETIME_FORMAT
                                     ).timestamp()
                                 )
                             ) * 1000
            params["created_before"] = created_before
            if df_result is None:
                df_result = df
            else:
                df_result = pd.concat([df_result, df])
            self.short_wait
            if limit == 0 or len(df) < params["limit"]:
                break
        print(df_result)
        return df_result.reset_index(drop=True)

    def get_messages(
            self, conversation_url=None, conversation_urn=None, start=0, limit=-1, count=20
    ):
        # Create the request URL with the given parameters
        req_url = f"{LINKEDIN_API}/message/getMessages?start={start}&limit={limit}&count{count}"
        # If conversation_url is given, add it to the request URL
        if conversation_url:
            req_url += f"&conversation_url={conversation_url}"
        # If conversation_urn is given, add it to the request URL
        if conversation_urn:
            req_url += f"&conversation_urn={conversation_urn}"
        # Set the headers for the request
        headers = {"Content-Type": "application/json"}
        # Make the POST request with the given URL and headers
        res = requests.post(req_url, json=self.cookies, headers=headers)
        # Raise an HTTPError if the request fails
        try:
            res.raise_for_status()
        except requests.HTTPError:
            # If the request fails, set the response JSON to an empty dictionary
            res_json = {}
        else:
            # If the request succeeds, set the response JSON to the response JSON
            res_json = res.json()
        # Create a DataFrame from the response JSON
        df = pd.DataFrame(res_json)
        # Wait for a long time
        self.long_wait
        # Reset the index of the DataFrame and return it
        return df.reset_index(drop=True)

    def send(self, content, recipients_url=None, recipients_urn=None):
        print('开始发送...')
        recipient_errors = []
        params = {"action": "create"}
        message_event = {
            "eventCreate": {
                "value": {
                    "com.linkedin.voyager.messaging.create.MessageCreate": {
                        "body": content,
                        "attachments": [],
                        "attributedBody": {
                            "text": content,
                            "attributes": [],
                        },
                        "mediaAttachments": [],
                    }
                }
            }
        }
        if type(recipients_url) is str:
            recipients_url = [recipients_url]
        if type(recipients_urn) is str:
            recipients_urn = [recipients_urn]
        if type(recipients_url) is list:
            recipients_urn = []
            for recipient in recipients_url:
                recipient_urn = LinkedIn.get_profile_urn(self, recipient)
                if type(recipient_urn) is requests.exceptions.HTTPError:
                    recipient_errors.append(recipient_urn)
                recipients_urn.append(recipient_urn)
        if len(recipient_errors) > 0:
            return recipient_errors
        message_event["recipients"] = recipients_urn
        message_event["subtype"] = "MEMBER_TO_MEMBER"
        payload = {
            "keyVersion": "LEGACY_INBOX",
            "conversationCreate": message_event,
        }
        res = requests.post(
            "https://www.linkedin.com/voyager/api/messaging/conversations",
            params=params,
            json=payload,
            cookies=self.cookies,
            headers=self.headers,
        )
        self.short_wait

        try:
            res.raise_for_status()
            # print("💬 Message successfully sent !")
            return {"status":True,'data':'Message successfully sent !'}
        except requests.HTTPError as e:
            # print(e)
            return {"status":False,'data':f'Message fail to send,errors:{e}!'}


class Post(LinkedIn):
    def __init__(self, cookies, headers):
        LinkedIn.__init__(self)
        self.cookies = cookies
        self.headers = headers

    def get_stats(self, post_url, activity_id=None):
        """
        Return an dataframe object with 28 columns:
        - ACTIVITY_ID       object
        - AUTHOR_NAME       object
        - SUBDESCRIPTION    object
        - TITLE             object
        - TEXT              object
        - CHARACTER_COUNT   int64
        - TAGS              object
        - TAGS_COUNT        int64
        - EMOJIS            object
        - EMOJIS_COUNT      int64
        - LINKS             object
        - LINKS_COUNT       int64
        - PROFILE_MENTION   object
        - COMPANY_MENTION   object
        - CONTENT           object
        - CONTENT_TITLE     object
        - CONTENT_URL       object
        - CONTENT_ID        object
        - IMAGE_URL         object
        - POLL_ID           object
        - POLL_QUESTION     object
        - POLL_RESULTS      object
        - POST_URL          object
        - VIEWS             int64
        - COMMENTS          int64
        - LIKES             int64
        - SHARES            int64
        - ENGAGEMENT_SCORE  float64

        Parameters
        ----------
        post_url: str:
            Post url from Linkedin.
            Example : "https://www.linkedin.com/posts/j%C3%A9r%C3%A9my-ravenel-8a396910_"
                      "thoughts-monday-work-activity-6891437034473426945-OOOg"

        activity_id: str (default None):
            Linkedin unique post id identifier
            Example : "6891437034473426945"

        """
        # Get profile
        if activity_id is None:
            activity_id = LinkedIn.get_activity_id(post_url)
            if activity_id is None:
                return "Please enter a valid post_url or activity_id"
        req_url = f"{LINKEDIN_API}/post/getStats?activity_id={activity_id}"
        headers = {"Content-Type": "application/json"}
        res = requests.post(req_url, json=self.cookies, headers=headers)
        try:
            res.raise_for_status()
        except requests.HTTPError as e:
            return e
        res_json = res.json()
        return pd.DataFrame(res_json)

    def get_polls(self, post_url, activity_id=None):
        """
        Return an dataframe object with 8 columns:
        - PROFILE_ID            object
        - PUBLIC_ID             object
        - FIRSTNAME             object
        - FULLNAME              object
        - OCCUPATION            object
        - PROFILE_PICTURE       object
        - BACKGROUND_PICTURE    object
        - POLL_RESULT           object

        Parameters
        ----------
        post_url: str:
            Post url from Linkedin.
            Example : "https://www.linkedin.com/posts/j%C3%A9r%C3%A9my-ravenel-8a396910_"
                      "thoughts-monday-work-activity-6891437034473426945-OOOg"

        activity_id: str (default None):
            Linkedin unique post id identifier
            Example : "6891437034473426945"

        """
        # Get profile
        if activity_id is None:
            activity_id = LinkedIn.get_activity_id(post_url)
            if activity_id is None:
                return "Please enter a valid post_url or activity_id"

        req_url = f"{LINKEDIN_API}/post/getPolls?activity_id={activity_id}"
        headers = {"Content-Type": "application/json"}
        res = requests.post(req_url, json=self.cookies, headers=headers)
        try:
            res.raise_for_status()
        except requests.HTTPError as e:
            return (e)
        res_json = res.json()
        return pd.DataFrame(res_json)

    def get_comments(self, post_url):
        req_url = f"{LINKEDIN_API}/post/getComments?post_link={post_url}"
        headers = {"Content-Type": "application/json"}
        res = requests.post(req_url, json=self.cookies, headers=headers)
        try:
            res.raise_for_status()
        except requests.HTTPError:
            res_json = {}
        else:
            res_json = res.json()
        df = pd.DataFrame(res_json)
        return df.reset_index(drop=True)

    def get_likes(self, post_url):
        req_url = f"{LINKEDIN_API}/post/getLikes?post_link={post_url}"
        headers = {"Content-Type": "application/json"}
        res = requests.post(req_url, json=self.cookies, headers=headers)
        try:
            res.raise_for_status()
        except requests.HTTPError:
            res_json = {}
        else:
            res_json = res.json()
        df = pd.DataFrame(res_json)
        return df.reset_index(drop=True)


class Event(LinkedIn):
    def __init__(self, cookies, headers):
        LinkedIn.__init__(self)
        self.cookies = cookies
        self.headers = headers

    def get_guests(self, url):
        req_url = f"{LINKEDIN_API}/event/getGuests?event_link={url}"
        headers = {"Content-Type": "application/json"}
        res = requests.post(req_url, json=self.cookies, headers=headers)
        try:
            res.raise_for_status()
        except requests.HTTPError:
            res_json = {}
        else:
            res_json = res.json()
        df = pd.DataFrame(res_json)
        return df.reset_index(drop=True)


class Company(LinkedIn):
    def __init__(self, cookies, headers):
        LinkedIn.__init__(self)
        self.cookies = cookies
        self.headers = headers

    def get_info(self, company_url):
        req_url = f"{LINKEDIN_API}/company/getInfo?company_url={company_url}"
        headers = {"Content-Type": "application/json"}
        res = requests.post(req_url, json=self.cookies, headers=headers)
        try:
            res.raise_for_status()
        except requests.HTTPError as e:
            return e
        else:
            res_json = res.json()
        return pd.DataFrame(res_json).reset_index(drop=True)


class Search(LinkedIn):
    def __init__(self, cookies, headers,name):
        LinkedIn.__init__(self)
        self.cookies = cookies
        self.headers = headers
        self.name = name

    def parse_line(self,i,key1,key2):
        if i[key1]:
            return i[key1][key2]
        return ""

    def get_total_page(self,keyword='',lastname='',title= '',company= '',network= '',location='',university='',start=0):
        page = None
        total = None
        base_url = 'https://www.linkedin.com/voyager/api/search/dash/clusters?&origin=FACETED_SEARCH&q=all&'
        Parameters = ['resultType:List(PEOPLE)', ]
        file_name = [keyword]
        if lastname:
            Parameters.append(f'lastName:List({lastname})')
            file_name.append(lastname)
        if title:  # Cloud Architect
            Parameters.append(f'title:List({title})')
            file_name.append(title)
        if network:  # List(F,S,O) 代表一级，二级，三级好友
            Parameters.append(f'network:List({network})')
        if company:
            Parameters.append(f'company:List({company})')
            file_name.append(company)
        if university:
            Parameters.append(f'schoolFreetext:List({university})')
            file_name.append(company)
        if location:  # 美国 103644278
            Parameters.append(f'geoUrn:List({location})')

        queryParameters = "({})".format(",".join(Parameters))

        query_list = [
            f'keywords:{keyword}',
            'flagshipSearchIntent:SEARCH_SRP',
            f'queryParameters:{queryParameters}',
            'includeFiltersInResponse:false',
        ]
        query = "({})".format(",".join(query_list))
        query_url = base_url + 'query={}'.format(query).replace(" ", "%20")
        print("_".join(file_name))
        try:
            res = requests.get(url=query_url + '&start={}'.format(start), cookies=self.cookies, headers=self.headers)
            print(res.status_code)
            page,total = self.get_page_data(res.json())
        except:
            return False

        return page,total

    def get_page_data(self,data):
        total = data['data']['metadata']['totalResultCount']
        paging = data['data']['paging']
        start = paging['start'] + 1
        search_total = paging['total']
        page = math.ceil(int(search_total) / 10)
        print(f"第{start}页，共{page}页,总计{search_total}/{total}")
        return page,total

    def parse_result(self,data):
        all_list = []
        for i in data['included']:
            try:
                title = self.parse_line(i,'title','text')
                current = self.parse_line(i, 'primarySubtitle', 'text')
                location = self.parse_line(i, 'secondarySubtitle', 'text')
                summary = self.parse_line(i, 'summary', 'text')
                distance = self.parse_line(i, 'entityCustomTrackingInfo', 'memberDistance')
                url = i['navigationUrl'].split('?')[0] + '/'
                urn = i['entityUrn'].rsplit(":")[-1].split(',')[0]
                # print(urn)
                try:
                    img = i['image']['attributes'][0]['detailDataUnion']['nonEntityProfilePicture']['vectorImage']['artifacts'][0]['fileIdentifyingUrlPathSegment']
                except:
                    img = ''
                # print(title,current,location,summary,distance,url, urn )
                all_list.append(
                    {
                    "name":title,
                    "occupation":current,
                    "location":location,
                    "industry":summary,
                    "distance":distance,
                    "linkedin":url,
                    "profileID":urn,
                    "image":img,
                    }
                )
            except Exception as e:
                print('解析错误：{}'.format(e))


        return all_list


    def search_query(self,keyword='',lastname='',title= '',company= '',network= '',location='',university='',start=0):
        base_url = 'https://www.linkedin.com/voyager/api/search/dash/clusters?&origin=FACETED_SEARCH&q=all&'
        Parameters = ['resultType:List(PEOPLE)',]
        file_name = [keyword]
        if lastname:
            Parameters.append(f'lastName:List({lastname})')
            file_name.append(lastname)
        if title: # Cloud Architect
            Parameters.append(f'title:List({title})')
            file_name.append(title)
        if network:  # List(F,S,O) 代表一级，二级，三级好友
            Parameters.append(f'network:List({network})')
        if company:
            Parameters.append(f'company:List({company})')
            file_name.append(company)

        if university:
            Parameters.append(f'schoolFreetext:List({university})')
            file_name.append(company)
        if location: # 美国 103644278
            Parameters.append(f'geoUrn:List({location})')


        queryParameters = "({})".format(",".join(Parameters))

        query_list = [
            f'keywords:{keyword}',
            'flagshipSearchIntent:SEARCH_SRP',
            f'queryParameters:{queryParameters}',
            'includeFiltersInResponse:false',
        ]
        query = "({})".format(",".join(query_list))
        query_url = base_url + 'query={}'.format(query).replace(" ","%20")
        keyword_name = "_".join(file_name)
        print(keyword_name)

        res = requests.get(url=query_url + f'&start={start}', cookies=self.cookies, headers=self.headers)
        print(res.status_code)
        if res.status_code != 200:
            return 400,400

        page,total= self.get_page_data(res.json())
        print("start", start,"page",page,"total",total)


        try:
            data = self.parse_result(res.json())
        except Exception as e:
            data = {}
            total = 0
            print(e)

        return data,total


    def auto_search(self,keyword='',lastname='',title= '',company= '',network= '',location='',university='',start=0):
        base_url = 'https://www.linkedin.com/voyager/api/search/dash/clusters?&origin=FACETED_SEARCH&q=all&'
        Parameters = ['resultType:List(PEOPLE)',]
        file_name = [keyword]
        if lastname:
            Parameters.append(f'lastName:List({lastname})')
            file_name.append(lastname)
        if title: # Cloud Architect
            Parameters.append(f'title:List({title})')
            file_name.append(title)
        if network:  # List(F,S,O) 代表一级，二级，三级好友
            Parameters.append(f'network:List({network})')
        if company:
            Parameters.append(f'company:List({company})')
            file_name.append(company)

        if university:
            Parameters.append(f'schoolFreetext:List({university})')
            file_name.append(company)
        if location: # 美国 103644278
            Parameters.append(f'geoUrn:List({location})')


        queryParameters = "({})".format(",".join(Parameters))

        query_list = [
            f'keywords:{keyword}',
            'flagshipSearchIntent:SEARCH_SRP',
            f'queryParameters:{queryParameters}',
            'includeFiltersInResponse:false',
        ]
        query = "({})".format(",".join(query_list))
        query_url = base_url + 'query={}'.format(query).replace(" ","%20")
        keyword_name = "_".join(file_name)
        # print(query_url + f'&start={start}')

        #################################################
        # 循环获取搜索数据
        data = ""
        try:
            res = requests.get(url=query_url + f'&start={start}', cookies=self.cookies, headers=self.headers)
            # print(res.status_code)
            print("开始解析")
            # print(res.json())
            data = self.parse_result(res.json())
            print('解析完成')
        except Exception as e:
            return {"code":500,"data":""}

        return {"code":res.status_code,"data":data}














