def parse_resume_df(df):
    from web import models
    from django.db import transaction

    dic = {'EXPERIENCE': [], 'EDUCATION': []}

    with transaction.atomic():
        for index, row in df.iterrows():
            can_obj = models.CandidateList.objects.filter(profileID=row[0]).first()
            models.ResumeData.objects.update_or_create(full_name=row[2],linkedin=can_obj.linkedin,urn=row[0],category=row[3],title=row[4],date_start=row[5],date_end=row[6],place_id=row[7],place=row[8],
                                                field=row[9],location=row[10],description=row[11],length=df.shape[0])

            dic['PROFILE_ID'] = row[0]
            dic['PROFILE_URL'] = can_obj.linkedin
            dic['FULL_NAME'] = row[2]

            if row[3] == 'Experience':
                line = {"PLACE": row[8], "TITLE": row[4], "DATE_START": row[5], "DATE_END": row[6], "LOCATION": row[10],
                        "DESCRIPTION": row[11]}

                dic['EXPERIENCE'].append(line)
            elif row[3] == 'Education':
                line = {"PLACE": row[8], "TITLE": row[4], "DATE_START": row[5].split("-")[0] if row[5] else "", "DATE_END": row[6].split("-")[0] if row[6] else "", "LOCATION": row[10],
                        "DESCRIPTION": row[11]}

                dic['EDUCATION'].append(line)

    return dic



# def parse_resume_df(df):
#     dic = {}
#     exp = []
#     edu = []
#     length = df.shape[0]
#
#     for index, row in df.iterrows():
#         can_obj = CandidateList.objects.filter(profileID=row[0]).first()
#         ResumeData.objects.update_or_create(full_name=row[2],linkedin=can_obj.linkedin,urn=row[0],category=row[3],title=row[4],date_start=row[5],date_end=row[6],place_id=row[7],place=row[8],
#                    field=row[9],location=row[10],description=row[11],length=length)
#
#
#         dic['PROFILE_ID'] = row[0]
#         dic['PROFILE_URL'] = can_obj.linkedin
#         dic['FULL_NAME'] = row[2]
#
#         if row[3] == 'Experience':
#             line = {"PLACE": row[8], "TITLE": row[4], "DATE_START": row[5], "DATE_END": row[6], "LOCATION": row[10],
#                     "DESCRIPTION": row[11]}
#
#             exp.append(line)
#         if row[3] == 'Education':
#             line = {"PLACE": row[8], "TITLE": row[4], "DATE_START": row[5].split("-")[0] if row[5] else "", "DATE_END": row[6].split("-")[0] if row[6] else "", "LOCATION": row[10],
#                     "DESCRIPTION": row[11]}
#             # print(line)
#             edu.append(line)
#
#     dic['EXPERIENCE'] = exp
#     dic['EDUCATION'] = edu
#
#     return dic
