"""
LinkedIn 搜索功能模块

集成 script/family_search.py 和 utils/auto_search.py 中的搜索逻辑，
提供统一的 CLI 接口。
"""

import os
import sys
import time
import datetime
import random
import threading
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table
from rich import box

console = Console()


_FAMILY_NAME_KEY = "name"
_COOKIE_LIST_KEY = "linkedin_cookies"


def init_family_name(cache, settings) -> None:
    """
    初始化 Redis 中的家族姓氏列表。
    从 django_settings.py 的 FAMILY_NAMES 中读取姓氏并写入 Redis。
    """
    names = settings.FAMILY_NAMES
    cache.delete(_FAMILY_NAME_KEY)
    cache.lpush(_FAMILY_NAME_KEY, *reversed([i.strip() for i in names]))
    return names


def linkedin_valid(cache, models, cookie_ids=None, specific_cookie_id=None):
    """
    从 Redis 中随机选择一个 Cookie 并连接 LinkedIn。
    若指定 specific_cookie_id，则使用该指定 Cookie。
    """
    from .linkedin.core import LinkedIn

    if specific_cookie_id is not None:
        # 使用指定的 Cookie ID
        cookie_id = specific_cookie_id
    elif cookie_ids is not None and cookie_ids:
        cookie_id = random.choice(cookie_ids)
    else:
        cookie_id_list = cache.lrange(_COOKIE_LIST_KEY, 0, -1)
        if not cookie_id_list:
            console.print("[red]❌ Redis 中无可用 Cookie，请先用 cookies update 命令更新[/]")
            return None
        cookie_id = str(random.choice(cookie_id_list), encoding="utf-8")

    try:
        cookie = models.Cookie.objects.get(id=cookie_id)
    except models.Cookie.DoesNotExist:
        console.print(f"[red]❌ Cookie ID {cookie_id} 在数据库中不存在[/]")
        return None

    LK = LinkedIn()
    LK.connect(
        li_at=cookie.LI_AT,
        jessionid=cookie.JSESSIONID,
        name=cookie.linkedin.name,
    )

    return LK, cookie


def format_search_query(
    keyword: str = "",
    location: str = "",
    job_title: str = "",
    company: str = "",
    university: str = "",
    family_name: str = "",
    network: str = "",
) -> dict:
    """
    格式化搜索参数字典。遵循 format_keyword() 的逻辑。
    """
    from .linkedin.location_list import COUNTRY_LIST

    query_dic = {
        "keyword": keyword,
        "location": location,
        "title": job_title,
        "company": company,
        "university": university,
        "lastname": family_name,
        "network": network,
    }

    # 处理 Location 转换
    if location:
        for loc_item in COUNTRY_LIST:
            if loc_item.get("id") == location:
                loc_name = loc_item.get("location")
                query_dic["location"] = loc_name
                break

    if network:
        query_dic["network"] = "好友" if network == "F" else "非好友"

    return query_dic


def run_search(
    keyword: str = "",
    location: str = "",
    job_title: str = "",
    company: str = "",
    university: str = "",
    family_name: str = "",
    network: str = "",
    current_user_id: int = 2,
    project_dir: Optional[str] = None,
    max_results: int = 1000,
    cookie_id: Optional[int] = None,
    headless: bool = False,
) -> None:
    """
    执行 LinkedIn 搜索任务的完整流程。

    集成 family_search.py 和 auto_search.py 的搜索逻辑:
    1. 初始化 Django + Redis
    2. 初始化家族姓氏列表到 Redis
    3. 格式化搜索参数
    4. 从 Redis 获取 Cookie 连接 LinkedIn
    5. 执行搜索并获取结果
    6. 保存结果到数据库
    """
    from .core import (
        init_django,
        get_models,
        get_redis_cache,
        console,
    )

    project_root = init_django(project_dir)
    models = get_models()
    cache, pool = get_redis_cache()

    from django.conf import settings
    from .linkedin.core import LinkedIn

    if not headless:
        console.print(
            Panel(
                f"[bold cyan]🔍 LinkedIn 搜索任务[/]\n\n"
                f"  • 关键词:    {keyword or '(空)'}\n"
                f"  • 地点:      {location or '(空)'}\n"
                f"  • 职位:      {job_title or '(空)'}\n"
                f"  • 公司:      {company or '(空)'}\n"
                f"  • 大学:      {university or '(空)'}\n"
                f"  • 姓氏:      {family_name or '(空)'}\n"
                f"  • 人脉:      {network or '(空)'}\n"
                f"  • Cookie ID: {cookie_id if cookie_id else '随机选取'}",
                title="📋 搜索参数",
                border_style="cyan",
            )
        )

    # Step 1: 初始化家族姓氏
    if not headless:
        console.print("[bold cyan]📝 初始化家族姓氏到 Redis...[/]")

    full_names = init_family_name(cache, settings)
    name_count = len(full_names)
    if not headless:
        console.print(f"[green]✅ 已加载 {name_count} 个姓氏到 Redis[/]")

    # Step 2: 获取可用的 Cookie 列表
    if cookie_id is not None:
        # 使用指定的 Cookie，不需要从 Redis 获取列表
        if not headless:
            console.print(f"[green]✅ 使用指定 Cookie ID: [bold]{cookie_id}[/][/]")
        cookie_ids_for_search = None
    else:
        cookie_id_list = cache.lrange(_COOKIE_LIST_KEY, 0, -1)
        if not cookie_id_list:
            console.print(
                "[red]❌ Redis 中无可用 Cookie[/]\n"
                "[yellow]请先运行: [bold]dlm-li-cat cookies update[/][/]"
            )
            pool.disconnect()
            return
        cookie_ids_for_search = [int(c.decode("utf-8")) for c in cookie_id_list]
        if not headless:
            console.print(f"[green]✅ 找到 {len(cookie_ids_for_search)} 个可用 Cookie[/]")

    # Step 3: 格式化搜索参数
    query_dic = format_search_query(
        keyword=keyword,
        location=location,
        job_title=job_title,
        company=company,
        university=university,
        family_name=family_name,
        network=network,
    )

    # 构建搜索词 (遵循 query() 中的逻辑)
    display_dic = dict(query_dic)
    if location and location.isdigit():
        display_dic["location"] = location
    if network:
        display_dic["network"] = network

    search_word_parts = [
        f"{k}:{v}" for k, v in display_dic.items() if v
    ]
    search_word = "_".join(search_word_parts) + "_CN_NAME"

    # Step 4: 创建或获取搜索词对象
    search_queryset = models.SearchWord.objects.filter(
        keyword=search_word, user_id=current_user_id
    )
    if search_queryset.exists():
        search_obj = search_queryset.first()
        start_num = search_obj.candidatelist_set.all().count()
        if not headless:
            console.print(f"[blue]ℹ️ 搜索词已存在，已有 {start_num} 条数据[/]")
        if search_obj.progress == "完成 - 100%":
            console.print("[green]✅ 该搜索词已完成，无需重复搜索[/]")
            pool.disconnect()
            return
    else:
        search_obj = models.SearchWord.objects.create(
            keyword=search_word, user_id=current_user_id
        )
        start_num = 0
        if not headless:
            console.print(f"[green]✅ 已创建新搜索词: {search_word}[/]")

    search_obj.date = datetime.date.today()
    search_obj.save()

    # Step 5: 执行姓氏搜索
    key = f"{current_user_id}_{search_obj.id}"
    start_index = 0
    if cache.get(key):
        start_index = int(cache.get(key))

    end_index = int(cache.llen(_FAMILY_NAME_KEY))

    if start_index < end_index:
        if not headless:
            progress_val = round(start_index / end_index * 100, 2) if end_index > 0 else 0
            console.print(
                f"[blue]ℹ️ 恢复搜索: 进度 {progress_val}% ({start_index}/{end_index})[/]"
            )

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task(
                description="执行搜索...", total=end_index - start_index
            )

            for i in range(start_index, end_index):
                family_name = str(
                    cache.lindex(_FAMILY_NAME_KEY, index=i), encoding="utf-8"
                )
                query_dic["lastname"] = family_name

                # 获取 LinkedIn 连接
                lk_result = linkedin_valid(cache, models, cookie_ids_for_search, specific_cookie_id=cookie_id)
                if lk_result is None:
                    break
                LK, cookie = lk_result

                # 执行搜索
                res = LK.search.get_total_page(**query_dic, start=0)
                if isinstance(res, tuple):
                    page, total = res
                else:
                    if not headless:
                        console.print(
                            f"[yellow]⚠️ 姓氏 '{family_name}' 搜索失败，跳过[/]"
                        )
                    cache.set(key, str(i + 1))
                    progress.update(task, advance=1)
                    time.sleep(2)
                    continue

                if total > max_results:
                    total = max_results

                # 创建搜索任务记录
                models.SearwordChineseTask.objects.get_or_create(
                    search_query=query_dic,
                    user_id=current_user_id,
                    keyword=search_obj,
                    total=total,
                    page=page,
                    status="待执行",
                )

                cache.set(key, str(i + 1))

                if not headless:
                    console.print(
                        f"  [cyan]姓氏 '{family_name}'[/]: "
                        f"页面 {page}, 总数 {total} "
                        f"[dim]({i+1-start_index}/{end_index-start_index})[/]"
                    )

                progress.update(task, advance=1)
                time.sleep(2)

        # 更新进度
        search_obj.progress = f"{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        search_obj.save()

    # Step 6: 生成执行任务
    total_tasks = models.SearwordChineseTask.objects.filter(
        keyword=search_obj, page__gt=0, status="待执行"
    ).count()

    completed_tasks = models.SearwordChineseTask.objects.filter(
        keyword=search_obj, status="已完成"
    ).count()

    if not headless:
        console.print(
            Panel(
                f"[bold green]✅ 搜索任务完成[/]\n\n"
                f"  • 搜索词:     {search_word}\n"
                f"  • 待执行任务: {total_tasks}\n"
                f"  • 已完成任务: {completed_tasks}\n"
                f"  • 姓氏范围:   {name_count} 个",
                title="📊 搜索结果",
                border_style="green",
            )
        )

    pool.disconnect()
