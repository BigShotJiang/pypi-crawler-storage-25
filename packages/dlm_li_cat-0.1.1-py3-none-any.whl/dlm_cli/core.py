"""
Django/Redis 初始化、项目配置发现及共享工具函数
"""

import os
import sys
import importlib
from pathlib import Path
from typing import Optional, Tuple

import typer
from rich.console import Console

console = Console()


def discover_project_root() -> Optional[Path]:
    """从当前目录向上查找包含 django_settings.py 的项目根目录"""
    cwd = Path(os.getcwd()).resolve()
    for parent in [cwd] + list(cwd.parents):
        if (parent / "django_settings.py").exists():
            return parent
    return None


def init_django(project_root: Optional[Path] = None) -> Path:
    """初始化 Django 环境，返回项目根路径

    查找 django_settings.py 的优先级:
    1. --project-dir 参数指定的路径
    2. 从当前目录向上自动发现
    3. 使用 dlm-li-cat 包内自带的默认配置
    """
    from rich.panel import Panel

    if project_root is None:
        project_root = discover_project_root()

    if project_root is None:
        # 尝试使用包内自带的默认配置
        bundled_config = Path(__file__).resolve().parent / "django_settings.py"
        if bundled_config.exists():
            # 将包目录加入 sys.path，使 Django 能导入 django_settings
            pkg_dir = str(bundled_config.parent)
            if pkg_dir not in sys.path:
                sys.path.insert(0, pkg_dir)
            project_root = bundled_config.parent
            os.environ.setdefault("DJANGO_SETTINGS_MODULE", "django_settings")
            console.print(
                Panel(
                    "[yellow]⚙️ 使用 dlm-li-cat 包内默认配置[/]\n\n"
                    "未找到项目级别的 [bold]django_settings.py[/]。\n"
                    f"已加载包内默认配置。[dim]可通过以下方式自定义:[/]\n"
                    "  • [bold]--project-dir[/] 参数指定自定义配置路径\n"
                    "  • 设置 [bold]DLM_CLI_PROJECT_DIR[/] 环境变量\n"
                    "  • 在项目目录下放置自定义 [bold]django_settings.py[/]",
                    title="配置加载",
                    border_style="yellow",
                )
            )
        else:
            project_root = Path(os.getcwd()).resolve()
            if not (project_root / "django_settings.py").exists():
                console.print(
                    Panel(
                        "[bold red]❌ 无法找到项目配置文件[/]\n\n"
                        "未找到 [bold]django_settings.py[/]。请确保:\n"
                        "  • 在项目目录下运行本命令\n"
                        "  • 或通过 [bold]--project-dir[/] 参数指定项目路径\n"
                        "  • 或设置 [bold]DLM_CLI_PROJECT_DIR[/] 环境变量",
                        title="项目定位失败",
                        border_style="red",
                    )
                )
                raise typer.Exit(code=1)

    project_root = project_root.resolve()
    project_root_str = str(project_root)

    # 将项目根目录加入 sys.path
    if project_root_str not in sys.path:
        sys.path.insert(0, project_root_str)

    # 设置 Django 配置（如已由回退逻辑设置，跳过）
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "django_settings")

    # 导入并初始化 Django
    try:
        import django

        django.setup()
    except ImportError as e:
        console.print(
            f"[bold red]❌ Django 导入失败: {e}[/]\n"
            f"[yellow]提示: 请确保已安装依赖，运行 [bold]pip install -r requirements.txt[/][/]"
        )
        raise typer.Exit(code=1)
    except Exception as e:
        console.print(f"[bold red]❌ Django 初始化失败: {e}[/]")
        raise typer.Exit(code=1)

    return project_root


def get_redis_cache() -> Tuple[object, object]:
    """连接并返回 Redis client 及 connection pool"""
    from django.conf import settings

    try:
        pool = __import__("redis").ConnectionPool(
            host=settings.REDIS_HOST,
            port=6379,
            password=settings.REDIS_PASSWORD,
        )
        cache = __import__("redis").Redis(connection_pool=pool)
        cache.ping()
        return cache, pool
    except ImportError:
        console.print("[bold red]❌ redis 模块未安装，请执行: pip install redis==4.3.1[/]")
        raise typer.Exit(code=1)
    except Exception as e:
        console.print(f"[bold red]❌ Redis 连接失败: {e}[/]")
        console.print(
            f"[yellow]  请检查 Redis 服务是否正常运行，以及配置是否正确[/]"
        )
        raise typer.Exit(code=1)


def get_django_cache() -> object:
    """获取 Django 缓存框架中的 Redis 缓存实例"""
    try:
        from django.core.cache import caches

        cache = caches["default"]
        return cache
    except Exception as e:
        console.print(f"[bold red]❌ Django 缓存初始化失败: {e}[/]")
        raise typer.Exit(code=1)


def get_models():
    """通过 Django app 注册表获取 web 应用的 models 模块"""
    try:
        from django.apps import apps as django_apps

        app_config = django_apps.get_app_config("web")
        return app_config.models_module
    except Exception as e:
        console.print(f"[bold red]❌ 模型获取失败: {e}[/]")
        console.print(
            "[yellow]  请确认 Django 配置中已注册 [bold]web[/] App[/]"
        )
        raise typer.Exit(code=1)


def get_linkedin() -> object:
    """导入并返回 linkedin.core.LinkedIn 类"""
    try:
        from .linkedin.core import LinkedIn as LK

        return LK
    except ImportError as e:
        console.print(f"[bold red]❌ LinkedIn 核心模块导入失败: {e}[/]")
        console.print(
            "[yellow]  请确认 [bold]linkedin[/] 子包已正确安装[/]"
        )
        raise typer.Exit(code=1)


def get_cookie_list_key() -> str:
    """返回 Redis 中存储 Cookie ID 列表的 key 名称"""
    return "linkedin_cookies"


def get_available_cookies_key() -> str:
    """返回 Redis 中存储可用 Cookie ID 列表的 key 名称"""
    from django.conf import settings

    return getattr(settings, "AVAILABLE_COOKIES_LIST_SET", "COOKIES_LIST_SET")
