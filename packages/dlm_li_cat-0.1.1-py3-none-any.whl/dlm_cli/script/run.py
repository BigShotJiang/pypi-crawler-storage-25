from dlm_cli.script.family_search import run_search, keyword_delete, update_cookies, get_cookie_pool

key = 'Nvidia'  # IT Manager  smts pmts
# key = ''
kwargs = {
    'keyword': key,
    'location': '',
    'job_title': 'Engineer OR Scientist OR Lead OR Tech',
    'company': "Nvidia",
    'university': '',
    'family_name': '',
    'network': ''
}

run_search(kwargs)


# keyword_delete('keyword:Microsoft_company:Microsoft_CN_NAME')

# Lina 2  Chandler 3
# update_cookies([253,])  # 137  169  177

# get_cookie_pool()  # 保存到redis的AVAILABLE_COOKIES_LIST
# test_linkedin_pool(AVAILABLE_COOKIES_LIST)

"""
加拿大 101174742
美国 103644278
硅谷 90000084
{'id': '102890883', 'location': '中国'},
{'id': '103873152', 'location': '北京'},
{'id': '102772228', 'location': '上海'},
{'id': '106750182', 'location': '深圳'},
{'id': '101821877', 'location': '杭州'},
{'id': '102046459', 'location': '广州'},
{'id': '107650347', 'location': '成都'},
{'id': '100275458', 'location': '西安'},
{'id': '107837013', 'location': '南京'},
"""

# generate_task('keyword:Workday Finance_location:美国_CN_NAME')

# IT Automation   # IT Manager
# Java Games   Canada
