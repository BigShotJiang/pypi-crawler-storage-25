from dlm_cli.script.family_search import get_cookies, get_cookies_schedule

if __name__ == '__main__':
    # get_cookies()
    get_cookies_schedule()
