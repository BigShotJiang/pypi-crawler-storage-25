"""
dlm_cli.script - LinkedIn 搜索独立脚本模块
"""
