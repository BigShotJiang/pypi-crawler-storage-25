import sys
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QLineEdit, QPushButton, QVBoxLayout, QMessageBox

from dlm_cli.script.family_search import run_search


class FamilySearchApp(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Family Search')
        self.resize(600, 300)  # 设置窗口尺寸
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()
        layout.setSpacing(5)  # 设置部件间距

        label_keyword = QLabel('Keyword:')
        label_keyword.setStyleSheet('font-weight: bold; font-size: 24px; color: #333;')

        self.input_keyword = QLineEdit(self)
        self.input_keyword.setText('AMD')
        self.input_keyword.setStyleSheet('padding: 5px; border: 1px solid #ccc;')

        label_company = QLabel('Company:')
        label_company.setStyleSheet('font-weight: bold; font-size: 24px; color: #333;')

        self.input_company = QLineEdit(self)
        self.input_company.setText('AMD')
        self.input_company.setStyleSheet('padding: 5px; border: 1px solid #ccc;')

        button = QPushButton('Run Search')
        button.clicked.connect(self.run_search)
        button.setStyleSheet('padding: 8px; background-color: #4CAF50; color: white; border: none;')

        self.status_label = QLabel()  # 用于显示搜索状态的标签
        layout.addWidget(label_keyword)
        layout.addWidget(self.input_keyword)
        layout.addWidget(label_company)
        layout.addWidget(button)
        layout.addWidget(self.status_label)

        self.setLayout(layout)

    def run_search(self):
        keyword = self.input_keyword.text()
        company = self.input_company.text()
        # location = self.input_location.text()

        kwargs = {
            'keyword': keyword,
            'location': '',
            'job_title': '',
            'company': company,
            'university': '',
            'family_name': '',
            'network': ''
        }

        self.status_label.setText('Searching...')  # 显示搜索状态信息

        results = run_search(kwargs)

        self.show_results(results)

    def show_results(self, results):
        self.status_label.setText('Search Completed')  # 在搜索完成后更新状态信息
        result_label = QLabel(f'Search Results: {results}')
        layout = self.layout()
        layout.addWidget(result_label)
        self.setLayout(layout)


def main():
    app = QApplication(sys.argv)
    window = FamilySearchApp()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
