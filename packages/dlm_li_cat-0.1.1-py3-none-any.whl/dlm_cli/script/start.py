import time
import os
import signal
import sys
import subprocess

# 保存当前运行的子进程
current_process = None


def run_script():
    """运行 dlm_cli.script.run 模块"""
    global current_process
    if current_process:  # 如果脚本已经在运行，先杀死它
        current_process.terminate()  # 终止子进程
        current_process.wait()  # 等待子进程完全终止
        print(f"Killed process {current_process.pid}")
        current_process = None

    # 重新启动脚本
    current_process = subprocess.Popen(
        [sys.executable, "-m", "dlm_cli.script.run"],
        creationflags=subprocess.CREATE_NEW_PROCESS_GROUP  # Windows 等价的进程组控制
    )
    print(f"Started process {current_process.pid}")


def main():
    try:
        while True:
            run_script()
            time.sleep(10 * 60)  # 每隔10分钟运行一次
    except KeyboardInterrupt:
        print("Terminating script...")
        if current_process:
            current_process.terminate()
            current_process.wait()
            print(f"Killed process {current_process.pid}")
        print("Exited gracefully.")


if __name__ == "__main__":
    main()
