#!/usr/bin/env python
# -*- coding:utf-8 -*-
import os

from dotenv import load_dotenv

# 从 .env 文件加载配置（如存在），优先级：.env > django_settings.py 默认值
load_dotenv()


def _env(key, default):
    """读取环境变量（来自 .env 或系统环境变量），若未设置则返回默认值"""
    return os.environ.get(key, default)


try:
    import pymysql
    pymysql.install_as_MySQLdb()
except ImportError:
    pass

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


# Django SECRET_KEY
SECRET_KEY = _env('DLM_SECRET_KEY', 'django-standalone-linkedin-search-key-20260517')

DEBUG = True

ALLOWED_HOSTS = ['*']

INSTALLED_APPS = [
    'django.contrib.contenttypes',
    'django.contrib.auth',
    'django.contrib.sessions',
    'dlm_cli.web.apps.WebConfig',
]

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

LANGUAGE_CODE = 'zh-hans'
TIME_ZONE = 'Asia/Shanghai'
USE_TZ = False
USE_I18N = True
USE_L10N = True

# Redis 连接配置（优先从 .env 文件读取）
REDIS_HOST = _env('DLM_REDIS_HOST', '127.0.0.1')
REDIS_PASSWORD = _env('DLM_REDIS_PASSWORD', '123456')
# MySQL 连接配置（优先从 .env 文件读取）
MYSQL_HOST = _env('DLM_MYSQL_HOST', '127.0.0.1')
MYSQL_PASSWORD = _env('DLM_MYSQL_PASSWORD', '123456')



# MySQL 数据库配置
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'dlm',
        'USER': 'dlm',
        'PASSWORD': MYSQL_PASSWORD,
        'HOST': MYSQL_HOST,
        'PORT': 3306,
        'OPTIONS': {
            'charset': 'utf8mb4',
        },
    }
}

# Redis 缓存配置（Django cache 框架）
CACHES = {
    "default": {
        "BACKEND": "django_redis.cache.RedisCache",
        "LOCATION": f"redis://{REDIS_HOST}:6379",
        "OPTIONS": {
            "CLIENT_CLASS": "django_redis.client.DefaultClient",
            "CONNECTION_POOL_KWARGS": {
                "max_connections": 1000,
                "encoding": "utf-8",
            },
            "PASSWORD": REDIS_PASSWORD,
        },
    }
}

# Cookie 集合常量
AVAILABLE_COOKIES_LIST_SET = 'COOKIES_LIST_SET'
UNAVAILABLE_COOKIES_LIST_SET = 'UNAVAILABLE_COOKIES_LIST_SET'


# 姓氏列表
FAMILY_NAMES = [
    'wang', 'li', 'zhang', 'liu', 'chen', 'yang', 'huang', 'wu', 'zhao', 'zhou',
    'xu', 'ma', 'zhu', 'hu', 'lin', 'guo', 'he', 'gao', 'luo', 'zheng', 'liang',
    'xie', 'song', 'tang', 'deng', 'feng', 'han', 'cao', 'ceng', 'peng', 'xiao',
    'cai', 'pan', 'tian', 'dong', 'yuan', 'yu', 'jiang', 'ye', 'du', 'wei',
    'cheng', 'lv', 'ding', 'shen', 'ren', 'yao', 'lu', 'zhong', 'cui', 'tan',
    'liao', 'fan', 'jin', 'shi', 'dai', 'jia', 'xia', 'qiu', 'fang', 'hou',
    'zou', 'xiong', 'meng', 'qin', 'bai', 'mao', 'yan', 'xue', 'yin', 'fu',
    'duan', 'lei', 'long', 'qian', 'tao', 'gu', 'gong', 'hao', 'shao', 'wan',
    'hong', 'lai', 'mo', 'kong', 'xiang', 'chang', 'wen', 'kang', 'niu', 'ge',
    'xing', 'qi', 'yi', 'qiao', 'pang', 'ni', 'zhuang', 'nie', 'yue', 'zhan',
    'geng', 'guan', 'jiao', 'zuo', 'gan', 'bao', 'ning', 'ruan', 'shang', 'shu',
    'ji', 'ke', 'mei', 'tong', 'bi', 'ling', 'dan', 'huo', 'miao', 'pei', 'tu',
    'qu', 'sheng', 'ran', 'weng', 'you', 'xin', 'ouyang', 'chai', 'hua', 'pu',
    'teng', 'jie', 'mou', 'mu', 'ying', 'nong', 'si', 'zhuo', 'che', 'jian',
    'lian', 'mai', 'chu', 'dou', 'cen', 'dang', 'jing', 'bo', 'fei', 'leng',
    'xi', 'mi', 'sui', 'zong', 'gui', 'quan', 'gou', 'min', 'zang', 'bian',
    'chou', 'luan', 'diao', 'sha', 'kou', 'rong', 'lang', 'sang', 'cong', 'zhen',
    'chi', 'ming', 'she', 'cha', 'kuang', 'ju', 'hui', 'nan', 'ban', 'lao',
    'xian', 'man', 'hai', 'qiang', 'shuai', 'gai', 'zu', 'zhi', 'qing', 'ping',
    'suo', 'xuan', 'men', 'yun', 'chao', 'rui', 'que', 'yong', 'xiu', 'tai',
    'hang', 'na', 'ru', 'bin', 'zan', 'heng', 'shou', 'bei', 'bu', 'shui',
    'xun', 'bie', 'bing', 'da', 'kuai', 'lun', 'shan', 'tie', 'kui', 'wo',
    'zi', 'cang', 'hei', 'huai', 'huan', 'nian', 'qie', 'shuang', 'ang',
    'baili', 'bang', 'chan', 'chong', 'chuai', 'chuan', 'chun', 'cuan', 'cun',
    'diwu', 'dian', 'tou', 'dun', 'duo', 'gang', 'guang', 'jiu', 'jue', 'jun',
    'kai', 'kan', 'kao', 'kuo', 'lie', 'miu', 'nai', 'nao', 'neng', 'mie',
    'pian', 'ruo', 'sai', 'sen', 'shun', 'tuo', 'zai', 'zeng'
]
