"""
dlm-li-cat: LinkedIn Search CLI Tool

基于 Typer 构建的命令行应用程序，专门用于 LinkedIn 搜索功能的管理和执行。

主要功能:
  - cookies show       显示当前可用的 cookie 列表及其详细信息
  - cookies test       测试 cookie 的有效性
  - cookies update     将有效的 cookie 更新到 Redis 缓存
  - search             执行 LinkedIn 搜索任务
"""

__version__ = "0.1.1"
