#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""LinkedIn 搜索工具函数（已迁移至 dlm_cli 包内）"""

from dlm_cli.core import init_django, get_models

init_django()

models = get_models()
from dlm_cli.linkedin.core import LinkedIn
from time import sleep
import random
import threading
from django.core.cache import caches

cache = caches['default']


# cache.set('tom','send',10)
# print(cache.delete('searchkeyword_656'))

def get_keyword_query(current_user_id, keyword_id):
    search_obj = models.SearchWord.objects.filter(id=keyword_id, user_id=current_user_id).first()
    exist_query_obj = models.QuerySearch.objects.filter(search_id=keyword_id).first()
    if not exist_query_obj:
        return {"data": "搜索词不存在，请删除搜索词，并重新搜索", "status": True}
    query_dic = exist_query_obj.query
    query_dic = eval(query_dic)
    start_num = exist_query_obj.start_num
    start_num = int(start_num)
    search_project_id = exist_query_obj.project_id

    if start_num == 1000:
        search_obj.progress = "{} - {}%".format("完成", "100")
        search_obj.save()
        return {"data": "恭喜~ 任务执行完成！", "status": False}

    print('搜索词{}，开始值{},项目ID:{}'.format(search_obj, start_num, search_project_id))

    return {
        "query_dic": query_dic,
        "start_num": start_num,
        "search_project_id": search_project_id,
        "search_obj": search_obj,
        "exist_query_obj": exist_query_obj,
    }


def init_linkedin(current_user_id, query_dic, search_obj):
    # 获取LINKEDIN参数
    cooki_obj = models.Cookie.objects.get(
        linkedin__user_id=current_user_id, linkedin__is_active=True, linkedin__is_valid=True
    )
    if not cooki_obj:
        search_obj.progress = "Cookies不可用，请查看Cookies"
        search_obj.save()
        return {"data": "没有可用的Cookies, 请查看Cookies", "status": True}

    linkedin_obj = models.Linkedin.objects.get(user_id=current_user_id, is_active=True)

    # 实例化Linkedin
    LK = LinkedIn()
    LK.connect(li_at=cooki_obj.LI_AT, jessionid=cooki_obj.JSESSIONID, name=linkedin_obj.name)

    ##########  获取页面数据 ##############
    res = LK.search.get_total_page(**query_dic, start=0)

    if not res:
        res_test = LK.network.test_account()
        if res_test != 200:
            search_obj.progress = "Cookies失效，请更新"
            search_obj.save()
        else:
            search_obj.progress = "出问题了，请点击继续"
            search_obj.save()
            return {"status": True}

    page, total = res
    print('页数{},总数{}'.format(page, total))
    if total > 1000:
        total = 1000
    return {"page": page, "total": total, 'linkedin_obj': LK}


def linkedin_query_search(
    current_user_id, search_project_id, start_num, search_obj, exist_query_obj, query_dic, linkedin_obj, page, total
):
    # 第一步
    ########### 根据返回的结果进行自加，然后去搜索##########
    LK = linkedin_obj
    while start_num < 1000:
        print('-' * 200)
        print("start_num:{},page:{}".format(start_num, page))
        data = LK.search.auto_search(**query_dic, start=str(start_num))
        code = data.get('code')
        res = data.get('data')
        if code == 500:
            res_test = LK.network.test_account()
            if res_test != 200:
                search_obj.progress = "{} - {}%".format("Cookies失效，请更新", round(start_num / total * 100, 2))
                search_obj.save()
                return {"data": "cookies失效，请登录Linkedin更新cookies", "status": True}

            search_obj.progress = "{} - {}%".format("意外终止，请点击继续", round(start_num / total * 100, 2))
            search_obj.save()
            return {"data": "遇到问题，建议重新试下，如果重试不行,请更新Cookies", "status": True}

        if code == 200 and not res:
            search_obj.progress = "{} - {}%".format("完成", "100")
            search_obj.save()
            return HttpResponse("恭喜，任务执行完成")

        search_obj.progress = "{} - {}%".format("执行中", round(start_num / total * 100, 2))
        search_obj.save()

        start_num += len(res)
        exist_query_obj.start_num = start_num
        exist_query_obj.save()

        result_to_db(res, current_user_id, search_obj.id, search_project_id)


def result_to_db(res, current_user_id, search_obj_id, search_project_id):
    #### 查询数据库，并写入数据######
    result = []
    for i in res:
        i['user_id'] = str(current_user_id)
        result.append(i)
    linkedin_list = [i['linkedin'] for i in result]
    exist_list = []

    candidates = models.CandidateList.objects.filter(linkedin__in=linkedin_list, user_id=current_user_id)
    # 如果不存在
    if candidates.exists():
        for candidate in candidates:
            exist_list.append(candidate.linkedin)
            # 如果存在，更新数据
            for item in result:
                if item['linkedin'] == candidate.linkedin:
                    sleep(random.uniform(0.5, 1))
                    candidate.occupation = item['occupation'].encode('utf8')
                    print(item['occupation'].encode('utf8'))
                    candidate.industry = item['industry'].encode('utf8')
                    candidate.location = item['location']
                    candidate.image = item['image']
                    candidate.save()

    # 需要新创建的列表
    new_list = list(set(linkedin_list).difference(set(exist_list)))
    # 批量创建
    person_list = []
    for linkedin in new_list:
        for item in result:
            if item['linkedin'] == linkedin:
                # print('新创建', item)
                person = models.CandidateList(**item)
                person_list.append(person)
    models.CandidateList.objects.bulk_create(person_list)
    print("批量创建{}".format(len(new_list)))
    print("已存在{}".format(len(exist_list)))

    # 批量添加project，searchword
    queryset = models.CandidateList.objects.filter(linkedin__in=linkedin_list, user_id=current_user_id)

    for can_obj in queryset:
        sleep(random.uniform(0.5, 1))
        try:
            can_obj.searchword.add(search_obj_id)
        except Exception:
            pass
        try:
            can_obj.project.add(search_project_id)
        except Exception:
            pass
        can_obj.save()


def auto_search_continue(current_user_id, keyword_id):
    params_dic = {"current_user_id": current_user_id}
    res_key = get_keyword_query(current_user_id, keyword_id)
    if res_key.get('status'):  # 搜索完成
        print(res_key.get('data'))
        return
    res_lk = init_linkedin(current_user_id, res_key['query_dic'], res_key.get('search_obj'))
    if res_lk.get('status'):  #  出问题了
        print(res_lk.get('data'))
        return
    params_dic.update(res_key)
    params_dic.update(res_lk)
    linkedin_query_search(**params_dic)


# current_user_id = 2
# keyword_id = 355
# auto_search_continue(current_user_id, keyword_id)
