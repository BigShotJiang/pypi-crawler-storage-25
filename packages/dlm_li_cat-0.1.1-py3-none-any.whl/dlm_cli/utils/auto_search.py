#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""自动 LinkedIn 搜索功能（已迁移至 dlm_cli 包内）"""

import time
import datetime
import random
import threading
import concurrent.futures

from dlm_cli.core import init_django, get_models, get_redis_cache

init_django()

models = get_models()
from dlm_cli.linkedin.location_list import COUNTRY_LIST
from dlm_cli.utils.search_utils import auto_search_continue, init_linkedin, result_to_db
from dlm_cli.linkedin.core import LinkedIn
from django.conf import settings

cache, _ = get_redis_cache()

FAMILY_NAME_KEY = 'name'
COOKIE_LIST_KEY = 'linkedin_cookies'
AVAILABLE_COOKIES_LIST = 'COOKIES_LIST'


# 往数据库添加数据：链接数据库、操作、关闭链接
def init_family_name():
    names = settings.FAMILY_NAMES
    cache.delete(FAMILY_NAME_KEY)
    cache.lpush(FAMILY_NAME_KEY, *reversed([i.strip() for i in names]))
    print(f'>>>> Family Name成功添加到redis的{FAMILY_NAME_KEY}')


def format_keyword(
    keyword='', location='', job_title='', company='', university='', family_name='', network=''
):
    query_dic = {
        "keyword": keyword,
        "location": location,
        "title": job_title,
        "company": company,
        "university": university,
        "lastname": family_name,
        "network": network,
    }

    # 处理Location,把地点文字转化成地点数字
    if location:
        for loc_item in COUNTRY_LIST:
            if loc_item.get("id") == location:
                loc_name = loc_item.get('location')
                query_dic['location'] = loc_name
                break
    if network:
        if network == "F":
            query_dic['network'] = "好友"
        else:
            query_dic['network'] = "非好友"

    search_word = '_'.join(['{}:{}'.format(k, v) for k, v in query_dic.items() if v]) + '_CN_NAME'

    return search_word, query_dic


def query(
    keyword='', location='', job_title='', company='',
    university='', family_name='', network='', current_user_id=2
):
    search_word, query_dic = format_keyword(
        keyword, location, job_title, company, university, family_name, network
    )
    print(search_word)

    # 判断搜索词是否存在，如果不存在则创建,并获取start_num
    search_queryset = models.SearchWord.objects.filter(keyword=search_word, user_id=current_user_id)
    if search_queryset.exists():
        search_obj = search_queryset.first()
        start_num = search_obj.candidatelist_set.all().count()
        search_obj.date = datetime.date.today()
        search_obj.save()
        print('搜索词存在')
        if search_obj.progress == "完成 - 100%":
            return {"data": "任务执行完成，请到候选人列表中查看", "status": True}

    else:
        search_obj = models.SearchWord.objects.create(keyword=search_word, user_id=current_user_id)
        cache.set('run', '1')
        # search_obj.project.add(search_project_id)
        start_num = 0

    query_dic['location'] = location
    query_dic['network'] = network

    #########################################  LinkedIn #####################################################
    key = "{}_{}".format(current_user_id, search_obj.id)
    start_index = 0
    if cache.get(key):
        start_index = int(cache.get(key))
    end_index = int(cache.llen(FAMILY_NAME_KEY))
    if start_index == end_index:
        print(f'完成进度：100% | 开始:{start_index} | 总数:{end_index}')
        return search_word
    print(f'完成进度：{round(start_index/end_index * 100, 2)}% | 开始:{start_index} | 总数:{end_index}')
    for i in range(start_index, end_index):
        family_name = str(cache.lindex(FAMILY_NAME_KEY, index=i), encoding='utf8')
        query_dic["lastname"] = family_name

        LK = linkedin_valid()
        res = LK.search.get_total_page(**query_dic, start=0)
        page, total = res
        print('页数{},总数{}'.format(page, total))
        if total > 1000:
            total = 1000

        models.SearwordChineseTask.objects.get_or_create(
            search_query=query_dic, user_id=current_user_id,
            keyword=search_obj, total=total, page=page, status='待执行'
        )
        cache.set(key, str(i + 1))
        time.sleep(2)

        search_obj = models.SearchWord.objects.filter(keyword=search_word).first()
        search_obj.progress = f'{datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}'
        search_obj.save()

    return search_word


def get_cookie_pool():
    """
    获取可用的cookie，存入redis
    :return:
    """
    cache.delete(AVAILABLE_COOKIES_LIST)
    queryset_cookie = models.Cookie.objects.all()
    for cookie in queryset_cookie:
        print(cookie.linkedin.name)
        LK = LinkedIn()
        LK.connect(li_at=cookie.LI_AT, jessionid=cookie.JSESSIONID, name='chandler')
        res_test = LK.network.test_account()
        if res_test != 200:
            print("Cookies失效，请更新")
            continue
        print(cookie.id, cookie.user_id)
        cache.lpush(AVAILABLE_COOKIES_LIST, cookie.id)
        time.sleep(1)


def test_linkedin_pool(KEY):
    """
    获取cookie池中的用户和领英的信息
    :return:
    """
    li = cache.lrange(KEY, 0, -1)
    for i in li:
        id = str(i, encoding='utf8')
        obj = models.Cookie.objects.filter(id=id).first()

        LK = LinkedIn()
        LK.connect(li_at=obj.LI_AT, jessionid=obj.JSESSIONID, name='chandler')
        res_test = LK.network.test_account()
        if res_test != 200:
            print(f"Cookies失效，请更新 - ID:{obj.user_id} - 账号:{obj.user} - 领英:{obj.linkedin} - Cookie ID:{obj.id}")
            continue
        print(f"ID:{obj.user_id} - 账号:{obj.user} - 领英:{obj.linkedin} - Cookie ID:{obj.id}")
        time.sleep(1)


def linkedin_valid():
    # 1. 选择cookie
    cookie_id_list = cache.lrange(COOKIE_LIST_KEY, 0, -1)
    cookie_id = str(random.choice(cookie_id_list), encoding='utf8')
    cookie = models.Cookie.objects.get(id=cookie_id)
    # 实例化Linkedin
    LK = LinkedIn()
    LK.connect(li_at=cookie.LI_AT, jessionid=cookie.JSESSIONID, name='xxx')
    print('-' * 100)
    print('Linkedin Account:', cookie.linkedin.name)
    return LK


def search(query_dic, start_num, search_obj, current_user_id=2, search_project_id=19):
    # 1. 选择cookie
    LK = linkedin_valid()

    # 2. 通过search_query, start_num获取数据
    data = LK.search.auto_search(**query_dic, start=str(start_num))
    code = data.get('code')
    res = data.get('data')
    if code != 200:
        print(data)
        return
    # 3. 保存数据
    result_to_db(res, current_user_id, search_obj.id, search_project_id)
    # 4. 更新数据库
    # cache.hdel('')


def generate_task(
    keyword='', location='', job_title='', company='',
    university='', family_name='', network=''
):
    search_word = query(keyword, location, job_title, company, university, family_name, network)
    print(search_word)
    search_obj = models.SearchWord.objects.filter(keyword=search_word).first()
    candidates = models.CandidateList.objects.filter(searchword=search_obj)
    search_obj.candidate_num = candidates.count()
    search_obj.save()

    tasks = models.SearwordChineseTask.objects.filter(keyword=search_obj, page__gt=0, status='待执行')
    print('剩余任务', tasks.count())

    cache.set('run', tasks.count())
    print(search_obj)
    if not tasks:
        search_obj.progress = '完成 - 100%'

    for task in tasks:
        print(task.search_query, task.page)
        if int(task.start_num) == int(task.page) * 10:
            task.status = '已完成'
            task.save()
            print('已完成')
            continue
        search(eval(task.search_query), task.start_num, search_obj)
        task.start_num += 10
        task.save()

        current_tasks = models.SearwordChineseTask.objects.filter(
            keyword=search_obj, page__gt=0, status='待执行'
        )
        search_obj.progress = f'{datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}|剩余:{current_tasks.count()}'
        search_obj.save()


class MyThread(threading.Thread):
    def __init__(self, keyword, location, job_title, company, university, family_name, network):
        threading.Thread.__init__(self)
        self.keyword = keyword
        self.location = location
        self.job_title = job_title
        self.company = company
        self.university = university
        self.family_name = family_name
        self.network = network

    def run(self):
        print('任务开始执行...')
        init_family_name()
        cookie_id_list = cache.lrange(COOKIE_LIST_KEY, 0, -1)
        if not cookie_id_list:
            print(f'>>>> 请添加{COOKIE_LIST_KEY}到redis,示例:lpush linkedin_cookies 2 3 4')
            return
        generate_task(
            self.keyword, self.location, self.job_title,
            self.company, self.university, self.family_name, self.network
        )


def keyword_delete(searchword):
    keyword = models.SearchWord.objects.filter(keyword=searchword).first()
    models.SearwordChineseTask.objects.filter(keyword_id=keyword.id).delete()
    keyword.delete()
    print('删除成功', searchword)


def search_continue(**kwargs):
    search_word, query_dic = format_keyword(**kwargs)
    print(search_word)

    status = None
    i = 0
    while i < 6:
        search_obj = models.SearchWord.objects.filter(keyword=search_word).first()
        if search_obj:
            current_status = search_obj.progress
            if status is None:
                status = current_status
            elif current_status != status:
                return False
        else:
            return True  # 如果没有找到search_obj，返回True
        time.sleep(5)  # 等待10秒
        i += 1
    return True  # 如果循环完成，status没有变化，返回True


def run_search(kwargs):
    if not search_continue(**kwargs):
        print('>>>>>>>>>> 搜索任务在进行中,请稍后再试 >>>>>>>>>>>>')
        return
    my_thread = MyThread(**kwargs)
    my_thread.start()
    print(f"线程启动，ID: {my_thread.ident}")  # 打印线程 ID

    monitor_flag = True

    while monitor_flag:
        if cache.get('run'):
            count = cache.get('run').decode('utf8')
            if count and int(count) == 0:
                print('#' * 40, '任务完成', '#' * 40)
                break
        time.sleep(2)
        if not my_thread.is_alive():
            print('线程已停止，正在重新启动')
            my_thread = MyThread(**kwargs)
            my_thread.start()
            print(f"线程重新启动，ID: {my_thread.ident}")  # 打印重新启动的线程 ID


def update_cookies(cookie_id_list):
    cache.delete(COOKIE_LIST_KEY)
    cache.lpush(COOKIE_LIST_KEY, *cookie_id_list)
    cookie_list = cache.lrange(COOKIE_LIST_KEY, 0, -1)

    print(f"success update cookie list:{cookie_list}")
    return f"success update cookie list:{cookie_list}"


def connect_linkedin(cookie):
    LK = LinkedIn()
    LK.connect(li_at=cookie.LI_AT, jessionid=cookie.JSESSIONID, name='chandler')
    res_test = LK.network.test_account()
    if res_test != 200:
        print("Cookies失效，请更新")
        return
    print(">" * 50, 'Cookie ID', cookie.id, "User ID", cookie.user_id)
    cache.lpush(AVAILABLE_COOKIES_LIST, cookie.id)
    time.sleep(1)


def get_cookies():
    queryset_cookie = models.Cookie.objects.exclude(id__in=[2, 3, 4])
    # 假设 queryset_cookie 是你的查询结果列表
    with concurrent.futures.ThreadPoolExecutor(max_workers=50) as executor:
        # 使用 map 函数提交任务到线程池
        executor.map(connect_linkedin, queryset_cookie)


def get_cookie_linkedin_user(redis_key):
    cookies_list = cache.lrange(redis_key, 0, -1)
    cookies_list = [i.decode('utf8') for i in cookies_list]
    cookie_info = ''
    print(cookies_list)
    for cookie in cookies_list:
        cookie_obj = models.Cookie.objects.get(id=cookie)
        info = f"{cookie_obj.linkedin.user.username} | {cookie_obj.linkedin.name} | {cookie_obj.id}"
        cookie_info += info + '\n'

    return cookie_info


def get_available_test_cookies():
    return get_cookie_linkedin_user(AVAILABLE_COOKIES_LIST)


def get_current_use_cookies():
    return get_cookie_linkedin_user(COOKIE_LIST_KEY)


# get_cookies()
# get_cookie_linkedin_user()
