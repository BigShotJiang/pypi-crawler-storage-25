from django.apps import AppConfig


class WebConfig(AppConfig):
    name = 'dlm_cli.web'
