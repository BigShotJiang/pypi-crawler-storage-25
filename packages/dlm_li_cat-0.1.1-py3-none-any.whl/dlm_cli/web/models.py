from django.db import models


class UserInfo(models.Model):
    """
    用户表
    """
    username = models.CharField(verbose_name='姓名', max_length=16)
    mobile_phone = models.CharField(verbose_name='手机号', max_length=32)



    def __str__(self):
        return self.username

    class Meta:
        verbose_name = "用户表"
        verbose_name_plural = verbose_name


class Linkedin(models.Model):
    """
    领英账号
    """
    name = models.CharField(verbose_name='名字', max_length=64)
    link = models.CharField(verbose_name='主页链接', max_length=256)
    cookies = models.TextField(verbose_name="Cookies")
    is_active = models.BooleanField(verbose_name="激活状态")
    is_valid = models.BooleanField(verbose_name="Cookies状态")
    user = models.ForeignKey(verbose_name="用户名",to="UserInfo")
    date = models.DateField(verbose_name="日期", auto_now_add=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "领英账号"
        verbose_name_plural = verbose_name

class Cookie(models.Model):
    """
    存储用户Cookie
    """
    linkedin = models.OneToOneField(verbose_name="领英账号",to="Linkedin")
    LI_AT = models.TextField(verbose_name="LI_AT")
    JSESSIONID = models.TextField(verbose_name="JSESSIONID")
    user = models.ForeignKey(verbose_name="用户名", to="UserInfo")
    date = models.DateField(verbose_name="日期", auto_now_add=True)

    def __str__(self):
        return self.linkedin

    class Meta:
        verbose_name = "Cookies"
        verbose_name_plural = verbose_name


class Project(models.Model):
    """
    项目表
    """
    title = models.CharField(verbose_name='项目名称',max_length=128)
    user = models.ForeignKey(verbose_name="用户名",to="UserInfo")
    candidate_num = models.IntegerField(verbose_name="候选人数目",default=0)
    keyword_num = models.IntegerField(verbose_name="搜索词数目",default=0)
    candidate_viewed = models.IntegerField(verbose_name="已查看候选人",default=0)
    progress = models.CharField(verbose_name="进度",max_length=32,blank=True,null=True)
    date = models.DateField(verbose_name="日期", auto_now_add=True)

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = "项目"
        verbose_name_plural = verbose_name





class SearchWord(models.Model):
    """
    搜索词表
    """
    keyword = models.CharField(verbose_name="搜索词", max_length=256)
    project = models.ManyToManyField(verbose_name='项目', to='Project')
    candidate_num = models.IntegerField(verbose_name="人才总数", default=0)
    candidate_viewed = models.IntegerField(verbose_name="已查看候选人", default=0)
    progress = models.CharField(verbose_name="搜索进度", max_length=32, blank=True, null=True)

    status_choices = (
        (0, "待查看"),
        (1, "查看中"),
        (2, "完成查看"),

    )

    user = models.ForeignKey(verbose_name="用户名", to="UserInfo")
    date = models.DateField(verbose_name="日期", auto_now_add=True)

    status = models.SmallIntegerField(verbose_name="查看状态", choices=status_choices, default=0)

    def __str__(self):
        return self.keyword

    class Meta:
        verbose_name = "搜索词"
        verbose_name_plural = verbose_name

class Keyword(models.Model):
    """
    技术关键词
    """
    word = models.CharField(verbose_name="关键词", max_length=256)
    user = models.ForeignKey(verbose_name="用户名", to="UserInfo")
    date = models.DateField(verbose_name="日期", auto_now_add=True)

    def __str__(self):
        return self.word



class CandidateList(models.Model):
    """
    候选人表
    """
    name = models.CharField(verbose_name='姓名', max_length=64)
    email = models.EmailField(verbose_name='邮箱', max_length=64,blank=True, null=True)
    phone = models.CharField(verbose_name='电话', max_length=64,blank=True, null=True)
    wechat = models.CharField(verbose_name='微信', max_length=64,blank=True, null=True)
    linkedin = models.CharField(verbose_name='领英', max_length=256,)
    image = models.CharField(verbose_name='图片', max_length=256,blank=True, null=True)
    comments = models.CharField(verbose_name='备注', max_length=256, blank=True, null=True)
    project = models.ManyToManyField(verbose_name="项目", to="Project")
    searchword = models.ManyToManyField(verbose_name="搜索词", to="SearchWord")
    keyword = models.ManyToManyField(verbose_name="关键词", to="Keyword")
    chinese_names = [
        (0, "未知"),
        (1, "华人"),
        (2, "疑似华人"),
    ]
    isChineseName = models.IntegerField(verbose_name="中文名", choices=chinese_names, default=0)

    view_choices = [
        (0, "未查看"),
        (1, "已查看"),
    ]
    view_or_not = models.BooleanField(verbose_name="是否查看", choices=view_choices, default=0)


    occupation = models.CharField(verbose_name='职位名称',max_length=256,blank=True, null=True)
    industry = models.CharField(verbose_name='行业',max_length=256,blank=True, null=True)
    location = models.CharField(verbose_name='地点',max_length=64,blank=True, null=True)
    profileID = models.CharField(verbose_name='候选人ID',max_length=128,blank=True, null=True)
    firstname = models.CharField(verbose_name='名', max_length=32, blank=True, null=True)
    lastname = models.CharField(verbose_name='姓', max_length=32, blank=True, null=True)
    distance = models.CharField(verbose_name='距离',max_length=16,blank=True, null=True)
    date = models.DateTimeField(verbose_name="联系日期", auto_now_add=True,null=True,blank=True)
    message_date = models.DateTimeField(verbose_name="发消息日期",null=True,blank=True)


    total_view_num = models.IntegerField(verbose_name="总浏览量",default=0)
    total_invitation_num = models.IntegerField(verbose_name="总邀请次数",default=0)

    user = models.ForeignKey(verbose_name="用户",to="UserInfo",default=1,db_index=True)
    invitation_status = models.ManyToManyField(verbose_name="邀请状态",to="InvitationStatus")
    view_status = models.ManyToManyField(verbose_name="查看状态",to="ViewStatus")
    pipeline_staus = models.ManyToManyField(verbose_name="流程状态",to="PipelineStatus")

    friend_status = models.ManyToManyField(verbose_name="是否好友",to="MyFriends")

    is_deleted = models.BooleanField(verbose_name="是否删除",default=False)

    linkedin_invite = models.ManyToManyField(verbose_name="领英邀请", to="Linkedin")

    invite_message = models.ManyToManyField(verbose_name="邀请信息",to="InvitationMessage")

    star_choices = [
        (0, "未星标"),
        (1, "已星标"),
    ]

    chagpt_choices = [
        (0, "不推荐"),
        (1, "推荐"),
    ]
    star = models.BooleanField(verbose_name="星标", choices=star_choices, default=0)
    chat_gpt_recommend = models.BooleanField(verbose_name="ChatGPT推荐", choices=chagpt_choices, default=0)


    def __str__(self):
        return self.name

    # class Meta:
    #     # 联合唯一
    #     unique_together = [('linkedin', 'user'),]
    class Meta:
        verbose_name = "候选人列表"
        verbose_name_plural = verbose_name









class QuerySearch(models.Model):
    search_id = models.IntegerField(verbose_name="搜索词ID")
    query = models.TextField(verbose_name="搜索条件")
    start_num = models.CharField(verbose_name="上次开始页码",max_length=16,default=0)
    project_id = models.IntegerField(verbose_name="项目ID")
    celery_id = models.CharField(verbose_name="Celery ID", max_length=256,blank=True,null=True)
    celery_status = models.CharField(verbose_name="Celery状态", max_length=64,blank=True,null=True)

    class Meta:
        verbose_name = "搜索任务表"
        verbose_name_plural = verbose_name





class SearwordChineseTask(models.Model):
    user = models.ForeignKey(verbose_name='用户', to='UserInfo')
    search_query = models.CharField(verbose_name="搜索Dict", max_length=256)
    keyword = models.ForeignKey(verbose_name='搜索词', to='SearchWord')
    page = models.IntegerField(verbose_name="页数")
    total = models.IntegerField(verbose_name='总数')
    start_num = models.IntegerField(verbose_name='开始数字',default=0)
    status = models.CharField(verbose_name="状态", max_length=64)
    create_datetime = models.DateTimeField(verbose_name='创建时间', auto_now_add=True)

    class Meta:
        verbose_name = "搜索中文任务表"
        verbose_name_plural = verbose_name


class UserLogin(models.Model):
    user = models.ForeignKey(verbose_name='用户', to='UserInfo')
    ip = models.CharField(verbose_name='IP地址',max_length=64)
    http_user_agent = models.CharField(verbose_name='浏览器', max_length=256, blank=True, null=True)
    server = models.CharField(verbose_name='服务器',max_length=64,blank=True,null=True)
    location = models.CharField(verbose_name='登录地点',max_length=64,blank=True,null=True)
    login_time = models.DateTimeField(verbose_name='登录时间', auto_now_add=True)

    class Meta:
        verbose_name = "用户登录表"
        verbose_name_plural = verbose_name


class InvitationStatus(models.Model):
    name = models.CharField(verbose_name='状态名称', max_length=64)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = '邀请状态'
        verbose_name_plural = verbose_name


class ViewStatus(models.Model):
    name = models.CharField(verbose_name='状态名称', max_length=64)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = '查看状态'
        verbose_name_plural = verbose_name


class PipelineStatus(models.Model):
    name = models.CharField(verbose_name='状态名称', max_length=64)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = '流程状态'
        verbose_name_plural = verbose_name


class MyFriends(models.Model):
    name = models.CharField(verbose_name='好友状态', max_length=64)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = '好友状态'
        verbose_name_plural = verbose_name


class InvitationMessage(models.Model):
    content = models.TextField(verbose_name='消息内容', blank=True, null=True)

    def __str__(self):
        return str(self.id)

    class Meta:
        verbose_name = '邀请消息'
        verbose_name_plural = verbose_name


class ResumeData(models.Model):
    full_name = models.CharField(verbose_name='全名', max_length=128)
    linkedin = models.CharField(verbose_name='领英', max_length=256)
    urn = models.CharField(verbose_name='URN', max_length=128)
    category = models.CharField(verbose_name='类别', max_length=64)
    title = models.CharField(verbose_name='标题', max_length=256, blank=True, null=True)
    date_start = models.CharField(verbose_name='开始日期', max_length=64, blank=True, null=True)
    date_end = models.CharField(verbose_name='结束日期', max_length=64, blank=True, null=True)
    place_id = models.CharField(verbose_name='地点ID', max_length=128, blank=True, null=True)
    place = models.CharField(verbose_name='地点', max_length=256, blank=True, null=True)
    field = models.CharField(verbose_name='领域', max_length=256, blank=True, null=True)
    location = models.CharField(verbose_name='位置', max_length=256, blank=True, null=True)
    description = models.TextField(verbose_name='描述', blank=True, null=True)
    length = models.IntegerField(verbose_name='长度', default=0)

    def __str__(self):
        return self.full_name

    class Meta:
        verbose_name = '简历数据'
        verbose_name_plural = verbose_name
