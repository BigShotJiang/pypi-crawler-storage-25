"""webots-mcp-kit package."""

__all__ = ["__version__"]

__version__ = "0.10.7"
