import asyncio
from typing import Optional, List
from .exceptions import LobbyJoinError, ChatMessageNotFound
from .utils import generate_lobby_code

# because we cant reverse enginner among us, we will use amongus library
import amongus
from amongus.client import Client
from amongus.events import on_chat

class lobbyValidator:
  def __init__(self, region: str = 'North America', bot_name: str = 'AmongBot Verifier'):
    self.region = region
    self.bot_name = bot_name
    self.client = Optional[Client] = None
    self.chat_messages: List[str] = []
    self._chat_event = asyncio.Event()
    self._target_username: Optional[str] = None
    
  async def _on_chat(self, player_name: str, message: str):
    self.chat_messages.append(f'{player_name}: {message}')
    if self._target_username and self._target_username.lower() in message.lower():
      self._chat_event.set()
      
  async def connect(self):
    self.client = Client(name=self.bot_name)
    self.client.on(on_chat, self._on_chat)
    await self.client.start(region=self.region)
    
  async def join_lobby(self, code: str) -> bool:
    if not self.client:
      raise LobbyJoinError('Client not connected...')
    try:
      result = await self.client.join_lobby(code.upper())
      return result
    except Exception as e:
      raise LobbyJoinError(f'Failed to join lobby: {e}')
      
  async def wait_for_chat_message(self, expected_text: str, timeout: float = 30.0) -> bool:
    self._target_username = expected_text
    try:
      await asyncio.wait_for(self._chat_event.wait(), timeout=timeout)
      return True
    except asyncio.TimeoutError:
      return False
      
  async def close(self):
    if self.client:
      await self.client.stop()
      
generate_lobby_code = generate_lobby_code