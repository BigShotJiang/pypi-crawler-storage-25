import requests
import time
from dataclasses import dataclass
from typing import Optional, Dict, Any
from .exceptions import *

api_base = 'https://api.innersloth.com'
user_agent = 'AmongUs/2024.11.26 (Windows; Steam)'

last_request_time = 0
min_interval = 1.0

def rate_limit():
  global last_request_time
  elapsed = time.time() - last_request_time
  if elapsed < min_interval:
    time.sleep(min_interval - elapsed)
  last_request_time = time.time()
  
@dataclass
class tokenVerificationResult:
  valid: bool
  puid: Optional[str] = None
  name: Optional[str] = None
  level: Optional[int] = None
  friend_code: Optional[str] = None
  platform: Optional[str] = None
  cosmetics: Optional[list] = None
  raw_data: Optional[Dict] = None
  error: Optional[str] = None
  
def verify_token(token: str, timeout: int = 15, proxies: Optional[Dict] = None) -> tokenVerificationResult:
  rate_limit()
  session = requests.Session()
  session.headers.update({
    'User-Agent': user_agent,
    'Accept': 'application/json',
  })
  if proxies:
    session.proxies.update(proxies)
    
  try:
    resp = session.get(
      f'{api_base}/api/v1/user',
      headers={'Authorization': f'Bearer {token}'},
      timeout=timeout
    )
    if resp.status_code == 200:
      data = resp.json()
      return tokenVerificationResult(
        valid = True,
        puid=data.get('puid'),
        name=data.get('name'),
        level=data.get('level'),
        friend_code=data.get('friendCode'),
        platform=data.get('lastPlatform'),
        cosmetics=data.get('cosmetics', []),
        raw_data=data,
      )
    elif resp.status_code == 401:
      raise InvalidTokenError('Token invalid or expired')
    elif resp.status_code == 403:
      raise AccountBannedError('Account banned or cloudflare block')
    elif resp.status_code == 429:
      raise RateLimitedError('Rate limit exceeded')
    else:
      raise AmongAPIError(f'HTTP {resp.status_code}')
  except requests.exceptions.Timeout:
    return tokenVerificationResult(valid=False, error='Connection timeout')
  except requests.exceptions.ConnectionError:
    return tokenVerificationResult(valid=False, error='Network error')
  except AmongAPIError as e:
    return tokenVerificationResult(valid=False, error=str(e))
  except Exception as e:
    return tokenVerificationResult(valid=False, error=f'Unexpected: {e}')
    
def get_public_profile(puid: str, proxies: Optional[Dict] = None) -> Optional[Dict]:
  rate_limit()
  headers = {'User-Agent': user_agent}
  try:
    resp = requests.get(
      f'{api_base}/api/v1/player/public/{puid}',
      headers=headers,
      proxies=proxies,
      timeout=10
    )
    return resp.json() if resp.status_code == 200 else None
  except:
    return None
    
def send_friend_request(token: str, target_puid: str, timeout: int = 10) -> bool:
  rate_limit()
  headers = {
    'Authorization': f'Bearer {token}',
    'User-Agent': user_agent,
    'Content-Type': 'application/json'
  }
  payload = {'puid': target_puid}
  try:
    resp = requests.post(
      f'{api_base}/api/v1/friendlist',
      headers=headers,
      json=payload,
      timeout=timeout
    )
    return resp.status_code == 200
  except:
    return False