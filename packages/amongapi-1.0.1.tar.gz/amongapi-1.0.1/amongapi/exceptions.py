class AmongAPIError(Exception):
  """Base exception for Among Us API errors..."""
  pass

class InvaildTokenError(AmongAPIError):
  pass

class AccountBannedError(AmongAPIError):
  pass

class RateLimitedError(AmongAPIError):
  pass

class LobbyJoinError(AmongAPIError):
  pass

class ChatMessageNotFound(AmongAPIError):
  pass