import asyncio
from typing import Optional, Dict, List, Callable, Awaitable
from enum import Enum

from amongus.client import Client
from amongus.events import on_game_state, on_player_info, on_meeting
from amongus.enums import GameState as AuGameState

class gamePhase(Enum):
  lobby = 'lobby'
  tasks = 'tasks'
  discussion = 'discussion'
  voting = 'voting'
  
class gameTracker:
  def __init__(self, region: str = 'North America', bot_name: str = 'AmongMute'):
    self.region = region
    self.bot_name = bot_name
    self.client: Optional[Client] = None
    self.phase: gamePhase = gamePhase.lobby
    self.players: Dict[str, Dict] = {}
    self._phase_callbacks: List[Callable[[gamePhase], Awaitable]] = []
    self._player_callbacks: List[Callable[[str, bool], Awaitable]] = []
    
  def on_phase_change(self, callback: Callable[[gamePhase], Awaitable]):
    self._phase_callbacks.append(callback)
    
  def on_player_state_change(self, callback: Callable[[str, bool], Awaitable]):
    self._player_callbacks_append(callback)
    
  async def handle_game_state(self, state: AuGameState):
    if state == AuGameState.lobby:
      new_phase = gamePhase.lobby
    elif state == AuGameState.tasks:
      new_phase = gamePhase.tasks
    elif state == AuGameState.discussion:
      new_phase = gamePhase.discussion
    elif state == AuGameState.voting:
      new_phase = gamePhase.voting
    else:
      return
    
    if new_phase != self.phase:
      self.phase = new_phase
      for cb in self._phase_callbacks:
        await cb(self.phase)
        
  async def handle_player_info(self, players: List):
    for p in players:
      name = p.name
      is_alive = not p.is_dead
      prev = self.players.get(name, {})
      prev_alive = prev.get('is_alive', True)
      self.players[name] = {
        'is_alive': is_alive,
        'is_impostor': p.is_impostor,
        'color': p.color.name if p.color else None
      }
      if is_alive != prev_alive:
        for cb in self._player_callbacks:
          await cb(name, is_alive)
  
  async def connect(self):
    self.client = Client(name=self.bot_name)
    self.client.on(on_game_state, self.handle_game_state)
    self.client.on(on_player_info, self.handle_player_info)
    await self.client.start(region=self.region)
  
  async def join_lobby(self, code: str) -> bool:
    if not self.client:
      return False
    try:
      return await self.client.join_lobby(code.upper())
    except:
      return False
      
  async def close(self):
    if self.client:
      await self.client.stop()
  
  def get_players_snapshot(self) -> List[Dict]:
    return [
      {'name': name, 'is_alive': data['is_alive']}
      for name, data in self.players.items()
    ]
    
    