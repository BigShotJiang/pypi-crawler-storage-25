from setuptools import setup, find_packages

with open('README.md', 'r') as fh:
  long_description = fh.read()
  
setup(
  name='amongapi',
  version='1.0.1',
  author='RawanF4X',
  description='Unofficial Among us API for AmongBot',
  long_description=long_description,
  long_description_content_type='text/markdown',
  url='https://github.com/RawanF4X/AmongAPI',
  packages=find_packages(),
  include_package_data=True,
  install_requires=[
    'requests>=2.28.0',
    'aiohttp>=3.8.0',
    'amongus>=0.0.0a0',
  ],
  classifiers=[
    'Programming Language :: Python :: 3',
    'License :: OSI Approved :: MIT License',
    'Operating System :: OS Independent',
  ],
  python_requires='>=3.8',
)