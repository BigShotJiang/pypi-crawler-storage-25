# Changelog

All notable changes to `aferiq-eval` (internal namespace: `rageval`).

This project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.1] — 2026-05-08

### Added
- **`aferiq init` CLI command** — interactive setup that drops the user from `pip install aferiq-eval` to first trace in seconds. Detects framework by scanning project imports (LangChain, LangGraph, CrewAI, LlamaIndex, Haystack, AutoGen, Pydantic AI, OpenAI/Anthropic SDKs), prompts for the API key via stdin (hidden, never as a CLI arg, never stored), writes/edits `.env` preserving existing variables, ensures `.env` is in `.gitignore`, and adds `import aferiq; aferiq.init()` to the detected entry point (`main.py` / `app.py` / `server.py` / etc) right after any module docstring or shebang. Idempotent — re-running is a safe no-op. Both `aferiq init` and `rageval init` resolve to the same command.
- **`aferiq.init(verbose=True, probe=True)`** — boot-time diagnostic. `verbose=True` (default) prints a 4-line summary on first init: state ✓/✗, endpoint, redact_pii flag, and probe status. `probe=True` (default) sends a HEAD request to the ingest URL and surfaces the result inline:
    ```
    [aferiq] ✓ tracing initialized
    [aferiq]   endpoint: https://aferiq.com.br/api/v1/traces
    [aferiq]   redact_pii: True (BR patterns)
    [aferiq]   workspace probe: 200 OK (key valid)
    ```
  Bad config surfaces immediately (`401 (key invalid or revoked)`, `404 (endpoint not found)`, `connection refused`, `timeout`) instead of silently dropping traces. Probe failures DO NOT prevent handler registration — the app keeps running normally with the standard per-trace warnings.
- New `aferiq` CLI entry point alongside `rageval` (both registered in `[project.scripts]`).
- 26 new tests across `test_cli_init.py` (env-file upsert, gitignore, prepend init, full CLI flow with `CliRunner`) and `TestVerboseAndProbe` in `test_cloud.py` (stdout assertions, probe status codes, network-error swallowing).

### Changed
- Existing init tests in `test_cloud.py` now pass `verbose=False, probe=False` so they stay silent and don't make network calls.

## [0.2.0] — 2026-05-08

### Added
- **Plug-and-play cloud setup** via `aferiq.init()` — collapses the 30+ lines of boilerplate (regex redactor + handler + httpx.post + register_trace_handler) that customers used to copy-paste into a single function call. Reads `AFERIQ_API_KEY` and `AFERIQ_INGEST_URL` from env, registers a default handler that POSTs traces with PII redaction by default, and is idempotent + no-op when env is missing. Full integration is now:
    ```python
    import aferiq
    aferiq.init()
    chain.invoke(input, config={"callbacks": [aferiq.handler()]})
    ```
- New top-level module `aferiq` (re-exports everything from `rageval`). Both `import aferiq` and `import rageval` work — `aferiq` is preferred going forward, matching the PyPI package name.
- `aferiq.handler()` factory — returns a fresh `RAGEvalCallbackHandler` per call (concurrent-safe).
- `aferiq.redact_pii_br(text)` — public BR-PII regex redactor (CPF/CNPJ/RG/CEP/email/phone). Idempotent, handles empty input.
- 20 new tests in `test_cloud.py` covering redactor, init lifecycle (env, kwargs, placeholder, idempotency), handler registration (EvalSample + AgentTrace serialization, network error swallowing, 4xx/5xx logging without raising), and handler factory.

### Changed
- Bump from 0.1.x to 0.2.0 because the new `init()` + `handler()` API is the recommended path going forward and changes the integration surface meaningfully (though `register_trace_handler` and `RAGEvalCallbackHandler` continue to work for users who want manual control).

## [0.1.1] — 2026-05-08

### Fixed
- `RAGEvalCallbackHandler` now emits traces reliably with **LCEL chains**. Previously, chains composed with `RunnableParallel` (e.g. `{"context": retriever | format_docs, "question": ...} | prompt | llm`) skipped emission because the handler required `on_retriever_end` to fire — which doesn't propagate consistently from inside a parallel map. The handler now tracks the outermost chain by `run_id` and emits on `on_chain_end`, with answer captured from `on_llm_end`/`on_chat_model_end` OR fallback-extracted from chain outputs.
- `RAGEvalCallbackHandler` now listens to `on_chat_model_end` (not just `on_llm_end`) so modern `ChatOpenAI` / `ChatAnthropic` integrations capture answers correctly.
- Empty/missing context no longer blocks emission. If `on_retriever_end` doesn't fire (LCEL nested case), the trace still goes through with `context=[]` — better than dropping the trace silently.

### Added
- `RAGEvalCallbackHandler.on_chain_error` resets internal state so a failed run doesn't poison the next one.
- Query extraction now also looks at `inputs["messages"]` (last message's `.content`) and accepts a raw string input for chat-style chains.

## [Unreleased]

### Added
- Agent eval support — `AgentTrace`, `AgentStep`, `evaluate_agent()` (alongside the existing single-turn `EvalSample` / `evaluate()` paths).
- `aferiq-trace-run` wrapper command. Auto-instruments OpenAI + Anthropic SDKs to capture tokens + latency per LLM call without touching application code.
- `AferiqAgentCallbackHandler` — single callback that captures full trajectories from LangChain `AgentExecutor` and LangGraph state machines.
- `AferiqAssistantHandler` — streaming event handler for OpenAI Assistants API.
- 4 agent metrics: `trajectory_quality`, `tool_use_correctness`, `goal_completion`, `cost_efficiency` (3 LLM-judged + 1 computational).
- New `prompts/` files (PT-BR + EN) for the agent metrics.
- `examples/` runnable demos for each integration path.

### Changed
- `TraceHandler` type widened to accept either `EvalSample` or `AgentTrace` (`Trace = Union[EvalSample, AgentTrace]`). Existing handlers keep working — the new shape only surfaces when an agent integration is active.
- `CloudClient.send` / `AsyncCloudClient.send` now dispatch by trace shape — RAG and agent traces serialise to different ingestion payloads.
- Hallucination judge prompt extended to emit per-claim `verdict` (grounded/partial/invented/contradicted) and `chunk_idx` (which retrieved chunk would have supported the claim, or null).

## [0.0.1] — 2026-05-06

### Added
- Single-turn RAG evaluation library (Brazilian Portuguese vertical).
- 3 metrics: `faithfulness`, `citation_accuracy`, `hallucination`.
- LangChain + LlamaIndex callback integrations.
- `@trace` decorator with auto-detection of common parameter names.
- `CloudClient` for shipping traces to the aferiq cloud API.
- CLI: `rageval evaluate --dataset traces.jsonl --metrics faithfulness`.
- Disk + memory caching backends.
