"""Tests for the plug-and-play cloud setup (aferiq.init / handler / redact)."""

from __future__ import annotations

from unittest.mock import patch

import httpx
import pytest

from rageval.agent import AgentStep, AgentTrace
from rageval.cloud import (
    _reset_for_testing,
    handler,
    init,
    redact_pii_br,
)
from rageval.integrations.langchain import RAGEvalCallbackHandler
from rageval.integrations.tracing import (
    _emit,
    _handlers,
    clear_trace_handlers,
)
from rageval.types import EvalSample


@pytest.fixture(autouse=True)
def _isolate(monkeypatch: pytest.MonkeyPatch) -> None:
    """Each test starts with no env vars, no handlers, init flag reset."""
    monkeypatch.delenv("AFERIQ_API_KEY", raising=False)
    monkeypatch.delenv("AFERIQ_INGEST_URL", raising=False)
    clear_trace_handlers()
    _reset_for_testing()
    yield
    clear_trace_handlers()
    _reset_for_testing()


class TestRedactPiiBr:
    def test_redacts_cpf(self) -> None:
        assert "[CPF]" in redact_pii_br("João, CPF 123.456.789-09")

    def test_redacts_cpf_unformatted(self) -> None:
        assert "[CPF]" in redact_pii_br("CPF 12345678909 do cliente")

    def test_redacts_cnpj(self) -> None:
        assert "[CNPJ]" in redact_pii_br("CNPJ 12.345.678/0001-90")

    def test_redacts_cep(self) -> None:
        assert "[CEP]" in redact_pii_br("CEP 01310-100, SP")

    def test_redacts_email(self) -> None:
        assert "[EMAIL]" in redact_pii_br("contato leo94pena@gmail.com")

    def test_redacts_phone(self) -> None:
        assert "[PHONE]" in redact_pii_br("Tel (11) 91234-5678")

    def test_empty_passes_through(self) -> None:
        assert redact_pii_br("") == ""

    def test_idempotent(self) -> None:
        once = redact_pii_br("CPF 123.456.789-09")
        twice = redact_pii_br(once)
        assert once == twice

    def test_multiple_in_one_string(self) -> None:
        text = "João (CPF 123.456.789-09, CEP 01310-100) email j@x.com"
        out = redact_pii_br(text)
        assert "[CPF]" in out
        assert "[CEP]" in out
        assert "[EMAIL]" in out


class TestInit:
    def test_no_env_returns_false_no_handler(self) -> None:
        result = init(verbose=False)
        assert result is False
        assert len(_handlers) == 0

    def test_explicit_kwargs_override_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("AFERIQ_API_KEY", "rg_pk_live_envvalue")
        monkeypatch.setenv("AFERIQ_INGEST_URL", "https://from.env/api/v1/traces")
        result = init(
            api_key="rg_pk_live_explicit",
            ingest_url="https://explicit/api/v1/traces",
            verbose=False,
            probe=False,
        )
        assert result is True
        assert len(_handlers) == 1

    def test_placeholder_key_returns_false(self) -> None:
        result = init(
            api_key="rg_pk_live_<COLOQUE_AQUI>",
            ingest_url="https://x/api/v1/traces",
            verbose=False,
        )
        assert result is False
        assert len(_handlers) == 0

    def test_idempotent(self) -> None:
        init(
            api_key="rg_pk_live_real",
            ingest_url="https://x/api/v1/traces",
            verbose=False,
            probe=False,
        )
        init(
            api_key="rg_pk_live_real",
            ingest_url="https://x/api/v1/traces",
            verbose=False,
            probe=False,
        )
        init(
            api_key="rg_pk_live_real",
            ingest_url="https://x/api/v1/traces",
            verbose=False,
            probe=False,
        )
        assert len(_handlers) == 1

    def test_reads_env_when_not_passed(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("AFERIQ_API_KEY", "rg_pk_live_real")
        monkeypatch.setenv(
            "AFERIQ_INGEST_URL", "https://prod.com/api/v1/traces"
        )
        result = init(verbose=False, probe=False)
        assert result is True
        assert len(_handlers) == 1


class TestVerboseAndProbe:
    """verbose=True prints the 4-line summary; probe=True validates key."""

    def test_verbose_prints_summary_on_success(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        with patch.object(httpx, "head") as mock_head:
            mock_head.return_value = httpx.Response(200, text="")
            init(
                api_key="rg_pk_live_real",
                ingest_url="https://prod.com/api/v1/traces",
                verbose=True,
                probe=True,
            )
        out = capsys.readouterr().out
        assert "[aferiq] ✓ tracing initialized" in out
        assert "endpoint: https://prod.com/api/v1/traces" in out
        assert "redact_pii: True" in out
        assert "200 OK (key valid)" in out

    def test_verbose_prints_disabled_on_missing_config(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        init(verbose=True, probe=False)
        out = capsys.readouterr().out
        assert "[aferiq] ✗ tracing DISABLED" in out

    def test_verbose_prints_placeholder_warning(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        init(
            api_key="rg_pk_live_<COLE_AQUI>",
            ingest_url="https://x/api/v1/traces",
            verbose=True,
        )
        out = capsys.readouterr().out
        assert "DISABLED" in out
        assert "placeholder" in out.lower()

    def test_probe_401_surfaces_in_summary(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        with patch.object(httpx, "head") as mock_head:
            mock_head.return_value = httpx.Response(401, text="invalid_key")
            init(
                api_key="rg_pk_live_revoked",
                ingest_url="https://prod.com/api/v1/traces",
                verbose=True,
                probe=True,
            )
        out = capsys.readouterr().out
        assert "401" in out
        assert "invalid or revoked" in out

    def test_probe_405_treated_as_healthy(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        # Many APIs return 405 Method Not Allowed for HEAD on POST-only routes.
        # That's fine — the endpoint exists; the POST will work in prod.
        with patch.object(httpx, "head") as mock_head:
            mock_head.return_value = httpx.Response(405, text="")
            init(
                api_key="rg_pk_live_real",
                ingest_url="https://prod.com/api/v1/traces",
                verbose=True,
                probe=True,
            )
        out = capsys.readouterr().out
        assert "405" in out
        assert "endpoint reachable" in out

    def test_probe_network_error_does_not_raise(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        with patch.object(httpx, "head", side_effect=httpx.ConnectError("boom")):
            result = init(
                api_key="rg_pk_live_real",
                ingest_url="https://prod.com/api/v1/traces",
                verbose=True,
                probe=True,
            )
        # init still returned True — handler registered, app keeps going.
        assert result is True
        out = capsys.readouterr().out
        assert "connection refused" in out

    def test_verbose_false_silent(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        with patch.object(httpx, "head") as mock_head:
            mock_head.return_value = httpx.Response(200, text="")
            init(
                api_key="rg_pk_live_real",
                ingest_url="https://prod.com/api/v1/traces",
                verbose=False,
                probe=True,
            )
        assert capsys.readouterr().out == ""

    def test_probe_false_skips_network_call(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        with patch.object(httpx, "head") as mock_head:
            init(
                api_key="rg_pk_live_real",
                ingest_url="https://prod.com/api/v1/traces",
                verbose=True,
                probe=False,
            )
            mock_head.assert_not_called()
        out = capsys.readouterr().out
        assert "skipped" in out


class TestHandlerRegistration:
    """The handler registered by init() POSTs samples to the ingest URL."""

    def test_eval_sample_redacted_and_posted(self) -> None:
        init(
            api_key="rg_pk_live_real",
            ingest_url="https://prod.com/api/v1/traces",
            verbose=False,
            probe=False,
        )

        sample = EvalSample(
            query="João da Silva, CPF 123.456.789-09, qual o prazo?",
            context=["Art. 49 do CDC: 7 dias"],
            answer="7 dias.",
        )

        with patch.object(httpx, "post") as mock_post:
            mock_post.return_value = httpx.Response(200, text="ok")
            _emit(sample)

        mock_post.assert_called_once()
        kwargs = mock_post.call_args.kwargs
        assert kwargs["json"]["query"] == "João da Silva, CPF [CPF], qual o prazo?"
        assert kwargs["headers"]["Authorization"] == "Bearer rg_pk_live_real"

    def test_redact_false_sends_raw(self) -> None:
        init(
            api_key="rg_pk_live_real",
            ingest_url="https://prod.com/api/v1/traces",
            redact=False,
        )

        sample = EvalSample(
            query="CPF 123.456.789-09",
            context=["x"],
            answer="y",
        )

        with patch.object(httpx, "post") as mock_post:
            mock_post.return_value = httpx.Response(200, text="ok")
            _emit(sample)

        kwargs = mock_post.call_args.kwargs
        assert kwargs["json"]["query"] == "CPF 123.456.789-09"

    def test_handler_swallows_network_errors(self) -> None:
        init(
            api_key="rg_pk_live_real",
            ingest_url="https://prod.com/api/v1/traces",
            verbose=False,
            probe=False,
        )

        sample = EvalSample(query="q", context=["c"], answer="a")

        with patch.object(httpx, "post", side_effect=httpx.ConnectError("boom")):
            # Must not raise — telemetry failures cannot break user requests.
            _emit(sample)

    def test_handler_logs_4xx_5xx_but_does_not_raise(self) -> None:
        init(
            api_key="rg_pk_live_real",
            ingest_url="https://prod.com/api/v1/traces",
            verbose=False,
            probe=False,
        )

        sample = EvalSample(query="q", context=["c"], answer="a")

        with patch.object(httpx, "post") as mock_post:
            mock_post.return_value = httpx.Response(500, text="ingest_failed")
            # Must not raise — server errors are logged but not propagated.
            _emit(sample)

    def test_agent_trace_serialized(self) -> None:
        init(
            api_key="rg_pk_live_real",
            ingest_url="https://prod.com/api/v1/traces",
        )

        agent_trace = AgentTrace(
            trace_id="abc",
            goal="achar prazo CDC pra CPF 123.456.789-09",
            final_answer="7 dias",
            steps=[
                AgentStep(
                    step_index=0,
                    step_type="llm",
                    step_input="pergunta original",
                    step_output="vou buscar CDC",
                ),
            ],
            tool_specs=[],
        )

        with patch.object(httpx, "post") as mock_post:
            mock_post.return_value = httpx.Response(200, text="ok")
            _emit(agent_trace)

        kwargs = mock_post.call_args.kwargs
        body = kwargs["json"]
        assert body["trace_id"] == "abc"
        assert body["goal"] == "achar prazo CDC pra CPF [CPF]"
        assert body["final_answer"] == "7 dias"
        assert len(body["steps"]) == 1


class TestHandlerFactory:
    def test_returns_fresh_callback_each_call(self) -> None:
        h1 = handler()
        h2 = handler()
        assert isinstance(h1, RAGEvalCallbackHandler)
        assert isinstance(h2, RAGEvalCallbackHandler)
        assert h1 is not h2  # fresh instances — concurrent isolation
