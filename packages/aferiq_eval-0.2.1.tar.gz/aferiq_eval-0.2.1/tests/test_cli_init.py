"""Tests for the `aferiq init` / `rageval init` CLI subcommand.

Uses Typer's CliRunner with a tmp_path project so each test starts with a
clean filesystem. We don't make real network calls — the init command
itself doesn't probe; that's the SDK's `aferiq.init(probe=True)` job.
"""

from __future__ import annotations

from pathlib import Path

import pytest
from typer.testing import CliRunner

from rageval.cli import app
from rageval.cli_init import _ensure_gitignored, _prepend_init, _upsert_env_var

runner = CliRunner()


class TestUpsertEnvVar:
    def test_creates_file_when_missing(self, tmp_path: Path) -> None:
        env = tmp_path / ".env"
        _upsert_env_var(env, "AFERIQ_API_KEY", "rg_pk_live_123")
        assert env.read_text() == "AFERIQ_API_KEY=rg_pk_live_123\n"

    def test_appends_when_var_missing(self, tmp_path: Path) -> None:
        env = tmp_path / ".env"
        env.write_text("OPENAI_API_KEY=sk-real\n")
        _upsert_env_var(env, "AFERIQ_API_KEY", "rg_pk_live_123")
        text = env.read_text()
        assert "OPENAI_API_KEY=sk-real" in text
        assert "AFERIQ_API_KEY=rg_pk_live_123" in text

    def test_replaces_when_var_present(self, tmp_path: Path) -> None:
        env = tmp_path / ".env"
        env.write_text(
            "OPENAI_API_KEY=sk-real\nAFERIQ_API_KEY=rg_pk_live_<COLE_AQUI>\n"
        )
        _upsert_env_var(env, "AFERIQ_API_KEY", "rg_pk_live_real")
        text = env.read_text()
        # Existing OPENAI_API_KEY preserved.
        assert "OPENAI_API_KEY=sk-real" in text
        # AFERIQ_API_KEY replaced (no two copies).
        assert text.count("AFERIQ_API_KEY=") == 1
        assert "rg_pk_live_real" in text
        assert "<COLE_AQUI>" not in text

    def test_handles_no_trailing_newline(self, tmp_path: Path) -> None:
        env = tmp_path / ".env"
        env.write_text("OPENAI_API_KEY=sk-real")  # no \n at end
        _upsert_env_var(env, "AFERIQ_API_KEY", "rg_pk_live_123")
        assert env.read_text() == (
            "OPENAI_API_KEY=sk-real\nAFERIQ_API_KEY=rg_pk_live_123\n"
        )


class TestEnsureGitignored:
    def test_creates_gitignore_when_missing(self, tmp_path: Path) -> None:
        gi = tmp_path / ".gitignore"
        _ensure_gitignored(gi, ".env")
        assert gi.read_text() == ".env\n"

    def test_appends_when_pattern_missing(self, tmp_path: Path) -> None:
        gi = tmp_path / ".gitignore"
        gi.write_text("__pycache__/\n*.pyc\n")
        _ensure_gitignored(gi, ".env")
        text = gi.read_text()
        assert "__pycache__/" in text
        assert ".env" in text

    def test_no_op_when_already_present(self, tmp_path: Path) -> None:
        gi = tmp_path / ".gitignore"
        gi.write_text("__pycache__/\n.env\n*.pyc\n")
        before = gi.read_text()
        _ensure_gitignored(gi, ".env")
        # No duplicate entry added.
        assert gi.read_text() == before


class TestPrependInit:
    def test_prepends_at_top_of_simple_file(self, tmp_path: Path) -> None:
        f = tmp_path / "main.py"
        f.write_text("from fastapi import FastAPI\napp = FastAPI()\n")
        _prepend_init(f)
        text = f.read_text()
        # The init block lives before the original imports.
        assert text.index("import aferiq") < text.index("from fastapi")
        assert "aferiq.init()" in text

    def test_prepends_after_module_docstring(self, tmp_path: Path) -> None:
        f = tmp_path / "main.py"
        f.write_text(
            '"""My RAG app."""\nfrom fastapi import FastAPI\napp = FastAPI()\n'
        )
        _prepend_init(f)
        text = f.read_text()
        # Docstring stays at line 0.
        assert text.startswith('"""My RAG app."""')
        # Init is after docstring but before fastapi import.
        assert text.index("aferiq.init()") < text.index("from fastapi")
        assert text.index('"""My RAG app."""') < text.index("import aferiq")

    def test_prepends_after_shebang(self, tmp_path: Path) -> None:
        f = tmp_path / "main.py"
        f.write_text("#!/usr/bin/env python\nfrom fastapi import FastAPI\n")
        _prepend_init(f)
        text = f.read_text()
        assert text.startswith("#!/usr/bin/env python")
        assert text.index("import aferiq") > text.index("#!/")
        assert text.index("import aferiq") < text.index("from fastapi")


class TestInitCommand:
    def test_writes_env_with_placeholder_when_yes(self, tmp_path: Path) -> None:
        result = runner.invoke(
            app,
            [
                "init",
                "--project",
                str(tmp_path),
                "--ingest-url",
                "https://example.com/api/v1/traces",
                "--yes",
            ],
        )
        assert result.exit_code == 0
        env_text = (tmp_path / ".env").read_text()
        assert "AFERIQ_API_KEY=rg_pk_live_<COLOQUE_AQUI>" in env_text
        assert "AFERIQ_INGEST_URL=https://example.com/api/v1/traces" in env_text

    def test_writes_env_example(self, tmp_path: Path) -> None:
        runner.invoke(
            app,
            [
                "init",
                "--project",
                str(tmp_path),
                "--ingest-url",
                "https://example.com/api/v1/traces",
                "--yes",
            ],
        )
        example = (tmp_path / ".env.example").read_text()
        assert "AFERIQ_API_KEY=rg_pk_live_<COLOQUE_AQUI>" in example

    def test_creates_gitignore_with_env(self, tmp_path: Path) -> None:
        runner.invoke(
            app,
            [
                "init",
                "--project",
                str(tmp_path),
                "--ingest-url",
                "https://example.com/api/v1/traces",
                "--yes",
            ],
        )
        gi = (tmp_path / ".gitignore").read_text()
        assert ".env" in gi

    def test_preserves_existing_env_vars(self, tmp_path: Path) -> None:
        (tmp_path / ".env").write_text(
            "OPENAI_API_KEY=sk-mine\nDATABASE_URL=postgres://local\n"
        )
        runner.invoke(
            app,
            [
                "init",
                "--project",
                str(tmp_path),
                "--ingest-url",
                "https://example.com/api/v1/traces",
                "--yes",
            ],
        )
        text = (tmp_path / ".env").read_text()
        assert "OPENAI_API_KEY=sk-mine" in text
        assert "DATABASE_URL=postgres://local" in text
        assert "AFERIQ_API_KEY=" in text
        assert "AFERIQ_INGEST_URL=" in text

    def test_modifies_main_py_when_present(self, tmp_path: Path) -> None:
        (tmp_path / "main.py").write_text(
            '"""Bot entry."""\nfrom fastapi import FastAPI\napp = FastAPI()\n'
        )
        runner.invoke(
            app,
            [
                "init",
                "--project",
                str(tmp_path),
                "--ingest-url",
                "https://example.com/api/v1/traces",
                "--yes",
            ],
        )
        main_text = (tmp_path / "main.py").read_text()
        assert "aferiq.init()" in main_text

    def test_idempotent_on_main_py(self, tmp_path: Path) -> None:
        (tmp_path / "main.py").write_text(
            "import aferiq\naferiq.init()\nfrom fastapi import FastAPI\n"
        )
        before = (tmp_path / "main.py").read_text()
        runner.invoke(
            app,
            [
                "init",
                "--project",
                str(tmp_path),
                "--ingest-url",
                "https://example.com/api/v1/traces",
                "--yes",
            ],
        )
        after = (tmp_path / "main.py").read_text()
        assert before == after  # second init is a no-op on the source file

    def test_rejects_invalid_key_format(self, tmp_path: Path) -> None:
        # When user provides a non-rg_pk_live_… key, command exits 2.
        result = runner.invoke(
            app,
            [
                "init",
                "--project",
                str(tmp_path),
                "--ingest-url",
                "https://example.com/api/v1/traces",
            ],
            input="not-a-real-key\n",
        )
        assert result.exit_code == 2

    def test_fails_on_missing_project_dir(self, tmp_path: Path) -> None:
        result = runner.invoke(
            app,
            [
                "init",
                "--project",
                str(tmp_path / "does_not_exist"),
                "--yes",
            ],
        )
        assert result.exit_code == 2
