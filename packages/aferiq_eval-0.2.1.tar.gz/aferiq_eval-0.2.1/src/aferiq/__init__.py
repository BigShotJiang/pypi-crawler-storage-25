"""aferiq — public name for the rageval SDK.

This module re-exports everything from ``rageval`` so users can write the
canonical plug-and-play setup::

    import aferiq
    aferiq.init()
    chain.invoke(input, config={"callbacks": [aferiq.handler()]})

Both ``import aferiq`` and ``import rageval`` work — they refer to the
same code. ``aferiq`` is the preferred name going forward, matching the
PyPI package (``pip install aferiq-eval``) and the dashboard URL.

Backwards compatibility: existing code that imports ``rageval`` (or any
of its submodules) keeps working — the rename is purely additive.
"""

from __future__ import annotations

# Re-export the entire public surface of rageval. Anything in `__all__`
# from `rageval.__init__` becomes available as `aferiq.<name>`.
from rageval import (
    AgentEvalResult,
    AgentStep,
    AgentTrace,
    AgentTraceResult,
    AsyncCloudClient,
    CloudClient,
    EvalResult,
    EvalSample,
    MetricScore,
    SampleResult,
    StepType,
    Trace,
    __version__,
    aevaluate,
    aevaluate_agent,
    aevaluate_samples,
    clear_trace_handlers,
    evaluate,
    evaluate_agent,
    evaluate_samples,
    handler,
    init,
    redact_pii_br,
    register_trace_handler,
    trace,
)

__all__ = [
    "AgentEvalResult",
    "AgentStep",
    "AgentTrace",
    "AgentTraceResult",
    "AsyncCloudClient",
    "CloudClient",
    "EvalResult",
    "EvalSample",
    "MetricScore",
    "SampleResult",
    "StepType",
    "Trace",
    "__version__",
    "aevaluate",
    "aevaluate_agent",
    "aevaluate_samples",
    "clear_trace_handlers",
    "evaluate",
    "evaluate_agent",
    "evaluate_samples",
    "handler",
    "init",
    "redact_pii_br",
    "register_trace_handler",
    "trace",
]
