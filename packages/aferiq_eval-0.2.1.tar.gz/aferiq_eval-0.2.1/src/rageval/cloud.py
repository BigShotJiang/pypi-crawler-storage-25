"""Plug-and-play setup for sending traces to the aferiq cloud.

This module collapses the boilerplate that customers used to copy-paste
(regex redactor + httpx.post handler + register_trace_handler call) into
a single ``init()`` call. The full integration becomes::

    # .env
    AFERIQ_API_KEY=rg_pk_live_...
    AFERIQ_INGEST_URL=https://...

    # In your app's entry point
    import aferiq
    aferiq.init()

    # On each chain invocation
    chain.invoke(input, config={"callbacks": [aferiq.handler()]})

Public API:
    init(api_key=None, ingest_url=None, redact=True, timeout=5.0) -> None
    handler() -> RAGEvalCallbackHandler
    redact_pii_br(text: str) -> str

``init()`` is idempotent and a no-op when env vars are missing or when the
API key is a placeholder — safe to leave in code without breaking dev/test
environments.
"""

from __future__ import annotations

import logging
import os
import re
from typing import Any

import httpx

from rageval.agent import AgentTrace
from rageval.integrations.langchain import RAGEvalCallbackHandler
from rageval.integrations.tracing import register_trace_handler
from rageval.types import EvalSample

_logger = logging.getLogger("rageval.cloud")
_initialized = False

# Brazilian PII patterns. Order matters: longer/more-specific patterns first
# so partial matches don't get consumed by a more permissive regex.
_DEFAULT_REDACTORS: list[tuple[re.Pattern[str], str]] = [
    # CNPJ: 12.345.678/0001-90 (more specific than CPF — match first)
    (re.compile(r"\b\d{2}\.?\d{3}\.?\d{3}/?\d{4}-?\d{2}\b"), "[CNPJ]"),
    # CPF: 123.456.789-09
    (re.compile(r"\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b"), "[CPF]"),
    # RG: 12.345.678-9 or 12.345.678-X (X is checksum digit, can be alpha)
    (re.compile(r"\b\d{1,2}\.?\d{3}\.?\d{3}-?[\dxX]\b"), "[RG]"),
    # CEP: 01310-100 or 01310100
    (re.compile(r"\b\d{5}-?\d{3}\b"), "[CEP]"),
    # Email
    (re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b"), "[EMAIL]"),
    # Brazilian phone: (11) 91234-5678, 11912345678, +55 11 91234-5678
    (re.compile(r"\(?\b\d{2}\)?\s?9?\d{4}-?\d{4}\b"), "[PHONE]"),
]


def redact_pii_br(text: str) -> str:
    """Redact common Brazilian PII patterns from a string.

    Replaces CPF, CNPJ, RG, CEP, email, and phone numbers with bracketed
    labels. Idempotent (calling twice does not double-redact).

    Args:
        text: Input string to redact. Empty/None passes through unchanged.

    Returns:
        Redacted string with each PII pattern replaced by ``[CPF]``,
        ``[CNPJ]``, ``[RG]``, ``[CEP]``, ``[EMAIL]``, or ``[PHONE]``.
    """
    if not text:
        return text
    for pattern, repl in _DEFAULT_REDACTORS:
        text = pattern.sub(repl, text)
    return text


def init(
    *,
    api_key: str | None = None,
    ingest_url: str | None = None,
    redact: bool = True,
    timeout: float = 5.0,
    verbose: bool = True,
    probe: bool = True,
) -> bool:
    """Configure aferiq cloud tracing in one line.

    Reads ``AFERIQ_API_KEY`` and ``AFERIQ_INGEST_URL`` from environment if
    not passed explicitly. Registers a trace handler that POSTs every
    captured sample to the ingest endpoint with PII redaction enabled by
    default.

    No-op (returns ``False``) if API key or ingest URL are missing or the
    key looks like a placeholder. This makes ``init()`` safe to call
    unconditionally in dev / test where env vars may be absent — your app
    keeps running with zero traces sent.

    Idempotent: only one handler is registered no matter how many times
    you call this.

    Args:
        api_key: Override AFERIQ_API_KEY env var. Format: ``rg_pk_live_…``.
        ingest_url: Override AFERIQ_INGEST_URL env var. Full URL ending in
            ``/api/v1/traces``.
        redact: Apply Brazilian PII regex (CPF/CNPJ/RG/CEP/email/phone)
            before posting. Default ``True``. Set ``False`` only if you
            already redact upstream OR are testing in a clean env.
        timeout: Per-POST HTTP timeout in seconds. Default 5.0 — kept short
            so tracing doesn't slow down user-facing requests.
        verbose: Print a 4-line setup summary to stdout on first call.
            Useful for sanity-checking env wiring during boot. Default
            ``True``. Set ``False`` for headless services where stdout
            should stay empty.
        probe: Send a no-op OPTIONS / HEAD request to ``ingest_url`` to
            validate the key + endpoint at boot time. Default ``True``.
            Bad config (revoked key, wrong URL, network down) surfaces
            immediately instead of silently dropping traces. Probe failures
            do NOT prevent the handler from being registered — your app
            keeps trying to post real traces, with their normal warnings.

    Returns:
        ``True`` if a handler was registered (config valid),
        ``False`` if init was skipped (missing config or placeholder key).
    """
    global _initialized
    if _initialized:
        return True  # already done — keep silent

    api_key = api_key or os.getenv("AFERIQ_API_KEY", "")
    ingest_url = ingest_url or os.getenv("AFERIQ_INGEST_URL", "")

    if not api_key or not ingest_url:
        _logger.info(
            "[aferiq] tracing disabled — set AFERIQ_API_KEY and "
            "AFERIQ_INGEST_URL in env to enable cloud traces."
        )
        if verbose:
            _print_status(
                ok=False,
                ingest_url=ingest_url or "(unset)",
                redact=redact,
                probe_status="skipped (config missing)",
            )
        return False

    if api_key.startswith("rg_pk_live_<") or "<COLE" in api_key.upper():
        _logger.warning(
            "[aferiq] tracing disabled — AFERIQ_API_KEY looks like a "
            "placeholder. Update .env with the real value from your "
            "dashboard's /dashboard/api-keys page."
        )
        if verbose:
            _print_status(
                ok=False,
                ingest_url=ingest_url,
                redact=redact,
                probe_status="skipped (placeholder key)",
            )
        return False

    handler_fn = _build_handler(api_key, ingest_url, redact, timeout)
    register_trace_handler(handler_fn)
    _initialized = True

    probe_status = "skipped"
    if probe:
        probe_status = _probe_ingest(api_key, ingest_url, timeout)

    _logger.info(
        "[aferiq] tracing initialized → %s (redact_pii=%s)",
        ingest_url, redact,
    )
    if verbose:
        _print_status(
            ok=True,
            ingest_url=ingest_url,
            redact=redact,
            probe_status=probe_status,
        )
    return True


def _probe_ingest(api_key: str, ingest_url: str, timeout: float) -> str:
    """Send a HEAD request to the ingest endpoint and return a one-word
    status describing what we got back. Used by the boot summary.

    Failure modes are friendly text, not exceptions — probe is purely
    informational and must never crash the user's app.
    """
    try:
        response = httpx.head(
            ingest_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=timeout,
        )
        if response.status_code == 200:
            return "200 OK (key valid)"
        if response.status_code == 401:
            return "401 (key invalid or revoked — generate a new one)"
        if response.status_code == 405:
            # Endpoint exists but doesn't accept HEAD — that's fine, the
            # POST handler is what actually runs in prod. Treat as healthy.
            return "405 (endpoint reachable; POST handler will accept)"
        if response.status_code == 404:
            return "404 (endpoint not found — check AFERIQ_INGEST_URL)"
        return f"{response.status_code} (unexpected — check dashboard)"
    except httpx.ConnectError:
        return "connection refused (DNS or network down)"
    except httpx.TimeoutException:
        return f"timeout after {timeout}s (network or server slow)"
    except Exception as exc:  # noqa: BLE001 — probe must never raise
        return f"error: {type(exc).__name__}"


def _print_status(
    *, ok: bool, ingest_url: str, redact: bool, probe_status: str
) -> None:
    """Render the 4-line setup summary to stdout. Plain text, no rich/colors —
    works in CI logs, Docker, and IDE consoles uniformly.
    """
    marker = "✓" if ok else "✗"
    state = "tracing initialized" if ok else "tracing DISABLED"
    print(f"[aferiq] {marker} {state}")
    print(f"[aferiq]   endpoint: {ingest_url}")
    print(f"[aferiq]   redact_pii: {redact} (BR patterns)")
    print(f"[aferiq]   workspace probe: {probe_status}")


def handler() -> RAGEvalCallbackHandler:
    """Return a fresh LangChain callback handler.

    Each call returns a NEW instance. Pass per chain invocation so concurrent
    requests don't share state::

        chain.invoke(input, config={"callbacks": [aferiq.handler()]})

    The handler captures (query, context, answer) from the chain run and
    emits via the trace handler registry — so :func:`init` must be called
    first for the trace to actually reach the cloud.
    """
    return RAGEvalCallbackHandler()


def _is_initialized() -> bool:
    """Test helper — exposed for tests to assert state, not for users."""
    return _initialized


def _reset_for_testing() -> None:
    """Test helper only — resets the init flag so tests can re-init."""
    global _initialized
    _initialized = False


def _build_handler(
    api_key: str,
    ingest_url: str,
    redact: bool,
    timeout: float,
) -> Any:
    """Closure over (api_key, ingest_url, redact, timeout) → trace handler.

    Returns a callable suitable for ``register_trace_handler``. The closure
    pattern keeps the API key out of any module-level mutable state.
    """

    def _do_redact(text: str) -> str:
        return redact_pii_br(text) if redact else text

    def _post(trace: Any) -> None:
        try:
            payload = _trace_to_payload(trace, _do_redact)
            if payload is None:
                return
            response = httpx.post(
                ingest_url,
                headers={"Authorization": f"Bearer {api_key}"},
                json=payload,
                timeout=timeout,
            )
            if response.status_code >= 400:
                _logger.warning(
                    "[aferiq] ingest returned %s: %s",
                    response.status_code,
                    response.text[:200],
                )
            else:
                _logger.info("[aferiq] trace posted")
        except Exception as exc:  # noqa: BLE001 — never break user's request flow
            _logger.warning("[aferiq] failed to post trace: %s", exc)

    return _post


def _trace_to_payload(trace: Any, redact_fn: Any) -> dict[str, Any] | None:
    """Serialize a trace shape into the ingest endpoint's JSON payload.

    Supports both single-turn ``EvalSample`` (RAG) and multi-step
    ``AgentTrace`` (agentic). Returns None for unknown shapes (logged as a
    warning by the caller's exception path).
    """
    if isinstance(trace, EvalSample):
        return {
            "query": redact_fn(trace.query),
            "context": [redact_fn(c) for c in trace.context],
            "answer": redact_fn(trace.answer),
        }
    if isinstance(trace, AgentTrace):
        return {
            "trace_id": trace.trace_id,
            "goal": redact_fn(trace.goal or ""),
            "final_answer": redact_fn(trace.final_answer or ""),
            "steps": [
                {
                    **step.model_dump(),
                    "step_input": redact_fn(str(step.step_input or "")),
                    "step_output": redact_fn(str(step.step_output or "")),
                }
                for step in trace.steps
            ],
            "tool_specs": trace.tool_specs,
        }
    _logger.warning(
        "[aferiq] unknown trace shape, skipping post: %s", type(trace).__name__
    )
    return None
