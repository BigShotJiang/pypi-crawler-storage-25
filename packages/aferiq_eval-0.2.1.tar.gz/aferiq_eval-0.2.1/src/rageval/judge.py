"""LLM-as-judge abstraction.

Default uses litellm (any model: OpenAI, Anthropic, Google, Maritaca, Ollama).
Dependency-injection friendly: pass ``judge_fn`` for tests or custom backends.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any

from rageval.cache import Cache, NullCache

JudgeFn = Callable[[str, str, float], str]
"""Sync judge signature: (prompt, model, temperature) -> raw response content."""

AsyncJudgeFn = Callable[[str, str, float], Awaitable[str]]
"""Async judge signature: (prompt, model, temperature) -> awaitable raw response."""


def litellm_judge(prompt: str, model: str, temperature: float) -> str:
    """Default sync judge — calls ``litellm.completion``."""
    import litellm  # local import keeps import-time light

    response: Any = litellm.completion(
        model=model,
        messages=[{"role": "user", "content": prompt}],
        temperature=temperature,
    )
    content = response.choices[0].message.content
    return content if isinstance(content, str) else ""


async def litellm_judge_async(prompt: str, model: str, temperature: float) -> str:
    """Default async judge — calls ``litellm.acompletion``."""
    import litellm

    response: Any = await litellm.acompletion(
        model=model,
        messages=[{"role": "user", "content": prompt}],
        temperature=temperature,
    )
    content = response.choices[0].message.content
    return content if isinstance(content, str) else ""


@dataclass
class Judge:
    """Synchronous judge with caching.

    Defaults to ``gpt-4o-mini`` at temperature 0 with ``NullCache`` (no cache).
    Pass ``cache=DiskCache()`` to enable persistent caching.
    """

    model: str = "gpt-4o-mini"
    temperature: float = 0.0
    judge_fn: JudgeFn = field(default=litellm_judge)
    cache: Cache = field(default_factory=NullCache)

    def __call__(self, prompt: str) -> str:
        cached = self.cache.get(prompt, self.model, self.temperature)
        if cached is not None:
            return cached
        response = self.judge_fn(prompt, self.model, self.temperature)
        self.cache.set(prompt, self.model, self.temperature, response)
        return response


@dataclass
class AsyncJudge:
    """Asynchronous judge with caching.

    Same shape as ``Judge`` but ``judge_fn`` returns an awaitable.
    """

    model: str = "gpt-4o-mini"
    temperature: float = 0.0
    judge_fn: AsyncJudgeFn = field(default=litellm_judge_async)
    cache: Cache = field(default_factory=NullCache)

    async def __call__(self, prompt: str) -> str:
        cached = self.cache.get(prompt, self.model, self.temperature)
        if cached is not None:
            return cached
        response = await self.judge_fn(prompt, self.model, self.temperature)
        self.cache.set(prompt, self.model, self.temperature, response)
        return response
