"""Agent callback handler — works with LangChain AgentExecutor and LangGraph.

Both frameworks emit ``langchain_core.callbacks.BaseCallbackHandler`` events,
so a single handler covers both. Captures the full trajectory (agent
decisions + tool calls) into an ``AgentTrace`` and emits it via the trace
handler registry when the chain finishes.

LLM-call tokens + latency are captured separately by the OpenAI/Anthropic
SDK monkey patches activated by ``aferiq-trace-run`` — this handler only
records the agent_action and tool steps. Run with::

    aferiq-trace-run python my_agent.py

so the LLM steps merge into the trajectory naturally.

Usage::

    from rageval.integrations.agent_callback import AferiqAgentCallbackHandler

    handler = AferiqAgentCallbackHandler(goal="Qual o prazo do CDC?")
    agent_executor.invoke(
        {"input": "Qual o prazo do CDC?"},
        config={"callbacks": [handler]},
    )
    # handler.last_trace is the AgentTrace, also broadcast to registered handlers
"""

from __future__ import annotations

import logging
from typing import Any

try:
    from langchain_core.callbacks import BaseCallbackHandler
except ImportError as e:  # pragma: no cover
    raise ImportError(
        "rageval.integrations.agent_callback requires langchain-core. "
        "Install with: pip install langchain-core (also covers LangGraph)."
    ) from e

from rageval.agent import AgentTrace
from rageval.integrations._context import (
    end_trajectory,
    record_step,
    start_trajectory,
)
from rageval.integrations.tracing import _emit_trace

_log = logging.getLogger(__name__)


class AferiqAgentCallbackHandler(BaseCallbackHandler):
    """Captures an agent run as an ``AgentTrace`` (multi-step trajectory).

    Hooks:
        - ``on_chain_start`` (top-level): begin trajectory with detected goal
        - ``on_agent_action``: record an "agent_action" step (LLM picked a tool)
        - ``on_tool_end``: record a "tool" step (tool returned)
        - ``on_chain_end`` (top-level): finalise trajectory + emit
        - ``on_chain_error`` (top-level): finalise with no final_answer + emit

    Concurrent runs in the same handler instance are not isolated — instantiate
    one handler per logical agent invocation if you call ``invoke`` in
    parallel from multiple threads. (The underlying ContextVar trajectory
    state is async-task-isolated, but this handler's ``_depth`` counter is not.)
    """

    raise_error: bool = False

    def __init__(
        self,
        goal: str | None = None,
        tool_specs: list[dict[str, Any]] | None = None,
    ) -> None:
        super().__init__()
        self.user_goal = goal
        self.tool_specs = tool_specs
        self.last_trace: AgentTrace | None = None
        self._depth = 0  # nested-chain counter — only act on top-level start/end

    # ------------------------------------------------------------------
    # Chain lifecycle
    # ------------------------------------------------------------------
    def on_chain_start(
        self,
        serialized: dict[str, Any],
        inputs: dict[str, Any],
        **kwargs: Any,
    ) -> None:
        self._depth += 1
        if self._depth > 1:
            return  # nested chain — leave the existing trajectory in place

        goal = self.user_goal or _extract_goal(inputs) or "(unknown goal)"
        start_trajectory(goal=goal, tool_specs=self.tool_specs)

    def on_chain_end(self, outputs: Any, **kwargs: Any) -> None:
        self._depth -= 1
        if self._depth > 0:
            return  # not the top-level end yet

        final = _extract_final_answer(outputs)
        trace = end_trajectory(final_answer=final)
        if trace is not None:
            self.last_trace = trace
            _emit_trace(trace)

    def on_chain_error(self, error: BaseException, **kwargs: Any) -> None:
        self._depth -= 1
        if self._depth > 0:
            return

        trace = end_trajectory(final_answer=None)
        if trace is not None:
            self.last_trace = trace
            _emit_trace(trace)

    # ------------------------------------------------------------------
    # Agent decisions + tool calls
    # ------------------------------------------------------------------
    def on_agent_action(self, action: Any, **kwargs: Any) -> None:
        record_step(
            step_type="agent_action",
            tool_name=getattr(action, "tool", None),
            step_input=_coerce_to_jsonable(getattr(action, "tool_input", None)),
        )

    def on_tool_end(self, output: Any, **kwargs: Any) -> None:
        record_step(
            step_type="tool",
            step_output=_coerce_to_jsonable(output),
        )


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
def _extract_goal(inputs: Any) -> str | None:
    if not isinstance(inputs, dict):
        return None
    for key in ("input", "query", "question", "goal", "user_input"):
        v = inputs.get(key)
        if isinstance(v, str) and v.strip():
            return v
    return None


def _extract_final_answer(outputs: Any) -> str | None:
    if isinstance(outputs, str):
        return outputs
    if isinstance(outputs, dict):
        for key in ("output", "answer", "result", "response"):
            v = outputs.get(key)
            if isinstance(v, str) and v.strip():
                return v
    return None


def _coerce_to_jsonable(value: Any) -> dict[str, Any] | str | None:
    """Convert tool inputs/outputs to a serialisable shape.

    Pydantic models, dicts pass through. Everything else is str-coerced.
    None stays None. We don't actually JSON-encode here — the API ingest
    route handles encoding.
    """
    if value is None:
        return None
    if isinstance(value, dict | str):
        return value
    if hasattr(value, "model_dump"):  # Pydantic v2
        try:
            return value.model_dump()  # type: ignore[no-any-return]
        except Exception:
            pass
    try:
        return str(value)
    except Exception:
        return None
