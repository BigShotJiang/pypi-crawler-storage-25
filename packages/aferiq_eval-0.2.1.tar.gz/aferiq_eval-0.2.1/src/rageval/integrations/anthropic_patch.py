"""Monkey-patch Anthropic's ``messages.create`` to capture tokens + latency.

Mirrors ``openai_patch.py``. Captures ``response.usage.input_tokens`` and
``output_tokens``. Both sync and async clients supported.

No-op if anthropic is not installed.
"""

from __future__ import annotations

import logging
import time
from typing import Any

from rageval.integrations._context import has_active_trajectory, record_step

_log = logging.getLogger(__name__)
_patched = False


def patch_anthropic() -> bool:
    """Install the patch. Idempotent."""
    global _patched
    if _patched:
        return True
    try:
        from anthropic.resources.messages import (  # type: ignore
            AsyncMessages,
            Messages,
        )
    except ImportError:
        _log.debug("anthropic SDK not installed; patch skipped")
        return False

    _patch_sync(Messages)
    _patch_async(AsyncMessages)
    _patched = True
    return True


def _patch_sync(Messages: Any) -> None:  # noqa: N803  -- mirrors anthropic SDK class name
    if getattr(Messages.create, "_aferiq_patched", False):
        return
    original = Messages.create

    def wrapped(self: Any, *args: Any, **kwargs: Any) -> Any:
        if not has_active_trajectory():
            return original(self, *args, **kwargs)
        t0 = time.perf_counter()
        try:
            response = original(self, *args, **kwargs)
        except Exception:
            latency = int((time.perf_counter() - t0) * 1000)
            _safe_record(latency_ms=latency, step_input=_summarize_request(kwargs))
            raise
        latency = int((time.perf_counter() - t0) * 1000)
        ti, to = _extract_usage(response)
        _safe_record(
            latency_ms=latency,
            tokens_in=ti,
            tokens_out=to,
            step_input=_summarize_request(kwargs),
            step_output=_summarize_response(response),
        )
        return response

    wrapped._aferiq_patched = True  # type: ignore[attr-defined]
    Messages.create = wrapped


def _patch_async(AsyncMessages: Any) -> None:  # noqa: N803  -- mirrors anthropic SDK class name
    if getattr(AsyncMessages.create, "_aferiq_patched", False):
        return
    original = AsyncMessages.create

    async def wrapped(self: Any, *args: Any, **kwargs: Any) -> Any:
        if not has_active_trajectory():
            return await original(self, *args, **kwargs)
        t0 = time.perf_counter()
        try:
            response = await original(self, *args, **kwargs)
        except Exception:
            latency = int((time.perf_counter() - t0) * 1000)
            _safe_record(latency_ms=latency, step_input=_summarize_request(kwargs))
            raise
        latency = int((time.perf_counter() - t0) * 1000)
        ti, to = _extract_usage(response)
        _safe_record(
            latency_ms=latency,
            tokens_in=ti,
            tokens_out=to,
            step_input=_summarize_request(kwargs),
            step_output=_summarize_response(response),
        )
        return response

    wrapped._aferiq_patched = True  # type: ignore[attr-defined]
    AsyncMessages.create = wrapped


def _extract_usage(response: Any) -> tuple[int | None, int | None]:
    try:
        usage = getattr(response, "usage", None)
        if usage is None:
            return None, None
        ti = getattr(usage, "input_tokens", None)
        to = getattr(usage, "output_tokens", None)
        return (int(ti) if ti is not None else None,
                int(to) if to is not None else None)
    except Exception:
        return None, None


def _summarize_request(kwargs: dict[str, Any]) -> dict[str, Any] | None:
    model = kwargs.get("model")
    messages = kwargs.get("messages")
    if not messages:
        return {"model": model} if model else None
    try:
        last_user = next(
            (m.get("content") for m in reversed(messages) if m.get("role") == "user"),
            None,
        )
        preview = (last_user or "")[:200] if isinstance(last_user, str) else None
        return {
            "model": model,
            "n_messages": len(messages),
            "last_user_preview": preview,
        }
    except Exception:
        return {"model": model}


def _summarize_response(response: Any) -> dict[str, Any] | None:
    try:
        content = getattr(response, "content", None)
        stop_reason = getattr(response, "stop_reason", None)
        # Anthropic content is a list of blocks; preview text from the first text block
        preview = None
        if isinstance(content, list) and content:
            for block in content:
                text = getattr(block, "text", None)
                if isinstance(text, str):
                    preview = text[:200]
                    break
        return {"stop_reason": stop_reason, "preview": preview}
    except Exception:
        return None


def _safe_record(**kwargs: Any) -> None:
    try:
        record_step(step_type="llm", **kwargs)
    except Exception as e:
        _log.debug("record_step failed: %s", e)
