"""Trajectory context propagation for agent eval.

A ``ContextVar`` holds the active trajectory's UUID; a module-level dict (with
a lock) holds the accumulating step list keyed by that UUID. This pattern
plays nicely with both threads and asyncio context propagation — when an
``await`` boundary fires, the ContextVar value carries through.

Usage (called by integrations like LangGraph callback or aferiq-trace-run
monkey-patches — not by end users directly):

    trace_id = start_trajectory(goal="Qual o prazo do CDC?")
    record_step(step_type="llm", tokens_in=1234, tokens_out=87, latency_ms=420)
    record_step(step_type="tool", tool_name="search", step_input={"q": "..."})
    record_step(step_type="llm", tokens_in=890, tokens_out=120, latency_ms=380)
    trace = end_trajectory(final_answer="7 dias do recebimento.")
    # trace is shipped via the existing register_trace_handler registry.
"""

from __future__ import annotations

import threading
import uuid
from contextvars import ContextVar
from typing import Any

from rageval.agent import AgentStep, AgentTrace, StepType

# Global state — keyed by trace_id (a UUID we generate per trajectory).
# The lock guards mutation; reads of the dict are also under it for simplicity.
_lock = threading.Lock()
_active_trajectories: dict[str, _TrajectoryState] = {}


class _TrajectoryState:
    """Mutable accumulator for one in-flight trajectory."""

    __slots__ = ("goal", "steps", "tool_specs", "metadata", "step_counter")

    def __init__(self, goal: str, tool_specs: list[dict[str, Any]] | None = None,
                 metadata: dict[str, Any] | None = None) -> None:
        self.goal = goal
        self.steps: list[AgentStep] = []
        self.tool_specs = tool_specs
        self.metadata = metadata or {}
        self.step_counter = 0


# Active trace_id for the current logical context (thread or async task).
_current_trace_id: ContextVar[str | None] = ContextVar(
    "rageval_current_trace_id", default=None
)


def start_trajectory(
    goal: str,
    *,
    trace_id: str | None = None,
    tool_specs: list[dict[str, Any]] | None = None,
    metadata: dict[str, Any] | None = None,
) -> str:
    """Begin recording a new trajectory in the current context.

    Returns the ``trace_id`` (generated if not provided). Subsequent
    ``record_step`` calls in the same context append to this trajectory until
    ``end_trajectory`` is called.

    If a trajectory is already active in the current context, this *replaces*
    it — the prior trajectory is dropped. This is intentional: the lib does
    not try to model nested trajectories in v1.
    """
    tid = trace_id or str(uuid.uuid4())
    with _lock:
        _active_trajectories[tid] = _TrajectoryState(
            goal=goal, tool_specs=tool_specs, metadata=metadata
        )
    _current_trace_id.set(tid)
    return tid


def record_step(
    *,
    step_type: StepType,
    tool_name: str | None = None,
    step_input: dict[str, Any] | str | None = None,
    step_output: dict[str, Any] | str | None = None,
    tokens_in: int | None = None,
    tokens_out: int | None = None,
    latency_ms: int | None = None,
) -> AgentStep | None:
    """Append a step to the active trajectory.

    Returns the recorded ``AgentStep``, or ``None`` if no trajectory is active
    (the call is a no-op — useful when monkey-patches fire outside a wrapped
    agent run, e.g. a one-off OpenAI call from somewhere else).
    """
    tid = _current_trace_id.get()
    if tid is None:
        return None

    with _lock:
        state = _active_trajectories.get(tid)
        if state is None:
            return None
        idx = state.step_counter
        state.step_counter += 1
        step = AgentStep(
            step_index=idx,
            step_type=step_type,
            tool_name=tool_name,
            step_input=step_input,
            step_output=step_output,
            tokens_in=tokens_in,
            tokens_out=tokens_out,
            latency_ms=latency_ms,
        )
        state.steps.append(step)
        return step


def end_trajectory(final_answer: str | None = None) -> AgentTrace | None:
    """Finalise the active trajectory and return an immutable ``AgentTrace``.

    Pops the accumulator, clears the ContextVar, and returns the assembled
    trace. Returns ``None`` if no trajectory was active.

    The caller is responsible for emitting the trace to handlers via
    ``rageval.integrations.tracing._emit`` (or equivalent) — this function
    only assembles the data, it doesn't dispatch.
    """
    tid = _current_trace_id.get()
    if tid is None:
        return None

    with _lock:
        state = _active_trajectories.pop(tid, None)
    _current_trace_id.set(None)
    if state is None:
        return None

    return AgentTrace(
        trace_id=tid,
        goal=state.goal,
        steps=state.steps,
        final_answer=final_answer,
        tool_specs=state.tool_specs,
        metadata=state.metadata,
    )


def current_trace_id() -> str | None:
    """Read-only accessor — useful for integrations that want to log/correlate."""
    return _current_trace_id.get()


def has_active_trajectory() -> bool:
    return _current_trace_id.get() is not None
