"""``aferiq init`` / ``rageval init`` CLI subcommand.

Drops the SDK setup down to one shell command:

    $ pip install aferiq-eval
    $ aferiq init
      ↓ detects framework, asks for the key, writes .env,
        adds 2 lines to the entry point
    $ python main.py
      [aferiq] ✓ tracing initialized · 200 OK (key valid)

Design notes:
    - The API key is prompted via stdin, NEVER passed as a CLI argument
      (would leak into shell history). Typer's ``Prompt`` with hide_input
      is used so the key doesn't echo to the terminal.
    - We never store the key — it goes straight to ``.env`` and the
      command exits.
    - .env edits PRESERVE existing variables (OPENAI_API_KEY, etc) — the
      AI-agent flow we shipped earlier hit the case where vars got
      overwritten and the user's app stopped booting.
    - Entry point detection scans common file names + framework imports.
      If we can't determine it, we fall back to printing manual
      instructions instead of writing into a guessed file.
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console

console = Console()
err = Console(stderr=True, style="red")

# Files we'd reasonably consider entry points, in priority order. The first
# one found in the project root wins.
_ENTRY_CANDIDATES: tuple[str, ...] = (
    "main.py",
    "app.py",
    "server.py",
    "run.py",
    "manage.py",
    "src/main.py",
    "src/app.py",
    "app/main.py",
)

# Framework detection — ordered most-specific to most-generic. The match
# determines which guidance we print after writing the .env.
_FRAMEWORK_HINTS: tuple[tuple[str, str], ...] = (
    ("LangGraph (multi-step agent)", "from langgraph"),
    ("LangChain (RAG)", "from langchain"),
    ("CrewAI", "from crewai"),
    ("LlamaIndex", "from llama_index"),
    ("Haystack", "from haystack"),
    ("AutoGen", "import autogen"),
    ("Pydantic AI", "from pydantic_ai"),
    ("Anthropic SDK direto", "import anthropic"),
    ("OpenAI SDK direto", "from openai"),
)

INIT_LINES = "import aferiq\naferiq.init()\n"


def aferiq_init(
    project_dir: Annotated[
        Path,
        typer.Option(
            "--project",
            "-p",
            help="Diretório do projeto Python a instrumentar. Default: cwd.",
        ),
    ] = Path.cwd(),
    ingest_url: Annotated[
        str,
        typer.Option(
            "--ingest-url",
            help="Endpoint do aferiq. Default lê AFERIQ_INGEST_URL ou usa produção.",
        ),
    ] = "",
    yes: Annotated[
        bool,
        typer.Option(
            "--yes",
            "-y",
            help="Pula confirmações interativas. Use com cuidado em CI.",
        ),
    ] = False,
) -> None:
    """Setup interativo do aferiq num projeto Python.

    Detecta framework, pede API key (não armazena), grava .env e adiciona
    2 linhas no entry point. Idempotente: rerun é seguro.
    """
    project_dir = project_dir.resolve()
    if not project_dir.exists() or not project_dir.is_dir():
        err.print(f"Diretório não existe: {project_dir}")
        raise typer.Exit(code=2)

    console.print()
    console.print(f"[bold]aferiq init[/] em [cyan]{project_dir}[/]")
    console.print()

    # 1. Resolve ingest URL.
    if not ingest_url:
        ingest_url = os.getenv(
            "AFERIQ_INGEST_URL", "https://aferiq.com.br/api/v1/traces"
        )
    console.print(f"[dim]Endpoint:[/] {ingest_url}")

    # 2. Detect framework.
    framework = _detect_framework(project_dir)
    if framework:
        console.print(f"[dim]Framework detectado:[/] [green]{framework}[/]")
    else:
        console.print("[dim]Framework:[/] não detectado (usando decorator genérico)")

    # 3. Prompt for API key. NEVER taken from CLI args — only stdin.
    if not yes:
        console.print()
        console.print(
            "[bold]Cola sua API key[/] (formato [cyan]rg_pk_live_…[/]). "
            "Crie em <DASHBOARD>/dashboard/api-keys."
        )
        console.print(
            "[dim]Ela é gravada direto no .env — não fica no histórico do shell.[/]"
        )
        api_key = typer.prompt(
            "  API key", hide_input=True, default="", show_default=False
        )
    else:
        api_key = "rg_pk_live_<COLOQUE_AQUI>"
        console.print(
            "[yellow]--yes:[/] pulando prompt — placeholder gravado, edite .env depois."
        )

    if api_key and not api_key.startswith("rg_pk_live_"):
        err.print(
            "Chave em formato inesperado (deveria começar com rg_pk_live_). Abortando."
        )
        raise typer.Exit(code=2)

    # 4. Write .env (preserve existing variables).
    env_path = project_dir / ".env"
    placeholder = "rg_pk_live_<COLOQUE_AQUI>"
    written_value = api_key or placeholder
    _upsert_env_var(env_path, "AFERIQ_API_KEY", written_value)
    _upsert_env_var(env_path, "AFERIQ_INGEST_URL", ingest_url)
    if api_key:
        console.print(f"[green]✓[/] API key gravada em [cyan]{env_path.name}[/]")
    else:
        console.print(
            f"[yellow]⚠[/] Placeholder gravado em [cyan]{env_path.name}[/]. "
            "Edite e cole o valor real."
        )

    # 5. Ensure .gitignore covers .env.
    _ensure_gitignored(project_dir / ".gitignore", ".env")

    # 6. Write .env.example so devs know what vars are needed.
    example_path = project_dir / ".env.example"
    _upsert_env_var(example_path, "AFERIQ_API_KEY", placeholder)
    _upsert_env_var(example_path, "AFERIQ_INGEST_URL", ingest_url)

    # 7. Modify entry point (or print guidance).
    entry = _find_entry_point(project_dir)
    if entry:
        if _entry_already_initialized(entry):
            console.print(
                f"[green]✓[/] [cyan]{entry.relative_to(project_dir)}[/] já tem aferiq.init()"
            )
        else:
            _prepend_init(entry)
            console.print(
                f"[green]✓[/] aferiq.init() adicionado em [cyan]{entry.relative_to(project_dir)}[/]"
            )
    else:
        console.print(
            "[yellow]⚠[/] Entry point não detectado. Adicione manualmente no topo do "
            "seu main.py / app.py:"
        )
        console.print()
        console.print("    [cyan]import aferiq[/]")
        console.print("    [cyan]aferiq.init()[/]")
        console.print()

    # 8. Final summary.
    console.print()
    console.print("[bold green]Pronto.[/] Próximo passo:")
    console.print()
    console.print("  [dim]$[/] [cyan]python main.py[/]   [dim]# ou seu entry point real[/]")
    console.print()
    console.print(
        "Você verá [cyan][aferiq] ✓ tracing initialized[/] no boot. "
        "Dispare uma chamada do bot e confira /dashboard/traces."
    )


def _detect_framework(project_dir: Path) -> str | None:
    """Scan up to 50 .py files in the project for framework imports."""
    py_files = list(project_dir.rglob("*.py"))[:50]
    if not py_files:
        return None
    seen: set[str] = set()
    for f in py_files:
        try:
            text = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        seen.add(text)
    blob = "\n".join(seen)
    for label, hint in _FRAMEWORK_HINTS:
        if hint in blob:
            return label
    return None


def _find_entry_point(project_dir: Path) -> Path | None:
    """Return the first entry-point candidate that exists in the project."""
    for candidate in _ENTRY_CANDIDATES:
        path = project_dir / candidate
        if path.exists() and path.is_file():
            return path
    return None


def _entry_already_initialized(path: Path) -> bool:
    """Check whether the entry file already calls aferiq.init() near the top."""
    try:
        text = path.read_text(encoding="utf-8")
    except Exception:
        return False
    return "aferiq.init(" in text


def _prepend_init(path: Path) -> None:
    """Add ``import aferiq; aferiq.init()`` after any module docstring and
    before the first non-import statement.

    We don't try to be clever about the ideal injection point — placing the
    init right after the file's docstring (or at line 0) works for >95% of
    Python entry points and surfaces immediately if there's a problem.
    """
    text = path.read_text(encoding="utf-8")
    lines = text.splitlines(keepends=True)

    # Skip leading shebang.
    insert_idx = 0
    if lines and lines[0].startswith("#!"):
        insert_idx = 1

    # Skip module docstring (single or triple-quoted).
    rest = "".join(lines[insert_idx:])
    docstring_match = re.match(r'\s*("""|\'\'\')[\s\S]*?\1\s*\n?', rest)
    if docstring_match:
        # Count how many lines the docstring spans + the leading whitespace.
        consumed = docstring_match.group(0)
        line_count = consumed.count("\n")
        insert_idx += line_count

    new_block = f"\n{INIT_LINES}\n"
    lines.insert(insert_idx, new_block)
    path.write_text("".join(lines), encoding="utf-8")


def _upsert_env_var(path: Path, key: str, value: str) -> None:
    """Add or replace KEY=VALUE in path. Preserves all other variables."""
    pattern = re.compile(rf"^{re.escape(key)}=.*$", flags=re.MULTILINE)
    new_line = f"{key}={value}"
    if path.exists():
        text = path.read_text(encoding="utf-8")
        if pattern.search(text):
            text = pattern.sub(new_line, text)
        else:
            if text and not text.endswith("\n"):
                text += "\n"
            text += new_line + "\n"
    else:
        text = new_line + "\n"
    path.write_text(text, encoding="utf-8")


def _ensure_gitignored(gitignore_path: Path, entry: str) -> None:
    """Make sure the given pattern is covered by .gitignore."""
    if not gitignore_path.exists():
        gitignore_path.write_text(f"{entry}\n", encoding="utf-8")
        return
    text = gitignore_path.read_text(encoding="utf-8")
    lines = {line.strip() for line in text.splitlines()}
    if entry in lines or f"/{entry}" in lines or f"{entry}/*" in lines:
        return
    if not text.endswith("\n"):
        text += "\n"
    text += f"{entry}\n"
    gitignore_path.write_text(text, encoding="utf-8")
