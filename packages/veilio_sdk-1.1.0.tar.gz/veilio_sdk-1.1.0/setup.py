"""
Setup configuration for Veilio Python SDK
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="veilio-sdk",
    version="1.1.0",
    author="Veilio",
    author_email="support@veilio.xyz",
    description="Official Veilio SDK for Python - Data tokenization and cyber-resilience API client",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/veilio/veilio-sdk-python",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Security",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.28.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "black>=22.0.0",
            "mypy>=0.991",
        ],
    },
    keywords="veilio tokenization data-protection cyber-resilience privacy security api-client",
    project_urls={
        "Documentation": "https://docs.veilio.com",
        "Source": "https://github.com/veilio/veilio-sdk-python",
        "Support": "https://veilio.com/support",
    },
)
