"""
Custom exceptions for Veilio SDK
"""


class VeilioError(Exception):
    """Base exception for Veilio API errors"""

    def __init__(
        self,
        message: str,
        code: str = "API_ERROR",
        status_code: int = 500,
        details: dict = None,
    ):
        self.message = message
        self.code = code
        self.status_code = status_code
        self.details = details or {}
        super().__init__(self.message)

    def __str__(self):
        return f"{self.code} ({self.status_code}): {self.message}"


class AuthenticationError(VeilioError):
    """Raised when API key is invalid or missing"""

    def __init__(self, message: str = "Invalid or missing API key"):
        super().__init__(message, "AUTH_ERROR", 401)


class ValidationError(VeilioError):
    """Raised when request data is invalid"""

    def __init__(self, message: str, details: dict = None):
        super().__init__(message, "VALIDATION_ERROR", 400, details)


class RateLimitError(VeilioError):
    """Raised when rate limit is exceeded"""

    def __init__(self, message: str = "Rate limit exceeded", retry_after: int = None):
        super().__init__(message, "RATE_LIMIT_ERROR", 429)
        self.retry_after = retry_after


class PlanLimitError(VeilioError):
    """Raised when plan limit is exceeded"""

    def __init__(self, message: str = "Plan limit exceeded"):
        super().__init__(message, "PLAN_LIMIT", 403)


class TokenShreddedError(VeilioError):
    """Raised when trying to access a cryptographically shredded token"""

    def __init__(self, message: str = "Token has been cryptographically shredded"):
        super().__init__(message, "TOKEN_SHREDDED", 410)
