"""
Veilio SDK - Official Python client for Veilio API

Data tokenization and cyber-resilience API client.
"""

from .client import VeilioClient
from .exceptions import (
    VeilioError,
    PlanLimitError,
    AuthenticationError,
    RateLimitError,
    TokenShreddedError,
)

__version__ = "1.1.0"
__all__ = [
    "VeilioClient",
    "VeilioError",
    "PlanLimitError",
    "AuthenticationError",
    "RateLimitError",
    "TokenShreddedError",
]
