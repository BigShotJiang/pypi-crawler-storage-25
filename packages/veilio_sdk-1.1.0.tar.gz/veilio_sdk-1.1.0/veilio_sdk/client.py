"""
Veilio API Client

Main client class for interacting with the Veilio API.
"""

import time
from typing import Optional, Dict, List, Any
import requests
from .exceptions import (
    VeilioError,
    AuthenticationError,
    RateLimitError,
    PlanLimitError,
    TokenShreddedError,
)


class VeilioClient:
    """
    Official Veilio API client for Python

    Example:
        >>> from veilio_sdk import VeilioClient
        >>> client = VeilioClient(api_key="veil_dev_xxx")
        >>> result = client.tokenize(data="test@example.com", type="email")
        >>> print(result["token"])
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.veilio.com/api",
        timeout: int = 30,
        max_retries: int = 3,
    ):
        """
        Initialize Veilio client

        Args:
            api_key: Your Veilio API key
            base_url: API base URL (default: https://api.veilio.com/api)
            timeout: Request timeout in seconds (default: 30)
            max_retries: Maximum number of retries for failed requests (default: 3)
        """
        if not api_key:
            raise ValueError("API key is required")

        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self.session = requests.Session()
        self.session.headers.update(
            {
                "X-API-Key": self.api_key,
                "Content-Type": "application/json",
            }
        )

    def _request(
        self,
        endpoint: str,
        method: str = "GET",
        data: Optional[Dict] = None,
    ) -> Dict[str, Any]:
        """
        Make an HTTP request with retry logic and error handling

        Args:
            endpoint: API endpoint (e.g., "/tokenize")
            method: HTTP method (GET, POST, etc.)
            data: Request body data

        Returns:
            Response JSON as dictionary

        Raises:
            VeilioError: For API errors
            AuthenticationError: For authentication errors
            RateLimitError: For rate limit errors
        """
        url = f"{self.base_url}{endpoint}"
        last_error = None

        for attempt in range(self.max_retries + 1):
            try:
                response = self.session.request(
                    method=method,
                    url=url,
                    json=data,
                    timeout=self.timeout,
                )

                # Parse JSON response
                try:
                    response_data = response.json()
                except ValueError:
                    response_data = {"message": response.text}

                # Handle errors
                if not response.ok:
                    # Rate limit handling
                    if response.status_code == 429:
                        retry_after = int(
                            response.headers.get("Retry-After", "60")
                        )
                        if attempt < self.max_retries:
                            time.sleep(retry_after)
                            continue
                        raise RateLimitError(
                            response_data.get("message", "Rate limit exceeded"),
                            retry_after=retry_after,
                        )

                    # Authentication error
                    if response.status_code == 401:
                        raise AuthenticationError(
                            response_data.get("message", "Invalid or missing API key")
                        )

                    # Plan limit error (403 with PLAN_LIMIT code)
                    if (
                        response.status_code == 403
                        and response_data.get("error") == "PLAN_LIMIT"
                    ):
                        raise PlanLimitError(
                            response_data.get("message", "Plan limit exceeded")
                        )
                    if (
                        response.status_code == 410
                        and response_data.get("error") == "TOKEN_SHREDDED"
                    ):
                        raise TokenShreddedError(
                            response_data.get(
                                "message",
                                "Token has been cryptographically shredded",
                            )
                        )

                    # Other errors
                    error_code = response_data.get("error", "API_ERROR")
                    error_message = response_data.get(
                        "message", f"HTTP {response.status_code}"
                    )
                    raise VeilioError(
                        error_message,
                        code=error_code,
                        status_code=response.status_code,
                        details=response_data.get("details"),
                    )

                return response_data

            except requests.exceptions.Timeout:
                if attempt < self.max_retries:
                    time.sleep(2 ** attempt)  # Exponential backoff
                    continue
                raise VeilioError(
                    "Request timeout",
                    code="TIMEOUT_ERROR",
                    status_code=408,
                )

            except requests.exceptions.ConnectionError as e:
                if attempt < self.max_retries:
                    time.sleep(2 ** attempt)
                    last_error = e
                    continue
                raise VeilioError(
                    f"Connection error: {str(e)}",
                    code="CONNECTION_ERROR",
                    status_code=0,
                )

            except (VeilioError, AuthenticationError, RateLimitError):
                # Don't retry these errors
                raise

            except Exception as e:
                if attempt < self.max_retries:
                    time.sleep(2 ** attempt)
                    last_error = e
                    continue
                raise VeilioError(
                    f"Unexpected error: {str(e)}",
                    code="UNKNOWN_ERROR",
                    status_code=0,
                )

        raise last_error or VeilioError(
            "Request failed after retries",
            code="RETRY_EXHAUSTED",
            status_code=0,
        )

    def tokenize(
        self,
        data: str,
        type: Optional[str] = None,
        metadata: Optional[Dict] = None,
        retention: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, str]:
        """
        Tokenize a single field

        Args:
            data: The sensitive data to tokenize
            type: Optional type of data (email, phone, ssn, etc.)
            metadata: Optional metadata dictionary
            retention: Optional retention policy for automatic shredding.
                Supported keys:
                - ttlDays (int): Number of days before shredding
                - retentionUntil (str): Absolute ISO datetime for shredding

        Returns:
            Dictionary with "token" and "createdAt" keys

        Example:
            >>> result = client.tokenize(data="john@example.com", type="email")
            >>> print(result["token"])
        """
        payload = {"data": data}
        if type:
            payload["type"] = type
        if metadata:
            payload["metadata"] = metadata
        if retention:
            payload["retention"] = retention

        return self._request("/tokenize", method="POST", data=payload)

    def tokenize_bulk(
        self, fields: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Tokenize multiple fields in a single request

        Args:
            fields: List of field dictionaries, each with:
                - data (str): The sensitive data
                - type (str, optional): Type of data
                - metadata (dict, optional): Additional metadata

        Returns:
            Dictionary with:
                - tokens: List of token results
                - summary: Summary with total, success, failed counts
                - errors: Optional list of errors
                - createdAt: ISO timestamp

        Example:
            >>> result = client.tokenize_bulk([
            ...     {"data": "john@example.com", "type": "email"},
            ...     {"data": "+33612345678", "type": "phone"},
            ... ])
            >>> print(result["summary"]["success"])
        """
        return self._request("/tokenize/bulk", method="POST", data={"fields": fields})

    def detokenize(
        self, token: str, reason: Optional[str] = None
    ) -> Dict[str, str]:
        """
        Detokenize a single token to retrieve original data

        Args:
            token: The token to detokenize
            reason: Optional reason for accessing the data (for audit logs)

        Returns:
            Dictionary with "data" and "accessedAt" keys

        Example:
            >>> result = client.detokenize(token="tok_abc123...", reason="Send email")
            >>> print(result["data"])
        """
        payload = {"token": token}
        if reason:
            payload["reason"] = reason

        return self._request("/detokenize", method="POST", data=payload)

    def detokenize_bulk(
        self, tokens: List[Dict[str, str]]
    ) -> Dict[str, Any]:
        """
        Detokenize multiple tokens in a single request

        Args:
            tokens: List of token dictionaries, each with:
                - token (str): The token to detokenize
                - reason (str, optional): Reason for access

        Returns:
            Dictionary with:
                - results: List of detokenized results
                - summary: Summary with total, success, failed counts
                - errors: Optional list of errors
                - accessedAt: ISO timestamp

        Example:
            >>> result = client.detokenize_bulk([
            ...     {"token": "tok_abc123...", "reason": "Processing"},
            ...     {"token": "tok_def456...", "reason": "Processing"},
            ... ])
            >>> print(result["results"][0]["data"])
        """
        return self._request("/detokenize/bulk", method="POST", data={"tokens": tokens})

    def tokenize_format(
        self,
        data: str,
        format: Optional[str] = None,
        options: Optional[Dict] = None,
    ) -> Dict[str, Any]:
        """
        Tokenize structured data (JSON, CSV, SQL)

        Args:
            data: The structured data as string
            format: Format type ("json", "csv", "sql") - auto-detected if omitted
            options: Optional format-specific options:
                - csv: Dict with delimiter, hasHeaders
                - fields: List of specific field paths to tokenize

        Returns:
            Dictionary with:
                - format: The format used
                - tokenizedData: Data with tokens replaced
                - tokens: List of tokens created
                - metadata: Additional metadata
                - summary: Summary with totalFields, tokenizedFields

        Example:
            >>> json_data = '{"email": "john@example.com"}'
            >>> result = client.tokenize_format(data=json_data, format="json")
            >>> print(result["tokenizedData"])
        """
        payload = {"data": data}
        if format:
            payload["format"] = format
        if options:
            payload["options"] = options

        return self._request("/tokenize/format", method="POST", data=payload)

    def detokenize_format(
        self,
        tokenized_data: str,
        format: str,
        tokens: List[Dict[str, str]],
    ) -> Dict[str, Any]:
        """
        Detokenize structured data (JSON, CSV, SQL)

        Args:
            tokenized_data: The tokenized data as string
            format: Format type ("json", "csv", "sql")
            tokens: List of token dictionaries with:
                - path (str): Path to the token in the data
                - token (str): The token value

        Returns:
            Dictionary with:
                - format: The format used
                - detokenizedData: Data with original values restored
                - summary: Summary with tokensProcessed

        Example:
            >>> result = client.detokenize_format(
            ...     tokenized_data='{"email": "tok_abc123..."}',
            ...     format="json",
            ...     tokens=[{"path": "email", "token": "tok_abc123..."}]
            ... )
            >>> print(result["detokenizedData"])
        """
        return self._request(
            "/detokenize/format",
            method="POST",
            data={
                "tokenizedData": tokenized_data,
                "format": format,
                "tokens": tokens,
            },
        )

    def shred_token(
        self, token: str, reason: Optional[str] = None
    ) -> Dict[str, str]:
        """
        Shred a token immediately (cryptographic erasure)

        Args:
            token: Token to shred immediately
            reason: Optional audit reason

        Returns:
            Dictionary with "token" and "shreddedAt" keys

        Example:
            >>> result = client.shred_token(
            ...     token="tok_abc123...",
            ...     reason="GDPR delete request"
            ... )
            >>> print(result["shreddedAt"])
        """
        payload = {"token": token}
        if reason:
            payload["reason"] = reason

        return self._request("/tokens/shred", method="POST", data=payload)
