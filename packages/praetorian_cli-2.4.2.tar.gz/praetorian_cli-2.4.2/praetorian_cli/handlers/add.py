import datetime
import json
import os.path

import click

from praetorian_cli.handlers.chariot import chariot
from praetorian_cli.handlers.cli_decorators import cli_handler, praetorian_only
from praetorian_cli.handlers.utils import error, parse_configuration_value
from praetorian_cli.sdk.model.globals import AddRisk, Asset, Seed, Kind


@chariot.group()
def add():
    """ Add an entity to Guard """
    pass


@add.command()
@cli_handler
@click.option('-g', '--group', '--dns', required=True, help='The group of the asset (e.g., domain name, project ID)')
@click.option('-i', '--identifier', '--name', required=False, help='The specific identifier of the asset (e.g., IP address)')
@click.option('-t', '--type', 'asset_type', required=False, help='The type of the asset (asset, generic, repository, etc.)', default=Kind.ASSET.value)
@click.option('-s', '--status', type=click.Choice([s.value for s in Asset]), required=False,
              default=Asset.ACTIVE.value, help=f'Status of the asset', show_default=True)
@click.option('-f', '--surface', required=False, default='', help=f'Attack surface of the asset', show_default=False)
@click.option('-r', '--resource-type', required=False, default='', help='Cloud resource type (e.g., compute.googleapis.com/Instance, AWS::EC2::Instance)')
def asset(sdk, identifier, group, asset_type, status, surface, resource_type):
    """ Add an asset

    Add an asset to the Guard database. This command requires a group for the asset.
    Optionally, an identifier can be provided to give the asset more specific information,
    such as IP address. If no identifier is provided, the group will be used as the identifier.

    The type can be one of the following: asset, generic, addomain, repository, webapplication,
    gcpresource, awsresource, azureresource.

    For cloud resource types (gcpresource, awsresource, azureresource), the --resource-type
    flag is required. See cloud_resource_type.go for the full list of valid resource types.

    \b
    Example assets:
        - A domain name:   reddit.com
        - An IP addresses: 208.67.222.222
        - A CIDR range:    208.67.222.0/24

    \b
    Example usages:
        - guard add asset --group example.com
        - guard add asset --group example.com --identifier 1.2.3.4
        - guard add asset --group internal.example.com --identifier 10.2.3.4 --surface internal
        - guard add asset --group https://example.com --identifier 'Example Web Application' --type webapplication
        - guard add asset --group my-project-id --identifier 'projects/my-proj/zones/us-central1-a/instances/vm1' --type gcpresource --resource-type 'compute.googleapis.com/Instance'
        - guard add asset --group "my-custom-id" --identifier "any string here" --type generic
    """
    if not identifier:
        identifier = group
    sdk.assets.add(group, identifier, asset_type, status, surface, resource_type=resource_type)


@add.command()
@cli_handler
@click.argument('path')
@click.option('-n', '--name', help='The file name in Guard. Default: the full path of the uploaded file')
def file(sdk, path, name):
    """ Upload a file

    This commands takes the path to a local file and uploads it to the
    Guard file system. The Guard file system is where the platform
    stores proofs of exploit, risk definitions, and other supporting data.

    User files reside in the "home/" folder. Those files appear in the app
    at https://guard.praetorian.com/app/files

    \b
    Arguments:
        - PATH: the local file path to the file you want to upload.

    \b
    Example usages:
        - guard add file ./file.txt
        - guard add file ./file.txt --name "home/file.txt"
    """
    try:
        sdk.files.add(path, name)
    except Exception as e:
        error(f'Unable to upload file {path}. Error: {e}')


@add.command()
@cli_handler
@click.argument('path')
@click.option('-n', '--name', help='The risk name definition. Default: the filename used')
def definition(sdk, path, name):
    """ Upload a risk definition

    This commands takes the path to the local file and uploads it to the
    Guard file system as risk definitions. Risk definitions reside
    in the "definitions/" folder in the file system.

    Risk definitions need to be in the Markdown format.

    \b
    Arguments
        - PATH: the local file path to the risk definition file

    \b
    Example usages:
        - guard add definition ./CVE-2024-23049
        - guard add definition ./CVE-2024-23049.updated.md --name CVE-2024-23049
    """
    if name is None:
        name = os.path.basename(path)
    try:
        sdk.definitions.add(path, name)
    except Exception as e:
        error(f'Unable to upload risk definition file {path}. Error: {e}')


@add.command()
@cli_handler
def webhook(sdk):
    """ Generate an authenticated URL for posting assets and risks

    The command prints the URL of the webhook generated. If the webhook
    is already present, you need to first delete it before generating
    a new one.

    \b
    Example usages:
        - guard add webhook
    """
    if sdk.webhook.get_record():
        click.echo('There is an existing webhook. Delete it first before adding a new one.')
    else:
        click.echo(sdk.webhook.upsert())


@add.command()
@cli_handler
@click.argument('name', required=True)
@click.option('-a', '--asset', required=True, help='Key of an existing asset')
@click.option('-s', '--status', type=click.Choice([s.value for s in AddRisk]), required=True,
              help=f'Status of the risk')
@click.option('-c', '--comment', default='', help='Comment for the risk')
@click.option('-cap', '--capability', default='', help='Capability that discoverd the risk')
@click.option('--title', '-t', default=None, help='Human-readable title for the risk')
@click.option('-g', '--tag', 'tags', multiple=True, help='Tag for the risk (can be specified multiple times)')
def risk(sdk, name, asset, status, comment, capability, title, tags):
    """ Add a risk

    This command adds a risk to Guard. A risk must have an associated asset.
    The asset is specified by its key, which can be retrieved by listing and
    searching the assets.

    \b
    Arguments:
        - NAME: the name of the risk. For example, "CVE-2024-23049".

    \b
    Example usages:
        - guard add risk CVE-2024-23049 --asset "#asset#example.com#1.2.3.4" --status TI
        - guard add risk CVE-2024-23049 --asset "#asset#example.com#1.2.3.4" --status TC
        - guard add risk CVE-2024-23049 --asset "#asset#example.com#1.2.3.4" --status TC --capability red-team
        - guard add risk CVE-2024-23049 --asset "#asset#example.com#1.2.3.4" --status TI --tag critical --tag needs-review
    """
    sdk.risks.add(asset, name, status, comment, capability, title, tags)


@add.command()
@cli_handler
@click.option('-k', '--key', required=True, help='Key of an existing asset or attribute')
@click.option('-c', '--capability', 'capabilities', multiple=True,
              help='Capabilities to run (can be specified multiple times)')
@click.option('-g', '--config', help='JSON configuration string')
@click.option('-s', '--credential', 'credentials', help='Credential ID to use with the job', multiple=True)
def job(sdk, key, capabilities, config, credentials):
    """ Schedule scan jobs for an asset or an attribute

    This command schedules the relevant discovery and vulnerability scans for
    the specified asset or attribute. Make sure to quote the key, since it
    contains the "#" sign.

    \b
    Example usages:
        - guard add job --key "#asset#example.com#1.2.3.4"
        - guard add job --key "#asset#example.com#1.2.3.4" -c subdomain -c portscan
        - guard add job --key "#attribute#ssh#22#asset#api.www.example.com#1.2.3.4"
        - guard add job --key "#asset#example.com#1.2.3.4" --config '{"run-type":"login"}'
        - guard add job --key "#asset#example.com#1.2.3.4" --config '{"run-type":"login"} --credential "E4644F37-6985-40B4-8D07-5311516D98F1"'
    """
    sdk.jobs.add(key, capabilities, config, credentials)


@add.command()
@cli_handler
@click.option('-k', '--key', required=True, help='Key of an existing asset or risk')
@click.option('-n', '--name', required=True, help='Name of the attribute')
@click.option('-v', '--value', required=True, help='Value of the attribute')
def attribute(sdk, key, name, value):
    """ Add an attribute for an asset or risk

    This command adds a name-value attribute for the specified asset or risk.

    \b
    Example usages:
        - guard add attribute --key "#risk#www.example.com#CVE-2024-23049" --name https --value 443
        - guard add attribute --key "#asset#www.example.com#www.example.com" --name id --value "arn:aws:route53::1654874321:hostedzone/Z0000000EJBHGTFTGH3"
    """
    sdk.attributes.add(key, name, value)


@add.command()
@cli_handler
@click.option('-t', '--type', 'seed_type', default='asset', help='Asset type (e.g., asset, addomain)')
@click.option('-s', '--status', type=click.Choice([s.value for s in Seed]),
              default=Seed.PENDING.value, help='The status of the seed', show_default=True)
@click.option('-f', '--field', 'field_list', multiple=True, 
              help='Field in format name:value (can be specified multiple times)')
def seed(sdk, seed_type, status, field_list):
    """ Add a seed

    Add a seed to the Guard database. Seeds are now assets with special labeling.
    You can specify the asset type and provide dynamic fields using --fields.

    \b
    Example usages:
        - guard add seed --type asset --field dns:example.com
        - guard add seed --type asset --field dns:example.com --status A
        - guard add seed --type asset --field dns:example.com --field name:1.2.3.4
        - guard add seed --type addomain --field domain:corp.local --field objectid:S-1-5-21-2701466056-1043032755-2418290285
    """
    # Collect dynamic fields from the --fields option
    dynamic_fields = {}
    
    # Parse field_list entries (name:value format)
    for field in field_list:
        if ':' in field:
            # Split only once to allow colons in the value
            name, value = field.split(':', 1)
            dynamic_fields[name] = value
        else:
            error(f"Field '{field}' is not in the format name:value")
            return
    
    # Call the updated add method with type and dynamic fields
    sdk.seeds.add(status=status, seed_type=seed_type, **dynamic_fields)


@add.command()
@cli_handler
@click.option('-t', '--type', required=True, help='Preseed type')
@click.option('-l', '--title', required=True, help='Preseed title')
@click.option('-v', '--value', required=True, help='Preseed value')
@click.option('-s', '--status', required=False, default='A', help='Preseed status', show_default=True)
def preseed(sdk, type, title, value, status):
    """ Add a preseed

    This command adds a preseed to the Guard database.
    Preseeds default to ACTIVE and cannot be added as PENDING.

    \b
    Example usages:
        - guard add preseed -t "whois+company" -l "Example Company" -v "example company"
        - guard add preseed --type "whois+company" --title "Example Company" --value "example company" --status "A"
    """
    sdk.preseeds.add(type, title, value, status)


@add.command()
@cli_handler
@click.option('-n', '--name', required=True, help='Name of the setting')
@click.option('-v', '--value', required=True, help='Value of the setting')
def setting(sdk, name, value):
    """ Add a setting

    This command adds a name-value setting.

    \b
    Example usages:
        - guard add setting --name "rate-limit" --value '{"capability-rate-limit": 100}'
    """
    sdk.settings.add(name, value)


@add.command()
@cli_handler
@click.option('-n', '--name', required=True, help='Name of the configuration')
@click.option('-e', '--entry', required=False, multiple=True,
              help='Key-value pair in format key=value. Can be specified multiple times to set multiple values.')
@click.option('--string', 'string_value', required=False,
              help='Set the configuration value to a string')
@click.option('--integer', 'integer_value', required=False,
              help='Set the configuration value to an integer')
@click.option('--float', 'float_value', required=False,
              help='Set the configuration value to a floating point number')
@praetorian_only
def configuration(sdk, name, entry, string_value, integer_value, float_value):
    """ Add a configuration

    This command adds, or overwrites if exists, a configuration value.

    Configuration values can be provided as a mapping of key-value pairs using
    ``--entry`` (the previous behavior), or as primitive values using
    ``--string``, ``--integer``, or ``--float``.

    \b
    Example usages:
        - guard add configuration --name "nuclei" --entry extra-tags=http,sql --entry something=else
        - guard add configuration --name "billing-status" --string PAID_MS
        - guard add configuration --name "request-timeout" --integer 60
        - guard add configuration --name "scoring-threshold" --float 0.85
    """
    config_value = parse_configuration_value(entry, string_value, integer_value, float_value)
    sdk.configurations.add(name, config_value)


@add.command()
@cli_handler
@click.option('-n', '--name', required=True, help='Name of the API key')
@click.option('-e', '--expires', required=True, help='Duration until key expiration, in days', type=int)
def key(sdk, name, expires):
    """ Add an API key

    This command creates a new API key for authentication.

    \b
    Example usages:
        - guard add key --name "my-automation-key"
        - guard add key --name "ci-cd-key"
    """

    expiresT = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=expires)
    result = sdk.keys.add(name, expires=expiresT.strftime('%Y-%m-%dT%H:%M:%SZ'))
    if 'secret' not in result:
        click.echo(f"Error: secret value was not present in the response")
        return
    click.echo(f'API key created: {result.get("key", "N/A")}')
    click.echo(f'Secret (save this, it will not be shown again): {result["secret"]}')


@add.command()
@cli_handler
@click.option('-u', '--url', required=True, help='The full URL of the page')
@click.option('-p', '--parent', required=False, help='Optional key of the parent WebApplication')
def webpage(sdk, url, parent):
    """ Add a Webpage

    Add a web page to the Guard database. Webpages can optionally be associated
    with a parent WebApplication or exist independently.

    \b
    Example usages:
        - guard add webpage --url https://app.example.com/login
        - guard add webpage --url https://app.example.com/admin --parent "#webapplication#https://app.example.com"
    """
    sdk.webpage.add(url, parent)


@add.command()
@cli_handler
@click.option('-r', '--resource-key', required=True, help='The resource key for the credential (e.g., account key)')
@click.option('-c', '--category', required=True,
              type=click.Choice(['integration', 'cloud', 'env-integration']),
              help='The category of the credential')
@click.option('-t', '--type', 'cred_type', required=True,
              help='The type of credential (aws, gcp, azure, static, ssh_key, json, active-directory, default)')
@click.option('-l', '--label', required=True, help='A human-readable label for the credential')
@click.option('-p', '--param', 'parameters', multiple=True,
              help='Parameter in format key=value (can be specified multiple times)')
def credential(sdk, resource_key, category, cred_type, label, parameters):
    """ Add a credential

    This command adds a credential to the credential broker. Credentials can be used
    for authentication with various cloud providers, integrations, and environment services.

    \b
    Example usages:
        - guard add credential --resource-key "C.0c6cf7104f516b08-OGMPG" --category env-integration --type active-directory --label "Robb Stark" --param username=robb.stark --param password=sexywolfy --param domain=north.sevenkingdoms.local
        - guard add credential -r "C.example-key" -c cloud -t aws --label "AWS Production" -p region=us-east-1 -p role_arn=arn:aws:iam::123456789012:role/MyRole
        - guard add credential -r "C.example-key" -c integration -t static --label "API Token" -p token=abc123xyz
    """
    # Parse parameters from key=value format
    params = {}
    for param in parameters:
        if '=' not in param:
            error(f"Parameter '{param}' is not in the format key=value")
            return
        key, value = param.split('=', 1)
        params[key] = value

    try:
        result = sdk.credentials.add(resource_key, category, cred_type, label, params)
        click.echo(json.dumps(result, indent=2))
    except Exception as e:
        error(f'Unable to add credential. Error: {e}')
