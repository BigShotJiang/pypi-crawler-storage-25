"""Tests for worktree configuration and Runner worktree integration."""

from steerdev_agent.config.models import EvidenceConfig, WorktreeConfig
from steerdev_agent.prompt.builder import WaveContext
from steerdev_agent.runner import Runner
from steerdev_agent.worktree import compute_branch_name


class TestComputeBranchName:
    def test_task_with_external_id(self):
        task = {"id": "abc12345xyz", "title": "Add auth", "linear_identifier": "PROJ-123"}
        assert compute_branch_name(task) == "task/PROJ-123-add-auth"

    def test_task_without_external_id(self):
        task = {"id": "abc12345xyz", "title": "Add user auth"}
        assert compute_branch_name(task) == "task/abc12345-add-user-auth"

    def test_task_short_id(self):
        task = {"id": "short", "title": "Fix bug"}
        assert compute_branch_name(task) == "task/short-fix-bug"

    def test_task_no_title(self):
        task = {"id": "abc12345xyz"}
        assert compute_branch_name(task) == "task/abc12345"

    def test_wave_based(self):
        task = {"id": "abc123", "title": "Something"}
        wave = WaveContext(wave_number=3, total_waves=5)
        assert compute_branch_name(task, wave) == "wave/3"

    def test_wave_takes_precedence(self):
        task = {"id": "abc12345xyz", "title": "Add auth", "linear_identifier": "PROJ-123"}
        wave = WaveContext(wave_number=2, total_waves=4)
        assert compute_branch_name(task, wave) == "wave/2"

    def test_title_slugified(self):
        task = {"id": "abc12345xyz", "title": "Add User Authentication & OAuth 2.0"}
        result = compute_branch_name(task)
        assert result == "task/abc12345-add-user-authentication-oauth-2-0"

    def test_long_title_truncated(self):
        task = {"id": "abc12345xyz", "title": "A" * 100}
        result = compute_branch_name(task)
        # Slug is max 40 chars
        slug = result.split("-", 1)[1] if "-" in result.split("/")[1] else ""
        assert len(slug) <= 40

    def test_external_id_via_external_id_field(self):
        task = {"id": "abc12345xyz", "title": "Fix", "external_id": "JIRA-456"}
        assert compute_branch_name(task) == "task/JIRA-456-fix"


class TestRunnerWorktreeConfig:
    def test_disabled_by_default(self):
        r = Runner(project_id="p", api_key="k")
        assert r._worktree_config.enabled is False

    def test_enabled_via_config(self):
        cfg = WorktreeConfig(enabled=True)
        r = Runner(project_id="p", api_key="k", worktree_config=cfg)
        assert r._worktree_config.enabled is True
        assert r._worktree_config.provider == "worktrunk"

    def test_legacy_provider(self):
        cfg = WorktreeConfig(enabled=True, provider="claude")
        r = Runner(project_id="p", api_key="k", worktree_config=cfg)
        assert r._worktree_config.provider == "claude"

    def test_cleanup_defaults(self):
        cfg = WorktreeConfig(enabled=True)
        assert cfg.cleanup_on_complete is True
        assert cfg.cleanup_on_failure is False

    def test_copy_gitignored_defaults(self):
        cfg = WorktreeConfig(enabled=True)
        assert ".env" in cfg.copy_gitignored
        assert ".env.local" in cfg.copy_gitignored

    def test_pre_merge_checks_empty_by_default(self):
        cfg = WorktreeConfig(enabled=True)
        assert cfg.pre_merge_checks == []


class TestRunnerEvidenceConfig:
    def test_enabled_by_default(self):
        r = Runner(project_id="p", api_key="k")
        assert r._evidence_config.enabled is True
        assert r._evidence_config.assets_dir == ".steerdev/evidence"

    def test_enabled_via_config(self):
        cfg = EvidenceConfig(enabled=True)
        r = Runner(project_id="p", api_key="k", evidence_config=cfg)
        assert r._evidence_config.enabled is True

    def test_disabled_via_config(self):
        cfg = EvidenceConfig(enabled=False)
        r = Runner(project_id="p", api_key="k", evidence_config=cfg)
        assert r._evidence_config.enabled is False
