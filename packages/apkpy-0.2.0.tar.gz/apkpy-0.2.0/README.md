# 🚀 ApkPy — Build Android UIs with Pure Python
ApkPy is a lightweight framework designed to bridge the gap between Python logic and Native Android UI. It translates your Python code directly into Production-Ready Java, allowing you to structure Android activities without touching a single line of XML or Java manually.

🔥 Key Features
⚡ Zero XML: Forget about complex layout files. Define your UI in Python, and let ApkPy handle the Java generation.

📱 Native Components: Not a web-view! These are real Android native components.

🎨 Style Integration: Built-in CSS-like parser to handle your app's look and feel.

🛠️ CLI Powered: Use the built-in command line interface to scaffold and build your projects instantly.

🏗️ Supported UI Elements
Text: text("Hello") — Renders as an Android TextView.

Button: button("Click Me") — Renders as an Android Button.

Input: input_field(type="text") — Renders as a standard EditText.

Password: input_field(type="password") — Renders as an EditText with secure masking.

Search: input_field(type="search") — Renders as a native SearchView.

Range: input_field(type="range") — Renders as an Android SeekBar.

Checkbox: input_field(type="checkbox") — Renders as a native CheckBox.

Radio: input_field(type="radio") — Renders as a native RadioButton.

💻 Fast Example
Python
from apkpy_lib.ui import text, button, input_field
from apkpy_lib.core.compiler import Compiler

# Define your layout
my_app = [
    text("Welcome to ApkPy", id="title"),
    input_field(id="user_login", type="text", placeholder="Username"),
    input_field(id="user_pass", type="password", placeholder="Password"),
    button("Login", id="login_btn")
]

# Compile to Native Java
compiler = Compiler(output_dir="my_android_project")
compiler.compile(my_app)
📥 Installation

pip install apkpy
To upgrade to the latest version (0.1.1) with new input types:

pip install --upgrade apkpy