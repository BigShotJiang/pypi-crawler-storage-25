import re

def parse_css(css_text):
    styles = {}
    # Procura blocos tipo: nome { propriedades }
    blocks = re.findall(r'(\w+)\s*{(.*?)}', css_text, re.DOTALL)
    
    for name, content in blocks:
        props = {}
        # Procura cada linha tipo: color: red;
        lines = re.findall(r'([\w-]+)\s*:\s*(.*?);', content)
        for key, value in lines:
            props[key.strip()] = value.strip()
        styles[name.strip()] = props
    return styles