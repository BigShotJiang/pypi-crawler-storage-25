import ast
import re
import os

from .style_parser import parse_css

def _parse_radius(style_dict):
    raw = style_dict.get('border-radius', '0')
    cleaned = re.sub(r'[^0-9.]', '', str(raw))
    try:
        return int(float(cleaned))
    except (ValueError, TypeError):
        return 0

def _get_style_bg(style_dict):
    return style_dict.get('background-color') or style_dict.get('backgroundcolor')

def _get_style_fg(style_dict):
    return style_dict.get('color')

def _get_style_border_color(style_dict):
    val = style_dict.get('border-color')
    if val and val.lower() == 'none':
        return 'none'
    elif val:
        return _resolve_color(val)
    return None

def _resolve_color(c):
    if not c: return "#d9d9d9"
    c_lower = c.lower()
    mapping = {
        'blue': '#0000FF', 'red': '#FF0000', 'green': '#00FF00',
        'yellow': '#FFFF00', 'black': '#000000', 'white': '#FFFFFF',
        'grey': '#808080', 'gray': '#808080', 'darkblue': '#00008B'
    }
    return mapping.get(c_lower, c)

def _generate_drawable_xml(bg_color, radius_px, border_color=None):
    lines = [
        '<?xml version="1.0" encoding="utf-8"?>',
        '<shape xmlns:android="http://schemas.android.com/apk/res/android">',
        f'    <solid android:color="{bg_color}" />',
        f'    <corners android:radius="{radius_px}dp" />'
    ]
    
    if border_color is None:
        lines.append('    <stroke android:width="1dp" android:color="#808080" />')
    elif border_color != 'none':
        lines.append(f'    <stroke android:width="1dp" android:color="{border_color}" />')

    lines.append('    <padding android:left="10dp" android:top="5dp" android:right="10dp" android:bottom="5dp" />')
    lines.append('</shape>')
    return "\\n".join(lines)


# ─── Legacy Single-Screen Transpiler ──────────────────────────────────────────

class JavaTranspiler(ast.NodeVisitor):
    def __init__(self, styles=None):
        self.java_lines = []
        self.counter = 0
        self.input_counter = 0
        self.styles = styles or {}
        self.drawables = {}

    def visit_Call(self, node):
        # ── BUTTON ────────────────────────────────────────────────────────────
        if isinstance(node.func, ast.Name) and node.func.id == 'button':
            self.counter += 1
            button_id = None
            for kw in node.keywords:
                if kw.arg == 'id':
                    button_id = kw.value.value

            label = node.args[0].value
            var_name = f"btn{self.counter}"

            java_code  = f'\n        Button {var_name} = new Button(this);'
            java_code += f'\n        {var_name}.setText("{label}");'

            if button_id in self.styles:
                s = self.styles[button_id]
                radius = _parse_radius(s)
                if radius > 0:
                    bg = _get_style_bg(s)
                    color = _resolve_color(bg)
                    bc = _get_style_border_color(s)
                    drawable_name = f"{button_id}_shape"
                    self.drawables[f"res/drawable/{drawable_name}.xml"] = _generate_drawable_xml(color, radius, border_color=bc)
                    java_code += f'\n        {var_name}.setBackgroundResource(R.drawable.{drawable_name});'
                elif 'background-color' in s or 'backgroundcolor' in s:
                    bg = _get_style_bg(s)
                    color_macro = bg.upper() if bg.lower() in ('blue', 'red', 'green', 'black', 'white', 'yellow') else 'BLUE'
                    java_code += f'\n        {var_name}.setBackgroundColor(android.graphics.Color.{color_macro});'
                    
                if 'color' in s:
                    java_code += f'\n        {var_name}.setTextColor(android.graphics.Color.WHITE);'

            java_code += f'\n        layout.addView({var_name});'
            self.java_lines.append(java_code)

        # ── INPUTS ────────────────────────────────────────────────────────────
        elif isinstance(node.func, ast.Name) and node.func.id in ('inputs', 'input_field'):
            self.input_counter += 1
            placeholder = node.args[0].value if node.args else ""
            input_id   = None
            input_type = "text"

            for kw in node.keywords:
                if kw.arg == 'id':
                    input_id = kw.value.value
                elif kw.arg == 'type':
                    input_type = kw.value.value

            var_name   = f"input{self.input_counter}"
            style_code = ""
            if input_id and input_id in self.styles:
                s = self.styles[input_id]
                radius = _parse_radius(s)
                if radius > 0:
                    bg = _get_style_bg(s)
                    color = _resolve_color(bg)
                    bc = _get_style_border_color(s)
                    drawable_name = f"{input_id}_shape"
                    self.drawables[f"res/drawable/{drawable_name}.xml"] = _generate_drawable_xml(color, radius, border_color=bc)
                    style_code += f'\n        {var_name}.setBackgroundResource(R.drawable.{drawable_name});'
                elif 'background-color' in s or 'backgroundcolor' in s:
                    bg = _get_style_bg(s)
                    color_macro = bg.upper() if bg.lower() in ('blue', 'red', 'green', 'black', 'white', 'yellow') else 'BLUE'
                    style_code += f'\n        {var_name}.setBackgroundColor(android.graphics.Color.{color_macro});'
                    
                if 'color' in s:
                    style_code += f'\n        {var_name}.setTextColor(android.graphics.Color.BLACK);'

            if input_type in ("text", "password", "search"):
                java_code  = f'\n        EditText {var_name} = new EditText(this);'
                java_code += f'\n        {var_name}.setHint("{placeholder}");'
                if input_type == "password":
                    java_code += (f'\n        {var_name}.setInputType('
                                  f'android.text.InputType.TYPE_CLASS_TEXT | '
                                  f'android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);')
                else:
                    java_code += f'\n        {var_name}.setInputType(android.text.InputType.TYPE_CLASS_TEXT);'
            elif input_type == "checkbox":
                java_code  = f'\n        CheckBox {var_name} = new CheckBox(this);'
                java_code += f'\n        {var_name}.setText("{placeholder}");'
            elif input_type == "range":
                java_code  = f'\n        SeekBar {var_name} = new SeekBar(this);'
                java_code += f'\n        {var_name}.setMax(100);'
            elif input_type == "radio":
                options   = [o.strip() for o in placeholder.split("|")] if placeholder else ["Opção 1", "Opção 2"]
                java_code = f'\n        RadioGroup {var_name}Group = new RadioGroup(this);'
                for i, opt in enumerate(options):
                    rb_var = f"{var_name}_rb{i}"
                    java_code += f'\n        RadioButton {rb_var} = new RadioButton(this);'
                    java_code += f'\n        {rb_var}.setText("{opt}");'
                    java_code += f'\n        {var_name}Group.addView({rb_var});'
                java_code += f'\n        layout.addView({var_name}Group);'
                self.java_lines.append(java_code)
                self.generic_visit(node)
                return
            else:
                java_code  = f'\n        EditText {var_name} = new EditText(this);'
                java_code += f'\n        {var_name}.setHint("{placeholder}");'

            java_code += style_code
            java_code += f'\n        layout.addView({var_name});'
            self.java_lines.append(java_code)

        self.generic_visit(node)


def translate_python_to_java(python_code):
    """Traduz código Python single-screen para o corpo de uma MainActivity Java."""
    try:
        import re
        style_match = re.search(r'style\s*=\s*"""(.*?)"""', python_code, re.DOTALL)
        styles = {}
        clean_code = python_code

        if style_match:
            styles     = parse_css(style_match.group(1))
            clean_code = python_code.replace(style_match.group(0), "")

        tree = ast.parse(clean_code)
        transpiler = JavaTranspiler(styles=styles)
        transpiler.visit(tree)

        if not transpiler.java_lines:
            return "        // Nenhum componente detectado", transpiler.drawables
        return "\n".join(transpiler.java_lines), transpiler.drawables

    except Exception as e:
        return f"        // Erro na tradução: {str(e)}", {}


# ─── Multi-Screen Transpiler ──────────────────────────────────────────────────

class MultiScreenTranspiler(ast.NodeVisitor):
    """
    Analisa código Python com Screens e constrói um modelo de dados
    que depois é usado para gerar múltiplos ficheiros Java/XML.
    """

    def __init__(self, styles=None):
        self.styles = styles or {}
        # var_name (Python) -> screen_id
        self.screens = {}
        # screen_id -> lista de dicts de componentes
        self.screen_components = {}
        # var_name -> dict do componente (para resolver on_click_navigate)
        self.component_vars = {}
        # lista de {from_screen_id, button_py_var, to_screen_id}
        self.navigations = []
        self.start_screen_id = None

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _kw(self, keywords, name, default=None):
        """Extrai o valor de um keyword argument por nome."""
        for kw in keywords:
            if kw.arg == name:
                if isinstance(kw.value, ast.Constant):
                    return kw.value.value
                elif isinstance(kw.value, ast.Name):
                    return kw.value.id  # devolve o nome da variável
        return default

    def _parse_component_call(self, comp_type, call, py_var=None):
        """
        Extrai info de uma chamada de componente e associa ao Screen correto.
        Devolve o dict do componente ou None se não tiver screen=.
        """
        screen_var = self._kw(call.keywords, 'screen')
        if screen_var is None:
            return None  # modo legado, sem Screen

        screen_id = self.screens.get(screen_var)
        if screen_id is None:
            return None

        comp = {'comp_type': comp_type, 'screen_id': screen_id, '_py_var': py_var}

        if comp_type == 'button':
            comp['text']       = call.args[0].value if call.args else ''
            comp['id']         = self._kw(call.keywords, 'id')
        elif comp_type in ('inputs', 'input_field'):
            comp['placeholder'] = call.args[0].value if call.args else ''
            comp['id']          = self._kw(call.keywords, 'id')
            comp['input_type']  = self._kw(call.keywords, 'type', 'text')
            # Suporte a password=True (sintaxe alternativa)
            for kw in call.keywords:
                if kw.arg == 'password' and isinstance(kw.value, ast.Constant) and kw.value.value:
                    comp['input_type'] = 'password'
        elif comp_type == 'label':
            comp['text'] = call.args[0].value if call.args else ''
            comp['id']   = self._kw(call.keywords, 'id')

        self.screen_components.setdefault(screen_id, []).append(comp)

        if py_var:
            self.component_vars[py_var] = comp

        return comp

    # ── Visitors ──────────────────────────────────────────────────────────────

    def visit_Assign(self, node):
        if not node.targets or not isinstance(node.targets[0], ast.Name):
            self.generic_visit(node)
            return

        var_name = node.targets[0].id
        value    = node.value

        if not isinstance(value, ast.Call):
            self.generic_visit(node)
            return

        func = value.func

        # login_screen = Screen(id="login")
        if isinstance(func, ast.Name) and func.id == 'Screen':
            screen_id = self._kw(value.keywords, 'id', var_name)
            self.screens[var_name] = screen_id
            self.screen_components.setdefault(screen_id, [])

        # btn = button("Entrar", screen=login_screen)
        elif isinstance(func, ast.Name) and func.id in ('button', 'inputs', 'input_field', 'label'):
            self._parse_component_call(func.id, value, py_var=var_name)

        self.generic_visit(node)

    def visit_Expr(self, node):
        if not isinstance(node.value, ast.Call):
            self.generic_visit(node)
            return

        call = node.value
        func = call.func

        # Chamadas standalone: label("...", screen=x), inputs("...", screen=x)
        if isinstance(func, ast.Name) and func.id in ('button', 'inputs', 'input_field', 'label'):
            self._parse_component_call(func.id, call)

        # login_screen.on_click_navigate(button=btn_entrar, to=dashboard_screen)
        elif isinstance(func, ast.Attribute) and func.attr == 'on_click_navigate':
            from_screen_var = func.value.id if isinstance(func.value, ast.Name) else None
            button_py_var   = self._kw(call.keywords, 'button')
            to_screen_var   = self._kw(call.keywords, 'to')

            if from_screen_var and button_py_var and to_screen_var:
                from_screen_id = self.screens.get(from_screen_var)
                to_screen_id   = self.screens.get(to_screen_var)
                if from_screen_id and to_screen_id:
                    self.navigations.append({
                        'from_screen_id': from_screen_id,
                        'button_py_var':  button_py_var,
                        'to_screen_id':   to_screen_id,
                    })

        # run(start_screen=login_screen)
        elif isinstance(func, ast.Name) and func.id == 'run':
            start_var = self._kw(call.keywords, 'start_screen')
            if start_var:
                self.start_screen_id = self.screens.get(start_var)

        self.generic_visit(node)


# ─── Java / XML / Manifest generators ────────────────────────────────────────

def _generate_activity_java(screen_id, components, navigations, start_screen_id,
                             package="com.apkpy.app"):
    """Gera o conteúdo completo de um ficheiro *Activity.java para um Screen."""

    class_name = f"Screen_{screen_id}Activity"

    # Descobrir quais imports são necessários
    types = {c.get('input_type', '') for c in components if c['comp_type'] in ('inputs', 'input_field')}
    has_button    = any(c['comp_type'] == 'button' for c in components)
    has_edittext  = bool(types & {'text', 'password', 'search'})
    has_textview  = any(c['comp_type'] == 'label' for c in components)
    has_checkbox  = 'checkbox' in types
    has_seekbar   = 'range' in types
    has_radio     = 'radio' in types
    has_nav       = any(n['from_screen_id'] == screen_id for n in navigations)

    imports = [
        f"import {package}.R;",
        "import android.os.Bundle;",
        "import android.view.View;",
        "import android.widget.LinearLayout;",
        "import androidx.appcompat.app.AppCompatActivity;",
    ]
    if has_button:    imports.append("import android.widget.Button;")
    if has_edittext:  imports.append("import android.widget.EditText;")
    if has_textview:  imports.append("import android.widget.TextView;")
    if has_checkbox:  imports.append("import android.widget.CheckBox;")
    if has_seekbar:   imports.append("import android.widget.SeekBar;")
    if has_radio:
        imports += ["import android.widget.RadioGroup;", "import android.widget.RadioButton;"]
    if has_nav:       imports.append("import android.content.Intent;")

    lines = []
    lines.append(f"package {package};")
    lines.append("")
    lines.extend(sorted(set(imports)))
    lines.append("")
    lines.append(f"public class {class_name} extends AppCompatActivity {{")
    lines.append("")
    lines.append("    @Override")
    lines.append("    protected void onCreate(Bundle savedInstanceState) {")
    lines.append("        super.onCreate(savedInstanceState);")
    lines.append("")
    lines.append("        LinearLayout layout = new LinearLayout(this);")
    lines.append("        layout.setOrientation(LinearLayout.VERTICAL);")
    lines.append("        layout.setPadding(40, 40, 40, 40);")
    lines.append("        setContentView(layout);")
    lines.append("")

    # Contadores para nomes de variáveis Java
    btn_n = lbl_n = inp_n = 0

    for comp in components:
        ctype = comp['comp_type']

        if ctype == 'button':
            btn_n += 1
            jv = f"btn{btn_n}"
            comp['_java_var'] = jv
            lines.append(f"        Button {jv} = new Button(this);")
            lines.append(f"        {jv}.setText(\"{comp['text']}\");")
            if comp.get('_drawable'):
                lines.append(f"        {jv}.setBackgroundResource(R.drawable.{comp['_drawable']});")
            lines.append(f"        layout.addView({jv});")
            lines.append("")

        elif ctype == 'label':
            lbl_n += 1
            jv = f"lbl{lbl_n}"
            comp['_java_var'] = jv
            lines.append(f"        TextView {jv} = new TextView(this);")
            lines.append(f"        {jv}.setText(\"{comp['text']}\");")
            lines.append(f"        {jv}.setTextSize(16);")
            lines.append(f"        layout.addView({jv});")
            lines.append("")

        elif ctype in ('inputs', 'input_field'):
            inp_n += 1
            jv          = f"inp{inp_n}"
            comp['_java_var'] = jv
            itype       = comp.get('input_type', 'text')
            placeholder = comp.get('placeholder', '')

            if itype in ('text', 'password', 'search'):
                lines.append(f"        EditText {jv} = new EditText(this);")
                lines.append(f"        {jv}.setHint(\"{placeholder}\");")
                if itype == 'password':
                    lines.append(f"        {jv}.setInputType(android.text.InputType.TYPE_CLASS_TEXT "
                                 f"| android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);")
                else:
                    lines.append(f"        {jv}.setInputType(android.text.InputType.TYPE_CLASS_TEXT);")
                if comp.get('_drawable'):
                    lines.append(f"        {jv}.setBackgroundResource(R.drawable.{comp['_drawable']});")
                lines.append(f"        layout.addView({jv});")
                lines.append("")

            elif itype == 'checkbox':
                lines.append(f"        CheckBox {jv} = new CheckBox(this);")
                lines.append(f"        {jv}.setText(\"{placeholder}\");")
                lines.append(f"        layout.addView({jv});")
                lines.append("")

            elif itype == 'range':
                lines.append(f"        SeekBar {jv} = new SeekBar(this);")
                lines.append(f"        {jv}.setMax(100);")
                lines.append(f"        layout.addView({jv});")
                lines.append("")

            elif itype == 'radio':
                options = [o.strip() for o in placeholder.split('|')] if placeholder else ['Opção 1', 'Opção 2']
                lines.append(f"        RadioGroup {jv}Group = new RadioGroup(this);")
                for i, opt in enumerate(options):
                    rb = f"{jv}_rb{i}"
                    lines.append(f"        RadioButton {rb} = new RadioButton(this);")
                    lines.append(f"        {rb}.setText(\"{opt}\");")
                    lines.append(f"        {rb}Group.addView({rb});")
                lines.append(f"        layout.addView({jv}Group);")
                lines.append("")

    # OnClickListeners de navegação
    for nav in navigations:
        if nav['from_screen_id'] != screen_id:
            continue

        btn_py_var  = nav['button_py_var']
        to_class    = f"Screen_{nav['to_screen_id']}Activity"

        # Encontrar o Java var do botão pelo Python var
        btn_java_var = None
        for comp in components:
            if comp.get('_py_var') == btn_py_var:
                btn_java_var = comp.get('_java_var')
                break

        if btn_java_var:
            lines.append(f"        {btn_java_var}.setOnClickListener(new View.OnClickListener() {{")
            lines.append(f"            @Override")
            lines.append(f"            public void onClick(View v) {{")
            lines.append(f"                Intent intent = new Intent({class_name}.this, {to_class}.class);")
            lines.append(f"                startActivity(intent);")
            lines.append(f"            }}")
            lines.append(f"        }});")
            lines.append("")

    lines.append("    }")
    lines.append("}")
    return "\n".join(lines)


def _generate_layout_xml(screen_id, components):
    """Gera o conteúdo de um ficheiro activity_screen_<id>.xml."""
    lines = [
        '<?xml version="1.0" encoding="utf-8"?>',
        '<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"',
        '    android:layout_width="match_parent"',
        '    android:layout_height="match_parent"',
        '    android:orientation="vertical"',
        '    android:padding="16dp">',
        '',
    ]

    lbl_n = btn_n = inp_n = 0

    for comp in components:
        ctype = comp['comp_type']

        if ctype == 'label':
            lbl_n += 1
            lines += [
                f'    <TextView',
                f'        android:id="@+id/lbl{lbl_n}"',
                f'        android:layout_width="match_parent"',
                f'        android:layout_height="wrap_content"',
                f'        android:text="{comp["text"]}"',
                f'        android:textSize="16sp" />',
                '',
            ]

        elif ctype == 'button':
            btn_n += 1
            attr_bg = f'\\n        android:background="@drawable/{comp["_drawable"]}"' if comp.get('_drawable') else ''
            lines += [
                f'    <Button',
                f'        android:id="@+id/btn{btn_n}"',
                f'        android:layout_width="match_parent"',
                f'        android:layout_height="wrap_content"',
                f'        android:text="{comp["text"]}"{attr_bg} />',
                '',
            ]

        elif ctype in ('inputs', 'input_field'):
            inp_n += 1
            itype       = comp.get('input_type', 'text')
            placeholder = comp.get('placeholder', '')

            if itype in ('text', 'search'):
                attr_bg = f'\\n        android:background="@drawable/{comp["_drawable"]}"' if comp.get('_drawable') else ''
                lines += [
                    f'    <EditText',
                    f'        android:id="@+id/inp{inp_n}"',
                    f'        android:layout_width="match_parent"',
                    f'        android:layout_height="wrap_content"',
                    f'        android:hint="{placeholder}"{attr_bg} />',
                    '',
                ]
            elif itype == 'password':
                attr_bg = f'\\n        android:background="@drawable/{comp["_drawable"]}"' if comp.get('_drawable') else ''
                lines += [
                    f'    <EditText',
                    f'        android:id="@+id/inp{inp_n}"',
                    f'        android:layout_width="match_parent"',
                    f'        android:layout_height="wrap_content"',
                    f'        android:hint="{placeholder}"',
                    f'        android:inputType="textPassword"{attr_bg} />',
                    '',
                ]
            elif itype == 'checkbox':
                lines += [
                    f'    <CheckBox',
                    f'        android:id="@+id/inp{inp_n}"',
                    f'        android:layout_width="match_parent"',
                    f'        android:layout_height="wrap_content"',
                    f'        android:text="{placeholder}" />',
                    '',
                ]
            elif itype == 'range':
                lines += [
                    f'    <SeekBar',
                    f'        android:id="@+id/inp{inp_n}"',
                    f'        android:layout_width="match_parent"',
                    f'        android:layout_height="wrap_content"',
                    f'        android:max="100" />',
                    '',
                ]
            elif itype == 'radio':
                options = [o.strip() for o in placeholder.split('|')] if placeholder else ['Opção 1', 'Opção 2']
                lines.append(f'    <RadioGroup')
                lines.append(f'        android:id="@+id/inp{inp_n}Group"')
                lines.append(f'        android:layout_width="match_parent"')
                lines.append(f'        android:layout_height="wrap_content">')
                for i, opt in enumerate(options):
                    lines += [
                        f'        <RadioButton',
                        f'            android:id="@+id/inp{inp_n}_rb{i}"',
                        f'            android:layout_width="wrap_content"',
                        f'            android:layout_height="wrap_content"',
                        f'            android:text="{opt}" />',
                    ]
                lines += ['    </RadioGroup>', '']

    lines.append('</LinearLayout>')
    return "\n".join(lines)


def _generate_manifest(screen_ids, start_screen_id, package="com.apkpy.app"):
    """Gera o conteúdo do AndroidManifest.xml com todas as Activities."""
    lines = [
        '<?xml version="1.0" encoding="utf-8"?>',
        f'<manifest xmlns:android="http://schemas.android.com/apk/res/android"',
        f'    package="{package}">',
        '',
        '    <application',
        '        android:allowBackup="true"',
        '        android:label="ApkPy App"',
        '        android:supportsRtl="true"',
        '        android:theme="@style/Theme.AppCompat.Light.DarkActionBar">',
        '',
    ]

    for sid in screen_ids:
        class_name = f"Screen_{sid}Activity"
        if sid == start_screen_id:
            lines += [
                f'        <activity android:name=".{class_name}" android:exported="true">',
                f'            <intent-filter>',
                f'                <action android:name="android.intent.action.MAIN" />',
                f'                <category android:name="android.intent.category.LAUNCHER" />',
                f'            </intent-filter>',
                f'        </activity>',
                '',
            ]
        else:
            lines.append(f'        <activity android:name=".{class_name}" />')
            lines.append('')

    lines += ['    </application>', '', '</manifest>']
    return "\n".join(lines)


# ─── Public multi-screen entry point ─────────────────────────────────────────

def translate_python_to_android(python_code, package="com.apkpy.app"):
    """
    Analisa código Python com múltiplos Screens e devolve um dicionário
    com todos os ficheiros gerados:

        {
          "java/Screen_loginActivity.java":     "...",
          "java/Screen_dashboardActivity.java": "...",
          "res/layout/activity_screen_login.xml": "...",
          "res/layout/activity_screen_dashboard.xml": "...",
          "AndroidManifest.xml": "...",
        }

    Retorna None se não encontrar nenhum Screen no código.
    """
    try:
        # Remover bloco style = \"\"\" ... \"\"\" antes de parsear o AST
        style_match = re.search(r'style\s*=\s*"""(.*?)"""', python_code, re.DOTALL)
        styles     = {}
        clean_code = python_code
        if style_match:
            styles     = parse_css(style_match.group(1))
            clean_code = python_code.replace(style_match.group(0), "")

        tree        = ast.parse(clean_code)
        transpiler  = MultiScreenTranspiler(styles=styles)
        transpiler.visit(tree)

        if not transpiler.screens:
            return None  # sem Screens → modo legado

        screen_ids      = list(transpiler.screens.values())
        start_screen_id = transpiler.start_screen_id or screen_ids[0]
        output_files    = {}

        for sid in screen_ids:
            components = transpiler.screen_components.get(sid, [])
            
            for comp in components:
                comp_id = comp.get('id')
                if comp_id and comp_id in styles:
                    radius = _parse_radius(styles[comp_id])
                    if radius > 0:
                        bg = _get_style_bg(styles[comp_id])
                        color = _resolve_color(bg)
                        bc = _get_style_border_color(styles[comp_id])
                        drawable_name = f"{comp_id}_shape"
                        comp['_drawable'] = drawable_name
                        output_files[f"res/drawable/{drawable_name}.xml"] = _generate_drawable_xml(color, radius, border_color=bc)

            # Java Activity
            java_content = _generate_activity_java(
                sid, components, transpiler.navigations, start_screen_id, package
            )
            output_files[f"java/Screen_{sid}Activity.java"] = java_content

            # XML Layout
            xml_content = _generate_layout_xml(sid, components)
            output_files[f"res/layout/activity_screen_{sid}.xml"] = xml_content

        # AndroidManifest
        output_files["AndroidManifest.xml"] = _generate_manifest(
            screen_ids, start_screen_id, package
        )

        return output_files

    except Exception as e:
        return {"error.txt": f"Erro na tradução multi-screen: {str(e)}"}