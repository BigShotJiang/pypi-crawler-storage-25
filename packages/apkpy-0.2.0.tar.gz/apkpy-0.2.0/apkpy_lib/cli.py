import click
import os
import zipfile
import shutil

from .core.compiler import translate_python_to_java, translate_python_to_android


@click.group()
def main():
    """APKPy: Transforme Python em Projetos Android (APK)"""
    pass


@main.command()
@click.argument('name')
def start(name):
    """Cria um novo projeto: apkpy start meu_projeto"""
    click.echo(f"Criando o projeto: {name}...")

    current_dir  = os.getcwd()
    project_path = os.path.join(current_dir, name)

    if not os.path.exists(project_path):
        os.makedirs(project_path)
        with open(os.path.join(project_path, "writehere.py"), "w") as f:
            f.write(
                "from apkpy_lib.ui import Screen, button, label, inputs, run\n\n"
                "# --- Ecrã de Início ---\n"
                "home = Screen(id=\"home\")\n"
                "label(\"Olá, ApkPy!\", screen=home)\n"
                "button(\"Continuar\", screen=home)\n\n"
                "run(start_screen=home)\n"
            )
        click.echo(f"Sucesso! Entre na pasta '{name}' e edite o writehere.py")
    else:
        click.echo("Erro: Essa pasta já existe.")


@main.command()
def build():
    """Compila o código e gera o ZIP pronto para o Android Studio"""
    file_path    = "writehere.py"
    template_path = os.path.join(os.path.dirname(__file__), "templates/android_project")
    build_dir    = "build_temp"

    if not os.path.exists(file_path):
        click.echo("Erro: writehere.py não encontrado.")
        return

    with open(file_path, "r", encoding="utf-8") as f:
        python_code = f.read()

    # ── Tenta o modo Multi-Screen primeiro ────────────────────────────────────
    multi_files = translate_python_to_android(python_code)

    if multi_files and "error.txt" not in multi_files:
        click.echo("📱  Modo Multi-Screen detetado — gerando Activities separadas...")

        if os.path.exists(build_dir):
            shutil.rmtree(build_dir)
        shutil.copytree(template_path, build_dir)

        java_dir     = os.path.join(build_dir, "app/src/main/java/com/apkpy/app")
        layout_dir   = os.path.join(build_dir, "app/src/main/res/layout")
        drawable_dir = os.path.join(build_dir, "app/src/main/res/drawable")
        os.makedirs(java_dir,   exist_ok=True)
        os.makedirs(layout_dir, exist_ok=True)
        os.makedirs(drawable_dir, exist_ok=True)

        for rel_path, content in multi_files.items():
            if rel_path.startswith("java/"):
                out = os.path.join(java_dir, os.path.basename(rel_path))
            elif rel_path.startswith("res/layout/"):
                out = os.path.join(layout_dir, os.path.basename(rel_path))
            elif rel_path.startswith("res/drawable/"):
                out = os.path.join(drawable_dir, os.path.basename(rel_path))
            elif rel_path == "AndroidManifest.xml":
                out = os.path.join(build_dir, "app/src/main/AndroidManifest.xml")
            else:
                out = os.path.join(build_dir, rel_path)

            with open(out, "w", encoding="utf-8") as f:
                f.write(content)
            click.echo(f"   ✅  {os.path.basename(out)}")

    else:
        # ── Fallback: Single-Screen (MainActivity) ────────────────────────────
        click.echo("📄  Modo Single-Screen — gerando MainActivity...")

        java_code, drawables = translate_python_to_java(python_code)

        if os.path.exists(build_dir):
            shutil.rmtree(build_dir)
        shutil.copytree(template_path, build_dir)

        drawable_dir = os.path.join(build_dir, "app/src/main/res/drawable")
        if drawables:
            os.makedirs(drawable_dir, exist_ok=True)
            for path, content in drawables.items():
                out = os.path.join(build_dir, "app/src/main", path)
                with open(out, "w", encoding="utf-8") as f:
                    f.write(content)
                click.echo(f"   🎨  {os.path.basename(out)}")

        main_activity_path = os.path.join(
            build_dir,
            "app/src/main/java/com/exemplo/MainActivity.java"
        )
        with open(main_activity_path, "r") as f:
            content = f.read()

        new_content = content.replace("// INJECT_CODE_HERE", java_code)

        with open(main_activity_path, "w") as f:
            f.write(new_content)

    # ── Gerar ZIP final ───────────────────────────────────────────────────────
    shutil.make_archive("meu_app_android", 'zip', build_dir)
    shutil.rmtree(build_dir)

    click.echo("\n🚀  Sucesso! Arquivo 'meu_app_android.zip' gerado.")
    click.echo("     Agora é só extrair e abrir no Android Studio.")