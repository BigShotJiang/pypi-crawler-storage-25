//! HTTP/1.1 listener + request parser for the hand-rolled event loop.
//!
//! Uses `httparse` for zero-copy header parsing (same library hyper uses).
//! Wraps `mio::net::TcpListener` bound on the HTTP data-plane port.
//!
//! # Parser design
//!
//! `parse_http_request` is a synchronous, resumable parser over a `BytesMut`
//! read buffer. It returns:
//! - `Ok(Some((WireRequest, keep_alive)))` — a complete request was consumed.
//! - `Ok(None)` — not enough bytes yet; caller reads more and retries.
//! - `Err(ParseError)` — malformed request; caller should close the connection.
//!
//! Pipelining is handled naturally: the caller loops calling `parse_http_request`
//! until it returns `Ok(None)`, processing each `WireRequest` inline.
//!
//! # Body handling
//!
//! Two modes:
//! 1. `Content-Length: N` — read exactly N bytes after `\r\n\r\n`.
//! 2. `Transfer-Encoding: chunked` — parse chunk-size lines + data + terminator.
//!
//! For requests with no body (GET, DELETE with no Content-Length), body is empty.

use bytes::{Bytes, BytesMut};
use std::net::SocketAddr;
use thiserror::Error;

use crate::router::Router;
use crate::wire_request::WireRequest;

/// Error from the HTTP request parser.
#[derive(Debug, Error)]
pub enum ParseError {
    #[error("httparse error: {0}")]
    Httparse(#[from] httparse::Error),
    #[error("invalid Content-Length: {0}")]
    InvalidContentLength(String),
    #[error("malformed chunked encoding: {0}")]
    BadChunked(String),
    #[error("request too large")]
    TooLarge,
}

/// Maximum header size (8 KiB — matches nginx default).
const MAX_HEADER_BYTES: usize = 8 * 1024;
/// Maximum number of headers parsed by httparse.
const MAX_HEADERS: usize = 64;
/// Maximum body size (4 MiB — same as TCP max_frame_bytes default).
const MAX_BODY_BYTES: usize = 4 * 1024 * 1024;

/// Attempt to parse one complete HTTP/1.1 request from `buf`.
///
/// Returns `Ok(Some((req, keep_alive)))` when a full request (headers + body)
/// is available, advancing `buf` past the consumed bytes.
/// Returns `Ok(None)` when more bytes are needed.
/// Returns `Err(ParseError)` on protocol violation.
///
/// Supports:
/// - `Content-Length` body framing
/// - `Transfer-Encoding: chunked` body framing
/// - `Connection: keep-alive` / `Connection: close` detection
/// - Pipelining (call repeatedly until `Ok(None)`)
pub fn parse_http_request(buf: &mut BytesMut) -> Result<Option<(WireRequest, bool)>, ParseError> {
    // httparse needs a slice of Header slots pre-allocated on the stack/heap.
    let mut headers = vec![httparse::EMPTY_HEADER; MAX_HEADERS];
    let mut req = httparse::Request::new(&mut headers);

    // Guard against absurdly large headers causing an OOM probe — but ONLY
    // for header bytes. The cap MUST NOT apply to the whole buffer, or any
    // HTTP request whose headers + body combined exceed 8 KiB would be
    // rejected (even with Content-Length well within MAX_BODY_BYTES). Scan
    // for `\r\n\r\n` to decide: if present, body bytes follow and are gated
    // by Content-Length; if absent and we already have > MAX_HEADER_BYTES of
    // unfinished headers, it's a genuine header bomb.
    let header_end_found = buf.windows(4).any(|w| w == b"\r\n\r\n");
    if !header_end_found && buf.len() > MAX_HEADER_BYTES {
        return Err(ParseError::TooLarge);
    }
    let probe = buf.as_ref();

    let header_end = match req.parse(probe)? {
        httparse::Status::Complete(n) => n,
        httparse::Status::Partial => return Ok(None), // need more header bytes
    };

    // Extract the fields we need before we release the borrow on `headers`.
    let method = req.method.unwrap_or("").to_owned();
    let path = req.path.unwrap_or("").to_owned();

    // Determine keep-alive from the Connection header (default keep-alive for HTTP/1.1).
    let mut keep_alive = true; // HTTP/1.1 default
    let mut content_length: Option<usize> = None;
    let mut is_chunked = false;
    // Capture Content-Type so we can return 415 for POST endpoints when the
    // client sends a non-JSON media type. None means header was absent;
    // Some("") means header was present but empty.
    let mut content_type_header: Option<String> = None;

    for h in req.headers.iter() {
        let name_lower = h.name.to_ascii_lowercase();
        match name_lower.as_str() {
            "connection" => {
                let val = std::str::from_utf8(h.value)
                    .unwrap_or("")
                    .to_ascii_lowercase();
                if val.contains("close") {
                    keep_alive = false;
                } else if val.contains("keep-alive") {
                    keep_alive = true;
                }
            }
            "content-length" => {
                let val = std::str::from_utf8(h.value)
                    .map_err(|e| ParseError::InvalidContentLength(e.to_string()))?
                    .trim();
                content_length = Some(
                    val.parse::<usize>()
                        .map_err(|e| ParseError::InvalidContentLength(e.to_string()))?,
                );
            }
            "transfer-encoding" => {
                let val = std::str::from_utf8(h.value)
                    .unwrap_or("")
                    .to_ascii_lowercase();
                if val.contains("chunked") {
                    is_chunked = true;
                }
            }
            "content-type" => {
                content_type_header =
                    Some(std::str::from_utf8(h.value).unwrap_or("").trim().to_owned());
            }
            _ => {}
        }
    }

    // Now read the body based on framing mode.
    let body: Bytes = if is_chunked {
        // Parse chunked encoding from buf starting at header_end.
        let body_start = header_end;
        match parse_chunked_body(&buf[body_start..]) {
            ChunkedResult::Complete {
                body,
                bytes_consumed,
            } => {
                // We have a complete chunked body.
                let total = body_start + bytes_consumed;
                // Advance the buffer past headers + body.
                let _ = buf.split_to(total);
                body
            }
            ChunkedResult::Incomplete => return Ok(None),
            ChunkedResult::Error(e) => return Err(ParseError::BadChunked(e)),
        }
    } else if let Some(len) = content_length {
        if len > MAX_BODY_BYTES {
            return Err(ParseError::TooLarge);
        }
        let body_start = header_end;
        let body_end = body_start + len;
        if buf.len() < body_end {
            return Ok(None); // need more body bytes
        }
        // Advance buf past headers + body.
        let mut taken = buf.split_to(body_end);
        taken.advance(body_start);
        taken.freeze()
    } else {
        // No body framing — consume headers only.
        let _ = buf.split_to(header_end);
        Bytes::new()
    };

    // Route the parsed request.
    let route = Router::route(&method, &path);
    use crate::router::Route;
    // HTTP always carries JSON bodies (content_type = CT_JSON = 0x01).
    use beava_core::wire::CT_JSON;

    // Enforce application/json on POST /register only. Other POST endpoints
    // do not validate Content-Type and just attempt JSON parse, returning
    // 400 on failure — matching the surface tests assert against.
    let is_register_post = method.eq_ignore_ascii_case("POST") && matches!(route, Route::Register);
    if is_register_post {
        let ct_ok = match &content_type_header {
            None => false,
            Some(ct) => is_json_content_type(ct),
        };
        if !ct_ok {
            let received = content_type_header.clone().unwrap_or_default();
            return Ok(Some((
                WireRequest::HttpUnsupportedMediaType {
                    received,
                    path: path.clone(),
                },
                keep_alive,
            )));
        }
    }

    let wire_req = match route {
        Route::Push { event_name } => WireRequest::HttpPush {
            event_name,
            body,
            body_format: CT_JSON,
        },
        Route::PushSync { event_name } => WireRequest::HttpPushSync {
            event_name,
            body,
            body_format: CT_JSON,
        },
        Route::PushBatch { event_name } => WireRequest::HttpPushBatch {
            event_name,
            body,
            body_format: CT_JSON,
        },
        Route::Get => WireRequest::HttpGet { body },
        Route::GetSingle { feature, key } => WireRequest::HttpGetSingle { feature, key },
        // POST /batch_get — heterogeneous batched read; same payload shape
        // as TCP OP_BATCH_GET, JSON-only on HTTP transport.
        Route::BatchGet => WireRequest::HttpBatchGet { body },
        Route::Register => WireRequest::Register { payload: body },
        // /health on the data-plane HTTP port — inline shim, no apply-thread
        // roundtrip. read_bench.py polls /health at startup.
        Route::Health => WireRequest::HttpHealth,
        // /ready and /registry on the data-plane HTTP port — back-compat
        // shims for TestServer-using tests; the admin sidecar remains the
        // canonical home for both endpoints.
        Route::Ready => WireRequest::HttpReady,
        Route::Registry => WireRequest::HttpRegistry,
        Route::NotFound => WireRequest::HttpNotFound {
            path: path.to_owned(),
        },
        Route::MethodNotAllowed => WireRequest::HttpMethodNotAllowed {
            method: method.to_owned(),
            path: path.to_owned(),
        },
        // POST /ping is the HTTP mirror of TCP OP_PING (0x0000). The
        // dispatch layer returns the same `200 {"status":"ok"}` shape as
        // /health so fixtures can poll either endpoint interchangeably.
        Route::Ping => WireRequest::HttpPing,
        // POST /push (verb-style — event name in JSON body). Body shape is
        // `{"event":"Tx","data":{...}}`; we extract the event name and
        // synthesize the `HttpPush` variant with the inner `data` payload
        // as the body so dispatch composes with the path-segment
        // `/push/:event_name` apply path.
        Route::PushVerb => parse_verb_push(&body, /* sync = */ false),
        // POST /push-sync (verb-style) — same body shape; awaits fsync.
        Route::PushSyncVerb => parse_verb_push(&body, /* sync = */ true),
        // POST /reset (verb-style HTTP mirror of TCP OP_RESET). Body is
        // opaque (empty `{}`); the dispatch arm enforces the test_mode gate.
        Route::Reset => WireRequest::HttpReset { body },
    };

    Ok(Some((wire_req, keep_alive)))
}

/// Returns true iff the Content-Type media type (before `;`) is
/// `application/json` (case-insensitive, trimmed).
fn is_json_content_type(ct: &str) -> bool {
    let media_type = ct.split(';').next().unwrap_or("").trim();
    media_type.eq_ignore_ascii_case("application/json")
}

/// Extract `event` from the JSON body of a verb-style `POST /push` (or
/// `POST /push-sync`), then synthesize the corresponding
/// `WireRequest::HttpPush` / `HttpPushSync` carrying the inner `data`
/// payload as the body the apply path expects.
///
/// Body contract: `{"event": "<name>", "data": {<push body>}}`.
///
/// Failure modes (both surface as `WireRequest::ParseError` with a special
/// reason; the apply-shard dispatcher special-cases these reasons to emit a
/// structured 400 with `error.code` rather than the generic 501 fallback):
/// - `invalid_json_body` — body isn't valid JSON.
/// - `missing_event_name_in_body` — body parsed but lacks the `event` string.
fn parse_verb_push(body: &[u8], sync: bool) -> WireRequest {
    use beava_core::wire::CT_JSON;
    let parsed: serde_json::Value = match serde_json::from_slice(body) {
        Ok(v) => v,
        Err(_) => {
            return WireRequest::ParseError {
                reason: "invalid_json_body".to_owned(),
            };
        }
    };
    let event_name = match parsed.get("event").and_then(|v| v.as_str()) {
        Some(s) => s.to_owned(),
        None => {
            return WireRequest::ParseError {
                reason: "missing_event_name_in_body".to_owned(),
            };
        }
    };
    // Re-serialise the inner `data` payload — dispatch expects the push
    // body to be the bare event payload (matching `/push/:event_name`
    // semantics). Default to `{}` when absent so a schemaless event (no
    // fields) still flows through validation.
    let data = parsed
        .get("data")
        .cloned()
        .unwrap_or(serde_json::Value::Object(Default::default()));
    let body_bytes = bytes::Bytes::from(serde_json::to_vec(&data).unwrap_or_default());
    if sync {
        WireRequest::HttpPushSync {
            event_name,
            body: body_bytes,
            body_format: CT_JSON,
        }
    } else {
        WireRequest::HttpPush {
            event_name,
            body: body_bytes,
            body_format: CT_JSON,
        }
    }
}

enum ChunkedResult {
    Complete { body: Bytes, bytes_consumed: usize },
    Incomplete,
    Error(String),
}

/// Parse a complete chunked-encoded body from a byte slice.
///
/// Chunk format: `<hex-size>\r\n<data>\r\n` ... `0\r\n\r\n`
/// We accumulate all chunk data into a Vec<u8>.
fn parse_chunked_body(data: &[u8]) -> ChunkedResult {
    let mut pos = 0;
    let mut body = Vec::new();

    loop {
        // Find the \r\n that terminates the chunk-size line.
        let line_end = match find_crlf(data, pos) {
            Some(i) => i,
            None => return ChunkedResult::Incomplete,
        };
        let size_str = match std::str::from_utf8(&data[pos..line_end]) {
            Ok(s) => s.trim(),
            Err(_) => return ChunkedResult::Error("non-UTF8 chunk size line".to_owned()),
        };

        // Strip optional chunk extensions (everything after ';').
        let size_str = size_str.split(';').next().unwrap_or("").trim();

        let chunk_size = match usize::from_str_radix(size_str, 16) {
            Ok(n) => n,
            Err(e) => return ChunkedResult::Error(format!("bad chunk size '{size_str}': {e}")),
        };

        // Advance past the size line + CRLF.
        pos = line_end + 2;

        if chunk_size == 0 {
            // Final chunk — need the trailing \r\n.
            if data.len() < pos + 2 {
                return ChunkedResult::Incomplete;
            }
            // Consume the trailing \r\n.
            pos += 2;
            return ChunkedResult::Complete {
                body: Bytes::from(body),
                bytes_consumed: pos,
            };
        }

        // Need chunk_size bytes + trailing CRLF.
        let data_end = pos + chunk_size;
        if data.len() < data_end + 2 {
            return ChunkedResult::Incomplete;
        }
        body.extend_from_slice(&data[pos..data_end]);
        pos = data_end + 2; // skip trailing \r\n
    }
}

/// Find the byte offset of the next `\r\n` in `data` starting at `from`.
/// Returns the index of `\r` (so data[result..result+2] == b"\r\n").
fn find_crlf(data: &[u8], from: usize) -> Option<usize> {
    let slice = &data[from..];
    for i in 0..slice.len().saturating_sub(1) {
        if slice[i] == b'\r' && slice[i + 1] == b'\n' {
            return Some(from + i);
        }
    }
    None
}

// Needed for split_to + advance.
use bytes::Buf;

/// A mio-backed TCP listener for HTTP/1.1 connections.
///
/// Binds the listener and exposes `accept()` for the event loop when the
/// HTTP listener token fires. The HTTP state machine (headers + body +
/// keep-alive + chunked TE) lives in `parse_http_request` above.
pub struct HttpListener {
    inner: mio::net::TcpListener,
    local_addr: SocketAddr,
}

impl std::fmt::Debug for HttpListener {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("HttpListener")
            .field("local_addr", &self.local_addr)
            .finish()
    }
}

impl HttpListener {
    /// Bind an HTTP/1.1 listener. Port 0 = OS-assigned.
    pub fn bind(addr: SocketAddr) -> std::io::Result<Self> {
        let inner = mio::net::TcpListener::bind(addr)?;
        let local_addr = inner.local_addr()?;
        Ok(Self { inner, local_addr })
    }

    /// Construct from an already-bound `std::net::TcpListener` (must be non-blocking).
    pub fn from_std(listener: std::net::TcpListener) -> std::io::Result<Self> {
        let local_addr = listener.local_addr()?;
        let inner = mio::net::TcpListener::from_std(listener);
        Ok(Self { inner, local_addr })
    }

    /// Actual bound address.
    pub fn local_addr(&self) -> SocketAddr {
        self.local_addr
    }

    /// Accept the next pending HTTP connection.
    pub fn accept(&self) -> std::io::Result<(mio::net::TcpStream, SocketAddr)> {
        self.inner.accept()
    }

    /// Borrow the inner mio listener for event loop registration.
    pub fn inner_mut(&mut self) -> &mut mio::net::TcpListener {
        &mut self.inner
    }
}
