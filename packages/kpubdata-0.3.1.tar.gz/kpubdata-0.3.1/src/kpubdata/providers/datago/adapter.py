"""Data.go.kr adapter with curated dataset catalogue."""

from __future__ import annotations

import logging
from collections.abc import Mapping, Sequence
from typing import NoReturn, cast
from urllib.parse import urlparse

import httpx

from kpubdata.config import KPubDataConfig
from kpubdata.core.models import (
    DatasetRef,
    Query,
    RecordBatch,
    SchemaDescriptor,
)
from kpubdata.exceptions import (
    AuthError,
    DatasetNotFoundError,
    InvalidRequestError,
    ParseError,
    ProviderResponseError,
    RateLimitError,
    ServiceUnavailableError,
    TransportError,
)
from kpubdata.providers._common import build_schema_from_metadata, coerce_int, load_catalogue
from kpubdata.transport.decode import decode_json, decode_xml, detect_content_type
from kpubdata.transport.http import HttpTransport, TransportConfig

logger = logging.getLogger("kpubdata.provider.datago")

_DATAGO_403_HINT = (
    "data.go.kr returned 403. This usually means the specific API has not been activated "
    "(활용신청) for your key. Visit the dataset's page on https://www.data.go.kr and "
    "click '활용신청'. Approval is usually automatic and becomes active within a few minutes."
)


def _is_success_code(code: str) -> bool:
    """Return True for any data.go.kr resultCode that signals success.

    Different endpoint families use different widths for the "no error" code:
    "00" (most APIs) and "000" (RTMS family under apis.data.go.kr/1613000).
    Both — and any zero-valued numeric variant — should be treated as success.
    """
    try:
        return int(code) == 0
    except ValueError:
        return False


class DataGoAdapter:
    """Adapter for data.go.kr (공공데이터포털).

    Provides a curated catalogue of supported datasets from the
    apis.data.go.kr endpoint family.
    """

    def __init__(
        self,
        *,
        config: KPubDataConfig | None = None,
        transport: HttpTransport | None = None,
        catalogue: Sequence[DatasetRef] | None = None,
    ) -> None:
        self._config: KPubDataConfig = config or KPubDataConfig()
        transport_config = TransportConfig(
            timeout=self._config.timeout,
            max_retries=self._config.max_retries,
        )
        self._transport: HttpTransport = transport or HttpTransport(transport_config)

        datasets = tuple(catalogue) if catalogue is not None else self._load_default_catalogue()
        self._datasets: tuple[DatasetRef, ...] = datasets
        self._datasets_by_key: dict[str, DatasetRef] = {
            dataset.dataset_key: dataset for dataset in self._datasets
        }

    @property
    def name(self) -> str:
        """Return canonical provider key."""

        return "datago"

    def list_datasets(self) -> list[DatasetRef]:
        """List datasets available from data.go.kr."""

        return list(self._datasets)

    def search_datasets(self, text: str) -> list[DatasetRef]:
        """Search datasets available from data.go.kr."""

        needle = text.casefold()
        return [
            dataset
            for dataset in self._datasets
            if needle in dataset.id.casefold() or needle in dataset.name.casefold()
        ]

    def get_dataset(self, dataset_key: str) -> DatasetRef:
        """Resolve provider-local dataset key for data.go.kr."""

        dataset = self._datasets_by_key.get(dataset_key)
        if dataset is not None:
            return dataset

        logger.debug(
            "Datago dataset not found",
            extra={"dataset_id": f"datago.{dataset_key}", "provider": "datago"},
        )
        raise DatasetNotFoundError(
            f"Dataset not found: datago.{dataset_key}",
            provider="datago",
            dataset_id=f"datago.{dataset_key}",
        )

    def query_records(self, dataset: DatasetRef, query: Query) -> RecordBatch:
        """Query records from a data.go.kr dataset."""

        if self._is_generic(dataset):
            logger.debug(
                "Datago list called with unsupported operation (generic)",
                extra={"dataset_id": dataset.id},
            )
            raise InvalidRequestError(
                "datago.generic does not support list(); use call_raw with _base_url instead",
                provider="datago",
                dataset_id=dataset.id,
            )

        page = query.page or 1
        page_size = query.page_size or 100
        logger.debug(
            "datago query_records",
            extra={
                "dataset_id": dataset.id,
                "page": page,
                "page_size": page_size,
                "filter_keys": sorted(query.filters.keys()),
            },
        )

        url = self._build_request_url(dataset)
        params = self._build_base_params(dataset)
        params["pageNo"] = str(page)
        params["numOfRows"] = str(page_size)

        reserved = {params_key.lower() for params_key in params}
        reserved.update({"pageno", "numofrows"})
        for key, raw_value in query.filters.items():
            if key.lower() not in reserved:
                value: object = raw_value
                params[key] = str(value)

        payload = self._request_and_decode(url, params, dataset.id)
        body, items = self._validate_envelope(payload, dataset)

        total_count = coerce_int(body.get("totalCount"), 0)
        if (total_count and page * page_size < total_count) or (
            not total_count and len(items) == page_size
        ):
            computed_next = page + 1
        else:
            computed_next = None

        if not items:
            logger.debug(
                "Datago envelope: zero items",
                extra={
                    "dataset_id": dataset.id,
                    "page": page,
                    "page_size": page_size,
                    "total_count": total_count,
                },
            )

        return RecordBatch(
            items=items,
            dataset=dataset,
            total_count=total_count if total_count else None,
            next_page=computed_next,
            raw=payload,
        )

    def get_schema(self, dataset: DatasetRef) -> SchemaDescriptor | None:
        """Get schema metadata for a data.go.kr dataset.

        Returns schema from curated catalogue metadata when available.
        data.go.kr has no live schema discovery endpoint, so this
        returns ``None`` for datasets without explicitly curated field
        definitions in the catalogue.
        """
        return build_schema_from_metadata(dataset)

    def call_raw(self, dataset: DatasetRef, operation: str, params: dict[str, object]) -> object:
        """Call provider-native data.go.kr API operation.

        ``datago.generic`` is a raw-only escape hatch for data.go.kr endpoints
        that are not in the curated catalogue. It returns the raw decoded
        response (dict) — no normalization, no pagination, no schema. Callers
        must pass:
          * ``_base_url`` (str, REQUIRED): endpoint base URL up to (but not
            including) the operation name.
          * ``_envelope`` (bool, default True): when True, validate the
            standard ``response.header.resultCode`` envelope. Must be a real
            bool — strings/ints are rejected.
          * ``_service_key_param`` (str): override service-key param name.
          * ``_format_param`` (str): override response-format param name.

        A warning is logged if ``_base_url`` does not point to a
        ``*.data.go.kr`` host. The call still proceeds — this is a soft check.
        """

        logger.debug(
            "datago call_raw",
            extra={
                "dataset_id": dataset.id,
                "operation": operation,
                "param_keys": sorted(params.keys()),
            },
        )

        is_generic = self._is_generic(dataset)
        if is_generic:
            base_url_override = params.get("_base_url")
            if not isinstance(base_url_override, str) or not base_url_override:
                logger.debug(
                    "Datago.generic missing _base_url in call_raw params",
                    extra={"dataset_id": dataset.id},
                )
                raise InvalidRequestError(
                    "datago.generic requires '_base_url' to be passed in params",
                    provider="datago",
                    dataset_id=dataset.id,
                )
            envelope_flag = params.get("_envelope", True)
            if not isinstance(envelope_flag, bool):
                logger.debug(
                    "Datago.generic '_envelope' must be a bool",
                    extra={"dataset_id": dataset.id},
                )
                raise InvalidRequestError(
                    "datago.generic '_envelope' must be a bool (True or False)",
                    provider="datago",
                    dataset_id=dataset.id,
                )
            validate_envelope = envelope_flag
            service_key_param_override = params.get("_service_key_param")
            format_param_override = params.get("_format_param")

            host = urlparse(base_url_override).hostname or ""
            if not host.endswith(".data.go.kr") and host != "data.go.kr":
                logger.warning(
                    "datago.generic called with non-data.go.kr host",
                    extra={
                        "dataset_id": dataset.id,
                        "operation": operation,
                        "base_url": base_url_override,
                        "host": host,
                    },
                )

            url = f"{base_url_override.rstrip('/')}/{operation}"
            logger.debug(
                "datago.generic dispatch",
                extra={
                    "dataset_id": dataset.id,
                    "operation": operation,
                    "base_url": base_url_override,
                    "envelope": validate_envelope,
                },
            )
            request_params = self._build_base_params(
                dataset,
                service_key_param_override=(
                    service_key_param_override
                    if isinstance(service_key_param_override, str)
                    else None
                ),
                format_param_override=(
                    format_param_override if isinstance(format_param_override, str) else None
                ),
            )
            service_key_param = (
                service_key_param_override
                if isinstance(service_key_param_override, str) and service_key_param_override
                else str(dataset.raw_metadata.get("service_key_param", "serviceKey"))
            )
            magic_keys = {
                "_base_url",
                "_envelope",
                "_service_key_param",
                "_format_param",
            }
            for key, value in params.items():
                if key in magic_keys or key == service_key_param:
                    continue
                request_params[key] = str(value)

            payload = self._request_and_decode(url, request_params, dataset.id)
            if validate_envelope:
                _ = self._validate_envelope(payload, dataset)
            return payload

        url = self._build_request_url(dataset, operation)
        request_params = self._build_base_params(dataset)

        service_key_param = str(dataset.raw_metadata.get("service_key_param", "serviceKey"))
        for key, value in params.items():
            if key != service_key_param:
                request_params[key] = str(value)

        payload = self._request_and_decode(url, request_params, dataset.id)
        _ = self._validate_envelope(payload, dataset)
        return payload

    @staticmethod
    def _is_generic(dataset: DatasetRef) -> bool:
        return bool(dataset.raw_metadata.get("generic"))

    def _require_api_key(self) -> str:
        return self._config.require_provider_key("datago")

    def _build_request_url(self, dataset: DatasetRef, operation: str | None = None) -> str:
        base_url_raw = dataset.raw_metadata.get("base_url")
        if not isinstance(base_url_raw, str) or not base_url_raw:
            raise ProviderResponseError(
                "Dataset metadata missing base_url",
                provider="datago",
                dataset_id=dataset.id,
            )
        selected_operation = operation or dataset.raw_metadata.get("default_operation")
        if isinstance(selected_operation, str) and selected_operation:
            return f"{base_url_raw}/{selected_operation}"
        return base_url_raw

    def _build_base_params(
        self,
        dataset: DatasetRef,
        *,
        service_key_param_override: str | None = None,
        format_param_override: str | None = None,
    ) -> dict[str, str]:
        api_key = self._require_api_key()
        service_key_param_raw = (
            service_key_param_override
            if service_key_param_override
            else dataset.raw_metadata.get("service_key_param", "serviceKey")
        )
        format_param_raw = (
            format_param_override
            if format_param_override
            else dataset.raw_metadata.get("format_param", "resultType")
        )
        service_key_param = (
            service_key_param_raw
            if isinstance(service_key_param_raw, str) and service_key_param_raw
            else "serviceKey"
        )
        format_param = (
            format_param_raw
            if isinstance(format_param_raw, str) and format_param_raw
            else "resultType"
        )
        return {service_key_param: api_key, format_param: "json"}

    def _request_and_decode(
        self, url: str, params: Mapping[str, object], dataset_id: str = ""
    ) -> dict[str, object]:
        string_params = {key: str(value) for key, value in params.items()}
        try:
            response = self._transport.request(
                "GET",
                url,
                params=string_params,
                dataset_id=dataset_id,
                provider="datago",
            )
        except TransportError as exc:
            if self._is_http_403(exc):
                raise AuthError(
                    _DATAGO_403_HINT,
                    provider="datago",
                    dataset_id=dataset_id or None,
                    status_code=403,
                ) from exc
            raise

        try:
            content_type = detect_content_type(response)
            if content_type == "json":
                decoded = decode_json(response.content)
            elif content_type == "xml":
                decoded = decode_xml(response.content)
            else:
                decoded = decode_json(response.content)
        except ParseError as exc:
            exc.provider = "datago"
            logger.debug("Datago response parsing failed", extra={"dataset_id": dataset_id})
            raise
        except ImportError as exc:
            raise ParseError("Failed to parse data.go.kr response", provider="datago") from exc

        if isinstance(decoded, dict):
            return cast(dict[str, object], decoded)

        logger.debug(
            "Datago decoded payload invalid type",
            extra={"dataset_id": dataset_id},
        )
        raise ParseError("Decoded payload is not an object", provider="datago")

    @staticmethod
    def _is_http_403(exc: TransportError) -> bool:
        cause = exc.__cause__
        return isinstance(cause, httpx.HTTPStatusError) and cause.response.status_code == 403

    def _validate_envelope(
        self, payload: dict[str, object], dataset: DatasetRef | None = None
    ) -> tuple[dict[str, object], list[dict[str, object]]]:
        dataset_id = dataset.id if dataset is not None else ""
        response_obj = payload.get("response")
        if not isinstance(response_obj, dict):
            logger.debug(
                "Datago envelope missing response/body",
                extra={"dataset_id": dataset_id},
            )
            raise ProviderResponseError(
                "Malformed response envelope: missing response",
                provider="datago",
                dataset_id=dataset_id or None,
            )

        response_dict = cast(dict[str, object], response_obj)

        envelope_style = dataset.raw_metadata.get("envelope_style") if dataset is not None else None
        if envelope_style == "gyeonggi_msg":
            return self._validate_gyeonggi_msg_envelope(response_dict, dataset_id)
        return self._validate_standard_envelope(response_dict, dataset_id)

    def _validate_standard_envelope(
        self, response_dict: dict[str, object], dataset_id: str
    ) -> tuple[dict[str, object], list[dict[str, object]]]:
        header_obj = response_dict.get("header")
        if not isinstance(header_obj, dict):
            raise ProviderResponseError(
                "Malformed response envelope: missing header",
                provider="datago",
                dataset_id=dataset_id or None,
            )

        header_dict = cast(dict[str, object], header_obj)
        result_code = header_dict.get("resultCode")
        if not isinstance(result_code, str):
            raise ProviderResponseError(
                "Malformed response envelope: missing resultCode",
                provider="datago",
                dataset_id=dataset_id or None,
            )

        result_msg_raw = header_dict.get("resultMsg")
        result_msg = (
            result_msg_raw if isinstance(result_msg_raw, str) else "Provider returned error"
        )
        logger.debug(
            "data.go.kr result",
            extra={"result_code": result_code, "result_msg": result_msg, "dataset_id": dataset_id},
        )
        if not _is_success_code(result_code):
            self._raise_for_result_code(result_code, result_msg, dataset_id)

        body_obj = response_dict.get("body")
        body_dict: dict[str, object] = (
            cast(dict[str, object], body_obj) if isinstance(body_obj, dict) else {}
        )
        items = self._normalize_items(body_dict.get("items"))
        return body_dict, items

    def _validate_gyeonggi_msg_envelope(
        self, response_dict: dict[str, object], dataset_id: str
    ) -> tuple[dict[str, object], list[dict[str, object]]]:
        header_obj = response_dict.get("msgHeader")
        if not isinstance(header_obj, dict):
            raise ProviderResponseError(
                "Malformed response envelope: missing msgHeader",
                provider="datago",
                dataset_id=dataset_id or None,
            )

        header_dict = cast(dict[str, object], header_obj)
        result_code = self._coerce_result_code(header_dict.get("resultCode"), dataset_id)
        result_msg_raw = header_dict.get("resultMessage")
        result_msg = (
            result_msg_raw if isinstance(result_msg_raw, str) else "Provider returned error"
        )
        logger.debug(
            "data.go.kr result",
            extra={"result_code": result_code, "result_msg": result_msg, "dataset_id": dataset_id},
        )
        if not _is_success_code(result_code):
            self._raise_for_result_code(result_code, result_msg, dataset_id)

        body_obj = response_dict.get("msgBody")
        body_dict: dict[str, object] = (
            cast(dict[str, object], body_obj) if isinstance(body_obj, dict) else {}
        )
        items_wrapper = self._extract_gyeonggi_msg_items_wrapper(body_dict)
        items = self._normalize_items(items_wrapper)
        return body_dict, items

    def _coerce_result_code(self, result_code: object, dataset_id: str) -> str:
        if isinstance(result_code, str):
            return result_code
        if isinstance(result_code, int):
            return str(result_code)
        raise ProviderResponseError(
            "Malformed response envelope: missing resultCode",
            provider="datago",
            dataset_id=dataset_id or None,
        )

    def _extract_gyeonggi_msg_items_wrapper(self, body_dict: dict[str, object]) -> object:
        list_values: list[object] = [
            value for value in body_dict.values() if isinstance(value, list)
        ]
        if len(list_values) == 1:
            return list_values[0]
        return body_dict

    def _raise_for_result_code(self, code: str, msg: str, dataset_id: str) -> NoReturn:
        extra = {"dataset_id": dataset_id, "result_code": code, "result_msg": msg}
        if code in {"30", "31", "20", "32"}:
            logger.debug("Datago API envelope error", extra=extra)
            raise AuthError(msg, provider="datago", provider_code=code)
        if code == "22":
            logger.debug("Datago API envelope error", extra=extra)
            raise RateLimitError(msg, provider="datago", provider_code=code, retryable=False)
        if code == "10":
            logger.debug("Datago API envelope error", extra=extra)
            raise InvalidRequestError(msg, provider="datago", provider_code=code)
        if code == "12":
            logger.debug("Datago API envelope error", extra=extra)
            raise DatasetNotFoundError(
                msg,
                provider="datago",
                provider_code=code,
                dataset_id=dataset_id,
            )
        if code in {"01", "02"}:
            logger.debug("Datago API envelope error", extra=extra)
            raise ServiceUnavailableError(msg, provider="datago", provider_code=code)
        logger.debug("Datago API envelope error", extra=extra)
        raise ProviderResponseError(msg, provider="datago", provider_code=code)

    def _normalize_items(self, items_wrapper: object) -> list[dict[str, object]]:
        if items_wrapper is None:
            return []

        if isinstance(items_wrapper, dict):
            item_value = cast(dict[str, object], items_wrapper).get("item")
            if isinstance(item_value, list):
                normalized_items = cast(list[object], item_value)
                return [
                    cast(dict[str, object], item)
                    for item in normalized_items
                    if isinstance(item, dict)
                ]
            if isinstance(item_value, dict):
                return [cast(dict[str, object], item_value)]
            return []

        if isinstance(items_wrapper, list):
            normalized_items = cast(list[object], items_wrapper)
            return [
                cast(dict[str, object], item) for item in normalized_items if isinstance(item, dict)
            ]

        return []

    @staticmethod
    def _load_default_catalogue() -> tuple[DatasetRef, ...]:
        return load_catalogue("kpubdata.providers.datago", "datago")


__all__ = ["DataGoAdapter"]
