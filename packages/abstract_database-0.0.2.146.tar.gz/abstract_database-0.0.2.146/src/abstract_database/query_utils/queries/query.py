from .imports import *
from .execute import execute_query

    
def query_data_as_dict(query, values=None, error="Error executing query:"):
    warnings.warn("query_data_as_dict is deprecated; use execute_query instead.", DeprecationWarning)
    return execute_query(query=query, values=values, fetch=True, as_dict=True)

def get_query_result(query, values=None, **kwargs):
    warnings.warn("get_query_result is deprecated; use execute_query instead.", DeprecationWarning)
    as_dict = resolve_as_dict(**kwargs)
    return execute_query(query, values=values, fetch=True, as_dict=as_dict)

def query_data(query, values=None, error="Error executing query:",  **kwargs):
    warnings.warn("query_data is deprecated; use execute_query instead.", DeprecationWarning)
    as_dict = resolve_as_dict(**kwargs)
    logger.debug(f"query = {query} and values = {values}")
    return execute_query(query, values=values, fetch=True, as_dict=as_dict)

def aggregate_rows(query, values=None, errorMsg='Error Fetching Rows', fetch=True, **kwargs):
    warnings.warn("aggregate_rows is deprecated; use execute_query instead.", DeprecationWarning)
    as_dict = resolve_as_dict(**kwargs)
    return execute_query(query, values=values, fetch=fetch, as_dict=as_dict)
