# -*- coding: utf-8 -*-
from __future__ import annotations

import re

from sentencesplit.abbreviation_replacer import AbbreviationReplacer
from sentencesplit.between_punctuation import BetweenPunctuation
from sentencesplit.exclamation_words import ExclamationWords
from sentencesplit.lists_item_replacer import ListItemReplacer
from sentencesplit.utils import apply_rules, ensure_compiled

# Pre-compiled patterns used on the hot path
_ALPHA_ONLY_RE = re.compile(r"\A[a-zA-Z]*\Z")
_ELLIPSIS_RE = re.compile(r"\A\.{3,}\Z")
_TRAILING_EXCL_RE = re.compile(r"&ᓴ&$")
_PAREN_SPACE_BEFORE_RE = re.compile(r"\s(?=\()")
_PAREN_SPACE_AFTER_RE = re.compile(r"(?<=\))\s")
_ORPHAN_SINGLE_CHARS = frozenset("'\")\u2019\u201d")
_CJK_QUOTE_RESPLIT_RE = re.compile(
    r"(?<=[。．][\]\"')”’」』】）》])(?=[\u4e00-\u9fff\u3040-\u30ff\u31f0-\u31ffA-Za-z0-9「『【（《])"
)
_LATIN_RESPLIT_RE = re.compile(r"(?<=[a-zA-Z]{2}\.\))\s+(?=[A-Z])")


def _sub_symbols_fast(text, lang):
    """Replace temporary symbols using str.replace() instead of regex."""
    for old, new in lang.SubSymbolsRules.SUBS_TABLE:
        text = text.replace(old, new)
    return text


class Processor:
    def __init__(self, text: str | None, lang, char_span: bool = False, split_mode: str = "conservative") -> None:
        self.text = text
        self.lang = lang
        self.char_span = char_span
        self.split_mode = split_mode
        # Cache hasattr lookups
        self._has_abbr_replacer = hasattr(lang, "AbbreviationReplacer")
        self._has_between_punct = hasattr(lang, "BetweenPunctuation")
        self._has_colon_rule = hasattr(lang, "ReplaceColonBetweenNumbersRule")
        self._has_comma_rule = hasattr(lang, "ReplaceNonSentenceBoundaryCommaRule")
        self._has_cjk_abbr_rules = hasattr(lang, "CjkAbbreviationRules")
        self._latin_uppercase_resplit = getattr(lang, "LATIN_UPPERCASE_RESPLIT", True)
        # Ensure regex attributes are compiled — downstream languages may define them as strings.
        self._sentence_boundary_re = ensure_compiled(lang.SENTENCE_BOUNDARY_REGEX)
        self._quotation_end_re = ensure_compiled(lang.QUOTATION_AT_END_OF_SENTENCE_REGEX)
        self._split_quotation_re = ensure_compiled(lang.SPLIT_SPACE_QUOTATION_AT_END_OF_SENTENCE_REGEX)
        self._parens_dq_re = ensure_compiled(lang.PARENS_BETWEEN_DOUBLE_QUOTES_REGEX)
        self._continuous_punct_re = ensure_compiled(lang.CONTINUOUS_PUNCTUATION_REGEX)
        self._numbered_ref_re = ensure_compiled(lang.NUMBERED_REFERENCE_REGEX)
        self._double_punct_re = ensure_compiled(lang.DoublePunctuationRules.DoublePunctuation)

    def process(self) -> list[str]:
        if not self.text:
            return []
        self.text = self.text.replace("\n", "\r")
        li = ListItemReplacer(self.text)
        self.text = li.add_line_break()
        self.replace_abbreviations()
        if self._has_cjk_abbr_rules:
            self.text = apply_rules(self.text, *self.lang.CjkAbbreviationRules.All)
        self.replace_numbers()
        self.replace_continuous_punctuation()
        self.replace_periods_before_numeric_references()
        self.text = apply_rules(
            self.text,
            self.lang.Abbreviation.WithMultiplePeriodsAndEmailRule,
            self.lang.GeoLocationRule,
            self.lang.FileFormatRule,
            self.lang.DotNetRule,
        )
        postprocessed_sents = self.split_into_segments()
        return postprocessed_sents

    def rm_none_flatten(self, sents: list[str | list[str] | None]) -> list[str]:
        new_sents = []
        for s in sents:
            if not s:
                continue
            if isinstance(s, list):
                new_sents.extend(s)
            else:
                new_sents.append(s)
        return new_sents

    def split_into_segments(self) -> list[str]:
        self.check_for_parens_between_quotes()
        sents = self.text.split("\r")
        # remove empty and none values
        sents = self.rm_none_flatten(sents)
        sents = [apply_rules(s, self.lang.SingleNewLineRule, *self.lang.EllipsisRules.All) for s in sents]
        sents = [self.check_for_punctuation(s) for s in sents]
        # flatten list of list of sentences
        sents = self.rm_none_flatten(sents)
        postprocessed_sents = []
        for sent in sents:
            sent = _sub_symbols_fast(sent, self.lang)
            for pps in self.post_process_segments(sent):
                if pps:
                    postprocessed_sents.append(pps)
        postprocessed_sents = [apply_rules(ns, self.lang.SubSingleQuoteRule) for ns in postprocessed_sents]
        if self._latin_uppercase_resplit:
            # Re-split at ".) Capital" boundaries (period inside closing paren before new sentence)
            resplit = []
            for pps in postprocessed_sents:
                parts = _LATIN_RESPLIT_RE.split(pps)
                resplit.extend(p for p in parts if p)
            postprocessed_sents = resplit
        else:
            # CJK: Re-split at closing-quote boundaries
            resplit = []
            for pps in postprocessed_sents:
                parts = _CJK_QUOTE_RESPLIT_RE.split(pps)
                resplit.extend(p for p in parts if p)
            postprocessed_sents = resplit
        # Merge orphan fragments into the preceding sentence.
        # An orphan is either an ellipsis (3+ periods) or a very short
        # lowercase abbreviation fragment ending with a period (e.g. "pp.").
        merged = []
        for sent in postprocessed_sents:
            stripped = sent.strip()
            is_orphan = False
            if stripped and merged:
                if _ELLIPSIS_RE.match(stripped):
                    is_orphan = True
                elif len(stripped) == 1 and stripped in _ORPHAN_SINGLE_CHARS:
                    is_orphan = True
                elif (
                    len(stripped) <= 10
                    and stripped.endswith(".")
                    and not stripped[0].isupper()
                    and any(c.isalnum() for c in stripped)
                ):
                    is_orphan = True
            if is_orphan:
                # Keep punctuation or quote closers attached to the previous
                # sentence without introducing an artificial space. Adding a
                # space here can make the processed sentence impossible to map
                # back to the original text span (e.g. `away.)` -> `away. )`).
                if len(stripped) == 1 and stripped in _ORPHAN_SINGLE_CHARS:
                    merged[-1] = merged[-1] + sent
                else:
                    merged[-1] = merged[-1] + " " + sent
            else:
                merged.append(sent)
        return merged

    def post_process_segments(self, txt: str) -> list[str]:
        if len(txt) > 2 and _ALPHA_ONLY_RE.search(txt):
            return [txt]

        txt = apply_rules(txt, *self.lang.ReinsertEllipsisRules.All)
        if self._quotation_end_re.search(txt):
            txt = self._split_quotation_re.split(txt)
            return [t for t in txt if t]
        else:
            txt = txt.replace("\n", "")
            txt = txt.strip()
            return [txt] if txt else []

    def check_for_parens_between_quotes(self) -> None:
        def paren_replace(match):
            match = match.group()
            sub1 = _PAREN_SPACE_BEFORE_RE.sub("\r", match)
            sub2 = _PAREN_SPACE_AFTER_RE.sub("\r", sub1)
            return sub2

        self.text = self._parens_dq_re.sub(paren_replace, self.text)

    def replace_continuous_punctuation(self) -> None:
        def continuous_puncs_replace(match):
            match = match.group()
            match = match.replace("!", "&ᓴ&")
            match = match.replace("?", "&ᓷ&")
            return match

        self.text = self._continuous_punct_re.sub(continuous_puncs_replace, self.text)

    def replace_periods_before_numeric_references(self) -> None:
        # https://github.com/diasks2/pragmatic_segmenter/commit/d9ec1a352aff92b91e2e572c30bb9561eb42c703
        self.text = self._numbered_ref_re.sub(r"∯\2\r\7", self.text)

    def check_for_punctuation(self, txt: str) -> list[str]:
        if any(p in txt for p in self.lang.Punctuations):
            sents = self.process_text(txt)
            return sents
        else:
            # NOTE: next steps of check_for_punctuation will unpack this list
            return [txt]

    def process_text(self, txt: str) -> list[str]:
        if txt[-1] not in self.lang.Punctuations:
            txt += "ȸ"
        txt = ExclamationWords.apply_rules(txt)
        txt = self.between_punctuation(txt)
        # handle text having only doublepunctuations
        if not self._double_punct_re.match(txt):
            txt = apply_rules(txt, *self.lang.DoublePunctuationRules.All)
        txt = apply_rules(txt, self.lang.QuestionMarkInQuotationRule, *self.lang.ExclamationPointRules.All)
        txt = ListItemReplacer(txt).replace_parens()
        txt = self.sentence_boundary_punctuation(txt)
        return txt

    def replace_numbers(self) -> None:
        self.text = apply_rules(self.text, *self.lang.Numbers.All)

    def abbreviations_replacer(self):
        if self._has_abbr_replacer:
            return self.lang.AbbreviationReplacer(self.text, self.lang, split_mode=self.split_mode)
        return AbbreviationReplacer(self.text, self.lang, split_mode=self.split_mode)

    def replace_abbreviations(self) -> None:
        self.text = self.abbreviations_replacer().replace()

    def between_punctuation_processor(self, txt: str):
        if self._has_between_punct:
            return self.lang.BetweenPunctuation(txt)
        else:
            return BetweenPunctuation(txt)

    def between_punctuation(self, txt: str) -> str:
        txt = self.between_punctuation_processor(txt).replace()
        return txt

    def sentence_boundary_punctuation(self, txt: str) -> list[str]:
        if self._has_colon_rule:
            txt = apply_rules(txt, self.lang.ReplaceColonBetweenNumbersRule)
        if self._has_comma_rule:
            txt = apply_rules(txt, self.lang.ReplaceNonSentenceBoundaryCommaRule)
        # retain exclamation mark if it is an ending character of a given text
        txt = _TRAILING_EXCL_RE.sub("!", txt)
        txt = [m.group() for m in self._sentence_boundary_re.finditer(txt)]
        return txt
