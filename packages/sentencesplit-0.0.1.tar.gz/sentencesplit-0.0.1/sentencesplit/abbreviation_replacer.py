# -*- coding: utf-8 -*-
from __future__ import annotations

import re
from collections import deque

from sentencesplit.utils import apply_rules, ensure_compiled


class AhoCorasickAutomaton:
    """Pure-Python Aho-Corasick automaton for multi-pattern substring search."""

    __slots__ = ("goto", "fail", "output", "_built")

    def __init__(self):
        # State 0 is the root. Each state maps char -> next_state.
        self.goto: list[dict[str, int]] = [{}]
        self.output: list[list[int]] = [[]]  # pattern IDs at each state
        self.fail: list[int] = [0]
        self._built = False

    def add_pattern(self, pattern: str, pattern_id: int) -> None:
        state = 0
        for ch in pattern:
            nxt = self.goto[state].get(ch)
            if nxt is None:
                nxt = len(self.goto)
                self.goto.append({})
                self.output.append([])
                self.fail.append(0)
                self.goto[state][ch] = nxt
            state = nxt
        self.output[state].append(pattern_id)

    def build(self) -> None:
        queue: deque[int] = deque()
        # Initialize depth-1 states
        for ch, s in self.goto[0].items():
            self.fail[s] = 0
            queue.append(s)
        # BFS to build failure links
        while queue:
            r = queue.popleft()
            for ch, s in self.goto[r].items():
                queue.append(s)
                state = self.fail[r]
                while state != 0 and ch not in self.goto[state]:
                    state = self.fail[state]
                self.fail[s] = self.goto[state].get(ch, 0)
                if self.fail[s] == s:
                    self.fail[s] = 0
                if self.output[self.fail[s]]:
                    self.output[s] = self.output[s] + self.output[self.fail[s]]
        self._built = True

    def search(self, text: str) -> set[int]:
        """Scan text in one pass, return set of matched pattern IDs."""
        state = 0
        found: set[int] = set()
        goto = self.goto
        fail = self.fail
        output = self.output
        for ch in text:
            while state != 0 and ch not in goto[state]:
                state = fail[state]
            state = goto[state].get(ch, 0)
            if output[state]:
                found.update(output[state])
        return found


def _replace_with_escape(txt: str, escaped: str, suffix_pattern: str, replacement: str, boundary_class: str = r"\s") -> str:
    """Replace period after abbreviation match using pre-escaped abbreviation."""
    txt = " " + txt
    txt = re.sub(rf"(?<=[{boundary_class}]{escaped}){suffix_pattern}", replacement, txt)
    return txt[1:]


class _AbbreviationData:
    """Pre-computed abbreviation data for a language, cached per Abbreviation class."""

    __slots__ = ("abbreviations", "prepositive_set", "number_abbr_set", "automaton", "elision_chars", "boundary_class")

    def __init__(self, lang_abbreviation_class):
        raw = lang_abbreviation_class.ABBREVIATIONS
        elision = getattr(lang_abbreviation_class, "ELISION_CHARACTERS", "")
        self.elision_chars = elision
        if elision:
            escaped_elision = re.escape(elision)
            self.boundary_class = rf"\s{escaped_elision}"
        else:
            self.boundary_class = r"\s"
        sorted_abbrs = sorted(raw, key=len, reverse=True)
        self.abbreviations = []
        self.automaton = AhoCorasickAutomaton()
        for idx, abbr in enumerate(sorted_abbrs):
            stripped = abbr.strip()
            stripped_lower = stripped.lower()
            escaped = re.escape(stripped)
            # Pre-compile the two findall patterns for this abbreviation
            if elision:
                match_re = re.compile(r"(?:^|\s|\r|\n|[{ec}]){esc}".format(ec=escaped_elision, esc=escaped), re.IGNORECASE)
            else:
                match_re = re.compile(r"(?:^|\s|\r|\n){}".format(escaped), re.IGNORECASE)
            next_word_re = re.compile(r"(?<={escaped}\. ).{{1}}".format(escaped=escaped), re.IGNORECASE)
            self.abbreviations.append(
                (
                    stripped,
                    stripped_lower,
                    escaped,
                    match_re,
                    next_word_re,
                )
            )
            self.automaton.add_pattern(stripped_lower, idx)
        self.automaton.build()
        self.prepositive_set = frozenset(a.lower() for a in lang_abbreviation_class.PREPOSITIVE_ABBREVIATIONS)
        self.number_abbr_set = frozenset(a.lower() for a in lang_abbreviation_class.NUMBER_ABBREVIATIONS)


class AbbreviationReplacer:
    _data_cache: dict[type, _AbbreviationData] = {}
    _boundary_regex_cache: dict[type, re.Pattern[str] | None] = {}
    SENTENCE_STARTERS = []
    SENTENCE_BOUNDARY_ABBREVIATIONS = ["U∯S", "U.S", "U∯K", "E∯U", "E.U", "U∯S∯A", "U.S.A", "I", "i.v", "I.V"]

    AGGRESSIVE_PREPOSITIVE_BOUNDARY_BLOCKLIST = frozenset(
        {
            # "st." is highly ambiguous (street vs Saint) and is often
            # sentence-final in address-like text.
            "st",
        }
    )

    # Prepositive abbreviations listed here will allow sentence splits
    # before known sentence starters.  E.g. "Cir. The panel reversed."
    # splits, while "Bankr. Court approved the plan." stays joined.
    # Only effective when SENTENCE_STARTERS is non-empty.
    STARTER_AWARE_PREPOSITIVE: frozenset[str] = frozenset()

    def __init__(self, text: str, lang, split_mode: str = "conservative") -> None:
        self.text = text
        self.lang = lang
        abbr_class = lang.Abbreviation
        self.split_mode = split_mode
        if abbr_class not in AbbreviationReplacer._data_cache:
            AbbreviationReplacer._data_cache[abbr_class] = _AbbreviationData(lang.Abbreviation)
        self._data = AbbreviationReplacer._data_cache[abbr_class]

    def replace(self) -> str:
        self.text = apply_rules(
            self.text,
            self.lang.PossessiveAbbreviationRule,
            self.lang.KommanditgesellschaftRule,
            *self.lang.SingleLetterAbbreviationRules.All,
        )
        lines: list[str] = []
        for line in self.text.splitlines(True):
            lines.append(self.search_for_abbreviations_in_string(line))
        self.text = "".join(lines)
        self.replace_multi_period_abbreviations()
        # Protect compact time tokens with no space before them (e.g. "3P.M.")
        # so a.m./p.m. rules can decide boundary vs non-boundary using context.
        self.text = re.sub(r"(?<=\d)([AaPp])\.([Mm])\.", r"\1∯\2∯", self.text)
        # Restore sentence-boundary period when an all-uppercase multi-period
        # abbreviation with 3+ parts (e.g. "S∯A∯T∯", "E∯S∯T∯") is followed
        # by a space and uppercase letter.  Two-part abbreviations like U∯S∯
        # are handled separately by replace_abbreviation_as_sentence_boundary.
        # Only uppercase lookbehind so lowercase abbreviations like "a.k.a."
        # keep their non-boundary separator.
        self.text = re.sub(r"(?<=[A-Z]∯[A-Z]∯[A-Z])∯(?=\s[A-Z])", ".", self.text)
        self.text = apply_rules(self.text, *self.lang.AmPmRules.All)
        self.text = self.replace_abbreviation_as_sentence_boundary()
        return self.text

    @classmethod
    def _get_boundary_regex(cls) -> re.Pattern[str] | None:
        if cls not in cls._boundary_regex_cache:
            boundary_abbr = "|".join(re.escape(abbr).replace(r"\.", r"[.∯]") for abbr in cls.SENTENCE_BOUNDARY_ABBREVIATIONS)
            if not boundary_abbr:
                cls._boundary_regex_cache[cls] = None
            elif cls.SENTENCE_STARTERS:
                sent_starters = "|".join(r"(?=\s{}\s)".format(word) for word in cls.SENTENCE_STARTERS)
                cls._boundary_regex_cache[cls] = re.compile(
                    r"(?<![A-Za-z0-9_∯])({})∯({})".format(boundary_abbr, sent_starters)
                )
            else:
                cls._boundary_regex_cache[cls] = re.compile(r"(?<![A-Za-z0-9_∯])({})∯".format(boundary_abbr))
        return cls._boundary_regex_cache[cls]

    def replace_abbreviation_as_sentence_boundary(self) -> str:
        regex = type(self)._get_boundary_regex()
        if regex is None:
            return self.text
        self.text = regex.sub("\\1.", self.text)
        return self.text

    def replace_multi_period_abbreviations(self) -> None:
        def mpa_replace(match):
            matched = match.group()
            parts = matched[:-1].split(".")
            next_text = self.text[match.end() :]
            protect_final_period = True

            # Keep sentence-final boundaries for mixed abbreviations like Ph.D.
            # when a likely new sentence starts next, but continue protecting
            # pure initialisms like A.I. before uppercase nouns.
            if re.match(r"\s[A-Z]", next_text) and any(len(part) > 1 for part in parts):
                protect_final_period = False

            body = matched[:-1].replace(".", "∯")
            tail = "∯" if protect_final_period else "."
            return body + tail

        self.text = ensure_compiled(self.lang.MULTI_PERIOD_ABBREVIATION_REGEX, re.IGNORECASE).sub(mpa_replace, self.text)

    def replace_period_of_abbr(self, txt: str, abbr: str, escaped: str | None = None) -> str:
        txt = " " + txt
        if escaped is None:
            escaped = re.escape(abbr.strip())
        boundary = self._data.boundary_class
        txt = re.sub(
            r"(?<=[{boundary}]{abbr})\.(?=((\.|\:|-|\?|,)|(\s([a-z]|I\s|I'm|I'll|\d|\())))".format(
                boundary=boundary, abbr=escaped
            ),
            "∯",
            txt,
        )
        return txt[1:]

    def search_for_abbreviations_in_string(self, text: str) -> str:
        lowered = text.lower()
        data = self._data
        found_indices = data.automaton.search(lowered)
        abbreviations = data.abbreviations
        for idx in sorted(found_indices):
            stripped, stripped_lower, escaped, match_re, next_word_re = abbreviations[idx]
            abbrev_match = match_re.findall(text)
            if not abbrev_match:
                continue
            char_array = next_word_re.findall(text)
            for ind, match in enumerate(abbrev_match):
                text = self.scan_for_replacements(text, match, ind, char_array, stripped, escaped)
        return text

    def _replace_number_abbr(self, txt: str, am_escaped: str, boundary: str, upper: bool) -> str:
        """Protect period after number abbreviations before digits and Roman numerals."""
        if upper:
            # Next word starts uppercase — protect only before Roman numerals.
            # Exclude lone "I" to avoid false joins with the pronoun "I".
            return _replace_with_escape(txt, am_escaped, r"\.(?=\s(?:[IVXLCDM]{2,}|[VXLCDM])\b)", "∯", boundary)
        return _replace_with_escape(txt, am_escaped, r"\.(?=(\s\d|\s+\(|\s[IVXLCDM]+\b))", "∯", boundary)

    def scan_for_replacements(
        self, txt: str, am: str, ind: int, char_array, stripped: str = "", escaped: str | None = None
    ) -> str:
        try:
            char = char_array[ind]
        except IndexError:
            char = ""
        use_case_heuristic = bool(self.SENTENCE_STARTERS)
        upper = char.isupper() if (char and use_case_heuristic) else False
        am_stripped = am.strip()
        # Strip leading elision characters (e.g. apostrophe in "l'Avv") so the
        # bare abbreviation is used for set lookups and replacement patterns.
        elision = self._data.elision_chars
        if elision and am_stripped and am_stripped[0] in elision:
            am_stripped = am_stripped[1:]
        am_lower = am_stripped.lower()
        boundary = self._data.boundary_class
        if not upper or am_lower in self._data.prepositive_set or am_lower in self._data.number_abbr_set:
            am_escaped = re.escape(am_stripped)
            if am_lower in self._data.prepositive_set:
                should_protect_prepositive = not (
                    self.split_mode == "aggressive" and am_lower in self.AGGRESSIVE_PREPOSITIVE_BOUNDARY_BLOCKLIST
                )
                if should_protect_prepositive:
                    # For abbreviations in STARTER_AWARE_PREPOSITIVE, allow
                    # splits before known sentence starters.  This prevents
                    # e.g. "Cir. The panel reversed." from collapsing into one
                    # segment while still protecting "Bankr. Court".
                    if self.SENTENCE_STARTERS and am_lower in self.STARTER_AWARE_PREPOSITIVE:
                        # Exclude single-char starters like "A" and "I" — they
                        # often appear as identifiers after prepositive
                        # abbreviations (e.g. "Sched. A", "Amend. I").
                        starters = "|".join(re.escape(s) for s in self.SENTENCE_STARTERS if len(s) > 1)
                        if upper:
                            suffix = rf"\.(?=(\s(?!(?:{starters})\s)|:\d+))"
                        elif char and not char.isalpha():
                            # First char is non-alpha (e.g. opening quote/bracket).
                            # Allow splits before quoted sentence starters like:
                            # Cir. "The panel reversed," he wrote.
                            open_q = r"""[\"'\u201c\u00ab(\[]*"""
                            suffix = rf"\.(?=(\s(?!{open_q}(?:{starters})\s)|:\d+))"
                        else:
                            suffix = r"\.(?=(\s|:\d+))"
                    else:
                        suffix = r"\.(?=(\s|:\d+))"
                    txt = _replace_with_escape(txt, am_escaped, suffix, "∯", boundary)
            elif am_lower in self._data.number_abbr_set:
                txt = self._replace_number_abbr(txt, am_escaped, boundary, upper)
            else:
                txt = self.replace_period_of_abbr(txt, am_stripped, am_escaped)
        return txt
