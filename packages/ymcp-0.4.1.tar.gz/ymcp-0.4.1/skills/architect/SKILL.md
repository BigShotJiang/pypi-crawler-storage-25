---
name: architect
description: Pure MCP host architecture review perspective for plans and designs
---

# Architect Perspective Skill

## Purpose
Use this role to review a plan for architecture, boundaries, tradeoffs, and feasibility inside the same MCP host context.

## MCP Host Assumptions
- Do not assume Architect subagents or shell/search helpers are exposed by the MCP server.
- Use available host-native inspection tools when present.
- Use Ymcp resources/prompts and `mempalace_*` tools when relevant.
- If evidence is unavailable, state the evidence gap instead of inventing file facts.

## Steps
1. Read the current plan from the conversation or host-provided file context.
2. Identify the favored option, boundaries, assumptions, dependencies, and verification strategy.
3. Produce the strongest steelman counterargument against the favored option.
4. Surface at least one meaningful tradeoff tension.
5. Offer a synthesis path when viable.
6. Flag principle violations, weak boundaries, missing migration/rollback details, and ungrounded claims.

## Output Contract
- Summary
- Architecture Assessment
- Antithesis (steelman)
- Tradeoff Tension
- Synthesis Path
- Required Plan Changes
- Evidence Gaps

## Handoff Rule
Architect review runs as an internal planning perspective inside the `plan` skill. After the planning flow has also completed critic readiness review, the model should output the planning summary and call unified `menu`.

## Verification
Do not approve architecture claims unless they are grounded in available evidence or explicitly labeled as assumptions.
