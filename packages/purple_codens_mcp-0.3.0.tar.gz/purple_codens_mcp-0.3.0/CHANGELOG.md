# Changelog

All notable changes to purple-codens-mcp will be documented in this file.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [0.3.0] — 2026-05-15

### Added
- `log_tools` module: `list_workflow_run_jobs()` and `get_task_log_url()` for
  inspecting workflow run tasks and retrieving CloudWatch log URLs (PR #933).
- `register_log_tools` wired into the MCP server (PR #913).

## [0.2.0] — 2026-05-05

### Added
- 6 new business mutation tools: `purple_create_workflow`, `purple_get_run_status`, `purple_subscribe_run_events`, `purple_inject_message`, `purple_list_runs`, `purple_cancel_run` (PR #700).
- Run Graph subscription via Server-Sent Events at `/api/v1/sse/purple/workflow-runs/{run_id}` (PR #700).
- `__version__` exposed on the package root.

### Changed
- Tool signatures now require `organization_id` to align with Purple backend's org-scoped API (`/api/v1/organizations/{organization_id}/...`) (PR #702 follow-up to PR #700).
- `purple_inject_message` signature changed from `(api_url, task_id, message)` to `(api_url, organization_id, project_id, run_id, message)` to target the heartbeat-run inject endpoint.
- SSE path corrected from `/api/v1/sse/workflow-runs/{run_id}` to `/api/v1/sse/purple/workflow-runs/{run_id}` (PR #702).

### Fixed
- Production 404 for all 6 new mutation tools introduced in 0.1.0-prerelease, caused by non-org-scoped paths (PR #702, CDTSK-1194).

## [0.1.0] — 2026-04-26

### Added
- Initial set of project setup tools (`purple_login`, `purple_analyze_repo`, `purple_init_project`, `purple_add_repository`, `purple_import_instructions`, `purple_sync_instructions`, `purple_list_*`).
- Credential storage in `~/.purple-codens/credentials.json` (mode 0600).
- Anthropic Claude Code integration via stdio MCP server.
