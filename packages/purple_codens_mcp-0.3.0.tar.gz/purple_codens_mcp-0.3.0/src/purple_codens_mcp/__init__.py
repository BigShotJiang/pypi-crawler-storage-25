"""Purple Codens MCP — MCP server for AI development orchestration."""

__version__ = "0.2.0"

__all__ = ["__version__"]
