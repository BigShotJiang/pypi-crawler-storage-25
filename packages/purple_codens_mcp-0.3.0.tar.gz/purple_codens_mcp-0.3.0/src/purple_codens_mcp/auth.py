"""JWT auth + credential storage for Purple Codens MCP."""

import json
import secrets
import socket
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Optional
from urllib.parse import parse_qs, urlencode, urlparse

CREDENTIALS_DIR = Path.home() / ".purple-codens"
CREDENTIALS_FILE = CREDENTIALS_DIR / "credentials.json"

AUTH_CODENS_CLIENT_ID = "purple-codens-mcp"


def _load_credentials() -> dict:
    if not CREDENTIALS_FILE.exists():
        return {}
    try:
        return json.loads(CREDENTIALS_FILE.read_text())
    except (json.JSONDecodeError, OSError):
        return {}


def _save_credentials(data: dict) -> None:
    CREDENTIALS_DIR.mkdir(parents=True, exist_ok=True)
    # Restrict to owner read/write only
    CREDENTIALS_FILE.write_text(json.dumps(data, indent=2))
    CREDENTIALS_FILE.chmod(0o600)


def store_credentials(
    token: str,
    user_id: str,
    org_id: str,
    email: str,
    api_url: str,
    refresh_token: Optional[str] = None,
    auth_service_url: Optional[str] = None,
) -> None:
    data = _load_credentials()
    entry: dict = {
        "token": token,
        "user_id": user_id,
        "org_id": org_id,
        "email": email,
        "api_url": api_url,
    }
    if refresh_token:
        entry["refresh_token"] = refresh_token
    if auth_service_url:
        entry["auth_service_url"] = auth_service_url
    data[api_url] = entry
    _save_credentials(data)


def get_credentials(api_url: str) -> Optional[dict]:
    data = _load_credentials()
    return data.get(api_url)


def clear_credentials(api_url: str) -> None:
    data = _load_credentials()
    data.pop(api_url, None)
    _save_credentials(data)


def _find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))
        return s.getsockname()[1]


_DEVICE_GRANT_TYPE = "urn:ietf:params:oauth:grant-type:device_code"
_DEVICE_POLL_INTERVAL = 5  # seconds between polling attempts
_DEVICE_TIMEOUT = 900  # 15 minutes


def device_code_login(auth_service_url: str) -> dict:
    """Login via Device Code Flow (RFC 8628) — works on headless/SSH servers.

    Requests a device code from Auth Codens, prints the user_code and
    verification_uri to the terminal, then polls until the user completes
    auth on any other device (phone, laptop browser).

    Args:
        auth_service_url: Auth Codens base URL (e.g. https://api.auth.codens.ai)

    Returns:
        dict with 'access_token', 'refresh_token', 'expires_in', 'scope' keys

    Raises:
        TimeoutError: if login is not completed within 15 minutes
        ValueError: if an unrecoverable error occurs
    """
    base_url = auth_service_url.rstrip("/")

    # Step 1: Request device + user codes
    authorize_data = urllib.parse.urlencode(
        {
            "client_id": AUTH_CODENS_CLIENT_ID,
            "scope": "openid profile email",
        }
    ).encode()
    req = urllib.request.Request(
        f"{base_url}/oauth/device/authorize",
        data=authorize_data,
        method="POST",
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    try:
        with urllib.request.urlopen(req) as resp:
            auth_resp = json.loads(resp.read().decode())
    except urllib.error.HTTPError as exc:
        body = exc.read().decode()
        raise ValueError(f"Device authorization failed: {exc.code} {body}") from exc

    device_code = auth_resp["device_code"]
    user_code = auth_resp["user_code"]
    verification_uri = auth_resp["verification_uri"]
    expires_in = auth_resp.get("expires_in", _DEVICE_TIMEOUT)
    interval = auth_resp.get("interval", _DEVICE_POLL_INTERVAL)

    # Step 2: Instruct the user
    print("\n" + "=" * 60)
    print("  Device Authorization Required")
    print("=" * 60)
    print(f"\n  1. Open this URL on any device:")
    print(f"     {verification_uri}")
    print(f"\n  2. Enter this code when prompted:")
    print(f"     {user_code}")
    print(f"\n  Waiting for authorization (expires in {expires_in // 60} minutes)...")
    print("=" * 60 + "\n")

    # Step 3: Poll until authorized or expired
    poll_data = urllib.parse.urlencode(
        {
            "grant_type": _DEVICE_GRANT_TYPE,
            "device_code": device_code,
            "client_id": AUTH_CODENS_CLIENT_ID,
        }
    ).encode()
    token_url = f"{base_url}/oauth/device/token"
    deadline = time.monotonic() + expires_in

    while time.monotonic() < deadline:
        time.sleep(interval)

        poll_req = urllib.request.Request(
            token_url,
            data=poll_data,
            method="POST",
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        try:
            with urllib.request.urlopen(poll_req) as resp:
                token_resp = json.loads(resp.read().decode())
            # Success
            print("  Authorization complete!\n")
            return token_resp
        except urllib.error.HTTPError as exc:
            raw = exc.read().decode()
            try:
                error_body = json.loads(raw) if raw else {}
            except json.JSONDecodeError:
                raise ValueError(f"Polling error: HTTP {exc.code}, body: {raw!r}")
            error_code = error_body.get("error", "")

            if error_code == "authorization_pending":
                continue  # still waiting
            elif error_code == "slow_down":
                interval += 5
                continue
            elif error_code in ("expired_token", "access_denied"):
                raise ValueError(f"Device authorization failed: {error_code}")
            else:
                raise ValueError(f"Unexpected polling error: {error_code} — {error_body}")

    raise TimeoutError("Device authorization timed out. Please try again.")


def browser_login(auth_service_url: str) -> dict:
    """Open browser for Google OAuth via Auth Codens.

    Starts a local HTTP server on a random port, opens a browser to the Auth
    Codens OAuth authorize URL, waits for the redirect callback, and returns
    the authorization code and redirect_uri needed for token exchange.

    Args:
        auth_service_url: Auth Codens base URL (e.g. https://api.auth.codens.ai)

    Returns:
        dict with 'code' and 'redirect_uri' keys

    Raises:
        TimeoutError: if login is not completed within 5 minutes
        ValueError: if the OAuth callback contains an error or a state mismatch
    """
    port = _find_free_port()
    redirect_uri = f"http://localhost:{port}/callback"
    state = secrets.token_urlsafe(16)

    result: dict = {}
    server_ready = threading.Event()

    class _CallbackHandler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:
            parsed = urlparse(self.path)
            if parsed.path == "/callback":
                params = parse_qs(parsed.query)
                error = params.get("error", [None])[0]
                received_state = params.get("state", [None])[0]

                if error:
                    result["error"] = error
                    self._respond(400, f"Login failed: {error}".encode())
                elif received_state != state:
                    result["error"] = "state_mismatch"
                    self._respond(400, b"State mismatch. Please try again.")
                else:
                    result["code"] = params.get("code", [None])[0]
                    result["redirect_uri"] = redirect_uri
                    self._respond(
                        200,
                        b"<html><body><h2>Login successful!</h2>"
                        b"<p>You can close this tab and return to your terminal.</p>"
                        b"</body></html>",
                    )
            else:
                self._respond(404, b"Not found")

        def _respond(self, status: int, body: bytes) -> None:
            self.send_response(status)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, format: str, *args: object) -> None:  # noqa: A002
            pass  # Suppress server logs

    httpd = HTTPServer(("localhost", port), _CallbackHandler)
    httpd.timeout = 1  # Poll every second so we can detect completion

    def _serve() -> None:
        server_ready.set()
        while "code" not in result and "error" not in result:
            httpd.handle_request()
        httpd.server_close()

    thread = threading.Thread(target=_serve, daemon=True)
    thread.start()
    server_ready.wait()

    authorize_params = urlencode(
        {
            "client_id": AUTH_CODENS_CLIENT_ID,
            "redirect_uri": redirect_uri,
            "response_type": "code",
            "scope": "openid profile email",
            "state": state,
        }
    )
    authorize_url = f"{auth_service_url.rstrip('/')}/oauth/authorize?{authorize_params}"

    print("\nOpening browser for login...")
    print(f"If the browser does not open automatically, visit:\n  {authorize_url}\n")
    webbrowser.open(authorize_url)

    thread.join(timeout=300)  # 5-minute timeout

    if "error" in result:
        raise ValueError(f"Login failed: {result['error']}")
    if "code" not in result:
        raise TimeoutError("Login timed out after 5 minutes. Please try again.")

    return result
