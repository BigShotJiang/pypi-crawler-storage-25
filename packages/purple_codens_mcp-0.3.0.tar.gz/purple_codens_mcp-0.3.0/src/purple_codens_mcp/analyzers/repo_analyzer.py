"""Local repository analyzer - detects project structure for Purple Codens setup."""

import json
import os
import re
import subprocess
from pathlib import Path
from typing import Optional


def _run_git(args: list[str], cwd: Path) -> Optional[str]:
    try:
        result = subprocess.run(
            ["git"] + args,
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=5,
        )
        return result.stdout.strip() if result.returncode == 0 else None
    except Exception:
        return None


def analyze_repository(cwd: Optional[str] = None) -> dict:
    """
    Scan the current working directory for project metadata.

    Returns a structured dict with:
    - claude_md: content of CLAUDE.md if present
    - rules: list of .claude/rules/ file names
    - test_commands: detected test commands
    - ci_workflows: list of workflow file names
    - git_remote: GitHub owner/repo parsed from remote URL
    - package_scripts: package.json script names
    - pytest_config: whether pytest.ini / pyproject pytest section exists
    - language_stack: detected languages/frameworks
    """
    root = Path(cwd) if cwd else Path.cwd()

    result: dict = {
        "root": str(root),
        "claude_md": None,
        "claude_md_path": None,
        "rules": [],
        "test_commands": [],
        "ci_workflows": [],
        "git_remote": None,
        "github_owner": None,
        "github_repo": None,
        "package_scripts": {},
        "pytest_config": False,
        "language_stack": [],
    }

    # CLAUDE.md
    claude_md = root / "CLAUDE.md"
    if claude_md.exists():
        result["claude_md"] = claude_md.read_text(encoding="utf-8", errors="replace")
        result["claude_md_path"] = str(claude_md)

    # .claude/rules/
    rules_dir = root / ".claude" / "rules"
    if rules_dir.is_dir():
        result["rules"] = [f.name for f in sorted(rules_dir.iterdir()) if f.is_file()]

    # CI workflows
    workflows_dir = root / ".github" / "workflows"
    if workflows_dir.is_dir():
        result["ci_workflows"] = [f.name for f in sorted(workflows_dir.iterdir()) if f.is_file()]

    # Git remote
    remote_url = _run_git(["remote", "get-url", "origin"], root)
    if remote_url:
        result["git_remote"] = remote_url
        # Parse github.com/:owner/:repo[.git]
        match = re.search(r"github\.com[:/]([^/]+)/([^/.]+)(?:\.git)?$", remote_url)
        if match:
            result["github_owner"] = match.group(1)
            result["github_repo"] = match.group(2)

    # package.json scripts
    package_json = root / "package.json"
    if package_json.exists():
        try:
            pkg = json.loads(package_json.read_text())
            result["package_scripts"] = pkg.get("scripts", {})
        except (json.JSONDecodeError, OSError):
            pass

    # pytest config
    pytest_ini = root / "pytest.ini"
    setup_cfg = root / "setup.cfg"
    pyproject = root / "pyproject.toml"

    if pytest_ini.exists():
        result["pytest_config"] = True
    elif setup_cfg.exists() and "[tool:pytest]" in setup_cfg.read_text(errors="replace"):
        result["pytest_config"] = True
    elif pyproject.exists() and "[tool.pytest" in pyproject.read_text(errors="replace"):
        result["pytest_config"] = True

    # Language/framework detection
    stack: list[str] = []
    if (root / "requirements.txt").exists() or (root / "pyproject.toml").exists():
        stack.append("python")
    if (root / "package.json").exists():
        stack.append("nodejs")
        try:
            pkg = json.loads((root / "package.json").read_text())
            deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}
            if "next" in deps:
                stack.append("nextjs")
            if "react" in deps:
                stack.append("react")
            if "typescript" in deps or (root / "tsconfig.json").exists():
                stack.append("typescript")
        except Exception:
            pass
    if (root / "go.mod").exists():
        stack.append("go")
    if (root / "Cargo.toml").exists():
        stack.append("rust")
    result["language_stack"] = stack

    # Build test command suggestions
    test_commands: list[str] = []
    if result["pytest_config"] or "python" in stack:
        test_commands.append("pytest tests/unit/ -x -q")
    scripts = result["package_scripts"]
    if "test" in scripts:
        test_commands.append("npm test")
    if "test:unit" in scripts:
        test_commands.append("npm run test:unit")
    if "type-check" in scripts:
        test_commands.append("npm run type-check")
    result["test_commands"] = test_commands

    return result
