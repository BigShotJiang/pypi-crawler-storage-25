"""Log retrieval MCP tools: purple_get_run_logs and purple_get_task_log_url."""

import json
from typing import Any

from mcp.server.fastmcp import FastMCP

from ..client import APIError, AuthenticationError


def register_log_tools(mcp: FastMCP, get_client: Any) -> None:

    @mcp.tool()
    def purple_get_run_logs(
        api_url: str,
        organization_id: str,
        run_id: str,
    ) -> str:
        """
        Get VPS job logs for a workflow run.

        Returns a list of all VPS jobs associated with the run, including each
        job's log URL (S3 presigned URL, valid for 1 hour), status, and timing.

        Args:
            api_url: Purple Codens API base URL
            organization_id: Organization ID
            run_id: Workflow run ID
        """
        try:
            client = get_client(api_url)
            result = client.list_workflow_run_jobs(organization_id, run_id)
            jobs = result.get("jobs", []) if isinstance(result, dict) else result
            total = result.get("total", len(jobs)) if isinstance(result, dict) else len(jobs)
            return json.dumps(
                {"status": "success", "run_id": run_id, "total": total, "jobs": jobs},
                ensure_ascii=False,
                indent=2,
            )
        except (AuthenticationError, APIError) as e:
            return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)

    @mcp.tool()
    def purple_get_task_log_url(
        api_url: str,
        organization_id: str,
        project_id: str,
        task_id: str,
    ) -> str:
        """
        Get the log URL for the latest Claude Code job of a task.

        Returns an S3 presigned URL (valid for 1 hour) that points to the
        Claude Code execution log for the specified task.

        Args:
            api_url: Purple Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            task_id: Task ID
        """
        try:
            client = get_client(api_url)
            result = client.get_task_log_url(organization_id, project_id, task_id)
            log_url = result.get("log_url") if isinstance(result, dict) else None
            payload: dict[str, Any] = {
                "status": "success",
                "task_id": task_id,
                "log_url": log_url,
                "note": "presigned URL is valid for approximately 1 hour" if log_url else None,
            }
            return json.dumps(payload, ensure_ascii=False, indent=2)
        except (AuthenticationError, APIError) as e:
            return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)
