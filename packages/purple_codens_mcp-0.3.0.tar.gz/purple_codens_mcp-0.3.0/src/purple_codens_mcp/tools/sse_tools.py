"""SSE subscription MCP tool: purple_subscribe_run_events."""

import json
from typing import Any

import httpx
from mcp.server.fastmcp import FastMCP

from ..client import APIError, AuthenticationError


def register_sse_tools(mcp: FastMCP, get_client: Any) -> None:

    @mcp.tool()
    def purple_subscribe_run_events(
        api_url: str,
        run_id: str,
        max_events: int = 50,
        timeout_seconds: int = 30,
    ) -> str:
        """
        Subscribe to SSE events for a workflow run.

        Collects up to max_events events or until timeout_seconds elapses,
        then returns the collected events as a list.

        Args:
            api_url: Purple Codens API base URL
            run_id: Workflow run ID
            max_events: Maximum number of events to collect (default: 50)
            timeout_seconds: Timeout in seconds (default: 30)
        """
        try:
            client = get_client(api_url)
            headers = client._headers()
            headers["Accept"] = "text/event-stream"
            url = f"{api_url.rstrip('/')}/api/v1/sse/purple/workflow-runs/{run_id}"
            events: list = []
            with httpx.Client(timeout=timeout_seconds) as http_client:
                try:
                    with http_client.stream("GET", url, headers=headers) as resp:
                        for line in resp.iter_lines():
                            if not line or not line.startswith("data:"):
                                continue
                            try:
                                events.append(json.loads(line[5:].strip()))
                            except Exception:
                                pass
                            if len(events) >= max_events:
                                break
                except (httpx.ReadTimeout, httpx.RemoteProtocolError):
                    pass
            return json.dumps(
                {"status": "success", "count": len(events), "events": events},
                ensure_ascii=False,
                indent=2,
            )
        except (AuthenticationError, APIError) as e:
            return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)
