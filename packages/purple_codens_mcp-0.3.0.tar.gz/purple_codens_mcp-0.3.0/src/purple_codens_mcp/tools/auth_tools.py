"""Auth MCP tools: purple_login, purple_whoami."""

import json
import os
from typing import Any

from mcp.server.fastmcp import FastMCP

from ..client import APIError, AuthenticationError, PurpleCodensClient


def register_auth_tools(mcp: FastMCP, get_client: Any) -> None:

    @mcp.tool()
    def purple_login(
        api_url: str,
        auth_service_url: str = "",
        email: str = "",
        password: str = "",
        use_device_code: bool = False,
    ) -> str:
        """
        Log in to Purple Codens.

        Three login methods are available (in priority order):

        1. Browser OAuth (default when auth_service_url provided):
           Opens a browser for Google OAuth via Auth Codens. Requires a browser
           on the local machine. Not suitable for headless/SSH environments.

        2. Device Code Flow (set use_device_code=True):
           Displays a short code and URL in the terminal. Open the URL on any
           device (phone, laptop), enter the code, and log in via Google.
           Works on headless servers and SSH sessions — no browser needed locally.

        3. Email + password (provide email and password):
           Direct login with credentials. Use for dev/CI environments where
           Google-OAuth-only accounts are not needed.

        The device code flow:
          1. Auth Codens issues a device_code and user_code (e.g. 'ABCD-1234').
          2. Terminal displays: Open <URL> and enter code: ABCD-1234
          3. User opens URL on any device, enters code, logs in via Google.
          4. MCP polls until authorized, then stores tokens in
             ~/.purple-codens/credentials.json.

        Args:
            api_url: Purple Codens API base URL (e.g. https://api.purple.codens.ai)
            auth_service_url: Auth Codens base URL
                (e.g. https://api.auth.codens.ai). If omitted, checks the
                PURPLE_AUTH_SERVICE_URL environment variable.
            email: Email address for password-based login.
            password: Password for password-based login.
            use_device_code: Use Device Code Flow instead of browser OAuth.
                Set to True on headless servers or SSH sessions.
        """
        effective_auth_url = auth_service_url or os.environ.get("PURPLE_AUTH_SERVICE_URL", "")

        try:
            client = PurpleCodensClient(api_url)

            if effective_auth_url and use_device_code:
                # Device Code Flow (RFC 8628) — headless/SSH environments
                from ..auth import device_code_login

                try:
                    token_resp = device_code_login(effective_auth_url)
                except TimeoutError as e:
                    return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)
                except ValueError as e:
                    return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)

                result = client.login_with_device_token(
                    access_token=token_resp["access_token"],
                    refresh_token=token_resp.get("refresh_token"),
                    auth_service_url=effective_auth_url,
                )

            elif effective_auth_url:
                # Browser OAuth flow (Google via Auth Codens)
                from ..auth import browser_login

                try:
                    callback = browser_login(effective_auth_url)
                except TimeoutError as e:
                    return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)
                except ValueError as e:
                    return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)

                result = client.login_with_code(
                    code=callback["code"],
                    redirect_uri=callback["redirect_uri"],
                    auth_service_url=effective_auth_url,
                )

            elif email and password:
                # Email + password fallback (dev / CI environments)
                result = client.login(email, password)

            else:
                return json.dumps(
                    {
                        "status": "error",
                        "message": (
                            "Provide auth_service_url (or set PURPLE_AUTH_SERVICE_URL) "
                            "for browser/device-code OAuth, or supply both email and "
                            "password for direct login. "
                            "On headless servers, also set use_device_code=True."
                        ),
                    },
                    ensure_ascii=False,
                )

            me = result["user"]
            orgs = me.get("organizations", [])
            org = orgs[0] if orgs else {}
            # Refresh the shared client reference
            get_client(api_url, force_reload=True)
            return json.dumps(
                {
                    "status": "success",
                    "message": f"Logged in as {me.get('email')}",
                    "user_id": str(me.get("user_id", "")),
                    "org_id": str(org.get("organization_id", "")),
                    "org_name": org.get("organization_name"),
                },
                ensure_ascii=False,
                indent=2,
            )

        except APIError as e:
            return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)

    @mcp.tool()
    def purple_whoami(api_url: str) -> str:
        """
        Return current authenticated user and organization information.

        Args:
            api_url: Purple Codens API base URL
        """
        try:
            client = get_client(api_url)
            me = client.whoami()
            orgs = me.get("organizations", [])
            org = orgs[0] if orgs else {}
            return json.dumps(
                {
                    "user_id": str(me.get("user_id", "")),
                    "email": me.get("email"),
                    "name": me.get("full_name"),
                    "org_id": str(org.get("organization_id", "")),
                    "org_name": org.get("organization_name"),
                },
                ensure_ascii=False,
                indent=2,
            )
        except AuthenticationError as e:
            return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)
        except APIError as e:
            return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)
