"""Project MCP tools: purple_analyze_repo, purple_init_project, purple_list_projects."""

import json
from pathlib import Path
from typing import Any, Optional

from mcp.server.fastmcp import FastMCP

from ..analyzers.repo_analyzer import analyze_repository
from ..client import APIError, AuthenticationError, PurpleCodensClient


def register_project_tools(mcp: FastMCP, get_client: Any) -> None:

    @mcp.tool()
    def purple_analyze_repo(cwd: Optional[str] = None) -> str:
        """
        Scan the current working directory and return a structured analysis.

        Detects: CLAUDE.md, .claude/rules/, package.json scripts, pytest config,
        .github/workflows/, git remote (GitHub owner/repo), language stack.

        Args:
            cwd: Directory to analyze. Defaults to current working directory.
        """
        analysis = analyze_repository(cwd)
        # Truncate CLAUDE.md content for readability
        if analysis.get("claude_md") and len(analysis["claude_md"]) > 2000:
            analysis["claude_md_preview"] = analysis["claude_md"][:2000] + "... (truncated)"
            del analysis["claude_md"]
        return json.dumps(analysis, ensure_ascii=False, indent=2)

    @mcp.tool()
    def purple_list_projects(api_url: str) -> str:
        """
        List all projects in the authenticated organization.

        Args:
            api_url: Purple Codens API base URL
        """
        try:
            client = get_client(api_url)
            projects = client.list_projects()
            return json.dumps(
                {
                    "count": len(projects),
                    "projects": [
                        {
                            "id": p.get("project_id"),
                            "name": p.get("name"),
                            "description": p.get("ai_instructions", ""),
                            "created_at": p.get("created_at"),
                        }
                        for p in projects
                    ],
                },
                ensure_ascii=False,
                indent=2,
            )
        except (AuthenticationError, APIError) as e:
            return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)

    @mcp.tool()
    def purple_init_project(
        api_url: str,
        name: str,
        cwd: Optional[str] = None,
        github_owner: Optional[str] = None,
        github_repo: Optional[str] = None,
        branch: str = "main",
        workflow_type: str = "github_flow",
    ) -> str:
        """
        Initialize a Purple Codens project for the current repository.

        Orchestrates:
        1. Analyze the local repo
        2. Create the project
        3. Link the GitHub repository
        4. Create purple project settings
        5. Import CLAUDE.md + .claude/rules/ as instruction files
        6. Return suggested verify commands

        Args:
            api_url: Purple Codens API base URL
            name: Project name
            cwd: Local repo directory (defaults to cwd)
            github_owner: GitHub owner (auto-detected from git remote if omitted)
            github_repo: GitHub repository name (auto-detected if omitted)
            branch: Default branch (default: main)
            workflow_type: Workflow type: github_flow, git_flow, trunk_based, custom
        """
        steps: list[dict] = []

        try:
            client = get_client(api_url)

            # Step 1: analyze repo
            analysis = analyze_repository(cwd)
            steps.append({"step": "analyze_repo", "status": "ok", "data": {
                "root": analysis["root"],
                "language_stack": analysis["language_stack"],
                "has_claude_md": analysis["claude_md"] is not None,
                "rules_count": len(analysis["rules"]),
                "ci_workflows": analysis["ci_workflows"],
                "detected_github_owner": analysis["github_owner"],
                "detected_github_repo": analysis["github_repo"],
            }})

            # Resolve GitHub owner/repo
            owner = github_owner or analysis.get("github_owner")
            repo = github_repo or analysis.get("github_repo")

            # Step 2: create project
            project = client.create_project(name)
            project_id = project["project_id"]
            steps.append({"step": "create_project", "status": "ok", "project_id": project_id})

            # Step 3: link repo (optional if no remote detected)
            repository_id: Optional[str] = None
            if owner and repo:
                repository = client.add_repository(
                    project_id, owner, repo, branch, workflow_type
                )
                repository_id = repository.get("repository_id")
                steps.append({
                    "step": "add_repository",
                    "status": "ok",
                    "repository_id": repository_id,
                    "github": f"{owner}/{repo}",
                })
            else:
                steps.append({
                    "step": "add_repository",
                    "status": "skipped",
                    "reason": "No GitHub remote detected. Use purple_add_repository to link manually.",
                })

            # Step 4: create purple project settings
            verify_cmd = _suggest_verify_command(analysis)
            try:
                client.create_purple_project(
                    project_id,
                    default_verify_commands=verify_cmd,
                )
                steps.append({
                    "step": "create_purple_project",
                    "status": "ok",
                    "default_verify_commands": verify_cmd,
                })
            except APIError as e:
                steps.append({"step": "create_purple_project", "status": "error", "message": str(e)})

            # Step 5: import instruction files
            if repository_id:
                try:
                    imported = client.import_instructions(project_id, repository_id)
                    steps.append({
                        "step": "import_instructions",
                        "status": "ok",
                        "imported": imported,
                    })
                except APIError as e:
                    steps.append({
                        "step": "import_instructions",
                        "status": "error",
                        "message": str(e),
                    })
            else:
                steps.append({
                    "step": "import_instructions",
                    "status": "skipped",
                    "reason": "No repository linked.",
                })

            return json.dumps(
                {
                    "status": "success",
                    "project_id": project_id,
                    "project_name": name,
                    "steps": steps,
                    "suggested_verify_command": verify_cmd,
                    "next_steps": _next_steps(owner, repo, repository_id),
                },
                ensure_ascii=False,
                indent=2,
            )

        except (AuthenticationError, APIError) as e:
            return json.dumps(
                {"status": "error", "message": str(e), "steps_completed": steps},
                ensure_ascii=False,
                indent=2,
            )


def _suggest_verify_command(analysis: dict) -> str:
    """Build a sensible verify command from repo analysis."""
    stack = analysis.get("language_stack", [])
    scripts = analysis.get("package_scripts", {})

    parts: list[str] = []

    if "python" in stack and analysis.get("pytest_config"):
        parts.append(
            "uv venv .venv --clear -q --python 3.12 && . .venv/bin/activate "
            "&& uv pip install -r requirements.txt -q "
            "&& python -m pytest tests/unit/ -x -q"
        )

    if "nodejs" in stack:
        if "typescript" in stack:
            parts.append("npm install --legacy-peer-deps && npx tsc --noEmit")
        elif "test" in scripts:
            parts.append("npm install --legacy-peer-deps && npm test")

    return " && ".join(parts) if parts else ""


def _next_steps(owner: Optional[str], repo: Optional[str], repository_id: Optional[str]) -> list[str]:
    steps: list[str] = []
    if not repository_id:
        steps.append("Link a GitHub repository with purple_add_repository")
    if not owner or not repo:
        steps.append("Provide github_owner and github_repo if not auto-detected")
    steps.append("Check imported instructions with purple_list_instructions")
    steps.append("Sync local changes any time with purple_sync_instructions")
    return steps
