"""Instruction file MCP tools: import, list, sync."""

import json
from pathlib import Path
from typing import Any, Optional

from mcp.server.fastmcp import FastMCP

from ..client import APIError, AuthenticationError


def register_instruction_tools(mcp: FastMCP, get_client: Any) -> None:

    @mcp.tool()
    def purple_import_instructions(
        api_url: str, project_id: str, repository_id: str
    ) -> str:
        """
        Import CLAUDE.md and .claude/rules/ from the linked GitHub repository
        into Purple Codens as instruction files.

        Args:
            api_url: Purple Codens API base URL
            project_id: Project ID
            repository_id: Repository ID to import from
        """
        try:
            client = get_client(api_url)
            result = client.import_instructions(project_id, repository_id)
            return json.dumps(
                {"status": "success", "imported": result},
                ensure_ascii=False,
                indent=2,
            )
        except (AuthenticationError, APIError) as e:
            return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)

    @mcp.tool()
    def purple_list_instructions(api_url: str, project_id: str) -> str:
        """
        List all instruction files for a project.

        Args:
            api_url: Purple Codens API base URL
            project_id: Project ID
        """
        try:
            client = get_client(api_url)
            files = client.list_instructions(project_id)
            return json.dumps(
                {
                    "count": len(files),
                    "files": [
                        {
                            "id": f.get("file_id"),
                            "name": f.get("filename"),
                            "file_type": f.get("file_type"),
                            "is_active": f.get("is_active"),
                            "updated_at": f.get("updated_at"),
                        }
                        for f in files
                    ],
                },
                ensure_ascii=False,
                indent=2,
            )
        except (AuthenticationError, APIError) as e:
            return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)

    @mcp.tool()
    def purple_sync_instructions(
        api_url: str,
        project_id: str,
        cwd: Optional[str] = None,
    ) -> str:
        """
        Read local CLAUDE.md and .claude/rules/, diff with Purple Codens,
        and update files that have changed.

        Args:
            api_url: Purple Codens API base URL
            project_id: Project ID
            cwd: Local repo root directory (defaults to cwd)
        """
        try:
            client = get_client(api_url)
            root = Path(cwd) if cwd else Path.cwd()

            # Build local file map: name -> content
            local_files: dict[str, tuple[str, str]] = {}  # name -> (content, file_type)

            claude_md = root / "CLAUDE.md"
            if claude_md.exists():
                local_files["CLAUDE.md"] = (
                    claude_md.read_text(encoding="utf-8", errors="replace"),
                    "claude_md",
                )

            rules_dir = root / ".claude" / "rules"
            if rules_dir.is_dir():
                for rule_file in sorted(rules_dir.iterdir()):
                    if rule_file.is_file():
                        local_files[rule_file.name] = (
                            rule_file.read_text(encoding="utf-8", errors="replace"),
                            "rule",
                        )

            # Fetch remote files
            remote_files = client.list_instructions(project_id)
            remote_map: dict[str, dict] = {f["filename"]: f for f in remote_files}

            results: list[dict] = []

            for name, (local_content, file_type) in local_files.items():
                if name in remote_map:
                    remote = remote_map[name]
                    remote_content = remote.get("content", "")
                    if local_content.strip() != remote_content.strip():
                        updated = client.update_instruction(
                            project_id, remote["file_id"], local_content
                        )
                        results.append({"name": name, "action": "updated", "id": remote["file_id"]})
                    else:
                        results.append({"name": name, "action": "unchanged"})
                else:
                    created = client.create_instruction(
                        project_id, name, local_content, file_type
                    )
                    results.append({"name": name, "action": "created", "id": created.get("file_id")})

            updated_count = sum(1 for r in results if r["action"] == "updated")
            created_count = sum(1 for r in results if r["action"] == "created")
            unchanged_count = sum(1 for r in results if r["action"] == "unchanged")

            return json.dumps(
                {
                    "status": "success",
                    "summary": {
                        "updated": updated_count,
                        "created": created_count,
                        "unchanged": unchanged_count,
                    },
                    "files": results,
                },
                ensure_ascii=False,
                indent=2,
            )
        except (AuthenticationError, APIError) as e:
            return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)
