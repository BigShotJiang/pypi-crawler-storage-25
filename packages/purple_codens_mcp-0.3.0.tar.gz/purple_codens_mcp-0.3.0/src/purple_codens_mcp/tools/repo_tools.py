"""Repository MCP tools: purple_add_repository, purple_list_repositories."""

import json
from typing import Any

from mcp.server.fastmcp import FastMCP

from ..client import APIError, AuthenticationError


def register_repo_tools(mcp: FastMCP, get_client: Any) -> None:

    @mcp.tool()
    def purple_add_repository(
        api_url: str,
        project_id: str,
        github_owner: str,
        github_repo: str,
        branch: str = "main",
        workflow_type: str = "github_flow",
    ) -> str:
        """
        Link a GitHub repository to a Purple Codens project.

        Args:
            api_url: Purple Codens API base URL
            project_id: Target project ID
            github_owner: GitHub organization or user name
            github_repo: GitHub repository name
            branch: Default branch (default: main)
            workflow_type: One of: github_flow, git_flow, trunk_based, custom
        """
        try:
            client = get_client(api_url)
            repo = client.add_repository(project_id, github_owner, github_repo, branch, workflow_type)
            return json.dumps(
                {
                    "status": "success",
                    "repository_id": repo.get("repository_id"),
                    "github": f"{github_owner}/{github_repo}",
                    "branch": branch,
                    "workflow_type": workflow_type,
                },
                ensure_ascii=False,
                indent=2,
            )
        except (AuthenticationError, APIError) as e:
            return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)

    @mcp.tool()
    def purple_list_repositories(api_url: str, project_id: str) -> str:
        """
        List all repositories linked to a project.

        Args:
            api_url: Purple Codens API base URL
            project_id: Project ID
        """
        try:
            client = get_client(api_url)
            repos = client.list_repositories(project_id)
            return json.dumps(
                {
                    "count": len(repos),
                    "repositories": [
                        {
                            "id": r.get("repository_id"),
                            "github_owner": r.get("github_owner"),
                            "github_repo": r.get("github_repo"),
                            "default_branch": r.get("github_branch"),
                            "workflow_type": r.get("workflow_type"),
                        }
                        for r in repos
                    ],
                },
                ensure_ascii=False,
                indent=2,
            )
        except (AuthenticationError, APIError) as e:
            return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)
