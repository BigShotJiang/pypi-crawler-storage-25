"""Workflow and run management MCP tools."""

import json
from typing import Any, Optional

from mcp.server.fastmcp import FastMCP

from ..client import APIError, AuthenticationError


def register_workflow_tools(mcp: FastMCP, get_client: Any) -> None:

    @mcp.tool()
    def purple_create_workflow(
        api_url: str,
        organization_id: str,
        project_id: str,
        name: str,
        spec: dict,
    ) -> str:
        """
        Create a new workflow in Purple Codens.

        Args:
            api_url: Purple Codens API base URL
            organization_id: Organization ID
            project_id: Target project ID
            name: Workflow name
            spec: Workflow specification dict (steps, triggers, etc.)
        """
        try:
            client = get_client(api_url)
            result = client.create_workflow(
                organization_id,
                body={"project_id": project_id, "name": name, "spec": spec},
            )
            return json.dumps(
                {"status": "success", "workflow": result},
                ensure_ascii=False,
                indent=2,
            )
        except (AuthenticationError, APIError) as e:
            return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)

    @mcp.tool()
    def purple_get_run_status(api_url: str, organization_id: str, run_id: str) -> str:
        """
        Get current status of a workflow run.

        Args:
            api_url: Purple Codens API base URL
            organization_id: Organization ID
            run_id: Workflow run ID
        """
        try:
            client = get_client(api_url)
            result = client.get_workflow_run(organization_id, run_id)
            return json.dumps(
                {"status": "success", "run": result},
                ensure_ascii=False,
                indent=2,
            )
        except (AuthenticationError, APIError) as e:
            return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)

    @mcp.tool()
    def purple_list_runs(
        api_url: str,
        organization_id: str,
        project_id: Optional[str] = None,
        status: Optional[str] = None,
    ) -> str:
        """
        List workflow runs scoped to organization, optionally filtered by project and status.

        Args:
            api_url: Purple Codens API base URL
            organization_id: Organization ID
            project_id: Optional project ID filter
            status: Optional status filter (e.g. running, pending)
        """
        try:
            client = get_client(api_url)
            params: dict = {}
            if project_id:
                params["project_id"] = project_id
            if status:
                params["status"] = status
            result = client.list_workflow_runs(organization_id, params=params)
            runs = result.get("runs", []) if isinstance(result, dict) else result
            return json.dumps(
                {"status": "success", "count": len(runs), "runs": runs},
                ensure_ascii=False,
                indent=2,
            )
        except (AuthenticationError, APIError) as e:
            return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)

    @mcp.tool()
    def purple_cancel_run(
        api_url: str,
        organization_id: str,
        run_id: str,
        reason: Optional[str] = None,
    ) -> str:
        """
        Cancel a running workflow.

        Args:
            api_url: Purple Codens API base URL
            organization_id: Organization ID
            run_id: Workflow run ID to cancel
            reason: Optional cancellation reason
        """
        try:
            client = get_client(api_url)
            body = {"reason": reason} if reason else {}
            result = client.cancel_workflow_run(organization_id, run_id, body=body)
            return json.dumps(
                {"status": "success", "result": result},
                ensure_ascii=False,
                indent=2,
            )
        except (AuthenticationError, APIError) as e:
            return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)

    @mcp.tool()
    def purple_inject_message(
        api_url: str,
        organization_id: str,
        project_id: str,
        run_id: str,
        message: str,
    ) -> str:
        """
        Inject an instruction message into a running heartbeat run.

        Args:
            api_url: Purple Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            run_id: Heartbeat run ID
            message: Instruction message to inject
        """
        try:
            client = get_client(api_url)
            result = client.inject_to_heartbeat_run(
                organization_id,
                project_id,
                run_id,
                body={"message": message},
            )
            return json.dumps(
                {"status": "success", "result": result},
                ensure_ascii=False,
                indent=2,
            )
        except (AuthenticationError, APIError) as e:
            return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)
