"""Purple Codens REST API client with JWT auth and auto-refresh."""

from typing import Any, Optional

import httpx

from .auth import (
    AUTH_CODENS_CLIENT_ID,
    clear_credentials,
    get_credentials,
    store_credentials,
)


class AuthenticationError(Exception):
    """Raised when not logged in or credentials are invalid."""


class APIError(Exception):
    """Raised when the API returns a non-2xx response."""

    def __init__(self, status_code: int, message: str) -> None:
        self.status_code = status_code
        super().__init__(f"HTTP {status_code}: {message}")


class PurpleCodensClient:
    def __init__(self, api_url: str) -> None:
        self.api_url = api_url.rstrip("/")
        self._token: Optional[str] = None
        self._refresh_token: Optional[str] = None
        self._auth_service_url: Optional[str] = None
        self._org_id: Optional[str] = None
        self._email: Optional[str] = None
        self._user_id: Optional[str] = None
        self._load_stored_credentials()

    # ------------------------------------------------------------------
    # Credential management
    # ------------------------------------------------------------------

    def _load_stored_credentials(self) -> None:
        creds = get_credentials(self.api_url)
        if creds:
            self._token = creds["token"]
            self._org_id = creds["org_id"]
            self._email = creds["email"]
            self._user_id = creds["user_id"]
            self._refresh_token = creds.get("refresh_token")
            self._auth_service_url = creds.get("auth_service_url")

    def _require_auth(self) -> tuple[str, str]:
        if not self._token or not self._org_id:
            raise AuthenticationError(
                "Not logged in. Run purple_login first."
            )
        return self._token, self._org_id

    def _expire_session(self) -> None:
        """Clear stored credentials and reset token state."""
        clear_credentials(self.api_url)
        self._token = None
        self._refresh_token = None

    # ------------------------------------------------------------------
    # Low-level HTTP helpers
    # ------------------------------------------------------------------

    def _headers(self) -> dict[str, str]:
        token, _ = self._require_auth()
        return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    def _url(self, path: str) -> str:
        return f"{self.api_url}{path}"

    def _raise_for_status(self, response: httpx.Response) -> None:
        if response.is_success:
            return
        try:
            detail = response.json().get("detail", response.text)
        except Exception:
            detail = response.text
        raise APIError(response.status_code, detail)

    def _do_refresh_token(self) -> None:
        """Exchange the stored refresh_token for a new access_token."""
        if not self._refresh_token or not self._auth_service_url:
            raise AuthenticationError("No refresh token available.")
        url = f"{self._auth_service_url.rstrip('/')}/oauth/token"
        with httpx.Client(timeout=30) as client:
            response = client.post(
                url,
                data={
                    "grant_type": "refresh_token",
                    "refresh_token": self._refresh_token,
                    "client_id": AUTH_CODENS_CLIENT_ID,
                },
            )
        if not response.is_success:
            raise AuthenticationError("Token refresh failed.")
        data = response.json()
        self._token = data["access_token"]
        if "refresh_token" in data:
            self._refresh_token = data["refresh_token"]
        store_credentials(
            self._token,
            self._user_id or "",
            self._org_id or "",
            self._email or "",
            self.api_url,
            self._refresh_token,
            self._auth_service_url,
        )

    def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        url = self._url(path)
        with httpx.Client(timeout=30) as client:
            response = client.request(method, url, headers=self._headers(), **kwargs)

        # On 401, attempt a token refresh once before giving up
        if response.status_code == 401 and self._refresh_token and self._auth_service_url:
            try:
                self._do_refresh_token()
            except Exception:
                self._expire_session()
                raise AuthenticationError("Session expired. Please run purple_login again.")
            with httpx.Client(timeout=30) as client:
                response = client.request(method, url, headers=self._headers(), **kwargs)

        if response.status_code == 401:
            self._expire_session()
            raise AuthenticationError("Session expired. Please run purple_login again.")

        self._raise_for_status(response)
        if response.status_code == 204 or not response.content:
            return None
        return response.json()

    # ------------------------------------------------------------------
    # Auth endpoints
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_me(me: dict) -> tuple[str, str]:
        """Return (user_id, org_id) from a /auth/me response."""
        user_id = str(me.get("id") or me.get("user_id", ""))
        org = me.get("organization") or {}
        orgs_list = me.get("organizations", [])
        if org:
            org_id = str(org.get("id", ""))
        elif orgs_list:
            org_id = str(orgs_list[0].get("organization_id") or orgs_list[0].get("id", ""))
        else:
            org_id = ""
        return user_id, org_id

    def login(self, email: str, password: str) -> dict:
        url = self._url("/api/v1/auth/login")
        with httpx.Client(timeout=30) as client:
            response = client.post(url, json={"email": email, "password": password})
        self._raise_for_status(response)
        data = response.json()
        token = data["access_token"]

        # Fetch user info with the new token
        me_url = self._url("/api/v1/auth/me")
        with httpx.Client(timeout=30) as client:
            me_response = client.get(
                me_url, headers={"Authorization": f"Bearer {token}"}
            )
        self._raise_for_status(me_response)
        me = me_response.json()

        user_id, org_id = self._parse_me(me)

        self._token = token
        self._org_id = org_id
        self._user_id = user_id
        self._email = email

        store_credentials(token, user_id, org_id, email, self.api_url)
        return {"user": me, "token": token}

    def login_with_device_token(
        self,
        access_token: str,
        refresh_token: Optional[str],
        auth_service_url: str,
    ) -> dict:
        """Store device-code-issued tokens and fetch user/org info.

        Called after device_code_login() succeeds. Fetches /api/v1/auth/me
        from the Purple Codens API using the access token, then persists
        credentials to ~/.purple-codens/credentials.json.

        Args:
            access_token: Access token from the device token response
            refresh_token: Refresh token from the device token response
            auth_service_url: Auth Codens base URL (for future token refresh)

        Returns:
            dict with 'user' and 'token' keys
        """
        me_url = self._url("/api/v1/auth/me")
        with httpx.Client(timeout=30) as client:
            me_response = client.get(
                me_url, headers={"Authorization": f"Bearer {access_token}"}
            )
        self._raise_for_status(me_response)
        me = me_response.json()

        user_id, org_id = self._parse_me(me)
        email = me.get("email", "")

        self._token = access_token
        self._refresh_token = refresh_token
        self._auth_service_url = auth_service_url
        self._org_id = org_id
        self._user_id = user_id
        self._email = email

        store_credentials(
            access_token, user_id, org_id, email, self.api_url, refresh_token, auth_service_url
        )
        return {"user": me, "token": access_token}

    def login_with_code(
        self,
        code: str,
        redirect_uri: str,
        auth_service_url: str,
    ) -> dict:
        """Exchange an OAuth authorization code for tokens.

        Calls POST /oauth/token on Auth Codens, then fetches /api/v1/auth/me
        on the Purple Codens API to retrieve user and organization info.

        Args:
            code: Authorization code received from the OAuth callback
            redirect_uri: The redirect_uri used in the original authorize request
            auth_service_url: Auth Codens base URL (e.g. https://api.auth.codens.ai)

        Returns:
            dict with 'user' and 'token' keys
        """
        token_url = f"{auth_service_url.rstrip('/')}/oauth/token"
        with httpx.Client(timeout=30) as client:
            response = client.post(
                token_url,
                data={
                    "grant_type": "authorization_code",
                    "code": code,
                    "redirect_uri": redirect_uri,
                    "client_id": AUTH_CODENS_CLIENT_ID,
                },
            )
        self._raise_for_status(response)
        token_data = response.json()

        access_token = token_data["access_token"]
        refresh_token = token_data.get("refresh_token")

        # Fetch user/org info from Purple Codens API
        me_url = self._url("/api/v1/auth/me")
        with httpx.Client(timeout=30) as client:
            me_response = client.get(
                me_url, headers={"Authorization": f"Bearer {access_token}"}
            )
        self._raise_for_status(me_response)
        me = me_response.json()

        user_id, org_id = self._parse_me(me)
        email = me.get("email", "")

        self._token = access_token
        self._refresh_token = refresh_token
        self._auth_service_url = auth_service_url
        self._org_id = org_id
        self._user_id = user_id
        self._email = email

        store_credentials(
            access_token, user_id, org_id, email, self.api_url, refresh_token, auth_service_url
        )
        return {"user": me, "token": access_token}

    def whoami(self) -> dict:
        return self._request("GET", "/api/v1/auth/me")

    # ------------------------------------------------------------------
    # Project endpoints
    # ------------------------------------------------------------------

    def list_projects(self) -> list[dict]:
        _, org_id = self._require_auth()
        resp = self._request("GET", f"/api/v1/organizations/{org_id}/projects")
        # API returns {"projects": [...], "total": N}
        if isinstance(resp, dict):
            return resp.get("projects", [])
        return resp

    def create_project(self, name: str, description: str = "") -> dict:
        _, org_id = self._require_auth()
        return self._request(
            "POST",
            f"/api/v1/organizations/{org_id}/projects",
            json={"name": name, "description": description},
        )

    def get_project(self, project_id: str) -> dict:
        _, org_id = self._require_auth()
        return self._request("GET", f"/api/v1/organizations/{org_id}/projects/{project_id}")

    # ------------------------------------------------------------------
    # Repository endpoints
    # ------------------------------------------------------------------

    def list_repositories(self, project_id: str) -> list[dict]:
        _, org_id = self._require_auth()
        resp = self._request(
            "GET", f"/api/v1/organizations/{org_id}/projects/{project_id}/repositories"
        )
        if isinstance(resp, dict):
            return resp.get("repositories", [])
        return resp

    def add_repository(
        self,
        project_id: str,
        github_owner: str,
        github_repo: str,
        branch: str = "main",
        workflow_type: str = "github_flow",
    ) -> dict:
        _, org_id = self._require_auth()
        return self._request(
            "POST",
            f"/api/v1/organizations/{org_id}/projects/{project_id}/repositories",
            json={
                "github_owner": github_owner,
                "github_repo": github_repo,
                "github_branch": branch,
                "workflow_type": workflow_type,
            },
        )

    # ------------------------------------------------------------------
    # Instruction file endpoints
    # ------------------------------------------------------------------

    def list_instructions(self, project_id: str) -> list[dict]:
        _, org_id = self._require_auth()
        resp = self._request(
            "GET", f"/api/v1/organizations/{org_id}/projects/{project_id}/purple/files"
        )
        if isinstance(resp, dict):
            return resp.get("files", [])
        return resp

    def import_instructions(self, project_id: str, repository_id: str) -> dict:
        _, org_id = self._require_auth()
        return self._request(
            "POST",
            f"/api/v1/organizations/{org_id}/projects/{project_id}/purple/files/import-from-repo",
            json={"repository_id": repository_id},
        )

    def create_instruction(
        self, project_id: str, name: str, content: str, file_type: str = "rule"
    ) -> dict:
        _, org_id = self._require_auth()
        return self._request(
            "POST",
            f"/api/v1/organizations/{org_id}/projects/{project_id}/purple/files",
            json={"filename": name, "content": content, "file_type": file_type, "is_active": True},
        )

    def update_instruction(self, project_id: str, file_id: str, content: str) -> dict:
        _, org_id = self._require_auth()
        return self._request(
            "PUT",
            f"/api/v1/organizations/{org_id}/projects/{project_id}/purple/files/{file_id}",
            json={"content": content},
        )

    # ------------------------------------------------------------------
    # Purple project settings
    # ------------------------------------------------------------------

    def get_purple_project(self, project_id: str) -> dict:
        _, org_id = self._require_auth()
        return self._request(
            "GET", f"/api/v1/organizations/{org_id}/projects/{project_id}/purple"
        )

    def create_purple_project(self, project_id: str, **settings: Any) -> dict:
        _, org_id = self._require_auth()
        return self._request(
            "POST",
            f"/api/v1/organizations/{org_id}/projects/{project_id}/purple",
            json=settings,
        )

    def update_purple_project(self, project_id: str, **settings: Any) -> dict:
        _, org_id = self._require_auth()
        return self._request(
            "PUT",
            f"/api/v1/organizations/{org_id}/projects/{project_id}/purple",
            json=settings,
        )

    # ------------------------------------------------------------------
    # Workflow endpoints
    # ------------------------------------------------------------------

    def create_workflow(self, organization_id: str, body: dict) -> dict:
        return self._request(
            "POST",
            f"/api/v1/organizations/{organization_id}/workflows",
            json=body,
        )

    def get_workflow_run(self, organization_id: str, run_id: str) -> dict:
        return self._request(
            "GET",
            f"/api/v1/organizations/{organization_id}/workflow-runs/{run_id}",
        )

    def list_workflow_runs(self, organization_id: str, params: Optional[dict] = None) -> dict:
        return self._request(
            "GET",
            f"/api/v1/organizations/{organization_id}/workflow-runs",
            params=params or {},
        )

    def cancel_workflow_run(self, organization_id: str, run_id: str, body: Optional[dict] = None) -> dict:
        return self._request(
            "POST",
            f"/api/v1/organizations/{organization_id}/workflow-runs/{run_id}/cancel",
            json=body or {},
        )

    def inject_to_heartbeat_run(
        self,
        organization_id: str,
        project_id: str,
        run_id: str,
        body: dict,
    ) -> dict:
        return self._request(
            "POST",
            f"/api/v1/organizations/{organization_id}/projects/{project_id}/purple/heartbeat/runs/{run_id}/inject",
            json=body,
        )

    # ------------------------------------------------------------------
    # Log endpoints
    # ------------------------------------------------------------------

    def list_workflow_run_jobs(self, organization_id: str, run_id: str) -> dict:
        return self._request(
            "GET",
            f"/api/v1/organizations/{organization_id}/workflow-runs/{run_id}/jobs",
        )

    def get_task_log_url(self, organization_id: str, project_id: str, task_id: str) -> dict:
        return self._request(
            "GET",
            f"/api/v1/organizations/{organization_id}/projects/{project_id}/purple/tasks/{task_id}/log",
        )

    @property
    def org_id(self) -> Optional[str]:
        return self._org_id

    @property
    def is_authenticated(self) -> bool:
        return bool(self._token and self._org_id)
