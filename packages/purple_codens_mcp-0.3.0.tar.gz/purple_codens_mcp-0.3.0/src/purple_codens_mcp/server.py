"""MCP server entry point for Purple Codens."""

import argparse
import sys
from typing import Optional

from mcp.server.fastmcp import FastMCP

from .client import PurpleCodensClient
from .tools.auth_tools import register_auth_tools
from .tools.instruction_tools import register_instruction_tools
from .tools.project_tools import register_project_tools
from .tools.repo_tools import register_repo_tools
from .tools.log_tools import register_log_tools
from .tools.sse_tools import register_sse_tools
from .tools.workflow_tools import register_workflow_tools

# ---------------------------------------------------------------------------
# Shared client registry — keyed by api_url so one process can talk to
# multiple Purple Codens instances (uncommon but supported).
# ---------------------------------------------------------------------------
_clients: dict[str, PurpleCodensClient] = {}


def _get_client(api_url: str, force_reload: bool = False) -> PurpleCodensClient:
    if force_reload or api_url not in _clients:
        _clients[api_url] = PurpleCodensClient(api_url)
    return _clients[api_url]


def build_server(api_url: Optional[str] = None) -> FastMCP:
    mcp = FastMCP(
        "purple-codens",
        instructions=(
            "Purple Codens MCP server. "
            "Use purple_login first, then purple_analyze_repo and purple_init_project "
            "to set up a project. All tools require the api_url parameter "
            "(default: https://api.purple.codens.ai)."
        ),
    )

    register_auth_tools(mcp, _get_client)
    register_project_tools(mcp, _get_client)
    register_repo_tools(mcp, _get_client)
    register_instruction_tools(mcp, _get_client)
    register_workflow_tools(mcp, _get_client)
    register_sse_tools(mcp, _get_client)
    register_log_tools(mcp, _get_client)

    return mcp


def _cmd_login(args: argparse.Namespace) -> None:
    """Handle `purple-codens-mcp login`."""
    from .auth import device_code_login

    auth_url = args.auth_url
    api_url = args.api_url

    print(f"Logging in to {api_url} via {auth_url} ...\n")
    token_resp = device_code_login(auth_url)

    client = PurpleCodensClient(api_url)
    result = client.login_with_device_token(
        access_token=token_resp["access_token"],
        refresh_token=token_resp.get("refresh_token"),
        auth_service_url=auth_url,
    )
    email = result.get("user", {}).get("email", "unknown")
    print(f"\nLogged in as {email}")


def _cmd_whoami(args: argparse.Namespace) -> None:
    """Handle `purple-codens-mcp whoami`."""
    client = PurpleCodensClient(args.api_url)
    if not client._token:
        print("Not logged in. Run: purple-codens-mcp login")
        sys.exit(1)
    try:
        me = client._request("GET", "/api/v1/auth/me")
        print(f"Email: {me.get('email')}")
        print(f"User ID: {me.get('id')}")
        orgs = me.get("organizations", [])
        if orgs:
            print(f"Organization: {orgs[0].get('organization_name')} ({orgs[0].get('role')})")
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


def _cmd_serve(args: argparse.Namespace) -> None:
    """Handle `purple-codens-mcp serve` (default)."""
    mcp = build_server(api_url=args.api_url)
    mcp.run(transport=args.transport)


def main() -> None:
    parser = argparse.ArgumentParser(description="Purple Codens MCP Server")
    parser.add_argument(
        "--api-url",
        default="https://api.purple.codens.ai",
        help="Purple Codens API base URL",
    )
    sub = parser.add_subparsers(dest="command")

    # purple-codens-mcp login
    login_p = sub.add_parser("login", help="Authenticate via Device Code Flow")
    login_p.add_argument(
        "--auth-url",
        default="https://api.auth.codens.ai",
        help="Auth Codens base URL",
    )

    # purple-codens-mcp whoami
    sub.add_parser("whoami", help="Show current authenticated user")

    # purple-codens-mcp serve (or no subcommand = default)
    serve_p = sub.add_parser("serve", help="Start MCP server (default)")
    serve_p.add_argument(
        "--transport",
        default="stdio",
        choices=["stdio"],
        help="MCP transport",
    )

    args = parser.parse_args()

    if args.command == "login":
        _cmd_login(args)
    elif args.command == "whoami":
        _cmd_whoami(args)
    elif args.command == "serve":
        _cmd_serve(args)
    else:
        # No subcommand = start MCP server (backward compatible)
        args.transport = "stdio"
        _cmd_serve(args)


if __name__ == "__main__":
    main()
