from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import yaml
from pydantic import ValidationError

from iints.core.simulator import StressEvent
from iints.validation.schemas import ScenarioModel, StressEventModel, PatientConfigModel, LATEST_SCHEMA_VERSION
from iints.validation.run_validation import (
    ValidationRule,
    ValidationProfile,
    ValidationCheckResult,
    RunValidationReport,
    load_validation_profiles,
    compute_run_metrics,
    evaluate_run,
)
from iints.validation.safety_contract import (
    SafetyContractSpec,
    SafetyContractViolation,
    SafetyContractVerificationReport,
    load_contract_spec,
    apply_contract_to_config,
    verify_safety_contract,
)
from iints.validation.replay import (
    ReplayRunDigest,
    ReplayCheckResult,
    run_deterministic_replay_check,
)
from iints.validation.golden import (
    GoldenScenarioSpec,
    GoldenBenchmarkPack,
    load_golden_benchmark_pack,
    evaluate_expected_ranges,
)


def _convert_legacy_scenario(data: Dict[str, Any]) -> Dict[str, Any]:
    if "events" in data and "stress_events" not in data:
        events = []
        for event in data.get("events", []):
            event_type = event.get("type")
            if event_type == "carb_error":
                event = dict(event)
                event["reported_value"] = 0
                event_type = "meal"
            events.append(
                {
                    "start_time": event.get("time"),
                    "event_type": event_type,
                    "value": event.get("value"),
                    "reported_value": event.get("reported_value"),
                    "absorption_delay_minutes": event.get("absorption_delay_minutes", 0),
                    "duration": event.get("duration", 0),
                }
            )
        return {
            "scenario_name": data.get("scenario_name", "Legacy Scenario"),
            "scenario_version": data.get("scenario_version", "legacy"),
            "description": data.get("description", ""),
            "stress_events": events,
        }
    return data


def migrate_scenario_dict(data: Dict[str, Any]) -> Dict[str, Any]:
    """Normalize legacy schemas into the latest scenario schema."""
    data = _convert_legacy_scenario(data)
    if "schema_version" not in data or not data.get("schema_version"):
        data["schema_version"] = LATEST_SCHEMA_VERSION
    if "scenario_version" not in data or not data.get("scenario_version"):
        data["scenario_version"] = "1.0"
    if "scenario_name" not in data or not data.get("scenario_name"):
        data["scenario_name"] = "Unnamed Scenario"
    return data


def load_scenario(path: Union[str, Path]) -> ScenarioModel:
    scenario_path = Path(path)
    data = json.loads(scenario_path.read_text())
    data = migrate_scenario_dict(data)
    return ScenarioModel.model_validate(data)


def validate_scenario_dict(data: Dict[str, Any]) -> ScenarioModel:
    data = migrate_scenario_dict(data)
    return ScenarioModel.model_validate(data)


def scenario_warnings(model: ScenarioModel) -> List[str]:
    warnings: List[str] = []
    for idx, event in enumerate(model.stress_events):
        prefix = f"event[{idx}]"
        if event.event_type in {"meal", "missed_meal"} and event.value is not None:
            if event.value > 200:
                warnings.append(f"{prefix}: meal value {event.value}g is unusually high")
        if event.absorption_delay_minutes > 120:
            warnings.append(f"{prefix}: absorption_delay_minutes {event.absorption_delay_minutes} is unusual")
        if event.duration > 240:
            warnings.append(f"{prefix}: duration {event.duration} is unusual")
    return warnings


def build_stress_events(payloads: List[Dict[str, Any]]) -> List[StressEvent]:
    events: List[StressEvent] = []
    for event_data in payloads:
        events.append(
            StressEvent(
                start_time=event_data["start_time"],
                event_type=event_data["event_type"],
                value=event_data.get("value"),
                reported_value=event_data.get("reported_value"),
                absorption_delay_minutes=event_data.get("absorption_delay_minutes", 0),
                duration=event_data.get("duration", 0),
                isf=event_data.get("isf"),
                icr=event_data.get("icr"),
                basal_rate=event_data.get("basal_rate"),
                dia_minutes=event_data.get("dia_minutes"),
            )
        )
    return events


def scenario_to_payloads(model: ScenarioModel) -> List[Dict[str, Any]]:
    return [event.model_dump() for event in model.stress_events]


def validate_patient_config_dict(data: Dict[str, Any]) -> PatientConfigModel:
    return PatientConfigModel.model_validate(data)


def load_patient_config(path: Union[str, Path]) -> PatientConfigModel:
    config_path = Path(path)
    data = yaml.safe_load(config_path.read_text())
    return validate_patient_config_dict(data)


def load_patient_config_by_name(name: str) -> PatientConfigModel:
    filename = f"{name}.yaml" if not name.endswith(".yaml") else name
    if sys.version_info >= (3, 9):
        from importlib.resources import files
        content = files("iints.data.virtual_patients").joinpath(filename).read_text()
    else:
        from importlib import resources
        content = resources.read_text("iints.data.virtual_patients", filename)
    data = yaml.safe_load(content)
    return validate_patient_config_dict(data)


def format_validation_error(error: ValidationError) -> List[str]:
    lines: List[str] = []
    for entry in error.errors():
        loc = ".".join(str(item) for item in entry.get("loc", []))
        msg = entry.get("msg", "Invalid value")
        lines.append(f"{loc}: {msg}")
    return lines


__all__ = [
    "StressEventModel",
    "ScenarioModel",
    "PatientConfigModel",
    "LATEST_SCHEMA_VERSION",
    "ValidationRule",
    "ValidationProfile",
    "ValidationCheckResult",
    "RunValidationReport",
    "SafetyContractSpec",
    "SafetyContractViolation",
    "SafetyContractVerificationReport",
    "load_scenario",
    "validate_scenario_dict",
    "scenario_warnings",
    "build_stress_events",
    "scenario_to_payloads",
    "validate_patient_config_dict",
    "load_patient_config",
    "load_patient_config_by_name",
    "load_validation_profiles",
    "compute_run_metrics",
    "evaluate_run",
    "load_contract_spec",
    "apply_contract_to_config",
    "verify_safety_contract",
    "ReplayRunDigest",
    "ReplayCheckResult",
    "run_deterministic_replay_check",
    "GoldenScenarioSpec",
    "GoldenBenchmarkPack",
    "load_golden_benchmark_pack",
    "evaluate_expected_ranges",
    "format_validation_error",
    "migrate_scenario_dict",
]
