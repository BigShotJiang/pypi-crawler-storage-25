from __future__ import annotations

import atexit
import json
import os
import re
import shlex
import signal
import subprocess
import sys
import time
import urllib.parse
from pathlib import Path
from typing import Any

from aidsc.env_bootstrap import ensure_gitignore_env, load_dotenv_if_present
from aidsc.models import LanguageInferenceRequest
from aidsc.zeus_client import ZeusHttpClient


# ──────────────────────────────────────────────────────────────────────────────
# Console helpers
# ──────────────────────────────────────────────────────────────────────────────

def _clear() -> None:
    os.system("cls" if os.name == "nt" else "clear")


def _banner(title: str) -> None:
    width = 60
    print("┌" + "─" * (width - 2) + "┐")
    print(f"│{'  AIDSC — Zeus Client':^{width - 2}}│")
    print(f"│{title:^{width - 2}}│")
    print("└" + "─" * (width - 2) + "┘")
    print()


def _section(label: str) -> None:
    print(f"\n  ▸ {label}")


def _ok(msg: str) -> None:
    print(f"  ✔  {msg}")


def _warn(msg: str) -> None:
    print(f"  ✖  {msg}")


def _prompt(label: str, secret: bool = False) -> str:
    if secret:
        import getpass
        return getpass.getpass(f"  ➤  {label}: ").strip()
    return input(f"  ➤  {label}: ").strip()


# ──────────────────────────────────────────────────────────────────────────────
# .env helpers — no-duplicate writes
# ──────────────────────────────────────────────────────────────────────────────

def _read_env_file(env_path: Path) -> dict[str, str]:
    """Return key→value map from a .env file (simple KEY=... lines only)."""
    result: dict[str, str] = {}
    if not env_path.is_file():
        return result
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        m = re.match(r'^([A-Za-z_][A-Za-z0-9_]*)=(.*)$', line)
        if m:
            result[m.group(1)] = m.group(2)
    return result


def _write_env_keys(env_path: Path, updates: dict[str, str]) -> None:
    """Write/update keys in a .env file without creating duplicates."""
    existing = _read_env_file(env_path)
    existing.update(updates)

    lines: list[str] = []
    if env_path.is_file():
        for line in env_path.read_text(encoding="utf-8").splitlines():
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                lines.append(line)
                continue
            m = re.match(r'^([A-Za-z_][A-Za-z0-9_]*)=', stripped)
            if m and m.group(1) in updates:
                continue  # will be appended below
            lines.append(line)

    # Append updated keys at end
    for k, v in updates.items():
        lines.append(f"{k}={json.dumps(v)}")

    env_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


# ──────────────────────────────────────────────────────────────────────────────
# Request mapping
# ──────────────────────────────────────────────────────────────────────────────

def language_request_to_zeus(
    req: LanguageInferenceRequest,
    *,
    server: int | str | None = None,
    max_new_tokens: int | None = None,
    client_timeout: int | None = None,
) -> dict[str, Any]:
    """Map aidsc language payload to the JSON body expected by ``POST /api/requests``."""
    tokens = req.max_new_tokens if max_new_tokens is None else max_new_tokens
    body: dict[str, Any] = {
        "model": req.args.model,
        "prompt": req.args.questions,
        "max_context_length": req.max_context_length,
        "max_server_uptime": req.max_server_uptime,
        "max_new_tokens": tokens,
        "total_concurrent_models": req.total_concurrent_models,
        "max_num_seqs": req.max_num_seqs,
    }
    if server is not None:
        body["server"] = server
    if client_timeout is not None:
        body["client_timeout"] = client_timeout
    return body


# ──────────────────────────────────────────────────────────────────────────────
# Main client
# ──────────────────────────────────────────────────────────────────────────────

class aidsc:
    # ...existing code...
    def infer(
        self,
        request: LanguageInferenceRequest,
        *,
        server: int | str | None = None,
        max_new_tokens: int | None = None,
        client_timeout: int | None = None,
    ) -> dict[str, Any]:
        """POST a language job to Zeus and return the JSON response."""
        self.ensure_ready()
        body = language_request_to_zeus(
            request,
            server=server,
            max_new_tokens=max_new_tokens,
            client_timeout=client_timeout,
        )
        client = ZeusHttpClient(self.effective_base_url, timeout=self._infer_timeout)
        return client.post_requests(body)


# ──────────────────────────────────────────────────────────────────────────────
# Main client
# ──────────────────────────────────────────────────────────────────────────────

class aidsc:
    """
    High-level Zeus client.

    On first use, checks ``localhost:32553``.  If that port is not reachable it
    opens an SSH tunnel through PAMD, reading credentials from environment
    variables ``PAMD_USER`` / ``PAMD_PASS`` (or a local ``.env`` file) before
    prompting interactively.

    The tunnel is torn down automatically when the Python process exits.
    """

    _tunnel_proc: subprocess.Popen | None = None

    def __init__(
        self,
        *,
        local_base_url: str | None = None,
        infer_timeout: float = 600.0,
        dotenv_path: str | os.PathLike[str] | None = None,
    ) -> None:
        load_dotenv_if_present(dotenv_path)
        default_local = os.environ.get("aidsc_ZEUS_LOCAL_URL", "http://127.0.0.1:32553")
        self._local_base = (local_base_url or default_local).rstrip("/")
        self._infer_timeout = infer_timeout
        self._mode: str | None = None
        self._tunnel_proc: subprocess.Popen | None = None

        # Register cleanup so the tunnel is killed when the interpreter exits
        atexit.register(self._teardown_tunnel)
        signal.signal(signal.SIGTERM, self._on_signal)

    # ── internal tunnel lifecycle ─────────────────────────────────────────────

    def _on_signal(self, signum, frame) -> None:  # noqa: ANN001
        self._teardown_tunnel()
        sys.exit(0)

    def _teardown_tunnel(self) -> None:
        if self._tunnel_proc is not None and self._tunnel_proc.poll() is None:
            _section("Shutting down SSH tunnel …")
            try:
                self._tunnel_proc.terminate()
                self._tunnel_proc.wait(timeout=5)
                _ok("SSH tunnel closed.")
            except Exception:
                try:
                    self._tunnel_proc.kill()
                except Exception:
                    pass
            self._tunnel_proc = None

    # ── local health check ────────────────────────────────────────────────────

    def _local_ok(self, timeout: float = 10.0) -> bool:
        try:
            return ZeusHttpClient(self._local_base, timeout=timeout).get_zeus_health()
        except Exception:
            return False

    # ── interactive setup ─────────────────────────────────────────────────────

    def setup_interactive(self) -> None:
        """
        Interactively set up an SSH tunnel to PAMD if localhost:32553 is not
        already reachable.  Reads ``PAMD_USER`` / ``PAMD_PASS`` from the
        environment (or .env) first; only prompts for what is missing.
        """
        _clear()
        _banner("Connection Setup")

        # ── step 1: check local port ──────────────────────────────────────
        _section("Checking localhost:32553 …")
        if self._local_ok():
            _ok("Port 32553 is already active — no tunnel needed.")
            self._mode = "local"
            ensure_gitignore_env()
            return

        _warn("Port 32553 is not reachable.")
        print()
        print("  An SSH tunnel to PAMD is required to reach Zeus remotely.")
        print("  Credentials will be read from PAMD_USER / PAMD_PASS env vars")
        print("  (or your .env file) if available.\n")

        # ── step 2: gather credentials ────────────────────────────────────
        env_path = Path.cwd() / ".env"

        pamd_user = os.environ.get("PAMD_USER", "").strip()
        pamd_pass = os.environ.get("PAMD_PASS", "").strip()

        if pamd_user:
            _ok(f"PAMD username loaded from environment: {pamd_user}")
        else:
            _section("PAMD Credentials")
            pamd_user = _prompt("PAMD username (e.g. abc12b)")
            if not pamd_user:
                raise RuntimeError("A PAMD username is required to establish the SSH tunnel.")

        if pamd_pass:
            _ok("PAMD password loaded from environment.")
        else:
            pamd_pass = _prompt("PAMD password", secret=True)
            if not pamd_pass:
                raise RuntimeError("A PAMD password is required to establish the SSH tunnel.")

        # ── step 3: offer to save credentials ────────────────────────────
        already_in_env = bool(os.environ.get("PAMD_USER")) and bool(os.environ.get("PAMD_PASS"))
        if not already_in_env:
            print()
            save_ans = _prompt("Save credentials to .env for future sessions? [y/N]")
            if save_ans.lower().startswith("y"):
                _write_env_keys(env_path, {"PAMD_USER": pamd_user, "PAMD_PASS": pamd_pass})
                os.environ["PAMD_USER"] = pamd_user
                os.environ["PAMD_PASS"] = pamd_pass
                ensure_gitignore_env()
                _ok(f"Credentials saved to {env_path}  (.env is git-ignored)")

        # ── step 4: open the tunnel ───────────────────────────────────────
        remote_url_str = os.environ.get("aidsc_ZEUS_REMOTE_URL", "http://144.174.11.196:32553")
        parsed = urllib.parse.urlparse(remote_url_str)
        remote_host = parsed.hostname or "144.174.11.196"
        remote_port = parsed.port or 32553

        print()
        _section(f"Opening SSH tunnel  localhost:32553 → {remote_host}:{remote_port} via pamd.sc.fsu.edu …")

        cmd = [
            "sshpass", "-p", pamd_pass,
            "ssh",
            "-o", "StrictHostKeyChecking=no",
            "-o", "BatchMode=no",
            "-N",
            "-L", f"32553:{remote_host}:{remote_port}",
            f"{pamd_user}@pamd.sc.fsu.edu",
        ]

        try:
            # Keep the process handle so we can kill it on exit
            self._tunnel_proc = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
            )
        except FileNotFoundError:
            raise RuntimeError(
                "sshpass is not installed.  Install it with: sudo apt install sshpass"
            )

        # Give SSH a moment to bind the port, then verify
        time.sleep(2)
        if self._tunnel_proc.poll() is not None:
            stderr = self._tunnel_proc.stderr.read().decode(errors="replace").strip()
            raise RuntimeError(f"SSH tunnel process exited immediately: {stderr}")

        if not self._local_ok(timeout=10.0):
            self._tunnel_proc.terminate()
            self._tunnel_proc = None
            raise RuntimeError("SSH tunnel is up but localhost:32553 is still not responding.")

        _ok("SSH tunnel established — localhost:32553 is now active.")
        print()

        # ── step 5: ask whether to keep tunnel alive after exit ───────────
        keep_ans = _prompt("Keep SSH tunnel open in background after exit? [y/N]")
        if keep_ans.lower().startswith("y"):
            # Detach — stop tracking the process so atexit won't kill it
            self._tunnel_proc = None
            _ok("Tunnel will remain running in the background.")
        else:
            _ok("Tunnel will be closed when this session ends.")
        print()

    # ── public API ────────────────────────────────────────────────────────────

    @property
    def effective_base_url(self) -> str:
        """URL used for ``/api/requests`` after ``ensure_ready``."""
        return self._local_base

    def ensure_ready(self) -> None:
        """
        Verify Zeus is reachable on localhost:32553.
        If not, launches ``setup_interactive`` to establish the SSH tunnel.
        """
        if self._local_ok():
            self._mode = "local"
            return

        self.setup_interactive()

        # Final check
        if not self._local_ok():
            raise RuntimeError(
                "Zeus is still not reachable on localhost:32553 after tunnel setup."
            )
        self._mode = "local"

    def infer(
        self,
        request: LanguageInferenceRequest,
        *,
        server: int | str | None = None,
        max_new_tokens: int | None = None,
        client_timeout: int | None = None,
    ) -> list[dict[str, Any]]:
        """POST a language job to Zeus and return the JSON response."""
        self.ensure_ready()
        client = ZeusHttpClient(self.effective_base_url, timeout=self._infer_timeout)
        
        results = []
        for question in request.args.questions:
            body = {
                "model": request.args.model,
                "prompt": question,
                "message": question,
                "max_context_length": request.max_context_length,
                "max_server_uptime": request.max_server_uptime,
                "max_new_tokens": max_new_tokens or request.max_new_tokens,
                "total_concurrent_models": request.total_concurrent_models,
                "max_num_seqs": request.max_num_seqs,
            }
            if server is not None:
                body["server"] = server
            if client_timeout is not None:
                body["client_timeout"] = client_timeout
            
            results.append(client.post_requests(body))
        
        return results
