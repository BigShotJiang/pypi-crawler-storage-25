#!/usr/bin/env python3
"""Packaging metadata for Sandai Operator Client."""

from pathlib import Path

from setuptools import find_namespace_packages, setup

readme_path = Path(__file__).parent / "README.md"
long_description = readme_path.read_text(encoding="utf-8") if readme_path.exists() else ""

setup(
    name="sandai-operator-client",
    version="0.5.0",
    description="Client library for the Sandai Operator SDK",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Sandai Team",
    author_email="dev@sand.ai",
    url="https://github.com/world-sim-dev/sandai-data-project",
    packages=find_namespace_packages(include=["sandai.*"]),
    python_requires=">=3.8",
    install_requires=[
        "celery>=5.2.0",
        "redis>=4.0.0",
        "kombu>=5.2.0",
        "msgpack>=1.0.0",
    ],
    extras_require={
        "tracing": [
            "opentelemetry-api>=1.0.0",
        ],
        "dev": [
            "black>=24.0.0",
            "flake8>=7.0.0",
            "isort>=5.13.0",
            "mypy>=1.10.0",
        ],
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Programming Language :: Python :: 3.14",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: System :: Distributed Computing",
    ],
)
