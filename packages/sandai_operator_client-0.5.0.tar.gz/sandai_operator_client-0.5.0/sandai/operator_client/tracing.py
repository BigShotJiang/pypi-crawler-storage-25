"""
Per-job OpenTelemetry tracing support for sandai-operator-client.

Install  : pip install sandai-operator-client[tracing]
Enable   : export SANDAI_OPERATOR_TRACING_ENABLED=true
Configure: set up a TracerProvider (e.g. via opentelemetry-sdk) in your application.

Usage
-----
Tracing is automatic — just enable it and configure a provider::

    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import SimpleSpanProcessor
    from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
    from opentelemetry import trace

    provider = TracerProvider()
    provider.add_span_processor(SimpleSpanProcessor(OTLPSpanExporter()))
    trace.set_tracer_provider(provider)

    # Each client.sync() call will now emit an operator.client.call span that
    # propagates context to the server-side operator.task span.

When SANDAI_OPERATOR_TRACING_ENABLED is not "true" / "1", all functions are no-ops.
"""
from __future__ import annotations

import os
from contextlib import contextmanager
from typing import Any, Dict, Generator, Optional

# ---------------------------------------------------------------------------
# Module-level initialisation — re-configurable via _reset_for_testing()
# ---------------------------------------------------------------------------

_TRACING_ENABLED: bool = os.getenv("SANDAI_OPERATOR_TRACING_ENABLED", "false").lower() in (
    "true",
    "1",
)

_ot_trace: Any = None
_StatusCode: Any = None

if _TRACING_ENABLED:
    try:
        import opentelemetry.trace as _ot_trace  # type: ignore[assignment]
        from opentelemetry.trace import StatusCode as _StatusCode  # type: ignore[assignment]
    except ImportError:
        pass

_TRACER_NAME = "sandai.operator.client"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

@contextmanager
def operator_span(operator_name: str) -> Generator[Optional[Any], None, None]:
    """Context manager that wraps a synchronous operator call in a tracing span.

    Use around :meth:`OperatorClient.sync` calls. The ``task.id`` attribute is
    set by the caller after the task has been submitted::

        with tracing.operator_span(client.operator_name) as span:
            async_result = client._send_task_async(...)
            if span is not None:
                span.set_attribute("task.id", async_result.id)
            result = client._wait_for_task_result(async_result, ...)

    Yields ``None`` when tracing is disabled so callers can always use the
    same ``if span is not None`` guard without conditional imports.
    """
    if _ot_trace is None:
        yield None
        return
    tracer = _ot_trace.get_tracer(_TRACER_NAME)
    with tracer.start_as_current_span(
        "operator.client.call",
        attributes={"operator.name": operator_name},
    ) as span:
        yield span


def inject_trace_context(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Inject the active span's W3C trace context into the task payload.

    Adds a ``_tracing`` key containing the W3C traceparent/tracestate headers
    so the server-side SDK can extract a parent context and create a child span.

    Returns the payload unchanged (no copy) when tracing is disabled or when
    no span is currently active.
    """
    if _ot_trace is None:
        return payload
    try:
        from opentelemetry.propagate import inject  # type: ignore[import]

        carrier: Dict[str, str] = {}
        inject(carrier)
        if carrier:
            payload = dict(payload)
            payload["_tracing"] = carrier
    except Exception:
        pass
    return payload


# ---------------------------------------------------------------------------
# Test helpers
# ---------------------------------------------------------------------------

def _reset_for_testing(enabled: bool = True) -> None:
    """Reset module-level state. **Do not call in production code.**"""
    global _TRACING_ENABLED, _ot_trace, _StatusCode
    _TRACING_ENABLED = enabled
    if enabled:
        try:
            import opentelemetry.trace

            _ot_trace = opentelemetry.trace
            from opentelemetry.trace import StatusCode

            _StatusCode = StatusCode
        except ImportError:
            _ot_trace = None
            _StatusCode = None
    else:
        _ot_trace = None
        _StatusCode = None
