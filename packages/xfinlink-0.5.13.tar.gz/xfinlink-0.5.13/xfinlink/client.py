"""HTTP client for the xfinlink API.

    import xfinlink as xfl
    df = xfl.prices("AAPL", start="2024-01-01", end="2024-12-31")
    df = xfl.fundamentals("AAPL", period_type="annual")
"""
from __future__ import annotations

import os
import warnings
from datetime import date, timedelta

import httpx

try:
    import pandas as pd
except ImportError:
    raise ImportError(
        "xfinlink: pandas is required but not installed. "
        "Fix: run 'pip install pandas' in your terminal."
    )

# ── Custom exception ──────────────────────────────────────────────────


class XfinlinkError(Exception):
    """Base exception for all xfinlink errors."""
    pass


# ── Module-level state ────────────────────────────────────────────────

API_BASE = "https://api.xfinlink.com"
_TIMEOUT = 120.0
_API_KEY: str | None = None
_MAX_PAGES = 50

# ── Period shorthand (like yfinance) ──────────────────────────────────

_PERIOD_MAP = {
    "1w": timedelta(weeks=1),
    "1mo": timedelta(days=30),
    "3mo": timedelta(days=90),
    "6mo": timedelta(days=182),
    "1y": timedelta(days=365),
    "2y": timedelta(days=730),
    "3y": timedelta(days=1095),
    "5y": timedelta(days=1825),
    "10y": timedelta(days=3650),
}


def _resolve_period(
    period: str | None,
    start: str | None,
    end: str | None,
) -> tuple[str | None, str | None]:
    """Convert a period shorthand into (start, end). Returns (start, end)."""
    if period is None:
        return start, end
    if start is not None or end is not None:
        raise XfinlinkError(
            "xfinlink: cannot use 'period' together with 'start'/'end'. "
            "Fix: use either period='1y' OR start='2025-01-01'"
        )
    period = period.lower().strip()
    if period == "ytd":
        return date.today().replace(month=1, day=1).isoformat(), None
    if period == "max":
        return "1900-01-01", None
    delta = _PERIOD_MAP.get(period)
    if delta is None:
        valid = list(_PERIOD_MAP.keys()) + ["ytd", "max"]
        raise XfinlinkError(
            f"xfinlink: period='{period}' not valid. Fix: use one of {valid}"
        )
    return (date.today() - delta).isoformat(), None


# ── Configuration ─────────────────────────────────────────────────────


def set_api_base(url: str) -> None:
    """Override the API base URL. Useful for local testing."""
    global API_BASE
    API_BASE = url.rstrip("/")


def set_api_key(key: str) -> None:
    """Set the API key for all subsequent requests."""
    global _API_KEY
    _API_KEY = key


def set_timeout(seconds: float) -> None:
    """Override the default HTTP timeout (default: 120s)."""
    global _TIMEOUT
    _TIMEOUT = float(seconds)


def _get_api_key() -> str | None:
    """Return the API key from set_api_key() or XFINLINK_API_KEY env var."""
    return _API_KEY or os.environ.get("XFINLINK_API_KEY") or os.environ.get("XFL_API_KEY")


def _default_start() -> str:
    """Return a date string 1 year ago from today."""
    return (date.today() - timedelta(days=365)).isoformat()


# ── Validation helpers ────────────────────────────────────────────────


def _validate_ticker(ticker: str | list[str] | tuple, func_name: str = "") -> str:
    """Validate ticker input and return a comma-separated string.

    Accepts strings, lists, and tuples. Space-separated strings are
    converted to comma-separated (like yfinance).
    """
    if isinstance(ticker, (list, tuple)):
        ticker = ",".join(str(t).strip() for t in ticker)
    if not isinstance(ticker, str):
        raise XfinlinkError(
            f"xfinlink: ticker must be a string or list, not "
            f"{type(ticker).__name__}. "
            f"Fix: xfl.prices('AAPL') or xfl.prices(['AAPL', 'MSFT'])"
        )
    # Space-separated → comma-separated (yfinance compat)
    if " " in ticker and "," not in ticker:
        ticker = ",".join(ticker.split())
    # Normalize: strip whitespace from each ticker
    ticker = ",".join(t.strip() for t in ticker.split(","))
    # Reject empty
    if not ticker or not ticker.replace(",", "").strip():
        raise XfinlinkError(
            "xfinlink: ticker cannot be empty. "
            "Fix: xfl.prices('AAPL')"
        )
    return ticker


def _validate_dates(
    start: str | date | None,
    end: str | date | None,
) -> tuple[str | None, str | None]:
    """Validate and normalize date parameters. Returns (start, end) as strings."""
    results: list[str | None] = []
    for param_name, param_val in [("start", start), ("end", end)]:
        if param_val is None:
            results.append(None)
            continue
        # Accept date/datetime/pd.Timestamp objects
        if hasattr(param_val, "isoformat"):
            param_val = param_val.isoformat()[:10]
        if not isinstance(param_val, str):
            raise XfinlinkError(
                f"xfinlink: {param_name} must be a string or date object, "
                f"not {type(param_val).__name__}. "
                f"Fix: {param_name}='2025-01-01' or {param_name}=date(2025, 1, 1)"
            )
        if len(param_val) != 10 or param_val[4] != "-" or param_val[7] != "-":
            raise XfinlinkError(
                f"xfinlink: {param_name}='{param_val}' is not valid. "
                f"Fix: use YYYY-MM-DD format, e.g. {param_name}='2025-01-01'"
            )
        results.append(param_val)
    return results[0], results[1]


def _warn_empty(ticker: str, start: str | None, end: str | None) -> None:
    """Emit a warning when no data is returned."""
    msg = f"xfinlink: No data returned for '{ticker}'"
    if start or end:
        msg += f" in range {start or '...'} to {end or '...'}"
    msg += ". Fix: check ticker spelling with xfl.search(q='...'), or widen the date range."
    warnings.warn(msg, UserWarning, stacklevel=3)


# ── HTTP internals ────────────────────────────────────────────────────


def _extract_ticker(resp: httpx.Response) -> str:
    """Try to extract the ticker from the request URL path."""
    try:
        path = resp.request.url.path
        # /v1/prices/AAPL or /v1/fundamentals/AAPL,MSFT
        parts = path.strip("/").split("/")
        if len(parts) >= 3:
            return parts[2]
    except Exception:
        pass
    return "unknown"


def _handle_error(resp: httpx.Response) -> None:
    """Raise LLM-parseable errors for non-2xx responses."""
    if resp.status_code in (401, 403):
        raise XfinlinkError(
            "xfinlink: API key invalid or missing. "
            "Fix: call xfl.set_api_key('your_key') at the top of your script. "
            "Get a free key at https://xfinlink.com/signup"
        )
    if resp.status_code == 429:
        try:
            body = resp.json()
        except Exception:
            raise XfinlinkError(
                "xfinlink: Rate limit reached. "
                "Fix: wait a few minutes, or reduce request volume "
                "with date filters."
            )
        retry = body.get("retry_after_seconds", "?")
        error_msg = body.get("error", "")
        raise XfinlinkError(
            f"xfinlink: Rate limit reached ({error_msg}). "
            f"Fix: wait {retry}s, or reduce requests by adding "
            "start/end date filters and using max_rows parameter."
        )
    if resp.status_code == 404:
        ticker = _extract_ticker(resp)
        raise XfinlinkError(
            f"xfinlink: Ticker '{ticker}' not found. "
            f"Fix: check spelling, or use xfl.search(q='{ticker}') "
            "to find the correct symbol."
        )
    if 400 <= resp.status_code < 500:
        try:
            body = resp.json()
            detail = body.get("error", body.get("detail", "unknown"))
        except Exception:
            detail = resp.text
        raise XfinlinkError(
            f"xfinlink: API error ({resp.status_code}): {detail}. "
            "Fix: check your parameters and try again."
        )
    if resp.status_code >= 500:
        raise XfinlinkError(
            f"xfinlink: Server error ({resp.status_code}). This is temporary. "
            "Fix: try again in a few seconds. If persistent, "
            "contact hello@xfinlink.com"
        )


def _request(endpoint: str, params: dict, max_rows: int | None = None) -> dict:
    """GET with automatic cursor-based pagination."""
    from xfinlink import __version__

    headers: dict[str, str] = {"User-Agent": f"xfinlink-python/{__version__}"}
    key = _get_api_key()
    if key:
        headers["X-API-Key"] = key
    all_data: list = []
    meta: dict = {}
    pages = 0

    while True:
        try:
            resp = httpx.get(
                f"{API_BASE}/v1/{endpoint}",
                params=params,
                headers=headers,
                timeout=_TIMEOUT,
            )
        except httpx.TimeoutException:
            raise XfinlinkError(
                "xfinlink: Request timed out after 30s. "
                "Fix: narrow your query with start/end dates or fewer tickers."
            )
        except httpx.ConnectError:
            raise XfinlinkError(
                "xfinlink: Cannot connect to api.xfinlink.com. "
                "Fix: check your internet connection."
            )
        _handle_error(resp)

        body = resp.json()
        all_data.extend(body["data"])
        meta = body.get("meta", {})
        pages += 1

        if max_rows is not None and len(all_data) >= max_rows:
            all_data = all_data[:max_rows]
            break

        if not meta.get("has_more") or not meta.get("next_cursor"):
            break

        if pages >= _MAX_PAGES:
            warnings.warn(
                f"xfinlink: Results truncated at {_MAX_PAGES} pages ({len(all_data)} rows). "
                "Fix: narrow your query with start/end dates or fewer tickers.",
                UserWarning,
                stacklevel=3,
            )
            break

        params = dict(params)
        params["cursor"] = meta["next_cursor"]

    meta["count"] = len(all_data)
    meta["has_more"] = False
    meta["next_cursor"] = None
    return {"data": all_data, "meta": meta}


def _request_single(endpoint: str, params: dict) -> dict:
    """GET without pagination (for endpoints that don't paginate)."""
    from xfinlink import __version__

    headers: dict[str, str] = {"User-Agent": f"xfinlink-python/{__version__}"}
    key = _get_api_key()
    if key:
        headers["X-API-Key"] = key
    try:
        resp = httpx.get(
            f"{API_BASE}/v1/{endpoint}",
            params=params,
            headers=headers,
            timeout=_TIMEOUT,
        )
    except httpx.TimeoutException:
        raise XfinlinkError(
            "xfinlink: Request timed out after 30s. "
            "Fix: narrow your query with start/end dates or fewer tickers."
        )
    except httpx.ConnectError:
        raise XfinlinkError(
            "xfinlink: Cannot connect to api.xfinlink.com. "
            "Fix: check your internet connection."
        )
    _handle_error(resp)
    return resp.json()


# ── Public API ────────────────────────────────────────────────────────


def status() -> dict:
    """Check API health. Returns dict with status, version, and table counts."""
    from xfinlink import __version__

    try:
        resp = httpx.get(
            f"{API_BASE}/v1/status",
            headers={"User-Agent": f"xfinlink-python/{__version__}"},
            timeout=_TIMEOUT,
        )
    except httpx.TimeoutException:
        raise XfinlinkError(
            "xfinlink: Request timed out after 30s. "
            "Fix: try again in a few seconds."
        )
    except httpx.ConnectError:
        raise XfinlinkError(
            "xfinlink: Cannot connect to api.xfinlink.com. "
            "Fix: check your internet connection."
        )
    if resp.status_code >= 400:
        raise XfinlinkError(
            f"xfinlink: Server error ({resp.status_code}). This is temporary. "
            "Fix: try again in a few seconds. If persistent, "
            "contact hello@xfinlink.com"
        )
    return resp.json()


def usage() -> dict:
    """Check current API usage and rate limits."""
    from xfinlink import __version__

    key = _get_api_key()
    if not key:
        raise XfinlinkError(
            "xfinlink: No API key set. "
            "Fix: call xfl.set_api_key('your_key') at the top of your script. "
            "Get a free key at https://xfinlink.com/signup"
        )
    try:
        resp = httpx.get(
            f"{API_BASE}/v1/auth/usage",
            headers={
                "User-Agent": f"xfinlink-python/{__version__}",
                "X-API-Key": key,
            },
            timeout=_TIMEOUT,
        )
    except httpx.TimeoutException:
        raise XfinlinkError(
            "xfinlink: Request timed out after 30s. "
            "Fix: try again in a few seconds."
        )
    except httpx.ConnectError:
        raise XfinlinkError(
            "xfinlink: Cannot connect to api.xfinlink.com. "
            "Fix: check your internet connection."
        )
    if resp.status_code in (401, 403):
        raise XfinlinkError(
            "xfinlink: API key invalid or missing. "
            "Fix: call xfl.set_api_key('your_key') at the top of your script. "
            "Get a free key at https://xfinlink.com/signup"
        )
    if resp.status_code != 200:
        raise XfinlinkError(
            f"xfinlink: Server error ({resp.status_code}). This is temporary. "
            "Fix: try again in a few seconds. If persistent, "
            "contact hello@xfinlink.com"
        )
    return resp.json()


def prices(
    ticker: str | list[str] | tuple,
    start: str | date | None = None,
    end: str | date | None = None,
    period: str | None = None,
    fields: list[str] | str | None = None,
    adjust: str = "split",
    limit: int = 5000,
    max_rows: int = 50000,
) -> pd.DataFrame:
    """Get historical price data.

    Args:
        ticker: Ticker symbol(s). Accepts "AAPL", ["AAPL", "MSFT"],
                ("AAPL",), "AAPL,MSFT", or "AAPL MSFT". Max 50.
        start: Start date. String "YYYY-MM-DD", date, or datetime.
               Defaults to 1 year ago.
        end: End date. String "YYYY-MM-DD", date, or datetime.
        period: Shorthand for start date: "1w", "1mo", "3mo", "6mo",
                "1y", "2y", "3y", "5y", "10y", "ytd", "max".
                Cannot be used with start/end.
        fields: Fields to return. String or list of strings (default: all).
        adjust: "split" (default) or "none".
        limit: Rows per API page (default/max: 5000).
        max_rows: Maximum total rows to return (default: 50000).

    Returns:
        DataFrame with date, open, high, low, close, volume, etc.

    Examples:
        >>> df = xfl.prices("AAPL", start="2024-01-01", end="2024-12-31")
        >>> df = xfl.prices(["AAPL", "MSFT"], start="2024-01-01")
        >>> df = xfl.prices("AAPL MSFT GOOG", period="1y")
        >>> df = xfl.prices("AAPL", start=date(2025, 1, 1))
    """
    ticker_str = _validate_ticker(ticker, "prices")
    start, end = _resolve_period(period, start, end)
    start, end = _validate_dates(start, end)
    if isinstance(fields, str):
        fields = [fields]
    adjust = adjust.lower()
    if adjust not in ("split", "none"):
        raise XfinlinkError(
            f"xfinlink: adjust='{adjust}' not valid. "
            "Fix: use 'split' or 'none'"
        )
    if start is None:
        start = _default_start()
    params: dict = {"limit": limit, "adjust": adjust, "start": start}
    if end:
        params["end"] = end
    if fields:
        params["fields"] = ",".join(fields)

    result = _request(f"prices/{ticker_str}", params, max_rows=max_rows)

    if not result["data"]:
        _warn_empty(ticker_str, start, end)
        return pd.DataFrame()

    df = pd.DataFrame(result["data"])
    df = df.loc[:, ~df.columns.duplicated()]
    if "date" in df.columns:
        df["date"] = pd.to_datetime(df["date"])
    df = df.sort_values(["ticker", "date"]).reset_index(drop=True)
    return df


def fundamentals(
    ticker: str | list[str] | tuple,
    start: str | date | None = None,
    end: str | date | None = None,
    period: str | None = None,
    period_type: str = "all",
    version: str = "restated",
    fields: list[str] | str | None = None,
    period_only: bool = False,
    limit: int = 5000,
    max_rows: int = 10000,
) -> pd.DataFrame:
    """Get financial statement data.

    Args:
        ticker: Ticker symbol(s). Accepts "AAPL", ["AAPL", "MSFT"],
                ("AAPL",), "AAPL,MSFT", or "AAPL MSFT".
        start: Start date for period_end. String "YYYY-MM-DD", date, or datetime.
               Defaults to 1 year ago.
        end: End date for period_end. String "YYYY-MM-DD", date, or datetime.
        period: Shorthand for start date: "1y", "5y", "10y", "max", etc.
                Cannot be used with start/end.
        period_type: "quarterly", "annual", or "all" (default).
        version: "restated" (default), "original", or "all".
        fields: Specific fields. String or list, e.g. ["revenue", "net_income"].
        period_only: De-cumulate YTD cash flows to single-quarter values.
        limit: Rows per API page (default/max: 5000).
        max_rows: Maximum total rows to return (default: 10000).

    Returns:
        DataFrame with period_end, revenue, net_income, total_assets, etc.

    Examples:
        >>> df = xfl.fundamentals("AAPL", period_type="annual")
        >>> df = xfl.fundamentals("AAPL", fields=["revenue", "net_income"])
        >>> df = xfl.fundamentals(["AAPL", "MSFT"], period_type="annual", period="5y")
    """
    ticker_str = _validate_ticker(ticker, "fundamentals")
    start, end = _resolve_period(period, start, end)
    start, end = _validate_dates(start, end)
    period_type = period_type.lower()
    valid_periods = ("annual", "quarterly", "all")
    if period_type not in valid_periods:
        raise XfinlinkError(
            f"xfinlink: period_type='{period_type}' is not valid. "
            f"Fix: use one of {valid_periods}"
        )
    if isinstance(fields, str):
        fields = [fields]
    # When period_only is used without an explicit start, widen the lookback
    # by 6 months so the prior quarter is always available for de-cumulation.
    if period_only and start is None and period is None:
        start = (date.today() - timedelta(days=365 + 182)).isoformat()
    elif start is None:
        start = _default_start()
    params: dict = {"limit": limit, "period_type": period_type, "version": version, "start": start}
    if end:
        params["end"] = end
    if fields:
        params["fields"] = ",".join(fields)
    if period_only:
        params["period_only"] = "true"

    result = _request(f"fundamentals/{ticker_str}", params, max_rows=max_rows)

    if not result["data"]:
        _warn_empty(ticker_str, start, end)
        return pd.DataFrame()

    df = pd.DataFrame(result["data"])
    df = df.loc[:, ~df.columns.duplicated()]
    if "period_end" in df.columns:
        df["period_end"] = pd.to_datetime(df["period_end"])
    if "filing_date" in df.columns:
        df["filing_date"] = pd.to_datetime(df["filing_date"])
    df = df.sort_values(["ticker", "period_end"]).reset_index(drop=True)
    return df


def resolve(
    ticker: str | list[str] | tuple,
    include: list[str] | None = None,
) -> dict:
    """Get entity resolution and history for a ticker.

    Args:
        ticker: Ticker symbol(s). Accepts "GM", ["GM", "AAPL"],
                ("GM",), "GM,AAPL", or "GM AAPL".
        include: Sections to include: ["events", "index", "classifications"].
                 Default: all sections.

    Returns:
        Dict with entity history, corporate events, index membership,
        and classifications grouped by ticker.

    Examples:
        >>> info = xfl.resolve("GM")
        >>> info["data"]["GM"]["entities"]
        >>> info = xfl.resolve("AAPL", include=["classifications"])
    """
    ticker_str = _validate_ticker(ticker, "resolve")
    params: dict = {}
    if include:
        params["include"] = ",".join(include)
    result = _request_single(f"resolve/{ticker_str}", params)
    if "," not in ticker_str:
        data = result.get("data", {})
        if ticker_str in data and not data[ticker_str].get("entities"):
            warnings.warn(
                f"xfinlink: Ticker '{ticker_str}' exists but has no entity data. "
                f"Fix: try xfl.search(q='{ticker_str}') to find related tickers.",
                UserWarning,
                stacklevel=2,
            )
    return result


def search(
    q: str | None = None,
    gics_sector: str | None = None,
    entity_type: str | None = None,
    sic: str | None = None,
    naics: str | None = None,
    country: str = "US",
    limit: int = 50,
    offset: int = 0,
) -> pd.DataFrame:
    """Search for entities by name, sector, type, etc.

    Args:
        q: Fuzzy search on company name or ticker (e.g. "apple", "energy").
        gics_sector: Filter by GICS sector (e.g. "Information Technology").
        entity_type: Filter by type (e.g. "corporation", "etf").
        sic: Filter by SIC code.
        naics: Filter by NAICS code.
        country: Filter by country (default: "US").
        limit: Maximum results (default: 50, max: 500).
        offset: Skip first N results for pagination.

    Returns:
        DataFrame with entity_id, name, ticker, gics_sector, sic_code,
        naics_code, entity_type, and country.

    Examples:
        >>> df = xfl.search(q="apple")
        >>> df = xfl.search(gics_sector="Energy", limit=100)
        >>> df = xfl.search(entity_type="etf")
    """
    params: dict = {}
    if q:
        params["q"] = q
    if gics_sector:
        params["gics_sector"] = gics_sector
    if entity_type:
        params["entity_type"] = entity_type
    if sic:
        params["sic"] = sic
    if naics:
        params["naics"] = naics
    if country:
        params["country"] = country
    params["limit"] = limit
    params["offset"] = offset
    result = _request("search", params)
    return pd.DataFrame(result["data"])


def index(
    index_name: str = "sp500",
    as_of: str | date | None = None,
    limit: int = 500,
    offset: int = 0,
) -> pd.DataFrame:
    """Get index constituents (current or historical).

    Args:
        index_name: Index name. Currently only "sp500" supported.
        as_of: Historical date for point-in-time membership. String
               "YYYY-MM-DD", date, or datetime. Defaults to current.
        limit: Maximum results (default: 500).
        offset: Skip first N results for pagination.

    Returns:
        DataFrame with entity_id, ticker, company_name, date_added,
        and date_removed.

    Examples:
        >>> df = xfl.index("sp500")
        >>> df = xfl.index("sp500", as_of="2020-01-01")
        >>> df = xfl.index("sp500", as_of=date(2020, 1, 1))
    """
    if as_of is not None and hasattr(as_of, "isoformat"):
        as_of = as_of.isoformat()[:10]
    params: dict = {"limit": limit, "offset": offset}
    if as_of:
        params["as_of"] = as_of
    result = _request(f"index/{index_name}", params)
    return pd.DataFrame(result["data"])


def metrics(
    ticker: str | list[str] | tuple,
    period_type: str = "annual",
    fields: list[str] | str | None = None,
    start: str | date | None = None,
    end: str | date | None = None,
    period: str | None = None,
    limit: int = 20,
    max_rows: int = 10000,
) -> pd.DataFrame:
    """Get computed financial metrics (P/E, ROE, margins, per-share, etc.).

    Args:
        ticker: Ticker symbol(s). Accepts "AAPL", ["AAPL", "MSFT"],
                ("AAPL",), "AAPL,MSFT", or "AAPL MSFT".
        period_type: "annual" (default), "quarterly", or "all".
        fields: Specific metrics. String or list, e.g. ["pe_ratio", "roe"].
        start: Start date. String "YYYY-MM-DD", date, or datetime.
               Defaults to 1 year ago.
        end: End date. String "YYYY-MM-DD", date, or datetime.
        period: Shorthand for start date: "1y", "5y", "10y", "max", etc.
                Cannot be used with start/end.
        limit: Rows per API page (default: 20).
        max_rows: Maximum total rows to return (default: 10000).

    Returns:
        DataFrame with period_end, ticker, and requested metrics.

    Examples:
        >>> df = xfl.metrics("AAPL", period_type="annual")
        >>> df = xfl.metrics("AAPL", fields=["pe_ratio", "roe", "market_cap"])
        >>> df = xfl.metrics(["AAPL", "MSFT"], period="5y")
    """
    ticker_str = _validate_ticker(ticker, "metrics")
    start, end = _resolve_period(period, start, end)
    start, end = _validate_dates(start, end)
    period_type = period_type.lower()
    valid_periods = ("annual", "quarterly", "all")
    if period_type not in valid_periods:
        raise XfinlinkError(
            f"xfinlink: period_type='{period_type}' is not valid. "
            f"Fix: use one of {valid_periods}"
        )
    if isinstance(fields, str):
        fields = [fields]
    if start is None:
        start = _default_start()
    params: dict = {"period_type": period_type, "limit": limit, "start": start}
    if fields:
        params["fields"] = ",".join(fields)
    if end:
        params["end"] = end
    result = _request(f"metrics/{ticker_str}", params, max_rows=max_rows)

    if not result["data"]:
        _warn_empty(ticker_str, start, end)
        return pd.DataFrame()

    df = pd.DataFrame(result["data"])
    df = df.loc[:, ~df.columns.duplicated()]
    if "period_end" in df.columns:
        df["period_end"] = pd.to_datetime(df["period_end"])
    if "ticker" in df.columns and "period_end" in df.columns:
        df = df.sort_values(["ticker", "period_end"]).reset_index(drop=True)
    return df


def llm_context() -> str:
    """Print and return the xfinlink LLM context block."""
    try:
        resp = httpx.get(f"{API_BASE}/llms.txt", timeout=10)
    except httpx.TimeoutException:
        raise XfinlinkError(
            "xfinlink: Request timed out after 10s. "
            "Fix: try again in a few seconds."
        )
    except httpx.ConnectError:
        raise XfinlinkError(
            "xfinlink: Cannot connect to api.xfinlink.com. "
            "Fix: check your internet connection."
        )
    if resp.status_code >= 400:
        raise XfinlinkError(
            f"xfinlink: Server error ({resp.status_code}). This is temporary. "
            "Fix: try again in a few seconds. If persistent, "
            "contact hello@xfinlink.com"
        )
    text = resp.text
    print(text)
    try:
        import pyperclip
        pyperclip.copy(text)
    except ImportError:
        pass
    return text
