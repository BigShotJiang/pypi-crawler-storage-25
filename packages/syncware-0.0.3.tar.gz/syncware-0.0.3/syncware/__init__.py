#!/usr/bin/env python3
"""
syncware CLI

A CLI tool for syncing selective folders from local Git repositories to a target directory.

Usage:
    syncware list
    syncware sync [--dry]
    syncware update
    syncware lockfile
    syncware verify [--fix]
"""

import argparse

from syncware.commands import (
    cmd_init,
    cmd_list,
    cmd_lockfile,
    cmd_verify,
)
from syncware.config import ConfigError, load_config
from syncware.core import dir_hash, get_all_folders, has_changed, resolve_folders
from syncware.git import get_git_commit, is_remote_url, resolve_repo_path
from syncware.lockfile import get_lockfile_path
from syncware.logging_ import setup_logging
from syncware.sync import cmd_sync, cmd_update

__all__ = [
    "cmd_init",
    "cmd_list",
    "cmd_lockfile",
    "cmd_sync",
    "cmd_update",
    "cmd_verify",
    "ConfigError",
    "dir_hash",
    "get_all_folders",
    "get_git_commit",
    "get_lockfile_path",
    "has_changed",
    "is_remote_url",
    "resolve_folders",
    "resolve_repo_path",
]


def main():
    parser = argparse.ArgumentParser(
        description="Folder Sync CLI - Sync selective folders from local Git repositories"
    )
    parser.add_argument(
        "-c",
        "--config",
        default="syncware.yaml",
        help="Path to config file (default: syncware.yaml)",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="count",
        default=0,
        help="Verbose output (-v info, -vv debug)",
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    list_parser = subparsers.add_parser("list", help="List all configured folders")

    sync_parser = subparsers.add_parser("sync", help="Sync folders to target directory")
    sync_parser.add_argument(
        "--dry",
        action="store_true",
        help="Show what would happen without modifying filesystem",
    )

    update_parser = subparsers.add_parser(
        "update", help="Update repos and sync folders"
    )
    update_parser.add_argument(
        "--dry",
        action="store_true",
        help="Show what would happen without modifying filesystem",
    )

    lockfile_parser = subparsers.add_parser(
        "lockfile", help="Generate or update lockfile"
    )
    lockfile_parser.add_argument(
        "--force",
        action="store_true",
        help="Force regenerate lockfile",
    )

    verify_parser = subparsers.add_parser(
        "verify", help="Verify folders against lockfile"
    )
    verify_parser.add_argument(
        "--fix",
        action="store_true",
        help="Auto-fix drift by re-syncing",
    )

    init_parser = subparsers.add_parser(
        "init", help="Initialize a new syncware project"
    )
    init_parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite existing config",
    )

    args = parser.parse_args()

    setup_logging(args.verbose)

    if args.command == "init":
        cmd_init(args)
    else:
        try:
            config = load_config(args.config)
        except ConfigError as e:
            print(f"Error: {e}", file=__import__("sys").stderr)
            __import__("sys").exit(1)

        if args.command == "list":
            cmd_list(config, verbose=args.verbose)
        elif args.command == "sync":
            cmd_sync(config, dry=args.dry, verbose=args.verbose)
        elif args.command == "update":
            cmd_update(config, dry=args.dry, verbose=args.verbose)
        elif args.command == "lockfile":
            cmd_lockfile(config, config_path=args.config, verbose=args.verbose)
        elif args.command == "verify":
            cmd_verify(
                config, config_path=args.config, fix=args.fix, verbose=args.verbose
            )


if __name__ == "__main__":
    main()
