#!/usr/bin/env python3
"""CLI commands for syncware."""

import datetime
import sys
from pathlib import Path

from syncware.core import dir_hash, get_all_folders, has_changed, resolve_folders
from syncware.git import get_git_commit, resolve_repo_path
from syncware.lockfile import load_lockfile, save_lockfile
from syncware.logging_ import c, print_msg
from syncware.sync import cmd_sync


def cmd_list(config, verbose=False):
    """List all configured folders."""
    print_msg("Configured folders:", "info")
    print()

    global_target = config.get("target", "./output")

    for repo in config.get("repos", []):
        repo_path = resolve_repo_path(repo)
        source = repo.get("source", repo.get("entry", ""))
        repo_target = repo.get("target", global_target)
        repo_name = repo.get("name", "unknown")

        print(f"{c(repo_name, 'bold')} -> {repo_target}")

        if not repo_path.exists():
            print_msg(f"  Repo not found: {repo_path}", "warning")
            continue

        for folder in resolve_folders(repo):
            folder_path = repo_path / source / folder
            folder_src = folder_path.resolve()
            print(f"  {c(folder, 'green')} -> {folder_src}")


def cmd_lockfile(config, config_path="syncware.yaml", verbose=False):
    """Generate or update lockfile."""
    lock_data = {
        "lockfileVersion": 1,
        "generatedAt": datetime.datetime.now(datetime.timezone.utc)
        .isoformat()
        .replace("+00:00", "Z"),
        "target": config.get("target", "./output"),
        "repos": {},
    }

    for repo in config.get("repos", []):
        repo_path = resolve_repo_path(repo)
        source = repo.get("source", repo.get("entry", ""))
        repo_name = repo["name"]

        if not repo_path.exists():
            print_msg(f"Repo not found: {repo_path}", "warning")
            continue

        git_commit = get_git_commit(repo_path)
        lock_data["repos"][repo_name] = {
            "repoCommit": git_commit,
            "repoPath": str(repo_path.resolve()),
            "folders": {},
        }

        for folder in resolve_folders(repo):
            folder_path = repo_path / source / folder
            if not folder_path.exists():
                print_msg(f"Folder not found: {folder_path}", "warning")
                continue

            content_hash = dir_hash(folder_path)
            lock_data["repos"][repo_name]["folders"][folder] = {
                "sourcePath": f"{source}/{folder}",
                "contentHash": content_hash,
            }

    save_lockfile(lock_data, config_path)


def cmd_verify(config, config_path="syncware.yaml", fix=False, verbose=False):
    """Verify folders against lockfile."""
    lock_data = load_lockfile(config_path)

    if not lock_data:
        print_msg("No lockfile found. Run 'syncware lockfile' first.", "error")
        return

    print_msg("Verifying folders against lockfile...", "info")
    print()

    drift_count = 0
    update_available = 0
    missing_count = 0

    for repo_name, repo_data in lock_data.get("repos", {}).items():
        repo_path = Path(repo_data["repoPath"])
        current_commit = get_git_commit(repo_path)
        locked_commit = repo_data.get("repoCommit")

        if not repo_path.exists():
            print_msg(f"Repo missing: {repo_name} ({repo_path})", "error")
            missing_count += 1
            continue

        if current_commit != locked_commit:
            print_msg(
                f"[{repo_name}] update available: {locked_commit[:8]} -> {current_commit[:8]}",
                "warning",
            )
            update_available += 1

        for folder_name, folder_data in repo_data.get("folders", {}).items():
            folder_rel_path = folder_data.get("sourcePath", "")
            folder_path = repo_path / folder_rel_path

            if not folder_path.exists():
                print_msg(f"[{repo_name}/{folder_name}] missing in source", "error")
                missing_count += 1
                drift_count += 1
                continue

            current_hash = dir_hash(folder_path)
            locked_hash = folder_data.get("contentHash")

            if current_hash != locked_hash:
                print_msg(
                    f"[{repo_name}/{folder_name}] content drift detected", "warning"
                )
                drift_count += 1
            else:
                if verbose:
                    print_msg(f"[{repo_name}/{folder_name}] OK", "success")

    print()
    if drift_count == 0 and update_available == 0 and missing_count == 0:
        print_msg("All folders verified - no drift detected", "success")
    else:
        if drift_count > 0:
            print_msg(f"Drift detected: {drift_count} folder(s)", "warning")
        if update_available > 0:
            print_msg(f"Updates available: {update_available} repo(s)", "warning")
        if missing_count > 0:
            print_msg(f"Missing: {missing_count} folder(s)", "error")

        if fix:
            print()
            print_msg("Auto-fix enabled - re-syncing drifted folders...", "info")
            cmd_sync(config, dry=False, verbose=verbose)
            cmd_lockfile(config, config_path=config_path, verbose=verbose)


def cmd_init(args):
    """Initialize a new syncware project."""
    config_path = Path(args.config)
    if config_path.exists() and not args.force:
        print_msg(
            f"Config already exists: {config_path}. Use --force to overwrite.", "error"
        )
        sys.exit(1)

    config_content = """# syncware configuration
# https://github.com/example/syncware

repos:
  - name: example
    path: /path/to/local/repo
    source: path/to/folders
    folders:
      - folder1
      - folder2
      - "*"  # or sync all subfolders
    # target: ./custom-output  # optional, overrides global target

# Global target (default for repos without own target)
target: ./output
"""

    with open(config_path, "w") as f:
        f.write(config_content)

    print_msg(f"Created config: {config_path}", "success")
    print_msg("Edit the config to add your repositories and folders.", "info")
