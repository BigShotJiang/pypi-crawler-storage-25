#!/usr/bin/env python3
"""Sync operations for folder synchronization."""

import os
import shutil
import subprocess
from pathlib import Path

from syncware.core import dir_hash, has_changed, resolve_folders
from syncware.git import resolve_repo_path
from syncware.logging_ import print_msg


def sync_repo(repo, config, global_target, dry=False):
    """Sync a single repo's folders to its target."""
    repo_path = resolve_repo_path(repo)
    source = repo.get("source", repo.get("entry", ""))
    repo_target_str = repo.get("target", global_target)
    repo_target = Path(os.path.expanduser(repo_target_str))
    repo_name = repo.get("name", "unknown")

    if not repo_path.exists():
        print_msg(f"Repo not found: {repo_path}", "warning")
        return 0

    if not dry:
        repo_target.mkdir(parents=True, exist_ok=True)

    configured = []

    for folder in resolve_folders(repo):
        folder_path = repo_path / source / folder

        if not folder_path.exists():
            print_msg(f"Folder not found: {folder_path}", "warning")
            continue

        dest = repo_target / folder
        dest_display = f"{repo_target_str}/{folder}"
        configured.append((dest, folder_path))

        # Determine if sync is needed and cache the result
        if not dest.exists():
            needs_sync = True
            status = "create"
        else:
            changed = has_changed(folder_path, dest)
            needs_sync = changed
            status = "update" if changed else "unchanged"

        print_msg(f"{status}: {dest_display}", "success" if status == "create" else "warning" if status == "update" else "info")

        if not dry and needs_sync:
            shutil.copytree(folder_path, dest, dirs_exist_ok=True)

    existing_dirs = []
    if repo_target.exists():
        for item in repo_target.iterdir():
            if item.is_dir():
                existing_dirs.append(item)

    for existing in existing_dirs:
        is_configured = any(dest.name == existing.name for dest, _ in configured)
        if not is_configured:
            print_msg(f"remove {repo_target_str}/{existing.name}", "warning")
            if not dry:
                shutil.rmtree(existing)

    return len(configured)


def cmd_sync(config, dry=False, verbose=False):
    """Sync all configured repos to their targets."""
    global_target = config.get("target", "./output")

    total = 0
    for repo in config.get("repos", []):
        repo_name = repo.get("name", "unknown")
        repo_target = repo.get("target", global_target)
        print_msg(f"Syncing {repo_name} -> {repo_target}...", "info")
        total += sync_repo(repo, config, global_target, dry=dry)

    if dry:
        print_msg("Dry run complete - no changes made", "info")
    else:
        print_msg(f"Synced {total} folder(s)", "success")


def cmd_update(config, dry=False, verbose=False):
    """Update repos via git pull and sync."""
    for repo in config.get("repos", []):
        repo_path = resolve_repo_path(repo)
        repo_name = repo["name"]

        if not repo_path.exists():
            print_msg(f"Repo not found: {repo_path}", "warning")
            continue

        print_msg(f"Updating {repo_name}...", "info")

        try:
            result = subprocess.run(
                ["git", "pull", "--ff-only"],
                cwd=repo_path,
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                print_msg(f"Updated {repo_name}", "success")
                if verbose:
                    print(result.stdout.strip())
            else:
                print_msg(
                    f"Git pull failed for {repo_name}: {result.stderr.strip()}", "error"
                )
        except Exception as e:
            print_msg(f"Error updating {repo_name}: {e}", "error")

    print()
    cmd_sync(config, dry=dry, verbose=verbose)
