#!/usr/bin/env python3
"""Lockfile operations for reproducible syncs."""

from pathlib import Path

import yaml

from syncware.logging_ import print_msg


def get_lockfile_path(config_path="syncware.yaml"):
    """Derive lockfile path from config path: syncware.yaml -> syncware.lock.yaml"""
    p = Path(config_path)
    stem = p.stem
    suffix = p.suffix
    return p.parent / f"{stem}.lock{suffix}"


def load_lockfile(config_path="syncware.yaml"):
    """Load existing lockfile if present."""
    lock_path = get_lockfile_path(config_path)
    if lock_path.exists():
        with open(lock_path) as f:
            return yaml.safe_load(f)
    return None


def save_lockfile(lock_data, config_path="syncware.yaml"):
    """Save lockfile to disk."""
    lock_path = get_lockfile_path(config_path)
    with open(lock_path, "w") as f:
        yaml.dump(lock_data, f, default_flow_style=False, sort_keys=False)
    print_msg(f"Lockfile saved: {lock_path}", "success")
