# syncware

A CLI tool for syncing selective folders from local Git repositories to a target directory. Think `go mod vendor` or `npm install`, but for folder-based content.

## Installation

```bash
pip install syncware
```

## Quick Start

```bash
# Initialize a new project
syncware init

# Edit syncware.yaml with your repositories

# List configured folders
syncware list

# Sync folders to target
syncware sync

# Preview sync (dry run)
syncware sync --dry

# Update repos and sync
syncware update

# Generate lockfile (captures exact versions)
syncware lockfile

# Verify folders against lockfile
syncware verify

# Auto-fix drift
syncware verify --fix
```

## Verbosity

```bash
syncware -v list      # INFO level (default)
syncware -vv list     # DEBUG level
```

## Configuration

Create a `syncware.yaml` file in your project root:

```yaml
repos:
  - name: myrepo
    path: /path/to/local/repo
    source: path/to/folders
    folders:
      - folder1
      - folder2
      - "*"  # or all subdirectories
    target: ./output  # optional, overrides global target

target: ./output  # global target (default)
```

### Per-Repo Target

Each repo can have its own target:

```yaml
repos:
  - name: frontend
    path: ./packages/frontend
    source: dist
    folders: ["ui", "icons"]
    target: ./public/assets

  - name: backend
    path: ./packages/backend
    source: configs
    folders: ["nginx", "docker"]
    target: ./deploy/config

target: ./common/output  # used by repos without own target
```

### Remote Repositories

You can also use remote Git URLs (GitHub, GitLab, etc.):

```yaml
repos:
  - name: claude
    path: https://github.com/user/repo.git
    source: skills
    folders: ["docx", "xlsx"]
```

Remote repos are cloned to `~/.cache/syncware/<name>` and reused on subsequent runs.

### Config Fields

| Field | Description |
|-------|-------------|
| `repos` | List of source repositories |
| `repos[].name` | Namespace identifier |
| `repos[].path` | Local path or Git URL |
| `repos[].source` | Subdirectory containing folders to sync |
| `repos[].folders` | List of folder names, or `"*"` for all |
| `repos[].target` | Per-repo destination (overrides global) |
| `target` | Global destination directory |

## How It Works

```
<repo.path>/<source>/<folder> → copied to <repo.target>/<folder>
                                  or <global.target>/<folder>
```

## Lockfile

The lockfile (`syncware.lock.yaml`) ensures reproducible syncs:

```bash
syncware lockfile          # Generate lockfile
syncware verify           # Check for drift
syncware verify --fix     # Auto-fix drift
```

**What gets locked:**
- Git commit hash of each source repository
- Content hash (SHA256) of each synced folder

**Verification detects:**
- `DRIFT` - Folder content was modified locally
- `UPDATE_AVAILABLE` - Source repo has new commits
- `MISSING` - Source folder was deleted

## Use Cases

- **Skills/Plugins** - Sync skill folders from a central repo
- **Config Management** - Keep config folders in sync across machines
- **Documentation** - Maintain a set of doc folders from different sources
- **Assets** - Bundle asset folders from multiple repositories

## Comparison

| Tool | Use Case |
|------|----------|
| `syncware` | Selective folder sync from local or remote repos |
| `go mod vendor` | Vendor Go dependencies |
| `npm install` | Install package dependencies |
| `rsync` | General file/folder synchronization |
