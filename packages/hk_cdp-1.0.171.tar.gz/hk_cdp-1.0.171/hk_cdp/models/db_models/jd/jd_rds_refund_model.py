# -*- coding: utf-8 -*-
"""
@Author: HuangJianYi
@Date: 2026-03-10 00:00:00
@LastEditTime: 2026-03-10 00:00:00
@LastEditors: HuangJianYi
@Description: 京东售后退款表
"""
from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import *


class JdRdsRefundModel(CacheModel):
    def __init__(self, db_connect_key='db_cloudapp', db_config_dict=None, sub_table=None, db_transaction=None, context=None, is_auto=False, cache_sub_table=None):
        super(JdRdsRefundModel, self).__init__(JdRdsRefund, sub_table, cache_sub_table)
        if not db_config_dict:
            db_config_dict = config.get_value(db_connect_key)
        self.db = MySQLHelper(self.convert_db_config(db_config_dict, is_auto))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context

    # 方法扩展请继承此类


class JdRdsRefund:
    def __init__(self):
        super(JdRdsRefund, self).__init__()
        self.serviceId = 0  # 售后服务Id
        self.orderId = 0  # 订单Id
        self.state = ''  # 订单状态
        self.orderType = ''  # 订单类型
        self.buId = ''  # 商家Id
        self.pin = ''  # 买家PIN(后期此字段将废弃, 建议使用openId)
        self.xid = ''  # 买家XID
        self.created = '1970-01-01 00:00:00.000'  # 交易创建时间
        self.modified = '1970-01-01 00:00:00.000'  # 交易修改时间
        self.responseJson = {}  # 详情(JSON)
        self.hashcode = ''  # 用来做数据校验的字段
        self.version = ''  # 交易版本号
        self.pushCreated = '1970-01-01 00:00:00.000'  # 数据第一次推送的时间
        self.pushModified = '1970-01-01 00:00:00.000'  # 数据最新一次推送的时间

    @classmethod
    def get_field_list(self):
        return [
            'serviceId', 'orderId', 'state', 'orderType', 'buId', 'pin', 'xid', 'created', 'modified', 'responseJson',
            'hashcode', 'version', 'pushCreated', 'pushModified'
        ]

    @classmethod
    def get_primary_key(self):
        return "serviceId"

    def __str__(self):
        return "jd_rds_refund_tb"
