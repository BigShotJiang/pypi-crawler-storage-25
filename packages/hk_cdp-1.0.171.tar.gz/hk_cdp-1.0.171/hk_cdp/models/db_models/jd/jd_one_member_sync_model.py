# -*- coding: utf-8 -*-
"""
@Author: HuangJianYi
@Date: 2026-03-10 00:00:00
@LastEditTime: 2026-04-10 17:16:40
@LastEditors: HuangJianYi
@Description: 京东一方会员同步表
"""
from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import *


class JdOneMemberSyncModel(CacheModel):
    def __init__(self, db_connect_key='db_cloudapp', db_config_dict=None, sub_table=None, db_transaction=None, context=None, is_auto=False, cache_sub_table=None):
        super(JdOneMemberSyncModel, self).__init__(JdOneMemberSync, sub_table, cache_sub_table)
        if not db_config_dict:
            db_config_dict = config.get_value(db_connect_key)
        self.db = MySQLHelper(self.convert_db_config(db_config_dict, is_auto))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context

    # 方法扩展请继承此类


class JdOneMemberSync:
    def __init__(self):
        super(JdOneMemberSync, self).__init__()
        self.id = 0  # id
        self.business_id = 0  # 商家标识
        self.scheme_id = 0  # 会员体系标识
        self.member_telephone = ''  # 会员手机号
        self.jd_one_id = ''  # 京东one_id
        self.sync_status = 0  # 同步状态(0-未同步 1-已同步 2-同步中  3-不予同步)
        self.sync_count = 0  # 同步次数
        self.sync_result = ''  # 同步结果
        self.sync_date = '1970-01-01 00:00:00.000'  # 同步时间
        self.create_date = '1970-01-01 00:00:00.000'  # 创建时间
        self.modify_date = '1970-01-01 00:00:00.000'  # 修改时间

    @classmethod
    def get_field_list(self):
        return [
            'id', 'business_id', 'scheme_id', 'member_telephone', 'jd_one_id', 'sync_status', 'sync_count', 'sync_result',
            'sync_date', 'create_date', 'modify_date'
        ]

    @classmethod
    def get_primary_key(self):
        return "id"

    def __str__(self):
        return "jd_one_member_sync_tb"
