# -*- coding: utf-8 -*-
"""
@Author: HuangJianYi
@Date: 2026-03-10 00:00:00
@LastEditTime: 2026-03-10 00:00:00
@LastEditors: HuangJianYi
@Description: 京东交易订单表
"""
from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import *


class JdRdsTradeModel(CacheModel):
    def __init__(self, db_connect_key='db_cloudapp', db_config_dict=None, sub_table=None, db_transaction=None, context=None, is_auto=False, cache_sub_table=None):
        super(JdRdsTradeModel, self).__init__(JdRdsTrade, sub_table, cache_sub_table)
        if not db_config_dict:
            db_config_dict = config.get_value(db_connect_key)
        self.db = MySQLHelper(self.convert_db_config(db_config_dict, is_auto))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context

    # 方法扩展请继承此类


class JdRdsTrade:
    def __init__(self):
        super(JdRdsTrade, self).__init__()
        self.orderId = 0  # 订单id
        self.hashcode = ''  # 用来做数据校验的字段
        self.state = ''  # 订单状态
        self.orderType = ''  # 订单类型
        self.created = '1970-01-01 00:00:00.000'  # 交易创建时间
        self.modified = '1970-01-01 00:00:00.000'  # 交易修改时间
        self.venderId = 0  # 商家Id
        self.pin = ''  # 买家PIN(后期此字段将废弃, 建议使用openId)
        self.responseJson = {}  # 订单详情(JSON), 参看jingdong.pop.order.get
        self.pushCreated = '1970-01-01 00:00:00.000'  # 数据第一次推送的时间
        self.pushModified = '1970-01-01 00:00:00.000'  # 数据最新一次推送的时间
        self.version = ''  # 交易版本号
        self.openId = ''  # 买家openId
        self.xid = ''  # 买家XID
        self.num = 0  # 商品购买数量

    @classmethod
    def get_field_list(self):
        return [
            'orderId', 'hashcode', 'state', 'orderType', 'created', 'modified', 'venderId', 'pin', 'responseJson',
            'pushCreated', 'pushModified', 'version', 'openId', 'xid', 'num'
        ]

    @classmethod
    def get_primary_key(self):
        return "orderId"

    def __str__(self):
        return "jd_rds_trade_tb"
