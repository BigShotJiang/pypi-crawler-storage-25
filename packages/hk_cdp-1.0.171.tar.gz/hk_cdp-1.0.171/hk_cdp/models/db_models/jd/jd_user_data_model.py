# -*- coding: utf-8 -*-
"""
@Author: HuangJianYi
@Date: 2026-03-10 00:00:00
@LastEditTime: 2026-03-10 00:00:00
@LastEditors: HuangJianYi
@Description: 京东用户数据表
"""
from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import *


class JdUserDataModel(CacheModel):
    def __init__(self, db_connect_key='db_cloudapp', db_config_dict=None, sub_table=None, db_transaction=None, context=None, is_auto=False, cache_sub_table=None):
        super(JdUserDataModel, self).__init__(JdUserData, sub_table, cache_sub_table)
        if not db_config_dict:
            db_config_dict = config.get_value(db_connect_key)
        self.db = MySQLHelper(self.convert_db_config(db_config_dict, is_auto))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context

    # 方法扩展请继承此类


class JdUserData:
    def __init__(self):
        super(JdUserData, self).__init__()
        self.id = 0  # id
        self.business_id = 0  # 商家标识
        self.scheme_id = 0  # 会员体系标识
        self.xid = ''  # xid
        self.total_order_price = 0.0  # 累计订单金额
        self.total_order_count = 0  # 累计订单笔数
        self.settle_price = 0.0  # 结算金额
        self.sync_integral = 0  # 同步积分（与京东对齐，用于对比差值同步变动的积分）
        self.info_json = {}  # 扩展信息json
        self.is_pull = 0  # 是否拉取（0-否 1-是）
        self.pull_integral = 0  # 拉取积分
        self.pull_date = '1970-01-01 00:00:00.000'  # 拉取时间
        self.sync_date = '1970-01-01 00:00:00.000'  # 同步时间
        self.create_date = '1970-01-01 00:00:00.000'  # 创建时间
        self.modify_date = '1970-01-01 00:00:00.000'  # 修改时间

    @classmethod
    def get_field_list(self):
        return [
            'id', 'business_id', 'scheme_id', 'xid', 'total_order_price', 'total_order_count', 'settle_price',
            'sync_integral', 'info_json', 'is_pull', 'pull_integral', 'pull_date', 'sync_date',
            'create_date', 'modify_date'
        ]

    @classmethod
    def get_primary_key(self):
        return "id"

    def __str__(self):
        return "jd_user_data_tb"
