# -*- coding: utf-8 -*-
"""
@Author: HuangJianYi
@Date: 2024-10-15 18:30:21
@LastEditTime: 2026-03-09 00:00:00
@LastEditors: HuangJianYi
@Description: 
"""
from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import *


class MemberMergeLogModel(CacheModel):
    def __init__(self, db_connect_key='db_cloudapp', db_config_dict=None, sub_table=None, db_transaction=None, context=None, is_auto=False, cache_sub_table=None):
        super(MemberMergeLogModel, self).__init__(MemberMergeLog, sub_table, cache_sub_table)
        if not db_config_dict:
            db_config_dict = config.get_value(db_connect_key)
        self.db = MySQLHelper(self.convert_db_config(db_config_dict, is_auto))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context

    # 方法扩展请继承此类


class MemberMergeLog:
    def __init__(self):
        super(MemberMergeLog, self).__init__()
        self.id = 0  # id
        self.business_id = 0  # 商家标识
        self.source_one_id = ""  # 合并前one_id
        self.target_one_id = ""  # 合并后one_id
        self.merge_type = 0  # 合并类型(1-omid合并 2-手机号合并 3-京东全域合并)
        self.create_date = '1970-01-01 00:00:00.000'  # 创建时间

    @classmethod
    def get_field_list(self):
        return [
            'id', 'business_id', 'source_one_id', 'target_one_id', 'merge_type', 'create_date'
        ]

    @classmethod
    def get_primary_key(self):
        return "id"

    def __str__(self):
        return "member_merge_log_tb"
