import pathlib
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Protocol

from telegraph import Telegraph

if TYPE_CHECKING:
    from grabber.core.extractor.infrastructure.checkpoints import SourceCheckpointHint


@dataclass(slots=True)
class SourceRunRequest:
    sources: list[str]
    entity: str
    telegraph_client: Telegraph | None = None
    final_dest: str | pathlib.Path = ""
    save_to_telegraph: bool = False
    is_tag: bool = False
    limit: int | None = 0
    is_video_enabled: bool = False
    channel: str = ""
    max_pages: int = 50
    checkpoint_hint: "SourceCheckpointHint | None" = None
    save_local: bool = False

    def as_kwargs(self) -> dict[str, Any]:
        return {
            "sources": self.sources,
            "entity": self.entity,
            "telegraph_client": self.telegraph_client,
            "final_dest": self.final_dest,
            "save_to_telegraph": self.save_to_telegraph,
            "is_tag": self.is_tag,
            "limit": self.limit,
            "is_video_enabled": self.is_video_enabled,
            "channel": self.channel,
            "max_pages": self.max_pages,
            "checkpoint_hint": self.checkpoint_hint,
            "save_local": self.save_local,
        }


class SourceUseCase(Protocol):
    async def run(self, request: SourceRunRequest) -> None:
        raise NotImplementedError
