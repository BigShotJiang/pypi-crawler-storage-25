import unicodedata
from typing import cast

from bs4 import Tag


def remove_diacritics(text: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", text) if unicodedata.category(c) != "Mn")


def get_page_title(soup: Tag, strings_to_remove: list[str]) -> str:
    page_title = cast(Tag, soup.find("title")).get_text(strip=True).strip().rstrip()

    for string_to_remove in strings_to_remove:
        page_title = page_title.split(string_to_remove)[0]

    page_title = page_title.replace("https:", "")
    page_title = remove_diacritics(
        " ".join(
            f"#{part.strip().replace(' ', '').replace('.', '_').replace('-', '_')}"
            for part in list(set(page_title.split("/")))
        )
    )
    return page_title
