import pathlib
from pathlib import Path
from typing import Any

from grabber.core.extractor.infrastructure.parsing.title import remove_diacritics
from boltons.setutils import IndexedSet


def handle_final_destination(
    page_title: str,
    entity: str,
    ordered_unique_img_urls: IndexedSet,
    title_folder_mapping: dict[str, tuple[IndexedSet, Any]],
    final_dest: str | Path | None = None,
) -> tuple[pathlib.Path | None, dict[str, tuple[IndexedSet, Any]]]:
    folder_dest: pathlib.Path | None = None
    if final_dest:
        folder_dest = pathlib.Path(final_dest) / remove_diacritics(f"{page_title} - {entity}")
        folder_dest.mkdir(parents=True, exist_ok=True)
        title_folder_mapping[page_title] = (ordered_unique_img_urls, folder_dest)
    return folder_dest, title_folder_mapping
