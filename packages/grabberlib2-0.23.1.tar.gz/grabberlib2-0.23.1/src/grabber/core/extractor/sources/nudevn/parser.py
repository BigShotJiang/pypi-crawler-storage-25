import logging
import pathlib

import httpx
from boltons.setutils import IndexedSet
from bs4 import BeautifulSoup
from telegraph import Telegraph

from grabber.core.extractor.constants import headers_mapping
from grabber.core.extractor.infrastructure.parsing.title import remove_diacritics
from grabber.core.extractor.infrastructure.publishing.telegraph import send_post_to_telegram

logger = logging.getLogger(__name__)


def get_page_title(soup: BeautifulSoup) -> str:
    tag = soup.find("title")
    raw = tag.get_text(strip=True) if tag else "nudevn"
    return remove_diacritics(raw.split(" - ")[0].strip())


def extract_image_urls(soup: BeautifulSoup) -> IndexedSet:
    urls: IndexedSet = IndexedSet()
    article = soup.select_one("article.single")
    if not article:
        return urls
    for img in article.select("img[class*='wp-image-']:not([class*='wp-post-image'])"):
        src = str(img.attrs.get("src", "")).strip()
        if src.startswith("https://nudevn.com/") and not src.endswith("-150x150.jpg"):
            urls.add(src)
    return urls


async def get_sources_for_nudevn(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs,
) -> None:
    channel = kwargs.get("channel", "")
    headers = dict(headers_mapping.get(entity, {}))
    all_sources: list[str] = []
    posts_sent_counter = 0

    async with httpx.AsyncClient(headers=headers, follow_redirects=True, timeout=30) as client:
        for source_url in sources:
            try:
                response = await client.get(source_url)
                response.raise_for_status()
                soup = BeautifulSoup(response.text, "lxml")
            except Exception:
                logger.exception("Failed to fetch %s", source_url)
                continue

            image_urls = extract_image_urls(soup)
            if not image_urls:
                logger.warning("No images found on %s", source_url)
                continue

            page_title = get_page_title(soup)
            print(f"[nudevn] {len(image_urls)} images | title: {page_title}")

            if not save_to_telegraph:
                continue

            try:
                await send_post_to_telegram(
                    page_title=page_title,
                    ordered_unique_img_urls=image_urls,
                    posts_sent_counter=posts_sent_counter,
                    telegraph_client=telegraph_client,
                    tqdm_sources_iterable=None,
                    all_sources=all_sources,
                    source_url=source_url,
                    entity=entity,
                    channel=channel,
                )
                posts_sent_counter += 1
            except Exception:
                logger.exception("Failed to publish %s", source_url)
