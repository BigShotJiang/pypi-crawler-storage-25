import logging
import pathlib
import re
from urllib.parse import urljoin, urlparse

import httpx
from boltons.setutils import IndexedSet
from bs4 import BeautifulSoup
from telegraph import Telegraph
from grabber.core.extractor.infrastructure.parsing.title import remove_diacritics

from grabber.core.extractor.constants import headers_mapping
from grabber.core.extractor.infrastructure.publishing import send_videos_to_channel

logger = logging.getLogger(__name__)


def get_page_title(soup: BeautifulSoup) -> str:
    tag = soup.find("title")
    raw = tag.get_text(strip=True) if tag else "video"
    return remove_diacritics(raw.split("|")[0].split("-")[0].strip())


def extract_video_url(soup: BeautifulSoup) -> str | None:
    for script in soup.find_all("script"):
        text = script.get_text()
        if "video_url" not in text:
            continue
        # Prefer 720p alt URL, fall back to standard URL
        for key in ("video_alt_url", "video_url"):
            match = re.search(rf"{key}:\s*'([^']+)'", text)
            if match:
                url = match.group(1).strip()
                if url and url.startswith("http"):
                    return url
    return None


def extract_video_page_links(soup: BeautifulSoup, base_url: str) -> list[str]:
    links = []
    for a in soup.select("a[href*='/video/']"):
        href = str(a.attrs.get("href", "")).strip()
        if href:
            links.append(urljoin(base_url, href))
    return list(dict.fromkeys(links))


async def _fetch_soup(client: httpx.AsyncClient, url: str) -> BeautifulSoup:
    response = await client.get(url)
    response.raise_for_status()
    return BeautifulSoup(response.text, "html.parser")


def _session_headers(client: httpx.AsyncClient, base_headers: dict[str, str]) -> dict[str, str]:
    cookies = dict(client.cookies)
    if not cookies:
        return base_headers
    cookie_str = "; ".join(f"{k}={v}" for k, v in cookies.items())
    return {**base_headers, "Cookie": cookie_str}


async def get_sources_for_sexyegirls(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs,
) -> None:
    channel = kwargs.get("channel", "")
    base_headers = dict(headers_mapping.get(entity, {}))

    async with httpx.AsyncClient(headers=base_headers, follow_redirects=True, timeout=30) as client:
        for source_url in sources:
            try:
                soup = await _fetch_soup(client, source_url)
            except Exception:
                logger.exception("Failed to fetch %s", source_url)
                continue
            video_url = extract_video_url(soup)
            headers = _session_headers(client, base_headers)

            if video_url:
                title = get_page_title(soup)
                filename = pathlib.Path(urlparse(video_url).path).name or "video.mp4"
                print(f"[sexyegirls] video found: {video_url}")
                print(f"[sexyegirls] title: {title} | channel: {channel}")
                records: IndexedSet = IndexedSet([(filename, video_url)])
                stats = await send_videos_to_channel(
                    channel=channel,
                    page_title=title,
                    source_url=source_url,
                    ordered_unique_video_urls=records,
                    headers=headers,
                )
                print(f"[sexyegirls] sent={stats.sent_count} skipped={stats.skipped_count} failed={stats.failed_count} link_only={stats.link_only_count}")
            else:
                video_links = extract_video_page_links(soup, source_url)
                print(f"[sexyegirls] no direct video — found {len(video_links)} video page link(s)")
                for video_page_url in video_links:
                    try:
                        video_soup = await _fetch_soup(client, video_page_url)
                    except Exception:
                        logger.warning("Failed to fetch video page %s", video_page_url)
                        continue
                    url = extract_video_url(video_soup)
                    if not url:
                        logger.warning("No video URL found on %s", video_page_url)
                        continue
                    title = get_page_title(video_soup)
                    filename = pathlib.Path(urlparse(url).path).name or "video.mp4"
                    print(f"[sexyegirls] video found: {url}")
                    records = IndexedSet([(filename, url)])
                    headers = _session_headers(client, base_headers)
                    stats = await send_videos_to_channel(
                        channel=channel,
                        page_title=title,
                        source_url=video_page_url,
                        ordered_unique_video_urls=records,
                        headers=headers,
                    )
                    print(f"[sexyegirls] sent={stats.sent_count} skipped={stats.skipped_count} failed={stats.failed_count} link_only={stats.link_only_count}")
