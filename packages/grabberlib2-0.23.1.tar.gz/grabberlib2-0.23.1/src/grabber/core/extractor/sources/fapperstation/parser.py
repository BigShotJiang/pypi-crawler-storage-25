import asyncio
import logging
import pathlib
import re
import tempfile
from urllib.parse import parse_qs, unquote, urljoin, urlparse

import httpx
from bs4 import BeautifulSoup
from telegraph import Telegraph

from grabber.core.extractor.constants import headers_mapping
from grabber.core.extractor.infrastructure.parsing.title import remove_diacritics
from grabber.core.extractor.infrastructure.publishing.video_delivery import send_local_video_to_channel

logger = logging.getLogger(__name__)

_VIDEO_PAGE_RE = re.compile(r"^https?://(?:www\.)?fapperstation\.com/videos/[^/?#]+/?$")


def _is_video_page(url: str) -> bool:
    return bool(_VIDEO_PAGE_RE.match(url))


def get_page_title(soup: BeautifulSoup) -> str:
    tag = soup.find("title")
    raw = tag.get_text(strip=True) if tag else "video"
    return remove_diacritics(raw.split(" - ")[0].strip())


def extract_m3u8_url(soup: BeautifulSoup, base_url: str) -> str | None:
    tag = soup.select_one("video source[src]")
    if not tag:
        return None
    src = str(tag.attrs.get("src", "")).strip()
    if not src:
        return None
    full_proxy_url = urljoin(base_url, src)
    parsed = urlparse(full_proxy_url)
    qs = parse_qs(parsed.query)
    url_params = qs.get("url", [])
    if url_params:
        return unquote(url_params[0])
    if src.endswith(".m3u8"):
        return src
    return None


def _slug_from_url(url: str) -> str:
    return pathlib.Path(urlparse(url).path.rstrip("/")).name or "video"


async def _download_hls(m3u8_url: str, output_path: pathlib.Path) -> pathlib.Path:
    from yt_dlp import YoutubeDL

    ydl_opts = {
        "quiet": True,
        "no_warnings": True,
        "outtmpl": str(output_path.with_suffix("")) + ".%(ext)s",
        "format": "best",
        "merge_output_format": "mp4",
    }

    def _run() -> None:
        with YoutubeDL(ydl_opts) as ydl:
            ydl.download([m3u8_url])

    await asyncio.to_thread(_run)

    mp4 = output_path.with_suffix(".mp4")
    if mp4.exists():
        return mp4
    candidates = list(output_path.parent.glob(f"{output_path.stem}.*"))
    if candidates:
        return candidates[0]
    raise FileNotFoundError(f"yt-dlp output not found near {output_path}")


async def get_sources_for_fapperstation(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs,
) -> None:
    channel = str(kwargs.get("channel", ""))
    save_local = bool(kwargs.get("save_local", False))
    headers = dict(headers_mapping.get(entity, {}))

    async with httpx.AsyncClient(headers=headers, follow_redirects=True, timeout=30) as client:
        for source_url in sources:
            try:
                response = await client.get(source_url)
                response.raise_for_status()
                soup = BeautifulSoup(response.text, "lxml")
            except Exception:
                logger.exception("Failed to fetch %s", source_url)
                continue

            m3u8_url = extract_m3u8_url(soup, source_url)
            if not m3u8_url:
                logger.warning("No m3u8 URL found on %s", source_url)
                continue

            title = get_page_title(soup)
            slug = _slug_from_url(source_url)
            print(f"[fapperstation] m3u8 found | title: {title}")
            print(f"[fapperstation] m3u8: {m3u8_url}")

            if save_local:
                media_dir = pathlib.Path.cwd() / ".media"
                media_dir.mkdir(exist_ok=True)
                output_path = media_dir / slug
                try:
                    video_file = await _download_hls(m3u8_url, output_path)
                except Exception:
                    logger.exception("HLS download failed for %s", source_url)
                    continue
                print(f"[fapperstation] saved {video_file.stat().st_size / 1024 / 1024:.1f}MB -> {video_file}")
                continue

            if not channel:
                logger.warning("No channel set; skipping send for %s", source_url)
                continue

            with tempfile.TemporaryDirectory(prefix="grabber-fapperstation-") as tmp:
                tmp_path = pathlib.Path(tmp) / slug
                try:
                    video_file = await _download_hls(m3u8_url, tmp_path)
                except Exception:
                    logger.exception("HLS download failed for %s", source_url)
                    continue

                print(f"[fapperstation] downloaded {video_file.stat().st_size / 1024 / 1024:.1f}MB -> sending")
                ok = await send_local_video_to_channel(
                    channel=channel,
                    page_title=title,
                    source_url=source_url,
                    local_file_path=video_file,
                    video_filename=video_file.name,
                )
                print(f"[fapperstation] send {'ok' if ok else 'failed'}")
