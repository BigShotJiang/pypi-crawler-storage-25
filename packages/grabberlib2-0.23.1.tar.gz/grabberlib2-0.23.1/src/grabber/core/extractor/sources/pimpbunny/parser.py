import asyncio
import logging
import pathlib
import re
from urllib.parse import parse_qs, urljoin, urlparse

from boltons.setutils import IndexedSet
from bs4 import BeautifulSoup
from telegraph import Telegraph
from grabber.core.extractor.infrastructure.parsing.title import remove_diacritics

from grabber.core.extractor.constants import headers_mapping
from grabber.core.extractor.infrastructure.fetching.scraper import get_webdriver
from grabber.core.extractor.infrastructure.publishing import send_videos_to_channel

logger = logging.getLogger(__name__)

_VIDEO_PAGE_RE = re.compile(r"^https?://(?:www\.)?pimpbunny\.com/videos/[^/?#]+/?$")


def _is_video_page(url: str) -> bool:
    return bool(_VIDEO_PAGE_RE.match(url))


def get_page_title(soup: BeautifulSoup) -> str:
    tag = soup.find("title")
    raw = tag.get_text(strip=True) if tag else "video"
    return remove_diacritics(raw.split("|")[0].split("-")[0].strip())


def _extract_filename(video_url: str) -> str:
    parsed = urlparse(video_url)
    qs = parse_qs(parsed.query)
    file_param = qs.get("file", [""])[0]
    if file_param:
        return pathlib.Path(file_param).name or "video.mp4"
    return pathlib.Path(parsed.path).name or "video.mp4"


def extract_video_url(soup: BeautifulSoup) -> str | None:
    tag = soup.select_one("video[src]")
    if tag:
        src = str(tag.attrs.get("src", "")).strip()
        if src.startswith("http"):
            return src
    tag = soup.select_one("video source[src]")
    if tag:
        src = str(tag.attrs.get("src", "")).strip()
        if src.startswith("http"):
            return src
    return None


def extract_video_page_links(soup: BeautifulSoup, base_url: str) -> list[str]:
    links = []
    for a in soup.select("a[href]"):
        href = str(a.attrs.get("href", "")).strip()
        if not href:
            continue
        full_url = urljoin(base_url, href).split("?")[0].split("#")[0]
        if _VIDEO_PAGE_RE.match(full_url):
            links.append(full_url)
    return list(dict.fromkeys(links))


async def _fetch_soup(url: str) -> BeautifulSoup:
    driver = await get_webdriver()
    try:
        driver.get(url)
        await asyncio.sleep(5)
        return BeautifulSoup(driver.page_source, "html.parser")
    finally:
        driver.quit()


async def get_sources_for_pimpbunny(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs,
) -> None:
    channel = kwargs.get("channel", "")
    headers = dict(headers_mapping.get(entity, {}))

    for source_url in sources:
        try:
            soup = await _fetch_soup(source_url)
        except Exception:
            logger.exception("Failed to fetch %s", source_url)
            continue

        video_url = extract_video_url(soup)

        if video_url:
            title = get_page_title(soup)
            filename = _extract_filename(video_url)
            print(f"[pimpbunny] video found: {video_url}")
            print(f"[pimpbunny] title: {title} | channel: {channel}")
            records: IndexedSet = IndexedSet([(filename, video_url)])
            stats = await send_videos_to_channel(
                channel=channel,
                page_title=title,
                source_url=source_url,
                ordered_unique_video_urls=records,
                headers=headers,
            )
            print(
                f"[pimpbunny] sent={stats.sent_count} skipped={stats.skipped_count} failed={stats.failed_count} link_only={stats.link_only_count}"
            )
        elif _is_video_page(source_url):
            logger.warning("No video URL found on video page %s", source_url)
        else:
            video_links = extract_video_page_links(soup, source_url)
            print(f"[pimpbunny] no direct video — found {len(video_links)} video page link(s)")
            for video_page_url in video_links:
                try:
                    video_soup = await _fetch_soup(video_page_url)
                except Exception:
                    logger.warning("Failed to fetch video page %s", video_page_url)
                    continue
                url = extract_video_url(video_soup)
                if not url:
                    logger.warning("No video URL found on %s", video_page_url)
                    continue
                title = get_page_title(video_soup)
                filename = _extract_filename(url)
                records = IndexedSet([(filename, url)])
                stats = await send_videos_to_channel(
                    channel=channel,
                    page_title=title,
                    source_url=video_page_url,
                    ordered_unique_video_urls=records,
                    headers=headers,
                )
                print(
                    f"[pimpbunny] sent={stats.sent_count} skipped={stats.skipped_count} failed={stats.failed_count} link_only={stats.link_only_count}"
                )
