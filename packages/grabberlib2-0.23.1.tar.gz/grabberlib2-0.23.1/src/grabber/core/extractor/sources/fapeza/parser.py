from typing import cast

from bs4 import BeautifulSoup, Tag
from grabber.core.extractor.infrastructure.parsing.title import remove_diacritics


class FapezaParser:
    @staticmethod
    def get_page_title(soup: BeautifulSoup) -> str:
        title_tag = cast(Tag, soup.find("title"))
        page_title = title_tag.get_text(strip=True).strip().rstrip()
        page_title = page_title.split("- Fapeza")[0].split("Nude")[0].replace("https:", "")
        return remove_diacritics(
            " ".join(
                f"#{part.strip().replace(' ', '').replace('.', '_').replace('-', '_')}"
                for part in page_title.split("/")
            )
        )
