"""Unit and integration tests for webhook authentication, cooldowns, and async jobs.

Covers:
- Bearer token authentication (missing, wrong, valid)
- Per-endpoint cooldown enforcement (429 with Retry-After)
- Cooldown persistence via DuckDB get_metadata / set_metadata
- App composition: parent Starlette app mounts both /api/* and /mcp paths
- Webhooks-disabled state: no /api routes when disabled or no secret env var
- Async job contract: POST /poll|/rescore|/maintenance returns 202 + job_id,
  background task runs the real work, GET /jobs/{id} surfaces the result
"""

from __future__ import annotations

import os
import time
from typing import Any

import pytest
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Mount, Route
from starlette.testclient import TestClient

from distillery.config import DistilleryConfig, ServerConfig, WebhookConfig
from distillery.mcp.webhooks import _verify_bearer_token, create_webhook_app
from distillery.store.duckdb import DuckDBStore

# The autouse fixture that clears ``_jobs``, ``_active_job_by_endpoint``,
# ``_endpoint_locks``, and ``_cooldown_ts`` between tests lives in the root
# ``tests/conftest.py`` so all webhook test files share it.

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_SECRET = "test-webhook-secret-xyz"
_AUTH_HEADER = {"Authorization": f"Bearer {_SECRET}"}


def _make_config(
    *, enabled: bool = True, secret_env: str = "DISTILLERY_WEBHOOK_SECRET"
) -> DistilleryConfig:
    """Return a DistilleryConfig with WebhookConfig overrides."""
    return DistilleryConfig(
        server=ServerConfig(
            webhooks=WebhookConfig(enabled=enabled, secret_env=secret_env),
        )
    )


def _make_shared_state(store: DuckDBStore) -> dict[str, Any]:
    """Return a minimal shared-state dict using *store*."""
    return {"store": store, "config": _make_config(), "embedding_provider": None}


def _wait_for_job(
    client: TestClient,
    job_id: str,
    *,
    timeout_s: float = 5.0,
    poll_interval_s: float = 0.01,
    path_prefix: str = "",
) -> dict[str, Any]:
    """Poll ``GET {path_prefix}/jobs/{job_id}`` until the job reaches a terminal state.

    ``path_prefix`` supports the parent-mount composition case (e.g.
    ``"/api"`` when the webhook app is mounted behind Starlette's ``Mount``)
    — the default empty string works for tests that hit the webhook app
    directly.

    Raises :class:`AssertionError` on timeout so tests fail with a readable
    message rather than flaking.  Returns the serialised job dict.
    """
    deadline = time.monotonic() + timeout_s
    url = f"{path_prefix}/jobs/{job_id}"
    last: dict[str, Any] | None = None
    while time.monotonic() < deadline:
        resp = client.get(url, headers=_AUTH_HEADER)
        assert resp.status_code == 200, f"GET {url} → {resp.status_code}: {resp.text}"
        body = resp.json()
        assert body["ok"] is True, body
        last = body["data"]
        if last["state"] in ("succeeded", "failed"):
            return last
        time.sleep(poll_interval_s)
    raise AssertionError(f"job {job_id} did not terminate within {timeout_s}s; last={last!r}")


# ---------------------------------------------------------------------------
# Auth tests
# ---------------------------------------------------------------------------


@pytest.mark.unit
async def test_auth_missing_token(store: DuckDBStore, monkeypatch: pytest.MonkeyPatch) -> None:
    """POST to /poll without Authorization header returns 401 unauthorized."""
    monkeypatch.setenv("DISTILLERY_WEBHOOK_SECRET", _SECRET)
    config = _make_config()
    shared = _make_shared_state(store)
    app = create_webhook_app(shared, config)

    client = TestClient(app, raise_server_exceptions=False)
    resp = client.post("/poll")

    assert resp.status_code == 401
    assert resp.json() == {"ok": False, "error": "unauthorized"}


@pytest.mark.unit
async def test_auth_wrong_token(store: DuckDBStore, monkeypatch: pytest.MonkeyPatch) -> None:
    """POST with wrong bearer token returns 401 unauthorized."""
    monkeypatch.setenv("DISTILLERY_WEBHOOK_SECRET", _SECRET)
    config = _make_config()
    shared = _make_shared_state(store)
    app = create_webhook_app(shared, config)

    client = TestClient(app, raise_server_exceptions=False)
    resp = client.post("/poll", headers={"Authorization": "Bearer wrong-secret-value"})

    assert resp.status_code == 401
    assert resp.json() == {"ok": False, "error": "unauthorized"}


@pytest.mark.unit
async def test_auth_valid_token_returns_202(
    store: DuckDBStore, monkeypatch: pytest.MonkeyPatch
) -> None:
    """POST with correct bearer token returns 202 and a job id."""
    monkeypatch.setenv("DISTILLERY_WEBHOOK_SECRET", _SECRET)
    config = _make_config()
    shared = _make_shared_state(store)
    app = create_webhook_app(shared, config)

    with TestClient(app, raise_server_exceptions=False) as client:
        resp = client.post("/poll", headers=_AUTH_HEADER)

        assert resp.status_code == 202, f"Expected 202, got {resp.status_code}: {resp.text}"
        body = resp.json()
        assert body["ok"] is True
        assert isinstance(body["job_id"], str) and body["job_id"]
        assert body["state"] == "queued"
        assert body["status_url"] == f"/jobs/{body['job_id']}"

        # The background task must complete; the real FeedPoller runs against
        # the empty fixture store and returns an all-zeros poll summary.
        final = _wait_for_job(client, body["job_id"])
        assert final["state"] == "succeeded"


def _make_request_with_auth(header_value: str) -> Request:
    """Build a minimal Starlette :class:`Request` carrying *header_value* as Authorization."""
    scope = {
        "type": "http",
        "method": "POST",
        "path": "/poll",
        "headers": [(b"authorization", header_value.encode("latin-1"))],
    }
    return Request(scope)


@pytest.mark.unit
@pytest.mark.parametrize(
    "scheme",
    ["Bearer", "bearer", "BEARER", "BeArEr"],
    ids=["title-case", "lower-case", "upper-case", "mixed-case"],
)
def test_verify_bearer_token_scheme_case_insensitive(scheme: str) -> None:
    """Regression for #469: RFC 7235 §2.1 makes the auth scheme case-insensitive."""
    request = _make_request_with_auth(f"{scheme} {_SECRET}")
    assert _verify_bearer_token(request, _SECRET) is True


@pytest.mark.unit
def test_verify_bearer_token_rejects_other_schemes() -> None:
    """Schemes other than ``bearer`` must still be rejected even if the token matches."""
    request = _make_request_with_auth(f"Basic {_SECRET}")
    assert _verify_bearer_token(request, _SECRET) is False


@pytest.mark.unit
def test_verify_bearer_token_rejects_missing_token() -> None:
    """A header with the right scheme but no token value must be rejected."""
    assert _verify_bearer_token(_make_request_with_auth("Bearer"), _SECRET) is False
    assert _verify_bearer_token(_make_request_with_auth("Bearer "), _SECRET) is False


@pytest.mark.unit
async def test_auth_lowercase_bearer_scheme_accepted(
    store: DuckDBStore, monkeypatch: pytest.MonkeyPatch
) -> None:
    """End-to-end regression: ``Authorization: bearer <token>`` is accepted (#469)."""
    monkeypatch.setenv("DISTILLERY_WEBHOOK_SECRET", _SECRET)
    config = _make_config()
    shared = _make_shared_state(store)
    app = create_webhook_app(shared, config)

    with TestClient(app, raise_server_exceptions=False) as client:
        resp = client.post("/poll", headers={"Authorization": f"bearer {_SECRET}"})

        assert resp.status_code == 202, f"Expected 202, got {resp.status_code}: {resp.text}"
        body = resp.json()
        assert body["ok"] is True
        assert isinstance(body["job_id"], str) and body["job_id"]

        # Wait for the background job to terminate so teardown doesn't race
        # with the autouse fixture that clears the in-process job registry.
        final = _wait_for_job(client, body["job_id"])
        assert final["state"] == "succeeded"


# ---------------------------------------------------------------------------
# Cooldown tests
# ---------------------------------------------------------------------------


@pytest.mark.unit
async def test_cooldown_enforced(store: DuckDBStore, monkeypatch: pytest.MonkeyPatch) -> None:
    """First authenticated request returns 202; immediate second returns 429 with Retry-After."""
    monkeypatch.setenv("DISTILLERY_WEBHOOK_SECRET", _SECRET)
    config = _make_config()
    shared = _make_shared_state(store)
    app = create_webhook_app(shared, config)

    with TestClient(app, raise_server_exceptions=False) as client:
        # First request: enqueues job, returns 202.  Cooldown is reserved
        # synchronously before 202 returns.
        first = client.post("/poll", headers=_AUTH_HEADER)
        assert first.status_code == 202, f"Expected 202 on first request, got {first.status_code}"

        # Wait for the first job to terminate before the second POST.  The
        # dispatcher checks idempotency (409) before cooldown (429); while
        # the first job is in flight the second call correctly returns 409.
        # To test cooldown enforcement in isolation we need the first job
        # out of the active-job registry first.
        _wait_for_job(client, first.json()["job_id"])

        # Second request after the first finished: now it hits the cooldown
        # path and must be rejected with 429.
        second = client.post("/poll", headers=_AUTH_HEADER)
        assert second.status_code == 429, (
            f"Expected 429 on second request, got {second.status_code}"
        )

        body = second.json()
        assert body["ok"] is False
        assert body["error"] == "too_early"
        assert "retry_after" in body
        assert isinstance(body["retry_after"], int)
        assert body["retry_after"] > 0

        # Retry-After header must also be present.
        assert "retry-after" in second.headers
        assert int(second.headers["retry-after"]) > 0


@pytest.mark.integration
async def test_cooldown_persisted(store: DuckDBStore, monkeypatch: pytest.MonkeyPatch) -> None:
    """Cooldown set by one app instance is visible to a new app using the same store.

    This tests DuckDB persistence: the cooldown timestamp written by
    create_webhook_app#1 via store.set_metadata is still present when a second
    create_webhook_app#2 instance is created pointing at the same store.
    """
    monkeypatch.setenv("DISTILLERY_WEBHOOK_SECRET", _SECRET)
    config = _make_config()
    shared1 = _make_shared_state(store)
    app1 = create_webhook_app(shared1, config)

    with TestClient(app1, raise_server_exceptions=False) as client1:
        # First request triggers cooldown recording in DuckDB.
        resp = client1.post("/poll", headers=_AUTH_HEADER)
        assert resp.status_code == 202
        _wait_for_job(client1, resp.json()["job_id"])

    # Verify the cooldown was actually written to DuckDB.
    cooldown_val = await store.get_metadata("webhook_cooldown:poll")
    assert cooldown_val is not None, "Cooldown timestamp was not persisted to DuckDB"

    # Create a brand-new app instance with a fresh shared_state dict,
    # but pointing at the same underlying store.
    shared2 = _make_shared_state(store)
    app2 = create_webhook_app(shared2, config)
    with TestClient(app2, raise_server_exceptions=False) as client2:
        # The new app should see the cooldown from DuckDB.
        resp2 = client2.post("/poll", headers=_AUTH_HEADER)
        assert resp2.status_code == 429, (
            "New webhook app instance did not see DuckDB-persisted cooldown"
        )
        assert resp2.json()["error"] == "too_early"


# ---------------------------------------------------------------------------
# App composition tests
# ---------------------------------------------------------------------------


@pytest.mark.integration
async def test_app_composition(store: DuckDBStore, monkeypatch: pytest.MonkeyPatch) -> None:
    """When webhooks are enabled and secret is set, parent Starlette app serves both
    /api/* and /mcp paths.
    """
    monkeypatch.setenv("DISTILLERY_WEBHOOK_SECRET", _SECRET)
    config = _make_config()
    shared = _make_shared_state(store)
    webhook_app = create_webhook_app(shared, config)

    # Build a minimal stub for the MCP app.
    async def _mcp_handler(request: Request) -> JSONResponse:
        return JSONResponse({"mcp": True})

    mcp_stub = Starlette(routes=[Route("/mcp", _mcp_handler)])

    # Compose parent app exactly as __main__.py does.
    parent = Starlette(
        routes=[
            Mount("/api", app=webhook_app),
            Mount("/", app=mcp_stub),
        ]
    )

    with TestClient(parent, raise_server_exceptions=False) as client:
        # /mcp path should be accessible.
        mcp_resp = client.get("/mcp")
        assert mcp_resp.status_code == 200
        assert mcp_resp.json() == {"mcp": True}

        # /api/poll without auth should return 401.
        api_resp = client.post("/api/poll")
        assert api_resp.status_code == 401
        assert api_resp.json()["error"] == "unauthorized"

        # /api/poll with correct auth should return 202 + job id.
        api_auth_resp = client.post("/api/poll", headers=_AUTH_HEADER)
        assert api_auth_resp.status_code == 202
        job_id = api_auth_resp.json()["job_id"]

        # Let the bg task complete to avoid a pending task at teardown.
        deadline = time.monotonic() + 5.0
        while time.monotonic() < deadline:
            resp = client.get(f"/api/jobs/{job_id}", headers=_AUTH_HEADER)
            assert resp.status_code == 200
            if resp.json()["data"]["state"] in ("succeeded", "failed"):
                break
            time.sleep(0.01)


# ---------------------------------------------------------------------------
# Disabled-state tests
# ---------------------------------------------------------------------------


@pytest.mark.unit
async def test_webhooks_disabled(store: DuckDBStore, monkeypatch: pytest.MonkeyPatch) -> None:
    """When webhooks are disabled OR the secret env var is unset, /api routes should
    not be mounted in the parent app.

    This test mirrors the guard in __main__.py:
        if config.server.webhooks.enabled and os.environ.get(config.server.webhooks.secret_env)
    """
    # Scenario 1: webhooks disabled via config flag (secret is still set).
    monkeypatch.setenv("DISTILLERY_WEBHOOK_SECRET", _SECRET)
    config_disabled = _make_config(enabled=False)
    shared = _make_shared_state(store)

    async def _mcp_handler(request: Request) -> JSONResponse:
        return JSONResponse({"mcp": True})

    mcp_stub = Starlette(routes=[Route("/mcp", _mcp_handler)])

    # Replicate __main__.py logic: only compose if enabled AND secret set.
    if config_disabled.server.webhooks.enabled and os.environ.get(
        config_disabled.server.webhooks.secret_env
    ):
        webhook_app = create_webhook_app(shared, config_disabled)
        final_app: Starlette = Starlette(
            routes=[
                Mount("/api", app=webhook_app),
                Mount("/", app=mcp_stub),
            ]
        )
    else:
        # Pass through as-is — no /api routes.
        final_app = mcp_stub

    client = TestClient(final_app, raise_server_exceptions=False)

    # /api/poll must not exist when disabled — expect 404.
    resp = client.post("/api/poll", headers=_AUTH_HEADER)
    assert resp.status_code == 404, (
        f"Expected 404 (no /api routes when disabled), got {resp.status_code}"
    )

    # /mcp is still accessible.
    mcp_resp = client.get("/mcp")
    assert mcp_resp.status_code == 200

    # Scenario 2: webhooks enabled via config but no secret env var set.
    monkeypatch.delenv("DISTILLERY_WEBHOOK_SECRET", raising=False)
    config_no_secret = _make_config(enabled=True)

    if config_no_secret.server.webhooks.enabled and os.environ.get(
        config_no_secret.server.webhooks.secret_env
    ):
        webhook_app2 = create_webhook_app(shared, config_no_secret)
        final_app2: Starlette = Starlette(
            routes=[
                Mount("/api", app=webhook_app2),
                Mount("/", app=mcp_stub),
            ]
        )
    else:
        final_app2 = mcp_stub

    client2 = TestClient(final_app2, raise_server_exceptions=False)

    resp2 = client2.post("/api/poll", headers=_AUTH_HEADER)
    assert resp2.status_code == 404, (
        f"Expected 404 (no /api routes when no secret), got {resp2.status_code}"
    )


# ---------------------------------------------------------------------------
# Handler tests — poll, rescore, maintenance (async contract)
# ---------------------------------------------------------------------------


@pytest.mark.unit
async def test_poll_handler(store: DuckDBStore, monkeypatch: pytest.MonkeyPatch) -> None:
    """POST /poll returns 202 immediately; the background job runs FeedPoller.poll()
    and the GET /jobs/{id} result reflects the summary."""
    from unittest.mock import AsyncMock, MagicMock, patch

    from distillery.feeds.poller import PollerSummary, PollResult

    monkeypatch.setenv("DISTILLERY_WEBHOOK_SECRET", _SECRET)
    config = _make_config()
    shared = _make_shared_state(store)

    result = PollResult(
        source_url="https://example.com/feed", source_type="rss", items_fetched=10, items_stored=7
    )
    summary = PollerSummary(results=[result], total_fetched=10, total_stored=7, sources_polled=1)

    mock_poller = MagicMock()
    mock_poller.poll = AsyncMock(return_value=summary)

    with patch("distillery.mcp.webhooks.FeedPoller", return_value=mock_poller) as mock_cls:
        app = create_webhook_app(shared, config)
        with TestClient(app, raise_server_exceptions=False) as client:
            resp = client.post("/poll", headers=_AUTH_HEADER)
            assert resp.status_code == 202, f"Expected 202, got {resp.status_code}: {resp.text}"
            final = _wait_for_job(client, resp.json()["job_id"])

    assert final["state"] == "succeeded", final
    data = final["result"]
    assert data["sources_polled"] == 1
    assert data["items_fetched"] == 10
    assert data["items_stored"] == 7
    assert data["errors"] == []
    mock_cls.assert_called_once()
    mock_poller.poll.assert_awaited_once()


@pytest.mark.unit
async def test_poll_advances_last_polled_at_in_store(
    store: DuckDBStore, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Issue #404: ``POST /poll`` must advance ``feed_sources.last_polled_at``
    on the store, regardless of whether the webhook background task lives
    long enough to write ``webhook_audit:poll``.

    Drives the real :class:`FeedPoller` against an in-memory DuckDBStore
    with a stubbed adapter so the test exercises the production code path:
    parse → 202 → bg task → ``_poll_source`` → ``_persist_poll_status``.
    """
    from datetime import UTC, datetime
    from unittest.mock import MagicMock, patch

    monkeypatch.setenv("DISTILLERY_WEBHOOK_SECRET", _SECRET)
    config = _make_config()

    # Seed a real feed source so list_feed_sources() returns something
    # for the poller to iterate over.
    await store.add_feed_source(
        url="https://example.com/rss",
        source_type="rss",
        poll_interval_minutes=60,
    )

    shared = _make_shared_state(store)

    # Capture t0 BEFORE the webhook fires so the assertion is robust to
    # event-loop scheduling skew.
    t0 = datetime.now(tz=UTC)

    with patch("distillery.feeds.poller._build_adapter") as mock_build:
        mock_adapter = MagicMock()
        mock_adapter.fetch.return_value = []  # no items → fast poll
        mock_build.return_value = mock_adapter

        app = create_webhook_app(shared, config)
        with TestClient(app, raise_server_exceptions=False) as client:
            resp = client.post("/poll", headers=_AUTH_HEADER)
            assert resp.status_code == 202, resp.text
            _wait_for_job(client, resp.json()["job_id"])

    sources = await store.list_feed_sources()
    assert len(sources) == 1
    last = sources[0]["last_polled_at"]
    assert isinstance(last, str), (
        "POST /poll must update feed_sources.last_polled_at via the "
        "real FeedPoller (#404 — was stuck at NULL after async refactor)"
    )
    assert datetime.fromisoformat(last) >= t0
    # next_poll_at is derived from last_polled_at + interval — also
    # asserted because the issue notes it was always null.
    assert sources[0]["next_poll_at"] is not None


@pytest.mark.unit
async def test_rescore_handler(store: DuckDBStore, monkeypatch: pytest.MonkeyPatch) -> None:
    """POST /rescore with body {limit: 50} returns 202; the background job
    forwards limit=50 to FeedPoller.rescore() and the job result carries the stats."""
    from unittest.mock import AsyncMock, MagicMock, patch

    monkeypatch.setenv("DISTILLERY_WEBHOOK_SECRET", _SECRET)
    config = _make_config()
    shared = _make_shared_state(store)

    rescore_stats = {"rescored": 50, "upgraded": 12, "downgraded": 5, "errors": 0}

    mock_poller = MagicMock()
    mock_poller.rescore = AsyncMock(return_value=rescore_stats)

    with patch("distillery.mcp.webhooks.FeedPoller", return_value=mock_poller):
        app = create_webhook_app(shared, config)
        with TestClient(app, raise_server_exceptions=False) as client:
            resp = client.post("/rescore", headers=_AUTH_HEADER, json={"limit": 50})
            assert resp.status_code == 202, f"Expected 202, got {resp.status_code}: {resp.text}"
            final = _wait_for_job(client, resp.json()["job_id"])

    assert final["state"] == "succeeded", final
    data = final["result"]
    assert data["rescored"] == 50
    assert data["upgraded"] == 12
    assert data["downgraded"] == 5
    # Verify the custom limit was forwarded to the poller.
    mock_poller.rescore.assert_awaited_once_with(limit=50)


@pytest.mark.unit
async def test_maintenance_handler(store: DuckDBStore, monkeypatch: pytest.MonkeyPatch) -> None:
    """POST /maintenance returns 202; the background job orchestrates
    poll → rescore → classify-batch and the GET /jobs/{id} result contains
    combined poll, rescore, and classify_batch keys."""
    from unittest.mock import AsyncMock, MagicMock, patch

    from distillery.feeds.poller import PollerSummary, PollResult

    monkeypatch.setenv("DISTILLERY_WEBHOOK_SECRET", _SECRET)
    config = _make_config()
    shared = _make_shared_state(store)

    # Mock FeedPoller for both poll and rescore sub-operations.
    poll_result = PollResult(
        source_url="https://example.com/feed",
        source_type="rss",
        items_fetched=5,
        items_stored=3,
    )
    poll_summary = PollerSummary(
        results=[poll_result], total_fetched=5, total_stored=3, sources_polled=1
    )
    rescore_stats = {"rescored": 20, "upgraded": 4, "downgraded": 1}

    mock_poller = MagicMock()
    mock_poller.poll = AsyncMock(return_value=poll_summary)
    mock_poller.rescore = AsyncMock(return_value=rescore_stats)

    with patch("distillery.mcp.webhooks.FeedPoller", return_value=mock_poller):
        app = create_webhook_app(shared, config)
        with TestClient(app, raise_server_exceptions=False) as client:
            resp = client.post("/maintenance", headers=_AUTH_HEADER)
            assert resp.status_code == 202, f"Expected 202, got {resp.status_code}: {resp.text}"
            final = _wait_for_job(client, resp.json()["job_id"])

    assert final["state"] == "succeeded", final
    data = final["result"]

    # Response must contain all three sub-operation keys.
    assert "poll" in data
    assert "rescore" in data
    assert "classify_batch" in data

    # poll sub-result contains expected fields.
    assert data["poll"]["sources_polled"] == 1
    assert data["poll"]["items_fetched"] == 5
    assert data["poll"]["items_stored"] == 3

    # rescore sub-result contains expected fields.
    assert data["rescore"]["rescored"] == 20
    assert data["rescore"]["upgraded"] == 4
    assert data["rescore"]["downgraded"] == 1

    # classify_batch sub-result is present (no pending entries → zeros).
    assert "classified" in data["classify_batch"]


@pytest.mark.unit
async def test_handler_error_surfaces_in_job(
    store: DuckDBStore, monkeypatch: pytest.MonkeyPatch
) -> None:
    """When FeedPoller.poll() raises an exception the endpoint still returns 202,
    but the background job terminates in the 'failed' state with a descriptive
    error payload."""
    from unittest.mock import AsyncMock, MagicMock, patch

    monkeypatch.setenv("DISTILLERY_WEBHOOK_SECRET", _SECRET)
    config = _make_config()
    shared = _make_shared_state(store)

    mock_poller = MagicMock()
    mock_poller.poll = AsyncMock(side_effect=RuntimeError("feed source unavailable"))

    with patch("distillery.mcp.webhooks.FeedPoller", return_value=mock_poller):
        app = create_webhook_app(shared, config)
        with TestClient(app, raise_server_exceptions=False) as client:
            resp = client.post("/poll", headers=_AUTH_HEADER)
            assert resp.status_code == 202, f"Expected 202, got {resp.status_code}: {resp.text}"
            final = _wait_for_job(client, resp.json()["job_id"])

    assert final["state"] == "failed", final
    # The webhook returns a stable, generic error message to clients and keeps
    # the exception details (e.g. "feed source unavailable") in server logs.
    assert final["error"] == "poll cycle failed"


@pytest.mark.unit
async def test_failed_job_triggers_store_rollback(
    store: DuckDBStore, monkeypatch: pytest.MonkeyPatch
) -> None:
    """When the bg runner fails, _execute_job calls store.rollback() so any
    aborted DuckDB transaction state cannot leak into the next webhook job.

    This is the defensive safety-net described in issue #396: a prior
    rollback regression let a poisoned connection cascade every subsequent
    find_similar/store call in the same poll run.  Rollback at the webhook
    boundary is redundant with ``DuckDBStore._run_sync`` on the happy path
    but catches regressions in paths that bypass it.
    """
    from unittest.mock import AsyncMock, MagicMock, patch

    monkeypatch.setenv("DISTILLERY_WEBHOOK_SECRET", _SECRET)
    config = _make_config()

    # Wrap the real store with a spy on rollback() to observe calls without
    # disturbing the rest of the interface.
    rollback_spy = AsyncMock(wraps=store.rollback)
    spy_store = MagicMock(wraps=store)
    spy_store.rollback = rollback_spy
    shared: dict[str, Any] = {
        "store": spy_store,
        "config": _make_config(),
        "embedding_provider": None,
    }

    mock_poller = MagicMock()
    mock_poller.poll = AsyncMock(side_effect=RuntimeError("feed source unavailable"))

    with patch("distillery.mcp.webhooks.FeedPoller", return_value=mock_poller):
        app = create_webhook_app(shared, config)
        with TestClient(app, raise_server_exceptions=False) as client:
            resp = client.post("/poll", headers=_AUTH_HEADER)
            assert resp.status_code == 202
            final = _wait_for_job(client, resp.json()["job_id"])

    assert final["state"] == "failed", final
    assert rollback_spy.await_count >= 1, (
        "store.rollback() must be called when the bg runner fails "
        "(defensive guard against issue #396 cascade)"
    )


# ---------------------------------------------------------------------------
# /hooks/poll and /hooks/rescore endpoint tests (deprecated async aliases)
# ---------------------------------------------------------------------------


@pytest.mark.unit
async def test_hooks_poll_route_exists(store: DuckDBStore, monkeypatch: pytest.MonkeyPatch) -> None:
    """POST /hooks/poll is a valid route that returns 202 + job id with a valid
    bearer token, and the background job succeeds."""
    from unittest.mock import AsyncMock, MagicMock, patch

    from distillery.feeds.poller import PollerSummary, PollResult

    monkeypatch.setenv("DISTILLERY_WEBHOOK_SECRET", _SECRET)
    config = _make_config()
    shared = _make_shared_state(store)

    result = PollResult(
        source_url="https://example.com/feed", source_type="rss", items_fetched=5, items_stored=3
    )
    summary = PollerSummary(results=[result], total_fetched=5, total_stored=3, sources_polled=1)

    mock_poller = MagicMock()
    mock_poller.poll = AsyncMock(return_value=summary)

    with patch("distillery.mcp.webhooks.FeedPoller", return_value=mock_poller):
        app = create_webhook_app(shared, config)
        with TestClient(app, raise_server_exceptions=False) as client:
            resp = client.post("/hooks/poll", headers=_AUTH_HEADER)
            assert resp.status_code == 202, f"Expected 202, got {resp.status_code}: {resp.text}"
            body = resp.json()
            assert body["ok"] is True
            assert "job_id" in body
            final = _wait_for_job(client, body["job_id"])

    assert final["state"] == "succeeded"


@pytest.mark.unit
async def test_hooks_poll_rejects_unauthenticated(
    store: DuckDBStore, monkeypatch: pytest.MonkeyPatch
) -> None:
    """POST /hooks/poll without a bearer token returns 401 unauthorized."""
    monkeypatch.setenv("DISTILLERY_WEBHOOK_SECRET", _SECRET)
    config = _make_config()
    shared = _make_shared_state(store)
    app = create_webhook_app(shared, config)

    client = TestClient(app, raise_server_exceptions=False)
    resp = client.post("/hooks/poll")

    assert resp.status_code == 401
    assert resp.json() == {"ok": False, "error": "unauthorized"}


@pytest.mark.unit
async def test_hooks_poll_source_url_query_param(
    store: DuckDBStore, monkeypatch: pytest.MonkeyPatch
) -> None:
    """POST /hooks/poll?source_url=<url> forwards source_url to FeedPoller.poll()
    on the background task."""
    from unittest.mock import AsyncMock, MagicMock, patch

    from distillery.feeds.poller import PollerSummary, PollResult

    monkeypatch.setenv("DISTILLERY_WEBHOOK_SECRET", _SECRET)
    config = _make_config()
    shared = _make_shared_state(store)

    target_url = "https://example.com/feed"
    result = PollResult(source_url=target_url, source_type="rss", items_fetched=3, items_stored=2)
    summary = PollerSummary(results=[result], total_fetched=3, total_stored=2, sources_polled=1)

    mock_poller = MagicMock()
    mock_poller.poll = AsyncMock(return_value=summary)

    with patch("distillery.mcp.webhooks.FeedPoller", return_value=mock_poller):
        app = create_webhook_app(shared, config)
        with TestClient(app, raise_server_exceptions=False) as client:
            resp = client.post(
                f"/hooks/poll?source_url={target_url}",
                headers=_AUTH_HEADER,
            )
            assert resp.status_code == 202, f"Expected 202, got {resp.status_code}: {resp.text}"
            _wait_for_job(client, resp.json()["job_id"])

    # Verify poll was called with the specific source_url.
    mock_poller.poll.assert_awaited_once_with(source_url=target_url)


@pytest.mark.unit
async def test_hooks_rescore_route_exists(
    store: DuckDBStore, monkeypatch: pytest.MonkeyPatch
) -> None:
    """POST /hooks/rescore is a valid route that returns 202 + job id with a valid
    bearer token, and the background job succeeds."""
    from unittest.mock import AsyncMock, MagicMock, patch

    monkeypatch.setenv("DISTILLERY_WEBHOOK_SECRET", _SECRET)
    config = _make_config()
    shared = _make_shared_state(store)

    rescore_stats = {"rescored": 20, "upgraded": 5, "downgraded": 2, "errors": 0}
    mock_poller = MagicMock()
    mock_poller.rescore = AsyncMock(return_value=rescore_stats)

    with patch("distillery.mcp.webhooks.FeedPoller", return_value=mock_poller):
        app = create_webhook_app(shared, config)
        with TestClient(app, raise_server_exceptions=False) as client:
            resp = client.post("/hooks/rescore", headers=_AUTH_HEADER)
            assert resp.status_code == 202, f"Expected 202, got {resp.status_code}: {resp.text}"
            body = resp.json()
            assert body["ok"] is True
            assert "job_id" in body
            final = _wait_for_job(client, body["job_id"])

    assert final["state"] == "succeeded"


@pytest.mark.unit
async def test_hooks_rescore_rejects_unauthenticated(
    store: DuckDBStore, monkeypatch: pytest.MonkeyPatch
) -> None:
    """POST /hooks/rescore without a bearer token returns 401 unauthorized."""
    monkeypatch.setenv("DISTILLERY_WEBHOOK_SECRET", _SECRET)
    config = _make_config()
    shared = _make_shared_state(store)
    app = create_webhook_app(shared, config)

    client = TestClient(app, raise_server_exceptions=False)
    resp = client.post("/hooks/rescore")

    assert resp.status_code == 401
    assert resp.json() == {"ok": False, "error": "unauthorized"}


@pytest.mark.unit
async def test_hooks_rescore_limit_query_param(
    store: DuckDBStore, monkeypatch: pytest.MonkeyPatch
) -> None:
    """POST /hooks/rescore?limit=50 forwards limit=50 to FeedPoller.rescore()."""
    from unittest.mock import AsyncMock, MagicMock, patch

    monkeypatch.setenv("DISTILLERY_WEBHOOK_SECRET", _SECRET)
    config = _make_config()
    shared = _make_shared_state(store)

    rescore_stats = {"rescored": 50, "upgraded": 10, "downgraded": 3, "errors": 0}
    mock_poller = MagicMock()
    mock_poller.rescore = AsyncMock(return_value=rescore_stats)

    with patch("distillery.mcp.webhooks.FeedPoller", return_value=mock_poller):
        app = create_webhook_app(shared, config)
        with TestClient(app, raise_server_exceptions=False) as client:
            resp = client.post("/hooks/rescore?limit=50", headers=_AUTH_HEADER)
            assert resp.status_code == 202, f"Expected 202, got {resp.status_code}: {resp.text}"
            _wait_for_job(client, resp.json()["job_id"])

    mock_poller.rescore.assert_awaited_once_with(limit=50)


@pytest.mark.unit
async def test_hooks_rescore_invalid_limit_query_param(
    store: DuckDBStore, monkeypatch: pytest.MonkeyPatch
) -> None:
    """POST /hooks/rescore?limit=abc returns 400 bad request (parsed before 202)."""
    monkeypatch.setenv("DISTILLERY_WEBHOOK_SECRET", _SECRET)
    config = _make_config()
    shared = _make_shared_state(store)
    app = create_webhook_app(shared, config)

    client = TestClient(app, raise_server_exceptions=False)
    resp = client.post("/hooks/rescore?limit=abc", headers=_AUTH_HEADER)

    assert resp.status_code == 400
    body = resp.json()
    assert body["ok"] is False
    assert "integer" in body["error"]


@pytest.mark.unit
@pytest.mark.parametrize("bad_limit", ["0", "-1"])
async def test_hooks_rescore_non_positive_limit_query_param(
    store: DuckDBStore, monkeypatch: pytest.MonkeyPatch, bad_limit: str
) -> None:
    """POST /hooks/rescore?limit=0 and ?limit=-1 return 400 bad request.

    Guards the ``limit <= 0`` branch in the rescore parser against regression
    — a purely typed check would let zero/negative values slip through.
    Each bad limit runs in its own parametrised invocation so the
    fresh in-memory ``store`` fixture provides a clean cooldown slate.
    """
    monkeypatch.setenv("DISTILLERY_WEBHOOK_SECRET", _SECRET)
    config = _make_config()
    shared = _make_shared_state(store)
    app = create_webhook_app(shared, config)

    client = TestClient(app, raise_server_exceptions=False)
    resp = client.post(f"/hooks/rescore?limit={bad_limit}", headers=_AUTH_HEADER)

    assert resp.status_code == 400, (
        f"limit={bad_limit!r} should be rejected; got {resp.status_code}: {resp.text}"
    )
    body = resp.json()
    assert body["ok"] is False
    assert "positive" in body["error"], (
        f"error should mention 'positive' for limit={bad_limit!r}; got {body['error']!r}"
    )


# ---------------------------------------------------------------------------
# Async job semantics — idempotency, status endpoint, unknown job id
# ---------------------------------------------------------------------------


@pytest.mark.unit
async def test_jobs_endpoint_requires_auth(
    store: DuckDBStore, monkeypatch: pytest.MonkeyPatch
) -> None:
    """GET /jobs/{id} without a bearer token returns 401 unauthorized."""
    monkeypatch.setenv("DISTILLERY_WEBHOOK_SECRET", _SECRET)
    config = _make_config()
    shared = _make_shared_state(store)
    app = create_webhook_app(shared, config)

    client = TestClient(app, raise_server_exceptions=False)
    resp = client.get("/jobs/does-not-matter")
    assert resp.status_code == 401
    assert resp.json()["error"] == "unauthorized"


@pytest.mark.unit
async def test_jobs_endpoint_unknown_id_returns_404(
    store: DuckDBStore, monkeypatch: pytest.MonkeyPatch
) -> None:
    """GET /jobs/<unknown> returns 404 with a descriptive error."""
    monkeypatch.setenv("DISTILLERY_WEBHOOK_SECRET", _SECRET)
    config = _make_config()
    shared = _make_shared_state(store)
    app = create_webhook_app(shared, config)

    client = TestClient(app, raise_server_exceptions=False)
    resp = client.get("/jobs/no-such-id", headers=_AUTH_HEADER)
    assert resp.status_code == 404
    assert resp.json() == {"ok": False, "error": "job not found"}


@pytest.mark.unit
async def test_second_poll_while_in_flight_returns_409(
    store: DuckDBStore, monkeypatch: pytest.MonkeyPatch
) -> None:
    """While a poll job is running, a second POST /poll returns 409 with the
    existing job_id (including a mount-aware ``status_url``) so the caller
    re-attaches rather than racing a duplicate.

    The dispatcher checks idempotency BEFORE cooldown, so the 409 is the
    authoritative signal even though the first POST also reserved a
    cooldown.  This test therefore needs no cooldown manipulation.
    """
    import asyncio
    from unittest.mock import AsyncMock, MagicMock, patch

    from distillery.feeds.poller import PollerSummary, PollResult

    monkeypatch.setenv("DISTILLERY_WEBHOOK_SECRET", _SECRET)
    config = _make_config()
    shared = _make_shared_state(store)

    # Slow poll: keep the bg task alive long enough that the second request
    # sees the job mid-flight.  asyncio.sleep is safe across portal loops
    # (unlike asyncio.Event which is loop-bound) because the bg task and
    # the second dispatch run in the same TestClient portal.
    result = PollResult(source_url="https://x/feed", source_type="rss")
    summary = PollerSummary(results=[result])

    async def _slow_poll(*args: Any, **kwargs: Any) -> PollerSummary:
        await asyncio.sleep(0.5)
        return summary

    mock_poller = MagicMock()
    mock_poller.poll = AsyncMock(side_effect=_slow_poll)

    with patch("distillery.mcp.webhooks.FeedPoller", return_value=mock_poller):
        app = create_webhook_app(shared, config)
        with TestClient(app, raise_server_exceptions=False) as client:
            first = client.post("/poll", headers=_AUTH_HEADER)
            assert first.status_code == 202
            first_job_id = first.json()["job_id"]

            second = client.post("/poll", headers=_AUTH_HEADER)
            assert second.status_code == 409, (
                f"Expected 409 while first job in-flight, got {second.status_code}: {second.text}"
            )
            body = second.json()
            assert body["ok"] is False
            assert body["error"] == "job_in_progress"
            assert body["job_id"] == first_job_id
            # Unmounted app: status_url has no prefix.
            assert body["status_url"] == f"/jobs/{first_job_id}"

            # Wait for the first job to finish cleanly.
            _wait_for_job(client, first_job_id, timeout_s=3.0)


@pytest.mark.unit
async def test_status_url_respects_mount_prefix(
    store: DuckDBStore, monkeypatch: pytest.MonkeyPatch
) -> None:
    """When the webhook app is mounted at ``/api``, the ``status_url`` in
    both the 202 and 409 responses must include the mount prefix so the
    scheduler can GET it directly without knowing the mount layout.
    """
    monkeypatch.setenv("DISTILLERY_WEBHOOK_SECRET", _SECRET)
    config = _make_config()
    shared = _make_shared_state(store)
    webhook_app = create_webhook_app(shared, config)

    parent = Starlette(routes=[Mount("/api", app=webhook_app)])

    with TestClient(parent, raise_server_exceptions=False) as client:
        first = client.post("/api/poll", headers=_AUTH_HEADER)
        assert first.status_code == 202, f"Expected 202, got {first.status_code}"
        first_body = first.json()
        job_id = first_body["job_id"]

        # 202 response: status_url must include /api prefix.
        assert first_body["status_url"] == f"/api/jobs/{job_id}", (
            f"status_url should be mount-aware; got {first_body['status_url']!r}"
        )

        # GET /api/jobs/{id} must actually work (sanity that the URL is usable).
        status_resp = client.get(first_body["status_url"], headers=_AUTH_HEADER)
        assert status_resp.status_code == 200, (
            f"Reported status_url must be GETtable; got {status_resp.status_code}"
        )

        # 409 response (while in flight): same mount-aware shape.
        second = client.post("/api/poll", headers=_AUTH_HEADER)
        if second.status_code == 409:
            second_body = second.json()
            assert second_body["status_url"] == f"/api/jobs/{second_body['job_id']}"

        # Let the job finish cleanly — mount-aware URL required since the
        # webhook app is behind /api in this test.
        _wait_for_job(client, job_id, path_prefix="/api")


@pytest.mark.unit
async def test_failed_job_records_audit(
    store: DuckDBStore, monkeypatch: pytest.MonkeyPatch
) -> None:
    """When the bg runner raises, _execute_job must still write
    ``webhook_audit:{endpoint}`` with the error so the failure mode isn't
    invisible to operators inspecting the DB.
    """
    from unittest.mock import AsyncMock, MagicMock, patch

    monkeypatch.setenv("DISTILLERY_WEBHOOK_SECRET", _SECRET)
    config = _make_config()
    shared = _make_shared_state(store)

    mock_poller = MagicMock()
    mock_poller.poll = AsyncMock(side_effect=RuntimeError("feed blew up"))

    with patch("distillery.mcp.webhooks.FeedPoller", return_value=mock_poller):
        app = create_webhook_app(shared, config)
        with TestClient(app, raise_server_exceptions=False) as client:
            resp = client.post("/poll", headers=_AUTH_HEADER)
            assert resp.status_code == 202
            final = _wait_for_job(client, resp.json()["job_id"])

    assert final["state"] == "failed"

    # Audit record must exist for the failure — previously the except
    # branch exited without writing one, leaving the DB silent on the
    # most-interesting path.
    audit_raw = await store.get_metadata("webhook_audit:poll")
    assert audit_raw is not None, "webhook_audit:poll must be written even when the runner raises"
    import json as _json

    record = _json.loads(audit_raw)
    assert record["ok"] is False
    assert record["status"] == 500
    assert "feed blew up" in record.get("error", "") or record.get("error")


@pytest.mark.unit
async def test_409_preferred_over_429_when_both_apply(
    store: DuckDBStore, monkeypatch: pytest.MonkeyPatch
) -> None:
    """When a job is in flight AND the cooldown would fire, the dispatcher
    must return 409 (job_in_progress), not 429 (too_early).

    Guards the ordering requested by CodeRabbit review on PR #397:
    schedulers that retry on 429 would back off on a cooldown that merely
    reflects their own in-flight work; the correct action is to poll
    ``/jobs/{id}`` for completion, which 409 signals with ``job_id`` and
    ``status_url``.
    """
    import asyncio
    from unittest.mock import AsyncMock, MagicMock, patch

    from distillery.feeds.poller import PollerSummary, PollResult

    monkeypatch.setenv("DISTILLERY_WEBHOOK_SECRET", _SECRET)
    config = _make_config()
    shared = _make_shared_state(store)

    result = PollResult(source_url="https://x/feed", source_type="rss")
    summary = PollerSummary(results=[result])

    async def _slow_poll(*args: Any, **kwargs: Any) -> PollerSummary:
        await asyncio.sleep(0.5)
        return summary

    mock_poller = MagicMock()
    mock_poller.poll = AsyncMock(side_effect=_slow_poll)

    with patch("distillery.mcp.webhooks.FeedPoller", return_value=mock_poller):
        app = create_webhook_app(shared, config)
        with TestClient(app, raise_server_exceptions=False) as client:
            # First POST sets cooldown AND starts a slow bg job.  When the
            # second POST arrives the cooldown is live (set synchronously
            # before 202 returns) and the job is in flight.  Both gates
            # would fire — we must see 409, not 429.
            first = client.post("/poll", headers=_AUTH_HEADER)
            assert first.status_code == 202

            second = client.post("/poll", headers=_AUTH_HEADER)
            assert second.status_code == 409, (
                f"Expected 409 (job_in_progress wins over cooldown), "
                f"got {second.status_code}: {second.text}"
            )
            assert second.json()["error"] == "job_in_progress"

            _wait_for_job(client, first.json()["job_id"], timeout_s=3.0)
