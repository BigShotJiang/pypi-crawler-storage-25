"""Tests for RelevanceScorer, FeedPoller, and the _handle_poll feed handler.

Note: distillery_poll and distillery_rescore were removed from the MCP tool
surface in T02.2 and moved to /hooks/poll and /hooks/rescore webhook endpoints.
The underlying handler functions (_handle_poll, _handle_rescore) still exist
in distillery.mcp.tools.feeds and are tested here directly as unit tests.

Covers:
  - RelevanceScorer.score: returns max similarity, handles empty text, handles errors
  - FeedPoller.poll: empty sources, items stored, dedup skipping, threshold filtering
  - FeedPoller._is_duplicate: similarity-based dedup
  - _handle_poll: feed handler success path and error paths (not an MCP tool)
  - distillery poll CLI subcommand
"""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from distillery.config import (
    DistilleryConfig,
    FeedsConfig,
    FeedSourceConfig,
    FeedsThresholdsConfig,
)
from distillery.feeds.models import FeedItem
from distillery.feeds.poller import FeedPoller, _item_text
from distillery.feeds.scorer import RelevanceScorer
from distillery.store.protocol import SearchResult

pytestmark = pytest.mark.unit


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_feed_item(
    item_id: str = "item-1",
    source_url: str = "https://example.com/rss",
    source_type: str = "rss",
    title: str | None = "Test Item",
    content: str | None = "Test content",
) -> FeedItem:
    return FeedItem(
        source_url=source_url,
        source_type=source_type,
        item_id=item_id,
        title=title,
        content=content,
    )


def _make_search_result(score: float = 0.8, external_id: str = "") -> SearchResult:
    from distillery.models import Entry, EntrySource, EntryType

    entry = Entry(
        content="existing content",
        entry_type=EntryType.FEED,
        source=EntrySource.IMPORT,
        author="poller",
        metadata={"external_id": external_id} if external_id else {},
    )
    return SearchResult(entry=entry, score=score)


def _make_store(
    find_similar_results: list[SearchResult] | None = None,
    feed_sources: list[dict[str, object]] | None = None,
) -> AsyncMock:
    store = AsyncMock()
    store.find_similar.return_value = find_similar_results or []
    store.list_entries.return_value = []  # default: no external_id matches
    store.store.return_value = "new-entry-id"
    store.get_tag_vocabulary.return_value = {}  # default: empty vocabulary
    _sources = feed_sources or []

    async def _list_feed_sources() -> list[dict[str, object]]:
        return list(_sources)

    store.list_feed_sources = AsyncMock(side_effect=_list_feed_sources)
    return store


def _source_to_dict(source: FeedSourceConfig) -> dict[str, object]:
    """Convert a FeedSourceConfig to a dict matching store output."""
    return {
        "url": source.url,
        "source_type": source.source_type,
        "label": source.label,
        "poll_interval_minutes": source.poll_interval_minutes,
        "trust_weight": source.trust_weight,
    }


def _make_config(
    sources: list[FeedSourceConfig] | None = None,
    digest_threshold: float = 0.0,
    alert_threshold: float = 0.85,
) -> DistilleryConfig:
    cfg = DistilleryConfig()
    cfg.feeds = FeedsConfig(
        sources=sources or [],
        thresholds=FeedsThresholdsConfig(alert=alert_threshold, digest=digest_threshold),
    )
    return cfg


# ---------------------------------------------------------------------------
# RelevanceScorer
# ---------------------------------------------------------------------------


class TestRelevanceScorer:
    async def test_empty_text_returns_zero(self) -> None:
        store = _make_store()
        scorer = RelevanceScorer(store=store)
        score = await scorer.score("   ")
        assert score == 0.0
        store.find_similar.assert_not_called()

    async def test_returns_max_similarity(self) -> None:
        results = [
            _make_search_result(score=0.7),
            _make_search_result(score=0.9),
            _make_search_result(score=0.5),
        ]
        store = _make_store(find_similar_results=results)
        scorer = RelevanceScorer(store=store)
        score = await scorer.score("hello world")
        assert score == pytest.approx(0.9)

    async def test_no_results_returns_zero(self) -> None:
        store = _make_store(find_similar_results=[])
        scorer = RelevanceScorer(store=store)
        score = await scorer.score("hello world")
        assert score == 0.0

    async def test_passes_threshold_to_store(self) -> None:
        store = _make_store()
        scorer = RelevanceScorer(store=store, min_score=0.5)
        await scorer.score("test text")
        store.find_similar.assert_called_once()
        call_kwargs = store.find_similar.call_args.kwargs
        assert call_kwargs["threshold"] == 0.5

    async def test_exception_propagates(self) -> None:
        store = AsyncMock()
        store.find_similar.side_effect = RuntimeError("db error")
        scorer = RelevanceScorer(store=store)
        with pytest.raises(RuntimeError, match="db error"):
            await scorer.score("test text")

    async def test_single_result_returns_that_score(self) -> None:
        store = _make_store(find_similar_results=[_make_search_result(score=0.75)])
        scorer = RelevanceScorer(store=store)
        score = await scorer.score("test text")
        assert score == pytest.approx(0.75)


# ---------------------------------------------------------------------------
# _item_text
# ---------------------------------------------------------------------------


class TestItemText:
    def test_title_and_content(self) -> None:
        item = _make_feed_item(title="Title", content="Content")
        assert _item_text(item) == "Title\nContent"

    def test_title_only(self) -> None:
        item = _make_feed_item(title="Title", content=None)
        assert _item_text(item) == "Title"

    def test_content_only(self) -> None:
        item = _make_feed_item(title=None, content="Content")
        assert _item_text(item) == "Content"

    def test_both_none(self) -> None:
        item = _make_feed_item(title=None, content=None)
        assert _item_text(item) == ""


# ---------------------------------------------------------------------------
# FeedPoller.poll — empty sources
# ---------------------------------------------------------------------------


class TestFeedPollerEmptySources:
    async def test_empty_sources_returns_empty_summary(self) -> None:
        store = _make_store(feed_sources=[])
        cfg = _make_config(sources=[])
        poller = FeedPoller(store=store, config=cfg)
        summary = await poller.poll()
        assert summary.sources_polled == 0
        assert summary.total_fetched == 0
        assert summary.total_stored == 0
        assert summary.results == []


# ---------------------------------------------------------------------------
# FeedPoller.poll — with RSS adapter mocked
# ---------------------------------------------------------------------------


class TestFeedPollerRSS:
    def _rss_source(self) -> FeedSourceConfig:
        return FeedSourceConfig(
            url="https://example.com/rss",
            source_type="rss",
            trust_weight=1.0,
        )

    async def test_items_above_threshold_are_stored(self) -> None:
        items = [_make_feed_item(item_id="id1", title="Python news", content="Details")]
        src = self._rss_source()
        store = _make_store(
            find_similar_results=[_make_search_result(score=0.9)],
            feed_sources=[_source_to_dict(src)],
        )
        cfg = _make_config(sources=[src], digest_threshold=0.5)

        with patch("distillery.feeds.poller._build_adapter") as mock_build:
            mock_adapter = MagicMock()
            mock_adapter.fetch.return_value = items
            mock_build.return_value = mock_adapter

            poller = FeedPoller(store=store, config=cfg)
            # Override find_similar to return no dedup match on first call, then score
            call_count = 0

            async def _find_similar(content: str, threshold: float, limit: int) -> list:
                nonlocal call_count
                call_count += 1
                if threshold == 0.95:
                    return []  # no dedup match
                return [_make_search_result(score=0.9)]  # high relevance

            store.find_similar.side_effect = _find_similar
            summary = await poller.poll()

        assert summary.total_stored == 1
        assert summary.total_fetched == 1
        assert summary.sources_polled == 1

    async def test_items_below_threshold_not_stored(self) -> None:
        items = [_make_feed_item(item_id="id1", title="Irrelevant item", content="Unrelated")]
        src = self._rss_source()
        store = _make_store(feed_sources=[_source_to_dict(src)])
        cfg = _make_config(sources=[src], digest_threshold=0.8)

        with patch("distillery.feeds.poller._build_adapter") as mock_build:
            mock_adapter = MagicMock()
            mock_adapter.fetch.return_value = items
            mock_build.return_value = mock_adapter

            call_count = 0

            async def _find_similar(content: str, threshold: float, limit: int) -> list:
                nonlocal call_count
                call_count += 1
                if threshold == 0.95:
                    return []  # no dedup
                return [_make_search_result(score=0.3)]  # low relevance

            store.find_similar.side_effect = _find_similar
            poller = FeedPoller(store=store, config=cfg)
            summary = await poller.poll()

        assert summary.total_stored == 0
        assert summary.total_below_threshold == 1

    async def test_duplicate_items_are_skipped_via_external_id(self) -> None:
        """RSS sources use authoritative external_id dedup — _has_external_id match."""
        items = [_make_feed_item(item_id="id1", title="Dup title", content="Dup content")]
        src = self._rss_source()
        store = _make_store(feed_sources=[_source_to_dict(src)])
        cfg = _make_config(sources=[src], digest_threshold=0.0)

        # _has_external_id calls list_entries with metadata filter — return a match.
        from distillery.models import Entry, EntrySource, EntryType

        existing = Entry(
            content="existing",
            entry_type=EntryType.FEED,
            source=EntrySource.IMPORT,
            author="poller",
            metadata={"external_id": "id1"},
        )

        async def _list_entries(
            filters: dict[str, object] | None = None,
            limit: int = 10,
            offset: int = 0,
        ) -> list[object]:
            if filters and filters.get("metadata.external_id") == "id1":
                return [existing]
            return []

        store.list_entries.side_effect = _list_entries

        with patch("distillery.feeds.poller._build_adapter") as mock_build:
            mock_adapter = MagicMock()
            mock_adapter.fetch.return_value = items
            mock_build.return_value = mock_adapter

            poller = FeedPoller(store=store, config=cfg)
            summary = await poller.poll()

        assert summary.total_skipped_dedup == 1
        assert summary.total_stored == 0
        store.store.assert_not_called()

    async def test_external_id_lookup_failure_treated_as_duplicate(self) -> None:
        """Issue #414: ``_has_external_id`` failing must skip the item, not store it.

        When the shared DuckDB connection is in an aborted-transaction state
        (e.g. after a failed FTS rebuild), every ``list_entries`` call raises
        ``TransactionContext Error``.  Returning ``False`` from
        ``_has_external_id`` in that path silently disabled dedup and caused
        every item the previous cycle had stored to be re-stored as a
        duplicate.  The fix is fail-closed: treat lookup failure as a
        possible duplicate and skip storage for this cycle.
        """
        items = [_make_feed_item(item_id="id1", title="Dup", content="Body")]
        src = self._rss_source()
        store = _make_store(feed_sources=[_source_to_dict(src)])
        cfg = _make_config(sources=[src], digest_threshold=0.0)

        store.list_entries.side_effect = RuntimeError(
            "TransactionContext Error: Current transaction is aborted (please ROLLBACK)"
        )

        with patch("distillery.feeds.poller._build_adapter") as mock_build:
            mock_adapter = MagicMock()
            mock_adapter.fetch.return_value = items
            mock_build.return_value = mock_adapter

            poller = FeedPoller(store=store, config=cfg)
            summary = await poller.poll()

        assert summary.total_skipped_dedup == 1
        assert summary.total_stored == 0
        store.store.assert_not_called()

    async def test_adapter_fetch_error_recorded(self) -> None:
        src = self._rss_source()
        store = _make_store(feed_sources=[_source_to_dict(src)])
        cfg = _make_config(sources=[src])

        with patch("distillery.feeds.poller._build_adapter") as mock_build:
            mock_adapter = MagicMock()
            mock_adapter.fetch.side_effect = RuntimeError("network error")
            mock_build.return_value = mock_adapter

            poller = FeedPoller(store=store, config=cfg)
            summary = await poller.poll()

        assert summary.sources_errored == 1
        assert len(summary.results[0].errors) == 1
        assert "network error" in summary.results[0].errors[0]

    async def test_unsupported_source_type_records_error(self) -> None:
        source = FeedSourceConfig(
            url="https://webhooks.example.com",
            source_type="hackernews",
        )
        store = _make_store(feed_sources=[_source_to_dict(source)])
        cfg = _make_config(sources=[source])
        poller = FeedPoller(store=store, config=cfg)
        summary = await poller.poll()
        assert summary.sources_errored == 1
        assert summary.results[0].errors

    async def test_trust_weight_applied_to_score(self) -> None:
        """trust_weight=0.5 should halve the score, potentially dropping below threshold."""
        source = FeedSourceConfig(
            url="https://example.com/rss",
            source_type="rss",
            trust_weight=0.5,
        )
        items = [_make_feed_item(item_id="id1")]
        store = _make_store(feed_sources=[_source_to_dict(source)])
        cfg = _make_config(sources=[source], digest_threshold=0.8)

        with patch("distillery.feeds.poller._build_adapter") as mock_build:
            mock_adapter = MagicMock()
            mock_adapter.fetch.return_value = items
            mock_build.return_value = mock_adapter

            async def _find_similar(content: str, threshold: float, limit: int) -> list:
                if threshold == 0.95:
                    return []
                # Raw score 0.9 * trust_weight 0.5 = 0.45 — below 0.8 threshold
                return [_make_search_result(score=0.9)]

            store.find_similar.side_effect = _find_similar
            poller = FeedPoller(store=store, config=cfg)
            summary = await poller.poll()

        assert summary.total_below_threshold == 1
        assert summary.total_stored == 0

    async def test_item_with_no_text_skipped(self) -> None:
        items = [_make_feed_item(title=None, content=None)]
        src = self._rss_source()
        store = _make_store(feed_sources=[_source_to_dict(src)])
        cfg = _make_config(sources=[src], digest_threshold=0.0)

        with patch("distillery.feeds.poller._build_adapter") as mock_build:
            mock_adapter = MagicMock()
            mock_adapter.fetch.return_value = items
            mock_build.return_value = mock_adapter

            poller = FeedPoller(store=store, config=cfg)
            summary = await poller.poll()

        assert summary.total_stored == 0
        assert summary.total_below_threshold == 1


# ---------------------------------------------------------------------------
# FeedPoller.poll — alert threshold (issue #472)
# ---------------------------------------------------------------------------


class TestFeedPollerAlertThreshold:
    """Two-tier threshold: items >= alert get metadata.is_alert=True;
    items in [digest, alert) are stored without the alert flag.

    Regression test for issue #472: FeedPoller previously read only the digest
    threshold and ignored ``feeds.thresholds.alert`` entirely.
    """

    def _rss_source(self) -> FeedSourceConfig:
        return FeedSourceConfig(
            url="https://example.com/rss",
            source_type="rss",
            trust_weight=1.0,
        )

    async def test_init_reads_alert_threshold_from_config(self) -> None:
        store = _make_store()
        cfg = _make_config(digest_threshold=0.4, alert_threshold=0.9)
        poller = FeedPoller(store=store, config=cfg)
        assert poller._alert_threshold == pytest.approx(0.9)
        assert poller._threshold == pytest.approx(0.4)

    async def test_item_at_or_above_alert_threshold_flagged(self) -> None:
        items = [_make_feed_item(item_id="alert-1", title="Critical", content="Hot news")]
        src = self._rss_source()
        store = _make_store(feed_sources=[_source_to_dict(src)])
        cfg = _make_config(sources=[src], digest_threshold=0.5, alert_threshold=0.85)

        with patch("distillery.feeds.poller._build_adapter") as mock_build:
            mock_adapter = MagicMock()
            mock_adapter.fetch.return_value = items
            mock_build.return_value = mock_adapter

            async def _find_similar(content: str, threshold: float, limit: int) -> list:
                if threshold == 0.95:
                    return []  # no dedup match
                return [_make_search_result(score=0.9)]  # >= alert (0.85)

            store.find_similar.side_effect = _find_similar
            poller = FeedPoller(store=store, config=cfg)
            summary = await poller.poll()

        assert summary.total_stored == 1
        # Inspect the Entry passed to store.store()
        store.store.assert_awaited_once()
        stored_entry = store.store.await_args.args[0]
        assert stored_entry.metadata.get("is_alert") is True

    async def test_item_in_digest_band_not_flagged_as_alert(self) -> None:
        items = [_make_feed_item(item_id="digest-1", title="Mild", content="Lukewarm")]
        src = self._rss_source()
        store = _make_store(feed_sources=[_source_to_dict(src)])
        cfg = _make_config(sources=[src], digest_threshold=0.5, alert_threshold=0.85)

        with patch("distillery.feeds.poller._build_adapter") as mock_build:
            mock_adapter = MagicMock()
            mock_adapter.fetch.return_value = items
            mock_build.return_value = mock_adapter

            async def _find_similar(content: str, threshold: float, limit: int) -> list:
                if threshold == 0.95:
                    return []
                # 0.7 is in the [digest=0.5, alert=0.85) band — stored,
                # but must NOT be flagged as alert.
                return [_make_search_result(score=0.7)]

            store.find_similar.side_effect = _find_similar
            poller = FeedPoller(store=store, config=cfg)
            summary = await poller.poll()

        assert summary.total_stored == 1
        store.store.assert_awaited_once()
        stored_entry = store.store.await_args.args[0]
        assert "is_alert" not in stored_entry.metadata or stored_entry.metadata["is_alert"] is False

    async def test_alert_threshold_respects_trust_weight(self) -> None:
        """adjusted_score = score * trust_weight is what gets compared, not raw score."""
        source = FeedSourceConfig(
            url="https://example.com/rss",
            source_type="rss",
            trust_weight=0.5,
        )
        items = [_make_feed_item(item_id="tw-1")]
        store = _make_store(feed_sources=[_source_to_dict(source)])
        # digest=0.3 lets it through; alert=0.85 — raw 0.9 * 0.5 = 0.45 < 0.85.
        cfg = _make_config(sources=[source], digest_threshold=0.3, alert_threshold=0.85)

        with patch("distillery.feeds.poller._build_adapter") as mock_build:
            mock_adapter = MagicMock()
            mock_adapter.fetch.return_value = items
            mock_build.return_value = mock_adapter

            async def _find_similar(content: str, threshold: float, limit: int) -> list:
                if threshold == 0.95:
                    return []
                return [_make_search_result(score=0.9)]

            store.find_similar.side_effect = _find_similar
            poller = FeedPoller(store=store, config=cfg)
            summary = await poller.poll()

        assert summary.total_stored == 1
        stored_entry = store.store.await_args.args[0]
        assert "is_alert" not in stored_entry.metadata or stored_entry.metadata["is_alert"] is False


# ---------------------------------------------------------------------------
# FeedPoller.poll — multiple sources
# ---------------------------------------------------------------------------


class TestFeedPollerMultipleSources:
    async def test_aggregates_across_sources(self) -> None:
        sources = [
            FeedSourceConfig(url="https://a.com/rss", source_type="rss"),
            FeedSourceConfig(url="https://b.com/rss", source_type="rss"),
        ]
        items_a = [_make_feed_item(item_id="a1", source_url="https://a.com/rss")]
        items_b = [
            _make_feed_item(item_id="b1", source_url="https://b.com/rss"),
            _make_feed_item(item_id="b2", source_url="https://b.com/rss"),
        ]

        store = AsyncMock()
        store.store.return_value = "eid"
        store.list_entries.return_value = []  # no external_id matches
        store.list_feed_sources = AsyncMock(return_value=[_source_to_dict(s) for s in sources])

        source_items_map = {
            "https://a.com/rss": items_a,
            "https://b.com/rss": items_b,
        }
        cfg = _make_config(sources=sources, digest_threshold=0.0)

        def _build_adapter_side_effect(source: FeedSourceConfig, **_kwargs: object) -> MagicMock:
            mock = MagicMock()
            mock.fetch.return_value = source_items_map[source.url]
            return mock

        async def _find_similar(content: str, threshold: float, limit: int) -> list:
            if threshold == 0.95:
                return []
            return [_make_search_result(score=0.8)]

        store.find_similar.side_effect = _find_similar

        with patch(
            "distillery.feeds.poller._build_adapter", side_effect=_build_adapter_side_effect
        ):
            poller = FeedPoller(store=store, config=cfg)
            summary = await poller.poll()

        assert summary.sources_polled == 2
        assert summary.total_fetched == 3
        assert summary.total_stored == 3
        assert len(summary.results) == 2


# ---------------------------------------------------------------------------
# Parallel source polling
# ---------------------------------------------------------------------------


class TestFeedPollerParallel:
    async def test_sources_polled_concurrently(self) -> None:
        """Verify that _poll_source is called for all sources via asyncio.gather."""
        sources = [
            FeedSourceConfig(url="https://a.com/rss", source_type="rss"),
            FeedSourceConfig(url="https://b.com/rss", source_type="rss"),
        ]
        items_a = [_make_feed_item(item_id="a1", source_url="https://a.com/rss")]
        items_b = [_make_feed_item(item_id="b1", source_url="https://b.com/rss")]

        store = _make_store(feed_sources=[_source_to_dict(s) for s in sources])

        source_items_map = {
            "https://a.com/rss": items_a,
            "https://b.com/rss": items_b,
        }
        cfg = _make_config(sources=sources, digest_threshold=0.0)

        def _build_adapter_side_effect(source: FeedSourceConfig, **_kwargs: object) -> MagicMock:
            mock = MagicMock()
            mock.fetch.return_value = source_items_map[source.url]
            return mock

        async def _find_similar(content: str, threshold: float, limit: int) -> list:
            return [_make_search_result(score=0.8)]

        store.find_similar.side_effect = _find_similar

        with patch(
            "distillery.feeds.poller._build_adapter", side_effect=_build_adapter_side_effect
        ):
            poller = FeedPoller(store=store, config=cfg)
            summary = await poller.poll()

        assert summary.sources_polled == 2
        assert summary.total_fetched == 2
        assert summary.total_stored == 2

    async def test_one_source_error_does_not_block_others(self) -> None:
        """If one source's adapter fails, other sources still complete."""
        sources = [
            FeedSourceConfig(url="https://good.com/rss", source_type="rss"),
            FeedSourceConfig(url="https://bad.com/rss", source_type="rss"),
        ]
        store = _make_store(feed_sources=[_source_to_dict(s) for s in sources])

        cfg = _make_config(sources=sources, digest_threshold=0.0)

        def _build_adapter_side_effect(source: FeedSourceConfig, **_kwargs: object) -> MagicMock:
            mock = MagicMock()
            if source.url == "https://bad.com/rss":
                mock.fetch.side_effect = RuntimeError("network error")
            else:
                mock.fetch.return_value = [
                    _make_feed_item(item_id="g1", source_url="https://good.com/rss")
                ]
            return mock

        async def _find_similar(content: str, threshold: float, limit: int) -> list:
            return [_make_search_result(score=0.8)]

        store.find_similar.side_effect = _find_similar

        with patch(
            "distillery.feeds.poller._build_adapter", side_effect=_build_adapter_side_effect
        ):
            poller = FeedPoller(store=store, config=cfg)
            summary = await poller.poll()

        assert summary.sources_polled == 2
        assert summary.sources_errored == 1
        assert summary.total_stored == 1


# ---------------------------------------------------------------------------
# Authoritative external_id dedup skip
# ---------------------------------------------------------------------------


class TestAuthoritativeExternalIdSkip:
    async def test_rss_skips_semantic_dedup(self) -> None:
        """RSS sources skip _is_duplicate (find_similar with 0.95 threshold)."""
        items = [_make_feed_item(item_id="new1", title="New item", content="Content")]
        src = FeedSourceConfig(url="https://example.com/rss", source_type="rss")
        store = _make_store(feed_sources=[_source_to_dict(src)])
        cfg = _make_config(sources=[src], digest_threshold=0.0)

        find_similar_thresholds: list[float] = []

        async def _find_similar(content: str, threshold: float, limit: int) -> list:
            find_similar_thresholds.append(threshold)
            return [_make_search_result(score=0.8)]

        store.find_similar.side_effect = _find_similar

        with patch("distillery.feeds.poller._build_adapter") as mock_build:
            mock_adapter = MagicMock()
            mock_adapter.fetch.return_value = items
            mock_build.return_value = mock_adapter

            poller = FeedPoller(store=store, config=cfg)
            summary = await poller.poll()

        # find_similar should only be called for scoring (threshold 0.0),
        # never for dedup (threshold 0.95) since RSS is authoritative.
        assert all(t != 0.95 for t in find_similar_thresholds), (
            f"Unexpected dedup find_similar call; thresholds seen: {find_similar_thresholds}"
        )
        assert summary.total_stored == 1

    async def test_non_authoritative_source_still_runs_semantic_dedup(self) -> None:
        """A source type not in _AUTHORITATIVE_EXTERNAL_ID_TYPES still runs semantic dedup."""
        items = [_make_feed_item(item_id="new1", title="New item", content="Content")]
        src = FeedSourceConfig(url="https://example.com/feed", source_type="hackernews")
        store = _make_store(feed_sources=[_source_to_dict(src)])
        cfg = _make_config(sources=[src], digest_threshold=0.0)

        find_similar_thresholds: list[float] = []

        async def _find_similar(content: str, threshold: float, limit: int) -> list:
            find_similar_thresholds.append(threshold)
            if threshold == 0.95:
                return []  # no dedup match
            return [_make_search_result(score=0.8)]

        store.find_similar.side_effect = _find_similar

        # Need to patch _build_adapter to handle 'hackernews' type
        with patch("distillery.feeds.poller._build_adapter") as mock_build:
            mock_adapter = MagicMock()
            mock_adapter.fetch.return_value = items
            mock_build.return_value = mock_adapter

            poller = FeedPoller(store=store, config=cfg)
            summary = await poller.poll()

        # Should have called find_similar with 0.95 for dedup
        assert 0.95 in find_similar_thresholds, (
            f"Expected dedup find_similar call; thresholds seen: {find_similar_thresholds}"
        )
        assert summary.total_stored == 1


# ---------------------------------------------------------------------------
# _handle_poll
# ---------------------------------------------------------------------------


class TestHandlePoll:
    async def test_no_sources_returns_empty_summary(self) -> None:
        from distillery.mcp.server import _handle_poll

        store = _make_store()
        cfg = _make_config(sources=[])
        result = await _handle_poll(store=store, config=cfg, arguments={})
        data = json.loads(result[0].text)
        assert data["sources_polled"] == 0
        assert data["total_stored"] == 0

    async def test_source_url_filter_not_found_returns_error(self) -> None:
        from distillery.mcp.server import _handle_poll

        src = FeedSourceConfig(url="https://real.com/rss", source_type="rss")
        store = _make_store(feed_sources=[_source_to_dict(src)])
        cfg = _make_config(sources=[src])
        result = await _handle_poll(
            store=store, config=cfg, arguments={"source_url": "https://nonexistent.com/rss"}
        )
        data = json.loads(result[0].text)
        assert data.get("error") is True
        assert data["code"] == "NOT_FOUND"

    async def test_source_url_filter_narrows_poll(self) -> None:
        from distillery.mcp.server import _handle_poll

        sources = [
            FeedSourceConfig(url="https://a.com/rss", source_type="rss"),
            FeedSourceConfig(url="https://b.com/rss", source_type="rss"),
        ]
        cfg = _make_config(sources=sources, digest_threshold=0.0)
        store = _make_store(feed_sources=[_source_to_dict(s) for s in sources])

        items = [_make_feed_item(item_id="x1", source_url="https://a.com/rss")]

        async def _find_similar(content: str, threshold: float, limit: int) -> list:
            if threshold == 0.95:
                return []
            return [_make_search_result(score=0.9)]

        store.find_similar.side_effect = _find_similar

        with patch("distillery.feeds.poller._build_adapter") as mock_build:
            mock_adapter = MagicMock()
            mock_adapter.fetch.return_value = items
            mock_build.return_value = mock_adapter

            result = await _handle_poll(
                store=store, config=cfg, arguments={"source_url": "https://a.com/rss"}
            )

        data = json.loads(result[0].text)
        assert data["sources_polled"] == 1
        assert data["total_fetched"] == 1

    async def test_returns_all_expected_fields(self) -> None:
        from distillery.mcp.server import _handle_poll

        cfg = _make_config(sources=[])
        store = _make_store()
        result = await _handle_poll(store=store, config=cfg, arguments={})
        data = json.loads(result[0].text)
        for key in (
            "sources_polled",
            "sources_errored",
            "total_fetched",
            "total_stored",
            "total_skipped_dedup",
            "total_below_threshold",
            "results",
            "started_at",
            "finished_at",
        ):
            assert key in data, f"Missing key: {key}"


# ---------------------------------------------------------------------------
# CLI poll subcommand
# ---------------------------------------------------------------------------


class TestCLIPollSubcommand:
    def test_no_sources_exits_zero(self) -> None:
        from distillery.cli import _cmd_poll

        with (
            patch("distillery.cli.load_config") as mock_load,
            patch("distillery.cli.asyncio") as mock_asyncio,
        ):
            cfg = _make_config(sources=[])
            mock_load.return_value = cfg
            mock_asyncio.run.return_value = "no-sources"
            code = _cmd_poll(config_path=None, fmt="text", source_url=None)
            assert code == 0

    def test_source_not_found_exits_one(self) -> None:
        from distillery.cli import _cmd_poll

        with (
            patch("distillery.cli.load_config") as mock_load,
            patch("distillery.cli.asyncio") as mock_asyncio,
        ):
            cfg = _make_config(
                sources=[FeedSourceConfig(url="https://real.com/rss", source_type="rss")]
            )
            mock_load.return_value = cfg
            mock_asyncio.run.return_value = "not-found:https://nonexistent.com/rss"
            code = _cmd_poll(config_path=None, fmt="text", source_url="https://nonexistent.com/rss")
            assert code == 1

    def test_poll_runs_and_exits_zero_on_no_errors(self) -> None:
        from distillery.cli import main

        with patch("distillery.cli._cmd_poll", return_value=0):
            with pytest.raises(SystemExit) as exc_info:
                main(["poll"])
            assert exc_info.value.code == 0

    def test_poll_json_format_accepted(self) -> None:
        from distillery.cli import _build_parser

        parser = _build_parser()
        args = parser.parse_args(["poll", "--format", "json"])
        assert args.format == "json"
        assert args.command == "poll"

    def test_poll_source_flag(self) -> None:
        from distillery.cli import _build_parser

        parser = _build_parser()
        args = parser.parse_args(["poll", "--source", "https://example.com/rss"])
        assert args.source == "https://example.com/rss"


# ---------------------------------------------------------------------------
# _build_adapter — GitHub token passthrough
# ---------------------------------------------------------------------------


class TestBuildAdapterGitHubToken:
    """_build_adapter() passes GITHUB_TOKEN to GitHubAdapter when set."""

    def test_passes_token_from_env_to_github_adapter(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from distillery.feeds.poller import _build_adapter

        monkeypatch.setenv("GITHUB_TOKEN", "ghp_testtoken123")
        src = FeedSourceConfig(url="https://github.com/owner/repo", source_type="github")
        adapter = _build_adapter(src)
        assert adapter._token == "ghp_testtoken123"  # noqa: SLF001

    def test_no_token_in_env_gives_empty_token(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from distillery.feeds.poller import _build_adapter

        monkeypatch.delenv("GITHUB_TOKEN", raising=False)
        src = FeedSourceConfig(url="https://github.com/owner/repo", source_type="github")
        adapter = _build_adapter(src)
        # Adapter should still be created; token is empty/falsy
        assert not adapter._token  # noqa: SLF001

    def test_token_not_logged_at_debug(
        self, monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture
    ) -> None:
        import logging

        from distillery.feeds.poller import _build_adapter

        monkeypatch.setenv("GITHUB_TOKEN", "ghp_secrettoken9999")
        src = FeedSourceConfig(url="https://github.com/owner/repo", source_type="github")
        with caplog.at_level(logging.DEBUG, logger="distillery.feeds.poller"):
            _build_adapter(src)
        for record in caplog.records:
            assert "ghp_secrettoken9999" not in record.getMessage(), (
                "Raw token must not appear in log output"
            )


# ---------------------------------------------------------------------------
# FeedPoller._persist_poll_status — persists liveness metadata per poll
# ---------------------------------------------------------------------------


class TestPersistPollStatus:
    async def test_records_successful_poll_on_store(self) -> None:
        """After poll() the store receives record_poll_status with success details."""
        items = [_make_feed_item(item_id="id1", title="Test", content="Body")]
        src = FeedSourceConfig(url="https://example.com/rss", source_type="rss")
        store = _make_store(feed_sources=[_source_to_dict(src)])
        cfg = _make_config(sources=[src], digest_threshold=0.0)

        with patch("distillery.feeds.poller._build_adapter") as mock_build:
            mock_adapter = MagicMock()
            mock_adapter.fetch.return_value = items
            mock_build.return_value = mock_adapter

            async def _find_similar(content: str, threshold: float, limit: int) -> list:
                if threshold == 0.95:
                    return []
                return [_make_search_result(score=0.9)]

            store.find_similar.side_effect = _find_similar
            poller = FeedPoller(store=store, config=cfg)
            await poller.poll()

        store.record_poll_status.assert_called_once()
        call = store.record_poll_status.call_args
        assert call.args[0] == "https://example.com/rss"
        assert call.kwargs["item_count"] == 1
        assert call.kwargs["error"] is None

    async def test_records_error_on_adapter_failure(self) -> None:
        """A fetch failure is persisted via record_poll_status with the error string."""
        src = FeedSourceConfig(url="https://example.com/rss", source_type="rss")
        store = _make_store(feed_sources=[_source_to_dict(src)])
        cfg = _make_config(sources=[src])

        with patch("distillery.feeds.poller._build_adapter") as mock_build:
            mock_adapter = MagicMock()
            mock_adapter.fetch.side_effect = RuntimeError("network error")
            mock_build.return_value = mock_adapter

            poller = FeedPoller(store=store, config=cfg)
            await poller.poll()

        store.record_poll_status.assert_called_once()
        call = store.record_poll_status.call_args
        assert call.args[0] == "https://example.com/rss"
        assert call.kwargs["item_count"] == 0
        assert call.kwargs["error"] is not None
        assert "network error" in call.kwargs["error"]

    async def test_persist_failure_is_swallowed(self) -> None:
        """A failing record_poll_status does not break the poll cycle."""
        src = FeedSourceConfig(url="https://example.com/rss", source_type="rss")
        store = _make_store(feed_sources=[_source_to_dict(src)])
        store.record_poll_status.side_effect = RuntimeError("DB unreachable")
        cfg = _make_config(sources=[src], digest_threshold=0.0)

        with patch("distillery.feeds.poller._build_adapter") as mock_build:
            mock_adapter = MagicMock()
            mock_adapter.fetch.return_value = []
            mock_build.return_value = mock_adapter

            poller = FeedPoller(store=store, config=cfg)
            summary = await poller.poll()

        # Poll returned a normal summary despite the persistence failure.
        assert summary.sources_polled == 1

    async def test_missing_recorder_method_is_ignored(self) -> None:
        """Stores predating the protocol addition (no record_poll_status) don't crash."""
        src = FeedSourceConfig(url="https://example.com/rss", source_type="rss")
        # Use MagicMock (not AsyncMock) so getattr(store, "record_poll_status", None)
        # returns the default None for missing attrs.  spec limits attribute access.
        store = MagicMock(
            spec=[
                "find_similar",
                "list_entries",
                "store",
                "list_feed_sources",
                "get_tag_vocabulary",
            ]
        )
        store.find_similar = AsyncMock(return_value=[])
        store.list_entries = AsyncMock(return_value=[])
        store.store = AsyncMock(return_value="eid")
        store.list_feed_sources = AsyncMock(return_value=[_source_to_dict(src)])
        store.get_tag_vocabulary = AsyncMock(return_value={})
        cfg = _make_config(sources=[src], digest_threshold=0.0)

        with patch("distillery.feeds.poller._build_adapter") as mock_build:
            mock_adapter = MagicMock()
            mock_adapter.fetch.return_value = []
            mock_build.return_value = mock_adapter

            poller = FeedPoller(store=store, config=cfg)
            summary = await poller.poll()

        assert summary.sources_polled == 1


class TestPersistOnPartialCycle:
    """Issue #404: per-source liveness must be persisted even when the
    surrounding poll cycle does not run to completion (e.g. the webhook
    background task is cancelled mid-gather, an unhandled exception
    escapes the inner work, or only the inner ``_do_poll_source`` call
    finishes for a single source).

    These tests guard the ``try/finally`` placement inside
    ``FeedPoller._poll_source`` — moving the persist back to a
    post-``gather`` loop in ``poll()`` (the pre-#404 behaviour) would
    regress all of these.
    """

    async def test_persist_runs_even_when_inner_raises(self) -> None:
        """An unhandled exception inside the per-item loop must not bypass
        the ``finally``-clause persist of liveness.
        """
        src = FeedSourceConfig(url="https://example.com/rss", source_type="rss")
        store = _make_store(feed_sources=[_source_to_dict(src)])
        cfg = _make_config(sources=[src], digest_threshold=0.0)

        # Force the inner ``_do_poll_source`` to raise after the adapter
        # has fetched items but before the post-gather loop would run.
        # ``_has_external_id`` is awaited deep in the per-item loop, so
        # raising there exercises the ``finally`` path under realistic
        # ordering.
        items = [_make_feed_item(item_id="id1", title="T", content="B")]

        with patch("distillery.feeds.poller._build_adapter") as mock_build:
            mock_adapter = MagicMock()
            mock_adapter.fetch.return_value = items
            mock_build.return_value = mock_adapter

            poller = FeedPoller(store=store, config=cfg)

            async def _boom(_item_id: str) -> bool:
                raise RuntimeError("boom")

            with patch.object(poller, "_has_external_id", side_effect=_boom):
                # The exception escapes _poll_source and surfaces as a
                # gather() result; ``poll()`` wraps it as an err_result.
                summary = await poller.poll()

        # Exactly one persist — from ``_poll_source``'s ``finally`` —
        # plus one more from the err_result branch in ``poll()`` for the
        # excepted gather entry.  Both target the same URL.
        urls = [c.args[0] for c in store.record_poll_status.call_args_list]
        assert "https://example.com/rss" in urls
        # The summary records the source as polled+errored (via err_result).
        assert summary.sources_polled == 1
        assert summary.sources_errored == 1

    async def test_persist_runs_when_inner_call_cancelled(self) -> None:
        """If a per-item await inside ``_do_poll_source`` is cancelled
        (simulating a host kill mid-fetch), the ``finally`` clause in
        ``_poll_source`` still persists liveness — protected from a
        cascading cancellation by ``asyncio.shield`` on the persist call.

        This is the production failure mode in issue #404: the webhook
        background task is cancelled by the host between item-store and
        the post-gather loop, leaving ``last_polled_at`` stuck at its
        prior value.  Without the ``finally`` + ``shield`` belt-and-
        braces in ``_poll_source``, the persist call never reaches the
        store.
        """
        import asyncio

        src = FeedSourceConfig(url="https://example.com/rss", source_type="rss")
        store = _make_store(feed_sources=[_source_to_dict(src)])
        cfg = _make_config(sources=[src], digest_threshold=0.0)

        # Have ``_has_external_id`` raise CancelledError on first call to
        # simulate a host-driven cancellation reaching the per-item loop
        # while the surrounding task is still otherwise valid.  This
        # avoids the more complex full-task-cancel scenario whose pytest
        # cleanup races the shielded persist task.
        items = [_make_feed_item(item_id="id1", title="T", content="B")]

        with patch("distillery.feeds.poller._build_adapter") as mock_build:
            mock_adapter = MagicMock()
            mock_adapter.fetch.return_value = items
            mock_build.return_value = mock_adapter

            poller = FeedPoller(store=store, config=cfg)

            async def _cancel(_item_id: str) -> bool:
                raise asyncio.CancelledError("simulated host cancel")

            with patch.object(poller, "_has_external_id", side_effect=_cancel):
                # The CancelledError escapes _poll_source.  ``poll()``
                # surfaces it as an err_result via ``return_exceptions=True``
                # to gather, but the ``finally`` clause inside
                # ``_poll_source`` runs first and records liveness.
                summary = await poller.poll()

        urls = [c.args[0] for c in store.record_poll_status.call_args_list]
        assert "https://example.com/rss" in urls, (
            "last_polled_at must be persisted even when the per-item loop "
            "is cancelled mid-flight (#404)"
        )
        # gather's err_result branch ALSO calls _persist_poll_status, so
        # we accept >=1 calls.  The important guarantee is that AT LEAST
        # one persist made it to the store before the cycle terminated.
        assert summary.sources_polled == 1


class TestLastPolledAtAdvancesPerSource:
    """Issue #404 regression: ``feed_sources.last_polled_at`` must be
    written by every successful per-source poll so that
    ``distillery_status.last_feed_poll.last_poll_at`` and
    ``distillery_watch(action='list').next_poll_at`` advance even when
    the surrounding webhook background task does not reach its audit
    write (e.g. host auto-stop after returning 202).
    """

    async def test_real_store_last_polled_at_updates(self) -> None:
        """End-to-end: a real DuckDBStore observes ``last_polled_at``
        advance on every poll.
        """
        from datetime import UTC, datetime

        from distillery.embedding.protocol import EmbeddingProvider
        from distillery.store.duckdb import DuckDBStore

        class _StubEmbedding:
            model_name = "stub"
            dimensions = 4

            async def embed(self, text: str) -> list[float]:
                return [0.1, 0.1, 0.1, 0.1]

            async def embed_batch(self, texts: list[str]) -> list[list[float]]:
                return [[0.1, 0.1, 0.1, 0.1] for _ in texts]

        embedder: EmbeddingProvider = _StubEmbedding()  # type: ignore[assignment]
        store = DuckDBStore(db_path=":memory:", embedding_provider=embedder)
        await store.initialize()
        try:
            await store.add_feed_source(
                url="https://example.com/rss",
                source_type="rss",
                poll_interval_minutes=60,
            )

            t0 = datetime.now(tz=UTC)

            cfg = _make_config(
                sources=[FeedSourceConfig(url="https://example.com/rss", source_type="rss")],
                digest_threshold=0.0,
            )
            with patch("distillery.feeds.poller._build_adapter") as mock_build:
                mock_adapter = MagicMock()
                mock_adapter.fetch.return_value = []
                mock_build.return_value = mock_adapter

                poller = FeedPoller(store=store, config=cfg)
                await poller.poll()

            sources = await store.list_feed_sources()
            assert len(sources) == 1
            ts_iso = sources[0]["last_polled_at"]
            assert isinstance(ts_iso, str), (
                "last_polled_at must be set after a successful poll cycle (#404)"
            )
            ts = datetime.fromisoformat(ts_iso)
            assert ts >= t0, f"last_polled_at {ts!r} should be >= t0 {t0!r}"

            # next_poll_at is derived from last_polled_at + interval and
            # should also be non-null now.
            assert sources[0]["next_poll_at"] is not None
        finally:
            await store.close()


# ---------------------------------------------------------------------------
# Reader enrichment integration (#403)
# ---------------------------------------------------------------------------


class _FakeReader:
    """Minimal reader stub used to assert poller wiring without httpx."""

    def __init__(self, responses: dict[str, str | None]) -> None:
        self.responses = responses
        self.calls: list[str] = []

    async def fetch(self, url: str) -> str | None:
        self.calls.append(url)
        return self.responses.get(url)


def _rss_source(url: str = "https://example.com/rss") -> FeedSourceConfig:
    return FeedSourceConfig(url=url, source_type="rss", trust_weight=1.0)


def _github_source(url: str = "https://github.com/foo/bar") -> FeedSourceConfig:
    return FeedSourceConfig(url=url, source_type="github", trust_weight=1.0)


def _make_reader_config(
    sources: list[FeedSourceConfig],
    *,
    enabled: bool = True,
    min_content_chars: int = 500,
    digest_threshold: float = 0.0,
) -> DistilleryConfig:
    from distillery.config import ReaderConfig

    cfg = DistilleryConfig()
    cfg.feeds = FeedsConfig(
        sources=sources,
        thresholds=FeedsThresholdsConfig(alert=0.85, digest=digest_threshold),
        reader=ReaderConfig(enabled=enabled, min_content_chars=min_content_chars),
    )
    return cfg


class TestReaderEnrichment:
    async def test_short_rss_item_is_enriched(self) -> None:
        item = _make_feed_item(
            item_id="id1",
            title="Short blurb",
            content="too short",
        )
        item.url = "https://example.com/article"
        src = _rss_source()
        cfg = _make_reader_config([src], min_content_chars=500)
        store = _make_store(feed_sources=[_source_to_dict(src)])

        async def _find_similar(content: str, threshold: float, limit: int) -> list:
            if threshold == 0.95:
                return []  # not a duplicate
            return [_make_search_result(score=0.9)]

        store.find_similar.side_effect = _find_similar

        reader = _FakeReader({"https://example.com/article": "# Full article body"})

        with patch("distillery.feeds.poller._build_adapter") as mock_build:
            mock_adapter = MagicMock()
            mock_adapter.fetch.return_value = [item]
            mock_build.return_value = mock_adapter

            poller = FeedPoller(store=store, config=cfg, reader=reader)  # type: ignore[arg-type]
            summary = await poller.poll()

        assert summary.total_items_enriched == 1
        assert summary.total_enrichment_errors == 0
        assert summary.total_stored == 1
        assert reader.calls == ["https://example.com/article"]
        # The store call should have received the enriched content + metadata.
        stored_entry = store.store.call_args.args[0]
        assert "Full article body" in stored_entry.content
        assert stored_entry.metadata["original_content"] == "too short"
        assert stored_entry.metadata["enriched_by"] == "jina-reader"
        assert "enriched_at" in stored_entry.metadata

    async def test_long_rss_item_is_not_enriched(self) -> None:
        long_content = "x" * 600
        item = _make_feed_item(item_id="id1", title="Long item", content=long_content)
        item.url = "https://example.com/article"
        src = _rss_source()
        cfg = _make_reader_config([src], min_content_chars=500)
        store = _make_store(feed_sources=[_source_to_dict(src)])

        async def _find_similar(content: str, threshold: float, limit: int) -> list:
            if threshold == 0.95:
                return []
            return [_make_search_result(score=0.9)]

        store.find_similar.side_effect = _find_similar

        reader = _FakeReader({})

        with patch("distillery.feeds.poller._build_adapter") as mock_build:
            mock_adapter = MagicMock()
            mock_adapter.fetch.return_value = [item]
            mock_build.return_value = mock_adapter

            poller = FeedPoller(store=store, config=cfg, reader=reader)  # type: ignore[arg-type]
            summary = await poller.poll()

        assert summary.total_items_enriched == 0
        assert summary.total_enrichment_errors == 0
        assert summary.total_stored == 1
        assert reader.calls == []
        stored_entry = store.store.call_args.args[0]
        # Original content is preserved as-is — no enrichment metadata.
        assert "original_content" not in stored_entry.metadata
        assert "enriched_by" not in stored_entry.metadata

    async def test_reader_failure_falls_back_to_original_content(self) -> None:
        item = _make_feed_item(item_id="id1", title="Short", content="short")
        item.url = "https://example.com/article"
        src = _rss_source()
        cfg = _make_reader_config([src], min_content_chars=500)
        store = _make_store(feed_sources=[_source_to_dict(src)])

        async def _find_similar(content: str, threshold: float, limit: int) -> list:
            if threshold == 0.95:
                return []
            return [_make_search_result(score=0.9)]

        store.find_similar.side_effect = _find_similar

        # Reader returns None — simulating a failure.
        reader = _FakeReader({"https://example.com/article": None})

        with patch("distillery.feeds.poller._build_adapter") as mock_build:
            mock_adapter = MagicMock()
            mock_adapter.fetch.return_value = [item]
            mock_build.return_value = mock_adapter

            poller = FeedPoller(store=store, config=cfg, reader=reader)  # type: ignore[arg-type]
            summary = await poller.poll()

        assert summary.total_items_enriched == 0
        assert summary.total_enrichment_errors == 1
        # Item is still stored using the fallback original content.
        assert summary.total_stored == 1
        stored_entry = store.store.call_args.args[0]
        assert "short" in stored_entry.content
        assert "original_content" not in stored_entry.metadata

    async def test_github_source_is_never_enriched(self) -> None:
        item = _make_feed_item(
            item_id="evt1",
            source_type="github",
            source_url="https://github.com/foo/bar",
            title="PR opened",
            content="short",
        )
        item.url = "https://github.com/foo/bar/pull/1"
        src = _github_source()
        cfg = _make_reader_config([src], min_content_chars=500)
        store = _make_store(feed_sources=[_source_to_dict(src)])

        async def _find_similar(content: str, threshold: float, limit: int) -> list:
            if threshold == 0.95:
                return []
            return [_make_search_result(score=0.9)]

        store.find_similar.side_effect = _find_similar

        reader = _FakeReader({"https://github.com/foo/bar/pull/1": "should not be used"})

        with patch("distillery.feeds.poller._build_adapter") as mock_build:
            mock_adapter = MagicMock()
            mock_adapter.fetch.return_value = [item]
            mock_build.return_value = mock_adapter

            poller = FeedPoller(store=store, config=cfg, reader=reader)  # type: ignore[arg-type]
            summary = await poller.poll()

        assert summary.total_items_enriched == 0
        assert reader.calls == []  # never invoked for non-RSS sources

    async def test_reader_disabled_when_client_is_none(self) -> None:
        item = _make_feed_item(item_id="id1", title="Short", content="short")
        item.url = "https://example.com/article"
        src = _rss_source()
        cfg = _make_reader_config([src], enabled=False, min_content_chars=500)
        store = _make_store(feed_sources=[_source_to_dict(src)])

        async def _find_similar(content: str, threshold: float, limit: int) -> list:
            if threshold == 0.95:
                return []
            return [_make_search_result(score=0.9)]

        store.find_similar.side_effect = _find_similar

        with patch("distillery.feeds.poller._build_adapter") as mock_build:
            mock_adapter = MagicMock()
            mock_adapter.fetch.return_value = [item]
            mock_build.return_value = mock_adapter

            # reader=None mirrors the production wiring when feeds.reader.enabled=False.
            poller = FeedPoller(store=store, config=cfg, reader=None)
            summary = await poller.poll()

        assert summary.total_items_enriched == 0
        assert summary.total_enrichment_errors == 0
        assert summary.total_stored == 1

    async def test_item_without_url_skips_enrichment(self) -> None:
        item = _make_feed_item(item_id="id1", title="Short", content="short")
        item.url = None  # explicit: no URL
        src = _rss_source()
        cfg = _make_reader_config([src], min_content_chars=500)
        store = _make_store(feed_sources=[_source_to_dict(src)])

        async def _find_similar(content: str, threshold: float, limit: int) -> list:
            if threshold == 0.95:
                return []
            return [_make_search_result(score=0.9)]

        store.find_similar.side_effect = _find_similar

        reader = _FakeReader({})

        with patch("distillery.feeds.poller._build_adapter") as mock_build:
            mock_adapter = MagicMock()
            mock_adapter.fetch.return_value = [item]
            mock_build.return_value = mock_adapter

            poller = FeedPoller(store=store, config=cfg, reader=reader)  # type: ignore[arg-type]
            summary = await poller.poll()

        assert summary.total_items_enriched == 0
        assert reader.calls == []  # filtered out by candidate predicate
