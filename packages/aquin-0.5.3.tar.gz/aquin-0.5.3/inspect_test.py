"""
On-prem inspection test using aquin.inspect().

Usage:
    pip install --upgrade aquin==0.5.0 transformers torch
    python inspect_test.py --api-key aq-xxxx

What it does:
    1. Loads Llama-3.2-1B-Instruct
    2. Calls aquin.inspect() — resolves SAE (Aquin → Neuronpedia → HF → trains locally)
    3. Runs feature analysis on default eval prompts
    4. Streams all results to dashboard (open model tab → SDK → enter key)
    5. Enters interactive mode — live prompt inspection from dashboard
"""

import argparse

parser = argparse.ArgumentParser()
parser.add_argument("--api-key",  required=True, help="Your Aquin API key (aq-xxx)")
parser.add_argument("--model-id", default="meta-llama/Llama-3.2-1B-Instruct")
parser.add_argument("--layer",    default=8, type=int, help="Transformer layer to attach SAE to")
args = parser.parse_args()

print(f"[inspect] model:  {args.model_id}")
print(f"[inspect] layer:  {args.layer}")
print()

import torch
from transformers import AutoModelForCausalLM

device = "cuda" if torch.cuda.is_available() else "cpu"
dtype  = torch.bfloat16 if torch.cuda.is_available() else torch.float32

print(f"[inspect] loading model on {device}…")
model = AutoModelForCausalLM.from_pretrained(
    args.model_id, torch_dtype=dtype, device_map=device
)
model.eval()
print(f"[inspect] model loaded — {sum(p.numel() for p in model.parameters()):,} params")
print()

import aquin

session = aquin.inspect(
    model,
    api_key=args.api_key,
    layer=args.layer,
)

print(f"[inspect] open dashboard → model tab → SDK → enter your API key → Connect")
print(f"[inspect] then session.run() will stream results live")
print()

session.run()