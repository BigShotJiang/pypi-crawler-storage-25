# aquin

Python SDK for [Aquin](https://aquin.app) — stream live training metrics, run model diffs, and inspect datasets directly from your training script.

## Install

```bash
pip install aquin
```

If you need PyTorch helpers (activation tracking etc.):

```bash
pip install "aquin[torch]"
```

## Usage

### Training session

```python
import aquin

session = aquin.attach(model, optimizer, api_key="aq-...")

for step in range(num_steps):
    loss = train_step()
    session.step(loss, epoch=epoch, batch=batch, total_batches=len(dataloader))

session.stop()
```

Open [aquin.app/app](https://aquin.app/app) → Training tab → connect with your API key to watch metrics stream in live.

### Model diff

Compare a fine-tuned checkpoint against its base model:

```python
diff = aquin.ModelDiff(
    base="meta-llama/Llama-3.2-1B",
    ft_path="./my-checkpoint.pt",
    api_key="aq-...",
)
result = diff.run(prompts=["Tell me about X", "Explain Y"])
```

### SAE feature diff

Inspect which SAE features changed most between base and fine-tuned:

```python
sae = aquin.SAEDiff(
    base="meta-llama/Llama-3.2-1B",
    ft_path="./my-checkpoint.pt",
    api_key="aq-...",
)
result = sae.run(prompts=["Tell me about X"])
```

### Dataset inspection

Scan a dataset for PII, toxicity, bias, synthetic content, and compliance:

```python
ds = aquin.DataSession(
    dataset_path="./training_data.jsonl",
    api_key="aq-...",
)
results = ds.inspect()
```

Supports `.jsonl`, `.json`, `.csv`, and `.tsv`.

## API key

Get your key at [aquin.app](https://aquin.app).

## Links

- [Dashboard](https://aquin.app/app)
- [Docs](https://aquin.app/docs)