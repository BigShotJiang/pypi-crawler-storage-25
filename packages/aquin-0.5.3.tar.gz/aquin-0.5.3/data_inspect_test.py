"""
On-prem dataset inspection test using aquin.inspect_data().

Usage:
    pip install --upgrade aquin==0.5.1
    python data_inspect_test.py --api-key aq-xxxx --dataset dataset.jsonl

What it does:
    1. Loads your dataset (.jsonl / .csv / .tsv / .json)
    2. Calls aquin.inspect_data() — streams session ID to dashboard
    3. Runs locally: PII scan · toxicity · bias surface · synthetic detection
    4. Builds audit trail (SHA-256 hash, timestamp, liability chain)
    5. Generates compliance report combining all checks
    6. All results stream to dashboard live as each check finishes

Open dashboard → dataset tab → SDK → enter your API key → Connect
then run this script.
"""

import argparse
import os

parser = argparse.ArgumentParser()
parser.add_argument("--api-key",  required=True, help="Your Aquin API key (aq-xxx)")
parser.add_argument("--dataset",  default="dataset.jsonl", help="Path to dataset file (.jsonl, .csv, .tsv, .json)")
parser.add_argument("--text-cols", default=None, help="Comma-separated column names to inspect (auto-detected if omitted)")
args = parser.parse_args()

if not os.path.exists(args.dataset):
    raise FileNotFoundError(
        f"Dataset not found: {args.dataset}\n"
        "Provide a .jsonl, .csv, .tsv, or .json file."
    )

text_columns = [c.strip() for c in args.text_cols.split(",")] if args.text_cols else None

print(f"[data_inspect] Dataset: {args.dataset}")
print(f"[data_inspect] Text columns: {text_columns or '(auto-detect)'}")
print()
print(f"[data_inspect] Open dashboard → dataset tab → SDK → enter your API key → Connect")
print(f"[data_inspect] Then results will stream live as each check finishes")
print()

import aquin

session = aquin.inspect_data(
    args.dataset,
    api_key=args.api_key,
    text_columns=text_columns,
)

session.run()

print()
print(f"[data_inspect] Done. Check the dataset tab in your Aquin dashboard for full results.")