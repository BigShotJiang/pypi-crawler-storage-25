"""
End-to-end test for the Aquin SDK worker pipeline.

Run this on a separate VM (NOT the Aquin server) with a GPU and the dataset file.
It simulates a real customer fine-tuning pipeline using only the SDK.

Usage:
    pip install aquin transformers peft torch datasets
    python e2e_test.py --api-key aq-xxxx

What it does:
    1. Loads Llama-3.2-1B-Instruct
    2. Applies LoRA
    3. Calls aquin.attach() — validates model, pulls SAE weights, opens WebSocket
    4. Trains on a small imaginary dataset (you provide as dataset.jsonl)
    5. Calls session.stop(ft_model=...) — runs model diff + SAE diff locally, sends to dashboard
    6. You watch the Training tab in the Aquin dashboard live
"""

import argparse
import os
import time

parser = argparse.ArgumentParser()
parser.add_argument("--api-key",  required=True,  help="Your Aquin API key (aq-xxx)")
parser.add_argument("--base-url", default="https://api.aquin.app", help="Aquin base URL")
parser.add_argument("--model-id", default="meta-llama/Llama-3.2-1B-Instruct")
parser.add_argument("--dataset",  default="dataset.jsonl", help="Path to your .jsonl training data")
args = parser.parse_args()

# ── Training config ───────────────────────────────────────────────────────────
RANK    = 8
ALPHA   = 16
LR      = 2e-4
EPOCHS  = 1
DROPOUT = 0.05
TARGET_MODULES = ["q_proj", "v_proj"]

print(f"[e2e] Starting end-to-end test")
print(f"[e2e] Model:    {args.model_id}")
print(f"[e2e] Dataset:  {args.dataset}")
print(f"[e2e] Base URL: {args.base_url}")
print(f"[e2e] Config:   rank={RANK}  alpha={ALPHA}  lr={LR}  epochs={EPOCHS}")
print()

# ── 1. Load dataset ───────────────────────────────────────────────────────────

import json

if not os.path.exists(args.dataset):
    raise FileNotFoundError(
        f"Dataset not found: {args.dataset}\n"
        "Create a .jsonl file with rows like: {\"instruction\": \"...\", \"response\": \"...\"}"
    )

rows = []
with open(args.dataset, encoding="utf-8") as f:
    for line in f:
        line = line.strip()
        if line:
            rows.append(json.loads(line))

print(f"[e2e] Loaded {len(rows)} training rows")

# ── 2. Load model + apply LoRA ────────────────────────────────────────────────

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import get_peft_model, LoraConfig, TaskType

print(f"[e2e] Loading tokenizer…")
tokenizer = AutoTokenizer.from_pretrained(args.model_id)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

device = "cuda" if torch.cuda.is_available() else "cpu"
dtype  = torch.bfloat16 if torch.cuda.is_available() else torch.float32

print(f"[e2e] Loading model on {device}…")
base_model = AutoModelForCausalLM.from_pretrained(
    args.model_id, torch_dtype=dtype, device_map=device
)

lora_cfg = LoraConfig(
    task_type=TaskType.CAUSAL_LM,
    r=RANK, lora_alpha=ALPHA, lora_dropout=DROPOUT,
    target_modules=TARGET_MODULES,
)
model = get_peft_model(base_model, lora_cfg)
model.train()

optimizer = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=0.01)

print(f"[e2e] LoRA applied — {sum(p.numel() for p in model.parameters() if p.requires_grad):,} trainable params")

# ── 3. Attach Aquin SDK ───────────────────────────────────────────────────────

import aquin

session = aquin.attach(
    model,
    optimizer,
    api_key=args.api_key,
    base_url=args.base_url,
    dataset_path=args.dataset,
    training_config={
        "algo_name":      "LoRA Fine-Tuning",
        "rank":           RANK,
        "alpha":          ALPHA,
        "lr":             LR,
        "epochs":         EPOCHS,
        "optimizer":      "AdamW",
        "scheduler":      "Cosine",
        "lora_dropout":   DROPOUT,
        "target_modules": TARGET_MODULES,
        "desc": [
            "Low-Rank Adaptation (LoRA) freezes all base model weights and injects small trainable rank decomposition matrices into each attention layer.",
            "For a weight matrix W₀ ∈ ℝᵈˣᵏ, LoRA adds ΔW = BA where B ∈ ℝᵈˣʳ and A ∈ ℝʳˣᵏ with rank r ≪ min(d,k).",
            "Only A and B are updated during training — the base model remains frozen.",
        ],
    },
)

# ── 4. Training loop ──────────────────────────────────────────────────────────

texts = [
    f"### Instruction:\n{r['instruction']}\n\n### Response:\n{r['response']}"
    for r in rows
]
encodings = tokenizer(texts, return_tensors="pt", padding=True, truncation=True, max_length=128)
input_ids = encodings["input_ids"].to(device)

import math
total_batches = len(input_ids)
total_steps   = EPOCHS * total_batches
scheduler = torch.optim.lr_scheduler.LambdaLR(
    optimizer,
    lambda step: max(0.0, 0.5 * (1 + math.cos(math.pi * step / max(total_steps, 1))))
)

print(f"[e2e] Starting training — {EPOCHS} epoch(s) × {total_batches} batches")
t0 = time.time()

for epoch in range(EPOCHS):
    for batch_idx, ids in enumerate(input_ids):
        ids    = ids.unsqueeze(0)
        labels = ids.clone()
        labels[labels == tokenizer.pad_token_id] = -100

        optimizer.zero_grad()
        out = model(input_ids=ids, labels=labels)
        out.loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        scheduler.step()

        session.step(
            out.loss,
            epoch=epoch,
            batch=batch_idx,
            total_batches=total_batches,
        )

    print(f"[e2e] Epoch {epoch + 1}/{EPOCHS} done  elapsed={time.time()-t0:.1f}s")

# ── 5. Merge LoRA + stop session (runs model diff + SAE diff automatically) ───

print(f"[e2e] Merging LoRA weights…")
ft_model = model.merge_and_unload()
ft_model.eval()

# session.stop() will:
#   - Send state=stopped to dashboard
#   - Wait for SAE weights pull to finish
#   - Run model diff locally → send to dashboard
#   - Run SAE diff locally   → send to dashboard
#   - Close WebSocket
session.stop(ft_model=ft_model)

print(f"[e2e] Done. Open the Training tab in your Aquin dashboard to see results.")
