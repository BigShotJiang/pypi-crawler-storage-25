"""cli/local/auth.py - SSO 鉴权：每次动态获取 token，自动缓存刷新"""
import os
import json
import subprocess
from pathlib import Path
from typing import Optional

_CONFIG_PATH = Path.home() / ".local" / "share" / "tsp-ops" / "config.json"
_DEFAULT_SERVER_URL = "https://productop.waimai.st.sankuai.com"
_NODE_PATH: Optional[str] = None


def _get_node_path() -> str:
    """动态获取 npm 全局模块路径，兼容 macOS / Linux。结果缓存在模块变量中。"""
    global _NODE_PATH
    if _NODE_PATH is not None:
        return _NODE_PATH
    try:
        result = subprocess.run(
            ["npm", "root", "-g"],
            capture_output=True, text=True, timeout=10,
        )
        path = result.stdout.strip()
        if path:
            _NODE_PATH = path
            return _NODE_PATH
    except Exception:
        pass
    _NODE_PATH = "/opt/homebrew/lib/node_modules"
    return _NODE_PATH


_TARGET_CLIENT_ID = "1569c915c9"
_NPM_REGISTRY = "http://r.npm.sankuai.com"
_PKG_NAME = "@it/oa-skills-shared"

_pkg_ensured = False


def _ensure_oa_skills_shared():
    """确保 @it/oa-skills-shared 已安装，未安装时自动安装。同一进程只检查一次。"""
    global _pkg_ensured
    if _pkg_ensured:
        return

    env = os.environ.copy()
    env["NODE_TLS_REJECT_UNAUTHORIZED"] = "0"

    # 检查是否已安装
    check = subprocess.run(
        ["node", "-e", f"require('{_PKG_NAME}/auth'); process.exit(0)"],
        capture_output=True,
        env={**env, "NODE_PATH": _get_node_path()},
    )
    if check.returncode == 0:
        _pkg_ensured = True
        return

    # 未安装，自动全局安装
    subprocess.run(
        ["npm", "install", "-g", _PKG_NAME, f"--registry={_NPM_REGISTRY}"],
        env=env,
        check=True,
    )
    _pkg_ensured = True

_JS_GET_TOKEN = """
const { getSsoAccessToken } = require('@it/oa-skills-shared/auth');
(async () => {
    try {
        const token = await getSsoAccessToken("city-menu-insight", "%s", {
            targetClientId: "%s",
            forceCiba: true
        });
        console.log(JSON.stringify({ success: true, token }));
    } catch (e) {
        console.log(JSON.stringify({ success: false, error: e.message }));
    }
})();
"""


def _load_config() -> dict:
    try:
        return json.loads(_CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def get_mis() -> str:
    return _load_config().get("mis") or ""


def get_server_url() -> str:
    return os.environ.get("TSP_OPS_SERVER_URL") or _DEFAULT_SERVER_URL


def get_token(mis: Optional[str] = None) -> str:
    """动态获取 SSO token，自动缓存刷新。mis 不传则从配置文件读取。"""
    _ensure_oa_skills_shared()
    user_id = mis or get_mis()
    if not user_id:
        raise RuntimeError("未找到 MIS ID，请先配置：tsp-ops-menu config set-mis <mis>")

    env = os.environ.copy()
    env["NODE_PATH"] = _get_node_path()
    env["NODE_TLS_REJECT_UNAUTHORIZED"] = "0"

    result = subprocess.run(
        ["node", "-e", _JS_GET_TOKEN % (user_id, _TARGET_CLIENT_ID)],
        capture_output=True,
        text=True,
        timeout=180,
        env=env,
    )
    # stdout 可能有多行日志，取最后一行 JSON
    for line in reversed(result.stdout.strip().splitlines()):
        try:
            data = json.loads(line)
            if "success" in data:
                break
        except Exception:
            continue
    else:
        raise RuntimeError(f"鉴权失败，无法解析输出：{result.stdout}\n{result.stderr}")

    if data["success"]:
        return data["token"]
    else:
        raise RuntimeError(f"鉴权失败: {data['error']}")


def get_headers(mis: Optional[str] = None) -> dict:
    headers = {"Content-Type": "application/json"}
    token = get_token(mis=mis)
    if token:
        headers["access-token"] = token
    return headers


def save_config(mis: Optional[str] = None):
    """写入配置文件，仅更新传入的字段。"""
    _CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    config = _load_config()
    if mis is not None:
        config["mis"] = mis
    _CONFIG_PATH.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
