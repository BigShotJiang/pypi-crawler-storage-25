"""CLI 入口，注册子命令"""
import typer
from importlib.metadata import version as pkg_version
from cli.commands.list_cmd import list_ranking, list_runs_cmd
from cli.commands.get_cmd import get_product
from cli.commands.update_cmd import update_ranking
from cli.commands.delete_cmd import delete_record
from cli.commands.export_cmd import export_ranking
from cli.commands.config_cmd import config_set_mis, config_show, config_clear_cache

app = typer.Typer(name="tsp-ops-menu", help="城市菜单洞察 CLI v2", no_args_is_help=True)


@app.command("version")
def show_version():
    """显示当前版本"""
    try:
        v = pkg_version("mt-city-menu-insight")
    except Exception:
        v = "unknown"
    typer.echo(v)

list_app = typer.Typer(help="查询类命令", no_args_is_help=True)
list_app.command("ranking")(list_ranking)
list_app.command("runs")(list_runs_cmd)

get_app = typer.Typer(help="查询单词指标", no_args_is_help=True)
get_app.command("product")(get_product)

update_app = typer.Typer(help="修改榜单", no_args_is_help=True)
update_app.command("ranking")(update_ranking)

delete_app = typer.Typer(help="撤销操作", no_args_is_help=True)
delete_app.command("record")(delete_record)

export_app = typer.Typer(help="导出榜单", no_args_is_help=True)
export_app.command("ranking")(export_ranking)

config_app = typer.Typer(help="配置管理", no_args_is_help=True)
config_app.command("set-mis")(config_set_mis)
config_app.command("show")(config_show)
config_app.command("clear-cache")(config_clear_cache)

app.add_typer(list_app, name="list")
app.add_typer(get_app, name="get")
app.add_typer(update_app, name="update")
app.add_typer(delete_app, name="delete")
app.add_typer(export_app, name="export")
app.add_typer(config_app, name="config")

if __name__ == "__main__":
    app()
