"""list ranking / list runs - 查询榜单 / 展示本地历史"""
import sys
import typer
import httpx
from datetime import datetime, timedelta
from typing import Optional
from rich.console import Console
from rich.table import Table
from cli.local import store, snapshot, auth

console = Console(width=120)

SERVER_URL = auth.get_server_url()
_DT_WINDOW_TO_DATE_TYPE = {"1d": 1, "3d": 3, "7d": 7, "14d": 14, "30d": 30}

_IS_INTERACTIVE = sys.stdin.isatty()


def list_ranking(
    run_id: Optional[str] = typer.Option(None, "--run-id", help="直接展示指定 run_id 的本地榜单，不调服务端"),
    city: Optional[str] = typer.Option(None, "--city", help="城市名称，如 北京、上海"),
    category: Optional[str] = typer.Option(None, "--category", help="拼好饭一级品类"),
    top_n: int = typer.Option(50, "--top-n"),
    dt_window: str = typer.Option("1d", "--dt-window"),
    price_min: Optional[float] = typer.Option(None, "--price-min"),
    price_max: Optional[float] = typer.Option(None, "--price-max"),
    min_sales: int = typer.Option(0, "--min-sales"),
    sort: str = typer.Option("orders_main", "--sort"),
    dt: Optional[str] = typer.Option(None, "--dt", help="数据日期，格式 yyyyMMdd，默认当天"),
    no_cache: bool = typer.Option(False, "--no-cache", help="跳过本地缓存，强制保存新查询结果"),
    fmt: str = typer.Option("markdown", "--format", help="输出格式：markdown（默认，AI 友好）/ table（终端表格）/ json（原始数据）"),
):
    # --run-id 模式：直接读本地文件展示
    if run_id:
        try:
            data = store.load(run_id)
        except FileNotFoundError:
            console.print(f"[red]找不到 run_id：{run_id}[/red]")
            raise typer.Exit(1)
        _display(run_id, data, fmt)
        return

    if not category:
        console.print("[red]需要 --category 参数（或用 --run-id 直接展示已有榜单）[/red]")
        raise typer.Exit(1)
    if not city:
        console.print("[red]需要 --city 参数，如 --city 北京[/red]")
        raise typer.Exit(1)

    now = datetime.now()
    dt = dt or (now - timedelta(days=1)).strftime("%Y%m%d")

    payload = {
        "dt": dt,
        "cityName": city,
        "categoryName": category,
        "topN": top_n,
        "sortType": "ORDER_SPACE_DESC" if sort == "order_space" else "SALES_DESC",
        "minPrice": int(price_min) if price_min is not None else 0,
        "minSales": min_sales,
        "dateType": _DT_WINDOW_TO_DATE_TYPE.get(dt_window, 30),
    }
    if price_max is not None:
        payload["maxPrice"] = int(price_max)

    try:
        resp = httpx.post(f"{SERVER_URL}/api/insight/opportunity/v1/list/query", headers=auth.get_headers(), json=payload, timeout=30)
        resp.raise_for_status()
    except Exception as e:
        console.print(f"[red]服务端请求失败：{e}[/red]")
        raise typer.Exit(1)

    result = resp.json()
    if str(result.get("code", "0")) != "0":
        console.print(f"[red]服务端错误：{result.get('message')}[/red]")
        raise typer.Exit(1)

    data_obj = result["data"]
    source = data_obj.get("source", "NEW_QUERY").upper()
    main_list = data_obj.get("mainList", [])
    buffer_list = data_obj.get("bufferList", [])

    # ── 层一：服务端缓存 ────────────────────────────────────────────
    if source == "CACHED":
        version_info = data_obj.get("versionInfo") or {}
        cached_dt = version_info.get("dt", "")
        creator = version_info.get("creatorMis", "")
        console.print(f"[yellow]命中服务端缓存（dt={cached_dt}，操作人：{creator}）[/yellow]")
        if _IS_INTERACTIVE:
            use_cache = typer.confirm("是否直接使用？", default=True)
            if not use_cache:
                console.print("[yellow]服务端缓存无法强制绕过，将使用缓存数据。[/yellow]")
        # 无论用户选择，服务端缓存数据都直接使用（无法强制重查）
        _save_and_display(run_id_prefix=f"{city}_{category}", now=now, city=city, category=category,
                          dt=dt, dt_window=dt_window, top_n=top_n, sort=sort,
                          price_min=price_min, price_max=price_max,
                          main_list=main_list, buffer_list=buffer_list, fmt=fmt)
        return

    # ── 层二：本地缓存（仅 NEW_QUERY 时检查）──────────────────────
    if not no_cache:
        cached_run = store.find_local_cache(
            city=city, category=category, top_n=top_n,
            price_min=price_min, price_max=price_max,
            sort_by=sort, dt_window=dt_window, dt=dt,
        )
        if cached_run:
            console.print(f"[cyan]命中本地缓存（run_id: {cached_run['run_id']}，生成时间：{cached_run['generated_at']}）[/cyan]")
            if _IS_INTERACTIVE:
                use_local = typer.confirm("是否直接使用？", default=True)
                if use_local:
                    data = store.load(cached_run["run_id"])
                    _display(cached_run["run_id"], data, fmt)
                    return
                # 用户选择不用本地缓存 → 继续保存新结果
            else:
                # Skill 端：默认使用本地缓存，直接展示
                data = store.load(cached_run["run_id"])
                _display(cached_run["run_id"], data, fmt)
                return

    # ── 无缓存命中 / --no-cache / 用户选择保存新结果 ──────────────
    _save_and_display(run_id_prefix=f"{city}_{category}", now=now, city=city, category=category,
                      dt=dt, dt_window=dt_window, top_n=top_n, sort=sort,
                      price_min=price_min, price_max=price_max,
                      main_list=main_list, buffer_list=buffer_list, fmt=fmt)


def _save_and_display(run_id_prefix, now, city, category, dt, dt_window, top_n, sort,
                      price_min, price_max, main_list, buffer_list, fmt):
    new_run_id = f"{city}_{category}_{now.strftime('%Y%m%d%H%M%S')}"
    rk_key = "rank_by_main" if sort in ("orders_main", "SALES_DESC") else "rank_by_space"
    other_key = "rank_by_space" if rk_key == "rank_by_main" else "rank_by_main"

    for i, item in enumerate(main_list, 1):
        item["rank"] = i
        item["isNewDiscovery"] = item.get("wmSales", 0) > 0 and item.get("phfSales", 0) == 0

    for item in buffer_list:
        item["isNewDiscovery"] = item.get("wmSales", 0) > 0 and item.get("phfSales", 0) == 0

    data = {
        "run_id": new_run_id,
        "city": city,
        "category": category,
        "dt": dt,
        "dt_window": dt_window,
        "top_n": top_n,
        "sort_by": sort,
        "price_min": price_min,
        "price_max": price_max,
        "generated_at": now.strftime("%Y-%m-%d %H:%M:%S"),
        "active_ranking": rk_key,
        rk_key: main_list,
        rk_key + "_pool": buffer_list,
        other_key: [],
        other_key + "_pool": [],
        "ops_log": [],
    }

    store.save_original(new_run_id, {
        rk_key: main_list,
        rk_key + "_pool": buffer_list,
    })
    store.save(new_run_id, data)
    snapshot.save(new_run_id, f"initial: {category} top{top_n} sort={sort}")
    _display(new_run_id, data, fmt)


def _display(run_id: str, data: dict, fmt: str):
    rk = data.get("active_ranking", "rank_by_main")
    items = data.get(rk, [])

    if fmt == "json":
        import json
        console.print(json.dumps({"run_id": run_id, "items": items}, ensure_ascii=False, indent=2))
        return

    if fmt == "markdown":
        lines = [
            f"run_id: {run_id}\n",
            "| 排名 | 候选必上菜名称 | 主站销量 | 主站订单占比 | PHF销量 | PHF订单占比 | 订单空间 | 是否新发现 | 标准菜 | 是否线上必上菜 | 主站均价 | 拼好饭均价 | TBSG销量 | TBSG订单占比 | TBSG均价 |",
            "|---:|---|---:|---:|---:|---:|---:|:---:|---|:---:|---:|---:|---:|---:|---:|",
        ]
        for item in items:
            must = item.get("isOnlineMustItem")
            must_str = "是" if must is True else ("-" if must == "-" else "否")
            lines.append(
                f"| {item.get('rank', '')} "
                f"| {item.get('productName', '')} "
                f"| {item.get('wmSales', 0):,} "
                f"| {item.get('wmOrderRatio', 0) * 100:.1f}% "
                f"| {item.get('phfSales', 0):,} "
                f"| {item.get('phfOrderRatio', 0) * 100:.1f}% "
                f"| {item.get('orderSpace', 0) * 100:.1f}% "
                f"| {'🆕' if item.get('isNewDiscovery') else ''} "
                f"| {item.get('standFoodName', '')} "
                f"| {must_str} "
                f"| ¥{item.get('wmAvgPrice') or 0:.1f} "
                f"| ¥{item.get('phfAvgPrice') or 0:.1f} "
                f"| {item.get('tbsgSales', 0):,} "
                f"| {item.get('tbsgOrderRatio', 0) * 100:.1f}% "
                f"| ¥{item.get('tbsgAvgPrice') or 0:.1f} |"
            )
        print("\n".join(lines))
        return

    console.print(f"\nrun_id: [bold]{run_id}[/bold]\n")
    t = Table(show_header=True, header_style="bold", expand=False)
    t.add_column("排名", justify="right", no_wrap=True)
    t.add_column("候选必上菜名称", no_wrap=True)
    t.add_column("主站销量", justify="right")
    t.add_column("主站订单占比", justify="right")
    t.add_column("PHF销量", justify="right")
    t.add_column("PHF订单占比", justify="right")
    t.add_column("订单空间", justify="right")
    t.add_column("是否新发现", justify="center", no_wrap=True)
    t.add_column("标准菜", no_wrap=True)
    t.add_column("是否线上必上菜", justify="center", no_wrap=True)
    t.add_column("主站均价", justify="right")
    t.add_column("拼好饭均价", justify="right")
    t.add_column("TBSG销量", justify="right")
    t.add_column("TBSG订单占比", justify="right")
    t.add_column("TBSG均价", justify="right")
    for item in items:
        must = item.get("isOnlineMustItem")
        must_str = "是" if must is True else ("-" if must == "-" else "否")
        t.add_row(
            str(item.get("rank", "")),
            item.get("productName", ""),
            f"{item.get('wmSales', 0):,}",
            f"{item.get('wmOrderRatio', 0) * 100:.1f}%",
            f"{item.get('phfSales', 0):,}",
            f"{item.get('phfOrderRatio', 0) * 100:.1f}%",
            f"{item.get('orderSpace', 0) * 100:.1f}%",
            "🆕" if item.get("isNewDiscovery") else "",
            item.get("standFoodName", ""),
            must_str,
            f"¥{item.get('wmAvgPrice') or 0:.1f}",
            f"¥{item.get('phfAvgPrice') or 0:.1f}",
            f"{item.get('tbsgSales', 0):,}",
            f"{item.get('tbsgOrderRatio', 0) * 100:.1f}%",
            f"¥{item.get('tbsgAvgPrice') or 0:.1f}",
        )
    console.print(t)


def list_runs_cmd():
    """展示所有本地榜单记录"""
    runs = store.list_runs()
    if not runs:
        print("暂无本地榜单记录")
        return

    lines = [
        "| run_id | 城市 | 品类 | 数据日期 | 时间窗口 | Top N | 排名方式 | 价格带 | 生成时间 | 操作数 |",
        "|---|---|---|---|---|---:|---|---|---|---:|",
    ]
    for r in runs:
        price_range = ""
        if r["price_min"] is not None or r["price_max"] is not None:
            lo = str(int(r["price_min"])) if r["price_min"] is not None else "0"
            hi = str(int(r["price_max"])) if r["price_max"] is not None else "∞"
            price_range = f"¥{lo}~{hi}"
        lines.append(
            f"| {r['run_id']} "
            f"| {r['city']} "
            f"| {r['category']} "
            f"| {r.get('dt', '')} "
            f"| {r['dt_window']} "
            f"| {r['top_n']} "
            f"| {r['sort_by']} "
            f"| {price_range or '不限'} "
            f"| {r['generated_at']} "
            f"| {r['ops_count']} |"
        )
    print("\n".join(lines))
