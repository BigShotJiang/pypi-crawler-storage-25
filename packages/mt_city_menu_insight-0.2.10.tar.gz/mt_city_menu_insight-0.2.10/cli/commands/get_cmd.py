"""get product - 查询本质词指标"""
import os
import re
import typer
import httpx
from datetime import datetime, timedelta
from collections import defaultdict
from rich.console import Console
from rich.table import Table
from cli.local import auth

console = Console(width=120)

SERVER_URL = auth.get_server_url()
_DT_WINDOW_TO_DATE_TYPE = {"1d": 1, "3d": 3, "7d": 7, "14d": 14, "30d": 30}


def _parse_query(s: str) -> dict:
    """解析 '(奶茶,0)' → {'key': '奶茶', 'depth': 0}"""
    m = re.match(r"\((.+),\s*(\d)\)", s.strip())
    if not m:
        raise typer.BadParameter(f"格式错误，应为 '(词,深度)'：{s}")
    return {"key": m.group(1).strip(), "depth": int(m.group(2))}


def get_product(
    query: str = typer.Option(..., "--query", help="查询列表，多个用 ; 分隔，格式 (词,深度)，如 (奶茶,0);(咖啡,1)"),
    city: str = typer.Option(..., "--city", help="城市名称，如 北京、上海"),
    category: str = typer.Option(..., "--category"),
    dt_window: str = typer.Option("1d", "--dt-window"),
    fmt: str = typer.Option("markdown", "--format", help="输出格式：markdown（默认，AI 友好）/ table（终端表格）"),
):
    entries = [e.strip() for e in query.split(";") if e.strip()]
    queries = [_parse_query(e) for e in entries]

    # 按 depth 分组查询
    by_depth = defaultdict(list)
    for q in queries:
        by_depth[q["depth"]].append(q["key"])

    dt = (datetime.now() - timedelta(days=1)).strftime("%Y%m%d")
    all_metrics = {}
    for depth, products in by_depth.items():
        try:
            resp = httpx.post(f"{SERVER_URL}/api/insight/opportunity/v1/product/query", headers=auth.get_headers(), json={
                "dt": dt,
                "products": products,
                "level": depth,
                "cityName": city,
                "categoryName": category,
                "dateType": _DT_WINDOW_TO_DATE_TYPE.get(dt_window, 30),
            }, timeout=30)
            resp.raise_for_status()
        except Exception as e:
            console.print(f"[red]服务端请求失败：{e}[/red]")
            raise typer.Exit(1)

        result = resp.json()
        if str(result.get("code", "0")) == "0":
            all_metrics.update(result["data"]["productMetrics"])

    for q in queries:
        items = all_metrics.get(q["key"])
        if not items:
            print(f"{q['key']}（depth={q['depth']}）：数据库中不存在")
            continue
        if q["depth"] == 0:
            print(f"\n{q['key']} 聚合指标：")
        else:
            print(f"\n{q['key']} 及子词（共 {len(items)} 个子词）：")
        _print_items(items, fmt)


def _print_items(items: list, fmt: str = "markdown"):
    if fmt == "markdown":
        lines = [
            "| 本质词 | 主站销量 | 主站订单占比 | PHF销量 | PHF订单占比 | 订单空间 | 是否新发现 | 主站均价 | 拼好饭均价 | TBSG销量 | TBSG订单占比 | TBSG均价 |",
            "|---|---:|---:|---:|---:|---:|:---:|---:|---:|---:|---:|---:|",
        ]
        for item in items:
            sub = item.get("subProductName", "-")
            display_name = item.get("productName", "") if sub == "-" else f"{item.get('productName', '')} / {sub}"
            lines.append(
                f"| {display_name} "
                f"| {item.get('wmSales', 0):,} "
                f"| {item.get('wmOrderRatio', 0) * 100:.2f}% "
                f"| {item.get('phfSales', 0):,} "
                f"| {item.get('phfOrderRatio', 0) * 100:.2f}% "
                f"| {item.get('orderSpace', 0) * 100:.2f}% "
                f"| {'🆕' if item.get('isNewDiscovery') else ''} "
                f"| ¥{item.get('wmAvgPrice') or 0:.1f} "
                f"| ¥{item.get('phfAvgPrice') or 0:.1f} "
                f"| {item.get('tbsgSales', 0):,} "
                f"| {item.get('tbsgOrderRatio', 0) * 100:.2f}% "
                f"| ¥{item.get('tbsgAvgPrice') or 0:.1f} |"
            )
        print("\n".join(lines))
        return

    t = Table(show_header=True, header_style="bold")
    t.add_column("本质词")
    t.add_column("主站销量", justify="right")
    t.add_column("主站订单占比", justify="right")
    t.add_column("PHF销量", justify="right")
    t.add_column("PHF订单占比", justify="right")
    t.add_column("订单空间", justify="right")
    t.add_column("是否新发现", justify="center")
    t.add_column("主站均价", justify="right")
    t.add_column("拼好饭均价", justify="right")
    t.add_column("TBSG销量", justify="right")
    t.add_column("TBSG订单占比", justify="right")
    t.add_column("TBSG均价", justify="right")
    for item in items:
        sub = item.get("subProductName", "-")
        display_name = item.get("productName", "") if sub == "-" else f"{item.get('productName', '')} / {sub}"
        t.add_row(
            display_name,
            f"{item.get('wmSales', 0):,}",
            f"{item.get('wmOrderRatio', 0) * 100:.2f}%",
            f"{item.get('phfSales', 0):,}",
            f"{item.get('phfOrderRatio', 0) * 100:.2f}%",
            f"{item.get('orderSpace', 0) * 100:.2f}%",
            "🆕" if item.get("isNewDiscovery") else "",
            f"¥{item.get('wmAvgPrice') or 0:.1f}",
            f"¥{item.get('phfAvgPrice') or 0:.1f}",
            f"{item.get('tbsgSales', 0):,}",
            f"{item.get('tbsgOrderRatio', 0) * 100:.2f}%",
            f"¥{item.get('tbsgAvgPrice') or 0:.1f}",
        )
    console.print(t)
