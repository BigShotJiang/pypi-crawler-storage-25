---
name: city-menu-insight
description: 城市菜单洞察工具。当用户想要查询某品类的热销品、机会品、大单品清单时触发。当用户想要对已有清单进行任何操作（微调、聚合、下钻、排名调整、撤销等）时触发。当用户询问已有清单时也触发，如"刚刚的清单"、"上次的清单"、"最新的清单"等。当用户询问某品类的必上菜时也触发，如"饭类有哪些机会品"、"饮品的必上菜是什么"等。即使用户只是说"查一下XX品类"、"看看XX有什么热销的"、"XX品类的机会品"等模糊表述，也应该触发此 skill。
---

# 城市菜单洞察工具

## CLI

所有命令通过 `uv run tsp-ops-menu` 执行（editable 安装，无需全局安装）。

---

## 鉴权

Token 由 CLI 在每次请求时自动通过 `@it/oa-skills-shared` 动态获取并刷新，无需手动管理。只需确保配置文件中有 MIS ID。

### 鉴权流程

**Step 1：检查 MIS ID**

```bash
cat ~/.local/share/tsp-ops/config.json 2>/dev/null
```

- 若 `mis` 字段非空 → **直接跳到功能执行**
- 否则并且不知道 → 询问用户：

> 请问你的美团 MIS ID 是什么？（例如：zhangsan）

获取后写入配置文件：

```bash
uv run tsp-ops-menu config set-mis {mis}
```

**首次使用**：CLI 发起请求时会触发大象 App 授权，告知用户：
> 请打开大象 App，点击收到的授权请求确认登录。

Token 自动缓存在 `~/.cache/openclaw-auth/auth-cache.json`，后续自动刷新，无需重复授权。

---

## 会话状态

每次会话维护：
- `current_run_id`：当前操作的清单 run_id（从 `list ranking` 输出中读取）
- `active_ranking`：当前排名维度，`rank_by_main`（默认）或 `rank_by_space`

---

## 功能一：获取清单

### 触发场景

"查一下饮品甜点的热销品"、"饮品甜点 top20"、"帮我看看西快小吃的机会品"

### 执行流程

#### Step 1：解析参数

从用户输入提取：
- `city`：城市名称（如 北京、上海、杭州）
- `category`：拼好饭一级品类（西快小吃/饮品甜点/粉面粥饺/饭类）
- `top_n`：清单数量，默认 50
- 价格带：默认不限
- 排名方式：默认主站销量（`orders_main`）

`city` 或 `category` 不明确时 → **暂停，用 AskUserQuestion 询问，不允许猜测**

#### Step 2：查询榜单（含两层缓存逻辑）

```bash
uv run tsp-ops-menu list ranking --city {city} --category {category} --top-n {top_n} [--dt {dt}] [--dt-window {dt_window}] [--price-min N] [--price-max N] [--sort orders_main|order_space]
```

**缓存行为（Skill 端）**：

CLI 会自动处理两层缓存，**Skill 端无需额外操作**：

1. **服务端缓存（CACHED）**：CLI 输出黄色提示"命中服务端缓存（dt=..., 操作人：...）"，直接使用缓存数据展示，服务端缓存无法强制绕过。
2. **本地缓存（NEW_QUERY + 本地有匹配）**：CLI 在非交互式模式下（Skill 调用时）**自动使用本地缓存**，直接展示已有 run_id，输出青色提示"命中本地缓存（run_id: ..., 生成时间：...）"。
3. **必须明确告知用户是否命中了缓存**，并展示缓存信息（如数据日期、生成时间、操作人等）。

**用户明确要求重新查询时**，加 `--no-cache` 参数跳过本地缓存：

```bash
uv run tsp-ops-menu list ranking --city {city} --category {category} --no-cache ...
```

- 记录 `current_run_id`（从 CLI 输出的 `run_id:` 行读取）
- 记录 `active_ranking`：`orders_main` → `rank_by_main`，`order_space` → `rank_by_space`

#### Step 3：后置引导

展示完清单后，**必须**输出：

```
---
你还可以：
- 🔄 切换排名方式（当前：主站销量 | 可切换为：订单空间）
- 💰 重新选择价格带（当前：不限）
- 🔢 调整清单数量（当前：Top {N}）
- 🔼 上聚本质词（如"把咖啡类合并"）
- 🔽 下钻展开（如"展开奶茶"）
- ✏️ 微调清单（删除某个词）
- ↩️ 撤销上一步
- 📋 导出清单
```

---

## 功能二：查看历史榜单

### 触发场景

"刚刚的清单"、"上次的清单"、"我有哪些历史榜单"、"昨天查的那个成都饭类"

### 执行流程

#### Step 1：列出历史记录

```bash
uv run tsp-ops-menu list runs
```

输出包含：run_id、城市、品类、数据日期、时间窗口、Top N、排名方式、价格带、生成时间、操作数。

#### Step 2：加载指定历史

```bash
uv run tsp-ops-menu list ranking --run-id {run_id}
```

记录 `current_run_id`，后续操作基于该 run_id。

---

## 功能三：查询本质词指标

### 触发场景

"奶茶下面有哪些子词"、"看看咖啡的指标"、"展开奶茶前先看看子词"

### 执行流程

```bash
# depth=0：查该词聚合指标
uv run tsp-ops-menu get product --query "(奶茶,0)" --city {city} --category {category}

# depth=1：查该词及子词列表（第一个元素为父词自身，子词行显示 productName / subProductName）
uv run tsp-ops-menu get product --query "(奶茶,1)" --city {city} --category {category}

# 批量查询，多个用 ; 分隔
uv run tsp-ops-menu get product --query "(奶茶,0);(咖啡,1)" --city {city} --category {category}
```

---

## 功能四：操作清单

**操作前确认 `current_run_id`**（从会话状态取；若无，提示用户先执行 `list ranking`）。

所有操作只针对 `active_ranking` 对应的清单，除非用户明确指定另一个。

### 4.1 切换排名方式

**触发**："切换到订单空间排名"、"按机会品排"、"换成主站销量"

```bash
uv run tsp-ops-menu update ranking --run-id {run_id} --switch orders_main
uv run tsp-ops-menu update ranking --run-id {run_id} --switch order_space
```

目标排名不存在时，CLI 自动调服务端生成并重放 ops_log。更新 `active_ranking`，展示新清单 + 后置引导。

### 4.2 重新查询（切换价格带或数量）

重新调用 `list ranking --no-cache`，生成新 run_id，更新会话状态，展示新清单。

### 4.3 上聚（把多个本质词合并为一个条目）

**触发**："把咖啡类合并"、"把美式咖啡和拿铁合并成咖啡系列"

**流程**：
1. 根据语义判断要合并的词列表，建议命名（用户指定则用用户的），**告知用户确认后再执行**
2. 用户确认后：

```bash
uv run tsp-ops-menu update ranking --run-id {run_id} --op merge --del "美式咖啡;拿铁咖啡" --add 咖啡系列
```

展示变更部分（合并了哪些词、新条目在第几位）+ 后置引导。

### 4.4 下钻（展开某个本质词的子词）

**触发**："展开奶茶"、"把奶茶拆开"

**流程**：
1. 先查子词，让用户确认：

```bash
uv run tsp-ops-menu get product --query "(奶茶,1)" --city {city} --category {category}
```

2. 用户确认后执行展开（可通过 `--add` 指定要插入的子词名称，不指定则插入所有子词，代码会自动排序）：

```bash
uv run tsp-ops-menu update ranking --run-id {run_id} --op expand --del 奶茶
uv run tsp-ops-menu update ranking --run-id {run_id} --op expand --del 奶茶 --add "珍珠奶茶;芋泥奶茶"
```

展示变更部分（展开了哪个词、插入了哪些子词及其位置）+ 后置引导。

### 4.5 删除

**触发**："删掉豆浆"、"去掉豆浆"

```bash
uv run tsp-ops-menu update ranking --run-id {run_id} --op delete --del 豆浆
```

删除后自动从候选池补位，保持榜单数量为 top_n。展示更新后清单 + 后置引导。

### 4.6 撤销

**触发**："撤销"、"撤销上一步"、"↩️"

```bash
uv run tsp-ops-menu delete record --last --run-id {run_id}
```

撤销后展示当前清单 + 后置引导。若提示"没有可撤销的操作"，告知用户。

### 4.7 导出清单

**触发**："导出清单"、"导出 Excel"、"整理成表格"

```bash
uv run tsp-ops-menu export ranking --run-id {run_id}
```

**导出缓存检查**：导出前 CLI 会自动查询服务端是否有已标记缓存：
- 若服务端有缓存（CACHED）：CLI 输出提示"服务端已有该清单的缓存（...），是否覆盖？"。**Skill 端为非交互式，CLI 会输出提示后自动继续导出**（不阻塞）。Skill 应在输出中告知用户"已检测到服务端有缓存，本次导出将覆盖"。
- 若无缓存：直接导出。
**不能使用自己写excel的方式导出清单**。导出洞察商品清单必须走CLI调用服务端接口生成Excel文件并上传到S3，获取链接后返回给用户。

导出成功后服务端返回 S3 下载链接，告知用户链接，询问是否还有其他操作。

---

## 功能五：清理本地缓存

### 触发场景

"清理全部缓存"、"清空本地缓存"、等

### 执行流程

```bash
uv run tsp-ops-menu config clear-cache --yes
```

清理后告知用户"本地缓存已清空，下次查询将重新从服务端获取数据"。

---

## 注意事项

1. **缓存优先**：Skill 端默认使用本地缓存（不加 `--no-cache`）。用户明确要求"重新查询"时加 `--no-cache`。
2. **服务端缓存只读**：命中服务端 CACHED 数据时，数据来自已标记清单，无法强制重查。
3. **删除自动补位**：删除/上聚后自动从候选池补位，保持榜单数量为 top_n；候选池耗尽时条目数可小于 top_n
4. **新发现标记**：`is_new_find=true`（标准菜名为空）的品在表格标记列显示「🆕」
5. **必须完整展示清单**： 每次的top清单必须被完整展示，不管数据有多少，不管清单有多少列
6. **城市范围**：'郑州', '济南', '广州', '成都', '杭州', 如果用户输入其他城市，要提醒用户没有数据，并列出支持的城市列表。
7. **品类范围**：'西快小吃', '饮品甜点', '粉面粥饺', '饭类'，如果用户输入其他品类，要提醒用户没有数据，并列出支持的品类列表。
