# CLAUDE.md

This file provides guidance to Claude Code when working with the city-menu-insight project (api-v2).

这是一个skill项目，这个项目是要部署到聊天机器人中，让用户通过聊天工具回话。我也可以用接口与机器人回话。

city-menu-insight/SKILL.md 里的skill是发布的版本，不能使用uv run 并且加
```bash
uv tool install mt-city-menu-insight --upgrade
```
不能删

每次修改SKILL.md的时候要同步修改city-menu-insight/SKILL.md中的对应功能

所有与python有关的都要用uv，绝对不能碰系统python环境

## 安装 CLI

```bash
uv pip install -e .
```

所有命令通过 `uv run tsp-ops-menu` 执行。

## 鉴权

配置文件：`~/.local/share/tsp-ops/config.json`，存储 `mis` 字段。

Token 每次请求时通过 `@it/oa-skills-shared` 动态获取，自动缓存在 `~/.cache/openclaw-auth/auth-cache.json`。

```bash
# 写入 MIS ID
uv run tsp-ops-menu config set-mis {mis}
```

## CLI 命令

```bash
# 查询榜单（每次直接调服务端，无本地缓存）
uv run tsp-ops-menu list ranking --city 成都 --category 饭类 --top-n 50 --dt-window 30d --dt 20260406

# 展示已有榜单（直接读本地文件，不调服务端）
uv run tsp-ops-menu list ranking --run-id {run_id}

# 查询本质词指标（depth=0 聚合指标，depth=1 子词列表）；多个用 ; 分隔
uv run tsp-ops-menu get product --query "(奶茶,0);(咖啡,1)" --city 成都 --category 饮品甜点

# 修改榜单；多个词用 ; 分隔
uv run tsp-ops-menu update ranking --run-id {run_id} --op delete --del 豆浆
uv run tsp-ops-menu update ranking --run-id {run_id} --op merge --del "美式咖啡;拿铁咖啡" --add 咖啡系列
uv run tsp-ops-menu update ranking --run-id {run_id} --op expand --del 奶茶 --add "珍珠奶茶;芋泥奶茶"

# 切换排名维度（目标不存在时自动调服务端生成并重放 ops_log）
uv run tsp-ops-menu update ranking --run-id {run_id} --switch order_space
uv run tsp-ops-menu update ranking --run-id {run_id} --switch orders_main

# 撤销最后一步
uv run tsp-ops-menu delete record --last --run-id {run_id}

# 导出 Excel
uv run tsp-ops-menu export ranking --run-id {run_id}
```

## API 接口

| 功能 | 路径 |
|------|------|
| 查询榜单 | `POST /api/insight/opportunity/v1/list/query` |
| 查询本质词 | `POST /api/insight/opportunity/v1/product/query` |
| 导出 | `POST /api/insight/opportunity/v1/export` |
| 上报操作记录 | `POST /api/insight/opportunity/v1/record/create` |

**关键注意**：`maxPrice` 为 `None` 时不传该字段（传 `null` 后端返回空数据）。

## Item 字段说明（新接口）

| 字段 | 类型 | 说明 |
|------|------|------|
| `productName` | string | 聚合本质词（榜单展示单元） |
| `wmSales` | int | 主站销量 |
| `phfSales` | int | 拼好饭销量 |
| `tbsgSales` | int | TBSG 销量 |
| `wmOrderRatio` | float | 主站下单率（百分比，如 8.0 = 8%） |
| `phfOrderRatio` | float | 拼好饭下单率（百分比） |
| `tbsgOrderRatio` | float | TBSG 下单率（百分比） |
| `orderSpace` | float | 订单空间（百分比，可为负） |
| `wmAvgPrice` | float | 主站均价（元，可为 null） |
| `phfAvgPrice` | float | 拼好饭均价（元，可为 null） |
| `tbsgAvgPrice` | float | TBSG 均价（元，可为 null） |
| `standFoodName` | string | 标准菜名，空则 `is_new_find=true` |
| `rank` | int | 排名（ranking 列表中有，pool 中无） |

## 本地文件结构

```
~/.local/share/tsp-ops/
├── config.json                  # MIS ID 配置
└── outputs/
    └── {run_id}/
        ├── ranking.json          # 当前榜单（含 ops_log）
        ├── ranking_original.json # 原始榜单（只读，用于 undo 重放）
        └── snapshots/
            ├── meta.json
            └── v001.json, v002.json, ...
```
