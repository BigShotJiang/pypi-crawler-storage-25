# Security Policy

## Supported Versions

Security fixes are applied to the latest released `0.x` version unless a
separate support policy is published.

## Reporting a Vulnerability

Report suspected vulnerabilities privately by emailing Ruben J. Jongejan at
<ruben.jongejan@gmail.com>. Please include:

- Affected version or commit
- Reproduction steps
- Impact and affected deployment mode
- Any relevant logs or request examples with secrets redacted

Do not open public issues for vulnerabilities until a fix or mitigation is
available.

## Deployment Security Notes

- Treat Drayage as infrastructure in a trusted network unless you have placed
  it behind access controls.
- If upstream credentials are configured, secure the Drayage listener so those
  upstream permissions are not exposed to untrusted clients.
- Protect `ca.key` for TLS transparent proxy mode. Anyone with that key can
  mint certificates trusted by hosts that installed the Drayage CA.
- Prefer an allowlisted set of upstream registries and token realms. Current
  releases reject unconfigured explicit upstream registries.
