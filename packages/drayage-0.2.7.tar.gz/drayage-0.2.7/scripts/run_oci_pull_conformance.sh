#!/usr/bin/env bash
set -euo pipefail

if [[ "${1:-}" == "--help" ]]; then
  cat <<'EOF'
Run the official OCI Distribution conformance suite in pull-only mode
against a running Drayage instance.

Environment variables:
  OCI_ROOT_URL              Default: http://127.0.0.1:5001
  OCI_NAMESPACE             Default: registry.k8s.io/pause
  OCI_TAG_NAME              Default: 3.9
  OCI_CONFORMANCE_VERSION   Default: v1.1.1
  OCI_REPORT_DIR            Default: ./oci-conformance-results
EOF
  exit 0
fi

if ! command -v git >/dev/null 2>&1; then
  echo "git is required" >&2
  exit 1
fi

if ! command -v go >/dev/null 2>&1; then
  echo "go is required" >&2
  exit 1
fi

if ! command -v python3 >/dev/null 2>&1; then
  echo "python3 is required" >&2
  exit 1
fi

ROOT_URL="${OCI_ROOT_URL:-http://127.0.0.1:5001}"
NAMESPACE="${OCI_NAMESPACE:-registry.k8s.io/pause}"
TAG_NAME="${OCI_TAG_NAME:-3.9}"
CONFORMANCE_VERSION="${OCI_CONFORMANCE_VERSION:-v1.1.1}"
REPORT_DIR="${OCI_REPORT_DIR:-$(pwd)/oci-conformance-results}"

mkdir -p "${REPORT_DIR}"

eval "$(
  python3 scripts/resolve_oci_pull_fixture.py \
    --root-url "${ROOT_URL}" \
    --namespace "${NAMESPACE}" \
    --reference "${TAG_NAME}"
)"

WORKDIR="$(mktemp -d "${TMPDIR:-/tmp}/drayage-oci-conformance.XXXXXX")"
trap 'rm -rf "${WORKDIR}"' EXIT

git clone --depth 1 --branch "${CONFORMANCE_VERSION}" \
  https://github.com/opencontainers/distribution-spec.git \
  "${WORKDIR}/distribution-spec"

pushd "${WORKDIR}/distribution-spec/conformance" >/dev/null
go test -c
OCI_ROOT_URL="${ROOT_URL}" \
OCI_NAMESPACE="${NAMESPACE}" \
OCI_TAG_NAME="${TAG_NAME}" \
OCI_MANIFEST_DIGEST="${manifest_digest}" \
OCI_BLOB_DIGEST="${blob_digest}" \
OCI_TEST_PULL=1 \
OCI_HIDE_SKIPPED_WORKFLOWS="${OCI_HIDE_SKIPPED_WORKFLOWS:-1}" \
OCI_DEBUG="${OCI_DEBUG:-0}" \
OCI_REPORT_DIR="${REPORT_DIR}" \
./conformance.test
popd >/dev/null

echo "OCI pull conformance report written to ${REPORT_DIR}"
echo "Manifest digest: ${manifest_digest}"
echo "Blob digest: ${blob_digest}"
