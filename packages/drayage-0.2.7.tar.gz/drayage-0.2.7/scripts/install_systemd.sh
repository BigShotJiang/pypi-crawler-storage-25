#!/usr/bin/env bash
set -euo pipefail

if [[ "${1:-}" == "--help" ]]; then
  cat <<'EOF'
Install a locally built Drayage binary plus the example systemd unit.

Expected inputs:
  - target/release/drayage
  - deploy/systemd/drayage.service
  - config.example.toml

Environment overrides:
  BIN_SOURCE    default: target/release/drayage
  INSTALL_BIN   default: /usr/local/bin/drayage
  CONFIG_DIR    default: /etc/drayage
  CACHE_DIR     default: /var/cache/drayage
  SERVICE_PATH  default: /etc/systemd/system/drayage.service
  RUN_USER      default: drayage
  RUN_GROUP     default: drayage
  CONFIG_SOURCE default: config.example.toml
  SERVICE_SOURCE default: deploy/systemd/drayage.service
  NOLOGIN_BIN   default: /usr/sbin/nologin
EOF
  exit 0
fi

if [[ "$(uname -s)" != "Linux" ]]; then
  echo "This installer targets Linux + systemd." >&2
  exit 1
fi

if ! command -v systemctl >/dev/null 2>&1; then
  echo "systemctl is required." >&2
  exit 1
fi

if [[ "${EUID}" -ne 0 ]]; then
  echo "Run as root or with sudo." >&2
  exit 1
fi

BIN_SOURCE="${BIN_SOURCE:-target/release/drayage}"
INSTALL_BIN="${INSTALL_BIN:-/usr/local/bin/drayage}"
CONFIG_DIR="${CONFIG_DIR:-/etc/drayage}"
CACHE_DIR="${CACHE_DIR:-/var/cache/drayage}"
SERVICE_PATH="${SERVICE_PATH:-/etc/systemd/system/drayage.service}"
RUN_USER="${RUN_USER:-drayage}"
RUN_GROUP="${RUN_GROUP:-drayage}"
CONFIG_SOURCE="${CONFIG_SOURCE:-config.example.toml}"
SERVICE_SOURCE="${SERVICE_SOURCE:-deploy/systemd/drayage.service}"
NOLOGIN_BIN="${NOLOGIN_BIN:-/usr/sbin/nologin}"

if [[ ! -x "${BIN_SOURCE}" ]]; then
  echo "Missing executable ${BIN_SOURCE}. Build first with: cargo build --release" >&2
  exit 1
fi

if [[ ! -f "${CONFIG_SOURCE}" ]]; then
  echo "Missing ${CONFIG_SOURCE}" >&2
  exit 1
fi

if [[ ! -f "${SERVICE_SOURCE}" ]]; then
  echo "Missing ${SERVICE_SOURCE}" >&2
  exit 1
fi

if ! getent group "${RUN_GROUP}" >/dev/null; then
  groupadd --system "${RUN_GROUP}"
fi

if ! id "${RUN_USER}" >/dev/null 2>&1; then
  useradd --system --home /var/lib/drayage --shell "${NOLOGIN_BIN}" --gid "${RUN_GROUP}" "${RUN_USER}"
fi

install -d -m 0750 -o root -g "${RUN_GROUP}" "${CONFIG_DIR}"
install -d -m 0750 -o "${RUN_USER}" -g "${RUN_GROUP}" "${CACHE_DIR}"
install -m 0755 "${BIN_SOURCE}" "${INSTALL_BIN}"
install -m 0644 "${SERVICE_SOURCE}" "${SERVICE_PATH}"

if [[ ! -f "${CONFIG_DIR}/config.toml" ]]; then
  install -m 0640 -o root -g "${RUN_GROUP}" "${CONFIG_SOURCE}" "${CONFIG_DIR}/config.toml"
fi

systemctl daemon-reload

cat <<EOF
Installed Drayage.

Next steps:
  1. Edit ${CONFIG_DIR}/config.toml
     Set cache_dir = "${CACHE_DIR}"
  2. If using transparent TLS, place ca.crt and ca.key under ${CONFIG_DIR}/certs
  3. Start the service:
     sudo systemctl enable --now drayage
  4. Check readiness:
     curl -fsS http://127.0.0.1:5001/readyz
EOF
