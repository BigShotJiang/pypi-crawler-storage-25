#!/usr/bin/env python3
"""Resolve stable manifest/blob digests for OCI pull conformance."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import urllib.request

ACCEPT = ", ".join(
    [
        "application/vnd.oci.image.manifest.v1+json",
        "application/vnd.oci.image.index.v1+json",
        "application/vnd.docker.distribution.manifest.v2+json",
        "application/vnd.docker.distribution.manifest.list.v2+json",
    ]
)


def fetch_manifest(root_url: str, namespace: str, reference: str) -> tuple[dict, str]:
    url = f"{root_url.rstrip('/')}/v2/{namespace}/manifests/{reference}"
    req = urllib.request.Request(url, headers={"Accept": ACCEPT})
    with urllib.request.urlopen(req, timeout=30) as resp:
        body = resp.read()
        digest = resp.headers.get("Docker-Content-Digest")

    if digest is None:
        digest = f"sha256:{hashlib.sha256(body).hexdigest()}"

    try:
        payload = json.loads(body)
    except json.JSONDecodeError as exc:
        raise SystemExit(f"manifest response from {url} is not valid JSON: {exc}") from exc

    return payload, digest


def resolve_fixture(root_url: str, namespace: str, reference: str) -> tuple[str, str]:
    manifest, manifest_digest = fetch_manifest(root_url, namespace, reference)
    blob_source = manifest

    manifests = manifest.get("manifests")
    if manifests:
        child_digest = manifests[0]["digest"]
        blob_source, _ = fetch_manifest(root_url, namespace, child_digest)

    blob_digest = blob_source.get("config", {}).get("digest")
    if not blob_digest:
        layers = blob_source.get("layers") or []
        if layers:
            blob_digest = layers[0].get("digest")

    if not blob_digest:
        raise SystemExit(
            "unable to resolve a blob digest from manifest; expected config or layer digest"
        )

    return manifest_digest, blob_digest


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root-url", required=True)
    parser.add_argument("--namespace", required=True)
    parser.add_argument("--reference", required=True)
    args = parser.parse_args()

    manifest_digest, blob_digest = resolve_fixture(
        args.root_url, args.namespace, args.reference
    )
    print(f"manifest_digest={manifest_digest}")
    print(f"blob_digest={blob_digest}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
