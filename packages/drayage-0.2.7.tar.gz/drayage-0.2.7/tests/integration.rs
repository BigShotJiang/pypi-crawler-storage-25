use std::collections::HashMap;
use std::path::Path;
use std::sync::Arc;

use axum::Router;
use axum::body::Body;
use dashmap::DashMap;
use futures_util::future::join_all;
use http::Request;
use sha2::{Digest, Sha256};
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tower::ServiceExt;
use wiremock::matchers::{header, method, path};
use wiremock::{Mock, MockServer, ResponseTemplate, Times};

use drayage::AppState;
use drayage::cache::Cache;
use drayage::config::{Config, UpstreamConfig};
use drayage::metrics::Metrics;
use drayage::negative_cache::NegativeCache;
use drayage::server::build_router;
use drayage::upstream::UpstreamClient;

async fn setup() -> (Router, MockServer, tempfile::TempDir) {
    setup_with_ttl(900).await
}

async fn setup_with_ttl(ttl: u64) -> (Router, MockServer, tempfile::TempDir) {
    setup_with_options(ttl, 10_485_760).await
}

async fn setup_with_options(
    ttl: u64,
    max_manifest_bytes: u64,
) -> (Router, MockServer, tempfile::TempDir) {
    let (router, mock, dir, _cache) = setup_with_options_and_cache(ttl, max_manifest_bytes).await;
    (router, mock, dir)
}

fn build_router_from_config(config: Config) -> (Router, Arc<Cache>) {
    let config = Arc::new(config);
    let metrics = Arc::new(Metrics::default());
    let cache = Arc::new(Cache::new(&config.cache_dir, config.manifest_ttl_seconds, None).unwrap());
    let upstream = Arc::new(UpstreamClient::new(config.clone(), metrics.clone()));
    let negative_cache = Arc::new(NegativeCache::new(config.negative_ttl_seconds));

    let state = AppState {
        cache: cache.clone(),
        upstream,
        inflight: Arc::new(DashMap::new()),
        metrics,
        negative_cache,
        config,
        revalidation_tracker: Arc::new(DashMap::new()),
    };

    (build_router(state), cache)
}

async fn setup_with_options_and_cache(
    ttl: u64,
    max_manifest_bytes: u64,
) -> (Router, MockServer, tempfile::TempDir, Arc<Cache>) {
    let mock = MockServer::start().await;
    let dir = tempfile::TempDir::new().unwrap();

    let mut upstreams = HashMap::new();
    upstreams.insert(
        "docker_io".to_string(),
        UpstreamConfig {
            registry: mock.uri(),
            username: None,
            password: None,
            connect_timeout_secs: None,
            read_timeout_secs: None,
        },
    );

    let config = Config {
        listen: "unused:0".to_string(),
        cache_dir: dir.path().to_str().unwrap().to_string(),
        manifest_ttl_seconds: ttl,
        max_cache_bytes: None,
        eviction_interval_seconds: 300,
        connect_timeout_secs: 10,
        read_timeout_secs: 30,
        max_manifest_bytes,
        negative_ttl_seconds: 60,
        offline_mode: false,
        upstreams,
        tls_listen: None,
        ca_cert_path: None,
        ca_key_path: None,
    };

    let (router, cache) = build_router_from_config(config);
    (router, mock, dir, cache)
}

async fn setup_with_upstream_url(
    upstream_url: String,
    connect_timeout_secs: u64,
    read_timeout_secs: u64,
) -> (Router, tempfile::TempDir, Arc<Cache>) {
    let dir = tempfile::TempDir::new().unwrap();

    let mut upstreams = HashMap::new();
    upstreams.insert(
        "docker_io".to_string(),
        UpstreamConfig {
            registry: upstream_url,
            username: None,
            password: None,
            connect_timeout_secs: Some(connect_timeout_secs),
            read_timeout_secs: Some(read_timeout_secs),
        },
    );

    let config = Config {
        listen: "unused:0".to_string(),
        cache_dir: dir.path().to_str().unwrap().to_string(),
        manifest_ttl_seconds: 900,
        max_cache_bytes: None,
        eviction_interval_seconds: 300,
        connect_timeout_secs,
        read_timeout_secs,
        max_manifest_bytes: 10_485_760,
        negative_ttl_seconds: 60,
        offline_mode: false,
        upstreams,
        tls_listen: None,
        ca_cert_path: None,
        ca_key_path: None,
    };

    let (router, cache) = build_router_from_config(config);
    (router, dir, cache)
}

fn sha256_hex(data: &[u8]) -> String {
    format!("sha256:{}", hex::encode(Sha256::digest(data)))
}

fn mock_manifest(content: &[u8]) -> (String, ResponseTemplate) {
    let digest = sha256_hex(content);
    let resp = ResponseTemplate::new(200)
        .insert_header(
            "Content-Type",
            "application/vnd.docker.distribution.manifest.v2+json",
        )
        .insert_header("Docker-Content-Digest", digest.as_str())
        .set_body_bytes(content.to_vec());
    (digest, resp)
}

fn blob_cache_path(dir: &Path, digest: &str) -> std::path::PathBuf {
    dir.join("blobs/sha256")
        .join(digest.strip_prefix("sha256:").unwrap_or(digest))
}

async fn spawn_interrupted_blob_upstream(
    repo: &str,
    digest: &str,
    full_body: Vec<u8>,
    bytes_before_disconnect: usize,
) -> (String, tokio::task::JoinHandle<()>) {
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let addr = listener.local_addr().unwrap();
    let expected_path = format!("/v2/{repo}/blobs/{digest}");
    let handle = tokio::spawn(async move {
        let (mut stream, _) = listener.accept().await.unwrap();
        let mut request = vec![0u8; 4096];
        let n = stream.read(&mut request).await.unwrap();
        let request_text = String::from_utf8_lossy(&request[..n]);
        assert!(
            request_text.contains(&format!("GET {} HTTP/1.1", expected_path)),
            "unexpected upstream request: {}",
            request_text
        );

        let cut = bytes_before_disconnect.min(full_body.len());
        let response = format!(
            "HTTP/1.1 200 OK\r\nContent-Type: application/octet-stream\r\nContent-Length: {}\r\nConnection: close\r\n\r\n",
            full_body.len()
        );
        stream.write_all(response.as_bytes()).await.unwrap();
        stream.write_all(&full_body[..cut]).await.unwrap();
        let _ = stream.shutdown().await;
    });

    (format!("http://{}", addr), handle)
}

// --- v2 check ---

#[tokio::test]
async fn v2_check_endpoint() {
    let (router, _mock, _dir) = setup().await;

    let resp = router
        .oneshot(Request::builder().uri("/v2/").body(Body::empty()).unwrap())
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    assert_eq!(
        resp.headers()
            .get("Docker-Distribution-Api-Version")
            .unwrap(),
        "registry/2.0"
    );
}

// --- health check ---

#[tokio::test]
async fn health_endpoint() {
    let (router, _mock, _dir) = setup().await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/health")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    let parsed: serde_json::Value = serde_json::from_slice(&body).unwrap();
    assert_eq!(parsed["status"], "ok");
}

// --- healthz / readyz ---

#[tokio::test]
async fn healthz_endpoint() {
    let (router, _mock, _dir) = setup().await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/healthz")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    let parsed: serde_json::Value = serde_json::from_slice(&body).unwrap();
    assert_eq!(parsed["status"], "ok");
}

#[tokio::test]
async fn readyz_endpoint() {
    let (router, _mock, _dir) = setup().await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/readyz")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    let parsed: serde_json::Value = serde_json::from_slice(&body).unwrap();
    assert_eq!(parsed["status"], "ready");
}

// --- manifest tests ---

#[tokio::test]
async fn manifest_cache_miss_then_hit() {
    let (router, mock, _dir) = setup().await;

    let manifest = br#"{"schemaVersion":2,"mediaType":"application/vnd.docker.distribution.manifest.v2+json"}"#;
    let (digest, resp_template) = mock_manifest(manifest);
    let _ = digest; // used inside mock_manifest

    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/latest"))
        .respond_with(resp_template)
        .expect(1)
        .mount(&mock)
        .await;

    // First request — cache miss, upstream called
    let resp = router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(resp.status(), 200);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    assert_eq!(body.as_ref(), manifest);

    // Second request — cache hit, upstream NOT called
    let resp = router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(resp.status(), 200);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    assert_eq!(body.as_ref(), manifest);

    // Mock's expect(1) verifies upstream was called exactly once
}

#[tokio::test]
async fn manifest_head_request() {
    let (router, mock, _dir) = setup().await;

    let manifest = br#"{"schemaVersion":2}"#;
    let (_digest, resp_template) = mock_manifest(manifest);

    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/latest"))
        .respond_with(resp_template)
        .mount(&mock)
        .await;

    // GET to populate cache
    router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    // HEAD request
    let resp = router
        .clone()
        .oneshot(
            Request::builder()
                .method("HEAD")
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    let content_length: usize = resp
        .headers()
        .get("Content-Length")
        .unwrap()
        .to_str()
        .unwrap()
        .parse()
        .unwrap();
    assert_eq!(content_length, manifest.len());

    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    assert!(body.is_empty(), "HEAD response body should be empty");
}

#[tokio::test]
async fn manifest_404_from_upstream() {
    let (router, mock, _dir) = setup().await;

    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/v999"))
        .respond_with(ResponseTemplate::new(404))
        .mount(&mock)
        .await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/v999")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 404);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    let parsed: serde_json::Value = serde_json::from_slice(&body).unwrap();
    assert!(parsed["errors"].is_array());
    assert_eq!(parsed["errors"][0]["code"], "MANIFEST_NOT_FOUND");
}

#[tokio::test]
async fn manifest_upstream_500_returns_bad_gateway() {
    let (router, mock, _dir) = setup().await;

    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/latest"))
        .respond_with(ResponseTemplate::new(500))
        .mount(&mock)
        .await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 502);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    let parsed: serde_json::Value = serde_json::from_slice(&body).unwrap();
    assert_eq!(parsed["errors"][0]["code"], "UPSTREAM_ERROR");
}

#[tokio::test]
async fn manifest_fetch_by_digest() {
    let (router, mock, _dir) = setup().await;

    let manifest = br#"{"schemaVersion":2,"config":{}}"#;
    let digest = sha256_hex(manifest);
    let (_d, resp_template) = mock_manifest(manifest);

    Mock::given(method("GET"))
        .and(path(format!("/v2/library/alpine/manifests/{}", digest)))
        .respond_with(resp_template)
        .expect(1)
        .mount(&mock)
        .await;

    // Fetch by digest — first request hits upstream
    let resp = router
        .clone()
        .oneshot(
            Request::builder()
                .uri(format!("/v2/library/alpine/manifests/{}", digest))
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(resp.status(), 200);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    assert_eq!(body.as_ref(), manifest);

    // Second request — served from by-digest cache
    let resp = router
        .clone()
        .oneshot(
            Request::builder()
                .uri(format!("/v2/library/alpine/manifests/{}", digest))
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(resp.status(), 200);

    // Mock expect(1) confirms only one upstream call
}

#[tokio::test]
async fn manifest_ttl_expiry_triggers_refetch() {
    // TTL of 1 second so we can wait for it to expire
    let (router, mock, _dir) = setup_with_ttl(1).await;

    let manifest_v1 = br#"{"schemaVersion":2,"tag":"v1"}"#;
    let manifest_v2 = br#"{"schemaVersion":2,"tag":"v2"}"#;

    // First upstream response
    let (_d1, resp1) = mock_manifest(manifest_v1);
    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/latest"))
        .respond_with(resp1)
        .expect(1)
        .named("v1")
        .mount(&mock)
        .await;

    // Fetch v1
    let resp = router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(resp.status(), 200);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    assert_eq!(body.as_ref(), manifest_v1);

    // Wait for TTL to expire
    tokio::time::sleep(std::time::Duration::from_secs(2)).await;

    // Reset mock for v2 response
    mock.reset().await;
    let (_d2, resp2) = mock_manifest(manifest_v2);
    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/latest"))
        .respond_with(resp2)
        .expect(1)
        .named("v2")
        .mount(&mock)
        .await;

    // Fetch again — TTL expired, stale-while-revalidate serves v1 immediately
    // while spawning a background task to fetch v2
    let resp = router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(resp.status(), 200);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    assert_eq!(
        body.as_ref(),
        manifest_v1,
        "stale response serves cached v1"
    );

    // Wait for background revalidation to complete
    tokio::time::sleep(std::time::Duration::from_secs(1)).await;

    // Next request gets the freshly revalidated v2
    let resp = router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(resp.status(), 200);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    assert_eq!(body.as_ref(), manifest_v2, "after revalidation, serves v2");
}

// --- blob tests ---

#[tokio::test]
async fn blob_cache_miss_then_hit() {
    let (router, mock, _dir) = setup().await;

    let blob = b"hello blob world";
    let digest = sha256_hex(blob);

    Mock::given(method("GET"))
        .and(path(format!("/v2/library/alpine/blobs/{}", digest)))
        .respond_with(ResponseTemplate::new(200).set_body_bytes(blob.to_vec()))
        .expect(1)
        .mount(&mock)
        .await;

    // First request — upstream fetch + cache write
    let resp = router
        .clone()
        .oneshot(
            Request::builder()
                .uri(format!("/v2/library/alpine/blobs/{}", digest))
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(resp.status(), 200);

    // Second request — served from cache
    let resp = router
        .clone()
        .oneshot(
            Request::builder()
                .uri(format!("/v2/library/alpine/blobs/{}", digest))
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(resp.status(), 200);

    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    assert_eq!(body.as_ref(), blob);
}

#[tokio::test]
async fn blob_served_from_pre_populated_cache() {
    let (router, _mock, dir) = setup().await;

    let blob = b"pre-populated blob data";
    let digest = sha256_hex(blob);
    let hash = digest.strip_prefix("sha256:").unwrap();

    // Write blob directly to cache directory
    std::fs::write(dir.path().join("blobs/sha256").join(hash), blob).unwrap();

    let resp = router
        .oneshot(
            Request::builder()
                .uri(format!("/v2/library/alpine/blobs/{}", digest))
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    assert_eq!(body.as_ref(), blob);
}

#[tokio::test]
async fn blob_head_request() {
    let (router, mock, _dir) = setup().await;

    let blob = b"blob for head test";
    let digest = sha256_hex(blob);

    Mock::given(method("GET"))
        .and(path(format!("/v2/library/alpine/blobs/{}", digest)))
        .respond_with(ResponseTemplate::new(200).set_body_bytes(blob.to_vec()))
        .mount(&mock)
        .await;

    // GET to populate cache
    router
        .clone()
        .oneshot(
            Request::builder()
                .uri(format!("/v2/library/alpine/blobs/{}", digest))
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    // HEAD request
    let resp = router
        .clone()
        .oneshot(
            Request::builder()
                .method("HEAD")
                .uri(format!("/v2/library/alpine/blobs/{}", digest))
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    let content_length: usize = resp
        .headers()
        .get("Content-Length")
        .unwrap()
        .to_str()
        .unwrap()
        .parse()
        .unwrap();
    assert_eq!(content_length, blob.len());
    assert_eq!(
        resp.headers().get("Docker-Content-Digest").unwrap(),
        digest.as_str()
    );

    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    assert!(body.is_empty(), "HEAD response body should be empty");
}

#[tokio::test]
async fn blob_upstream_500_returns_bad_gateway() {
    let (router, mock, _dir) = setup().await;

    let digest = "sha256:0000000000000000000000000000000000000000000000000000000000000000";

    Mock::given(method("GET"))
        .and(path(format!("/v2/library/alpine/blobs/{}", digest)))
        .respond_with(ResponseTemplate::new(500))
        .mount(&mock)
        .await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri(format!("/v2/library/alpine/blobs/{}", digest))
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 502);
}

// --- routing ---

#[tokio::test]
async fn unknown_v2_path_returns_404() {
    let (router, _mock, _dir) = setup().await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/v2/not/a/valid/endpoint")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 404);
}

#[tokio::test]
async fn non_v2_path_returns_404() {
    let (router, _mock, _dir) = setup().await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/nonexistent")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 404);
}

// --- metrics ---

#[tokio::test]
async fn metrics_endpoint_contains_counters() {
    let (router, mock, _dir) = setup().await;

    let manifest = br#"{"schemaVersion":2}"#;
    let (_digest, resp_template) = mock_manifest(manifest);

    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/latest"))
        .respond_with(resp_template)
        .mount(&mock)
        .await;

    // Generate some metrics
    router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    // Fetch metrics
    let resp = router
        .oneshot(
            Request::builder()
                .uri("/metrics")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    let text = String::from_utf8(body.to_vec()).unwrap();

    assert!(text.contains("drayage_manifest_cache_misses_total 1"));
    assert!(text.contains("drayage_upstream_fetches_total 1"));
}

#[tokio::test]
async fn metrics_track_cache_hits() {
    let (router, mock, _dir) = setup().await;

    let manifest = br#"{"schemaVersion":2}"#;
    let (_digest, resp_template) = mock_manifest(manifest);

    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/latest"))
        .respond_with(resp_template)
        .mount(&mock)
        .await;

    // Miss
    router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    // Hit
    router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/metrics")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    let text = String::from_utf8(body.to_vec()).unwrap();

    assert!(
        text.contains("drayage_manifest_cache_hits_total 1"),
        "expected 1 cache hit: {}",
        text
    );
    assert!(
        text.contains("drayage_manifest_cache_misses_total 1"),
        "expected 1 cache miss: {}",
        text
    );
}

#[tokio::test]
async fn metrics_contain_histogram_lines() {
    let (router, mock, _dir) = setup().await;

    let manifest = br#"{"schemaVersion":2,"histogram":"test"}"#;
    let (_digest, resp_template) = mock_manifest(manifest);

    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/latest"))
        .respond_with(resp_template)
        .mount(&mock)
        .await;

    // Trigger a manifest fetch to record a histogram observation
    router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    // Fetch metrics
    let resp = router
        .oneshot(
            Request::builder()
                .uri("/metrics")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    let text = String::from_utf8(body.to_vec()).unwrap();

    // Verify manifest histogram structure is present with registry label
    assert!(
        text.contains("# TYPE drayage_upstream_manifest_duration_seconds histogram"),
        "missing manifest histogram TYPE line: {text}"
    );
    assert!(
        text.contains(
            "drayage_upstream_manifest_duration_seconds_bucket{registry=\"docker_io\",le=\"0.005\"}"
        ),
        "missing manifest histogram bucket line with registry label: {text}"
    );
    assert!(
        text.contains(
            "drayage_upstream_manifest_duration_seconds_bucket{registry=\"docker_io\",le=\"+Inf\"}"
        ),
        "missing manifest histogram +Inf bucket with registry label: {text}"
    );
    assert!(
        text.contains("drayage_upstream_manifest_duration_seconds_count{registry=\"docker_io\"} 1"),
        "manifest histogram count should be 1 after one fetch: {text}"
    );

    // Verify blob histogram HELP/TYPE is present (no observations, so no bucket lines)
    assert!(
        text.contains("# TYPE drayage_upstream_blob_duration_seconds histogram"),
        "missing blob histogram TYPE line: {text}"
    );
    assert!(
        !text.contains("drayage_upstream_blob_duration_seconds_bucket"),
        "blob histogram should have no bucket lines with zero observations: {text}"
    );
}

// --- request coalescing ---

#[tokio::test]
async fn concurrent_manifest_requests_coalesce() {
    let (router, mock, _dir) = setup().await;

    let manifest = br#"{"schemaVersion":2,"coalesce":"test"}"#;
    let (_digest, resp_template) = mock_manifest(manifest);

    // Add a delay to the mock so concurrent requests have time to coalesce
    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/latest"))
        .respond_with(resp_template.set_delay(std::time::Duration::from_millis(100)))
        .expect(1)
        .mount(&mock)
        .await;

    // Fire multiple concurrent requests
    let futs: Vec<_> = (0..5)
        .map(|_| {
            let r = router.clone();
            tokio::spawn(async move {
                r.oneshot(
                    Request::builder()
                        .uri("/v2/library/alpine/manifests/latest")
                        .body(Body::empty())
                        .unwrap(),
                )
                .await
                .unwrap()
            })
        })
        .collect();

    let results: Vec<_> = futures_util::future::join_all(futs).await;
    for result in results {
        let resp = result.unwrap();
        assert_eq!(resp.status(), 200);
    }

    // Mock expect(1) confirms only a single upstream call despite 5 concurrent requests
}

// --- TOCTOU / eviction-during-read tests ---

#[tokio::test]
async fn blob_evicted_after_cache_hit_falls_through_to_upstream() {
    let (router, mock, dir) = setup().await;

    let blob = b"eviction-race-blob";
    let digest = sha256_hex(blob);
    let hash = digest.strip_prefix("sha256:").unwrap();

    // Pre-populate cache so the first request sees a cache hit
    std::fs::write(dir.path().join("blobs/sha256").join(hash), blob).unwrap();

    // Verify blob is served from cache
    let resp = router
        .clone()
        .oneshot(
            Request::builder()
                .uri(format!("/v2/library/alpine/blobs/{}", digest))
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(resp.status(), 200);

    // Simulate eviction: delete the cached blob
    std::fs::remove_file(dir.path().join("blobs/sha256").join(hash)).unwrap();

    // Set up upstream mock so the next request can fall through
    Mock::given(method("GET"))
        .and(path(format!("/v2/library/alpine/blobs/{}", digest)))
        .respond_with(ResponseTemplate::new(200).set_body_bytes(blob.to_vec()))
        .expect(1)
        .mount(&mock)
        .await;

    // Request again — blob was evicted, should fall through to upstream
    let resp = router
        .clone()
        .oneshot(
            Request::builder()
                .uri(format!("/v2/library/alpine/blobs/{}", digest))
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    assert_eq!(body.as_ref(), blob);
}

#[tokio::test]
async fn blob_head_on_evicted_blob_falls_through_to_upstream() {
    let (router, mock, dir) = setup().await;

    let blob = b"head-eviction-test";
    let digest = sha256_hex(blob);
    let hash = digest.strip_prefix("sha256:").unwrap();

    // Pre-populate, then delete (simulating eviction)
    std::fs::write(dir.path().join("blobs/sha256").join(hash), blob).unwrap();
    std::fs::remove_file(dir.path().join("blobs/sha256").join(hash)).unwrap();

    // Upstream available for fallthrough
    Mock::given(method("GET"))
        .and(path(format!("/v2/library/alpine/blobs/{}", digest)))
        .respond_with(ResponseTemplate::new(200).set_body_bytes(blob.to_vec()))
        .mount(&mock)
        .await;

    // HEAD request on a missing (evicted) blob — should succeed via upstream fetch
    let resp = router
        .clone()
        .oneshot(
            Request::builder()
                .method("HEAD")
                .uri(format!("/v2/library/alpine/blobs/{}", digest))
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    let content_length: usize = resp
        .headers()
        .get("Content-Length")
        .unwrap()
        .to_str()
        .unwrap()
        .parse()
        .unwrap();
    assert_eq!(content_length, blob.len());
}

// --- retry tests ---

#[tokio::test]
async fn manifest_upstream_503_retries_and_succeeds() {
    let (router, mock, _dir) = setup().await;

    let manifest = br#"{"schemaVersion":2,"retry":"manifest"}"#;
    let (_digest, resp_template) = mock_manifest(manifest);

    // First response: 503 (transient failure)
    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/latest"))
        .respond_with(ResponseTemplate::new(503))
        .up_to_n_times(1)
        .expect(1)
        .mount(&mock)
        .await;

    // Second response: 200 (success after retry)
    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/latest"))
        .respond_with(resp_template)
        .expect(1)
        .mount(&mock)
        .await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    assert_eq!(body.as_ref(), manifest);
}

#[tokio::test]
async fn blob_upstream_503_retries_and_succeeds() {
    let (router, mock, _dir) = setup().await;

    let blob = b"retry-blob-data";
    let digest = sha256_hex(blob);

    // First response: 503 (transient failure)
    Mock::given(method("GET"))
        .and(path(format!("/v2/library/alpine/blobs/{}", digest)))
        .respond_with(ResponseTemplate::new(503))
        .up_to_n_times(1)
        .expect(1)
        .mount(&mock)
        .await;

    // Second response: 200 (success after retry)
    Mock::given(method("GET"))
        .and(path(format!("/v2/library/alpine/blobs/{}", digest)))
        .respond_with(ResponseTemplate::new(200).set_body_bytes(blob.to_vec()))
        .expect(1)
        .mount(&mock)
        .await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri(format!("/v2/library/alpine/blobs/{}", digest))
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    assert_eq!(body.as_ref(), blob);
}

#[tokio::test]
async fn manifest_upstream_persistent_503_returns_bad_gateway() {
    let (router, mock, _dir) = setup().await;

    // All responses: 503 (persistent failure, exhausts all retries)
    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/latest"))
        .respond_with(ResponseTemplate::new(503))
        .expect(Times::from(3..))
        .mount(&mock)
        .await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    // After exhausting retries, upstream 503 is returned as 502 Bad Gateway
    assert_eq!(resp.status(), 502);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    let parsed: serde_json::Value = serde_json::from_slice(&body).unwrap();
    assert_eq!(parsed["errors"][0]["code"], "UPSTREAM_ERROR");
}

// --- load / chaos tests ---

#[tokio::test]
async fn manifest_upstream_connection_refused_returns_bad_gateway() {
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let addr = listener.local_addr().unwrap();
    drop(listener);

    let (router, _dir, _cache) = setup_with_upstream_url(format!("http://{}", addr), 1, 1).await;

    let resp = tokio::time::timeout(
        std::time::Duration::from_secs(5),
        router.oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        ),
    )
    .await
    .expect("request should complete")
    .unwrap();

    assert_eq!(resp.status(), 502);
}

#[tokio::test]
async fn blob_fetch_fails_under_disk_pressure_and_leaves_no_partial_cache() {
    let (router, mock, dir, cache) = setup_with_options_and_cache(900, 10_485_760).await;
    cache.set_disk_available_bytes_override_for_tests(Some(1024));

    let blob = vec![0x5a; 128 * 1024];
    let digest = sha256_hex(&blob);

    Mock::given(method("GET"))
        .and(path(format!("/v2/library/alpine/blobs/{}", digest)))
        .respond_with(ResponseTemplate::new(200).set_body_bytes(blob.clone()))
        .expect(1)
        .mount(&mock)
        .await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri(format!("/v2/library/alpine/blobs/{}", digest))
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 502);

    let cache_path = blob_cache_path(dir.path(), &digest);
    assert!(
        !cache_path.exists(),
        "blob must not be cached on disk-pressure failure"
    );
    assert!(
        !cache_path.with_extension("tmp").exists(),
        "temporary blob file must be removed on disk-pressure failure"
    );
}

#[tokio::test]
async fn blob_interrupted_upstream_download_returns_bad_gateway_and_cleans_tmp() {
    let blob = vec![0x41; 256 * 1024];
    let digest = sha256_hex(&blob);
    let (upstream_url, upstream_task) =
        spawn_interrupted_blob_upstream("library/alpine", &digest, blob, 32 * 1024).await;
    let (router, dir, _cache) = setup_with_upstream_url(upstream_url, 1, 2).await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri(format!("/v2/library/alpine/blobs/{}", digest))
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 502);
    upstream_task.await.unwrap();

    let cache_path = blob_cache_path(dir.path(), &digest);
    assert!(
        !cache_path.exists(),
        "interrupted downloads must not leave a cached blob behind"
    );
    assert!(
        !cache_path.with_extension("tmp").exists(),
        "interrupted downloads must clean up temporary blob files"
    );
}

#[tokio::test]
async fn concurrent_blob_requests_with_interrupted_upstream_leave_no_partial_cache() {
    let blob = vec![0x24; 192 * 1024];
    let digest = sha256_hex(&blob);
    let (upstream_url, upstream_task) =
        spawn_interrupted_blob_upstream("library/alpine", &digest, blob, 16 * 1024).await;
    let (router, dir, _cache) = setup_with_upstream_url(upstream_url, 1, 2).await;

    let responses = join_all((0..8).map(|_| {
        router.clone().oneshot(
            Request::builder()
                .uri(format!("/v2/library/alpine/blobs/{}", digest))
                .body(Body::empty())
                .unwrap(),
        )
    }))
    .await;

    for response in responses {
        let resp = response.unwrap();
        assert_eq!(resp.status(), 502);
    }

    upstream_task.await.unwrap();

    let cache_path = blob_cache_path(dir.path(), &digest);
    assert!(
        !cache_path.exists(),
        "coalesced interrupted downloads must not leave a cached blob behind"
    );
    assert!(
        !cache_path.with_extension("tmp").exists(),
        "coalesced interrupted downloads must clean up temporary blob files"
    );
}

// --- stale-while-revalidate tests ---

#[tokio::test]
async fn manifest_stale_while_revalidate_serves_stale() {
    // TTL of 1 second so we can trigger staleness quickly
    let (router, mock, _dir) = setup_with_ttl(1).await;

    let manifest_v1 = br#"{"schemaVersion":2,"tag":"v1-stale"}"#;
    let manifest_v2 = br#"{"schemaVersion":2,"tag":"v2-fresh"}"#;

    // Mount v1 response
    let (_d1, resp1) = mock_manifest(manifest_v1);
    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/latest"))
        .respond_with(resp1)
        .expect(1)
        .named("v1-initial")
        .mount(&mock)
        .await;

    // Fetch v1 to populate cache
    let resp = router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(resp.status(), 200);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    assert_eq!(body.as_ref(), manifest_v1);

    // Wait for TTL to expire
    tokio::time::sleep(std::time::Duration::from_secs(2)).await;

    // Reset mock — now return v2 for the background revalidation
    mock.reset().await;
    let (_d2, resp2) = mock_manifest(manifest_v2);
    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/latest"))
        .respond_with(resp2)
        .expect(1)
        .named("v2-revalidate")
        .mount(&mock)
        .await;

    // Request while stale — should get v1 immediately (stale data served)
    let resp = router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(resp.status(), 200);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    assert_eq!(
        body.as_ref(),
        manifest_v1,
        "stale request should serve cached v1 data immediately"
    );

    // Wait for background revalidation to complete
    tokio::time::sleep(std::time::Duration::from_secs(1)).await;

    // Next request should get the freshly revalidated v2 data
    let resp = router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(resp.status(), 200);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    assert_eq!(
        body.as_ref(),
        manifest_v2,
        "after background revalidation, should serve fresh v2 data"
    );
}

#[tokio::test]
async fn manifest_stale_revalidate_metric_incremented() {
    let (router, mock, _dir) = setup_with_ttl(1).await;

    let manifest = br#"{"schemaVersion":2,"tag":"stale-metric"}"#;
    let (_d, resp_template) = mock_manifest(manifest);

    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/latest"))
        .respond_with(resp_template)
        .mount(&mock)
        .await;

    // Populate cache
    router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    // Wait for TTL to expire
    tokio::time::sleep(std::time::Duration::from_secs(2)).await;

    // Request stale manifest
    router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    // Wait for background revalidation
    tokio::time::sleep(std::time::Duration::from_millis(500)).await;

    // Check metrics
    let resp = router
        .oneshot(
            Request::builder()
                .uri("/metrics")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    let text = String::from_utf8(body.to_vec()).unwrap();

    assert!(
        text.contains("drayage_manifest_stale_revalidates_total 1"),
        "expected 1 stale revalidate, metrics: {}",
        text
    );
}

// --- max_manifest_bytes tests ---

#[tokio::test]
async fn manifest_exceeding_size_limit_returns_bad_gateway() {
    // Set a very small limit (50 bytes)
    let (router, mock, _dir) = setup_with_options(900, 50).await;

    // Create a manifest larger than the 50-byte limit
    let large_manifest = br#"{"schemaVersion":2,"mediaType":"application/vnd.docker.distribution.manifest.v2+json","config":{"digest":"sha256:abc","size":100}}"#;
    assert!(
        large_manifest.len() > 50,
        "test manifest must exceed the configured limit"
    );

    let digest = sha256_hex(large_manifest);
    let resp_template = ResponseTemplate::new(200)
        .insert_header(
            "Content-Type",
            "application/vnd.docker.distribution.manifest.v2+json",
        )
        .insert_header("Docker-Content-Digest", digest.as_str())
        .set_body_bytes(large_manifest.to_vec());

    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/latest"))
        .respond_with(resp_template)
        .mount(&mock)
        .await;

    let resp = router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 502);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    let parsed: serde_json::Value = serde_json::from_slice(&body).unwrap();
    assert_eq!(parsed["errors"][0]["code"], "UPSTREAM_ERROR");
}

#[tokio::test]
async fn manifest_within_size_limit_succeeds() {
    // Set a generous limit (10 KB)
    let (router, mock, _dir) = setup_with_options(900, 10_240).await;

    let manifest = br#"{"schemaVersion":2,"mediaType":"application/vnd.docker.distribution.manifest.v2+json"}"#;
    assert!(
        (manifest.len() as u64) <= 10_240,
        "test manifest must be within the configured limit"
    );

    let (_digest, resp_template) = mock_manifest(manifest);

    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/latest"))
        .respond_with(resp_template)
        .mount(&mock)
        .await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    assert_eq!(body.as_ref(), manifest);
}

#[tokio::test]
async fn manifest_size_limit_zero_means_unlimited() {
    // max_manifest_bytes = 0 should allow any size
    let (router, mock, _dir) = setup_with_options(900, 0).await;

    let large_manifest = br#"{"schemaVersion":2,"mediaType":"application/vnd.docker.distribution.manifest.v2+json","config":{"digest":"sha256:abc","size":100}}"#;
    let (_digest, resp_template) = mock_manifest(large_manifest);

    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/latest"))
        .respond_with(resp_template)
        .mount(&mock)
        .await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    assert_eq!(body.as_ref(), large_manifest);
}

#[tokio::test]
async fn manifest_size_rejected_metric_incremented() {
    let (router, mock, _dir) = setup_with_options(900, 50).await;

    let large_manifest = br#"{"schemaVersion":2,"mediaType":"application/vnd.docker.distribution.manifest.v2+json","config":{"digest":"sha256:abc","size":100}}"#;
    let digest = sha256_hex(large_manifest);
    let resp_template = ResponseTemplate::new(200)
        .insert_header(
            "Content-Type",
            "application/vnd.docker.distribution.manifest.v2+json",
        )
        .insert_header("Docker-Content-Digest", digest.as_str())
        .set_body_bytes(large_manifest.to_vec());

    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/latest"))
        .respond_with(resp_template)
        .mount(&mock)
        .await;

    // Trigger the oversized manifest fetch
    router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    // Check metrics
    let resp = router
        .oneshot(
            Request::builder()
                .uri("/metrics")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    let text = String::from_utf8(body.to_vec()).unwrap();

    assert!(
        text.contains("drayage_manifest_size_rejected_total 1"),
        "expected 1 manifest size rejection, metrics: {}",
        text
    );
}

// --- circuit breaker tests ---

#[tokio::test]
async fn circuit_breaker_trips_after_consecutive_failures() {
    let (router, mock, _dir) = setup().await;

    // Mount a mock that returns 500 for every request.
    // We expect exactly 5 requests (the threshold) to reach the mock.
    // The 6th request should be blocked by the circuit breaker.
    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/latest"))
        .respond_with(ResponseTemplate::new(500))
        .expect(5)
        .mount(&mock)
        .await;

    // Send 5 requests — each triggers a 500 from upstream and records a failure
    for i in 0..5 {
        let resp = router
            .clone()
            .oneshot(
                Request::builder()
                    .uri("/v2/library/alpine/manifests/latest")
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(
            resp.status(),
            502,
            "request {} should return 502 (upstream 500)",
            i + 1
        );
    }

    // 6th request — circuit breaker is open, should NOT hit the mock
    let resp = router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(
        resp.status(),
        502,
        "6th request should return 502 (circuit breaker open)"
    );

    // Verify metrics: circuit breaker should have tripped once
    let resp = router
        .oneshot(
            Request::builder()
                .uri("/metrics")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    let text = String::from_utf8(body.to_vec()).unwrap();
    assert!(
        text.contains("drayage_circuit_breaker_trips_total 1"),
        "expected 1 circuit breaker trip, metrics: {}",
        text
    );

    // Mock's expect(5) verifies that the mock was hit exactly 5 times,
    // confirming the 6th request was blocked by the circuit breaker.
}

// --- 410 Gone tests ---

#[tokio::test]
async fn manifest_410_from_upstream_returns_404() {
    let (router, mock, _dir) = setup().await;

    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/gone-tag"))
        .respond_with(ResponseTemplate::new(410))
        .mount(&mock)
        .await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/gone-tag")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 404);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    let parsed: serde_json::Value = serde_json::from_slice(&body).unwrap();
    assert_eq!(parsed["errors"][0]["code"], "MANIFEST_NOT_FOUND");
}

#[tokio::test]
async fn blob_410_from_upstream_returns_404() {
    let (router, mock, _dir) = setup().await;

    let digest = "sha256:0000000000000000000000000000000000000000000000000000000000000001";

    Mock::given(method("GET"))
        .and(path(format!("/v2/library/alpine/blobs/{}", digest)))
        .respond_with(ResponseTemplate::new(410))
        .mount(&mock)
        .await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri(format!("/v2/library/alpine/blobs/{}", digest))
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 404);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    let parsed: serde_json::Value = serde_json::from_slice(&body).unwrap();
    assert_eq!(parsed["errors"][0]["code"], "BLOB_NOT_FOUND");
}

// --- blob 404 test ---

#[tokio::test]
async fn blob_404_from_upstream() {
    let (router, mock, _dir) = setup().await;

    let digest = "sha256:0000000000000000000000000000000000000000000000000000000000000002";

    Mock::given(method("GET"))
        .and(path(format!("/v2/library/alpine/blobs/{}", digest)))
        .respond_with(ResponseTemplate::new(404))
        .mount(&mock)
        .await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri(format!("/v2/library/alpine/blobs/{}", digest))
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 404);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    let parsed: serde_json::Value = serde_json::from_slice(&body).unwrap();
    assert_eq!(parsed["errors"][0]["code"], "BLOB_NOT_FOUND");
}

// --- stale-while-revalidate upstream failure tests ---

#[tokio::test]
async fn stale_revalidate_upstream_failure_preserves_cache() {
    // If the background revalidation fails, the stale data should still be served
    let (router, mock, _dir) = setup_with_ttl(1).await;

    let manifest = br#"{"schemaVersion":2,"tag":"resilient"}"#;
    let (_d, resp_template) = mock_manifest(manifest);

    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/latest"))
        .respond_with(resp_template)
        .expect(1)
        .mount(&mock)
        .await;

    // Populate cache
    let resp = router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(resp.status(), 200);

    // Wait for TTL to expire
    tokio::time::sleep(std::time::Duration::from_secs(2)).await;

    // Mount a 500 for the background revalidation
    mock.reset().await;
    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/latest"))
        .respond_with(ResponseTemplate::new(500))
        .mount(&mock)
        .await;

    // Request stale — should serve cached manifest, trigger background revalidation (which fails)
    let resp = router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(resp.status(), 200);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    assert_eq!(
        body.as_ref(),
        manifest,
        "stale data should still be served even though revalidation will fail"
    );

    // Wait for background task
    tokio::time::sleep(std::time::Duration::from_secs(1)).await;

    // Cache should still have the old manifest (not corrupted by failed revalidation)
    // Need to wait for TTL again since the stale request happened just now
    tokio::time::sleep(std::time::Duration::from_secs(2)).await;

    // Mount a fresh 200 this time
    mock.reset().await;
    let (_d2, resp2) = mock_manifest(manifest);
    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/latest"))
        .respond_with(resp2)
        .mount(&mock)
        .await;

    // Should still serve the original manifest (stale) and trigger another revalidation
    let resp = router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(resp.status(), 200);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    assert_eq!(
        body.as_ref(),
        manifest,
        "original manifest should be preserved after failed revalidation"
    );
}

// --- Auth denial tests (401/403 → 404) ---

#[tokio::test]
async fn manifest_upstream_401_without_auth_header_returns_404() {
    let (router, mock, _dir) = setup().await;

    // Upstream returns 401 without WWW-Authenticate — no auth flow possible
    Mock::given(method("GET"))
        .and(path("/v2/library/private/manifests/latest"))
        .respond_with(ResponseTemplate::new(401))
        .mount(&mock)
        .await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/v2/library/private/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 404);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    let parsed: serde_json::Value = serde_json::from_slice(&body).unwrap();
    assert_eq!(parsed["errors"][0]["code"], "MANIFEST_NOT_FOUND");
}

#[tokio::test]
async fn manifest_upstream_403_returns_404() {
    let (router, mock, _dir) = setup().await;

    Mock::given(method("GET"))
        .and(path("/v2/library/forbidden/manifests/latest"))
        .respond_with(ResponseTemplate::new(403))
        .mount(&mock)
        .await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/v2/library/forbidden/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 404);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    let parsed: serde_json::Value = serde_json::from_slice(&body).unwrap();
    assert_eq!(parsed["errors"][0]["code"], "MANIFEST_NOT_FOUND");
}

#[tokio::test]
async fn blob_upstream_401_returns_404() {
    let (router, mock, _dir) = setup().await;

    let digest = "sha256:0000000000000000000000000000000000000000000000000000000000000003";

    Mock::given(method("GET"))
        .and(path(format!("/v2/library/private/blobs/{}", digest)))
        .respond_with(ResponseTemplate::new(401))
        .mount(&mock)
        .await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri(format!("/v2/library/private/blobs/{}", digest))
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 404);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    let parsed: serde_json::Value = serde_json::from_slice(&body).unwrap();
    assert_eq!(parsed["errors"][0]["code"], "BLOB_NOT_FOUND");
}

#[tokio::test]
async fn blob_upstream_403_returns_404() {
    let (router, mock, _dir) = setup().await;

    let digest = "sha256:0000000000000000000000000000000000000000000000000000000000000004";

    Mock::given(method("GET"))
        .and(path(format!("/v2/library/forbidden/blobs/{}", digest)))
        .respond_with(ResponseTemplate::new(403))
        .mount(&mock)
        .await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri(format!("/v2/library/forbidden/blobs/{}", digest))
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 404);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    let parsed: serde_json::Value = serde_json::from_slice(&body).unwrap();
    assert_eq!(parsed["errors"][0]["code"], "BLOB_NOT_FOUND");
}

#[tokio::test]
async fn manifest_token_endpoint_403_returns_404() {
    // Simulate: upstream returns 401 with WWW-Authenticate pointing to a
    // token endpoint that returns 403 (private/inaccessible image).
    let (router, mock, _dir) = setup().await;

    // Token endpoint returns 403
    Mock::given(method("GET"))
        .and(path("/token"))
        .respond_with(
            ResponseTemplate::new(403).set_body_string(
                r#"{"errors":[{"code":"DENIED","message":"requested access to the resource is denied"}]}"#,
            ),
        )
        .mount(&mock)
        .await;

    // Manifest endpoint returns 401 with WWW-Authenticate pointing to our mock token endpoint
    let auth_header = format!(
        r#"Bearer realm="{}/token",service="registry.docker.io",scope="repository:library/private:pull""#,
        mock.uri()
    );
    Mock::given(method("GET"))
        .and(path("/v2/library/private/manifests/latest"))
        .respond_with(
            ResponseTemplate::new(401).insert_header("WWW-Authenticate", auth_header.as_str()),
        )
        .mount(&mock)
        .await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/v2/library/private/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(
        resp.status(),
        404,
        "token endpoint 403 should result in 404 to client"
    );
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    let parsed: serde_json::Value = serde_json::from_slice(&body).unwrap();
    assert_eq!(parsed["errors"][0]["code"], "MANIFEST_NOT_FOUND");
}

// --- Client auth forwarding tests ---

#[tokio::test]
async fn manifest_client_auth_forwarded_to_upstream() {
    let (router, mock, _dir) = setup().await;

    let manifest_body = b"authed manifest content";
    let (digest, resp_template) = mock_manifest(manifest_body);

    // Upstream expects the Authorization header from the client and succeeds
    Mock::given(method("GET"))
        .and(path("/v2/library/private/manifests/latest"))
        .and(header("authorization", "Bearer client-token-123"))
        .respond_with(resp_template)
        .expect(1)
        .mount(&mock)
        .await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/v2/library/private/manifests/latest")
                .header("authorization", "Bearer client-token-123")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    assert_eq!(
        resp.headers().get("docker-content-digest").unwrap(),
        &digest
    );
}

#[tokio::test]
async fn manifest_client_auth_falls_back_to_token_exchange_on_401() {
    let (router, mock, _dir) = setup().await;

    let manifest_body = b"private manifest via token exchange";
    let (digest, success_resp) = mock_manifest(manifest_body);

    // First call with client auth returns 401 with WWW-Authenticate
    let auth_header = format!(
        r#"Bearer realm="{}/token",service="registry.docker.io",scope="repository:library/private:pull""#,
        mock.uri()
    );
    Mock::given(method("GET"))
        .and(path("/v2/library/private/manifests/latest"))
        .and(header("authorization", "Basic dXNlcjpwYXNz"))
        .respond_with(
            ResponseTemplate::new(401).insert_header("WWW-Authenticate", auth_header.as_str()),
        )
        .expect(1)
        .mount(&mock)
        .await;

    // Token endpoint receives client Basic auth and returns a token
    Mock::given(method("GET"))
        .and(path("/token"))
        .and(header("authorization", "Basic dXNlcjpwYXNz"))
        .respond_with(
            ResponseTemplate::new(200)
                .set_body_json(serde_json::json!({"token": "exchanged-bearer-token"})),
        )
        .expect(1)
        .mount(&mock)
        .await;

    // Authenticated request with exchanged token succeeds
    Mock::given(method("GET"))
        .and(path("/v2/library/private/manifests/latest"))
        .and(header("authorization", "Bearer exchanged-bearer-token"))
        .respond_with(success_resp)
        .expect(1)
        .mount(&mock)
        .await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/v2/library/private/manifests/latest")
                .header("authorization", "Basic dXNlcjpwYXNz")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    assert_eq!(
        resp.headers().get("docker-content-digest").unwrap(),
        &digest
    );
}

#[tokio::test]
async fn blob_client_auth_forwarded_to_upstream() {
    let (router, mock, _dir) = setup().await;

    let blob_content = b"private blob bytes";
    let digest = sha256_hex(blob_content);

    // Upstream expects the Authorization header from the client and succeeds
    Mock::given(method("GET"))
        .and(path(format!("/v2/library/private/blobs/{}", digest)))
        .and(header("authorization", "Bearer client-blob-token"))
        .respond_with(
            ResponseTemplate::new(200)
                .insert_header("Content-Type", "application/octet-stream")
                .set_body_bytes(blob_content.to_vec()),
        )
        .expect(1)
        .mount(&mock)
        .await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri(format!("/v2/library/private/blobs/{}", digest))
                .header("authorization", "Bearer client-blob-token")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    assert_eq!(&body[..], blob_content);
}

#[tokio::test]
async fn manifest_no_auth_header_still_works_anonymously() {
    // Verify that requests without an Authorization header still work as before
    let (router, mock, _dir) = setup().await;

    let manifest_body = b"public manifest content";
    let (digest, resp_template) = mock_manifest(manifest_body);

    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/latest"))
        .respond_with(resp_template)
        .expect(1)
        .mount(&mock)
        .await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    assert_eq!(
        resp.headers().get("docker-content-digest").unwrap(),
        &digest
    );
}

#[tokio::test]
async fn blob_client_auth_falls_back_to_token_exchange_on_401() {
    let (router, mock, _dir) = setup().await;

    let blob_content = b"private blob via token exchange";
    let digest = sha256_hex(blob_content);

    // First call with client auth returns 401 with WWW-Authenticate
    let auth_header = format!(
        r#"Bearer realm="{}/token",service="registry.docker.io",scope="repository:library/private:pull""#,
        mock.uri()
    );
    Mock::given(method("GET"))
        .and(path(format!("/v2/library/private/blobs/{}", digest)))
        .and(header("authorization", "Basic dXNlcjpwYXNz"))
        .respond_with(
            ResponseTemplate::new(401).insert_header("WWW-Authenticate", auth_header.as_str()),
        )
        .expect(1)
        .mount(&mock)
        .await;

    // Token endpoint receives client Basic auth and returns a token
    Mock::given(method("GET"))
        .and(path("/token"))
        .and(header("authorization", "Basic dXNlcjpwYXNz"))
        .respond_with(
            ResponseTemplate::new(200)
                .set_body_json(serde_json::json!({"token": "blob-bearer-token"})),
        )
        .expect(1)
        .mount(&mock)
        .await;

    // Authenticated request with exchanged token succeeds
    Mock::given(method("GET"))
        .and(path(format!("/v2/library/private/blobs/{}", digest)))
        .and(header("authorization", "Bearer blob-bearer-token"))
        .respond_with(
            ResponseTemplate::new(200)
                .insert_header("Content-Type", "application/octet-stream")
                .set_body_bytes(blob_content.to_vec()),
        )
        .expect(1)
        .mount(&mock)
        .await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri(format!("/v2/library/private/blobs/{}", digest))
                .header("authorization", "Basic dXNlcjpwYXNz")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    assert_eq!(&body[..], blob_content);
}

// --- Negative cache tests ---

#[tokio::test]
async fn negative_cache_serves_404_without_upstream_call() {
    let (router, mock, _dir) = setup().await;

    // First request: upstream returns 404
    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/nonexistent"))
        .respond_with(ResponseTemplate::new(404))
        .expect(1) // Only called once
        .mount(&mock)
        .await;

    let resp = router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/nonexistent")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(resp.status(), 404);

    // Second request: served from negative cache (no upstream call)
    let resp = router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/nonexistent")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(resp.status(), 404);

    // Verify negative cache hit metric
    let resp = router
        .oneshot(
            Request::builder()
                .uri("/metrics")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    let text = String::from_utf8(body.to_vec()).unwrap();
    assert!(
        text.contains("drayage_negative_cache_hits_total 1"),
        "expected 1 negative cache hit, metrics: {}",
        text
    );
    // Mock expect(1) confirms only one upstream call despite two requests
}

#[tokio::test]
async fn negative_cache_does_not_apply_to_digest_lookups() {
    let (router, mock, _dir) = setup().await;

    let digest = "sha256:0000000000000000000000000000000000000000000000000000000000000099";

    // Upstream returns 404 for both calls (digest lookups bypass negative cache)
    Mock::given(method("GET"))
        .and(path(format!("/v2/library/alpine/manifests/{}", digest)))
        .respond_with(ResponseTemplate::new(404))
        .expect(2) // Called both times
        .mount(&mock)
        .await;

    for _ in 0..2 {
        let resp = router
            .clone()
            .oneshot(
                Request::builder()
                    .uri(format!("/v2/library/alpine/manifests/{}", digest))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(resp.status(), 404);
    }

    // Mock expect(2) confirms both requests hit upstream
}

// --- stats endpoint tests ---

#[tokio::test]
async fn stats_endpoint_returns_json() {
    let (router, _mock, _dir) = setup().await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/stats")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    assert_eq!(
        resp.headers().get("Content-Type").unwrap(),
        "application/json"
    );
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    let parsed: serde_json::Value = serde_json::from_slice(&body).unwrap();
    assert_eq!(parsed["blob_count"], 0);
    assert_eq!(parsed["blob_total_bytes"], 0);
    assert_eq!(parsed["manifest_digest_count"], 0);
    assert_eq!(parsed["manifest_tag_count"], 0);
    assert!(parsed["disk_available_bytes"].as_u64().unwrap() > 0);
}

#[tokio::test]
async fn stats_endpoint_reflects_cached_data() {
    let (router, mock, _dir) = setup().await;

    let manifest = br#"{"schemaVersion":2,"stats":"test"}"#;
    let (_digest, resp_template) = mock_manifest(manifest);

    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/latest"))
        .respond_with(resp_template)
        .mount(&mock)
        .await;

    // Populate cache with a manifest
    router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    // Check stats
    let resp = router
        .oneshot(
            Request::builder()
                .uri("/stats")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    let parsed: serde_json::Value = serde_json::from_slice(&body).unwrap();
    assert_eq!(
        parsed["manifest_tag_count"], 1,
        "should have 1 cached manifest tag"
    );
    assert_eq!(
        parsed["manifest_digest_count"], 1,
        "should have 1 cached manifest by digest"
    );
}

// --- Offline mode tests ---

async fn setup_offline() -> (Router, tempfile::TempDir) {
    let dir = tempfile::TempDir::new().unwrap();

    let config = Config {
        listen: "unused:0".to_string(),
        cache_dir: dir.path().to_str().unwrap().to_string(),
        manifest_ttl_seconds: 900,
        max_cache_bytes: None,
        eviction_interval_seconds: 300,
        connect_timeout_secs: 10,
        read_timeout_secs: 30,
        max_manifest_bytes: 10_485_760,
        negative_ttl_seconds: 60,
        offline_mode: true,
        upstreams: HashMap::new(),
        tls_listen: None,
        ca_cert_path: None,
        ca_key_path: None,
    };

    let config = Arc::new(config);
    let metrics = Arc::new(Metrics::default());
    let cache = Arc::new(Cache::new(dir.path(), config.manifest_ttl_seconds, None).unwrap());
    let upstream = Arc::new(UpstreamClient::new(config.clone(), metrics.clone()));
    let negative_cache = Arc::new(NegativeCache::new(config.negative_ttl_seconds));

    let state = AppState {
        cache,
        upstream,
        inflight: Arc::new(DashMap::new()),
        metrics,
        negative_cache,
        config,
        revalidation_tracker: Arc::new(DashMap::new()),
    };

    let router = build_router(state);
    (router, dir)
}

#[tokio::test]
async fn offline_mode_serves_cached_manifest() {
    // First: populate cache with online setup
    let (online_router, mock, dir) = setup_with_ttl(900).await;

    let manifest = br#"{"schemaVersion":2,"offline":"cached"}"#;
    let (_digest, resp_template) = mock_manifest(manifest);

    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/latest"))
        .respond_with(resp_template)
        .mount(&mock)
        .await;

    // Populate cache
    let resp = online_router
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(resp.status(), 200);

    // Create offline router using the same cache directory
    let config = Config {
        listen: "unused:0".to_string(),
        cache_dir: dir.path().to_str().unwrap().to_string(),
        manifest_ttl_seconds: 900,
        max_cache_bytes: None,
        eviction_interval_seconds: 300,
        connect_timeout_secs: 10,
        read_timeout_secs: 30,
        max_manifest_bytes: 10_485_760,
        negative_ttl_seconds: 60,
        offline_mode: true,
        upstreams: HashMap::new(),
        tls_listen: None,
        ca_cert_path: None,
        ca_key_path: None,
    };
    let config = Arc::new(config);
    let metrics = Arc::new(Metrics::default());
    let cache = Arc::new(Cache::new(dir.path(), config.manifest_ttl_seconds, None).unwrap());
    let upstream = Arc::new(UpstreamClient::new(config.clone(), metrics.clone()));
    let negative_cache = Arc::new(NegativeCache::new(config.negative_ttl_seconds));
    let offline_state = AppState {
        cache,
        upstream,
        inflight: Arc::new(DashMap::new()),
        metrics,
        negative_cache,
        config,
        revalidation_tracker: Arc::new(DashMap::new()),
    };
    let offline_router = build_router(offline_state);

    // Offline request should serve from cache
    let resp = offline_router
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(resp.status(), 200);
    let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
        .await
        .unwrap();
    assert_eq!(body.as_ref(), manifest);
}

#[tokio::test]
async fn offline_mode_returns_404_on_cache_miss() {
    let (router, _dir) = setup_offline().await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 404);
}

#[tokio::test]
async fn offline_mode_blob_returns_404_on_cache_miss() {
    let (router, _dir) = setup_offline().await;

    let digest = "sha256:0000000000000000000000000000000000000000000000000000000000000099";

    let resp = router
        .oneshot(
            Request::builder()
                .uri(format!("/v2/library/alpine/blobs/{}", digest))
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(resp.status(), 404);
}

// --- Security regression tests ---

#[tokio::test]
async fn authenticated_manifest_cache_is_not_served_to_unauthenticated_request() {
    let (router, mock, _dir) = setup().await;

    let manifest = br#"{"schemaVersion":2,"private":"manifest"}"#;
    let (_digest, resp_template) = mock_manifest(manifest);

    Mock::given(method("GET"))
        .and(path("/v2/library/private/manifests/latest"))
        .and(header("authorization", "Bearer private-token"))
        .respond_with(resp_template)
        .expect(1)
        .mount(&mock)
        .await;

    let authed = router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/private/manifests/latest")
                .header("authorization", "Bearer private-token")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(authed.status(), 200);

    let unauthenticated = router
        .oneshot(
            Request::builder()
                .uri("/v2/library/private/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(
        unauthenticated.status(),
        404,
        "public requests must not read auth-scoped manifest cache entries"
    );
}

#[tokio::test]
async fn authenticated_blob_cache_is_not_served_to_unauthenticated_request() {
    let (router, mock, _dir) = setup().await;

    let blob = b"private blob bytes";
    let digest = sha256_hex(blob);

    Mock::given(method("GET"))
        .and(path(format!("/v2/library/private/blobs/{}", digest)))
        .and(header("authorization", "Bearer private-token"))
        .respond_with(ResponseTemplate::new(200).set_body_bytes(blob.to_vec()))
        .expect(1)
        .mount(&mock)
        .await;

    let authed = router
        .clone()
        .oneshot(
            Request::builder()
                .uri(format!("/v2/library/private/blobs/{}", digest))
                .header("authorization", "Bearer private-token")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(authed.status(), 200);

    let unauthenticated = router
        .oneshot(
            Request::builder()
                .uri(format!("/v2/library/private/blobs/{}", digest))
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(
        unauthenticated.status(),
        404,
        "public requests must not read auth-scoped blob cache entries"
    );
}

#[tokio::test]
async fn negative_cache_is_scoped_by_client_authorization() {
    let (router, mock, _dir) = setup().await;

    Mock::given(method("GET"))
        .and(path("/v2/library/private/manifests/latest"))
        .respond_with(ResponseTemplate::new(404))
        .expect(1)
        .mount(&mock)
        .await;

    let unauthenticated = router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/private/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(unauthenticated.status(), 404);

    mock.reset().await;
    let manifest = br#"{"schemaVersion":2,"private":"allowed"}"#;
    let (_digest, resp_template) = mock_manifest(manifest);
    Mock::given(method("GET"))
        .and(path("/v2/library/private/manifests/latest"))
        .and(header("authorization", "Bearer private-token"))
        .respond_with(resp_template)
        .expect(1)
        .mount(&mock)
        .await;

    let authed = router
        .oneshot(
            Request::builder()
                .uri("/v2/library/private/manifests/latest")
                .header("authorization", "Bearer private-token")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(
        authed.status(),
        200,
        "public negative-cache entries must not deny authorized requests"
    );
}

#[tokio::test]
async fn invalid_digest_and_tag_paths_are_rejected() {
    let (router, _mock, _dir) = setup().await;

    let bad_blob = router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/blobs/sha256:../../secret")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(bad_blob.status(), 400);

    let bad_tag = router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/bad/tag")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(bad_tag.status(), 400);

    let bad_repo = router
        .oneshot(
            Request::builder()
                .uri("/v2/Library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(bad_repo.status(), 400);
}

#[tokio::test]
async fn opaque_nonexistent_manifest_reference_returns_404() {
    let (router, mock, _dir) = setup().await;

    Mock::given(path("/v2/library/alpine/manifests/.INVALID_MANIFEST_NAME"))
        .respond_with(ResponseTemplate::new(404))
        .expect(1)
        .mount(&mock)
        .await;

    for method in ["GET", "HEAD"] {
        let resp = router
            .clone()
            .oneshot(
                Request::builder()
                    .method(method)
                    .uri("/v2/library/alpine/manifests/.INVALID_MANIFEST_NAME")
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(resp.status(), 404);
    }
}

#[tokio::test]
async fn opaque_manifest_reference_upstream_400_is_translated_to_404() {
    let (router, mock, _dir) = setup().await;

    Mock::given(path("/v2/library/alpine/manifests/.INVALID_MANIFEST_NAME"))
        .respond_with(ResponseTemplate::new(400))
        .expect(1)
        .mount(&mock)
        .await;

    for method in ["GET", "HEAD"] {
        let resp = router
            .clone()
            .oneshot(
                Request::builder()
                    .method(method)
                    .uri("/v2/library/alpine/manifests/.INVALID_MANIFEST_NAME")
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(resp.status(), 404);
    }
}

#[tokio::test]
async fn manifest_digest_header_mismatch_returns_bad_gateway() {
    let (router, mock, _dir) = setup().await;

    let manifest = br#"{"schemaVersion":2,"digest":"mismatch"}"#;
    Mock::given(method("GET"))
        .and(path("/v2/library/alpine/manifests/latest"))
        .respond_with(
            ResponseTemplate::new(200)
                .insert_header(
                    "Content-Type",
                    "application/vnd.docker.distribution.manifest.v2+json",
                )
                .insert_header(
                    "Docker-Content-Digest",
                    "sha256:0000000000000000000000000000000000000000000000000000000000000000",
                )
                .set_body_bytes(manifest.to_vec()),
        )
        .mount(&mock)
        .await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(resp.status(), 502);
}

#[tokio::test]
async fn unconfigured_explicit_registry_is_rejected() {
    let (router, _mock, _dir) = setup().await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/v2/evil.example.com/repo/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(resp.status(), 502);
}

#[tokio::test]
async fn token_realm_outside_upstream_allowlist_is_rejected() {
    let (router, mock, _dir) = setup().await;

    Mock::given(method("GET"))
        .and(path("/v2/library/private/manifests/latest"))
        .respond_with(ResponseTemplate::new(401).insert_header(
            "WWW-Authenticate",
            r#"Bearer realm="https://evil.example.com/token",service="registry.docker.io",scope="repository:library/private:pull""#,
        ))
        .mount(&mock)
        .await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/v2/library/private/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(resp.status(), 404);
}
