//! Integration tests that pull real manifests and blobs from public registries.
//!
//! All tests are `#[ignore]` so they are skipped by `cargo test` / `make test`.
//! Run manually with:
//!
//!     make test-real
//!     # or: cargo test --test real_registry -- --ignored --test-threads=1

use std::collections::HashMap;
use std::sync::Arc;

use axum::Router;
use axum::body::Body;
use dashmap::DashMap;
use http::Request;
use sha2::{Digest, Sha256};
use tower::ServiceExt;

use drayage::AppState;
use drayage::cache::Cache;
use drayage::config::{Config, UpstreamConfig};
use drayage::metrics::Metrics;
use drayage::server::build_router;
use drayage::upstream::UpstreamClient;

/// Known manifest media types that registries return.
const MANIFEST_MEDIA_TYPES: &[&str] = &[
    "application/vnd.docker.distribution.manifest.v2+json",
    "application/vnd.docker.distribution.manifest.list.v2+json",
    "application/vnd.oci.image.manifest.v1+json",
    "application/vnd.oci.image.index.v1+json",
];

fn real_config(cache_dir: &std::path::Path) -> Config {
    let mut upstreams = HashMap::new();

    upstreams.insert(
        "docker_io".to_string(),
        UpstreamConfig {
            registry: "https://registry-1.docker.io".to_string(),
            username: None,
            password: None,
            connect_timeout_secs: None,
            read_timeout_secs: None,
        },
    );
    upstreams.insert(
        "gcr_io".to_string(),
        UpstreamConfig {
            registry: "https://gcr.io".to_string(),
            username: None,
            password: None,
            connect_timeout_secs: None,
            read_timeout_secs: None,
        },
    );
    upstreams.insert(
        "ghcr_io".to_string(),
        UpstreamConfig {
            registry: "https://ghcr.io".to_string(),
            username: None,
            password: None,
            connect_timeout_secs: None,
            read_timeout_secs: None,
        },
    );
    upstreams.insert(
        "quay_io".to_string(),
        UpstreamConfig {
            registry: "https://quay.io".to_string(),
            username: None,
            password: None,
            connect_timeout_secs: None,
            read_timeout_secs: None,
        },
    );
    upstreams.insert(
        "registry_k8s_io".to_string(),
        UpstreamConfig {
            registry: "https://registry.k8s.io".to_string(),
            username: None,
            password: None,
            connect_timeout_secs: None,
            read_timeout_secs: None,
        },
    );

    Config {
        listen: "unused:0".to_string(),
        cache_dir: cache_dir.to_str().unwrap().to_string(),
        manifest_ttl_seconds: 900,
        max_cache_bytes: None,
        eviction_interval_seconds: 300,
        connect_timeout_secs: 10,
        read_timeout_secs: 30,
        max_manifest_bytes: 10_485_760,
        negative_ttl_seconds: 60,
        offline_mode: false,
        upstreams,
        tls_listen: None,
        ca_cert_path: None,
        ca_key_path: None,
    }
}

async fn setup_real() -> (Router, tempfile::TempDir) {
    let dir = tempfile::TempDir::new().unwrap();
    let config = Arc::new(real_config(dir.path()));
    let metrics = Arc::new(Metrics::default());
    let cache = Arc::new(Cache::new(dir.path(), config.manifest_ttl_seconds, None).unwrap());
    let upstream = Arc::new(UpstreamClient::new(config.clone(), metrics.clone()));
    let negative_cache = Arc::new(drayage::negative_cache::NegativeCache::new(
        config.negative_ttl_seconds,
    ));

    let state = AppState {
        cache,
        upstream,
        inflight: Arc::new(DashMap::new()),
        metrics,
        negative_cache,
        config,
        revalidation_tracker: Arc::new(DashMap::new()),
    };

    (build_router(state), dir)
}

/// Verify a manifest response: status 200, valid JSON, recognized content-type,
/// and `Docker-Content-Digest` matches the body's SHA256.
async fn assert_manifest_ok(resp: http::Response<Body>, label: &str) {
    assert_eq!(resp.status(), 200, "{label}: expected 200");

    let content_type = resp
        .headers()
        .get("content-type")
        .expect(&format!("{label}: missing Content-Type"))
        .to_str()
        .unwrap()
        .to_string();
    assert!(
        MANIFEST_MEDIA_TYPES
            .iter()
            .any(|mt| content_type.contains(mt)),
        "{label}: unexpected content-type: {content_type}"
    );

    let digest_header = resp
        .headers()
        .get("docker-content-digest")
        .expect(&format!("{label}: missing Docker-Content-Digest"))
        .to_str()
        .unwrap()
        .to_string();

    let body = axum::body::to_bytes(resp.into_body(), 50 * 1024 * 1024)
        .await
        .expect(&format!("{label}: failed to read body"));

    // Body must be valid JSON
    let _: serde_json::Value =
        serde_json::from_slice(&body).expect(&format!("{label}: body is not valid JSON"));

    // Verify digest
    let computed = format!("sha256:{}", hex::encode(Sha256::digest(&body)));
    assert_eq!(
        digest_header, computed,
        "{label}: digest mismatch (header vs computed)"
    );
}

// ---------------------------------------------------------------------------
// Manifest tests — one per registry
// ---------------------------------------------------------------------------

#[tokio::test]
#[ignore]
async fn real_docker_io_manifest() {
    let (router, _dir) = setup_real().await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/3.20")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_manifest_ok(resp, "docker.io/library/alpine:3.20").await;
}

#[tokio::test]
#[ignore]
async fn real_gcr_io_manifest() {
    let (router, _dir) = setup_real().await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/v2/gcr.io/distroless/static-debian12/manifests/latest")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_manifest_ok(resp, "gcr.io/distroless/static-debian12:latest").await;
}

#[tokio::test]
#[ignore]
async fn real_ghcr_io_manifest() {
    let (router, _dir) = setup_real().await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/v2/ghcr.io/cloudnative-pg/cloudnative-pg/manifests/1.25.0")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_manifest_ok(resp, "ghcr.io/cloudnative-pg/cloudnative-pg:1.25.0").await;
}

#[tokio::test]
#[ignore]
async fn real_quay_io_manifest() {
    let (router, _dir) = setup_real().await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/v2/quay.io/prometheus/node-exporter/manifests/v1.8.2")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_manifest_ok(resp, "quay.io/prometheus/node-exporter:v1.8.2").await;
}

#[tokio::test]
#[ignore]
async fn real_registry_k8s_io_manifest() {
    let (router, _dir) = setup_real().await;

    let resp = router
        .oneshot(
            Request::builder()
                .uri("/v2/registry.k8s.io/pause/manifests/3.9")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_manifest_ok(resp, "registry.k8s.io/pause:3.9").await;
}

// ---------------------------------------------------------------------------
// Blob test — verify blob fetch + digest integrity (docker.io only)
// ---------------------------------------------------------------------------

#[tokio::test]
#[ignore]
async fn real_docker_io_blob() {
    let (router, _dir) = setup_real().await;

    // First, fetch the manifest to get a blob digest
    let resp = router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/3.20")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(resp.status(), 200, "manifest fetch failed");

    let body = axum::body::to_bytes(resp.into_body(), 50 * 1024 * 1024)
        .await
        .unwrap();
    let manifest: serde_json::Value = serde_json::from_slice(&body).unwrap();

    // The manifest may be a manifest list (index) or a single manifest.
    // For a single manifest, extract the config digest.
    // For a manifest list, extract the first manifest's digest and fetch that.
    let blob_digest = if manifest.get("manifests").is_some() {
        // It's a manifest list/index — get the digest of the first platform manifest
        let first = &manifest["manifests"][0];
        let child_digest = first["digest"].as_str().unwrap();

        // Fetch the child manifest to get its config digest
        let child_resp = router
            .clone()
            .oneshot(
                Request::builder()
                    .uri(format!("/v2/library/alpine/manifests/{child_digest}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(child_resp.status(), 200, "child manifest fetch failed");

        let child_body = axum::body::to_bytes(child_resp.into_body(), 50 * 1024 * 1024)
            .await
            .unwrap();
        let child_manifest: serde_json::Value = serde_json::from_slice(&child_body).unwrap();
        child_manifest["config"]["digest"]
            .as_str()
            .unwrap()
            .to_string()
    } else {
        // Single manifest — config digest directly
        manifest["config"]["digest"].as_str().unwrap().to_string()
    };

    // Fetch the blob
    let blob_resp = router
        .oneshot(
            Request::builder()
                .uri(format!("/v2/library/alpine/blobs/{blob_digest}"))
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(blob_resp.status(), 200, "blob fetch failed");

    let blob_body = axum::body::to_bytes(blob_resp.into_body(), 50 * 1024 * 1024)
        .await
        .unwrap();

    // Verify blob digest matches
    let computed = format!("sha256:{}", hex::encode(Sha256::digest(&blob_body)));
    assert_eq!(
        blob_digest, computed,
        "blob digest mismatch (expected vs computed)"
    );
}

// ---------------------------------------------------------------------------
// Cache hit test — verify second request is served from cache
// ---------------------------------------------------------------------------

#[tokio::test]
#[ignore]
async fn real_docker_io_cache_hit() {
    let (router, _dir) = setup_real().await;

    // First request — cache miss, upstream fetch
    let resp1 = router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/3.20")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(resp1.status(), 200);
    let body1 = axum::body::to_bytes(resp1.into_body(), 50 * 1024 * 1024)
        .await
        .unwrap();

    // Second request — should be served from cache (same body)
    let resp2 = router
        .oneshot(
            Request::builder()
                .uri("/v2/library/alpine/manifests/3.20")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(resp2.status(), 200);
    let body2 = axum::body::to_bytes(resp2.into_body(), 50 * 1024 * 1024)
        .await
        .unwrap();

    assert_eq!(
        body1, body2,
        "cached response should match initial response"
    );
}
