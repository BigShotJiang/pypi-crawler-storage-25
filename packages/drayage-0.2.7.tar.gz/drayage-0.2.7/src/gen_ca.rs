use std::path::Path;
#[cfg(unix)]
use std::{fs::OpenOptions, io::Write, os::unix::fs::OpenOptionsExt};

use rcgen::{CertificateParams, DnType, IsCa, KeyPair};

/// Generate a self-signed CA certificate and private key.
///
/// Writes `ca.crt` and `ca.key` (PEM-encoded) to the given directory.
/// Errors if files already exist unless `force` is true.
pub fn run(dir: &str, force: bool) -> anyhow::Result<()> {
    let out = Path::new(dir);
    if !out.exists() {
        std::fs::create_dir_all(out)?;
    }

    let cert_path = out.join("ca.crt");
    let key_path = out.join("ca.key");

    if !force {
        if cert_path.exists() {
            anyhow::bail!(
                "{} already exists (use --force to overwrite)",
                cert_path.display()
            );
        }
        if key_path.exists() {
            anyhow::bail!(
                "{} already exists (use --force to overwrite)",
                key_path.display()
            );
        }
    }

    let key_pair = KeyPair::generate()?;
    let mut params = CertificateParams::default();
    params.is_ca = IsCa::Ca(rcgen::BasicConstraints::Unconstrained);
    params
        .distinguished_name
        .push(DnType::CommonName, "drayage CA");
    params
        .distinguished_name
        .push(DnType::OrganizationName, "drayage");

    let cert = params.self_signed(&key_pair)?;

    std::fs::write(&cert_path, cert.pem())?;
    write_private_key(&key_path, &key_pair.serialize_pem())?;

    println!("wrote {}", cert_path.display());
    println!("wrote {}", key_path.display());
    Ok(())
}

#[cfg(unix)]
fn write_private_key(path: &Path, pem: &str) -> anyhow::Result<()> {
    let mut file = OpenOptions::new()
        .write(true)
        .create(true)
        .truncate(true)
        .mode(0o600)
        .open(path)?;
    file.write_all(pem.as_bytes())?;
    file.flush()?;
    Ok(())
}

#[cfg(not(unix))]
fn write_private_key(path: &Path, pem: &str) -> anyhow::Result<()> {
    std::fs::write(path, pem)?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::TempDir;

    #[test]
    fn gen_ca_creates_cert_and_key() {
        let dir = TempDir::new().unwrap();
        run(dir.path().to_str().unwrap(), false).unwrap();

        let cert_path = dir.path().join("ca.crt");
        let key_path = dir.path().join("ca.key");
        assert!(cert_path.exists());
        assert!(key_path.exists());

        let cert_pem = std::fs::read_to_string(&cert_path).unwrap();
        let key_pem = std::fs::read_to_string(&key_path).unwrap();
        assert!(cert_pem.contains("BEGIN CERTIFICATE"));
        assert!(key_pem.contains("BEGIN PRIVATE KEY"));
    }

    #[test]
    fn gen_ca_refuses_overwrite_without_force() {
        let dir = TempDir::new().unwrap();
        std::fs::write(dir.path().join("ca.crt"), "existing").unwrap();

        let err = run(dir.path().to_str().unwrap(), false).unwrap_err();
        assert!(
            err.to_string().contains("already exists"),
            "expected 'already exists' error, got: {err}"
        );
    }

    #[test]
    fn gen_ca_overwrites_with_force() {
        let dir = TempDir::new().unwrap();
        std::fs::write(dir.path().join("ca.crt"), "old").unwrap();
        std::fs::write(dir.path().join("ca.key"), "old").unwrap();

        run(dir.path().to_str().unwrap(), true).unwrap();

        let cert_pem = std::fs::read_to_string(dir.path().join("ca.crt")).unwrap();
        assert!(cert_pem.contains("BEGIN CERTIFICATE"));
    }

    #[test]
    fn gen_ca_creates_output_directory() {
        let dir = TempDir::new().unwrap();
        let nested = dir.path().join("nested").join("certs");
        run(nested.to_str().unwrap(), false).unwrap();
        assert!(nested.join("ca.crt").exists());
        assert!(nested.join("ca.key").exists());
    }

    #[test]
    fn gen_ca_produces_valid_ca_cert() {
        let dir = TempDir::new().unwrap();
        run(dir.path().to_str().unwrap(), false).unwrap();

        let cert_pem = std::fs::read_to_string(dir.path().join("ca.crt")).unwrap();
        let key_pem = std::fs::read_to_string(dir.path().join("ca.key")).unwrap();

        // Verify the generated CA can be loaded by SniCertResolver
        let cert_path = dir.path().join("ca.crt");
        let key_path = dir.path().join("ca.key");
        let resolver = crate::tls::SniCertResolver::load(
            cert_path.to_str().unwrap(),
            key_path.to_str().unwrap(),
            None,
        );
        assert!(
            resolver.is_ok(),
            "generated CA should be loadable: {:?}",
            resolver.err()
        );

        // Verify PEM structure
        assert!(cert_pem.starts_with("-----BEGIN CERTIFICATE-----"));
        assert!(key_pem.starts_with("-----BEGIN PRIVATE KEY-----"));
    }

    #[test]
    fn gen_ca_key_path_blocks_overwrite() {
        let dir = TempDir::new().unwrap();
        // Only key exists, cert doesn't
        std::fs::write(dir.path().join("ca.key"), "existing key").unwrap();

        let err = run(dir.path().to_str().unwrap(), false).unwrap_err();
        assert!(
            err.to_string().contains("ca.key"),
            "error should mention ca.key: {err}"
        );
    }

    #[cfg(unix)]
    #[test]
    fn gen_ca_private_key_is_owner_only() {
        use std::os::unix::fs::PermissionsExt;

        let dir = TempDir::new().unwrap();
        run(dir.path().to_str().unwrap(), false).unwrap();

        let mode = std::fs::metadata(dir.path().join("ca.key"))
            .unwrap()
            .permissions()
            .mode()
            & 0o777;
        assert_eq!(mode, 0o600);
    }
}
