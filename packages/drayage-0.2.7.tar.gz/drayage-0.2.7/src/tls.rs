use std::collections::HashSet;
use std::fmt;
use std::sync::Arc;

use dashmap::DashMap;
use rcgen::{CertificateParams, DnType, KeyPair};
use rustls::pki_types::{CertificateDer, PrivateKeyDer, PrivatePkcs8KeyDer};
use rustls::server::ClientHello;
use rustls::sign::CertifiedKey;
use tracing::warn;

/// Validate that an SNI hostname is a reasonable DNS name.
/// Rejects empty names, names with path separators, control characters,
/// overly long names, and names that don't look like hostnames.
fn is_valid_hostname(hostname: &str) -> bool {
    if hostname.is_empty() {
        return false;
    }
    // DNS max is 253 characters
    if hostname.len() > 253 {
        return false;
    }
    // Reject path separators, null bytes, and other dangerous characters
    if hostname.contains('/') || hostname.contains('\\') || hostname.contains('\0') {
        return false;
    }
    // Reject whitespace and control characters
    if hostname
        .chars()
        .any(|c| c.is_control() || c.is_whitespace())
    {
        return false;
    }
    // Each DNS label must be 1-63 characters
    for label in hostname.split('.') {
        if label.is_empty() || label.len() > 63 {
            return false;
        }
    }
    true
}

pub struct SniCertResolver {
    ca_cert: rcgen::Certificate,
    ca_key: KeyPair,
    cache: DashMap<String, Arc<CertifiedKey>>,
    allowed_hosts: Option<HashSet<String>>,
}

impl fmt::Debug for SniCertResolver {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SniCertResolver")
            .field("cached_hosts", &self.cache.len())
            .finish()
    }
}

impl SniCertResolver {
    pub fn load(
        ca_cert_path: &str,
        ca_key_path: &str,
        allowed_hosts: Option<Vec<String>>,
    ) -> anyhow::Result<Self> {
        let ca_cert_pem = std::fs::read_to_string(ca_cert_path)
            .map_err(|e| anyhow::anyhow!("reading {}: {}", ca_cert_path, e))?;
        let ca_key_pem = std::fs::read_to_string(ca_key_path)
            .map_err(|e| anyhow::anyhow!("reading {}: {}", ca_key_path, e))?;

        let ca_key = KeyPair::from_pem(&ca_key_pem)?;
        let ca_params = CertificateParams::from_ca_cert_pem(&ca_cert_pem)?;
        let ca_cert = ca_params.self_signed(&ca_key)?;

        Ok(Self {
            ca_cert,
            ca_key,
            cache: DashMap::new(),
            allowed_hosts: allowed_hosts.map(|hosts| hosts.into_iter().collect()),
        })
    }

    fn generate_cert(&self, hostname: &str) -> anyhow::Result<CertifiedKey> {
        let leaf_key = KeyPair::generate()?;
        let mut params = CertificateParams::new(vec![hostname.to_string()])?;
        params.distinguished_name.push(DnType::CommonName, hostname);
        let leaf_cert = params.signed_by(&leaf_key, &self.ca_cert, &self.ca_key)?;

        let cert_der = CertificateDer::from(leaf_cert.der().to_vec());
        let key_der = PrivateKeyDer::Pkcs8(PrivatePkcs8KeyDer::from(leaf_key.serialize_der()));
        let signing_key = rustls::crypto::ring::sign::any_supported_type(&key_der)
            .map_err(|e| anyhow::anyhow!("signing key error: {:?}", e))?;

        Ok(CertifiedKey::new(vec![cert_der], signing_key))
    }
}

impl rustls::server::ResolvesServerCert for SniCertResolver {
    fn resolve(&self, client_hello: ClientHello<'_>) -> Option<Arc<CertifiedKey>> {
        let hostname = client_hello.server_name()?;

        if !is_valid_hostname(hostname) {
            warn!("rejecting invalid SNI hostname: {:?}", hostname);
            return None;
        }

        if let Some(ref allowed) = self.allowed_hosts
            && !allowed.contains(hostname)
        {
            warn!("SNI hostname '{}' not in allowed list, rejecting", hostname);
            return None;
        }

        if let Some(cached) = self.cache.get(hostname) {
            return Some(cached.clone());
        }

        match self.generate_cert(hostname) {
            Ok(key) => {
                let arc = Arc::new(key);
                self.cache.insert(hostname.to_string(), arc.clone());
                Some(arc)
            }
            Err(e) => {
                warn!("cert generation for {}: {}", hostname, e);
                None
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn valid_hostname_simple() {
        assert!(is_valid_hostname("registry.docker.io"));
    }

    #[test]
    fn valid_hostname_with_hyphens() {
        assert!(is_valid_hostname("registry-1.docker.io"));
    }

    #[test]
    fn invalid_hostname_empty() {
        assert!(!is_valid_hostname(""));
    }

    #[test]
    fn invalid_hostname_path_traversal() {
        assert!(!is_valid_hostname("../../../etc/passwd"));
    }

    #[test]
    fn invalid_hostname_null_byte() {
        assert!(!is_valid_hostname("host\0name.com"));
    }

    #[test]
    fn invalid_hostname_too_long() {
        let long = "a".repeat(254);
        assert!(!is_valid_hostname(&long));
    }

    #[test]
    fn invalid_hostname_control_chars() {
        assert!(!is_valid_hostname("host\nname.com"));
    }

    #[test]
    fn invalid_hostname_label_too_long() {
        let long_label = "a".repeat(64);
        let hostname = format!("{long_label}.com");
        assert!(!is_valid_hostname(&hostname));
    }

    #[test]
    fn valid_hostname_max_label() {
        let label = "a".repeat(63);
        let hostname = format!("{label}.com");
        assert!(is_valid_hostname(&hostname));
    }

    #[test]
    fn invalid_hostname_whitespace() {
        assert!(!is_valid_hostname("host name.com"));
    }

    #[test]
    fn invalid_hostname_backslash() {
        assert!(!is_valid_hostname("host\\name.com"));
    }

    #[test]
    fn valid_hostname_single_label() {
        assert!(is_valid_hostname("localhost"));
    }

    #[test]
    fn invalid_hostname_trailing_dot_empty_label() {
        assert!(!is_valid_hostname("example.com."));
    }

    #[test]
    fn invalid_hostname_double_dot() {
        assert!(!is_valid_hostname("example..com"));
    }

    #[test]
    fn invalid_hostname_tab() {
        assert!(!is_valid_hostname("host\tname.com"));
    }

    #[test]
    fn invalid_hostname_carriage_return() {
        assert!(!is_valid_hostname("host\rname.com"));
    }

    #[test]
    fn valid_hostname_max_length() {
        // 253 chars total: 63 + 1 + 63 + 1 + 63 + 1 + 61 = 253
        let hostname = format!(
            "{}.{}.{}.{}",
            "a".repeat(63),
            "b".repeat(63),
            "c".repeat(63),
            "d".repeat(61)
        );
        assert_eq!(hostname.len(), 253);
        assert!(is_valid_hostname(&hostname));
    }

    #[test]
    fn valid_hostname_common_registries() {
        assert!(is_valid_hostname("registry-1.docker.io"));
        assert!(is_valid_hostname("gcr.io"));
        assert!(is_valid_hostname("ghcr.io"));
        assert!(is_valid_hostname("registry.k8s.io"));
        assert!(is_valid_hostname("quay.io"));
    }
}
