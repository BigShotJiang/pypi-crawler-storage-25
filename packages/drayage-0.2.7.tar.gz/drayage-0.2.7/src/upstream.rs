use std::sync::Arc;
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

use base64::{Engine as _, engine::general_purpose::URL_SAFE_NO_PAD};
use dashmap::DashMap;
use futures_util::TryStreamExt;
use reqwest::Client;
use serde::Deserialize;
use tokio_util::io::StreamReader;
use tracing::{debug, warn};

use crate::cache::{Cache, CacheScope};
use crate::config::Config;
use crate::metrics::Metrics;

const CIRCUIT_FAILURE_THRESHOLD: u64 = 5;
const CIRCUIT_OPEN_DURATION_SECS: u64 = 30;

struct CircuitState {
    consecutive_failures: AtomicU64,
    /// Timestamp (seconds since UNIX epoch) when the circuit opened.
    /// 0 means the circuit is closed (healthy).
    open_since: AtomicU64,
}

impl CircuitState {
    fn new() -> Self {
        Self {
            consecutive_failures: AtomicU64::new(0),
            open_since: AtomicU64::new(0),
        }
    }
}

fn now_epoch_secs() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}

#[derive(Deserialize)]
struct TokenResponse {
    token: Option<String>,
    access_token: Option<String>,
}

impl TokenResponse {
    fn get_token(&self) -> Option<&str> {
        self.token.as_deref().or(self.access_token.as_deref())
    }
}

struct CachedToken {
    token: String,
    expires_at: Instant,
}

const MAX_RETRIES: u32 = 2;
const RETRY_BASE_DELAY: Duration = Duration::from_millis(100);

fn is_retryable_status(status: u16) -> bool {
    matches!(status, 502..=504)
}

fn is_server_error(status: u16) -> bool {
    (500..600).contains(&status)
}

fn is_retryable_error(err: &reqwest::Error) -> bool {
    err.is_connect() || err.is_timeout()
}

fn retry_delay(attempt: u32) -> Duration {
    RETRY_BASE_DELAY * 4u32.pow(attempt)
}

pub struct UpstreamClient {
    client: Client,
    config: Arc<Config>,
    token_cache: DashMap<String, CachedToken>,
    metrics: Arc<Metrics>,
    circuit_states: DashMap<String, Arc<CircuitState>>,
}

/// Produce a composite cache key that namespaces tokens per registry,
/// preventing collisions when different registries share an auth server.
/// When client auth is present, a hash is appended to avoid cross-contamination
/// between anonymous and authenticated token entries.
fn token_cache_key(registry_key: &str, www_auth: &str, client_auth: Option<&str>) -> String {
    match client_auth {
        Some(auth) => {
            use std::hash::{Hash, Hasher};
            let mut hasher = std::collections::hash_map::DefaultHasher::new();
            auth.hash(&mut hasher);
            format!("{}:{}:{:x}", registry_key, www_auth, hasher.finish())
        }
        None => format!("{}:{}", registry_key, www_auth),
    }
}

impl UpstreamClient {
    pub fn new(config: Arc<Config>, metrics: Arc<Metrics>) -> Self {
        let client = Client::builder()
            .user_agent(concat!("drayage/", env!("CARGO_PKG_VERSION")))
            .connect_timeout(Duration::from_secs(config.connect_timeout_secs))
            .build()
            .expect("failed to build HTTP client");
        Self {
            client,
            config,
            token_cache: DashMap::new(),
            metrics,
            circuit_states: DashMap::new(),
        }
    }

    /// Resolve the (connect, read) timeout durations for a given registry.
    /// Per-upstream overrides take precedence over global defaults.
    fn timeout_for(&self, registry_key: &str) -> (Duration, Duration) {
        if let Some(upstream) = self.config.upstreams.get(registry_key) {
            let connect = upstream
                .connect_timeout_secs
                .unwrap_or(self.config.connect_timeout_secs);
            let read = upstream
                .read_timeout_secs
                .unwrap_or(self.config.read_timeout_secs);
            (Duration::from_secs(connect), Duration::from_secs(read))
        } else {
            (
                Duration::from_secs(self.config.connect_timeout_secs),
                Duration::from_secs(self.config.read_timeout_secs),
            )
        }
    }

    fn get_circuit(&self, registry_key: &str) -> Arc<CircuitState> {
        self.circuit_states
            .entry(registry_key.to_string())
            .or_insert_with(|| Arc::new(CircuitState::new()))
            .clone()
    }

    fn check_circuit(&self, registry_key: &str) -> Result<(), crate::UpstreamError> {
        let circuit = self.get_circuit(registry_key);
        let open_since = circuit.open_since.load(Ordering::Relaxed);
        if open_since == 0 {
            return Ok(());
        }

        let now = now_epoch_secs();
        let elapsed = now.saturating_sub(open_since);
        if elapsed >= CIRCUIT_OPEN_DURATION_SECS {
            // Cooldown elapsed: allow a half-open probe
            debug!(
                registry_key,
                elapsed_secs = elapsed,
                "circuit breaker half-open, allowing probe request"
            );
            Ok(())
        } else {
            warn!(
                registry_key,
                remaining_secs = CIRCUIT_OPEN_DURATION_SECS - elapsed,
                "circuit breaker open, rejecting request"
            );
            Err(crate::UpstreamError::Unavailable(
                "circuit breaker open".to_string(),
            ))
        }
    }

    fn record_success(&self, registry_key: &str) {
        let circuit = self.get_circuit(registry_key);
        circuit.consecutive_failures.store(0, Ordering::Relaxed);
        circuit.open_since.store(0, Ordering::Relaxed);
    }

    fn record_failure(&self, registry_key: &str) {
        let circuit = self.get_circuit(registry_key);
        let prev = circuit.consecutive_failures.fetch_add(1, Ordering::Relaxed);
        let new_count = prev + 1;
        if new_count >= CIRCUIT_FAILURE_THRESHOLD && circuit.open_since.load(Ordering::Relaxed) == 0
        {
            circuit
                .open_since
                .store(now_epoch_secs(), Ordering::Relaxed);
            self.metrics.inc(&self.metrics.circuit_breaker_trips);
            warn!(
                registry_key,
                failures = new_count,
                "circuit breaker tripped"
            );
        }
    }

    fn upstream_base_url(
        &self,
        registry_key: &str,
        registry_host: &str,
    ) -> Result<String, crate::UpstreamError> {
        if let Some(upstream) = self.config.upstreams.get(registry_key) {
            return Ok(upstream.registry.clone());
        }

        match registry_host {
            "docker.io" | "registry-1.docker.io" => Ok("https://registry-1.docker.io".to_string()),
            host => Err(crate::UpstreamError::Unavailable(format!(
                "upstream registry '{host}' is not configured"
            ))),
        }
    }

    fn token_realm_allowed(upstream_base_url: &str, realm_url: &reqwest::Url) -> bool {
        let Ok(upstream_url) = reqwest::Url::parse(upstream_base_url) else {
            return false;
        };
        let Some(upstream_host) = upstream_url.host_str() else {
            return false;
        };
        let Some(realm_host) = realm_url.host_str() else {
            return false;
        };

        let same_origin = upstream_url.scheme() == realm_url.scheme()
            && upstream_host.eq_ignore_ascii_case(realm_host)
            && upstream_url.port_or_known_default() == realm_url.port_or_known_default();
        if same_origin {
            return true;
        }

        realm_url.scheme() == "https"
            && realm_host.eq_ignore_ascii_case("auth.docker.io")
            && matches!(upstream_host, "registry-1.docker.io" | "docker.io")
    }

    fn normalize_base_url(base: &str) -> &str {
        base.trim_end_matches('/')
    }

    fn make_registry_url(base: &str, repo: &str, kind: &str, reference: &str) -> String {
        format!(
            "{}/v2/{}/{}/{}",
            Self::normalize_base_url(base),
            repo,
            kind,
            reference
        )
    }

    fn record_result_for_circuit<T>(
        &self,
        registry_key: &str,
        result: &anyhow::Result<T>,
        status: impl Fn(&T) -> Option<u16>,
    ) {
        match result {
            Ok(resp) if status(resp).is_some_and(is_server_error) => {
                self.record_failure(registry_key);
            }
            Ok(_) => {
                self.record_success(registry_key);
            }
            Err(e) => {
                if e.downcast_ref::<reqwest::Error>()
                    .is_some_and(is_retryable_error)
                {
                    self.record_failure(registry_key);
                }
            }
        }
    }

    fn record_blob_result_for_circuit(
        &self,
        registry_key: &str,
        result: &anyhow::Result<BlobFetchResult>,
    ) {
        match result {
            Ok(r) if is_server_error(r.status) => {
                self.record_failure(registry_key);
            }
            Ok(_) => {
                self.record_success(registry_key);
            }
            Err(e) => {
                // Don't double-record if check_circuit already returned an error
                if !matches!(
                    e.downcast_ref::<crate::UpstreamError>(),
                    Some(crate::UpstreamError::Unavailable(_))
                ) && e
                    .downcast_ref::<reqwest::Error>()
                    .is_some_and(is_retryable_error)
                {
                    self.record_failure(registry_key);
                }
            }
        }
    }

    fn record_manifest_result_for_circuit(
        &self,
        registry_key: &str,
        result: &anyhow::Result<UpstreamResponse>,
    ) {
        self.record_result_for_circuit(registry_key, result, |resp| Some(resp.status));
    }

    fn token_timeout(&self, registry_key: &str) -> Duration {
        let (_, read_timeout) = self.timeout_for(registry_key);
        read_timeout
    }

    async fn send_token_request(
        &self,
        registry_key: &str,
        url: reqwest::Url,
        client_auth: Option<&str>,
    ) -> anyhow::Result<reqwest::Response> {
        let mut req = self
            .client
            .get(url)
            .timeout(self.token_timeout(registry_key));

        // Prefer client-provided credentials over config-based credentials
        if let Some(auth) = client_auth {
            req = req.header("authorization", auth);
        } else if let Some(upstream) = self.config.upstreams.get(registry_key)
            && let (Some(user), Some(pass)) = (&upstream.username, &upstream.password)
            && !user.is_empty()
            && !pass.is_empty()
        {
            req = req.basic_auth(user, Some(pass));
        }

        Ok(req.send().await?)
    }

    async fn fetch_token(
        &self,
        registry_key: &str,
        upstream_base_url: &str,
        www_authenticate: &str,
        client_auth: Option<&str>,
    ) -> anyhow::Result<String> {
        let realm = extract_bearer_param(www_authenticate, "realm")
            .ok_or_else(|| anyhow::anyhow!("no realm in WWW-Authenticate"))?;
        let service = extract_bearer_param(www_authenticate, "service").unwrap_or_default();
        let scope = extract_bearer_param(www_authenticate, "scope").unwrap_or_default();

        let mut url = reqwest::Url::parse(&realm)?;
        if !Self::token_realm_allowed(upstream_base_url, &url) {
            anyhow::bail!(
                "token realm '{}' is not allowed for upstream '{}'",
                url,
                upstream_base_url
            );
        }
        if !service.is_empty() {
            url.query_pairs_mut().append_pair("service", &service);
        }
        if !scope.is_empty() {
            url.query_pairs_mut().append_pair("scope", &scope);
        }

        let resp = self
            .send_token_request(registry_key, url, client_auth)
            .await?;
        let status = resp.status().as_u16();
        if status != 200 {
            let body = resp
                .text()
                .await
                .unwrap_or_else(|_| "<no body>".to_string());
            anyhow::bail!("token endpoint returned {}: {}", status, body);
        }
        let token_resp: TokenResponse = resp.json().await?;
        token_resp
            .get_token()
            .map(|t| t.to_string())
            .ok_or_else(|| anyhow::anyhow!("no token in response"))
    }

    pub async fn fetch_manifest(
        &self,
        registry_key: &str,
        registry_host: &str,
        repo: &str,
        reference: &str,
        client_auth: Option<&str>,
    ) -> anyhow::Result<UpstreamResponse> {
        self.check_circuit(registry_key)?;

        let base = self.upstream_base_url(registry_key, registry_host)?;
        let url = Self::make_registry_url(&base, repo, "manifests", reference);

        // Always request modern manifest formats from upstream.
        // Never forward the client's Accept header — clients (e.g. Docker daemon)
        // include v1 types for backwards compatibility, which can cause registries
        // to return schema v1 manifests that Docker 20+ refuses to use.
        let accept = "application/vnd.docker.distribution.manifest.v2+json, \
                      application/vnd.docker.distribution.manifest.list.v2+json, \
                      application/vnd.oci.image.manifest.v1+json, \
                      application/vnd.oci.image.index.v1+json";

        let start = Instant::now();
        let result = self
            .fetch_with_auth(&url, registry_key, &base, Some(accept), client_auth)
            .await;
        self.metrics
            .upstream_manifest_duration
            .observe(registry_key, start.elapsed());

        self.record_manifest_result_for_circuit(registry_key, &result);

        result
    }

    /// Fetch a blob from upstream, streaming directly into the cache.
    /// Returns the HTTP status code and content length without buffering the body.
    pub async fn fetch_blob_to_cache(
        &self,
        request: BlobFetchRequest<'_>,
        cache: &Cache,
        cache_scope: &CacheScope,
    ) -> anyhow::Result<BlobFetchResult> {
        let start = Instant::now();
        let result = self
            .fetch_blob_to_cache_inner(request, cache, cache_scope)
            .await;
        self.metrics
            .upstream_blob_duration
            .observe(request.registry_key, start.elapsed());

        self.record_blob_result_for_circuit(request.registry_key, &result);

        result
    }

    async fn fetch_blob_to_cache_inner(
        &self,
        request: BlobFetchRequest<'_>,
        cache: &Cache,
        cache_scope: &CacheScope,
    ) -> anyhow::Result<BlobFetchResult> {
        self.check_circuit(request.registry_key)?;

        let base = self.upstream_base_url(request.registry_key, request.registry_host)?;
        let url = Self::make_registry_url(&base, request.repo, "blobs", request.digest);
        let (_, read_timeout) = self.timeout_for(request.registry_key);

        // If client provided auth, use it on the initial probe; otherwise start unauthenticated
        let resp = if let Some(auth) = request.client_auth {
            self.send_blob_request_with_auth_header(&url, auth, read_timeout)
                .await?
        } else {
            self.send_blob_request_with_retry(&url, None, read_timeout)
                .await?
        };
        let status = resp.status().as_u16();

        if status == 401 {
            let www_auth = resp
                .headers()
                .get("www-authenticate")
                .and_then(|v| v.to_str().ok())
                .map(|s| s.to_string());
            let _ = resp.bytes().await;

            if let Some(www_auth) = www_auth {
                let token = self
                    .get_or_fetch_token(request.registry_key, &base, &www_auth, request.client_auth)
                    .await?;

                let resp = self
                    .send_blob_request_with_retry(&url, Some(&token), read_timeout)
                    .await?;
                let status = resp.status().as_u16();

                if status == 401 {
                    // Stale token — evict and retry once
                    let cache_key =
                        token_cache_key(request.registry_key, &www_auth, request.client_auth);
                    self.token_cache.remove(&cache_key);
                    self.metrics.inc(&self.metrics.auth_token_refreshes);
                    let _ = resp.bytes().await;
                    let fresh_token = self
                        .get_or_fetch_token(
                            request.registry_key,
                            &base,
                            &www_auth,
                            request.client_auth,
                        )
                        .await?;
                    let resp = self
                        .send_blob_request_with_retry(&url, Some(&fresh_token), read_timeout)
                        .await?;
                    return self
                        .stream_response_to_cache(resp, request.digest, cache, cache_scope)
                        .await;
                }

                return self
                    .stream_response_to_cache(resp, request.digest, cache, cache_scope)
                    .await;
            }

            return Ok(BlobFetchResult { status: 401 });
        }

        self.stream_response_to_cache(resp, request.digest, cache, cache_scope)
            .await
    }

    /// Send a blob GET request with retry on transient failures (502/503/504)
    /// and connection/timeout errors.
    async fn send_blob_request_with_retry(
        &self,
        url: &str,
        token: Option<&str>,
        timeout: Duration,
    ) -> anyhow::Result<reqwest::Response> {
        let mut last_err: Option<reqwest::Error> = None;

        for attempt in 0..=MAX_RETRIES {
            let mut req = self.client.get(url).timeout(timeout);
            if let Some(token) = token {
                req = req.bearer_auth(token);
            }

            match req.send().await {
                Ok(resp) => {
                    let status = resp.status().as_u16();
                    if is_retryable_status(status) && attempt < MAX_RETRIES {
                        let delay = retry_delay(attempt);
                        warn!(
                            url,
                            status,
                            attempt = attempt + 1,
                            max_retries = MAX_RETRIES,
                            delay_ms = delay.as_millis() as u64,
                            "retrying transient upstream blob failure"
                        );
                        let _ = resp.bytes().await;
                        tokio::time::sleep(delay).await;
                        continue;
                    }
                    return Ok(resp);
                }
                Err(e) => {
                    if is_retryable_error(&e) && attempt < MAX_RETRIES {
                        let delay = retry_delay(attempt);
                        warn!(
                            url,
                            error = %e,
                            attempt = attempt + 1,
                            max_retries = MAX_RETRIES,
                            delay_ms = delay.as_millis() as u64,
                            "retrying transient upstream blob connection error"
                        );
                        tokio::time::sleep(delay).await;
                        last_err = Some(e);
                        continue;
                    }
                    return Err(e.into());
                }
            }
        }

        // All retries exhausted due to connection errors
        Err(last_err.unwrap().into())
    }

    /// Send a blob GET request with the raw Authorization header from the client.
    /// Uses the same retry logic as `send_blob_request_with_retry`.
    async fn send_blob_request_with_auth_header(
        &self,
        url: &str,
        auth_header: &str,
        timeout: Duration,
    ) -> anyhow::Result<reqwest::Response> {
        let mut last_err: Option<reqwest::Error> = None;

        for attempt in 0..=MAX_RETRIES {
            let req = self
                .client
                .get(url)
                .timeout(timeout)
                .header("authorization", auth_header);

            match req.send().await {
                Ok(resp) => {
                    let status = resp.status().as_u16();
                    if is_retryable_status(status) && attempt < MAX_RETRIES {
                        let delay = retry_delay(attempt);
                        warn!(
                            url,
                            status,
                            attempt = attempt + 1,
                            max_retries = MAX_RETRIES,
                            delay_ms = delay.as_millis() as u64,
                            "retrying transient upstream blob failure"
                        );
                        let _ = resp.bytes().await;
                        tokio::time::sleep(delay).await;
                        continue;
                    }
                    return Ok(resp);
                }
                Err(e) => {
                    if is_retryable_error(&e) && attempt < MAX_RETRIES {
                        let delay = retry_delay(attempt);
                        warn!(
                            url,
                            error = %e,
                            attempt = attempt + 1,
                            max_retries = MAX_RETRIES,
                            delay_ms = delay.as_millis() as u64,
                            "retrying transient upstream blob connection error"
                        );
                        tokio::time::sleep(delay).await;
                        last_err = Some(e);
                        continue;
                    }
                    return Err(e.into());
                }
            }
        }

        Err(last_err.unwrap().into())
    }

    /// Helper: get a token from cache or fetch a fresh one.
    async fn get_or_fetch_token(
        &self,
        registry_key: &str,
        upstream_base_url: &str,
        www_auth: &str,
        client_auth: Option<&str>,
    ) -> anyhow::Result<String> {
        let cache_key = token_cache_key(registry_key, www_auth, client_auth);
        if let Some(cached) = self.token_cache.get(&cache_key) {
            if cached.expires_at > Instant::now() {
                self.metrics.inc(&self.metrics.token_cache_hits);
                return Ok(cached.token.clone());
            }
            drop(cached);
            self.token_cache.remove(&cache_key);
        }
        let token = self
            .fetch_token(registry_key, upstream_base_url, www_auth, client_auth)
            .await?;
        let ttl = token_ttl(&token);
        self.token_cache.insert(
            cache_key,
            CachedToken {
                token: token.clone(),
                expires_at: Instant::now() + ttl,
            },
        );
        Ok(token)
    }

    /// Remove all expired tokens from the cache.
    pub fn cleanup_expired_tokens(&self) {
        let now = Instant::now();
        self.token_cache.retain(|_, cached| cached.expires_at > now);
    }

    /// Stream a successful response body directly into the blob cache.
    async fn stream_response_to_cache(
        &self,
        resp: reqwest::Response,
        digest: &str,
        cache: &Cache,
        cache_scope: &CacheScope,
    ) -> anyhow::Result<BlobFetchResult> {
        let status = resp.status().as_u16();
        if status != 200 {
            let _ = resp.bytes().await;
            return Ok(BlobFetchResult { status });
        }

        let byte_stream = resp.bytes_stream().map_err(std::io::Error::other);
        let reader = StreamReader::new(byte_stream);
        let written = cache
            .write_blob_from_reader_scoped(digest, reader, cache_scope)
            .await?;
        self.metrics.add(&self.metrics.upstream_bytes, written);
        Ok(BlobFetchResult { status: 200 })
    }

    async fn fetch_with_auth(
        &self,
        url: &str,
        registry_key: &str,
        upstream_base_url: &str,
        accept: Option<&str>,
        client_auth: Option<&str>,
    ) -> anyhow::Result<UpstreamResponse> {
        let (_, read_timeout) = self.timeout_for(registry_key);

        // If client provided auth, use it on the initial probe; otherwise start unauthenticated
        let resp = if let Some(auth) = client_auth {
            self.make_request_with_auth_header(url, auth, accept, read_timeout)
                .await?
        } else {
            self.make_request_with_retry(url, None, accept, read_timeout)
                .await?
        };

        if resp.status == 401
            && let Some(www_auth) = &resp.www_authenticate
        {
            let www_auth = www_auth.clone();
            let cache_key = token_cache_key(registry_key, &www_auth, client_auth);

            // Check token cache
            if let Some(cached) = self.token_cache.get(&cache_key) {
                if cached.expires_at > Instant::now() {
                    self.metrics.inc(&self.metrics.token_cache_hits);
                    debug!("using cached token for auth challenge");
                    let retry = self
                        .make_request_with_retry(url, Some(&cached.token), accept, read_timeout)
                        .await?;
                    if retry.status != 401 {
                        return Ok(retry);
                    }
                    debug!("cached token was stale, fetching fresh token");
                }
                drop(cached);
                self.token_cache.remove(&cache_key);
                self.metrics.inc(&self.metrics.auth_token_refreshes);
            }

            let token = match self
                .fetch_token(registry_key, upstream_base_url, &www_auth, client_auth)
                .await
            {
                Ok(t) => t,
                Err(e) => {
                    warn!("token fetch failed for {}: {}", registry_key, e);
                    return Ok(UpstreamResponse {
                        status: 403,
                        www_authenticate: None,
                        content_type: None,
                        docker_content_digest: None,
                        body: bytes::Bytes::new(),
                    });
                }
            };
            let ttl = token_ttl(&token);
            debug!("caching token with TTL {}s", ttl.as_secs());
            self.token_cache.insert(
                cache_key,
                CachedToken {
                    token: token.clone(),
                    expires_at: Instant::now() + ttl,
                },
            );
            return self
                .make_request_with_retry(url, Some(&token), accept, read_timeout)
                .await;
        }

        Ok(resp)
    }

    /// Wraps `make_request` with retry logic for transient upstream failures
    /// (502/503/504 status codes and connection/timeout errors).
    async fn make_request_with_retry(
        &self,
        url: &str,
        token: Option<&str>,
        accept: Option<&str>,
        timeout: Duration,
    ) -> anyhow::Result<UpstreamResponse> {
        let mut last_err: Option<anyhow::Error> = None;

        for attempt in 0..=MAX_RETRIES {
            match self.make_request(url, token, accept, timeout).await {
                Ok(resp) => {
                    if is_retryable_status(resp.status) && attempt < MAX_RETRIES {
                        let delay = retry_delay(attempt);
                        warn!(
                            url,
                            status = resp.status,
                            attempt = attempt + 1,
                            max_retries = MAX_RETRIES,
                            delay_ms = delay.as_millis() as u64,
                            "retrying transient upstream failure"
                        );
                        tokio::time::sleep(delay).await;
                        continue;
                    }
                    return Ok(resp);
                }
                Err(e) => {
                    let is_transient = e
                        .downcast_ref::<reqwest::Error>()
                        .is_some_and(is_retryable_error);
                    if is_transient && attempt < MAX_RETRIES {
                        let delay = retry_delay(attempt);
                        warn!(
                            url,
                            error = %e,
                            attempt = attempt + 1,
                            max_retries = MAX_RETRIES,
                            delay_ms = delay.as_millis() as u64,
                            "retrying transient upstream connection error"
                        );
                        tokio::time::sleep(delay).await;
                        last_err = Some(e);
                        continue;
                    }
                    return Err(e);
                }
            }
        }

        // All retries exhausted due to connection errors
        Err(last_err.unwrap())
    }

    /// Like `make_request_with_retry` but sets the raw `Authorization` header
    /// directly, for forwarding client credentials to upstream.
    async fn make_request_with_auth_header(
        &self,
        url: &str,
        auth_header: &str,
        accept: Option<&str>,
        timeout: Duration,
    ) -> anyhow::Result<UpstreamResponse> {
        let mut last_err: Option<anyhow::Error> = None;

        for attempt in 0..=MAX_RETRIES {
            match self
                .make_request_raw_auth(url, auth_header, accept, timeout)
                .await
            {
                Ok(resp) => {
                    if is_retryable_status(resp.status) && attempt < MAX_RETRIES {
                        let delay = retry_delay(attempt);
                        warn!(
                            url,
                            status = resp.status,
                            attempt = attempt + 1,
                            max_retries = MAX_RETRIES,
                            delay_ms = delay.as_millis() as u64,
                            "retrying transient upstream failure"
                        );
                        tokio::time::sleep(delay).await;
                        continue;
                    }
                    return Ok(resp);
                }
                Err(e) => {
                    let is_transient = e
                        .downcast_ref::<reqwest::Error>()
                        .is_some_and(is_retryable_error);
                    if is_transient && attempt < MAX_RETRIES {
                        let delay = retry_delay(attempt);
                        warn!(
                            url,
                            error = %e,
                            attempt = attempt + 1,
                            max_retries = MAX_RETRIES,
                            delay_ms = delay.as_millis() as u64,
                            "retrying transient upstream connection error"
                        );
                        tokio::time::sleep(delay).await;
                        last_err = Some(e);
                        continue;
                    }
                    return Err(e);
                }
            }
        }

        Err(last_err.unwrap())
    }

    /// Single request with raw Authorization header (no bearer_auth).
    async fn make_request_raw_auth(
        &self,
        url: &str,
        auth_header: &str,
        accept: Option<&str>,
        timeout: Duration,
    ) -> anyhow::Result<UpstreamResponse> {
        let mut req = self
            .client
            .get(url)
            .timeout(timeout)
            .header("authorization", auth_header);

        if let Some(accept) = accept {
            req = req.header(reqwest::header::ACCEPT, accept);
        }

        let resp = req.send().await?;
        let status = resp.status().as_u16();

        let www_authenticate = resp
            .headers()
            .get("www-authenticate")
            .and_then(|v| v.to_str().ok())
            .map(|s| s.to_string());

        let content_type = resp
            .headers()
            .get("content-type")
            .and_then(|v| v.to_str().ok())
            .map(|s| s.to_string());

        let docker_content_digest = resp
            .headers()
            .get("docker-content-digest")
            .and_then(|v| v.to_str().ok())
            .map(|s| s.to_string());

        let body = resp.bytes().await?;

        if self.config.max_manifest_bytes > 0 && body.len() as u64 > self.config.max_manifest_bytes
        {
            self.metrics.inc(&self.metrics.manifest_size_rejected);
            anyhow::bail!(
                "manifest size {} exceeds limit {}",
                body.len(),
                self.config.max_manifest_bytes
            );
        }

        Ok(UpstreamResponse {
            status,
            www_authenticate,
            content_type,
            docker_content_digest,
            body,
        })
    }

    async fn make_request(
        &self,
        url: &str,
        token: Option<&str>,
        accept: Option<&str>,
        timeout: Duration,
    ) -> anyhow::Result<UpstreamResponse> {
        let mut req = self.client.get(url).timeout(timeout);

        if let Some(token) = token {
            req = req.bearer_auth(token);
        }

        if let Some(accept) = accept {
            req = req.header(reqwest::header::ACCEPT, accept);
        }

        let resp = req.send().await?;
        let status = resp.status().as_u16();

        let www_authenticate = resp
            .headers()
            .get("www-authenticate")
            .and_then(|v| v.to_str().ok())
            .map(|s| s.to_string());

        let content_type = resp
            .headers()
            .get("content-type")
            .and_then(|v| v.to_str().ok())
            .map(|s| s.to_string());

        let docker_content_digest = resp
            .headers()
            .get("docker-content-digest")
            .and_then(|v| v.to_str().ok())
            .map(|s| s.to_string());

        let body = resp.bytes().await?;

        // Reject manifests that exceed the configured size limit.
        // A limit of 0 means unlimited.
        if self.config.max_manifest_bytes > 0 && body.len() as u64 > self.config.max_manifest_bytes
        {
            self.metrics.inc(&self.metrics.manifest_size_rejected);
            anyhow::bail!(
                "manifest size {} exceeds limit {}",
                body.len(),
                self.config.max_manifest_bytes
            );
        }

        Ok(UpstreamResponse {
            status,
            www_authenticate,
            content_type,
            docker_content_digest,
            body,
        })
    }
}

pub struct BlobFetchResult {
    pub status: u16,
}

#[derive(Clone, Copy)]
pub struct BlobFetchRequest<'a> {
    pub registry_key: &'a str,
    pub registry_host: &'a str,
    pub repo: &'a str,
    pub digest: &'a str,
    pub client_auth: Option<&'a str>,
}

pub struct UpstreamResponse {
    pub status: u16,
    pub www_authenticate: Option<String>,
    pub content_type: Option<String>,
    pub docker_content_digest: Option<String>,
    pub body: bytes::Bytes,
}

fn extract_bearer_param(header: &str, key: &str) -> Option<String> {
    let search = format!("{}=\"", key);
    let mut offset = 0;
    while let Some(rel) = header[offset..].find(&search) {
        let pos = offset + rel;
        // Verify full key match: must be at start or preceded by whitespace/comma
        if pos == 0
            || matches!(
                header.as_bytes()[pos - 1],
                b' ' | b'\t' | b',' | b'\r' | b'\n'
            )
        {
            let start = pos + search.len();
            if let Some(end_rel) = header[start..].find('"') {
                return Some(header[start..start + end_rel].to_string());
            }
        }
        offset = pos + 1;
    }
    None
}

/// Decode a JWT's `exp` claim to compute remaining TTL.
/// Falls back to 60 seconds if parsing fails.
fn token_ttl(token: &str) -> Duration {
    const FALLBACK: Duration = Duration::from_secs(60);
    // Subtract 30s margin to avoid using a token right at expiry
    const MARGIN: Duration = Duration::from_secs(30);

    let parts: Vec<&str> = token.split('.').collect();
    if parts.len() < 2 {
        return FALLBACK;
    }

    let payload = match URL_SAFE_NO_PAD.decode(parts[1]) {
        Ok(p) => p,
        Err(_) => return FALLBACK,
    };

    #[derive(Deserialize)]
    struct Claims {
        exp: Option<u64>,
    }

    let claims: Claims = match serde_json::from_slice(&payload) {
        Ok(c) => c,
        Err(_) => return FALLBACK,
    };

    match claims.exp {
        Some(exp) => {
            let now = std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap_or_default()
                .as_secs();
            if exp <= now {
                return FALLBACK;
            }
            let remaining = Duration::from_secs(exp - now);
            remaining.saturating_sub(MARGIN).max(Duration::from_secs(5))
        }
        None => FALLBACK,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::Duration;

    const DOCKER_AUTH_HEADER: &str = r#"Bearer realm="https://auth.docker.io/token",service="registry.docker.io",scope="repository:library/alpine:pull""#;

    fn make_jwt(payload_json: &str) -> String {
        let header = URL_SAFE_NO_PAD.encode(b"{}");
        let payload = URL_SAFE_NO_PAD.encode(payload_json.as_bytes());
        format!("{}.{}.sig", header, payload)
    }

    fn now_secs() -> u64 {
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_secs()
    }

    // --- extract_bearer_param tests ---

    #[test]
    fn extract_bearer_param_realm() {
        let result = extract_bearer_param(DOCKER_AUTH_HEADER, "realm");
        assert_eq!(result, Some("https://auth.docker.io/token".to_string()));
    }

    #[test]
    fn extract_bearer_param_service() {
        let result = extract_bearer_param(DOCKER_AUTH_HEADER, "service");
        assert_eq!(result, Some("registry.docker.io".to_string()));
    }

    #[test]
    fn extract_bearer_param_scope() {
        let result = extract_bearer_param(DOCKER_AUTH_HEADER, "scope");
        assert_eq!(result, Some("repository:library/alpine:pull".to_string()));
    }

    #[test]
    fn extract_bearer_param_missing_key() {
        let result = extract_bearer_param(DOCKER_AUTH_HEADER, "nonexistent");
        assert_eq!(result, None);
    }

    #[test]
    fn extract_bearer_param_empty_header() {
        let result = extract_bearer_param("", "realm");
        assert_eq!(result, None);
    }

    // --- token_ttl tests ---

    #[test]
    fn token_ttl_valid_future_exp() {
        let exp = now_secs() + 300;
        let jwt = make_jwt(&format!(r#"{{"exp":{}}}"#, exp));
        let ttl = token_ttl(&jwt);
        // 300 - 30s margin = 270s, allow small timing tolerance
        assert!(
            ttl.as_secs() >= 265 && ttl.as_secs() <= 275,
            "expected ~270s, got {}s",
            ttl.as_secs()
        );
    }

    #[test]
    fn token_ttl_expired_token() {
        let exp = now_secs() - 100;
        let jwt = make_jwt(&format!(r#"{{"exp":{}}}"#, exp));
        let ttl = token_ttl(&jwt);
        assert_eq!(ttl, Duration::from_secs(60));
    }

    #[test]
    fn token_ttl_missing_exp_claim() {
        let jwt = make_jwt("{}");
        let ttl = token_ttl(&jwt);
        assert_eq!(ttl, Duration::from_secs(60));
    }

    #[test]
    fn token_ttl_not_a_jwt() {
        let ttl = token_ttl("notajwt");
        assert_eq!(ttl, Duration::from_secs(60));
    }

    #[test]
    fn token_ttl_invalid_base64_payload() {
        let ttl = token_ttl("a.!!!.c");
        assert_eq!(ttl, Duration::from_secs(60));
    }

    #[test]
    fn token_ttl_invalid_json_payload() {
        let header = URL_SAFE_NO_PAD.encode(b"{}");
        let payload = URL_SAFE_NO_PAD.encode(b"not json");
        let jwt = format!("{}.{}.sig", header, payload);
        let ttl = token_ttl(&jwt);
        assert_eq!(ttl, Duration::from_secs(60));
    }

    #[test]
    fn token_ttl_very_short_remaining() {
        let exp = now_secs() + 10;
        let jwt = make_jwt(&format!(r#"{{"exp":{}}}"#, exp));
        let ttl = token_ttl(&jwt);
        // 10 - 30 = negative, saturating_sub gives 0, max(0, 5) = 5s
        assert_eq!(ttl, Duration::from_secs(5));
    }

    #[test]
    fn token_ttl_exactly_at_margin() {
        // exp = now + 30, so remaining - margin = 0, clamped to 5s floor
        let exp = now_secs() + 30;
        let jwt = make_jwt(&format!(r#"{{"exp":{}}}"#, exp));
        let ttl = token_ttl(&jwt);
        assert_eq!(ttl, Duration::from_secs(5));
    }

    #[test]
    fn token_ttl_just_above_margin() {
        // exp = now + 35, so remaining - 30 = 5, which equals the floor
        let exp = now_secs() + 35;
        let jwt = make_jwt(&format!(r#"{{"exp":{}}}"#, exp));
        let ttl = token_ttl(&jwt);
        assert_eq!(ttl, Duration::from_secs(5));
    }

    #[test]
    fn token_ttl_two_dot_segments() {
        // Only header.payload (no signature) — still has 2 parts so it's processed
        let header = URL_SAFE_NO_PAD.encode(b"{}");
        let exp = now_secs() + 300;
        let payload = URL_SAFE_NO_PAD.encode(format!(r#"{{"exp":{}}}"#, exp).as_bytes());
        let jwt = format!("{}.{}", header, payload);
        let ttl = token_ttl(&jwt);
        assert!(ttl.as_secs() >= 265 && ttl.as_secs() <= 275);
    }

    #[test]
    fn extract_bearer_param_empty_value() {
        let header = r#"Bearer realm="",service="registry.docker.io""#;
        let result = extract_bearer_param(header, "realm");
        assert_eq!(result, Some("".to_string()));
    }

    #[test]
    fn extract_bearer_param_partial_key_match() {
        // Boundary check prevents "xservice" from matching "service"
        let header = r#"Bearer xservice="wrong",service="correct""#;
        let result = extract_bearer_param(header, "service");
        assert_eq!(result, Some("correct".to_string()));
    }

    #[test]
    fn extract_bearer_param_key_at_start() {
        let header = r#"realm="https://auth.example.com",service="svc""#;
        let result = extract_bearer_param(header, "realm");
        assert_eq!(result, Some("https://auth.example.com".to_string()));
    }

    #[test]
    fn extract_bearer_param_only_substring_matches() {
        // When the key only appears as a substring, should return None
        let header = r#"Bearer xrealm="value""#;
        let result = extract_bearer_param(header, "realm");
        assert_eq!(result, None);
    }

    #[test]
    fn extract_bearer_param_multiple_substring_collisions() {
        // Multiple substring hits before the real key
        let header = r#"Bearer aservice="a",bservice="b",service="real""#;
        let result = extract_bearer_param(header, "service");
        assert_eq!(result, Some("real".to_string()));
    }

    #[test]
    fn extract_bearer_param_tab_delimiter() {
        let header = "Bearer\trealm=\"https://auth.io/token\",\tservice=\"svc\"";
        assert_eq!(
            extract_bearer_param(header, "realm"),
            Some("https://auth.io/token".to_string())
        );
        assert_eq!(
            extract_bearer_param(header, "service"),
            Some("svc".to_string())
        );
    }

    #[test]
    fn token_ttl_exp_exactly_now() {
        let exp = now_secs();
        let jwt = make_jwt(&format!(r#"{{"exp":{}}}"#, exp));
        let ttl = token_ttl(&jwt);
        // exp <= now → fallback
        assert_eq!(ttl, Duration::from_secs(60));
    }

    // --- is_retryable_status tests ---

    #[test]
    fn retryable_status_502() {
        assert!(is_retryable_status(502));
    }

    #[test]
    fn retryable_status_503() {
        assert!(is_retryable_status(503));
    }

    #[test]
    fn retryable_status_504() {
        assert!(is_retryable_status(504));
    }

    #[test]
    fn non_retryable_status_200() {
        assert!(!is_retryable_status(200));
    }

    #[test]
    fn non_retryable_status_401() {
        assert!(!is_retryable_status(401));
    }

    #[test]
    fn non_retryable_status_403() {
        assert!(!is_retryable_status(403));
    }

    #[test]
    fn non_retryable_status_404() {
        assert!(!is_retryable_status(404));
    }

    #[test]
    fn non_retryable_status_500() {
        assert!(!is_retryable_status(500));
    }

    // --- retry_delay tests ---

    #[test]
    fn retry_delay_first_attempt() {
        assert_eq!(retry_delay(0), Duration::from_millis(100));
    }

    #[test]
    fn retry_delay_second_attempt() {
        assert_eq!(retry_delay(1), Duration::from_millis(400));
    }

    // --- is_server_error tests ---

    #[test]
    fn server_error_500() {
        assert!(is_server_error(500));
    }

    #[test]
    fn server_error_503() {
        assert!(is_server_error(503));
    }

    #[test]
    fn server_error_599() {
        assert!(is_server_error(599));
    }

    #[test]
    fn not_server_error_200() {
        assert!(!is_server_error(200));
    }

    #[test]
    fn not_server_error_404() {
        assert!(!is_server_error(404));
    }

    // --- circuit breaker tests ---

    fn make_client_for_circuit_tests() -> UpstreamClient {
        use crate::config::Config;
        use std::collections::HashMap;

        let config = Config {
            listen: "unused:0".to_string(),
            cache_dir: "/tmp".to_string(),
            manifest_ttl_seconds: 900,
            max_cache_bytes: None,
            eviction_interval_seconds: 300,
            connect_timeout_secs: 10,
            read_timeout_secs: 30,
            max_manifest_bytes: 10_485_760,
            negative_ttl_seconds: 60,
            offline_mode: false,
            upstreams: HashMap::new(),
            tls_listen: None,
            ca_cert_path: None,
            ca_key_path: None,
        };
        UpstreamClient::new(Arc::new(config), Arc::new(Metrics::default()))
    }

    #[test]
    fn circuit_below_threshold_stays_closed() {
        let client = make_client_for_circuit_tests();
        for _ in 0..CIRCUIT_FAILURE_THRESHOLD - 1 {
            client.record_failure("test_registry");
        }
        assert!(client.check_circuit("test_registry").is_ok());
    }

    #[test]
    fn circuit_at_threshold_trips_open() {
        let client = make_client_for_circuit_tests();
        for _ in 0..CIRCUIT_FAILURE_THRESHOLD {
            client.record_failure("test_registry");
        }
        let result = client.check_circuit("test_registry");
        assert!(result.is_err());
        match result.unwrap_err() {
            crate::UpstreamError::Unavailable(msg) => {
                assert!(msg.contains("circuit breaker open"), "got: {msg}");
            }
            other => panic!("expected Unavailable, got: {other:?}"),
        }
    }

    #[test]
    fn circuit_rejects_when_open() {
        let client = make_client_for_circuit_tests();
        for _ in 0..CIRCUIT_FAILURE_THRESHOLD {
            client.record_failure("test_registry");
        }
        for _ in 0..3 {
            assert!(client.check_circuit("test_registry").is_err());
        }
    }

    #[test]
    fn circuit_cooldown_allows_half_open() {
        let client = make_client_for_circuit_tests();
        for _ in 0..CIRCUIT_FAILURE_THRESHOLD {
            client.record_failure("test_registry");
        }
        assert!(client.check_circuit("test_registry").is_err());

        // Simulate cooldown expiry by backdating open_since
        let circuit = client.get_circuit("test_registry");
        let past = now_epoch_secs() - CIRCUIT_OPEN_DURATION_SECS - 1;
        circuit.open_since.store(past, Ordering::Relaxed);

        assert!(client.check_circuit("test_registry").is_ok());
    }

    #[test]
    fn circuit_success_resets_state() {
        let client = make_client_for_circuit_tests();
        for _ in 0..CIRCUIT_FAILURE_THRESHOLD {
            client.record_failure("test_registry");
        }
        assert!(client.check_circuit("test_registry").is_err());

        client.record_success("test_registry");

        let circuit = client.get_circuit("test_registry");
        assert_eq!(circuit.consecutive_failures.load(Ordering::Relaxed), 0);
        assert_eq!(circuit.open_since.load(Ordering::Relaxed), 0);
        assert!(client.check_circuit("test_registry").is_ok());
    }

    #[test]
    fn circuit_trips_metric_incremented() {
        let client = make_client_for_circuit_tests();
        for _ in 0..CIRCUIT_FAILURE_THRESHOLD {
            client.record_failure("test_registry");
        }
        let trips = client.metrics.circuit_breaker_trips.load(Ordering::Relaxed);
        assert_eq!(trips, 1);
    }

    #[test]
    fn circuit_extra_failures_dont_re_trip() {
        let client = make_client_for_circuit_tests();
        for _ in 0..CIRCUIT_FAILURE_THRESHOLD {
            client.record_failure("test_registry");
        }
        for _ in 0..10 {
            client.record_failure("test_registry");
        }
        let trips = client.metrics.circuit_breaker_trips.load(Ordering::Relaxed);
        assert_eq!(trips, 1, "circuit should only trip once");
    }

    #[test]
    fn circuit_independent_per_registry() {
        let client = make_client_for_circuit_tests();
        for _ in 0..CIRCUIT_FAILURE_THRESHOLD {
            client.record_failure("registry_a");
        }
        assert!(client.check_circuit("registry_a").is_err());
        assert!(client.check_circuit("registry_b").is_ok());
    }

    #[test]
    fn circuit_re_trips_after_reset() {
        let client = make_client_for_circuit_tests();
        for _ in 0..CIRCUIT_FAILURE_THRESHOLD {
            client.record_failure("test_registry");
        }
        assert!(client.check_circuit("test_registry").is_err());

        client.record_success("test_registry");
        assert!(client.check_circuit("test_registry").is_ok());

        for _ in 0..CIRCUIT_FAILURE_THRESHOLD {
            client.record_failure("test_registry");
        }
        assert!(client.check_circuit("test_registry").is_err());

        let trips = client.metrics.circuit_breaker_trips.load(Ordering::Relaxed);
        assert_eq!(trips, 2, "circuit should have tripped twice");
    }

    // --- timeout_for tests ---

    use crate::config::UpstreamConfig;

    fn make_client_with_upstreams(
        upstreams: std::collections::HashMap<String, UpstreamConfig>,
    ) -> UpstreamClient {
        let config = Config {
            listen: "unused:0".to_string(),
            cache_dir: "/tmp".to_string(),
            manifest_ttl_seconds: 900,
            max_cache_bytes: None,
            eviction_interval_seconds: 300,
            connect_timeout_secs: 10,
            read_timeout_secs: 30,
            max_manifest_bytes: 10_485_760,
            negative_ttl_seconds: 60,
            offline_mode: false,
            upstreams,
            tls_listen: None,
            ca_cert_path: None,
            ca_key_path: None,
        };
        UpstreamClient::new(Arc::new(config), Arc::new(Metrics::default()))
    }

    #[test]
    fn timeout_for_returns_global_defaults_when_no_upstreams() {
        let client = make_client_with_upstreams(std::collections::HashMap::new());
        let (connect, read) = client.timeout_for("unknown_registry");
        assert_eq!(connect, Duration::from_secs(10));
        assert_eq!(read, Duration::from_secs(30));
    }

    #[test]
    fn timeout_for_returns_global_defaults_for_upstream_without_overrides() {
        let mut upstreams = std::collections::HashMap::new();
        upstreams.insert(
            "gcr_io".to_string(),
            UpstreamConfig {
                registry: "https://gcr.io".into(),
                username: None,
                password: None,
                connect_timeout_secs: None,
                read_timeout_secs: None,
            },
        );
        let client = make_client_with_upstreams(upstreams);
        let (connect, read) = client.timeout_for("gcr_io");
        assert_eq!(connect, Duration::from_secs(10));
        assert_eq!(read, Duration::from_secs(30));
    }

    #[test]
    fn timeout_for_uses_per_upstream_overrides() {
        let mut upstreams = std::collections::HashMap::new();
        upstreams.insert(
            "docker_io".to_string(),
            UpstreamConfig {
                registry: "https://registry-1.docker.io".into(),
                username: None,
                password: None,
                connect_timeout_secs: Some(15),
                read_timeout_secs: Some(120),
            },
        );
        let client = make_client_with_upstreams(upstreams);
        let (connect, read) = client.timeout_for("docker_io");
        assert_eq!(connect, Duration::from_secs(15));
        assert_eq!(read, Duration::from_secs(120));
    }

    #[test]
    fn timeout_for_partial_override_uses_global_for_missing() {
        let mut upstreams = std::collections::HashMap::new();
        upstreams.insert(
            "docker_io".to_string(),
            UpstreamConfig {
                registry: "https://registry-1.docker.io".into(),
                username: None,
                password: None,
                connect_timeout_secs: None,
                read_timeout_secs: Some(90),
            },
        );
        let client = make_client_with_upstreams(upstreams);
        let (connect, read) = client.timeout_for("docker_io");
        assert_eq!(connect, Duration::from_secs(10));
        assert_eq!(read, Duration::from_secs(90));
    }

    #[test]
    fn timeout_for_with_custom_global_defaults() {
        let config = Config {
            listen: "unused:0".to_string(),
            cache_dir: "/tmp".to_string(),
            manifest_ttl_seconds: 900,
            max_cache_bytes: None,
            eviction_interval_seconds: 300,
            connect_timeout_secs: 5,
            read_timeout_secs: 60,
            max_manifest_bytes: 10_485_760,
            negative_ttl_seconds: 60,
            offline_mode: false,
            upstreams: std::collections::HashMap::new(),
            tls_listen: None,
            ca_cert_path: None,
            ca_key_path: None,
        };
        let client = UpstreamClient::new(Arc::new(config), Arc::new(Metrics::default()));
        let (connect, read) = client.timeout_for("any_registry");
        assert_eq!(connect, Duration::from_secs(5));
        assert_eq!(read, Duration::from_secs(60));
    }

    // --- token_cache_key tests ---

    #[test]
    fn token_cache_key_includes_registry() {
        let auth = r#"Bearer realm="https://auth.docker.io/token",service="registry.docker.io""#;
        let key_a = token_cache_key("docker_io", auth, None);
        let key_b = token_cache_key("ghcr_io", auth, None);
        assert_ne!(
            key_a, key_b,
            "different registries must produce different keys"
        );
        assert!(key_a.starts_with("docker_io:"));
        assert!(key_b.starts_with("ghcr_io:"));
    }

    #[test]
    fn token_cache_key_same_registry_same_auth_produces_same_key() {
        let auth = r#"Bearer realm="https://auth.docker.io/token""#;
        let key1 = token_cache_key("docker_io", auth, None);
        let key2 = token_cache_key("docker_io", auth, None);
        assert_eq!(key1, key2);
    }

    #[test]
    fn token_cache_key_same_registry_different_auth_produces_different_keys() {
        let auth_a = r#"Bearer realm="https://auth.docker.io/token",scope="repo:a:pull""#;
        let auth_b = r#"Bearer realm="https://auth.docker.io/token",scope="repo:b:pull""#;
        let key_a = token_cache_key("docker_io", auth_a, None);
        let key_b = token_cache_key("docker_io", auth_b, None);
        assert_ne!(key_a, key_b);
    }

    #[test]
    fn token_cache_key_client_auth_produces_different_key() {
        let www_auth = r#"Bearer realm="https://auth.docker.io/token""#;
        let key_anon = token_cache_key("docker_io", www_auth, None);
        let key_authed = token_cache_key("docker_io", www_auth, Some("Basic dXNlcjpwYXNz"));
        assert_ne!(
            key_anon, key_authed,
            "anonymous and authenticated must produce different cache keys"
        );
    }

    #[test]
    fn token_cache_key_different_client_auth_produces_different_keys() {
        let www_auth = r#"Bearer realm="https://auth.docker.io/token""#;
        let key_a = token_cache_key("docker_io", www_auth, Some("Basic dXNlcjE6cGFzcw=="));
        let key_b = token_cache_key("docker_io", www_auth, Some("Basic dXNlcjI6cGFzcw=="));
        assert_ne!(key_a, key_b);
    }

    #[test]
    fn token_cache_key_same_client_auth_is_deterministic() {
        let www_auth = r#"Bearer realm="https://auth.docker.io/token""#;
        let key1 = token_cache_key("docker_io", www_auth, Some("Bearer tok123"));
        let key2 = token_cache_key("docker_io", www_auth, Some("Bearer tok123"));
        assert_eq!(key1, key2);
    }

    #[test]
    fn token_realm_allowed_same_origin() {
        let realm = reqwest::Url::parse("http://127.0.0.1:5000/token").unwrap();
        assert!(UpstreamClient::token_realm_allowed(
            "http://127.0.0.1:5000",
            &realm
        ));
    }

    #[test]
    fn token_realm_allowed_docker_auth_service() {
        let realm = reqwest::Url::parse("https://auth.docker.io/token").unwrap();
        assert!(UpstreamClient::token_realm_allowed(
            "https://registry-1.docker.io",
            &realm
        ));
    }

    #[test]
    fn token_realm_rejects_unrelated_host() {
        let realm = reqwest::Url::parse("https://evil.example.com/token").unwrap();
        assert!(!UpstreamClient::token_realm_allowed(
            "https://registry-1.docker.io",
            &realm
        ));
    }

    #[test]
    fn token_realm_rejects_http_cross_origin() {
        let realm = reqwest::Url::parse("http://evil.example.com/token").unwrap();
        assert!(!UpstreamClient::token_realm_allowed(
            "https://registry-1.docker.io",
            &realm
        ));
    }

    // --- cleanup_expired_tokens tests ---

    #[test]
    fn cleanup_expired_tokens_removes_expired() {
        let client = make_client_for_circuit_tests();
        // Insert an already-expired token
        client.token_cache.insert(
            "expired_key".to_string(),
            CachedToken {
                token: "old_token".to_string(),
                expires_at: Instant::now() - Duration::from_secs(10),
            },
        );
        assert_eq!(client.token_cache.len(), 1);

        client.cleanup_expired_tokens();
        assert_eq!(client.token_cache.len(), 0);
    }

    #[test]
    fn cleanup_expired_tokens_retains_valid() {
        let client = make_client_for_circuit_tests();
        // Insert a token that expires in the future
        client.token_cache.insert(
            "valid_key".to_string(),
            CachedToken {
                token: "good_token".to_string(),
                expires_at: Instant::now() + Duration::from_secs(300),
            },
        );
        assert_eq!(client.token_cache.len(), 1);

        client.cleanup_expired_tokens();
        assert_eq!(client.token_cache.len(), 1);
        assert_eq!(
            client.token_cache.get("valid_key").unwrap().token,
            "good_token"
        );
    }

    #[test]
    fn cleanup_expired_tokens_mixed() {
        let client = make_client_for_circuit_tests();
        // Insert one expired and one valid token
        client.token_cache.insert(
            "expired".to_string(),
            CachedToken {
                token: "old".to_string(),
                expires_at: Instant::now() - Duration::from_secs(60),
            },
        );
        client.token_cache.insert(
            "valid".to_string(),
            CachedToken {
                token: "fresh".to_string(),
                expires_at: Instant::now() + Duration::from_secs(600),
            },
        );
        assert_eq!(client.token_cache.len(), 2);

        client.cleanup_expired_tokens();
        assert_eq!(client.token_cache.len(), 1);
        assert!(client.token_cache.get("expired").is_none());
        assert!(client.token_cache.get("valid").is_some());
    }

    #[test]
    fn cleanup_expired_tokens_empty_cache_is_noop() {
        let client = make_client_for_circuit_tests();
        assert_eq!(client.token_cache.len(), 0);
        client.cleanup_expired_tokens();
        assert_eq!(client.token_cache.len(), 0);
    }

    // --- circuit breaker half-open and concurrent token tests ---

    #[test]
    fn circuit_half_open_probe_failure_re_trips() {
        let client = make_client_for_circuit_tests();

        // Trip the circuit
        for _ in 0..CIRCUIT_FAILURE_THRESHOLD {
            client.record_failure("test_registry");
        }
        assert!(client.check_circuit("test_registry").is_err());

        // Simulate cooldown expiry by backdating open_since
        let circuit = client.get_circuit("test_registry");
        let past = now_epoch_secs() - CIRCUIT_OPEN_DURATION_SECS - 1;
        circuit.open_since.store(past, Ordering::Relaxed);

        // Half-open: probe is allowed through
        assert!(client.check_circuit("test_registry").is_ok());

        // Probe fails — record another failure
        client.record_failure("test_registry");

        // Circuit should still be open (open_since remains non-zero)
        let circuit = client.get_circuit("test_registry");
        let open_since = circuit.open_since.load(Ordering::Relaxed);
        assert!(
            open_since > 0,
            "circuit should still be open after probe failure"
        );

        // Consecutive failures should exceed the threshold
        let failures = circuit.consecutive_failures.load(Ordering::Relaxed);
        assert!(
            failures > CIRCUIT_FAILURE_THRESHOLD,
            "consecutive failures ({}) should exceed threshold ({})",
            failures,
            CIRCUIT_FAILURE_THRESHOLD
        );
    }

    #[test]
    fn cleanup_expired_tokens_concurrent_access() {
        use std::sync::Arc;
        use std::thread;

        let client = Arc::new(make_client_for_circuit_tests());

        // Pre-populate with a mix of expired and valid tokens
        for i in 0..100 {
            let expires = if i % 2 == 0 {
                Instant::now() - Duration::from_secs(10) // expired
            } else {
                Instant::now() + Duration::from_secs(300) // valid
            };
            client.token_cache.insert(
                format!("key_{}", i),
                CachedToken {
                    token: format!("token_{}", i),
                    expires_at: expires,
                },
            );
        }

        // Spawn threads that concurrently read, write, and cleanup
        let threads: Vec<_> = (0..10)
            .map(|t| {
                let c = Arc::clone(&client);
                thread::spawn(move || {
                    for j in 0..100 {
                        if t % 3 == 0 {
                            // Cleanup thread
                            c.cleanup_expired_tokens();
                        } else if t % 3 == 1 {
                            // Reader thread
                            let _ = c.token_cache.get(&format!("key_{}", j % 100));
                        } else {
                            // Writer thread
                            c.token_cache.insert(
                                format!("concurrent_key_{}_{}", t, j),
                                CachedToken {
                                    token: "t".to_string(),
                                    expires_at: Instant::now() + Duration::from_secs(60),
                                },
                            );
                        }
                    }
                })
            })
            .collect();

        for t in threads {
            t.join().unwrap();
        }

        // After all threads complete, cleanup once more
        client.cleanup_expired_tokens();

        // All remaining tokens should be valid (not expired)
        for entry in client.token_cache.iter() {
            assert!(
                entry.value().expires_at > Instant::now(),
                "found expired token after cleanup: {}",
                entry.key()
            );
        }
    }

    // --- reqwest feature tests ---

    #[test]
    fn reqwest_gzip_feature_enabled() {
        // Verify that reqwest is compiled with gzip support.
        // The gzip(true) call would fail at build time if the feature were missing.
        let client = reqwest::Client::builder()
            .gzip(true)
            .build()
            .expect("client with gzip should build successfully");
        drop(client);
    }

    #[test]
    fn reqwest_deflate_feature_enabled() {
        // Verify that reqwest is compiled with deflate support.
        let client = reqwest::Client::builder()
            .deflate(true)
            .build()
            .expect("client with deflate should build successfully");
        drop(client);
    }
}
