use serde::Deserialize;
use std::collections::HashMap;
use std::net::ToSocketAddrs;
use std::path::Path;

#[derive(Debug, Deserialize, Clone)]
#[serde(deny_unknown_fields)]
pub struct Config {
    pub listen: String,
    pub cache_dir: String,
    #[serde(default = "default_manifest_ttl")]
    pub manifest_ttl_seconds: u64,
    /// Maximum blob cache size in bytes. When exceeded, oldest blobs are evicted.
    /// Unset or 0 means unlimited.
    pub max_cache_bytes: Option<u64>,
    /// How often to check cache size and evict, in seconds. Default: 300 (5 min).
    #[serde(default = "default_eviction_interval")]
    pub eviction_interval_seconds: u64,
    /// Global default connect timeout in seconds. Default: 10.
    #[serde(default = "default_connect_timeout")]
    pub connect_timeout_secs: u64,
    /// Global default read/request timeout in seconds. Default: 30.
    #[serde(default = "default_read_timeout")]
    pub read_timeout_secs: u64,
    /// Maximum manifest size in bytes. Manifests larger than this are rejected.
    /// Default: 10 MB (10_485_760).
    #[serde(default = "default_max_manifest_bytes")]
    pub max_manifest_bytes: u64,
    /// TTL in seconds for negative cache entries (404/403). Default: 60. 0 disables.
    #[serde(default = "default_negative_ttl")]
    pub negative_ttl_seconds: u64,
    /// When true, serve from cache only. Skip all upstream fetches.
    #[serde(default)]
    pub offline_mode: bool,
    #[serde(default)]
    pub upstreams: HashMap<String, UpstreamConfig>,
    pub tls_listen: Option<String>,
    pub ca_cert_path: Option<String>,
    pub ca_key_path: Option<String>,
}

fn default_manifest_ttl() -> u64 {
    900
}

fn default_eviction_interval() -> u64 {
    300
}

fn default_connect_timeout() -> u64 {
    10
}

fn default_read_timeout() -> u64 {
    30
}

fn default_max_manifest_bytes() -> u64 {
    10_485_760
}

fn default_negative_ttl() -> u64 {
    60
}

#[derive(Debug, Deserialize, Clone)]
#[serde(deny_unknown_fields)]
pub struct UpstreamConfig {
    pub registry: String,
    pub username: Option<String>,
    pub password: Option<String>,
    /// Per-upstream connect timeout override (seconds).
    pub connect_timeout_secs: Option<u64>,
    /// Per-upstream read/request timeout override (seconds).
    pub read_timeout_secs: Option<u64>,
}

impl Config {
    pub fn load(path: &str) -> anyhow::Result<Self> {
        let content = std::fs::read_to_string(path)?;
        let config: Config = toml::from_str(&content).map_err(|e| {
            let msg = e.to_string();
            if msg.contains("unknown field") {
                anyhow::anyhow!(
                    "config error in {}: {}. Check for typos in field names.",
                    path,
                    msg
                )
            } else {
                anyhow::anyhow!("config error in {}: {}", path, msg)
            }
        })?;
        Ok(config)
    }

    /// Validate configuration values at startup.
    ///
    /// Returns an error for fatal misconfigurations (missing files, unparseable
    /// addresses). Emits warnings via `tracing::warn` for non-fatal issues
    /// (zero TTL, very small cache limits).
    pub fn validate(&self) -> anyhow::Result<()> {
        // 1. cache_dir must exist and be writable
        let cache_path = Path::new(&self.cache_dir);
        if !cache_path.exists() {
            anyhow::bail!("cache_dir '{}' does not exist", self.cache_dir);
        }
        let probe = cache_path.join(".drayage_write_probe");
        std::fs::write(&probe, b"probe").map_err(|e| {
            anyhow::anyhow!("cache_dir '{}' is not writable: {}", self.cache_dir, e)
        })?;
        let _ = std::fs::remove_file(&probe);

        // 2. TLS fields are all-or-nothing
        if self.tls_listen.is_some() || self.ca_cert_path.is_some() || self.ca_key_path.is_some() {
            let tls_listen = self.tls_listen.as_deref().ok_or_else(|| {
                anyhow::anyhow!("ca_cert_path/ca_key_path are set but tls_listen is missing")
            })?;
            let ca_cert = self
                .ca_cert_path
                .as_deref()
                .ok_or_else(|| anyhow::anyhow!("tls_listen is set but ca_cert_path is missing"))?;
            let ca_key = self
                .ca_key_path
                .as_deref()
                .ok_or_else(|| anyhow::anyhow!("tls_listen is set but ca_key_path is missing"))?;

            // Validate tls_listen is a valid socket address
            tls_listen.to_socket_addrs().map_err(|e| {
                anyhow::anyhow!(
                    "tls_listen '{}' is not a valid socket address: {}",
                    tls_listen,
                    e
                )
            })?;

            if !Path::new(ca_cert).exists() {
                anyhow::bail!("ca_cert_path '{}' does not exist", ca_cert);
            }
            if !Path::new(ca_key).exists() {
                anyhow::bail!("ca_key_path '{}' does not exist", ca_key);
            }
            warn_if_private_key_permissions_too_broad(ca_key)?;
        }

        // 3. listen address must be parseable
        self.listen.to_socket_addrs().map_err(|e| {
            anyhow::anyhow!(
                "listen '{}' is not a valid socket address: {}",
                self.listen,
                e
            )
        })?;

        // 4. TTL of 0 effectively disables caching
        if self.manifest_ttl_seconds == 0 {
            tracing::warn!("manifest_ttl_seconds is 0, manifest caching is effectively disabled");
        }

        // 5. Very small max_cache_bytes
        const ONE_MB: u64 = 1_048_576;
        if let Some(max) = self.max_cache_bytes
            && max > 0
            && max < ONE_MB
        {
            tracing::warn!(
                "max_cache_bytes is {} bytes (< 1 MB), this is unusually small for an OCI cache",
                max
            );
        }

        // 6. Upstream registry URLs must be valid HTTP/HTTPS URLs
        for (key, upstream) in &self.upstreams {
            let url = reqwest::Url::parse(&upstream.registry).map_err(|e| {
                anyhow::anyhow!(
                    "upstream '{}' has invalid registry URL '{}': {}",
                    key,
                    upstream.registry,
                    e
                )
            })?;
            match url.scheme() {
                "http" | "https" => {}
                scheme => {
                    anyhow::bail!(
                        "upstream '{}' registry URL must use http:// or https://, got '{}'",
                        key,
                        scheme
                    );
                }
            }
        }

        Ok(())
    }
}

#[cfg(unix)]
fn warn_if_private_key_permissions_too_broad(path: &str) -> anyhow::Result<()> {
    use std::os::unix::fs::PermissionsExt;

    let mode = std::fs::metadata(path)?.permissions().mode() & 0o777;
    if mode & 0o077 != 0 {
        tracing::warn!(
            "ca_key_path '{}' is readable by group/other (mode {:o}); use chmod 600 for production",
            path,
            mode
        );
    }
    Ok(())
}

#[cfg(not(unix))]
fn warn_if_private_key_permissions_too_broad(_path: &str) -> anyhow::Result<()> {
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    #[test]
    fn minimal_valid_config() {
        let mut f = NamedTempFile::new().unwrap();
        write!(
            f,
            r#"
listen = "0.0.0.0:5001"
cache_dir = "/cache"
"#
        )
        .unwrap();
        let config = Config::load(f.path().to_str().unwrap()).unwrap();
        assert_eq!(config.listen, "0.0.0.0:5001");
        assert_eq!(config.cache_dir, "/cache");
        assert_eq!(config.manifest_ttl_seconds, 900);
        assert_eq!(config.eviction_interval_seconds, 300);
        assert!(config.upstreams.is_empty());
        assert!(config.max_cache_bytes.is_none());
        assert!(config.tls_listen.is_none());
        assert!(config.ca_cert_path.is_none());
        assert!(config.ca_key_path.is_none());
    }

    #[test]
    fn full_config() {
        let mut f = NamedTempFile::new().unwrap();
        write!(
            f,
            r#"
listen = "0.0.0.0:5001"
cache_dir = "/cache"
manifest_ttl_seconds = 1800
max_cache_bytes = 10737418240
eviction_interval_seconds = 600
tls_listen = "0.0.0.0:443"
ca_cert_path = "/certs/ca.crt"
ca_key_path = "/certs/ca.key"

[upstreams.docker_io]
registry = "https://registry-1.docker.io"
username = "user"
password = "pass"
"#
        )
        .unwrap();
        let config = Config::load(f.path().to_str().unwrap()).unwrap();
        assert_eq!(config.listen, "0.0.0.0:5001");
        assert_eq!(config.cache_dir, "/cache");
        assert_eq!(config.manifest_ttl_seconds, 1800);
        assert_eq!(config.max_cache_bytes, Some(10737418240));
        assert_eq!(config.eviction_interval_seconds, 600);
        assert_eq!(config.tls_listen.as_deref(), Some("0.0.0.0:443"));
        assert_eq!(config.ca_cert_path.as_deref(), Some("/certs/ca.crt"));
        assert_eq!(config.ca_key_path.as_deref(), Some("/certs/ca.key"));

        let upstream = config.upstreams.get("docker_io").unwrap();
        assert_eq!(upstream.registry, "https://registry-1.docker.io");
        assert_eq!(upstream.username.as_deref(), Some("user"));
        assert_eq!(upstream.password.as_deref(), Some("pass"));
    }

    #[test]
    fn config_with_upstreams() {
        let mut f = NamedTempFile::new().unwrap();
        write!(
            f,
            r#"
listen = "0.0.0.0:5001"
cache_dir = "/cache"

[upstreams.docker_io]
registry = "https://registry-1.docker.io"
username = "myuser"
password = "mypass"

[upstreams.gcr_io]
registry = "https://gcr.io"
"#
        )
        .unwrap();
        let config = Config::load(f.path().to_str().unwrap()).unwrap();

        assert_eq!(config.upstreams.len(), 2);

        let docker = config.upstreams.get("docker_io").unwrap();
        assert_eq!(docker.registry, "https://registry-1.docker.io");
        assert_eq!(docker.username.as_deref(), Some("myuser"));
        assert_eq!(docker.password.as_deref(), Some("mypass"));

        let gcr = config.upstreams.get("gcr_io").unwrap();
        assert_eq!(gcr.registry, "https://gcr.io");
        assert!(gcr.username.is_none());
        assert!(gcr.password.is_none());
    }

    #[test]
    fn missing_listen_field() {
        let mut f = NamedTempFile::new().unwrap();
        write!(
            f,
            r#"
cache_dir = "/cache"
"#
        )
        .unwrap();
        let result = Config::load(f.path().to_str().unwrap());
        assert!(result.is_err());
    }

    #[test]
    fn invalid_toml() {
        let mut f = NamedTempFile::new().unwrap();
        f.write_all(b"this is not valid toml {{{").unwrap();
        let result = Config::load(f.path().to_str().unwrap());
        assert!(result.is_err());
    }

    #[test]
    fn default_ttl() {
        let mut f = NamedTempFile::new().unwrap();
        write!(
            f,
            r#"
listen = "0.0.0.0:5001"
cache_dir = "/cache"
"#
        )
        .unwrap();
        let config = Config::load(f.path().to_str().unwrap()).unwrap();
        assert_eq!(config.manifest_ttl_seconds, 900);
    }

    #[test]
    fn default_eviction_interval() {
        let mut f = NamedTempFile::new().unwrap();
        write!(
            f,
            r#"
listen = "0.0.0.0:5001"
cache_dir = "/cache"
"#
        )
        .unwrap();
        let config = Config::load(f.path().to_str().unwrap()).unwrap();
        assert_eq!(config.eviction_interval_seconds, 300);
    }

    #[test]
    fn nonexistent_file() {
        let result = Config::load("nonexistent.toml");
        assert!(result.is_err());
    }

    #[test]
    fn max_cache_bytes_zero() {
        let mut f = NamedTempFile::new().unwrap();
        write!(
            f,
            r#"
listen = "0.0.0.0:5001"
cache_dir = "/cache"
max_cache_bytes = 0
"#
        )
        .unwrap();
        let config = Config::load(f.path().to_str().unwrap()).unwrap();
        assert_eq!(config.max_cache_bytes, Some(0));
    }

    #[test]
    fn missing_cache_dir_field() {
        let mut f = NamedTempFile::new().unwrap();
        write!(
            f,
            r#"
listen = "0.0.0.0:5001"
"#
        )
        .unwrap();
        let result = Config::load(f.path().to_str().unwrap());
        assert!(result.is_err());
    }

    #[test]
    fn wrong_type_for_ttl() {
        let mut f = NamedTempFile::new().unwrap();
        write!(
            f,
            r#"
listen = "0.0.0.0:5001"
cache_dir = "/cache"
manifest_ttl_seconds = "not a number"
"#
        )
        .unwrap();
        let result = Config::load(f.path().to_str().unwrap());
        assert!(result.is_err());
    }

    #[test]
    fn upstream_without_auth() {
        let mut f = NamedTempFile::new().unwrap();
        write!(
            f,
            r#"
listen = "0.0.0.0:5001"
cache_dir = "/cache"

[upstreams.ghcr_io]
registry = "https://ghcr.io"
"#
        )
        .unwrap();
        let config = Config::load(f.path().to_str().unwrap()).unwrap();
        let upstream = config.upstreams.get("ghcr_io").unwrap();
        assert_eq!(upstream.registry, "https://ghcr.io");
        assert!(upstream.username.is_none());
        assert!(upstream.password.is_none());
    }

    #[test]
    fn unknown_fields_rejected() {
        let mut f = NamedTempFile::new().unwrap();
        write!(
            f,
            r#"
listen = "0.0.0.0:5001"
cache_dir = "/cache"
unknown_field = "should cause error"
"#
        )
        .unwrap();
        let result = Config::load(f.path().to_str().unwrap());
        let err = result.unwrap_err().to_string();
        assert!(
            err.contains("unknown field"),
            "error should mention unknown field: {err}"
        );
        assert!(
            err.contains("Check for typos"),
            "error should hint at typos: {err}"
        );
    }

    #[test]
    fn unknown_fields_in_upstream_rejected() {
        let mut f = NamedTempFile::new().unwrap();
        write!(
            f,
            r#"
listen = "0.0.0.0:5001"
cache_dir = "/cache"

[upstreams.docker_io]
registry = "https://registry-1.docker.io"
unknown_option = "typo"
"#
        )
        .unwrap();
        let result = Config::load(f.path().to_str().unwrap());
        assert!(
            result.is_err(),
            "unknown fields in upstream config should be rejected"
        );
    }

    #[test]
    fn empty_file() {
        let mut f = NamedTempFile::new().unwrap();
        f.write_all(b"").unwrap();
        let result = Config::load(f.path().to_str().unwrap());
        assert!(
            result.is_err(),
            "empty file should fail (missing required fields)"
        );
    }

    // --- validate() tests ---

    /// Helper: build a Config with a real writable cache_dir.
    fn valid_config(cache_dir: &std::path::Path) -> Config {
        Config {
            listen: "0.0.0.0:5001".into(),
            cache_dir: cache_dir.to_str().unwrap().into(),
            manifest_ttl_seconds: 900,
            max_cache_bytes: None,
            eviction_interval_seconds: 300,
            connect_timeout_secs: 10,
            read_timeout_secs: 30,
            max_manifest_bytes: 10_485_760,
            negative_ttl_seconds: 60,
            offline_mode: false,
            upstreams: HashMap::new(),
            tls_listen: None,
            ca_cert_path: None,
            ca_key_path: None,
        }
    }

    #[test]
    fn validate_passes_for_valid_config() {
        let dir = tempfile::tempdir().unwrap();
        let config = valid_config(dir.path());
        assert!(config.validate().is_ok());
    }

    #[test]
    fn validate_cache_dir_must_exist() {
        let config = Config {
            listen: "0.0.0.0:5001".into(),
            cache_dir: "/nonexistent/path/that/does/not/exist".into(),
            manifest_ttl_seconds: 900,
            max_cache_bytes: None,
            eviction_interval_seconds: 300,
            connect_timeout_secs: 10,
            read_timeout_secs: 30,
            max_manifest_bytes: 10_485_760,
            negative_ttl_seconds: 60,
            offline_mode: false,
            upstreams: HashMap::new(),
            tls_listen: None,
            ca_cert_path: None,
            ca_key_path: None,
        };
        let err = config.validate().unwrap_err().to_string();
        assert!(
            err.contains("does not exist"),
            "expected 'does not exist' in: {err}"
        );
    }

    #[test]
    fn validate_cache_dir_must_be_writable() {
        use std::os::unix::fs::PermissionsExt;
        let dir = tempfile::tempdir().unwrap();
        // Make directory read-only
        std::fs::set_permissions(dir.path(), std::fs::Permissions::from_mode(0o444)).unwrap();
        let config = valid_config(dir.path());
        let err = config.validate().unwrap_err().to_string();
        assert!(
            err.contains("not writable"),
            "expected 'not writable' in: {err}"
        );
        // Restore permissions so tempdir cleanup succeeds
        std::fs::set_permissions(dir.path(), std::fs::Permissions::from_mode(0o755)).unwrap();
    }

    #[test]
    fn validate_listen_address_must_be_parseable() {
        let dir = tempfile::tempdir().unwrap();
        let mut config = valid_config(dir.path());
        config.listen = "not-a-valid-address".into();
        let err = config.validate().unwrap_err().to_string();
        assert!(
            err.contains("not a valid socket address"),
            "expected socket address error in: {err}"
        );
    }

    #[test]
    fn validate_listen_address_valid_formats() {
        let dir = tempfile::tempdir().unwrap();
        for addr in &["0.0.0.0:5001", "127.0.0.1:8080", "[::]:5001"] {
            let mut config = valid_config(dir.path());
            config.listen = (*addr).into();
            assert!(
                config.validate().is_ok(),
                "address '{addr}' should be valid"
            );
        }
    }

    #[test]
    fn validate_tls_missing_cert_path() {
        let dir = tempfile::tempdir().unwrap();
        let mut config = valid_config(dir.path());
        config.tls_listen = Some("0.0.0.0:443".into());
        config.ca_key_path = Some("/some/key.pem".into());
        // ca_cert_path is None
        let err = config.validate().unwrap_err().to_string();
        assert!(
            err.contains("ca_cert_path is missing"),
            "expected missing cert error in: {err}"
        );
    }

    #[test]
    fn validate_tls_missing_key_path() {
        let dir = tempfile::tempdir().unwrap();
        let mut config = valid_config(dir.path());
        config.tls_listen = Some("0.0.0.0:443".into());
        config.ca_cert_path = Some("/some/cert.pem".into());
        // ca_key_path is None
        let err = config.validate().unwrap_err().to_string();
        assert!(
            err.contains("ca_key_path is missing"),
            "expected missing key error in: {err}"
        );
    }

    #[test]
    fn validate_tls_missing_listen() {
        let dir = tempfile::tempdir().unwrap();
        let mut config = valid_config(dir.path());
        // tls_listen is None but cert/key are set
        config.ca_cert_path = Some("/some/cert.pem".into());
        config.ca_key_path = Some("/some/key.pem".into());
        let err = config.validate().unwrap_err().to_string();
        assert!(
            err.contains("tls_listen is missing"),
            "expected missing tls_listen error in: {err}"
        );
    }

    #[test]
    fn validate_tls_cert_file_must_exist() {
        let dir = tempfile::tempdir().unwrap();
        let key_file = NamedTempFile::new().unwrap();
        let mut config = valid_config(dir.path());
        config.tls_listen = Some("0.0.0.0:443".into());
        config.ca_cert_path = Some("/nonexistent/cert.pem".into());
        config.ca_key_path = Some(key_file.path().to_str().unwrap().into());
        let err = config.validate().unwrap_err().to_string();
        assert!(
            err.contains("ca_cert_path") && err.contains("does not exist"),
            "expected cert file missing error in: {err}"
        );
    }

    #[test]
    fn validate_tls_key_file_must_exist() {
        let dir = tempfile::tempdir().unwrap();
        let cert_file = NamedTempFile::new().unwrap();
        let mut config = valid_config(dir.path());
        config.tls_listen = Some("0.0.0.0:443".into());
        config.ca_cert_path = Some(cert_file.path().to_str().unwrap().into());
        config.ca_key_path = Some("/nonexistent/key.pem".into());
        let err = config.validate().unwrap_err().to_string();
        assert!(
            err.contains("ca_key_path") && err.contains("does not exist"),
            "expected key file missing error in: {err}"
        );
    }

    #[test]
    fn validate_tls_invalid_listen_address() {
        let dir = tempfile::tempdir().unwrap();
        let cert_file = NamedTempFile::new().unwrap();
        let key_file = NamedTempFile::new().unwrap();
        let mut config = valid_config(dir.path());
        config.tls_listen = Some("garbage".into());
        config.ca_cert_path = Some(cert_file.path().to_str().unwrap().into());
        config.ca_key_path = Some(key_file.path().to_str().unwrap().into());
        let err = config.validate().unwrap_err().to_string();
        assert!(
            err.contains("not a valid socket address"),
            "expected socket address error for tls_listen in: {err}"
        );
    }

    #[test]
    fn validate_tls_all_valid() {
        let dir = tempfile::tempdir().unwrap();
        let cert_file = NamedTempFile::new().unwrap();
        let key_file = NamedTempFile::new().unwrap();
        let mut config = valid_config(dir.path());
        config.tls_listen = Some("0.0.0.0:443".into());
        config.ca_cert_path = Some(cert_file.path().to_str().unwrap().into());
        config.ca_key_path = Some(key_file.path().to_str().unwrap().into());
        assert!(config.validate().is_ok());
    }

    #[test]
    fn validate_no_tls_fields_is_ok() {
        let dir = tempfile::tempdir().unwrap();
        let config = valid_config(dir.path());
        // All TLS fields are None
        assert!(config.validate().is_ok());
    }

    #[test]
    fn validate_ttl_zero_warns_but_passes() {
        let dir = tempfile::tempdir().unwrap();
        let mut config = valid_config(dir.path());
        config.manifest_ttl_seconds = 0;
        // Should succeed (warning only, not an error)
        assert!(config.validate().is_ok());
    }

    #[test]
    fn validate_max_cache_bytes_small_warns_but_passes() {
        let dir = tempfile::tempdir().unwrap();
        let mut config = valid_config(dir.path());
        config.max_cache_bytes = Some(1024); // 1 KB, well under 1 MB
        // Should succeed (warning only, not an error)
        assert!(config.validate().is_ok());
    }

    #[test]
    fn validate_max_cache_bytes_zero_no_warning() {
        let dir = tempfile::tempdir().unwrap();
        let mut config = valid_config(dir.path());
        config.max_cache_bytes = Some(0);
        // 0 means unlimited, should not warn
        assert!(config.validate().is_ok());
    }

    #[test]
    fn validate_max_cache_bytes_above_1mb_ok() {
        let dir = tempfile::tempdir().unwrap();
        let mut config = valid_config(dir.path());
        config.max_cache_bytes = Some(10 * 1_048_576); // 10 MB
        assert!(config.validate().is_ok());
    }

    #[test]
    fn validate_max_cache_bytes_none_ok() {
        let dir = tempfile::tempdir().unwrap();
        let config = valid_config(dir.path());
        // max_cache_bytes is None (unlimited)
        assert!(config.validate().is_ok());
    }

    // --- timeout config tests ---

    #[test]
    fn default_timeouts() {
        let mut f = NamedTempFile::new().unwrap();
        write!(
            f,
            r#"
listen = "0.0.0.0:5001"
cache_dir = "/cache"
"#
        )
        .unwrap();
        let config = Config::load(f.path().to_str().unwrap()).unwrap();
        assert_eq!(config.connect_timeout_secs, 10);
        assert_eq!(config.read_timeout_secs, 30);
    }

    #[test]
    fn custom_global_timeouts() {
        let mut f = NamedTempFile::new().unwrap();
        write!(
            f,
            r#"
listen = "0.0.0.0:5001"
cache_dir = "/cache"
connect_timeout_secs = 5
read_timeout_secs = 60
"#
        )
        .unwrap();
        let config = Config::load(f.path().to_str().unwrap()).unwrap();
        assert_eq!(config.connect_timeout_secs, 5);
        assert_eq!(config.read_timeout_secs, 60);
    }

    #[test]
    fn upstream_timeout_overrides() {
        let mut f = NamedTempFile::new().unwrap();
        write!(
            f,
            r#"
listen = "0.0.0.0:5001"
cache_dir = "/cache"
connect_timeout_secs = 5
read_timeout_secs = 60

[upstreams.docker_io]
registry = "https://registry-1.docker.io"
connect_timeout_secs = 15
read_timeout_secs = 120

[upstreams.gcr_io]
registry = "https://gcr.io"
"#
        )
        .unwrap();
        let config = Config::load(f.path().to_str().unwrap()).unwrap();

        let docker = config.upstreams.get("docker_io").unwrap();
        assert_eq!(docker.connect_timeout_secs, Some(15));
        assert_eq!(docker.read_timeout_secs, Some(120));

        let gcr = config.upstreams.get("gcr_io").unwrap();
        assert_eq!(gcr.connect_timeout_secs, None);
        assert_eq!(gcr.read_timeout_secs, None);
    }

    #[test]
    fn upstream_partial_timeout_override() {
        let mut f = NamedTempFile::new().unwrap();
        write!(
            f,
            r#"
listen = "0.0.0.0:5001"
cache_dir = "/cache"

[upstreams.docker_io]
registry = "https://registry-1.docker.io"
read_timeout_secs = 90
"#
        )
        .unwrap();
        let config = Config::load(f.path().to_str().unwrap()).unwrap();
        let docker = config.upstreams.get("docker_io").unwrap();
        assert_eq!(docker.connect_timeout_secs, None);
        assert_eq!(docker.read_timeout_secs, Some(90));
    }

    // --- max_manifest_bytes config tests ---

    #[test]
    fn default_max_manifest_bytes() {
        let mut f = NamedTempFile::new().unwrap();
        write!(
            f,
            r#"
listen = "0.0.0.0:5001"
cache_dir = "/cache"
"#
        )
        .unwrap();
        let config = Config::load(f.path().to_str().unwrap()).unwrap();
        assert_eq!(config.max_manifest_bytes, 10_485_760);
    }

    #[test]
    fn custom_max_manifest_bytes() {
        let mut f = NamedTempFile::new().unwrap();
        write!(
            f,
            r#"
listen = "0.0.0.0:5001"
cache_dir = "/cache"
max_manifest_bytes = 5242880
"#
        )
        .unwrap();
        let config = Config::load(f.path().to_str().unwrap()).unwrap();
        assert_eq!(config.max_manifest_bytes, 5_242_880);
    }

    #[test]
    fn max_manifest_bytes_zero_means_unlimited() {
        let mut f = NamedTempFile::new().unwrap();
        write!(
            f,
            r#"
listen = "0.0.0.0:5001"
cache_dir = "/cache"
max_manifest_bytes = 0
"#
        )
        .unwrap();
        let config = Config::load(f.path().to_str().unwrap()).unwrap();
        assert_eq!(config.max_manifest_bytes, 0);
    }

    // --- upstream URL validation tests ---

    #[test]
    fn validate_upstream_valid_https_url() {
        let dir = tempfile::tempdir().unwrap();
        let mut config = valid_config(dir.path());
        config.upstreams.insert(
            "docker_io".into(),
            UpstreamConfig {
                registry: "https://registry-1.docker.io".into(),
                username: None,
                password: None,
                connect_timeout_secs: None,
                read_timeout_secs: None,
            },
        );
        assert!(config.validate().is_ok());
    }

    #[test]
    fn validate_upstream_valid_http_url() {
        let dir = tempfile::tempdir().unwrap();
        let mut config = valid_config(dir.path());
        config.upstreams.insert(
            "local".into(),
            UpstreamConfig {
                registry: "http://localhost:5000".into(),
                username: None,
                password: None,
                connect_timeout_secs: None,
                read_timeout_secs: None,
            },
        );
        assert!(config.validate().is_ok());
    }

    #[test]
    fn validate_upstream_invalid_url() {
        let dir = tempfile::tempdir().unwrap();
        let mut config = valid_config(dir.path());
        config.upstreams.insert(
            "bad".into(),
            UpstreamConfig {
                registry: "not-a-url".into(),
                username: None,
                password: None,
                connect_timeout_secs: None,
                read_timeout_secs: None,
            },
        );
        let err = config.validate().unwrap_err().to_string();
        assert!(err.contains("invalid registry URL"), "got: {err}");
    }

    #[test]
    fn validate_upstream_wrong_scheme() {
        let dir = tempfile::tempdir().unwrap();
        let mut config = valid_config(dir.path());
        config.upstreams.insert(
            "bad".into(),
            UpstreamConfig {
                registry: "ftp://registry.example.com".into(),
                username: None,
                password: None,
                connect_timeout_secs: None,
                read_timeout_secs: None,
            },
        );
        let err = config.validate().unwrap_err().to_string();
        assert!(err.contains("http:// or https://"), "got: {err}");
    }
}
