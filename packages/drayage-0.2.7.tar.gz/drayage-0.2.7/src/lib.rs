pub mod cache;
pub mod config;
pub mod gen_ca;
pub(crate) mod handlers;
pub mod init;
pub mod metrics;
pub mod negative_cache;
pub mod registry;
pub mod server;
pub mod tls;
pub mod upstream;

use std::sync::Arc;
use std::time::Instant;

use dashmap::DashMap;
use tokio::sync::OnceCell;

/// Typed error for upstream fetch failures, replacing stringly-typed errors
/// in the inflight coalescing map.
#[derive(Clone, Debug)]
pub enum UpstreamError {
    /// The requested resource does not exist upstream (HTTP 404).
    NotFound,
    /// The requested resource was permanently deleted upstream (HTTP 410).
    Gone,
    /// Upstream returned a non-200/non-404/non-410 status code.
    BadGateway(u16),
    /// Network or other transport-level failure.
    Unavailable(String),
}

impl std::fmt::Display for UpstreamError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::NotFound => write!(f, "not found"),
            Self::Gone => write!(f, "gone (permanently deleted)"),
            Self::BadGateway(status) => write!(f, "bad gateway (upstream returned {status})"),
            Self::Unavailable(msg) => write!(f, "unavailable: {msg}"),
        }
    }
}

impl std::error::Error for UpstreamError {}

/// Shared inflight map for request coalescing.
/// Key format: `"blob:{digest}"` or `"manifest:{registry}:{repo}:{reference}"`.
/// Multiple concurrent requests for the same resource share one upstream fetch.
pub type InflightMap = DashMap<String, Arc<OnceCell<Result<(), UpstreamError>>>>;

/// RAII guard that removes an inflight map entry when dropped.
/// Ensures cleanup even if the handler is cancelled (client disconnect).
pub struct InflightGuard {
    map: Arc<InflightMap>,
    key: String,
}

impl InflightGuard {
    pub fn new(map: Arc<InflightMap>, key: String) -> Self {
        Self { map, key }
    }
}

impl Drop for InflightGuard {
    fn drop(&mut self) {
        self.map.remove(&self.key);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn upstream_error_display_not_found() {
        assert_eq!(UpstreamError::NotFound.to_string(), "not found");
    }

    #[test]
    fn upstream_error_display_gone() {
        assert_eq!(
            UpstreamError::Gone.to_string(),
            "gone (permanently deleted)"
        );
    }

    #[test]
    fn upstream_error_display_bad_gateway() {
        assert_eq!(
            UpstreamError::BadGateway(502).to_string(),
            "bad gateway (upstream returned 502)"
        );
    }

    #[test]
    fn upstream_error_display_unavailable() {
        assert_eq!(
            UpstreamError::Unavailable("timeout".to_string()).to_string(),
            "unavailable: timeout"
        );
    }

    #[test]
    fn inflight_guard_removes_entry_on_drop() {
        let map: Arc<InflightMap> = Arc::new(DashMap::new());
        map.insert("test_key".to_string(), Arc::new(OnceCell::new()));
        assert_eq!(map.len(), 1);

        {
            let _guard = InflightGuard::new(map.clone(), "test_key".to_string());
            assert_eq!(map.len(), 1);
        } // guard dropped here

        assert_eq!(map.len(), 0);
    }

    #[test]
    fn inflight_guard_noop_if_key_already_removed() {
        let map: Arc<InflightMap> = Arc::new(DashMap::new());
        map.insert("key".to_string(), Arc::new(OnceCell::new()));

        let guard = InflightGuard::new(map.clone(), "key".to_string());
        map.remove("key"); // manually removed before guard drops
        assert_eq!(map.len(), 0);

        drop(guard); // should not panic
        assert_eq!(map.len(), 0);
    }

    #[test]
    fn inflight_guard_only_removes_its_own_key() {
        let map: Arc<InflightMap> = Arc::new(DashMap::new());
        map.insert("key_a".to_string(), Arc::new(OnceCell::new()));
        map.insert("key_b".to_string(), Arc::new(OnceCell::new()));

        {
            let _guard = InflightGuard::new(map.clone(), "key_a".to_string());
        }

        assert_eq!(map.len(), 1);
        assert!(map.contains_key("key_b"));
    }
}

/// Shared application state threaded through all Axum handlers.
///
/// Holds the filesystem cache, the upstream HTTP client, an inflight-request
/// map used for coalescing duplicate fetches, and atomic Prometheus metrics.
#[derive(Clone)]
pub struct AppState {
    pub cache: Arc<cache::Cache>,
    pub upstream: Arc<upstream::UpstreamClient>,
    pub inflight: Arc<InflightMap>,
    pub metrics: Arc<metrics::Metrics>,
    pub negative_cache: Arc<negative_cache::NegativeCache>,
    pub config: Arc<config::Config>,
    /// Tracks when a stale-while-revalidate background task was last spawned
    /// for each tag, to prevent hammering a down upstream on every request.
    pub revalidation_tracker: Arc<DashMap<String, Instant>>,
}
