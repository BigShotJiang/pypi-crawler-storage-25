use std::sync::Arc;
use std::time::Duration;

use clap::{Parser, Subcommand};
use dashmap::DashMap;
use tokio::signal::unix::SignalKind;
use tokio_util::sync::CancellationToken;
use tracing::{info, warn};

use drayage::AppState;
use drayage::cache::Cache;
use drayage::config;
use drayage::metrics::Metrics;
use drayage::negative_cache::NegativeCache;
use drayage::server;
use drayage::tls;
use drayage::upstream::UpstreamClient;

#[derive(Parser)]
#[command(name = "drayage", about = "OCI registry pull-through cache", version)]
struct Cli {
    #[command(subcommand)]
    command: Option<Command>,
}

#[derive(Subcommand)]
enum Command {
    /// Run the cache server
    Serve(ServeArgs),
    /// Generate a default config.toml
    Init(InitArgs),
    /// Generate a CA certificate and key for the TLS transparent proxy
    GenCa(GenCaArgs),
    /// Check the server readiness endpoint and exit non-zero on failure
    Healthcheck(HealthcheckArgs),
}

#[derive(clap::Args)]
struct ServeArgs {
    #[arg(short, long, default_value = "./config.toml")]
    config: String,
    /// Output logs as JSON lines (for log aggregation)
    #[arg(long, default_value_t = false)]
    log_json: bool,
}

#[derive(clap::Args)]
struct InitArgs {
    /// Output path for the generated config file
    #[arg(short, long, default_value = "./config.toml")]
    path: String,
    /// Overwrite existing config file
    #[arg(long)]
    force: bool,
    /// Generate containerd mirror hosts.toml files instead of a drayage config
    #[arg(long)]
    containerd: bool,
    /// Output directory for containerd hosts.toml files
    #[arg(long, default_value = "/etc/containerd/certs.d")]
    containerd_dir: String,
    /// Drayage URL for containerd mirror config (required with --containerd)
    #[arg(long)]
    drayage_url: Option<String>,
}

#[derive(clap::Args)]
struct GenCaArgs {
    /// Output directory for ca.crt and ca.key
    #[arg(short, long, default_value = "./certs")]
    dir: String,
    /// Overwrite existing CA files
    #[arg(long)]
    force: bool,
}

#[derive(clap::Args)]
struct HealthcheckArgs {
    /// Readiness URL to check
    #[arg(long, default_value = "http://127.0.0.1:5001/readyz")]
    url: String,
    /// Request timeout in seconds
    #[arg(long, default_value_t = 2)]
    timeout_secs: u64,
}

/// Wait for SIGINT (Ctrl+C) or SIGTERM, then return.
async fn shutdown_signal() {
    let ctrl_c = tokio::signal::ctrl_c();
    let mut sigterm =
        tokio::signal::unix::signal(SignalKind::terminate()).expect("failed to register SIGTERM");
    tokio::select! {
        _ = ctrl_c => info!("received SIGINT, shutting down"),
        _ = sigterm.recv() => info!("received SIGTERM, shutting down"),
    }
}

async fn run_server(config_path: &str) -> anyhow::Result<()> {
    let config = config::Config::load(config_path)?;
    config.validate()?;
    let config = Arc::new(config);

    info!("starting drayage on {}", config.listen);
    info!("cache dir: {}", config.cache_dir);

    let metrics = Arc::new(Metrics::default());
    let cache = Arc::new(Cache::new(
        &config.cache_dir,
        config.manifest_ttl_seconds,
        Some(metrics.clone()),
    )?);
    let upstream = Arc::new(UpstreamClient::new(config.clone(), metrics.clone()));
    let negative_cache = Arc::new(NegativeCache::new(config.negative_ttl_seconds));

    let state = AppState {
        cache,
        upstream,
        inflight: Arc::new(DashMap::new()),
        metrics,
        negative_cache,
        config: config.clone(),
        revalidation_tracker: Arc::new(DashMap::new()),
    };

    let cancel = CancellationToken::new();

    // Spawn background cache eviction task if a size limit is configured
    if let Some(max_bytes) = config.max_cache_bytes
        && max_bytes > 0
    {
        let eviction_cache = state.cache.clone();
        let interval_secs = config.eviction_interval_seconds;
        let eviction_cancel = cancel.clone();
        info!(
            "cache eviction enabled: max {}MB, checking every {}s",
            max_bytes / (1024 * 1024),
            interval_secs
        );
        tokio::spawn(async move {
            let mut interval = tokio::time::interval(std::time::Duration::from_secs(interval_secs));
            loop {
                tokio::select! {
                    _ = interval.tick() => {
                        if let Err(e) = eviction_cache.evict_blobs(max_bytes).await {
                            warn!("cache eviction error: {}", e);
                        }
                    }
                    _ = eviction_cancel.cancelled() => {
                        info!("eviction task stopping");
                        break;
                    }
                }
            }
        });
    }

    // Spawn background task to clean up expired auth tokens every 60 seconds
    {
        let cleanup_upstream = state.upstream.clone();
        let cleanup_cancel = cancel.clone();
        tokio::spawn(async move {
            let mut interval = tokio::time::interval(std::time::Duration::from_secs(60));
            loop {
                tokio::select! {
                    _ = interval.tick() => {
                        cleanup_upstream.cleanup_expired_tokens();
                    }
                    _ = cleanup_cancel.cancelled() => {
                        info!("token cleanup task stopping");
                        break;
                    }
                }
            }
        });
    }

    // Spawn background task to clean up expired negative cache entries
    if config.negative_ttl_seconds > 0 {
        let neg_cache = state.negative_cache.clone();
        let neg_cancel = cancel.clone();
        tokio::spawn(async move {
            let mut interval = tokio::time::interval(std::time::Duration::from_secs(60));
            loop {
                tokio::select! {
                    _ = interval.tick() => {
                        neg_cache.cleanup();
                    }
                    _ = neg_cancel.cancelled() => {
                        info!("negative cache cleanup task stopping");
                        break;
                    }
                }
            }
        });
    }

    // Drive shutdown_signal → cancel the token
    let signal_cancel = cancel.clone();
    tokio::spawn(async move {
        shutdown_signal().await;
        signal_cancel.cancel();
    });

    if let (Some(tls_addr), Some(ca_cert), Some(ca_key)) = (
        &config.tls_listen,
        &config.ca_cert_path,
        &config.ca_key_path,
    ) {
        rustls::crypto::ring::default_provider()
            .install_default()
            .expect("failed to install rustls ring provider");

        let allowed_hosts: Vec<String> = config
            .upstreams
            .values()
            .filter_map(|u| reqwest::Url::parse(&u.registry).ok())
            .filter_map(|url| url.host_str().map(|h| h.to_string()))
            .collect();
        let allowed = if allowed_hosts.is_empty() {
            None
        } else {
            Some(allowed_hosts)
        };
        let resolver = Arc::new(tls::SniCertResolver::load(ca_cert, ca_key, allowed)?);
        let http_state = state.clone();
        let tls_state = state.clone();
        let http_addr = config.listen.clone();
        let tls_addr = tls_addr.clone();
        let http_cancel = cancel.clone();
        let tls_cancel = cancel.clone();

        tokio::try_join!(
            async {
                let listener = tokio::net::TcpListener::bind(&http_addr).await?;
                info!("HTTP listener on {}", http_addr);
                axum::serve(listener, server::build_router(http_state))
                    .with_graceful_shutdown(http_cancel.cancelled_owned())
                    .await?;
                Ok::<(), anyhow::Error>(())
            },
            server::serve_tls(tls_state, &tls_addr, resolver, tls_cancel),
        )?;
    } else {
        let listener = tokio::net::TcpListener::bind(&config.listen).await?;
        info!("listening on {}", config.listen);
        axum::serve(listener, server::build_router(state))
            .with_graceful_shutdown(cancel.cancelled_owned())
            .await?;
    }

    info!("shutdown complete");
    Ok(())
}

async fn run_healthcheck(url: &str, timeout_secs: u64) -> anyhow::Result<()> {
    if timeout_secs == 0 {
        anyhow::bail!("--timeout-secs must be greater than 0");
    }

    let client = reqwest::Client::builder()
        .timeout(Duration::from_secs(timeout_secs))
        .build()?;
    let status = client.get(url).send().await?.status();

    if status.is_success() {
        Ok(())
    } else {
        anyhow::bail!("healthcheck failed: {} returned {}", url, status);
    }
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let cli = Cli::parse();

    match cli.command {
        Some(Command::Init(args)) => {
            if args.containerd {
                let drayage_url = args.drayage_url.ok_or_else(|| {
                    anyhow::anyhow!("--drayage-url is required with --containerd")
                })?;
                drayage::init::run_containerd(
                    &args.path,
                    &args.containerd_dir,
                    &drayage_url,
                    args.force,
                )
            } else {
                drayage::init::run(&args.path, args.force)
            }
        }
        Some(Command::GenCa(args)) => drayage::gen_ca::run(&args.dir, args.force),
        Some(Command::Healthcheck(args)) => run_healthcheck(&args.url, args.timeout_secs).await,
        Some(Command::Serve(args)) => {
            init_tracing(args.log_json);
            run_server(&args.config).await
        }
        None => {
            init_tracing(false);
            run_server("./config.toml").await
        }
    }
}

fn init_tracing(json: bool) {
    let filter = tracing_subscriber::EnvFilter::try_from_default_env()
        .unwrap_or_else(|_| "drayage=info".into());
    if json {
        tracing_subscriber::fmt()
            .json()
            .with_env_filter(filter)
            .init();
    } else {
        tracing_subscriber::fmt().with_env_filter(filter).init();
    }
}
