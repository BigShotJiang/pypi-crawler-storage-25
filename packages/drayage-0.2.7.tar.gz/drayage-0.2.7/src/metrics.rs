use std::sync::atomic::{AtomicU64, Ordering};
use std::time::Duration;

use dashmap::DashMap;

/// Standard Prometheus HTTP latency buckets (in seconds).
const LATENCY_BUCKETS: &[f64] = &[
    0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0,
];

/// A Prometheus counter with a single label dimension (e.g., `registry`).
pub struct LabeledCounter {
    label_name: &'static str,
    counters: DashMap<String, AtomicU64>,
}

impl LabeledCounter {
    pub fn new(label_name: &'static str) -> Self {
        Self {
            label_name,
            counters: DashMap::new(),
        }
    }

    /// Increment the counter for the given label value by 1.
    pub fn inc(&self, label_value: &str) {
        self.counters
            .entry(label_value.to_string())
            .or_insert_with(|| AtomicU64::new(0))
            .fetch_add(1, Ordering::Relaxed);
    }

    /// Add `value` to the counter for the given label value.
    pub fn add(&self, label_value: &str, value: u64) {
        self.counters
            .entry(label_value.to_string())
            .or_insert_with(|| AtomicU64::new(0))
            .fetch_add(value, Ordering::Relaxed);
    }

    /// Render this labeled counter in Prometheus text exposition format.
    pub fn render(&self, name: &str, help: &str) -> String {
        let mut out = format!("# HELP {name} {help}\n# TYPE {name} counter\n");

        let mut entries: Vec<_> = self
            .counters
            .iter()
            .map(|e| (e.key().clone(), e.value().load(Ordering::Relaxed)))
            .collect();
        entries.sort_by(|a, b| a.0.cmp(&b.0));

        let label = self.label_name;
        for (label_value, count) in &entries {
            out.push_str(&format!("{name}{{{label}=\"{label_value}\"}} {count}\n"));
        }

        out
    }
}

/// Lock-free Prometheus histogram using atomic counters per bucket.
pub struct Histogram {
    /// Upper bounds for each bucket (in seconds).
    bounds: &'static [f64],
    /// Atomic counter for each bucket plus one for +Inf.
    buckets: Vec<AtomicU64>,
    /// Running sum of all observed values (stored as integer microseconds).
    sum_us: AtomicU64,
    /// Total observation count.
    count: AtomicU64,
}

impl Histogram {
    pub fn new(bounds: &'static [f64]) -> Self {
        let buckets = (0..bounds.len() + 1).map(|_| AtomicU64::new(0)).collect();
        Self {
            bounds,
            buckets,
            sum_us: AtomicU64::new(0),
            count: AtomicU64::new(0),
        }
    }

    /// Record a duration observation into the histogram.
    pub fn observe(&self, duration: Duration) {
        let secs = duration.as_secs_f64();
        let us = duration.as_micros() as u64;

        // Increment the bucket whose upper bound is >= the observed value.
        // Each bucket counts observations that fall into its range (non-cumulative internally);
        // cumulative counts are computed at render time.
        let mut placed = false;
        for (i, &bound) in self.bounds.iter().enumerate() {
            if secs <= bound {
                self.buckets[i].fetch_add(1, Ordering::Relaxed);
                placed = true;
                break;
            }
        }
        if !placed {
            // Falls into the +Inf bucket (last element).
            self.buckets[self.bounds.len()].fetch_add(1, Ordering::Relaxed);
        }

        self.sum_us.fetch_add(us, Ordering::Relaxed);
        self.count.fetch_add(1, Ordering::Relaxed);
    }

    /// Render this histogram in Prometheus text exposition format.
    pub fn render(&self, name: &str, help: &str) -> String {
        let mut out = format!("# HELP {name} {help}\n# TYPE {name} histogram\n");

        let count = self.count.load(Ordering::Relaxed);
        let sum_us = self.sum_us.load(Ordering::Relaxed);

        // Compute cumulative bucket counts.
        let mut cumulative: u64 = 0;
        for (i, &bound) in self.bounds.iter().enumerate() {
            cumulative += self.buckets[i].load(Ordering::Relaxed);
            let le = format_le(bound);
            out.push_str(&format!("{name}_bucket{{le=\"{le}\"}} {cumulative}\n"));
        }

        // +Inf bucket always equals total count.
        out.push_str(&format!("{name}_bucket{{le=\"+Inf\"}} {count}\n"));

        let sum_secs = sum_us as f64 / 1_000_000.0;
        out.push_str(&format!("{name}_sum {sum_secs}\n"));
        out.push_str(&format!("{name}_count {count}\n"));

        out
    }
}

/// Snapshot of a histogram's atomic counters at a point in time.
pub struct HistogramSnapshot {
    pub bucket_counts: Vec<u64>,
    pub sum_us: u64,
    pub count: u64,
}

impl Histogram {
    /// Take a consistent snapshot of all atomic counters.
    pub fn snapshot(&self) -> HistogramSnapshot {
        HistogramSnapshot {
            bucket_counts: self
                .buckets
                .iter()
                .map(|b| b.load(Ordering::Relaxed))
                .collect(),
            sum_us: self.sum_us.load(Ordering::Relaxed),
            count: self.count.load(Ordering::Relaxed),
        }
    }
}

/// A Prometheus histogram with a single label dimension (e.g., `registry`).
pub struct LabeledHistogram {
    label_name: &'static str,
    bounds: &'static [f64],
    histograms: DashMap<String, Histogram>,
}

impl LabeledHistogram {
    pub fn new(label_name: &'static str, bounds: &'static [f64]) -> Self {
        Self {
            label_name,
            bounds,
            histograms: DashMap::new(),
        }
    }

    /// Record a duration observation for the given label value.
    pub fn observe(&self, label_value: &str, duration: Duration) {
        self.histograms
            .entry(label_value.to_string())
            .or_insert_with(|| Histogram::new(self.bounds))
            .observe(duration);
    }

    /// Render this labeled histogram in Prometheus text exposition format.
    pub fn render(&self, name: &str, help: &str) -> String {
        let mut out = format!("# HELP {name} {help}\n# TYPE {name} histogram\n");

        // Sort labels for deterministic output
        let mut entries: Vec<_> = self
            .histograms
            .iter()
            .map(|e| (e.key().clone(), e.value().snapshot()))
            .collect();
        entries.sort_by(|a, b| a.0.cmp(&b.0));

        for (label_value, snap) in &entries {
            let label = self.label_name;
            let mut cumulative: u64 = 0;
            for (i, &bound) in self.bounds.iter().enumerate() {
                cumulative += snap.bucket_counts[i];
                let le = format_le(bound);
                out.push_str(&format!(
                    "{name}_bucket{{{label}=\"{label_value}\",le=\"{le}\"}} {cumulative}\n"
                ));
            }
            out.push_str(&format!(
                "{name}_bucket{{{label}=\"{label_value}\",le=\"+Inf\"}} {}\n",
                snap.count
            ));
            let sum_secs = snap.sum_us as f64 / 1_000_000.0;
            out.push_str(&format!(
                "{name}_sum{{{label}=\"{label_value}\"}} {sum_secs}\n"
            ));
            out.push_str(&format!(
                "{name}_count{{{label}=\"{label_value}\"}} {}\n",
                snap.count
            ));
        }

        out
    }
}

/// Format a bucket upper bound with minimal decimal precision.
fn format_le(val: f64) -> String {
    // If the value is a whole number, render with one decimal (e.g. "1.0").
    if val.fract() == 0.0 {
        return format!("{val:.1}");
    }
    // Otherwise use default f64 Display which trims trailing zeros.
    format!("{val}")
}

/// Atomic counters for cache and upstream metrics.
pub struct Metrics {
    pub blob_cache_hits: AtomicU64,
    pub blob_cache_misses: AtomicU64,
    pub manifest_cache_hits: AtomicU64,
    pub manifest_cache_misses: AtomicU64,
    pub manifest_stale_revalidates: AtomicU64,
    pub upstream_fetches: AtomicU64,
    pub coalesce_joined: AtomicU64,
    pub token_cache_hits: AtomicU64,
    pub digest_mismatches: AtomicU64,
    pub auth_token_refreshes: AtomicU64,
    pub upstream_bytes: AtomicU64,
    pub eviction_runs_total: AtomicU64,
    pub blobs_evicted_total: AtomicU64,
    pub bytes_freed_total: AtomicU64,
    pub circuit_breaker_trips: AtomicU64,
    pub manifest_size_rejected: AtomicU64,
    pub manifest_revalidation_failures: AtomicU64,
    pub negative_cache_hits: AtomicU64,
    pub upstream_manifest_duration: LabeledHistogram,
    pub upstream_blob_duration: LabeledHistogram,
    pub manifest_cache_hits_by_registry: LabeledCounter,
    pub manifest_cache_misses_by_registry: LabeledCounter,
    pub blob_cache_hits_by_registry: LabeledCounter,
    pub blob_cache_misses_by_registry: LabeledCounter,
    pub bandwidth_saved_bytes: LabeledCounter,
}

impl Default for Metrics {
    fn default() -> Self {
        Self {
            blob_cache_hits: AtomicU64::new(0),
            blob_cache_misses: AtomicU64::new(0),
            manifest_cache_hits: AtomicU64::new(0),
            manifest_cache_misses: AtomicU64::new(0),
            manifest_stale_revalidates: AtomicU64::new(0),
            upstream_fetches: AtomicU64::new(0),
            coalesce_joined: AtomicU64::new(0),
            token_cache_hits: AtomicU64::new(0),
            digest_mismatches: AtomicU64::new(0),
            auth_token_refreshes: AtomicU64::new(0),
            upstream_bytes: AtomicU64::new(0),
            eviction_runs_total: AtomicU64::new(0),
            blobs_evicted_total: AtomicU64::new(0),
            bytes_freed_total: AtomicU64::new(0),
            circuit_breaker_trips: AtomicU64::new(0),
            manifest_size_rejected: AtomicU64::new(0),
            manifest_revalidation_failures: AtomicU64::new(0),
            negative_cache_hits: AtomicU64::new(0),
            upstream_manifest_duration: LabeledHistogram::new("registry", LATENCY_BUCKETS),
            upstream_blob_duration: LabeledHistogram::new("registry", LATENCY_BUCKETS),
            manifest_cache_hits_by_registry: LabeledCounter::new("registry"),
            manifest_cache_misses_by_registry: LabeledCounter::new("registry"),
            blob_cache_hits_by_registry: LabeledCounter::new("registry"),
            blob_cache_misses_by_registry: LabeledCounter::new("registry"),
            bandwidth_saved_bytes: LabeledCounter::new("registry"),
        }
    }
}

impl Metrics {
    pub fn inc(&self, counter: &AtomicU64) {
        counter.fetch_add(1, Ordering::Relaxed);
    }

    pub fn add(&self, counter: &AtomicU64, value: u64) {
        counter.fetch_add(value, Ordering::Relaxed);
    }

    /// Render metrics in Prometheus text exposition format.
    pub fn render(&self) -> String {
        let mut out = String::new();

        let counters = [
            prom_counter(
                "drayage_blob_cache_hits_total",
                "Blob requests served from cache",
                &self.blob_cache_hits,
            ),
            prom_counter(
                "drayage_blob_cache_misses_total",
                "Blob requests that required upstream fetch",
                &self.blob_cache_misses,
            ),
            prom_counter(
                "drayage_manifest_cache_hits_total",
                "Manifest requests served from cache",
                &self.manifest_cache_hits,
            ),
            prom_counter(
                "drayage_manifest_cache_misses_total",
                "Manifest requests that required upstream fetch",
                &self.manifest_cache_misses,
            ),
            prom_counter(
                "drayage_manifest_stale_revalidates_total",
                "Manifest requests served stale while revalidating in background",
                &self.manifest_stale_revalidates,
            ),
            prom_counter(
                "drayage_upstream_fetches_total",
                "Total upstream registry fetches",
                &self.upstream_fetches,
            ),
            prom_counter(
                "drayage_coalesce_joined_total",
                "Requests that joined an existing inflight fetch",
                &self.coalesce_joined,
            ),
            prom_counter(
                "drayage_token_cache_hits_total",
                "Bearer token requests served from cache",
                &self.token_cache_hits,
            ),
            prom_counter(
                "drayage_digest_mismatches_total",
                "Blob downloads with digest verification failure",
                &self.digest_mismatches,
            ),
            prom_counter(
                "drayage_auth_token_refreshes_total",
                "Stale bearer tokens evicted and re-fetched",
                &self.auth_token_refreshes,
            ),
            prom_counter(
                "drayage_upstream_bytes_total",
                "Total bytes fetched from upstream registries",
                &self.upstream_bytes,
            ),
            prom_counter(
                "drayage_eviction_runs_total",
                "Number of cache eviction runs",
                &self.eviction_runs_total,
            ),
            prom_counter(
                "drayage_blobs_evicted_total",
                "Number of blobs evicted from cache",
                &self.blobs_evicted_total,
            ),
            prom_counter(
                "drayage_bytes_freed_total",
                "Total bytes freed by cache eviction",
                &self.bytes_freed_total,
            ),
            prom_counter(
                "drayage_circuit_breaker_trips_total",
                "Number of times a circuit breaker tripped for a registry",
                &self.circuit_breaker_trips,
            ),
            prom_counter(
                "drayage_manifest_size_rejected_total",
                "Manifests rejected for exceeding max_manifest_bytes",
                &self.manifest_size_rejected,
            ),
            prom_counter(
                "drayage_manifest_revalidation_failures_total",
                "Background stale-while-revalidate refreshes that failed",
                &self.manifest_revalidation_failures,
            ),
            prom_counter(
                "drayage_negative_cache_hits_total",
                "Requests served from the negative cache",
                &self.negative_cache_hits,
            ),
        ];

        for c in &counters {
            out.push_str(c);
        }

        out.push_str(&self.upstream_manifest_duration.render(
            "drayage_upstream_manifest_duration_seconds",
            "Duration of upstream manifest fetches",
        ));
        out.push_str(&self.upstream_blob_duration.render(
            "drayage_upstream_blob_duration_seconds",
            "Duration of upstream blob fetches",
        ));

        out.push_str(&self.manifest_cache_hits_by_registry.render(
            "drayage_manifest_cache_hits_by_registry_total",
            "Manifest cache hits by registry",
        ));
        out.push_str(&self.manifest_cache_misses_by_registry.render(
            "drayage_manifest_cache_misses_by_registry_total",
            "Manifest cache misses by registry",
        ));
        out.push_str(&self.blob_cache_hits_by_registry.render(
            "drayage_blob_cache_hits_by_registry_total",
            "Blob cache hits by registry",
        ));
        out.push_str(&self.blob_cache_misses_by_registry.render(
            "drayage_blob_cache_misses_by_registry_total",
            "Blob cache misses by registry",
        ));
        out.push_str(&self.bandwidth_saved_bytes.render(
            "drayage_bandwidth_saved_bytes_total",
            "Bytes served from cache instead of fetched from upstream",
        ));

        out
    }
}

fn prom_counter(name: &str, help: &str, counter: &AtomicU64) -> String {
    format!(
        "# HELP {} {}\n# TYPE {} counter\n{} {}\n",
        name,
        help,
        name,
        name,
        counter.load(Ordering::Relaxed)
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn default_state_renders_all_zeros() {
        let m = Metrics::default();
        let output = m.render();
        assert!(output.contains("drayage_blob_cache_hits_total 0"));
        assert!(output.contains("drayage_blob_cache_misses_total 0"));
        assert!(output.contains("drayage_manifest_cache_hits_total 0"));
        assert!(output.contains("drayage_manifest_cache_misses_total 0"));
        assert!(output.contains("drayage_manifest_stale_revalidates_total 0"));
        assert!(output.contains("drayage_upstream_fetches_total 0"));
        assert!(output.contains("drayage_coalesce_joined_total 0"));
        assert!(output.contains("drayage_token_cache_hits_total 0"));
        assert!(output.contains("drayage_digest_mismatches_total 0"));
        assert!(output.contains("drayage_auth_token_refreshes_total 0"));
        assert!(output.contains("drayage_upstream_bytes_total 0"));
        assert!(output.contains("drayage_eviction_runs_total 0"));
        assert!(output.contains("drayage_blobs_evicted_total 0"));
        assert!(output.contains("drayage_bytes_freed_total 0"));
        assert!(output.contains("drayage_circuit_breaker_trips_total 0"));
        assert!(output.contains("drayage_manifest_size_rejected_total 0"));
        assert!(output.contains("drayage_manifest_revalidation_failures_total 0"));
    }

    #[test]
    fn inc_increments_counter() {
        let m = Metrics::default();
        m.inc(&m.blob_cache_hits);
        let output = m.render();
        assert!(output.contains("drayage_blob_cache_hits_total 1"));
    }

    #[test]
    fn add_adds_value() {
        let m = Metrics::default();
        m.add(&m.upstream_bytes, 1024);
        let output = m.render();
        assert!(output.contains("drayage_upstream_bytes_total 1024"));
    }

    #[test]
    fn prometheus_format_valid() {
        let m = Metrics::default();
        let output = m.render();

        let counters = [
            "drayage_blob_cache_hits_total",
            "drayage_blob_cache_misses_total",
            "drayage_manifest_cache_hits_total",
            "drayage_manifest_cache_misses_total",
            "drayage_manifest_stale_revalidates_total",
            "drayage_upstream_fetches_total",
            "drayage_coalesce_joined_total",
            "drayage_token_cache_hits_total",
            "drayage_digest_mismatches_total",
            "drayage_auth_token_refreshes_total",
            "drayage_upstream_bytes_total",
            "drayage_eviction_runs_total",
            "drayage_blobs_evicted_total",
            "drayage_bytes_freed_total",
            "drayage_circuit_breaker_trips_total",
            "drayage_manifest_size_rejected_total",
            "drayage_manifest_revalidation_failures_total",
        ];

        for name in counters {
            assert!(
                output.contains(&format!("# HELP {name} ")),
                "missing HELP line for {name}"
            );
            assert!(
                output.contains(&format!("# TYPE {name} counter")),
                "missing TYPE line for {name}"
            );
            assert!(
                output.contains(&format!("{name} ")),
                "missing value line for {name}"
            );
        }
    }

    #[test]
    fn multiple_increments() {
        let m = Metrics::default();
        m.inc(&m.blob_cache_hits);
        m.inc(&m.blob_cache_hits);
        m.inc(&m.blob_cache_hits);
        let output = m.render();
        assert!(output.contains("drayage_blob_cache_hits_total 3"));
    }

    #[test]
    fn concurrent_increments() {
        use std::sync::Arc;
        use std::thread;

        let m = Arc::new(Metrics::default());
        let threads: Vec<_> = (0..10)
            .map(|_| {
                let m = Arc::clone(&m);
                thread::spawn(move || {
                    for _ in 0..1000 {
                        m.inc(&m.blob_cache_hits);
                    }
                })
            })
            .collect();

        for t in threads {
            t.join().unwrap();
        }

        let output = m.render();
        assert!(
            output.contains("drayage_blob_cache_hits_total 10000"),
            "10 threads x 1000 increments = 10000"
        );
    }

    #[test]
    fn concurrent_add() {
        use std::sync::Arc;
        use std::thread;

        let m = Arc::new(Metrics::default());
        let threads: Vec<_> = (0..10)
            .map(|_| {
                let m = Arc::clone(&m);
                thread::spawn(move || {
                    for _ in 0..100 {
                        m.add(&m.upstream_bytes, 50);
                    }
                })
            })
            .collect();

        for t in threads {
            t.join().unwrap();
        }

        let output = m.render();
        // 10 threads x 100 adds x 50 bytes = 50000
        assert!(output.contains("drayage_upstream_bytes_total 50000"));
    }

    #[test]
    fn inc_and_add_are_independent() {
        let m = Metrics::default();
        m.inc(&m.blob_cache_hits);
        m.add(&m.upstream_bytes, 100);
        m.inc(&m.manifest_cache_misses);

        let output = m.render();
        assert!(output.contains("drayage_blob_cache_hits_total 1"));
        assert!(output.contains("drayage_upstream_bytes_total 100"));
        assert!(output.contains("drayage_manifest_cache_misses_total 1"));
        // Others should remain zero
        assert!(output.contains("drayage_blob_cache_misses_total 0"));
        assert!(output.contains("drayage_manifest_cache_hits_total 0"));
    }

    #[test]
    fn render_output_ends_with_newline() {
        let m = Metrics::default();
        let output = m.render();
        assert!(
            output.ends_with('\n'),
            "Prometheus output should end with newline"
        );
    }

    // --- Histogram unit tests ---

    #[test]
    fn histogram_empty_render() {
        let h = Histogram::new(LATENCY_BUCKETS);
        let output = h.render(
            "drayage_upstream_manifest_duration_seconds",
            "Duration of upstream manifest fetches",
        );

        assert!(output.contains(
            "# HELP drayage_upstream_manifest_duration_seconds Duration of upstream manifest fetches"
        ));
        assert!(output.contains("# TYPE drayage_upstream_manifest_duration_seconds histogram"));

        // All buckets should be zero
        for bound in LATENCY_BUCKETS {
            let le = format_le(*bound);
            assert!(
                output.contains(&format!(
                    "drayage_upstream_manifest_duration_seconds_bucket{{le=\"{le}\"}} 0"
                )),
                "missing or non-zero bucket for le={le}: {output}"
            );
        }

        assert!(
            output.contains("drayage_upstream_manifest_duration_seconds_bucket{le=\"+Inf\"} 0")
        );
        assert!(output.contains("drayage_upstream_manifest_duration_seconds_sum 0"));
        assert!(output.contains("drayage_upstream_manifest_duration_seconds_count 0"));
    }

    #[test]
    fn histogram_observe_and_render() {
        let h = Histogram::new(LATENCY_BUCKETS);

        // Observe values that fall into different buckets:
        // 3ms -> le=0.005 bucket
        // 8ms -> le=0.01 bucket
        // 150ms -> le=0.25 bucket
        // 20s -> +Inf bucket (above 10.0)
        h.observe(Duration::from_millis(3));
        h.observe(Duration::from_millis(8));
        h.observe(Duration::from_millis(150));
        h.observe(Duration::from_secs(20));

        let output = h.render("test_hist", "test histogram");

        // Cumulative bucket counts:
        // le=0.005 -> 1 (3ms)
        // le=0.01 -> 2 (3ms + 8ms)
        // le=0.025 -> 2
        // le=0.05 -> 2
        // le=0.1 -> 2
        // le=0.25 -> 3 (+ 150ms)
        // le=0.5 -> 3
        // le=1.0 -> 3
        // le=2.5 -> 3
        // le=5.0 -> 3
        // le=10.0 -> 3
        // le=+Inf -> 4 (+ 20s)
        assert!(
            output.contains("test_hist_bucket{le=\"0.005\"} 1"),
            "output: {output}"
        );
        assert!(
            output.contains("test_hist_bucket{le=\"0.01\"} 2"),
            "output: {output}"
        );
        assert!(
            output.contains("test_hist_bucket{le=\"0.025\"} 2"),
            "output: {output}"
        );
        assert!(
            output.contains("test_hist_bucket{le=\"0.05\"} 2"),
            "output: {output}"
        );
        assert!(
            output.contains("test_hist_bucket{le=\"0.1\"} 2"),
            "output: {output}"
        );
        assert!(
            output.contains("test_hist_bucket{le=\"0.25\"} 3"),
            "output: {output}"
        );
        assert!(
            output.contains("test_hist_bucket{le=\"0.5\"} 3"),
            "output: {output}"
        );
        assert!(
            output.contains("test_hist_bucket{le=\"1.0\"} 3"),
            "output: {output}"
        );
        assert!(
            output.contains("test_hist_bucket{le=\"2.5\"} 3"),
            "output: {output}"
        );
        assert!(
            output.contains("test_hist_bucket{le=\"5.0\"} 3"),
            "output: {output}"
        );
        assert!(
            output.contains("test_hist_bucket{le=\"10.0\"} 3"),
            "output: {output}"
        );
        assert!(
            output.contains("test_hist_bucket{le=\"+Inf\"} 4"),
            "output: {output}"
        );

        assert!(output.contains("test_hist_count 4"), "output: {output}");

        // Sum = 0.003 + 0.008 + 0.150 + 20.0 = 20.161 seconds
        // Stored as microseconds: 3000 + 8000 + 150000 + 20000000 = 20161000
        // Rendered: 20.161
        assert!(output.contains("test_hist_sum 20.161"), "output: {output}");
    }

    #[test]
    fn histogram_all_in_first_bucket() {
        let h = Histogram::new(LATENCY_BUCKETS);
        h.observe(Duration::from_micros(100)); // 0.0001s, well below 0.005
        h.observe(Duration::from_micros(200));

        let output = h.render("fast", "fast requests");

        // Both observations in the first bucket, cumulative carries through
        assert!(
            output.contains("fast_bucket{le=\"0.005\"} 2"),
            "output: {output}"
        );
        assert!(
            output.contains("fast_bucket{le=\"0.01\"} 2"),
            "output: {output}"
        );
        assert!(
            output.contains("fast_bucket{le=\"+Inf\"} 2"),
            "output: {output}"
        );
        assert!(output.contains("fast_count 2"), "output: {output}");
    }

    #[test]
    fn histogram_all_in_inf_bucket() {
        let h = Histogram::new(LATENCY_BUCKETS);
        h.observe(Duration::from_secs(30));
        h.observe(Duration::from_secs(60));

        let output = h.render("slow", "slow requests");

        // All finite buckets should be 0
        assert!(
            output.contains("slow_bucket{le=\"10.0\"} 0"),
            "output: {output}"
        );
        assert!(
            output.contains("slow_bucket{le=\"+Inf\"} 2"),
            "output: {output}"
        );
        assert!(output.contains("slow_count 2"), "output: {output}");
    }

    #[test]
    fn histogram_exact_boundary_value() {
        let h = Histogram::new(LATENCY_BUCKETS);
        // Observe exactly 0.01 seconds -- should land in the le=0.01 bucket (<=)
        h.observe(Duration::from_millis(10));

        let output = h.render("boundary", "boundary test");

        assert!(
            output.contains("boundary_bucket{le=\"0.005\"} 0"),
            "output: {output}"
        );
        assert!(
            output.contains("boundary_bucket{le=\"0.01\"} 1"),
            "output: {output}"
        );
        assert!(
            output.contains("boundary_bucket{le=\"+Inf\"} 1"),
            "output: {output}"
        );
    }

    #[test]
    fn histogram_concurrent_observe() {
        use std::sync::Arc;
        use std::thread;

        let h = Arc::new(Histogram::new(LATENCY_BUCKETS));
        let threads: Vec<_> = (0..10)
            .map(|_| {
                let h = Arc::clone(&h);
                thread::spawn(move || {
                    for _ in 0..100 {
                        h.observe(Duration::from_millis(50)); // falls in le=0.05 bucket
                    }
                })
            })
            .collect();

        for t in threads {
            t.join().unwrap();
        }

        let output = h.render("conc", "concurrent histogram");
        assert!(output.contains("conc_count 1000"), "output: {output}");
        assert!(
            output.contains("conc_bucket{le=\"0.05\"} 1000"),
            "output: {output}"
        );
        assert!(
            output.contains("conc_bucket{le=\"+Inf\"} 1000"),
            "output: {output}"
        );
    }

    #[test]
    fn histogram_renders_in_default_metrics() {
        let m = Metrics::default();
        let output = m.render();

        // Empty labeled histograms render only HELP/TYPE lines (no labels observed yet)
        assert!(
            output.contains("# HELP drayage_upstream_manifest_duration_seconds"),
            "default render should include manifest histogram HELP: {output}"
        );
        assert!(
            output.contains("# TYPE drayage_upstream_manifest_duration_seconds histogram"),
            "default render should include manifest histogram TYPE: {output}"
        );
        assert!(
            output.contains("# HELP drayage_upstream_blob_duration_seconds"),
            "default render should include blob histogram HELP: {output}"
        );
        assert!(
            output.contains("# TYPE drayage_upstream_blob_duration_seconds histogram"),
            "default render should include blob histogram TYPE: {output}"
        );

        // No bucket/count/sum lines when no labels have been observed
        assert!(
            !output.contains("drayage_upstream_manifest_duration_seconds_bucket"),
            "should not have bucket lines with no observations: {output}"
        );
        assert!(
            !output.contains("drayage_upstream_blob_duration_seconds_bucket"),
            "should not have bucket lines with no observations: {output}"
        );
    }

    // --- LabeledHistogram tests ---

    #[test]
    fn labeled_histogram_empty_renders_only_help_type() {
        let lh = LabeledHistogram::new("registry", LATENCY_BUCKETS);
        let output = lh.render("test_metric", "A test metric");

        assert!(output.contains("# HELP test_metric A test metric\n"));
        assert!(output.contains("# TYPE test_metric histogram\n"));
        // No bucket/count/sum lines
        assert!(
            !output.contains("test_metric_bucket"),
            "empty labeled histogram should have no buckets: {output}"
        );
        assert!(
            !output.contains("test_metric_count"),
            "empty labeled histogram should have no count: {output}"
        );
        assert!(
            !output.contains("test_metric_sum"),
            "empty labeled histogram should have no sum: {output}"
        );
    }

    #[test]
    fn labeled_histogram_single_label() {
        let lh = LabeledHistogram::new("registry", LATENCY_BUCKETS);
        lh.observe("docker_io", Duration::from_millis(3));

        let output = lh.render("upstream_duration", "Duration");

        // Check labeled bucket format
        assert!(
            output.contains("upstream_duration_bucket{registry=\"docker_io\",le=\"0.005\"} 1"),
            "output: {output}"
        );
        assert!(
            output.contains("upstream_duration_bucket{registry=\"docker_io\",le=\"+Inf\"} 1"),
            "output: {output}"
        );
        assert!(
            output.contains("upstream_duration_count{registry=\"docker_io\"} 1"),
            "output: {output}"
        );
        assert!(
            output.contains("upstream_duration_sum{registry=\"docker_io\"}"),
            "output: {output}"
        );
    }

    #[test]
    fn labeled_histogram_multiple_labels_sorted() {
        let lh = LabeledHistogram::new("registry", LATENCY_BUCKETS);
        // Observe in reverse alphabetical order
        lh.observe("gcr_io", Duration::from_millis(100));
        lh.observe("docker_io", Duration::from_millis(5));

        let output = lh.render("hist", "test");

        // docker_io should appear before gcr_io (sorted)
        let docker_pos = output.find("registry=\"docker_io\"").unwrap();
        let gcr_pos = output.find("registry=\"gcr_io\"").unwrap();
        assert!(
            docker_pos < gcr_pos,
            "labels should be sorted alphabetically: {output}"
        );

        // docker_io: 5ms -> le=0.005 bucket
        assert!(
            output.contains("hist_bucket{registry=\"docker_io\",le=\"0.005\"} 1"),
            "output: {output}"
        );
        assert!(
            output.contains("hist_count{registry=\"docker_io\"} 1"),
            "output: {output}"
        );

        // gcr_io: 100ms -> le=0.1 bucket
        assert!(
            output.contains("hist_bucket{registry=\"gcr_io\",le=\"0.1\"} 1"),
            "output: {output}"
        );
        assert!(
            output.contains("hist_count{registry=\"gcr_io\"} 1"),
            "output: {output}"
        );
    }

    #[test]
    fn labeled_histogram_concurrent_same_label() {
        use std::sync::Arc;
        use std::thread;

        let lh = Arc::new(LabeledHistogram::new("registry", LATENCY_BUCKETS));
        let threads: Vec<_> = (0..10)
            .map(|_| {
                let lh = Arc::clone(&lh);
                thread::spawn(move || {
                    for _ in 0..100 {
                        lh.observe("docker_io", Duration::from_millis(50));
                    }
                })
            })
            .collect();

        for t in threads {
            t.join().unwrap();
        }

        let output = lh.render("conc", "concurrent test");
        assert!(
            output.contains("conc_count{registry=\"docker_io\"} 1000"),
            "output: {output}"
        );
        assert!(
            output.contains("conc_bucket{registry=\"docker_io\",le=\"0.05\"} 1000"),
            "output: {output}"
        );
    }

    #[test]
    fn labeled_histogram_multiple_observations_same_label() {
        let lh = LabeledHistogram::new("registry", LATENCY_BUCKETS);
        // 3ms -> le=0.005, 150ms -> le=0.25, 20s -> +Inf
        lh.observe("docker_io", Duration::from_millis(3));
        lh.observe("docker_io", Duration::from_millis(150));
        lh.observe("docker_io", Duration::from_secs(20));

        let output = lh.render("hist", "test");

        assert!(
            output.contains("hist_bucket{registry=\"docker_io\",le=\"0.005\"} 1"),
            "output: {output}"
        );
        assert!(
            output.contains("hist_bucket{registry=\"docker_io\",le=\"0.25\"} 2"),
            "output: {output}"
        );
        assert!(
            output.contains("hist_bucket{registry=\"docker_io\",le=\"10.0\"} 2"),
            "output: {output}"
        );
        assert!(
            output.contains("hist_bucket{registry=\"docker_io\",le=\"+Inf\"} 3"),
            "output: {output}"
        );
        assert!(
            output.contains("hist_count{registry=\"docker_io\"} 3"),
            "output: {output}"
        );
    }

    // --- LabeledCounter tests ---

    #[test]
    fn labeled_counter_empty_renders_only_help_type() {
        let lc = LabeledCounter::new("registry");
        let output = lc.render("test_counter", "A test counter");
        assert!(output.contains("# HELP test_counter A test counter\n"));
        assert!(output.contains("# TYPE test_counter counter\n"));
        assert!(
            !output.contains("test_counter{"),
            "empty labeled counter should have no value lines: {output}"
        );
    }

    #[test]
    fn labeled_counter_single_label() {
        let lc = LabeledCounter::new("registry");
        lc.inc("docker_io");
        let output = lc.render("hits", "Cache hits");
        assert!(
            output.contains("hits{registry=\"docker_io\"} 1"),
            "output: {output}"
        );
    }

    #[test]
    fn labeled_counter_multiple_labels_sorted() {
        let lc = LabeledCounter::new("registry");
        lc.inc("gcr_io");
        lc.inc("docker_io");
        lc.inc("ghcr_io");
        let output = lc.render("hits", "Cache hits");
        let docker_pos = output.find("registry=\"docker_io\"").unwrap();
        let gcr_pos = output.find("registry=\"gcr_io\"").unwrap();
        let ghcr_pos = output.find("registry=\"ghcr_io\"").unwrap();
        assert!(
            docker_pos < gcr_pos && gcr_pos < ghcr_pos,
            "labels should be sorted: {output}"
        );
    }

    #[test]
    fn labeled_counter_add() {
        let lc = LabeledCounter::new("registry");
        lc.add("docker_io", 1024);
        lc.add("docker_io", 2048);
        let output = lc.render("bytes", "Bytes saved");
        assert!(
            output.contains("bytes{registry=\"docker_io\"} 3072"),
            "output: {output}"
        );
    }

    #[test]
    fn labeled_counter_concurrent_increments() {
        use std::sync::Arc;
        use std::thread;

        let lc = Arc::new(LabeledCounter::new("registry"));
        let threads: Vec<_> = (0..10)
            .map(|_| {
                let lc = Arc::clone(&lc);
                thread::spawn(move || {
                    for _ in 0..100 {
                        lc.inc("docker_io");
                    }
                })
            })
            .collect();

        for t in threads {
            t.join().unwrap();
        }

        let output = lc.render("conc", "concurrent");
        assert!(
            output.contains("conc{registry=\"docker_io\"} 1000"),
            "output: {output}"
        );
    }

    #[test]
    fn format_le_whole_numbers() {
        assert_eq!(format_le(1.0), "1.0");
        assert_eq!(format_le(5.0), "5.0");
        assert_eq!(format_le(10.0), "10.0");
    }

    #[test]
    fn format_le_fractional_numbers() {
        assert_eq!(format_le(0.005), "0.005");
        assert_eq!(format_le(0.01), "0.01");
        assert_eq!(format_le(0.025), "0.025");
        assert_eq!(format_le(0.25), "0.25");
        assert_eq!(format_le(2.5), "2.5");
    }
}
