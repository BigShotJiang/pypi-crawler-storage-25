use std::path::Path;

use crate::config::Config;

/// Default config template embedded in the binary.
pub const DEFAULT_CONFIG: &str = r#"listen = "0.0.0.0:5001"
cache_dir = "./cache"
manifest_ttl_seconds = 900  # 15 minutes

# max_cache_bytes = 10737418240       # 10 GB. Unset or 0 means unlimited.
# eviction_interval_seconds = 300     # How often to check cache size (default: 5 min)
# connect_timeout_secs = 10           # Global connect timeout (seconds)
# read_timeout_secs = 30              # Global read/request timeout (seconds)
# max_manifest_bytes = 10485760       # Max manifest size (default: 10 MB, 0 = unlimited)
# negative_ttl_seconds = 60           # Negative cache TTL (default: 60s, 0 disables)
# offline_mode = false                # Serve from cache only, skip upstream fetches

# TLS transparent proxy (optional, all three fields required)
# tls_listen = "0.0.0.0:443"
# ca_cert_path = "/certs/ca.crt"
# ca_key_path = "/certs/ca.key"

# Upstream registries
# Key naming convention: replace '.' and '-' with '_' in the hostname.
# Example: registry.k8s.io -> registry_k8s_io

[upstreams.docker_io]
registry = "https://registry-1.docker.io"
# username = ""
# password = ""
# connect_timeout_secs = 15           # Per-upstream override
# read_timeout_secs = 120             # Per-upstream override

[upstreams.gcr_io]
registry = "https://gcr.io"

[upstreams.ghcr_io]
registry = "https://ghcr.io"

[upstreams.quay_io]
registry = "https://quay.io"

[upstreams.registry_k8s_io]
registry = "https://registry.k8s.io"
"#;

/// Write the default config template to `path`.
///
/// Returns an error if the file already exists and `force` is false.
pub fn run(path: &str, force: bool) -> anyhow::Result<()> {
    let dest = Path::new(path);

    if dest.exists() && !force {
        anyhow::bail!(
            "{} already exists (use --force to overwrite)",
            dest.display()
        );
    }

    if let Some(parent) = dest.parent()
        && !parent.as_os_str().is_empty()
        && !parent.exists()
    {
        std::fs::create_dir_all(parent)?;
    }

    std::fs::write(dest, DEFAULT_CONFIG)?;
    println!("wrote {}", dest.display());
    Ok(())
}

/// Extract the hostname from a registry URL for use as a containerd mirror directory name.
///
/// Special case: `registry-1.docker.io` maps to `docker.io` because containerd
/// uses the canonical name, not the API endpoint.
pub fn containerd_host_name(registry_url: &str) -> anyhow::Result<String> {
    let url = reqwest::Url::parse(registry_url)
        .map_err(|e| anyhow::anyhow!("invalid registry URL '{}': {}", registry_url, e))?;
    let host = url
        .host_str()
        .ok_or_else(|| anyhow::anyhow!("no host in registry URL '{}'", registry_url))?;

    // containerd uses "docker.io" as the canonical name
    if host == "registry-1.docker.io" {
        return Ok("docker.io".to_string());
    }

    Ok(host.to_string())
}

/// Generate containerd mirror `hosts.toml` files for all configured upstreams.
///
/// Reads drayage config from `config_path` and writes one directory + hosts.toml
/// per upstream into `containerd_dir`.
pub fn run_containerd(
    config_path: &str,
    containerd_dir: &str,
    drayage_url: &str,
    force: bool,
) -> anyhow::Result<()> {
    let config = Config::load(config_path)?;
    let base = Path::new(containerd_dir);

    if config.upstreams.is_empty() {
        anyhow::bail!("no upstreams configured in {}", config_path);
    }

    for upstream in config.upstreams.values() {
        let host = containerd_host_name(&upstream.registry)?;
        let dir = base.join(&host);
        let hosts_toml = dir.join("hosts.toml");

        if hosts_toml.exists() && !force {
            println!(
                "skip {} (exists, use --force to overwrite)",
                hosts_toml.display()
            );
            continue;
        }

        std::fs::create_dir_all(&dir)?;

        let content = format!(
            "server = \"{server}\"\n\n[host.\"{drayage}\"]\n  capabilities = [\"pull\", \"resolve\"]\n",
            server = upstream.registry,
            drayage = drayage_url,
        );

        std::fs::write(&hosts_toml, &content)?;
        println!("wrote {}", hosts_toml.display());
    }

    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::TempDir;

    #[test]
    fn init_creates_config_file() {
        let dir = TempDir::new().unwrap();
        let path = dir.path().join("config.toml");
        run(path.to_str().unwrap(), false).unwrap();
        assert!(path.exists());
        let content = std::fs::read_to_string(&path).unwrap();
        assert!(content.contains("listen"));
        assert!(content.contains("cache_dir"));
    }

    #[test]
    fn init_refuses_overwrite_without_force() {
        let dir = TempDir::new().unwrap();
        let path = dir.path().join("config.toml");
        std::fs::write(&path, "existing").unwrap();

        let err = run(path.to_str().unwrap(), false).unwrap_err();
        assert!(
            err.to_string().contains("already exists"),
            "expected 'already exists' error, got: {err}"
        );
        // Original content should be preserved
        assert_eq!(std::fs::read_to_string(&path).unwrap(), "existing");
    }

    #[test]
    fn init_overwrites_with_force() {
        let dir = TempDir::new().unwrap();
        let path = dir.path().join("config.toml");
        std::fs::write(&path, "old content").unwrap();

        run(path.to_str().unwrap(), true).unwrap();
        let content = std::fs::read_to_string(&path).unwrap();
        assert!(content.contains("listen"));
        assert_ne!(content, "old content");
    }

    #[test]
    fn init_generated_config_is_valid_toml() {
        let config: crate::config::Config = toml::from_str(DEFAULT_CONFIG).unwrap();
        assert_eq!(config.listen, "0.0.0.0:5001");
        assert_eq!(config.cache_dir, "./cache");
        assert_eq!(config.manifest_ttl_seconds, 900);
        assert_eq!(config.upstreams.len(), 5);
        assert!(config.upstreams.contains_key("docker_io"));
        assert!(config.upstreams.contains_key("gcr_io"));
        assert!(config.upstreams.contains_key("ghcr_io"));
        assert!(config.upstreams.contains_key("quay_io"));
        assert!(config.upstreams.contains_key("registry_k8s_io"));
    }

    #[test]
    fn init_creates_parent_directories() {
        let dir = TempDir::new().unwrap();
        let path = dir.path().join("nested").join("dir").join("config.toml");
        run(path.to_str().unwrap(), false).unwrap();
        assert!(path.exists());
    }

    // --- containerd tests ---

    #[test]
    fn containerd_host_name_docker_io() {
        assert_eq!(
            containerd_host_name("https://registry-1.docker.io").unwrap(),
            "docker.io"
        );
    }

    #[test]
    fn containerd_host_name_gcr_io() {
        assert_eq!(containerd_host_name("https://gcr.io").unwrap(), "gcr.io");
    }

    #[test]
    fn containerd_host_name_ghcr_io() {
        assert_eq!(containerd_host_name("https://ghcr.io").unwrap(), "ghcr.io");
    }

    #[test]
    fn containerd_host_name_quay_io() {
        assert_eq!(containerd_host_name("https://quay.io").unwrap(), "quay.io");
    }

    #[test]
    fn containerd_host_name_registry_k8s_io() {
        assert_eq!(
            containerd_host_name("https://registry.k8s.io").unwrap(),
            "registry.k8s.io"
        );
    }

    #[test]
    fn containerd_host_name_invalid_url() {
        assert!(containerd_host_name("not-a-url").is_err());
    }

    #[test]
    fn run_containerd_creates_hosts_toml_files() {
        let config_dir = TempDir::new().unwrap();
        let config_path = config_dir.path().join("config.toml");
        std::fs::write(&config_path, DEFAULT_CONFIG).unwrap();

        let output_dir = TempDir::new().unwrap();
        run_containerd(
            config_path.to_str().unwrap(),
            output_dir.path().to_str().unwrap(),
            "http://10.10.30.234:5001",
            false,
        )
        .unwrap();

        // Verify all 5 registry directories created
        for host in &[
            "docker.io",
            "gcr.io",
            "ghcr.io",
            "quay.io",
            "registry.k8s.io",
        ] {
            let hosts_toml = output_dir.path().join(host).join("hosts.toml");
            assert!(
                hosts_toml.exists(),
                "expected {} to exist",
                hosts_toml.display()
            );

            let content = std::fs::read_to_string(&hosts_toml).unwrap();
            assert!(
                content.contains("[host.\"http://10.10.30.234:5001\"]"),
                "expected drayage URL in {}: {}",
                host,
                content
            );
            assert!(
                content.contains("capabilities = [\"pull\", \"resolve\"]"),
                "expected capabilities in {}: {}",
                host,
                content
            );
        }
    }

    #[test]
    fn run_containerd_generated_files_are_valid_toml() {
        let config_dir = TempDir::new().unwrap();
        let config_path = config_dir.path().join("config.toml");
        std::fs::write(&config_path, DEFAULT_CONFIG).unwrap();

        let output_dir = TempDir::new().unwrap();
        run_containerd(
            config_path.to_str().unwrap(),
            output_dir.path().to_str().unwrap(),
            "http://10.10.30.234:5001",
            false,
        )
        .unwrap();

        for host in &[
            "docker.io",
            "gcr.io",
            "ghcr.io",
            "quay.io",
            "registry.k8s.io",
        ] {
            let content =
                std::fs::read_to_string(output_dir.path().join(host).join("hosts.toml")).unwrap();
            let parsed: toml::Value = toml::from_str(&content).unwrap_or_else(|e| {
                panic!("invalid TOML for {}: {}\ncontent:\n{}", host, e, content)
            });

            // Check structure: server key and host table
            assert!(
                parsed.get("server").is_some(),
                "missing 'server' key in {}",
                host
            );
            assert!(
                parsed.get("host").is_some(),
                "missing 'host' table in {}",
                host
            );
        }
    }

    #[test]
    fn run_containerd_skips_existing_without_force() {
        let config_dir = TempDir::new().unwrap();
        let config_path = config_dir.path().join("config.toml");
        std::fs::write(&config_path, DEFAULT_CONFIG).unwrap();

        let output_dir = TempDir::new().unwrap();

        // Create one existing file
        let existing = output_dir.path().join("docker.io");
        std::fs::create_dir_all(&existing).unwrap();
        std::fs::write(existing.join("hosts.toml"), "original").unwrap();

        run_containerd(
            config_path.to_str().unwrap(),
            output_dir.path().to_str().unwrap(),
            "http://10.10.30.234:5001",
            false,
        )
        .unwrap();

        // docker.io should be preserved
        let content = std::fs::read_to_string(existing.join("hosts.toml")).unwrap();
        assert_eq!(content, "original");

        // Other registries should be created
        assert!(output_dir.path().join("gcr.io").join("hosts.toml").exists());
    }

    #[test]
    fn run_containerd_overwrites_with_force() {
        let config_dir = TempDir::new().unwrap();
        let config_path = config_dir.path().join("config.toml");
        std::fs::write(&config_path, DEFAULT_CONFIG).unwrap();

        let output_dir = TempDir::new().unwrap();

        // Create one existing file
        let existing = output_dir.path().join("docker.io");
        std::fs::create_dir_all(&existing).unwrap();
        std::fs::write(existing.join("hosts.toml"), "original").unwrap();

        run_containerd(
            config_path.to_str().unwrap(),
            output_dir.path().to_str().unwrap(),
            "http://10.10.30.234:5001",
            true,
        )
        .unwrap();

        // docker.io should be overwritten
        let content = std::fs::read_to_string(existing.join("hosts.toml")).unwrap();
        assert_ne!(content, "original");
        assert!(content.contains("server"));
    }

    #[test]
    fn run_containerd_docker_io_has_correct_server() {
        let config_dir = TempDir::new().unwrap();
        let config_path = config_dir.path().join("config.toml");
        std::fs::write(&config_path, DEFAULT_CONFIG).unwrap();

        let output_dir = TempDir::new().unwrap();
        run_containerd(
            config_path.to_str().unwrap(),
            output_dir.path().to_str().unwrap(),
            "http://10.10.30.234:5001",
            false,
        )
        .unwrap();

        let content =
            std::fs::read_to_string(output_dir.path().join("docker.io").join("hosts.toml"))
                .unwrap();
        assert!(
            content.contains("server = \"https://registry-1.docker.io\""),
            "docker.io hosts.toml should point to registry-1.docker.io: {}",
            content
        );
    }
}
