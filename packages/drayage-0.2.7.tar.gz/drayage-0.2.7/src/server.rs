use std::sync::Arc;

use axum::Router;
use axum::extract::{Path, State};
use axum::http::{HeaderMap, Method, StatusCode};
use axum::response::Response;
use axum::routing::get;

use crate::AppState;
use crate::handlers;
use crate::tls::SniCertResolver;

#[derive(Clone, Debug)]
pub struct SniHostname(pub String);

pub fn build_router(state: AppState) -> Router {
    Router::new()
        .route("/v2/", get(handlers::version::handle_version_check))
        .route("/health", get(health_check))
        .route("/healthz", get(health_check))
        .route("/readyz", get(readiness_check))
        .route("/metrics", get(handle_metrics))
        .route("/stats", get(handle_stats))
        .route(
            "/v2/{*path}",
            get(handle_v2_request).head(handle_v2_request),
        )
        .with_state(state)
}

async fn handle_v2_request(
    State(state): State<AppState>,
    Path(path): Path<String>,
    method: Method,
    headers: HeaderMap,
    sni: Option<axum::Extension<SniHostname>>,
) -> Response {
    let host_from_header = headers
        .get("host")
        .and_then(|v| v.to_str().ok())
        .map(|s| s.to_string());
    let host_override = sni.as_ref().map(|s| s.0.0.clone()).or(host_from_header);
    let head_only = method == Method::HEAD;
    let client_auth = headers
        .get("authorization")
        .and_then(|v| v.to_str().ok())
        .map(|s| s.to_string());

    if let Some((name, reference)) = parse_manifest_path(&path) {
        handlers::manifests::handle_manifest(
            state,
            name,
            reference,
            host_override,
            head_only,
            client_auth,
        )
        .await
    } else if let Some((name, digest)) = parse_blob_path(&path) {
        handlers::blobs::handle_blob(state, name, digest, host_override, head_only, client_auth)
            .await
    } else {
        error_response(StatusCode::NOT_FOUND, "not found")
    }
}

pub async fn serve_tls(
    state: AppState,
    addr: &str,
    resolver: Arc<SniCertResolver>,
    cancel: tokio_util::sync::CancellationToken,
) -> anyhow::Result<()> {
    use axum::body::Body;
    use hyper::body::Incoming;
    use hyper_util::rt::{TokioExecutor, TokioIo};
    use hyper_util::server::conn::auto;
    use hyper_util::service::TowerToHyperService;
    use tower::ServiceExt;

    let server_config = rustls::ServerConfig::builder()
        .with_no_client_auth()
        .with_cert_resolver(resolver);
    let tls_acceptor = tokio_rustls::TlsAcceptor::from(Arc::new(server_config));
    let listener = tokio::net::TcpListener::bind(addr).await?;
    tracing::info!("TLS listener on {}", addr);

    let app_router = build_router(state);

    loop {
        let (tcp_stream, peer) = tokio::select! {
            result = listener.accept() => match result {
                Ok(x) => x,
                Err(e) => {
                    tracing::warn!("TLS accept: {}", e);
                    continue;
                }
            },
            _ = cancel.cancelled() => {
                tracing::info!("TLS listener shutting down");
                break;
            }
        };

        let acceptor = tls_acceptor.clone();
        let app = app_router.clone();

        tokio::spawn(async move {
            let tls_stream = match acceptor.accept(tcp_stream).await {
                Ok(s) => s,
                Err(e) => {
                    tracing::debug!("TLS handshake from {}: {}", peer, e);
                    return;
                }
            };

            let sni = tls_stream
                .get_ref()
                .1
                .server_name()
                .map(|s| SniHostname(s.to_string()));

            let svc = app.map_request(move |req: http::Request<Incoming>| {
                let mut req = req.map(Body::new);
                if let Some(ref sni_host) = sni {
                    req.extensions_mut().insert(sni_host.clone());
                }
                req
            });

            if let Err(e) = auto::Builder::new(TokioExecutor::new())
                .serve_connection(TokioIo::new(tls_stream), TowerToHyperService::new(svc))
                .await
            {
                tracing::debug!("TLS connection from {}: {}", peer, e);
            }
        });
    }

    Ok(())
}

async fn health_check() -> Response {
    Response::builder()
        .status(StatusCode::OK)
        .header("Content-Type", "application/json")
        .body(axum::body::Body::from(r#"{"status":"ok"}"#))
        .expect("response build")
}

async fn readiness_check(State(state): State<AppState>) -> Response {
    match std::fs::metadata(state.cache.root()) {
        Ok(_) => Response::builder()
            .status(StatusCode::OK)
            .header("Content-Type", "application/json")
            .body(axum::body::Body::from(r#"{"status":"ready"}"#))
            .expect("response build"),
        Err(e) => Response::builder()
            .status(StatusCode::SERVICE_UNAVAILABLE)
            .header("Content-Type", "application/json")
            .body(axum::body::Body::from(format!(
                r#"{{"status":"not ready","reason":"{}"}}"#,
                e
            )))
            .expect("response build"),
    }
}

async fn handle_metrics(State(state): State<AppState>) -> Response {
    Response::builder()
        .status(StatusCode::OK)
        .header("Content-Type", "text/plain; version=0.0.4; charset=utf-8")
        .body(axum::body::Body::from(state.metrics.render()))
        .expect("response build")
}

async fn handle_stats(State(state): State<AppState>) -> Response {
    match state.cache.stats().await {
        Ok(stats) => {
            let body = serde_json::to_string(&stats).expect("CacheStats serialization");
            Response::builder()
                .status(StatusCode::OK)
                .header("Content-Type", "application/json")
                .body(axum::body::Body::from(body))
                .expect("response build")
        }
        Err(e) => Response::builder()
            .status(StatusCode::INTERNAL_SERVER_ERROR)
            .header("Content-Type", "application/json")
            .body(axum::body::Body::from(format!(r#"{{"error":"{}"}}"#, e)))
            .expect("response build"),
    }
}

fn parse_manifest_path(path: &str) -> Option<(String, String)> {
    let marker = "/manifests/";
    let pos = path.rfind(marker)?;
    let name = &path[..pos];
    let reference = &path[pos + marker.len()..];
    if name.is_empty() || reference.is_empty() {
        return None;
    }
    Some((name.to_string(), reference.to_string()))
}

fn parse_blob_path(path: &str) -> Option<(String, String)> {
    let marker = "/blobs/";
    let pos = path.rfind(marker)?;
    let name = &path[..pos];
    let digest = &path[pos + marker.len()..];
    if name.is_empty() || digest.is_empty() {
        return None;
    }
    Some((name.to_string(), digest.to_string()))
}

fn error_response(status: StatusCode, msg: &str) -> Response {
    Response::builder()
        .status(status)
        .header("Content-Type", "application/json")
        .body(axum::body::Body::from(format!(
            r#"{{"errors":[{{"code":"{}","message":"{}"}}]}}"#,
            msg.to_uppercase().replace(' ', "_"),
            msg
        )))
        .expect("response build")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_manifest_path_simple() {
        assert_eq!(
            parse_manifest_path("alpine/manifests/latest"),
            Some(("alpine".into(), "latest".into()))
        );
    }

    #[test]
    fn parse_manifest_path_nested_repo() {
        assert_eq!(
            parse_manifest_path("library/ubuntu/manifests/22.04"),
            Some(("library/ubuntu".into(), "22.04".into()))
        );
    }

    #[test]
    fn parse_manifest_path_digest_ref() {
        assert_eq!(
            parse_manifest_path("alpine/manifests/sha256:abc"),
            Some(("alpine".into(), "sha256:abc".into()))
        );
    }

    #[test]
    fn parse_manifest_path_empty_reference() {
        assert_eq!(parse_manifest_path("alpine/manifests/"), None);
    }

    #[test]
    fn parse_manifest_path_empty_name() {
        assert_eq!(parse_manifest_path("/manifests/latest"), None);
    }

    #[test]
    fn parse_manifest_path_no_marker() {
        assert_eq!(parse_manifest_path("alpine/blobs/sha256:abc"), None);
    }

    #[test]
    fn parse_blob_path_simple() {
        assert_eq!(
            parse_blob_path("alpine/blobs/sha256:abc123"),
            Some(("alpine".into(), "sha256:abc123".into()))
        );
    }

    #[test]
    fn parse_blob_path_nested_repo() {
        assert_eq!(
            parse_blob_path("library/ubuntu/blobs/sha256:abc"),
            Some(("library/ubuntu".into(), "sha256:abc".into()))
        );
    }

    #[test]
    fn parse_blob_path_empty_digest() {
        assert_eq!(parse_blob_path("alpine/blobs/"), None);
    }

    #[test]
    fn parse_blob_path_empty_name() {
        assert_eq!(parse_blob_path("/blobs/sha256:abc"), None);
    }

    #[test]
    fn parse_blob_path_no_marker() {
        assert_eq!(parse_blob_path("alpine/manifests/latest"), None);
    }

    #[test]
    fn parse_manifest_path_deeply_nested() {
        assert_eq!(
            parse_manifest_path("a/b/c/d/manifests/v1"),
            Some(("a/b/c/d".into(), "v1".into()))
        );
    }

    #[test]
    fn parse_manifest_path_duplicate_marker_uses_last() {
        // rfind picks the last "/manifests/" occurrence
        assert_eq!(
            parse_manifest_path("repo/manifests/manifests/latest"),
            Some(("repo/manifests".into(), "latest".into()))
        );
    }

    #[test]
    fn parse_blob_path_deeply_nested() {
        assert_eq!(
            parse_blob_path("a/b/c/d/blobs/sha256:abc"),
            Some(("a/b/c/d".into(), "sha256:abc".into()))
        );
    }

    #[test]
    fn parse_blob_path_duplicate_marker_uses_last() {
        assert_eq!(
            parse_blob_path("repo/blobs/blobs/sha256:abc"),
            Some(("repo/blobs".into(), "sha256:abc".into()))
        );
    }

    #[test]
    fn parse_manifest_path_only_marker() {
        // Just "/manifests/" with nothing before or after
        assert_eq!(parse_manifest_path("/manifests/"), None);
    }

    #[test]
    fn parse_blob_path_only_marker() {
        assert_eq!(parse_blob_path("/blobs/"), None);
    }
}
