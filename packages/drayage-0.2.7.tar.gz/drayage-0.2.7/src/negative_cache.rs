use std::time::Instant;

use dashmap::DashMap;

/// Entry in the negative cache recording when a negative response was received.
struct NegativeEntry {
    status: u16,
    inserted_at: Instant,
}

/// In-memory cache for negative responses (404/403) to avoid repeated upstream
/// fetches for nonexistent images. Only used for tag lookups (not digests).
pub struct NegativeCache {
    entries: DashMap<String, NegativeEntry>,
    ttl_seconds: u64,
}

impl NegativeCache {
    pub fn new(ttl_seconds: u64) -> Self {
        Self {
            entries: DashMap::new(),
            ttl_seconds,
        }
    }

    /// Returns the cached status code if the key exists and hasn't expired.
    pub fn get(&self, key: &str) -> Option<u16> {
        if self.ttl_seconds == 0 {
            return None;
        }
        let entry = self.entries.get(key)?;
        if entry.inserted_at.elapsed().as_secs() < self.ttl_seconds {
            Some(entry.status)
        } else {
            drop(entry);
            self.entries.remove(key);
            None
        }
    }

    /// Insert a negative response for the given key.
    pub fn insert(&self, key: String, status: u16) {
        if self.ttl_seconds == 0 {
            return;
        }
        self.entries.insert(
            key,
            NegativeEntry {
                status,
                inserted_at: Instant::now(),
            },
        );
    }

    /// Remove all expired entries. Called periodically from a background task.
    pub fn cleanup(&self) {
        self.entries
            .retain(|_, entry| entry.inserted_at.elapsed().as_secs() < self.ttl_seconds);
    }

    /// Number of entries (for testing).
    #[cfg(test)]
    fn len(&self) -> usize {
        self.entries.len()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn insert_and_get() {
        let nc = NegativeCache::new(60);
        nc.insert("key1".to_string(), 404);
        assert_eq!(nc.get("key1"), Some(404));
    }

    #[test]
    fn get_missing_key_returns_none() {
        let nc = NegativeCache::new(60);
        assert_eq!(nc.get("missing"), None);
    }

    #[test]
    fn ttl_zero_disables_cache() {
        let nc = NegativeCache::new(0);
        nc.insert("key1".to_string(), 404);
        assert_eq!(nc.get("key1"), None);
        assert_eq!(nc.len(), 0);
    }

    #[test]
    fn expired_entry_returns_none() {
        let nc = NegativeCache::new(1);
        nc.entries.insert(
            "old".to_string(),
            NegativeEntry {
                status: 404,
                inserted_at: Instant::now() - std::time::Duration::from_secs(2),
            },
        );
        assert_eq!(nc.get("old"), None);
        // Entry should have been removed on access
        assert_eq!(nc.len(), 0);
    }

    #[test]
    fn cleanup_removes_expired() {
        let nc = NegativeCache::new(1);
        nc.entries.insert(
            "expired".to_string(),
            NegativeEntry {
                status: 404,
                inserted_at: Instant::now() - std::time::Duration::from_secs(2),
            },
        );
        nc.insert("fresh".to_string(), 403);
        assert_eq!(nc.len(), 2);
        nc.cleanup();
        assert_eq!(nc.len(), 1);
        assert_eq!(nc.get("fresh"), Some(403));
        assert_eq!(nc.get("expired"), None);
    }

    #[test]
    fn different_status_codes() {
        let nc = NegativeCache::new(60);
        nc.insert("not_found".to_string(), 404);
        nc.insert("forbidden".to_string(), 403);
        assert_eq!(nc.get("not_found"), Some(404));
        assert_eq!(nc.get("forbidden"), Some(403));
    }

    #[test]
    fn overwrite_entry() {
        let nc = NegativeCache::new(60);
        nc.insert("key".to_string(), 404);
        nc.insert("key".to_string(), 403);
        assert_eq!(nc.get("key"), Some(403));
    }

    #[test]
    fn concurrent_access() {
        use std::sync::Arc;
        use std::thread;

        let nc = Arc::new(NegativeCache::new(60));
        let threads: Vec<_> = (0..10)
            .map(|i| {
                let nc = Arc::clone(&nc);
                thread::spawn(move || {
                    let key = format!("key_{i}");
                    nc.insert(key.clone(), 404);
                    assert_eq!(nc.get(&key), Some(404));
                })
            })
            .collect();

        for t in threads {
            t.join().unwrap();
        }

        assert_eq!(nc.len(), 10);
    }
}
