use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::SystemTime;

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use sha2::{Digest as _, Sha256};
use tokio::io::{AsyncRead, AsyncReadExt, AsyncWriteExt};
use tokio_util::io::ReaderStream;
use tracing::{debug, info, warn};

use crate::metrics::Metrics;

/// Minimum free disk space required before writing a blob (10 MB).
const MIN_FREE_DISK_BYTES: u64 = 10 * 1024 * 1024;
const NO_DISK_AVAILABLE_OVERRIDE: u64 = u64::MAX;

#[derive(Debug, Serialize)]
pub struct CacheStats {
    pub blob_count: u64,
    pub blob_total_bytes: u64,
    pub manifest_digest_count: u64,
    pub manifest_tag_count: u64,
    pub disk_available_bytes: u64,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct CachedManifest {
    pub fetched_at: DateTime<Utc>,
    pub digest: String,
    pub content_type: String,
    pub content: String, // base64-encoded manifest bytes
}

/// Whether a cached manifest is still within TTL or has expired.
pub enum ManifestFreshness {
    Fresh(CachedManifest),
    Stale(CachedManifest),
}

#[derive(Clone, Debug, Eq, PartialEq, Hash)]
pub enum CacheScope {
    Public,
    Authenticated(String),
}

impl CacheScope {
    pub fn for_client_auth(client_auth: Option<&str>) -> Self {
        match client_auth {
            Some(auth) => {
                let hash = Sha256::digest(auth.as_bytes());
                Self::Authenticated(hex::encode(hash))
            }
            None => Self::Public,
        }
    }

    pub fn cache_key_prefix(&self) -> String {
        match self {
            Self::Public => "public".to_string(),
            Self::Authenticated(scope_id) => format!("auth:{scope_id}"),
        }
    }
}

pub struct Cache {
    root: PathBuf,
    manifest_ttl_seconds: u64,
    metrics: Option<Arc<Metrics>>,
    disk_available_bytes_override: AtomicU64,
}

impl Cache {
    pub fn root(&self) -> &Path {
        &self.root
    }

    pub fn new(
        root: impl AsRef<Path>,
        manifest_ttl_seconds: u64,
        metrics: Option<Arc<Metrics>>,
    ) -> anyhow::Result<Self> {
        let root = root.as_ref().to_path_buf();
        std::fs::create_dir_all(root.join("blobs/sha256"))?;
        std::fs::create_dir_all(root.join("manifests/by-digest/sha256"))?;
        std::fs::create_dir_all(root.join("manifests/by-tag"))?;
        Ok(Self {
            root,
            manifest_ttl_seconds,
            metrics,
            disk_available_bytes_override: AtomicU64::new(NO_DISK_AVAILABLE_OVERRIDE),
        })
    }

    /// Internal test hook for forcing the free-space check result.
    ///
    /// This is intended for integration tests that need deterministic behavior
    /// under simulated disk pressure.
    pub fn set_disk_available_bytes_override_for_tests(&self, bytes: Option<u64>) {
        self.disk_available_bytes_override.store(
            bytes.unwrap_or(NO_DISK_AVAILABLE_OVERRIDE),
            Ordering::Relaxed,
        );
    }

    fn scoped_root(&self, scope: &CacheScope) -> PathBuf {
        match scope {
            CacheScope::Public => self.root.clone(),
            CacheScope::Authenticated(scope_id) => self.root.join("auth").join(scope_id),
        }
    }

    fn safe_path_component(value: &str) -> String {
        value
            .chars()
            .map(|c| {
                if c == '/' || c == '\\' || c == '\0' || c.is_control() {
                    '_'
                } else {
                    c
                }
            })
            .collect()
    }

    fn digest_component(digest: &str) -> String {
        let hash = digest.strip_prefix("sha256:").unwrap_or(digest);
        Self::safe_path_component(hash)
    }

    async fn ensure_scope_dirs(&self, scope: &CacheScope) -> anyhow::Result<()> {
        let root = self.scoped_root(scope);
        tokio::fs::create_dir_all(root.join("blobs/sha256")).await?;
        tokio::fs::create_dir_all(root.join("manifests/by-digest/sha256")).await?;
        tokio::fs::create_dir_all(root.join("manifests/by-tag")).await?;
        Ok(())
    }

    /// Return the number of bytes available on the cache filesystem, or 0 if
    /// the statvfs syscall fails.
    fn disk_available_bytes(&self) -> u64 {
        let override_value = self.disk_available_bytes_override.load(Ordering::Relaxed);
        if override_value != NO_DISK_AVAILABLE_OVERRIDE {
            return override_value;
        }

        let Ok(path) = std::ffi::CString::new(self.root.to_str().unwrap_or("/")) else {
            return 0;
        };
        let mut stat: libc::statvfs = unsafe { std::mem::zeroed() };
        let ret = unsafe { libc::statvfs(path.as_ptr(), &mut stat) };
        if ret != 0 {
            return 0;
        }
        #[allow(clippy::unnecessary_cast)]
        let available = (stat.f_bavail as u64) * (stat.f_frsize as u64);
        available
    }

    /// Check that the cache filesystem has at least `MIN_FREE_DISK_BYTES` free.
    /// Returns `Ok(())` if space is available, or an error if not.
    /// If the statvfs syscall fails, logs a warning and allows the write to proceed.
    fn check_disk_space(&self) -> anyhow::Result<()> {
        let available = self.disk_available_bytes();
        if available == 0 {
            warn!("statvfs failed, skipping disk space check");
            return Ok(());
        }
        if available < MIN_FREE_DISK_BYTES {
            anyhow::bail!(
                "insufficient disk space: {} bytes available, need at least {}",
                available,
                MIN_FREE_DISK_BYTES
            );
        }
        Ok(())
    }

    /// Collect filesystem-level cache statistics.
    pub async fn stats(&self) -> anyhow::Result<CacheStats> {
        let root = self.root.clone();
        let disk_available = self.disk_available_bytes();

        Ok(tokio::task::spawn_blocking(move || {
            let mut blob_count: u64 = 0;
            let mut blob_total_bytes: u64 = 0;
            let mut manifest_digest_count: u64 = 0;
            // Count blobs
            let blob_dir = root.join("blobs/sha256");
            if let Ok(rd) = std::fs::read_dir(&blob_dir) {
                for entry in rd.flatten() {
                    let path = entry.path();
                    if path.extension().is_some_and(|ext| ext == "tmp") {
                        continue;
                    }
                    if let Ok(meta) = entry.metadata()
                        && meta.is_file()
                    {
                        blob_count += 1;
                        blob_total_bytes += meta.len();
                    }
                }
            }

            // Count manifests by digest
            let digest_dir = root.join("manifests/by-digest/sha256");
            if let Ok(rd) = std::fs::read_dir(&digest_dir) {
                for entry in rd.flatten() {
                    if let Ok(meta) = entry.metadata()
                        && meta.is_file()
                    {
                        manifest_digest_count += 1;
                    }
                }
            }

            // Count manifests by tag (recursive: by-tag/<registry>/<repo>/<tag>.json)
            fn count_tag_files(dir: &std::path::Path) -> u64 {
                let mut count = 0;
                if let Ok(rd) = std::fs::read_dir(dir) {
                    for entry in rd.flatten() {
                        let path = entry.path();
                        if path.is_dir() {
                            count += count_tag_files(&path);
                        } else if path.is_file()
                            && path.extension().is_some_and(|ext| ext == "json")
                        {
                            count += 1;
                        }
                    }
                }
                count
            }

            let tag_dir = root.join("manifests/by-tag");
            let manifest_tag_count = count_tag_files(&tag_dir);

            CacheStats {
                blob_count,
                blob_total_bytes,
                manifest_digest_count,
                manifest_tag_count,
                disk_available_bytes: disk_available,
            }
        })
        .await?)
    }

    pub fn blob_path(&self, digest: &str) -> PathBuf {
        self.blob_path_scoped(digest, &CacheScope::Public)
    }

    pub fn blob_path_scoped(&self, digest: &str, scope: &CacheScope) -> PathBuf {
        self.scoped_root(scope)
            .join("blobs/sha256")
            .join(Self::digest_component(digest))
    }

    /// Write a blob from an async reader, streaming to disk with digest verification.
    /// Computes SHA-256 as bytes flow through and verifies against the expected digest.
    /// Atomic: writes to a .tmp file, renames only on success + digest match.
    /// Cleans up .tmp on any failure.
    pub async fn write_blob_from_reader(
        &self,
        digest: &str,
        reader: impl AsyncRead + Unpin,
    ) -> anyhow::Result<u64> {
        self.write_blob_from_reader_scoped(digest, reader, &CacheScope::Public)
            .await
    }

    pub async fn write_blob_from_reader_scoped(
        &self,
        digest: &str,
        mut reader: impl AsyncRead + Unpin,
        scope: &CacheScope,
    ) -> anyhow::Result<u64> {
        self.check_disk_space()?;
        self.ensure_scope_dirs(scope).await?;
        let path = self.blob_path_scoped(digest, scope);
        let tmp = path.with_extension("tmp");
        let mut file = tokio::fs::File::create(&tmp).await?;
        let mut hasher = Sha256::new();
        let mut buf = vec![0u8; 64 * 1024];
        let mut written: u64 = 0;

        let result: Result<(), anyhow::Error> = async {
            loop {
                let n = reader.read(&mut buf).await?;
                if n == 0 {
                    break;
                }
                hasher.update(&buf[..n]);
                file.write_all(&buf[..n]).await?;
                written += n as u64;
            }
            file.flush().await?;
            Ok(())
        }
        .await;

        if let Err(e) = result {
            let _ = tokio::fs::remove_file(&tmp).await;
            return Err(e);
        }

        let computed = format!("sha256:{}", hex::encode(hasher.finalize()));
        if computed != digest {
            let _ = tokio::fs::remove_file(&tmp).await;
            if let Some(ref m) = self.metrics {
                m.inc(&m.digest_mismatches);
            }
            anyhow::bail!(
                "digest mismatch: expected {}, computed {}",
                digest,
                computed
            );
        }

        tokio::fs::rename(&tmp, &path).await?;
        Ok(written)
    }

    /// Atomic blob size: returns `Ok(None)` if the file does not exist,
    /// propagates other I/O errors.
    pub async fn try_blob_size(&self, digest: &str) -> anyhow::Result<Option<u64>> {
        self.try_blob_size_scoped(digest, &CacheScope::Public).await
    }

    pub async fn try_blob_size_scoped(
        &self,
        digest: &str,
        scope: &CacheScope,
    ) -> anyhow::Result<Option<u64>> {
        let path = self.blob_path_scoped(digest, scope);
        match tokio::fs::metadata(&path).await {
            Ok(meta) => Ok(Some(meta.len())),
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(None),
            Err(e) => Err(e.into()),
        }
    }

    /// Atomic blob stream: opens the file and returns `(size, stream)`,
    /// or `Ok(None)` if the file does not exist.
    pub async fn try_stream_blob(
        &self,
        digest: &str,
    ) -> anyhow::Result<Option<(u64, ReaderStream<tokio::fs::File>)>> {
        self.try_stream_blob_scoped(digest, &CacheScope::Public)
            .await
    }

    pub async fn try_stream_blob_scoped(
        &self,
        digest: &str,
        scope: &CacheScope,
    ) -> anyhow::Result<Option<(u64, ReaderStream<tokio::fs::File>)>> {
        let path = self.blob_path_scoped(digest, scope);
        match tokio::fs::File::open(&path).await {
            Ok(file) => {
                let meta = file.metadata().await?;
                Ok(Some((meta.len(), ReaderStream::new(file))))
            }
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(None),
            Err(e) => Err(e.into()),
        }
    }

    /// Atomic manifest-by-digest read: returns raw bytes or `Ok(None)` if missing.
    pub async fn try_read_manifest_by_digest(
        &self,
        digest: &str,
    ) -> anyhow::Result<Option<Vec<u8>>> {
        self.try_read_manifest_by_digest_scoped(digest, &CacheScope::Public)
            .await
    }

    pub async fn try_read_manifest_by_digest_scoped(
        &self,
        digest: &str,
        scope: &CacheScope,
    ) -> anyhow::Result<Option<Vec<u8>>> {
        let path = self.manifest_digest_path_scoped(digest, scope);
        match tokio::fs::read(&path).await {
            Ok(data) => Ok(Some(data)),
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(None),
            Err(e) => Err(e.into()),
        }
    }

    pub fn manifest_digest_path(&self, digest: &str) -> PathBuf {
        self.manifest_digest_path_scoped(digest, &CacheScope::Public)
    }

    pub fn manifest_digest_path_scoped(&self, digest: &str, scope: &CacheScope) -> PathBuf {
        self.scoped_root(scope)
            .join("manifests/by-digest/sha256")
            .join(Self::digest_component(digest))
    }

    pub async fn write_manifest_by_digest(&self, digest: &str, data: &[u8]) -> anyhow::Result<()> {
        self.write_manifest_by_digest_scoped(digest, data, &CacheScope::Public)
            .await
    }

    pub async fn write_manifest_by_digest_scoped(
        &self,
        digest: &str,
        data: &[u8],
        scope: &CacheScope,
    ) -> anyhow::Result<()> {
        self.ensure_scope_dirs(scope).await?;
        let path = self.manifest_digest_path_scoped(digest, scope);
        let tmp = path.with_extension("tmp");
        tokio::fs::write(&tmp, data).await?;
        tokio::fs::rename(&tmp, &path).await?;
        Ok(())
    }

    fn tag_path(&self, registry: &str, repo: &str, tag: &str, scope: &CacheScope) -> PathBuf {
        let encoded_registry = Self::safe_path_component(&registry.replace(['/', ':'], "_"));
        let encoded_repo = Self::safe_path_component(&repo.replace('/', "_"));
        let encoded_tag = Self::safe_path_component(tag);
        self.scoped_root(scope)
            .join("manifests/by-tag")
            .join(&encoded_registry)
            .join(&encoded_repo)
            .join(format!("{}.json", encoded_tag))
    }

    pub async fn get_manifest_by_tag(
        &self,
        registry: &str,
        repo: &str,
        tag: &str,
    ) -> anyhow::Result<Option<CachedManifest>> {
        self.get_manifest_by_tag_scoped(registry, repo, tag, &CacheScope::Public)
            .await
    }

    pub async fn get_manifest_by_tag_scoped(
        &self,
        registry: &str,
        repo: &str,
        tag: &str,
        scope: &CacheScope,
    ) -> anyhow::Result<Option<CachedManifest>> {
        let path = self.tag_path(registry, repo, tag, scope);
        if !path.exists() {
            return Ok(None);
        }
        let data = tokio::fs::read_to_string(&path).await?;
        let cached: CachedManifest = serde_json::from_str(&data)?;

        let age = Utc::now() - cached.fetched_at;
        if age.num_seconds() as u64 > self.manifest_ttl_seconds {
            return Ok(None);
        }
        Ok(Some(cached))
    }

    /// Like `get_manifest_by_tag`, but returns stale manifests instead of `None`
    /// when the TTL has expired. This enables stale-while-revalidate: the caller
    /// can serve the stale data immediately while refreshing in the background.
    pub async fn get_manifest_by_tag_with_stale(
        &self,
        registry: &str,
        repo: &str,
        tag: &str,
    ) -> anyhow::Result<Option<ManifestFreshness>> {
        self.get_manifest_by_tag_with_stale_scoped(registry, repo, tag, &CacheScope::Public)
            .await
    }

    pub async fn get_manifest_by_tag_with_stale_scoped(
        &self,
        registry: &str,
        repo: &str,
        tag: &str,
        scope: &CacheScope,
    ) -> anyhow::Result<Option<ManifestFreshness>> {
        let path = self.tag_path(registry, repo, tag, scope);
        if !path.exists() {
            return Ok(None);
        }
        let data = tokio::fs::read_to_string(&path).await?;
        let cached: CachedManifest = serde_json::from_str(&data)?;

        let age = Utc::now() - cached.fetched_at;
        if age.num_seconds() as u64 > self.manifest_ttl_seconds {
            Ok(Some(ManifestFreshness::Stale(cached)))
        } else {
            Ok(Some(ManifestFreshness::Fresh(cached)))
        }
    }

    pub async fn write_manifest_by_tag(
        &self,
        registry: &str,
        repo: &str,
        tag: &str,
        manifest: &CachedManifest,
    ) -> anyhow::Result<()> {
        self.write_manifest_by_tag_scoped(registry, repo, tag, manifest, &CacheScope::Public)
            .await
    }

    pub async fn write_manifest_by_tag_scoped(
        &self,
        registry: &str,
        repo: &str,
        tag: &str,
        manifest: &CachedManifest,
        scope: &CacheScope,
    ) -> anyhow::Result<()> {
        self.ensure_scope_dirs(scope).await?;
        let path = self.tag_path(registry, repo, tag, scope);
        if let Some(parent) = path.parent() {
            tokio::fs::create_dir_all(parent).await?;
        }
        let data = serde_json::to_string(manifest)?;
        let tmp = path.with_extension("tmp.json");
        tokio::fs::write(&tmp, data).await?;
        tokio::fs::rename(&tmp, &path).await?;
        Ok(())
    }

    /// Evict oldest blobs until total blob cache size is under `max_bytes`.
    /// Uses file modification time for LRU ordering.
    /// Runs synchronously on blocking thread pool (file I/O heavy).
    pub async fn evict_blobs(&self, max_bytes: u64) -> anyhow::Result<()> {
        let blob_dir = self.root.join("blobs/sha256");
        let blob_dir_clone = blob_dir.clone();

        // Collect file entries on a blocking thread (many stat calls)
        let mut entries: Vec<(PathBuf, u64, SystemTime)> = tokio::task::spawn_blocking(move || {
            let mut entries = Vec::new();
            let read_dir = match std::fs::read_dir(&blob_dir_clone) {
                Ok(rd) => rd,
                Err(e) => {
                    warn!("failed to read blob cache dir: {}", e);
                    return entries;
                }
            };
            for entry in read_dir.flatten() {
                let path = entry.path();
                // Skip .tmp files (in-progress writes)
                if path.extension().is_some_and(|ext| ext == "tmp") {
                    continue;
                }
                if let Ok(meta) = entry.metadata()
                    && meta.is_file()
                {
                    let mtime = meta.modified().unwrap_or(SystemTime::UNIX_EPOCH);
                    entries.push((path, meta.len(), mtime));
                }
            }
            entries
        })
        .await?;

        if let Some(ref m) = self.metrics {
            m.inc(&m.eviction_runs_total);
        }

        let total_size: u64 = entries.iter().map(|(_, size, _)| size).sum();
        if total_size <= max_bytes {
            debug!(
                "blob cache size {}MB within limit {}MB",
                total_size / (1024 * 1024),
                max_bytes / (1024 * 1024)
            );
            return Ok(());
        }

        // Sort by mtime ascending (oldest first)
        entries.sort_by_key(|(_, _, mtime)| *mtime);

        let mut freed: u64 = 0;
        let target = total_size - max_bytes;
        let mut evicted_count: u64 = 0;

        for (path, size, _) in &entries {
            if freed >= target {
                break;
            }
            if let Err(e) = tokio::fs::remove_file(&path).await {
                warn!("failed to evict blob {}: {}", path.display(), e);
                continue;
            }
            freed += size;
            evicted_count += 1;
        }

        if let Some(ref m) = self.metrics {
            m.add(&m.blobs_evicted_total, evicted_count);
            m.add(&m.bytes_freed_total, freed);
        }

        info!(
            "evicted {} blobs ({}MB freed), cache now ~{}MB",
            evicted_count,
            freed / (1024 * 1024),
            (total_size - freed) / (1024 * 1024)
        );
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use base64::Engine as _;
    use std::io::Cursor;
    use tempfile::TempDir;

    fn tmp_cache(ttl: u64) -> (TempDir, Cache) {
        let dir = TempDir::new().expect("failed to create temp dir");
        let cache = Cache::new(dir.path(), ttl, None).expect("failed to create cache");
        (dir, cache)
    }

    fn hello_world_digest() -> String {
        format!("sha256:{}", hex::encode(Sha256::digest(b"hello world")))
    }

    #[test]
    fn new_creates_dirs() {
        let (dir, _cache) = tmp_cache(900);
        assert!(dir.path().join("blobs/sha256").is_dir());
        assert!(dir.path().join("manifests/by-digest/sha256").is_dir());
        assert!(dir.path().join("manifests/by-tag").is_dir());
    }

    #[test]
    fn blob_path_format() {
        let (dir, cache) = tmp_cache(900);
        let path = cache.blob_path("sha256:abc");
        assert_eq!(path, dir.path().join("blobs/sha256/abc"));
    }

    #[test]
    fn blob_path_strips_prefix() {
        let (dir, cache) = tmp_cache(900);
        // Without "sha256:" prefix, the raw value is used as-is
        let path = cache.blob_path("abc");
        assert_eq!(path, dir.path().join("blobs/sha256/abc"));
    }

    #[tokio::test]
    async fn write_blob_from_reader_success() {
        let (_dir, cache) = tmp_cache(900);
        let digest = hello_world_digest();
        let reader = Cursor::new(b"hello world");

        let written = cache
            .write_blob_from_reader(&digest, reader)
            .await
            .expect("write should succeed");

        assert_eq!(written, 11);
        assert!(cache.try_blob_size(&digest).await.unwrap().is_some());
    }

    #[tokio::test]
    async fn write_blob_from_reader_digest_mismatch() {
        let (_dir, cache) = tmp_cache(900);
        let wrong_digest =
            "sha256:0000000000000000000000000000000000000000000000000000000000000000";
        let reader = Cursor::new(b"hello");

        let result = cache.write_blob_from_reader(wrong_digest, reader).await;
        assert!(result.is_err());
        assert!(!cache.blob_path(wrong_digest).exists());
    }

    #[tokio::test]
    async fn write_blob_no_tmp_leftover() {
        let (dir, cache) = tmp_cache(900);
        let digest = hello_world_digest();
        let reader = Cursor::new(b"hello world");

        cache
            .write_blob_from_reader(&digest, reader)
            .await
            .expect("write should succeed");

        let has_tmp = std::fs::read_dir(dir.path().join("blobs/sha256"))
            .expect("read dir")
            .filter_map(|e| e.ok())
            .any(|e| e.path().extension().is_some_and(|ext| ext == "tmp"));
        assert!(
            !has_tmp,
            "no .tmp files should remain after successful write"
        );
    }

    #[tokio::test]
    async fn manifest_by_digest_roundtrip() {
        let (_dir, cache) = tmp_cache(900);
        let digest = "sha256:abcdef1234567890";
        let content = b"manifest-content-here";

        cache
            .write_manifest_by_digest(digest, content)
            .await
            .expect("write should succeed");

        let read_back = cache
            .try_read_manifest_by_digest(digest)
            .await
            .expect("read should succeed")
            .expect("manifest should be present");
        assert_eq!(read_back, content);
    }

    #[tokio::test]
    async fn manifest_by_tag_roundtrip() {
        let (_dir, cache) = tmp_cache(900);
        let content_bytes = b"some manifest payload";
        let encoded = base64::engine::general_purpose::STANDARD.encode(content_bytes);
        let manifest = CachedManifest {
            fetched_at: Utc::now(),
            digest: "sha256:abc123".to_string(),
            content_type: "application/vnd.docker.distribution.manifest.v2+json".to_string(),
            content: encoded.clone(),
        };

        cache
            .write_manifest_by_tag("docker.io", "library/nginx", "latest", &manifest)
            .await
            .expect("write should succeed");

        let result = cache
            .get_manifest_by_tag("docker.io", "library/nginx", "latest")
            .await
            .expect("get should succeed");

        let cached = result.expect("manifest should be present");
        assert_eq!(cached.digest, "sha256:abc123");
        assert_eq!(
            cached.content_type,
            "application/vnd.docker.distribution.manifest.v2+json"
        );
        assert_eq!(cached.content, encoded);
    }

    #[tokio::test]
    async fn manifest_tag_ttl_fresh() {
        let (_dir, cache) = tmp_cache(900);
        let manifest = CachedManifest {
            fetched_at: Utc::now(),
            digest: "sha256:fresh".to_string(),
            content_type: "application/json".to_string(),
            content: "e30=".to_string(), // base64("{}")
        };

        cache
            .write_manifest_by_tag("gcr.io", "proj/img", "v1", &manifest)
            .await
            .expect("write should succeed");

        let result = cache
            .get_manifest_by_tag("gcr.io", "proj/img", "v1")
            .await
            .expect("get should succeed");

        assert!(result.is_some(), "fresh manifest should be returned");
    }

    #[tokio::test]
    async fn manifest_tag_ttl_expired() {
        let (_dir, cache) = tmp_cache(900);
        let manifest = CachedManifest {
            fetched_at: Utc::now() - chrono::Duration::seconds(1000),
            digest: "sha256:stale".to_string(),
            content_type: "application/json".to_string(),
            content: "e30=".to_string(),
        };

        cache
            .write_manifest_by_tag("gcr.io", "proj/img", "v2", &manifest)
            .await
            .expect("write should succeed");

        let result = cache
            .get_manifest_by_tag("gcr.io", "proj/img", "v2")
            .await
            .expect("get should succeed");

        assert!(result.is_none(), "expired manifest should return None");
    }

    #[tokio::test]
    async fn evict_blobs_under_limit() {
        let (dir, cache) = tmp_cache(900);
        // Write two small blobs (10 bytes each)
        for i in 0..2u8 {
            let data = vec![i; 10];
            let digest = format!("sha256:{}", hex::encode(Sha256::digest(&data)));
            let reader = Cursor::new(data);
            cache
                .write_blob_from_reader(&digest, reader)
                .await
                .expect("write should succeed");
        }

        cache.evict_blobs(1024).await.expect("evict should succeed");

        // All files should still be present
        let count = std::fs::read_dir(dir.path().join("blobs/sha256"))
            .expect("read dir")
            .filter_map(|e| e.ok())
            .filter(|e| e.path().is_file())
            .count();
        assert_eq!(count, 2, "no blobs should be evicted when under limit");
    }

    #[tokio::test]
    async fn evict_blobs_over_limit() {
        let (dir, cache) = tmp_cache(900);
        // Write 5 blobs of 100 bytes each (500 total)
        for i in 0..5u8 {
            let data = vec![i; 100];
            let digest = format!("sha256:{}", hex::encode(Sha256::digest(&data)));
            let reader = Cursor::new(data);
            cache
                .write_blob_from_reader(&digest, reader)
                .await
                .expect("write should succeed");
        }

        // Set limit to 200 bytes; eviction should remove some blobs
        cache.evict_blobs(200).await.expect("evict should succeed");

        let total: u64 = std::fs::read_dir(dir.path().join("blobs/sha256"))
            .expect("read dir")
            .filter_map(|e| e.ok())
            .filter_map(|e| e.metadata().ok())
            .filter(|m| m.is_file())
            .map(|m| m.len())
            .sum();
        assert!(
            total <= 200,
            "total blob size ({total}) should be at most 200 after eviction"
        );
    }

    #[tokio::test]
    async fn evict_blobs_skips_tmp() {
        let (dir, cache) = tmp_cache(900);
        // Write a real blob
        let data = vec![42u8; 100];
        let digest = format!("sha256:{}", hex::encode(Sha256::digest(&data)));
        let reader = Cursor::new(data);
        cache
            .write_blob_from_reader(&digest, reader)
            .await
            .expect("write should succeed");

        // Create a .tmp file manually
        let tmp_path = dir.path().join("blobs/sha256/in-progress.tmp");
        std::fs::write(&tmp_path, b"partial data").expect("write tmp");

        // Evict with limit that forces eviction of the real blob
        cache.evict_blobs(0).await.expect("evict should succeed");

        // The .tmp file should still exist (skipped by eviction)
        assert!(tmp_path.exists(), ".tmp file should not be evicted");
    }

    #[tokio::test]
    async fn write_blob_digest_mismatch_cleans_up_tmp() {
        let (dir, cache) = tmp_cache(900);
        let wrong_digest =
            "sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
        let reader = Cursor::new(b"some data that won't match");

        let result = cache.write_blob_from_reader(wrong_digest, reader).await;
        assert!(result.is_err());

        // Verify no .tmp file was left behind
        let has_tmp = std::fs::read_dir(dir.path().join("blobs/sha256"))
            .expect("read dir")
            .filter_map(|e| e.ok())
            .any(|e| e.path().extension().is_some_and(|ext| ext == "tmp"));
        assert!(!has_tmp, ".tmp should be cleaned up after digest mismatch");
    }

    #[tokio::test]
    async fn write_blob_empty_content() {
        let (_dir, cache) = tmp_cache(900);
        let digest = format!("sha256:{}", hex::encode(Sha256::digest(b"")));
        let reader = Cursor::new(b"");

        let written = cache
            .write_blob_from_reader(&digest, reader)
            .await
            .expect("empty blob write should succeed");

        assert_eq!(written, 0);
        assert!(cache.try_blob_size(&digest).await.unwrap().is_some());
    }

    #[tokio::test]
    async fn manifest_by_tag_different_registries_isolated() {
        let (_dir, cache) = tmp_cache(900);
        let manifest_a = CachedManifest {
            fetched_at: Utc::now(),
            digest: "sha256:aaa".to_string(),
            content_type: "application/json".to_string(),
            content: "YQ==".to_string(),
        };
        let manifest_b = CachedManifest {
            fetched_at: Utc::now(),
            digest: "sha256:bbb".to_string(),
            content_type: "application/json".to_string(),
            content: "Yg==".to_string(),
        };

        cache
            .write_manifest_by_tag("docker.io", "library/nginx", "latest", &manifest_a)
            .await
            .unwrap();
        cache
            .write_manifest_by_tag("ghcr.io", "library/nginx", "latest", &manifest_b)
            .await
            .unwrap();

        let a = cache
            .get_manifest_by_tag("docker.io", "library/nginx", "latest")
            .await
            .unwrap()
            .unwrap();
        let b = cache
            .get_manifest_by_tag("ghcr.io", "library/nginx", "latest")
            .await
            .unwrap()
            .unwrap();

        assert_eq!(a.digest, "sha256:aaa");
        assert_eq!(b.digest, "sha256:bbb");
    }

    #[tokio::test]
    async fn manifest_by_tag_nonexistent() {
        let (_dir, cache) = tmp_cache(900);
        let result = cache
            .get_manifest_by_tag("docker.io", "library/nginx", "nonexistent")
            .await
            .expect("should not error");
        assert!(result.is_none());
    }

    #[test]
    fn manifest_digest_path_format() {
        let (dir, cache) = tmp_cache(900);
        let path = cache.manifest_digest_path("sha256:abc123");
        assert_eq!(path, dir.path().join("manifests/by-digest/sha256/abc123"));
    }

    #[tokio::test]
    async fn manifest_tag_ttl_zero_means_always_expired() {
        let (_dir, cache) = tmp_cache(0);
        let manifest = CachedManifest {
            fetched_at: Utc::now(),
            digest: "sha256:zero-ttl".to_string(),
            content_type: "application/json".to_string(),
            content: "e30=".to_string(),
        };

        cache
            .write_manifest_by_tag("docker.io", "lib/img", "v1", &manifest)
            .await
            .unwrap();

        // With TTL=0, age (even 0s) > 0 is false, but age cast might be 0 which is not > 0
        // Actually: age.num_seconds() as u64 > 0 — if fetched_at == now, age ≈ 0, so 0 > 0 = false → returns Some
        // This documents the edge: TTL=0 with just-written manifest still returns it
        let result = cache
            .get_manifest_by_tag("docker.io", "lib/img", "v1")
            .await
            .unwrap();
        assert!(
            result.is_some(),
            "TTL=0 with age=0 should still return manifest"
        );
    }

    #[tokio::test]
    async fn manifest_by_tag_overwrite_updates_content() {
        let (_dir, cache) = tmp_cache(900);
        let v1 = CachedManifest {
            fetched_at: Utc::now(),
            digest: "sha256:old".to_string(),
            content_type: "application/json".to_string(),
            content: "b2xk".to_string(), // base64("old")
        };
        cache
            .write_manifest_by_tag("docker.io", "library/nginx", "latest", &v1)
            .await
            .unwrap();

        let v2 = CachedManifest {
            fetched_at: Utc::now(),
            digest: "sha256:new".to_string(),
            content_type: "application/json".to_string(),
            content: "bmV3".to_string(), // base64("new")
        };
        cache
            .write_manifest_by_tag("docker.io", "library/nginx", "latest", &v2)
            .await
            .unwrap();

        let result = cache
            .get_manifest_by_tag("docker.io", "library/nginx", "latest")
            .await
            .unwrap()
            .unwrap();
        assert_eq!(
            result.digest, "sha256:new",
            "second write should overwrite first"
        );
    }

    // --- try_* atomic method tests ---

    #[tokio::test]
    async fn try_blob_size_returns_none_for_missing() {
        let (_dir, cache) = tmp_cache(900);
        let result = cache.try_blob_size("sha256:nonexistent").await.unwrap();
        assert!(result.is_none());
    }

    #[tokio::test]
    async fn try_blob_size_returns_size_for_existing() {
        let (_dir, cache) = tmp_cache(900);
        let digest = hello_world_digest();
        let reader = Cursor::new(b"hello world");
        cache.write_blob_from_reader(&digest, reader).await.unwrap();

        let result = cache.try_blob_size(&digest).await.unwrap();
        assert_eq!(result, Some(11));
    }

    #[tokio::test]
    async fn try_stream_blob_returns_none_for_missing() {
        let (_dir, cache) = tmp_cache(900);
        let result = cache.try_stream_blob("sha256:nonexistent").await.unwrap();
        assert!(result.is_none());
    }

    #[tokio::test]
    async fn try_stream_blob_returns_data_for_existing() {
        let (_dir, cache) = tmp_cache(900);
        let digest = hello_world_digest();
        let reader = Cursor::new(b"hello world");
        cache.write_blob_from_reader(&digest, reader).await.unwrap();

        let (size, mut stream) = cache
            .try_stream_blob(&digest)
            .await
            .unwrap()
            .expect("should return Some");

        assert_eq!(size, 11);
        let mut buf = Vec::new();
        while let Some(chunk) = futures_util::StreamExt::next(&mut stream).await {
            buf.extend_from_slice(&chunk.unwrap());
        }
        assert_eq!(buf, b"hello world");
    }

    #[tokio::test]
    async fn try_read_manifest_by_digest_returns_none_for_missing() {
        let (_dir, cache) = tmp_cache(900);
        let result = cache
            .try_read_manifest_by_digest("sha256:nonexistent")
            .await
            .unwrap();
        assert!(result.is_none());
    }

    #[tokio::test]
    async fn try_read_manifest_by_digest_returns_data_for_existing() {
        let (_dir, cache) = tmp_cache(900);
        let digest = "sha256:abc123";
        let content = b"manifest-data";
        cache
            .write_manifest_by_digest(digest, content)
            .await
            .unwrap();

        let result = cache
            .try_read_manifest_by_digest(digest)
            .await
            .unwrap()
            .expect("should return Some");
        assert_eq!(result, content);
    }

    #[tokio::test]
    async fn try_stream_blob_after_eviction_returns_none() {
        let (_dir, cache) = tmp_cache(900);
        let digest = hello_world_digest();
        let reader = Cursor::new(b"hello world");
        cache.write_blob_from_reader(&digest, reader).await.unwrap();

        // Verify it exists
        assert!(cache.try_stream_blob(&digest).await.unwrap().is_some());

        // Simulate eviction by deleting the file
        tokio::fs::remove_file(cache.blob_path(&digest))
            .await
            .unwrap();

        // Should return None, not error
        assert!(cache.try_stream_blob(&digest).await.unwrap().is_none());
    }

    #[tokio::test]
    async fn evict_blobs_with_explicit_mtime_ordering() {
        let (dir, cache) = tmp_cache(900);

        // Write blobs and manually set distinct mtimes to avoid
        // nondeterministic ordering on fast filesystems
        let mut paths = Vec::new();
        for i in 0..3u8 {
            let data = vec![i; 200];
            let digest = format!("sha256:{}", hex::encode(Sha256::digest(&data)));
            let reader = Cursor::new(data);
            cache
                .write_blob_from_reader(&digest, reader)
                .await
                .expect("write should succeed");
            paths.push(cache.blob_path(&digest));
        }

        // Set mtimes: oldest (0) -> middle (1) -> newest (2)
        // Use filetime via raw syscall to set distinct modification times
        for (i, path) in paths.iter().enumerate() {
            let t = std::time::SystemTime::UNIX_EPOCH
                + std::time::Duration::from_secs(1_000_000 + (i as u64) * 1000);
            let file = std::fs::File::open(path).unwrap();
            file.set_modified(t).unwrap();
        }

        // Total = 600 bytes, limit = 200 → must evict oldest until under 200
        cache.evict_blobs(200).await.expect("evict should succeed");

        // Oldest blobs should be gone, newest should remain
        assert!(!paths[0].exists(), "oldest blob should be evicted");
        assert!(paths[2].exists(), "newest blob should survive");

        let total: u64 = std::fs::read_dir(dir.path().join("blobs/sha256"))
            .unwrap()
            .filter_map(|e| e.ok())
            .filter_map(|e| e.metadata().ok())
            .filter(|m| m.is_file())
            .map(|m| m.len())
            .sum();
        assert!(total <= 200);
    }

    // --- get_manifest_by_tag_with_stale tests ---

    #[tokio::test]
    async fn get_manifest_by_tag_with_stale_fresh() {
        let (_dir, cache) = tmp_cache(900);
        let manifest = CachedManifest {
            fetched_at: Utc::now(),
            digest: "sha256:fresh".to_string(),
            content_type: "application/json".to_string(),
            content: "e30=".to_string(),
        };

        cache
            .write_manifest_by_tag("gcr.io", "proj/img", "v1", &manifest)
            .await
            .expect("write should succeed");

        let result = cache
            .get_manifest_by_tag_with_stale("gcr.io", "proj/img", "v1")
            .await
            .expect("get should succeed");

        assert!(
            matches!(result, Some(ManifestFreshness::Fresh(_))),
            "fresh manifest should return Fresh variant"
        );
        if let Some(ManifestFreshness::Fresh(cached)) = result {
            assert_eq!(cached.digest, "sha256:fresh");
        }
    }

    #[tokio::test]
    async fn get_manifest_by_tag_with_stale_expired() {
        let (_dir, cache) = tmp_cache(900);
        let manifest = CachedManifest {
            fetched_at: Utc::now() - chrono::Duration::seconds(1000),
            digest: "sha256:stale".to_string(),
            content_type: "application/json".to_string(),
            content: "e30=".to_string(),
        };

        cache
            .write_manifest_by_tag("gcr.io", "proj/img", "v2", &manifest)
            .await
            .expect("write should succeed");

        let result = cache
            .get_manifest_by_tag_with_stale("gcr.io", "proj/img", "v2")
            .await
            .expect("get should succeed");

        assert!(
            matches!(result, Some(ManifestFreshness::Stale(_))),
            "expired manifest should return Stale variant, not None"
        );
        if let Some(ManifestFreshness::Stale(cached)) = result {
            assert_eq!(cached.digest, "sha256:stale");
        }
    }

    #[tokio::test]
    async fn get_manifest_by_tag_with_stale_missing() {
        let (_dir, cache) = tmp_cache(900);

        let result = cache
            .get_manifest_by_tag_with_stale("docker.io", "library/nginx", "nonexistent")
            .await
            .expect("should not error");

        assert!(result.is_none(), "missing manifest should return None");
    }

    #[tokio::test]
    async fn evict_blobs_records_metrics() {
        use std::sync::atomic::Ordering;

        let dir = TempDir::new().expect("failed to create temp dir");
        let metrics = Arc::new(Metrics::default());
        let cache =
            Cache::new(dir.path(), 900, Some(metrics.clone())).expect("failed to create cache");

        // Write 5 blobs of 100 bytes each (500 total)
        for i in 0..5u8 {
            let data = vec![i; 100];
            let digest = format!("sha256:{}", hex::encode(Sha256::digest(&data)));
            let reader = Cursor::new(data);
            cache
                .write_blob_from_reader(&digest, reader)
                .await
                .expect("write should succeed");
        }

        // Evict with limit of 200 bytes (must free at least 300)
        cache.evict_blobs(200).await.expect("evict should succeed");

        assert_eq!(
            metrics.eviction_runs_total.load(Ordering::Relaxed),
            1,
            "eviction_runs_total should be 1 after one eviction run"
        );
        assert!(
            metrics.blobs_evicted_total.load(Ordering::Relaxed) >= 3,
            "should evict at least 3 blobs to get from 500 to <=200 bytes"
        );
        assert!(
            metrics.bytes_freed_total.load(Ordering::Relaxed) >= 300,
            "should free at least 300 bytes"
        );
    }

    #[tokio::test]
    async fn evict_blobs_under_limit_still_counts_run() {
        use std::sync::atomic::Ordering;

        let dir = TempDir::new().expect("failed to create temp dir");
        let metrics = Arc::new(Metrics::default());
        let cache =
            Cache::new(dir.path(), 900, Some(metrics.clone())).expect("failed to create cache");

        // Write a small blob
        let data = vec![0u8; 10];
        let digest = format!("sha256:{}", hex::encode(Sha256::digest(&data)));
        let reader = Cursor::new(data);
        cache
            .write_blob_from_reader(&digest, reader)
            .await
            .expect("write should succeed");

        // Evict with generous limit -- nothing to evict
        cache.evict_blobs(1024).await.expect("evict should succeed");

        assert_eq!(
            metrics.eviction_runs_total.load(Ordering::Relaxed),
            1,
            "eviction_runs_total should increment even when no blobs are evicted"
        );
        assert_eq!(
            metrics.blobs_evicted_total.load(Ordering::Relaxed),
            0,
            "no blobs should be evicted when under limit"
        );
        assert_eq!(
            metrics.bytes_freed_total.load(Ordering::Relaxed),
            0,
            "no bytes should be freed when under limit"
        );
    }

    #[tokio::test]
    async fn write_blob_digest_mismatch_increments_metric() {
        use std::sync::atomic::Ordering;

        let dir = TempDir::new().expect("failed to create temp dir");
        let metrics = Arc::new(Metrics::default());
        let cache =
            Cache::new(dir.path(), 900, Some(metrics.clone())).expect("failed to create cache");

        let wrong_digest =
            "sha256:0000000000000000000000000000000000000000000000000000000000000000";
        let reader = Cursor::new(b"hello world");
        let result = cache.write_blob_from_reader(wrong_digest, reader).await;
        assert!(result.is_err());
        assert_eq!(
            metrics.digest_mismatches.load(Ordering::Relaxed),
            1,
            "digest_mismatches should increment on mismatch"
        );
    }

    #[tokio::test]
    async fn check_disk_space_passes_for_temp_dir() {
        let (_dir, cache) = tmp_cache(900);
        assert!(
            cache.check_disk_space().is_ok(),
            "temp dir should have enough free space"
        );
    }

    #[tokio::test]
    async fn disk_space_override_for_tests_forces_failure() {
        let (_dir, cache) = tmp_cache(900);
        cache.set_disk_available_bytes_override_for_tests(Some(1));
        let err = cache.check_disk_space().unwrap_err();
        assert!(
            err.to_string().contains("insufficient disk space"),
            "unexpected error: {err}"
        );
        cache.set_disk_available_bytes_override_for_tests(None);
        assert!(cache.check_disk_space().is_ok());
    }

    #[tokio::test]
    async fn stats_empty_cache() {
        let (_dir, cache) = tmp_cache(900);
        let stats = cache.stats().await.expect("stats should succeed");
        assert_eq!(stats.blob_count, 0);
        assert_eq!(stats.blob_total_bytes, 0);
        assert_eq!(stats.manifest_digest_count, 0);
        assert_eq!(stats.manifest_tag_count, 0);
        assert!(stats.disk_available_bytes > 0);
    }

    #[tokio::test]
    async fn stats_counts_blobs_and_manifests() {
        let (_dir, cache) = tmp_cache(900);

        // Write two blobs
        for i in 0..2u8 {
            let data = vec![i; 100];
            let digest = format!("sha256:{}", hex::encode(Sha256::digest(&data)));
            cache
                .write_blob_from_reader(&digest, Cursor::new(data))
                .await
                .unwrap();
        }

        // Write a manifest by digest
        cache
            .write_manifest_by_digest("sha256:deadbeef", b"manifest-1")
            .await
            .unwrap();

        // Write two manifests by tag
        for tag in &["latest", "v1"] {
            let manifest = CachedManifest {
                fetched_at: Utc::now(),
                digest: format!("sha256:{tag}"),
                content_type: "application/json".to_string(),
                content: "e30=".to_string(),
            };
            cache
                .write_manifest_by_tag("docker.io", "library/nginx", tag, &manifest)
                .await
                .unwrap();
        }

        let stats = cache.stats().await.expect("stats should succeed");
        assert_eq!(stats.blob_count, 2);
        assert_eq!(stats.blob_total_bytes, 200);
        assert_eq!(stats.manifest_digest_count, 1);
        assert_eq!(stats.manifest_tag_count, 2);
    }

    #[tokio::test]
    async fn stats_skips_tmp_files() {
        let (dir, cache) = tmp_cache(900);

        // Write a real blob
        let data = vec![42u8; 50];
        let digest = format!("sha256:{}", hex::encode(Sha256::digest(&data)));
        cache
            .write_blob_from_reader(&digest, Cursor::new(data))
            .await
            .unwrap();

        // Create a .tmp file manually
        std::fs::write(dir.path().join("blobs/sha256/in-progress.tmp"), b"partial").unwrap();

        let stats = cache.stats().await.expect("stats should succeed");
        assert_eq!(stats.blob_count, 1, ".tmp files should be excluded");
        assert_eq!(stats.blob_total_bytes, 50);
    }
}
