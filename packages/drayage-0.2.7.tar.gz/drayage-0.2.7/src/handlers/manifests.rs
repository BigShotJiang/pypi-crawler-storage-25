use std::sync::Arc;
use std::time::Instant;

use axum::http::StatusCode;
use axum::response::Response;
use base64::{Engine as _, engine::general_purpose::STANDARD as BASE64};
use chrono::Utc;
use sha2::{Digest, Sha256};
use tokio::sync::OnceCell;
use tracing::{debug, warn};

/// Minimum interval between revalidation attempts for the same tag.
const REVALIDATION_BACKOFF_SECS: u64 = 30;

use crate::cache::{CacheScope, CachedManifest, ManifestFreshness};
use crate::registry::{
    is_valid_repository, is_valid_sha256_digest, is_valid_tag, parse_image_name,
};
use crate::{AppState, InflightGuard, UpstreamError};

pub async fn handle_manifest(
    state: AppState,
    name: String,
    reference: String,
    host_override: Option<String>,
    head_only: bool,
    client_auth: Option<String>,
) -> Response {
    let parsed = parse_image_name(&name, host_override.as_deref());
    debug!(
        "manifest request: name={}, ref={}, registry={}",
        name, reference, parsed.registry_host
    );

    let is_digest = reference.starts_with("sha256:");
    if !is_valid_repository(&parsed.repo) {
        return error_response(StatusCode::BAD_REQUEST, "invalid repository name");
    }
    if is_digest {
        if !is_valid_sha256_digest(&reference) {
            return error_response(StatusCode::BAD_REQUEST, "invalid digest");
        }
    } else if !is_valid_tag(&reference) {
        return error_response(StatusCode::BAD_REQUEST, "invalid tag");
    }

    let cache_scope = CacheScope::for_client_auth(client_auth.as_deref());
    let cache_scope_key = cache_scope.cache_key_prefix();

    // Check cache first (atomic reads to avoid TOCTOU races with eviction)
    if is_digest {
        match state
            .cache
            .try_read_manifest_by_digest_scoped(&reference, &cache_scope)
            .await
        {
            Ok(Some(data)) => {
                state.metrics.inc(&state.metrics.manifest_cache_hits);
                state
                    .metrics
                    .manifest_cache_hits_by_registry
                    .inc(&parsed.registry_key);
                state
                    .metrics
                    .bandwidth_saved_bytes
                    .add(&parsed.registry_key, data.len() as u64);
                return manifest_response(&data, &reference, None, head_only);
            }
            Ok(None) => {} // cache miss
            Err(e) => {
                warn!("failed to read cached manifest: {}", e);
                return error_response(StatusCode::INTERNAL_SERVER_ERROR, "cache read error");
            }
        }
    } else {
        match state
            .cache
            .get_manifest_by_tag_with_stale_scoped(
                &parsed.registry_host,
                &parsed.repo,
                &reference,
                &cache_scope,
            )
            .await
        {
            Ok(Some(ManifestFreshness::Fresh(cached))) => {
                if let Ok(data) = BASE64.decode(&cached.content) {
                    state.metrics.inc(&state.metrics.manifest_cache_hits);
                    state
                        .metrics
                        .manifest_cache_hits_by_registry
                        .inc(&parsed.registry_key);
                    state
                        .metrics
                        .bandwidth_saved_bytes
                        .add(&parsed.registry_key, data.len() as u64);
                    return manifest_response(
                        &data,
                        &cached.digest,
                        Some(&cached.content_type),
                        head_only,
                    );
                }
                warn!("corrupt fresh manifest cache entry, falling through to upstream");
            }
            Ok(Some(ManifestFreshness::Stale(cached))) => {
                if let Ok(data) = BASE64.decode(&cached.content) {
                    state.metrics.inc(&state.metrics.manifest_cache_hits);
                    state
                        .metrics
                        .manifest_cache_hits_by_registry
                        .inc(&parsed.registry_key);
                    state
                        .metrics
                        .bandwidth_saved_bytes
                        .add(&parsed.registry_key, data.len() as u64);
                    state.metrics.inc(&state.metrics.manifest_stale_revalidates);
                    if !state.config.offline_mode {
                        let reval_key = format!(
                            "{}:{}:{}:{}",
                            cache_scope_key, parsed.registry_host, parsed.repo, reference
                        );
                        let should_revalidate = state
                            .revalidation_tracker
                            .get(&reval_key)
                            .is_none_or(|entry| {
                                entry.elapsed().as_secs() >= REVALIDATION_BACKOFF_SECS
                            });
                        if should_revalidate {
                            state.revalidation_tracker.insert(reval_key, Instant::now());
                            spawn_revalidate(
                                state.clone(),
                                parsed.clone(),
                                reference.clone(),
                                client_auth.clone(),
                                cache_scope.clone(),
                            );
                        }
                    }
                    return manifest_response(
                        &data,
                        &cached.digest,
                        Some(&cached.content_type),
                        head_only,
                    );
                }
                warn!("corrupt stale manifest cache entry, falling through to upstream");
            }
            Ok(None) => {} // true cache miss, fall through
            Err(e) => {
                warn!("cache read error: {}", e);
                // fall through to upstream
            }
        }
    }

    state.metrics.inc(&state.metrics.manifest_cache_misses);
    state
        .metrics
        .manifest_cache_misses_by_registry
        .inc(&parsed.registry_key);

    // Check negative cache for tag lookups (digests are content-addressed, skip)
    if !is_digest {
        let neg_key = format!(
            "{}:{}:{}:{}",
            cache_scope_key, parsed.registry_host, parsed.repo, reference
        );
        if let Some(_status) = state.negative_cache.get(&neg_key) {
            state.metrics.inc(&state.metrics.negative_cache_hits);
            return error_response(StatusCode::NOT_FOUND, "manifest not found");
        }
    }

    // Offline mode: no upstream to fetch from
    if state.config.offline_mode {
        debug!("offline mode: returning 404 for cache miss");
        return error_response(StatusCode::NOT_FOUND, "manifest not found");
    }

    // Cache miss — coalesce concurrent requests
    let inflight_key = if is_digest {
        format!("manifest:{}:{}", cache_scope_key, reference)
    } else {
        format!(
            "manifest:{}:{}:{}:{}",
            cache_scope_key, parsed.registry_host, parsed.repo, reference
        )
    };

    let cell = state
        .inflight
        .entry(inflight_key.clone())
        .or_insert_with(|| Arc::new(OnceCell::new()))
        .clone();

    // RAII guard ensures cleanup even on client disconnect
    let _guard = InflightGuard::new(state.inflight.clone(), inflight_key.clone());

    if cell.initialized() {
        state.metrics.inc(&state.metrics.coalesce_joined);
    }

    let result = cell
        .get_or_init(|| {
            let state = state.clone();
            let parsed = parsed.clone();
            let reference = reference.clone();
            let client_auth = client_auth.clone();
            let cache_scope = cache_scope.clone();
            let cache_scope_key = cache_scope_key.clone();
            async move {
                state.metrics.inc(&state.metrics.upstream_fetches);
                debug!(
                    "upstream manifest fetch: {}/{}:{}",
                    parsed.registry_host, parsed.repo, reference
                );
                let upstream_resp = match state
                    .upstream
                    .fetch_manifest(
                        &parsed.registry_key,
                        &parsed.registry_host,
                        &parsed.repo,
                        &reference,
                        client_auth.as_deref(),
                    )
                    .await
                {
                    Ok(r) => r,
                    Err(e) => {
                        warn!("upstream fetch failed: {}", e);
                        return Err(UpstreamError::Unavailable(format!("{e}")));
                    }
                };

                if upstream_resp.status == 404
                    || upstream_resp.status == 401
                    || upstream_resp.status == 403
                    || (!is_digest && upstream_resp.status == 400)
                {
                    if !is_digest {
                        let neg_key = format!(
                            "{}:{}:{}:{}",
                            cache_scope_key, parsed.registry_host, parsed.repo, reference
                        );
                        state.negative_cache.insert(neg_key, upstream_resp.status);
                    }
                    return Err(UpstreamError::NotFound);
                }
                if upstream_resp.status == 410 {
                    return Err(UpstreamError::Gone);
                }

                if upstream_resp.status != 200 {
                    warn!("upstream returned {}", upstream_resp.status);
                    return Err(UpstreamError::BadGateway(upstream_resp.status));
                }

                let digest = compute_digest(&upstream_resp.body);
                if let Some(header_digest) = upstream_resp.docker_content_digest.as_deref()
                    && header_digest != digest
                {
                    state.metrics.inc(&state.metrics.digest_mismatches);
                    warn!(
                        "upstream manifest digest mismatch: header={}, computed={}",
                        header_digest, digest
                    );
                    return Err(UpstreamError::BadGateway(502));
                }
                if is_digest && reference != digest {
                    state.metrics.inc(&state.metrics.digest_mismatches);
                    warn!(
                        "upstream manifest digest mismatch for requested digest: requested={}, computed={}",
                        reference, digest
                    );
                    return Err(UpstreamError::BadGateway(502));
                }

                let content_type = upstream_resp.content_type.clone().unwrap_or_else(|| {
                    "application/vnd.docker.distribution.manifest.v2+json".to_string()
                });

                if digest.starts_with("sha256:")
                    && let Err(e) = state
                        .cache
                        .write_manifest_by_digest_scoped(&digest, &upstream_resp.body, &cache_scope)
                        .await
                {
                    warn!("failed to cache manifest by digest: {}", e);
                }

                if !is_digest {
                    let cached = CachedManifest {
                        fetched_at: Utc::now(),
                        digest: digest.clone(),
                        content_type: content_type.clone(),
                        content: BASE64.encode(&upstream_resp.body),
                    };
                    if let Err(e) = state
                        .cache
                        .write_manifest_by_tag_scoped(
                            &parsed.registry_host,
                            &parsed.repo,
                            &reference,
                            &cached,
                            &cache_scope,
                        )
                        .await
                    {
                        warn!("failed to cache manifest by tag: {}", e);
                    }
                }

                Ok(())
            }
        })
        .await;

    match result {
        Ok(()) => {
            // Read back from cache atomically
            if is_digest {
                match state
                    .cache
                    .try_read_manifest_by_digest_scoped(&reference, &cache_scope)
                    .await
                {
                    Ok(Some(data)) => manifest_response(&data, &reference, None, head_only),
                    Ok(None) => {
                        warn!(
                            "manifest {} missing from cache after upstream fetch",
                            reference
                        );
                        error_response(StatusCode::INTERNAL_SERVER_ERROR, "cache read error")
                    }
                    Err(e) => {
                        warn!("failed to read manifest after caching: {}", e);
                        error_response(StatusCode::INTERNAL_SERVER_ERROR, "cache read error")
                    }
                }
            } else {
                match state
                    .cache
                    .get_manifest_by_tag_scoped(
                        &parsed.registry_host,
                        &parsed.repo,
                        &reference,
                        &cache_scope,
                    )
                    .await
                {
                    Ok(Some(cached)) => {
                        let data = match BASE64.decode(&cached.content) {
                            Ok(d) => d,
                            Err(_) => {
                                return error_response(
                                    StatusCode::INTERNAL_SERVER_ERROR,
                                    "cache decode error",
                                );
                            }
                        };
                        manifest_response(
                            &data,
                            &cached.digest,
                            Some(&cached.content_type),
                            head_only,
                        )
                    }
                    _ => error_response(StatusCode::INTERNAL_SERVER_ERROR, "cache read error"),
                }
            }
        }
        Err(e) => match e {
            UpstreamError::NotFound | UpstreamError::Gone => {
                error_response(StatusCode::NOT_FOUND, "manifest not found")
            }
            UpstreamError::BadGateway(_) | UpstreamError::Unavailable(_) => {
                error_response(StatusCode::BAD_GATEWAY, "upstream error")
            }
        },
    }
}

fn spawn_revalidate(
    state: AppState,
    parsed: crate::registry::ParsedImage,
    reference: String,
    client_auth: Option<String>,
    cache_scope: CacheScope,
) {
    tokio::spawn(async move {
        debug!(
            "stale-while-revalidate: refreshing {}/{}:{}",
            parsed.registry_host, parsed.repo, reference
        );
        let upstream_resp = match state
            .upstream
            .fetch_manifest(
                &parsed.registry_key,
                &parsed.registry_host,
                &parsed.repo,
                &reference,
                client_auth.as_deref(),
            )
            .await
        {
            Ok(r) => r,
            Err(e) => {
                state
                    .metrics
                    .inc(&state.metrics.manifest_revalidation_failures);
                warn!("background revalidate failed: {}", e);
                return;
            }
        };

        if upstream_resp.status != 200 {
            state
                .metrics
                .inc(&state.metrics.manifest_revalidation_failures);
            warn!("background revalidate got status {}", upstream_resp.status);
            return;
        }

        let digest = compute_digest(&upstream_resp.body);
        if let Some(header_digest) = upstream_resp.docker_content_digest.as_deref()
            && header_digest != digest
        {
            state
                .metrics
                .inc(&state.metrics.manifest_revalidation_failures);
            state.metrics.inc(&state.metrics.digest_mismatches);
            warn!(
                "background revalidate digest mismatch: header={}, computed={}",
                header_digest, digest
            );
            return;
        }
        let content_type = upstream_resp
            .content_type
            .clone()
            .unwrap_or_else(|| "application/vnd.docker.distribution.manifest.v2+json".to_string());

        if digest.starts_with("sha256:")
            && let Err(e) = state
                .cache
                .write_manifest_by_digest_scoped(&digest, &upstream_resp.body, &cache_scope)
                .await
        {
            warn!("background revalidate: failed to cache by digest: {}", e);
        }

        let cached = CachedManifest {
            fetched_at: Utc::now(),
            digest,
            content_type,
            content: BASE64.encode(&upstream_resp.body),
        };
        if let Err(e) = state
            .cache
            .write_manifest_by_tag_scoped(
                &parsed.registry_host,
                &parsed.repo,
                &reference,
                &cached,
                &cache_scope,
            )
            .await
        {
            warn!("background revalidate: failed to cache by tag: {}", e);
        }

        // Clear backoff so next stale request triggers immediate revalidation
        let reval_key = format!(
            "{}:{}:{}:{}",
            cache_scope.cache_key_prefix(),
            parsed.registry_host,
            parsed.repo,
            reference
        );
        state.revalidation_tracker.remove(&reval_key);

        debug!(
            "stale-while-revalidate: refreshed {}/{}:{}",
            parsed.registry_host, parsed.repo, reference
        );
    });
}

fn manifest_response(
    data: &[u8],
    digest: &str,
    content_type: Option<&str>,
    head_only: bool,
) -> Response {
    let ct = content_type.unwrap_or("application/vnd.docker.distribution.manifest.v2+json");
    let len = data.len();
    let builder = Response::builder()
        .status(StatusCode::OK)
        .header("Content-Type", ct)
        .header("Docker-Distribution-Api-Version", "registry/2.0")
        .header("Docker-Content-Digest", digest)
        .header("Content-Length", len.to_string());

    if head_only {
        builder
            .body(axum::body::Body::empty())
            .expect("response build")
    } else {
        builder
            .body(axum::body::Body::from(data.to_vec()))
            .expect("response build")
    }
}

fn error_response(status: StatusCode, msg: &str) -> Response {
    let code = match msg {
        "invalid repository name" => "NAME_INVALID",
        "invalid digest" => "DIGEST_INVALID",
        "invalid tag" => "TAG_INVALID",
        _ => "",
    };
    let code = if code.is_empty() {
        msg.to_uppercase().replace(' ', "_")
    } else {
        code.to_string()
    };

    Response::builder()
        .status(status)
        .header("Content-Type", "application/json")
        .body(axum::body::Body::from(format!(
            r#"{{"errors":[{{"code":"{}","message":"{}"}}]}}"#,
            code, msg
        )))
        .expect("response build")
}

fn compute_digest(data: &[u8]) -> String {
    let hash = Sha256::digest(data);
    format!("sha256:{}", hex::encode(hash))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn known_vector_hello() {
        assert_eq!(
            compute_digest(b"hello"),
            "sha256:2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824"
        );
    }

    #[test]
    fn empty_input() {
        assert_eq!(
            compute_digest(b""),
            "sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        );
    }

    #[test]
    fn binary_data() {
        let expected = format!("sha256:{}", hex::encode(Sha256::digest([0u8; 1024])));
        assert_eq!(compute_digest(&[0u8; 1024]), expected);
    }

    #[test]
    fn manifest_response_get_has_body() {
        let data = b"test manifest body";
        let resp = manifest_response(data, "sha256:abc", Some("application/json"), false);
        assert_eq!(resp.status(), StatusCode::OK);
        assert_eq!(
            resp.headers().get("Docker-Content-Digest").unwrap(),
            "sha256:abc"
        );
        assert_eq!(
            resp.headers().get("Content-Type").unwrap(),
            "application/json"
        );
        assert_eq!(
            resp.headers()
                .get("Docker-Distribution-Api-Version")
                .unwrap(),
            "registry/2.0"
        );
        assert_eq!(
            resp.headers().get("Content-Length").unwrap(),
            &data.len().to_string()
        );
    }

    #[tokio::test]
    async fn manifest_response_head_has_empty_body() {
        let data = b"test manifest body";
        let resp = manifest_response(data, "sha256:abc", Some("application/json"), true);
        assert_eq!(resp.status(), StatusCode::OK);
        assert_eq!(
            resp.headers().get("Content-Length").unwrap(),
            &data.len().to_string()
        );
        // HEAD response should have empty body
        let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
            .await
            .unwrap();
        assert!(body.is_empty(), "HEAD response body should be empty");
    }

    #[test]
    fn manifest_response_default_content_type() {
        let resp = manifest_response(b"data", "sha256:abc", None, false);
        assert_eq!(
            resp.headers().get("Content-Type").unwrap(),
            "application/vnd.docker.distribution.manifest.v2+json"
        );
    }

    #[test]
    fn error_response_format() {
        let resp = error_response(StatusCode::NOT_FOUND, "manifest not found");
        assert_eq!(resp.status(), StatusCode::NOT_FOUND);
        assert_eq!(
            resp.headers().get("Content-Type").unwrap(),
            "application/json"
        );
    }

    #[tokio::test]
    async fn error_response_body_is_valid_json() {
        let resp = error_response(StatusCode::NOT_FOUND, "manifest not found");
        let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
            .await
            .unwrap();
        let parsed: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert!(parsed["errors"].is_array());
        assert_eq!(parsed["errors"][0]["code"], "MANIFEST_NOT_FOUND");
        assert_eq!(parsed["errors"][0]["message"], "manifest not found");
    }

    #[tokio::test]
    async fn error_response_invalid_digest_uses_oci_code() {
        let resp = error_response(StatusCode::BAD_REQUEST, "invalid digest");
        let body = axum::body::to_bytes(resp.into_body(), usize::MAX)
            .await
            .unwrap();
        let parsed: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(parsed["errors"][0]["code"], "DIGEST_INVALID");
    }

    #[test]
    fn compute_digest_deterministic() {
        let data = b"deterministic check";
        assert_eq!(compute_digest(data), compute_digest(data));
    }

    #[test]
    fn compute_digest_different_inputs_differ() {
        assert_ne!(compute_digest(b"a"), compute_digest(b"b"));
    }
}
