use axum::http::StatusCode;
use axum::response::Response;

pub async fn handle_version_check() -> Response {
    Response::builder()
        .status(StatusCode::OK)
        .header("Docker-Distribution-Api-Version", "registry/2.0")
        .header("Content-Type", "application/json")
        .body(axum::body::Body::from("{}"))
        .expect("response build")
}
