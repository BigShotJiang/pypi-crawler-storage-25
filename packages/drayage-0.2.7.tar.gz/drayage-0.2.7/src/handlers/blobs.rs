use std::sync::Arc;

use axum::body::Body;
use axum::http::StatusCode;
use axum::response::Response;
use tokio::sync::OnceCell;
use tracing::{debug, warn};

use crate::cache::CacheScope;
use crate::registry::{is_valid_repository, is_valid_sha256_digest, parse_image_name};
use crate::upstream::BlobFetchRequest;
use crate::{AppState, InflightGuard, UpstreamError};

pub async fn handle_blob(
    state: AppState,
    name: String,
    digest: String,
    host_override: Option<String>,
    head_only: bool,
    client_auth: Option<String>,
) -> Response {
    debug!("blob request: name={}, digest={}", name, digest);

    let parsed = parse_image_name(&name, host_override.as_deref());
    if !is_valid_repository(&parsed.repo) {
        return error_response(StatusCode::BAD_REQUEST, "invalid repository name");
    }
    if !is_valid_sha256_digest(&digest) {
        return error_response(StatusCode::BAD_REQUEST, "invalid digest");
    }
    let cache_scope = CacheScope::for_client_auth(client_auth.as_deref());
    let cache_scope_key = cache_scope.cache_key_prefix();

    // Atomic cache probe — no separate existence check
    match try_stream_blob_response(&state, &digest, &cache_scope, head_only).await {
        Ok(Some(resp)) => {
            state.metrics.inc(&state.metrics.blob_cache_hits);
            state
                .metrics
                .blob_cache_hits_by_registry
                .inc(&parsed.registry_key);
            if let Ok(Some(size)) = state
                .cache
                .try_blob_size_scoped(&digest, &cache_scope)
                .await
            {
                state
                    .metrics
                    .bandwidth_saved_bytes
                    .add(&parsed.registry_key, size);
            }
            return resp;
        }
        Ok(None) => {} // cache miss, fall through to upstream
        Err(e) => {
            warn!("cache read error for blob {}: {}", digest, e);
            return error_response(StatusCode::INTERNAL_SERVER_ERROR, "cache read error");
        }
    }

    state.metrics.inc(&state.metrics.blob_cache_misses);
    state
        .metrics
        .blob_cache_misses_by_registry
        .inc(&parsed.registry_key);

    if state.config.offline_mode {
        debug!("offline mode: returning 404 for blob cache miss");
        return error_response(StatusCode::NOT_FOUND, "blob not found");
    }

    let inflight_key = format!("blob:{}:{}", cache_scope_key, digest);

    let cell = state
        .inflight
        .entry(inflight_key.clone())
        .or_insert_with(|| Arc::new(OnceCell::new()))
        .clone();

    // RAII guard ensures cleanup even on client disconnect
    let _guard = InflightGuard::new(state.inflight.clone(), inflight_key.clone());

    // If the cell already has a value being computed, this request is coalescing
    if cell.initialized() {
        state.metrics.inc(&state.metrics.coalesce_joined);
    }

    let result = cell
        .get_or_init(|| {
            let state = state.clone();
            let parsed = parsed.clone();
            let digest = digest.clone();
            let client_auth = client_auth.clone();
            let cache_scope = cache_scope.clone();
            async move {
                debug!("upstream blob fetch (streaming): {}", digest);
                state.metrics.inc(&state.metrics.upstream_fetches);
                let fetch_result = match state
                    .upstream
                    .fetch_blob_to_cache(
                        BlobFetchRequest {
                            registry_key: &parsed.registry_key,
                            registry_host: &parsed.registry_host,
                            repo: &parsed.repo,
                            digest: &digest,
                            client_auth: client_auth.as_deref(),
                        },
                        &state.cache,
                        &cache_scope,
                    )
                    .await
                {
                    Ok(r) => r,
                    Err(e) => {
                        warn!("upstream blob fetch failed: {}", e);
                        return Err(UpstreamError::Unavailable(format!("{e}")));
                    }
                };

                if fetch_result.status == 404 {
                    return Err(UpstreamError::NotFound);
                }
                if fetch_result.status == 401 || fetch_result.status == 403 {
                    return Err(UpstreamError::NotFound);
                }
                if fetch_result.status == 410 {
                    return Err(UpstreamError::Gone);
                }
                if fetch_result.status != 200 {
                    return Err(UpstreamError::BadGateway(fetch_result.status));
                }

                Ok(())
            }
        })
        .await;

    match result {
        Ok(()) => {
            // Read back from cache atomically
            match try_stream_blob_response(&state, &digest, &cache_scope, head_only).await {
                Ok(Some(resp)) => resp,
                Ok(None) => {
                    warn!("blob {} missing from cache after upstream fetch", digest);
                    error_response(StatusCode::INTERNAL_SERVER_ERROR, "cache read error")
                }
                Err(e) => {
                    warn!("cache read error for blob {}: {}", digest, e);
                    error_response(StatusCode::INTERNAL_SERVER_ERROR, "cache read error")
                }
            }
        }
        Err(e) => match e {
            UpstreamError::NotFound | UpstreamError::Gone => {
                error_response(StatusCode::NOT_FOUND, "blob not found")
            }
            UpstreamError::BadGateway(_) | UpstreamError::Unavailable(_) => {
                error_response(StatusCode::BAD_GATEWAY, "upstream error")
            }
        },
    }
}

/// Attempt to build a streaming response from a cached blob.
/// Returns `Ok(None)` if the blob does not exist (race-safe).
async fn try_stream_blob_response(
    state: &AppState,
    digest: &str,
    cache_scope: &CacheScope,
    head_only: bool,
) -> anyhow::Result<Option<Response>> {
    if head_only {
        match state
            .cache
            .try_blob_size_scoped(digest, cache_scope)
            .await?
        {
            Some(size) => Ok(Some(
                Response::builder()
                    .status(StatusCode::OK)
                    .header("Content-Type", "application/octet-stream")
                    .header("Docker-Distribution-Api-Version", "registry/2.0")
                    .header("Docker-Content-Digest", digest)
                    .header("Content-Length", size.to_string())
                    .body(Body::empty())
                    .expect("response build"),
            )),
            None => Ok(None),
        }
    } else {
        match state
            .cache
            .try_stream_blob_scoped(digest, cache_scope)
            .await?
        {
            Some((size, stream)) => Ok(Some(
                Response::builder()
                    .status(StatusCode::OK)
                    .header("Content-Type", "application/octet-stream")
                    .header("Docker-Distribution-Api-Version", "registry/2.0")
                    .header("Docker-Content-Digest", digest)
                    .header("Content-Length", size.to_string())
                    .body(Body::from_stream(stream))
                    .expect("response build"),
            )),
            None => Ok(None),
        }
    }
}

fn error_response(status: StatusCode, msg: &str) -> Response {
    let code = match msg {
        "invalid repository name" => "NAME_INVALID",
        "invalid digest" => "DIGEST_INVALID",
        _ => "",
    };
    let code = if code.is_empty() {
        msg.to_uppercase().replace(' ', "_")
    } else {
        code.to_string()
    };

    Response::builder()
        .status(status)
        .header("Content-Type", "application/json")
        .body(Body::from(format!(
            r#"{{"errors":[{{"code":"{}","message":"{}"}}]}}"#,
            code, msg
        )))
        .expect("response build")
}
