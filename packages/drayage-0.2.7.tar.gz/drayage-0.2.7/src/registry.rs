#[derive(Debug, Clone)]
pub struct ParsedImage {
    pub registry_key: String,
    pub registry_host: String,
    pub repo: String,
}

/// Validate an OCI repository name after registry/default-library parsing.
///
/// This intentionally accepts a conservative subset of the distribution grammar:
/// lowercase alphanumeric path components separated by '/', with '.', '_' and
/// '-' allowed inside components. The goal is to keep the path safe for both
/// filesystem cache keys and upstream URL construction.
pub fn is_valid_repository(repo: &str) -> bool {
    if repo.is_empty() || repo.len() > 255 || repo.starts_with('/') || repo.ends_with('/') {
        return false;
    }

    repo.split('/').all(is_valid_repository_component)
}

fn is_valid_repository_component(component: &str) -> bool {
    if component.is_empty() || component == "." || component == ".." || component.contains("..") {
        return false;
    }

    let mut chars = component.chars();
    let Some(first) = chars.next() else {
        return false;
    };
    if !first.is_ascii_lowercase() && !first.is_ascii_digit() {
        return false;
    }

    let mut last = first;
    for ch in chars {
        if !ch.is_ascii_lowercase() && !ch.is_ascii_digit() && ch != '.' && ch != '_' && ch != '-' {
            return false;
        }
        last = ch;
    }

    last.is_ascii_lowercase() || last.is_ascii_digit()
}

/// Validate an OCI tag reference.
pub fn is_valid_tag(tag: &str) -> bool {
    if tag.is_empty() || tag.len() > 128 {
        return false;
    }

    !tag.chars()
        .any(|ch| ch == '/' || ch == '\\' || ch == '\0' || ch.is_control() || ch.is_whitespace())
}

/// Validate the only digest format drayage currently caches on disk.
pub fn is_valid_sha256_digest(digest: &str) -> bool {
    let Some(hex) = digest.strip_prefix("sha256:") else {
        return false;
    };
    hex.len() == 64 && hex.bytes().all(|b| b.is_ascii_hexdigit())
}

pub fn parse_image_name(name: &str, host_override: Option<&str>) -> ParsedImage {
    let parts: Vec<&str> = name.splitn(2, '/').collect();

    // If the first path component contains '.' or ':', it's an explicit registry prefix
    if parts.len() >= 2 && (parts[0].contains('.') || parts[0].contains(':')) {
        let host = parts[0];
        let repo = parts[1];
        let key = host.replace(['.', '-', ':'], "_");
        return ParsedImage {
            registry_key: key,
            registry_host: host.to_string(),
            repo: repo.to_string(),
        };
    }

    // If host_override is an external registry, use it (TLS transparent mode)
    if let Some(host) = host_override
        && is_external_registry(host)
    {
        let key = host.replace(['.', '-', ':'], "_");
        return ParsedImage {
            registry_key: key,
            registry_host: host.to_string(),
            repo: name.to_string(),
        };
    }

    // Default to docker.io; add "library/" prefix for single-component names
    let repo = if name.contains('/') {
        name.to_string()
    } else {
        format!("library/{}", name)
    };
    ParsedImage {
        registry_key: "docker_io".to_string(),
        registry_host: "docker.io".to_string(),
        repo,
    }
}

fn is_external_registry(host: &str) -> bool {
    host.contains('.')
        && !host.starts_with("10.")
        && !host.starts_with("192.168.")
        && !host.starts_with("172.")
        && !host.starts_with("127.")
        && !host.starts_with("localhost")
        && !host.contains(".local")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn explicit_registry_with_dot() {
        let img = parse_image_name("gcr.io/my-project/image", None);
        assert_eq!(img.registry_host, "gcr.io");
        assert_eq!(img.repo, "my-project/image");
        assert_eq!(img.registry_key, "gcr_io");
    }

    #[test]
    fn explicit_registry_with_port() {
        let img = parse_image_name("registry:5000/myimage", None);
        assert_eq!(img.registry_host, "registry:5000");
        assert_eq!(img.repo, "myimage");
        assert_eq!(img.registry_key, "registry_5000");
    }

    #[test]
    fn docker_library_image() {
        let img = parse_image_name("nginx", None);
        assert_eq!(img.registry_host, "docker.io");
        assert_eq!(img.repo, "library/nginx");
        assert_eq!(img.registry_key, "docker_io");
    }

    #[test]
    fn docker_user_repo() {
        let img = parse_image_name("user/repo", None);
        assert_eq!(img.registry_host, "docker.io");
        assert_eq!(img.repo, "user/repo");
        assert_eq!(img.registry_key, "docker_io");
    }

    #[test]
    fn external_host_override() {
        let img = parse_image_name("library/alpine", Some("ghcr.io"));
        assert_eq!(img.registry_host, "ghcr.io");
        assert_eq!(img.repo, "library/alpine");
        assert_eq!(img.registry_key, "ghcr_io");
    }

    #[test]
    fn local_host_override_10x() {
        let img = parse_image_name("image", Some("10.0.0.1"));
        assert_eq!(img.registry_host, "docker.io");
        assert_eq!(img.repo, "library/image");
        assert_eq!(img.registry_key, "docker_io");
    }

    #[test]
    fn local_host_override_192_168() {
        let img = parse_image_name("image", Some("192.168.1.1"));
        assert_eq!(img.registry_host, "docker.io");
        assert_eq!(img.repo, "library/image");
        assert_eq!(img.registry_key, "docker_io");
    }

    #[test]
    fn local_host_override_localhost() {
        let img = parse_image_name("image", Some("localhost:5000"));
        assert_eq!(img.registry_host, "docker.io");
        assert_eq!(img.repo, "library/image");
        assert_eq!(img.registry_key, "docker_io");
    }

    #[test]
    fn local_host_override_dot_local() {
        let img = parse_image_name("image", Some("registry.local"));
        assert_eq!(img.registry_host, "docker.io");
        assert_eq!(img.repo, "library/image");
        assert_eq!(img.registry_key, "docker_io");
    }

    #[test]
    fn key_sanitization_with_dashes() {
        let img = parse_image_name("registry-1.docker.io/library/alpine", None);
        assert_eq!(img.registry_key, "registry_1_docker_io");
    }

    #[test]
    fn no_host_override() {
        let img = parse_image_name("alpine", None);
        assert_eq!(img.registry_host, "docker.io");
        assert_eq!(img.repo, "library/alpine");
        assert_eq!(img.registry_key, "docker_io");
    }

    #[test]
    fn local_host_override_172x() {
        let img = parse_image_name("image", Some("172.16.0.1"));
        assert_eq!(img.registry_host, "docker.io");
        assert_eq!(img.repo, "library/image");
        assert_eq!(img.registry_key, "docker_io");
    }

    #[test]
    fn local_host_override_127x() {
        let img = parse_image_name("image", Some("127.0.0.1"));
        assert_eq!(img.registry_host, "docker.io");
        assert_eq!(img.repo, "library/image");
        assert_eq!(img.registry_key, "docker_io");
    }

    #[test]
    fn host_override_without_dot_falls_through() {
        // A host override without '.' is not considered external
        let img = parse_image_name("myimage", Some("intranet"));
        assert_eq!(img.registry_host, "docker.io");
        assert_eq!(img.repo, "library/myimage");
    }

    #[test]
    fn explicit_registry_with_port_and_dot() {
        let img = parse_image_name("my.registry.io:5000/project/image", None);
        assert_eq!(img.registry_host, "my.registry.io:5000");
        assert_eq!(img.repo, "project/image");
        assert_eq!(img.registry_key, "my_registry_io_5000");
    }

    #[test]
    fn host_override_with_port() {
        let img = parse_image_name("library/nginx", Some("ghcr.io:443"));
        assert_eq!(img.registry_host, "ghcr.io:443");
        assert_eq!(img.repo, "library/nginx");
        assert_eq!(img.registry_key, "ghcr_io_443");
    }

    #[test]
    fn explicit_registry_takes_precedence_over_override() {
        // When the name itself contains an explicit registry, host_override is ignored
        let img = parse_image_name("gcr.io/my-project/image", Some("ghcr.io"));
        assert_eq!(img.registry_host, "gcr.io");
        assert_eq!(img.repo, "my-project/image");
        assert_eq!(img.registry_key, "gcr_io");
    }

    #[test]
    fn deeply_nested_repo() {
        let img = parse_image_name("ghcr.io/org/sub/project/image", None);
        assert_eq!(img.registry_host, "ghcr.io");
        // splitn(2, '/') keeps everything after first '/' together
        assert_eq!(img.repo, "org/sub/project/image");
        assert_eq!(img.registry_key, "ghcr_io");
    }

    #[test]
    fn valid_repository_accepts_normal_names() {
        assert!(is_valid_repository("library/alpine"));
        assert!(is_valid_repository("org/sub-project/image_1"));
        assert!(is_valid_repository("distroless/static-debian12"));
    }

    #[test]
    fn valid_repository_rejects_path_traversal_and_invalid_chars() {
        assert!(!is_valid_repository("../secret"));
        assert!(!is_valid_repository("library/../secret"));
        assert!(!is_valid_repository("library//alpine"));
        assert!(!is_valid_repository("Library/alpine"));
        assert!(!is_valid_repository("library/alpine:latest"));
    }

    #[test]
    fn valid_tag_examples() {
        assert!(is_valid_tag("latest"));
        assert!(is_valid_tag("v1.2.3"));
        assert!(is_valid_tag("_build-123"));
        assert!(is_valid_tag(".INVALID_MANIFEST_NAME"));
    }

    #[test]
    fn invalid_tag_examples() {
        assert!(!is_valid_tag(""));
        assert!(!is_valid_tag("bad/tag"));
        assert!(!is_valid_tag("bad\\tag"));
        assert!(!is_valid_tag("bad tag"));
        assert!(!is_valid_tag(&"a".repeat(129)));
    }

    #[test]
    fn valid_sha256_digest_examples() {
        assert!(is_valid_sha256_digest(
            "sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
        ));
    }

    #[test]
    fn invalid_sha256_digest_examples() {
        assert!(!is_valid_sha256_digest("sha256:../secret"));
        assert!(!is_valid_sha256_digest(
            "sha512:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
        ));
        assert!(!is_valid_sha256_digest("sha256:short"));
        assert!(!is_valid_sha256_digest(
            "sha256:gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg"
        ));
    }

    #[test]
    fn valid_sha256_digest_accepts_uppercase_hex() {
        assert!(is_valid_sha256_digest(
            "sha256:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        ));
    }
}
