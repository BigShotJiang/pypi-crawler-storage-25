# Changelog

All notable changes to this project will be documented in this file.

The format is based on Keep a Changelog, and this project uses semantic
versioning while the public API is stabilizing.








## [0.2.7](https://github.com/rvben/drayage/compare/v0.2.6...v0.2.7) - 2026-04-09

### Fixed

- **release**: use GITHUB_TOKEN for GHCR verification ([4833307](https://github.com/rvben/drayage/commit/4833307dcb334e0c136ff09cc22e7106d88867d6))

## [0.2.6](https://github.com/rvben/drayage/compare/v0.2.5...v0.2.6) - 2026-04-09

### Fixed

- **release**: replace twine with pypa/gh-action-pypi-publish ([a430541](https://github.com/rvben/drayage/commit/a4305412431852d4fb2e6fe193bb43a278f94cd0))

## [0.2.5](https://github.com/rvben/drayage/compare/v0.2.4...v0.2.5) - 2026-04-09

### Fixed

- **release**: pin twine <6 to avoid license-file metadata rejection ([87e3177](https://github.com/rvben/drayage/commit/87e3177f1b87a850e84d734ba3d3b0fd975af1b0))

## [0.2.4](https://github.com/rvben/drayage/compare/v0.2.3...v0.2.4) - 2026-04-09

### Fixed

- **release**: download artifacts outside repo to avoid cargo publish dirty check ([3a4dbc5](https://github.com/rvben/drayage/commit/3a4dbc59c591e3fe45e725d05162365d6fd687f8))

## [0.2.3](https://github.com/rvben/drayage/compare/v0.2.2...v0.2.3) - 2026-04-08

### Fixed

- **release**: download only wheel and sdist artifacts in publish job ([6fa611f](https://github.com/rvben/drayage/commit/6fa611fc16e43c7bfc4f4a50378d7cf89054a630))

## [0.2.2](https://github.com/rvben/drayage/compare/v0.2.1...v0.2.2) - 2026-04-08

## [0.2.1](https://github.com/rvben/drayage/compare/v0.2.0...v0.2.1) - 2026-04-08

## Unreleased

## 0.2.0 - 2026-04-08

### Added

- Auth-scoped manifest/blob caching and negative-cache scoping.
- Validation for repository names, tags, and SHA-256 digest references.
- Manifest digest verification for upstream responses.
- Token-realm allowlisting and request timeouts for registry auth flows.
- Owner-only CA private key permissions on Unix.
- Built-in `drayage healthcheck` command for container health checks.
- Production deployment notes and example Docker Compose/systemd units.
- Reverse-proxy examples, upgrade guidance, troubleshooting notes, and a Linux
  `systemd` installer.
- Live upstream registry tests, OCI pull conformance automation, and nightly
  scheduled live validation workflows.
- Chaos coverage for disk pressure, upstream outages, and interrupted blob
  downloads.

### Changed

- The Docker image now runs as an unprivileged numeric user and declares a
  built-in readiness healthcheck.
- The container entrypoint now supports the Compose override pattern used in the
  published deployment example.
- Release metadata, install examples, and pinned image references now target
  `0.2.0`.

### Security

- Prevented authenticated cache entries from being served to unauthenticated
  clients.
- Prevented malformed digest/reference path traversal through cache paths.
- Restricted unconfigured upstream registry proxying.
