# Upgrade Guide

Drayage is a `0.x` release. Upgrade conservatively, pin exact versions, and
read release notes for any documented config or operational changes.

## Before You Upgrade

- Read the release notes and [CHANGELOG.md](../CHANGELOG.md).
- Back up:
  - `config.toml`
  - `ca.crt` and `ca.key` if using transparent TLS
- Treat the cache as disposable unless you specifically need warm-cache
  continuity.
- If the release changes auth, manifest handling, or blob streaming, run:

```bash
cargo test --test real_registry -- --ignored --test-threads=1
```

## Docker Compose Upgrade

1. Update the image tag in `deploy/docker-compose.yml` or set `DRAYAGE_IMAGE`.
2. Pull the new image:

```bash
docker compose -f deploy/docker-compose.yml pull
```

3. Restart the service:

```bash
docker compose -f deploy/docker-compose.yml up -d
```

4. Verify:

```bash
docker compose -f deploy/docker-compose.yml ps
curl -fsS http://127.0.0.1:5001/readyz
curl -fsS http://127.0.0.1:5001/stats
```

## systemd Upgrade

1. Build or fetch the new binary.
2. Stop Drayage:

```bash
sudo systemctl stop drayage
```

3. Replace the binary:

```bash
sudo install -m 0755 target/release/drayage /usr/local/bin/drayage
```

4. If the service file changed, reinstall it:

```bash
sudo install -m 0644 deploy/systemd/drayage.service /etc/systemd/system/drayage.service
sudo systemctl daemon-reload
```

5. Start and verify:

```bash
sudo systemctl start drayage
sudo systemctl status drayage
journalctl -u drayage -n 100 --no-pager
```

## Rollback

- For Compose: revert to the previous pinned image tag and redeploy.
- For systemd: reinstall the previous binary and restart the service.
- If the issue is cache-related, stopping Drayage and moving the cache
  directory aside is a safe fallback. Drayage will rebuild cache contents from
  upstream on demand.
