# Production Deployment Notes

Drayage is released for pull-through cache deployments, but the supported scope
is intentionally narrow. Use this checklist before running it in an environment
where untrusted clients, private upstream credentials, or critical pull paths
are involved.

## Recommended Deployment Model

Keep the deployment simple:

- Use [docker-compose.yml](../deploy/docker-compose.yml) for containerized installs.
- Use [drayage.service](../deploy/systemd/drayage.service) for host installs.
- Put Drayage on a trusted network segment.
- If you need access control, add a simple reverse proxy or network allowlist
  instead of building more orchestration around it.

Additional operator docs:

- [Reverse proxy examples](reverse-proxy.md)
- [Upgrade guide](upgrades.md)
- [Troubleshooting](troubleshooting.md)
- [OCI pull conformance](oci-conformance.md)

## Threat Model

- Treat the HTTP and TLS listeners as privileged infrastructure endpoints.
- Do not expose Drayage directly to the public internet.
- If `[upstreams.<name>].username` and `password` are configured, every client
  that can reach Drayage can potentially use those upstream pull permissions.
- If TLS transparent proxy mode is enabled, protect `ca.key` as a private CA
  key. Hosts that trust `ca.crt` trust certificates minted from that key.

## Minimum Production Checklist

- Restrict client access with firewall rules, network policy, a reverse proxy,
  VPN, or another access-control layer.
- Pin the container image to a version tag instead of `latest`.
- Run the container as a non-root user. The published image uses UID/GID
  `10001:10001`.
- Make the cache directory writable by UID/GID `10001:10001` for bind mounts.
- Set `max_cache_bytes` to a value that leaves headroom for the host.
- Monitor `/readyz`, `/metrics`, disk usage, and upstream error rates.
- Keep `ca.key` outside the cache directory and restrict it to the Drayage
  process user.
- Back up only the configuration and CA material. The cache itself should be
  treated as rebuildable.

## Docker Compose

Use `deploy/docker-compose.yml` as a hardened starting point:

```bash
mkdir -p cache
cp config.example.toml config.toml
docker compose -f deploy/docker-compose.yml up -d
```

On Linux bind mounts, ensure the cache path is writable by the image user:

```bash
sudo chown -R 10001:10001 cache
```

For transparent TLS mode in a non-root container, bind the host's port 443 to an
unprivileged container port:

```toml
tls_listen = "0.0.0.0:8443"
ca_cert_path = "/certs/ca.crt"
ca_key_path = "/certs/ca.key"
```

Then publish `443:8443` in Compose.

## Systemd

Use `deploy/systemd/drayage.service` as a starting point for package or
host-level installs:

```bash
sudo useradd --system --home /var/lib/drayage --shell /usr/sbin/nologin drayage
sudo install -d -m 0750 -o root -g drayage /etc/drayage
sudo install -d -m 0750 -o drayage -g drayage /var/cache/drayage
sudo install -m 0640 -o root -g drayage config.example.toml /etc/drayage/config.toml
sudo install -m 0644 deploy/systemd/drayage.service /etc/systemd/system/drayage.service
sudo systemctl daemon-reload
sudo systemctl enable --now drayage
```

Set `cache_dir = "/var/cache/drayage"` in `/etc/drayage/config.toml`.
If the config contains upstream credentials, keep `config.toml` group-readable
only by the `drayage` service account.

If you already built a release binary locally, you can use the helper:

```bash
cargo build --release
sudo bash scripts/install_systemd.sh
```

## Health Checks

The image includes:

```bash
drayage healthcheck --url http://127.0.0.1:5001/readyz --timeout-secs 2
```

It exits non-zero if the readiness endpoint is unreachable or returns a
non-success HTTP status.

## Operational Limits

- Drayage is a cache, not the source of truth. Cache loss should only cause
  upstream refetches.
- Tag pulls are revalidated according to `manifest_ttl_seconds`; digest pulls
  are immutable and should be preferred in critical workloads.
- Offline mode serves only already-cached content and should be tested before
  relying on it during upstream outages.
- Run `cargo test --test real_registry -- --ignored --test-threads=1` before a
  release that changes upstream authentication, manifest handling, or blob
  streaming behavior.
