# Reverse Proxy Examples

These examples are for the normal registry-mirror deployment model where
clients talk to a fixed Drayage hostname such as `drayage.example.internal`.

They are useful for:

- IP allowlisting
- HTTPS termination for the mirror endpoint
- Keeping Drayage itself on plain HTTP on `127.0.0.1:5001`

Do not put these HTTP reverse proxies in front of Drayage's transparent TLS
mode. Transparent TLS relies on the original SNI hostname reaching Drayage.
For transparent TLS deployments, use network-level ACLs or a TCP proxy that
preserves SNI.

## Caddy

Example file: [Caddyfile](../deploy/caddy/Caddyfile)

Use this when you want the simplest allowlisted HTTPS entrypoint:

```bash
caddy run --config deploy/caddy/Caddyfile
```

Adjust:

- `drayage.example.internal`
- the allowed CIDRs
- certificate settings if you do not want Caddy to manage TLS automatically

## Nginx

Example file: [drayage.conf](../deploy/nginx/drayage.conf)

Important settings:

- `proxy_request_buffering off`
- `proxy_buffering off`
- `client_max_body_size 0`
- preserve `Host` and `Authorization`

Those keep large blob responses streaming instead of forcing full buffering and
ensure upstream auth forwarding still works.

## Operational Guidance

- Prefer IP allowlisting, VPN, or a private network over per-request auth.
- If you proxy `/metrics`, either keep it private or protect it separately.
- Do not rewrite `/v2/...` paths.
- If Docker or containerd clients start seeing `502`, check proxy timeouts and
  request buffering first.
