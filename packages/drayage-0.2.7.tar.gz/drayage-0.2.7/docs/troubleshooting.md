# Troubleshooting

## First Checks

```bash
curl -fsS http://127.0.0.1:5001/readyz
curl -fsS http://127.0.0.1:5001/stats
curl -fsS http://127.0.0.1:5001/metrics | head
```

For container deployments:

```bash
docker compose -f deploy/docker-compose.yml logs --tail=200
```

For systemd deployments:

```bash
journalctl -u drayage -n 200 --no-pager
```

## `404` On Pull

Possible causes:

- The tag or digest does not exist upstream.
- The image is private and upstream denied access.
- `offline_mode = true` and the content was not already cached.
- The request used a malformed repository, tag, or digest.

Checks:

- Verify the exact image reference.
- Check whether the upstream registry requires auth.
- Confirm you are not testing in offline mode.

## `502` Upstream Error

Possible causes:

- Upstream registry outage or timeout.
- Token realm rejected by Drayage allowlisting.
- Circuit breaker opened after repeated failures.
- Cache write failed under disk pressure.
- Reverse proxy buffering or timeout misconfiguration.

Checks:

- Inspect Drayage logs for `upstream returned`, `circuit breaker`, or `insufficient disk space`.
- Check host free disk space.
- If a reverse proxy sits in front, disable request buffering and increase
  read/send timeouts.

## Cache Directory Permission Errors

The container image runs as UID/GID `10001:10001`.

For bind mounts:

```bash
sudo chown -R 10001:10001 cache
```

For systemd host installs, ensure `cache_dir` matches the path owned by the
`drayage` user, for example `/var/cache/drayage`.

## Transparent TLS Mode Not Working

Checks:

- `ca.crt` is installed in the Docker host trust store.
- DNS for the upstream registry points at Drayage.
- The requested registry hostname exists in `[upstreams]`.
- `ca.key` is readable only by the Drayage process user.

If you put an HTTP reverse proxy in front of transparent TLS mode, remove it.
Use direct TCP reachability or a TCP proxy that preserves SNI.

## Blob Downloads Fail Mid-Transfer

Checks:

- Drayage logs for upstream disconnects or retries.
- Reverse proxy buffering and timeouts.
- Host disk pressure.

Drayage cleans up temporary files after interrupted downloads, so retrying the
pull is safe.
