# OCI Distribution Conformance

Drayage currently implements pull-through cache behavior for OCI distribution
read paths. It does not implement registry push, delete, or tag-list APIs.

Because of that, the official OCI Distribution conformance suite is wired in
for the `Pull` workflow only.

## What Is Covered

- `GET /v2/`
- Pulling manifests by tag and digest
- Pulling blobs by digest
- HEAD/GET semantics exercised by the official pull workflow

## What Is Not Claimed

- Push conformance
- Content discovery conformance (`tags/list`)
- Content management conformance (delete flows)

## GitHub Workflows

The repo includes [oci-conformance.yml](../.github/workflows/oci-conformance.yml),
which can be run manually or reused from another workflow. It:

1. Builds Drayage from this repository.
2. Starts Drayage locally on `127.0.0.1:5001`.
3. Resolves a public pull fixture dynamically from `registry.k8s.io/pause:3.9`.
4. Runs the official OCI Distribution conformance action in pull-only mode.
5. Uploads `junit.xml` and `report.html` as workflow artifacts.

The fixture digests are resolved dynamically so the workflow does not depend on
hard-coded manifest or blob digests.

Periodic live validation is handled by
[live-validation.yml](../.github/workflows/live-validation.yml), which runs
nightly at `03:17` UTC and calls both:

- [real-registry.yml](../.github/workflows/real-registry.yml) for live pulls
  against public registries
- [oci-conformance.yml](../.github/workflows/oci-conformance.yml) for official
  OCI pull conformance

## Local Runner

Start Drayage separately, then run:

```bash
make test-oci-pull-conformance
```

Defaults:

- `OCI_ROOT_URL=http://127.0.0.1:5001`
- `OCI_NAMESPACE=registry.k8s.io/pause`
- `OCI_TAG_NAME=3.9`
- `OCI_CONFORMANCE_VERSION=v1.1.1`

The local runner requires:

- `git`
- `go`
- `python3`

Artifacts are written to `./oci-conformance-results` by default.

## Extending Coverage Later

If Drayage adds push or discovery APIs, the workflow can be extended by setting
the corresponding official environment variables:

- `OCI_TEST_PUSH=1`
- `OCI_TEST_CONTENT_DISCOVERY=1`
- `OCI_TEST_CONTENT_MANAGEMENT=1`
