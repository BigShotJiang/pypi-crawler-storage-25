# drayage

> Public `0.x` release. Scope is intentionally narrow: pull-through caching for
> trusted environments, with `docker compose` and `systemd` as the supported
> deployment targets.

OCI registry pull-through cache. Sits between Docker daemons and upstream registries, caching manifests and blobs to reduce external traffic and improve pull reliability.

## Features

- **Manifest and blob caching** with configurable TTL and size limits
- **Stale-while-revalidate** serves cached manifests immediately while refreshing in the background (30s backoff between attempts per image)
- **Request coalescing** deduplicates concurrent upstream fetches for the same resource
- **Circuit breaker** per upstream registry (trips after 5 consecutive failures, reopens after 30s)
- **Negative caching** for 404/403 responses with configurable TTL
- **TLS transparent proxy** with SNI-based per-hostname certificate generation from a local CA
- **Offline mode** serves only already-cached content, skipping all upstream fetches
- **Prometheus metrics** on `/metrics`
- **LRU cache eviction** with configurable size limits

## Install

```bash
# From PyPI (prebuilt wheels for Linux and macOS)
pip install drayage

# From crates.io
cargo install drayage

# Docker
docker pull ghcr.io/rvben/drayage:0.2.0
```

## Quick start

```bash
# Generate a config file
drayage init

# Create the cache directory
mkdir -p ./cache

# Start the server
drayage
```

## Docker daemon setup

Add drayage as a registry mirror in `/etc/docker/daemon.json`:

```json
{
  "registry-mirrors": ["http://<drayage-host>:5001"],
  "insecure-registries": ["<drayage-host>:5001"]
}
```

Restart Docker after editing `daemon.json`.

## Containerd setup

Generate containerd mirror `hosts.toml` files from your drayage config:

```bash
drayage init --containerd \
  --config ./config.toml \
  --containerd-dir /etc/containerd/certs.d \
  --drayage-url http://<drayage-host>:5001
```

This creates one directory per configured upstream (e.g. `docker.io/hosts.toml`, `ghcr.io/hosts.toml`) under the containerd certs directory. Each `hosts.toml` routes pulls through drayage with `["pull", "resolve"]` capabilities.

Restart containerd after generating the files. No `insecure-registries` configuration is needed.

## Usage

```
drayage                              # Run server with ./config.toml
drayage serve --config /etc/drayage/config.toml  # Custom config path
drayage serve --log-json             # Structured JSON log output
drayage init                         # Generate ./config.toml
drayage init --path /etc/drayage/config.toml     # Custom output path
drayage init --force                 # Overwrite existing config
drayage init --containerd --drayage-url http://10.0.0.1:5001  # Containerd mirrors
drayage gen-ca                       # Generate CA cert+key in ./certs/
drayage gen-ca --dir /etc/drayage/certs          # Custom output directory
drayage healthcheck                  # Check http://127.0.0.1:5001/readyz
```

## How it works

1. Docker daemon sends a pull request to drayage (`/v2/<repo>/manifests/<ref>` or `/v2/<repo>/blobs/<digest>`)
2. Drayage checks its filesystem cache
3. **Cache hit**: returns the cached response immediately
4. **Stale tag**: if a cached manifest by tag exceeds `manifest_ttl_seconds`, serves the stale version immediately and spawns a background revalidation (with 30s backoff per image to avoid hammering a failing upstream)
5. **Cache miss**: fetches from the upstream registry, caches the response, and returns it to the client
6. **Concurrent requests** for the same resource are coalesced into a single upstream fetch
7. **Circuit breaker**: after 5 consecutive failures to an upstream registry, requests fail fast for 30s before allowing a probe request

## Production deployment

Drayage should be treated as infrastructure running inside a trusted network.
If upstream credentials are configured, restrict access to the Drayage listener
with firewall rules, network policy, a reverse proxy, VPN, or another access
control layer.

- Recommended complexity level: `docker compose` for container deployments,
  `systemd` for host installs, and network ACLs or a simple reverse proxy for
  access control.
- Avoid adding Helm unless Kubernetes is your primary target environment.

- See [production notes](docs/production.md) for the deployment checklist.
- See [OCI conformance notes](docs/oci-conformance.md) for the official pull
  conformance workflow and local runner.
- See [Docker Compose example](deploy/docker-compose.yml) for a hardened
  container baseline.
- See [systemd unit example](deploy/systemd/drayage.service) for host installs.
- See [reverse-proxy examples](docs/reverse-proxy.md) for Caddy and Nginx.
- See [upgrade guide](docs/upgrades.md) for pinned-image and systemd upgrades.
- See [troubleshooting](docs/troubleshooting.md) for common operational failures.
- See [systemd installer](scripts/install_systemd.sh) for a simple Linux install path.

The published Docker image runs as UID/GID `10001:10001`. Bind-mounted cache
directories must be writable by that user.

## Configuration

All fields with defaults can be omitted. Generate a starter config with `drayage init`.

| Field | Default | Description |
|-------|---------|-------------|
| `listen` | *(required)* | HTTP listen address (e.g. `0.0.0.0:5001`) |
| `cache_dir` | *(required)* | Filesystem path for cached manifests and blobs |
| `manifest_ttl_seconds` | `900` | How long cached manifests are considered fresh |
| `max_cache_bytes` | *unlimited* | Maximum blob cache size in bytes. `0` or unset = unlimited |
| `eviction_interval_seconds` | `300` | How often to run LRU eviction (seconds) |
| `connect_timeout_secs` | `10` | Global upstream connect timeout (seconds) |
| `read_timeout_secs` | `30` | Global upstream read timeout (seconds) |
| `max_manifest_bytes` | `10485760` | Reject manifests larger than this (bytes). `0` = unlimited |
| `negative_ttl_seconds` | `60` | How long 404/403 responses are cached. `0` disables negative caching |
| `offline_mode` | `false` | Serve only already-cached content and skip upstream fetches |
| `tls_listen` | *disabled* | TLS proxy listen address (e.g. `0.0.0.0:443`) |
| `ca_cert_path` | *disabled* | Path to CA certificate for TLS proxy |
| `ca_key_path` | *disabled* | Path to CA private key for TLS proxy |

### Upstream registries

Upstream registries are configured under `[upstreams.<key>]`. The key is the registry hostname with `.` and `-` replaced by `_`:

```toml
[upstreams.docker_io]
registry = "https://registry-1.docker.io"
# username = ""
# password = ""
# connect_timeout_secs = 15   # Per-upstream override
# read_timeout_secs = 120     # Per-upstream override

[upstreams.registry_k8s_io]
registry = "https://registry.k8s.io"
```

### Offline mode

When `offline_mode = true`, drayage serves only from cache and never contacts upstream registries. Useful during upstream outages or for air-gapped environments with a pre-warmed cache.

Requests for uncached content return `502`. Background revalidation is disabled. To pre-warm the cache, run with `offline_mode = false` first and pull the images you need.

### TLS transparent proxy

The TLS transparent proxy lets Docker daemons pull through drayage without any `registry-mirrors` or `insecure-registries` configuration. Docker thinks it's talking directly to `registry-1.docker.io`, `ghcr.io`, etc., but DNS resolves those hostnames to drayage, which terminates TLS, serves from cache or fetches upstream, and returns the response.

This works because drayage reads the SNI hostname from the TLS handshake, generates a certificate for that hostname on the fly (signed by a local CA), and routes the request to the correct upstream registry.

#### Step 1: Generate a CA

```bash
drayage gen-ca --dir /etc/drayage/certs
```

This creates `ca.crt` and `ca.key` in the specified directory.

#### Step 2: Configure drayage

Add the TLS fields to your `config.toml`:

```toml
tls_listen = "0.0.0.0:443"
ca_cert_path = "/etc/drayage/certs/ca.crt"
ca_key_path = "/etc/drayage/certs/ca.key"
```

All three fields must be set together. Drayage will listen on both the HTTP port (for `registry-mirrors` mode) and the TLS port simultaneously.

#### Step 3: Point DNS to drayage

Configure your DNS server (Pi-hole, CoreDNS, dnsmasq, etc.) to resolve upstream registry hostnames to drayage's IP address. For example, in Pi-hole add Local DNS records:

```
registry-1.docker.io  → <drayage-ip>
ghcr.io               → <drayage-ip>
gcr.io                → <drayage-ip>
quay.io               → <drayage-ip>
registry.k8s.io       → <drayage-ip>
```

Only add entries for registries you have configured in `[upstreams]`. Drayage rejects SNI hostnames that don't match a configured upstream.

#### Step 4: Install the CA on Docker hosts

Copy `ca.crt` to each Docker host and add it to the system trust store:

```bash
# Debian/Ubuntu
sudo cp ca.crt /usr/local/share/ca-certificates/drayage-ca.crt
sudo update-ca-certificates

# RHEL/CentOS/Fedora
sudo cp ca.crt /etc/pki/ca-trust/source/anchors/drayage-ca.crt
sudo update-ca-trust
```

Restart Docker after updating the trust store. No changes to `daemon.json` are needed for the TLS mode.

## Endpoints

| Endpoint | Description |
|----------|-------------|
| `GET /v2/` | OCI distribution version check |
| `GET /v2/<name>/manifests/<ref>` | Pull manifest by tag or digest |
| `GET /v2/<name>/blobs/<digest>` | Pull blob by digest |
| `GET /health` | Always returns `200 OK` |
| `GET /healthz` | Always returns `200 OK` |
| `GET /readyz` | Returns `200 OK` when the cache directory is accessible |
| `GET /metrics` | Prometheus metrics |
| `GET /stats` | Cache statistics (manifest/blob counts, total size) |

## Metrics

All metrics use the `drayage_` prefix.

### Counters

| Metric | Description |
|--------|-------------|
| `drayage_blob_cache_hits_total` | Blob requests served from cache |
| `drayage_blob_cache_misses_total` | Blob requests that required upstream fetch |
| `drayage_manifest_cache_hits_total` | Manifest requests served from cache |
| `drayage_manifest_cache_misses_total` | Manifest requests that required upstream fetch |
| `drayage_manifest_stale_revalidates_total` | Manifests served stale while revalidating |
| `drayage_upstream_fetches_total` | Total upstream registry fetches |
| `drayage_coalesce_joined_total` | Requests that joined an existing inflight fetch |
| `drayage_token_cache_hits_total` | Bearer token requests served from cache |
| `drayage_digest_mismatches_total` | Blob downloads with digest verification failure |
| `drayage_auth_token_refreshes_total` | Stale bearer tokens evicted and re-fetched |
| `drayage_upstream_bytes_total` | Total bytes fetched from upstream registries |
| `drayage_eviction_runs_total` | Number of cache eviction runs |
| `drayage_blobs_evicted_total` | Number of blobs evicted from cache |
| `drayage_bytes_freed_total` | Total bytes freed by cache eviction |
| `drayage_circuit_breaker_trips_total` | Circuit breaker trips per registry |
| `drayage_manifest_size_rejected_total` | Manifests rejected for exceeding size limit |
| `drayage_manifest_revalidation_failures_total` | Background revalidation failures |

### Histograms

| Metric | Labels | Description |
|--------|--------|-------------|
| `drayage_upstream_manifest_duration_seconds` | `registry` | Upstream manifest fetch latency |
| `drayage_upstream_blob_duration_seconds` | `registry` | Upstream blob fetch latency |

## License

MIT
