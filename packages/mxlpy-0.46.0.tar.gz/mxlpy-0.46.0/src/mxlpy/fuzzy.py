"""Fuzzy / bayesian fitting methods."""

from __future__ import annotations

import multiprocessing
from concurrent.futures import TimeoutError as FuturesTimeoutError
from dataclasses import dataclass, field
from functools import partial
from math import ceil
from typing import TYPE_CHECKING, Self

import numpy as np
import pandas as pd
from loky import ProcessPoolExecutor
from tqdm import tqdm, trange

from mxlpy.simulation import Simulation
from mxlpy.simulator import Simulator

if TYPE_CHECKING:
    from collections.abc import Iterable

    from mxlpy import Model

__all__ = [
    "ThompsonState",
    "thompson_sampling",
]


@dataclass
class ThompsonState:
    """State of thompson sampling."""

    rng: np.random.Generator = field(default_factory=np.random.default_rng)
    state: dict[str, pd.DataFrame] = field(default_factory=dict)

    @classmethod
    def from_parameter_values(cls, parameters: dict[str, Iterable[float]]) -> Self:
        """Create state from parameter values.

        Parameters
        ----------
        parameters
            Mapping of parameter names to iterables of candidate values.

        """
        return cls(
            state={
                k: pd.DataFrame(
                    {
                        "x": v,
                        "success": np.ones_like(v, dtype=int),
                        "fail": np.ones_like(v, dtype=int),
                    }
                )
                for k, v in parameters.items()
            },
        )

    def sample(self) -> tuple[dict[str, int], dict[str, float]]:
        """Sample idxs and parameters."""
        idxs = {
            k: int(np.argmax(self.rng.beta(v["success"], v["fail"])))
            for k, v in self.state.items()
        }
        parameters = {k: v["x"][idxs[k]] for k, v in self.state.items()}
        return idxs, parameters

    def update(
        self,
        idxs: dict[str, int],
        pred: pd.DataFrame | None,
        data: pd.DataFrame,
        rtol: float,
    ) -> None:
        """Update state based on prediction accuracy.

        Parameters
        ----------
        idxs
            Mapping of parameter names to sampled indices.
        pred
            Predicted variables DataFrame, or None if simulation failed.
        data
            Observed data to compare against.
        rtol
            Tolerance for accepting a prediction as successful.

        """
        accept: bool = (
            False if pred is None else np.sqrt(np.mean(np.square(pred - data))) < rtol
        )
        for k, v in self.state.items():
            v.loc[idxs[k], "success" if accept else "fail"] += 1  # type: ignore


def _thompson_worker(
    inp: tuple[dict[str, int], dict[str, float]],
    model: Model,
    data: pd.DataFrame,
) -> tuple[dict[str, int], pd.DataFrame | None]:
    idxs, parameters = inp
    res = (
        Simulator(model)
        .update_parameters(parameters)
        .simulate_time_course(data.index)
        .get_result()
    )
    match val := res.value:
        case Simulation():
            return idxs, val.get_variables()
        case _:
            return idxs, None


def thompson_sampling(
    model: Model,
    data: pd.DataFrame,
    state: ThompsonState,
    rtol: float,
    n: int,
    *,
    max_workers: int | None = None,
    disable_tqdm: bool = False,
    timeout: float | None = None,
    parallel: bool = True,
) -> ThompsonState:
    """Perform thompson sampling.

    Parameters
    ----------
    model
        Model to fit.
    data
        Observed data to fit against.
    state
        Current Thompson sampling state.
    rtol
        Tolerance for accepting a prediction as successful.
    n
        Number of sampling iterations.
    max_workers
        Maximum number of worker processes. If None, uses all available CPUs.
    disable_tqdm
        Whether to disable the progress bar.
    timeout
        Maximum time in seconds per worker. If None, no timeout.
    parallel
        Whether to execute in parallel.

    """
    max_workers = multiprocessing.cpu_count() if max_workers is None else max_workers
    worker = partial(_thompson_worker, model=model, data=data)

    if not parallel:
        for _ in trange(n):
            idxs, pred = worker(state.sample())
            state.update(idxs, pred, data=data, rtol=rtol)
    else:
        # FIXME: think about whether this is ok to do. Thompson sampling is state-
        # dependent. We are breaking up that state a bit by chunking the approach
        # Is that fine to do?
        pool = ProcessPoolExecutor(max_workers=max_workers)
        with tqdm(total=n, disable=disable_tqdm) as pbar:
            try:
                for _ in range(ceil(n / max_workers)):
                    futures = [
                        pool.submit(worker, state.sample()) for _ in range(max_workers)
                    ]
                    for future in futures:
                        try:
                            idxs, pred = future.result(timeout=timeout)
                            state.update(idxs, pred, data=data, rtol=rtol)
                            pbar.update(1)
                        except FuturesTimeoutError:
                            future.cancel()
                            pbar.update(1)
            finally:
                pool.shutdown(wait=False, kill_workers=True)
    return state
