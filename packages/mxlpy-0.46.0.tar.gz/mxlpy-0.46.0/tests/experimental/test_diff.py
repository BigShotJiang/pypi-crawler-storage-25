def test_model_diff() -> None:
    # FIXME: implement this
    assert True


def test_soft_eq() -> None:
    # FIXME: implement this
    assert True
