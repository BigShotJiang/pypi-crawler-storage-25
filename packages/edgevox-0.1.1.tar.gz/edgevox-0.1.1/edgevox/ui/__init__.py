"""TUI frontend."""
