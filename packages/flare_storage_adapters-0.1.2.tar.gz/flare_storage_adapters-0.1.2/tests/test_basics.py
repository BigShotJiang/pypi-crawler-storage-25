from __future__ import annotations

import flare_storage_adapters


def test_package_smoke_imports() -> None:
    assert flare_storage_adapters.__name__ == "flare_storage_adapters"


def test_package_docstring_is_stable() -> None:
    assert flare_storage_adapters.__doc__ == "FLARE storage adapters package."
