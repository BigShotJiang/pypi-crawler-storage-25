# flare-storage-adapters

数据与存储适配层。

## 架构边界文档

1. `docs/ADAPTER-BOUNDARY.md`（SSOT）
2. `docs/ADAPTER-UPLOAD-CONTEXT-MEMORY-BOUNDARY.md`（引用型）
3. `docs/CAPABILITY-INVENTORY.md`

当前标准后端：

1. PostgreSQL
2. Qdrant
3. Redis

后续支持通过 adapter 扩展，不改 kernel 主逻辑。

## 最小发布说明

1. 当前包版本：`0.1.0`
2. 发布元数据：`packages/flare-storage-adapters/pyproject.toml`
3. 本地构建：`python -m build`
4. 本地安装：`pip install packages/flare-storage-adapters`
5. 当前只提供可发布骨架，后续 adapter 实现再逐步补齐。
