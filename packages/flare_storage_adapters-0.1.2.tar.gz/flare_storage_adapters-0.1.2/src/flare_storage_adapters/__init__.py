"""FLARE storage adapters package."""
