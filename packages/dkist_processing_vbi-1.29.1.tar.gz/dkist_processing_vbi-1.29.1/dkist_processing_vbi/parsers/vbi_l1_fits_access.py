"""VBI FITS access for L1 data."""

import numpy as np
from astropy.io import fits
from dkist_processing_common.parsers.l1_fits_access import L1FitsAccess

from dkist_processing_vbi.models.fits_access import VbiMetadataKey


class VbiL1FitsAccess(L1FitsAccess):
    """
    Class to provide easy access to L1 headers.

    i.e. instead of <VbiL1FitsAccess>.header['key'] this class lets us use <VbiL1FitsAccess>.key instead

    Parameters
    ----------
    header
        The header from which to parse higher-level properties

    data
        A data array to associate with the current instance

    name
        The name of the file that was loaded into this FitsAccess object

    auto_squeeze
        When set to True, dimensions of length 1 will be removed from the array
    """

    def __init__(
        self,
        *,
        header: fits.Header,
        data: np.ndarray | None = None,
        name: str | None = None,
        auto_squeeze: bool = True,
    ):
        super().__init__(header=header, data=data, name=name, auto_squeeze=auto_squeeze)

        self.number_of_spatial_steps: int = self.header.get(VbiMetadataKey.number_of_spatial_steps)
        self.current_spatial_step: int = self.header.get(VbiMetadataKey.current_spatial_step)
