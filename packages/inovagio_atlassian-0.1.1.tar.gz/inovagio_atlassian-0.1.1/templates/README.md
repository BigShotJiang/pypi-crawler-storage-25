# atlassiancli — Templates

Copy-deployable configuration kits that complement the `atlassiancli` engine.

## Why this directory exists

`atlassiancli` is the **engine** — a zero-runtime-dep Python 3.12+ CLI that
exposes a stable JSON / exit-code contract for Jira and Confluence operations.
On its own, the engine answers *"how do I drive Atlassian from a script or an
agent?"* It does not answer *"how do I wire a real autonomous-development
workflow into my repository?"* That is what `templates/` is for.

Each subdirectory in `templates/` is a **drop-in kit** — a self-contained set
of files (agent prompts, SOPs, pre-commit config, IDE settings, doc
skeletons) that a consuming project can copy into its own repo and customise.
The kits assume `atlassiancli` is installed as the underlying CLI; they
reference its subcommands by name and rely on its JSON / exit-code contract.

## Quick start

Pick the kit you want, copy it into your project, fill in the placeholders,
install pre-commit hooks. For the autonomous-dev-system kit:

```bash
# from the root of your project
cp -R /path/to/atlassiancli/templates/autonomous-dev-system/. .
# review templates/autonomous-dev-system/INSTALL.md for the full walkthrough
```

Every kit ships with its own `README.md` (what's in it, who it's for) and
`INSTALL.md` (the copy-deploy walkthrough plus customisation checklist).

## Available kits

| Kit                              | Purpose                                                                                       |
| -------------------------------- | --------------------------------------------------------------------------------------------- |
| `autonomous-dev-system/`         | DevCycle agent prompts + SOP skeletons + pre-commit hooks + VS Code config for AI-driven, ticket-to-PR autonomous development. |

More kits may be added over time (e.g. release-management, security-only,
docs-only). Each kit is independent — you can adopt any subset.

## Conventions used across all kits

- **Placeholders use angle brackets**: `<PROJECT_NAME>`, `<JIRA_PROJECT_KEY>`,
  `<your-site>`, `<CONFLUENCE_SPACE>`, `<LANGUAGE_STACK>`. Search-and-replace
  these once you copy a kit into your project.
- **Files ending in `.template`** are skeletons — copy them to the same path
  without the `.template` suffix and fill in the bracketed sections.
- **Files ending in `.example`** are sample configs — copy them to the same
  path without the `.example` suffix and substitute real values.
- **CLI references are by subcommand name**, e.g. `atlassiancli analyse
  ready <KEY>`. Every command cited in a template exists in
  `src/atlassiancli/cli/main.py`.

## Packaging note

The `templates/` directory ships in the **source distribution** (sdist) so it
is browsable on GitHub and present after `pip download --no-binary` /
`pip install --no-binary`, but is **excluded from the built wheel** —
templates are repository assets, not Python runtime code, and have no place
in `site-packages`.

See `MANIFEST.in` for the inclusion rules and the wheel's `pyproject.toml`
`[tool.setuptools.packages.find]` block for the wheel-side exclusion.

## Contributing a new kit

1. Open an issue describing the gap (what workflow does the kit enable?).
2. Stand up the kit under `templates/<kit-name>/` with at minimum a
   `README.md` and an `INSTALL.md`.
3. Follow the placeholder conventions above.
4. Make every CLI invocation cite an actual `atlassiancli` subcommand.
5. Open a PR.
