#!/usr/bin/env bash
#
# sop-story-check.sh — Phase 2 SOP story-time review. Delegates to the
# atlassiancli engine, which reads sops/sop-manifest.yaml, fetches the
# story description from Jira, and verifies every required section is
# present.
#
# Usage:
#   ./scripts/sop-story-check.sh <ISSUE_KEY>
#   ./scripts/sop-story-check.sh <ISSUE_KEY> --manifest <path>
#   ./scripts/sop-story-check.sh <ISSUE_KEY> --json
#
# Wiring:
#   - DevCycle Phase 2 calls this after `analyze ready`.
#   - Exit code 0 = story READY against SOPs; 1 = NOT_READY; 2 = error.
#
# Environment:
#   ATLASSIAN_URL / ATLASSIAN_EMAIL / ATLASSIAN_API_TOKEN must be set.

set -euo pipefail

if [[ $# -lt 1 ]]; then
    echo "usage: sop-story-check.sh <ISSUE_KEY> [--manifest <path>] [--json]" >&2
    exit 2
fi

ISSUE_KEY="$1"
shift

MANIFEST="sops/sop-manifest.yaml"
EMIT_JSON=0

while [[ $# -gt 0 ]]; do
    case "$1" in
        --manifest) MANIFEST="$2"; shift 2 ;;
        --json) EMIT_JSON=1; shift ;;
        *)
            echo "unknown arg: $1" >&2
            exit 2
            ;;
    esac
done

if ! command -v atlassiancli >/dev/null 2>&1; then
    echo "sop-story-check: atlassiancli not on PATH" >&2
    echo "  install with: pip install inovagio-atlassian" >&2
    exit 2
fi

if [[ ! -f "$MANIFEST" ]]; then
    echo "sop-story-check: manifest not found at $MANIFEST" >&2
    exit 2
fi

if [[ "$EMIT_JSON" -eq 1 ]]; then
    response=$(atlassiancli --json analyze sop "$ISSUE_KEY" --manifest "$MANIFEST")
    echo "$response"
    verdict=$(echo "$response" | python3 -c "import json,sys; print(json.load(sys.stdin).get('verdict',''))")
else
    atlassiancli analyze sop "$ISSUE_KEY" --manifest "$MANIFEST"
    verdict_response=$(atlassiancli --json analyze sop "$ISSUE_KEY" --manifest "$MANIFEST")
    verdict=$(echo "$verdict_response" | python3 -c "import json,sys; print(json.load(sys.stdin).get('verdict',''))")
fi

case "$verdict" in
    READY) exit 0 ;;
    NOT_READY) exit 1 ;;
    *) exit 2 ;;
esac
