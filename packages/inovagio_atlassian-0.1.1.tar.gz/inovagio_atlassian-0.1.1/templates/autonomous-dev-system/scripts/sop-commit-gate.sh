#!/usr/bin/env bash
#
# sop-commit-gate.sh — Phase 6 / pre-commit blocking gate for the autonomous
# development system. Delegates to the atlassiancli engine, which reads
# sops/sop-manifest.yaml, runs every `phase: commit` rule, and exits non-zero
# if any blocking rule fires.
#
# Usage:
#   ./scripts/sop-commit-gate.sh                    # gate the staged diff
#   ./scripts/sop-commit-gate.sh --self-test        # validate the manifest itself
#   ./scripts/sop-commit-gate.sh --json             # machine-readable output
#   ./scripts/sop-commit-gate.sh --manifest <path>  # use a non-default manifest
#
# Wiring:
#   - .pre-commit-config.yaml entry calls this script.
#   - DevCycle Phase 6 calls this script and reads exit code + JSON output.
#
# Exit codes:
#   0   no blocking findings
#   1   one or more blocking rules fired
#   2   manifest missing / unparseable / atlassiancli not on PATH

set -euo pipefail

MANIFEST="sops/sop-manifest.yaml"
EMIT_JSON=0
SELF_TEST=0

while [[ $# -gt 0 ]]; do
    case "$1" in
        --manifest) MANIFEST="$2"; shift 2 ;;
        --json) EMIT_JSON=1; shift ;;
        --self-test) SELF_TEST=1; shift ;;
        -h|--help)
            sed -n '2,20p' "$0"
            exit 0
            ;;
        *)
            echo "unknown arg: $1" >&2
            exit 2
            ;;
    esac
done

if ! command -v atlassiancli >/dev/null 2>&1; then
    echo "sop-commit-gate: atlassiancli not on PATH" >&2
    echo "  install with: pip install inovagio-atlassian" >&2
    exit 2
fi

if [[ ! -f "$MANIFEST" ]]; then
    echo "sop-commit-gate: manifest not found at $MANIFEST" >&2
    exit 2
fi

if [[ "$SELF_TEST" -eq 1 ]]; then
    if [[ "$EMIT_JSON" -eq 1 ]]; then
        atlassiancli --json framework sop-validate-manifest --manifest "$MANIFEST"
    else
        atlassiancli framework sop-validate-manifest --manifest "$MANIFEST"
    fi
    exit $?
fi

if [[ "$EMIT_JSON" -eq 1 ]]; then
    atlassiancli --json framework sop-commit-gate --manifest "$MANIFEST"
else
    atlassiancli framework sop-commit-gate --manifest "$MANIFEST"
fi
exit $?
