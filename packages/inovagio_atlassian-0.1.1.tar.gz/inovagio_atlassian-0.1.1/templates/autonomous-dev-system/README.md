# autonomous-dev-system kit

A copy-deployable configuration kit that turns a project into an
**AI-driven autonomous-development workflow** — a Jira ticket goes in, a
reviewable pull request comes out, with three layers of quality enforcement
(pre-commit hooks, agent SOPs, CI gates) defending the trunk.

The kit is engine-agnostic: bring your own AI coding agent
(GitHub Copilot agent mode, Claude Code, Cursor, etc.) and your own CI. The
moving parts the kit provides are configuration files, agent prompts, and
SOP skeletons — they wire the engine `atlassiancli` into a real flow.

## 1. What this template provides

End-to-end scaffolding for the autonomous-dev system documented in the
operator how-to:

- **DevCycle agent prompt** — an enforced 8-phase state machine that an AI
  agent reads on `@devcycle` invocation. Phases: `init → fetch-jira →
  prepare-story → mark-in-progress → implement → test → review → fix → pr`.
- **Thinking-beast-mode escalation prompt** — deep root-cause analysis when
  Phase 7 exhausts retries.
- **Six machine-enforced SOPs** the agent must satisfy at story-time
  (Phase 2) and at commit-time (Phase 6 / pre-commit). Each ships as a
  fillable `.template` plus an entry in `sops/sop-manifest.yaml` mapping
  the SOP to greps, regexes, and shell checks the gate scripts run:
  - **01-architecture** — layer / bounded-context / interface-first / no
    upward imports.
  - **02-security** — no secrets in source, no hand-rolled crypto, authz
    + audit at every boundary, PII redaction, SCA scanning.
  - **03-code-quality** — zero warnings, zero linter findings, formatter
    clean, no silent failures, no dead code.
  - **04-testing** — coverage floor, sanitiser-clean, no flakes, failure-
    mode tests required.
  - **05-logging** — structured-only, correlation IDs, sensitive-field
    deny-list.
  - **06-monitoring** — every public op has metrics, bounded label
    cardinality, alerts have runbooks, dashboards-as-code.
- **Two long-form SOPs** for context the agent reads but doesn't grep:
  - Architecture overview (`docs/architecture/ARCHITECTURE.md`)
  - Security architecture (`docs/architecture/SECURITY.md`)
  - Plus `data_handling.md`, `ai_safety.md`, `story_authoring.md`.
- **Pre-commit hooks** — multi-language quality gates (Python, .NET, React,
  plus universal sanity + secrets scanning + Conventional Commits).
- **VS Code config** — MCP servers (Atlassian + GitHub), DevCycle config,
  workspace settings.
- **Story-authoring guide** — how humans write stories that AI agents can
  actually implement.

## 2. Audience

- Engineering teams adopting **AI-driven autonomous development**.
- Teams whose backlog is in Jira, whose docs are in Confluence, whose code
  is on GitHub, and whose PR review is partly or fully agent-assisted.
- Teams who want their agent to self-enforce a Definition of Ready, a
  Definition of Done, and an architecture-and-security SOP — *without*
  hand-rolling the prompts.

If your stack is "no Jira" or "no GitHub" or "agents banned by policy," this
kit is not for you. The atlassiancli engine itself may still be useful to
you, but this configuration kit assumes the full Atlassian + GitHub +
agent-mode triad.

## 3. How it works

```
human  ───►  Jira story (DoR-clean)
                │
                ▼
        @devcycle <KEY>          ◄──── reads .github/prompts/devcycle.prompt.md
                │
                ▼
   ┌────────────┼─────────────┐
   │ Phase 0–8 state machine │   ◄──── reads .vscode/devcycle-config.json
   └────────────┼─────────────┘
                │  shells out to
                ▼
          atlassiancli            ◄──── stable JSON + exit-code contract
                │
                ▼
   ┌──────────────────────────┐
   │ pre-commit hooks         │   ◄──── .pre-commit-config.yaml
   │ SOP enforcement          │   ◄──── docs/architecture/*.md
   │ CI gates (pytest etc.)   │
   └──────────────────────────┘
                │
                ▼
            GitHub PR              ◄──── opened via `gh pr create`
                │
                ▼
       Copilot review          ◄──── auto-requested in Phase 6
                │
                ▼
            Phase 7 fix loop  ◄──── max 3 iterations, then beast mode
                │
                ▼
       Jira story → Done       ◄──── transitioned via `atlassiancli transition`
```

Three quality layers defend the trunk:

1. **Local** — pre-commit hooks block obviously bad commits.
2. **Agent SOP** — the DevCycle prompt forces the agent to satisfy the three
   SOPs before opening a PR.
3. **CI / SonarQube / Copilot review** — runs after the PR opens.

## 4. Manifest — every file in this kit

| File                                                         | Purpose                                                    |
| ------------------------------------------------------------ | ---------------------------------------------------------- |
| `README.md`                                                  | This document.                                             |
| `INSTALL.md`                                                  | Step-by-step copy-deploy walkthrough.                      |
| `.github/copilot-instructions.md`                             | Code Quality + Testing SOP (multi-language baseline).      |
| `.github/prompts/devcycle.prompt.md`                          | The DevCycle 8-phase agent system prompt.                  |
| `.github/prompts/thinking-beast-mode.prompt.md`               | Escalation handoff agent prompt.                           |
| `.vscode/mcp.json`                                            | Atlassian + GitHub MCP server config.                      |
| `.vscode/devcycle-config.json`                                | Project-specific DevCycle config (Jira URL, language stack, etc.). |
| `.vscode/settings.json`                                       | Workspace settings (Copilot agent mode, format-on-save).   |
| `.pre-commit-config.yaml`                                     | Multi-language pre-commit hooks.                           |
| `.editorconfig`                                               | Cross-language formatting baseline.                        |
| `sonar-project.properties.example`                            | SonarQube project config (rename + customise on copy).     |
| `docs/architecture/ARCHITECTURE.md.template`                  | Architecture overview (long-form prose).                   |
| `docs/architecture/SECURITY.md.template`                      | Security architecture (long-form prose).                   |
| `docs/architecture/data_handling.md.template`                 | PHI / PII data classification + flow.                      |
| `docs/architecture/ai_safety.md.template`                     | AI safety / prompt safety / eval skeleton.                 |
| `docs/architecture/story_authoring.md.template`               | AI-implementable story authoring guide.                    |
| `sops/01-architecture.sop.md.template`                        | Machine-enforced architecture SOP (Phase 2 + Phase 6).     |
| `sops/02-security.sop.md.template`                            | Machine-enforced security SOP (Phase 2 + Phase 6).         |
| `sops/03-code-quality.sop.md.template`                        | Machine-enforced code-quality SOP (Phase 2 + Phase 6).     |
| `sops/04-testing.sop.md.template`                             | Machine-enforced testing SOP (Phase 2 + Phase 6).          |
| `sops/05-logging.sop.md.template`                             | Machine-enforced logging SOP (Phase 2 + Phase 6).          |
| `sops/06-monitoring.sop.md.template`                          | Machine-enforced monitoring SOP (Phase 2 + Phase 6).       |
| `sops/sop-manifest.yaml`                                      | Authoritative manifest binding SOPs to greps + regex + shell rules. |
| `scripts/sop-story-check.sh`                                  | Phase 2 wrapper — verifies story has every required section. |
| `scripts/sop-commit-gate.sh`                                  | Phase 6 / pre-commit gate — runs commit-time SOP rules; blocks the commit on violations. |

## 5. Customisation points

Every file in this kit is intentionally **project-agnostic**. To make it
yours, replace these placeholders (search-and-replace across the copied
tree):

| Placeholder          | Replace with                                                  |
| -------------------- | ------------------------------------------------------------- |
| `<PROJECT_NAME>`     | Your project / monorepo name.                                 |
| `<JIRA_PROJECT_KEY>` | The Jira project key, e.g. `ACME`.                            |
| `<your-site>`        | Your Atlassian Cloud site, e.g. `acme` in `acme.atlassian.net`. |
| `<CONFLUENCE_SPACE>` | Your Confluence space key.                                    |
| `<LANGUAGE_STACK>`   | The languages you actually use (e.g. `python, typescript`).   |
| `<SONAR_HOST>`       | Your SonarQube / SonarCloud host URL.                         |
| `<DEFAULT_BRANCH>`   | The base branch for PRs (default `main`).                     |

Files marked `.template` should be copied to the same path **without** the
suffix. Files marked `.example` are samples — copy them and fill in real
values, then commit the rendered file.

## 6. Cross-reference: which atlassiancli subcommands the agent uses

The DevCycle prompt invokes these `atlassiancli` subcommands by name. They
exist in `src/atlassiancli/cli/main.py` of the engine repo:

| Phase / use                   | Subcommand                                                       |
| ----------------------------- | ---------------------------------------------------------------- |
| Phase 1 — fetch story         | `atlassiancli analyse fetch <KEY> --json`                        |
| Phase 2 — DoR gate            | `atlassiancli analyse ready <KEY> --json`                        |
| Phase 2 — atomicity check     | `atlassiancli analyse atomicity <KEY> --json`                    |
| Phase 2 — lint                | `atlassiancli analyse lint <KEY> --json`                         |
| Phase 2 — architecture review | `atlassiancli analyse architecture <KEY> --json`                 |
| Phase 3 / 8 — transitions     | `atlassiancli transition <KEY> --status "In Progress"`           |
| Phase 5 / 6 — comment         | `atlassiancli comment <KEY> --body "<msg>" --idempotency-key`    |
| Phase 8 — link PR             | `atlassiancli link-pr <KEY> --pr-url <url>`                      |
| Phase 0 / 8 — assignee        | `atlassiancli assign <KEY> --user <email>`                       |
| Sprint context                | `atlassiancli sprint current --json`, `... sprint stories --json` |
| Story authoring + import      | `atlassiancli import yaml`, `... import markdown`                |

Exit-code contract (the prompt branches on these):

| Exit code | Meaning                  | Agent behaviour                                       |
| --------- | ------------------------ | ----------------------------------------------------- |
| `0`       | Success                  | Continue to the next phase.                           |
| `1`       | Validation / generic error | Stop, log, surface to human.                         |
| `75`      | Transient (rate-limit / 5xx) | Retry with exponential backoff.                  |
| `77`      | Auth failure             | Halt immediately — do not retry.                      |

The DevCycle prompt encodes this contract literally — see Phase 1 / Phase 8
for the exact branching logic.
