# Copilot Instructions — Code Quality + Testing SOP

> This file is loaded by GitHub Copilot (and any other agent that respects
> `.github/copilot-instructions.md`) on every interaction in this repo. It
> defines the **Code Quality + Testing SOP** that the DevCycle agent
> enforces. Read it before writing any code.

## 1. Project context

- **Project**: `<PROJECT_NAME>`
- **Language stack**: `<LANGUAGE_STACK>` (e.g. `python, typescript, csharp`)
- **Default branch**: `<DEFAULT_BRANCH>`
- **Issue tracker**: Jira project `<JIRA_PROJECT_KEY>` on
  `https://<your-site>.atlassian.net`
- **Docs**: Confluence space `<CONFLUENCE_SPACE>`
- **Quality engine**: `atlassiancli` (CLI for Atlassian + agent quality
  gates) — assume it is on `PATH`.

This is a multi-stack monorepo placeholder. Treat each language section
below as opt-in: delete the sections you do not use; *do not* delete the
universal section.

## 2. Universal patterns (apply to every change)

### 2.1 Logging

- **Structured only** — log records must be JSON-encodable maps, never
  free-form strings.
- **Correlation IDs** — every request / job / agent invocation propagates a
  correlation id (e.g. `request_id`, `run_id`, `trace_id`). Log it on every
  record produced inside that scope.
- **No secrets in logs** — passwords, tokens, API keys, PHI, PII never
  appear in log output. Validate via `gitleaks` (pre-commit) and SAST.
- **Levels** — `DEBUG` for dev-only chatter, `INFO` for state changes,
  `WARN` for recoverable degradations, `ERROR` for failures the user must
  see. Reserve `CRITICAL` / `FATAL` for incidents.

### 2.2 Error handling

- Domain errors are **typed** (typed exceptions / discriminated unions) —
  not strings, not generic `Exception` / `Error`.
- Public APIs **document** every failure mode they can return.
- Never swallow an exception silently. If you catch, you either *handle* it
  or *re-raise* with context.

### 2.3 Public-API documentation

Every exported function / class / endpoint has:

- A one-line summary.
- A behavioural contract (what it returns, what it throws, what side effects
  it produces).
- Example invocation when non-obvious.

For Python: docstrings (Google or NumPy style — pick one and be consistent).
For TypeScript: TSDoc with `@param`, `@returns`, `@throws`.
For C#: XML documentation comments (`<summary>`, `<param>`, `<returns>`,
`<exception>`).

### 2.4 No drift markers

- **No `TODO` / `FIXME` / `XXX` without a Jira key** — `// TODO(ACME-1234):
  refactor cache eviction` is fine; bare `// TODO: fix this` is rejected
  by pre-commit.
- **No commented-out code** — delete it. `git` remembers.
- **No leftover debug prints** — `print(...)`, `console.log(...)`,
  `Console.WriteLine(...)` in production paths are blocked at PR review.

### 2.5 Test coverage baseline

- Branch coverage `>= 85%` in changed files. CI fails the PR otherwise.
- Every bug fix ships with a regression test that fails on the unfixed code
  and passes on the fix.
- Every public API has a test that exercises the documented contract.

## 3. Per-language sections

### 3.1 Python (delete this section if you do not use Python)

- **Version**: 3.12+
- **Type safety**: `mypy --strict` clean. No bare `Any`, no untyped public
  surface.
- **Lint**: `ruff check .` (ruleset: `E,F,I,N,UP,B,C4,SIM,RUF,PL`). Zero
  warnings.
- **Format**: `ruff format` (or `black` if you prefer — pick one). 100-char
  line length.
- **Imports**: `isort` via ruff's `I` rules, first-party / third-party /
  stdlib grouped.
- **Test framework**: `pytest`. Tests under `tests/`, mirroring the
  package layout. Coverage via `pytest-cov`.
- **Security scan**: `bandit -r src/` clean (or whitelist with comments
  citing the Jira key that approved the deviation).
- **Dependencies**: pinned in `pyproject.toml`. No floating `>=` ranges in
  production extras.

### 3.2 TypeScript / React (delete if not used)

- **Version**: TypeScript `5.x`, Node `20+`.
- **Type safety**: `tsc --noEmit --strict` clean. No `any` in committed
  code (use `unknown` + narrowing).
- **Lint**: `eslint .` clean (ruleset: `@typescript-eslint/recommended`,
  `react-hooks`, plus project rules).
- **Format**: `prettier --check .` clean. 100-char line length, single
  quotes, trailing commas.
- **Test framework**: `vitest` or `jest` — pick one. Component tests via
  `@testing-library/react`.
- **Coverage**: `c8` / `vitest --coverage`, threshold `85%`.
- **Bundle hygiene**: no `process.env.*` reads outside a single
  `config.ts` boundary; no `eval`; never inject raw HTML strings into the
  DOM without an explicit sanitisation step (e.g. DOMPurify) and a comment
  citing the Jira key that approved it.

### 3.3 C# / .NET (delete if not used)

- **Version**: `.NET 8` LTS or later.
- **Lint / format**: `dotnet format --verify-no-changes` clean. Treat
  warnings as errors in `Directory.Build.props`
  (`<TreatWarningsAsErrors>true</TreatWarningsAsErrors>`).
- **Nullable**: `<Nullable>enable</Nullable>` everywhere; no `!`
  null-forgiving operator without a comment.
- **Test framework**: `xUnit` (or `NUnit`). Test projects suffixed
  `*.Tests`.
- **Coverage**: `coverlet` integrated into the test runner; threshold
  `85%`.

## 4. Quality-gate references

This SOP is enforced by three layers; the agent must satisfy all three
before opening a PR:

1. **Local — pre-commit hooks** (`.pre-commit-config.yaml`)
   - Universal: trailing whitespace, EOL, large-files, gitleaks.
   - Python: `ruff check`, `ruff format --check`, `mypy`, `bandit`.
   - TypeScript: `prettier --check`, `eslint`, `tsc --noEmit`.
   - C#: `dotnet format --verify-no-changes`, `dotnet build`.
   - Pre-push: SonarQube scanner (when configured).
   - Commit-msg: Conventional Commits regex.
2. **Agent SOP — DevCycle Phase 4 / 5 / 6**
   - The agent runs the language test suite and the lint gate locally
     before transitioning to Phase 6 (review).
   - The agent also runs `atlassiancli analyse architecture <KEY>` and
     `atlassiancli analyse ready <KEY>` to satisfy story-quality gates.
3. **CI** (`.github/workflows/*.yml`)
   - Re-runs the same lint + test + coverage gates on every push.
   - SonarQube scan on `pull_request` against `<DEFAULT_BRANCH>`.
   - Blocks merge if any gate fails.

## 5. Always do this / Never do this

| Always                                                              | Never                                                                       |
| ------------------------------------------------------------------- | --------------------------------------------------------------------------- |
| Add a regression test for every bug fix.                            | Commit a fix without a test that proves it.                                 |
| Use the project's logger (structured, leveled).                     | Use `print` / `console.log` / `Console.WriteLine` in production paths.      |
| Type every public function / endpoint signature.                    | Use `Any` / `any` / `dynamic` in committed code without justification.       |
| Use the project's secret manager.                                   | Hard-code API keys, tokens, passwords, connection strings.                  |
| Run `pre-commit run --all-files` before opening a PR.               | `git commit --no-verify` to skip the hooks.                                 |
| Reference a Jira key in every TODO / FIXME.                         | Leave bare `TODO` / `FIXME` / `XXX` markers.                                |
| Document every public API with examples.                            | Ship undocumented "internal-only" APIs that are imported externally.        |
| Squash + rebase before merge to keep `<DEFAULT_BRANCH>` linear.     | Merge feature branches with merge commits.                                  |
| Update the SOPs in `docs/architecture/` when patterns change.       | Treat the SOPs as decorative — they drive agent behaviour.                  |

## 6. When asked to write code

The agent should:

1. Re-read this file before producing each diff.
2. Re-read `docs/architecture/ARCHITECTURE.md` and
   `docs/architecture/SECURITY.md` for the current change.
3. Re-read `docs/architecture/data_handling.md` if the change touches
   user data.
4. Re-read `docs/architecture/ai_safety.md` if the change touches model
   inputs / outputs.
5. Produce the smallest correct diff — no opportunistic refactors.
6. Add tests in the same diff. Tests-after counts as no tests.
7. Run the lint + test gates locally and paste the output.
8. Stop and ask the human if any SOP is unclear — do not paper over with a
   plausible-looking guess.
