# Install — autonomous-dev-system kit

Step-by-step walkthrough for copying this kit into your project and lighting
up the autonomous-dev workflow.

## 1. Prerequisites

- **atlassiancli installed and on `PATH`** — `atlassiancli --version` must
  succeed. Install with `pip install inovagio-atlassian` or
  `pipx install atlassiancli`.
- **Atlassian Cloud access** for the project's Jira + Confluence (the agent
  authenticates against the standard Atlassian OAuth flow via the MCP
  server).
- **GitHub repository** for the project (the kit assumes GitHub PRs and
  GitHub Copilot review; adapt or strip the Copilot pieces if you use a
  different forge).
- **VS Code with GitHub Copilot agent mode** enabled (or any AI coding
  agent that can read `.github/prompts/*.prompt.md` system prompts).
- **Python 3.12+** for `pre-commit` itself (the hooks themselves can target
  any language).
- **`pre-commit`** — `pipx install pre-commit` or `pip install pre-commit`.
- **`gh` CLI** — `gh auth status` must succeed (used by the agent in
  Phase 8 to open the PR).

## 2. Copy the templates

From the root of your project:

### macOS / Linux

```bash
# from the root of your project, with atlassiancli's source nearby
SRC=/path/to/atlassiancli/templates/autonomous-dev-system

# copy the dotfile trees explicitly so hidden directories survive
cp -R "$SRC/.github"          .
cp -R "$SRC/.vscode"          .
cp    "$SRC/.pre-commit-config.yaml" .
cp    "$SRC/.editorconfig"          .
cp    "$SRC/sonar-project.properties.example" sonar-project.properties

# docs — strip the .template suffix so the agent finds them at the SOP path
mkdir -p docs/architecture
for f in "$SRC"/docs/architecture/*.template; do
  base=$(basename "$f" .template)
  cp "$f" "docs/architecture/$base"
done

# SOPs (machine-enforced) + their gate scripts + manifest
mkdir -p sops scripts
for f in "$SRC"/sops/*.sop.md.template; do
  base=$(basename "$f" .template)
  cp "$f" "sops/$base"
done
cp "$SRC/sops/sop-manifest.yaml" sops/sop-manifest.yaml
cp "$SRC/scripts/sop-story-check.sh"  scripts/
cp "$SRC/scripts/sop-commit-gate.sh"  scripts/
chmod +x scripts/sop-*.sh
```

### Windows (PowerShell)

```powershell
$Src = "C:\path\to\atlassiancli\templates\autonomous-dev-system"

Copy-Item -Recurse "$Src\.github"        .
Copy-Item -Recurse "$Src\.vscode"        .
Copy-Item "$Src\.pre-commit-config.yaml" .
Copy-Item "$Src\.editorconfig"           .
Copy-Item "$Src\sonar-project.properties.example" sonar-project.properties

New-Item -ItemType Directory -Force -Path "docs\architecture" | Out-Null
Get-ChildItem "$Src\docs\architecture\*.template" | ForEach-Object {
  $dst = "docs\architecture\" + $_.BaseName  # BaseName drops the .template
  Copy-Item $_.FullName $dst
}

# SOPs (machine-enforced) + their gate scripts + manifest
New-Item -ItemType Directory -Force -Path "sops"    | Out-Null
New-Item -ItemType Directory -Force -Path "scripts" | Out-Null
Get-ChildItem "$Src\sops\*.sop.md.template" | ForEach-Object {
  $dst = "sops\" + $_.BaseName  # drops the .template
  Copy-Item $_.FullName $dst
}
Copy-Item "$Src\sops\sop-manifest.yaml"        "sops\sop-manifest.yaml"
Copy-Item "$Src\scripts\sop-story-check.sh"    "scripts\sop-story-check.sh"
Copy-Item "$Src\scripts\sop-commit-gate.sh"    "scripts\sop-commit-gate.sh"
```

### Verification

After copying you should have, at minimum:

```
.github/
  copilot-instructions.md
  prompts/
    devcycle.prompt.md
    thinking-beast-mode.prompt.md
.vscode/
  mcp.json
  devcycle-config.json
  settings.json
.pre-commit-config.yaml
.editorconfig
sonar-project.properties
docs/
  architecture/
    ARCHITECTURE.md
    SECURITY.md
    data_handling.md
    ai_safety.md
    story_authoring.md
sops/
  01-architecture.sop.md
  02-security.sop.md
  03-code-quality.sop.md
  04-testing.sop.md
  05-logging.sop.md
  06-monitoring.sop.md
  sop-manifest.yaml
scripts/
  sop-story-check.sh
  sop-commit-gate.sh
```

## 3. Customise placeholders

Search-and-replace across the copied tree:

| Placeholder          | Replace with                                                  |
| -------------------- | ------------------------------------------------------------- |
| `<PROJECT_NAME>`     | Your project / monorepo name.                                 |
| `<JIRA_PROJECT_KEY>` | The Jira project key, e.g. `ACME`.                            |
| `<your-site>`        | Your Atlassian Cloud site (the prefix in `*.atlassian.net`).  |
| `<CONFLUENCE_SPACE>` | Your Confluence space key.                                    |
| `<LANGUAGE_STACK>`   | Comma-separated language list, e.g. `python, typescript`.     |
| `<SONAR_HOST>`       | Your SonarQube / SonarCloud host URL.                         |
| `<DEFAULT_BRANCH>`   | The base branch for PRs (`main`, `trunk`, etc.).              |
| `<TEAM_EMAIL>`       | The team mailbox for escalations.                             |

A reasonably safe macOS / Linux one-liner (review the diff before
committing!):

```bash
grep -rl '<PROJECT_NAME>' .github .vscode docs sonar-project.properties \
  | xargs sed -i.bak 's/<PROJECT_NAME>/acme/g'
# repeat per placeholder; remove the .bak files when you're happy
find . -name '*.bak' -delete
```

Strip any per-language sections in `.pre-commit-config.yaml` and
`.github/copilot-instructions.md` that don't apply to your stack — each
section has a comment marker (`# --- python ---` etc.) so it is easy to
delete.

## 4. Install pre-commit hooks

```bash
pre-commit install                       # install the pre-commit hook
pre-commit install --hook-type commit-msg # install the commit-msg hook (Conventional Commits)
pre-commit install --hook-type pre-push   # install the pre-push hook (SonarQube)

# one-time bootstrap run against the whole repo
pre-commit run --all-files
```

The first run will be slow (it pulls hook environments). Subsequent runs
hit only changed files.

## 5. Configure VS Code

1. Restart VS Code so it picks up the new `.vscode/` directory.
2. Open the Command Palette and run `MCP: List Servers`. You should see
   `atlassian` and `github` as configured but not yet authenticated.
3. Run `MCP: Sign In: atlassian` and complete the Atlassian OAuth flow.
4. Run `MCP: Sign In: github` and complete the GitHub OAuth flow.
5. Open Copilot Chat, switch to **Agent** mode, and run
   `@workspace /list-prompts` — you should see `devcycle` and
   `thinking-beast-mode` listed.

If your AI agent is not GitHub Copilot, adapt the prompts: every agent that
supports system-prompt-style instructions will accept the markdown bodies
verbatim.

## 6. Author your SOPs

You now have **two parallel SOP surfaces**:

- `docs/architecture/*.md` — long-form prose SOPs (architecture, security,
  AI safety, data handling, story authoring). The agent reads these for
  context.
- `sops/*.sop.md` + `sops/sop-manifest.yaml` — machine-enforced SOPs
  (architecture, security, code quality, testing, logging, monitoring).
  The Phase 2 story-time check and the Phase 6 / pre-commit gate
  read the manifest and **block** on violations.

Both start as skeletons with bracketed `<placeholders>` and example rules.
The DevCycle agent reads them on every story — empty brackets and
unedited example rules become weak gates. Fill them in **before**
running `@devcycle` against a real ticket. Suggested order:

1. `sops/01-architecture.sop.md` — layer + bounded-context rules first;
   the manifest's `arch.commit.no_upward_layer_imports` regex must match
   your actual import patterns.
2. `sops/02-security.sop.md` — secret regexes, authz / audit hooks. The
   built-in regex set covers AWS / GitHub / Slack / OpenAI tokens;
   add provider-specific patterns for whatever else you use.
3. `sops/03-code-quality.sop.md` — pin your formatter, linter, and
   complexity threshold in the manifest's `project.toolchain` block.
4. `sops/04-testing.sop.md` — pin the test runner + coverage tool; the
   default coverage floor is 85%.
5. `sops/05-logging.sop.md` — declare your logger interface and PII
   deny-list.
6. `sops/06-monitoring.sop.md` — declare metric / tracing libraries and
   cardinality deny-list.
7. `docs/architecture/ARCHITECTURE.md` — long-form layer diagram +
   context map.
8. `docs/architecture/SECURITY.md` — long-form security architecture.
9. `docs/architecture/data_handling.md` — PHI / PII classes only matter
   if you actually have regulated data. Otherwise stub as "all data is
   Internal."
10. `docs/architecture/ai_safety.md` — fill once you run model inference.

Verify the manifest parses before you point the agent at a real ticket:

```bash
./scripts/sop-commit-gate.sh --self-test
```

## 7. Verify the agent loop with `@devcycle sandbox`

Before pointing the agent at a real ticket, run the sandbox mode:

```text
@devcycle sandbox
```

The agent will:

1. Read `.github/prompts/devcycle.prompt.md` and `.vscode/devcycle-config.json`.
2. Run `atlassiancli --version` to confirm the engine is on PATH.
3. Run a `--dry-run` against `atlassiancli analyse fetch DUMMY-1` to confirm
   the JSON contract is intact.
4. Print the parsed config, the discovered SOP files, and the planned
   workflow — but **not** transition any Jira state, write any files, or
   open any PRs.

If the sandbox completes cleanly, you're ready. Drive a real ticket with:

```text
@devcycle <JIRA_PROJECT_KEY>-123
```

The state machine takes over from there. Watch the live state in
`.vscode/devcycle/state.json`.
