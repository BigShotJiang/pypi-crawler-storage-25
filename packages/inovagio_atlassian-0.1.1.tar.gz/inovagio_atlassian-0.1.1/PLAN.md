# atlassiancli — Build Plan

**Status:** PROPOSAL — drafted 2026-05-09
**Repo:** https://github.com/inovagio/atlassiancli

## 1. Vision

A standalone, pip-installable, zero-pip-dep Python 3.12+ CLI for Atlassian operations (Jira + Confluence) that any project can drop in and use. Works in any project, copy-deployable, no environment-specific assumptions.

The CLI is also designed as **agent-callable infrastructure** for autonomous-development workflows. AI coding agents that drive ticket-to-PR cycles invoke this CLI to fetch sprint stories, lint story quality, transition workflow states, post comments, and sync repo docs to Confluence. Every subcommand supports `--json` output for machine consumption and is idempotent so the agent can safely retry.

Four capability tiers:

1. **Atlassian basics** — create / analyse / transition issues; sprint operations; reporting; Confluence page CRUD; markdown-to-Confluence import
2. **Story analysis + enhancement** — story quality lint, atomic-test check, Definition-of-Ready gate, AI-implementable story templates
3. **Doc framework bridge** — manifest-driven Jira story creation, parity verification, reverse-sync, repo-markdown to Confluence sync
4. **Project bootstrap** — end-to-end procedure for adopting the doc framework on a new project

## 2. Architecture

DDD-layered Python package. Each layer has a single responsibility:

- **Domain** — value objects, repository interfaces, service interfaces. Pure business logic; no I/O.
- **Application** — use-case services that orchestrate domain operations. Accept request DTOs, return response DTOs.
- **Infrastructure** — concrete adapters: HTTP clients, YAML codec, markdown formatter, config loader, env parser.
- **CLI** — argparse-based command handlers that adapt CLI args to application service calls.

A composition root wires dependencies once at startup. Tests can substitute alternate adapters for any layer.

## 3. Constraints

1. **Zero pip dependencies at runtime.** Python 3.12+ standard library only.
2. **Self-contained.** All capabilities live inside the `atlassiancli/` package. No imports outside the package + stdlib.
3. **Project-agnostic.** No hardcoded project keys, page ids, or organisational assumptions. Everything that varies per consuming project lives in config files.
4. **Copy-deployable.** A user can `cp -R src/atlassiancli/ <their-project>/` and it works without further setup beyond credentials + a project config.
5. **Pip-installable.** `pip install inovagio-atlassian` (after publish) provides the same capability via the standard Python packaging path.

## 4. Target structure

```
atlassiancli/
├── README.md                            # what it is, install, quick start
├── LICENSE                              # MIT
├── PLAN.md                              # this file
├── pyproject.toml                       # PEP 517/518, console entry, no runtime deps
├── .gitignore
├── docs/
│   ├── USAGE.md                         # every subcommand
│   ├── RUNBOOK.md                       # operational procedures
│   ├── ARCHITECTURE.md                  # DDD layered overview
│   └── EXAMPLES/
│       ├── minimal-project/             # Jira-only starter config
│       ├── doc-framework-product/       # full doc-framework config + sample manifests
│       └── README.md
├── src/
│   └── atlassiancli/
│       ├── __init__.py
│       ├── __main__.py                  # python -m atlassiancli
│       ├── cli/
│       │   ├── __init__.py
│       │   ├── main.py                  # argparse + subcommand dispatch
│       │   ├── handlers/
│       │   │   ├── issues.py            # create / analyse / transition / delete
│       │   │   ├── sprints.py           # sprint ops, balance, goals
│       │   │   ├── confluence.py        # page CRUD, import, formatting
│       │   │   ├── reporting.py         # quality, velocity, themes, health
│       │   │   ├── product_docs.py      # generic doc-structure scaffolding
│       │   │   └── framework.py         # doc-framework bridge subcommands
│       │   └── composition_root.py
│       ├── domain/
│       │   ├── __init__.py
│       │   ├── value_objects.py         # IssueKey, ConfluencePageId, etc.
│       │   ├── models.py                # Epic, Story, Task, ConfluencePage
│       │   ├── repositories.py          # IIssueRepository, IConfluenceRepository
│       │   ├── services.py              # domain service interfaces
│       │   └── framework/
│       │       ├── __init__.py
│       │       ├── value_objects.py     # ProductHandle, DocHandle, EpicKey
│       │       └── config.py            # ProductFrameworkConfig dataclass
│       ├── application/
│       │   ├── __init__.py
│       │   ├── dtos.py                  # request / response DTOs
│       │   ├── services.py              # use-case orchestration
│       │   └── framework_services.py    # framework-specific use cases
│       └── infrastructure/
│           ├── __init__.py
│           ├── http_client.py           # stdlib urllib base
│           ├── jira_client.py           # uses http_client
│           ├── confluence_client.py     # uses http_client
│           ├── markdown_formatter.py    # markdown → Confluence storage XHTML
│           ├── yaml_codec.py            # pure-Python YAML parser + writer
│           ├── env_loader.py            # stdlib .env parser
│           ├── config.py                # uses env_loader
│           └── framework_config.py      # .docframework.yaml loader
└── tests/
    ├── unit/
    └── integration/
```

## 5. Pure-Python implementations

The constraint "zero pip deps" forces us to provide our own implementations of three things commonly outsourced to PyPI packages:

### 5.1 YAML parser + writer (`infrastructure/yaml_codec.py`)

Subset supported (sufficient for typical config + manifest files):

- Mappings (`key: value`), nested
- Block sequences (`- item`), nested
- Compact-mapping-in-sequence (`- key: val\n  key2: val2`)
- Flow-style sequences (`[A, B, C]`)
- Scalars: null / bool / int / float / string
- Single-quoted + double-quoted strings (with `\n`, `\t`, `\r`, `\\`, `\"` escapes)
- Block literal scalars (`|` with `|-` strip and clip default)
- Comments (`#`, after whitespace, not inside quoted strings)
- Document separators (`---` / `...`) — ignored
- `${VAR:-default}` env expansion (configurable)

Not supported (none typically used in config / manifest YAML):

- Anchors (`&name`) and aliases (`*name`)
- Tags (`!!str`)
- Multi-document streams
- Folded scalars (`>`)
- Flow-style mappings (`{key: val}`)

Estimated size: ~400-500 lines.

The parser produces standard Python types (`dict / list / str / int / float / bool / None`) — drop-in replacement for what `yaml.safe_load` returns. The writer emits canonical YAML.

### 5.2 HTTP client (`infrastructure/http_client.py`)

A small `HttpClient` class wrapping `urllib.request`:

- Methods: `get`, `post`, `put`, `delete`
- JSON body encode + response decode helpers
- Basic auth via `Authorization` header (drop-in for `requests.auth.HTTPBasicAuth`)
- Stable error type that wraps `urllib.error.HTTPError` with the response body for diagnostics
- Configurable timeout per call

Estimated size: ~150 lines.

### 5.3 `.env` file parser (`infrastructure/env_loader.py`)

Load `.env` files into `os.environ`:

- `KEY=VALUE` lines
- Comments (`#`)
- Empty lines
- Single-quoted and double-quoted values
- Variable expansion `${VAR}` (configurable)
- Override-vs-respect-existing controls

Estimated size: ~50 lines.

## 6. Capabilities

### 6.1 Atlassian basics (Tier 1)

```
atlassiancli configure                              # Interactive — prompts for site URL / email / token; stores in ~/.atlassiancli/config.yaml
atlassiancli create epic --title "..."             # Create Jira epic
atlassiancli create story --epic <KEY> --title ...  # Create story under an epic
atlassiancli create task --story <KEY> --title ...  # Create task under a story
atlassiancli create version --project <KEY> ...     # Create a release version
atlassiancli transition <KEY> --to "In Progress"    # Workflow transition
atlassiancli assign <KEY> --user <email>            # Assign an issue
atlassiancli comment <KEY> --body "..."             # Add a comment
atlassiancli link-pr <KEY> --pr-url <url>           # Link a GitHub PR to an issue
atlassiancli delete --issue <KEY>                   # Delete an issue
atlassiancli sprint move --to <ID> <KEY>...         # Move issues to a sprint
atlassiancli sprint goals --board <ID>              # Generate sprint goals
atlassiancli sprint split --story <KEY>             # Split a story into subtasks
atlassiancli sprint balance --board <ID>            # Balance sprint capacity
atlassiancli sprint current --board <ID>            # Identify the active sprint id
atlassiancli sprint stories --sprint <ID> [--unassigned] [--priority-order]
atlassiancli report quality --project <KEY>         # Story quality roll-up
atlassiancli report velocity --board <ID>           # Velocity metrics
atlassiancli report health --project <KEY>          # Backlog health
atlassiancli report themes --project <KEY>          # Theme distribution
atlassiancli docs create --space <KEY> --title ...  # Create a Confluence page
atlassiancli docs import --file <md>                # Import markdown to Confluence
atlassiancli docs sync --page <ID> --file <md>      # Sync a markdown file to a page
atlassiancli product-docs scaffold --product <handle>  # Generate baseline doc structure
```

### 6.2 Story analysis + enhancement (Tier 2 — agent-callable)

These subcommands support **autonomous-development workflows** where AI coding agents drive ticket-to-PR cycles. Every command supports `--json` for machine consumption and is read-only by default; writes happen only with explicit `--apply` flags.

```
atlassiancli analyse lint <KEY> [--json]             # Story-quality score 0-100 against the 11-section AI-implementable schema; ≥80 is the Definition-of-Ready bar
atlassiancli analyse atomicity <KEY> [--json]        # Atomic-test check (5 criteria: bounded module, single layer, PR-sized, no prerequisite ambiguity, isolated tests)
atlassiancli analyse description <KEY> [--json]      # Description-quality breakdown by required section
atlassiancli analyse architecture <KEY> [--json]     # Architecture-fit check against the project's ARCHITECTURE.md
atlassiancli analyse ready <KEY> [--json]            # Composite gate: lint ≥80 AND atomicity passes AND all 11 sections present — returns READY/NOT_READY
atlassiancli analyse fetch <KEY> [--json]            # Full structured story content for agent consumption
atlassiancli enhance <KEY> [--apply] [--dry-run]     # Generate missing required sections; `--apply` writes back to Jira description, default writes to stdout
atlassiancli template story [--type <kind>]          # Emit the 11-section blank story template
atlassiancli template epic [--type <kind>]           # Emit the epic template
```

Every analyse subcommand emits structured JSON when `--json` is set, with this stable schema:

```json
{
  "issue_key": "PROJ-247",
  "command": "lint",
  "verdict": "PASS|FAIL|WARN",
  "score": 87,
  "threshold": 80,
  "findings": [
    {"severity": "critical|major|minor|info", "rule": "<id>", "section": "<section>", "message": "<text>", "fix_hint": "<text>"}
  ],
  "metadata": {"jql_used": "...", "fetched_at": "<iso8601>"}
}
```

The agent's state machine reads `verdict` + `findings` programmatically; the human-readable form is a default-pretty-printed mode without `--json`.

### 6.3 Doc framework bridge (Tier 3)

```
atlassiancli framework create-stories --product <handle>
atlassiancli framework verify-stories --product <handle>
atlassiancli framework reverse-sync   --product <handle> [--epic <ID>]
atlassiancli framework sync-docs      --product <handle> [--doc <HANDLE>]
atlassiancli framework bootstrap      --product <handle>
```

### 6.4 Autonomous-development system integration

The CLI is invoked by AI agents implementing ticket-to-PR workflows. The integration contract:

| Agent phase | CLI subcommands invoked | Required behaviour |
|---|---|---|
| Fetch sprint item | `sprint current --board <ID>` then `sprint stories --sprint <ID> --unassigned --priority-order` | JSON output; first item is the agent's pick |
| Validate story | `analyse ready <KEY> --json` | Returns `READY` only if all gates pass; agent halts on `NOT_READY` |
| Enhance gaps (fallback) | `enhance <KEY> --dry-run --json` | Returns proposed description in JSON; agent shows to operator before `--apply` |
| Mark in-progress | `transition <KEY> --to "In Progress"` then `assign <KEY> --user $ATLASSIAN_EMAIL` then `comment <KEY> --body "<agent run id>"` | Idempotent — safe to retry |
| Mark done | `transition <KEY> --to "Done"` then `link-pr <KEY> --pr-url <url>` | Idempotent |

**Invariants the CLI guarantees:**

- Every subcommand returns exit code 0 on success, non-zero on failure
- Every JSON output is parseable with stdlib `json.loads()` — no decorations, no terminal colour codes when `--json` is set
- HTTP rate-limit errors surface as exit code 75 (EX_TEMPFAIL) so the agent can retry with backoff
- Auth errors surface as exit code 77 (EX_NOPERM) so the agent halts cleanly
- All write operations are idempotent — re-running is safe

The `framework` subcommand reads `.docframework.yaml` (per-product config: jira label namespace, summary prefix, epic key map, Confluence hub page id, doc-page id map). The bridge logic walks story manifests under `<repo>/docs/<product>/stories/manifests/*.yaml` and reconciles with Jira; walks markdown docs under `<repo>/docs/<product>/*.md` and syncs to Confluence.

### 6.3 Project bootstrap (Tier 3)

`framework bootstrap --product <handle>` runs the full procedure for adopting the doc framework in a project that doesn't have it yet:

1. Confirm prerequisites (auth env vars set, repo writable)
2. Reserve a Confluence hub page if not configured
3. Create epics in Jira if not configured
4. Generate skeleton `.docframework.yaml`
5. Generate skeleton `docs/<product>/` directory structure
6. Run initial parity verification

## 7. Configuration model

Each consuming project provides:

### 7.1 Authentication

Three lookup paths, in priority order:

1. **Env vars** (preferred for CI):
   ```
   ATLASSIAN_EMAIL=user@example.com
   ATLASSIAN_TOKEN=<api token>
   ATLASSIAN_SITE=<site>.atlassian.net
   ```
2. **`.env` file** at the project root (parsed by `infrastructure/env_loader.py`)
3. **User config** at `~/.atlassiancli/config.yaml` (created by `atlassiancli configure` interactive prompt)

The user config supports profiles for engineers who work across multiple Atlassian sites:

```yaml
default_profile: work
profiles:
  work:
    site: company.atlassian.net
    email: user@company.com
    token: <encrypted token>
  personal:
    site: personal.atlassian.net
    email: user@personal.com
    token: <encrypted token>
```

Switch with `atlassiancli --profile <name>` or set `ATLASSIAN_PROFILE` env var.

### 7.2 Project config (`.atlassiancli.yaml`)

Top-level CLI defaults for the project:

```yaml
atlassian:
  cloud_site: <site>.atlassian.net
  default_jira_project: <KEY>
  default_confluence_space: <KEY>

framework:
  enabled: true
  products_dir: docs                    # where docs/<product>/ trees live
```

### 7.3 Per-product framework config (`docs/<product>/.docframework.yaml`)

When using the framework subcommand, each product gets its own config:

```yaml
product:
  id: <handle>
  name: <Display Name>

jira:
  cloud_site: <site>.atlassian.net
  project_key: <KEY>
  default_assignee_email: <email>
  label_namespace: <handle>-ga-v1
  summary_prefix: "[<HANDLE>]"
  epics:
    E-01: <ISSUE-KEY>
    # ...

confluence:
  cloud_site: <site>.atlassian.net
  space_key: <KEY>
  hub_page_id: "<page id>"
  doc_pages:
    README: "<page id>"
    # ...

paths:
  manifests_dir: stories/manifests
  evidence_dir: evidence
  epic_docs_dir: epics
  adr_dir: adrs
```

This means atlassiancli has no knowledge of any specific project's labels, epic keys, or page ids — every consuming project provides its own.

## 8. Phased build-out (8 PRs)

Each PR lands a working subset.

### PR 1 — Bootstrap the package skeleton

Files:
- `pyproject.toml` (PEP 517/518; console entry `atlassiancli = "atlassiancli.cli.main:main"`; no runtime deps; dev deps optional)
- `src/atlassiancli/__init__.py` (`__version__`)
- `src/atlassiancli/__main__.py` (delegates to `cli.main`)
- `src/atlassiancli/cli/main.py` (minimal — `--version` prints; no subcommands yet)
- `.gitignore`
- `tests/test_smoke.py` (import + version check)
- `README.md` (replace placeholder)

Verification: `pip install -e .` in a venv; `atlassiancli --version` prints.

### PR 2 — stdlib infrastructure

Files added:
- `infrastructure/http_client.py`
- `infrastructure/yaml_codec.py`
- `infrastructure/env_loader.py`

Tests: round-trip every YAML construct, HTTP auth header / JSON helpers (mocked), `.env` parsing edge cases.

Verification: all unit tests pass with stdlib `unittest`.

### PR 3 — Atlassian-basics tier

Files added:
- `domain/{value_objects,models,repositories,services}.py`
- `application/{dtos,services}.py`
- `infrastructure/{jira_client,confluence_client,markdown_formatter,config}.py`
- `cli/handlers/{issues,sprints,confluence,reporting,product_docs}.py`
- `cli/handlers/configure.py` — interactive credential setup
- `cli/composition_root.py`
- `cli/main.py` extended to register Tier-1 subcommands

Verification: every Tier-1 subcommand has `--help`; HTTP layer mocked in unit tests; `configure` subcommand round-trips a profile.

### PR 4 — Story analysis + enhancement tier (agent-callable)

Files added:
- `domain/story/value_objects.py` — `StoryQualityScore`, `Verdict`, `Finding`
- `domain/story/lint_rules.py` — declarative rule definitions (11 sections, atomic-test, anti-patterns from §6.5)
- `application/story_services.py` — `StoryLintService`, `StoryAtomicityService`, `StoryReadyService`, `StoryEnhanceService`, `StoryFetchService`
- `infrastructure/story_lint_evaluator.py` — runs the rule engine against fetched issue content
- `infrastructure/story_enhancer.py` — generates missing-section content from existing issue context
- `cli/handlers/story_analysis.py` — `analyse {lint|atomicity|description|architecture|ready|fetch}` + `enhance` + `template`

Tests:
- `tests/unit/test_story_lint.py` — every rule against fixture stories (good story → 100, bad story → expected score breakdown)
- `tests/unit/test_atomicity.py` — 5 criteria, mixed pass/fail fixtures
- `tests/unit/test_story_ready_gate.py` — composite gate logic
- `tests/integration/test_agent_workflow.py` — simulates the agent's invocation sequence (sprint current → sprint stories → analyse ready → transition → comment → link-pr) with recorded HTTP

Verification:
- `--json` output parseable on every subcommand
- Exit codes match the contract (0/1/75/77)
- Idempotency tests: running each write subcommand twice yields the same Jira state

### PR 5 — Doc framework bridge tier

Files added:
- `domain/framework/{value_objects,config}.py`
- `application/framework_services.py`
- `infrastructure/framework_config.py`
- `cli/handlers/framework.py`

Tests: `.docframework.yaml` loading + validation; service-level tests with mocked clients; integration test against fixture manifest set with recorded HTTP responses.

Verification: `atlassiancli framework --help` lists 5 subcommands; bootstrap on an example product config succeeds.

### PR 6 — Documentation

Files added:
- `README.md` (install, quick start)
- `docs/USAGE.md` (every subcommand with examples)
- `docs/RUNBOOK.md` (operational procedures)
- `docs/ARCHITECTURE.md` (DDD layered overview)
- `docs/AGENT_INTEGRATION.md` — how AI coding agents call this CLI: subcommand contracts, JSON schemas, exit codes, idempotency guarantees, recommended invocation patterns
- `docs/EXAMPLES/minimal-project/` (Jira-only starter)
- `docs/EXAMPLES/doc-framework-product/` (full framework starter)
- `docs/EXAMPLES/agent-driven-workflow/` — sample agent prompt + invocation transcript showing the CLI used end-to-end

Verification: docs render cleanly on GitHub; example projects work when copied.

### PR 7 — CI + linting

Files added:
- `.github/workflows/ci.yml` (Python 3.12 only at floor; lint with ruff; test with stdlib unittest; build wheel)
- `.github/workflows/release.yml` (on tag, publish to PyPI; gated)
- `pyproject.toml` extended with `[tool.ruff]`

Verification: CI green on push.

### PR 8 — pip-installable polish

Files added:
- `MANIFEST.in` (if needed for example data)
- Project metadata in `pyproject.toml` (description, classifiers, urls)
- `docs/INSTALL.md`

Verification:
- `python -m build` produces a wheel
- `pip install dist/atlassiancli-X.Y.Z-py3-none-any.whl` in a fresh venv works
- `atlassiancli framework --help` runs

## 9. Self-containment criteria

When all 8 PRs land, atlassiancli must satisfy:

- [ ] **Zero pip deps at runtime.** `pyproject.toml` `dependencies` is `[]`. `pip install inovagio-atlassian` installs nothing from PyPI except stdlib-resolved packaging.
- [ ] **No imports outside `atlassiancli` + stdlib.** `grep -r "^import \|^from " src/atlassiancli/` shows only `import atlassiancli.*` and stdlib modules.
- [ ] **No project-specific hardcoded values.** All Jira project keys, Confluence space ids, page ids, label namespaces, summary prefixes come from config files, never source code.
- [ ] **Copy-deployable.** `cp -R src/atlassiancli/ /target/project/` then `python -m atlassiancli framework --help` works.
- [ ] **Pip-installable.** `python -m build` produces a wheel; `pip install <wheel>` works in fresh venv.
- [ ] **Agent-callable.** Every analyse / write subcommand has `--json` output mode; output validates against the schema in §6.2; exit codes follow the contract (0 success / non-zero failure / 75 transient / 77 auth); all writes are idempotent.

## 10. Decisions (signed off 2026-05-09)

| # | Decision | Value |
|---|---|---|
| 1 | Repo layout | `src/` (PEP 518 best practice for pip-installable) |
| 2 | Console entry-point | `atlassiancli` |
| 3 | Python version floor | **3.12** (match / structural pattern matching, modern type-hint generics, PEP 695 type aliases) |
| 4 | Test framework | `unittest` default (stdlib) — **configurable**: tests are written with `unittest.TestCase` so `pytest` runs them unchanged for contributors who prefer it |
| 5 | Lint tool | `ruff` default (dev-time only) — **configurable**: lint config follows PEP 8 + a small set of explicit rule selections so `flake8` / `pylint` / `pyflakes` also work |
| 6 | Versioning | semver, starting at `0.1.0` |
| 7 | License | MIT (already set) |
| 8 | Auth pattern | `ATLASSIAN_EMAIL` + `ATLASSIAN_TOKEN` env vars; `.env` file fallback; `~/.atlassiancli/config.yaml` profile system below that |
| 9 | Auto-publish to PyPI on tag | yes, gated by manual approval in `release.yml` |
| 10 | PyPI distribution name | `atlassiancli` (if available); alternatives reserved if taken: `atlassian-cli-tool`, `atlassiancli-app` |

### Configurability of test framework + lint tool

The defaults are stdlib + ruff to satisfy the zero-pip-dep runtime rule, but **dev-time tooling is not locked**:

- **Tests** live in `tests/` and use `unittest.TestCase`. `pytest` discovers and runs `TestCase` subclasses natively — `pip install pytest && pytest tests/` works for contributors who prefer it. CI runs the unittest path; nothing in the codebase precludes pytest as an alternative.
- **Lint config** is in `pyproject.toml` under `[tool.ruff]`, but the rule selection mirrors what `flake8` + plugins enforce (E / W / F / I / N / UP / B / C4 / SIM / RUF). A contributor running `flake8` against the codebase sees the same violations modulo a few ruff-specific rules. CI runs ruff; alternative tools are documented in `CONTRIBUTING.md` for contributors who want to use them.

This keeps the runtime promise (zero pip deps for users of the CLI) while not dictating dev-time tooling for contributors.

## 11. Future enhancements (post-PR-7)

- **Profile system** — `~/.atlassiancli/profiles.yaml` for multiple Atlassian sites with `--profile <name>` switch.
- **MCP integration** — bridge atlassiancli to Anthropic's Model Context Protocol so it works as a Claude tool.
- **Plugin architecture** — third-party subcommands discovered via Python entry points.
- **Optional `cryptography` extra** — `pip install inovagio-atlassian[crypto]` enables key-management subcommands.
- **`tomllib` config option** — Python 3.11+ stdlib TOML support as an alternative to YAML for the project config.
- **Async HTTP layer** — `asyncio`-based concurrent operations for bulk syncs.
