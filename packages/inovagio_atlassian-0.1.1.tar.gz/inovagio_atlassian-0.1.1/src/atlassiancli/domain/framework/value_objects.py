"""Value objects for the doc framework bridge tier.

Per PLAN §4 + §6.2. These are pure-stdlib, frozen dataclasses with light
validation: invalid construction raises ``ValueError`` at the boundary so
caller code can rely on shape constraints downstream.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

# ---------------------------------------------------------------------------
# Regex patterns shared by the value objects
# ---------------------------------------------------------------------------

# Product handles are lowercase alphanumeric with internal hyphens (matches
# directory naming convention under ``docs/<handle>/``).
_PRODUCT_HANDLE_RE = re.compile(r"^[a-z][a-z0-9]*(-[a-z0-9]+)*$")

# Story IDs follow ``S<phase>.<index>`` form, e.g. ``S4.6``.
_STORY_ID_RE = re.compile(r"^S\d+(\.\d+)?$")

# Epic short keys follow ``E-<NN>`` or ``E-<NNN>``.
_EPIC_KEY_RE = re.compile(r"^E-\d{2,3}$")


@dataclass(frozen=True)
class ProductHandle:
    """The directory-friendly handle for a product (e.g. ``mnemos``).

    Mirrors the ``<handle>`` segment in ``docs/<handle>/.docframework.yaml``.
    """

    handle: str

    def __post_init__(self) -> None:
        if not self.handle:
            raise ValueError("ProductHandle: handle must be non-empty")
        if not _PRODUCT_HANDLE_RE.match(self.handle):
            raise ValueError(
                f"ProductHandle: invalid handle {self.handle!r} — expected "
                "lowercase letters / digits / hyphens, must start with a letter"
            )

    def __str__(self) -> str:
        return self.handle


@dataclass(frozen=True)
class DocHandle:
    """A canonical handle for a top-level repo doc (e.g. ``ARCHITECTURE``).

    Used as the key in ``confluence.doc_pages`` to map handles -> page ids.
    """

    handle: str

    def __post_init__(self) -> None:
        if not self.handle:
            raise ValueError("DocHandle: handle must be non-empty")

    def __str__(self) -> str:
        return self.handle


@dataclass(frozen=True)
class EpicKey:
    """The short epic identifier (e.g. ``E-04``) used in manifests + config.

    Distinguished from a Jira-issue-key (``INOV-247``); the doc framework
    stores both — short keys identify epics in the manifest tree, Jira
    issue-keys are looked up via ``ProductConfig.jira.epics``.
    """

    short_key: str

    def __post_init__(self) -> None:
        if not _EPIC_KEY_RE.match(self.short_key):
            raise ValueError(
                f"EpicKey: invalid short key {self.short_key!r} — expected E-<NN> or E-<NNN>"
            )

    def __str__(self) -> str:
        return self.short_key


@dataclass(frozen=True)
class StoryId:
    """A manifest-side story identifier (e.g. ``S4.6``)."""

    story_id: str

    def __post_init__(self) -> None:
        if not _STORY_ID_RE.match(self.story_id):
            raise ValueError(
                f"StoryId: invalid id {self.story_id!r} — expected S<phase> or S<phase>.<index>"
            )

    def __str__(self) -> str:
        return self.story_id


__all__ = [
    "DocHandle",
    "EpicKey",
    "ProductHandle",
    "StoryId",
]
