"""Per-product framework config dataclasses.

Copied from ``inovagio/scripts/_docframework.py`` (the ``ProductConfig`` /
``JiraConfig`` / ``ConfluenceConfig`` / ``PathsConfig`` families). Pure
stdlib; pure data. The infrastructure layer's ``framework_config`` module
is responsible for loading and validating these from a
``.docframework.yaml`` file.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass
class JiraConfig:
    """Jira-side per-product settings (project, label namespace, epic map)."""

    cloud_site: str
    project_key: str
    default_assignee_email: str
    label_namespace: str
    summary_prefix: str
    epics: dict[str, str]


@dataclass
class ConfluenceConfig:
    """Confluence-side per-product settings (space, hub page, doc map)."""

    cloud_site: str
    space_key: str
    hub_page_id: str
    doc_pages: dict[str, str]


@dataclass
class PathsConfig:
    """Per-product directory layout under ``docs/<product>/``."""

    manifests_dir: str
    evidence_dir: str
    epic_docs_dir: str
    adr_dir: str


@dataclass
class ProductConfig:
    """Resolved per-product config used by every bridge service.

    Mirrors the structure of ``docs/<product>/.docframework.yaml``. Path
    fields are absolute — they're resolved by the loader against the docs
    root passed in at load time.
    """

    id: str
    name: str
    docs_dir: Path  # absolute path to docs/<product>/
    jira: JiraConfig
    confluence: ConfluenceConfig
    paths: PathsConfig

    @property
    def manifests_dir(self) -> Path:
        """``docs/<product>/<paths.manifests_dir>``."""
        return self.docs_dir / self.paths.manifests_dir

    @property
    def evidence_dir(self) -> Path:
        """``docs/<product>/<paths.evidence_dir>``."""
        return self.docs_dir / self.paths.evidence_dir

    @property
    def epic_docs_dir(self) -> Path:
        """``docs/<product>/<paths.epic_docs_dir>``."""
        return self.docs_dir / self.paths.epic_docs_dir

    @property
    def adr_dir(self) -> Path:
        """``docs/<product>/<paths.adr_dir>``."""
        return self.docs_dir / self.paths.adr_dir


__all__ = [
    "ConfluenceConfig",
    "JiraConfig",
    "PathsConfig",
    "ProductConfig",
]
