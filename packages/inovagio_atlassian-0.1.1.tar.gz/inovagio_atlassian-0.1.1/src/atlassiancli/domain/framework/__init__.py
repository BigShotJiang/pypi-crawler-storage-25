"""Doc framework domain layer — value objects + per-product config types."""
