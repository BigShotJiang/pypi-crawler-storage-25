#!/usr/bin/env python3
"""
Repository Interfaces

Abstractions for persistence operations.
Domain layer defines interfaces, infrastructure implements them.

Author: Inovagio Engineering Team
"""

from abc import ABC, abstractmethod
from typing import Any, Optional

from .models import Issue, Task
from .value_objects import ConfluencePageId, IssueKey, SprintIdentifier


class IIssueRepository(ABC):
    """
    Repository interface for Jira issues.

    Provides persistence abstraction - domain doesn't know about Jira API.
    """

    @abstractmethod
    def create(self, issue: Issue) -> IssueKey:
        """
        Create a new issue in Jira.

        Args:
            issue: Domain model to persist

        Returns:
            Generated issue key

        Raises:
            RepositoryError: If creation fails
        """

    @abstractmethod
    def find_by_key(self, key: IssueKey) -> Issue | None:
        """
        Find issue by key.

        Args:
            key: Issue key to find

        Returns:
            Domain model or None if not found
        """

    @abstractmethod
    def update(self, issue: Issue) -> bool:
        """
        Update an existing issue.

        Args:
            issue: Domain model with changes

        Returns:
            True if successful
        """

    @abstractmethod
    def delete(self, key: IssueKey) -> bool:
        """
        Delete an issue.

        Args:
            key: Issue key to delete

        Returns:
            True if successful
        """

    @abstractmethod
    def transition(self, key: IssueKey, transition_id: str) -> bool:
        """
        Transition an issue to a new status.

        Args:
            key: Issue key to transition
            transition_id: ID of the transition to perform

        Returns:
            True if successful
        """

    @abstractmethod
    def get_available_transitions(self, key: IssueKey) -> list[dict]:
        """
        Get available transitions for an issue.

        Args:
            key: Issue key

        Returns:
            List of transition objects (id, name, to_status)
        """

    @abstractmethod
    def find_by_sprint(self, sprint: SprintIdentifier) -> list[Issue]:
        """
        Find all issues in a sprint.

        Args:
            sprint: Sprint identifier

        Returns:
            List of issues
        """

    @abstractmethod
    def search(self, jql: str, max_results: int = 50) -> list[Issue]:
        """
        Search issues using JQL.

        Args:
            jql: JQL query string
            max_results: Maximum results to return

        Returns:
            List of matching issues
        """

    @abstractmethod
    def get_subtasks(self, parent_key: IssueKey) -> list[Task]:
        """
        Get all subtasks for a parent issue.

        Args:
            parent_key: Parent issue key

        Returns:
            List of subtasks
        """

    @abstractmethod
    def get_raw_issue(self, key: IssueKey, fields: list[str] | None = None) -> dict[str, Any]:
        """
        Get raw Jira issue payload (unmapped) for advanced analysis.

        Args:
            key: Issue key
            fields: Optional list of Jira fields to fetch

        Returns:
            Raw Jira issue JSON payload
        """

    @abstractmethod
    def get_remote_links(self, key: IssueKey) -> list[dict[str, Any]]:
        """
        Get Jira remote links for an issue.

        Args:
            key: Issue key

        Returns:
            List of raw remote link objects
        """


class IConfluenceRepository(ABC):
    """
    Repository interface for Confluence pages.

    Provides persistence abstraction for documentation.
    """

    @abstractmethod
    def create_page(
        self,
        space_key: str,
        title: str,
        content: str,
        parent_page_id: ConfluencePageId | None = None,
    ) -> ConfluencePageId:
        """
        Create a new Confluence page.

        Args:
            space_key: Confluence space (e.g., "INOV")
            title: Page title
            content: Page content (XHTML format)
            parent_page_id: Optional parent page

        Returns:
            Created page ID
        """

    @abstractmethod
    def find_page_by_title(self, space_key: str, title: str) -> ConfluencePageId | None:
        """
        Find page by exact title.

        Args:
            space_key: Confluence space
            title: Exact page title

        Returns:
            Page ID or None if not found
        """

    @abstractmethod
    def update_page(
        self,
        page_id: ConfluencePageId,
        title: str,
        content: str,
        parent_page_id: ConfluencePageId | None = None,
    ) -> bool:
        """
        Update an existing page.

        Args:
            page_id: Page to update
            title: New title
            content: New content
            parent_page_id: Optional new parent (to move page)

        Returns:
            True if successful
        """

    @abstractmethod
    def find_or_create_parent_page(
        self,
        space_key: str,
        parent_title: str,
        parent_content: str = "",
        under_parent_id: ConfluencePageId | None = None,
    ) -> ConfluencePageId:
        """
        Find or create organizational parent page.

        Args:
            space_key: Confluence space key
            parent_title: Title of the parent page
            parent_content: Content for the parent page (if creating)
            under_parent_id: Optional parent page to nest under

        Returns:
            ConfluencePageId of the parent page
        """

    @abstractmethod
    def get_page_url(self, page_id: ConfluencePageId) -> str:
        """
        Get the URL for a page.

        Args:
            page_id: Page ID

        Returns:
            Full URL to page
        """

    @abstractmethod
    def add_remote_link_to_jira(self, issue_key: IssueKey, page_url: str, link_title: str) -> bool:
        """
        Add a remote link from Jira issue to Confluence page.

        Args:
            issue_key: Jira issue to link from
            page_url: Confluence page URL
            link_title: Link display title

        Returns:
            True if successful
        """

    @abstractmethod
    def get_page(self, page_id: ConfluencePageId) -> Optional["ConfluencePage"]:
        """
        Get a page with its content.

        Args:
            page_id: Page to retrieve

        Returns:
            ConfluencePage with title, content, and metadata or None if not found
        """

    @abstractmethod
    def get_child_pages(self, parent_id: ConfluencePageId) -> list["ConfluencePage"]:
        """
        Get all child pages of a parent page.

        Args:
            parent_id: Parent page ID

        Returns:
            List of child pages with their content
        """


class ConfluencePage:
    """
    Value object representing a Confluence page with content.

    Used for reading pages (vs ConfluencePageId which is just an identifier).
    """

    def __init__(
        self,
        page_id: ConfluencePageId,
        title: str,
        content: str,
        space_key: str = "",
        version: int = 1,
    ):
        self.page_id = page_id
        self.title = title
        self.content = content
        self.space_key = space_key
        self.version = version

    def __repr__(self) -> str:
        return f"ConfluencePage(id={self.page_id}, title='{self.title}')"


class SearchCriteria:
    """Search criteria value object"""

    def __init__(
        self,
        issue_type: str | None = None,
        sprint: SprintIdentifier | None = None,
        epic_key: IssueKey | None = None,
        labels: list[str] | None = None,
    ):
        self.issue_type = issue_type
        self.sprint = sprint
        self.epic_key = epic_key
        self.labels = labels or []

    def to_jql(self) -> str:
        """Convert to JQL query string"""
        clauses = []

        if self.issue_type:
            clauses.append(f'type = "{self.issue_type}"')

        if self.sprint:
            clauses.append(f"sprint = {self.sprint.sprint_number}")

        if self.epic_key:
            clauses.append(f'"Epic Link" = {self.epic_key.key}')

        if self.labels:
            label_clause = " OR ".join(f'labels = "{label}"' for label in self.labels)
            clauses.append(f"({label_clause})")

        return " AND ".join(clauses) if clauses else "project = INOV"
