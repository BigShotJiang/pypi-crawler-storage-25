#!/usr/bin/env python3
"""
Domain Models - Rich Entities and Aggregates

Contains business logic and domain rules.
Models are NOT anemic - they encapsulate behavior.

Author: Inovagio Engineering Team
"""

from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any

from .events import DomainEvent, EpicCreatedEvent, IssueUpdatedEvent, StoryCreatedEvent
from .value_objects import (
    AcceptanceCriterion,
    AIReadinessLevel,
    BoundedContext,
    Component,
    IssueKey,
    IssueType,
    Label,
    Priority,
    SprintIdentifier,
    StoryPoints,
    Theme,
    ValidationResult,
)


class DomainError(Exception):
    """Base exception for domain errors"""


class ValidationError(DomainError):
    """Validation rule violation"""


class Issue(ABC):
    """
    Base aggregate root for all issue types.

    Encapsulates business rules and validation logic.
    Issues are aggregate roots that own their lifecycle.
    """

    def __init__(
        self,
        key: IssueKey | None,
        title: str,
        description: str,
        issue_type: IssueType,
        priority: Priority = Priority.MEDIUM,
    ):
        if not title or not title.strip():
            raise ValidationError("Title cannot be empty")

        if len(title) > 255:
            raise ValidationError(f"Title too long: {len(title)} chars (max 255)")

        self._key = key
        self._title = title.strip()
        self._description = description or ""
        self._issue_type = issue_type
        self._priority = priority

        # Collections
        self._labels: set[Label] = set()
        self._components: set[Component] = set()
        self._themes: set[Theme] = set()

        # Domain events
        self._domain_events: list[DomainEvent] = []

        # Metadata
        self._created_at: datetime | None = None
        self._updated_at: datetime | None = None
        self._sprint: SprintIdentifier | None = None

    # Properties
    @property
    def key(self) -> IssueKey | None:
        return self._key

    @property
    def title(self) -> str:
        return self._title

    @property
    def description(self) -> str:
        return self._description

    @property
    def issue_type(self) -> IssueType:
        return self._issue_type

    @property
    def sprint(self) -> SprintIdentifier | None:
        return self._sprint

    @property
    def priority(self) -> Priority:
        return self._priority

    @property
    def labels(self) -> set[Label]:
        return self._labels.copy()

    @property
    def components(self) -> set[Component]:
        return self._components.copy()

    @property
    def themes(self) -> set[Theme]:
        return self._themes.copy()

    @property
    def domain_events(self) -> list[DomainEvent]:
        """Get and clear domain events"""
        events = self._domain_events.copy()
        self._domain_events.clear()
        return events

    # Business methods
    def update_title(self, new_title: str):
        """Update title with validation"""
        if not new_title or not new_title.strip():
            raise ValidationError("Title cannot be empty")

        if len(new_title) > 255:
            raise ValidationError(f"Title too long: {len(new_title)} chars")

        old_title = self._title
        self._title = new_title.strip()
        self._updated_at = datetime.now()

        self._domain_events.append(IssueUpdatedEvent(self, {"title": (old_title, new_title)}))

    def update_description(self, new_description: Any):
        """Update description (supports plain text or ADF dict)"""
        self._description = new_description or ""
        self._updated_at = datetime.now()

        self._domain_events.append(IssueUpdatedEvent(self, {"description_updated": True}))

    def add_label(self, label: Label):
        """Add a label"""
        self._labels.add(label)
        self._updated_at = datetime.now()

    def remove_label(self, label: Label):
        """Remove a label"""
        self._labels.discard(label)
        self._updated_at = datetime.now()

    def clear_labels(self):
        """Clear all labels"""
        self._labels.clear()
        self._updated_at = datetime.now()

    def add_component(self, component: Component):
        """Add a component"""
        self._components.add(component)
        self._updated_at = datetime.now()

    def remove_component(self, component: Component):
        """Remove a component"""
        self._components.discard(component)
        self._updated_at = datetime.now()

    def clear_components(self):
        """Clear all components"""
        self._components.clear()
        self._updated_at = datetime.now()

    def add_theme(self, theme: Theme):
        """Add a theme"""
        self._themes.add(theme)

    def set_priority(self, priority: Priority):
        """Change priority"""
        old_priority = self._priority
        self._priority = priority
        self._updated_at = datetime.now()

        self._domain_events.append(IssueUpdatedEvent(self, {"priority": (old_priority, priority)}))

    def assign_to_sprint(self, sprint: SprintIdentifier):
        """Assign issue to a sprint"""
        self._sprint = sprint
        self._updated_at = datetime.now()

    @abstractmethod
    def validate(self) -> ValidationResult:
        """Validate domain rules - must be implemented by subclasses"""

    def __eq__(self, other) -> bool:
        """Issues are equal if they have the same key"""
        if not isinstance(other, Issue):
            return False
        if self._key is None or other._key is None:
            return False
        return self._key == other._key

    def __hash__(self) -> int:
        return hash(self._key) if self._key else hash(id(self))

    def __str__(self) -> str:
        key_str = str(self._key) if self._key else "NEW"
        return f"{self._issue_type.value} {key_str}: {self._title}"


class Epic(Issue):
    """
    Epic aggregate root.

    Business rules:
    - Must have objective
    - Must have success metrics (KPIs)
    - Can have up to 20 child stories
    - Must link to architecture documentation
    """

    def __init__(
        self,
        key: IssueKey | None,
        title: str,
        description: str,
        objective: str,
        bounded_context: BoundedContext,
        priority: Priority = Priority.MEDIUM,
    ):
        super().__init__(key, title, description, IssueType.EPIC, priority)

        if not objective or not objective.strip():
            raise ValidationError("Epic must have an objective")

        self._objective = objective.strip()
        self._bounded_context = bounded_context
        self._kpis: list[str] = []
        self._stories: list[Story] = []
        self._architecture_link: str | None = None
        self._in_scope: list[str] = []
        self._out_of_scope: list[str] = []

        # Raise domain event
        self._domain_events.append(EpicCreatedEvent(self))

    @property
    def objective(self) -> str:
        return self._objective

    @property
    def bounded_context(self) -> BoundedContext:
        return self._bounded_context

    @property
    def kpis(self) -> list[str]:
        return self._kpis.copy()

    @property
    def stories(self) -> list["Story"]:
        return self._stories.copy()

    @property
    def story_count(self) -> int:
        return len(self._stories)

    @property
    def architecture_link(self) -> str | None:
        return self._architecture_link

    @property
    def in_scope(self) -> list[str]:
        return self._in_scope.copy()

    @property
    def out_of_scope(self) -> list[str]:
        return self._out_of_scope.copy()

    def add_kpi(self, kpi: str):
        """Add success metric"""
        if not kpi or not kpi.strip():
            raise ValidationError("KPI cannot be empty")
        self._kpis.append(kpi.strip())

    def add_story(self, story: "Story"):
        """Add child story with business rule validation"""
        if len(self._stories) >= 20:
            raise DomainError(
                f"Epic cannot have more than 20 stories (current: {len(self._stories)})"
            )

        if story in self._stories:
            raise DomainError(f"Story already added: {story}")

        self._stories.append(story)
        self._updated_at = datetime.now()

    def remove_story(self, story: "Story"):
        """Remove child story"""
        if story in self._stories:
            self._stories.remove(story)
            self._updated_at = datetime.now()

    def set_architecture_link(self, url: str):
        """Link to architecture documentation"""
        if not url or not url.startswith("http"):
            raise ValidationError("Invalid architecture URL")
        self._architecture_link = url

    def define_scope(self, in_scope: list[str], out_of_scope: list[str]):
        """Define epic scope boundaries"""
        self._in_scope = [s.strip() for s in in_scope if s.strip()]
        self._out_of_scope = [s.strip() for s in out_of_scope if s.strip()]

    def validate(self) -> ValidationResult:
        """Validate epic business rules"""
        errors = []
        warnings = []

        # Required fields
        if not self._objective:
            errors.append("Epic must have objective")

        if not self._kpis:
            errors.append("Epic must have at least one KPI")

        if not self._bounded_context:
            errors.append("Epic must be assigned to a bounded context")

        # Warnings
        if not self._architecture_link:
            warnings.append("Epic should link to architecture documentation")

        if not self._in_scope:
            warnings.append("Epic should define in-scope capabilities")

        if not self._out_of_scope:
            warnings.append("Epic should define out-of-scope items")

        if self.story_count == 0:
            warnings.append("Epic has no child stories")

        if self.story_count > 15:
            warnings.append(f"Epic has many stories ({self.story_count}), consider splitting")

        return ValidationResult(
            is_valid=len(errors) == 0, errors=tuple(errors), warnings=tuple(warnings)
        )


class Story(Issue):
    """
    Story aggregate root.

    Business rules:
    - Must have acceptance criteria
    - Must be assigned to bounded context
    - Story points must be 1-8 (larger stories should be split)
    - Must have user/system intent
    - AI-readiness score determines if implementable
    """

    def __init__(
        self,
        key: IssueKey | None,
        title: str,
        description: str,
        bounded_context: BoundedContext,
        epic_key: IssueKey | None = None,
        priority: Priority = Priority.MEDIUM,
    ):
        super().__init__(key, title, description, IssueType.STORY, priority)

        self._bounded_context = bounded_context
        self._epic_key = epic_key
        self._acceptance_criteria: list[AcceptanceCriterion] = []
        self._story_points: StoryPoints | None = None
        self._subtasks: list[Task] = []
        self._original_story_points: int | None = None

        # AI readiness tracking
        self._ai_readiness_level = AIReadinessLevel.NOT_READY
        self._ai_readiness_score = 0

        # Technical details
        self._affected_modules: list[str] = []
        self._integration_points: list[str] = []

        # Documentation fields (for Confluence Story Spec)
        self._story_intent: str = ""
        self._problem_statement: str = ""
        self._proposed_solution: str = ""
        self._functional_requirements: list[str] = []
        self._nonfunctional_requirements: list[str] = []
        self._security_requirements: list[str] = []
        self._unit_test_spec: str = ""
        self._integration_test_spec: str = ""
        self._test_data_and_mocks: str = ""
        self._cicd_requirements: str = ""
        self._observability_spec: str = ""
        self._rollback_strategy: str = ""

        # Raise domain event
        self._domain_events.append(StoryCreatedEvent(self))

    @property
    def bounded_context(self) -> BoundedContext:
        return self._bounded_context

    @property
    def epic_key(self) -> IssueKey | None:
        return self._epic_key

    @property
    def acceptance_criteria(self) -> list[AcceptanceCriterion]:
        return self._acceptance_criteria.copy()

    @property
    def story_points(self) -> StoryPoints | None:
        return self._story_points

    @property
    def subtasks(self) -> list["Task"]:
        return self._subtasks.copy()

    @property
    def ai_readiness_level(self) -> AIReadinessLevel:
        return self._ai_readiness_level

    @property
    def ai_readiness_score(self) -> int:
        return self._ai_readiness_score

    @property
    def affected_modules(self) -> list[str]:
        return self._affected_modules.copy()

    @property
    def integration_points(self) -> list[str]:
        return self._integration_points.copy()

    @property
    def story_intent(self) -> str:
        return self._story_intent

    @property
    def problem_statement(self) -> str:
        return self._problem_statement

    @property
    def proposed_solution(self) -> str:
        return self._proposed_solution

    @property
    def functional_requirements(self) -> list[str]:
        return self._functional_requirements.copy()

    @property
    def nonfunctional_requirements(self) -> list[str]:
        return self._nonfunctional_requirements.copy()

    @property
    def security_requirements(self) -> list[str]:
        return self._security_requirements.copy()

    @property
    def unit_test_spec(self) -> str:
        return self._unit_test_spec

    @property
    def integration_test_spec(self) -> str:
        return self._integration_test_spec

    @property
    def test_data_and_mocks(self) -> str:
        return self._test_data_and_mocks

    @property
    def cicd_requirements(self) -> str:
        return self._cicd_requirements

    @property
    def observability_spec(self) -> str:
        return self._observability_spec

    @property
    def rollback_strategy(self) -> str:
        return self._rollback_strategy

    def set_story_intent(self, intent: str):
        """Set story intent"""
        self._story_intent = intent or ""
        self._updated_at = datetime.now()

    def set_problem_statement(self, statement: str):
        """Set problem statement"""
        self._problem_statement = statement or ""
        self._updated_at = datetime.now()

    def set_proposed_solution(self, solution: str):
        """Set proposed solution"""
        self._proposed_solution = solution or ""
        self._updated_at = datetime.now()

    def set_epic(self, epic_key: IssueKey):
        """Link story to an epic"""
        self._epic_key = epic_key
        self._updated_at = datetime.now()

    def set_security_requirements(self, requirements: list[str]):
        """Set security requirements"""
        self._security_requirements = requirements or []
        self._updated_at = datetime.now()

    def set_unit_test_spec(self, spec: str):
        """Set unit test specification"""
        self._unit_test_spec = spec or ""
        self._updated_at = datetime.now()

    def set_integration_test_spec(self, spec: str):
        """Set integration test specification"""
        self._integration_test_spec = spec or ""
        self._updated_at = datetime.now()

    def set_observability_spec(self, spec: str):
        """Set observability specification"""
        self._observability_spec = spec or ""
        self._updated_at = datetime.now()

    def set_rollback_strategy(self, strategy: str):
        """Set rollback strategy"""
        self._rollback_strategy = strategy or ""
        self._updated_at = datetime.now()

    def add_acceptance_criterion(self, criterion: AcceptanceCriterion):
        """Add acceptance criterion"""
        if criterion in self._acceptance_criteria:
            return  # Already exists
        self._acceptance_criteria.append(criterion)
        self._recalculate_ai_readiness()

    def set_story_points(self, points: StoryPoints):
        """Set story points with validation"""
        if points.value > 8:
            raise DomainError(
                f"Story points too high ({points.value}). "
                "Stories > 8 SP should be split into smaller stories."
            )
        self._story_points = points

    def assign_to_sprint(self, sprint: SprintIdentifier):
        """Assign to sprint"""
        self._sprint = sprint
        self._updated_at = datetime.now()

    def add_subtask(self, subtask: "Task"):
        """Add subtask"""
        if subtask in self._subtasks:
            raise DomainError(f"Subtask already added: {subtask}")
        self._subtasks.append(subtask)

    def add_affected_module(self, module_path: str):
        """Track affected codebase modules"""
        if module_path not in self._affected_modules:
            self._affected_modules.append(module_path)

    def add_integration_point(self, integration: str):
        """Track integration points"""
        if integration not in self._integration_points:
            self._integration_points.append(integration)

    def calculate_ai_readiness(self) -> AIReadinessLevel:
        """
        Calculate AI-executable readiness level.

        Scoring criteria:
        - Description quality: 20 points
        - Acceptance criteria: 30 points
        - Bounded context: 15 points
        - Affected modules: 15 points
        - Integration points: 10 points
        - Gherkin format: 10 points
        """
        score = 0

        # Description
        if self._description:
            if len(self._description) > 200:
                score += 20
            elif len(self._description) > 50:
                score += 10

        # Acceptance criteria
        if len(self._acceptance_criteria) >= 3:
            score += 30
        elif len(self._acceptance_criteria) >= 1:
            score += 15

        # Bounded context
        if self._bounded_context:
            score += 15

        # Technical details
        if self._affected_modules:
            score += 15

        if self._integration_points:
            score += 10

        # Gherkin format
        gherkin_count = sum(1 for ac in self._acceptance_criteria if ac.is_gherkin)
        if gherkin_count >= 2:
            score += 10
        elif gherkin_count >= 1:
            score += 5

        self._ai_readiness_score = score

        # Determine level
        if score >= 90:
            self._ai_readiness_level = AIReadinessLevel.OPTIMAL
        elif score >= 70:
            self._ai_readiness_level = AIReadinessLevel.READY
        elif score >= 40:
            self._ai_readiness_level = AIReadinessLevel.INCOMPLETE
        else:
            self._ai_readiness_level = AIReadinessLevel.NOT_READY

        return self._ai_readiness_level

    def _recalculate_ai_readiness(self):
        """Recalculate AI readiness when criteria change"""
        self.calculate_ai_readiness()

    def validate(self) -> ValidationResult:
        """Validate story business rules"""
        errors = []
        warnings = []

        # Required fields
        if not self._bounded_context:
            errors.append("Story must be assigned to bounded context")

        if not self._acceptance_criteria:
            errors.append("Story must have acceptance criteria")

        # Warnings
        if not self._epic_key:
            warnings.append("Story not linked to an epic")

        if not self._story_points:
            warnings.append("Story points not set")

        if self._story_points and self._story_points.value > 5:
            warnings.append(f"Story is large ({self._story_points} SP), consider splitting")

        if len(self._acceptance_criteria) < 3:
            warnings.append("Story has few acceptance criteria (< 3)")

        if not any(ac.is_gherkin for ac in self._acceptance_criteria):
            warnings.append("Acceptance criteria not in Gherkin format (GIVEN/WHEN/THEN)")

        # AI readiness
        readiness = self.calculate_ai_readiness()
        if readiness in [AIReadinessLevel.NOT_READY, AIReadinessLevel.INCOMPLETE]:
            warnings.append(
                f"Story not AI-ready (level: {readiness.value}, score: {self._ai_readiness_score}/100)"
            )

        return ValidationResult(
            is_valid=len(errors) == 0, errors=tuple(errors), warnings=tuple(warnings)
        )


class Task(Issue):
    """
    Task entity (not an aggregate root - owned by Story).

    Business rules:
    - Must have parent story
    - Should be completable in < 1 day
    - Has implementation steps
    """

    def __init__(
        self,
        key: IssueKey | None,
        title: str,
        description: str,
        parent_story_key: IssueKey,
        priority: Priority = Priority.MEDIUM,
        bounded_context: BoundedContext | None = None,
        issue_type: IssueType = IssueType.TASK,
    ):
        super().__init__(key, title, description, issue_type, priority)

        self._parent_story_key = parent_story_key
        self._bounded_context = bounded_context
        self._implementation_steps: list[str] = []
        self._estimated_hours: int | None = None
        self._story_points: StoryPoints | None = None

    @property
    def parent_story_key(self) -> IssueKey:
        return self._parent_story_key

    @property
    def bounded_context(self) -> BoundedContext | None:
        return self._bounded_context

    @property
    def implementation_steps(self) -> list[str]:
        return self._implementation_steps.copy()

    @property
    def estimated_hours(self) -> int | None:
        return self._estimated_hours

    @property
    def story_points(self) -> StoryPoints | None:
        return self._story_points

    def set_story_points(self, points: StoryPoints):
        """Set story points"""
        self._story_points = points

    def add_implementation_step(self, step: str):
        """Add implementation step"""
        if step and step.strip():
            self._implementation_steps.append(step.strip())

    def set_estimated_hours(self, hours: int):
        """Set time estimate"""
        if hours < 0:
            raise ValidationError("Estimated hours cannot be negative")
        if hours > 8:
            raise DomainError(
                f"Task too large ({hours}h). Tasks should be < 8 hours. Consider splitting."
            )
        self._estimated_hours = hours

    def validate(self) -> ValidationResult:
        """Validate task business rules"""
        errors = []
        warnings = []

        # Required
        if not self._parent_story_key:
            errors.append("Task must have parent story")

        # Warnings
        if not self._implementation_steps:
            warnings.append("Task has no implementation steps")

        if not self._estimated_hours:
            warnings.append("Task has no time estimate")

        if self._estimated_hours and self._estimated_hours > 4:
            warnings.append(f"Task is large ({self._estimated_hours}h), consider splitting")

        return ValidationResult(
            is_valid=len(errors) == 0, errors=tuple(errors), warnings=tuple(warnings)
        )
