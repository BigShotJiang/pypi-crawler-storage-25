#!/usr/bin/env python3
"""
Domain Service Interfaces

Stateless services that encapsulate domain logic that doesn't
belong to a single entity or value object.

Author: Inovagio Engineering Team
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from .value_objects import BoundedContext, IssueType, Theme

# ============================================================================
# DOCUMENT IMPORT/ANALYSIS - PROPER SEPARATION OF CONCERNS
# ============================================================================
#
# Architecture (DRY + SRP):
#
#   IDocumentImporter (many implementations)
#         │
#         ▼
#   ImportedDocument (normalized content)
#         │
#         ▼
#   IDocumentAnalyzer (ONE implementation)
#         │
#         ▼
#   DocumentAnalysisResult (work items)
#
# This ensures:
# - Import logic is NOT duplicated in each analyzer
# - Analysis logic is NOT duplicated in each importer
# - Adding new sources only requires a new importer
# ============================================================================


class DocumentSource(Enum):
    """Enum representing document source types"""

    MARKDOWN_FILE = "markdown_file"
    CONFLUENCE_PAGE = "confluence_page"
    YAML_FILE = "yaml_file"
    TEXT_CONTENT = "text_content"


@dataclass
class ImportedDocument:
    """
    Normalized document content from any source.

    This is the BOUNDARY between importers and analyzers.
    All importers produce this; the single analyzer consumes it.

    DRY PRINCIPLE: One format, many importers, one analyzer.
    """

    source: DocumentSource
    source_path: str  # File path, page ID, or URL
    title: str = ""
    content: str = ""  # Raw content (markdown, HTML, etc.)
    content_format: str = "markdown"  # markdown, html, yaml
    sections: list[dict[str, Any]] = field(default_factory=list)  # [{title, content, level}]
    metadata: dict[str, Any] = field(default_factory=dict)  # Source-specific metadata
    children: list["ImportedDocument"] = field(default_factory=list)  # Child pages/files
    import_errors: list[str] = field(default_factory=list)

    @property
    def is_valid(self) -> bool:
        return bool(self.content or self.sections) and not self.import_errors


class IDocumentImporter(ABC):
    """
    Interface for importing documents from various sources.

    RESPONSIBILITY: Fetch/read content and normalize to ImportedDocument.
    Does NOT analyze or extract work items - that's the analyzer's job.

    SOLID COMPLIANCE:
    - Single Responsibility: Only imports, doesn't analyze
    - Interface Segregation: Clean import contract
    - Open/Closed: New sources = new importer, no analyzer changes

    Implementations:
    - MarkdownFileImporter: Read local .md files
    - ConfluencePageImporter: Fetch Confluence pages via API
    - YamlFileImporter: Read local .yaml/.yml files
    """

    @abstractmethod
    def import_document(
        self, source: str, include_children: bool = False, **kwargs
    ) -> ImportedDocument:
        """
        Import a document from the source.

        Args:
            source: Source identifier (file path, page ID, URL)
            include_children: Include child documents (for hierarchical sources)
            **kwargs: Source-specific options

        Returns:
            ImportedDocument with normalized content
        """

    @abstractmethod
    def get_source_type(self) -> DocumentSource:
        """Get the document source type this importer handles."""

    @abstractmethod
    def supports_source(self, source: str) -> bool:
        """
        Check if this importer can handle the given source.

        Args:
            source: Source identifier to check

        Returns:
            True if this importer can handle the source
        """


@dataclass
class ParsedWorkItem:
    """
    Unified value object for work items parsed from any document source.

    DRY PRINCIPLE: Single definition used by all parsers.
    This replaces:
    - importers.py: ParsedRequirement, ExtractedWorkItem
    - confluence_importer.py: ImplementationWorkItem, ArchitecturalComponent
    """

    title: str
    description: str = ""
    work_type: IssueType = IssueType.STORY
    acceptance_criteria: list[str] = field(default_factory=list)
    technical_requirements: list[str] = field(default_factory=list)
    children: list["ParsedWorkItem"] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)
    bounded_context: str = "core-models"
    story_points: int | None = None
    priority: str = "Medium"
    labels: list[str] = field(default_factory=list)
    themes: list[str] = field(default_factory=list)
    parent_epic: str | None = None
    source_page: str | None = None
    source_component: str | None = None
    jira_key: str | None = None

    def __post_init__(self):
        """Ensure work_type is IssueType enum"""
        if isinstance(self.work_type, str):
            self.work_type = IssueType(self.work_type)


@dataclass
class DocumentAnalysisResult:
    """
    Unified value object for document analysis results.

    DRY PRINCIPLE: Single definition used by all analyzers.
    This replaces:
    - importers.py: ImportPlan
    - confluence_importer.py: AnalysisResult
    """

    success: bool
    source: DocumentSource
    source_path: str = ""
    epics: list[ParsedWorkItem] = field(default_factory=list)
    stories: list[ParsedWorkItem] = field(default_factory=list)
    tasks: list[ParsedWorkItem] = field(default_factory=list)
    orphan_stories: list[ParsedWorkItem] = field(default_factory=list)
    pages_analyzed: int = 0
    analysis_notes: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    @property
    def total_epics(self) -> int:
        return len(self.epics)

    @property
    def total_stories(self) -> int:
        return len(self.stories) + sum(
            len(e.children) for e in self.epics if e.work_type == IssueType.EPIC
        )

    @property
    def total_tasks(self) -> int:
        return len(self.tasks)

    @property
    def total_items(self) -> int:
        return self.total_epics + self.total_stories + self.total_tasks

    def get_summary(self) -> str:
        """Get human-readable summary of analysis results"""
        lines = [
            f"📄 DOCUMENT ANALYSIS RESULTS ({self.source.value})",
            "=" * 50,
            f"Source: {self.source_path}",
            f"Status: {'✅ Success' if self.success else '❌ Failed'}",
            "",
            "📊 WORK ITEMS EXTRACTED:",
            f"  • Epics: {self.total_epics}",
            f"  • Stories: {self.total_stories}",
            f"  • Tasks: {self.total_tasks}",
            f"  • Orphan Stories: {len(self.orphan_stories)}",
            f"  • Total: {self.total_items}",
        ]

        if self.pages_analyzed > 0:
            lines.append(f"  • Pages Analyzed: {self.pages_analyzed}")

        if self.analysis_notes:
            lines.append("")
            lines.append("📝 ANALYSIS NOTES:")
            for note in self.analysis_notes[:5]:  # First 5 notes
                lines.append(f"  • {note}")

        if self.errors:
            lines.append("")
            lines.append("❌ ERRORS:")
            for error in self.errors:
                lines.append(f"  • {error}")

        return "\n".join(lines)


class IDocumentAnalyzer(ABC):
    """
    Domain service interface for analyzing documents and extracting work items.

    ARCHITECTURE:
    - Receives ImportedDocument (normalized content from any importer)
    - Extracts work items using a SINGLE analysis algorithm
    - Returns DocumentAnalysisResult with epics/stories/tasks

    SOLID COMPLIANCE:
    - Single Responsibility: Only analyzes, doesn't import
    - Open/Closed: One analyzer, many importers
    - Dependency Inversion: Works with ImportedDocument abstraction

    DRY COMPLIANCE:
    - ONE analysis implementation (no duplicate logic per source)
    - Unified return types (DocumentAnalysisResult, ParsedWorkItem)
    - Source-agnostic work item extraction

    USAGE:
        importer = MarkdownFileImporter()  # or ConfluencePageImporter
        document = importer.import_document(source)
        analyzer = DocumentAnalyzer(theme_detector, context_resolver)
        result = analyzer.analyze(document)
    """

    @abstractmethod
    def analyze(self, document: "ImportedDocument") -> DocumentAnalysisResult:
        """
        Analyze an imported document and extract work items.

        This is the SINGLE analysis entry point. The document has already
        been imported and normalized by an IDocumentImporter.

        Args:
            document: Normalized ImportedDocument from any importer

        Returns:
            DocumentAnalysisResult with extracted work items
        """

    @abstractmethod
    def extract_work_items(self, document: "ImportedDocument") -> list[ParsedWorkItem]:
        """
        Extract work items (epics/stories/tasks) from document content.

        Args:
            document: Normalized ImportedDocument

        Returns:
            List of ParsedWorkItem objects
        """

    @abstractmethod
    def extract_architectural_components(
        self, document: "ImportedDocument"
    ) -> list[dict[str, Any]]:
        """
        Extract architectural components (interfaces, services, etc.) from document.

        Used for architecture documentation analysis.

        Args:
            document: Normalized ImportedDocument

        Returns:
            List of architectural component dictionaries
        """


class IThemeDetector(ABC):
    """
    Domain service interface for detecting themes from text.

    Single source of truth for theme detection logic.
    """

    @abstractmethod
    def detect_themes(self, text: str) -> list[Theme]:
        """
        Detect themes from text content.

        Args:
            text: Text to analyze (title + description)

        Returns:
            List of detected themes
        """


class IBoundedContextResolver(ABC):
    """
    Domain service interface for resolving bounded context from themes.

    Maps themes to the appropriate bounded context in the architecture.
    """

    @abstractmethod
    def resolve_context(self, themes: list[Theme], text: str = "") -> BoundedContext:
        """
        Resolve bounded context from themes and text.

        Args:
            themes: Detected themes
            text: Optional text for additional context

        Returns:
            Resolved bounded context
        """

    @abstractmethod
    def get_all_contexts(self) -> list[BoundedContext]:
        """
        Get all available bounded contexts.

        Returns:
            List of all bounded contexts in the system
        """


class ILabelDeriver(ABC):
    """
    Domain service for deriving Jira labels from themes.
    """

    @abstractmethod
    def derive_labels(self, themes: list[Theme]) -> list[str]:
        """
        Derive Jira labels from themes.

        Args:
            themes: Themes to convert

        Returns:
            List of label strings (lowercase, no spaces)
        """


class IComponentDeriver(ABC):
    """
    Domain service for deriving Jira components from themes.
    """

    @abstractmethod
    def derive_components(self, themes: list[Theme]) -> list[str]:
        """
        Derive Jira components from themes.

        Args:
            themes: Themes to convert

        Returns:
            List of component names
        """


class IPriorityCalculator(ABC):
    """
    Domain service for calculating issue priority.
    """

    @abstractmethod
    def calculate_priority(self, issue_type: str, themes: list[Theme], description: str) -> str:
        """
        Calculate priority based on issue type and context.

        Args:
            issue_type: Type of issue (Epic, Story, Task)
            themes: Associated themes
            description: Issue description

        Returns:
            Priority name (Highest, High, Medium, Low)
        """


class IStoryPointEstimator(ABC):
    """
    Domain service for estimating story points.
    """

    @abstractmethod
    def estimate_story_points(self, title: str, description: str) -> int:
        """
        Estimate story points based on complexity keywords.

        Args:
            title: Issue title
            description: Issue description

        Returns:
            Estimated story points (Fibonacci: 1, 2, 3, 5, 8)
        """


class IDuplicateDetector(ABC):
    """
    Domain service interface for detecting duplicate/similar issues.

    Searches existing Jira issues to prevent creating duplicates.
    Implements Jaccard word similarity matching.
    """

    @abstractmethod
    def find_similar_issues(
        self, title: str, issue_type: str = "Epic", threshold: float = 0.3
    ) -> list["SimilarityMatch"]:
        """
        Find existing Jira issues with similar titles.

        Uses JQL text search combined with Jaccard word similarity scoring.

        Args:
            title: Title to search for similar issues
            issue_type: Issue type to search ("Epic", "Story", "Task")
            threshold: Minimum similarity score (0.0-1.0) to include in results
                      Default 0.3 (30% word overlap)

        Returns:
            List of SimilarityMatch objects sorted by similarity (highest first)
        """

    @abstractmethod
    def calculate_similarity(self, title1: str, title2: str) -> float:
        """
        Calculate similarity score between two titles.

        Uses Jaccard similarity coefficient: |A ∩ B| / |A ∪ B|

        Args:
            title1: First title
            title2: Second title

        Returns:
            Similarity score from 0.0 (no overlap) to 1.0 (identical)
        """

    @abstractmethod
    def is_potential_duplicate(self, title: str, issue_type: str = "Epic") -> bool:
        """
        Quick check if title is likely a duplicate of existing issue.

        Args:
            title: Title to check
            issue_type: Issue type to search

        Returns:
            True if a similar issue exists (>60% similarity)
        """


# Import for forward reference


@dataclass
class SimilarityMatch:
    """
    Value object representing a similarity match result.

    Contains the matched issue details and similarity score.
    """

    issue_key: str  # e.g., "INOV-123"
    summary: str  # Matched issue title
    status: str  # Issue status (e.g., "To Do", "In Progress")
    similarity: float  # Jaccard similarity score (0.0-1.0)
    matched_title: str  # The title we searched for

    @property
    def is_high_match(self) -> bool:
        """Check if this is a high-confidence match (>60% similarity)"""
        return self.similarity > 0.6

    @property
    def is_likely_duplicate(self) -> bool:
        """Check if this is likely a duplicate (>80% similarity)"""
        return self.similarity > 0.8

    @property
    def recommendation(self) -> str:
        """Get recommendation based on similarity level"""
        if self.similarity > 0.8:
            return f"⚠️ LIKELY DUPLICATE - Consider linking to {self.issue_key} instead"
        elif self.similarity > 0.6:
            return f"⚡ HIGH MATCH - Review {self.issue_key} before creating"
        elif self.similarity > 0.3:
            return f"ℹ️ RELATED - May overlap with {self.issue_key}"
        return ""

    def __str__(self) -> str:
        return f"{self.issue_key}: {self.summary} ({self.similarity:.0%} similar)"


# ============================================================================
# CODEBASE CROSS-REFERENCER - Validates against actual codebase
# ============================================================================


@dataclass
class ExistingInterface:
    """
    Value object representing an interface found in the codebase.
    """

    name: str  # Interface name (e.g., "IExecutor")
    file_path: str  # Relative path from workspace root
    line_number: int  # Line where interface is defined
    bounded_context: str  # Which bounded context it belongs to
    methods: list[str] = field(default_factory=list)  # Method signatures
    documentation: str = ""  # Doxygen/doc comment if found

    @property
    def full_qualified_name(self) -> str:
        """Get namespace-qualified name"""
        return f"{self.bounded_context}::{self.name}"

    def __str__(self) -> str:
        return f"{self.name} ({self.file_path}:{self.line_number})"


@dataclass
class ExistingImplementation:
    """
    Value object representing an implementation found in the codebase.
    """

    name: str  # Class name
    file_path: str  # Relative path from workspace root
    line_number: int  # Line where class is defined
    bounded_context: str  # Which bounded context it belongs to
    implements: list[str] = field(default_factory=list)  # Interfaces it implements

    def __str__(self) -> str:
        return f"{self.name} implements {', '.join(self.implements) or 'N/A'}"


@dataclass
class CodebaseValidationResult:
    """
    Value object containing results of codebase cross-reference validation.
    """

    # What exists in the codebase
    existing_interfaces: list[ExistingInterface] = field(default_factory=list)
    existing_implementations: list[ExistingImplementation] = field(default_factory=list)

    # What the proposed work would create
    proposed_interfaces: list[str] = field(default_factory=list)
    proposed_implementations: list[str] = field(default_factory=list)

    # Validation results
    already_exists: list[str] = field(default_factory=list)  # Work items that already exist
    partially_exists: list[str] = field(default_factory=list)  # Interface exists, needs impl
    valid_new_work: list[str] = field(default_factory=list)  # Genuinely new work

    # Domain vocabulary validation
    unknown_terms: list[str] = field(default_factory=list)  # Terms not in glossary
    suggested_terms: dict[str, str] = field(default_factory=dict)  # unknown -> suggested

    @property
    def has_conflicts(self) -> bool:
        """Check if any proposed work already exists"""
        return len(self.already_exists) > 0

    @property
    def validation_summary(self) -> str:
        """Get human-readable summary"""
        lines = []
        if self.already_exists:
            lines.append(f"⚠️  {len(self.already_exists)} items ALREADY EXIST in codebase")
        if self.partially_exists:
            lines.append(f"ℹ️  {len(self.partially_exists)} items PARTIALLY EXIST (interface only)")
        if self.valid_new_work:
            lines.append(f"✅ {len(self.valid_new_work)} items are VALID NEW WORK")
        if self.unknown_terms:
            lines.append(f"📝 {len(self.unknown_terms)} terms not found in domain glossary")
        return "\n".join(lines) if lines else "No validation issues"


@dataclass
class ContextMapEntry:
    """
    Value object representing a bounded context from context_map.md.
    """

    name: str  # e.g., "Core-ANI"
    layer: int  # 0-4
    responsibilities: list[str] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)
    integration_patterns: dict[str, str] = field(default_factory=dict)


@dataclass
class GlossaryTerm:
    """
    Value object representing a term from domain_glossary.md.
    """

    term: str  # The term itself
    definition: str  # Full definition
    category: str = ""  # Category heading
    aliases: list[str] = field(default_factory=list)


class ICodebaseCrossReferencer(ABC):
    """
    Domain service interface for cross-referencing with actual codebase.

    Scans the Inovagio codebase to:
    1. Find existing interfaces (I*.hpp)
    2. Find existing implementations
    3. Read context_map.md for bounded context validation
    4. Read domain_glossary.md for ubiquitous language validation

    This ensures proposed Jira issues don't duplicate existing work.
    """

    @abstractmethod
    def scan_codebase(self, workspace_root: str) -> None:
        """
        Scan the codebase to build knowledge base.

        Reads:
        - core/**/*.hpp for interfaces and classes
        - docs/architecture/context_map.md for bounded contexts
        - docs/architecture/domain_glossary.md for domain terms

        Args:
            workspace_root: Absolute path to workspace root
        """

    @abstractmethod
    def get_existing_interfaces(
        self, bounded_context: str | None = None
    ) -> list[ExistingInterface]:
        """
        Get all interfaces found in codebase.

        Args:
            bounded_context: Optional filter by bounded context name

        Returns:
            List of ExistingInterface objects
        """

    @abstractmethod
    def get_existing_implementations(
        self, interface_name: str | None = None
    ) -> list[ExistingImplementation]:
        """
        Get all implementations found in codebase.

        Args:
            interface_name: Optional filter by interface name

        Returns:
            List of ExistingImplementation objects
        """

    @abstractmethod
    def interface_exists(self, name: str) -> bool:
        """
        Check if an interface already exists in codebase.

        Args:
            name: Interface name (with or without 'I' prefix)

        Returns:
            True if interface exists
        """

    @abstractmethod
    def get_context_map(self) -> dict[str, ContextMapEntry]:
        """
        Get parsed context map from docs/architecture/context_map.md.

        Returns:
            Dict mapping context name to ContextMapEntry
        """

    @abstractmethod
    def get_scan_summary(self) -> str:
        """
        Get a summary of the codebase scan.

        Returns:
            Summary string
        """

    @abstractmethod
    def get_glossary_terms(self) -> dict[str, GlossaryTerm]:
        """
        Get parsed glossary from docs/architecture/domain_glossary.md.

        Returns:
            Dict mapping term name to GlossaryTerm
        """

    @abstractmethod
    def validate_proposed_work(
        self,
        proposed_interfaces: list[str],
        proposed_implementations: list[str],
        terms_used: list[str],
    ) -> CodebaseValidationResult:
        """
        Validate proposed work items against codebase.

        Args:
            proposed_interfaces: Interface names to create
            proposed_implementations: Implementation names to create
            terms_used: Domain terms used in descriptions

        Returns:
            CodebaseValidationResult with validation details
        """

    @abstractmethod
    def validate_architecture(self, analysis: "DocumentAnalysisResult") -> CodebaseValidationResult:
        """
        Validate architecture from document analysis against codebase.

        Args:
            analysis: Document analysis result

        Returns:
            CodebaseValidationResult with validation details
        """

    @abstractmethod
    def suggest_bounded_context(self, title: str, description: str) -> str:
        """
        Suggest appropriate bounded context based on content.

        Uses context_map.md knowledge to suggest the right context.

        Args:
            title: Issue title
            description: Issue description

        Returns:
            Suggested bounded context name
        """

    @abstractmethod
    def validate_layer_dependencies(self, from_context: str, to_context: str) -> bool:
        """
        Validate that a dependency between contexts is allowed.

        Rules: Layer N can depend on Layer N-1 only (no upward dependencies).

        Args:
            from_context: Context that depends
            to_context: Context being depended on

        Returns:
            True if dependency is allowed
        """


# ============================================================================
# BACKLOG ANALYZER - Comprehensive Jira backlog scanning
# ============================================================================


@dataclass
class BacklogEpic:
    """
    Value object representing an epic in the backlog.
    """

    key: str  # e.g., "INOV-123"
    summary: str  # Epic title
    status: str  # Epic status
    bounded_context: str  # Which context this epic belongs to
    labels: list[str] = field(default_factory=list)
    child_count: int = 0  # Number of child issues
    completed_count: int = 0  # Number of completed children
    assignee: str = ""  # Current assignee

    @property
    def progress_percent(self) -> int:
        """Get completion percentage"""
        if self.child_count == 0:
            return 0
        return int((self.completed_count / self.child_count) * 100)

    @property
    def is_in_progress(self) -> bool:
        """Check if epic is actively being worked on"""
        return self.status.lower() in ("in progress", "development", "in review")

    def __str__(self) -> str:
        return f"{self.key}: {self.summary} [{self.status}] ({self.progress_percent}% complete)"


@dataclass
class BacklogStory:
    """
    Value object representing a story/task in the backlog.
    """

    key: str  # e.g., "INOV-456"
    summary: str  # Story title
    status: str  # Story status
    issue_type: str  # "Story" or "Task"
    epic_key: str | None  # Parent epic key (if any)
    bounded_context: str  # Which context this belongs to
    sprint: str | None = None  # Sprint name if assigned
    assignee: str = ""  # Current assignee
    priority: str = ""  # Priority (e.g., "High", "Medium", "Low")
    labels: list[str] = field(default_factory=list)
    story_points: int | None = None
    _sprint_state: str | None = None

    @property
    def is_in_sprint(self) -> bool:
        """Check if story is assigned to a sprint"""
        return self.sprint is not None

    @property
    def is_in_progress(self) -> bool:
        """Check if story is actively being worked on"""
        return self.status.lower() in ("in progress", "development", "in review", "code review")

    @property
    def is_blocked(self) -> bool:
        """Check if story is blocked"""
        return self.status.lower() in ("blocked", "on hold", "waiting")

    def __str__(self) -> str:
        sprint_info = f" [{self.sprint}]" if self.sprint else ""
        return f"{self.key}: {self.summary} [{self.status}]{sprint_info}"


@dataclass
class BacklogAnalysisResult:
    """
    Value object containing comprehensive backlog analysis results.
    """

    # Backlog structure by bounded context
    epics_by_context: dict[str, list[BacklogEpic]] = field(default_factory=dict)
    stories_by_context: dict[str, list[BacklogStory]] = field(default_factory=dict)

    # Sprint information
    current_sprint_items: list[BacklogStory] = field(default_factory=list)
    next_sprint_items: list[BacklogStory] = field(default_factory=list)

    # Active work tracking
    in_progress_by_context: dict[str, list[BacklogStory]] = field(default_factory=dict)
    blocked_items: list[BacklogStory] = field(default_factory=list)

    # Related issues for proposed work
    related_epics: list[BacklogEpic] = field(default_factory=list)
    related_stories: list[BacklogStory] = field(default_factory=list)

    # Coverage analysis
    covered_contexts: set[str] = field(default_factory=set)
    gaps: list[str] = field(default_factory=list)  # Contexts with no coverage

    # Conflicts with proposed work
    potential_conflicts: list[str] = field(default_factory=list)
    linkable_epics: list[str] = field(default_factory=list)  # Epics to link new work to

    @property
    def total_epics(self) -> int:
        """Total number of epics in backlog"""
        return sum(len(epics) for epics in self.epics_by_context.values())

    @property
    def total_stories(self) -> int:
        """Total number of stories/tasks in backlog"""
        return sum(len(stories) for stories in self.stories_by_context.values())

    @property
    def total_in_progress(self) -> int:
        """Total number of items currently in progress"""
        return sum(len(items) for items in self.in_progress_by_context.values())

    @property
    def has_conflicts(self) -> bool:
        """Check if there are conflicts with proposed work"""
        return len(self.potential_conflicts) > 0

    def get_summary(self) -> str:
        """Get human-readable backlog summary"""
        lines = [
            "📊 BACKLOG ANALYSIS SUMMARY",
            "=" * 40,
            f"Total Epics: {self.total_epics}",
            f"Total Stories/Tasks: {self.total_stories}",
            f"In Progress: {self.total_in_progress}",
            f"Current Sprint Items: {len(self.current_sprint_items)}",
            f"Blocked Items: {len(self.blocked_items)}",
            "",
            "📁 COVERAGE BY BOUNDED CONTEXT:",
        ]

        for ctx in sorted(self.covered_contexts):
            epic_count = len(self.epics_by_context.get(ctx, []))
            story_count = len(self.stories_by_context.get(ctx, []))
            in_progress = len(self.in_progress_by_context.get(ctx, []))
            lines.append(
                f"  • {ctx}: {epic_count} epics, {story_count} stories, {in_progress} in progress"
            )

        if self.gaps:
            lines.append("")
            lines.append("⚠️ GAPS (no coverage):")
            for gap in self.gaps:
                lines.append(f"  • {gap}")

        if self.potential_conflicts:
            lines.append("")
            lines.append("🚨 POTENTIAL CONFLICTS:")
            for conflict in self.potential_conflicts:
                lines.append(f"  • {conflict}")

        if self.linkable_epics:
            lines.append("")
            lines.append("🔗 LINKABLE EPICS (for new work):")
            for epic in self.linkable_epics:
                lines.append(f"  • {epic}")

        return "\n".join(lines)


class IBacklogAnalyzer(ABC):
    """
    Domain service interface for comprehensive Jira backlog analysis.

    Provides full visibility into:
    1. All epics/stories grouped by bounded context
    2. Current sprint allocation
    3. In-progress work that might conflict
    4. Related epics for linking new work
    5. Coverage gaps in the backlog

    This complements IDuplicateDetector by providing strategic
    backlog intelligence rather than just title-based matching.
    """

    @abstractmethod
    def analyze_backlog(
        self, project_key: str, bounded_contexts: list[str] | None = None
    ) -> BacklogAnalysisResult:
        """
        Perform comprehensive backlog analysis.

        Scans all epics, stories, and tasks to build a complete picture.

        Args:
            project_key: Jira project key
            bounded_contexts: Optional filter by specific contexts

        Returns:
            BacklogAnalysisResult with full analysis
        """

    @abstractmethod
    def find_related_epics(self, bounded_context: str, themes: list[str]) -> list[BacklogEpic]:
        """
        Find epics related to a bounded context and themes.

        Used to identify existing epics that new stories should link to.

        Args:
            bounded_context: The bounded context to search in
            themes: Themes/keywords to match

        Returns:
            List of related BacklogEpic objects
        """

    @abstractmethod
    def find_in_progress_work(self, bounded_context: str) -> list[BacklogStory]:
        """
        Find all in-progress work for a bounded context.

        Used to identify potential conflicts with proposed work.

        Args:
            bounded_context: The bounded context to check

        Returns:
            List of in-progress BacklogStory objects
        """

    @abstractmethod
    def check_sprint_allocation(self, bounded_context: str) -> dict[str, list[BacklogStory]]:
        """
        Check sprint allocation for a bounded context.

        Returns current and upcoming sprint items.

        Args:
            bounded_context: The bounded context to check

        Returns:
            Dict with 'current' and 'next' sprint lists
        """

    @abstractmethod
    def identify_conflicts(
        self, proposed_title: str, proposed_context: str, proposed_themes: list[str]
    ) -> list[str]:
        """
        Identify potential conflicts with proposed work.

        Checks for:
        - Similar work in progress
        - Overlapping epics
        - Sprint capacity issues

        Args:
            proposed_title: Title of proposed work
            proposed_context: Bounded context for proposed work
            proposed_themes: Themes/keywords in proposed work

        Returns:
            List of conflict descriptions
        """

    @abstractmethod
    def suggest_epic_link(self, bounded_context: str, themes: list[str]) -> str | None:
        """
        Suggest an existing epic to link new work to.

        Args:
            bounded_context: The bounded context
            themes: Themes/keywords to match

        Returns:
            Epic key to link to, or None if no suitable epic exists
        """

    @abstractmethod
    def get_coverage_gaps(self, expected_contexts: list[str]) -> list[str]:
        """
        Identify bounded contexts with no backlog coverage.

        Args:
            expected_contexts: List of expected bounded context names

        Returns:
            List of context names with no coverage
        """
