#!/usr/bin/env python3
"""
Domain Value Objects

Immutable value objects that encapsulate domain concepts.
Value objects have no identity - they're equal if their values are equal.

Author: Inovagio Engineering Team
"""

from dataclasses import dataclass
from enum import Enum


class IssueType(Enum):
    """Issue type enumeration"""

    EPIC = "Epic"
    STORY = "Story"
    TASK = "Task"
    SUBTASK = "Sub-task"
    BUG = "Bug"


class Priority(Enum):
    """Priority levels"""

    HIGHEST = "Highest"
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"
    LOWEST = "Lowest"


class AIReadinessLevel(Enum):
    """AI-executable readiness levels"""

    NOT_READY = "not_ready"  # Missing critical fields
    INCOMPLETE = "incomplete"  # Has gaps, needs refinement
    READY = "ready"  # AI can execute with minor clarifications
    OPTIMAL = "optimal"  # Fully AI-executable


@dataclass(frozen=True)
class IssueKey:
    """
    Jira Issue Key value object.

    Format: PROJECT-NUMBER (e.g., INOV-123)
    Immutable and validated.
    """

    key: str

    def __post_init__(self):
        """Validate issue key format"""
        if not self.key:
            raise ValueError("Issue key cannot be empty")

        if "-" not in self.key:
            raise ValueError(f"Invalid issue key format: {self.key} (expected PROJECT-NUMBER)")

        parts = self.key.split("-")
        if len(parts) != 2:
            raise ValueError(f"Invalid issue key format: {self.key}")

        project, number = parts
        if not project.isupper() or not project.isalpha():
            raise ValueError(f"Project key must be uppercase letters: {project}")

        if not number.isdigit():
            raise ValueError(f"Issue number must be numeric: {number}")

    @property
    def project(self) -> str:
        """Extract project key"""
        return self.key.split("-")[0]

    @property
    def number(self) -> int:
        """Extract issue number"""
        return int(self.key.split("-")[1])

    def __str__(self) -> str:
        return self.key


@dataclass(frozen=True)
class BoundedContext:
    """
    DDD Bounded Context value object.

    Represents a module in the Inovagio architecture.
    """

    name: str  # e.g., "core-ani", "core-orchestration"
    layer: int  # 0-3 (Layer 0 = Foundation)
    patterns: tuple[str, ...]  # Design patterns used
    dependencies: tuple[str, ...]  # Other contexts it depends on
    source_path: str | None = None  # Path in codebase

    def __post_init__(self):
        """Validate bounded context"""
        if not self.name:
            raise ValueError("Bounded context name cannot be empty")

        if self.layer not in range(4):
            raise ValueError(f"Layer must be 0-3, got {self.layer}")

        # Ensure tuples (immutable)
        object.__setattr__(self, "patterns", tuple(self.patterns) if self.patterns else ())
        object.__setattr__(
            self, "dependencies", tuple(self.dependencies) if self.dependencies else ()
        )

    @property
    def is_core(self) -> bool:
        """Check if this is a core context"""
        return self.name.startswith("core-")

    @property
    def is_product(self) -> bool:
        """Check if this is a product context"""
        return self.name.startswith("modules-")

    def __str__(self) -> str:
        return f"{self.name} (Layer {self.layer})"


@dataclass(frozen=True)
class Theme:
    """Theme/label value object"""

    name: str

    def __post_init__(self):
        if not self.name:
            raise ValueError("Theme name cannot be empty")

        # Normalize to lowercase
        object.__setattr__(self, "name", self.name.lower())

    def __str__(self) -> str:
        return self.name


@dataclass(frozen=True)
class Component:
    """Jira component value object"""

    name: str

    def __post_init__(self):
        if not self.name:
            raise ValueError("Component name cannot be empty")

    def __str__(self) -> str:
        return self.name


@dataclass(frozen=True)
class Label:
    """Jira label value object"""

    value: str

    def __post_init__(self):
        """Validate label format"""
        if not self.value:
            raise ValueError("Label cannot be empty")

        # Labels cannot have spaces
        if " " in self.value:
            raise ValueError(f"Label cannot contain spaces: {self.value}")

        # Normalize
        object.__setattr__(self, "value", self.value.lower().replace("_", "-"))

    def __str__(self) -> str:
        return self.value


@dataclass(frozen=True)
class StoryPoints:
    """Story points value object with validation"""

    value: int

    def __post_init__(self):
        """Validate story points"""
        if self.value < 0:
            raise ValueError("Story points cannot be negative")

        if self.value < 1 or self.value > 8:
            raise ValueError(
                f"Story points must be 1-8 (got {self.value}), larger stories should be split"
            )

    def __int__(self) -> int:
        return self.value

    def __str__(self) -> str:
        return str(self.value)


@dataclass(frozen=True)
class AcceptanceCriterion:
    """Single acceptance criterion"""

    description: str

    def __post_init__(self):
        if not self.description:
            raise ValueError("Acceptance criterion cannot be empty")

    @property
    def is_gherkin(self) -> bool:
        """Check if written in Gherkin format"""
        return any(keyword in self.description.upper() for keyword in ["GIVEN", "WHEN", "THEN"])

    def __str__(self) -> str:
        return self.description


@dataclass(frozen=True)
class SprintIdentifier:
    """Sprint identifier value object"""

    sprint_number: int
    name: str | None = None

    def __post_init__(self):
        if self.sprint_number < 1:
            raise ValueError("Sprint number must be positive")

    def __str__(self) -> str:
        return self.name or f"Sprint {self.sprint_number}"


@dataclass(frozen=True)
class ConfluencePageId:
    """Confluence page ID value object"""

    page_id: str

    def __post_init__(self):
        if not self.page_id:
            raise ValueError("Page ID cannot be empty")

        # Page IDs are typically numeric strings
        if not self.page_id.isdigit():
            raise ValueError(f"Invalid page ID format: {self.page_id}")

    def __str__(self) -> str:
        return self.page_id


@dataclass(frozen=True)
class ValidationResult:
    """Result of domain validation"""

    is_valid: bool
    errors: tuple[str, ...]
    warnings: tuple[str, ...] = ()

    def __post_init__(self):
        # Ensure immutability
        object.__setattr__(self, "errors", tuple(self.errors) if self.errors else ())
        object.__setattr__(self, "warnings", tuple(self.warnings) if self.warnings else ())

    @property
    def has_errors(self) -> bool:
        return len(self.errors) > 0

    @property
    def has_warnings(self) -> bool:
        return len(self.warnings) > 0

    def __str__(self) -> str:
        if self.is_valid:
            return "✅ Valid"
        return f"❌ Invalid: {', '.join(self.errors)}"


# Catalog of predefined bounded contexts (single source of truth)
BOUNDED_CONTEXT_CATALOG = {
    # Layer 0 - Foundation
    "core-models": BoundedContext(
        name="core-models",
        layer=0,
        patterns=("Value Objects", "Entities"),
        dependencies=(),
        source_path="core/core-models",
    ),
    # Layer 1 - Infrastructure
    "core-utils": BoundedContext(
        name="core-utils",
        layer=1,
        patterns=("Utility", "Service"),
        dependencies=("core-models",),
        source_path="core/core-utils",
    ),
    # Layer 2 - Cross-cutting
    "core-governance": BoundedContext(
        name="core-governance",
        layer=2,
        patterns=("RBAC", "Policy", "Audit"),
        dependencies=("core-models", "core-utils"),
        source_path="core/core-governance",
    ),
    "core-persistence": BoundedContext(
        name="core-persistence",
        layer=2,
        patterns=("Repository", "Unit of Work"),
        dependencies=("core-models", "core-utils"),
        source_path="core/core-persistence",
    ),
    # Layer 3 - Domain Services
    "core-ani": BoundedContext(
        name="core-ani",
        layer=3,
        patterns=("Gateway", "Broker", "Protocol"),
        dependencies=("core-models", "core-utils", "core-governance"),
        source_path="core/core-ani",
    ),
    "core-orchestration": BoundedContext(
        name="core-orchestration",
        layer=3,
        patterns=("Executor", "Scheduler", "Workflow"),
        dependencies=("core-models", "core-utils", "core-governance", "core-persistence"),
        source_path="core/core-orchestration",
    ),
    "core-agents": BoundedContext(
        name="core-agents",
        layer=3,
        patterns=("Agent", "LLM Client", "Lifecycle"),
        dependencies=("core-models", "core-utils", "core-governance"),
        source_path="core/core-agents",
    ),
    "core-connectors": BoundedContext(
        name="core-connectors",
        layer=3,
        patterns=("Adapter", "Connector", "Integration"),
        dependencies=("core-models", "core-utils", "core-governance"),
        source_path="core/core-connectors",
    ),
    # Product Contexts
    "modules-flow": BoundedContext(
        name="modules-flow",
        layer=3,
        patterns=("Visual Builder", "Bridge"),
        dependencies=("core-models", "core-utils", "core-orchestration"),
        source_path="modules/flow",
    ),
    "modules-origin": BoundedContext(
        name="modules-origin",
        layer=3,
        patterns=("Factory", "Registry", "Provider"),
        dependencies=("core-models", "core-utils", "core-agents"),
        source_path="modules/origin",
    ),
}


def get_bounded_context(name: str) -> BoundedContext:
    """Get bounded context by name (single source of truth)"""
    context = BOUNDED_CONTEXT_CATALOG.get(name)
    if not context:
        # Default fallback
        return BOUNDED_CONTEXT_CATALOG["core-models"]
    return context
