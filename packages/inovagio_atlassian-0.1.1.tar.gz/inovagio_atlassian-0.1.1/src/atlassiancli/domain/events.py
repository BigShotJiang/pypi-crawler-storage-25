#!/usr/bin/env python3
"""
Domain Events

Events that represent something important that happened in the domain.
Used for loose coupling between aggregates and bounded contexts.

Author: Inovagio Engineering Team
"""

from abc import ABC
from dataclasses import dataclass
from datetime import datetime
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from .models import Epic, Issue, Story


class DomainEvent(ABC):
    """Base class for all domain events"""

    def __init__(self):
        self.occurred_at = datetime.now()
        self.event_id = f"{self.__class__.__name__}_{datetime.now().timestamp()}"

    def __str__(self) -> str:
        return f"{self.__class__.__name__} at {self.occurred_at}"


@dataclass
class IssueCreatedEvent(DomainEvent):
    """Event raised when an issue is created"""

    issue: "Issue"

    def __post_init__(self):
        super().__init__()


@dataclass
class EpicCreatedEvent(IssueCreatedEvent):
    """Event raised when an epic is created"""

    epic: Optional["Epic"] = None

    def __post_init__(self):
        self.epic = self.issue  # type: ignore
        super().__post_init__()


@dataclass
class StoryCreatedEvent(IssueCreatedEvent):
    """Event raised when a story is created"""

    story: Optional["Story"] = None

    def __post_init__(self):
        self.story = self.issue  # type: ignore
        super().__post_init__()


@dataclass
class IssueUpdatedEvent(DomainEvent):
    """Event raised when an issue is updated"""

    issue: "Issue"
    changes: dict[str, Any]

    def __post_init__(self):
        super().__init__()


@dataclass
class StoryAssignedToSprintEvent(DomainEvent):
    """Event raised when story is assigned to sprint"""

    story: "Story"
    sprint_number: int

    def __post_init__(self):
        super().__init__()


@dataclass
class StoryEnhancedEvent(DomainEvent):
    """Event raised when story is enhanced with AI-ready content"""

    story: "Story"
    previous_readiness_level: str
    new_readiness_level: str

    def __post_init__(self):
        super().__init__()


@dataclass
class ConfluenceDocCreatedEvent(DomainEvent):
    """Event raised when Confluence documentation is created"""

    issue_key: str
    page_id: str
    page_url: str
    page_type: str  # "spec", "test_plan", "architecture"

    def __post_init__(self):
        super().__init__()
