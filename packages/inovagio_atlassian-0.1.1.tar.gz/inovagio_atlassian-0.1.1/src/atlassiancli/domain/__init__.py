"""Domain Layer - Pure Business Logic

This layer contains:
- Value Objects (immutable, validated primitives)
- Entities (objects with identity)
- Aggregates (consistency boundaries)
- Domain Services (stateless business logic)
- Repository Interfaces (persistence abstraction)
- Domain Events

NO dependencies on infrastructure or external libraries.
"""

from .events import DomainEvent, EpicCreatedEvent, StoryCreatedEvent
from .models import Epic, Issue, Story, Task
from .repositories import ConfluencePage, IConfluenceRepository, IIssueRepository
from .services import (
    BacklogAnalysisResult,
    BacklogEpic,
    BacklogStory,
    CodebaseValidationResult,
    ContextMapEntry,
    ExistingImplementation,
    ExistingInterface,
    GlossaryTerm,
    IBacklogAnalyzer,
    IBoundedContextResolver,
    ICodebaseCrossReferencer,
    IDuplicateDetector,
    IThemeDetector,
    SimilarityMatch,
)
from .value_objects import AIReadinessLevel, BoundedContext, IssueKey

__all__ = [
    # Value Objects
    "IssueKey",
    "BoundedContext",
    "AIReadinessLevel",
    "ConfluencePage",
    "SimilarityMatch",
    "ExistingInterface",
    "ExistingImplementation",
    "CodebaseValidationResult",
    "ContextMapEntry",
    "GlossaryTerm",
    "BacklogEpic",
    "BacklogStory",
    "BacklogAnalysisResult",
    # Entities
    "Issue",
    "Epic",
    "Story",
    "Task",
    # Services
    "IThemeDetector",
    "IBoundedContextResolver",
    "IDuplicateDetector",
    "ICodebaseCrossReferencer",
    "IBacklogAnalyzer",
    # Repositories
    "IIssueRepository",
    "IConfluenceRepository",
    # Events
    "DomainEvent",
    "StoryCreatedEvent",
    "EpicCreatedEvent",
]
