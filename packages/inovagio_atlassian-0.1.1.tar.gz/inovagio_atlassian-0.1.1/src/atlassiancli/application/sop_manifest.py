"""SOP manifest loader and validator.

Reads the YAML contract that ties prose SOPs to enforceable rules
(`templates/autonomous-dev-system/sops/sop-manifest.yaml` is the canonical
shape). Used by:

- ``analyse sop`` — Phase 2 story-time review (only ``phase: story`` rules).
- ``framework sop-commit-gate`` — Phase 6 / pre-commit blocking gate
  (only ``phase: commit`` rules).
- ``framework sop-validate-manifest`` — schema / regex validation of the
  manifest itself.

The loader is intentionally lenient about the schema's evolution: unknown
keys are preserved on the rule object so future SOP work can extend the
manifest without breaking older atlassiancli installations.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ..infrastructure.yaml_codec import YamlError, safe_load

# ---------------------------------------------------------------------------
# Public dataclasses
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SopMatch:
    """One match-clause inside a rule. Exactly one of the optional fields
    is meaningful; the runner picks the highest-priority field present
    in this order: ``required_section`` > ``regex`` > ``shell``."""

    required_section: str | None = None
    regex: str | None = None
    paths: tuple[str, ...] = ()
    exclude_paths: tuple[str, ...] = ()
    shell: str | None = None


@dataclass(frozen=True)
class SopOnViolation:
    message: str
    fix_hint: str = ""


@dataclass(frozen=True)
class SopRule:
    id: str
    sop: str
    description: str
    severity: str  # "blocking" | "warning" | "info"
    phase: str  # "story" | "commit" | "both"
    match: SopMatch
    on_violation: SopOnViolation
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class SopManifest:
    version: int
    project: dict[str, Any]
    rules: tuple[SopRule, ...]


@dataclass(frozen=True)
class ManifestValidationError:
    rule_id: str
    field: str
    message: str


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class SopManifestError(Exception):
    """Raised when the manifest file cannot be located, parsed, or
    structurally interpreted as a SOP manifest."""


# ---------------------------------------------------------------------------
# Loader
# ---------------------------------------------------------------------------


_VALID_SEVERITY = {"blocking", "warning", "info"}
_VALID_PHASE = {"story", "commit", "both"}


def load_manifest(path: str | Path) -> SopManifest:
    """Load + parse a SOP manifest from disk.

    Raises :class:`SopManifestError` if the file is missing, unparseable,
    or doesn't contain at least the ``version`` + a rule list.
    """
    p = Path(path)
    if not p.is_file():
        raise SopManifestError(f"manifest not found: {p}")

    try:
        with p.open("r", encoding="utf-8") as f:
            raw = safe_load(f.read())
    except YamlError as exc:
        raise SopManifestError(f"manifest parse failed at {p}: {exc}") from exc

    if not isinstance(raw, dict):
        raise SopManifestError(
            f"manifest at {p} must be a YAML mapping at top-level (found {type(raw).__name__})"
        )

    try:
        version = int(raw.get("version", 1))
    except (TypeError, ValueError):
        version = 1

    project_raw = raw.get("project") or {}
    project = dict(project_raw) if isinstance(project_raw, dict) else {}

    rules_raw = raw.get("rules") or []
    if not isinstance(rules_raw, list):
        raise SopManifestError(
            f"manifest at {p} must declare a 'rules:' sequence (found {type(rules_raw).__name__})"
        )

    rules: list[SopRule] = []
    for item in rules_raw:
        if not isinstance(item, dict) or "id" not in item:
            continue
        rules.append(_build_rule(item))

    return SopManifest(version=version, project=project, rules=tuple(rules))


def _build_rule(raw: dict[str, Any]) -> SopRule:
    raw_match = raw.get("match") or {}
    if not isinstance(raw_match, dict):
        raw_match = {}
    raw_on = raw.get("on_violation") or {}
    if not isinstance(raw_on, dict):
        raw_on = {}

    paths = _as_str_tuple(raw_match.get("paths"))
    excludes = _as_str_tuple(raw_match.get("exclude_paths"))

    return SopRule(
        id=str(raw["id"]),
        sop=str(raw.get("sop", "")),
        description=str(raw.get("description", "")),
        severity=str(raw.get("severity", "blocking")).lower(),
        phase=str(raw.get("phase", "commit")).lower(),
        match=SopMatch(
            required_section=_as_optional_str(raw_match.get("required_section")),
            regex=_as_optional_str(raw_match.get("regex")),
            paths=paths,
            exclude_paths=excludes,
            shell=_as_optional_str(raw_match.get("shell")),
        ),
        on_violation=SopOnViolation(
            message=str(raw_on.get("message", raw.get("description", raw["id"]))),
            fix_hint=str(raw_on.get("fix_hint", "")),
        ),
        extra={
            k: v
            for k, v in raw.items()
            if k not in {"id", "sop", "description", "severity", "phase", "match", "on_violation"}
        },
    )


def _as_optional_str(value: Any) -> str | None:
    if value is None or value == "":
        return None
    return str(value)


def _as_str_tuple(value: Any) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, str):
        return (value,)
    if isinstance(value, (list, tuple)):
        return tuple(str(v) for v in value)
    return ()


# ---------------------------------------------------------------------------
# Validator
# ---------------------------------------------------------------------------


def validate_manifest(manifest: SopManifest) -> list[ManifestValidationError]:
    """Return a list of structural / regex problems with the manifest.

    An empty list means the manifest is fit to drive the gates.
    """
    errors: list[ManifestValidationError] = []
    seen_ids: set[str] = set()

    for rule in manifest.rules:
        if not rule.id:
            errors.append(ManifestValidationError("<unknown>", "id", "rule is missing id"))
            continue
        if rule.id in seen_ids:
            errors.append(ManifestValidationError(rule.id, "id", "duplicate rule id"))
        seen_ids.add(rule.id)

        if rule.severity not in _VALID_SEVERITY:
            errors.append(
                ManifestValidationError(
                    rule.id,
                    "severity",
                    f"unknown severity {rule.severity!r}; expected one of {sorted(_VALID_SEVERITY)}",
                )
            )
        if rule.phase not in _VALID_PHASE:
            errors.append(
                ManifestValidationError(
                    rule.id,
                    "phase",
                    f"unknown phase {rule.phase!r}; expected one of {sorted(_VALID_PHASE)}",
                )
            )

        match = rule.match
        # Exactly one of required_section / regex / shell must be present.
        present = sum(1 for v in (match.required_section, match.regex, match.shell) if v)
        if present == 0:
            errors.append(
                ManifestValidationError(
                    rule.id,
                    "match",
                    "match must declare one of required_section / regex / shell",
                )
            )
        elif present > 1:
            errors.append(
                ManifestValidationError(
                    rule.id,
                    "match",
                    "match must declare exactly one of required_section / regex / shell",
                )
            )

        if match.regex:
            try:
                re.compile(match.regex)
            except re.error as exc:
                errors.append(
                    ManifestValidationError(rule.id, "match.regex", f"regex compile failed: {exc}")
                )

        if rule.phase in ("story", "both") and match.required_section is None and match.regex:
            # Story-only rules with a regex are unusual but legal — warn via
            # validator? No, keep validator strict: regex on story phase is
            # accepted; runner just skips evaluating it for stories.
            pass

    return errors
