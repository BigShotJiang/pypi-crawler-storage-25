#!/usr/bin/env python3
"""
Expert Enhancement Service

Application service for PhD-level story enhancement using Jira wiki format.
Integrates with the DDD architecture and domain services.

Features:
- Expert analysis for stories (acceptance criteria, testing, security)
- Already-enhanced detection to prevent re-corruption
- Proper Jira wiki format output

Author: Inovagio Engineering Team
"""

from typing import Any

from ..domain.models import Story
from ..domain.repositories import IIssueRepository
from ..domain.services import (
    IBoundedContextResolver,
    IComponentDeriver,
    ILabelDeriver,
    IPriorityCalculator,
    IStoryPointEstimator,
    IThemeDetector,
)
from ..domain.value_objects import (
    AcceptanceCriterion,
    Component,
    IssueKey,
    Label,
    Priority,
    SprintIdentifier,
    StoryPoints,
)
from ..infrastructure.architecture_analyzer import ArchitectureAnalyzer
from ..infrastructure.document_writer import get_document_writer, get_wiki_writer
from ..infrastructure.expert_enhancement import (
    ExpertTeam,
    format_enhanced_description,
    is_already_enhanced,
    sanitize_description,
)
from .dtos import (
    EnhanceIssueRequest,
    EnhanceIssueResponse,
    EnhanceSprintRequest,
    EnhanceSprintResponse,
    Result,
)


class ExpertEnhancementService:
    """Application service for expert-level story enhancement.

    DDD: Coordinates domain models, infrastructure (expert analysis),
    and repository interactions for the enhance use case.
    """

    def __init__(
        self,
        issue_repo: IIssueRepository,
        analysis_service: Any | None = None,
        theme_detector: IThemeDetector | None = None,
        context_resolver: IBoundedContextResolver | None = None,
        label_deriver: ILabelDeriver | None = None,
        component_deriver: IComponentDeriver | None = None,
        priority_calculator: IPriorityCalculator | None = None,
        story_point_estimator: IStoryPointEstimator | None = None,
        arch_analyzer: ArchitectureAnalyzer | None = None,
    ):
        self._issues = issue_repo
        self._analysis_service = analysis_service
        self._themes = theme_detector
        self._contexts = context_resolver
        self._labels = label_deriver
        self._components = component_deriver
        self._priorities = priority_calculator
        self._story_points = story_point_estimator
        self._expert_team = ExpertTeam()
        self._arch_analyzer = arch_analyzer or ArchitectureAnalyzer()

    def _collect_quality_metrics(
        self, issue_key: IssueKey, description_text: str
    ) -> dict[str, Any]:
        """Collect quality metrics used to drive and report automatic enhancement."""
        metrics: dict[str, Any] = {}

        if self._analysis_service:
            lint_result = self._analysis_service.lint_issue(issue_key)
            if lint_result.success and lint_result.value:
                metrics["lint"] = lint_result.value

            atomicity_result = self._analysis_service.analyze_atomicity(issue_key)
            if atomicity_result.success and atomicity_result.value:
                metrics["atomicity"] = atomicity_result.value

            description_result = self._analysis_service.analyze_description_quality(
                description_text
            )
            if description_result.success and description_result.value:
                metrics["description"] = description_result.value

        return metrics

    def _apply_professional_quality_pass(self, sections: list[Any], analysis: Any) -> list[Any]:
        """Keep the story implementation-ready and concise for engineering teams."""
        from ..infrastructure.document_writer import DocumentSection

        keep_titles = {
            "📚 Documentation References",
            "🧾 Agile User Story",
            "📋 Overview",
            "🏛️ Architecture Review",
            "🎯 Acceptance Criteria",
            "🏗️ Technical Approach",
            "🧪 Testing Strategy",
            "✅ Definition of Done",
            "📝 Implementation Notes",
        }

        refined: list[DocumentSection] = []
        for section in sections:
            if section.title and section.title not in keep_titles:
                continue

            content = section.content

            if section.title == "🎯 Acceptance Criteria" and isinstance(content, list):
                prioritized = []
                for item in content:
                    text = str(item)
                    if "GIVEN" in text.upper() and "THEN" in text.upper():
                        prioritized.append(text)
                if not prioritized:
                    prioritized = [str(item) for item in content]
                content = prioritized[:6]

            if section.title == "🏗️ Technical Approach" and isinstance(content, list):
                content = [str(item) for item in content][:18]

            if section.title == "🧪 Testing Strategy" and isinstance(content, list):
                content = [str(item) for item in content][:12]

            if section.title == "📝 Implementation Notes" and isinstance(content, list):
                content = [str(item) for item in content][:8]

            refined.append(
                DocumentSection(
                    title=section.title,
                    content=content,
                    section_type=section.section_type,
                    show_rule=section.show_rule,
                )
            )

        if not any(s.title == "🎯 Acceptance Criteria" for s in refined):
            refined.append(
                DocumentSection(
                    title="🎯 Acceptance Criteria",
                    content=analysis.acceptance_criteria[:6],
                    section_type="checklist",
                )
            )

        return refined

    def enhance_issue(
        self, request: EnhanceIssueRequest, dry_run: bool = False
    ) -> Result[EnhanceIssueResponse, str]:
        """Use case: Enhance a story with PhD-level analysis using Jira wiki format.

        Args:
            request: Enhancement request with issue key and options
            dry_run: If True, don't persist changes (preview mode)

        Returns:
            Result with enhancement response or error
        """
        try:
            # Fetch issue
            issue_key = IssueKey(request.issue_key)
            issue = self._issues.find_by_key(issue_key)

            if not issue:
                return Result.fail("not_found", [f"Issue {request.issue_key} not found"])

            # Support Epics, Stories, and Tasks
            from ..domain.models import Epic, Task

            if not isinstance(issue, (Epic, Story, Task)):
                return Result.fail(
                    "invalid_type", ["Only Epics, Stories, and Tasks can be enhanced"]
                )

            story = issue
            changes_made: list[str] = []
            quality_before: dict[str, Any] = {}
            quality_after: dict[str, Any] = {}

            # Check if already enhanced (prevent re-corruption)
            current_description = story.description or ""
            already_enhanced = is_already_enhanced(current_description)

            if already_enhanced and not request.force:
                return Result.fail(
                    "already_enhanced",
                    [
                        f"Issue {request.issue_key} appears to already be enhanced. "
                        "Use --force to re-enhance (will sanitize first)."
                    ],
                )

            # Run architecture review on FULL description (before sanitization)
            # so it can detect Guard/Sentinel/Logging references from prior enhancements.
            arch_review = self._arch_analyzer.analyze(
                issue_key=request.issue_key,
                title=story.title or "",
                description=current_description,
            )

            if request.auto_quality:
                quality_before = self._collect_quality_metrics(issue_key, current_description)
                if quality_before:
                    changes_made.append("Auto-quality analysis completed")

            # If forcing re-enhancement, sanitize for re-generation
            if already_enhanced and request.force:
                current_description = sanitize_description(current_description)
                changes_made.append("Sanitized corrupted description")

            # Populate proposed architecture requirements for preview
            critical_missing = [
                i for i in arch_review.missing_integrations if i in ["Guard", "Sentinel", "Logging"]
            ]
            if critical_missing:
                # Generate proposed acceptance criteria
                arch_review.proposed_acceptance_criteria = []
                for integration in critical_missing:
                    if integration == "Guard":
                        arch_review.proposed_acceptance_criteria.append(
                            "GIVEN the implementation WHEN executing operations THEN Guard safety policies MUST be enforced with validation and circuit breaking"
                        )
                    elif integration == "Sentinel":
                        arch_review.proposed_acceptance_criteria.append(
                            "GIVEN the implementation WHEN processing data THEN Sentinel compliance monitoring MUST track all regulated operations with audit trail"
                        )
                    elif integration == "Logging":
                        arch_review.proposed_acceptance_criteria.append(
                            "GIVEN any operation WHEN executed THEN structured logs MUST be emitted using Core-Observability IAuditLogger with proper context"
                        )

                # Generate proposed NFR section
                arch_review.proposed_nfr_section = f"""## Non-Functional Requirements (Architecture Review)

**Safety & Resilience**:
- Integrate with NexusGuard for safety enforcement and policy validation
- Implement circuit breaker patterns for fault tolerance
- Handle failures gracefully with proper error recovery

**Compliance & Audit**:
- Integrate with Sentinel for compliance monitoring
- Maintain immutable audit trail for all regulated operations
- Ensure data handling meets security standards

**Observability**:
- Use Core-Observability IAuditLogger for structured logging
- Emit metrics using histogram/counter patterns
- Include proper context (user_id, resource_id, action) in all logs

**Core Libraries**:
- Use Inovagio Regex library (inovagio::core::utils::regex) for pattern matching
- Use Inovagio HashMap (inovagio::core::utils::containers) for efficient lookups

**Architecture Score**: {arch_review.grade} ({arch_review.score}/100)
**Documentation**: {arch_review.arch_doc_link or "Not linked"}
"""

            # Log architecture review results
            changes_made.append(
                f"Architecture Review: {arch_review.grade} ({arch_review.score}/100)"
            )
            if not arch_review.has_arch_doc:
                changes_made.append("⚠️  WARNING: Missing architecture documentation in Confluence")
            if arch_review.missing_integrations:
                changes_made.append(
                    f"⚠️  Missing integrations: {', '.join(arch_review.missing_integrations[:3])}"
                )

            # Perform expert analysis
            analysis = self._expert_team.analyze_story(
                issue_key=request.issue_key,
                summary=story.title or "",
                description=current_description,
            )

            changes_made.append(f"Detected category: {analysis.category}")
            changes_made.append(
                f"Generated {len(analysis.acceptance_criteria)} acceptance criteria"
            )
            changes_made.append(
                f"Generated testing strategy ({len(analysis.testing_strategy.get('unit_tests', []))} unit tests)"
            )
            changes_made.append(
                f"Added {len(analysis.security_requirements)} security requirements"
            )
            changes_made.append(f"Generated {len(analysis.definition_of_done)} DoD items")

            # Apply architecture requirements if requested
            if request.apply_architecture and arch_review.proposed_acceptance_criteria:
                # Append proposed acceptance criteria to existing ones
                for criterion in arch_review.proposed_acceptance_criteria:
                    analysis.acceptance_criteria.append(criterion)
                changes_made.append(
                    f"✅ Applied {len(arch_review.proposed_acceptance_criteria)} architecture acceptance criteria"
                )

            if request.apply_architecture and arch_review.proposed_nfr_section:
                # Add NFR section to implementation notes
                analysis.implementation_notes.insert(
                    0, "**Non-Functional Requirements (Architecture Review)**:"
                )
                analysis.implementation_notes.insert(1, arch_review.proposed_nfr_section)
                changes_made.append("✅ Applied NFR section from architecture review")

            # Format enhanced description as structured sections
            sections = format_enhanced_description(
                analysis=analysis,
                existing_description=current_description,
                summary=story.title or "",
                category=analysis.category,
                arch_review=arch_review,
            )

            if request.auto_quality:
                sections = self._apply_professional_quality_pass(sections, analysis)
                changes_made.append("Applied professional quality rewrite (concise)")

            if isinstance(story, Story):
                for criterion in analysis.acceptance_criteria[:6]:
                    story.add_acceptance_criterion(AcceptanceCriterion(criterion))

                for component in analysis.technical_approach.get("key_components", []):
                    if isinstance(component, tuple) and component:
                        story.add_affected_module(str(component[0]))

                for integration in analysis.technical_approach.get("integration_points", []):
                    story.add_integration_point(str(integration))

            # Convert sections to ADF using the unified DocumentWriter (SOLID/DRY)
            doc_writer = get_document_writer()
            enhanced_description = doc_writer.create_document(sections)

            wiki_writer = get_wiki_writer()
            enhanced_preview = wiki_writer.create_document(sections)

            # Update metadata if requested
            if request.update_metadata:
                # Detect themes
                themes = []
                if self._themes:
                    text_to_analyze = (story.title or "") + " " + (current_description or "")
                    themes = self._themes.detect_themes(text_to_analyze)

                # Update labels
                if self._labels and themes:
                    derived_labels = self._labels.derive_labels(themes)
                    story.clear_labels()
                    for label_str in derived_labels:
                        story.add_label(Label(label_str))
                    changes_made.append(f"Updated labels: {', '.join(derived_labels)}")

                # Update components
                if self._components and themes:
                    derived_components = self._components.derive_components(themes)
                    story.clear_components()
                    for comp_str in derived_components:
                        story.add_component(Component(comp_str))
                    changes_made.append(f"Updated components: {', '.join(derived_components)}")

                # Update priority
                if self._priorities:
                    priority_str = self._priorities.calculate_priority(
                        story.__class__.__name__, themes, current_description
                    )
                    story.set_priority(Priority(priority_str))
                    changes_made.append(f"Updated priority: {priority_str}")

                # Update story points (Stories and Tasks)
                if self._story_points and isinstance(story, (Story, Task)):
                    points = self._story_points.estimate_story_points(
                        story.title, current_description
                    )
                    story.set_story_points(StoryPoints(points))
                    changes_made.append(f"Updated story points: {points}")

            # Calculate readiness (Stories only)
            previous_readiness = (
                story.ai_readiness_level.value if isinstance(story, Story) else "N/A"
            )

            # Update issue description (now supports ADF dict)
            if not dry_run:
                story.update_description(enhanced_description)
                if isinstance(story, Story):
                    story.calculate_ai_readiness()

                success = self._issues.update(story)
                if success:
                    changes_made.append("✅ Description and metadata updated in Jira")
                    if request.auto_quality:
                        quality_after = self._collect_quality_metrics(issue_key, enhanced_preview)
                else:
                    return Result.fail(
                        "update_failed",
                        [
                            f"Failed to update issue {request.issue_key} in Jira. Check logs for details."
                        ],
                    )
            else:
                changes_made.append("🔍 DRY RUN - No changes made to Jira")
                if request.auto_quality:
                    quality_after = self._collect_quality_metrics(issue_key, enhanced_preview)

            # Calculate new readiness
            new_readiness = "N/A"
            if isinstance(story, Story):
                new_readiness = (
                    story.ai_readiness_level.value if not dry_run else "READY (projected)"
                )

            return Result.ok(
                EnhanceIssueResponse(
                    issue_key=story.key.key if story.key else request.issue_key,
                    previous_readiness=previous_readiness,
                    new_readiness=new_readiness,
                    changes_made=changes_made,
                    architecture_review=arch_review,
                    quality_before=quality_before,
                    quality_after=quality_after,
                )
            )

        except Exception as e:  # pylint: disable=broad-exception-caught
            return Result.fail("error", [str(e)])

    def enhance_sprint(
        self, request: EnhanceSprintRequest, dry_run: bool = False
    ) -> Result[EnhanceSprintResponse, str]:
        """Use case: Enhance all issues in a sprint using expert-level analysis.

        Iterates through sprint issues, applying PhD-level enhancement with
        architecture analysis, metadata updates, and Jira wiki format.

        Args:
            request: Sprint enhancement request with options
            dry_run: If True, don't persist changes (preview mode)

        Returns:
            Result with sprint enhancement response or error
        """
        try:
            sprint_id = SprintIdentifier(request.sprint_number)
            issues = self._issues.find_by_sprint(sprint_id)

            if not issues:
                return Result.fail(
                    "no_issues",
                    [f"No issues found in sprint {request.sprint_number}"],
                )

            enhanced: list[str] = []
            skipped: list[str] = []
            failed: list[str] = []
            total_changes = 0

            from ..domain.models import Epic, Task

            for issue in issues:
                issue_key_str = issue.key.key if issue.key else "UNKNOWN"

                # Only enhance Epics, Stories, and Tasks
                if not isinstance(issue, (Epic, Story, Task)):
                    skipped.append(issue_key_str)
                    continue

                # Skip if already READY and not forcing
                if (
                    not request.force
                    and isinstance(issue, Story)
                    and issue.ai_readiness_level.value == "READY"
                ):
                    skipped.append(issue_key_str)
                    continue

                try:
                    enhance_req = EnhanceIssueRequest(
                        issue_key=issue_key_str,
                        force=request.force,
                        update_metadata=request.update_metadata,
                        apply_architecture=request.apply_architecture,
                        auto_quality=request.auto_quality,
                    )
                    result = self.enhance_issue(enhance_req, dry_run=dry_run)

                    if result.success and result.value:
                        enhanced.append(issue_key_str)
                        total_changes += len(result.value.changes_made)
                    else:
                        error_msg = result.error or "Unknown error"
                        # Treat already_enhanced as skip, not failure
                        if "already_enhanced" in error_msg:
                            skipped.append(issue_key_str)
                        else:
                            failed.append(issue_key_str)

                except ValueError:
                    failed.append(issue_key_str)

            return Result.ok(
                EnhanceSprintResponse(
                    sprint_number=request.sprint_number,
                    enhanced=enhanced,
                    skipped=skipped,
                    failed=failed,
                    total_changes=total_changes,
                )
            )

        except Exception as e:  # pylint: disable=broad-exception-caught
            return Result.fail("error", [str(e)])

    def check_enhancement_status(self, issue_key: str) -> Result[dict, str]:
        """Check if an issue has already been enhanced.

        Args:
            issue_key: Jira issue key (e.g., "INOV-123")

        Returns:
            Result with status dict or error
        """
        try:
            key = IssueKey(issue_key)
            issue = self._issues.find_by_key(key)

            if not issue:
                return Result.fail("not_found", [f"Issue {issue_key} not found"])

            description = issue.description or ""
            enhanced = is_already_enhanced(description)

            return Result.ok(
                {
                    "issue_key": issue_key,
                    "is_enhanced": enhanced,
                    "description_length": len(description),
                    "has_wiki_headers": "h2." in description,
                    "has_markdown_headers": "##" in description,
                    "recommendation": (
                        "Already enhanced - use --force to re-enhance"
                        if enhanced
                        else "Ready for enhancement"
                    ),
                }
            )

        except Exception as e:  # pylint: disable=broad-exception-caught
            return Result.fail("error", [str(e)])

    def preview_enhancement(
        self, issue_key: str, apply_architecture: bool = False
    ) -> Result[dict, str]:
        """Preview what an enhancement would look like without applying it.

        Args:
            issue_key: Jira issue key
            apply_architecture: Whether to apply proposed architecture requirements

        Returns:
            Result with preview dict including enhanced description
        """
        try:
            key = IssueKey(issue_key)
            issue = self._issues.find_by_key(key)

            if not issue:
                return Result.fail("not_found", [f"Issue {issue_key} not found"])

            # Support Epics, Stories, and Tasks for preview
            from ..domain.models import Epic, Task

            if not isinstance(issue, (Epic, Story, Task)):
                return Result.fail(
                    "invalid_type", ["Only Epics, Stories, and Tasks can be previewed"]
                )

            story = issue
            description = story.description or ""

            # Run architecture review on FULL description (before sanitization)
            # so it can detect Guard/Sentinel/Logging references from prior enhancements.
            arch_review = self._arch_analyzer.analyze(
                issue_key=issue_key, title=story.title or "", description=description
            )

            # Sanitize if already enhanced
            if is_already_enhanced(description):
                description = sanitize_description(description)

            # Analyze
            analysis = self._expert_team.analyze_story(
                issue_key=issue_key, summary=story.title or "", description=description
            )

            # Apply architecture requirements if requested
            if apply_architecture and arch_review.proposed_acceptance_criteria:
                for criterion in arch_review.proposed_acceptance_criteria:
                    analysis.acceptance_criteria.append(criterion)

            if apply_architecture and arch_review.proposed_nfr_section:
                analysis.implementation_notes.insert(
                    0, "**Non-Functional Requirements (Architecture Review)**:"
                )
                analysis.implementation_notes.insert(1, arch_review.proposed_nfr_section)

            # Format
            sections = format_enhanced_description(
                analysis=analysis,
                existing_description=description,
                summary=story.title or "",
                category=analysis.category,
                arch_review=arch_review,
            )

            # Convert sections to Wiki format for terminal preview
            wiki_writer = get_wiki_writer()
            enhanced = wiki_writer.create_document(sections)

            return Result.ok(
                {
                    "issue_key": issue_key,
                    "category": analysis.category,
                    "acceptance_criteria_count": len(analysis.acceptance_criteria),
                    "security_requirements_count": len(analysis.security_requirements),
                    "dod_items_count": len(analysis.definition_of_done),
                    "enhanced_description": enhanced,
                    "description_length_before": len(story.description or ""),
                    "description_length_after": len(enhanced),
                }
            )

        except Exception as e:  # pylint: disable=broad-exception-caught
            return Result.fail("error", [str(e)])
