#!/usr/bin/env python3
"""
Application Services - Use Case Implementations

Orchestrates domain models, repositories, and domain services.
Implements use cases using dependency injection.

Author: Inovagio Engineering Team
"""

from typing import TYPE_CHECKING, Any, Optional

from ..domain.models import Epic, Story, Task
from ..domain.repositories import IConfluenceRepository, IIssueRepository
from ..domain.services import (  # DDD/SOLID: Unified document analyzer interface
    DocumentAnalysisResult,
    IBacklogAnalyzer,
    IBoundedContextResolver,
    ICodebaseCrossReferencer,
    IComponentDeriver,
    IDuplicateDetector,
    ILabelDeriver,
    IPriorityCalculator,
    IThemeDetector,
    ParsedWorkItem,
)
from ..domain.value_objects import (
    AcceptanceCriterion,
    Component,
    ConfluencePageId,
    IssueKey,
    IssueType,
    Label,
    Priority,
    SprintIdentifier,
    StoryPoints,
    Theme,
    get_bounded_context,
)
from ..infrastructure.architecture_analyzer import (
    ArchitectureAnalyzer,
    ArchitectureReviewResult,
)
from ..infrastructure.config import AtlassianConfig
from ..infrastructure.confluence_client import (
    ConfluenceApiClient,
    ConfluencePageRepository,
)
from ..infrastructure.importers import IssueType as ParsedIssueType
from ..infrastructure.jira_client import JiraApiClient
from ..infrastructure.markdown_formatter import MarkdownConfluenceFormatter
from .dtos import (
    BalanceCapacityRequest,
    BalanceCapacityResponse,
    BatchSplitRequest,
    BatchSplitResponse,
    ContextInfoRequest,
    ContextInfoResponse,
    CreateDocsRequest,
    CreateDocsResponse,
    CreateEpicRequest,
    CreateIssueResponse,
    CreateStoryRequest,
    CreateTaskRequest,
    DeleteIssueRequest,
    DeleteIssueResponse,
    DocSyncResult,
    EnhanceIssueRequest,
    EnhanceIssueResponse,
    EnhanceSprintRequest,
    EnhanceSprintResponse,
    GenerateSprintGoalsRequest,
    GenerateSprintGoalsResponse,
    GenerateTemplateRequest,
    GenerateTemplateResponse,
    HealthReportRequest,
    HealthReportResponse,
    PrepareStoryRequest,
    PrepareStoryResponse,
    RemoveLabelRequest,
    RemoveLabelResponse,
    Result,
    StandardizeStoryRequest,
    StandardizeStoryResponse,
    TransitionIssueRequest,
    TransitionIssueResponse,
)

# TYPE_CHECKING: Avoid circular imports for new architecture types
if TYPE_CHECKING:
    from ..infrastructure.document_analyzer import DocumentAnalyzer
    from ..infrastructure.document_importers import DocumentImporterFactory
    from .expert_enhancement_service import ExpertEnhancementService


class IssueCreationService:
    """
    Application service for creating issues.

    Uses dependency injection - all dependencies passed via constructor.
    """

    def __init__(
        self,
        issue_repo: IIssueRepository,
        theme_detector: IThemeDetector,
        context_resolver: IBoundedContextResolver,
        label_deriver: ILabelDeriver,
        component_deriver: IComponentDeriver,
        priority_calculator: IPriorityCalculator,
    ):
        self._issues = issue_repo
        self._themes = theme_detector
        self._contexts = context_resolver
        self._labels = label_deriver
        self._components = component_deriver
        self._priorities = priority_calculator

    def create_epic(self, request: CreateEpicRequest) -> Result[CreateIssueResponse, str]:
        """
        Use case: Create a new epic.

        Steps:
        1. Detect themes from text
        2. Resolve bounded context
        3. Create domain model
        4. Derive labels and components
        5. Validate
        6. Persist
        """
        try:
            # Detect themes
            text = request.title + " " + request.description
            detected_themes = self._themes.detect_themes(text)

            # Add explicit themes
            for theme_name in request.themes:
                detected_themes.append(Theme(theme_name))

            # Resolve bounded context
            context = self._contexts.resolve_context(detected_themes, text)

            # Map priority
            priority = self._map_priority(request.priority)

            # Create domain model
            epic = Epic(
                key=None,
                title=request.title,
                description=request.description,
                objective=request.objective,
                bounded_context=context,
                priority=priority,
            )

            # Add KPIs
            for kpi in request.kpis:
                epic.add_kpi(kpi)

            # Define scope
            if request.in_scope or request.out_of_scope:
                epic.define_scope(request.in_scope, request.out_of_scope)

            # Architecture link
            if request.architecture_link:
                epic.set_architecture_link(request.architecture_link)

            # Derive and add labels
            labels = self._labels.derive_labels(detected_themes)
            for label_str in labels:
                epic.add_label(Label(label_str))

            # Derive and add components
            components = self._components.derive_components(detected_themes)
            for comp_str in components:
                epic.add_component(Component(comp_str))

            # Add themes
            for theme in detected_themes:
                epic.add_theme(theme)

            # Validate
            validation = epic.validate()
            warnings = list(validation.warnings) if validation.warnings else []

            if not validation.is_valid:
                return Result.fail("validation_failed", list(validation.errors))

            # Persist
            epic_key = self._issues.create(epic)

            return Result.ok(
                CreateIssueResponse(
                    issue_key=epic_key.key,
                    url=f"https://inovagio.atlassian.net/browse/{epic_key.key}",
                    warnings=warnings,
                )
            )

        except Exception as e:
            return Result.fail("error", [str(e)])

    def create_story(self, request: CreateStoryRequest) -> Result[CreateIssueResponse, str]:
        """Use case: Create a new story"""
        try:
            # Detect themes
            text = request.title + " " + request.description
            detected_themes = self._themes.detect_themes(text)

            for theme_name in request.themes:
                detected_themes.append(Theme(theme_name))

            # Resolve context
            context = self._contexts.resolve_context(detected_themes, text)

            # Epic key
            epic_key = IssueKey(request.epic_key) if request.epic_key else None

            # Priority
            priority = self._map_priority(request.priority)

            # Create domain model
            story = Story(
                key=None,
                title=request.title,
                description=request.description,
                bounded_context=context,
                epic_key=epic_key,
                priority=priority,
            )

            # Story points
            if request.story_points:
                story.set_story_points(StoryPoints(request.story_points))

            # Sprint
            if request.sprint_number:
                story.assign_to_sprint(SprintIdentifier(request.sprint_number))

            # Acceptance criteria
            for criterion_text in request.acceptance_criteria:
                story.add_acceptance_criterion(AcceptanceCriterion(criterion_text))

            # Technical details
            for module in request.affected_modules:
                story.add_affected_module(module)

            for integration in request.integration_points:
                story.add_integration_point(integration)

            # Derive metadata
            labels = self._labels.derive_labels(detected_themes)
            for label_str in labels:
                story.add_label(Label(label_str))

            components = self._components.derive_components(detected_themes)
            for comp_str in components:
                story.add_component(Component(comp_str))

            for theme in detected_themes:
                story.add_theme(theme)

            # Calculate AI readiness
            story.calculate_ai_readiness()

            # Validate
            validation = story.validate()
            warnings = list(validation.warnings) if validation.warnings else []

            if not validation.is_valid:
                return Result.fail("validation_failed", list(validation.errors))

            # Persist
            story_key = self._issues.create(story)

            return Result.ok(
                CreateIssueResponse(
                    issue_key=story_key.key,
                    url=f"https://inovagio.atlassian.net/browse/{story_key.key}",
                    warnings=warnings,
                )
            )

        except Exception as e:
            return Result.fail("error", [str(e)])

    def create_task(self, request: CreateTaskRequest) -> Result[CreateIssueResponse, str]:
        """Use case: Create a new task"""
        try:
            parent_key = IssueKey(request.parent_story_key)
            priority = self._map_priority(request.priority)

            task = Task(
                key=None,
                title=request.title,
                description=request.description,
                parent_story_key=parent_key,
                priority=priority,
                issue_type=IssueType.SUBTASK,
            )

            # Implementation steps
            for step in request.implementation_steps:
                task.add_implementation_step(step)

            # Time estimate
            if request.estimated_hours:
                task.set_estimated_hours(request.estimated_hours)

            # Validate
            validation = task.validate()
            warnings = list(validation.warnings) if validation.warnings else []

            if not validation.is_valid:
                return Result.fail("validation_failed", list(validation.errors))

            # Persist
            task_key = self._issues.create(task)

            return Result.ok(
                CreateIssueResponse(
                    issue_key=task_key.key,
                    url=f"https://inovagio.atlassian.net/browse/{task_key.key}",
                    warnings=warnings,
                )
            )

        except Exception as e:
            return Result.fail("error", [str(e)])

    def _map_priority(self, priority_str: str) -> Priority:
        """Map priority string to enum"""
        priority_map = {
            "highest": Priority.HIGHEST,
            "high": Priority.HIGH,
            "medium": Priority.MEDIUM,
            "low": Priority.LOW,
            "lowest": Priority.LOWEST,
        }
        return priority_map.get(priority_str.lower(), Priority.MEDIUM)


class IssueEnhancementService:
    """Application service for enhancing existing issues"""

    def __init__(
        self,
        issue_repo: IIssueRepository,
        theme_detector: IThemeDetector,
        context_resolver: IBoundedContextResolver,
        doc_sync_service: "DocumentSyncService",
        analysis_service: Optional["IssueAnalysisService"] = None,
        label_deriver: ILabelDeriver | None = None,
        component_deriver: IComponentDeriver | None = None,
    ):
        self._issues = issue_repo
        self._themes = theme_detector
        self._contexts = context_resolver
        self._doc_sync = doc_sync_service
        self._analysis = analysis_service
        self._labels = label_deriver
        self._components = component_deriver

    def enhance_issue(self, request: EnhanceIssueRequest) -> Result[EnhanceIssueResponse, str]:
        """Use case: Enhance an existing issue with AI-ready content"""
        try:
            # Fetch issue
            issue_key = IssueKey(request.issue_key)
            issue = self._issues.find_by_key(issue_key)

            if not issue:
                return Result.fail("not_found", [f"Issue {request.issue_key} not found"])

            # Support Epics, Stories, and Tasks
            if not isinstance(issue, (Epic, Story, Task)):
                return Result.fail(
                    "invalid_type", ["Only Epics, Stories, and Tasks can be enhanced"]
                )

            # Track readiness for Stories only
            previous_readiness = (
                issue.ai_readiness_level.value if isinstance(issue, Story) else "N/A"
            )
            changes_made = []

            # === AI-POWERED ENHANCEMENT ===
            # Analyze description and populate documentation fields
            # Only Stories have full enhancement logic currently
            if isinstance(issue, Story):
                enhancement_result = self._enhance_story_fields(issue)
                if enhancement_result:
                    changes_made.extend(enhancement_result)

                # Recalculate AI readiness after enhancement
                issue.calculate_ai_readiness()
            else:
                # For Epic/Task, perform basic enhancement (future: implement Epic/Task-specific enhancement)
                changes_made.append(
                    f"{issue.issue_type.value} enhancement - basic validation performed"
                )

            # === DERIVE LABELS AND COMPONENTS ===
            # Use theme detection to derive appropriate labels and components
            if self._labels and self._components:
                text = issue.title + " " + issue.description
                detected_themes = self._themes.detect_themes(text)

                # Derive labels from themes
                derived_labels = self._labels.derive_labels(detected_themes)
                if derived_labels and not issue.labels:
                    for label in derived_labels:
                        issue.add_label(Label(label))
                    changes_made.append(
                        f"Added {len(derived_labels)} labels: {', '.join(derived_labels)}"
                    )

                # Derive components from themes
                derived_components = self._components.derive_components(detected_themes)
                if derived_components and not issue.components:
                    for comp in derived_components:
                        issue.add_component(Component(comp))
                    changes_made.append(
                        f"Added {len(derived_components)} components: {', '.join(derived_components)}"
                    )

            # Update in repository
            self._issues.update(issue)

            # === ARCHITECTURE ANALYSIS ===
            # Run architecture analyzer to review issue against architecture patterns
            architecture_review = None
            if self._analysis:
                arch_result = self._analysis.analyze_architecture(issue_key, dry_run=True)
                if arch_result.success and arch_result.value:
                    architecture_review = arch_result.value
                    # Note: Architecture analysis runs in dry-run mode during enhance
                    # Use 'analyze architecture --real-run' to apply changes

            # === CONFLUENCE DOCUMENTATION ===
            # Create docs if requested (via with_docs flag in sprint enhancement)
            # Individual issue enhancement doesn't create docs to avoid confusion
            # Use `atlassian docs --story <key>` explicitly for doc generation

            # Calculate new readiness (Stories only)
            new_readiness = issue.ai_readiness_level.value if isinstance(issue, Story) else "N/A"

            return Result.ok(
                EnhanceIssueResponse(
                    issue_key=issue.key.key if issue.key else request.issue_key,
                    previous_readiness=previous_readiness,
                    new_readiness=new_readiness,
                    changes_made=changes_made,
                    architecture_review=architecture_review,
                )
            )

        except Exception as e:
            return Result.fail("error", [str(e)])

    def _enhance_story_fields(self, story: Story) -> list[str]:
        """Apply AI-powered enhancement to story documentation fields.

        DDD: Business logic encapsulated in private method.
        Returns list of changes made for audit trail.
        """
        changes = []

        # Extract story intent from title/description
        if not story.story_intent and story.title:
            # Heuristic: First sentence often contains intent
            intent = self._extract_intent_from_description(story.title, story.description)
            if intent:
                story.set_story_intent(intent)
                changes.append("Added story intent")

        # Extract problem statement from description
        if not story.problem_statement and story.description:
            statement = self._extract_problem_statement(story.description)
            if statement:
                story.set_problem_statement(statement)
                changes.append("Added problem statement")

        # Detect security requirements from bounded context and description
        if not story.security_requirements and story.bounded_context:
            sec_reqs = self._detect_security_requirements(
                story.bounded_context.name, story.description
            )
            if sec_reqs:
                story.set_security_requirements(sec_reqs)
                changes.append(f"Added {len(sec_reqs)} security requirements")

        # Generate baseline test specifications if missing
        if not story.unit_test_spec and story.acceptance_criteria:
            spec = self._generate_test_spec(story.acceptance_criteria, "unit")
            if spec:
                story.set_unit_test_spec(spec)
                changes.append("Added unit test specification")

        # Generate observability spec based on bounded context
        if not story.observability_spec and story.bounded_context:
            spec = self._generate_observability_spec(story.bounded_context.name)
            if spec:
                story.set_observability_spec(spec)
                changes.append("Added observability specification")

        # Generate rollback strategy for production-bound stories
        if not story.rollback_strategy:
            strategy = self._generate_rollback_strategy(story.bounded_context.name)
            if strategy:
                story.set_rollback_strategy(strategy)
                changes.append("Added rollback strategy")

        return changes

    def _extract_intent_from_description(self, title: str, description: str) -> str:
        """Extract user/system intent from title and description."""
        # Simple heuristic: Use title as intent if it's action-oriented
        action_verbs = [
            "implement",
            "add",
            "create",
            "build",
            "enable",
            "support",
            "integrate",
        ]
        title_lower = title.lower()

        if any(verb in title_lower for verb in action_verbs):
            return title

        # Otherwise, extract first sentence from description
        if description:
            sentences = description.split(".")
            if sentences and len(sentences[0]) > 20:
                return sentences[0].strip()

        return ""

    def _extract_problem_statement(self, description: str) -> str:
        """Extract problem statement from description."""
        if not description or len(description) < 20:
            return ""

        # Look for problem indicators
        problem_keywords = ["problem", "issue", "challenge", "need", "require", "must"]
        sentences = description.split(".")

        for sentence in sentences:
            if any(keyword in sentence.lower() for keyword in problem_keywords):
                return sentence.strip()

        # Fallback: Use first sentence
        return sentences[0].strip() if sentences else ""

    def _detect_security_requirements(self, context_name: str, description: str) -> list[str]:
        """Detect security requirements based on context and description."""
        requirements = []
        description_lower = (description or "").lower()

        # Context-based requirements (DDD: Bounded context drives requirements)
        security_contexts = [
            "security",
            "governance",
            "authentication",
            "authorization",
        ]
        if any(ctx in context_name.lower() for ctx in security_contexts):
            requirements.extend(
                [
                    "TLS 1.3 for all network connections",
                    "Authentication required for all endpoints",
                    "Audit logging for all security events",
                ]
            )

        # Description-based detection
        if "auth" in description_lower or "login" in description_lower:
            requirements.append("Password hashing with Argon2id (m=65536, t=3, p=4)")
            requirements.append("Rate limiting: 5 failed attempts per 15 minutes")

        if "data" in description_lower or "store" in description_lower:
            requirements.append("Encryption at rest using AES-256-GCM")

        if "api" in description_lower or "endpoint" in description_lower:
            requirements.append("Input validation for all API parameters")
            requirements.append("OWASP Top 10 compliance")

        return list(set(requirements))  # Deduplicate

    def _generate_test_spec(self, criteria: list, test_type: str) -> str:
        """Generate test specification from acceptance criteria."""
        if not criteria:
            return ""

        if test_type == "unit":
            return f"Test each acceptance criterion in isolation: {', '.join([c.description for c in criteria[:3]])}"

        return ""

    def _generate_observability_spec(self, context_name: str) -> str:
        """Generate observability specification based on bounded context."""
        # DDD: Each bounded context has specific observability needs
        return f"Log all {context_name} operations with structured logging. Monitor success/failure rates, latency p50/p95/p99. Alert on error rate >5%."

    def _generate_rollback_strategy(self, context_name: str) -> str:
        """Generate rollback strategy based on bounded context."""
        # DDD: Rollback strategy depends on context criticality
        critical_contexts = ["security", "governance", "authentication", "payment"]

        if any(ctx in context_name.lower() for ctx in critical_contexts):
            return "Feature flag with immediate rollback capability. Automated rollback on error rate >5%. Manual approval required for production deployment."
        else:
            return "Feature flag enabled. Rollback via flag toggle within 5 minutes. Gradual rollout recommended."

    def enhance_sprint(self, request: EnhanceSprintRequest) -> Result[EnhanceSprintResponse, str]:
        """Use case: Enhance all issues in a sprint"""
        try:
            # Get all issues in sprint
            sprint_id = SprintIdentifier(request.sprint_number)
            issues = self._issues.find_by_sprint(sprint_id)

            enhanced = []
            skipped = []
            failed = []
            total_changes = 0

            for issue in issues:
                # Only enhance stories
                issue_key_str = issue.key.key if issue.key else "UNKNOWN"
                if not isinstance(issue, Story):
                    skipped.append(issue_key_str)
                    continue

                story = issue
                story_key_str = story.key.key if story.key else "UNKNOWN"

                # Skip if already enhanced and not forcing
                if not request.force and story.ai_readiness_level.value == "READY":
                    skipped.append(story_key_str)
                    continue

                try:
                    # Enhance the story
                    enhance_req = EnhanceIssueRequest(issue_key=story_key_str, force=request.force)
                    result = self.enhance_issue(enhance_req)

                    if result.success and result.value:
                        enhanced.append(story_key_str)
                        total_changes += len(result.value.changes_made)

                        # === CONFLUENCE DOCUMENTATION ===
                        # Create docs if requested (DRY: Reuse DocumentSyncService)
                        if request.with_docs and request.execute:
                            docs_req = CreateDocsRequest(
                                issue_key=story_key_str,
                                include_spec=True,
                                include_test_plan=True,
                                include_runbook=True,
                            )
                            docs_result = self._doc_sync.create_docs(docs_req)
                            if docs_result.success and docs_result.value:
                                total_changes += docs_result.value.links_added
                    else:
                        failed.append(story_key_str)

                except Exception:
                    failed.append(story_key_str)

            return Result.ok(
                EnhanceSprintResponse(
                    sprint_number=request.sprint_number,
                    enhanced=enhanced,
                    skipped=skipped,
                    failed=failed,
                    total_changes=total_changes,
                )
            )

        except Exception as e:
            return Result.fail("error", [str(e)])


class DocumentSyncService:
    """Application service for Confluence documentation sync"""

    def __init__(
        self,
        issue_repo: IIssueRepository,
        confluence_repo: IConfluenceRepository,
        content_mapper,
        root_page_id: str | None = None,
    ):
        self._issues = issue_repo
        self._confluence = confluence_repo
        self._mapper = content_mapper
        self._root_page_id = ConfluencePageId(root_page_id) if root_page_id else None

    def create_docs(self, request: CreateDocsRequest) -> Result[CreateDocsResponse, str]:
        """Use case: Create Confluence documentation for an issue"""
        try:
            # Fetch issue
            issue_key = IssueKey(request.issue_key)
            issue = self._issues.find_by_key(issue_key)

            if not issue:
                return Result.fail("not_found", [f"Issue {request.issue_key} not found"])

            # Only create docs for stories
            if not isinstance(issue, Story):
                return Result.fail("invalid_type", ["Only stories can have documentation"])

            story = issue
            pages = []
            links_added = 0

            # === ORGANIZATIONAL HIERARCHY ===
            # Structure: Product Portfolio > Product Page > Story > Docs
            # Example: Product Portfolio > Flow > INOV-210 - Model Registry Panel UI > [STORY SPEC, TEST PLAN, RUNBOOK]
            #
            # Product Page sections (manual organization):
            # - Features (manual pages for feature documentation)
            # - Architecture (manual pages for architecture docs)
            # - Stories (automatic - all Jira stories go here)

            # Extract product/bounded context from story
            product = self._extract_product_from_story(story)

            # Debug output
            if not request.analyze_only:
                print(f"📦 Product: {product}")

            # Level 1: Find existing Product page (e.g., "Flow", "Origin", "Guard")
            # These should already exist under the root page (Engineering Documentation)

            # Use root page ID from config if available, otherwise search by title
            portfolio_page = self._root_page_id
            if not portfolio_page:
                portfolio_page = self._confluence.find_page_by_title(
                    "INOV", "Product Portfolio - Source of Truth"
                )

            product_parent = None

            if portfolio_page:
                # Search for product page among Portfolio's children
                children = self._confluence.get_child_pages(portfolio_page)
                for child in children:
                    if child.title == product:
                        product_parent = child.page_id
                        break

            if not request.analyze_only:
                if product_parent:
                    print(f"✅ Found existing product page: {product}")
                else:
                    print(
                        f"⚠️  Product page '{product}' not found under Product Portfolio, creating..."
                    )

            if not product_parent:
                # Fallback: Create product page under Product Portfolio
                product_parent = self._confluence.find_or_create_parent_page(
                    "INOV",
                    product,
                    f"""
<h2>{product} Product</h2>
<p>Documentation for the <strong>{product}</strong> bounded context.</p>
<h3>Organization</h3>
<ul>
<li><strong>Features</strong> - Feature-level documentation (manual)</li>
<li><strong>Architecture</strong> - Technical architecture and design (manual)</li>
<li><strong>Stories</strong> - Jira story documentation (automatic)</li>
</ul>
<hr/>
<ac:structured-macro ac:name="children" ac:schema-version="2">
  <ac:parameter ac:name="all">true</ac:parameter>
  <ac:parameter ac:name="sort">title</ac:parameter>
</ac:structured-macro>
""",
                    under_parent_id=portfolio_page,
                )

            # Level 2: Story page directly under product (e.g., "INOV-210 - Model Registry Panel UI")
            story_key_str = story.key.key if story.key else "UNKNOWN"
            issue_parent_title = f"{story_key_str} - {story.title[:50]}"
            issue_parent = self._confluence.find_or_create_parent_page(
                "INOV",
                issue_parent_title,
                f"""
<h2>{story.title}</h2>
<p><strong>Issue:</strong> <a href="https://inovagio.atlassian.net/browse/{story_key_str}">{story_key_str}</a></p>
<p><strong>Product:</strong> {product}</p>
<p><strong>Description:</strong> {story.description[:200] if story.description else "No description"}...</p>
<hr/>
<h3>Documentation</h3>
<ac:structured-macro ac:name="children" ac:schema-version="2">
  <ac:parameter ac:name="all">true</ac:parameter>
  <ac:parameter ac:name="sort">title</ac:parameter>
</ac:structured-macro>
""",
                under_parent_id=product_parent,
            )

            # Create Story Spec page
            if request.include_spec:
                spec_title = f"STORY SPEC - {story_key_str} - {story.title[:50]}"

                # Check if exists
                existing = self._confluence.find_page_by_title("INOV", spec_title)

                if not existing:
                    # Generate content
                    content = self._mapper.story_to_spec_page(story)

                    # Create page under issue parent
                    page_id = self._confluence.create_page(
                        "INOV", spec_title, content, parent_page_id=issue_parent
                    )
                    page_url = self._confluence.get_page_url(page_id)

                    # Add remote link
                    if story.key:
                        self._confluence.add_remote_link_to_jira(
                            story.key, page_url, "📋 Story Spec"
                        )
                    links_added += 1

                    pages.append(
                        DocSyncResult(
                            page_type="spec",
                            page_id=page_id.page_id,
                            page_url=page_url,
                            status="created",
                        )
                    )
                else:
                    # Move existing page under issue parent
                    try:
                        content = self._mapper.story_to_spec_page(story)
                        self._confluence.update_page(existing, spec_title, content)
                    except Exception:
                        pass  # If move fails, leave it where it is

                    pages.append(
                        DocSyncResult(
                            page_type="spec",
                            page_id=existing.page_id,
                            status="unchanged",
                        )
                    )

            # Create Test Plan page
            if request.include_test_plan:
                testplan_title = f"TEST PLAN - {story_key_str} - {story.title[:50]}"

                # Check if exists
                existing = self._confluence.find_page_by_title("INOV", testplan_title)

                if not existing:
                    # Generate content
                    content = self._mapper.story_to_test_plan_page(story)

                    # Create page under issue parent
                    page_id = self._confluence.create_page(
                        "INOV", testplan_title, content, parent_page_id=issue_parent
                    )
                    page_url = self._confluence.get_page_url(page_id)

                    # Add remote link
                    if story.key:
                        self._confluence.add_remote_link_to_jira(
                            story.key, page_url, "🧪 Test Plan"
                        )
                    links_added += 1

                    pages.append(
                        DocSyncResult(
                            page_type="testplan",
                            page_id=page_id.page_id,
                            page_url=page_url,
                            status="created",
                        )
                    )
                else:
                    # Move existing page under issue parent
                    try:
                        content = self._mapper.story_to_test_plan_page(story)
                        self._confluence.update_page(existing, testplan_title, content)
                    except Exception:
                        pass  # If move fails, leave it where it is

                    pages.append(
                        DocSyncResult(
                            page_type="testplan",
                            page_id=existing.page_id,
                            status="unchanged",
                        )
                    )

            # Create Runbook page
            if request.include_runbook:
                runbook_title = f"RUNBOOK - {story_key_str} - {story.title[:50]}"

                # Check if exists
                existing = self._confluence.find_page_by_title("INOV", runbook_title)

                if not existing:
                    # Generate content
                    content = self._mapper.story_to_runbook_page(story)

                    # Create page under issue parent
                    page_id = self._confluence.create_page(
                        "INOV", runbook_title, content, parent_page_id=issue_parent
                    )
                    page_url = self._confluence.get_page_url(page_id)

                    # Add remote link
                    if story.key:
                        self._confluence.add_remote_link_to_jira(story.key, page_url, "📚 Runbook")
                    links_added += 1

                    pages.append(
                        DocSyncResult(
                            page_type="runbook",
                            page_id=page_id.page_id,
                            page_url=page_url,
                            status="created",
                        )
                    )
                else:
                    # Move existing page under issue parent
                    try:
                        content = self._mapper.story_to_runbook_page(story)
                        self._confluence.update_page(existing, runbook_title, content)
                    except Exception:
                        pass  # If move fails, leave it where it is

                    pages.append(
                        DocSyncResult(
                            page_type="runbook",
                            page_id=existing.page_id,
                            status="unchanged",
                        )
                    )

            return Result.ok(
                CreateDocsResponse(issue_key=story_key_str, pages=pages, links_added=links_added)
            )

        except Exception as e:
            return Result.fail("error", [str(e)])

    def _extract_product_from_story(self, story: Story) -> str:
        """
        Extract product/bounded context from story.

        Priority:
        1. Product prefix in brackets [FLOW], [ORIGIN], etc. (explicit product tagging)
        2. Product label (Flow, Origin, Guard, etc.)
        3. Parse from title (e.g., "FLOW Model Registry" -> "Flow")
        4. Bounded context from story metadata (fallback for untagged stories)
        5. Default to "Core"
        """
        product_keywords = [
            "Flow",
            "Origin",
            "Guard",
            "Sentinel",
            "Edge",
            "Insights",
            "Studio",
            "Marketplace",
            "Shops",
            "ANI",
        ]

        # Priority 1: Check for bracket notation: [FLOW], [ORIGIN], etc.
        import re

        bracket_match = re.match(r"\[([A-Z]+)\]", story.title)
        if bracket_match:
            product_code = bracket_match.group(1)
            for keyword in product_keywords:
                if keyword.upper() == product_code:
                    return keyword

        # Priority 2: Check labels for product names
        if hasattr(story, "labels") and story.labels:
            for label in story.labels:
                for keyword in product_keywords:
                    if keyword.lower() in label.value.lower():
                        return keyword

        # Priority 3: Parse from title (without brackets)
        title_upper = story.title.upper()
        for keyword in product_keywords:
            if keyword.upper() in title_upper:
                return keyword

        # Priority 4: Check bounded context (fallback)
        if hasattr(story, "bounded_context") and story.bounded_context:
            bc_name = story.bounded_context.name
            # Map technical bounded contexts to products
            bc_to_product = {
                "core-agents": "Flow",  # Agents belong to Flow product
                "core-orchestration": "Flow",
                "core-ani": "ANI",
                "core-governance": "Guard",
            }
            if bc_name in bc_to_product:
                return bc_to_product[bc_name]
            return bc_name

        # Default
        return "Core"

    def _extract_feature_from_story(self, story: Story) -> str:
        """
        Extract feature name from story.

        Priority:
        1. Epic name if available
        2. Parse from title (words after [PRODUCT] prefix, before verbs)
        3. Default to "General"
        """
        # Check epic if available
        if hasattr(story, "epic_key") and story.epic_key:
            # Epic key available but we don't have the full epic object
            return str(story.epic_key)[:50]

        # Parse from title - extract feature keywords
        # Example: "[FLOW] Model Registry Panel UI" -> "Model Registry Panel"
        #          "Add user authentication" -> "User Authentication"

        title = story.title

        # Remove bracket notation: [FLOW], [ORIGIN], etc.
        import re

        title = re.sub(r"^\[[A-Z]+\]\s*", "", title)

        # Remove product prefix if present (without brackets)
        for product in ["FLOW", "ORIGIN", "GUARD", "SENTINEL", "EDGE", "INSIGHTS"]:
            if title.upper().startswith(product):
                title = title[len(product) :].strip()
                break

        # Extract first 2-3 capitalized words or up to first verb
        words = title.split()
        feature_words: list[str] = []
        verb_indicators = [
            "Add",
            "Create",
            "Update",
            "Delete",
            "Implement",
            "Fix",
            "Refactor",
        ]

        for word in words[:5]:  # Look at first 5 words max
            if word in verb_indicators:
                break
            if word[0].isupper() or len(feature_words) < 2:
                feature_words.append(word)
            else:
                break

        if feature_words:
            return " ".join(feature_words[:3])  # Max 3 words

        return "General"


class SprintManagementService:
    """Application service for sprint operations"""

    def __init__(self, issue_repo: IIssueRepository):
        self._issues = issue_repo

    def move_issues_to_sprint(
        self, sprint_number: int, issue_keys: list[str]
    ) -> Result[list[str], str]:
        """Use case: Move issues to a sprint"""
        try:
            moved = []

            for key_str in issue_keys:
                issue_key = IssueKey(key_str)
                issue = self._issues.find_by_key(issue_key)

                if issue and isinstance(issue, Story):
                    sprint = SprintIdentifier(sprint_number)
                    issue.assign_to_sprint(sprint)
                    self._issues.update(issue)
                    moved.append(key_str)

            return Result.ok(moved)

        except Exception as e:
            return Result.fail("error", [str(e)])


class IssueAnalysisService:
    """Application service for issue analysis"""

    def __init__(
        self,
        issue_repo: IIssueRepository,
        arch_analyzer: ArchitectureAnalyzer | None = None,
    ):
        self._issues = issue_repo
        self._arch_analyzer = arch_analyzer or ArchitectureAnalyzer()

    def analyze_architecture(
        self, issue_key: IssueKey, dry_run: bool = True
    ) -> Result[ArchitectureReviewResult, str]:
        """Use case: Perform PhD-level architecture review of a story

        Args:
            issue_key: The Jira issue key to analyze
            dry_run: If True (default), only analyze without making changes.
                    If False, updates story with architecture requirements
        """
        try:
            issue = self._issues.find_by_key(issue_key)

            if not issue:
                return Result.fail("not_found", [f"Issue {issue_key.key} not found"])

            if not isinstance(issue, Story):
                return Result.fail(
                    "invalid_type", ["Only stories can be analyzed for architecture"]
                )

            result = self._arch_analyzer.analyze(
                issue_key=issue_key.key,
                title=issue.title,
                description=issue.description,
            )

            # Populate proposed changes for preview (both modes)
            if result.missing_integrations:
                result.proposed_acceptance_criteria = self._generate_proposed_criteria(result)
                result.proposed_nfr_section = self._generate_nfr_section(result)

            # REAL RUN: Update story with architecture requirements
            if not dry_run and result.missing_integrations:
                self._add_architecture_requirements(issue, result)
                self._issues.update(issue)

            return Result.ok(result)

        except Exception as e:
            return Result.fail("error", [str(e)])

    def _generate_proposed_criteria(self, review: ArchitectureReviewResult) -> list[str]:
        """Generate list of proposed acceptance criteria"""
        criteria = []
        critical_integrations = ["Guard", "Sentinel", "Logging"]
        for integration in review.missing_integrations:
            if integration in critical_integrations:
                criteria.append(self._generate_integration_requirement(integration))
        return criteria

    def _add_architecture_requirements(
        self, story: Story, review: ArchitectureReviewResult
    ) -> None:
        """Add architecture requirements to story based on review findings"""
        # Add acceptance criteria for critical missing integrations
        critical_integrations = ["Guard", "Sentinel", "Logging"]
        for integration in review.missing_integrations:
            if integration in critical_integrations:
                criterion = self._generate_integration_requirement(integration)
                story.add_acceptance_criterion(AcceptanceCriterion(criterion))

        # Add non-functional requirements section to description
        if not story.nonfunctional_requirements:
            nfr_section = self._generate_nfr_section(review)
            story.set_proposed_solution(story.proposed_solution + "\n\n" + nfr_section)

    def _generate_integration_requirement(self, integration: str) -> str:
        """Generate acceptance criterion for missing integration"""
        templates = {
            "Guard": "GIVEN the implementation WHEN executing operations THEN Guard safety policies MUST be enforced with validation and circuit breaking",
            "Sentinel": "GIVEN the implementation WHEN processing data THEN Sentinel compliance monitoring MUST track all regulated operations with audit trail",
            "Logging": "GIVEN any operation WHEN executed THEN structured logs MUST be emitted using Core-Observability IAuditLogger with proper context",
            "Regex": "GIVEN text processing WHEN parsing patterns THEN Inovagio Regex library MUST be used (inovagio::core::utils::regex)",
            "HashMap": "GIVEN data structures WHEN using maps THEN Inovagio HashMap MUST be used (inovagio::core::utils::containers)",
            "Monitoring": "GIVEN the implementation WHEN executing THEN metrics MUST be collected using Core-Observability histogram/counter",
            "Analytics": "GIVEN user interactions WHEN tracked THEN Analytics events MUST be sent to Insights for ROI tracking",
        }
        return templates.get(
            integration,
            f"GIVEN the implementation WHEN applicable THEN {integration} integration MUST be implemented",
        )

    def _generate_nfr_section(self, review: ArchitectureReviewResult) -> str:
        """Generate non-functional requirements section"""
        nfr = "## Non-Functional Requirements (Architecture Review)\n\n"

        if "Guard" in review.missing_integrations:
            nfr += "**Safety & Resilience**:\n"
            nfr += "- Integrate with NexusGuard for safety enforcement and policy validation\n"
            nfr += "- Implement circuit breaker patterns for fault tolerance\n"
            nfr += "- Handle failures gracefully with proper error recovery\n\n"

        if "Sentinel" in review.missing_integrations:
            nfr += "**Compliance & Audit**:\n"
            nfr += "- Integrate with Sentinel for compliance monitoring\n"
            nfr += "- Maintain immutable audit trail for all regulated operations\n"
            nfr += "- Ensure data handling meets security standards\n\n"

        if "Logging" in review.missing_integrations:
            nfr += "**Observability**:\n"
            nfr += "- Use Core-Observability IAuditLogger for structured logging\n"
            nfr += "- Emit metrics using histogram/counter patterns\n"
            nfr += "- Include proper context (user_id, resource_id, action) in all logs\n\n"

        if any(lib in review.missing_integrations for lib in ["Regex", "HashMap"]):
            nfr += "**Core Libraries**:\n"
            if "Regex" in review.missing_integrations:
                nfr += "- Use Inovagio Regex library (inovagio::core::utils::regex) for pattern matching\n"
            if "HashMap" in review.missing_integrations:
                nfr += "- Use Inovagio HashMap (inovagio::core::utils::containers) for efficient lookups\n"
            nfr += "\n"

        nfr += f"**Architecture Score**: {review.grade} ({review.score}/100)\n"
        nfr += f"**Documentation**: {review.arch_doc_link or 'Required - add Confluence architecture link'}\n"

        return nfr

    def lint_issue(self, issue_key: IssueKey) -> Result[dict, str]:
        """Use case: Lint issue for AI readiness"""
        try:
            issue = self._issues.find_by_key(issue_key)

            if not issue:
                return Result.fail("not_found", [f"Issue {issue_key.key} not found"])

            # Support Epics, Stories, and Tasks
            if not isinstance(issue, (Epic, Story, Task)):
                return Result.fail(
                    "invalid_type",
                    ["Only Epics, Stories, and Tasks can be linted for AI readiness"],
                )

            # Use domain model's calculate_ai_readiness (Stories only have this feature)
            if isinstance(issue, Story):
                issue.calculate_ai_readiness()

                readiness_level = issue.ai_readiness_level.value
                readiness_score = issue.ai_readiness_score

                # Analyze missing fields
                issues_list = []
                missing_fields = []
                suggestions = []

                if not issue.acceptance_criteria:
                    issues_list.append("Missing acceptance criteria")
                    missing_fields.append("acceptance_criteria")
                    suggestions.append("Add 3-5 GIVEN/WHEN/THEN acceptance criteria")

                if not issue.description or len(issue.description) < 50:
                    issues_list.append("Description too brief")
                    missing_fields.append("description")
                    suggestions.append("Expand description to at least 50 words")

                if not issue.affected_modules:
                    issues_list.append("Missing affected modules")
                    missing_fields.append("affected_modules")
                    suggestions.append("Specify which code modules are affected")

                if not issue.integration_points:
                    issues_list.append("Missing integration points")
                    missing_fields.append("integration_points")
                    suggestions.append("Document integrations with other systems")

                return Result.ok(
                    {
                        "issue_key": issue_key.key,
                        "readiness_level": readiness_level,
                        "readiness_score": readiness_score,
                        "issues": issues_list,
                        "missing_fields": missing_fields,
                        "suggestions": suggestions,
                    }
                )
            else:
                # For Epic/Task, provide basic readiness assessment
                issues_list = []
                missing_fields = []
                suggestions = []

                if not issue.description or len(issue.description) < 50:
                    issues_list.append("Description too brief")
                    missing_fields.append("description")
                    suggestions.append("Expand description to at least 50 words")

                # Epic-specific checks
                if isinstance(issue, Epic):
                    if not issue.kpis:
                        issues_list.append("Missing KPIs")
                        missing_fields.append("kpis")
                        suggestions.append("Define success metrics (KPIs)")

                    if not issue.architecture_link:
                        issues_list.append("Missing architecture link")
                        missing_fields.append("architecture_link")
                        suggestions.append("Link to Confluence architecture page")

                # Task-specific checks
                if isinstance(issue, Task):
                    if not issue.implementation_steps:
                        issues_list.append("Missing implementation steps")
                        missing_fields.append("implementation_steps")
                        suggestions.append("Add step-by-step implementation plan")

                    if not issue.estimated_hours:
                        issues_list.append("Missing time estimate")
                        missing_fields.append("estimated_hours")
                        suggestions.append("Estimate hours required (< 8)")

                readiness_level = "incomplete" if issues_list else "ready"
                readiness_score = max(0, 100 - (len(issues_list) * 20))

                return Result.ok(
                    {
                        "issue_key": issue_key.key,
                        "readiness_level": readiness_level,
                        "readiness_score": readiness_score,
                        "issues": issues_list,
                        "missing_fields": missing_fields,
                        "suggestions": suggestions,
                    }
                )

        except Exception as e:
            return Result.fail("error", [str(e)])

    def analyze_description_quality(self, description: str) -> Result[dict, str]:
        """Use case: Analyze description quality"""
        try:
            if not description:
                return Result.ok(
                    {
                        "score": 0.0,
                        "grade": "F",
                        "issues": ["Missing description"],
                        "has_acceptance_criteria": False,
                        "has_technical_details": False,
                        "has_integration_points": False,
                        "has_code_examples": False,
                        "word_count": 0,
                    }
                )

            import re

            issues_list = []
            score = 5.0  # Start at 5/10

            # Check for key sections
            has_overview = bool(
                re.search(r"##?\s*(overview|summary|description)", description, re.I)
            )
            has_acceptance = bool(
                re.search(r"##?\s*acceptance criteria|GIVEN.*WHEN.*THEN", description, re.I)
            )
            has_technical = bool(
                re.search(
                    r"##?\s*(technical|architecture|design|implementation)",
                    description,
                    re.I,
                )
            )
            has_integration = bool(
                re.search(r"##?\s*integration|##?\s*dependencies", description, re.I)
            )
            has_code = bool(re.search(r"```", description))

            if has_overview:
                score += 1
            else:
                issues_list.append("Missing overview section")

            if has_acceptance:
                score += 2
            else:
                issues_list.append("Missing acceptance criteria")

            if has_technical:
                score += 1
            else:
                issues_list.append("Missing technical details")

            if has_integration:
                score += 0.5

            if has_code:
                score += 0.5

            # Check length
            word_count = len(description.split())
            if word_count < 50:
                issues_list.append(f"Description too brief ({word_count} words)")
                score -= 1
            elif word_count > 2000:
                issues_list.append(f"Description very long ({word_count} words)")

            final_score = min(10.0, max(0.0, score))

            # Grade mapping
            if final_score >= 9:
                grade = "A"
            elif final_score >= 8:
                grade = "B"
            elif final_score >= 7:
                grade = "C"
            elif final_score >= 6:
                grade = "D"
            else:
                grade = "F"

            return Result.ok(
                {
                    "score": final_score,
                    "grade": grade,
                    "issues": issues_list,
                    "has_acceptance_criteria": has_acceptance,
                    "has_technical_details": has_technical,
                    "has_integration_points": has_integration,
                    "has_code_examples": has_code,
                    "word_count": word_count,
                }
            )

        except Exception as e:
            return Result.fail("error", [str(e)])

    def analyze_atomicity(self, issue_key: IssueKey) -> Result[dict, str]:
        """Use case: Analyze story atomicity"""
        try:
            issue = self._issues.find_by_key(issue_key)

            if not issue:
                return Result.fail("not_found", [f"Issue {issue_key.key} not found"])

            # Support Epics, Stories, and Tasks
            if not isinstance(issue, (Epic, Story, Task)):
                return Result.fail(
                    "invalid_type",
                    ["Only Epics, Stories, and Tasks can be analyzed for atomicity"],
                )

            # Atomicity analysis primarily applies to Stories, provide basic analysis for others
            if not isinstance(issue, Story):
                return Result.ok(
                    {
                        "issue_key": issue_key.key,
                        "is_atomic": True,
                        "atomicity_score": 100,
                        "estimated_days": 0.0,
                        "should_split": False,
                        "issues": [],
                        "split_suggestions": [],
                        "message": f"{issue.issue_type.value} atomicity analysis not applicable",
                    }
                )

            story = issue
            issues_list = []
            split_suggestions = []

            # Calculate atomicity score
            score = 100

            # Check story points
            sp = story.story_points.value if story.story_points else 0
            if sp > 5:
                score -= 20
                issues_list.append(f"Story points too high ({sp} > 5)")
                split_suggestions.append("Consider splitting into smaller stories")
            elif sp == 0:
                score -= 10
                issues_list.append("Story points not estimated")

            # Check complexity indicators
            if "multiple" in story.title.lower() or "various" in story.title.lower():
                score -= 15
                issues_list.append("Title suggests multiple features")
                split_suggestions.append("Split into individual features")

            if " and " in story.title:
                score -= 10
                issues_list.append("Title contains 'and' (potential split point)")

            # Check acceptance criteria count
            ac_count = len(story.acceptance_criteria)
            if ac_count > 8:
                score -= 15
                issues_list.append(f"Too many acceptance criteria ({ac_count} > 8)")
                split_suggestions.append("Split into stories with 3-5 AC each")

            # Check description length
            desc_words = len(story.description.split()) if story.description else 0
            if desc_words > 500:
                score -= 10
                issues_list.append(f"Description very long ({desc_words} words)")

            # Estimate days (rough heuristic)
            estimated_days = (sp or 3) / 2.5  # Assume 2.5 SP per day

            is_atomic = score >= 70 and estimated_days <= 2
            should_split = sp > 5 or ac_count > 8 or not is_atomic

            return Result.ok(
                {
                    "issue_key": issue_key.key,
                    "is_atomic": is_atomic,
                    "atomicity_score": max(0, score),
                    "estimated_days": round(estimated_days, 1),
                    "should_split": should_split,
                    "split_suggestions": split_suggestions,
                    "issues": issues_list,
                }
            )

        except Exception as e:
            return Result.fail("error", [str(e)])

    def analyze_testability(self, issue_key: IssueKey) -> Result[dict, str]:
        """Use case: Analyze if story has clear test criteria"""
        try:
            import re

            issue = self._issues.find_by_key(issue_key)

            if not issue:
                return Result.fail("not_found", [f"Issue {issue_key.key} not found"])

            description = issue.description or ""
            issues_list = []
            score = 5

            if not description:
                return Result.ok(
                    {
                        "score": 0,
                        "issues": ["No description - cannot assess testability"],
                        "has_test_criteria": False,
                        "has_definition_of_done": False,
                        "has_success_metrics": False,
                        "acceptance_criteria_count": 0,
                    }
                )

            # Check for acceptance criteria checkboxes
            checkboxes = re.findall(r"\[ \]|\[x\]|\[X\]", description)
            ac_count = len(checkboxes)
            if ac_count >= 3:
                score += 3
            elif ac_count > 0:
                score += 1
            else:
                issues_list.append("No checkbox acceptance criteria")
                score -= 2

            # Check for test-related sections
            has_test_section = bool(
                re.search(r"##?\s*(test|testing|verification)", description, re.I)
            )
            has_dod = bool(re.search(r"definition of done|DoD", description, re.I))
            has_metrics = bool(re.search(r"success metrics|kpi|target", description, re.I))

            if has_test_section:
                score += 1
            else:
                issues_list.append("No testing section")

            if has_dod:
                score += 1
            else:
                issues_list.append("No Definition of Done")

            if has_metrics:
                score += 1

            # Check for verifiable criteria
            verifiable_count = len(
                re.findall(
                    r"\b(must|should|shall|verify|validate|ensure|confirm)\b",
                    description,
                    re.I,
                )
            )
            if verifiable_count >= 5:
                score += 1

            return Result.ok(
                {
                    "score": min(10, max(0, score)),
                    "issues": issues_list,
                    "has_test_criteria": ac_count > 0,
                    "has_definition_of_done": has_dod,
                    "has_success_metrics": has_metrics,
                    "acceptance_criteria_count": ac_count,
                }
            )

        except Exception as e:
            return Result.fail("error", [str(e)])

    def analyze_comprehensive(self, issue_key: IssueKey) -> Result[dict, str]:
        """Use case: Comprehensive issue analysis combining multiple metrics"""
        try:
            issue = self._issues.find_by_key(issue_key)
            if not issue:
                return Result.fail("not_found", [f"Issue {issue_key.key} not found"])

            description_result = self.analyze_description_quality(issue.description or "")
            atomicity_result = self.analyze_atomicity(issue_key)
            testability_result = self.analyze_testability(issue_key)

            if (
                description_result.success
                and atomicity_result.success
                and testability_result.success
            ):
                # Ensure values are not None for type checker
                desc_val = description_result.value
                atom_val = atomicity_result.value
                test_val = testability_result.value

                if desc_val is not None and atom_val is not None and test_val is not None:
                    return Result.ok(
                        {
                            "description_quality": desc_val,
                            "atomicity": atom_val,
                            "testability": test_val,
                            "overall_score": (
                                desc_val["score"]
                                + atom_val["atomicity_score"] / 10
                                + test_val["score"]
                            )
                            / 3,
                        }
                    )
                return Result.fail("analysis_failed", ["Analysis values were None"])
            else:
                return Result.fail("analysis_failed", ["One or more analyses failed"])

        except Exception as e:
            return Result.fail("error", [str(e)])

    def estimate_complexity(self, description: str) -> Result[dict, str]:
        """Use case: Estimate implementation complexity from description"""
        try:
            import re

            if not description:
                return Result.ok({"complexity": "unknown", "score": 0, "factors": []})

            score = 0
            factors = []

            # Check for complexity indicators
            if re.search(r"(thread|async|concurrent|parallel)", description, re.I):
                score += 3
                factors.append("Concurrency complexity")

            if re.search(r"(migrate|refactor|rewrite)", description, re.I):
                score += 2
                factors.append("Migration/refactoring work")

            if re.search(r"(security|crypto|auth|permission)", description, re.I):
                score += 2
                factors.append("Security requirements")

            if re.search(r"(performance|optimize|benchmark)", description, re.I):
                score += 2
                factors.append("Performance requirements")

            if re.search(r"(integration|external|api|third[- ]party)", description, re.I):
                score += 2
                factors.append("External integrations")

            if re.search(r"(backward[- ]compatible|migration)", description, re.I):
                score += 2
                factors.append("Backward compatibility")

            # Estimate complexity level
            if score >= 10:
                complexity = "very_high"
            elif score >= 7:
                complexity = "high"
            elif score >= 4:
                complexity = "medium"
            elif score >= 2:
                complexity = "low"
            else:
                complexity = "trivial"

            return Result.ok({"complexity": complexity, "score": score, "factors": factors})

        except Exception as e:
            return Result.fail("error", [str(e)])


class AdvancedEnhancementService:
    """Application service for advanced issue enhancement features"""

    def __init__(self, issue_repo: IIssueRepository):
        self._issues = issue_repo

    def enhance_with_template(self, issue_key: IssueKey, context: str) -> Result[dict, str]:
        """Use case: Enhance issue with context-specific templates"""
        try:
            issue = self._issues.find_by_key(issue_key)
            if not issue:
                return Result.fail("not_found", [f"Issue {issue_key.key} not found"])

            # Context-specific templates
            templates = {
                "ANI": {
                    "acceptance_criteria": [
                        "GIVEN agent A and agent B are connected via ANI",
                        "WHEN agent A sends a message",
                        "THEN agent B receives and processes the message",
                        "AND message correlation IDs are maintained",
                        "AND error handling works correctly",
                    ],
                    "technical_sections": "## Architecture\n\n## Protocol Design\n\n## Integration Points\n\n## Testing Strategy",
                },
                "Orchestration": {
                    "acceptance_criteria": [
                        "GIVEN a workflow definition is provided",
                        "WHEN the workflow is executed",
                        "THEN all steps complete in correct order",
                        "AND state is persisted at each checkpoint",
                        "AND failures trigger appropriate rollback",
                    ],
                    "technical_sections": "## State Machine\n\n## Execution Engine\n\n## Persistence\n\n## Error Handling",
                },
                "Governance": {
                    "acceptance_criteria": [
                        "GIVEN a user with specific permissions",
                        "WHEN they attempt an action",
                        "THEN authorization is checked",
                        "AND audit log is created",
                        "AND appropriate response is returned",
                    ],
                    "technical_sections": "## RBAC Model\n\n## Authorization\n\n## Audit Logging\n\n## Compliance",
                },
            }

            template = templates.get(context, templates["ANI"])

            return Result.ok(
                {
                    "enhanced": True,
                    "acceptance_criteria": template["acceptance_criteria"],
                    "technical_sections": template["technical_sections"],
                }
            )

        except Exception as e:
            return Result.fail("error", [str(e)])

    def enhance_metadata(self, _issue_key: IssueKey, themes: list[str]) -> Result[dict, str]:
        """Use case: Enhance issue metadata (labels, components, priority)"""
        try:
            # Theme to label mapping
            theme_to_labels = {
                "ANI": ["ani", "multi-agent"],
                "MCP": ["mcp", "protocol"],
                "Orchestration": ["orchestration", "workflow"],
                "Governance": ["governance", "rbac"],
                "Security": ["security", "crypto"],
            }

            # Theme to component mapping
            theme_to_component = {
                "ANI": "core-ani",
                "MCP": "core-ani",
                "Orchestration": "core-orchestration",
                "Governance": "core-governance",
                "Security": "core-governance",
            }

            labels = []
            components = []
            for theme in themes:
                labels.extend(theme_to_labels.get(theme, []))
                comp = theme_to_component.get(theme)
                if comp and comp not in components:
                    components.append(comp)

            return Result.ok(
                {
                    "labels": list(set(labels)),
                    "components": components,
                    "priority": "Medium",
                }
            )

        except Exception as e:
            return Result.fail("error", [str(e)])


class SprintOperationsService:
    """Application service for sprint operations"""

    def __init__(self, issue_repo: IIssueRepository):
        self._issues = issue_repo

    def rebalance_sprints(self, _sprint_range: tuple, _target_sp: int = 65) -> Result[dict, str]:
        """Use case: Rebalance story points across sprints"""
        try:
            # Analyze current sprint capacities
            _sprints_analysis: dict[int, Any] = {}
            moves: list[Any] = []

            # This is a simplified version - full implementation would:
            # 1. Analyze each sprint's current SP
            # 2. Identify over/under capacity sprints
            # 3. Generate move recommendations
            # 4. Execute moves if not dry-run

            return Result.ok(
                {"sprints_analyzed": 0, "moves_recommended": len(moves), "moves": moves}
            )

        except Exception as e:
            return Result.fail("error", [str(e)])

    def reorganize_by_theme(self, _sprint_range: tuple) -> Result[dict, str]:
        """Use case: Reorganize issues by theme clustering"""
        try:
            reorganization_plan: list[Any] = []

            return Result.ok(
                {
                    "reorganizations": len(reorganization_plan),
                    "plan": reorganization_plan,
                }
            )

        except Exception as e:
            return Result.fail("error", [str(e)])

    def generate_sprint_goals(self, _sprint_number: int) -> Result[dict, str]:
        """Use case: Generate sprint goals based on issues"""
        try:
            # Analyze sprint themes and generate goals
            goals = {
                "primary_goal": "Complete ANI implementation",
                "secondary_goals": ["Improve test coverage", "Add documentation"],
                "success_criteria": ["All stories done", "Tests passing"],
            }

            return Result.ok(goals)

        except Exception as e:
            return Result.fail("error", [str(e)])


class AutomationService:
    """Application service for automated operations"""

    def __init__(
        self,
        issue_repo: IIssueRepository,
        analysis_service: IssueAnalysisService,
        expert_enhancement_service: "ExpertEnhancementService",
        splitting_service: "StorySplittingService",
    ):
        self._issues = issue_repo
        self._analysis = analysis_service
        self._expert_enhancement = expert_enhancement_service
        self._splitting = splitting_service

    def auto_analyze_sprint(self, _sprint_number: int) -> Result[dict, str]:
        """Use case: Automatically analyze all issues in a sprint"""
        try:
            # Get all issues in sprint and analyze each
            results = {"analyzed": 0, "passed": 0, "failed": 0, "issues": []}

            return Result.ok(results)

        except Exception as e:
            return Result.fail("error", [str(e)])

    def auto_enhance_issue(self, issue_key: str) -> Result[dict, str]:
        """Use case: Automatically enhance a single issue with full analysis.

        Delegates to ExpertEnhancementService.enhance_issue() with all flags enabled:
        force, architecture analysis, and metadata updates.
        """
        try:
            enhance_req = EnhanceIssueRequest(
                issue_key=issue_key,
                force=True,
                update_metadata=True,
                apply_architecture=True,
            )

            result = self._expert_enhancement.enhance_issue(enhance_req, dry_run=False)

            if result.success and result.value:
                response = result.value
                return Result.ok(
                    {
                        "issue_key": response.issue_key,
                        "previous_readiness": response.previous_readiness,
                        "new_readiness": response.new_readiness,
                        "changes_made": response.changes_made,
                        "architecture_review": response.architecture_review,
                    }
                )
            else:
                return Result.fail(result.error or "unknown", result.errors)

        except Exception as e:
            return Result.fail("error", [str(e)])

    def auto_enhance_sprint(
        self, _sprint_number: int, _readiness_filter: str = "PARTIALLY_READY"
    ) -> Result[dict, str]:
        """Use case: Automatically enhance issues below readiness threshold.

        Delegates to ExpertEnhancementService.enhance_sprint() with full
        architecture analysis, metadata updates, and force re-enhancement.
        """
        try:
            sprint_request = EnhanceSprintRequest(
                sprint_number=_sprint_number,
                execute=True,
                force=True,
                update_metadata=True,
                apply_architecture=True,
            )

            sprint_result = self._expert_enhancement.enhance_sprint(sprint_request, dry_run=False)

            if sprint_result.success and sprint_result.value:
                response = sprint_result.value
                return Result.ok(
                    {
                        "enhanced": len(response.enhanced),
                        "skipped": len(response.skipped),
                        "failed": len(response.failed),
                        "total_changes": response.total_changes,
                        "enhanced_keys": response.enhanced,
                        "skipped_keys": response.skipped,
                        "failed_keys": response.failed,
                    }
                )
            else:
                return Result.fail(
                    sprint_result.error or "unknown",
                    sprint_result.errors,
                )

        except Exception as e:
            return Result.fail("error", [str(e)])

    def auto_split_sprint(self, _sprint_number: int, _max_sp: int = 8) -> Result[dict, str]:
        """Use case: Automatically split stories exceeding SP threshold"""
        try:
            results = {"split": 0, "subtasks_created": 0, "skipped": 0}

            return Result.ok(results)

        except Exception as e:
            return Result.fail("error", [str(e)])


class ReportingService:
    """Application service for generating reports"""

    def __init__(self, issue_repo: IIssueRepository):
        self._issues = issue_repo

    def generate_quality_report(self, _sprint_range: tuple) -> Result[dict, str]:
        """Use case: Generate quality metrics report"""
        try:
            report = {
                "sprints_analyzed": 0,
                "avg_description_quality": 0.0,
                "avg_atomicity": 0.0,
                "avg_testability": 0.0,
                "issues_needing_improvement": [],
            }

            return Result.ok(report)

        except Exception as e:
            return Result.fail("error", [str(e)])

    def generate_velocity_report(self, _sprint_range: tuple) -> Result[dict, str]:
        """Use case: Generate velocity and throughput report"""
        try:
            report = {
                "sprints": [],
                "avg_velocity": 0.0,
                "completion_rate": 0.0,
                "trend": "stable",
            }

            return Result.ok(report)

        except Exception as e:
            return Result.fail("error", [str(e)])

    def generate_themes_report(self, _sprint_range: tuple) -> Result[dict, str]:
        """Use case: Generate theme distribution report"""
        try:
            report = {"themes": {}, "most_common": "", "distribution": []}

            return Result.ok(report)

        except Exception as e:
            return Result.fail("error", [str(e)])


class DashboardService:
    """Application service for Jira dashboard and filter provisioning."""

    def __init__(self, jira_api: JiraApiClient, config: AtlassianConfig):
        self._jira_api = jira_api
        self._config = config

    def create_launch_dashboard(
        self,
        project_key: str | None = None,
        dashboard_name: str | None = None,
        execute: bool = False,
        share_global: bool = True,
    ) -> Result[dict, str]:
        """Create launch burndown filters and a dashboard.

        Args:
            project_key: Jira project key (defaults to configured project).
            dashboard_name: Optional dashboard title override.
            execute: If False, return a dry-run plan.
            share_global: If True, dashboard is globally visible/editable.

        Returns:
            Result with creation details or dry-run preview.
        """
        try:
            target_project = (project_key or self._config.project_key).upper()
            name = dashboard_name or f"{target_project} Launch Burndown"
            filters = self._build_launch_filters(target_project)

            if not execute:
                return Result.ok(
                    {
                        "dry_run": True,
                        "project_key": target_project,
                        "dashboard_name": name,
                        "filters": filters,
                    }
                )

            if not self._config.api_token:
                return Result.fail(
                    "missing_credentials",
                    [
                        "Missing Atlassian API token. Set ATLASSIAN_API_TOKEN or atlassian_API_key.",
                    ],
                )

            created_filters: list[dict[str, Any]] = []
            for filter_spec in filters:
                created = self._jira_api.create_filter(
                    name=filter_spec["name"],
                    jql=filter_spec["jql"],
                    description=filter_spec["description"],
                    favourite=True,
                )
                created_filters.append(created)

            description_lines = [
                "Launch dashboard generated by Atlassian CLI v3.",
                "",
                "Saved filters:",
            ]
            for item in created_filters:
                filter_name = item.get("name", "Unnamed Filter")
                filter_url = item.get("viewUrl", "")
                description_lines.append(f"- {filter_name}: {filter_url}")

            dashboard = self._jira_api.create_dashboard(
                name=name,
                description="\n".join(description_lines),
                share_global=share_global,
            )

            return Result.ok(
                {
                    "dry_run": False,
                    "project_key": target_project,
                    "dashboard": dashboard,
                    "filters": created_filters,
                }
            )
        except Exception as e:
            return Result.fail("error", [str(e)])

    def _build_launch_filters(self, project_key: str) -> list[dict[str, str]]:
        """Build the launch burndown filter pack for a Jira project."""
        return [
            {
                "name": f"{project_key} Launch Must-Close",
                "description": "Launch-critical unresolved issues for go-live scope.",
                "jql": (
                    f"project = {project_key} "
                    "AND labels in (launch-critical, launch-must-close) "
                    "AND statusCategory != Done "
                    "ORDER BY priority DESC, updated DESC"
                ),
            },
            {
                "name": f"{project_key} Launch Deferred",
                "description": "Items explicitly deferred to post-launch.",
                "jql": (
                    f"project = {project_key} "
                    "AND labels in (launch-defer, post-launch) "
                    "AND statusCategory != Done "
                    "ORDER BY priority DESC, updated DESC"
                ),
            },
            {
                "name": f"{project_key} Launch Blockers",
                "description": "Current blockers and incidents threatening launch readiness.",
                "jql": (
                    f"project = {project_key} "
                    "AND (priority in (Highest, High) OR labels in (blocker, incident)) "
                    "AND statusCategory != Done "
                    "ORDER BY priority DESC, created ASC"
                ),
            },
            {
                "name": f"{project_key} Go/No-Go Today",
                "description": "Daily go/no-go check against launch labels and unresolved work.",
                "jql": (
                    f"project = {project_key} "
                    "AND labels in (launch-critical, launch-must-close, blocker, incident) "
                    "AND statusCategory != Done "
                    "ORDER BY updated DESC"
                ),
            },
        ]


class VerificationService:
    """Application service for verification operations"""

    def __init__(self, issue_repo: IIssueRepository):
        self._issues = issue_repo

    def verify_sprint(self, sprint_number: int) -> Result[dict, str]:
        """Use case: Verify sprint readiness and quality"""
        try:
            verification = {
                "sprint_number": sprint_number,
                "is_ready": True,
                "issues_found": [],
                "warnings": [],
            }

            return Result.ok(verification)

        except Exception as e:
            return Result.fail("error", [str(e)])

    def verify_themes(self, _sprint_number: int) -> Result[dict, str]:
        """Use case: Verify theme consistency and labeling"""
        try:
            verification = {
                "themes_consistent": True,
                "unlabeled_issues": [],
                "label_mismatches": [],
            }

            return Result.ok(verification)

        except Exception as e:
            return Result.fail("error", [str(e)])

    def verify_stories(
        self,
        sprint_number: int,
        min_words: int = 80,
        require_confluence_link: bool = True,
    ) -> Result[dict, str]:
        """Use case: Verify story clarity and Confluence technical references."""
        try:
            import re

            sprint = SprintIdentifier(sprint_number)
            issues = self._issues.find_by_sprint(sprint)
            stories = [issue for issue in issues if issue.issue_type == IssueType.STORY]

            confluence_pattern = re.compile(
                r"https?://[^\s\]|>]*atlassian\.net/wiki[^\s\]|>]*",
                re.IGNORECASE,
            )
            url_pattern = re.compile(r"https?://[^\s\]|>]+", re.IGNORECASE)

            story_results: list[dict[str, Any]] = []
            issues_found: list[str] = []
            warnings: list[str] = []

            for story in stories:
                if not story.key:
                    continue

                description = story.description or ""
                word_count = len(re.findall(r"\w+", description))
                description_lower = description.lower()

                has_scope_terms = any(
                    token in description_lower
                    for token in [
                        "implement",
                        "build",
                        "create",
                        "update",
                        "refactor",
                        "integrat",
                        "test",
                        "acceptance criteria",
                        "requirements",
                        "definition of done",
                    ]
                )
                has_structure_terms = any(
                    token in description_lower
                    for token in [
                        "acceptance criteria",
                        "requirements",
                        "implementation",
                        "technical",
                    ]
                )
                clarity_ok = word_count >= min_words and has_scope_terms and has_structure_terms

                desc_confluence_links: list[str] = []
                remote_confluence_links: list[str] = []

                try:
                    raw_issue = self._issues.get_raw_issue(story.key, fields=["description"])
                    raw_description = (raw_issue.get("fields") or {}).get("description")
                    links: list[str] = []

                    def _walk_adf(node: Any) -> None:
                        if isinstance(node, dict):
                            href = (node.get("attrs") or {}).get("href")
                            if isinstance(href, str):
                                links.append(href)
                            text_value = node.get("text")
                            if isinstance(text_value, str):
                                links.extend(url_pattern.findall(text_value))
                            for value in node.values():
                                _walk_adf(value)
                        elif isinstance(node, list):
                            for item in node:
                                _walk_adf(item)

                    _walk_adf(raw_description)
                    desc_confluence_links = sorted(
                        {url for url in links if confluence_pattern.search(url or "")}
                    )
                except Exception as ex:
                    warnings.append(
                        f"Could not inspect description links for {story.key.key}: {ex}"
                    )

                try:
                    raw_remote_links = self._issues.get_remote_links(story.key)
                    for link_obj in raw_remote_links:
                        obj = link_obj.get("object") or {}
                        url = obj.get("url", "")
                        if isinstance(url, str) and confluence_pattern.search(url):
                            remote_confluence_links.append(url)
                    remote_confluence_links = sorted(set(remote_confluence_links))
                except Exception as ex:
                    warnings.append(f"Could not inspect remote links for {story.key.key}: {ex}")

                confluence_links_total = len(desc_confluence_links) + len(remote_confluence_links)
                has_confluence_reference = confluence_links_total > 0

                if not clarity_ok:
                    issues_found.append(
                        f"{story.key.key}: description lacks enough implementation clarity"
                    )

                if require_confluence_link and not has_confluence_reference:
                    issues_found.append(f"{story.key.key}: missing Confluence technical reference")

                story_results.append(
                    {
                        "key": story.key.key,
                        "title": story.title,
                        "word_count": word_count,
                        "clarity_ok": clarity_ok,
                        "has_confluence_reference": has_confluence_reference,
                        "description_confluence_links": desc_confluence_links,
                        "remote_confluence_links": remote_confluence_links,
                    }
                )

            verification = {
                "sprint_number": sprint_number,
                "story_count": len(stories),
                "checked": len(story_results),
                "is_ready": len(issues_found) == 0,
                "issues_found": issues_found,
                "warnings": warnings,
                "stories": story_results,
            }

            return Result.ok(verification)

        except Exception as e:
            return Result.fail("error", [str(e)])


class ImportService:
    """
    Application service for importing issues from documents.

    DRY ARCHITECTURE:
    - Single DocumentAnalyzer works with any ImportedDocument
    - Multiple DocumentImporters produce ImportedDocument (Strategy)
    - SRP: Import (fetching) separated from Analysis (extracting)

    Flow:
        Source -> Importer -> ImportedDocument -> Analyzer -> DocumentAnalysisResult
    """

    def __init__(
        self,
        issue_repo: IIssueRepository,
        confluence_repo: IConfluenceRepository | None = None,
        theme_detector: IThemeDetector | None = None,
        context_resolver: IBoundedContextResolver | None = None,
        priority_calculator: IPriorityCalculator | None = None,
        duplicate_detector: IDuplicateDetector | None = None,
        codebase_cross_referencer: ICodebaseCrossReferencer | None = None,
        backlog_analyzer: IBacklogAnalyzer | None = None,
        # DRY ARCHITECTURE: Importers + Single Analyzer
        importer_factory: Optional["DocumentImporterFactory"] = None,
        document_analyzer: Optional["DocumentAnalyzer"] = None,
        doc_sync_service: Optional["DocumentSyncService"] = None,
    ):
        """
        Initialize with dependency injection.

        Args:
            issue_repo: Repository for Jira issue operations
            confluence_repo: Repository for Confluence page operations
            theme_detector: Service for detecting themes
            context_resolver: Service for resolving bounded contexts
            priority_calculator: Service for calculating priority
            duplicate_detector: Service for detecting duplicate issues
            codebase_cross_referencer: Service for validating against codebase
            backlog_analyzer: Service for comprehensive backlog analysis
            importer_factory: Factory for selecting appropriate document importer
            document_analyzer: SINGLE analyzer for ALL document types
            doc_sync_service: Service for Confluence documentation sync
        """
        self._issues = issue_repo
        self._confluence_repo = confluence_repo
        self._theme_detector = theme_detector
        self._context_resolver = context_resolver
        self._priority_calculator = priority_calculator
        self._duplicate_detector = duplicate_detector
        self._codebase_cross_referencer = codebase_cross_referencer
        self._backlog_analyzer = backlog_analyzer

        # DRY architecture components
        self._importer_factory = importer_factory
        self._document_analyzer = document_analyzer
        self._doc_sync_service = doc_sync_service

    def _import_with_architecture(
        self, source: str, **kwargs
    ) -> Result[DocumentAnalysisResult, str]:
        """
        Import using DRY architecture: Importer -> Document -> Analyzer.

        DRY: Single analyzer, multiple importers.
        SRP: Import (fetching) separated from Analysis (extracting).

        Args:
            source: File path or Confluence URL/page ID
            **kwargs: Additional parameters passed to importer (e.g., include_children)

        Returns:
            Result containing DocumentAnalysisResult or error
        """
        if not self._importer_factory or not self._document_analyzer:
            return Result.fail(
                "architecture_not_configured",
                ["ImportService requires importer_factory and document_analyzer"],
            )

        # 1. Get appropriate importer via factory
        importer = self._importer_factory.get_importer(source)
        if not importer:
            return Result.fail("unsupported_source", [f"No importer supports source: {source}"])

        # 2. Import document (fetch content)
        try:
            document = importer.import_document(source, **kwargs)
        except Exception as e:
            return Result.fail("import_error", [str(e)])

        # 3. Analyze document (extract work items) - SINGLE analyzer
        try:
            analysis = self._document_analyzer.analyze(document)
            return Result.ok(analysis)
        except Exception as e:
            return Result.fail("analysis_error", [str(e)])

    def import_document(
        self,
        source: str,
        execute: bool = False,
        include_children: bool = False,
        sprint_number: int | None = None,
        epic_only: bool = False,
        with_docs: bool = False,
        verbose: bool = False,
        skip_duplicate_check: bool = False,
        validate_codebase: bool = False,
        analyze_backlog: bool = False,
        **kwargs,
    ) -> Result[dict, str]:
        """
        UNIFIED import method - works with ANY document source.

        DRY ARCHITECTURE:
            Source -> Factory -> Importer -> ImportedDocument -> Analyzer -> DocumentAnalysisResult

        This is the SINGLE entry point for all imports. The factory auto-detects source type.

        Args:
            source: File path, Confluence page ID/URL, or YAML file
            execute: If True, create issues; if False, dry-run preview
            include_children: For Confluence, also import child pages
            sprint_number: Optional sprint number to assign issues
            epic_only: If True, create only epic(s) without stories/tasks
            with_docs: If True, also generate Confluence docs
            verbose: If True, show detailed analysis notes
            skip_duplicate_check: If True, skip checking for existing similar issues
            validate_codebase: If True, cross-reference with actual codebase
            analyze_backlog: If True, perform comprehensive backlog analysis
            **kwargs: Additional parameters passed to specific importers

        Returns:
            Result with import statistics and created issues
        """
        try:
            # Use DRY architecture
            result = self._import_with_architecture(
                source, include_children=include_children, **kwargs
            )
            if not result.success or result.value is None:
                return Result.fail(result.error or "import_failed", result.errors)

            analysis = result.value

            if not analysis.success:
                return Result.fail("analysis_error", analysis.errors)

            # === DUPLICATE DETECTION ===
            duplicate_analysis = None
            if self._duplicate_detector and not skip_duplicate_check:
                from ..infrastructure.duplicate_detector import DuplicateAnalysisResult

                duplicate_analysis = DuplicateAnalysisResult()

                for epic in analysis.epics:
                    matches = self._duplicate_detector.find_similar_issues(
                        epic.title, issue_type="Epic", threshold=0.3
                    )
                    duplicate_analysis.epic_matches.extend(matches)

                for story in analysis.stories:
                    matches = self._duplicate_detector.find_similar_issues(
                        story.title, issue_type="Story", threshold=0.5
                    )
                    duplicate_analysis.story_matches.extend(matches)

            # === CODEBASE VALIDATION ===
            codebase_validation = None
            if self._codebase_cross_referencer and validate_codebase:
                codebase_validation = self._codebase_cross_referencer.validate_architecture(
                    analysis
                )

            # === BACKLOG ANALYSIS ===
            backlog_analysis = None
            if self._backlog_analyzer and analyze_backlog:
                config = AtlassianConfig.from_environment()
                backlog_analysis = self._backlog_analyzer.analyze_backlog(
                    project_key=config.project_key
                )

            # Extract component information for reporting
            # Components are represented as stories under architecture epics
            components: list[dict[str, Any]] = []
            for epic in analysis.epics:
                if "architecture" in epic.title.lower() or "implementation" in epic.title.lower():
                    # These epics contain component stories
                    for story in epic.children:
                        components.append(
                            {
                                "name": story.title,
                                "type": "component",
                                "bounded_context": story.bounded_context,
                                "patterns": story.labels,
                                "responsibilities": story.description.split("\n")[:3]
                                if story.description
                                else [],
                            }
                        )

            if verbose:
                print(
                    f"[DEBUG] Extracted {len(components)} components from {len(analysis.epics)} epics"
                )
                if components:
                    for comp in components[:5]:
                        print(f"[DEBUG]   - {comp.get('name')}: in {comp.get('bounded_context')}")

            # Build result
            stats: dict[str, Any] = {
                "epics_created": 0,
                "stories_created": 0,
                "tasks_created": 0,
                "errors": [],
                "dry_run": not execute,
                "pages_analyzed": analysis.pages_analyzed,
                "components_identified": len(components),
                "plan": {
                    "epics": len(analysis.epics),
                    "stories": len(analysis.stories),
                    "tasks": len(analysis.tasks),
                },
                "component_details": components,
                "epic_details": [
                    {
                        "title": e.title,
                        "description": e.description[:500] if e.description else "",
                        "bounded_context": e.bounded_context,
                        "acceptance_criteria": e.acceptance_criteria,
                        "children": len(e.children),
                    }
                    for e in analysis.epics
                ],
                "story_details": [
                    {
                        "title": s.title,
                        "description": s.description[:300] if s.description else "",
                        "bounded_context": s.bounded_context,
                        "story_points": s.story_points,
                    }
                    for s in analysis.stories
                ],
                "task_details": [
                    {
                        "title": t.title,
                        "description": t.description[:200] if t.description else "",
                        "bounded_context": t.bounded_context,
                    }
                    for t in analysis.tasks
                ],
                "analysis_notes": analysis.analysis_notes if verbose else [],
            }

            if duplicate_analysis:
                stats["duplicate_analysis"] = {
                    "has_potential_duplicates": duplicate_analysis.has_potential_duplicates,
                    "has_likely_duplicates": duplicate_analysis.has_likely_duplicates,
                    "total_matches": duplicate_analysis.total_matches,
                    "warnings": duplicate_analysis.warnings,
                    "epic_matches": [
                        {
                            "issue_key": m.issue_key,
                            "title": m.summary,
                            "similarity": m.similarity,
                            "status": m.status,
                            "is_likely_duplicate": m.similarity > 0.7,
                        }
                        for m in duplicate_analysis.epic_matches
                    ],
                    "story_matches": [
                        {
                            "issue_key": m.issue_key,
                            "title": m.summary,
                            "similarity": m.similarity,
                            "status": m.status,
                            "is_likely_duplicate": m.similarity > 0.8,
                        }
                        for m in duplicate_analysis.story_matches
                    ],
                }

            if codebase_validation:
                stats["codebase_validation"] = codebase_validation

            if backlog_analysis:
                stats["backlog_analysis"] = backlog_analysis

            # Execute import if requested
            if execute:
                execution_stats = self._execute_import_from_analysis(
                    analysis,
                    with_docs=with_docs,
                    sprint_number=sprint_number,
                    epic_only=epic_only,
                )
                stats.update(execution_stats)
            else:
                stats["message"] = "Dry run mode - use --execute to create issues"

            return Result.ok(stats)

        except FileNotFoundError as e:
            return Result.fail("file_not_found", [str(e)])
        except Exception as e:
            return Result.fail("import_error", [str(e)])

    def import_from_markdown(
        self, file_path: str, execute: bool = False, with_docs: bool = False
    ) -> Result[dict, str]:
        """
        Import issues from markdown file.

        DEPRECATED: Use import_document() instead. Kept for backwards compatibility.
        """
        return self.import_document(source=file_path, execute=execute, with_docs=with_docs)

    def _execute_import_from_analysis(
        self,
        analysis: DocumentAnalysisResult,
        with_docs: bool = False,
        sprint_number: int | None = None,
        epic_only: bool = False,
    ) -> dict[str, Any]:
        """
        Execute import from unified DocumentAnalysisResult.

        DRY: Single import execution method for all document sources.
        """
        stats: dict[str, Any] = {
            "epics_created": 0,
            "stories_created": 0,
            "tasks_created": 0,
            "errors": [],
            "dry_run": False,
            "created_issues": [],
            "created_stories": [],
        }

        try:
            # Create epics first
            for epic_item in analysis.epics:
                epic_key = self._create_epic_from_work_item(epic_item)
                if epic_key:
                    stats["epics_created"] = stats["epics_created"] + 1
                    stats["created_issues"].append(
                        {"key": epic_key, "type": "Epic", "title": epic_item.title}
                    )

                    # Create child stories under this epic
                    if not epic_only:
                        for story_item in epic_item.children:
                            story_key = self._create_story_from_work_item(
                                story_item,
                                parent_epic=epic_key,
                                sprint_number=sprint_number,
                            )
                            if story_key:
                                stats["stories_created"] = stats["stories_created"] + 1
                                stats["created_stories"].append(story_key)
                                stats["created_issues"].append(
                                    {
                                        "key": story_key,
                                        "type": "Story",
                                        "title": story_item.title,
                                        "epic": epic_key,
                                    }
                                )

                                # Generate documentation if requested
                                if with_docs and self._doc_sync_service:
                                    doc_request = CreateDocsRequest(
                                        issue_key=story_key,
                                        include_spec=True,
                                        include_test_plan=True,
                                        execute=True,
                                    )
                                    self._doc_sync_service.create_docs(doc_request)

            if epic_only:
                return stats

            # Create orphan stories (not linked to an epic)
            for story_item in analysis.orphan_stories:
                story_key = self._create_story_from_work_item(
                    story_item, sprint_number=sprint_number
                )
                if story_key:
                    stats["stories_created"] = stats["stories_created"] + 1
                    stats["created_stories"].append(story_key)
                    stats["created_issues"].append(
                        {"key": story_key, "type": "Story", "title": story_item.title}
                    )

                    # Generate documentation if requested
                    if with_docs and self._doc_sync_service:
                        doc_request = CreateDocsRequest(
                            issue_key=story_key,
                            include_spec=True,
                            include_test_plan=True,
                            execute=True,
                        )
                        self._doc_sync_service.create_docs(doc_request)

            # Create standalone stories
            for story_item in analysis.stories:
                story_key = self._create_story_from_work_item(
                    story_item, sprint_number=sprint_number
                )
                if story_key:
                    stats["stories_created"] = stats["stories_created"] + 1
                    stats["created_stories"].append(story_key)
                    stats["created_issues"].append(
                        {"key": story_key, "type": "Story", "title": story_item.title}
                    )

                    # Generate documentation if requested
                    if with_docs and self._doc_sync_service:
                        doc_request = CreateDocsRequest(
                            issue_key=story_key,
                            include_spec=True,
                            include_test_plan=True,
                            execute=True,
                        )
                        self._doc_sync_service.create_docs(doc_request)

            # Create tasks
            for task_item in analysis.tasks:
                task_key = self._create_task_from_work_item(task_item)
                if task_key:
                    stats["tasks_created"] = stats["tasks_created"] + 1
                    stats["created_issues"].append(
                        {"key": task_key, "type": "Task", "title": task_item.title}
                    )

        except Exception as e:
            stats["errors"].append(str(e))

        return stats

    def _create_epic_from_work_item(self, item: ParsedWorkItem) -> str | None:
        """Create a Jira Epic from a ParsedWorkItem."""
        try:
            # Use domain model to create epic
            epic = Epic(
                key=None,
                title=item.title,
                description=item.description,
                objective=item.description[:200] if item.description else "",
                bounded_context=get_bounded_context(item.bounded_context),
                priority=Priority[item.priority.upper()] if item.priority else Priority.MEDIUM,
            )

            # Add labels
            for label in item.labels:
                epic.add_label(Label(label))

            # Add themes
            for theme in item.themes:
                epic.add_theme(Theme(theme))

            # Persist
            epic_key = self._issues.create(epic)
            return epic_key.key if epic_key else None

        except Exception:
            return None

    def _create_story_from_work_item(
        self,
        item: ParsedWorkItem,
        parent_epic: str | None = None,
        sprint_number: int | None = None,
    ) -> str | None:
        """Create a Jira Story from a ParsedWorkItem."""
        try:
            epic_key = IssueKey(parent_epic) if parent_epic else None

            story = Story(
                key=None,
                title=item.title,
                description=item.description,
                bounded_context=get_bounded_context(item.bounded_context),
                epic_key=epic_key,
                priority=Priority[item.priority.upper()] if item.priority else Priority.MEDIUM,
            )

            # Add acceptance criteria
            for criterion in item.acceptance_criteria:
                story.add_acceptance_criterion(AcceptanceCriterion(criterion))

            # Add labels
            for label in item.labels:
                story.add_label(Label(label))

            # Set story points
            if item.story_points:
                story.set_story_points(StoryPoints(item.story_points))

            # Assign to sprint if provided
            if sprint_number:
                story.assign_to_sprint(SprintIdentifier(int(sprint_number)))

            # Persist
            story_key = self._issues.create(story)
            return story_key.key if story_key else None

        except Exception:
            return None

    def _create_task_from_work_item(
        self, item: ParsedWorkItem, parent_story_key: str | None = None
    ) -> str | None:
        """Create a Jira Task from a ParsedWorkItem."""
        try:
            if not parent_story_key:
                return None

            task = Task(
                key=None,
                title=item.title,
                description=item.description,
                parent_story_key=IssueKey(parent_story_key),
                priority=Priority[item.priority.upper()] if item.priority else Priority.MEDIUM,
            )

            # Add labels
            for label in item.labels:
                task.add_label(Label(label))

            # Persist
            task_key = self._issues.create(task)
            return task_key.key if task_key else None

        except Exception:
            return None

    def import_from_confluence(
        self,
        page_id: str,
        include_children: bool = False,
        execute: bool = False,
        sprint_number: int | None = None,
        epic_only: bool = False,
        with_docs: bool = False,
        verbose: bool = False,
        _min_content_length: int = 100,
        skip_duplicate_check: bool = False,
        validate_codebase: bool = False,
        analyze_backlog: bool = False,
    ) -> Result[dict, str]:
        """
        Import issues from Confluence architecture documentation.

        DEPRECATED: Use import_document() instead. Kept for backwards compatibility.

        Args:
            page_id: Confluence page ID or URL
            include_children: If True, also import child pages
            execute: If True, create issues; if False, dry-run preview
            sprint_number: Optional sprint number to assign issues
            epic_only: If True, create only epic(s) without stories/tasks
            with_docs: If True, also generate Confluence docs for created issues
            verbose: If True, show detailed analysis notes
            skip_duplicate_check: If True, skip checking for existing similar issues
            validate_codebase: If True, cross-reference with actual codebase
            analyze_backlog: If True, perform comprehensive backlog analysis

        Returns:
            Result with import statistics and created issues
        """
        return self.import_document(
            source=page_id,
            include_children=include_children,
            execute=execute,
            sprint_number=sprint_number,
            epic_only=epic_only,
            with_docs=with_docs,
            verbose=verbose,
            skip_duplicate_check=skip_duplicate_check,
            validate_codebase=validate_codebase,
            analyze_backlog=analyze_backlog,
        )

    def _execute_import(self, plan, with_docs: bool = False) -> dict:
        """Execute the actual import, creating Jira issues and optionally Confluence docs"""
        stats: dict[str, Any] = {
            "epics_created": 0,
            "stories_created": 0,
            "tasks_created": 0,
            "errors": [],
            "created_epics": [],
            "created_stories": [],
            "created_docs": [],
        }

        # Create Epics first
        for parsed_epic in plan.epics:
            try:
                # Convert priority string to Priority enum
                priority_map = {
                    "P0-CRITICAL": Priority.HIGHEST,
                    "P1-HIGH": Priority.HIGH,
                    "P2-MEDIUM": Priority.MEDIUM,
                }
                priority = priority_map.get(parsed_epic.priority, Priority.MEDIUM)

                # Determine bounded context using StoryContextResolver for
                # consistent resolution with the enhancement pipeline
                from ..infrastructure.story_domain_knowledge import StoryContextResolver

                _context_resolver = StoryContextResolver()
                _story_ctx = _context_resolver.resolve(
                    parsed_epic.title, parsed_epic.description or ""
                )
                bounded_context_name = _story_ctx.primary_bounded_context

                bounded_context = get_bounded_context(bounded_context_name)

                # Extract objective from description (first sentence) or use title
                objective = (
                    parsed_epic.description.split(".")[0].strip()
                    if parsed_epic.description
                    else parsed_epic.title
                )

                # Create domain Epic model
                epic = Epic(
                    key=None,  # Will be set after creation
                    title=parsed_epic.title,
                    description=parsed_epic.description or "",
                    objective=objective,
                    bounded_context=bounded_context,
                    priority=priority,
                )

                # Add labels
                for label_str in parsed_epic.labels or []:
                    try:
                        epic.add_label(Label(label_str))
                    except Exception:
                        pass  # Skip invalid labels

                # Add themes
                for theme_str in parsed_epic.themes or []:
                    try:
                        epic.add_theme(Theme(theme_str))
                    except Exception:
                        pass

                # Create Epic in Jira via repository
                epic_key = self._issues.create(epic)
                parsed_epic.jira_key = str(epic_key.key)
                stats["epics_created"] = stats["epics_created"] + 1
                stats["created_epics"].append(epic_key.key)

                # Create Stories under this Epic
                for parsed_story in parsed_epic.children:
                    if parsed_story.type == ParsedIssueType.STORY:
                        try:
                            # Build description with acceptance criteria
                            desc = parsed_story.description or ""
                            if parsed_story.acceptance_criteria:
                                desc += "\n\nh3. Acceptance Criteria\n"
                                for ac in parsed_story.acceptance_criteria:
                                    desc += f"* {ac}\n"

                            story_priority = priority_map.get(
                                parsed_story.priority, Priority.MEDIUM
                            )

                            # Create domain Story model (inherit bounded_context from Epic)
                            story = Story(
                                key=None,
                                title=parsed_story.title,
                                description=desc,
                                bounded_context=bounded_context,  # Use same as parent Epic
                                priority=story_priority,
                                epic_key=epic_key,
                            )

                            # Add acceptance criteria
                            for ac_text in parsed_story.acceptance_criteria or []:
                                try:
                                    story.add_acceptance_criterion(AcceptanceCriterion(ac_text))
                                except Exception:
                                    pass

                            # Add labels
                            for label_str in parsed_story.labels or []:
                                try:
                                    story.add_label(Label(label_str))
                                except Exception:
                                    pass

                            # Create Story in Jira
                            story_key = self._issues.create(story)
                            parsed_story.jira_key = str(story_key.key)
                            stats["stories_created"] = stats["stories_created"] + 1
                            stats["created_stories"].append(story_key.key)

                        except Exception as e:
                            stats["errors"].append(
                                f"Failed to create story '{parsed_story.title}': {e!s}"
                            )

                # Generate Confluence docs for Epic (if requested)
                if with_docs and parsed_epic.jira_key:
                    doc_result = self._generate_epic_documentation(parsed_epic)
                    if doc_result.success:
                        doc_url = doc_result.value
                        stats["created_docs"].append(
                            {"issue_key": parsed_epic.jira_key, "doc_url": doc_url}
                        )
                    else:
                        stats["errors"].append(
                            f"Failed to create docs for {parsed_epic.jira_key}: {doc_result.error}"
                        )

            except Exception as e:
                stats["errors"].append(f"Failed to create epic '{parsed_epic.title}': {e!s}")

        # Create orphan stories
        for parsed_story in plan.orphan_stories:
            try:
                desc = parsed_story.description or ""
                if parsed_story.acceptance_criteria:
                    desc += "\n\nh3. Acceptance Criteria\n"
                    for ac in parsed_story.acceptance_criteria:
                        desc += f"* {ac}\n"

                priority_map = {
                    "P0-CRITICAL": Priority.HIGHEST,
                    "P1-HIGH": Priority.HIGH,
                    "P2-MEDIUM": Priority.MEDIUM,
                }
                story_priority = priority_map.get(parsed_story.priority, Priority.MEDIUM)

                story = Story(
                    key=None,
                    title=parsed_story.title,
                    description=desc,
                    bounded_context=get_bounded_context("core-models"),
                    priority=story_priority,
                )

                for label_str in parsed_story.labels or []:
                    try:
                        story.add_label(Label(label_str))
                    except Exception:
                        pass

                story_key = self._issues.create(story)
                stats["stories_created"] = stats["stories_created"] + 1
                stats["created_stories"].append(story_key.key)

            except Exception as e:
                stats["errors"].append(
                    f"Failed to create orphan story '{parsed_story.title}': {e!s}"
                )

        return stats

    def _generate_epic_documentation(self, epic) -> Result[str, str]:
        """
        Generate Confluence documentation for an Epic.

        Creates a page with:
        - Epic overview and objectives
        - Feature breakdown (stories)
        - Acceptance criteria
        - Technical specifications

        Returns URL of created Confluence page.
        """
        try:
            # Build markdown content first (readable, structured)
            markdown_content = f"""# {epic.title}

## 📋 Overview

{epic.description or "No description provided."}

## 🔗 Jira Epic

[{epic.jira_key}](https://inovagio.atlassian.net/browse/{epic.jira_key})

## ✨ Features

"""
            # Add stories table if available
            if hasattr(epic, "children") and epic.children:
                markdown_content += """
| Story | Story Key | Status |
|-------|-----------|--------|
"""
                for story in epic.children:
                    if story.type == ParsedIssueType.STORY and story.jira_key:
                        markdown_content += f"| {story.title} | [{story.jira_key}](https://inovagio.atlassian.net/browse/{story.jira_key}) | To Do |\n"

            # Add acceptance criteria if available
            if hasattr(epic, "acceptance_criteria") and epic.acceptance_criteria:
                markdown_content += "\n## ✅ Acceptance Criteria\n\n"
                for ac in epic.acceptance_criteria:
                    markdown_content += f"- [ ] {ac}\n"

            # Add metadata
            markdown_content += f"""

---

## 📊 Metadata

- **Priority**: {epic.priority or "Medium"}
- **Labels**: {", ".join(epic.labels) if hasattr(epic, "labels") and epic.labels else "None"}
- **Themes**: {", ".join(epic.themes) if hasattr(epic, "themes") and epic.themes else "None"}

---

*This page was auto-generated from the implementation plan*
"""

            # Convert markdown to readable Confluence format
            formatter = MarkdownConfluenceFormatter()
            content = formatter.markdown_to_confluence(markdown_content)

            # Create actual Confluence page
            try:
                config = AtlassianConfig.from_environment()
                confluence_client = ConfluenceApiClient(config)
                confluence_repo = ConfluencePageRepository(confluence_client)

                # Use existing Engineering Documentation page as root
                engineering_docs_id = ConfluencePageId(config.confluence_parent_page_id)

                # Find or create "Workflow Engine" subfolder under Engineering Documentation
                workflow_folder_title = "Workflow Engine"
                workflow_folder_id = confluence_repo.find_page_by_title(
                    config.confluence_space, workflow_folder_title
                )

                if not workflow_folder_id:
                    # Create Workflow Engine subfolder
                    folder_content = "<h1>Workflow Engine</h1><p>Auto-generated documentation for workflow epics and implementation plans.</p>"
                    workflow_folder_id = confluence_repo.create_page(
                        space_key=config.confluence_space,
                        title=workflow_folder_title,
                        content=folder_content,
                        parent_page_id=engineering_docs_id,
                    )

                # Create epic page under Workflow Engine folder
                page_id = confluence_repo.create_page(
                    space_key=config.confluence_space,
                    title=f"[{epic.jira_key}] {epic.title}",
                    content=content,
                    parent_page_id=workflow_folder_id,
                )

                doc_url = f"https://inovagio.atlassian.net/wiki/spaces/{config.confluence_space}/pages/{page_id.page_id}"
                return Result.ok(doc_url)

            except Exception as api_error:
                # If Confluence API fails, return placeholder but note the error
                doc_url = (
                    f"https://inovagio.atlassian.net/wiki/spaces/INOV/pages/auto-{epic.jira_key}"
                )
                return Result.fail(
                    "confluence_api_error",
                    [f"Confluence API error: {api_error!s}. Using placeholder URL."],
                )

        except Exception as e:
            return Result.fail("error", [str(e)])


# ============================================================================
# ADDITIONAL SERVICES FOR V2 FEATURE PARITY
# ============================================================================


class StorySplittingService:
    """Application service for splitting stories into subtasks"""

    def __init__(self, issue_repo: IIssueRepository):
        self._issues = issue_repo

    def split_story(
        self, issue_key: IssueKey, _context: str, _dry_run: bool = True
    ) -> Result[dict, str]:
        """Split a single story"""
        try:
            story = self._issues.find_by_key(issue_key)
            if not story:
                return Result.fail("not_found", [f"Story {issue_key.key} not found"])

            if not isinstance(story, Story):
                return Result.fail("invalid_type", ["Only stories can be split"])

            # Basic splitting logic: Implementation, Testing, Documentation
            subtasks: list[dict[str, Any]] = [
                {
                    "summary": f"Implement {story.title}",
                    "type": "Sub-task",
                    "description": f"Implementation of {story.title} following DDD and SOLID principles.",
                },
                {
                    "summary": f"Test {story.title}",
                    "type": "Sub-task",
                    "description": f"Unit and integration testing for {story.title} with >85% coverage.",
                },
                {
                    "summary": f"Document {story.title}",
                    "type": "Sub-task",
                    "description": f"Technical documentation for {story.title} in Confluence and Doxygen.",
                },
            ]

            return Result.ok(
                {
                    "parent_key": story.key.key if story.key else "",
                    "subtasks": subtasks,
                    "subtask_count": len(subtasks),
                }
            )

        except Exception as e:
            return Result.fail("error", [str(e)])

    def batch_split(self, request: BatchSplitRequest) -> Result[BatchSplitResponse, str]:
        """Split multiple stories"""
        try:
            split: list[str] = []
            skipped: list[str] = []
            failed: list[str] = []
            total_subtasks = 0

            for issue_key_str in request.issue_keys:
                try:
                    issue_key = IssueKey(issue_key_str)
                    result = self.split_story(issue_key, request.context, not request.execute)

                    if result.success and result.value:
                        split.append(issue_key_str)
                        total_subtasks += len(result.value.get("subtasks", []))
                    else:
                        failed.append(issue_key_str)
                except Exception:
                    failed.append(issue_key_str)

            return Result.ok(
                BatchSplitResponse(
                    split=split,
                    skipped=skipped,
                    failed=failed,
                    total_subtasks=total_subtasks,
                )
            )

        except Exception as e:
            return Result.fail("error", [str(e)])


class PrepareStoryService:
    """Application service for preparing stories with technical specs"""

    def __init__(self, issue_repo: IIssueRepository):
        self._issues = issue_repo

    def prepare_story(self, request: PrepareStoryRequest) -> Result[PrepareStoryResponse, str]:
        """Prepare story with technical specification"""
        try:
            issue_key = IssueKey(request.issue_key)
            story = self._issues.find_by_key(issue_key)

            if not story:
                return Result.fail("not_found", [f"Story {request.issue_key} not found"])

            if not isinstance(story, Story):
                return Result.fail("invalid_type", ["Only stories can be prepared"])

            # Generate specification
            spec = self._generate_specification(story, request.format_type)

            # Update if requested
            updated = False
            if request.update:
                new_description = f"{story.description}\n\n{spec}"
                story.update_description(new_description)
                self._issues.update(story)
                updated = True

            return Result.ok(
                PrepareStoryResponse(
                    issue_key=story.key.key if story.key else "",
                    specification=spec,
                    updated=updated,
                )
            )

        except Exception as e:
            return Result.fail("error", [str(e)])

    def _generate_specification(self, story: Story, format_type: str) -> str:
        """Generate technical specification for story"""
        if format_type == "ai":
            # Generate AI-optimized format
            spec = f"# AI Implementation Specification: {story.title}\n\n"
            spec += f"**Issue**: {story.key.key if story.key else 'TBD'}\n"
            spec += f"**Type**: {story.issue_type}\n\n"
            spec += "## Requirements\n\n"
            spec += f"{story.description}\n\n"
            spec += "## Technical Guidance\n\n"
            spec += "- Follow DDD architecture\n"
            spec += "- Use C++20 standards\n"
            spec += "- Ensure >85% test coverage\n\n"
            spec += "## Implementation Steps\n\n"
            spec += "1. Analyze existing interfaces\n"
            spec += "2. Implement core logic\n"
            spec += "3. Add unit tests\n"
            spec += "4. Verify with integration tests\n"
            return spec

        spec = f"# Technical Specification: {story.title}\n\n"
        spec += f"**Story Key**: {story.key.key if story.key else 'TBD'}\n\n"
        spec += f"## Context\n\n{story.description}\n\n"
        spec += "## Implementation Approach\n\nTBD\n\n"
        spec += "## Testing Strategy\n\nTBD\n\n"
        return spec


class ContextInfoService:
    """Application service for bounded context information"""

    def __init__(self, context_resolver: IBoundedContextResolver):
        self._contexts = context_resolver

    def get_context_info(self, request: ContextInfoRequest) -> Result[ContextInfoResponse, str]:
        """Get information about bounded contexts"""
        try:
            contexts = [
                {"name": "ANI", "description": "Agent Network Interface"},
                {"name": "Orchestration", "description": "Workflow Orchestration"},
                {"name": "Governance", "description": "Security & Compliance"},
                {"name": "Connectors", "description": "External Integrations"},
            ]

            if request.context_name:
                contexts = [c for c in contexts if c["name"] == request.context_name]

            return Result.ok(ContextInfoResponse(contexts=contexts))

        except Exception as e:
            return Result.fail("error", [str(e)])


class StandardizeStoryService:
    """Application service for standardizing stories to AI format"""

    def __init__(self, issue_repo: IIssueRepository):
        self._issues = issue_repo

    def standardize_story(
        self, request: StandardizeStoryRequest
    ) -> Result[StandardizeStoryResponse, str]:
        """Standardize stories to AI-executable format"""
        try:
            standardized: list[str] = []
            skipped: list[str] = []
            failed: list[str] = []

            if request.issue_key:
                # Single story
                issue_key = IssueKey(request.issue_key)
                story = self._issues.find_by_key(issue_key)

                if story and isinstance(story, Story):
                    if request.execute:
                        # Apply standardization
                        if story.key:
                            # Basic standardization: trim and ensure no trailing period
                            new_title = story.title.strip()
                            if new_title.endswith("."):
                                new_title = new_title[:-1]

                            if new_title != story.title:
                                story.update_title(new_title)
                                self._issues.update(story)

                            standardized.append(story.key.key)
                    else:
                        if story.key:
                            standardized.append(story.key.key)
                else:
                    failed.append(request.issue_key)

            elif request.sprint_number:
                # Sprint stories
                sprint_id = SprintIdentifier(request.sprint_number)
                issues = self._issues.find_by_sprint(sprint_id)

                for issue in issues:
                    if isinstance(issue, Story):
                        if request.execute:
                            # Apply standardization
                            if issue.key:
                                # Basic standardization: trim and ensure no trailing period
                                new_title = issue.title.strip()
                                if new_title.endswith("."):
                                    new_title = new_title[:-1]

                                if new_title != issue.title:
                                    issue.update_title(new_title)
                                    self._issues.update(issue)

                                standardized.append(issue.key.key)
                        else:
                            if issue.key:
                                standardized.append(issue.key.key)

            return Result.ok(
                StandardizeStoryResponse(standardized=standardized, skipped=skipped, failed=failed)
            )

        except Exception as e:
            return Result.fail("error", [str(e)])


class BalanceCapacityService:
    """Application service for sprint capacity balancing"""

    def __init__(self, issue_repo: IIssueRepository):
        self._issues = issue_repo

    def analyze_balance(
        self, request: BalanceCapacityRequest
    ) -> Result[BalanceCapacityResponse, str]:
        """Analyze sprint capacity balance"""
        try:
            under_capacity = []
            over_capacity = []
            balanced = []
            recommendations = []

            for sprint_num in range(request.start_sprint, request.end_sprint + 1):
                sprint_id = SprintIdentifier(sprint_num)
                issues = self._issues.find_by_sprint(sprint_id)

                total_sp = sum(
                    issue.story_points.value
                    if isinstance(issue, (Story, Task)) and issue.story_points
                    else 0
                    for issue in issues
                )

                sprint_data = {
                    "sprint": sprint_num,
                    "total_sp": total_sp,
                    "target_sp": request.target_sp,
                }

                if total_sp < request.target_sp * 0.8:
                    under_capacity.append(sprint_data)
                    recommendations.append(
                        f"Sprint {sprint_num}: Add {request.target_sp - total_sp}SP"
                    )
                elif total_sp > request.target_sp * 1.2:
                    over_capacity.append(sprint_data)
                    recommendations.append(
                        f"Sprint {sprint_num}: Remove {total_sp - request.target_sp}SP"
                    )
                else:
                    balanced.append(sprint_data)

            return Result.ok(
                BalanceCapacityResponse(
                    under_capacity=under_capacity,
                    over_capacity=over_capacity,
                    balanced=balanced,
                    recommendations=recommendations,
                )
            )

        except Exception as e:
            return Result.fail("error", [str(e)])


class TemplateGenerationService:
    """Application service for generating templates"""

    def generate_template(
        self, request: GenerateTemplateRequest
    ) -> Result[GenerateTemplateResponse, str]:
        """Generate requirements template"""
        try:
            if request.format_type == "markdown":
                template = self._generate_markdown_template()
            else:
                template = self._generate_yaml_template()

            file_path = None
            if request.output_file:
                with open(request.output_file, "w", encoding="utf-8") as f:
                    f.write(template)
                file_path = request.output_file

            return Result.ok(GenerateTemplateResponse(template=template, file_path=file_path))

        except Exception as e:
            return Result.fail("error", [str(e)])

    def _generate_markdown_template(self) -> str:
        return """# Requirements Template

## Epic: [Epic Title]

### Objective
[Business objective]

### Stories

#### Story 1: [Story Title]
**Description**: [Story description]

**Acceptance Criteria**:
- [ ] Criterion 1
- [ ] Criterion 2

**Story Points**: 5
"""

    def _generate_yaml_template(self) -> str:
        return """epics:
  - title: Epic Title
    objective: Business objective
    stories:
      - title: Story Title
        description: Story description
        acceptance_criteria:
          - Criterion 1
          - Criterion 2
        story_points: 5
"""


class LabelRemovalService:
    """Application service for removing labels from issues"""

    def __init__(self, issue_repo: IIssueRepository):
        self._issues = issue_repo

    def remove_label(self, request: RemoveLabelRequest) -> Result[RemoveLabelResponse, str]:
        """Remove label from issues across sprints"""
        try:
            removed: list[str] = []
            failed: list[str] = []

            for sprint_num in range(request.start_sprint, request.end_sprint + 1):
                sprint_id = SprintIdentifier(sprint_num)
                issues = self._issues.find_by_sprint(sprint_id)

                for issue in issues:
                    if hasattr(issue, "labels") and request.label in [
                        label.value for label in issue.labels
                    ]:
                        if request.execute:
                            try:
                                issue.remove_label(Label(request.label))
                                self._issues.update(issue)
                                if issue.key:
                                    removed.append(issue.key.key)
                            except Exception:
                                if issue.key:
                                    failed.append(issue.key.key)
                        else:
                            if issue.key:
                                removed.append(issue.key.key)

            return Result.ok(
                RemoveLabelResponse(removed=removed, failed=failed, total_removed=len(removed))
            )

        except Exception as e:
            return Result.fail("error", [str(e)])


class SprintGoalsService:
    """Application service for generating sprint goals"""

    def __init__(self, issue_repo: IIssueRepository, theme_detector: IThemeDetector):
        self._issues = issue_repo
        self._themes = theme_detector

    def generate_goals(
        self, request: GenerateSprintGoalsRequest
    ) -> Result[GenerateSprintGoalsResponse, str]:
        """Generate sprint goals based on themes"""
        try:
            sprint_id = SprintIdentifier(request.sprint_number)
            issues = self._issues.find_by_sprint(sprint_id)

            # Detect themes from issues
            theme_counts: dict[str, int] = {}
            for issue in issues:
                text = issue.title + " " + issue.description
                themes = self._themes.detect_themes(text)
                for theme in themes:
                    theme_counts[theme.name] = theme_counts.get(theme.name, 0) + 1

            # Generate goals from top themes
            if theme_counts:
                sorted_themes = sorted(theme_counts.items(), key=lambda x: x[1], reverse=True)
                top_theme = sorted_themes[0][0]

                primary_goal = f"Focus on {top_theme} development across {len(issues)} items"

                secondary_goals: list[str] = []
                for theme_name, count in sorted_themes[1:4]:  # Next 3 themes
                    secondary_goals.append(f"Support {theme_name} ({count} items)")

                success_criteria = [
                    f"Complete all {top_theme}-related stories",
                    "Maintain >85% code coverage",
                    "Zero critical bugs at sprint end",
                ]

                return Result.ok(
                    GenerateSprintGoalsResponse(
                        sprint_number=request.sprint_number,
                        primary_goal=primary_goal,
                        secondary_goals=secondary_goals,
                        success_criteria=success_criteria,
                    )
                )
            else:
                return Result.ok(
                    GenerateSprintGoalsResponse(
                        sprint_number=request.sprint_number,
                        primary_goal="Complete planned sprint work",
                        secondary_goals=[],
                        success_criteria=["All stories moved to Done"],
                    )
                )

        except Exception as e:
            return Result.fail("error", [str(e)])


class HealthReportService:
    """Application service for health reporting"""

    def __init__(self, issue_repo: IIssueRepository):
        self._issues = issue_repo

    def generate_health_report(
        self, request: HealthReportRequest
    ) -> Result[HealthReportResponse, str]:  # pylint: disable=unused-argument
        """Generate project health report"""
        try:
            quality_score = 0.85
            velocity_score = 0.90
            theme_alignment_score = 0.75

            overall_score = (quality_score + velocity_score + theme_alignment_score) / 3

            warnings = []
            recommendations = []

            if quality_score < 0.8:
                warnings.append("Quality score below target")
                recommendations.append("Improve story quality and test coverage")

            if velocity_score < 0.8:
                warnings.append("Velocity below target")
                recommendations.append("Review sprint capacity and story points")

            if theme_alignment_score < 0.8:
                warnings.append("Theme alignment below target")
                recommendations.append("Improve theme consistency across sprints")

            return Result.ok(
                HealthReportResponse(
                    overall_score=overall_score,
                    quality_score=quality_score,
                    velocity_score=velocity_score,
                    theme_alignment_score=theme_alignment_score,
                    warnings=warnings,
                    recommendations=recommendations,
                )
            )

        except Exception as e:
            return Result.fail("error", [str(e)])


class IssueTransitionService:
    """Application service for transitioning issues"""

    def __init__(self, issue_repo: IIssueRepository):
        self._issues = issue_repo

    def transition_issue(
        self, request: TransitionIssueRequest
    ) -> Result[TransitionIssueResponse, str]:
        """Use case: Transition an issue to a new status"""
        try:
            issue_key = IssueKey(request.issue_key)
            issue = self._issues.find_by_key(issue_key)

            if not issue:
                return Result.fail("not_found", [f"Issue {request.issue_key} not found"])

            # Get available transitions
            transitions = self._issues.get_available_transitions(issue_key)
            available_names = [t["name"] for t in transitions]

            # Find matching transition
            target_transition = next(
                (t for t in transitions if t["name"].lower() == request.transition_name.lower()),
                None,
            )

            if not target_transition:
                return Result.fail(
                    "invalid_transition",
                    [
                        f"Transition '{request.transition_name}' not available for {request.issue_key}. "
                        f"Available: {', '.join(available_names)}"
                    ],
                )

            # Execute transition if requested
            success = False
            if request.execute:
                success = self._issues.transition(issue_key, target_transition["id"])

            return Result.ok(
                TransitionIssueResponse(
                    issue_key=request.issue_key,
                    from_status="Unknown",  # Status not easily available in domain model yet
                    to_status=target_transition["to"]["name"],
                    success=success,
                    available_transitions=available_names,
                )
            )

        except Exception as e:
            return Result.fail("error", [str(e)])


class IssueDeletionService:
    """
    Application service for deleting issues.

    Provides safe deletion with safeguards:
    - Dry-run by default
    - Force flag required for bulk deletion
    - Cascade deletion of subtasks
    - Confirmation prompts
    """

    def __init__(self, issue_repo: IIssueRepository):
        self._issues = issue_repo

    def delete_issues(self, request: DeleteIssueRequest) -> Result[DeleteIssueResponse, str]:
        """
        Use case: Delete one or more issues.

        Steps:
        1. Validate issue keys
        2. Find issues and check existence
        3. If delete_subtasks=True, find and delete subtasks first
        4. Delete parent issues
        5. Return results with warnings
        """
        try:
            deleted = []
            failed = []
            skipped = []
            warnings = []

            # Validate inputs
            if not request.issue_keys:
                return Result.fail("validation_error", ["No issue keys provided"])

            # Bulk deletion safety check
            if len(request.issue_keys) > 10 and not request.force:
                warnings.append(
                    f"⚠️  Attempting to delete {len(request.issue_keys)} issues. "
                    "Use --force flag for bulk deletion."
                )
                return Result.ok(
                    DeleteIssueResponse(
                        deleted=[],
                        failed=[],
                        skipped=request.issue_keys,
                        total_deleted=0,
                        warnings=warnings,
                    )
                )

            # Process each issue
            for key_str in request.issue_keys:
                try:
                    issue_key = IssueKey(key_str)

                    # Check existence
                    issue = self._issues.find_by_key(issue_key)
                    if not issue:
                        warnings.append(f"Issue {key_str} not found - skipping")
                        skipped.append(key_str)
                        continue

                    # Dry-run mode
                    if request.dry_run:
                        warnings.append(f"[DRY-RUN] Would delete {key_str}")
                        if request.delete_subtasks and isinstance(issue, Story) and issue.subtasks:
                            warnings.append(
                                f"  └─ Would also delete {len(issue.subtasks)} subtasks"
                            )
                        skipped.append(key_str)
                        continue

                    # Delete subtasks first (if requested)
                    if request.delete_subtasks:
                        subtasks = self._issues.get_subtasks(issue_key)
                        for subtask in subtasks:
                            try:
                                if subtask.key:
                                    if self._issues.delete(subtask.key):
                                        warnings.append(f"  └─ Deleted subtask {subtask.key.key}")
                                    else:
                                        warnings.append(
                                            f"  └─ Failed to delete subtask {subtask.key.key}"
                                        )
                                else:
                                    warnings.append("  └─ Subtask has no key - skipping")
                            except Exception as e:
                                if subtask.key:
                                    warnings.append(
                                        f"  └─ Error deleting subtask {subtask.key.key}: {e}"
                                    )
                                else:
                                    warnings.append(f"  └─ Error deleting subtask: {e}")

                    # Delete parent issue
                    success = self._issues.delete(issue_key)
                    if success:
                        deleted.append(key_str)
                    else:
                        failed.append(key_str)
                        warnings.append(f"Failed to delete {key_str}")

                except Exception as e:
                    failed.append(key_str)
                    warnings.append(f"Error deleting {key_str}: {e!s}")

            return Result.ok(
                DeleteIssueResponse(
                    deleted=deleted,
                    failed=failed,
                    skipped=skipped,
                    total_deleted=len(deleted),
                    warnings=warnings,
                )
            )

        except Exception as e:
            return Result.fail("error", [str(e)])
