"""Full ``framework bootstrap`` scaffolder.

Generates a per-product doc tree at ``docs/<product>/`` from the templates
shipped at ``templates/product-doc-tree/``. The output is the canonical
INOVAGIO_DOC_FRAMEWORK shape — every product onboarded via this scaffolder
matches the same skeleton, which is what makes the bridge tooling
(``framework create-stories`` / ``verify-stories`` / ``sync-docs`` /
``reverse-sync``) able to operate against arbitrary products without
per-project glue.

Design principles:

- **Idempotent.** Re-running over an existing tree is non-destructive: any
  file that exists is skipped, never overwritten. ``--force`` is required
  to overwrite. Each operation reports per-file ``created`` / ``skipped``
  / ``overwritten`` so callers can audit what changed.
- **No network in the default path.** The scaffolder writes files only.
  Confluence hub-page reservation and Jira epic creation are explicitly
  out of scope here — they're project-specific and operator-driven, and
  the autonomous-dev system has no way to know what to call them.
- **Minimal token interpolation.** Templates use ``{{name}}`` substitutions
  for a small fixed set: ``product_id``, ``product_id_upper``, ``product_name``,
  ``project_key``, ``user_email``, ``atlassian_site``, ``confluence_space``,
  ``generated_at``. Everything else is left as ``<placeholder>`` for the
  operator to fill.
"""

from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass, field
from pathlib import Path

# ---------------------------------------------------------------------------
# Public dataclasses
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ScaffoldOptions:
    """Inputs to :func:`scaffold_product`. All defaults are safe for
    invoking from a CLI handler that's already validated argparse args."""

    product_id: str
    """Lowercase slug used in paths + Jira labels (e.g. ``mnemos``)."""

    product_name: str
    """Human-readable name used in doc titles (e.g. ``Mnemos``)."""

    project_key: str = ""
    """Jira project key (e.g. ``INOV``). Optional; can be filled later."""

    user_email: str = ""
    """Default assignee for created stories. Optional."""

    atlassian_site: str = ""
    """Atlassian Cloud site (e.g. ``acme.atlassian.net``). Optional."""

    confluence_space: str = ""
    """Confluence space key. Optional."""

    repo_root: Path = Path(".")
    """Where the scaffolded ``docs/<product_id>/`` directory will live."""

    force: bool = False
    """When True, overwrite existing files. When False (default), skip."""

    dry_run: bool = False
    """When True, report what would be written without touching disk."""


@dataclass
class ScaffoldFileOutcome:
    relpath: str
    action: str  # "created" | "skipped" | "overwritten" | "would_create" | "would_overwrite"
    reason: str = ""


@dataclass
class ScaffoldResult:
    product_id: str
    docs_dir: str
    file_outcomes: list[ScaffoldFileOutcome] = field(default_factory=list)
    next_steps: list[str] = field(default_factory=list)
    dry_run: bool = False

    @property
    def created_count(self) -> int:
        return sum(1 for o in self.file_outcomes if o.action in ("created", "overwritten"))

    @property
    def skipped_count(self) -> int:
        return sum(1 for o in self.file_outcomes if o.action == "skipped")


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class ScaffoldError(Exception):
    """Raised when the scaffolder cannot proceed (bad inputs, template
    directory missing, repo root unwritable)."""


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def scaffold_product(opts: ScaffoldOptions) -> ScaffoldResult:
    """Run the scaffolder. Pure function modulo the disk writes."""
    _validate_options(opts)
    template_root = _resolve_template_root()
    if not template_root.is_dir():
        raise ScaffoldError(
            f"Template tree not found at {template_root}. atlassiancli was not installed correctly."
        )

    docs_dir = (opts.repo_root / "docs" / opts.product_id).resolve()
    result = ScaffoldResult(
        product_id=opts.product_id,
        docs_dir=str(docs_dir),
        dry_run=opts.dry_run,
    )

    substitutions = _build_substitutions(opts)

    for src in _walk_templates(template_root):
        rel = src.relative_to(template_root)
        # ``.template`` suffix is stripped on output so the agent finds the
        # docs at their canonical paths (e.g. ``ARCHITECTURE.md`` not
        # ``ARCHITECTURE.md.template``).
        target_rel = rel.with_suffix("") if rel.suffix == ".template" else rel
        target = docs_dir / target_rel
        rel_str = str(target_rel)

        body = _render(src.read_text(encoding="utf-8"), substitutions)

        if target.exists() and not opts.force:
            result.file_outcomes.append(
                ScaffoldFileOutcome(relpath=rel_str, action="skipped", reason="already exists")
            )
            continue

        action = (
            "would_create"
            if opts.dry_run and not target.exists()
            else "would_overwrite"
            if opts.dry_run
            else "overwritten"
            if target.exists()
            else "created"
        )

        if not opts.dry_run:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(body, encoding="utf-8")

        result.file_outcomes.append(ScaffoldFileOutcome(relpath=rel_str, action=action))

    result.next_steps = _next_steps(opts, docs_dir)
    return result


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------


_VALID_PRODUCT_ID = "abcdefghijklmnopqrstuvwxyz0123456789-"


def _validate_options(opts: ScaffoldOptions) -> None:
    if not opts.product_id:
        raise ScaffoldError("product_id must be a non-empty string")
    if not all(c in _VALID_PRODUCT_ID for c in opts.product_id):
        raise ScaffoldError(
            f"product_id {opts.product_id!r} must be lowercase alphanumeric "
            "with hyphens (e.g. 'mnemos', 'forge', 'data-pipeline')"
        )
    if not opts.product_name:
        raise ScaffoldError("product_name must be a non-empty string")
    if not opts.repo_root.is_dir():
        raise ScaffoldError(f"repo_root not found: {opts.repo_root}")


def _resolve_template_root() -> Path:
    """Find the shipped template tree.

    Looks first relative to this file (covers the editable-install case
    used in development), falls back to walking up to find a sibling
    ``templates/product-doc-tree/`` directory (covers the wheel-install
    case where templates ship via :class:`MANIFEST.in`).
    """
    here = Path(__file__).resolve()
    candidates = [
        here.parents[3] / "templates" / "product-doc-tree",
        here.parents[2] / "templates" / "product-doc-tree",
        Path.cwd() / "templates" / "product-doc-tree",
    ]
    for candidate in candidates:
        if candidate.is_dir():
            return candidate
    return candidates[0]  # for the error message in scaffold_product


def _walk_templates(root: Path):
    """Yield every regular file under ``root`` (any depth)."""
    for path in sorted(root.rglob("*")):
        if path.is_file():
            yield path


def _build_substitutions(opts: ScaffoldOptions) -> dict[str, str]:
    return {
        "product_id": opts.product_id,
        "product_id_upper": opts.product_id.upper().replace("-", "_"),
        "product_name": opts.product_name,
        "project_key": opts.project_key or "<JIRA_PROJECT_KEY>",
        "user_email": opts.user_email or "<your-email@example.com>",
        "atlassian_site": opts.atlassian_site or "<your-site>.atlassian.net",
        "confluence_space": opts.confluence_space or "<CONFLUENCE_SPACE>",
        "generated_at": _dt.date.today().isoformat(),
    }


def _render(template: str, substitutions: dict[str, str]) -> str:
    """Naive ``{{name}}`` replacement. We don't need full Jinja for this
    — the templates only use simple top-level keys and never branch."""
    out = template
    for key, value in substitutions.items():
        out = out.replace(f"{{{{{key}}}}}", value)
    return out


def _next_steps(opts: ScaffoldOptions, docs_dir: Path) -> list[str]:
    return [
        f"Edit docs/{opts.product_id}/.docframework.yaml — fill in "
        "`hub_page_id` once you reserve the Confluence hub page.",
        f"Edit docs/{opts.product_id}/.docframework.yaml — populate "
        "`jira.epics` once you create epics in Jira.",
        f"Author the seven mandatory top-level docs in docs/{opts.product_id}/ "
        "(README, product-identity, ARCHITECTURE, DESIGN_SPEC, "
        "IMPLEMENTATION_PLAN, ROADMAP, PARITY_LEDGER).",
        f"Author at least one ADR in docs/{opts.product_id}/adrs/ to anchor "
        "the decision-record habit.",
        f"Author the first epic + story manifest, then run "
        f"`atlassiancli framework create-stories --product {opts.product_id}`.",
        f"After creating Confluence pages, run "
        f"`atlassiancli framework sync-docs --product {opts.product_id}` to "
        "push the rendered markdown.",
    ]
