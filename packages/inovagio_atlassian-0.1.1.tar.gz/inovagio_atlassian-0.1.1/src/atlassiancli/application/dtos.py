#!/usr/bin/env python3
"""
Data Transfer Objects (DTOs)

Request and response objects for application services.

Author: Inovagio Engineering Team
"""

from dataclasses import dataclass, field
from typing import Any, Generic, TypeVar

# Generic Result type
T = TypeVar("T")
E = TypeVar("E")


@dataclass
class Result(Generic[T, E]):
    """Generic result type for success/failure"""

    success: bool
    value: T | None = None
    error: E | None = None
    errors: list[str] = field(default_factory=list)

    @staticmethod
    def ok(value: T) -> "Result[T, E]":
        """Create success result"""
        return Result(success=True, value=value)

    @staticmethod
    def fail(error: E, errors: list[str] | None = None) -> "Result[T, E]":
        """Create failure result"""
        return Result(success=False, error=error, errors=errors or [])


# Issue Creation DTOs
@dataclass
class CreateEpicRequest:
    """Request to create an epic"""

    title: str
    description: str
    objective: str
    kpis: list[str] = field(default_factory=list)
    themes: list[str] = field(default_factory=list)
    in_scope: list[str] = field(default_factory=list)
    out_of_scope: list[str] = field(default_factory=list)
    architecture_link: str | None = None
    priority: str = "High"


@dataclass
class CreateStoryRequest:
    """Request to create a story"""

    title: str
    description: str
    epic_key: str | None = None
    themes: list[str] = field(default_factory=list)
    acceptance_criteria: list[str] = field(default_factory=list)
    story_points: int | None = None
    sprint_number: int | None = None
    priority: str = "Medium"
    affected_modules: list[str] = field(default_factory=list)
    integration_points: list[str] = field(default_factory=list)


@dataclass
class CreateTaskRequest:
    """Request to create a task"""

    title: str
    description: str
    parent_story_key: str
    implementation_steps: list[str] = field(default_factory=list)
    estimated_hours: int | None = None
    priority: str = "Medium"


@dataclass
class CreateVersionRequest:
    """Request to create a release version"""

    name: str
    description: str
    project_id: str
    start_date: str | None = None
    release_date: str | None = None
    released: bool = False
    archived: bool = False


@dataclass
class CreateIssueResponse:
    """Response from issue creation"""

    issue_key: str
    url: str
    warnings: list[str] = field(default_factory=list)


@dataclass
class CreateVersionResponse:
    """Response from version creation"""

    version_id: str
    name: str
    url: str
    warnings: list[str] = field(default_factory=list)


# Enhancement DTOs
@dataclass
class EnhanceIssueRequest:
    """Request to enhance an issue"""

    issue_key: str
    force: bool = False
    skip_metadata: bool = False
    update_metadata: bool = False
    apply_architecture: bool = False  # Apply proposed architecture requirements
    auto_quality: bool = True  # Auto-run quality analysis + professional rewrite


@dataclass
class EnhanceIssueResponse:
    """Response from enhancement"""

    issue_key: str
    previous_readiness: str
    new_readiness: str
    changes_made: list[str] = field(default_factory=list)
    architecture_review: Any | None = None  # ArchitectureReviewResult
    quality_before: dict[str, Any] | None = None
    quality_after: dict[str, Any] | None = None


@dataclass
class TransitionIssueRequest:
    """Request to transition an issue"""

    issue_key: str
    transition_name: str  # e.g., "Done", "In Progress"
    execute: bool = False


@dataclass
class TransitionIssueResponse:
    """Response from transition"""

    issue_key: str
    from_status: str
    to_status: str
    success: bool
    available_transitions: list[str] = field(default_factory=list)
    changes_made: list[str] = field(default_factory=list)
    architecture_review: Any | None = None  # ArchitectureReviewResult


@dataclass
class EnhanceSprintRequest:
    """Request to enhance all issues in a sprint"""

    sprint_number: int
    execute: bool = False
    force: bool = False
    with_docs: bool = False
    update_metadata: bool = False
    apply_architecture: bool = False
    auto_quality: bool = True


@dataclass
class EnhanceSprintResponse:
    """Response from sprint enhancement"""

    sprint_number: int
    enhanced: list[str] = field(default_factory=list)
    skipped: list[str] = field(default_factory=list)
    failed: list[str] = field(default_factory=list)
    total_changes: int = 0


# Documentation DTOs
@dataclass
class CreateDocsRequest:
    """Request to create Confluence docs"""

    issue_key: str
    include_spec: bool = True
    include_test_plan: bool = True
    include_runbook: bool = False
    analyze_only: bool = False
    execute: bool = False


@dataclass
class BatchSplitRequest:
    """Request to split multiple stories"""

    issue_keys: list[str]
    execute: bool = False
    force: bool = False
    context: str = "ANI"


@dataclass
class BatchSplitResponse:
    """Response from batch split operation"""

    split: list[str] = field(default_factory=list)
    skipped: list[str] = field(default_factory=list)
    failed: list[str] = field(default_factory=list)
    total_subtasks: int = 0


@dataclass
class DocSyncResult:
    """Result of doc sync for a single page"""

    page_type: str  # "spec", "test_plan"
    page_id: str | None = None
    page_url: str | None = None
    status: str = "created"  # "created", "updated", "unchanged"


@dataclass
class CreateDocsResponse:
    """Response from doc creation"""

    issue_key: str
    pages: list[DocSyncResult] = field(default_factory=list)
    links_added: int = 0


# Sprint Management DTOs
@dataclass
class MoveIssuesRequest:
    """Request to move issues to sprint"""

    issue_keys: list[str]
    sprint_number: int
    with_subtasks: bool = True


@dataclass
class MoveIssuesResponse:
    """Response from move operation"""

    moved: list[str] = field(default_factory=list)
    failed: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


# Reporting DTOs
@dataclass
class HealthReportRequest:
    """Request for project health report"""

    start_sprint: int
    end_sprint: int
    format: str = "text"


@dataclass
class HealthReportResponse:
    """Response with health metrics"""

    overall_score: float
    quality_score: float
    velocity_score: float
    theme_alignment_score: float
    warnings: list[str] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)


# Analysis DTOs
@dataclass
class LintIssueRequest:
    """Request to lint an issue for AI readiness"""

    issue_key: str


@dataclass
class LintIssueResponse:
    """Response from linting"""

    issue_key: str
    readiness_level: str  # "not_ready", "incomplete", "ready", "optimal"
    readiness_score: int  # 0-100
    issues: list[str] = field(default_factory=list)
    missing_fields: list[str] = field(default_factory=list)
    suggestions: list[str] = field(default_factory=list)


@dataclass
class AnalyzeDescriptionRequest:
    """Request to analyze description quality"""

    description: str


@dataclass
class AnalyzeDescriptionResponse:
    """Response from description analysis"""

    score: float  # 0-10
    grade: str  # A-F
    issues: list[str] = field(default_factory=list)
    has_acceptance_criteria: bool = False
    has_technical_details: bool = False
    has_integration_points: bool = False
    has_code_examples: bool = False
    word_count: int = 0


@dataclass
class AnalyzeAtomicityRequest:
    """Request to analyze story atomicity"""

    issue_key: str


@dataclass
class AnalyzeAtomicityResponse:
    """Response from atomicity analysis"""

    issue_key: str
    is_atomic: bool
    atomicity_score: int  # 0-100
    estimated_days: float
    should_split: bool
    split_suggestions: list[str] = field(default_factory=list)
    issues: list[str] = field(default_factory=list)


@dataclass
class AnalyzeIssueRequest:
    """Request for comprehensive issue analysis"""

    issue_key: str


@dataclass
class AnalyzeIssueResponse:
    """Response from comprehensive analysis"""

    issue_key: str
    overall_grade: str  # A-F
    overall_score: int  # 0-100
    description_score: float
    atomicity_score: int
    testability_score: int
    ai_readiness_score: int
    issues: list[str] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)


@dataclass
class AnalyzeSprintRequest:
    """Request to analyze a sprint"""

    sprint_number: int


@dataclass
class AnalyzeSprintResponse:
    """Response from sprint analysis"""

    sprint_number: int
    sprint_name: str
    total_issues: int
    total_story_points: float
    average_quality_score: float
    theme_cohesion_score: int
    issues_by_grade: dict[str, Any] = field(default_factory=dict)
    top_themes: list[tuple[Any, ...]] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)


# Split DTOs
@dataclass
class SplitStoryRequest:
    """Request to split a story"""

    issue_key: str
    max_story_points: int = 5
    dry_run: bool = True


@dataclass
class SplitStoryResponse:
    """Response from story splitting"""

    original_key: str
    subtasks_created: list[str] = field(default_factory=list)
    split_strategy: str = ""
    dry_run: bool = True


# Rebalance DTOs
@dataclass
class RebalanceSprintsRequest:
    """Request to rebalance sprints"""

    start_sprint: int
    end_sprint: int
    target_capacity: int = 55
    dry_run: bool = True


@dataclass
class RebalanceSprintsResponse:
    """Response from rebalancing"""

    moves_executed: int = 0
    moves_planned: int = 0
    sprint_summaries: list[dict[str, Any]] = field(default_factory=list)
    dry_run: bool = True


# Import DTOs
@dataclass
class ImportRequest:
    """Request to import from file"""

    file_path: str
    format: str  # "markdown", "yaml", "auto"
    dry_run: bool = True


@dataclass
class ImportResponse:
    """Response from import"""

    epics_created: int = 0
    stories_created: int = 0
    tasks_created: int = 0
    issues: list[str] = field(default_factory=list)
    dry_run: bool = True


# Enhancement DTOs
@dataclass
class EnhanceWithTemplateRequest:
    """Request to enhance with template"""

    issue_key: str
    context: str  # "ANI", "Orchestration", "Governance"
    dry_run: bool = True


@dataclass
class EnhanceWithTemplateResponse:
    """Response from template enhancement"""

    issue_key: str
    enhanced: bool
    acceptance_criteria: list[str] = field(default_factory=list)
    technical_sections: str = ""


@dataclass
class EnhanceMetadataRequest:
    """Request to enhance metadata"""

    issue_key: str
    themes: list[str] = field(default_factory=list)
    dry_run: bool = True


@dataclass
class EnhanceMetadataResponse:
    """Response from metadata enhancement"""

    issue_key: str
    labels: list[str] = field(default_factory=list)
    components: list[str] = field(default_factory=list)
    priority: str = ""


# Sprint Operations DTOs
@dataclass
class ReorganizeByThemeRequest:
    """Request to reorganize by theme"""

    start_sprint: int
    end_sprint: int
    dry_run: bool = True


@dataclass
class ReorganizeByThemeResponse:
    """Response from reorganization"""

    reorganizations: int = 0
    plan: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class GenerateSprintGoalsRequest:
    """Request to generate sprint goals"""

    sprint_number: int


@dataclass
class GenerateSprintGoalsResponse:
    """Response with generated goals"""

    sprint_number: int
    primary_goal: str = ""
    secondary_goals: list[str] = field(default_factory=list)
    success_criteria: list[str] = field(default_factory=list)


# Automation DTOs
@dataclass
class AutoAnalyzeRequest:
    """Request for auto analysis"""

    sprint_number: int
    min_grade: str = "C"  # Only analyze issues below this grade


@dataclass
class AutoAnalyzeResponse:
    """Response from auto analysis"""

    analyzed: int = 0
    passed: int = 0
    failed: int = 0
    issues: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class AutoEnhanceRequest:
    """Request for auto enhancement"""

    sprint_number: int
    readiness_filter: str = "PARTIALLY_READY"


@dataclass
class AutoEnhanceResponse:
    """Response from auto enhancement"""

    enhanced: int = 0
    skipped: int = 0
    failed: int = 0


@dataclass
class AutoSplitRequest:
    """Request for auto split"""

    sprint_number: int
    max_sp: int = 8


@dataclass
class AutoSplitResponse:
    """Response from auto split"""

    split: int = 0
    subtasks_created: int = 0
    skipped: int = 0


# Reporting DTOs
@dataclass
class GenerateReportRequest:
    """Request to generate report"""

    report_type: str  # "quality", "velocity", "themes"
    start_sprint: int
    end_sprint: int
    output_format: str = "text"  # "text", "markdown", "json"


@dataclass
class GenerateReportResponse:
    """Response with report data"""

    report_type: str
    report_data: dict[str, Any] = field(default_factory=dict)
    formatted_output: str = ""


# Verification DTOs
@dataclass
class VerifySprintRequest:
    """Request to verify sprint"""

    sprint_number: int


@dataclass
class VerifySprintResponse:
    """Response from sprint verification"""

    sprint_number: int
    is_ready: bool
    issues_found: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


@dataclass
class VerifyThemesRequest:
    """Request to verify themes"""

    sprint_number: int


@dataclass
class VerifyThemesResponse:
    """Response from theme verification"""

    sprint_number: int
    themes_consistent: bool
    unlabeled_issues: list[str] = field(default_factory=list)
    label_mismatches: list[dict[str, Any]] = field(default_factory=list)


# Complexity Estimation DTO
@dataclass
class EstimateComplexityRequest:
    """Request to estimate complexity"""

    description: str


@dataclass
class EstimateComplexityResponse:
    """Response from complexity estimation"""

    complexity: str  # "trivial", "low", "medium", "high", "very_high"
    score: int
    factors: list[str] = field(default_factory=list)


# Additional V2 Feature DTOs
@dataclass
class PrepareStoryRequest:
    """Request to prepare story with technical specification"""

    issue_key: str
    update: bool = False
    format_type: str = "full"
    output_file: str | None = None


@dataclass
class PrepareStoryResponse:
    """Response from story preparation"""

    issue_key: str
    specification: str
    updated: bool = False


@dataclass
class ContextInfoRequest:
    """Request for bounded context information"""

    context_name: str | None = None


@dataclass
class ContextInfoResponse:
    """Response with context information"""

    contexts: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class StandardizeStoryRequest:
    """Request to standardize story to AI format"""

    issue_key: str | None = None
    sprint_number: int | None = None
    execute: bool = False


@dataclass
class StandardizeStoryResponse:
    """Response from standardization"""

    standardized: list[str] = field(default_factory=list)
    skipped: list[str] = field(default_factory=list)
    failed: list[str] = field(default_factory=list)


@dataclass
class BalanceCapacityRequest:
    """Request for capacity balance analysis"""

    start_sprint: int
    end_sprint: int
    target_sp: int = 65


@dataclass
class BalanceCapacityResponse:
    """Response with balance analysis"""

    under_capacity: list[dict[str, Any]] = field(default_factory=list)
    over_capacity: list[dict[str, Any]] = field(default_factory=list)
    balanced: list[dict[str, Any]] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)


@dataclass
class GenerateTemplateRequest:
    """Request to generate requirements template"""

    format_type: str = "markdown"
    output_file: str | None = None


@dataclass
class GenerateTemplateResponse:
    """Response with template"""

    template: str
    file_path: str | None = None


@dataclass
class RemoveLabelRequest:
    """Request to remove label from issues"""

    label: str
    start_sprint: int = 2
    end_sprint: int = 25
    execute: bool = False


@dataclass
class RemoveLabelResponse:
    """Response from label removal"""

    removed: list[str] = field(default_factory=list)
    failed: list[str] = field(default_factory=list)
    total_removed: int = 0


@dataclass
class DeleteIssueRequest:
    """Request to delete one or more issues"""

    issue_keys: list[str]
    delete_subtasks: bool = True
    force: bool = False
    dry_run: bool = True


@dataclass
class DeleteIssueResponse:
    """Response from issue deletion"""

    deleted: list[str] = field(default_factory=list)
    failed: list[str] = field(default_factory=list)
    skipped: list[str] = field(default_factory=list)
    total_deleted: int = 0
    warnings: list[str] = field(default_factory=list)
