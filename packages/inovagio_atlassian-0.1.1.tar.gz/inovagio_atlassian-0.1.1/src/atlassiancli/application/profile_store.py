"""Multi-profile credential store.

Each profile lives at ``~/.atlassiancli/<name>.toml`` and carries the same
six fields :class:`AtlassianConfig` reads from env vars. The store is
deliberately small: read via :mod:`tomllib` (stdlib, Python 3.11+), write
via a hand-rolled emitter that handles the flat-string subset we need.
File mode is set to ``0600`` on write so the credential isn't readable by
group / other accounts on shared machines.

This module is the single integration point between
:mod:`atlassiancli.cli.configure_handler` (interactive wizard) and
:mod:`atlassiancli.infrastructure.config` (consumer).

Precedence the rest of the system honours, highest first:

1. Explicit ``--config <path>`` argument.
2. Env vars (``ATLASSIAN_TOKEN``, ``ATLASSIAN_EMAIL``, ...).
3. ``~/.atlassiancli/<profile>.toml`` (profile name = ``--profile`` arg
   then ``$ATLASSIAN_PROFILE`` then ``default``).
4. Hardcoded defaults.
"""

from __future__ import annotations

import os
import tempfile
import tomllib
from dataclasses import dataclass, fields
from pathlib import Path

DEFAULT_PROFILE_NAME = "default"
PROFILE_DIR_ENV = "ATLASSIANCLI_HOME"
"""When set, overrides the default ``~/.atlassiancli`` directory location."""

# ---------------------------------------------------------------------------
# Profile dataclass
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Profile:
    """Persisted credential + endpoint set for a single Atlassian site.

    All fields are optional on disk — missing fields fall back to env vars
    or the project defaults at consumption time. This means an operator can
    opt to keep their token in env and store only the endpoint here, or
    vice versa.
    """

    name: str
    base_url: str = ""
    user_email: str = ""
    api_token: str = ""
    project_key: str = ""
    confluence_space: str = ""

    def merged_with_env(self) -> dict[str, str]:
        """Return a flat dict of effective values, env vars overriding profile."""
        # The order here matches the documented precedence: env vars layer
        # on top of profile values. Both are optional; the consumer applies
        # hardcoded defaults if both are empty.
        merged = {
            "base_url": self.base_url,
            "user_email": self.user_email,
            "api_token": self.api_token,
            "project_key": self.project_key,
            "confluence_space": self.confluence_space,
        }
        env_overrides = {
            "base_url": _first_env("Atlassian_ORGANIZATION_URL", "ATLASSIAN_URL"),
            "user_email": _first_env("ATLASSIAN_USER_EMAIL", "ATLASSIAN_EMAIL"),
            "api_token": _first_env("ATLASSIAN_TOKEN", "ATLASSIAN_API_TOKEN", "atlassian_API_key"),
            "project_key": os.getenv("JIRA_PROJECT_KEY", ""),
            "confluence_space": os.getenv("CONFLUENCE_SPACE", ""),
        }
        for key, value in env_overrides.items():
            if value:
                merged[key] = value
        return merged


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class ProfileNotFoundError(FileNotFoundError):
    """The named profile is not on disk and the caller required it."""


class ProfileWriteError(OSError):
    """Profile could not be written (permissions, disk full, etc.)."""


# ---------------------------------------------------------------------------
# Store
# ---------------------------------------------------------------------------


class ProfileStore:
    """Read / write profiles under a base directory.

    The base directory is ``~/.atlassiancli/`` by default but can be
    overridden via the ``ATLASSIANCLI_HOME`` env var (used in tests so we
    never touch the real user home).
    """

    def __init__(self, base_dir: Path | str | None = None) -> None:
        if base_dir is not None:
            self._base_dir = Path(base_dir)
        elif os.getenv(PROFILE_DIR_ENV):
            self._base_dir = Path(os.environ[PROFILE_DIR_ENV])
        else:
            self._base_dir = Path.home() / ".atlassiancli"

    @property
    def base_dir(self) -> Path:
        return self._base_dir

    def path_for(self, profile: str) -> Path:
        """Return the absolute path of the profile file (may not exist)."""
        return self._base_dir / f"{profile}.toml"

    def list_profiles(self) -> list[str]:
        """Return the sorted list of profile names present on disk."""
        if not self._base_dir.is_dir():
            return []
        return sorted(p.stem for p in self._base_dir.glob("*.toml") if p.is_file())

    def load(self, profile: str, *, required: bool = False) -> Profile:
        """Load a profile by name.

        When ``required=False`` (default), a missing profile returns a
        :class:`Profile` with only the name populated, all credentials empty.
        When ``required=True``, raises :class:`ProfileNotFoundError`.
        """
        path = self.path_for(profile)
        if not path.is_file():
            if required:
                raise ProfileNotFoundError(
                    f"Profile {profile!r} not found at {path}. "
                    f"Run `atlassiancli configure --profile {profile}` to create it."
                )
            return Profile(name=profile)

        with path.open("rb") as f:
            data = tomllib.load(f)
        return Profile(
            name=profile,
            base_url=str(data.get("base_url", "")),
            user_email=str(data.get("user_email", "")),
            api_token=str(data.get("api_token", "")),
            project_key=str(data.get("project_key", "")),
            confluence_space=str(data.get("confluence_space", "")),
        )

    def save(self, profile: Profile) -> Path:
        """Atomically write a profile to disk with mode 0600.

        Uses a temp file in the same directory + ``os.replace`` to make
        the write atomic — readers never observe a partially-written file.
        Sets the file mode to 0600 (owner read/write only) so the API
        token isn't accessible to other local accounts.
        """
        self._base_dir.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(self._base_dir, 0o700)
        except OSError:
            # On Windows / network-mounted filesystems we may not be able
            # to set Unix mode bits; that's fine, the call is best-effort.
            pass

        target = self.path_for(profile.name)
        body = _to_toml(profile)
        try:
            fd, tmp = tempfile.mkstemp(
                prefix=f".{profile.name}.", suffix=".toml.tmp", dir=str(self._base_dir)
            )
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    f.write(body)
                os.chmod(tmp, 0o600)
                os.replace(tmp, target)
            except Exception:
                # Best-effort cleanup of the temp file before re-raising.
                try:
                    os.unlink(tmp)
                except OSError:
                    pass
                raise
        except OSError as exc:
            raise ProfileWriteError(
                f"Could not write profile {profile.name!r} to {target}: {exc}"
            ) from exc
        return target

    def delete(self, profile: str) -> bool:
        """Remove a profile from disk. Returns True if it existed."""
        path = self.path_for(profile)
        if not path.is_file():
            return False
        path.unlink()
        return True


# ---------------------------------------------------------------------------
# Resolution helpers
# ---------------------------------------------------------------------------


def resolve_profile_name(
    cli_arg: str | None,
    *,
    env_var: str = "ATLASSIAN_PROFILE",
    default: str = DEFAULT_PROFILE_NAME,
) -> str:
    """Pick the active profile name from the documented precedence chain."""
    if cli_arg:
        return cli_arg
    env_value = os.getenv(env_var)
    if env_value:
        return env_value
    return default


# ---------------------------------------------------------------------------
# TOML emitter — write side only (read uses tomllib)
# ---------------------------------------------------------------------------


def _to_toml(profile: Profile) -> str:
    """Render a :class:`Profile` as a TOML document (flat-string subset).

    The shape is six top-level string keys. We escape backslashes and
    double-quotes to keep the output round-trippable through
    :mod:`tomllib`.
    """
    lines = [
        "# atlassiancli profile — managed by `atlassiancli configure`.",
        f"# Profile name: {profile.name}",
        "",
    ]
    for field in fields(profile):
        if field.name == "name":
            continue
        value = getattr(profile, field.name)
        lines.append(f'{field.name} = "{_escape_string(value)}"')
    return "\n".join(lines) + "\n"


def _escape_string(value: str) -> str:
    """Apply TOML basic-string escapes (just \\ and ")."""
    return value.replace("\\", "\\\\").replace('"', '\\"')


def _first_env(*names: str) -> str:
    """Return the first non-empty value among the named env vars; '' otherwise."""
    for name in names:
        value = os.getenv(name)
        if value:
            return value
    return ""
