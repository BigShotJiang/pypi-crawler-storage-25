"""Stable JSON envelope for agent-callable subcommands.

Documented in PLAN.md §6.2. Every analyse / write subcommand, when invoked
with the global ``--json`` flag, emits exactly one :class:`AgentResponse`
JSON document on stdout. The schema is fixed and forward-compatible: fields
that don't apply to a given command are emitted as ``null`` (never omitted)
so the agent's parser can rely on key presence.

This module is import-clean — it has no dependencies outside the stdlib and
deliberately knows nothing about Jira, HTTP, or argparse. CLI handlers
build :class:`AgentResponse` values; the top-level dispatcher serialises
them via :meth:`AgentResponse.to_json`.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from typing import Any, Literal

# Stable severity / verdict vocabularies. Anything outside these constants is
# a contract violation — the agent's state machine branches on them
# byte-exactly.
Severity = Literal["critical", "major", "minor", "info"]
Verdict = Literal["PASS", "FAIL", "WARN", "READY", "NOT_READY"]


@dataclass(frozen=True)
class AgentFinding:
    """One actionable observation about a story / command result."""

    severity: Severity
    rule: str
    section: str | None
    message: str
    fix_hint: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Render the finding as a plain dict (stable key order, nulls kept)."""
        return {
            "severity": self.severity,
            "rule": self.rule,
            "section": self.section,
            "message": self.message,
            "fix_hint": self.fix_hint,
        }


@dataclass(frozen=True)
class AgentResponse:
    """The single envelope every agent-callable subcommand returns.

    Matches the schema in PLAN §6.2. Field semantics:

    - ``issue_key``: Jira key the command operates on, or ``None`` for
      issue-less commands (template, sprint current, ...).
    - ``command``: dotted command path, e.g. ``analyse.lint``,
      ``sprint.current``, ``transition``.
    - ``verdict``: ``PASS`` / ``FAIL`` / ``WARN`` for analyse commands,
      ``READY`` / ``NOT_READY`` for the composite gate, ``None`` where
      not applicable (template, fetch).
    - ``score``, ``threshold``: integer pair for scored gates; both
      ``None`` for unscored commands.
    - ``findings``: zero-or-more :class:`AgentFinding` rows. Empty list,
      not ``None``, when no findings.
    - ``metadata``: free-form dict for command-specific payload (proposed
      description, sprint info, story list, exit_code on errors, etc.).
    """

    command: str
    issue_key: str | None = None
    verdict: Verdict | None = None
    score: int | None = None
    threshold: int | None = None
    findings: list[AgentFinding] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Render the response as a plain dict in stable key order."""
        return {
            "issue_key": self.issue_key,
            "command": self.command,
            "verdict": self.verdict,
            "score": self.score,
            "threshold": self.threshold,
            "findings": [f.to_dict() for f in self.findings],
            "metadata": dict(self.metadata),
        }

    def to_json(self, *, indent: int = 2) -> str:
        """Serialise to a UTF-8 JSON string (no trailing newline)."""
        return json.dumps(self.to_dict(), indent=indent, sort_keys=False)

    # ------------------------------------------------------------------
    # Convenience constructors
    # ------------------------------------------------------------------

    @classmethod
    def success(
        cls,
        command: str,
        *,
        issue_key: str | None = None,
        verdict: Verdict | None = "PASS",
        score: int | None = None,
        threshold: int | None = None,
        findings: list[AgentFinding] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> AgentResponse:
        """Build a success-shaped response. ``verdict`` defaults to PASS."""
        return cls(
            command=command,
            issue_key=issue_key,
            verdict=verdict,
            score=score,
            threshold=threshold,
            findings=list(findings or []),
            metadata=_with_default_metadata(metadata),
        )

    @classmethod
    def failure(
        cls,
        command: str,
        findings: list[AgentFinding],
        *,
        issue_key: str | None = None,
        score: int | None = None,
        threshold: int | None = None,
        metadata: dict[str, Any] | None = None,
        verdict: Verdict = "FAIL",
    ) -> AgentResponse:
        """Build a failure-shaped response. Always ``verdict=FAIL``."""
        return cls(
            command=command,
            issue_key=issue_key,
            verdict=verdict,
            score=score,
            threshold=threshold,
            findings=list(findings),
            metadata=_with_default_metadata(metadata),
        )


def _with_default_metadata(extra: dict[str, Any] | None) -> dict[str, Any]:
    """Merge caller metadata onto a default with an ISO8601 timestamp."""
    base: dict[str, Any] = {"fetched_at": _utc_now_iso()}
    if extra:
        base.update(extra)
    return base


def _utc_now_iso() -> str:
    """Return the current UTC time in ISO 8601 with the trailing ``Z``."""
    # ``timespec='seconds'`` keeps the surface stable for golden tests; we
    # don't need millisecond precision in the envelope.
    return datetime.now(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


# Re-export the dataclass-asdict helper for callers that want to build
# their own variant (kept private to discourage drift from to_dict()).
__all__ = [
    "AgentFinding",
    "AgentResponse",
    "Severity",
    "Verdict",
]


def _ensure_dataclass_serialisable(obj: Any) -> Any:  # pragma: no cover
    """Defensive helper used by future callers that pass dataclasses through.

    Not used internally — every constructor here guarantees ``to_dict``
    returns JSON-clean primitives. Exposed so that tests / future callers
    can assert no rogue dataclass leaked into ``metadata``.
    """
    return asdict(obj) if hasattr(obj, "__dataclass_fields__") else obj
