"""Per-language toolchain + idiom defaults consumed by SOP autogeneration.

Each :class:`LanguageProfile` answers the questions a generated SOP needs to
pin: which linter / formatter / test runner is canonical, what the structured
logger of choice is, what regex flags a "raw print in service code" call site,
and which file globs scope the rules to actual source. ``unknown`` is the
explicit fallback for projects we can't classify.

This module is **pure data** — no I/O, no detection logic, no string
formatting. Detection lives in :mod:`stack_detector`; rendering lives in
:mod:`sop_autogen`.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class LanguageProfile:
    """The toolchain + idiom defaults for one language.

    Field meaning
    -------------
    ``language``
        Canonical lowercase identifier (``python``, ``typescript``, ...).
    ``display_name``
        Human-readable name used in generated prose.
    ``linter`` / ``formatter`` / ``test_runner`` / ``coverage_tool`` /
    ``sca_tool``
        Tool names emitted into ``project.toolchain`` of the SOP manifest.
    ``logger``
        Idiomatic structured logger name (``logging``, ``slog``, ...) used
        as a hint in the prose SOPs.
    ``source_globs``
        Globs matching service-code source files. Pinned on commit-time
        rules so they don't fire on docs / tests / vendor.
    ``test_globs``
        Globs matching test files. Used to scope test-only rules.
    ``print_pattern``
        Regex (string form, ECMAScript-compatible) flagging a raw print
        / log call in service code. Drives ``cq.commit.no_print_in_service_code``.
    ``println_pattern``
        Regex flagging language-specific raw stdout writes that the
        ``log.commit.structured_only`` rule should pick up. Often equals
        ``print_pattern`` for languages with one print primitive.
    ``empty_catch_pattern``
        Regex flagging an empty try/catch block in this language. Drives
        ``cq.commit.no_empty_catch``.
    ``layer_hint``
        One-line layering note prepended to the architecture SOP, naming
        the language's typical module / package boundary.
    ``error_idiom``
        Short label used in the code-quality SOP (``Result<T,E>``,
        ``(T, error)``, ``Optional<T>``, ...).
    """

    language: str
    display_name: str
    linter: str
    formatter: str
    test_runner: str
    coverage_tool: str
    sca_tool: str
    logger: str
    source_globs: tuple[str, ...]
    test_globs: tuple[str, ...]
    print_pattern: str
    println_pattern: str
    empty_catch_pattern: str
    layer_hint: str
    error_idiom: str


# ---------------------------------------------------------------------------
# Profiles
# ---------------------------------------------------------------------------
#
# Every profile is intentionally hand-tuned. Don't fold these into a generic
# template — the *point* of stack-aware SOPs is that the regexes match this
# language's actual idioms (e.g. Go's ``fmt.Println`` is meaningless for
# Python; Python's ``print(`` would not match Go).


_PYTHON = LanguageProfile(
    language="python",
    display_name="Python",
    linter="ruff",
    formatter="ruff format",
    test_runner="pytest",
    coverage_tool="coverage.py",
    sca_tool="pip-audit",
    logger="logging / structlog",
    source_globs=("src/**/*.py", "**/*.py"),
    test_globs=("tests/**/*.py", "**/test_*.py", "**/*_test.py"),
    print_pattern=r"\bprint\s*\(",
    println_pattern=r"\bprint\s*\(",
    empty_catch_pattern=r"except\s+\w*\s*:\s*pass",
    layer_hint=(
        "Python projects: bounded contexts map to top-level packages; "
        "layers map to subpackages (`domain/`, `application/`, "
        "`infrastructure/`, `cli/`)."
    ),
    error_idiom="Result-style returns / specific exception types at boundaries",
)

_TYPESCRIPT = LanguageProfile(
    language="typescript",
    display_name="TypeScript",
    linter="eslint",
    formatter="prettier",
    test_runner="vitest",
    coverage_tool="c8",
    sca_tool="npm audit",
    logger="pino",
    source_globs=("src/**/*.ts", "src/**/*.tsx"),
    test_globs=("**/*.test.ts", "**/*.test.tsx", "tests/**/*.ts"),
    print_pattern=r"\bconsole\.(log|debug|info)\s*\(",
    println_pattern=r"\bconsole\.(log|debug|info)\s*\(",
    empty_catch_pattern=r"catch\s*\([^)]*\)\s*\{\s*\}",
    layer_hint=(
        "TypeScript projects: bounded contexts map to feature folders or "
        "monorepo packages; keep `domain/` / `application/` / "
        "`infrastructure/` separation visible in directory structure."
    ),
    error_idiom="Result<T, E> via neverthrow / fp-ts, or typed Error classes",
)

_JAVASCRIPT = LanguageProfile(
    language="javascript",
    display_name="JavaScript",
    linter="eslint",
    formatter="prettier",
    test_runner="jest",
    coverage_tool="c8",
    sca_tool="npm audit",
    logger="pino",
    source_globs=("src/**/*.js", "src/**/*.mjs", "src/**/*.cjs"),
    test_globs=("**/*.test.js", "tests/**/*.js"),
    print_pattern=r"\bconsole\.(log|debug|info)\s*\(",
    println_pattern=r"\bconsole\.(log|debug|info)\s*\(",
    empty_catch_pattern=r"catch\s*\([^)]*\)\s*\{\s*\}",
    layer_hint=(
        "JavaScript projects: bounded contexts map to feature folders or "
        "monorepo packages; document layering even without a type system "
        "to enforce it."
    ),
    error_idiom="Typed Error subclasses; reserve thrown values for genuine errors",
)

_GO = LanguageProfile(
    language="go",
    display_name="Go",
    linter="golangci-lint",
    formatter="gofmt",
    test_runner="go test ./...",
    coverage_tool="go test -cover",
    sca_tool="govulncheck",
    logger="log/slog",
    source_globs=("**/*.go",),
    test_globs=("**/*_test.go",),
    print_pattern=r"\bfmt\.(Println|Printf|Print)\s*\(",
    println_pattern=r"\bfmt\.(Println|Printf|Print)\s*\(",
    empty_catch_pattern=r"if\s+err\s*!=\s*nil\s*\{\s*\}",
    layer_hint=(
        "Go projects: bounded contexts map to top-level packages under "
        "`internal/`; the public package surface is the contract — keep "
        "it small."
    ),
    error_idiom="(T, error) — wrap with fmt.Errorf and %w; never discard",
)

_RUST = LanguageProfile(
    language="rust",
    display_name="Rust",
    linter="cargo clippy",
    formatter="cargo fmt",
    test_runner="cargo test",
    coverage_tool="cargo tarpaulin",
    sca_tool="cargo audit",
    logger="tracing",
    source_globs=("src/**/*.rs",),
    test_globs=("tests/**/*.rs", "**/tests.rs"),
    print_pattern=r"\b(println|print|eprintln|eprint)!\s*\(",
    println_pattern=r"\b(println|print|eprintln|eprint)!\s*\(",
    empty_catch_pattern=r"\.unwrap_or_else\s*\(\s*\|_\|\s*\(\s*\)\s*\)",
    layer_hint=(
        "Rust projects: bounded contexts map to crates; layers map to "
        "modules within a crate. Use `pub(crate)` aggressively to enforce "
        "boundaries."
    ),
    error_idiom="Result<T, E> with thiserror / anyhow at the boundary",
)

_CPP = LanguageProfile(
    language="cpp",
    display_name="C++",
    linter="clang-tidy",
    formatter="clang-format",
    test_runner="ctest --test-dir build",
    coverage_tool="llvm-cov",
    sca_tool="trivy fs .",
    logger="(project structured logger)",
    source_globs=(
        "src/**/*.cpp",
        "src/**/*.cc",
        "src/**/*.cxx",
        "src/**/*.hpp",
        "src/**/*.h",
        "include/**/*.hpp",
    ),
    test_globs=("tests/**/*.cpp", "**/test_*.cpp"),
    print_pattern=r"std::cout\s*<<",
    println_pattern=r"std::cout\s*<<",
    empty_catch_pattern=r"catch\s*\([^)]*\)\s*\{\s*\}",
    layer_hint=(
        "C++ projects: bounded contexts map to top-level libraries; layers "
        "map to namespaces. No upward includes — Layer N may only "
        "`#include` Layers 0..N-1."
    ),
    error_idiom="Result<T, E> at boundaries; exceptions only for truly exceptional",
)

_JAVA = LanguageProfile(
    language="java",
    display_name="Java",
    linter="checkstyle / spotbugs",
    formatter="google-java-format",
    test_runner="mvn test",
    coverage_tool="jacoco",
    sca_tool="dependency-check",
    logger="SLF4J / logback",
    source_globs=("src/main/java/**/*.java",),
    test_globs=("src/test/java/**/*.java",),
    print_pattern=r"System\.out\.print(ln)?\s*\(",
    println_pattern=r"System\.out\.print(ln)?\s*\(",
    empty_catch_pattern=r"catch\s*\([^)]*\)\s*\{\s*\}",
    layer_hint=(
        "Java projects: bounded contexts map to top-level packages; layers "
        "map to subpackages. Modulith / module-info may make layering a "
        "compile-time check."
    ),
    error_idiom="Checked exceptions at boundaries; Result-like Optional<T> for queries",
)

_KOTLIN = LanguageProfile(
    language="kotlin",
    display_name="Kotlin",
    linter="ktlint",
    formatter="ktlint -F",
    test_runner="gradle test",
    coverage_tool="kover",
    sca_tool="dependency-check",
    logger="SLF4J / kotlin-logging",
    source_globs=("src/main/kotlin/**/*.kt",),
    test_globs=("src/test/kotlin/**/*.kt",),
    print_pattern=r"\bprintln\s*\(",
    println_pattern=r"\bprintln\s*\(",
    empty_catch_pattern=r"catch\s*\([^)]*\)\s*\{\s*\}",
    layer_hint=(
        "Kotlin projects: bounded contexts map to top-level packages; "
        "favour `internal` visibility to enforce module boundaries."
    ),
    error_idiom="Result<T> / sealed class hierarchies at boundaries",
)

_CSHARP = LanguageProfile(
    language="csharp",
    display_name="C#",
    linter="dotnet analyzers",
    formatter="dotnet format",
    test_runner="dotnet test",
    coverage_tool="coverlet",
    sca_tool="dotnet list package --vulnerable",
    logger="Microsoft.Extensions.Logging",
    source_globs=("**/*.cs",),
    test_globs=("**/*Tests.cs", "**/*.Tests/**/*.cs"),
    print_pattern=r"Console\.Write(Line)?\s*\(",
    println_pattern=r"Console\.Write(Line)?\s*\(",
    empty_catch_pattern=r"catch\s*\([^)]*\)\s*\{\s*\}",
    layer_hint=(
        "C# projects: bounded contexts map to assemblies / projects; layers "
        "map to namespaces. Internal visibility enforces project boundaries."
    ),
    error_idiom="Result<T> via FluentResults or specific exception types",
)

_RUBY = LanguageProfile(
    language="ruby",
    display_name="Ruby",
    linter="rubocop",
    formatter="rubocop -A",
    test_runner="bundle exec rspec",
    coverage_tool="simplecov",
    sca_tool="bundler-audit",
    logger="Rails.logger / Logger",
    source_globs=("app/**/*.rb", "lib/**/*.rb"),
    test_globs=("spec/**/*_spec.rb", "test/**/*_test.rb"),
    print_pattern=r"\b(puts|print|pp)\s*\(",
    println_pattern=r"\b(puts|print|pp)\s*\(",
    empty_catch_pattern=r"rescue\s*(=>\s*\w+)?\s*end",
    layer_hint=(
        "Ruby projects: bounded contexts map to top-level modules; layers "
        "map to namespaces (e.g. `App::Domain`, `App::Application`)."
    ),
    error_idiom="Result-style monad gems (dry-monads) or specific exception classes",
)

_UNKNOWN = LanguageProfile(
    language="unknown",
    display_name="(unknown stack)",
    linter="",
    formatter="",
    test_runner="",
    coverage_tool="",
    sca_tool="",
    logger="(project structured logger)",
    source_globs=("src/**", "core/**", "products/**"),
    test_globs=("tests/**", "**/test_*", "**/*_test.*"),
    print_pattern=(
        r"(\bprint\s*\(|\bconsole\.log\s*\(|std::cout\s*<<|"
        r"\bfmt\.Println\s*\(|\bprintln!\s*\()"
    ),
    println_pattern=(r"(\bprintln!?\s*\(|\bfmt\.Println\s*\(|\beprintln!\s*\()"),
    empty_catch_pattern=(r"(except\s+\w*\s*:\s*pass|catch\s*\([^)]*\)\s*\{\s*\})"),
    layer_hint=(
        "Bounded contexts and layers should be documented even when no "
        "language tooling enforces them."
    ),
    error_idiom="Project's chosen Result-style or exception convention",
)


_PROFILES: dict[str, LanguageProfile] = {
    p.language: p
    for p in (
        _PYTHON,
        _TYPESCRIPT,
        _JAVASCRIPT,
        _GO,
        _RUST,
        _CPP,
        _JAVA,
        _KOTLIN,
        _CSHARP,
        _RUBY,
        _UNKNOWN,
    )
}


# ---------------------------------------------------------------------------
# Public lookup
# ---------------------------------------------------------------------------


def get_profile(language: str) -> LanguageProfile:
    """Return the profile for ``language`` (lowercased), or the ``unknown``
    profile if no matching profile is registered. Never raises."""
    return _PROFILES.get(language.lower(), _UNKNOWN)


def known_languages() -> tuple[str, ...]:
    """Return the lowercase identifiers of every registered profile,
    excluding ``unknown``. Useful for ``--lang`` argparse choices."""
    return tuple(name for name in _PROFILES if name != "unknown")
