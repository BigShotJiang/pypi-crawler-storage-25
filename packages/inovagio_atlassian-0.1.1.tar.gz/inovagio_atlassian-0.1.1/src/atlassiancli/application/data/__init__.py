"""Static data tables consumed by application services.

Kept separate from logic modules so per-language defaults, regex tables,
and similar reference material can grow without crowding the services
that read them.
"""
