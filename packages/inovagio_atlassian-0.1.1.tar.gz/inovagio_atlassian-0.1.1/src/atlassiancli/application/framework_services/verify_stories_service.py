"""``framework verify-stories`` use case.

Copied from ``inovagio/scripts/verifyproductstories.py``. The service
reads the manifest tree, queries Jira via the v3 ``approximate-count``
endpoint, and returns a structured per-epic delta.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field

from atlassiancli.domain.framework.config import ProductConfig
from atlassiancli.infrastructure.framework_jira_client import (
    FrameworkJiraClient,
)


def manifest_count_per_epic(cfg: ProductConfig) -> dict[str, int]:
    """Count manifests per configured epic by parsing the ``epic:`` line.

    The parse is intentionally line-based + minimal — it doesn't pull in
    the whole YAML loader because we only need to read one field per file
    and this matches the source script's behaviour byte-for-byte (so the
    parity gate stays stable across the repo's manifest count).
    """
    counts: dict[str, int] = dict.fromkeys(cfg.jira.epics, 0)
    if not cfg.manifests_dir.is_dir():
        return counts
    for path in sorted(cfg.manifests_dir.glob("*.yaml")):
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.startswith("epic:"):
                ep = line.split(":", 1)[1].strip()
                if ep in counts:
                    counts[ep] += 1
                break
    return counts


@dataclass(frozen=True)
class EpicParity:
    """Per-epic counts (manifests on disk vs. Jira) plus done count."""

    epic: str
    epic_key: str
    manifests: int
    jira_total: int
    jira_done: int

    @property
    def delta(self) -> int:
        """``manifests - jira_total``; non-zero means drift."""
        return self.manifests - self.jira_total

    @property
    def status(self) -> str:
        """``OK`` when in parity, otherwise ``DELTA (+N)`` / ``DELTA (-N)``."""
        return "OK" if self.delta == 0 else f"DELTA ({self.delta:+d})"


@dataclass(frozen=True)
class VerifyResult:
    """Aggregated verify-stories outcome."""

    rows: list[EpicParity] = field(default_factory=list)
    total_manifests: int = 0
    total_jira: int = 0
    total_done: int = 0
    mismatches: list[str] = field(default_factory=list)

    @property
    def green(self) -> bool:
        """``True`` when every epic's row is in parity."""
        return not self.mismatches


class VerifyStoriesService:
    """Reconcile per-epic manifest counts with Jira."""

    def __init__(
        self,
        cfg: ProductConfig,
        client: FrameworkJiraClient,
        *,
        log: Callable[[str], None] = print,
    ) -> None:
        self._cfg = cfg
        self._client = client
        self._log = log

    def verify(self) -> VerifyResult:
        """Run the parity scan and return a structured delta report."""
        manifests = manifest_count_per_epic(self._cfg)
        rows: list[EpicParity] = []
        mismatches: list[str] = []
        total_manifests = sum(manifests.values())
        total_jira = 0
        total_done = 0

        for ep, key in self._cfg.jira.epics.items():
            m = manifests.get(ep, 0)
            base = (
                f"project = {self._cfg.jira.project_key} AND parent = {key} "
                f"AND issuetype = Story "
                f'AND labels = "{self._cfg.jira.label_namespace}"'
            )
            j = self._client.approximate_count(base)
            d = self._client.approximate_count(base + " AND status = Done")
            total_jira += j
            total_done += d
            row = EpicParity(epic=ep, epic_key=key, manifests=m, jira_total=j, jira_done=d)
            rows.append(row)
            self._log(f"{ep:<6} {m:>10} {j:>6} {d:>6}  {row.status}")
            if row.delta != 0:
                mismatches.append(f"{ep}: manifests={m} jira={j}")

        return VerifyResult(
            rows=rows,
            total_manifests=total_manifests,
            total_jira=total_jira,
            total_done=total_done,
            mismatches=mismatches,
        )


__all__ = [
    "EpicParity",
    "VerifyResult",
    "VerifyStoriesService",
    "manifest_count_per_epic",
]
