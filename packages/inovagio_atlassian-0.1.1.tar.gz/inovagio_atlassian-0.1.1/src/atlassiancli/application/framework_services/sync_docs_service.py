"""``framework sync-docs`` use case.

Copied from ``inovagio/scripts/syncproductdocstoconfluence.py``. Surgical
adaptations:

* ``MarkdownConfluenceFormatter`` is imported directly from
  :mod:`atlassiancli.infrastructure.markdown_formatter` rather than via
  ``importlib.util.spec_from_file_location`` — same class, same behaviour,
  no filesystem boot path.
* The Confluence client is :class:`FrameworkConfluenceClient` (transport
  swap; same surface).
* The argparse-driven ``main()`` is replaced by an explicit-kwargs class.

Doc-handle resolution (``DEFAULT_REPO_PATHS``, ``CONFLUENCE_ONLY_HANDLES``,
``EPIC_HANDLE_RE``, ``ADR_HANDLE_RE``) is preserved verbatim.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass, field

from atlassiancli.domain.framework.config import ProductConfig
from atlassiancli.infrastructure.confluence_client import ConfluenceApiError
from atlassiancli.infrastructure.framework_confluence_client import (
    FrameworkConfluenceClient,
)
from atlassiancli.infrastructure.markdown_formatter import (
    MarkdownConfluenceFormatter,
)

GITHUB_URL_BASE = "https://github.com/inovagio/inovagio/blob/main/docs"

# Map doc handle -> repo file (relative to docs/<product>/) for top-level docs.
# Convention-based handles ``EPIC_E-NN`` and ``ADR_NNNN`` are resolved via
# ``resolve_repo_path()`` against the configured ``epic_docs_dir`` /
# ``adr_dir`` paths.
DEFAULT_REPO_PATHS: dict[str, str] = {
    "README": "README.md",
    "PRODUCT_IDENTITY": "product-identity.md",
    "ARCHITECTURE": "ARCHITECTURE.md",
    "DESIGN_SPEC": "DESIGN_SPEC.md",
    "IMPLEMENTATION_PLAN": "IMPLEMENTATION_PLAN.md",
    "ROADMAP": "ROADMAP.md",
    "GA_V1_PLAN": "GA_V1_PLAN.md",
    "PARITY_LEDGER": "PARITY_LEDGER.md",
    "POSTGRES_PARITY": "POSTGRES_FEATURE_PARITY_GAP_LEDGER.md",
    "ENGINE_PARITY_AUDIT": "engine-parity-audit-2026-05-01.md",
    "OPERATOR_GUIDE": "operations/runbook.md",
    "CAPABILITY_MAP": "CAPABILITY_MAP.md",
    "SURFACE_SPEC": "SURFACE_SPEC.md",
}

# Handles that map to Confluence-only organizational pages (no repo file).
CONFLUENCE_ONLY_HANDLES: set[str] = {"RELEASE_GATES", "EPICS_HUB", "ADRS_HUB"}

EPIC_HANDLE_RE = re.compile(r"^EPIC_(E-\d{2,3})$")
ADR_HANDLE_RE = re.compile(r"^ADR_(\d{4})$")

RELATIVE_LINK_RE = re.compile(r"\[([^\]]+)\]\(([^)]+)\)")


# ---------------------------------------------------------------------------
# Doc-handle -> repo path resolution
# ---------------------------------------------------------------------------


def resolve_repo_path(handle: str, cfg: ProductConfig) -> str | None:
    """Map a doc handle to its repo file path (relative to docs/<product>/).

    Returns ``None`` for Confluence-only organizational handles or for
    handles with no matching repo file.
    """
    if handle in CONFLUENCE_ONLY_HANDLES:
        return None
    if handle in DEFAULT_REPO_PATHS:
        return DEFAULT_REPO_PATHS[handle]

    m = EPIC_HANDLE_RE.match(handle)
    if m:
        epic_id = m.group(1)
        epics_dir = cfg.docs_dir / cfg.paths.epic_docs_dir
        if epics_dir.is_dir():
            matches = sorted(epics_dir.glob(f"{epic_id}-*.md"))
            if matches:
                return matches[0].relative_to(cfg.docs_dir).as_posix()
        return None

    m = ADR_HANDLE_RE.match(handle)
    if m:
        adr_id = m.group(1)
        adr_dir = cfg.docs_dir / cfg.paths.adr_dir
        if adr_dir.is_dir():
            matches = sorted(adr_dir.glob(f"{adr_id}-*.md"))
            if matches:
                return matches[0].relative_to(cfg.docs_dir).as_posix()
        return None

    return None


# ---------------------------------------------------------------------------
# Markdown -> Confluence body preprocessor
# ---------------------------------------------------------------------------


def build_sibling_link_map(cfg: ProductConfig) -> dict[str, str]:
    """Map repo doc filenames -> Confluence page URLs (for cross-linking)."""
    mapping: dict[str, str] = {}
    for handle, page_id in cfg.confluence.doc_pages.items():
        repo_rel = resolve_repo_path(handle, cfg)
        if repo_rel:
            mapping[repo_rel] = (
                f"https://{cfg.confluence.cloud_site}"
                f"/wiki/spaces/{cfg.confluence.space_key}/pages/{page_id}"
            )
    return mapping


def rewrite_links(
    markdown: str,
    source_relpath: str,
    sibling_links: dict[str, str],
    cfg: ProductConfig,
) -> str:
    """Rewrite relative markdown links to Confluence siblings or GitHub URLs."""
    from pathlib import Path as _Path

    source_dir = _Path(source_relpath).parent

    def repl(match: re.Match[str]) -> str:
        text, target = match.group(1), match.group(2)
        if target.startswith(("http://", "https://", "mailto:", "#")):
            return f"[{text}]({target})"
        target_path, _, fragment = target.partition("#")
        sibling = sibling_links.get(target_path)
        if sibling:
            return f"[{text}]({sibling}{('#' + fragment) if fragment else ''})"
        if target_path.startswith("/"):
            github_path = target_path.lstrip("/")
        else:
            joined = (source_dir / target_path).as_posix()
            github_path = joined.replace("./", "")
        full = f"{GITHUB_URL_BASE}/{cfg.id}/{github_path}"
        return f"[{text}]({full}{('#' + fragment) if fragment else ''})"

    return RELATIVE_LINK_RE.sub(repl, markdown)


def render_markdown_to_storage(markdown_text: str) -> str:
    """Convert GitHub-flavored markdown to Confluence storage XHTML."""
    formatter = MarkdownConfluenceFormatter()
    return formatter.markdown_to_confluence(markdown_text)


def prepare_body(markdown: str, source_relpath: str, cfg: ProductConfig) -> str:
    """Rewrite links + append the authoring-source footer (idempotent)."""
    sibling_links = build_sibling_link_map(cfg)
    body = rewrite_links(markdown, source_relpath, sibling_links, cfg)
    marker = "<!-- inovagio-docframework:authoring-source-footer -->"
    if marker in body:
        return body
    footer = (
        f"\n\n---\n\n{marker}\n"
        f"_Authoring source:_ "
        f"[`docs/{cfg.id}/{source_relpath}`]"
        f"({GITHUB_URL_BASE}/{cfg.id}/{source_relpath}) "
        f"in the inovagio monorepo. This page is a reader-facing mirror — "
        f"do not edit it directly. Update the repo and re-run "
        f"`atlassiancli framework sync-docs --product {cfg.id}`."
    )
    return body + footer


# ---------------------------------------------------------------------------
# Result types + service
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SyncDocOutcome:
    """Per-doc outcome of a sync-docs run."""

    handle: str
    page_id: str
    success: bool
    skipped_confluence_only: bool = False
    error: str | None = None
    next_version: int | None = None


@dataclass(frozen=True)
class SyncResult:
    """Aggregated sync-docs outcome."""

    successes: int
    failures: int
    outcomes: list[SyncDocOutcome] = field(default_factory=list)
    dry_run: bool = False


class SyncDocsService:
    """Push repo markdown docs to Confluence pages declared in the config."""

    def __init__(
        self,
        cfg: ProductConfig,
        client: FrameworkConfluenceClient,
        *,
        log: Callable[[str], None] = print,
    ) -> None:
        self._cfg = cfg
        self._client = client
        self._log = log

    def sync(
        self,
        *,
        handles: list[str] | None = None,
        dry_run: bool = False,
    ) -> SyncResult:
        """Sync the listed handles (or every configured one) to Confluence."""
        if not self._cfg.confluence.doc_pages:
            raise ValueError(
                f"docs/{self._cfg.id}/.docframework.yaml has no "
                f"confluence.doc_pages entries — nothing to sync"
            )

        target_handles = handles if handles else list(self._cfg.confluence.doc_pages)

        outcomes: list[SyncDocOutcome] = []
        successes = 0
        failures = 0

        for handle in target_handles:
            page_id = self._cfg.confluence.doc_pages.get(handle)
            if not page_id:
                outcomes.append(
                    SyncDocOutcome(
                        handle=handle,
                        page_id="",
                        success=False,
                        error="not in confluence.doc_pages",
                    )
                )
                failures += 1
                continue
            outcome = self._sync_one(handle, page_id, dry_run=dry_run)
            outcomes.append(outcome)
            if outcome.success:
                successes += 1
            else:
                failures += 1

        return SyncResult(
            successes=successes,
            failures=failures,
            outcomes=outcomes,
            dry_run=dry_run,
        )

    # -- internals --

    def _sync_one(self, handle: str, page_id: str, *, dry_run: bool) -> SyncDocOutcome:
        if handle in CONFLUENCE_ONLY_HANDLES:
            self._log(f"-- {handle} (page id {page_id}): skipped — Confluence-only")
            return SyncDocOutcome(
                handle=handle,
                page_id=page_id,
                success=True,
                skipped_confluence_only=True,
            )

        repo_rel = resolve_repo_path(handle, self._cfg)
        if not repo_rel:
            err = (
                f"{handle}: cannot resolve repo path "
                f"(handle not recognised; expected EPIC_E-NN, ADR_NNNN, "
                f"or one of {sorted(DEFAULT_REPO_PATHS)})"
            )
            self._log(f"  X {err}")
            return SyncDocOutcome(handle=handle, page_id=page_id, success=False, error=err)

        repo_path = self._cfg.docs_dir / repo_rel
        if not repo_path.exists():
            err = f"{handle}: repo file missing at {repo_path}"
            self._log(f"  X {err}")
            return SyncDocOutcome(handle=handle, page_id=page_id, success=False, error=err)

        self._log(f"-- {handle} (page id {page_id})")
        try:
            page = self._client.get_page(page_id)
        except ConfluenceApiError as exc:
            err = f"{handle}: get_page failed: {exc}"
            self._log(f"  X {err}")
            return SyncDocOutcome(handle=handle, page_id=page_id, success=False, error=err)

        title = page.get("title", "")
        current_version = int((page.get("version") or {}).get("number", 0))
        next_version = current_version + 1
        self._log(f"   title: {title}")
        self._log(f"   current version: {current_version}")

        body_md = prepare_body(repo_path.read_text(encoding="utf-8"), repo_rel, self._cfg)
        body_storage = render_markdown_to_storage(body_md)
        md_size = len(body_md.encode("utf-8"))
        storage_size = len(body_storage.encode("utf-8"))
        self._log(
            f"   prepared body: {md_size:,} bytes markdown -> {storage_size:,} bytes storage XHTML"
        )

        if dry_run:
            self._log(f"   [dry-run] would PUT v{next_version}")
            return SyncDocOutcome(
                handle=handle,
                page_id=page_id,
                success=True,
                next_version=next_version,
            )

        msg = (
            f"sync from docs/{self._cfg.id}/{repo_rel} (repo authoritative; "
            f"per docs/INOVAGIO_DOC_FRAMEWORK.md)"
        )
        try:
            self._client.update_page(
                page_id,
                title=title,
                body_value=body_storage,
                body_representation="storage",
                version_message=msg,
                next_version=next_version,
            )
        except ConfluenceApiError as exc:
            err = f"{handle}: update_page failed: {exc}"
            self._log(f"  X {err}")
            return SyncDocOutcome(handle=handle, page_id=page_id, success=False, error=err)

        self._log(f"   updated to v{next_version}")
        return SyncDocOutcome(
            handle=handle,
            page_id=page_id,
            success=True,
            next_version=next_version,
        )


__all__ = [
    "ADR_HANDLE_RE",
    "CONFLUENCE_ONLY_HANDLES",
    "DEFAULT_REPO_PATHS",
    "EPIC_HANDLE_RE",
    "GITHUB_URL_BASE",
    "RELATIVE_LINK_RE",
    "SyncDocOutcome",
    "SyncDocsService",
    "SyncResult",
    "build_sibling_link_map",
    "prepare_body",
    "render_markdown_to_storage",
    "resolve_repo_path",
    "rewrite_links",
]
