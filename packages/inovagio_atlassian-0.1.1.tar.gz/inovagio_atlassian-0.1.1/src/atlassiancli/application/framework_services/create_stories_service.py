"""``framework create-stories`` use case.

Copied from ``inovagio/scripts/createproductstories.py``. Surgical adaptations:

* YAML loading via :mod:`atlassiancli.infrastructure.yaml_codec` (replaces
  the source's ``_inovagio_yaml`` ctypes wrapper).
* Jira client is :class:`FrameworkJiraClient` (same surface as the source's
  ``JiraClient``; different transport).
* The argparse-driven ``main()`` is replaced by a class with explicit kwargs
  so CLI handlers can adapt args -> service call -> structured result.

The three-pass logic (create / link / transition) is preserved verbatim from
the source: same idempotency markers, same skip semantics, same payload
shape, same labelling convention.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from atlassiancli.domain.framework.config import ProductConfig
from atlassiancli.infrastructure.framework_jira_client import (
    FrameworkJiraClient,
)
from atlassiancli.infrastructure.jira_client import JiraApiError
from atlassiancli.infrastructure.yaml_codec import safe_load

PRIORITY_MAP = {"P0": "Highest", "P1": "High", "P2": "Medium", "P3": "Low"}
DONE_STATUSES = {"DONE", "COMPLETED"}
QUALITY_GATES_TEXT = (
    "0 clang-tidy warnings · 0 sanitizer findings · cross-OS green "
    "(Linux + macOS + Windows) · ≥85% coverage · no stub markers · "
    "DDD layer rules respected · pipeline-wired (E19 standard)."
)


# ---------------------------------------------------------------------------
# Manifest loading
# ---------------------------------------------------------------------------


def load_manifest(path: Path) -> dict[str, Any]:
    """Load + minimally validate a single ``SX.Y.yaml`` manifest."""
    data = safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"{path}: not a YAML mapping")
    for required in ("id", "epic", "title"):
        if required not in data:
            raise ValueError(f"{path}: missing required field {required!r}")
    return data


def discover_manifests(
    cfg: ProductConfig, *, filter_epic: str | None, filter_id: str | None
) -> list[dict[str, Any]]:
    """Glob ``stories/manifests/S*.yaml`` and return ordered manifests."""
    out: list[dict[str, Any]] = []
    for path in sorted(cfg.manifests_dir.glob("S*.yaml")):
        m = load_manifest(path)
        if filter_id and m["id"] != filter_id:
            continue
        if filter_epic and m["epic"] != filter_epic:
            continue
        out.append(m)
    return out


# ---------------------------------------------------------------------------
# Description rendering (markdown emitted into Jira ADF)
# ---------------------------------------------------------------------------


def escape_md_path(path: str) -> str:
    """Escape ``**`` so glob-style paths don't render as bold in markdown."""
    return path.replace("**", "\\*\\*")


def render_description(m: dict[str, Any], cfg: ProductConfig) -> str:
    """Render a manifest into the canonical 7-section markdown description."""
    s_id = m["id"]
    title = m["title"]
    phase = m.get("phase", "?")
    priority = m.get("priority", "P2")
    priority_label = {
        "P0": "(Highest)",
        "P1": "(High)",
        "P2": "(Medium)",
        "P3": "(Low)",
    }.get(priority, "")

    acs = m.get("acceptance") or []
    owns = m.get("owns_paths") or []
    reads = m.get("reads_paths") or []
    build = m.get("build") or {}
    target = build.get("target") or "null"
    test_targets = build.get("test_targets") or []
    test_target_str = ", ".join(test_targets)

    depends_on = m.get("depends_on") or []
    blocks = m.get("blocks") or []
    blocked_by_str = ", ".join(depends_on) if depends_on else "—"
    blocks_str = ", ".join(blocks) if blocks else "—"

    spec_refs = m.get("spec_refs") or []
    spec_refs_str = ", ".join(spec_refs) if spec_refs else "—"

    epic_short = m["epic"]
    epic_key = cfg.jira.epics.get(epic_short, "?")
    manifest_path = f"docs/{cfg.id}/{cfg.paths.manifests_dir}/{s_id}.yaml"
    evidence_path = m.get("evidence_path", f"docs/{cfg.id}/{cfg.paths.evidence_dir}/{s_id}.md")
    requires_intake = m.get("requires_human_intake_approval", False)

    lines: list[str] = []
    lines += ["## Goal", "", title, ""]
    lines += [
        "## Phase / Priority",
        "",
        f"Phase {phase} · **{priority}** {priority_label}",
        "",
    ]
    lines += ["## Acceptance Criteria", ""]
    if acs:
        for ac in acs:
            lines.append(f"* {ac}")
    else:
        lines.append("* TBD — no acceptance criteria captured in manifest yet")
    lines.append("")
    lines += ["## Key Files", "", "**Owns:**", ""]
    for p in owns:
        lines.append(f"* {escape_md_path(p)}")
    if not owns:
        lines.append("* —")
    lines += ["", "**Reads:**", ""]
    for p in reads:
        lines.append(f"* {escape_md_path(p)}")
    if not reads:
        lines.append("* —")
    lines += ["", f"**Build target:** `{target}` (test: `{test_target_str}`)", ""]
    lines += [
        "## Dependencies",
        "",
        f"* Blocked by: {blocked_by_str}",
        f"* Blocks: {blocks_str}",
        "",
    ]
    lines += ["## Code Quality Gates", "", QUALITY_GATES_TEXT, ""]
    lines += [
        "## Definition of Done",
        "",
        f"All AC pass · tests green on CI · evidence at `{evidence_path}` · "
        "Confluence story page updated · PR merged to main.",
        "",
    ]
    lines += [
        "## References",
        "",
        f"* Manifest: `{manifest_path}`",
        f"* Epic: \\[{cfg.jira.summary_prefix.strip('[]')}\\] {epic_short} ({epic_key})",
        f"* Spec refs: {spec_refs_str}",
        f"* **Requires human intake approval before merge: {'YES' if requires_intake else 'NO'}**",
        "",
    ]

    return "\n".join(lines)


def adf_from_markdown(md: str) -> dict:
    """Wrap a markdown blob in a minimal ADF document envelope."""
    return {
        "type": "doc",
        "version": 1,
        "content": [
            {"type": "paragraph", "content": [{"type": "text", "text": md}]},
        ],
    }


# ---------------------------------------------------------------------------
# Field assembly
# ---------------------------------------------------------------------------


def compute_labels(m: dict[str, Any], cfg: ProductConfig) -> list[str]:
    """Compute the canonical label set for a story create payload."""
    epic_short = m["epic"]
    # E-04 -> e04
    epic_label = "epic-e" + epic_short.replace("E-", "").lstrip("0").zfill(2)
    labels = [
        cfg.id,
        cfg.jira.label_namespace,
        f"phase-{m.get('phase', 1)}",
        f"priority-{m.get('priority', 'P2')}",
        epic_label,
    ]
    if m.get("requires_human_intake_approval"):
        labels.append("requires-human-intake")
    return labels


def build_create_payload(
    m: dict[str, Any], cfg: ProductConfig, assignee_account_id: str | None
) -> dict:
    """Build the ``fields`` dict for ``POST /rest/api/3/issue``."""
    s_id = m["id"]
    title = m["title"]
    epic_short = m["epic"]
    epic_key = cfg.jira.epics.get(epic_short)
    if epic_key is None:
        raise ValueError(
            f"{s_id}: epic {epic_short!r} not in {cfg.docs_dir}/.docframework.yaml (jira.epics)"
        )

    summary = f"{cfg.jira.summary_prefix} {s_id} {title}"
    fields: dict[str, Any] = {
        "project": {"key": cfg.jira.project_key},
        "issuetype": {"name": "Story"},
        "summary": summary,
        "description": adf_from_markdown(render_description(m, cfg)),
        "labels": compute_labels(m, cfg),
        "priority": {"name": PRIORITY_MAP.get(m.get("priority", "P2"), "Medium")},
        "parent": {"key": epic_key},
    }
    fields["customfield_10014"] = epic_key  # legacy Epic Link
    if assignee_account_id:
        fields["assignee"] = {"accountId": assignee_account_id}
    return fields


def find_existing_story_for(
    client: FrameworkJiraClient, cfg: ProductConfig, s_id: str
) -> str | None:
    """Probe Jira for an existing story whose summary starts with ``[PFX] s_id``."""
    prefix = cfg.jira.summary_prefix
    jql = (
        f"project = {cfg.jira.project_key} AND issuetype = Story AND "
        f'summary ~ "\\"{prefix} {s_id}\\""'
    )
    try:
        issues = client.search_jql(jql, fields=["summary"], max_results=5)
    except JiraApiError:
        return None
    pattern = re.compile(rf"^{re.escape(prefix)}\s*(\S+)")
    for issue in issues:
        summary = issue.get("fields", {}).get("summary", "")
        match = pattern.match(summary)
        if match and match.group(1) == s_id:
            return issue["key"]
    return None


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CreateStoriesResult:
    """Aggregated outcome of a create-stories invocation."""

    discovered: int
    created: int
    skipped_existing: int
    linked: int
    link_skipped: int
    transitioned: int
    transition_skipped: int
    errors: list[str] = field(default_factory=list)
    s_to_key: dict[str, str] = field(default_factory=dict)
    dry_run: bool = False


# ---------------------------------------------------------------------------
# Service
# ---------------------------------------------------------------------------


class CreateStoriesService:
    """Orchestrate the three create-stories passes (create / link / transition).

    Idempotent: re-running against the same manifest set is a no-op when no
    drift exists. ``dry_run=True`` short-circuits every API write.
    """

    def __init__(
        self,
        cfg: ProductConfig,
        client: FrameworkJiraClient | None,
        *,
        log: Callable[[str], None] = print,
    ) -> None:
        self._cfg = cfg
        self._client = client
        self._log = log

    # -- public --

    def create(
        self,
        *,
        filter_epic: str | None = None,
        filter_id: str | None = None,
        dry_run: bool = False,
        skip_link_pass: bool = False,
        no_transition: bool = False,
    ) -> CreateStoriesResult:
        """Execute the three-pass workflow against the configured product."""
        manifests = discover_manifests(self._cfg, filter_epic=filter_epic, filter_id=filter_id)
        self._log(f"Discovered {len(manifests)} manifest(s)")

        assignee_account_id: str | None = None
        if self._client is not None and not dry_run and self._cfg.jira.default_assignee_email:
            assignee_account_id = self._client.find_account_id(
                self._cfg.jira.default_assignee_email
            )
            if assignee_account_id is None:
                self._log(
                    f"WARN: could not resolve account for "
                    f"{self._cfg.jira.default_assignee_email}; assignee unset"
                )

        s_to_key, created, skipped_existing, errors = self._pass_create(
            manifests,
            dry_run=dry_run,
            assignee_account_id=assignee_account_id,
        )

        if dry_run and not skip_link_pass:
            for m in manifests:
                s_to_key.setdefault(m["id"], f"NEW-{m['id']}")

        linked = 0
        link_skipped = 0
        if not skip_link_pass:
            linked, link_skipped = self._pass_link(manifests, s_to_key, dry_run=dry_run)

        transitioned = 0
        transition_skipped = 0
        if not no_transition:
            transitioned, transition_skipped = self._pass_transition(
                manifests, s_to_key, dry_run=dry_run
            )

        return CreateStoriesResult(
            discovered=len(manifests),
            created=created,
            skipped_existing=skipped_existing,
            linked=linked,
            link_skipped=link_skipped,
            transitioned=transitioned,
            transition_skipped=transition_skipped,
            errors=errors,
            s_to_key=s_to_key,
            dry_run=dry_run,
        )

    # -- pass 1: create --

    def _pass_create(
        self,
        manifests: list[dict[str, Any]],
        *,
        dry_run: bool,
        assignee_account_id: str | None,
    ) -> tuple[dict[str, str], int, int, list[str]]:
        s_to_key: dict[str, str] = {}
        skipped = 0
        created = 0
        errors: list[str] = []
        self._log("Pass 1 — Create stories")
        for m in manifests:
            s_id = m["id"]
            existing = (
                find_existing_story_for(self._client, self._cfg, s_id)
                if self._client is not None
                else None
            )
            if existing:
                verb = "would skip (exists)" if dry_run else "exists"
                self._log(f"   {s_id}: {verb} as {existing}")
                s_to_key[s_id] = existing
                skipped += 1
                continue

            try:
                payload = build_create_payload(m, self._cfg, assignee_account_id)
            except ValueError as exc:
                errors.append(str(exc))
                self._log(f"   {s_id}: FAILED — {exc}")
                continue

            if dry_run:
                self._log(f"   {s_id}: would CREATE — {payload['summary'][:80]}")
                continue

            try:
                assert self._client is not None
                result = self._client.create_issue(payload)
                s_to_key[s_id] = result["key"]
                self._log(f"   {s_id}: created as {result['key']}")
                created += 1
            except JiraApiError as exc:
                errors.append(f"{s_id}: {exc}")
                self._log(f"   {s_id}: FAILED — {exc}")

        return s_to_key, created, skipped, errors

    # -- pass 2: link --

    def _pass_link(
        self,
        manifests: list[dict[str, Any]],
        s_to_key: dict[str, str],
        *,
        dry_run: bool,
    ) -> tuple[int, int]:
        self._log("Pass 2 — Link dependencies")
        linked = 0
        skipped = 0
        for m in manifests:
            s_id = m["id"]
            from_key = s_to_key.get(s_id)
            if not from_key:
                continue
            for dep in m.get("depends_on") or []:
                to_key = s_to_key.get(dep)
                if not to_key and not dry_run and self._client is not None:
                    to_key = find_existing_story_for(self._client, self._cfg, dep)
                if not to_key:
                    self._log(f"   {s_id} depends_on {dep}: target not found")
                    skipped += 1
                    continue
                if dry_run:
                    self._log(f"   {s_id} ({from_key}) <-blocks- {dep} ({to_key})")
                    continue
                try:
                    assert self._client is not None
                    self._client.add_issue_link("Blocks", inward_key=from_key, outward_key=to_key)
                    linked += 1
                    self._log(f"   {dep} blocks {s_id}")
                except JiraApiError as exc:
                    msg = str(exc).lower()
                    if "already exists" in msg or "duplicate" in msg:
                        self._log(f"   {dep} -> {s_id}: link already exists")
                    else:
                        self._log(f"   {dep} -> {s_id}: {exc}")
        return linked, skipped

    # -- pass 3: transition --

    def _pass_transition(
        self,
        manifests: list[dict[str, Any]],
        s_to_key: dict[str, str],
        *,
        dry_run: bool,
    ) -> tuple[int, int]:
        self._log("Pass 3 — Transition COMPLETED/DONE stories to Done")
        transitioned = 0
        skipped = 0
        for m in manifests:
            s_id = m["id"]
            if (m.get("status") or "NOT_STARTED") not in DONE_STATUSES:
                continue
            key = s_to_key.get(s_id)
            if not key:
                continue
            if dry_run:
                self._log(f"   {s_id} ({key}): would transition ({m['status']} -> Done)")
                continue
            try:
                assert self._client is not None
                transitions = self._client.get_transitions(key)
                done_t = next(
                    (t for t in transitions if t.get("name", "").lower() == "done"),
                    None,
                )
                if not done_t:
                    skipped += 1
                    self._log(f"   {s_id} ({key}): no Done transition available")
                    continue
                self._client.transition_issue(key, done_t["id"])
                transitioned += 1
                self._log(f"   {s_id} ({key}): transitioned to Done")
            except JiraApiError as exc:
                self._log(f"   {s_id} ({key}): {exc}")
        return transitioned, skipped


__all__ = [
    "CreateStoriesResult",
    "CreateStoriesService",
    "DONE_STATUSES",
    "PRIORITY_MAP",
    "QUALITY_GATES_TEXT",
    "adf_from_markdown",
    "build_create_payload",
    "compute_labels",
    "discover_manifests",
    "escape_md_path",
    "find_existing_story_for",
    "load_manifest",
    "render_description",
]
