"""Application services for the doc framework bridge tier (PR 5).

Each service encapsulates one of the four bridge subcommands:

* :mod:`.create_stories_service` — manifests -> Jira stories
* :mod:`.verify_stories_service` — manifest <-> Jira parity
* :mod:`.reverse_sync_service`   — Jira -> manifests
* :mod:`.sync_docs_service`      — repo markdown -> Confluence pages

Services accept fully-resolved dependencies (config, clients) at construction
time and expose a single public entry method that returns a structured result
dataclass. CLI handlers convert those into JSON or human-readable output.
"""
