"""``framework reverse-sync`` use case.

Copied from ``inovagio/scripts/reversesyncproductmanifests.py``. The service
walks Jira ADF descriptions for stories under the configured epics and
materialises canonical YAML manifests for stories that don't yet have one
on disk. Idempotent: skips any S-id whose manifest already exists.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from atlassiancli.domain.framework.config import ProductConfig
from atlassiancli.infrastructure.framework_jira_client import (
    FrameworkJiraClient,
)
from atlassiancli.infrastructure.yaml_codec import safe_dump

PRIORITY_REVERSE = {"Highest": "P0", "High": "P1", "Medium": "P2", "Low": "P3"}

DEP_LIST_RE = re.compile(r"\s*[,;]\s*")


# ---------------------------------------------------------------------------
# ADF traversal
# ---------------------------------------------------------------------------


def adf_text(node: Any) -> str:
    """Concatenate all ``text`` leaves of an ADF subtree (no marks)."""
    if not isinstance(node, dict):
        return ""
    if node.get("type") == "text":
        return node.get("text", "") or ""
    return "".join(adf_text(c) for c in (node.get("content") or []))


def adf_text_with_marks(node: Any) -> str:
    """Concatenate ADF text with code/strong marks rendered as markdown."""
    if not isinstance(node, dict):
        return ""
    if node.get("type") == "text":
        text = node.get("text", "") or ""
        for mark in node.get("marks") or []:
            mt = mark.get("type")
            if mt == "code":
                text = f"`{text}`"
            elif mt == "strong":
                text = f"**{text}**"
        return text
    return "".join(adf_text_with_marks(c) for c in (node.get("content") or []))


def parse_sections(adf: dict) -> dict[str, list[dict]]:
    """Split an ADF doc into ``{h2-heading: [child nodes]}`` sections."""
    sections: dict[str, list[dict]] = {}
    if not isinstance(adf, dict) or adf.get("type") != "doc":
        return sections
    current: str | None = None
    current_nodes: list[dict] = []
    for node in adf.get("content") or []:
        if (
            isinstance(node, dict)
            and node.get("type") == "heading"
            and (node.get("attrs") or {}).get("level") == 2
        ):
            if current is not None:
                sections[current] = current_nodes
            current = adf_text(node).strip()
            current_nodes = []
        elif current is not None:
            current_nodes.append(node)
    if current is not None:
        sections[current] = current_nodes
    return sections


def first_bullet_items(nodes: list[dict]) -> list[str]:
    """Return the items of the first ``bulletList`` in ``nodes``."""
    for node in nodes:
        if node.get("type") == "bulletList":
            items: list[str] = []
            for li in node.get("content") or []:
                if li.get("type") == "listItem":
                    items.append(adf_text_with_marks(li).strip())
            return items
    return []


def section_to_text_block(nodes: list[dict]) -> str:
    """Flatten a section's child nodes into a markdown-ish text block."""
    parts: list[str] = []
    for node in nodes:
        t = node.get("type")
        if t == "paragraph":
            txt = adf_text_with_marks(node).strip()
            if txt:
                parts.append(txt)
        elif t == "bulletList":
            for li in node.get("content") or []:
                if li.get("type") == "listItem":
                    parts.append(f"- {adf_text_with_marks(li).strip()}")
        elif t == "codeBlock":
            parts.append("```")
            parts.append(adf_text(node))
            parts.append("```")
    return "\n".join(parts).strip()


# ---------------------------------------------------------------------------
# Section parsers
# ---------------------------------------------------------------------------


def parse_dependencies(items: list[str]) -> tuple[list[str], list[str]]:
    """Parse the ``Blocked by:`` / ``Blocks:`` bullet items into two lists."""
    depends: list[str] = []
    blocks: list[str] = []
    for raw in items:
        clean = raw.replace("**", "").strip()
        m_dep = re.match(r"Blocked by:\s*(.*)$", clean, re.IGNORECASE)
        m_block = re.match(r"Blocks:\s*(.*)$", clean, re.IGNORECASE)
        if m_dep:
            payload = m_dep.group(1).strip()
            if payload and payload != "—":
                depends = [s.strip().strip("`") for s in DEP_LIST_RE.split(payload) if s.strip()]
        elif m_block:
            payload = m_block.group(1).strip()
            if payload and payload != "—":
                blocks = [s.strip().strip("`") for s in DEP_LIST_RE.split(payload) if s.strip()]
    return depends, blocks


def parse_references(items: list[str]) -> tuple[list[str], bool]:
    """Parse ``Spec refs:`` + ``Requires human intake approval`` markers."""
    spec_refs: list[str] = []
    requires_intake = False
    for raw in items:
        clean = raw.replace("**", "").strip()
        if "requires human intake approval" in clean.lower():
            requires_intake = "yes" in clean.lower()
            continue
        m_specs = re.match(r"Spec refs:\s*(.*)$", clean, re.IGNORECASE)
        if m_specs:
            payload = m_specs.group(1).strip()
            if payload and payload != "—":
                spec_refs = [
                    s.strip().strip("`")
                    for s in DEP_LIST_RE.split(payload)
                    if s.strip() and s.strip() != "—"
                ]
    return spec_refs, requires_intake


def parse_key_files(
    nodes: list[dict],
) -> tuple[list[str], list[str], str | None, list[str]]:
    """Parse the Key Files section's owns / reads / build-target sub-blocks."""
    owns: list[str] = []
    reads: list[str] = []
    build_target: str | None = None
    test_targets: list[str] = []

    bucket: list[str] | None = None
    for node in nodes:
        t = node.get("type")
        if t == "paragraph":
            text = adf_text(node).strip()
            if text.lower().startswith("**owns:**") or text.lower() == "owns:":
                bucket = owns
                continue
            if text.lower().startswith("**reads:**") or text.lower() == "reads:":
                bucket = reads
                continue
            m_target = re.search(r"Build target:\s*`?([^`\s]+)`?", text)
            if m_target:
                build_target = m_target.group(1)
                m_test = re.search(r"test:\s*`?([^`\)]+)`?", text)
                if m_test:
                    test_targets = [s.strip() for s in m_test.group(1).split(",") if s.strip()]
                bucket = None
                continue
        elif t == "bulletList" and bucket is not None:
            for li in node.get("content") or []:
                if li.get("type") == "listItem":
                    item = adf_text(li).strip()
                    if item and item != "—":
                        bucket.append(item)
    return owns, reads, build_target, test_targets


# ---------------------------------------------------------------------------
# Manifest builder
# ---------------------------------------------------------------------------


class ParseFailure(RuntimeError):  # noqa: N818  # source-script name preserved
    """Raised when a Jira issue cannot be reverse-engineered into a manifest."""


def build_manifest(
    issue: dict, cfg: ProductConfig, *, strict: bool
) -> tuple[str, dict[str, Any], list[str]]:
    """Convert a Jira issue payload into a canonical manifest dict.

    Returns ``(s_id, manifest, warnings)``. Raises :class:`ParseFailure`
    when the summary doesn't match the configured prefix or the parent
    isn't a configured epic.
    """
    fields = issue.get("fields") or {}
    summary = fields.get("summary", "")
    summary_re = re.compile(rf"^{re.escape(cfg.jira.summary_prefix)}\s+(\S+)\s+(.+)$")
    m = summary_re.match(summary)
    if not m:
        raise ParseFailure(
            f"summary does not match `{cfg.jira.summary_prefix} SX.Y title`: {summary!r}"
        )
    s_id, title = m.group(1), m.group(2).strip()

    parent_key = (fields.get("parent") or {}).get("key") or ""
    key_to_short = {v: k for k, v in cfg.jira.epics.items()}
    epic_short = key_to_short.get(parent_key)
    if not epic_short:
        raise ParseFailure(
            f"{s_id}: parent {parent_key!r} is not a configured epic in "
            f"docs/{cfg.id}/.docframework.yaml"
        )

    labels = fields.get("labels") or []
    phase: int | None = None
    priority: str | None = None
    requires_intake_label = "requires-human-intake" in labels
    for lab in labels:
        m_phase = re.match(r"^phase-(\d+)$", lab)
        if m_phase:
            phase = int(m_phase.group(1))
        m_pri = re.match(r"^priority-(P\d)$", lab)
        if m_pri:
            priority = m_pri.group(1)
    if priority is None:
        priority = PRIORITY_REVERSE.get(((fields.get("priority") or {}).get("name") or ""), "P2")
    if phase is None:
        phase = 1

    desc = fields.get("description") or {}
    sections = parse_sections(desc)

    warnings: list[str] = []

    acceptance = first_bullet_items(sections.get("Acceptance Criteria", []))
    if not acceptance:
        msg = f"{s_id}: Acceptance Criteria section empty or missing"
        if strict:
            raise ParseFailure(msg)
        warnings.append(msg)

    deps_items = first_bullet_items(sections.get("Dependencies", []))
    depends_on, blocks = parse_dependencies(deps_items)

    ref_items = first_bullet_items(sections.get("References", []))
    spec_refs, requires_intake = parse_references(ref_items)
    requires_intake = requires_intake or requires_intake_label

    owns, reads, build_target, test_targets = parse_key_files(sections.get("Key Files", []))

    epic_num = int(epic_short.split("-", 1)[1])
    tags = [f"e{epic_num:02d}"]

    canonical = {
        "Goal",
        "Phase / Priority",
        "Acceptance Criteria",
        "Key Files",
        "Dependencies",
        "Code Quality Gates",
        "Definition of Done",
        "References",
    }
    extra_sections: dict[str, str] = {}
    for name, nodes in sections.items():
        if name in canonical:
            continue
        block = section_to_text_block(nodes)
        if block:
            extra_sections[name] = block

    manifest: dict[str, Any] = {
        "id": s_id,
        "epic": epic_short,
        "title": title,
        "status": "NOT_STARTED",
        "phase": phase,
        "priority": priority,
        "spec_refs": spec_refs,
        "depends_on": depends_on,
        "blocks": blocks,
        "owns_paths": owns,
        "reads_paths": reads,
        "touches_shared": [],
        "build": {
            "target": build_target,
            "test_targets": test_targets,
            "cpu_budget": 4,
            "est_build_minutes": 4,
            "est_test_minutes": 1,
        },
        "acceptance": acceptance,
        "evidence_path": (f"docs/{cfg.id}/{cfg.paths.evidence_dir}/{s_id}.md"),
        "requires_human_review_before_merge": True,
        "requires_human_intake_approval": requires_intake,
        "experimental": False,
        "tags": tags,
        "claim": {
            "agent_id": None,
            "session_id": None,
            "started_at": None,
            "heartbeat_at": None,
        },
        "pr": {"number": None, "url": None, "opened_at": None, "state": None},
        "history": [],
    }
    if extra_sections:
        manifest["notes"] = extra_sections

    return s_id, manifest, warnings


def dump_manifest(manifest: dict) -> str:
    """Serialize a manifest dict to YAML via the local pure-Python codec."""
    return safe_dump(manifest)


# ---------------------------------------------------------------------------
# Result type + service
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ReverseSyncResult:
    """Aggregated reverse-sync outcome."""

    materialised: int
    skipped_existing: int
    warnings: list[str] = field(default_factory=list)
    failures: list[tuple[str, str]] = field(default_factory=list)
    written_paths: list[str] = field(default_factory=list)
    dry_run: bool = False


class ReverseSyncService:
    """Materialise YAML manifests from Jira stories that lack one on disk."""

    def __init__(
        self,
        cfg: ProductConfig,
        client: FrameworkJiraClient,
        *,
        log: Callable[[str], None] = print,
    ) -> None:
        self._cfg = cfg
        self._client = client
        self._log = log

    def reverse_sync(
        self,
        *,
        filter_epic: str | None = None,
        dry_run: bool = False,
        strict: bool = False,
    ) -> ReverseSyncResult:
        """Pull stories under the configured epic(s) and write missing manifests."""
        if filter_epic is not None:
            if filter_epic not in self._cfg.jira.epics:
                raise ValueError(f"unknown epic {filter_epic!r} for product {self._cfg.id}")
            epic_keys = [self._cfg.jira.epics[filter_epic]]
        else:
            epic_keys = sorted(self._cfg.jira.epics.values())

        parent_clause = ", ".join(epic_keys)
        jql = (
            f"project = {self._cfg.jira.project_key} "
            f"AND parent in ({parent_clause}) "
            f"AND issuetype = Story "
            f'AND labels = "{self._cfg.jira.label_namespace}"'
        )
        fields = ["summary", "description", "labels", "priority", "parent"]

        self._log(f"Querying Jira for {len(epic_keys)} epic(s)…")
        issues = self._client.search_jql_paged(jql, fields=fields)
        self._log(f"Returned {len(issues)} stories.")

        materialised = 0
        skipped_existing = 0
        warnings: list[str] = []
        failures: list[tuple[str, str]] = []
        written_paths: list[str] = []

        for issue in issues:
            try:
                s_id, manifest, warns = build_manifest(issue, self._cfg, strict=strict)
            except ParseFailure as exc:
                failures.append((issue.get("key", "?"), str(exc)))
                continue
            warnings.extend(warns)

            target = self._cfg.manifests_dir / f"{s_id}.yaml"
            if target.exists():
                skipped_existing += 1
                continue

            rel = _relative_to_cwd(target)
            if dry_run:
                self._log(
                    f"  [dry-run] would write {rel}  "
                    f"(epic={manifest['epic']} "
                    f"priority={manifest['priority']} "
                    f"phase={manifest['phase']} "
                    f"ac={len(manifest['acceptance'])} "
                    f"deps={len(manifest['depends_on'])})"
                )
                written_paths.append(str(target))
                continue

            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(dump_manifest(manifest), encoding="utf-8")
            materialised += 1
            written_paths.append(str(target))
            self._log(f"  + wrote {rel}")

        return ReverseSyncResult(
            materialised=materialised,
            skipped_existing=skipped_existing,
            warnings=warnings,
            failures=failures,
            written_paths=written_paths,
            dry_run=dry_run,
        )


def _relative_to_cwd(path: Path) -> str:
    try:
        return str(path.relative_to(Path.cwd()))
    except ValueError:
        return str(path)


__all__ = [
    "ParseFailure",
    "ReverseSyncResult",
    "ReverseSyncService",
    "adf_text",
    "adf_text_with_marks",
    "build_manifest",
    "dump_manifest",
    "first_bullet_items",
    "parse_dependencies",
    "parse_key_files",
    "parse_references",
    "parse_sections",
    "section_to_text_block",
]
