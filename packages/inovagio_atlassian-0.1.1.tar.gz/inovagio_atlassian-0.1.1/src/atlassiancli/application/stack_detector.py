"""Project stack detection from repo contents.

Walks a project root looking for marker files that pin its language
toolchain. Returns a :class:`ProjectStack` describing the primary language,
any secondary languages, detected frameworks, and the canonical toolchain
the SOP autogenerator should pin into the manifest.

This is a pure read-only scan — no I/O outside the project root, no
network. Detection rules are intentionally narrow: each language is
identified by a small fixed set of marker files (``pyproject.toml``,
``go.mod``, etc.). When two markers fire we list both languages, ranked
by source-file count; the primary is whichever produced the most files.

The detector is independent of :mod:`sop_autogen`: callers can inspect a
``ProjectStack`` and override the autogenerator's primary language pick
when they know better (e.g. a polyglot repo whose SOPs should follow the
backend language even if the frontend has more files).
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .data.language_profiles import LanguageProfile, get_profile

# ---------------------------------------------------------------------------
# Public dataclass
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ProjectStack:
    """A snapshot of one project's detected stack.

    ``primary_language`` is the language whose source-file count is highest
    among detected markers, with ties broken by the marker iteration order
    in :func:`detect_stack`. When no markers fire it is ``"unknown"``.
    ``languages`` lists every detected language including the primary, in
    descending source-count order.

    ``frameworks`` is best-effort: detected from dependency files (e.g.
    ``pyproject.toml`` mentioning ``fastapi``). Empty when the dependency
    file is absent or unreadable.
    """

    primary_language: str
    languages: tuple[str, ...]
    frameworks: tuple[str, ...]
    profile: LanguageProfile

    @property
    def is_unknown(self) -> bool:
        return self.primary_language == "unknown"


# ---------------------------------------------------------------------------
# Detection
# ---------------------------------------------------------------------------


# Order matters only for tie-breaking on equal source counts.
_MARKERS: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("python", ("pyproject.toml", "setup.py", "setup.cfg", "requirements.txt", "Pipfile")),
    ("typescript", ("tsconfig.json",)),
    ("javascript", ("package.json",)),
    ("go", ("go.mod",)),
    ("rust", ("Cargo.toml",)),
    ("cpp", ("CMakeLists.txt",)),
    ("java", ("pom.xml", "build.gradle", "build.gradle.kts")),
    ("kotlin", ("build.gradle.kts",)),
    ("csharp", ()),  # detected via *.csproj glob below
    ("ruby", ("Gemfile",)),
)


_SOURCE_EXTENSIONS: dict[str, tuple[str, ...]] = {
    "python": (".py",),
    "typescript": (".ts", ".tsx"),
    "javascript": (".js", ".jsx", ".mjs", ".cjs"),
    "go": (".go",),
    "rust": (".rs",),
    "cpp": (".cpp", ".cc", ".cxx", ".hpp", ".h", ".hh"),
    "java": (".java",),
    "kotlin": (".kt", ".kts"),
    "csharp": (".cs",),
    "ruby": (".rb",),
}


# Substring -> framework name. We scan the relevant dependency / config file
# as plain text rather than parse it; this keeps the detector free of pip
# dependencies and handles the long tail of dialects (TOML inline tables,
# package.json + dev deps, etc.) without per-format parsers.
_FRAMEWORK_SIGNALS: dict[str, tuple[tuple[str, str], ...]] = {
    "python": (
        ("fastapi", "fastapi"),
        ("django", "django"),
        ("flask", "flask"),
        ("pydantic", "pydantic"),
        ("sqlalchemy", "sqlalchemy"),
        ("starlette", "starlette"),
        ("celery", "celery"),
    ),
    "typescript": (
        ('"react"', "react"),
        ('"next"', "next.js"),
        ('"@nestjs/', "nestjs"),
        ('"express"', "express"),
        ('"vue"', "vue"),
        ('"svelte"', "svelte"),
    ),
    "javascript": (
        ('"react"', "react"),
        ('"express"', "express"),
        ('"vue"', "vue"),
    ),
    "go": (
        ("github.com/gin-gonic/gin", "gin"),
        ("github.com/labstack/echo", "echo"),
        ("github.com/go-chi/chi", "chi"),
        ("github.com/gofiber/fiber", "fiber"),
    ),
    "rust": (
        ("axum", "axum"),
        ("actix-web", "actix"),
        ("rocket", "rocket"),
        ("tokio", "tokio"),
    ),
    "java": (
        ("spring-boot", "spring-boot"),
        ("io.micronaut", "micronaut"),
        ("io.quarkus", "quarkus"),
    ),
    "kotlin": (
        ("spring-boot", "spring-boot"),
        ("ktor", "ktor"),
    ),
    "csharp": (
        ("Microsoft.AspNetCore", "aspnetcore"),
        ("Microsoft.EntityFrameworkCore", "ef-core"),
    ),
    "ruby": (
        ("'rails'", "rails"),
        ("'sinatra'", "sinatra"),
    ),
}


_FRAMEWORK_FILES: dict[str, tuple[str, ...]] = {
    "python": ("pyproject.toml", "requirements.txt", "Pipfile", "setup.py", "setup.cfg"),
    "typescript": ("package.json",),
    "javascript": ("package.json",),
    "go": ("go.mod", "go.sum"),
    "rust": ("Cargo.toml",),
    "java": ("pom.xml", "build.gradle", "build.gradle.kts"),
    "kotlin": ("build.gradle.kts", "build.gradle"),
    "csharp": (),  # csproj files are scanned via glob below
    "ruby": ("Gemfile", "Gemfile.lock"),
}


_IGNORED_DIRS = frozenset(
    {
        ".git",
        ".hg",
        ".svn",
        "node_modules",
        "vendor",
        "third_party",
        ".venv",
        "venv",
        "env",
        "build",
        "dist",
        "target",
        "out",
        ".tox",
        ".pytest_cache",
        ".mypy_cache",
        ".ruff_cache",
        "__pycache__",
        ".idea",
        ".vscode",
    }
)


def detect_stack(repo_root: Path) -> ProjectStack:
    """Inspect ``repo_root`` and return a :class:`ProjectStack`.

    Never raises on a normal directory tree. Unreadable files are silently
    skipped (we treat them as "no signal").
    """
    if not repo_root.is_dir():
        return _unknown()

    detected: dict[str, int] = {}
    for language, markers in _MARKERS:
        if any((repo_root / m).is_file() for m in markers):
            detected[language] = 0  # populated by source-count pass

    # csharp: detected via *.csproj glob (no fixed marker filename).
    if any(repo_root.rglob("*.csproj")):
        detected["csharp"] = 0

    # TypeScript implies JavaScript; demote JavaScript so a TS project isn't
    # listed as both.
    if "typescript" in detected and "javascript" in detected:
        del detected["javascript"]

    if not detected:
        return _unknown()

    for language in detected:
        detected[language] = _count_sources(repo_root, language)

    ranked = sorted(detected.items(), key=lambda kv: (-kv[1], kv[0]))
    languages = tuple(lang for lang, _ in ranked)
    primary = languages[0]

    frameworks = _detect_frameworks(repo_root, primary)

    return ProjectStack(
        primary_language=primary,
        languages=languages,
        frameworks=frameworks,
        profile=get_profile(primary),
    )


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------


def _unknown() -> ProjectStack:
    return ProjectStack(
        primary_language="unknown",
        languages=(),
        frameworks=(),
        profile=get_profile("unknown"),
    )


def _count_sources(root: Path, language: str) -> int:
    """Count source files for ``language`` under ``root``, skipping common
    vendored / generated directories."""
    extensions = _SOURCE_EXTENSIONS.get(language, ())
    if not extensions:
        return 0
    count = 0
    for path in _walk_sources(root):
        if path.suffix.lower() in extensions:
            count += 1
    return count


def _walk_sources(root: Path):
    """Yield every regular file under ``root``, skipping ignored dirs."""
    stack: list[Path] = [root]
    while stack:
        current = stack.pop()
        try:
            children = list(current.iterdir())
        except (PermissionError, OSError):
            continue
        for child in children:
            if child.is_symlink():
                continue
            name = child.name
            if name.startswith(".") and name not in {".github"} and child.is_dir():
                # Hidden directories are noise except a few well-known ones.
                continue
            if child.is_dir():
                if name in _IGNORED_DIRS:
                    continue
                stack.append(child)
            elif child.is_file():
                yield child


def _detect_frameworks(root: Path, language: str) -> tuple[str, ...]:
    """Return the framework names whose signals appear in the language's
    canonical dependency files."""
    signals = _FRAMEWORK_SIGNALS.get(language, ())
    if not signals:
        return ()
    files = _FRAMEWORK_FILES.get(language, ())
    haystack_parts: list[str] = []

    for filename in files:
        path = root / filename
        if path.is_file():
            haystack_parts.append(_safe_read(path))

    # csharp: gather every csproj file's text (small files, OK to slurp).
    if language == "csharp":
        for path in root.rglob("*.csproj"):
            haystack_parts.append(_safe_read(path))

    haystack = "\n".join(haystack_parts).lower()
    if not haystack:
        return ()

    found: list[str] = []
    seen: set[str] = set()
    for needle, name in signals:
        if needle.lower() in haystack and name not in seen:
            found.append(name)
            seen.add(name)
    return tuple(found)


def _safe_read(path: Path) -> str:
    """Read a text file, returning empty string on any I/O error."""
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""
