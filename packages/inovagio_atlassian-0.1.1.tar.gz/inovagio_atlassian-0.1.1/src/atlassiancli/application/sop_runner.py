"""SOP rule evaluation.

Two entry points:

- :func:`run_story_check` — given a manifest and a Jira story description,
  evaluate every ``phase: story`` (and ``phase: both``) rule. Each rule's
  ``required_section`` clause is checked against the description's heading
  set; ``regex`` clauses can also be evaluated against the description text.
- :func:`run_commit_gate` — given a manifest and a list of staged files
  (relative to the repo root), evaluate every ``phase: commit``
  (and ``phase: both``) rule. Regex rules grep through staged file content;
  shell rules execute the snippet via ``bash -c`` and trigger on non-zero exit.

Both return a list of :class:`SopFinding` objects; callers map findings
into :class:`AgentFinding` for the JSON envelope.
"""

from __future__ import annotations

import re
import subprocess
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

from .sop_manifest import SopManifest, SopRule

# ---------------------------------------------------------------------------
# Public types
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SopFinding:
    rule_id: str
    sop: str
    severity: str  # "blocking" | "warning" | "info"
    section: str | None
    message: str
    fix_hint: str
    where: str | None  # e.g. file path that triggered, or None for shell rules


# ---------------------------------------------------------------------------
# Story-time evaluator (Phase 2)
# ---------------------------------------------------------------------------


def run_story_check(
    manifest: SopManifest,
    *,
    description: str,
) -> list[SopFinding]:
    """Evaluate ``phase: story`` rules against a Jira story description.

    Returns a finding per rule whose ``required_section`` is missing.
    Regex / shell rules on the story phase are not executed here — they
    are reserved for the commit gate (rules can declare ``phase: both``
    if they should fire in both contexts, but the section-presence check
    is the only meaningful story-time evaluation).
    """
    findings: list[SopFinding] = []
    headings = _extract_headings(description)

    for rule in manifest.rules:
        if rule.phase not in ("story", "both"):
            continue
        section = rule.match.required_section
        if not section:
            continue
        if not _has_heading(headings, section):
            findings.append(
                SopFinding(
                    rule_id=rule.id,
                    sop=rule.sop,
                    severity=rule.severity,
                    section=section,
                    message=rule.on_violation.message,
                    fix_hint=rule.on_violation.fix_hint,
                    where=None,
                )
            )
    return findings


_HEADING_RE = re.compile(r"^\s*#{1,6}\s+(?P<title>.+?)\s*$", re.MULTILINE)


def _extract_headings(description: str) -> set[str]:
    """Return a normalised set of heading titles found in the description."""
    if not description:
        return set()
    headings = {m.group("title").strip() for m in _HEADING_RE.finditer(description)}
    return {h.lower() for h in headings}


def _has_heading(headings: set[str], required: str) -> bool:
    """Case-insensitive, anchored-to-word-boundary match. Allows the manifest
    to say ``Bounded Context`` and accept ``## Bounded Context`` or
    ``### Bounded Context — foo``."""
    needle = required.lower().strip()
    return any(
        h == needle
        or h.startswith(needle + " ")
        or h.startswith(needle + "—")
        or h.startswith(needle + "-")
        or h.startswith(needle + ":")
        for h in headings
    )


# ---------------------------------------------------------------------------
# Commit-time evaluator (Phase 6)
# ---------------------------------------------------------------------------


def run_commit_gate(
    manifest: SopManifest,
    *,
    staged_files: Iterable[str],
    repo_root: Path | None = None,
) -> list[SopFinding]:
    """Evaluate ``phase: commit`` rules against the staged diff.

    - Regex rules: read each staged file (filtered by ``paths`` /
      ``exclude_paths``) and search for the regex.
    - Shell rules: execute via ``bash -c`` from the repo root; a non-zero
      exit triggers the rule's ``on_violation``.

    ``required_section`` clauses are skipped here — they are story-only.
    """
    repo_root = repo_root or Path.cwd()
    staged = [s for s in staged_files if s.strip()]
    findings: list[SopFinding] = []

    for rule in manifest.rules:
        if rule.phase not in ("commit", "both"):
            continue
        match = rule.match
        if match.regex:
            findings.extend(_evaluate_regex(rule, staged, repo_root))
        elif match.shell:
            findings.extend(_evaluate_shell(rule, repo_root))
        # required_section rules are story-only; skip silently here.
    return findings


def _evaluate_regex(
    rule: SopRule,
    staged: list[str],
    repo_root: Path,
) -> list[SopFinding]:
    pattern = re.compile(rule.match.regex or "")
    paths = rule.match.paths or ("**/*",)
    excludes = rule.match.exclude_paths
    findings: list[SopFinding] = []

    for relpath in staged:
        if any(_path_matches(relpath, p) for p in excludes):
            continue
        if not any(_path_matches(relpath, p) for p in paths):
            continue
        full = repo_root / relpath
        try:
            text = full.read_text(encoding="utf-8", errors="ignore")
        except (OSError, UnicodeDecodeError):
            continue
        if pattern.search(text):
            findings.append(
                SopFinding(
                    rule_id=rule.id,
                    sop=rule.sop,
                    severity=rule.severity,
                    section=None,
                    message=rule.on_violation.message,
                    fix_hint=rule.on_violation.fix_hint,
                    where=relpath,
                )
            )
    return findings


def _evaluate_shell(rule: SopRule, repo_root: Path) -> list[SopFinding]:
    cmd = rule.match.shell or ""
    try:
        result = subprocess.run(
            ["bash", "-c", cmd],
            cwd=str(repo_root),
            capture_output=True,
            text=True,
            timeout=60,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError) as exc:
        return [
            SopFinding(
                rule_id=rule.id,
                sop=rule.sop,
                severity=rule.severity,
                section=None,
                message=f"shell rule failed to execute: {exc}",
                fix_hint=rule.on_violation.fix_hint,
                where=None,
            )
        ]
    if result.returncode == 0:
        return []
    return [
        SopFinding(
            rule_id=rule.id,
            sop=rule.sop,
            severity=rule.severity,
            section=None,
            message=rule.on_violation.message,
            fix_hint=rule.on_violation.fix_hint,
            where=None,
        )
    ]


def _path_matches(relpath: str, pattern: str) -> bool:
    """Glob match supporting ``**`` (recursive any-segment).

    Python's :mod:`fnmatch` treats ``*`` as "any except /", so ``**/*``
    misses top-level files. :class:`pathlib.PurePosixPath.match` honours
    ``**`` natively; we delegate to it and fall back to :mod:`fnmatch`
    for legacy patterns.
    """
    if pattern in ("**", "**/*"):
        return True
    try:
        if PurePosixPath(relpath).match(pattern):
            return True
    except (ValueError, NotImplementedError):
        pass
    if pattern.startswith("**/"):
        try:
            if PurePosixPath(relpath).match(pattern[3:]):
                return True
        except (ValueError, NotImplementedError):
            pass
    import fnmatch

    return fnmatch.fnmatch(relpath, pattern)


def staged_files_from_git(repo_root: Path | None = None) -> list[str]:
    """Return the list of staged file paths from ``git diff --cached``.

    Empty list when no staging area is set up or no files are staged.
    """
    cwd = str(repo_root) if repo_root else None
    try:
        result = subprocess.run(
            ["git", "diff", "--cached", "--name-only", "--diff-filter=ACMR"],
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=30,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return []
    if result.returncode != 0:
        return []
    return [line.strip() for line in result.stdout.splitlines() if line.strip()]
