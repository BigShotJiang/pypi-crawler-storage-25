"""Agent-callable adapter on top of the existing PR-3 handlers.

PR 3 shipped 24 ``CommandHandler`` classes that print human-readable text
to stdout and return integer exit codes. This module is the **adapter** that
wraps those handlers (and a handful of new composite ones) to:

1. Build a :class:`~atlassiancli.application.agent_response.AgentResponse`
   instead of (or alongside) the human print output, when the global
   ``--json`` flag is set.
2. Implement the new agent-specific subcommands documented in PLAN §6.2:
   ``analyse ready``, ``analyse fetch``, ``enhance``, ``template story|epic``,
   ``sprint current``, ``sprint stories``, ``comment``, ``link-pr``,
   ``assign``.

No PR-3 handler is modified — the human-readable code path remains the
default and is preserved byte-for-byte.
"""

from __future__ import annotations

import argparse
import time
from typing import Any

from ..application.agent_response import AgentFinding, AgentResponse
from ..application.dtos import PrepareStoryRequest, StandardizeStoryRequest
from ..domain.value_objects import IssueKey
from .composition_root import CompositionRoot

# ----------------------------------------------------------------------
# Threshold + helper constants — sourced from PLAN §6.2
# ----------------------------------------------------------------------

# Definition-of-Ready bar for ``analyse lint`` / ``analyse ready``.
LINT_READINESS_THRESHOLD = 80

# The 11-section AI-implementable schema names from PLAN §6.2.
REQUIRED_STORY_SECTIONS: tuple[str, ...] = (
    "Overview",
    "User Story",
    "Acceptance Criteria",
    "Technical Approach",
    "Architecture Notes",
    "Affected Modules",
    "Integration Points",
    "Testing Strategy",
    "Definition of Done",
    "Non-Functional Requirements",
    "Out of Scope",
)


# ----------------------------------------------------------------------
# Small helpers
# ----------------------------------------------------------------------


def _enum_value(value: Any) -> str | None:
    """Return the human-readable form of a domain enum.

    Domain enums (:class:`~atlassiancli.domain.value_objects.IssueType`,
    :class:`~atlassiancli.domain.value_objects.Priority`) carry a clean
    string in their ``.value`` (``"Story"`` / ``"Highest"``). Calling
    :func:`str` on them yields the Python repr (``"IssueType.STORY"``)
    which is useless to JSON consumers. Use this helper instead.
    """
    if value is None:
        return None
    if hasattr(value, "value"):
        return str(value.value)
    return str(value)


def _fetch_status(container: CompositionRoot, issue_key: str) -> str | None:
    """Return ``fields.status.name`` for the issue, or ``None`` on failure.

    The domain :class:`Issue` model deliberately doesn't carry workflow
    status (status is a Jira-side concept, not a domain concept), so we
    pull it via a lightweight direct API call. The call is best-effort:
    any error returns ``None`` rather than failing the whole fetch.
    """
    try:
        api = container.jira_client()
        response = api.get(
            f"/rest/api/3/issue/{issue_key}",
            params={"fields": "status"},
        )
        if response.status_code != 200:
            return None
        body = response.json()
        return body.get("fields", {}).get("status", {}).get("name")
    except Exception:  # best-effort — domain fetch already succeeded
        return None


# ----------------------------------------------------------------------
# Section-presence detector — used by ``analyse ready`` composite gate
# ----------------------------------------------------------------------


def detect_present_sections(description: str | None) -> list[str]:
    """Return the subset of :data:`REQUIRED_STORY_SECTIONS` present in text.

    Detection is permissive on purpose: matches either the wiki-markup
    (``h2.``) or markdown (``##``) form, case-insensitive, allowing the
    section name to differ in trailing punctuation.
    """
    if not description:
        return []
    found: list[str] = []
    lowered = description.lower()
    for section in REQUIRED_STORY_SECTIONS:
        needle = section.lower()
        # Either ``## <section>`` or ``h2. <section>``-style — both common
        # in Jira descriptions seeded from PR-3 enhancement.
        if (
            f"## {needle}" in lowered
            or f"h2. {needle}" in lowered
            or f"### {needle}" in lowered
            or f"h3. {needle}" in lowered
        ):
            found.append(section)
    return found


# ----------------------------------------------------------------------
# JSON adapters for existing analyse subcommands
# ----------------------------------------------------------------------


def lint_to_json(container: CompositionRoot, issue_key: str) -> AgentResponse:
    """Run lint via existing service and shape the result as AgentResponse."""
    started = time.monotonic()
    service = container.issue_analysis_service()
    result = service.lint_issue(IssueKey(issue_key))
    elapsed_ms = int((time.monotonic() - started) * 1000)

    if not (result.success and result.value):
        return AgentResponse.failure(
            command="analyse.lint",
            issue_key=issue_key,
            findings=[
                AgentFinding(
                    severity="critical",
                    rule="lint.fetch_failed",
                    section=None,
                    message=str(result.error or "Unknown lint failure"),
                    fix_hint=None,
                )
            ],
            metadata={"elapsed_ms": elapsed_ms},
        )

    data = result.value
    score = int(data.get("readiness_score", 0))
    findings: list[AgentFinding] = []
    issues = data.get("issues", [])
    suggestions = data.get("suggestions", []) + [None] * len(issues)
    for issue_text, fix in zip(issues, suggestions, strict=False):
        findings.append(
            AgentFinding(
                severity="major" if score < LINT_READINESS_THRESHOLD else "minor",
                rule="lint.section_missing",
                section=None,
                message=issue_text,
                fix_hint=fix,
            )
        )
    verdict = "PASS" if score >= LINT_READINESS_THRESHOLD else "FAIL"
    return AgentResponse.success(
        command="analyse.lint",
        issue_key=issue_key,
        verdict=verdict,
        score=score,
        threshold=LINT_READINESS_THRESHOLD,
        findings=findings,
        metadata={
            "elapsed_ms": elapsed_ms,
            "readiness_level": data.get("readiness_level"),
        },
    )


def atomicity_to_json(container: CompositionRoot, issue_key: str) -> AgentResponse:
    """Run atomicity analysis and shape as AgentResponse."""
    started = time.monotonic()
    service = container.issue_analysis_service()
    result = service.analyze_atomicity(IssueKey(issue_key))
    elapsed_ms = int((time.monotonic() - started) * 1000)

    if not (result.success and result.value):
        return AgentResponse.failure(
            command="analyse.atomicity",
            issue_key=issue_key,
            findings=[
                AgentFinding(
                    severity="critical",
                    rule="atomicity.fetch_failed",
                    section=None,
                    message=str(result.error or "Unknown atomicity failure"),
                    fix_hint=None,
                )
            ],
            metadata={"elapsed_ms": elapsed_ms},
        )

    data = result.value
    is_atomic = bool(data.get("is_atomic"))
    score = int(data.get("atomicity_score", 0))
    verdict = "PASS" if is_atomic else "FAIL"
    findings = [
        AgentFinding(
            severity="major" if not is_atomic else "info",
            rule="atomicity.issue",
            section=None,
            message=msg,
            fix_hint=None,
        )
        for msg in data.get("issues", [])
    ]
    for hint in data.get("split_suggestions", []):
        findings.append(
            AgentFinding(
                severity="info",
                rule="atomicity.split_suggestion",
                section=None,
                message=hint,
                fix_hint=hint,
            )
        )
    return AgentResponse.success(
        command="analyse.atomicity",
        issue_key=issue_key,
        verdict=verdict,
        score=score,
        threshold=70,  # IssueAnalysisService.analyze_atomicity treats score>=70 as atomic
        findings=findings,
        metadata={
            "elapsed_ms": elapsed_ms,
            "is_atomic": is_atomic,
            "estimated_days": data.get("estimated_days"),
            "should_split": data.get("should_split"),
        },
    )


def description_to_json(container: CompositionRoot, text: str) -> AgentResponse:
    """Run description-quality analysis and shape as AgentResponse."""
    service = container.issue_analysis_service()
    result = service.analyze_description_quality(text)
    if not (result.success and result.value):
        return AgentResponse.failure(
            command="analyse.description",
            findings=[
                AgentFinding(
                    severity="critical",
                    rule="description.analyze_failed",
                    section=None,
                    message=str(result.error or "Unknown failure"),
                    fix_hint=None,
                )
            ],
        )
    data = result.value
    score = float(data.get("score", 0.0))
    grade = data.get("grade", "F")
    verdict = "PASS" if grade in ("A", "B") else ("WARN" if grade == "C" else "FAIL")
    findings = [
        AgentFinding(
            severity="major",
            rule="description.issue",
            section=None,
            message=msg,
            fix_hint=None,
        )
        for msg in data.get("issues", [])
    ]
    return AgentResponse.success(
        command="analyse.description",
        verdict=verdict,
        score=round(score * 10),  # 0-100 normalised from 0-10 (round returns int)
        threshold=80,
        findings=findings,
        metadata={
            "grade": grade,
            "raw_score": score,
            "word_count": data.get("word_count"),
            "has_acceptance_criteria": data.get("has_acceptance_criteria"),
            "has_technical_details": data.get("has_technical_details"),
            "has_integration_points": data.get("has_integration_points"),
            "has_code_examples": data.get("has_code_examples"),
        },
    )


def architecture_to_json(container: CompositionRoot, issue_key: str) -> AgentResponse:
    """Run architecture review (always dry-run from agent path) and shape it."""
    started = time.monotonic()
    service = container.issue_analysis_service()
    result = service.analyze_architecture(IssueKey(issue_key), dry_run=True)
    elapsed_ms = int((time.monotonic() - started) * 1000)
    if not (result.success and result.value):
        return AgentResponse.failure(
            command="analyse.architecture",
            issue_key=issue_key,
            findings=[
                AgentFinding(
                    severity="critical",
                    rule="architecture.fetch_failed",
                    section=None,
                    message=str(result.error or "Unknown failure"),
                    fix_hint=None,
                )
            ],
            metadata={"elapsed_ms": elapsed_ms},
        )
    review = result.value
    findings = [
        AgentFinding(
            severity="major",
            rule="architecture.finding",
            section=None,
            message=msg,
            fix_hint=None,
        )
        for msg in review.findings
    ]
    for hint in review.suggestions:
        findings.append(
            AgentFinding(
                severity="info",
                rule="architecture.suggestion",
                section=None,
                message=hint,
                fix_hint=hint,
            )
        )
    verdict = "PASS" if review.score >= 80 else ("WARN" if review.score >= 60 else "FAIL")
    return AgentResponse.success(
        command="analyse.architecture",
        issue_key=issue_key,
        verdict=verdict,
        score=int(review.score),
        threshold=80,
        findings=findings,
        metadata={
            "elapsed_ms": elapsed_ms,
            "grade": review.grade,
            "has_arch_doc": review.has_arch_doc,
            "arch_doc_link": review.arch_doc_link,
            "missing_integrations": list(review.missing_integrations),
        },
    )


# ----------------------------------------------------------------------
# New subcommands: analyse ready / fetch
# ----------------------------------------------------------------------


def ready_to_json(container: CompositionRoot, issue_key: str) -> AgentResponse:
    """Composite Definition-of-Ready gate.

    Verdict is ``READY`` iff:
      1. lint score >= :data:`LINT_READINESS_THRESHOLD`
      2. atomicity verdict is ``PASS``
      3. all 11 :data:`REQUIRED_STORY_SECTIONS` present in the description
    Otherwise ``NOT_READY`` (exit 0 either way — the verdict is the signal).
    """
    started = time.monotonic()

    lint = lint_to_json(container, issue_key)
    atomic = atomicity_to_json(container, issue_key)

    # Fetch the description to test section completeness.
    issues_repo = container._issue_repo
    issue = issues_repo.find_by_key(IssueKey(issue_key))
    description: str | None = None
    if issue is not None:
        description = getattr(issue, "description", None)
    present = detect_present_sections(description)
    missing = [s for s in REQUIRED_STORY_SECTIONS if s not in present]

    findings: list[AgentFinding] = []
    findings.extend(lint.findings)
    findings.extend(atomic.findings)
    for section in missing:
        findings.append(
            AgentFinding(
                severity="major",
                rule="ready.section_missing",
                section=section,
                message=f"Required section '{section}' not present in description",
                fix_hint=f"Add a '## {section}' section",
            )
        )

    lint_pass = lint.verdict == "PASS"
    atomic_pass = atomic.verdict == "PASS"
    sections_pass = not missing

    verdict = "READY" if (lint_pass and atomic_pass and sections_pass) else "NOT_READY"

    elapsed_ms = int((time.monotonic() - started) * 1000)
    return AgentResponse(
        command="analyse.ready",
        issue_key=issue_key,
        verdict=verdict,
        score=lint.score,
        threshold=LINT_READINESS_THRESHOLD,
        findings=findings,
        metadata={
            "elapsed_ms": elapsed_ms,
            "lint_pass": lint_pass,
            "atomic_pass": atomic_pass,
            "sections_pass": sections_pass,
            "missing_sections": missing,
            "present_sections": present,
        },
    )


def fetch_to_json(container: CompositionRoot, issue_key: str) -> AgentResponse:
    """Return full structured story content (no scoring, no findings)."""
    started = time.monotonic()
    issues_repo = container._issue_repo
    issue = issues_repo.find_by_key(IssueKey(issue_key))
    elapsed_ms = int((time.monotonic() - started) * 1000)
    if issue is None:
        return AgentResponse.failure(
            command="analyse.fetch",
            issue_key=issue_key,
            findings=[
                AgentFinding(
                    severity="critical",
                    rule="fetch.not_found",
                    section=None,
                    message=f"Issue {issue_key} not found",
                    fix_hint=None,
                )
            ],
            metadata={"elapsed_ms": elapsed_ms},
        )

    payload: dict[str, Any] = {
        "issue_key": issue_key,
        "title": getattr(issue, "title", None),
        "description": getattr(issue, "description", None),
        "issue_type": _enum_value(getattr(issue, "issue_type", None)),
        "status": _fetch_status(container, issue_key),
        "priority": _enum_value(getattr(issue, "priority", None)),
    }
    # Story-only attributes (use getattr fall-throughs so Epics/Tasks don't
    # explode the JSON shape).
    for attr in (
        "acceptance_criteria",
        "affected_modules",
        "integration_points",
        "themes",
        "story_points",
    ):
        value = getattr(issue, attr, None)
        if value is None:
            payload[attr] = None
        elif hasattr(value, "value"):
            payload[attr] = value.value
        elif isinstance(value, (list, tuple, set, frozenset)):
            items = [v.value if hasattr(v, "value") else str(v) for v in value]
            if isinstance(value, (set, frozenset)):
                items.sort()
            payload[attr] = items
        else:
            payload[attr] = value

    return AgentResponse(
        command="analyse.fetch",
        issue_key=issue_key,
        verdict=None,
        score=None,
        threshold=None,
        findings=[],
        metadata={"elapsed_ms": elapsed_ms, "story": payload},
    )


# ----------------------------------------------------------------------
# enhance — dry-run / --apply
# ----------------------------------------------------------------------


def enhance_to_json(container: CompositionRoot, issue_key: str, *, apply: bool) -> AgentResponse:
    """Generate proposed enhancement; optionally write back to Jira."""
    started = time.monotonic()
    prepare = container.prepare_story_service()
    standardize = container.standardize_story_service()

    # Dry-run: compose the technical specification from PrepareStoryService
    # without writing it back. ``update=False`` keeps the call read-only.
    prep_result = prepare.prepare_story(
        PrepareStoryRequest(issue_key=issue_key, update=False, format_type="ai")
    )

    if not (prep_result.success and prep_result.value):
        return AgentResponse.failure(
            command="enhance",
            issue_key=issue_key,
            findings=[
                AgentFinding(
                    severity="critical",
                    rule="enhance.fetch_failed",
                    section=None,
                    message=str(prep_result.error or "Unknown failure"),
                    fix_hint=None,
                )
            ],
            metadata={"elapsed_ms": int((time.monotonic() - started) * 1000)},
        )

    proposed = prep_result.value.specification

    applied = False
    standardize_summary: dict[str, Any] = {}
    if apply:
        # Apply: standardize first (title cleanup) then write proposed
        # description through the issue repository's update method. We
        # call the service with ``execute=True`` so any title fixes land,
        # then push the description directly via the repo.
        std_result = standardize.standardize_story(
            StandardizeStoryRequest(issue_key=issue_key, execute=True)
        )
        if std_result.success and std_result.value:
            standardize_summary = {
                "standardized": list(std_result.value.standardized),
                "skipped": list(std_result.value.skipped),
                "failed": list(std_result.value.failed),
            }
        # Push the enhanced description.
        issues_repo = container._issue_repo
        story = issues_repo.find_by_key(IssueKey(issue_key))
        if story is not None and hasattr(story, "update_description"):
            story.update_description(proposed)
            issues_repo.update(story)
            applied = True

    elapsed_ms = int((time.monotonic() - started) * 1000)
    return AgentResponse(
        command="enhance",
        issue_key=issue_key,
        verdict="PASS",
        score=None,
        threshold=None,
        findings=[],
        metadata={
            "elapsed_ms": elapsed_ms,
            "apply": apply,
            "applied": applied,
            "proposed_description": proposed,
            "standardize": standardize_summary,
        },
    )


# ----------------------------------------------------------------------
# template story / template epic — pure markdown emission
# ----------------------------------------------------------------------

# The 11-section AI-implementable story skeleton matches PLAN §6.2.
STORY_TEMPLATE_MARKDOWN = """# <Story Title>

## Overview
<One-paragraph summary of what this story delivers and why.>

## User Story
As a <role>, I want <capability>, so that <business value>.

## Acceptance Criteria
- GIVEN <context> WHEN <action> THEN <observable outcome>
- GIVEN <context> WHEN <action> THEN <observable outcome>
- GIVEN <context> WHEN <action> THEN <observable outcome>

## Technical Approach
<Concrete implementation strategy: classes, modules, key algorithms.>

## Architecture Notes
<DDD layer placement, bounded context, dependencies on other layers.>

## Affected Modules
- <module/path/one>
- <module/path/two>

## Integration Points
- <upstream / downstream system, contract, format>

## Testing Strategy
- Unit tests covering <X>
- Integration tests covering <Y>
- Coverage target: >85%

## Definition of Done
- [ ] Code merged to main
- [ ] Tests pass in CI
- [ ] Documentation updated
- [ ] Code review approved

## Non-Functional Requirements
- Performance: <target>
- Security: <controls>
- Observability: <logs/metrics/traces>

## Out of Scope
- <explicitly NOT included in this story>
"""

EPIC_TEMPLATE_MARKDOWN = """# <Epic Title>

## Objective
<Business outcome this epic delivers.>

## KPIs
- <quantifiable success metric one>
- <quantifiable success metric two>

## In Scope
- <capability one>
- <capability two>

## Out of Scope
- <explicitly NOT included>

## Architecture Documentation
<Confluence link to the architecture page for this epic.>

## Stories
- <child story key + title>
- <child story key + title>

## Themes
- <theme one>
- <theme two>
"""


def template_to_json(kind: str) -> AgentResponse:
    """Emit the story or epic markdown template inside an AgentResponse."""
    if kind == "story":
        body = STORY_TEMPLATE_MARKDOWN
        command = "template.story"
    elif kind == "epic":
        body = EPIC_TEMPLATE_MARKDOWN
        command = "template.epic"
    else:
        return AgentResponse.failure(
            command="template",
            findings=[
                AgentFinding(
                    severity="critical",
                    rule="template.invalid_kind",
                    section=None,
                    message=f"Unknown template kind: {kind}",
                    fix_hint="Use 'story' or 'epic'",
                )
            ],
        )
    return AgentResponse(
        command=command,
        verdict="PASS",
        score=None,
        threshold=None,
        findings=[],
        metadata={"template": body, "section_count": REQUIRED_STORY_SECTIONS_COUNT(kind)},
    )


def REQUIRED_STORY_SECTIONS_COUNT(kind: str) -> int:  # noqa: N802
    """Section count helper used by ``template_to_json``."""
    return len(REQUIRED_STORY_SECTIONS) if kind == "story" else 0


def template_to_text(kind: str) -> str:
    """Return the raw markdown template for the human-readable code path."""
    if kind == "story":
        return STORY_TEMPLATE_MARKDOWN
    if kind == "epic":
        return EPIC_TEMPLATE_MARKDOWN
    raise ValueError(f"Unknown template kind: {kind}")


# ----------------------------------------------------------------------
# sprint current / sprint stories
# ----------------------------------------------------------------------


def sprint_current_to_json(container: CompositionRoot, board_id: int | None) -> AgentResponse:
    """Find the active sprint for a board via the Jira agile API."""
    started = time.monotonic()
    api = container.jira_client()
    bid = board_id or container._config.board_id
    response = api.get(f"/rest/agile/1.0/board/{bid}/sprint", params={"state": "active"})
    elapsed_ms = int((time.monotonic() - started) * 1000)
    if response.status_code != 200:
        return AgentResponse.failure(
            command="sprint.current",
            findings=[
                AgentFinding(
                    severity="critical",
                    rule="sprint.fetch_failed",
                    section=None,
                    message=f"Active-sprint lookup failed: HTTP {response.status_code}",
                    fix_hint=None,
                )
            ],
            metadata={"elapsed_ms": elapsed_ms, "board_id": bid},
        )
    payload = response.json()
    values = payload.get("values", []) if isinstance(payload, dict) else []
    if not values:
        return AgentResponse(
            command="sprint.current",
            issue_key=None,
            verdict="WARN",
            score=None,
            threshold=None,
            findings=[
                AgentFinding(
                    severity="info",
                    rule="sprint.no_active",
                    section=None,
                    message=f"No active sprint on board {bid}",
                    fix_hint=None,
                )
            ],
            metadata={"elapsed_ms": elapsed_ms, "board_id": bid},
        )
    sprint = values[0]
    return AgentResponse(
        command="sprint.current",
        issue_key=None,
        verdict="PASS",
        score=None,
        threshold=None,
        findings=[],
        metadata={
            "elapsed_ms": elapsed_ms,
            "board_id": bid,
            "sprint_id": str(sprint.get("id", "")),
            "sprint_name": sprint.get("name"),
            "state": sprint.get("state"),
            "start_date": sprint.get("startDate"),
            "end_date": sprint.get("endDate"),
        },
    )


_PRIORITY_RANK: dict[str, int] = {
    "highest": 0,
    "high": 1,
    "medium": 2,
    "low": 3,
    "lowest": 4,
}


def sprint_stories_to_json(
    container: CompositionRoot,
    sprint_id: int,
    *,
    unassigned: bool,
    priority_order: bool,
) -> AgentResponse:
    """List stories on a sprint, optionally filtered to unassigned + sorted."""
    started = time.monotonic()
    issues_repo = container._issue_repo
    from ..domain.value_objects import SprintIdentifier

    issues = issues_repo.find_by_sprint(SprintIdentifier(sprint_id))

    rows: list[dict[str, Any]] = []
    for issue in issues:
        assignee = getattr(issue, "assignee", None) or getattr(issue, "assignee_email", None)
        if unassigned and assignee:
            continue
        rows.append(
            {
                "key": issue.key.key if getattr(issue, "key", None) else None,
                "summary": getattr(issue, "title", None),
                "status": str(getattr(issue, "status", "")),
                "priority": str(getattr(issue, "priority", "medium")),
                "assignee": assignee,
                "story_points": (
                    issue.story_points.value if getattr(issue, "story_points", None) else None
                ),
            }
        )

    if priority_order:
        rows.sort(key=lambda r: _PRIORITY_RANK.get(str(r.get("priority", "")).lower(), 99))

    elapsed_ms = int((time.monotonic() - started) * 1000)
    return AgentResponse(
        command="sprint.stories",
        issue_key=None,
        verdict="PASS",
        score=None,
        threshold=None,
        findings=[],
        metadata={
            "elapsed_ms": elapsed_ms,
            "sprint_id": str(sprint_id),
            "stories": rows,
            "story_count": len(rows),
            "filter_unassigned": unassigned,
            "priority_order": priority_order,
        },
    )


# ----------------------------------------------------------------------
# Idempotent write helpers: comment / link-pr / assign
# ----------------------------------------------------------------------


def comment_to_json(
    container: CompositionRoot,
    issue_key: str,
    body: str,
    *,
    idempotency_key: str | None,
) -> AgentResponse:
    """Post a comment, optionally skipping when ``idempotency_key`` already present.

    The marker is appended to the comment body in a footer line so that
    subsequent runs scanning existing comments can detect prior posts.
    """
    api = container.jira_client()

    # Idempotency check: list existing comments and skip if any contains
    # the marker.
    if idempotency_key:
        marker = f"[idempotency-key: {idempotency_key}]"
        existing = api.get(f"/rest/api/3/issue/{issue_key}/comment")
        if existing.status_code == 200:
            existing_payload = existing.json() or {}
            for c in existing_payload.get("comments", []):
                if marker in _comment_text(c):
                    return AgentResponse(
                        command="comment",
                        issue_key=issue_key,
                        verdict="PASS",
                        score=None,
                        threshold=None,
                        findings=[],
                        metadata={
                            "skipped": True,
                            "reason": "idempotency_key_already_present",
                            "idempotency_key": idempotency_key,
                            "comment_id": str(c.get("id", "")) or None,
                        },
                    )
        body = f"{body}\n\n{marker}"

    payload = {
        "body": {
            "type": "doc",
            "version": 1,
            "content": [
                {
                    "type": "paragraph",
                    "content": [{"type": "text", "text": body}],
                }
            ],
        }
    }
    response = api.post(f"/rest/api/3/issue/{issue_key}/comment", payload)
    if response.status_code not in (200, 201):
        return AgentResponse.failure(
            command="comment",
            issue_key=issue_key,
            findings=[
                AgentFinding(
                    severity="critical",
                    rule="comment.post_failed",
                    section=None,
                    message=f"Comment POST failed: HTTP {response.status_code}",
                    fix_hint=None,
                )
            ],
        )
    # Capture the new comment's id from the POST response so callers can
    # round-trip it (audit logs, metric attribution, deletion, etc.). Jira
    # returns the full comment object on 201; ``id`` is a string at the top
    # level. We tolerate any response shape — comment_id stays None if the
    # server returns something unexpected.
    new_id: str | None = None
    try:
        new_id = str(response.json().get("id", "")) or None
    except (ValueError, TypeError, AttributeError):
        new_id = None
    return AgentResponse(
        command="comment",
        issue_key=issue_key,
        verdict="PASS",
        score=None,
        threshold=None,
        findings=[],
        metadata={
            "skipped": False,
            "idempotency_key": idempotency_key,
            "comment_id": new_id,
        },
    )


def _comment_text(comment_obj: Any) -> str:
    """Extract a flat text snapshot from a Jira ADF / plain comment body."""
    body = comment_obj.get("body") if isinstance(comment_obj, dict) else None
    if isinstance(body, str):
        return body
    if isinstance(body, dict):
        # ADF: walk the tree and concatenate any 'text' leaves.
        out: list[str] = []

        def walk(node: Any) -> None:
            if isinstance(node, dict):
                if node.get("type") == "text" and isinstance(node.get("text"), str):
                    out.append(node["text"])
                for child in node.get("content", []) or []:
                    walk(child)
            elif isinstance(node, list):
                for child in node:
                    walk(child)

        walk(body)
        return "\n".join(out)
    return ""


def link_pr_to_json(container: CompositionRoot, issue_key: str, pr_url: str) -> AgentResponse:
    """Add a remote-issue-link to ``pr_url``; idempotent on URL match."""
    api = container.jira_client()

    existing_links = api.get(f"/rest/api/3/issue/{issue_key}/remotelink")
    if existing_links.status_code == 200:
        for link in existing_links.json() or []:
            url = (link.get("object") or {}).get("url") if isinstance(link, dict) else None
            if url == pr_url:
                return AgentResponse(
                    command="link-pr",
                    issue_key=issue_key,
                    verdict="PASS",
                    score=None,
                    threshold=None,
                    findings=[],
                    metadata={
                        "skipped": True,
                        "reason": "pr_url_already_linked",
                        "pr_url": pr_url,
                    },
                )

    payload = {
        "object": {
            "url": pr_url,
            "title": f"PR: {pr_url.rsplit('/', 1)[-1]}",
            "icon": {"url16x16": "https://github.com/favicon.ico"},
        }
    }
    response = api.post(f"/rest/api/3/issue/{issue_key}/remotelink", payload)
    if response.status_code not in (200, 201):
        return AgentResponse.failure(
            command="link-pr",
            issue_key=issue_key,
            findings=[
                AgentFinding(
                    severity="critical",
                    rule="link_pr.post_failed",
                    section=None,
                    message=f"Remote-link POST failed: HTTP {response.status_code}",
                    fix_hint=None,
                )
            ],
        )
    return AgentResponse(
        command="link-pr",
        issue_key=issue_key,
        verdict="PASS",
        score=None,
        threshold=None,
        findings=[],
        metadata={"skipped": False, "pr_url": pr_url},
    )


def assign_to_json(container: CompositionRoot, issue_key: str, user_email: str) -> AgentResponse:
    """Assign issue to the named user; PUT is idempotent at the Jira API."""
    api = container.jira_client()
    # Resolve email -> accountId.
    lookup = api.get("/rest/api/3/user/search", params={"query": user_email})
    if lookup.status_code != 200:
        return AgentResponse.failure(
            command="assign",
            issue_key=issue_key,
            findings=[
                AgentFinding(
                    severity="critical",
                    rule="assign.user_lookup_failed",
                    section=None,
                    message=f"User lookup failed: HTTP {lookup.status_code}",
                    fix_hint=None,
                )
            ],
        )
    users = lookup.json() or []
    if not users:
        return AgentResponse.failure(
            command="assign",
            issue_key=issue_key,
            findings=[
                AgentFinding(
                    severity="critical",
                    rule="assign.user_not_found",
                    section=None,
                    message=f"No user matching {user_email}",
                    fix_hint=None,
                )
            ],
        )
    account_id = users[0].get("accountId")
    response = api.put(f"/rest/api/3/issue/{issue_key}/assignee", {"accountId": account_id})
    if response.status_code not in (200, 204):
        return AgentResponse.failure(
            command="assign",
            issue_key=issue_key,
            findings=[
                AgentFinding(
                    severity="critical",
                    rule="assign.put_failed",
                    section=None,
                    message=f"Assignee PUT failed: HTTP {response.status_code}",
                    fix_hint=None,
                )
            ],
        )
    return AgentResponse(
        command="assign",
        issue_key=issue_key,
        verdict="PASS",
        score=None,
        threshold=None,
        findings=[],
        metadata={"assignee_email": user_email, "account_id": account_id},
    )


# ----------------------------------------------------------------------
# Dispatch entry-point — called by cli/main.py when --json is set
# ----------------------------------------------------------------------


def dispatch_json(container: CompositionRoot, args: argparse.Namespace) -> AgentResponse:
    """Route an argparse Namespace to the right JSON-emitting helper.

    Returns an :class:`AgentResponse` for every supported command. Raises
    ``ValueError`` if the command isn't a member of the agent contract —
    the dispatcher in :mod:`cli.main` falls back to the human-readable
    handler in that case (so unknown commands still render a useful
    error).
    """
    cmd = args.command
    if cmd in ("analyse", "analyze"):
        sub = getattr(args, "analyze_type", None)
        if sub == "lint":
            return lint_to_json(container, args.issue_key)
        if sub == "atomicity":
            return atomicity_to_json(container, args.issue_key)
        if sub == "description":
            return description_to_json(container, args.text)
        if sub == "architecture":
            return architecture_to_json(container, args.issue_key)
        if sub == "ready":
            return ready_to_json(container, args.issue_key)
        if sub == "fetch":
            return fetch_to_json(container, args.issue_key)
        if sub == "sop":
            from .sop_adapter import sop_story_check_to_json

            return sop_story_check_to_json(
                container,
                args.issue_key,
                manifest_path=getattr(args, "sop_manifest", None),
            )
        raise ValueError(f"Unknown analyse subcommand: {sub}")
    if cmd == "enhance":
        # When dispatched via --json, prefer the simplified agent surface
        # using args.issue_key and args.apply_agent / args.dry_run flags.
        apply = bool(getattr(args, "apply_agent", False))
        return enhance_to_json(container, args.issue_key, apply=apply)
    if cmd == "template":
        kind = getattr(args, "template_kind", None) or "story"
        return template_to_json(kind)
    if cmd == "sprint":
        action = getattr(args, "sprint_action", None)
        if action == "current":
            return sprint_current_to_json(container, getattr(args, "board_id", None))
        if action == "stories":
            return sprint_stories_to_json(
                container,
                args.sprint_id,
                unassigned=bool(getattr(args, "unassigned", False)),
                priority_order=bool(getattr(args, "priority_order", False)),
            )
        raise ValueError(f"Unknown sprint action: {action}")
    if cmd == "comment":
        return comment_to_json(
            container,
            args.issue_key,
            args.body,
            idempotency_key=getattr(args, "idempotency_key", None),
        )
    if cmd == "link-pr":
        return link_pr_to_json(container, args.issue_key, args.pr_url)
    if cmd == "assign":
        return assign_to_json(container, args.issue_key, args.user)
    if cmd == "review":
        from .review_handler import review_to_json

        return review_to_json(
            container,
            args.issue_key,
            manifest_path=getattr(args, "sop_manifest", None),
            skip_sop=bool(getattr(args, "skip_sop", False)),
            skip_architecture=bool(getattr(args, "skip_architecture", False)),
        )
    if cmd == "transition":
        # ``transition`` defaults to dry-run; ``--execute`` is required to
        # actually fire the workflow change. The dispatch_json path
        # previously ignored args.execute and always called
        # repo.transition(), which silently mutated Jira state on what
        # operators expected to be a dry-run. Honor the flag here.
        repo = container._issue_repo
        transitions = repo.get_available_transitions(IssueKey(args.issue_key))
        target = (args.transition_name or "").lower()
        match = next(
            (t for t in transitions if str(t.get("name", "")).lower() == target),
            None,
        )
        if match is None:
            return AgentResponse.failure(
                command="transition",
                issue_key=args.issue_key,
                findings=[
                    AgentFinding(
                        severity="major",
                        rule="transition.unknown_target",
                        section=None,
                        message=(
                            f"No transition named '{args.transition_name}' "
                            f"available on {args.issue_key}"
                        ),
                        fix_hint=(
                            "Available: " + ", ".join(str(t.get("name", "")) for t in transitions)
                        ),
                    )
                ],
            )

        execute = bool(getattr(args, "execute", False))
        applied = False
        ok = True
        if execute:
            ok = repo.transition(IssueKey(args.issue_key), str(match.get("id", "")))
            applied = bool(ok)

        return AgentResponse(
            command="transition",
            issue_key=args.issue_key,
            verdict="PASS" if ok else "FAIL",
            score=None,
            threshold=None,
            findings=[],
            metadata={
                "transition_name": args.transition_name,
                "transition_id": match.get("id"),
                "applied": applied,
                "dry_run": not execute,
            },
        )
    raise ValueError(f"Command not in agent contract: {cmd}")
