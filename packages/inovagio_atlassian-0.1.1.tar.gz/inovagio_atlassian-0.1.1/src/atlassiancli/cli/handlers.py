#!/usr/bin/env python3
"""
CLI Command Handlers

Adapts CLI arguments to application service calls.
Handles presentation logic (output formatting, error display).

Author: Inovagio Engineering Team
"""

import traceback
from typing import Any, Optional

from ..application.dtos import (
    BalanceCapacityRequest,
    BatchSplitRequest,
    ContextInfoRequest,
    CreateDocsRequest,
    CreateEpicRequest,
    CreateStoryRequest,
    CreateTaskRequest,
    DeleteIssueRequest,
    EnhanceIssueRequest,
    EnhanceSprintRequest,
    GenerateSprintGoalsRequest,
    GenerateTemplateRequest,
    HealthReportRequest,
    PrepareStoryRequest,
    RemoveLabelRequest,
    StandardizeStoryRequest,
    TransitionIssueRequest,
)
from ..application.expert_enhancement_service import ExpertEnhancementService
from ..application.services import (
    AutomationService,
    BalanceCapacityService,
    ContextInfoService,
    DashboardService,
    DocumentSyncService,
    HealthReportService,
    ImportService,
    IssueAnalysisService,
    IssueCreationService,
    IssueDeletionService,
    IssueEnhancementService,
    IssueTransitionService,
    LabelRemovalService,
    PrepareStoryService,
    ReportingService,
    SprintGoalsService,
    SprintManagementService,
    StandardizeStoryService,
    StorySplittingService,
    TemplateGenerationService,
    VerificationService,
)
from ..domain.value_objects import ConfluencePageId, IssueKey
from ..infrastructure.confluence_client import ConfluencePageRepository
from ..infrastructure.jira_client import JiraApiClient, JiraApiError


class CreateCommandHandler:
    """Handles 'create' commands (epic, story, task, version)"""

    def __init__(
        self,
        service: IssueCreationService,
        jira_client: Optional["JiraApiClient"] = None,
    ):
        self._service = service
        self._jira_client = jira_client

    def handle_create_epic(
        self,
        title: str,
        description: str,
        objective: str,
        kpis: list[str],
        in_scope: list[str],
        out_of_scope: list[str],
        architecture_link: str | None,
        themes: list[str],
        priority: str,
    ) -> int:
        """
        Handle CLI 'create epic' command.

        Returns: Exit code (0 = success, 1 = error)
        """
        request = CreateEpicRequest(
            title=title,
            description=description,
            objective=objective,
            kpis=kpis,
            in_scope=in_scope,
            out_of_scope=out_of_scope,
            architecture_link=architecture_link,
            themes=themes,
            priority=priority,
        )

        result = self._service.create_epic(request)

        if result.success and result.value:
            response = result.value
            print(f"✅ Epic created: {response.issue_key}")
            print(f"🔗 URL: {response.url}")

            if response.warnings:
                print("\n⚠️  Warnings:")
                for warning in response.warnings:
                    print(f"  - {warning}")

            return 0
        elif not result.success:
            print(f"❌ Failed to create epic: {result.error}")
            for error in result.errors:
                print(f"  - {error}")
            return 1
        else:
            print("❌ Failed to create epic: No response data received")
            return 1

    def handle_create_story(
        self,
        title: str,
        description: str,
        epic_key: str | None,
        story_points: int | None,
        sprint_number: int | None,
        acceptance_criteria: list[str],
        affected_modules: list[str],
        integration_points: list[str],
        themes: list[str],
        priority: str,
    ) -> int:
        """Handle CLI 'create story' command"""
        request = CreateStoryRequest(
            title=title,
            description=description,
            epic_key=epic_key,
            story_points=story_points,
            sprint_number=sprint_number,
            acceptance_criteria=acceptance_criteria,
            affected_modules=affected_modules,
            integration_points=integration_points,
            themes=themes,
            priority=priority,
        )

        result = self._service.create_story(request)

        if result.success and result.value:
            response = result.value
            print(f"✅ Story created: {response.issue_key}")
            print(f"🔗 URL: {response.url}")

            if response.warnings:
                print("\n⚠️  Warnings:")
                for warning in response.warnings:
                    print(f"  - {warning}")

            return 0
        elif not result.success:
            print(f"❌ Failed to create story: {result.error}")
            for error in result.errors:
                print(f"  - {error}")
            return 1
        else:
            print("❌ Failed to create story: No response data received")
            return 1

    def handle_create_task(
        self,
        title: str,
        description: str,
        parent_story_key: str,
        implementation_steps: list[str],
        estimated_hours: float | None,
        priority: str,
    ) -> int:
        """Handle CLI 'create task' command"""
        request = CreateTaskRequest(
            title=title,
            description=description,
            parent_story_key=parent_story_key,
            implementation_steps=implementation_steps,
            estimated_hours=int(estimated_hours) if estimated_hours is not None else None,
            priority=priority,
        )

        result = self._service.create_task(request)

        if result.success and result.value:
            response = result.value
            print(f"✅ Task created: {response.issue_key}")
            print(f"🔗 URL: {response.url}")

            if response.warnings:
                print("\n⚠️  Warnings:")
                for warning in response.warnings:
                    print(f"  - {warning}")

            return 0
        elif not result.success:
            print(f"❌ Failed to create task: {result.error}")
            for error in result.errors:
                print(f"  - {error}")
            return 1
        else:
            print("❌ Failed to create task: No response data received")
            return 1

    def handle_create_version(
        self,
        name: str,
        description: str,
        project_id: str,
        start_date: str | None = None,
        release_date: str | None = None,
        released: bool = False,
        archived: bool = False,
    ) -> int:
        """Handle CLI 'create version' command"""
        if not self._jira_client:
            print("❌ Jira API client not available")
            return 1

        payload: dict[str, Any] = {
            "name": name,
            "description": description,
            "projectId": int(project_id),
            "archived": archived,
            "released": released,
        }
        if start_date:
            payload["startDate"] = start_date
        if release_date:
            payload["releaseDate"] = release_date

        try:
            result = self._jira_client.create_version(payload)
            version_id = result.get("id", "unknown")
            version_name = result.get("name", name)
            self_url = result.get("self", "")
            print(f"✅ Version created: {version_name} (id={version_id})")
            if self_url:
                print(f"🔗 URL: {self_url}")
            return 0
        except JiraApiError as e:
            print(f"❌ Failed to create version: {e}")
            return 1

    def handle_list_versions(self, project_key: str) -> int:
        """Handle CLI 'list versions' for a project"""
        if not self._jira_client:
            print("❌ Jira API client not available")
            return 1

        try:
            versions = self._jira_client.list_versions(project_key)
            if not versions:
                print(f"No versions found for project {project_key}")
                return 0
            print(f"Versions for {project_key}:")
            for v in versions:
                status = "Released" if v.get("released") else "Unreleased"
                archived = " (Archived)" if v.get("archived") else ""
                dates = ""
                if v.get("startDate"):
                    dates += f" start={v['startDate']}"
                if v.get("releaseDate"):
                    dates += f" release={v['releaseDate']}"
                print(f"  {v['name']} (id={v['id']}) — {status}{archived}{dates}")
            return 0
        except JiraApiError as e:
            print(f"❌ Failed to list versions: {e}")
            return 1


class EnhanceCommandHandler:
    """Handles 'enhance' command"""

    def __init__(self, service: IssueEnhancementService):
        self._service = service

    def handle_enhance(self, issue_key: str) -> int:
        """Handle CLI 'enhance' command for single issue"""
        request = EnhanceIssueRequest(issue_key=issue_key)

        result = self._service.enhance_issue(request)

        if result.success and result.value:
            response = result.value
            print(f"✅ Enhanced: {response.issue_key}")
            print(f"📊 AI Readiness: {response.previous_readiness} → {response.new_readiness}")

            if response.changes_made:
                print("\n✏️  Changes:")
                for change in response.changes_made:
                    print(f"  - {change}")

            # Display architecture analysis if available
            if response.architecture_review:
                arch = response.architecture_review
                print("\n" + "=" * 60)
                print("🏗️  ARCHITECTURE ANALYSIS")
                print("=" * 60)
                print(f"📊 Grade: {arch.grade} ({arch.score}/100)")
                print(f"📄 Arch Doc: {'✅ Linked' if arch.has_arch_doc else '❌ Missing'}")
                if arch.arch_doc_link:
                    print(f"🔗 Link: {arch.arch_doc_link}")

                if arch.findings:
                    print("\n📝 Findings:")
                    for finding in arch.findings:
                        print(f"  - {finding}")

                if arch.suggestions:
                    print("\n💡 Suggestions:")
                    for suggestion in arch.suggestions:
                        print(f"  - {suggestion}")

                # Show proposed changes preview
                if arch.proposed_acceptance_criteria or arch.proposed_nfr_section:
                    print("\n📋 Proposed Architecture Requirements:")
                    print("   (Use 'analyze architecture --real-run' to apply these)")

                    if arch.proposed_acceptance_criteria:
                        print(
                            f"\n   ✏️  Would add {len(arch.proposed_acceptance_criteria)} Acceptance Criteria:"
                        )
                        for i, criterion in enumerate(arch.proposed_acceptance_criteria, 1):
                            # Show first 100 chars of each criterion
                            preview = criterion[:100] + "..." if len(criterion) > 100 else criterion
                            print(f"      {i}. {preview}")

                    if arch.proposed_nfr_section:
                        nfr_lines = arch.proposed_nfr_section.split("\n")
                        print(f"\n   ✏️  Would add NFR section ({len(nfr_lines)} lines)")

            return 0
        elif not result.success:
            print(f"❌ Failed to enhance: {result.error}")
            for error in result.errors:
                print(f"  - {error}")
            return 1
        else:
            print("❌ Failed to enhance: No response data received")
            return 1

    def handle_enhance_sprint(
        self,
        sprint_number: int,
        execute: bool = False,
        force: bool = False,
        with_docs: bool = False,
    ) -> int:
        """Handle CLI 'enhance --sprint' command for batch enhancement"""
        request = EnhanceSprintRequest(
            sprint_number=sprint_number,
            execute=execute,
            force=force,
            with_docs=with_docs,
        )

        result = self._service.enhance_sprint(request)

        if result.success and result.value:
            response = result.value
            print(f"✅ Sprint {response.sprint_number} Enhancement Complete")
            print(f"📊 Enhanced: {len(response.enhanced)}")
            print(f"⏭️  Skipped: {len(response.skipped)}")
            print(f"❌ Failed: {len(response.failed)}")
            print(f"✏️  Total Changes: {response.total_changes}")

            if not execute:
                print("\n⚠️  DRY RUN - Use --execute to apply changes")

            if response.enhanced:
                print("\n✅ Enhanced Issues:")
                for key in response.enhanced[:10]:  # Show first 10
                    print(f"  - {key}")
                if len(response.enhanced) > 10:
                    print(f"  ... and {len(response.enhanced) - 10} more")

            return 0
        elif not result.success:
            print(f"❌ Failed to enhance sprint: {result.error}")
            for error in result.errors:
                print(f"  - {error}")
            return 1
        else:
            print("❌ Failed to enhance sprint: No response data received")
            return 1


class DocsCommandHandler:
    """Handles 'docs' command"""

    def __init__(self, service: DocumentSyncService):
        self._service = service

    def handle_create_docs(
        self,
        issue_key: str,
        include_spec: bool,
        include_testplan: bool,
        include_runbook: bool,
        analyze_only: bool = False,
        execute: bool = False,
    ) -> int:
        """Handle CLI 'docs' command"""
        request = CreateDocsRequest(
            issue_key=issue_key,
            include_spec=include_spec,
            include_test_plan=include_testplan,
            include_runbook=include_runbook,
            analyze_only=analyze_only,
            execute=execute,
        )

        if analyze_only:
            print(f"🔍 Analyzing documentation needs for {issue_key}")
            print("📋 Recommended documentation:")
            if include_spec or not (include_spec or include_testplan or include_runbook):
                print("  ✅ Story Specification")
            if include_testplan or not (include_spec or include_testplan or include_runbook):
                print("  ✅ Test Plan")
            if include_runbook:
                print("  ✅ Runbook")
            print("\n💡 Use without --analyze to create pages")
            return 0

        result = self._service.create_docs(request)

        if result.success and result.value:
            response = result.value
            print(f"✅ Documentation created for: {response.issue_key}")
            print(f"📄 Pages created: {len(response.pages)}")
            print(f"🔗 Remote links added: {response.links_added}")

            if not execute:
                print("\n⚠️  DRY RUN - Use --execute to create pages")

            for page in response.pages:
                status_icon = "✅" if page.status == "created" else "ℹ️"
                print(f"  {status_icon} {page.page_type}: {page.page_url or page.page_id}")

            return 0
        elif not result.success:
            print(f"❌ Failed to create docs: {result.error}")
            for error in result.errors:
                print(f"  - {error}")
            return 1
        else:
            print("❌ Failed to create docs: No response data received")
            return 1


class SprintCommandHandler:
    """Handles sprint management commands"""

    def __init__(self, service: SprintManagementService):
        self._service = service

    def handle_move_to_sprint(
        self,
        sprint_number: int,
        issue_keys: list[str],
    ) -> int:
        """Handle CLI 'move' command"""
        result = self._service.move_issues_to_sprint(sprint_number, issue_keys)

        if result.success and result.value is not None:
            moved = result.value
            print(f"✅ Moved {len(moved)} issues to Sprint {sprint_number}")
            for key in moved:
                print(f"  - {key}")
            return 0
        elif not result.success:
            print(f"❌ Failed to move issues: {result.error}")
            for error in result.errors:
                print(f"  - {error}")
            return 1
        else:
            print("❌ Failed to move issues: No response data received")
            return 1


class AnalysisCommandHandler:
    """Handles analysis commands"""

    def __init__(self, service: IssueAnalysisService):
        self._service = service

    def handle_lint(self, issue_key: str) -> int:
        """Handle CLI 'lint' command"""
        try:
            key = IssueKey(issue_key)
        except ValueError as e:
            print(f"❌ Invalid issue key: {e}")
            return 1

        result = self._service.lint_issue(key)

        if result.success and result.value:
            data = result.value
            print(f"🔍 Lint Results: {data['issue_key']}")
            print(f"📊 AI Readiness: {data['readiness_level']} ({data['readiness_score']}/100)")

            if data["issues"]:
                print("\n⚠️  Issues Found:")
                for issue in data["issues"]:
                    print(f"  - {issue}")

            if data["suggestions"]:
                print("\n💡 Suggestions:")
                for suggestion in data["suggestions"]:
                    print(f"  - {suggestion}")

            return 0
        elif not result.success:
            print(f"❌ Failed to lint: {result.error}")
            for error in result.errors:
                print(f"  - {error}")
            return 1
        else:
            print("❌ Failed to lint: No response data received")
            return 1

    def handle_analyze_description(self, description: str) -> int:
        """Handle CLI 'analyze-description' command"""
        result = self._service.analyze_description_quality(description)

        if result.success and result.value:
            data = result.value
            print(f"📊 Description Quality: {data['grade']} ({data['score']:.1f}/10)")
            print(f"📝 Word Count: {data['word_count']}")
            print(f"✅ Has Acceptance Criteria: {data['has_acceptance_criteria']}")
            print(f"🔧 Has Technical Details: {data['has_technical_details']}")
            print(f"🔗 Has Integration Points: {data['has_integration_points']}")
            print(f"💻 Has Code Examples: {data['has_code_examples']}")

            if data["issues"]:
                print("\n⚠️  Issues:")
                for issue in data["issues"]:
                    print(f"  - {issue}")

            return 0
        elif not result.success:
            print(f"❌ Failed to analyze: {result.error}")
            return 1
        else:
            print("❌ Failed to analyze: No response data received")
            return 1

    def handle_analyze_atomicity(self, issue_key: str) -> int:
        """Handle CLI 'analyze-atomicity' command"""
        try:
            key = IssueKey(issue_key)
        except ValueError as e:
            print(f"❌ Invalid issue key: {e}")
            return 1

        result = self._service.analyze_atomicity(key)

        if result.success and result.value:
            data = result.value
            print(f"🔍 Atomicity Analysis: {data['issue_key']}")
            print(f"📊 Score: {data['atomicity_score']}/100")
            print(f"⚛️  Is Atomic: {data['is_atomic']}")
            print(f"📅 Estimated Days: {data['estimated_days']}")
            print(f"✂️  Should Split: {data['should_split']}")

            if data["issues"]:
                print("\n⚠️  Issues:")
                for issue in data["issues"]:
                    print(f"  - {issue}")

            if data["split_suggestions"]:
                print("\n💡 Split Suggestions:")
                for suggestion in data["split_suggestions"]:
                    print(f"  - {suggestion}")

            return 0
        elif not result.success:
            print(f"❌ Failed to analyze: {result.error}")
            for error in result.errors:
                print(f"  - {error}")
            return 1
        else:
            print("❌ Failed to analyze: No response data received")
            return 1

    def handle_architecture_review(self, issue_key: str, dry_run: bool = True) -> int:
        """Handle CLI 'analyze architecture' command

        Args:
            issue_key: The Jira issue key to review
            dry_run: If True (default), read-only analysis. If False, can modify issue.
        """
        try:
            key = IssueKey(issue_key)
        except ValueError as e:
            print(f"❌ Invalid issue key: {e}")
            return 1

        result = self._service.analyze_architecture(key, dry_run=dry_run)

        if result.success and result.value:
            data = result.value
            mode = "🔍 DRY RUN" if dry_run else "✍️  REAL RUN"
            print(f"{mode} - Architecture Review: {data.issue_key}")
            print(f"📊 Grade: {data.grade} ({data.score}/100)")
            print(f"📄 Arch Doc: {'✅ Linked' if data.has_arch_doc else '❌ Missing'}")
            if data.arch_doc_link:
                print(f"🔗 Link: {data.arch_doc_link}")

            if data.findings:
                print("\n📝 Findings:")
                for finding in data.findings:
                    print(f"  - {finding}")

            if data.suggestions:
                print("\n💡 Suggestions:")
                for suggestion in data.suggestions:
                    print(f"  - {suggestion}")

            if dry_run:
                # Show what WOULD be updated
                if data.proposed_acceptance_criteria or data.proposed_nfr_section:
                    print("\n📋 Proposed Updates (preview - use --real-run to apply):")

                    if data.proposed_acceptance_criteria:
                        print(
                            f"\n  ✏️  Would add {len(data.proposed_acceptance_criteria)} Acceptance Criteria:"
                        )
                        for i, criterion in enumerate(data.proposed_acceptance_criteria, 1):
                            print(f"\n  {i}. {criterion}")

                    if data.proposed_nfr_section:
                        print("\n  ✏️  Would add Non-Functional Requirements section:")
                        for line in data.proposed_nfr_section.split("\n"):
                            print(f"     {line}")

                    print("\n✓ No changes made (dry-run mode)")
                else:
                    print("\n✓ No updates needed - story meets architecture standards")
            else:
                # Show what was updated
                critical_missing = [
                    i for i in data.missing_integrations if i in ["Guard", "Sentinel", "Logging"]
                ]
                if critical_missing:
                    print("\n✅ Story updated with requirements:")
                    print(
                        f"   • Added {len(critical_missing)} acceptance criteria for: {', '.join(critical_missing)}"
                    )
                    print("   • Added non-functional requirements section")
            for error in result.errors:
                print(f"  - {error}")
            return 1
        else:
            print("❌ Failed to review architecture: No response data received")
            return 1


class EnhancementCommandHandler:
    """Handles enhancement commands"""

    def __init__(self, service):
        self._service = service

    def handle_enhance_template(self, issue_key: str, context: str, dry_run: bool = True) -> int:
        """Handle 'enhance template' command"""
        result = self._service.enhance_with_template(IssueKey(issue_key), context)

        if result.success and result.value:
            data = result.value
            print(f"✅ Enhanced {issue_key} with {context} template")
            print(f"📋 AC Count: {len(data['acceptance_criteria'])}")
            if not dry_run:
                print("✓ Changes applied")
            else:
                print("🔍 DRY RUN - No changes made")
            return 0
        elif not result.success:
            print(f"❌ Enhancement failed: {result.error}")
            return 1
        else:
            print("❌ Enhancement failed: No response data received")
            return 1

    def handle_enhance_metadata(
        self, issue_key: str, themes: list[str], dry_run: bool = True
    ) -> int:
        """Handle 'enhance metadata' command"""
        result = self._service.enhance_metadata(IssueKey(issue_key), themes)

        if result.success and result.value:
            data = result.value
            print(f"✅ Enhanced metadata for {issue_key}")
            print(f"🏷️  Labels: {', '.join(data['labels'])}")
            print(f"📦 Components: {', '.join(data['components'])}")
            print(f"⚡ Priority: {data['priority']}")
            if not dry_run:
                print("✓ Changes applied")
            else:
                print("🔍 DRY RUN - No changes made")
            return 0
        elif not result.success:
            print(f"❌ Enhancement failed: {result.error}")
            return 1
        else:
            print("❌ Enhancement failed: No response data received")
            return 1


class SplittingCommandHandler:
    """Handles story splitting commands"""

    def __init__(
        self,
        service: StorySplittingService,
        story_splitting_service: StorySplittingService,
    ):
        self._service = service
        self._story_splitting_service = story_splitting_service

    def handle_split(self, issue_key: str, context: str, dry_run: bool = True) -> int:
        """Handle 'split' command"""
        result = self._service.split_story(IssueKey(issue_key), context)

        if result.success and result.value:
            data = result.value
            print(f"✅ Split plan for {data['parent_key']}")
            print(f"📊 Subtasks: {data['subtask_count']}")
            for i, subtask in enumerate(data["subtasks"], 1):
                print(f"\n{i}. {subtask['summary']}")
                print(f"   {subtask['description'][:100]}...")
            if not dry_run:
                print("\n✓ Subtasks created")
            else:
                print("\n🔍 DRY RUN - No subtasks created")
            return 0
        elif not result.success:
            print(f"❌ Split failed: {result.error}")
            return 1
        else:
            print("❌ Split failed: No response data received")
            return 1

    def handle_batch_split(self, project_key: str, context: str, dry_run: bool = True) -> int:
        """Handle 'split batch' command"""

        request = BatchSplitRequest(issue_keys=[project_key], execute=not dry_run, context=context)

        result = self._story_splitting_service.batch_split(request)

        if result.success and result.value:
            response = result.value
            print(f"✅ Batch split completed for project {project_key}")
            print(f"📊 Total subtasks created: {response.total_subtasks}")
            print(f"✓ Successful splits: {len(response.split)}")
            print(f"✗ Failed splits: {len(response.failed)}")

            if response.split:
                print("\n✨ Split issues:")
                for key in response.split:
                    print(f"  - {key}")

            if response.failed:
                print("\n❌ Failed issues:")
                for key in response.failed:
                    print(f"  - {key}")

            if dry_run:
                print("\n🔍 DRY RUN - No subtasks created")
            return 0
        elif not result.success:
            print(f"❌ Batch split failed: {result.error}")
            return 1
        else:
            print("❌ Batch split failed: No response data received")
            return 1


class OperationsCommandHandler:
    """Handles sprint operations commands"""

    def __init__(self, service):
        self._service = service

    def handle_rebalance(
        self,
        start_sprint: int,
        end_sprint: int,
        target_sp: int = 65,
        dry_run: bool = True,
    ) -> int:
        """Handle 'rebalance' command"""
        result = self._service.rebalance_sprints((start_sprint, end_sprint), target_sp)

        if result.success and result.value:
            data = result.value
            print("✅ Rebalance Analysis")
            print(f"📊 Moves Recommended: {data['moves_recommended']}")
            if not dry_run:
                print("✓ Moves executed")
            else:
                print("🔍 DRY RUN - No moves made")
            return 0
        elif not result.success:
            print(f"❌ Rebalance failed: {result.error}")
            return 1
        else:
            print("❌ Rebalance failed: No response data received")
            return 1

    def handle_reorganize(self, start_sprint: int, end_sprint: int, dry_run: bool = True) -> int:
        """Handle 'reorganize' command"""
        result = self._service.reorganize_by_theme((start_sprint, end_sprint))

        if result.success and result.value:
            data = result.value
            print("✅ Reorganization Plan")
            print(f"📊 Reorganizations: {data['reorganizations']}")
            if not dry_run:
                print("✓ Reorganization complete")
            else:
                print("🔍 DRY RUN - No changes made")
            return 0
        elif not result.success:
            print(f"❌ Reorganization failed: {result.error}")
            return 1
        else:
            print("❌ Reorganization failed: No response data received")
            return 1

    def handle_sprint_goals(self, sprint_number: int) -> int:
        """Handle 'sprint-goals' command"""
        result = self._service.generate_sprint_goals(sprint_number)

        if result.success and result.value:
            data = result.value
            print(f"🎯 Sprint {sprint_number} Goals")
            print(f"\n📌 Primary: {data['primary_goal']}")
            print("\n📋 Secondary:")
            for goal in data["secondary_goals"]:
                print(f"  - {goal}")
            print("\n✅ Success Criteria:")
            for criterion in data["success_criteria"]:
                print(f"  - {criterion}")
            return 0
        elif not result.success:
            print(f"❌ Goal generation failed: {result.error}")
            return 1
        else:
            print("❌ Goal generation failed: No response data received")
            return 1


class AutomationCommandHandler:
    """Handles automation commands"""

    def __init__(self, service: AutomationService):
        self._service = service

    def handle_auto_analyze(self, sprint_number: int, min_grade: str = "C") -> int:
        """Handle 'auto analyze' command"""
        result = self._service.auto_analyze_sprint(sprint_number)

        if result.success and result.value:
            data = result.value
            print(f"🤖 Auto Analysis Complete (Min Grade: {min_grade})")
            print(f"📊 Analyzed: {data['analyzed']}")
            print(f"✅ Passed: {data['passed']}")
            print(f"❌ Failed: {data['failed']}")
            return 0
        elif not result.success:
            print(f"❌ Auto analysis failed: {result.error}")
            return 1
        else:
            print("❌ Auto analysis failed: No response data received")
            return 1

    def handle_auto_enhance_issue(self, issue_key: str) -> int:
        """Handle 'auto enhance' for single issue"""
        print(f"\n🤖 Auto Enhancing {issue_key}")
        print("   Force: True | Architecture: True | Metadata: True")
        print("   Using: ExpertEnhancementService\n")

        result = self._service.auto_enhance_issue(issue_key)

        if result.success and result.value:
            data = result.value
            print(f"✅ Enhanced: {data['issue_key']}")
            print(f"📊 AI Readiness: {data['previous_readiness']} → {data['new_readiness']}")

            if data.get("changes_made"):
                print("\n✏️  Changes:")
                for change in data["changes_made"]:
                    print(f"  - {change}")

            # Show architecture review if available
            arch = data.get("architecture_review")
            if arch:
                print(f"\n🏗️  Architecture: {arch.grade} ({arch.score}/100)")
                if hasattr(arch, "has_arch_doc") and not arch.has_arch_doc:
                    print("   ⚠️  Missing architecture documentation")

            return 0
        elif not result.success:
            print(f"❌ Auto enhancement failed: {result.error}")
            return 1
        else:
            print("❌ Auto enhancement failed: No response data received")
            return 1

    def handle_auto_enhance_sprint(
        self, sprint_number: int, readiness_filter: str = "PARTIALLY_READY"
    ) -> int:
        """Handle 'auto enhance' for sprint batch"""
        print(f"\n🤖 Auto Enhancing Sprint {sprint_number}")
        print(f"   Readiness Filter: {readiness_filter}")
        print("   Using: ExpertEnhancementService (architecture + metadata)\n")

        result = self._service.auto_enhance_sprint(sprint_number, readiness_filter)

        if result.success and result.value:
            data = result.value
            print("🤖 Auto Enhancement Complete")
            print(f"✅ Enhanced: {data['enhanced']}")
            print(f"⏭️  Skipped: {data['skipped']}")
            print(f"❌ Failed: {data['failed']}")
            if data.get("total_changes"):
                print(f"✏️  Total Changes: {data['total_changes']}")

            # Show enhanced issue keys
            if data.get("enhanced_keys"):
                print("\n✅ Enhanced Issues:")
                for key in data["enhanced_keys"]:
                    print(f"  - {key}")

            # Show failed issue keys
            if data.get("failed_keys"):
                print("\n❌ Failed Issues:")
                for key in data["failed_keys"]:
                    print(f"  - {key}")

            return 0
        elif not result.success:
            print(f"❌ Auto enhancement failed: {result.error}")
            return 1
        else:
            print("❌ Auto enhancement failed: No response data received")
            return 1

    def handle_auto_split(self, sprint_number: int, max_sp: int = 8) -> int:
        """Handle 'auto split' command"""
        result = self._service.auto_split_sprint(sprint_number, max_sp)

        if result.success and result.value:
            data = result.value
            print("🤖 Auto Split Complete")
            print(f"✂️  Stories Split: {data['split']}")
            print(f"📋 Subtasks Created: {data['subtasks_created']}")
            print(f"⏭️  Skipped: {data['skipped']}")
            return 0
        elif not result.success:
            print(f"❌ Auto split failed: {result.error}")
            return 1
        else:
            print("❌ Auto split failed: No response data received")
            return 1


class ReportingCommandHandler:
    """Handles reporting commands"""

    def __init__(self, service: ReportingService, health_report_service: HealthReportService):
        self._service = service
        self._health_report_service = health_report_service

    def handle_quality_report(
        self, start_sprint: int, end_sprint: int, output_format: str = "text"
    ) -> int:
        """Handle 'report quality' command"""
        result = self._service.generate_quality_report((start_sprint, end_sprint))

        if result.success and result.value:
            data = result.value
            print(
                f"📊 Quality Report (Sprints {start_sprint}-{end_sprint}, Format: {output_format})"
            )
            print(f"📈 Avg Description Quality: {data['avg_description_quality']:.1f}")
            print(f"⚛️  Avg Atomicity: {data['avg_atomicity']:.1f}")
            print(f"🧪 Avg Testability: {data['avg_testability']:.1f}")
            return 0
        elif not result.success:
            print(f"❌ Report generation failed: {result.error}")
            return 1
        else:
            print("❌ Report generation failed: No response data received")
            return 1

    def handle_velocity_report(self, start_sprint: int, end_sprint: int) -> int:
        """Handle 'report velocity' command"""
        result = self._service.generate_velocity_report((start_sprint, end_sprint))

        if result.success and result.value:
            data = result.value
            print("📊 Velocity Report")
            print(f"⚡ Avg Velocity: {data['avg_velocity']:.1f} SP")
            print(f"✅ Completion Rate: {data['completion_rate']:.1f}%")
            print(f"📈 Trend: {data['trend']}")
            return 0
        elif not result.success:
            print(f"❌ Report generation failed: {result.error}")
            return 1
        else:
            print("❌ Report generation failed: No response data received")
            return 1

    def handle_themes_report(self, start_sprint: int, end_sprint: int) -> int:
        """Handle 'report themes' command"""
        result = self._service.generate_themes_report((start_sprint, end_sprint))

        if result.success and result.value:
            data = result.value
            print("📊 Themes Report")
            print(f"🏆 Most Common: {data['most_common']}")
            print("\n📋 Distribution:")
            for theme, count in data.get("distribution", []):
                print(f"  {theme}: {count}")
            return 0
        elif not result.success:
            print(f"❌ Report generation failed: {result.error}")
            return 1
        else:
            print("❌ Report generation failed: No response data received")
            return 1

    def handle_health_report(self, project_key: str) -> int:
        """Handle 'report health' command"""

        # Health report now requires sprint range, using defaults for project-wide
        request = HealthReportRequest(start_sprint=1, end_sprint=100)
        result = self._health_report_service.generate_health_report(request)

        if result.success and result.value:
            response = result.value
            print(f"📊 Project Health Report: {project_key}\n")
            print(f"Overall Score: {response.overall_score:.2%}")
            print(f"  Quality: {response.quality_score:.2%}")
            print(f"  Velocity: {response.velocity_score:.2%}")
            print(f"  Theme Alignment: {response.theme_alignment_score:.2%}")

            if response.warnings:
                print("\n⚠️  Warnings:")
                for warning in response.warnings:
                    print(f"  - {warning}")

            if response.recommendations:
                print("\n💡 Recommendations:")
                for rec in response.recommendations:
                    print(f"  - {rec}")
            return 0
        elif not result.success:
            print(f"❌ Health report failed: {result.error}")
            return 1
        else:
            print("❌ Health report failed: No response data received")
            return 1


class DashboardCommandHandler:
    """Handles dashboard provisioning commands."""

    def __init__(self, service: DashboardService):
        self._service = service

    def handle_launch_dashboard(
        self,
        project_key: str | None,
        dashboard_name: str | None,
        execute: bool,
        share_global: bool,
    ) -> int:
        """Create launch burndown filters and a dashboard."""
        result = self._service.create_launch_dashboard(
            project_key=project_key,
            dashboard_name=dashboard_name,
            execute=execute,
            share_global=share_global,
        )

        if not result.success:
            print(f"❌ Dashboard provisioning failed: {result.error}")
            for error in result.errors:
                print(f"  - {error}")
            return 1

        if not result.value:
            print("❌ Dashboard provisioning failed: No response data received")
            return 1

        data = result.value
        if data.get("dry_run", False):
            print("🔍 DRY RUN - Launch dashboard plan")
            print(f"📌 Project: {data['project_key']}")
            print(f"📊 Dashboard Name: {data['dashboard_name']}")
            print("\nFilters to create:")
            for filter_spec in data.get("filters", []):
                print(f"  • {filter_spec['name']}")
                print(f"    JQL: {filter_spec['jql']}")
            print("\n💡 Use --execute to create filters and dashboard in Jira")
            return 0

        dashboard = data.get("dashboard", {})
        filters = data.get("filters", [])
        dashboard_name_value = dashboard.get("name") or "(unnamed)"
        dashboard_url = dashboard.get("view") or dashboard.get("viewUrl") or ""
        dashboard_id = dashboard.get("id")

        print("✅ Launch dashboard created")
        print(f"📌 Project: {data.get('project_key')}")
        print(f"📊 Dashboard: {dashboard_name_value} (ID: {dashboard_id})")
        if dashboard_url:
            print(f"🔗 Dashboard URL: {dashboard_url}")

        if filters:
            print("\nSaved Filters:")
            for item in filters:
                filter_name = item.get("name", "Unnamed Filter")
                filter_id = item.get("id", "?")
                filter_url = item.get("viewUrl", "")
                print(f"  • {filter_name} (ID: {filter_id})")
                if filter_url:
                    print(f"    {filter_url}")

        return 0


class VerificationCommandHandler:
    """Handles verification commands"""

    def __init__(self, service: VerificationService):
        self._service = service

    def handle_verify_sprint(self, sprint_number: int) -> int:
        """Handle 'verify sprint' command"""
        result = self._service.verify_sprint(sprint_number)

        if result.success and result.value:
            data = result.value
            status = "✅ READY" if data["is_ready"] else "❌ NOT READY"
            print(f"🔍 Sprint {sprint_number} Verification: {status}")
            if data["issues_found"]:
                print("\n❌ Issues:")
                for issue in data["issues_found"]:
                    print(f"  - {issue}")
            if data["warnings"]:
                print("\n⚠️  Warnings:")
                for warning in data["warnings"]:
                    print(f"  - {warning}")
            return 0 if data["is_ready"] else 1
        elif not result.success:
            print(f"❌ Verification failed: {result.error}")
            return 1
        else:
            print("❌ Verification failed: No response data received")
            return 1

    def handle_verify_themes(self, sprint_number: int) -> int:
        """Handle 'verify themes' command"""
        result = self._service.verify_themes(sprint_number)

        if result.success and result.value:
            data = result.value
            status = "✅ CONSISTENT" if data["themes_consistent"] else "❌ INCONSISTENT"
            print(f"🔍 Theme Verification: {status}")
            if data["unlabeled_issues"]:
                print(f"\n⚠️  Unlabeled Issues: {len(data['unlabeled_issues'])}")
                for key in data["unlabeled_issues"][:10]:
                    print(f"  - {key}")
            if data["label_mismatches"]:
                print(f"\n❌ Label Mismatches: {len(data['label_mismatches'])}")
            return 0 if data["themes_consistent"] else 1
        elif not result.success:
            print(f"❌ Verification failed: {result.error}")
            return 1
        else:
            print("❌ Verification failed: No response data received")
            return 1

    def handle_verify_stories(
        self,
        sprint_number: int,
        min_words: int = 80,
        require_confluence_link: bool = True,
    ) -> int:
        """Handle 'verify stories' command."""
        result = self._service.verify_stories(
            sprint_number=sprint_number,
            min_words=min_words,
            require_confluence_link=require_confluence_link,
        )

        if result.success and result.value:
            data = result.value
            status = "✅ READY" if data["is_ready"] else "❌ NEEDS UPDATES"
            print(
                f"🔎 Sprint {sprint_number} Story Audit: {status} "
                f"({data['checked']}/{data['story_count']} stories checked)"
            )

            for story in data.get("stories", []):
                clarity = "✅" if story.get("clarity_ok") else "❌"
                docs = "✅" if story.get("has_confluence_reference") else "❌"
                print(
                    f"  {story.get('key')}: clarity {clarity}, confluence {docs}, "
                    f"words={story.get('word_count')}"
                )

                desc_links = story.get("description_confluence_links", [])
                remote_links = story.get("remote_confluence_links", [])

                if desc_links:
                    print("    • Description Confluence links:")
                    for link in desc_links:
                        print(f"      - {link}")

                if remote_links:
                    print("    • Remote Confluence links:")
                    for link in remote_links:
                        print(f"      - {link}")

            if data["issues_found"]:
                print("\n❌ Findings:")
                for issue in data["issues_found"]:
                    print(f"  - {issue}")

            if data["warnings"]:
                print("\n⚠️  Warnings:")
                for warning in data["warnings"]:
                    print(f"  - {warning}")

            return 0 if data["is_ready"] else 1
        elif not result.success:
            print(f"❌ Verification failed: {result.error}")
            return 1
        else:
            print("❌ Verification failed: No response data received")
            return 1


class ImportCommandHandler:
    """Handles import commands"""

    def __init__(
        self,
        service: ImportService,
        enhancement_service: Optional["ExpertEnhancementService"] = None,
    ):
        self._service = service
        self._enhancement_service = enhancement_service

    def handle_import_markdown(
        self,
        file_path: str,
        dry_run: bool = True,
        with_docs: bool = False,
        auto: bool = False,
    ) -> int:
        """Handle 'import markdown' command with full automation support"""
        print(f"\n{'=' * 60}")
        print("📥 IMPORT FROM MARKDOWN")
        print(f"{'=' * 60}\n")
        print(f"📄 File: {file_path}")
        print(
            f"🎯 Mode: {'AUTO (full workflow)' if auto else 'Execute' if not dry_run else 'Dry Run (preview only)'}"
        )
        if with_docs:
            print("📚 Docs: Generate Confluence documentation")
        print()

        # Phase 1: Import/Parse
        result = self._service.import_from_markdown(
            file_path, execute=not dry_run, with_docs=with_docs
        )

        if result.success and result.value:
            data = result.value

            # Show parsed document structure
            if "plan" in data:
                plan = data["plan"]
                print("📊 Parsed from document:")
                print(f"   📖 Epics: {plan.get('epics', 0)}")
                print(f"   📝 Stories: {plan.get('stories', 0)}")
                print(f"   ✅ Tasks: {plan.get('tasks', 0)}")
                print()

            if data.get("dry_run"):
                print("🔍 DRY RUN MODE - No issues created")
                print("   Use --execute to create issues")
                print("   Use --auto for full automated workflow")
                return 0

            # Show creation results
            print("✨ Created in Jira:")
            print(f"   📖 Epics: {data['epics_created']}")
            print(f"   📝 Stories: {data['stories_created']}")
            print(f"   ✅ Tasks: {data['tasks_created']}")

            if data.get("created_docs"):
                print(f"\n📚 Created Confluence Pages: {len(data['created_docs'])}")
                for doc in data["created_docs"][:5]:  # Show first 5
                    print(f"   • {doc['issue_key']}: {doc['doc_url']}")

            if data.get("errors"):
                print(f"\n⚠️  Errors encountered: {len(data['errors'])}")
                for error in data["errors"][:5]:
                    print(f"   • {error}")

            print("\n✓ Import complete!")

            # Phase 2: Auto workflow (if requested)
            if auto and data.get("created_stories"):
                print(f"\n{'=' * 60}")
                print("🤖 AUTO WORKFLOW - Enhancing created stories...")
                print(f"{'=' * 60}\n")

                if not self._enhancement_service:
                    print("⚠️  Enhancement service not available. Skipping auto-enhance.")
                    print("   Stories were created but not enhanced.")
                    print("   Run 'enhance --issue <KEY>' manually for each story.")
                else:
                    created_stories = data["created_stories"]
                    enhanced_count = 0
                    failed_count = 0

                    for story_key in created_stories:
                        try:
                            print(f"   📝 Enhancing {story_key}...", end=" ")
                            enhance_request = EnhanceIssueRequest(
                                issue_key=story_key,
                                force=False,
                                skip_metadata=False,
                                update_metadata=True,
                                apply_architecture=True,
                            )
                            enhance_result = self._enhancement_service.enhance_issue(
                                enhance_request
                            )
                            if enhance_result.success:
                                enhanced_count += 1
                                print("✓")
                            else:
                                failed_count += 1
                                error_msg = (
                                    enhance_result.errors[0]
                                    if enhance_result.errors
                                    else "Unknown error"
                                )
                                print(f"⚠️  {error_msg}")
                        except Exception:
                            failed_count += 1
                            print("❌ Error")

                    print(f"\n   Enhanced: {enhanced_count}/{len(created_stories)}")
                    if failed_count:
                        print(f"   Failed: {failed_count}")

                print("\n✓ Auto workflow complete!")

            return 0
        elif not result.success:
            print(
                f"❌ Import failed: {result.error if hasattr(result, 'error') else 'Unknown error'}"
            )
            if result.errors:
                for error in result.errors:
                    print(f"   • {error}")
            return 1
        else:
            print("❌ Import failed: No response data received")
            return 1

    def handle_import_yaml(self, file_path: str, dry_run: bool = True) -> int:
        """Handle 'import yaml' command"""
        result = self._service.import_document(source=file_path, execute=not dry_run)

        if result.success and result.value:
            data = result.value
            print("📥 Import from YAML")
            print(f"📋 Epics Created: {data.get('epics_created', 0)}")
            print(f"📋 Stories Created: {data.get('stories_created', 0)}")
            print(f"📋 Tasks Created: {data.get('tasks_created', 0)}")
            if not dry_run:
                print("\n✓ Import complete")
            else:
                print("\n🔍 DRY RUN - No issues created")
            return 0
        elif not result.success:
            print(f"❌ Import failed: {result.error}")
            return 1
        else:
            print("❌ Import failed: No response data received")
            return 1

    def handle_import_confluence(
        self,
        page_id: str,
        include_children: bool = False,
        dry_run: bool = True,
        sprint_number: int | None = None,
        epic_only: bool = False,
        with_docs: bool = False,
        verbose: bool = False,
        skip_duplicate_check: bool = False,
        validate_codebase: bool = False,
        analyze_backlog: bool = False,
    ) -> int:
        """Handle 'import confluence' command - analyze architecture docs and create Jira issues"""
        print(f"\n{'=' * 60}")
        print("🏛️  ARCHITECTURE ANALYZER - CONFLUENCE IMPORT")
        print(f"{'=' * 60}\n")
        print(f"📄 Page ID: {page_id}")
        print(f"🔗 Include Children: {'Yes' if include_children else 'No'}")
        print(f"🎯 Mode: {'Execute' if not dry_run else 'Dry Run (preview only)'}")
        print(f"🔍 Duplicate Check: {'Disabled' if skip_duplicate_check else 'Enabled'}")
        print(
            f"🔬 Codebase Validation: {'Enabled (scanning core/**/*.hpp, context_map.md, glossary)' if validate_codebase else 'Disabled'}"
        )
        print(
            f"📊 Backlog Analysis: {'Enabled (scanning full backlog for conflicts, related epics, sprint allocation)' if analyze_backlog else 'Disabled'}"
        )
        if sprint_number:
            print(f"🏃 Sprint: {sprint_number}")
        if epic_only:
            print("📖 Epic Only: True")
        if verbose:
            print("🔍 Verbose: Yes")
        print()

        try:
            # Analyze architecture documentation
            result = self._service.import_from_confluence(
                page_id=page_id,
                include_children=include_children,
                execute=not dry_run,
                sprint_number=sprint_number,
                epic_only=epic_only,
                with_docs=with_docs,
                verbose=verbose,
                skip_duplicate_check=skip_duplicate_check,
                validate_codebase=validate_codebase,
                analyze_backlog=analyze_backlog,
            )

            if result.success and result.value:
                data = result.value

                # Show analysis summary
                print("📊 Architecture Analysis Results:")
                print(f"   📄 Pages analyzed: {data.get('pages_analyzed', 0)}")
                print(f"   🔍 Components identified: {data.get('components_identified', 0)}")
                print()

                if data.get("dry_run"):
                    print("🔍 DRY RUN MODE - No issues created")
                    print("\n" + "=" * 60)
                    print("📋 IMPLEMENTATION WORK ITEMS PREVIEW")
                    print("=" * 60)

                    if "plan" in data:
                        plan = data["plan"]
                        print("\n📊 Work Items Summary:")
                        print(f"   📖 Epics (by bounded context): {plan.get('epics', 0)}")
                        print(f"   📝 Stories (implementation work): {plan.get('stories', 0)}")
                        print(f"   ✅ Tasks (specific technical work): {plan.get('tasks', 0)}")

                    # === DUPLICATE DETECTION RESULTS ===
                    dup_analysis = data.get("duplicate_analysis")
                    if dup_analysis and dup_analysis.get("total_matches", 0) > 0:
                        print(f"\n{'─' * 60}")
                        print("🔍 DUPLICATE DETECTION ANALYSIS:")
                        print(f"{'─' * 60}")

                        if dup_analysis.get("has_likely_duplicates"):
                            print("\n  ⚠️  WARNING: Likely duplicates detected!")
                            print(
                                "      Consider linking to existing issues instead of creating new ones."
                            )
                        elif dup_analysis.get("has_potential_duplicates"):
                            print("\n  ⚡ NOTICE: Potential duplicates detected.")
                            print("      Review matched issues before proceeding.")

                        # Show epic matches
                        epic_matches = dup_analysis.get("epic_matches", [])
                        if epic_matches:
                            print(f"\n  📖 Epic Matches ({len(epic_matches)}):")
                            for match in epic_matches[:5]:
                                marker = "⚠️" if match["similarity"] > 0.6 else "ℹ️"
                                print(
                                    f"     {marker} [{match['issue_key']}] {match['summary'][:50]}..."
                                )
                                print(
                                    f"        Similarity: {match['similarity']:.0%} | Status: {match['status']}"
                                )
                                print(f"        Searching for: {match['matched_title'][:40]}...")
                                if match.get("recommendation"):
                                    print(f"        {match['recommendation']}")
                            if len(epic_matches) > 5:
                                print(f"     ... and {len(epic_matches) - 5} more epic matches")

                        # Show story matches
                        story_matches = dup_analysis.get("story_matches", [])
                        if story_matches:
                            print(f"\n  📝 Story Matches ({len(story_matches)}):")
                            for match in story_matches[:5]:
                                marker = "⚠️" if match["similarity"] > 0.6 else "ℹ️"
                                print(
                                    f"     {marker} [{match['issue_key']}] {match['summary'][:50]}..."
                                )
                                print(
                                    f"        Similarity: {match['similarity']:.0%} | Status: {match['status']}"
                                )
                                if match.get("recommendation"):
                                    print(f"        {match['recommendation']}")
                            if len(story_matches) > 5:
                                print(f"     ... and {len(story_matches) - 5} more story matches")

                        # Show task matches
                        task_matches = dup_analysis.get("task_matches", [])
                        if task_matches:
                            print(f"\n  ✅ Task Matches ({len(task_matches)}):")
                            for match in task_matches[:5]:
                                marker = "⚠️" if match["similarity"] > 0.6 else "ℹ️"
                                print(
                                    f"     {marker} [{match['issue_key']}] {match['summary'][:50]}..."
                                )
                                print(f"        Similarity: {match['similarity']:.0%}")
                            if len(task_matches) > 5:
                                print(f"     ... and {len(task_matches) - 5} more task matches")

                        print(
                            f"\n  💡 Total similar issues found: {dup_analysis.get('total_matches', 0)}"
                        )
                    elif dup_analysis is not None:
                        print("\n  ✅ No similar existing issues found - safe to create")

                    # === BACKLOG ANALYSIS RESULTS ===
                    backlog_analysis = data.get("backlog_analysis")
                    if backlog_analysis:
                        print(f"\n{'─' * 60}")
                        print("📊 COMPREHENSIVE BACKLOG ANALYSIS:")
                        print(f"{'─' * 60}")

                        print("\n  📈 Backlog Overview:")
                        print(f"     Total Epics: {getattr(backlog_analysis, 'total_epics', 0)}")
                        print(
                            f"     Total Stories/Tasks: {getattr(backlog_analysis, 'total_stories', 0)}"
                        )
                        print(
                            f"     Currently In Progress: {getattr(backlog_analysis, 'total_in_progress', 0)}"
                        )
                        print(
                            f"     Current Sprint Items: {getattr(backlog_analysis, 'current_sprint_count', 0)}"
                        )
                        print(
                            f"     Blocked Items: {getattr(backlog_analysis, 'blocked_count', 0)}"
                        )

                        covered = getattr(backlog_analysis, "covered_contexts", [])
                        if covered:
                            print(f"\n  📁 Bounded Contexts with Coverage ({len(covered)}):")
                            for ctx in sorted(covered)[:10]:
                                print(f"     • {ctx}")
                            if len(covered) > 10:
                                print(f"     ... and {len(covered) - 10} more")

                        gaps = getattr(backlog_analysis, "coverage_gaps", [])
                        if gaps:
                            print(f"\n  ⚠️  Coverage Gaps ({len(gaps)} contexts with no backlog):")
                            for gap in gaps:
                                print(f"     • {gap}")

                        # Show related epics (for linking)
                        related_epics = getattr(backlog_analysis, "related_epics", [])
                        if related_epics:
                            print("\n  🔗 Related Epics (consider linking new work):")
                            for epic in related_epics[:5]:
                                status_marker = (
                                    "🟢" if epic["status"].lower() == "in progress" else "⚪"
                                )
                                print(
                                    f"     {status_marker} [{epic['key']}] {epic['summary'][:50]}..."
                                )
                                print(
                                    f"        Context: {epic['bounded_context']} | Progress: {epic['progress_percent']}%"
                                )

                        # Show linkable epics (suggested)
                        linkable = getattr(backlog_analysis, "linkable_epics", [])
                        if linkable:
                            print("\n  💡 Suggested Epic Links:")
                            for epic_key in linkable[:3]:
                                print(f"     • Link new stories to: {epic_key}")

                        # Show potential conflicts
                        conflicts = getattr(backlog_analysis, "potential_conflicts", [])
                        if conflicts:
                            print("\n  🚨 POTENTIAL CONFLICTS:")
                            for conflict in conflicts[:10]:
                                print(f"     {conflict}")

                        # Show in-progress work by context
                        in_progress = getattr(backlog_analysis, "in_progress_by_context", {})
                        if in_progress:
                            print("\n  🔄 In-Progress Work by Context:")
                            for ctx, stories in list(in_progress.items())[:5]:
                                print(f"     {ctx}:")
                                for story in stories[:3]:
                                    assignee = (
                                        f" ({getattr(story, 'assignee', '')})"
                                        if getattr(story, "assignee", "")
                                        else ""
                                    )
                                    print(
                                        f"       • [{getattr(story, 'key', '')}] {getattr(story, 'summary', '')[:40]}...{assignee}"
                                    )

                        # Show summary
                        if hasattr(backlog_analysis, "get_summary") and callable(
                            backlog_analysis.get_summary
                        ):
                            summary = backlog_analysis.get_summary()
                            if summary:
                                print(f"\n  {'─' * 56}")
                                print("  BACKLOG SUMMARY:")
                                for line in summary.split("\n")[3:12]:  # Skip header, show key info
                                    if line.strip():
                                        print(f"  {line}")

                    # Show identified architectural components
                    if data.get("component_details"):
                        print(f"\n{'─' * 60}")
                        print("🔍 ARCHITECTURAL COMPONENTS IDENTIFIED:")
                        print(f"{'─' * 60}")
                        for i, comp in enumerate(data["component_details"], 1):
                            print(f"\n  [{i}] {comp.get('name', 'Unknown')}")
                            print(f"      Type: {comp.get('type', 'N/A')}")
                            print(f"      Context: {comp.get('bounded_context', 'N/A')}")
                            if comp.get("patterns"):
                                print(f"      Patterns: {', '.join(comp['patterns'][:3])}")
                            if comp.get("responsibilities"):
                                print("      Responsibilities:")
                                for resp in comp["responsibilities"][:2]:
                                    print(f"        • {resp[:80]}...")

                    # Show epic details
                    if data.get("epic_details"):
                        print(f"\n{'─' * 60}")
                        print("📖 EPICS TO CREATE (by Bounded Context):")
                        print(f"{'─' * 60}")
                        for i, epic in enumerate(data["epic_details"], 1):
                            print(f"\n  [{i}] {epic.get('title', 'Untitled Epic')}")
                            print(f"      Context: {epic.get('bounded_context', 'N/A')}")
                            print(f"      Priority: {epic.get('priority', 'Medium')}")
                            if epic.get("labels"):
                                print(f"      Labels: {', '.join(epic['labels'][:5])}")
                            if epic.get("acceptance_criteria"):
                                print("      Definition of Done:")
                                for ac in epic["acceptance_criteria"][:3]:
                                    print(f"        ✓ {ac}")

                    # Show story details (grouped by epic)
                    if data.get("story_details"):
                        print(f"\n{'─' * 60}")
                        print("📝 STORIES TO CREATE (Implementation Work):")
                        print(f"{'─' * 60}")

                        # Group stories by epic
                        stories_by_epic: dict[str, list[dict[str, Any]]] = {}
                        for story in data["story_details"]:
                            epic_title = story.get("parent_epic", "No Epic")
                            if epic_title not in stories_by_epic:
                                stories_by_epic[epic_title] = []
                            stories_by_epic[epic_title].append(story)

                        for epic_title, stories in stories_by_epic.items():
                            print(f"\n  📖 {epic_title}")
                            print(f"     ({len(stories)} stories)")
                            for j, story in enumerate(stories[:5], 1):  # Show first 5 per epic
                                sp = (
                                    f" [{story.get('story_points', '?')} pts]"
                                    if getattr(story, "story_points", "")
                                    else ""
                                )
                                print(f"     [{j}] {story.get('title', 'Untitled')}{sp}")
                                if getattr(story, "acceptance_criteria", ""):
                                    print(
                                        f"         Acceptance Criteria ({len(story['acceptance_criteria'])} items):"
                                    )
                                    for ac in story["acceptance_criteria"][:3]:
                                        print(
                                            f"           • {ac[:60]}{'...' if len(ac) > 60 else ''}"
                                        )
                                if getattr(story, "priority", "") and story["priority"] != "Medium":
                                    print(f"         Priority: {story['priority']}")
                            if len(stories) > 5:
                                print(f"     ... and {len(stories) - 5} more stories")

                    # Show task details
                    if data.get("task_details") and len(data["task_details"]) > 0:
                        print(f"\n{'─' * 60}")
                        print("✅ TASKS TO CREATE (Technical Work):")
                        print(f"{'─' * 60}")
                        for k, task in enumerate(data["task_details"][:10], 1):
                            print(f"  [{k}] {task.get('title', 'Untitled Task')}")
                            if task.get("bounded_context"):
                                print(f"      Context: {task['bounded_context']}")
                        if len(data["task_details"]) > 10:
                            print(f"  ... and {len(data['task_details']) - 10} more tasks")

                    # Show analysis notes if verbose
                    if verbose and data.get("analysis_notes"):
                        print(f"\n{'─' * 60}")
                        print("🔍 ANALYSIS NOTES:")
                        print(f"{'─' * 60}")
                        for note in data["analysis_notes"]:
                            print(f"  {note}")

                    print(f"\n{'=' * 60}")
                    print("💡 This analysis identifies REAL implementation work based on")
                    print("   software engineering best practices and Inovagio architecture.")
                    print()
                    print("💡 To create these issues in Jira, run with --execute")
                    print("=" * 60)
                    return 0

                # Show creation results
                print("✨ Created in Jira:")
                print(f"   📖 Epics: {data.get('epics_created', 0)}")
                print(f"   📝 Stories: {data.get('stories_created', 0)}")
                print(f"   ✅ Tasks: {data.get('tasks_created', 0)}")

                if data.get("created_issues"):
                    print("\n📋 Created Issues:")
                    for issue in data["created_issues"][:10]:  # Show first 10
                        print(f"   • {issue['key']}: {issue['summary']}")
                    if len(data["created_issues"]) > 10:
                        print(f"   ... and {len(data['created_issues']) - 10} more")

                if data.get("errors"):
                    print(f"\n⚠️  Errors encountered: {len(data['errors'])}")
                    for error in data["errors"][:5]:
                        print(f"   • {error}")

                print("\n✓ Import complete!")
                return 0
            elif not result.success:
                print(
                    f"❌ Analysis failed: {result.error if hasattr(result, 'error') else 'Unknown error'}"
                )
                if hasattr(result, "errors") and result.errors:
                    for error in result.errors:
                        print(f"   • {error}")
                return 1
            else:
                print("❌ Analysis failed: No response data received")
                return 1

        except Exception as e:  # type: ignore  # pylint: disable=broad-except
            print(f"❌ Unexpected error: {e!s}")
            traceback.print_exc()
            return 1


class PrepareCommandHandler:
    """Handles story preparation commands"""

    def __init__(self, prepare_story_service: PrepareStoryService):
        self._service = prepare_story_service

    def handle_prepare(
        self,
        issue_key: str,
        update: bool = False,
        format_type: str = "full",
        output_file: str | None = None,
    ) -> int:
        """Handle 'prepare' command - generate technical specifications"""

        request = PrepareStoryRequest(
            issue_key=issue_key,
            update=update,
            format_type=format_type,
            output_file=output_file,
        )
        result = self._service.prepare_story(request)

        if result.success and result.value:
            response = result.value
            print(f"✅ Technical specification generated for {response.issue_key}")

            if output_file:
                try:
                    with open(output_file, "w", encoding="utf-8") as f:
                        f.write(response.specification)
                    print(f"💾 Specification saved to: {output_file}")
                except Exception as e:
                    print(f"⚠️ Failed to save to file: {e}")

            if response.updated:
                print("📝 Issue description updated in Jira")

            if not output_file:
                print(f"\n📋 Specification:\n{response.specification}")

            return 0
        elif not result.success:
            print(f"❌ Prepare failed: {result.error}")
            return 1
        else:
            print("❌ Prepare failed: No response data received")
            return 1


class ContextCommandHandler:
    """Handles bounded context commands"""

    def __init__(self, context_info_service: ContextInfoService):
        self._service = context_info_service

    def handle_context(self, context_name: str | None = None) -> int:
        """Handle 'context' command - show bounded context information"""

        request = ContextInfoRequest(context_name=context_name)
        result = self._service.get_context_info(request)

        if result.success and result.value:
            response = result.value
            print("🏗️  Bounded Context Information\n")
            for ctx in response.contexts:
                print(f"📦 {ctx['name']}")
                if ctx.get("description"):
                    print(f"   {ctx['description']}")
                if ctx.get("responsibilities"):
                    print(f"   Responsibilities: {', '.join(ctx['responsibilities'])}")
                print()
            return 0
        elif not result.success:
            print(f"❌ Context info failed: {result.error}")
            return 1
        else:
            print("❌ Context info failed: No response data received")
            return 1


class StandardizeCommandHandler:
    """Handles story standardization commands"""

    def __init__(self, standardize_story_service: StandardizeStoryService):
        self._service = standardize_story_service

    def handle_standardize(self, issue_key: str, format_type: str = "user_story") -> int:
        """Handle 'standardize' command - convert stories to standard format"""

        request = StandardizeStoryRequest(issue_key=issue_key, execute=True)
        result = self._service.standardize_story(request)

        if result.success and result.value:
            response = result.value
            print(f"✅ Standardization completed (Format: {format_type})")
            if response.standardized:
                print(f"✨ Standardized: {', '.join(response.standardized)}")
            if response.skipped:
                print(f"⏭️  Skipped: {', '.join(response.skipped)}")
            if response.failed:
                print(f"❌ Failed: {', '.join(response.failed)}")
            return 0
        elif not result.success:
            print(f"❌ Standardize failed: {result.error}")
            return 1
        else:
            print("❌ Standardize failed: No response data received")
            return 1


class BalanceCommandHandler:
    """Handles sprint capacity balancing commands"""

    def __init__(self, balance_capacity_service: BalanceCapacityService):
        self._service = balance_capacity_service

    def handle_balance(self, sprint_number: int) -> int:
        """Handle 'balance' command - analyze and balance sprint capacity"""

        request = BalanceCapacityRequest(start_sprint=sprint_number, end_sprint=sprint_number)
        result = self._service.analyze_balance(request)

        if result.success and result.value:
            response = result.value
            print(f"📊 Sprint {sprint_number} Capacity Analysis\n")

            if response.recommendations:
                print("\n💡 Recommendations:")
                for rec in response.recommendations:
                    print(f"  - {rec}")
            return 0
        elif not result.success:
            print(f"❌ Balance analysis failed: {result.error}")
            return 1
        else:
            print("❌ Balance analysis failed: No response data received")
            return 1


class TemplateCommandHandler:
    """Handles template generation commands"""

    def __init__(self, template_generation_service: TemplateGenerationService):
        self._service = template_generation_service

    def handle_template(self, template_type: str, format_type: str = "markdown") -> int:
        """Handle 'template' command - generate templates"""

        request = GenerateTemplateRequest(format_type=format_type)
        result = self._service.generate_template(request)

        if result.success and result.value:
            response = result.value
            print(f"✅ Template generated (Type: {template_type}, Format: {format_type})\n")
            print(response.template)

            if response.file_path:
                print(f"\n💾 Saved to: {response.file_path}")
            return 0
        elif not result.success:
            print(f"❌ Template generation failed: {result.error}")
            return 1
        else:
            print("❌ Template generation failed: No response data received")
            return 1


class RemoveLabelCommandHandler:
    """Handles bulk label removal commands"""

    def __init__(self, label_removal_service: LabelRemovalService):
        self._service = label_removal_service

    def handle_remove_label(
        self, label: str, project_key: str | None = None, dry_run: bool = True
    ) -> int:
        """Handle 'remove-label' command - bulk remove labels from issues"""

        request = RemoveLabelRequest(label=label, execute=not dry_run)
        result = self._service.remove_label(request)

        if result.success and result.value:
            response = result.value
            project_info = f" for project {project_key}" if project_key else ""
            print(f"✅ Label removal {'simulation' if dry_run else 'complete'}{project_info}")
            print(f"📊 Total removed: {response.total_removed}")

            if response.removed:
                print("\nRemoved from:")
                for issue_key in response.removed[:20]:  # Show first 20
                    print(f"  - {issue_key}")
                if len(response.removed) > 20:
                    print(f"  ... and {len(response.removed) - 20} more")

            if dry_run:
                print("\n🔍 DRY RUN - No labels removed")
            return 0
        elif not result.success:
            print(f"❌ Label removal failed: {result.error}")
            return 1
        else:
            print("❌ Label removal failed: No response data received")
            return 1


class GoalsCommandHandler:
    """Handles sprint goals generation commands"""

    def __init__(self, sprint_goals_service: SprintGoalsService):
        self._service = sprint_goals_service

    def handle_goals(self, sprint_number: int) -> int:
        """Handle 'goals' command - generate sprint goals"""

        request = GenerateSprintGoalsRequest(sprint_number=sprint_number)
        result = self._service.generate_goals(request)

        if result.success and result.value:
            response = result.value
            print(f"🎯 Sprint {response.sprint_number} Goals\n")
            print(f"Primary Goal:\n  {response.primary_goal}\n")

            if response.secondary_goals:
                print("Secondary Goals:")
                for goal in response.secondary_goals:
                    print(f"  - {goal}")

            if response.success_criteria:
                print("\n✓ Success Criteria:")
                for criterion in response.success_criteria:
                    print(f"  - {criterion}")
            return 0
        elif not result.success:
            print(f"❌ Goals generation failed: {result.error}")
            return 1
        else:
            print("❌ Goals generation failed: No response data received")
            return 1


class DeleteCommandHandler:
    """Handles 'delete' commands for issue deletion"""

    def __init__(self, deletion_service: IssueDeletionService):
        self._service = deletion_service

    def handle_delete(
        self,
        issue_keys: list[str],
        delete_subtasks: bool = True,
        force: bool = False,
        dry_run: bool = True,
    ) -> int:
        """Handle 'delete' command - delete issues with safeguards"""

        # Show warning for non-dry-run
        if not dry_run and not force:
            print("⚠️  WARNING: This will permanently delete the specified issues!")
            if delete_subtasks:
                print("⚠️  Subtasks will also be deleted (--delete-subtasks enabled)")
            confirm = input("Type 'DELETE' to confirm: ")
            if confirm != "DELETE":
                print("❌ Deletion cancelled")
                return 1

        request = DeleteIssueRequest(
            issue_keys=issue_keys,
            delete_subtasks=delete_subtasks,
            force=force,
            dry_run=dry_run,
        )

        result = self._service.delete_issues(request)

        if result.success and result.value:
            response = result.value

            if dry_run:
                print("🔍 DRY-RUN MODE - No changes made\n")

            if response.deleted:
                print(f"✅ Deleted {response.total_deleted} issue(s):")
                for key in response.deleted:
                    print(f"  ✓ {key}")

            if response.skipped:
                print(f"\n⏭️  Skipped {len(response.skipped)} issue(s):")
                for key in response.skipped:
                    print(f"  - {key}")

            if response.failed:
                print(f"\n❌ Failed to delete {len(response.failed)} issue(s):")
                for key in response.failed:
                    print(f"  ✗ {key}")

            if response.warnings:
                print("\n⚠️  Warnings:")
                for warning in response.warnings:
                    print(f"  {warning}")

            if dry_run:
                print("\n💡 Use --execute to actually delete these issues")
                if len(issue_keys) > 10:
                    print("💡 Add --force flag for bulk deletion (>10 issues)")

            return 0 if not response.failed else 1
        elif not result.success:
            print(f"❌ Deletion failed: {result.error}")
            if result.errors:
                for error in result.errors:
                    print(f"  - {error}")
            return 1
        else:
            print("❌ Deletion failed: No response data received")
            return 1


class ReorganizeCommandHandler:
    """Handles 'reorganize' commands for Confluence page restructuring"""

    def __init__(self, confluence: ConfluencePageRepository):
        self._confluence = confluence

    def handle_reorganize(self, dry_run: bool = True) -> int:
        """Reorganize Product Portfolio pages to align with DDD Context Map"""

        # Standard product names per DDD Context Map
        # STANDARD_PRODUCTS = {
        #     "Control Plane": "P0-CRITICAL - Governance UI/API",
        #     "Crews": "P0-CRITICAL - Virtual Employee runtime",
        #     "Edge": "Local execution runtime",
        #     "Flow": "Agent builder (Python SDK)",
        #     "Guard": "Safety and policy enforcement",
        #     "Insights": "Analytics, billing, ROI",
        #     "Marketplace": "Asset catalog, transactions",
        #     "Origin": "SLM/LLM Training Platform",
        #     "Sentinel": "Compliance monitoring and audit",
        #     "Shops": "AI Workforce Agencies, storefronts",
        #     "Studio": "Visual workflow builder"
        # }

        # Mapping from current names to standard names
        RENAME_MAP = {
            "Inovagio Control Plane - Governance UI": "Control Plane",
            "Inovagio Crews": "Crews",
            "Inovagio Edge": "Edge",
            "Inovagio Flow": "Flow",
            "Inovagio Guard - Policy Enforcement": "Guard",
            "Inovagio Insights - AI Workforce Analytics": "Insights",
            "Inovagio Marketplace - Agent Exchange": "Marketplace",
            "Inovagio Origin": "Origin",
            "Inovagio Sentinel - Runtime Safety": "Sentinel",
            "Inovagio Shops - AI Workforce Agencies": "Shops",
            "Inovagio Studio": "Studio",
        }

        # Feature pages to move to products
        FEATURE_PAGES = {
            "Human-in-the-Loop (HITL) — Workflow Patterns & Governance": "Flow",
            "Hybrid Workflow Orchestrator": "Flow",
            "Inovagio Connector SDK — Building Enterprise Integrations": "Flow",
            "Workflow Engine Enhancement Specification: Superiority Roadmap": "Flow",
            "Inovagio Edge — Air-Gapped & Regulated Deployment Guide": "Edge",
            "Inovagio Connect Packs - Enterprise Integration Bundles": "Marketplace",
            "Creator Economics - Revenue & Monetization": "Marketplace",
        }

        # Pages to archive
        PAGES_TO_ARCHIVE = {
            "Inovagio ANI - Multi-Agent Communication",
            "Inovagio Cloud Workspace - Enterprise SaaS Application",
            "Inovagio Ecosystem - Complete Product & Architecture Map",
            "Inovagio Evaluator - Quality Assurance & Benchmarking Framework",
            "Work Orders - Project Tracking",
        }

        print("\n" + "=" * 70)
        print("📋 Product Portfolio Reorganization")
        print("=" * 70)

        # Find Product Portfolio
        portfolio_id = self._confluence.find_page_by_title(
            "INOV", "Product Portfolio - Source of Truth"
        )
        if not portfolio_id:
            print("❌ ERROR: Product Portfolio page not found!")
            return 1

        print("✅ Found Product Portfolio page\n")
        children = self._confluence.get_child_pages(portfolio_id)
        current_pages = {child.title: child for child in children}

        # Preview changes
        print("🔄 RENAMES (preserves page ID and all links):")
        print("-" * 70)
        renames = []
        for old_name, new_name in RENAME_MAP.items():
            if old_name in current_pages:
                page = current_pages[old_name]
                if new_name in current_pages and old_name != new_name:
                    print(f"  ⚠️  CONFLICT: '{old_name}' → '{new_name}'")
                    print(f"      Target '{new_name}' already exists")
                else:
                    renames.append((page.page_id, old_name, new_name))
                    print(f"  ✓ '{old_name}' → '{new_name}'")

        print("\n📑 FEATURE PAGES (move to product pages):")
        print("-" * 70)
        features = []
        for page_name, product in FEATURE_PAGES.items():
            if page_name in current_pages:
                page = current_pages[page_name]
                features.append((page.page_id, page_name, product))
                print(f"  ✓ '{page_name}' → {product}")

        print("\n📦 ARCHIVES (move out of Product Portfolio):")
        print("-" * 70)
        archives = []
        for page_name in PAGES_TO_ARCHIVE:
            if page_name in current_pages:
                page = current_pages[page_name]
                archives.append((page.page_id, page_name))
                print(f"  ✓ '{page_name}'")

        print("\n" + "=" * 70)
        print("📊 SUMMARY:")
        print(f"  Renames: {len(renames)}")
        print(f"  Feature Moves: {len(features)}")
        print(f"  Archives: {len(archives)}")
        print("=" * 70)

        if dry_run:
            print("\n🔍 DRY-RUN MODE: No changes were made")
            print("   Use --execute to apply changes")
            return 0

        # Execute renames
        if renames:
            print("\n🔄 Executing Renames...")
            print("-" * 70)
            for page_id, old_name, new_name in renames:
                try:
                    page_data = self._confluence.get_page(page_id)
                    if page_data is None:
                        print(f"  ❌ Failed to get '{old_name}'")
                        continue

                    content = page_data.content

                    success = self._confluence.update_page(page_id, new_name, content)

                    if success:
                        print(f"  ✅ Renamed '{old_name}' → '{new_name}'")
                    else:
                        print(f"  ❌ Failed to rename '{old_name}'")
                except Exception as e:  # type: ignore
                    print(f"  ❌ Error: {e}")

        # Execute feature moves
        if features:
            print("\n📑 Moving Feature Pages...")
            print("-" * 70)
            # Refresh product pages after renames
            children = self._confluence.get_child_pages(portfolio_id)
            product_pages = {child.title: child.page_id for child in children}

            for page_id, page_name, product in features:
                try:
                    if product not in product_pages:
                        print(f"  ⚠️  Product '{product}' not found, skipping '{page_name}'")
                        continue

                    success = self._confluence.move_page(page_id, product_pages[product])

                    if success:
                        print(f"  ✅ Moved '{page_name}' → {product}")
                    else:
                        print(f"  ❌ Failed to move '{page_name}'")
                except Exception as e:  # type: ignore
                    print(f"  ❌ Error: {e}")

        # Execute archives
        if archives:
            print("\n📦 Archiving Pages...")
            print("-" * 70)
            archive_parent = self._confluence.find_page_by_title("INOV", "Archived Documentation")

            if not archive_parent:
                print("  Creating 'Archived Documentation' page...")
                archive_parent = self._confluence.create_page(
                    "INOV",
                    "Archived Documentation",
                    """
<h2>Archived Documentation</h2>
<p>Pages moved out of Product Portfolio during reorganization.</p>
<hr/>
<ac:structured-macro ac:name="children" ac:schema-version="2">
  <ac:parameter ac:name="all">true</ac:parameter>
</ac:structured-macro>
""",
                )

            for page_id, page_name in archives:
                try:
                    success = self._confluence.move_page(page_id, archive_parent)

                    if success:
                        print(f"  ✅ Archived '{page_name}'")
                    else:
                        print(f"  ❌ Failed to archive '{page_name}'")
                except Exception as e:  # type: ignore
                    print(f"  ❌ Error: {e}")

        print("\n" + "=" * 70)
        print("✅ REORGANIZATION COMPLETE!")
        print("=" * 70)
        return 0


class ProductDocsCommandHandler:
    """Handles 'product-docs' command for creating standard product documentation structure"""

    def __init__(self, confluence: ConfluencePageRepository):
        self._confluence = confluence

    def handle_create_product_docs(self, product: str, dry_run: bool = True) -> int:
        """Create standard documentation structure for a product"""

        print("\n" + "=" * 70)
        print(f"📚 Creating Standard Documentation Structure for: {product}")
        print("=" * 70)

        # Define standard pages first (needed for dry-run output)
        standard_pages = [
            {
                "title": "Overview",
                "content": f"""
<h2>{product} - Overview</h2>

<h3>Purpose</h3>
<p>[What problem does this product solve?]</p>

<h3>Key Capabilities</h3>
<ul>
<li>Capability 1</li>
<li>Capability 2</li>
<li>Capability 3</li>
</ul>

<h3>Target Users</h3>
<ul>
<li>Persona 1</li>
<li>Persona 2</li>
</ul>

<h3>Status</h3>
<ul>
<li><strong>Current Version:</strong> vX.Y.Z</li>
<li><strong>Release Date:</strong> [Date]</li>
<li><strong>Maturity:</strong> [Alpha/Beta/GA]</li>
</ul>

<h3>Quick Links</h3>
<ul>
<li><ac:link><ri:page ri:content-title="Architecture"/><ac:plain-text-link-body><![CDATA[Architecture]]></ac:plain-text-link-body></ac:link></li>
<li><ac:link><ri:page ri:content-title="Getting Started"/><ac:plain-text-link-body><![CDATA[Getting Started]]></ac:plain-text-link-body></ac:link></li>
<li><ac:link><ri:page ri:content-title="Features"/><ac:plain-text-link-body><![CDATA[Features]]></ac:plain-text-link-body></ac:link></li>
</ul>
""",
            },
            {
                "title": "Features",
                "content": f"""
<h2>{product} - Features</h2>
<p>Feature-level documentation for {product}.</p>

<h3>Feature Pages</h3>
<p>Create child pages for each major feature using the template:</p>
<ul>
<li><strong>Feature: [Name]</strong></li>
</ul>

<h3>Feature List</h3>
<ac:structured-macro ac:name="children" ac:schema-version="2">
  <ac:parameter ac:name="all">true</ac:parameter>
  <ac:parameter ac:name="sort">title</ac:parameter>
</ac:structured-macro>
""",
            },
            {
                "title": "Architecture",
                "content": f"""
<h2>{product} - Architecture</h2>

<h3>System Context</h3>
<p>[C4 Context Diagram]</p>

<h3>Container Diagram</h3>
<p>[C4 Container Diagram]</p>

<h3>Key Components</h3>

<h4>Component 1</h4>
<ul>
<li><strong>Purpose:</strong> [Description]</li>
<li><strong>Dependencies:</strong> [List]</li>
<li><strong>Interfaces:</strong> [List]</li>
</ul>

<h3>Data Flow</h3>
<p>[Sequence diagrams]</p>

<h3>Technology Stack</h3>
<ul>
<li><strong>Languages:</strong> C++20, Python</li>
<li><strong>Frameworks:</strong> [List]</li>
<li><strong>Dependencies:</strong> [List]</li>
</ul>

<h3>Architecture Decisions (ADRs)</h3>
<ac:structured-macro ac:name="children" ac:schema-version="2">
  <ac:parameter ac:name="all">true</ac:parameter>
  <ac:parameter ac:name="sort">title</ac:parameter>
</ac:structured-macro>
""",
            },
            {
                "title": "Getting Started",
                "content": f"""
<h2>{product} - Getting Started</h2>

<h3>Prerequisites</h3>
<ul>
<li>Requirement 1</li>
<li>Requirement 2</li>
</ul>

<h3>Installation</h3>
<ac:structured-macro ac:name="code" ac:schema-version="1">
  <ac:parameter ac:name="language">bash</ac:parameter>
  <ac:plain-text-body><![CDATA[# Installation commands
]]></ac:plain-text-body>
</ac:structured-macro>

<h3>Quick Start</h3>
<ol>
<li>Step 1</li>
<li>Step 2</li>
<li>Step 3</li>
</ol>

<h3>Configuration</h3>
<p>[Configuration guide]</p>

<h3>Examples</h3>
<ac:structured-macro ac:name="code" ac:schema-version="1">
  <ac:parameter ac:name="language">cpp</ac:parameter>
  <ac:plain-text-body><![CDATA[// Example code
]]></ac:plain-text-body>
</ac:structured-macro>

<h3>Next Steps</h3>
<ul>
<li><ac:link><ri:page ri:content-title="Features"/><ac:plain-text-link-body><![CDATA[Explore Features]]></ac:plain-text-link-body></ac:link></li>
<li><ac:link><ri:page ri:content-title="Architecture"/><ac:plain-text-link-body><![CDATA[Understand Architecture]]></ac:plain-text-link-body></ac:link></li>
</ul>
""",
            },
            {
                "title": "API Reference",
                "content": f"""
<h2>{product} - API Reference</h2>

<h3>REST API</h3>
<p>[REST API documentation]</p>

<h3>gRPC API</h3>
<p>[gRPC API documentation]</p>

<h3>Authentication</h3>
<p>[How to authenticate]</p>

<h3>Rate Limits</h3>
<p>[Rate limit policies]</p>

<h3>Error Handling</h3>
<p>[Error codes and handling]</p>
""",
            },
            {
                "title": "Operations",
                "content": f"""
<h2>{product} - Operations</h2>

<h3>Deployment</h3>
<p>[Deployment procedures]</p>

<h3>Monitoring</h3>
<p>[Monitoring setup and dashboards]</p>

<h3>Troubleshooting</h3>
<p>[Common issues and solutions]</p>

<h3>Backup & Recovery</h3>
<p>[Backup procedures]</p>

<h3>Performance Tuning</h3>
<p>[Performance optimization]</p>
""",
            },
            {
                "title": "Release Notes",
                "content": f"""
<h2>{product} - Release Notes</h2>
<p>Release history for {product}.</p>

<h3>Releases</h3>
<ac:structured-macro ac:name="children" ac:schema-version="2">
  <ac:parameter ac:name="all">true</ac:parameter>
  <ac:parameter ac:name="sort">title</ac:parameter>
  <ac:parameter ac:name="reverse">true</ac:parameter>
</ac:structured-macro>
""",
            },
            {
                "title": "Glossary",
                "content": f"""
<h2>{product} - Glossary</h2>

<h3>Terms</h3>

<h4>Term 1</h4>
<ul>
<li><strong>Definition:</strong> [Clear, concise definition]</li>
<li><strong>Example:</strong> [Usage example]</li>
<li><strong>Related:</strong> [Links to related terms]</li>
</ul>

<h4>Term 2</h4>
<ul>
<li><strong>Definition:</strong> [Clear, concise definition]</li>
<li><strong>Example:</strong> [Usage example]</li>
</ul>
""",
            },
            {
                "title": "FAQ",
                "content": f"""
<h2>{product} - FAQ</h2>

<h3>General Questions</h3>

<h4>Q: Question 1?</h4>
<p><strong>A:</strong> Answer...</p>

<h3>Technical Questions</h3>

<h4>Q: Technical question?</h4>
<p><strong>A:</strong> Answer...</p>

<h3>Troubleshooting</h3>

<h4>Q: Common issue?</h4>
<p><strong>A:</strong> Solution...</p>
""",
            },
        ]

        # Find Product Portfolio
        portfolio_id = self._confluence.find_page_by_title(
            "INOV", "Product Portfolio - Source of Truth"
        )
        if not portfolio_id:
            print("❌ ERROR: Product Portfolio page not found!")
            return 1

        # Find or create product page
        children = self._confluence.get_child_pages(portfolio_id)
        product_page = None
        for child in children:
            if child.title == product:
                product_page = child.page_id  # Already a ConfluencePageId
                break

        if not product_page:
            print(f"⚠️  Product page '{product}' not found")
            if dry_run:
                print("   [DRY-RUN] Would create product page")
                print("\n📄 Standard Pages to Create:")
                print("-" * 70)
                for page_spec in standard_pages:
                    print(f"  [DRY-RUN] Would create: {page_spec['title']}")
                print("\n" + "=" * 70)
                print("📊 Summary:")
                print(f"  Total pages: {len(standard_pages)}")
                print("\n🔍 DRY-RUN MODE: No changes were made")
                print("   Use --execute to create pages")
                print("=" * 70)
                return 0
            else:
                print("   Creating product page...")
                product_page = self._confluence.create_page(
                    "INOV",
                    product,
                    f"""
<h2>{product} Product</h2>
<p>Documentation for the <strong>{product}</strong> bounded context.</p>
<h3>Organization</h3>
<ul>
<li><strong>Features</strong> - Feature-level documentation (manual)</li>
<li><strong>Architecture</strong> - Technical architecture and design (manual)</li>
<li><strong>Stories</strong> - Jira story documentation (automatic)</li>
</ul>
<hr/>
<ac:structured-macro ac:name="children" ac:schema-version="2">
  <ac:parameter ac:name="all">true</ac:parameter>
  <ac:parameter ac:name="sort">title</ac:parameter>
</ac:structured-macro>
""",
                    parent_page_id=portfolio_id,
                )
                print("   ✅ Created product page")
        else:
            print(f"✅ Found product page: {product}")

        # Get existing child pages to avoid duplicates
        existing_children = self._confluence.get_child_pages(product_page)
        existing_titles = {child.title for child in existing_children}

        # Create pages
        print("\n📄 Standard Pages to Create:")
        print("-" * 70)

        for page_spec in standard_pages:
            title = page_spec["title"]
            content = page_spec["content"]

            # Check if page already exists as child
            if title in existing_titles:
                print(f"  ⊗ {title} (already exists)")
            else:
                if dry_run:
                    print(f"  [DRY-RUN] Would create: {title}")
                else:
                    try:
                        self._confluence.create_page(
                            "INOV", title, content, parent_page_id=product_page
                        )
                        print(f"  ✅ Created: {title}")
                    except Exception as e:  # type: ignore
                        error_msg = str(e)
                        if "already exists" in error_msg.lower():
                            print(f"  ⊗ {title} (already exists elsewhere in space)")
                        else:
                            print(f"  ❌ Failed to create {title}: {e}")

        print("\n" + "=" * 70)
        print("📊 Summary:")
        print(f"  Total pages: {len(standard_pages)}")
        if dry_run:
            print("\n🔍 DRY-RUN MODE: No changes were made")
            print("   Use --execute to create pages")
        else:
            print("\n✅ PRODUCT DOCUMENTATION STRUCTURE CREATED!")
        print("=" * 70)
        return 0


class TransitionCommandHandler:
    """Handles 'transition' command"""

    def __init__(self, service: IssueTransitionService):
        self._service = service

    def handle_transition(self, issue_key: str, transition_name: str, execute: bool = False) -> int:
        """Handle CLI 'transition' command"""
        request = TransitionIssueRequest(
            issue_key=issue_key, transition_name=transition_name, execute=execute
        )

        result = self._service.transition_issue(request)

        if result.success and result.value:
            data = result.value
            print(f"✅ Transition: {data.issue_key}")
            print(f"  From: {data.from_status}")
            print(f"  To: {data.to_status}")
            print(f"  Status: {'Executed' if data.success else 'Preview (Dry Run)'}")

            if not execute:
                print("\n💡 Use --execute to apply the transition")

            return 0
        elif not result.success:
            print(f"❌ Transition failed: {result.error}")
            for error in result.errors:
                print(f"  - {error}")
            return 1
        else:
            print("❌ Transition failed: No response data received")
            return 1

        return 0


class ConfluenceCommandHandler:
    """Handles 'confluence' commands for direct Confluence page operations"""

    def __init__(self, confluence: ConfluencePageRepository):
        self._confluence = confluence

    def handle_get(self, page_id: str) -> int:
        """Get and display a Confluence page's content"""
        page = self._confluence.get_page(ConfluencePageId(page_id))
        if not page:
            print(f"❌ Page {page_id} not found")
            return 1

        print(f"📄 Title: {page.title}")
        print(f"🆔 Page ID: {page.page_id.page_id}")
        print(f"📦 Space: {page.space_key}")
        print(f"📊 Version: {page.version}")
        print(f"📏 Content length: {len(page.content)} chars")
        print("=" * 70)
        print(page.content)
        return 0

    def handle_children(self, page_id: str) -> int:
        """List child pages of a Confluence page"""
        children = self._confluence.get_child_pages(ConfluencePageId(page_id))
        if not children:
            print(f"📭 No child pages found under {page_id}")
            return 0

        print(f"📚 Child pages of {page_id}:")
        print("-" * 70)
        for child in children:
            print(f"  📄 {child.title}")
            print(
                f"     ID: {child.page_id.page_id} | Version: {child.version} | Content: {len(child.content)} chars"
            )
        print(f"\nTotal: {len(children)} child pages")
        return 0

    def handle_find(self, space_key: str, title: str) -> int:
        """Find a page by title in a space"""
        page_id = self._confluence.find_page_by_title(space_key, title)
        if not page_id:
            print(f"❌ Page '{title}' not found in space {space_key}")
            return 1

        print(f"✅ Found: {title}")
        print(f"🆔 Page ID: {page_id.page_id}")
        url = self._confluence.get_page_url(page_id)
        print(f"🔗 URL: {url}")
        return 0

    def handle_create(
        self,
        space_key: str,
        title: str,
        content_file: str | None = None,
        content: str | None = None,
        parent_id: str | None = None,
        markdown: bool = False,
        dry_run: bool = True,
    ) -> int:
        """Create a new Confluence page"""
        # Resolve content
        page_content = self._resolve_content(content_file, content, markdown)
        if page_content is None:
            return 1

        parent = ConfluencePageId(parent_id) if parent_id else None

        print(f"📝 Creating page: '{title}'")
        print(f"   Space: {space_key}")
        print(f"   Parent: {parent_id or '(root)'}")
        print(f"   Content: {len(page_content)} chars")

        if dry_run:
            print("\n🔍 DRY RUN — use --execute to create the page")
            print("=" * 70)
            print(page_content[:2000])
            if len(page_content) > 2000:
                print(f"\n... ({len(page_content) - 2000} more chars)")
            return 0

        try:
            new_page_id = self._confluence.create_page(space_key, title, page_content, parent)
            url = self._confluence.get_page_url(new_page_id)
            print("✅ Page created!")
            print(f"🆔 Page ID: {new_page_id.page_id}")
            print(f"🔗 URL: {url}")
            return 0
        except (OSError, RuntimeError) as e:
            print(f"❌ Failed to create page: {e}")
            return 1

    def handle_update(
        self,
        page_id: str,
        content_file: str | None = None,
        content: str | None = None,
        title: str | None = None,
        parent_id: str | None = None,
        markdown: bool = False,
        append: bool = False,
        dry_run: bool = True,
    ) -> int:
        """Update an existing Confluence page"""
        # Get current page first
        current = self._confluence.get_page(ConfluencePageId(page_id))
        if not current:
            print(f"❌ Page {page_id} not found")
            return 1

        # Resolve content
        new_content = self._resolve_content(content_file, content, markdown)
        if new_content is None:
            # If no content provided, keep existing
            if not title and not parent_id:
                print("❌ Must provide --content-file, --content, --title, or --parent-id")
                return 1
            new_content = current.content

        # Append mode: add to existing content
        if append:
            new_content = current.content + "\n" + new_content

        page_title = title or current.title
        parent = ConfluencePageId(parent_id) if parent_id else None

        print(f"📝 Updating page: '{current.title}'")
        print(f"   Page ID: {page_id}")
        print(f"   Version: {current.version} → {current.version + 1}")
        if title and title != current.title:
            print(f"   Title: '{current.title}' → '{title}'")
        if parent_id:
            print(f"   Move to parent: {parent_id}")
        print(f"   Content: {len(current.content)} → {len(new_content)} chars")

        if dry_run:
            print("\n🔍 DRY RUN — use --execute to apply changes")
            print("=" * 70)
            print(new_content[:3000])
            if len(new_content) > 3000:
                print(f"\n... ({len(new_content) - 3000} more chars)")
            return 0

        try:
            success = self._confluence.update_page(
                ConfluencePageId(page_id), page_title, new_content, parent
            )
            if success:
                url = self._confluence.get_page_url(ConfluencePageId(page_id))
                print("✅ Page updated!")
                print(f"🔗 URL: {url}")
                return 0
            else:
                print("❌ Failed to update page")
                return 1
        except (OSError, RuntimeError) as e:
            print(f"❌ Failed to update page: {e}")
            return 1

    def _resolve_content(
        self,
        content_file: str | None,
        content: str | None,
        markdown: bool,
    ) -> str | None:
        """Resolve page content from file or inline string"""
        if content_file:
            try:
                with open(content_file, encoding="utf-8") as f:
                    raw = f.read()
            except FileNotFoundError:
                print(f"❌ File not found: {content_file}")
                return None
            except OSError as e:
                print(f"❌ Failed to read file: {e}")
                return None

            if markdown:
                return self._markdown_to_confluence_storage(raw)
            return raw

        if content:
            if markdown:
                return self._markdown_to_confluence_storage(content)
            return content

        return None

    @staticmethod
    def _markdown_to_confluence_storage(md: str) -> str:
        """Convert markdown to Confluence storage format (XHTML).

        Handles the most common markdown constructs:
        - Headings (# → <h1>, ## → <h2>, etc.)
        - Bold (**text**), italic (*text*)
        - Inline code (`code`)
        - Code blocks (```language ... ```)
        - Unordered lists (- item)
        - Ordered lists (1. item)
        - Horizontal rules (---)
        - Links [text](url)
        - Tables (| col | col |)
        - Blockquotes (> text)
        """
        import re

        lines = md.split("\n")
        html_lines: list[str] = []
        in_code_block = False
        code_lang = ""
        code_lines: list[str] = []
        in_ul = False
        in_ol = False
        in_table = False
        table_header_done = False

        def close_list() -> None:
            nonlocal in_ul, in_ol
            if in_ul:
                html_lines.append("</ul>")
                in_ul = False
            if in_ol:
                html_lines.append("</ol>")
                in_ol = False

        def close_table() -> None:
            nonlocal in_table, table_header_done
            if in_table:
                html_lines.append("</tbody></table>")
                in_table = False
                table_header_done = False

        def inline_format(text: str) -> str:
            """Apply inline markdown formatting"""
            # Links: [text](url)
            text = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', text)
            # Bold: **text**
            text = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)
            # Italic: *text* (but not inside **)
            text = re.sub(r"(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)", r"<em>\1</em>", text)
            # Inline code: `code`
            text = re.sub(r"`([^`]+)`", r"<code>\1</code>", text)
            return text

        for line in lines:
            # Code blocks
            if line.strip().startswith("```"):
                if in_code_block:
                    # End code block
                    code_content = "\n".join(code_lines)
                    # Escape for CDATA
                    code_content = code_content.replace("]]>", "]]]]><![CDATA[>")
                    html_lines.append(
                        f'<ac:structured-macro ac:name="code" ac:schema-version="1">'
                        f'<ac:parameter ac:name="language">{code_lang or "text"}</ac:parameter>'
                        f"<ac:plain-text-body><![CDATA[{code_content}]]></ac:plain-text-body>"
                        f"</ac:structured-macro>"
                    )
                    in_code_block = False
                    code_lines = []
                    code_lang = ""
                else:
                    close_list()
                    close_table()
                    in_code_block = True
                    code_lang = line.strip()[3:].strip()
                continue

            if in_code_block:
                code_lines.append(line)
                continue

            stripped = line.strip()

            # Empty line
            if not stripped:
                close_list()
                close_table()
                continue

            # Horizontal rule
            if re.match(r"^-{3,}$", stripped) or re.match(r"^\*{3,}$", stripped):
                close_list()
                close_table()
                html_lines.append("<hr/>")
                continue

            # Headings
            heading_match = re.match(r"^(#{1,6})\s+(.+)", stripped)
            if heading_match:
                close_list()
                close_table()
                level = len(heading_match.group(1))
                text = inline_format(heading_match.group(2))
                html_lines.append(f"<h{level}>{text}</h{level}>")
                continue

            # Table rows
            if stripped.startswith("|") and stripped.endswith("|"):
                close_list()
                # Check if separator row (| --- | --- |)
                if re.match(r"^\|[\s\-:]+\|", stripped):
                    table_header_done = True
                    continue

                cells = [c.strip() for c in stripped.strip("|").split("|")]

                if not in_table:
                    in_table = True
                    table_header_done = False
                    html_lines.append("<table><tbody>")
                    # First row is header
                    tag = "th"
                    cell_html = "".join(f"<{tag}>{inline_format(c)}</{tag}>" for c in cells)
                    html_lines.append(f"<tr>{cell_html}</tr>")
                    continue

                tag = "td"
                cell_html = "".join(f"<{tag}>{inline_format(c)}</{tag}>" for c in cells)
                html_lines.append(f"<tr>{cell_html}</tr>")
                continue

            close_table()

            # Blockquote
            if stripped.startswith(">"):
                close_list()
                text = inline_format(stripped[1:].strip())
                html_lines.append(f"<blockquote><p>{text}</p></blockquote>")
                continue

            # Unordered list
            ul_match = re.match(r"^[\-\*]\s+(.+)", stripped)
            if ul_match:
                if in_ol:
                    html_lines.append("</ol>")
                    in_ol = False
                if not in_ul:
                    html_lines.append("<ul>")
                    in_ul = True
                html_lines.append(f"<li>{inline_format(ul_match.group(1))}</li>")
                continue

            # Ordered list
            ol_match = re.match(r"^\d+\.\s+(.+)", stripped)
            if ol_match:
                if in_ul:
                    html_lines.append("</ul>")
                    in_ul = False
                if not in_ol:
                    html_lines.append("<ol>")
                    in_ol = True
                html_lines.append(f"<li>{inline_format(ol_match.group(1))}</li>")
                continue

            # Regular paragraph
            close_list()
            html_lines.append(f"<p>{inline_format(stripped)}</p>")

        # Close any open structures
        close_list()
        close_table()

        return "\n".join(html_lines)
