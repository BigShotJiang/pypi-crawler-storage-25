"""Unified ``atlassiancli review <KEY>`` — runs every story-time check.

Composes the three story-time gates into a single agent-callable command
so the autonomous-dev system can replace this:

    atlassiancli --json analyze ready <KEY>
    atlassiancli --json analyze sop <KEY>
    atlassiancli --json analyze architecture <KEY>

with a single call:

    atlassiancli --json review <KEY>

Returned envelope merges every finding from the three sources, namespaces
the rule ids so the operator can tell which check fired (``ready.*`` /
``sop.*`` / ``architecture.*``), and reports a single composite verdict
under the standard worst-of ordering: ``FAIL`` > ``NOT_READY`` > ``WARN``
> ``PASS`` > ``READY``.
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING

from ..application.agent_response import AgentFinding, AgentResponse

if TYPE_CHECKING:
    from .composition_root import CompositionRoot


# Worst-of ordering, ascending severity. Higher rank = worse outcome.
# READY/PASS rank below WARN; the gate counts a clean ready pass as
# benign even if the SOP check returns READY (semantically the same).
_VERDICT_RANK = {
    None: 0,
    "PASS": 1,
    "READY": 1,
    "WARN": 2,
    "NOT_READY": 3,
    "FAIL": 4,
}


def review_to_json(
    container: CompositionRoot,
    issue_key: str,
    *,
    manifest_path: str | None = None,
    skip_sop: bool = False,
    skip_architecture: bool = False,
) -> AgentResponse:
    """Run every story-time check and return a single merged envelope.

    ``skip_sop`` / ``skip_architecture`` are escape hatches for projects
    that haven't bootstrapped a SOP manifest or aren't using the Inovagio-
    style architecture pattern pack — both default off so the standard
    autonomous-dev flow gets the full review.
    """
    started = time.monotonic()
    sources: list[tuple[str, AgentResponse]] = []

    # 1. Ready (composite of lint + atomicity + section presence).
    from .agent_adapter import ready_to_json

    sources.append(("ready", ready_to_json(container, issue_key)))

    # 2. SOP story-time check.
    if not skip_sop:
        from .sop_adapter import sop_story_check_to_json

        sources.append(
            (
                "sop",
                sop_story_check_to_json(container, issue_key, manifest_path=manifest_path),
            )
        )

    # 3. Architecture review (pattern-matches integrations against the
    #    architecture pattern pack).
    if not skip_architecture:
        from .agent_adapter import architecture_to_json

        sources.append(("architecture", architecture_to_json(container, issue_key)))

    merged_findings: list[AgentFinding] = []
    per_source: dict[str, dict] = {}
    worst_rank = 0
    worst_verdict: str | None = None

    for source_name, response in sources:
        rank = _VERDICT_RANK.get(response.verdict, 0)
        if rank > worst_rank:
            worst_rank = rank
            worst_verdict = response.verdict
        per_source[source_name] = {
            "verdict": response.verdict,
            "finding_count": len(response.findings),
            "metadata": response.metadata,
        }
        # Namespace each finding's rule with its source so callers can
        # filter / route findings without re-parsing.
        for finding in response.findings:
            merged_findings.append(
                AgentFinding(
                    severity=finding.severity,
                    rule=f"{source_name}.{finding.rule}",
                    section=finding.section,
                    message=finding.message,
                    fix_hint=finding.fix_hint,
                )
            )

    elapsed_ms = int((time.monotonic() - started) * 1000)

    return AgentResponse(
        command="review",
        issue_key=issue_key,
        verdict=worst_verdict,
        score=None,
        threshold=None,
        findings=merged_findings,
        metadata={
            "elapsed_ms": elapsed_ms,
            "sources_run": [name for name, _ in sources],
            "per_source": per_source,
            "blocking_finding_count": sum(
                1 for f in merged_findings if f.severity in ("critical", "major")
            ),
            "total_finding_count": len(merged_findings),
        },
    )
