#!/usr/bin/env python3
"""
Atlassian CLI v3 - Main Entry Point

Enterprise-grade CLI for Jira/Confluence operations.
Built with Domain-Driven Design, SOLID principles, and dependency injection.

Architecture:
- Domain layer: Pure business logic
- Infrastructure layer: Concrete implementations
- Application layer: Use cases
- CLI layer: Command handlers

Author: Inovagio Engineering Team
Version: 3.0.0
"""

import argparse
import json as _json
import sys
import traceback
from typing import Any

from atlassiancli import __version__

from ..application.agent_response import AgentFinding, AgentResponse
from ..infrastructure.http_client import (
    HttpAuthError,
    HttpClientError,
    HttpError,
    HttpRateLimitError,
    HttpTransientError,
)
from . import agent_adapter
from .composition_root import CompositionRoot
from .handlers import (
    AnalysisCommandHandler,
    AutomationCommandHandler,
    BalanceCommandHandler,
    ConfluenceCommandHandler,
    ContextCommandHandler,
    CreateCommandHandler,
    DashboardCommandHandler,
    DeleteCommandHandler,
    DocsCommandHandler,
    GoalsCommandHandler,
    ImportCommandHandler,
    OperationsCommandHandler,
    PrepareCommandHandler,
    ProductDocsCommandHandler,
    RemoveLabelCommandHandler,
    ReorganizeCommandHandler,
    ReportingCommandHandler,
    SplittingCommandHandler,
    SprintCommandHandler,
    StandardizeCommandHandler,
    TemplateCommandHandler,
    TransitionCommandHandler,
    VerificationCommandHandler,
)


def _add_review_args(subparsers: Any) -> None:
    """``atlassiancli review <KEY>`` — unified story-time review.

    Composes ``analyze ready`` + ``analyze sop`` + ``analyze architecture``
    into a single command + envelope. The autonomous-dev DevCycle Phase 2
    calls this instead of three separate commands.
    """
    review_parser = subparsers.add_parser(
        "review",
        help=(
            "Unified story-time review: runs ready + SOP + architecture "
            "checks and merges findings into one JSON envelope."
        ),
    )
    review_parser.add_argument("issue_key", help="Issue key (e.g., INOV-123)")
    review_parser.add_argument(
        "--manifest",
        dest="sop_manifest",
        default=None,
        help="Path to sops/sop-manifest.yaml (default: sops/sop-manifest.yaml)",
    )
    review_parser.add_argument(
        "--skip-sop",
        action="store_true",
        help="Skip the SOP story-time check (for projects without a manifest).",
    )
    review_parser.add_argument(
        "--skip-architecture",
        action="store_true",
        help="Skip the architecture pattern review.",
    )


def _add_configure_args(subparsers: Any) -> None:
    """``atlassiancli configure`` — interactive credential wizard."""
    cfg = subparsers.add_parser(
        "configure",
        help=(
            "Interactive credential wizard. Prompts for site / email / token, "
            "verifies the credential, and saves a profile under "
            "~/.atlassiancli/<name>.toml."
        ),
    )
    cfg.add_argument(
        "--profile",
        dest="configure_profile",
        default=None,
        help="Profile name to write (default: 'default').",
    )
    cfg.add_argument(
        "--no-verify",
        action="store_true",
        help="Skip the credential round-trip against /rest/api/3/myself.",
    )


def _add_create_args(subparsers: Any) -> None:
    """Add arguments for 'create' command"""
    create_cmd_parser = subparsers.add_parser("create", help="Create issues")
    create_subparsers = create_cmd_parser.add_subparsers(dest="issue_type", help="Issue type")

    # CREATE EPIC
    epic_parser = create_subparsers.add_parser("epic", help="Create an epic")
    epic_parser.add_argument("--title", required=True, help="Epic title")
    epic_parser.add_argument("--description", required=True, help="Epic description")
    epic_parser.add_argument("--objective", required=True, help="Business objective")
    epic_parser.add_argument(
        "--kpi", action="append", dest="kpis", default=[], help="KPI (repeatable)"
    )
    epic_parser.add_argument(
        "--in-scope", action="append", default=[], help="In-scope item (repeatable)"
    )
    epic_parser.add_argument(
        "--out-of-scope",
        action="append",
        default=[],
        help="Out-of-scope item (repeatable)",
    )
    epic_parser.add_argument("--architecture", help="Architecture document link")
    epic_parser.add_argument(
        "--theme", action="append", dest="themes", default=[], help="Theme (repeatable)"
    )
    epic_parser.add_argument(
        "--priority",
        default="medium",
        choices=["highest", "high", "medium", "low", "lowest"],
        help="Priority",
    )

    # CREATE STORY
    story_parser = create_subparsers.add_parser("story", help="Create a story")
    story_parser.add_argument("--title", required=True, help="Story title")
    story_parser.add_argument("--description", required=True, help="Story description")
    story_parser.add_argument("--epic", dest="epic_key", help="Parent epic key (e.g., INOV-123)")
    story_parser.add_argument("--points", type=int, dest="story_points", help="Story points (1-8)")
    story_parser.add_argument("--sprint", type=int, dest="sprint_number", help="Sprint number")
    story_parser.add_argument(
        "--ac",
        action="append",
        dest="acceptance_criteria",
        default=[],
        help="Acceptance criterion (repeatable)",
    )
    story_parser.add_argument(
        "--module",
        action="append",
        dest="affected_modules",
        default=[],
        help="Affected module (repeatable)",
    )
    story_parser.add_argument(
        "--integration",
        action="append",
        dest="integration_points",
        default=[],
        help="Integration point (repeatable)",
    )
    story_parser.add_argument(
        "--theme", action="append", dest="themes", default=[], help="Theme (repeatable)"
    )
    story_parser.add_argument(
        "--priority",
        default="medium",
        choices=["highest", "high", "medium", "low", "lowest"],
        help="Priority",
    )

    # CREATE TASK
    task_parser = create_subparsers.add_parser("task", help="Create a task")
    task_parser.add_argument("--title", required=True, help="Task title")
    task_parser.add_argument("--description", required=True, help="Task description")
    task_parser.add_argument(
        "--parent",
        required=True,
        dest="parent_story_key",
        help="Parent story key (e.g., INOV-456)",
    )
    task_parser.add_argument(
        "--step",
        action="append",
        dest="implementation_steps",
        default=[],
        help="Implementation step (repeatable)",
    )
    task_parser.add_argument("--hours", type=float, dest="estimated_hours", help="Estimated hours")
    task_parser.add_argument(
        "--priority",
        default="medium",
        choices=["highest", "high", "medium", "low", "lowest"],
        help="Priority",
    )

    # CREATE VERSION
    version_parser = create_subparsers.add_parser("version", help="Create a release version")
    version_parser.add_argument("--name", required=True, help="Version name (e.g., v1.0.0-alpha)")
    version_parser.add_argument("--description", required=True, help="Version description")
    version_parser.add_argument("--project-id", required=True, help="Jira project ID (numeric)")
    version_parser.add_argument("--start-date", help="Start date (YYYY-MM-DD)")
    version_parser.add_argument("--release-date", help="Target release date (YYYY-MM-DD)")
    version_parser.add_argument("--released", action="store_true", help="Mark as released")
    version_parser.add_argument("--archived", action="store_true", help="Mark as archived")


def _add_enhance_args(subparsers: Any) -> None:
    """Add arguments for 'enhance' command"""
    enhance_parser = subparsers.add_parser("enhance", help="Enhance an issue with expert analysis")
    # Group is non-required because PR 4 adds an alternative agent
    # surface — a positional ``agent_issue_key`` — that main() validates.
    enhance_group = enhance_parser.add_mutually_exclusive_group(required=False)
    enhance_group.add_argument("--issue", dest="issue_key", help="Issue key (e.g., INOV-123)")
    enhance_group.add_argument("--sprint", type=int, dest="sprint_number", help="Enhance sprint")
    enhance_parser.add_argument(
        "--execute", action="store_true", help="Apply enhancements (default: dry-run)"
    )
    enhance_parser.add_argument(
        "--force",
        action="store_true",
        help="Force re-enhancement of already-enhanced issues",
    )
    enhance_parser.add_argument(
        "--with-docs", action="store_true", help="Also create Confluence docs"
    )
    enhance_parser.add_argument(
        "--update-metadata",
        action="store_true",
        help="Update Priority, Labels, Components, and Story Points",
    )
    enhance_parser.add_argument(
        "--check", action="store_true", help="Check if already enhanced (no changes)"
    )
    enhance_parser.add_argument(
        "--preview",
        action="store_true",
        help="Preview enhanced description without applying",
    )
    enhance_parser.add_argument(
        "--apply-architecture",
        action="store_true",
        help="Apply proposed architecture requirements (acceptance criteria + NFRs)",
    )
    enhance_parser.add_argument(
        "--no-auto-quality",
        action="store_true",
        help="Disable automatic quality analysis + concise professional rewrite",
    )
    # Agent-callable surface (PLAN §6.2): plain ``enhance <KEY>`` with
    # ``--apply`` / ``--dry-run``. Kept compatible with the existing
    # ``--issue`` / ``--sprint`` group above by treating the positional
    # as a third (optional) input — main() resolves precedence.
    enhance_parser.add_argument(
        "agent_issue_key",
        nargs="?",
        default=None,
        help="Issue key (agent surface, e.g. INOV-123)",
    )
    enhance_parser.add_argument(
        "--apply",
        action="store_true",
        dest="apply_agent",
        help="Apply the proposed enhancement (writes to Jira). Default is dry-run.",
    )
    enhance_parser.add_argument(
        "--dry-run",
        action="store_true",
        dest="dry_run_agent",
        help="Generate the proposed enhancement without writing to Jira (default).",
    )


def _add_docs_args(subparsers: Any) -> None:
    """Add arguments for 'docs' command"""
    docs_parser = subparsers.add_parser("docs", help="Create Confluence documentation")
    docs_parser.add_argument("issue_key", help="Issue key (e.g., INOV-123)")
    docs_parser.add_argument(
        "--spec", action="store_true", dest="include_spec", help="Create story spec"
    )
    docs_parser.add_argument(
        "--testplan",
        action="store_true",
        dest="include_testplan",
        help="Create test plan",
    )
    docs_parser.add_argument(
        "--runbook", action="store_true", dest="include_runbook", help="Create runbook"
    )
    docs_parser.add_argument("--all", action="store_true", help="Create all documentation types")
    docs_parser.add_argument("--analyze", action="store_true", help="Analyze only")
    docs_parser.add_argument("--execute", action="store_true", help="Create pages")


def _add_delete_args(subparsers: Any) -> None:
    """Add arguments for 'delete' command"""
    delete_parser = subparsers.add_parser("delete", help="Delete issues (with safeguards)")
    delete_parser.add_argument("issue_keys", nargs="+", help="Issue keys to delete")
    delete_parser.add_argument(
        "--no-subtasks",
        action="store_false",
        dest="delete_subtasks",
        help="Do not delete subtasks",
    )
    delete_parser.add_argument(
        "--force", action="store_true", help="Force bulk deletion (>10 issues)"
    )
    delete_parser.add_argument(
        "--execute", action="store_false", dest="dry_run", help="Execute deletion"
    )


def _add_analyze_args(subparsers: Any) -> None:
    """Add arguments for 'analyse' / 'analyze' command.

    The PLAN-§6.2 spelling is British (``analyse``); ``analyze`` is kept
    as an alias for backward compatibility.
    """
    analyze_parser = subparsers.add_parser("analyse", aliases=["analyze"], help="Analyse issues")
    analyze_subparsers = analyze_parser.add_subparsers(dest="analyze_type", help="Analysis type")

    # LINT
    lint_parser = analyze_subparsers.add_parser("lint", help="Lint issue for AI readiness")
    lint_parser.add_argument("issue_key", help="Issue key (e.g., INOV-123)")

    # ATOMICITY
    atomicity_parser = analyze_subparsers.add_parser("atomicity", help="Analyze story atomicity")
    atomicity_parser.add_argument("issue_key", help="Issue key (e.g., INOV-123)")

    # DESCRIPTION
    description_parser = analyze_subparsers.add_parser(
        "description", help="Analyze description quality"
    )
    description_parser.add_argument("--text", required=True, help="Description text to analyze")

    # ARCHITECTURE
    arch_parser = analyze_subparsers.add_parser(
        "architecture", help="PhD-level architecture review"
    )
    arch_parser.add_argument("issue_key", help="Issue key (e.g., INOV-123)")
    arch_parser.add_argument(
        "--real-run",
        action="store_true",
        help="Enable write mode (future: add comments/labels)",
    )

    # READY (composite Definition-of-Ready gate — agent-callable)
    ready_parser = analyze_subparsers.add_parser(
        "ready",
        help="Composite gate: lint >=80 AND atomic AND all 11 sections present",
    )
    ready_parser.add_argument("issue_key", help="Issue key (e.g., INOV-123)")

    # FETCH (full structured story content for agent consumption)
    fetch_parser = analyze_subparsers.add_parser(
        "fetch", help="Fetch full structured story content as JSON"
    )
    fetch_parser.add_argument("issue_key", help="Issue key (e.g., INOV-123)")

    # SOP (Phase 2 story-time SOP review against sops/sop-manifest.yaml)
    sop_parser = analyze_subparsers.add_parser(
        "sop",
        help=(
            "Verify story has every required section declared in the SOP "
            "manifest. Returns READY / NOT_READY for the autonomous-dev "
            "Phase 2 gate."
        ),
    )
    sop_parser.add_argument("issue_key", help="Issue key (e.g., INOV-123)")
    sop_parser.add_argument(
        "--manifest",
        dest="sop_manifest",
        default=None,
        help="Path to sop-manifest.yaml (default: sops/sop-manifest.yaml)",
    )


def _add_import_args(subparsers: Any) -> None:
    """Add arguments for 'import' command"""
    import_parser = subparsers.add_parser("import", help="Import issues from files")
    import_subparsers = import_parser.add_subparsers(dest="import_type", help="Import type")

    # IMPORT MARKDOWN
    import_md_parser = import_subparsers.add_parser("markdown", help="Import from Markdown")
    import_md_parser.add_argument("file_path", help="Path to markdown file")
    import_md_parser.add_argument(
        "--execute", action="store_false", dest="dry_run", help="Execute import"
    )
    import_md_parser.add_argument(
        "--with-docs", action="store_true", help="Also generate Confluence docs"
    )
    import_md_parser.add_argument("--auto", action="store_true", help="Full auto workflow")

    # IMPORT YAML
    import_yaml_parser = import_subparsers.add_parser("yaml", help="Import from YAML")
    import_yaml_parser.add_argument("file_path", help="Path to YAML file")
    import_yaml_parser.add_argument(
        "--execute", action="store_false", dest="dry_run", help="Execute import"
    )
    import_yaml_parser.add_argument(
        "--with-docs", action="store_true", help="Also generate Confluence docs"
    )

    # IMPORT CONFLUENCE
    import_confluence_parser = import_subparsers.add_parser(
        "confluence", help="Import from Confluence"
    )
    import_confluence_parser.add_argument("page_id", help="Confluence page ID or URL")
    import_confluence_parser.add_argument(
        "--include-children", action="store_true", help="Import child pages"
    )
    import_confluence_parser.add_argument(
        "--execute", action="store_false", dest="dry_run", help="Execute import"
    )
    import_confluence_parser.add_argument("--sprint", type=int, help="Assign to this sprint")
    import_confluence_parser.add_argument(
        "--epic-only", action="store_true", help="Create epic only"
    )
    import_confluence_parser.add_argument("--with-docs", action="store_true", help="Generate docs")
    import_confluence_parser.add_argument(
        "--verbose", "-v", action="store_true", help="Show parsed sections"
    )
    import_confluence_parser.add_argument(
        "--min-content-length", type=int, default=100, help="Min content length"
    )
    import_confluence_parser.add_argument(
        "--skip-duplicate-check", action="store_true", help="Skip duplicate check"
    )
    import_confluence_parser.add_argument(
        "--validate-codebase", action="store_true", help="Cross-reference codebase"
    )
    import_confluence_parser.add_argument(
        "--analyze-backlog", action="store_true", help="Backlog scan"
    )


def _add_report_args(subparsers: Any) -> None:
    """Add arguments for 'report' command"""
    report_parser = subparsers.add_parser("report", help="Generate reports")
    report_subparsers = report_parser.add_subparsers(dest="report_type", help="Report type")

    # REPORT QUALITY
    report_quality_parser = report_subparsers.add_parser("quality", help="Quality metrics report")
    report_quality_parser.add_argument(
        "--start", type=int, required=True, dest="start_sprint", help="Start sprint"
    )
    report_quality_parser.add_argument(
        "--end", type=int, required=True, dest="end_sprint", help="End sprint"
    )
    report_quality_parser.add_argument(
        "--format",
        default="text",
        choices=["text", "markdown", "json"],
        help="Output format",
    )

    # REPORT VELOCITY
    report_velocity_parser = report_subparsers.add_parser("velocity", help="Velocity report")
    report_velocity_parser.add_argument(
        "--start", type=int, required=True, dest="start_sprint", help="Start sprint"
    )
    report_velocity_parser.add_argument(
        "--end", type=int, required=True, dest="end_sprint", help="End sprint"
    )

    # REPORT THEMES
    report_themes_parser = report_subparsers.add_parser("themes", help="Theme distribution report")
    report_themes_parser.add_argument(
        "--start", type=int, required=True, dest="start_sprint", help="Start sprint"
    )
    report_themes_parser.add_argument(
        "--end", type=int, required=True, dest="end_sprint", help="End sprint"
    )

    # REPORT HEALTH
    report_health_parser = report_subparsers.add_parser(
        "health", help="Overall project health report"
    )
    report_health_parser.add_argument("project_key", help="Project key (e.g., INOV)")
    report_health_parser.add_argument(
        "--format",
        default="text",
        choices=["text", "markdown", "json"],
        help="Output format",
    )


def _add_dashboard_args(subparsers: Any) -> None:
    """Add arguments for 'dashboard' command."""
    dashboard_parser = subparsers.add_parser(
        "dashboard", help="Dashboard and saved filter operations"
    )
    dashboard_subparsers = dashboard_parser.add_subparsers(
        dest="dashboard_type", help="Dashboard operation"
    )

    launch_parser = dashboard_subparsers.add_parser(
        "launch", help="Create launch burndown dashboard + saved filters"
    )
    launch_parser.add_argument(
        "--project", dest="project_key", help="Project key override (default: env)"
    )
    launch_parser.add_argument("--name", dest="dashboard_name", help="Dashboard name override")
    launch_parser.add_argument(
        "--private",
        action="store_true",
        help="Create private dashboard (default is shared with all logged-in users)",
    )
    launch_parser.add_argument(
        "--execute",
        action="store_true",
        help="Create filters and dashboard in Jira (default: dry run)",
    )


def _add_sprint_ops_args(subparsers: Any) -> None:
    """Add arguments for sprint operations commands"""
    # MOVE
    move_parser = subparsers.add_parser("move", help="Move issues to a sprint")
    move_parser.add_argument(
        "--sprint", type=int, required=True, dest="sprint_number", help="Sprint number"
    )
    move_parser.add_argument("issue_keys", nargs="+", help="Issue keys to move")

    # SPLIT
    split_parser = subparsers.add_parser("split", help="Split a story into subtasks")
    split_parser.add_argument("issue_key", nargs="?", help="Issue key for single split")
    split_parser.add_argument("--context", default="ANI", help="Bounded context")
    split_parser.add_argument("--execute", action="store_false", dest="dry_run", help="Execute")
    split_parser.add_argument("--project-key", help="Project key for batch split")
    split_parser.add_argument("--force", action="store_true", help="Force split")

    # REBALANCE
    rebalance_parser = subparsers.add_parser("rebalance", help="Rebalance story points")
    rebalance_parser.add_argument(
        "--start", type=int, required=True, dest="start_sprint", help="Start"
    )
    rebalance_parser.add_argument("--end", type=int, required=True, dest="end_sprint", help="End")
    rebalance_parser.add_argument("--target-sp", type=int, default=65, help="Target SP")
    rebalance_parser.add_argument("--execute", action="store_false", dest="dry_run", help="Execute")

    # REORGANIZE
    reorganize_parser = subparsers.add_parser("reorganize", help="Reorganize issues by theme")
    reorganize_parser.add_argument(
        "--start", type=int, required=True, dest="start_sprint", help="Start"
    )
    reorganize_parser.add_argument("--end", type=int, required=True, dest="end_sprint", help="End")
    reorganize_parser.add_argument(
        "--execute", action="store_false", dest="dry_run", help="Execute"
    )

    # SPRINT-GOALS
    goals_parser = subparsers.add_parser("sprint-goals", help="Generate sprint goals")
    goals_parser.add_argument("sprint_number", type=int, help="Sprint number")


def _add_auto_args(subparsers: Any) -> None:
    """Add arguments for 'auto' command"""
    auto_parser = subparsers.add_parser("auto", help="Automated operations")
    auto_subparsers = auto_parser.add_subparsers(dest="auto_type", help="Automation type")

    # AUTO ANALYZE
    auto_analyze_parser = auto_subparsers.add_parser("analyze", help="Auto-analyze sprint issues")
    auto_analyze_parser.add_argument("sprint_number", type=int, help="Sprint number")
    auto_analyze_parser.add_argument("--min-grade", default="C", help="Min grade filter")

    # AUTO ENHANCE
    auto_enhance_parser = auto_subparsers.add_parser("enhance", help="Auto-enhance issue or sprint")
    auto_enhance_parser.add_argument("target", help="Issue key (e.g., INOV-123) or sprint number")
    auto_enhance_parser.add_argument(
        "--readiness", default="PARTIALLY_READY", help="Readiness filter (sprint only)"
    )

    # AUTO SPLIT
    auto_split_parser = auto_subparsers.add_parser("split", help="Auto-split large stories")
    auto_split_parser.add_argument("sprint_number", type=int, help="Sprint number")
    auto_split_parser.add_argument("--max-sp", type=int, default=8, help="Max SP before splitting")


def _add_verify_args(subparsers: Any) -> None:
    """Add arguments for 'verify' command"""
    verify_parser = subparsers.add_parser("verify", help="Verification operations")
    verify_subparsers = verify_parser.add_subparsers(dest="verify_type", help="Verification type")

    # VERIFY SPRINT
    verify_sprint_parser = verify_subparsers.add_parser("sprint", help="Verify sprint readiness")
    verify_sprint_parser.add_argument("sprint_number", type=int, help="Sprint number")

    # VERIFY THEMES
    verify_themes_parser = verify_subparsers.add_parser("themes", help="Verify theme consistency")
    verify_themes_parser.add_argument("sprint_number", type=int, help="Sprint number")

    # VERIFY STORIES
    verify_stories_parser = verify_subparsers.add_parser(
        "stories",
        help="Verify story clarity and Confluence technical references in a sprint",
    )
    verify_stories_parser.add_argument("sprint_number", type=int, help="Sprint number")
    verify_stories_parser.add_argument(
        "--min-words",
        type=int,
        default=80,
        help="Minimum description word count for clarity checks",
    )
    verify_stories_parser.add_argument(
        "--allow-missing-confluence",
        action="store_true",
        help="Do not fail verification when Confluence links are missing",
    )


def _add_v2_legacy_args(subparsers: Any) -> None:
    """Add arguments for legacy V2 commands"""
    # PREPARE
    prepare_parser = subparsers.add_parser(
        "prepare", help="Prepare story with technical specification"
    )
    prepare_parser.add_argument("issue_key", help="Issue key (e.g., INOV-123)")
    prepare_parser.add_argument("--update", action="store_true", help="Update issue description")
    prepare_parser.add_argument(
        "--format",
        choices=["full", "spec", "hints", "test", "ai"],
        default="full",
        help="Output format",
    )
    prepare_parser.add_argument("--output", help="Output file")

    # CONTEXT
    context_parser = subparsers.add_parser("context", help="Show bounded context information")
    context_parser.add_argument("context_name", nargs="?", help="Context name")

    # STANDARDIZE
    standardize_parser = subparsers.add_parser("standardize", help="Upgrade stories to AI format")
    standardize_group = standardize_parser.add_mutually_exclusive_group(required=True)
    standardize_group.add_argument("--issue", help="Issue key to standardize")
    standardize_group.add_argument("--sprint", type=int, help="Standardize sprint")
    standardize_parser.add_argument("--execute", action="store_true", help="Apply changes")

    # BALANCE
    balance_parser = subparsers.add_parser("balance", help="Analyze sprint capacity balance")
    balance_parser.add_argument(
        "--start", type=int, required=True, dest="start_sprint", help="Start sprint"
    )
    balance_parser.add_argument(
        "--end", type=int, required=True, dest="end_sprint", help="End sprint"
    )
    balance_parser.add_argument("--target-sp", type=int, default=65, help="Target SP per sprint")

    # TEMPLATE — agent-callable: `template story` / `template epic`.
    # The existing ``--format``/``--output`` flags continue to work for the
    # legacy code path; the new positional ``kind`` selects the
    # PLAN-§6.2 11-section markdown skeleton or the epic skeleton.
    template_parser = subparsers.add_parser(
        "template", help="Generate requirements template (story|epic)"
    )
    template_parser.add_argument(
        "template_kind",
        nargs="?",
        choices=["story", "epic"],
        help="Template kind (story = 11-section AI skeleton, epic = epic skeleton)",
    )
    template_parser.add_argument("--type", dest="type", help="Template type (legacy)")
    template_parser.add_argument(
        "--format", choices=["yaml", "markdown"], default="markdown", help="Format"
    )
    template_parser.add_argument("--output", help="Output file")

    # REMOVE-LABEL
    remove_label_parser = subparsers.add_parser("remove-label", help="Remove a label")
    remove_label_parser.add_argument("label", help="Label to remove")
    remove_label_parser.add_argument(
        "--start", type=int, default=2, dest="start_sprint", help="Start sprint"
    )
    remove_label_parser.add_argument(
        "--end", type=int, default=25, dest="end_sprint", help="End sprint"
    )
    remove_label_parser.add_argument(
        "--execute", action="store_true", help="Actually remove labels"
    )

    # GOALS
    goals_alias_parser = subparsers.add_parser("goals", help="Generate and update sprint goals")
    goals_alias_parser.add_argument(
        "--from-sprint", type=int, default=2, dest="from_sprint", help="Start"
    )
    goals_alias_parser.add_argument(
        "--to-sprint", type=int, default=25, dest="to_sprint", help="End"
    )
    goals_alias_parser.add_argument("--execute", action="store_true", help="Apply goals")

    # PORTFOLIO-REORG
    portfolio_parser = subparsers.add_parser("portfolio-reorg", help="Reorganize Portfolio pages")
    portfolio_parser.add_argument("--execute", action="store_true", help="Apply changes")

    # PRODUCT-DOCS
    product_docs_parser = subparsers.add_parser(
        "product-docs", help="Create standard documentation"
    )
    product_docs_parser.add_argument("product", help="Product name")
    product_docs_parser.add_argument("--execute", action="store_true", help="Create pages")


def build_parser() -> argparse.ArgumentParser:
    """Create CLI argument parser"""

    parser = argparse.ArgumentParser(
        prog="atlassiancli",
        description="atlassiancli - Standalone, zero-pip-dep CLI for Atlassian (Jira + Confluence) operations",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"atlassiancli {__version__}",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        dest="json_output",
        help=(
            "Emit a stable JSON envelope on stdout for agent consumption "
            "(see PLAN.md §6.2). Replaces the human-readable output."
        ),
    )
    parser.add_argument(
        "--profile",
        "-P",
        dest="profile",
        default=None,
        help=(
            "Named credential profile. Falls back to $ATLASSIAN_PROFILE then "
            "'default'. Profiles live at ~/.atlassiancli/<name>.toml; create "
            "one with `atlassiancli configure --profile <name>`."
        ),
    )
    parser.add_argument(
        "--config",
        dest="config_path",
        default=None,
        help=(
            "Explicit path to a profile TOML file. Overrides --profile and "
            "the per-user profile lookup; env vars still take precedence."
        ),
    )

    subparsers = parser.add_subparsers(dest="command", help="Commands")
    _add_configure_args(subparsers)
    _add_review_args(subparsers)

    _add_create_args(subparsers)
    _add_enhance_args(subparsers)
    _add_docs_args(subparsers)
    _add_delete_args(subparsers)
    _add_sprint_ops_args(subparsers)
    _add_analyze_args(subparsers)
    _add_auto_args(subparsers)
    _add_report_args(subparsers)
    _add_dashboard_args(subparsers)
    _add_verify_args(subparsers)
    _add_import_args(subparsers)
    _add_transition_args(subparsers)
    _add_confluence_args(subparsers)
    _add_v2_legacy_args(subparsers)
    _add_agent_args(subparsers)
    _add_framework_args(subparsers)

    return parser


def _add_framework_args(subparsers: Any) -> None:
    """Add the ``framework`` subcommand group (PR 5 — doc framework bridge)."""
    framework_parser = subparsers.add_parser(
        "framework",
        help="Doc framework bridge: manifests <-> Jira <-> Confluence",
    )
    framework_subs = framework_parser.add_subparsers(
        dest="framework_action", help="Framework action"
    )

    # create-stories
    cs = framework_subs.add_parser(
        "create-stories",
        help="Create / update Jira stories from per-product YAML manifests",
    )
    cs.add_argument("--product", required=True, help="Product handle")
    cs.add_argument("--epic", dest="filter_epic", help="Filter to one epic")
    cs.add_argument(
        "--manifest",
        dest="filter_id",
        help="Filter to a single manifest by S-ID",
    )
    cs.add_argument("--dry-run", action="store_true", help="Preview without API writes")
    cs.add_argument("--skip-link-pass", action="store_true", help="Skip dependency linking")
    cs.add_argument(
        "--no-transition",
        action="store_true",
        help="Skip the COMPLETED/DONE -> Done transition pass",
    )

    # verify-stories
    vs = framework_subs.add_parser(
        "verify-stories",
        help="Verify per-epic manifest <-> Jira story-count parity",
    )
    vs.add_argument("--product", required=True, help="Product handle")

    # reverse-sync
    rs = framework_subs.add_parser(
        "reverse-sync",
        help="Materialise YAML manifests from Jira stories that lack one on disk",
    )
    rs.add_argument("--product", required=True, help="Product handle")
    rs.add_argument("--epic", dest="filter_epic", help="Scope to a single epic")
    rs.add_argument("--dry-run", action="store_true", help="Preview without writing files")
    rs.add_argument("--strict", action="store_true", help="Fail on parse warnings")

    # sync-docs
    sd = framework_subs.add_parser(
        "sync-docs",
        help="Push repo markdown docs to their configured Confluence pages",
    )
    sd.add_argument("--product", required=True, help="Product handle")
    sd.add_argument(
        "--doc",
        help="Sync a single doc by handle (e.g. ARCHITECTURE)",
    )
    sd.add_argument("--dry-run", action="store_true", help="Preview without API writes")

    # bootstrap
    bs = framework_subs.add_parser(
        "bootstrap",
        help=(
            "Bootstrap a product into the doc framework. Scaffold mode "
            "when docs/<product>/ does not exist (generates the skeleton "
            "from templates); parity-check mode when it exists."
        ),
    )
    bs.add_argument("--product", required=True, help="Product handle (lowercase slug)")
    bs.add_argument(
        "--name",
        dest="product_name",
        default=None,
        help="Human-readable product name. Defaults to title-case of --product.",
    )
    bs.add_argument(
        "--force",
        action="store_true",
        help="Overwrite existing files in scaffold mode (default: skip).",
    )
    bs.add_argument(
        "--dry-run",
        action="store_true",
        help="Report what scaffold mode would write without touching disk.",
    )
    bs.add_argument(
        "--auto-sops",
        dest="auto_sops",
        action="store_true",
        default=True,
        help=(
            "Detect the project stack and emit stack-tuned SOPs (default). "
            "Falls back to generic templates if detection returns 'unknown'."
        ),
    )
    bs.add_argument(
        "--no-auto-sops",
        dest="auto_sops",
        action="store_false",
        help="Skip stack detection; use generic SOP templates only.",
    )
    bs.add_argument(
        "--lang",
        dest="lang_override",
        default=None,
        help=(
            "Override stack auto-detection. One of: python, typescript, "
            "javascript, go, rust, cpp, java, kotlin, csharp, ruby."
        ),
    )

    # regenerate-sops
    rgs = framework_subs.add_parser(
        "regenerate-sops",
        help=(
            "Regenerate the SOP set for an existing product from the "
            "detected stack. Files carrying the auto-generated header "
            "are rewritten; user-edited files are skipped."
        ),
    )
    rgs.add_argument("--product", required=True, help="Product handle (lowercase slug)")
    rgs.add_argument(
        "--force",
        action="store_true",
        help="Rewrite files even if their auto-generated header is missing.",
    )
    rgs.add_argument(
        "--dry-run",
        action="store_true",
        help="Report what would be rewritten without touching disk.",
    )
    rgs.add_argument(
        "--lang",
        dest="lang_override",
        default=None,
        help="Override stack detection; same choices as `bootstrap --lang`.",
    )

    # sop-commit-gate
    scg = framework_subs.add_parser(
        "sop-commit-gate",
        help=(
            "Phase 6 / pre-commit gate: run every commit-time rule from the "
            "SOP manifest against the staged diff. Exits non-zero on "
            "blocking findings."
        ),
    )
    scg.add_argument(
        "--manifest",
        dest="sop_manifest",
        default=None,
        help="Path to sop-manifest.yaml (default: sops/sop-manifest.yaml)",
    )

    # sop-validate-manifest
    svm = framework_subs.add_parser(
        "sop-validate-manifest",
        help="Validate the SOP manifest's structure and regex patterns.",
    )
    svm.add_argument(
        "--manifest",
        dest="sop_manifest",
        default=None,
        help="Path to sop-manifest.yaml (default: sops/sop-manifest.yaml)",
    )


def _add_confluence_args(subparsers: Any) -> None:
    """Add arguments for 'confluence' command — direct page operations"""
    conf_parser = subparsers.add_parser("confluence", help="Direct Confluence page operations")
    conf_subparsers = conf_parser.add_subparsers(dest="confluence_action", help="Action")

    # GET
    get_parser = conf_subparsers.add_parser("get", help="Get page content by ID")
    get_parser.add_argument("page_id", help="Confluence page ID")

    # CHILDREN
    children_parser = conf_subparsers.add_parser("children", help="List child pages")
    children_parser.add_argument("page_id", help="Parent page ID")

    # FIND
    find_parser = conf_subparsers.add_parser("find", help="Find page by title")
    find_parser.add_argument("title", help="Page title to search for")
    find_parser.add_argument("--space", default="INOV", help="Space key (default: INOV)")

    # CREATE
    create_parser = conf_subparsers.add_parser("create", help="Create a new page")
    create_parser.add_argument("--title", required=True, help="Page title")
    create_parser.add_argument("--space", default="INOV", help="Space key (default: INOV)")
    create_parser.add_argument("--content-file", help="Path to content file")
    create_parser.add_argument("--content", help="Inline content string")
    create_parser.add_argument("--parent-id", help="Parent page ID")
    create_parser.add_argument(
        "--markdown",
        action="store_true",
        help="Convert markdown to Confluence storage format",
    )
    create_parser.add_argument(
        "--execute", action="store_true", help="Create page (default: dry run)"
    )

    # UPDATE
    update_parser = conf_subparsers.add_parser("update", help="Update an existing page")
    update_parser.add_argument("page_id", help="Page ID to update")
    update_parser.add_argument("--content-file", help="Path to content file")
    update_parser.add_argument("--content", help="Inline content string")
    update_parser.add_argument("--title", help="New page title")
    update_parser.add_argument("--parent-id", help="Move page to new parent")
    update_parser.add_argument(
        "--markdown",
        action="store_true",
        help="Convert markdown to Confluence storage format",
    )
    update_parser.add_argument(
        "--append", action="store_true", help="Append content instead of replace"
    )
    update_parser.add_argument(
        "--execute", action="store_true", help="Apply update (default: dry run)"
    )


def _add_transition_args(subparsers: Any) -> None:
    """Add arguments for 'transition' command"""
    transition_parser = subparsers.add_parser("transition", help="Transition an issue status")
    transition_parser.add_argument("issue_key", help="Issue key (e.g., INOV-123)")
    transition_parser.add_argument(
        "transition_name",
        nargs="?",
        help="Transition name (e.g., Done, 'In Progress'). Required unless --to is used.",
    )
    transition_parser.add_argument(
        "--to",
        dest="transition_to",
        help="Target state (alias for the positional transition_name; PLAN §6.4)",
    )
    transition_parser.add_argument("--execute", action="store_true", help="Apply the transition")


def _add_agent_args(subparsers: Any) -> None:
    """Add the agent-contract subcommands documented in PLAN §6.4.

    These are the verbs the agent's state machine invokes between phases:
    sprint discovery, story commentary, PR linkage, and assignment.
    """
    # sprint <action>
    sprint_parser = subparsers.add_parser(
        "sprint", help="Sprint discovery operations (current, stories)"
    )
    sprint_subparsers = sprint_parser.add_subparsers(dest="sprint_action", help="Sprint action")
    current_parser = sprint_subparsers.add_parser(
        "current", help="Find the active sprint on a board"
    )
    current_parser.add_argument(
        "--board", type=int, dest="board_id", help="Board ID (default: env)"
    )
    stories_parser = sprint_subparsers.add_parser("stories", help="List stories on a sprint")
    stories_parser.add_argument(
        "--sprint", type=int, required=True, dest="sprint_id", help="Sprint ID"
    )
    stories_parser.add_argument(
        "--unassigned", action="store_true", help="Filter to unassigned stories only"
    )
    stories_parser.add_argument(
        "--priority-order",
        action="store_true",
        help="Sort by priority (highest first)",
    )

    # comment <KEY> --body <text> [--idempotency-key <key>]
    comment_parser = subparsers.add_parser(
        "comment", help="Add a comment to an issue (idempotent with key)"
    )
    comment_parser.add_argument("issue_key", help="Issue key (e.g., INOV-123)")
    comment_parser.add_argument("--body", required=True, help="Comment body text")
    comment_parser.add_argument(
        "--idempotency-key",
        dest="idempotency_key",
        help=(
            "When set, suppress duplicate comments — agent passes its run id "
            "so retries don't multiply comments."
        ),
    )

    # link-pr <KEY> --pr-url <url>
    linkpr_parser = subparsers.add_parser(
        "link-pr", help="Add a PR remote-link to an issue (idempotent)"
    )
    linkpr_parser.add_argument("issue_key", help="Issue key (e.g., INOV-123)")
    linkpr_parser.add_argument("--pr-url", required=True, dest="pr_url", help="PR URL to link")

    # assign <KEY> --user <email>
    assign_parser = subparsers.add_parser("assign", help="Assign an issue to a user (idempotent)")
    assign_parser.add_argument("issue_key", help="Issue key (e.g., INOV-123)")
    assign_parser.add_argument("--user", required=True, help="User email")


def handle_create_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Handle 'create' command"""
    service = container.issue_creation_service()
    handler = CreateCommandHandler(service, jira_client=container.jira_client())

    if args.issue_type == "epic":
        return handler.handle_create_epic(
            title=args.title,
            description=args.description,
            objective=args.objective,
            kpis=args.kpis,
            in_scope=args.in_scope,
            out_of_scope=args.out_of_scope,
            architecture_link=args.architecture,
            themes=args.themes,
            priority=args.priority,
        )
    if args.issue_type == "story":
        return handler.handle_create_story(
            title=args.title,
            description=args.description,
            epic_key=args.epic_key,
            story_points=args.story_points,
            sprint_number=args.sprint_number,
            acceptance_criteria=args.acceptance_criteria,
            affected_modules=args.affected_modules,
            integration_points=args.integration_points,
            themes=args.themes,
            priority=args.priority,
        )
    if args.issue_type == "task":
        return handler.handle_create_task(
            title=args.title,
            description=args.description,
            parent_story_key=args.parent_story_key,
            implementation_steps=args.implementation_steps,
            estimated_hours=args.estimated_hours,
            priority=args.priority,
        )
    if args.issue_type == "version":
        return handler.handle_create_version(
            name=args.name,
            description=args.description,
            project_id=args.project_id,
            start_date=args.start_date,
            release_date=args.release_date,
            released=args.released,
            archived=args.archived,
        )
    print("❌ Invalid issue type. Use: epic, story, task, or version")
    return 1


def handle_enhance_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Handle 'enhance' command with expert analysis"""

    # Use expert enhancement service for single issues
    if hasattr(args, "issue_key") and args.issue_key:
        expert_service = container.expert_enhancement_service()

        # Check mode: just check if already enhanced
        if getattr(args, "check", False):
            result = expert_service.check_enhancement_status(args.issue_key)
            if result.success and result.value:
                data = result.value
                print(f"🔍 Enhancement Status: {data['issue_key']}")
                print(f"   Enhanced: {'✅ Yes' if data['is_enhanced'] else '❌ No'}")
                print(f"   Has Wiki Headers (h2.): {data['has_wiki_headers']}")
                print(f"   Has Markdown Headers (##): {data['has_markdown_headers']}")
                print(f"   Description Length: {data['description_length']}")
                print(f"\n💡 {data['recommendation']}")
                return 0
            else:
                print(f"❌ Failed to check: {result.error}")
                return 1

        # Preview mode: show what enhancement would look like
        if getattr(args, "preview", False):
            result = expert_service.preview_enhancement(
                args.issue_key,
                apply_architecture=getattr(args, "apply_architecture", False),
            )
            if result.success and result.value:
                data = result.value
                print(f"🔍 Enhancement Preview: {data['issue_key']}")
                print(f"   Category: {data['category']}")
                print(f"   Acceptance Criteria: {data['acceptance_criteria_count']}")
                print(f"   Security Requirements: {data['security_requirements_count']}")
                print(f"   Definition of Done Items: {data['dod_items_count']}")
                print(
                    f"   Description: {data['description_length_before']} → {data['description_length_after']} chars"
                )
                print("\n" + "=" * 60 + "\n")
                print(data["enhanced_description"])
                print("\n" + "=" * 60)
                return 0
            else:
                print(f"❌ Failed to preview: {result.error}")
                return 1

        # Normal enhance mode with expert analysis
        from ..application.dtos import EnhanceIssueRequest

        request = EnhanceIssueRequest(
            issue_key=args.issue_key,
            force=getattr(args, "force", False),
            update_metadata=getattr(args, "update_metadata", False),
            apply_architecture=getattr(args, "apply_architecture", False),
            auto_quality=not getattr(args, "no_auto_quality", False),
        )

        dry_run = not getattr(args, "execute", False)
        expert_result = expert_service.enhance_issue(request, dry_run=dry_run)

        if expert_result.success and expert_result.value:
            response = expert_result.value
            print(f"{'🔍 DRY RUN - ' if dry_run else ''}✅ Enhanced: {response.issue_key}")
            print(f"📊 AI Readiness: {response.previous_readiness} → {response.new_readiness}")

            if response.changes_made:
                print("\n✏️  Changes:")
                for change in response.changes_made:
                    print(f"  - {change}")

            if response.quality_before or response.quality_after:
                print("\n🧪 Quality Analysis (auto)")
                if response.quality_before:
                    lint_before = response.quality_before.get("lint", {})
                    desc_before = response.quality_before.get("description", {})
                    if lint_before:
                        print(
                            "  Before Lint: "
                            f"{lint_before.get('readiness_level', 'n/a')} "
                            f"({lint_before.get('readiness_score', 'n/a')}/100)"
                        )
                    if desc_before:
                        print(
                            "  Before Description: "
                            f"{desc_before.get('grade', 'n/a')} "
                            f"({desc_before.get('score', 'n/a')}/10)"
                        )

                if response.quality_after:
                    lint_after = response.quality_after.get("lint", {})
                    desc_after = response.quality_after.get("description", {})
                    if lint_after:
                        print(
                            "  After Lint: "
                            f"{lint_after.get('readiness_level', 'n/a')} "
                            f"({lint_after.get('readiness_score', 'n/a')}/100)"
                        )
                    if desc_after:
                        print(
                            "  After Description: "
                            f"{desc_after.get('grade', 'n/a')} "
                            f"({desc_after.get('score', 'n/a')}/10)"
                        )

            # Display full architecture analysis if available
            if response.architecture_review:
                arch = response.architecture_review
                print("\n" + "=" * 60)
                print("🏗️  ARCHITECTURE ANALYSIS")
                print("=" * 60)
                print(f"📊 Grade: {arch.grade} ({arch.score}/100)")
                print(f"📄 Arch Doc: {'✅ Linked' if arch.has_arch_doc else '❌ Missing'}")
                if arch.arch_doc_link:
                    print(f"🔗 Link: {arch.arch_doc_link}")

                if arch.findings:
                    print("\n📝 Findings:")
                    for finding in arch.findings:
                        print(f"  - {finding}")

                if arch.suggestions:
                    print("\n💡 Suggestions:")
                    for suggestion in arch.suggestions:
                        print(f"  - {suggestion}")

                # Show proposed architecture requirements
                if arch.proposed_acceptance_criteria or arch.proposed_nfr_section:
                    applied = getattr(args, "apply_architecture", False)
                    if applied:
                        print("\n📋 Applied Architecture Requirements:")
                    else:
                        print("\n📋 Proposed Architecture Requirements:")
                        print("   (Use --apply-architecture to apply these)")

                    if arch.proposed_acceptance_criteria:
                        action = "Added" if applied else "Would add"
                        print(
                            f"\n   ✏️  {action} {len(arch.proposed_acceptance_criteria)} Acceptance Criteria:"
                        )
                        for i, criterion in enumerate(arch.proposed_acceptance_criteria, 1):
                            # Show first 100 chars of each criterion
                            preview = criterion[:100] + "..." if len(criterion) > 100 else criterion
                            print(f"      {i}. {preview}")

                    if arch.proposed_nfr_section:
                        nfr_lines = arch.proposed_nfr_section.split("\n")
                        action = "Added" if applied else "Would add"
                        print(f"\n   ✏️  {action} NFR section ({len(nfr_lines)} lines)")

            if dry_run:
                print("\n⚠️  Use --execute to apply changes to Jira")
            return 0
        else:
            print(f"❌ Failed to enhance: {expert_result.error}")
            for error in expert_result.errors:
                print(f"  - {error}")
            return 1

    # Sprint enhancement uses ExpertEnhancementService for full analysis
    if hasattr(args, "sprint_number") and args.sprint_number:
        from ..application.dtos import EnhanceSprintRequest

        sprint_service = container.expert_enhancement_service()
        sprint_dry_run = not getattr(args, "execute", False)

        sprint_request = EnhanceSprintRequest(
            sprint_number=args.sprint_number,
            execute=getattr(args, "execute", False),
            force=getattr(args, "force", False),
            with_docs=getattr(args, "with_docs", False),
            update_metadata=getattr(args, "update_metadata", False),
            apply_architecture=getattr(args, "apply_architecture", False),
            auto_quality=not getattr(args, "no_auto_quality", False),
        )

        print(f"\n🚀 Enhancing Sprint {args.sprint_number} with Expert Analysis")
        print(
            f"   Force: {sprint_request.force} | Architecture: {sprint_request.apply_architecture} | Metadata: {sprint_request.update_metadata}"
        )
        print(f"   Auto Quality: {sprint_request.auto_quality}")
        print(f"   Mode: {'EXECUTE' if sprint_request.execute else 'DRY RUN'}\n")

        sprint_result = sprint_service.enhance_sprint(sprint_request, dry_run=sprint_dry_run)

        if sprint_result.success and sprint_result.value:
            sprint_response = sprint_result.value
            print(f"\n✅ Sprint {sprint_response.sprint_number} Enhancement Complete")
            print(f"📊 Enhanced: {len(sprint_response.enhanced)}")
            print(f"⏭️  Skipped: {len(sprint_response.skipped)}")
            print(f"❌ Failed: {len(sprint_response.failed)}")
            print(f"✏️  Total Changes: {sprint_response.total_changes}")

            if sprint_response.enhanced:
                print("\n✅ Enhanced Issues:")
                for key in sprint_response.enhanced:
                    print(f"  - {key}")

            if sprint_response.skipped:
                print("\n⏭️  Skipped Issues:")
                for key in sprint_response.skipped[:10]:
                    print(f"  - {key}")
                if len(sprint_response.skipped) > 10:
                    print(f"  ... and {len(sprint_response.skipped) - 10} more")

            if sprint_response.failed:
                print("\n❌ Failed Issues:")
                for key in sprint_response.failed:
                    print(f"  - {key}")

            if sprint_dry_run:
                print("\n⚠️  DRY RUN - Use --execute to apply changes to Jira")
            return 0
        elif not sprint_result.success:
            print(f"❌ Failed to enhance sprint: {sprint_result.error}")
            for error in sprint_result.errors:
                print(f"  - {error}")
            return 1
        else:
            print("❌ Failed to enhance sprint: No response data received")
            return 1

    print("❌ Must provide either --issue or --sprint")
    return 1


def handle_docs_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Handle 'docs' command"""
    service = container.document_sync_service()
    handler = DocsCommandHandler(service)

    # If --all, enable all doc types
    if args.all:
        include_spec = True
        include_testplan = True
        include_runbook = True
    else:
        include_spec = args.include_spec
        include_testplan = args.include_testplan
        include_runbook = args.include_runbook

    return handler.handle_create_docs(
        issue_key=args.issue_key,
        include_spec=include_spec,
        include_testplan=include_testplan,
        include_runbook=include_runbook,
        analyze_only=getattr(args, "analyze", False),
        execute=getattr(args, "execute", False),
    )


def handle_delete_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Handle 'delete' command"""
    service = container.issue_deletion_service()
    handler = DeleteCommandHandler(service)
    return handler.handle_delete(
        issue_keys=args.issue_keys,
        delete_subtasks=args.delete_subtasks,
        force=args.force,
        dry_run=args.dry_run,
    )


def handle_move_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Handle 'move' command"""
    service = container.sprint_management_service()
    handler = SprintCommandHandler(service)
    return handler.handle_move_to_sprint(
        sprint_number=args.sprint_number,
        issue_keys=args.issue_keys,
    )


def handle_analyze_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Handle 'analyze' command"""
    service = container.issue_analysis_service()
    handler = AnalysisCommandHandler(service)

    if args.analyze_type == "lint":
        return handler.handle_lint(args.issue_key)
    if args.analyze_type == "atomicity":
        return handler.handle_analyze_atomicity(args.issue_key)
    if args.analyze_type == "description":
        return handler.handle_analyze_description(args.text)
    if args.analyze_type == "architecture":
        dry_run = not getattr(args, "real_run", False)  # Default to dry-run
        return handler.handle_architecture_review(args.issue_key, dry_run=dry_run)
    print("❌ Invalid analysis type. Use: lint, atomicity, description, or architecture")
    return 1


def handle_split_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Handle 'split' command"""
    service = container.story_splitting_service()
    story_splitting_service = container.story_splitting_service()
    handler = SplittingCommandHandler(service, story_splitting_service)

    if hasattr(args, "project_key") and args.project_key:
        return handler.handle_batch_split(args.project_key, args.context, args.dry_run)
    if args.issue_key:
        return handler.handle_split(args.issue_key, args.context, args.dry_run)
    print("❌ Must provide either --issue-key or --project-key")
    return 1


def handle_sprint_ops_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Handle sprint operations commands (rebalance, reorganize, sprint-goals)"""
    service = container.sprint_operations_service()
    handler = OperationsCommandHandler(service)

    if args.command == "rebalance":
        return handler.handle_rebalance(
            args.start_sprint, args.end_sprint, args.target_sp, args.dry_run
        )
    if args.command == "reorganize":
        return handler.handle_reorganize(args.start_sprint, args.end_sprint, args.dry_run)
    if args.command == "sprint-goals":
        return handler.handle_sprint_goals(args.sprint_number)
    return 1


def handle_auto_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Handle 'auto' command"""
    service = container.automation_service()
    handler = AutomationCommandHandler(service)

    if args.auto_type == "analyze":
        return handler.handle_auto_analyze(args.sprint_number, args.min_grade)
    if args.auto_type == "enhance":
        # Detect if target is issue key or sprint number
        target = args.target
        if "-" in str(target):  # Issue key format (INOV-123)
            return handler.handle_auto_enhance_issue(target)
        else:  # Sprint number
            try:
                sprint_num = int(target)
                return handler.handle_auto_enhance_sprint(sprint_num, args.readiness)
            except ValueError:
                print(f"❌ Invalid target: {target}. Use issue key (INOV-123) or sprint number")
                return 1
    if args.auto_type == "split":
        return handler.handle_auto_split(args.sprint_number, args.max_sp)
    print("❌ Invalid auto type. Use: analyze, enhance, or split")
    return 1


def handle_report_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Handle 'report' command"""
    service = container.reporting_service()
    health_report_service = container.health_report_service()
    handler = ReportingCommandHandler(service, health_report_service)

    if args.report_type == "quality":
        return handler.handle_quality_report(args.start_sprint, args.end_sprint, args.format)
    if args.report_type == "velocity":
        return handler.handle_velocity_report(args.start_sprint, args.end_sprint)
    if args.report_type == "themes":
        return handler.handle_themes_report(args.start_sprint, args.end_sprint)
    if args.report_type == "health":
        return handler.handle_health_report(args.project_key)
    print("❌ Invalid report type. Use: quality, velocity, themes, or health")
    return 1


def handle_dashboard_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Handle 'dashboard' command."""
    service = container.dashboard_service()
    handler = DashboardCommandHandler(service)

    if args.dashboard_type == "launch":
        return handler.handle_launch_dashboard(
            project_key=getattr(args, "project_key", None),
            dashboard_name=getattr(args, "dashboard_name", None),
            execute=getattr(args, "execute", False),
            share_global=not getattr(args, "private", False),
        )

    print("❌ Invalid dashboard type. Use: launch")
    return 1


def handle_verify_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Handle 'verify' command"""
    service = container.verification_service()
    handler = VerificationCommandHandler(service)

    if args.verify_type == "sprint":
        return handler.handle_verify_sprint(args.sprint_number)
    if args.verify_type == "themes":
        return handler.handle_verify_themes(args.sprint_number)
    if args.verify_type == "stories":
        return handler.handle_verify_stories(
            sprint_number=args.sprint_number,
            min_words=args.min_words,
            require_confluence_link=not args.allow_missing_confluence,
        )
    print("❌ Invalid verify type. Use: sprint, themes, or stories")
    return 1


def handle_import_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Handle 'import' command"""
    service = container.import_service()
    enhancement_service = container.expert_enhancement_service()
    handler = ImportCommandHandler(service, enhancement_service=enhancement_service)

    if args.import_type == "markdown":
        return handler.handle_import_markdown(
            args.file_path,
            args.dry_run,
            with_docs=args.with_docs if hasattr(args, "with_docs") else False,
            auto=args.auto if hasattr(args, "auto") else False,
        )
    if args.import_type == "yaml":
        # handle_import_yaml doesn't support with_docs yet
        return handler.handle_import_yaml(args.file_path, args.dry_run)
    if args.import_type == "confluence":
        return handler.handle_import_confluence(
            args.page_id,
            include_children=args.include_children,
            dry_run=args.dry_run,
            sprint_number=args.sprint if hasattr(args, "sprint") else None,
            epic_only=args.epic_only,
            with_docs=args.with_docs if hasattr(args, "with_docs") else False,
            verbose=args.verbose if hasattr(args, "verbose") else False,
            skip_duplicate_check=args.skip_duplicate_check
            if hasattr(args, "skip_duplicate_check")
            else False,
            validate_codebase=args.validate_codebase
            if hasattr(args, "validate_codebase")
            else False,
            analyze_backlog=args.analyze_backlog if hasattr(args, "analyze_backlog") else False,
        )
    print("❌ Invalid import type. Use: markdown, yaml, or confluence")
    return 1


def handle_prepare_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Handle 'prepare' command"""
    service = container.prepare_story_service()
    handler = PrepareCommandHandler(service)
    return handler.handle_prepare(
        args.issue_key,
        update=args.update,
        format_type=args.format,
        output_file=args.output,
    )


def handle_context_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Handle 'context' command"""
    service = container.context_info_service()
    handler = ContextCommandHandler(service)
    return handler.handle_context(args.context_name if hasattr(args, "context_name") else None)


def handle_standardize_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Handle 'standardize' command"""
    service = container.standardize_story_service()
    handler = StandardizeCommandHandler(service)
    if args.issue:
        return handler.handle_standardize(
            args.issue, args.format if hasattr(args, "format") else "user_story"
        )
    print("❌ Must provide --issue")
    return 1


def handle_balance_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Handle 'balance' command"""
    service = container.balance_capacity_service()
    handler = BalanceCommandHandler(service)
    sprint_number = args.start_sprint if hasattr(args, "start_sprint") else args.sprint
    return handler.handle_balance(sprint_number)


def handle_template_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Handle 'template' command.

    PR 4 adds the agent surface ``template story`` / ``template epic``
    that emits the PLAN-§6.2 11-section markdown skeletons. When a
    ``template_kind`` positional is supplied the agent path runs;
    otherwise the legacy ``--type`` / ``--format`` path runs unchanged.
    """
    kind = getattr(args, "template_kind", None)
    if kind in ("story", "epic"):
        print(agent_adapter.template_to_text(kind))
        return 0
    service = container.template_generation_service()
    handler = TemplateCommandHandler(service)
    template_type = args.type if getattr(args, "type", None) else "user_story"
    format_type = args.format if hasattr(args, "format") else "markdown"
    return handler.handle_template(template_type, format_type)


def handle_remove_label_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Handle 'remove-label' command"""
    service = container.label_removal_service()
    handler = RemoveLabelCommandHandler(service)
    project_key = args.project_key if hasattr(args, "project_key") else None
    dry_run = not args.execute if hasattr(args, "execute") else True
    return handler.handle_remove_label(args.label, project_key, dry_run)


def handle_goals_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Handle 'goals' command"""
    service = container.sprint_goals_service()
    handler = GoalsCommandHandler(service)
    sprint_number = args.from_sprint if hasattr(args, "from_sprint") else args.sprint
    return handler.handle_goals(sprint_number)


def handle_portfolio_reorg_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Handle 'portfolio-reorg' command"""
    confluence = container.confluence_repo
    handler = ReorganizeCommandHandler(confluence)
    dry_run = not args.execute if hasattr(args, "execute") else True
    return handler.handle_reorganize(dry_run)


def handle_product_docs_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Handle 'product-docs' command"""
    confluence = container.confluence_repo
    handler = ProductDocsCommandHandler(confluence)
    dry_run = not args.execute if hasattr(args, "execute") else True
    return handler.handle_create_product_docs(args.product, dry_run)


def handle_confluence_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Handle 'confluence' command"""
    confluence = container.confluence_repo
    handler = ConfluenceCommandHandler(confluence)

    action = getattr(args, "confluence_action", None)

    if action == "get":
        return handler.handle_get(args.page_id)
    if action == "children":
        return handler.handle_children(args.page_id)
    if action == "find":
        return handler.handle_find(args.space, args.title)
    if action == "create":
        dry_run = not getattr(args, "execute", False)
        return handler.handle_create(
            space_key=args.space,
            title=args.title,
            content_file=getattr(args, "content_file", None),
            content=getattr(args, "content", None),
            parent_id=getattr(args, "parent_id", None),
            markdown=getattr(args, "markdown", False),
            dry_run=dry_run,
        )
    if action == "update":
        dry_run = not getattr(args, "execute", False)
        return handler.handle_update(
            page_id=args.page_id,
            content_file=getattr(args, "content_file", None),
            content=getattr(args, "content", None),
            title=getattr(args, "title", None),
            parent_id=getattr(args, "parent_id", None),
            markdown=getattr(args, "markdown", False),
            append=getattr(args, "append", False),
            dry_run=dry_run,
        )

    print("❌ Invalid confluence action. Use: get, children, find, create, or update")
    return 1


def handle_transition_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Handle 'transition' command"""
    service = container.issue_transition_service()
    handler = TransitionCommandHandler(service)
    return handler.handle_transition(args.issue_key, args.transition_name, args.execute)


def _handle_configure_command(args: argparse.Namespace) -> int:
    """Run the interactive credential wizard."""
    from ..application.profile_store import DEFAULT_PROFILE_NAME
    from .configure_handler import (
        CredentialVerificationError,
        run_wizard,
    )

    profile_name = (
        getattr(args, "configure_profile", None)
        or getattr(args, "profile", None)
        or DEFAULT_PROFILE_NAME
    )
    no_verify = bool(getattr(args, "no_verify", False))

    try:
        result = run_wizard(profile_name=profile_name, no_verify=no_verify)
    except CredentialVerificationError as exc:
        print(f"❌ {exc}")
        return 1
    except KeyboardInterrupt:
        print("\nConfigure cancelled — no profile written.")
        return 1

    if getattr(args, "json_output", False):
        import json

        payload = {
            "command": "configure",
            "profile_name": result.profile_name,
            "saved_path": result.saved_path,
            "verified": result.verified,
            "account_id": result.account_id,
            "display_name": result.display_name,
            "warnings": list(result.warnings),
        }
        print(json.dumps(payload, indent=2))
    return 0


def _print_sop_response(response: Any) -> None:
    """Render an AgentResponse from the SOP adapters in human-readable form."""
    print(f"verdict: {response.verdict}")
    meta = response.metadata or {}
    if meta:
        keys = ("manifest_path", "blocking_count", "total_findings", "rules_loaded")
        bits = [f"{k}={meta[k]}" for k in keys if k in meta]
        if bits:
            print("  " + " | ".join(bits))
    for f in response.findings:
        sec = f" [{f.section}]" if f.section else ""
        print(f"  - {f.severity:6s} {f.rule}{sec}: {f.message}")
        if f.fix_hint:
            print(f"      -> {f.fix_hint}")


def handle_framework_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Dispatch ``framework <action>`` to the FrameworkCommandHandler (PR 5)."""
    action = getattr(args, "framework_action", None)
    json_output = bool(getattr(args, "json_output", False))

    if not action:
        print(
            "ERROR: missing framework action. Use: create-stories, "
            "verify-stories, reverse-sync, sync-docs, bootstrap, "
            "regenerate-sops, sop-commit-gate, sop-validate-manifest"
        )
        return 1

    # SOP subactions don't take --product and don't need a Jira/Confluence
    # client — short-circuit to the dedicated adapter.
    if action == "sop-commit-gate":
        from .sop_adapter import sop_commit_gate_to_json

        response = sop_commit_gate_to_json(manifest_path=getattr(args, "sop_manifest", None))
        if json_output:
            print(response.to_json())
        else:
            _print_sop_response(response)
        return 0 if response.verdict == "PASS" else 1

    if action == "sop-validate-manifest":
        from .sop_adapter import sop_validate_manifest_to_json

        response = sop_validate_manifest_to_json(manifest_path=getattr(args, "sop_manifest", None))
        if json_output:
            print(response.to_json())
        else:
            _print_sop_response(response)
        return 0 if response.verdict == "PASS" else 1

    handler = container.framework_command_handler()
    product = args.product

    if action == "create-stories":
        return handler.handle_create_stories(
            product,
            filter_epic=getattr(args, "filter_epic", None),
            filter_id=getattr(args, "filter_id", None),
            dry_run=bool(getattr(args, "dry_run", False)),
            skip_link_pass=bool(getattr(args, "skip_link_pass", False)),
            no_transition=bool(getattr(args, "no_transition", False)),
            json_output=json_output,
        )
    if action == "verify-stories":
        return handler.handle_verify_stories(product, json_output=json_output)
    if action == "reverse-sync":
        return handler.handle_reverse_sync(
            product,
            filter_epic=getattr(args, "filter_epic", None),
            dry_run=bool(getattr(args, "dry_run", False)),
            strict=bool(getattr(args, "strict", False)),
            json_output=json_output,
        )
    if action == "sync-docs":
        return handler.handle_sync_docs(
            product,
            doc=getattr(args, "doc", None),
            dry_run=bool(getattr(args, "dry_run", False)),
            json_output=json_output,
        )
    if action == "bootstrap":
        return handler.handle_bootstrap(
            product,
            json_output=json_output,
            product_name=getattr(args, "product_name", None),
            force=bool(getattr(args, "force", False)),
            dry_run=bool(getattr(args, "dry_run", False)),
            auto_sops=bool(getattr(args, "auto_sops", True)),
            lang_override=getattr(args, "lang_override", None),
        )
    if action == "regenerate-sops":
        return handler.handle_regenerate_sops(
            product,
            json_output=json_output,
            force=bool(getattr(args, "force", False)),
            dry_run=bool(getattr(args, "dry_run", False)),
            lang_override=getattr(args, "lang_override", None),
        )

    print(f"ERROR: unknown framework action {action!r}")
    return 1


def handle_agent_sprint_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Human-readable path for ``sprint current`` / ``sprint stories``."""
    action = getattr(args, "sprint_action", None)
    if action == "current":
        response = agent_adapter.sprint_current_to_json(container, getattr(args, "board_id", None))
    elif action == "stories":
        response = agent_adapter.sprint_stories_to_json(
            container,
            args.sprint_id,
            unassigned=bool(getattr(args, "unassigned", False)),
            priority_order=bool(getattr(args, "priority_order", False)),
        )
    else:
        print("❌ Invalid sprint action. Use: current or stories")
        return 1
    print(_json.dumps(response.to_dict(), indent=2))
    return 0


def handle_review_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Human-readable path for ``review`` — runs ready + SOP + architecture."""
    from .review_handler import review_to_json

    response = review_to_json(
        container,
        args.issue_key,
        manifest_path=getattr(args, "sop_manifest", None),
        skip_sop=bool(getattr(args, "skip_sop", False)),
        skip_architecture=bool(getattr(args, "skip_architecture", False)),
    )
    print(f"verdict: {response.verdict}")
    per = response.metadata.get("per_source", {})
    for source, info in per.items():
        print(f"  {source:12s} {info['verdict']!s:10s} ({info['finding_count']} findings)")
    if response.findings:
        print()
        for finding in response.findings:
            sec = f" [{finding.section}]" if finding.section else ""
            print(f"  - {finding.severity:8s} {finding.rule}{sec}: {finding.message}")
            if finding.fix_hint:
                print(f"      -> {finding.fix_hint}")
    # Composite verdict drives exit semantics: clean → 0, anything else → 1.
    return 0 if response.verdict in ("PASS", "READY", None) else 1


def handle_agent_comment_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Human-readable path for ``comment``."""
    response = agent_adapter.comment_to_json(
        container,
        args.issue_key,
        args.body,
        idempotency_key=getattr(args, "idempotency_key", None),
    )
    if response.verdict == "FAIL":
        print(f"❌ Comment failed: {response.findings[0].message if response.findings else ''}")
        return 1
    if response.metadata.get("skipped"):
        print("⏭️  Comment skipped (idempotency-key match)")
    else:
        print(f"✅ Comment posted to {args.issue_key}")
    return 0


def handle_agent_link_pr_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Human-readable path for ``link-pr``."""
    response = agent_adapter.link_pr_to_json(container, args.issue_key, args.pr_url)
    if response.verdict == "FAIL":
        print(f"❌ link-pr failed: {response.findings[0].message if response.findings else ''}")
        return 1
    if response.metadata.get("skipped"):
        print(f"⏭️  PR url already linked to {args.issue_key}")
    else:
        print(f"✅ Linked {args.pr_url} to {args.issue_key}")
    return 0


def handle_agent_assign_command(container: CompositionRoot, args: argparse.Namespace) -> int:
    """Human-readable path for ``assign``."""
    response = agent_adapter.assign_to_json(container, args.issue_key, args.user)
    if response.verdict == "FAIL":
        print(f"❌ assign failed: {response.findings[0].message if response.findings else ''}")
        return 1
    print(f"✅ Assigned {args.issue_key} to {args.user}")
    return 0


_AGENT_JSON_COMMANDS: frozenset[str] = frozenset(
    {
        "analyse",
        "analyze",
        "enhance",
        "template",
        "sprint",
        "comment",
        "link-pr",
        "assign",
        "transition",
        "review",
    }
)


def _emit_json_response(response: AgentResponse) -> None:
    """Print a stable JSON envelope to stdout — newline-terminated."""
    print(response.to_json())


def _exit_code_for_exception(exc: BaseException) -> int:
    """Map an exception to the PLAN §6.4 exit-code contract.

    - 77 (EX_NOPERM) for auth failures
    - 75 (EX_TEMPFAIL) for transient / rate-limit failures
    - 1  for everything else (including ValueError / KeyError validation)
    """
    if isinstance(exc, HttpAuthError):
        return 77
    if isinstance(exc, (HttpRateLimitError, HttpTransientError)):
        return 75
    if isinstance(exc, HttpClientError):
        return 1
    if isinstance(exc, HttpError):
        return 1
    if isinstance(exc, (ValueError, KeyError)):
        return 1
    return 1


def _emit_json_error(args: argparse.Namespace, exc: BaseException, exit_code: int) -> None:
    """Write a failure-shaped AgentResponse to stdout (per PLAN §6.4)."""
    command = str(getattr(args, "command", "unknown"))
    issue_key = getattr(args, "issue_key", None)
    response = AgentResponse.failure(
        command=command,
        issue_key=issue_key,
        findings=[
            AgentFinding(
                severity="critical",
                rule="execution.error",
                section=None,
                message=str(exc),
                fix_hint=None,
            )
        ],
        metadata={
            "exit_code": exit_code,
            "exception_type": type(exc).__name__,
        },
    )
    _emit_json_response(response)


def main() -> int:
    """Main entry point"""

    # Parse arguments
    parser = build_parser()
    args = parser.parse_args()

    # Show help if no command
    if not args.command:
        parser.print_help()
        return 1

    json_mode = bool(getattr(args, "json_output", False))

    # Normalise the analyse alias so downstream code only handles one name.
    if args.command == "analyze":
        args.command = "analyse"

    # Normalise transition --to into the positional name slot so the
    # existing handler keeps working.
    if args.command == "transition":
        if not getattr(args, "transition_name", None) and getattr(args, "transition_to", None):
            args.transition_name = args.transition_to

    # Normalise enhance positional issue key onto args.issue_key when no
    # --issue/--sprint provided, so the legacy handler accepts it.
    if args.command == "enhance":
        if not getattr(args, "issue_key", None) and not getattr(args, "sprint_number", None):
            agent_key = getattr(args, "agent_issue_key", None)
            if agent_key:
                args.issue_key = agent_key

    # Configure subcommand short-circuits — it doesn't need a Jira client.
    if args.command == "configure":
        return _handle_configure_command(args)

    # Create composition root (dependency injection). Honour --profile /
    # --config so multi-tenant operators can switch sites with one flag.
    try:
        container = CompositionRoot.create(
            profile_name=getattr(args, "profile", None),
            config_path=getattr(args, "config_path", None),
        )
    except Exception as e:  # pylint: disable=broad-exception-caught
        if json_mode:
            _emit_json_error(args, e, 1)
        else:
            print(f"❌ Failed to initialize: {e}")
        return 1

    # JSON path: route through the agent adapter for any command in the
    # agent contract; everything else falls through to the human-readable
    # handler with a JSON wrapping at the boundary on error.
    if json_mode and args.command in _AGENT_JSON_COMMANDS:
        try:
            response = agent_adapter.dispatch_json(container, args)
            _emit_json_response(response)
            # Verdict-only commands (READY/NOT_READY/PASS/FAIL) all exit 0
            # — the verdict is the signal, not the exit code. Errors that
            # raised an exception are handled below with the exit-code
            # contract. A FAIL verdict from a command that ran cleanly is
            # still exit 0 per PLAN §6.4 ("first item is the agent's
            # pick" / "agent halts on NOT_READY").
            return 0
        except (HttpAuthError, HttpRateLimitError, HttpTransientError) as exc:
            code = _exit_code_for_exception(exc)
            _emit_json_error(args, exc, code)
            return code
        except HttpError as exc:
            _emit_json_error(args, exc, 1)
            return 1
        except (ValueError, KeyError) as exc:
            _emit_json_error(args, exc, 1)
            return 1
        except Exception as exc:  # pylint: disable=broad-exception-caught
            _emit_json_error(args, exc, 1)
            return 1

    # Route to handlers (legacy human-readable path + non-agent commands)
    try:
        command_map = {
            "create": handle_create_command,
            "enhance": handle_enhance_command,
            "docs": handle_docs_command,
            "delete": handle_delete_command,
            "move": handle_move_command,
            "analyse": handle_analyze_command,
            "split": handle_split_command,
            "rebalance": handle_sprint_ops_command,
            "reorganize": handle_sprint_ops_command,
            "sprint-goals": handle_sprint_ops_command,
            "auto": handle_auto_command,
            "report": handle_report_command,
            "dashboard": handle_dashboard_command,
            "verify": handle_verify_command,
            "import": handle_import_command,
            "prepare": handle_prepare_command,
            "context": handle_context_command,
            "standardize": handle_standardize_command,
            "balance": handle_balance_command,
            "template": handle_template_command,
            "remove-label": handle_remove_label_command,
            "goals": handle_goals_command,
            "portfolio-reorg": handle_portfolio_reorg_command,
            "product-docs": handle_product_docs_command,
            "transition": handle_transition_command,
            "confluence": handle_confluence_command,
            # Agent-contract commands handled outside JSON mode too —
            # human-readable summaries.
            "sprint": handle_agent_sprint_command,
            "comment": handle_agent_comment_command,
            "link-pr": handle_agent_link_pr_command,
            "assign": handle_agent_assign_command,
            "review": handle_review_command,
            # PR 5 — doc framework bridge tier
            "framework": handle_framework_command,
        }

        handler_func = command_map.get(args.command)
        if handler_func:
            return handler_func(container, args)

        print(f"❌ Unknown command: {args.command}")
        parser.print_help()
        return 1

    except KeyboardInterrupt:
        print("\n⚠️  Interrupted by user")
        return 130
    except (HttpAuthError, HttpRateLimitError, HttpTransientError) as exc:
        code = _exit_code_for_exception(exc)
        print(f"❌ {type(exc).__name__}: {exc}")
        return code
    except HttpError as exc:
        print(f"❌ HTTP error: {exc}")
        return 1
    except Exception as e:  # pylint: disable=broad-exception-caught
        print(f"❌ Error: {e}")
        if args.debug if hasattr(args, "debug") else False:
            traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
