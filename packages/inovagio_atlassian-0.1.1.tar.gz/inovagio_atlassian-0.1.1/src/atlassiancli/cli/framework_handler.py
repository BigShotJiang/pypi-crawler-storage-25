"""CLI handler for the ``framework`` subcommand group (PR 5).

Each method on :class:`FrameworkCommandHandler` corresponds to one
sub-subcommand under ``atlassiancli framework``:

* ``create-stories`` — :meth:`handle_create_stories`
* ``verify-stories`` — :meth:`handle_verify_stories`
* ``reverse-sync``   — :meth:`handle_reverse_sync`
* ``sync-docs``      — :meth:`handle_sync_docs`
* ``bootstrap``      — :meth:`handle_bootstrap`

When ``json_output`` is true each handler emits an :class:`AgentResponse`
JSON envelope on stdout (PLAN §6.4 contract). Otherwise it prints
human-readable progress + summary lines and returns an integer exit code.
"""

from __future__ import annotations

import json as _json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ..application.agent_response import AgentFinding, AgentResponse
from ..application.framework_services.create_stories_service import (
    CreateStoriesResult,
    CreateStoriesService,
)
from ..application.framework_services.reverse_sync_service import (
    ReverseSyncResult,
    ReverseSyncService,
)
from ..application.framework_services.sync_docs_service import (
    SyncDocsService,
    SyncResult,
)
from ..application.framework_services.verify_stories_service import (
    VerifyResult,
    VerifyStoriesService,
)
from ..domain.framework.config import ProductConfig
from ..infrastructure.confluence_client import ConfluenceApiClient
from ..infrastructure.framework_confluence_client import (
    FrameworkConfluenceClient,
)
from ..infrastructure.framework_jira_client import FrameworkJiraClient
from ..infrastructure.jira_client import JiraApiClient


@dataclass
class FrameworkClientFactory:
    """Builds wrapped framework clients on demand from atlassiancli's clients.

    Allows the handler to be constructed without forcing client creation —
    callers supplying ``--dry-run`` or hitting a missing-config exit don't
    need network credentials.
    """

    jira_api: JiraApiClient
    confluence_api: ConfluenceApiClient

    def jira(self) -> FrameworkJiraClient:
        return FrameworkJiraClient(self.jira_api)

    def confluence(self) -> FrameworkConfluenceClient:
        return FrameworkConfluenceClient(self.confluence_api)


# ---------------------------------------------------------------------------
# Handler
# ---------------------------------------------------------------------------


class FrameworkCommandHandler:
    """Adapts argparse-shaped args into framework-service calls."""

    def __init__(
        self,
        clients: FrameworkClientFactory,
        config_loader: Any,
    ) -> None:
        """Construct the handler.

        Parameters
        ----------
        clients:
            Factory that produces wrapped framework clients lazily.
        config_loader:
            Module with ``load_product_config``, ``list_configured_products``,
            and ``get_credentials`` functions (mirrors the source script's
            ``_docframework`` surface). Defaults to
            :mod:`atlassiancli.infrastructure.framework_config`.
        """
        self._clients = clients
        self._cfg_loader = config_loader

    # ------------------------------------------------------------------
    # create-stories
    # ------------------------------------------------------------------

    def handle_create_stories(
        self,
        product: str,
        *,
        filter_epic: str | None,
        filter_id: str | None,
        dry_run: bool,
        skip_link_pass: bool,
        no_transition: bool,
        json_output: bool,
    ) -> int:
        cfg = self._cfg_loader.load_product_config(product)
        client = self._build_jira_client(cfg, dry_run=dry_run)

        log = _make_log("create-stories", json_output)
        service = CreateStoriesService(cfg, client, log=log)
        result = service.create(
            filter_epic=filter_epic,
            filter_id=filter_id,
            dry_run=dry_run,
            skip_link_pass=skip_link_pass,
            no_transition=no_transition,
        )

        if json_output:
            response = _create_stories_response(product, cfg, result)
            print(response.to_json())
            return 0 if not result.errors else 1

        _print_create_stories_summary(cfg, result)
        return 0 if not result.errors else 1

    # ------------------------------------------------------------------
    # verify-stories
    # ------------------------------------------------------------------

    def handle_verify_stories(self, product: str, *, json_output: bool) -> int:
        cfg = self._cfg_loader.load_product_config(product)
        # Verify always needs Jira creds (read-only).
        self._cfg_loader.get_credentials()
        client = self._clients.jira()

        log = _make_log("verify-stories", json_output)
        if not json_output:
            log(f"{'Epic':<6} {'Manifests':>10} {'Jira':>6} {'Done':>6}  Status")
            log("-" * 60)
        service = VerifyStoriesService(cfg, client, log=log)
        result = service.verify()

        if json_output:
            response = _verify_response(product, cfg, result)
            print(response.to_json())
            return 0 if result.green else 1

        _print_verify_summary(cfg, result)
        return 0 if result.green else 1

    # ------------------------------------------------------------------
    # reverse-sync
    # ------------------------------------------------------------------

    def handle_reverse_sync(
        self,
        product: str,
        *,
        filter_epic: str | None,
        dry_run: bool,
        strict: bool,
        json_output: bool,
    ) -> int:
        cfg = self._cfg_loader.load_product_config(product)
        self._cfg_loader.get_credentials()
        client = self._clients.jira()

        log = _make_log("reverse-sync", json_output)
        service = ReverseSyncService(cfg, client, log=log)
        try:
            result = service.reverse_sync(filter_epic=filter_epic, dry_run=dry_run, strict=strict)
        except ValueError as exc:
            return _emit_error(
                "framework.reverse-sync",
                product,
                str(exc),
                json_output=json_output,
            )

        if json_output:
            response = _reverse_sync_response(product, cfg, result)
            print(response.to_json())
            return 0 if not result.failures else 1

        _print_reverse_sync_summary(result)
        return 0 if not result.failures else 1

    # ------------------------------------------------------------------
    # sync-docs
    # ------------------------------------------------------------------

    def handle_sync_docs(
        self,
        product: str,
        *,
        doc: str | None,
        dry_run: bool,
        json_output: bool,
    ) -> int:
        cfg = self._cfg_loader.load_product_config(product)
        self._cfg_loader.get_credentials()
        client = self._clients.confluence()

        log = _make_log("sync-docs", json_output)
        service = SyncDocsService(cfg, client, log=log)
        try:
            result = service.sync(handles=[doc] if doc else None, dry_run=dry_run)
        except ValueError as exc:
            return _emit_error(
                "framework.sync-docs",
                product,
                str(exc),
                json_output=json_output,
            )

        if json_output:
            response = _sync_docs_response(product, cfg, result)
            print(response.to_json())
            return 0 if result.failures == 0 else 1

        log(f"Done — successes={result.successes}, failures={result.failures}")
        return 0 if result.failures == 0 else 1

    # ------------------------------------------------------------------
    # bootstrap (minimal viable validate-the-configured-state gate)
    # ------------------------------------------------------------------

    def handle_bootstrap(
        self,
        product: str,
        *,
        json_output: bool,
        product_name: str | None = None,
        force: bool = False,
        dry_run: bool = False,
        auto_sops: bool = True,
        lang_override: str | None = None,
    ) -> int:
        """Bootstrap a product into the doc framework.

        Two modes, dispatched on whether ``docs/<product>/`` exists:

        - **Scaffold mode** (directory missing): generate
          ``.docframework.yaml`` + the seven mandatory top-level docs +
          ``adrs/`` / ``epics/`` / ``stories/`` / ``evidence/`` directories
          from the templates shipped at
          ``templates/product-doc-tree/``. No network. Idempotent on
          re-run; ``--force`` overwrites existing files.

        - **Parity mode** (directory exists): validate the existing
          ``.docframework.yaml``, run a verify-stories parity check
          (when creds are present), and emit next-step guidance. Original
          behaviour preserved so existing callers keep working.
        """
        log = _make_log("bootstrap", json_output)

        # Scaffold mode: create the doc tree if it isn't there yet.
        product_docs_dir = Path("docs") / product
        if not (product_docs_dir / ".docframework.yaml").is_file():
            return self._handle_bootstrap_scaffold(
                product=product,
                product_name=product_name,
                force=force,
                dry_run=dry_run,
                json_output=json_output,
                log=log,
                auto_sops=auto_sops,
                lang_override=lang_override,
            )

        findings: list[AgentFinding] = []

        # 1. Config check (load_product_config exits 2 on missing — handled).
        cfg = self._cfg_loader.load_product_config(product)
        log(f"Config OK: docs/{cfg.id}/.docframework.yaml")

        # 2. Auth env var check (warn-only, do not exit — bootstrap can run
        #    in a planning context where creds aren't yet in place).
        auth_ok = bool(os.environ.get("ATLASSIAN_EMAIL") and os.environ.get("ATLASSIAN_TOKEN"))
        if auth_ok:
            log("Auth OK: ATLASSIAN_EMAIL + ATLASSIAN_TOKEN set")
        else:
            findings.append(
                AgentFinding(
                    severity="major",
                    rule="bootstrap.auth_missing",
                    section=None,
                    message=(
                        "ATLASSIAN_EMAIL + ATLASSIAN_TOKEN not set — "
                        "verify-stories cannot run until creds are provided"
                    ),
                    fix_hint=("export ATLASSIAN_EMAIL=... and ATLASSIAN_TOKEN=... in this shell"),
                )
            )
            log("WARN: ATLASSIAN_EMAIL + ATLASSIAN_TOKEN not set")

        # 3. Optional parity check (only if auth available).
        verify_result: VerifyResult | None = None
        if auth_ok:
            log("Running verify-stories parity check…")
            client = self._clients.jira()
            service = VerifyStoriesService(cfg, client, log=log)
            verify_result = service.verify()
            if not verify_result.green:
                for line in verify_result.mismatches:
                    findings.append(
                        AgentFinding(
                            severity="major",
                            rule="bootstrap.parity_drift",
                            section=None,
                            message=line,
                            fix_hint=(
                                "Run `atlassiancli framework create-stories "
                                f"--product {cfg.id}` to push missing "
                                "manifests, or `reverse-sync` for the inverse"
                            ),
                        )
                    )

        # 4. Next-step guidance
        next_steps = _bootstrap_next_steps(cfg, auth_ok, verify_result)
        for step in next_steps:
            log(f"  - {step}")

        if json_output:
            response = AgentResponse.success(
                command="framework.bootstrap",
                verdict="PASS" if not findings else "WARN",
                findings=findings,
                metadata={
                    "product": product,
                    "auth_ok": auth_ok,
                    "config_path": str(cfg.docs_dir / ".docframework.yaml"),
                    "epics_configured": list(cfg.jira.epics),
                    "doc_pages_configured": list(cfg.confluence.doc_pages),
                    "verify_green": (verify_result.green if verify_result is not None else None),
                    "next_steps": next_steps,
                },
            )
            print(response.to_json())
        return 0

    # ------------------------------------------------------------------
    # internals
    # ------------------------------------------------------------------

    def _handle_bootstrap_scaffold(
        self,
        *,
        product: str,
        product_name: str | None,
        force: bool,
        dry_run: bool,
        json_output: bool,
        log,
        auto_sops: bool = True,
        lang_override: str | None = None,
    ) -> int:
        """Scaffold mode: generate the doc tree from templates."""
        from ..application.framework_bootstrap import (
            ScaffoldError,
            ScaffoldOptions,
            scaffold_product,
        )

        opts = ScaffoldOptions(
            product_id=product,
            product_name=product_name or product.replace("-", " ").title(),
            project_key=os.environ.get("JIRA_PROJECT_KEY", ""),
            user_email=(
                os.environ.get("ATLASSIAN_USER_EMAIL") or os.environ.get("ATLASSIAN_EMAIL", "")
            ),
            atlassian_site=_strip_scheme(os.environ.get("ATLASSIAN_URL", "")),
            confluence_space=os.environ.get("CONFLUENCE_SPACE", ""),
            repo_root=Path.cwd(),
            force=force,
            dry_run=dry_run,
        )

        try:
            result = scaffold_product(opts)
        except ScaffoldError as exc:
            log(f"❌ Scaffold failed: {exc}")
            if json_output:
                response = AgentResponse.failure(
                    command="framework.bootstrap",
                    findings=[
                        AgentFinding(
                            severity="critical",
                            rule="bootstrap.scaffold_failed",
                            section=None,
                            message=str(exc),
                            fix_hint=None,
                        )
                    ],
                    metadata={"product": product},
                )
                print(response.to_json())
            return 1

        for outcome in result.file_outcomes:
            log(f"  {outcome.action:14s} {outcome.relpath}")
        log(
            f"Scaffold complete: {result.created_count} created, "
            f"{result.skipped_count} skipped (dry_run={result.dry_run})"
        )

        autogen_payload: dict[str, Any] | None = None
        if auto_sops:
            autogen_payload = self._run_autogen_for_scaffold(
                product=product,
                docs_dir=Path(result.docs_dir),
                lang_override=lang_override,
                force=force,
                dry_run=dry_run,
                log=log,
            )

        log("Next steps:")
        for step in result.next_steps:
            log(f"  - {step}")

        if json_output:
            metadata: dict[str, Any] = {
                "product": product,
                "mode": "scaffold",
                "docs_dir": result.docs_dir,
                "dry_run": result.dry_run,
                "created_count": result.created_count,
                "skipped_count": result.skipped_count,
                "file_outcomes": [
                    {"path": o.relpath, "action": o.action, "reason": o.reason}
                    for o in result.file_outcomes
                ],
                "next_steps": result.next_steps,
            }
            if autogen_payload is not None:
                metadata["autogen"] = autogen_payload
            response = AgentResponse(
                command="framework.bootstrap",
                issue_key=None,
                verdict="PASS",
                score=None,
                threshold=None,
                findings=[],
                metadata=metadata,
            )
            print(response.to_json())
        return 0

    # ------------------------------------------------------------------
    # regenerate-sops
    # ------------------------------------------------------------------

    def handle_regenerate_sops(
        self,
        product: str,
        *,
        json_output: bool,
        force: bool = False,
        dry_run: bool = False,
        lang_override: str | None = None,
    ) -> int:
        """Regenerate the SOP set for ``product`` from the detected stack.

        Idempotent: files carrying the ``auto-generated`` header are
        rewritten; files without that header are left alone (user took
        ownership). ``force`` overrides the ownership guard.
        """
        from ..application.sop_autogen import (
            AutogenError,
            AutogenOptions,
            generate_sops,
        )
        from ..application.stack_detector import detect_stack

        log = _make_log("regenerate-sops", json_output)

        docs_dir = Path("docs") / product
        if not docs_dir.is_dir():
            return _emit_error(
                "framework.regenerate-sops",
                product,
                f"docs/{product}/ does not exist; run "
                f"`atlassiancli framework bootstrap --product {product}` first.",
                json_output=json_output,
            )

        stack = detect_stack(Path.cwd())
        if lang_override:
            from ..application.data.language_profiles import get_profile
            from ..application.stack_detector import ProjectStack

            profile = get_profile(lang_override)
            if profile.language == "unknown":
                return _emit_error(
                    "framework.regenerate-sops",
                    product,
                    f"unknown --lang {lang_override!r}; "
                    "see `atlassiancli framework regenerate-sops --help` "
                    "for supported languages.",
                    json_output=json_output,
                )
            stack = ProjectStack(
                primary_language=profile.language,
                languages=(profile.language,),
                frameworks=(),
                profile=profile,
            )

        if stack.is_unknown:
            return _emit_error(
                "framework.regenerate-sops",
                product,
                "could not detect project stack; pass --lang <name> "
                "to override (e.g. --lang python).",
                json_output=json_output,
            )

        sops_dir = docs_dir / "sops"
        opts = AutogenOptions(
            stack=stack,
            output_dir=sops_dir,
            force=force,
            dry_run=dry_run,
        )
        try:
            result = generate_sops(opts)
        except AutogenError as exc:
            return _emit_error(
                "framework.regenerate-sops",
                product,
                str(exc),
                json_output=json_output,
            )

        log(f"Stack: {result.stack_signature}")
        for outcome in result.file_outcomes:
            log(f"  {outcome.action:18s} sops/{outcome.relpath}")
        log(
            f"Regenerate complete: {result.created_count} written, "
            f"{result.skipped_count} skipped (dry_run={result.dry_run})"
        )

        if json_output:
            response = AgentResponse(
                command="framework.regenerate-sops",
                issue_key=None,
                verdict="PASS",
                score=None,
                threshold=None,
                findings=[],
                metadata={
                    "product": product,
                    "stack_signature": result.stack_signature,
                    "primary_language": stack.primary_language,
                    "frameworks": list(stack.frameworks),
                    "dry_run": result.dry_run,
                    "created_count": result.created_count,
                    "skipped_count": result.skipped_count,
                    "file_outcomes": [
                        {
                            "path": o.relpath,
                            "action": o.action,
                            "reason": o.reason,
                        }
                        for o in result.file_outcomes
                    ],
                },
            )
            print(response.to_json())
        return 0

    # ------------------------------------------------------------------
    # internal — autogen wiring shared by bootstrap + regenerate
    # ------------------------------------------------------------------

    def _run_autogen_for_scaffold(
        self,
        *,
        product: str,
        docs_dir: Path,
        lang_override: str | None,
        force: bool,
        dry_run: bool,
        log,
    ) -> dict[str, Any]:
        """Detect stack + run the SOP autogenerator under bootstrap.

        Always returns a payload (never raises) so a missing-stack repo
        falls back gracefully — bootstrap's primary job (scaffolding the
        doc tree) has already succeeded by the time this runs.
        """
        from ..application.sop_autogen import (
            AutogenError,
            AutogenOptions,
            generate_sops,
        )
        from ..application.stack_detector import detect_stack

        stack = detect_stack(Path.cwd())
        if lang_override:
            from ..application.data.language_profiles import get_profile
            from ..application.stack_detector import ProjectStack

            profile = get_profile(lang_override)
            if profile.language != "unknown":
                stack = ProjectStack(
                    primary_language=profile.language,
                    languages=(profile.language,),
                    frameworks=(),
                    profile=profile,
                )

        if stack.is_unknown:
            log(
                "Auto-SOPs: stack not detected — falling back to generic "
                "templates. Run `atlassiancli framework regenerate-sops "
                f"--product {product} --lang <name>` to override."
            )
            return {
                "ran": False,
                "reason": "stack_unknown",
                "stack_signature": "",
                "file_outcomes": [],
            }

        opts = AutogenOptions(
            stack=stack,
            output_dir=docs_dir / "sops",
            force=force,
            dry_run=dry_run,
        )
        try:
            result = generate_sops(opts)
        except AutogenError as exc:
            log(f"Auto-SOPs failed: {exc}")
            return {
                "ran": False,
                "reason": "autogen_error",
                "error": str(exc),
                "stack_signature": "",
                "file_outcomes": [],
            }

        log(f"Auto-SOPs: stack={result.stack_signature}")
        for outcome in result.file_outcomes:
            log(f"  {outcome.action:18s} sops/{outcome.relpath}")

        return {
            "ran": True,
            "stack_signature": result.stack_signature,
            "primary_language": stack.primary_language,
            "frameworks": list(stack.frameworks),
            "created_count": result.created_count,
            "skipped_count": result.skipped_count,
            "file_outcomes": [
                {"path": o.relpath, "action": o.action, "reason": o.reason}
                for o in result.file_outcomes
            ],
        }

    def _build_jira_client(
        self, cfg: ProductConfig, *, dry_run: bool
    ) -> FrameworkJiraClient | None:
        """Return a Jira client unless dry-run + no creds."""
        have_creds = bool(os.environ.get("ATLASSIAN_EMAIL") and os.environ.get("ATLASSIAN_TOKEN"))
        if not have_creds:
            if not dry_run:
                # Mirrors source UX: get_credentials exits 2.
                self._cfg_loader.get_credentials()
            return None
        return self._clients.jira()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_log(_command: str, json_output: bool):
    """Return a print-or-noop logger that respects ``--json`` output mode."""
    if json_output:
        # In JSON mode every line of progress would corrupt the envelope —
        # silence the service log entirely.
        return lambda _msg: None
    return print


def _strip_scheme(url: str) -> str:
    """Return the host portion of a URL or the input unchanged if it
    doesn't carry a scheme. Used to render an Atlassian site URL into
    the ``acme.atlassian.net`` shape expected by ``.docframework.yaml``."""
    if not url:
        return ""
    for prefix in ("https://", "http://"):
        if url.startswith(prefix):
            return url[len(prefix) :].rstrip("/")
    return url.rstrip("/")


def _emit_error(command: str, product: str, message: str, *, json_output: bool) -> int:
    """Emit a uniform error response (JSON envelope or stderr text)."""
    if json_output:
        response = AgentResponse.failure(
            command=command,
            issue_key=None,
            findings=[
                AgentFinding(
                    severity="critical",
                    rule="framework.error",
                    section=None,
                    message=message,
                    fix_hint=None,
                )
            ],
            metadata={"product": product},
        )
        print(response.to_json())
    else:
        print(f"ERROR: {message}")
    return 1


def _create_stories_response(
    product: str, cfg: ProductConfig, result: CreateStoriesResult
) -> AgentResponse:
    findings = [
        AgentFinding(
            severity="major",
            rule="create_stories.error",
            section=None,
            message=err,
            fix_hint=None,
        )
        for err in result.errors
    ]
    verdict = "FAIL" if result.errors else "PASS"
    return AgentResponse(
        command="framework.create-stories",
        verdict=verdict,
        findings=findings,
        metadata={
            "product": product,
            "product_name": cfg.name,
            "dry_run": result.dry_run,
            "discovered": result.discovered,
            "created": result.created,
            "skipped_existing": result.skipped_existing,
            "linked": result.linked,
            "link_skipped": result.link_skipped,
            "transitioned": result.transitioned,
            "transition_skipped": result.transition_skipped,
            "stories": result.s_to_key,
        },
    )


def _print_create_stories_summary(cfg: ProductConfig, result: CreateStoriesResult) -> None:
    print(f"\nProduct: {cfg.name}  ({'DRY RUN' if result.dry_run else 'EXECUTE'})")
    print(f"  Discovered: {result.discovered}")
    print(f"  Pass 1 (create): created={result.created}  skipped={result.skipped_existing}")
    print(f"  Pass 2 (link): linked={result.linked}  skipped={result.link_skipped}")
    print(
        f"  Pass 3 (transition): transitioned={result.transitioned}  "
        f"skipped={result.transition_skipped}"
    )
    if result.errors:
        print(f"  Errors: {len(result.errors)}")
        for err in result.errors:
            print(f"    - {err}")


def _verify_response(product: str, cfg: ProductConfig, result: VerifyResult) -> AgentResponse:
    findings = [
        AgentFinding(
            severity="major",
            rule="verify.delta",
            section=None,
            message=line,
            fix_hint=None,
        )
        for line in result.mismatches
    ]
    return AgentResponse(
        command="framework.verify-stories",
        verdict="PASS" if result.green else "FAIL",
        findings=findings,
        metadata={
            "product": product,
            "product_name": cfg.name,
            "total_manifests": result.total_manifests,
            "total_jira": result.total_jira,
            "total_done": result.total_done,
            "rows": [
                {
                    "epic": r.epic,
                    "epic_key": r.epic_key,
                    "manifests": r.manifests,
                    "jira_total": r.jira_total,
                    "jira_done": r.jira_done,
                    "delta": r.delta,
                    "status": r.status,
                }
                for r in result.rows
            ],
        },
    )


def _print_verify_summary(cfg: ProductConfig, result: VerifyResult) -> None:
    print("-" * 60)
    print(
        f"{'TOTAL':<6} {result.total_manifests:>10} {result.total_jira:>6} {result.total_done:>6}"
    )
    if result.green:
        print(f"\nGREEN: every epic's manifest count matches Jira for product {cfg.name}.")
    else:
        print("\nMISMATCHES:")
        for line in result.mismatches:
            print(f"  - {line}")


def _reverse_sync_response(
    product: str, cfg: ProductConfig, result: ReverseSyncResult
) -> AgentResponse:
    findings: list[AgentFinding] = []
    for w in result.warnings:
        findings.append(
            AgentFinding(
                severity="minor",
                rule="reverse_sync.warning",
                section=None,
                message=w,
                fix_hint=None,
            )
        )
    for key, err in result.failures:
        findings.append(
            AgentFinding(
                severity="major",
                rule="reverse_sync.parse_failure",
                section=None,
                message=f"{key}: {err}",
                fix_hint=None,
            )
        )
    verdict = "FAIL" if result.failures else "PASS"
    return AgentResponse(
        command="framework.reverse-sync",
        verdict=verdict,
        findings=findings,
        metadata={
            "product": product,
            "product_name": cfg.name,
            "dry_run": result.dry_run,
            "materialised": result.materialised,
            "skipped_existing": result.skipped_existing,
            "written_paths": result.written_paths,
        },
    )


def _print_reverse_sync_summary(result: ReverseSyncResult) -> None:
    print(f"\nMaterialised: {result.materialised}")
    print(f"Skipped (already on disk): {result.skipped_existing}")
    if result.warnings:
        print(f"Warnings: {len(result.warnings)}")
        for w in result.warnings:
            print(f"  - {w}")
    if result.failures:
        print(f"Parse failures: {len(result.failures)}")
        for key, err in result.failures:
            print(f"  - {key}: {err}")


def _sync_docs_response(product: str, cfg: ProductConfig, result: SyncResult) -> AgentResponse:
    findings: list[AgentFinding] = []
    outcomes_payload: list[dict[str, Any]] = []
    for outcome in result.outcomes:
        outcomes_payload.append(
            {
                "handle": outcome.handle,
                "page_id": outcome.page_id,
                "success": outcome.success,
                "skipped_confluence_only": outcome.skipped_confluence_only,
                "next_version": outcome.next_version,
                "error": outcome.error,
            }
        )
        if not outcome.success:
            findings.append(
                AgentFinding(
                    severity="major",
                    rule="sync_docs.failure",
                    section=None,
                    message=outcome.error or f"{outcome.handle} failed",
                    fix_hint=None,
                )
            )
    return AgentResponse(
        command="framework.sync-docs",
        verdict="PASS" if result.failures == 0 else "FAIL",
        findings=findings,
        metadata={
            "product": product,
            "product_name": cfg.name,
            "dry_run": result.dry_run,
            "successes": result.successes,
            "failures": result.failures,
            "outcomes": outcomes_payload,
        },
    )


def _bootstrap_next_steps(
    cfg: ProductConfig,
    auth_ok: bool,
    verify_result: VerifyResult | None,
) -> list[str]:
    """Produce the operator-facing next-step list the bootstrap surfaces."""
    steps: list[str] = []
    if not auth_ok:
        steps.append(
            "Set ATLASSIAN_EMAIL + ATLASSIAN_TOKEN env vars, then re-run "
            "`atlassiancli framework bootstrap --product " + cfg.id + "`."
        )
        return steps

    if not cfg.jira.epics:
        steps.append(
            f"docs/{cfg.id}/.docframework.yaml has no jira.epics entries — "
            "configure the epic short -> Jira key map before running "
            "create-stories."
        )
    if not cfg.confluence.doc_pages:
        steps.append(
            f"docs/{cfg.id}/.docframework.yaml has no confluence.doc_pages "
            "entries — reserve Confluence pages and add their ids to the "
            "doc_pages map before running sync-docs."
        )
    if verify_result is not None and not verify_result.green:
        steps.append(
            "verify-stories shows drift — run "
            f"`atlassiancli framework create-stories --product {cfg.id} "
            "--dry-run` to preview, then drop --dry-run to push missing "
            "stories."
        )
    if not steps:
        steps.append(
            "Bootstrap green — proceed with normal operation: "
            "`atlassiancli framework create-stories / verify-stories / "
            "sync-docs --product " + cfg.id + "` as needed."
        )
    return steps


# Re-export json_dumps just for convenience in CLI main where we may want
# to pretty-print things consistently.
__all__ = [
    "FrameworkClientFactory",
    "FrameworkCommandHandler",
]


# ---------------------------------------------------------------------------
# Defensive: guard against accidental dependency on stdlib ``json`` aliasing
# ---------------------------------------------------------------------------
# (The handlers above use the imported `_json` only via AgentResponse, so
# this re-export is a no-op for tests but documents intent.)
_ = _json
_ = Path
