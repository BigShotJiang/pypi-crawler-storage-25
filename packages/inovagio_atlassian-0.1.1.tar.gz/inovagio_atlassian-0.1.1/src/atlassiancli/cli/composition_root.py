#!/usr/bin/env python3
"""
Dependency Injection Composition Root

Wires up all dependencies and creates service instances.
Single place where all dependencies are composed.

REFACTORED FOR DRY ARCHITECTURE:
- IDocumentImporter: Many implementations (markdown, confluence, yaml)
- DocumentAnalyzer: ONE implementation that works with any ImportedDocument
- This ensures analysis logic is NOT duplicated

Author: Inovagio Engineering Team
"""

import os
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .framework_handler import FrameworkCommandHandler

from ..application.expert_enhancement_service import ExpertEnhancementService
from ..application.services import (
    AdvancedEnhancementService,
    AutomationService,
    BalanceCapacityService,
    ContextInfoService,
    DashboardService,
    DocumentSyncService,
    HealthReportService,
    ImportService,
    IssueAnalysisService,
    IssueCreationService,
    IssueDeletionService,
    IssueEnhancementService,
    IssueTransitionService,
    LabelRemovalService,
    PrepareStoryService,
    ReportingService,
    SprintGoalsService,
    SprintManagementService,
    SprintOperationsService,
    StandardizeStoryService,
    StorySplittingService,
    TemplateGenerationService,
    VerificationService,
)
from ..infrastructure.architecture_analyzer import ArchitectureAnalyzer
from ..infrastructure.backlog_analyzer import JiraBacklogAnalyzer
from ..infrastructure.codebase_cross_referencer import CodebaseCrossReferencerService
from ..infrastructure.config import AtlassianConfig
from ..infrastructure.confluence_client import (
    ConfluenceApiClient,
    ConfluencePageRepository,
)
from ..infrastructure.document_analyzer import DocumentAnalyzer

# NEW DRY ARCHITECTURE: Separate importers + single analyzer
from ..infrastructure.document_importers import (
    ConfluencePageImporter,
    DocumentImporterFactory,
    MarkdownFileImporter,
    YamlFileImporter,
)
from ..infrastructure.domain_services import (
    BoundedContextResolverService,
    ComponentDeriverService,
    LabelDeriverService,
    PriorityCalculatorService,
    StoryPointEstimatorService,
    ThemeDetectorService,
)
from ..infrastructure.duplicate_detector import JiraDuplicateDetector
from ..infrastructure.jira_client import JiraApiClient, JiraIssueRepository
from ..infrastructure.mappers import ConfluenceContentMapper, IssueMapper

# Domain interfaces


class CompositionRoot:
    """
    IoC Container - Composes all dependencies.

    SOLID Compliance:
    - Single Responsibility: Only wires up dependencies
    - Open/Closed: New services are added without modifying existing code
    - Dependency Inversion: Creates concrete implementations for interfaces

    Usage:
        container = CompositionRoot.create()
        creation_service = container.issue_creation_service()
    """

    def __init__(self, config: AtlassianConfig):
        self._config = config

        # Infrastructure - API clients
        self._jira_client = JiraApiClient(config)
        self._confluence_client = ConfluenceApiClient(config)

        # Infrastructure - Mappers
        self._issue_mapper = IssueMapper(config)
        self._content_mapper = ConfluenceContentMapper()

        # Infrastructure - Repositories
        self._issue_repo = JiraIssueRepository(self._jira_client, self._issue_mapper)
        self._confluence_repo = ConfluencePageRepository(self._confluence_client)

        # Infrastructure - Domain Services
        self._theme_detector = ThemeDetectorService()
        self._context_resolver = BoundedContextResolverService()
        self._label_deriver = LabelDeriverService()
        self._component_deriver = ComponentDeriverService()
        self._priority_calculator = PriorityCalculatorService()
        self._story_point_estimator = StoryPointEstimatorService()
        self._duplicate_detector = JiraDuplicateDetector(self._issue_repo, config)
        # Pass API client for direct access to sprint data (customfield_10020)
        self._backlog_analyzer = JiraBacklogAnalyzer(
            self._issue_repo, config, api_client=self._jira_client
        )
        self._arch_analyzer = ArchitectureAnalyzer()

        # Codebase cross-referencer (lazy initialization - scans on first use)
        self._codebase_cross_referencer = CodebaseCrossReferencerService()
        self._workspace_root = self._detect_workspace_root()

        # ====================================================================
        # NEW DRY ARCHITECTURE: Separate importers + single analyzer
        # ====================================================================
        # Importers (many - one per source type)
        self._markdown_importer = MarkdownFileImporter()
        self._yaml_importer = YamlFileImporter()
        self._confluence_importer = ConfluencePageImporter(self._confluence_repo)

        # Importer factory (selects appropriate importer for source)
        self._importer_factory = DocumentImporterFactory(self._confluence_repo)

        # Analyzer (ONE - works with any ImportedDocument)
        self._document_analyzer = DocumentAnalyzer(
            theme_detector=self._theme_detector,
            context_resolver=self._context_resolver,
            priority_calculator=self._priority_calculator,
        )

    def _detect_workspace_root(self) -> str:
        """
        Detect the workspace root directory.

        Looks for markers like CMakeLists.txt, .git, or AGENTS.md to find
        the Inovagio repository root.
        """
        # Start from current file location and walk up
        current = Path(__file__).resolve()

        # Walk up looking for workspace markers
        markers = ["CMakeLists.txt", ".git", "AGENTS.md", "core"]

        for parent in [current] + list(current.parents):
            if any((parent / marker).exists() for marker in markers):
                # Verify this is the inovagio workspace
                if (parent / "core").exists() and (parent / "CMakeLists.txt").exists():
                    return str(parent)

        # Fallback: Use INOVAGIO_WORKSPACE env var or current working directory
        return os.environ.get("INOVAGIO_WORKSPACE", str(Path.cwd()))

    @classmethod
    def create(
        cls,
        *,
        profile_name: str | None = None,
        config_path: str | None = None,
    ) -> "CompositionRoot":
        """Factory method — loads config with the documented precedence chain.

        With no arguments this is equivalent to the old behaviour (env vars
        only). When ``profile_name`` or ``config_path`` is supplied, the
        per-user profile / explicit config file is layered under env vars.
        """
        if profile_name is None and config_path is None:
            config = AtlassianConfig.from_environment()
        else:
            config = AtlassianConfig.from_profile(
                profile_name=profile_name,
                config_path=config_path,
            )
        return cls(config)

    def jira_client(self) -> JiraApiClient:
        """Get Jira API client for direct API access"""
        return self._jira_client

    def issue_creation_service(self) -> IssueCreationService:
        """Get issue creation service with all dependencies"""
        return IssueCreationService(
            issue_repo=self._issue_repo,
            theme_detector=self._theme_detector,
            context_resolver=self._context_resolver,
            label_deriver=self._label_deriver,
            component_deriver=self._component_deriver,
            priority_calculator=self._priority_calculator,
        )

    def issue_enhancement_service(self) -> IssueEnhancementService:
        """Get issue enhancement service"""
        return IssueEnhancementService(
            issue_repo=self._issue_repo,
            theme_detector=self._theme_detector,
            context_resolver=self._context_resolver,
            doc_sync_service=self.document_sync_service(),
            analysis_service=self.issue_analysis_service(),
            label_deriver=self._label_deriver,
            component_deriver=self._component_deriver,
        )

    def expert_enhancement_service(self) -> ExpertEnhancementService:
        """Get expert enhancement service (PhD-level analysis with Jira wiki format)"""
        return ExpertEnhancementService(
            issue_repo=self._issue_repo,
            analysis_service=self.issue_analysis_service(),
            theme_detector=self._theme_detector,
            context_resolver=self._context_resolver,
            label_deriver=self._label_deriver,
            component_deriver=self._component_deriver,
            priority_calculator=self._priority_calculator,
            story_point_estimator=self._story_point_estimator,
            arch_analyzer=self._arch_analyzer,
        )

    def document_sync_service(self) -> DocumentSyncService:
        """Get document sync service"""
        return DocumentSyncService(
            issue_repo=self._issue_repo,
            confluence_repo=self._confluence_repo,
            content_mapper=self._content_mapper,
            root_page_id=self._config.confluence_parent_page_id,
        )

    def sprint_management_service(self) -> SprintManagementService:
        """Get sprint management service"""
        return SprintManagementService(
            issue_repo=self._issue_repo,
        )

    def issue_analysis_service(self) -> IssueAnalysisService:
        """Get issue analysis service"""
        return IssueAnalysisService(issue_repo=self._issue_repo, arch_analyzer=self._arch_analyzer)

    def story_splitting_service(self) -> StorySplittingService:
        """Get story splitting service"""
        return StorySplittingService(
            issue_repo=self._issue_repo,
        )

    def sprint_operations_service(self) -> SprintOperationsService:
        """Get sprint operations service"""
        return SprintOperationsService(
            issue_repo=self._issue_repo,
        )

    def automation_service(self) -> AutomationService:
        """Get automation service"""
        return AutomationService(
            issue_repo=self._issue_repo,
            analysis_service=self.issue_analysis_service(),
            expert_enhancement_service=self.expert_enhancement_service(),
            splitting_service=self.story_splitting_service(),
        )

    def reporting_service(self) -> ReportingService:
        """Get reporting service"""
        return ReportingService(
            issue_repo=self._issue_repo,
        )

    def verification_service(self) -> VerificationService:
        """Get verification service"""
        return VerificationService(
            issue_repo=self._issue_repo,
        )

    def import_service(self) -> ImportService:
        """
        Get import service with all dependencies injected.

        NEW DRY ARCHITECTURE:
        - Uses DocumentImporterFactory for source selection
        - Uses single DocumentAnalyzer for ALL document types
        - Analysis logic is NOT duplicated per source
        """
        return ImportService(
            issue_repo=self._issue_repo,
            confluence_repo=self._confluence_repo,
            theme_detector=self._theme_detector,
            context_resolver=self._context_resolver,
            priority_calculator=self._priority_calculator,
            duplicate_detector=self._duplicate_detector,
            codebase_cross_referencer=self._codebase_cross_referencer,
            backlog_analyzer=self._backlog_analyzer,
            # NEW DRY ARCHITECTURE
            importer_factory=self._importer_factory,
            document_analyzer=self._document_analyzer,
            doc_sync_service=self.document_sync_service(),
        )

    def duplicate_detector(self) -> JiraDuplicateDetector:
        """
        Get duplicate detector service.

        Used for checking if similar Jira issues already exist.
        """
        return self._duplicate_detector

    def backlog_analyzer(self) -> JiraBacklogAnalyzer:
        """
        Get backlog analyzer service.

        Used for comprehensive analysis of all Jira backlog items:
        - Epics/stories grouped by bounded context
        - Sprint allocation
        - In-progress work tracking
        - Coverage gaps
        - Conflict identification
        """
        return self._backlog_analyzer

    def codebase_cross_referencer(self, scan: bool = True) -> CodebaseCrossReferencerService:
        """
        Get codebase cross-referencer service.

        Scans the Inovagio codebase to validate proposed work items against:
        - Existing interfaces (core/**/*.hpp)
        - docs/architecture/context_map.md
        - docs/architecture/domain_glossary.md

        Args:
            scan: Whether to scan codebase if not already scanned (default: True)

        Returns:
            CodebaseCrossReferencerService instance
        """
        if scan and not self._codebase_cross_referencer.is_scanned:
            self._codebase_cross_referencer.scan_codebase(self._workspace_root)
        return self._codebase_cross_referencer

    # ========================================================================
    # NEW DRY ARCHITECTURE: Importers + Single Analyzer
    # ========================================================================

    def importer_factory(self) -> DocumentImporterFactory:
        """
        Get the document importer factory.

        USAGE:
            factory = container.importer_factory()
            importer = factory.get_importer(source)
            document = importer.import_document(source)

        Returns:
            DocumentImporterFactory that selects appropriate importer
        """
        return self._importer_factory

    def document_analyzer(self) -> DocumentAnalyzer:
        """
        Get the SINGLE document analyzer.

        DRY: ONE analyzer works with any ImportedDocument.
        Analysis logic is NOT duplicated per source type.

        USAGE:
            importer = factory.get_importer(source)
            document = importer.import_document(source)
            analyzer = container.document_analyzer()
            result = analyzer.analyze(document)

        Returns:
            DocumentAnalyzer instance
        """
        return self._document_analyzer

    def markdown_importer(self) -> MarkdownFileImporter:
        """Get markdown file importer."""
        return self._markdown_importer

    def confluence_importer(self) -> ConfluencePageImporter:
        """Get Confluence page importer."""
        return self._confluence_importer

    def yaml_importer(self) -> YamlFileImporter:
        """Get YAML file importer."""
        return self._yaml_importer

    @property
    def workspace_root(self) -> str:
        """Get detected workspace root path."""
        return self._workspace_root

    def advanced_enhancement_service(self) -> AdvancedEnhancementService:
        """Get advanced enhancement service"""
        return AdvancedEnhancementService(
            issue_repo=self._issue_repo,
        )

    def prepare_story_service(self) -> PrepareStoryService:
        """Get story preparation service"""
        return PrepareStoryService(
            issue_repo=self._issue_repo,
        )

    def context_info_service(self) -> ContextInfoService:
        """Get context info service"""
        return ContextInfoService(
            context_resolver=self._context_resolver,
        )

    def standardize_story_service(self) -> StandardizeStoryService:
        """Get story standardization service"""
        return StandardizeStoryService(
            issue_repo=self._issue_repo,
        )

    def balance_capacity_service(self) -> BalanceCapacityService:
        """Get capacity balance service"""
        return BalanceCapacityService(
            issue_repo=self._issue_repo,
        )

    def template_generation_service(self) -> TemplateGenerationService:
        """Get template generation service"""
        return TemplateGenerationService()

    def label_removal_service(self) -> LabelRemovalService:
        """Get label removal service"""
        return LabelRemovalService(
            issue_repo=self._issue_repo,
        )

    def sprint_goals_service(self) -> SprintGoalsService:
        """Get sprint goals service"""
        return SprintGoalsService(
            issue_repo=self._issue_repo,
            theme_detector=self._theme_detector,
        )

    def health_report_service(self) -> HealthReportService:
        """Get health report service"""
        return HealthReportService(
            issue_repo=self._issue_repo,
        )

    def issue_deletion_service(self) -> IssueDeletionService:
        """Get issue deletion service"""
        return IssueDeletionService(
            issue_repo=self._issue_repo,
        )

    def issue_transition_service(self) -> IssueTransitionService:
        """Get issue transition service"""
        return IssueTransitionService(
            issue_repo=self._issue_repo,
        )

    def dashboard_service(self) -> DashboardService:
        """Get dashboard provisioning service."""
        return DashboardService(
            jira_api=self._jira_client,
            config=self._config,
        )

    @property
    def confluence_repo(self) -> ConfluencePageRepository:
        """Get confluence repository"""
        return self._confluence_repo

    # ========================================================================
    # PR 5 — Doc framework bridge tier
    # ========================================================================

    def framework_command_handler(self) -> "FrameworkCommandHandler":
        """Build the doc-framework subcommand handler (PR 5).

        Lazily wires :class:`FrameworkClientFactory` over the existing
        Jira / Confluence API clients so the framework subcommands share
        auth + transport with the rest of atlassiancli.
        """
        from ..infrastructure import framework_config as _framework_config_loader
        from .framework_handler import (
            FrameworkClientFactory,
            FrameworkCommandHandler,
        )

        factory = FrameworkClientFactory(
            jira_api=self._jira_client,
            confluence_api=self._confluence_client,
        )
        return FrameworkCommandHandler(
            clients=factory,
            config_loader=_framework_config_loader,
        )
