"""Agent-callable adapters for the SOP analyzer + commit gate.

Wraps :mod:`atlassiancli.application.sop_manifest` +
:mod:`atlassiancli.application.sop_runner` in
:class:`~atlassiancli.application.agent_response.AgentResponse` envelopes
so the autonomous-dev system gets identical JSON shape across all
agent-callable commands.

Three handlers:

- :func:`sop_story_check_to_json` — Phase 2 story-time review. Reads the
  manifest, fetches the story description via the issue repository, and
  evaluates every ``phase: story`` rule.
- :func:`sop_commit_gate_to_json` — Phase 6 / pre-commit gate. Reads the
  manifest, walks the staged diff, evaluates every ``phase: commit`` rule.
  No Jira call required.
- :func:`sop_validate_manifest_to_json` — schema / regex validator. Loads
  the manifest, reports any structural problems.

Exit-code semantics live with the calling site in :mod:`cli.main`; these
handlers only shape the response.
"""

from __future__ import annotations

import time
from pathlib import Path

from ..application.agent_response import AgentFinding, AgentResponse
from ..application.sop_manifest import (
    SopManifestError,
    load_manifest,
    validate_manifest,
)
from ..application.sop_runner import (
    SopFinding,
    run_commit_gate,
    run_story_check,
    staged_files_from_git,
)
from ..domain.value_objects import IssueKey
from .composition_root import CompositionRoot

DEFAULT_MANIFEST_PATH = "sops/sop-manifest.yaml"


# ---------------------------------------------------------------------------
# Phase 2 — analyze sop
# ---------------------------------------------------------------------------


def sop_story_check_to_json(
    container: CompositionRoot,
    issue_key: str,
    *,
    manifest_path: str | None = None,
) -> AgentResponse:
    started = time.monotonic()
    path = manifest_path or DEFAULT_MANIFEST_PATH

    try:
        manifest = load_manifest(path)
    except SopManifestError as exc:
        return AgentResponse.failure(
            command="analyse.sop",
            issue_key=issue_key,
            findings=[
                AgentFinding(
                    severity="critical",
                    rule="sop.manifest_load_failed",
                    section=None,
                    message=str(exc),
                    fix_hint=f"Ensure {path} exists and is a valid SOP manifest.",
                )
            ],
            metadata={"manifest_path": path},
        )

    issue = container._issue_repo.find_by_key(IssueKey(issue_key))
    if issue is None:
        return AgentResponse.failure(
            command="analyse.sop",
            issue_key=issue_key,
            findings=[
                AgentFinding(
                    severity="critical",
                    rule="sop.story_not_found",
                    section=None,
                    message=f"Issue {issue_key} not found",
                    fix_hint=None,
                )
            ],
            metadata={"manifest_path": path},
        )

    description = getattr(issue, "description", "") or ""
    findings = run_story_check(manifest, description=description)
    blocking = [f for f in findings if f.severity == "blocking"]
    elapsed_ms = int((time.monotonic() - started) * 1000)

    return AgentResponse(
        command="analyse.sop",
        issue_key=issue_key,
        verdict="READY" if not blocking else "NOT_READY",
        score=None,
        threshold=None,
        findings=[_to_agent_finding(f) for f in findings],
        metadata={
            "manifest_path": path,
            "elapsed_ms": elapsed_ms,
            "story_rules_evaluated": sum(1 for r in manifest.rules if r.phase in ("story", "both")),
            "blocking_count": len(blocking),
            "total_findings": len(findings),
        },
    )


# ---------------------------------------------------------------------------
# Phase 6 — framework sop-commit-gate
# ---------------------------------------------------------------------------


def sop_commit_gate_to_json(
    *,
    manifest_path: str | None = None,
    repo_root: Path | None = None,
    staged_files: list[str] | None = None,
) -> AgentResponse:
    started = time.monotonic()
    path = manifest_path or DEFAULT_MANIFEST_PATH

    try:
        manifest = load_manifest(path)
    except SopManifestError as exc:
        return AgentResponse.failure(
            command="framework.sop-commit-gate",
            issue_key=None,
            findings=[
                AgentFinding(
                    severity="critical",
                    rule="sop.manifest_load_failed",
                    section=None,
                    message=str(exc),
                    fix_hint=f"Ensure {path} exists and is a valid SOP manifest.",
                )
            ],
            metadata={"manifest_path": path},
        )

    if staged_files is None:
        staged_files = staged_files_from_git(repo_root)

    findings = run_commit_gate(manifest, staged_files=staged_files, repo_root=repo_root)
    blocking = [f for f in findings if f.severity == "blocking"]
    elapsed_ms = int((time.monotonic() - started) * 1000)

    return AgentResponse(
        command="framework.sop-commit-gate",
        issue_key=None,
        verdict="PASS" if not blocking else "FAIL",
        score=None,
        threshold=None,
        findings=[_to_agent_finding(f) for f in findings],
        metadata={
            "manifest_path": path,
            "elapsed_ms": elapsed_ms,
            "staged_files_count": len(staged_files),
            "commit_rules_evaluated": sum(
                1 for r in manifest.rules if r.phase in ("commit", "both")
            ),
            "blocking_count": len(blocking),
            "total_findings": len(findings),
        },
    )


# ---------------------------------------------------------------------------
# framework sop-validate-manifest
# ---------------------------------------------------------------------------


def sop_validate_manifest_to_json(
    *,
    manifest_path: str | None = None,
) -> AgentResponse:
    started = time.monotonic()
    path = manifest_path or DEFAULT_MANIFEST_PATH

    try:
        manifest = load_manifest(path)
    except SopManifestError as exc:
        return AgentResponse.failure(
            command="framework.sop-validate-manifest",
            issue_key=None,
            findings=[
                AgentFinding(
                    severity="critical",
                    rule="sop.manifest_load_failed",
                    section=None,
                    message=str(exc),
                    fix_hint=f"Ensure {path} exists and is a valid SOP manifest.",
                )
            ],
            metadata={"manifest_path": path},
        )

    errors = validate_manifest(manifest)
    elapsed_ms = int((time.monotonic() - started) * 1000)

    return AgentResponse(
        command="framework.sop-validate-manifest",
        issue_key=None,
        verdict="PASS" if not errors else "FAIL",
        score=None,
        threshold=None,
        findings=[
            AgentFinding(
                severity="major",
                rule=f"sop.manifest.{e.field.replace('.', '_')}",
                section=e.rule_id,
                message=e.message,
                fix_hint=None,
            )
            for e in errors
        ],
        metadata={
            "manifest_path": path,
            "elapsed_ms": elapsed_ms,
            "rules_loaded": len(manifest.rules),
            "validation_errors": len(errors),
        },
    )


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def _to_agent_finding(finding: SopFinding) -> AgentFinding:
    """Normalise a SopFinding into the AgentResponse envelope shape."""
    sev_map = {"blocking": "major", "warning": "minor", "info": "info"}
    return AgentFinding(
        severity=sev_map.get(finding.severity, finding.severity),
        rule=finding.rule_id,
        section=finding.where or finding.section,
        message=finding.message,
        fix_hint=finding.fix_hint or None,
    )
