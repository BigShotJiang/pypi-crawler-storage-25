"""Interactive credential wizard.

Run via ``atlassiancli configure [--profile <name>]``. Prompts for the four
fields a fresh install needs (site URL, email, API token, optional default
project key + Confluence space), verifies the credential against
``GET /rest/api/3/myself``, and persists the result to
``~/.atlassiancli/<profile>.toml``.

Designed to be testable: all I/O routes through injectable callbacks so a
unit test can drive the wizard end-to-end without a TTY or a network.
"""

from __future__ import annotations

import getpass
import sys
from collections.abc import Callable, Iterable, Iterator
from dataclasses import dataclass, field

from ..application.profile_store import (
    DEFAULT_PROFILE_NAME,
    Profile,
    ProfileStore,
)
from ..infrastructure.http_client import (
    HttpAuthError,
    HttpClient,
    HttpError,
)

# ---------------------------------------------------------------------------
# Result + dependency wiring
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ConfigureResult:
    """Outcome of a wizard run, surfaced to the CLI handler."""

    profile_name: str
    saved_path: str
    verified: bool
    account_id: str | None = None
    display_name: str | None = None
    warnings: tuple[str, ...] = field(default_factory=tuple)


@dataclass
class ConfigureDeps:
    """Injectable dependencies — a test passes its own ask / secret /
    out / verify callable; the real CLI uses the defaults."""

    ask: Callable[[str], str]
    """Prompt for a non-secret string. Default: ``input``."""

    secret: Callable[[str], str]
    """Prompt for a secret (no echo). Default: ``getpass.getpass``."""

    out: Callable[[str], None]
    """Emit a line to the user. Default: ``print``."""

    verify: Callable[[str, str, str], VerifyResult]
    """Run the credential check. Default: :func:`_verify_via_jira_myself`."""

    store: ProfileStore
    """Where the profile is persisted."""


@dataclass(frozen=True)
class VerifyResult:
    """What :func:`_verify_via_jira_myself` returns."""

    ok: bool
    account_id: str | None = None
    display_name: str | None = None
    error_message: str | None = None


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def run_wizard(
    *,
    profile_name: str = DEFAULT_PROFILE_NAME,
    no_verify: bool = False,
    deps: ConfigureDeps | None = None,
) -> ConfigureResult:
    """Run the interactive wizard against ``deps`` and persist the profile.

    The wizard is non-destructive: an existing profile is loaded and shown
    as the default for each prompt, so re-running ``configure`` to update
    one field is cheap. Empty input keeps the previous value.
    """
    deps = deps or _default_deps()
    store = deps.store

    existing = store.load(profile_name)
    deps.out(f"Configuring profile: {profile_name}")
    if any([existing.base_url, existing.user_email, existing.api_token]):
        deps.out(f"  (loaded existing profile from {store.path_for(profile_name)})")

    base_url = _ask_with_default(
        deps.ask,
        "Atlassian site URL",
        existing.base_url or "https://acme.atlassian.net",
    )
    user_email = _ask_with_default(deps.ask, "Account email", existing.user_email)
    api_token = _ask_token(deps.secret, existing.api_token)
    project_key = _ask_with_default(
        deps.ask, "Default Jira project key (optional)", existing.project_key
    )
    confluence_space = _ask_with_default(
        deps.ask,
        "Default Confluence space key (optional)",
        existing.confluence_space,
    )

    warnings: list[str] = []
    verified = False
    account_id: str | None = None
    display_name: str | None = None

    if no_verify:
        warnings.append(
            "skipped credential verification (--no-verify); "
            "the profile will be saved without confirming the token works."
        )
    else:
        deps.out("Verifying credential against /rest/api/3/myself ...")
        result = deps.verify(base_url, user_email, api_token)
        if result.ok:
            verified = True
            account_id = result.account_id
            display_name = result.display_name
            deps.out(
                f"  authenticated as {result.display_name or '?'} ({result.account_id or '?'})"
            )
        else:
            msg = (
                f"credential verification failed: {result.error_message or 'unknown'}. "
                "The profile was NOT saved. Run with --no-verify to save anyway."
            )
            raise CredentialVerificationError(msg)

    profile = Profile(
        name=profile_name,
        base_url=base_url,
        user_email=user_email,
        api_token=api_token,
        project_key=project_key,
        confluence_space=confluence_space,
    )
    saved_path = store.save(profile)
    deps.out(f"Saved profile {profile_name!r} to {saved_path}")

    return ConfigureResult(
        profile_name=profile_name,
        saved_path=str(saved_path),
        verified=verified,
        account_id=account_id,
        display_name=display_name,
        warnings=tuple(warnings),
    )


class CredentialVerificationError(RuntimeError):
    """Verification round-trip failed and ``--no-verify`` was not passed."""


# ---------------------------------------------------------------------------
# Default dependency wiring — production use
# ---------------------------------------------------------------------------


def _default_deps() -> ConfigureDeps:
    return ConfigureDeps(
        ask=input,
        secret=getpass.getpass,
        out=lambda line: print(line, file=sys.stderr),
        verify=_verify_via_jira_myself,
        store=ProfileStore(),
    )


def _verify_via_jira_myself(base_url: str, user_email: str, api_token: str) -> VerifyResult:
    """Hit ``GET /rest/api/3/myself`` and translate the response into a
    :class:`VerifyResult`. Returns ``ok=False`` on auth errors, http errors,
    or any unexpected exception — never raises."""
    try:
        client = HttpClient(
            base_url=base_url,
            auth=(user_email, api_token),
            default_headers={"Accept": "application/json"},
            timeout_seconds=15.0,
        )
        response = client.get("/rest/api/3/myself")
    except HttpAuthError as exc:
        return VerifyResult(ok=False, error_message=f"auth failed (HTTP {exc.status})")
    except HttpError as exc:
        return VerifyResult(ok=False, error_message=str(exc))
    except Exception as exc:  # pragma: no cover — safety net
        return VerifyResult(ok=False, error_message=f"verification error: {exc}")

    if response.status != 200:
        return VerifyResult(ok=False, error_message=f"unexpected HTTP {response.status}")

    payload = response.json() or {}
    return VerifyResult(
        ok=True,
        account_id=str(payload.get("accountId", "")) or None,
        display_name=str(payload.get("displayName", "")) or None,
    )


# ---------------------------------------------------------------------------
# Prompt helpers
# ---------------------------------------------------------------------------


def _ask_with_default(ask: Callable[[str], str], label: str, default: str) -> str:
    """Prompt for a value, returning the default if the user just hits enter."""
    suffix = f" [{default}]" if default else ""
    raw = ask(f"  {label}{suffix}: ").strip()
    if not raw:
        return default
    return raw


def _ask_token(secret: Callable[[str], str], existing: str) -> str:
    """Prompt for the API token, accepting blank to keep the existing value."""
    label = "  API token (input hidden; press enter to keep existing)"
    if not existing:
        label = "  API token (input hidden)"
    raw = secret(f"{label}: ").strip()
    return raw or existing


# ---------------------------------------------------------------------------
# Test-only helper: build a deps object backed by a fixed input list
# ---------------------------------------------------------------------------


def deps_from_inputs(
    inputs: Iterable[str],
    *,
    secret_inputs: Iterable[str] | None = None,
    verify: Callable[[str, str, str], VerifyResult] | None = None,
    store: ProfileStore | None = None,
    out_capture: list[str] | None = None,
) -> ConfigureDeps:
    """Build a :class:`ConfigureDeps` driven by pre-baked inputs.

    Used by the unit tests to drive the wizard without a real TTY or
    network. ``secret_inputs`` defaults to ``inputs`` so a single iterator
    can supply both prompt types when the test doesn't care.
    """
    iterator: Iterator[str] = iter(inputs)
    secret_iter: Iterator[str] = iter(secret_inputs) if secret_inputs else iterator

    out_lines = out_capture if out_capture is not None else []

    def _verify_default(_url: str, _email: str, _token: str) -> VerifyResult:
        return VerifyResult(ok=True, account_id="acc-1", display_name="Test User")

    return ConfigureDeps(
        ask=lambda _label: next(iterator),
        secret=lambda _label: next(secret_iter),
        out=out_lines.append,
        verify=verify or _verify_default,
        store=store or ProfileStore(),
    )
