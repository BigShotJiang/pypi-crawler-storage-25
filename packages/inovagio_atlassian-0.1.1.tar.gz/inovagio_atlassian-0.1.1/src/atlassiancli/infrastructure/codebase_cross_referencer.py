#!/usr/bin/env python3
"""
Codebase Cross-Referencer Implementation

Scans the Inovagio codebase to validate proposed Jira issues against:
1. Existing interfaces (I*.hpp)
2. Existing implementations
3. context_map.md for bounded context validation
4. domain_glossary.md for ubiquitous language validation

This ensures proposed work items are genuinely new and architecturally sound.

Follows DDD/DRY/SOLID:
- Single Responsibility: Only codebase scanning and validation
- Dependency Injection: No hard-coded paths, workspace_root injected
- Interface Segregation: Implements ICodebaseCrossReferencer

Author: Inovagio Engineering Team
"""

import logging
import re
from pathlib import Path

from ..domain.services import (
    CodebaseValidationResult,
    ContextMapEntry,
    DocumentAnalysisResult,
    ExistingImplementation,
    ExistingInterface,
    GlossaryTerm,
    ICodebaseCrossReferencer,
)

logger = logging.getLogger(__name__)


class CodebaseCrossReferencerService(ICodebaseCrossReferencer):
    """
    Concrete implementation of codebase cross-referencing.

    Scans:
    - core/**/*.hpp for interfaces (class I*) and implementations
    - docs/architecture/context_map.md for bounded context knowledge
    - docs/architecture/domain_glossary.md for ubiquitous language

    Thread-safe: All data is read-only after scan_codebase() completes.
    """

    def __init__(self, workspace_root: str | None = None):
        """
        Initialize cross-referencer.

        Args:
            workspace_root: Optional workspace root (can be set later via scan_codebase)
        """
        self._workspace_root: str | None = workspace_root
        self._interfaces: dict[str, ExistingInterface] = {}
        self._implementations: dict[str, ExistingImplementation] = {}
        self._context_map: dict[str, ContextMapEntry] = {}
        self._glossary: dict[str, GlossaryTerm] = {}
        self._scanned = False

        # Layer definitions from context_map.md
        self._layer_map: dict[str, int] = {
            "core-models": 0,
            "core-utils": 1,
            "core-governance": 2,
            "core-observability": 2,
            "core-persistence": 2,
            "core-connectors": 3,
            "core-ani": 3,
            "core-agents": 3,
            "core-orchestration": 3,
            "core-config": 2,
        }

    def scan_codebase(self, workspace_root: str) -> None:
        """
        Scan the codebase to build knowledge base.

        Reads:
        - core/**/*.hpp for interfaces and classes
        - docs/architecture/context_map.md for bounded contexts
        - docs/architecture/domain_glossary.md for domain terms

        Args:
            workspace_root: Absolute path to workspace root
        """
        self._workspace_root = workspace_root
        logger.info("Scanning codebase at: %s", workspace_root)

        # Clear previous scan
        self._interfaces.clear()
        self._implementations.clear()
        self._context_map.clear()
        self._glossary.clear()

        # Scan in order
        self._scan_cpp_headers(workspace_root)
        self._parse_context_map(workspace_root)
        self._parse_domain_glossary(workspace_root)

        self._scanned = True
        logger.info(
            "Codebase scan complete: %d interfaces, %d implementations, %d contexts, %d glossary terms",
            len(self._interfaces),
            len(self._implementations),
            len(self._context_map),
            len(self._glossary),
        )

    def _scan_cpp_headers(self, workspace_root: str) -> None:
        """Scan core/**/*.hpp for interfaces and implementations."""
        core_path = Path(workspace_root) / "core"
        if not core_path.exists():
            logger.warning("Core directory not found: %s", core_path)
            return

        # Regex patterns for C++ interface/class detection
        interface_pattern = re.compile(
            r"^\s*class\s+(I[A-Z][a-zA-Z0-9_]*)\s*(?::\s*public\s+)?", re.MULTILINE
        )
        class_pattern = re.compile(
            r"^\s*class\s+([A-Z][a-zA-Z0-9_]*)\s*(?:final\s*)?(?::\s*public\s+(I[A-Z][a-zA-Z0-9_]*))?",
            re.MULTILINE,
        )
        method_pattern = re.compile(
            r"^\s*virtual\s+[\w:<>,\s\*&]+\s+(\w+)\s*\([^)]*\)\s*(?:const)?\s*(?:noexcept)?\s*=\s*0\s*;",
            re.MULTILINE,
        )

        # Walk through core directory
        for hpp_file in core_path.rglob("*.hpp"):
            rel_path = str(hpp_file.relative_to(workspace_root))
            bounded_context = self._infer_bounded_context(rel_path)

            try:
                content = hpp_file.read_text(encoding="utf-8", errors="ignore")

                # Find interfaces (classes starting with I)
                for match in interface_pattern.finditer(content):
                    interface_name = match.group(1)
                    line_number = content[: match.start()].count("\n") + 1

                    # Extract methods
                    methods = []
                    # Look for pure virtual methods in the class
                    class_end = content.find("};", match.end())
                    if class_end > 0:
                        class_content = content[match.end() : class_end]
                        for method_match in method_pattern.finditer(class_content):
                            methods.append(method_match.group(1))

                    # Extract documentation (look for comment block before class)
                    doc_start = max(0, match.start() - 500)
                    preceding = content[doc_start : match.start()]
                    doc_match = re.search(r"/\*\*([^*]|\*(?!/))*\*/", preceding, re.DOTALL)
                    documentation = doc_match.group(0) if doc_match else ""

                    self._interfaces[interface_name] = ExistingInterface(
                        name=interface_name,
                        file_path=rel_path,
                        line_number=line_number,
                        bounded_context=bounded_context,
                        methods=methods,
                        documentation=documentation[:500],  # Truncate long docs
                    )

                # Find implementations (non-I classes that implement interfaces)
                for match in class_pattern.finditer(content):
                    class_name = match.group(1)
                    implements = match.group(2)

                    # Skip interfaces themselves
                    if class_name.startswith("I") and class_name[1:2].isupper():
                        continue

                    line_number = content[: match.start()].count("\n") + 1
                    impl_list = [implements] if implements else []

                    self._implementations[class_name] = ExistingImplementation(
                        name=class_name,
                        file_path=rel_path,
                        line_number=line_number,
                        bounded_context=bounded_context,
                        implements=impl_list,
                    )

            except (OSError, re.error) as e:
                logger.warning("Error scanning %s: %s", hpp_file, e)

    def _infer_bounded_context(self, file_path: str) -> str:
        """Infer bounded context from file path."""
        path_lower = file_path.lower()

        # Map directory patterns to contexts
        context_patterns = {
            "core-models": ["core/core-models", "core-models"],
            "core-utils": ["core/core-utils", "core-utils"],
            "core-governance": ["core/core-governance", "core-governance"],
            "core-persistence": ["core/core-persistence", "core-persistence"],
            "core-connectors": ["core/core-connectors", "core-connectors"],
            "core-ani": ["core/core-ani", "core-ani"],
            "core-agents": ["core/core-agents", "core-agents"],
            "core-orchestration": ["core/core-orchestration", "core-orchestration"],
            "core-observability": ["core/core-observability", "core-observability"],
            "core-config": ["core/core-config", "core-config"],
        }

        for context, patterns in context_patterns.items():
            if any(p in path_lower for p in patterns):
                return context

        return "unknown"

    def _parse_context_map(self, workspace_root: str) -> None:
        """Parse docs/architecture/context_map.md for bounded context knowledge."""
        context_map_path = Path(workspace_root) / "docs" / "architecture" / "context_map.md"
        if not context_map_path.exists():
            logger.warning("Context map not found: %s", context_map_path)
            return

        try:
            content = context_map_path.read_text(encoding="utf-8")

            # Parse Core Bounded Contexts section
            core_section = re.search(
                r"## Core Bounded Contexts.*?(?=## Product|$)", content, re.DOTALL
            )
            if core_section:
                self._parse_context_section(core_section.group(0), is_core=True)

            # Parse Product Bounded Contexts section
            product_section = re.search(
                r"## Product Bounded Contexts.*?(?=## Context Relationships|$)", content, re.DOTALL
            )
            if product_section:
                self._parse_context_section(product_section.group(0), is_core=False)

            # Parse dependency layers
            layer_section = re.search(r"## Dependency Flow.*?```(.*?)```", content, re.DOTALL)
            if layer_section:
                self._parse_layer_dependencies(layer_section.group(1))

        except (OSError, re.error) as e:
            logger.warning("Error parsing context map: %s", e)

    def _parse_context_section(self, section: str, is_core: bool) -> None:
        """Parse a bounded contexts section."""
        # Pattern: **Context-Name** — Description
        pattern = re.compile(r"\*\*([^*]+)\*\*\s*[—-]\s*(.+?)(?=\n\d+\.|\n##|$)", re.DOTALL)

        for match in pattern.finditer(section):
            name = match.group(1).strip()
            description = match.group(2).strip()

            # Normalize name to lowercase with hyphens
            normalized = name.lower().replace(" ", "-")

            layer = self._layer_map.get(normalized, 4 if not is_core else 0)

            self._context_map[normalized] = ContextMapEntry(
                name=name,
                layer=layer,
                responsibilities=[description],
                dependencies=[],
                integration_patterns={},
            )

    def _parse_layer_dependencies(self, layer_content: str) -> None:
        """Parse layer dependency diagram."""
        # Extract dependencies like: core-utils [→ core-models]
        dep_pattern = re.compile(r"(\w[\w-]*)\s*\[→\s*([^\]]+)\]")

        for match in dep_pattern.finditer(layer_content):
            context = match.group(1).strip()
            deps = [d.strip() for d in match.group(2).split(",")]

            if context in self._context_map:
                self._context_map[context].dependencies = deps

    def _parse_domain_glossary(self, workspace_root: str) -> None:
        """Parse docs/architecture/domain_glossary.md for ubiquitous language."""
        glossary_path = Path(workspace_root) / "docs" / "architecture" / "domain_glossary.md"
        if not glossary_path.exists():
            logger.warning("Domain glossary not found: %s", glossary_path)
            return

        try:
            content = glossary_path.read_text(encoding="utf-8")
            current_category = ""

            # Pattern: **Term** — Definition
            term_pattern = re.compile(r"\*\*([^*]+)\*\*\s*[—-]\s*(.+?)(?=\n\*\*|\n##|$)", re.DOTALL)

            # Process content section by section
            sections = re.split(r"^##\s+", content, flags=re.MULTILINE)

            for section in sections[1:]:  # Skip content before first ##
                lines = section.split("\n", 1)
                if len(lines) >= 2:
                    current_category = lines[0].strip()
                    section_content = lines[1]

                    for match in term_pattern.finditer(section_content):
                        term = match.group(1).strip()
                        definition = match.group(2).strip()

                        # Handle parenthetical aliases like "SLM (Small Language Model)"
                        aliases = []
                        alias_match = re.search(r"\(([^)]+)\)", term)
                        if alias_match:
                            aliases.append(alias_match.group(1))
                            term = term.replace(f"({alias_match.group(1)})", "").strip()

                        self._glossary[term.lower()] = GlossaryTerm(
                            term=term,
                            definition=definition[:500],  # Truncate
                            category=current_category,
                            aliases=aliases,
                        )

                        # Also index aliases
                        for alias in aliases:
                            self._glossary[alias.lower()] = GlossaryTerm(
                                term=alias,
                                definition=definition[:500],
                                category=current_category,
                                aliases=[term],
                            )

        except (OSError, re.error) as e:
            logger.warning("Error parsing domain glossary: %s", e)

    def get_existing_interfaces(
        self, bounded_context: str | None = None
    ) -> list[ExistingInterface]:
        """Get all interfaces found in codebase."""
        interfaces = list(self._interfaces.values())

        if bounded_context:
            interfaces = [i for i in interfaces if i.bounded_context == bounded_context]

        return sorted(interfaces, key=lambda x: x.name)

    def get_existing_implementations(
        self, interface_name: str | None = None
    ) -> list[ExistingImplementation]:
        """Get all implementations found in codebase."""
        implementations = list(self._implementations.values())

        if interface_name:
            implementations = [i for i in implementations if interface_name in i.implements]

        return sorted(implementations, key=lambda x: x.name)

    def interface_exists(self, name: str) -> bool:
        """Check if an interface already exists in codebase."""
        # Normalize name
        check_name = name if name.startswith("I") else f"I{name}"
        return check_name in self._interfaces

    def get_context_map(self) -> dict[str, ContextMapEntry]:
        """Get parsed context map."""
        return self._context_map.copy()

    def get_glossary_terms(self) -> dict[str, GlossaryTerm]:
        """Get parsed glossary."""
        return self._glossary.copy()

    def validate_proposed_work(
        self,
        proposed_interfaces: list[str],
        proposed_implementations: list[str],
        terms_used: list[str],
    ) -> CodebaseValidationResult:
        """
        Validate proposed work items against codebase.

        Args:
            proposed_interfaces: Interface names to create
            proposed_implementations: Implementation names to create
            terms_used: Domain terms used in descriptions

        Returns:
            CodebaseValidationResult with validation details
        """
        result = CodebaseValidationResult(
            existing_interfaces=list(self._interfaces.values()),
            existing_implementations=list(self._implementations.values()),
            proposed_interfaces=proposed_interfaces,
            proposed_implementations=proposed_implementations,
        )

        # Check interfaces
        for iface in proposed_interfaces:
            normalized = iface if iface.startswith("I") else f"I{iface}"
            if normalized in self._interfaces:
                existing = self._interfaces[normalized]

                # Check if implementation exists
                has_impl = any(
                    normalized in impl.implements for impl in self._implementations.values()
                )

                if has_impl:
                    result.already_exists.append(
                        f"{iface} (exists at {existing.file_path}:{existing.line_number})"
                    )
                else:
                    result.partially_exists.append(
                        f"{iface} (interface only, needs implementation)"
                    )
            else:
                result.valid_new_work.append(iface)

        # Check implementations
        for impl in proposed_implementations:
            if impl in self._implementations:
                existing_impl = self._implementations[impl]
                result.already_exists.append(
                    f"{impl} (exists at {existing_impl.file_path}:{existing_impl.line_number})"
                )
            else:
                result.valid_new_work.append(impl)

        # Validate domain terms
        for term in terms_used:
            term_lower = term.lower()
            if term_lower not in self._glossary:
                result.unknown_terms.append(term)

                # Try to suggest similar terms
                suggestion = self._find_similar_term(term_lower)
                if suggestion:
                    result.suggested_terms[term] = suggestion

        return result

    def validate_architecture(self, analysis: "DocumentAnalysisResult") -> CodebaseValidationResult:
        """
        Validate architecture from document analysis against codebase.
        """
        proposed_interfaces = []
        proposed_implementations = []
        terms_used = []

        # Extract from epics
        for epic in analysis.epics:
            if epic.title.startswith("I") and epic.title[1].isupper():
                proposed_interfaces.append(epic.title)

            # Extract terms from description
            if epic.description:
                terms_used.extend(re.findall(r"\b[A-Z][a-z]+\b", epic.description))

            # Extract from children
            for story in epic.children:
                if story.title.startswith("I") and story.title[1].isupper():
                    proposed_interfaces.append(story.title)
                else:
                    proposed_implementations.append(story.title)

                if story.description:
                    terms_used.extend(re.findall(r"\b[A-Z][a-z]+\b", story.description))

        # Extract from orphan stories
        for story in analysis.orphan_stories:
            if story.title.startswith("I") and story.title[1].isupper():
                proposed_interfaces.append(story.title)
            else:
                proposed_implementations.append(story.title)

            if story.description:
                terms_used.extend(re.findall(r"\b[A-Z][a-z]+\b", story.description))

        return self.validate_proposed_work(
            proposed_interfaces=list(set(proposed_interfaces)),
            proposed_implementations=list(set(proposed_implementations)),
            terms_used=list(set(terms_used)),
        )

    def _find_similar_term(self, term: str) -> str | None:
        """Find a similar term in the glossary using Jaccard similarity."""
        term_words = set(term.lower().split())
        best_match = None
        best_score = 0.3  # Minimum threshold

        for glossary_term in self._glossary:
            glossary_words = set(glossary_term.split())
            intersection = term_words & glossary_words
            union = term_words | glossary_words

            if union:
                score = len(intersection) / len(union)
                if score > best_score:
                    best_score = score
                    best_match = self._glossary[glossary_term].term

        return best_match

    def suggest_bounded_context(self, title: str, description: str) -> str:
        """
        Suggest appropriate bounded context based on content.

        Uses context_map.md knowledge and keyword matching.
        """
        combined = f"{title} {description}".lower()

        # Score each context based on keyword matches
        scores: dict[str, int] = {}

        # Keywords per context (from context_map knowledge)
        context_keywords = {
            "core-models": ["value object", "entity", "id", "aggregate", "domain primitive"],
            "core-utils": [
                "utility",
                "logging",
                "thread pool",
                "serialization",
                "event bus",
                "config",
            ],
            "core-governance": ["rbac", "permission", "audit", "compliance", "policy", "security"],
            "core-persistence": [
                "repository",
                "database",
                "storage",
                "migration",
                "event sourcing",
            ],
            "core-connectors": ["connector", "integration", "api", "external", "adapter"],
            "core-ani": [
                "ani",
                "agent network",
                "multi-agent",
                "message",
                "protocol",
                "communication",
            ],
            "core-agents": ["agent", "llm", "tool", "executor", "lifecycle"],
            "core-orchestration": ["workflow", "task", "scheduler", "dag", "execution"],
            "core-observability": ["metric", "trace", "logging", "monitoring", "telemetry"],
        }

        for context, keywords in context_keywords.items():
            score = sum(1 for kw in keywords if kw in combined)
            if score > 0:
                scores[context] = score

        if scores:
            return max(scores, key=lambda k: scores[k])

        return "core-models"  # Default fallback

    def validate_layer_dependencies(self, from_context: str, to_context: str) -> bool:
        """
        Validate that a dependency between contexts is allowed.

        Rules: Layer N can depend on Layer N-1 only (no upward dependencies).
        """
        from_layer = self._layer_map.get(from_context, 4)
        to_layer = self._layer_map.get(to_context, 0)

        # Dependencies can only flow downward or same layer
        return from_layer >= to_layer

    # ========================================================================
    # CONVENIENCE METHODS FOR ARCHITECTURE ANALYZER
    # ========================================================================

    def get_interfaces_for_context(self, context: str) -> list[str]:
        """Get list of interface names for a bounded context."""
        return [
            iface.name for iface in self._interfaces.values() if iface.bounded_context == context
        ]

    def get_unimplemented_interfaces(self) -> list[ExistingInterface]:
        """Get interfaces that have no implementation."""
        implemented = set()
        for impl in self._implementations.values():
            implemented.update(impl.implements)

        return [iface for iface in self._interfaces.values() if iface.name not in implemented]

    def search_interfaces(self, pattern: str) -> list[ExistingInterface]:
        """Search interfaces by name pattern."""
        regex = re.compile(pattern, re.IGNORECASE)
        return [iface for iface in self._interfaces.values() if regex.search(iface.name)]

    def is_term_in_glossary(self, term: str) -> bool:
        """Check if a term is in the domain glossary."""
        return term.lower() in self._glossary

    def get_term_definition(self, term: str) -> str | None:
        """Get definition for a glossary term."""
        entry = self._glossary.get(term.lower())
        return entry.definition if entry else None

    @property
    def is_scanned(self) -> bool:
        """Check if codebase has been scanned."""
        return self._scanned

    def get_scan_summary(self) -> str:
        """Get summary of codebase scan results."""
        if not self._scanned:
            return "Codebase not yet scanned"

        return (
            f"📊 Codebase Scan Summary:\n"
            f"   • {len(self._interfaces)} interfaces found\n"
            f"   • {len(self._implementations)} implementations found\n"
            f"   • {len(self._context_map)} bounded contexts mapped\n"
            f"   • {len(self._glossary)} glossary terms indexed\n"
            f"   • {len(self.get_unimplemented_interfaces())} interfaces need implementation"
        )
