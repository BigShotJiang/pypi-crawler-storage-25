#!/usr/bin/env python3
"""
Backlog Analyzer Infrastructure Implementation

Implements IBacklogAnalyzer for comprehensive Jira backlog scanning.
Provides visibility into all backlog items, sprint allocation, and conflicts.

Author: Inovagio Engineering Team
"""

import re

from ..domain.repositories import IIssueRepository
from ..domain.services import BacklogAnalysisResult, BacklogEpic, BacklogStory, IBacklogAnalyzer
from ..infrastructure.config import AtlassianConfig

# Keywords mapping to bounded contexts
CONTEXT_KEYWORDS: dict[str, list[str]] = {
    "Core-Models": ["model", "value object", "entity", "aggregate", "domain primitive", "types"],
    "Core-Utils": ["utility", "logging", "serialization", "thread pool", "event bus", "regex"],
    "Core-Governance": ["rbac", "audit", "compliance", "policy", "permission", "authorization"],
    "Core-Persistence": [
        "storage",
        "database",
        "repository",
        "postgresql",
        "sqlite",
        "persistence",
    ],
    "Core-Connectors": ["connector", "integration", "external", "api", "adapter", "bridge"],
    "Core-ANI": ["ani", "agent network", "multi-agent", "networking", "protocol"],
    "Core-Agents": ["agent", "llm", "lifecycle", "virtual employee", "ai agent"],
    "Core-Orchestration": ["workflow", "orchestration", "executor", "scheduler", "pipeline"],
    "Origin": ["setup", "onboarding", "configuration", "initialization"],
    "Flow": ["workflow builder", "automation", "task flow"],
    "Edge": ["deployment", "edge computing", "local agent"],
    "Insights": ["analytics", "dashboard", "reporting", "metrics"],
    "Studio": ["design", "builder", "visual editor"],
    "Marketplace": ["marketplace", "plugin", "extension", "app store"],
    "Shops": ["shop", "template", "recipe"],
    "Guard": ["safety", "guardrail", "content filter", "moderation"],
    "Sentinel": ["monitoring", "alerting", "observability", "health check"],
}

# Labels that indicate bounded context
CONTEXT_LABELS: dict[str, str] = {
    "core-models": "Core-Models",
    "core-utils": "Core-Utils",
    "core-governance": "Core-Governance",
    "core-persistence": "Core-Persistence",
    "core-connectors": "Core-Connectors",
    "core-ani": "Core-ANI",
    "core-agents": "Core-Agents",
    "core-orchestration": "Core-Orchestration",
    "origin": "Origin",
    "flow": "Flow",
    "edge": "Edge",
    "insights": "Insights",
    "studio": "Studio",
    "marketplace": "Marketplace",
    "shops": "Shops",
    "guard": "Guard",
    "sentinel": "Sentinel",
}


class JiraBacklogAnalyzer(IBacklogAnalyzer):
    """
    Concrete implementation of IBacklogAnalyzer.

    Performs comprehensive Jira backlog analysis using JQL queries.
    Uses direct API calls to access sprint data (customfield_10020).
    Follows Dependency Injection - receives dependencies through constructor.
    """

    # Sprint custom field ID (standard Jira Cloud field for sprint)
    SPRINT_FIELD = "customfield_10020"

    def __init__(self, issue_repo: IIssueRepository, config: AtlassianConfig, api_client=None):
        """
        Initialize analyzer with dependencies.

        Args:
            issue_repo: Repository for Jira operations (DI)
            config: Configuration for project key
            api_client: Optional JiraApiClient for direct API calls (for sprint data)
        """
        self._issues = issue_repo
        self._config = config
        self._api_client = api_client
        self._cached_analysis: BacklogAnalysisResult | None = None

    def analyze_backlog(
        self, project_key: str, bounded_contexts: list[str] | None = None
    ) -> BacklogAnalysisResult:
        """
        Perform comprehensive backlog analysis.

        Scans all epics, stories, and tasks to build a complete picture.
        """
        result = BacklogAnalysisResult()

        # Fetch all epics
        epics = self._fetch_all_epics(project_key)
        for epic in epics:
            ctx = epic.bounded_context
            result.covered_contexts.add(ctx)
            if ctx not in result.epics_by_context:
                result.epics_by_context[ctx] = []
            result.epics_by_context[ctx].append(epic)

        # Fetch all stories/tasks
        stories = self._fetch_all_stories(project_key)
        for story in stories:
            ctx = story.bounded_context
            result.covered_contexts.add(ctx)
            if ctx not in result.stories_by_context:
                result.stories_by_context[ctx] = []
            result.stories_by_context[ctx].append(story)

            # Track sprint allocation using sprint state
            if story.sprint:
                sprint_state = getattr(story, "_sprint_state", None)
                if sprint_state == "active":
                    result.current_sprint_items.append(story)
                elif sprint_state == "future":
                    result.next_sprint_items.append(story)
                # Closed sprints are ignored for allocation tracking

            # Track in-progress work
            if story.is_in_progress:
                if ctx not in result.in_progress_by_context:
                    result.in_progress_by_context[ctx] = []
                result.in_progress_by_context[ctx].append(story)

            # Track blocked items
            if story.is_blocked:
                result.blocked_items.append(story)

        # Filter by bounded contexts if specified
        if bounded_contexts:
            result.epics_by_context = {
                k: v for k, v in result.epics_by_context.items() if k in bounded_contexts
            }
            result.stories_by_context = {
                k: v for k, v in result.stories_by_context.items() if k in bounded_contexts
            }
            result.covered_contexts = {c for c in result.covered_contexts if c in bounded_contexts}

        self._cached_analysis = result
        return result

    def find_related_epics(self, bounded_context: str, themes: list[str]) -> list[BacklogEpic]:
        """
        Find epics related to a bounded context and themes.
        """
        # Ensure we have analysis data
        if not self._cached_analysis:
            self.analyze_backlog(self._config.project_key)

        if not self._cached_analysis:
            return []

        related = []

        # Get epics in the bounded context
        context_epics = self._cached_analysis.epics_by_context.get(bounded_context, [])

        # Score epics by theme match
        for epic in context_epics:
            score = self._calculate_theme_match(epic.summary, themes)
            if score > 0:
                related.append(epic)

        # Also check other contexts for cross-cutting concerns
        for ctx, epics in self._cached_analysis.epics_by_context.items():
            if ctx == bounded_context:
                continue
            for epic in epics:
                score = self._calculate_theme_match(epic.summary, themes)
                if score >= 2:  # Higher threshold for cross-context
                    if epic not in related:
                        related.append(epic)

        # Sort by progress (prefer linking to in-progress epics)
        related.sort(key=lambda e: (e.is_in_progress, e.progress_percent), reverse=True)

        return related

    def find_in_progress_work(self, bounded_context: str) -> list[BacklogStory]:
        """
        Find all in-progress work for a bounded context.
        """
        if not self._cached_analysis:
            self.analyze_backlog(self._config.project_key)

        if not self._cached_analysis:
            return []

        return self._cached_analysis.in_progress_by_context.get(bounded_context, [])

    def check_sprint_allocation(self, bounded_context: str) -> dict[str, list[BacklogStory]]:
        """
        Check sprint allocation for a bounded context.
        """
        if not self._cached_analysis:
            self.analyze_backlog(self._config.project_key)

        if not self._cached_analysis:
            return {"current": [], "next": []}

        current = [
            s
            for s in self._cached_analysis.current_sprint_items
            if s.bounded_context == bounded_context
        ]
        next_sprint = [
            s
            for s in self._cached_analysis.next_sprint_items
            if s.bounded_context == bounded_context
        ]

        return {
            "current": current,
            "next": next_sprint,
        }

    def identify_conflicts(
        self, proposed_title: str, proposed_context: str, proposed_themes: list[str]
    ) -> list[str]:
        """
        Identify potential conflicts with proposed work.
        """
        conflicts = []

        if not self._cached_analysis:
            self.analyze_backlog(self._config.project_key)

        # Check for similar in-progress work
        in_progress = self.find_in_progress_work(proposed_context)
        for story in in_progress:
            similarity = self._calculate_title_similarity(proposed_title, story.summary)
            if similarity > 0.4:
                conflicts.append(
                    f"⚠️ Similar work IN PROGRESS: {story.key} - {story.summary} "
                    f"(assigned to: {story.assignee or 'unassigned'})"
                )

        # Check for overlapping epics
        related_epics = self.find_related_epics(proposed_context, proposed_themes)
        for epic in related_epics[:3]:  # Top 3 most related
            if epic.is_in_progress:
                conflicts.append(
                    f"ℹ️ Related epic IN PROGRESS: {epic.key} - {epic.summary} "
                    f"({epic.progress_percent}% complete)"
                )

        # Check sprint capacity
        sprint_items = self.check_sprint_allocation(proposed_context)
        current_count = len(sprint_items.get("current", []))
        if current_count >= 5:
            conflicts.append(
                f"📊 Sprint capacity: {current_count} items already in current sprint "
                f"for {proposed_context}"
            )

        return conflicts

    def suggest_epic_link(self, bounded_context: str, themes: list[str]) -> str | None:
        """
        Suggest an existing epic to link new work to.
        """
        related_epics = self.find_related_epics(bounded_context, themes)

        if not related_epics:
            return None

        # Prefer:
        # 1. In-progress epics (active work)
        # 2. Epics with low completion (room for more stories)
        # 3. Recently updated epics
        for epic in related_epics:
            if epic.is_in_progress and epic.progress_percent < 80:
                return epic.key

        # Return first related epic if none are in-progress
        return related_epics[0].key if related_epics else None

    def get_coverage_gaps(self, expected_contexts: list[str]) -> list[str]:
        """
        Identify bounded contexts with no backlog coverage.
        """
        if not self._cached_analysis:
            self.analyze_backlog(self._config.project_key)

        if not self._cached_analysis:
            return expected_contexts

        covered = self._cached_analysis.covered_contexts
        gaps = [ctx for ctx in expected_contexts if ctx not in covered]

        return gaps

    # =========================================================================
    # Private Helper Methods
    # =========================================================================

    def _fetch_all_epics(self, project_key: str) -> list[BacklogEpic]:
        """Fetch all epics from Jira"""
        jql = f"project = {project_key} AND type = Epic AND status != Done ORDER BY created DESC"

        try:
            issues = self._issues.search(jql, max_results=200)
        except Exception:
            return []

        epics = []
        for issue in issues:
            # Extract fields safely
            key = str(issue.key) if issue.key else "UNKNOWN"
            summary = issue.title if hasattr(issue, "title") else str(issue)
            status = self._get_status(issue)
            labels = self._get_labels(issue)
            assignee = self._get_assignee(issue)

            # Determine bounded context
            bounded_context = self._infer_bounded_context(summary, labels)

            epics.append(
                BacklogEpic(
                    key=key,
                    summary=summary,
                    status=status,
                    bounded_context=bounded_context,
                    labels=labels,
                    assignee=assignee,
                )
            )

        return epics

    def _fetch_all_stories(self, project_key: str) -> list[BacklogStory]:
        """Fetch all stories, tasks, sub-tasks, and epics from Jira with sprint data"""
        # Include ALL issue types that can be in a sprint
        jql = (
            f"project = {project_key} "
            f"AND type IN (Story, Task, Sub-task, Epic, Bug) "
            f"AND status != Done "
            f"ORDER BY priority DESC, created DESC"
        )

        # Use direct API call if available (for sprint data)
        if self._api_client:
            return self._fetch_stories_via_api(jql)

        # Fallback to repository (no sprint data)
        try:
            issues = self._issues.search(jql, max_results=1000)
        except Exception:
            return []

        stories = []
        for issue in issues:
            # Extract fields safely
            key = str(issue.key) if issue.key else "UNKNOWN"
            summary = issue.title if hasattr(issue, "title") else str(issue)
            status = self._get_status(issue)
            issue_type = self._get_issue_type(issue)
            epic_key = self._get_epic_link(issue)
            sprint = self._get_sprint(issue)
            labels = self._get_labels(issue)
            assignee = self._get_assignee(issue)
            priority = self._get_priority(issue)

            # Determine bounded context
            bounded_context = self._infer_bounded_context(summary, labels)

            stories.append(
                BacklogStory(
                    key=key,
                    summary=summary,
                    status=status,
                    issue_type=issue_type,
                    epic_key=epic_key,
                    bounded_context=bounded_context,
                    sprint=sprint,
                    labels=labels,
                    assignee=assignee,
                    priority=priority,
                )
            )

        return stories

    def _fetch_stories_via_api(self, jql: str) -> list[BacklogStory]:
        """Fetch stories via direct API call to get sprint data with pagination"""
        all_stories = []
        next_page_token = None

        while True:
            payload = {
                "jql": jql,
                "maxResults": 100,
                "fields": [
                    "summary",
                    "status",
                    "issuetype",
                    "parent",
                    "labels",
                    "assignee",
                    "priority",
                    self.SPRINT_FIELD,
                ],
            }
            if next_page_token:
                payload["nextPageToken"] = next_page_token

            try:
                response = self._api_client.post("/rest/api/3/search/jql", payload)
                if response.status_code != 200:
                    break
                data = response.json()
            except Exception:
                break

            for issue_data in data.get("issues", []):
                key = issue_data.get("key", "UNKNOWN")
                fields = issue_data.get("fields", {})

                summary = fields.get("summary", "")
                status = fields.get("status", {}).get("name", "Unknown")
                issue_type = fields.get("issuetype", {}).get("name", "Unknown")

                # Epic link (parent)
                parent = fields.get("parent")
                epic_key = parent.get("key") if parent else None

                # Sprint data from custom field
                sprint_data = fields.get(self.SPRINT_FIELD, [])
                sprint = None
                sprint_state = None
                if sprint_data and len(sprint_data) > 0:
                    # Get the most recent sprint (last in list)
                    active_sprint = None
                    for s in sprint_data:
                        if s.get("state") == "active":
                            active_sprint = s
                            break
                    if active_sprint:
                        sprint = active_sprint.get("name")
                        sprint_state = "active"
                    elif sprint_data:
                        sprint = sprint_data[-1].get("name")
                        sprint_state = sprint_data[-1].get("state")

                # Labels
                labels = fields.get("labels", [])

                # Assignee
                assignee_data = fields.get("assignee")
                assignee = assignee_data.get("displayName", "") if assignee_data else ""

                # Priority
                priority_data = fields.get("priority")
                priority = priority_data.get("name", "Medium") if priority_data else "Medium"

                # Determine bounded context
                bounded_context = self._infer_bounded_context(summary, labels)

                story = BacklogStory(
                    key=key,
                    summary=summary,
                    status=status,
                    issue_type=issue_type,
                    epic_key=epic_key,
                    bounded_context=bounded_context,
                    sprint=sprint,
                    labels=labels,
                    assignee=assignee,
                    priority=priority,
                )
                # Store sprint state for filtering
                story._sprint_state = sprint_state
                all_stories.append(story)

            # Check for more pages
            is_last = data.get("isLast", True)
            next_page_token = data.get("nextPageToken")
            if is_last or not next_page_token:
                break

        return all_stories

    def _infer_bounded_context(self, summary: str, labels: list[str]) -> str:
        """Infer bounded context from summary and labels"""
        # First check labels
        for label in labels:
            label_lower = label.lower()
            if label_lower in CONTEXT_LABELS:
                return CONTEXT_LABELS[label_lower]

        # Then check summary for keywords
        summary_lower = summary.lower()
        best_match = ("Unknown", 0)

        for context, keywords in CONTEXT_KEYWORDS.items():
            matches = sum(1 for kw in keywords if kw in summary_lower)
            if matches > best_match[1]:
                best_match = (context, matches)

        return best_match[0]

    def _calculate_theme_match(self, text: str, themes: list[str]) -> int:
        """Calculate how many themes match in text"""
        text_lower = text.lower()
        return sum(1 for theme in themes if theme.lower() in text_lower)

    def _calculate_title_similarity(self, title1: str, title2: str) -> float:
        """Calculate simple word overlap similarity"""
        words1 = set(re.findall(r"\w+", title1.lower()))
        words2 = set(re.findall(r"\w+", title2.lower()))

        if not words1 or not words2:
            return 0.0

        intersection = len(words1 & words2)
        union = len(words1 | words2)

        return intersection / union if union > 0 else 0.0

    def _is_current_sprint(self, sprint_name: str) -> bool:
        """Check if sprint appears to be the current sprint"""
        sprint_lower = sprint_name.lower()
        return (
            "active" in sprint_lower
            or "current" in sprint_lower
            or "sprint" in sprint_lower  # Basic heuristic
        )

    def _get_status(self, issue) -> str:
        """Safely extract status from issue"""
        if hasattr(issue, "_status"):
            return issue._status
        if hasattr(issue, "status"):
            return str(issue.status)
        return "Unknown"

    def _get_labels(self, issue) -> list[str]:
        """Safely extract labels from issue"""
        if hasattr(issue, "labels"):
            labels = issue.labels
            if isinstance(labels, list):
                return labels
        return []

    def _get_assignee(self, issue) -> str:
        """Safely extract assignee from issue"""
        if hasattr(issue, "assignee"):
            assignee = issue.assignee
            if assignee:
                if hasattr(assignee, "displayName"):
                    return assignee.displayName
                return str(assignee)
        return ""

    def _get_issue_type(self, issue) -> str:
        """Safely extract issue type from issue"""
        if hasattr(issue, "issue_type"):
            return issue.issue_type
        if hasattr(issue, "fields") and hasattr(issue.fields, "issuetype"):
            return str(issue.fields.issuetype.name)
        return "Unknown"

    def _get_epic_link(self, issue) -> str | None:
        """Safely extract epic link from issue"""
        if hasattr(issue, "epic_key"):
            return issue.epic_key
        if hasattr(issue, "fields"):
            # Jira Cloud uses parent field for epic
            if hasattr(issue.fields, "parent"):
                parent = issue.fields.parent
                if parent:
                    return str(parent.key)
        return None

    def _get_sprint(self, issue) -> str | None:
        """Safely extract sprint from issue"""
        if hasattr(issue, "sprint"):
            sprint = issue.sprint
            if sprint:
                if hasattr(sprint, "name"):
                    return sprint.name
                return str(sprint)
        return None

    def _get_priority(self, issue) -> str:
        """Safely extract priority from issue"""
        if hasattr(issue, "priority"):
            priority = issue.priority
            if priority:
                if hasattr(priority, "name"):
                    return priority.name
                return str(priority)
        return "Medium"
