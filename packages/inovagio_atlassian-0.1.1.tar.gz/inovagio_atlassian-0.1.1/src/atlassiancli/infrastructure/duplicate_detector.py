#!/usr/bin/env python3
"""
Duplicate Detector Infrastructure Implementation

Implements IDuplicateDetector using IIssueRepository for JQL search.
Uses Jaccard word similarity for matching similar issues.

Ported from V2 (scripts/atlassian/importers.py) following DDD/SOLID principles.

Author: Inovagio Engineering Team
"""

import re

from ..domain.repositories import IIssueRepository
from ..domain.services import IDuplicateDetector, SimilarityMatch
from ..infrastructure.config import AtlassianConfig

# Stop words to filter from similarity calculations
# These common words don't contribute to semantic similarity
STOP_WORDS: frozenset[str] = frozenset(
    {
        "the",
        "a",
        "an",
        "and",
        "or",
        "for",
        "to",
        "in",
        "of",
        "with",
        "on",
        "implement",
        "add",
        "create",
        "update",
        "fix",
        "remove",
        "delete",
        "new",
        "as",
        "is",
        "are",
        "be",
        "been",
        "being",
        "have",
        "has",
        "had",
        "do",
        "does",
        "did",
        "will",
        "would",
        "could",
        "should",
        "may",
        "might",
        "must",
        "shall",
        "can",
        "need",
        "this",
        "that",
        "these",
        "those",
        "support",
        "enable",
        "ensure",
        "provide",
        "allow",
        "make",
        "use",
    }
)

# Minimum word length for similarity calculation
MIN_WORD_LENGTH = 3


class JiraDuplicateDetector(IDuplicateDetector):
    """
    Concrete implementation of IDuplicateDetector.

    Uses IIssueRepository for JQL search and Jaccard similarity for matching.
    Follows Dependency Injection - receives repository through constructor.
    """

    def __init__(self, issue_repo: IIssueRepository, config: AtlassianConfig):
        """
        Initialize detector with dependencies.

        Args:
            issue_repo: Repository for Jira operations (DI)
            config: Configuration for project key
        """
        self._issues = issue_repo
        self._config = config

    def find_similar_issues(
        self, title: str, issue_type: str = "Epic", threshold: float = 0.3
    ) -> list[SimilarityMatch]:
        """
        Find existing Jira issues with similar titles.

        Uses two-phase search:
        1. JQL text search to find candidates
        2. Jaccard similarity scoring to rank results

        Args:
            title: Title to search for similar issues
            issue_type: Issue type to search ("Epic", "Story", "Task")
            threshold: Minimum similarity score (0.0-1.0)

        Returns:
            List of SimilarityMatch objects sorted by similarity (highest first)
        """
        # Extract meaningful words for JQL search
        search_words = self._extract_search_words(title)

        if not search_words:
            return []

        # Build JQL query with text search
        search_terms = " ".join(search_words[:5])  # Limit to first 5 words
        jql = (
            f"project = {self._config.project_key} "
            f'AND type = "{issue_type}" '
            f'AND text ~ "{search_terms}" '
            f"ORDER BY created DESC"
        )

        # Search for candidates
        try:
            candidates = self._issues.search(jql, max_results=20)
        except Exception:
            # Graceful degradation - return empty if search fails
            return []

        # Score candidates by similarity
        matches: list[SimilarityMatch] = []
        for issue in candidates:
            summary = issue.title if hasattr(issue, "title") else str(issue)
            similarity = self.calculate_similarity(title, summary)

            if similarity >= threshold:
                # Extract issue key and status safely
                issue_key = str(issue.key) if issue.key else "UNKNOWN"
                status = "Unknown"

                # Try to get status if available
                if hasattr(issue, "_status"):
                    status = issue._status
                elif hasattr(issue, "status"):
                    status = issue.status

                matches.append(
                    SimilarityMatch(
                        issue_key=issue_key,
                        summary=summary,
                        status=status,
                        similarity=similarity,
                        matched_title=title,
                    )
                )

        # Sort by similarity (highest first)
        matches.sort(key=lambda m: m.similarity, reverse=True)

        return matches

    def calculate_similarity(self, title1: str, title2: str) -> float:
        """
        Calculate Jaccard similarity coefficient between two titles.

        Jaccard similarity = |A ∩ B| / |A ∪ B|
        where A and B are sets of meaningful words.

        Args:
            title1: First title
            title2: Second title

        Returns:
            Similarity score from 0.0 (no overlap) to 1.0 (identical)
        """
        words1 = self._extract_word_set(title1)
        words2 = self._extract_word_set(title2)

        if not words1 or not words2:
            return 0.0

        intersection = len(words1 & words2)
        union = len(words1 | words2)

        return intersection / union if union > 0 else 0.0

    def is_potential_duplicate(self, title: str, issue_type: str = "Epic") -> bool:
        """
        Quick check if title is likely a duplicate.

        Args:
            title: Title to check
            issue_type: Issue type to search

        Returns:
            True if a similar issue exists with >60% similarity
        """
        matches = self.find_similar_issues(title, issue_type, threshold=0.6)
        return len(matches) > 0

    def _extract_search_words(self, text: str) -> list[str]:
        """
        Extract meaningful words for JQL search.

        Filters out stop words and short words.
        Splits CamelCase into separate words.

        Args:
            text: Text to extract words from

        Returns:
            List of meaningful words (lowercase)
        """
        # Split CamelCase first (e.g., "WorkflowEngine" -> "Workflow Engine")
        text_with_spaces = re.sub(r"([a-z])([A-Z])", r"\1 \2", text)
        words = re.findall(r"\w+", text_with_spaces.lower())
        return [w for w in words if w not in STOP_WORDS and len(w) >= MIN_WORD_LENGTH]

    def _extract_word_set(self, text: str) -> set[str]:
        """
        Extract word set for similarity calculation.

        Splits CamelCase into separate words for better matching.

        Args:
            text: Text to extract words from

        Returns:
            Set of meaningful words (lowercase)
        """
        # Split CamelCase first (e.g., "WorkflowEngine" -> "Workflow Engine")
        text_with_spaces = re.sub(r"([a-z])([A-Z])", r"\1 \2", text)
        words = re.findall(r"\w+", text_with_spaces.lower())
        return {w for w in words if len(w) >= MIN_WORD_LENGTH}


class DuplicateAnalysisResult:
    """
    Aggregated result of duplicate analysis across multiple items.

    Used to present analysis results to user before import.
    """

    def __init__(self):
        self.epic_matches: list[SimilarityMatch] = []
        self.story_matches: list[SimilarityMatch] = []
        self.task_matches: list[SimilarityMatch] = []

    @property
    def has_potential_duplicates(self) -> bool:
        """Check if any potential duplicates were found"""
        return any(
            [
                any(m.is_high_match for m in self.epic_matches),
                any(m.is_high_match for m in self.story_matches),
                any(m.is_high_match for m in self.task_matches),
            ]
        )

    @property
    def has_likely_duplicates(self) -> bool:
        """Check if any likely duplicates were found (>80% match)"""
        return any(
            [
                any(m.is_likely_duplicate for m in self.epic_matches),
                any(m.is_likely_duplicate for m in self.story_matches),
                any(m.is_likely_duplicate for m in self.task_matches),
            ]
        )

    @property
    def total_matches(self) -> int:
        """Total number of matches found"""
        return len(self.epic_matches) + len(self.story_matches) + len(self.task_matches)

    @property
    def warnings(self) -> list[str]:
        """Get list of warning messages for matches"""
        warnings = []

        for match in self.epic_matches:
            if match.is_high_match:
                warnings.append(f"Epic '{match.matched_title}' - {match.recommendation}")

        for match in self.story_matches:
            if match.is_high_match:
                warnings.append(f"Story '{match.matched_title}' - {match.recommendation}")

        for match in self.task_matches:
            if match.is_high_match:
                warnings.append(f"Task '{match.matched_title}' - {match.recommendation}")

        return warnings

    def format_report(self) -> str:
        """Format a human-readable report of duplicate analysis"""
        lines = []
        lines.append("=" * 60)
        lines.append("🔍 DUPLICATE DETECTION ANALYSIS")
        lines.append("=" * 60)

        if not self.total_matches:
            lines.append("\n✅ No similar existing issues found")
            return "\n".join(lines)

        # Report by type
        if self.epic_matches:
            lines.append(f"\n📖 Epic Matches ({len(self.epic_matches)}):")
            for match in self.epic_matches:
                marker = "⚠️" if match.is_high_match else "ℹ️"
                lines.append(f"   {marker} [{match.issue_key}] {match.summary}")
                lines.append(f"      Similarity: {match.similarity:.0%} | Status: {match.status}")
                if match.recommendation:
                    lines.append(f"      {match.recommendation}")

        if self.story_matches:
            lines.append(f"\n📝 Story Matches ({len(self.story_matches)}):")
            for match in self.story_matches:
                marker = "⚠️" if match.is_high_match else "ℹ️"
                lines.append(f"   {marker} [{match.issue_key}] {match.summary}")
                lines.append(f"      Similarity: {match.similarity:.0%} | Status: {match.status}")
                if match.recommendation:
                    lines.append(f"      {match.recommendation}")

        if self.task_matches:
            lines.append(f"\n✅ Task Matches ({len(self.task_matches)}):")
            for match in self.task_matches:
                marker = "⚠️" if match.is_high_match else "ℹ️"
                lines.append(f"   {marker} [{match.issue_key}] {match.summary}")
                lines.append(f"      Similarity: {match.similarity:.0%} | Status: {match.status}")
                if match.recommendation:
                    lines.append(f"      {match.recommendation}")

        # Summary
        lines.append("\n" + "-" * 60)
        if self.has_likely_duplicates:
            lines.append("⚠️ WARNING: Likely duplicates detected!")
            lines.append("   Consider linking to existing issues instead of creating new ones.")
        elif self.has_potential_duplicates:
            lines.append("⚡ NOTICE: Potential duplicates detected.")
            lines.append("   Review matched issues before proceeding.")
        else:
            lines.append("ℹ️ Related issues found - may be useful for context.")

        return "\n".join(lines)
