"""Stdlib ``.env`` file loader.

Parses a small subset of dotenv syntax — single-line ``KEY=VALUE`` entries
with optional quoting, comments, and an optional ``${VAR}`` expansion pass —
sufficient for the credential / config scenarios the CLI targets.
"""

from __future__ import annotations

import os
import re
from pathlib import Path

# A reference to ``${VAR}`` (and only that form — no ``$VAR``, no
# ``${VAR:-default}``). Using a strict pattern avoids accidentally rewriting
# legitimate dollar-sign content in values.
_EXPAND_RE = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")


def load_env_file(
    path: Path | str,
    *,
    override_existing: bool = False,
    expand_vars: bool = False,
    strict: bool = False,
) -> dict[str, str]:
    """Parse a ``.env`` file and (optionally) populate :data:`os.environ`.

    Parameters
    ----------
    path:
        File path. If the path does not exist, returns ``{}`` silently — the
        ``.env`` file is conventionally optional.
    override_existing:
        When ``False`` (default), keys already present in :data:`os.environ`
        are preserved. When ``True``, parsed values overwrite them.
    expand_vars:
        When ``True``, ``${VAR}`` references in values are substituted with
        the corresponding :data:`os.environ` value (empty string if absent).
        Substitution happens after parsing the file but before merging into
        :data:`os.environ`, so a later line in the same file can reference
        an earlier line in the same file.
    strict:
        When ``True``, raises :class:`ValueError` on any line that is not a
        ``KEY=VALUE`` assignment (or a ``#`` comment / blank). When ``False``
        (default), such lines are silently skipped — many real ``.env`` files
        in the wild use ``---- section ----`` separators or other free-form
        annotations without a leading ``#``, and crashing on them at module-
        import time is a worse default than letting parseable assignments
        come through.

    Returns
    -------
    dict[str, str]
        The parsed key/value pairs (post-expansion).

    Raises
    ------
    ValueError
        Only when ``strict=True`` and a malformed line is encountered. The
        offending line number is embedded in the message.
    """
    file_path = Path(path)
    if not file_path.is_file():
        return {}

    parsed: dict[str, str] = {}
    with file_path.open("r", encoding="utf-8") as fh:
        for line_no, raw in enumerate(fh, start=1):
            line = raw.rstrip("\n").rstrip("\r")
            stripped = line.strip()
            if stripped == "" or stripped.startswith("#"):
                continue
            # Tolerate `export KEY=VALUE` — strip the `export ` courtesy.
            if stripped.startswith("export "):
                stripped = stripped[len("export ") :].lstrip()
            if "=" not in stripped:
                if strict:
                    raise ValueError(
                        f"Malformed line {line_no} in {file_path}: missing '=' in {stripped!r}"
                    )
                continue
            key, _, value = stripped.partition("=")
            key = key.strip()
            if key == "":
                if strict:
                    raise ValueError(
                        f"Malformed line {line_no} in {file_path}: empty key in {stripped!r}"
                    )
                continue
            value = _parse_value(value)
            parsed[key] = value

    # Expansion pass — uses both already-parsed keys (this file) AND the
    # current ``os.environ``. Already-parsed keys take precedence so the
    # caller's declared values win over anything inherited from the shell.
    if expand_vars:
        expanded: dict[str, str] = {}
        for key, value in parsed.items():
            expanded[key] = _expand(value, parsed | os.environ)
        parsed = expanded

    # Merge into os.environ.
    for key, value in parsed.items():
        if override_existing or key not in os.environ:
            os.environ[key] = value

    return parsed


def _parse_value(raw: str) -> str:
    """Strip trailing comments and apply quoting rules to a raw value token."""
    value = raw.lstrip()
    if value == "":
        return ""
    # Quoted forms: consume up to the matching closing quote, ignore anything
    # after (e.g. trailing comments).
    if value[0] in ("'", '"'):
        quote = value[0]
        # Find the matching quote. We don't honor escaped quotes here — the
        # ``.env`` format we support does not specify escapes.
        end = value.find(quote, 1)
        if end == -1:
            # No closing quote — treat the whole remainder as the value
            # (excluding the opening quote) so callers don't lose data.
            return value[1:]
        return value[1:end]
    # Unquoted: trailing ``# ...`` comment when preceded by whitespace.
    out_chars: list[str] = []
    i = 0
    n = len(value)
    while i < n:
        ch = value[i]
        if ch == "#" and (i == 0 or value[i - 1] in (" ", "\t")):
            break
        out_chars.append(ch)
        i += 1
    return "".join(out_chars).rstrip()


def _expand(value: str, env: dict[str, str] | os._Environ[str]) -> str:
    """Substitute ``${VAR}`` references using ``env``."""

    def repl(match: re.Match[str]) -> str:
        name = match.group(1)
        try:
            return env[name]
        except KeyError:
            return ""

    return _EXPAND_RE.sub(repl, value)
