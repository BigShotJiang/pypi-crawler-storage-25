"""Infrastructure adapters: HTTP client, YAML codec, .env loader, etc.

This package contains concrete implementations of cross-cutting concerns that
the application and CLI layers depend on. Everything here is implemented using
only the Python 3.12+ standard library — no third-party imports.
"""

from .backlog_analyzer import JiraBacklogAnalyzer
from .codebase_cross_referencer import CodebaseCrossReferencerService
from .confluence_client import ConfluenceApiClient, ConfluencePageRepository
from .domain_services import (
    BoundedContextResolverService,
    ComponentDeriverService,
    LabelDeriverService,
    PriorityCalculatorService,
    ThemeDetectorService,
)
from .duplicate_detector import DuplicateAnalysisResult, JiraDuplicateDetector
from .jira_client import JiraApiClient, JiraIssueRepository
from .mappers import ConfluenceContentMapper, IssueMapper

__all__ = [
    # API Clients
    "JiraApiClient",
    "ConfluenceApiClient",
    # Repositories
    "JiraIssueRepository",
    "ConfluencePageRepository",
    # Domain Services
    "ThemeDetectorService",
    "BoundedContextResolverService",
    "LabelDeriverService",
    "ComponentDeriverService",
    "PriorityCalculatorService",
    "JiraDuplicateDetector",
    "JiraBacklogAnalyzer",
    "CodebaseCrossReferencerService",
    # Result Types
    "DuplicateAnalysisResult",
    # Mappers
    "IssueMapper",
    "ConfluenceContentMapper",
]
