"""Framework-specific Jira API methods (paged JQL, links, transitions).

Copied from ``inovagio/scripts/_docframework.py::JiraClient``. Adapted to
delegate to :class:`atlassiancli.infrastructure.jira_client.JiraApiClient`
instead of holding its own urllib socket pool — so framework subcommands
share auth/rate-limit handling with the rest of atlassiancli.

The behaviour (endpoint URLs, payload shapes, paging semantics) is preserved
byte-for-byte from the source script: this is a transport swap, not a logic
rewrite.
"""

from __future__ import annotations

from typing import Any

from atlassiancli.infrastructure.jira_client import JiraApiClient, JiraApiError


class FrameworkJiraClient:
    """Thin facade over :class:`JiraApiClient` for framework bridge use.

    Mirrors the public surface of the source script's ``JiraClient`` so the
    application services copy across with minimal change. Each method maps
    1:1 onto the urllib-era source — the only delta is that errors flow
    through :class:`JiraApiError` (with status / body) instead of a bare
    ``RuntimeError``.
    """

    def __init__(self, api: JiraApiClient) -> None:
        self._api = api

    def search_jql(
        self,
        jql: str,
        *,
        fields: list[str] | None = None,
        max_results: int = 100,
    ) -> list[dict]:
        """POST ``/rest/api/3/search/jql`` (single page)."""
        body = {
            "jql": jql,
            "fields": fields or ["summary"],
            "maxResults": max_results,
        }
        response = self._api.post("/rest/api/3/search/jql", body)
        if response.status_code != 200:
            raise JiraApiError(f"search_jql failed: {response.status_code} - {response.text[:200]}")
        return response.json().get("issues", [])

    def search_jql_paged(
        self,
        jql: str,
        *,
        fields: list[str],
        page_size: int = 100,
    ) -> list[dict]:
        """Walk every page of a JQL search, exhausting ``nextPageToken``."""
        all_issues: list[dict] = []
        next_token: str | None = None
        while True:
            body: dict[str, Any] = {
                "jql": jql,
                "fields": fields,
                "maxResults": page_size,
            }
            if next_token:
                body["nextPageToken"] = next_token
            response = self._api.post("/rest/api/3/search/jql", body)
            if response.status_code != 200:
                raise JiraApiError(
                    f"search_jql_paged failed: {response.status_code} - {response.text[:200]}"
                )
            result = response.json()
            all_issues.extend(result.get("issues") or [])
            if result.get("isLast", True):
                break
            next_token = result.get("nextPageToken")
            if not next_token:
                break
        return all_issues

    def approximate_count(self, jql: str) -> int:
        """POST ``/rest/api/3/search/approximate-count`` for parity gates."""
        response = self._api.post("/rest/api/3/search/approximate-count", {"jql": jql})
        if response.status_code != 200:
            raise JiraApiError(
                f"approximate_count failed: {response.status_code} - {response.text[:200]}"
            )
        return int(response.json().get("count", 0))

    def find_account_id(self, email: str) -> str | None:
        """Resolve an email -> Atlassian ``accountId`` (case-insensitive)."""
        response = self._api.get("/rest/api/3/user/search", params={"query": email})
        if response.status_code != 200:
            return None
        results = response.json() or []
        for user in results:
            if user.get("emailAddress", "").lower() == email.lower():
                return user["accountId"]
        return None

    def create_issue(self, fields: dict) -> dict:
        """POST ``/rest/api/3/issue`` with ``{fields: ...}`` envelope."""
        response = self._api.post("/rest/api/3/issue", {"fields": fields})
        if response.status_code not in (200, 201):
            raise JiraApiError(
                f"create_issue failed: {response.status_code} - {response.text[:500]}"
            )
        return response.json()

    def add_issue_link(self, link_type: str, *, inward_key: str, outward_key: str) -> None:
        """POST ``/rest/api/3/issueLink`` for typed inter-issue dependencies."""
        body = {
            "type": {"name": link_type},
            "inwardIssue": {"key": inward_key},
            "outwardIssue": {"key": outward_key},
        }
        response = self._api.post("/rest/api/3/issueLink", body)
        if response.status_code not in (200, 201, 204):
            raise JiraApiError(
                f"add_issue_link failed: {response.status_code} - {response.text[:500]}"
            )

    def get_transitions(self, issue_key: str) -> list[dict]:
        """List the workflow transitions available on ``issue_key``."""
        response = self._api.get(f"/rest/api/3/issue/{issue_key}/transitions")
        if response.status_code != 200:
            raise JiraApiError(
                f"get_transitions failed: {response.status_code} - {response.text[:200]}"
            )
        return response.json().get("transitions") or []

    def transition_issue(self, issue_key: str, transition_id: str) -> None:
        """POST a transition by id to advance ``issue_key`` through workflow."""
        response = self._api.post(
            f"/rest/api/3/issue/{issue_key}/transitions",
            {"transition": {"id": transition_id}},
        )
        if response.status_code not in (200, 204):
            raise JiraApiError(
                f"transition_issue failed: {response.status_code} - {response.text[:200]}"
            )


__all__ = ["FrameworkJiraClient"]
