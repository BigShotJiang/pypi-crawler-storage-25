#!/usr/bin/env python3
"""
Story Domain Knowledge Base

Maps story content to actual bounded contexts, interfaces, schemas, and
technology requirements from the Inovagio codebase. Eliminates generic
boilerplate by resolving story-specific technical context.

Architecture:
- DDD Infrastructure Service (knowledge repository)
- SOLID: Single Responsibility (story context resolution)
- DRY: Single source of truth for domain-to-technology mapping

Author: Inovagio Engineering Team
"""

from dataclasses import dataclass, field

# ============================================================================
# STORY CONTEXT (Resolved Domain Object)
# ============================================================================


@dataclass
class StoryContext:
    """Resolved technical context for a specific story.

    This replaces category-only resolution with story-specific technical
    requirements derived from title/description analysis against the
    actual codebase structure.
    """

    # Identity
    story_title: str = ""
    resolved_category: str = "DEFAULT"

    # Bounded context resolution
    primary_bounded_context: str = "core-models"
    secondary_bounded_contexts: list[str] = field(default_factory=list)
    layer_placement: str = "Layer 3 - Domain services"

    # Technology-specific requirements
    existing_interfaces: list[tuple[str, str]] = field(default_factory=list)  # (name, description)
    new_interfaces_needed: list[tuple[str, str]] = field(
        default_factory=list
    )  # (name, description)
    key_value_objects: list[tuple[str, str]] = field(default_factory=list)  # (name, description)
    data_schemas: list[str] = field(default_factory=list)  # C++ struct/JSON schema blocks
    design_patterns: list[str] = field(default_factory=list)
    state_machine: list[str] = field(default_factory=list)
    code_examples: list[str] = field(default_factory=list)

    # Dependency tracking
    depends_on_stories: list[str] = field(default_factory=list)
    adjacent_stories: list[str] = field(default_factory=list)

    # Confluence linkage
    primary_confluence_doc: str = ""
    related_confluence_docs: list[str] = field(default_factory=list)


# ============================================================================
# BOUNDED CONTEXT KNOWLEDGE BASE
# ============================================================================

BOUNDED_CONTEXT_MAP: dict[str, dict] = {
    "core-models": {
        "layer": "Layer 0 (Foundation)",
        "description": "Universal types, IDs, value objects, domain primitives",
        "key_interfaces": [],
        "key_entities": ["Result<T,E>", "UUID", "Identity", "Checkpoint", "Timestamp"],
        "key_value_objects": [
            "IssueKey",
            "StoryPoints",
            "Priority",
            "Label",
            "Component",
        ],
        "dependencies": [],
    },
    "core-utils": {
        "layer": "Layer 1 (Infrastructure)",
        "description": "Thread pools, logging, serialization, regex, buffers, clock",
        "key_interfaces": ["IBufferPool", "IAllocator", "IClock", "IFallbackHandler"],
        "key_entities": ["BoundedThreadPool", "RegexCompiler", "EventBus"],
        "key_value_objects": [],
        "dependencies": ["core-models"],
    },
    "core-platform": {
        "layer": "Layer 1 (Infrastructure)",
        "description": "Platform services, memory policy, thread executor, observability abstraction",
        "key_interfaces": [
            "IPlatformServices",
            "IThreadExecutor",
            "IObservability",
            "IMemoryPolicy",
            "IArena",
            "IConfigManager",
        ],
        "key_entities": [],
        "key_value_objects": [],
        "dependencies": ["core-models"],
    },
    "core-governance": {
        "layer": "Layer 2 (Cross-Cutting)",
        "description": "RBAC, audit, compliance, policy enforcement",
        "key_interfaces": ["IAuthorizationService", "IAuditLogger", "IPolicyEngine"],
        "key_entities": ["Role", "Permission", "Policy", "AuditEntry"],
        "key_value_objects": ["RoleId", "PermissionSet"],
        "dependencies": ["core-models", "core-utils"],
    },
    "core-observability": {
        "layer": "Layer 2 (Cross-Cutting)",
        "description": "Metrics, tracing, logging, OTel provider, SLO tracking, LLM metrics",
        "key_interfaces": ["ILogger", "IMetrics", "ITracer", "ISloTracker"],
        "key_entities": [
            "OtelProvider",
            "SpanContext",
            "LlmMetrics",
            "AgentMetrics",
            "LlmErrorTracker",
        ],
        "key_value_objects": ["Labels", "SloModels"],
        "dependencies": ["core-models", "core-utils"],
    },
    "core-security": {
        "layer": "Layer 2 (Cross-Cutting)",
        "description": "Crypto, tokens, passwords, secrets, identity providers, sentinel audit",
        "key_interfaces": [
            "ICryptoService",
            "ITokenService",
            "IPasswordService",
            "ISecretStore",
            "IIdentityProvider",
            "INexusGuard",
            "ISentinelAuditService",
        ],
        "key_entities": ["IdentityProviderFactory", "SentinelAudit", "NexusGuard"],
        "key_value_objects": [],
        "dependencies": ["core-models", "core-utils"],
    },
    "core-persistence": {
        "layer": "Layer 2 (Cross-Cutting)",
        "description": "Storage abstraction, PostgreSQL connections",
        "key_interfaces": ["IRepository", "IUnitOfWork"],
        "key_entities": ["PostgresConnection"],
        "key_value_objects": [],
        "dependencies": ["core-models", "core-utils"],
    },
    "core-connectors": {
        "layer": "Layer 3 (Domain Services)",
        "description": "HTTP, MCP, PostgreSQL, Redis, S3 connectors, secret resolvers",
        "key_interfaces": ["ISecretResolver"],
        "key_entities": [
            "HttpConnector",
            "McpConnector",
            "RedisConnector",
            "S3Connector",
        ],
        "key_value_objects": [],
        "dependencies": ["core-models", "core-utils", "core-security"],
    },
    "core-agents": {
        "layer": "Layer 3 (Domain Services)",
        "description": "Agent lifecycle, LLM client, tools, tool registry, experience store",
        "key_interfaces": ["IAgent", "ILLMClient"],
        "key_entities": [
            "AgentRuntime",
            "AgentBridge",
            "AgentRunner",
            "ExperienceStore",
            "ChatGateway",
            "ToolProvider",
            "ToolRegistry",
            "SingleNodeRuntime",
        ],
        "key_value_objects": ["AgentId", "MessageSerializer", "EmployeeProfile"],
        "dependencies": [
            "core-models",
            "core-utils",
            "core-governance",
            "core-security",
        ],
    },
    "core-ani": {
        "layer": "Layer 3 (Domain Services)",
        "description": "Agent Network Interface — A2A, messaging, routing, discovery, handoff",
        "key_interfaces": ["IMessageRouter", "IMessageHandler"],
        "key_entities": [
            "Broker",
            "Gateway",
            "Discovery",
            "HandoffProtocol",
            "SecureChannel",
            "MessageRouter",
            "SessionLifecycle",
        ],
        "key_value_objects": ["Message", "A2ASchema", "MessageTypes", "CallChain"],
        "dependencies": ["core-models", "core-utils", "core-security"],
    },
    "core-orchestration": {
        "layer": "Layer 3 (Domain Services)",
        "description": "Workflow engine, executors, schedulers, triggers, DAG graph, HITL",
        "key_interfaces": [
            "IWorkflowRuntime",
            "IExecutionScheduler",
            "INodeExecutor",
            "INodeExecutorRegistry",
            "ITaskHandler",
            "ITaskHandlerFactory",
            "IExecutor",
            "IScheduler",
            "IWorkflowRunRepository",
            "IWorkflowDefinitionRepository",
            "IObservabilityHook",
            "IGovernanceHook",
            "IContentFilter",
            "ITrigger",
            "IHITLManager",
            "ISubWorkflowExecutor",
            "IDynamicRouter",
        ],
        "key_entities": [
            "WorkflowGraph",
            "Engine",
            "Runtime",
            "ExecutionContext",
            "NodeExecutor",
            "TaskHandler",
            "CircuitBreakerWithFallback",
            "RetryableNodeExecutor",
            "WorkflowAggregate",
        ],
        "key_value_objects": ["WorkflowModel", "TriggerModel"],
        "dependencies": [
            "core-models",
            "core-utils",
            "core-governance",
            "core-security",
        ],
    },
    "core-retrieval": {
        "layer": "Layer 3 (Domain Services)",
        "description": "RAG pipeline, embedder, retriever, reranker",
        "key_interfaces": ["IEmbedder", "IRagPipeline", "IReranker", "IRetriever"],
        "key_entities": ["RagPipeline", "Embedder", "Retriever", "Reranker"],
        "key_value_objects": ["EmbeddingVector", "RetrievalResult"],
        "dependencies": ["core-models", "core-utils", "core-persistence"],
    },
    "core-nexus": {
        "layer": "Layer 3 (Domain Services)",
        "description": "Capability registry, guard, PII redaction, manifest, telemetry",
        "key_interfaces": ["ICapabilityRegistry", "ICapabilityExecutor"],
        "key_entities": [
            "Capability",
            "Manifest",
            "Registry",
            "PiiRedactor",
            "Telemetry",
        ],
        "key_value_objects": ["CapabilityId", "Resource"],
        "dependencies": ["core-models", "core-utils", "core-governance"],
    },
    "core-workforce": {
        "layer": "Layer 4 (Application)",
        "description": "Virtual employees, parties, teams, organizations, roles, ACLs",
        "key_interfaces": [
            "IWorkforceService",
            "IPartyRepository",
            "IWorkUnitRepository",
            "IMemoryAccess",
            "IComplianceAcl",
            "IConnectorAcl",
            "IMarketplaceAcl",
            "IOriginAcl",
            "IOrchestrationAcl",
        ],
        "key_entities": [
            "VirtualEmployee",
            "Party",
            "Person",
            "Human",
            "Organization",
            "Team",
            "WorkUnit",
            "Assignment",
        ],
        "key_value_objects": ["RoleFacet", "Principal", "BusinessProcess"],
        "dependencies": [
            "core-models",
            "core-utils",
            "core-governance",
            "core-agents",
            "core-orchestration",
        ],
    },
    "core-evaluation": {
        "layer": "Layer 3 (Domain Services)",
        "description": "Evaluator for agent/model quality",
        "key_interfaces": ["IEvaluator"],
        "key_entities": ["Evaluator", "BenchmarkSuite"],
        "key_value_objects": ["EvaluationResult", "MetricScore"],
        "dependencies": ["core-models", "core-utils", "core-agents"],
    },
}


# ============================================================================
# BOUNDED CONTEXT → CATEGORY MAPPING
#
# When StoryContextResolver matches a specific technology pattern, this
# mapping provides the correct ExpertTeam category for the resolved bounded
# context. This overrides keyword-based category detection (which can
# produce false positives like "MCP" for core-agents stories when generic
# keywords like "tool" or "capability" appear in the description).
# ============================================================================

BOUNDED_CONTEXT_TO_CATEGORY: dict[str, str] = {
    "core-agents": "AGENTIC",
    "core-orchestration": "FLOW",
    "core-ani": "ANI",
    "core-nexus": "NEXUS",
    "core-retrieval": "AGENTIC",
    "core-security": "DEFAULT",
    "core-governance": "DEFAULT",
    "core-observability": "EVAL",
    "core-evaluation": "EVAL",
    "core-connectors": "MCP",
    "core-workforce": "DEFAULT",
    "core-models": "DEFAULT",
    "core-utils": "DEFAULT",
    "core-platform": "DEFAULT",
    "core-persistence": "DEFAULT",
}


# ============================================================================
# STORY TECHNOLOGY PATTERNS
#
# Maps specific keywords/phrases in story titles to their actual technical
# requirements. This is the key innovation: instead of category-based
# boilerplate, we resolve story-specific technology needs.
# ============================================================================

STORY_TECHNOLOGY_PATTERNS: dict[str, dict] = {
    # ── INOV-578: StructuredOutput<T> ──
    "structuredoutput": {
        "primary_context": "core-agents",
        "layer": "Layer 3 (Domain Services) — core-agents ILLMClient level",
        "existing_interfaces": [
            (
                "ILLMClient",
                "Abstract LLM client interface (90% complete) — core/agents/include/llm_client.hpp",
            ),
        ],
        "new_interfaces": [
            (
                "IStructuredOutputParser<T>",
                "Compile-time type-safe parser for LLM JSON responses",
            ),
        ],
        "value_objects": [
            (
                "StructuredOutput<T>",
                "Type-safe wrapper for deserialized LLM response with validation metadata",
            ),
            (
                "ValidationError",
                "Schema validation failure with field path and constraint details",
            ),
            (
                "OutputSchema",
                "JSON Schema definition for constraining LLM output format",
            ),
        ],
        "schemas": [
            "*StructuredOutput<T>* (C++ Template):",
            "```cpp",
            "template<typename T>",
            "struct StructuredOutput {",
            "    T value;                              // Deserialized typed result",
            "    OutputSchema schema;                   // JSON Schema used for validation",
            "    std::vector<ValidationError> warnings; // Non-fatal validation issues",
            "    int retry_count{0};                    // Retries needed for valid output",
            "    std::chrono::milliseconds parse_time;  // Deserialization latency",
            "};",
            "```",
            "",
            "*StructuredOutputRequest* (C++ Struct):",
            "```cpp",
            "struct StructuredOutputRequest {",
            "    std::string prompt;",
            "    OutputSchema schema;       // JSON Schema for output constraint",
            "    int max_retries{3};         // Retry-with-feedback attempts",
            "    bool strict_mode{true};     // Reject partial matches",
            "};",
            "```",
        ],
        "patterns": [
            "Strategy (output parsing)",
            "Template Method (retry-with-feedback)",
            "Builder (schema construction)",
        ],
        "state_machine": [
            "*States*: `Idle` -> `Generating` -> `Parsing` -> `Validating` -> `Retrying` | `Done`",
            "*Transitions*:",
            "• `generate<T>(request)`: `Idle` -> `Generating`",
            "• `llm_response_received`: `Generating` -> `Parsing`",
            "• `parse_success`: `Parsing` -> `Validating`",
            "• `validation_pass`: `Validating` -> `Done`",
            "• `validation_fail && retries < max`: `Validating` -> `Retrying` -> `Generating`",
            "• `validation_fail && retries >= max`: `Validating` -> `Done` (with errors)",
        ],
        "code_examples": [
            """*StructuredOutput<T> Usage — ILLMClient Extension*:
```cpp
#include "core/agents/include/llm_client.hpp"
#include "core/agents/include/structured_output.hpp"

// Define output type
struct CodeReview {
    std::string summary;
    std::vector<Issue> issues;
    int severity_score;
};

// Generate type-safe structured output
auto request = StructuredOutputRequest{
    .prompt = "Review this code for security issues",
    .schema = OutputSchema::from_type<CodeReview>(),
    .max_retries = 3,
    .strict_mode = true
};

Result<StructuredOutput<CodeReview>, Error> result =
    llm_client_->generate_structured<CodeReview>(request);

if (result.is_ok()) {
    const auto& review = result.unwrap().value;
    for (const auto& issue : review.issues) {
        logger_->log(LogLevel::Info, "code_issue_found",
            {{"severity", issue.severity}, {"description", issue.description}});
    }
}
```""",
        ],
        "depends_on": [],
        "adjacent": ["INOV-255 (inter-step validation)", "Origin constrained decoding"],
        "confluence": "Architecture/technology",
    },
    # ── INOV-579: IContextProvider ──
    "contextprovider": {
        "primary_context": "core-agents",
        "layer": "Layer 3 (Domain Services) — core-agents invocation lifecycle",
        "existing_interfaces": [
            ("IAgent", "Abstract agent interface — core/agents/include/iagent.hpp"),
        ],
        "new_interfaces": [
            (
                "IContextProvider",
                "Two-phase invocation lifecycle hook: before_invocation() → LLM → after_invocation()",
            ),
            ("IContextProviderChain", "Ordered chain of composable context providers"),
        ],
        "value_objects": [
            (
                "InvocationContext",
                "Accumulated context passed through provider chain into LLM call",
            ),
            ("ProviderResult", "Output from a single context provider phase"),
        ],
        "schemas": [
            "*IContextProvider* (C++ Interface):",
            "```cpp",
            "class IContextProvider {",
            "public:",
            "    virtual ~IContextProvider() = default;",
            "",
            "    /// Called before LLM invocation to inject context",
            "    [[nodiscard]] virtual Result<InvocationContext, Error>",
            "        before_invocation(const InvocationContext& ctx) = 0;",
            "",
            "    /// Called after LLM response for post-processing",
            "    [[nodiscard]] virtual Result<InvocationContext, Error>",
            "        after_invocation(const InvocationContext& ctx,",
            "                         const LLMResponse& response) = 0;",
            "",
            "    /// Provider priority for chain ordering",
            "    [[nodiscard]] virtual int priority() const = 0;",
            "};",
            "```",
            "",
            "*InvocationContext* (C++ Struct):",
            "```cpp",
            "struct InvocationContext {",
            "    std::string system_prompt;",
            "    std::vector<Message> messages;",
            "    std::unordered_map<std::string, std::string> metadata;",
            "    std::vector<std::string> injected_context_chunks;",
            "    UUID correlation_id;",
            "};",
            "```",
        ],
        "patterns": [
            "Chain of Responsibility (provider chain)",
            "Decorator (context wrapping)",
            "Observer (invocation events)",
        ],
        "state_machine": [
            "*States*: `Ready` -> `BeforePhase` -> `LLMInvocation` -> `AfterPhase` -> `Complete`",
            "*Transitions*:",
            "• `invoke(context)`: `Ready` -> `BeforePhase`",
            "• `all_providers_done`: `BeforePhase` -> `LLMInvocation`",
            "• `llm_response`: `LLMInvocation` -> `AfterPhase`",
            "• `post_processing_done`: `AfterPhase` -> `Complete`",
            "• `provider_error`: `*` -> `Error` (with partial context)",
        ],
        "code_examples": [
            """*IContextProvider Two-Phase Lifecycle*:
```cpp
#include "core/agents/include/context_provider.hpp"

class GovernanceContextProvider : public IContextProvider {
public:
    GovernanceContextProvider(std::shared_ptr<IAuthorizationService> auth)
        : auth_(std::move(auth)) {}

    Result<InvocationContext, Error>
    before_invocation(const InvocationContext& ctx) override {
        // Inject permission context before LLM call
        auto perms = auth_->get_permissions(ctx.metadata.at("user_id"));
        auto enriched = ctx;
        enriched.metadata["permissions"] = perms.to_string();
        return enriched;
    }

    Result<InvocationContext, Error>
    after_invocation(const InvocationContext& ctx,
                     const LLMResponse& response) override {
        // Audit the invocation after completion
        audit_logger_->log_audit(AuditEvent::LLMInvocation, {
            {"user_id", ctx.metadata.at("user_id")},
            {"model", response.model},
            {"tokens_used", std::to_string(response.usage.total_tokens)}
        });
        return ctx;
    }

    int priority() const override { return 100; } // High priority
};
```""",
        ],
        "depends_on": [],
        "adjacent": ["INOV-246", "INOV-244 (governance context contracts)"],
        "confluence": "Architecture/technology",
    },
    # ── INOV-580: DelegatingAgent ──
    "delegatingagent": {
        "primary_context": "core-agents",
        "layer": "Layer 3 (Domain Services) — core-agents middleware pipeline",
        "existing_interfaces": [
            ("IAgent", "Abstract agent interface — core/agents/include/iagent.hpp"),
        ],
        "new_interfaces": [
            (
                "DelegatingAgent",
                "Composable middleware wrapper for IAgent with decorator chain",
            ),
        ],
        "value_objects": [
            (
                "MiddlewareConfig",
                "Configuration for middleware ordering and parameters",
            ),
            (
                "DelegationResult",
                "Result from middleware chain execution with diagnostics",
            ),
        ],
        "schemas": [
            "*DelegatingAgent* (C++ Class):",
            "```cpp",
            "class DelegatingAgent : public IAgent {",
            "public:",
            "    explicit DelegatingAgent(std::shared_ptr<IAgent> inner);",
            "",
            "    /// Add middleware layer to the pipeline",
            "    DelegatingAgent& add_middleware(",
            "        std::shared_ptr<IAgentMiddleware> middleware);",
            "",
            "    /// Build the chain and return the wrapped agent",
            "    [[nodiscard]] std::shared_ptr<IAgent> build();",
            "",
            "    // IAgent interface delegation",
            "    Result<Response, Error> invoke(const Request& req) override;",
            "",
            "private:",
            "    std::shared_ptr<IAgent> inner_;",
            "    std::vector<std::shared_ptr<IAgentMiddleware>> middlewares_;",
            "};",
            "```",
            "",
            "*IAgentMiddleware* (C++ Interface):",
            "```cpp",
            "class IAgentMiddleware {",
            "public:",
            "    virtual ~IAgentMiddleware() = default;",
            "    [[nodiscard]] virtual Result<Response, Error>",
            "        process(const Request& req,",
            "                std::function<Result<Response, Error>(const Request&)> next) = 0;",
            "};",
            "```",
        ],
        "patterns": [
            "Decorator (middleware chain)",
            "Chain of Responsibility (pipeline)",
            "Strategy (middleware implementations)",
        ],
        "state_machine": [
            "*Pipeline*: `Request` -> `Telemetry` -> `Governance` -> `Caching` -> `RateLimiting` -> `Retry` -> `InnerAgent` -> `Response`",
            "*Each middleware*: `Enter` -> `ProcessRequest` -> `CallNext` -> `ProcessResponse` -> `Exit`",
        ],
        "code_examples": [
            """*DelegatingAgent Middleware Pipeline*:
```cpp
#include "core/agents/include/delegating_agent.hpp"

// Build composable middleware pipeline
auto agent = DelegatingAgent(inner_agent)
    .add_middleware(std::make_shared<TelemetryMiddleware>(tracer_))
    .add_middleware(std::make_shared<GovernanceMiddleware>(auth_service_))
    .add_middleware(std::make_shared<CachingMiddleware>(cache_))
    .add_middleware(std::make_shared<RateLimitMiddleware>(limiter_))
    .add_middleware(std::make_shared<RetryMiddleware>(
        RetryConfig{.max_retries = 3, .backoff = ExponentialBackoff{}}))
    .build();

// Use like any IAgent
auto result = agent->invoke(request);
// Telemetry -> Governance -> Cache -> RateLimit -> Retry -> InnerAgent
```""",
        ],
        "depends_on": [],
        "adjacent": [
            "INOV-518 (IdP decorator)",
            "INOV-3 (Guard hooks)",
            "INOV-346 (GuardObserver)",
        ],
        "confluence": "Architecture/technology",
    },
    # ── INOV-581: IRAGContextProvider ──
    "ragcontextprovider|rag-to-agent|ragpipeline": {
        "primary_context": "core-retrieval",
        "secondary_contexts": ["core-agents"],
        "layer": "Layer 3 (Domain Services) — core-retrieval + core-agents bridge",
        "existing_interfaces": [
            (
                "IRagPipeline",
                "RAG pipeline interface — core/retrieval/include/rag_pipeline.hpp",
            ),
            ("IRetriever", "Document retriever — core/retrieval/include/retriever.hpp"),
            ("IEmbedder", "Embedding generator — core/retrieval/include/embedder.hpp"),
            ("IReranker", "Result reranker — core/retrieval/include/reranker.hpp"),
        ],
        "new_interfaces": [
            (
                "IRAGContextProvider",
                "IContextProvider implementation that auto-injects retrieved context into agent invocations",
            ),
        ],
        "value_objects": [
            (
                "RetrievalConfig",
                "Configuration for RAG context injection (top-k, score threshold, chunk strategy)",
            ),
            (
                "RetrievedChunk",
                "A single retrieved document chunk with score and metadata",
            ),
        ],
        "schemas": [
            "*IRAGContextProvider* (C++ Class — implements IContextProvider):",
            "```cpp",
            "class RAGContextProvider : public IContextProvider {",
            "public:",
            "    RAGContextProvider(",
            "        std::shared_ptr<IRagPipeline> pipeline,",
            "        RetrievalConfig config);",
            "",
            "    Result<InvocationContext, Error>",
            "        before_invocation(const InvocationContext& ctx) override;",
            "",
            "    Result<InvocationContext, Error>",
            "        after_invocation(const InvocationContext& ctx,",
            "                         const LLMResponse& response) override;",
            "",
            "    int priority() const override { return 50; }",
            "",
            "private:",
            "    std::shared_ptr<IRagPipeline> pipeline_;",
            "    RetrievalConfig config_;",
            "};",
            "```",
        ],
        "patterns": [
            "Bridge (RAG ↔ Agent lifecycle)",
            "Strategy (retrieval configuration)",
            "Adapter (pipeline to context provider)",
        ],
        "state_machine": [
            "*before_invocation*: `ExtractQuery` -> `Embed` -> `Retrieve` -> `Rerank` -> `InjectContext`",
            "*after_invocation*: `LogRetrievalMetrics` -> `UpdateExperienceStore` (optional)",
        ],
        "code_examples": [
            """*RAG-to-Agent Invocation Bridge*:
```cpp
#include "core/retrieval/include/rag_context_provider.hpp"

// Configure RAG context injection
auto rag_provider = std::make_shared<RAGContextProvider>(
    rag_pipeline_,
    RetrievalConfig{
        .top_k = 5,
        .score_threshold = 0.7f,
        .chunk_strategy = ChunkStrategy::Semantic,
        .max_context_tokens = 4096
    }
);

// Register as context provider in agent invocation chain
agent_runtime.register_context_provider(rag_provider);

// Now every agent invocation automatically retrieves relevant context
auto result = agent->invoke(request);
// RAGContextProvider.before_invocation() runs:
//   1. Extract query from last message
//   2. Embed query via IEmbedder
//   3. Retrieve top-k chunks via IRetriever
//   4. Rerank via IReranker
//   5. Inject chunks into InvocationContext
```""",
        ],
        "depends_on": ["INOV-579 (IContextProvider interface)"],
        "adjacent": [
            "INOV-257 (RAG pipeline)",
            "INOV-533 (experience store)",
            "INOV-473 (role-based LTM)",
        ],
        "confluence": "Architecture/technology",
    },
    # ── INOV-582: Stream Continuation & Resume ──
    "stream": {
        "primary_context": "core-agents",
        "layer": "Layer 3 (Domain Services) — core-agents streaming subsystem (new)",
        "existing_interfaces": [
            (
                "ILLMClient",
                "Abstract LLM client — currently returns complete responses only",
            ),
        ],
        "new_interfaces": [
            ("IStreamManager", "Manages SSE stream lifecycle with checkpoint/resume"),
            ("IStreamConsumer", "Consumer interface for receiving stream chunks"),
        ],
        "value_objects": [
            (
                "StreamCheckpoint",
                "Serializable checkpoint token for resume-from-interruption",
            ),
            (
                "StreamChunk",
                "Individual streaming chunk with sequence number and metadata",
            ),
            ("BackpressureConfig", "Flow control configuration for stream consumer"),
        ],
        "schemas": [
            "*IStreamManager* (C++ Interface):",
            "```cpp",
            "class IStreamManager {",
            "public:",
            "    virtual ~IStreamManager() = default;",
            "",
            "    [[nodiscard]] virtual Result<StreamHandle, Error>",
            "        start_stream(const StreamRequest& req) = 0;",
            "",
            "    [[nodiscard]] virtual Result<StreamHandle, Error>",
            "        resume_stream(const StreamCheckpoint& checkpoint) = 0;",
            "",
            "    [[nodiscard]] virtual Result<void, Error>",
            "        cancel_stream(StreamHandle handle) = 0;",
            "};",
            "```",
            "",
            "*StreamCheckpoint* (C++ Struct):",
            "```cpp",
            "struct StreamCheckpoint {",
            "    UUID stream_id;",
            "    uint64_t sequence_number;    // Last received chunk",
            "    std::string provider_token;  // Provider-specific resume token",
            "    std::chrono::system_clock::time_point created_at;",
            "};",
            "```",
        ],
        "patterns": [
            "Observer (stream events)",
            "Memento (checkpoint/restore)",
            "Strategy (backpressure policies)",
        ],
        "state_machine": [
            "*States*: `Idle` -> `Streaming` -> `Paused` -> `Resuming` -> `Complete` | `Failed`",
            "*Transitions*:",
            "• `start_stream()`: `Idle` -> `Streaming`",
            "• `backpressure_trigger`: `Streaming` -> `Paused`",
            "• `consumer_ready`: `Paused` -> `Streaming`",
            "• `connection_lost`: `Streaming` -> `Failed` (checkpoint saved)",
            "• `resume_stream(checkpoint)`: `Failed` -> `Resuming` -> `Streaming`",
            "• `end_of_stream`: `Streaming` -> `Complete`",
        ],
        "code_examples": [
            """*Stream with Checkpoint Resume*:
```cpp
#include "core/agents/include/stream_manager.hpp"

auto stream = stream_manager_->start_stream(StreamRequest{
    .prompt = "Analyze this large codebase...",
    .model = "gpt-4",
    .enable_checkpoints = true
});

if (stream.is_ok()) {
    auto handle = stream.unwrap();
    handle.on_chunk([&](const StreamChunk& chunk) {
        process_chunk(chunk);
    });

    handle.on_error([&](const Error& err, const StreamCheckpoint& cp) {
        // Save checkpoint for later resume
        checkpoint_store_->save(cp);
        LOG_WARN("Stream interrupted at seq {}, checkpoint saved",
                 cp.sequence_number);
    });
}

// Resume from checkpoint after reconnection
auto checkpoint = checkpoint_store_->load(stream_id);
auto resumed = stream_manager_->resume_stream(checkpoint);
```""",
        ],
        "depends_on": [],
        "adjacent": [],
        "confluence": "Architecture/technology",
    },
    # ── INOV-583: BSP Superstep ──
    "superstep|bsp": {
        "primary_context": "core-orchestration",
        "layer": "Layer 3 (Domain Services) — core-orchestration execution model",
        "existing_interfaces": [
            ("IExecutor", "Task executor interface"),
            (
                "INodeExecutor",
                "Graph node executor — core/orchestration/include/node_executor.hpp",
            ),
            (
                "IScheduler",
                "Execution scheduler — core/orchestration/include/scheduler.hpp",
            ),
            (
                "IWorkflowRuntime",
                "Workflow runtime — core/orchestration/include/workflow_runtime.hpp",
            ),
        ],
        "new_interfaces": [
            ("IBSPExecutor", "Barrier-synchronized BSP superstep executor"),
            (
                "IBarrierSynchronizer",
                "Barrier synchronization primitive for superstep boundaries",
            ),
        ],
        "value_objects": [
            (
                "SuperstepState",
                "Global state at superstep boundary (counter, aggregated results, convergence metric)",
            ),
            ("BarrierToken", "Token indicating all workers have reached the barrier"),
        ],
        "schemas": [
            "*IBSPExecutor* (C++ Interface):",
            "```cpp",
            "class IBSPExecutor {",
            "public:",
            "    virtual ~IBSPExecutor() = default;",
            "",
            "    [[nodiscard]] virtual Result<SuperstepState, Error>",
            "        execute_superstep(",
            "            uint32_t superstep_number,",
            "            const std::vector<NodeTask>& tasks,",
            "            const SuperstepState& global_state) = 0;",
            "",
            "    [[nodiscard]] virtual Result<BarrierToken, Error>",
            "        wait_for_barrier(uint32_t superstep_number) = 0;",
            "",
            "    [[nodiscard]] virtual bool",
            "        has_converged(const SuperstepState& state) const = 0;",
            "};",
            "```",
        ],
        "patterns": [
            "Template Method (superstep lifecycle)",
            "Barrier (synchronization)",
            "Iterator (superstep sequence)",
        ],
        "state_machine": [
            "*States*: `Init` -> `Computing` -> `Barrier` -> `Aggregating` -> `CheckConvergence` -> `Computing` | `Done`",
            "*Transitions*:",
            "• `start()`: `Init` -> `Computing` (superstep 0)",
            "• `all_workers_done`: `Computing` -> `Barrier`",
            "• `barrier_released`: `Barrier` -> `Aggregating`",
            "• `aggregation_complete`: `Aggregating` -> `CheckConvergence`",
            "• `not_converged`: `CheckConvergence` -> `Computing` (superstep N+1)",
            "• `converged`: `CheckConvergence` -> `Done`",
        ],
        "code_examples": [
            """*BSP Superstep Execution*:
```cpp
#include "core/orchestration/include/bsp_executor.hpp"

auto bsp = BSPExecutor::create(BSPConfig{
    .max_supersteps = 100,
    .convergence_threshold = 0.001,
    .worker_count = 4
});

SuperstepState global_state{};
uint32_t superstep = 0;

while (!bsp->has_converged(global_state) && superstep < max_supersteps) {
    // Execute all tasks in current superstep (parallel)
    auto result = bsp->execute_superstep(superstep, tasks, global_state);
    if (!result.is_ok()) {
        return result.error();
    }

    // Wait for all workers to reach barrier
    auto barrier = bsp->wait_for_barrier(superstep);

    // Aggregate results into global state
    global_state = result.unwrap();
    ++superstep;
}
```""",
        ],
        "depends_on": ["INOV-4 (Core Workflow Engine)"],
        "adjacent": [
            "INOV-440 (ParallelExecutor)",
            "INOV-428 (executor resilience)",
            "INOV-434 (INodeExecutor contract)",
        ],
        "confluence": "Orchestration/main",
    },
    # ── INOV-584: Fan-Out / Fan-In ──
    "fan-out|fan-in|scatter|gather": {
        "primary_context": "core-orchestration",
        "layer": "Layer 3 (Domain Services) — core-orchestration graph edges",
        "existing_interfaces": [
            ("INodeExecutor", "Graph node executor"),
            ("IWorkflowRuntime", "Workflow runtime"),
        ],
        "new_interfaces": [
            ("IFanOutStrategy", "Dynamic fan-out strategy for scatter operations"),
            ("IFanInAggregator", "Typed aggregation strategy for gather operations"),
        ],
        "value_objects": [
            (
                "FanOutEdge",
                "Typed edge representing scatter operation with dynamic cardinality",
            ),
            (
                "FanInEdge",
                "Typed edge representing gather operation with aggregation policy",
            ),
            (
                "AggregationPolicy",
                "Policy: first-wins, majority-vote, merge-all, custom",
            ),
        ],
        "schemas": [
            "*FanOutEdge / FanInEdge* (C++ Structs):",
            "```cpp",
            "struct FanOutEdge {",
            "    UUID source_node;",
            "    std::vector<UUID> target_nodes;  // Dynamic at runtime",
            "    FanOutStrategy strategy;           // round-robin, broadcast, conditional",
            "};",
            "",
            "struct FanInEdge {",
            "    std::vector<UUID> source_nodes;",
            "    UUID target_node;",
            "    AggregationPolicy policy;  // first-wins, majority-vote, merge-all",
            "    std::optional<std::chrono::milliseconds> timeout;",
            "};",
            "```",
        ],
        "patterns": [
            "Strategy (aggregation policies)",
            "Factory (edge creation)",
            "Observer (partial result notification)",
        ],
        "state_machine": [
            "*Fan-Out*: `Pending` -> `Scattering` -> `AllDispatched` -> `WaitingForResults`",
            "*Fan-In*: `Collecting` -> `ThresholdMet` | `Timeout` -> `Aggregating` -> `Done`",
        ],
        "code_examples": [
            """*Fan-Out / Fan-In Typed Edges*:
```cpp
#include "core/orchestration/include/fan_out_edge.hpp"
#include "core/orchestration/include/fan_in_edge.hpp"

// Fan-out: scatter analysis across multiple agent nodes
auto fan_out = FanOutEdge{
    .source_node = analysis_node,
    .strategy = FanOutStrategy::Broadcast
};

// Fan-in: aggregate results with majority-vote
auto fan_in = FanInEdge{
    .target_node = aggregation_node,
    .policy = AggregationPolicy::MajorityVote,
    .timeout = std::chrono::seconds(30)
};

workflow_graph.add_edge(fan_out);
workflow_graph.add_edge(fan_in);
```""",
        ],
        "depends_on": ["INOV-4 (Core Workflow Engine)"],
        "adjacent": ["INOV-573 (safety rails)", "INOV-440 (parallel execution)"],
        "confluence": "Orchestration/main",
    },
    # ── INOV-585: Multi-Provider LLM ──
    "multi-provider|llm expansion|anthropic|gemini|claude": {
        "primary_context": "core-agents",
        "layer": "Layer 3 (Domain Services) — core-agents LLM provider abstraction",
        "existing_interfaces": [
            ("ILLMClient", "Abstract LLM client — currently OpenAI only"),
        ],
        "new_interfaces": [
            (
                "ILLMProviderFactory",
                "Factory for creating provider-specific ILLMClient implementations",
            ),
            (
                "ILLMCapabilityRouter",
                "Routes requests to providers based on capability/cost/latency",
            ),
        ],
        "value_objects": [
            (
                "ProviderConfig",
                "Provider-specific configuration (API key, endpoint, model)",
            ),
            (
                "ProviderCapability",
                "Declared capabilities per provider (vision, function-calling, streaming)",
            ),
            ("CostEstimate", "Estimated cost for a request to a specific provider"),
        ],
        "schemas": [
            "*ILLMProviderFactory* (C++ Interface):",
            "```cpp",
            "class ILLMProviderFactory {",
            "public:",
            "    virtual ~ILLMProviderFactory() = default;",
            "",
            "    [[nodiscard]] virtual Result<std::shared_ptr<ILLMClient>, Error>",
            "        create_client(const ProviderConfig& config) = 0;",
            "",
            "    [[nodiscard]] virtual std::vector<ProviderCapability>",
            "        get_capabilities(const std::string& provider_name) const = 0;",
            "};",
            "```",
        ],
        "patterns": [
            "Abstract Factory (provider creation)",
            "Strategy (capability routing)",
            "Adapter (provider normalization)",
        ],
        "state_machine": [
            "*Routing*: `ReceiveRequest` -> `EvaluateCapabilities` -> `SelectProvider` -> `RouteToProvider` -> `NormalizeResponse`",
        ],
        "code_examples": [
            """*Multi-Provider LLM Client*:
```cpp
#include "core/agents/include/llm_provider_factory.hpp"

// Register providers
auto factory = LLMProviderFactory::create();
factory->register_provider("openai", OpenAIProvider::create(openai_config));
factory->register_provider("anthropic", AnthropicProvider::create(claude_config));
factory->register_provider("azure_openai", AzureOpenAIProvider::create(azure_config));

// Capability-based routing
auto router = CapabilityRouter::create(factory);
router->set_preference(RoutingStrategy::CostOptimized);

// Route to best provider for this request
auto client = router->select_client(request);
auto result = client->generate(prompt);
// Router selects based on: capability match, cost, latency, availability
```""",
        ],
        "depends_on": [],
        "adjacent": ["Existing OpenAI support via ILLMClient"],
        "confluence": "Architecture/technology",
    },
    # ── INOV-586: AgentTool Wrapper ──
    "agenttool|agent-as-tool|agent as tool": {
        "primary_context": "core-agents",
        "layer": "Layer 3 (Domain Services) — core-agents tool composition",
        "existing_interfaces": [
            ("IAgent", "Abstract agent interface"),
            ("ToolProvider", "Tool provider for agent tool access"),
            ("ToolRegistry", "Registry of available tools"),
        ],
        "new_interfaces": [
            (
                "AgentTool",
                "Wrapper that exposes IAgent as a callable tool in ToolRegistry",
            ),
        ],
        "value_objects": [
            (
                "AgentToolManifest",
                "Auto-generated JSON Schema from agent capability manifest",
            ),
            (
                "DelegationToken",
                "Security token forwarded when delegating to agent-as-tool",
            ),
        ],
        "schemas": [
            "*AgentTool* (C++ Class):",
            "```cpp",
            "class AgentTool : public ITool {",
            "public:",
            "    explicit AgentTool(",
            "        std::shared_ptr<IAgent> agent,",
            "        AgentToolConfig config);",
            "",
            "    [[nodiscard]] ToolManifest get_manifest() const override;",
            "    [[nodiscard]] Result<ToolResult, Error>",
            "        execute(const ToolInput& input) override;",
            "",
            "private:",
            "    std::shared_ptr<IAgent> agent_;",
            "    AgentToolConfig config_;",
            "    ToolManifest cached_manifest_;  // Auto-generated from agent",
            "};",
            "```",
        ],
        "patterns": [
            "Adapter (agent → tool)",
            "Facade (simplify agent interface)",
            "Proxy (delegation token forwarding)",
        ],
        "state_machine": [],
        "code_examples": [
            """*Agent-as-Tool Composition*:
```cpp
#include "core/agents/include/agent_tool.hpp"

// Wrap an agent as a callable tool
auto research_agent = create_research_agent();
auto agent_tool = std::make_shared<AgentTool>(
    research_agent,
    AgentToolConfig{
        .name = "research",
        .description = "Research agent for deep analysis",
        .auto_generate_schema = true,  // From capability manifest
        .forward_delegation_token = true
    }
);

// Register in tool registry — now other agents can call it
tool_registry_->register_tool(agent_tool);
```""",
        ],
        "depends_on": ["INOV-578 (schema generation for StructuredOutput)"],
        "adjacent": [
            "INOV-236 (delegation tokens)",
            "INOV-534 (DELEGATE message)",
            "INOV-363 (task decomposition)",
        ],
        "confluence": "Architecture/technology",
    },
    # ── INOV-587: Named Orchestration Primitives ──
    "sequentialagent|concurrentagent|sequential/concurrent|sequential agent|concurrent agent|groupchat|orchestration primitive|composition pattern": {
        "primary_context": "core-orchestration",
        "secondary_contexts": ["core-agents"],
        "layer": "Layer 3 (Domain Services) — core-agents named orchestrators",
        "existing_interfaces": [
            ("IAgent", "Abstract agent interface"),
        ],
        "new_interfaces": [
            (
                "SequentialAgent",
                "Named orchestrator: execute agents in order, passing output as input",
            ),
            (
                "ConcurrentAgent",
                "Named orchestrator: execute agents in parallel, merge results",
            ),
            (
                "GroupChat",
                "Named orchestrator: round-robin or moderated multi-agent conversation",
            ),
        ],
        "value_objects": [
            ("OrchestrationConfig", "Configuration for named orchestration primitives"),
            ("ConversationTurn", "A single turn in a group chat conversation"),
        ],
        "schemas": [
            "*Named Orchestration Primitives* (C++ Classes):",
            "```cpp",
            "class SequentialAgent : public IAgent {",
            "public:",
            "    explicit SequentialAgent(std::vector<std::shared_ptr<IAgent>> agents);",
            "    Result<Response, Error> invoke(const Request& req) override;",
            "};",
            "",
            "class ConcurrentAgent : public IAgent {",
            "public:",
            "    ConcurrentAgent(std::vector<std::shared_ptr<IAgent>> agents,",
            "                    AggregationPolicy merge_policy);",
            "    Result<Response, Error> invoke(const Request& req) override;",
            "};",
            "",
            "class GroupChat : public IAgent {",
            "public:",
            "    GroupChat(std::vector<std::shared_ptr<IAgent>> participants,",
            "              std::shared_ptr<IAgent> moderator,",
            "              GroupChatConfig config);",
            "    Result<Response, Error> invoke(const Request& req) override;",
            "};",
            "```",
        ],
        "patterns": [
            "Composite (agent composition)",
            "Mediator (group chat moderation)",
            "Strategy (aggregation policies)",
        ],
        "state_machine": [
            "*SequentialAgent*: `Start` -> `Agent[0]` -> `Agent[1]` -> ... -> `Agent[N]` -> `Done`",
            "*ConcurrentAgent*: `Start` -> `ForkAll` -> `WaitAll` -> `Aggregate` -> `Done`",
            "*GroupChat*: `Start` -> `NextTurn` -> `Moderate` -> `NextTurn` | `Terminate`",
        ],
        "code_examples": [
            """*Named Orchestration Primitives*:
```cpp
#include "core/agents/include/orchestration_primitives.hpp"

// Sequential: pipeline of agents
auto pipeline = std::make_shared<SequentialAgent>(
    std::vector{research_agent, analysis_agent, summary_agent});

// Concurrent: parallel execution with merge
auto parallel = std::make_shared<ConcurrentAgent>(
    std::vector{fast_agent, thorough_agent},
    AggregationPolicy::BestQuality);

// GroupChat: moderated conversation
auto chat = std::make_shared<GroupChat>(
    std::vector{expert_a, expert_b, expert_c},
    moderator_agent,
    GroupChatConfig{.max_turns = 10, .termination = "consensus"});

auto result = chat->invoke(request);
```""",
        ],
        "depends_on": [],
        "adjacent": [
            "INOV-288 (handoff)",
            "INOV-298 (advanced handoff)",
            "INOV-534 (DELEGATE)",
        ],
        "confluence": "Architecture/technology",
    },
    # ── INOV-588: OTel GenAI Semantic Conventions ──
    "otel|opentelemetry|genai semantic|semantic convention": {
        "primary_context": "core-observability",
        "layer": "Layer 2 (Cross-Cutting) — core-observability OTel compliance",
        "existing_interfaces": [
            (
                "ITracer",
                "Distributed tracing interface — core/observability/include/tracer.hpp",
            ),
            ("IMetrics", "Metrics collection — core/observability/include/metrics.hpp"),
            ("ILogger", "Structured logging — core/observability/include/logger.hpp"),
        ],
        "new_interfaces": [],
        "value_objects": [
            (
                "GenAISpanAttributes",
                "OTel v1.38.0 GenAI semantic convention attributes",
            ),
            ("LLMUsageMetrics", "Token usage, cost, and latency metrics per request"),
        ],
        "schemas": [
            "*GenAI Semantic Convention Attributes* (v1.38.0):",
            "```cpp",
            "namespace otel::genai {",
            "    // Request attributes",
            '    constexpr auto REQUEST_MODEL = "gen_ai.request.model";',
            '    constexpr auto REQUEST_TEMPERATURE = "gen_ai.request.temperature";',
            '    constexpr auto REQUEST_TOP_P = "gen_ai.request.top_p";',
            '    constexpr auto REQUEST_MAX_TOKENS = "gen_ai.request.max_tokens";',
            "",
            "    // Response attributes",
            '    constexpr auto RESPONSE_MODEL = "gen_ai.response.model";',
            '    constexpr auto RESPONSE_FINISH_REASONS = "gen_ai.response.finish_reasons";',
            "",
            "    // Usage attributes",
            '    constexpr auto USAGE_INPUT_TOKENS = "gen_ai.usage.input_tokens";',
            '    constexpr auto USAGE_OUTPUT_TOKENS = "gen_ai.usage.output_tokens";',
            '    constexpr auto USAGE_COST = "gen_ai.usage.cost";',
            "",
            "    // Agent attributes",
            '    constexpr auto AGENT_NAME = "gen_ai.agent.name";',
            '    constexpr auto AGENT_DESCRIPTION = "gen_ai.agent.description";',
            "}",
            "```",
        ],
        "patterns": [
            "Observer (span lifecycle)",
            "Decorator (auto-instrumentation)",
            "Strategy (metric aggregation)",
        ],
        "state_machine": [],
        "code_examples": [
            """*OTel GenAI Instrumentation*:
```cpp
#include "core/observability/include/otel_genai.hpp"

// Auto-instrument LLM calls with GenAI semantic conventions
auto span = tracer_->start_span("gen_ai.chat");
span->set_attribute(otel::genai::REQUEST_MODEL, "gpt-4");
span->set_attribute(otel::genai::REQUEST_TEMPERATURE, 0.7);

auto result = llm_client_->generate(prompt);

if (result.is_ok()) {
    const auto& response = result.unwrap();
    span->set_attribute(otel::genai::RESPONSE_MODEL, response.model);
    span->set_attribute(otel::genai::USAGE_INPUT_TOKENS, response.usage.input);
    span->set_attribute(otel::genai::USAGE_OUTPUT_TOKENS, response.usage.output);
    span->set_attribute(otel::genai::USAGE_COST, response.usage.estimated_cost);
    span->set_attribute(otel::genai::RESPONSE_FINISH_REASONS, response.finish_reason);
}

span->end();
```""",
        ],
        "depends_on": [],
        "adjacent": [
            "INOV-101 (observability engine)",
            "INOV-116 (OTel spans)",
            "INOV-117 (Prometheus metrics)",
        ],
        "confluence": "Architecture/technology",
    },
}


# ============================================================================
# STORY CONTEXT RESOLVER
# ============================================================================


class StoryContextResolver:
    """Resolves story title/description to specific technical context.

    Instead of mapping to a broad category (FLOW, ANI, etc.) and generating
    boilerplate, this resolver matches story content against actual technology
    patterns and produces story-specific technical requirements.

    Architecture:
    - DDD: Infrastructure Service (knowledge resolution)
    - SOLID/SRP: Single responsibility — resolve story context
    - SOLID/OCP: Open for extension — add new patterns to STORY_TECHNOLOGY_PATTERNS
    """

    def __init__(self) -> None:
        self._patterns = STORY_TECHNOLOGY_PATTERNS
        self._bounded_contexts = BOUNDED_CONTEXT_MAP

    def resolve(self, title: str, description: str, category: str = "DEFAULT") -> StoryContext:
        """Resolve story-specific technical context.

        Args:
            title: Story title (primary signal for pattern matching)
            description: Story description (secondary signal)
            category: Broad category from ExpertTeam.detect_category()

        Returns:
            StoryContext with resolved domain-specific requirements
        """
        ctx = StoryContext(story_title=title, resolved_category=category)

        # Try to match against specific technology patterns
        matched_pattern = self._match_technology_pattern(title, description)

        if matched_pattern:
            self._apply_pattern(ctx, matched_pattern)
        else:
            # Fall back to bounded context resolution from keywords
            self._resolve_from_keywords(ctx, title, description, category)

        return ctx

    def _match_technology_pattern(self, title: str, description: str) -> dict | None:
        """Match story against specific technology patterns.

        Uses regex patterns in STORY_TECHNOLOGY_PATTERNS keys to find
        the most specific match for this story.
        """
        combined = f"{title} {description}".lower()

        best_match: dict | None = None
        best_score = 0

        for pattern_key, pattern_data in self._patterns.items():
            # Split pattern key by | for alternation
            keywords = pattern_key.split("|")
            score = 0
            for kw in keywords:
                kw_lower = kw.strip().lower()
                if kw_lower in combined:
                    # Weight title matches higher than description matches
                    if kw_lower in title.lower():
                        score += 10 + len(kw_lower)  # Prefer longer/more specific matches
                    else:
                        score += 1

            if score > best_score:
                best_score = score
                best_match = pattern_data

        return best_match if best_score > 0 else None

    def _apply_pattern(self, ctx: StoryContext, pattern: dict) -> None:
        """Apply matched technology pattern to story context."""
        ctx.primary_bounded_context = pattern.get("primary_context", "core-models")
        ctx.secondary_bounded_contexts = pattern.get("secondary_contexts", [])
        ctx.layer_placement = pattern.get("layer", "Layer 3 - Domain services")

        # Override resolved_category based on bounded context mapping.
        # This prevents keyword-based category detection false positives
        # (e.g., "tool" matching MCP for a core-agents story).
        ctx.resolved_category = BOUNDED_CONTEXT_TO_CATEGORY.get(
            ctx.primary_bounded_context, ctx.resolved_category
        )

        ctx.existing_interfaces = [
            (name, desc) for name, desc in pattern.get("existing_interfaces", [])
        ]
        ctx.new_interfaces_needed = [
            (name, desc) for name, desc in pattern.get("new_interfaces", [])
        ]
        ctx.key_value_objects = [(name, desc) for name, desc in pattern.get("value_objects", [])]

        ctx.data_schemas = pattern.get("schemas", [])
        ctx.design_patterns = pattern.get("patterns", [])
        ctx.state_machine = pattern.get("state_machine", [])
        ctx.code_examples = pattern.get("code_examples", [])
        ctx.depends_on_stories = pattern.get("depends_on", [])
        ctx.adjacent_stories = pattern.get("adjacent", [])

        # Resolve Confluence doc
        confluence_key = pattern.get("confluence", "")
        if confluence_key:
            ctx.primary_confluence_doc = confluence_key

    def _resolve_from_keywords(
        self, ctx: StoryContext, title: str, description: str, category: str
    ) -> None:
        """Fall back: resolve bounded context from keywords in title/description."""
        combined = f"{title} {description}".lower()

        # Score each bounded context by keyword overlap
        context_scores: dict[str, int] = {}
        keyword_map = {
            "core-agents": [
                "agent",
                "llm",
                "tool",
                "chat",
                "runtime",
                "invoke",
                "experience",
                "employee",
                "profile",
            ],
            "core-orchestration": [
                "workflow",
                "orchestrat",
                "executor",
                "scheduler",
                "trigger",
                "dag",
                "graph",
                "hitl",
                "node",
                "pipeline",
                "engine",
            ],
            "core-ani": [
                "ani",
                "a2a",
                "broker",
                "gateway",
                "handoff",
                "message",
                "routing",
                "discovery",
                "multi-agent",
                "protocol",
            ],
            "core-retrieval": [
                "rag",
                "retriev",
                "embed",
                "rerank",
                "vector",
                "chunk",
                "context",
                "semantic search",
            ],
            "core-security": [
                "crypto",
                "token",
                "password",
                "secret",
                "identity",
                "guard",
                "sentinel",
                "audit",
                "tls",
                "encrypt",
            ],
            "core-governance": [
                "rbac",
                "permission",
                "policy",
                "compliance",
                "authorization",
                "role",
            ],
            "core-observability": [
                "otel",
                "opentelemetry",
                "metric",
                "trac",
                "log",
                "span",
                "slo",
                "monitor",
            ],
            "core-nexus": [
                "nexus",
                "capability",
                "pii",
                "redact",
                "manifest",
                "telemetry",
                "resource registry",
            ],
            "core-connectors": [
                "connector",
                "http",
                "redis",
                "s3",
                "postgres",
                "external service",
            ],
            "core-workforce": [
                "workforce",
                "virtual employee",
                "party",
                "team",
                "organization",
                "assignment",
            ],
            "core-evaluation": ["evaluat", "benchmark", "quality", "scoring"],
            "core-models": [
                "model",
                "value object",
                "id",
                "result",
                "entity",
                "primitive",
                "type",
            ],
            "core-utils": [
                "util",
                "thread pool",
                "regex",
                "buffer",
                "clock",
                "serializ",
            ],
            "core-platform": ["platform", "memory policy", "arena", "config"],
        }

        for context_name, keywords in keyword_map.items():
            score = sum(1 for kw in keywords if kw in combined)
            # Title matches weighted 3x
            score += sum(2 for kw in keywords if kw in title.lower())
            if score > 0:
                context_scores[context_name] = score

        if context_scores:
            # Primary = highest score
            sorted_contexts = sorted(context_scores.items(), key=lambda x: x[1], reverse=True)
            ctx.primary_bounded_context = sorted_contexts[0][0]
            ctx.secondary_bounded_contexts = [c[0] for c in sorted_contexts[1:3]]

            # Override resolved_category based on bounded context mapping
            ctx.resolved_category = BOUNDED_CONTEXT_TO_CATEGORY.get(
                ctx.primary_bounded_context, ctx.resolved_category
            )

        # Populate from bounded context knowledge
        bc_info = self._bounded_contexts.get(ctx.primary_bounded_context, {})
        ctx.layer_placement = bc_info.get("layer", "Layer 3 (Domain Services)")

        ctx.existing_interfaces = [
            (iface, f"Existing in {ctx.primary_bounded_context}")
            for iface in bc_info.get("key_interfaces", [])
        ]

        ctx.key_value_objects = [
            (vo, f"Value object in {ctx.primary_bounded_context}")
            for vo in bc_info.get("key_value_objects", [])[:5]
        ]

        # Generate context-appropriate design patterns
        ctx.design_patterns = self._infer_patterns(category, ctx.primary_bounded_context)

    def _infer_patterns(self, category: str, bounded_context: str) -> list[str]:
        """Infer appropriate design patterns from category and bounded context."""
        _ = category  # Reserved for future category-specific pattern inference
        pattern_map = {
            "core-agents": [
                "Strategy (agent behavior)",
                "Decorator (middleware)",
                "Factory (agent creation)",
            ],
            "core-orchestration": [
                "State (workflow lifecycle)",
                "Command (task execution)",
                "Observer (event notification)",
            ],
            "core-ani": [
                "Mediator (message routing)",
                "Observer (event-driven)",
                "State (connection lifecycle)",
            ],
            "core-retrieval": [
                "Pipeline (RAG stages)",
                "Strategy (retrieval)",
                "Template Method (embedding)",
            ],
            "core-security": [
                "Proxy (access control)",
                "Chain of Responsibility (auth)",
                "Strategy (crypto algorithm)",
            ],
            "core-governance": [
                "Strategy (policy evaluation)",
                "Observer (audit events)",
                "Specification (permission rules)",
            ],
            "core-observability": [
                "Observer (metric emission)",
                "Decorator (auto-instrumentation)",
                "Strategy (aggregation)",
            ],
            "core-nexus": [
                "Registry (capability lookup)",
                "Proxy (guard enforcement)",
                "Adapter (tool normalization)",
            ],
        }
        default = [
            "Repository (data access)",
            "Factory (object creation)",
            "Strategy (algorithm selection)",
        ]
        return pattern_map.get(bounded_context, default)
