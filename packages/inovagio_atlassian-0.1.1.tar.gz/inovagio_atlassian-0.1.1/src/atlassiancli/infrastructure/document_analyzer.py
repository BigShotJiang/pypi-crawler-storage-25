#!/usr/bin/env python3
"""
Document Analyzer - SINGLE Analysis Implementation

ARCHITECTURE (SRP + DRY):
- ONE analyzer that works with any ImportedDocument
- Receives normalized content from any IDocumentImporter
- Extracts work items using a SINGLE algorithm
- NO source-specific logic (that's in the importers)

This is the ONLY place where analysis logic lives.
Adding a new source type = add an importer, NOT a new analyzer.

Author: Inovagio Engineering Team
"""

import re
from dataclasses import dataclass, field
from typing import Any

from ..domain.services import (
    DocumentAnalysisResult,
    IBoundedContextResolver,
    IDocumentAnalyzer,
    ImportedDocument,
    IPriorityCalculator,
    IThemeDetector,
    ParsedWorkItem,
)
from ..domain.value_objects import IssueType, Theme
from .story_domain_knowledge import BOUNDED_CONTEXT_MAP, StoryContextResolver

# Theme name constants (matches domain_services.py THEME_KEYWORDS keys)
THEME_ORCHESTRATION = "Orchestration"
THEME_SECURITY = "Security"
THEME_GOVERNANCE = "Governance"
THEME_CONNECTORS = "Connectors"
THEME_AI_AGENTS = "AI_Agents"
THEME_ANI = "ANI"
THEME_GENERAL = "General"


# ============================================================================
# ARCHITECTURAL COMPONENT (internal representation)
# ============================================================================


@dataclass
class ArchitecturalComponent:
    """
    Represents an architectural component found in documentation.

    Used internally during analysis; converted to ParsedWorkItem for output.
    """

    name: str
    component_type: str  # interface, service, gateway, orchestrator, etc.
    description: str = ""
    bounded_context: str = "core-models"
    patterns: list[str] = field(default_factory=list)
    responsibilities: list[str] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)
    source_section: str = ""


# ============================================================================
# UNIFIED DOCUMENT ANALYZER
# ============================================================================


class DocumentAnalyzer(IDocumentAnalyzer):
    """
    THE ONE analyzer that processes all document types.

    SOLID COMPLIANCE:
    - Single Responsibility: Only analyzes documents
    - Open/Closed: Works with any ImportedDocument (new importers don't change this)
    - Dependency Inversion: Uses injected services for theme/context detection

    DRY COMPLIANCE:
    - ONE implementation of analysis logic
    - Works with normalized ImportedDocument from ANY importer
    - No duplicate parsing code per source type

    USAGE:
        # Import from any source
        importer = MarkdownFileImporter()  # or ConfluencePageImporter, etc.
        document = importer.import_document(source)

        # Analyze with single analyzer
        analyzer = DocumentAnalyzer(theme_detector, context_resolver)
        result = analyzer.analyze(document)
    """

    def __init__(
        self,
        theme_detector: IThemeDetector | None = None,
        context_resolver: IBoundedContextResolver | None = None,
        priority_calculator: IPriorityCalculator | None = None,
    ):
        """
        Initialize with domain services.

        Args:
            theme_detector: Service for detecting themes from text
            context_resolver: Service for resolving bounded contexts
            priority_calculator: Service for calculating priority
        """
        self._theme_detector = theme_detector
        self._context_resolver = context_resolver
        self._priority_calculator = priority_calculator
        self._story_context_resolver = StoryContextResolver()

    def analyze(self, document: ImportedDocument) -> DocumentAnalysisResult:
        """
        Analyze an imported document and extract work items.

        This is the SINGLE analysis entry point for ALL document types.

        Args:
            document: Normalized ImportedDocument from any importer

        Returns:
            DocumentAnalysisResult with extracted work items
        """
        if not document.is_valid:
            return DocumentAnalysisResult(
                success=False,
                source=document.source,
                source_path=document.source_path,
                errors=document.import_errors,
            )

        try:
            # Extract work items from document
            work_items = self.extract_work_items(document)

            # Separate into epics, stories, tasks
            epics = [w for w in work_items if w.work_type == IssueType.EPIC]
            stories = [w for w in work_items if w.work_type == IssueType.STORY]
            tasks = [w for w in work_items if w.work_type == IssueType.TASK]

            # Find orphan stories (not linked to any epic)
            epic_titles = {e.title for e in epics}
            orphan_stories = [
                s for s in stories if not s.parent_epic or s.parent_epic not in epic_titles
            ]

            # Also analyze children if present
            pages_analyzed = 1
            for child in document.children:
                child_result = self.analyze(child)
                epics.extend(child_result.epics)
                stories.extend(child_result.stories)
                tasks.extend(child_result.tasks)
                orphan_stories.extend(child_result.orphan_stories)
                pages_analyzed += child_result.pages_analyzed

            return DocumentAnalysisResult(
                success=True,
                source=document.source,
                source_path=document.source_path,
                epics=epics,
                stories=stories,
                tasks=tasks,
                orphan_stories=orphan_stories,
                pages_analyzed=pages_analyzed,
                analysis_notes=[
                    f"Analyzed: {document.title}",
                    f"Sections: {len(document.sections)}",
                    f"Content format: {document.content_format}",
                ],
            )

        except Exception as e:
            return DocumentAnalysisResult(
                success=False,
                source=document.source,
                source_path=document.source_path,
                errors=[f"Analysis error: {e!s}"],
            )

    def extract_work_items(self, document: ImportedDocument) -> list[ParsedWorkItem]:
        """
        Extract work items from document content.

        Uses multiple extraction strategies:
        1. Work Order format (WO-XXX-NNN headers)
        2. Architectural components (interfaces, services, etc.)
        3. Standard markdown sections (## headers)

        Args:
            document: Normalized ImportedDocument

        Returns:
            List of ParsedWorkItem objects
        """
        work_items = []

        # Strategy 1: Try Work Order format
        wo_items = self._extract_work_orders(document)
        if wo_items:
            work_items.extend(wo_items)

        # Strategy 2: Extract architectural components
        arch_items = self._extract_from_architecture(document)
        if arch_items:
            work_items.extend(arch_items)

        # Strategy 3: Fallback to section-based extraction
        if not work_items:
            section_items = self._extract_from_sections(document)
            work_items.extend(section_items)

        return work_items

    def extract_architectural_components(self, document: ImportedDocument) -> list[dict[str, Any]]:
        """
        Extract architectural components from document.

        Args:
            document: Normalized ImportedDocument

        Returns:
            List of architectural component dictionaries
        """
        components = []
        content = document.content

        # Pattern 1: Interface definitions (IServiceName)
        interface_pattern = r"\b(I[A-Z][a-zA-Z]+(?:Service|Repository|Factory|Handler|Manager|Provider|Gateway|Adapter))\b"
        for match in re.finditer(interface_pattern, content):
            name = match.group(1)
            components.append(
                {
                    "name": name,
                    "type": "interface",
                    "context": self._infer_context_from_name(name),
                    "patterns": ["Interface Segregation"],
                }
            )

        # Pattern 2: Class/service mentions
        service_pattern = (
            r"\b([A-Z][a-zA-Z]+(?:Executor|Scheduler|Engine|Manager|Service|Handler))\b"
        )
        for match in re.finditer(service_pattern, content):
            name = match.group(1)
            if not name.startswith("I"):  # Not an interface
                components.append(
                    {
                        "name": name,
                        "type": "service",
                        "context": self._infer_context_from_name(name),
                        "patterns": ["Service"],
                    }
                )

        # Pattern 3: Gateway/Adapter mentions
        gateway_pattern = r"\b([A-Z][a-zA-Z]+(?:Gateway|Adapter|Connector|Bridge|Proxy))\b"
        for match in re.finditer(gateway_pattern, content):
            name = match.group(1)
            components.append(
                {
                    "name": name,
                    "type": "gateway",
                    "context": "core-connectors",
                    "patterns": ["Gateway", "Adapter"],
                }
            )

        # Deduplicate by name
        seen = set()
        unique_components = []
        for comp in components:
            if comp["name"] not in seen:
                seen.add(comp["name"])
                unique_components.append(comp)

        return unique_components

    # ========================================================================
    # PRIVATE EXTRACTION METHODS
    # ========================================================================

    def _extract_work_orders(self, document: ImportedDocument) -> list[ParsedWorkItem]:
        """Extract work items from Work Order format (WO-XXX-NNN)"""
        items = []
        content = document.content

        # Find Work Order headers: ### WO-ORCH-001: Title
        wo_pattern = r"^#{2,4}\s+(WO-[A-Z]+-\d+)[:\s]+(.+?)$"

        for match in re.finditer(wo_pattern, content, re.MULTILINE):
            wo_id = match.group(1)
            title = match.group(2).strip()

            # Get content after this header until next header
            start = match.end()
            next_header = re.search(r"^#{2,4}\s+", content[start:], re.MULTILINE)
            end = start + next_header.start() if next_header else len(content)
            section_content = content[start:end].strip()

            # Detect themes
            themes = self._detect_themes(f"{title} {section_content}")

            # Resolve bounded context
            context = self._resolve_context(themes)

            # Create epic for Work Order
            epic = ParsedWorkItem(
                title=f"[{wo_id}] {title}",
                description=section_content[:500],
                work_type=IssueType.EPIC,
                bounded_context=context,
                themes=[t.value if hasattr(t, "value") else str(t) for t in themes],
                labels=["work-order", wo_id.lower()],
                source_page=document.source_path,
            )

            # Extract stories from numbered items in section
            stories = self._extract_stories_from_content(section_content, epic.title, context)
            epic.children = stories

            items.append(epic)

        return items

    def _extract_from_architecture(self, document: ImportedDocument) -> list[ParsedWorkItem]:
        """Extract work items from architectural components"""
        items = []

        # Get architectural components
        components = self.extract_architectural_components(document)

        # Group by bounded context
        by_context: dict[str, list[dict]] = {}
        for comp in components:
            ctx = comp.get("context", "core-models")
            if ctx not in by_context:
                by_context[ctx] = []
            by_context[ctx].append(comp)

        # Create epic per context with component stories
        for context, context_components in by_context.items():
            if not context_components:
                continue

            # Create epic
            epic = ParsedWorkItem(
                title=f"[{context.upper()}] Architecture Implementation",
                description=f"Implement {len(context_components)} architectural components for {context}",
                work_type=IssueType.EPIC,
                bounded_context=context,
                labels=["architecture", "ddd", context.replace("core-", "")],
                acceptance_criteria=[
                    f"All {len(context_components)} components implemented",
                    ">85% unit test coverage",
                    "Integration tests passing",
                ],
                source_page=document.source_path,
            )

            # Create stories for each component
            for comp in context_components:
                story = self._create_story_for_component(comp, context)
                epic.children.append(story)

            items.append(epic)

        return items

    def _extract_from_sections(self, document: ImportedDocument) -> list[ParsedWorkItem]:
        """Extract work items from document sections (fallback)"""
        items = []

        for section in document.sections:
            title = section.get("title", "")
            content = section.get("content", "")
            level = int(section.get("level", 2))

            # Skip low-content sections
            if len(content) < 100:
                continue

            # Level 2 headers become epics, Level 3+ become stories
            themes = self._detect_themes(f"{title} {content}")
            context = self._resolve_context(themes)

            if level <= 2:
                item = ParsedWorkItem(
                    title=title,
                    description=content[:500],
                    work_type=IssueType.EPIC,
                    bounded_context=context,
                    themes=[t.value if hasattr(t, "value") else str(t) for t in themes],
                    source_page=document.source_path,
                )
            else:
                item = ParsedWorkItem(
                    title=title,
                    description=content[:300],
                    work_type=IssueType.STORY,
                    bounded_context=context,
                    themes=[t.value if hasattr(t, "value") else str(t) for t in themes],
                    source_page=document.source_path,
                )

            items.append(item)

        return items

    def _extract_stories_from_content(
        self, content: str, parent_epic: str, context: str
    ) -> list[ParsedWorkItem]:
        """Extract stories from numbered/bulleted items in content"""
        stories = []

        # Pattern for numbered items: 1. Title or #### 1. Title
        numbered_pattern = r"^(?:#{3,4}\s+)?(\d+)\.\s+(.+?)(?:\n|$)"

        for match in re.finditer(numbered_pattern, content, re.MULTILINE):
            _ = match.group(1)
            title = match.group(2).strip()

            # Get description from following content
            start = match.end()
            next_item = re.search(r"^(?:#{3,4}\s+)?\d+\.", content[start:], re.MULTILINE)
            end = start + next_item.start() if next_item else min(start + 500, len(content))
            description = content[start:end].strip()

            story = ParsedWorkItem(
                title=title,
                description=description[:300],
                work_type=IssueType.STORY,
                bounded_context=context,
                parent_epic=parent_epic,
                story_points=self._estimate_points(description),
            )
            stories.append(story)

        return stories

    def _create_story_for_component(
        self, component: dict[str, Any], context: str
    ) -> ParsedWorkItem:
        """Create a story for an architectural component.

        Uses StoryContextResolver for technology-aware acceptance criteria
        and design patterns instead of generic boilerplate.
        """
        comp_type = component.get("type", "component")
        name = component.get("name", "Unknown")

        # Resolve story-specific context using domain knowledge base
        story_ctx = self._story_context_resolver.resolve(name, f"{comp_type} for {context}")

        # Use resolved bounded context if more specific than the caller's
        resolved_context = (
            story_ctx.primary_bounded_context
            if story_ctx.primary_bounded_context != "core-models"
            else context
        )

        # Look up bounded context details from knowledge base
        bc_info = BOUNDED_CONTEXT_MAP.get(resolved_context, {})
        layer = bc_info.get("layer", "Layer 3")
        bc_desc = bc_info.get("description", resolved_context)

        # Generate appropriate story based on component type with domain-specific criteria
        if comp_type == "interface":
            title = f"Define {name} Interface"
            acceptance_criteria = [
                f"Pure virtual interface defined in {resolved_context}/include/{name.lower()}.hpp",
                "No implementation dependencies — header-only contract",
                f"Follows ISP (Interface Segregation) — focused on {bc_desc}",
                "Documented with Doxygen: purpose, thread-safety, ownership semantics",
                "Unit tests verify interface contract with mock implementations",
                "[[nodiscard]] on all query methods per project standards",
            ]
            points = 3
        elif comp_type == "gateway":
            title = f"Integrate {name} Protocol"
            acceptance_criteria = [
                f"Protocol adapter implements {resolved_context} gateway interface",
                "Message serialization/deserialization with type-safe Result<T,E>",
                "Error handling: network failures, timeouts, malformed responses",
                "Circuit breaker pattern for fault tolerance",
                "Integration tests with mock server (>85% coverage)",
                "Structured logging via IAuditLogger for all protocol exchanges",
            ]
            points = 8
        else:
            title = f"Implement {name}"
            # Use story-specific patterns if available
            patterns_note = ""
            if story_ctx.design_patterns:
                patterns_note = f" using {story_ctx.design_patterns[0]}"

            acceptance_criteria = [
                f"Implements interface contract in {resolved_context} ({layer})",
                f"SOLID: SRP (single reason to change), DIP (injected dependencies){patterns_note}",
                "Error handling with Result<T,E> — no exceptions",
                "Unit tests with >85% coverage using Google Test + GMock",
                "RAII for all resources, std::make_unique/make_shared only",
                f"Integrates with {resolved_context} bounded context invariants",
            ]
            points = 5

        # Add existing interface references from knowledge base
        existing_refs = []
        if story_ctx.existing_interfaces:
            for iface_name, iface_desc in story_ctx.existing_interfaces[:2]:
                existing_refs.append(f"Extends/uses existing {iface_name}: {iface_desc}")

        description_parts = [
            f"Implement {name} for the {resolved_context} bounded context.",
            f"\n**Layer**: {layer}",
            f"**Bounded Context**: {bc_desc}",
        ]
        if existing_refs:
            description_parts.append("\n**Related Interfaces**:")
            description_parts.extend(f"- {ref}" for ref in existing_refs)
        if story_ctx.design_patterns:
            description_parts.append(
                f"\n**Design Patterns**: {', '.join(story_ctx.design_patterns[:3])}"
            )

        # Add labels based on resolved context
        labels = ["architecture", comp_type]
        if resolved_context.startswith("core-"):
            labels.append(resolved_context.replace("core-", ""))

        return ParsedWorkItem(
            title=title,
            description="\n".join(description_parts),
            work_type=IssueType.STORY,
            bounded_context=resolved_context,
            acceptance_criteria=acceptance_criteria,
            story_points=points,
            labels=labels,
            source_component=name,
        )

    # ========================================================================
    # HELPER METHODS
    # ========================================================================

    def _detect_themes(self, text: str) -> list[Theme]:
        """Detect themes from text using injected service or fallback"""
        if self._theme_detector:
            return self._theme_detector.detect_themes(text)

        # Fallback: basic keyword detection (returns Theme dataclass instances)
        themes = []
        text_lower = text.lower()

        theme_keywords = {
            THEME_ORCHESTRATION: [
                "workflow",
                "orchestrat",
                "dag",
                "execution",
                "scheduler",
            ],
            THEME_GOVERNANCE: [
                "security",
                "auth",
                "rbac",
                "encrypt",
                "credential",
                "governance",
                "compliance",
                "audit",
                "policy",
            ],
            THEME_CONNECTORS: ["connector", "integration", "api", "adapter", "gateway"],
            THEME_AI_AGENTS: ["agent", "llm", "ai", "model", "inference"],
            THEME_ANI: ["ani", "network", "protocol", "message", "communication"],
        }

        for theme_name, keywords in theme_keywords.items():
            if any(kw in text_lower for kw in keywords):
                themes.append(Theme(name=theme_name))

        return themes if themes else [Theme(name=THEME_GENERAL)]

    def _resolve_context(self, themes: list[Theme]) -> str:
        """Resolve bounded context from themes"""
        if self._context_resolver:
            context = self._context_resolver.resolve_context(themes)
            return context.name if hasattr(context, "name") else str(context)

        # Fallback: basic mapping
        theme_to_context = {
            THEME_ORCHESTRATION: "core-orchestration",
            THEME_GOVERNANCE: "core-governance",
            THEME_CONNECTORS: "core-connectors",
            THEME_AI_AGENTS: "core-agents",
            THEME_ANI: "core-ani",
        }

        for theme in themes:
            theme_name = theme.name if isinstance(theme, Theme) else str(theme)
            if theme_name in theme_to_context:
                return theme_to_context[theme_name]

        return "core-models"

    def _infer_context_from_name(self, name: str) -> str:
        """Infer bounded context from component name using StoryContextResolver.

        Uses the same domain knowledge base as the enhancement pipeline to ensure
        consistent bounded context resolution across import and enhance flows.
        """
        # Use StoryContextResolver for technology-aware resolution
        story_ctx = self._story_context_resolver.resolve(name, "")
        if story_ctx.primary_bounded_context != "core-models":
            return story_ctx.primary_bounded_context

        # Fallback: keyword-based inference for generic component names
        name_lower = name.lower()

        context_keywords = {
            "core-orchestration": [
                "workflow",
                "executor",
                "scheduler",
                "orchestrat",
                "superstep",
                "bsp",
                "fan-out",
                "fan-in",
                "dag",
                "pipeline",
                "engine",
            ],
            "core-governance": [
                "auth",
                "guard",
                "policy",
                "governance",
                "rbac",
                "sentinel",
                "compliance",
                "audit",
                "permission",
            ],
            "core-connectors": [
                "connector",
                "gateway",
                "adapter",
                "mcp",
                "bridge",
                "integration",
            ],
            "core-agents": [
                "agent",
                "llm",
                "model",
                "tool",
                "chat",
                "invoke",
                "context_provider",
                "structured_output",
                "stream",
            ],
            "core-ani": [
                "ani",
                "network",
                "protocol",
                "message",
                "broker",
                "handoff",
                "a2a",
                "routing",
            ],
            "core-persistence": ["repository", "persist", "storage", "database"],
            "core-retrieval": ["rag", "retriev", "embed", "vector", "search"],
            "core-observability": [
                "otel",
                "trac",
                "metric",
                "observ",
                "telemetry",
                "instrument",
            ],
            "core-security": [
                "crypto",
                "encrypt",
                "token",
                "secret",
                "password",
                "tls",
            ],
        }

        for context_name, keywords in context_keywords.items():
            if any(kw in name_lower for kw in keywords):
                return context_name

        return "core-models"

    def _estimate_points(self, description: str) -> int:
        """Estimate story points from description complexity"""
        word_count = len(description.split())

        if word_count < 50:
            return 2
        elif word_count < 150:
            return 3
        elif word_count < 300:
            return 5
        else:
            return 8
