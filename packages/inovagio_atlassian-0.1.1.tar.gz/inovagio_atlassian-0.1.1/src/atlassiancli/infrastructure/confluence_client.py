#!/usr/bin/env python3
"""
Confluence API Client and Repository Implementation

Author: Inovagio Engineering Team
"""

from collections.abc import Callable
from typing import Any

from atlassiancli.infrastructure.http_client import HttpClient, HttpError

from ..domain.repositories import ConfluencePage, IConfluenceRepository
from ..domain.value_objects import ConfluencePageId, IssueKey
from .config import AtlassianConfig


class ConfluenceApiError(Exception):
    """Confluence API error"""


class _AdaptedResponse:
    """``requests.Response``-compatible facade over our typed-error stdlib client.

    Mirrors the helper in :mod:`jira_client` — preserves the legacy
    ``status_code`` / ``text`` / ``json()`` surface so all post-call
    inspection in ``ConfluencePageRepository`` works unchanged after the
    surgical swap from :mod:`requests` to :class:`HttpClient`.
    """

    __slots__ = ("_body_bytes", "headers", "status_code")

    def __init__(self, status_code: int, body_bytes: bytes, headers: dict[str, str]):
        self.status_code = status_code
        self._body_bytes = body_bytes
        self.headers = headers

    @property
    def text(self) -> str:
        return self._body_bytes.decode("utf-8", errors="replace")

    def json(self) -> Any:
        import json as _json  # local import: keeps top-level imports stdlib-clean

        return _json.loads(self._body_bytes.decode("utf-8"))


def _adapt(call: Callable[[], Any]) -> _AdaptedResponse:
    """Run an :class:`HttpClient` method and return a response-shaped facade.

    Catches :class:`HttpError` so the legacy "inspect status_code" idiom in
    every Confluence method works identically; preserves the body / headers
    on errors so diagnostics are not lost.
    """
    try:
        result = call()
    except HttpError as exc:
        return _AdaptedResponse(
            status_code=exc.status if exc.status is not None else 0,
            body_bytes=exc.body,
            headers=dict(exc.headers),
        )
    return _AdaptedResponse(
        status_code=result.status,
        body_bytes=result.body_bytes,
        headers=dict(result.headers),
    )


class ConfluenceApiClient:
    """Low-level Confluence REST API client"""

    def __init__(self, config: AtlassianConfig):
        self.config = config
        self.base_url = config.base_url
        self.headers = {"Accept": "application/json", "Content-Type": "application/json"}
        self._http = HttpClient(
            base_url=config.base_url,
            auth=(config.user_email, config.api_token),
            default_headers=self.headers,
            timeout_seconds=30.0,
        )

    def post(self, endpoint: str, data: dict[str, Any]) -> _AdaptedResponse:
        """POST request"""
        return _adapt(lambda: self._http.post(endpoint, json=data))

    def get(self, endpoint: str, params: dict[str, Any] | None = None) -> _AdaptedResponse:
        """GET request"""
        return _adapt(lambda: self._http.get(endpoint, params=params))

    def put(self, endpoint: str, data: dict[str, Any]) -> _AdaptedResponse:
        """PUT request"""
        return _adapt(lambda: self._http.put(endpoint, json=data))


class ConfluencePageRepository(IConfluenceRepository):
    """Concrete implementation of IConfluenceRepository"""

    def __init__(self, api_client: ConfluenceApiClient):
        self._api = api_client
        self._config = api_client.config

    def create_page(
        self,
        space_key: str,
        title: str,
        content: str,
        parent_page_id: ConfluencePageId | None = None,
    ) -> ConfluencePageId:
        """Create Confluence page"""
        payload: dict[str, Any] = {
            "type": "page",
            "title": title,
            "space": {"key": space_key},
            "body": {"storage": {"value": content, "representation": "storage"}},
        }

        if parent_page_id:
            payload["ancestors"] = [{"id": parent_page_id.page_id}]

        response = self._api.post("/wiki/rest/api/content", payload)

        if response.status_code not in [200, 201]:
            raise ConfluenceApiError(
                f"Failed to create page: {response.status_code} - {response.text}"
            )

        result = response.json()
        page_id = result.get("id")

        if not page_id:
            raise ConfluenceApiError("No page ID in response")

        return ConfluencePageId(page_id)

    def find_page_by_title(self, space_key: str, title: str) -> ConfluencePageId | None:
        """Find page by exact title"""
        params = {"spaceKey": space_key, "title": title, "expand": "version"}

        response = self._api.get("/wiki/rest/api/content", params)

        if response.status_code != 200:
            return None

        result = response.json()
        results = result.get("results", [])

        if not results:
            return None

        page_id = results[0].get("id")
        return ConfluencePageId(page_id) if page_id else None

    def update_page(
        self,
        page_id: ConfluencePageId,
        title: str,
        content: str,
        parent_page_id: ConfluencePageId | None = None,
    ) -> bool:
        """Update existing page (optionally with new parent to move it)"""
        # Get current version first
        response = self._api.get(f"/wiki/rest/api/content/{page_id.page_id}")

        if response.status_code != 200:
            return False

        current = response.json()
        current_version = current.get("version", {}).get("number", 1)

        # Update with incremented version
        payload: dict[str, Any] = {
            "version": {"number": current_version + 1},
            "title": title,
            "type": "page",
            "body": {"storage": {"value": content, "representation": "storage"}},
        }

        # Add parent (ancestors) to move the page
        if parent_page_id:
            payload["ancestors"] = [{"id": parent_page_id.page_id}]

        update_response = self._api.put(f"/wiki/rest/api/content/{page_id.page_id}", payload)

        return update_response.status_code in [200, 204]

    def move_page(self, page_id: ConfluencePageId, new_parent_id: ConfluencePageId) -> bool:
        """Move page to new parent"""
        # Get current page details
        response = self._api.get(
            f"/wiki/rest/api/content/{page_id.page_id}?expand=body.storage,version"
        )

        if response.status_code != 200:
            return False

        current = response.json()
        title = current.get("title", "")
        content = current.get("body", {}).get("storage", {}).get("value", "")

        # Update with new parent
        return self.update_page(page_id, title, content, new_parent_id)

    def get_page_url(self, page_id: ConfluencePageId) -> str:
        """Get page URL"""
        space = self._config.confluence_space
        return f"{self._config.base_url}/wiki/spaces/{space}/pages/{page_id.page_id}"

    def add_remote_link_to_jira(self, issue_key: IssueKey, page_url: str, link_title: str) -> bool:
        """Add remote link from Jira to Confluence"""
        payload = {"object": {"url": page_url, "title": link_title}}

        response = self._api.post(f"/rest/api/3/issue/{issue_key.key}/remotelink", payload)

        return response.status_code in [200, 201]

    def get_page(self, page_id: ConfluencePageId) -> ConfluencePage | None:
        """
        Get a page with its content.

        Args:
            page_id: Page to retrieve

        Returns:
            ConfluencePage with title, content, and metadata or None if not found
        """
        endpoint = f"/wiki/rest/api/content/{page_id.page_id}"
        params = {"expand": "body.storage,version,space"}

        response = self._api.get(endpoint, params)

        if response.status_code != 200:
            return None

        data = response.json()

        return ConfluencePage(
            page_id=page_id,
            title=data.get("title", ""),
            content=data.get("body", {}).get("storage", {}).get("value", ""),
            space_key=data.get("space", {}).get("key", ""),
            version=data.get("version", {}).get("number", 1),
        )

    def get_child_pages(self, parent_id: ConfluencePageId) -> list[ConfluencePage]:
        """
        Get all child pages of a parent page.

        Args:
            parent_id: Parent page ID

        Returns:
            List of child pages with their content
        """
        endpoint = f"/wiki/rest/api/content/{parent_id.page_id}/child/page"
        params = {
            "expand": "body.storage,version,space",
            "limit": 100,  # Confluence default is 25, increase for larger doc trees
        }

        response = self._api.get(endpoint, params)

        if response.status_code != 200:
            return []

        data = response.json()
        results = data.get("results", [])

        children = []
        for page_data in results:
            child = ConfluencePage(
                page_id=ConfluencePageId(page_data.get("id", "")),
                title=page_data.get("title", ""),
                content=page_data.get("body", {}).get("storage", {}).get("value", ""),
                space_key=page_data.get("space", {}).get("key", ""),
                version=page_data.get("version", {}).get("number", 1),
            )
            children.append(child)

        return children

    def find_or_create_parent_page(
        self,
        space_key: str,
        parent_title: str,
        parent_content: str = "",
        under_parent_id: ConfluencePageId | None = None,
    ) -> ConfluencePageId:
        """
        Find or create organizational parent page.

        Args:
            space_key: Confluence space key
            parent_title: Title of the parent page
            parent_content: Content for the parent page (if creating)
            under_parent_id: Optional parent page to nest under

        Returns:
            ConfluencePageId of the parent page
        """
        # Try to find existing parent
        existing = self.find_page_by_title(space_key, parent_title)

        if existing:
            return existing

        # Create parent page with default content
        if not parent_content:
            parent_content = f"""
<h2>Overview</h2>
<p>This page organizes documentation for stories in the {space_key} project.</p>
<p>Documentation is automatically generated and organized by issue key.</p>
"""

        return self.create_page(
            space_key, parent_title, parent_content, parent_page_id=under_parent_id
        )
