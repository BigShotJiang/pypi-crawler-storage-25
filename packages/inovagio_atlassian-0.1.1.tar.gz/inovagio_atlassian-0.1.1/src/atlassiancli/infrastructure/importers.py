#!/usr/bin/env python3
"""
Atlassian CLI v3 - Markdown Document Analyzer

REFACTORED FOR DDD/SOLID COMPLIANCE:
- Implements IDocumentAnalyzer interface (Interface Segregation)
- Uses domain value objects (DRY - no duplicate types)
- Receives IThemeDetector via DI (Dependency Inversion)
- Single responsibility: Parse markdown files

Author: Inovagio Engineering Team
"""

import re
from pathlib import Path
from typing import Any

from ..domain.services import (
    DocumentAnalysisResult,
    DocumentSource,
    IDocumentAnalyzer,
    ImportedDocument,
    IThemeDetector,
    ParsedWorkItem,
)
from ..domain.value_objects import IssueType

# ============================================================================
# MARKDOWN DOCUMENT ANALYZER - Implements IDocumentAnalyzer
# ============================================================================


class MarkdownDocumentAnalyzer(IDocumentAnalyzer):
    """
    Concrete implementation of IDocumentAnalyzer for markdown files.

    SOLID COMPLIANCE:
    - Single Responsibility: Only parses markdown files
    - Open/Closed: Extends IDocumentAnalyzer without modification
    - Dependency Inversion: Depends on IThemeDetector abstraction

    DRY COMPLIANCE:
    - Uses unified ParsedWorkItem (no local dataclasses)
    - Uses IThemeDetector service (no local detect_themes())
    - Uses domain IssueType enum (no local enum)
    """

    def __init__(self, theme_detector: IThemeDetector | None = None):
        """
        Initialize with optional theme detector.

        Args:
            theme_detector: Optional IThemeDetector service. If not provided,
                           uses fallback detection (for backward compatibility).
        """
        self._theme_detector = theme_detector

    def analyze(
        self,
        document: Any,
        include_children: bool = False,  # pylint: disable=unused-argument
        **kwargs,  # pylint: disable=unused-argument
    ) -> DocumentAnalysisResult:
        """
        Analyze a markdown file and extract work items.

        Args:
            document: ImportedDocument or file path string
            include_children: Not used for markdown (no hierarchy)
            **kwargs: Additional options (not used currently)

        Returns:
            DocumentAnalysisResult with extracted work items
        """
        try:
            if isinstance(document, str):
                source = document
                path = Path(source)
                if not path.exists():
                    return DocumentAnalysisResult(
                        success=False,
                        source=DocumentSource.MARKDOWN_FILE,
                        source_path=source,
                        errors=[f"File not found: {source}"],
                    )
                content = path.read_text(encoding="utf-8")
            else:
                source = document.source_path
                content = document.content

            # Try intelligent parsing first (Work Orders)
            result = self._parse_with_work_orders(content, source)
            if result.total_epics > 0:
                return result

            # Fallback to standard markdown parsing
            return self._parse_standard_markdown(content, source)

        except Exception as e:
            source = (
                document
                if isinstance(document, str)
                else getattr(document, "source_path", "unknown")
            )
            return DocumentAnalysisResult(
                success=False,
                source=DocumentSource.MARKDOWN_FILE,
                source_path=source,
                errors=[f"Parse error: {e!s}"],
            )

    def extract_work_items(self, document: ImportedDocument) -> list[ParsedWorkItem]:
        """Extract work items (implemented via analyze for backward compat)"""
        result = self.analyze(document)
        items = []
        items.extend(result.epics)
        for epic in result.epics:
            items.extend(epic.children)
        items.extend(result.orphan_stories)
        return items

    def extract_architectural_components(self, document: ImportedDocument) -> list[dict[str, Any]]:
        """Extract architectural components (not implemented for legacy analyzer)"""
        return []

    def get_source_type(self) -> DocumentSource:
        """Return markdown file source type."""
        return DocumentSource.MARKDOWN_FILE

    def supports_source(self, source: str) -> bool:
        """
        Check if this analyzer supports the given source.

        Supports .md, .markdown files and plain text that looks like markdown.
        """
        if not source:
            return False

        # File path check
        path = Path(source)
        if path.suffix.lower() in (".md", ".markdown", ".txt"):
            return True

        # Check if it's a local file path (not URL/Confluence ID)
        if source.isdigit():  # Confluence page ID
            return False
        if source.startswith(("http://", "https://")):
            return False

        return path.exists() and path.is_file()

    def _detect_themes(self, text: str) -> list[str]:
        """
        Detect themes using injected service or fallback.

        DRY: Delegates to IThemeDetector when available.
        """
        if self._theme_detector:
            themes = self._theme_detector.detect_themes(text)
            return [t.name for t in themes]

        # Fallback: simple keyword detection (for backward compatibility)
        fallback_themes = []
        text_lower = text.lower()

        theme_keywords = {
            "Orchestration": ["orchestration", "workflow", "execution", "scheduler", "runtime"],
            "Agents": ["agent", "llm", "model", "ai"],
            "Governance": ["governance", "rbac", "audit", "compliance", "permission"],
            "ANI": ["ani", "agent network", "multi-agent", "communication"],
            "Connectors": ["connector", "integration", "external", "api"],
            "Persistence": ["persistence", "database", "storage", "repository"],
            "Analytics": ["analytics", "metrics", "monitoring", "observability"],
            "Security": ["security", "encryption", "authentication", "authorization"],
        }

        for theme, keywords in theme_keywords.items():
            if any(kw in text_lower for kw in keywords):
                fallback_themes.append(theme)

        return fallback_themes if fallback_themes else ["General"]

    def _parse_with_work_orders(self, content: str, source_path: str) -> DocumentAnalysisResult:
        """
        Parse document looking for Work Order patterns (WO-XXX-NNN).

        Work Orders map to Epics, Features map to Stories.
        """
        result = DocumentAnalysisResult(
            success=True,
            source=DocumentSource.MARKDOWN_FILE,
            source_path=source_path,
        )

        work_orders = self._extract_work_orders(content)

        if not work_orders:
            return result  # Empty result, will fallback to standard parsing

        for wo in work_orders:
            themes = self._detect_themes(wo["title"])

            # Create Epic for Work Order
            epic = ParsedWorkItem(
                title=wo["title"],
                description=wo.get("description", ""),
                work_type=IssueType.EPIC,
                priority=wo.get("priority", "Medium"),
                themes=themes,
                labels=[wo["id"].lower().replace("-", "")],
            )

            # Convert features to Stories (as children)
            for feature in wo.get("features", []):
                story = ParsedWorkItem(
                    title=feature["title"],
                    description=feature.get("description", ""),
                    work_type=IssueType.STORY,
                    acceptance_criteria=feature.get("acceptance_criteria", []),
                    themes=themes,
                    priority=wo.get("priority", "Medium"),
                    labels=[wo["id"].lower().replace("-", "")],
                )
                epic.children.append(story)

            # If no features, create default story
            if not epic.children:
                epic.children.append(
                    ParsedWorkItem(
                        title=f"Implement {wo['title']}",
                        description=wo.get("description", "")[:300],
                        work_type=IssueType.STORY,
                        themes=themes,
                        priority=wo.get("priority", "Medium"),
                        labels=[wo["id"].lower().replace("-", "")],
                    )
                )

            result.epics.append(epic)

        result.analysis_notes.append(f"Parsed {len(work_orders)} Work Orders")
        return result

    def _extract_work_orders(self, content: str) -> list[dict]:
        """
        Extract Work Orders from structured document.

        Looks for patterns like:
        - # WO-ORCH-001: Workflow Engine Core
        - ## WO-ANI-002: Agent Communication
        """
        work_orders = []
        lines = content.split("\n")

        current_wo: dict | None = None
        current_feature: dict | None = None
        buffer: list[str] = []
        in_acceptance_criteria = False

        for line in lines:
            # Match Work Order headings
            wo_match = re.match(r"^#{1,4}\s+(WO-[A-Z]+-\d+)[:\s]*(.*)$", line, re.IGNORECASE)
            if wo_match:
                if current_wo:
                    work_orders.append(current_wo)

                wo_id = wo_match.group(1).upper()
                wo_title = wo_match.group(2).strip() or "Untitled Work Order"
                current_wo = {
                    "id": wo_id,
                    "title": wo_title,
                    "description": "",
                    "priority": "Medium",
                    "features": [],
                }
                buffer = []
                current_feature = None
                in_acceptance_criteria = False
                continue

            if not current_wo:
                continue

            # Match feature/story headings
            feature_match = re.match(r"^##\s+(?:Feature|Story)[:\s]*(.+)$", line, re.IGNORECASE)
            if feature_match:
                if current_feature and buffer:
                    current_feature["description"] = "\n".join(buffer).strip()

                current_feature = {
                    "title": feature_match.group(1).strip(),
                    "description": "",
                    "acceptance_criteria": [],
                }
                current_wo["features"].append(current_feature)
                buffer = []
                in_acceptance_criteria = False
                continue

            # Match acceptance criteria section
            ac_match = re.match(r"^###\s+Acceptance\s+Criteria", line, re.IGNORECASE)
            if ac_match:
                if current_feature and buffer:
                    current_feature["description"] = "\n".join(buffer).strip()
                buffer = []
                in_acceptance_criteria = True
                continue

            # Extract acceptance criteria items
            if in_acceptance_criteria and current_feature:
                criteria_match = re.match(r"^\s*[-*]\s*\[[ x]?\]\s*(.+)", line, re.IGNORECASE)
                if criteria_match:
                    current_feature["acceptance_criteria"].append(criteria_match.group(1).strip())
                    continue
                bullet_match = re.match(r"^\s*[-*]\s+(.+)", line)
                if bullet_match:
                    current_feature["acceptance_criteria"].append(bullet_match.group(1).strip())
                    continue

            if line.strip():
                buffer.append(line)

        # Save last work order
        if current_wo:
            if current_feature and buffer:
                current_feature["description"] = "\n".join(buffer).strip()
            if buffer and not current_wo["features"]:
                current_wo["description"] = "\n".join(buffer).strip()
            work_orders.append(current_wo)

        return work_orders

    def _parse_standard_markdown(self, content: str, source_path: str) -> DocumentAnalysisResult:
        """
        Parse standard markdown with H1=Epic, H2=Story pattern.

        Hierarchy:
        - # or #### WO-XXX-NNN → Epic (Work Order)
        - # → Epic (fallback)
        - ## Feature/Story → Story
        - ### Acceptance Criteria → Extract criteria
        """
        result = DocumentAnalysisResult(
            success=True,
            source=DocumentSource.MARKDOWN_FILE,
            source_path=source_path,
        )

        lines = content.split("\n")
        current_epic: ParsedWorkItem | None = None
        current_story: ParsedWorkItem | None = None
        current_section: str | None = None
        buffer: list[str] = []

        def flush_buffer():
            nonlocal buffer, current_epic, current_story, current_section
            if not buffer:
                return
            text = "\n".join(buffer).strip()
            buffer = []

            if current_section == "acceptance_criteria":
                criteria = re.findall(r"[-*]\s*\[[ x]?\]\s*(.+)", text, re.IGNORECASE)
                if not criteria:
                    criteria = re.findall(r"[-*]\s+(.+)", text)
                if current_story:
                    current_story.acceptance_criteria.extend(criteria)
            elif current_section == "description":
                if current_story:
                    current_story.description = text
                elif current_epic:
                    current_epic.description = text

        for line in lines:
            # Work Orders (WO-*) = Epic
            work_order_match = re.match(r"^#{1,4}\s+(WO-[A-Z]+-\d+[:\s]*.*?)$", line, re.IGNORECASE)
            if work_order_match:
                flush_buffer()
                title = work_order_match.group(1).strip()
                current_epic = ParsedWorkItem(
                    title=title,
                    work_type=IssueType.EPIC,
                    themes=self._detect_themes(title),
                )
                result.epics.append(current_epic)
                current_story = None
                current_section = "description"
                continue

            # H1 = Epic (fallback)
            epic_match = re.match(r"^#\s+(?:Epic[:\s]*)?(.+)$", line, re.IGNORECASE)
            if epic_match and not work_order_match:
                flush_buffer()
                title = epic_match.group(1).strip()
                current_epic = ParsedWorkItem(
                    title=title,
                    work_type=IssueType.EPIC,
                    themes=self._detect_themes(title),
                )
                result.epics.append(current_epic)
                current_story = None
                current_section = "description"
                continue

            # H2 = Story
            story_match = re.match(r"^##\s+(?:Story|Feature)[:\s]*(.+)$", line, re.IGNORECASE)
            if story_match:
                flush_buffer()
                title = story_match.group(1).strip()
                current_story = ParsedWorkItem(
                    title=title,
                    work_type=IssueType.STORY,
                    themes=self._detect_themes(title),
                )
                if current_epic:
                    current_epic.children.append(current_story)
                else:
                    result.orphan_stories.append(current_story)
                current_section = "description"
                continue

            # H3 = Acceptance Criteria
            if re.match(r"^###\s+Acceptance\s+Criteria", line, re.IGNORECASE):
                flush_buffer()
                current_section = "acceptance_criteria"
                continue

            if line.strip().startswith(("-", "*", "[ ]", "[x]")):
                buffer.append(line)
                continue

            buffer.append(line)

        flush_buffer()

        result.analysis_notes.append(
            f"Parsed {len(result.epics)} epics, {len(result.orphan_stories)} orphan stories"
        )
        return result


# ============================================================================
# BACKWARD COMPATIBILITY - Legacy function wrappers
# ============================================================================

# Singleton analyzer for backward compatibility
_default_analyzer: MarkdownDocumentAnalyzer | None = None


def _get_default_analyzer() -> MarkdownDocumentAnalyzer:
    """Get or create default analyzer (singleton for backward compat)."""
    global _default_analyzer  # pylint: disable=global-statement
    if _default_analyzer is None:
        _default_analyzer = MarkdownDocumentAnalyzer()
    return _default_analyzer


def parse_requirements_document(file_path: str) -> DocumentAnalysisResult:
    """
    Main entry point: parse any requirements document.

    BACKWARD COMPATIBLE: Returns DocumentAnalysisResult (use .epics, .stories, etc.)
    """
    analyzer = _get_default_analyzer()
    return analyzer.analyze(file_path)


def detect_themes(text: str) -> list[str]:
    """
    Detect architectural themes from text.

    BACKWARD COMPATIBLE: Delegates to analyzer's theme detection.
    """
    analyzer = _get_default_analyzer()
    return analyzer._detect_themes(text)


# ============================================================================
# LEGACY TYPE ALIASES (for gradual migration)
# ============================================================================

# These map old types to new domain types for backward compatibility
# Import these from domain instead:
#   from ..domain.value_objects import IssueType
#   from ..domain.services import ParsedWorkItem, DocumentAnalysisResult

# Legacy aliases (deprecated - will be removed in next version)
ParsedRequirement = ParsedWorkItem  # Use ParsedWorkItem instead
ImportPlan = DocumentAnalysisResult  # Use DocumentAnalysisResult instead
