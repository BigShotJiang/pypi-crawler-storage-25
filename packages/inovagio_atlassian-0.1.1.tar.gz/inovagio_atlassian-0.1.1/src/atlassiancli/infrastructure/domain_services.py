#!/usr/bin/env python3
"""
Domain Service Implementations

Concrete implementations of domain service interfaces.
SINGLE SOURCE OF TRUTH for theme detection, context resolution, etc.

Author: Inovagio Engineering Team
"""

import re

from ..domain.services import (
    IBoundedContextResolver,
    IComponentDeriver,
    ILabelDeriver,
    IPriorityCalculator,
    IStoryPointEstimator,
    IThemeDetector,
)
from ..domain.value_objects import BOUNDED_CONTEXT_CATALOG, BoundedContext, Theme

# THEME KEYWORDS - Single Source of Truth
THEME_KEYWORDS: dict[str, list[str]] = {
    "ANI": [
        "ani",
        "ani-",
        "ani]",
        "agent network interface",
        "anibroker",
        "ani broker",
        "multi-agent",
        "agent-to-agent",
        "a2a gateway",
        "mcp gateway",
    ],
    "Orchestration": [
        "orchestration",
        "wo-",
        "workflow orchestrat",
        "iexecutor",
        "ischeduler",
        "hybrid workflow",
        "execution engine",
        "task graph",
    ],
    "Governance": [
        "governance",
        "gov",
        "rbac",
        "guard",
        "sentinel",
        "policy engine",
        "compliance",
        "audit",
        "permission",
    ],
    "Connectors": [
        "connectors",
        "conn",
        "connector",
        "nexus",
        "iconnector",
        "external system",
        "integration adapter",
    ],
    "Flow": ["flow", "inovagio flow", "flow-", "native bridge", "electron", "n-api"],
    "Origin": ["origin", "model factory", "inovagio origin", "llm provider"],
    "Insights": ["insights", "analytics", "dashboard", "inovagio insights"],
    "Edge": ["edge", "air-gapped", "on-premise", "inovagio edge"],
    "Infrastructure": ["infrastructure", "devops", "kubernetes", "docker", "ci/cd"],
    "Testing": ["testing", "test", "fuzzing", "benchmark"],
}

# THEME TO LABEL MAPPING
THEME_TO_LABELS: dict[str, list[str]] = {
    "ANI": ["ani", "multi-agent", "networking"],
    "Orchestration": ["workflow", "orchestration", "execution"],
    "Governance": ["governance", "security", "compliance"],
    "Connectors": ["connectors", "integration", "external"],
    "Flow": ["flow", "ui", "visual-builder"],
    "Origin": ["origin", "llm", "model-factory"],
    "Infrastructure": ["infrastructure", "devops"],
    "Testing": ["testing", "qa"],
}

# THEME TO COMPONENT MAPPING
THEME_TO_COMPONENTS: dict[str, list[str]] = {
    "ANI": ["core-ani"],
    "Orchestration": ["core-orchestration"],
    "Governance": ["core-governance"],
    "Connectors": ["core-connectors"],
    "Flow": ["modules-flow"],
    "Origin": ["modules-origin"],
    "Infrastructure": ["core-utils"],
    "Testing": ["tests"],
}

# THEME TO BOUNDED CONTEXT MAPPING
THEME_TO_CONTEXT: dict[str, str] = {
    "ANI": "core-ani",
    "Orchestration": "core-orchestration",
    "Governance": "core-governance",
    "Connectors": "core-connectors",
    "Flow": "modules-flow",
    "Origin": "modules-origin",
    "Insights": "modules-insights",
    "Edge": "modules-edge",
    "Infrastructure": "core-utils",
    "Testing": "tests",
}


class ThemeDetectorService(IThemeDetector):
    """Concrete implementation of theme detection.

    Matches keywords against the input text with **word-boundary** semantics
    so a 3-letter keyword like ``ani`` does not falsely match inside words
    like ``human``, ``company``, ``manifest``. Multi-word keywords (``"ci/cd"``,
    ``"a2a gateway"``) match as whole phrases bounded by whitespace or
    punctuation. Keyword text is regex-escaped before compilation.
    """

    def __init__(self, keyword_map: dict[str, list[str]] | None = None):
        self._keyword_map = keyword_map or THEME_KEYWORDS
        self._compiled_map = {
            theme: [self._compile_keyword(k) for k in keywords]
            for theme, keywords in self._keyword_map.items()
        }

    @staticmethod
    def _compile_keyword(keyword: str) -> re.Pattern[str]:
        """Compile ``keyword`` to a case-insensitive word-boundary pattern.

        ``\\b`` only anchors against word characters, so a keyword that
        starts or ends with non-word punctuation (e.g. ``"ani-"`` or
        ``"a2a gateway"``) gets a permissive boundary at that side
        (whitespace / start / end / non-word) instead of ``\\b``.
        """
        escaped = re.escape(keyword)
        left = r"\b" if keyword[:1].isalnum() or keyword[:1] == "_" else r"(?:^|(?<=\W))"
        right = r"\b" if keyword[-1:].isalnum() or keyword[-1:] == "_" else r"(?=\W|$)"
        return re.compile(f"{left}{escaped}{right}", re.IGNORECASE)

    def detect_themes(self, text: str) -> list[Theme]:
        """Detect themes from text - SINGLE IMPLEMENTATION"""
        themes: list[Theme] = []
        for theme_name, patterns in self._compiled_map.items():
            for pattern in patterns:
                if pattern.search(text):
                    themes.append(Theme(theme_name))
                    break  # Found one keyword for this theme
        return themes


class BoundedContextResolverService(IBoundedContextResolver):
    """Concrete implementation of bounded context resolution"""

    def __init__(self, theme_to_context_map: dict[str, str] | None = None):
        self._theme_map = theme_to_context_map or THEME_TO_CONTEXT
        self._catalog = BOUNDED_CONTEXT_CATALOG
        # Create case-insensitive lookup
        self._theme_map_lower = {k.lower(): v for k, v in self._theme_map.items()}

    def resolve_context(self, themes: list[Theme], text: str = "") -> BoundedContext:
        """Resolve bounded context - SINGLE IMPLEMENTATION"""
        # Try theme mapping first (case-insensitive)
        for theme in themes:
            context_name = self._theme_map_lower.get(theme.name.lower())
            if context_name and context_name in self._catalog:
                return self._catalog[context_name]

        # Keyword fallback for text
        if text:
            text_lower = text.lower()
            keyword_map = {
                "core-agents": ["agent", "llm", "model", "ai agent"],
                "core-ani": ["ani", "network", "communication", "protocol"],
                "core-orchestration": ["workflow", "task", "executor", "schedule"],
                "core-governance": ["rbac", "permission", "audit", "compliance"],
                "core-connectors": ["connector", "integration", "external", "api"],
                "core-persistence": ["database", "storage", "repository"],
                "core-utils": ["utility", "logging", "config"],
            }

            for context_name, keywords in keyword_map.items():
                if any(kw in text_lower for kw in keywords):
                    if context_name in self._catalog:
                        return self._catalog[context_name]

        # Default fallback
        return self._catalog["core-models"]

    def get_all_contexts(self) -> list[BoundedContext]:
        """Get all bounded contexts"""
        return list(self._catalog.values())


class LabelDeriverService(ILabelDeriver):
    """Concrete implementation of label derivation"""

    def __init__(self, theme_to_labels_map: dict[str, list[str]] | None = None):
        self._theme_map = theme_to_labels_map or THEME_TO_LABELS
        # Create case-insensitive lookup
        self._theme_map_lower = {k.lower(): v for k, v in self._theme_map.items()}

    def derive_labels(self, themes: list[Theme]) -> list[str]:
        """Derive labels from themes - SINGLE IMPLEMENTATION"""
        labels = set()

        for theme in themes:
            # Use case-insensitive lookup
            theme_labels = self._theme_map_lower.get(theme.name.lower(), [])
            labels.update(theme_labels)

        # Normalize: lowercase, no spaces, replace underscores
        return [self._normalize_label(label) for label in sorted(labels)]

    def _normalize_label(self, label: str) -> str:
        """Normalize label format"""
        return label.lower().replace("_", "-").replace(" ", "-")


class ComponentDeriverService(IComponentDeriver):
    """Concrete implementation of component derivation"""

    def __init__(self, theme_to_components_map: dict[str, list[str]] | None = None):
        self._theme_map = theme_to_components_map or THEME_TO_COMPONENTS
        # Create case-insensitive lookup
        self._theme_map_lower = {k.lower(): v for k, v in self._theme_map.items()}

    def derive_components(self, themes: list[Theme]) -> list[str]:
        """Derive components from themes - SINGLE IMPLEMENTATION"""
        components = set()

        for theme in themes:
            # Use case-insensitive lookup
            theme_components = self._theme_map_lower.get(theme.name.lower(), [])
            components.update(theme_components)

        return sorted(components)


class PriorityCalculatorService(IPriorityCalculator):
    """Concrete implementation of priority calculation"""

    def calculate_priority(self, issue_type: str, themes: list[Theme], description: str) -> str:
        """Calculate priority - SINGLE IMPLEMENTATION"""
        # Check for explicit priority markers
        desc_upper = description.upper()

        if any(marker in desc_upper for marker in ["P0", "CRITICAL", "URGENT", "BLOCKER"]):
            return "Highest"

        if any(marker in desc_upper for marker in ["P1", "HIGH PRIORITY", "IMPORTANT"]):
            return "High"

        if any(marker in desc_upper for marker in ["P3", "LOW PRIORITY", "NICE TO HAVE"]):
            return "Low"

        # Default by issue type
        if issue_type == "Epic":
            return "High"
        elif issue_type == "Story":
            return "Medium"
        else:
            return "Medium"


class StoryPointEstimatorService(IStoryPointEstimator):
    """Concrete implementation of story point estimation"""

    def estimate_story_points(self, title: str, description: str) -> int:
        """Estimate story points based on complexity keywords"""
        text = (title + " " + description).lower()

        # Complexity scoring
        score = 0

        # High complexity markers (+3)
        if any(
            kw in text
            for kw in [
                "complex",
                "refactor",
                "architecture",
                "security",
                "performance",
                "migration",
            ]
        ):
            score += 3

        # Medium complexity markers (+2)
        if any(kw in text for kw in ["implement", "integrate", "develop", "create", "design"]):
            score += 2

        # Low complexity markers (+1)
        if any(kw in text for kw in ["update", "fix", "bug", "documentation", "readme", "cleanup"]):
            score += 1

        # Map score to Fibonacci
        if score >= 5:
            return 8
        elif score >= 4:
            return 5
        elif score >= 3:
            return 3
        elif score >= 2:
            return 2
        else:
            return 1
