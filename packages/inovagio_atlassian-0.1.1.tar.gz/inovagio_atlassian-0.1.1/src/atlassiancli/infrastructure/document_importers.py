#!/usr/bin/env python3
"""
Document Importers - Fetch/Read Content from Various Sources

ARCHITECTURE (SRP + DRY):
- Each importer ONLY imports content from one source type
- All importers produce the same ImportedDocument format
- NO analysis logic here - that's in document_analyzer.py

Author: Inovagio Engineering Team
"""

import re
from pathlib import Path
from typing import Any

from ..domain.repositories import IConfluenceRepository
from ..domain.services import DocumentSource, IDocumentImporter, ImportedDocument
from ..domain.value_objects import ConfluencePageId

# ============================================================================
# MARKDOWN FILE IMPORTER
# ============================================================================


class MarkdownFileImporter(IDocumentImporter):
    """
    Import markdown files from the local filesystem.

    RESPONSIBILITY: Read file content and parse into sections.
    Does NOT analyze or extract work items.
    """

    def import_document(
        self, source: str, include_children: bool = False, **kwargs
    ) -> ImportedDocument:
        """
        Import a markdown file.

        Args:
            source: File path to the markdown document
            include_children: Not used (markdown files have no hierarchy)

        Returns:
            ImportedDocument with file content and parsed sections
        """
        try:
            path = Path(source)
            if not path.exists():
                return ImportedDocument(
                    source=DocumentSource.MARKDOWN_FILE,
                    source_path=source,
                    import_errors=[f"File not found: {source}"],
                )

            content = path.read_text(encoding="utf-8")
            title = path.stem  # Filename without extension

            # Parse sections from markdown headers
            sections = self._parse_sections(content)

            return ImportedDocument(
                source=DocumentSource.MARKDOWN_FILE,
                source_path=source,
                title=title,
                content=content,
                content_format="markdown",
                sections=sections,
                metadata={
                    "file_size": path.stat().st_size,
                    "file_name": path.name,
                },
            )

        except Exception as e:
            return ImportedDocument(
                source=DocumentSource.MARKDOWN_FILE,
                source_path=source,
                import_errors=[f"Import error: {e!s}"],
            )

    def get_source_type(self) -> DocumentSource:
        return DocumentSource.MARKDOWN_FILE

    def supports_source(self, source: str) -> bool:
        """Check if source is a markdown file path"""
        if not source:
            return False
        path = Path(source)
        return path.suffix.lower() in [".md", ".markdown", ".mdown"]

    def _parse_sections(self, content: str) -> list[dict[str, Any]]:
        """Parse markdown content into sections by headers"""
        sections: list[dict[str, Any]] = []
        current_section: dict[str, Any] | None = None
        current_content: list[str] = []

        for line in content.split("\n"):
            # Check for markdown headers
            header_match = re.match(r"^(#{1,6})\s+(.+)$", line)
            if header_match:
                # Save previous section
                if current_section:
                    current_section["content"] = "\n".join(current_content).strip()
                    sections.append(current_section)

                # Start new section
                level = len(header_match.group(1))
                title = header_match.group(2).strip()
                current_section = {"title": title, "level": level, "content": ""}
                current_content = []
            else:
                current_content.append(line)

        # Save last section
        if current_section:
            current_section["content"] = "\n".join(current_content).strip()
            sections.append(current_section)

        return sections


# ============================================================================
# CONFLUENCE PAGE IMPORTER
# ============================================================================


class ConfluencePageImporter(IDocumentImporter):
    """
    Import Confluence pages via the Confluence API.

    RESPONSIBILITY: Fetch page content and convert to normalized format.
    Does NOT analyze or extract work items.
    """

    def __init__(self, confluence_repository: IConfluenceRepository):
        """
        Initialize with Confluence repository for API access.

        Args:
            confluence_repository: Repository for Confluence API operations
        """
        self._confluence = confluence_repository

    def import_document(
        self, source: str, include_children: bool = False, **kwargs
    ) -> ImportedDocument:
        """
        Import a Confluence page.

        Args:
            source: Page ID or URL
            include_children: Also import child pages

        Returns:
            ImportedDocument with page content
        """
        try:
            # Extract page ID from URL if needed
            page_id = self._extract_page_id(source)

            # Fetch page from Confluence
            page = self._confluence.get_page(ConfluencePageId(page_id))
            if not page:
                return ImportedDocument(
                    source=DocumentSource.CONFLUENCE_PAGE,
                    source_path=source,
                    import_errors=[f"Page not found: {page_id}"],
                )

            # Handle different page response types (object vs dict)
            if isinstance(page, dict):
                title = page.get("title", "Untitled")
                body = page.get("content", "")  # Changed from 'body' to 'content'
                space_key = (
                    page.get("space", {}).get("key")
                    if isinstance(page.get("space"), dict)
                    else page.get("space_key")
                )
                version = (
                    page.get("version", {}).get("number")
                    if isinstance(page.get("version"), dict)
                    else page.get("version")
                )
                url = (
                    page.get("_links", {}).get("webui")
                    if isinstance(page.get("_links"), dict)
                    else page.get("url")
                )
            else:
                title = getattr(page, "title", "Untitled")
                body = getattr(page, "content", "")  # Changed from 'body' to 'content'
                space_key = getattr(page, "space_key", None)
                version = getattr(page, "version", None)
                url = getattr(page, "url", None)

            # Convert HTML to markdown-like format for consistency
            content = self._html_to_markdown(body)
            sections = self._parse_confluence_sections(body)

            document = ImportedDocument(
                source=DocumentSource.CONFLUENCE_PAGE,
                source_path=page_id,
                title=title,
                content=content,
                content_format="markdown",  # Converted from HTML
                sections=sections,
                metadata={
                    "page_id": page_id,
                    "space_key": space_key,
                    "version": version,
                    "url": url,
                },
            )

            # Import children if requested
            if include_children:
                children = self._confluence.get_child_pages(ConfluencePageId(page_id))
                for child_page in children:
                    try:
                        # Extract child page ID (handle both objects and strings)
                        if isinstance(child_page, str):
                            child_id = child_page
                        elif hasattr(child_page, "id"):
                            child_id = str(child_page.id)
                        elif hasattr(child_page, "page_id"):
                            child_id = str(child_page.page_id)
                        else:
                            child_id = str(child_page)

                        child_doc = self.import_document(
                            child_id,
                            include_children=False,  # Don't recurse deeper
                        )
                        document.children.append(child_doc)
                    except Exception as e:
                        # Log error but continue with other children
                        document.import_errors.append(f"Failed to import child page: {e!s}")

            return document

        except Exception as e:
            return ImportedDocument(
                source=DocumentSource.CONFLUENCE_PAGE,
                source_path=source,
                import_errors=[f"Import error: {e!s}"],
            )

    def get_source_type(self) -> DocumentSource:
        return DocumentSource.CONFLUENCE_PAGE

    def supports_source(self, source: str) -> bool:
        """Check if source is a Confluence page ID or URL"""
        if not source:
            return False
        # Page ID (numeric)
        if source.isdigit():
            return True
        # Confluence URL
        if "atlassian.net/wiki" in source or "/pages/" in source:
            return True
        return False

    def _extract_page_id(self, source: str) -> str:
        """Extract page ID from URL or return as-is if already an ID"""
        if source.isdigit():
            return source

        # Extract from URL patterns
        # Pattern 1: /pages/123456789/Page+Title
        match = re.search(r"/pages/(\d+)", source)
        if match:
            return match.group(1)

        # Pattern 2: pageId=123456789
        match = re.search(r"pageId=(\d+)", source)
        if match:
            return match.group(1)

        return source

    def _html_to_markdown(self, html_content: str) -> str:
        """Convert Confluence HTML to markdown-like format"""
        import html as html_module

        if not html_content:
            return ""

        text = html_content

        # Convert headers
        for i in range(6, 0, -1):
            text = re.sub(
                rf"<h{i}[^>]*>(.*?)</h{i}>",
                r"#" * i + r" \1\n",
                text,
                flags=re.IGNORECASE | re.DOTALL,
            )

        # Convert lists
        text = re.sub(r"<li[^>]*>(.*?)</li>", r"- \1\n", text, flags=re.IGNORECASE | re.DOTALL)
        text = re.sub(r"<[uo]l[^>]*>|</[uo]l>", "", text, flags=re.IGNORECASE)

        # Convert paragraphs
        text = re.sub(r"<p[^>]*>(.*?)</p>", r"\1\n\n", text, flags=re.IGNORECASE | re.DOTALL)

        # Convert code blocks
        text = re.sub(
            r'<ac:structured-macro[^>]*ac:name="code"[^>]*>.*?<ac:plain-text-body><!\[CDATA\[(.*?)\]\]></ac:plain-text-body>.*?</ac:structured-macro>',
            r"```\n\1\n```",
            text,
            flags=re.IGNORECASE | re.DOTALL,
        )

        # Remove remaining HTML tags
        text = re.sub(r"<[^>]+>", "", text)

        # Decode HTML entities
        text = html_module.unescape(text)

        # Clean up whitespace
        text = re.sub(r"\n{3,}", "\n\n", text)

        return text.strip()

    def _parse_confluence_sections(self, html_content: str) -> list[dict[str, Any]]:
        """Parse Confluence HTML into sections by headers"""
        sections = []

        # Find all headers
        header_pattern = r"<h(\d)[^>]*>(.*?)</h\1>"
        headers = list(re.finditer(header_pattern, html_content, re.IGNORECASE | re.DOTALL))

        for i, match in enumerate(headers):
            level = int(match.group(1))
            title = re.sub(r"<[^>]+>", "", match.group(2)).strip()

            # Get content between this header and next
            start = match.end()
            end = headers[i + 1].start() if i + 1 < len(headers) else len(html_content)
            content = html_content[start:end]

            # Convert content to markdown
            content = self._html_to_markdown(content)

            sections.append({"title": title, "level": level, "content": content})

        return sections


# ============================================================================
# YAML FILE IMPORTER
# ============================================================================


class YamlFileImporter(IDocumentImporter):
    """
    Import YAML files from the local filesystem.

    RESPONSIBILITY: Read YAML content and convert to normalized format.
    Does NOT analyze or extract work items.
    """

    def import_document(
        self, source: str, include_children: bool = False, **kwargs
    ) -> ImportedDocument:
        """
        Import a YAML file.

        Args:
            source: File path to the YAML document

        Returns:
            ImportedDocument with parsed YAML content
        """
        try:
            import yaml  # type: ignore

            path = Path(source)
            if not path.exists():
                return ImportedDocument(
                    source=DocumentSource.YAML_FILE,
                    source_path=source,
                    import_errors=[f"File not found: {source}"],
                )

            content = path.read_text(encoding="utf-8")
            data = yaml.safe_load(content)

            # Convert YAML structure to sections
            sections = self._yaml_to_sections(data)

            return ImportedDocument(
                source=DocumentSource.YAML_FILE,
                source_path=source,
                title=path.stem,
                content=content,
                content_format="yaml",
                sections=sections,
                metadata={
                    "file_size": path.stat().st_size,
                    "file_name": path.name,
                    "yaml_data": data,  # Preserve parsed structure
                },
            )

        except Exception as e:
            return ImportedDocument(
                source=DocumentSource.YAML_FILE,
                source_path=source,
                import_errors=[f"Import error: {e!s}"],
            )

    def get_source_type(self) -> DocumentSource:
        return DocumentSource.YAML_FILE

    def supports_source(self, source: str) -> bool:
        """Check if source is a YAML file path"""
        if not source:
            return False
        path = Path(source)
        return path.suffix.lower() in [".yaml", ".yml"]

    def _yaml_to_sections(self, data: Any, level: int = 1) -> list[dict[str, Any]]:
        """Convert YAML data to sections"""
        sections = []

        if isinstance(data, dict):
            for key, value in data.items():
                if isinstance(value, dict):
                    # Nested dict becomes a section
                    sections.append({"title": str(key), "level": level, "content": str(value)})
                    sections.extend(self._yaml_to_sections(value, level + 1))
                elif isinstance(value, list):
                    # List becomes bullet points
                    content = "\n".join(f"- {item}" for item in value)
                    sections.append({"title": str(key), "level": level, "content": content})
                else:
                    sections.append({"title": str(key), "level": level, "content": str(value)})

        return sections


# ============================================================================
# IMPORTER FACTORY
# ============================================================================


class DocumentImporterFactory:
    """
    Factory for creating appropriate importer based on source.

    USAGE:
        factory = DocumentImporterFactory(confluence_repo)
        importer = factory.get_importer(source)
        document = importer.import_document(source)
    """

    def __init__(self, confluence_repository: IConfluenceRepository | None = None):
        self._confluence_repo = confluence_repository
        self._importers: list[IDocumentImporter] = []
        self._register_importers()

    def _register_importers(self):
        """Register all available importers"""
        self._importers.append(MarkdownFileImporter())
        self._importers.append(YamlFileImporter())

        if self._confluence_repo:
            self._importers.append(ConfluencePageImporter(self._confluence_repo))

    def get_importer(self, source: str) -> IDocumentImporter | None:
        """
        Get the appropriate importer for the given source.

        Args:
            source: Source identifier (file path, page ID, URL)

        Returns:
            Appropriate IDocumentImporter or None if not supported
        """
        for importer in self._importers:
            if importer.supports_source(source):
                return importer
        return None

    def import_document(
        self, source: str, include_children: bool = False, **kwargs
    ) -> ImportedDocument:
        """
        Import a document using the appropriate importer.

        Convenience method that finds the right importer and imports.

        Args:
            source: Source identifier
            include_children: Include child documents

        Returns:
            ImportedDocument or error document if no importer found
        """
        importer = self.get_importer(source)
        if not importer:
            return ImportedDocument(
                source=DocumentSource.TEXT_CONTENT,
                source_path=source,
                import_errors=[f"No importer found for source: {source}"],
            )

        return importer.import_document(source, include_children, **kwargs)
