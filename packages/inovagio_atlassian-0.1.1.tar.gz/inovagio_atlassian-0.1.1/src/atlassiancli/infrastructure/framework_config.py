"""Loader + credential helpers for the doc framework bridge.

Copied from ``inovagio/scripts/_docframework.py`` (``load_product_config``,
``list_configured_products``, ``get_credentials``). Surgical adaptations:

  * YAML parsing via :mod:`atlassiancli.infrastructure.yaml_codec`
    (replaces the source's ``_inovagio_yaml`` ctypes wrapper — identical
    ``safe_load`` API).
  * Repo root is configurable; each consuming project can specify where
    its ``docs/`` tree lives without hardcoding the inovagio monorepo
    path. Defaults to the current working directory's ``docs/`` so that
    ``atlassiancli framework <subcommand> --product <handle>`` works
    when invoked from a project's repo root.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

from atlassiancli.domain.framework.config import (
    ConfluenceConfig,
    JiraConfig,
    PathsConfig,
    ProductConfig,
)
from atlassiancli.infrastructure.yaml_codec import (
    YamlError,
)
from atlassiancli.infrastructure.yaml_codec import (
    safe_load as _yaml_safe_load,
)


def default_docs_root() -> Path:
    """Return ``<cwd>/docs`` — the conventional location for product docs."""
    return Path.cwd() / "docs"


def load_product_config(
    product: str,
    *,
    docs_root: Path | None = None,
) -> ProductConfig:
    """Load ``<docs_root>/<product>/.docframework.yaml`` into a config.

    Exits the process with status 2 if the config is missing or malformed —
    the bridge subcommands treat this as a hard, recoverable misconfiguration
    (operator forgot to fork the template) rather than an exception, mirroring
    the source script's UX.
    """
    root = docs_root if docs_root is not None else default_docs_root()
    docs_dir = root / product
    config_path = docs_dir / ".docframework.yaml"

    if not config_path.exists():
        rel = _safe_relative(config_path)
        print(
            f"ERROR: no config at {rel}. "
            f"Fork docs/_template/.docframework.yaml into docs/{product}/ and "
            f"populate the values per docs/INOVAGIO_DOC_FRAMEWORK.md.",
            file=sys.stderr,
        )
        sys.exit(2)

    try:
        raw = _yaml_safe_load(config_path.read_text(encoding="utf-8"))
    except YamlError as exc:
        print(f"ERROR: {config_path}: {exc}", file=sys.stderr)
        sys.exit(2)

    if not isinstance(raw, dict):
        print(f"ERROR: {config_path}: not a YAML mapping", file=sys.stderr)
        sys.exit(2)

    for required in ("product", "jira", "confluence"):
        if required not in raw:
            print(
                f"ERROR: {config_path}: missing '{required}' section",
                file=sys.stderr,
            )
            sys.exit(2)

    if raw["product"].get("id") != product:
        print(
            f"ERROR: {config_path}: product.id is {raw['product'].get('id')!r}, "
            f"expected {product!r}",
            file=sys.stderr,
        )
        sys.exit(2)

    jira_raw = raw["jira"]
    confluence_raw = raw["confluence"]
    paths_raw = raw.get("paths") or {}

    for required in ("label_namespace", "summary_prefix"):
        if required not in jira_raw:
            print(
                f"ERROR: {config_path}: jira.{required} is required",
                file=sys.stderr,
            )
            sys.exit(2)
    if "hub_page_id" not in confluence_raw:
        print(
            f"ERROR: {config_path}: confluence.hub_page_id is required",
            file=sys.stderr,
        )
        sys.exit(2)

    return ProductConfig(
        id=raw["product"]["id"],
        name=raw["product"]["name"],
        docs_dir=docs_dir,
        jira=JiraConfig(
            cloud_site=jira_raw.get("cloud_site", "inovagio.atlassian.net"),
            project_key=jira_raw.get("project_key", "INOV"),
            default_assignee_email=jira_raw.get("default_assignee_email", ""),
            label_namespace=jira_raw["label_namespace"],
            summary_prefix=jira_raw["summary_prefix"],
            epics={k: str(v) for k, v in (jira_raw.get("epics") or {}).items()},
        ),
        confluence=ConfluenceConfig(
            cloud_site=confluence_raw.get("cloud_site", "inovagio.atlassian.net"),
            space_key=confluence_raw.get("space_key", "INOV"),
            hub_page_id=str(confluence_raw["hub_page_id"]),
            doc_pages={k: str(v) for k, v in (confluence_raw.get("doc_pages") or {}).items()},
        ),
        paths=PathsConfig(
            manifests_dir=paths_raw.get("manifests_dir", "stories/manifests"),
            evidence_dir=paths_raw.get("evidence_dir", "evidence"),
            epic_docs_dir=paths_raw.get("epic_docs_dir", "epics"),
            adr_dir=paths_raw.get("adr_dir", "adrs"),
        ),
    )


def list_configured_products(*, docs_root: Path | None = None) -> list[str]:
    """Return product handles that have a ``.docframework.yaml``."""
    root = docs_root if docs_root is not None else default_docs_root()
    if not root.is_dir():
        return []
    out: list[str] = []
    for child in sorted(root.iterdir()):
        if not child.is_dir() or child.name.startswith("_"):
            continue
        if (child / ".docframework.yaml").is_file():
            out.append(child.name)
    return out


def get_credentials() -> tuple[str, str]:
    """Return ``(email, token)`` from env or exit with status 2."""
    email = os.environ.get("ATLASSIAN_EMAIL")
    token = os.environ.get("ATLASSIAN_TOKEN")
    if not (email and token):
        print(
            "ERROR: set ATLASSIAN_EMAIL + ATLASSIAN_TOKEN environment variables",
            file=sys.stderr,
        )
        sys.exit(2)
    return email, token


def _safe_relative(path: Path) -> str:
    """Format a path relative to cwd if possible, else absolute."""
    try:
        return str(path.relative_to(Path.cwd()))
    except ValueError:
        return str(path)


__all__ = [
    "default_docs_root",
    "get_credentials",
    "list_configured_products",
    "load_product_config",
]
