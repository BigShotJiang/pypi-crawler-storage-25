#!/usr/bin/env python3
"""
Expert Enhancement Infrastructure

Provides PhD-level expert analysis for story enhancement using Jira wiki format.
Integrates with the atlassian_v3 DDD architecture.

Features:
- Story category detection (FLOW, ANI, MCP, etc.)
- Expert analysis generation (acceptance criteria, testing strategy, etc.)
- Jira wiki format output (h2., *bold*, [text|url])
- Already-enhanced detection to prevent re-corruption
- Description sanitization for re-enhancement

Author: Inovagio Engineering Team
"""

import re
from dataclasses import dataclass, field
from typing import Any

from .document_writer import DocumentSection
from .story_domain_knowledge import StoryContext, StoryContextResolver

# ============================================================================
# CONFLUENCE DOCUMENTATION MAPPING
# ============================================================================

CONFLUENCE_DOCS = {
    "ANI": {
        "main": "https://inovagio.atlassian.net/wiki/spaces/INOV/pages/146079747/ANI+Agent+Network+Interface+Architecture",
        "v2": "https://inovagio.atlassian.net/wiki/spaces/INOV/pages/147554305/ANI+v2.0+-+Enterprise+Agent+Fabric+Enhancement+Roadmap",
        "broker": "https://inovagio.atlassian.net/wiki/spaces/INOV/pages/147128419/ANI+Broker+Architecture",
        "gateway": "https://inovagio.atlassian.net/wiki/spaces/INOV/pages/147488770/ANI+Protocol+Gateway+Architecture+MCP+A2A",
        "handoff": "https://inovagio.atlassian.net/wiki/spaces/INOV/pages/147652610/Pattern+35+Agent+Handoff+Protocol",
    },
    "MCP": {
        "gateway": "https://inovagio.atlassian.net/wiki/spaces/INOV/pages/147488770/ANI+Protocol+Gateway+Architecture+MCP+A2A",
        "integration": "https://inovagio.atlassian.net/wiki/spaces/IAS/pages/108462466/Inovagio+Integration+Roadmap+ADI+A2A+MCP",
    },
    "Orchestration": {
        "main": "https://inovagio.atlassian.net/wiki/spaces/INOV/pages/142376962/Hybrid+Workflow+Orchestrator",
        "enhancements": "https://inovagio.atlassian.net/wiki/spaces/INOV/pages/149028866/Workflow+Engine+Enhancement+Specification+Superiority+Roadmap",
    },
    "Patterns": {
        "architecture": "https://inovagio.atlassian.net/wiki/spaces/INOV/pages/147128442/Agentic+Design+Patterns+Architecture"
    },
    "Flow": {
        "architecture": "https://inovagio.atlassian.net/wiki/spaces/INOV/pages/146079771/Inovagio+Flow+-+Product+Architecture+Engineering+Blueprint",
        "bridge": "https://inovagio.atlassian.net/wiki/spaces/INOV/pages/147357698/Inovagio+Flow+-+Native+Bridge+Specification",
    },
    "Guard": {
        "main": "https://inovagio.atlassian.net/wiki/spaces/INOV/pages/142377045/Inovagio+Crews"
    },
    "Sentinel": {
        "main": "https://inovagio.atlassian.net/wiki/spaces/INOV/pages/142377045/Inovagio+Crews"
    },
    "EVAL": {
        "origin": "https://inovagio.atlassian.net/wiki/spaces/INOV/pages/142737433/Inovagio+Origin"
    },
    "Architecture": {
        "ddd": "https://inovagio.atlassian.net/wiki/spaces/INOV/pages/142377005/DDD+Context+Map",
        "technology": "https://inovagio.atlassian.net/wiki/spaces/INOV/pages/142376985/Technology+Architecture",
        "alignment": "https://inovagio.atlassian.net/wiki/spaces/INOV/pages/147456001/Architecture+Alignment+Guide+-+Core+vs+Product+Boundaries",
        "ecosystem": "https://inovagio.atlassian.net/wiki/spaces/INOV/pages/146735117/Inovagio+Ecosystem+-+Complete+Product+Architecture+Map",
    },
    "API": {
        "reference": "https://inovagio.atlassian.net/wiki/spaces/INOV/pages/142606382/API+Reference"
    },
    "Domain": {
        "glossary": "https://inovagio.atlassian.net/wiki/spaces/INOV/pages/142508058/Domain+Glossary"
    },
    "Development": {
        "sops": "https://inovagio.atlassian.net/wiki/spaces/INOV/pages/142737528/Software+Development+SOPs"
    },
}

# ============================================================================
# STORY CATEGORIES
# ============================================================================

STORY_CATEGORIES = {
    "FLOW": {
        "domain": "Inovagio Flow - VS Code Fork for AI Workflows",
        "key_concerns": [
            "Native Bridge (N-API)",
            "TypeScript/React UI",
            "Electron",
            "Security hardening",
        ],
        "test_types": [
            "UI component tests",
            "Bridge integration tests",
            "E2E workflow tests",
        ],
        "dependencies": ["core-agents", "core-orchestration", "core-security"],
    },
    "AGENTIC": {
        "domain": "Agentic Design Patterns - RAG, Reflection, Multi-Agent",
        "key_concerns": [
            "LLM integration",
            "Pattern implementation",
            "Hallucination reduction",
            "Latency",
        ],
        "test_types": [
            "Mock LLM tests",
            "Pattern behavior tests",
            "Performance benchmarks",
        ],
        "dependencies": ["core-agents", "core-retrieval", "core-orchestration"],
    },
    "ANI": {
        "domain": "Agent Network Interface - Multi-Agent Communication",
        "key_concerns": [
            "MCP protocol",
            "A2A messaging",
            "Agent discovery",
            "Handoff patterns",
        ],
        "test_types": [
            "Protocol conformance",
            "Message serialization",
            "Network fault tests",
        ],
        "dependencies": ["core-ani", "core-connectors", "core-models"],
    },
    "GTM": {
        "domain": "Go-to-Market - User-Facing Features",
        "key_concerns": [
            "UX flow",
            "Time-to-value",
            "Onboarding",
            "Integration simplicity",
        ],
        "test_types": [
            "User journey tests",
            "Time-to-complete metrics",
            "A/B test infrastructure",
        ],
        "dependencies": ["Origin Studio", "Flow", "Marketplace"],
    },
    "MCP": {
        "domain": "Model Context Protocol - Tool/Resource Server",
        "key_concerns": [
            "Tool discovery",
            "Capability declaration",
            "Guard integration",
            "Telemetry",
        ],
        "test_types": [
            "Protocol compliance",
            "Tool execution tests",
            "Security boundary tests",
        ],
        "dependencies": ["core-nexus", "core-governance", "core-connectors"],
    },
    "NEXUS": {
        "domain": "Capability Hub - Unified Tool/Resource Access",
        "key_concerns": [
            "Resource abstraction",
            "Capability registry",
            "Policy enforcement",
            "PII redaction",
        ],
        "test_types": [
            "Capability execution",
            "Guard integration",
            "Telemetry emission",
        ],
        "dependencies": ["core-nexus", "core-governance", "core-observability"],
    },
    "EVAL": {
        "domain": "Inovagio Origin - SLM Training & Evaluation",
        "key_concerns": [
            "Model training",
            "Benchmark evaluation",
            "Artifact registry",
            "Compute plane",
        ],
        "test_types": [
            "Training pipeline tests",
            "Evaluation accuracy",
            "Resource cleanup tests",
        ],
        "dependencies": ["Origin Engine", "Artifact Registry", "Compute Plane"],
    },
    "DEFAULT": {
        "domain": "Inovagio Platform - Enterprise AI Workforce",
        "key_concerns": [
            "DDD compliance",
            "Security",
            "Test coverage",
            "Observability",
        ],
        "test_types": ["Unit tests", "Integration tests", "Contract tests"],
        "dependencies": ["core-models", "core-utils", "core-governance"],
    },
}

# Security requirements by domain
SECURITY_REQUIREMENTS = {
    "FLOW": [
        "Extension whitelist enforcement via signed configuration",
        "Hardware trust root (Secure Enclave/TPM) for key operations",
        "TLS 1.3 for all network communication",
        "No PII in telemetry payloads",
    ],
    "ANI": [
        "Agent identity verification via Ed25519 signatures",
        "Message encryption for sensitive payloads",
        "Rate limiting per agent/tenant",
        "Audit logging for all cross-agent calls",
    ],
    "MCP": [
        "Capability permission checks via Guard",
        "PII redaction in tool responses",
        "Resource access authorization",
        "Execution timeout enforcement",
    ],
    "DEFAULT": [
        "RBAC via core-governance::IAuthorizationService",
        "Audit logging for protected operations",
        "No secrets in logs or config files",
        "Constant-time secret comparison",
    ],
}


# ============================================================================
# DATA CLASSES
# ============================================================================


@dataclass
class ExpertAnalysis:
    """Result of expert analysis for a story"""

    category: str = "DEFAULT"
    acceptance_criteria: list[str] = field(default_factory=list)
    technical_approach: dict[str, Any] = field(default_factory=dict)
    testing_strategy: dict[str, list[str]] = field(default_factory=dict)
    security_requirements: list[str] = field(default_factory=list)
    related_confluence_pages: list[str] = field(default_factory=list)
    implementation_notes: list[str] = field(default_factory=list)
    definition_of_done: list[str] = field(default_factory=list)
    # New fields for AI-ready stories (PhD-level precision)
    data_schemas: list[str] = field(default_factory=list)
    interface_definitions: list[str] = field(default_factory=list)
    state_machine_spec: list[str] = field(default_factory=list)
    auth_flow_spec: list[str] = field(default_factory=list)
    # Business and implementation guidance (INOV-520 level detail)
    business_value: str = ""
    code_examples: list[str] = field(default_factory=list)
    debugging_guide: list[str] = field(default_factory=list)
    # Resolved story context (domain-specific technical requirements)
    story_context: Any | None = None


# ============================================================================
# DETECTION AND SANITIZATION
# ============================================================================


def is_already_enhanced(description: str) -> bool:
    """Detect if description was already enhanced to prevent re-corruption.

    Checks for presence of our structured sections in either:
    - Jira wiki format (h2. 📚)
    - Markdown format (## 📚)
    - Corrupted format (1. 📚 or \\*)
    """
    if not description:
        return False

    # Check for our section markers
    enhancement_markers = [
        "h2. 📚 Documentation References",
        "h2. 🎯 Acceptance Criteria",
        "h2. 🏗️ Technical Approach",
        "h2. ✅ Definition of Done",
        "## 📚 Documentation References",
        "## 🎯 Acceptance Criteria",
        # Corrupted markers (already damaged)
        "\\*\\*",  # Escaped asterisks
        "\\[",  # Escaped brackets
        "1. \n    1. 📚",  # Numbered list corruption
    ]

    for marker in enhancement_markers:
        if marker in description:
            return True

    return False


def sanitize_description(description: str) -> str:
    """Remove enhancement formatting to extract clean overview content.

    Strips structured sections and escaped characters to get original intent.
    Aggressively removes AI-generated sections to prevent re-corruption.
    """
    if not description:
        return ""

    clean = description

    # Remove escaped characters from corruption
    clean = clean.replace("\\*", "*")
    clean = clean.replace("\\[", "[")
    clean = clean.replace("\\]", "]")
    clean = clean.replace("\\#", "#")

    # SPECIAL CASE: If there is an Overview section, extract its content first
    # as it likely contains the original story intent we want to preserve.
    overview_match = re.search(
        r"(?:##|h2\.)\s*📋\s*Overview\s*\n+(.*?)(?=(?:##|h2\.)\s*[📚🧾🎯🏗️✅🧪🔗📝🏛️💻🔄💰🔍💡📐🔧]|----+|---|$)",
        clean,
        flags=re.DOTALL,
    )
    overview_content = overview_match.group(1).strip() if overview_match else ""

    # If overview content itself contains enhancement headers, sanitize it too
    if overview_content:
        overview_content = re.sub(
            r"(?:##|h2\.)\s*[📚📋🧾🎯🏗️✅🧪🔗📝🏛️💻🔄💰🔍💡📐🔧].*$",
            "",
            overview_content,
            flags=re.MULTILINE | re.DOTALL,
        )
        overview_content = overview_content.strip()

    # Remove structured section headers and their content (wiki format)
    # Matches h2. [Emoji] ... until next h2., horizontal rule, or end
    clean = re.sub(
        r"h2\.\s*[📚📋🧾🎯🏗️✅🧪🔗📝🏛️💻🔄💰🔍💡📐🔧].*?(?=h2\.|----+|---|##|$)",
        "",
        clean,
        flags=re.DOTALL,
    )

    # Remove structured section headers and their content (markdown format)
    # Matches ## [Emoji] ... until next ##, horizontal rule, or end
    clean = re.sub(
        r"##\s*[📚📋🧾🎯🏗️✅🧪🔗📝🏛️💻🔄💰🔍💡📐🔧].*?(?=##|----+|---|h2\.|$)",
        "",
        clean,
        flags=re.DOTALL,
    )

    # Remove specific sections that might not have emojis (like NFRs from previous runs)
    clean = re.sub(
        r"##\s*Non-Functional Requirements.*?(?=##|----+|---|h2\.|$)",
        "",
        clean,
        flags=re.DOTALL | re.I,
    )
    clean = re.sub(
        r"h2\.\s*Non-Functional Requirements.*?(?=h2\.|----+|---|##|$)",
        "",
        clean,
        flags=re.DOTALL | re.I,
    )

    # Remove non-emoji enhancement sections from previous runs
    # (e.g., "## Context", "## Technical Approach", "## Related Stories")
    for section_name in [
        "Context",
        "Technical Approach",
        "Related Stories",
        "Architecture Findings",
        "Concrete Implementation",
    ]:
        clean = re.sub(
            rf"##\s*{section_name}.*?(?=##|----+|---|h2\.|$)",
            "",
            clean,
            flags=re.DOTALL | re.I,
        )
        clean = re.sub(
            rf"h2\.\s*{section_name}.*?(?=h2\.|----+|---|##|$)",
            "",
            clean,
            flags=re.DOTALL | re.I,
        )

    # If we found overview content and the resulting clean string is empty, use the overview
    if overview_content and not clean.strip():
        clean = overview_content

    # Remove any remaining lines that start with an enhancement emoji
    clean = re.sub(r"^[📚📋🧾🎯🏗️✅🧪🔗📝🏛️💻🔄💰🔍💡📐🔧].*$", "", clean, flags=re.MULTILINE)

    # Remove numbered list wrappers from previous corruption
    clean = re.sub(r"^\d+\.\s*\n\s*\d+\.", "", clean, flags=re.MULTILINE)

    # Remove horizontal rules
    clean = re.sub(r"----+", "", clean)
    clean = re.sub(r"---", "", clean)

    # Remove checkbox items that look generated
    clean = re.sub(r"\[[ x]\]\s*(AC\d+:|Criterion \d+:|.*?).*?\n", "", clean)

    # Remove common AI-generated artifacts like colons at start of lines
    clean = re.sub(r"^\s*:\s*", "", clean, flags=re.MULTILINE)

    # Clean up whitespace
    clean = re.sub(r"\n{3,}", "\n\n", clean)
    clean = clean.strip()

    return clean


# ============================================================================
# EXPERT TEAM ANALYZER
# ============================================================================


class ExpertTeam:
    """Simulates a team of PhD-level engineers analyzing a story"""

    def __init__(self):
        self.domain_keywords = self._build_keyword_index()
        self._context_resolver = StoryContextResolver()

    def _build_keyword_index(self) -> dict[str, list[str]]:
        """Build keyword index for domain detection"""
        return {
            "FLOW": [
                "flow",
                "vscode",
                "bridge",
                "electron",
                "tauri",
                "graphcanvas",
                "ui",
                "panel",
                "editor",
            ],
            "AGENTIC": [
                "agentic",
                "rag",
                "reflection",
                "pattern",
                "llm",
                "retrieval",
                "embedding",
                "rerank",
            ],
            "ANI": [
                "ani",
                "a2a",
                "agent network",
                "handoff",
                "broker",
                "gateway",
                "multi-agent",
            ],
            "GTM": [
                "gtm",
                "onboarding",
                "wizard",
                "10-minute",
                "marketplace",
                "user journey",
            ],
            "MCP": ["mcp", "tool", "resource", "capability", "nexus", "protocol"],
            "NEXUS": [
                "nexus",
                "capability",
                "resource",
                "registry",
                "guard",
                "telemetry",
            ],
            "EVAL": [
                "origin",
                "training",
                "model",
                "slm",
                "benchmark",
                "artifact",
                "compute",
            ],
        }

    def detect_category(self, summary: str, description: str) -> str:
        """Detect story category from content"""
        content = f"{summary} {description}".lower()

        # Check for explicit tag in summary
        for tag in [
            "[FLOW]",
            "[AGENTIC]",
            "[ANI]",
            "[GTM]",
            "[MCP]",
            "[NEXUS]",
            "[EVAL]",
        ]:
            if tag in summary.upper():
                return tag.strip("[]")

        # Score by keywords
        scores: dict[str, int] = {}
        for category, keywords in self.domain_keywords.items():
            scores[category] = sum(1 for kw in keywords if kw in content)

        if max(scores.values()) > 0:
            return max(scores, key=lambda k: scores[k])

        return "DEFAULT"

    def extract_existing_criteria(self, description: str) -> list[str]:
        """Extract any existing acceptance criteria from description"""
        criteria = []

        # Look for checked/unchecked items
        patterns = [
            r"\[[ x]\]\s*(.+?)(?=\n|\[|\Z)",  # [ ] or [x] items
            r"\*\s*\[[ x]\]\s*(.+?)(?=\n|\*|\Z)",  # * [ ] items
        ]

        for pattern in patterns:
            matches = re.findall(pattern, description, re.MULTILINE | re.DOTALL)
            for match in matches:
                cleaned = match.strip()
                if cleaned and not cleaned.startswith("_Add") and "Criterion" not in cleaned:
                    criteria.append(cleaned)

        return criteria

    def analyze_story(self, issue_key: str, summary: str, description: str) -> ExpertAnalysis:
        """Perform expert analysis on a story"""
        # issue_key reserved for future use (e.g., linking related issues)
        _ = issue_key  # Mark as intentionally unused
        analysis = ExpertAnalysis()

        # Detect category
        category = self.detect_category(summary, description)
        analysis.category = category
        category_info = STORY_CATEGORIES.get(category, STORY_CATEGORIES["DEFAULT"])

        # Extract existing criteria
        existing_criteria = self.extract_existing_criteria(description)

        # Generate acceptance criteria based on story type
        analysis.acceptance_criteria = self._generate_acceptance_criteria(
            summary, description, category, existing_criteria
        )

        # Generate technical approach
        analysis.technical_approach = self._generate_technical_approach(
            summary, description, category, category_info
        )

        # Generate testing strategy
        analysis.testing_strategy = self._generate_testing_strategy(
            summary, description, category, category_info
        )

        # Add security requirements
        analysis.security_requirements = SECURITY_REQUIREMENTS.get(
            category, SECURITY_REQUIREMENTS["DEFAULT"]
        )

        # Generate implementation notes
        analysis.implementation_notes = self._generate_implementation_notes(
            summary, description, category
        )

        # Generate Definition of Done
        analysis.definition_of_done = self._generate_definition_of_done(category)

        # Resolve story-specific technical context (replaces category-only boilerplate)
        story_context = self._context_resolver.resolve(summary, description, category)

        # Override category if resolver matched a specific technology pattern.
        # This prevents keyword-based detection false positives (e.g., "tool"
        # triggering MCP category for a core-agents story about StructuredOutput).
        if (
            story_context.resolved_category != "DEFAULT"
            and story_context.resolved_category != category
        ):
            category = story_context.resolved_category
            analysis.category = category

        # Generate High-Precision Technical Specs using story context (AI-Ready)
        analysis.data_schemas = self._generate_data_schemas_from_context(story_context, category)
        analysis.interface_definitions = self._generate_interface_definitions_from_context(
            story_context, category
        )
        analysis.state_machine_spec = self._generate_state_machine_from_context(
            story_context, category
        )
        analysis.auth_flow_spec = self._generate_auth_flow_spec(category)

        # Generate business value, code examples, and debugging guide
        analysis.business_value = generate_business_value(category, summary, description)
        analysis.code_examples = generate_code_examples_from_context(
            story_context, category, summary, description
        )
        analysis.debugging_guide = generate_debugging_guide(category, summary, description)

        # Attach story context to analysis for downstream use
        analysis.story_context = story_context

        return analysis

    def _generate_data_schemas_from_context(
        self, story_context: StoryContext, category: str
    ) -> list[str]:
        """Generate data schemas from resolved story context.

        Uses story-specific schemas when available, falls back to
        category-based generation only as last resort.
        """
        # Use story-specific schemas if resolved
        if story_context.data_schemas:
            return story_context.data_schemas

        # Fall back to category-based (legacy behavior)
        return self._generate_data_schemas(category)

    def _generate_interface_definitions_from_context(
        self, story_context: StoryContext, category: str
    ) -> list[str]:
        """Generate interface definitions from resolved story context.

        Produces story-specific interfaces showing both existing interfaces
        that the story uses and new interfaces that need to be created.
        """
        if story_context.existing_interfaces or story_context.new_interfaces_needed:
            interfaces: list[str] = []

            if story_context.existing_interfaces:
                interfaces.append("*Existing Interfaces (use as-is)*:")
                for name, desc in story_context.existing_interfaces:
                    interfaces.append(f"• `{name}`: {desc}")
                interfaces.append("")

            if story_context.new_interfaces_needed:
                interfaces.append("*New Interfaces Required*:")
                for name, desc in story_context.new_interfaces_needed:
                    interfaces.append(f"• `{name}`: {desc}")
                interfaces.append("")

            if story_context.key_value_objects:
                interfaces.append("*Key Value Objects*:")
                for name, desc in story_context.key_value_objects:
                    interfaces.append(f"• `{name}`: {desc}")

            # Append any schema blocks that contain interface definitions
            for schema_line in story_context.data_schemas:
                if schema_line.startswith("*I") and "Interface" in schema_line:
                    interfaces.append("")
                    interfaces.append(schema_line)

            return interfaces

        # Fall back to category-based
        return self._generate_interface_definitions(category)

    def _generate_state_machine_from_context(
        self, story_context: StoryContext, category: str
    ) -> list[str]:
        """Generate state machine from resolved story context."""
        if story_context.state_machine:
            return story_context.state_machine
        return self._generate_state_machine_spec(category)

    def _generate_acceptance_criteria(
        self,
        summary: str,
        description: str,
        category: str,
        existing: list[str],
    ) -> list[str]:
        """Generate specific, testable acceptance criteria"""
        _ = description  # Reserved for future NLP-based criteria extraction
        criteria = existing.copy() if existing else []

        summary_lower = summary.lower()

        # Add category-specific criteria
        if category == "FLOW":
            if "bridge" in summary_lower:
                criteria.extend(
                    [
                        "Bridge bindings compile without warnings on macOS, Linux, Windows",
                        "Async operations return Promise-based TypeScript API",
                        "Memory is properly managed (no leaks under ASan)",
                        "Cancellation is supported for long-running operations",
                    ]
                )
            elif "ui" in summary_lower or "panel" in summary_lower:
                criteria.extend(
                    [
                        "Component renders correctly in all supported themes (light/dark)",
                        "Keyboard navigation works for accessibility (WCAG 2.1 AA)",
                        "State persists across VS Code reload",
                        "Performance: renders in <100ms for typical data size",
                    ]
                )
            elif "security" in summary_lower or "trust" in summary_lower:
                criteria.extend(
                    [
                        "Hardware trust root integration verified on target platforms",
                        "Key material never exposed to JavaScript layer",
                        "Security audit trail captures all cryptographic operations",
                        "Fallback mode activates gracefully on unsupported hardware",
                    ]
                )

        elif category == "AGENTIC":
            if "rag" in summary_lower or "retrieval" in summary_lower:
                criteria.extend(
                    [
                        "Retrieval precision@5 ≥ 90% on benchmark dataset",
                        "Embedding batch processing supports >100 chunks/second",
                        "Citation metadata preserved through pipeline",
                        "Latency p99 < 500ms for single query",
                    ]
                )
            elif "reflection" in summary_lower:
                criteria.extend(
                    [
                        "Reflection loop converges within max_iterations in 95% of cases",
                        "Quality score rubric produces consistent results (kappa > 0.8)",
                        "HITL fallback triggers correctly when threshold not met",
                        "Output improvement measurable (>15% quality delta)",
                    ]
                )

        elif category == "ANI":
            criteria.extend(
                [
                    "Messages serialize/deserialize round-trip correctly",
                    "Agent discovery completes within 5 seconds",
                    "Handoff state preserved across agent transitions",
                    "Network partition recovery within configurable timeout",
                ]
            )

        elif category in ["MCP", "NEXUS"]:
            criteria.extend(
                [
                    "Capability manifest validates against schema",
                    "Guard pre-check blocks unauthorized requests",
                    "PII redaction runs on all response payloads",
                    "Telemetry emits for every capability execution",
                ]
            )

        elif category == "EVAL":
            criteria.extend(
                [
                    "Training job submits and runs to completion",
                    "Checkpoints saved at configured intervals",
                    "Artifact registry stores model with metadata",
                    "Inference playground loads trained model",
                ]
            )

        # Add universal criteria if list is short
        if len(criteria) < 5:
            criteria.extend(
                [
                    "Unit test coverage ≥ 85% for new code",
                    "Integration tests verify end-to-end flow",
                    "No memory leaks (ASan clean)",
                    "Zero compiler warnings (-Werror)",
                ]
            )

        # Deduplicate and limit
        seen = set()
        unique_criteria = []
        for c in criteria:
            if c not in seen:
                seen.add(c)
                unique_criteria.append(c)

        return unique_criteria[:8]

    def _generate_technical_approach(
        self,
        summary: str,
        description: str,
        category: str,
        category_info: dict[str, Any],
    ) -> dict[str, Any]:
        """Generate technical approach section"""
        _ = description  # Reserved for future code snippet detection
        approach: dict[str, Any] = {
            "key_components": [],
            "integration_points": [],
            "design_patterns": [],
            "layer_placement": "",
        }

        summary_lower = summary.lower()
        if any(m in summary_lower for m in ["model", "value object", "entity", "id"]):
            approach["layer_placement"] = (
                "Layer 0 (core-models) - Value objects and domain primitives"
            )
        elif any(m in summary_lower for m in ["util", "logging", "thread", "serialize"]):
            approach["layer_placement"] = "Layer 1 (core-utils) - Infrastructure utilities"
        elif any(m in summary_lower for m in ["governance", "audit", "persist", "observ"]):
            approach["layer_placement"] = "Layer 2 - Cross-cutting concerns"
        else:
            approach["layer_placement"] = "Layer 3 - Domain services"

        # Key components based on category
        if category == "FLOW":
            approach["key_components"] = [
                ("NativeBridge", "N-API binding layer exposing C++ to TypeScript"),
                ("TypeScript Interface", "Type-safe API consumed by React components"),
                (
                    "React Component",
                    "UI presentation layer with hooks for bridge calls",
                ),
            ]
            approach["design_patterns"] = [
                "Bridge",
                "Adapter",
                "Observer (for state sync)",
            ]
            approach["integration_points"] = [
                "core-agents via AgentBridge",
                "core-orchestration via WorkflowBridge",
                "core-security via SecurityBridge",
            ]

        elif category == "AGENTIC":
            approach["key_components"] = [
                (
                    "Interface Definition",
                    "Abstract interface in core-agents/core-retrieval",
                ),
                (
                    "Default Implementation",
                    "Production implementation with configurable behavior",
                ),
                ("Mock Implementation", "Test double for unit/integration tests"),
            ]
            approach["design_patterns"] = [
                "Strategy",
                "Template Method",
                "Chain of Responsibility",
            ]
            approach["integration_points"] = [
                "core-agents for LLM client access",
                "core-persistence for vector storage",
                "core-orchestration for workflow integration",
            ]

        elif category == "ANI":
            approach["key_components"] = [
                ("Protocol Handler", "Message serialization/deserialization"),
                ("Broker Integration", "ANI Broker registration and discovery"),
                ("State Machine", "Agent state transitions and handoff logic"),
            ]
            approach["design_patterns"] = ["State", "Mediator", "Observer"]
            approach["integration_points"] = [
                "ANI Broker for agent registry",
                "core-governance for permission checks",
                "core-observability for distributed tracing",
            ]

        else:
            approach["key_components"] = [
                ("Public Interface", "Header in include/ directory"),
                ("Implementation", "Source in src/ directory"),
                ("Unit Tests", "Tests in tests/ directory"),
            ]
            approach["design_patterns"] = category_info.get(
                "patterns", ["Repository", "Factory", "Strategy"]
            )[:3]
            approach["integration_points"] = category_info.get(
                "dependencies", ["core-models", "core-utils"]
            )

        return approach

    def _generate_testing_strategy(
        self,
        summary: str,
        description: str,
        category: str,
        category_info: dict[str, Any],
    ) -> dict[str, list[str]]:
        """Generate testing strategy section"""
        _, _ = summary, description  # Reserved for future use
        strategy: dict[str, list[str]] = {
            "unit_tests": [],
            "integration_tests": [],
            "edge_cases": [],
        }

        # Universal unit tests
        strategy["unit_tests"] = [
            "Verify default construction and initialization",
            "Test all public methods with valid inputs",
            "Test error handling for invalid inputs",
            "Verify Result<T,E> error propagation",
        ]

        # Category-specific tests
        if category == "FLOW":
            strategy["unit_tests"].extend(
                [
                    "Mock N-API environment for bridge tests",
                    "Verify TypeScript type generation matches C++ types",
                ]
            )
            strategy["integration_tests"] = [
                "End-to-end bridge call from TypeScript to C++",
                "Async operation completion and callback",
                "Error propagation from C++ to TypeScript rejection",
            ]
            strategy["edge_cases"] = [
                "Bridge call during application shutdown",
                "Large payload serialization (>1MB)",
                "Concurrent bridge calls from multiple threads",
            ]

        elif category == "AGENTIC":
            strategy["unit_tests"].extend(
                [
                    "Mock LLM responses for deterministic testing",
                    "Verify embedding dimension consistency",
                ]
            )
            strategy["integration_tests"] = [
                "Full RAG pipeline with real vector store",
                "Reflection loop convergence with mock LLM",
                "Multi-agent handoff sequence",
            ]
            strategy["edge_cases"] = [
                "Empty result set from retrieval",
                "LLM timeout during generation",
                "Reflection loop hitting max iterations",
            ]

        elif category == "ANI":
            strategy["integration_tests"] = [
                "Agent registration and discovery flow",
                "Message delivery with acknowledgment",
                "Handoff with state transfer",
            ]
            strategy["edge_cases"] = [
                "Network partition during handoff",
                "Agent crash during message processing",
                "Duplicate message detection",
            ]

        elif category in ["MCP", "NEXUS"]:
            strategy["integration_tests"] = [
                "Capability registration and discovery",
                "Guard permission check integration",
                "Telemetry emission verification",
            ]
            strategy["edge_cases"] = [
                "Capability execution timeout",
                "PII in unexpected response field",
                "Rate limit exceeded",
            ]

        else:
            strategy["integration_tests"] = category_info.get(
                "test_types",
                [
                    "Module integration with dependencies",
                    "End-to-end workflow test",
                    "Error recovery scenario",
                ],
            )
            strategy["edge_cases"] = [
                "Null/empty input handling",
                "Concurrent access (thread safety)",
                "Resource exhaustion (memory, file handles)",
            ]

        return strategy

    def _generate_implementation_notes(
        self,
        summary: str,
        description: str,
        category: str,
    ) -> list[str]:
        """Generate implementation notes and gotchas"""
        _, _ = summary, description  # Reserved for future use
        notes = []

        if category == "FLOW":
            notes.extend(
                [
                    "Use cmake-js for native module builds (not node-gyp)",
                    "N-API thread-safe function required for callbacks from C++ threads",
                    "Electron main process has limited access to native modules - use preload",
                ]
            )

        elif category == "AGENTIC":
            notes.extend(
                [
                    "Use Result<T,E> consistently - never throw exceptions",
                    "Embedding models may have different dimension sizes - validate at runtime",
                    "Consider batching embeddings to reduce API calls",
                ]
            )

        elif category == "ANI":
            notes.extend(
                [
                    "MCP and A2A protocols have different message envelopes - use adapters",
                    "Agent state must be serializable for handoff",
                    "Use correlation IDs for distributed tracing",
                ]
            )

        # Universal notes
        notes.extend(
            [
                "Follow SOLID principles - single responsibility per class",
                "Use dependency injection for testability",
            ]
        )

        return notes[:5]

    def _generate_definition_of_done(self, category: str) -> list[str]:
        """Generate Definition of Done checklist"""
        dod = [
            "All acceptance criteria verified and passing",
            "Unit tests written with ≥85% code coverage",
            "Integration tests passing in CI",
            "Code reviewed and approved by at least one team member",
            "Documentation updated (README, inline comments, Doxygen)",
            "No compiler warnings (-Werror clean build)",
            "Sanitizers clean (ASan, UBSan, TSan where applicable)",
            "Performance benchmarks meet targets (if applicable)",
        ]

        if category == "FLOW":
            dod.append("Cross-platform build verified (macOS, Linux, Windows)")
            dod.append("TypeScript types exported and documented")

        elif category in ["ANI", "MCP", "NEXUS"]:
            dod.append("Security review passed for new interfaces")
            dod.append("Audit logging verified in compliance check")

        return dod

    def _generate_data_schemas(self, category: str) -> list[str]:
        """Generate high-precision data schemas (C++ structs/JSON)."""
        schemas = []
        if category == "FLOW":
            schemas.extend(
                [
                    "*FlowExecutionState* (C++ Struct):",
                    "```cpp",
                    "struct FlowExecutionState {",
                    "    UUID flow_id;",
                    "    ExecutionStatus status;",
                    "    std::vector<StepResult> results;",
                    "    std::chrono::system_clock::time_point started_at;",
                    "};",
                    "```",
                ]
            )
        elif category == "ANI":
            schemas.extend(
                [
                    "*MCPMessageEnvelope* (JSON Schema):",
                    "```json",
                    "{",
                    '  "jsonrpc": "2.0",',
                    '  "method": "string",',
                    '  "params": {},',
                    '  "id": "string|number"',
                    "}",
                    "```",
                ]
            )
        elif category == "AGENTIC":
            schemas.extend(
                [
                    "*AgentMemoryEntry* (C++ Struct):",
                    "```cpp",
                    "struct AgentMemoryEntry {",
                    "    UUID entry_id;",
                    "    std::string content;",
                    "    std::vector<float> embedding;",
                    "    Metadata metadata;",
                    "};",
                    "```",
                ]
            )
        elif category == "MCP":
            schemas.extend(
                [
                    "*CapabilityManifest* (JSON Schema):",
                    "```json",
                    "{",
                    '  "name": "string",',
                    '  "version": "string",',
                    '  "tools": [',
                    '    { "name": "string", "description": "string", "inputSchema": {} }',
                    "  ]",
                    "}",
                    "```",
                ]
            )
        elif category == "EVAL":
            schemas.extend(
                [
                    "*TrainingArtifact* (C++ Struct):",
                    "```cpp",
                    "struct TrainingArtifact {",
                    "    UUID artifact_id;",
                    "    Path checkpoint_path;",
                    "    Metrics training_metrics;",
                    "    ModelConfig config;",
                    "};",
                    "```",
                ]
            )
        else:
            schemas.append(
                "• *GenericDataModel*: Standard Result<T,E> wrapper for all domain operations."
            )

        return schemas

    def _generate_interface_definitions(self, category: str) -> list[str]:
        """Generate high-precision interface definitions (C++ Abstract Classes)."""
        interfaces = []
        if category == "FLOW":
            interfaces.extend(
                [
                    "*IFlowEngine*:",
                    "```cpp",
                    "class IFlowEngine {",
                    "public:",
                    "    virtual ~IFlowEngine() = default;",
                    "    virtual Result<UUID, Error> execute(const FlowDefinition& def) = 0;",
                    "    virtual Result<FlowStatus, Error> get_status(UUID flow_id) const = 0;",
                    "};",
                    "```",
                ]
            )
        elif category == "ANI":
            interfaces.extend(
                [
                    "*IMCPClient*:",
                    "```cpp",
                    "class IMCPClient {",
                    "public:",
                    "    virtual ~IMCPClient() = default;",
                    "    virtual Result<void, Error> connect(const std::string& uri) = 0;",
                    "    virtual Result<Response, Error> call(const Request& req) = 0;",
                    "};",
                    "```",
                ]
            )
        else:
            interfaces.append(
                "• *IDomainService*: Standard interface with execute() returning Result<T,E>."
            )

        return interfaces

    def _generate_state_machine_spec(self, category: str) -> list[str]:
        """Generate state machine specifications."""
        if category == "FLOW":
            return [
                "*States*: `Idle` -> `Validating` -> `Running` -> `Completed` | `Failed`",
                "*Transitions*:",
                "• `execute()`: `Idle` -> `Validating`",
                "• `validation_success`: `Validating` -> `Running`",
                "• `all_steps_done`: `Running` -> `Completed`",
                "• `error_encountered`: `*` -> `Failed`",
            ]
        elif category == "ANI":
            return [
                "*States*: `Disconnected` -> `Connecting` -> `Connected` -> `HandoffInProgress` -> `Disconnected`",
                "*Transitions*:",
                "• `connect()`: `Disconnected` -> `Connecting`",
                "• `on_ready`: `Connecting` -> `Connected`",
                "• `initiate_handoff`: `Connected` -> `HandoffInProgress`",
                "• `handoff_complete`: `HandoffInProgress` -> `Connected`",
            ]
        elif category == "AGENTIC":
            return [
                "*States*: `Idle` -> `Thinking` -> `Acting` -> `Reflecting` -> `Done`",
                "*Transitions*:",
                "• `receive_task`: `Idle` -> `Thinking`",
                "• `plan_ready`: `Thinking` -> `Acting`",
                "• `action_complete`: `Acting` -> `Reflecting`",
                "• `reflection_pass`: `Reflecting` -> `Done`",
                "• `reflection_fail`: `Reflecting` -> `Thinking`",
            ]
        return ["• *Standard Lifecycle*: `Created` -> `Active` -> `Inactive` -> `Deleted`"]

    def _generate_auth_flow_spec(self, category: str) -> list[str]:
        """Generate authentication and authorization flow specifications."""
        _ = category
        return [
            "1. *Identity*: Resolve `user_id` from `ITokenService`.",
            "2. *Permission*: Check `governance.check_permission(user_id, Permission::Execute, resource_id)`.",
            "3. *Audit*: Log attempt via `IAuditLogger`.",
            "4. *Execution*: Proceed only if `is_allowed()` is true.",
        ]


# ============================================================================
# BUSINESS VALUE GENERATION
# ============================================================================


def generate_business_value(category: str, title: str, description: str) -> str:
    """Generate business value statement based on story category and content."""
    # title and description reserved for future NLP-based ROI extraction
    _ = title, description

    # Extract user personas by category
    personas = {
        "FLOW": "AI Workflow Engineers, Enterprise Developers",
        "ANI": "Multi-Agent System Architects, Integration Engineers",
        "MCP": "Tool Developers, Integration Platform Teams",
        "AGENTIC": "AI Engineers, ML Platform Teams",
        "GTM": "End Users, Product Managers, Sales Teams",
        "EVAL": "ML Engineers, Model Training Teams",
        "DEFAULT": "Platform Engineers, Enterprise Developers",
    }

    # ROI calculation heuristics
    roi_metrics = {
        "FLOW": "30% reduction in workflow development time, 50% faster debugging cycles",
        "ANI": "10x improvement in multi-agent coordination latency, 80% reduction in integration effort",
        "MCP": "50% reduction in tool integration time, universal tool compatibility",
        "AGENTIC": "40% improvement in response quality, 25% reduction in hallucinations",
        "GTM": "2x faster time-to-value, 60% reduction in onboarding friction",
        "EVAL": "80% reduction in training experiment time, 3x faster model iteration",
        "DEFAULT": "Improved developer productivity, reduced technical debt",
    }

    # Success metrics
    success_metrics = {
        "FLOW": "Developer adoption >70%, workflow completion rate >90%",
        "ANI": "Agent handoff success rate >95%, message latency <100ms p99",
        "MCP": "Tool discovery success >99%, execution reliability >99.9%",
        "AGENTIC": "Response quality score >8/10, hallucination rate <5%",
        "GTM": "User activation rate >60%, NPS >50",
        "EVAL": "Training success rate >95%, artifact reuse >80%",
        "DEFAULT": "Test coverage >85%, zero critical bugs in production",
    }

    persona = personas.get(category, personas["DEFAULT"])
    roi = roi_metrics.get(category, roi_metrics["DEFAULT"])
    metrics = success_metrics.get(category, success_metrics["DEFAULT"])

    return f"""*User Personas*: {persona}

*ROI*: {roi}

*Success Metrics*: {metrics}

*Business Impact*: This capability is critical for enterprise adoption in Government/Healthcare/Finance/Legal sectors where {category.lower()} functionality is a differentiator."""


# ============================================================================
# CODE EXAMPLES GENERATION
# ============================================================================


def generate_code_examples_from_context(
    story_context: "StoryContext", category: str, title: str, description: str
) -> list[str]:
    """Generate code examples from resolved story context.

    Uses story-specific code examples when available from the domain
    knowledge base, falls back to category-based generation.
    """
    if story_context.code_examples:
        return story_context.code_examples

    # Fall back to category-based examples
    return generate_code_examples(category, title, description)


def generate_code_examples(category: str, title: str, description: str) -> list[str]:
    """Generate technology-specific code examples based on story category."""
    # title reserved for future pattern detection
    _ = title

    examples = []

    if category == "FLOW" or "bridge" in description.lower() or "n-api" in description.lower():
        examples.append("""*N-API Bridge Example (TypeScript → C++)*:
```typescript
// TypeScript side (Flow UI)
import { createNativeBridge } from './native-bridge';

const bridge = createNativeBridge();
const result = await bridge.executeWorkflow({
  agentId: 'agent-123',
  input: { task: 'Analyze code' }
});
```

```cpp
// C++ side (Core Agent)
#include <napi.h>
#include "core/agents/agent_runtime.hpp"

Napi::Value ExecuteWorkflow(const Napi::CallbackInfo& info) {
    auto env = info.Env();
    auto config = ParseConfig(info[0]);

    auto result = inovagio::core::agents::AgentRuntime::execute(
        config.agent_id,
        config.input
    );

    return result.is_ok()
        ? Napi::String::New(env, result.unwrap())
        : Napi::Error::New(env, result.error()).Value();
}
```""")

    if category == "ANI" or "multi-agent" in description.lower():
        examples.append("""*ANI Message Passing Example*:
```cpp
#include "core/ani/broker.hpp"
#include "core/ani/message.hpp"

auto broker = inovagio::core::ani::Broker::create();

// Send message to another agent
auto message = inovagio::core::ani::Message::builder()
    .from_agent("agent-1")
    .to_agent("agent-2")
    .payload(R"({"task": "process_data"})")
    .build();

auto result = broker.send(message);
if (!result.is_ok()) {
    LOG_ERROR("Failed to send ANI message: {}", result.error());
}
```""")

    # Thread safety example (universal)
    examples.append("""*Thread Safety Example*:
```cpp
#include "core/utils/threading/bounded_thread_pool.hpp"
#include <memory>
#include <mutex>

class SafeAgent {
private:
    mutable std::mutex mutex_;
    std::shared_ptr<AgentState> state_;

public:
    Result<Response, Error> process(Request req) {
        std::lock_guard<std::mutex> lock(mutex_);
        return state_->execute(req);
    }
};

// Use thread pool for async tasks
auto pool = inovagio::core::utils::BoundedThreadPool::create(4);
pool.submit([agent, req]() {
    return agent->process(req);
});
```""")

    # Error handling (universal)
    examples.append("""*Error Handling with Result<T, E>*:
```cpp
#include "core/models/result.hpp"

Result<Data, Error> fetch_data(const std::string& id) {
    if (id.empty()) {
        return Error::invalid_argument("id cannot be empty");
    }

    auto result = repository_->find(id);
    if (!result.has_value()) {
        return Error::not_found("Data not found: " + id);
    }

    return result.value();
}

// Usage
auto result = fetch_data("123");
if (result.is_ok()) {
    process(result.unwrap());
} else {
    LOG_ERROR("Failed: {}", result.error().message());
}
```""")

    return examples


# ============================================================================
# DEBUGGING GUIDE GENERATION
# ============================================================================


def generate_debugging_guide(category: str, title: str, description: str) -> list[str]:
    """Generate debugging guide based on technology stack."""
    # title and description reserved for future tool detection
    _ = title, description

    guide = []

    # C++ debugging (universal for core)
    guide.append("""*C++ Core Debugging (lldb/gdb)*:
```bash
# Build with debug symbols
cmake -B build -DCMAKE_BUILD_TYPE=Debug -DBUILD_TESTS=ON
cmake --build build

# Run with lldb
lldb build/bin/test_agent_runtime
(lldb) breakpoint set -n execute_workflow
(lldb) run
(lldb) thread backtrace
(lldb) frame variable
```""")

    # Memory leak detection
    guide.append("""*Memory Leak Detection (ASan)*:
```bash
# Build with AddressSanitizer
cmake -B build -DCMAKE_BUILD_TYPE=Debug \
    -DCMAKE_CXX_FLAGS="-fsanitize=address -fno-omit-frame-pointer"
cmake --build build

# Run tests with ASan
ASAN_OPTIONS=detect_leaks=1:symbolize=1 \
    ctest --test-dir build --output-on-failure

# Check for leaks
# ASan will print stack traces for any detected leaks
```""")

    if category == "FLOW" or "bridge" in description.lower():
        guide.append("""*N-API Bridge Debugging (Node.js)*:
```bash
# Enable Node.js inspector
node --inspect-brk dist/main.js

# Chrome DevTools
# Open chrome://inspect in Chrome
# Click "inspect" on your process

# Check bridge calls
console.log('Bridge call:', method, args);
try {
    const result = await nativeModule.call(method, args);
    console.log('Bridge result:', result);
} catch (err) {
    console.error('Bridge error:', err.message, err.stack);
}
```""")

    # Common failure modes
    guide.append("""*Common Failure Modes*:
1. **Segmentation Fault**: Check for null pointer dereference, use ASan
2. **Deadlock**: Enable TSan (`-fsanitize=thread`), check mutex ordering
3. **Memory Corruption**: Run valgrind (`valgrind --leak-check=full ./program`)
4. **Race Condition**: Use TSan, add thread-safety tests
5. **API Integration Failure**: Check logs for auth errors, rate limiting

*Troubleshooting Checklist*:
- [ ] Verify all tests pass (`ctest --output-on-failure`)
- [ ] Check sanitizers (ASan, UBSan, TSan)
- [ ] Review logs (`grep ERROR build/logs/*.log`)
- [ ] Validate input parameters (null checks, range checks)
- [ ] Confirm dependencies initialized (composition root)""")

    return guide


# ============================================================================
# JIRA ADF DOCUMENT GENERATOR (SOLID/DRY)
# ============================================================================


def generate_confluence_references(category: str) -> list[str]:
    """Generate Confluence documentation references as list of strings.

    Returns clean strings; formatting is handled by the DocumentWriter.
    """
    lines = []

    category_mappings = {
        "FLOW": ["Flow", "Architecture", "Development"],
        "AGENTIC": ["Patterns", "Architecture", "Development"],
        "ANI": ["ANI", "MCP", "Architecture", "Development"],
        "MCP": ["MCP", "ANI", "Architecture", "Development"],
        "NEXUS": ["MCP", "Architecture", "Domain", "Development"],
        "EVAL": ["EVAL", "Architecture", "Development"],
        "GTM": ["Flow", "Architecture", "Development"],
        "Orchestration": ["Orchestration", "Architecture", "Development"],
        "DEFAULT": ["Architecture", "Domain", "Development"],
    }

    themes = category_mappings.get(category, category_mappings["DEFAULT"])

    for theme in themes:
        if theme in CONFLUENCE_DOCS:
            # Add theme as a bold header line
            lines.append(f"*{theme}*")
            for doc_name, url in CONFLUENCE_DOCS[theme].items():
                # Include explicit URL text to preserve links across format conversions.
                lines.append(f"[{doc_name.title()}|{url}] ({url})")

    return lines


def _derive_story_persona(category: str) -> str:
    """Derive a primary persona for agile user-story formatting."""
    persona_map = {
        "FLOW": "workflow engineer",
        "AGENTIC": "AI engineer",
        "ANI": "platform integration engineer",
        "MCP": "capability platform engineer",
        "NEXUS": "enterprise platform engineer",
        "EVAL": "ML engineer",
        "GTM": "product user",
    }
    return persona_map.get(category, "platform engineer")


def _persona_with_article(persona: str) -> str:
    """Return persona with correct indefinite article for readable story text."""
    if not persona:
        return "a platform engineer"

    first = persona.strip().lower()[:1]
    article = "an" if first in {"a", "e", "i", "o", "u"} else "a"
    return f"{article} {persona}"


def _derive_story_value(analysis: ExpertAnalysis, category: str) -> str:
    """Derive a concise business value statement for the agile user story."""
    if analysis.business_value:
        for line in analysis.business_value.splitlines():
            text = line.strip()
            if text.startswith("*ROI*:"):
                return text.replace("*ROI*:", "", 1).strip()

        first_line = analysis.business_value.splitlines()[0].strip()
        if first_line:
            return first_line.replace("*User Personas*:", "", 1).strip()

    default_value = {
        "FLOW": "workflow delivery is faster and more reliable",
        "AGENTIC": "agent output quality improves with predictable behavior",
        "ANI": "multi-agent collaboration is reliable and observable",
        "MCP": "tool execution is secure, governed, and auditable",
        "NEXUS": "shared capabilities are reusable and policy-compliant",
        "EVAL": "model iteration is measurable and repeatable",
    }
    return default_value.get(category, "delivery is predictable, testable, and secure")


def _normalize_to_given_when_then(criteria: list[str], summary: str) -> list[str]:
    """Normalize criteria into GIVEN/WHEN/THEN format for Scrum readiness."""
    normalized: list[str] = []
    feature = summary.strip() if summary else "the requested capability"

    for criterion in criteria:
        text = str(criterion).strip()
        if not text:
            continue

        if re.search(r"\bGIVEN\b.*\bWHEN\b.*\bTHEN\b", text, flags=re.IGNORECASE):
            normalized.append(text)
            continue

        sentence = text.rstrip(".")
        if sentence:
            sentence = sentence[0].lower() + sentence[1:]
        normalized.append(f"GIVEN {feature} WHEN implementation is executed THEN {sentence}")

    return normalized


def format_enhanced_description(
    analysis: ExpertAnalysis,
    existing_description: str,
    summary: str = "",
    category: str = "DEFAULT",
    arch_review: Any | None = None,
) -> list[DocumentSection]:
    """Format expert analysis as list of DocumentSections.

    This follows DDD/SOLID:
    - Returns structured domain objects (DocumentSection)
    - Decoupled from final output format (ADF/Wiki)
    - Atomic sections for document building
    """
    sections = []

    # 1. Documentation References
    confluence_lines = generate_confluence_references(category)
    sections.append(DocumentSection(title="📚 Documentation References", content=confluence_lines))

    # 2. Professional Agile User Story
    persona = _persona_with_article(_derive_story_persona(category))
    value = _derive_story_value(analysis, category)
    capability = summary.strip() if summary else "implement the requested capability"
    sections.append(
        DocumentSection(
            title="🧾 Agile User Story",
            content=[
                f"As {persona}, I want {capability}, so that {value}.",
                "Story Quality Standard: INVEST-compliant, testable, and architecture-aligned.",
            ],
        )
    )

    # 3. Overview (if available)
    # Extract original story content by sanitizing the existing description
    if existing_description:
        cleaned = sanitize_description(existing_description)
        # Only add if there's meaningful content left (original story intent)
        if cleaned and len(cleaned) > 10:
            sections.append(DocumentSection(title="📋 Overview", content=[cleaned]))

    # 4. Architecture Review (if available)
    if arch_review:
        arch_content = [
            f"*Architecture Score*: {arch_review.grade} ({arch_review.score}/100)",
            f"*Documentation*: {arch_review.arch_doc_link or 'Not linked'}",
        ]

        if arch_review.proposed_architecture_requirements:
            arch_content.append("")
            arch_content.append("*Proposed Architecture Requirements*:")
            arch_content.extend(arch_review.proposed_architecture_requirements)

        if arch_review.proposed_nfr_section:
            arch_content.append("")
            arch_content.append("*Non-Functional Requirements*:")
            # Split by newline to handle the string format
            arch_content.extend(arch_review.proposed_nfr_section.split("\n"))

        sections.append(DocumentSection(title="🏛️ Architecture Review", content=arch_content))

        # Add Architecture Findings & Recommendations section (ALL findings and suggestions)
        if arch_review.findings or arch_review.suggestions:
            findings_content = []

            if arch_review.findings:
                findings_content.append("*Findings*:")
                for finding in arch_review.findings:
                    findings_content.append(f"• {finding}")
                findings_content.append("")

            if arch_review.suggestions:
                findings_content.append("*Concrete Implementation Guidance*:")
                findings_content.append("")
                # Suggestions now contain formatted code blocks - don't add bullet points
                for suggestion in arch_review.suggestions:
                    findings_content.append(suggestion)
                    findings_content.append("")

            sections.append(
                DocumentSection(
                    title="🔍 Architecture Findings & Recommendations",
                    content=findings_content,
                )
            )

        # NEW: Add concrete implementations section (filled from codebase analysis)
        if arch_review.concrete_implementations:
            impl_content = []
            impl_content.append("*Concrete Implementations from Codebase Analysis*:")
            impl_content.append("")
            for (
                capability,
                implementation,
            ) in arch_review.concrete_implementations.items():
                impl_content.append(f"*{capability}*:")
                impl_content.append(implementation)
                impl_content.append("")

            sections.append(
                DocumentSection(title="💡 Concrete Implementation Guidance", content=impl_content)
            )

        # NEW: Add DDD/SOLID explanation section
        if arch_review.ddd_solid_explanation:
            sections.append(
                DocumentSection(
                    title="🏗️ DDD & SOLID Principles",
                    content=[arch_review.ddd_solid_explanation],
                )
            )

        # NEW: Add relevant code examples section
        if arch_review.relevant_code_examples:
            code_examples_content = []
            code_examples_content.append("*Code Examples from Existing Components*:")
            code_examples_content.append("")
            for component, example in arch_review.relevant_code_examples.items():
                code_examples_content.append(f"*{component} Example*:")
                code_examples_content.append(example)
                code_examples_content.append("")

            sections.append(
                DocumentSection(
                    title="📋 Code Examples from Codebase",
                    content=code_examples_content,
                )
            )

    # 5. Acceptance Criteria
    normalized_criteria = _normalize_to_given_when_then(analysis.acceptance_criteria, summary)
    sections.append(
        DocumentSection(
            title="🎯 Acceptance Criteria",
            content=normalized_criteria,
            section_type="checklist",
        )
    )

    # 6. Business Value (NEW - INOV-520 level detail)
    if analysis.business_value:
        sections.append(
            DocumentSection(title="💰 Business Value", content=[analysis.business_value])
        )

    # 7. Technical Approach (enhanced with story context)
    ta = analysis.technical_approach
    story_ctx = getattr(analysis, "story_context", None)

    # Use story-specific layer placement if available
    layer_text = ta.get("layer_placement", "Layer 3")
    if story_ctx and story_ctx.layer_placement:
        layer_text = story_ctx.layer_placement
    ta_content = [f"*Layer Placement*: {layer_text}"]

    # Bounded context (from story context if available)
    if story_ctx and story_ctx.primary_bounded_context:
        ctx_text = f"*Bounded Context*: {story_ctx.primary_bounded_context}"
        if story_ctx.secondary_bounded_contexts:
            ctx_text += f" (also: {', '.join(story_ctx.secondary_bounded_contexts)})"
        ta_content.append(ctx_text)

    if ta.get("key_components"):
        ta_content.append("*Key Components*:")
        for name, desc in ta.get("key_components", []):
            ta_content.append(f"• *{name}*: {desc}")

    # Use story-specific design patterns if available
    patterns = ta.get("design_patterns", [])
    if story_ctx and story_ctx.design_patterns:
        patterns = story_ctx.design_patterns
    if patterns:
        ta_content.append(f"*Design Patterns*: {', '.join(patterns)}")

    if ta.get("integration_points"):
        ta_content.append("*Integration Points*:")
        for ip in ta.get("integration_points", []):
            ta_content.append(f"• {ip}")

    # Story dependency tracking
    if story_ctx and story_ctx.depends_on_stories:
        ta_content.append("*Dependencies*:")
        for dep in story_ctx.depends_on_stories:
            ta_content.append(f"• {dep}")

    if story_ctx and story_ctx.adjacent_stories:
        ta_content.append("*Related Stories*:")
        for adj in story_ctx.adjacent_stories:
            ta_content.append(f"• {adj}")

    if analysis.security_requirements:
        ta_content.append("*Security Considerations*:")
        for req in analysis.security_requirements[:3]:
            ta_content.append(f"• {req}")

    sections.append(DocumentSection(title="🏗️ Technical Approach", content=ta_content))

    # 8. Code Examples (NEW - INOV-520 level detail)
    if analysis.code_examples:
        sections.append(DocumentSection(title="💻 Code Examples", content=analysis.code_examples))

    # 9. Data Schemas & Interfaces (AI-Ready)
    if analysis.data_schemas or analysis.interface_definitions:
        tech_specs = []
        if analysis.data_schemas:
            tech_specs.append("*Data Schemas*:")
            tech_specs.extend(analysis.data_schemas)

        if analysis.interface_definitions:
            if tech_specs:
                tech_specs.append("")  # Spacer
            tech_specs.append("*Interface Definitions*:")
            tech_specs.extend(analysis.interface_definitions)

        sections.append(DocumentSection(title="📐 Technical Specifications", content=tech_specs))

    # 10. State Machine & Auth Flows
    if analysis.state_machine_spec or analysis.auth_flow_spec:
        flow_specs = []
        if analysis.state_machine_spec:
            flow_specs.append("*State Machine*:")
            flow_specs.extend(analysis.state_machine_spec)

        if analysis.auth_flow_spec:
            if flow_specs:
                flow_specs.append("")  # Spacer
            flow_specs.append("*Auth & Governance Flow*:")
            flow_specs.extend(analysis.auth_flow_spec)

        sections.append(DocumentSection(title="🔄 Logic & Security Flows", content=flow_specs))

    # 11. Testing Strategy
    ts = analysis.testing_strategy
    ts_content = []

    if ts.get("unit_tests"):
        ts_content.append("*Unit Tests*:")
        for t in ts.get("unit_tests", [])[:4]:
            ts_content.append(f"• {t}")

    if ts.get("integration_tests"):
        ts_content.append("*Integration Tests*:")
        for t in ts.get("integration_tests", [])[:3]:
            ts_content.append(f"• {t}")

    if ts.get("edge_cases"):
        ts_content.append("*Edge Cases*:")
        for t in ts.get("edge_cases", [])[:3]:
            ts_content.append(f"• {t}")

    ts_content.append("*Traceability*:")
    ts_content.append("• Each acceptance criterion MUST map to at least one automated test case")
    ts_content.append("• Test evidence MUST be attached in Jira/CI output before story closure")

    sections.append(DocumentSection(title="🧪 Testing Strategy", content=ts_content))

    # 12. Debugging Guide (NEW - INOV-520 level detail)
    if analysis.debugging_guide:
        sections.append(
            DocumentSection(title="🔧 Debugging Guide", content=analysis.debugging_guide)
        )

    # 13. Definition of Done
    dod_content = list(analysis.definition_of_done)
    dod_content.append(
        "Confluence technical references include architecture + implementation guidance links"
    )
    dod_content.append(
        "Acceptance criteria, test plan, and architecture constraints are mutually consistent"
    )
    sections.append(
        DocumentSection(
            title="✅ Definition of Done",
            content=dod_content,
            section_type="checklist",
        )
    )

    # 14. Implementation Notes
    if analysis.implementation_notes:
        sections.append(
            DocumentSection(title="📝 Implementation Notes", content=analysis.implementation_notes)
        )

    return sections
