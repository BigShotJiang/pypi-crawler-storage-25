#!/usr/bin/env python3
"""
Markdown to Readable Confluence Formatter

Converts markdown documentation into human-readable Confluence Storage Format (XHTML)
with proper structure, white space, and visual hierarchy.

Author: Inovagio Engineering Team
Date: December 23, 2025
"""

import re
from dataclasses import dataclass


@dataclass
class Section:
    """Represents a document section with hierarchy"""

    level: int  # 1-6 for H1-H6
    title: str
    content: list[str]
    subsections: list["Section"]


class MarkdownConfluenceFormatter:
    """
    Converts markdown to readable Confluence Storage Format.

    Key principles:
    1. Clear hierarchy with proper heading levels
    2. White space between sections
    3. Structured lists and tables
    4. Code blocks with syntax highlighting
    5. Info/warning panels for callouts
    6. Expandable sections for long content
    """

    def __init__(self):
        self.section_stack: list[Section] = []

    def parse_markdown_to_sections(self, markdown: str) -> list[Section]:
        """Parse markdown into hierarchical sections"""
        lines = markdown.split("\n")
        root_sections: list[Section] = []
        current_section: Section | None = None
        content_buffer: list[str] = []

        for line in lines:
            # Match heading
            heading_match = re.match(r"^(#{1,6})\s+(.+)$", line)

            if heading_match:
                # Save previous section
                if current_section:
                    current_section.content = content_buffer
                    root_sections.append(current_section)

                # Start new section
                level = len(heading_match.group(1))
                title = heading_match.group(2).strip()
                current_section = Section(level=level, title=title, content=[], subsections=[])
                content_buffer = []
            else:
                content_buffer.append(line)

        # Save last section
        if current_section:
            current_section.content = content_buffer
            root_sections.append(current_section)

        return root_sections

    def markdown_to_confluence(self, markdown: str, max_section_depth: int = 3) -> str:
        """
        Convert markdown to readable Confluence Storage Format.

        Args:
            markdown: Input markdown text
            max_section_depth: Maximum depth before using expandable sections (default 3)

        Returns:
            Confluence Storage Format XHTML
        """
        # Parse into sections
        sections = self.parse_markdown_to_sections(markdown)

        # Build Confluence XHTML
        confluence_xhtml = []

        # Add table of contents for long documents
        if len(sections) > 3:
            confluence_xhtml.append(self._generate_toc())
            confluence_xhtml.append("<hr />")

        # Convert each section
        for section in sections:
            confluence_xhtml.append(self._section_to_confluence(section, max_section_depth))
            confluence_xhtml.append("<hr />")  # Visual separator between major sections

        return "\n\n".join(confluence_xhtml)

    def _generate_toc(self) -> str:
        """Generate table of contents macro"""
        return """
<ac:structured-macro ac:name="toc">
  <ac:parameter ac:name="printable">true</ac:parameter>
  <ac:parameter ac:name="style">square</ac:parameter>
  <ac:parameter ac:name="maxLevel">3</ac:parameter>
  <ac:parameter ac:name="minLevel">1</ac:parameter>
</ac:structured-macro>
"""

    def _section_to_confluence(
        self, section: Section, max_depth: int, current_depth: int = 1
    ) -> str:
        """Convert a section to Confluence XHTML"""
        parts = []

        # Section heading
        heading_level = min(section.level, 6)
        parts.append(f"<h{heading_level}>{self._escape_html(section.title)}</h{heading_level}>")
        parts.append("")  # White space after heading

        # Section content
        content_html = self._convert_content_block(section.content)

        # Use expandable section if too deep
        if current_depth > max_depth and content_html.strip():
            parts.append(self._wrap_in_expand(section.title, content_html))
        else:
            parts.append(content_html)

        # Add white space after content
        parts.append("")

        # Convert subsections
        for subsection in section.subsections:
            parts.append(self._section_to_confluence(subsection, max_depth, current_depth + 1))

        return "\n".join(parts)

    def _convert_content_block(self, lines: list[str]) -> str:
        """Convert content lines to Confluence HTML"""
        if not lines:
            return ""

        content = "\n".join(lines).strip()
        if not content:
            return ""

        # Process markdown elements
        html_parts = []

        # Split by major blocks (code, tables, lists, paragraphs)
        blocks = self._split_into_blocks(content)

        for block_type, block_content in blocks:
            if block_type == "code":
                html_parts.append(self._convert_code_block(block_content))
            elif block_type == "table":
                html_parts.append(self._convert_table(block_content))
            elif block_type == "list":
                html_parts.append(self._convert_list(block_content))
            elif block_type == "blockquote":
                html_parts.append(self._convert_blockquote(block_content))
            elif block_type == "paragraph":
                html_parts.append(self._convert_paragraph(block_content))

            html_parts.append("")  # White space between blocks

        return "\n".join(html_parts)

    def _split_into_blocks(self, content: str) -> list[tuple[str, str]]:
        """Split content into typed blocks"""
        blocks = []
        lines = content.split("\n")
        i = 0

        while i < len(lines):
            line = lines[i]

            # Code block
            if line.startswith("```"):
                code_lines = [line]
                i += 1
                while i < len(lines) and not lines[i].startswith("```"):
                    code_lines.append(lines[i])
                    i += 1
                if i < len(lines):
                    code_lines.append(lines[i])  # Closing ```
                blocks.append(("code", "\n".join(code_lines)))
                i += 1
                continue

            # Table
            if "|" in line and i + 1 < len(lines) and "|" in lines[i + 1]:
                table_lines = []
                while i < len(lines) and "|" in lines[i]:
                    table_lines.append(lines[i])
                    i += 1
                blocks.append(("table", "\n".join(table_lines)))
                continue

            # List
            if re.match(r"^\s*[-*+]\s+", line) or re.match(r"^\s*\d+\.\s+", line):
                list_lines = []
                while i < len(lines) and (
                    re.match(r"^\s*[-*+]\s+", lines[i])
                    or re.match(r"^\s*\d+\.\s+", lines[i])
                    or (lines[i].strip() == "")
                ):
                    list_lines.append(lines[i])
                    i += 1
                blocks.append(("list", "\n".join(list_lines)))
                continue

            # Blockquote
            if line.startswith(">"):
                quote_lines = []
                while i < len(lines) and lines[i].startswith(">"):
                    quote_lines.append(lines[i])
                    i += 1
                blocks.append(("blockquote", "\n".join(quote_lines)))
                continue

            # Paragraph
            if line.strip():
                para_lines = []
                while i < len(lines) and lines[i].strip() and not lines[i].startswith("#"):
                    para_lines.append(lines[i])
                    i += 1
                blocks.append(("paragraph", "\n".join(para_lines)))
                continue

            i += 1

        return blocks

    def _convert_code_block(self, code: str) -> str:
        """Convert code block to Confluence code macro"""
        lines = code.split("\n")

        # Extract language
        language = "text"
        if lines[0].startswith("```"):
            lang_match = re.match(r"```(\w+)", lines[0])
            if lang_match:
                language = lang_match.group(1)
            lines = lines[1:]  # Remove opening ```

        if lines and lines[-1].startswith("```"):
            lines = lines[:-1]  # Remove closing ```

        code_content = "\n".join(lines)

        return f"""
<ac:structured-macro ac:name="code">
  <ac:parameter ac:name="language">{language}</ac:parameter>
  <ac:parameter ac:name="linenumbers">true</ac:parameter>
  <ac:plain-text-body><![CDATA[{code_content}]]></ac:plain-text-body>
</ac:structured-macro>
"""

    def _convert_table(self, table: str) -> str:
        """Convert markdown table to HTML table"""
        lines = [line.strip() for line in table.split("\n") if line.strip()]
        if len(lines) < 2:
            return ""

        # Parse header
        header_cells = [cell.strip() for cell in lines[0].split("|")[1:-1]]

        # Skip separator line (lines[1])

        # Parse rows
        rows = []
        for line in lines[2:]:
            cells = [cell.strip() for cell in line.split("|")[1:-1]]
            rows.append(cells)

        # Build HTML table
        html = ["<table>"]
        html.append("  <thead>")
        html.append("    <tr>")
        for cell in header_cells:
            html.append(f"      <th>{self._inline_markdown(cell)}</th>")
        html.append("    </tr>")
        html.append("  </thead>")
        html.append("  <tbody>")

        for row in rows:
            html.append("    <tr>")
            for cell in row:
                html.append(f"      <td>{self._inline_markdown(cell)}</td>")
            html.append("    </tr>")

        html.append("  </tbody>")
        html.append("</table>")

        return "\n".join(html)

    def _convert_list(self, list_content: str) -> str:
        """Convert markdown list to HTML list"""
        lines = [line for line in list_content.split("\n") if line.strip()]
        if not lines:
            return ""

        # Detect list type
        is_ordered = bool(re.match(r"^\s*\d+\.", lines[0]))
        tag = "ol" if is_ordered else "ul"

        html = [f"<{tag}>"]

        for line in lines:
            # Extract list item content
            match = re.match(r"^\s*(?:\d+\.|-|\*|\+)\s+(.+)$", line)
            if match:
                content = match.group(1)
                html.append(f"  <li>{self._inline_markdown(content)}</li>")

        html.append(f"</{tag}>")

        return "\n".join(html)

    def _convert_blockquote(self, quote: str) -> str:
        """Convert blockquote to Confluence info panel"""
        lines = [line.lstrip(">").strip() for line in quote.split("\n")]
        content = " ".join(lines)

        # Detect callout type
        if content.lower().startswith("warning") or content.lower().startswith("⚠"):
            panel_type = "warning"
            title = "Warning"
        elif content.lower().startswith("note") or content.lower().startswith("ℹ"):
            panel_type = "note"
            title = "Note"
        else:
            panel_type = "info"
            title = "Info"

        return f"""
<ac:structured-macro ac:name="{panel_type}">
  <ac:parameter ac:name="title">{title}</ac:parameter>
  <ac:rich-text-body>
    <p>{self._inline_markdown(content)}</p>
  </ac:rich-text-body>
</ac:structured-macro>
"""

    def _convert_paragraph(self, para: str) -> str:
        """Convert paragraph to HTML"""
        # Process inline markdown
        html = self._inline_markdown(para)
        return f"<p>{html}</p>"

    def _inline_markdown(self, text: str) -> str:
        """Convert inline markdown (bold, italic, code, links)"""
        # Bold (**text** or __text__)
        text = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)
        text = re.sub(r"__(.+?)__", r"<strong>\1</strong>", text)

        # Italic (*text* or _text_)
        text = re.sub(r"\*(.+?)\*", r"<em>\1</em>", text)
        text = re.sub(r"_(.+?)_", r"<em>\1</em>", text)

        # Inline code (`code`)
        text = re.sub(r"`(.+?)`", r"<code>\1</code>", text)

        # Links [text](url)
        text = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', text)

        # Checkboxes
        text = text.replace("- [ ]", "☐")
        text = text.replace("- [x]", "☑")
        text = text.replace("- [X]", "☑")

        # Emojis (common ones)
        text = text.replace("✅", "✅")
        text = text.replace("❌", "❌")
        text = text.replace("⚠️", "⚠️")
        text = text.replace("🔴", "🔴")
        text = text.replace("🟡", "🟡")
        text = text.replace("🟢", "🟢")

        return text

    def _wrap_in_expand(self, title: str, content: str) -> str:
        """Wrap content in expandable section"""
        return f"""
<ac:structured-macro ac:name="expand">
  <ac:parameter ac:name="title">{self._escape_html(title)}</ac:parameter>
  <ac:rich-text-body>
{content}
  </ac:rich-text-body>
</ac:structured-macro>
"""

    def _escape_html(self, text: str) -> str:
        """Escape HTML special characters"""
        return (
            text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
            .replace("'", "&#39;")
        )


def format_implementation_plan_for_confluence(markdown_file_path: str) -> str:
    """
    Convert implementation plan markdown to readable Confluence format.

    This is the main entry point for the CLI tool.

    Args:
        markdown_file_path: Path to markdown implementation plan

    Returns:
        Confluence Storage Format XHTML (readable, well-structured)
    """
    with open(markdown_file_path, encoding="utf-8") as file_handle:
        markdown_content = file_handle.read()

    formatter = MarkdownConfluenceFormatter()
    return formatter.markdown_to_confluence(markdown_content)


# Example usage
if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage: markdown_formatter.py <markdown_file>")
        sys.exit(1)

    markdown_file = sys.argv[1]
    confluence_html = format_implementation_plan_for_confluence(markdown_file)

    # Output to file or stdout
    if len(sys.argv) > 2:
        output_file = sys.argv[2]
        with open(output_file, "w", encoding="utf-8") as output_handle:
            output_handle.write(confluence_html)
        print(f"✅ Formatted Confluence HTML written to {output_file}")
    else:
        print(confluence_html)
