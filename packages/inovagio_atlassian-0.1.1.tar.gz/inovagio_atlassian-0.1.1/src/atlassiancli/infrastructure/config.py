#!/usr/bin/env python3
"""
Configuration Management

Centralized configuration for v3 architecture.
Loaded from environment variables.

Author: Inovagio Engineering Team
"""

import os
from dataclasses import dataclass

from atlassiancli.infrastructure.env_loader import load_env_file

load_env_file(".env")


def _first_env(*names: str, default: str = "") -> str:
    """Return the first non-empty value among the named env vars.

    Falls back to ``default`` if none of the names is set or if every value
    is the empty string.
    """
    for name in names:
        value = os.getenv(name)
        if value:
            return value
    return default


@dataclass(frozen=True)
class AtlassianConfig:
    """Immutable configuration"""

    # API Configuration
    base_url: str
    api_token: str
    user_email: str

    # Project Configuration
    project_key: str
    board_id: int

    # Custom Field IDs
    story_points_field: str
    sprint_field: str
    epic_link_field: str

    # Sprint Configuration
    default_sprint_capacity: int
    max_story_points: int

    # Confluence
    confluence_space: str
    confluence_parent_page_id: (
        str  # Parent page ID for auto-generated docs (Engineering Documentation)
    )

    @classmethod
    def from_environment(cls) -> "AtlassianConfig":
        """Load configuration from environment variables (legacy entry).

        Equivalent to :meth:`from_profile` with no profile (env vars only).
        Kept so existing callers in tests and CI scripts don't break.
        """
        return cls.from_profile(profile_name=None)

    @classmethod
    def from_profile(
        cls,
        *,
        profile_name: str | None = None,
        config_path: str | None = None,
    ) -> "AtlassianConfig":
        """Load configuration with the documented precedence chain.

        Highest priority first:

        1. ``config_path`` — explicit path to a profile TOML file.
        2. Environment variables (``ATLASSIAN_TOKEN`` etc.).
        3. ``~/.atlassiancli/<profile_name>.toml`` (or
           ``$ATLASSIAN_PROFILE`` if ``profile_name`` is None, falling back
           to ``default``).
        4. Hardcoded project defaults.
        """
        # Lazy import — profile_store is in the application layer; importing
        # at module top would risk a cycle if that ever grows a dep on us.
        from ..application.profile_store import (
            DEFAULT_PROFILE_NAME,
            Profile,
            ProfileStore,
            resolve_profile_name,
        )

        store = ProfileStore()
        if config_path:
            import tomllib
            from pathlib import Path

            from ..application.profile_store import Profile as _Profile

            cp = Path(config_path)
            if cp.is_file():
                with cp.open("rb") as fh:
                    raw = tomllib.load(fh)
                profile = _Profile(
                    name=str(raw.get("name", "<config>")),
                    base_url=str(raw.get("base_url", "")),
                    user_email=str(raw.get("user_email", "")),
                    api_token=str(raw.get("api_token", "")),
                    project_key=str(raw.get("project_key", "")),
                    confluence_space=str(raw.get("confluence_space", "")),
                )
            else:
                # Empty profile — env vars + hardcoded defaults still apply.
                profile = Profile(name="<config-missing>")
        else:
            name = resolve_profile_name(profile_name, default=DEFAULT_PROFILE_NAME)
            profile = store.load(name)

        merged = profile.merged_with_env()

        return cls(
            base_url=merged["base_url"] or "https://inovagio.atlassian.net",
            # ATLASSIAN_TOKEN is the shorter form most operators use; the
            # legacy `atlassian_API_key` and `ATLASSIAN_API_TOKEN` names
            # remain valid for backwards compatibility (handled by Profile).
            api_token=merged["api_token"],
            user_email=merged["user_email"] or "brian@inovagio.com",
            project_key=merged["project_key"] or os.getenv("JIRA_PROJECT_KEY", "INOV"),
            board_id=int(os.getenv("JIRA_BOARD_ID", "35")),
            story_points_field=os.getenv("JIRA_STORY_POINTS_FIELD", "customfield_10036"),
            sprint_field=os.getenv("JIRA_SPRINT_FIELD", "customfield_10020"),
            epic_link_field=os.getenv("JIRA_EPIC_LINK_FIELD", "customfield_10014"),
            default_sprint_capacity=int(os.getenv("DEFAULT_SPRINT_CAPACITY", "55")),
            max_story_points=int(os.getenv("MAX_STORY_POINTS", "8")),
            confluence_space=merged["confluence_space"] or os.getenv("CONFLUENCE_SPACE", "INOV"),
            confluence_parent_page_id=os.getenv(
                "CONFLUENCE_PARENT_PAGE_ID", "150667282"
            ),  # Engineering Documentation
        )

    def validate(self) -> bool:
        """Validate configuration"""
        if not self.api_token:
            raise ValueError("atlassian_API_key not found in environment")
        if not self.base_url:
            raise ValueError("Atlassian_ORGANIZATION_URL not found")
        return True
