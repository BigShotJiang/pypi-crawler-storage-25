#!/usr/bin/env python3
"""
Confluence Architecture Analyzer - Expert Solution Architect for Jira Issue Generation

This module acts as an expert solution architect that:
1. Analyzes Confluence architecture documentation semantically
2. Understands Inovagio's DDD architecture and bounded contexts
3. Identifies implementation work items based on software engineering best practices
4. Generates properly structured epics/stories/tasks with real acceptance criteria

NOT a naive parser - an intelligent analyzer that creates engineering work items.

REFACTORED FOR DDD/SOLID COMPLIANCE:
- Implements IDocumentAnalyzer interface (Interface Segregation)
- Uses unified ParsedWorkItem/DocumentAnalysisResult (DRY - no duplicate types)
- Uses IConfluenceRepository for page operations (no duplicate API calls)
- Uses IThemeDetector for theme detection (single source of truth)
- Uses IBoundedContextResolver for context resolution (single source of truth)
- Uses IPriorityCalculator for priority calculation (single source of truth)

Author: Inovagio Engineering Team
"""

import html
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from ..domain.models import Epic, Story, Task
from ..domain.repositories import ConfluencePage, IConfluenceRepository, IIssueRepository
from ..domain.services import (
    CodebaseValidationResult,
    DocumentAnalysisResult,
    DocumentSource,
    IBoundedContextResolver,
    ICodebaseCrossReferencer,
    IDocumentAnalyzer,
    IPriorityCalculator,
    IThemeDetector,
    ParsedWorkItem,
)
from ..domain.value_objects import (
    AcceptanceCriterion,
    ConfluencePageId,
    IssueKey,
    IssueType,
    Label,
    Priority,
    SprintIdentifier,
    get_bounded_context,
)

# ============================================================================
# INOVAGIO ARCHITECTURE KNOWLEDGE BASE
# ============================================================================


class InovagioLayer(Enum):
    """DDD Layer hierarchy - dependencies flow DOWN only"""

    FOUNDATION = 0  # core-models: Universal types, IDs, value objects
    INFRASTRUCTURE = 1  # core-utils: Thread pools, logging, serialization
    CROSS_CUTTING = 2  # core-governance, core-persistence: RBAC, audit, storage
    DOMAIN_SERVICES = 3  # core-connectors, core-ani, core-agents, core-orchestration


# Bounded contexts and their responsibilities
BOUNDED_CONTEXTS = {
    "core-models": {
        "layer": InovagioLayer.FOUNDATION,
        "responsibilities": ["Domain primitives", "Value objects", "Entity IDs", "Result types"],
        "patterns": ["Value Object", "Entity", "Aggregate Root"],
    },
    "core-utils": {
        "layer": InovagioLayer.INFRASTRUCTURE,
        "responsibilities": ["Thread pools", "Logging", "Serialization", "Event bus"],
        "patterns": ["Observer", "Singleton (composition root only)"],
    },
    "core-governance": {
        "layer": InovagioLayer.CROSS_CUTTING,
        "responsibilities": ["RBAC", "Audit logging", "Compliance", "Policy enforcement"],
        "patterns": ["Strategy", "Chain of Responsibility", "Decorator"],
    },
    "core-persistence": {
        "layer": InovagioLayer.CROSS_CUTTING,
        "responsibilities": ["Repository abstractions", "Unit of Work", "Event sourcing"],
        "patterns": ["Repository", "Unit of Work", "Event Sourcing"],
    },
    "core-connectors": {
        "layer": InovagioLayer.DOMAIN_SERVICES,
        "responsibilities": ["External system integration", "API clients", "Protocol adapters"],
        "patterns": ["Adapter", "Gateway", "Anti-Corruption Layer"],
    },
    "core-ani": {
        "layer": InovagioLayer.DOMAIN_SERVICES,
        "responsibilities": [
            "Agent Network Interface",
            "Multi-agent messaging",
            "Protocol routing",
        ],
        "patterns": ["Mediator", "Protocol Buffer", "Message Queue"],
    },
    "core-agents": {
        "layer": InovagioLayer.DOMAIN_SERVICES,
        "responsibilities": ["Agent lifecycle", "LLM clients", "Tool execution"],
        "patterns": ["Strategy", "State", "Template Method"],
    },
    "core-orchestration": {
        "layer": InovagioLayer.DOMAIN_SERVICES,
        "responsibilities": ["Workflow engine", "DAG execution", "Scheduling"],
        "patterns": ["Command", "State Machine", "Saga"],
    },
}

# Implementation patterns that generate specific story types
IMPLEMENTATION_PATTERNS: dict[str, dict[str, Any]] = {
    "interface_definition": {
        "story_template": "Define {name} Interface",
        "acceptance_criteria": [
            "Pure virtual interface defined in header",
            "No implementation dependencies",
            "Documented with Doxygen comments",
            "Unit tests for interface contracts",
        ],
        "story_points": 3,
    },
    "concrete_implementation": {
        "story_template": "Implement {name}",
        "acceptance_criteria": [
            "Implements interface contract completely",
            "Follows SOLID principles",
            "Unit tests with >85% coverage",
            "Integration tests with dependent components",
            "Error handling with Result<T,E> pattern",
        ],
        "story_points": 5,
    },
    "protocol_integration": {
        "story_template": "Integrate {name} Protocol",
        "acceptance_criteria": [
            "Protocol adapter implements gateway interface",
            "Message serialization/deserialization tested",
            "Error handling for network failures",
            "Retry logic with exponential backoff",
            "Observability: metrics and tracing",
        ],
        "story_points": 8,
    },
    "event_sourcing": {
        "story_template": "Implement Event Sourcing for {name}",
        "acceptance_criteria": [
            "Event store interface defined",
            "Events are immutable value objects",
            "Aggregate reconstruction from events",
            "Snapshot support for performance",
            "Event versioning strategy documented",
        ],
        "story_points": 8,
    },
    "security_implementation": {
        "story_template": "Implement Security for {name}",
        "acceptance_criteria": [
            "Uses centralized ICryptoService (no hand-rolled crypto)",
            "RBAC checks at application boundary",
            "Audit logging for security events",
            "Secrets accessed via ISecretsProvider",
            "TLS 1.2+ for all external communication",
        ],
        "story_points": 5,
    },
}


@dataclass
class ArchitecturalComponent:
    """A component identified from architecture documentation"""

    name: str
    component_type: str  # interface, service, adapter, gateway, etc.
    bounded_context: str
    description: str
    responsibilities: list[str] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)
    patterns: list[str] = field(default_factory=list)
    priority: str = "Medium"
    source_page: str | None = None


@dataclass
class ImplementationWorkItem:
    """A work item derived from architectural analysis"""

    title: str
    description: str
    work_type: str  # epic, story, task
    acceptance_criteria: list[str] = field(default_factory=list)
    technical_requirements: list[str] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)
    bounded_context: str = "core-models"
    story_points: int | None = None
    priority: str = "Medium"
    labels: list[str] = field(default_factory=list)
    parent_epic: str | None = None
    source_component: str | None = None


@dataclass
class AnalysisResult:
    """Result of architecture analysis"""

    success: bool
    components: list[ArchitecturalComponent] = field(default_factory=list)
    epics: list[ImplementationWorkItem] = field(default_factory=list)
    stories: list[ImplementationWorkItem] = field(default_factory=list)
    tasks: list[ImplementationWorkItem] = field(default_factory=list)
    pages_analyzed: int = 0
    analysis_notes: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


@dataclass
class CreationResult:
    """Result of creating Jira issues"""

    epics_created: int = 0
    stories_created: int = 0
    tasks_created: int = 0
    created_issues: list[dict[str, str]] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


class ConfluenceArchitectureAnalyzer(IDocumentAnalyzer):
    """
    Expert Solution Architect for analyzing Confluence architecture documentation.

    IMPLEMENTS: IDocumentAnalyzer (DDD/SOLID compliance)

    This is NOT a naive parser. It acts as an intelligent analyzer that:
    1. Understands software architecture patterns
    2. Identifies implementable components from documentation
    3. Generates properly structured work items with real acceptance criteria
    4. Respects Inovagio's DDD architecture and layer dependencies

    Responsibilities:
    1. Fetch and understand Confluence architecture pages
    2. Identify architectural components (interfaces, services, adapters)
    3. Determine implementation patterns (event sourcing, protocol integration, etc.)
    4. Generate epics based on bounded contexts
    5. Generate stories based on implementation patterns
    6. Generate tasks for specific technical work

    DDD/SOLID Compliance:
    - Implements IDocumentAnalyzer interface (Liskov Substitution)
    - Receives all dependencies via constructor injection (Dependency Inversion)
    - Uses IConfluenceRepository for page operations (no duplicate API calls)
    - Uses domain services for theme/context/priority (single source of truth)
    - Returns unified ParsedWorkItem/DocumentAnalysisResult (DRY)
    """

    def __init__(
        self,
        issue_repo: IIssueRepository,
        confluence_repo: IConfluenceRepository | None = None,
        theme_detector: IThemeDetector | None = None,
        context_resolver: IBoundedContextResolver | None = None,
        priority_calculator: IPriorityCalculator | None = None,
        codebase_cross_referencer: ICodebaseCrossReferencer | None = None,
        verbose: bool = False,
    ):
        """
        Initialize with dependency injection.

        Args:
            issue_repo: Repository for Jira issue operations
            confluence_repo: Repository for Confluence page operations (DI - no duplicate API calls)
            theme_detector: Service for detecting themes from text (DI - single source of truth)
            context_resolver: Service for resolving bounded contexts (DI - single source of truth)
            priority_calculator: Service for calculating priority (DI - single source of truth)
            codebase_cross_referencer: Service for validating against actual codebase (optional)
            verbose: Enable verbose logging
        """
        self._issues = issue_repo
        self._confluence = confluence_repo
        self._theme_detector = theme_detector
        self._context_resolver = context_resolver
        self._priority_calculator = priority_calculator
        self._codebase_cross_referencer = codebase_cross_referencer
        self._verbose = verbose
        self._analysis_log: list[str] = []
        self._codebase_validation: CodebaseValidationResult | None = None

    # =========================================================================
    # IDocumentAnalyzer INTERFACE IMPLEMENTATION
    # =========================================================================

    def analyze(
        self, document: Any, include_children: bool = False, **_kwargs: Any
    ) -> DocumentAnalysisResult:
        """
        IDocumentAnalyzer interface: Analyze a Confluence page and extract work items.

        This is the unified interface method that wraps analyze_architecture()
        and returns the standardized DocumentAnalysisResult.

        Args:
            document: ImportedDocument or Confluence page ID/URL
            include_children: Also analyze child pages
            **kwargs: Additional options (validate_codebase, etc.)

        Returns:
            DocumentAnalysisResult with extracted work items
        """
        # Handle both ImportedDocument and legacy string source
        if isinstance(document, str):
            source = document
        else:
            # It's an ImportedDocument
            source = document.source_path

        # Delegate to analyze_architecture and convert result
        legacy_result = self.analyze_architecture(source, include_children)

        # Convert AnalysisResult to DocumentAnalysisResult
        return self._convert_to_document_result(legacy_result, source)

    def get_source_type(self) -> DocumentSource:
        """Return Confluence page source type."""
        return DocumentSource.CONFLUENCE_PAGE

    def supports_source(self, source: str) -> bool:
        """
        Check if this analyzer supports the given source.

        Supports Confluence page IDs (numeric) and Confluence URLs.
        """
        if not source:
            return False

        # Numeric page ID
        if source.isdigit():
            return True

        # Confluence URL
        if "atlassian.net" in source and ("/wiki/" in source or "/pages/" in source):
            return True

        # NOT a file path
        if "/" in source and "atlassian" not in source:
            return False

        return False

    def _convert_to_document_result(
        self, legacy_result: "AnalysisResult", source: str
    ) -> DocumentAnalysisResult:
        """
        Convert legacy AnalysisResult to unified DocumentAnalysisResult.

        DRY: Converts internal types to domain types for uniform interface.
        """
        result = DocumentAnalysisResult(
            success=legacy_result.success,
            source=DocumentSource.CONFLUENCE_PAGE,
            source_path=source,
            pages_analyzed=legacy_result.pages_analyzed,
            analysis_notes=legacy_result.analysis_notes,
            errors=legacy_result.errors,
        )

        # Convert epics
        for epic in legacy_result.epics:
            result.epics.append(self._convert_work_item(epic, IssueType.EPIC))

        # Convert stories
        for story in legacy_result.stories:
            result.stories.append(self._convert_work_item(story, IssueType.STORY))

        # Convert tasks
        for task in legacy_result.tasks:
            result.tasks.append(self._convert_work_item(task, IssueType.TASK))

        return result

    def _convert_work_item(
        self, item: "ImplementationWorkItem", work_type: IssueType
    ) -> ParsedWorkItem:
        """Convert internal ImplementationWorkItem to domain ParsedWorkItem."""
        return ParsedWorkItem(
            title=item.title,
            description=item.description,
            work_type=work_type,
            acceptance_criteria=item.acceptance_criteria,
            technical_requirements=item.technical_requirements,
            dependencies=item.dependencies,
            bounded_context=item.bounded_context,
            story_points=item.story_points,
            priority=item.priority,
            labels=item.labels,
            parent_epic=item.parent_epic,
            source_component=item.source_component,
        )

    # =========================================================================
    # LEGACY ANALYSIS METHODS (preserved for backward compatibility)
    # =========================================================================

    def analyze_architecture(self, page_id: str, include_children: bool = False) -> AnalysisResult:
        """
        Analyze Confluence architecture documentation and generate work items.

        This is the main entry point. It:
        1. Fetches Confluence pages
        2. Extracts architectural components semantically
        3. Identifies implementation patterns
        4. Generates properly structured work items

        Args:
            page_id: Confluence page ID
            include_children: Also analyze child pages

        Returns:
            AnalysisResult with components, epics, stories, tasks
        """
        try:
            numeric_page_id = self._extract_page_id(page_id)

            # Phase 1: Fetch all relevant pages
            pages = self._fetch_pages(numeric_page_id, include_children)
            if not pages:
                return AnalysisResult(
                    success=False, errors=[f"Failed to fetch Confluence page {page_id}"]
                )

            self._log(f"📚 Fetched {len(pages)} architecture pages for analysis")

            # Phase 2: Extract architectural components from all pages
            all_components: list[ArchitecturalComponent] = []
            for page in pages:
                components = self._extract_architectural_components(page)
                all_components.extend(components)
                title = page.get("title", "Untitled")
                self._log(f"   Found {len(components)} components in '{title}'")

            # Phase 3: Deduplicate and enrich components
            unique_components = self._deduplicate_components(all_components)
            self._log(f"🔍 Identified {len(unique_components)} unique architectural components")

            # Phase 3.5: Cross-reference with actual codebase (if enabled)
            if self._codebase_cross_referencer:
                self._validate_against_codebase(unique_components)

            # Phase 4: Generate implementation work items
            epics, stories, tasks = self._generate_work_items(unique_components)

            # Phase 5: Add cross-cutting concerns
            self._add_cross_cutting_work_items(epics, stories, tasks, unique_components)

            return AnalysisResult(
                success=True,
                components=unique_components,
                epics=epics,
                stories=stories,
                tasks=tasks,
                pages_analyzed=len(pages),
                analysis_notes=self._analysis_log,
            )

        except Exception as e:  # pylint: disable=broad-exception-caught
            return AnalysisResult(success=False, errors=[f"Analysis error: {e!s}"])

    def _log(self, message: str):
        """Log analysis progress"""
        self._analysis_log.append(message)
        if self._verbose:
            print(message)

    def _fetch_pages(self, page_id: str, include_children: bool) -> list[dict[str, Any]]:
        """
        Fetch main page and optionally child pages.

        Uses IConfluenceRepository if injected (DI), falls back to direct API calls.
        """
        pages = []

        # Use injected repository if available (DDD/DI pattern)
        if self._confluence:
            confluence_page_id = ConfluencePageId(page_id)
            main_page_obj = self._confluence.get_page(confluence_page_id)

            if main_page_obj:
                # Convert ConfluencePage to dict format for compatibility
                page_dict = self._confluence_page_to_dict(main_page_obj)
                pages.append(page_dict)
                self._log(f"   ✅ Found: {main_page_obj.title}")

                if include_children:
                    children_objs = self._confluence.get_child_pages(confluence_page_id)
                    self._log(f"   ✅ Found {len(children_objs)} child pages")
                    for child_obj in children_objs:
                        child_dict = self._confluence_page_to_dict(child_obj)
                        pages.append(child_dict)
        else:
            # Fallback to direct API calls (legacy behavior)
            main_page_dict = self._fetch_confluence_page_legacy(page_id)
            if main_page_dict:
                pages.append(main_page_dict)

                if include_children:
                    children_dicts = self._fetch_child_pages_legacy(page_id)
                    for child_info in children_dicts:
                        child_page_dict = self._fetch_confluence_page_legacy(child_info["id"])
                        if child_page_dict:
                            pages.append(child_page_dict)

        return pages

    def _confluence_page_to_dict(self, page: ConfluencePage) -> dict[str, Any]:
        """Convert ConfluencePage value object to dict format for compatibility."""
        return {
            "id": page.page_id.page_id,
            "title": page.title,
            "body": {"storage": {"value": page.content}},
            "space": {"key": page.space_key},
            "version": {"number": page.version},
        }

    def _extract_architectural_components(
        self, page: dict[str, Any]
    ) -> list[ArchitecturalComponent]:
        """
        Extract architectural components from a Confluence page.

        Looks for:
        - Interface definitions (I*, pure virtual)
        - Service classes
        - Adapters and gateways
        - Protocol implementations
        - Domain entities and aggregates
        """
        components: list[ArchitecturalComponent] = []
        page_title = page.get("title", "Untitled")
        page_url = page.get("_links", {}).get("webui", "")

        # Get page content
        body = page.get("body", {})
        storage_content = body.get("storage", {}).get("value", "")
        content = self._html_to_text(storage_content) if storage_content else ""

        if not content:
            return components

        # Strategy 1: Look for explicit interface/class definitions
        components.extend(self._find_interface_definitions(content, page_title, page_url))

        # Strategy 2: Look for architectural patterns mentioned
        components.extend(self._find_pattern_implementations(content, page_title, page_url))

        # Strategy 3: Look for integration points/protocols
        components.extend(self._find_integration_points(content, page_title, page_url))

        # Strategy 4: Look for feature/capability descriptions
        components.extend(self._find_feature_capabilities(content, page_title, page_url))

        return components

    def _find_interface_definitions(
        self, content: str, _page_title: str, page_url: str
    ) -> list[ArchitecturalComponent]:
        """Find interface definitions like IProtocolGateway, IMCPClient"""
        components = []

        # Pattern: I[A-Z][a-zA-Z]+ - interface naming convention
        interface_pattern = (
            r"\b(I[A-Z][a-zA-Z]+(?:Service|Gateway|Client|Handler|Provider|Repository|"
            r"Factory|Adapter|Manager|Executor|Scheduler|Router|Resolver))\b"
        )

        for match in re.finditer(interface_pattern, content):
            interface_name = match.group(1)

            # Extract context around the match
            start = max(0, match.start() - 200)
            end = min(len(content), match.end() + 500)
            context = content[start:end]

            # Determine bounded context
            bounded_context = self._determine_bounded_context(interface_name, context)

            # Extract description from context
            description = self._extract_description(interface_name, context)

            # Extract responsibilities
            responsibilities = self._extract_responsibilities(context)

            components.append(
                ArchitecturalComponent(
                    name=interface_name,
                    component_type="interface",
                    bounded_context=bounded_context,
                    description=description,
                    responsibilities=responsibilities,
                    patterns=["Interface Segregation"],
                    priority=self._determine_priority(context),
                    source_page=page_url,
                )
            )

        return components

    def _find_pattern_implementations(
        self, content: str, _page_title: str, page_url: str
    ) -> list[ArchitecturalComponent]:
        """Find architectural pattern implementations"""
        components = []

        # Look for event sourcing mentions
        if re.search(r"event\s+sourc", content, re.IGNORECASE):
            # Find what's being event-sourced
            entity_match = re.search(r"(\w+(?:Aggregate|Entity|State))", content)
            entity_name = entity_match.group(1) if entity_match else "Domain"

            components.append(
                ArchitecturalComponent(
                    name=f"{entity_name}EventStore",
                    component_type="event_store",
                    bounded_context=self._determine_bounded_context(entity_name, content),
                    description=f"Event sourcing implementation for {entity_name}",
                    responsibilities=[
                        "Store domain events immutably",
                        "Reconstruct aggregate state from events",
                        "Support event replay and snapshots",
                    ],
                    patterns=["Event Sourcing", "CQRS"],
                    priority="High",
                    source_page=page_url,
                )
            )

        # Look for saga/orchestration patterns
        if re.search(r"saga|orchestrat|workflow", content, re.IGNORECASE):
            saga_match = re.search(
                r"(\w+)(?:\s+)?(?:Saga|Orchestrat|Workflow)", content, re.IGNORECASE
            )
            saga_name = saga_match.group(1) if saga_match else "Workflow"

            components.append(
                ArchitecturalComponent(
                    name=f"{saga_name}Orchestrator",
                    component_type="orchestrator",
                    bounded_context="core-orchestration",
                    description=f"Orchestration for {saga_name} workflows",
                    responsibilities=[
                        "Coordinate multi-step processes",
                        "Handle compensation on failures",
                        "Maintain workflow state",
                    ],
                    patterns=["Saga", "Orchestrator"],
                    priority="High",
                    source_page=page_url,
                )
            )

        return components

    def _find_integration_points(
        self, content: str, _page_title: str, page_url: str
    ) -> list[ArchitecturalComponent]:
        """Find external integration points and protocols"""
        components = []

        # MCP (Model Context Protocol) integration
        if re.search(r"MCP|Model\s+Context\s+Protocol", content, re.IGNORECASE):
            components.append(
                ArchitecturalComponent(
                    name="MCPProtocolGateway",
                    component_type="gateway",
                    bounded_context="core-connectors",
                    description="Gateway for Model Context Protocol integration",
                    responsibilities=[
                        "Handle MCP message serialization/deserialization",
                        "Route tool calls to appropriate handlers",
                        "Manage MCP session lifecycle",
                        "Implement resource and prompt serving",
                    ],
                    dependencies=["core-ani", "core-models"],
                    patterns=["Gateway", "Adapter", "Protocol Buffer"],
                    priority="High",
                    source_page=page_url,
                )
            )

        # A2A (Agent-to-Agent) protocol
        if re.search(r"A2A|Agent.to.Agent", content, re.IGNORECASE):
            components.append(
                ArchitecturalComponent(
                    name="A2AProtocolAdapter",
                    component_type="adapter",
                    bounded_context="core-ani",
                    description="Adapter for Agent-to-Agent protocol",
                    responsibilities=[
                        "Handle A2A message format",
                        "Agent discovery and registration",
                        "Inter-agent communication routing",
                    ],
                    dependencies=["core-models"],
                    patterns=["Adapter", "Protocol Buffer"],
                    priority="High",
                    source_page=page_url,
                )
            )

        # Generic API/REST integration
        api_matches = re.finditer(
            r"(\w+)\s+(?:API|REST|GraphQL)\s+(?:integration|client|gateway)", content, re.IGNORECASE
        )
        for match in api_matches:
            api_name = match.group(1)
            components.append(
                ArchitecturalComponent(
                    name=f"{api_name}ApiClient",
                    component_type="client",
                    bounded_context="core-connectors",
                    description=f"API client for {api_name} integration",
                    responsibilities=[
                        f"Handle {api_name} API authentication",
                        "Request/response serialization",
                        "Error handling and retries",
                        "Rate limiting compliance",
                    ],
                    patterns=["Client", "Adapter"],
                    priority="Medium",
                    source_page=page_url,
                )
            )

        return components

    def _find_feature_capabilities(
        self, content: str, _page_title: str, page_url: str
    ) -> list[ArchitecturalComponent]:
        """Find high-level features and capabilities that need implementation"""
        components = []

        # Look for feature sections with implementation requirements
        feature_patterns = [
            (r"(?:##|###)\s*(?:Feature|Capability)[:\s]*(.+?)(?:\n|$)", "feature"),
            (r"(?:##|###)\s*(?:Requirement)[:\s]*(.+?)(?:\n|$)", "requirement"),
            (r"(?:##|###)\s*(?:Implementation)[:\s]*(.+?)(?:\n|$)", "implementation"),
        ]

        for pattern, comp_type in feature_patterns:
            for match in re.finditer(pattern, content):
                feature_name = match.group(1).strip()

                # Skip generic/navigation titles
                if self._is_navigation_title(feature_name):
                    continue

                # Get surrounding content for context
                start = match.end()
                end = min(len(content), start + 1000)
                feature_content = content[start:end]

                # Only create component if there's substantial content
                if len(feature_content.strip()) < 100:
                    continue

                bounded_context = self._determine_bounded_context(feature_name, feature_content)

                components.append(
                    ArchitecturalComponent(
                        name=self._normalize_component_name(feature_name),
                        component_type=comp_type,
                        bounded_context=bounded_context,
                        description=feature_content[:300].strip(),
                        responsibilities=self._extract_responsibilities(feature_content),
                        priority=self._determine_priority(feature_content),
                        source_page=page_url,
                    )
                )

        return components

    def _generate_work_items(
        self, components: list[ArchitecturalComponent]
    ) -> tuple[
        list[ImplementationWorkItem], list[ImplementationWorkItem], list[ImplementationWorkItem]
    ]:
        """
        Generate implementation work items from architectural components.

        Strategy:
        1. Group components by bounded context → Epics
        2. Each component → Story with pattern-based acceptance criteria
        3. Complex components → Additional tasks
        """
        epics: list[ImplementationWorkItem] = []
        stories: list[ImplementationWorkItem] = []
        tasks: list[ImplementationWorkItem] = []

        # Group components by bounded context
        context_groups: dict[str, list[ArchitecturalComponent]] = {}
        for comp in components:
            ctx = comp.bounded_context
            if ctx not in context_groups:
                context_groups[ctx] = []
            context_groups[ctx].append(comp)

        # Generate epics for each bounded context with components
        for context, context_components in context_groups.items():
            if not context_components:
                continue

            # Create epic for this bounded context
            context_info = BOUNDED_CONTEXTS.get(context, {})
            epic_title = f"[{context.upper()}] Architecture Implementation"

            epic_description = self._generate_epic_description(
                context, context_components, context_info
            )

            epic = ImplementationWorkItem(
                title=epic_title,
                description=epic_description,
                work_type="epic",
                bounded_context=context,
                priority=self._aggregate_priority(context_components),
                labels=["architecture", "ddd", context.replace("core-", "")],
                acceptance_criteria=[
                    f"All {len(context_components)} components implemented",
                    ">85% unit test coverage",
                    "Integration tests passing",
                    "API documentation complete",
                    "Code review approved",
                ],
            )
            epics.append(epic)

            # Generate stories for each component
            for comp in context_components:
                story, component_tasks = self._generate_story_for_component(comp, epic_title)
                stories.append(story)
                tasks.extend(component_tasks)

        return epics, stories, tasks

    def _generate_epic_description(
        self, context: str, components: list[ArchitecturalComponent], context_info: dict
    ) -> str:
        """Generate a rich epic description"""
        description = f"""## Overview
Implement the {context} bounded context architecture based on Confluence documentation analysis.

## Bounded Context: {context}
**Layer**: {context_info.get("layer", InovagioLayer.DOMAIN_SERVICES).name if context_info else "DOMAIN_SERVICES"}
**Responsibilities**:
"""
        for resp in context_info.get("responsibilities", ["See architecture documentation"]):
            description += f"- {resp}\n"

        description += f"""
## Components to Implement ({len(components)})
"""
        for comp in components[:10]:  # List first 10
            description += (
                f"- **{comp.name}** ({comp.component_type}): {comp.description[:100]}...\n"
            )

        if len(components) > 10:
            description += f"- ... and {len(components) - 10} more components\n"

        description += """
## Technical Requirements
- Follow DDD layer architecture (no upward dependencies)
- Use Result<T,E> for error handling
- RAII for resource management
- >85% test coverage
- Zero compiler warnings (-Werror)

## Definition of Done
- [ ] All interfaces defined with Doxygen docs
- [ ] Implementations pass unit tests
- [ ] Integration tests with dependent contexts
- [ ] Code review approved
- [ ] Documentation updated
"""
        return description

    def _generate_story_for_component(
        self, component: ArchitecturalComponent, parent_epic: str
    ) -> tuple[ImplementationWorkItem, list[ImplementationWorkItem]]:
        """Generate a story and tasks for a component"""
        tasks = []

        # Determine implementation pattern
        pattern = self._determine_implementation_pattern(component)
        pattern_info = IMPLEMENTATION_PATTERNS.get(
            pattern, IMPLEMENTATION_PATTERNS["concrete_implementation"]
        )

        # Generate story title
        story_title = pattern_info["story_template"].format(name=component.name)

        # Generate acceptance criteria based on pattern + component specifics
        acceptance_criteria = list(pattern_info["acceptance_criteria"])

        # Add component-specific criteria
        for resp in component.responsibilities[:3]:
            acceptance_criteria.append(f"Implements: {resp}")

        # Generate description
        description = f"""## Component: {component.name}
**Type**: {component.component_type}
**Bounded Context**: {component.bounded_context}
**Patterns**: {", ".join(component.patterns) if component.patterns else "N/A"}

## Description
{component.description}

## Responsibilities
"""
        for resp in component.responsibilities:
            description += f"- {resp}\n"

        if component.dependencies:
            description += "\n## Dependencies\n"
            for dep in component.dependencies:
                description += f"- {dep}\n"

        description += f"""
## Source Documentation
{component.source_page or "See Confluence architecture pages"}
"""

        story = ImplementationWorkItem(
            title=story_title,
            description=description,
            work_type="story",
            acceptance_criteria=acceptance_criteria,
            bounded_context=component.bounded_context,
            story_points=pattern_info["story_points"],
            priority=component.priority,
            labels=component.patterns[:3] if component.patterns else ["implementation"],
            parent_epic=parent_epic,
            source_component=component.name,
        )

        # Generate tasks for complex components
        if component.component_type in ["gateway", "orchestrator", "event_store"]:
            tasks.extend(self._generate_tasks_for_complex_component(component, story_title))

        return story, tasks

    def _generate_tasks_for_complex_component(
        self, component: ArchitecturalComponent, parent_story: str
    ) -> list[ImplementationWorkItem]:
        """Generate tasks for complex components"""
        tasks = []

        # Task 1: Interface definition
        tasks.append(
            ImplementationWorkItem(
                title=f"Define I{component.name} interface",
                description=f"Define the interface for {component.name} with all required methods.",
                work_type="task",
                bounded_context=component.bounded_context,
                technical_requirements=[
                    "Pure virtual interface in header",
                    "Doxygen documentation",
                    "No implementation dependencies",
                ],
                parent_epic=parent_story,
            )
        )

        # Task 2: Unit tests
        tasks.append(
            ImplementationWorkItem(
                title=f"Unit tests for {component.name}",
                description=f"Implement comprehensive unit tests for {component.name}.",
                work_type="task",
                bounded_context=component.bounded_context,
                technical_requirements=[
                    ">85% code coverage",
                    "Mock all dependencies",
                    "Test error paths",
                    "Property-based tests where applicable",
                ],
                parent_epic=parent_story,
            )
        )

        # Task 3: Integration tests (for gateways/adapters)
        if component.component_type in ["gateway", "adapter", "client"]:
            tasks.append(
                ImplementationWorkItem(
                    title=f"Integration tests for {component.name}",
                    description=f"Implement integration tests for {component.name} with external systems.",
                    work_type="task",
                    bounded_context=component.bounded_context,
                    technical_requirements=[
                        "Test with real/mock external system",
                        "Test error handling and retries",
                        "Test timeout behavior",
                    ],
                    parent_epic=parent_story,
                )
            )

        return tasks

    def _add_cross_cutting_work_items(
        self,
        _epics: list[ImplementationWorkItem],
        stories: list[ImplementationWorkItem],
        _tasks: list[ImplementationWorkItem],
        components: list[ArchitecturalComponent],
    ):
        """Add cross-cutting concerns as additional work items"""

        # Check if we have security-sensitive components
        has_security = any(
            any(
                kw in comp.name.lower() or kw in comp.description.lower()
                for kw in ["auth", "security", "crypto", "token", "secret"]
            )
            for comp in components
        )

        if has_security:
            stories.append(
                ImplementationWorkItem(
                    title="Security Review and Hardening",
                    description="""Perform security review of implemented components.

## Requirements
- Verify all crypto uses ICryptoService
- Verify RBAC checks at application boundary
- Verify audit logging for security events
- Verify no secrets in logs or configs
- Run static analysis (CodeQL, Semgrep)
""",
                    work_type="story",
                    acceptance_criteria=[
                        "Security review checklist completed",
                        "No hard-coded secrets",
                        "All auth paths use centralized services",
                        "Audit logging verified",
                        "Static analysis clean",
                    ],
                    bounded_context="core-governance",
                    priority="High",
                    labels=["security", "review"],
                )
            )

        # Add observability story if we have services
        has_services = any(
            comp.component_type in ["gateway", "orchestrator", "service"] for comp in components
        )
        if has_services:
            stories.append(
                ImplementationWorkItem(
                    title="Observability and Monitoring",
                    description="""Implement observability for all new services.

## Requirements
- Structured logging with trace IDs
- Metrics export (Prometheus format)
- Distributed tracing integration
- Health check endpoints
- Dashboard configuration
""",
                    work_type="story",
                    acceptance_criteria=[
                        "All services emit structured logs",
                        "Metrics exported for key operations",
                        "Trace IDs propagated through call chains",
                        "Health checks implemented",
                    ],
                    bounded_context="core-utils",
                    priority="Medium",
                    labels=["observability", "monitoring"],
                )
            )

    # ========================================================================
    # HELPER METHODS
    # ========================================================================

    def _determine_bounded_context(self, name: str, context: str) -> str:
        """
        Determine which bounded context a component belongs to.

        Uses IBoundedContextResolver if injected (DI), falls back to local logic.
        """
        combined = name + " " + context

        # Use injected service if available (DDD/DI pattern - single source of truth)
        if self._context_resolver and self._theme_detector:
            themes = self._theme_detector.detect_themes(combined)
            resolved = self._context_resolver.resolve_context(themes, combined)
            return resolved.name

        # Fallback to local logic (legacy behavior)
        combined_lower = combined.lower()

        # Check for explicit mentions
        context_keywords = {
            "core-ani": ["ani", "agent network", "multi-agent", "a2a"],
            "core-orchestration": ["orchestrat", "workflow", "execution", "scheduler", "dag"],
            "core-connectors": ["connector", "mcp", "integration", "external", "api client"],
            "core-governance": ["governance", "rbac", "audit", "permission", "compliance"],
            "core-persistence": ["persist", "repository", "event store", "storage"],
            "core-agents": ["agent", "llm", "tool execution"],
            "core-utils": ["util", "logging", "thread pool", "serializ"],
            "core-models": ["model", "value object", "entity", "domain primitive"],
        }

        for ctx, keywords in context_keywords.items():
            if any(kw in combined_lower for kw in keywords):
                return ctx

        return "core-models"  # Default

    def _determine_priority(self, content: str) -> str:
        """
        Determine priority from content.

        Uses IPriorityCalculator if injected (DI), falls back to local logic.
        """
        # Use injected service if available (DDD/DI pattern - single source of truth)
        if self._priority_calculator and self._theme_detector:
            themes = self._theme_detector.detect_themes(content)
            return self._priority_calculator.calculate_priority("Story", themes, content)

        # Fallback to local logic (legacy behavior)
        content_lower = content.lower()

        if any(kw in content_lower for kw in ["critical", "blocker", "p0", "urgent"]):
            return "Highest"
        if any(kw in content_lower for kw in ["high", "important", "p1"]):
            return "High"
        if any(kw in content_lower for kw in ["low", "minor", "p3", "nice to have"]):
            return "Low"
        return "Medium"

    def _aggregate_priority(self, components: list[ArchitecturalComponent]) -> str:
        """Aggregate priority from multiple components"""
        priority_order = ["Highest", "High", "Medium", "Low", "Lowest"]
        priorities = [comp.priority for comp in components]

        for p in priority_order:
            if p in priorities:
                return p
        return "Medium"

    def _determine_implementation_pattern(self, component: ArchitecturalComponent) -> str:
        """Determine which implementation pattern to use"""
        if component.component_type == "interface":
            return "interface_definition"
        if component.component_type in ["gateway", "adapter", "client"]:
            return "protocol_integration"
        if component.component_type == "event_store":
            return "event_sourcing"
        if any("security" in p.lower() for p in component.patterns):
            return "security_implementation"
        return "concrete_implementation"

    def _extract_description(self, name: str, context: str) -> str:
        """Extract a description from surrounding context"""
        # Look for sentences containing the name
        sentences = re.split(r"[.!?]\s+", context)
        for sentence in sentences:
            if name.lower() in sentence.lower() and len(sentence) > 30:
                return sentence.strip()[:300]
        return f"Implementation for {name}"

    def _extract_responsibilities(self, content: str) -> list[str]:
        """Extract responsibilities from bullet lists"""
        responsibilities = []

        # Look for bullet points
        bullets = re.findall(r"[-*]\s+(.+?)(?:\n|$)", content)
        for bullet in bullets[:5]:  # Max 5
            clean = bullet.strip()
            if len(clean) > 10 and len(clean) < 200:
                responsibilities.append(clean)

        return responsibilities

    def _normalize_component_name(self, name: str) -> str:
        """Normalize a feature name to a valid component name"""
        # Remove special characters, convert to PascalCase
        words = re.findall(r"[a-zA-Z]+", name)
        return "".join(word.capitalize() for word in words[:4])  # Max 4 words

    def _is_navigation_title(self, title: str) -> bool:
        """Check if title is a navigation/structural element"""
        navigation_titles = {
            "overview",
            "introduction",
            "summary",
            "background",
            "context",
            "table of contents",
            "references",
            "appendix",
            "glossary",
            "next steps",
            "action items",
            "notes",
            "related pages",
        }
        return title.lower().strip() in navigation_titles

    def _deduplicate_components(
        self, components: list[ArchitecturalComponent]
    ) -> list[ArchitecturalComponent]:
        """Remove duplicate components by name"""
        seen = set()
        unique = []
        for comp in components:
            if comp.name not in seen:
                seen.add(comp.name)
                unique.append(comp)
        return unique

    def _validate_against_codebase(self, components: list[ArchitecturalComponent]) -> None:
        """
        Cross-reference extracted components with actual codebase.

        Scans:
        - core/**/*.hpp for existing interfaces and implementations
        - docs/architecture/context_map.md for bounded context validation
        - docs/architecture/domain_glossary.md for domain term validation

        This ensures proposed Jira issues:
        1. Don't duplicate existing code
        2. Use correct bounded context assignments
        3. Use ubiquitous language from the domain glossary

        Updates self._codebase_validation with results.
        """
        if not self._codebase_cross_referencer:
            return

        self._log("🔬 Cross-referencing with actual codebase...")
        self._log(self._codebase_cross_referencer.get_scan_summary())

        # Extract proposed interfaces and implementations from components
        proposed_interfaces = []
        proposed_implementations = []
        terms_used = set()

        for comp in components:
            if comp.component_type == "interface":
                proposed_interfaces.append(comp.name)
            else:
                proposed_implementations.append(comp.name)

            # Extract domain terms from description
            words = re.findall(r"\b[A-Z][a-z]+(?:[A-Z][a-z]+)*\b", comp.description)
            terms_used.update(words)

            # Also check responsibilities
            for resp in comp.responsibilities:
                words = re.findall(r"\b[A-Z][a-z]+(?:[A-Z][a-z]+)*\b", resp)
                terms_used.update(words)

        # Run validation
        self._codebase_validation = self._codebase_cross_referencer.validate_proposed_work(
            proposed_interfaces=proposed_interfaces,
            proposed_implementations=proposed_implementations,
            terms_used=list(terms_used),
        )

        # Log validation results
        self._log("\n" + self._codebase_validation.validation_summary)

        if self._codebase_validation.already_exists:
            self._log("\n⚠️  ALREADY EXISTS IN CODEBASE:")
            for item in self._codebase_validation.already_exists[:5]:  # Show first 5
                self._log(f"   • {item}")
            if len(self._codebase_validation.already_exists) > 5:
                self._log(f"   • ... and {len(self._codebase_validation.already_exists) - 5} more")

        if self._codebase_validation.partially_exists:
            self._log("\nℹ️  INTERFACE EXISTS (needs implementation):")
            for item in self._codebase_validation.partially_exists[:5]:
                self._log(f"   • {item}")

        if self._codebase_validation.unknown_terms:
            self._log("\n📝 TERMS NOT IN DOMAIN GLOSSARY:")
            for term in self._codebase_validation.unknown_terms[:10]:
                suggestion = self._codebase_validation.suggested_terms.get(term)
                if suggestion:
                    self._log(f"   • {term} → Did you mean '{suggestion}'?")
                else:
                    self._log(f"   • {term}")

        # Validate layer dependencies for components
        self._validate_layer_dependencies(components)

        # Enrich components with codebase context
        self._enrich_components_from_codebase(components)

    def _validate_layer_dependencies(self, components: list[ArchitecturalComponent]) -> None:
        """Validate that proposed component dependencies respect layer architecture."""
        if not self._codebase_cross_referencer:
            return

        violations = []
        for comp in components:
            from_context = comp.bounded_context
            for dep in comp.dependencies:
                # Try to resolve dependency to a context
                dep_context = self._infer_context_from_dependency(dep)
                if dep_context:
                    if not self._codebase_cross_referencer.validate_layer_dependencies(
                        from_context, dep_context
                    ):
                        violations.append(f"{comp.name} ({from_context}) → {dep} ({dep_context})")

        if violations:
            self._log("\n🚨 LAYER DEPENDENCY VIOLATIONS:")
            for v in violations:
                self._log(f"   • {v}")
            self._log("   Rule: Layer N can only depend on Layer N-1 (dependencies flow DOWN)")

    def _infer_context_from_dependency(self, dependency: str) -> str | None:
        """Infer bounded context from dependency name."""
        dep_lower = dependency.lower()

        # Map common patterns to contexts
        context_patterns = {
            "core-models": ["id", "value", "entity", "aggregate", "result"],
            "core-utils": ["log", "thread", "event", "config", "serializ"],
            "core-governance": ["rbac", "permission", "audit", "policy"],
            "core-persistence": ["repository", "database", "storage"],
            "core-connectors": ["connector", "adapter", "gateway", "api"],
            "core-ani": ["ani", "network", "message", "protocol"],
            "core-agents": ["agent", "llm", "tool", "executor"],
            "core-orchestration": ["workflow", "task", "scheduler", "dag"],
        }

        for context, patterns in context_patterns.items():
            if any(p in dep_lower for p in patterns):
                return context

        return None

    def _enrich_components_from_codebase(self, components: list[ArchitecturalComponent]) -> None:
        """Enrich components with information from codebase scan."""
        if not self._codebase_cross_referencer:
            return

        for comp in components:
            # Check if interface already exists
            if self._codebase_cross_referencer.interface_exists(comp.name):
                existing = self._codebase_cross_referencer.get_existing_interfaces()
                for iface in existing:
                    if iface.name in (comp.name, f"I{comp.name}"):
                        # Add note about existing interface
                        comp.responsibilities.append(
                            f"NOTE: Interface already exists at {iface.file_path}:{iface.line_number}"
                        )
                        # Update bounded context to match existing
                        if iface.bounded_context != "unknown":
                            comp.bounded_context = iface.bounded_context
                        break

            # Use codebase cross-referencer to suggest better bounded context
            if comp.bounded_context == "core-models":  # Default fallback
                suggested = self._codebase_cross_referencer.suggest_bounded_context(
                    comp.name, comp.description
                )
                if suggested != "core-models":
                    comp.bounded_context = suggested

    def get_codebase_validation_result(self) -> CodebaseValidationResult | None:
        """Get the codebase validation result from the last analysis."""
        return self._codebase_validation

    def _extract_page_id(self, page_id_or_url: str) -> str:
        """Extract numeric page ID from URL or return as-is"""
        match = re.search(r"/pages/(\d+)/", page_id_or_url)
        if match:
            return match.group(1)
        return page_id_or_url

    def _fetch_confluence_page_legacy(self, page_id: str) -> dict[str, Any] | None:
        """
        Fetch Confluence page content via Atlassian REST API (legacy fallback).

        DEPRECATED: Use IConfluenceRepository.get_page() instead via DI.
        """
        import requests
        from requests.auth import HTTPBasicAuth

        from .config import AtlassianConfig

        try:
            config = AtlassianConfig.from_environment()
            config.validate()

            url = f"{config.base_url}/wiki/api/v2/pages/{page_id}"
            params = {"body-format": "storage"}

            auth = HTTPBasicAuth(config.user_email, config.api_token)
            headers = {"Accept": "application/json"}

            self._log(f"📡 Fetching Confluence page {page_id}...")
            response = requests.get(url, params=params, auth=auth, headers=headers, timeout=30)

            if response.status_code == 200:
                page_data = response.json()
                self._log(f"   ✅ Found: {page_data.get('title', 'Untitled')}")
                return page_data
            if response.status_code == 404:
                self._log(f"   ❌ Page {page_id} not found")
                return None

            self._log(f"   ❌ API error: {response.status_code}")
            return None

        except Exception as e:  # pylint: disable=broad-exception-caught
            self._log(f"   ❌ Error fetching page: {e!s}")
            return None

    def _fetch_child_pages_legacy(self, page_id: str) -> list[dict[str, Any]]:
        """
        Fetch child pages via Atlassian REST API (legacy fallback).

        DEPRECATED: Use IConfluenceRepository.get_child_pages() instead via DI.
        """
        import requests
        from requests.auth import HTTPBasicAuth

        from .config import AtlassianConfig

        try:
            config = AtlassianConfig.from_environment()

            url = f"{config.base_url}/wiki/api/v2/pages/{page_id}/children"
            params = {"limit": 50}

            auth = HTTPBasicAuth(config.user_email, config.api_token)
            headers = {"Accept": "application/json"}

            self._log(f"📡 Fetching child pages of {page_id}...")
            response = requests.get(url, params=params, auth=auth, headers=headers, timeout=30)

            if response.status_code == 200:
                data = response.json()
                children = data.get("results", [])
                self._log(f"   ✅ Found {len(children)} child pages")
                return children

            self._log(f"   ⚠️  Could not fetch children: {response.status_code}")
            return []

        except Exception as e:  # pylint: disable=broad-exception-caught
            self._log(f"   ❌ Error fetching children: {e!s}")
            return []

    def _html_to_text(self, html_content: str) -> str:
        """Convert HTML storage format to plain text with markdown-like structure"""
        text = html_content

        # Convert headings
        text = re.sub(r"<h1[^>]*>(.*?)</h1>", r"\n# \1\n", text, flags=re.IGNORECASE | re.DOTALL)
        text = re.sub(r"<h2[^>]*>(.*?)</h2>", r"\n## \1\n", text, flags=re.IGNORECASE | re.DOTALL)
        text = re.sub(r"<h3[^>]*>(.*?)</h3>", r"\n### \1\n", text, flags=re.IGNORECASE | re.DOTALL)
        text = re.sub(r"<h4[^>]*>(.*?)</h4>", r"\n#### \1\n", text, flags=re.IGNORECASE | re.DOTALL)

        # Convert lists
        text = re.sub(r"<li[^>]*>(.*?)</li>", r"- \1\n", text, flags=re.IGNORECASE | re.DOTALL)

        # Convert paragraphs
        text = re.sub(r"<p[^>]*>(.*?)</p>", r"\1\n\n", text, flags=re.IGNORECASE | re.DOTALL)

        # Convert code blocks
        code_pattern = (
            r'<ac:structured-macro[^>]*ac:name="code"[^>]*>.*?'
            r"<ac:plain-text-body><!\[CDATA\[(.*?)\]\]></ac:plain-text-body>.*?"
            r"</ac:structured-macro>"
        )
        text = re.sub(code_pattern, r"\n```\n\1\n```\n", text, flags=re.IGNORECASE | re.DOTALL)

        # Remove remaining HTML tags
        text = re.sub(r"<[^>]+>", "", text)

        # Decode HTML entities
        text = html.unescape(text)

        # Clean up whitespace
        text = re.sub(r"\n{3,}", "\n\n", text)

        return text.strip()

    def create_jira_issues_from_analysis(
        self,
        analysis: AnalysisResult,
        sprint_number: int | None = None,
        epic_only: bool = False,
        _with_docs: bool = False,
    ) -> CreationResult:
        """
        Create Jira issues from architecture analysis.

        Args:
            analysis: AnalysisResult from analyze_architecture()
            sprint_number: Optional sprint to assign issues
            epic_only: If True, create only epics
            with_docs: If True, also generate Confluence docs

        Returns:
            CreationResult with creation statistics
        """
        result = CreationResult()
        epic_map = {}  # Maps epic title to IssueKey

        try:
            # Create epics
            for epic in analysis.epics:
                try:
                    domain_epic = self._create_epic_from_work_item(epic)

                    if sprint_number:
                        domain_epic.assign_to_sprint(SprintIdentifier(sprint_number))

                    epic_key = self._issues.create(domain_epic)
                    epic_map[epic.title] = epic_key

                    result.epics_created += 1
                    result.created_issues.append(
                        {"key": str(epic_key.key), "summary": epic.title, "type": "Epic"}
                    )

                except Exception as e:  # pylint: disable=broad-exception-caught
                    result.errors.append(f"Epic creation failed: {e!s}")

            # Create stories and tasks if not epic-only
            if not epic_only:
                for story in analysis.stories:
                    try:
                        domain_story = self._create_story_from_work_item(story)

                        if story.parent_epic and story.parent_epic in epic_map:
                            domain_story.set_epic(epic_map[story.parent_epic])

                        if sprint_number:
                            domain_story.assign_to_sprint(SprintIdentifier(sprint_number))

                        story_key = self._issues.create(domain_story)

                        result.stories_created += 1
                        result.created_issues.append(
                            {"key": str(story_key.key), "summary": story.title, "type": "Story"}
                        )

                    except Exception as e:  # pylint: disable=broad-exception-caught
                        result.errors.append(f"Story creation failed: {e!s}")

                for task in analysis.tasks:
                    try:
                        domain_task = self._create_task_from_work_item(task)

                        if sprint_number:
                            domain_task.assign_to_sprint(SprintIdentifier(sprint_number))

                        task_key = self._issues.create(domain_task)

                        result.tasks_created += 1
                        result.created_issues.append(
                            {"key": str(task_key.key), "summary": task.title, "type": "Task"}
                        )

                    except Exception as e:  # pylint: disable=broad-exception-caught
                        result.errors.append(f"Task creation failed: {e!s}")

        except Exception as e:  # pylint: disable=broad-exception-caught
            result.errors.append(f"Creation error: {e!s}")

        return result

    def _create_epic_from_work_item(self, work_item: ImplementationWorkItem) -> Epic:
        """Create Epic domain model from work item"""
        bounded_context = get_bounded_context(work_item.bounded_context)

        priority_map = {
            "Highest": Priority.HIGHEST,
            "High": Priority.HIGH,
            "Medium": Priority.MEDIUM,
            "Low": Priority.LOW,
            "Lowest": Priority.LOWEST,
        }
        priority = priority_map.get(work_item.priority, Priority.MEDIUM)

        epic = Epic(
            key=None,
            title=work_item.title,
            description=work_item.description,
            objective=work_item.title,
            bounded_context=bounded_context,
            priority=priority,
        )

        for label_str in work_item.labels:
            try:
                epic.add_label(Label(label_str))
            except Exception:  # pylint: disable=broad-exception-caught
                pass

        return epic

    def _create_story_from_work_item(self, work_item: ImplementationWorkItem) -> Story:
        """Create Story domain model from work item"""
        bounded_context = get_bounded_context(work_item.bounded_context)

        priority_map = {
            "Highest": Priority.HIGHEST,
            "High": Priority.HIGH,
            "Medium": Priority.MEDIUM,
            "Low": Priority.LOW,
            "Lowest": Priority.LOWEST,
        }
        priority = priority_map.get(work_item.priority, Priority.MEDIUM)

        story = Story(
            key=None,
            title=work_item.title,
            description=work_item.description,
            bounded_context=bounded_context,
            priority=priority,
        )

        for ac_text in work_item.acceptance_criteria:
            try:
                story.add_acceptance_criterion(AcceptanceCriterion(ac_text))
            except Exception:  # pylint: disable=broad-exception-caught
                pass

        for label_str in work_item.labels:
            try:
                story.add_label(Label(label_str))
            except Exception:  # pylint: disable=broad-exception-caught
                pass

        return story

    def _create_task_from_work_item(self, work_item: ImplementationWorkItem) -> Task:
        """Create Task domain model from work item"""
        bounded_context = get_bounded_context(work_item.bounded_context)

        task = Task(
            key=None,
            title=work_item.title,
            description=work_item.description,
            parent_story_key=IssueKey("TEMP-1"),  # Placeholder, will be updated during creation
            bounded_context=bounded_context,
        )

        return task


# Backwards compatibility alias
ConfluenceImporter = ConfluenceArchitectureAnalyzer
