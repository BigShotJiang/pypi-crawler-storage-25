#!/usr/bin/env python3
"""
Jira API Client and Repository Implementation

Low-level API client and repository implementation.

Author: Inovagio Engineering Team
"""

from collections.abc import Callable
from typing import Any

from atlassiancli.infrastructure.http_client import HttpClient, HttpError

from ..domain.models import Issue, Task
from ..domain.repositories import IIssueRepository
from ..domain.value_objects import IssueKey, SprintIdentifier
from .config import AtlassianConfig
from .mappers import IssueMapper


class JiraApiError(Exception):
    """Jira API error"""


class _AdaptedResponse:
    """``requests.Response``-compatible facade over our typed-error stdlib client.

    Preserves the legacy call-site shape ``response.status_code`` /
    ``response.text`` / ``response.json()`` / ``response.headers`` so that
    existing inspection logic (e.g. ``if response.status_code != 200``) keeps
    working unchanged after the surgical swap from :mod:`requests` to
    :class:`atlassiancli.infrastructure.http_client.HttpClient`. On a non-2xx
    response the underlying client raises an :class:`HttpError`; this adapter
    catches it once, harvests the status / body / headers off the exception,
    and presents the same surface as a successful response would have.
    """

    __slots__ = ("_body_bytes", "headers", "status_code")

    def __init__(self, status_code: int, body_bytes: bytes, headers: dict[str, str]):
        self.status_code = status_code
        self._body_bytes = body_bytes
        self.headers = headers

    @property
    def text(self) -> str:
        return self._body_bytes.decode("utf-8", errors="replace")

    def json(self) -> Any:
        import json as _json  # local import: keeps top-level imports stdlib-clean

        return _json.loads(self._body_bytes.decode("utf-8"))


def _adapt(call: Callable[[], Any]) -> _AdaptedResponse:
    """Run an :class:`HttpClient` method and return a response-shaped facade.

    Wraps :class:`HttpError` so the legacy "inspect status_code" pattern in
    every Jira method works identically; preserves attached body / headers
    so ``response.text`` and ``response.json()`` still surface server-side
    error payloads for diagnostics.
    """
    try:
        result = call()
    except HttpError as exc:
        return _AdaptedResponse(
            status_code=exc.status if exc.status is not None else 0,
            body_bytes=exc.body,
            headers=dict(exc.headers),
        )
    return _AdaptedResponse(
        status_code=result.status,
        body_bytes=result.body_bytes,
        headers=dict(result.headers),
    )


class JiraApiClient:
    """Low-level Jira REST API client"""

    def __init__(self, config: AtlassianConfig):
        self.config = config
        self.base_url = config.base_url
        self.headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
        }
        self._http = HttpClient(
            base_url=config.base_url,
            auth=(config.user_email, config.api_token),
            default_headers=self.headers,
            timeout_seconds=30.0,
        )

    def post(self, endpoint: str, data: dict) -> _AdaptedResponse:
        """POST request"""
        return _adapt(lambda: self._http.post(endpoint, json=data))

    def get(self, endpoint: str, params: dict | None = None) -> _AdaptedResponse:
        """GET request"""
        return _adapt(lambda: self._http.get(endpoint, params=params))

    def put(self, endpoint: str, data: dict) -> _AdaptedResponse:
        """PUT request"""
        return _adapt(lambda: self._http.put(endpoint, json=data))

    def delete(self, endpoint: str) -> _AdaptedResponse:
        """DELETE request"""
        return _adapt(lambda: self._http.delete(endpoint))

    def get_transitions(self, issue_key: str) -> list[dict]:
        """Get available transitions for an issue"""
        response = self.get(f"/rest/api/3/issue/{issue_key}/transitions")
        if response.status_code != 200:
            raise JiraApiError(
                f"Failed to get transitions: {response.status_code} - {response.text}"
            )
        return response.json().get("transitions", [])

    def transition_issue(self, issue_key: str, transition_id: str) -> bool:
        """Perform a transition on an issue"""
        payload = {"transition": {"id": transition_id}}
        response = self.post(f"/rest/api/3/issue/{issue_key}/transitions", payload)
        return response.status_code in [204, 200]

    def create_filter(
        self,
        name: str,
        jql: str,
        description: str = "",
        favourite: bool = True,
    ) -> dict[str, Any]:
        """Create a Jira saved filter.

        Args:
            name: Filter display name.
            jql: JQL query string.
            description: Optional filter description.
            favourite: Whether to favorite the filter for the current user.

        Returns:
            Raw Jira filter payload including id and view URL.

        Raises:
            JiraApiError: If API call fails.
        """
        payload: dict[str, Any] = {
            "name": name,
            "jql": jql,
            "description": description,
            "favourite": favourite,
        }
        response = self.post("/rest/api/3/filter", payload)
        if response.status_code not in [200, 201]:
            raise JiraApiError(f"Failed to create filter: {response.status_code} - {response.text}")
        return response.json()

    def create_version(self, version_data: dict) -> dict[str, Any]:
        """Create a release version in a Jira project.

        Args:
            version_data: Version payload with name, description, projectId,
                startDate, releaseDate, released, archived.

        Returns:
            Raw Jira version payload including id and self URL.

        Raises:
            JiraApiError: If API call fails.
        """
        response = self.post("/rest/api/3/version", version_data)
        if response.status_code not in [200, 201]:
            raise JiraApiError(
                f"Failed to create version: {response.status_code} - {response.text}"
            )
        return response.json()

    def list_versions(self, project_key: str) -> list[dict[str, Any]]:
        """List all versions for a project.

        Args:
            project_key: Project key (e.g., INOV).

        Returns:
            List of version payloads.

        Raises:
            JiraApiError: If API call fails.
        """
        response = self.get(f"/rest/api/3/project/{project_key}/versions")
        if response.status_code != 200:
            raise JiraApiError(f"Failed to list versions: {response.status_code} - {response.text}")
        return response.json()

    def create_dashboard(
        self,
        name: str,
        description: str = "",
        share_global: bool = True,
    ) -> dict[str, Any]:
        """Create a Jira dashboard.

        Args:
            name: Dashboard name.
            description: Dashboard description.
            share_global: If True, dashboard is viewable/editable by all authenticated users.

        Returns:
            Raw Jira dashboard payload including id and view URL.

        Raises:
            JiraApiError: If API call fails.
        """
        permissions = [{"type": "loggedin"}] if share_global else []
        payload: dict[str, Any] = {
            "name": name,
            "description": description,
            "sharePermissions": permissions,
            "editPermissions": permissions,
        }
        response = self.post("/rest/api/3/dashboard", payload)
        if response.status_code not in [200, 201]:
            raise JiraApiError(
                f"Failed to create dashboard: {response.status_code} - {response.text}"
            )
        return response.json()


class JiraIssueRepository(IIssueRepository):
    """Concrete implementation of IIssueRepository"""

    def __init__(self, api_client: JiraApiClient, mapper: IssueMapper):
        self._api = api_client
        self._mapper = mapper
        self._config = api_client.config

    def create(self, issue: Issue) -> IssueKey:
        """Create issue in Jira"""
        # Map domain model to API payload
        payload = self._mapper.to_api_payload(issue)

        # Call API
        response = self._api.post("/rest/api/3/issue", payload)

        if response.status_code not in [200, 201]:
            raise JiraApiError(f"Failed to create issue: {response.status_code} - {response.text}")

        # Extract key from response
        result = response.json()
        key_str = result.get("key")

        if not key_str:
            raise JiraApiError("No issue key in response")

        return IssueKey(key_str)

    def find_by_key(self, key: IssueKey) -> Issue | None:
        """Find issue by key"""
        response = self._api.get(f"/rest/api/3/issue/{key.key}")

        if response.status_code == 404:
            return None

        if response.status_code != 200:
            raise JiraApiError(f"Failed to fetch issue: {response.status_code}")

        # Map API response to domain model
        issue_data = response.json()
        return self._mapper.to_domain_model(issue_data)

    def update(self, issue: Issue) -> bool:
        """Update issue"""
        if not issue.key:
            raise ValueError("Cannot update issue without key")

        # Map to update payload
        payload = self._mapper.to_update_payload(issue)

        import logging

        logger = logging.getLogger(__name__)

        response = self._api.put(f"/rest/api/3/issue/{issue.key.key}", payload)

        if response.status_code not in [200, 204]:
            try:
                error_body = response.json()
            except (ValueError, AttributeError):
                error_body = response.text[:500] if response.text else "(empty)"
            logger.error(
                "Jira update failed for %s: HTTP %s — %s",
                issue.key.key,
                response.status_code,
                error_body,
            )
            return False

        return True

    def delete(self, key: IssueKey) -> bool:
        """Delete issue"""
        response = self._api.delete(f"/rest/api/3/issue/{key.key}")
        return response.status_code == 204

    def transition(self, key: IssueKey, transition_id: str) -> bool:
        """Transition issue"""
        return self._api.transition_issue(key.key, transition_id)

    def get_available_transitions(self, key: IssueKey) -> list[dict]:
        """Get available transitions"""
        return self._api.get_transitions(key.key)

    def find_by_sprint(self, sprint: SprintIdentifier) -> list[Issue]:
        """Find issues in sprint"""
        jql = f"project = {self._config.project_key} AND sprint = {sprint.sprint_number}"
        return self.search(jql, max_results=100)

    def search(self, jql: str, max_results: int = 50) -> list[Issue]:
        """Search using JQL

        Uses the new /rest/api/3/search/jql endpoint as the old /rest/api/3/search
        was deprecated and removed (HTTP 410) per Atlassian migration notice:
        https://developer.atlassian.com/changelog/#CHANGE-2046
        """
        # New API uses POST with JSON body instead of GET with query params
        payload = {"jql": jql, "maxResults": max_results, "fields": ["*all"]}

        response = self._api.post("/rest/api/3/search/jql", payload)

        if response.status_code != 200:
            raise JiraApiError(f"Search failed: {response.status_code} - {response.text[:200]}")

        result = response.json()
        issues = result.get("issues", [])

        return [self._mapper.to_domain_model(issue_data) for issue_data in issues]

    def get_subtasks(self, parent_key: IssueKey) -> list[Task]:
        """Get subtasks"""
        parent = self.find_by_key(parent_key)
        if not parent:
            return []

        jql = f"parent = {parent_key.key}"
        issues = self.search(jql)

        return [issue for issue in issues if isinstance(issue, Task)]

    def get_raw_issue(self, key: IssueKey, fields: list[str] | None = None) -> dict:
        """Get raw Jira issue payload for advanced analysis."""
        params = None
        if fields:
            params = {"fields": ",".join(fields)}

        response = self._api.get(f"/rest/api/3/issue/{key.key}", params=params)

        if response.status_code != 200:
            raise JiraApiError(f"Failed to fetch raw issue {key.key}: {response.status_code}")

        return response.json()

    def get_remote_links(self, key: IssueKey) -> list[dict]:
        """Get remote links for a Jira issue."""
        response = self._api.get(f"/rest/api/3/issue/{key.key}/remotelink")

        if response.status_code != 200:
            raise JiraApiError(
                f"Failed to fetch remote links for {key.key}: {response.status_code}"
            )

        data = response.json()
        if isinstance(data, list):
            return data
        return []
