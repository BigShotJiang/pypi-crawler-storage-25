"""Pure-Python YAML parser + writer (subset).

This module provides drop-in equivalents for ``yaml.safe_load`` and
``yaml.safe_dump`` covering the subset of YAML we actually use in config and
manifest files. The parser produces standard Python types (dict / list / str /
int / float / bool / None) and the writer emits canonical block-style YAML.

Supported (per PLAN §5.1):

  * Mappings (``key: value``), nested
  * Block sequences (``- item``), nested
  * Compact-mapping-in-sequence (``- key: val\\n  key2: val2``)
  * Flow-style sequences (``[A, B, C]`` only)
  * Scalars: null / bool / int / float / string
  * Single-quoted (literal) and double-quoted (with ``\\n \\t \\r \\\\ \\"``)
    strings
  * Block literal scalars: ``|`` (clip), ``|-`` (strip), ``|+`` (keep)
  * Comments (``#`` after whitespace, not inside quoted strings)
  * Document separators (``---`` / ``...``) — ignored, single document only

Explicitly NOT supported (raise :class:`YamlParseError` on encounter):

  * Anchors (``&name``) and aliases (``*name``)
  * Tags (``!!str``)
  * Multi-document streams
  * Folded scalars (``>``)
  * Flow-style mappings (``{key: val}``)

The writer's output convention:

  * Strings without special characters: bare
  * Strings containing newlines: block literal ``|-`` (strip-chomp)
  * Strings whose first character is a YAML indicator: single-quoted
  * Lists: block style (``- item`` per line)
  * Maps: block style with ``key: value``
  * Indent of 2 spaces by default
"""

from __future__ import annotations

import re
from typing import Any

# ---------------------------------------------------------------------------
# Public surface
# ---------------------------------------------------------------------------


class YamlError(Exception):
    """Base class for YAML codec errors."""


class YamlParseError(YamlError):
    """Raised when input cannot be parsed.

    Carries the source line and column (1-based) where the error was detected
    so callers can build helpful error messages.
    """

    def __init__(self, message: str, line: int, col: int) -> None:
        super().__init__(f"{message} (line {line}, column {col})")
        self.message = message
        self.line = line
        self.col = col


def safe_load(stream: str | bytes) -> Any:
    """Parse a YAML document and return the resulting Python object.

    Mirrors ``yaml.safe_load`` for the supported subset. Empty input returns
    ``None``.
    """
    text = stream.decode("utf-8") if isinstance(stream, bytes) else stream
    parser = _Parser(text)
    return parser.parse()


def safe_dump(data: Any, *, indent: int = 2, sort_keys: bool = False) -> str:
    """Serialize a Python object as canonical block-style YAML.

    Parameters
    ----------
    data:
        The value to serialize.
    indent:
        Number of spaces per indent level (default 2).
    sort_keys:
        Sort mapping keys alphabetically when ``True``. Defaults to insertion
        order.
    """
    writer = _Writer(indent=indent, sort_keys=sort_keys)
    writer.write(data)
    return writer.result()


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------


# A "logical line" is the source line stripped of trailing comments and
# trailing whitespace, paired with its indent and original line number for
# error reporting.
class _Line:
    __slots__ = ("content", "indent", "lineno", "raw")

    def __init__(self, indent: int, content: str, lineno: int, raw: str) -> None:
        self.indent = indent
        self.content = content
        self.lineno = lineno
        self.raw = raw

    def __repr__(self) -> str:  # pragma: no cover — debug only
        return f"_Line(indent={self.indent}, content={self.content!r}, lineno={self.lineno})"


class _Parser:
    """Recursive-descent YAML parser for the supported subset."""

    def __init__(self, text: str) -> None:
        # Normalize line endings; YAML allows ``\r\n`` and ``\r`` but our
        # processing assumes ``\n``.
        self._raw_lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
        self._lines: list[_Line] = []
        self._scan()
        self._pos = 0

    # ----- pre-scan: strip comments + collect non-empty content lines ------

    def _scan(self) -> None:
        for idx, raw in enumerate(self._raw_lines):
            stripped_for_doc_marker = raw.strip()
            # Document separator markers — single-document only, so ignore.
            if stripped_for_doc_marker in ("---", "..."):
                continue
            content = _strip_inline_comment(raw)
            stripped = content.strip()
            if not stripped:
                continue
            indent = len(content) - len(content.lstrip(" "))
            self._lines.append(_Line(indent=indent, content=stripped, lineno=idx + 1, raw=raw))

    # ----- parse driver ----------------------------------------------------

    def parse(self) -> Any:
        if not self._lines:
            return None
        first = self._lines[self._pos]
        # Block literal at top level isn't meaningful (a top-level plain
        # scalar is, but a top-level ``|`` would be a single multi-line
        # string that we'd parse as such if encountered). For our use case
        # the document is virtually always a mapping or a sequence.
        return self._parse_node(first.indent)

    # ----- node parsers ----------------------------------------------------

    def _parse_node(self, indent: int) -> Any:
        line = self._peek()
        if line is None:
            return None
        if line.indent < indent:
            return None
        if line.content.startswith("- "):
            return self._parse_block_sequence(indent)
        if line.content == "-":
            return self._parse_block_sequence(indent)
        if _looks_like_mapping(line.content):
            return self._parse_block_mapping(indent)
        # Single scalar at this level.
        self._advance()
        return _parse_scalar(line.content, line.lineno, line.indent + 1)

    def _parse_block_mapping(self, indent: int) -> dict[str, Any]:
        result: dict[str, Any] = {}
        while True:
            line = self._peek()
            if line is None or line.indent < indent:
                return result
            if line.indent > indent:
                # A child showed up where a sibling key was expected — this
                # means the previous key took ownership; the loop should
                # already have consumed it. Reaching here implies malformed
                # input.
                raise YamlParseError(
                    "unexpected indent (mapping key was expected here)",
                    line.lineno,
                    line.indent + 1,
                )
            self._reject_unsupported(line)
            key, rest = _split_key_value(line.content, line.lineno, line.indent + 1)
            self._advance()
            if rest is None or rest == "":
                # Value is a child block (mapping / sequence / multiline).
                result[key] = self._parse_block_value(line.indent)
            elif rest.startswith("|"):
                # Block literal on the same line: ``key: |`` / ``|-`` / ``|+``.
                result[key] = self._parse_block_literal(line, rest, base_indent=line.indent)
            elif rest.startswith(">"):
                raise YamlParseError(
                    "folded scalars (`>`) are not supported",
                    line.lineno,
                    line.indent + 1,
                )
            else:
                result[key] = _parse_scalar(rest, line.lineno, line.indent + 1)

    def _parse_block_value(self, parent_indent: int) -> Any:
        """Consume the child block belonging to a mapping key whose RHS is empty."""
        nxt = self._peek()
        if nxt is None or nxt.indent <= parent_indent:
            return None
        return self._parse_node(nxt.indent)

    def _parse_block_sequence(self, indent: int) -> list[Any]:
        result: list[Any] = []
        while True:
            line = self._peek()
            if line is None or line.indent < indent or not line.content.startswith("-"):
                return result
            if line.indent > indent:
                raise YamlParseError(
                    "unexpected indent in sequence",
                    line.lineno,
                    line.indent + 1,
                )
            self._reject_unsupported(line)
            after_dash = line.content[1:]  # strip the leading ``-``
            if after_dash == "":
                # ``-`` alone — child block on next lines.
                self._advance()
                child = self._parse_block_value(line.indent)
                result.append(child)
                continue
            if not after_dash.startswith(" "):
                raise YamlParseError(
                    "expected space after '-' in block sequence",
                    line.lineno,
                    line.indent + 2,
                )
            payload = after_dash[1:]  # strip the single space
            if _looks_like_mapping(payload):
                # Compact mapping in sequence: ``- key: val`` plus possibly
                # additional ``  key2: val2`` lines indented past the dash.
                # We model this by rewriting the line as if it were the first
                # key of a mapping at indent = ``line.indent + 2`` (one for
                # the dash, one for the space).
                self._advance()
                child_indent = line.indent + 2
                synthetic = _Line(
                    indent=child_indent,
                    content=payload,
                    lineno=line.lineno,
                    raw=line.raw,
                )
                # Re-inject so the mapping parser sees it.
                self._lines.insert(self._pos, synthetic)
                mapping_value = self._parse_block_mapping(child_indent)
                result.append(mapping_value)
                continue
            if payload.startswith("|"):
                self._advance()
                literal_value = self._parse_block_literal(
                    line, payload, base_indent=line.indent + 2
                )
                result.append(literal_value)
                continue
            if payload.startswith(">"):
                raise YamlParseError(
                    "folded scalars (`>`) are not supported",
                    line.lineno,
                    line.indent + 3,
                )
            self._advance()
            result.append(_parse_scalar(payload, line.lineno, line.indent + 3))

    # ----- block literal scalars ------------------------------------------

    def _parse_block_literal(self, header_line: _Line, header: str, *, base_indent: int) -> str:
        """Consume a ``|`` / ``|-`` / ``|+`` block literal scalar."""
        chomp = "clip"  # default
        if header == "|":
            chomp = "clip"
        elif header == "|-":
            chomp = "strip"
        elif header == "|+":
            chomp = "keep"
        else:
            raise YamlParseError(
                f"unsupported block-scalar header: {header!r}",
                header_line.lineno,
                header_line.indent + 1,
            )

        # Block-literal content is read from the *raw* source lines so we
        # preserve embedded blank lines (which the pre-scan dropped). We
        # consume raw lines until we see a non-blank line whose indent is at
        # most ``base_indent``.
        start_raw_idx = header_line.lineno  # 1-based; first content line is here
        collected: list[str] = []
        content_indent: int | None = None
        raw_idx = start_raw_idx
        while raw_idx < len(self._raw_lines):
            raw = self._raw_lines[raw_idx]
            if raw.strip() == "":
                collected.append("")
                raw_idx += 1
                continue
            indent = len(raw) - len(raw.lstrip(" "))
            if indent <= base_indent:
                break
            if content_indent is None:
                content_indent = indent
            collected.append(raw[content_indent:])
            raw_idx += 1

        # Sync the logical-line cursor: advance past every logical line whose
        # ``lineno`` is < ``raw_idx + 1``.
        next_raw_lineno = raw_idx + 1
        while self._pos < len(self._lines) and self._lines[self._pos].lineno < next_raw_lineno:
            self._pos += 1

        # Trim trailing blank lines for chomp handling.
        # ``collected`` contains content lines + blanks in source order. We
        # need to apply chomping to the trailing newlines of the assembled
        # string.
        text = "\n".join(collected)
        # Strip trailing blank "lines" introduced by our blank-passthrough so
        # we have predictable trailing-newline accounting.
        # text always represents the logical block; add a trailing newline so
        # ``clip`` semantics are well-defined.
        if not text.endswith("\n"):
            text = text + "\n"
        # Count trailing newlines.
        end = len(text)
        nl_count = 0
        while end > 0 and text[end - 1] == "\n":
            nl_count += 1
            end -= 1
        body = text[:end]
        if chomp == "strip":
            return body
        if chomp == "clip":
            # Single trailing newline preserved.
            return body + "\n" if body else ""
        # keep: preserve all trailing newlines.
        return body + ("\n" * nl_count)

    # ----- cursor primitives ----------------------------------------------

    def _peek(self) -> _Line | None:
        if self._pos >= len(self._lines):
            return None
        return self._lines[self._pos]

    def _advance(self) -> None:
        self._pos += 1

    @staticmethod
    def _reject_unsupported(line: _Line) -> None:
        # Anchors, aliases, tags. We check the start of the raw content.
        c = line.content
        col = line.indent + 1
        if c.startswith("&"):
            raise YamlParseError("anchors (`&name`) are not supported", line.lineno, col)
        if c.startswith("*"):
            raise YamlParseError("aliases (`*name`) are not supported", line.lineno, col)
        if c.startswith("!"):
            raise YamlParseError("tags (`!!type`) are not supported", line.lineno, col)
        if c.startswith("{"):
            raise YamlParseError(
                "flow-style mappings (`{...}`) are not supported",
                line.lineno,
                line.indent + 1,
            )


# ---------------------------------------------------------------------------
# Lexical helpers
# ---------------------------------------------------------------------------


def _strip_inline_comment(raw: str) -> str:
    """Remove a trailing ``# comment`` from a source line.

    The ``#`` only starts a comment when preceded by whitespace (or at the
    start of a line) AND it is not inside a quoted string.
    """
    result_chars: list[str] = []
    i = 0
    in_single = False
    in_double = False
    n = len(raw)
    while i < n:
        ch = raw[i]
        if in_single:
            result_chars.append(ch)
            if ch == "'":
                # YAML escaping: ``''`` inside single quotes => literal ``'``.
                if i + 1 < n and raw[i + 1] == "'":
                    result_chars.append(raw[i + 1])
                    i += 2
                    continue
                in_single = False
            i += 1
            continue
        if in_double:
            result_chars.append(ch)
            if ch == "\\" and i + 1 < n:
                result_chars.append(raw[i + 1])
                i += 2
                continue
            if ch == '"':
                in_double = False
            i += 1
            continue
        if ch == "'":
            in_single = True
            result_chars.append(ch)
            i += 1
            continue
        if ch == '"':
            in_double = True
            result_chars.append(ch)
            i += 1
            continue
        # Comment marker only when preceded by whitespace or at line start.
        if ch == "#" and (i == 0 or raw[i - 1] in (" ", "\t")):
            break
        result_chars.append(ch)
        i += 1
    return "".join(result_chars).rstrip()


_MAPPING_KEY_RE = re.compile(
    r"""
    ^
    (
        '(?:[^']|'')*'        # single-quoted key
      | "(?:[^"\\]|\\.)*"      # double-quoted key
      | [^\s:#'"\[\{][^:]*?    # bare key (no leading quote / flow / comment)
    )
    \s*:                       # the mandatory colon
    (?:\s|$)                   # followed by whitespace OR end-of-line
    """,
    re.VERBOSE,
)


def _looks_like_mapping(content: str) -> bool:
    """Heuristic: does this logical line start a ``key: value`` mapping?"""
    return _MAPPING_KEY_RE.match(content) is not None


def _split_key_value(content: str, lineno: int, col: int) -> tuple[str, str | None]:
    """Split ``key: value`` (or ``key:``) into its parts.

    Returns ``(key, value_or_None)`` where ``None`` means there was no value
    on this line (the value is a child block).
    """
    match = _MAPPING_KEY_RE.match(content)
    if not match:
        raise YamlParseError("expected mapping key", lineno, col)
    raw_key = match.group(1)
    rest_start = match.end()
    rest = content[rest_start:].strip()
    key = _parse_key(raw_key)
    if rest == "":
        return key, None
    return key, rest


def _parse_key(raw_key: str) -> str:
    """Convert a key token into its string value (handles quoted forms)."""
    raw = raw_key.strip()
    if raw.startswith("'") and raw.endswith("'"):
        return raw[1:-1].replace("''", "'")
    if raw.startswith('"') and raw.endswith('"'):
        return _decode_double_quoted(raw[1:-1])
    return raw


# ---------------------------------------------------------------------------
# Scalar parser
# ---------------------------------------------------------------------------


_INT_RE = re.compile(r"^-?(?:0|[1-9]\d*)$")
_FLOAT_RE = re.compile(r"^-?(?:\d+\.\d*|\.\d+|\d+)(?:[eE][+-]?\d+)?$")
_HEX_RE = re.compile(r"^-?0x[0-9a-fA-F]+$")
_OCT_RE = re.compile(r"^-?0o[0-7]+$")


def _parse_scalar(token: str, lineno: int, col: int) -> Any:
    """Parse a YAML scalar token into the corresponding Python value."""
    if token == "":
        return None
    # Quoted strings.
    if token.startswith("'") and token.endswith("'") and len(token) >= 2:
        return token[1:-1].replace("''", "'")
    if token.startswith('"') and token.endswith('"') and len(token) >= 2:
        return _decode_double_quoted(token[1:-1])
    # Reject unsupported value-side constructs early.
    if token.startswith("&"):
        raise YamlParseError(
            "anchors (`&name`) are not supported",
            lineno,
            col,
        )
    if token.startswith("*"):
        raise YamlParseError(
            "aliases (`*name`) are not supported",
            lineno,
            col,
        )
    if token.startswith("!"):
        raise YamlParseError(
            "tags (`!!type`) are not supported",
            lineno,
            col,
        )
    # Flow sequence.
    if token.startswith("["):
        if not token.endswith("]"):
            raise YamlParseError("unterminated flow sequence", lineno, col)
        return _parse_flow_sequence(token, lineno, col)
    if token.startswith("{"):
        raise YamlParseError(
            "flow-style mappings (`{...}`) are not supported",
            lineno,
            col,
        )
    # Null.
    if token in ("null", "Null", "NULL", "~"):
        return None
    # Booleans (the YAML 1.1 set we support).
    lowered = token.lower()
    if lowered in ("true", "yes", "on"):
        return True
    if lowered in ("false", "no", "off"):
        return False
    # Hex / octal integers.
    if _HEX_RE.match(token):
        return int(token, 16)
    if _OCT_RE.match(token):
        return int(token, 8)
    # Decimal integer.
    if _INT_RE.match(token):
        return int(token)
    # Float.
    if _FLOAT_RE.match(token) and any(ch in token for ch in ".eE"):
        return float(token)
    if token in ("inf", "Inf", "INF", ".inf", ".Inf", ".INF"):
        return float("inf")
    if token in ("-inf", "-Inf", "-INF", "-.inf", "-.Inf", "-.INF"):
        return float("-inf")
    if token in (".nan", ".NaN", ".NAN", "nan", "NaN", "NAN"):
        return float("nan")
    # Plain string fallback.
    return token


_DOUBLE_QUOTED_ESCAPES = {
    "n": "\n",
    "t": "\t",
    "r": "\r",
    "\\": "\\",
    '"': '"',
    "0": "\x00",
    "a": "\a",
    "b": "\b",
    "f": "\f",
    "v": "\v",
    "/": "/",
}


def _decode_double_quoted(s: str) -> str:
    """Apply the supported escape set to a double-quoted body."""
    out: list[str] = []
    i = 0
    n = len(s)
    while i < n:
        ch = s[i]
        if ch == "\\" and i + 1 < n:
            nxt = s[i + 1]
            replacement = _DOUBLE_QUOTED_ESCAPES.get(nxt)
            if replacement is None:
                # Preserve unknown escape verbatim (matches PyYAML behaviour
                # for the limited set we don't model).
                out.append(ch)
                out.append(nxt)
            else:
                out.append(replacement)
            i += 2
            continue
        out.append(ch)
        i += 1
    return "".join(out)


def _parse_flow_sequence(token: str, lineno: int, col: int) -> list[Any]:
    """Parse ``[a, b, c]``-style flow sequences (no nesting required)."""
    body = token[1:-1].strip()
    if body == "":
        return []
    items: list[str] = []
    current: list[str] = []
    in_single = False
    in_double = False
    depth = 0
    for ch in body:
        if in_single:
            current.append(ch)
            if ch == "'":
                in_single = False
            continue
        if in_double:
            current.append(ch)
            if ch == "\\":
                continue  # naive but matches our escape model below
            if ch == '"':
                in_double = False
            continue
        if ch == "'":
            in_single = True
            current.append(ch)
            continue
        if ch == '"':
            in_double = True
            current.append(ch)
            continue
        if ch == "[":
            depth += 1
            current.append(ch)
            continue
        if ch == "]":
            depth -= 1
            current.append(ch)
            continue
        if ch == "," and depth == 0:
            items.append("".join(current).strip())
            current = []
            continue
        current.append(ch)
    last = "".join(current).strip()
    if last != "":
        items.append(last)
    if in_single or in_double:
        raise YamlParseError("unterminated quoted string in flow sequence", lineno, col)
    return [_parse_scalar(item, lineno, col) for item in items]


# ---------------------------------------------------------------------------
# Writer
# ---------------------------------------------------------------------------


# Characters that, if they appear at the start of a bare scalar, force us to
# single-quote the string for safety. This mirrors the YAML 1.2 indicator
# set plus a few practical cases.
_INDICATOR_PREFIXES = (
    "-",
    "?",
    ":",
    ",",
    "[",
    "]",
    "{",
    "}",
    "#",
    "&",
    "*",
    "!",
    "|",
    ">",
    "'",
    '"',
    "%",
    "@",
    "`",
)
_NEEDS_QUOTING_RE = re.compile(r"[:#\n\t]")
_RESERVED_BAREWORDS = {
    "null",
    "Null",
    "NULL",
    "~",
    "true",
    "True",
    "TRUE",
    "false",
    "False",
    "FALSE",
    "yes",
    "Yes",
    "YES",
    "no",
    "No",
    "NO",
    "on",
    "On",
    "ON",
    "off",
    "Off",
    "OFF",
}


class _Writer:
    """Emit canonical block-style YAML for a Python object graph."""

    def __init__(self, *, indent: int, sort_keys: bool) -> None:
        self._indent = indent
        self._sort_keys = sort_keys
        self._out: list[str] = []

    def write(self, data: Any) -> None:
        if isinstance(data, dict):
            if not data:
                self._out.append("{}\n")
                return
            self._write_mapping(data, level=0)
        elif isinstance(data, list):
            if not data:
                self._out.append("[]\n")
                return
            self._write_sequence(data, level=0)
        else:
            self._out.append(self._format_scalar(data) + "\n")

    def result(self) -> str:
        return "".join(self._out)

    # ----- containers ------------------------------------------------------

    def _write_mapping(self, mapping: dict[Any, Any], *, level: int) -> None:
        keys = list(mapping.keys())
        if self._sort_keys:
            keys.sort(key=lambda k: (isinstance(k, str), k))
        prefix = " " * (level * self._indent)
        for key in keys:
            value = mapping[key]
            key_str = self._format_key(key)
            if isinstance(value, dict):
                if not value:
                    self._out.append(f"{prefix}{key_str}: " + "{}\n")
                else:
                    self._out.append(f"{prefix}{key_str}:\n")
                    self._write_mapping(value, level=level + 1)
            elif isinstance(value, list):
                if not value:
                    self._out.append(f"{prefix}{key_str}: " + "[]\n")
                else:
                    self._out.append(f"{prefix}{key_str}:\n")
                    self._write_sequence(value, level=level + 1)
            elif isinstance(value, str) and "\n" in value:
                self._out.append(f"{prefix}{key_str}: |-\n")
                self._write_block_literal(value, level=level + 1)
            else:
                self._out.append(f"{prefix}{key_str}: {self._format_scalar(value)}\n")

    def _write_sequence(self, items: list[Any], *, level: int) -> None:
        prefix = " " * (level * self._indent)
        for item in items:
            if isinstance(item, dict):
                if not item:
                    self._out.append(f"{prefix}- " + "{}\n")
                    continue
                # Compact mapping in sequence: first key on the same line as
                # the dash, subsequent keys indented to match.
                self._write_compact_mapping_in_sequence(item, level=level)
            elif isinstance(item, list):
                if not item:
                    self._out.append(f"{prefix}- " + "[]\n")
                    continue
                self._out.append(f"{prefix}-\n")
                self._write_sequence(item, level=level + 1)
            elif isinstance(item, str) and "\n" in item:
                self._out.append(f"{prefix}- |-\n")
                self._write_block_literal(item, level=level + 1)
            else:
                self._out.append(f"{prefix}- {self._format_scalar(item)}\n")

    def _write_compact_mapping_in_sequence(self, mapping: dict[Any, Any], *, level: int) -> None:
        prefix = " " * (level * self._indent)
        keys = list(mapping.keys())
        if self._sort_keys:
            keys.sort(key=lambda k: (isinstance(k, str), k))
        # Each key after the first uses ``  ``-padded continuation indent
        # equal to ``level + 1`` so children of those keys (if any) still
        # nest correctly.
        continuation = " " * (level * self._indent + 2)
        for idx, key in enumerate(keys):
            value = mapping[key]
            key_str = self._format_key(key)
            line_prefix = f"{prefix}- " if idx == 0 else continuation
            if isinstance(value, dict):
                if not value:
                    self._out.append(f"{line_prefix}{key_str}: " + "{}\n")
                else:
                    self._out.append(f"{line_prefix}{key_str}:\n")
                    self._write_mapping(value, level=level + 2)
            elif isinstance(value, list):
                if not value:
                    self._out.append(f"{line_prefix}{key_str}: " + "[]\n")
                else:
                    self._out.append(f"{line_prefix}{key_str}:\n")
                    self._write_sequence(value, level=level + 2)
            elif isinstance(value, str) and "\n" in value:
                self._out.append(f"{line_prefix}{key_str}: |-\n")
                self._write_block_literal(value, level=level + 2)
            else:
                self._out.append(f"{line_prefix}{key_str}: {self._format_scalar(value)}\n")

    def _write_block_literal(self, value: str, *, level: int) -> None:
        prefix = " " * (level * self._indent)
        # ``|-`` is strip-chomp: trailing newlines are dropped on parse, so
        # we don't emit a blank line at the end.
        text = value
        # Drop any trailing newline (round-trip with strip-chomp parse).
        while text.endswith("\n"):
            text = text[:-1]
        for line in text.split("\n"):
            self._out.append(f"{prefix}{line}\n")

    # ----- scalar formatting ----------------------------------------------

    def _format_key(self, key: Any) -> str:
        if isinstance(key, str):
            return self._format_scalar(key)
        return self._format_scalar(key)

    def _format_scalar(self, value: Any) -> str:
        if value is None:
            return "null"
        if isinstance(value, bool):
            return "true" if value else "false"
        if isinstance(value, int):
            return str(value)
        if isinstance(value, float):
            if value != value:  # NaN
                return ".nan"
            if value == float("inf"):
                return ".inf"
            if value == float("-inf"):
                return "-.inf"
            return repr(value)
        if isinstance(value, str):
            return self._format_string(value)
        # Fallback — represent unknown types as their str() under single quotes.
        return self._quote_single(str(value))

    @staticmethod
    def _format_string(value: str) -> str:
        if value == "":
            return "''"
        # Newlines are handled elsewhere via block literal emission. By the
        # time we get here, we want a single-line representation.
        if "\n" in value:
            # Defensive: fall back to a quoted form rather than raise.
            return _Writer._quote_single(value.replace("\n", "\\n"))
        if (
            value in _RESERVED_BAREWORDS
            or value.startswith(_INDICATOR_PREFIXES)
            or _NEEDS_QUOTING_RE.search(value) is not None
            or value.strip() != value
        ):
            return _Writer._quote_single(value)
        # Pure-numeric strings need quoting too, otherwise round-tripping
        # would re-parse them as int / float.
        if _INT_RE.match(value) or _FLOAT_RE.match(value):
            return _Writer._quote_single(value)
        return value

    @staticmethod
    def _quote_single(value: str) -> str:
        return "'" + value.replace("'", "''") + "'"
