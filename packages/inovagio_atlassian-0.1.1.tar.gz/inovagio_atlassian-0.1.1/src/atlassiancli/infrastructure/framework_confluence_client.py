"""Framework-specific Confluence v2 API methods.

Copied from ``inovagio/scripts/_docframework.py::ConfluenceClient``. Adapted
to delegate to :class:`ConfluenceApiClient` so framework subcommands share
auth + transport with the rest of atlassiancli.

Endpoint shapes (``/wiki/api/v2/pages/{id}``) are preserved exactly — the
sync-docs flow specifically targets v2 for the body-representation /
``next_version`` semantics that the legacy Cloud REST v1 endpoint lacks.
"""

from __future__ import annotations

from typing import Any

from atlassiancli.infrastructure.confluence_client import (
    ConfluenceApiClient,
    ConfluenceApiError,
)


class FrameworkConfluenceClient:
    """v2 page reader / writer for framework subcommands."""

    def __init__(self, api: ConfluenceApiClient) -> None:
        self._api = api

    def get_page(self, page_id: str) -> dict:
        """GET ``/wiki/api/v2/pages/{id}`` with full body."""
        response = self._api.get(f"/wiki/api/v2/pages/{page_id}")
        if response.status_code != 200:
            raise ConfluenceApiError(
                f"get_page({page_id}) failed: {response.status_code} - {response.text[:200]}"
            )
        return response.json()

    def update_page(
        self,
        page_id: str,
        *,
        title: str,
        body_value: str,
        body_representation: str,
        version_message: str,
        next_version: int,
    ) -> dict:
        """PUT ``/wiki/api/v2/pages/{id}`` with a versioned body update."""
        payload: dict[str, Any] = {
            "id": page_id,
            "status": "current",
            "title": title,
            "body": {"representation": body_representation, "value": body_value},
            "version": {"number": next_version, "message": version_message},
        }
        response = self._api.put(f"/wiki/api/v2/pages/{page_id}", payload)
        if response.status_code not in (200, 201, 204):
            raise ConfluenceApiError(
                f"update_page({page_id}) failed: {response.status_code} - {response.text[:500]}"
            )
        return response.json() if response.status_code != 204 else {}


__all__ = ["FrameworkConfluenceClient"]
