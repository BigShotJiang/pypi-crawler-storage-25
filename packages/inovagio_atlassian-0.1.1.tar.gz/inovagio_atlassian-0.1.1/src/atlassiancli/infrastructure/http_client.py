"""Stdlib-only HTTP client for Atlassian REST APIs.

A small wrapper around :mod:`urllib.request` that exposes a ``requests``-like
ergonomic surface (``get`` / ``post`` / ``put`` / ``delete`` returning a
:class:`HttpResponse`) while remaining strictly dependency-free. The error
hierarchy is stable so callers can branch on auth / rate-limit / transient /
client-error categories without parsing status codes themselves.

The client deliberately performs no logging and emits no output — the caller
decides whether (and how) to surface request/response activity.
"""

from __future__ import annotations

import base64
import json
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from typing import Any

# Truncate body bytes attached to error objects at this size for diagnostics.
# Any larger and the resulting tracebacks become unreadable; smaller and we
# may discard the JSON error payload Atlassian returns. 4 KiB strikes a
# reasonable balance.
_ERROR_BODY_TRUNCATION_BYTES = 4096


# ---------------------------------------------------------------------------
# Error hierarchy
# ---------------------------------------------------------------------------


class HttpError(Exception):
    """Base class for all errors raised by :class:`HttpClient`.

    The HTTP status (when available), response headers, and a (possibly
    truncated) snapshot of the response body are attached so callers can
    surface diagnostics without re-issuing the request.
    """

    def __init__(
        self,
        message: str,
        *,
        status: int | None = None,
        headers: dict[str, str] | None = None,
        body: bytes | None = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.headers = headers or {}
        # Truncate so the exception remains printable.
        if body is not None and len(body) > _ERROR_BODY_TRUNCATION_BYTES:
            self.body = body[:_ERROR_BODY_TRUNCATION_BYTES]
            self.body_truncated = True
        else:
            self.body = body or b""
            self.body_truncated = False


class HttpAuthError(HttpError):
    """401 Unauthorized or 403 Forbidden — credentials missing / invalid."""


class HttpRateLimitError(HttpError):
    """429 Too Many Requests or 503 Service Unavailable.

    The ``retry_after_seconds`` attribute is parsed from the ``Retry-After``
    header when present (delta-seconds form only — HTTP-date form is left as
    ``None`` because converting it requires timezone arithmetic that the
    caller is better positioned to do).
    """

    def __init__(
        self,
        message: str,
        *,
        status: int | None = None,
        headers: dict[str, str] | None = None,
        body: bytes | None = None,
        retry_after_seconds: float | None = None,
    ) -> None:
        super().__init__(message, status=status, headers=headers, body=body)
        self.retry_after_seconds = retry_after_seconds


class HttpTransientError(HttpError):
    """5xx server errors and network-level transient failures (timeouts)."""


class HttpClientError(HttpError):
    """Other 4xx client errors (404, 400, 422, ...)."""


# ---------------------------------------------------------------------------
# Response value object
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class HttpResponse:
    """Result of a successful (2xx/3xx) HTTP request."""

    status: int
    headers: dict[str, str] = field(default_factory=dict)
    body_bytes: bytes = b""

    @property
    def text(self) -> str:
        """Decode the body as UTF-8 (with replacement for invalid bytes)."""
        return self.body_bytes.decode("utf-8", errors="replace")

    def json(self) -> Any:
        """Parse the body as JSON via :mod:`json`.

        Raises :class:`json.JSONDecodeError` if the body is not valid JSON.
        """
        return json.loads(self.body_bytes.decode("utf-8"))


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------


class HttpClient:
    """Minimal HTTP client built on :mod:`urllib.request`.

    Parameters
    ----------
    base_url:
        Optional URL prefix joined with the per-call ``path``. When ``None``,
        each call must pass an absolute URL.
    auth:
        Optional ``(email, token)`` tuple for HTTP Basic authentication.
        Encoded once and added to every request as ``Authorization: Basic ...``.
    timeout_seconds:
        Per-call timeout. Network-level timeouts surface as
        :class:`HttpTransientError`.
    default_headers:
        Headers added to every request. Per-call headers override these.
    """

    def __init__(
        self,
        base_url: str | None = None,
        *,
        auth: tuple[str, str] | None = None,
        timeout_seconds: float = 30.0,
        default_headers: dict[str, str] | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/") if base_url else None
        self._timeout_seconds = timeout_seconds
        self._default_headers: dict[str, str] = dict(default_headers or {})
        if auth is not None:
            email, token = auth
            credential = f"{email}:{token}".encode()
            encoded = base64.b64encode(credential).decode("ascii")
            self._default_headers["Authorization"] = f"Basic {encoded}"

    # -- public surface -----------------------------------------------------

    def get(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> HttpResponse:
        """Issue an HTTP GET. ``params`` is URL-encoded onto the query string."""
        return self._request("GET", path, params=params, headers=headers)

    def post(
        self,
        path: str,
        *,
        json: Any = None,
        headers: dict[str, str] | None = None,
    ) -> HttpResponse:
        """Issue an HTTP POST. ``json`` is encoded as a UTF-8 JSON body."""
        return self._request("POST", path, json_body=json, headers=headers)

    def put(
        self,
        path: str,
        *,
        json: Any = None,
        headers: dict[str, str] | None = None,
    ) -> HttpResponse:
        """Issue an HTTP PUT. ``json`` is encoded as a UTF-8 JSON body."""
        return self._request("PUT", path, json_body=json, headers=headers)

    def delete(
        self,
        path: str,
        *,
        headers: dict[str, str] | None = None,
    ) -> HttpResponse:
        """Issue an HTTP DELETE."""
        return self._request("DELETE", path, headers=headers)

    # -- internals ----------------------------------------------------------

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json_body: Any = None,
        headers: dict[str, str] | None = None,
    ) -> HttpResponse:
        url = self._build_url(path, params=params)
        body_bytes: bytes | None = None
        merged_headers: dict[str, str] = dict(self._default_headers)
        if headers:
            merged_headers.update(headers)
        if json_body is not None:
            body_bytes = json.dumps(json_body).encode("utf-8")
            merged_headers.setdefault("Content-Type", "application/json")
            merged_headers.setdefault("Accept", "application/json")

        request = urllib.request.Request(
            url=url,
            data=body_bytes,
            headers=merged_headers,
            method=method,
        )

        try:
            with urllib.request.urlopen(request, timeout=self._timeout_seconds) as response:
                resp_body = response.read()
                resp_headers = _flatten_headers(response.headers.items())
                resp_status = int(response.status)
        except urllib.error.HTTPError as exc:  # type: ignore[misc]
            self._raise_for_status_error(exc)
            # _raise_for_status_error always raises; appease the type checker.
            raise  # pragma: no cover
        except urllib.error.URLError as exc:
            # Includes timeouts (``socket.timeout``) and DNS / connection
            # failures. We classify all of these as transient — callers that
            # want different semantics can catch the base class.
            raise HttpTransientError(f"Network error contacting {url}: {exc.reason!r}") from exc

        return HttpResponse(
            status=resp_status,
            headers=resp_headers,
            body_bytes=resp_body,
        )

    def _build_url(self, path: str, *, params: dict[str, Any] | None) -> str:
        if path.startswith(("http://", "https://")):
            url = path
        elif self._base_url is None:
            raise ValueError("HttpClient was constructed without base_url; path must be absolute")
        else:
            url = f"{self._base_url}/{path.lstrip('/')}"
        if params:
            query = urllib.parse.urlencode(params, doseq=True)
            separator = "&" if "?" in url else "?"
            url = f"{url}{separator}{query}"
        return url

    @staticmethod
    def _raise_for_status_error(exc: urllib.error.HTTPError) -> None:
        status = int(exc.code)
        try:
            body = exc.read()
        except Exception:
            body = b""
        headers = _flatten_headers(exc.headers.items()) if exc.headers else {}
        message = f"HTTP {status} from {exc.url}: {exc.reason}"

        if status in (401, 403):
            raise HttpAuthError(message, status=status, headers=headers, body=body)
        if status in (429, 503):
            retry_after = _parse_retry_after(headers.get("Retry-After"))
            raise HttpRateLimitError(
                message,
                status=status,
                headers=headers,
                body=body,
                retry_after_seconds=retry_after,
            )
        if 500 <= status <= 599:
            raise HttpTransientError(message, status=status, headers=headers, body=body)
        raise HttpClientError(message, status=status, headers=headers, body=body)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _flatten_headers(items: Any) -> dict[str, str]:
    """Convert a header iterable (possibly multi-valued) into a flat dict.

    Multi-valued headers are joined with ``", "`` per RFC 7230 §3.2.2.
    """
    result: dict[str, str] = {}
    for name, value in items:
        if name in result:
            result[name] = f"{result[name]}, {value}"
        else:
            result[name] = value
    return result


def _parse_retry_after(value: str | None) -> float | None:
    """Parse the delta-seconds form of ``Retry-After``.

    HTTP-date form (e.g. ``Fri, 31 Dec 1999 23:59:59 GMT``) is intentionally
    not handled here — the caller is in a better position to decide what
    "now" means relative to that absolute time.
    """
    if value is None:
        return None
    stripped = value.strip()
    try:
        return float(stripped)
    except ValueError:
        return None
