#!/usr/bin/env python3
"""
Mappers - Domain Model <-> API Payload Conversion

Translates between domain models and Jira/Confluence API formats.

Author: Inovagio Engineering Team
"""

from typing import Any

from ..domain.models import Epic, Issue, Story, Task
from ..domain.value_objects import (
    AcceptanceCriterion,
    BoundedContext,
    Component,
    IssueKey,
    IssueType,
    Label,
    Priority,
    StoryPoints,
    get_bounded_context,
)


class IssueMapper:
    """Maps between domain Issue models and Jira API payloads"""

    def __init__(self, config):
        self._config = config
        self._story_points_field = config.story_points_field
        self._sprint_field = config.sprint_field
        self._epic_link_field = config.epic_link_field

    def to_api_payload(self, issue: Issue) -> dict[str, Any]:
        """Convert domain model to Jira API create payload"""
        fields: dict[str, Any] = {
            "project": {"key": self._config.project_key},
            "summary": issue.title,
            "description": self._to_jira_description(issue.description),
            "issuetype": {"name": issue.issue_type.value},
            "priority": {"name": issue.priority.value},
        }

        # Labels
        if issue.labels:
            fields["labels"] = [label.value for label in issue.labels]

        # Components
        if issue.components:
            fields["components"] = [{"name": comp.name} for comp in issue.components]

        # Type-specific fields
        if isinstance(issue, Story):
            if issue.story_points:
                fields[self._story_points_field] = issue.story_points.value

            if issue.epic_key:
                fields[self._epic_link_field] = issue.epic_key.key

        elif isinstance(issue, Task):
            if issue.parent_story_key:
                fields["parent"] = {"key": issue.parent_story_key.key}

        return {"fields": fields}

    def to_update_payload(self, issue: Issue) -> dict[str, Any]:
        """Convert domain model to Jira API update payload"""
        fields: dict[str, Any] = {
            "summary": issue.title,
            "description": self._to_jira_description(issue.description),
            "priority": {"name": issue.priority.value},
        }

        if issue.labels:
            fields["labels"] = [label.value for label in issue.labels]

        if issue.components:
            fields["components"] = [{"name": comp.name} for comp in issue.components]

        if isinstance(issue, (Story, Task)) and issue.story_points:
            # Only include story points if not a sub-task (usually not supported on sub-task screens)
            if issue.issue_type != IssueType.SUBTASK:
                fields[self._story_points_field] = issue.story_points.value

        return {"fields": fields}

    def to_domain_model(self, api_data: dict[str, Any]) -> Issue:
        """Convert Jira API response to domain model"""
        fields = api_data.get("fields", {})
        key = IssueKey(api_data["key"])

        issue_type_name = fields.get("issuetype", {}).get("name", "Story")
        issue_type = self._map_issue_type(issue_type_name)

        title = fields.get("summary", "")
        description = self._from_jira_description(fields.get("description"))

        priority_name = fields.get("priority", {}).get("name", "Medium")
        priority = self._map_priority(priority_name)

        # Detect bounded context from components
        components = fields.get("components", [])
        component_names = [c.get("name") for c in components]
        context = self._detect_context(component_names, title, description)

        # Create appropriate domain model
        if issue_type == IssueType.EPIC:
            epic = Epic(
                key=key,
                title=title,
                description=description,
                objective=self._extract_section(description, "objective") or "TBD",
                bounded_context=context,
                priority=priority,
            )
            self._populate_common_fields(epic, fields)
            return epic

        elif issue_type == IssueType.STORY:
            epic_link = fields.get(self._epic_link_field)
            epic_key = IssueKey(epic_link) if epic_link else None

            story = Story(
                key=key,
                title=title,
                description=description,
                bounded_context=context,
                epic_key=epic_key,
                priority=priority,
            )

            # Story points - handle validation errors gracefully for existing issues
            sp_value = fields.get(self._story_points_field)
            if sp_value and isinstance(sp_value, (int, float)):
                try:
                    story.set_story_points(StoryPoints(int(sp_value)))
                except Exception:
                    # Story points too high - this is an existing issue that violates our rules
                    # Set to max allowed (8) and note the original value
                    story.set_story_points(StoryPoints(8))
                    # Store original value for reference
                    story._original_story_points = int(sp_value)

            # Acceptance criteria
            criteria = self._extract_acceptance_criteria(description)
            for criterion in criteria:
                story.add_acceptance_criterion(AcceptanceCriterion(criterion))

            # Derive technical metadata from enhanced descriptions
            technical_section = self._extract_section(description, "technical approach")
            integration_section = self._extract_section(description, "integration points")

            if technical_section:
                for module in self._extract_affected_modules(technical_section):
                    story.add_affected_module(module)

                for integration in self._extract_integration_points(technical_section):
                    story.add_integration_point(integration)

            if integration_section:
                for integration in self._extract_integration_points(integration_section):
                    story.add_integration_point(integration)

            self._populate_common_fields(story, fields)
            return story

        else:  # Task or Sub-task
            parent_data = fields.get("parent", {})
            parent_key = IssueKey(parent_data.get("key")) if parent_data else None

            if not parent_key:
                # Fallback for tasks without parent
                parent_key = key  # Use self as parent (will be handled)

            task = Task(
                key=key,
                title=title,
                description=description,
                parent_story_key=parent_key,
                priority=priority,
                issue_type=issue_type,
            )
            self._populate_common_fields(task, fields)
            return task

    def _populate_common_fields(self, issue: Issue, fields: dict):
        """Populate common fields (labels, components, themes)"""
        # Labels
        labels = fields.get("labels", [])
        for label_str in labels:
            try:
                issue.add_label(Label(label_str))
            except ValueError:
                pass  # Skip invalid labels

        # Components
        components = fields.get("components", [])
        for comp_data in components:
            comp_name = comp_data.get("name")
            if comp_name:
                issue.add_component(Component(comp_name))

        # Detect themes from title/description
        text = issue.title + " " + issue.description
        from .domain_services import ThemeDetectorService

        theme_detector = ThemeDetectorService()
        themes = theme_detector.detect_themes(text)
        for theme in themes:
            issue.add_theme(theme)

    def _map_issue_type(self, type_name: str) -> IssueType:
        """Map API issue type to domain enum"""
        type_map = {
            "Epic": IssueType.EPIC,
            "Story": IssueType.STORY,
            "Task": IssueType.TASK,
            "Sub-task": IssueType.SUBTASK,
            "Bug": IssueType.BUG,
        }
        return type_map.get(type_name, IssueType.STORY)

    def _map_priority(self, priority_name: str) -> Priority:
        """Map API priority to domain enum"""
        priority_map = {
            "Highest": Priority.HIGHEST,
            "High": Priority.HIGH,
            "Medium": Priority.MEDIUM,
            "Low": Priority.LOW,
            "Lowest": Priority.LOWEST,
        }
        return priority_map.get(priority_name, Priority.MEDIUM)

    def _detect_context(
        self, component_names: list[str], title: str, description: str
    ) -> BoundedContext:
        """Detect bounded context from components and text"""
        # Try components first
        for comp_name in component_names:
            if comp_name in [
                "core-ani",
                "core-orchestration",
                "core-governance",
                "core-connectors",
                "core-agents",
                "core-persistence",
            ]:
                return get_bounded_context(comp_name)

        # Fallback to text detection
        from .domain_services import BoundedContextResolverService, ThemeDetectorService

        theme_detector = ThemeDetectorService()
        context_resolver = BoundedContextResolverService()

        text = title + " " + description
        themes = theme_detector.detect_themes(text)
        return context_resolver.resolve_context(themes, text)

    def _extract_section(self, text: str, header: str) -> str | None:
        """Extract content under a header"""
        import re

        if not text:
            return None
        pattern = rf"(?:h[23]\.|##)\s*{header}[^\n]*\n(.*?)(?=h[23]\.|##|----|\Z)"
        match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
        return match.group(1).strip() if match else None

    def _extract_acceptance_criteria(self, text: str) -> list[str]:
        """Extract acceptance criteria from description"""
        import re

        criteria: list[str] = []

        # Find acceptance criteria section
        ac_section = self._extract_section(text, "acceptance criteria")
        if not ac_section:
            return criteria

        # Extract bullet points or numbered items
        lines = ac_section.split("\n")
        for line in lines:
            line = line.strip()
            # Match bullets, numbers, or checkboxes
            if re.match(r"^[-*\d]+[.)]\s+|^\[[ x]\]\s+", line):
                criterion = re.sub(r"^[-*\d]+[.)]\s+|^\[[ x]\]\s+", "", line).strip()
                if criterion:
                    criteria.append(criterion)

        return criteria

    def _extract_affected_modules(self, text: str) -> list[str]:
        """Extract affected module/component names from technical sections."""
        import re

        modules: list[str] = []
        for line in text.split("\n"):
            normalized = line.strip()
            if not normalized:
                continue

            # Examples: "• *NativeBridge*: ..." or "- core-ani"
            name_match = re.search(r"\*([A-Za-z][A-Za-z0-9_\-]+)\*\s*:", normalized)
            if name_match:
                modules.append(name_match.group(1))
                continue

            plain_match = re.match(r"^[-*•]\s+([A-Za-z][A-Za-z0-9_\-/]+)$", normalized)
            if plain_match:
                modules.append(plain_match.group(1))

        # Keep order, remove duplicates
        return list(dict.fromkeys(modules))[:8]

    def _extract_integration_points(self, text: str) -> list[str]:
        """Extract integration points from technical sections."""
        import re

        integrations: list[str] = []
        capture = False
        for line in text.split("\n"):
            normalized = line.strip()
            if not normalized:
                continue

            if re.search(r"integration points", normalized, re.IGNORECASE):
                capture = True
                continue

            if capture and re.match(r"^\*[^*]+\*:\s*$", normalized):
                break

            if capture:
                bullet = re.sub(r"^[-*•]\s+", "", normalized)
                if bullet:
                    integrations.append(bullet)

        if not integrations:
            for line in text.split("\n"):
                normalized = line.strip()
                if "core-" in normalized or "Bridge" in normalized or "Service" in normalized:
                    cleaned = re.sub(r"^[-*•]\s+", "", normalized)
                    cleaned = cleaned.strip()
                    if cleaned:
                        integrations.append(cleaned)

        return list(dict.fromkeys(integrations))[:8]

    def _to_jira_description(self, description: Any) -> dict[str, Any]:
        """Convert description to Atlassian Document Format (ADF).

        Jira API v3 REQUIRES ADF for description field.
        If description is already a dict, it's assumed to be ADF.
        If it's a string, it's wrapped in basic ADF structure.
        """
        if not description:
            return {"version": 1, "type": "doc", "content": []}

        if isinstance(description, dict):
            # Already ADF
            return description

        # Use AtlassianDocumentWriter for consistent ADF generation (SOLID/DRY)
        from .document_writer import AtlassianDocumentWriter, DocumentSection

        writer = AtlassianDocumentWriter()

        # Split into paragraphs and treat as a single section
        # This ensures rich text (bold, links) is parsed correctly
        section = DocumentSection(title="", content=str(description), show_rule=False)

        return writer.create_document([section])

    def _from_jira_description(self, description_obj: Any) -> str:
        """Convert Jira description format (ADF) to plain text/markdown.

        This is used when reading issues from Jira to reconstruct a readable
        description that can be sanitized or displayed.
        """
        if not description_obj:
            return ""

        if isinstance(description_obj, str):
            return description_obj

        if isinstance(description_obj, dict):
            # Extract text from Atlassian Document Format
            content = description_obj.get("content", [])
            text_parts = []

            for block in content:
                block_type = block.get("type")

                if block_type == "paragraph":
                    para_content = block.get("content", [])
                    para_text = "".join(
                        [
                            item.get("text", "")
                            for item in para_content
                            if item.get("type") == "text"
                        ]
                    )
                    if para_text:
                        text_parts.append(para_text)

                elif block_type == "heading":
                    level = block.get("attrs", {}).get("level", 1)
                    heading_content = block.get("content", [])
                    heading_text = "".join(
                        [
                            item.get("text", "")
                            for item in heading_content
                            if item.get("type") == "text"
                        ]
                    )
                    text_parts.append(f"{'#' * level} {heading_text}")

                elif block_type == "bulletList":
                    list_items = block.get("content", [])
                    for item in list_items:
                        if item.get("type") == "listItem":
                            # List items contain blocks (usually paragraphs)
                            item_blocks = item.get("content", [])
                            item_text = self._from_jira_description({"content": item_blocks})
                            text_parts.append(f"* {item_text}")

                elif block_type == "rule":
                    text_parts.append("---")

                elif block_type == "codeBlock":
                    code_content = block.get("content", [])
                    code_text = "".join(
                        [
                            item.get("text", "")
                            for item in code_content
                            if item.get("type") == "text"
                        ]
                    )
                    text_parts.append(f"```\n{code_text}\n```")

            return "\n\n".join(text_parts)

        return str(description_obj)


class ConfluenceContentMapper:
    """Maps domain models to Confluence page content (XHTML)"""

    def story_to_spec_page(self, story: Story) -> str:
        """Generate comprehensive Story Spec page content"""
        # Build sections dynamically based on what's populated

        epic_link = (
            f"<p><strong>Epic Link:</strong> {story.epic_key.key if story.epic_key else 'None'}</p>"
            if story.epic_key
            else ""
        )

        context_section = self._build_context_section(story)
        solution_section = self._build_solution_section(story)
        architecture_section = self._build_architecture_section(story)
        requirements_section = self._build_requirements_section(story)
        integration_section = self._build_integration_section(story)
        acceptance_section = self._build_acceptance_section(story)
        testing_section = self._build_testing_section(story)
        delivery_section = self._build_delivery_section(story)
        readiness_section = self._build_readiness_section(story)

        return f"""
<h1>📋 STORY SPEC - {story.key.key if story.key else "NEW"} - {self._escape(story.title)}</h1>

<h2>1. Overview</h2>
<p><strong>Story:</strong> {self._escape(story.title)}</p>
<p><strong>Key:</strong> {story.key.key if story.key else "NEW"}</p>
{epic_link}
<p><strong>Bounded Context:</strong> {story.bounded_context.name}</p>
<p><strong>Priority:</strong> {story.priority.value}</p>
{f"<p><strong>Story Points:</strong> {story.story_points.value}</p>" if story.story_points else ""}

{context_section}

{solution_section}

{architecture_section}

{requirements_section}

{integration_section}

{acceptance_section}

{testing_section}

{delivery_section}

{readiness_section}

<hr/>
<p><em>Status: Draft | Owner: {getattr(story, "assignee", "Unassigned")} | Last Updated: {story._updated_at.strftime("%Y-%m-%d %H:%M") if hasattr(story, "_updated_at") and story._updated_at else "N/A"}</em></p>
"""

    def _build_context_section(self, story: Story) -> str:
        """Build Context & Intent section"""
        if not (story.story_intent or story.problem_statement or story.description):
            return ""

        intent = (
            f"<p><strong>Story Intent:</strong> {self._escape(story.story_intent)}</p>"
            if story.story_intent
            else ""
        )
        problem = (
            f"<p><strong>Problem Statement:</strong> {self._escape(story.problem_statement)}</p>"
            if story.problem_statement
            else ""
        )
        description = f"<p>{self._escape(story.description)}</p>" if story.description else ""

        return f"""
<h2>2. Context &amp; Intent</h2>
{intent}
{problem}
{description}
"""

    def _build_solution_section(self, story: Story) -> str:
        """Build Proposed Solution section"""
        if not story.proposed_solution:
            return ""

        return f"""
<h2>3. Proposed Solution (High-Level)</h2>
<p>{self._escape(story.proposed_solution)}</p>
"""

    def _build_architecture_section(self, story: Story) -> str:
        """Build Architecture References section"""
        modules_html = ""
        if story.affected_modules:
            modules_html = "<p><strong>Affected Modules:</strong></p><ul>"
            for module in story.affected_modules:
                modules_html += f"<li><code>{self._escape(module)}</code></li>"
            modules_html += "</ul>"

        return f"""
<h2>4. Architecture &amp; Design</h2>
<p><strong>Bounded Context:</strong> {story.bounded_context.name}</p>
<p><strong>Layer:</strong> {story.bounded_context.layer}</p>
<p><strong>Design Patterns:</strong> {", ".join(story.bounded_context.patterns)}</p>
{modules_html}
<p><em>Note: Link to architecture diagrams, API contracts, and data models should be added as page attachments or web links.</em></p>
"""

    def _build_requirements_section(self, story: Story) -> str:
        """Build Requirements section"""
        if not (
            story.functional_requirements
            or story.nonfunctional_requirements
            or story.security_requirements
        ):
            return ""

        functional_html = ""
        if story.functional_requirements:
            functional_html = "<h3>Functional Requirements</h3><ol>"
            for req in story.functional_requirements:
                functional_html += f"<li>{self._escape(req)}</li>"
            functional_html += "</ol>"

        nonfunctional_html = ""
        if story.nonfunctional_requirements:
            nonfunctional_html = "<h3>Non-Functional Requirements</h3><ul>"
            for req in story.nonfunctional_requirements:
                nonfunctional_html += f"<li>{self._escape(req)}</li>"
            nonfunctional_html += "</ul>"

        security_html = ""
        if story.security_requirements:
            security_html = "<h3>Security Requirements</h3><ul>"
            for req in story.security_requirements:
                security_html += f"<li>{self._escape(req)}</li>"
            security_html += "</ul>"

        return f"""
<h2>5. Requirements</h2>
{functional_html}
{nonfunctional_html}
{security_html}
"""

    def _build_integration_section(self, story: Story) -> str:
        """Build Integration Points section"""
        if not story.integration_points:
            return ""

        integrations_html = "<ul>"
        for integration in story.integration_points:
            integrations_html += f"<li>{self._escape(integration)}</li>"
        integrations_html += "</ul>"

        return f"""
<h2>6. Integration Points &amp; Dependencies</h2>
{integrations_html}
"""

    def _build_acceptance_section(self, story: Story) -> str:
        """Build Acceptance Criteria section"""
        if not story.acceptance_criteria:
            return ""

        return f"""
<h2>7. Acceptance Criteria (Gherkin)</h2>
<ul>
{self._criteria_to_html(story.acceptance_criteria)}
</ul>
<p><em>Format: Given [context], When [action], Then [outcome]</em></p>
"""

    def _build_testing_section(self, story: Story) -> str:
        """Build Testing Requirements section"""
        if not (story.unit_test_spec or story.integration_test_spec or story.test_data_and_mocks):
            return ""

        unit_html = (
            f"<h3>Unit Test Spec</h3><pre>{self._escape(story.unit_test_spec)}</pre>"
            if story.unit_test_spec
            else ""
        )
        integration_html = (
            f"<h3>Integration Test Spec</h3><pre>{self._escape(story.integration_test_spec)}</pre>"
            if story.integration_test_spec
            else ""
        )
        test_data_html = (
            f"<h3>Test Data &amp; Mocks</h3><pre>{self._escape(story.test_data_and_mocks)}</pre>"
            if story.test_data_and_mocks
            else ""
        )

        return f"""
<h2>8. Testing Requirements</h2>
{unit_html}
{integration_html}
{test_data_html}
<p><strong>Coverage Target:</strong> &gt;85% (enforced in CI)</p>
"""

    def _build_delivery_section(self, story: Story) -> str:
        """Build Delivery & Operations section"""
        if not (story.cicd_requirements or story.observability_spec or story.rollback_strategy):
            return ""

        cicd_html = (
            f"<h3>CI/CD Requirements</h3><p>{self._escape(story.cicd_requirements)}</p>"
            if story.cicd_requirements
            else ""
        )
        observability_html = (
            f"<h3>Observability Spec</h3><p>{self._escape(story.observability_spec)}</p>"
            if story.observability_spec
            else ""
        )
        rollback_html = (
            f"<h3>Rollback Strategy</h3><p>{self._escape(story.rollback_strategy)}</p>"
            if story.rollback_strategy
            else ""
        )

        return f"""
<h2>9. Delivery &amp; Operations</h2>
{cicd_html}
{observability_html}
{rollback_html}
"""

    def _build_readiness_section(self, story: Story) -> str:
        """Build AI Readiness section"""
        return f"""
<h2>10. AI Readiness Assessment</h2>
<p><strong>Readiness Level:</strong> {story.ai_readiness_level.value}</p>
<p><strong>Readiness Score:</strong> {story.ai_readiness_score}/100</p>
<h3>Completeness Checklist:</h3>
<ul>
<li>{"✅" if story.story_intent else "⬜"} Story Intent defined</li>
<li>{"✅" if story.problem_statement else "⬜"} Problem Statement documented</li>
<li>{"✅" if story.proposed_solution else "⬜"} Solution approach described</li>
<li>{"✅" if story.affected_modules else "⬜"} Affected modules identified</li>
<li>{"✅" if story.functional_requirements else "⬜"} Functional requirements specified</li>
<li>{"✅" if story.nonfunctional_requirements else "⬜"} Non-functional requirements defined</li>
<li>{"✅" if story.security_requirements else "⬜"} Security requirements documented</li>
<li>{"✅" if story.acceptance_criteria else "⬜"} Acceptance criteria in Gherkin format</li>
<li>{"✅" if story.unit_test_spec else "⬜"} Unit test specifications written</li>
<li>{"✅" if story.integration_test_spec else "⬜"} Integration test scenarios defined</li>
<li>{"✅" if story.test_data_and_mocks else "⬜"} Test data and mocks prepared</li>
<li>{"✅" if story.cicd_requirements else "⬜"} CI/CD requirements specified</li>
<li>{"✅" if story.observability_spec else "⬜"} Observability configured</li>
<li>{"✅" if story.rollback_strategy else "⬜"} Rollback strategy documented</li>
</ul>
"""

    def story_to_test_plan_page(self, story: Story) -> str:
        """Generate comprehensive Test Plan page content"""
        return f"""
<h1>🧪 TEST PLAN - {story.key.key if story.key else "NEW"} - {self._escape(story.title)}</h1>

<h2>1. Test Strategy</h2>
<p><strong>Story:</strong> {story.key.key if story.key else "NEW"} - {self._escape(story.title)}</p>
<p><strong>Bounded Context:</strong> {story.bounded_context.name}</p>
<p><strong>Scope:</strong> Unit, Integration, Acceptance (E2E)</p>
<p><strong>Approach:</strong> Test-Driven Development (TDD) with property-based testing</p>
<p><strong>Tools:</strong> Google Test, Catch2, PropertyBasedTesting, Hypothesis</p>
<p><strong>Coverage Target:</strong> &gt;85% (enforced in CI with -Werror)</p>

<h2>2. Unit Tests</h2>
{f"<pre>{self._escape(story.unit_test_spec)}</pre>" if story.unit_test_spec else "<p><em>Define unit test cases for individual functions/methods.</em></p>"}
<h3>Test Cases Template:</h3>
<table>
<thead>
<tr>
<th>Test Case</th>
<th>Input</th>
<th>Expected Output</th>
<th>Coverage</th>
</tr>
</thead>
<tbody>
<tr>
<td>test_valid_input</td>
<td>Valid parameters</td>
<td>Success result</td>
<td>Happy path</td>
</tr>
<tr>
<td>test_invalid_input</td>
<td>Invalid parameters</td>
<td>Error result</td>
<td>Error handling</td>
</tr>
<tr>
<td>test_edge_cases</td>
<td>Boundary values</td>
<td>Correct behavior</td>
<td>Edge cases</td>
</tr>
</tbody>
</table>

<h2>3. Integration Tests</h2>
{f"<pre>{self._escape(story.integration_test_spec)}</pre>" if story.integration_test_spec else "<p><em>Define integration test scenarios involving multiple components.</em></p>"}
<h3>Integration Scenarios:</h3>
<ul>
<li>End-to-end flow with real dependencies</li>
<li>Database integration (use test containers)</li>
<li>External API integration (with mocks/stubs)</li>
<li>Event bus integration (publish/subscribe)</li>
</ul>

<h2>4. Acceptance Tests (E2E)</h2>
<h3>User Stories &amp; Scenarios:</h3>
<ul>
{self._criteria_to_html(story.acceptance_criteria) if story.acceptance_criteria else "<li><em>Define acceptance criteria in Gherkin format (Given/When/Then).</em></li>"}
</ul>
<p><strong>Test Environment:</strong> Staging with production-like data</p>
<p><strong>Test Users:</strong> Admin, Developer, Viewer roles</p>

<h2>5. Test Data &amp; Mocks</h2>
{f"<pre>{self._escape(story.test_data_and_mocks)}</pre>" if story.test_data_and_mocks else "<p><em>Define test fixtures, mock objects, and seed data.</em></p>"}
<h3>Test Data Requirements:</h3>
<ul>
<li><strong>Mock Users:</strong> admin, developer, viewer</li>
<li><strong>Mock Data:</strong> Sample entities with various states</li>
<li><strong>Test Database:</strong> Migrations applied, seed data loaded</li>
<li><strong>External Services:</strong> Mocked with predictable responses</li>
</ul>

<h2>6. Non-Functional Tests</h2>
<h3>Performance Testing:</h3>
<ul>
<li><strong>Load:</strong> 1000 requests/sec sustained for 5 minutes</li>
<li><strong>Latency:</strong> p95 &lt; 100ms, p99 &lt; 500ms</li>
<li><strong>Throughput:</strong> System handles expected load without degradation</li>
</ul>

<h3>Security Testing:</h3>
<ul>
<li><strong>Authentication:</strong> JWT validation, token expiration</li>
<li><strong>Authorization:</strong> RBAC enforcement, permission checks</li>
<li><strong>Input Validation:</strong> SQL injection, XSS prevention</li>
<li><strong>Data Protection:</strong> Encryption at rest (AES-256-GCM)</li>
</ul>

<h3>Reliability Testing:</h3>
<ul>
<li><strong>Fault Injection:</strong> Database failures, network timeouts</li>
<li><strong>Chaos Engineering:</strong> Random service failures</li>
<li><strong>Recovery Testing:</strong> System recovers gracefully</li>
</ul>

<h2>7. Test Execution Plan</h2>
<table>
<thead>
<tr>
<th>Phase</th>
<th>Tests</th>
<th>Environment</th>
<th>Owner</th>
</tr>
</thead>
<tbody>
<tr>
<td>1. Local Dev</td>
<td>Unit tests</td>
<td>Developer machine</td>
<td>Developer</td>
</tr>
<tr>
<td>2. CI/CD</td>
<td>Unit + Integration</td>
<td>GitHub Actions</td>
<td>CI Pipeline</td>
</tr>
<tr>
<td>3. Staging</td>
<td>E2E + Non-Functional</td>
<td>Staging environment</td>
<td>QA Team</td>
</tr>
<tr>
<td>4. Pre-Prod</td>
<td>Smoke tests</td>
<td>Pre-production</td>
<td>QA Team</td>
</tr>
</tbody>
</table>

<h2>8. Test Metrics &amp; Acceptance</h2>
<p><strong>Pass Criteria:</strong></p>
<ul>
<li>✅ All unit tests passing (100%)</li>
<li>✅ All integration tests passing (100%)</li>
<li>✅ All acceptance tests passing (100%)</li>
<li>✅ Code coverage &gt;85%</li>
<li>✅ No critical/high security vulnerabilities</li>
<li>✅ Performance benchmarks met</li>
<li>✅ Zero compiler warnings (-Werror)</li>
</ul>

<hr/>
<p><em>Status: Draft | Owner: {getattr(story, "assignee", "Unassigned")} | Last Updated: {story._updated_at.strftime("%Y-%m-%d %H:%M") if hasattr(story, "_updated_at") and story._updated_at else "N/A"}</em></p>
"""

    def story_to_runbook_page(self, story: Story) -> str:
        """Generate Runbook page content"""
        return f"""
<h1>📚 RUNBOOK - {story.key.key if story.key else "NEW"} - {self._escape(story.title)}</h1>

<h2>1. Overview</h2>
<p><strong>Story:</strong> {story.key.key if story.key else "NEW"} - {self._escape(story.title)}</p>
<p><strong>Bounded Context:</strong> {story.bounded_context.name}</p>
<p><strong>Components:</strong> {", ".join(self._escape(m) for m in story.affected_modules) if story.affected_modules else "TBD"}</p>
<p><strong>Owner:</strong> {getattr(story, "assignee", "Unassigned")}</p>

<h2>2. Deployment Procedure</h2>
{f"<pre>{self._escape(story.cicd_requirements)}</pre>" if story.cicd_requirements else "<p><em>Define deployment steps and requirements.</em></p>"}

<h3>Pre-Deployment Checklist:</h3>
<ul>
<li>⬜ All tests passing (>85% coverage)</li>
<li>⬜ Code reviewed and approved</li>
<li>⬜ Database migrations tested</li>
<li>⬜ Configuration verified</li>
<li>⬜ Monitoring dashboards ready</li>
<li>⬜ Rollback plan confirmed</li>
</ul>

<h3>Deployment Steps:</h3>
<ol>
<li><strong>Build:</strong> CMake Release build with tests enabled</li>
<li><strong>Test:</strong> Run full test suite in staging</li>
<li><strong>Deploy:</strong> Canary deployment to 10% traffic</li>
<li><strong>Monitor:</strong> Watch metrics for 1 hour</li>
<li><strong>Rollout:</strong> Gradually increase to 100%</li>
</ol>

<h2>3. Rollback Strategy</h2>
{f"<p>{self._escape(story.rollback_strategy)}</p>" if story.rollback_strategy else "<p><em>Define how to revert this change if issues arise.</em></p>"}

<h3>Rollback Triggers:</h3>
<ul>
<li>🚨 Error rate &gt;1%</li>
<li>🚨 Latency p95 &gt;500ms</li>
<li>🚨 Critical security vulnerability detected</li>
<li>🚨 Data integrity issues</li>
</ul>

<h3>Rollback Procedure:</h3>
<ol>
<li><strong>Feature Flag:</strong> Disable feature flag immediately</li>
<li><strong>Deploy:</strong> Deploy previous version</li>
<li><strong>Database:</strong> Run rollback migrations if needed</li>
<li><strong>Verify:</strong> Confirm system stability</li>
<li><strong>Post-Mortem:</strong> Document incident and lessons learned</li>
</ol>

<h2>4. Monitoring &amp; Observability</h2>
{f"<p>{self._escape(story.observability_spec)}</p>" if story.observability_spec else "<p><em>Define metrics, logs, and traces to monitor.</em></p>"}

<h3>Key Metrics:</h3>
<ul>
<li><strong>Request Rate:</strong> requests_total (counter)</li>
<li><strong>Error Rate:</strong> errors_total (counter)</li>
<li><strong>Latency:</strong> request_duration_seconds (histogram)</li>
<li><strong>Availability:</strong> service_up (gauge)</li>
</ul>

<h3>Dashboards:</h3>
<ul>
<li>Grafana: System overview dashboard</li>
<li>Prometheus: Metrics and alerts</li>
<li>Jaeger: Distributed tracing</li>
</ul>

<h3>Alerts:</h3>
<table>
<thead>
<tr>
<th>Alert</th>
<th>Condition</th>
<th>Severity</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<tr>
<td>High Error Rate</td>
<td>Errors &gt;1% for 5 min</td>
<td>Critical</td>
<td>Page on-call</td>
</tr>
<tr>
<td>High Latency</td>
<td>p95 &gt;500ms for 10 min</td>
<td>Warning</td>
<td>Investigate</td>
</tr>
<tr>
<td>Service Down</td>
<td>Health check failing</td>
<td>Critical</td>
<td>Page on-call</td>
</tr>
</tbody>
</table>

<h2>5. Troubleshooting Guide</h2>

<h3>Common Issues:</h3>

<h4>Issue: High latency</h4>
<p><strong>Symptoms:</strong> Response times &gt;500ms</p>
<p><strong>Diagnosis:</strong></p>
<ol>
<li>Check database query performance</li>
<li>Check external API response times</li>
<li>Check CPU/memory usage</li>
</ol>
<p><strong>Resolution:</strong></p>
<ul>
<li>Scale horizontally (add more instances)</li>
<li>Optimize slow queries (add indexes)</li>
<li>Increase cache TTL</li>
</ul>

<h4>Issue: Authentication failures</h4>
<p><strong>Symptoms:</strong> 401 Unauthorized errors</p>
<p><strong>Diagnosis:</strong></p>
<ol>
<li>Check JWT token expiration</li>
<li>Verify token signature</li>
<li>Check auth service availability</li>
</ol>
<p><strong>Resolution:</strong></p>
<ul>
<li>Refresh tokens</li>
<li>Verify secret keys match</li>
<li>Check auth service health</li>
</ul>

<h4>Issue: Database connection errors</h4>
<p><strong>Symptoms:</strong> Cannot connect to database</p>
<p><strong>Diagnosis:</strong></p>
<ol>
<li>Check connection pool exhaustion</li>
<li>Verify database availability</li>
<li>Check network connectivity</li>
</ol>
<p><strong>Resolution:</strong></p>
<ul>
<li>Increase connection pool size</li>
<li>Restart database connections</li>
<li>Scale database read replicas</li>
</ul>

<h2>6. Maintenance Tasks</h2>

<h3>Regular Maintenance:</h3>
<table>
<thead>
<tr>
<th>Task</th>
<th>Frequency</th>
<th>Owner</th>
</tr>
</thead>
<tbody>
<tr>
<td>Review logs for errors</td>
<td>Daily</td>
<td>On-call</td>
</tr>
<tr>
<td>Check metrics dashboards</td>
<td>Daily</td>
<td>On-call</td>
</tr>
<tr>
<td>Update dependencies</td>
<td>Weekly</td>
<td>Team</td>
</tr>
<tr>
<td>Security vulnerability scan</td>
<td>Weekly</td>
<td>Security Team</td>
</tr>
<tr>
<td>Performance benchmarks</td>
<td>Monthly</td>
<td>Team</td>
</tr>
</tbody>
</table>

<h2>7. Contacts &amp; Escalation</h2>

<h3>Team Contacts:</h3>
<ul>
<li><strong>On-Call:</strong> {getattr(story, "assignee", "TBD")}</li>
<li><strong>Tech Lead:</strong> TBD</li>
<li><strong>Product Owner:</strong> TBD</li>
</ul>

<h3>Escalation Path:</h3>
<ol>
<li><strong>L1:</strong> On-call engineer (response: 15 min)</li>
<li><strong>L2:</strong> Tech lead (response: 30 min)</li>
<li><strong>L3:</strong> Engineering director (response: 1 hour)</li>
</ol>

<hr/>
<p><em>Status: Draft | Owner: {getattr(story, "assignee", "Unassigned")} | Last Updated: {story._updated_at.strftime("%Y-%m-%d %H:%M") if hasattr(story, "_updated_at") and story._updated_at else "N/A"}</em></p>
"""

    def _criteria_to_html(self, criteria: list[AcceptanceCriterion]) -> str:
        """Convert acceptance criteria to HTML list items"""
        items = []
        for criterion in criteria:
            items.append(f"<li>{self._escape(criterion.description)}</li>")
        return "\n".join(items)

    def _escape(self, text: str) -> str:
        """Escape HTML entities"""
        if not text:
            return ""
        return (
            text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
        )
