#!/usr/bin/env python3
"""
Document Writer - Unified ADF Generator (SOLID/DRY/Atomic)

Single Responsibility: Convert structured content to Atlassian Document Format
- Follows DDD: Infrastructure service
- Follows SOLID: Single responsibility, open for extension
- Follows DRY: One document writer for entire codebase
- Atomic: Each operation produces complete valid ADF

Atlassian Document Format (ADF) Specification:
https://developer.atlassian.com/cloud/jira/platform/apis/document/structure/
"""

from dataclasses import dataclass
from typing import Any


@dataclass
class DocumentSection:
    """Domain model for a document section (DDD Value Object)"""

    title: str
    content: str | list[str]
    section_type: str = "normal"  # normal, checklist, code, quote
    show_rule: bool = True


@dataclass
class DocumentLink:
    """Domain model for a hyperlink (DDD Value Object)"""

    text: str
    url: str


class AtlassianDocumentWriter:
    """
    Unified document writer for Atlassian Document Format (ADF).

    SOLID Principles:
    - Single Responsibility: Only converts content to ADF
    - Open/Closed: Extendable for new content types
    - Liskov Substitution: Can be mocked/replaced
    - Interface Segregation: Focused interface
    - Dependency Inversion: Depends on abstractions (DocumentSection)

    DRY: All ADF generation goes through this single class.
    Atomic: Each method produces valid ADF node.
    """

    def __init__(self):
        """Initialize document writer"""
        self._version = 1
        self._type = "doc"

    def create_document(self, sections: list[DocumentSection]) -> dict[str, Any]:
        """
        Create complete ADF document from sections.

        This is the main entry point - all other code calls this.
        Atomic: Returns complete valid ADF document.

        Args:
            sections: List of document sections

        Returns:
            Complete ADF document structure
        """
        content_nodes = []

        for section in sections:
            # Add section heading
            if section.title:
                content_nodes.append(self._create_heading(section.title, level=2))

            # Add section content based on type
            if section.section_type == "checklist":
                content_nodes.extend(
                    self._create_checklist(
                        section.content if isinstance(section.content, list) else [section.content]
                    )
                )
            elif section.section_type == "code":
                content_nodes.append(
                    self._create_code_block(
                        "\n".join(section.content)
                        if isinstance(section.content, list)
                        else section.content
                    )
                )
            elif section.section_type == "quote":
                content_nodes.append(
                    self._create_quote(
                        "\n".join(section.content)
                        if isinstance(section.content, list)
                        else section.content
                    )
                )
            elif isinstance(section.content, str):
                content_nodes.append(self._create_paragraph(section.content))
            elif isinstance(section.content, list):
                # Smart grouping: Group consecutive bullet-like items
                current_list: list[str] = []
                for item in section.content:
                    text = str(item).strip()
                    if not text:
                        continue

                    # If it's a checklist item, handle it separately
                    if text.startswith(("[ ]", "[x]")):
                        if current_list:
                            content_nodes.append(self._create_bullet_list(current_list))
                            current_list = []
                        content_nodes.extend(self._create_checklist([text]))
                    # If it starts with a bullet or is a link-only line, it's a list item
                    elif text.startswith(("• ", "- ")):
                        clean_text = text[2:].strip()
                        current_list.append(clean_text)
                    elif text.startswith("* ") and not text.endswith("*"):
                        # Bullet like "* Item", but not bold like "*Bold*"
                        clean_text = text[2:].strip()
                        current_list.append(clean_text)
                    elif text.startswith("[") and text.endswith("]"):
                        current_list.append(text)
                    else:
                        # Not a list item, flush current list if any
                        if current_list:
                            content_nodes.append(self._create_bullet_list(current_list))
                            current_list = []
                        content_nodes.append(self._create_paragraph(text))

                # Final flush
                if current_list:
                    content_nodes.append(self._create_bullet_list(current_list))

            # Add horizontal rule between sections
            if section.show_rule:
                content_nodes.append(self._create_rule())

        return {"version": self._version, "type": self._type, "content": content_nodes}

    def _create_heading(self, text: str, level: int = 1) -> dict[str, Any]:
        """Create ADF heading (atomic operation)"""
        return {
            "type": "heading",
            "attrs": {"level": level},
            "content": [{"type": "text", "text": text}],
        }

    def _create_paragraph(self, text: str) -> dict[str, Any]:
        """
        Create ADF paragraph with rich text parsing (bold, links).

        Atomic: Returns a single paragraph node with parsed content.
        """
        # Parse bold (*text*) and links ([label|url])
        import re

        content = []

        # Split by bold and links
        # Pattern: (*bold*) or ([label|url])
        parts = re.split(r"(\*[^*]+\*|\[[^\]|]+\|[^\]]+\])", text)

        for part in parts:
            if not part:
                continue

            # Check if it's a link
            link_match = re.match(r"\[([^\]|]+)\|([^\]]+)\]", part)
            if link_match:
                label, url = link_match.groups()
                content.append(
                    {
                        "type": "text",
                        "text": label,
                        "marks": [{"type": "link", "attrs": {"href": url}}],
                    }
                )
                continue

            # Handle bold in the remaining text
            bold_parts = re.split(r"(\*[^*]+\*)", part)
            for b_part in bold_parts:
                if not b_part:
                    continue

                if b_part.startswith("*") and b_part.endswith("*"):
                    content.append(
                        {"type": "text", "text": b_part[1:-1], "marks": [{"type": "strong"}]}
                    )
                else:
                    content.append({"type": "text", "text": b_part})

        if not content:
            content = [{"type": "text", "text": text}]

        return {"type": "paragraph", "content": content}

    def _create_bullet_list(self, items: list[str]) -> dict[str, Any]:
        """Create ADF bullet list (atomic operation)"""
        list_items = []
        for item in items:
            list_items.append({"type": "listItem", "content": [self._create_paragraph(item)]})

        return {"type": "bulletList", "content": list_items}

    def _create_checklist(self, items: list[str]) -> list[dict[str, Any]]:
        """Create ADF bullet list with checkboxes (atomic operation)"""
        list_items = []
        for item in items:
            # Keep the [ ] or [x] prefix for visual representation in bullet list
            list_items.append({"type": "listItem", "content": [self._create_paragraph(item)]})

        return [{"type": "bulletList", "content": list_items}]

    def _create_code_block(self, code: str, language: str = "cpp") -> dict[str, Any]:
        """Create ADF code block (atomic operation)"""
        return {
            "type": "codeBlock",
            "attrs": {"language": language},
            "content": [{"type": "text", "text": code}],
        }

    def _create_quote(self, text: str) -> dict[str, Any]:
        """Create ADF block quote (atomic operation)"""
        return {"type": "blockquote", "content": [self._create_paragraph(text)]}

    def _create_rule(self) -> dict[str, Any]:
        """Create ADF horizontal rule/divider (atomic operation)"""
        return {"type": "rule"}


class WikiDocumentWriter:
    """
    Converts structured content to Jira Wiki format.

    SOLID Principles:
    - Single Responsibility: Only converts content to Wiki format
    - Open/Closed: Extendable for new content types
    """

    def create_document(self, sections: list[DocumentSection]) -> str:
        """
        Create complete Jira Wiki document from sections.

        Args:
            sections: List of document sections

        Returns:
            Complete Jira Wiki string
        """
        lines = []

        for section in sections:
            # Add section heading
            if section.title:
                lines.append(f"h2. {section.title}")

            # Add section content based on type
            if section.section_type == "checklist":
                for item in (
                    section.content if isinstance(section.content, list) else [section.content]
                ):
                    # Jira wiki uses * for bullets
                    lines.append(f"* {item}")
            elif section.section_type == "code":
                lines.append("{code:cpp}")
                lines.append(
                    "\n".join(section.content)
                    if isinstance(section.content, list)
                    else section.content
                )
                lines.append("{code}")
            elif section.section_type == "quote":
                lines.append("{quote}")
                lines.append(
                    "\n".join(section.content)
                    if isinstance(section.content, list)
                    else section.content
                )
                lines.append("{quote}")
            elif isinstance(section.content, str):
                lines.append(section.content)
            elif isinstance(section.content, list):
                for item in section.content:
                    text = str(item).strip()
                    if not text:
                        continue

                    # Convert bullets to Jira wiki format
                    if text.startswith(("• ", "- ")):
                        lines.append(f"* {text[2:].strip()}")
                    else:
                        lines.append(text)

            # Add horizontal rule between sections
            if section.show_rule:
                lines.append("----")

            lines.append("")

        return "\n".join(lines).strip()


# Singleton instances for dependency injection
_document_writer_instance: AtlassianDocumentWriter | None = None
_wiki_writer_instance: WikiDocumentWriter | None = None


def get_document_writer() -> AtlassianDocumentWriter:
    """
    Get ADF document writer instance (Dependency Injection).
    """
    global _document_writer_instance
    if _document_writer_instance is None:
        _document_writer_instance = AtlassianDocumentWriter()
    return _document_writer_instance


def get_wiki_writer() -> WikiDocumentWriter:
    """
    Get Wiki document writer instance (Dependency Injection).
    """
    global _wiki_writer_instance
    if _wiki_writer_instance is None:
        _wiki_writer_instance = WikiDocumentWriter()
    return _wiki_writer_instance
