"""Entry point for `python -m atlassiancli`."""

from atlassiancli.cli.main import main

raise SystemExit(main())
