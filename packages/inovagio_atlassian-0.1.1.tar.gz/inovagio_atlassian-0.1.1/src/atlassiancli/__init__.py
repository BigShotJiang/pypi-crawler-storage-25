"""atlassiancli — zero-pip-dep Python CLI for Atlassian (Jira + Confluence) operations."""

__version__ = "0.1.0"


# Lazy import to avoid module execution warning when running with `python -m`
def cli_main() -> int:
    """Entry point for CLI - lazy import to avoid double-import warning"""
    from atlassiancli.cli.main import main

    return main()


__all__ = ["__version__", "cli_main"]
