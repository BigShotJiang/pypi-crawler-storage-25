# Contributing to atlassiancli

Thanks for your interest in improving atlassiancli. This project assumes only
`pip` as its package manager and Python 3.12+; no other tooling is required.

## Install dev dependencies

From a fresh checkout:

```bash
python3.12 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -e ".[dev]"
```

The `dev` extra installs `ruff`, `build`, and `twine`. The runtime package
itself has zero third-party dependencies — that constraint is non-negotiable.

## Run the tests

The default test runner is the standard library's `unittest`:

```bash
python -m unittest discover tests/
```

All tests are written as `unittest.TestCase` subclasses, so contributors who
prefer `pytest` can use it without changes:

```bash
pip install pytest
pytest tests/
```

CI runs the `unittest` path. Either tool yields the same results.

## Lint

The default linter is `ruff` (installed via the `dev` extra):

```bash
ruff check .
```

The `[tool.ruff]` configuration in `pyproject.toml` selects rules that mirror
`flake8` + common plugins (E, W, F, I, N, UP, B, C4, SIM, RUF). Contributors
who prefer `flake8` can run it instead and will see substantially the same
violation set:

```bash
pip install flake8
flake8 src tests
```

CI runs `ruff`. Either tool is acceptable for local development.

## Build a wheel

```bash
python -m build
```

Produces `dist/atlassiancli-<version>.tar.gz` and a matching `.whl`.

## Coding standards

- Python 3.12+ syntax is fine (PEP 695 type aliases, `match` statements, etc.).
- No third-party imports inside `src/atlassiancli/`; standard library only.
- Tests live under `tests/` and use `unittest.TestCase` + `unittest.mock`.
- Keep the public CLI surface stable; subcommand additions land in numbered
  PRs per [PLAN.md](PLAN.md).

## CI gates

Every push and PR triggers `.github/workflows/ci.yml`:

- `ruff check src/ tests/` (lint)
- `ruff format --check src/ tests/` (formatting)
- `mypy src/atlassiancli/ --ignore-missing-imports` (informational; not a gate yet)
- `python -m unittest discover tests/` (stdlib test runner)
- `pytest tests/` (alternate runner — must also pass)
- `python -m build --wheel` (wheel artifact)
- `pip install <wheel> && atlassiancli --version` (smoke test in fresh venv)

Run all of these locally before pushing:

```bash
ruff check src/ tests/
ruff format --check src/ tests/
python -m unittest discover tests/
pytest tests/
python -m build --wheel
```

If `ruff format --check` reports drift, run `ruff format src/ tests/` and
commit the formatted result; CI will fail if the tree is not formatted.

## Commit messages

This project uses **Conventional Commits** for the squash-commit subject
line. The commit type drives both the changelog grouping and the next
semantic version (via `release-please`).

| Prefix | Triggers | Example |
|---|---|---|
| `feat:` | minor version bump (`0.1.0` → `0.2.0`) | `feat(framework): add regenerate-sops command` |
| `fix:` | patch version bump (`0.1.0` → `0.1.1`) | `fix(http): retry on 503 with backoff` |
| `feat!:` or `BREAKING CHANGE:` footer | major version bump (`0.x.y` → `1.0.0`) | `feat(api)!: drop Python 3.11 support` |
| `perf:` | patch version bump | `perf(yaml): faster scalar parsing` |
| `docs:` | no version bump (listed in changelog) | `docs(readme): clarify install steps` |
| `refactor:` | no version bump | `refactor(domain): extract value object` |
| `chore:` / `build:` / `ci:` / `test:` / `style:` | no version bump (hidden from changelog) | `chore: bump dev dependencies` |

The release-PR is generated automatically: as soon as `main` accumulates
at least one `feat:` or `fix:` commit since the last tag, `release-please`
opens (or updates) a rolling `chore(main): release X.Y.Z` PR with the
version bump + new CHANGELOG.md section. **Reviewing and merging that PR
is what cuts a release** — the merge tags `vX.Y.Z`, which fires the
publish pipeline.

## Releases

Two-step automated flow driven by the `release-please` workflow:

1. **Push to main** — `release-please` opens / updates a `chore(main):
   release X.Y.Z` PR if there are any version-bumping commits since the
   last tag.
2. **Merge the release PR** — `release-please` creates the `vX.Y.Z` tag
   and a GitHub release. The tag push fires
   `.github/workflows/release.yml`:

   1. Build sdist + wheel
   2. Publish to **Test PyPI** automatically (OIDC trusted publishing)
   3. Publish to **PyPI** — gated by manual approval via the `pypi`
      GitHub environment (configured in repo settings → Environments →
      required reviewers)

Trusted publishing for both registries is already configured. See
[docs/RELEASE.md](docs/RELEASE.md) for the full runbook (rollback rules,
debugging a misconfigured publisher, etc.).
