# atlassiancli — Usage Reference

Comprehensive subcommand reference for day-to-day use. Audience: an engineer
running atlassiancli interactively or scripting it into a workflow.

The subcommand surface documented here matches what is **actually shipped**
in the current package. A small number of subcommands sketched in
[PLAN.md §6](../PLAN.md) are still forthcoming and noted explicitly in each
section as such.

---

## Top-level options

These flags apply to every subcommand:

| Option | Purpose |
|---|---|
| `--version` | Print `atlassiancli <version>` and exit |
| `--help`, `-h` | Print help for the current parser level |
| `--json` | Emit the stable JSON envelope (PLAN §6.2) on stdout instead of human-readable text. See [AGENT_INTEGRATION.md](AGENT_INTEGRATION.md) for the schema |
| `--profile <name>`, `-P <name>` | Use the named profile under `~/.atlassiancli/<name>.toml`. Falls back to `$ATLASSIAN_PROFILE` then `default` |
| `--config <path>` | Explicit profile file (overrides `--profile` and per-user lookup; env vars still take precedence) |

---

## Configuration

atlassiancli looks up credentials in this order, highest priority first:

1. **`--config <path>`** — an explicit profile TOML file passed on the command line.
2. **Environment variables** — preferred for CI; override anything below:
   ```
   ATLASSIAN_TOKEN=<atlassian api token>      # ATLASSIAN_API_TOKEN also accepted
   ATLASSIAN_EMAIL=you@example.com
   ATLASSIAN_URL=https://your-site.atlassian.net
   ```
3. **Per-user profile** at `~/.atlassiancli/<profile>.toml`. The profile name comes from `--profile` → `$ATLASSIAN_PROFILE` → `default`.
4. **Project `.env`** at the working directory — auto-loaded at startup. Supports `KEY=VALUE`, comments, quoted values, `${VAR}` expansion. Free-form section separators (lines without `=`) are silently skipped.
5. **Hardcoded defaults** — the project's own URL / email / project key.

### Quickest setup — interactive wizard

```
atlassiancli configure
```

The wizard prompts for site / email / API token, verifies the credential against `GET /rest/api/3/myself`, and writes `~/.atlassiancli/default.toml` with mode 0600.

Flags:
- `--profile <name>` — write to a named profile (e.g. `work`, `personal`).
- `--no-verify` — skip the credential round-trip (useful for offline setup).

Re-run safely — existing values become the prompt defaults, blank input keeps them.

### Multi-tenant example

```bash
atlassiancli configure --profile work     # → ~/.atlassiancli/work.toml
atlassiancli configure --profile personal # → ~/.atlassiancli/personal.toml

atlassiancli --profile work analyze fetch ACME-1
atlassiancli --profile personal sprint current --board 7
```

### Profile file shape (`~/.atlassiancli/<name>.toml`)

```toml
base_url = "https://acme.atlassian.net"
user_email = "you@acme.com"
api_token = "ATATT3xFf..."
project_key = "ACME"
confluence_space = "ACMEDOCS"
```

All fields are optional. Missing values fall through to env vars then to project defaults — so a CI pipeline can keep credentials in env and only the endpoint in the profile.

---

## Tier 1 — Atlassian basics

### `create epic`

Create a Jira epic.

```
atlassiancli create epic --title <text> --description <text> --objective <text>
                         [--kpi <text> ...] [--in-scope <text> ...]
                         [--out-of-scope <text> ...] [--architecture <link>]
                         [--theme <text> ...]
                         [--priority highest|high|medium|low|lowest]
```

Repeatable flags (`--kpi`, `--in-scope`, `--out-of-scope`, `--theme`) accumulate.

**Example:**
```bash
atlassiancli create epic \
  --title "Catalogue virtualisation" \
  --description "Expose the storage catalogue as virtual tables" \
  --objective "Unblock SQL clients reading metadata" \
  --kpi "Latency p99 < 50ms" --priority high
```

Exit codes: `0` on success, `1` on validation / API failure, `77` on auth.

### `create story`

Create a story under an epic.

```
atlassiancli create story --title <text> --description <text>
                          --epic-key <KEY>
                          [--story-points <int>] [--sprint-number <int>]
                          [--acceptance-criteria <text>] ...
                          [--affected-modules <text> ...]
                          [--integration-points <text> ...]
                          [--theme <text> ...]
                          [--priority highest|high|medium|low|lowest]
```

**Example:**
```bash
atlassiancli create story --title "Implement IpSecurityFilter" \
  --description "..." --epic-key PROJ-100 --story-points 5
```

### `create task`

Create a task under a story.

```
atlassiancli create task --title <text> --description <text>
                         --parent-story-key <KEY>
                         [--implementation-steps <text> ...]
                         [--estimated-hours <float>]
                         [--priority highest|high|medium|low|lowest]
```

### `create version`

Create a release version on a project.

```
atlassiancli create version --name <text> --description <text>
                            --project-id <int>
                            [--start-date YYYY-MM-DD]
                            [--release-date YYYY-MM-DD]
                            [--released] [--archived]
```

### `transition <KEY> [<state>] [--to <state>] [--execute]`

Transition an issue's workflow state. `--to` is the agent-contract alias
for the positional `<state>`.

```bash
atlassiancli transition PROJ-247 "In Progress" --execute
atlassiancli transition PROJ-247 --to "Done" --execute
```

Idempotent — Jira no-ops on already-targeted state. Exit codes `0` / `1` /
`75` / `77`.

### `assign <KEY> --user <email>`

Assign an issue. Idempotent.

```bash
atlassiancli assign PROJ-247 --user you@example.com
```

### `comment <KEY> --body <text> [--idempotency-key <key>]`

Add a comment. Pass `--idempotency-key` (typically the agent run id) to skip
posting if a comment already contains that key.

```bash
atlassiancli comment PROJ-247 --body "Run id: $RUN_ID" --idempotency-key "$RUN_ID"
```

### `link-pr <KEY> --pr-url <url>`

Add a PR remote-link to an issue. Dedupes against existing remote-issue-links.

```bash
atlassiancli link-pr PROJ-247 --pr-url https://github.com/org/repo/pull/123
```

### `delete <KEY>... [--confirm] [--execute]`

Delete one or more issues. Defaults to dry-run; pass `--execute` to commit.

```bash
atlassiancli delete PROJ-247 PROJ-248 --execute
```

### `sprint current [--board <ID>]`

Find the active sprint on a board. Falls back to env when `--board` omitted.

```bash
atlassiancli sprint current --board 42
atlassiancli --json sprint current --board 42
```

### `sprint stories --sprint <ID> [--unassigned] [--priority-order]`

List stories on a sprint. With `--unassigned --priority-order`, returns
the agent's pick list (unassigned, highest priority first).

```bash
atlassiancli --json sprint stories --sprint 318 --unassigned --priority-order
```

### `move --to <SPRINT-ID> <KEY>...`

Move issues into a sprint.

```bash
atlassiancli move --to 318 PROJ-247 PROJ-248
```

### `split <KEY> [--context <name>] [--target-sp <int>] [--force]`

Split a story exceeding the target story-point ceiling into subtasks. Also
supports batch mode: `split --project-key PROJ`.

### `rebalance [--sprint-number <int>] [--target-sp <int>]`

Rebalance story points across a sprint.

### `reorganize [...]`

Reorganise issue hierarchy.

### `sprint-goals <sprint-number>`

Generate sprint goals from a sprint number.

### `goals [--board <ID>] [...]`

Alias for sprint-goals at the top level (`goals_alias`).

### `balance [...]`

Balance sprint capacity.

### `report quality --project <KEY> [...]`

Story-quality roll-up across a project.

```bash
atlassiancli report quality --project PROJ
```

### `report velocity --board <ID>`

Velocity metrics over recent sprints.

### `report themes --project <KEY>`

Distribution of themes across a project's backlog.

### `report health --project <KEY>`

Backlog-health metrics.

### `confluence get <PAGE-ID>`

Fetch a Confluence page's content by id.

### `confluence children <PAGE-ID>`

List child pages of a Confluence page.

### `confluence find <title> [--space <KEY>]`

Find a page by title (exact match within a space).

### `confluence create --title <text> [--space <KEY>] [--parent-id <ID>] [--content <text> | --content-file <path>] [--markdown] [--execute]`

Create a Confluence page. Defaults to dry-run; `--execute` commits. With
`--markdown`, the content is converted to Confluence storage XHTML by
`infrastructure/markdown_formatter.py`.

```bash
atlassiancli confluence create --title "Design Doc" --space PROJ \
  --content-file design.md --markdown --execute
```

### `confluence update <PAGE-ID> [--content <text> | --content-file <path>] [--title <text>] [--parent-id <ID>] [--markdown] [--append] [--execute]`

Update an existing Confluence page. Supports replace (default) and append
(`--append`). Defaults to dry-run.

### `docs <KEY> [--space <KEY>] [--parent <ID>] [--analyze | --execute]`

Create Confluence documentation pages from a Jira issue. Use `--analyze` for
a dry-run plan; `--execute` commits.

### `import markdown <file> [--project <KEY>] [...]`

Import issues from a markdown file.

### `import yaml <file> [--project <KEY>] [...]`

Import issues from a structured YAML file.

### `import confluence <PAGE-ID> [--project <KEY>] [...]`

Import issues from a Confluence page (parsed as a backlog).

### `product-docs <product> [--execute]`

Generate baseline doc-structure pages for a product. The fuller
`product-docs scaffold --product <handle>` form sketched in PLAN §6.1 is
**forthcoming**.

---

## Tier 2 — Story analysis + enhancement

These subcommands target the autonomous-development workflow described in
[AGENT_INTEGRATION.md](AGENT_INTEGRATION.md). Note the actual top-level verb
is `analyze` (US spelling) — the PLAN draft used `analyse`.

### `analyze lint <KEY>`

Score a story 0–100 against the 11-section AI-implementable schema. With
`--json`, returns the stable AgentResponse envelope.

```bash
atlassiancli analyze lint PROJ-247
atlassiancli --json analyze lint PROJ-247
```

Verdict bar: `score >= 80` → `PASS`, otherwise `FAIL`. Exit codes follow
the §6.4 contract.

### `analyze atomicity <KEY>`

Atomic-test check — five criteria: bounded module, single layer, PR-sized,
no prerequisite ambiguity, isolated tests.

### `analyze description <KEY>`

Description-quality breakdown by required section.

### `analyze architecture <KEY> [...]`

Architecture-fit check against the project's architecture documentation.

### `analyze ready <KEY>`

Composite Definition-of-Ready gate: lint ≥ 80 AND atomicity passes AND
all 11 sections present. Returns verdict `READY` / `NOT_READY`.

```bash
atlassiancli --json analyze ready PROJ-247
```

### `analyze fetch <KEY>`

Full structured story content for agent consumption (as JSON when `--json`
is set).

### `enhance <KEY> [--check | --apply] [...]`

Generate missing required sections. Default writes proposed content to
stdout; `--apply` writes back to the Jira description; `--check` reports
whether the issue is already enhanced.

```bash
atlassiancli enhance PROJ-247               # dry run, prints proposal
atlassiancli enhance PROJ-247 --apply       # write back to Jira
atlassiancli enhance PROJ-247 --check       # report status only
```

### `template <kind> [...]`

Emit blank story / epic templates. The full subcommand surface
(`template story`, `template epic` per PLAN §6.2) is partially shipped via
`template` with `--type` / similar arguments — see `atlassiancli template
--help` for the version installed.

---

## Tier 3 — Doc framework bridge

The `framework` group walks per-product YAML manifests and reconciles them
with Jira / Confluence. Every consuming project provides its own
`docs/<product>/.docframework.yaml` (schema in
[RUNBOOK.md §6](RUNBOOK.md)).

### `framework create-stories --product <handle> [...]`

Create / update Jira stories from per-product YAML manifests under
`docs/<product>/stories/manifests/S*.yaml`. Idempotent.

```
atlassiancli framework create-stories --product myproduct
                                      [--epic <ID>] [--manifest <S-ID>]
                                      [--dry-run] [--skip-link-pass]
                                      [--no-transition]
```

**Example:**
```bash
atlassiancli framework create-stories --product myproduct --dry-run
atlassiancli framework create-stories --product myproduct --epic E-01
```

### `framework verify-stories --product <handle>`

Verify per-epic manifest ↔ Jira story-count parity.

```bash
atlassiancli framework verify-stories --product myproduct
atlassiancli --json framework verify-stories --product myproduct
```

### `framework reverse-sync --product <handle> [--epic <ID>] [--dry-run] [--strict]`

Materialise YAML manifests on disk from Jira stories that lack one. Useful
when adopting the framework on a project that already has stories in Jira.

### `framework sync-docs --product <handle> [--doc <HANDLE>] [--dry-run]`

Push repo markdown docs (`docs/<product>/*.md`) to their configured
Confluence pages. With `--doc`, sync only one logical doc handle (e.g.
`ARCHITECTURE`).

### `framework bootstrap --product <handle>`

Two modes, dispatched on whether `docs/<product>/` exists:

**Scaffold mode** (directory missing) — generates the full doc tree from the templates shipped at `templates/product-doc-tree/`:

- `.docframework.yaml` (per-product bridge config, with token substitution)
- The seven mandatory top-level docs: `README.md`, `product-identity.md`, `ARCHITECTURE.md`, `DESIGN_SPEC.md`, `IMPLEMENTATION_PLAN.md`, `ROADMAP.md`, `PARITY_LEDGER.md`
- `adrs/` (with example ADR), `epics/` (with example epic), `stories/manifests/` (with example story manifest), `evidence/` (with example evidence file)
- `sops/` — SOP set tuned to the detected stack (Python, TypeScript, Go, Rust, C++, Java, Kotlin, C#, Ruby, JavaScript). Off via `--no-auto-sops`; override via `--lang <name>`.

Idempotent on re-run — existing files are skipped. `--force` overwrites.

```bash
atlassiancli framework bootstrap --product widgets --name "Widgets"
atlassiancli framework bootstrap --product widgets --dry-run    # report what would write
atlassiancli framework bootstrap --product widgets --force      # overwrite existing
atlassiancli framework bootstrap --product widgets --lang go    # force the SOP set to a chosen language
atlassiancli framework bootstrap --product widgets --no-auto-sops  # use generic SOP templates
```

Confluence hub-page reservation and Jira epic creation stay manual — they're project-specific and the wizard prints next-step guidance for both.

#### Auto-SOPs (default ON)

`framework bootstrap` runs stack detection on the current directory and emits SOPs whose enforcement rules are pinned to the project's actual toolchain:

| Stack | Linter | Formatter | Test runner | Print regex |
|---|---|---|---|---|
| Python | ruff | ruff format | pytest | `\bprint\s*\(` |
| TypeScript | eslint | prettier | vitest | `\bconsole\.(log\|debug\|info)\s*\(` |
| Go | golangci-lint | gofmt | go test ./... | `\bfmt\.(Println\|Printf\|Print)\s*\(` |
| Rust | cargo clippy | cargo fmt | cargo test | `\b(println\|print\|eprintln\|eprint)!\s*\(` |
| C++ | clang-tidy | clang-format | ctest | `std::cout\s*<<` |

When detection returns "unknown", scaffold mode falls back to the generic templates and prints a hint to re-run `regenerate-sops --lang <name>`.

Generated SOP files carry an `auto-generated by atlassiancli` header. The header is what `regenerate-sops` checks before overwriting — delete it to take ownership of a file.

**Parity mode** (directory exists) — validates the existing config, runs a `verify-stories` parity check (when creds are present), and emits next-step guidance:

- `.docframework.yaml` parses + has all required sections
- credentials are set (`ATLASSIAN_TOKEN` + `ATLASSIAN_EMAIL`)
- the configured Confluence hub page exists
- the configured epics exist in Jira

### `framework regenerate-sops --product <handle> [--lang <name>] [--force] [--dry-run]`

Re-runs SOP autogeneration in place for a product whose doc tree already exists. Idempotent: files carrying the `auto-generated by atlassiancli` header are rewritten byte-identically; files without that header are preserved (the user took ownership). `--force` bypasses that guard.

```bash
atlassiancli framework regenerate-sops --product widgets               # detect + regenerate
atlassiancli framework regenerate-sops --product widgets --lang go     # override detection
atlassiancli framework regenerate-sops --product widgets --dry-run     # preview
atlassiancli framework regenerate-sops --product widgets --force       # rewrite even user-edited files
```

Use this when:

- The project's toolchain changed (e.g. ruff replaced flake8) and the SOP regexes should follow.
- A new SOP rule shipped in `atlassiancli` and you want it picked up across products.
- You need to swap the primary language for a polyglot repo (`--lang typescript` for the frontend pass, `--lang go` for the backend pass).

The command does not change scaffolded files outside `sops/` — it is strictly a SOP refresh.

---

## Tier 4 — Project bootstrap

Tier 4 is delivered through the `framework bootstrap` subcommand above
(see PLAN §6.3 for the design intent).

---

## Other subcommands

A handful of legacy / utility commands ship in the package:

- `auto analyze|enhance|split <sprint-number>` — bulk-mode automation.
- `verify sprint|themes|stories <sprint-number>` — verification operations
  for the older sprint workflow.
- `prepare <KEY> [...]` — prepare an issue for downstream tooling.
- `context <name>` — bounded-context utility.
- `standardize --issue <KEY> | --sprint <int>` — standardise issue formatting.
- `dashboard launch [...]` — launch the dashboard UI.
- `remove-label <label> ...` — remove a label from issues.
- `portfolio [...]` — portfolio-level summary.

Run `atlassiancli <subcommand> --help` for the exact argument list shipped
in your version.

---

## Exit codes

Every subcommand follows the agent contract from
[AGENT_INTEGRATION.md](AGENT_INTEGRATION.md):

| Code | Meaning |
|---|---|
| `0` | Success |
| `1` | Generic failure (validation, runtime, unexpected error) |
| `2` | Bad usage (argparse) or missing required config |
| `75` | Transient failure (HTTP 5xx, rate-limit) — retry with backoff |
| `77` | Auth failure (HTTP 401/403) — halt, fix credentials |
