# How-To: Autonomous Development with GitHub Copilot Agents in VS Code

**Audience:** AI engineering teams building AI-enabled applications
**Outcome:** A configured workstation that can pull a Jira story from the active sprint, implement it, test it, validate it against architecture + security + code-quality SOPs, and open a pull request — autonomously — in a verifiable loop.
**Primary stack:** Python · C# / .NET · React (TypeScript) — workflow is language-agnostic and applies equally to other stacks the team adopts.

---

## 0. The system at a glance

**DevCycle is the system; the CLI is one of three components that compose it.** Don't mistake the package for the product. The product is a verifiable, gated workflow that turns Jira stories into PRs without bypassing checks. Three components, equally load-bearing, none of them sufficient alone:

```
        ┌─────────────────────────────────────────────────────────────┐
        │     Component 1: The Copilot Agent (the state machine)      │
        │  .github/agents/DevCycle.agent.md — 8 phases, blocking gate │
        │  at Phase 6, escalation protocol, durable state in .vscode/ │
        └─────────────────────────────────────────────────────────────┘
                              ▲                       │
                              │ enforces              │ invokes
                              │                       ▼
        ┌─────────────────────────────────────┐  ┌─────────────────────────────────────┐
        │   Component 2: The SOPs (rules)     │  │  Component 3: The CLI (the bridge)  │
        │  Architecture · Security · Quality  │  │  inovagio-atlassian                 │
        │  Testing · Logging · Monitoring     │  │  Reaches Jira / Confluence /        │
        │  Stack-tuned, in docs/<product>/sops│  │  SOP-enforcement engine             │
        └─────────────────────────────────────┘  └─────────────────────────────────────┘
                                                            │ falls back to
                                                            ▼
                                              ┌──────────────────────────────────┐
                                              │  Atlassian MCP (read-only ops)   │
                                              └──────────────────────────────────┘
```

**Without all three, you don't have DevCycle:**

- **Without the agent** — there's no state machine. You're back to manually driving every step. No autonomous loop.
- **Without the SOPs** — there's no enforcement. The agent is just confident vibe-coding without rules to check against.
- **Without the CLI** — the agent loses reliable access to Jira / Confluence / SOP enforcement. MCP can substitute for some Atlassian *reads*, but it times out on long-running write workflows and doesn't enforce SOPs at all.

You're configuring a workstation where one Copilot invocation drives the entire ticket-to-PR cycle:

```
Sprint Backlog (Jira)  ─►  @devcycle auto  ─►  PR Open + Jira Done  ─►  next ticket
```

The agent that does this work is **DevCycle** — an enforced state machine with eight phases (0 through 8) and one mandatory blocking gate (Phase 6: Code Review). The state machine is what stops the agent from skipping tests, bypassing review, or shipping unauthorized commits. It is not a vibe-coding loop. Every phase has explicit entry conditions, verification checklists, and exit actions written to disk in `.vscode/devcycle/state.json`.

The agent is **language-agnostic by design**. It executes whatever build, test, and lint commands your project declares — Python via `pytest` and `ruff`, .NET via `dotnet test` and Roslyn analyzers, React/TypeScript via `vitest` / `jest` and `eslint`. What it enforces are workflow gates and SOP compliance, not a particular toolchain.

There are **three layers of quality enforcement**, in order of when they fire:

```
1. Pre-commit hooks  ─►  catch defects before commit (Section 4)
2. DevCycle agent    ─►  catch defects before PR (Sections 5–9)
3. CI pipeline       ─►  catch defects before merge (your team's CI config)
```

A defect that passes all three is a defect that ships. Each layer exists because the others miss things.

The three SOPs every layer enforces are:

| SOP | Source of truth (in your repo) | What it governs |
|---|---|---|
| **Architecture** | `docs/<product>/sops/01-architecture.sop.md` | Service boundaries, module/package layering, AI/data pipeline isolation, integration patterns |
| **Security** | `docs/<product>/sops/02-security.sop.md` | AuthN/AuthZ, secrets, PHI/PII handling, audit logging, AI-specific risks (prompt injection, output safety) |
| **Code quality + testing** | `.github/copilot-instructions.md` + `docs/<product>/sops/03-code-quality.sop.md` + `04-testing.sop.md` | Language patterns, structured logging, ≥85% coverage, sanitizer/analyzer cleanliness |

Your job as the human in the loop is to **set up the environment correctly**, **write stories the agent can actually implement** (Section 6), **kick off the agent**, and **validate at the gates**. The agent does the typing.

> **Healthcare / regulated context.** If your environment handles Protected Health Information (PHI), Personal Data (PII), payment-card data (PCI), or other regulated classes, the Security SOP must enforce centralized handling interfaces for that class. The DevCycle gate will fail code that handles regulated data without going through those interfaces. Do not try to talk the agent out of this.

---

## 1. CLI vs MCP — the agent's hybrid Atlassian path

The DevCycle agent reaches Atlassian and Confluence through **two paths**, used by precedence:

| Path | When the agent uses it | Why |
|---|---|---|
| **`inovagio-atlassian` (CLI, preferred)** | All write / lifecycle operations: `analyze lint`, `enhance`, `analyze architecture`, `analyze atomicity`, `transition`, `assign`, `comment`, `link-pr`, `confluence create/update`, `framework sync-docs`, `framework sop-commit-gate`, etc. | MCP occasionally times out on long-running workflows. The CLI is in-process, deterministic, idempotent on retry, and emits a stable JSON envelope the agent can branch on. |
| **Atlassian MCP server (fallback)** | Stateless reads where the CLI is overkill: `getAccessibleAtlassianResources` (cloud-id), JQL search, `getTransitionsForJiraIssue`, basic `getJiraIssue` / `getConfluencePage`. | Lower latency for reads; native Copilot integration. |

The implication for an agent author: if the operation **changes Atlassian state** (transitions, comments, page edits, sprint moves) or **enforces a gate** (lint, atomicity, SOP, architecture), use the CLI. If it **just reads** (cloud-id, JQL search, transition list), MCP is fine.

The CLI is invoked as `atlassiancli` (the binary; the PyPI distribution is `inovagio-atlassian`). For inovagio-internal projects that haven't migrated yet, the legacy invocation `python3 -m scripts.atlassian_v3` is the same surface — they share heritage and most subcommands are interchangeable.

---

## 2. Prerequisites

Before doing anything else, confirm you have all of the following. Missing items will cause Phase 0 to fail.

**Accounts and access**
- GitHub account with write access to the team's repositories
- GitHub Copilot subscription (Business or Enterprise — agent mode requires it)
- Atlassian access to the team's Jira project and Confluence space
- Atlassian API token (Atlassian → Profile → Security → API tokens)
- Access to your team's secrets vault (Azure Key Vault, AWS Secrets Manager, or HashiCorp Vault — whichever your team uses)
- SonarQube account on the team's instance (for local scan auth)

**Local tooling — base**
- macOS, Linux, or Windows with WSL2
- VS Code 1.95 or newer
- Git 2.40+
- Docker Desktop (for integration tests against containerized dependencies)
- Python 3.12+ (the `inovagio-atlassian` CLI requires it; the `pre-commit` framework also requires Python)

**Local tooling — by stack**

| Stack | Required | Recommended |
|---|---|---|
| Python | Python 3.12+, `pip`, `venv` | `poetry` or `uv`, `ruff`, `black`, `isort`, `mypy`, `bandit`, `pytest`, `pytest-cov` |
| C# / .NET | .NET 8 SDK | `dotnet-format`, `dotnet-coverage`, xUnit or NUnit, `Security Code Scan` |
| React / TypeScript | Node 20 LTS, `npm` or `pnpm` | `pnpm`, `eslint`, `prettier`, `vitest` or `jest`, `playwright` (E2E) |
| AI/ML work | Above + `pip install -e .[dev]` | Project-defined eval harness, prompt-test runner |

**VS Code extensions** (install all relevant to your stack)
- GitHub Copilot
- GitHub Copilot Chat
- GitHub Pull Requests and Issues
- SonarLint (runs SonarQube rules in your editor and at commit)
- Python + Pylance (Python work)
- C# Dev Kit (.NET work)
- ES7+ React snippets, ESLint, Prettier (React work)
- Docker

Verify the basics with:

```bash
code --version
git --version
docker --version
python3 --version
pre-commit --version  # install with: pip install pre-commit
dotnet --version      # if you do .NET work
node --version        # if you do React work
```

If anything fails, fix it before continuing. Don't ask the agent to fix your toolchain.

---

## 3. One-Time Workstation Setup

### 3.1 Clone the repo and install the CLI

```bash
git clone <your-repo-url>
cd <repo>

# Install the CLI globally (the agent invokes it from any cwd)
pip install --user inovagio-atlassian
atlassiancli --version
```

### 3.2 Bootstrap your product into the doc framework

`atlassiancli framework bootstrap` is the one-shot scaffolder. It detects your project's primary language and emits SOPs tuned to that toolchain — no manual SOP editing required for the common case.

```bash
atlassiancli framework bootstrap --product myproduct --name "My Product"
```

That produces:

```
.github/
  copilot-instructions.md          # Code quality + testing SOP (Section 10)
  prompts/
    devcycle.prompt.md             # The DevCycle agent (state machine)
    thinking-beast-mode.prompt.md  # Escalation handoff agent

.pre-commit-config.yaml            # Pre-commit hook definitions (Section 4)
.editorconfig                      # Cross-language formatting baseline
sonar-project.properties           # SonarQube project config

.vscode/
  mcp.json                         # MCP servers (Atlassian, GitHub) — fallback path
  devcycle-config.json             # Project-specific DevCycle config
  settings.json                    # Workspace settings (formatters, tasks)

docs/myproduct/
  sops/                            # Stack-tuned SOPs (regenerate with framework regenerate-sops)
    01-architecture.sop.md
    02-security.sop.md             # Includes PHI/PII handling rules if applicable
    03-code-quality.sop.md
    04-testing.sop.md
    05-logging.sop.md
    06-monitoring.sop.md
    sop-manifest.yaml              # Enforceable rules — what `framework sop-commit-gate` reads

  # Mandatory product doc floor:
  README.md
  product-identity.md
  ARCHITECTURE.md
  DESIGN_SPEC.md
  IMPLEMENTATION_PLAN.md
  ROADMAP.md
  PARITY_LEDGER.md
  adrs/         epics/         stories/         evidence/
```

When the toolchain changes (e.g., ruff replaces flake8), refresh the stack-tuned SOPs in place:

```bash
atlassiancli framework regenerate-sops --product myproduct
```

Files carrying the `# auto-generated by atlassiancli` header are rewritten; user-edited files (header removed) are preserved unless you pass `--force`.

### 3.3 Install pre-commit hooks (mandatory)

This is non-optional. Pre-commit hooks are the first quality gate and they run on every commit, including commits made by the DevCycle agent.

```bash
pip install pre-commit
pre-commit install                              # installs the git hook
pre-commit install --hook-type commit-msg       # for commit message linting
pre-commit install --hook-type pre-push         # for slower checks (e.g., SonarQube)
pre-commit run --all-files                      # one-time check on the existing tree
```

Section 4 explains what gets installed and why.

### 3.4 Enable GitHub Copilot agent mode

The autonomous agent capability is what runs DevCycle. Confirm it's enabled:

1. VS Code → Settings (`Cmd/Ctrl + ,`)
2. Search for `chat.agent.enabled` → set to `true`
3. Search for `chat.mcp.enabled` → set to `true`

Open Copilot Chat (`Ctrl/Cmd + Alt + I`) and confirm the mode dropdown offers **Ask**, **Edit**, and **Agent**. If **Agent** is missing, your Copilot license tier doesn't include it — escalate to your manager.

### 3.5 Configure MCP servers (read-fallback path only)

The DevCycle agent's *primary* path is the `inovagio-atlassian` CLI. MCP is configured as a fallback for stateless reads. Declared in `.vscode/mcp.json`:

```json
{
  "servers": {
    "atlassian": {
      "url": "https://mcp.atlassian.com/v1/sse",
      "type": "sse"
    },
    "github": {
      "url": "https://api.githubcopilot.com/mcp/",
      "type": "http"
    }
  }
}
```

Restart VS Code. On first agent invocation you'll be prompted to authenticate to Atlassian (browser-based OAuth) and GitHub. Approve both.

### 3.6 Authenticate the CLI

Either set environment variables (preferred for CI):

```bash
export ATLASSIAN_EMAIL=you@example.com
export ATLASSIAN_TOKEN=<your-api-token>
export ATLASSIAN_URL=https://your-site.atlassian.net
```

Or run the interactive multi-tenant wizard:

```bash
atlassiancli configure
```

For per-project config (project key, label namespace, summary prefix) drop a `.atlassiancli.yaml` at the repo root.

### 3.7 Configure SonarLint to your team's SonarQube server

In VS Code:

1. Command Palette → `SonarLint: Configure Connection`
2. Choose **SonarQube Server** (not SonarCloud)
3. Enter your team's server URL and an authentication token
4. Bind the workspace to the SonarQube project key for this repo

This makes SonarQube rules show up as you type **and** lets the pre-commit hook run a local scan against the same ruleset the CI server uses.

### 3.8 Verify build, lint, and test work without the agent

This is the most-skipped step and the cause of most agent failures. Confirm the project builds and tests cleanly on your machine **before** turning the agent loose.

| Stack | Verify |
|---|---|
| Python | `ruff check . && black --check . && isort --check . && mypy . && pytest --cov` |
| .NET | `dotnet format --verify-no-changes && dotnet build -warnaserror && dotnet test --collect:"XPlat Code Coverage"` |
| React | `pnpm lint && pnpm typecheck && pnpm test --coverage` |

All checks must pass. Then do one trial commit to verify the pre-commit hooks fire correctly:

```bash
git commit --allow-empty -m "chore: verify pre-commit hooks"
# All hooks should run and pass. If any fail on an empty commit, the config is wrong.
git reset HEAD~1   # discard the test commit
```

If anything fails, fix the local environment before invoking the agent.

---

## 4. Pre-Commit Hooks — The Local Quality Gate

Pre-commit hooks run **on your machine, before code reaches the remote**. They are the cheapest place to catch defects: no agent tokens spent, no CI minutes consumed, no PR review noise. Every commit goes through them — including commits made by the DevCycle agent.

The agent **must** pass pre-commit hooks to push. If a hook fails, the agent treats it as a Phase 4 build error and tries to auto-fix. If it can't fix in three attempts, the run blocks for human help. **Never bypass with `--no-verify`.** A hook bypass is a Phase 6 critical defect.

### 4.1 The framework

We use the [`pre-commit`](https://pre-commit.com/) framework (Python-based but works for any language). It's defined by a single file at the repo root: `.pre-commit-config.yaml`. The full reference template covering Python, .NET, and React/TypeScript ships at `templates/autonomous-dev-system/.pre-commit-config.yaml` and is installed by `framework bootstrap`.

### 4.2 What runs at commit time

The hook chain runs on **only the files staged for commit**, in this order:

```
1. Universal sanity checks    (large files, EOL, trailing whitespace, secrets)
2. Language-specific format   (black/isort, dotnet-format, prettier)
3. Language-specific lint     (ruff, Roslyn analyzers, eslint)
4. Type checking              (mypy, tsc --noEmit, dotnet build)
5. Security scan              (bandit, security analyzers, eslint-plugin-security)
6. SonarLint                  (your SonarQube ruleset, locally)
7. atlassiancli SOP gate      (framework sop-commit-gate)
8. Commit message lint        (Conventional Commits format)
```

A separate, slower set of checks runs at **pre-push** time:

```
9. Full SonarQube scan        (sonar-scanner against the team's server)
10. Test suite + coverage     (full pytest / dotnet test / vitest run)
```

If any step fails, the commit (or push) aborts. Most format/style hooks **auto-fix** the files and ask you to `git add` and re-commit. Lint and type errors require manual fixes.

### 4.3 The atlassiancli SOP gate

`atlassiancli framework sop-commit-gate` is the bridge between the project's SOP manifest (`docs/<product>/sops/sop-manifest.yaml`) and the pre-commit hook chain. It runs every commit-time rule from the manifest against the staged diff and exits non-zero on blocking findings.

Pinned to a hook entry:

```yaml
- repo: local
  hooks:
    - id: atlassiancli-sop-gate
      name: atlassiancli SOP commit gate
      entry: atlassiancli framework sop-commit-gate
      language: system
      pass_filenames: false
```

This is the same enforcement that runs at DevCycle Phase 6, so what passes here passes the agent's blocking gate too.

### 4.4 How the agent interacts with hooks

When the DevCycle agent reaches Phase 8 (Create PR) and runs `git commit`, the hooks fire. The agent has been prompted to:

1. Run hooks **before** attempting the commit (`pre-commit run --all-files` on staged files)
2. If hooks fail with auto-fixes applied, restage and retry
3. If hooks fail with manual-fix-required errors, treat as a Phase 4 regression and loop back
4. **Never** invoke `git commit --no-verify`

If you find the agent has bypassed a hook, that's a state machine integrity bug — file it.

### 4.5 When a hook is wrong

Sometimes a hook flags something that isn't actually wrong. Do not disable the hook. Either:

1. Add a **per-line** suppression with a comment that explains why (`# noqa: E501  long URL in docstring`)
2. Add a **file-level** exclusion to the tool's config with a comment explaining why
3. If the rule is genuinely wrong for your codebase, propose a rule change in the team config — not in your branch

Do not put `# pragma: no cover`, `// eslint-disable-next-line`, or `[SuppressMessage]` on code without a comment explaining the reason. The agent will flag uncommented suppressions as a Phase 6 minor defect.

---

## 5. The Three SOPs — What the Agent Will Enforce

Read your team's actual SOPs once before your first agent run. The agent reads them every cycle, but you need to know what it's checking so you can validate its output. The summaries below are a framework for what those SOPs should cover, not a substitute for them. The auto-generated SOPs at `docs/<product>/sops/` are stack-tuned starting points that you customise per team.

### 5.1 Architecture SOP — boundaries and dependency rules

The architecture document defines:

- **Service / module boundaries.** Which services own which data. Which packages may import which.
- **Layering.** Typically: domain logic → application services → infrastructure adapters → entrypoints (API, CLI, UI). Lower layers do not depend on higher layers.
- **Cross-boundary communication.** Direct imports between bounded modules are not allowed; communication goes through defined interfaces, message buses, or anti-corruption layer adapters.
- **AI pipeline isolation.** Model serving, prompt construction, retrieval (RAG), and evaluation each have defined interfaces. A frontend component does not call an LLM directly; it goes through a backend gateway that handles auth, rate limits, audit, and PHI redaction.
- **Data residency and tenant isolation.** Every query carries tenant context. Cross-tenant reads are a critical defect.

The agent fails Phase 6 if it catches:

- An upward layer dependency (e.g., a domain class importing a Flask/ASP.NET/React utility)
- A direct import between bounded modules without an adapter
- A frontend component that calls an LLM API directly with embedded credentials
- Any code path where tenant context is dropped or implicit

### 5.2 Security SOP — centralization and PHI/PII handling

The Security SOP exists because security cannot be enforced by reviewers spotting issues line by line. It must be **centralized in interfaces** that every developer (and the agent) is required to use:

```
ICryptoService       — encrypt/decrypt/sign/verify/RNG/key derivation
ITokenService        — issue/validate/refresh OAuth and session tokens
IPasswordService     — hash/verify (Argon2id parameters per current OWASP)
ISecretsProvider     — vault-backed secret retrieval (Key Vault / Secrets Manager / Vault)
IAuditLogger         — immutable structured audit events
IPhiRedactor         — PHI detection and redaction before logging, prompting, or storage
IModelClient         — gateway to LLMs/SLMs with built-in safety, audit, rate-limit
```

Names will differ in your team's codebase. The principle is: there is **one** way to call cryptography, **one** way to validate a token, **one** way to fetch a secret, **one** way to redact PHI before it crosses a trust boundary. The agent fails Phase 6 if it sees:

- Direct calls to crypto primitives instead of `ICryptoService`
- Custom JWT parsing instead of `ITokenService`
- `os.environ.get("API_KEY")` or `process.env.API_KEY` reaching production code paths
- PHI fields in logs, exception messages, prompts, or analytics events without going through `IPhiRedactor`
- Direct LLM SDK calls (OpenAI SDK, Anthropic SDK, Azure OpenAI) outside the gateway
- Plain-text comparison of secrets (must be constant-time)
- `eval`, `exec`, `Function()`, or unparameterized SQL anywhere

**AI-specific security gates** the SOP should mandate and the agent should enforce:

- **Prompt injection defense** for any LLM input that originates from untrusted sources (user input, retrieved documents, tool output)
- **Output validation** before LLM responses are rendered, executed, or stored (no raw HTML rendering of LLM output via the React HTML-injection escape hatch; no eval of LLM-generated code in production)
- **PHI/PII redaction** before any text is sent to an external model
- **Audit logging** for every model call: input hash, output hash, model name, version, tokens, user, tenant
- **Rate limiting and cost ceilings** per tenant and per user
- **Model card and eval results** for every deployed model, refreshed on version bump

### 5.3 Code quality + testing SOP — language baselines

`.github/copilot-instructions.md` codifies the cross-language standard. Per-language enforcement:

| Concern | Python | C# / .NET | React / TypeScript |
|---|---|---|---|
| Type safety | type hints + `mypy --strict` | `<Nullable>enable</Nullable>`, `<TreatWarningsAsErrors>true</TreatWarningsAsErrors>` | `tsconfig.json` `"strict": true` |
| Linting | `ruff` (errors as failures) | Roslyn analyzers + `.editorconfig` | `eslint` with `--max-warnings 0` |
| Formatting | `black` + `isort` (Black profile) | `dotnet format --verify-no-changes` | `prettier --check` |
| Test framework | `pytest` | `xUnit` or `NUnit` | `vitest` or `jest` |
| Coverage threshold | ≥ 85 % line + branch | ≥ 85 % line + branch | ≥ 85 % line + branch |
| Coverage tool | `pytest --cov --cov-fail-under=85` | `dotnet-coverage` + ReportGenerator | `vitest run --coverage` with thresholds in config |
| Security scan | `bandit` (security), `pip-audit` (deps) | `Security Code Scan`, `dotnet list package --vulnerable` | `eslint-plugin-security`, `pnpm audit` |
| Quality gate | SonarQube quality gate (server-side) | SonarQube quality gate | SonarQube quality gate |

Universal rules regardless of language:

- **Structured logging only** — log records are objects with named fields, not concatenated strings
- **Correlation IDs** propagate end-to-end through every service call
- **No secrets, tokens, or PHI in logs** — pre-commit, the agent, and SonarQube all search log statements for these patterns
- **Every fallible operation has a defined error type** — Python custom exception hierarchies, C# `Result<T, TError>` patterns or domain exceptions, TypeScript discriminated unions or `Result` types
- **Public APIs are documented** — Python docstrings (Google or NumPy style), C# XML doc comments, TSDoc on exported TypeScript symbols
- **No `TODO`, `FIXME`, `HACK`, `XXX`** in committed code without an attached Jira ticket reference

---

## 6. Writing Jira Stories for AI Agents

This is the highest-leverage section in this document. Most agent failures are **story failures**, not code failures.

A senior engineer can fill in gaps, ask Slack questions, find the right person, recall last sprint's design decision, or notice that a ticket is missing key context. **An AI agent has none of those abilities.** It implements what the story says, in isolation, without follow-up. If the story is vague, the implementation is wrong. If the story spans three services, the agent makes architectural decisions you didn't authorize. If the story implies prior context, the agent invents it.

The fix is upstream of the agent: **stories must be written for AI implementation from day one**, not adapted at sprint kickoff. This is a real shift in how PMs, POs, and tech leads work, and your team needs to commit to it.

### 6.1 The atomic test

A story is **atomic** if and only if all of the following are true:

1. **One bounded module or service.** The implementation lives in a single architectural boundary. If you find yourself writing "and also update the frontend," that's two stories.
2. **One layer.** Domain change, application change, infrastructure change — pick one. If you need all three, that's an epic, not a story.
3. **One pull request worth of work.** Roughly 1–8 story points, ~50–500 lines of new code. Bigger than that means the agent will lose coherence partway through.
4. **No prerequisite ambiguity.** Every dependency this story has on other work is either already merged or explicitly listed in the story.
5. **Testable in isolation.** You can write the acceptance tests without standing up half the system.

A story that fails any of these tests should be split before sprint commitment. `atlassiancli analyze atomicity <KEY>` flags suspicious stories at sprint planning.

### 6.2 Required sections in every story

Every Jira story the team plans to give to an agent must include all of the following. This is not aspirational — incomplete stories should not enter a sprint.

1. **Summary** — one sentence, active voice, present tense, specific
2. **User story** — `As a <role>, I want <capability>, so that <outcome>`
3. **Bounded module / service** — references a real entry in `ARCHITECTURE.md`
4. **Data classification** — `Public` / `Internal` / `PII` / `PHI` / `Confidential` (no exceptions)
5. **Acceptance criteria (Given/When/Then)** — numbered, testable, specific. Each becomes ≥ 1 automated test.
6. **Technical specification** — interface signatures, data shapes, error cases, configuration, observability
7. **Out of scope** — explicit list of what the agent should not do
8. **Test strategy** — named test cases the implementation must include
9. **Definition of Done** — checklist of all gates that must pass
10. **Reference links** — *specific sections* of SOPs/architecture docs (not whole documents — the agent's context window is finite)
11. **Dependencies** — other stories that must merge first

### 6.3 Definition of Ready (story-level gate)

Before a story enters a sprint, it must pass a **Definition of Ready** check:

- [ ] All eleven required sections are filled in
- [ ] Atomicity test passes (Section 6.1)
- [ ] All reference links resolve and point to specific sections
- [ ] Data classification is set
- [ ] Acceptance criteria are testable (no "system should be performant")
- [ ] Technical spec includes interface signatures
- [ ] Out-of-scope list exists and is non-trivial
- [ ] Test strategy lists at least three named tests
- [ ] `atlassiancli analyze ready <KEY>` returns verdict `READY` (composite gate)
- [ ] `atlassiancli analyze lint <KEY>` returns a quality score ≥ 80

This check happens at sprint planning. **Stories that fail go back to refinement, not into the sprint.** Capacity planning should account for this — a sprint of half-baked stories produces zero shippable PRs because the agent will block on every one of them.

### 6.4 Common anti-patterns and their fixes

| Anti-pattern | Why it breaks the agent | Fix |
|---|---|---|
| "Refactor X for clarity" | No measurable done condition | Concrete acceptance criteria: "Extract method Y", "Reduce cyclomatic complexity of Z below 10" |
| "Improve performance of the search endpoint" | No baseline, no target | "Reduce p95 latency of `/search` from 1.2s to <500ms, measured by existing load test suite" |
| "Update the frontend to match the new API" | Spans two services | Split into one story per service |
| "Fix the bug we discussed" | No context, requires tribal knowledge | Reproducer steps, expected vs. actual, root cause hypothesis |
| "Add validation to user input" | Which input, where, what rules | Specify field, layer, rule set, reject behavior |
| Stories with TBDs | Agent will pick something arbitrary | Resolve TBDs at refinement, not at implementation |

### 6.5 What the agent does when a story is bad

DevCycle Phase 2 runs `atlassiancli analyze lint`. If the score is below 70 or required sections are missing, the agent attempts an **enhance** pass — it generates the missing sections from context and posts them back to the Jira story. This is a fallback, not a workflow. Two reasons it should not be relied on:

1. The agent's enhancement is its **interpretation** of what you meant. If you didn't mean that, the implementation will be wrong in ways that look correct.
2. The story is now polluted with AI-generated content that subsequent humans will mistake for product/architectural intent.

Treat agent-enhanced stories as a signal that the refinement process needs work, not as a substitute for refinement.

---

## 7. The DevCycle State Machine

This is the agent that does the work. It lives at `.github/prompts/devcycle.prompt.md` (or `.github/agents/DevCycle.agent.md` in newer Copilot versions) and is invoked from Copilot Chat in Agent mode.

### 7.1 Phases at a glance

```
Phase 0  Initialize environment        (state file, log dirs, prereq checks)
Phase 1  Fetch Jira item               (CLI or MCP — current sprint, top of priority queue)
Phase 2  Prepare story                 (CLI: analyze lint / enhance / analyze architecture / analyze atomicity)
Phase 3  Update Jira → In Progress     (CLI: transition + assign + comment)
Phase 4  Implement code                (per language: code + tests + config)
Phase 5  Run tests                     (lint + typecheck + test + coverage + security scan)
Phase 6  Code review (BLOCKING GATE)   (CLI: review / analyze sop / framework sop-commit-gate)
Phase 7  Fix defects                   (loops back to Phase 6 — never to 8)
Phase 8  Create PR                     (pre-commit hooks + branch + commit + push + PR + Jira → Done via CLI)
```

The two rules that make the state machine trustworthy:

1. **Phase 8 cannot run without `.vscode/devcycle/review-passed.flag`.** That file is created only by Phase 6 on a PASS verdict. No flag, no commit. This prevents the agent from talking itself into shipping defective code.
2. **Phase 7 always returns to Phase 6, never directly to 8.** Re-review after every fix. Maximum three iterations before automatic escalation to a deeper-analysis handoff.

### 7.2 Invocation patterns

Open Copilot Chat in Agent mode and run one of:

| Command | Behavior |
|---|---|
| `@devcycle auto` | Pull the highest-priority unassigned story from the current sprint, run end-to-end |
| `@devcycle <ISSUE-KEY>` | Run end-to-end against a specific issue key |
| `@devcycle resume` | Read `.vscode/devcycle/state.json` and continue from the last checkpoint |
| `@devcycle sandbox` | Dry-run the entire workflow against a fake story in `.devcycle-sandbox/` (touches no real repo, Jira, or GitHub) |

For your **first run**, use `@devcycle sandbox` to verify the agent works end-to-end without risking your repo or Jira state. Then run `@devcycle <some-low-stakes-issue>` to verify Jira/GitHub credentials are wired. Only after both pass should you run `@devcycle auto` against the real backlog.

### 7.3 What gets written to disk

Every phase writes to `.vscode/devcycle/`:

```
.vscode/devcycle/
  state.json                   # Single source of truth for current phase + status
  review-passed.flag           # Created by Phase 6 PASS, deleted by Phase 8 cleanup
  current-story.md             # Generated by Phase 2 — the technical spec
  logs/
    phase_0.log
    phase_1.log
    ...
    phase_8.log
```

Tail logs in a side terminal to watch the agent work in real time:

```bash
tail -f .vscode/devcycle/logs/phase_*.log
```

---

## 8. Daily Developer Workflow

This is the workflow your team will run every morning of every sprint day.

### 8.1 Start of day

1. Pull `main`:
   ```bash
   git checkout main && git pull
   ```
2. Confirm pre-commit hooks are still installed and current:
   ```bash
   pre-commit autoupdate
   pre-commit install
   ```
3. Confirm no leftover state from the previous day:
   ```bash
   cat .vscode/devcycle/state.json 2>/dev/null
   ```
   If it shows `"status": "completed"` for Phase 8, you're clean. If it shows anything else, decide whether to resume it or reset.
4. Open Copilot Chat → Agent mode → `@devcycle auto`.

### 8.2 During a run

Watch the logs in a terminal:

```bash
tail -f .vscode/devcycle/logs/*.log
```

Validate at the gates per Section 9. Don't passively trust the agent.

### 8.3 When the agent stops

| State | What it means | What you do |
|---|---|---|
| `completed` at phase 8 | PR opened, Jira moved to Done | Review the PR, then `@devcycle auto` for the next story |
| `blocked` | Hit a condition it can't resolve | Read the error in `state.json`, resolve manually, then `@devcycle resume` |
| `failed` after 3 review iterations | Couldn't satisfy Phase 6 gate | Use the **Analyze Complex Problem** handoff, then return to Phase 4 |

---

## 9. Validation at Each Gate

The agent is fast and confident, neither of which is the same as correct. Validate at every gate.

### 9.1 After Phase 1 (Fetch)

- Did it pull the right issue? `state.json` → `jira_key` and `jira_summary`
- Is the issue in the current sprint? Open Jira, confirm.
- Already assigned to someone? Abort.
- Marked **Ready**? If not, abort and refine the story first.

### 9.2 After Phase 2 (Prepare)

Open `.vscode/devcycle/current-story.md`. The story must include all eleven sections from Section 6.2. If anything is missing, this is a **story problem, not an agent problem**. Kill the run, fix the story in Jira, and restart.

### 9.3 After Phase 4 (Implement)

Skim every file in `state.json` → `files_modified` for architecture / security / quality violations:

- Upward layer imports
- Direct cross-context imports without an adapter
- Frontend code calling LLMs directly with embedded credentials
- Direct crypto/JWT/password library calls instead of `ICrypto/IToken/IPassword`
- Secrets read from `os.environ` / `process.env` in production code paths
- PHI in logs, prompts, exception messages, telemetry without redaction
- Per-language landmines: Python `eval` / `exec` / `pickle.loads` on untrusted data; C# unparameterized SQL / `BinaryFormatter`; React/TS use of the React HTML-injection escape hatch / `eval` / secrets in client bundles
- Missing types / nullable annotations
- Broad exception catches that swallow errors
- `print` / `Console.WriteLine` / `console.log` left in
- Lint suppressions without explanatory comments

If you spot any of these, **abort before Phase 5**.

### 9.4 After Phase 5 (Test)

Required outcomes in `state.json` → `test_results`: `failed: 0`, `coverage: >= 85`. Re-run lint, typecheck, security scan, and `pre-commit run --all-files` to confirm.

### 9.5 After Phase 6 (Review) — the gate

```bash
test -f .vscode/devcycle/review-passed.flag && echo "OK" || echo "BLOCKED"
cat .vscode/devcycle/review-passed.flag
```

The flag must contain `"status": "PASS"`, `"defects_found": { "critical": 0, "major": 0, ... }`, `"authorized_to_commit": true`. If `critical > 0` or `major > 0`, the flag should not exist. If it does, that's a state machine violation — file a bug against the DevCycle agent itself.

You can also run the unified gate via the CLI:

```bash
atlassiancli review PROJ-247
```

This composes `analyze ready` + `analyze sop` + `analyze architecture` and returns a worst-of verdict — a sanity check independent of the agent's own self-assessment.

### 9.6 After Phase 8 (PR)

- The PR exists on GitHub and links to the Jira ticket
- Jira transitioned to `Done`
- Branch name follows your team's convention
- Commit message follows Conventional Commits
- Pre-commit hooks ran on the agent's commit
- CI pipeline passes
- `.vscode/devcycle/review-passed.flag` was deleted (cleanup verification)

Then **review the PR yourself** — don't merge on the agent's say-so.

---

## 10. The `copilot-instructions.md` File

This is the file Copilot reads on every interaction in your repo. It's how you make standards travel with the code instead of living in a wiki nobody reads.

The canonical reference template ships at [`templates/autonomous-dev-system/.github/copilot-instructions.md`](../templates/autonomous-dev-system/.github/copilot-instructions.md) and is auto-installed by `atlassiancli framework bootstrap`. It covers:

- **Project context** — stack, build, tests, quality gates, references to architecture / security / data-handling docs
- **Universal patterns** — pre-commit hooks mandatory, structured logging, no `--no-verify`, no broad exception swallowing, correlation IDs, no PHI/secrets in logs
- **Per-language patterns** — Python (type hints, ruff, black, mypy strict, pytest, bandit), C#/.NET (nullable, analyzers, xUnit, threshold 85%), React/TypeScript (strict mode, eslint zero warnings, vitest with coverage thresholds)
- **AI-specific patterns** — model gateway only (no direct SDK calls), prompt-injection defense, output validation, audit logging for every model call
- **Definition of Done** — the checklist every implementation must satisfy before Phase 6 PASS

When you onboard a new repo, treat that file as a starting template — not gospel. Add anything specific to your codebase (e.g., team-specific structured-logger names, project-specific error type hierarchies, the exact fields your `IAuditLogger` requires) at the bottom of the file. The agent reads the whole thing every cycle, so concrete, project-specific guidance is read every time.

---

## Appendix A: CLI commands by DevCycle phase

| Phase | Commands |
|---|---|
| **1. Fetch** | `atlassiancli sprint current --board <ID>` · `atlassiancli sprint stories --sprint <ID> --unassigned --priority-order` · `atlassiancli analyze fetch <KEY>` |
| **2. Prepare** | `atlassiancli analyze ready <KEY>` · `atlassiancli analyze lint <KEY>` · `atlassiancli analyze atomicity <KEY>` · `atlassiancli analyze architecture <KEY>` · `atlassiancli enhance <KEY> --apply-architecture --execute` · `atlassiancli template story` |
| **3. Claim** | `atlassiancli transition <KEY> --to "In Progress" --execute` · `atlassiancli assign <KEY> --user <email>` · `atlassiancli comment <KEY> --body "..." --idempotency-key <RUN_ID>` |
| **6. Review (BLOCKING GATE)** | `atlassiancli review <KEY>` · `atlassiancli analyze sop <KEY>` · `atlassiancli framework sop-commit-gate` |
| **8. Create PR** | `atlassiancli link-pr <KEY> --pr-url <URL>` · `atlassiancli transition <KEY> --to "Done" --execute` · `atlassiancli comment <KEY> --body "Merged: <PR_URL>"` |
| **(Setup / maintenance)** | `atlassiancli framework bootstrap --product <handle>` · `atlassiancli framework regenerate-sops --product <handle>` · `atlassiancli framework verify-stories --product <handle>` · `atlassiancli framework sync-docs --product <handle>` |

Every command supports `--json` for the agent-callable envelope. Exit codes follow the contract: `0` proceeds, `1` surfaces findings, `2` is a usage error, `75` (EX_TEMPFAIL) retries with backoff, `77` (EX_NOPERM) halts on auth. Idempotent writes mean the agent can be killed and restarted at any point without producing duplicate comments, transitions, or PR links.

For the full subcommand surface and JSON schemas, see [docs/USAGE.md](USAGE.md) and [docs/AGENT_INTEGRATION.md](AGENT_INTEGRATION.md).

## Appendix B: Mapping the inovagio-internal `scripts.atlassian_v3` to the public CLI

The DevCycle agent at `inovagio/.github/agents/DevCycle.agent.md` was authored against the inovagio-internal `python3 -m scripts.atlassian_v3` path. **The public `inovagio-atlassian` CLI has full surface parity** for every command the agent invokes — they share heritage and the public CLI is the productized version. Migrating the agent is a straightforward find-and-replace.

| Internal (`scripts.atlassian_v3`) | Public (`inovagio-atlassian`) | Notes |
|---|---|---|
| `analyze lint <KEY>` | `analyze lint <KEY>` | identical |
| `analyze atomicity <KEY>` | `analyze atomicity <KEY>` | identical |
| `analyze architecture <KEY>` (and `--real-run`) | `analyze architecture <KEY>` (and `--real-run`) | identical |
| `analyze description --text <TEXT>` | `analyze description --text <TEXT>` | identical |
| `analyze fetch <KEY>` | `analyze fetch <KEY>` | identical |
| `analyze ready <KEY>` | `analyze ready <KEY>` | identical (composite Definition-of-Ready gate) |
| `analyze sop <KEY>` | `analyze sop <KEY>` | identical (Phase 2 story-time SOP rules) |
| `enhance --issue <KEY> --apply-architecture --execute` | `enhance <KEY> --apply-architecture --execute` | positional issue key replaces `--issue` |
| `prepare <KEY> --format ai --output <file>` | `prepare <KEY> --format ai --output <file>` | identical (formats: `full` / `spec` / `hints` / `test` / `ai`) |
| `split <KEY> --execute` | `split <KEY> --execute` | identical (also supports `--project-key` for batch + `--context` filter) |
| `context [<bounded-context>]` | `context [<bounded-context>]` | identical |
| `transition <KEY> "<TARGET>" --execute` | `transition <KEY> --to "<TARGET>" --execute` | flag spelling: `--to <TARGET>` instead of positional |

To migrate the agent: in `DevCycle.agent.md`, replace every `python3 -m scripts.atlassian_v3 ` invocation with `atlassiancli ` (and update the one transition call to use `--to`). The state-machine semantics are unchanged.
