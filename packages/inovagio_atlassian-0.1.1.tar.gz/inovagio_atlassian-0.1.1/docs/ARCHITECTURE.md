# atlassiancli — Architecture

DDD-layered architecture overview. Audience: contributors and engineers who
want to understand how atlassiancli is built before changing it.

The high-level constraints — **zero pip deps at runtime**, **DDD-layered
package**, **agent-callable** — drive every choice below. See
[PLAN.md §2-3](../PLAN.md) for the original design intent.

---

## 1. Layered architecture

```
┌─────────────────────────────────────────────────────────┐
│                          CLI                            │
│  argparse dispatch · agent JSON adapter · DI wiring      │
│   cli/main.py · cli/handlers.py · cli/agent_adapter.py   │
│  cli/framework_handler.py · cli/composition_root.py      │
└──────────────────────┬──────────────────────────────────┘
                       │ uses
                       ▼
┌─────────────────────────────────────────────────────────┐
│                      Application                        │
│  use-case services · DTOs · agent response envelope      │
│   application/services.py · application/dtos.py          │
│   application/agent_response.py                          │
│   application/framework_services/ (4 services)           │
│   application/expert_enhancement_service.py              │
└──────────┬───────────────────────────────────┬──────────┘
           │ depends on (interfaces)           │
           ▼                                   ▼
┌─────────────────────────┐    ┌──────────────────────────┐
│        Domain           │    │      Infrastructure      │
│  pure logic, no I/O     │    │   concrete adapters      │
│  models · value objects │    │   urllib HTTP client     │
│  repositories (intf)    │◄───│   YAML codec             │
│  services (intf)        │    │   .env loader            │
│  framework/ subpackage  │    │   Jira / Confluence      │
└─────────────────────────┘    │   markdown formatter     │
                               │   framework_config       │
                               └──────────────────────────┘
```

The composition root in `cli/composition_root.py` wires concrete
infrastructure adapters into application services at startup. Tests
substitute alternative adapters (typically by patching `urllib.request.urlopen`
or by injecting fake clients).

**Layer N depends on layers 0..N-1, never upward.** Domain has no imports
from application, infrastructure, or cli.

---

## 2. Domain layer

Location: `src/atlassiancli/domain/`

Pure business logic. No I/O, no HTTP, no filesystem.

| File | Contents |
|---|---|
| `models.py` | Rich domain models: `Epic`, `Story`, `Task`, `ConfluencePage`, etc. |
| `value_objects.py` | Type-safe value objects: `IssueKey`, `ConfluencePageId`, story-quality types |
| `repositories.py` | Repository interfaces (`IIssueRepository`, `IConfluenceRepository`) |
| `services.py` | Domain service interfaces |
| `events.py` | Domain events |
| `framework/` | Framework sub-package: `ProductHandle`, `DocHandle`, `ProductConfig`, `JiraConfig`, `ConfluenceConfig`, `PathsConfig` |

Allowed imports: stdlib only. No imports from any other layer.

---

## 3. Application layer

Location: `src/atlassiancli/application/`

Use-case services that orchestrate domain operations. Accept request DTOs,
return response DTOs or `AgentResponse` envelopes.

| File / module | Contents |
|---|---|
| `services.py` | Tier-1 + Tier-2 use-case services (`IssueCreationService`, `StoryLintService`, `StoryReadyService`, `StoryEnhanceService`, `StoryFetchService`, etc.) |
| `dtos.py` | Request / response DTOs |
| `agent_response.py` | Stable JSON envelope (`AgentResponse`, `AgentFinding`, `Severity`, `Verdict`) — import-clean, stdlib-only |
| `expert_enhancement_service.py` | Story-enhancement use-case |
| `framework_services/` | Tier-3 framework services: `create_stories_service.py`, `verify_stories_service.py`, `reverse_sync_service.py`, `sync_docs_service.py` |

Allowed imports: domain + stdlib. No HTTP / Jira / Confluence imports.

---

## 4. Infrastructure layer

Location: `src/atlassiancli/infrastructure/`

Concrete adapters. Everything outside the package's process boundary lives
here.

| File | Contents |
|---|---|
| `http_client.py` | Stdlib `urllib`-based `HttpClient`; raises `HttpAuthError` (→ exit 77) and `HttpRateLimitError` / `HttpTransientError` (→ exit 75) |
| `yaml_codec.py` | Pure-Python YAML parser + writer (subset sufficient for config + manifests) |
| `env_loader.py` | `.env` file parser (stdlib) |
| `config.py` | Project config loader (`.atlassiancli.yaml`) |
| `jira_client.py` | Jira REST adapter on top of `HttpClient` |
| `confluence_client.py` | Confluence REST adapter |
| `markdown_formatter.py` | Markdown → Confluence storage XHTML |
| `framework_config.py` | Per-product `.docframework.yaml` loader |
| `framework_jira_client.py` | Framework-scoped Jira ops (idempotent create-or-update by stable manifest id) |
| `framework_confluence_client.py` | Framework-scoped Confluence ops (page-id-keyed sync) |
| `story_domain_knowledge.py`, `architecture_analyzer.py`, `document_analyzer.py`, `expert_enhancement.py`, `codebase_cross_referencer.py`, `backlog_analyzer.py`, `duplicate_detector.py` | Story-quality + architecture-fit analysers |
| `importers.py`, `confluence_importer.py`, `document_importers.py`, `document_writer.py` | Issue / Confluence importers |
| `mappers.py`, `domain_services.py` | Mapping + helpers |

Allowed imports: domain + stdlib. **No imports from PyPI** at runtime.

---

## 5. CLI layer

Location: `src/atlassiancli/cli/`

argparse-driven dispatch — adapts CLI args to application service calls and
formats the output.

| File | Contents |
|---|---|
| `main.py` | Top-level argparse parser; subcommand registration; dispatch + JSON adapter integration |
| `handlers.py` | Twenty-plus command handlers — `CreateCommandHandler`, `TransitionCommandHandler`, `SprintCommandHandler`, `ConfluenceCommandHandler`, `ReportingCommandHandler`, etc. |
| `agent_adapter.py` | Glue between argparse + `AgentResponse` — emits the JSON envelope when `--json` is set |
| `framework_handler.py` | The five `framework` sub-subcommands (create-stories / verify-stories / reverse-sync / sync-docs / bootstrap) |
| `composition_root.py` | Dependency injection wiring: builds infrastructure adapters and assembles application services |

The composition root is the only place that imports both infrastructure and
application — it is the assembly seam.

---

## 6. Zero-pip-dep boundary

PLAN §3 forces every runtime dependency into the Python standard library.
This means we ship our own implementations of three things commonly
outsourced to PyPI:

1. **YAML codec** (`infrastructure/yaml_codec.py`) — replaces `pyyaml`.
   Subset: mappings, sequences, scalars, single/double quotes, block
   literals (`|`), comments, document separators, `${VAR:-default}`
   expansion. Anchors / aliases / tags / folded scalars are not
   supported.
2. **HTTP client** (`infrastructure/http_client.py`) — replaces `requests`.
   Wraps `urllib.request` with JSON helpers, basic auth header,
   stable error types (`HttpAuthError`, `HttpRateLimitError`,
   `HttpTransientError`, `HttpClientError`, `HttpError`) that map
   directly to the agent exit-code contract.
3. **`.env` loader** (`infrastructure/env_loader.py`) — replaces
   `python-dotenv`. Supports `KEY=VALUE`, comments, quoted values,
   `${VAR}` expansion, override-vs-respect-existing controls.

PyPI deps appear only in dev-time tooling (`ruff`, `build`, `twine`) under
`pyproject.toml`'s `[project.optional-dependencies] dev = [...]`. The
`dependencies` field is `[]`.

Verification:

```bash
# runtime deps must be empty
python -c "import tomllib; print(tomllib.load(open('pyproject.toml','rb'))['project']['dependencies'])"
# []

# package source imports nothing outside stdlib + atlassiancli
grep -rE '^import |^from ' src/atlassiancli/ | grep -v 'atlassiancli\|^[^:]*:import \(typing\|json\|os\|sys\|argparse\|urllib\|datetime\|pathlib\|re\|dataclasses\|abc\|collections\|enum\|functools\|itertools\|hashlib\|base64\|html\|http\|email\)'
```

---

## 7. Testing strategy

- **Test framework:** `unittest.TestCase` (stdlib). `pytest` discovers and
  runs `TestCase` subclasses unchanged for contributors who prefer it.
- **Mocking pattern:** patch `urllib.request.urlopen` at the boundary;
  feed canned response bodies. No live network.
- **Layered tests:**
  - `tests/unit/test_domain.py` — pure-logic tests against domain types
  - `tests/unit/test_infrastructure.py` — adapters with mocked HTTP
  - `tests/unit/test_http_client.py`, `test_env_loader.py`,
    `test_markdown_formatter.py` — focused unit tests
  - `tests/unit/test_framework_services.py` — Tier-3 service tests
  - `tests/unit/test_framework_handler.py` — CLI-level tests for the
    `framework` subcommand group
  - `tests/test_smoke.py` — package import + version check
- **CI:** runs `python -m unittest discover tests/` + `ruff check src/ tests/`
  + `python -m build --wheel`.

---

## 8. Adding a new subcommand

For a non-trivial domain operation (recommended path):

1. **Domain** — add the value objects / model types / repository interface
   methods you need to `domain/`.
2. **Application** — add a new use-case service in `application/services.py`
   (or a new module) that depends only on domain interfaces.
3. **Infrastructure** — add a concrete adapter in `infrastructure/` and
   wire any HTTP calls through `HttpClient` so exit-code mapping is
   automatic.
4. **CLI registration** — add an `_add_<subcommand>_args(subparsers)`
   function in `cli/main.py`, dispatch from `main()` to a handler in
   `cli/handlers.py`, and (if agent-callable) emit an `AgentResponse`
   under `--json`.
5. **Composition root** — wire the new infrastructure → application
   dependency in `cli/composition_root.py`.
6. **Tests** — at minimum, add a unit test against the application
   service with a mocked infrastructure adapter, and a CLI smoke test
   that asserts `--help` and (for agent-callable subcommands) that
   `--json` round-trips.

For a trivial CLI utility (e.g. a one-shot output formatter), a lightweight
handler directly in `cli/handlers.py` is acceptable. Anything that touches
Jira or Confluence must go through the layered path.
