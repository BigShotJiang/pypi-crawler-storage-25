# Release runbook

How releases of `atlassiancli` are cut and shipped.

## Names — mind the three-way split

| What | Value | Why |
|---|---|---|
| GitHub repo | `inovagio/atlassiancli` | Matches the project's historical identity and the trusted-publisher registration. |
| PyPI distribution name | `inovagio-atlassian` | `atlassian-cli` is taken on PyPI and the normalizer treats `atlassiancli` as the same canonical name, so the package publishes under the org-prefixed form. Users do `pip install inovagio-atlassian`. |
| Installed binary command | `atlassiancli` | Stays unchanged across the rename — `pip install inovagio-atlassian` puts an `atlassiancli` script on `$PATH`. |
| Importable Python package | `atlassiancli` | The internal module name is unchanged so `import atlassiancli.…` keeps working. |

The trusted-publisher registration on PyPI uses the **GitHub repo name** (`atlassiancli`), not the PyPI distribution name. Don't put `inovagio-atlassian` in the "Repository name" field at pypi.org — that field maps to the GitHub repo.

## Trust model

Releases publish to PyPI via [trusted publishing](https://docs.pypi.org/trusted-publishers/) — there is no long-lived PyPI token in GitHub Secrets. PyPI verifies the workflow's OIDC token against a per-project allow-list, which means a release is only authorized if **all** of these match:

- Repository: `inovagio/atlassiancli`
- Workflow file: `.github/workflows/release.yml`
- Environment: `pypi` (or `test-pypi` for the staging publish)

A compromised PR cannot publish — both because PRs can't write to the `pypi` environment, and because the environment requires a maintainer to click "Approve" in the Actions UI.

## What happens when a tag is pushed

```
git tag -s v0.5.0 -m "Release v0.5.0"
git push origin v0.5.0
```

The `Release` workflow then runs three jobs in sequence:

1. **build** — builds the sdist + wheel into `dist/`. No special permissions.
2. **publish-test-pypi** — uploads to TestPyPI through the `test-pypi` deployment environment. Auto-approves (tag-only policy is the only gate). Use this to confirm the artifacts install cleanly before the real publish.
3. **publish-pypi** — uploads to PyPI through the `pypi` deployment environment. **Blocks on a required-reviewer approval** before running. Approve in the Actions UI when you're satisfied with the TestPyPI smoke test.

Both publish jobs use SHA-pinned action versions and the workflow has only `contents: read` at the top level; `id-token: write` is granted only inside the publish jobs (and only there).

## One-time PyPI setup

The trust must be registered **at pypi.org** before the first publish — the workflow alone can't grant itself permission. Done once per project on each registry.

### TestPyPI (do this first, then verify on a tag push)

1. Create / log in to your TestPyPI account at https://test.pypi.org/.
2. Publish the first version manually with a token, OR pre-register the trusted publisher:
   - https://test.pypi.org/manage/account/publishing/
   - **Owner:** `inovagio`
   - **Repository:** `atlassiancli`
   - **Workflow:** `release.yml`
   - **Environment:** `test-pypi`
3. Save.

### PyPI

Same flow, on the production registry:

1. https://pypi.org/manage/account/publishing/
2. **Owner:** `inovagio`
3. **Repository:** `atlassiancli`
4. **Workflow:** `release.yml`
5. **Environment:** `pypi`
6. Save.

The first project ever published to a PyPI account requires the project to already exist (PyPI uses "pending publisher" entries for fresh-name registrations). If `inovagio-atlassian` hasn't been published to PyPI yet, register the publisher (use **PyPI Project name** = `inovagio-atlassian`), then push the first tag — PyPI will create the project on the first successful upload.

## Cutting a release (automated via release-please)

You **don't** edit `pyproject.toml`, `CHANGELOG.md`, or push tags by hand.
[`release-please`](https://github.com/googleapis/release-please) computes
the next version from Conventional Commit titles and manages everything.

Day-to-day workflow:

1. **Land work on `main`** with Conventional Commit titles (`feat:`,
   `fix:`, `feat!:`, `perf:`, etc.). The merge gate already enforces
   squash-only, so each merge produces one commit on `main`.
2. **Watch the rolling release PR.** As soon as there's at least one
   `feat:` or `fix:` commit since the last tag, `release-please` opens
   (or keeps updating) a single PR titled `chore(main): release X.Y.Z`
   that contains:
   - `pyproject.toml` version bump (computed from commit types — `feat:`
     → minor, `fix:` → patch, `feat!:` / `BREAKING CHANGE:` → major)
   - `CHANGELOG.md` new section with the user-facing changes since the
     last release
   - `.release-please-manifest.json` updated to the new version
3. **When you want to ship, merge the release PR.** Squash-merge as
   normal. On merge, `release-please` creates the `vX.Y.Z` tag and a
   GitHub release. The tag push fires `release.yml`.
4. **Approve the production publish.** The pipeline auto-publishes to
   TestPyPI via OIDC; the `publish-pypi` job blocks on a required-
   reviewer approval. Open the workflow run, find that job, click
   **Review deployments → Approve**.
5. **Verify.** `pip install inovagio-atlassian==X.Y.Z` in a fresh venv.

Common flow for a small fix:

```bash
# … land your fix:
gh pr create --title "fix(http): retry on 503 with backoff" --body "…"
gh pr merge <num> --squash --admin

# release-please opens "chore(main): release 0.1.1" within ~30s.
# Review it, then:
gh pr merge <release-pr-num> --squash --admin

# Tag fires; TestPyPI publishes; you approve PyPI; done.
```

### Skipping a release

Don't want a `feat:` to ship right away? Don't merge the release PR.
It'll keep updating itself as more commits land, accumulating the next
version's worth of changes. When you finally merge it, all accumulated
changes ship together.

### Forcing a major / minor / patch bump out of order

Override the computed version by editing the release PR's title before
merge: change `chore(main): release 0.2.0` to `chore(main): release
1.0.0`. `release-please` honours the title.

## Rollback

PyPI **does not allow re-uploading** a version. To roll back you must:

1. Yank the bad version: `pip install --upgrade twine && twine upload --skip-existing dist/*` is not the rollback path. Instead, use https://pypi.org/manage/project/inovagio-atlassian/release/0.5.0/ → "Yank release". Yanked versions stay installable for pinned consumers but are skipped by default `pip install`.
2. Cut a new patch version with the fix.
3. **Never delete a published file.** Yank only.

## What to do if the trusted publisher is misconfigured

The `publish-pypi` job will fail with an OIDC error such as `invalid-publisher: valid token, but no corresponding publisher`. To diagnose:

1. Confirm the four-tuple matches exactly (`owner` / `repo` / `workflow` / `environment`).
2. Confirm the workflow filename is `release.yml` (not a renamed copy).
3. Confirm the environment name in `release.yml` is the one registered at PyPI.
4. Re-run the failed job after fixing — no re-tag needed.
