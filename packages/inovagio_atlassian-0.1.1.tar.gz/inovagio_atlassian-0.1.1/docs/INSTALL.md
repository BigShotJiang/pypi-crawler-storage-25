# Installing atlassiancli

A user-facing walkthrough from a clean machine to a working, agent-friendly
setup. If you only want the one-line install, jump to §1; everything else is
there for the moments when something doesn't work.

## 1. Quick install

From PyPI (once published):

```bash
pip install inovagio-atlassian
```

From source (development clone):

```bash
git clone https://github.com/inovagio/atlassiancli.git
cd atlassiancli
pip install -e .
```

Confirm the install resolves and the entry-point is on `PATH`:

```bash
atlassiancli --version
```

The runtime install pulls **zero** third-party packages — only the Python
standard library. The optional `dev` extra (`pip install -e ".[dev]"`) adds
`ruff`, `build`, `twine`, and `mypy` for contributors.

## 2. Python version requirements

atlassiancli targets **Python 3.12 or newer**. 3.12 is the floor; CI runs
against 3.12 only. Older interpreters will fail at import — there is no
back-compat shim because the codebase uses 3.12-only syntax (PEP 695 `type`
aliases, structural pattern matching idioms).

Check your interpreter:

```bash
python3 --version    # must be 3.12+
which python3        # confirm the interpreter pip will install into
```

## 3. Authentication setup

Every subcommand that talks to Atlassian needs an API token. Create one at
[id.atlassian.com](https://id.atlassian.com/manage-profile/security/api-tokens)
under Profile -> Security -> API tokens. Treat the token like a password.

There are three places atlassiancli will look for credentials, in priority
order:

### 3a. Environment variables (CI-friendly)

```bash
export ATLASSIAN_EMAIL=you@example.com
export ATLASSIAN_TOKEN=<atlassian api token>
export ATLASSIAN_SITE=<your-site>.atlassian.net
```

This is the most portable setup and the only one that survives across
Docker / GitHub Actions / a fresh shell with no dotfiles.

### 3b. `.env` file (project-local)

Drop a `.env` file at the project root with the same three keys:

```dotenv
ATLASSIAN_EMAIL=you@example.com
ATLASSIAN_TOKEN=<atlassian api token>
ATLASSIAN_SITE=<your-site>.atlassian.net
```

atlassiancli's stdlib `.env` loader reads this file automatically when the
CLI is invoked from the directory containing it. Add `.env` to your
`.gitignore` — never commit a token.

### 3c. `~/.atlassiancli/config.yaml` (user-global)

For per-user credentials shared across projects, the planned `configure`
subcommand writes to `~/.atlassiancli/config.yaml`. Until that subcommand
ships, prefer 3a or 3b.

## 4. First-time test

Three smoke commands, in increasing trust level:

```bash
# No auth needed — verifies the entry-point is wired
atlassiancli --version

# No auth needed — verifies the rule engine + template generator
atlassiancli template story

# Auth + read-only — verifies the HTTP client + token actually work
atlassiancli sprint current --board <BOARD_ID> --json
```

If `sprint current --json` returns a parseable JSON envelope with
`exit_code: 0`, the auth + transport are correct.

## 5. Project setup

### Adding atlassiancli to a project

Most projects only need:

1. Install the package (`pip install inovagio-atlassian`)
2. Provide credentials (env vars or `.env`)

That's it — there is no project bootstrap step required for the basics tier
or the story-analysis tier.

### Optional: `.atlassiancli.yaml` for project defaults

Projects that always operate against the same project key, board, or
Confluence space can drop a project-local `.atlassiancli.yaml` so
contributors don't need to remember IDs. Keys mirror the CLI flags they
default; see [`docs/USAGE.md`](USAGE.md) for the full schema.

### Optional: `.docframework.yaml` for the framework subcommand

Projects using the doc-framework bridge add per-product manifests under
`docs/<product>/stories/manifests/` and a per-product
`docs/<product>/.docframework.yaml` describing the Jira / Confluence
endpoints. See [`docs/USAGE.md`](USAGE.md) -> "framework" for the schema.

## 6. Updating

```bash
pip install -U inovagio-atlassian
atlassiancli --version
```

Always check [`CHANGELOG.md`](../CHANGELOG.md) before upgrading across a
minor version — semver is honoured but the YAML manifest schemas may shift
between minors.

## 7. Uninstall

```bash
pip uninstall atlassiancli
```

Optional cleanup:

```bash
rm -rf ~/.atlassiancli/    # only if you used the user-global config path
```

## 8. Troubleshooting

| Symptom | Cause | Fix |
| ------- | ----- | --- |
| `atlassiancli: command not found` | pip's `bin/` not on `PATH` | Add `~/.local/bin` (or your venv's `bin/`) to `PATH`, or invoke via `python -m atlassiancli` |
| `401 Unauthorized` | token expired, wrong email, or wrong site | Re-issue the token; double-check `ATLASSIAN_EMAIL` matches the account that owns the token |
| `429 Too Many Requests` (exit code 75) | Atlassian rate limit hit | Back off and retry; the exit-code contract treats 75 as transient so agent loops can sleep + retry |
| `ModuleNotFoundError: atlassiancli` | Python <3.12 or wrong venv | `python3 --version` -> upgrade to 3.12+, then reinstall |
| `Permission denied` writing `~/.atlassiancli/` | Read-only home dir (some CI images) | Use env-var auth (§3a) instead of the user-global config |

For unrecognised failures, run with `--json` and inspect the `error` field;
agent-callable subcommands always return a structured envelope before
exiting non-zero.

## 9. Optional integrations

### GitHub Actions

```yaml
# .github/workflows/jira-link.yml
name: Link PR to Jira
on:
  pull_request:
    types: [opened, edited]
jobs:
  link:
    runs-on: ubuntu-latest
    env:
      ATLASSIAN_EMAIL: ${{ secrets.ATLASSIAN_EMAIL }}
      ATLASSIAN_TOKEN: ${{ secrets.ATLASSIAN_TOKEN }}
      ATLASSIAN_SITE:  ${{ secrets.ATLASSIAN_SITE }}
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - run: pip install inovagio-atlassian
      - run: atlassiancli link-pr --pr-url ${{ github.event.pull_request.html_url }}
```

### Pre-commit hook

A repo-local hook that lints any `Closes <ISSUE>` reference in the commit
message before it lands:

```bash
# .git/hooks/commit-msg
#!/usr/bin/env bash
issue=$(grep -oE '[A-Z]+-[0-9]+' "$1" | head -1)
[ -n "$issue" ] || exit 0
atlassiancli analyze ready "$issue" --json >/dev/null
```

### Cron-driven Confluence sync

```cron
# Every weekday at 06:30, push repo docs into Confluence
30 6 * * 1-5  cd /path/to/repo && atlassiancli framework sync-docs --product myproduct
```

---

For the full subcommand reference see [`docs/USAGE.md`](USAGE.md). For the
agent-callable contract see [`docs/AGENT_INTEGRATION.md`](AGENT_INTEGRATION.md).
For day-to-day operational procedures see [`docs/RUNBOOK.md`](RUNBOOK.md).
