# atlassiancli — Operational Runbook

**Audience:** engineers setting up, running, or maintaining atlassiancli
in a consuming project.

This is the operational companion to [USAGE.md](USAGE.md) (which lists every
subcommand) and [ARCHITECTURE.md](ARCHITECTURE.md) (which explains how the
package is built). If you are the first engineer adopting atlassiancli on a
new project, read [README.md](../README.md) → this runbook → AGENT_INTEGRATION.md
in that order.

---

## 1. Prerequisites

### 1.1 Tooling

- **Python 3.12 or newer.** Check with `python3 --version`.
- **pip** for installing the package.
- An **Atlassian site** (Jira and / or Confluence Cloud) with an API token
  generated at <https://id.atlassian.com/manage-profile/security/api-tokens>.
- For the doc-framework subcommand: a `docs/` directory in your project where
  per-product trees can live.

### 1.2 Install

Either install from PyPI (when published):

```bash
pip install inovagio-atlassian
```

Or from a clone:

```bash
git clone https://github.com/inovagio/atlassiancli.git
cd atlassiancli
pip install -e ".[dev]"
```

Verify:

```bash
atlassiancli --version
# atlassiancli 0.1.0
```

### 1.3 Smoke-test the install

```bash
atlassiancli --help
```

Should list all top-level subcommands. If this fails, your `pip install`
didn't expose the `atlassiancli` console entry — check your virtualenv
activation and the script directory in `pip show -f atlassiancli`.

---

## 2. One-time setup

### 2.1 Set credentials (env vars)

The simplest path. Add to your shell profile or your CI environment:

```bash
export ATLASSIAN_EMAIL="you@example.com"
export ATLASSIAN_TOKEN="<api token>"
export ATLASSIAN_SITE="<your-site>.atlassian.net"
```

### 2.2 Or: a project-root `.env`

If you prefer a per-project `.env` file, drop one at the repo root:

```
# .env
ATLASSIAN_EMAIL=you@example.com
ATLASSIAN_TOKEN=<api token>
ATLASSIAN_SITE=<your-site>.atlassian.net
```

`atlassiancli` parses `.env` via `infrastructure/env_loader.py` (stdlib).
Add `.env` to your project's `.gitignore`.

### 2.3 Or: run the interactive wizard

```
atlassiancli configure                 # writes ~/.atlassiancli/default.toml
atlassiancli configure --profile work  # writes ~/.atlassiancli/work.toml
```

The wizard prompts for site / email / token, verifies the credential
against `GET /rest/api/3/myself`, and writes the profile with mode 0600.
Re-run safely — existing values become the prompt defaults.

### 2.4 Multi-tenant: switch profiles per command

```
atlassiancli --profile work       analyze fetch ACME-1
atlassiancli --profile personal   sprint current --board 7
ATLASSIAN_PROFILE=work atlassiancli analyze ready ACME-1   # via env var
atlassiancli --config /path/to/profile.toml ...            # explicit path
```

Precedence (highest first): `--config` > env vars > `~/.atlassiancli/<profile>.toml` > project defaults.

### 2.5 (Optional) project config

Drop `.atlassiancli.yaml` at the project root for project defaults
(`default_jira_project`, `default_confluence_space`, `framework.products_dir`).
See [examples/minimal-project/.atlassiancli.yaml](EXAMPLES/minimal-project/.atlassiancli.yaml)
for a starter.

---

## 3. Daily Atlassian operations

### 3.1 Create a story

```bash
atlassiancli create story \
  --epic-key PROJ-100 \
  --title "Implement IpSecurityFilter" \
  --description "Filter inbound IPs against the security policy" \
  --story-points 5
```

### 3.2 Move a story through the workflow

```bash
atlassiancli transition PROJ-247 --to "In Progress" --execute
atlassiancli assign PROJ-247 --user you@example.com
atlassiancli comment PROJ-247 --body "Picked up by <you>"
# ... do the work ...
atlassiancli transition PROJ-247 --to "Done" --execute
atlassiancli link-pr PROJ-247 --pr-url https://github.com/org/repo/pull/123
```

All four write commands are idempotent — safe to retry.

### 3.3 Sprint operations

Find the active sprint, list its unassigned items in priority order, and
pick one:

```bash
atlassiancli sprint current --board 42
atlassiancli sprint stories --sprint 318 --unassigned --priority-order
atlassiancli move --to 318 PROJ-247
```

### 3.4 Reports

Quick health check across a project:

```bash
atlassiancli report quality --project PROJ
atlassiancli report velocity --board 42
atlassiancli report themes --project PROJ
atlassiancli report health --project PROJ
```

---

## 4. Story-quality workflows

The `analyze` group implements a Definition-of-Ready gate so stories meet
a known bar before AI-driven implementation.

### 4.1 Definition-of-Ready gate

```bash
atlassiancli analyze ready PROJ-247
# verdict: READY  (score 87 / 80, all 11 sections present, atomicity PASS)
```

For machine consumption:

```bash
atlassiancli --json analyze ready PROJ-247
```

Returns a stable JSON envelope with `verdict: "READY"` or `"NOT_READY"` —
see [AGENT_INTEGRATION.md](AGENT_INTEGRATION.md).

### 4.2 Enhance dry-run → human review → apply

```bash
# 1. propose changes (writes to stdout, no Jira write)
atlassiancli enhance PROJ-247

# 2. review the proposed sections
# 3. apply if satisfied
atlassiancli enhance PROJ-247 --apply
```

### 4.3 Emit a blank template

```bash
atlassiancli template story
atlassiancli template story --output new-story.md
```

Use the template as the starting point for `create story --description-file`
or as a manifest source.

---

## 5. Doc framework operations

The `framework` subcommand bridges per-product YAML manifests on disk with
Jira (stories) and Confluence (docs). Each consuming project has a
**per-product config** at `docs/<product>/.docframework.yaml`.

### 5.1 Bootstrap a new product

```bash
atlassiancli framework bootstrap --product myproduct --name "My Product"
$EDITOR docs/myproduct/.docframework.yaml   # fill in hub_page_id, epics map
```

`bootstrap` is mode-dispatched:

- **Scaffold mode** when `docs/<product>/` is missing — generates the full doc tree from `templates/product-doc-tree/`: `.docframework.yaml`, the seven mandatory top-level docs (README / product-identity / ARCHITECTURE / DESIGN_SPEC / IMPLEMENTATION_PLAN / ROADMAP / PARITY_LEDGER), plus `adrs/`, `epics/`, `stories/manifests/`, `evidence/` with example contents in each. Idempotent on re-run; `--force` overwrites; `--dry-run` reports without touching disk. By default also runs **stack detection** and emits a `sops/` set tuned to the detected language (linter, formatter, test runner, print-pattern regex, error idiom). Pass `--no-auto-sops` to skip detection or `--lang <name>` to override (`python`, `typescript`, `go`, `rust`, `cpp`, `java`, `kotlin`, `csharp`, `ruby`, `javascript`).
- **Parity mode** when the directory already exists — validates `.docframework.yaml`, runs `verify-stories` (when creds are present), echoes next-step guidance.

After scaffolding:
1. Reserve a Confluence hub page in your space and put its numeric id in `confluence.hub_page_id`.
2. Create your epics in Jira and map them under `jira.epics: { E-01: PROJ-100, ... }`.
3. Author the seven mandatory docs (the templates ship with section skeletons — fill them in).
4. Skim `sops/` — the SOPs are auto-tuned to the detected stack but team-specific overrides (legacy paths, complexity thresholds, alert routing) still need editing.
5. Author your first story manifest and run `framework create-stories --product myproduct`.

Re-run SOP autogeneration any time the toolchain changes:

```bash
atlassiancli framework regenerate-sops --product myproduct           # detect + refresh
atlassiancli framework regenerate-sops --product myproduct --lang go # override
atlassiancli framework regenerate-sops --product myproduct --dry-run # preview
```

Generated SOP files carry an `auto-generated by atlassiancli` header. Files that have had that header removed (you took ownership) are skipped; pass `--force` to overwrite anyway.

### 5.2 Add a new ADR / epic / story

ADRs and epics are markdown files under `docs/<product>/adrs/` and
`docs/<product>/epics/`. They sync to Confluence via `framework sync-docs`
(see 5.4).

For new stories, author a manifest:

```bash
$EDITOR docs/myproduct/stories/manifests/S2.5.yaml
atlassiancli framework create-stories --product myproduct \
                                      --manifest S2.5 --dry-run
# review the planned Jira write
atlassiancli framework create-stories --product myproduct --manifest S2.5
```

The manifest schema (minimum required fields):

```yaml
id: S2.5
epic: E-02
title: Implement the X service
# optional but recommended:
phase: 2
priority: P1
acceptance:
  - The service responds in <50ms p99
  - All inputs are validated before reaching the domain
owns_paths:
  - src/x_service/**
spec_refs:
  - DESIGN_SPEC.md#x-service
```

### 5.3 Update an existing doc + sync to Confluence

```bash
$EDITOR docs/myproduct/ARCHITECTURE.md
atlassiancli framework sync-docs --product myproduct --doc ARCHITECTURE --dry-run
atlassiancli framework sync-docs --product myproduct --doc ARCHITECTURE
```

### 5.4 Reverse-sync from Jira when stories pre-exist

If your project had stories in Jira before adopting the framework:

```bash
atlassiancli framework reverse-sync --product myproduct --epic E-01 --dry-run
atlassiancli framework reverse-sync --product myproduct --epic E-01
```

This materialises a `docs/<product>/stories/manifests/SX.Y.yaml` file for
each Jira story missing one. Run epic-by-epic to keep diffs small.

### 5.5 Verify parity (manifest ↔ Jira)

```bash
atlassiancli framework verify-stories --product myproduct
atlassiancli --json framework verify-stories --product myproduct
```

The verify subcommand counts manifests per epic, queries Jira for matching
stories per epic, and reports any drift. CI integrations should call this
with `--json` and fail the build on mismatch.

---

## 6. Configuration files reference

### 6.1 Project config (`.atlassiancli.yaml`)

Top-level CLI defaults at the project root:

```yaml
atlassian:
  cloud_site: <your-site>.atlassian.net
  default_jira_project: <KEY>
  default_confluence_space: <KEY>

framework:
  enabled: true
  products_dir: docs              # where docs/<product>/ trees live
```

### 6.2 Per-product framework config (`docs/<product>/.docframework.yaml`)

```yaml
product:
  id: myproduct                   # must match the directory name
  name: My Product

jira:
  cloud_site: <your-site>.atlassian.net
  project_key: <KEY>
  default_assignee_email: you@example.com
  label_namespace: myproduct-ga-v1     # required
  summary_prefix: "[MYPRODUCT]"        # required
  epics:
    E-01: <ISSUE-KEY>
    E-02: <ISSUE-KEY>

confluence:
  cloud_site: <your-site>.atlassian.net
  space_key: <KEY>
  hub_page_id: "<your project's confluence hub page id>"   # required
  doc_pages:
    README: "<page id>"
    ARCHITECTURE: "<page id>"

paths:
  manifests_dir: stories/manifests
  evidence_dir: evidence
  epic_docs_dir: epics
  adr_dir: adrs
```

Hard-required fields (loader exits with status 2 if missing):
`product.id`, `product.name`, `jira.label_namespace`, `jira.summary_prefix`,
`confluence.hub_page_id`. The `paths.*` block is optional — sensible defaults
ship.

### 6.3 User config (`~/.atlassiancli/config.yaml`)

Multi-profile credentials (see §2.3 above).

---

## 7. Common gotchas

### Auth errors (exit code 77)

The HTTP layer raises `HttpAuthError` on 401 / 403 and the dispatcher exits
with **77** (EX_NOPERM). Cause is almost always one of:

- `ATLASSIAN_TOKEN` is missing, expired, or revoked
- `ATLASSIAN_EMAIL` does not match the token's owner
- The user lacks Jira / Confluence permission for the targeted site

Regenerate the token at id.atlassian.com and re-export.

### Rate-limit / transient errors (exit code 75)

Atlassian Cloud applies per-tenant rate limits. The HTTP layer raises
`HttpRateLimitError` / `HttpTransientError`, the dispatcher exits with **75**
(EX_TEMPFAIL). Agent integrations retry with exponential backoff (see
[AGENT_INTEGRATION.md §3](AGENT_INTEGRATION.md)).

### Missing config errors (exit code 2)

The framework loader exits with **2** if `.docframework.yaml` is missing,
not a YAML mapping, or missing a required section. The error message names
the missing file or field — fork
[the example .docframework.yaml](EXAMPLES/doc-framework-product/docs/myproduct/.docframework.yaml)
into `docs/<product>/` and populate the placeholders.

### Confluence page reservation needed before sync

`framework sync-docs` and `confluence update` require the page id to already
exist. The CLI does not auto-create pages from a markdown filename. To
publish a brand-new doc, first `confluence create --execute` to reserve the
page id, then add the new page id to the product's `confluence.doc_pages`
map, then run `framework sync-docs`.

### `framework <subcommand>` exits with status 2 immediately

Two common causes: `ATLASSIAN_EMAIL` / `ATLASSIAN_TOKEN` are unset, or the
`docs/<product>/.docframework.yaml` is missing or malformed. Both surface
through `infrastructure/framework_config.py::get_credentials()` /
`load_product_config()` with a precise message — read stderr.

---

## 8. Verification gates

### 8.1 When to run `framework verify-stories`

- After every batch `framework create-stories` operation
- As a CI gate on PRs that touch `docs/<product>/stories/manifests/`
- Before cutting a release branch

```bash
atlassiancli --json framework verify-stories --product myproduct \
  || echo "manifest <-> Jira drift; investigate"
```

### 8.2 When to run `analyze ready`

- Before assigning a story to an AI agent
- As a CI gate against newly-touched stories on a PR
- During grooming, against any story flagged for the next sprint

```bash
atlassiancli --json analyze ready PROJ-247
```

If verdict is `NOT_READY`, run `analyze lint` and `analyze description` for
the per-rule findings, then `enhance --apply` (or hand-edit) and re-check.

### 8.3 JSON output for CI integration

Every analyse / framework subcommand emits the stable AgentResponse envelope
under `--json`. Wire CI to `jq -e` the `verdict` field:

```bash
atlassiancli --json analyze ready PROJ-247 \
  | jq -e '.verdict == "READY"' \
  || (echo "Story not ready" && exit 1)
```
