# atlassiancli — Agent Integration Guide

How AI coding agents call atlassiancli. Audience: an engineer writing an
agent prompt or wiring atlassiancli into an autonomous-development workflow.

The integration contract is specified in [PLAN.md §6.4](../PLAN.md). This
guide is the implementer's reference.

---

## 1. Overview

atlassiancli is designed as **agent-callable infrastructure** for
ticket-to-PR workflows. An autonomous coding agent uses it to:

- discover the active sprint and pick an unassigned, prioritised story,
- validate the story against a Definition-of-Ready gate,
- propose missing description sections (review-then-apply),
- mark the story in-progress, post a run-id comment, attach the resulting
  PR, and transition to Done.

Three properties make this safe:

1. **Stable JSON output** under `--json` (schema in §2)
2. **Stable exit-code contract** so the agent's state machine can branch
   on `0` / `1` / `2` / `75` / `77` (table in §3)
3. **Idempotent writes** so the agent can retry without producing
   duplicate state (rules in §4)

---

## 2. Output format

When invoked with the global `--json` flag, every analyse / agent / framework
subcommand emits exactly one **AgentResponse** envelope on stdout. The
envelope is defined in `application/agent_response.py` and is the single
source of truth.

### 2.1 Schema

```json
{
  "issue_key": "PROJ-247",
  "command": "analyze.lint",
  "verdict": "PASS",
  "score": 87,
  "threshold": 80,
  "findings": [
    {
      "severity": "minor",
      "rule": "section.acceptance.coverage",
      "section": "Acceptance Criteria",
      "message": "Only 2 acceptance criteria — recommend at least 3",
      "fix_hint": "Add ACs covering negative paths"
    }
  ],
  "metadata": {
    "fetched_at": "2026-05-09T15:30:00Z"
  }
}
```

### 2.2 Field semantics

| Field | Type | Notes |
|---|---|---|
| `issue_key` | `string \| null` | Jira key the command operates on; `null` for issue-less commands (`template`, `sprint current`) |
| `command` | `string` | Dotted command path: `analyze.lint`, `sprint.current`, `transition`, `framework.verify-stories`, etc. |
| `verdict` | `"PASS" \| "FAIL" \| "WARN" \| "READY" \| "NOT_READY" \| null` | `null` where not applicable (`fetch`, `template`) |
| `score` | `int \| null` | Integer 0–100 for scored gates |
| `threshold` | `int \| null` | The pass/fail bar applied to `score` |
| `findings` | `list[Finding]` | Always a list (possibly empty), never `null` |
| `metadata` | `object` | Free-form; always contains `fetched_at` (ISO 8601 with trailing `Z`) |

A **Finding** has shape:

```json
{
  "severity": "critical | major | minor | info",
  "rule": "<rule id>",
  "section": "<section name or null>",
  "message": "<text>",
  "fix_hint": "<text or null>"
}
```

### 2.3 Stability promise

- Fields that don't apply are emitted as `null`, never omitted. The agent
  parser can rely on key presence.
- The severity enum is fixed at `critical` / `major` / `minor` / `info`.
- The verdict enum is fixed at `PASS` / `FAIL` / `WARN` / `READY` /
  `NOT_READY` / `null`.
- New fields may be **added** in minor versions; never **removed** or
  **renamed** within a major version.

### 2.4 Pretty-printing for humans

When `--json` is omitted, the same handler emits a human-readable rendering
of the same response. Don't parse the human form — always pass `--json`
from the agent.

---

## 3. Exit-code contract

Implemented in `cli/main.py::_exit_code_for_exception`. Every subcommand
follows this table.

| Code | Meaning | Agent action |
|---|---|---|
| `0` | Success | Continue to the next phase |
| `1` | Generic failure (validation, runtime, business-rule violation) | Halt the run, surface the finding to the operator |
| `2` | Bad CLI usage (argparse) or missing required config | Halt — programmer error, will not fix on retry |
| `75` | Transient failure (`HttpTransientError`, `HttpRateLimitError` — HTTP 5xx, 429) | Retry with exponential backoff (recommended: 2× from 1s, max 60s, max 5 attempts) |
| `77` | Auth failure (`HttpAuthError` — HTTP 401 / 403) | Halt — credentials issue. Re-running won't fix it |

JSON mode does not change the exit code: the envelope is on stdout, the
exit code is the program return value.

---

## 4. Idempotency guarantees

Every write subcommand is safe to retry. The implementations enforce this
in code:

| Command | Idempotency rule |
|---|---|
| `transition <KEY> --to <state>` | Jira no-ops if the issue is already in the target state. Safe to call repeatedly. |
| `assign <KEY> --user <email>` | Jira no-ops if the user is already assigned. |
| `comment <KEY> --body <text> --idempotency-key <key>` | Skips the post if any existing comment contains the key. Pass the agent run id as the key. |
| `link-pr <KEY> --pr-url <url>` | Dedupes against existing remote-issue-links — same URL, no duplicate link. |
| `framework create-stories` | Manifests carry stable IDs (`SX.Y`); the bridge updates the existing Jira story rather than creating a duplicate. |
| `framework sync-docs` | Confluence page updates are content-versioned; replaying with the same content is a no-op (or version-bump if changed). |
| `framework reverse-sync` | Skips manifests already on disk; only materialises missing ones. |
| `framework verify-stories` | Read-only; idempotent by definition. |

Without `--idempotency-key`, `comment` is **not** idempotent: a retry will
post a duplicate. Always pass the key from agents.

---

## 5. Recommended invocation patterns

A canonical ticket-to-PR cycle, phase by phase. Replace `PROJ` with your
project key and `42` with your board id.

### 5.1 Phase: fetch sprint item

```bash
atlassiancli --json sprint current --board 42
# metadata.sprint_id is the active sprint

atlassiancli --json sprint stories --sprint <id> --unassigned --priority-order
# metadata.stories[0] is the agent's pick
```

### 5.2 Phase: validate story

```bash
atlassiancli --json analyze ready PROJ-247
# verdict == "READY" → continue; "NOT_READY" → see 5.3
```

### 5.3 Phase: enhance gaps (fallback)

```bash
atlassiancli --json enhance PROJ-247
# metadata.proposed_description is the agent's suggested rewrite

# show to operator; on approval:
atlassiancli enhance PROJ-247 --apply
```

`enhance` defaults to dry-run (no Jira write). The agent **must not**
apply enhancements without human approval — the contract is review-then-apply.

### 5.4 Phase: mark in-progress

```bash
atlassiancli transition PROJ-247 --to "In Progress" --execute
atlassiancli assign PROJ-247 --user "$ATLASSIAN_EMAIL"
atlassiancli comment PROJ-247 \
  --body "Run id: $RUN_ID — agent picked up at $(date -u +%FT%TZ)" \
  --idempotency-key "$RUN_ID"
```

All three are idempotent — retry-safe on transient failure.

### 5.5 Phase: mark done

```bash
atlassiancli transition PROJ-247 --to "Done" --execute
atlassiancli link-pr PROJ-247 --pr-url "$PR_URL"
```

---

## 6. Error handling pattern

Reference Python implementation an agent can drop into a runtime:

```python
import json
import subprocess
import time
from typing import Any


class AtlassianCliError(Exception):
    """Raised when atlassiancli returns a non-zero exit code we cannot recover from."""


def call(
    *args: str,
    max_retries: int = 5,
    base_backoff_s: float = 1.0,
    max_backoff_s: float = 60.0,
) -> dict[str, Any]:
    """Invoke atlassiancli with --json; retry transient failures."""
    backoff = base_backoff_s
    for attempt in range(max_retries):
        proc = subprocess.run(
            ["atlassiancli", "--json", *args],
            capture_output=True,
            text=True,
            check=False,
        )
        rc = proc.returncode

        if rc == 0:
            return json.loads(proc.stdout)

        if rc == 75:                                      # transient
            if attempt + 1 == max_retries:
                raise AtlassianCliError(f"transient failure after {max_retries} retries: {proc.stderr}")
            time.sleep(min(backoff, max_backoff_s))
            backoff *= 2
            continue

        if rc == 77:                                      # auth — halt
            raise AtlassianCliError(f"auth failure (77): fix credentials. stderr: {proc.stderr}")

        if rc == 2:                                       # bad usage / config — halt
            raise AtlassianCliError(f"usage / config error (2): {proc.stderr}")

        # rc == 1 or other — surface the JSON error envelope if present
        try:
            envelope = json.loads(proc.stdout)
        except json.JSONDecodeError:
            envelope = {"stdout": proc.stdout, "stderr": proc.stderr}
        raise AtlassianCliError(f"failure (rc={rc}): {envelope}")

    raise AtlassianCliError("unreachable")  # pragma: no cover
```

### 6.1 Failure-shaped envelope

When a subcommand fails inside the JSON dispatch path, the dispatcher writes
a **failure-shaped AgentResponse** before exiting:

```json
{
  "issue_key": "PROJ-247",
  "command": "transition",
  "verdict": "FAIL",
  "score": null,
  "threshold": null,
  "findings": [
    {
      "severity": "critical",
      "rule": "execution.error",
      "section": null,
      "message": "<exception message>",
      "fix_hint": null
    }
  ],
  "metadata": {
    "fetched_at": "2026-05-09T15:30:00Z",
    "exit_code": 75,
    "exception_type": "HttpRateLimitError"
  }
}
```

The agent can branch on `metadata.exit_code` and `metadata.exception_type`
identically to the process exit code.

---

## 7. Recorded fixtures for agent testing

The CLI itself has no live-network test suite — every test mocks
`urllib.request.urlopen` and feeds canned responses. To build an offline
integration test for **your** agent against atlassiancli:

1. Run a representative invocation against a real Atlassian site once,
   capturing both the JSON request bodies (logged on stderr in debug mode)
   and the response bodies.
2. Place the captured pairs under `tests/fixtures/<scenario>/` in your agent
   repo as `request_<n>.json` + `response_<n>.json`.
3. Implement a `urlopen` patch that replays the captured responses in order.
4. In agent tests, drive the CLI via `subprocess.run` with the patched env
   pointing at a local mock server, or via direct module imports for finer
   control.

The `application/agent_response.py` module is import-clean (no Atlassian or
HTTP dependencies) — agents can import `AgentResponse` directly to validate
captured envelopes.

---

## 8. Versioning + stability promise

- **JSON schema** is semver-stable. Minor versions may add fields; never
  remove or rename within a major version.
- **Exit codes** (`0` / `1` / `2` / `75` / `77`) are stable across patch
  and minor versions.
- **Severity enum** (`critical` / `major` / `minor` / `info`) and
  **verdict enum** (`PASS` / `FAIL` / `WARN` / `READY` / `NOT_READY`) are
  fixed.
- **Major version bumps** may break the schema. Agents should pin and
  read `atlassiancli --version` before assuming a contract version.

```bash
atlassiancli --version
# atlassiancli 0.1.0
```

When wiring a long-lived agent: pin the major version in your virtualenv
spec (`atlassiancli>=0.1,<1.0`) and re-test against each major bump.
