nullify

Description: Randomly replaces existing column data with a completely blank string (empty field) up to your defined percentage limit.

Validation Purpose: Tests whether your framework correctly handles missing keys, detects structural row count imbalances, or drops values during outer-join schema comparisons.

case_swap

Description: Swaps lowercase letters to uppercase and uppercase letters to lowercase across characters in the string.

Validation Purpose: Verifies if your reconciliation system is case-sensitive or if database collation mismatches are causing false-positive validation passes on string lookups.

numeric_shift

Description: Modifies existing integers or float numbers by adding or subtracting a specific numeric scale factor (e.g., changing values by exactly 0.05).

Validation Purpose: Validates micro-level rounding, numeric precision degradation, and floating-point arithmetic tolerances inside financial or statistical data tracking pipelines.

date_shift

Description: Shifts standard ISO formatted dates or datetime values forward or backward by a targeted count of days.

Validation Purpose: Pinpoints synchronization lag problems, server timezone configuration offsets, and temporal boundary filter execution logic.

typo

Description: Substitutes a single character within an alphanumeric string with a completely different random character or number.

Validation Purpose: Breaks text string hash keys (like MD5 or SHA-256 binary signatures) immediately, verifying if your row-level checksum calculations are operating with absolute binary fidelity.