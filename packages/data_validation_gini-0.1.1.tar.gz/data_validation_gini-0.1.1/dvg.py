#!/usr/bin/env python3
import argparse
import csv
import os
import sys
from datetime import datetime

from dvg_report import write_html_report


def parse_args():
    parser = argparse.ArgumentParser(
        description="Data Validation Gini CLI (dvg): compare source and target files."
    )
    parser.add_argument(
        "--file-type",
        required=True,
        choices=["EXCEL"],
        help="Input file type. Use EXCEL for .csv/.xlsx/.xlsm/.xltx files.",
    )
    parser.add_argument("--src-path", required=True, help="Path to source file")
    parser.add_argument("--tgt-path", required=True, help="Path to target file")
    parser.add_argument(
        "--validation-type",
        required=True,
        help="Validation mode: ROWCOUNT, ROW_COL_VALIDATION, or both (e.g., 'ROWCOUNT,ROW_COL_VALIDATION')",
    )
    parser.add_argument(
        "--html-output",
        required=False,
        help="Optional HTML report path. Supports <datetime> token.",
    )
    parser.add_argument(
        "--src-sheet",
        required=False,
        help="Optional source sheet name for Excel input.",
    )
    parser.add_argument(
        "--tgt-sheet",
        required=False,
        help="Optional target sheet name for Excel input.",
    )
    parser.add_argument(
        "--sheet-mapping",
        required=False,
        help="Optional Excel sheet mapping, e.g. 'SRC1:TGT1,SRC2:TGT2'.",
    )
    return parser.parse_args()


def normalize_cell(value):
    if value is None:
        return ""
    return str(value)


def trim_trailing_empty(values):
    result = list(values)
    while result and result[-1] == "":
        result.pop()
    return result


def load_csv(path):
    with open(path, mode="r", encoding="utf-8-sig", newline="") as f:
        raw = list(csv.reader(f))
    if not raw:
        return [], []
    header = trim_trailing_empty([normalize_cell(v) for v in raw[0]])
    rows = [trim_trailing_empty([normalize_cell(v) for v in row]) for row in raw[1:]]
    return header, rows


def load_excel(path, sheet_name=None):
    try:
        from openpyxl import load_workbook
    except ImportError:
        print("FAILED")
        print("Reason: openpyxl is required for .xlsx/.xlsm/.xltx files. Install it with: pip install openpyxl")
        sys.exit(1)

    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    if sheet_name:
        if sheet_name not in wb.sheetnames:
            wb.close()
            print("FAILED")
            print(f"Reason: Sheet '{sheet_name}' not found in file: {path}")
            sys.exit(1)
        ws = wb[sheet_name]
    raw = []
    for row in ws.iter_rows(values_only=True):
        raw.append(trim_trailing_empty([normalize_cell(v) for v in row]))
    wb.close()

    if not raw:
        return [], []
    header = raw[0]
    rows = raw[1:]
    return header, rows


def load_table(path, sheet_name=None):
    ext = os.path.splitext(path)[1].lower()
    if ext == ".csv":
        if sheet_name:
            print("FAILED")
            print(f"Reason: --src-sheet/--tgt-sheet requires Excel input, got CSV: {path}")
            sys.exit(1)
        return load_csv(path)
    if ext in {".xlsx", ".xlsm", ".xltx"}:
        return load_excel(path, sheet_name=sheet_name)
    print("FAILED")
    print(f"Reason: Unsupported file extension '{ext}'. Supported: .csv, .xlsx, .xlsm, .xltx")
    sys.exit(1)


def is_excel_path(path):
    return os.path.splitext(path)[1].lower() in {".xlsx", ".xlsm", ".xltx"}


def parse_sheet_mapping(mapping_text):
    pairs = []
    for token in (mapping_text or "").split(","):
        item = token.strip()
        if not item:
            continue
        if ":" not in item:
            print("FAILED")
            print(
                "Reason: Invalid --sheet-mapping format. Use 'SRC1:TGT1,SRC2:TGT2'."
            )
            sys.exit(1)
        src_sheet, tgt_sheet = item.split(":", 1)
        src_sheet = src_sheet.strip()
        tgt_sheet = tgt_sheet.strip()
        if not src_sheet or not tgt_sheet:
            print("FAILED")
            print(
                "Reason: Invalid --sheet-mapping pair. Both source and target sheet names are required."
            )
            sys.exit(1)
        pairs.append((src_sheet, tgt_sheet))

    if not pairs:
        print("FAILED")
        print("Reason: --sheet-mapping is empty. Use format 'SRC1:TGT1,SRC2:TGT2'.")
        sys.exit(1)

    return pairs


def compare_rowcount(src_rows, tgt_rows):
    src_count = len(src_rows)
    tgt_count = len(tgt_rows)
    passed = src_count == tgt_count
    if passed:
        reason = f"Row counts match: src={src_count}, tgt={tgt_count}."
    else:
        reason = f"Row count mismatch: src={src_count}, tgt={tgt_count}."
    return passed, reason, []


def compare_row_col(src_header, src_rows, tgt_header, tgt_rows):
    mismatches = []

    def classify_mismatch(src_val, tgt_val):
        src_blank = str(src_val).strip() == ""
        tgt_blank = str(tgt_val).strip() == ""
        if (not src_blank) and tgt_blank:
            return "SRC_ONLY", "Source-only value (target missing or blank)"
        if src_blank and (not tgt_blank):
            return "TGT_ONLY", "Target-only value (source missing or blank)"
        return "CELL", "Cell value mismatch"

    def build_row_map(header, rows):
        preferred_keys = ["employee_id", "id", "emp_id", "record_id", "pk"]
        lowered = [str(h).strip().lower() for h in header]

        key_idx = None
        for candidate in preferred_keys:
            if candidate in lowered:
                key_idx = lowered.index(candidate)
                break

        # Fallback to first column if no standard key column is present.
        if key_idx is None and header:
            key_idx = 0

        row_map = {}
        if key_idx is None:
            return row_map, key_idx

        for row_idx, row in enumerate(rows):
            key_val = row[key_idx] if key_idx < len(row) else ""
            key_text = str(key_val).strip()
            if key_text == "":
                # Deterministic fallback key for blank ID values.
                key_text = f"__row_{row_idx + 2}"
            row_map[key_text] = (row_idx, row)

        return row_map, key_idx

    if len(src_header) != len(tgt_header):
        mismatches.append(
            {
                "type": "HEADER_LENGTH",
                "row": 1,
                "column": "<HEADER>",
                "src": str(len(src_header)),
                "tgt": str(len(tgt_header)),
                "reason": "Header column count mismatch",
            }
        )

    header_limit = max(len(src_header), len(tgt_header))
    for col_idx in range(header_limit):
        src_col = src_header[col_idx] if col_idx < len(src_header) else ""
        tgt_col = tgt_header[col_idx] if col_idx < len(tgt_header) else ""
        if src_col != tgt_col:
            mismatches.append(
                {
                    "type": "HEADER_NAME",
                    "row": 1,
                    "column": f"col_{col_idx + 1}",
                    "src": src_col,
                    "tgt": tgt_col,
                    "reason": "Header name mismatch",
                }
            )

    if len(src_rows) != len(tgt_rows):
        mismatches.append(
            {
                "type": "ROWCOUNT",
                "row": 0,
                "column": "<ROWCOUNT>",
                "src": str(len(src_rows)),
                "tgt": str(len(tgt_rows)),
                "reason": "Data row count mismatch",
            }
        )

    src_map, _ = build_row_map(src_header, src_rows)
    tgt_map, _ = build_row_map(tgt_header, tgt_rows)

    all_keys = sorted(set(src_map.keys()) | set(tgt_map.keys()))

    for key in all_keys:
        src_entry = src_map.get(key)
        tgt_entry = tgt_map.get(key)

        src_row_idx = src_entry[0] if src_entry else None
        tgt_row_idx = tgt_entry[0] if tgt_entry else None
        src_row = src_entry[1] if src_entry else []
        tgt_row = tgt_entry[1] if tgt_entry else []

        display_row = (src_row_idx if src_row_idx is not None else tgt_row_idx) + 2
        col_limit = max(len(src_header), len(tgt_header), len(src_row), len(tgt_row))

        for col_idx in range(col_limit):
            src_val = src_row[col_idx] if col_idx < len(src_row) else ""
            tgt_val = tgt_row[col_idx] if col_idx < len(tgt_row) else ""
            if src_val == tgt_val:
                continue

            if col_idx < len(src_header):
                col_name = src_header[col_idx]
            elif col_idx < len(tgt_header):
                col_name = tgt_header[col_idx]
            else:
                col_name = f"col_{col_idx + 1}"

            mismatch_type, mismatch_reason = classify_mismatch(src_val, tgt_val)
            mismatches.append(
                {
                    "type": mismatch_type,
                    "row": display_row,
                    "column": col_name,
                    "src": src_val,
                    "tgt": tgt_val,
                    "reason": mismatch_reason,
                }
            )

    passed = len(mismatches) == 0
    if passed:
        reason = "All rows and columns match."
    else:
        reason = f"Found {len(mismatches)} mismatch(es) across headers/rows/columns."
    return passed, reason, mismatches


def resolve_output_path(path):
    if not path:
        return None
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    resolved = path.replace("<datetime>", ts).replace("<datetime<", ts)
    resolved = os.path.normpath(resolved)
    out_dir = os.path.dirname(resolved)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    return resolved


def main():
    args = parse_args()

    if not os.path.exists(args.src_path):
        print("FAILED")
        print(f"Reason: Source file not found: {args.src_path}")
        sys.exit(1)
    if not os.path.exists(args.tgt_path):
        print("FAILED")
        print(f"Reason: Target file not found: {args.tgt_path}")
        sys.exit(1)

    if args.sheet_mapping and (not is_excel_path(args.src_path) or not is_excel_path(args.tgt_path)):
        print("FAILED")
        print("Reason: --sheet-mapping is supported only for Excel files (.xlsx/.xlsm/.xltx).")
        sys.exit(1)

    if args.sheet_mapping:
        sheet_pairs = parse_sheet_mapping(args.sheet_mapping)
    else:
        sheet_pairs = [(args.src_sheet, args.tgt_sheet)]

    # Parse validation types (support comma-separated values)
    validation_types_raw = args.validation_type.split(",")
    validation_types = [vt.strip().upper() for vt in validation_types_raw]
    
    # Validate that all requested types are supported
    supported = {"ROWCOUNT", "ROW_COL_VALIDATION"}
    for vt in validation_types:
        if vt not in supported:
            print("FAILED")
            print(f"Reason: Unsupported validation type '{vt}'. Supported: ROWCOUNT, ROW_COL_VALIDATION")
            sys.exit(1)

    # Run validations across configured sheet pair(s)
    all_mismatches = []
    all_passed = True
    reasons = []
    total_src_rows = 0
    total_tgt_rows = 0

    for src_sheet_name, tgt_sheet_name in sheet_pairs:
        src_header, src_rows = load_table(args.src_path, sheet_name=src_sheet_name)
        tgt_header, tgt_rows = load_table(args.tgt_path, sheet_name=tgt_sheet_name)

        total_src_rows += len(src_rows)
        total_tgt_rows += len(tgt_rows)

        if src_sheet_name or tgt_sheet_name:
            sheet_label = f"{src_sheet_name or '<active>'}->{tgt_sheet_name or '<active>'}"
        else:
            sheet_label = "<active_sheet>"

        if "ROWCOUNT" in validation_types:
            rc_passed, rc_reason, rc_mismatches = compare_rowcount(src_rows, tgt_rows)
            all_passed = all_passed and rc_passed
            reasons.append(f"[{sheet_label}][ROWCOUNT] {rc_reason}")
            for item in rc_mismatches:
                tagged = dict(item)
                tagged["reason"] = f"[{sheet_label}] {item.get('reason', '')}"
                all_mismatches.append(tagged)

        if "ROW_COL_VALIDATION" in validation_types:
            row_col_passed, row_col_reason, row_col_mismatches = compare_row_col(
                src_header, src_rows, tgt_header, tgt_rows
            )
            all_passed = all_passed and row_col_passed
            reasons.append(f"[{sheet_label}][ROW_COL_VALIDATION] {row_col_reason}")
            for item in row_col_mismatches:
                tagged = dict(item)
                tagged["reason"] = f"[{sheet_label}] {item.get('reason', '')}"
                all_mismatches.append(tagged)

    passed = all_passed
    reason = " | ".join(reasons)

    print("PASSED" if passed else "FAILED")
    print(f"Reason: {reason}")

    if not passed and all_mismatches:
        preview = all_mismatches[:10]
        print("Mismatch preview (first 10):")
        for item in preview:
            print(
                f"  - type={item['type']} row={item['row']} column={item['column']} "
                f"src='{item['src']}' tgt='{item['tgt']}' reason='{item['reason']}'"
            )

    if args.html_output:
        out_path = resolve_output_path(args.html_output)
        write_html_report(
            path=out_path,
            passed=passed,
            summary=reason,
            src_path=args.src_path,
            tgt_path=args.tgt_path,
            validation_type=args.validation_type,
            mismatches=all_mismatches,
            src_rows_count=total_src_rows,
            tgt_rows_count=total_tgt_rows,
        )
        print(f"HTML report: {out_path}")

    sys.exit(0 if passed else 1)


if __name__ == "__main__":
    main()
