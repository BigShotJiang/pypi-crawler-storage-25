"""External skill installation service -- sandbox, scan, pin.

Handles the complete flow for installing skills from external sources
(e.g. ClawHub): download to sandbox, hash contents, check scan cache,
run security pipeline on cache miss, and pin the installed version.
"""

from __future__ import annotations

import io
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path

import httpx
import typer
from rich.console import Console

from agentpowers_cli.services.api_client import APIClient, APIError
from agentpowers_cli.services.auth_store import load_token
from agentpowers_cli.services.config import API_BASE_URL
from agentpowers_cli.services.content_hasher import hash_directory
from agentpowers_cli.services.installer import get_claude_dir
from agentpowers_cli.services.pin_manager import save_pin

console = Console()


def install_external_skill(
    client: APIClient,
    slug: str,
    source: str,
    skill_type: str = "skill",
    version: str | None = None,
    pins_path: str | None = None,
    base_dir: Path | None = None,
) -> str:
    """Install an external skill through sandbox + security scan + pin.

    1. Download to temp sandbox via external source CLI
    2. Hash the contents
    3. Check scan cache via API
    4. On cache miss: package and upload for scanning
    5. If pass/warn: move to install dir, save pin
    6. If block: show findings, exit

    Args:
        client: Configured APIClient instance.
        slug: The skill slug to install.
        source: External source name (e.g. "clawhub").
        skill_type: Either "skill" or "agent".
        version: Optional version string.
        pins_path: Override path for pins.json.
        base_dir: Override for the base .claude directory. Defaults to ~/.claude.

    Returns:
        Path to the installed directory.

    Raises:
        typer.Exit: On download failure, scan failure, or blocked skill.
    """
    # Step 1: Download to sandbox
    sandbox = tempfile.mkdtemp(prefix="ap-sandbox-")
    try:
        with console.status(
            f"Downloading {slug} from {source}...", spinner="dots"
        ) as status:
            result = subprocess.run(
                ["npx", source, "install", slug, "--no-input", "--dir", sandbox],
                capture_output=True,
                text=True,
                timeout=60,
            )
            if result.returncode != 0:
                console.print(f"[red]External install failed:[/red] {result.stderr}")
                raise typer.Exit(code=1)

            # Step 2: Hash contents
            status.update(f"Hashing contents of {slug}...")
            content_hash = hash_directory(sandbox)

            # Step 3: Check scan cache
            status.update("Checking scan cache...")
            # Use server-computed hash for pinning (not client hash)
            pin_hash = content_hash
            try:
                cached = client.get(f"/v1/security/check/{content_hash}")
                security_status = cached.get("security_status", "pass")
            except APIError as exc:
                if exc.status_code == 404:
                    # Cache miss -- need to scan
                    status.update("Running security scan...")
                    security_status, server_hash = _scan_package(
                        client, sandbox, content_hash, source, slug, version, skill_type
                    )
                    if server_hash:
                        pin_hash = server_hash
                else:
                    console.print(f"[red]Security check failed:[/red] {exc}")
                    raise typer.Exit(code=1)

            # Step 4: Check verdict
            if security_status == "block":
                console.print(f"[red]Skill '{slug}' blocked by security scan.[/red]")
                raise typer.Exit(code=1)

            if security_status == "warn":
                console.print(
                    f"[yellow]Warning: '{slug}' has "
                    "security warnings.[/yellow]"
                )

            # Step 5: Move to final location
            status.update(f"Installing {slug}...")
            install_base = base_dir if base_dir is not None else get_claude_dir()
            target_dir = "skills" if skill_type == "skill" else "agents"
            dest = install_base / target_dir / slug
            if dest.exists():
                shutil.rmtree(dest)
            dest.mkdir(parents=True, exist_ok=True)
            # External installers (e.g. npx clawhub install) often create a
            # slug-named subdirectory inside the sandbox. Copy from that inner
            # directory to avoid double-nesting (skills/slug/slug/SKILL.md).
            inner = Path(sandbox) / slug
            copy_src = str(inner) if inner.is_dir() else sandbox
            shutil.copytree(copy_src, str(dest), dirs_exist_ok=True)

            # Step 6: Save pin (using server-computed hash)
            pin_path = pins_path or str(Path.home() / ".agentpowers" / "pins.json")
            save_pin(
                slug, source, version, pin_hash,
                security_status, skill_type, pin_path,
                install_location=str(dest),
            )

            return str(dest)
    finally:
        shutil.rmtree(sandbox, ignore_errors=True)


def _scan_package(
    client: APIClient,
    sandbox_dir: str,
    content_hash: str,
    source: str,
    slug: str,
    version: str | None,
    skill_type: str,
) -> tuple[str, str]:
    """Package sandbox contents and upload for security scanning.

    Creates a ZIP archive of the sandbox directory and uploads it
    to the API's scan-package endpoint for full security analysis.

    Args:
        client: Configured APIClient (unused directly, kept for consistency).
        sandbox_dir: Path to the sandbox directory.
        content_hash: SHA-256 hash of the sandbox contents.
        source: External source name.
        slug: The skill slug.
        version: Optional version string.
        skill_type: Either "skill" or "agent".

    Returns:
        Tuple of (security_status, server_hash) where server_hash is the
        server-computed content hash from the scan response.

    Raises:
        typer.Exit: On upload or scan failure.
    """
    # Create ZIP of sandbox contents
    buf = io.BytesIO()
    sandbox_path = Path(sandbox_dir)
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for file_path in sorted(sandbox_path.rglob("*")):
            if file_path.is_file():
                arcname = str(file_path.relative_to(sandbox_path))
                zf.write(file_path, arcname)
    buf.seek(0)

    # Upload for scanning
    token = load_token()
    headers: dict[str, str] = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    try:
        with httpx.Client() as http:
            resp = http.post(
                f"{API_BASE_URL}/v1/security/scan-package",
                data={
                    "content_hash": content_hash,
                    "source": source,
                    "source_slug": slug,
                    "source_version": version or "",
                    "skill_type": skill_type,
                },
                files={"package": ("package.zip", buf, "application/zip")},
                headers=headers,
                timeout=120,
            )
            resp.raise_for_status()
            result = resp.json()
            return (
                result.get("security_status", "pass"),
                result.get("content_hash", ""),
            )
    except httpx.HTTPError as exc:
        console.print(f"[red]Security scan failed:[/red] {exc}")
        raise typer.Exit(code=1)
