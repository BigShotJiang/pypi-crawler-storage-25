"""Installer service for extracting skill/agent packages.

Handles ZIP extraction and placement into the correct tool config
directory structure (e.g. ~/.claude/skills/ or ~/.codex/skills/).
"""

from __future__ import annotations

import io
import os
import shutil
import stat
import zipfile
from pathlib import Path

# Maps --for <tool> values to their global config directory names.
# Extend this dict to add support for new tools.
SUPPORTED_TOOLS: dict[str, str] = {
    "claude-code": ".claude",
    "claude-desktop": ".claude",
    "codex": ".codex",
    "gemini": ".gemini",
    "kiro": ".kiro",
}


def get_tool_config_dir(tool: str = "claude-code") -> Path:
    """Return the global config directory for the given tool.

    Args:
        tool: Tool name — must be a key in SUPPORTED_TOOLS.

    Returns:
        Path to ~/<config-dir>.

    Raises:
        ValueError: If tool is not in SUPPORTED_TOOLS.
    """
    if tool not in SUPPORTED_TOOLS:
        supported = ", ".join(sorted(SUPPORTED_TOOLS))
        raise ValueError(
            f"Unknown tool '{tool}'. Supported tools: {supported}"
        )
    return Path.home() / SUPPORTED_TOOLS[tool]


def get_claude_dir() -> Path:
    """Return the path to the user's Claude configuration directory.

    Returns:
        Path to ~/.claude.
    """
    return get_tool_config_dir("claude-code")


def detect_install_base(
    force_global: bool = False,
    for_tool: str = "claude-code",
) -> Path:
    """Detect the appropriate install base directory.

    For tools that support project-local skills (claude-code,
    claude-desktop, gemini, kiro): if force_global is False and the
    tool's config directory exists in cwd, installs project-locally.
    Otherwise installs globally to the tool's config dir.

    Args:
        force_global: If True, always use the global config dir.
        for_tool: Tool to install for. Must be a key in SUPPORTED_TOOLS.

    Returns:
        Path to the config directory to install into.

    Raises:
        ValueError: If for_tool is not in SUPPORTED_TOOLS.
    """
    global_dir = get_tool_config_dir(for_tool)

    # Tools that support project-scoped skills
    project_local_tools = {"claude-code", "claude-desktop", "gemini", "kiro"}
    if for_tool in project_local_tools and not force_global:
        config_dir_name = SUPPORTED_TOOLS[for_tool]
        local = Path.cwd() / config_dir_name
        if local.exists():
            return local

    return global_dir


def extract_package(
    zip_data: bytes,
    slug: str,
    skill_type: str,
    base_dir: Path | None = None,
) -> Path:
    """Extract a ZIP package into the appropriate Claude subdirectory.

    Extracts the contents of a ZIP archive into either the skills/ or
    agents/ subdirectory under the Claude config dir. If the destination
    already exists, it is removed first to ensure a clean install.

    Args:
        zip_data: Raw bytes of the ZIP archive.
        slug: The skill or agent slug used as the directory name.
        skill_type: Either "skill" or "agent" to determine subdirectory.
        base_dir: Override for the base directory (defaults to ~/.claude).

    Returns:
        Path to the extracted package directory.
    """
    if base_dir is None:
        base_dir = get_claude_dir()

    subdir = "skills" if skill_type == "skill" else "agents"
    dest = base_dir / subdir / slug

    # Clean existing installation
    if dest.exists():
        shutil.rmtree(dest)

    dest.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(io.BytesIO(zip_data)) as zf:
        _safe_extractall(zf, dest)

    return dest


def _safe_extractall(zf: zipfile.ZipFile, dest: Path) -> None:
    """Extract all members from a ZIP archive with path traversal protection.

    Validates every member before extraction. Rejects:
    - Entries whose resolved path escapes the destination directory
    - Entries with absolute paths
    - Entries containing '..' components or backslash traversal
    - Symlinks and hardlinks

    Args:
        zf: An open ZipFile to extract from.
        dest: The target directory for extraction.

    Raises:
        ValueError: If any member fails validation.
    """
    dest_resolved = dest.resolve()

    for info in zf.infolist():
        # Reject symlinks (Unix external_attr encodes file type in upper 16 bits)
        if info.external_attr != 0:
            file_mode = info.external_attr >> 16
            if file_mode != 0 and stat.S_ISLNK(file_mode):
                raise ValueError(
                    f"Refusing to extract symlink entry: {info.filename!r}"
                )

        # Normalize backslashes to forward slashes for consistent checking
        normalized = info.filename.replace("\\", "/")

        # Reject absolute paths
        if os.path.isabs(normalized):
            raise ValueError(
                f"Blocked path traversal: absolute path in archive "
                f"member {info.filename!r}"
            )

        # Reject any '..' component
        if ".." in normalized.split("/"):
            raise ValueError(
                f"Blocked path traversal: '..' in archive "
                f"member {info.filename!r}"
            )

        # Final check: resolved path must be within dest
        target = (dest / normalized).resolve()
        if not str(target).startswith(str(dest_resolved)):
            raise ValueError(
                f"Blocked path traversal: {info.filename!r} resolves "
                f"outside destination directory"
            )

    # All members validated — now extract
    for info in zf.infolist():
        zf.extract(info, dest)
