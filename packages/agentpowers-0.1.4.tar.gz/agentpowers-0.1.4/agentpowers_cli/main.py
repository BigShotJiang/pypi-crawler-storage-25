"""AgentPowers CLI — discover, install, and publish marketplace skills."""

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _pkg_version

import typer

from agentpowers_cli.commands import (
    auth,
    claim,
    detail,
    install,
    profile,
    publish,
    republish,
    scan,
    search,
    status,
    uninstall,
    unpublish,
    update,
    verify,
)


def _get_version() -> str:
    try:
        return _pkg_version("agentpowers")
    except PackageNotFoundError:
        return "dev"


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"agentpowers {_get_version()}")
        raise typer.Exit()


app = typer.Typer(
    name="ap",
    no_args_is_help=True,
)


@app.callback()
def main(
    version: bool = typer.Option(  # noqa: ARG001
        False, "--version", "-V", help="Show version and exit.",
        callback=_version_callback, is_eager=True,
    ),
) -> None:
    """AgentPowers — marketplace for Claude Code skills and agents."""

app.command(name="login")(auth.login)
app.command(name="logout")(auth.logout)
app.command(name="whoami")(auth.whoami)
app.command(name="search")(search.search)
app.command(name="detail")(detail.detail)
app.command(name="install")(install.install)
app.command(name="profile")(profile.profile)
app.command(name="publish")(publish.publish)
app.command(name="republish")(republish.republish)
app.command(name="claim")(claim.claim)
app.command(name="scan")(scan.scan)
app.command(name="status")(status.status)
app.command(name="uninstall")(uninstall.uninstall)
app.command(name="unpublish")(unpublish.unpublish)
app.command(name="update")(update.update)
app.command(name="verify")(verify.verify)

if __name__ == "__main__":
    app()
