"""Uninstall command for the AgentPowers CLI.

Removes installed skills or agents from the Claude configuration
directory and cleans up install metadata.
"""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import typer
from rich.console import Console

from agentpowers_cli.services.installer import get_claude_dir
from agentpowers_cli.services.pin_manager import DEFAULT_PINS_PATH

console = Console()


def _remove_pin(slug: str, pins_path: str) -> bool:
    """Remove a pin entry for a slug from pins.json.

    Args:
        slug: The skill/agent slug to remove.
        pins_path: Path to the pins JSON file.

    Returns:
        True if a pin was removed, False if no pin existed.
    """
    path = Path(pins_path)
    if not path.exists():
        return False
    try:
        pins = json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return False
    if slug not in pins:
        return False
    del pins[slug]
    path.write_text(json.dumps(pins, indent=2))
    return True


def uninstall(
    slug: str = typer.Argument(help="Skill or agent slug to remove"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation prompt"),
) -> None:
    """Remove an installed skill or agent.

    Deletes the skill/agent directory from ~/.claude/skills/ or
    ~/.claude/agents/ and removes its install metadata.
    """
    from agentpowers_cli.commands import validate_slug
    slug = validate_slug(slug)

    claude_dir = get_claude_dir()
    skill_dir = claude_dir / "skills" / slug
    agent_dir = claude_dir / "agents" / slug

    found_dirs: list[Path] = []
    if skill_dir.exists():
        found_dirs.append(skill_dir)
    if agent_dir.exists():
        found_dirs.append(agent_dir)

    # Check if pin exists (even if dir already deleted)
    pins_path_str = DEFAULT_PINS_PATH
    pin_path = Path(pins_path_str)
    has_pin = False
    if pin_path.exists():
        try:
            pins = json.loads(pin_path.read_text())
            has_pin = slug in pins
        except (json.JSONDecodeError, OSError):
            pass

    if not found_dirs and not has_pin:
        console.print(f"[red]'{slug}' not found. Not installed.[/red]")
        raise typer.Exit(code=1)

    if not force:
        locations = (
            ", ".join(str(d) for d in found_dirs)
            if found_dirs
            else "metadata only"
        )
        confirm = typer.confirm(f"Remove '{slug}' ({locations})?")
        if not confirm:
            console.print("Aborted.")
            return

    with console.status(f"Removing {slug}...", spinner="dots"):
        for d in found_dirs:
            shutil.rmtree(d)
        _remove_pin(slug, pins_path_str)

    console.print(f"[green]Uninstalled '{slug}'.[/green]")
