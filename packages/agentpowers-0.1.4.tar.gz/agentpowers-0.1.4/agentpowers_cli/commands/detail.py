"""Detail command for the AgentPowers CLI.

Provides a detail command that fetches and displays detailed information
about a skill from the marketplace API in a Rich panel. Optionally runs
a full security scan with detailed findings via --scan.
"""

from __future__ import annotations

import shutil

import typer
from rich.console import Console
from rich.panel import Panel

from agentpowers_cli.commands.scan import (
    _download_to_sandbox,
    _format_status,
    _resolve_source,
    _upload_for_scan,
)
from agentpowers_cli.services.api_client import APIClient, APIError

console = Console()


def get_api_client() -> APIClient:
    """Create and return an APIClient instance.

    Returns:
        A configured APIClient.
    """
    return APIClient()


def _format_price(price_cents: int) -> str:
    """Format a price in cents for display.

    Args:
        price_cents: Price in cents (0 means free).

    Returns:
        Formatted price string, e.g. "Free" or "$12.00".
    """
    if price_cents == 0:
        return "Free"
    return f"${price_cents / 100:.2f}"


def _format_security(status: str | None) -> str:
    """Format a security status with Rich color markup.

    Args:
        status: The security status string (pass, warn, block), or None.

    Returns:
        Rich-formatted security status string.
    """
    if not status:
        return "not scanned"
    s = status.lower()
    if s == "pass":
        return "[green]pass[/green]"
    if s == "warn":
        return "[yellow]warn[/yellow]"
    if s == "block":
        return "[red]block[/red]"
    return status


def _severity_style(severity: str) -> str:
    """Return Rich style for a severity level."""
    s = severity.upper()
    if s == "HIGH":
        return "bold red"
    if s == "MEDIUM":
        return "bold yellow"
    if s == "LOW":
        return "dim yellow"
    return "dim"


def _render_finding_card(finding: dict) -> Panel:
    """Render a single finding as a Rich Panel with code context.

    Args:
        finding: Enriched finding dict with optional file, line,
            context, and explanation fields.

    Returns:
        Rich Panel ready for console.print().
    """
    severity = finding.get("severity", "INFO")
    detail_text = finding.get("detail", "") or finding.get("description", "")
    file_name = finding.get("file", "")
    line_num = finding.get("line")
    context = finding.get("context", [])
    explanation = finding.get("explanation", "")
    match_text = finding.get("match", "")

    # Clean up verbose VirusTotal analysis IDs
    if "did not complete within" in detail_text:
        detail_text = "VirusTotal analysis timed out (non-blocking)"

    lines: list[str] = []

    # Severity + detail header
    sev_style = _severity_style(severity)
    lines.append(f"  [{sev_style}]{severity}[/{sev_style}]  {detail_text}")
    lines.append("")

    # Code context (if available)
    if context:
        for ctx_line in context:
            ln = ctx_line.get("line", 0)
            text = ctx_line.get("text", "")
            highlight = ctx_line.get("highlight", False)
            if highlight:
                lines.append(f"  [bold red]> {ln:>4} [/bold red]| [bold]{text}[/bold]")
            else:
                lines.append(f"   {ln:>4} | {text}")
        lines.append("")
    elif line_num:
        lines.append(f"  Line {line_num}")
        lines.append("")

    # Matched text
    if match_text:
        lines.append(f"  [dim]Matched:[/dim] [bold]{match_text}[/bold]")

    # Explanation
    if explanation:
        lines.append(f"  [dim]Why:[/dim] {explanation}")

    # Panel title is filename or category
    title = file_name if file_name else finding.get("category", "Finding")

    border_color = (
        "red" if severity == "HIGH"
        else "yellow" if severity == "MEDIUM"
        else "dim"
    )

    return Panel(
        "\n".join(lines),
        title=title,
        border_style=border_color,
        padding=(0, 1),
    )


def _display_detailed_results(slug: str, source: str, result: dict) -> None:
    """Render detailed scan results with per-finding cards.

    Args:
        slug: Skill slug.
        source: Source name.
        result: Server response from scan-package.
    """
    status_str = result.get("security_status", "unknown")
    score = result.get("security_score", 0)
    layers = result.get("layers", [])

    # Summary header
    border = (
        "green" if status_str == "pass"
        else "yellow" if status_str == "warn"
        else "red"
    )
    summary = (
        f"Skill: [bold]{slug}[/bold]  Source: {source}\n"
        f"Status: {_format_status(status_str)}  Score: {score}/10"
    )
    console.print(Panel(summary, title="Security Scan Summary", border_style=border))
    console.print()

    # Collect all findings with detail from layers (preferred) or flat findings
    all_findings: list[dict] = []
    if layers:
        for layer in layers:
            layer_findings = layer.get("findings", [])
            all_findings.extend(layer_findings)
    else:
        all_findings = result.get("findings", [])

    # If no findings at all
    if not all_findings:
        console.print(
            "[green]No security findings.[/green] This skill passed all checks."
        )
        return

    # Group findings by file
    by_file: dict[str, list[dict]] = {}
    no_file: list[dict] = []
    for f in all_findings:
        fname = f.get("file", "")
        if fname:
            by_file.setdefault(fname, []).append(f)
        else:
            no_file.append(f)

    # Render findings grouped by file
    for fname, findings in sorted(by_file.items()):
        for finding in findings:
            console.print(_render_finding_card(finding))
            console.print()

    # Render findings without file association
    for finding in no_file:
        console.print(_render_finding_card(finding))
        console.print()

    # Actionable guidance
    if status_str == "pass":
        console.print(
            "[green]Safe to install.[/green] Run: "
            f"[bold]ap install {slug} --source {source}[/bold]"
        )
    elif status_str == "warn":
        console.print(
            "[yellow]Warnings detected.[/yellow] "
            "Review the findings above before installing."
        )
        console.print(
            f"To install anyway: [bold]ap install {slug} --source {source}[/bold]"
        )
    elif status_str == "block":
        console.print(
            "[red]Blocked.[/red] "
            "This skill failed security checks and "
            "cannot be installed."
        )
        console.print(
            "If you believe this is a false positive, report it to the skill author."
        )


def detail(
    slug: str = typer.Argument(..., help="Skill slug to get details for"),
    source: str | None = typer.Option(
        None, "--source", "-s", help="Filter by source (e.g. clawhub)"
    ),
    scan: bool = typer.Option(
        False, "--scan", help="Run a full security scan and show detailed findings"
    ),
) -> None:
    """Show detailed information about a skill.

    By default, displays metadata from the API. Use --scan to download,
    run the security pipeline, and show per-finding detail cards.
    """
    from agentpowers_cli.commands import validate_slug
    slug = validate_slug(slug)

    client = get_api_client()

    params = {}
    if source:
        params["source"] = source

    with console.status("Fetching details...", spinner="dots"):
        try:
            data = client.get(f"/v1/detail/{slug}", params=params)
        except APIError as exc:
            if exc.status_code == 404:
                console.print(f"[red]Error:[/red] Skill '{slug}' not found.")
            else:
                console.print(f"[red]Error:[/red] {exc}")
            raise typer.Exit(code=1)

    # Build the panel content
    lines: list[str] = []
    na = "--"

    # Title
    title = data.get("title", slug)

    # Row 1: Author, Version, Category, Type, Source
    author = data.get("author_display_name") or data.get("author_github") or na
    version = data.get("version") or na
    category = data.get("category") or na
    skill_type = data.get("type") or na
    src = data.get("source") or na
    lines.append(
        f"[bold]Author:[/bold] {author}  "
        f"[bold]Version:[/bold] {version}  "
        f"[bold]Category:[/bold] {category}  "
        f"[bold]Type:[/bold] {skill_type}  "
        f"[bold]Source:[/bold] {src}"
    )

    # Row 2: Security, Price
    security = data.get("security_status") or data.get("ap_security_status")
    lines.append(
        f"[bold]Security:[/bold] {_format_security(security)}  "
        f"[bold]Price:[/bold] {_format_price(data.get('price_cents', 0))}"
    )

    # Description
    desc = data.get("long_description") or data.get("description") or na
    lines.append("")
    lines.append(desc)

    # Rating
    rating_avg = data.get("rating_average")
    rating_count = data.get("rating_count", 0)
    if rating_avg is not None:
        full = int(round(rating_avg))
        stars_display = f"{'★' * full}{'☆' * (5 - full)}"
        lines.append("")
        lines.append(
            f"[bold]Rating:[/bold] {stars_display} "
            f"{rating_avg}/5 ({rating_count} "
            f"review{'s' if rating_count != 1 else ''})"
        )

    # Stats: Downloads, Views, Installs, Stars
    dl = (
        data.get("download_count")
        if data.get("download_count") is not None
        else data.get("source_downloads")
    )
    view_count = data.get("view_count")
    install_count = data.get("install_count")
    installs = data.get("source_installs")
    stars = data.get("source_stars")
    lines.append("")
    stat_parts = [f"Downloads: {dl if dl is not None else na}"]
    if view_count is not None and view_count > 0:
        stat_parts.append(f"Views: {view_count}")
    if install_count is not None and install_count > 0:
        stat_parts.append(f"Installs: {install_count}")
    if installs is not None:
        stat_parts.append(f"Source Installs: {installs}")
    if stars is not None:
        stat_parts.append(f"Stars: {stars}")
    lines.append(f"[bold]Stats:[/bold] {'  |  '.join(stat_parts)}")

    # Platforms
    platforms = ", ".join(data["platforms"]) if data.get("platforms") else na
    lines.append(f"[bold]Platforms:[/bold] {platforms}")

    # URL
    url = data.get("source_url") or na
    lines.append(f"[bold]URL:[/bold] {url}")

    content = "\n".join(lines)
    console.print(
        Panel(
            content,
            title=f"[bold]{title}[/bold]",
            border_style="cyan",
            padding=(1, 2),
        )
    )

    # If --scan flag, run full security scan with detailed findings
    if scan:
        scan_source = source
        if not scan_source:
            with console.status("Resolving source...", spinner="dots"):
                scan_source = _resolve_source(client, slug)
            if not scan_source:
                console.print(
                    f"[red]Skill '{slug}' not found in any external source.[/red]"
                )
                raise typer.Exit(code=1)

        sandbox = None
        try:
            with console.status(
                f"Downloading {slug} from {scan_source}...", spinner="dots"
            ) as status:
                try:
                    sandbox, _ = _download_to_sandbox(slug, scan_source)
                except RuntimeError as exc:
                    console.print(f"[red]Download failed:[/red] {exc}")
                    raise typer.Exit(code=1)

                status.update("Running security scan...")
                try:
                    result = _upload_for_scan(
                        sandbox, scan_source, slug, skill_type
                    )
                except RuntimeError as exc:
                    console.print(f"[red]Scan failed:[/red] {exc}")
                    raise typer.Exit(code=1)

            console.print()
            _display_detailed_results(slug, scan_source, result)

            if result.get("security_status") == "block":
                raise typer.Exit(code=1)

        finally:
            if sandbox:
                shutil.rmtree(sandbox, ignore_errors=True)
