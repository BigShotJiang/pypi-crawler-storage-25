"""Install command for the AgentPowers CLI.

Downloads and installs skills or agents from the AgentPowers marketplace.
Supports free skills, paid skills with license codes, security status
checks, and external source installations (e.g. ClawHub).
"""

from __future__ import annotations

import socket
from pathlib import Path

import httpx
import typer
from rich.console import Console

from agentpowers_cli.services.api_client import APIClient, APIError
from agentpowers_cli.services.content_hasher import hash_directory
from agentpowers_cli.services.installer import (
    SUPPORTED_TOOLS,
    detect_install_base,
    extract_package,
)
from agentpowers_cli.services.pin_manager import save_pin

console = Console()


def _parse_slug(raw: str) -> tuple[str | None, str]:
    """Split 'author/slug' into (author, slug) or (None, slug).

    Only a single slash is allowed. Multiple slashes are rejected.

    Args:
        raw: Raw slug string, optionally prefixed with 'author/'.

    Returns:
        Tuple of (author, slug) where author is None if not present.

    Raises:
        typer.BadParameter: If multiple slashes are present.
    """
    if raw.count("/") > 1:
        raise typer.BadParameter(
            f"Invalid slug format '{raw}'. Expected 'slug' or 'author/slug'.",
            param_hint="'SLUG'",
        )
    if "/" in raw:
        author, _, slug = raw.partition("/")
        return author or None, slug
    return None, raw


def _record_installation(
    client: APIClient,
    slug: str,
    platform: str,
    source: str,
) -> None:
    """Fire-and-forget tracking call. Swallows all errors."""
    try:
        hostname = socket.gethostname()
        client.record_installation(slug, platform, source, hostname)
    except Exception:
        pass


def get_api_client() -> APIClient:
    """Create and return an APIClient instance.

    Returns:
        A configured APIClient.
    """
    return APIClient()


def install_from_url(
    url: str,
    slug: str,
    skill_type: str,
    base_dir: Path | None = None,
) -> str:
    """Download a ZIP from a URL and extract it locally.

    Args:
        url: The download URL for the ZIP package.
        slug: The skill or agent slug.
        skill_type: Either "skill" or "agent".
        base_dir: Override for the base .claude directory.

    Returns:
        String path to the installed directory.

    Raises:
        typer.Exit: If the download fails.
    """
    with console.status(f"Downloading '{slug}'...", spinner="dots") as status:
        try:
            with httpx.Client() as client:
                response = client.get(url)
                response.raise_for_status()
        except httpx.HTTPError as exc:
            console.print(f"[red]Download failed:[/red] {exc}")
            raise typer.Exit(code=1)

        status.update(f"Installing '{slug}'...")
        dest = extract_package(response.content, slug, skill_type, base_dir=base_dir)
    return str(dest)


def install_external_skill(
    client: APIClient,
    slug: str,
    source: str,
    skill_type: str = "skill",
    version: str | None = None,
    pins_path: str | None = None,
    base_dir: Path | None = None,
) -> str:
    """Wrapper that delegates to external_installer module.

    This function exists at module level so tests can patch it at
    ``src.commands.install.install_external_skill``.

    Args:
        client: Configured APIClient instance.
        slug: The skill slug to install.
        source: External source name (e.g. "clawhub").
        skill_type: Either "skill" or "agent".
        version: Optional version string.
        pins_path: Override path for pins.json.
        base_dir: Override for the base .claude directory.

    Returns:
        Path to the installed directory.
    """
    from agentpowers_cli.services.external_installer import (
        install_external_skill as _install_external,
    )

    return _install_external(
        client, slug, source, skill_type, version, pins_path, base_dir
    )


def _search_external_sources(client: APIClient, slug: str) -> list[dict]:
    """Search external sources for an exact slug match.

    Args:
        client: Configured APIClient instance.
        slug: The skill slug to search for.

    Returns:
        List of matching external items with their source name.
    """
    try:
        data = client.get("/v1/search", params={"q": slug, "limit": 50})
    except APIError:
        return []

    matches = []
    for source_name, section in data.items():
        if source_name == "agentpowers":
            continue
        for item in section.get("items", []):
            if item.get("slug") == slug:
                matches.append({**item, "source": source_name})
    return matches


def _prompt_source_choice(matches: list[dict], slug: str) -> dict | None:
    """Prompt user to choose between multiple source matches.

    Args:
        matches: List of matching items from different sources.
        slug: The skill slug.

    Returns:
        The chosen item dict, or None if user cancels.
    """
    console.print(f"\n'{slug}' found in multiple sources:\n")
    for i, item in enumerate(matches, 1):
        source = item.get("source", "unknown")
        installs = item.get("source_installs", 0)
        version = item.get("version", "?")
        title = item.get("title", slug)
        console.print(
            f"  [bold]{i}.[/bold] [cyan]{title}[/cyan] "
            f"from [yellow]{source}[/yellow] "
            f"(v{version}, {installs} installs)"
        )

    console.print()
    choice = typer.prompt("Choose a source (number)", type=int)
    if choice < 1 or choice > len(matches):
        console.print("[red]Invalid choice.[/red]")
        return None
    return matches[choice - 1]


def install(
    slug: str = typer.Argument(help="Skill or agent slug (supports author/slug format)"),
    code: str | None = typer.Option(None, "--code", help="License code"),
    source: str | None = typer.Option(
        None, "--source", help="External source (e.g. clawhub)"
    ),
    global_: bool = typer.Option(
        False, "--global", help="Install globally to the tool's config dir"
    ),
    for_tool: str = typer.Option(
        "claude-code",
        "--for",
        help=(
            "Target AI tool to install for. "
            f"Supported: {', '.join(sorted(SUPPORTED_TOOLS))}. "
            "Default: claude-code."
        ),
    ),
) -> None:
    """Install a skill or agent from the AgentPowers marketplace.

    Supports author/slug format (e.g. 'clerk/my-skill') to resolve skills
    by seller. For claude-code, installs to <cwd>/.claude/skills/ when a
    .claude/ directory exists, otherwise to ~/.claude/skills/. Use --global
    to force the global config dir.

    Use --for to target a different AI tool (e.g. --for codex installs to
    ~/.codex/skills/).

    If no --source is specified and the skill isn't found natively,
    searches external sources automatically. If found in exactly one
    source, installs from there. If found in multiple, prompts to choose.
    """
    if for_tool not in SUPPORTED_TOOLS:
        supported = ", ".join(sorted(SUPPORTED_TOOLS))
        raise typer.BadParameter(
            f"Unknown tool '{for_tool}'. Supported tools: {supported}",
            param_hint="'--for'",
        )
    client = get_api_client()
    author, slug = _parse_slug(slug)

    from agentpowers_cli.commands import validate_slug
    slug = validate_slug(slug)
    if author is not None:
        author = author.strip()
        if not author:
            console.print("[red]Author name cannot be empty.[/red]")
            raise typer.Exit(code=1)
    base_dir = detect_install_base(global_, for_tool=for_tool)

    # If author/slug given, resolve via seller endpoint
    if author:
        with console.status(f"Looking up '{author}/{slug}'...", spinner="dots"):
            try:
                data = client.get(f"/v1/sellers/{author}/skills")
                items = data.get("items", [])
                skill: dict | None = next(
                    (s for s in items if s.get("slug") == slug), None
                )
            except APIError as exc:
                console.print(f"[red]Seller '{author}' not found:[/red] {exc}")
                raise typer.Exit(code=1)
        if skill is None:
            console.print(
                f"[red]Skill '{slug}' not found for seller '{author}'.[/red]"
            )
            raise typer.Exit(code=1)
        _install_native(client, skill, slug, code, base_dir)
        return

    # If --source explicitly given, go straight to external install
    if source:
        with console.status(f"Looking up '{slug}'...", spinner="dots"):
            try:
                skill = client.get(f"/v1/skills/{slug}")
            except APIError:
                skill = None

        if skill and skill.get("source", "agentpowers") != "agentpowers":
            source = source or skill.get("source", source)

        dest = install_external_skill(client, slug, source, base_dir=base_dir)
        _record_installation(client, slug, "cli", source)
        console.print(f"[green]Installed '{slug}' to {dest}[/green]")
        return

    # Try native AgentPowers first
    with console.status(f"Searching for '{slug}'...", spinner="dots"):
        try:
            skill = client.get(f"/v1/skills/{slug}")
        except APIError as exc:
            if exc.status_code != 404:
                console.print(f"[red]Error:[/red] {exc}")
                raise typer.Exit(code=1)
            skill = None

    # If found natively and it's an external-sourced skill, route to external
    if skill and skill.get("source", "agentpowers") != "agentpowers":
        skill_source = skill.get("source", "")
        dest = install_external_skill(
            client,
            slug,
            skill_source,
            skill.get("type", "skill"),
            version=skill.get("version"),
            base_dir=base_dir,
        )
        _record_installation(client, slug, "cli", skill_source)
        console.print(f"[green]Installed '{slug}' to {dest}[/green]")
        return

    # If found natively as an AgentPowers skill, install normally
    if skill:
        _install_native(client, skill, slug, code, base_dir)
        return

    # Not found natively — search external sources
    with console.status("Searching other sources...", spinner="dots"):
        matches = _search_external_sources(client, slug)

    if not matches:
        console.print(f"[red]Skill '{slug}' not found in any source.[/red]")
        raise typer.Exit(code=1)

    if len(matches) == 1:
        match = matches[0]
        match_source = match["source"]
        console.print(
            f"Found on [yellow]{match_source}[/yellow]: "
            f"[cyan]{match.get('title', slug)}[/cyan] "
            f"(v{match.get('version', '?')}, "
            f"{match.get('source_installs', 0)} installs)"
        )
        dest = install_external_skill(client, slug, match_source, base_dir=base_dir)
        _record_installation(client, slug, "cli", match_source)
        console.print(f"[green]Installed '{slug}' to {dest}[/green]")
        return

    # Multiple sources — prompt user
    chosen = _prompt_source_choice(matches, slug)
    if chosen is None:
        raise typer.Exit(code=1)
    chosen_source = chosen["source"]
    dest = install_external_skill(client, slug, chosen_source, base_dir=base_dir)
    _record_installation(client, slug, "cli", chosen_source)
    console.print(f"[green]Installed '{slug}' to {dest}[/green]")


def _install_native(
    client: APIClient,
    skill: dict,
    slug: str,
    code: str | None,
    base_dir: Path | None = None,
) -> None:
    """Install a native AgentPowers skill.

    Args:
        client: Configured APIClient instance.
        skill: Skill metadata dict from the API.
        slug: The skill slug.
        code: Optional license code for paid skills.
        base_dir: Override for the base .claude directory.
    """
    security_status = skill.get("security_status", "pass")
    if security_status == "block":
        console.print(
            f"[red]Skill '{slug}' has been blocked due to security concerns.[/red]"
        )
        raise typer.Exit(code=1)

    if code is not None:
        try:
            client.post(
                "/v1/purchases/redeem",
                json_data={"license_code": code},
                auth=True,
            )
        except APIError as exc:
            console.print(f"[red]Failed to redeem license code:[/red] {exc}")
            raise typer.Exit(code=1)

    price_cents = skill.get("price_cents", 0)
    try:
        download_info = client.get(
            f"/v1/skills/{slug}/download",
            auth=(price_cents > 0),
        )
    except APIError as exc:
        console.print(f"[red]Download failed:[/red] {exc}")
        raise typer.Exit(code=1)

    skill_type = skill.get("type", "skill")
    download_url = download_info.get("url", "")
    dest = install_from_url(download_url, slug, skill_type, base_dir=base_dir)

    content_hash = hash_directory(dest)
    save_pin(
        slug=slug,
        source="agentpowers",
        version=skill.get("version"),
        content_hash=content_hash,
        security_status=security_status,
        skill_type=skill_type,
        install_location=dest,
    )

    _record_installation(client, slug, "cli", "agentpowers")
    console.print(f"[green]Installed '{slug}' to {dest}[/green]")
