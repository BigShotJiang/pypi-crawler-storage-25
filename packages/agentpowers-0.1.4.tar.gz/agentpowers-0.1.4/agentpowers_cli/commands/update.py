"""Update command for the AgentPowers CLI.

Checks installed skills for newer versions and re-downloads them.
Detects locally edited skills and skips them to avoid overwriting changes.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import httpx
import typer
from rich.console import Console

from agentpowers_cli.commands.install import install_external_skill
from agentpowers_cli.services.api_client import APIClient, APIError
from agentpowers_cli.services.installer import extract_package
from agentpowers_cli.services.pin_manager import (
    DEFAULT_PINS_PATH,
    load_pins,
    save_pin,
)

console = Console()


def get_api_client() -> APIClient:
    """Create and return an APIClient instance."""
    return APIClient()


def _compare_versions(installed: str, latest: str) -> bool:
    """Return True if installed version is behind latest.

    Simple semver comparison: splits on dots and compares tuples.
    """
    try:
        inst = tuple(int(x) for x in installed.split("."))
        lat = tuple(int(x) for x in latest.split("."))
        return inst < lat
    except (ValueError, AttributeError):
        return False


def _compute_content_hash(install_dir: Path) -> str | None:
    """Compute SHA-256 hash of installed files for edit detection.

    Returns None if the directory doesn't exist or hash computation fails.
    """
    if not install_dir.exists():
        return None

    try:
        from agentpowers_cli.services.content_hasher import hash_directory
        return hash_directory(str(install_dir))
    except (ImportError, Exception):
        return None


def _check_edited(slug: str, pins: dict, pins_path: str) -> bool:
    """Check if an installed skill has been locally edited.

    Returns True if the content hash doesn't match the pinned hash.
    """
    pin = pins.get(slug)
    if not pin:
        return False

    pinned_hash = pin.get("content_hash")
    if not pinned_hash:
        return False

    # Determine install directory
    _source = pin.get("source", "agentpowers")
    pin_type = pin.get("type", "skill")
    claude_dir = Path.home() / ".claude"
    # Check pin type first, then fall back to scanning both dirs
    preferred_subdir = "agents" if pin_type == "agent" else "skills"
    search_order = [preferred_subdir] + [
        d for d in ("skills", "agents") if d != preferred_subdir
    ]
    for subdir in search_order:
        install_dir = claude_dir / subdir / slug
        if install_dir.exists():
            current_hash = _compute_content_hash(install_dir)
            if current_hash is not None:
                return current_hash != pinned_hash
    return False


def _fix_stale_pin(
    slug: str, pin: dict | None, detail: dict, pins_path: str
) -> None:
    """Rehash installed directory and fix pin if hash is stale.

    When a skill is up-to-date but the pin hash doesn't match disk,
    save a corrected pin to prevent false "Edited" detection in search.
    """
    if not pin:
        return

    pinned_hash = pin.get("content_hash")
    if not pinned_hash:
        return

    # Find the install directory
    claude_dir = Path.home() / ".claude"
    for subdir in ("skills", "agents"):
        install_dir = claude_dir / subdir / slug
        if install_dir.exists():
            current_hash = _compute_content_hash(install_dir)
            if current_hash and current_hash != pinned_hash:
                save_pin(
                    slug=slug,
                    source=pin.get("source", "agentpowers"),
                    version=pin.get("version"),
                    content_hash=current_hash,
                    security_status=detail.get("security_status", "pending"),
                    skill_type=pin.get("type", "skill"),
                    pins_path=pins_path,
                )
            break


def _download_and_install(
    client: APIClient, slug: str, skill_type: str = "skill"
) -> tuple[str, bytes]:
    """Download a skill package and extract it.

    Returns:
        Tuple of (destination path string, raw zip bytes).
    """
    download_info = client.get(f"/v1/skills/{slug}/download")
    url = download_info.get("url", "")

    with httpx.Client() as http:
        response = http.get(url)
        response.raise_for_status()

    zip_data = response.content
    dest = extract_package(zip_data, slug, skill_type)
    return str(dest), zip_data


def _update_single(
    client: APIClient,
    slug: str,
    pins: dict,
    pins_path: str,
    force: bool = False,
) -> str:
    """Update a single skill. Returns a status message.

    Raises:
        typer.Exit: On fatal errors.
    """
    pin = pins.get(slug)
    if not pin:
        # Check filesystem too
        claude_dir = Path.home() / ".claude"
        found = False
        for subdir in ("skills", "agents"):
            if (claude_dir / subdir / slug).exists():
                found = True
                break
        if not found:
            console.print(
                f"[red]'{slug}' is not installed. "
                f"Run `ap install {slug}` first.[/red]"
            )
            raise typer.Exit(code=1)

    # Check for external source — route through external update flow
    if pin and pin.get("source", "agentpowers") != "agentpowers":
        source = pin.get("source", "unknown")
        is_edited = _check_edited(slug, pins, pins_path)

        # Fetch latest version from external source
        try:
            detail = client.get(f"/v1/detail/{slug}", params={"source": source})
        except APIError as exc:
            if exc.status_code == 404:
                console.print(f"[red]'{slug}' not found on {source}.[/red]")
                raise typer.Exit(code=1)
            raise

        latest_version = detail.get("version")
        installed_version = pin.get("version")

        # Can only compare when both versions are available
        if not latest_version or not installed_version:
            ver_display = f"v{installed_version}" if installed_version else "installed"
            console.print(
                f"[dim]{slug} is already up to date ({ver_display})[/dim]"
            )
            _fix_stale_pin(slug, pin, detail, pins_path)
            return "up_to_date"

        if not _compare_versions(installed_version, latest_version):
            if is_edited:
                # Same version but locally edited — warn user
                if not force:
                    console.print(
                        f"[yellow]{slug} has been locally edited.[/yellow]"
                    )
                    if not typer.confirm(
                        f"Restore {slug} to original? "
                        "Local changes will be overwritten",
                        default=False,
                    ):
                        console.print(f"Skipping {slug}.")
                        return "edited"
                # force=True or user confirmed — re-install to restore original
            else:
                console.print(
                    f"[dim]{slug} is already up to date (v{installed_version})[/dim]"
                )
                _fix_stale_pin(slug, pin, detail, pins_path)
                return "up_to_date"
        elif is_edited and not force:
            # Skill is behind AND edited — confirm before overwriting
            console.print(
                f"[yellow]{slug} has been locally edited.[/yellow]"
            )
            if not typer.confirm(
                f"Update {slug} anyway? Local changes will be overwritten",
                default=False,
            ):
                console.print(f"Skipping {slug}.")
                return "edited"

        # Re-install via external installer
        skill_type = detail.get("type", "skill")
        install_external_skill(
            client, slug, source, skill_type,
            latest_version, pins_path,
        )

        if installed_version == latest_version:
            console.print(
                f"[green]Restored {slug} "
                f"v{latest_version} to original.[/green]"
            )
        else:
            console.print(
                f"[green]Updated {slug} from v{installed_version} "
                f"to v{latest_version}[/green]"
            )
        return "updated"

    # Check for local edits
    is_edited = _check_edited(slug, pins, pins_path)

    # Fetch latest version from API
    try:
        detail = client.get(f"/v1/detail/{slug}")
    except APIError as exc:
        if exc.status_code == 404:
            console.print(f"[red]'{slug}' not found on AgentPowers.[/red]")
            raise typer.Exit(code=1)
        raise

    latest_version = detail.get("version", "0.0.0")
    installed_version = pin.get("version", "0.0.0") if pin else "0.0.0"

    if not _compare_versions(installed_version, latest_version):
        if is_edited:
            # Same version but locally edited — warn user
            if not force:
                console.print(
                    f"[yellow]{slug} has been locally edited.[/yellow]"
                )
                if not typer.confirm(
                    f"Restore {slug} to original? Local changes will be overwritten",
                    default=False,
                ):
                    console.print(f"Skipping {slug}.")
                    return "edited"
            # force=True or user confirmed — re-download to restore original
        else:
            console.print(
                f"[dim]{slug} is already up to date (v{installed_version})[/dim]"
            )
            _fix_stale_pin(slug, pin, detail, pins_path)
            return "up_to_date"

    # Skill is behind — but check if edited
    if is_edited and not force:
        console.print(
            f"[yellow]{slug} has been locally edited.[/yellow]"
        )
        if not typer.confirm(
            f"Update {slug} anyway? Local changes will be overwritten",
            default=False,
        ):
            console.print(f"Skipping {slug}.")
            return "edited"

    # Check security status
    security_status = detail.get("security_status", "pending")
    if security_status == "block":
        console.print(
            f"[red]{slug} v{latest_version} is blocked by security. "
            f"Keeping v{installed_version}.[/red]"
        )
        return "blocked"

    # Download and install
    skill_type = detail.get("type", "skill")
    try:
        dest, zip_data = _download_and_install(client, slug, skill_type)
    except APIError as exc:
        if exc.status_code == 403:
            console.print(
                f"[yellow]'{slug}' requires purchase. "
                "Visit agentpowers.ai to buy.[/yellow]"
            )
            raise typer.Exit(code=1)
        console.print(f"[red]Failed to update {slug}:[/red] {exc}")
        return "failed"
    except httpx.HTTPError as exc:
        console.print(f"[red]Download failed for {slug}:[/red] {exc}")
        return "failed"

    # Compute content hash from installed directory (not zip bytes)
    # so that edit detection via hash_directory() will match
    from agentpowers_cli.services.content_hasher import hash_directory
    content_hash = hash_directory(dest)

    save_pin(
        slug=slug,
        source="agentpowers",
        version=latest_version,
        content_hash=content_hash,
        security_status=security_status,
        skill_type=skill_type,
        pins_path=pins_path,
    )

    if installed_version == latest_version:
        console.print(f"[green]Restored {slug} v{latest_version} to original.[/green]")
    else:
        console.print(
            f"[green]Updated {slug} from v{installed_version} "
            f"to v{latest_version}[/green]"
        )
    return "updated"


def update(
    slug: str | None = typer.Argument(
        default=None, help="Skill slug to update (omit to update all)"
    ),
    force: bool = typer.Option(
        False, "--force", "-f", help="Skip confirmation prompt"
    ),
    pins_path: str = typer.Option(
        DEFAULT_PINS_PATH, hidden=True,
    ),
) -> None:
    """Update installed skills to their latest versions.

    If a slug is provided, updates just that skill. Otherwise checks
    all installed AgentPowers skills for updates.
    """
    client = get_api_client()

    if slug:
        from agentpowers_cli.commands import validate_slug
        slug = validate_slug(slug)
        # Single skill update
        pins = load_pins(pins_path)
        with console.status(f"Checking for updates to '{slug}'...", spinner="dots"):
            _update_single(client, slug, pins, pins_path, force)
        return

    # Update all — includes both native and external pins
    pins = load_pins(pins_path)

    if not pins:
        console.print("No skills installed to update.")
        return

    # Check each skill
    edited_slugs: list[str] = []
    to_update: list[dict[str, Any]] = []
    up_to_date: list[str] = []

    with console.status("Checking for updates...", spinner="dots"):
        for pin_slug, pin_data in pins.items():
            source = pin_data.get("source", "agentpowers")
            is_external = source != "agentpowers"
            is_edited = _check_edited(pin_slug, pins, pins_path)

            # Check latest version — external pins use ?source= param
            try:
                params = {"source": source} if is_external else {}
                detail = client.get(f"/v1/detail/{pin_slug}", params=params)
            except APIError:
                continue

            latest_version = (
                detail.get("version")
                if is_external
                else detail.get("version", "0.0.0")
            )
            installed_version = (
                pin_data.get("version")
                if is_external
                else pin_data.get("version", "0.0.0")
            )

            # Without both versions, can't determine if behind — treat as up-to-date
            if is_external and (not latest_version or not installed_version):
                up_to_date.append(pin_slug)
                continue

            if _compare_versions(installed_version, latest_version):
                security_status = detail.get("security_status", "pending")
                if security_status == "block":
                    continue
                to_update.append({
                    "slug": pin_slug,
                    "installed_version": installed_version,
                    "latest_version": latest_version,
                    "type": detail.get("type", "skill"),
                    "security_status": security_status,
                    "source": source,
                    "edited": is_edited,
                })
            else:
                if is_edited:
                    edited_slugs.append(pin_slug)
                else:
                    up_to_date.append(pin_slug)

    if not to_update and not edited_slugs:
        console.print("[dim]All installed skills are up to date.[/dim]")
        return

    # Show summary and confirm
    clean_updates = [i for i in to_update if not i.get("edited")]
    edited_updates = [i for i in to_update if i.get("edited")]

    if clean_updates:
        console.print(f"\n[bold]Updates available ({len(clean_updates)}):[/bold]")
        for item in clean_updates:
            console.print(
                f"  {item['slug']}: "
                f"v{item['installed_version']} → v{item['latest_version']}"
            )

    if edited_updates:
        console.print(
            f"\n[yellow]Locally edited with updates ({len(edited_updates)}):[/yellow]"
        )
        for item in edited_updates:
            console.print(
                f"  {item['slug']}: "
                f"v{item['installed_version']} → v{item['latest_version']}"
            )

    if edited_slugs:
        console.print(
            f"\n[yellow]Locally edited, up to date ({len(edited_slugs)}):[/yellow]"
        )
        for s in edited_slugs:
            console.print(f"  {s}")

    if clean_updates and not force:
        console.print()
        if not typer.confirm(f"Update {len(clean_updates)} skills?"):
            console.print("Update cancelled.")
            return

    # Download and install updates
    updated: list[str] = []
    failed: list[str] = []
    skipped_edited: list[str] = []

    for item in to_update:
        item_slug = item["slug"]
        item_source = item.get("source", "agentpowers")

        # Prompt per-edited-skill before updating
        if item.get("edited"):
            if not typer.confirm(
                f"{item_slug} has been locally edited. "
                f"Update anyway? Local changes will be overwritten",
                default=False,
            ):
                skipped_edited.append(item_slug)
                continue

        with console.status(
            f"Updating {item_slug}...", spinner="dots"
        ):
            try:
                if item_source != "agentpowers":
                    # External: delegate to external installer
                    install_external_skill(
                        client, item_slug, item_source,
                        item["type"], item["latest_version"], pins_path,
                    )
                else:
                    # Native: download and install directly
                    dest, zip_data = _download_and_install(
                        client, item_slug, item["type"]
                    )
                    from agentpowers_cli.services.content_hasher import hash_directory
                    content_hash = hash_directory(dest)
                    save_pin(
                        slug=item_slug,
                        source="agentpowers",
                        version=item["latest_version"],
                        content_hash=content_hash,
                        security_status=item["security_status"],
                        skill_type=item.get("type", "skill"),
                        pins_path=pins_path,
                    )
                updated.append(item_slug)
            except Exception as exc:
                console.print(f"[red]Failed to update {item_slug}:[/red] {exc}")
                failed.append(item_slug)

    # Combine skipped edited lists
    all_edited_skipped = edited_slugs + skipped_edited

    # Print summary
    console.print()
    if updated:
        for item in to_update:
            if item["slug"] in updated:
                console.print(
                    f"[green]Updated {item['slug']} "
                    f"v{item['installed_version']} → "
                    f"v{item['latest_version']}[/green]"
                )

    if up_to_date:
        console.print(
            f"[dim]{len(up_to_date)} skills already up to date[/dim]"
        )

    if all_edited_skipped:
        console.print(
            f"[yellow]{len(all_edited_skipped)} locally edited — skipped[/yellow]"
        )

    if failed:
        console.print(
            f"[red]{len(failed)} failed: {', '.join(failed)}[/red]"
        )
        raise typer.Exit(code=1)
