"""Authentication commands for the AgentPowers CLI.

Provides login (browser-based OAuth via Clerk), logout, and whoami commands.
"""

from __future__ import annotations

import socket
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any
from urllib.parse import parse_qs, urlparse

import typer
from rich.console import Console

from agentpowers_cli.banner import print_banner
from agentpowers_cli.services.api_client import APIClient, APIError
from agentpowers_cli.services.auth_store import delete_token, save_token
from agentpowers_cli.services.config import (
    AUTH_CALLBACK_HOST,
    CLERK_FRONTEND_URL,
    SITE_URL,
)

console = Console()

_PAGE_STYLE = """\
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: 'DM Sans', system-ui, -apple-system, sans-serif;
    background: #0a0f1a;
    color: #e2e8f0;
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
  }
  .card {
    text-align: center;
    padding: 3rem 2.5rem;
    max-width: 420px;
    border: 1px solid rgba(56, 189, 184, 0.2);
    border-radius: 16px;
    background: rgba(15, 23, 42, 0.8);
    box-shadow: 0 0 40px rgba(56, 189, 184, 0.08);
  }
  .icon {
    width: 56px; height: 56px; margin: 0 auto 1.5rem;
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
  }
  .icon-success { background: rgba(56, 189, 184, 0.15); }
  .icon-error   { background: rgba(239, 68, 68, 0.15); }
  .icon svg { width: 28px; height: 28px; }
  h1 {
    font-family: 'Space Grotesk', 'DM Sans', system-ui, sans-serif;
    font-size: 1.5rem;
    font-weight: 600;
    margin-bottom: 0.75rem;
  }
  p {
    font-size: 0.95rem;
    color: #94a3b8;
    line-height: 1.5;
  }
  .brand {
    margin-top: 2rem;
    font-size: 0.8rem;
    color: #475569;
    letter-spacing: 0.05em;
  }
  .brand span { color: #38bdb8; }
</style>
"""

_SUCCESS_HTML = (
    "<!DOCTYPE html>"
    "<html lang='en'><head><meta charset='utf-8'>"
    "<meta name='viewport' content='width=device-width,initial-scale=1'>"
    "<title>Logged in to AgentPowers!</title>"
    f"{_PAGE_STYLE}</head><body>"
    "<div class='card'>"
    "<div class='icon icon-success'>"
    "<svg viewBox='0 0 24 24' fill='none' stroke='#38bdb8' stroke-width='2.5'"
    " stroke-linecap='round' stroke-linejoin='round'>"
    "<polyline points='20 6 9 17 4 12'/></svg></div>"
    "<h1>Logged in to AgentPowers!</h1>"
    "<p>You can close this tab and return to the terminal.</p>"
    "<div class='brand'><span>agent</span>powers</div>"
    "</div></body></html>"
)

_ERROR_HTML = (
    "<!DOCTYPE html>"
    "<html lang='en'><head><meta charset='utf-8'>"
    "<meta name='viewport' content='width=device-width,initial-scale=1'>"
    "<title>Login Error</title>"
    f"{_PAGE_STYLE}</head><body>"
    "<div class='card'>"
    "<div class='icon icon-error'>"
    "<svg viewBox='0 0 24 24' fill='none' stroke='#ef4444' stroke-width='2.5'"
    " stroke-linecap='round' stroke-linejoin='round'>"
    "<line x1='18' y1='6' x2='6' y2='18'/>"
    "<line x1='6' y1='6' x2='18' y2='18'/></svg></div>"
    "<h1>Login Failed</h1>"
    "<p>Missing token. Please try logging in again from the terminal.</p>"
    "<div class='brand'><span>agent</span>powers</div>"
    "</div></body></html>"
)


def get_api_client() -> APIClient:
    """Create and return an APIClient instance.

    Returns:
        A configured APIClient.
    """
    return APIClient()


def _find_free_port() -> int:
    """Find an available TCP port on localhost.

    Returns:
        An available port number.
    """
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("", 0))
        return sock.getsockname()[1]


def open_browser(url: str) -> None:
    """Open a URL in the user's default browser.

    Args:
        url: The URL to open.
    """
    webbrowser.open(url)


class _CallbackHandler(BaseHTTPRequestHandler):
    """HTTP request handler for the OAuth callback.

    Expects a GET request to /callback?token=XXX and stores the
    token on the server instance.
    """

    def do_GET(self) -> None:
        """Handle the GET callback from Clerk auth redirect."""
        parsed = urlparse(self.path)
        if parsed.path != "/callback":
            self.send_response(404)
            self.end_headers()
            return

        params = parse_qs(parsed.query)
        token_values = params.get("token")

        if token_values:
            server: Any = self.server
            server.received_token = token_values[0]
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(_SUCCESS_HTML.encode())
        else:
            self.send_response(400)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(_ERROR_HTML.encode())

    def log_message(self, format: str, *args: Any) -> None:
        """Suppress default HTTP server logging."""


def start_auth_server(port: int, timeout: int = 120) -> str | None:
    """Start a temporary HTTP server and wait for the auth callback.

    Blocks until a token is received or the timeout expires.

    Args:
        port: The port to listen on.
        timeout: Maximum seconds to wait for the callback.

    Returns:
        The received JWT token, or None if the timeout expired.
    """
    server = HTTPServer((AUTH_CALLBACK_HOST, port), _CallbackHandler)
    server.received_token = None  # type: ignore[attr-defined]
    server.timeout = timeout

    # Run in a thread so we can enforce the overall timeout
    thread = threading.Thread(target=server.handle_request, daemon=True)
    thread.start()
    thread.join(timeout=timeout)

    server.server_close()
    return server.received_token  # type: ignore[attr-defined]


def login() -> None:
    """Authenticate with AgentPowers via browser-based Clerk login.

    Opens the default browser to the Clerk sign-in page. A temporary
    local HTTP server receives the callback with the JWT token. The
    short-lived JWT is exchanged for a long-lived CLI token.
    """
    port = _find_free_port()
    callback_url = f"http://{AUTH_CALLBACK_HOST}:{port}/callback"
    bridge_url = f"{SITE_URL}/auth/cli-callback?redirect_to={callback_url}"
    auth_url = f"{CLERK_FRONTEND_URL}/sign-in?redirect_url={bridge_url}"

    console.print(f"Opening browser to sign in...\n  [dim]{auth_url}[/dim]")
    open_browser(auth_url)

    console.print(f"Waiting for authentication (listening on port {port})...")
    clerk_jwt = start_auth_server(port)

    if clerk_jwt is None:
        console.print("[red]Login timed out.[/red] Please try again.")
        raise typer.Exit(code=1)

    # Exchange short-lived Clerk JWT for long-lived CLI token
    try:
        client = get_api_client()
        # Temporarily save the Clerk JWT so the client can use it
        save_token(clerk_jwt)
        result = client.post("/v1/auth/cli-token", auth=True)
        cli_token = result["token"]
        save_token(cli_token)
        console.print("[green]Logged in successfully![/green]")
    except (APIError, Exception):
        # Fallback: save the raw JWT (will expire, but login succeeded)
        save_token(clerk_jwt)
        console.print(
            "[green]Logged in successfully![/green] "
            "[dim](session token — may expire sooner)[/dim]"
        )


def logout() -> None:
    """Log out by revoking server-side token and removing local credentials."""
    try:
        client = get_api_client()
        client.post("/v1/auth/revoke-cli-token", auth=True)
    except (APIError, Exception):
        pass  # Best-effort revocation; always delete locally
    delete_token()
    console.print("Logged out.")


def whoami() -> None:
    """Display the currently authenticated user's information."""
    print_banner(console)

    client = get_api_client()
    try:
        user = client.get("/v1/auth/me", auth=True)
    except APIError as exc:
        if exc.status_code == 401:
            console.print("[red]Not logged in.[/red] Run `ap login` first.")
        else:
            console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1)

    email = user.get("email", "unknown")
    name = user.get("name", "")

    console.print(f"[bold]Email:[/bold]  {email}")
    if name:
        console.print(f"[bold]Name:[/bold]   {name}")
