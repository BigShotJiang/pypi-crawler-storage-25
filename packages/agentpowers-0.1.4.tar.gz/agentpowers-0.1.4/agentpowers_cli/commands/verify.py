"""Verify command — check installed skills against version pins."""

from __future__ import annotations

import typer
from rich.console import Console

from agentpowers_cli.services.content_hasher import hash_directory
from agentpowers_cli.services.installer import get_claude_dir
from agentpowers_cli.services.pin_manager import DEFAULT_PINS_PATH, load_pins

console = Console()


def verify() -> None:
    """Verify integrity of all installed skills against their content hashes."""
    pins = load_pins(DEFAULT_PINS_PATH)
    if not pins:
        console.print("[dim]No installed skills to verify.[/dim]")
        return

    claude_dir = get_claude_dir()
    all_ok = True

    for slug, pin_data in pins.items():
        expected_hash = pin_data.get("content_hash")
        source = pin_data.get("source", "unknown")

        if not expected_hash:
            console.print(
                f"  [yellow]SKIP[/yellow]    {slug} ({source})"
                " — no content hash stored"
            )
            continue

        # Check skills/ and agents/ directories
        skill_dir = claude_dir / "skills" / slug
        agent_dir = claude_dir / "agents" / slug
        target_dir = skill_dir if skill_dir.exists() else agent_dir

        if not target_dir.exists():
            console.print(
                f"  [red]MISSING[/red]  {slug} ({source})"
                " — not found on disk"
            )
            all_ok = False
            continue

        actual_hash = hash_directory(str(target_dir))
        if actual_hash == expected_hash:
            console.print(f"  [green]OK[/green]      {slug} ({source})")
        else:
            console.print(f"  [red]FAIL[/red]    {slug} ({source}) — hash mismatch")
            all_ok = False

    if not all_ok:
        raise typer.Exit(code=1)
