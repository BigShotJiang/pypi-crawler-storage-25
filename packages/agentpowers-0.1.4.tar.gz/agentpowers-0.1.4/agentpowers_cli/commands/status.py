"""Status command for the AgentPowers CLI.

Shows locally installed skills and agents with source, security,
version, and install date from install metadata.
"""

from __future__ import annotations

import json
from pathlib import Path

from rich.console import Console
from rich.table import Table

from agentpowers_cli.services.auth_store import load_token
from agentpowers_cli.services.installer import get_claude_dir
from agentpowers_cli.services.pin_manager import DEFAULT_PINS_PATH

console = Console()


def _list_installed(base_dir: Path, subdir: str) -> list[str]:
    """List installed package slugs (subdirectories only).

    Args:
        base_dir: The Claude config directory (~/.claude).
        subdir: Either "skills" or "agents".

    Returns:
        Sorted list of directory names.
    """
    target = base_dir / subdir
    if not target.exists():
        return []
    return sorted(d.name for d in target.iterdir() if d.is_dir())


def _load_pins(pins_path: str) -> dict:
    """Load pins from disk, returning empty dict on any error."""
    path = Path(pins_path)
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return {}


def _format_security(status: str | None) -> str:
    """Format security status with color."""
    if not status:
        return "-"
    s = status.lower()
    if s == "pass":
        return "[green]pass[/green]"
    if s == "warn":
        return "[yellow]warn[/yellow]"
    if s == "block":
        return "[red]block[/red]"
    return status


def _format_date(iso_str: str | None) -> str:
    """Extract date portion from ISO datetime string."""
    if not iso_str:
        return "-"
    return iso_str[:10]


def _build_table(
    slugs: list[str], pins: dict, kind: str
) -> Table | None:
    """Build a Rich table for installed items.

    Args:
        slugs: List of installed slugs.
        pins: Loaded pins dict.
        kind: Either "Skills" or "Agents" for the title.

    Returns:
        A Rich Table, or None if no items.
    """
    if not slugs:
        return None

    table = Table(title=f"Installed {kind} ({len(slugs)})")
    table.add_column("Slug", style="cyan", no_wrap=True)
    table.add_column("Source", style="yellow")
    table.add_column("Security")
    table.add_column("Version")
    table.add_column("Installed")

    for slug in slugs:
        pin = pins.get(slug, {})
        source = pin.get("source", "local")
        security = _format_security(pin.get("security_status"))
        version = pin.get("version") or "-"
        installed = _format_date(pin.get("installed_at"))

        table.add_row(slug, source, security, version, installed)

    return table


def status() -> None:
    """Show installed skills and agents with their status."""
    token = load_token()
    if token:
        console.print(
            "[green]Logged in[/green] [dim](run `ap whoami` to verify)[/dim]"
        )
    else:
        console.print(
            "[yellow]Not logged in.[/yellow] Run "
            "[bold]ap login[/bold] to purchase and publish skills."
        )
    console.print()

    claude_dir = get_claude_dir()
    pins = _load_pins(DEFAULT_PINS_PATH)

    skills = _list_installed(claude_dir, "skills")
    agents = _list_installed(claude_dir, "agents")

    skills_table = _build_table(skills, pins, "Skills")
    if skills_table:
        console.print(skills_table)
    else:
        console.print("No skills installed.")

    agents_table = _build_table(agents, pins, "Agents")
    if agents_table:
        console.print()
        console.print(agents_table)
    else:
        console.print("No agents installed.")
