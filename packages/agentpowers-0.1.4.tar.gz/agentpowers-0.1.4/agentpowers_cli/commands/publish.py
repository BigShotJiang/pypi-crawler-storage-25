"""Publish command for the AgentPowers CLI.

Packages a local skill or agent directory and uploads it to the
AgentPowers marketplace. Supports both first-time publish (create)
and updates (new version via upsert).
"""

from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console

from agentpowers_cli.services.api_client import APIClient, APIError
from agentpowers_cli.services.packager import load_skill_metadata, package_directory

console = Console()


def get_api_client() -> APIClient:
    """Create and return an APIClient instance.

    Returns:
        A configured APIClient.
    """
    return APIClient()


def _prompt_for_display_name(client: APIClient) -> str:
    """Prompt the user to set a display name and persist it via the API.

    Loops until a valid display name is accepted by the server.

    Args:
        client: An authenticated APIClient instance.

    Returns:
        The accepted display name string.
    """
    console.print("[yellow]A display name is required before publishing.[/yellow]")

    while True:
        display_name = typer.prompt("Choose a display name").strip()

        if not display_name:
            console.print("[red]Display name cannot be empty.[/red]")
            continue

        try:
            client.patch(
                "/v1/users/profile",
                json_data={"display_name": display_name},
                auth=True,
            )
            console.print(f"[green]Display name set to '{display_name}'.[/green]")
            return display_name
        except APIError as exc:
            if exc.status_code == 422:
                console.print(f"[red]Invalid display name: {exc}[/red]")
            else:
                console.print(f"[red]Failed to set display name: {exc}[/red]")
                raise


def publish(
    price: float | None = typer.Option(
        None, "--price", help="Price in USD (0 for free)"
    ),
    directory: Path = typer.Option(
        ".", "--dir", help="Directory containing the skill or agent"
    ),
    category: str = typer.Option(
        "development", "--category", help="Marketplace category"
    ),
    bump: str = typer.Option(
        "patch",
        "--bump",
        help="Version bump type: patch, minor, or major",
    ),
    version: str | None = typer.Option(
        None,
        "--version",
        help="Explicit version string (e.g. 2.0.0). Mutually exclusive with --bump.",
    ),
    changelog: str | None = typer.Option(
        None,
        "--changelog",
        help="Changelog message for this version",
    ),
) -> None:
    """Publish a skill or agent to the AgentPowers marketplace.

    First publish creates a new listing. Subsequent publishes create new
    versions (upsert). Use --bump to auto-increment or --version for
    an explicit version string.
    """
    # Validate mutually exclusive options
    if version and bump != "patch":
        console.print(
            "[red]Cannot use --bump and --version together.[/red]"
        )
        raise typer.Exit(code=1)

    # If --version is provided, ignore the default --bump value
    if version:
        bump = "patch"  # Reset to default so it won't be sent

    if price is not None and price < 0:
        console.print("[red]Price cannot be negative.[/red]")
        raise typer.Exit(code=1)

    directory = directory.resolve()

    metadata = load_skill_metadata(directory)
    if metadata is None:
        console.print(
            "[red]No skill found. Directory must contain SKILL.md (for skills) "
            "or an agent .md file with name/description frontmatter[/red]"
        )
        raise typer.Exit(code=1)

    slug = metadata.get("name", "unnamed").lower().replace(" ", "-")
    title = metadata.get("name", "Unnamed Skill")
    description = metadata.get("description", "")
    skill_type = metadata.get("type", "skill")
    price_cents = int(price * 100) if price is not None else None

    client = get_api_client()

    skill_payload: dict = {
        "slug": slug,
        "title": title,
        "description": description,
        "category": category,
        "type": skill_type,
        "price_cents": price_cents if price_cents is not None else 0,
    }

    with console.status("Packaging skill...", spinner="dots") as status:
        zip_data = package_directory(directory)

        status.update("Creating skill listing...")
        try:
            client.post("/v1/skills", json_data=skill_payload, auth=True)
            # First-time publish succeeded
            is_update = False
        except APIError as exc:
            if exc.status_code == 400 and "DISPLAY_NAME_REQUIRED" in str(exc):
                # User has no display name yet — collect one inline, then retry
                status.stop()
                _prompt_for_display_name(client)
                status.start()
                status.update("Creating skill listing...")
                try:
                    client.post("/v1/skills", json_data=skill_payload, auth=True)
                    is_update = False
                except APIError as retry_exc:
                    if retry_exc.status_code == 409:
                        is_update = True
                    else:
                        console.print(
                            f"[red]Failed to create skill:[/red] {retry_exc}"
                        )
                        raise typer.Exit(code=1)
            elif exc.status_code == 409:
                # Slug exists — this is an update
                is_update = True
            else:
                console.print(f"[red]Failed to create skill:[/red] {exc}")
                raise typer.Exit(code=1)

        new_version = None
        if is_update:
            status.update("Updating skill version...")
            patch_data: dict = {}
            if version:
                patch_data["version"] = version
            else:
                patch_data["bump"] = bump
            if changelog:
                patch_data["changelog"] = changelog
            # Send metadata updates too
            patch_data["title"] = title
            patch_data["description"] = description
            patch_data["category"] = category
            if price_cents is not None:
                patch_data["price_cents"] = price_cents

            try:
                update_resp = client.patch(
                    f"/v1/skills/{slug}",
                    json_data=patch_data,
                    auth=True,
                )
                new_version = update_resp.get("new_version")
            except APIError as exc:
                _handle_update_error(exc, slug)
                raise typer.Exit(code=1)

        status.update("Uploading package...")
        upload_path = f"/v1/skills/{slug}/upload"
        if new_version:
            upload_path += f"?version={new_version}"

        try:
            client.upload(
                upload_path,
                file_data=zip_data,
                filename="package.zip",
                auth=True,
            )
        except APIError as exc:
            console.print(f"[red]Upload failed:[/red] {exc}")
            raise typer.Exit(code=1)

    if is_update:
        console.print(
            f"[green]Updated '{slug}' to v{new_version}. "
            "Security scan pending.[/green]"
        )
    else:
        console.print(f"[green]Published '{slug}' successfully![/green]")


def _handle_update_error(exc: APIError, slug: str) -> None:
    """Print a human-friendly error message for update failures."""
    detail = str(exc)

    # Check for structured error codes
    if "SKILL_NOT_OWNER" in detail or exc.status_code == 403:
        console.print(
            f"[red]You are not the author of '{slug}'[/red]"
        )
    elif "SKILL_ARCHIVED" in detail:
        console.print(
            "[red]Skill is archived. Run `ap republish` first.[/red]"
        )
    elif "SKILL_VERSION_PENDING" in detail:
        console.print(
            "[red]A version is already pending scan. "
            "Wait for scan to complete or contact support.[/red]"
        )
    elif exc.status_code == 422:
        console.print(f"[red]Validation error:[/red] {detail}")
    else:
        console.print(f"[red]Update failed:[/red] {detail}")
