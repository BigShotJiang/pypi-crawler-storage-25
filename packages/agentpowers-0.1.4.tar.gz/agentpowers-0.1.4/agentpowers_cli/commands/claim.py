"""Claim command — submit ownership claim for a ClawHub skill."""

from __future__ import annotations

import typer
from rich.console import Console

from agentpowers_cli.services.api_client import APIClient, APIError

console = Console()


def get_api_client() -> APIClient:
    """Create and return an APIClient instance.

    Returns:
        A configured APIClient.
    """
    return APIClient()


def claim(
    slug: str = typer.Argument(help="Slug of the ClawHub skill to claim"),
) -> None:
    """Claim ownership of a ClawHub-imported skill.

    Submits a POST request to /v1/skills/{slug}/claim.
    The API verifies GitHub identity and returns an approval status,
    sandbox (manual review), or rejection with a verification score.

    Args:
        slug: The URL slug identifying the ClawHub skill to claim.
    """
    from agentpowers_cli.commands import validate_slug
    slug = validate_slug(slug)

    client = get_api_client()

    try:
        result = client.post(
            f"/v1/skills/{slug}/claim",
            auth=True,
        )
    except APIError as exc:
        if exc.status_code == 401:
            console.print("[red]Not logged in.[/red] Run `ap login` first.")
        elif exc.status_code == 404:
            console.print(f"[red]Skill '{slug}' not found.[/red]")
        elif exc.status_code == 409:
            console.print(
                f"[yellow]Skill '{slug}' is already claimed.[/yellow]",
            )
        else:
            console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1)

    status = result.get("status", "unknown")
    score = result.get("verification_score", 0)
    message = result.get("message", "")

    if status == "approved":
        console.print(f"[green]Approved![/green] {message}")
        console.print(f"  Score: {score}")
    elif status == "sandbox":
        console.print(f"[yellow]Under review.[/yellow] {message}")
        console.print(f"  Score: {score}")
        console.print("  An admin will review your claim shortly.")
    elif status == "rejected":
        console.print(f"[red]Rejected.[/red] {message}")
        console.print(f"  Score: {score}")
    else:
        console.print(f"Status: {status} — {message}")
