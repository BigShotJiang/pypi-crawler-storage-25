"""Tests for the update command."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from agentpowers_cli.main import app
from agentpowers_cli.services.api_client import APIError

runner = CliRunner()


def _pin(
    source: str = "agentpowers",
    version: str | None = "1.0.0",
    content_hash: str = "sha256:abc123",
) -> dict:
    """Build a pin dict for testing."""
    return {
        "source": source,
        "version": version,
        "content_hash": content_hash,
    }


def _normalize(text: str) -> str:
    """Collapse all whitespace in text to single spaces for assertion matching."""
    return " ".join(text.split())


class TestUpdateSingle:
    """Tests for updating a single skill."""

    @patch("agentpowers_cli.commands.update.save_pin")
    @patch("agentpowers_cli.commands.update._download_and_install")
    @patch("agentpowers_cli.commands.update._check_edited", return_value=False)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_single_update_behind(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        mock_download: MagicMock,
        mock_save: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Skill behind latest version is updated successfully."""
        mock_pins.return_value = {"test-skill": _pin(version="1.0.0")}
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {
            "version": "1.0.1",
            "type": "skill",
            "security_status": "pass",
        }
        mock_download.return_value = ("/path/to/dest", b"zip-data")

        pins_file = str(tmp_path / "pins.json")
        result = runner.invoke(app, ["update", "test-skill", "--pins-path", pins_file])

        assert result.exit_code == 0
        assert "Updated test-skill" in result.output
        assert "1.0.1" in result.output
        mock_download.assert_called_once()
        mock_save.assert_called_once()

    @patch("agentpowers_cli.commands.update._check_edited", return_value=False)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_single_already_up_to_date(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Skill at latest version shows up-to-date message."""
        mock_pins.return_value = {"test-skill": _pin(version="1.0.0")}
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {
            "version": "1.0.0",
            "type": "skill",
            "security_status": "pass",
        }

        pins_file = str(tmp_path / "pins.json")
        result = runner.invoke(app, ["update", "test-skill", "--pins-path", pins_file])

        assert result.exit_code == 0
        assert "up to date" in result.output

    @patch("agentpowers_cli.commands.update._check_edited", return_value=True)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_single_locally_edited_prompts_user(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Locally edited skill prompts user before skipping (default No)."""
        mock_pins.return_value = {"test-skill": _pin(version="1.0.0")}
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {
            "version": "1.1.0",
            "type": "skill",
            "security_status": "pass",
        }

        pins_file = str(tmp_path / "pins.json")
        with patch("agentpowers_cli.commands.update.typer.confirm",
             return_value=False) as mock_confirm:
            result = runner.invoke(
                app, ["update", "test-skill", "--pins-path", pins_file],
            )

        assert result.exit_code == 0
        assert "locally edited" in result.output
        assert "Skipping" in result.output
        mock_confirm.assert_called_once()

    @patch("agentpowers_cli.commands.update.save_pin")
    @patch("agentpowers_cli.commands.update._download_and_install")
    @patch("agentpowers_cli.commands.update._check_edited", return_value=True)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_single_locally_edited_user_confirms_updates(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        mock_download: MagicMock,
        mock_save: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Locally edited skill proceeds with update when user confirms."""
        mock_pins.return_value = {"test-skill": _pin(version="1.0.0")}
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {
            "version": "1.1.0",
            "type": "skill",
            "security_status": "pass",
        }
        mock_download.return_value = ("/path/to/dest", b"zip-data")

        pins_file = str(tmp_path / "pins.json")
        with patch("agentpowers_cli.commands.update.typer.confirm", return_value=True):
            result = runner.invoke(
                app, ["update", "test-skill", "--pins-path", pins_file],
            )

        assert result.exit_code == 0
        assert "Updated test-skill" in result.output
        mock_download.assert_called_once()
        mock_save.assert_called_once()

    @patch("agentpowers_cli.commands.update.save_pin")
    @patch("agentpowers_cli.commands.update._download_and_install")
    @patch("agentpowers_cli.commands.update._check_edited", return_value=True)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_single_locally_edited_force_skips_prompt(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        mock_download: MagicMock,
        mock_save: MagicMock,
        tmp_path: Path,
    ) -> None:
        """--force flag bypasses the edit prompt and updates directly."""
        mock_pins.return_value = {"test-skill": _pin(version="1.0.0")}
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {
            "version": "1.1.0",
            "type": "skill",
            "security_status": "pass",
        }
        mock_download.return_value = ("/path/to/dest", b"zip-data")

        pins_file = str(tmp_path / "pins.json")
        with patch("agentpowers_cli.commands.update.typer.confirm") as mock_confirm:
            result = runner.invoke(
                app, ["update", "test-skill", "--force", "--pins-path", pins_file],
            )

        assert result.exit_code == 0
        assert "Updated test-skill" in result.output
        mock_confirm.assert_not_called()
        mock_download.assert_called_once()

    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_single_not_installed(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Skill not in pins or filesystem shows not-installed error."""
        mock_pins.return_value = {}
        client = MagicMock()
        mock_client_fn.return_value = client

        # Also patch Path.home so filesystem check fails
        with patch("agentpowers_cli.commands.update.Path.home", return_value=tmp_path):
            pins_file = str(tmp_path / "pins.json")
            result = runner.invoke(
                app, ["update", "nonexistent-skill", "--pins-path", pins_file],
            )

        assert result.exit_code == 1
        assert "not installed" in result.output

    @patch("agentpowers_cli.commands.update.install_external_skill")
    @patch("agentpowers_cli.commands.update._check_edited", return_value=False)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_single_external_update_behind(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        mock_ext_install: MagicMock,
        tmp_path: Path,
    ) -> None:
        """External skill behind latest version is updated via external installer."""
        mock_pins.return_value = {
            "ext-skill": _pin(source="clawhub", version="1.0.0"),
        }
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {
            "version": "1.1.0",
            "type": "skill",
        }
        mock_ext_install.return_value = "/path/to/dest"

        pins_file = str(tmp_path / "pins.json")
        result = runner.invoke(app, ["update", "ext-skill", "--pins-path", pins_file])

        assert result.exit_code == 0
        assert "Updated ext-skill" in result.output
        assert "v1.1.0" in result.output
        mock_ext_install.assert_called_once_with(
            client, "ext-skill", "clawhub", "skill", "1.1.0", pins_file,
        )

    @patch("agentpowers_cli.commands.update._check_edited", return_value=False)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_single_external_up_to_date(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        tmp_path: Path,
    ) -> None:
        """External skill at latest version shows up-to-date message."""
        mock_pins.return_value = {
            "ext-skill": _pin(source="clawhub", version="1.0.0"),
        }
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {"version": "1.0.0", "type": "skill"}

        pins_file = str(tmp_path / "pins.json")
        result = runner.invoke(app, ["update", "ext-skill", "--pins-path", pins_file])

        assert result.exit_code == 0
        assert "up to date" in result.output

    @patch("agentpowers_cli.commands.update._check_edited", return_value=True)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_single_external_edited_prompts_user(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Locally edited external skill prompts user and skips on decline."""
        mock_pins.return_value = {
            "ext-skill": _pin(source="clawhub", version="1.0.0"),
        }
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {"version": "1.1.0", "type": "skill"}

        pins_file = str(tmp_path / "pins.json")
        with patch("agentpowers_cli.commands.update.typer.confirm",
             return_value=False) as mock_confirm:
            result = runner.invoke(
                app, ["update", "ext-skill", "--pins-path", pins_file],
            )

        assert result.exit_code == 0
        assert "locally edited" in result.output
        assert "Skipping" in result.output
        mock_confirm.assert_called_once()

    @patch("agentpowers_cli.commands.update.install_external_skill")
    @patch("agentpowers_cli.commands.update._check_edited", return_value=True)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_single_external_edited_user_confirms_updates(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        mock_ext_install: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Locally edited external skill updates when user confirms."""
        mock_pins.return_value = {
            "ext-skill": _pin(source="clawhub", version="1.0.0"),
        }
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {"version": "1.1.0", "type": "skill"}
        mock_ext_install.return_value = "/path/to/dest"

        pins_file = str(tmp_path / "pins.json")
        with patch("agentpowers_cli.commands.update.typer.confirm", return_value=True):
            result = runner.invoke(
                app, ["update", "ext-skill", "--pins-path", pins_file],
            )

        assert result.exit_code == 0
        assert "Updated ext-skill" in result.output
        mock_ext_install.assert_called_once()

    @patch("agentpowers_cli.commands.update.install_external_skill")
    @patch("agentpowers_cli.commands.update._check_edited", return_value=True)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_single_external_edited_force_skips_prompt(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        mock_ext_install: MagicMock,
        tmp_path: Path,
    ) -> None:
        """--force on edited external skill skips prompt and updates."""
        mock_pins.return_value = {
            "ext-skill": _pin(source="clawhub", version="1.0.0"),
        }
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {"version": "1.1.0", "type": "skill"}
        mock_ext_install.return_value = "/path/to/dest"

        pins_file = str(tmp_path / "pins.json")
        with patch("agentpowers_cli.commands.update.typer.confirm") as mock_confirm:
            result = runner.invoke(
                app, ["update", "ext-skill", "--force", "--pins-path", pins_file],
            )

        assert result.exit_code == 0
        assert "Updated ext-skill" in result.output
        mock_confirm.assert_not_called()
        mock_ext_install.assert_called_once()

    @patch("agentpowers_cli.commands.update._check_edited", return_value=False)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_single_external_no_installed_version_up_to_date(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        tmp_path: Path,
    ) -> None:
        """External skill with no installed version and unedited is up-to-date."""
        mock_pins.return_value = {
            "ext-skill": _pin(source="clawhub", version=None),
        }
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {"version": "1.0.0", "type": "skill"}

        pins_file = str(tmp_path / "pins.json")
        result = runner.invoke(app, ["update", "ext-skill", "--pins-path", pins_file])

        assert result.exit_code == 0
        assert "up to date" in result.output

    @patch("agentpowers_cli.commands.update._check_edited", return_value=False)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_single_external_no_latest_version_up_to_date(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        tmp_path: Path,
    ) -> None:
        """External skill where API returns no version treats as up-to-date."""
        mock_pins.return_value = {
            "ext-skill": _pin(source="clawhub", version="1.0.0"),
        }
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {"type": "skill"}

        pins_file = str(tmp_path / "pins.json")
        result = runner.invoke(app, ["update", "ext-skill", "--pins-path", pins_file])

        assert result.exit_code == 0
        assert "up to date" in result.output

    @patch("agentpowers_cli.commands.update._check_edited", return_value=False)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_single_external_both_versions_none_up_to_date(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        tmp_path: Path,
    ) -> None:
        """External skill with both versions None treats as up-to-date."""
        mock_pins.return_value = {
            "ext-skill": _pin(source="clawhub", version=None),
        }
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {"type": "skill"}

        pins_file = str(tmp_path / "pins.json")
        result = runner.invoke(app, ["update", "ext-skill", "--pins-path", pins_file])

        assert result.exit_code == 0
        assert "up to date" in result.output

    @patch("agentpowers_cli.commands.update._check_edited", return_value=False)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_single_skill_not_found_on_api(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Skill in pins but not found on API shows error."""
        mock_pins.return_value = {"missing-skill": _pin(version="1.0.0")}
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.side_effect = APIError("not found", status_code=404)

        pins_file = str(tmp_path / "pins.json")
        result = runner.invoke(
            app, ["update", "missing-skill", "--pins-path", pins_file],
        )

        assert result.exit_code == 1
        assert "not found" in result.output


class TestUpdateAll:
    """Tests for updating all installed skills."""

    @patch("agentpowers_cli.commands.update.save_pin")
    @patch("agentpowers_cli.commands.update._download_and_install")
    @patch("agentpowers_cli.commands.update._check_edited", return_value=False)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_update_all_with_confirmation(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        mock_download: MagicMock,
        mock_save: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Update all with user confirmation proceeds to download."""
        mock_pins.return_value = {
            "skill-a": _pin(version="1.0.0"),
            "skill-b": _pin(version="2.0.0"),
        }
        client = MagicMock()
        mock_client_fn.return_value = client
        # skill-a has update, skill-b is current
        client.get.side_effect = [
            {"version": "1.1.0", "type": "skill", "security_status": "pass"},
            {"version": "2.0.0", "type": "skill", "security_status": "pass"},
        ]
        mock_download.return_value = ("/path/dest", b"zip-data")

        pins_file = str(tmp_path / "pins.json")
        with patch("agentpowers_cli.commands.update.typer.confirm", return_value=True):
            result = runner.invoke(app, ["update", "--pins-path", pins_file])

        assert result.exit_code == 0
        assert "Updated skill-a" in result.output
        mock_download.assert_called_once()

    @patch("agentpowers_cli.commands.update.save_pin")
    @patch("agentpowers_cli.commands.update._download_and_install")
    @patch("agentpowers_cli.commands.update._check_edited", return_value=False)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_update_all_with_force(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        mock_download: MagicMock,
        mock_save: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Update all with --force skips confirmation prompt."""
        mock_pins.return_value = {"skill-a": _pin(version="1.0.0")}
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {
            "version": "1.1.0",
            "type": "skill",
            "security_status": "pass",
        }
        mock_download.return_value = ("/path/dest", b"zip-data")

        pins_file = str(tmp_path / "pins.json")
        # No need to patch typer.confirm since --force bypasses it
        result = runner.invoke(app, ["update", "--force", "--pins-path", pins_file])

        assert result.exit_code == 0
        assert "Updated skill-a" in result.output

    @patch("agentpowers_cli.commands.update._check_edited", return_value=False)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_update_all_no_outdated(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        tmp_path: Path,
    ) -> None:
        """All skills up to date shows 'all up to date' message."""
        mock_pins.return_value = {"skill-a": _pin(version="1.0.0")}
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {
            "version": "1.0.0",
            "type": "skill",
            "security_status": "pass",
        }

        pins_file = str(tmp_path / "pins.json")
        result = runner.invoke(app, ["update", "--pins-path", pins_file])

        assert result.exit_code == 0
        assert "up to date" in result.output

    @patch("agentpowers_cli.commands.update._check_edited", return_value=False)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_update_all_external_only_up_to_date(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Only external skills in pins, all up to date, shows up-to-date."""
        mock_pins.return_value = {
            "ext-skill": _pin(source="clawhub", version="1.0.0"),
        }
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {"version": "1.0.0", "type": "skill"}

        pins_file = str(tmp_path / "pins.json")
        result = runner.invoke(app, ["update", "--pins-path", pins_file])

        assert result.exit_code == 0
        assert "up to date" in result.output

    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_update_all_empty_pins(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Empty pins file shows no skills message."""
        mock_pins.return_value = {}
        client = MagicMock()
        mock_client_fn.return_value = client

        pins_file = str(tmp_path / "pins.json")
        result = runner.invoke(app, ["update", "--pins-path", pins_file])

        assert result.exit_code == 0
        assert "No skills installed" in result.output

    @patch("agentpowers_cli.commands.update.install_external_skill")
    @patch("agentpowers_cli.commands.update.save_pin")
    @patch("agentpowers_cli.commands.update._download_and_install")
    @patch("agentpowers_cli.commands.update._check_edited", return_value=False)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_update_all_includes_external(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        mock_download: MagicMock,
        mock_save: MagicMock,
        mock_ext_install: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Update-all includes both native and external skills."""
        mock_pins.return_value = {
            "native-skill": _pin(source="agentpowers", version="1.0.0"),
            "ext-skill": _pin(source="clawhub", version="1.0.0"),
        }
        client = MagicMock()
        mock_client_fn.return_value = client
        # Both have updates available
        client.get.side_effect = [
            {"version": "1.1.0", "type": "skill", "security_status": "pass"},
            {"version": "1.2.0", "type": "skill"},
        ]
        mock_download.return_value = ("/path/dest", b"zip-data")
        mock_ext_install.return_value = "/path/ext-dest"

        pins_file = str(tmp_path / "pins.json")
        with patch("agentpowers_cli.commands.update.typer.confirm", return_value=True):
            result = runner.invoke(app, ["update", "--pins-path", pins_file])

        assert result.exit_code == 0
        assert "Updated native-skill" in result.output
        assert "Updated ext-skill" in result.output
        mock_download.assert_called_once()  # Only native
        mock_ext_install.assert_called_once()  # Only external


class TestUpdateAllEditedPrompt:
    """Tests for edited skill prompts during update-all."""

    @patch("agentpowers_cli.commands.update.save_pin")
    @patch("agentpowers_cli.commands.update._download_and_install")
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_update_all_edited_skill_prompted_and_included(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_download: MagicMock,
        mock_save: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Edited skill in update-all prompts per-skill and updates on confirm."""
        mock_pins.return_value = {
            "edited-skill": _pin(version="1.0.0"),
        }
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {
            "version": "1.1.0",
            "type": "skill",
            "security_status": "pass",
        }
        mock_download.return_value = ("/path/dest", b"zip-data")

        def check_edited_side_effect(slug, pins, pins_path):
            return True

        pins_file = str(tmp_path / "pins.json")
        with (
            patch("agentpowers_cli.commands.update._check_edited",
                side_effect=check_edited_side_effect),
            patch("agentpowers_cli.commands.update.typer.confirm",
                return_value=True) as _mock_confirm,
        ):
            result = runner.invoke(app, ["update", "--force", "--pins-path", pins_file])

        assert result.exit_code == 0
        assert "Updated edited-skill" in result.output

    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_update_all_edited_skill_declined_stays_skipped(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Edited skill in update-all that user declines remains skipped."""
        mock_pins.return_value = {
            "edited-skill": _pin(version="1.0.0"),
        }
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {
            "version": "1.1.0",
            "type": "skill",
            "security_status": "pass",
        }

        def check_edited_side_effect(slug, pins, pins_path):
            return True

        pins_file = str(tmp_path / "pins.json")
        with (
            patch("agentpowers_cli.commands.update._check_edited",
                side_effect=check_edited_side_effect),
            patch("agentpowers_cli.commands.update.typer.confirm",
                return_value=False) as _mock_confirm,
        ):
            result = runner.invoke(app, ["update", "--force", "--pins-path", pins_file])

        assert result.exit_code == 0
        assert "locally edited" in _normalize(result.output)
        assert "skipped" in _normalize(result.output).lower()

    @patch("agentpowers_cli.commands.update.save_pin")
    @patch("agentpowers_cli.commands.update._download_and_install")
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_update_all_edited_force_prompts_per_edited_skill(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_download: MagicMock,
        mock_save: MagicMock,
        tmp_path: Path,
    ) -> None:
        """--force skips bulk confirm but still prompts per-edited-skill."""
        mock_pins.return_value = {
            "clean-skill": _pin(version="1.0.0"),
            "edited-skill": _pin(version="1.0.0"),
        }
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.side_effect = [
            {"version": "1.1.0", "type": "skill", "security_status": "pass"},
            {"version": "1.1.0", "type": "skill", "security_status": "pass"},
        ]
        mock_download.return_value = ("/path/dest", b"zip-data")

        def check_edited_side_effect(slug, pins, pins_path):
            return slug == "edited-skill"

        pins_file = str(tmp_path / "pins.json")
        with (
            patch("agentpowers_cli.commands.update._check_edited",
                side_effect=check_edited_side_effect),
            patch("agentpowers_cli.commands.update.typer.confirm",
                return_value=False) as mock_confirm,
        ):
            result = runner.invoke(app, ["update", "--force", "--pins-path", pins_file])

        assert result.exit_code == 0
        # Clean skill updated, edited skill skipped
        assert "Updated clean-skill" in result.output
        # The confirm was called once (for the edited skill only — --force skips the
        # bulk prompt)
        mock_confirm.assert_called_once()


class TestEditedEdgeCasesSingle:
    """Edge cases for the edited-skill prompt on single update."""

    @patch("agentpowers_cli.commands.update._check_edited", return_value=True)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_single_edited_up_to_date_warns_user(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Edited skill at latest version warns user and prompts to restore."""
        mock_pins.return_value = {"test-skill": _pin(version="1.0.0")}
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {
            "version": "1.0.0",
            "type": "skill",
            "security_status": "pass",
        }

        pins_file = str(tmp_path / "pins.json")
        with patch("agentpowers_cli.commands.update.typer.confirm",
             return_value=False) as mock_confirm:
            result = runner.invoke(
                app, ["update", "test-skill", "--pins-path", pins_file],
            )

        assert result.exit_code == 0
        assert "locally edited" in result.output
        assert "Skipping" in result.output
        mock_confirm.assert_called_once()

    @patch("agentpowers_cli.commands.update._check_edited", return_value=True)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    @patch("agentpowers_cli.commands.update.save_pin")
    @patch("agentpowers_cli.commands.update._download_and_install")
    def test_single_edited_force_up_to_date_redownloads(
        self,
        mock_download: MagicMock,
        mock_save: MagicMock,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Edited skill + --force + up-to-date: re-downloads to restore original."""
        mock_pins.return_value = {"test-skill": _pin(version="1.0.0")}
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {
            "version": "1.0.0",
            "type": "skill",
            "security_status": "pass",
        }
        mock_download.return_value = ("/path/to/dest", b"zip-data")

        pins_file = str(tmp_path / "pins.json")
        with patch("agentpowers_cli.commands.update.typer.confirm") as mock_confirm:
            result = runner.invoke(
                app, ["update", "test-skill", "--force", "--pins-path", pins_file],
            )

        assert result.exit_code == 0
        assert "Restored" in result.output
        mock_confirm.assert_not_called()
        mock_download.assert_called_once()

    @patch("agentpowers_cli.commands.update._check_edited", return_value=True)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_single_edited_behind_blocked_by_security(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Edited + behind + blocked: user confirms overwrite but security blocks."""
        mock_pins.return_value = {"test-skill": _pin(version="1.0.0")}
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {
            "version": "1.1.0",
            "type": "skill",
            "security_status": "block",
        }

        pins_file = str(tmp_path / "pins.json")
        with patch("agentpowers_cli.commands.update.typer.confirm", return_value=True):
            result = runner.invoke(
                app, ["update", "test-skill", "--pins-path", pins_file],
            )

        assert result.exit_code == 0
        assert "blocked by security" in result.output
        assert "Keeping v1.0.0" in result.output

    @patch("agentpowers_cli.commands.update._download_and_install")
    @patch("agentpowers_cli.commands.update._check_edited", return_value=True)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_single_edited_confirm_then_download_fails(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        mock_download: MagicMock,
        tmp_path: Path,
    ) -> None:
        """User confirms overwrite on edited skill but download fails."""
        import httpx
        mock_pins.return_value = {"test-skill": _pin(version="1.0.0")}
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {
            "version": "1.1.0",
            "type": "skill",
            "security_status": "pass",
        }
        mock_download.side_effect = httpx.HTTPError("connection refused")

        pins_file = str(tmp_path / "pins.json")
        with patch("agentpowers_cli.commands.update.typer.confirm", return_value=True):
            result = runner.invoke(
                app, ["update", "test-skill", "--pins-path", pins_file],
            )

        assert result.exit_code == 0
        assert "Download failed" in result.output

    @patch("agentpowers_cli.commands.update._download_and_install")
    @patch("agentpowers_cli.commands.update._check_edited", return_value=True)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_single_edited_confirm_then_403_purchase_required(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        mock_download: MagicMock,
        tmp_path: Path,
    ) -> None:
        """User confirms overwrite on edited skill but 403 purchase required."""
        mock_pins.return_value = {"test-skill": _pin(version="1.0.0")}
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {
            "version": "1.1.0",
            "type": "skill",
            "security_status": "pass",
        }
        mock_download.side_effect = APIError("forbidden", status_code=403)

        pins_file = str(tmp_path / "pins.json")
        with patch("agentpowers_cli.commands.update.typer.confirm", return_value=True):
            result = runner.invoke(
                app, ["update", "test-skill", "--pins-path", pins_file],
            )

        assert result.exit_code == 1
        assert "requires purchase" in result.output

    @patch("agentpowers_cli.commands.update._check_edited", return_value=True)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_single_external_edited_up_to_date_warns_user(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Edited external skill at latest version warns user and prompts."""
        mock_pins.return_value = {
            "ext-skill": _pin(source="clawhub", version="1.0.0"),
        }
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {"version": "1.0.0", "type": "skill"}

        pins_file = str(tmp_path / "pins.json")
        with patch("agentpowers_cli.commands.update.typer.confirm",
             return_value=False) as mock_confirm:
            result = runner.invoke(
                app, ["update", "ext-skill", "--pins-path", pins_file],
            )

        assert result.exit_code == 0
        assert "locally edited" in result.output
        assert "Skipping" in result.output
        mock_confirm.assert_called_once()

    @patch("agentpowers_cli.commands.update._check_edited", return_value=True)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_single_edited_prompt_text_contains_slug_and_warning(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Confirm prompt text includes slug name and overwrite warning."""
        mock_pins.return_value = {"my-custom-skill": _pin(version="1.0.0")}
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {
            "version": "1.1.0",
            "type": "skill",
            "security_status": "pass",
        }

        pins_file = str(tmp_path / "pins.json")
        with patch("agentpowers_cli.commands.update.typer.confirm",
             return_value=False) as mock_confirm:
            runner.invoke(app, ["update", "my-custom-skill", "--pins-path", pins_file])

        prompt_text = mock_confirm.call_args[0][0]
        assert "my-custom-skill" in prompt_text
        assert "overwritten" in prompt_text.lower()

    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_single_no_pin_filesystem_only_never_prompts(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Skill on filesystem but not in pins: no prompt."""
        mock_pins.return_value = {}
        client = MagicMock()
        mock_client_fn.return_value = client

        # Create the skill dir on filesystem so it's "found"
        skills_dir = tmp_path / ".claude" / "skills" / "fs-skill"
        skills_dir.mkdir(parents=True)

        pins_file = str(tmp_path / "pins.json")
        with (
            patch("agentpowers_cli.commands.update.Path.home", return_value=tmp_path),
            patch("agentpowers_cli.commands.update.typer.confirm") as mock_confirm,
        ):
            # No pin means _check_edited returns False, so version check runs.
            # client.get will be called for version check.
            client.get.return_value = {
                "version": "1.0.0",
                "type": "skill",
                "security_status": "pass",
            }
            result = runner.invoke(
                app, ["update", "fs-skill", "--pins-path", pins_file],
            )

        assert result.exit_code == 0
        mock_confirm.assert_not_called()


class TestUpdateAllEditedEdgeCases:
    """Edge cases for edited skill prompts in update-all flow."""

    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_update_all_mixed_edited_behind_and_up_to_date(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Update-all shows both edited+behind and edited+up-to-date sections."""
        mock_pins.return_value = {
            "edited-behind": _pin(version="1.0.0"),
            "edited-current": _pin(version="2.0.0"),
        }
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.side_effect = [
            {"version": "1.1.0", "type": "skill", "security_status": "pass"},
            {"version": "2.0.0", "type": "skill", "security_status": "pass"},
        ]

        def check_edited_side_effect(slug, pins, pins_path):
            return True  # Both are edited

        pins_file = str(tmp_path / "pins.json")
        with (
            patch("agentpowers_cli.commands.update._check_edited",
                side_effect=check_edited_side_effect),
            patch("agentpowers_cli.commands.update.typer.confirm", return_value=False),
        ):
            result = runner.invoke(app, ["update", "--force", "--pins-path", pins_file])

        output = _normalize(result.output)
        assert result.exit_code == 0
        # Should show edited-behind in "Locally edited with updates" section
        assert "edited-behind" in output
        # Should show edited-current in "Locally edited, up to date" section
        assert "edited-current" in output

    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_update_all_all_edited_all_declined(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        tmp_path: Path,
    ) -> None:
        """All skills edited+behind, all declined: summary shows all skipped."""
        mock_pins.return_value = {
            "skill-a": _pin(version="1.0.0"),
            "skill-b": _pin(version="1.0.0"),
        }
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.side_effect = [
            {"version": "1.1.0", "type": "skill", "security_status": "pass"},
            {"version": "1.1.0", "type": "skill", "security_status": "pass"},
        ]

        def check_edited_side_effect(slug, pins, pins_path):
            return True

        pins_file = str(tmp_path / "pins.json")
        with (
            patch("agentpowers_cli.commands.update._check_edited",
                side_effect=check_edited_side_effect),
            patch("agentpowers_cli.commands.update.typer.confirm",
                return_value=False) as mock_confirm,
        ):
            result = runner.invoke(app, ["update", "--force", "--pins-path", pins_file])

        assert result.exit_code == 0
        # Both declined = 2 skipped
        assert "2 locally edited" in _normalize(result.output)
        assert "skipped" in _normalize(result.output).lower()
        # confirm called twice (once per edited skill)
        assert mock_confirm.call_count == 2

    @patch("agentpowers_cli.commands.update.install_external_skill")
    @patch("agentpowers_cli.commands.update.save_pin")
    @patch("agentpowers_cli.commands.update._download_and_install")
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_update_all_edited_external_prompted_and_updated(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_download: MagicMock,
        mock_save: MagicMock,
        mock_ext_install: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Edited external skill in update-all prompts and calls external installer."""
        mock_pins.return_value = {
            "ext-edited": _pin(source="clawhub", version="1.0.0"),
        }
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {"version": "1.1.0", "type": "skill"}
        mock_ext_install.return_value = "/path/ext-dest"

        def check_edited_side_effect(slug, pins, pins_path):
            return True

        pins_file = str(tmp_path / "pins.json")
        with (
            patch("agentpowers_cli.commands.update._check_edited",
                side_effect=check_edited_side_effect),
            patch("agentpowers_cli.commands.update.typer.confirm",
                return_value=True) as mock_confirm,
        ):
            result = runner.invoke(app, ["update", "--force", "--pins-path", pins_file])

        assert result.exit_code == 0
        assert "Updated ext-edited" in result.output
        mock_ext_install.assert_called_once()
        mock_download.assert_not_called()  # External, not native
        mock_confirm.assert_called_once()

    @patch("agentpowers_cli.commands.update.save_pin")
    @patch("agentpowers_cli.commands.update._download_and_install")
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_update_all_cancel_bulk_confirm_skips_edited_prompts_too(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_download: MagicMock,
        mock_save: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Cancelling bulk confirm also prevents edited skill per-skill prompts."""
        mock_pins.return_value = {
            "clean-skill": _pin(version="1.0.0"),
            "edited-skill": _pin(version="1.0.0"),
        }
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.side_effect = [
            {"version": "1.1.0", "type": "skill", "security_status": "pass"},
            {"version": "1.1.0", "type": "skill", "security_status": "pass"},
        ]

        def check_edited_side_effect(slug, pins, pins_path):
            return slug == "edited-skill"

        pins_file = str(tmp_path / "pins.json")
        # User declines the bulk confirm for clean skills
        with (
            patch("agentpowers_cli.commands.update._check_edited",
                side_effect=check_edited_side_effect),
            patch("agentpowers_cli.commands.update.typer.confirm",
                return_value=False) as _mock_confirm,
        ):
            result = runner.invoke(app, ["update", "--pins-path", pins_file])

        assert result.exit_code == 0
        assert "cancelled" in result.output.lower()
        mock_download.assert_not_called()


class TestUpdateHelpers:
    """Tests for helper functions in the update module."""

    def test_compare_versions_behind(self) -> None:
        """Installed version behind latest returns True."""
        from agentpowers_cli.commands.update import _compare_versions

        assert _compare_versions("1.0.0", "1.0.1") is True
        assert _compare_versions("1.0.0", "2.0.0") is True
        assert _compare_versions("0.9.9", "1.0.0") is True

    def test_compare_versions_current(self) -> None:
        """Same version returns False."""
        from agentpowers_cli.commands.update import _compare_versions

        assert _compare_versions("1.0.0", "1.0.0") is False

    def test_compare_versions_ahead(self) -> None:
        """Installed version ahead of latest returns False."""
        from agentpowers_cli.commands.update import _compare_versions

        assert _compare_versions("2.0.0", "1.0.0") is False

    def test_compare_versions_invalid(self) -> None:
        """Invalid version strings return False."""
        from agentpowers_cli.commands.update import _compare_versions

        assert _compare_versions("abc", "1.0.0") is False
        assert _compare_versions("1.0.0", "xyz") is False


class TestUpdateFixesStalePins:
    """ap update should rehash and fix stale pins when skill is up-to-date."""

    @patch("agentpowers_cli.commands.update.save_pin")
    @patch("agentpowers_cli.commands.update._check_edited", return_value=False)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_up_to_date_stale_hash_gets_fixed(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        mock_save: MagicMock,
        tmp_path: Path,
    ) -> None:
        """When version is current but pin hash differs from disk, save_pin fixes it."""
        mock_pins.return_value = {
            "my-skill": _pin(version="1.0.0", content_hash="sha256:stale_wrong_hash")
        }
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {
            "version": "1.0.0",
            "type": "skill",
            "security_status": "pass",
        }

        # Create a fake install directory so _fix_stale_pin can find it
        fake_claude = tmp_path / "fakehome" / ".claude" / "skills" / "my-skill"
        fake_claude.mkdir(parents=True)
        (fake_claude / "SKILL.md").write_text("# Hello")

        pins_file = str(tmp_path / "pins.json")
        with patch("agentpowers_cli.commands.update.Path.home",
             return_value=tmp_path / "fakehome"):
            result = runner.invoke(
                app, ["update", "my-skill", "--pins-path", pins_file],
            )

        assert result.exit_code == 0
        assert "up to date" in result.output
        mock_save.assert_called_once()
        call_kwargs = mock_save.call_args[1]
        assert call_kwargs["slug"] == "my-skill"
        assert call_kwargs["source"] == "agentpowers"
        assert call_kwargs["version"] == "1.0.0"
        assert call_kwargs["content_hash"].startswith("sha256:")
        assert call_kwargs["content_hash"] != "sha256:stale_wrong_hash"
        assert call_kwargs["security_status"] == "pass"

    @patch("agentpowers_cli.commands.update.save_pin")
    @patch("agentpowers_cli.commands.update._check_edited", return_value=False)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_up_to_date_correct_hash_no_save(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        mock_save: MagicMock,
        tmp_path: Path,
    ) -> None:
        """When version is current and pin hash matches disk, no save needed."""
        # Create the directory first to compute the real hash
        fake_claude = tmp_path / "fakehome" / ".claude" / "skills" / "my-skill"
        fake_claude.mkdir(parents=True)
        (fake_claude / "SKILL.md").write_text("# Hello")
        from agentpowers_cli.services.content_hasher import hash_directory
        real_hash = hash_directory(str(fake_claude))

        mock_pins.return_value = {
            "my-skill": _pin(version="1.0.0", content_hash=real_hash)
        }
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {
            "version": "1.0.0",
            "type": "skill",
            "security_status": "pass",
        }

        pins_file = str(tmp_path / "pins.json")
        with patch("agentpowers_cli.commands.update.Path.home",
             return_value=tmp_path / "fakehome"):
            result = runner.invoke(
                app, ["update", "my-skill", "--pins-path", pins_file],
            )

        assert result.exit_code == 0
        assert "up to date" in result.output
        mock_save.assert_not_called()

    @patch("agentpowers_cli.commands.update.save_pin")
    @patch("agentpowers_cli.commands.update._check_edited", return_value=False)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_external_up_to_date_stale_hash_gets_fixed(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        mock_save: MagicMock,
        tmp_path: Path,
    ) -> None:
        """External skill up-to-date with stale hash also gets pin fixed."""
        mock_pins.return_value = {
            "ext-skill": _pin(
                source="clawhub",
                version="2.0.0",
                content_hash="sha256:stale_ext_hash",
            )
        }
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {
            "version": "2.0.0",
            "type": "skill",
            "security_status": "pass",
        }

        fake_claude = tmp_path / "fakehome" / ".claude" / "skills" / "ext-skill"
        fake_claude.mkdir(parents=True)
        (fake_claude / "SKILL.md").write_text("# External")

        pins_file = str(tmp_path / "pins.json")
        with patch("agentpowers_cli.commands.update.Path.home",
             return_value=tmp_path / "fakehome"):
            result = runner.invoke(
                app, ["update", "ext-skill", "--pins-path", pins_file],
            )

        assert result.exit_code == 0
        assert "up to date" in result.output
        mock_save.assert_called_once()
        call_kwargs = mock_save.call_args[1]
        assert call_kwargs["slug"] == "ext-skill"
        assert call_kwargs["source"] == "clawhub"
        assert call_kwargs["content_hash"] != "sha256:stale_ext_hash"

    @patch("agentpowers_cli.commands.update.save_pin")
    @patch("agentpowers_cli.commands.update._check_edited", return_value=False)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_up_to_date_no_install_dir_no_save(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        mock_save: MagicMock,
        tmp_path: Path,
    ) -> None:
        """If install directory doesn't exist, don't save a bad pin."""
        mock_pins.return_value = {
            "missing-skill": _pin(version="1.0.0", content_hash="sha256:stale")
        }
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {
            "version": "1.0.0",
            "type": "skill",
            "security_status": "pass",
        }

        # Don't create any install directory — fakehome/.claude/skills/missing-skill
        # doesn't exist
        fake_claude = tmp_path / "fakehome" / ".claude"
        fake_claude.mkdir(parents=True)

        pins_file = str(tmp_path / "pins.json")
        with patch("agentpowers_cli.commands.update.Path.home",
             return_value=tmp_path / "fakehome"):
            result = runner.invoke(
                app, ["update", "missing-skill", "--pins-path", pins_file],
            )

        assert result.exit_code == 0
        assert "up to date" in result.output
        mock_save.assert_not_called()


class TestEditedSameVersion:
    """Tests for edited skill at same version — should warn, not silently rehash."""

    @patch("agentpowers_cli.commands.update._fix_stale_pin")
    @patch("agentpowers_cli.commands.update._check_edited", return_value=True)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_same_version_edited_warns_user(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        mock_fix_pin: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Same version + edited → warns user about local edits."""
        mock_pins.return_value = {"test-skill": _pin(version="1.0.0")}
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {
            "version": "1.0.0",
            "type": "skill",
            "security_status": "pass",
        }

        pins_file = str(tmp_path / "pins.json")
        with patch("agentpowers_cli.commands.update.typer.confirm", return_value=False):
            result = runner.invoke(
                app, ["update", "test-skill", "--pins-path", pins_file],
            )

        assert result.exit_code == 0
        assert "locally edited" in result.output
        assert "Skipping" in result.output
        # Should NOT silently rehash the pin
        mock_fix_pin.assert_not_called()

    @patch("agentpowers_cli.commands.update.save_pin")
    @patch("agentpowers_cli.commands.update._download_and_install")
    @patch("agentpowers_cli.commands.update._check_edited", return_value=True)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_same_version_edited_force_redownloads(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        mock_download: MagicMock,
        mock_save: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Same version + edited + --force → re-downloads to restore original."""
        mock_pins.return_value = {"test-skill": _pin(version="1.0.0")}
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {
            "version": "1.0.0",
            "type": "skill",
            "security_status": "pass",
        }
        mock_download.return_value = ("/path/to/dest", b"zip-data")

        pins_file = str(tmp_path / "pins.json")
        result = runner.invoke(
            app, ["update", "test-skill", "--force", "--pins-path", pins_file],
        )

        assert result.exit_code == 0
        mock_download.assert_called_once()
        # Should re-download and save pin with correct hash
        assert "Restored" in result.output or "Updated" in result.output

    @patch("agentpowers_cli.commands.update._fix_stale_pin")
    @patch("agentpowers_cli.commands.update._check_edited", return_value=True)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_same_version_edited_user_declines_skips(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        mock_fix_pin: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Same version + edited + user declines → keeps edits, no rehash."""
        mock_pins.return_value = {"test-skill": _pin(version="1.0.0")}
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {
            "version": "1.0.0",
            "type": "skill",
            "security_status": "pass",
        }

        pins_file = str(tmp_path / "pins.json")
        with patch("agentpowers_cli.commands.update.typer.confirm", return_value=False):
            result = runner.invoke(
                app, ["update", "test-skill", "--pins-path", pins_file],
            )

        assert result.exit_code == 0
        assert "Skipping" in result.output
        mock_fix_pin.assert_not_called()


class TestExternalEditedSameVersion:
    """Tests for external skill edited at same version — same bug as native path."""

    @patch("agentpowers_cli.commands.update._fix_stale_pin")
    @patch("agentpowers_cli.commands.update._check_edited", return_value=True)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_external_same_version_edited_warns_user(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        mock_fix_pin: MagicMock,
        tmp_path: Path,
    ) -> None:
        """External skill: same version + edited → warns user, does NOT rehash."""
        mock_pins.return_value = {
            "ext-skill": _pin(source="clawhub", version="2.0.0")
        }
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {
            "version": "2.0.0",
            "type": "skill",
            "security_status": "pass",
        }

        pins_file = str(tmp_path / "pins.json")
        with patch("agentpowers_cli.commands.update.typer.confirm", return_value=False):
            result = runner.invoke(
                app, ["update", "ext-skill", "--pins-path", pins_file],
            )

        assert result.exit_code == 0
        assert "locally edited" in result.output
        assert "Skipping" in result.output
        mock_fix_pin.assert_not_called()

    @patch("agentpowers_cli.commands.update.install_external_skill")
    @patch("agentpowers_cli.commands.update._check_edited", return_value=True)
    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_external_same_version_edited_force_reinstalls(
        self,
        mock_client_fn: MagicMock,
        mock_pins: MagicMock,
        mock_edited: MagicMock,
        mock_ext_install: MagicMock,
        tmp_path: Path,
    ) -> None:
        """External skill: same version + edited + --force → re-installs."""
        mock_pins.return_value = {
            "ext-skill": _pin(source="clawhub", version="2.0.0")
        }
        client = MagicMock()
        mock_client_fn.return_value = client
        client.get.return_value = {
            "version": "2.0.0",
            "type": "skill",
            "security_status": "pass",
        }

        pins_file = str(tmp_path / "pins.json")
        result = runner.invoke(
            app, ["update", "ext-skill", "--force", "--pins-path", pins_file]
        )

        assert result.exit_code == 0
        mock_ext_install.assert_called_once()
        assert "Restored" in result.output or "Updated" in result.output
