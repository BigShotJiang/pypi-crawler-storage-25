"""Tests for ap verify command."""

import json
from unittest.mock import patch

from typer.testing import CliRunner

from agentpowers_cli.main import app

runner = CliRunner()


def test_verify_all_pass(tmp_path):
    pins_path = tmp_path / "pins.json"
    skill_dir = tmp_path / ".claude" / "skills" / "my-skill"
    skill_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text("# My Skill")

    from agentpowers_cli.services.content_hasher import hash_directory

    h = hash_directory(str(skill_dir))
    pins_path.write_text(
        json.dumps({"my-skill": {"content_hash": h, "source": "clawhub"}})
    )

    with patch("agentpowers_cli.commands.verify.DEFAULT_PINS_PATH", str(pins_path)):
        with patch(
            "agentpowers_cli.commands.verify.get_claude_dir",
            return_value=tmp_path / ".claude",
        ):
            result = runner.invoke(app, ["verify"])

    assert result.exit_code == 0
    assert "my-skill" in result.output
    assert "OK" in result.output or "pass" in result.output.lower()


def test_verify_hash_mismatch(tmp_path):
    """Detect modified files after install."""
    pins_path = tmp_path / "pins.json"
    skill_dir = tmp_path / ".claude" / "skills" / "tampered"
    skill_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text("# Original")

    pins_path.write_text(
        json.dumps(
            {"tampered": {"content_hash": "sha256:wrong", "source": "clawhub"}}
        )
    )

    with patch("agentpowers_cli.commands.verify.DEFAULT_PINS_PATH", str(pins_path)):
        with patch(
            "agentpowers_cli.commands.verify.get_claude_dir",
            return_value=tmp_path / ".claude",
        ):
            result = runner.invoke(app, ["verify"])

    assert result.exit_code == 1
    assert "tampered" in result.output
    assert "FAIL" in result.output or "mismatch" in result.output.lower()


def test_verify_missing_skill(tmp_path):
    """Pinned skill no longer on disk."""
    pins_path = tmp_path / "pins.json"
    (tmp_path / ".claude" / "skills").mkdir(parents=True)
    pins_path.write_text(
        json.dumps(
            {"gone-skill": {"content_hash": "sha256:x", "source": "clawhub"}}
        )
    )

    with patch("agentpowers_cli.commands.verify.DEFAULT_PINS_PATH", str(pins_path)):
        with patch(
            "agentpowers_cli.commands.verify.get_claude_dir",
            return_value=tmp_path / ".claude",
        ):
            result = runner.invoke(app, ["verify"])

    assert result.exit_code == 1
    assert "gone-skill" in result.output
    assert "MISSING" in result.output or "not found" in result.output.lower()


def test_verify_no_pins(tmp_path):
    """No pins file = nothing to verify."""
    with patch(
        "agentpowers_cli.commands.verify.DEFAULT_PINS_PATH",
        str(tmp_path / "nope.json"),
    ):
        result = runner.invoke(app, ["verify"])

    assert result.exit_code == 0
    assert "no installed" in result.output.lower() or "nothing" in result.output.lower()
