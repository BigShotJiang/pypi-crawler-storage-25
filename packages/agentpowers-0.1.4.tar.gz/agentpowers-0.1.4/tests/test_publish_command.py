"""Tests for the publish command and packager service."""

from __future__ import annotations

import zipfile
from io import BytesIO
from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from agentpowers_cli.main import app
from agentpowers_cli.services.packager import load_skill_metadata, package_directory

runner = CliRunner()

SKILL_FRONTMATTER = """\
---
name: my-cool-skill
description: A really cool skill
---

# My Cool Skill

Instructions here.
"""

AGENT_FRONTMATTER = """\
---
name: my-agent
description: An autonomous agent
tools: Read, Glob, Grep, Bash
model: sonnet
---

You are an autonomous agent that helps with tasks.
"""

AGENT_FRONTMATTER_MINIMAL = """\
---
name: my-agent
description: An autonomous agent
---

Agent instructions.
"""


# ---------------------------------------------------------------------------
# Packager service tests
# ---------------------------------------------------------------------------


class TestPackageSkillDirectory:
    """Tests for the package_directory function."""

    def test_package_skill_directory(self, tmp_path: Path) -> None:
        """Package a directory with SKILL.md and README.md into a ZIP."""
        (tmp_path / "SKILL.md").write_text(SKILL_FRONTMATTER)
        (tmp_path / "README.md").write_text("# Readme")

        zip_bytes = package_directory(tmp_path)

        with zipfile.ZipFile(BytesIO(zip_bytes)) as zf:
            names = zf.namelist()
            assert "SKILL.md" in names
            assert "README.md" in names

    def test_package_excludes_hidden_dirs(self, tmp_path: Path) -> None:
        """Hidden directories like .git are excluded from the package."""
        git_dir = tmp_path / ".git"
        git_dir.mkdir()
        (git_dir / "config").write_text("git config")
        (tmp_path / "data.txt").write_text("data")

        zip_bytes = package_directory(tmp_path)

        with zipfile.ZipFile(BytesIO(zip_bytes)) as zf:
            names = zf.namelist()
            assert "data.txt" in names
            assert not any(".git" in name for name in names)


class TestLoadSkillMetadata:
    """Tests for the load_skill_metadata function."""

    def test_load_skill_metadata_from_skill_md(self, tmp_path: Path) -> None:
        """SKILL.md frontmatter is parsed with type='skill'."""
        (tmp_path / "SKILL.md").write_text(SKILL_FRONTMATTER)

        meta = load_skill_metadata(tmp_path)

        assert meta is not None
        assert meta["name"] == "my-cool-skill"
        assert meta["description"] == "A really cool skill"
        assert meta["type"] == "skill"

    def test_load_agent_metadata_from_frontmatter_md(self, tmp_path: Path) -> None:
        """An .md file with name+description frontmatter is detected as agent."""
        (tmp_path / "code-reviewer.md").write_text(AGENT_FRONTMATTER)

        meta = load_skill_metadata(tmp_path)

        assert meta is not None
        assert meta["name"] == "my-agent"
        assert meta["description"] == "An autonomous agent"
        assert meta["type"] == "agent"
        assert meta["tools"] == "Read, Glob, Grep, Bash"

    def test_load_agent_metadata_minimal_frontmatter(self, tmp_path: Path) -> None:
        """Agent with only name+description (no tools) is still detected."""
        (tmp_path / "helper.md").write_text(AGENT_FRONTMATTER_MINIMAL)

        meta = load_skill_metadata(tmp_path)

        assert meta is not None
        assert meta["name"] == "my-agent"
        assert meta["type"] == "agent"

    def test_skill_md_takes_priority_over_agent(self, tmp_path: Path) -> None:
        """SKILL.md is preferred over agent .md files."""
        (tmp_path / "SKILL.md").write_text(SKILL_FRONTMATTER)
        (tmp_path / "code-reviewer.md").write_text(AGENT_FRONTMATTER)

        meta = load_skill_metadata(tmp_path)

        assert meta is not None
        assert meta["type"] == "skill"
        assert meta["name"] == "my-cool-skill"

    def test_load_metadata_missing_skill_file(self, tmp_path: Path) -> None:
        """Returns None when no SKILL.md or agent .md exists."""
        (tmp_path / "README.md").write_text("# Just a readme")

        meta = load_skill_metadata(tmp_path)

        assert meta is None

    def test_md_without_frontmatter_not_detected(self, tmp_path: Path) -> None:
        """A plain .md file without frontmatter is not detected as agent."""
        (tmp_path / "notes.md").write_text("# Just some notes\n\nNo frontmatter.")

        meta = load_skill_metadata(tmp_path)

        assert meta is None

    def test_md_with_partial_frontmatter_not_detected(self, tmp_path: Path) -> None:
        """An .md file with frontmatter missing description is not an agent."""
        partial = "---\nname: incomplete\n---\n\nMissing description field.\n"
        (tmp_path / "incomplete.md").write_text(partial)

        meta = load_skill_metadata(tmp_path)

        assert meta is None


# ---------------------------------------------------------------------------
# Publish command tests
# ---------------------------------------------------------------------------


class TestPublishCommand:
    """Tests for the `ap publish` CLI command."""

    @patch(
        "agentpowers_cli.commands.publish.package_directory",
        return_value=b"fake-zip",
    )
    @patch("agentpowers_cli.commands.publish.load_skill_metadata")
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_publish_success(
        self,
        mock_get_client: MagicMock,
        mock_load_meta: MagicMock,
        mock_package: MagicMock,
    ) -> None:
        """Successful publish exits with code 0."""
        mock_load_meta.return_value = {
            "name": "my-skill",
            "description": "A skill",
            "type": "skill",
        }
        client = MagicMock()
        mock_get_client.return_value = client
        client.post.return_value = {"slug": "my-skill"}
        client.upload.return_value = {"status": "ok"}

        result = runner.invoke(app, ["publish"])

        assert result.exit_code == 0
        assert "my-skill" in result.output
        client.post.assert_called_once()
        client.upload.assert_called_once()

    @patch("agentpowers_cli.commands.publish.load_skill_metadata", return_value=None)
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_publish_no_skill_file(
        self,
        mock_get_client: MagicMock,
        mock_load_meta: MagicMock,
    ) -> None:
        """Missing metadata file exits with code 1 and error message."""
        result = runner.invoke(app, ["publish"])

        assert result.exit_code == 1
        assert "No skill found" in result.output
        assert "name/description frontmatter" in result.output
