"""Tests for content_hasher -- hash_directory OS artifact exclusion."""

from __future__ import annotations

from pathlib import Path

from agentpowers_cli.services.content_hasher import hash_directory


class TestHashDirectoryExcludesOSArtifacts:
    """hash_directory must ignore OS-generated files that aren't skill content."""

    def test_ds_store_does_not_change_hash(self, tmp_path: Path) -> None:
        """macOS .DS_Store should be excluded from hash computation."""
        (tmp_path / "SKILL.md").write_text("# Hello")
        h1 = hash_directory(str(tmp_path))

        (tmp_path / ".DS_Store").write_bytes(b"\x00\x00\x00\x01Bud1")
        h2 = hash_directory(str(tmp_path))

        assert h1 == h2

    def test_pycache_dir_does_not_change_hash(self, tmp_path: Path) -> None:
        """__pycache__ directories should be excluded from hash computation."""
        (tmp_path / "main.py").write_text("print('hi')")
        h1 = hash_directory(str(tmp_path))

        cache = tmp_path / "__pycache__"
        cache.mkdir()
        (cache / "main.cpython-310.pyc").write_bytes(b"\x00\x00\x00\x00")
        h2 = hash_directory(str(tmp_path))

        assert h1 == h2

    def test_thumbs_db_does_not_change_hash(self, tmp_path: Path) -> None:
        """Windows Thumbs.db should be excluded from hash computation."""
        (tmp_path / "SKILL.md").write_text("# Hello")
        h1 = hash_directory(str(tmp_path))

        (tmp_path / "Thumbs.db").write_bytes(b"\x00\x00")
        h2 = hash_directory(str(tmp_path))

        assert h1 == h2

    def test_pyc_files_do_not_change_hash(self, tmp_path: Path) -> None:
        """.pyc files at any level should be excluded."""
        (tmp_path / "module.py").write_text("x = 1")
        h1 = hash_directory(str(tmp_path))

        (tmp_path / "module.pyc").write_bytes(b"\x00\x00")
        h2 = hash_directory(str(tmp_path))

        assert h1 == h2

    def test_nested_ds_store_excluded(self, tmp_path: Path) -> None:
        """.DS_Store in subdirectories also excluded."""
        sub = tmp_path / "lib"
        sub.mkdir()
        (sub / "util.py").write_text("pass")
        h1 = hash_directory(str(tmp_path))

        (sub / ".DS_Store").write_bytes(b"\x00\x00\x00\x01Bud1")
        h2 = hash_directory(str(tmp_path))

        assert h1 == h2

    def test_actual_content_changes_detected(self, tmp_path: Path) -> None:
        """Real content changes DO affect the hash (sanity check)."""
        (tmp_path / "SKILL.md").write_text("# Version 1")
        h1 = hash_directory(str(tmp_path))

        (tmp_path / "SKILL.md").write_text("# Version 2")
        h2 = hash_directory(str(tmp_path))

        assert h1 != h2

    def test_new_real_file_changes_hash(self, tmp_path: Path) -> None:
        """Adding a real skill file changes the hash (sanity check)."""
        (tmp_path / "SKILL.md").write_text("# Hello")
        h1 = hash_directory(str(tmp_path))

        (tmp_path / "helper.py").write_text("def foo(): pass")
        h2 = hash_directory(str(tmp_path))

        assert h1 != h2
