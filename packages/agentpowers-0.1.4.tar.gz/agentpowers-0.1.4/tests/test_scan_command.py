"""Tests for the ap scan command."""

import io
import zipfile
from unittest.mock import MagicMock, patch

import click.exceptions
import httpx
import pytest

from agentpowers_cli.commands.scan import _NativeSkillError, _resolve_source, scan
from agentpowers_cli.services.api_client import APIError


def _make_zip(files: dict[str, str]) -> bytes:
    """Create a valid ZIP archive from a dict of filename -> content."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, content in files.items():
            zf.writestr(name, content)
    return buf.getvalue()


@patch("agentpowers_cli.commands.scan.get_api_client")
@patch("agentpowers_cli.commands.scan._download_to_sandbox")
@patch("agentpowers_cli.commands.scan._upload_for_scan")
def test_scan_pass(mock_upload, mock_download, mock_client, tmp_path, capsys):
    """ap scan <slug> shows pass result and cleans up sandbox."""
    # Setup sandbox with a skill file
    sandbox = tmp_path / "sandbox"
    sandbox.mkdir()
    (sandbox / "SKILL.md").write_text("# Test Skill")
    mock_download.return_value = (str(sandbox), "clawhub")

    mock_upload.return_value = {
        "content_hash": "sha256:abc123",
        "security_status": "pass",
        "security_score": 0,
        "findings": [],
    }

    scan(slug="test-skill")

    # Verify download was called
    mock_download.assert_called_once()
    # Verify upload was called with sandbox path
    mock_upload.assert_called_once()


@patch("agentpowers_cli.commands.scan.get_api_client")
@patch("agentpowers_cli.commands.scan._download_to_sandbox")
@patch("agentpowers_cli.commands.scan._upload_for_scan")
def test_scan_warn(mock_upload, mock_download, mock_client, tmp_path):
    """ap scan shows warnings when security_status is warn."""
    sandbox = tmp_path / "sandbox"
    sandbox.mkdir()
    (sandbox / "SKILL.md").write_text("# Warn Skill")
    mock_download.return_value = (str(sandbox), "clawhub")

    mock_upload.return_value = {
        "content_hash": "sha256:def456",
        "security_status": "warn",
        "security_score": 4,
        "findings": [{"type": "warning", "message": "Suspicious pattern"}],
    }

    scan(slug="warn-skill")

    mock_upload.assert_called_once()


@patch("agentpowers_cli.commands.scan.get_api_client")
@patch("agentpowers_cli.commands.scan._download_to_sandbox")
@patch("agentpowers_cli.commands.scan._upload_for_scan")
def test_scan_block(mock_upload, mock_download, mock_client, tmp_path):
    """ap scan shows block result and exits with code 1."""
    sandbox = tmp_path / "sandbox"
    sandbox.mkdir()
    (sandbox / "SKILL.md").write_text("# Evil Skill")
    mock_download.return_value = (str(sandbox), "clawhub")

    mock_upload.return_value = {
        "content_hash": "sha256:evil789",
        "security_status": "block",
        "security_score": 10,
        "findings": [{"type": "critical", "message": "Malware detected"}],
    }

    with pytest.raises(click.exceptions.Exit) as exc_info:
        scan(slug="evil-skill")
    assert exc_info.value.exit_code == 1


@patch("agentpowers_cli.commands.scan.get_api_client")
@patch("agentpowers_cli.commands.scan._download_to_sandbox")
def test_scan_download_failure(mock_download, mock_client):
    """ap scan exits with error when download fails."""
    mock_download.side_effect = RuntimeError("npx failed")

    with pytest.raises(click.exceptions.Exit) as exc_info:
        scan(slug="broken-skill")
    assert exc_info.value.exit_code == 1


@patch("agentpowers_cli.commands.scan.get_api_client")
@patch("agentpowers_cli.commands.scan._resolve_source")
def test_scan_not_found(mock_resolve, mock_client):
    """ap scan exits with error when skill not found in any source."""
    mock_resolve.return_value = None

    with pytest.raises(click.exceptions.Exit) as exc_info:
        scan(slug="nonexistent-skill", source=None)
    assert exc_info.value.exit_code == 1


@patch("agentpowers_cli.commands.scan.get_api_client")
@patch("agentpowers_cli.commands.scan._download_to_sandbox")
@patch("agentpowers_cli.commands.scan._upload_for_scan")
def test_scan_cleans_up_sandbox(mock_upload, mock_download, mock_client, tmp_path):
    """ap scan cleans up the sandbox directory after completion."""
    sandbox = tmp_path / "sandbox"
    sandbox.mkdir()
    (sandbox / "SKILL.md").write_text("# Cleanup Test")
    mock_download.return_value = (str(sandbox), "clawhub")

    mock_upload.return_value = {
        "content_hash": "sha256:cleanup",
        "security_status": "pass",
        "security_score": 0,
        "findings": [],
    }

    scan(slug="cleanup-skill")

    # Sandbox should be cleaned up
    assert not sandbox.exists()


@patch("agentpowers_cli.commands.scan.get_api_client")
@patch("agentpowers_cli.commands.scan._download_to_sandbox")
@patch("agentpowers_cli.commands.scan._upload_for_scan")
def test_scan_uses_server_hash(mock_upload, mock_download, mock_client, tmp_path):
    """ap scan displays the server-computed hash, not any client-side hash."""
    sandbox = tmp_path / "sandbox"
    sandbox.mkdir()
    (sandbox / "SKILL.md").write_text("# Hash Test")
    mock_download.return_value = (str(sandbox), "clawhub")

    mock_upload.return_value = {
        "content_hash": "sha256:server-computed-hash",
        "security_status": "pass",
        "security_score": 0,
        "findings": [],
    }

    scan(slug="hash-skill")

    # The upload function should have been called (we verify it sends to server)
    mock_upload.assert_called_once()


class TestResolveSource:
    """Tests for the _resolve_source helper."""

    def test_native_skill_raises_error(self):
        """_resolve_source raises _NativeSkillError for native AgentPowers skills."""
        client = MagicMock()
        client.get.return_value = {
            "agentpowers": {
                "items": [{"slug": "hello-world-test", "title": "Hello World"}],
                "total": 1,
            },
        }
        with pytest.raises(_NativeSkillError) as exc_info:
            _resolve_source(client, "hello-world-test")
        assert exc_info.value.slug == "hello-world-test"

    def test_external_skill_returns_source(self):
        """_resolve_source returns source name for external skills."""
        client = MagicMock()
        client.get.return_value = {
            "agentpowers": {"items": [], "total": 0},
            "clawhub": {
                "items": [{"slug": "ext-skill", "title": "External Skill"}],
                "total": 1,
            },
        }
        result = _resolve_source(client, "ext-skill")
        assert result == "clawhub"

    def test_not_found_returns_none(self):
        """_resolve_source returns None when slug not found anywhere."""
        client = MagicMock()
        client.get.return_value = {
            "agentpowers": {"items": [], "total": 0},
            "clawhub": {"items": [], "total": 0},
        }
        result = _resolve_source(client, "nonexistent")
        assert result is None

    def test_timeout_returns_none(self):
        """_resolve_source returns None on httpx.TimeoutException."""
        client = MagicMock()
        client.get.side_effect = httpx.ReadTimeout("timed out")
        result = _resolve_source(client, "any-skill")
        assert result is None

    def test_connect_error_returns_none(self):
        """_resolve_source returns None on httpx.ConnectError."""
        client = MagicMock()
        client.get.side_effect = httpx.ConnectError("connection refused")
        result = _resolve_source(client, "any-skill")
        assert result is None

    def test_api_error_returns_none(self):
        """_resolve_source returns None on APIError."""
        client = MagicMock()
        client.get.side_effect = APIError("Server error", status_code=500)
        result = _resolve_source(client, "any-skill")
        assert result is None


class TestScanNativeSkill:
    """Tests for ap scan handling of native AgentPowers skills."""

    @patch("agentpowers_cli.commands.scan.get_api_client")
    @patch("agentpowers_cli.commands.scan._resolve_source")
    def test_native_skill_exits_zero(self, mock_resolve, mock_client):
        """ap scan exits with code 0 and helpful message for native skills."""
        mock_resolve.side_effect = _NativeSkillError("hello-world-test")

        with pytest.raises(click.exceptions.Exit) as exc_info:
            scan(slug="hello-world-test", source=None)
        assert exc_info.value.exit_code == 0
