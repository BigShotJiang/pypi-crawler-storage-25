"""Tests for the DISPLAY_NAME_REQUIRED inline-prompt flow in `ap publish`."""

from __future__ import annotations

from unittest.mock import MagicMock, call, patch

from typer.testing import CliRunner

from agentpowers_cli.main import app
from agentpowers_cli.services.api_client import APIError

runner = CliRunner()

_METADATA = {"name": "my-skill", "description": "desc", "type": "skill"}
_SKILL_PAYLOAD = {
    "slug": "my-skill",
    "title": "my-skill",
    "description": "desc",
    "category": "development",
    "type": "skill",
    "price_cents": 0,
}


@patch(
    "agentpowers_cli.commands.publish.package_directory",
    return_value=b"fake zip data",
)
@patch("agentpowers_cli.commands.publish.load_skill_metadata", return_value=_METADATA)
@patch("agentpowers_cli.commands.publish.get_api_client")
def test_publish_display_name_required_prompts_and_retries(
    mock_get_client: MagicMock,
    mock_load_meta: MagicMock,
    mock_package: MagicMock,
) -> None:
    """When the API returns DISPLAY_NAME_REQUIRED, the user is prompted for a
    display name and the POST is retried — ending in a successful publish."""
    client = MagicMock()
    mock_get_client.return_value = client

    # First POST raises DISPLAY_NAME_REQUIRED; second POST succeeds.
    client.post.side_effect = [
        APIError("DISPLAY_NAME_REQUIRED", status_code=400),
        {"slug": "my-skill"},
    ]
    client.patch.return_value = {"display_name": "New User"}
    client.upload.return_value = {}

    result = runner.invoke(app, ["publish"], input="New User\n")

    assert result.exit_code == 0, result.output
    assert "Display name set to 'New User'" in result.output
    assert "Published" in result.output

    # PATCH for profile update called once
    client.patch.assert_called_once_with(
        "/v1/users/profile",
        json_data={"display_name": "New User"},
        auth=True,
    )

    # POST called twice: first attempt + retry
    assert client.post.call_count == 2
    client.post.assert_called_with("/v1/skills", json_data=_SKILL_PAYLOAD, auth=True)

    # Upload called once
    client.upload.assert_called_once()


@patch(
    "agentpowers_cli.commands.publish.package_directory",
    return_value=b"fake zip data",
)
@patch("agentpowers_cli.commands.publish.load_skill_metadata", return_value=_METADATA)
@patch("agentpowers_cli.commands.publish.get_api_client")
def test_publish_display_name_required_invalid_loops(
    mock_get_client: MagicMock,
    mock_load_meta: MagicMock,
    mock_package: MagicMock,
) -> None:
    """A 422 validation error from the profile PATCH keeps the loop alive,
    and a subsequent valid display name leads to a successful publish."""
    client = MagicMock()
    mock_get_client.return_value = client

    client.post.side_effect = [
        APIError("DISPLAY_NAME_REQUIRED", status_code=400),
        {"slug": "my-skill"},
    ]
    # First PATCH raises 422; second PATCH succeeds.
    client.patch.side_effect = [
        APIError("Invalid display name format", status_code=422),
        {"display_name": "Valid Name"},
    ]
    client.upload.return_value = {}

    result = runner.invoke(app, ["publish"], input="!!\nValid Name\n")

    assert result.exit_code == 0, result.output
    assert "Invalid display name" in result.output
    assert "Display name set to 'Valid Name'" in result.output
    assert "Published" in result.output


@patch(
    "agentpowers_cli.commands.publish.package_directory",
    return_value=b"fake zip data",
)
@patch("agentpowers_cli.commands.publish.load_skill_metadata", return_value=_METADATA)
@patch("agentpowers_cli.commands.publish.get_api_client")
def test_publish_display_name_required_retry_409_becomes_update(
    mock_get_client: MagicMock,
    mock_load_meta: MagicMock,
    mock_package: MagicMock,
) -> None:
    """After DISPLAY_NAME_REQUIRED + display name set, if the retry POST returns
    409 (slug already exists) the command transitions into update mode."""
    client = MagicMock()
    mock_get_client.return_value = client

    client.post.side_effect = [
        APIError("DISPLAY_NAME_REQUIRED", status_code=400),
        APIError("Conflict", status_code=409),  # retry → treat as update
    ]
    client.patch.side_effect = [
        {"display_name": "New User"},   # profile update
        {"new_version": "1.0.1"},       # skill version bump
    ]
    client.upload.return_value = {}

    result = runner.invoke(app, ["publish"], input="New User\n")

    assert result.exit_code == 0, result.output
    assert "Display name set to 'New User'" in result.output
    # Should have fallen through to update path
    assert "1.0.1" in result.output or "Updated" in result.output


@patch(
    "agentpowers_cli.commands.publish.package_directory",
    return_value=b"fake zip data",
)
@patch("agentpowers_cli.commands.publish.load_skill_metadata", return_value=_METADATA)
@patch("agentpowers_cli.commands.publish.get_api_client")
def test_publish_display_name_required_empty_loops(
    mock_get_client: MagicMock,
    mock_load_meta: MagicMock,
    mock_package: MagicMock,
) -> None:
    """Empty display name input loops until a non-empty value is entered."""
    client = MagicMock()
    mock_get_client.return_value = client

    client.post.side_effect = [
        APIError("DISPLAY_NAME_REQUIRED", status_code=400),
        {"slug": "my-skill"},
    ]
    client.patch.return_value = {"display_name": "Real Name"}
    client.upload.return_value = {}

    # First input is empty, second is valid
    result = runner.invoke(app, ["publish"], input="\nReal Name\n")

    assert result.exit_code == 0, result.output
    assert "Display name set to 'Real Name'" in result.output
    assert "Published" in result.output
