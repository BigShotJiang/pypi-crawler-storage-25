"""Tests for the search command."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from agentpowers_cli.main import app

runner = CliRunner()

# All tests mock _get_installed_slugs to avoid filesystem access.
# The "installed" decorator must come BEFORE get_api_client (outermost = last arg).
_NO_INSTALLS = patch(
    "agentpowers_cli.commands.search._get_installed_slugs", return_value={}
)


def _make_mock_client(return_value: dict) -> MagicMock:
    """Create a mock APIClient that returns the given value from get().

    Args:
        return_value: The dict to return from client.get().

    Returns:
        A configured MagicMock.
    """
    mock_client = MagicMock()
    mock_client.get.return_value = return_value
    return mock_client


def _sectioned(native_items=None, clawhub_items=None):
    """Build a sectioned search response."""
    return {
        "agentpowers": {
            "items": native_items or [],
            "total": len(native_items or []),
            "limit": 20,
            "offset": 0,
        },
        "clawhub": {
            "total": len(clawhub_items or []),
            "items": clawhub_items or [],
        },
    }


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_with_native_results(mock_get_client: MagicMock, _m) -> None:
    """Search with native results displays slug, price, and source."""
    mock_client = _make_mock_client(
        _sectioned(
            native_items=[
                {
                    "slug": "code-reviewer",
                    "title": "Code Reviewer",
                    "type": "skill",
                    "category": "dev-tools",
                    "price_cents": 1200,
                    "download_count": 42,
                    "security_status": "pass",
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "reviewer"])

    assert result.exit_code == 0
    assert "code-reviewer" in result.output
    assert "$12" in result.output
    # Source may be truncated by Rich table width
    assert "agentpow" in result.output


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_native_title_shows_downloads(mock_get_client: MagicMock, _m) -> None:
    """Native results show download count inline with title."""
    mock_client = _make_mock_client(
        _sectioned(
            native_items=[
                {
                    "slug": "popular-skill",
                    "title": "Popular Skill",
                    "type": "skill",
                    "category": "dev-tools",
                    "price_cents": 0,
                    "download_count": 99,
                    "security_status": "pass",
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "popular"])

    assert result.exit_code == 0
    # Download count should appear inline with title
    assert "99" in result.output


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_with_external_results(mock_get_client: MagicMock, _m) -> None:
    """External results display with installs/stars inline in title."""
    mock_client = _make_mock_client(
        _sectioned(
            clawhub_items=[
                {
                    "slug": "ext-skill",
                    "title": "External Skill",
                    "source": "clawhub",
                    "source_installs": 500,
                    "source_stars": 42,
                    "version": "1.0.0",
                    "ap_security_status": None,
                    "price_cents": 0,
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "ext"])

    assert result.exit_code == 0
    assert "ext-skill" in result.output
    assert "clawhub" in result.output
    assert "500" in result.output  # Installs inline
    assert "42" in result.output  # Stars inline


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_external_null_fields_show_no_stats(
    mock_get_client: MagicMock, _m
) -> None:
    """External results with null installs/stars show title without stats."""
    mock_client = _make_mock_client(
        _sectioned(
            clawhub_items=[
                {
                    "slug": "stripe-best-practices",
                    "title": "Stripe Best Practices",
                    "source": "clawhub",
                    "source_installs": None,
                    "source_stars": None,
                    "version": None,
                    "ap_security_status": None,
                    "price_cents": 0,
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "stripe"])

    assert result.exit_code == 0
    assert "stripe-best-practices" in result.output
    assert "None" not in result.output


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_no_results(mock_get_client: MagicMock, _m) -> None:
    """Empty results display 'No results found.' message."""
    mock_client = _make_mock_client(_sectioned())
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "nonexistent"])

    assert result.exit_code == 0
    assert "No results found." in result.output


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_free_skill_shows_free(mock_get_client: MagicMock, _m) -> None:
    """A skill with price_cents=0 displays 'Free' in the output."""
    mock_client = _make_mock_client(
        _sectioned(
            native_items=[
                {
                    "slug": "free-tool",
                    "title": "Free Tool",
                    "type": "skill",
                    "category": "utilities",
                    "price_cents": 0,
                    "download_count": 100,
                    "security_status": "pass",
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "free"])

    assert result.exit_code == 0
    assert "Free" in result.output


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_unified_table_has_installs_stars_inline(
    mock_get_client: MagicMock,
    _m,
) -> None:
    """External results show installs and stars inline with title."""
    mock_client = _make_mock_client(
        _sectioned(
            clawhub_items=[
                {
                    "slug": "starry-skill",
                    "title": "Starry",
                    "source": "clawhub",
                    "source_installs": 10,
                    "source_stars": 99,
                    "version": "2.0.0",
                    "ap_security_status": "pass",
                    "price_cents": 0,
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "starry"])

    assert result.exit_code == 0
    assert "99" in result.output
    assert "10" in result.output


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_external_null_stars_no_star_in_title(
    mock_get_client: MagicMock,
    _m,
) -> None:
    """External results with null stars omit star stat from title."""
    mock_client = _make_mock_client(
        _sectioned(
            clawhub_items=[
                {
                    "slug": "no-stars",
                    "title": "No Stars",
                    "source": "clawhub",
                    "source_installs": 5,
                    "source_stars": None,
                    "version": "1.0.0",
                    "ap_security_status": None,
                    "price_cents": 0,
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "no-stars"])

    assert result.exit_code == 0
    assert "5" in result.output  # installs still shown
    assert "None" not in result.output


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_with_category_filter(mock_get_client: MagicMock, _m) -> None:
    """Passing --category includes category in API request params."""
    mock_client = _make_mock_client(_sectioned())
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "test", "--category", "dev-tools"])

    assert result.exit_code == 0
    call_kwargs = mock_client.get.call_args
    params = call_kwargs.kwargs.get("params") or call_kwargs[1].get("params")
    assert params["category"] == "dev-tools"


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_mixed_results_native_first(mock_get_client: MagicMock, _m) -> None:
    """Native items appear before external items in the unified table."""
    mock_client = _make_mock_client(
        _sectioned(
            native_items=[
                {
                    "slug": "native-skill",
                    "title": "Native Skill",
                    "type": "skill",
                    "category": "dev-tools",
                    "price_cents": 0,
                    "download_count": 10,
                    "security_status": "pass",
                },
            ],
            clawhub_items=[
                {
                    "slug": "ext-skill",
                    "title": "External Skill",
                    "source": "clawhub",
                    "source_installs": 5,
                    "source_stars": 3,
                    "version": "1.0.0",
                    "ap_security_status": None,
                    "price_cents": 0,
                },
            ],
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "skill"])

    assert result.exit_code == 0
    assert "native-skill" in result.output
    assert "ext-skill" in result.output
    native_pos = result.output.index("native-skill")
    ext_pos = result.output.index("ext-skill")
    assert native_pos < ext_pos


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_paid_before_free(mock_get_client: MagicMock, _m) -> None:
    """Paid items sort above free items within the same source group."""
    mock_client = _make_mock_client(
        _sectioned(
            native_items=[
                {
                    "slug": "free-skill",
                    "title": "Free Skill",
                    "type": "skill",
                    "category": "dev-tools",
                    "price_cents": 0,
                    "download_count": 100,
                    "security_status": "pass",
                },
                {
                    "slug": "paid-skill",
                    "title": "Paid Skill",
                    "type": "skill",
                    "category": "dev-tools",
                    "price_cents": 500,
                    "download_count": 50,
                    "security_status": "pass",
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "skill"])

    assert result.exit_code == 0
    paid_pos = result.output.index("paid-skill")
    free_pos = result.output.index("free-skill")
    assert paid_pos < free_pos


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_no_category_or_version_columns(mock_get_client: MagicMock, _m) -> None:
    """Unified table does not have Category or Version column headers."""
    mock_client = _make_mock_client(
        _sectioned(
            native_items=[
                {
                    "slug": "some-skill",
                    "title": "Some Skill",
                    "type": "skill",
                    "category": "dev-tools",
                    "price_cents": 0,
                    "version": "1.0.0",
                    "download_count": 5,
                    "security_status": "pass",
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "some"])

    assert result.exit_code == 0
    # These columns should NOT appear as headers
    assert "Category" not in result.output
    assert "Version" not in result.output


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_external_item_shows_type_skill(mock_get_client: MagicMock, _m) -> None:
    """External items show type 'skill' in the Type column."""
    mock_client = _make_mock_client(
        _sectioned(
            clawhub_items=[
                {
                    "slug": "self-improving-agent",
                    "title": "Self-Improving Agent",
                    "source": "clawhub",
                    "type": "skill",
                    "source_installs": 951,
                    "source_stars": 1040,
                    "version": "1.0.11",
                    "ap_security_status": None,
                    "price_cents": 0,
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "agent"])

    assert result.exit_code == 0
    assert "skill" in result.output
    # The em-dash should NOT appear when type is present
    assert "\u2014" not in result.output


# --- Installed column tests ---


@patch(
    "agentpowers_cli.commands.search._get_installed_slugs",
    return_value={"code-reviewer": "clean"},
)
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_installed_column_header(mock_get_client: MagicMock, _m) -> None:
    """The Installed column header appears in the table output."""
    mock_client = _make_mock_client(
        _sectioned(
            native_items=[
                {
                    "slug": "code-reviewer",
                    "title": "Code Reviewer",
                    "type": "skill",
                    "price_cents": 0,
                    "download_count": 10,
                    "security_status": "pass",
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "code"])

    assert result.exit_code == 0
    assert "Installed" in result.output


@patch(
    "agentpowers_cli.commands.search._get_installed_slugs",
    return_value={"my-skill": "clean"},
)
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_installed_skill_shows_yes(mock_get_client: MagicMock, _m) -> None:
    """An installed skill displays 'Yes' in the Installed column."""
    mock_client = _make_mock_client(
        _sectioned(
            native_items=[
                {
                    "slug": "my-skill",
                    "title": "My Skill",
                    "type": "skill",
                    "price_cents": 0,
                    "download_count": 5,
                    "security_status": "pass",
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "my"])

    assert result.exit_code == 0
    assert "Yes" in result.output


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_not_installed_skill_shows_no(mock_get_client: MagicMock, _m) -> None:
    """A skill that is NOT installed displays 'No' in the Installed column."""
    mock_client = _make_mock_client(
        _sectioned(
            native_items=[
                {
                    "slug": "other-skill",
                    "title": "Other Skill",
                    "type": "skill",
                    "price_cents": 0,
                    "download_count": 5,
                    "security_status": "pass",
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "other"])

    assert result.exit_code == 0
    assert "No" in result.output


@patch(
    "agentpowers_cli.commands.search._get_installed_slugs",
    return_value={"native-skill": "clean"},
)
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_mixed_installed_and_not(mock_get_client: MagicMock, _m) -> None:
    """Mixed results correctly show Yes for installed and No for not installed."""
    mock_client = _make_mock_client(
        _sectioned(
            native_items=[
                {
                    "slug": "native-skill",
                    "title": "Installed Skill",
                    "type": "skill",
                    "price_cents": 0,
                    "download_count": 10,
                    "security_status": "pass",
                },
                {
                    "slug": "not-installed",
                    "title": "Not Installed Skill",
                    "type": "skill",
                    "price_cents": 0,
                    "download_count": 5,
                    "security_status": "pass",
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "skill"])

    assert result.exit_code == 0
    assert "Yes" in result.output
    assert "No" in result.output


@patch(
    "agentpowers_cli.commands.search._get_installed_slugs",
    return_value={"ext-installed": "clean"},
)
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_external_installed_shows_yes(mock_get_client: MagicMock, _m) -> None:
    """An installed external skill displays 'Yes' in the Installed column."""
    mock_client = _make_mock_client(
        _sectioned(
            clawhub_items=[
                {
                    "slug": "ext-installed",
                    "title": "Ext Installed",
                    "source": "clawhub",
                    "source_installs": 100,
                    "source_stars": 50,
                    "version": "1.0.0",
                    "ap_security_status": "pass",
                    "price_cents": 0,
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "ext"])

    assert result.exit_code == 0
    assert "Yes" in result.output
