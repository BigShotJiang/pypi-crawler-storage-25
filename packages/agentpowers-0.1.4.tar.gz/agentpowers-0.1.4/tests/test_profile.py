"""Tests for the profile command."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from agentpowers_cli.main import app
from agentpowers_cli.services.api_client import APIError

runner = CliRunner()

_BASE_PROFILE = {
    "display_name": "Jane Smith",
    "display_name_slug": "jane-smith",
    "email": "j@test.com",
    "bio": "hello",
    "created_at": "2024-01-01",
    "account_status": "active",
}


class TestProfileView:
    """Tests for `ap profile` (view mode)."""

    @patch("agentpowers_cli.commands.profile.get_api_client")
    def test_profile_view_shows_display_name(self, mock_get_client: MagicMock) -> None:
        """View mode prints the current display name."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.return_value = dict(_BASE_PROFILE)

        result = runner.invoke(app, ["profile"])

        assert result.exit_code == 0
        assert "Jane Smith" in result.output

    @patch("agentpowers_cli.commands.profile.get_api_client")
    def test_profile_view_no_display_name_shows_hint(
        self, mock_get_client: MagicMock
    ) -> None:
        """View mode shows hint when display_name is None."""
        client = MagicMock()
        mock_get_client.return_value = client
        profile_data = dict(_BASE_PROFILE, display_name=None)
        client.get.return_value = profile_data

        result = runner.invoke(app, ["profile"])

        assert result.exit_code == 0
        assert "No display name set" in result.output

    @patch("agentpowers_cli.commands.profile.get_api_client")
    def test_profile_view_not_logged_in(self, mock_get_client: MagicMock) -> None:
        """View mode prints not-logged-in message and exits 1 on 401."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.side_effect = APIError("Unauthorized", status_code=401)

        result = runner.invoke(app, ["profile"])

        assert result.exit_code == 1
        assert "Not logged in" in result.output


class TestProfileSet:
    """Tests for `ap profile --set` (interactive set mode)."""

    @patch("agentpowers_cli.commands.profile.get_api_client")
    def test_profile_set_success(self, mock_get_client: MagicMock) -> None:
        """Set mode updates profile and prints success message."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.return_value = dict(_BASE_PROFILE)
        updated = dict(_BASE_PROFILE, display_name="Jane Smith", bio="hello bio")
        client.patch.return_value = updated

        # Input order: display_name, bio
        result = runner.invoke(
            app,
            ["profile", "--set"],
            input="Jane Smith\nhello bio\n",
        )

        assert result.exit_code == 0
        assert "Profile updated" in result.output

    @patch("agentpowers_cli.commands.profile.get_api_client")
    def test_profile_set_api_error_exits(self, mock_get_client: MagicMock) -> None:
        """Set mode exits 1 on unexpected API error."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.return_value = dict(_BASE_PROFILE)
        client.patch.side_effect = APIError("Server error", status_code=500)

        result = runner.invoke(
            app,
            ["profile", "--set"],
            input="Jane Smith\nhello\n",
        )

        assert result.exit_code == 1
        assert "Error" in result.output
