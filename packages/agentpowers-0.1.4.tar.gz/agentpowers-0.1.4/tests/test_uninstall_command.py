"""Tests for the uninstall command."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

from typer.testing import CliRunner

from agentpowers_cli.main import app

runner = CliRunner()


class TestUninstallSkill:
    """Tests for removing installed skills."""

    def test_uninstall_skill(self, tmp_path: Path) -> None:
        """Remove an installed skill directory and its pin."""
        # Set up installed skill
        skill_dir = tmp_path / "skills" / "weather"
        skill_dir.mkdir(parents=True)
        (skill_dir / "SKILL.md").write_text("# Weather")

        # Set up pin
        pins_path = tmp_path / "pins.json"
        pins_path.write_text(json.dumps({"weather": {"source": "clawhub"}}))

        with patch(
            "agentpowers_cli.commands.uninstall.get_claude_dir",
            return_value=tmp_path,
        ), patch(
            "agentpowers_cli.commands.uninstall.DEFAULT_PINS_PATH",
            str(pins_path),
        ):
            result = runner.invoke(app, ["uninstall", "weather", "--force"])

        assert result.exit_code == 0
        assert not skill_dir.exists()
        assert "weather" not in json.loads(pins_path.read_text())

    def test_uninstall_agent(self, tmp_path: Path) -> None:
        """Remove an installed agent directory."""
        agent_dir = tmp_path / "agents" / "my-agent"
        agent_dir.mkdir(parents=True)
        (agent_dir / "agent.md").write_text("# Agent")

        with patch(
            "agentpowers_cli.commands.uninstall.get_claude_dir",
            return_value=tmp_path,
        ), patch(
            "agentpowers_cli.commands.uninstall.DEFAULT_PINS_PATH",
            str(tmp_path / "pins.json"),
        ):
            result = runner.invoke(app, ["uninstall", "my-agent", "--force"])

        assert result.exit_code == 0
        assert not agent_dir.exists()

    def test_uninstall_not_found(self, tmp_path: Path) -> None:
        """Error when skill/agent not installed."""
        with patch(
            "agentpowers_cli.commands.uninstall.get_claude_dir",
            return_value=tmp_path,
        ), patch(
            "agentpowers_cli.commands.uninstall.DEFAULT_PINS_PATH",
            str(tmp_path / "pins.json"),
        ):
            result = runner.invoke(app, ["uninstall", "nonexistent", "--force"])

        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    def test_uninstall_prompts_confirmation(self, tmp_path: Path) -> None:
        """Without --force, prompts for confirmation."""
        skill_dir = tmp_path / "skills" / "weather"
        skill_dir.mkdir(parents=True)
        (skill_dir / "SKILL.md").write_text("# Weather")

        with patch(
            "agentpowers_cli.commands.uninstall.get_claude_dir",
            return_value=tmp_path,
        ), patch(
            "agentpowers_cli.commands.uninstall.DEFAULT_PINS_PATH",
            str(tmp_path / "pins.json"),
        ):
            # User says "n" to abort
            _result = runner.invoke(app, ["uninstall", "weather"], input="n\n")

        assert skill_dir.exists()  # Not removed

    def test_uninstall_confirm_yes(self, tmp_path: Path) -> None:
        """With confirmation 'y', removes the skill."""
        skill_dir = tmp_path / "skills" / "weather"
        skill_dir.mkdir(parents=True)
        (skill_dir / "SKILL.md").write_text("# Weather")

        with patch(
            "agentpowers_cli.commands.uninstall.get_claude_dir",
            return_value=tmp_path,
        ), patch(
            "agentpowers_cli.commands.uninstall.DEFAULT_PINS_PATH",
            str(tmp_path / "pins.json"),
        ):
            result = runner.invoke(app, ["uninstall", "weather"], input="y\n")

        assert result.exit_code == 0
        assert not skill_dir.exists()

    def test_uninstall_cleans_pin_only(self, tmp_path: Path) -> None:
        """Pin is removed even if directory was already deleted."""
        pins_path = tmp_path / "pins.json"
        pins_path.write_text(
            json.dumps({
                "weather": {"source": "clawhub"},
                "other": {"source": "agentpowers"},
            })
        )

        with patch(
            "agentpowers_cli.commands.uninstall.get_claude_dir",
            return_value=tmp_path,
        ), patch(
            "agentpowers_cli.commands.uninstall.DEFAULT_PINS_PATH",
            str(pins_path),
        ):
            result = runner.invoke(app, ["uninstall", "weather", "--force"])

        # Should still succeed (pin existed)
        assert result.exit_code == 0
        pins = json.loads(pins_path.read_text())
        assert "weather" not in pins
        assert "other" in pins  # Other pins preserved

    def test_uninstall_prefers_skill_over_agent(self, tmp_path: Path) -> None:
        """When slug exists in both skills/ and agents/, removes both."""
        skill_dir = tmp_path / "skills" / "dual"
        agent_dir = tmp_path / "agents" / "dual"
        skill_dir.mkdir(parents=True)
        agent_dir.mkdir(parents=True)
        (skill_dir / "SKILL.md").write_text("# Dual")
        (agent_dir / "agent.md").write_text("# Dual")

        with patch(
            "agentpowers_cli.commands.uninstall.get_claude_dir",
            return_value=tmp_path,
        ), patch(
            "agentpowers_cli.commands.uninstall.DEFAULT_PINS_PATH",
            str(tmp_path / "pins.json"),
        ):
            result = runner.invoke(app, ["uninstall", "dual", "--force"])

        assert result.exit_code == 0
        assert not skill_dir.exists()
        assert not agent_dir.exists()
