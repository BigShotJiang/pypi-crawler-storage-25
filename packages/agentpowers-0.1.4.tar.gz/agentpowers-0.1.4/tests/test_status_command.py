"""Tests for the status command."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

from typer.testing import CliRunner

from agentpowers_cli.main import app

runner = CliRunner()


def _patch_status(tmp_path: Path, pins_path: Path):
    """Return context managers to patch claude dir and pins path."""
    return (
        patch("agentpowers_cli.commands.status.get_claude_dir", return_value=tmp_path),
        patch("agentpowers_cli.commands.status.DEFAULT_PINS_PATH", str(pins_path)),
    )


class TestStatus:
    """Tests for the ap status command."""

    def test_status_shows_installed_skills(self, tmp_path: Path) -> None:
        """List installed skill directories."""
        (tmp_path / "skills" / "weather").mkdir(parents=True)
        (tmp_path / "skills" / "pdf").mkdir(parents=True)
        pins_path = tmp_path / "pins.json"
        pins_path.write_text("{}")

        p1, p2 = _patch_status(tmp_path, pins_path)
        with p1, p2:
            result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "weather" in result.output
        assert "pdf" in result.output
        assert "Installed Skills" in result.output

    def test_status_shows_installed_agents(self, tmp_path: Path) -> None:
        """List installed agent directories."""
        (tmp_path / "agents" / "my-agent").mkdir(parents=True)
        pins_path = tmp_path / "pins.json"
        pins_path.write_text("{}")

        p1, p2 = _patch_status(tmp_path, pins_path)
        with p1, p2:
            result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "my-agent" in result.output
        assert "Installed Agents" in result.output

    def test_status_shows_pin_data(self, tmp_path: Path) -> None:
        """Skills with pins show source, security, version, date."""
        (tmp_path / "skills" / "weather").mkdir(parents=True)
        pins_path = tmp_path / "pins.json"
        pins_path.write_text(json.dumps({
            "weather": {
                "source": "clawhub",
                "version": "1.0.0",
                "content_hash": "sha256:abc",
                "installed_at": "2026-02-28T12:00:00+00:00",
                "scanned_at": "2026-02-28T12:00:00+00:00",
                "security_status": "pass",
            }
        }))

        p1, p2 = _patch_status(tmp_path, pins_path)
        with p1, p2:
            result = runner.invoke(app, ["status"])

        assert "clawhub" in result.output
        assert "pass" in result.output
        assert "1.0.0" in result.output
        assert "2026-02-28" in result.output

    def test_status_local_skills_show_local_source(self, tmp_path: Path) -> None:
        """Skills without pins show 'local' as source."""
        (tmp_path / "skills" / "my-skill").mkdir(parents=True)
        pins_path = tmp_path / "pins.json"
        pins_path.write_text("{}")

        p1, p2 = _patch_status(tmp_path, pins_path)
        with p1, p2:
            result = runner.invoke(app, ["status"])

        assert "local" in result.output

    def test_status_empty(self, tmp_path: Path) -> None:
        """No skills or agents installed."""
        pins_path = tmp_path / "pins.json"
        pins_path.write_text("{}")

        p1, p2 = _patch_status(tmp_path, pins_path)
        with p1, p2:
            result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "No skills installed" in result.output
        assert "No agents installed" in result.output

    def test_status_ignores_non_directories(self, tmp_path: Path) -> None:
        """Files in skills/ dir are not listed as installed skills."""
        skills_dir = tmp_path / "skills"
        skills_dir.mkdir(parents=True)
        (skills_dir / "README.md").write_text("# readme")
        (skills_dir / "real-skill").mkdir()
        pins_path = tmp_path / "pins.json"
        pins_path.write_text("{}")

        p1, p2 = _patch_status(tmp_path, pins_path)
        with p1, p2:
            result = runner.invoke(app, ["status"])

        assert "real-skill" in result.output
        assert "README" not in result.output

    def test_status_counts_in_title(self, tmp_path: Path) -> None:
        """Table title includes count of installed items."""
        (tmp_path / "skills" / "a").mkdir(parents=True)
        (tmp_path / "skills" / "b").mkdir(parents=True)
        (tmp_path / "skills" / "c").mkdir(parents=True)
        pins_path = tmp_path / "pins.json"
        pins_path.write_text("{}")

        p1, p2 = _patch_status(tmp_path, pins_path)
        with p1, p2:
            result = runner.invoke(app, ["status"])

        assert "3" in result.output

    def test_status_shows_logged_in(self, tmp_path: Path) -> None:
        """When a token exists, status shows 'Logged in'."""
        pins_path = tmp_path / "pins.json"
        pins_path.write_text("{}")

        p1, p2 = _patch_status(tmp_path, pins_path)
        with p1, p2, patch(
            "agentpowers_cli.commands.status.load_token", return_value="some-jwt"
        ):
            result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "Logged in" in result.output

    def test_status_shows_not_logged_in(self, tmp_path: Path) -> None:
        """When no token, status shows 'Not logged in' and suggests login."""
        pins_path = tmp_path / "pins.json"
        pins_path.write_text("{}")

        p1, p2 = _patch_status(tmp_path, pins_path)
        with p1, p2, patch(
            "agentpowers_cli.commands.status.load_token", return_value=None
        ):
            result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "Not logged in" in result.output
        assert "ap login" in result.output
