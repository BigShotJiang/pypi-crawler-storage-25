"""Adversarial tests — edge cases, bad inputs, and security boundaries.

These tests cover the hardening fixes from the CLI smoke test audit:
- Empty/invalid slug validation across all commands
- Search limit bounds checking
- _parse_slug multi-slash rejection
- Negative price rejection in publish
- Auth directory permissions
- API client non-JSON response handling
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import typer
from typer.testing import CliRunner

from agentpowers_cli.commands import validate_slug
from agentpowers_cli.commands.install import _parse_slug
from agentpowers_cli.main import app
from agentpowers_cli.services.api_client import APIClient, APIError
from agentpowers_cli.services.auth_store import save_token

runner = CliRunner()


# ---------------------------------------------------------------------------
# validate_slug tests
# ---------------------------------------------------------------------------


class TestValidateSlug:
    """Tests for the shared validate_slug function."""

    def test_empty_slug(self) -> None:
        with pytest.raises(typer.Exit):
            validate_slug("")

    def test_whitespace_only(self) -> None:
        with pytest.raises(typer.Exit):
            validate_slug("   ")

    def test_valid_slug(self) -> None:
        assert validate_slug("my-skill") == "my-skill"

    def test_valid_slug_with_numbers(self) -> None:
        assert validate_slug("skill-123") == "skill-123"

    def test_slug_uppercase_rejected(self) -> None:
        with pytest.raises(typer.Exit):
            validate_slug("MySkill")

    def test_slug_special_chars_rejected(self) -> None:
        with pytest.raises(typer.Exit):
            validate_slug("my_skill")

    def test_slug_path_traversal_rejected(self) -> None:
        with pytest.raises(typer.Exit):
            validate_slug("../../etc/passwd")

    def test_slug_dots_rejected(self) -> None:
        with pytest.raises(typer.Exit):
            validate_slug("my.skill")

    def test_slug_leading_hyphen_rejected(self) -> None:
        with pytest.raises(typer.Exit):
            validate_slug("-my-skill")

    def test_slug_spaces_rejected(self) -> None:
        with pytest.raises(typer.Exit):
            validate_slug("my skill")

    def test_slug_strips_whitespace(self) -> None:
        assert validate_slug("  my-skill  ") == "my-skill"


# ---------------------------------------------------------------------------
# _parse_slug tests
# ---------------------------------------------------------------------------


class TestParseSlugAdversarial:
    """Adversarial tests for slug parsing."""

    def test_triple_slash_rejected(self) -> None:
        with pytest.raises(typer.BadParameter, match="Invalid slug format"):
            _parse_slug("a/b/c")

    def test_double_slash_rejected(self) -> None:
        with pytest.raises(typer.BadParameter, match="Invalid slug format"):
            _parse_slug("a//b")


# ---------------------------------------------------------------------------
# Command-level empty slug rejection
# ---------------------------------------------------------------------------


class TestEmptySlugRejection:
    """Every command that accepts a slug must reject empty strings."""

    def test_install_empty(self) -> None:
        result = runner.invoke(app, ["install", ""])
        assert result.exit_code != 0
        assert "empty" in result.output.lower() or "invalid" in result.output.lower()

    def test_uninstall_empty(self) -> None:
        result = runner.invoke(app, ["uninstall", "--force", ""])
        assert result.exit_code != 0
        assert "empty" in result.output.lower() or "invalid" in result.output.lower()

    def test_detail_empty(self) -> None:
        result = runner.invoke(app, ["detail", ""])
        assert result.exit_code != 0
        assert "empty" in result.output.lower() or "invalid" in result.output.lower()

    def test_unpublish_empty(self) -> None:
        result = runner.invoke(app, ["unpublish", ""], input="y\n")
        assert result.exit_code != 0
        assert "empty" in result.output.lower() or "invalid" in result.output.lower()

    def test_republish_empty(self) -> None:
        result = runner.invoke(app, ["republish", ""], input="y\n")
        assert result.exit_code != 0
        assert "empty" in result.output.lower() or "invalid" in result.output.lower()

    def test_claim_empty(self) -> None:
        result = runner.invoke(app, ["claim", ""])
        assert result.exit_code != 0
        assert "empty" in result.output.lower() or "invalid" in result.output.lower()

    def test_scan_empty(self) -> None:
        result = runner.invoke(app, ["scan", ""])
        assert result.exit_code != 0
        assert "empty" in result.output.lower() or "invalid" in result.output.lower()

    def test_update_invalid(self) -> None:
        """Update with an invalid slug (non-empty but bad chars) is rejected."""
        result = runner.invoke(app, ["update", "INVALID_SLUG!!"])
        assert result.exit_code != 0
        assert "invalid" in result.output.lower()


# ---------------------------------------------------------------------------
# Search limit validation
# ---------------------------------------------------------------------------


class TestSearchLimitValidation:
    """Search command must reject invalid --limit values client-side."""

    @patch("agentpowers_cli.commands.search.get_api_client")
    def test_negative_limit(self, mock_client: MagicMock) -> None:
        result = runner.invoke(app, ["search", "--limit", "-1", "test"])
        assert result.exit_code != 0
        assert "--limit must be at least 1" in result.output

    @patch("agentpowers_cli.commands.search.get_api_client")
    def test_zero_limit(self, mock_client: MagicMock) -> None:
        result = runner.invoke(app, ["search", "--limit", "0", "test"])
        assert result.exit_code != 0
        assert "--limit must be at least 1" in result.output


# ---------------------------------------------------------------------------
# Publish validation
# ---------------------------------------------------------------------------


class TestPublishValidation:
    """Tests for publish command input validation."""

    def test_negative_price(self, tmp_path: Path) -> None:
        skill_md = tmp_path / "SKILL.md"
        skill_md.write_text(
            "---\nname: test-skill\ndescription: A test\n---\nContent"
        )
        result = runner.invoke(
            app, ["publish", "--price", "-5", "--dir", str(tmp_path)]
        )
        assert result.exit_code != 0
        assert "cannot be negative" in result.output.lower()

    def test_version_with_explicit_bump_rejected(self) -> None:
        result = runner.invoke(
            app, ["publish", "--version", "2.0.0", "--bump", "minor"]
        )
        assert result.exit_code != 0
        assert "Cannot use --bump and --version together" in result.output


# ---------------------------------------------------------------------------
# Auth directory permissions
# ---------------------------------------------------------------------------


class TestAuthDirPermissions:
    """Auth directory should be restricted to owner-only."""

    def test_save_token_sets_dir_permissions(self, tmp_path: Path) -> None:
        auth_dir = tmp_path / ".agentpowers"
        auth_file = auth_dir / "auth.json"

        with patch(
            "agentpowers_cli.services.auth_store.get_auth_file",
            return_value=auth_file,
        ):
            save_token("test-token")

        dir_mode = oct(auth_dir.stat().st_mode & 0o777)
        file_mode = oct(auth_file.stat().st_mode & 0o777)
        assert dir_mode == "0o700", f"Expected 0o700, got {dir_mode}"
        assert file_mode == "0o600", f"Expected 0o600, got {file_mode}"


# ---------------------------------------------------------------------------
# API client non-JSON response handling
# ---------------------------------------------------------------------------


class TestAPIClientNonJSON:
    """API client must handle non-JSON responses gracefully."""

    def test_success_non_json_raises(self) -> None:
        client = APIClient(base_url="http://test.local")

        mock_response = MagicMock()
        mock_response.is_success = True
        mock_response.status_code = 200
        mock_response.json.side_effect = ValueError("No JSON")

        with pytest.raises(APIError, match="invalid JSON"):
            client._handle_response(mock_response)

    def test_error_non_json_returns_unknown(self) -> None:
        client = APIClient(base_url="http://test.local")

        mock_response = MagicMock()
        mock_response.is_success = False
        mock_response.status_code = 500
        mock_response.json.side_effect = ValueError("No JSON")

        with pytest.raises(APIError, match="Unknown error"):
            client._handle_response(mock_response)


# ---------------------------------------------------------------------------
# Install multi-slash rejection
# ---------------------------------------------------------------------------


class TestInstallMultiSlash:
    """Install command must reject slugs with multiple slashes."""

    def test_multi_slash_rejected(self) -> None:
        result = runner.invoke(app, ["install", "a/b/c"])
        assert result.exit_code != 0
        assert "Invalid slug format" in result.output
