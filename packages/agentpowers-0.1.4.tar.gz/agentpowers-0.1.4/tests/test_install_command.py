"""Tests for the install command and installer service."""

from __future__ import annotations

import io
import zipfile
from pathlib import Path
from unittest.mock import ANY, MagicMock, patch

import pytest

from typer.testing import CliRunner

from agentpowers_cli.main import app
from agentpowers_cli.services.api_client import APIError
from agentpowers_cli.services.installer import extract_package

runner = CliRunner()


def _make_zip(files: dict[str, str]) -> bytes:
    """Create an in-memory ZIP archive from a dict of filename -> content.

    Args:
        files: Mapping of file paths to their string contents.

    Returns:
        Raw bytes of the ZIP archive.
    """
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, content in files.items():
            zf.writestr(name, content)
    return buf.getvalue()


# ---------------------------------------------------------------------------
# Installer service tests
# ---------------------------------------------------------------------------


class TestExtractPackage:
    """Tests for the extract_package function."""

    def test_extract_zip_to_skills_dir(self, tmp_path: Path) -> None:
        """Extract a skill ZIP into the skills/ subdirectory."""
        zip_data = _make_zip({"CLAUDE.md": "# My Skill", "main.py": "print('hi')"})

        dest = extract_package(zip_data, "my-skill", "skill", base_dir=tmp_path)

        assert dest == tmp_path / "skills" / "my-skill"
        assert (dest / "CLAUDE.md").read_text() == "# My Skill"
        assert (dest / "main.py").read_text() == "print('hi')"

    def test_extract_zip_to_agents_dir(self, tmp_path: Path) -> None:
        """Extract an agent ZIP into the agents/ subdirectory."""
        zip_data = _make_zip({"agent.yaml": "name: test"})

        dest = extract_package(zip_data, "my-agent", "agent", base_dir=tmp_path)

        assert dest == tmp_path / "agents" / "my-agent"
        assert (dest / "agent.yaml").read_text() == "name: test"

    def test_extract_overwrites_existing(self, tmp_path: Path) -> None:
        """Extracting twice overwrites the previous installation."""
        zip_v1 = _make_zip({"version.txt": "v1", "old_file.txt": "remove me"})
        zip_v2 = _make_zip({"version.txt": "v2"})

        extract_package(zip_v1, "my-skill", "skill", base_dir=tmp_path)
        dest = extract_package(zip_v2, "my-skill", "skill", base_dir=tmp_path)

        assert (dest / "version.txt").read_text() == "v2"
        assert not (dest / "old_file.txt").exists()


# ---------------------------------------------------------------------------
# Install command tests
# ---------------------------------------------------------------------------


def _mock_skill(
    slug: str = "cool-skill",
    price_cents: int = 0,
    security_status: str = "pass",
    skill_type: str = "skill",
) -> dict:
    """Build a mock skill response dict."""
    return {
        "slug": slug,
        "name": "Cool Skill",
        "price_cents": price_cents,
        "security_status": security_status,
        "type": skill_type,
    }


class TestInstallCommand:
    """Tests for the `ap install` CLI command."""

    @patch(
        "agentpowers_cli.commands.install.install_from_url",
        return_value="/home/.claude/skills/cool-skill",
    )
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_install_free_skill(
        self, mock_get_client: MagicMock, mock_install_url: MagicMock
    ) -> None:
        """Free skill installs successfully with exit code 0."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.side_effect = [
            _mock_skill(price_cents=0),
            {"url": "https://cdn.example.com/cool-skill.zip"},
        ]

        result = runner.invoke(app, ["install", "cool-skill"])

        assert result.exit_code == 0
        assert "Installed" in result.output
        mock_install_url.assert_called_once()

    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_install_blocked_skill_rejected(
        self, mock_get_client: MagicMock
    ) -> None:
        """Blocked skill is rejected with exit code 1."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.return_value = _mock_skill(security_status="block")

        result = runner.invoke(app, ["install", "bad-skill"])

        assert result.exit_code == 1
        assert "blocked" in result.output.lower()

    @patch(
        "agentpowers_cli.commands.install.install_from_url",
        return_value="/home/.claude/skills/paid-skill",
    )
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_install_with_license_code(
        self, mock_get_client: MagicMock, mock_install_url: MagicMock
    ) -> None:
        """License code triggers a redeem POST call."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.side_effect = [
            _mock_skill(price_cents=1000),
            {"url": "https://cdn.example.com/paid-skill.zip"},
        ]
        client.post.return_value = {"status": "redeemed"}

        result = runner.invoke(app, ["install", "paid-skill", "--code", "ABC-123"])

        assert result.exit_code == 0
        client.post.assert_called_once_with(
            "/v1/purchases/redeem",
            json_data={"license_code": "ABC-123"},
            auth=True,
        )

    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_install_not_found_anywhere(self, mock_get_client: MagicMock) -> None:
        """Skill not found natively or externally returns exit code 1."""
        client = MagicMock()
        mock_get_client.return_value = client
        # First call: /v1/skills/{slug} -> 404
        # Second call: /v1/search -> no matching slugs
        client.get.side_effect = [
            APIError("Not found", status_code=404),
            {
                "agentpowers": {"items": [], "total": 0},
                "clawhub": {"items": [], "total": 0},
            },
        ]

        result = runner.invoke(app, ["install", "nonexistent"])

        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    @patch("agentpowers_cli.commands.install.install_external_skill")
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_install_waterfall_single_external(
        self, mock_get_client: MagicMock, mock_ext_install: MagicMock
    ) -> None:
        """Skill not found natively but found in one external source."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.side_effect = [
            APIError("Not found", status_code=404),
            {
                "agentpowers": {"items": [], "total": 0},
                "clawhub": {
                    "total": 1,
                    "items": [
                        {
                            "slug": "weather",
                            "title": "Weather",
                            "source": "clawhub",
                            "source_installs": 587,
                            "version": "1.0.0",
                        }
                    ],
                },
            },
        ]
        mock_ext_install.return_value = "/tmp/installed"

        result = runner.invoke(app, ["install", "weather"])

        assert result.exit_code == 0
        assert "Installed" in result.output
        mock_ext_install.assert_called_once_with(
            client, "weather", "clawhub", base_dir=ANY
        )


# ---------------------------------------------------------------------------
# Native install saves pin tests
# ---------------------------------------------------------------------------


class TestNativeInstallSavesPin:
    """Verify that _install_native saves a pin after extraction."""

    @patch("agentpowers_cli.commands.install.save_pin")
    @patch(
        "agentpowers_cli.commands.install.hash_directory",
        return_value="sha256:abc123",
    )
    @patch(
        "agentpowers_cli.commands.install.install_from_url",
        return_value="/home/.claude/skills/my-skill",
    )
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_native_install_saves_pin(
        self,
        mock_get_client: MagicMock,
        mock_install_url: MagicMock,
        mock_hash: MagicMock,
        mock_save_pin: MagicMock,
    ) -> None:
        """Installing a free native skill saves a pin with correct hash."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.side_effect = [
            _mock_skill(slug="my-skill", price_cents=0, security_status="pass"),
            {"url": "https://cdn.example.com/my-skill.zip"},
        ]

        result = runner.invoke(app, ["install", "my-skill"])

        assert result.exit_code == 0
        mock_hash.assert_called_once_with("/home/.claude/skills/my-skill")
        mock_save_pin.assert_called_once_with(
            slug="my-skill",
            source="agentpowers",
            version=None,
            content_hash="sha256:abc123",
            security_status="pass",
            skill_type="skill",
            install_location="/home/.claude/skills/my-skill",
        )

    @patch("agentpowers_cli.commands.install.save_pin")
    @patch(
        "agentpowers_cli.commands.install.hash_directory",
        return_value="sha256:def456",
    )
    @patch(
        "agentpowers_cli.commands.install.install_from_url",
        return_value="/home/.claude/skills/warn-skill",
    )
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_native_install_saves_pin_with_warn_status(
        self,
        mock_get_client: MagicMock,
        mock_install_url: MagicMock,
        mock_hash: MagicMock,
        mock_save_pin: MagicMock,
    ) -> None:
        """Pin records the actual security status (warn, not just pass)."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.side_effect = [
            _mock_skill(slug="warn-skill", price_cents=0, security_status="warn"),
            {"url": "https://cdn.example.com/warn-skill.zip"},
        ]

        result = runner.invoke(app, ["install", "warn-skill"])

        assert result.exit_code == 0
        mock_save_pin.assert_called_once_with(
            slug="warn-skill",
            source="agentpowers",
            version=None,
            content_hash="sha256:def456",
            security_status="warn",
            skill_type="skill",
            install_location="/home/.claude/skills/warn-skill",
        )

    @patch("agentpowers_cli.commands.install.save_pin")
    @patch(
        "agentpowers_cli.commands.install.hash_directory",
        return_value="sha256:ghi789",
    )
    @patch(
        "agentpowers_cli.commands.install.install_from_url",
        return_value="/home/.claude/skills/versioned",
    )
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_native_install_saves_pin_with_version(
        self,
        mock_get_client: MagicMock,
        mock_install_url: MagicMock,
        mock_hash: MagicMock,
        mock_save_pin: MagicMock,
    ) -> None:
        """Pin includes version from skill metadata when available."""
        client = MagicMock()
        mock_get_client.return_value = client
        skill = _mock_skill(slug="versioned", price_cents=0)
        skill["version"] = "1.2.3"
        client.get.side_effect = [
            skill,
            {"url": "https://cdn.example.com/versioned.zip"},
        ]

        result = runner.invoke(app, ["install", "versioned"])

        assert result.exit_code == 0
        mock_save_pin.assert_called_once_with(
            slug="versioned",
            source="agentpowers",
            version="1.2.3",
            content_hash="sha256:ghi789",
            security_status="pass",
            skill_type="skill",
            install_location="/home/.claude/skills/versioned",
        )

    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_blocked_skill_does_not_save_pin(
        self, mock_get_client: MagicMock
    ) -> None:
        """Blocked skill exits before saving any pin."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.return_value = _mock_skill(security_status="block")

        with patch("agentpowers_cli.commands.install.save_pin") as mock_save_pin:
            result = runner.invoke(app, ["install", "bad-skill"])

        assert result.exit_code == 1
        mock_save_pin.assert_not_called()


class TestRecordInstallationTracking:
    """Verify that record_installation is called correctly after installs."""

    @patch(
        "agentpowers_cli.commands.install.install_from_url",
        return_value="/home/.claude/skills/tracked-skill",
    )
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_record_installation_called_after_native_install(
        self, mock_get_client: MagicMock, mock_install_url: MagicMock
    ) -> None:
        """record_installation is called after a successful native AP install."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.side_effect = [
            _mock_skill(slug="tracked-skill"),
            {"url": "https://cdn.example.com/tracked-skill.zip"},
        ]

        result = runner.invoke(app, ["install", "tracked-skill"])

        assert result.exit_code == 0
        client.record_installation.assert_called_once()
        call_kwargs = client.record_installation.call_args
        assert call_kwargs[0][0] == "tracked-skill"  # source_slug
        assert call_kwargs[0][1] == "cli"             # platform
        assert call_kwargs[0][2] == "agentpowers"     # source

    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_record_installation_not_called_on_failure(
        self, mock_get_client: MagicMock
    ) -> None:
        """record_installation is NOT called when install is blocked or fails."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.return_value = _mock_skill(security_status="block")

        result = runner.invoke(app, ["install", "bad-skill"])

        assert result.exit_code == 1
        client.record_installation.assert_not_called()


# ---------------------------------------------------------------------------
# _parse_slug tests
# ---------------------------------------------------------------------------


from agentpowers_cli.commands.install import _parse_slug  # noqa: E402


class TestParseSlug:
    """Tests for the _parse_slug helper function."""

    def test_parse_slug_with_author(self) -> None:
        """author/slug splits into (author, slug)."""
        assert _parse_slug("clerk/my-skill") == ("clerk", "my-skill")

    def test_parse_slug_without_author(self) -> None:
        """Plain slug returns (None, slug)."""
        assert _parse_slug("my-skill") == (None, "my-skill")

    def test_parse_slug_empty_author(self) -> None:
        """Leading slash treats author as None."""
        assert _parse_slug("/my-skill") == (None, "my-skill")

    def test_parse_slug_nested_slashes_rejected(self) -> None:
        """Multiple slashes are rejected as invalid format."""
        import typer
        with pytest.raises(typer.BadParameter, match="Invalid slug format"):
            _parse_slug("author/part/extra")


# ---------------------------------------------------------------------------
# detect_install_base tests
# ---------------------------------------------------------------------------


from agentpowers_cli.services.installer import detect_install_base  # noqa: E402


class TestDetectInstallBase:
    """Tests for the detect_install_base function."""

    def test_detect_install_base_local(self, tmp_path: Path) -> None:
        """When .claude/ exists in cwd, returns cwd/.claude."""
        local_claude = tmp_path / ".claude"
        local_claude.mkdir()

        with patch("agentpowers_cli.services.installer.Path.cwd", return_value=tmp_path):
            result = detect_install_base(force_global=False)

        assert result == local_claude

    def test_detect_install_base_global_no_local(self, tmp_path: Path) -> None:
        """No .claude/ in cwd falls back to ~/.claude."""
        with patch("agentpowers_cli.services.installer.Path.cwd", return_value=tmp_path):
            result = detect_install_base(force_global=False)

        assert result == Path.home() / ".claude"

    def test_detect_install_base_force_global(self, tmp_path: Path) -> None:
        """--global always returns ~/.claude even when .claude/ exists in cwd."""
        local_claude = tmp_path / ".claude"
        local_claude.mkdir()

        with patch("agentpowers_cli.services.installer.Path.cwd", return_value=tmp_path):
            result = detect_install_base(force_global=True)

        assert result == Path.home() / ".claude"

    def test_detect_install_base_for_codex(self, tmp_path: Path) -> None:
        """--for codex always returns ~/.codex regardless of local .claude/."""
        local_claude = tmp_path / ".claude"
        local_claude.mkdir()

        with patch("agentpowers_cli.services.installer.Path.cwd", return_value=tmp_path):
            result = detect_install_base(force_global=False, for_tool="codex")

        assert result == Path.home() / ".codex"

    @pytest.mark.parametrize(
        "tool,expected_dir",
        [
            ("claude-code", ".claude"),
            ("claude-desktop", ".claude"),
            ("codex", ".codex"),
            ("gemini", ".gemini"),
            ("kiro", ".kiro"),
        ],
    )
    def test_detect_install_base_for_all_supported_tools(
        self, tmp_path: Path, tool: str, expected_dir: str
    ) -> None:
        """Each supported tool maps to the correct global config directory."""
        with patch("agentpowers_cli.services.installer.Path.cwd", return_value=tmp_path):
            result = detect_install_base(force_global=False, for_tool=tool)

        assert result == Path.home() / expected_dir

    def test_detect_install_base_unknown_tool_raises(self) -> None:
        """Unknown tool name raises ValueError with helpful message."""
        with pytest.raises(ValueError, match="Unknown tool 'unknown-tool'"):
            detect_install_base(for_tool="unknown-tool")

    def test_detect_install_base_codex_ignores_local_claude(self, tmp_path: Path) -> None:
        """For codex, local .claude/ dir is ignored — always returns ~/.codex."""
        local_claude = tmp_path / ".claude"
        local_claude.mkdir()

        with patch("agentpowers_cli.services.installer.Path.cwd", return_value=tmp_path):
            result = detect_install_base(force_global=False, for_tool="codex")

        # Must not return the local claude dir
        assert result != local_claude
        assert result == Path.home() / ".codex"


# ---------------------------------------------------------------------------
# --for flag integration tests
# ---------------------------------------------------------------------------


class TestForToolFlag:
    """Tests for the --for <tool> flag on ap install."""

    runner = CliRunner()

    @patch("agentpowers_cli.commands.install.install_from_url")
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_for_codex_installs_to_codex_dir(
        self, mock_get_client: MagicMock, mock_install_url: MagicMock
    ) -> None:
        """--for codex passes ~/.codex as base_dir to install_from_url."""
        client = MagicMock()
        mock_get_client.return_value = client
        skill = _mock_skill(slug="pdf-parser")
        client.get.return_value = skill
        mock_install_url.return_value = str(Path.home() / ".codex" / "skills" / "pdf-parser")

        result = self.runner.invoke(app, ["install", "--for", "codex", "pdf-parser"])

        assert result.exit_code == 0, result.output
        # base_dir passed to install_from_url must be ~/.codex
        call_kwargs = mock_install_url.call_args
        base_dir_arg = call_kwargs.kwargs.get("base_dir") or call_kwargs.args[2]
        assert base_dir_arg == Path.home() / ".codex"

    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_for_unknown_tool_exits_with_error(self, mock_get_client: MagicMock) -> None:
        """--for with an unknown tool name shows an error and exits non-zero."""
        result = self.runner.invoke(app, ["install", "--for", "vscode", "pdf-parser"])
        assert result.exit_code != 0
        assert "vscode" in result.output or "vscode" in str(result.exception)

    def test_for_claude_code_default_behavior(self, tmp_path: Path) -> None:
        """--for claude-code (default) preserves existing local .claude/ detection."""
        from agentpowers_cli.services.installer import detect_install_base

        local = tmp_path / ".claude"
        local.mkdir()

        with patch("agentpowers_cli.services.installer.Path.cwd", return_value=tmp_path):
            result = detect_install_base(force_global=False, for_tool="claude-code")

        assert result == local


# ---------------------------------------------------------------------------
# Author/slug install tests
# ---------------------------------------------------------------------------


class TestAuthorSlugInstall:
    """Tests for ap install <author>/<slug> format."""

    @patch(
        "agentpowers_cli.commands.install.install_from_url",
        return_value="/home/.claude/skills/my-skill",
    )
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_author_slug_resolves_seller(
        self, mock_get_client: MagicMock, mock_install_url: MagicMock
    ) -> None:
        """author/slug resolves via GET /v1/sellers/{author}/skills."""
        client = MagicMock()
        mock_get_client.return_value = client
        skill = _mock_skill(slug="my-skill")
        client.get.side_effect = [
            # Seller skills listing
            {"items": [skill], "total": 1},
            # Download URL
            {"url": "https://cdn.example.com/my-skill.zip"},
        ]

        result = runner.invoke(app, ["install", "clerk/my-skill"])

        assert result.exit_code == 0
        assert "Installed" in result.output
        client.get.assert_any_call("/v1/sellers/clerk/skills")

    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_author_slug_seller_not_found(self, mock_get_client: MagicMock) -> None:
        """Unknown seller returns exit code 1 with an error message."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.side_effect = APIError("Not found", status_code=404)

        result = runner.invoke(app, ["install", "nobody/my-skill"])

        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_author_slug_skill_not_in_seller_list(
        self, mock_get_client: MagicMock
    ) -> None:
        """Seller found but skill not in their list returns exit code 1."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.return_value = {"items": [], "total": 0}

        result = runner.invoke(app, ["install", "clerk/nonexistent"])

        assert result.exit_code == 1
        assert "not found" in result.output.lower()
