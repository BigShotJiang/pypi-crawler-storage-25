"""Tests for api_client module."""

from unittest.mock import MagicMock, patch

import pytest

from agentpowers_cli.services.api_client import APIClient, APIError


class TestAPIError:
    """Tests for APIError exception."""

    def test_has_status_code(self) -> None:
        err = APIError("not found", status_code=404)
        assert err.status_code == 404

    def test_has_message(self) -> None:
        err = APIError("server error", status_code=500)
        assert str(err) == "server error"


class TestAPIClientGet:
    """Tests for APIClient.get method."""

    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_get_without_auth_no_authorization_header(
        self, mock_client_cls: MagicMock
    ) -> None:
        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"data": "ok"}
        mock_response.is_success = True
        mock_client.get.return_value = mock_response

        client = APIClient(base_url="https://api.test.com")
        result = client.get("/v1/skills", auth=False)

        assert result == {"data": "ok"}
        call_kwargs = mock_client.get.call_args
        headers = call_kwargs.kwargs.get("headers", {})
        assert "Authorization" not in headers

    @patch(
        "agentpowers_cli.services.api_client.load_token",
        return_value="jwt-token-abc",
    )
    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_get_with_auth_includes_bearer_token(
        self, mock_client_cls: MagicMock, mock_load: MagicMock
    ) -> None:
        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"skills": []}
        mock_response.is_success = True
        mock_client.get.return_value = mock_response

        client = APIClient(base_url="https://api.test.com")
        result = client.get("/v1/skills", auth=True)

        assert result == {"skills": []}
        call_kwargs = mock_client.get.call_args
        headers = call_kwargs.kwargs.get("headers", {})
        assert headers["Authorization"] == "Bearer jwt-token-abc"

    @patch("agentpowers_cli.services.api_client.load_token", return_value=None)
    def test_get_auth_required_but_no_token_raises(
        self, mock_load: MagicMock
    ) -> None:
        client = APIClient(base_url="https://api.test.com")
        with pytest.raises(APIError, match="Not authenticated"):
            client.get("/v1/skills", auth=True)

    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_get_with_params(self, mock_client_cls: MagicMock) -> None:
        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"results": []}
        mock_response.is_success = True
        mock_client.get.return_value = mock_response

        client = APIClient(base_url="https://api.test.com")
        client.get("/v1/search", auth=False, params={"q": "test"})

        call_kwargs = mock_client.get.call_args
        assert call_kwargs.kwargs["params"] == {"q": "test"}

    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_get_http_error_raises_api_error(
        self, mock_client_cls: MagicMock
    ) -> None:
        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.is_success = False
        mock_response.json.return_value = {"detail": "Skill not found"}
        mock_client.get.return_value = mock_response

        client = APIClient(base_url="https://api.test.com")
        with pytest.raises(APIError) as exc_info:
            client.get("/v1/skills/missing", auth=False)

        assert exc_info.value.status_code == 404
        assert "Skill not found" in str(exc_info.value)


class TestAPIClientPost:
    """Tests for APIClient.post method."""

    @patch("agentpowers_cli.services.api_client.load_token", return_value="token-123")
    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_post_with_json_body(
        self, mock_client_cls: MagicMock, mock_load: MagicMock
    ) -> None:
        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_response = MagicMock()
        mock_response.status_code = 201
        mock_response.json.return_value = {"id": "skill-1"}
        mock_response.is_success = True
        mock_client.post.return_value = mock_response

        client = APIClient(base_url="https://api.test.com")
        result = client.post(
            "/v1/skills", json_data={"name": "my-skill"}, auth=True
        )

        assert result == {"id": "skill-1"}
        call_kwargs = mock_client.post.call_args
        assert call_kwargs.kwargs["json"] == {"name": "my-skill"}
        headers = call_kwargs.kwargs.get("headers", {})
        assert headers["Authorization"] == "Bearer token-123"

    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_post_http_error_raises_api_error(
        self, mock_client_cls: MagicMock
    ) -> None:
        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_response = MagicMock()
        mock_response.status_code = 422
        mock_response.is_success = False
        mock_response.json.return_value = {"detail": "Validation error"}
        mock_client.post.return_value = mock_response

        client = APIClient(base_url="https://api.test.com")
        with pytest.raises(APIError) as exc_info:
            client.post("/v1/skills", json_data={}, auth=False)

        assert exc_info.value.status_code == 422


class TestAPIClientUpload:
    """Tests for APIClient.upload method."""

    @patch("agentpowers_cli.services.api_client.load_token", return_value="token-xyz")
    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_upload_sends_file(
        self, mock_client_cls: MagicMock, mock_load: MagicMock
    ) -> None:
        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"url": "https://r2.example.com/f"}
        mock_response.is_success = True
        mock_client.post.return_value = mock_response

        client = APIClient(base_url="https://api.test.com")
        result = client.upload(
            "/v1/skills/upload",
            file_data=b"zip-content",
            filename="skill.zip",
        )

        assert result == {"url": "https://r2.example.com/f"}
        call_kwargs = mock_client.post.call_args
        # files kwarg should have the file tuple
        files = call_kwargs.kwargs["files"]
        assert files["file"][0] == "skill.zip"
        assert files["file"][1] == b"zip-content"
