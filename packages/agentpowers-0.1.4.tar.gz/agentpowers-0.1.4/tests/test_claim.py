"""Tests for the claim command."""

from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from agentpowers_cli.main import app
from agentpowers_cli.services.api_client import APIError

runner = CliRunner()


class TestClaimCommand:

    @patch("agentpowers_cli.commands.claim.get_api_client")
    def test_claim_approved(self, mock_get_client: MagicMock) -> None:
        """Test that an approved claim prints success and exits 0."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.return_value = {
            "id": "claim-1",
            "skill_slug": "my-skill",
            "status": "approved",
            "verification_score": 1.0,
            "message": "Claim approved. You now own this skill.",
        }
        result = runner.invoke(app, ["claim", "my-skill"])
        assert result.exit_code == 0
        assert "approved" in result.output.lower()

    @patch("agentpowers_cli.commands.claim.get_api_client")
    def test_claim_approved_shows_score(self, mock_get_client: MagicMock) -> None:
        """Test that an approved claim output includes the verification score."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.return_value = {
            "id": "claim-1",
            "skill_slug": "my-skill",
            "status": "approved",
            "verification_score": 1.0,
            "message": "Claim approved. You now own this skill.",
        }
        result = runner.invoke(app, ["claim", "my-skill"])
        assert result.exit_code == 0
        assert "1.0" in result.output

    @patch("agentpowers_cli.commands.claim.get_api_client")
    def test_claim_sandbox(self, mock_get_client: MagicMock) -> None:
        """Test that a sandbox claim prints review notice and exits 0."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.return_value = {
            "id": "claim-2",
            "skill_slug": "other-skill",
            "status": "sandbox",
            "verification_score": 0.6,
            "message": "Claim under review.",
        }
        result = runner.invoke(app, ["claim", "other-skill"])
        assert result.exit_code == 0
        assert (
            "review" in result.output.lower()
            or "sandbox" in result.output.lower()
        )

    @patch("agentpowers_cli.commands.claim.get_api_client")
    def test_claim_sandbox_shows_score(self, mock_get_client: MagicMock) -> None:
        """Test that a sandbox claim output includes the verification score."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.return_value = {
            "id": "claim-2",
            "skill_slug": "other-skill",
            "status": "sandbox",
            "verification_score": 0.6,
            "message": "Claim under review.",
        }
        result = runner.invoke(app, ["claim", "other-skill"])
        assert result.exit_code == 0
        assert "0.6" in result.output

    @patch("agentpowers_cli.commands.claim.get_api_client")
    def test_claim_rejected(self, mock_get_client: MagicMock) -> None:
        """Test that a rejected claim prints rejection message and exits 0."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.return_value = {
            "id": "claim-3",
            "skill_slug": "not-mine",
            "status": "rejected",
            "verification_score": 0.0,
            "message": "GitHub username does not match.",
        }
        result = runner.invoke(app, ["claim", "not-mine"])
        assert result.exit_code == 0
        assert "rejected" in result.output.lower()

    @patch("agentpowers_cli.commands.claim.get_api_client")
    def test_claim_rejected_shows_score(self, mock_get_client: MagicMock) -> None:
        """Test that a rejected claim output includes the verification score."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.return_value = {
            "id": "claim-3",
            "skill_slug": "not-mine",
            "status": "rejected",
            "verification_score": 0.0,
            "message": "GitHub username does not match.",
        }
        result = runner.invoke(app, ["claim", "not-mine"])
        assert result.exit_code == 0
        assert "0.0" in result.output

    @patch("agentpowers_cli.commands.claim.get_api_client")
    def test_claim_unknown_status(self, mock_get_client: MagicMock) -> None:
        """Test that an unknown status is printed gracefully and exits 0."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.return_value = {
            "id": "claim-4",
            "skill_slug": "weird-skill",
            "status": "pending_manual",
            "verification_score": 0.5,
            "message": "Awaiting manual review.",
        }
        result = runner.invoke(app, ["claim", "weird-skill"])
        assert result.exit_code == 0
        assert (
            "pending_manual" in result.output
            or "awaiting" in result.output.lower()
        )

    @patch("agentpowers_cli.commands.claim.get_api_client")
    def test_claim_not_found(self, mock_get_client: MagicMock) -> None:
        """Test that a 404 error causes exit code 1."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.side_effect = APIError("Skill not found", status_code=404)
        result = runner.invoke(app, ["claim", "nonexistent"])
        assert result.exit_code == 1

    @patch("agentpowers_cli.commands.claim.get_api_client")
    def test_claim_not_found_message(self, mock_get_client: MagicMock) -> None:
        """Test that a 404 error prints the slug in the output."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.side_effect = APIError("Skill not found", status_code=404)
        result = runner.invoke(app, ["claim", "nonexistent"])
        assert "nonexistent" in result.output

    @patch("agentpowers_cli.commands.claim.get_api_client")
    def test_claim_not_logged_in(self, mock_get_client: MagicMock) -> None:
        """Test that a 401 error causes exit code 1."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.side_effect = APIError("Unauthorized", status_code=401)
        result = runner.invoke(app, ["claim", "some-skill"])
        assert result.exit_code == 1

    @patch("agentpowers_cli.commands.claim.get_api_client")
    def test_claim_not_logged_in_message(self, mock_get_client: MagicMock) -> None:
        """Test that a 401 error tells the user to run ap login."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.side_effect = APIError("Unauthorized", status_code=401)
        result = runner.invoke(app, ["claim", "some-skill"])
        assert (
            "login" in result.output.lower()
            or "log in" in result.output.lower()
        )

    @patch("agentpowers_cli.commands.claim.get_api_client")
    def test_claim_already_claimed(self, mock_get_client: MagicMock) -> None:
        """Test that a 409 conflict error causes exit code 1."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.side_effect = APIError("Already claimed", status_code=409)
        result = runner.invoke(app, ["claim", "taken-skill"])
        assert result.exit_code == 1

    @patch("agentpowers_cli.commands.claim.get_api_client")
    def test_claim_already_claimed_message(self, mock_get_client: MagicMock) -> None:
        """Test that a 409 conflict error prints the slug in the output."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.side_effect = APIError("Already claimed", status_code=409)
        result = runner.invoke(app, ["claim", "taken-skill"])
        assert "taken-skill" in result.output

    @patch("agentpowers_cli.commands.claim.get_api_client")
    def test_claim_generic_error(self, mock_get_client: MagicMock) -> None:
        """Test that an unexpected API error causes exit code 1."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.side_effect = APIError(
            "Internal server error", status_code=500
        )
        result = runner.invoke(app, ["claim", "some-skill"])
        assert result.exit_code == 1

    @patch("agentpowers_cli.commands.claim.get_api_client")
    def test_claim_posts_correct_payload(self, mock_get_client: MagicMock) -> None:
        """Test that the claim command POSTs to /v1/skills/{slug}/claim."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.return_value = {
            "id": "claim-5",
            "skill_slug": "my-skill",
            "status": "approved",
            "verification_score": 1.0,
            "message": "Approved.",
        }
        runner.invoke(app, ["claim", "my-skill"])
        mock_client.post.assert_called_once_with(
            "/v1/skills/my-skill/claim",
            auth=True,
        )

    @patch("agentpowers_cli.commands.claim.get_api_client")
    def test_claim_requires_slug_argument(self, mock_get_client: MagicMock) -> None:
        """Test that running claim without a slug shows usage help."""
        result = runner.invoke(app, ["claim"])
        assert result.exit_code != 0
