"""Tests for the republish CLI command."""

from unittest.mock import MagicMock, patch

import httpx
from typer.testing import CliRunner

from agentpowers_cli.main import app
from agentpowers_cli.services.api_client import APIError

runner = CliRunner()


class TestRepublishCommand:

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_success(self, mock_get_client: MagicMock) -> None:
        """Confirmed republish prints success message."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.return_value = {
            "slug": "my-skill",
            "archived_at": None,
            "message": "Skill republished.",
        }
        result = runner.invoke(app, ["republish", "my-skill"], input="y\n")
        assert result.exit_code == 0
        assert "republish" in result.output.lower()
        mock_client.post.assert_called_once_with(
            "/v1/skills/my-skill/republish",
            auth=True,
        )

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_confirmation_declined(self, mock_get_client: MagicMock) -> None:
        """Declining confirmation aborts without API call."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        result = runner.invoke(app, ["republish", "my-skill"], input="n\n")
        assert result.exit_code == 0
        mock_client.post.assert_not_called()
        assert "abort" in result.output.lower()

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_default_no(self, mock_get_client: MagicMock) -> None:
        """Empty input (default N) aborts."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        _result = runner.invoke(app, ["republish", "my-skill"], input="\n")
        mock_client.post.assert_not_called()

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_401_login_prompt(self, mock_get_client: MagicMock) -> None:
        """401 error tells user to login."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.side_effect = APIError("Unauthorized", status_code=401)
        result = runner.invoke(app, ["republish", "my-skill"], input="y\n")
        assert result.exit_code == 1
        assert "login" in result.output.lower()

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_404_not_found(self, mock_get_client: MagicMock) -> None:
        """404 error shows not found message."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.side_effect = APIError("Skill not found", status_code=404)
        result = runner.invoke(app, ["republish", "my-skill"], input="y\n")
        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_403_not_owner(self, mock_get_client: MagicMock) -> None:
        """403 error shows not owner message."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.side_effect = APIError("Not the author", status_code=403)
        result = runner.invoke(app, ["republish", "my-skill"], input="y\n")
        assert result.exit_code == 1
        assert "owner" in result.output.lower() or "author" in result.output.lower()

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_409_not_archived(self, mock_get_client: MagicMock) -> None:
        """409 error shows skill is not archived message."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.side_effect = APIError("Not archived", status_code=409)
        result = runner.invoke(app, ["republish", "my-skill"], input="y\n")
        assert result.exit_code == 1
        assert (
            "not archived" in result.output.lower()
            or "already" in result.output.lower()
        )

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_generic_error(self, mock_get_client: MagicMock) -> None:
        """Unexpected status code (e.g., 500) shows generic error."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.side_effect = APIError(
            "Internal Server Error", status_code=500
        )
        result = runner.invoke(app, ["republish", "my-skill"], input="y\n")
        assert result.exit_code == 1
        assert "error" in result.output.lower()

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_network_error_connect(self, mock_get_client: MagicMock) -> None:
        """Connection refused shows friendly network error."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.side_effect = httpx.ConnectError("Connection refused")
        result = runner.invoke(app, ["republish", "my-skill"], input="y\n")
        assert result.exit_code == 1
        assert "connect" in result.output.lower() or "network" in result.output.lower()

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_network_error_timeout(self, mock_get_client: MagicMock) -> None:
        """Timeout shows friendly timeout error."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.side_effect = httpx.TimeoutException("Request timed out")
        result = runner.invoke(app, ["republish", "my-skill"], input="y\n")
        assert result.exit_code == 1
        assert (
            "timed out" in result.output.lower()
            or "timeout" in result.output.lower()
        )

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_429_rate_limited(self, mock_get_client: MagicMock) -> None:
        """429 rate limit shows appropriate message."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.side_effect = APIError("Rate limit exceeded", status_code=429)
        result = runner.invoke(app, ["republish", "my-skill"], input="y\n")
        assert result.exit_code == 1
        assert (
            "rate" in result.output.lower()
            or "too many" in result.output.lower()
            or "try again" in result.output.lower()
        )

    def test_republish_requires_slug(self) -> None:
        """Running republish without a slug shows usage help."""
        result = runner.invoke(app, ["republish"])
        assert result.exit_code != 0
