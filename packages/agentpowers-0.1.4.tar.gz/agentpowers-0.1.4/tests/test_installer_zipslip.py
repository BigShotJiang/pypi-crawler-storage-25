"""Tests for ZIP Slip path traversal prevention in extract_package."""

from __future__ import annotations

import io
import stat
import zipfile
from pathlib import Path

import pytest

from agentpowers_cli.services.installer import extract_package


def _make_zip(members: dict[str, bytes]) -> bytes:
    """Create a ZIP archive in memory with the given filename->content mapping."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        for name, data in members.items():
            zf.writestr(name, data)
    return buf.getvalue()


def _make_zip_with_symlink(target: str, link_name: str) -> bytes:
    """Create a ZIP archive containing a symlink entry."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        # Add a normal file so the archive isn't empty
        zf.writestr("legit.txt", b"ok")
        # Create a symlink entry
        info = zipfile.ZipInfo(link_name)
        info.create_system = 3  # Unix
        # Set symlink attribute (0xA000 in upper 16 bits of external_attr)
        info.external_attr = (stat.S_IFLNK | 0o777) << 16
        zf.writestr(info, target)
    return buf.getvalue()


class TestZipSlipPrevention:
    """Verify extract_package rejects path traversal attempts."""

    def test_rejects_dot_dot_path(self, tmp_path: Path) -> None:
        """A member with ../../ prefix must be rejected."""
        malicious_zip = _make_zip({
            "../../tmp/zipslip_test": b"pwned",
        })
        with pytest.raises(ValueError, match="path traversal"):
            extract_package(malicious_zip, "evil", "skill", base_dir=tmp_path)

        # The escape file must not exist anywhere
        assert not (tmp_path / "../../tmp/zipslip_test").exists()

    def test_rejects_absolute_path(self, tmp_path: Path) -> None:
        """A member with an absolute path (e.g. /tmp/evil) must be rejected."""
        malicious_zip = _make_zip({
            "/tmp/zipslip_abs_test": b"pwned",
        })
        with pytest.raises(ValueError, match="path traversal"):
            extract_package(malicious_zip, "evil", "skill", base_dir=tmp_path)

        assert not Path("/tmp/zipslip_abs_test").exists()

    def test_rejects_backslash_traversal(self, tmp_path: Path) -> None:
        """Windows-style backslash traversal must also be rejected."""
        malicious_zip = _make_zip({
            "..\\..\\tmp\\zipslip_win": b"pwned",
        })
        with pytest.raises(ValueError, match="path traversal"):
            extract_package(malicious_zip, "evil", "skill", base_dir=tmp_path)

    def test_rejects_symlink(self, tmp_path: Path) -> None:
        """Symlink entries must be rejected to prevent symlink attacks."""
        malicious_zip = _make_zip_with_symlink(
            target="/etc/passwd",
            link_name="evil_link",
        )
        with pytest.raises(ValueError, match="symlink"):
            extract_package(malicious_zip, "evil", "skill", base_dir=tmp_path)

    def test_rejects_nested_traversal(self, tmp_path: Path) -> None:
        """A member like 'foo/../../../etc/passwd' must be rejected."""
        malicious_zip = _make_zip({
            "foo/../../../etc/passwd": b"pwned",
        })
        with pytest.raises(ValueError, match="path traversal"):
            extract_package(malicious_zip, "evil", "skill", base_dir=tmp_path)

    def test_allows_legitimate_paths(self, tmp_path: Path) -> None:
        """Normal files must still be extracted correctly."""
        legit_zip = _make_zip({
            "CLAUDE.md": b"# My skill",
            "src/main.py": b"print('hello')",
            "src/utils/helper.py": b"def h(): pass",
        })
        dest = extract_package(legit_zip, "good-skill", "skill", base_dir=tmp_path)
        assert (dest / "CLAUDE.md").read_bytes() == b"# My skill"
        assert (dest / "src/main.py").read_bytes() == b"print('hello')"
        assert (dest / "src/utils/helper.py").read_bytes() == b"def h(): pass"

    def test_mixed_good_and_bad_rejects_all(self, tmp_path: Path) -> None:
        """If any member is malicious, the entire extraction must fail."""
        mixed_zip = _make_zip({
            "legit.txt": b"ok",
            "../../escape.txt": b"pwned",
        })
        with pytest.raises(ValueError, match="path traversal"):
            extract_package(mixed_zip, "mixed", "skill", base_dir=tmp_path)

        # Even the legit file should not be extracted (fail-fast)
        # The destination directory might exist but should be cleaned up or
        # the legit file should not have been written
