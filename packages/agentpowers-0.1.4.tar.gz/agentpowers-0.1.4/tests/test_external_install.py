"""Tests for external skill installation flow."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import ANY, MagicMock, patch

from typer.testing import CliRunner

from agentpowers_cli.main import app

runner = CliRunner()


class TestExternalInstallCommand:
    """Tests for the install command with --source flag."""

    @patch("agentpowers_cli.commands.install.install_external_skill")
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_install_external_skill_from_db(
        self, mock_get_client: MagicMock, mock_ext_install: MagicMock
    ) -> None:
        """--source flag goes straight to external installer even if in DB."""
        client = MagicMock()
        mock_get_client.return_value = client
        mock_ext_install.return_value = "/tmp/installed"

        result = runner.invoke(app, ["install", "ext-skill", "--source", "clawhub"])

        assert result.exit_code == 0
        assert "Installed" in result.output
        mock_ext_install.assert_called_once_with(
            client, "ext-skill", "clawhub", base_dir=ANY
        )

    @patch("agentpowers_cli.commands.install.install_external_skill")
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_install_external_skill_not_in_db(
        self, mock_get_client: MagicMock, mock_ext_install: MagicMock
    ) -> None:
        """--source flag goes straight to external installer."""
        client = MagicMock()
        mock_get_client.return_value = client
        mock_ext_install.return_value = "/tmp/installed"

        result = runner.invoke(app, ["install", "ext-skill", "--source", "clawhub"])

        assert result.exit_code == 0
        assert "Installed" in result.output
        mock_ext_install.assert_called_once_with(
            client, "ext-skill", "clawhub", base_dir=ANY
        )

    @patch("agentpowers_cli.commands.install.install_external_skill")
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_install_external_skill_with_source_from_response(
        self, mock_get_client: MagicMock, mock_ext_install: MagicMock
    ) -> None:
        """Skill in DB with non-agentpowers source routes externally."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.return_value = {
            "slug": "clawhub-skill",
            "title": "ClawHub Skill",
            "type": "agent",
            "source": "clawhub",
            "version": "2.0.0",
            "security_status": "pass",
            "price_cents": 0,
        }
        mock_ext_install.return_value = "/tmp/installed"

        result = runner.invoke(app, ["install", "clawhub-skill"])

        assert result.exit_code == 0
        mock_ext_install.assert_called_once_with(
            client, "clawhub-skill", "clawhub", "agent", version="2.0.0", base_dir=ANY
        )

    @patch(
        "agentpowers_cli.commands.install.install_from_url",
        return_value="/home/.claude/skills/s",
    )
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_install_native_skill_unchanged(
        self, mock_get_client: MagicMock, mock_install_url: MagicMock
    ) -> None:
        """Native skill (no --source, source=agentpowers) follows existing path."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.side_effect = [
            {
                "slug": "native-skill",
                "title": "Native",
                "type": "skill",
                "source": "agentpowers",
                "security_status": "pass",
                "price_cents": 0,
            },
            {"url": "https://r2.example.com/package.zip", "slug": "native-skill"},
        ]

        result = runner.invoke(app, ["install", "native-skill"])

        assert result.exit_code == 0
        assert "Installed" in result.output
        mock_install_url.assert_called_once()

    @patch(
        "agentpowers_cli.commands.install.install_from_url",
        return_value="/home/.claude/skills/s",
    )
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_install_skill_without_source_field_defaults_native(
        self, mock_get_client: MagicMock, mock_install_url: MagicMock
    ) -> None:
        """Skill response without 'source' field defaults to agentpowers."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.side_effect = [
            {
                "slug": "old-skill",
                "title": "Old Skill",
                "type": "skill",
                "security_status": "pass",
                "price_cents": 0,
            },
            {"url": "https://r2.example.com/package.zip"},
        ]

        result = runner.invoke(app, ["install", "old-skill"])

        assert result.exit_code == 0
        mock_install_url.assert_called_once()


class TestExternalInstallTracking:
    """Verify that record_installation is called after successful external installs."""

    @patch("agentpowers_cli.commands.install.install_external_skill")
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_record_installation_called_after_external_install(
        self, mock_get_client: MagicMock, mock_ext_install: MagicMock
    ) -> None:
        """record_installation is called with correct source after --source install."""
        client = MagicMock()
        mock_get_client.return_value = client
        mock_ext_install.return_value = "/tmp/installed"

        result = runner.invoke(app, ["install", "ext-skill", "--source", "clawhub"])

        assert result.exit_code == 0
        client.record_installation.assert_called_once()
        call_args = client.record_installation.call_args[0]
        assert call_args[0] == "ext-skill"   # source_slug
        assert call_args[1] == "cli"          # platform
        assert call_args[2] == "clawhub"      # source

    @patch("agentpowers_cli.commands.install.install_external_skill")
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_record_installation_not_called_when_external_install_fails(
        self, mock_get_client: MagicMock, mock_ext_install: MagicMock
    ) -> None:
        """record_installation is NOT called when external install raises."""
        from agentpowers_cli.services.api_client import APIError
        client = MagicMock()
        mock_get_client.return_value = client
        mock_ext_install.side_effect = APIError("Download failed", status_code=500)

        result = runner.invoke(app, ["install", "broken-skill", "--source", "clawhub"])

        assert result.exit_code != 0
        client.record_installation.assert_not_called()

    @patch("agentpowers_cli.commands.install.install_external_skill")
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_record_installation_called_for_waterfall_external(
        self, mock_get_client: MagicMock, mock_ext_install: MagicMock
    ) -> None:
        """Waterfall external discover also calls record_installation."""
        from agentpowers_cli.services.api_client import APIError as _APIError
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.side_effect = [
            _APIError("Not found", status_code=404),
            {
                "agentpowers": {"items": [], "total": 0},
                "clawhub": {
                    "total": 1,
                    "items": [{"slug": "weather", "title": "Weather",
                               "source": "clawhub", "source_installs": 10, "version": "1.0"}],
                },
            },
        ]
        mock_ext_install.return_value = "/tmp/weather"

        result = runner.invoke(app, ["install", "weather"])

        assert result.exit_code == 0
        client.record_installation.assert_called_once()
        call_args = client.record_installation.call_args[0]
        assert call_args[0] == "weather"
        assert call_args[2] == "clawhub"


class TestExternalInstallerDoubleNesting:
    """Tests for the inner-directory detection that prevents double nesting."""

    @patch("agentpowers_cli.services.external_installer.save_pin")
    @patch("agentpowers_cli.services.external_installer.hash_directory")
    @patch("agentpowers_cli.services.external_installer.subprocess")
    def test_inner_slug_directory_stripped(
        self,
        mock_subprocess: MagicMock,
        mock_hash: MagicMock,
        mock_save_pin: MagicMock,
        tmp_path,
    ) -> None:
        """When npx creates sandbox/slug/SKILL.md, only inner contents are copied."""
        from agentpowers_cli.services.external_installer import install_external_skill

        # Simulate npx creating slug-named subdirectory in sandbox
        def fake_run(cmd, **kwargs):
            sandbox_dir = cmd[cmd.index("--dir") + 1]
            inner = Path(sandbox_dir) / "my-skill"
            inner.mkdir(parents=True)
            (inner / "SKILL.md").write_text("# My Skill")
            (inner / "README.md").write_text("readme")
            return MagicMock(returncode=0, stderr="")

        mock_subprocess.run.side_effect = fake_run
        mock_hash.return_value = "sha256:abc"

        client = MagicMock()
        client.get.return_value = {"security_status": "pass"}

        pins_file = str(tmp_path / "pins.json")
        dest = install_external_skill(
            client, "my-skill", "clawhub",
            pins_path=pins_file, base_dir=tmp_path,
        )

        dest_path = Path(dest)
        # SKILL.md should be directly in dest, not in dest/my-skill/
        assert (dest_path / "SKILL.md").exists()
        assert not (dest_path / "my-skill" / "SKILL.md").exists()

    @patch("agentpowers_cli.services.external_installer.save_pin")
    @patch("agentpowers_cli.services.external_installer.hash_directory")
    @patch("agentpowers_cli.services.external_installer.subprocess")
    def test_flat_sandbox_copied_directly(
        self,
        mock_subprocess: MagicMock,
        mock_hash: MagicMock,
        mock_save_pin: MagicMock,
        tmp_path,
    ) -> None:
        """When npx puts files directly in sandbox (no inner dir), they copy fine."""
        from agentpowers_cli.services.external_installer import install_external_skill

        def fake_run(cmd, **kwargs):
            sandbox_dir = cmd[cmd.index("--dir") + 1]
            Path(sandbox_dir).mkdir(parents=True, exist_ok=True)
            (Path(sandbox_dir) / "SKILL.md").write_text("# Flat Skill")
            return MagicMock(returncode=0, stderr="")

        mock_subprocess.run.side_effect = fake_run
        mock_hash.return_value = "sha256:flat"

        client = MagicMock()
        client.get.return_value = {"security_status": "pass"}

        pins_file = str(tmp_path / "pins.json")
        dest = install_external_skill(
            client, "flat-skill", "clawhub",
            pins_path=pins_file, base_dir=tmp_path,
        )

        assert (Path(dest) / "SKILL.md").exists()


class TestExternalInstallerService:
    """Tests for the external_installer module directly."""

    @patch("agentpowers_cli.services.external_installer.save_pin")
    @patch("agentpowers_cli.services.external_installer.get_claude_dir")
    @patch("agentpowers_cli.services.external_installer.hash_directory")
    @patch("agentpowers_cli.services.external_installer.subprocess")
    def test_install_with_cache_hit(
        self,
        mock_subprocess: MagicMock,
        mock_hash: MagicMock,
        mock_claude_dir: MagicMock,
        mock_save_pin: MagicMock,
        tmp_path,
    ) -> None:
        """External skill with cached scan result skips scanning."""
        from agentpowers_cli.services.external_installer import install_external_skill

        # Setup mocks
        mock_subprocess.run.return_value = MagicMock(returncode=0, stderr="")
        mock_hash.return_value = "sha256:cached123"
        mock_claude_dir.return_value = tmp_path

        client = MagicMock()
        client.get.return_value = {"security_status": "pass"}

        pins_file = str(tmp_path / "pins.json")
        dest = install_external_skill(
            client, "cached-skill", "clawhub", pins_path=pins_file
        )

        assert "cached-skill" in dest
        client.get.assert_called_once_with("/v1/security/check/sha256:cached123")
        mock_save_pin.assert_called_once()

    @patch("agentpowers_cli.services.external_installer.save_pin")
    @patch("agentpowers_cli.services.external_installer.get_claude_dir")
    @patch("agentpowers_cli.services.external_installer._scan_package")
    @patch("agentpowers_cli.services.external_installer.hash_directory")
    @patch("agentpowers_cli.services.external_installer.subprocess")
    def test_install_with_cache_miss_runs_scan(
        self,
        mock_subprocess: MagicMock,
        mock_hash: MagicMock,
        mock_scan: MagicMock,
        mock_claude_dir: MagicMock,
        mock_save_pin: MagicMock,
        tmp_path,
    ) -> None:
        """Cache miss triggers full security scan."""
        from agentpowers_cli.services.api_client import APIError
        from agentpowers_cli.services.external_installer import install_external_skill

        mock_subprocess.run.return_value = MagicMock(returncode=0, stderr="")
        mock_hash.return_value = "sha256:new123"
        mock_claude_dir.return_value = tmp_path
        mock_scan.return_value = ("pass", "sha256:server-new123")

        client = MagicMock()
        client.get.side_effect = APIError("Not found", status_code=404)

        pins_file = str(tmp_path / "pins.json")
        dest = install_external_skill(
            client, "new-skill", "clawhub", pins_path=pins_file
        )

        assert "new-skill" in dest
        mock_scan.assert_called_once()

    @patch("agentpowers_cli.services.external_installer.get_claude_dir")
    @patch("agentpowers_cli.services.external_installer.hash_directory")
    @patch("agentpowers_cli.services.external_installer.subprocess")
    def test_install_blocked_skill_exits(
        self,
        mock_subprocess: MagicMock,
        mock_hash: MagicMock,
        mock_claude_dir: MagicMock,
        tmp_path,
    ) -> None:
        """Blocked security status exits with code 1."""
        import click
        import pytest

        from agentpowers_cli.services.external_installer import install_external_skill

        mock_subprocess.run.return_value = MagicMock(returncode=0, stderr="")
        mock_hash.return_value = "sha256:bad123"
        mock_claude_dir.return_value = tmp_path

        client = MagicMock()
        client.get.return_value = {"security_status": "block"}

        with pytest.raises(click.exceptions.Exit):
            install_external_skill(client, "bad-skill", "clawhub")

    @patch("agentpowers_cli.services.external_installer.save_pin")
    @patch("agentpowers_cli.services.external_installer.get_claude_dir")
    @patch("agentpowers_cli.services.external_installer._scan_package")
    @patch("agentpowers_cli.services.external_installer.hash_directory")
    @patch("agentpowers_cli.services.external_installer.subprocess")
    def test_install_uses_server_hash_for_pinning(
        self,
        mock_subprocess: MagicMock,
        mock_hash: MagicMock,
        mock_scan: MagicMock,
        mock_claude_dir: MagicMock,
        mock_save_pin: MagicMock,
        tmp_path,
    ) -> None:
        """Pin uses server-returned hash, not client-computed hash."""
        from agentpowers_cli.services.api_client import APIError
        from agentpowers_cli.services.external_installer import install_external_skill

        mock_subprocess.run.return_value = MagicMock(returncode=0, stderr="")
        mock_hash.return_value = "sha256:client-computed"
        mock_claude_dir.return_value = tmp_path
        # _scan_package returns (status, server_hash)
        mock_scan.return_value = ("pass", "sha256:server-computed")

        client = MagicMock()
        client.get.side_effect = APIError("Not found", status_code=404)

        pins_file = str(tmp_path / "pins.json")
        install_external_skill(
            client, "hash-skill", "clawhub", pins_path=pins_file
        )

        # Pin must use server-computed hash, not client-computed
        pin_call = mock_save_pin.call_args
        assert pin_call[0][3] == "sha256:server-computed"  # content_hash arg

    @patch("agentpowers_cli.services.external_installer.subprocess")
    def test_install_download_failure_exits(
        self, mock_subprocess: MagicMock
    ) -> None:
        """Failed external download exits with code 1."""
        import click
        import pytest

        from agentpowers_cli.services.external_installer import install_external_skill

        mock_subprocess.run.return_value = MagicMock(
            returncode=1, stderr="install failed"
        )

        client = MagicMock()

        with pytest.raises(click.exceptions.Exit):
            install_external_skill(client, "broken-skill", "clawhub")

    @patch("agentpowers_cli.services.external_installer.save_pin")
    @patch("agentpowers_cli.services.external_installer.get_claude_dir")
    @patch("agentpowers_cli.services.external_installer.hash_directory")
    @patch("agentpowers_cli.services.external_installer.subprocess")
    def test_cli_command_uses_source_as_package_name(
        self,
        mock_subprocess: MagicMock,
        mock_hash: MagicMock,
        mock_claude_dir: MagicMock,
        mock_save_pin: MagicMock,
        tmp_path,
    ) -> None:
        """Subprocess command uses source name directly (e.g. 'npx clawhub')."""
        from agentpowers_cli.services.external_installer import install_external_skill

        mock_subprocess.run.return_value = MagicMock(returncode=0, stderr="")
        mock_hash.return_value = "sha256:abc"
        mock_claude_dir.return_value = tmp_path

        client = MagicMock()
        client.get.return_value = {"security_status": "pass"}

        pins_file = str(tmp_path / "pins.json")
        install_external_skill(client, "test-skill", "clawhub", pins_path=pins_file)

        call_args = mock_subprocess.run.call_args[0][0]
        assert call_args[0] == "npx"
        assert call_args[1] == "clawhub"
        assert "--no-input" in call_args
        assert "test-skill" in call_args
