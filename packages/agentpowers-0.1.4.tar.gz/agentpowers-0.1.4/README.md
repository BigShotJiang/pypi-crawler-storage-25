# AgentPowers CLI

The `ap` command-line tool for the AgentPowers marketplace.

## Status

**Phase 1E: Complete** -- 73 passing tests. All core commands implemented including `ap claim`.

## Commands

- `ap login` -- Open browser for Clerk auth, store JWT locally
- `ap logout` -- Remove stored credentials
- `ap whoami` -- Show current user info
- `ap search <query>` -- Search the marketplace (Rich table output)
- `ap install <slug> [--code XXXX]` -- Install a skill or agent (with optional license code)
- `ap publish [--price N] [--dir .] [--category dev]` -- Package and publish a skill or agent
- `ap claim <slug>` -- Claim ownership of a ClawHub-imported skill

## Development

```bash
cd agentpowers-cli
uv venv .venv && source .venv/bin/activate
uv pip install -e ".[dev]"
ap --help
pytest tests/ -v    # Run tests
```

## Auth

Credentials stored at `~/.agentpowers/auth.json` (permissions: 600). Shared with the Claude Code plugin's MCP server.
