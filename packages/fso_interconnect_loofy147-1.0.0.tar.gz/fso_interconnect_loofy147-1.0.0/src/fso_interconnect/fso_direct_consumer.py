import importlib
import subprocess
import sys
import hashlib
from typing import Any, Dict, List, Tuple
import numpy as np

class FSODirectConsumer:
    """
    Directly consumes industrial-grade libraries (pip installed)
    and maps their functions to FSO Hamiltonian Coordinates.
    """
    def __init__(self, m: int):
        self.m = m

    def _ensure_package(self, package_name: str):
        """Ensures the industry logic is present on the node."""
        try:
            importlib.import_module(package_name)
        except ImportError:
            print(f"[*] Node {package_name} missing. Auto-provisioning logic...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", package_name])

    def get_coords(self, function_identity: str) -> Tuple[int, int, int]:
        """Maps 'package.module.function' to a Torus coordinate."""
        h = int(hashlib.sha256(function_identity.encode()).hexdigest(), 16)
        return (h % self.m, (h // self.m) % self.m, (h // (self.m**2)) % self.m)

    def execute_logic(self, call_spec: str, params: Any):
        """
        Example call_spec: 'skimage.filters.gaussian'
        The node imports it dynamically and executes it.
        params can be a list (positional) or dict (keyword).
        """
        parts = call_spec.split('.')
        package_name = parts[0]
        self._ensure_package(package_name)

        # Dynamic Resolution
        if len(parts) > 1:
            # Special case for torch.add and other multi-part modules
            module_parts = parts[:-1]
            func_name = parts[-1]
            try:
                module = importlib.import_module(".".join(module_parts))
                func = getattr(module, func_name)
            except (ImportError, AttributeError):
                # Fallback: maybe the first two parts are the module
                if len(parts) > 2:
                    module = importlib.import_module(".".join(parts[:2]))
                    func = getattr(module, ".".join(parts[2:]))
                else:
                    raise
        else:
            module = importlib.import_module(package_name)
            func = module

        # Industrial Pre-processing: Positional vs Keyword
        if isinstance(params, list):
            # Positional processing (convert lists to numpy/torch if they look like arrays)
            # We favor numpy as the universal baseline.
            processed_params = [
                np.array(p) if isinstance(p, list) and len(p) > 0 and isinstance(p[0], (int, float, list))
                else p for p in params
            ]
            return func(*processed_params)
        elif isinstance(params, dict):
            # Keyword processing
            processed_params = {
                k: (np.array(v) if isinstance(v, list) and len(v) > 0 and isinstance(v[0], (int, float, list))
                    else v) for k, v in params.items()
            }
            return func(**processed_params)
        else:
            # Single argument
            return func(params)

if __name__ == "__main__":
    dc = FSODirectConsumer(m=31)
    print(f"Math.cos(1.57): {dc.execute_logic('math.cos', 1.5707963267948966)}")
    # Test torch
    import torch
    print(f"Torch.add(2,2): {dc.execute_logic('torch.add', [2, 2])}")
