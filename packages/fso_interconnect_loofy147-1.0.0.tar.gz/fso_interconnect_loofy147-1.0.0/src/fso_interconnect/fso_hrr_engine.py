"""
FSO HRR ENGINE v1.1 (Production - FFT Accelerated)
The mathematical engine for high-dimensional semantic concept binding.
Implements Holographic Reduced Representations (Plate, 1995).
Uses numpy.fft for O(d log d) circular convolution/correlation.
"""
import math
import random
import numpy as np
from typing import List, Union

class HRREngine:
    def __init__(self, dim: int = 1024):
        self.dim = dim

    def generate_vector(self) -> List[float]:
        """Generates a d-dimensional normalized Gaussian vector."""
        std_dev = math.sqrt(1.0 / self.dim)
        # Using numpy for faster generation
        return np.random.normal(0, std_dev, self.dim).tolist()

    def circular_convolution(self, a: Union[List[float], np.ndarray], b: Union[List[float], np.ndarray]) -> List[float]:
        """
        Binds two concepts into a single high-dimensional trace.
        Complexity: O(d log d) via FFT.
        """
        a_fft = np.fft.fft(a)
        b_fft = np.fft.fft(b)
        res = np.fft.ifft(a_fft * b_fft).real
        return res.tolist()

    def circular_correlation(self, a: Union[List[float], np.ndarray], b: Union[List[float], np.ndarray]) -> List[float]:
        """
        Unbinds a concept from a trace using its approximate inverse.
        Complexity: O(d log d) via FFT.
        """
        a_fft = np.fft.fft(a)
        b_fft = np.fft.fft(b)
        # Correlation in frequency domain is conj(A) * B
        res = np.fft.ifft(np.conj(a_fft) * b_fft).real
        return res.tolist()

    def cosine_similarity(self, a: Union[List[float], np.ndarray], b: Union[List[float], np.ndarray]) -> float:
        """Measures the semantic intersection between two vectors."""
        a = np.array(a)
        b = np.array(b)
        dot = np.dot(a, b)
        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)
        if norm_a == 0 or norm_b == 0: return 0.0
        return float(dot / (norm_a * norm_b))
