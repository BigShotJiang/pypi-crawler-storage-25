from fso_kernel import FSOTopology, FSOMessage
import random

class Task:
    """A unit of work to be processed by a node."""
    def __init__(self, task_id, payload=None):
        self.task_id = task_id
        self.payload = payload
        self.completed = False
        self.completed_by = None

    def __repr__(self):
        return f"Task(id={self.task_id}, done={self.completed}, by={self.completed_by})"

class FSONode:
    """A virtual node in the FSO Torus."""
    def __init__(self, coords):
        self.coords = coords
        self.busy_until = 0

    def is_idle(self, current_time):
        return current_time >= self.busy_until

    def process(self, task, current_time, duration=1):
        task.completed = True
        task.completed_by = self.coords
        self.busy_until = current_time + duration
        return task

class FSOTaskQueue:
    """A distributed task queue powered by FSO Hamiltonian cycles."""
    def __init__(self, m, k=3):
        self.m = m
        self.k = k
        self.topology = FSOTopology(m, k)
        self.nodes = {
            coords: FSONode(coords)
            for coords in self._generate_coords(m, k)
        }
        self.messages = []
        self.current_time = 0

    def _generate_coords(self, m, k):
        import itertools
        return itertools.product(range(m), repeat=k)

    def add_task(self, task, color=0, origin=(0, 0, 0)):
        """Injects a task into the manifold."""
        msg = FSOMessage(task, origin, color)
        self.messages.append(msg)

    def tick(self):
        """Advances the simulation by one step."""
        next_messages = []
        completed_this_tick = []

        for msg in self.messages:
            node = self.nodes[msg.current_pos]

            if not msg.payload.completed and node.is_idle(self.current_time):
                # Node grabs the task!
                node.process(msg.payload, self.current_time)
                completed_this_tick.append(msg.payload)
                # Task stays in the message but marked completed,
                # or we could drop the message.
                # Let's keep moving it for 'Closure' demonstration,
                # but it won't be grabbed again.

            # Move the message regardless (simulating continuous flow)
            msg.move(self.topology)

            # If the task has circled back to start and is done, discard message
            if msg.hops < self.m**self.k:
                next_messages.append(msg)
            elif not msg.payload.completed:
                # Re-inject if not completed after a full cycle?
                msg.hops = 0
                next_messages.append(msg)

        self.messages = next_messages
        self.current_time += 1
        return completed_this_tick
