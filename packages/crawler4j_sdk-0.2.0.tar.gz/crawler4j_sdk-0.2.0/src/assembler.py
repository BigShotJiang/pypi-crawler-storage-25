"""Module Assembler for Crawler4j modules.

This module provides the ModuleAssembler class which handles automatic discovery
of tasks and workflows within a module, and provides a standardized entry point.
"""

import importlib
import inspect
import logging
from pathlib import Path
from pkgutil import iter_modules
from typing import Any, Callable, Dict, Optional, Type

import yaml

from crawler4j_sdk.base import TaskScript
from crawler4j_sdk.context import TaskContext
from crawler4j_sdk.env_selector import EnvSelectorInfo, get_env_selector_info, invoke_env_selector
from crawler4j_sdk.result import TaskResult
from crawler4j_sdk.workflow import TaskFlow

logger = logging.getLogger(__name__)


class ModuleAssembler:
    """Handles discovery and execution of module components."""

    def __init__(self, package_root: Path, module_name: str, default_workflow: str = ""):
        self.package_root = package_root
        self.module_name = module_name
        self.default_workflow = default_workflow
        self.task_scripts: Dict[str, Type[TaskScript]] = {}
        self.workflows: Dict[str, Type[TaskFlow]] = {}
        self.discovery_errors: Dict[str, str] = {}

        # Hooks that can be overridden by module_runtime.py
        self.hooks: Dict[str, Callable] = {}
        self.env_selectors: Dict[str, Callable] = {}
        self.env_selector_infos: Dict[str, EnvSelectorInfo] = {}

        self._load_manifest()
        self._discover()
        self._load_runtime_extensions()

    def _load_manifest(self):
        """Load default_workflow from module.yaml if not set."""
        manifest_path = self.package_root / "module.yaml"
        if manifest_path.exists():
            try:
                with open(manifest_path, "r", encoding="utf-8") as f:
                    manifest = yaml.safe_load(f)
                    if manifest and not self.default_workflow:
                        workflows = manifest.get("workflows", [])
                        if workflows and isinstance(workflows, list):
                            self.default_workflow = workflows[0].get("name", "")
            except Exception as e:
                logger.warning(f"Failed to load manifest at {manifest_path}: {e}")

    def _load_registry(self, subpackage: str, base_cls: type) -> Dict[str, type]:
        registry: Dict[str, type] = {}
        package_dir = self.package_root / subpackage
        if not package_dir.exists():
            return registry

        full_package_name = f"{self.module_name}.{subpackage}"
        for module_info in iter_modules([str(package_dir)]):
            if module_info.name.startswith("_"):
                continue
            import_target = f"{full_package_name}.{module_info.name}"
            try:
                module = importlib.import_module(import_target)
                for attr_name in dir(module):
                    candidate = getattr(module, attr_name)
                    if (
                        inspect.isclass(candidate)
                        and issubclass(candidate, base_cls)
                        and candidate is not base_cls
                        ):
                        key = getattr(candidate, "name", "") or module_info.name
                        registry[key] = candidate
            except Exception as exc:
                error_message = (
                    f"Failed to import {import_target} during {subpackage} discovery: "
                    f"{exc.__class__.__name__}: {exc}"
                )
                self.discovery_errors[module_info.name] = error_message
                logger.exception(error_message)
                continue
        return registry

    def _discover(self):
        """Automatically discover tasks and workflows."""
        self.task_scripts = self._load_registry("tasks", TaskScript)
        self.workflows = self._load_registry("workflows", TaskFlow)

    def _load_runtime_extensions(self):
        """Load optional module_runtime.py extensions."""
        runtime_path = self.package_root / "module_runtime.py"
        if runtime_path.exists():
            try:
                runtime_module = importlib.import_module(f"{self.module_name}.module_runtime")

                # Load hooks if present
                hook_names = [
                    "prepare_env",
                    "init_env",
                    "before_run",
                    "on_success",
                    "on_failure",
                    "on_timeout",
                    "on_cleanup",
                ]
                for name in hook_names:
                    if hasattr(runtime_module, name):
                        self.hooks[name] = getattr(runtime_module, name)

                # Allow overriding default_workflow
                if hasattr(runtime_module, "DEFAULT_WORKFLOW"):
                    self.default_workflow = getattr(runtime_module, "DEFAULT_WORKFLOW")

                # Allow manual registration/override of tasks/workflows
                if hasattr(runtime_module, "TASK_SCRIPTS"):
                    self.task_scripts.update(getattr(runtime_module, "TASK_SCRIPTS"))
                if hasattr(runtime_module, "WORKFLOWS"):
                    self.workflows.update(getattr(runtime_module, "WORKFLOWS"))

                for attr_name in dir(runtime_module):
                    candidate = getattr(runtime_module, attr_name)
                    info = get_env_selector_info(candidate)
                    if not info:
                        continue
                    self.env_selectors[info.name] = candidate
                    self.env_selector_infos[info.name] = info

            except Exception as e:
                logger.exception(f"Failed to load runtime extensions: {e}")

    @staticmethod
    def _normalize_result_payload(result: object) -> TaskResult:
        if isinstance(result, TaskResult):
            return result
        if result is None:
            return TaskResult.ok()
        if isinstance(result, dict):
            return TaskResult.ok(data=result)
        return TaskResult.ok(data={"value": result})

    async def _run_task_script(self, script_cls: Type[TaskScript], ctx: TaskContext) -> TaskResult:
        script = script_cls()
        result = await script.execute(ctx)
        return self._normalize_result_payload(result)

    async def _run_task_flow(self, flow_cls: Type[TaskFlow], ctx: TaskContext) -> TaskResult:
        flow = flow_cls()
        result = await flow.run(ctx)
        if result is None:
            return TaskResult.ok(data=dict(ctx.state))
        return self._normalize_result_payload(result)

    async def _subtask_executor(self, task_name: str, ctx: TaskContext) -> TaskResult:
        if task_name not in self.task_scripts:
            raise ValueError(f"Unknown subtask: {task_name}")
        return await self._run_task_script(self.task_scripts[task_name], ctx)

    @staticmethod
    def _resolve_workflow_name(context: TaskContext, default_workflow: str) -> str:
        """Resolve workflow selection from runtime only."""
        runtime = getattr(context, "runtime", None)
        if isinstance(runtime, dict):
            workflow_name = runtime.get("workflow")
            if isinstance(workflow_name, str) and workflow_name.strip():
                return workflow_name
        return default_workflow

    async def run(self, context: TaskContext) -> TaskResult:
        """Module execution entry point."""
        workflow_name = self._resolve_workflow_name(context, self.default_workflow)

        if workflow_name in self.workflows:
            context._subtask_executor = self._subtask_executor
            return await self._run_task_flow(self.workflows[workflow_name], context)

        if workflow_name in self.task_scripts:
            return await self._run_task_script(self.task_scripts[workflow_name], context)

        discovery_error = self.discovery_errors.get(workflow_name)
        if discovery_error:
            raise ValueError(f"Workflow or task not found: {workflow_name}. {discovery_error}")

        raise ValueError(f"Workflow or task not found: {workflow_name}")

    def get_hook(self, name: str) -> Optional[Callable]:
        """Get a registered hook by name."""
        return self.hooks.get(name)

    def get_env_selector(self, name: str) -> Optional[Callable]:
        """Get a registered env selector callback by name."""
        return self.env_selectors.get(name)

    def list_env_selectors(self) -> list[EnvSelectorInfo]:
        """List registered env selectors in stable name order."""
        return [
            self.env_selector_infos[name]
            for name in sorted(self.env_selector_infos)
        ]

    async def run_env_selector(
        self,
        name: str,
        context: TaskContext,
        candidates: list[Any],
    ) -> Any:
        selector = self.get_env_selector(name)
        if not selector:
            raise ValueError(f"Env selector not found: {name}")
        return await invoke_env_selector(selector, context, candidates)
