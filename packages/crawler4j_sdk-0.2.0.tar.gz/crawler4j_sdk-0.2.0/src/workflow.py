"""TaskFlow 工作流编排基类。

本模块定义了 Crawler4j SDK 的核心契约之一：TaskFlow（工作流编排基类）。
TaskFlow 用于把多个 TaskScript 组合成一个可取消、可重试、可观测的复合流程。

稳定契约 (Stable API - 同 MAJOR 版本内冻结):
    - 类属性: name, display_name, description
    - 方法: run

参考规格: docs/02-requirements/reference-srs/06-sdk/06-2-taskflow.md
"""

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from crawler4j_sdk.context import TaskContext
    from crawler4j_sdk.result import TaskResult


class TaskFlow(ABC):
    """工作流编排基类。
    
    TaskFlow 用于把多个 TaskScript 组合成一个"可取消、可重试、可观测"的复合流程。
    通过 Python 代码方式编排子任务的执行顺序：顺序、循环、分支、条件判断。
    
    类属性 (Stable):
        name: 工作流唯一标识符 (MUST)，用于调度、引用和追溯。
        display_name: 面向 UI/日志的可读名称 (SHOULD)。
        description: 简要说明 (SHOULD)。
    
    子任务调用:
        - 通过 ctx.run_subtask("task_name", **kwargs) 调用子任务
        - kwargs 会合并到 ctx.state，子任务共享同一个 state
        - 成功且有 payload 时返回子任务 TaskResult.data
        - 成功但无 payload 时返回 True
        - 失败时返回一个可按 dict 读取、但布尔值为 False 的失败结果
    
    停止/取消语义:
        - ctx.request_stop(): 请求停止工作流
        - ctx.should_stop(): 检查停止标志，长循环必须周期性检查
    
    断点恢复建议:
        - 将可恢复点写入 ctx.state，例如 cursor/phase/last_task_id
        - 运行时在需要时将 ctx.state 持久化并在重试/恢复时回灌
    
    示例:
        >>> from crawler4j_sdk import TaskFlow, TaskContext
        >>>
        >>> class DemoWorkflow(TaskFlow):
        ...     name = "demo_workflow"
        ...     display_name = "示例工作流"
        ...     description = "演示如何顺序编排子任务"
        ...
        ...     async def run(self, ctx: TaskContext) -> None:
        ...         await ctx.run_subtask("login")
        ...
        ...         while not ctx.should_stop():
        ...             ctx.state["phase"] = "claim"
        ...             task = await ctx.run_subtask("claim_task")
        ...             if not task:
        ...                 break
        ...
        ...             ctx.state["phase"] = "process"
        ...             data = await ctx.run_subtask("process_task", task=task)
        ...
        ...             ctx.state["phase"] = "finalize"
        ...             await ctx.run_subtask("finalize_task", data=data)
    """
    
    # === 类属性 (Stable) ===
    
    name: str = ""
    """工作流唯一标识符 (MUST)。用于调度、引用和追溯，应保持稳定。"""
    
    display_name: str = ""
    """面向 UI/日志的可读名称 (SHOULD)。"""
    
    description: str = ""
    """工作流简要说明 (SHOULD)。"""
    
    # === 主执行方法 (Stable) ===
    
    @abstractmethod
    async def run(self, ctx: "TaskContext") -> "TaskResult | None":
        """执行工作流的主方法 (MUST 实现)。
        
        这是 TaskFlow 的核心方法，子类必须实现。
        方法应编排子任务的执行顺序，使用 Python 控制流实现顺序、循环、分支逻辑。
        
        Args:
            ctx: 任务执行上下文。使用 ctx.run_subtask() 调用子任务，
                 使用 ctx.should_stop() 检查停止标志。
        
        Note:
            - 返回 None 时，运行时默认以共享 state 组装成功结果
            - 如需发出终态或等待确认信号，可返回 TaskResult
            - 长循环必须周期性检查 ctx.should_stop()
            - 关键阶段建议写入 ctx.state["phase"] 便于诊断
            - 可恢复游标建议写入 ctx.state["cursor"]
        """
        pass
