# Parameter Comparison: SARIMAX(3,0,3)(1,1,1)[24] with exog=[hm, ta]

Dataset: 2019 hourly Korean power demand (`power_demand_final.csv`), n=8760.

Five fits compared. All Rust runs use the *Profiled Kalman-GLS Trust-Region*
method (API string `profile-trust-region`). Statsmodels uses its default L-BFGS.
R uses `stats::arima(method="CSS-ML")` (CSS init → exact-MLE final stage).

## Estimated parameters

| Parameter | R CSS-ML | Rust sd profile-TR | statsmodels sd | Rust exact profile-TR | statsmodels exact |
|-----------|---------:|-------------------:|---------------:|----------------------:|------------------:|
| **hm (x1)**   |    +1.7224 |    +1.4692 |   −5.1166 |   +18.9342 |   +13.6602 |
| **ta (x2)**   |  −122.7978 |  −117.7640 | −268.3642 |  −159.1588 |  −271.2402 |
| ar.L1     |   +0.8559 |   +0.8572 |   +0.8533 |   +0.8699 |   +0.8669 |
| ar.L2     |   −0.0103 |   −0.0186 |   −0.0074 |   −0.0740 |   −0.0699 |
| ar.L3     |   +0.0953 |   +0.0999 |   +0.0956 |   +0.1351 |   +0.1343 |
| ma.L1     |   +0.8349 |   +0.8273 |   +0.8340 |   +0.8188 |   +0.8197 |
| ma.L2     |   +0.7234 |   +0.7286 |   +0.7209 |   +0.7243 |   +0.7230 |
| ma.L3     |   +0.4653 |   +0.4735 |   +0.4639 |   +0.4626 |   +0.4616 |
| ar.S.L24  |   +0.2471 |   +0.2806 |   +0.2451 |   +0.2471 |   +0.2457 |
| ma.S.L24  |   −0.9292 |   −0.9042 |   −0.9305 |   −0.9285 |   −0.9293 |
| sigma²    |   466,028 |   489,145 |   467,208 |   554,682 |   555,656 |
| **loglik** | **−69,427.71** | **−69,618.46** | **−69,443.49** | **−70,983.87** | **−70,992.03** |
| AIC       | 138,877.43 | 139,258.91 | 138,908.98 | 141,989.73 | 142,006.07 |
| nobs      |     8,736 |     8,736 |     8,736 |     8,760 |     8,760 |
| converged |   true |   **false** |   true |   **false** |   true |
| runtime (s) |   33.3 |    1.3 |   66.2 |    9.0 |  119.5 |

`sd` = `simple_differencing=True`. R's CSS-ML uses the exact log-likelihood at the
final stage on the same simple-differenced n = 8736 observations, so its LL/AIC
ARE directly comparable to Rust-sd and statsmodels-sd. Exact-state-space rows
(Rust exact, statsmodels exact) use n = 8760 and are a *different* objective —
their LL/AIC must not be compared head-to-head against the sd rows.

## Like-for-like comparisons

### Exact vs exact (Rust ↔ statsmodels)

| | Rust exact | statsmodels exact | diff |
|---|---:|---:|---:|
| loglik | −70,983.87 | −70,992.03 | **+8.17** (Rust higher) |
| ar/ma/sar/sma | — | — | all within 0.005 |
| hm | +18.93 | +13.66 | +5.27 |
| ta | −159.16 | −271.24 | +112.08 |
| sigma² | 554,682 | 555,656 | −974 |

Rust exact has *higher* LL than statsmodels exact (Rust has not even converged
formally yet still beats statsmodels). ARMA parameters agree to 3 decimals. The
exog β estimates diverge substantially — this is the under-identified direction
of the likelihood surface flagged in the plan.

### Simple-differencing comparisons (all three at n=8736)

| | R CSS-ML | Rust sd profile-TR | statsmodels sd |
|---|---:|---:|---:|
| loglik | −69,427.71 | −69,618.46 | −69,443.49 |
| Δlog-L vs R | 0 | −190.74 | −15.78 |
| hm sign | + | + | **−** |
| hm value | +1.72 | +1.47 | −5.12 |
| ta value | −122.80 | −117.76 | −268.36 |
| sar1 | 0.247 | **0.281** | 0.245 |
| sma1 | −0.929 | **−0.904** | −0.931 |

Observations:

- statsmodels sd reaches the highest LL but lands on **opposite sign for hm**
  relative to R. ta is twice as large in magnitude.
- Rust profile-TR sd reaches lower LL (~190 units below R) and converged=false.
  Its β estimates are the **closest to R in both sign and magnitude** among the
  three sd fits.
- Rust-sd seasonal terms `(sar1, sma1)` differ noticeably from R / statsmodels.
  Likely the converged=false flag is real — the trust-region BFGS has not
  fully exploited the seasonal-component basin under simple_diff.

## Direct answer: "are the parameters nearly identical?"

**No, not across all five — but ARMA terms agree closely while exog β does
not.** Specifically:

- Non-seasonal ARMA (ar1, ma1..ma3): all five within ~0.02 of each other.
- Seasonal AR/MA (sar1, sma1): four of five agree at ~(0.246, −0.93). Rust-sd
  drifts to (0.281, −0.904) — convergence issue.
- σ²: simple-diff group cluster near 470k; exact group cluster near 555k.
  Exact-vs-exact agree within 0.2%.
- **Exog β**: spans hm ∈ [−5.1, +18.9] and ta ∈ [−271, −118] across the five
  fits. The exog direction is the under-identified one in this likelihood.
  Among the three sd fits, Rust profile-TR is the closest to R CSS-ML.

## Practical recommendation for the paper

- **Headline comparison (exact-vs-exact)**: Rust agrees with statsmodels at the
  ARMA level to 3 decimals and beats it on LL by 8 units; β diverges in the
  flat direction.
- **Sd comparison**: highlight that Rust profile-TR is the only Python-side fit
  that reproduces R's β sign and magnitude. Note the converged=false caveat and
  the seasonal-term drift; raising maxiter beyond 200 should be tested before
  going to print.

## Raw data

- Rust + statsmodels: `param_compare_2019.csv`
- R: `param_compare_2019_R.csv`
- Scripts: `python_tests/compare_profile_methods_2019.py`,
  `python_tests/compare_profile_methods_R.R`
