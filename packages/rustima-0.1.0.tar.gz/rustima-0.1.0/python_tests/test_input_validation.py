"""API contract and input validation tests for all PyO3 functions.

Verifies:
- Error paths: wrong params, NaN/Inf rejection, order bounds, length mismatches
- Return types, dict keys, dtypes (API contract)
- Happy-path smoke for exog, concentrate_scale=False
"""

import numpy as np
import pytest

import rustima
from conftest import generate_ar1


def _sample_series(n: int = 30) -> np.ndarray:
    return np.linspace(0.0, 1.0, n, dtype=np.float64)


def test_loglike_rejects_wrong_param_length():
    y = _sample_series()
    with pytest.raises(ValueError, match="length mismatch"):
        rustima.sarimax_loglike(
            y,
            (1, 0, 1),
            (0, 0, 0, 0),
            np.array([0.2], dtype=np.float64),  # should be length 2
        )


def test_fit_rejects_wrong_start_params_length():
    y = _sample_series()
    with pytest.raises(ValueError, match="length mismatch"):
        rustima.sarimax_fit(
            y,
            (1, 0, 1),
            (0, 0, 0, 0),
            start_params=np.array([0.2], dtype=np.float64),  # should be length 2
        )


def test_rejects_invalid_seasonal_d_s_combination():
    y = _sample_series()
    with pytest.raises(ValueError, match="requires seasonal period s >= 2"):
        rustima.sarimax_loglike(
            y,
            (0, 0, 0),
            (0, 1, 0, 0),  # D>0 with s=0
            np.array([], dtype=np.float64),
        )


def test_exog_basic_acceptance():
    """Verify that exog (2D array) is accepted and produces valid results."""
    y = _sample_series()
    n = len(y)
    # Create a 2D exog array: (n_obs, 1)
    exog = np.ones((n, 1), dtype=np.float64)

    # loglike with exog: params = [exog_coeff(1), ar(1)] = 2 params
    ll = rustima.sarimax_loglike(
        y,
        (1, 0, 0),
        (0, 0, 0, 0),
        np.array([0.0, 0.1], dtype=np.float64),  # [exog_beta, ar_phi]
        exog=exog,
    )
    assert np.isfinite(ll), f"loglike with exog should be finite, got {ll}"

    # fit with exog
    result = rustima.sarimax_fit(
        y,
        (1, 0, 0),
        (0, 0, 0, 0),
        exog=exog,
    )
    assert result["converged"], "fit with exog should converge"
    assert len(result["params"]) == 2, "should have exog_coeff + ar_coeff"


def test_forecast_rejects_missing_future_exog():
    """Bug #1: exog model forecast must require future_exog."""
    y = _sample_series(n=100)
    exog = np.ones((len(y), 1), dtype=np.float64)
    result = rustima.sarimax_fit(
        y, (1, 0, 0), (0, 0, 0, 0), exog=exog,
        enforce_stationarity=False, enforce_invertibility=False,
    )
    params = np.array(result["params"], dtype=np.float64)
    with pytest.raises(ValueError, match="future_exog is required"):
        rustima.sarimax_forecast(
            y, (1, 0, 0), (0, 0, 0, 0), params,
            steps=5, exog=exog,
            # future_exog intentionally omitted
        )


def test_fit_rejects_non_positive_sigma2_when_not_concentrated():
    y = _sample_series()
    with pytest.raises(ValueError, match="variance sigma2 must be positive"):
        rustima.sarimax_fit(
            y,
            (1, 0, 0),
            (0, 0, 0, 0),
            start_params=np.array([0.1, -1.0], dtype=np.float64),  # ar(1), sigma2
            concentrate_scale=False,
        )


# =========================================================================
# Phase 5 tests: expanded coverage
# =========================================================================


# --- 5-4: NaN/Inf input rejection ---

class TestNanInfRejection:
    """All public functions must reject NaN/Inf input."""

    def test_loglike_rejects_nan(self):
        y = _sample_series()
        y[5] = np.nan
        with pytest.raises(ValueError, match="NaN or Inf"):
            rustima.sarimax_loglike(
                y, (1, 0, 0), (0, 0, 0, 0),
                np.array([0.5], dtype=np.float64),
            )

    def test_loglike_rejects_inf(self):
        y = _sample_series()
        y[3] = np.inf
        with pytest.raises(ValueError, match="NaN or Inf"):
            rustima.sarimax_loglike(
                y, (1, 0, 0), (0, 0, 0, 0),
                np.array([0.5], dtype=np.float64),
            )

    def test_fit_rejects_nan(self):
        y = _sample_series()
        y[0] = np.nan
        with pytest.raises(ValueError, match="NaN or Inf"):
            rustima.sarimax_fit(y, (1, 0, 0), (0, 0, 0, 0))

    def test_loglike_rejects_nan_in_exog(self):
        y = _sample_series()
        exog = np.ones((len(y), 1), dtype=np.float64)
        exog[3, 0] = np.nan
        with pytest.raises(ValueError, match="exog contains NaN or Inf"):
            rustima.sarimax_loglike(
                y, (1, 0, 0), (0, 0, 0, 0),
                np.array([0.0, 0.5], dtype=np.float64),
                exog=exog,
            )

    def test_fit_rejects_inf_in_exog(self):
        y = _sample_series()
        exog = np.ones((len(y), 1), dtype=np.float64)
        exog[4, 0] = np.inf
        with pytest.raises(ValueError, match="exog contains NaN or Inf"):
            rustima.sarimax_fit(
                y, (1, 0, 0), (0, 0, 0, 0),
                exog=exog,
            )

    def test_forecast_rejects_nan(self):
        y = _sample_series()
        y[10] = np.nan
        params = np.array([0.5], dtype=np.float64)
        with pytest.raises(ValueError, match="NaN or Inf"):
            rustima.sarimax_forecast(
                y, (1, 0, 0), (0, 0, 0, 0), params, steps=5,
            )

    def test_residuals_rejects_inf(self):
        y = _sample_series()
        y[2] = -np.inf
        params = np.array([0.5], dtype=np.float64)
        with pytest.raises(ValueError, match="NaN or Inf"):
            rustima.sarimax_residuals(
                y, (1, 0, 0), (0, 0, 0, 0), params,
            )

    def test_batch_fit_rejects_nan(self):
        y_good = _sample_series()
        y_bad = _sample_series()
        y_bad[4] = np.nan
        with pytest.raises(ValueError, match="index 1.*NaN or Inf"):
            rustima.sarimax_batch_fit(
                [y_good, y_bad], (1, 0, 0), (0, 0, 0, 0),
            )

    def test_batch_forecast_rejects_inf(self):
        y_good = _sample_series()
        y_bad = _sample_series()
        y_bad[0] = np.inf
        params = np.array([0.5], dtype=np.float64)
        with pytest.raises(ValueError, match="index 1.*NaN or Inf"):
            rustima.sarimax_batch_forecast(
                [y_good, y_bad], (1, 0, 0), (0, 0, 0, 0),
                [params, params], steps=3,
            )


# --- 5-3: Batch length mismatch negative tests ---

class TestBatchLengthMismatch:
    """Batch functions must reject length mismatches."""

    def test_batch_fit_exog_list_length_mismatch(self):
        y1 = _sample_series()
        y2 = _sample_series()
        exog1 = np.ones((len(y1), 1), dtype=np.float64)
        with pytest.raises(ValueError, match="exog_list length"):
            rustima.sarimax_batch_fit(
                [y1, y2], (1, 0, 0), (0, 0, 0, 0),
                exog_list=[exog1],  # only 1 exog for 2 series
            )

    def test_batch_forecast_series_params_length_mismatch(self):
        y = _sample_series()
        params = np.array([0.5], dtype=np.float64)
        with pytest.raises(ValueError, match="same length"):
            rustima.sarimax_batch_forecast(
                [y, y], (1, 0, 0), (0, 0, 0, 0),
                [params],  # only 1 params for 2 series
                steps=3,
            )

    def test_batch_forecast_exog_list_length_mismatch(self):
        y = _sample_series()
        params = np.array([0.5, 0.1], dtype=np.float64)  # exog_coeff + ar_coeff
        exog = np.ones((len(y), 1), dtype=np.float64)
        future_exog = np.ones((3, 1), dtype=np.float64)
        with pytest.raises(ValueError, match="exog_list length"):
            rustima.sarimax_batch_forecast(
                [y, y], (1, 0, 0), (0, 0, 0, 0),
                [params, params], steps=3,
                exog_list=[exog],  # only 1 exog for 2 series
                exog_forecast_list=[future_exog, future_exog],
            )

    def test_batch_forecast_rejects_short_future_exog_rows(self):
        y = _sample_series()
        exog = np.ones((len(y), 1), dtype=np.float64)
        fit = rustima.sarimax_fit(
            y, (1, 0, 0), (0, 0, 0, 0),
            exog=exog,
            enforce_stationarity=False,
            enforce_invertibility=False,
        )
        params = np.array(fit["params"], dtype=np.float64)
        short_future_exog = np.ones((2, 1), dtype=np.float64)  # steps=5보다 짧음

        with pytest.raises(ValueError, match="forecast steps requested"):
            rustima.sarimax_batch_forecast(
                [y], (1, 0, 0), (0, 0, 0, 0), [params],
                steps=5,
                exog_list=[exog],
                exog_forecast_list=[short_future_exog],
            )

    def test_batch_forecast_alpha_out_of_range(self):
        y = _sample_series()
        params = np.array([0.5], dtype=np.float64)
        with pytest.raises(ValueError, match="alpha"):
            rustima.sarimax_batch_forecast(
                [y], (1, 0, 0), (0, 0, 0, 0), [params],
                steps=3, alpha=0.0,
            )
        with pytest.raises(ValueError, match="alpha"):
            rustima.sarimax_batch_forecast(
                [y], (1, 0, 0), (0, 0, 0, 0), [params],
                steps=3, alpha=1.0,
            )
        with pytest.raises(ValueError, match="alpha"):
            rustima.sarimax_batch_forecast(
                [y], (1, 0, 0), (0, 0, 0, 0), [params],
                steps=3, alpha=-0.5,
            )


# --- 5-5: Minimum series length edge cases ---

class TestMinSeriesLength:
    """Models should reject very short series with a normal Python exception."""

    def test_series_shorter_than_order(self):
        """AR(3) on a 3-observation series should fail gracefully."""
        y = np.array([1.0, 2.0, 3.0], dtype=np.float64)
        with pytest.raises((ValueError, RuntimeError)):
            rustima.sarimax_fit(y, (3, 0, 0), (0, 0, 0, 0))

    def test_differenced_series_too_short(self):
        """ARIMA(1,2,0) on 4 observations → differenced series has 2 obs, barely usable."""
        y = np.array([1.0, 2.0, 4.0, 7.0], dtype=np.float64)
        with pytest.raises((ValueError, RuntimeError)):
            rustima.sarimax_fit(y, (1, 2, 0), (0, 0, 0, 0))

    def test_seasonal_too_short(self):
        """SARIMA with s=12 on 10 observations should fail."""
        y = np.arange(10, dtype=np.float64)
        with pytest.raises((ValueError, RuntimeError)):
            rustima.sarimax_fit(y, (1, 0, 0), (1, 0, 0, 12))


# --- 5-1: concentrate_scale=False full likelihood ---

class TestConcentrateScaleFalse:
    """Test full likelihood (sigma2 as free parameter)."""

    def test_fit_concentrate_false_produces_finite(self):
        """fit with concentrate_scale=False should converge and produce finite loglike."""
        np.random.seed(42)
        n = 200
        y = np.zeros(n)
        for t in range(1, n):
            y[t] = 0.7 * y[t - 1] + np.random.randn()

        result = rustima.sarimax_fit(
            y, (1, 0, 0), (0, 0, 0, 0),
            concentrate_scale=False,
            enforce_stationarity=False,
            enforce_invertibility=False,
        )
        assert result["converged"], f"fit should converge, got error: {result}"
        assert np.isfinite(result["loglike"]), "loglike should be finite"
        # With concentrate_scale=False, params include sigma2
        assert len(result["params"]) == 2, "should have ar(1) + sigma2"
        assert result["params"][1] > 0, "sigma2 must be positive"

    def test_loglike_concentrate_false_vs_true(self):
        """concentrated and full loglike should be close for well-fit model."""
        np.random.seed(42)
        n = 200
        y = np.zeros(n)
        for t in range(1, n):
            y[t] = 0.7 * y[t - 1] + np.random.randn()

        result = rustima.sarimax_fit(
            y, (1, 0, 0), (0, 0, 0, 0),
            concentrate_scale=False,
            enforce_stationarity=False,
            enforce_invertibility=False,
        )
        ll_full = result["loglike"]

        # Evaluate concentrated loglike at same AR param
        ar_param = np.array([result["params"][0]], dtype=np.float64)
        ll_conc = rustima.sarimax_loglike(
            y, (1, 0, 0), (0, 0, 0, 0), ar_param,
            concentrate_scale=True,
            enforce_stationarity=False, enforce_invertibility=False,
        )
        # Both should be close (not exact due to different parameterizations)
        assert abs(ll_full - ll_conc) < 5.0, (
            f"full vs concentrated loglike too far apart: {ll_full} vs {ll_conc}"
        )


# --- 5-2: Batch forecast with exog (happy path) ---

class TestBatchForecastExog:
    """Test batch_forecast with exogenous variables."""

    def test_batch_forecast_with_exog_happy_path(self):
        """batch_forecast with exog should produce valid forecasts."""
        np.random.seed(42)
        n = 100
        exog_col = np.random.randn(n)
        y = np.zeros(n)
        for t in range(1, n):
            y[t] = 0.5 * y[t - 1] + 0.3 * exog_col[t] + np.random.randn() * 0.5

        exog = exog_col.reshape(-1, 1).astype(np.float64)
        result = rustima.sarimax_fit(
            y, (1, 0, 0), (0, 0, 0, 0), exog=exog,
            enforce_stationarity=False, enforce_invertibility=False,
        )
        assert result["converged"], f"fit failed: {result}"

        params = np.array(result["params"], dtype=np.float64)
        future_exog = np.ones((5, 1), dtype=np.float64)

        forecasts = rustima.sarimax_batch_forecast(
            [y, y], (1, 0, 0), (0, 0, 0, 0),
            [params, params], steps=5,
            exog_list=[exog, exog],
            exog_forecast_list=[future_exog, future_exog],
        )
        assert len(forecasts) == 2
        for i, fc in enumerate(forecasts):
            assert "error" not in fc, f"series {i} failed: {fc.get('error')}"
            assert len(fc["mean"]) == 5
            assert all(np.isfinite(fc["mean"])), f"series {i}: non-finite forecast"


# --- 4-2 regression: error type check ---

class TestErrorTypes:
    """Verify that error types are correctly mapped."""

    def test_optimization_failure_raises_runtime_error(self):
        """OptimizationFailed should raise RuntimeError, not ValueError."""
        # A tiny series with complex model should trigger optimization failure
        y = np.array([1.0, 2.0], dtype=np.float64)
        with pytest.raises((RuntimeError, ValueError)):
            rustima.sarimax_fit(
                y, (3, 0, 3), (0, 0, 0, 0),
                enforce_stationarity=False,
                enforce_invertibility=False,
            )


# --- Vuln-2: Model order upper bounds ---

class TestOrderUpperBounds:
    """Excessive model orders must be rejected to prevent OOM/DoS."""

    def test_rejects_p_too_large(self):
        y = _sample_series(n=100)
        with pytest.raises(ValueError, match="AR order p=.*exceeds maximum"):
            rustima.sarimax_loglike(
                y, (21, 0, 0), (0, 0, 0, 0),
                np.zeros(21, dtype=np.float64),
            )

    def test_rejects_q_too_large(self):
        y = _sample_series(n=100)
        with pytest.raises(ValueError, match="MA order q=.*exceeds maximum"):
            rustima.sarimax_loglike(
                y, (0, 0, 21), (0, 0, 0, 0),
                np.zeros(21, dtype=np.float64),
            )

    def test_rejects_d_too_large(self):
        y = _sample_series(n=100)
        with pytest.raises(ValueError, match="differencing order d=.*exceeds maximum"):
            rustima.sarimax_loglike(
                y, (0, 4, 0), (0, 0, 0, 0),
                np.array([], dtype=np.float64),
            )

    def test_rejects_seasonal_P_too_large(self):
        y = _sample_series(n=100)
        with pytest.raises(ValueError, match="seasonal AR order P=.*exceeds maximum"):
            rustima.sarimax_loglike(
                y, (0, 0, 0), (5, 0, 0, 4),
                np.zeros(5, dtype=np.float64),
            )

    def test_rejects_seasonal_D_too_large(self):
        y = _sample_series(n=100)
        with pytest.raises(ValueError, match="seasonal differencing D=.*exceeds maximum"):
            rustima.sarimax_loglike(
                y, (0, 0, 0), (0, 3, 0, 4),
                np.array([], dtype=np.float64),
            )

    def test_rejects_seasonal_Q_too_large(self):
        y = _sample_series(n=100)
        with pytest.raises(ValueError, match="seasonal MA order Q=.*exceeds maximum"):
            rustima.sarimax_loglike(
                y, (0, 0, 0), (0, 0, 5, 4),
                np.zeros(5, dtype=np.float64),
            )

    def test_rejects_s_too_large(self):
        y = _sample_series(n=1000)
        with pytest.raises(ValueError, match="seasonal period s=.*exceeds maximum"):
            rustima.sarimax_loglike(
                y, (0, 0, 0), (1, 0, 0, 400),
                np.zeros(1, dtype=np.float64),
            )

    def test_rejects_seasonal_order_without_period(self):
        """P>0 or D>0 or Q>0 with s<2 must be rejected."""
        y = _sample_series(n=100)
        with pytest.raises(ValueError, match="requires seasonal period s >= 2"):
            rustima.sarimax_loglike(
                y, (0, 0, 0), (1, 0, 0, 0),
                np.zeros(1, dtype=np.float64),
            )

    def test_accepts_max_valid_orders(self):
        """Maximum valid individual orders should still be accepted."""
        y = _sample_series(n=100)
        # p=20 is the limit, should be accepted (though fit might fail for other reasons)
        ll = rustima.sarimax_loglike(
            y, (20, 0, 0), (0, 0, 0, 0),
            np.zeros(20, dtype=np.float64),
            enforce_stationarity=False,
        )
        assert np.isfinite(ll)


# --- Vuln-1: exog NaN/Inf validation (verify existing guards) ---

class TestExogNanInfRejection:
    """Verify that NaN/Inf in exog is rejected (not silently computed)."""

    def test_loglike_rejects_nan_exog(self):
        y = _sample_series(n=50)
        exog = np.ones((50, 1), dtype=np.float64)
        exog[5, 0] = np.nan
        with pytest.raises(ValueError, match="NaN or Inf"):
            rustima.sarimax_loglike(
                y, (1, 0, 0), (0, 0, 0, 0),
                np.array([0.0, 0.1], dtype=np.float64),
                exog=exog,
            )

    def test_fit_rejects_inf_exog(self):
        y = _sample_series(n=50)
        exog = np.ones((50, 1), dtype=np.float64)
        exog[3, 0] = np.inf
        with pytest.raises(ValueError, match="NaN or Inf"):
            rustima.sarimax_fit(
                y, (1, 0, 0), (0, 0, 0, 0), exog=exog,
            )

    def test_forecast_rejects_nan_exog_forecast(self):
        y = _sample_series(n=100)
        exog = np.ones((100, 1), dtype=np.float64)
        result = rustima.sarimax_fit(
            y, (1, 0, 0), (0, 0, 0, 0), exog=exog,
            enforce_stationarity=False, enforce_invertibility=False,
        )
        params = np.array(result["params"], dtype=np.float64)
        future_exog = np.ones((5, 1), dtype=np.float64)
        future_exog[2, 0] = np.nan
        with pytest.raises(ValueError, match="NaN or Inf"):
            rustima.sarimax_forecast(
                y, (1, 0, 0), (0, 0, 0, 0), params, steps=5,
                exog=exog, future_exog=future_exog,
            )


# =========================================================================
# API contract tests (merged from test_api_contract.py)
# =========================================================================

@pytest.fixture(scope="module")
def ar1_data():
    return generate_ar1()


@pytest.fixture(scope="module")
def ar1_fit_result(ar1_data):
    return rustima.sarimax_fit(ar1_data, (1, 0, 0), (0, 0, 0, 0))


@pytest.fixture(scope="module")
def ar1_params(ar1_fit_result):
    return np.array(ar1_fit_result["params"])


class TestVersionContract:
    def test_returns_string(self):
        assert isinstance(rustima.version(), str)

    def test_version_format(self):
        parts = rustima.version().split(".")
        assert len(parts) >= 2


class TestLoglikeContract:
    def test_returns_finite_float(self, ar1_data, ar1_params):
        result = rustima.sarimax_loglike(
            ar1_data, (1, 0, 0), (0, 0, 0, 0), ar1_params,
        )
        assert isinstance(result, float) and np.isfinite(result)

    def test_wrong_param_length_raises(self, ar1_data):
        with pytest.raises((ValueError, RuntimeError)):
            rustima.sarimax_loglike(
                ar1_data, (1, 0, 0), (0, 0, 0, 0),
                np.array([0.5, 0.3]),
            )

    def test_accepts_exog_none(self, ar1_data, ar1_params):
        result = rustima.sarimax_loglike(
            ar1_data, (1, 0, 0), (0, 0, 0, 0), ar1_params, exog=None,
        )
        assert np.isfinite(result)


class TestFitContract:
    REQUIRED_KEYS = {
        "params", "loglike", "aic", "bic", "scale",
        "converged", "method", "n_obs", "n_iter",
    }

    def test_returns_dict(self, ar1_data):
        result = rustima.sarimax_fit(ar1_data, (1, 0, 0), (0, 0, 0, 0))
        assert isinstance(result, dict)

    def test_required_keys_present(self, ar1_fit_result):
        missing = self.REQUIRED_KEYS - set(ar1_fit_result.keys())
        assert not missing, f"Missing keys: {missing}"

    def test_params_is_list_of_floats(self, ar1_fit_result):
        params = ar1_fit_result["params"]
        assert isinstance(params, list)
        assert all(isinstance(p, float) for p in params)

    def test_loglike_is_float(self, ar1_fit_result):
        assert isinstance(ar1_fit_result["loglike"], float)

    def test_converged_is_bool(self, ar1_fit_result):
        assert isinstance(ar1_fit_result["converged"], bool)

    def test_params_length_matches_order(self, ar1_data):
        result = rustima.sarimax_fit(ar1_data, (2, 0, 0), (0, 0, 0, 0))
        assert len(result["params"]) == 2

    def test_n_obs_matches_data_length(self, ar1_data, ar1_fit_result):
        assert ar1_fit_result["n_obs"] == len(ar1_data)


class TestForecastContract:
    REQUIRED_KEYS = {"mean", "variance", "ci_lower", "ci_upper"}

    def test_returns_dict_with_keys(self, ar1_data, ar1_params):
        result = rustima.sarimax_forecast(
            ar1_data, (1, 0, 0), (0, 0, 0, 0), ar1_params, steps=5,
        )
        assert isinstance(result, dict)
        missing = self.REQUIRED_KEYS - set(result.keys())
        assert not missing, f"Missing keys: {missing}"

    def test_output_length_matches_steps(self, ar1_data, ar1_params):
        for steps in [1, 5, 10, 20]:
            result = rustima.sarimax_forecast(
                ar1_data, (1, 0, 0), (0, 0, 0, 0), ar1_params, steps=steps,
            )
            for key in self.REQUIRED_KEYS:
                assert len(result[key]) == steps

    def test_variance_non_negative(self, ar1_data, ar1_params):
        result = rustima.sarimax_forecast(
            ar1_data, (1, 0, 0), (0, 0, 0, 0), ar1_params, steps=10,
        )
        assert all(v >= 0 for v in result["variance"])


class TestResidualsContract:
    REQUIRED_KEYS = {"residuals", "standardized_residuals"}

    def test_returns_dict_with_keys(self, ar1_data, ar1_params):
        result = rustima.sarimax_residuals(
            ar1_data, (1, 0, 0), (0, 0, 0, 0), ar1_params,
        )
        assert isinstance(result, dict)
        missing = self.REQUIRED_KEYS - set(result.keys())
        assert not missing

    def test_residuals_length_matches_data(self, ar1_data, ar1_params):
        result = rustima.sarimax_residuals(
            ar1_data, (1, 0, 0), (0, 0, 0, 0), ar1_params,
        )
        assert len(result["residuals"]) == len(ar1_data)


class TestBatchLoglikeContract:
    def test_returns_list(self, ar1_data, ar1_params):
        result = rustima.sarimax_batch_loglike(
            [ar1_data, ar1_data], (1, 0, 0), (0, 0, 0, 0), ar1_params,
        )
        assert isinstance(result, list) and len(result) == 2

    def test_each_element_has_loglike(self, ar1_data, ar1_params):
        result = rustima.sarimax_batch_loglike(
            [ar1_data], (1, 0, 0), (0, 0, 0, 0), ar1_params,
        )
        assert isinstance(result[0], dict) and "loglike" in result[0]


class TestBatchFitContract:
    def test_returns_list_of_dicts(self, ar1_data):
        result = rustima.sarimax_batch_fit(
            [ar1_data, ar1_data], (1, 0, 0), (0, 0, 0, 0),
        )
        assert isinstance(result, list) and len(result) == 2
        assert all(isinstance(r, dict) for r in result)

    def test_each_dict_has_fit_keys(self, ar1_data):
        result = rustima.sarimax_batch_fit([ar1_data], (1, 0, 0), (0, 0, 0, 0))
        required = {"params", "loglike", "converged"}
        for r in result:
            assert not (required - set(r.keys()))

    def test_empty_input_returns_empty(self):
        assert rustima.sarimax_batch_fit([], (1, 0, 0), (0, 0, 0, 0)) == []


class TestBatchForecastContract:
    def test_returns_list_with_forecast_keys(self, ar1_data, ar1_params):
        result = rustima.sarimax_batch_forecast(
            [ar1_data], (1, 0, 0), (0, 0, 0, 0), [ar1_params], steps=5,
        )
        assert isinstance(result, list) and len(result) == 1
        required = {"mean", "variance", "ci_lower", "ci_upper"}
        assert not (required - set(result[0].keys()))

    def test_output_length_matches_input(self, ar1_data, ar1_params):
        result = rustima.sarimax_batch_forecast(
            [ar1_data] * 3, (1, 0, 0), (0, 0, 0, 0), [ar1_params] * 3, steps=5,
        )
        assert len(result) == 3

    def test_empty_input_returns_empty(self):
        assert rustima.sarimax_batch_forecast(
            [], (1, 0, 0), (0, 0, 0, 0), [], steps=5,
        ) == []
