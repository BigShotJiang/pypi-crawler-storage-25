# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

from typing import Any, Dict, SupportsFloat, Tuple

import gymnasium as gym

from amesa_core.agent.scenario import Scenario
from amesa_core.examples.cstr.sim.sim import CSTRSim
from amesa_core.networking.sim.server_amesa import ServerAmesa


class ServerImpl(ServerAmesa):
    """Server impl for CSTR sim."""

    def __init__(self, *args, **kwargs):
        self.env_init = kwargs.get("env_init", {})
        self.env_id = kwargs.get("env_id")
        # Event processors may call set_scenario before an explicit make/reset.
        # Keep a default env available so those calls are safe.
        self.env = CSTRSim(self.env_init)

    def _ensure_env(self) -> None:
        if not hasattr(self, "env") or self.env is None:
            self.env = CSTRSim(self.env_init)

    async def make(self, env_id: str, env_init: dict):
        self.env_id = env_id if env_id else self.env_id
        self.env_init = env_init if env_init else self.env_init
        self.env = CSTRSim(self.env_init)
        return {"id": "cstr_simulator", "max_episode_steps": 1000}

    async def sensor_space_info(self) -> gym.Space:
        self._ensure_env()
        return self.env.sensor_space

    async def action_space_info(self) -> gym.Space:
        self._ensure_env()
        return self.env.action_space

    async def action_space_sample(self) -> Any:
        self._ensure_env()
        return self.env.action_space.sample()

    async def reset(self) -> Tuple[Any, Dict[str, Any]]:
        self._ensure_env()
        return self.env.reset()

    async def step(
        self, action
    ) -> Tuple[Any, SupportsFloat, bool, bool, Dict[str, Any]]:
        self._ensure_env()
        return self.env.step(action)

    async def close(self):
        if hasattr(self, "env") and self.env is not None:
            self.env.close()

    async def set_scenario(self, scenario):
        self._ensure_env()
        self.env.set_scenario(scenario)

    async def get_scenario(self):
        self._ensure_env()
        if self.env.scenario is None:
            return Scenario({"Cref_signal": "complete"})
        return self.env.scenario

    async def get_render(self):
        self._ensure_env()
        return f"CSTR: T={self.env.T:.1f} Tc={self.env.Tc:.1f} Ca={self.env.Ca:.1f}"
