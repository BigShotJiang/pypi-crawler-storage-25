# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

"""
Minimal CSTR (Continuous Stirred Tank Reactor) simulation for integration testing.
Provides T, Tc, Ca, Cref, Tref sensors and a cooling action.
"""

from typing import Any, Dict, Optional, SupportsFloat, Tuple

import gymnasium as gym
import numpy as np

from amesa_core.agent.scenario import Scenario


class CSTRSim(gym.Env):
    """Minimal CSTR sim for e2e tests. Simplified reactor dynamics."""

    def __init__(self, env_init: dict = {}):
        self.cref_signal = env_init.get("Cref_signal", "complete")
        self.max_steps = int(env_init.get("max_steps", 100))
        self.episode_max_steps = self.max_steps
        self.step_count = 0

        # State: T (reactor temp), Tc (coolant), Ca (concentration)
        self.T = 300.0
        self.Tc = 300.0
        self.Ca = 5.0
        self.Cref = 8.0
        self.Tref = 311.0

        # Sensor space: T, Tc, Ca, Cref, Tref (CSTR teachers expect these)
        self.sensor_space = gym.spaces.Dict(
            {
                "T": gym.spaces.Box(low=0.0, high=500.0, shape=(1,), dtype=np.float32),
                "Tc": gym.spaces.Box(low=0.0, high=500.0, shape=(1,), dtype=np.float32),
                "Ca": gym.spaces.Box(low=0.0, high=20.0, shape=(1,), dtype=np.float32),
                "Cref": gym.spaces.Box(low=0.0, high=20.0, shape=(1,), dtype=np.float32),
                "Tref": gym.spaces.Box(low=250.0, high=400.0, shape=(1,), dtype=np.float32),
            }
        )
        # Action: coolant delta (Box) - simplified
        self.action_space = gym.spaces.Box(
            low=np.array([-10.0]), high=np.array([10.0]), dtype=np.float32
        )
        self.scenario: Optional[Scenario] = None

    def _signal_episode_limit(self, signal_name: str) -> int:
        """Return per-signal episode cap, always bounded by global max_steps."""
        per_signal_steps = {
            "complete": self.max_steps,
            "ss1": 30,
            "ss2": 30,
            "ss3": 30,
            "transition": 45,
        }
        requested = per_signal_steps.get(signal_name, self.max_steps)
        return int(min(self.max_steps, requested))

    def _get_sensors(self) -> Dict[str, np.ndarray]:
        return {
            "T": np.array([self.T], dtype=np.float32),
            "Tc": np.array([self.Tc], dtype=np.float32),
            "Ca": np.array([self.Ca], dtype=np.float32),
            "Cref": np.array([self.Cref], dtype=np.float32),
            "Tref": np.array([self.Tref], dtype=np.float32),
        }

    def reset(
        self,
        *,
        seed: Optional[int] = None,
        options: Optional[dict] = None,
    ) -> Tuple[Dict[str, np.ndarray], Dict[str, Any]]:
        super().reset(seed=seed)
        self.step_count = 0
        self.T = 300.0
        self.Tc = 300.0
        self.Ca = 5.0
        self.episode_max_steps = self.max_steps
        if isinstance(self.scenario, Scenario):
            sample = self.scenario.sample()
            if "Cref_signal" in sample:
                self.cref_signal = str(sample["Cref_signal"])
                self.episode_max_steps = self._signal_episode_limit(self.cref_signal)
            if "max_steps" in sample:
                # Allow scenario to explicitly reduce episode horizon.
                self.episode_max_steps = int(min(self.max_steps, int(sample["max_steps"])))
            if "Cref" in sample:
                self.Cref = float(sample["Cref"])
            if "Tref" in sample:
                self.Tref = float(sample["Tref"])
        return self._get_sensors(), {}

    def step(
        self, action
    ) -> Tuple[Dict[str, np.ndarray], SupportsFloat, bool, bool, Dict[str, Any]]:
        self.step_count += 1
        delta_tc = float(np.clip(action, self.action_space.low, self.action_space.high)[0])
        self.Tc = np.clip(self.Tc + delta_tc, 250.0, 400.0)
        self.T = np.clip(
            self.T + 0.1 * (self.Tref - self.T) - 0.05 * (self.T - self.Tc),
            250.0,
            400.0,
        )
        # Couple concentration dynamics to reactor temperature so coolant actions
        # can influence Ca tracking. Without this coupling, reward is nearly
        # action-independent and PPO has little/no learnable signal.
        # Stronger coupling so policy actions measurably influence concentration.
        temp_effect = -0.01 * (self.T - 300.0)
        self.Ca = np.clip(
            self.Ca + 0.02 * (self.Cref - self.Ca) + temp_effect,
            0.0,
            20.0,
        )
        reward = 1.0 / (1.0 + abs(self.Cref - self.Ca))
        done = self.step_count >= self.episode_max_steps
        return self._get_sensors(), reward, done, False, {}

    def set_scenario(self, scenario: Scenario):
        self.scenario = scenario
